"""Autonomous mode CLI commands."""

import logging
import sys
from pathlib import Path
from typing import Optional

import click

from core.autonomous_executor import AutonomousConfig, AutonomousExecutor
from core.checkpoint_manager import CheckpointManager
from core.progress_tracker import ProgressTracker


@click.group()
def autonomous() -> None:
    """Autonomous novel generation commands."""
    pass


@autonomous.command("start")
@click.argument("project_name")
@click.option("--start-phase", default="new_novel", help="Phase to start from")
@click.option("--end-phase", default="autonomous", help="Phase to end at")
@click.option("--human-in-loop", is_flag=True, help="Enable human-in-the-loop checkpoints")
@click.option("--max-chapters", type=int, help="Maximum number of chapters to generate")
@click.option("--provider", default="openai", help="LLM provider to use")
@click.option("--resume", is_flag=True, help="Resume from latest checkpoint")
@click.option("--checkpoint-id", help="Resume from specific checkpoint ID")
@click.option("--git-commit", is_flag=True, help="Auto-commit after each phase")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--checkpoint-dir", default=".checkpoints", help="Directory for checkpoints")
@click.pass_context
def start_autonomous(
    ctx: click.Context,
    project_name: str,
    start_phase: str,
    end_phase: str,
    human_in_loop: bool,
    max_chapters: Optional[int],
    provider: str,
    resume: bool,
    checkpoint_id: Optional[str],
    git_commit: bool,
    project_dir: str,
    checkpoint_dir: str,
) -> None:
    """Run autonomous novel generation pipeline."""
    debug = ctx.obj.get("debug", False)
    logger = logging.getLogger("scribe")

    try:
        if resume:
            logger.info(f"Resuming autonomous pipeline for: {project_name}")
        else:
            logger.info(f"Starting autonomous pipeline for: {project_name}")

        project_path = Path(project_dir) / project_name
        if not project_path.exists() and not resume:
            logger.error(f"Project '{project_name}' not found")
            logger.info(f"Create it first with: scribe new {project_name}")
            sys.exit(1)

        config = AutonomousConfig(
            project_name=project_name,
            start_phase=start_phase,
            end_phase=end_phase,
            human_in_loop=human_in_loop,
            max_chapters=max_chapters,
            provider=provider,
        )

        executor = AutonomousExecutor(config=config, storage_path=Path(project_dir))

        logger.info("Configuration:")
        logger.info(f"  Start Phase: {start_phase}")
        logger.info(f"  End Phase: {end_phase}")
        logger.info(f"  Human-in-Loop: {human_in_loop}")
        if max_chapters:
            logger.info(f"  Max Chapters: {max_chapters}")
        logger.info(f"  Provider: {provider}")
        logger.info(f"  Git Commits: {git_commit}")
        logger.info("")

        result = executor.execute(resume=resume)

        if result.success:
            logger.info("✅ Autonomous pipeline completed successfully!")
            logger.info(f"   Project: {project_name}")
            logger.info(f"   Completed Phases: {len(result.completed_phases)}")

            if result.completed_phases:
                logger.info(f"   Phases: {', '.join(result.completed_phases)}")
        else:
            logger.error("❌ Autonomous pipeline failed")
            logger.error(f"   Status: {result.final_status.value}")
            if result.error:
                logger.error(f"   Error: {result.error}")
            logger.info(f"   Completed Phases: {len(result.completed_phases)}")
            logger.info("   Use 'scribe autonomous start --resume' to continue from checkpoint")
            sys.exit(1)

    except Exception as e:
        logger.error(f"Autonomous pipeline error: {e}")
        if debug:
            logger.exception("Full error trace:")
        sys.exit(1)


@autonomous.command("checkpoints")
@click.option("--project-dir", default=".checkpoints", help="Directory containing checkpoints")
@click.option("--project-name", help="Filter by project name")
@click.option("--limit", type=int, default=10, help="Maximum number of checkpoints to show")
@click.pass_context
def list_checkpoints(
    ctx: click.Context, project_dir: str, project_name: Optional[str], limit: int
) -> None:
    """List available checkpoints."""
    logger = logging.getLogger("scribe")

    try:
        effective_project_name = project_name or "default"
        checkpoint_manager = CheckpointManager(
            project_name=effective_project_name,
            storage_path=Path(project_dir),
        )
        checkpoints = checkpoint_manager.list_checkpoints()

        if project_name:
            checkpoints = [cp for cp in checkpoints if cp.project_name == project_name]

        if not checkpoints:
            logger.info("No checkpoints found")
            return

        logger.info(f"Found {len(checkpoints)} checkpoint(s):")
        logger.info("")

        for i, checkpoint in enumerate(checkpoints[:limit], 1):
            progress_pct = checkpoint.progress_state.progress_percentage
            status = checkpoint.progress_state.status.value

            logger.info(f"{i}. {checkpoint.checkpoint_id}")
            logger.info(f"   Project: {checkpoint.project_name}")
            logger.info(f"   Phase: {checkpoint.progress_state.current_phase}")
            logger.info(f"   Progress: {progress_pct:.1f}%")
            logger.info(f"   Status: {status}")
            logger.info(f"   Completed: {len(checkpoint.completed_workflows)} workflows")
            logger.info(f"   Timestamp: {checkpoint.timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
            logger.info("")

        if len(checkpoints) > limit:
            logger.info(f"... and {len(checkpoints) - limit} more (use --limit to show more)")

    except Exception as e:
        logger.error(f"Failed to list checkpoints: {e}")
        sys.exit(1)


@autonomous.command("show-checkpoint")
@click.argument("checkpoint_id")
@click.option("--project-dir", default=".checkpoints", help="Directory containing checkpoints")
@click.pass_context
def show_checkpoint(ctx: click.Context, checkpoint_id: str, project_dir: str) -> None:
    """Show detailed checkpoint information."""
    logger = logging.getLogger("scribe")

    try:
        checkpoint_manager = CheckpointManager(
            project_name="default",
            storage_path=Path(project_dir),
        )
        checkpoint = checkpoint_manager.load_checkpoint(checkpoint_id)

        if not checkpoint:
            logger.error(f"Checkpoint '{checkpoint_id}' not found")
            sys.exit(1)

        progress = checkpoint.progress_state

        logger.info(f"Checkpoint: {checkpoint.checkpoint_id}")
        logger.info("=" * 60)
        logger.info(f"Project: {checkpoint.project_name}")
        logger.info(f"Created: {checkpoint.timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info("")
        logger.info("Progress:")
        logger.info(f"  Current Phase: {progress.current_phase}")
        logger.info(f"  Completed Phases: {len(progress.completed_phases)}")
        if progress.completed_phases:
            for phase in progress.completed_phases:
                logger.info(f"    - {phase}")
        logger.info(f"  Steps: {progress.completed_steps}/{progress.total_steps}")
        logger.info(f"  Progress: {progress.progress_percentage:.1f}%")
        logger.info(f"  Status: {progress.status.value}")
        logger.info("")

        if progress.current_step:
            logger.info(f"Current Step: {progress.current_step}")

        if checkpoint.current_workflow:
            logger.info(f"Current Workflow: {checkpoint.current_workflow}")

        if checkpoint.execution_context:
            logger.info("Execution Context:")
            for key, value in checkpoint.execution_context.items():
                logger.info(f"  {key}: {value}")

        if progress.error:
            logger.info(f"Error: {progress.error}")

    except Exception as e:
        logger.error(f"Failed to show checkpoint: {e}")
        sys.exit(1)


@autonomous.command("delete-checkpoint")
@click.argument("checkpoint_id")
@click.option("--project-dir", default=".checkpoints", help="Directory containing checkpoints")
@click.option("--force", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def delete_checkpoint(
    ctx: click.Context, checkpoint_id: str, project_dir: str, force: bool
) -> None:
    """Delete a checkpoint."""
    logger = logging.getLogger("scribe")

    try:
        checkpoint_manager = CheckpointManager(
            project_name="default",
            storage_path=Path(project_dir),
        )

        if not force:
            checkpoint = checkpoint_manager.load_checkpoint(checkpoint_id)
            if not checkpoint:
                logger.error(f"Checkpoint '{checkpoint_id}' not found")
                sys.exit(1)

            logger.info(f"Checkpoint: {checkpoint.checkpoint_id}")
            logger.info(f"Project: {checkpoint.project_name}")
            logger.info(f"Phase: {checkpoint.progress_state.current_phase}")
            logger.info("")

            confirm = click.confirm("Are you sure you want to delete this checkpoint?")
            if not confirm:
                logger.info("Deletion cancelled")
                return

        deleted = checkpoint_manager.delete_checkpoint(checkpoint_id)

        if deleted:
            logger.info(f"✅ Checkpoint '{checkpoint_id}' deleted successfully")
        else:
            logger.error(f"Failed to delete checkpoint '{checkpoint_id}'")
            sys.exit(1)

    except Exception as e:
        logger.error(f"Failed to delete checkpoint: {e}")
        sys.exit(1)


@autonomous.command("progress")
@click.argument("project_name")
@click.option("--project-dir", default=".checkpoints", help="Directory containing checkpoints")
@click.pass_context
def show_progress(ctx: click.Context, project_name: str, project_dir: str) -> None:
    """Show project execution progress."""
    logger = logging.getLogger("scribe")

    try:
        progress_tracker = ProgressTracker(
            project_name=project_name,
            storage_path=Path(project_dir),
        )
        state = progress_tracker.get_state()

        if not state:
            logger.info(f"No progress state found for '{project_name}'")
            logger.info("Start autonomous mode to track progress")
            return

        logger.info(f"Progress for: {project_name}")
        logger.info("=" * 60)
        logger.info(f"Current Phase: {state.current_phase}")
        logger.info(f"Status: {state.status.value}")
        logger.info(f"Progress: {state.progress_percentage:.1f}%")
        logger.info(f"Steps: {state.completed_steps}/{state.total_steps}")
        logger.info("")

        if state.completed_phases:
            logger.info("Completed Phases:")
            for phase in state.completed_phases:
                logger.info(f"  ✅ {phase}")

        logger.info("")
        logger.info(f"Started: {state.start_time.strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"Last Update: {state.last_update.strftime('%Y-%m-%d %H:%M:%S')}")

        if state.error:
            logger.info(f"Error: {state.error}")

    except Exception as e:
        logger.error(f"Failed to show progress: {e}")
        sys.exit(1)
