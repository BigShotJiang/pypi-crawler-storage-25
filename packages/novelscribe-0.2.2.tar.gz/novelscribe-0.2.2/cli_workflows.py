"""Workflow exploration and management commands."""

import logging
import sys
from pathlib import Path

import click

from core.language_config import LanguageCode, get_current_language
from core.workflow_loader import WorkflowLoader


@click.group()
def workflows():
    """Workflow exploration and management commands."""
    pass


@workflows.command("list")
@click.pass_context
def workflows_list(ctx: click.Context):
    """List all available workflows."""
    logger = logging.getLogger("scribe")

    try:
        workflows_dir = Path("workflows")
        if not workflows_dir.exists():
            logger.error("Workflows directory not found")
            sys.exit(1)

        lang_str = ctx.obj.get("lang") if ctx.obj else None
        language = LanguageCode(lang_str) if lang_str else None
        project_dir = Path.cwd()

        current_language = get_current_language(
            explicit_language=language,
            project_dir=project_dir,
        )

        loader = WorkflowLoader(workflows_dir, language=current_language)
        all_workflows = loader.load_all_workflows()

        if not all_workflows:
            logger.warning("No workflows found")
            return

        logger.info(f"Available Workflows ({len(all_workflows)}) [Language: {current_language}]:")
        logger.info("")

        setup_workflows = []
        development_workflows = []
        production_workflows = []
        complete_workflows = []

        for workflow in all_workflows:
            name = workflow.name
            if name == "new_novel":
                setup_workflows.append(workflow)
            elif name in [
                "worldbuilding_phase",
                "character_phase",
                "outline_phase",
                "chapter_plan_phase",
            ]:
                development_workflows.append(workflow)
            elif name in ["writing_phase", "continuity_phase", "verification_phase"]:
                production_workflows.append(workflow)
            elif name == "autonomous":
                complete_workflows.append(workflow)

        if setup_workflows:
            logger.info("Setup:")
            for workflow in sorted(setup_workflows, key=lambda w: w.name):
                name_width = max(25, len(workflow.name))
                logger.info(f"  {workflow.name:<{name_width}} - {workflow.description}")
            logger.info("")

        if development_workflows:
            logger.info("Development Phases:")
            for workflow in sorted(development_workflows, key=lambda w: w.name):
                name_width = max(25, len(workflow.name))
                logger.info(f"  {workflow.name:<{name_width}} - {workflow.description}")
            logger.info("")

        if production_workflows:
            logger.info("Production:")
            for workflow in sorted(production_workflows, key=lambda w: w.name):
                name_width = max(25, len(workflow.name))
                logger.info(f"  {workflow.name:<{name_width}} - {workflow.description}")
            logger.info("")

        if complete_workflows:
            logger.info("Complete:")
            for workflow in sorted(complete_workflows, key=lambda w: w.name):
                name_width = max(25, len(workflow.name))
                logger.info(f"  {workflow.name:<{name_width}} - {workflow.description}")
            logger.info("")

        logger.info("Run 'scribe workflows show <name>' for detailed information about a workflow.")
        logger.info("Use '--lang <code>' to switch languages (e.g., --lang zh-CN)")

    except Exception as e:
        logger.error(f"Failed to list workflows: {e}")
        if ctx.obj.get("debug", False):
            logger.exception("Full error trace:")
        sys.exit(1)


@workflows.command("show")
@click.argument("workflow_name")
@click.pass_context
def workflows_show(ctx: click.Context, workflow_name: str):
    """Show detailed information about a workflow."""
    logger = logging.getLogger("scribe")

    try:
        workflows_dir = Path("workflows")
        if not workflows_dir.exists():
            logger.error("Workflows directory not found")
            sys.exit(1)

        lang_str = ctx.obj.get("lang") if ctx.obj else None
        language = LanguageCode(lang_str) if lang_str else None
        project_dir = Path.cwd()

        current_language = get_current_language(
            explicit_language=language,
            project_dir=project_dir,
        )

        loader = WorkflowLoader(workflows_dir, language=current_language)
        workflow = loader.reload_workflow(workflow_name)

        if not workflow:
            logger.error(f"Workflow '{workflow_name}' not found [Language: {current_language}]")
            all_workflows = loader.load_all_workflows()
            available = [w.name for w in all_workflows]
            logger.info(f"Available workflows: {', '.join(available)}")
            sys.exit(1)

        logger.info(f"Workflow: {workflow.name} [Language: {current_language}]")
        logger.info("")
        logger.info(f"Version: {workflow.version}")
        logger.info("")
        logger.info("Description:")
        logger.info(f"  {workflow.description}")
        logger.info("")

        if workflow.variables:
            logger.info("Variables:")
            for key, value in workflow.variables.items():
                if value is None:
                    logger.info(f"  {key}: (required)")
                else:
                    logger.info(f"  {key}: {value}")
        else:
            logger.info("Variables: None")
        logger.info("")

        logger.info(f"Steps ({len(workflow.steps)}):")
        for step in workflow.steps:
            step_type = "Agent" if step.agent else ("Workflow" if step.workflow else "Action")
            logger.info(f"  {step.step}. {step.name} ({step_type})")
            if step.agent:
                logger.info(f"     Agent: {step.agent}")
            elif step.workflow:
                logger.info(f"     Workflow: {step.workflow}")
            elif step.action:
                logger.info(f"     Action: {step.action}")
        logger.info("")

        logger.info(f"Run 'scribe run workflow {workflow.name} --novel <name>' to execute.")

    except Exception as e:
        logger.error(f"Failed to show workflow: {e}")
        if ctx.obj.get("debug", False):
            logger.exception("Full error trace:")
        sys.exit(1)
