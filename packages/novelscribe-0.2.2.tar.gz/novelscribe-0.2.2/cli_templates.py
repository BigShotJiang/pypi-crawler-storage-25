"""CLI commands for template management."""

import json
import logging

import click

logger = logging.getLogger("scribe")


@click.group()
def templates():
    """Manage and browse story templates."""
    pass


@templates.command()
@click.option("--category", "-c", help="Filter by category (plot, character, scene, world)")
def list(category):
    """List available templates."""
    try:
        from core.template_loader import get_template_loader

        loader = get_template_loader("en")

        categories = ["plot", "character", "scene", "world"] if not category else [category]

        click.echo("\n📚 Available Templates")
        click.echo("=" * 60)

        for cat in categories:
            templates_list = loader.list_templates(cat)
            if templates_list:
                click.echo(f"\n🎯 {cat.upper()}")
                for tmpl in sorted(templates_list):
                    click.echo(f"  • {tmpl}")

        click.echo("")

    except Exception as e:
        logger.error(f"Failed to list templates: {e}")
        click.echo(f"❌ Error: {e}", err=True)


@templates.command()
@click.argument("template_name")
@click.option("--category", "-c", default="plot", help="Template category")
@click.option(
    "--format", "-f", "fmt", type=click.Choice(["markdown", "json", "yaml"]), default="markdown"
)
def show(template_name, category, fmt):
    """Show template details."""
    try:
        import yaml

        from core.template_loader import get_template_loader

        loader = get_template_loader("en")

        # Load template based on category
        if category == "plot":
            data = loader.load_plot_template(template_name)
        elif category == "character":
            data = loader.load_character_template(template_name)
        elif category == "scene":
            data = loader.load_scene_template(template_name)
        else:
            click.echo(f"❌ Unknown category: {category}", err=True)
            return

        if not data:
            click.echo(f"❌ Template not found: {template_name}", err=True)
            return

        if fmt == "json":
            click.echo(json.dumps(data, indent=2, default=str))
        elif fmt == "yaml":
            click.echo(yaml.dump(data, default_flow_style=False))
        else:  # markdown
            _print_template_markdown(template_name, data, category)

    except Exception as e:
        logger.error(f"Failed to show template: {e}")
        click.echo(f"❌ Error: {e}", err=True)


def _print_template_markdown(name, data, category):
    """Print template in markdown format."""

    if category == "plot":
        # Get first template
        template_data = list(data.values())[0] if data else {}
        beats = template_data.get("beats", [])

        click.echo(f"\n# {template_data.get('name', name)}\n")
        click.echo(f"{template_data.get('description', '')}\n")
        click.echo("## Plot Beats\n")

        for beat in beats:
            click.echo(f"### {beat.get('name', 'Unknown')}")
            click.echo(f"Position: {beat.get('percentage', 0)}%\n")
            click.echo(f"{beat.get('description', '')}\n")

            questions = beat.get("questions", [])
            if questions:
                click.echo("**Key Questions:**\n")
                for q in questions:
                    click.echo(f"- {q}")
                click.echo()

    elif category == "character":
        char_types = data.get("character_types", {})
        arc_types = data.get("arc_types", {})

        click.echo("\n# Character Templates\n")

        if char_types:
            click.echo("## Character Types\n")
            for key, char in char_types.items():
                click.echo(f"\n### {char.get('name', key)}")
                click.echo(f"{char.get('description', '')}\n")

                elements = char.get("elements", [])
                if elements:
                    for elem in elements:
                        click.echo(f"**{elem.get('name', '')}**: {elem.get('description', '')}")

        if arc_types:
            click.echo("\n## Character Arc Types\n")
            for key, arc in arc_types.items():
                click.echo(f"\n### {arc.get('name', key)}")
                click.echo(f"{arc.get('description', '')}\n")

                stages = arc.get("stages", [])
                if stages:
                    for i, stage in enumerate(stages, 1):
                        click.echo(f"{i}. {stage}")

    elif category == "scene":
        scene_types = data.get("scene_types", {})

        click.echo("\n# Scene Templates\n")

        for key, scene in scene_types.items():
            click.echo(f"\n## {scene.get('name', key)}")
            click.echo(f"{scene.get('description', '')}\n")

            structure = scene.get("structure", [])
            if structure:
                click.echo("**Structure:**\n")
                for elem in structure:
                    click.echo(f"- **{elem.get('name', '')}**: {elem.get('description', '')}")

    click.echo()


@templates.command()
@click.option("--category", "-c", help="Filter by category")
@click.option("--language", "-l", default="en", help="Language (en, zh-CN, zh-TW)")
def search(category, language):
    """Search templates by keyword."""
    try:
        from core.template_loader import get_template_loader

        loader = get_template_loader(language)

        if category:
            templates_list = loader.list_templates(category)
            click.echo(f"\n🔍 Templates in '{category}':\n")
            for tmpl in sorted(templates_list):
                click.echo(f"  • {tmpl}")
        else:
            # Search all categories
            click.echo("\n🔍 Available Templates by Category:\n")

            for cat in ["plot", "character", "scene", "world"]:
                templates_list = loader.list_templates(cat)
                if templates_list:
                    click.echo(f"\n🎯 {cat.upper()}")
                    for tmpl in sorted(templates_list):
                        click.echo(f"  • {tmpl}")

        click.echo("")

    except Exception as e:
        logger.error(f"Failed to search templates: {e}")
        click.echo(f"❌ Error: {e}", err=True)


@templates.command()
@click.option("--output", "-o", help="Output file")
@click.option("--format", "-f", "fmt", type=click.Choice(["json", "yaml"]), default="json")
def export(output, fmt):
    """Export all templates."""
    try:
        import yaml

        from core.template_loader import get_template_loader

        loader = get_template_loader("en")

        all_templates = {}

        for category in ["plot", "character", "scene", "world"]:
            templates_list = loader.list_templates(category)
            category_data = {}

            for tmpl_name in templates_list:
                if category == "plot":
                    data = loader.load_plot_template(tmpl_name)
                elif category == "character":
                    data = loader.load_character_template(tmpl_name)
                elif category == "scene":
                    data = loader.load_scene_template(tmpl_name)
                else:
                    data = {}

                if data:
                    category_data[tmpl_name] = data

            if category_data:
                all_templates[category] = category_data

        if fmt == "yaml":
            output_str = yaml.dump(all_templates, default_flow_style=False)
        else:
            output_str = json.dumps(all_templates, indent=2, default=str)

        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write(output_str)
            click.echo(f"✅ Exported templates to {output}")
        else:
            click.echo(output_str)

    except Exception as e:
        logger.error(f"Failed to export templates: {e}")
        click.echo(f"❌ Error: {e}", err=True)


@templates.command()
def languages():
    """Show supported languages."""
    click.echo("\n🌐 Supported Languages")
    click.echo("=" * 40)
    click.echo("  • en       - English")
    click.echo("  • zh-CN    - 简体中文")
    click.echo("  • zh-TW    - 繁體中文")
    click.echo("")


@templates.command()
@click.argument("template_name")
@click.option("--position", "-p", type=int, help="Position percentage (0-100)")
def format(template_name, position):
    """Format template for use in prompts."""
    try:
        from core.template_loader import get_template_loader

        loader = get_template_loader("en")

        # Format for prompt
        formatted = loader.format_template_for_prompt(template_name)

        if not formatted:
            click.echo(f"❌ Template not found: {template_name}", err=True)
            return

        # If position provided, show beat at that position
        if position is not None:
            beat = loader.get_plot_beat_for_position(template_name, position)
            if beat:
                click.echo(f"\n📍 Position: {position}%")
                click.echo(f"\n# {beat.get('name', 'Unknown')}\n")
                click.echo(f"{beat.get('description', '')}\n")

                questions = beat.get("questions", [])
                if questions:
                    click.echo("**Questions to Consider:**\n")
                    for q in questions:
                        click.echo(f"- {q}")
            else:
                click.echo(f"❌ Could not find beat at position {position}%")
        else:
            click.echo(formatted)

    except Exception as e:
        logger.error(f"Failed to format template: {e}")
        click.echo(f"❌ Error: {e}", err=True)


@templates.command()
def info():
    """Show template system information."""
    click.echo("\n📚 Template System Info")
    click.echo("=" * 50)
    click.echo()
    click.echo("Template Directory: templates/")
    click.echo()
    click.echo("Categories:")
    click.echo("  • plot     - Story structures (Hero's Journey, etc.)")
    click.echo("  • character - Character archetypes and arcs")
    click.echo("  • scene    - Scene types and structures")
    click.echo("  • world    - World-building templates")
    click.echo()
    click.echo("Supported Languages:")
    click.echo("  • en    - English (base)")
    click.echo("  • zh-CN - Simplified Chinese")
    click.echo("  • zh-TW - Traditional Chinese")
    click.echo()
    click.echo("Commands:")
    click.echo("  templates list                 - List all templates")
    click.echo("  templates show <name>          - Show template details")
    click.echo("  templates search               - Search templates")
    click.echo("  templates format <name>         - Format for prompts")
    click.echo("  templates export               - Export all templates")
    click.echo("  templates languages           - Show supported languages")
    click.echo("  templates info                - Show this info")
    click.echo()
