# NovelScribe

[![CI](https://github.com/huangjien/wst/actions/workflows/ci.yml/badge.svg)](https://github.com/huangjien/wst/actions/workflows/ci.yml)
[![PyPI version](https://badge.fury.io/py/novelscribe.svg)](https://pypi.org/project/novelscribe/)
[![Python versions](https://img.shields.io/badge/python-3.10%20%7C%203.11%20%7C%203.12%20%7C%203.13-blue.svg)](https://pypi.org/project/novelscribe/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

An AI-powered autonomous novel generation agent. Give it a concept, pick a genre, and it writes a full novel — outline, characters, world-building, chapters, and all.

> **Language / 语言 / 語言:** [English](README.md) | [简体中文](docs/getting-started/README.zh-CN.md) | [繁體中文](docs/getting-started/README.zh-TW.md)

---

## Install

```bash
pip install novelscribe
```

That's it. The `scribe` command is now available.

```bash
pipx install novelscribe   # recommended (isolated env)
```

Or the one-liner:

```bash
curl -sSL https://raw.githubusercontent.com/huangjien/wst/main/novel_harness/install.sh | bash
```

## 30-Second Demo

```bash
# Create a new novel project
scribe new my-novel

# Run fully autonomous generation (outline → characters → world → chapters)
scribe autonomous start my-novel

# Check progress
scribe --help
```

## What It Does

NovelScribe chains 9 specialized AI agents into an autonomous pipeline:

```
discuss → genre → characters → world-building → outline → chapter-planning → writing → continuity → editing
```

Each agent is a Markdown file with a system prompt and model config. The orchestrator runs them step-by-step through YAML-defined workflows, with verification loops that auto-fix issues until quality passes.

### Key Features

- **Autonomous generation** — one command produces a complete novel
- **9 specialized agents** — writer, editor, character designer, world-builder, continuity checker, etc.
- **Verification loops** — auto-detects and fixes plot holes, inconsistencies, and quality issues
- **Quality gates** — Bronze / Silver / Gold / Platinum tiers with metrics and benchmarks
- **Parallel execution** — runs independent agents concurrently for 2-4x speedup
- **Scales to 3M words** — hierarchical summaries, memory optimization, chapter pagination
- **Multi-language** — English, 简体中文, 繁體中文 (with fallback)
- **5 LLM providers** — OpenAI, Claude, Gemini, Ollama, LM Studio

## Usage

### Create a Novel

```bash
scribe new my-novel --provider openai --model gpt-4
```

### Run Autonomous Generation

```bash
scribe autonomous start my-novel
```

### Run Individual Phases

```bash
# Generate the outline
scribe run workflow outline --project my-novel

# Run a single agent
scribe run agent writer_agent --project my-novel

# Preview without executing
scribe run workflow writing --project my-novel --dry-run
```

### Explore Agents & Workflows

```bash
scribe agents list
scribe agents show writer_agent

scribe workflows list
scribe workflows show outline
```

### Templates

```bash
scribe templates list
scribe templates show heros_journey --category plot
scribe template-create plot -n "My Structure" -d "Description" -b "0:Hook:Description"
```

### Version & Updates

```bash
scribe version info              # current version
scribe version check             # check PyPI for updates
scribe version update            # self-update to latest
scribe version update --yes      # skip confirmation
```

NovelScribe checks for updates on startup (once per 24h) and shows a notification when a new version is available.

## Multi-Language Support

| Language | Code |
|----------|------|
| English | `en` |
| Simplified Chinese | `zh-CN` |
| Traditional Chinese | `zh-TW` |

Set per-project in `META.yaml`:

```yaml
project_name: my_novel
language: zh-CN
genre: fantasy
target_word_count: 80000
```

Or per-command:

```bash
scribe --lang zh-TW agents list
```

Language resolution priority: `--lang` flag > `META.yaml` > user config > `SCRIBE_LANGUAGE` env > system locale > English fallback.

## Configuration

Set your LLM provider:

```bash
# Interactive setup
scribe config setup

# Or set directly
export OPENAI_API_KEY=sk-...
export ANTHROPIC_API_KEY=sk-ant-...
```

Supported providers:

| Provider | Env Var | Notes |
|----------|---------|-------|
| OpenAI | `OPENAI_API_KEY` | Best quality |
| Anthropic | `ANTHROPIC_API_KEY` | Long context |
| Google Gemini | `GOOGLE_API_KEY` | Free tier available |
| Ollama | — | Local, no API key needed |
| LM Studio | — | Local, no API key needed |

## Architecture

```
novel_harness/
├── cli.py                 # Entry point (registered as 'scribe')
├── cli_*.py               # Command modules
├── core/                  # Core engine
│   ├── orchestrator.py    # Central coordinator
│   ├── llm_client.py      # Multi-provider LLM abstraction
│   ├── storage.py         # File-based storage
│   ├── version.py         # Update checker & self-updater
│   └── ...
├── agents/                # Agent definitions (Markdown)
├── workflows/             # Workflow definitions (YAML)
├── api/                   # FastAPI server (optional)
└── tests/                 # Test suite
```

## LLM Providers

NovelScribe supports any OpenAI-compatible API. Configure via environment variables or `scribe config setup`:

```bash
# .env file
OPENAI_API_KEY=sk-...
LLM_PROVIDER=openai
LLM_MODEL=gpt-4-turbo-preview
```

## API Server (Optional)

For web UI integration or programmatic access:

```bash
pip install "novelscribe[api]"
uvicorn api.app:app --host 0.0.0.0 --port 8000
```

## Development

```bash
git clone https://github.com/huangjien/wst.git
cd novelscribe/novel_harness
uv sync --all-extras

# Run quality checks
make check

# Individual
make format      # ruff format
make lint        # ruff check --fix
make type-check  # mypy
make test        # pytest with coverage
make build       # uv build → dist/
```

## License

[MIT](LICENSE)
