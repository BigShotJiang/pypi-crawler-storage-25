"""Setup commands for first-time configuration."""

import importlib.util
import logging
import sys

import click

from core.language_config import LanguageCode, LanguageResolver


@click.group()
def setup():
    """First-time setup and configuration commands."""
    pass


@setup.command()
@click.pass_context
def interactive(ctx: click.Context):
    """Run interactive setup wizard."""
    logger = logging.getLogger("scribe")

    try:
        from setup_wizard import SetupWizard

        wizard = SetupWizard()
        wizard.run()
    except ImportError:
        logger.error("Setup wizard not available. Please install inquirer3:")
        logger.error("  uv add inquirer3")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Setup failed: {e}")
        if ctx.obj.get("debug", False):
            logger.exception("Full error trace:")
        sys.exit(1)


@setup.command()
@click.argument("provider", type=click.Choice(["openai", "anthropic", "google"]))
@click.argument("api_key")
@click.pass_context
def apikey(ctx: click.Context, provider: str, api_key: str):
    """Configure LLM provider API key.

    Examples:
        scribe setup apikey openai sk-...
        scribe setup apikey anthropic sk-ant-...
        scribe setup apikey google YOUR_GOOGLE_API_KEY
    """
    import os

    logger = logging.getLogger("scribe")

    # Validate API key format
    env_var_map = {
        "openai": "OPENAI_API_KEY",
        "anthropic": "ANTHROPIC_API_KEY",
        "google": "GOOGLE_API_KEY",
    }

    if provider == "openai" and not api_key.startswith("sk-"):
        logger.error("Invalid OpenAI API key format. Must start with 'sk-'")
        sys.exit(1)
    elif provider == "anthropic" and not api_key.startswith("sk-ant-"):
        logger.error("Invalid Anthropic API key format. Must start with 'sk-ant-'")
        sys.exit(1)
    elif provider == "google" and len(api_key) != 32:
        logger.error("Invalid Google API key format. Must be 32 characters")
        sys.exit(1)

    try:
        from pathlib import Path

        install_dir = Path(__file__).parent
        env_file = install_dir / ".env"

        # Write only the new key (secure, atomic)
        env_var = env_var_map[provider]
        env_content = f"{env_var}={api_key}\n"

        # Write to file
        env_file.parent.mkdir(parents=True, exist_ok=True)
        env_file.write_text(env_content)

        # Set secure permissions (owner read/write only)
        os.chmod(env_file, 0o600)

        logger.info(f"✅ {provider.upper()} API key configured")
        logger.info(f"   Saved to: {env_file}")

    except PermissionError:
        logger.error(f"Permission denied writing to: {env_file}")
        logger.info("Try running with appropriate permissions")
        sys.exit(1)
    except OSError as e:
        logger.error(f"Failed to write API key: {e}")
        if ctx.obj.get("debug", False):
            logger.exception("Full error trace:")
        sys.exit(1)


@setup.command()
@click.argument("language", type=click.Choice(["en", "zh-CN", "zh-TW"]))
@click.pass_context
def language(ctx: click.Context, language: str):
    """Configure default language.

    Examples:
        scribe setup language en
        scribe setup language zh-CN
        scribe setup language zh-TW
    """
    logger = logging.getLogger("scribe")

    try:
        resolver = LanguageResolver()
        config = resolver.get_config()
        config.default_language = LanguageCode(language)
        resolver.save_config(config)

        logger.info(f"✅ Default language set to: {language}")
        logger.info(f"   Config saved to: {resolver.config_path}")
        logger.info("")
        logger.info("This language will be used for all new projects.")
        logger.info("Use '--lang <code>' to override for individual commands.")

    except Exception as e:
        logger.error(f"Failed to set language: {e}")
        if ctx.obj.get("debug", False):
            logger.exception("Full error trace:")
        sys.exit(1)


@setup.command()
@click.pass_context
def install_skill(ctx: click.Context):
    """Install chatbot skill for IDE integration."""
    logger = logging.getLogger("scribe")

    try:
        import shutil
        from pathlib import Path

        install_dir = Path(__file__).parent
        skill_file = install_dir / "novel_harness_skill.skill"
        trae_skills_dir = Path.home() / ".trae" / "skills"

        if not skill_file.exists():
            logger.error(f"Skill file not found: {skill_file}")
            logger.info(
                "Make sure you're running this from the Novel Harness installation directory."
            )
            sys.exit(1)

        if not trae_skills_dir.exists():
            logger.error(f"Trae skills directory not found: {trae_skills_dir}")
            logger.info("Make sure Trae is installed.")
            logger.info("You can manually copy the skill file:")
            logger.info(f"  cp {skill_file} ~/.trae/skills/")
            sys.exit(1)

        # Copy skill file
        shutil.copy(skill_file, trae_skills_dir / "novel-harness.skill")

        logger.info("✅ Chatbot skill installed successfully")
        logger.info(f"   Skill file copied to: {trae_skills_dir}")
        logger.info("")
        logger.info("You can now use Novel Harness from VS Code Copilot/Trae:")
        logger.info('  "Create a science fiction novel called Mars Colony"')
        logger.info('  "Start autonomous generation"')
        logger.info('  "Check the status"')

    except Exception as e:
        logger.error(f"Failed to install skill: {e}")
        if ctx.obj.get("debug", False):
            logger.exception("Full error trace:")
        sys.exit(1)


@setup.command()
@click.pass_context
def verify(ctx: click.Context):
    """Verify installation and configuration."""
    logger = logging.getLogger("scribe")

    logger.info("Verifying Novel Harness installation...")
    logger.info("")

    issues = []

    # Check Python version
    import sys

    if sys.version_info < (3, 10):
        issues.append("❌ Python 3.10+ required, found " + sys.version)
    else:
        py_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        logger.info(f"✅ Python version: {py_version}")

    # Check CLI
    logger.info("✅ CLI command: scribe")

    # Check dependencies
    try:
        importlib.util.find_spec("click")
        importlib.util.find_spec("yaml")

        logger.info("✅ Core dependencies installed")
    except ImportError as e:
        issues.append(f"❌ Missing dependency: {e}")

    # Check API key
    from pathlib import Path

    from dotenv import load_dotenv

    install_dir = Path(__file__).parent
    env_file = install_dir / ".env"

    if env_file.exists():
        load_dotenv(env_file)
        import os

        if os.getenv("OPENAI_API_KEY"):
            logger.info("✅ OpenAI API key configured")
        elif os.getenv("ANTHROPIC_API_KEY"):
            logger.info("✅ Anthropic API key configured")
        elif os.getenv("GOOGLE_API_KEY"):
            logger.info("✅ Google API key configured")
        else:
            issues.append("⚠️  No API key found. Run: scribe setup apikey <provider> <key>")
    else:
        issues.append("⚠️  .env file not found. Run: scribe setup apikey <provider> <key>")

    # Check config directory
    config_dir = Path.home() / ".scribe"
    if config_dir.exists():
        logger.info("✅ Configuration directory exists")
    else:
        issues.append("⚠️  Configuration directory not found. Will be created on first use.")

    # Check skill installation
    skill_file = install_dir / "novel_harness_skill.skill"
    if skill_file.exists():
        logger.info("✅ Chatbot skill file present")
    else:
        issues.append("⚠️  Chatbot skill file not found")

    logger.info("")

    if issues:
        logger.warning("Found issues that need attention:")
        for issue in issues:
            logger.warning(issue)
        logger.info("")
        logger.info("Run 'scribe setup interactive' to fix most issues.")
    else:
        logger.info("🎉 Everything looks good! You're ready to write novels.")
