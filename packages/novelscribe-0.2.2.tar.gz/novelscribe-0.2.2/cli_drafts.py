"""Draft management CLI commands."""

import logging
import sys
from pathlib import Path
from typing import Optional

import click

from core.chapter_regenerator import ChapterRegenerator, RegenerationConfig, RegenerationStrategy
from core.draft_manager import DraftManager
from core.rollback_manager import RollbackManager
from core.version_comparator import VersionComparator


@click.group()
def drafts() -> None:
    """Draft version management and regeneration commands."""
    pass


@drafts.command("regenerate")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, required=True, help="Chapter number to regenerate")
@click.option(
    "--strategy",
    type=click.Choice(["full", "targeted", "continuity", "style"]),
    default="full",
    help="Regeneration strategy",
)
@click.option("--preserve-dialogue", is_flag=True, default=True, help="Preserve dialogue")
@click.option("--preserve-action", is_flag=True, default=True, help="Preserve action scenes")
@click.option("--fix-issues", multiple=True, help="List of issues to fix")
@click.option("--style-target", help="Style adjustment target")
@click.option("--max-words", type=int, help="Maximum word count")
@click.option("--reason", default="regeneration", help="Reason for regeneration")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.pass_context
def regenerate_chapter(
    ctx: click.Context,
    project_name: str,
    chapter: int,
    strategy: str,
    preserve_dialogue: bool,
    preserve_action: bool,
    fix_issues: tuple,
    style_target: Optional[str],
    max_words: Optional[int],
    reason: str,
    project_dir: str,
) -> None:
    """Regenerate a chapter with specified strategy."""
    logger = logging.getLogger("scribe")

    try:
        project_path = Path(project_dir) / project_name
        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        config = RegenerationConfig(
            strategy=RegenerationStrategy(strategy),
            preserve_dialogue=preserve_dialogue,
            preserve_action_scenes=preserve_action,
            fix_issues=list(fix_issues),
            style_target=style_target,
            max_word_count=max_words,
        )

        regenerator = ChapterRegenerator(str(project_path))
        result = regenerator.regenerate(chapter, config, reason)

        if result.success:
            logger.info(f"✅ Chapter {chapter} regenerated successfully")
            logger.info(f"   New version: {result.new_version}")
            logger.info(f"   Words changed: {result.words_changed:+d}")
            logger.info(f"   Similarity: {result.content_similarity:.2%}")
            logger.info(f"   Quality score: {result.quality_score:.2f}")
            if result.issues_resolved:
                logger.info(f"   Issues fixed: {', '.join(result.issues_resolved)}")
        else:
            logger.error("❌ Regeneration failed")
            if result.new_issues:
                for issue in result.new_issues:
                    logger.error(f"   - {issue}")
            sys.exit(1)

    except Exception as e:
        logger.error(f"Regeneration error: {e}")
        sys.exit(1)


@drafts.command("list")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, help="Filter by chapter number")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.pass_context
def list_drafts(
    ctx: click.Context, project_name: str, chapter: Optional[int], project_dir: str
) -> None:
    """List draft versions."""
    logger = logging.getLogger("scribe")

    try:
        project_path = Path(project_dir) / project_name
        manager = DraftManager(str(project_path))

        if chapter:
            versions = manager.list_versions(chapter)

            if not versions:
                logger.info(f"No versions found for chapter {chapter}")
                return

            logger.info(f"Draft versions for Chapter {chapter}:")
            logger.info("")

            for v in versions:
                status_symbol = "✓" if v.status == "active" else "a"
                logger.info(
                    f"  v{v.version:03d} [{status_symbol}] {v.regeneration_reason or 'draft'}"
                )
                logger.info(f"    Words: {v.word_count} | Quality: {v.quality_score or 'N/A'}")
                logger.info(f"    Created: {v.timestamp.strftime('%Y-%m-%d %H:%M')}")
                if v.parent_version:
                    logger.info(f"    Parent: v{v.parent_version:03d}")
                logger.info("")
        else:
            summary = manager.get_project_summary()

            logger.info(f"Draft summary for '{project_name}':")
            logger.info(f"  Total chapters: {summary['total_chapters']}")
            logger.info(f"  Total drafts: {summary['total_drafts']}")
            logger.info(f"  Total words: {summary['total_words']}")
            logger.info("")

    except Exception as e:
        logger.error(f"Failed to list drafts: {e}")
        sys.exit(1)


@drafts.command("show")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, required=True, help="Chapter number")
@click.option("--version", "-v", type=int, help="Version number (default: current)")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.pass_context
def show_draft(
    ctx: click.Context, project_name: str, chapter: int, version: Optional[int], project_dir: str
) -> None:
    """Show draft details."""
    logger = logging.getLogger("scribe")

    try:
        project_path = Path(project_dir) / project_name
        manager = DraftManager(str(project_path))

        if version:
            metadata = manager.get_version(chapter, version)
        else:
            metadata = manager.get_current_version(chapter)

        if not metadata:
            logger.error("Draft not found")
            sys.exit(1)

        content = manager.get_version_content(chapter, metadata.version)

        logger.info(f"Draft: Chapter {chapter}, Version {metadata.version}")
        logger.info("=" * 60)
        logger.info(f"Status: {metadata.status.value}")
        logger.info(f"Reason: {metadata.regeneration_reason or 'N/A'}")
        logger.info(f"Word count: {metadata.word_count}")
        logger.info(f"Quality score: {metadata.quality_score or 'N/A'}")
        logger.info(f"Created: {metadata.timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info("")
        logger.info("Content preview:")
        logger.info(content[:500] + "..." if len(content) > 500 else content)

    except Exception as e:
        logger.error(f"Failed to show draft: {e}")
        sys.exit(1)


@drafts.command("compare")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, required=True, help="Chapter number")
@click.option("--from", "from_version", type=int, required=True, help="From version")
@click.option("--to", "to_version", type=int, required=True, help="To version")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.pass_context
def compare_versions(
    ctx: click.Context,
    project_name: str,
    chapter: int,
    from_version: int,
    to_version: int,
    project_dir: str,
) -> None:
    """Compare two draft versions."""
    logger = logging.getLogger("scribe")

    try:
        project_path = Path(project_dir) / project_name
        comparator = VersionComparator(str(project_path))

        report = comparator.generate_diff_report(chapter, from_version, to_version)

        logger.info(f"Version comparison for Chapter {chapter}")
        logger.info("=" * 60)
        logger.info(report.summary)
        logger.info("")

        if report.recommendations:
            logger.info("Recommendations:")
            for rec in report.recommendations:
                logger.info(f"  - {rec}")
            logger.info("")

        logger.info(f"Quality impact: {report.quality_impact}")

    except Exception as e:
        logger.error(f"Comparison failed: {e}")
        sys.exit(1)


@drafts.command("rollback")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, required=True, help="Chapter number")
@click.option("--to-version", type=int, required=True, help="Target version")
@click.option("--create-backup", is_flag=True, default=True, help="Create backup before rollback")
@click.option("--force", is_flag=True, help="Force rollback despite warnings")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.pass_context
def rollback_version(
    ctx: click.Context,
    project_name: str,
    chapter: int,
    to_version: int,
    create_backup: bool,
    force: bool,
    project_dir: str,
) -> None:
    """Rollback to a previous version."""
    logger = logging.getLogger("scribe")

    try:
        project_path = Path(project_dir) / project_name
        manager = RollbackManager(str(project_path))

        validation = manager.validate_rollback(chapter, to_version)

        if not validation.can_rollback and not force:
            logger.error("Cannot rollback:")
            for reason in validation.reasons:
                logger.error(f"  - {reason}")
            sys.exit(1)

        if validation.warnings:
            logger.warning("Warnings:")
            for warning in validation.warnings:
                logger.warning(f"  - {warning}")
            logger.warning("")

        if validation.dependency_issues:
            logger.warning("Dependency issues:")
            for issue in validation.dependency_issues:
                logger.warning(f"  - {issue}")
            logger.warning("")

        if not force and validation.dependency_issues:
            logger.error("Dependency issues detected. Use --force to override.")
            sys.exit(1)

        result = manager.rollback(chapter, to_version, create_backup, force)

        if result.success:
            logger.info("✅ Rollback successful")
            logger.info(f"   Chapter {chapter}: v{result.from_version} → v{result.to_version}")
            if result.backup_created:
                logger.info(f"   Backup created: {result.backup_path}")
        else:
            logger.error("❌ Rollback failed")
            if result.error_message:
                logger.error(f"   {result.error_message}")
            sys.exit(1)

    except Exception as e:
        logger.error(f"Rollback error: {e}")
        sys.exit(1)


@drafts.command("archive")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, help="Archive specific chapter")
@click.option("--keep-recent", type=int, default=5, help="Number of recent versions to keep")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.pass_context
def archive_drafts(
    ctx: click.Context,
    project_name: str,
    chapter: Optional[int],
    keep_recent: int,
    project_dir: str,
) -> None:
    """Archive old draft versions."""
    logger = logging.getLogger("scribe")

    try:
        project_path = Path(project_dir) / project_name
        manager = DraftManager(str(project_path))

        if chapter:
            archived = manager.archive_old_versions(chapter, keep_recent)
            logger.info(f"✅ Archived {archived} old versions for chapter {chapter}")
        else:
            summary = manager.get_project_summary()
            total_archived = 0

            for ch in summary.get("chapters", []):
                ch_num = ch["chapter_number"]
                archived = manager.archive_old_versions(ch_num, keep_recent)
                total_archived += archived

            logger.info(f"✅ Archived {total_archived} old versions across all chapters")

    except Exception as e:
        logger.error(f"Archive failed: {e}")
        sys.exit(1)
