"""Configuration management commands."""

import logging
import sys

import click

from core.language_config import LanguageCode, LanguageResolver


@click.group()
def config():
    """Configuration management commands."""
    pass


@config.command("set")
@click.argument("key", type=click.Choice(["language"]))
@click.argument("value")
@click.pass_context
def config_set(ctx: click.Context, key: str, value: str):
    """Set a configuration value.

    Examples:
        scribe config set language zh-CN
        scribe config set language zh-TW
        scribe config set language en
    """
    logger = logging.getLogger("scribe")

    try:
        if key == "language":
            try:
                language = LanguageCode(value)
            except ValueError:
                logger.error(f"Invalid language code: {value}")
                logger.info("Valid languages: en, zh-CN, zh-TW")
                sys.exit(1)

            resolver = LanguageResolver()
            config = resolver.get_config()
            config.default_language = language
            resolver.save_config(config)

            logger.info(f"✅ Default language set to: {language.value}")
            logger.info(f"   Config saved to: {resolver.config_path}")
            logger.info("")
            logger.info("This language will be used for all new projects.")
            logger.info("Use '--lang <code>' to override for individual commands.")

    except Exception as e:
        logger.error(f"Failed to set configuration: {e}")
        if ctx.obj.get("debug", False):
            logger.exception("Full error trace:")
        sys.exit(1)


@config.command("get")
@click.argument("key", type=click.Choice(["language"]), required=False)
@click.pass_context
def config_get(ctx: click.Context, key: str | None):
    """Get configuration value(s).

    Examples:
        scribe config get language
        scribe config get
    """
    logger = logging.getLogger("scribe")

    try:
        resolver = LanguageResolver()
        config = resolver.get_config()

        if key:
            if key == "language":
                logger.info(f"Default language: {config.default_language.value}")
        else:
            logger.info("Current Configuration:")
            logger.info("")
            logger.info(f"  default_language: {config.default_language.value}")
            logger.info(f"  config_path: {resolver.config_path}")
            logger.info("")
            logger.info("Valid languages: en, zh-CN, zh-TW")
            logger.info("Use 'scribe config set language <code>' to change.")

    except Exception as e:
        logger.error(f"Failed to get configuration: {e}")
        if ctx.obj.get("debug", False):
            logger.exception("Full error trace:")
        sys.exit(1)
