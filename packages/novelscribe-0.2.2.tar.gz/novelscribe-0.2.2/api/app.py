"""
FastAPI application for Novel Generation System

This module provides a RESTful API for managing novel generation projects,
executing workflows, monitoring status, and accessing logs.

API runs on http://localhost:8000
Auto-generated docs at http://localhost:8000/docs
"""

import time
import uuid
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Any

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response

from api.models import ErrorResponse, HealthCheckResponse, SystemStatusResponse

# Import routers
from api.routers import logs, projects, streaming, suggestions, websocket, workflows
from api.routers import status as status_router

# Startup time for uptime calculation
startup_time = time.time()


@asynccontextmanager
async def lifespan(app: FastAPI) -> Any:
    """
    Lifespan context manager for startup and shutdown events

    This is the modern FastAPI replacement for on_event decorators.
    """
    # Startup
    print("🚀 Starting Novel Generation API...")
    print("📚 API Documentation: http://localhost:8000/docs")
    print("🔍 ReDoc Documentation: http://localhost:8000/redoc")

    yield

    # Shutdown
    print("🛑 Shutting down Novel Generation API...")


# Initialize FastAPI application
app = FastAPI(
    title="Novel Generation API",
    version="1.0.0",
    description="""
    RESTful API for autonomous novel generation and management.

    ## Features

    * **Project Management**: Create, read, update, and delete novel projects
    * **Workflow Execution**: Trigger and monitor autonomous generation workflows
    * **Status Monitoring**: Real-time project and execution status
    * **Log Access**: Retrieve execution logs with filtering and pagination
    * **Draft Management**: Access and manage chapter draft versions

    ## Quick Start

    1. Create a project: `POST /api/v1/projects`
    2. Run a workflow: `POST /api/v1/run_workflow`
    3. Check status: `GET /api/v1/status/{project_name}`
    4. View logs: `GET /api/v1/logs/{project_name}`
    """,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan,
)


# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:3001",
        "http://127.0.0.1:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Request ID middleware
@app.middleware("http")
async def add_request_id(request: Request, call_next: Any) -> Response:
    """Add unique request ID to each request for tracking"""
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    request.state.request_id = request_id

    response: Response = await call_next(request)
    response.headers["X-Request-ID"] = request_id
    return response


# Exception handlers
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    """Handle HTTP exceptions with standardized error response"""
    error_response = ErrorResponse(
        error=str(exc.status_code),
        message=exc.detail,
        path=str(request.url.path),
    )
    return JSONResponse(status_code=exc.status_code, content=error_response.model_dump(mode="json"))


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Handle general exceptions with standardized error response"""
    error_response = ErrorResponse(
        error="INTERNAL_SERVER_ERROR",
        message=str(exc),
        path=str(request.url.path),
    )
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=error_response.model_dump(mode="json"),
    )


# Include routers
app.include_router(projects.router, prefix="/api/v1/projects", tags=["Projects"])

app.include_router(workflows.router, prefix="/api/v1/workflows", tags=["Workflows"])

app.include_router(status_router.router, prefix="/api/v1/status", tags=["Status"])

app.include_router(logs.router, prefix="/api/v1/logs", tags=["Logs"])

app.include_router(streaming.router, prefix="/api/v1/stream", tags=["Streaming"])

app.include_router(websocket.router, tags=["WebSocket"])

app.include_router(suggestions.router, prefix="/api/v1", tags=["Suggestions"])


# Health check endpoint
@app.get(
    "/health",
    response_model=HealthCheckResponse,
    tags=["System"],
    summary="Health check",
    description="Check if the API is running and healthy",
)
async def health_check() -> HealthCheckResponse:
    """Basic health check endpoint"""
    return HealthCheckResponse(status="healthy", timestamp=datetime.now(), version="1.0.0")


# Root endpoint
@app.get(
    "/", tags=["System"], summary="API root", description="Welcome message and API information"
)
async def root() -> dict[str, Any]:
    """Root endpoint with API information"""
    return {
        "name": "Novel Generation API",
        "version": "1.0.0",
        "status": "running",
        "documentation": "/docs",
        "redoc": "/redoc",
        "openapi": "/openapi.json",
        "endpoints": {
            "projects": "/api/v1/projects",
            "workflows": "/api/v1/workflows",
            "status": "/api/v1/status",
            "logs": "/api/v1/logs",
        },
    }


# System status endpoint
@app.get(
    "/api/v1/status",
    response_model=SystemStatusResponse,
    tags=["System"],
    summary="System status",
    description="Get overall system status and statistics",
)
async def get_system_status() -> SystemStatusResponse:
    """Get system-wide status and statistics"""
    from core.storage import Storage

    try:
        storage = Storage()
        projects = storage.list_projects()
        projects_count = len(projects)
    except Exception:
        projects_count = 0

    uptime = time.time() - startup_time

    return SystemStatusResponse(
        status="healthy",
        version="1.0.0",
        projects_count=projects_count,
        active_executions=0,  # NOTE: Execution tracking will be implemented in M8
        uptime_seconds=uptime,
    )


if __name__ == "__main__":
    import uvicorn

    print("🚀 Starting Novel Generation API...")
    print("📚 Documentation: http://localhost:8000/docs")

    uvicorn.run("api.app:app", host="0.0.0.0", port=8000, reload=True, log_level="info")
