"""
Pydantic models for API requests and responses

This module defines all data models used by the Novel Generation API.
"""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field, field_serializer, field_validator


class SuggestionChoice(BaseModel):
    """Represents a suggestion option in API responses"""

    id: str
    name: str
    description: str
    best_for: List[str] = Field(default_factory=list)
    examples: List[str] = Field(default_factory=list)
    source: str
    acceptance_rate: Optional[float] = None


class ProactiveSuggestions(BaseModel):
    """Proactive suggestions included in API responses"""

    show_suggestions: bool
    trigger_type: Optional[str] = None
    formatted_suggestions: Optional[str] = None
    suggestions: List[SuggestionChoice] = Field(default_factory=list)
    presented_at: Optional[datetime] = None


class ProjectStatus(str, Enum):
    """Project status enum"""

    CREATED = "created"
    OUTLINING = "outlining"
    WRITING = "writing"
    REVIEW = "review"
    COMPLETED = "completed"
    ERROR = "error"


class ExecutionStatus(str, Enum):
    """Workflow execution status enum"""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class LogLevel(str, Enum):
    """Log level enum"""

    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class ProjectCreate(BaseModel):
    """Request model for creating a project"""

    name: str = Field(..., min_length=1, max_length=100, description="Project name")
    provider: Optional[str] = Field(None, description="LLM provider (e.g., 'openai', 'claude')")
    model: Optional[str] = Field(None, description="LLM model (e.g., 'gpt-4', 'claude-3-opus')")
    description: Optional[str] = Field(None, max_length=500, description="Project description")

    @field_validator("name")
    @classmethod
    def validate_name(cls, v):
        """Validate project name"""
        if not v or not v.strip():
            raise ValueError("Project name cannot be empty")
        if "/" in v or "\\" in v:
            raise ValueError("Project name cannot contain slashes")
        return v.strip()


class ProjectResponse(BaseModel):
    """Response model for project details"""

    name: str
    status: ProjectStatus
    created_at: datetime
    updated_at: Optional[datetime] = None
    location: str
    chapter_count: int = 0
    description: Optional[str] = None
    meta: Dict[str, Any] = Field(default_factory=dict)
    suggestions: Optional[ProactiveSuggestions] = None

    model_config = ConfigDict(ser_json_timedelta="iso8601")

    @field_serializer("created_at", "updated_at")
    def serialize_datetime(self, v: Optional[datetime]) -> Optional[str]:
        return v.isoformat() if v else None


class ProjectSummary(BaseModel):
    """Summary model for project listings"""

    name: str
    status: ProjectStatus
    created_at: datetime
    chapter_count: int = 0
    description: Optional[str] = None


class WorkflowRunRequest(BaseModel):
    """Request model for running a workflow"""

    project_name: str = Field(..., description="Target project name")
    workflow: str = Field(..., description="Workflow name to execute")
    variables: Dict[str, Any] = Field(default_factory=dict, description="Workflow variables")
    background: bool = Field(True, description="Run in background or wait for completion")

    @field_validator("workflow")
    @classmethod
    def validate_workflow(cls, v):
        """Validate workflow name"""
        valid_workflows = [
            "new_novel",
            "outline_phase",
            "character_phase",
            "worldbuilding_phase",
            "writing_phase",
            "review_phase",
            "autonomous",
            "write_chapter",
            "generate_outline",
        ]
        if v not in valid_workflows:
            raise ValueError(f"Invalid workflow. Must be one of: {', '.join(valid_workflows)}")
        return v


class WorkflowRunResponse(BaseModel):
    """Response model for workflow execution"""

    execution_id: str
    status: ExecutionStatus
    project: str
    workflow: str
    started_at: datetime
    message: str
    background: bool
    suggestions: Optional[ProactiveSuggestions] = None


class ExecutionStatusResponse(BaseModel):
    """Response model for execution status"""

    execution_id: str
    status: ExecutionStatus
    project: str
    workflow: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    progress: float = Field(0.0, ge=0.0, le=100.0, description="Progress percentage")
    current_step: Optional[str] = None
    error: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    suggestions: Optional[ProactiveSuggestions] = None


class RecordSuggestionChoiceRequest(BaseModel):
    """Request model for recording user's suggestion choice"""

    project_name: str = Field(..., description="Project name")
    suggestion_id: str = Field(..., description="ID of the suggestion")
    accepted: bool = Field(..., description="Whether user accepted the suggestion")
    user_choice: str = Field(..., description="What the user chose")
    trigger_type: str = Field(..., description="Type of trigger")
    category: str = Field(..., description="Suggestion category")


class RecordSuggestionChoiceResponse(BaseModel):
    """Response model for recording suggestion choice"""

    success: bool
    message: str
    suggestion_id: str


class SystemStatusResponse(BaseModel):
    """Response model for system status"""

    status: str = Field(..., description="System health status")
    version: str = Field(..., description="API version")
    projects_count: int = Field(..., description="Total number of projects")
    active_executions: int = Field(..., description="Number of active workflow executions")
    uptime_seconds: float = Field(..., description="Server uptime in seconds")


class ProjectStatusResponse(BaseModel):
    """Response model for project status"""

    name: str
    status: ProjectStatus
    created_at: datetime
    updated_at: Optional[datetime] = None
    chapter_count: int
    last_activity: Optional[datetime] = None
    current_phase: Optional[str] = None


class DraftInfo(BaseModel):
    """Draft version information"""

    number: int = Field(..., description="Chapter number")
    versions: int = Field(..., description="Number of versions")
    current_version: int = Field(..., description="Current version number")
    updated_at: Optional[datetime] = None


class DraftStatusResponse(BaseModel):
    """Response model for draft status"""

    project: str
    chapters: List[DraftInfo]
    total_chapters: int
    total_versions: int


class LogEntry(BaseModel):
    """Log entry model"""

    timestamp: datetime
    level: LogLevel
    message: str
    source: Optional[str] = None
    execution_id: Optional[str] = None
    chapter: Optional[int] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class LogsResponse(BaseModel):
    """Response model for logs query"""

    project: str
    logs: List[LogEntry]
    total: int
    offset: int
    limit: int
    has_more: bool


class ErrorResponse(BaseModel):
    """Standard error response model"""

    error: str = Field(..., description="Error type")
    message: str = Field(..., description="Error message")
    details: Optional[Dict[str, Any]] = None
    path: Optional[str] = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now())


class WorkflowInfo(BaseModel):
    """Workflow information model"""

    name: str
    description: str
    category: str
    steps: List[str] = Field(default_factory=list)
    required_vars: List[str] = Field(default_factory=list)


class AvailableWorkflowsResponse(BaseModel):
    """Response model for available workflows"""

    workflows: List[WorkflowInfo]


class CancelExecutionResponse(BaseModel):
    """Response model for cancellation"""

    success: bool
    message: str
    execution_id: str


class DeleteProjectResponse(BaseModel):
    """Response model for project deletion"""

    success: bool
    message: str
    project: str


class HealthCheckResponse(BaseModel):
    """Health check response"""

    status: str = "healthy"
    timestamp: datetime = Field(default_factory=lambda: datetime.now())
    version: str = "1.0.0"
