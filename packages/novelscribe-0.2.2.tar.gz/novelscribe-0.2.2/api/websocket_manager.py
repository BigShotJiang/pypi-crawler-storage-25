"""
WebSocket Connection Manager for Real-time Updates

This module manages WebSocket connections for live updates, including:
- Connection pooling per project
- Message broadcasting
- Connection lifecycle management
- Heartbeat/ping-pong
- Client identification
"""

import asyncio
import threading
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set
from uuid import uuid4

from fastapi import WebSocket


class EventType(str, Enum):
    """Event types for real-time updates"""

    LOG = "log"
    PROGRESS = "progress"
    STATUS_CHANGE = "status_change"
    EXECUTION_START = "execution_start"
    EXECUTION_COMPLETE = "execution_complete"
    EXECUTION_ERROR = "execution_error"
    CHAPTER_COMPLETE = "chapter_complete"
    HEARTBEAT = "heartbeat"
    SYSTEM_STATUS = "system_status"


@dataclass
class WSConnection:
    """Represents a WebSocket connection"""

    client_id: str
    websocket: WebSocket
    project_name: Optional[str] = None
    connected_at: datetime = field(default_factory=datetime.now)
    last_ping: datetime = field(default_factory=datetime.now)
    subscribed_events: Set[EventType] = field(default_factory=lambda: set(EventType))
    metadata: Dict[str, Any] = field(default_factory=dict)

    async def send_json(self, data: Dict[str, Any]) -> None:
        """Send JSON data to client"""
        try:
            await self.websocket.send_json(data)
        except Exception:
            raise

    async def send_text(self, text: str) -> None:
        """Send text data to client"""
        try:
            await self.websocket.send_text(text)
        except Exception:
            raise

    def update_ping(self) -> None:
        """Update last ping time"""
        self.last_ping = datetime.now()


@dataclass
class RealtimeEvent:
    """Real-time event structure"""

    type: EventType
    timestamp: datetime = field(default_factory=datetime.now)
    data: Dict[str, Any] = field(default_factory=dict)
    priority: str = "normal"
    source: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        return {
            "type": self.type.value,
            "timestamp": self.timestamp.isoformat(),
            "data": self.data,
            "priority": self.priority,
            "source": self.source,
        }

    def to_websocket_message(self) -> Dict[str, Any]:
        """Convert to WebSocket message format"""
        return {"type": self.type.value, "data": self.data, "timestamp": self.timestamp.isoformat()}


class WebSocketManager:
    """
    Manager for WebSocket connections and real-time events

    Features:
    - Connection pooling per project
    - Message broadcasting
    - Event subscription
    - Heartbeat management
    - Thread-safe operations

    Usage:
        manager = WebSocketManager()

        # Connect client
        client_id = await manager.connect(websocket, project_name="my-novel")

        # Broadcast event
        event = RealtimeEvent(EventType.PROGRESS, data={"progress": 50})
        await manager.broadcast_to_project("my-novel", event)

        # Disconnect
        await manager.disconnect(client_id)
    """

    HEARTBEAT_INTERVAL = 30  # seconds
    HEARTBEAT_TIMEOUT = 90  # seconds

    def __init__(
        self,
        id_generator: Optional[Callable[[], str]] = None,
        time_provider: Optional[Callable[[], datetime]] = None,
    ):
        """
        Initialize WebSocket manager

        Args:
            id_generator: Optional custom ID generator (for testing)
            time_provider: Optional custom time provider (for testing)
        """
        # Use custom or default generators
        self._id_generator = id_generator or (lambda: str(uuid4()))
        self._time_provider = time_provider or datetime.now

        # Connection storage
        self.connections: Dict[str, WSConnection] = {}
        self.project_connections: Dict[str, Set[str]] = defaultdict(set)
        self.global_connections: Set[str] = set()

        # Lock for thread safety
        self.lock = threading.Lock()

        # Event subscriptions
        self.subscriptions: Dict[str, Set[EventType]] = defaultdict(set)

        # Statistics
        self.total_connections = 0
        self.total_disconnections = 0
        self.total_messages_sent = 0

        # Background tasks
        self._heartbeat_task: Optional[asyncio.Task] = None

    def _create_connection(
        self,
        client_id: str,
        websocket: WebSocket,
        project_name: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> WSConnection:
        """Create a new connection object (extracted for testability)"""
        return WSConnection(
            client_id=client_id,
            websocket=websocket,
            project_name=project_name,
            metadata=metadata or {},
        )

    def _create_welcome_event(self, connection: WSConnection) -> RealtimeEvent:
        """Create welcome event for new connection (extracted for testability)"""
        return RealtimeEvent(
            type=EventType.HEARTBEAT,
            data={
                "client_id": connection.client_id,
                "message": "Connected to Novel Generation API",
                "project": connection.project_name,
                "subscribed_events": [e.value for e in connection.subscribed_events],
            },
        )

    async def connect(
        self,
        websocket: WebSocket,
        project_name: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Accept WebSocket connection and register it

        Args:
            websocket: FastAPI WebSocket instance
            project_name: Optional project to subscribe to
            metadata: Optional client metadata

        Returns:
            Client ID for the connection
        """
        # Accept connection
        await websocket.accept()

        # Generate client ID
        client_id = self._id_generator()

        # Create connection object
        connection = self._create_connection(
            client_id=client_id,
            websocket=websocket,
            project_name=project_name,
            metadata=metadata,
        )

        # Register connection
        await self._register_connection(connection)

        # Subscribe to all events by default
        connection.subscribed_events = set(EventType)

        # Send welcome message
        await self._send_welcome(connection)

        return client_id

    async def _register_connection(self, connection: WSConnection) -> None:
        """Register connection in manager (extracted for testability)"""
        with self.lock:
            # Register connection
            self.connections[connection.client_id] = connection
            self.total_connections += 1

            # Register in project or global
            if connection.project_name:
                self.project_connections[connection.project_name].add(connection.client_id)
            else:
                self.global_connections.add(connection.client_id)

    async def disconnect(self, client_id: str) -> None:
        """
        Disconnect and remove a client

        Args:
            client_id: Client ID to disconnect
        """
        connection = await self._unregister_connection(client_id)

        if not connection:
            return

        # Close WebSocket gracefully
        await self._close_websocket(connection)

    async def _unregister_connection(self, client_id: str) -> Optional[WSConnection]:
        """Unregister connection from manager (extracted for testability)"""
        with self.lock:
            connection = self.connections.pop(client_id, None)

            if not connection:
                return None

            # Remove from project or global
            if connection.project_name:
                self.project_connections[connection.project_name].discard(client_id)
            else:
                self.global_connections.discard(client_id)

            # Remove subscriptions
            if client_id in self.subscriptions:
                del self.subscriptions[client_id]

            self.total_disconnections += 1

        return connection

    async def _close_websocket(self, connection: WSConnection) -> None:
        """Close WebSocket connection (extracted for testability)"""
        try:
            await connection.websocket.close()
        except Exception:
            pass

    async def _send_welcome(self, connection: WSConnection) -> None:
        """Send welcome message to new client"""
        welcome = self._create_welcome_event(connection)
        await connection.send_json(welcome.to_websocket_message())

    async def send_to_client(self, client_id: str, message: Dict[str, Any]) -> bool:
        """
        Send message to specific client

        Args:
            client_id: Target client ID
            message: Message dictionary

        Returns:
            True if sent successfully
        """
        with self.lock:
            connection = self.connections.get(client_id)

        if not connection:
            return False

        return await self._send_message_to_connection(connection, message)

    async def _send_message_to_connection(
        self, connection: WSConnection, message: Dict[str, Any]
    ) -> bool:
        """Send message to a connection (extracted for testability)"""
        try:
            await connection.send_json(message)
            self.total_messages_sent += 1
            return True
        except Exception:
            # Connection might be dead
            await self.disconnect(connection.client_id)
            return False

    async def send_to_client_raw(self, client_id: str, text: str) -> bool:
        """
        Send raw text to specific client

        Args:
            client_id: Target client ID
            text: Raw text message

        Returns:
            True if sent successfully
        """
        with self.lock:
            connection = self.connections.get(client_id)

        if not connection:
            return False

        try:
            await connection.send_text(text)
            self.total_messages_sent += 1
            return True
        except Exception:
            await self.disconnect(client_id)
            return False

    async def broadcast_to_project(self, project_name: str, event: RealtimeEvent) -> int:
        """
        Broadcast event to all clients subscribed to a project

        Args:
            project_name: Target project name
            event: Event to broadcast

        Returns:
            Number of clients that received the event
        """
        client_ids = self._get_project_client_ids(project_name)

        if not client_ids:
            return 0

        return await self._broadcast_to_clients(client_ids, event)

    def _get_project_client_ids(self, project_name: str) -> List[str]:
        """Get list of client IDs for a project (extracted for testability)"""
        with self.lock:
            return list(self.project_connections.get(project_name, set()))

    async def broadcast_global(self, event: RealtimeEvent) -> int:
        """
        Broadcast event to all globally subscribed clients

        Args:
            event: Event to broadcast

        Returns:
            Number of clients that received the event
        """
        client_ids = self._get_global_client_ids()

        if not client_ids:
            return 0

        return await self._broadcast_to_clients(client_ids, event)

    def _get_global_client_ids(self) -> List[str]:
        """Get list of global client IDs (extracted for testability)"""
        with self.lock:
            return list(self.global_connections)

    async def _broadcast_to_clients(self, client_ids: List[str], event: RealtimeEvent) -> int:
        """Broadcast event to list of clients (extracted for testability)"""
        sent_count = 0
        for client_id in client_ids:
            # Check subscription
            connection = self.connections.get(client_id)
            if connection and event.type in connection.subscribed_events:
                message = event.to_websocket_message()
                if await self._send_message_to_connection(connection, message):
                    sent_count += 1

        return sent_count

    async def emit_event(self, event: RealtimeEvent) -> int:
        """
        Emit event to appropriate clients based on event source

        Args:
            event: Event to emit

        Returns:
            Number of clients that received the event
        """
        # Check for project in source
        if event.source:
            return await self.broadcast_to_project(event.source, event)

        # Check for project in data
        if event.data and "project" in event.data:
            project = event.data["project"]
            return await self.broadcast_to_project(project, event)

        # Broadcast globally
        return await self.broadcast_global(event)

    def subscribe(self, client_id: str, event_types: List[EventType]) -> bool:
        """
        Subscribe client to specific event types

        Args:
            client_id: Client to subscribe
            event_types: List of event types to subscribe to

        Returns:
            True if successful
        """
        with self.lock:
            if client_id not in self.connections:
                return False

            connection = self.connections[client_id]
            for event_type in event_types:
                connection.subscribed_events.add(event_type)

        return True

    def unsubscribe(self, client_id: str, event_types: List[EventType]) -> bool:
        """
        Unsubscribe client from specific event types

        Args:
            client_id: Client to unsubscribe
            event_types: List of event types to unsubscribe from

        Returns:
            True if successful
        """
        with self.lock:
            if client_id not in self.connections:
                return False

            connection = self.connections[client_id]
            for event_type in event_types:
                connection.subscribed_events.discard(event_type)

        return True

    async def handle_client_message(self, client_id: str, message: Dict[str, Any]) -> None:
        """
        Handle incoming message from client

        Args:
            client_id: Client that sent message
            message: Message dictionary with 'type' and 'event_types'
        """
        msg_type = message.get("type")

        if msg_type == "subscribe":
            event_types = message.get("event_types", [])
            if event_types:
                event_type_enums = [EventType(et) for et in event_types]
                self.subscribe(client_id, event_type_enums)

        elif msg_type == "unsubscribe":
            event_types = message.get("event_types", [])
            if event_types:
                event_type_enums = [EventType(et) for et in event_types]
                self.unsubscribe(client_id, event_type_enums)

        elif msg_type == "ping":
            with self.lock:
                connection = self.connections.get(client_id)
            if connection:
                connection.update_ping()

    def get_clients_for_project(self, project_name: str) -> List[WSConnection]:
        """Get all clients connected to a project"""
        with self.lock:
            client_ids = self.project_connections.get(project_name, set())
            return [self.connections[cid] for cid in client_ids if cid in self.connections]

    def get_stats(self) -> Dict[str, Any]:
        """Get connection statistics"""
        with self.lock:
            return {
                "total_connections": self.total_connections,
                "total_disconnections": self.total_disconnections,
                "total_messages_sent": self.total_messages_sent,
                "active_connections": len(self.connections),
            }

    def get_connected_clients(self) -> int:
        """Get number of connected clients"""
        with self.lock:
            return len(self.connections)

    def get_connection_info(self, client_id: str) -> Optional[Dict[str, Any]]:
        """Get information about a specific connection"""
        with self.lock:
            connection = self.connections.get(client_id)
            if not connection:
                return None

            return {
                "client_id": connection.client_id,
                "project_name": connection.project_name,
                "metadata": connection.metadata,
                "connected_at": connection.connected_at.isoformat(),
                "subscribed_events": [e.value for e in connection.subscribed_events],
            }


# Singleton instance
_instance: Optional[WebSocketManager] = None
_instance_lock = threading.Lock()


def get_websocket_manager() -> WebSocketManager:
    """Get or create singleton WebSocket manager instance"""
    global _instance
    with _instance_lock:
        if _instance is None:
            _instance = WebSocketManager()
        return _instance
