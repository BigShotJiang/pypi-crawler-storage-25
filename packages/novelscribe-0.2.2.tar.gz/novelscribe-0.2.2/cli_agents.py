"""Agent exploration and management commands."""

import logging
import sys
from pathlib import Path

import click

from core.agent import AgentCategory
from core.agent_registry import AgentRegistry
from core.language_config import LanguageCode, get_current_language


@click.group()
def agents():
    """Agent exploration and management commands."""
    pass


@agents.command("list")
@click.pass_context
def agents_list(ctx: click.Context):
    """List all available agents."""
    logger = logging.getLogger("scribe")

    try:
        import agents as agents_pkg

        agents_dir = Path(agents_pkg.__file__).parent
        if not agents_dir.exists():
            logger.error("Agents directory not found")
            sys.exit(1)

        lang_str = ctx.obj.get("lang") if ctx.obj else None
        language = LanguageCode(lang_str) if lang_str else None
        project_dir = Path.cwd()

        current_language = get_current_language(
            explicit_language=language,
            project_dir=project_dir,
        )

        registry = AgentRegistry(agents_dir, language=current_language)
        all_agents = registry.get_all_agents()

        if not all_agents:
            logger.warning("No agents found")
            return

        logger.info(f"Available Agents ({len(all_agents)}) [Language: {current_language}]:")
        logger.info("")

        for category in AgentCategory:
            category_agents = registry.get_agents_by_category(category)
            if category_agents:
                category_name = category.value.capitalize()
                logger.info(f"{category_name} Agents:")

                for agent in sorted(category_agents, key=lambda a: a.name):
                    name_width = max(25, len(agent.name))
                    logger.info(f"  {agent.name:<{name_width}} - {agent.description}")

                logger.info("")

        logger.info("Run 'scribe agents show <name>' for detailed information about an agent.")
        supported_langs = registry.get_supported_languages()
        if len(supported_langs) > 1:
            logger.info(f"Supported languages: {', '.join(supported_langs)}")
            logger.info("Use '--lang <code>' to switch languages (e.g., --lang zh-CN)")

    except Exception as e:
        logger.error(f"Failed to list agents: {e}")
        if ctx.obj.get("debug", False):
            logger.exception("Full error trace:")
        sys.exit(1)


@agents.command("show")
@click.argument("agent_name")
@click.pass_context
def agents_show(ctx: click.Context, agent_name: str):
    """Show detailed information about an agent."""
    logger = logging.getLogger("scribe")

    try:
        import agents as agents_pkg

        agents_dir = Path(agents_pkg.__file__).parent
        if not agents_dir.exists():
            logger.error("Agents directory not found")
            sys.exit(1)

        lang_str = ctx.obj.get("lang") if ctx.obj else None
        language = LanguageCode(lang_str) if lang_str else None
        project_dir = Path.cwd()

        current_language = get_current_language(
            explicit_language=language,
            project_dir=project_dir,
        )

        registry = AgentRegistry(agents_dir, language=current_language)
        agent = registry.get_agent(agent_name)

        if not agent:
            logger.error(f"Agent '{agent_name}' not found [Language: {current_language}]")
            all_agents = registry.get_all_agents()
            available = [a.name for a in all_agents]
            logger.info(f"Available agents: {', '.join(available)}")
            sys.exit(1)

        logger.info(f"Agent: {agent.name} [Language: {current_language}]")
        logger.info("")
        if hasattr(agent.category, "value"):
            category_val = agent.category.value
        else:
            category_val = str(agent.category)
        logger.info(f"Category: {category_val.capitalize()}")
        logger.info(f"Version: {agent.version}")
        logger.info("")
        logger.info("Description:")
        logger.info(f"  {agent.description}")
        logger.info("")

        if agent.dependencies:
            deps = [d if isinstance(d, str) else d for d in agent.dependencies]
            logger.info(f"Dependencies: {', '.join(deps)}")
        else:
            logger.info("Dependencies: None")
        logger.info("")

        if agent.input_schema:
            logger.info("Input Schema:")
            for item in agent.input_schema:
                logger.info(f"  - {item}")
        else:
            logger.info("Input Schema: None")
        logger.info("")

        if agent.output_schema:
            logger.info("Output Schema:")
            for item in agent.output_schema:
                logger.info(f"  - {item}")
        else:
            logger.info("Output Schema: None")
        logger.info("")

        if agent.instructions:
            logger.info("Instructions:")
            prompt_lines = agent.instructions.strip().split("\n")[:3]
            for line in prompt_lines:
                logger.info(f"  {line}")
            if len(agent.instructions.split("\n")) > 3:
                logger.info("  [...]")
        logger.info("")

    except Exception as e:
        logger.error(f"Failed to show agent: {e}")
        if ctx.obj.get("debug", False):
            logger.exception("Full error trace:")
        sys.exit(1)
