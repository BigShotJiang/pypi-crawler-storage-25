"""
Comprehensive tests for Performance Optimization components

Tests cover:
- Performance Profiler
- File I/O Optimizer
- Parallel Executor
- LLM Call Optimizer
"""

import json
import tempfile
import time
from pathlib import Path
from unittest.mock import Mock

import pytest

from core.file_optimizer import FileOptimizer, get_file_optimizer
from core.llm_optimizer import (
    CachePolicy,
    LLMOptimizer,
    RateLimiter,
    get_llm_optimizer,
)
from core.parallel_executor import (
    ExecutionGraph,
    ExecutionNode,
    ParallelExecutor,
    get_parallel_executor,
)
from core.performance_profiler import (
    ExecutionStatus,
    PerformanceProfiler,
    ProfileType,
    ProfilingContext,
    get_profiler,
)


class TestPerformanceProfiler:
    """Test suite for PerformanceProfiler"""

    def test_profiler_initialization(self):
        """Test profiler initialization"""
        profiler = PerformanceProfiler()
        assert len(profiler.profiles) == 0
        assert len(profiler.active_profiles) == 0
        assert profiler.start_time > 0

    def test_start_profile(self):
        """Test starting a new profile"""
        profiler = PerformanceProfiler()
        profile_id = profiler.start_profile("test_agent", ProfileType.AGENT)

        assert profile_id in profiler.profiles
        assert profiler.profiles[profile_id].name == "test_agent"
        assert profiler.profiles[profile_id].profile_type == ProfileType.AGENT
        assert profiler.profiles[profile_id].status == ExecutionStatus.RUNNING

    def test_end_profile(self):
        """Test ending a profile"""
        profiler = PerformanceProfiler()
        profile_id = profiler.start_profile("test_agent", ProfileType.AGENT)
        time.sleep(0.1)

        profile = profiler.end_profile(profile_id)

        assert profile.status == ExecutionStatus.COMPLETED
        assert profile.duration is not None
        assert profile.duration >= 0.1

    def test_profile_with_error(self):
        """Test profile with error"""
        profiler = PerformanceProfiler()
        profile_id = profiler.start_profile("test_agent", ProfileType.AGENT)

        profile = profiler.end_profile(profile_id, error="Test error")

        assert profile.status == ExecutionStatus.FAILED
        assert profile.error == "Test error"

    def test_parent_child_relationships(self):
        """Test parent-child profile relationships"""
        profiler = PerformanceProfiler()

        parent_id = profiler.start_profile("parent", ProfileType.WORKFLOW)
        child_id = profiler.start_profile("child", ProfileType.AGENT)

        assert profiler.profiles[child_id].parent_id == parent_id
        assert child_id in profiler.profiles[parent_id].sub_profiles

        profiler.end_profile(child_id)
        profiler.end_profile(parent_id)

    def test_get_profiles_by_type(self):
        """Test filtering profiles by type"""
        profiler = PerformanceProfiler()

        agent_id = profiler.start_profile("agent1", ProfileType.AGENT)
        workflow_id = profiler.start_profile("workflow1", ProfileType.WORKFLOW)

        agent_profiles = profiler.get_profiles_by_type(ProfileType.AGENT)
        workflow_profiles = profiler.get_profiles_by_type(ProfileType.WORKFLOW)

        assert len(agent_profiles) == 1
        assert len(workflow_profiles) == 1
        assert agent_profiles[0].name == "agent1"
        assert workflow_profiles[0].name == "workflow1"

        profiler.end_profile(agent_id)
        profiler.end_profile(workflow_id)

    def test_identify_bottlenecks(self):
        """Test bottleneck identification"""
        profiler = PerformanceProfiler()

        # Create fast profile
        fast_id = profiler.start_profile("fast", ProfileType.AGENT)
        profiler.end_profile(fast_id)

        # Create slow profile (simulate with manual duration)
        slow_id = profiler.start_profile("slow", ProfileType.AGENT)
        slow_profile = profiler.profiles[slow_id]
        slow_profile.end_time = slow_profile.start_time + 10  # 10 seconds
        slow_profile.duration = 10
        slow_profile.status = ExecutionStatus.COMPLETED

        bottlenecks = profiler.identify_bottlenecks(threshold=5.0)

        assert len(bottlenecks) == 1
        assert "slow" in bottlenecks[0]

    def test_get_report(self):
        """Test generating performance report"""
        profiler = PerformanceProfiler()

        agent_id = profiler.start_profile("agent1", ProfileType.AGENT)
        profiler.end_profile(agent_id)

        report = profiler.get_report()

        assert report.total_duration > 0
        assert len(report.agent_profiles) == 1
        assert "agents" in report.summary

    def test_export_json(self):
        """Test exporting data as JSON"""
        profiler = PerformanceProfiler()

        profile_id = profiler.start_profile("test", ProfileType.AGENT)
        profiler.end_profile(profile_id)

        with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".json") as f:
            output_path = f.name

        try:
            result_path = profiler.export_data(output_path, format="json")

            assert Path(result_path).exists()

            with open(result_path, "r") as f:
                data = json.load(f)

            assert "agents" in data
            assert len(data["agents"]) == 1
        finally:
            Path(output_path).unlink(missing_ok=True)

    def test_profiling_context_manager(self):
        """Test ProfilingContext context manager"""
        profiler = PerformanceProfiler()

        with ProfilingContext(profiler, "test_agent", ProfileType.AGENT):
            time.sleep(0.1)

        # Profile should be completed automatically
        profiles = profiler.get_profiles_by_type(ProfileType.AGENT)
        assert len(profiles) == 1
        assert profiles[0].status == ExecutionStatus.COMPLETED
        assert profiles[0].duration >= 0.1


class TestFileOptimizer:
    """Test suite for FileOptimizer"""

    def test_file_optimizer_initialization(self):
        """Test file optimizer initialization"""
        optimizer = FileOptimizer()
        assert optimizer.write_cache_size == FileOptimizer.DEFAULT_WRITE_CACHE_SIZE
        assert optimizer.enable_compression

    def test_read_and_write_file(self):
        """Test basic file read and write"""
        optimizer = FileOptimizer()

        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.txt"
            test_content = "Hello, World!"

            optimizer.write_file(str(test_file), test_content, immediate=True)
            assert test_file.exists()

            read_content = optimizer.read_file(str(test_file))
            assert read_content == test_content

    def test_file_caching(self):
        """Test file read caching"""
        optimizer = FileOptimizer()

        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.txt"
            test_content = "Cached content"

            optimizer.write_file(str(test_file), test_content, immediate=True)

            # First read (cache miss)
            optimizer.read_file(str(test_file))
            stats1 = optimizer.get_stats()

            # Second read (cache hit)
            optimizer.read_file(str(test_file))
            stats2 = optimizer.get_stats()

            assert stats2.cache_hits > stats1.cache_hits

    def test_write_behind_cache(self):
        """Test write-behind caching"""
        optimizer = FileOptimizer(write_cache_size=4096)  # Larger than test content

        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.txt"
            content = "x" * 2000  # Smaller than cache

            # Write should be cached (content < cache size)
            optimizer.write_file(str(test_file), content, immediate=False)

            # File should not exist yet (cached)
            assert not test_file.exists()

            # Flush should write the file
            optimizer.flush_all()
            assert test_file.exists()

    def test_file_compression(self):
        """Test automatic file compression"""
        optimizer = FileOptimizer(compression_threshold=100, enable_compression=True)

        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.txt"
            large_content = "x" * 200

            optimizer.write_file(str(test_file), large_content, immediate=True)

            # Compressed version should exist
            compressed_file = test_file.with_suffix(test_file.suffix + ".gz")
            assert compressed_file.exists()

            stats = optimizer.get_stats()
            assert stats.compressed_files > 0

    def test_cache_clear(self):
        """Test clearing caches"""
        optimizer = FileOptimizer()

        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.txt"

            optimizer.write_file(str(test_file), "content", immediate=True)
            optimizer.read_file(str(test_file))

            cache_info_before = optimizer.get_cache_info()
            assert cache_info_before["cached_files"] > 0

            optimizer.clear_cache()

            cache_info_after = optimizer.get_cache_info()
            assert cache_info_after["cached_files"] == 0

    def test_file_statistics(self):
        """Test file I/O statistics"""
        optimizer = FileOptimizer()

        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.txt"

            optimizer.write_file(str(test_file), "content", immediate=True)
            optimizer.read_file(str(test_file))

            stats = optimizer.get_stats()

            assert stats.reads > 0
            assert stats.writes > 0
            assert stats.bytes_read > 0
            assert stats.bytes_written > 0

    def test_delete_file(self):
        """Test file deletion"""
        optimizer = FileOptimizer()

        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.txt"

            optimizer.write_file(str(test_file), "content", immediate=True)
            optimizer.read_file(str(test_file))

            assert test_file.exists()

            optimizer.delete_file(str(test_file))

            assert not test_file.exists()
            # Cache should also be cleared
            cache_info = optimizer.get_cache_info()
            assert cache_info["cached_files"] == 0

    def test_read_file_from_gz(self):
        """Test reading file from .gz when only compressed exists (lines 74-75)."""
        import gzip

        optimizer = FileOptimizer()

        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.txt"
            gz_file = Path(str(test_file) + ".gz")
            content = "compressed content data"

            with gzip.open(str(gz_file), "wt") as f:
                f.write(content)

            assert not test_file.exists()
            assert gz_file.exists()

            read_content = optimizer.read_file(str(test_file))
            assert read_content == content

    def test_delete_file_removes_gz(self):
        """Test delete_file removes both regular and .gz files (lines 108→110, 110→113, 115)."""
        optimizer = FileOptimizer(compression_threshold=10, enable_compression=True)

        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.txt"
            large_content = "x" * 200

            optimizer.write_file(str(test_file), large_content, immediate=True)
            gz_file = Path(str(test_file) + ".gz")

            assert test_file.exists()
            assert gz_file.exists()

            optimizer.read_file(str(test_file))

            optimizer.delete_file(str(test_file))

            assert not test_file.exists()
            assert not gz_file.exists()
            cache_info = optimizer.get_cache_info()
            assert cache_info["cached_files"] == 0


class TestParallelExecutor:
    """Test suite for ParallelExecutor"""

    def test_executor_initialization(self):
        """Test executor initialization"""
        executor = ParallelExecutor(max_workers=4)
        assert executor.max_workers == 4

    def test_build_execution_graph(self):
        """Test building execution graph"""
        executor = ParallelExecutor()

        workflow_steps = [
            {"agent": "agent1", "dependencies": []},
            {"agent": "agent2", "dependencies": ["agent1"]},
        ]

        graph = executor.build_graph_from_workflow(workflow_steps)

        assert len(graph.nodes) == 2
        assert len(graph.edges) >= 1

    def test_topological_sort(self):
        """Test topological sorting"""
        executor = ParallelExecutor()

        workflow_steps = [
            {"agent": "agent1", "dependencies": []},
            {"agent": "agent2", "dependencies": ["agent1"]},
            {"agent": "agent3", "dependencies": ["agent1"]},
        ]

        graph = executor.build_graph_from_workflow(workflow_steps)
        order = graph.topological_sort()

        assert len(order) == 3
        # agent1 should come before agent2 and agent3
        agent1_idx = next(
            i for i, node_id in enumerate(order) if graph.nodes[node_id].agent_name == "agent1"
        )
        agent2_idx = next(
            i for i, node_id in enumerate(order) if graph.nodes[node_id].agent_name == "agent2"
        )
        agent3_idx = next(
            i for i, node_id in enumerate(order) if graph.nodes[node_id].agent_name == "agent3"
        )

        assert agent1_idx < agent2_idx
        assert agent1_idx < agent3_idx

    def test_cycle_detection(self):
        """Test cycle detection in execution graph"""
        graph = ExecutionGraph()

        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2")
        node3 = ExecutionNode(agent_name="agent3")

        graph.add_node(node1)
        graph.add_node(node2)
        graph.add_node(node3)

        # Create cycle: 1 -> 2 -> 3 -> 1
        graph.add_edge(node1.agent_id, node2.agent_id)
        graph.add_edge(node2.agent_id, node3.agent_id)
        graph.add_edge(node3.agent_id, node1.agent_id)

        cycles = graph.detect_cycles()
        assert len(cycles) > 0

    def test_graph_validation(self):
        """Test graph validation"""
        graph = ExecutionGraph()

        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2", dependencies=["nonexistent"])

        graph.add_node(node1)
        graph.add_node(node2)

        is_valid, errors = graph.validate()
        assert not is_valid
        assert len(errors) > 0

    def test_parallel_execution(self):
        """Test parallel execution"""
        executor = ParallelExecutor(max_workers=2)

        workflow_steps = [
            {"agent": "agent1", "dependencies": []},
            {"agent": "agent2", "dependencies": []},
        ]

        graph = executor.build_graph_from_workflow(workflow_steps)

        def mock_agent(name):
            def agent():
                time.sleep(0.1)
                return f"{name} result"

            return agent

        agent_functions = {
            "agent1": mock_agent("agent1"),
            "agent2": mock_agent("agent2"),
        }

        executor.execute_parallel(graph, agent_functions)

        assert len(graph.nodes) == 2

    def test_sequential_execution(self):
        """Test sequential execution"""
        executor = ParallelExecutor()

        workflow_steps = [
            {"agent": "agent1", "dependencies": []},
            {"agent": "agent2", "dependencies": ["agent1"]},
        ]

        graph = executor.build_graph_from_workflow(workflow_steps)

        agent_functions = {
            "agent1": lambda: "result1",
            "agent2": lambda: "result2",
        }

        result = executor.execute_sequential(graph, agent_functions)

        assert result.success
        assert len(result.completed_nodes) == 2


class TestLLMOptimizer:
    """Test suite for LLMOptimizer"""

    def test_optimizer_initialization(self):
        """Test optimizer initialization"""
        optimizer = LLMOptimizer()
        assert optimizer.default_provider == "openai"
        assert optimizer.enable_caching

    def test_hash_prompt(self):
        """Test prompt hashing"""
        optimizer = LLMOptimizer()

        hash1 = optimizer._hash_prompt("test prompt", "gpt-4")
        hash2 = optimizer._hash_prompt("test prompt", "gpt-4")
        hash3 = optimizer._hash_prompt("different prompt", "gpt-4")

        assert hash1 == hash2
        assert hash1 != hash3

    def test_estimate_tokens(self):
        """Test token estimation"""
        optimizer = LLMOptimizer()

        tokens = optimizer._estimate_tokens("Hello, world!")
        assert tokens > 0

    def test_estimate_cost(self):
        """Test cost estimation"""
        optimizer = LLMOptimizer()

        cost = optimizer._estimate_cost("gpt-4", 1000, 500)
        assert cost > 0

    def test_prompt_compression(self):
        """Test prompt compression"""
        optimizer = LLMOptimizer()

        original = "Hello     world\n\n\nTest"
        compressed = optimizer._compress_prompt(original)

        # Should remove extra whitespace
        assert "Hello     world" not in compressed
        assert "Hello world" in compressed

    def test_cache_operations(self):
        """Test cache operations"""
        optimizer = LLMOptimizer(cache_size=10)

        prompt_hash = "test_hash"
        response = "Test response"

        optimizer._add_to_cache(prompt_hash, response, "gpt-4", CachePolicy.STATIC)

        assert prompt_hash in optimizer.cache
        assert optimizer.cache[prompt_hash].response == response

        # Test cache hit
        cached = optimizer._get_cached_response(prompt_hash)
        assert cached is not None
        assert cached.response == response

    def test_cache_expiration(self):
        """Test cache expiration"""
        optimizer = LLMOptimizer()

        prompt_hash = "test_hash"

        optimizer._add_to_cache(prompt_hash, "response", "gpt-4", CachePolicy.SHORT)  # 5 minutes

        # Should not be expired
        cached = optimizer._get_cached_response(prompt_hash)
        assert cached is not None

        # Manually expire
        optimizer.cache[prompt_hash].created_at = time.time() - 400  # >5 min
        cached = optimizer._get_cached_response(prompt_hash)
        assert cached is None  # Should be expired

    def test_clear_cache(self):
        """Test clearing cache"""
        optimizer = LLMOptimizer()

        optimizer._add_to_cache("hash1", "response1", "gpt-4", CachePolicy.STATIC)
        optimizer._add_to_cache("hash2", "response2", "gpt-3.5-turbo", CachePolicy.STATIC)

        assert len(optimizer.cache) == 2

        # Clear all
        count = optimizer.clear_cache()
        assert count == 2
        assert len(optimizer.cache) == 0

        # Add back and clear by model
        optimizer._add_to_cache("hash1", "response1", "gpt-4", CachePolicy.STATIC)
        optimizer._add_to_cache("hash2", "response2", "gpt-3.5-turbo", CachePolicy.STATIC)

        count = optimizer.clear_cache(model="gpt-4")
        assert count == 1
        assert len(optimizer.cache) == 1

    def test_llm_call_with_cache(self):
        """Test LLM call with caching"""
        optimizer = LLMOptimizer()

        # Mock LLM client
        mock_client = Mock(return_value="Mock response")
        optimizer.set_llm_client(mock_client)

        prompt = "Test prompt"

        # First call (cache miss)
        response1 = optimizer.call_llm(
            prompt=prompt, model="gpt-4", cache_policy=CachePolicy.STATIC
        )

        # Second call (cache hit)
        response2 = optimizer.call_llm(
            prompt=prompt, model="gpt-4", cache_policy=CachePolicy.STATIC
        )

        assert response1 == response2
        assert mock_client.call_count == 1  # Only called once due to cache

    def test_batch_call(self):
        """Test batch LLM calls"""
        optimizer = LLMOptimizer()

        # Mock LLM client
        mock_client = Mock(return_value="Batch response")
        optimizer.set_llm_client(mock_client)

        requests = [
            {"prompt": "prompt1", "model": "gpt-4"},
            {"prompt": "prompt2", "model": "gpt-4"},
        ]

        responses = optimizer.batch_call(requests)

        assert len(responses) == 2
        assert mock_client.call_count == 2

    def test_statistics(self):
        """Test LLM statistics"""
        optimizer = LLMOptimizer()

        mock_client = Mock(return_value="Response")
        optimizer.set_llm_client(mock_client)

        optimizer.call_llm("prompt1", "gpt-4", cache_policy=CachePolicy.NONE)
        optimizer.call_llm("prompt2", "gpt-4", cache_policy=CachePolicy.NONE)

        stats = optimizer.get_stats()

        assert stats.total_calls == 2
        assert stats.cache_misses == 0


class TestRateLimiter:
    """Test suite for RateLimiter"""

    def test_rate_limiter_initialization(self):
        """Test rate limiter initialization"""
        limiter = RateLimiter(requests_per_minute=60)
        assert limiter.requests_per_minute == 60
        assert limiter.tokens == 60

    def test_acquire_tokens(self):
        """Test acquiring tokens"""
        limiter = RateLimiter(requests_per_minute=60)

        # Acquire 1 token
        assert limiter.acquire(1)
        assert limiter.tokens == 59

        # Try to acquire more than available
        assert not limiter.acquire(100)

    def test_token_refill(self):
        """Test token refill over time"""
        limiter = RateLimiter(requests_per_minute=60)

        # Use all tokens
        limiter.acquire(60)
        assert not limiter.acquire(1)

        # Wait for refill (simulate time passing)
        limiter.last_update = time.time() - 60  # 1 minute ago
        limiter.tokens = 0

        # Tokens should be refilled
        available = limiter.get_available_tokens()
        assert available == 60


class TestGlobalInstances:
    """Test global instance functions"""

    def test_get_profiler(self):
        """Test global profiler instance"""
        profiler1 = get_profiler()
        profiler2 = get_profiler()
        assert profiler1 is profiler2

    def test_get_file_optimizer(self):
        """Test global file optimizer instance"""
        optimizer1 = get_file_optimizer()
        optimizer2 = get_file_optimizer()
        assert optimizer1 is optimizer2

    def test_get_parallel_executor(self):
        """Test global parallel executor instance"""
        executor1 = get_parallel_executor()
        executor2 = get_parallel_executor()
        assert executor1 is executor2

    def test_get_llm_optimizer(self):
        """Test global LLM optimizer instance"""
        optimizer1 = get_llm_optimizer()
        optimizer2 = get_llm_optimizer()
        assert optimizer1 is optimizer2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
