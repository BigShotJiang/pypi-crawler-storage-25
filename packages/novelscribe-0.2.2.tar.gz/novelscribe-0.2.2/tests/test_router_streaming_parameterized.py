"""Parameterized tests for streaming router covering various protocols and formats.

This test suite uses pytest parametrize to test:
- Different streaming protocols (SSE, chunked transfer encoding)
- Different data formats (JSON, binary, text)
- Different log levels
- Edge cases in parsing and formatting

Coverage Target: Extended test coverage with parameterization
"""

import json
from unittest.mock import MagicMock

import pytest

from api.models import LogLevel
from api.routers.streaming import (
    LogStreamerConfig,
    StatusStreamerConfig,
    create_error_event,
    create_log_event,
    format_sse,
    parse_event_types,
)


class TestFormatSSEParameterized:
    """Parameterized tests for format_sse function."""

    @pytest.mark.parametrize(
        "event_type",
        [
            "connected",
            "disconnected",
            "log",
            "error",
            "raw",
            "heartbeat",
            "execution_start",
            "execution_complete",
            "status_change",
        ],
    )
    def test_format_sse_various_event_types(self, event_type):
        """Test format_sse with various event types."""

        result = format_sse(event_type, {"test": "data"})
        assert result.startswith(f"event: {event_type}\n")
        assert result.endswith("\n\n")

    @pytest.mark.parametrize(
        "data",
        [
            {"simple": "value"},
            {"nested": {"deep": {"value": 123}}},
            {"array": [1, 2, 3, "four"]},
            {"empty": {}},
            {"unicode": "中文测试 🔥"},
            {"special_chars": 'Quote: " and slash: / and backslash: \\'},
            {"long_value": "x" * 1000},
            {"null_value": None},
            {"bool_values": True},
        ],
    )
    def test_format_sse_various_data_formats(self, data):
        """Test format_sse with various data formats."""

        result = format_sse("test", data)
        assert "event: test\ndata:" in result

        parsed_data = json.loads(result.split("data: ", 1)[1].rstrip("\n\n"))
        assert parsed_data == data

    @pytest.mark.parametrize(
        "event_type,data,expected_in_result",
        [
            ("connected", {"project": "p1"}, "connected"),
            ("heartbeat", {"timestamp": "2024-01-01"}, "heartbeat"),
            ("error", {"error": "msg"}, "error"),
            ("log", {"message": "test"}, "log"),
        ],
    )
    def test_format_sse_expected_content(self, event_type, data, expected_in_result):
        """Test format_sse contains expected content."""

        result = format_sse(event_type, data)
        assert expected_in_result in result


class TestCreateLogEventParameterized:
    """Parameterized tests for create_log_event function."""

    @pytest.mark.parametrize(
        "line",
        [
            '{"level": "INFO", "message": "test"}',
            '{"level": "ERROR", "message": "Error occurred"}',
            '{"level": "WARNING", "message": "Warning message"}',
            '{"level": "DEBUG", "message": "Debug info"}',
            '{"level": "CRITICAL", "message": "Critical issue"}',
        ],
    )
    def test_create_log_event_json_formats(self, line):
        """Test create_log_event with various JSON log formats."""

        result = create_log_event(line)
        assert result.startswith("event: log\ndata:")
        assert line in result or line.rstrip() in result

    @pytest.mark.parametrize("event_type", ["log", "raw"])
    def test_create_log_event_both_types(self, event_type):
        """Test create_log_event with both event types."""

        result = create_log_event("test line", event_type=event_type)
        assert f"event: {event_type}" in result

    @pytest.mark.parametrize(
        "line",
        [
            "plain text log",
            "multi\nline\nlog",
            "log with 'single quotes'",
            'log with "double quotes"',
            "unicode: 中文",
            "emoji: 🔥",
            "special: & < >",
            "",
        ],
    )
    def test_create_log_event_raw_type(self, line):
        """Test create_log_event with raw type for non-JSON lines."""

        result = create_log_event(line, event_type="raw")
        assert "event: raw" in result
        assert "message" in result


class TestCreateErrorEventParameterized:
    """Parameterized tests for create_error_event function."""

    @pytest.mark.parametrize(
        "error_message",
        [
            "Project not found",
            "Storage error: connection failed",
            "Permission denied",
            "Timeout while reading file",
            "Invalid log format",
            "x" * 500,
            "中文错误消息",
            "Error with 'quotes'",
            "Multiple errors: error1, error2",
        ],
    )
    def test_create_error_event_various_messages(self, error_message):
        """Test create_error_event with various error messages."""

        result = create_error_event(error_message)
        assert "event: error" in result
        assert error_message in result or json.dumps({"error": error_message}) in result

    def test_create_error_event_json_validity(self):
        """Test create_error_event produces valid JSON."""
        import json

        result = create_error_event("Test error")
        parts = result.split("data: ", 1)
        if len(parts) > 1:
            data_str = parts[1].rstrip("\n\n")
            parsed = json.loads(data_str)
            assert "error" in parsed


class TestParseEventTypesParameterized:
    """Parameterized tests for parse_event_types function."""

    @pytest.mark.parametrize(
        "input_str,expected",
        [
            ("log", ["log"]),
            ("log,error", ["log", "error"]),
            ("log,error,warning", ["log", "error", "warning"]),
            ("log , error", ["log", "error"]),
            (" log , error ", ["log", "error"]),
            ("a,b,c,d,e", ["a", "b", "c", "d", "e"]),
        ],
    )
    def test_parse_event_types_valid_inputs(self, input_str, expected):
        """Test parse_event_types with valid inputs."""

        result = parse_event_types(input_str)
        assert result == expected

    @pytest.mark.parametrize(
        "input_str",
        [
            None,
            "",
            "   ",
            "  ",
        ],
    )
    def test_parse_event_types_none_empty(self, input_str):
        """Test parse_event_types with None/empty inputs."""

        result = parse_event_types(input_str)
        assert result is None

    def test_parse_event_types_many_items(self):
        """Test parse_event_types with many items."""

        items = [f"type_{i}" for i in range(100)]
        result = parse_event_types(",".join(items))
        assert len(result) == 100


class TestLogStreamerConfigParameterized:
    """Parameterized tests for LogStreamerConfig class."""

    @pytest.mark.parametrize(
        "max_iterations,poll_interval",
        [
            (1000, 1),
            (100, 0.1),
            (1, 0.001),
            (500, 0.5),
            (10, 2),
            (1, 10),
        ],
    )
    def test_log_streamer_config_values(self, max_iterations, poll_interval):
        """Test LogStreamerConfig with various values."""

        config = LogStreamerConfig(max_iterations=max_iterations, poll_interval=poll_interval)
        assert config.max_iterations == max_iterations
        assert config.poll_interval == poll_interval

    def test_log_streamer_config_defaults(self):
        """Test LogStreamerConfig default values."""

        config = LogStreamerConfig()
        assert config.max_iterations == 1000
        assert config.poll_interval == 1


class TestStatusStreamerConfigParameterized:
    """Parameterized tests for StatusStreamerConfig class."""

    @pytest.mark.parametrize(
        "max_iterations,poll_interval",
        [
            (1000, 2),
            (100, 0.5),
            (1, 0.001),
            (50, 1),
        ],
    )
    def test_status_streamer_config_values(self, max_iterations, poll_interval):
        """Test StatusStreamerConfig with various values."""

        config = StatusStreamerConfig(max_iterations=max_iterations, poll_interval=poll_interval)
        assert config.max_iterations == max_iterations
        assert config.poll_interval == poll_interval

    def test_status_streamer_config_defaults(self):
        """Test StatusStreamerConfig default values."""

        config = StatusStreamerConfig()
        assert config.max_iterations == 1000
        assert config.poll_interval == 2


class TestLogLevelFiltering:
    """Parameterized tests for log level filtering in generate_log_events."""

    @pytest.mark.parametrize(
        "log_level",
        [
            LogLevel.DEBUG,
            LogLevel.INFO,
            LogLevel.WARNING,
            LogLevel.ERROR,
            LogLevel.CRITICAL,
        ],
    )
    async def test_filter_by_log_level(self, tmp_path, log_level):
        """Test log filtering by various log levels."""
        from api.routers.streaming import generate_log_events

        log_file = tmp_path / "execution.log"
        log_file.write_text(
            '{"level": "DEBUG", "message": "debug_msg"}\n'
            '{"level": "INFO", "message": "info_msg"}\n'
            '{"level": "WARNING", "message": "warn_msg"}\n'
            '{"level": "ERROR", "message": "error_msg"}\n'
            '{"level": "CRITICAL", "message": "critical_msg"}\n'
        )

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            log_level=log_level,
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)

    @pytest.mark.parametrize(
        "log_lines,expected_count",
        [
            (['{"level": "INFO", "message": "1"}'], 1),
            (['{"level": "INFO"}\n{"level": "INFO"}\n{"level": "INFO"}\n'], 3),
            (['{"level": "INFO"}\n{"level": "ERROR"}\n{"level": "INFO"}\n'], 2),
        ],
    )
    async def test_log_event_count(self, tmp_path, log_lines, expected_count):
        """Test log event counting with various inputs."""
        from api.routers.streaming import generate_log_events

        log_file = tmp_path / "execution.log"
        log_file.write_text("\n".join(log_lines))

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            log_level=LogLevel.INFO,
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)


class TestEventTypeFiltering:
    """Parameterized tests for event type filtering."""

    @pytest.mark.parametrize(
        "event_types",
        [
            ["log"],
            ["error"],
            ["agent"],
            ["workflow"],
            ["log", "error"],
            ["agent", "workflow", "log"],
            None,
        ],
    )
    async def test_filter_by_event_types(self, tmp_path, event_types):
        """Test event type filtering with various inputs."""
        from api.routers.streaming import generate_log_events

        log_file = tmp_path / "execution.log"
        log_file.write_text(
            '{"type": "log", "message": "log_msg"}\n'
            '{"type": "error", "message": "error_msg"}\n'
            '{"type": "agent", "message": "agent_msg"}\n'
            '{"type": "workflow", "message": "workflow_msg"}\n'
        )

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            event_types=event_types,
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)


class TestSSEFormatCompliance:
    """Tests for SSE format compliance."""

    @pytest.mark.parametrize(
        "event,data",
        [
            ("test", {"key": "value"}),
            ("connected", {"project": "test", "status": "connected"}),
            ("log", {"timestamp": "2024-01-01T12:00:00", "level": "INFO"}),
        ],
    )
    def test_sse_format_compliance(self, event, data):
        """Test SSE format follows specification."""

        result = format_sse(event, data)

        lines = result.split("\n")
        assert lines[0] == f"event: {event}", f"First line should be 'event: {event}'"
        assert lines[1].startswith("data: "), "Second line should start with 'data: '"
        assert result.endswith("\n\n"), "Should end with double newline"

    def test_sse_multiline_data_handling(self):
        """Test SSE handles multiline data correctly."""

        data = {"message": "Line1\nLine2\nLine3", "nested": {"value": 123}}
        result = format_sse("log", data)

        parsed = json.loads(result.split("data: ", 1)[1].rstrip("\n\n"))
        assert parsed["message"] == "Line1\nLine2\nLine3"

    def test_sse_empty_data(self):
        """Test SSE with empty data object."""

        result = format_sse("heartbeat", {})
        assert "event: heartbeat" in result
        assert "data: {}" in result

    def test_sse_data_with_newlines(self):
        """Test SSE data containing newlines."""

        result = format_sse("test", {"message": "Line1\nLine2"})
        data_part = result.split("data: ")[1].rstrip("\n\n")
        parsed = json.loads(data_part)
        assert parsed["message"] == "Line1\nLine2"


class TestStreamingProtocolVariations:
    """Tests for various streaming protocol behaviors."""

    @pytest.mark.parametrize(
        "poll_interval,iterations",
        [
            (0.001, 2),
            (0.01, 3),
            (0.1, 2),
        ],
    )
    async def test_log_streaming_timing(self, tmp_path, poll_interval, iterations):
        """Test log streaming with various timing configurations."""
        from api.routers.streaming import generate_log_events

        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=iterations, poll_interval=poll_interval)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)

        assert len(events) >= 1

    async def test_status_streaming_with_executions_tracking(self):
        """Test status streaming tracks execution states."""
        from api.routers.streaming import generate_status_events

        storage_checker = MagicMock(return_value=["test_project"])

        mock_exec_1 = MagicMock()
        mock_exec_1.execution_id = "exec_001"
        mock_exec_1.status = MagicMock(value="pending")
        mock_exec_1.to_dict.return_value = {"id": "exec_001", "status": "pending"}

        mock_exec_2 = MagicMock()
        mock_exec_2.execution_id = "exec_002"
        mock_exec_2.status = MagicMock(value="running")
        mock_exec_2.to_dict.return_value = {"id": "exec_002", "status": "running"}

        task_manager = MagicMock()
        task_manager.get_all_executions.side_effect = [
            [mock_exec_1],
            [mock_exec_1, mock_exec_2],
            [mock_exec_2],
            [],
        ]

        config = StatusStreamerConfig(max_iterations=4, poll_interval=0.001)

        events = []
        async for event in generate_status_events(
            "test_project",
            storage_checker=storage_checker,
            task_manager_getter=MagicMock(return_value=task_manager),
            config=config,
        ):
            events.append(event)

        start_events = [e for e in events if "execution_start" in e]

        assert len(start_events) >= 2

    @pytest.mark.parametrize("num_executions", [0, 1, 5, 10])
    async def test_status_streaming_with_various_execution_counts(self, num_executions):
        """Test status streaming with various execution counts."""
        from api.routers.streaming import generate_status_events

        storage_checker = MagicMock(return_value=["test_project"])

        mock_executions = []
        for i in range(num_executions):
            mock_exec = MagicMock()
            mock_exec.execution_id = f"exec_{i:03d}"
            mock_exec.status = MagicMock(value="running")
            mock_exec.to_dict.return_value = {"id": f"exec_{i:03d}", "status": "running"}
            mock_executions.append(mock_exec)

        task_manager = MagicMock()
        task_manager.get_all_executions.return_value = mock_executions

        config = StatusStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_status_events(
            "test_project",
            storage_checker=storage_checker,
            task_manager_getter=MagicMock(return_value=task_manager),
            config=config,
        ):
            events.append(event)

        start_events = [e for e in events if "execution_start" in e]
        assert len(start_events) >= num_executions if num_executions > 0 else True


class TestEdgeCasesAndBoundaries:
    """Edge case and boundary tests."""

    @pytest.mark.parametrize(
        "project_name",
        [
            "simple",
            "with-dash",
            "with_underscore",
            "with.dots",
            "a" * 50,
            "Project123",
        ],
    )
    def test_valid_project_names(self, project_name):
        """Test valid project names pass validation."""
        from api.routers.streaming import validate_project_name

        validate_project_name(project_name)

    @pytest.mark.parametrize(
        "project_name",
        [
            "path/with/slash",
            "path\\with\\backslash",
            "mixed\\path/separators",
            "../traversal",
            "path/../escape",
        ],
    )
    def test_invalid_project_names(self, project_name):
        """Test invalid project names fail validation."""
        from fastapi import HTTPException

        from api.routers.streaming import validate_project_name

        with pytest.raises(HTTPException) as exc_info:
            validate_project_name(project_name)
        assert exc_info.value.status_code == 400

    @pytest.mark.asyncio
    async def test_log_file_read_position_tracking(self, tmp_path):
        """Test log file position tracking works correctly."""
        from api.routers.streaming import generate_log_events

        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO", "message": "initial"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=3, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)

        log_events = [e for e in events if "event: log" in e]
        assert len(log_events) >= 1

    async def test_mixed_json_and_raw_lines(self, tmp_path):
        """Test handling mixed JSON and raw log lines."""
        from api.routers.streaming import generate_log_events

        log_file = tmp_path / "execution.log"
        log_file.write_text(
            '{"level": "INFO", "message": "json1"}\n'
            "plain text line\n"
            '{"level": "ERROR", "message": "json2"}\n'
            "another plain line\n"
        )

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)

        log_or_raw_events = [e for e in events if "event: log" in e or "event: raw" in e]
        assert len(log_or_raw_events) >= 2

    def test_build_stream_headers_consistency(self):
        """Test build_stream_headers returns consistent results."""
        from api.routers.streaming import build_stream_headers

        headers1 = build_stream_headers()
        headers2 = build_stream_headers()

        assert headers1 == headers2
        assert headers1["Cache-Control"] == "no-cache"
        assert headers1["Connection"] == "keep-alive"
        assert headers1["X-Accel-Buffering"] == "no"
