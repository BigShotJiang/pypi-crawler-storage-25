"""Tests for benchmarking module."""

from core.benchmarking import BenchmarkingEngine


def test_benchmarking_engine_creation():
    """Test BenchmarkingEngine can be created."""
    engine = BenchmarkingEngine("test_project")
    assert engine is not None
