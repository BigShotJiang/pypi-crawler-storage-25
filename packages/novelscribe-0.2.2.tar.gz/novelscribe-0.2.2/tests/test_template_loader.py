"""Test coverage for core/template_loader.py."""

import tempfile
from pathlib import Path

import yaml

from core.template_loader import TemplateLoader, get_template_loader


class TestTemplateLoader:
    """Test TemplateLoader class."""

    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        self.templates_dir = Path(self.temp_dir)
        (self.templates_dir / "en" / "plot").mkdir(parents=True, exist_ok=True)
        (self.templates_dir / "en" / "character").mkdir(parents=True, exist_ok=True)
        (self.templates_dir / "en" / "scene").mkdir(parents=True, exist_ok=True)
        (self.templates_dir / "zh-CN" / "plot").mkdir(parents=True, exist_ok=True)

    def _write_template(self, rel_path: str, data: dict):
        path = self.templates_dir / rel_path
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            yaml.dump(data, f)

    def test_init_with_custom_dir(self):
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        assert loader.templates_dir == Path(self.temp_dir)
        assert loader.language == "en"

    def test_init_with_default_dir(self):
        loader = TemplateLoader(language="en")
        assert loader.templates_dir.name == "templates"

    def test_load_yaml_caching(self):
        self._write_template("en/plot/test.yaml", {"templates": {"key": {"name": "Test"}}})
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        path = loader._get_template_path("plot", "test.yaml")

        data1 = loader._load_yaml(path)
        data2 = loader._load_yaml(path)
        assert data1 is data2

    def test_load_yaml_missing_file(self):
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        data = loader._load_yaml(Path("/nonexistent/file.yaml"))
        assert data == {}

    def test_get_template_path_language_fallback(self):
        self._write_template("en/plot/heros_journey.yaml", {"templates": {}})
        loader = TemplateLoader(templates_dir=self.temp_dir, language="zh-CN")
        path = loader._get_template_path("plot", "heros_journey.yaml")
        assert "en" in str(path)

    def test_get_template_path_missing(self):
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        path = loader._get_template_path("plot", "missing.yaml")
        assert "en" in str(path)

    def test_list_templates(self):
        self._write_template("en/plot/heros_journey.yaml", {})
        self._write_template("en/plot/three_act.yaml", {})
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        templates = loader.list_templates("plot")
        assert "heros_journey" in templates
        assert "three_act" in templates

    def test_list_templates_missing_dir(self):
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        templates = loader.list_templates("nonexistent")
        assert templates == []

    def test_load_plot_template(self):
        self._write_template(
            "en/plot/heros_journey.yaml",
            {"templates": {"heros_journey": {"name": "Hero's Journey", "beats": []}}},
        )
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        data = loader.load_plot_template("heros_journey")
        assert "heros_journey" in data

    def test_load_character_template(self):
        self._write_template(
            "en/character/archetypes.yaml",
            {"character_types": {"hero": {"name": "Hero"}}, "arc_types": {}},
        )
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        data = loader.load_character_template("archetypes")
        assert "character_types" in data

    def test_load_scene_template(self):
        self._write_template(
            "en/scene/structure.yaml",
            {"scene_types": {"action": {"name": "Action Scene"}}},
        )
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        data = loader.load_scene_template("structure")
        assert "scene_types" in data

    def test_get_plot_structures(self):
        self._write_template(
            "en/plot/heros_journey.yaml",
            {
                "templates": {
                    "heros_journey": {
                        "name": "Hero's Journey",
                        "description": "A monomyth structure",
                        "beats": [
                            {"name": "Ordinary World", "percentage": 0, "description": ""},
                            {"name": "Call to Adventure", "percentage": 10, "description": ""},
                        ],
                    }
                }
            },
        )
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        structures = loader.get_plot_structures()
        assert len(structures) >= 1
        assert structures[0]["name"] == "Hero's Journey"
        assert structures[0]["template_key"] == "heros_journey"
        assert len(structures[0]["beats"]) == 2

    def test_get_character_types(self):
        self._write_template(
            "en/character/archetypes.yaml",
            {"character_types": {"hero": {"name": "Hero"}, "mentor": {"name": "Mentor"}}},
        )
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        types = loader.get_character_types()
        assert "hero" in types
        assert "mentor" in types

    def test_get_arc_types(self):
        self._write_template(
            "en/character/archetypes.yaml",
            {"arc_types": {"transformation": {"name": "Transformation"}}},
        )
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        arcs = loader.get_arc_types()
        assert "transformation" in arcs

    def test_get_scene_types(self):
        self._write_template(
            "en/scene/structure.yaml",
            {
                "scene_types": {
                    "action": {"name": "Action Scene"},
                    "dialogue": {"name": "Dialogue Scene"},
                }
            },
        )
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        types = loader.get_scene_types()
        assert "action" in types
        assert "dialogue" in types

    def test_get_plot_beat_for_position_first_beat(self):
        self._write_template(
            "en/plot/heros_journey.yaml",
            {
                "templates": {
                    "heros_journey": {
                        "beats": [
                            {"name": "Beat1", "percentage": 0, "description": "First"},
                            {"name": "Beat2", "percentage": 50, "description": "Second"},
                        ]
                    }
                }
            },
        )
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        beat = loader.get_plot_beat_for_position("heros_journey", 0.0)
        assert beat["name"] == "Beat1"

    def test_get_plot_beat_for_position_last(self):
        self._write_template(
            "en/plot/heros_journey.yaml",
            {
                "templates": {
                    "heros_journey": {
                        "beats": [
                            {"name": "Beat1", "percentage": 0, "description": "First"},
                            {"name": "Beat2", "percentage": 50, "description": "Second"},
                        ]
                    }
                }
            },
        )
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        beat = loader.get_plot_beat_for_position("heros_journey", 99.0)
        assert beat["name"] == "Beat2"

    def test_get_plot_beat_for_position_missing_template(self):
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        beat = loader.get_plot_beat_for_position("nonexistent", 50.0)
        assert beat is None

    def test_format_template_for_prompt(self):
        self._write_template(
            "en/plot/heros_journey.yaml",
            {
                "templates": {
                    "heros_journey": {
                        "name": "Hero's Journey",
                        "description": "A monomyth",
                        "beats": [
                            {
                                "name": "Ordinary World",
                                "percentage": 0,
                                "description": "The hero's home",
                                "questions": ["Who is the hero?"],
                            }
                        ],
                    }
                }
            },
        )
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        formatted = loader.format_template_for_prompt("heros_journey")
        assert "Hero's Journey" in formatted
        assert "A monomyth" in formatted
        assert "Ordinary World" in formatted
        assert "Who is the hero?" in formatted

    def test_format_template_for_prompt_unknown_template(self):
        loader = TemplateLoader(templates_dir=self.temp_dir, language="en")
        formatted = loader.format_template_for_prompt("nonexistent")
        assert formatted == ""

    def test_format_template_for_prompt_scene_type(self):
        formatted = TemplateLoader(
            templates_dir=self.temp_dir, language="en"
        ).format_template_for_prompt("some_template", template_type="character")
        assert formatted == ""

    def test_get_template_loader_helper(self):
        loader = get_template_loader("zh-CN")
        assert loader.language == "zh-CN"

    def test_language_specific_fallback_to_en(self):
        self._write_template(
            "en/plot/heros_journey.yaml",
            {"templates": {"heros_journey": {"name": "Heros Journey", "beats": []}}},
        )
        loader = TemplateLoader(templates_dir=self.temp_dir, language="fr")
        path = loader._get_template_path("plot", "heros_journey.yaml")
        assert "en" in str(path)
