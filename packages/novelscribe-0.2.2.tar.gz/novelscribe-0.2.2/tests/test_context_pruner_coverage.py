"""
Comprehensive tests for context_pruner.py to increase coverage to 90%+.
Tests edge cases, error handling, and all pruning strategies.
"""

from unittest.mock import Mock

from novel_harness.core.context_pruner import (
    ContextPruner,
    KeyElement,
    PruningConfig,
    PruningResult,
    PruningStrategy,
)


class TestKeyElement:
    """Test KeyElement dataclass."""

    def test_touch_updates_last_mention(self):
        """Test that touch() updates last_mention and increments mention_count."""
        element = KeyElement(
            element_type="character",
            content="Alice",
            importance_score=0.8,
            first_mention=1,
            last_mention=3,
            mention_count=2,
        )

        element.touch(5)

        assert element.last_mention == 5
        assert element.mention_count == 3

    def test_touch_increment(self):
        """Test mention_count increment."""
        element = KeyElement(
            element_type="location",
            content="Castle",
            importance_score=0.9,
            first_mention=1,
            last_mention=1,
            mention_count=1,
        )

        element.touch(2)
        assert element.mention_count == 2


class TestPruningConfig:
    """Test PruningConfig configuration."""

    def test_default_config(self):
        """Test default configuration values."""
        config = PruningConfig()

        assert config.strategy == PruningStrategy.IMPORTANCE
        assert config.target_size_tokens == 8000
        assert config.preserve_characters is True
        assert config.preserve_locations is True
        assert config.preserve_plot_points is True
        assert config.summary_compression is True
        assert config.min_importance_score == 0.3
        assert config.overlap_tokens == 200
        assert config.preserve_recent_chapters == 3

    def test_custom_config(self):
        """Test custom configuration."""
        config = PruningConfig(
            strategy=PruningStrategy.CHRONOLOGICAL,
            target_size_tokens=4000,
            preserve_characters=False,
        )

        assert config.strategy == PruningStrategy.CHRONOLOGICAL
        assert config.target_size_tokens == 4000
        assert config.preserve_characters is False


class TestContextPrunerInit:
    """Test ContextPruner initialization."""

    def test_init_with_defaults(self):
        """Test initialization with default values."""
        pruner = ContextPruner()

        assert pruner.config.strategy == PruningStrategy.IMPORTANCE
        assert pruner.llm_client is None
        assert pruner.key_elements == []
        assert pruner.chapter_summaries == {}

    def test_init_with_config(self):
        """Test initialization with custom config."""
        config = PruningConfig(strategy=PruningStrategy.SEMANTIC)
        pruner = ContextPruner(config=config)

        assert pruner.config.strategy == PruningStrategy.SEMANTIC

    def test_init_with_llm_client(self):
        """Test initialization with LLM client."""
        mock_client = Mock()
        pruner = ContextPruner(llm_client=mock_client)

        assert pruner.llm_client is mock_client


class TestPruneContext:
    """Test prune_context method."""

    def test_no_pruning_needed(self):
        """Test when context is already within target size."""
        pruner = ContextPruner()
        short_context = "This is a short context."

        result = pruner.prune_context(short_context, max_tokens=1000)

        assert isinstance(result, PruningResult)
        assert result.pruned_context == short_context
        assert result.reduction_percent == 0.0
        assert result.compression_time_seconds >= 0

    def test_prune_uses_config_target(self):
        """Test that max_tokens defaults to config target."""
        pruner = ContextPruner(config=PruningConfig(target_size_tokens=100))
        long_context = "word " * 1000

        result = pruner.prune_context(long_context)

        assert result.pruned_size_tokens <= 150

    def test_chronological_strategy(self):
        """Test chronological pruning strategy."""
        config = PruningConfig(strategy=PruningStrategy.CHRONOLOGICAL)
        pruner = ContextPruner(config=config)

        context = "\n".join([f"Line {i}" for i in range(100)])
        result = pruner.prune_context(context, max_tokens=50)

        assert isinstance(result, PruningResult)
        assert result.pruned_size_tokens < result.original_size_tokens
        assert result.reduction_percent > 0

    def test_importance_strategy(self):
        """Test importance-based pruning strategy."""
        config = PruningConfig(strategy=PruningStrategy.IMPORTANCE)
        pruner = ContextPruner(config=config)

        context = """
        Alice walked through the Castle. Alice saw Bob at the Castle entrance.
        The Castle was magnificent. Alice decided to enter the Castle.
        Bob followed Alice into the great hall.
        """

        result = pruner.prune_context(context, max_tokens=30)

        assert isinstance(result, PruningResult)
        assert len(result.pruned_context) > 0

    def test_semantic_strategy_without_llm(self):
        """Test semantic pruning falls back to importance without LLM."""
        config = PruningConfig(strategy=PruningStrategy.SEMANTIC)
        pruner = ContextPruner(config=config, llm_client=None)

        context = "Alice walked to the Castle. " * 100
        result = pruner.prune_context(context, max_tokens=50)

        assert isinstance(result, PruningResult)
        assert len(result.pruned_context) > 0

    def test_semantic_strategy_with_llm(self):
        """Test semantic pruning with LLM client."""
        config = PruningConfig(strategy=PruningStrategy.SEMANTIC)
        mock_client = Mock()
        mock_client.generate = Mock(return_value="Compressed context about Alice and Castle")
        pruner = ContextPruner(config=config, llm_client=mock_client)

        context = "Alice walked to the Castle. " * 100
        result = pruner.prune_context(context, max_tokens=50)

        assert isinstance(result, PruningResult)
        mock_client.generate.assert_called_once()
        assert "Compressed context" in result.pruned_context

    def test_semantic_strategy_llm_failure(self):
        """Test semantic pruning falls back on LLM failure."""
        config = PruningConfig(strategy=PruningStrategy.SEMANTIC)
        mock_client = Mock()
        mock_client.generate = Mock(side_effect=Exception("LLM error"))
        pruner = ContextPruner(config=config, llm_client=mock_client)

        context = "Alice walked to the Castle. " * 100
        result = pruner.prune_context(context, max_tokens=50)

        assert isinstance(result, PruningResult)
        assert len(result.pruned_context) > 0

    def test_compressive_strategy(self):
        """Test compressive pruning strategy."""
        config = PruningConfig(strategy=PruningStrategy.COMPRESSIVE)
        pruner = ContextPruner(config=config)

        context = (
            """
        Alice discovered the secret in the Castle.
        Bob revealed the truth about his past.
        They confronted the enemy together.
        """
            * 5
        )

        result = pruner.prune_context(context, max_tokens=100)

        assert isinstance(result, PruningResult)
        assert len(result.pruned_context) > 0

    def test_compressive_strategy_without_compression(self):
        """Test compressive strategy falls back when compression disabled."""
        config = PruningConfig(
            strategy=PruningStrategy.COMPRESSIVE,
            summary_compression=False,
        )
        pruner = ContextPruner(config=config)

        context = "Alice walked to the Castle. " * 100
        result = pruner.prune_context(context, max_tokens=50)

        assert isinstance(result, PruningResult)

    def test_compressive_fallback_to_importance(self):
        """Test that compressive strategy with no summaries falls back appropriately."""
        config = PruningConfig(strategy=PruningStrategy.COMPRESSIVE)
        pruner = ContextPruner(config=config)

        context = "Alice walked to the Castle. Bob followed her."
        result = pruner.prune_context(context, max_tokens=50)

        assert isinstance(result, PruningResult)
        assert len(result.pruned_context) > 0


class TestChronologicalPruning:
    """Test chronological pruning method."""

    def test_keeps_most_recent_lines(self):
        """Test that chronological pruning keeps recent content."""
        pruner = ContextPruner()

        context = "\n".join([f"Line {i}" for i in range(100)])
        pruned = pruner._prune_chronologically(context, target_tokens=30)

        lines = pruned.split("\n")
        assert len(lines) < 100

    def test_handles_empty_context(self):
        """Test chronological pruning with empty context."""
        pruner = ContextPruner()

        result = pruner._prune_chronologically("", target_tokens=100)
        assert result == ""


class TestImportancePruning:
    """Test importance-based pruning method."""

    def test_preserve_characters_only(self):
        """Test preserving only characters."""
        config = PruningConfig(
            preserve_characters=True,
            preserve_locations=False,
            preserve_plot_points=False,
        )
        pruner = ContextPruner(config=config)

        context = "Alice walked to the Castle. Bob followed her. The Castle was old."
        pruned = pruner._prune_by_importance(context, target_tokens=30)

        assert len(pruned) > 0

    def test_preserve_locations_only(self):
        """Test preserving only locations."""
        config = PruningConfig(
            preserve_characters=False,
            preserve_locations=True,
            preserve_plot_points=False,
        )
        pruner = ContextPruner(config=config)

        context = "Alice walked to the Castle. Bob followed her."
        pruned = pruner._prune_by_importance(context, target_tokens=30)

        assert len(pruned) > 0

    def test_preserve_plot_points_only(self):
        """Test preserving only plot points."""
        config = PruningConfig(
            preserve_characters=False,
            preserve_locations=False,
            preserve_plot_points=True,
        )
        pruner = ContextPruner(config=config)

        context = "Alice discovered the secret and decided to act."
        pruned = pruner._prune_by_importance(context, target_tokens=30)

        assert len(pruned) > 0

    def test_preserved_content_within_target(self):
        """Test when preserved content is within target size."""
        config = PruningConfig(
            preserve_characters=True,
            preserve_locations=True,
            preserve_plot_points=True,
        )
        pruner = ContextPruner(config=config)

        context = "Alice discovered the secret in the Castle. Bob attacked at the Castle."
        pruned = pruner._prune_by_importance(context, target_tokens=100)

        assert len(pruned) > 0


class TestKeyElementExtraction:
    """Test key element extraction methods."""

    def test_extract_key_elements_characters(self):
        """Test character extraction."""
        pruner = ContextPruner()

        context = """
        Alice said hello to Bob.
        Alice walked to the Castle.
        Alice looked at the view.
        Bob followed Alice.
        """

        elements = pruner.extract_key_elements(context)

        char_elements = [e for e in elements if e.element_type == "character"]
        assert len(char_elements) > 0
        assert any(e.content == "Alice" for e in char_elements)

    def test_extract_key_elements_locations(self):
        """Test location extraction."""
        pruner = ContextPruner()

        context = """
        Alice walked to the Castle.
        She arrived at the Castle entrance.
        They met in the Great Hall.
        """

        elements = pruner.extract_key_elements(context)

        loc_elements = [e for e in elements if e.element_type == "location"]
        assert len(loc_elements) > 0

    def test_extract_key_elements_plot_points(self):
        """Test plot point extraction."""
        pruner = ContextPruner()

        context = """
        Alice discovered the secret treasure.
        She realized the truth about Bob.
        They decided to escape the Castle.
        """

        elements = pruner.extract_key_elements(context)

        plot_elements = [e for e in elements if e.element_type == "plot_point"]
        assert len(plot_elements) > 0

    def test_character_below_threshold(self):
        """Test characters with insufficient mentions are excluded."""
        pruner = ContextPruner()

        context = "Alice walked to the Castle."
        elements = pruner.extract_key_elements(context)

        char_elements = [e for e in elements if e.element_type == "character"]
        assert len(char_elements) == 0

    def test_location_below_threshold(self):
        """Test locations with insufficient mentions are excluded."""
        pruner = ContextPruner()

        context = "Alice walked to the Castle."
        elements = pruner.extract_key_elements(context)

        loc_elements = [e for e in elements if e.element_type == "location"]
        assert len(loc_elements) == 0

    def test_importance_score_capping(self):
        """Test that importance scores are capped at 1.0."""
        pruner = ContextPruner()

        context = "Alice " * 20 + "walked to the Castle."
        elements = pruner.extract_key_elements(context)

        for element in elements:
            assert element.importance_score <= 1.0


class TestContentExtraction:
    """Test content extraction methods."""

    def test_get_character_content(self):
        """Test character content generation."""
        pruner = ContextPruner()

        elements = [
            KeyElement(
                element_type="character",
                content="Alice",
                importance_score=0.8,
                first_mention=1,
                last_mention=5,
                mention_count=5,
            ),
            KeyElement(
                element_type="character",
                content="Bob",
                importance_score=0.5,
                first_mention=2,
                last_mention=4,
                mention_count=3,
            ),
        ]

        content = pruner._get_character_content(elements)

        assert "**Characters**:" in content
        assert "Alice" in content
        assert "Bob" in content

    def test_get_character_content_below_threshold(self):
        """Test character content with low importance scores."""
        config = PruningConfig(min_importance_score=0.9)
        pruner = ContextPruner(config=config)

        elements = [
            KeyElement(
                element_type="character",
                content="Alice",
                importance_score=0.5,
                first_mention=1,
                last_mention=1,
                mention_count=1,
            )
        ]

        content = pruner._get_character_content(elements)
        assert content == ""

    def test_get_location_content(self):
        """Test location content generation."""
        pruner = ContextPruner()

        elements = [
            KeyElement(
                element_type="location",
                content="Castle",
                importance_score=0.9,
                first_mention=1,
                last_mention=5,
                mention_count=3,
            ),
            KeyElement(
                element_type="location",
                content="Forest",
                importance_score=0.7,
                first_mention=2,
                last_mention=4,
                mention_count=2,
            ),
        ]

        content = pruner._get_location_content(elements)

        assert "**Locations**:" in content
        assert "Castle" in content
        assert "Forest" in content

    def test_get_location_content_below_threshold(self):
        """Test location content with low importance scores."""
        config = PruningConfig(min_importance_score=0.9)
        pruner = ContextPruner(config=config)

        elements = [
            KeyElement(
                element_type="location",
                content="Castle",
                importance_score=0.5,
                first_mention=1,
                last_mention=1,
                mention_count=1,
            )
        ]

        content = pruner._get_location_content(elements)
        assert content == ""

    def test_get_plot_content(self):
        """Test plot content generation."""
        pruner = ContextPruner()

        elements = [
            KeyElement(
                element_type="plot_point",
                content="Alice discovered the secret",
                importance_score=0.8,
                first_mention=1,
                last_mention=1,
                mention_count=1,
            ),
            KeyElement(
                element_type="plot_point",
                content="Bob betrayed the group",
                importance_score=0.9,
                first_mention=2,
                last_mention=2,
                mention_count=1,
            ),
        ]

        content = pruner._get_plot_content(elements)

        assert "**Key Plot Points**:" in content
        assert "Alice discovered the secret" in content
        assert "Bob betrayed the group" in content

    def test_get_plot_content_below_threshold(self):
        """Test plot content with low importance scores."""
        config = PruningConfig(min_importance_score=0.9)
        pruner = ContextPruner(config=config)

        elements = [
            KeyElement(
                element_type="plot_point",
                content="Some plot point",
                importance_score=0.5,
                first_mention=1,
                last_mention=1,
                mention_count=1,
            )
        ]

        content = pruner._get_plot_content(elements)
        assert content == ""


class TestAdditionalContent:
    """Test additional content extraction."""

    def test_get_additional_content(self):
        """Test extracting additional content beyond preserved."""
        pruner = ContextPruner()

        context = "Line 1\nLine 2\nLine 3\nLine 4\nLine 5"
        preserved = "Line 1\nLine 2"

        additional = pruner._get_additional_content(context, preserved, target_tokens=50)

        assert len(additional) > 0

    def test_additional_content_skips_preserved(self):
        """Test that preserved content is not duplicated."""
        pruner = ContextPruner()

        context = "Alice walked\nBob followed\nAlice sat down"
        preserved = "Alice walked"

        additional = pruner._get_additional_content(context, preserved, target_tokens=100)

        assert "Alice walked" not in additional


class TestSummaryOperations:
    """Test summary extraction and manipulation."""

    def test_extract_summaries_with_markers(self):
        """Test extracting summaries with chapter markers."""
        pruner = ContextPruner()

        context = """
        **Chapter 1:** Alice discovered the secret and decided to investigate the matter further.

        **Chapter 2:** Bob revealed the truth about his past and his connection to the Castle.

        **Chapter 3:** They escaped together and planned their next move against the enemy.
        """

        summaries = pruner._extract_summaries(context)

        assert len(summaries) >= 1

    def test_extract_summaries_without_markers(self):
        """Test extracting summaries without chapter markers."""
        pruner = ContextPruner()

        context = """
        This is a long paragraph about what happened.
        It contains many details about the characters.

        This is another paragraph with more story details.
        It continues the narrative and provides context.
        """

        summaries = pruner._extract_summaries(context)

        assert len(summaries) >= 0

    def test_compress_summaries_empty(self):
        """Test compressing empty summary list."""
        pruner = ContextPruner()

        result = pruner.compress_summaries([])
        assert result == ""

    def test_compress_summaries_single(self):
        """Test compressing single summary."""
        pruner = ContextPruner()

        result = pruner.compress_summaries(["Single summary text."])
        assert result == "Single summary text."

    def test_compress_summaries_multiple(self):
        """Test compressing multiple summaries."""
        pruner = ContextPruner()

        summaries = [
            "Alice discovered the secret treasure hidden in the castle.",
            "Bob revealed his true identity to the group.",
            "They decided to work together to defeat the enemy.",
        ]

        result = pruner.compress_summaries(summaries)

        assert len(result) > 0
        assert "Alice" in result or "Bob" in result

    def test_merge_summaries_empty(self):
        """Test merging empty summary list."""
        pruner = ContextPruner()

        result = pruner.merge_summaries([])
        assert result == ""

    def test_merge_summaries_single(self):
        """Test merging single summary."""
        pruner = ContextPruner()

        result = pruner.merge_summaries(["Single summary text."])
        assert result == "Single summary text."

    def test_merge_summaries_multiple(self):
        """Test merging multiple summaries."""
        pruner = ContextPruner()

        summaries = [
            "Alice discovered the secret treasure hidden in the castle.",
            "Bob revealed his true identity and motivations.",
            "They decided to work together to defeat the enemy.",
        ]

        result = pruner.merge_summaries(summaries)

        assert len(result) > 0
        assert "\n\n" in result


class TestRanking:
    """Test element ranking functionality."""

    def test_rank_by_importance(self):
        """Test ranking elements by importance score."""
        pruner = ContextPruner()

        elements = [
            KeyElement(
                element_type="character",
                content="Alice",
                importance_score=0.5,
                first_mention=1,
                last_mention=5,
                mention_count=5,
            ),
            KeyElement(
                element_type="character",
                content="Bob",
                importance_score=0.9,
                first_mention=2,
                last_mention=4,
                mention_count=3,
            ),
            KeyElement(
                element_type="location",
                content="Castle",
                importance_score=0.7,
                first_mention=1,
                last_mention=5,
                mention_count=4,
            ),
        ]

        ranked = pruner.rank_by_importance(elements)

        assert ranked[0].content == "Bob"
        assert ranked[1].content == "Castle"
        assert ranked[2].content == "Alice"


class TestChapterSummaries:
    """Test chapter summary tracking."""

    def test_add_chapter_summary(self):
        """Test adding chapter summaries."""
        pruner = ContextPruner()

        pruner.add_chapter_summary(1, "Alice began her journey.")
        pruner.add_chapter_summary(2, "Bob joined the adventure.")

        assert pruner.chapter_summaries[1] == "Alice began her journey."
        assert pruner.chapter_summaries[2] == "Bob joined the adventure."

    def test_clear_cache(self):
        """Test clearing cached data."""
        pruner = ContextPruner()

        pruner.key_elements = [
            KeyElement(
                element_type="character",
                content="Alice",
                importance_score=0.8,
                first_mention=1,
                last_mention=1,
                mention_count=1,
            )
        ]
        pruner.chapter_summaries = {1: "Summary"}

        pruner.clear_cache()

        assert pruner.key_elements == []
        assert pruner.chapter_summaries == {}


class TestEdgeCases:
    """Test edge cases and boundary conditions."""

    def test_empty_context(self):
        """Test pruning empty context."""
        pruner = ContextPruner()

        result = pruner.prune_context("", max_tokens=100)

        assert isinstance(result, PruningResult)
        assert result.pruned_context == ""

    def test_very_short_context(self):
        """Test pruning very short context."""
        pruner = ContextPruner()

        result = pruner.prune_context("Hi", max_tokens=1000)

        assert result.reduction_percent == 0.0

    def test_zero_target_tokens(self):
        """Test pruning with zero target tokens."""
        pruner = ContextPruner()

        result = pruner.prune_context("Some context", max_tokens=0)

        assert isinstance(result, PruningResult)

    def test_context_with_special_characters(self):
        """Test pruning context with special characters."""
        pruner = ContextPruner()

        context = 'Alice said: "Hello!" @#$%^&*()'
        result = pruner.prune_context(context, max_tokens=50)

        assert isinstance(result, PruningResult)

    def test_multiline_context(self):
        """Test pruning multiline context."""
        pruner = ContextPruner()

        context = "\n\n\n".join(["Line content"] * 10)
        result = pruner.prune_context(context, max_tokens=30)

        assert isinstance(result, PruningResult)
