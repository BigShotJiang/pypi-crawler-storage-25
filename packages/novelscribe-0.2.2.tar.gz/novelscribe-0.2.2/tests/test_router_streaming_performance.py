"""Performance tests for streaming router under concurrent load conditions.

This test suite validates streaming performance under concurrent load:
- Multiple simultaneous streaming connections
- High event throughput
- Resource cleanup and connection handling
- Memory usage patterns

Coverage Target: Performance and stress testing
"""

import asyncio
import json
import time
from unittest.mock import MagicMock

import pytest

from api.routers.streaming import (
    LogStreamerConfig,
    StatusStreamerConfig,
    generate_log_events,
    generate_status_events,
)


class TestConcurrentStreaming:
    """Performance tests for concurrent streaming operations."""

    @pytest.mark.asyncio
    async def test_concurrent_log_generators(self, tmp_path):
        """Test multiple concurrent log generators."""

        log_file = tmp_path / "execution.log"
        log_file.write_text(
            "\n".join([f'{{"level": "INFO", "message": "msg{i}"}}' for i in range(100)])
        )

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=5, poll_interval=0.001)

        async def run_generator(gen_id):
            events = []
            async for event in generate_log_events(
                f"project_{gen_id}",
                storage_checker=storage_checker,
                log_file_provider=log_file_provider,
                config=config,
            ):
                events.append(event)
            return events

        results = await asyncio.gather(*[run_generator(i) for i in range(10)])

        for events in results:
            assert len(events) >= 1

    @pytest.mark.asyncio
    async def test_concurrent_status_generators(self):
        """Test multiple concurrent status generators."""

        storage_checker = MagicMock(return_value=["test_project"])

        mock_exec = MagicMock()
        mock_exec.execution_id = "exec_001"
        mock_exec.status = MagicMock(value="running")
        mock_exec.to_dict.return_value = {"id": "exec_001", "status": "running"}

        task_manager = MagicMock()
        task_manager.get_all_executions.return_value = [mock_exec]

        config = StatusStreamerConfig(max_iterations=5, poll_interval=0.001)

        async def run_generator(gen_id):
            events = []
            async for event in generate_status_events(
                f"project_{gen_id}",
                storage_checker=storage_checker,
                task_manager_getter=MagicMock(return_value=task_manager),
                config=config,
            ):
                events.append(event)
            return events

        results = await asyncio.gather(*[run_generator(i) for i in range(10)])

        for events in results:
            assert len(events) >= 1

    @pytest.mark.asyncio
    async def test_high_throughput_log_streaming(self, tmp_path):
        """Test high throughput log streaming with many events."""

        log_file = tmp_path / "execution.log"
        lines = [json.dumps({"level": "INFO", "message": f"Message {i}"}) for i in range(500)]
        log_file.write_text("\n".join(lines))

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=10, poll_interval=0.001)

        start = time.time()
        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)
        elapsed = time.time() - start

        log_events = [e for e in events if "event: log" in e]
        assert len(log_events) >= 1
        assert elapsed < 5.0

    @pytest.mark.asyncio
    async def test_mixed_log_status_streaming(self, tmp_path):
        """Test mixing log and status streaming concurrently."""

        log_file = tmp_path / "execution.log"
        log_file.write_text(
            "\n".join([f'{{"level": "INFO", "message": "msg{i}"}}' for i in range(50)])
        )

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)

        mock_exec = MagicMock()
        mock_exec.execution_id = "exec_001"
        mock_exec.status = MagicMock(value="running")
        mock_exec.to_dict.return_value = {"id": "exec_001", "status": "running"}

        task_manager = MagicMock()
        task_manager.get_all_executions.return_value = [mock_exec]

        config_log = LogStreamerConfig(max_iterations=5, poll_interval=0.001)
        config_status = StatusStreamerConfig(max_iterations=5, poll_interval=0.001)

        async def run_log_stream():
            events = []
            async for event in generate_log_events(
                "test_project",
                storage_checker=storage_checker,
                log_file_provider=log_file_provider,
                config=config_log,
            ):
                events.append(event)
            return events

        async def run_status_stream():
            events = []
            async for event in generate_status_events(
                "test_project",
                storage_checker=storage_checker,
                task_manager_getter=MagicMock(return_value=task_manager),
                config=config_status,
            ):
                events.append(event)
            return events

        log_events, status_events = await asyncio.gather(run_log_stream(), run_status_stream())

        assert len(log_events) >= 1
        assert len(status_events) >= 1


class TestStreamingPerformanceMetrics:
    """Tests for streaming performance metrics."""

    @pytest.mark.asyncio
    async def test_event_generation_latency(self, tmp_path):
        """Test latency of event generation."""

        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO", "message": "test"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=20, poll_interval=0.001)

        latencies = []
        start = None

        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            now = time.time()
            if start is None:
                start = now
            latencies.append(now - start)

        avg_latency = sum(latencies) / len(latencies) if latencies else 0
        assert avg_latency < 1.0

    @pytest.mark.asyncio
    async def test_memory_usage_with_many_events(self, tmp_path):
        """Test memory usage with many events generated."""

        log_file = tmp_path / "execution.log"
        data_str = '{"x": "' + ("*" * 100) + '"}'
        lines = [
            f'{{"level": "INFO", "message": "msg{i}", "data": {data_str}}}' for i in range(200)
        ]
        log_file.write_text("\n".join(lines))

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=10, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)

        assert len(events) >= 1
        total_size = sum(len(e) for e in events)
        assert total_size > 0

    @pytest.mark.asyncio
    @pytest.mark.slow
    async def test_generator_cleanup_on_timeout(self, tmp_path):
        """Test generator cleanup when cancelled."""

        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=100, poll_interval=0.001)

        gen = generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        )

        collected = []
        start = time.time()
        try:
            async for event in gen:
                collected.append(event)
                if time.time() - start > 0.5:
                    break
        finally:
            gen.aclose()

        assert len(collected) >= 1


class TestConnectionHandling:
    """Tests for connection handling under various conditions."""

    @pytest.mark.asyncio
    async def test_rapid_connect_disconnect(self, tmp_path):
        """Test rapid connect/disconnect cycles."""

        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=3, poll_interval=0.001)

        for i in range(20):
            events = []
            async for event in generate_log_events(
                "test_project",
                storage_checker=storage_checker,
                log_file_provider=log_file_provider,
                config=config,
            ):
                events.append(event)
                if len(events) >= 5:
                    break

            assert len(events) >= 1

    @pytest.mark.asyncio
    async def test_generator_completion_clean(self, tmp_path):
        """Test clean generator completion."""

        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)

        assert len(events) >= 1
        connected_events = [e for e in events if "connected" in e]
        assert len(connected_events) == 1

    @pytest.mark.asyncio
    async def test_error_during_streaming_recovery(self, tmp_path):
        """Test error recovery when log file becomes unavailable."""

        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n')

        call_count = [0]

        def intermittent_file_provider(name):
            call_count[0] += 1
            if call_count[0] >= 3:
                return None
            return log_file

        storage_checker = MagicMock(return_value=["test_project"])
        config = LogStreamerConfig(max_iterations=10, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=intermittent_file_provider,
            config=config,
        ):
            events.append(event)

        assert len(events) >= 1
        connected_events = [e for e in events if "connected" in e]
        assert len(connected_events) == 1


class TestStressTesting:
    """Stress tests for the streaming router."""

    @pytest.mark.asyncio
    async def test_sustained_high_load(self, tmp_path):
        """Test sustained high load over time."""

        log_file = tmp_path / "execution.log"
        log_file.write_text(
            "\n".join([f'{{"level": "INFO", "message": "msg{i}"}}' for i in range(1000)])
        )

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=50, poll_interval=0.001)

        start = time.time()
        event_count = 0

        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            event_count += 1

        elapsed = time.time() - start
        events_per_second = event_count / elapsed if elapsed > 0 else 0

        assert event_count >= 1
        assert events_per_second > 0

    @pytest.mark.asyncio
    async def test_large_log_file_handling(self, tmp_path):
        """Test handling of large log files."""

        log_file = tmp_path / "execution.log"
        lines = [
            json.dumps(
                {
                    "level": "INFO",
                    "message": f"Message {i}",
                    "timestamp": f"2024-01-01T{i:02d}:00:00",
                    "metadata": {"idx": i, "data": "x" * 50},
                }
            )
            for i in range(1000)
        ]
        log_file.write_text("\n".join(lines))

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=10, poll_interval=0.001)

        start = time.time()
        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)
            if len(events) >= 100:
                break

        elapsed = time.time() - start

        assert len(events) >= 1
        assert elapsed < 2.0

    @pytest.mark.asyncio
    async def test_concurrent_generators_with_different_configs(self, tmp_path):
        """Test concurrent generators with different configurations."""

        log_file = tmp_path / "execution.log"
        log_file.write_text(
            "\n".join([f'{{"level": "INFO", "message": "msg{i}"}}' for i in range(100)])
        )

        async def run_with_config(iterations, poll_interval):
            config = LogStreamerConfig(max_iterations=iterations, poll_interval=poll_interval)
            events = []
            async for event in generate_log_events(
                "test_project",
                storage_checker=MagicMock(return_value=["test_project"]),
                log_file_provider=MagicMock(return_value=log_file),
                config=config,
            ):
                events.append(event)
            return events

        results = await asyncio.gather(
            run_with_config(5, 0.01),
            run_with_config(10, 0.005),
            run_with_config(15, 0.001),
        )

        for events in results:
            assert len(events) >= 1


class TestResourceManagement:
    """Tests for resource management in streaming."""

    @pytest.mark.asyncio
    async def test_file_handle_cleanup(self, tmp_path):
        """Test file handles are properly handled."""

        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=3, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)

        log_file.write_text('{"level": "ERROR"}\n')

        events2 = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=MagicMock(return_value=log_file),
            config=config,
        ):
            events2.append(event)

        assert len(events) >= 1

    @pytest.mark.asyncio
    async def test_generator_iteration_cleanup(self, tmp_path):
        """Test generator iteration cleanup."""

        log_file = tmp_path / "execution.log"
        log_file.write_text(
            "\n".join([f'{{"level": "INFO", "message": "msg{i}"}}' for i in range(50)])
        )

        config = LogStreamerConfig(max_iterations=20, poll_interval=0.001)

        for _ in range(10):
            events = []
            async for event in generate_log_events(
                "test_project",
                storage_checker=MagicMock(return_value=["test_project"]),
                log_file_provider=MagicMock(return_value=log_file),
                config=config,
            ):
                events.append(event)
                if len(events) >= 10:
                    break

            assert len(events) >= 1


class TestStreamingQuality:
    """Tests for streaming quality metrics."""

    @pytest.mark.asyncio
    async def test_event_ordering(self, tmp_path):
        """Test events maintain correct ordering."""

        log_file = tmp_path / "execution.log"
        log_file.write_text(
            "\n".join(
                [f'{{"level": "INFO", "message": "msg{i}", "order": {i}}}' for i in range(20)]
            )
        )

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=5, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)

        connected_events = [e for e in events if "connected" in e]
        log_events = [e for e in events if "event: log" in e]

        if connected_events and log_events:
            connected_idx = events.index(connected_events[0])
            first_log_idx = events.index(log_events[0])
            assert connected_idx < first_log_idx

    @pytest.mark.asyncio
    async def test_no_duplicate_events(self, tmp_path):
        """Test no duplicate events are generated."""

        log_file = tmp_path / "execution.log"
        log_file.write_text(
            "\n".join([f'{{"level": "INFO", "message": "msg{i}"}}' for i in range(10)])
        )

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=3, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)

        log_data = [e for e in events if "event: log" in e]
        unique_data = set(log_data)
        assert len(log_data) == len(unique_data)
