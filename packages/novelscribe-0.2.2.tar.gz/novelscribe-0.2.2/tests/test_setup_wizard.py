"""Tests for setup_wizard module."""

import os
import tempfile
from pathlib import Path

import pytest

# Test that inquirer3 can be imported
try:
    import importlib.util

    INQUIRER3_AVAILABLE = importlib.util.find_spec("inquirer3") is not None
except ImportError:
    INQUIRER3_AVAILABLE = False


@pytest.mark.skipif(not INQUIRER3_AVAILABLE, reason="inquirer3 module not available")
class TestSetupWizard:
    """Test cases for SetupWizard class."""

    @pytest.fixture
    def temp_dir(self):
        """Create temporary directory for testing."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    @pytest.fixture
    def mock_wizard(self, temp_dir):
        """Create SetupWizard instance with mocked dependencies."""
        from setup_wizard import SetupWizard

        wizard = SetupWizard()
        wizard.install_dir = temp_dir
        wizard.config_dir = temp_dir / ".scribe"
        wizard.env_file = temp_dir / ".env"
        return wizard

    def test_validate_api_key_openai_valid(self, mock_wizard):
        """Test OpenAI API key validation with valid key."""
        valid_key = "sk-1234567890123456789012345678901234567890"
        assert mock_wizard.validate_api_key("openai", valid_key) is True

    def test_validate_api_key_openai_invalid(self, mock_wizard):
        """Test OpenAI API key validation with invalid key."""
        assert mock_wizard.validate_api_key("openai", "invalid") is False
        assert mock_wizard.validate_api_key("openai", "1234567890") is False
        assert mock_wizard.validate_api_key("openai", "") is False

    def test_validate_api_key_anthropic_valid(self, mock_wizard):
        """Test Anthropic API key validation with valid key."""
        valid_key = "sk-ant-1234567890123456789012345678901234567890"
        assert mock_wizard.validate_api_key("anthropic", valid_key) is True

    def test_validate_api_key_anthropic_invalid(self, mock_wizard):
        """Test Anthropic API key validation with invalid key."""
        assert mock_wizard.validate_api_key("anthropic", "sk-1234567890") is False
        assert mock_wizard.validate_api_key("anthropic", "invalid") is False

    def test_validate_api_key_google_valid(self, mock_wizard):
        """Test Google API key validation with valid key."""
        valid_key = "a1B2c3D4e5F6g7H8i9J0k1L2m3N4o5P6"
        assert mock_wizard.validate_api_key("google", valid_key) is True

    def test_validate_api_key_google_invalid(self, mock_wizard):
        """Test Google API key validation with invalid key."""
        assert mock_wizard.validate_api_key("google", "short") is False
        assert mock_wizard.validate_api_key("google", "a" * 31) is False
        assert mock_wizard.validate_api_key("google", "a" * 33) is False

    def test_save_api_key_creates_file(self, mock_wizard, temp_dir):
        """Test that save_api_key creates .env file."""
        mock_wizard.save_api_key("openai", "sk-test123")

        assert mock_wizard.env_file.exists()
        content = mock_wizard.env_file.read_text()
        assert "OPENAI_API_KEY=sk-test123" in content

    def test_save_api_key_secure_permissions(self, mock_wizard, temp_dir):
        """Test that save_api_key sets secure file permissions."""
        mock_wizard.save_api_key("openai", "sk-test123")

        # Check file permissions (should be 0o600 = 384)
        if os.name != "nt":  # Windows doesn't support chmod
            stat_info = os.stat(mock_wizard.env_file)
            mode = stat_info.st_mode & 0o777
            assert mode == 0o600, f"Expected 0o600, got {oct(mode)}"

    def test_save_api_key_overwrites_previous(self, mock_wizard, temp_dir):
        """Test that save_api_key overwrites previous keys."""
        mock_wizard.save_api_key("openai", "sk-first")
        mock_wizard.save_api_key("anthropic", "sk-ant-second")

        content = mock_wizard.env_file.read_text()
        # Should only have the latest key
        assert "sk-first" not in content
        assert "sk-ant-second" in content

    def test_save_api_key_anthropic(self, mock_wizard, temp_dir):
        """Test saving Anthropic API key."""
        mock_wizard.save_api_key("anthropic", "sk-ant-test123")

        content = mock_wizard.env_file.read_text()
        assert "ANTHROPIC_API_KEY=sk-ant-test123" in content

    def test_save_api_key_google(self, mock_wizard, temp_dir):
        """Test saving Google API key."""
        mock_wizard.save_api_key("google", "a1B2c3D4e5F6g7H8i9J0k1L2m3N4o5P6")

        content = mock_wizard.env_file.read_text()
        assert "GOOGLE_API_KEY=a1B2c3D4e5F6g7H8i9J0k1L2m3N4o5P6" in content

    def test_validate_api_key_unknown_provider(self, mock_wizard):
        """Test API key validation with unknown provider."""
        assert mock_wizard.validate_api_key("unknown", "any-key") is False

    def test_env_file_parent_created(self, mock_wizard, temp_dir):
        """Test that parent directory is created if needed."""
        nested_env = temp_dir / "nested" / "dir" / ".env"
        mock_wizard.env_file = nested_env

        mock_wizard.save_api_key("openai", "sk-test")

        assert nested_env.exists()
        assert nested_env.parent.exists()


class TestSetupWizardIntegration:
    """Integration tests for SetupWizard."""

    @pytest.fixture
    def temp_env(self):
        """Create temporary environment for testing."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_dir = Path(tmpdir)
            # Create mock install dir structure
            (test_dir / "agents").mkdir()
            yield test_dir

    def test_full_setup_flow_mocked(self, temp_env):
        """Test complete setup flow with mocked user input."""
        # This would require more complex mocking of inquirer
        # For now, test individual components
        pass

    def test_api_key_validation_edge_cases(self):
        """Test edge cases in API key validation."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from setup_wizard import SetupWizard

            wizard = SetupWizard()
            wizard.env_file = Path(tmpdir) / ".env"

            # Test minimum valid lengths
            assert wizard.validate_api_key("openai", "sk-" + "x" * 20) is True
            assert wizard.validate_api_key("openai", "sk-" + "x" * 19) is False

    def test_concurrent_api_key_writes(self, temp_env):
        """Test concurrent writes don't corrupt .env file."""
        import threading

        from setup_wizard import SetupWizard

        wizard = SetupWizard()
        wizard.env_file = temp_env / ".env"

        results = []

        def write_key(provider, key):
            wizard.save_api_key(provider, key)
            results.append((provider, key))

        threads = [
            threading.Thread(target=write_key, args=("openai", "sk-thread1")),
            threading.Thread(target=write_key, args=("anthropic", "sk-ant-thread2")),
        ]

        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # File should exist with one of the writes (race condition possible)
        assert wizard.env_file.exists()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
