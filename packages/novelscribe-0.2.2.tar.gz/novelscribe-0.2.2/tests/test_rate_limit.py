"""Test coverage for api/middleware/rate_limit.py."""

import time
from unittest.mock import AsyncMock, MagicMock

import pytest

from api.middleware.rate_limit import (
    RateLimitConfig,
    RateLimiter,
    RateLimitMiddleware,
    TokenBucket,
    get_rate_limiter,
    reset_rate_limiter,
)


class TestRateLimitConfig:
    def test_defaults(self):
        config = RateLimitConfig()
        assert config.requests_per_minute == 60
        assert config.burst_size == 10
        assert config.by_ip is True
        assert config.by_endpoint is False
        assert config.enabled is True


class TestTokenBucket:
    def test_init(self):
        bucket = TokenBucket(tokens=10.0, max_tokens=10.0, refill_rate=1.0)
        assert bucket.tokens == 10.0
        assert bucket.max_tokens == 10.0
        assert bucket.refill_rate == 1.0

    def test_consume_success(self):
        bucket = TokenBucket(tokens=5.0, max_tokens=10.0, refill_rate=1.0)
        assert bucket.consume(1) is True
        assert abs(bucket.tokens - 4.0) < 0.001

    def test_consume_insufficient_tokens(self):
        bucket = TokenBucket(tokens=0.0, max_tokens=10.0, refill_rate=1.0)
        result = bucket.consume(1)
        assert result is False

    def test_consume_multiple_tokens(self):
        bucket = TokenBucket(tokens=5.0, max_tokens=10.0, refill_rate=1.0)
        assert bucket.consume(3) is True
        assert abs(bucket.tokens - 2.0) < 0.001

    def test_remaining_property(self):
        bucket = TokenBucket(tokens=5.0, max_tokens=10.0, refill_rate=1.0)
        assert bucket.remaining == 5

    def test_reset_time_full(self):
        bucket = TokenBucket(tokens=10.0, max_tokens=10.0, refill_rate=1.0)
        assert bucket.reset_time == 0.0

    def test_reset_time_empty(self):
        bucket = TokenBucket(tokens=0.0, max_tokens=10.0, refill_rate=1.0)
        assert bucket.reset_time == 10.0

    def test_reset_time_partially_full(self):
        bucket = TokenBucket(tokens=5.0, max_tokens=10.0, refill_rate=2.0)
        assert bucket.reset_time == 2.5


class TestRateLimiter:
    def test_init_default(self):
        limiter = RateLimiter()
        assert limiter.config.requests_per_minute == 60
        assert limiter.config.burst_size == 10
        assert limiter.buckets == {}

    def test_init_with_config(self):
        config = RateLimitConfig(requests_per_minute=120, burst_size=20)
        limiter = RateLimiter(config)
        assert limiter.config.requests_per_minute == 120
        assert limiter.config.burst_size == 20

    def test_create_bucket(self):
        config = RateLimitConfig(requests_per_minute=60, burst_size=5)
        limiter = RateLimiter(config)
        bucket = limiter._create_bucket()
        assert bucket.max_tokens == 5.0
        assert bucket.refill_rate == 1.0

    def test_is_allowed_new_key(self):
        limiter = RateLimiter()
        result = limiter.is_allowed("192.168.1.1")
        assert result is True
        assert "192.168.1.1" in limiter.buckets

    def test_is_allowed_disabled(self):
        config = RateLimitConfig(enabled=False)
        limiter = RateLimiter(config)
        assert limiter.is_allowed("any_key") is True

    def test_is_allowed_exhausted(self):
        config = RateLimitConfig(requests_per_minute=60, burst_size=2)
        limiter = RateLimiter(config)
        limiter.is_allowed("client_a")
        limiter.is_allowed("client_a")
        result = limiter.is_allowed("client_a")
        assert result is False

    def test_get_remaining_new_key(self):
        limiter = RateLimiter()
        remaining = limiter.get_remaining("new_client")
        assert remaining == 10

    def test_get_remaining_existing_key(self):
        config = RateLimitConfig(requests_per_minute=60, burst_size=5)
        limiter = RateLimiter(config)
        limiter.is_allowed("client_b")
        limiter.is_allowed("client_b")
        remaining = limiter.get_remaining("client_b")
        assert remaining < 5

    def test_get_reset_time(self):
        limiter = RateLimiter()
        limiter.is_allowed("client_c")
        reset = limiter.get_reset_time("client_c")
        assert reset >= 0.0

    def test_get_reset_time_unknown_key(self):
        limiter = RateLimiter()
        reset = limiter.get_reset_time("nonexistent")
        assert reset == 0.0

    def test_get_headers(self):
        config = RateLimitConfig(requests_per_minute=60, burst_size=10)
        limiter = RateLimiter(config)
        limiter.is_allowed("client_d")
        headers = limiter.get_headers("client_d")
        assert "X-RateLimit-Limit" in headers
        assert "X-RateLimit-Remaining" in headers
        assert "X-RateLimit-Reset" in headers

    def test_reset_specific_key(self):
        limiter = RateLimiter()
        limiter.is_allowed("client_e")
        limiter.reset("client_e")
        assert "client_e" not in limiter.buckets

    def test_reset_all(self):
        limiter = RateLimiter()
        limiter.is_allowed("client_f")
        limiter.is_allowed("client_g")
        limiter.reset()
        assert limiter.buckets == {}

    def test_cleanup_old_buckets(self):
        limiter = RateLimiter()
        limiter.is_allowed("old_client")
        limiter.buckets["old_client"].last_refill = time.time() - 4000
        removed = limiter.cleanup_old_buckets(max_age_seconds=3600)
        assert removed == 1
        assert "old_client" not in limiter.buckets

    def test_cleanup_old_buckets_none(self):
        limiter = RateLimiter()
        limiter.is_allowed("recent_client")
        removed = limiter.cleanup_old_buckets(max_age_seconds=3600)
        assert removed == 0

    def test_get_client_ip_forwarded(self):
        limiter = RateLimiter()
        mock_request = MagicMock()
        mock_request.headers.get.side_effect = lambda k: (
            "10.0.0.1, 10.0.0.2" if k == "X-Forwarded-For" else None
        )
        mock_request.client = None
        ip = limiter._get_client_ip(mock_request)
        assert ip == "10.0.0.1"

    def test_get_client_ip_real_ip(self):
        limiter = RateLimiter()
        mock_request = MagicMock()
        mock_request.headers.get.side_effect = lambda k: None
        mock_request.client.host = "192.168.1.100"
        ip = limiter._get_client_ip(mock_request)
        assert ip == "192.168.1.100"

    def test_get_client_ip_unknown(self):
        limiter = RateLimiter()
        mock_request = MagicMock()
        mock_request.headers.get.return_value = None
        mock_request.client = None
        ip = limiter._get_client_ip(mock_request)
        assert ip == "unknown"

    def test_get_key_by_ip_only(self):
        config = RateLimitConfig(by_ip=True, by_endpoint=False)
        limiter = RateLimiter(config)
        mock_request = MagicMock()
        mock_request.headers.get.side_effect = lambda k: None
        mock_request.client.host = "10.0.0.1"
        key = limiter._get_key(mock_request)
        assert key == "10.0.0.1"

    def test_get_key_by_ip_and_endpoint(self):
        config = RateLimitConfig(by_ip=True, by_endpoint=True)
        limiter = RateLimiter(config)
        mock_request = MagicMock()
        mock_request.headers.get.side_effect = lambda k: None
        mock_request.client.host = "10.0.0.1"
        key = limiter._get_key(mock_request, "GET:/api/v1/status")
        assert "10.0.0.1" in key
        assert "GET:/api/v1/status" in key

    def test_get_key_by_endpoint_only(self):
        config = RateLimitConfig(by_ip=False, by_endpoint=True)
        limiter = RateLimiter(config)
        mock_request = MagicMock()
        key = limiter._get_key(mock_request, "GET:/api/v1/logs")
        assert key == "GET:/api/v1/logs"

    def test_get_key_global(self):
        config = RateLimitConfig(by_ip=False, by_endpoint=False)
        limiter = RateLimiter(config)
        key = limiter._get_key(MagicMock())
        assert key == "global"

    def test_is_allowed_request(self):
        limiter = RateLimiter()
        mock_request = MagicMock()
        mock_request.headers.get.side_effect = lambda k: None
        mock_request.client.host = "10.0.0.1"
        result = limiter.is_allowed_request(mock_request)
        assert result is True

    def test_get_remaining_request(self):
        limiter = RateLimiter()
        mock_request = MagicMock()
        mock_request.headers.get.side_effect = lambda k: None
        mock_request.client.host = "10.0.0.1"
        remaining = limiter.get_remaining_request(mock_request)
        assert remaining >= 0


class TestRateLimitMiddleware:
    def test_init(self):
        middleware = RateLimitMiddleware(MagicMock())
        assert middleware.limiter is not None
        assert middleware.limiter.config.enabled is True

    def test_init_with_config(self):
        config = RateLimitConfig(requests_per_minute=30, burst_size=5)
        middleware = RateLimitMiddleware(MagicMock(), config)
        assert middleware.limiter.config.requests_per_minute == 30
        assert middleware.limiter.config.burst_size == 5

    @pytest.mark.asyncio
    async def test_dispatch_disabled(self):
        config = RateLimitConfig(enabled=False)
        middleware = RateLimitMiddleware(MagicMock(), config)
        mock_request = MagicMock()
        mock_call_next = AsyncMock(return_value=MagicMock())
        await middleware.dispatch(mock_request, mock_call_next)
        mock_call_next.assert_called_once_with(mock_request)

    @pytest.mark.asyncio
    async def test_dispatch_allowed(self):
        middleware = RateLimitMiddleware(MagicMock())
        mock_request = MagicMock()
        mock_request.method = "GET"
        mock_request.url.path = "/api/v1/test"
        mock_request.headers.get.side_effect = lambda k: None
        mock_request.client.host = "10.0.0.1"
        mock_response = MagicMock()
        mock_call_next = AsyncMock(return_value=mock_response)
        response = await middleware.dispatch(mock_request, mock_call_next)
        assert response is mock_response
        assert mock_response.headers is not None

    @pytest.mark.asyncio
    async def test_dispatch_rate_limited(self):
        config = RateLimitConfig(requests_per_minute=60, burst_size=0)
        middleware = RateLimitMiddleware(MagicMock(), config)
        mock_request = MagicMock()
        mock_request.method = "GET"
        mock_request.url.path = "/api/v1/test"
        mock_request.headers.get.side_effect = lambda k: None
        mock_request.client.host = "10.0.0.1"
        from fastapi import HTTPException

        with pytest.raises(HTTPException) as exc_info:
            await middleware.dispatch(mock_request, AsyncMock())
        assert exc_info.value.status_code == 429


class TestGlobalInstances:
    def setup_method(self):
        import api.middleware.rate_limit as rl_module

        rl_module._rate_limiter = None

    def test_get_rate_limiter_creates_instance(self):
        limiter = get_rate_limiter()
        assert limiter is not None
        assert isinstance(limiter, RateLimiter)

    def test_get_rate_limiter_returns_same_instance(self):
        limiter1 = get_rate_limiter()
        limiter2 = get_rate_limiter()
        assert limiter1 is limiter2

    def test_reset_rate_limiter(self):
        limiter1 = get_rate_limiter()
        reset_rate_limiter()
        limiter2 = get_rate_limiter()
        assert limiter1 is not limiter2

    def test_get_rate_limiter_with_config(self):
        config = RateLimitConfig(requests_per_minute=100)
        limiter = get_rate_limiter(config)
        assert limiter.config.requests_per_minute == 100
