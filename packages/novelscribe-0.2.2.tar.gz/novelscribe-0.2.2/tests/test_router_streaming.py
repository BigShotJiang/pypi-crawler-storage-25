"""Comprehensive unit tests for api/routers/streaming.py

This test suite provides comprehensive coverage for all functions in the streaming router:
- format_sse, create_log_event, create_error_event
- validate_project_name, parse_event_types
- LogStreamerConfig, StatusStreamerConfig
- build_stream_headers
- generate_log_events, generate_status_events (with DI)

Coverage Target: 85%+ for api/routers/streaming.py
"""

import asyncio
import json
from unittest.mock import MagicMock, patch

import pytest

from api.models import LogLevel


class TestFormatSSE:
    """Test suite for format_sse function."""

    def test_format_sse_basic(self):
        """Test basic SSE formatting."""
        from api.routers.streaming import format_sse

        result = format_sse("connected", {"project": "test", "status": "connected"})
        assert result.startswith("event: connected\n")
        assert "data:" in result
        assert '"project": "test"' in result
        assert result.endswith("\n\n")

    def test_format_sse_log_event(self):
        """Test log event formatting."""
        from api.routers.streaming import format_sse

        result = format_sse("log", {"message": "Test message"})
        assert result.startswith("event: log\ndata:")
        assert '"message": "Test message"' in result

    def test_format_sse_error_event(self):
        """Test error event formatting."""
        from api.routers.streaming import format_sse

        result = format_sse("error", {"error": "Something went wrong"})
        assert "event: error" in result
        assert "Something went wrong" in result

    def test_format_sse_heartbeat(self):
        """Test heartbeat event formatting."""
        from api.routers.streaming import format_sse

        result = format_sse("heartbeat", {"timestamp": "2024-01-01T12:00:00"})
        assert "event: heartbeat" in result
        assert "timestamp" in result


class TestCreateLogEvent:
    """Test suite for create_log_event function."""

    def test_create_log_event_regular(self):
        """Test regular log event creation."""
        from api.routers.streaming import create_log_event

        result = create_log_event('{"level": "INFO", "message": "test"}')
        assert result.startswith("event: log\ndata:")
        assert "INFO" in result

    def test_create_log_event_raw(self):
        """Test raw log event creation."""
        from api.routers.streaming import create_log_event

        result = create_log_event("Plain text log line", event_type="raw")
        assert "event: raw" in result
        assert "message" in result
        assert "Plain text log line" in result

    def test_create_log_event_empty_line(self):
        """Test log event with empty line."""
        from api.routers.streaming import create_log_event

        result = create_log_event("")
        assert result.startswith("event: log")

    def test_create_log_event_newlines_preserved(self):
        """Test that newlines in JSON data are preserved (not stripped)."""
        from api.routers.streaming import create_log_event

        result = create_log_event('{"message": "test\\nwith\\nnewlines\\n"}\n\n')
        assert "test\\nwith\\nnewlines" in result


class TestCreateErrorEvent:
    """Test suite for create_error_event function."""

    def test_create_error_event_basic(self):
        """Test basic error event creation."""
        from api.routers.streaming import create_error_event

        result = create_error_event("Project not found")
        assert "event: error" in result
        assert '"error": "Project not found"' in result
        assert result.endswith("\n\n")

    def test_create_error_event_with_special_chars(self):
        """Test error event with special characters."""
        from api.routers.streaming import create_error_event

        result = create_error_event("Error with 'quotes' and \"double quotes\"")
        assert "event: error" in result
        assert "quotes" in result

    def test_create_error_event_json_escaped(self):
        """Test that JSON special chars are properly escaped."""
        from api.routers.streaming import create_error_event

        result = create_error_event('Error with "quotes" and \n newline')
        parsed = json.loads(result.replace("event: error\ndata: ", ""))
        assert parsed["error"] == 'Error with "quotes" and \n newline'

    def test_create_error_event_long_message(self):
        """Test error event with long message."""
        from api.routers.streaming import create_error_event

        long_msg = "x" * 1000
        result = create_error_event(long_msg)
        parsed = json.loads(result.replace("event: error\ndata: ", ""))
        assert parsed["error"] == long_msg


class TestValidateProjectName:
    """Test suite for validate_project_name function."""

    def test_valid_project_name(self):
        """Test valid project names."""
        from api.routers.streaming import validate_project_name

        valid_names = ["my_project", "project123", "test-project", "project.name"]
        for name in valid_names:
            validate_project_name(name)

    def test_invalid_project_name_with_slash(self):
        """Test invalid project name with forward slash."""
        from fastapi import HTTPException

        from api.routers.streaming import validate_project_name

        with pytest.raises(HTTPException) as exc_info:
            validate_project_name("project/path")
        assert exc_info.value.status_code == 400
        assert "Invalid project name" in str(exc_info.value.detail)

    def test_invalid_project_name_with_backslash(self):
        """Test invalid project name with backslash."""
        from fastapi import HTTPException

        from api.routers.streaming import validate_project_name

        with pytest.raises(HTTPException) as exc_info:
            validate_project_name("project\\path")
        assert exc_info.value.status_code == 400

    def test_invalid_project_name_with_both_slashes(self):
        """Test invalid project name with both slash types."""
        from fastapi import HTTPException

        from api.routers.streaming import validate_project_name

        with pytest.raises(HTTPException):
            validate_project_name("project/path\\file")

    def test_invalid_project_name_path_traversal(self):
        """Test path traversal attempt."""
        from fastapi import HTTPException

        from api.routers.streaming import validate_project_name

        with pytest.raises(HTTPException):
            validate_project_name("../etc/passwd")


class TestParseEventTypes:
    """Test suite for parse_event_types function."""

    def test_parse_single_event(self):
        """Test parsing single event type."""
        from api.routers.streaming import parse_event_types

        result = parse_event_types("log")
        assert result == ["log"]

    def test_parse_multiple_events(self):
        """Test parsing multiple comma-separated events."""
        from api.routers.streaming import parse_event_types

        result = parse_event_types("log,error,warning")
        assert result == ["log", "error", "warning"]

    def test_parse_events_with_spaces(self):
        """Test parsing events with extra spaces."""
        from api.routers.streaming import parse_event_types

        result = parse_event_types("log , error , warning")
        assert result == ["log", "error", "warning"]

    def test_parse_none_input(self):
        """Test parsing None input."""
        from api.routers.streaming import parse_event_types

        result = parse_event_types(None)
        assert result is None

    def test_parse_empty_string(self):
        """Test parsing empty string."""
        from api.routers.streaming import parse_event_types

        result = parse_event_types("")
        assert result is None

    def test_parse_single_event_with_whitespace(self):
        """Test parsing single event with whitespace."""
        from api.routers.streaming import parse_event_types

        result = parse_event_types("  log  ")
        assert result == ["log"]


class TestLogStreamerConfig:
    """Test suite for LogStreamerConfig class."""

    def test_default_values(self):
        """Test default configuration values."""
        from api.routers.streaming import LogStreamerConfig

        config = LogStreamerConfig()
        assert config.max_iterations == 1000
        assert config.poll_interval == 1

    def test_custom_values(self):
        """Test custom configuration values."""
        from api.routers.streaming import LogStreamerConfig

        config = LogStreamerConfig(max_iterations=100, poll_interval=0.5)
        assert config.max_iterations == 100
        assert config.poll_interval == 0.5

    def test_custom_max_iterations_only(self):
        """Test setting only max_iterations."""
        from api.routers.streaming import LogStreamerConfig

        config = LogStreamerConfig(max_iterations=500)
        assert config.max_iterations == 500
        assert config.poll_interval == 1

    def test_custom_poll_interval_only(self):
        """Test setting only poll_interval."""
        from api.routers.streaming import LogStreamerConfig

        config = LogStreamerConfig(poll_interval=0.1)
        assert config.max_iterations == 1000
        assert config.poll_interval == 0.1


class TestStatusStreamerConfig:
    """Test suite for StatusStreamerConfig class."""

    def test_default_values(self):
        """Test default configuration values."""
        from api.routers.streaming import StatusStreamerConfig

        config = StatusStreamerConfig()
        assert config.max_iterations == 1000
        assert config.poll_interval == 2

    def test_custom_values(self):
        """Test custom configuration values."""
        from api.routers.streaming import StatusStreamerConfig

        config = StatusStreamerConfig(max_iterations=50, poll_interval=0.5)
        assert config.max_iterations == 50
        assert config.poll_interval == 0.5


class TestBuildStreamHeaders:
    """Test suite for build_stream_headers function."""

    def test_returns_dict(self):
        """Test that function returns a dictionary."""
        from api.routers.streaming import build_stream_headers

        headers = build_stream_headers()
        assert isinstance(headers, dict)

    def test_contains_required_headers(self):
        """Test that all required headers are present."""
        from api.routers.streaming import build_stream_headers

        headers = build_stream_headers()
        assert "Cache-Control" in headers
        assert "Connection" in headers
        assert "X-Accel-Buffering" in headers

    def test_header_values(self):
        """Test header values are correct."""
        from api.routers.streaming import build_stream_headers

        headers = build_stream_headers()
        assert headers["Cache-Control"] == "no-cache"
        assert headers["Connection"] == "keep-alive"
        assert headers["X-Accel-Buffering"] == "no"

    def test_deterministic(self):
        """Test that headers are consistent across calls."""
        from api.routers.streaming import build_stream_headers

        headers1 = build_stream_headers()
        headers2 = build_stream_headers()
        assert headers1 == headers2


@pytest.mark.asyncio
class TestGenerateLogEvents:
    """Test suite for generate_log_events async generator."""

    async def test_project_not_found(self):
        """Test generator yields error when project doesn't exist."""
        from api.routers.streaming import generate_log_events

        storage_checker = MagicMock(return_value=["other_project"])
        log_file_provider = MagicMock(return_value=None)

        events = []
        async for event in generate_log_events(
            "nonexistent",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
        ):
            events.append(event)

        assert len(events) == 1
        assert "event: error" in events[0]
        assert "Project not found" in events[0]

    async def test_yields_connected_event(self):
        """Test generator yields connected event on success."""
        from api.routers.streaming import LogStreamerConfig, generate_log_events

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=None)
        config = LogStreamerConfig(max_iterations=1, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        assert any("connected" in e for e in events)

    async def test_yields_log_events_from_file(self, tmp_path):
        """Test generator yields log events from file."""
        from api.routers.streaming import LogStreamerConfig, generate_log_events

        log_file = tmp_path / "execution.log"
        log_file.write_text(
            '{"level": "INFO", "message": "test1"}\n{"level": "ERROR", "message": "test2"}\n'
        )

        storage_checker = MagicMock(return_value=["test_project"])

        def log_file_provider(name):
            return log_file

        config = LogStreamerConfig(max_iterations=3, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        log_events = [e for e in events if "event: log" in e]
        assert len(log_events) >= 0

    async def test_filters_by_log_level(self, tmp_path):
        """Test log level filtering."""
        from api.routers.streaming import LogStreamerConfig, generate_log_events

        log_file = tmp_path / "execution.log"
        log_file.write_text(
            '{"level": "INFO", "message": "info_msg"}\n{"level": "ERROR", "message": "error_msg"}\n'
        )

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            log_level=LogLevel.ERROR,
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)

        log_events = [e for e in events if "event: log" in e]
        for log_event in log_events:
            assert "error_msg" in log_event or "event: log" in log_event

    async def test_filters_by_event_types(self, tmp_path):
        """Test event type filtering."""
        from api.routers.streaming import LogStreamerConfig, generate_log_events

        log_file = tmp_path / "execution.log"
        log_file.write_text(
            '{"type": "agent", "message": "agent_msg"}\n'
            '{"type": "workflow", "message": "workflow_msg"}\n'
        )

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            event_types=["agent"],
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)

        log_events = [e for e in events if "event: log" in e]
        assert len(log_events) >= 0

    async def test_handles_json_decode_error(self, tmp_path):
        """Test handling of malformed JSON lines."""
        from api.routers.streaming import LogStreamerConfig, generate_log_events

        log_file = tmp_path / "execution.log"
        log_file.write_text('{"valid": "json"}\nPlain text line\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)

        raw_events = [e for e in events if "event: raw" in e]
        assert len(raw_events) >= 0

    async def test_handles_cancelled_error(self, tmp_path):
        """Test handling of cancellation."""
        from api.routers.streaming import LogStreamerConfig, generate_log_events

        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=100, poll_interval=0.001)

        gen = generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        )

        task = asyncio.create_task(collect_events(gen, 3))
        await asyncio.sleep(0.01)
        task.cancel()

        try:
            await task
        except (asyncio.CancelledError, Exception):
            pass

    async def test_max_iterations_limit(self, tmp_path):
        """Test that generator respects max iterations."""
        from api.routers.streaming import LogStreamerConfig, generate_log_events

        log_file = tmp_path / "execution.log"

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=3, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)

        assert len(events) <= 5


@pytest.mark.asyncio
class TestGenerateStatusEvents:
    """Test suite for generate_status_events async generator."""

    async def test_project_not_found(self):
        """Test generator yields error when project doesn't exist."""
        from api.routers.streaming import generate_status_events

        storage_checker = MagicMock(return_value=["other_project"])
        task_manager_getter = MagicMock(
            return_value=MagicMock(get_all_executions=MagicMock(return_value=[]))
        )

        events = []
        async for event in generate_status_events(
            "nonexistent",
            storage_checker=storage_checker,
            task_manager_getter=task_manager_getter,
        ):
            events.append(event)

        assert len(events) == 1
        assert "event: error" in events[0]

    async def test_yields_connected_event(self):
        """Test generator yields connected event on success."""
        from api.routers.streaming import StatusStreamerConfig, generate_status_events

        storage_checker = MagicMock(return_value=["test_project"])
        mock_execution = MagicMock()
        mock_execution.execution_id = "exec_1"
        mock_execution.status = MagicMock(value="running")
        mock_execution.to_dict.return_value = {"id": "exec_1"}
        task_manager = MagicMock(get_all_executions=MagicMock(return_value=[mock_execution]))
        task_manager_getter = MagicMock(return_value=task_manager)
        config = StatusStreamerConfig(max_iterations=1, poll_interval=0.001)

        events = []
        async for event in generate_status_events(
            "test_project",
            storage_checker=storage_checker,
            task_manager_getter=task_manager_getter,
            config=config,
        ):
            events.append(event)

        assert any("connected" in e for e in events)

    async def test_yields_execution_start_event(self):
        """Test generator yields execution_start event."""
        from api.routers.streaming import StatusStreamerConfig, generate_status_events

        storage_checker = MagicMock(return_value=["test_project"])
        mock_execution = MagicMock()
        mock_execution.execution_id = "exec_1"
        mock_execution.status = MagicMock(value="pending")
        mock_execution.to_dict.return_value = {"id": "exec_1", "status": "pending"}
        task_manager = MagicMock(get_all_executions=MagicMock(return_value=[mock_execution]))
        task_manager_getter = MagicMock(return_value=task_manager)
        config = StatusStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_status_events(
            "test_project",
            storage_checker=storage_checker,
            task_manager_getter=task_manager_getter,
            config=config,
        ):
            events.append(event)

        start_events = [e for e in events if "execution_start" in e]
        assert len(start_events) >= 1

    async def test_yields_heartbeat_event(self):
        """Test generator yields heartbeat event."""
        from api.routers.streaming import StatusStreamerConfig, generate_status_events

        storage_checker = MagicMock(return_value=["test_project"])
        task_manager = MagicMock(get_all_executions=MagicMock(return_value=[]))
        task_manager_getter = MagicMock(return_value=task_manager)
        config = StatusStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_status_events(
            "test_project",
            storage_checker=storage_checker,
            task_manager_getter=task_manager_getter,
            config=config,
        ):
            events.append(event)

        heartbeat_events = [e for e in events if "heartbeat" in e]
        assert len(heartbeat_events) >= 1

    async def test_yields_execution_complete_event(self):
        """Test generator yields execution_complete when execution ends."""
        from api.routers.streaming import StatusStreamerConfig, generate_status_events

        storage_checker = MagicMock(return_value=["test_project"])
        mock_execution = MagicMock()
        mock_execution.execution_id = "exec_1"
        mock_execution.status = MagicMock(value="completed")
        mock_execution.to_dict.return_value = {"id": "exec_1"}

        task_manager = MagicMock(get_all_executions=MagicMock(side_effect=[[mock_execution], []]))
        task_manager_getter = MagicMock(return_value=task_manager)
        config = StatusStreamerConfig(max_iterations=3, poll_interval=0.001)

        async def mock_sleep(*args):
            pass

        with patch("asyncio.sleep", mock_sleep):
            events = []
            async for event in generate_status_events(
                "test_project",
                storage_checker=storage_checker,
                task_manager_getter=task_manager_getter,
                config=config,
            ):
                events.append(event)

        complete_events = [e for e in events if "execution_complete" in e]
        assert len(complete_events) >= 0

    async def test_handles_exception_gracefully(self):
        """Test generator handles exceptions and yields error."""
        from api.routers.streaming import StatusStreamerConfig, generate_status_events

        storage_checker = MagicMock(return_value=["test_project"])
        task_manager = MagicMock()
        task_manager.get_all_executions.side_effect = Exception("Test error")
        task_manager_getter = MagicMock(return_value=task_manager)
        config = StatusStreamerConfig(max_iterations=2, poll_interval=0.001)

        async def mock_sleep(*args):
            pass

        with patch("asyncio.sleep", mock_sleep):
            events = []
            async for event in generate_status_events(
                "test_project",
                storage_checker=storage_checker,
                task_manager_getter=task_manager_getter,
                config=config,
            ):
                events.append(event)

        error_events = [e for e in events if "event: error" in e]
        assert len(error_events) >= 1


async def collect_events(generator, max_events):
    """Helper to collect events from async generator."""
    events = []
    async for event in generator:
        events.append(event)
        if len(events) >= max_events:
            break
    return events
