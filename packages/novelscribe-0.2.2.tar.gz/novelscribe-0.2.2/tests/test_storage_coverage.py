"""Comprehensive tests for core/storage.py to increase coverage."""

from __future__ import annotations

from pathlib import Path

import pytest

from core.storage import (
    FileStorage,
    StorageConfig,
)


class TestStorageAdvanced:
    """Advanced storage tests for better coverage."""

    def test_write_yaml_with_custom_settings(self, tmp_path):
        """Test writing YAML with custom formatting."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        data = {
            "nested": {"key1": "value1", "key2": [1, 2, 3]},
            "unicode": "中文测试 🎉",
            "boolean": True,
            "number": 42.5,
        }

        storage.write_yaml("test_custom.yaml", data)
        result = storage.read_yaml("test_custom.yaml")

        assert result["nested"]["key1"] == "value1"
        assert result["nested"]["key2"] == [1, 2, 3]
        assert result["unicode"] == "中文测试 🎉"
        assert result["boolean"] is True
        assert result["number"] == 42.5

    def test_read_yaml_nonexistent_raises(self, tmp_path):
        """Test reading nonexistent YAML file."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        with pytest.raises(Exception):
            storage.read_yaml("nonexistent.yaml")

    def test_write_and_read_markdown_unicode(self, tmp_path):
        """Test handling Unicode content in markdown."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        content = "# Title\n\n内容 with émojis: 🎨 📚 ✍️\n\n中文内容"
        storage.write_markdown("unicode.md", content)
        result = storage.read_markdown("unicode.md")

        assert result == content

    def test_write_and_read_markdown_special_chars(self, tmp_path):
        """Test handling special characters in markdown."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        content = """# Special Characters Test

Code: `const x = 5;`

Links: [Click here](https://example.com)

Images: ![Alt](path/to/image.png)

Blockquotes:
> This is a quote

Lists:
- Item 1
- Item 2
  - Nested item
  - Another nested

Tables:
| Header | Header |
|--------|--------|
| Cell   | Cell   |
"""
        storage.write_markdown("special.md", content)
        result = storage.read_markdown("special.md")

        assert result == content

    def test_read_agent_with_metadata(self, tmp_path):
        """Test reading agent with metadata fields."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        agent_content = """---
name: test_agent_metadata
description: A test agent with metadata
model: gpt-4
temperature: 0.7
max_tokens: 1000
custom_field: custom_value
another_field: 123
---

You are a test agent.
"""

        agent_path = tmp_path / "test_agent.md"
        agent_path.write_text(agent_content)

        agent = storage.read_agent("test_agent.md")

        assert agent.name == "test_agent_metadata"
        assert agent.metadata["custom_field"] == "custom_value"
        assert agent.metadata["another_field"] == 123

    def test_read_workflow_with_variables(self, tmp_path):
        """Test reading workflow with variables."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        workflow_content = """name: test_workflow
version: 1.0
description: A test workflow with variables
variables:
  project_name: null
  chapter: 1
  verbose: false
steps:
  - step: 1
    name: Test step
    agent: test_agent
"""

        workflow_path = tmp_path / "test_workflow.yaml"
        workflow_path.write_text(workflow_content)

        workflow = storage.read_workflow("test_workflow.yaml")

        assert workflow.name == "test_workflow"
        assert workflow.description == "A test workflow with variables"
        assert len(workflow.steps) == 1

    def test_exists_file(self, tmp_path):
        """Test checking if file exists."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        # Create a file
        storage.write_markdown("exists.md", "content")

        assert storage.exists("exists.md") is True
        assert storage.exists("nonexistent.md") is False

    def test_exists_directory(self, tmp_path):
        """Test checking if directory exists."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        # Create a subdirectory
        (Path(tmp_path) / "subdir").mkdir()

        assert storage.exists("subdir") is True

    def test_delete_file(self, tmp_path):
        """Test deleting a file."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        # Create and delete
        storage.write_markdown("to_delete.md", "content")
        assert storage.exists("to_delete.md") is True

        storage.delete("to_delete.md")
        assert storage.exists("to_delete.md") is False

    def test_delete_directory(self, tmp_path):
        """Test deleting a directory."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        # Create subdirectory
        subdir_path = Path(tmp_path) / "subdir"
        subdir_path.mkdir()
        (subdir_path / "file.md").write_text("content")

        assert storage.exists("subdir") is True

        storage.delete("subdir")
        assert storage.exists("subdir") is False

    def test_list_files_empty_directory(self, tmp_path):
        """Test listing files in empty directory."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        files = storage.list_files(".")
        assert isinstance(files, list)

    def test_list_files_with_pattern(self, tmp_path):
        """Test listing files with pattern."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        # Create test files
        storage.write_markdown("test1.md", "content1")
        storage.write_markdown("test2.md", "content2")
        storage.write_markdown("other.txt", "content")

        md_files = storage.list_files(".", "*.md")
        txt_files = storage.list_files(".", "*.txt")

        assert len(md_files) >= 2
        assert len(txt_files) >= 1

    def test_list_files_nonexistent_directory(self, tmp_path):
        """Test listing files in nonexistent directory."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        files = storage.list_files("nonexistent")
        assert files == []

    def test_read_invalid_yaml_format(self, tmp_path):
        """Test reading invalid YAML format."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        # Create invalid YAML
        invalid_yaml = Path(tmp_path) / "invalid.yaml"
        invalid_yaml.write_text("key: [unclosed list")

        with pytest.raises(Exception):
            storage.read_yaml("invalid.yaml")

    def test_read_agent_missing_frontmatter(self, tmp_path):
        """Test reading agent without frontmatter."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        # Create agent without frontmatter
        agent_path = tmp_path / "no_frontmatter.md"
        agent_path.write_text("No frontmatter content")

        with pytest.raises(Exception):
            storage.read_agent("no_frontmatter.md")

    def test_read_agent_missing_required_field(self, tmp_path):
        """Test reading agent with missing required field."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        # Create agent missing description
        agent_content = """---
name: test_agent
model: gpt-4
---

Content
"""
        agent_path = tmp_path / "missing_field.md"
        agent_path.write_text(agent_content)

        with pytest.raises(Exception):
            storage.read_agent("missing_field.md")

    def test_read_workflow_missing_required_field(self, tmp_path):
        """Test reading workflow with missing required field."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        # Create workflow missing steps
        workflow_content = """name: incomplete_workflow
description: Missing steps
"""
        workflow_path = tmp_path / "incomplete.yaml"
        workflow_path.write_text(workflow_content)

        with pytest.raises(Exception):
            storage.read_workflow("incomplete.yaml")

    def test_read_workflow_invalid_steps_format(self, tmp_path):
        """Test reading workflow with invalid steps format."""
        config = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(config)

        # Create workflow with invalid steps (not a list)
        workflow_content = """name: invalid_workflow
description: Invalid steps
steps: not_a_list
"""
        workflow_path = tmp_path / "invalid_workflow.yaml"
        workflow_path.write_text(workflow_content)

        with pytest.raises(Exception):
            storage.read_workflow("invalid_workflow.yaml")
