"""
Unit tests for CLI agent commands.

Tests for cli_agents.py including:
- agents list command
- agents show command
- Error handling
- Command structure
"""

import subprocess
import sys
from pathlib import Path

import pytest
from click.testing import CliRunner

from cli_agents import agents


class TestAgentsCommandStructure:
    """Tests for agents command structure."""

    def test_agents_command_group_exists(self):
        """Test that agents command group is defined."""
        from cli_agents import agents

        assert agents is not None, "agents command group should exist"
        assert hasattr(agents, "commands"), "Should have commands attribute"

    def test_agents_list_command_exists(self):
        """Test that agents list command exists."""
        runner = CliRunner()
        result = runner.invoke(agents, ["--help"])

        assert "list" in result.output, "Should have 'list' command"
        assert "show" in result.output, "Should have 'show' command"

    def test_agents_show_command_requires_agent_name(self):
        """Test that agents show requires an agent name argument."""
        runner = CliRunner()
        result = runner.invoke(agents, ["show"])

        # Should fail without agent name
        assert result.exit_code != 0, "Should require agent name"

    def test_agents_registered_in_main_cli(self):
        """Test that agents is registered in main CLI."""
        from cli import cli

        assert "agents" in cli.commands, "agents should be registered in main CLI"


class TestAgentsCommandWithRealFiles:
    """Tests using actual agent files."""

    def test_agents_directory_exists(self):
        """Test that agents directory exists."""
        import agents as agents_pkg

        agents_dir = Path(agents_pkg.__file__).parent

        assert agents_dir.exists(), "Agents directory should exist"
        assert agents_dir.is_dir(), "Should be a directory"

    def test_agents_have_md_files(self):
        """Test that agents directory contains .md files."""
        import agents as agents_pkg

        agents_dir = Path(agents_pkg.__file__).parent / "en"

        md_files = list(agents_dir.glob("*.md"))
        assert len(md_files) >= 12, f"Should have at least 12 .md files, found {len(md_files)}"

    def test_known_agent_files_exist(self):
        """Test that known agent files exist."""
        import agents as agents_pkg

        agents_dir = Path(agents_pkg.__file__).parent / "en"

        known_agents = [
            "writer_agent.md",
            "outline_agent.md",
            "character_agent.md",
            "world_agent.md",
        ]

        for agent_file in known_agents:
            agent_path = agents_dir / agent_file
            assert agent_path.exists(), f"Agent file {agent_file} should exist"


class TestAgentsCommandIntegration:
    """Integration tests using subprocess."""

    def test_agents_list_via_subprocess(self):
        """Test agents list via subprocess."""
        result = subprocess.run(
            [sys.executable, "-m", "cli", "agents", "list"],
            capture_output=True,
            text=True,
            cwd=Path(__file__).parent.parent,
        )

        # Should not crash
        assert result.returncode in [0, 1], "Should not crash"

    def test_agents_show_via_subprocess(self):
        """Test agents show via subprocess."""
        result = subprocess.run(
            [sys.executable, "-m", "cli", "agents", "show", "writer_agent"],
            capture_output=True,
            text=True,
            cwd=Path(__file__).parent.parent,
        )

        # Should not crash
        assert result.returncode in [0, 1], "Should not crash"


class TestAgentsCommandErrorHandling:
    """Tests for error handling."""

    def test_agents_show_with_nonexistent_agent(self):
        """Test showing nonexistent agent via subprocess."""
        result = subprocess.run(
            [sys.executable, "-m", "cli", "agents", "show", "nonexistent_agent_xyz"],
            capture_output=True,
            text=True,
            cwd=Path(__file__).parent.parent,
        )

        # Should fail
        assert result.returncode != 0, "Should fail for nonexistent agent"

    def test_agents_show_with_empty_name(self):
        """Test showing agent with empty name."""
        runner = CliRunner()
        result = runner.invoke(agents, ["show", ""])

        # Should handle gracefully
        assert result.exit_code != 0 or result.exception


class TestAgentsOutputDoesNotCrash:
    """Tests that commands don't crash."""

    def test_agents_list_does_not_crash(self):
        """Test that list command doesn't crash."""
        runner = CliRunner()
        result = runner.invoke(agents, ["list"])

        # Should not have unhandled exceptions
        assert result.exception is None or isinstance(result.exception, SystemExit), (
            f"Should not crash with exception: {result.exception}"
        )

    def test_agents_show_does_not_crash(self):
        """Test that show command doesn't crash."""
        runner = CliRunner()
        result = runner.invoke(agents, ["show", "writer_agent"])

        # Should not have unhandled exceptions
        assert result.exception is None or isinstance(result.exception, SystemExit), (
            f"Should not crash with exception: {result.exception}"
        )


class TestAgentsLoaderIntegration:
    """Tests for AgentLoader integration."""

    def test_agent_loader_can_load_agents(self):
        """Test that AgentLoader can load all agents."""
        import agents as agents_pkg

        agents_dir = Path(agents_pkg.__file__).parent
        from core.agent_loader import AgentLoader

        loader = AgentLoader(str(agents_dir))
        loaded_agents = loader.load_all_agents()

        assert len(loaded_agents) >= 12, f"Should load at least 12 agents, got {len(loaded_agents)}"

    def test_agent_loader_finds_known_agents(self):
        """Test that AgentLoader finds known agents."""
        import agents as agents_pkg

        agents_dir = Path(agents_pkg.__file__).parent
        from core.agent_loader import AgentLoader

        loader = AgentLoader(str(agents_dir))
        loaded_agents = loader.load_all_agents()

        agent_names = [agent.name for agent in loaded_agents]

        # Should find known agents
        assert "writer_agent" in agent_names, "Should find writer_agent"
        assert "outline_agent" in agent_names, "Should find outline_agent"
        assert "character_agent" in agent_names, "Should find character_agent"


class TestAgentsDocumentation:
    """Tests for agent documentation."""

    def test_agents_have_help_text(self):
        """Test that agents command has help text."""
        runner = CliRunner()
        result = runner.invoke(agents, ["--help"])

        assert result.exit_code == 0, "Help should succeed"
        assert len(result.output) > 0, "Should have help output"
        assert "agents" in result.output.lower(), "Should mention agents"

    def test_agents_list_has_help(self):
        """Test that agents list has help."""
        runner = CliRunner()
        result = runner.invoke(agents, ["list", "--help"])

        assert result.exit_code == 0, "Help should succeed"
        assert len(result.output) > 0, "Should have help output"

    def test_agents_show_has_help(self):
        """Test that agents show has help."""
        runner = CliRunner()
        result = runner.invoke(agents, ["show", "--help"])

        assert result.exit_code == 0, "Help should succeed"
        assert len(result.output) > 0, "Should have help output"
        assert "AGENT_NAME" in result.output, "Should document AGENT_NAME argument"


@pytest.fixture
def temp_agent_file(tmp_path):
    """Create temporary agent file for testing."""
    agents_dir = tmp_path / "agents"
    agents_dir.mkdir()

    agent_file = agents_dir / "temp_test_agent.md"
    agent_file.write_text("""---
name: temp_test_agent
version: 1.0.0
description: Temporary test agent
category: analytical
input:
  - test_input
output:
  - test_output
dependencies: []
---

# Test Agent
""")

    return agent_file


class TestAgentsWithFixtures:
    """Tests with custom fixtures."""

    def test_temp_agent_file_is_valid(self, temp_agent_file):
        """Test that temp agent file has valid format."""
        from core.agent_loader import AgentLoader

        loader = AgentLoader(str(temp_agent_file.parent))
        agents = loader.load_all_agents()

        assert any(a.name == "temp_test_agent" for a in agents), "Should load temp_test_agent"

    def test_temp_agent_has_required_fields(self, temp_agent_file):
        """Test that temp agent has required fields."""
        from core.agent_loader import AgentLoader

        loader = AgentLoader(str(temp_agent_file.parent))
        agents = loader.load_all_agents()

        test_agent = next((a for a in agents if a.name == "temp_test_agent"), None)

        assert test_agent is not None, "Should find temp_test_agent"
        assert test_agent.category == "analytical", "Should have category"
        assert len(test_agent.input_schema) > 0, "Should have inputs"
        assert len(test_agent.output_schema) > 0, "Should have outputs"
