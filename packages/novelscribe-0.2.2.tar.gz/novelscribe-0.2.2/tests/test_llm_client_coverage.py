"""Comprehensive tests for core/llm_client.py to increase coverage."""

from __future__ import annotations

import pytest

from core.llm_client import LLMClientFactory, LLMConfig, LLMError, LLMResponse


class TestLLMClientFactory:
    """Test LLM client factory."""

    def test_create_openai_client(self):
        """Test creating OpenAI client."""
        config = LLMConfig(provider="openai", model="gpt-4")
        client = LLMClientFactory.create(config)
        assert client is not None

    def test_create_with_custom_model(self):
        """Test creating client with custom model."""
        config = LLMConfig(provider="openai", model="gpt-4")
        client = LLMClientFactory.create(config)
        assert client is not None

    def test_create_unknown_provider(self):
        """Test creating client with unknown provider."""
        config = LLMConfig(provider="unknown")
        with pytest.raises(Exception):
            LLMClientFactory.create(config)


class TestLLMConfig:
    """Test LLM configuration."""

    def test_default_config(self):
        """Test default configuration."""
        config = LLMConfig()
        assert config.provider == "openai"
        assert config.model == "gpt-4o"
        assert config.temperature == 0.7

    def test_custom_config(self):
        """Test custom configuration."""
        config = LLMConfig(provider="openai", model="gpt-4", temperature=0.5, max_tokens=4000)
        assert config.provider == "openai"
        assert config.model == "gpt-4"
        assert config.temperature == 0.5
        assert config.max_tokens == 4000

    def test_config_with_api_key(self):
        """Test configuration with API key."""
        config = LLMConfig(api_key="test-key")
        assert config.api_key == "test-key"

    def test_config_with_base_url(self):
        """Test configuration with base URL."""
        config = LLMConfig(base_url="https://custom.api.com")
        assert config.base_url == "https://custom.api.com"

    def test_config_with_timeout(self):
        """Test configuration with timeout."""
        config = LLMConfig(timeout=120)
        assert config.timeout == 120

    def test_config_with_streaming(self):
        """Test configuration with streaming."""
        config = LLMConfig(streaming=True)
        assert config.streaming is True


class TestLLMResponse:
    """Test LLM response."""

    def test_create_response(self):
        """Test creating LLM response."""
        response = LLMResponse(
            content="Test response", model="gpt-4", provider="openai", tokens_used=30
        )
        assert response.content == "Test response"
        assert response.model == "gpt-4"
        assert response.provider == "openai"
        assert response.tokens_used == 30

    def test_response_with_finish_reason(self):
        """Test response with finish reason."""
        response = LLMResponse(
            content="Response with finish", model="gpt-4", provider="openai", finish_reason="stop"
        )
        assert response.finish_reason == "stop"

    def test_response_with_no_tokens(self):
        """Test response with no tokens."""
        response = LLMResponse(content="Response", model="gpt-4", provider="openai")
        assert response.tokens_used is None


class TestLLMError:
    """Test LLM error handling."""

    def test_create_error(self):
        """Test creating LLM error."""
        error = LLMError("Test error")
        assert str(error) == "Test error"

    def test_error_string_representation(self):
        """Test error string representation."""
        error = LLMError("API error occurred")
        assert "API error occurred" in str(error)
