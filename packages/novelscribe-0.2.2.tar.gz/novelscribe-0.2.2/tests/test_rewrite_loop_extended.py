"""
Comprehensive tests for rewrite_loop.py to increase coverage to 100%.
Tests rewrite loop execution and iteration management.
"""

from novel_harness.core.rewrite_loop import (
    IterationStatus,
    RewriteConfig,
    RewriteIteration,
    RewriteLoopExecutor,
)


class TestIterationStatus:
    """Test IterationStatus enum."""

    def test_all_statuses(self):
        """Test all iteration statuses exist."""
        assert IterationStatus.PENDING.value == "pending"
        assert IterationStatus.IN_PROGRESS.value == "in_progress"
        assert IterationStatus.PASSED.value == "passed"
        assert IterationStatus.FAILED.value == "failed"
        assert IterationStatus.MAX_LIMIT_REACHED.value == "max_limit_reached"
        assert IterationStatus.STOPPED.value == "stopped"


class TestRewriteConfig:
    """Test RewriteConfig model."""

    def test_default_config(self):
        """Test default configuration."""
        config = RewriteConfig()

        assert config.max_iterations == 5
        assert config.stop_on_passed is True

    def test_custom_config(self):
        """Test custom configuration."""
        config = RewriteConfig(
            max_iterations=10,
            stop_on_passed=False,
        )

        assert config.max_iterations == 10
        assert config.stop_on_passed is False


class TestRewriteIteration:
    """Test RewriteIteration model."""

    def test_iteration_creation(self):
        """Test creating a rewrite iteration."""
        iteration = RewriteIteration(
            iteration_number=1,
            status=IterationStatus.PENDING,
        )

        assert iteration.iteration_number == 1
        assert iteration.status == IterationStatus.PENDING
        assert iteration.issues_fixed == 0

    def test_iteration_with_all_fields(self):
        """Test iteration with all fields."""
        iteration = RewriteIteration(
            iteration_number=2,
            status=IterationStatus.PASSED,
            issues_fixed=5,
            issues_after=0,
            critical_after=0,
            major_after=0,
            minor_after=0,
            content="Fixed content",
            fixes_applied=3,
            issues_before=8,
            execution_time=10.5,
        )

        assert iteration.iteration_number == 2
        assert iteration.status == IterationStatus.PASSED
        assert iteration.issues_fixed == 5
        assert iteration.content == "Fixed content"
        assert iteration.execution_time == 10.5

    def test_iteration_with_default_values(self):
        """Test iteration with default values."""
        iteration = RewriteIteration(
            iteration_number=1,
            status=IterationStatus.IN_PROGRESS,
        )

        assert iteration.issues_fixed == 0
        assert iteration.issues_after == 0
        assert iteration.critical_after == 0
        assert iteration.major_after == 0
        assert iteration.minor_after == 0
        assert iteration.content == ""
        assert iteration.fixes_applied == 0
        assert iteration.execution_time == 0.0
        assert iteration.timestamp is not None


class TestRewriteLoopExecutor:
    """Test RewriteLoopExecutor class."""

    def test_init(self):
        """Test initialization."""
        config = RewriteConfig(max_iterations=10)
        executor = RewriteLoopExecutor("/path/to/project", config)

        assert executor.project_dir == "/path/to/project"
        assert executor.config.max_iterations == 10
        assert executor.iterations == []

    def test_init_with_defaults(self):
        """Test initialization with default config."""
        executor = RewriteLoopExecutor("/path/to/project", RewriteConfig())

        assert executor.project_dir == "/path/to/project"
        assert executor.config.max_iterations == 5
        assert executor.iterations == []

    def test_execute_loop(self):
        """Test executing loop."""
        config = RewriteConfig()
        executor = RewriteLoopExecutor("/path/to/project", config)

        result = executor.execute_loop()

        assert result.iteration_number == 1
        assert result.status == IterationStatus.PASSED
        assert result.issues_after == 0
        assert len(executor.iterations) == 1

    def test_execute_loop_records_iteration(self):
        """Test that execute_loop records iteration."""
        config = RewriteConfig()
        executor = RewriteLoopExecutor("/path/to/project", config)

        executor.execute_loop()

        assert len(executor.iterations) == 1
        assert executor.iterations[0].iteration_number == 1
