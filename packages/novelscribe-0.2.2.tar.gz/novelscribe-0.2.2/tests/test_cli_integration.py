"""Integration tests for CLI commands."""

from __future__ import annotations

from unittest.mock import patch

from click.testing import CliRunner


class TestCLINewCommand:
    """Test scribe new command."""

    def test_new_command_success(self, tmp_path):
        """Test successful project creation."""
        from cli import cli

        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(cli, ["new", "test-novel", "--provider", "openai"])

            # Should not fail at least (may fail due to missing API key, but shouldn't crash)
            # The command should create the project structure
            assert result.exit_code in [0, 1]  # 0 if works, 1 if API key missing

    def test_new_command_with_model(self, tmp_path):
        """Test new command with custom model."""
        from cli import cli

        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(
                cli, ["new", "test-novel", "--provider", "openai", "--model", "gpt-4"]
            )

            # Should not crash
            assert result.exit_code in [0, 1]


class TestCLIOutlineCommand:
    """Test scribe outline command."""

    def test_outline_command_missing_project(self):
        """Test outline command with missing project."""
        from cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["outline", "nonexistent-novel"])

        # Should fail with helpful message
        assert result.exit_code == 1
        assert "not found" in result.output.lower() or "Create it first" in result.output

    def test_outline_command_with_options(self):
        """Test outline command with various options."""
        from cli import cli

        runner = CliRunner()
        result = runner.invoke(
            cli, ["outline", "nonexistent-novel", "--provider", "openai", "--model", "gpt-4"]
        )

        # Should fail with missing project error
        assert result.exit_code == 1


class TestCLIWriteCommand:
    """Test scribe write command."""

    def test_write_command_missing_project(self):
        """Test write command with missing project."""
        from cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["write", "nonexistent-novel", "--chapter", "1"])

        # Should fail with helpful message
        assert result.exit_code == 1
        assert "not found" in result.output.lower() or "Create it first" in result.output


class TestCLIVersionCommands:
    """Test version-related CLI commands."""

    def test_version_flag(self):
        """Test --version flag."""
        import re

        from cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["--version"])

        # Should show version in format X.Y.Z
        assert result.exit_code == 0
        version_pattern = r"\d+\.\d+\.\d+"
        assert re.search(version_pattern, result.output) or "novelscribe" in result.output.lower()

    def test_version_info_command(self):
        """Test version info command."""
        from cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["version", "info"])

        # Should show version info
        assert result.exit_code == 0
        assert "version" in result.output.lower() or "NovelScribe" in result.output

    def test_version_check_command(self):
        """Test version check command."""
        from cli import cli

        runner = CliRunner()
        with patch("core.version.VersionManager.check_for_updates") as mock_check:
            mock_check.return_value = {
                "current": "0.1.0",
                "latest": "0.1.0",
                "update_available": False,
            }
            result = runner.invoke(cli, ["version", "check"])

            # Should check for updates
            assert result.exit_code == 0


class TestCLIHelpCommand:
    """Test help-related commands."""

    def test_help_flag(self):
        """Test --help flag."""
        from cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])

        assert result.exit_code == 0
        assert "NovelScribe" in result.output or "scribe" in result.output

    def test_help_for_subcommand(self):
        """Test help for specific subcommand."""
        from cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["new", "--help"])

        assert result.exit_code == 0
        assert "PROJECT_NAME" in result.output or "project_name" in result.output


class TestCLIWorkflowCommands:
    """Test workflow-related commands."""

    def test_workflows_list_command(self):
        """Test workflows list command."""
        from cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["workflows", "list"])

        # Exit code 1 means directory not found (expected in test environment)
        # Exit code 0 means successfully listed workflows
        assert result.exit_code in [0, 1]  # Accept both success and missing directory

    def test_agents_list_command(self):
        """Test agents list command."""
        from cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["agents", "list"])

        # Exit code 1 means directory not found (expected in test environment)
        # Exit code 0 means successfully listed agents
        assert result.exit_code in [0, 1]  # Accept both success and missing directory
