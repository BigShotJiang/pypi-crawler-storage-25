"""
Tests for CLI drafts commands
"""

from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from cli_drafts import (
    drafts,
)


class TestDraftsGroup:
    """Test cases for drafts command group"""

    def test_drafts_group_exists(self):
        """Test that drafts command group exists"""
        assert drafts is not None

    def test_drafts_help(self):
        """Test drafts command help"""
        runner = CliRunner()
        result = runner.invoke(drafts, ["--help"])

        assert result.exit_code == 0
        assert "drafts" in result.output.lower()


class TestRegenerateCommand:
    """Test cases for regenerate command"""

    def test_regenerate_missing_project_name(self):
        """Test regenerate command without project name"""
        runner = CliRunner()
        result = runner.invoke(drafts, ["regenerate"])

        assert result.exit_code != 0

    def test_regenerate_project_not_found(self):
        """Test regenerate command with non-existent project"""
        runner = CliRunner()

        with patch("cli_drafts.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = False
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(drafts, ["regenerate", "test-project", "--chapter", "1"])

            assert result.exit_code == 1

    def test_regenerate_with_defaults(self):
        """Test regenerate command with default options"""
        runner = CliRunner()

        with (
            patch("cli_drafts.Path") as mock_path,
            patch("cli_drafts.ChapterRegenerator") as mock_regenerator_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_result = MagicMock()
            mock_result.success = True
            mock_result.new_version = 2
            mock_result.words_changed = 150
            mock_result.content_similarity = 0.85
            mock_result.quality_score = 0.92
            mock_result.issues_resolved = ["grammar", "flow"]

            mock_regenerator = MagicMock()
            mock_regenerator.regenerate.return_value = mock_result
            mock_regenerator_class.return_value = mock_regenerator

            result = runner.invoke(drafts, ["regenerate", "test-project", "--chapter", "1"])

            assert result.exit_code in [0, 1]

    def test_regenerate_with_strategy(self):
        """Test regenerate command with strategy option"""
        runner = CliRunner()

        with (
            patch("cli_drafts.Path") as mock_path,
            patch("cli_drafts.ChapterRegenerator") as mock_regenerator_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_result = MagicMock()
            mock_result.success = True
            mock_result.new_version = 3
            mock_result.words_changed = 200
            mock_result.content_similarity = 0.75
            mock_result.quality_score = 0.88
            mock_result.issues_resolved = []

            mock_regenerator = MagicMock()
            mock_regenerator.regenerate.return_value = mock_result
            mock_regenerator_class.return_value = mock_regenerator

            result = runner.invoke(
                drafts, ["regenerate", "test-project", "--chapter", "2", "--strategy", "targeted"]
            )

            assert result.exit_code in [0, 1]

    def test_regenerate_failure(self):
        """Test regenerate command with failure"""
        runner = CliRunner()

        with (
            patch("cli_drafts.Path") as mock_path,
            patch("cli_drafts.ChapterRegenerator") as mock_regenerator_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_result = MagicMock()
            mock_result.success = False
            mock_result.new_issues = ["Issue 1", "Issue 2"]

            mock_regenerator = MagicMock()
            mock_regenerator.regenerate.return_value = mock_result
            mock_regenerator_class.return_value = mock_regenerator

            result = runner.invoke(drafts, ["regenerate", "test-project", "--chapter", "1"])

            assert result.exit_code == 1


class TestListCommand:
    """Test cases for list command"""

    def test_list_missing_project_name(self):
        """Test list command without project name"""
        runner = CliRunner()
        result = runner.invoke(drafts, ["list"])

        assert result.exit_code != 0

    def test_list_with_chapter(self):
        """Test list command with chapter option"""
        runner = CliRunner()

        with (
            patch("cli_drafts.Path") as mock_path,
            patch("cli_drafts.DraftManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_version = MagicMock()
            mock_version.version = 1
            mock_version.status = "active"
            mock_version.regeneration_reason = "initial"
            mock_version.word_count = 1000
            mock_version.quality_score = 0.9
            mock_version.timestamp.strftime.return_value = "2024-01-01 12:00"
            mock_version.parent_version = None

            mock_manager = MagicMock()
            mock_manager.list_versions.return_value = [mock_version]
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(drafts, ["list", "test-project", "--chapter", "1"])

            assert result.exit_code in [0, 1]

    def test_list_all_chapters(self):
        """Test list command without chapter option"""
        runner = CliRunner()

        with (
            patch("cli_drafts.Path") as mock_path,
            patch("cli_drafts.DraftManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_manager = MagicMock()
            mock_manager.get_project_summary.return_value = {
                "total_chapters": 10,
                "total_drafts": 25,
                "total_words": 25000,
            }
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(drafts, ["list", "test-project"])

            assert result.exit_code in [0, 1]


class TestShowCommand:
    """Test cases for show command"""

    def test_show_missing_project_name(self):
        """Test show command without project name"""
        runner = CliRunner()
        result = runner.invoke(drafts, ["show"])

        assert result.exit_code != 0

    def test_show_with_chapter_and_version(self):
        """Test show command with chapter and version"""
        runner = CliRunner()

        with (
            patch("cli_drafts.Path") as mock_path,
            patch("cli_drafts.DraftManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_metadata = MagicMock()
            mock_metadata.version = 2
            mock_metadata.status.value = "active"
            mock_metadata.regeneration_reason = "improvement"
            mock_metadata.word_count = 1500
            mock_metadata.quality_score = 0.92
            mock_metadata.timestamp.strftime.return_value = "2024-01-01 12:00:00"

            mock_manager = MagicMock()
            mock_manager.get_version.return_value = mock_metadata
            mock_manager.get_version_content.return_value = "Chapter content here"
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(
                drafts, ["show", "test-project", "--chapter", "1", "--version", "2"]
            )

            assert result.exit_code in [0, 1]


class TestCompareCommand:
    """Test cases for compare command"""

    def test_compare_missing_project_name(self):
        """Test compare command without project name"""
        runner = CliRunner()
        result = runner.invoke(drafts, ["compare"])

        assert result.exit_code != 0

    def test_compare_success(self):
        """Test compare command success"""
        runner = CliRunner()

        with (
            patch("cli_drafts.Path") as mock_path,
            patch("cli_drafts.VersionComparator") as mock_comparator_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_report = MagicMock()
            mock_report.summary = "Version comparison summary"
            mock_report.recommendations = ["Keep version 2"]
            mock_report.quality_impact = "positive"

            mock_comparator = MagicMock()
            mock_comparator.generate_diff_report.return_value = mock_report
            mock_comparator_class.return_value = mock_comparator

            result = runner.invoke(
                drafts,
                ["compare", "test-project", "--chapter", "1", "--from", "1", "--to", "2"],
            )

            assert result.exit_code in [0, 1]


class TestRollbackCommand:
    """Test cases for rollback command"""

    def test_rollback_missing_project_name(self):
        """Test rollback command without project name"""
        runner = CliRunner()
        result = runner.invoke(drafts, ["rollback"])

        assert result.exit_code != 0

    def test_rollback_success(self):
        """Test rollback command success"""
        runner = CliRunner()

        with (
            patch("cli_drafts.Path") as mock_path,
            patch("cli_drafts.RollbackManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_validation = MagicMock()
            mock_validation.can_rollback = True
            mock_validation.warnings = []
            mock_validation.dependency_issues = []

            mock_result = MagicMock()
            mock_result.success = True
            mock_result.from_version = 3
            mock_result.to_version = 2
            mock_result.backup_created = True
            mock_result.backup_path = "/backup/path"

            mock_manager = MagicMock()
            mock_manager.validate_rollback.return_value = mock_validation
            mock_manager.rollback.return_value = mock_result
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(
                drafts, ["rollback", "test-project", "--chapter", "1", "--to-version", "2"]
            )

            assert result.exit_code in [0, 1]

    def test_rollback_with_force(self):
        """Test rollback command with force option"""
        runner = CliRunner()

        with (
            patch("cli_drafts.Path") as mock_path,
            patch("cli_drafts.RollbackManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_validation = MagicMock()
            mock_validation.can_rollback = False
            mock_validation.reasons = ["Issue 1"]
            mock_validation.warnings = []
            mock_validation.dependency_issues = []

            mock_result = MagicMock()
            mock_result.success = True

            mock_manager = MagicMock()
            mock_manager.validate_rollback.return_value = mock_validation
            mock_manager.rollback.return_value = mock_result
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(
                drafts,
                ["rollback", "test-project", "--chapter", "1", "--to-version", "2", "--force"],
            )

            assert result.exit_code in [0, 1]


class TestArchiveCommand:
    """Test cases for archive command"""

    def test_archive_missing_project_name(self):
        """Test archive command without project name"""
        runner = CliRunner()
        result = runner.invoke(drafts, ["archive"])

        assert result.exit_code != 0

    def test_archive_with_chapter(self):
        """Test archive command with chapter option"""
        runner = CliRunner()

        with (
            patch("cli_drafts.Path") as mock_path,
            patch("cli_drafts.DraftManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_manager = MagicMock()
            mock_manager.archive_old_versions.return_value = 5
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(
                drafts, ["archive", "test-project", "--chapter", "1", "--keep-recent", "3"]
            )

            assert result.exit_code in [0, 1]

    def test_archive_all_chapters(self):
        """Test archive command without chapter option"""
        runner = CliRunner()

        with (
            patch("cli_drafts.Path") as mock_path,
            patch("cli_drafts.DraftManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_manager = MagicMock()
            mock_manager.get_project_summary.return_value = {
                "total_chapters": 10,
                "total_drafts": 30,
                "total_words": 30000,
                "chapters": [
                    {"chapter_number": 1},
                    {"chapter_number": 2},
                ],
            }
            mock_manager.archive_old_versions.return_value = 3
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(drafts, ["archive", "test-project", "--keep-recent", "5"])

            assert result.exit_code in [0, 1]
