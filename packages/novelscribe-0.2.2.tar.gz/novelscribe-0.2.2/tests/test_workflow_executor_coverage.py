"""Coverage tests for workflow_executor.py to increase coverage to 90%+."""

from unittest.mock import Mock

import pytest

from core.workflow_executor import WorkflowExecutor


@pytest.fixture
def mock_dependencies():
    """Create mock dependencies for WorkflowExecutor."""
    agent_integration = Mock()
    storage = Mock()
    git_manager = Mock()

    return {
        "agent_integration": agent_integration,
        "storage": storage,
        "git_manager": git_manager,
    }


@pytest.fixture
def workflows_dir(tmp_path):
    """Create a temporary workflows directory."""
    workflows_dir = tmp_path / "workflows"
    workflows_dir.mkdir()
    return workflows_dir


@pytest.fixture
def workflow_executor(workflows_dir, mock_dependencies):
    """Create a WorkflowExecutor instance for testing."""
    return WorkflowExecutor(
        workflows_dir=workflows_dir,
        agent_integration=mock_dependencies["agent_integration"],
        storage=mock_dependencies["storage"],
        git_manager=mock_dependencies["git_manager"],
        work_dir=str(workflows_dir),
    )


class TestWorkflowExecutorCoverage:
    """Test WorkflowExecutor for full coverage."""

    def test_execute_workflow_success(self, workflow_executor, workflows_dir):
        """Test successful workflow execution."""
        # Create a simple workflow file
        workflow_content = """
name: test_workflow
version: "1.0"
description: Test workflow
variables:
  test_var: value
steps:
  - step: 1
    name: step1
    agent: writer
"""
        (workflows_dir / "test_workflow.yaml").write_text(workflow_content)

        # Mock step executor to return success
        workflow_executor.step_executor.execute_step = Mock(
            return_value={
                "success": True,
                "output": {"result": "success"},
                "skipped": False,
            }
        )

        result = workflow_executor.execute_workflow(
            workflow_name="test_workflow",
            project_name="test_project",
            variables={"custom_var": "custom_value"},
            config={"model": "gpt-4"},
        )

        assert result["success"] is True
        assert result["workflow"] == "test_workflow"
        assert len(result["executed_steps"]) == 1
        assert len(result["failed_steps"]) == 0

    def test_execute_workflow_with_skipped_step(self, workflow_executor, workflows_dir):
        """Test workflow execution with skipped step."""
        workflow_content = """
name: test_workflow
version: "1.0"
description: Test workflow
variables: {}
steps:
  - step: 1
    name: step1
    agent: writer
"""
        (workflows_dir / "test_workflow.yaml").write_text(workflow_content)

        workflow_executor.step_executor.execute_step = Mock(
            return_value={
                "success": True,
                "output": {"result": "success"},
                "skipped": True,
            }
        )

        result = workflow_executor.execute_workflow(
            workflow_name="test_workflow",
            project_name="test_project",
            variables={},
            config={},
        )

        assert result["success"] is True
        assert len(result["executed_steps"]) == 1

    def test_execute_workflow_with_failed_step(self, workflow_executor, workflows_dir):
        """Test workflow execution with failed step."""
        workflow_content = """
name: test_workflow
version: "1.0"
description: Test workflow
variables: {}
steps:
  - step: 1
    name: step1
    agent: writer
"""
        (workflows_dir / "test_workflow.yaml").write_text(workflow_content)

        workflow_executor.step_executor.execute_step = Mock(
            return_value={
                "success": False,
                "output": {},
                "skipped": False,
            }
        )

        result = workflow_executor.execute_workflow(
            workflow_name="test_workflow",
            project_name="test_project",
            variables={},
            config={},
        )

        assert result["success"] is False
        assert len(result["failed_steps"]) == 1

    def test_execute_workflow_with_multiple_steps(self, workflow_executor, workflows_dir):
        """Test workflow execution with multiple steps."""
        workflow_content = """
name: test_workflow
version: "1.0"
description: Test workflow
variables: {}
steps:
  - step: 1
    name: step1
    agent: writer
  - step: 2
    name: step2
    agent: reviewer
"""
        (workflows_dir / "test_workflow.yaml").write_text(workflow_content)

        call_count = [0]

        def mock_execute_step(*args, **kwargs):
            call_count[0] += 1
            return {
                "success": True,
                "output": {"step": call_count[0]},
                "skipped": False,
            }

        workflow_executor.step_executor.execute_step = Mock(side_effect=mock_execute_step)

        result = workflow_executor.execute_workflow(
            workflow_name="test_workflow",
            project_name="test_project",
            variables={},
            config={},
        )

        assert result["success"] is True
        assert len(result["executed_steps"]) == 2
        assert result["step_outputs"]["step1"]["step"] == 1
        assert result["step_outputs"]["step2"]["step"] == 2

    def test_execute_workflow_exception_handling(self, workflow_executor, workflows_dir):
        """Test workflow execution with exception."""
        workflow_content = """
name: test_workflow
version: "1.0"
description: Test workflow
variables: {}
steps:
  - step: 1
    name: step1
    agent: writer
"""
        (workflows_dir / "test_workflow.yaml").write_text(workflow_content)

        # Mock workflow loader to raise exception
        workflow_executor.workflow_loader.load_workflow = Mock(side_effect=Exception("Load error"))

        result = workflow_executor.execute_workflow(
            workflow_name="test_workflow",
            project_name="test_project",
            variables={},
            config={},
        )

        assert result["success"] is False
        assert "error" in result
        assert result["error"] == "Load error"
        assert len(result["executed_steps"]) == 0

    def test_execute_workflow_with_loop_all_success(self, workflow_executor, workflows_dir):
        """Test workflow loop execution with all iterations successful."""
        workflow_content = """
name: test_workflow
version: "1.0"
description: Test workflow
variables: {}
steps:
  - step: 1
    name: step1
    agent: writer
"""
        (workflows_dir / "test_workflow.yaml").write_text(workflow_content)

        workflow_executor.step_executor.execute_step = Mock(
            return_value={
                "success": True,
                "output": {},
                "skipped": False,
            }
        )

        result = workflow_executor.execute_workflow_with_loop(
            workflow_name="test_workflow",
            project_name="test_project",
            variables={},
            config={},
            loop_range=range(3),
        )

        assert result["success"] is True
        assert result["iterations"] == 3
        assert len(result["failed_iterations"]) == 0
        assert len(result["results"]) == 3

    def test_execute_workflow_with_loop_some_failures(self, workflow_executor, workflows_dir):
        """Test workflow loop execution with some iterations failing."""
        workflow_content = """
name: test_workflow
version: "1.0"
description: Test workflow
variables: {}
steps:
  - step: 1
    name: step1
    agent: writer
"""
        (workflows_dir / "test_workflow.yaml").write_text(workflow_content)

        call_count = [0]

        def mock_execute_step(*args, **kwargs):
            call_count[0] += 1
            return {
                "success": call_count[0] % 2 == 1,  # Alternate success/failure
                "output": {},
                "skipped": False,
            }

        workflow_executor.step_executor.execute_step = Mock(side_effect=mock_execute_step)

        result = workflow_executor.execute_workflow_with_loop(
            workflow_name="test_workflow",
            project_name="test_project",
            variables={},
            config={},
            loop_range=range(4),
        )

        assert result["success"] is False
        assert result["iterations"] == 4
        assert len(result["failed_iterations"]) == 2
        assert 1 in result["failed_iterations"]
        assert 3 in result["failed_iterations"]

    def test_execute_workflow_with_loop_variables_merged(self, workflow_executor, workflows_dir):
        """Test that loop variables are merged with iteration variable."""
        workflow_content = """
name: test_workflow
version: "1.0"
description: Test workflow
variables: {}
steps:
  - step: 1
    name: step1
    agent: writer
"""
        (workflows_dir / "test_workflow.yaml").write_text(workflow_content)

        captured_variables = []

        def mock_execute_step(*args, variables=None, **kwargs):
            if variables:
                captured_variables.append(variables)
            return {
                "success": True,
                "output": {},
                "skipped": False,
            }

        workflow_executor.step_executor.execute_step = Mock(side_effect=mock_execute_step)

        workflow_executor.execute_workflow_with_loop(
            workflow_name="test_workflow",
            project_name="test_project",
            variables={"base_var": "base_value"},
            config={},
            loop_range=range(2),
        )

        assert captured_variables[0]["iteration"] == 0
        assert captured_variables[0]["base_var"] == "base_value"
        assert captured_variables[1]["iteration"] == 1
        assert captured_variables[1]["base_var"] == "base_value"

    def test_list_workflows(self, workflow_executor, workflows_dir):
        """Test listing all available workflows."""
        # Create multiple workflow files
        workflow1 = """
name: workflow1
version: "1.0"
description: First workflow
variables: {}
steps: []
"""
        workflow2 = """
name: workflow2
version: "1.0"
description: Second workflow
variables: {}
steps: []
"""
        (workflows_dir / "workflow1.yaml").write_text(workflow1)
        (workflows_dir / "workflow2.yaml").write_text(workflow2)

        workflows = workflow_executor.list_workflows()

        assert len(workflows) == 2
        assert workflows["workflow1"] == "First workflow"
        assert workflows["workflow2"] == "Second workflow"

    def test_get_workflow_info_success(self, workflow_executor, workflows_dir):
        """Test getting workflow information successfully."""
        workflow_content = """
name: test_workflow
version: "2.0"
description: A test workflow
variables:
  var1: value1
  var2: value2
steps:
  - step: 1
    name: step1
    agent: writer
  - step: 2
    name: step2
    agent: reviewer
"""
        (workflows_dir / "test_workflow.yaml").write_text(workflow_content)

        info = workflow_executor.get_workflow_info("test_workflow")

        assert info["name"] == "test_workflow"
        assert info["version"] == "2.0"
        assert info["description"] == "A test workflow"
        assert info["variables"]["var1"] == "value1"
        assert info["step_count"] == 2

    def test_get_workflow_info_not_found(self, workflow_executor, workflows_dir):
        """Test getting workflow info for non-existent workflow."""
        info = workflow_executor.get_workflow_info("nonexistent_workflow")

        assert info == {}

    def test_execute_workflow_merges_variables(self, workflow_executor, workflows_dir):
        """Test that workflow variables are merged with provided variables."""
        workflow_content = """
name: test_workflow
version: "1.0"
description: Test workflow
variables:
  workflow_var: workflow_value
  shared_var: from_workflow
steps:
  - step: 1
    name: step1
    agent: writer
"""
        (workflows_dir / "test_workflow.yaml").write_text(workflow_content)

        captured_variables = []

        def mock_execute_step(*args, variables=None, **kwargs):
            if variables:
                captured_variables.append(variables)
            return {
                "success": True,
                "output": {},
                "skipped": False,
            }

        workflow_executor.step_executor.execute_step = Mock(side_effect=mock_execute_step)

        workflow_executor.execute_workflow(
            workflow_name="test_workflow",
            project_name="test_project",
            variables={"custom_var": "custom_value", "shared_var": "custom_override"},
            config={},
        )

        # Provided variables should override workflow variables
        assert captured_variables[0]["workflow_var"] == "workflow_value"
        assert captured_variables[0]["custom_var"] == "custom_value"
        assert captured_variables[0]["shared_var"] == "custom_override"
