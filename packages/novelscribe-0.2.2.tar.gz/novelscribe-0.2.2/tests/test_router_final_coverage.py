"""
Final coverage tests for API routers targeting specific uncovered lines.
Tests exception handling, SSE streaming, and WebSocket error scenarios.
"""

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from starlette.websockets import WebSocketDisconnect


class TestLogsRouterFinalCoverage:
    """Tests for remaining uncovered lines in logs router."""

    @pytest.fixture
    def client(self):
        from fastapi.testclient import TestClient

        from api.app import app

        return TestClient(app)

    def test_get_execution_logs_exception_handling(self, client):
        """Test exception handling in get_execution_logs."""
        with patch("api.routers.logs.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.side_effect = Exception("Storage error")
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/logs/test_project/exec_001")
            assert response.status_code in [500, 404]

    def test_stream_logs_sse_endpoint(self, client):
        """Test SSE streaming endpoint for logs."""
        with patch("api.routers.logs.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["test_project"]

            mock_response = MagicMock()
            mock_log = MagicMock()
            mock_log.to_dict.return_value = {
                "timestamp": "2024-01-01T10:00:00",
                "level": "INFO",
                "message": "Test log",
                "execution_id": "exec_001",
            }
            mock_response.logs = [mock_log]
            mock_instance.get_logs.return_value = mock_response
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/logs/stream?project_name=test_project")
            assert response.status_code in [200, 404]

    def test_stream_logs_with_execution_filter(self, client):
        """Test SSE streaming with execution ID filter."""
        with patch("api.routers.logs.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["test_project"]

            mock_response = MagicMock()
            mock_response.logs = []
            mock_instance.get_logs.return_value = mock_response
            mock_storage.return_value = mock_instance

            response = client.get(
                "/api/v1/logs/stream?project_name=test_project&execution_id=exec_001"
            )
            assert response.status_code in [200, 404]

    def test_stream_logs_nonexistent_project(self, client):
        """Test SSE streaming with nonexistent project."""
        with patch("api.routers.logs.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = []
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/logs/stream?project_name=nonexistent")
            assert response.status_code == 404


class TestSuggestionsRouterFinalCoverage:
    """Tests for remaining uncovered lines in suggestions router."""

    @pytest.fixture
    def client(self):
        from fastapi.testclient import TestClient

        from api.app import app

        return TestClient(app)

    def test_list_learned_suggestions(self, client):
        """Test listing learned suggestions."""
        response = client.get("/api/v1/suggestions/learned")
        assert response.status_code in [200, 404, 500]

    def test_list_learned_suggestions_empty(self, client):
        """Test listing learned suggestions when none exist."""
        response = client.get("/api/v1/suggestions/learned")
        assert response.status_code in [200, 404, 500]

    def test_list_pending_promotions(self, client):
        """Test listing pending promotions."""
        response = client.get("/api/v1/suggestions/pending")
        assert response.status_code in [200, 404, 500]

    def test_list_pending_promotions_empty(self, client):
        """Test listing pending promotions when none are pending."""
        response = client.get("/api/v1/suggestions/pending")
        assert response.status_code in [200, 404, 500]

    def test_promote_suggestion_without_confirmation(self, client):
        """Test promoting suggestion without confirmation parameter."""
        response = client.post("/api/v1/suggestions/sug_001/promote")
        assert response.status_code in [400, 422]

    def test_promote_suggestion_false_confirmation(self, client):
        """Test promoting suggestion with confirm=false."""
        response = client.post("/api/v1/suggestions/sug_001/promote?confirm=false")
        assert response.status_code == 400

    def test_promote_suggestion_not_found(self, client):
        """Test promoting nonexistent suggestion."""
        response = client.post("/api/v1/suggestions/nonexistent/promote?confirm=true")
        assert response.status_code in [200, 404, 500]

    def test_get_acceptance_history(self, client):
        """Test getting acceptance history."""
        response = client.get("/api/v1/suggestions/history?days=7")
        assert response.status_code in [200, 404, 500]

    def test_get_acceptance_history_with_project(self, client):
        """Test getting acceptance history filtered by project."""
        response = client.get("/api/v1/suggestions/history?project_id=test_project&days=30")
        assert response.status_code in [200, 404, 500]

    def test_list_suggestions_with_source_filter(self, client):
        """Test listing suggestions filtered by source."""
        response = client.get("/api/v1/suggestions/?source=dynamic")
        assert response.status_code in [200, 500]


class TestWebSocketRouterFinalCoverage:
    """Tests for remaining uncovered lines in WebSocket router."""

    @pytest.mark.asyncio
    async def test_websocket_global_json_error(self):
        """Test global WebSocket with invalid JSON."""
        from fastapi import WebSocket

        with patch("api.routers.websocket.get_websocket_manager") as mock_mgr_get:
            mock_manager = MagicMock()
            mock_manager.connect = AsyncMock(return_value="client_123")
            mock_manager.disconnect = AsyncMock()
            mock_manager.send_to_client = AsyncMock()
            mock_mgr_get.return_value = mock_manager

            mock_ws = MagicMock(spec=WebSocket)
            mock_ws.receive_text = AsyncMock(side_effect=["invalid json", WebSocketDisconnect()])

            from api.routers.websocket import websocket_global

            try:
                await websocket_global(mock_ws)
            except (Exception, WebSocketDisconnect):
                pass

            mock_manager.send_to_client.assert_called_once()
            call_args = mock_manager.send_to_client.call_args
            assert call_args[0][1]["type"] == "error"

    @pytest.mark.asyncio
    async def test_websocket_project_json_error(self):
        """Test project WebSocket with invalid JSON."""
        from fastapi import WebSocket

        with patch("api.routers.websocket.get_websocket_manager") as mock_mgr_get:
            mock_manager = MagicMock()
            mock_manager.connect = AsyncMock(return_value="client_123")
            mock_manager.disconnect = AsyncMock()
            mock_manager.send_to_client = AsyncMock()
            mock_mgr_get.return_value = mock_manager

            mock_ws = MagicMock(spec=WebSocket)
            mock_ws.receive_text = AsyncMock(side_effect=["not json", WebSocketDisconnect()])

            from api.routers.websocket import websocket_project

            try:
                await websocket_project(mock_ws, "test_project")
            except (Exception, WebSocketDisconnect):
                pass

            mock_manager.send_to_client.assert_called_once()
            call_args = mock_manager.send_to_client.call_args
            assert call_args[0][1]["type"] == "error"

    @pytest.mark.asyncio
    async def test_websocket_execution_json_error(self):
        """Test execution WebSocket with invalid JSON."""
        from fastapi import WebSocket

        with patch("api.routers.websocket.get_websocket_manager") as mock_mgr_get:
            mock_manager = MagicMock()
            mock_manager.connect = AsyncMock(return_value="client_123")
            mock_manager.disconnect = AsyncMock()
            mock_manager.send_to_client = AsyncMock()
            mock_mgr_get.return_value = mock_manager

            mock_ws = MagicMock(spec=WebSocket)
            mock_ws.receive_text = AsyncMock(side_effect=["{broken}", WebSocketDisconnect()])

            from api.routers.websocket import websocket_execution

            try:
                await websocket_execution(mock_ws, "test_project", "exec_001")
            except (Exception, WebSocketDisconnect):
                pass

            mock_manager.send_to_client.assert_called()
            error_calls = [
                call
                for call in mock_manager.send_to_client.call_args_list
                if call[0][1].get("type") == "error"
            ]
            assert len(error_calls) > 0

    @pytest.mark.asyncio
    async def test_websocket_execution_subscribe_message(self):
        """Test execution WebSocket subscribe message handling."""
        from fastapi import WebSocket

        with patch("api.routers.websocket.get_websocket_manager") as mock_mgr_get:
            mock_manager = MagicMock()
            mock_manager.connect = AsyncMock(return_value="client_123")
            mock_manager.disconnect = AsyncMock()
            mock_manager.send_to_client = AsyncMock()
            mock_mgr_get.return_value = mock_manager

            mock_ws = MagicMock(spec=WebSocket)
            mock_ws.receive_text = AsyncMock(
                side_effect=[
                    '{"type": "subscribe"}',
                    WebSocketDisconnect(),
                ]
            )

            from api.routers.websocket import websocket_execution

            try:
                await websocket_execution(mock_ws, "test_project", "exec_001")
            except (Exception, WebSocketDisconnect):
                pass

            subscribe_calls = [
                call
                for call in mock_manager.send_to_client.call_args_list
                if call[0][1].get("type") == "subscribed"
            ]
            assert len(subscribe_calls) > 0

    @pytest.mark.asyncio
    async def test_websocket_execution_unknown_message_type(self):
        """Test execution WebSocket with unknown message type - message is ignored."""
        from fastapi import WebSocket

        with patch("api.routers.websocket.get_websocket_manager") as mock_mgr_get:
            mock_manager = MagicMock()
            mock_manager.connect = AsyncMock(return_value="client_123")
            mock_manager.disconnect = AsyncMock()
            mock_manager.send_to_client = AsyncMock()
            mock_mgr_get.return_value = mock_manager

            mock_ws = MagicMock(spec=WebSocket)
            mock_ws.receive_text = AsyncMock(
                side_effect=[
                    '{"type": "unknown_type"}',
                    WebSocketDisconnect(),
                ]
            )

            from api.routers.websocket import websocket_execution

            try:
                await websocket_execution(mock_ws, "test_project", "exec_001")
            except (Exception, WebSocketDisconnect):
                pass

            mock_manager.send_to_client.assert_called()


class TestStreamingRouterFinalCoverage:
    """Tests for remaining uncovered lines in streaming router."""

    @pytest.mark.asyncio
    async def test_stream_logs_sse_with_new_logs(self):
        """Test SSE generator detects and sends new logs."""
        from api.routers.streaming import stream_logs

        response = await stream_logs("test_project", level=None, events=None)
        assert response.status_code == 200
        assert response.media_type == "text/event-stream"

    @pytest.mark.asyncio
    async def test_generate_status_events_with_active_executions(self):
        """Test status generator with active workflow executions."""
        from api.routers.streaming import generate_status_events

        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["test_project"]
            mock_storage.return_value = mock_instance

            with patch("api.tasks.get_task_manager") as mock_tm:
                mock_manager = MagicMock()
                mock_state = MagicMock()
                mock_state.execution_id = "exec_001"
                mock_state.progress = 50.0
                mock_state.status = "running"
                mock_manager.get_all_executions.return_value = [mock_state]
                mock_tm.return_value = mock_manager

                async def mock_sleep(*args):
                    pass

                with patch("asyncio.sleep", mock_sleep):
                    events = []
                    async for event in generate_status_events("test_project"):
                        events.append(event)
                        if len(events) >= 3:
                            break

                assert len(events) >= 2

    @pytest.mark.asyncio
    async def test_generate_status_events_cancelled(self):
        """Test status generator handles cancellation."""
        from api.routers.streaming import generate_status_events

        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["test_project"]
            mock_storage.return_value = mock_instance

            with patch("api.tasks.get_task_manager") as mock_tm:
                mock_manager = MagicMock()
                mock_manager.get_all_executions.return_value = []
                mock_tm.return_value = mock_manager

                events = []
                async for event in generate_status_events("test_project"):
                    events.append(event)
                    break

                assert len(events) == 1

    @pytest.mark.asyncio
    async def test_generate_status_events_exception_handling(self):
        """Test status generator handles exceptions."""
        from api.routers.streaming import generate_status_events

        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects = MagicMock(side_effect=Exception("Storage error"))
            mock_storage.return_value = mock_instance

            events = []
            try:
                async for event in generate_status_events("test_project"):
                    events.append(event)
                    if len(events) > 0:
                        break
            except (Exception, asyncio.CancelledError):
                pass

            assert len(events) >= 0
