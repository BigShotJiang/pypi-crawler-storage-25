"""
Unit Tests for Quality Metrics Calculator

Tests the comprehensive quality metrics calculation including readability,
dialogue analysis, pacing metrics, consistency checks, and style analysis.
"""

import pytest

from core.quality_metrics import (
    QualityMetricsCalculator,
)


class TestQualityMetricsCalculator:
    """Test suite for QualityMetricsCalculator."""

    @pytest.fixture
    def calculator(self):
        """Create a calculator instance for testing."""
        return QualityMetricsCalculator()

    @pytest.fixture
    def sample_content(self):
        """Create sample content for testing."""
        return """
        The quick brown fox jumped over the lazy dog. This sentence has multiple words.
        "Hello there," said John. "How are you today?" asked Mary with a smile.
        "I'm doing well," replied John happily. The sun was setting in the distance.
        They walked together through the forest. Birds were singing. The wind was blowing.
        """

    @pytest.fixture
    def dialogue_content(self):
        """Create dialogue-heavy content for testing."""
        return """
        "What do you mean?" asked Tom, his voice rising.
        "I mean exactly what I said," replied Sarah calmly.
        Tom stared at her. "But that doesn't make sense."
        "It does if you think about it," Sarah said.
        """

    @pytest.fixture
    def passive_voice_content(self):
        """Create content with passive voice for testing."""
        return """
        The ball was thrown by the boy. The window was broken.
        The cake was being eaten by the children. The book was read by everyone.
        """

    def test_calculate_basic_metrics(self, calculator, sample_content):
        """Test basic content metrics calculation."""
        metrics = calculator.calculate_metrics(sample_content, 1, 1)

        assert metrics.word_count > 0
        assert metrics.sentence_count > 0
        assert metrics.paragraph_count > 0
        assert metrics.avg_sentence_length > 0
        assert metrics.avg_paragraph_length > 0

    def test_readability_metrics(self, calculator, sample_content):
        """Test readability score calculations."""
        metrics = calculator.calculate_metrics(sample_content, 1, 1)

        assert 0 <= metrics.flesch_kincaid <= 20
        assert 0 <= metrics.gunning_fog <= 20
        assert 0 <= metrics.smog_index <= 20

    def test_dialogue_metrics(self, calculator, dialogue_content):
        """Test dialogue analysis metrics."""
        metrics = calculator.calculate_metrics(dialogue_content, 1, 1)

        assert metrics.dialogue_ratio > 0
        assert metrics.dialogue_line_count > 0
        assert 0 <= metrics.speaker_clarity <= 1

    def test_passive_voice_detection(self, calculator, passive_voice_content):
        """Test passive voice detection."""
        metrics = calculator.calculate_metrics(passive_voice_content, 1, 1)

        assert metrics.passive_voice_ratio > 0
        assert metrics.passive_voice_ratio <= 1.0

    def test_vocabulary_diversity(self, calculator):
        """Test vocabulary diversity calculation."""
        repetitive_content = "the cat the cat the cat the cat"
        diverse_content = "the feline jumped ran sprinted dashed quickly"

        repetitive_metrics = calculator.calculate_metrics(repetitive_content, 1, 1)
        diverse_metrics = calculator.calculate_metrics(diverse_content, 1, 1)

        assert diverse_metrics.vocabulary_diversity > repetitive_metrics.vocabulary_diversity

    def test_character_consistency(self, calculator):
        """Test character consistency checking."""
        content = "John and Mary went to the store. John bought apples."
        character_names = ["John", "Mary", "Bob"]

        metrics = calculator.calculate_metrics(content, 1, 1, character_names=character_names)

        assert metrics.character_consistency == 2.0 / 3.0

    def test_plot_continuity(self, calculator):
        """Test plot continuity checking."""
        content = "They arrived at the castle and entered the great hall."
        locations = ["castle", "forest", "village"]

        metrics = calculator.calculate_metrics(content, 1, 1, location_names=locations)

        assert metrics.plot_continuity == 1.0 / 3.0

    def test_overall_quality_score(self, calculator, sample_content):
        """Test overall quality score calculation."""
        metrics = calculator.calculate_metrics(sample_content, 1, 1)

        assert 0 <= metrics.overall_quality_score <= 1

    def test_metrics_summary(self, calculator, sample_content):
        """Test metrics summary generation."""
        metrics = calculator.calculate_metrics(sample_content, 1, 1)
        summary = calculator.get_metrics_summary(metrics)

        assert "Chapter 1" in summary
        assert "Quality Metrics Summary" in summary
        assert "Words:" in summary
        assert "Overall Quality Score:" in summary

    def test_compare_metrics(self, calculator, sample_content):
        """Test metrics comparison functionality."""
        metrics1 = calculator.calculate_metrics(sample_content, 1, 1)
        metrics2 = calculator.calculate_metrics(sample_content + " More content.", 1, 2)

        comparison = calculator.compare_metrics(metrics1, metrics2)

        assert "word_count_change" in comparison
        assert "readability_change" in comparison
        assert "dialogue_ratio_change" in comparison
        assert comparison["word_count_change"] > 0

    def test_empty_content(self, calculator):
        """Test handling of empty content."""
        metrics = calculator.calculate_metrics("", 1, 1)

        assert metrics.word_count == 0
        assert metrics.sentence_count == 0
        assert metrics.overall_quality_score >= 0

    def test_very_long_sentence(self, calculator):
        """Test detection of very long sentences."""
        long_sentence_content = (
            "This is a sentence that goes on and on and on and on and on and on "
            "and on and on and on and on and on and on and on and on and on and "
            "on and on and on and on and on and on and on and on and on and on "
            "and on and on and on and on and on and on and on and on and on and on."
        )
        metrics = calculator.calculate_metrics(long_sentence_content, 1, 1)

        assert metrics.avg_sentence_length > 30

    def test_action_frequency(self, calculator):
        """Test action frequency calculation."""
        action_content = "The hero ran and jumped and fought and attacked and defended."
        metrics = calculator.calculate_metrics(action_content, 1, 1)

        assert metrics.action_frequency > 0


class TestContentMetrics:
    """Test suite for content metrics calculation."""

    @pytest.fixture
    def calculator(self):
        return QualityMetricsCalculator()

    def test_word_count(self, calculator):
        """Test accurate word counting."""
        content = "Hello world. This is a test."
        metrics = calculator._calculate_content_metrics(content)

        assert metrics.word_count == 6

    def test_sentence_count(self, calculator):
        """Test accurate sentence counting."""
        content = "First sentence. Second sentence! Third question?"
        metrics = calculator._calculate_content_metrics(content)

        assert metrics.sentence_count == 3

    def test_paragraph_count(self, calculator):
        """Test accurate paragraph counting."""
        content = "First paragraph.\n\nSecond paragraph.\n\nThird paragraph."
        metrics = calculator._calculate_content_metrics(content)

        assert metrics.paragraph_count == 3


class TestReadabilityMetrics:
    """Test suite for readability metrics."""

    @pytest.fixture
    def calculator(self):
        return QualityMetricsCalculator()

    def test_flesch_kincaid_grade(self, calculator):
        """Test Flesch-Kincaid grade level calculation."""
        simple_text = "The cat sat on the mat."
        complex_text = (
            "The comprehensive investigation demonstrated that the utilization "
            "of sophisticated methodologies significantly enhanced the "
            "analytical capabilities."
        )

        simple_metrics = calculator._calculate_readability_metrics(simple_text)
        complex_metrics = calculator._calculate_readability_metrics(complex_text)

        assert simple_metrics.flesch_kincaid_grade < complex_metrics.flesch_kincaid_grade

    def test_gunning_fog_index(self, calculator):
        """Test Gunning Fog index calculation."""
        metrics = calculator._calculate_readability_metrics("This is a test.")

        assert metrics.gunning_fog_index >= 0


class TestDialogueMetrics:
    """Test suite for dialogue metrics."""

    @pytest.fixture
    def calculator(self):
        return QualityMetricsCalculator()

    def test_dialogue_extraction(self, calculator):
        """Test extraction of dialogue from content."""
        content = '"Hello," he said. "How are you?" she asked.'
        metrics = calculator._calculate_dialogue_metrics(content)

        assert metrics.dialogue_line_count == 2

    def test_speaker_clarity(self, calculator):
        """Test speaker clarity calculation."""
        clear_dialogue = '"Hello," said John. "Hi," replied Mary.'
        unclear_dialogue = '"Hello." "Hi."'

        clear_metrics = calculator._calculate_dialogue_metrics(clear_dialogue)
        unclear_metrics = calculator._calculate_dialogue_metrics(unclear_dialogue)

        assert clear_metrics.dialogue_ratio >= 0
        assert unclear_metrics.dialogue_ratio >= 0


class TestPacingMetrics:
    """Test suite for pacing metrics."""

    @pytest.fixture
    def calculator(self):
        return QualityMetricsCalculator()

    def test_scene_variation(self, calculator):
        """Test scene variation calculation."""
        uniform_content = "Short. Short. Short. Short. Short."
        varied_content = """
        This is a much longer paragraph with significantly more content.
        Short.
        Another medium length paragraph with some content.
        """

        uniform_metrics = calculator._calculate_pacing_metrics(uniform_content)
        varied_metrics = calculator._calculate_pacing_metrics(varied_content)

        assert varied_metrics.scene_variation_score >= uniform_metrics.scene_variation_score


class TestStyleMetrics:
    """Test suite for style metrics."""

    @pytest.fixture
    def calculator(self):
        return QualityMetricsCalculator()

    def test_adverb_detection(self, calculator):
        """Test adverb detection."""
        content_with_adverbs = "He quickly ran. She slowly walked. They happily jumped."
        content_without_adverbs = "He ran. She walked. They jumped."

        with_adverbs = calculator._calculate_style_metrics(content_with_adverbs)
        without_adverbs = calculator._calculate_style_metrics(content_without_adverbs)

        assert with_adverbs.adverb_frequency > without_adverbs.adverb_frequency

    def test_vocabulary_diversity_calculation(self, calculator):
        """Test vocabulary diversity calculation."""
        repetitive = "cat cat cat dog dog"
        diverse = "cat feline canine dog hound pet"

        repetitive_metrics = calculator._calculate_style_metrics(repetitive)
        diverse_metrics = calculator._calculate_style_metrics(diverse)

        assert diverse_metrics.vocabulary_diversity > repetitive_metrics.vocabulary_diversity


class TestSyllableCounter:
    """Test suite for syllable counting."""

    @pytest.fixture
    def calculator(self):
        return QualityMetricsCalculator()

    def test_simple_word_syllables(self, calculator):
        """Test syllable counting for simple words."""
        assert calculator._count_syllables("the") == 1
        assert calculator._count_syllables("cat") == 1
        assert calculator._count_syllables("hello") == 2

    def test_complex_word_syllables(self, calculator):
        """Test syllable counting for complex words."""
        assert calculator._count_syllables("beautiful") == 3
        assert calculator._count_syllables("education") == 4
        assert calculator._count_syllables("extraordinary") >= 5
