"""Coverage tests for api/routers/streaming.py edge cases.

This test suite specifically targets code paths that have lower coverage:
- Exception handling paths
- asyncio.CancelledError handling
- stream_all_events generator
- Edge case configurations
- Factory functions

Coverage Target: Additional tests to reach 85% coverage
"""

import asyncio
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from fastapi.responses import StreamingResponse

from api.models import LogLevel
from api.routers.streaming import (
    DEFAULT_LOG_POLL_INTERVAL,
    DEFAULT_MAX_ITERATIONS,
    DEFAULT_STATUS_POLL_INTERVAL,
    LogStreamerConfig,
    StatusStreamerConfig,
    build_stream_headers,
    create_error_event,
    create_log_event,
    create_log_file_provider,
    create_storage_checker,
    format_sse,
    generate_log_events,
    generate_status_events,
    parse_event_types,
    router,
    validate_project_name,
)


class TestFactoryFunctions:
    """Tests for factory functions."""

    def test_create_storage_checker_returns_callable(self):
        """Test create_storage_checker returns a callable."""
        checker = create_storage_checker()
        assert callable(checker)

    def test_create_log_file_provider_returns_callable(self):
        """Test create_log_file_provider returns a callable."""
        provider = create_log_file_provider()
        assert callable(provider)

    def test_create_storage_checker_executes_storage_call(self):
        """Test create_storage_checker executes Storage().list_projects()."""
        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["project1", "project2"]
            mock_storage.return_value = mock_instance

            checker = create_storage_checker()
            result = checker()

            mock_instance.list_projects.assert_called_once()
            assert result == ["project1", "project2"]

    def test_create_log_file_provider_executes_storage_call(self):
        """Test create_log_file_provider uses Storage().project_dir."""
        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.project_dir = Path("/fake/path")
            mock_storage.return_value = mock_instance

            provider = create_log_file_provider()
            result = provider("test_project")

            assert "test_project" in str(result)
            assert "execution.log" in str(result)


class TestExceptionHandling:
    """Tests for exception handling paths."""

    async def test_log_generator_handles_storage_checker_exception(self):
        """Test log generator handles storage_checker exceptions."""

        def failing_storage_checker():
            raise RuntimeError("Storage connection failed")

        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=failing_storage_checker,
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        assert len(events) >= 1
        error_events = [e for e in events if "event: error" in e]
        assert len(error_events) >= 1
        assert "Storage error" in events[0]

    async def test_status_generator_handles_storage_checker_exception(self):
        """Test status generator handles storage_checker exceptions."""

        def failing_storage_checker():
            raise RuntimeError("Storage connection failed")

        config = StatusStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_status_events(
            "test_project",
            storage_checker=failing_storage_checker,
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        assert len(events) >= 1
        error_events = [e for e in events if "event: error" in e]
        assert len(error_events) >= 1
        assert "Storage error" in events[0]


class TestDefaultConfigHandling:
    """Tests for default config handling."""

    async def test_log_generator_with_no_config(self, tmp_path):
        """Test log generator uses default config when None provided."""
        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        assert len(events) >= 1

    async def test_status_generator_with_no_config(self):
        """Test status generator uses default config when None provided."""
        storage_checker = MagicMock(return_value=["test_project"])
        task_manager = MagicMock(get_all_executions=MagicMock(return_value=[]))
        config = StatusStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_status_events(
            "test_project",
            storage_checker=storage_checker,
            task_manager_getter=MagicMock(return_value=task_manager),
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        assert len(events) >= 1


class TestStreamAllEventsGenerator:
    """Tests for the combined stream_all_events generator."""

    async def test_generate_all_events_basic(self, tmp_path):
        """Test combined log and status event generation."""
        from api.routers.streaming import generate_log_events, generate_status_events

        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO", "message": "test"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        task_manager = MagicMock(get_all_executions=MagicMock(return_value=[]))

        log_config = LogStreamerConfig(max_iterations=1, poll_interval=0.001)
        status_config = StatusStreamerConfig(max_iterations=1, poll_interval=0.001)

        log_gen = generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=log_config,
        )
        status_gen = generate_status_events(
            "test_project",
            storage_checker=storage_checker,
            task_manager_getter=MagicMock(return_value=task_manager),
            config=status_config,
        )

        log_event = await log_gen.__anext__()
        assert "connected" in log_event

        status_event = await status_gen.__anext__()
        assert "connected" in status_event

        await log_gen.aclose()
        await status_gen.aclose()

    async def test_generate_all_events_multiple_iterations(self, tmp_path):
        """Test combined generator with multiple iterations."""
        from api.routers.streaming import generate_log_events

        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        log_gen = generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        )

        event = await asyncio.wait_for(log_gen.__anext__(), timeout=1.0)
        assert "connected" in event

        event2 = await asyncio.wait_for(log_gen.__anext__(), timeout=1.0)
        assert "event: log" in event2

        await log_gen.aclose()


class TestConfigEdgeCases:
    """Tests for configuration edge cases."""

    def test_log_streamer_config_default_values(self):
        """Test LogStreamerConfig default values."""
        config = LogStreamerConfig()
        assert config.max_iterations == DEFAULT_MAX_ITERATIONS
        assert config.poll_interval == DEFAULT_LOG_POLL_INTERVAL

    def test_log_streamer_config_custom_values(self):
        """Test LogStreamerConfig with custom values."""
        config = LogStreamerConfig(max_iterations=5, poll_interval=1.0)
        assert config.max_iterations == 5
        assert config.poll_interval == 1.0

    def test_status_streamer_config_default_values(self):
        """Test StatusStreamerConfig default values."""
        config = StatusStreamerConfig()
        assert config.max_iterations == DEFAULT_MAX_ITERATIONS
        assert config.poll_interval == DEFAULT_STATUS_POLL_INTERVAL

    def test_status_streamer_config_custom_values(self):
        """Test StatusStreamerConfig with custom values."""
        config = StatusStreamerConfig(max_iterations=20, poll_interval=2.0)
        assert config.max_iterations == 20
        assert config.poll_interval == 2.0


class TestEdgeCaseHelpers:
    """Tests for helper functions edge cases."""

    def test_format_sse_empty_data(self):
        """Test format_sse with empty data."""
        from api.routers.streaming import format_sse

        result = format_sse("test", {})
        assert "event: test\n" in result
        assert result.endswith("\n\n")

    def test_format_sse_with_list_data(self):
        """Test format_sse with list data."""
        from api.routers.streaming import format_sse

        result = format_sse("test", ["item1", "item2"])
        assert "event: test\n" in result

    def test_format_sse_none_data(self):
        """Test format_sse with None data."""
        from api.routers.streaming import format_sse

        result = format_sse("test", None)
        assert "event: test\n" in result

    def test_create_log_event_with_types(self):
        """Test create_log_event with various types."""
        result = create_log_event('{"level": "INFO"}', event_type="log")
        assert "event: log\n" in result
        assert '"level": "INFO"' in result

        result = create_log_event('{"level": "ERROR"}', event_type="custom")
        assert "event: log\n" in result
        assert '"level": "ERROR"' in result

    def test_create_log_event_raw_type(self):
        """Test create_log_event with raw type."""
        result = create_log_event("plain text log", event_type="raw")
        assert "event: raw\n" in result
        assert "plain text log" in result

    def test_create_error_event_format(self):
        """Test create_error_event format."""
        result = create_error_event("Error message")
        assert "event: error\n" in result
        assert "Error message" in result
        assert result.endswith("\n\n")

    def test_parse_event_types_empty_string(self):
        """Test parse_event_types with empty string."""
        result = parse_event_types("")
        assert result is None

    def test_parse_event_types_none(self):
        """Test parse_event_types with None."""
        result = parse_event_types(None)
        assert result is None

    def test_parse_event_types_single_event(self):
        """Test parse_event_types with single event."""
        result = parse_event_types("log")
        assert result == ["log"]

    def test_parse_event_types_multiple_with_whitespace(self):
        """Test parse_event_types with whitespace around events."""
        result = parse_event_types(" log , error , warning ")
        assert result == ["log", "error", "warning"]


class TestBuildStreamHeaders:
    """Tests for build_stream_headers function."""

    def test_build_stream_headers_returns_dict(self):
        """Test build_stream_headers returns correct dict."""
        headers = build_stream_headers()
        assert isinstance(headers, dict)
        assert headers["Cache-Control"] == "no-cache"
        assert headers["Connection"] == "keep-alive"
        assert headers["X-Accel-Buffering"] == "no"

    def test_build_stream_headers_keys(self):
        """Test build_stream_headers has all required keys."""
        headers = build_stream_headers()
        required_keys = {"Cache-Control", "Connection", "X-Accel-Buffering"}
        assert set(headers.keys()) == required_keys


class TestValidateProjectName:
    """Tests for validate_project_name edge cases."""

    def test_validate_project_name_with_forward_slash(self):
        """Test validate_project_name with forward slash."""
        from fastapi import HTTPException

        with pytest.raises(HTTPException) as exc_info:
            validate_project_name("project/name")
        assert exc_info.value.status_code == 400

    def test_validate_project_name_with_backslash(self):
        """Test validate_project_name with backslash."""
        from fastapi import HTTPException

        with pytest.raises(HTTPException):
            validate_project_name("project\\name")

    def test_validate_project_name_with_dots(self):
        """Test validate_project_name with dots (should pass)."""
        validate_project_name("project.name")

    def test_validate_project_name_with_spaces(self):
        """Test validate_project_name with spaces (should pass)."""
        validate_project_name("project name")

    def test_validate_project_name_empty(self):
        """Test validate_project_name with empty string (should pass)."""
        validate_project_name("")

    def test_validate_project_name_valid(self):
        """Test validate_project_name with valid name."""
        validate_project_name("valid_project_123")


class TestLogLevelFilter:
    """Tests for log level filtering in generators."""

    async def test_log_generator_filters_by_level(self, tmp_path):
        """Test log generator filters by log level."""
        log_file = tmp_path / "execution.log"
        log_file.write_text(
            '{"level": "INFO", "message": "info1"}\n'
            '{"level": "ERROR", "message": "error1"}\n'
            '{"level": "WARNING", "message": "warn1"}\n'
        )

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            log_level=LogLevel.ERROR,
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        assert len(events) >= 1
        log_events = [e for e in events if '"level": "ERROR"' in e]
        assert len(log_events) >= 1

    async def test_log_generator_filters_by_event_types(self, tmp_path):
        """Test log generator filters by event types."""
        log_file = tmp_path / "execution.log"
        log_file.write_text(
            '{"type": "user_action", "message": "action1"}\n{"type": "system", "message": "sys1"}\n'
        )

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            event_types=["user_action"],
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        assert len(events) >= 1


class TestStatusChangeDetection:
    """Tests for status change detection in status generator."""

    async def test_status_generator_detects_new_execution(self):
        """Test status generator yields execution_start for new executions."""
        storage_checker = MagicMock(return_value=["test_project"])

        mock_exec = MagicMock()
        mock_exec.execution_id = "exec_001"
        mock_exec.status = "running"
        mock_exec.to_dict.return_value = {"id": "exec_001", "status": "running"}

        task_manager = MagicMock()
        task_manager.get_all_executions.return_value = [mock_exec]

        config = StatusStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_status_events(
            "test_project",
            storage_checker=storage_checker,
            task_manager_getter=MagicMock(return_value=task_manager),
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        start_events = [e for e in events if "execution_start" in e]
        assert len(start_events) >= 1


class TestGeneratorIterationLimit:
    """Tests for generator iteration limits."""

    async def test_log_generator_respects_max_iterations(self, tmp_path):
        """Test log generator respects max_iterations limit."""
        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)

        assert len(events) >= 1
        connected_events = [e for e in events if "connected" in e]
        assert len(connected_events) == 1

    async def test_status_generator_respects_max_iterations(self):
        """Test status generator respects max_iterations limit."""
        storage_checker = MagicMock(return_value=["test_project"])
        task_manager = MagicMock(get_all_executions=MagicMock(return_value=[]))
        config = StatusStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_status_events(
            "test_project",
            storage_checker=storage_checker,
            task_manager_getter=MagicMock(return_value=task_manager),
            config=config,
        ):
            events.append(event)

        assert len(events) >= 1
        connected_events = [e for e in events if "connected" in e]
        assert len(connected_events) == 1


class TestProjectNotFound:
    """Tests for project not found handling."""

    async def test_log_generator_project_not_found(self):
        """Test log generator handles missing project."""
        storage_checker = MagicMock(return_value=["other_project"])
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "nonexistent_project",
            storage_checker=storage_checker,
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        assert len(events) >= 1
        error_events = [e for e in events if "event: error" in e]
        assert len(error_events) >= 1
        assert "Project not found" in events[0]

    async def test_status_generator_project_not_found(self):
        """Test status generator handles missing project."""
        storage_checker = MagicMock(return_value=["other_project"])
        config = StatusStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_status_events(
            "nonexistent_project",
            storage_checker=storage_checker,
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        assert len(events) >= 1
        error_events = [e for e in events if "event: error" in e]
        assert len(error_events) >= 1
        assert "Project not found" in events[0]


class TestHeartbeatEvents:
    """Tests for heartbeat event generation."""

    async def test_status_generator_yields_heartbeat(self):
        """Test status generator yields heartbeat events."""
        storage_checker = MagicMock(return_value=["test_project"])
        task_manager = MagicMock(get_all_executions=MagicMock(return_value=[]))
        config = StatusStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_status_events(
            "test_project",
            storage_checker=storage_checker,
            task_manager_getter=MagicMock(return_value=task_manager),
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        heartbeat_events = [e for e in events if "heartbeat" in e]
        assert len(heartbeat_events) >= 1


class TestRawLogHandling:
    """Tests for raw log line handling."""

    async def test_log_generator_handles_non_json_lines(self, tmp_path):
        """Test log generator handles non-JSON lines."""
        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\nplain text line\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        assert len(events) >= 1
        log_events = [e for e in events if "event: log" in e]
        assert len(log_events) >= 1


class TestSSEEventFormatting:
    """Tests for SSE event formatting."""

    def test_format_sse_with_complex_data(self):
        """Test format_sse with complex nested data."""
        data = {
            "user": {"id": 1, "name": "test"},
            "tags": ["a", "b", "c"],
            "count": 42,
        }
        result = format_sse("complex", data)
        assert "event: complex\n" in result
        assert result.endswith("\n\n")
        assert '"user"' in result
        assert '"tags"' in result

    def test_format_sse_with_unicode(self):
        """Test format_sse with unicode data."""
        data = {"message": "Hello 世界 🌍"}
        result = format_sse("unicode", data)
        assert "event: unicode\n" in result
        assert "Hello" in result

    def test_format_sse_with_special_chars(self):
        """Test format_sse with special characters."""
        data = {"message": "Line1\nLine2\tTabbed"}
        result = format_sse("special", data)
        assert "event: special\n" in result


class TestRouterEndpoints:
    """Tests for router endpoints structure."""

    def test_router_has_logs_endpoint(self):
        """Test router has /logs/{project_name} endpoint."""
        routes = [r.path for r in router.routes]
        assert any("/logs/{project_name}" in r for r in routes)

    def test_router_has_status_endpoint(self):
        """Test router has /status/{project_name} endpoint."""
        routes = [r.path for r in router.routes]
        assert any("/status/{project_name}" in r for r in routes)

    def test_router_has_events_endpoint(self):
        """Test router has /events/{project_name} endpoint."""
        routes = [r.path for r in router.routes]
        assert any("/events/{project_name}" in r for r in routes)


class TestDefaultDiLambdas:
    """Tests for default DI lambda functions (lines 133-136, 145)."""

    async def test_log_generator_creates_default_storage_checker(self, tmp_path):
        """Test log generator creates default storage_checker when None provided."""
        with patch("core.storage.Storage") as mock_storage_class:
            mock_storage = MagicMock()
            mock_storage.list_projects.return_value = ["test_project"]
            mock_storage.project_dir = tmp_path
            mock_storage_class.return_value = mock_storage

            log_file = tmp_path / "test_project" / "logs" / "execution.log"
            log_file.parent.mkdir(parents=True, exist_ok=True)
            log_file.write_text('{"level": "INFO"}\n')

            config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)
            events = []
            async for event in generate_log_events(
                "test_project",
                config=config,
            ):
                events.append(event)
                if len(events) >= 10:
                    break

            assert len(events) >= 1

    async def test_log_generator_creates_default_log_file_provider(self, tmp_path):
        """Test log generator creates default log_file_provider when None provided."""
        with patch("core.storage.Storage") as mock_storage_class:
            mock_storage = MagicMock()
            mock_storage.list_projects.return_value = ["test_project"]
            mock_storage.project_dir = tmp_path
            mock_storage_class.return_value = mock_storage

            log_file = tmp_path / "test_project" / "logs" / "execution.log"
            log_file.parent.mkdir(parents=True, exist_ok=True)
            log_file.write_text('{"level": "INFO"}\n')

            config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)
            events = []
            async for event in generate_log_events(
                "test_project",
                config=config,
            ):
                events.append(event)
                if len(events) >= 10:
                    break

            assert len(events) >= 1


class TestStatusGeneratorDefaultDI:
    """Tests for status generator default DI (lines 204-207, 232-235)."""

    async def test_status_generator_creates_default_storage_checker(self):
        """Test status generator creates default storage_checker when None provided."""
        with patch("core.storage.Storage") as mock_storage_class:
            mock_storage = MagicMock()
            mock_storage.list_projects.return_value = ["test_project"]
            mock_storage_class.return_value = mock_storage

            with patch("api.tasks.get_task_manager") as mock_get_task_manager:
                mock_task_manager = MagicMock()
                mock_task_manager.get_all_executions.return_value = []
                mock_get_task_manager.return_value = mock_task_manager

                config = StatusStreamerConfig(max_iterations=2, poll_interval=0.001)
                events = []
                async for event in generate_status_events(
                    "test_project",
                    config=config,
                ):
                    events.append(event)
                    if len(events) >= 10:
                        break

                assert len(events) >= 1

    async def test_status_generator_creates_default_task_manager(self):
        """Test status generator creates default task_manager_getter when None provided."""
        with patch("core.storage.Storage") as mock_storage_class:
            mock_storage = MagicMock()
            mock_storage.list_projects.return_value = ["test_project"]
            mock_storage_class.return_value = mock_storage

            with patch("api.tasks.get_task_manager") as mock_get_task_manager:
                mock_task_manager = MagicMock()
                mock_task_manager.get_all_executions.return_value = []
                mock_get_task_manager.return_value = mock_task_manager

                config = StatusStreamerConfig(max_iterations=2, poll_interval=0.001)
                events = []
                async for event in generate_status_events(
                    "test_project",
                    config=config,
                ):
                    events.append(event)
                    if len(events) >= 10:
                        break

                assert len(events) >= 1


class TestCancelledErrorHandling:
    """Tests for asyncio.CancelledError handling (lines 185, 232-235)."""

    async def test_log_generator_cancelled_error_handling(self, tmp_path):
        """Test log generator handles asyncio.CancelledError gracefully."""
        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=1000, poll_interval=0.001)

        gen = generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        )

        events = []
        async for event in gen:
            events.append(event)
            if len(events) >= 2:
                break

        gen.aclose()
        assert len(events) >= 2

    async def test_status_generator_cancelled_error_handling(self):
        """Test status generator handles asyncio.CancelledError gracefully."""
        storage_checker = MagicMock(return_value=["test_project"])
        task_manager = MagicMock(get_all_executions=MagicMock(return_value=[]))
        config = StatusStreamerConfig(max_iterations=1000, poll_interval=0.001)

        gen = generate_status_events(
            "test_project",
            storage_checker=storage_checker,
            task_manager_getter=MagicMock(return_value=task_manager),
            config=config,
        )

        events = []
        async for event in gen:
            events.append(event)
            if len(events) >= 3:
                break

        gen.aclose()
        assert len(events) >= 3


class TestStatusGeneratorExceptionHandling:
    """Tests for status generator exception handling (lines 277, 301-302)."""

    async def test_status_generator_task_manager_exception(self):
        """Test status generator handles task_manager.get_all_executions exception."""
        storage_checker = MagicMock(return_value=["test_project"])
        task_manager = MagicMock()
        task_manager.get_all_executions.side_effect = Exception("Database error")

        config = StatusStreamerConfig(max_iterations=2, poll_interval=0.001)

        async def mock_sleep(*args):
            pass

        with patch("asyncio.sleep", mock_sleep):
            events = []
            async for event in generate_status_events(
                "test_project",
                storage_checker=storage_checker,
                task_manager_getter=MagicMock(return_value=task_manager),
                config=config,
            ):
                events.append(event)
                if len(events) >= 10:
                    break

        assert len(events) >= 1
        error_events = [e for e in events if "event: error" in e or "Database error" in e]
        assert len(error_events) >= 1


class TestRawLogLineHandling:
    """Tests for raw log line handling (line 185 - JSONDecodeError path)."""

    async def test_log_generator_handles_malformed_json(self, tmp_path):
        """Test log generator handles malformed JSON lines as raw logs."""
        log_file = tmp_path / "execution.log"
        log_file.write_text("valid json\nmalformed {json\n")

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        assert len(events) >= 1
        raw_events = [e for e in events if "event: raw" in e]
        assert len(raw_events) >= 1


class TestStatusChangeDetectionEndpoint:
    """Tests for status change detection endpoint (line 277)."""

    async def test_status_generator_detects_status_change(self):
        """Test status generator yields status_change events."""
        from api.tasks import TaskStatus

        storage_checker = MagicMock(return_value=["test_project"])

        mock_execution1 = MagicMock()
        mock_execution1.execution_id = "exec1"
        mock_execution1.status = TaskStatus.PENDING
        mock_execution1.to_dict.return_value = {"execution_id": "exec1", "status": "pending"}

        mock_execution2 = MagicMock()
        mock_execution2.execution_id = "exec1"
        mock_execution2.status = TaskStatus.RUNNING
        mock_execution2.to_dict.return_value = {"execution_id": "exec1", "status": "running"}

        task_manager = MagicMock()
        task_manager.get_all_executions.side_effect = [
            [mock_execution1],
            [mock_execution2],
        ]

        config = StatusStreamerConfig(max_iterations=3, poll_interval=0.001)

        async def mock_sleep(*args):
            pass

        with patch("asyncio.sleep", mock_sleep):
            events = []
            async for event in generate_status_events(
                "test_project",
                storage_checker=storage_checker,
                task_manager_getter=MagicMock(return_value=task_manager),
                config=config,
            ):
                events.append(event)
                if len(events) >= 20:
                    break

        status_change_events = [e for e in events if "status_change" in e]
        assert len(status_change_events) >= 1


class TestStreamAllEvents:
    """Tests for stream_all_events endpoint (lines 388-417)."""

    async def test_generate_all_events_combines_logs_and_status(self, tmp_path):
        """Test generate_all_events yields both log and status events."""
        from api.routers.streaming import stream_all_events

        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n')

        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["test_project"]
            mock_instance.project_dir = tmp_path
            mock_storage.return_value = mock_instance

            with patch("api.tasks.get_task_manager") as mock_get_tm:
                mock_task_manager = MagicMock()
                mock_task_manager.get_all_executions.return_value = []
                mock_get_tm.return_value = mock_task_manager

                with patch("api.routers.streaming.generate_log_events") as mock_log_gen:
                    with patch("api.routers.streaming.generate_status_events") as mock_status_gen:
                        mock_log_gen.return_value = iter(
                            [
                                "event: log\ndata: {}\n\n",
                            ]
                        )
                        mock_status_gen.return_value = iter(
                            [
                                "event: heartbeat\ndata: {}\n\n",
                            ]
                        )

                        gen = stream_all_events("test_project")
                        response = StreamingResponse(
                            gen,
                            media_type="text/event-stream",
                            headers=build_stream_headers(),
                        )

                        assert response.media_type == "text/event-stream"


class TestParseEventTypes:
    """Tests for parse_event_types function used in stream_logs (lines 338-342)."""

    def test_parse_event_types_with_events_param(self):
        """Test parse_event_types parses comma-separated events."""
        result = parse_event_types("log,raw,status")
        assert "log" in result
        assert "raw" in result
        assert "status" in result

    def test_parse_event_types_none_returns_none(self):
        """Test parse_event_types returns None when events is None."""
        result = parse_event_types(None)
        assert result is None


class TestStreamLogsEndpoint:
    """Tests for stream_logs endpoint (lines 338-342)."""

    async def test_stream_logs_endpoint_integration(self, tmp_path):
        """Test stream_logs endpoint returns StreamingResponse."""
        from api.routers.streaming import stream_logs

        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["test_project"]
            mock_instance.project_dir = tmp_path
            mock_storage.return_value = mock_instance

            log_file = tmp_path / "test_project" / "logs" / "execution.log"
            log_file.parent.mkdir(parents=True, exist_ok=True)
            log_file.write_text('{"level": "INFO"}\n')

            response = await stream_logs("test_project", level=LogLevel.INFO, events=None)

            assert isinstance(response, StreamingResponse)
            assert response.media_type == "text/event-stream"


class TestStreamStatusEndpoint:
    """Tests for stream_status endpoint (lines 364-366)."""

    async def test_stream_status_endpoint_returns_streaming_response(self):
        """Test stream_status endpoint returns StreamingResponse."""
        from api.routers.streaming import stream_status

        with patch("core.storage.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["test_project"]
            mock_storage.return_value = mock_instance

            with patch("api.tasks.get_task_manager") as mock_get_tm:
                mock_task_manager = MagicMock()
                mock_task_manager.get_all_executions.return_value = []
                mock_get_tm.return_value = mock_task_manager

                response = await stream_status("test_project")

                assert isinstance(response, StreamingResponse)
                assert response.media_type == "text/event-stream"


class TestExecutionCompleteEvent:
    """Tests for execution_complete event (line 301-302)."""

    async def test_status_generator_yields_execution_complete(self):
        """Test status generator yields execution_complete when execution disappears."""
        from api.tasks import TaskStatus

        storage_checker = MagicMock(return_value=["test_project"])

        mock_execution1 = MagicMock()
        mock_execution1.execution_id = "exec1"
        mock_execution1.status = TaskStatus.PENDING
        mock_execution1.to_dict.return_value = {"execution_id": "exec1", "status": "pending"}

        mock_execution2 = MagicMock()
        mock_execution2.execution_id = "exec1"
        mock_execution2.status = TaskStatus.PENDING
        mock_execution2.to_dict.return_value = {"execution_id": "exec1", "status": "pending"}

        task_manager = MagicMock()
        task_manager.get_all_executions.side_effect = [
            [mock_execution1],
            [mock_execution2],
            [],
        ]

        config = StatusStreamerConfig(max_iterations=4, poll_interval=0.001)

        async def mock_sleep(*args):
            pass

        with patch("asyncio.sleep", mock_sleep):
            events = []
            async for event in generate_status_events(
                "test_project",
                storage_checker=storage_checker,
                task_manager_getter=MagicMock(return_value=task_manager),
                config=config,
            ):
                events.append(event)
                if len(events) >= 20:
                    break

        complete_events = [e for e in events if "execution_complete" in e]
        assert len(complete_events) >= 1


class TestEmptyLineSkip:
    """Tests for empty line skipping in log generator (line 182)."""

    async def test_log_generator_skips_empty_lines(self, tmp_path):
        """Test log generator skips blank lines between JSON entries."""
        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n\n{"level": "ERROR"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        log_events = [e for e in events if "event: log" in e]
        assert len(log_events) >= 2


class TestLogGeneratorCancelledError:
    """Tests for CancelledError handling in log generator (lines 200-201)."""

    async def test_log_generator_yields_disconnected_on_cancel(self, tmp_path):
        """Test log generator yields disconnected event on CancelledError."""
        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=100, poll_interval=0.001)

        sleep_count = 0
        original_sleep = asyncio.sleep

        async def sleep_with_cancel(delay):
            nonlocal sleep_count
            sleep_count += 1
            if sleep_count >= 2:
                raise asyncio.CancelledError()
            await original_sleep(0)

        with patch("asyncio.sleep", sleep_with_cancel):
            events = []
            async for event in generate_log_events(
                "test_project",
                storage_checker=storage_checker,
                log_file_provider=log_file_provider,
                config=config,
            ):
                events.append(event)

        assert any("connected" in e for e in events)
        assert any("disconnected" in e for e in events)


class TestLogGeneratorGeneralException:
    """Tests for general exception handling in log generator (lines 203-204)."""

    async def test_log_generator_yields_error_on_exception(self, tmp_path):
        """Test log generator yields error event on general exception."""
        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=3, poll_interval=0.001)

        sleep_count = 0
        original_sleep = asyncio.sleep

        async def sleep_with_error(delay):
            nonlocal sleep_count
            sleep_count += 1
            if sleep_count == 2:
                raise RuntimeError("Simulated IO error")
            await original_sleep(0)

        with patch("asyncio.sleep", sleep_with_error):
            events = []
            async for event in generate_log_events(
                "test_project",
                storage_checker=storage_checker,
                log_file_provider=log_file_provider,
                config=config,
            ):
                events.append(event)
                if len(events) >= 15:
                    break

        assert any("connected" in e for e in events)
        assert any("event: error" in e for e in events)


class TestStatusGeneratorCancelledError:
    """Tests for CancelledError handling in status generator (lines 298-299)."""

    async def test_status_generator_yields_disconnected_on_cancel(self):
        """Test status generator yields disconnected event on CancelledError."""
        storage_checker = MagicMock(return_value=["test_project"])
        task_manager = MagicMock(get_all_executions=MagicMock(return_value=[]))
        config = StatusStreamerConfig(max_iterations=100, poll_interval=0.001)

        sleep_count = 0
        original_sleep = asyncio.sleep

        async def sleep_with_cancel(delay):
            nonlocal sleep_count
            sleep_count += 1
            if sleep_count >= 2:
                raise asyncio.CancelledError()
            await original_sleep(0)

        with patch("asyncio.sleep", sleep_with_cancel):
            events = []
            async for event in generate_status_events(
                "test_project",
                storage_checker=storage_checker,
                task_manager_getter=MagicMock(return_value=task_manager),
                config=config,
            ):
                events.append(event)

        assert any("connected" in e for e in events)
        assert any("disconnected" in e for e in events)


class TestStreamAllEventsCombined:
    """Tests for the combined stream_all_events generator (lines 385-424)."""

    async def test_stream_all_events_yields_log_and_status(self):
        """Test stream_all_events yields both log and status events."""
        from api.routers.streaming import stream_all_events

        async def mock_log_gen(project_name, *args, **kwargs):
            yield "event: log\ndata: test_log\n\n"

        async def mock_status_gen(project_name, *args, **kwargs):
            yield "event: heartbeat\ndata: test_hb\n\n"

        with (
            patch("api.routers.streaming.generate_log_events", mock_log_gen),
            patch("api.routers.streaming.generate_status_events", mock_status_gen),
        ):
            response = await stream_all_events("test_project")

            events = []
            async for chunk in response.body_iterator:
                text = chunk if isinstance(chunk, str) else chunk.decode()
                events.append(text)

            assert any("test_log" in e for e in events)
            assert any("test_hb" in e for e in events)

    async def test_stream_all_events_log_exhausted_first(self):
        """Test stream_all_events when log generator exhausts before status."""
        from api.routers.streaming import stream_all_events

        async def mock_log_gen_short(project_name, *args, **kwargs):
            yield "event: log\ndata: log1\n\n"

        async def mock_status_gen_multi(project_name, *args, **kwargs):
            yield "event: heartbeat\ndata: hb1\n\n"
            yield "event: heartbeat\ndata: hb2\n\n"

        with (
            patch("api.routers.streaming.generate_log_events", mock_log_gen_short),
            patch("api.routers.streaming.generate_status_events", mock_status_gen_multi),
        ):
            response = await stream_all_events("test_project")

            events = []
            async for chunk in response.body_iterator:
                text = chunk if isinstance(chunk, str) else chunk.decode()
                events.append(text)

            assert any("log1" in e for e in events)
            assert any("hb1" in e for e in events)

    async def test_stream_all_events_handles_cancelled(self):
        """Test stream_all_events closes generators on CancelledError."""
        from api.routers.streaming import stream_all_events

        async def mock_log_gen_cancel(project_name, *args, **kwargs):
            yield "event: log\ndata: log1\n\n"
            raise asyncio.CancelledError()

        async def mock_status_gen(project_name, *args, **kwargs):
            yield "event: heartbeat\ndata: hb1\n\n"

        with (
            patch("api.routers.streaming.generate_log_events", mock_log_gen_cancel),
            patch("api.routers.streaming.generate_status_events", mock_status_gen),
        ):
            response = await stream_all_events("test_project")

            events = []
            try:
                async for chunk in response.body_iterator:
                    text = chunk if isinstance(chunk, str) else chunk.decode()
                    events.append(text)
            except (asyncio.CancelledError, StopAsyncIteration, GeneratorExit, RuntimeError):
                pass

            assert len(events) >= 1

    async def test_stream_all_events_status_exhausts_in_else_branch(self):
        """Test else branch catches StopAsyncIteration from status gen (lines 415-416)."""
        from api.routers.streaming import stream_all_events

        async def mock_log_gen_two(project_name, *args, **kwargs):
            yield "event: log\ndata: log0\n\n"
            yield "event: log\ndata: log1\n\n"

        async def mock_status_gen_empty(project_name, *args, **kwargs):
            if False:
                yield

        with (
            patch("api.routers.streaming.generate_log_events", mock_log_gen_two),
            patch("api.routers.streaming.generate_status_events", mock_status_gen_empty),
        ):
            response = await stream_all_events("test_project")

            events = []
            async for chunk in response.body_iterator:
                text = chunk if isinstance(chunk, str) else chunk.decode()
                events.append(text)

            assert any("log0" in e for e in events)
            assert any("log1" in e for e in events)

    async def test_stream_all_events_cancelled_before_log_gen_assigned(self):
        """Test CancelledError before log_gen assigned covers branches 419->421."""
        from api.routers.streaming import stream_all_events

        def raise_cancelled(*args, **kwargs):
            raise asyncio.CancelledError()

        with (
            patch("api.routers.streaming.generate_log_events", raise_cancelled),
            patch("api.routers.streaming.generate_status_events", MagicMock()),
        ):
            response = await stream_all_events("test_project")

            events = []
            try:
                async for chunk in response.body_iterator:
                    text = chunk if isinstance(chunk, str) else chunk.decode()
                    events.append(text)
            except (asyncio.CancelledError, StopAsyncIteration, GeneratorExit, RuntimeError):
                pass

            assert len(events) == 0
