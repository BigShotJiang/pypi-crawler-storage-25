"""
Unit tests for suggestion data models.
"""

from datetime import datetime

import pytest
from pydantic import ValidationError

from core.suggestions.models import (
    ProactiveConfig,
    Suggestion,
    SuggestionCategory,
    SuggestionEvent,
    SuggestionRequest,
    SuggestionResponse,
    SuggestionSource,
    TriggerType,
)


class TestSuggestion:
    """Test Suggestion model."""

    def test_create_suggestion_minimal(self):
        """Test creating a suggestion with minimal fields."""
        suggestion = Suggestion(
            id="test_suggestion",
            name="Test Suggestion",
            description="A test suggestion",
            category=SuggestionCategory.GENRE,
        )

        assert suggestion.id == "test_suggestion"
        assert suggestion.name == "Test Suggestion"
        assert suggestion.source == SuggestionSource.STATIC
        assert suggestion.language == "en"
        assert suggestion.acceptance_rate == 0.5
        assert suggestion.acceptance_count == 0

    def test_create_suggestion_full(self):
        """Test creating a suggestion with all fields."""
        suggestion = Suggestion(
            id="test_full",
            name="Full Suggestion",
            description="Complete suggestion",
            category=SuggestionCategory.TECHNICAL,
            best_for=["Testing", "Development"],
            examples=["Example 1", "Example 2"],
            source=SuggestionSource.LEARNED,
            language="zh-CN",
            acceptance_rate=0.8,
            acceptance_count=10,
            accepted_count=8,
            metadata={"key": "value"},
        )

        assert suggestion.category == SuggestionCategory.TECHNICAL
        assert len(suggestion.best_for) == 2
        assert suggestion.source == SuggestionSource.LEARNED
        assert suggestion.language == "zh-CN"
        assert suggestion.acceptance_rate == 0.8

    def test_record_acceptance(self):
        """Test recording acceptance events."""
        suggestion = Suggestion(
            id="test_acceptance", name="Test", description="Test", category=SuggestionCategory.GENRE
        )

        suggestion.record_acceptance(True)
        assert suggestion.acceptance_count == 1
        assert suggestion.accepted_count == 1
        assert suggestion.acceptance_rate == 1.0

        suggestion.record_acceptance(False)
        assert suggestion.acceptance_count == 2
        assert suggestion.accepted_count == 1
        assert suggestion.acceptance_rate == 0.5

    def test_acceptance_rate_validation(self):
        """Test acceptance rate validation."""
        with pytest.raises(ValidationError):
            Suggestion(
                id="invalid",
                name="Invalid",
                description="Test",
                category=SuggestionCategory.GENRE,
                acceptance_rate=1.5,
            )

        with pytest.raises(ValidationError):
            Suggestion(
                id="invalid2",
                name="Invalid2",
                description="Test",
                category=SuggestionCategory.GENRE,
                acceptance_rate=-0.1,
            )

    def test_serialization(self):
        """Test JSON serialization."""
        suggestion = Suggestion(
            id="test_serialize",
            name="Serialize Test",
            description="Testing serialization",
            category=SuggestionCategory.WORKFLOW,
        )

        data = suggestion.model_dump(mode="json")
        assert data["id"] == "test_serialize"
        assert data["category"] == "workflow"

        new_suggestion = Suggestion(**data)
        assert new_suggestion.id == suggestion.id


class TestSuggestionEvent:
    """Test SuggestionEvent model."""

    def test_create_event_minimal(self):
        """Test creating an event with minimal fields."""
        event = SuggestionEvent(
            suggestion_id="test_suggestion",
            project_id="test_project",
            user_choice="Option 1",
            trigger_type=TriggerType.DECISION_POINT,
            suggestion_category=SuggestionCategory.GENRE,
        )

        assert event.suggestion_id == "test_suggestion"
        assert event.project_id == "test_project"
        assert event.accepted_dynamic is False
        assert event.acceptance_prompt_shown is False

    def test_create_event_full(self):
        """Test creating an event with all fields."""
        now = datetime.now()
        event = SuggestionEvent(
            suggestion_id="test",
            timestamp=now,
            project_id="project1",
            user_choice="Option 2",
            accepted_dynamic=True,
            project_context={"key": "value"},
            trigger_type=TriggerType.PHASE_TRANSITION,
            suggestion_category=SuggestionCategory.QUALITY,
            acceptance_prompt_shown=True,
            acceptance_prompt_response=True,
        )

        assert event.accepted_dynamic is True
        assert event.acceptance_prompt_response is True
        assert event.project_context["key"] == "value"


class TestProactiveConfig:
    """Test ProactiveConfig model."""

    def test_default_config(self):
        """Test default configuration."""
        config = ProactiveConfig()

        assert config.enabled is False
        assert config.continuous is False
        assert config.continuous_interval == 300

        assert config.is_category_enabled(SuggestionCategory.GENRE) is True
        assert config.is_category_enabled(SuggestionCategory.TECHNICAL) is True
        assert config.should_prompt_to_save() is True
        assert config.get_promote_threshold() == 5
        assert config.should_auto_add_accepted() is True

    def test_custom_config(self):
        """Test custom configuration."""
        config = ProactiveConfig(
            enabled=True,
            continuous=True,
            continuous_interval=600,
            suggestions={SuggestionCategory.GENRE: True, SuggestionCategory.TECHNICAL: False},
            learning={"auto_add_accepted": False, "prompt_to_save": False, "promote_threshold": 10},
        )

        assert config.enabled is True
        assert config.continuous is True
        assert config.continuous_interval == 600
        assert config.is_category_enabled(SuggestionCategory.GENRE) is True
        assert config.is_category_enabled(SuggestionCategory.TECHNICAL) is False
        assert config.should_prompt_to_save() is False
        assert config.get_promote_threshold() == 10
        assert config.should_auto_add_accepted() is False

    def test_continuous_interval_validation(self):
        """Test continuous interval validation."""
        with pytest.raises(ValidationError):
            ProactiveConfig(continuous_interval=30)

        with pytest.raises(ValidationError):
            ProactiveConfig(continuous_interval=-10)


class TestSuggestionRequest:
    """Test SuggestionRequest model."""

    def test_create_request(self):
        """Test creating a suggestion request."""
        request = SuggestionRequest(
            trigger_type=TriggerType.USER_REQUEST,
            project_id="test_project",
            category=SuggestionCategory.WORKFLOW,
            context={"genre": "fantasy"},
            max_suggestions=3,
        )

        assert request.trigger_type == TriggerType.USER_REQUEST
        assert request.category == SuggestionCategory.WORKFLOW
        assert request.max_suggestions == 3

    def test_request_defaults(self):
        """Test request default values."""
        request = SuggestionRequest(trigger_type=TriggerType.DECISION_POINT, project_id="test")

        assert request.category is None
        assert request.project_context == {}
        assert request.max_suggestions == 4
        assert request.language == "en"
        assert request.include_dynamic is True

    def test_max_suggestions_validation(self):
        """Test max_suggestions validation."""
        with pytest.raises(ValidationError):
            SuggestionRequest(
                trigger_type=TriggerType.USER_REQUEST, project_id="test", max_suggestions=0
            )

        with pytest.raises(ValidationError):
            SuggestionRequest(
                trigger_type=TriggerType.USER_REQUEST, project_id="test", max_suggestions=15
            )


class TestSuggestionResponse:
    """Test SuggestionResponse model."""

    def test_create_response(self):
        """Test creating a suggestion response."""
        suggestions = [
            Suggestion(
                id="s1",
                name="Suggestion 1",
                description="First suggestion",
                category=SuggestionCategory.GENRE,
            )
        ]

        response = SuggestionResponse(
            suggestions=suggestions,
            trigger_type=TriggerType.DECISION_POINT,
            category=SuggestionCategory.GENRE,
            formatted_suggestions="Here are your suggestions",
        )

        assert len(response.suggestions) == 1
        assert response.trigger_type == TriggerType.DECISION_POINT
        assert response.formatted_suggestions == "Here are your suggestions"
        assert response.show_suggestions is True
        assert response.presented_at is not None


class TestEnums:
    """Test enum values."""

    def test_suggestion_category(self):
        """Test SuggestionCategory enum."""
        assert SuggestionCategory.GENRE == "genre"
        assert SuggestionCategory.TECHNICAL == "technical"
        assert SuggestionCategory.WORKFLOW == "workflow"
        assert SuggestionCategory.QUALITY == "quality"

    def test_trigger_type(self):
        """Test TriggerType enum."""
        assert TriggerType.DECISION_POINT == "decision_point"
        assert TriggerType.PHASE_TRANSITION == "phase_transition"
        assert TriggerType.ISSUE_DETECTED == "issue_detected"
        assert TriggerType.USER_REQUEST == "user_request"
        assert TriggerType.CONTINUOUS == "continuous"

    def test_suggestion_source(self):
        """Test SuggestionSource enum."""
        assert SuggestionSource.STATIC == "static"
        assert SuggestionSource.DYNAMIC == "dynamic"
        assert SuggestionSource.LEARNED == "learned"
