from unittest.mock import MagicMock, patch

from core.workflow_executor import WorkflowExecutor


def _executor():
    with (
        patch("core.workflow_executor.WorkflowLoader") as wl,
        patch("core.workflow_executor.StepExecutor") as se,
    ):
        loader = MagicMock()
        wl.return_value = loader
        step_exec = MagicMock()
        se.return_value = step_exec
        executor = WorkflowExecutor(
            workflows_dir="/tmp/workflows",
            agent_integration=MagicMock(),
            storage=MagicMock(),
            git_manager=MagicMock(),
            work_dir="/tmp/work",
        )
    return executor, loader, step_exec


def _workflow():
    wf = MagicMock()
    wf.name = "wf"
    wf.version = "1.0"
    wf.description = "desc"
    wf.variables = {"a": 1}
    s1 = MagicMock()
    s1.step = 1
    s1.name = "s1"
    s2 = MagicMock()
    s2.step = 2
    s2.name = "s2"
    wf.steps = [s1, s2]
    return wf


def test_execute_workflow_success_and_outputs():
    executor, loader, step_exec = _executor()
    loader.load_workflow.return_value = _workflow()
    step_exec.execute_step.side_effect = [
        {"success": True, "output": {"x": 1}, "skipped": False},
        {"success": True, "output": {"y": 2}, "skipped": False},
    ]
    res = executor.execute_workflow("wf", "p", {"b": 2}, {"m": "x"})
    assert res["success"] is True
    assert len(res["executed_steps"]) == 2
    assert "s1" in res["step_outputs"]


def test_execute_workflow_with_skip_and_failure():
    executor, loader, step_exec = _executor()
    loader.load_workflow.return_value = _workflow()
    step_exec.execute_step.side_effect = [
        {"success": True, "output": {}, "skipped": True},
        {"success": False, "error": "boom", "skipped": False},
    ]
    res = executor.execute_workflow("wf", "p", {}, {})
    assert res["success"] is False
    assert len(res["failed_steps"]) == 1


def test_execute_workflow_loader_exception_returns_error():
    executor, loader, _ = _executor()
    loader.load_workflow.side_effect = RuntimeError("bad")
    res = executor.execute_workflow("wf", "p", {}, {})
    assert res["success"] is False
    assert "error" in res


def test_execute_workflow_with_loop_collects_failures():
    executor, _, _ = _executor()
    with patch.object(
        executor, "execute_workflow", side_effect=[{"success": True}, {"success": False}]
    ):
        res = executor.execute_workflow_with_loop("wf", "p", {}, {}, range(2))
        assert res["iterations"] == 2
        assert res["success"] is False
        assert res["failed_iterations"] == [1]


def test_list_workflows_and_get_info():
    executor, loader, _ = _executor()
    wf = _workflow()
    loader.load_all_workflows.return_value = [wf]
    listing = executor.list_workflows()
    assert listing == {"wf": "desc"}
    loader.load_workflow.return_value = wf
    info = executor.get_workflow_info("wf")
    assert info["name"] == "wf"
    assert info["step_count"] == 2


def test_get_workflow_info_on_error_returns_empty_dict():
    executor, loader, _ = _executor()
    loader.load_workflow.side_effect = Exception("x")
    assert executor.get_workflow_info("wf") == {}


def test_execute_workflow_with_loop_all_success():
    executor, _, _ = _executor()
    with patch.object(executor, "execute_workflow", return_value={"success": True}):
        res = executor.execute_workflow_with_loop("wf", "p", {}, {}, range(3))
        assert res["success"] is True
        assert res["failed_iterations"] == []


def test_get_workflow_info_contains_expected_keys():
    executor, loader, _ = _executor()
    wf = _workflow()
    loader.load_workflow.return_value = wf
    info = executor.get_workflow_info("wf")
    assert set(info.keys()) == {"name", "version", "description", "variables", "step_count"}
