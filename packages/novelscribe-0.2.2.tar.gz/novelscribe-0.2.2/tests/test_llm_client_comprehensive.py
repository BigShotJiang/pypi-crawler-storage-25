"""Comprehensive tests for LLM client coverage improvement."""

from unittest.mock import Mock, patch

import pytest

from core.llm_client import (
    ClaudeClient,
    GeminiClient,
    LLMClientFactory,
    LLMConfig,
    LLMError,
    LLMProvider,
    LLMResponse,
    LMStudioClient,
    MultiLLMClient,
    OllamaClient,
    OpenAIClient,
    ProviderNotFoundError,
)


class TestLLMProvider:
    """Test LLMProvider enum."""

    def test_provider_values(self):
        """Test provider enum values."""
        assert LLMProvider.OPENAI.value == "openai"
        assert LLMProvider.CLAUDE.value == "claude"
        assert LLMProvider.GEMINI.value == "gemini"
        assert LLMProvider.OLLAMA.value == "ollama"
        assert LLMProvider.LM_STUDIO.value == "lm_studio"

    def test_max_context_tokens_openai(self):
        """Test max context tokens for OpenAI."""
        assert LLMProvider.OPENAI.max_context_tokens() == 128000

    def test_max_context_tokens_claude(self):
        """Test max context tokens for Claude."""
        assert LLMProvider.CLAUDE.max_context_tokens() == 200000

    def test_max_context_tokens_gemini(self):
        """Test max context tokens for Gemini."""
        assert LLMProvider.GEMINI.max_context_tokens() == 1000000


class TestLLMConfig:
    """Test LLMConfig model."""

    def test_default_config(self):
        """Test default configuration."""
        config = LLMConfig()
        assert config.provider == "openai"
        assert config.model == "gpt-4o"
        assert config.temperature == 0.7
        assert config.max_tokens == 4096
        assert config.api_key == ""
        assert config.base_url == ""
        assert config.timeout == 120
        assert config.streaming is False

    def test_custom_config(self):
        """Test custom configuration."""
        config = LLMConfig(
            provider="claude",
            model="claude-3-opus",
            temperature=0.5,
            max_tokens=2048,
            api_key="test-key",
            base_url="https://api.anthropic.com",
            timeout=60,
            streaming=True,
        )
        assert config.provider == "claude"
        assert config.model == "claude-3-opus"
        assert config.temperature == 0.5
        assert config.api_key == "test-key"


class TestLLMResponse:
    """Test LLMResponse model."""

    def test_create_response(self):
        """Test creating LLM response."""
        response = LLMResponse(
            content="Test response",
            model="gpt-4",
            provider="openai",
            tokens_used=100,
            finish_reason="stop",
        )
        assert response.content == "Test response"
        assert response.model == "gpt-4"
        assert response.tokens_used == 100

    def test_response_optional_fields(self):
        """Test response with optional fields."""
        response = LLMResponse(
            content="Test response",
            model="gpt-4",
            provider="openai",
        )
        assert response.tokens_used is None
        assert response.finish_reason is None


class TestLLMClientFactoryMethods:
    """Test LLMClientFactory methods."""

    def test_create_openai_client(self):
        """Test creating OpenAI client."""
        config = LLMConfig(provider="openai", api_key="test-key")
        with patch("openai.OpenAI"):
            client = LLMClientFactory.create(config)
            assert isinstance(client, OpenAIClient)

    def test_create_claude_client(self):
        """Test creating Claude client."""
        config = LLMConfig(provider="claude", api_key="test-key")
        client = LLMClientFactory.create(config)
        assert isinstance(client, ClaudeClient)

    def test_create_gemini_client(self):
        """Test creating Gemini client."""
        mock_genai = Mock()
        mock_genai.Client = Mock()
        mock_genai_types = Mock()
        mock_genai.types = mock_genai_types
        config = LLMConfig(provider="gemini", api_key="test-key")
        with patch.dict(
            "sys.modules", {"google.genai": mock_genai, "google.genai.types": mock_genai_types}
        ):
            client = LLMClientFactory.create(config)
            assert isinstance(client, GeminiClient)

    def test_create_ollama_client(self):
        """Test creating Ollama client."""
        config = LLMConfig(provider="ollama")
        client = LLMClientFactory.create(config)
        assert isinstance(client, OllamaClient)

    def test_create_lm_studio_client(self):
        """Test creating LM Studio client."""
        config = LLMConfig(provider="lm_studio")
        client = LLMClientFactory.create(config)
        assert isinstance(client, LMStudioClient)

    def test_create_unknown_provider(self):
        """Test creating client with unknown provider."""
        config = LLMConfig(provider="unknown")
        with pytest.raises(ProviderNotFoundError):
            LLMClientFactory.create(config)

    def test_register_provider(self):
        """Test registering a new provider."""
        original_providers = LLMClientFactory._providers.copy()
        LLMClientFactory.register_provider("custom", Mock)
        assert "custom" in LLMClientFactory._providers
        LLMClientFactory._providers = original_providers

    def test_list_providers(self):
        """Test listing providers."""
        providers = LLMClientFactory.list_providers()
        assert "openai" in providers
        assert "claude" in providers
        assert "gemini" in providers


class TestOpenAIClient:
    """Test OpenAIClient class."""

    def test_initialization(self):
        """Test OpenAI client initialization."""
        config = LLMConfig(provider="openai", api_key="test-key")
        with patch("openai.OpenAI"):
            client = OpenAIClient(config)
            assert client.provider_name == "openai"

    def test_validate_config_with_api_key(self):
        """Test validation with API key."""
        config = LLMConfig(provider="openai", api_key="test-key")
        client = OpenAIClient(config)
        assert client.validate_config() is True

    @patch.dict("os.environ", {"OPENAI_API_KEY": "env-key"})
    def test_validate_config_from_env(self):
        """Test validation with API key from environment."""
        config = LLMConfig(provider="openai", api_key="")
        client = OpenAIClient(config)
        assert client.validate_config() is True

    @patch.dict("os.environ", {}, clear=True)
    def test_validate_config_no_key(self):
        """Test validation without API key."""
        config = LLMConfig(provider="openai", api_key="")
        client = OpenAIClient(config)
        assert client.validate_config() is False

    def test_format_messages_with_system(self):
        """Test formatting messages with system prompt."""
        config = LLMConfig(provider="openai", api_key="test-key")
        client = OpenAIClient(config)
        messages = client._format_messages("You are helpful.", "Hello!")
        assert len(messages) == 2
        assert messages[0]["role"] == "system"
        assert messages[1]["role"] == "user"

    def test_format_messages_without_system(self):
        """Test formatting messages without system prompt."""
        config = LLMConfig(provider="openai", api_key="test-key")
        client = OpenAIClient(config)
        messages = client._format_messages("", "Hello!")
        assert len(messages) == 1
        assert messages[0]["role"] == "user"

    @patch("openai.OpenAI")
    def test_generate_success(self, mock_openai):
        """Test successful generation."""
        config = LLMConfig(provider="openai", api_key="test-key")
        mock_client = Mock()
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Test response"
        mock_response.choices[0].finish_reason = "stop"
        mock_response.model = "gpt-4"
        mock_response.usage = Mock()
        mock_response.usage.total_tokens = 100
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client

        client = OpenAIClient(config)
        response = client.generate("System", "User")

        assert response.content == "Test response"
        assert response.provider == "openai"

    @patch.dict("os.environ", {"OPENAI_API_KEY": ""}, clear=True)
    def test_generate_without_api_key(self):
        """Test generation without API key."""
        config = LLMConfig(provider="openai", api_key="")
        client = OpenAIClient(config)
        with pytest.raises(LLMError):
            client.generate("System", "User")


class TestClaudeClient:
    """Test ClaudeClient class."""

    def test_initialization(self):
        """Test Claude client initialization."""
        config = LLMConfig(provider="claude", api_key="test-key")
        with patch("anthropic.Anthropic"):
            client = ClaudeClient(config)
            assert client.provider_name == "claude"

    def test_validate_config_with_api_key(self):
        """Test validation with API key."""
        config = LLMConfig(provider="claude", api_key="test-key")
        client = ClaudeClient(config)
        assert client.validate_config() is True

    @patch.dict("os.environ", {"ANTHROPIC_API_KEY": "env-key"})
    def test_validate_config_from_env(self):
        """Test validation with API key from environment."""
        config = LLMConfig(provider="claude", api_key="")
        client = ClaudeClient(config)
        assert client.validate_config() is True

    def test_validate_config_no_key(self):
        """Test validation without API key."""
        config = LLMConfig(provider="claude", api_key="")
        client = ClaudeClient(config)
        assert client.validate_config() is False

    @patch("anthropic.Anthropic")
    def test_generate_success(self, mock_anthropic):
        """Test successful generation."""
        config = LLMConfig(provider="claude", api_key="test-key")
        mock_client = Mock()
        mock_response = Mock()
        mock_response.content = [Mock()]
        mock_response.content[0].text = "Test response"
        mock_response.model = "claude-3"
        mock_response.usage = Mock()
        mock_response.usage.input_tokens = 50
        mock_response.usage.output_tokens = 50
        mock_response.stop_reason = "end_turn"
        mock_client.messages.create.return_value = mock_response
        mock_anthropic.return_value = mock_client

        client = ClaudeClient(config)
        response = client.generate("System", "User")

        assert response.content == "Test response"
        assert response.provider == "claude"
        assert response.tokens_used == 100


class TestGeminiClient:
    """Test GeminiClient class."""

    def _create_mock_google_genai(self):
        """Create mock google.genai module."""
        mock_genai = Mock()
        mock_genai.Client = Mock()
        mock_genai_types = Mock()
        mock_genai.types = mock_genai_types
        return mock_genai

    def test_initialization(self):
        """Test Gemini client initialization."""
        config = LLMConfig(provider="gemini", api_key="test-key")
        mock_genai = self._create_mock_google_genai()
        with patch.dict(
            "sys.modules", {"google.genai": mock_genai, "google.genai.types": mock_genai.types}
        ):
            client = GeminiClient(config)
            assert client.provider_name == "gemini"

    def test_validate_config_with_api_key(self):
        """Test validation with API key."""
        config = LLMConfig(provider="gemini", api_key="test-key")
        mock_genai = self._create_mock_google_genai()
        with patch.dict(
            "sys.modules", {"google.genai": mock_genai, "google.genai.types": mock_genai.types}
        ):
            client = GeminiClient(config)
            assert client.validate_config() is True

    @patch.dict("os.environ", {"GOOGLE_API_KEY": "env-key"})
    def test_validate_config_from_env(self):
        """Test validation with API key from environment."""
        config = LLMConfig(provider="gemini", api_key="")
        mock_genai = self._create_mock_google_genai()
        with patch.dict(
            "sys.modules", {"google.genai": mock_genai, "google.genai.types": mock_genai.types}
        ):
            client = GeminiClient(config)
            assert client.validate_config() is True

    def test_validate_config_no_key(self):
        """Test validation without API key."""
        config = LLMConfig(provider="gemini", api_key="")
        mock_genai = self._create_mock_google_genai()
        with patch.dict(
            "sys.modules", {"google.genai": mock_genai, "google.genai.types": mock_genai.types}
        ):
            client = GeminiClient(config)
            assert client.validate_config() is False


class TestOllamaClient:
    """Test OllamaClient class."""

    def test_initialization(self):
        """Test Ollama client initialization."""
        config = LLMConfig(provider="ollama")
        with patch("requests.post"):
            client = OllamaClient(config)
            assert client.provider_name == "ollama"

    def test_initialization_with_base_url(self):
        """Test Ollama client initialization with base URL."""
        config = LLMConfig(provider="ollama", base_url="http://localhost:11434")
        with patch("requests.post"):
            client = OllamaClient(config)
            assert client.base_url == "http://localhost:11434"

    @patch.dict("os.environ", {"OLLAMA_BASE_URL": "http://custom:11434"})
    def test_initialization_from_env(self):
        """Test Ollama client initialization from environment."""
        config = LLMConfig(provider="ollama")
        with patch("requests.post"):
            client = OllamaClient(config)
            assert client.base_url == "http://custom:11434"

    def test_validate_config(self):
        """Test validation always returns True."""
        config = LLMConfig(provider="ollama")
        client = OllamaClient(config)
        assert client.validate_config() is True


class TestLMStudioClient:
    """Test LMStudioClient class."""

    def test_initialization(self):
        """Test LM Studio client initialization."""
        config = LLMConfig(provider="lm_studio")
        with patch("openai.OpenAI"):
            client = LMStudioClient(config)
            assert client.provider_name == "lm_studio"

    def test_initialization_with_base_url(self):
        """Test LM Studio client initialization with base URL."""
        config = LLMConfig(provider="lm_studio", base_url="http://localhost:1234/v1")
        with patch("openai.OpenAI"):
            client = LMStudioClient(config)
            assert client.base_url == "http://localhost:1234/v1"

    def test_validate_config(self):
        """Test validation always returns True."""
        config = LLMConfig(provider="lm_studio")
        client = LMStudioClient(config)
        assert client.validate_config() is True


class TestMultiLLMClient:
    """Test MultiLLMClient class."""

    def test_initialization_without_fallback(self):
        """Test initialization without fallback."""
        config = LLMConfig(provider="openai", api_key="test-key")
        with patch("openai.OpenAI"):
            client = MultiLLMClient(config)
            assert client.primary_client is not None
            assert client.fallback_client is None

    def test_initialization_with_fallback(self):
        """Test initialization with fallback."""
        primary_config = LLMConfig(provider="openai", api_key="test-key")
        fallback_config = LLMConfig(provider="claude", api_key="test-key")

        with patch("openai.OpenAI"):
            with patch("anthropic.Anthropic"):
                client = MultiLLMClient(primary_config, fallback_config)
                assert client.primary_client is not None
                assert client.fallback_client is not None

    @patch.object(OpenAIClient, "generate")
    def test_generate_success(self, mock_generate):
        """Test successful generation without fallback."""
        mock_generate.return_value = LLMResponse(content="Test", model="gpt-4", provider="openai")

        config = LLMConfig(provider="openai", api_key="test-key")
        client = MultiLLMClient(config)
        client.primary_client = Mock()
        client.primary_client.generate.return_value = mock_generate.return_value

        response = client.generate("System", "User")
        assert response.content == "Test"

    @patch.object(OpenAIClient, "generate")
    @patch.object(ClaudeClient, "generate")
    def test_generate_fallback_on_error(self, mock_claude, mock_openai):
        """Test fallback when primary fails."""
        mock_openai.side_effect = LLMError("OpenAI error")
        mock_claude.return_value = LLMResponse(
            content="Fallback", model="claude-3", provider="claude"
        )

        primary_config = LLMConfig(provider="openai", api_key="test-key")
        fallback_config = LLMConfig(provider="claude", api_key="test-key")

        with patch("openai.OpenAI"):
            with patch("anthropic.Anthropic"):
                client = MultiLLMClient(primary_config, fallback_config)
                client.primary_client.generate.side_effect = mock_openai.side_effect
                client.fallback_client.generate.return_value = mock_claude.return_value

                response = client.generate("System", "User")
                assert response.content == "Fallback"


class TestLLMError:
    """Test LLMError exception."""

    def test_raise_llm_error(self):
        """Test raising LLM error."""
        with pytest.raises(LLMError):
            raise LLMError("Test error")

    def test_raise_provider_not_found_error(self):
        """Test raising provider not found error."""
        with pytest.raises(ProviderNotFoundError):
            raise ProviderNotFoundError("Provider not found")


class TestLLMClientFactory:
    """Test LLMClientFactory class."""

    def test_create_openai_client(self):
        """Test creating OpenAI client."""
        config = LLMConfig(provider="openai", api_key="test-key")
        with patch("openai.OpenAI"):
            client = LLMClientFactory.create(config)
            assert isinstance(client, OpenAIClient)

    def test_create_claude_client(self):
        """Test creating Claude client."""
        config = LLMConfig(provider="claude", api_key="test-key")
        with patch("anthropic.Anthropic"):
            client = LLMClientFactory.create(config)
            assert isinstance(client, ClaudeClient)

    def test_create_gemini_client(self):
        """Test creating Gemini client."""
        mock_genai = Mock()
        mock_genai.Client = Mock()
        mock_genai_types = Mock()
        mock_genai.types = mock_genai_types
        config = LLMConfig(provider="gemini", api_key="test-key")
        with patch.dict(
            "sys.modules", {"google.genai": mock_genai, "google.genai.types": mock_genai_types}
        ):
            client = LLMClientFactory.create(config)
            assert isinstance(client, GeminiClient)

    def test_create_ollama_client(self):
        """Test creating Ollama client."""
        config = LLMConfig(provider="ollama")
        with patch("requests.post"):
            client = LLMClientFactory.create(config)
            assert isinstance(client, OllamaClient)

    def test_create_lm_studio_client(self):
        """Test creating LM Studio client."""
        config = LLMConfig(provider="lm_studio")
        with patch("openai.OpenAI"):
            client = LLMClientFactory.create(config)
            assert isinstance(client, LMStudioClient)

    def test_create_unknown_provider(self):
        """Test creating client with unknown provider."""
        config = LLMConfig(provider="unknown")
        with pytest.raises(ProviderNotFoundError):
            LLMClientFactory.create(config)

    def test_register_provider(self):
        """Test registering a new provider."""
        original_providers = LLMClientFactory._providers.copy()

        class CustomClient(OpenAIClient):
            pass

        LLMClientFactory.register_provider("custom", CustomClient)
        assert "custom" in LLMClientFactory._providers

        LLMClientFactory._providers = original_providers

    def test_list_providers(self):
        """Test listing available providers."""
        providers = LLMClientFactory.list_providers()
        assert "openai" in providers
        assert "claude" in providers
        assert "gemini" in providers
        assert "ollama" in providers
        assert "lm_studio" in providers


class TestLLMClientAbstract:
    """Test LLMClient abstract methods."""

    def test_format_messages_with_system(self):
        """Test _format_messages with system prompt."""
        config = LLMConfig(provider="openai")
        with patch("openai.OpenAI"):
            client = OpenAIClient(config)
            messages = client._format_messages("System prompt", "User prompt")
            assert len(messages) == 2
            assert messages[0]["role"] == "system"
            assert messages[0]["content"] == "System prompt"
            assert messages[1]["role"] == "user"

    def test_format_messages_without_system(self):
        """Test _format_messages without system prompt."""
        config = LLMConfig(provider="openai")
        with patch("openai.OpenAI"):
            client = OpenAIClient(config)
            messages = client._format_messages("", "User prompt")
            assert len(messages) == 1
            assert messages[0]["role"] == "user"

    def test_format_messages_without_user(self):
        """Test _format_messages without user prompt."""
        config = LLMConfig(provider="openai")
        with patch("openai.OpenAI"):
            client = OpenAIClient(config)
            messages = client._format_messages("System prompt", "")
            assert len(messages) == 1
            assert messages[0]["role"] == "system"


class TestOpenAIClientCoverage:
    """Test OpenAIClient for coverage."""

    @patch.dict("os.environ", {}, clear=True)
    def test_validate_config_with_env_var(self):
        """Test validate_config with environment variable."""
        import os

        os.environ["OPENAI_API_KEY"] = "env-api-key"
        config = LLMConfig(provider="openai")
        with patch("openai.OpenAI"):
            client = OpenAIClient(config)
            assert client.validate_config() is True
        del os.environ["OPENAI_API_KEY"]

    @patch.dict("os.environ", {}, clear=True)
    def test_validate_config_without_key(self):
        """Test validate_config without API key."""
        config = LLMConfig(provider="openai", api_key="")
        with patch("openai.OpenAI"):
            client = OpenAIClient(config)
            assert client.validate_config() is False

    @patch.dict("os.environ", {}, clear=True)
    def test_generate_without_api_key(self):
        """Test generate without API key raises error."""
        config = LLMConfig(provider="openai", api_key="")
        with patch("openai.OpenAI"):
            client = OpenAIClient(config)
            with pytest.raises(LLMError, match="OpenAI API key not configured"):
                client.generate("System", "User")

    @patch.dict("os.environ", {}, clear=True)
    def test_generate_with_history_without_api_key(self):
        """Test generate_with_history without API key raises error."""
        config = LLMConfig(provider="openai", api_key="")
        with patch("openai.OpenAI"):
            client = OpenAIClient(config)
            with pytest.raises(LLMError, match="OpenAI API key not configured"):
                client.generate_with_history([{"role": "user", "content": "Hello"}])

    def test_generate_api_error(self):
        """Test generate with API error."""
        config = LLMConfig(provider="openai", api_key="test-key")
        with patch("openai.OpenAI") as mock_openai:
            mock_client = Mock()
            mock_client.chat.completions.create.side_effect = Exception("API Error")
            mock_openai.return_value = mock_client

            client = OpenAIClient(config)
            with pytest.raises(LLMError, match="OpenAI API error"):
                client.generate("System", "User")


class TestClaudeClientCoverage:
    """Test ClaudeClient for coverage."""

    @patch.dict("os.environ", {}, clear=True)
    def test_validate_config_with_env_var(self):
        """Test validate_config with environment variable."""
        import os

        os.environ["ANTHROPIC_API_KEY"] = "env-api-key"
        config = LLMConfig(provider="claude")
        with patch("anthropic.Anthropic"):
            client = ClaudeClient(config)
            assert client.validate_config() is True
        del os.environ["ANTHROPIC_API_KEY"]

    @patch.dict("os.environ", {}, clear=True)
    def test_validate_config_without_key(self):
        """Test validate_config without API key."""
        config = LLMConfig(provider="claude", api_key="")
        with patch("anthropic.Anthropic"):
            client = ClaudeClient(config)
            assert client.validate_config() is False

    def test_generate_without_api_key(self):
        """Test generate without API key raises error."""
        config = LLMConfig(provider="claude", api_key="")
        with patch("anthropic.Anthropic"):
            client = ClaudeClient(config)
            with pytest.raises(LLMError, match="Anthropic API key not configured"):
                client.generate("System", "User")

    def test_generate_with_history_without_api_key(self):
        """Test generate_with_history without API key raises error."""
        config = LLMConfig(provider="claude", api_key="")
        with patch("anthropic.Anthropic"):
            client = ClaudeClient(config)
            with pytest.raises(LLMError, match="Anthropic API key not configured"):
                client.generate_with_history([{"role": "user", "content": "Hello"}])

    def test_generate_with_history_with_system(self):
        """Test generate_with_history extracts system prompt."""
        config = LLMConfig(provider="claude", api_key="test-key")
        with patch("anthropic.Anthropic") as mock_anthropic:
            mock_client = Mock()
            mock_response = Mock()
            mock_response.content = [Mock(text="Response")]
            mock_response.model = "claude-3"
            mock_response.usage.input_tokens = 10
            mock_response.usage.output_tokens = 20
            mock_response.stop_reason = "stop"
            mock_client.messages.create.return_value = mock_response
            mock_anthropic.return_value = mock_client

            client = ClaudeClient(config)
            messages = [
                {"role": "system", "content": "System prompt"},
                {"role": "user", "content": "Hello"},
            ]
            response = client.generate_with_history(messages)
            assert response.content == "Response"

    def test_generate_api_error(self):
        """Test generate with API error."""
        config = LLMConfig(provider="claude", api_key="test-key")
        with patch("anthropic.Anthropic") as mock_anthropic:
            mock_client = Mock()
            mock_client.messages.create.side_effect = Exception("API Error")
            mock_anthropic.return_value = mock_client

            client = ClaudeClient(config)
            with pytest.raises(LLMError, match="Claude API error"):
                client.generate("System", "User")


class TestGeminiClientCoverage:
    """Test GeminiClient for coverage."""

    def _create_mock_google_genai(self, client_mock=None):
        """Create mock google.genai module."""
        mock_genai = Mock()
        mock_client = client_mock or Mock()
        mock_genai.Client = Mock(return_value=mock_client)
        mock_genai_types = Mock()
        mock_genai.types = mock_genai_types
        return mock_genai, mock_client

    @patch.dict("os.environ", {}, clear=True)
    def test_validate_config_with_env_var(self):
        """Test validate_config with environment variable."""
        import os

        os.environ["GOOGLE_API_KEY"] = "env-api-key"
        config = LLMConfig(provider="gemini")
        mock_genai, _ = self._create_mock_google_genai()
        with patch.dict(
            "sys.modules", {"google.genai": mock_genai, "google.genai.types": mock_genai.types}
        ):
            client = GeminiClient(config)
            assert client.validate_config() is True
        del os.environ["GOOGLE_API_KEY"]

    @patch.dict("os.environ", {}, clear=True)
    def test_validate_config_without_key(self):
        """Test validate_config without API key."""
        config = LLMConfig(provider="gemini", api_key="")
        mock_genai, _ = self._create_mock_google_genai()
        with patch.dict(
            "sys.modules", {"google.genai": mock_genai, "google.genai.types": mock_genai.types}
        ):
            client = GeminiClient(config)
            assert client.validate_config() is False

    def test_generate_without_api_key(self):
        """Test generate without API key raises error."""
        config = LLMConfig(provider="gemini", api_key="")
        mock_genai, _ = self._create_mock_google_genai()
        with patch.dict(
            "sys.modules", {"google.genai": mock_genai, "google.genai.types": mock_genai.types}
        ):
            client = GeminiClient(config)
            with pytest.raises(LLMError, match="Google API key not configured"):
                client.generate("System", "User")

    def test_generate_with_history_without_api_key(self):
        """Test generate_with_history without API key raises error."""
        config = LLMConfig(provider="gemini", api_key="")
        mock_genai, _ = self._create_mock_google_genai()
        with patch.dict(
            "sys.modules", {"google.genai": mock_genai, "google.genai.types": mock_genai.types}
        ):
            client = GeminiClient(config)
            with pytest.raises(LLMError, match="Google API key not configured"):
                client.generate_with_history([{"role": "user", "content": "Hello"}])

    def test_generate_api_error(self):
        """Test generate with API error."""
        config = LLMConfig(provider="gemini", api_key="test-key")
        mock_client = Mock()
        mock_client.models.generate_content.side_effect = Exception("API Error")
        mock_genai, _ = self._create_mock_google_genai(client_mock=mock_client)
        with patch.dict(
            "sys.modules", {"google.genai": mock_genai, "google.genai.types": mock_genai.types}
        ):
            client = GeminiClient(config)
            with pytest.raises(LLMError, match="Gemini API error"):
                client.generate("System", "User")

    def test_generate_with_history_api_error(self):
        """Test generate_with_history with API error."""
        config = LLMConfig(provider="gemini", api_key="test-key")
        mock_client = Mock()
        mock_client.models.generate_content.side_effect = Exception("API Error")
        mock_genai, _ = self._create_mock_google_genai(client_mock=mock_client)
        with patch.dict(
            "sys.modules", {"google.genai": mock_genai, "google.genai.types": mock_genai.types}
        ):
            client = GeminiClient(config)
            with pytest.raises(LLMError, match="Gemini API error"):
                client.generate_with_history([{"role": "user", "content": "Hello"}])

    def test_generate_with_system_prompt(self):
        """Test generate with system prompt."""
        config = LLMConfig(provider="gemini", api_key="test-key")
        mock_response = Mock()
        mock_response.text = "Response"
        mock_response.candidates = []
        mock_response.usage_metadata = Mock(total_token_count=100)
        mock_client = Mock()
        mock_client.models.generate_content.return_value = mock_response
        mock_genai, _ = self._create_mock_google_genai(client_mock=mock_client)
        with patch.dict(
            "sys.modules", {"google.genai": mock_genai, "google.genai.types": mock_genai.types}
        ):
            client = GeminiClient(config)
            response = client.generate("System", "User")
            assert response.content == "Response"


class TestOllamaClientCoverage:
    """Test OllamaClient for coverage."""

    def test_validate_config(self):
        """Test validate_config always returns True."""
        config = LLMConfig(provider="ollama")
        with patch("requests.post"):
            client = OllamaClient(config)
            assert client.validate_config() is True

    def test_generate_success(self):
        """Test successful generate."""
        config = LLMConfig(provider="ollama", model="llama2")
        with patch("requests.post") as mock_post:
            mock_response = Mock()
            mock_response.json.return_value = {
                "message": {"content": "Response"},
                "prompt_eval_count": 10,
                "eval_count": 20,
            }
            mock_post.return_value = mock_response

            client = OllamaClient(config)
            response = client.generate("System", "User")
            assert response.content == "Response"
            assert response.tokens_used == 30

    def test_generate_with_history_success(self):
        """Test successful generate_with_history."""
        config = LLMConfig(provider="ollama", model="llama2")
        with patch("requests.post") as mock_post:
            mock_response = Mock()
            mock_response.json.return_value = {
                "message": {"content": "Response"},
                "prompt_eval_count": 10,
                "eval_count": 20,
            }
            mock_post.return_value = mock_response

            client = OllamaClient(config)
            response = client.generate_with_history([{"role": "user", "content": "Hello"}])
            assert response.content == "Response"

    def test_generate_api_error(self):
        """Test generate with API error."""
        config = LLMConfig(provider="ollama")
        with patch("requests.post") as mock_post:
            mock_post.side_effect = Exception("API Error")

            client = OllamaClient(config)
            with pytest.raises(LLMError, match="Ollama API error"):
                client.generate("System", "User")

    def test_generate_with_history_api_error(self):
        """Test generate_with_history with API error."""
        config = LLMConfig(provider="ollama")
        with patch("requests.post") as mock_post:
            mock_post.side_effect = Exception("API Error")

            client = OllamaClient(config)
            with pytest.raises(LLMError, match="Ollama API error"):
                client.generate_with_history([{"role": "user", "content": "Hello"}])


class TestLMStudioClientCoverage:
    """Test LMStudioClient for coverage."""

    def test_validate_config(self):
        """Test validate_config always returns True."""
        config = LLMConfig(provider="lm_studio")
        with patch("openai.OpenAI"):
            client = LMStudioClient(config)
            assert client.validate_config() is True

    def test_initialization_with_base_url(self):
        """Test initialization with base URL."""
        config = LLMConfig(provider="lm_studio", base_url="http://custom:1234/v1")
        with patch("openai.OpenAI") as mock_openai:
            LMStudioClient(config)
            mock_openai.assert_called_once()

    def test_generate_success(self):
        """Test successful generate."""
        config = LLMConfig(provider="lm_studio", model="model")
        with patch("openai.OpenAI") as mock_openai:
            mock_client = Mock()
            mock_response = Mock()
            mock_response.choices = [Mock(message=Mock(content="Response"), finish_reason="stop")]
            mock_response.usage = Mock(total_tokens=100)
            mock_client.chat.completions.create.return_value = mock_response
            mock_openai.return_value = mock_client

            client = LMStudioClient(config)
            response = client.generate("System", "User")
            assert response.content == "Response"

    def test_generate_with_history_success(self):
        """Test successful generate_with_history."""
        config = LLMConfig(provider="lm_studio", model="model")
        with patch("openai.OpenAI") as mock_openai:
            mock_client = Mock()
            mock_response = Mock()
            mock_response.choices = [Mock(message=Mock(content="Response"), finish_reason="stop")]
            mock_response.usage = Mock(total_tokens=100)
            mock_client.chat.completions.create.return_value = mock_response
            mock_openai.return_value = mock_client

            client = LMStudioClient(config)
            response = client.generate_with_history([{"role": "user", "content": "Hello"}])
            assert response.content == "Response"

    def test_generate_api_error(self):
        """Test generate with API error."""
        config = LLMConfig(provider="lm_studio", model="model")
        with patch("openai.OpenAI") as mock_openai:
            mock_client = Mock()
            mock_client.chat.completions.create.side_effect = Exception("API Error")
            mock_openai.return_value = mock_client

            client = LMStudioClient(config)
            with pytest.raises(LLMError, match="LM Studio API error"):
                client.generate("System", "User")

    def test_generate_with_history_api_error(self):
        """Test generate_with_history with API error."""
        config = LLMConfig(provider="lm_studio", model="model")
        with patch("openai.OpenAI") as mock_openai:
            mock_client = Mock()
            mock_client.chat.completions.create.side_effect = Exception("API Error")
            mock_openai.return_value = mock_client

            client = LMStudioClient(config)
            with pytest.raises(LLMError, match="LM Studio API error"):
                client.generate_with_history([{"role": "user", "content": "Hello"}])


class TestMultiLLMClientCoverage:
    """Test MultiLLMClient for additional coverage."""

    def test_generate_with_fallback_success(self):
        """Test generate with fallback success."""
        config = LLMConfig(provider="openai", api_key="test-key")
        with patch("openai.OpenAI"):
            client = MultiLLMClient(config)
            client.primary_client = Mock()
            mock_response = LLMResponse(content="Primary", model="gpt-4", provider="openai")
            client.primary_client.generate.return_value = mock_response

            response = client.generate("System", "User")
            assert response.content == "Primary"

    def test_generate_with_history_fallback_success(self):
        """Test generate_with_history with fallback success."""
        config = LLMConfig(provider="openai", api_key="test-key")
        with patch("openai.OpenAI"):
            client = MultiLLMClient(config)
            client.primary_client = Mock()
            mock_response = LLMResponse(content="Primary", model="gpt-4", provider="openai")
            client.primary_client.generate_with_history.return_value = mock_response

            response = client.generate_with_history([{"role": "user", "content": "Hello"}])
            assert response.content == "Primary"

    def test_generate_without_fallback_error(self):
        """Test generate without fallback re-raises error."""
        config = LLMConfig(provider="openai", api_key="test-key")
        with patch("openai.OpenAI"):
            client = MultiLLMClient(config)
            client.primary_client = Mock()
            client.primary_client.generate.side_effect = LLMError("Error")
            client.fallback_client = None

            with pytest.raises(LLMError):
                client.generate("System", "User")

    def test_generate_with_history_without_fallback_error(self):
        """Test generate_with_history without fallback re-raises error."""
        config = LLMConfig(provider="openai", api_key="test-key")
        with patch("openai.OpenAI"):
            client = MultiLLMClient(config)
            client.primary_client = Mock()
            client.primary_client.generate_with_history.side_effect = LLMError("Error")
            client.fallback_client = None

            with pytest.raises(LLMError):
                client.generate_with_history([{"role": "user", "content": "Hello"}])


class TestLLMClientMissingCoverage:
    """Tests for missing coverage in llm_client.py."""

    def test_openai_client_import_error(self):
        """Test OpenAIClient with missing openai package (lines 117-118)."""
        config = LLMConfig(provider="openai")
        with patch.dict("sys.modules", {"openai": None}):
            with pytest.raises(LLMError, match="OpenAI package not installed"):
                OpenAIClient(config)

    def test_openai_generate_with_history_no_api_key(self):
        """Test OpenAIClient.generate_with_history with no key (lines 154-170)."""
        config = LLMConfig(provider="openai", api_key="")
        with patch.dict("os.environ", {"OPENAI_API_KEY": ""}):
            with patch("openai.OpenAI"):
                client = OpenAIClient(config)
                with pytest.raises(LLMError, match="API key not configured"):
                    client.generate_with_history([{"role": "user", "content": "test"}])

    def test_claude_client_import_error(self):
        """Test ClaudeClient with missing anthropic package (lines 182-183)."""
        config = LLMConfig(provider="claude", api_key="test")
        with patch.dict("sys.modules", {"anthropic": None}):
            with pytest.raises(LLMError, match="Anthropic package not installed"):
                ClaudeClient(config)

    def test_gemini_client_import_error(self):
        """Test GeminiClient with missing google-genai (lines 243-244)."""
        config = LLMConfig(provider="gemini", api_key="test")
        with patch.dict(
            "sys.modules", {"google": None, "google.genai": None, "google.genai.types": None}
        ):
            with pytest.raises(LLMError, match="Google Gemini package not installed"):
                GeminiClient(config)

    def test_ollama_client_import_error(self):
        """Test OllamaClient with missing requests (lines 309-311)."""
        config = LLMConfig(provider="ollama")
        with patch.dict("sys.modules", {"requests": None}):
            with pytest.raises(LLMError, match="Requests package not installed"):
                OllamaClient(config)

    def test_lm_studio_client_import_error(self):
        """Test LMStudioClient with missing openai (lines 430-431)."""
        config = LLMConfig(provider="lm_studio")
        with patch.dict("sys.modules", {"openai": None}):
            with pytest.raises(LLMError, match="OpenAI package not installed"):
                LMStudioClient(config)

    def test_openai_client_with_base_url(self):
        """Test OpenAIClient with custom base_url (line 114)."""
        config = LLMConfig(provider="openai", api_key="test", base_url="http://localhost:1234/v1")
        with patch("openai.OpenAI") as mock_openai:
            OpenAIClient(config)
            mock_openai.assert_called_once()

    def test_openai_client_no_base_url(self):
        """Test OpenAIClient without custom base_url (line 113)."""
        config = LLMConfig(provider="openai", api_key="test", base_url="")
        with patch("openai.OpenAI"):
            OpenAIClient(config)

    def test_ollama_generate_with_history_error(self):
        """Test OllamaClient.generate_with_history error handling (line 332)."""
        config = LLMConfig(provider="ollama")
        with patch.dict(
            "sys.modules",
            {"requests": Mock(post=Mock(side_effect=Exception("Connection refused")))},
        ):
            client = OllamaClient(config)
            with pytest.raises(LLMError, match="Ollama API error"):
                client.generate_with_history([{"role": "user", "content": "test"}])

    def test_lm_studio_generate_with_history_error(self):
        """Test LMStudioClient.generate_with_history error (line 361-362)."""
        config = LLMConfig(provider="lm_studio")
        with patch("openai.OpenAI") as mock_openai:
            mock_instance = Mock()
            mock_instance.chat.completions.create.side_effect = Exception("LM Studio error")
            mock_openai.return_value = mock_instance
            client = LMStudioClient(config)
            with pytest.raises(LLMError, match="LM Studio API error"):
                client.generate_with_history([{"role": "user", "content": "test"}])

    def test_multi_llm_generate_with_history_fallback(self):
        """Test MultiLLMClient.generate_with_history with fallback (line 544)."""
        config = LLMConfig(provider="openai", api_key="test")
        fallback = LLMConfig(provider="ollama")
        mock_requests = Mock()
        with patch("openai.OpenAI"), patch.dict("sys.modules", {"requests": mock_requests}):
            client = MultiLLMClient(config, fallback)
            client.primary_client = Mock()
            client.fallback_client = Mock()
            client.primary_client.generate_with_history.side_effect = LLMError("Primary fail")
            mock_resp = LLMResponse(content="Fallback", model="test", provider="ollama")
            client.fallback_client.generate_with_history.return_value = mock_resp
            resp = client.generate_with_history([{"role": "user", "content": "test"}])
            assert resp.content == "Fallback"


class TestLLMClientMissingLines:
    """Tests for specific missing coverage lines in llm_client.py."""

    def test_openai_generate_with_history_success(self):
        """Test OpenAIClient.generate_with_history success (lines 154-170)."""
        config = LLMConfig(provider="openai", api_key="test-key")
        with patch("openai.OpenAI") as mock_openai:
            mock_client = Mock()
            mock_response = Mock()
            mock_response.choices = [
                Mock(message=Mock(content="History response"), finish_reason="stop")
            ]
            mock_response.model = "gpt-4"
            mock_response.usage = Mock(total_tokens=50)
            mock_client.chat.completions.create.return_value = mock_response
            mock_openai.return_value = mock_client

            client = OpenAIClient(config)
            response = client.generate_with_history([{"role": "user", "content": "Hello"}])
            assert response.content == "History response"
            assert response.tokens_used == 50

    def test_openai_generate_with_history_api_error(self):
        """Test OpenAIClient.generate_with_history API error (lines 169-170)."""
        config = LLMConfig(provider="openai", api_key="test-key")
        with patch("openai.OpenAI") as mock_openai:
            mock_client = Mock()
            mock_client.chat.completions.create.side_effect = Exception("API Error")
            mock_openai.return_value = mock_client

            client = OpenAIClient(config)
            with pytest.raises(LLMError, match="OpenAI API error"):
                client.generate_with_history([{"role": "user", "content": "Hello"}])

    def test_claude_generate_with_history_error(self):
        """Test ClaudeClient.generate_with_history error (lines 243-244)."""
        config = LLMConfig(provider="claude", api_key="test-key")
        with patch("anthropic.Anthropic") as mock_anthropic:
            mock_client = Mock()
            mock_client.messages.create.side_effect = Exception("Claude API Error")
            mock_anthropic.return_value = mock_client

            client = ClaudeClient(config)
            with pytest.raises(LLMError, match="Claude API error"):
                client.generate_with_history(
                    [
                        {"role": "system", "content": "System"},
                        {"role": "user", "content": "Hello"},
                    ]
                )

    def test_gemini_generate_with_history_assistant_role(self):
        """Test GeminiClient.generate_with_history with assistant messages (lines 309-311, 332)."""
        config = LLMConfig(provider="gemini", api_key="test-key")
        mock_response = Mock()
        mock_response.text = "Gemini response"
        mock_finish_reason = Mock()
        mock_finish_reason.name = "STOP"
        mock_response.candidates = [Mock(finish_reason=mock_finish_reason)]
        mock_response.usage_metadata = Mock(total_token_count=200)
        mock_client = Mock()
        mock_client.models.generate_content.return_value = mock_response

        mock_genai = Mock()
        mock_genai.Client = Mock(return_value=mock_client)

        mock_part = Mock()
        mock_content = Mock()
        mock_types = Mock()
        mock_types.Part = Mock(return_value=mock_part)
        mock_types.Content = Mock(return_value=mock_content)
        mock_types.GenerateContentConfig = Mock()
        mock_genai.types = mock_types

        with patch.dict(
            "sys.modules", {"google.genai": mock_genai, "google.genai.types": mock_types}
        ):
            client = GeminiClient(config)
            messages = [
                {"role": "user", "content": "Hello"},
                {"role": "assistant", "content": "Hi there"},
                {"role": "user", "content": "How are you?"},
            ]
            response = client.generate_with_history(messages)
            assert response.content == "Gemini response"
            assert response.tokens_used == 200

    def test_openai_generate_with_history_no_usage(self):
        """Test OpenAIClient.generate_with_history with no usage (line 166)."""
        config = LLMConfig(provider="openai", api_key="test-key")
        with patch("openai.OpenAI") as mock_openai:
            mock_client = Mock()
            mock_response = Mock()
            mock_response.choices = [Mock(message=Mock(content="No usage"), finish_reason="stop")]
            mock_response.model = "gpt-4"
            mock_response.usage = None
            mock_client.chat.completions.create.return_value = mock_response
            mock_openai.return_value = mock_client

            client = OpenAIClient(config)
            response = client.generate_with_history([{"role": "user", "content": "Hello"}])
            assert response.tokens_used is None
