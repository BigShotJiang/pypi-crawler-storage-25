"""
Simple tests for storage models.
"""

import pytest

from novel_harness.core.storage import (
    AgentDefinition,
    FileNotFoundError,
    FileParseError,
    FileWriteError,
    StorageConfig,
    StorageError,
    WorkflowDefinition,
)


class TestExceptions:
    """Test storage exceptions."""

    def test_storage_error(self):
        """Test StorageError can be raised."""
        with pytest.raises(StorageError):
            raise StorageError("Test error")

    def test_file_not_found_error(self):
        """Test FileNotFoundError can be raised."""
        with pytest.raises(FileNotFoundError):
            raise FileNotFoundError("File not found")

    def test_file_parse_error(self):
        """Test FileParseError can be raised."""
        with pytest.raises(FileParseError):
            raise FileParseError("Parse error")

    def test_file_write_error(self):
        """Test FileWriteError can be raised."""
        with pytest.raises(FileWriteError):
            raise FileWriteError("Write error")


class TestStorageConfig:
    """Test StorageConfig model."""

    def test_defaults(self):
        """Test default values."""
        config = StorageConfig()
        assert config.backend == "file"
        assert config.base_path == ".novels"
        assert config.cache_enabled is True

    def test_custom(self):
        """Test custom values."""
        config = StorageConfig(backend="db", base_path="/data", cache_enabled=False)
        assert config.backend == "db"
        assert config.base_path == "/data"
        assert config.cache_enabled is False


class TestAgentDefinition:
    """Test AgentDefinition model."""

    def test_required_fields(self):
        """Test required fields."""
        agent = AgentDefinition(
            name="test", description="desc", model="gpt-4", system_prompt="prompt"
        )
        assert agent.name == "test"
        assert agent.temperature == 0.7
        assert agent.max_tokens == 4096

    def test_custom_values(self):
        """Test custom values."""
        agent = AgentDefinition(
            name="agent",
            description="desc",
            model="claude-3",
            system_prompt="prompt",
            temperature=0.9,
            max_tokens=8192,
        )
        assert agent.temperature == 0.9
        assert agent.max_tokens == 8192


class TestWorkflowDefinition:
    """Test WorkflowDefinition model."""

    def test_required_fields(self):
        """Test required fields."""
        workflow = WorkflowDefinition(name="test", description="desc", steps=[])
        assert workflow.name == "test"

    def test_custom_metadata(self):
        """Test metadata."""
        workflow = WorkflowDefinition(
            name="test", description="desc", steps=[], metadata={"key": "value"}
        )
        assert workflow.metadata["key"] == "value"
