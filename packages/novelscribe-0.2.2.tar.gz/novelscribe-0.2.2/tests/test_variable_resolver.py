"""Test coverage for core/variable_resolver.py."""

from core.variable_resolver import VariableResolver


class TestVariableResolver:
    def test_initialization(self):
        """Test resolver initialization"""
        resolver = VariableResolver()
        assert resolver.variables == {}
        assert resolver.step_outputs == {}

    def test_resolve_string_with_variable(self):
        """Test resolving variable in string"""
        resolver = VariableResolver()
        result = resolver.resolve("Hello ${name}", variables={"name": "World"})
        assert result == "Hello World"

    def test_resolve_string_with_dot_notation(self):
        """Test resolving variable with dot notation"""
        resolver = VariableResolver()
        result = resolver.resolve(
            "${project.meta.genre}", variables={"project": {"meta": {"genre": "fantasy"}}}
        )
        assert result == "fantasy"

    def test_resolve_string_from_step_outputs(self):
        """Test resolving variable from step outputs"""
        resolver = VariableResolver()
        result = resolver.resolve("${step1.output}", step_outputs={"step1": {"output": "result"}})
        assert result == "result"

    def test_resolve_nonexistent_variable(self):
        """Test resolving non-existent variable returns original"""
        resolver = VariableResolver()
        result = resolver.resolve("Hello ${nonexistent}")
        assert result == "Hello ${nonexistent}"

    def test_resolve_non_string_value(self):
        """Test resolving non-string value returns as-is"""
        resolver = VariableResolver()
        result = resolver.resolve(12345)
        assert result == 12345

    def test_resolve_dict_with_variables(self):
        """Test resolving variables in dictionary"""
        resolver = VariableResolver()
        data = {
            "greeting": "Hello ${name}",
            "age": 25,
            "nested": {"value": "${test}"},
        }
        result = resolver.resolve_dict(data, variables={"name": "John", "test": "value"})
        assert result["greeting"] == "Hello John"
        assert result["age"] == 25
        assert result["nested"]["value"] == "value"

    def test_resolve_list_with_variables(self):
        """Test resolving variables in list"""
        resolver = VariableResolver()
        data = ["Hello ${name}", "${value}", 123, {"key": "${test}"}]
        result = resolver.resolve_list(
            data, variables={"name": "World", "value": "test", "test": "result"}
        )
        assert result[0] == "Hello World"
        assert result[1] == "test"
        assert result[2] == 123
        assert result[3]["key"] == "result"

    def test_resolve_nested_list_of_dicts(self):
        """Test resolving nested structures"""
        resolver = VariableResolver()
        data = [{"items": ["${a}", "${b}"]}]
        result = resolver.resolve_list(data, variables={"a": "1", "b": "2"})
        assert result[0]["items"] == ["1", "2"]

    def test_evaluate_condition_true(self):
        """Test evaluating true condition"""
        resolver = VariableResolver()
        result = resolver.evaluate_condition("${value} == 5", variables={"value": 5})
        assert result is True

    def test_evaluate_condition_false(self):
        """Test evaluating false condition"""
        resolver = VariableResolver()
        result = resolver.evaluate_condition("${value} == 10", variables={"value": 5})
        assert result is False

    def test_evaluate_condition_with_string(self):
        """Test evaluating condition with string"""
        resolver = VariableResolver()
        result = resolver.evaluate_condition('${name} == "John"', variables={"name": "John"})
        assert result is True

    def test_evaluate_condition_with_variable_substitution(self):
        """Test evaluating condition with variable substitution"""
        resolver = VariableResolver()
        result = resolver.evaluate_condition("${value} > 3", variables={"value": 5})
        assert result is True

    def test_evaluate_empty_condition(self):
        """Test evaluating empty condition returns True"""
        resolver = VariableResolver()
        result = resolver.evaluate_condition("")
        assert result is True

    def test_evaluate_condition_none(self):
        """Test evaluating None condition returns True"""
        resolver = VariableResolver()
        result = resolver.evaluate_condition(None)
        assert result is True

    def test_evaluate_invalid_condition(self):
        """Test evaluating invalid condition returns False"""
        resolver = VariableResolver()
        result = resolver.evaluate_condition("invalid syntax {{")
        assert result is False

    def test_clear(self):
        """Test clearing variables"""
        resolver = VariableResolver()
        resolver.variables = {"key": "value"}
        resolver.step_outputs = {"step": "output"}
        resolver.clear()
        assert resolver.variables == {}
        assert resolver.step_outputs == {}

    def test_set_variable(self):
        """Test setting variable"""
        resolver = VariableResolver()
        resolver.set_variable("key", "value")
        assert resolver.variables["key"] == "value"

    def test_set_step_output(self):
        """Test setting step output"""
        resolver = VariableResolver()
        resolver.set_step_output("step1", {"result": "success"})
        assert resolver.step_outputs["step1"] == {"result": "success"}

    def test_get_variable(self):
        """Test getting variable"""
        resolver = VariableResolver()
        resolver.variables = {"key": "value"}
        result = resolver.get_variable("key")
        assert result == "value"

    def test_get_variable_default(self):
        """Test getting variable with default"""
        resolver = VariableResolver()
        result = resolver.get_variable("nonexistent", "default_value")
        assert result == "default_value"

    def test_get_step_output(self):
        """Test getting step output"""
        resolver = VariableResolver()
        resolver.step_outputs = {"step1": {"output": "result"}}
        result = resolver.get_step_output("step1")
        assert result == {"output": "result"}

    def test_get_step_output_default(self):
        """Test getting step output with default"""
        resolver = VariableResolver()
        result = resolver.get_step_output("nonexistent", {"default": True})
        assert result == {"default": True}

    def test_get_variable_value_simple(self):
        """Test _get_variable_value with simple path"""
        resolver = VariableResolver()
        resolver.variables = {"name": "John"}
        result = resolver._get_variable_value("name")
        assert result == "John"

    def test_get_variable_value_dot_notation(self):
        """Test _get_variable_value with dot notation"""
        resolver = VariableResolver()
        resolver.variables = {"user": {"name": "John", "age": 30}}
        result = resolver._get_variable_value("user.name")
        assert result == "John"

    def test_get_variable_value_nested_dict(self):
        """Test _get_variable_value with nested dict"""
        resolver = VariableResolver()
        resolver.variables = {"project": {"meta": {"genre": "fantasy"}}}
        result = resolver._get_variable_value("project.meta.genre")
        assert result == "fantasy"

    def test_get_variable_value_from_step_outputs(self):
        """Test _get_variable_value from step outputs"""
        resolver = VariableResolver()
        resolver.step_outputs = {"step1": {"output": "result"}}
        result = resolver._get_variable_value("step1.output")
        assert result == "result"

    def test_get_variable_value_nonexistent(self):
        """Test _get_variable_value with nonexistent path"""
        resolver = VariableResolver()
        result = resolver._get_variable_value("nonexistent")
        assert result is None

    def test_get_variable_value_invalid_path(self):
        """Test _get_variable_value with invalid nested path"""
        resolver = VariableResolver()
        resolver.variables = {"user": {"name": "John"}}
        result = resolver._get_variable_value("user.nonexistent")
        assert result is None

    def test_resolve_updates_internal_state(self):
        """Test that resolve updates internal variables"""
        resolver = VariableResolver()
        resolver.resolve("${value}", variables={"value": "test"})
        assert resolver.variables == {"value": "test"}

    def test_resolve_dict_updates_internal_state(self):
        """Test that resolve_dict updates internal variables"""
        resolver = VariableResolver()
        resolver.resolve_dict({"key": "${value}"}, variables={"value": "test"})
        assert resolver.variables == {"value": "test"}

    def test_resolve_list_updates_internal_state(self):
        """Test that resolve_list updates internal variables"""
        resolver = VariableResolver()
        resolver.resolve_list(["${value}"], variables={"value": "test"})
        assert resolver.variables == {"value": "test"}

    def test_evaluate_condition_updates_state(self):
        """Test that evaluate_condition updates internal state"""
        resolver = VariableResolver()
        resolver.evaluate_condition("${value} == 5", variables={"value": 5})
        assert resolver.variables == {"value": 5}

    def test_multiple_variables_in_string(self):
        """Test resolving multiple variables in one string"""
        resolver = VariableResolver()
        result = resolver.resolve("${a} and ${b}", variables={"a": "First", "b": "Second"})
        assert result == "First and Second"

    def test_complex_condition(self):
        """Test evaluating complex condition"""
        resolver = VariableResolver()
        result = resolver.evaluate_condition(
            "${value} > 5 and ${value} < 10", variables={"value": 7}
        )
        assert result is True

    def test_condition_with_or(self):
        """Test evaluating condition with OR"""
        resolver = VariableResolver()
        result = resolver.evaluate_condition(
            "${value} == 5 or ${value} == 10", variables={"value": 5}
        )
        assert result is True

    def test_resolve_empty_string(self):
        """Test resolving empty string"""
        resolver = VariableResolver()
        result = resolver.resolve("")
        assert result == ""

    def test_resolve_none_value(self):
        """Test resolving None value"""
        resolver = VariableResolver()
        result = resolver.resolve(None)
        assert result is None

    def test_resolve_boolean_value(self):
        """Test resolving boolean value"""
        resolver = VariableResolver()
        result = resolver.resolve(True)
        assert result is True

    def test_resolve_list_value(self):
        """Test resolving list value as-is"""
        resolver = VariableResolver()
        data = [1, 2, 3]
        result = resolver.resolve(data)
        assert result == data

    def test_resolve_dict_value(self):
        """Test resolving dict value as-is"""
        resolver = VariableResolver()
        data = {"key": "value"}
        result = resolver.resolve(data)
        assert result == data

    def test_resolve_empty_dict(self):
        """Test resolving empty dict"""
        resolver = VariableResolver()
        result = resolver.resolve_dict({})
        assert result == {}

    def test_resolve_empty_list(self):
        """Test resolving empty list"""
        resolver = VariableResolver()
        result = resolver.resolve_list([])
        assert result == []

    def test_resolve_dict_with_nested_dicts(self):
        """Test resolving deeply nested dicts"""
        resolver = VariableResolver()
        data = {"level1": {"level2": {"level3": "${value}"}}}
        result = resolver.resolve_dict(data, variables={"value": "deep"})
        assert result["level1"]["level2"]["level3"] == "deep"

    def test_resolve_list_with_nested_lists(self):
        """Test resolving nested lists"""
        resolver = VariableResolver()
        data = [["${a}", "${b}"], ["${c}"]]
        result = resolver.resolve_list(data, variables={"a": "1", "b": "2", "c": "3"})
        assert result == [["1", "2"], ["3"]]

    def test_get_variable_value_non_dict_in_path(self):
        """Test _get_variable_value when intermediate value is not dict"""
        resolver = VariableResolver()
        resolver.variables = {"user": "string_value"}
        result = resolver._get_variable_value("user.name")
        assert result is None

    def test_evaluate_condition_with_step_outputs(self):
        """Test evaluate_condition updates step_outputs state"""
        resolver = VariableResolver()
        resolver.evaluate_condition("${step1} == 5", step_outputs={"step1": 5})
        assert resolver.step_outputs == {"step1": 5}

    def test_evaluate_condition_with_both_sources(self):
        """Test evaluate_condition with variables and step_outputs"""
        resolver = VariableResolver()
        result = resolver.evaluate_condition(
            "${var} + ${step} == 10", variables={"var": 5}, step_outputs={"step": 5}
        )
        assert result is True

    def test_evaluate_condition_string_comparison(self):
        """Test evaluating condition with string values"""
        resolver = VariableResolver()
        result = resolver.evaluate_condition(
            '${name} == "Jane" and ${age} == 30', variables={"name": "Jane", "age": 30}
        )
        assert result is True

    def test_evaluate_condition_with_string_variable(self):
        """Test evaluating condition with string variable in expression"""
        resolver = VariableResolver()
        result = resolver.evaluate_condition(
            "${text} == ${value}", variables={"value": "hello", "text": "hello"}
        )
        assert result is True

    def test_resolve_multiple_occurrences(self):
        """Test resolving same variable multiple times in string"""
        resolver = VariableResolver()
        result = resolver.resolve("${x} and ${x} again", variables={"x": "test"})
        assert result == "test and test again"

    def test_resolve_preserves_non_matching_dollar_signs(self):
        """Test that text without ${} is preserved"""
        resolver = VariableResolver()
        result = resolver.resolve("Price: $100")
        assert result == "Price: $100"

    def test_resolve_dict_with_list_of_dicts(self):
        """Test resolving dict containing list of dicts"""
        resolver = VariableResolver()
        data = {"items": [{"name": "${name1}"}, {"name": "${name2}"}]}
        result = resolver.resolve_dict(data, variables={"name1": "A", "name2": "B"})
        assert result["items"][0]["name"] == "A"
        assert result["items"][1]["name"] == "B"

    def test_resolve_list_with_mixed_types(self):
        """Test resolving list with mixed types"""
        resolver = VariableResolver()
        data = ["text", 123, {"key": "${val}"}, ["${nested}"], None]
        result = resolver.resolve_list(data, variables={"val": "test", "nested": "deep"})
        assert result[0] == "text"
        assert result[1] == 123
        assert result[2]["key"] == "test"
        assert result[3] == ["deep"]
        assert result[4] is None

    def test_set_variable_overwrites(self):
        """Test that set_variable overwrites existing value"""
        resolver = VariableResolver()
        resolver.set_variable("key", "value1")
        resolver.set_variable("key", "value2")
        assert resolver.variables["key"] == "value2"

    def test_set_step_output_overwrites(self):
        """Test that set_step_output overwrites existing value"""
        resolver = VariableResolver()
        resolver.set_step_output("step1", {"old": "data"})
        resolver.set_step_output("step1", {"new": "data"})
        assert resolver.step_outputs["step1"] == {"new": "data"}

    def test_clear_with_existing_data(self):
        """Test clear removes all existing data"""
        resolver = VariableResolver()
        resolver.variables = {"a": 1, "b": 2}
        resolver.step_outputs = {"step1": {}, "step2": {}}
        resolver.clear()
        assert len(resolver.variables) == 0
        assert len(resolver.step_outputs) == 0

    def test_resolve_with_no_variables_provided(self):
        """Test resolve with no variables dict provided"""
        resolver = VariableResolver()
        result = resolver.resolve("static text")
        assert result == "static text"

    def test_evaluate_condition_with_unresolved_variable_returns_false(self):
        resolver = VariableResolver()
        result = resolver.evaluate_condition("${missing} == 1", variables={"x": 1})
        assert result is False
