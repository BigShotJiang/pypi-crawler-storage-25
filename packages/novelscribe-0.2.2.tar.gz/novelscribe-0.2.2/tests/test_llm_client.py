"""Tests for LLM client module."""

import os
from unittest.mock import patch

import pytest

from core.llm_client import (
    ClaudeClient,
    GeminiClient,
    LLMClientFactory,
    LLMConfig,
    LLMResponse,
    LMStudioClient,
    MultiLLMClient,
    OllamaClient,
    OpenAIClient,
    ProviderNotFoundError,
)


@pytest.fixture
def openai_config():
    """Create OpenAI configuration."""
    return LLMConfig(
        provider="openai",
        model="gpt-4",
        api_key="test-key",
        temperature=0.7,
        max_tokens=1000,
    )


@pytest.fixture
def claude_config():
    """Create Claude configuration."""
    return LLMConfig(
        provider="claude",
        model="claude-3-opus-20240229",
        api_key="test-key",
        temperature=0.7,
        max_tokens=1000,
    )


@pytest.fixture
def gemini_config():
    """Create Gemini configuration."""
    return LLMConfig(
        provider="gemini",
        model="gemini-pro",
        api_key="test-key",
    )


@pytest.fixture
def ollama_config():
    """Create Ollama configuration."""
    return LLMConfig(
        provider="ollama",
        model="llama2",
        base_url="http://localhost:11434",
    )


@pytest.fixture
def lm_studio_config():
    """Create LM Studio configuration."""
    return LLMConfig(
        provider="lm_studio",
        model="local-model",
        base_url="http://localhost:1234/v1",
    )


class TestLLMConfig:
    """Tests for LLMConfig."""

    def test_default_config(self):
        """Test default configuration values."""
        config = LLMConfig()
        assert config.provider == "openai"
        assert config.model == "gpt-4o"
        assert config.temperature == 0.7
        assert config.max_tokens == 4096

    def test_custom_config(self):
        """Test custom configuration values."""
        config = LLMConfig(
            provider="claude",
            model="claude-3-opus",
            temperature=0.5,
            max_tokens=2000,
        )
        assert config.provider == "claude"
        assert config.model == "claude-3-opus"
        assert config.temperature == 0.5
        assert config.max_tokens == 2000


class TestLLMResponse:
    """Tests for LLMResponse."""

    def test_response_creation(self):
        """Test creating LLM response."""
        response = LLMResponse(
            content="Test response",
            model="gpt-4",
            provider="openai",
            tokens_used=100,
            finish_reason="stop",
        )
        assert response.content == "Test response"
        assert response.model == "gpt-4"
        assert response.provider == "openai"
        assert response.tokens_used == 100
        assert response.finish_reason == "stop"


class TestOpenAIClient:
    """Tests for OpenAI client."""

    def test_client_creation(self, openai_config):
        """Test creating OpenAI client."""
        try:
            client = OpenAIClient(openai_config)
            assert client.provider_name == "openai"
            assert client.config == openai_config
        except Exception:
            pytest.skip("OpenAI SDK not available")

    def test_validate_config_with_key(self, openai_config):
        """Test validation with API key."""
        try:
            client = OpenAIClient(openai_config)
            assert client.validate_config() is True
        except Exception:
            pytest.skip("OpenAI SDK not available")

    def test_validate_config_without_key(self):
        """Test validation without API key."""
        try:
            config = LLMConfig(provider="openai", model="gpt-4")
            client = OpenAIClient(config)
            with patch.dict(os.environ, {"OPENAI_API_KEY": ""}, clear=True):
                assert client.validate_config() is False
        except Exception:
            pytest.skip("OpenAI SDK not available")


class TestClaudeClient:
    """Tests for Claude client."""

    def test_client_creation(self, claude_config):
        """Test creating Claude client."""
        try:
            client = ClaudeClient(claude_config)
            assert client.provider_name == "claude"
            assert client.config == claude_config
        except Exception:
            pytest.skip("Claude SDK not available")

    def test_validate_config_with_key(self, claude_config):
        """Test validation with API key."""
        try:
            client = ClaudeClient(claude_config)
            assert client.validate_config() is True
        except Exception:
            pytest.skip("Claude SDK not available")


class TestGeminiClient:
    """Tests for Gemini client."""

    def test_client_creation(self, gemini_config):
        """Test creating Gemini client."""
        try:
            client = GeminiClient(gemini_config)
            assert client.provider_name == "gemini"
            assert client.config == gemini_config
        except Exception:
            pytest.skip("Gemini SDK not available")

    def test_validate_config_with_key(self, gemini_config):
        """Test validation with API key."""
        try:
            client = GeminiClient(gemini_config)
            assert client.validate_config() is True
        except Exception:
            pytest.skip("Gemini SDK not available")


class TestOllamaClient:
    """Tests for Ollama client."""

    def test_client_creation(self, ollama_config):
        """Test creating Ollama client."""
        try:
            client = OllamaClient(ollama_config)
            assert client.provider_name == "ollama"
            assert client.config == ollama_config
        except Exception:
            pytest.skip("Ollama not available")


class TestLMStudioClient:
    """Tests for LM Studio client."""

    def test_client_creation(self, lm_studio_config):
        """Test creating LM Studio client."""
        try:
            client = LMStudioClient(lm_studio_config)
            assert client.provider_name == "lm_studio"
            assert client.config == lm_studio_config
        except Exception:
            pytest.skip("LM Studio not available")


class TestLLMClientFactory:
    """Tests for LLM client factory."""

    def test_create_openai_client(self, openai_config):
        """Test creating OpenAI client via factory."""
        try:
            client = LLMClientFactory.create(openai_config)
            assert client.provider_name == "openai"
        except Exception:
            pytest.skip("OpenAI SDK not available")

    def test_create_claude_client(self, claude_config):
        """Test creating Claude client via factory."""
        try:
            client = LLMClientFactory.create(claude_config)
            assert client.provider_name == "claude"
        except Exception:
            pytest.skip("Claude SDK not available")

    def test_create_gemini_client(self, gemini_config):
        """Test creating Gemini client via factory."""
        try:
            client = LLMClientFactory.create(gemini_config)
            assert client.provider_name == "gemini"
        except Exception:
            pytest.skip("Gemini SDK not available")

    def test_create_ollama_client(self, ollama_config):
        """Test creating Ollama client via factory."""
        try:
            client = LLMClientFactory.create(ollama_config)
            assert client.provider_name == "ollama"
        except Exception:
            pytest.skip("Ollama not available")

    def test_create_lm_studio_client(self, lm_studio_config):
        """Test creating LM Studio client via factory."""
        try:
            client = LLMClientFactory.create(lm_studio_config)
            assert client.provider_name == "lm_studio"
        except Exception:
            pytest.skip("LM Studio not available")

    def test_unsupported_provider(self):
        """Test creating client with unsupported provider."""
        config = LLMConfig(provider="unsupported", model="model")
        with pytest.raises(ProviderNotFoundError):
            LLMClientFactory.create(config)


class TestMultiLLMClient:
    """Tests for multi-LLM client."""

    def test_primary_client_success(self):
        """Test using primary client."""
        config = LLMConfig(provider="openai", model="gpt-4", api_key="test-key")
        try:
            client = MultiLLMClient(primary_config=config)
            assert client.primary_provider == "openai"
        except Exception:
            pytest.skip("OpenAI SDK not available")

    def test_fallback_to_secondary(self):
        """Test fallback to secondary client."""
        primary_config = LLMConfig(provider="openai", model="gpt-4", api_key="test-key")
        secondary_config = LLMConfig(provider="claude", model="claude-3", api_key="test-key")
        try:
            client = MultiLLMClient(
                primary_config=primary_config,
                secondary_config=secondary_config,
            )
            assert client.primary_provider == "openai"
            assert client.secondary_provider == "claude"
        except Exception:
            pytest.skip("SDK not available")
