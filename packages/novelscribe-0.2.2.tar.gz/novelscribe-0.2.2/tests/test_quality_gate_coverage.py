"""Additional coverage tests for quality_gate.py to reach 90%+ coverage."""

from datetime import datetime

from core.quality_gate import (
    GateResult,
    QualityGate,
    QualityGateConfig,
    QualityLevel,
)
from core.quality_metrics import QualityMetrics
from core.validation_system import ValidationReport


class TestGateResultCoverage:
    """Test GateResult edge cases for coverage."""

    def test_pass_rate_with_empty_scores(self):
        """Test pass_rate calculation when no scores exist."""
        result = GateResult(
            gate_level=QualityLevel.SILVER,
            passed=True,
            scores={},
            failed_criteria=[],
            recommendations=[],
            overall_score=0.8,
        )
        assert result.pass_rate == 1.0


class TestQualityGateConfigCoverage:
    """Test QualityGateConfig edge cases."""

    def test_get_level_config_default(self):
        """Test get_level_config returns self when no level matches."""
        config = QualityGateConfig(
            min_word_count=500,
            max_passive_voice=0.25,
        )
        result = config.get_level_config(None)
        assert result is config


class TestQualityGateCoverage:
    """Test QualityGate methods for full coverage."""

    def setup_method(self):
        """Set up test fixtures."""
        self.gate = QualityGate()

    def create_metrics(
        self,
        word_count: int = 1200,
        passive_voice: float = 0.12,
        readability: float = 65.0,
        dialogue_clarity: float = 0.75,
        character_consistency: float = 0.85,
        vocabulary_diversity: float = 0.45,
        adverb_frequency: float = 0.06,
        quality_score: float = 0.75,
    ) -> QualityMetrics:
        """Helper to create test metrics."""
        return QualityMetrics(
            chapter_number=1,
            version=1,
            word_count=word_count,
            sentence_count=50,
            paragraph_count=10,
            avg_sentence_length=24.0,
            avg_paragraph_length=120.0,
            flesch_kincaid=readability,
            gunning_fog=readability + 5,
            smog_index=readability + 2,
            passive_voice_ratio=passive_voice,
            dialogue_ratio=0.3,
            dialogue_line_count=15,
            speaker_clarity=dialogue_clarity,
            scene_variation=0.7,
            action_frequency=0.6,
            character_consistency=character_consistency,
            plot_continuity=0.8,
            vocabulary_diversity=vocabulary_diversity,
            adverb_frequency=adverb_frequency,
            overall_quality_score=quality_score,
        )

    def create_validation_report(
        self,
        errors: int = 0,
        warnings: int = 0,
        total_rules: int = 10,
        passed_rules: int = 10,
    ) -> ValidationReport:
        """Helper to create test validation report."""
        return ValidationReport(
            content_path="/test/path",
            timestamp=datetime.now(),
            total_rules_checked=total_rules,
            passed_rules=passed_rules,
            failed_rules=total_rules - passed_rules,
            warnings=warnings,
            errors=errors,
            results=[],
        )

    def test_check_criterion_operators(self):
        """Test all comparison operators in _check_criterion."""
        gate = QualityGate()

        assert gate._check_criterion(5, 3, ">=") is True
        assert gate._check_criterion(3, 5, ">=") is False
        assert gate._check_criterion(3, 5, "<=") is True
        assert gate._check_criterion(5, 3, "<=") is False
        assert gate._check_criterion(5, 3, ">") is True
        assert gate._check_criterion(3, 5, ">") is False
        assert gate._check_criterion(3, 5, "<") is True
        assert gate._check_criterion(5, 3, "<") is False
        assert gate._check_criterion(5, 3, "invalid") is False

    def test_check_validation_report_bronze(self):
        """Test validation report check for bronze level."""
        gate = QualityGate()
        report = self.create_validation_report(errors=0)
        assert gate._check_validation_report(report, QualityLevel.BRONZE) is True

        report_with_errors = self.create_validation_report(errors=1)
        assert gate._check_validation_report(report_with_errors, QualityLevel.BRONZE) is False

    def test_check_validation_report_silver(self):
        """Test validation report check for silver level."""
        gate = QualityGate()
        report = self.create_validation_report(errors=0, warnings=0)
        assert gate._check_validation_report(report, QualityLevel.SILVER) is True

        report_with_warnings = self.create_validation_report(errors=0, warnings=3)
        assert gate._check_validation_report(report_with_warnings, QualityLevel.SILVER) is False

    def test_check_validation_report_gold(self):
        """Test validation report check for gold level."""
        gate = QualityGate()
        report = self.create_validation_report(errors=0, warnings=0)
        assert gate._check_validation_report(report, QualityLevel.GOLD) is True

        report_with_warnings = self.create_validation_report(errors=0, warnings=1)
        assert gate._check_validation_report(report_with_warnings, QualityLevel.GOLD) is False

    def test_check_validation_report_platinum(self):
        """Test validation report check for platinum level."""
        gate = QualityGate()
        report = self.create_validation_report(
            errors=0, warnings=0, total_rules=100, passed_rules=98
        )
        assert gate._check_validation_report(report, QualityLevel.PLATINUM) is True

        report_low_success = self.create_validation_report(
            errors=0, warnings=0, total_rules=100, passed_rules=90
        )
        assert gate._check_validation_report(report_low_success, QualityLevel.PLATINUM) is False

    def test_check_quality_gate_with_validation_failure(self):
        """Test quality gate with failing validation report."""
        gate = QualityGate()
        metrics = self.create_metrics()
        report = self.create_validation_report(errors=1)

        result = gate.check_quality_gate(
            "test_project",
            metrics,
            report,
            QualityLevel.SILVER,
        )

        assert result.passed is False
        assert "validation" in result.failed_criteria
        assert any("validation" in rec.lower() for rec in result.recommendations)

    def test_check_quality_gate_with_validation_warning(self):
        """Test quality gate with validation report containing warnings."""
        gate = QualityGate()
        metrics = self.create_metrics()
        report = self.create_validation_report(errors=0, warnings=3)

        result = gate.check_quality_gate(
            "test_project",
            metrics,
            report,
            QualityLevel.SILVER,
        )

        assert result.passed is False
        assert "validation" in result.failed_criteria

    def test_promote_to_level_passed(self):
        """Test promote_to_level when content already passes."""
        gate = QualityGate()
        metrics = self.create_metrics(quality_score=0.95)
        report = self.create_validation_report(errors=0, warnings=0)

        result = gate.promote_to_level(
            "test_project",
            metrics,
            report,
            QualityLevel.SILVER,
        )

        assert result["passed"] is True
        assert result["can_auto_promote"] is True
        assert len(result["actions_needed"]) > 0

    def test_calculate_overall_score_with_validation(self):
        """Test overall score calculation with validation score."""
        gate = QualityGate()
        config = QualityGateConfig().get_level_config(QualityLevel.SILVER)

        scores = {
            "quality_score": 0.8,
            "readability_ease": 65.0,
            "dialogue_clarity": 0.75,
            "character_consistency": 0.85,
            "vocabulary_diversity": 0.45,
            "passive_voice": 0.12,
            "adverb_frequency": 0.06,
            "word_count": 1200,
            "validation": 1.0,
        }

        overall = gate._calculate_overall_score(scores, config)
        assert 0.0 <= overall <= 1.0

    def test_analyze_promotion_gap_with_frequency_criteria(self):
        """Test gap analysis for frequency-based criteria."""
        gate = QualityGate()
        metrics = self.create_metrics(adverb_frequency=0.10)
        result = GateResult(
            gate_level=QualityLevel.SILVER,
            passed=False,
            scores={"adverb_frequency": 0.10},
            failed_criteria=["adverb_frequency"],
            recommendations=[],
            overall_score=0.6,
        )

        gap = gate._analyze_promotion_gap(metrics, result, QualityLevel.SILVER)

        assert "adverb_frequency" in gap
        assert gap["adverb_frequency"]["current"] == 0.10
        assert gap["adverb_frequency"]["gap"] > 0

    def test_analyze_promotion_gap_with_word_count(self):
        """Test gap analysis for word count criterion."""
        gate = QualityGate()
        metrics = self.create_metrics(word_count=800)
        result = GateResult(
            gate_level=QualityLevel.SILVER,
            passed=False,
            scores={"word_count": 800},
            failed_criteria=["word_count"],
            recommendations=[],
            overall_score=0.6,
        )

        gap = gate._analyze_promotion_gap(metrics, result, QualityLevel.SILVER)

        assert "word_count" in gap
        assert gap["word_count"]["current"] == 800
        assert gap["word_count"]["gap"] == 200

    def test_analyze_promotion_gap_zero_threshold(self):
        """Test gap analysis when threshold is zero."""
        gate = QualityGate()
        metrics = self.create_metrics(vocabulary_diversity=0.2)
        result = GateResult(
            gate_level=QualityLevel.SILVER,
            passed=False,
            scores={"vocabulary_diversity": 0.2},
            failed_criteria=["vocabulary_diversity"],
            recommendations=[],
            overall_score=0.6,
        )

        gap = gate._analyze_promotion_gap(metrics, result, QualityLevel.SILVER)
        assert "vocabulary_diversity" in gap

    def test_generate_auto_fix_plan_all_criteria(self):
        """Test auto-fix plan generation for all failed criteria."""
        gate = QualityGate()
        failed_criteria = [
            "word_count",
            "passive_voice",
            "readability_ease",
            "dialogue_clarity",
            "character_consistency",
            "vocabulary_diversity",
            "adverb_frequency",
        ]
        gap_analysis = {
            "word_count": {"gap": 200},
            "passive_voice": {"gap": 0.05},
            "readability_ease": {},
            "dialogue_clarity": {},
            "character_consistency": {},
            "vocabulary_diversity": {},
            "adverb_frequency": {"gap": 0.03},
        }

        plan = gate._generate_auto_fix_plan(failed_criteria, gap_analysis)
        assert len(plan) > 0
        assert any("word" in p.lower() for p in plan)
        assert any("passive" in p.lower() for p in plan)

    def test_generate_action_plan_with_failed_criteria(self):
        """Test action plan generation with failed criteria."""
        gate = QualityGate()
        failed_criteria = ["validation", "quality_score", "word_count"]
        recommendations = [
            "Address validation errors before promoting to next quality level",
            "Improve overall quality from 65.0% to 70.0% or higher",
            "Expand content to meet minimum word count (1000 words)",
            "Review all failed criteria and implement recommendations",
        ]

        plan = gate._generate_action_plan(failed_criteria, recommendations)
        assert len(plan) > 0
        assert any("validation" in p.lower() for p in plan)
        assert any("quality" in p.lower() for p in plan)
        assert any("word" in p.lower() for p in plan)

    def test_generate_action_plan_case_insensitive_matching(self):
        """Test action plan matches criteria case-insensitively."""
        gate = QualityGate()
        failed_criteria = ["passive_voice"]
        recommendations = [
            "Reduce Passive Voice from 15% to 10% or less",
            "Rewrite passive constructions as active voice",
        ]

        plan = gate._generate_action_plan(failed_criteria, recommendations)
        assert len(plan) > 0

    def test_generate_quality_report_with_validation(self):
        """Test quality report generation with validation report."""
        gate = QualityGate()
        metrics = self.create_metrics()
        report = self.create_validation_report(
            errors=0,
            warnings=1,
            total_rules=15,
            passed_rules=14,
        )

        quality_report = gate.generate_quality_report("test_project", metrics, report)
        assert "Validation Results" in quality_report
        assert "Total Rules Checked: 15" in quality_report
        assert "Warnings: 1" in quality_report

    def test_get_gate_statistics_with_history(self):
        """Test gate statistics with populated history."""
        gate = QualityGate()
        metrics = self.create_metrics()
        report = self.create_validation_report()

        for level in [QualityLevel.BRONZE, QualityLevel.SILVER, QualityLevel.SILVER]:
            gate.check_quality_gate("test_project", metrics, report, level)

        stats = gate.get_gate_statistics("test_project")
        assert stats["total_checks"] == 3
        assert stats["pass_count"] == 3
        assert stats["pass_rate"] == 1.0
        assert stats["level_distribution"]["silver"] == 2
        assert stats["level_distribution"]["bronze"] == 1

    def test_record_gate_result(self):
        """Test recording gate results."""
        gate = QualityGate()
        result = GateResult(
            gate_level=QualityLevel.SILVER,
            passed=True,
            scores={},
            failed_criteria=[],
            recommendations=[],
            overall_score=0.8,
        )

        gate._record_gate_result("test_project", result)
        assert "test_project" in gate.gate_history
        assert len(gate.gate_history["test_project"]) == 1
        assert gate.gate_history["test_project"][0] is result
