"""Comprehensive tests for summary store coverage improvement."""

import json
from datetime import datetime

import yaml

from core.summary_store import (
    ChapterSummary,
    GlobalSummary,
    GroupSummary,
    SummaryStore,
    SummaryStoreConfig,
)


class TestChapterSummary:
    """Test ChapterSummary dataclass."""

    def test_create_chapter_summary(self):
        """Test creating a chapter summary."""
        summary = ChapterSummary(
            chapter_number=1,
            summary="Test summary",
            key_events=["Event 1", "Event 2"],
            characters={"Hero": "protagonist"},
            locations={"Castle": "main setting"},
            plot_advancement="Plot moves forward",
            next_chapter_setup="Setup for next chapter",
            created_at=datetime.now(),
            word_count=1000,
        )
        assert summary.chapter_number == 1
        assert summary.summary == "Test summary"
        assert len(summary.key_events) == 2
        assert summary.word_count == 1000

    def test_chapter_summary_to_dict(self):
        """Test converting chapter summary to dictionary."""
        created_at = datetime.now()
        summary = ChapterSummary(
            chapter_number=2,
            summary="Summary text",
            key_events=["Event A"],
            characters={"Alice": "protagonist"},
            locations={"City": "urban setting"},
            plot_advancement="Rising action",
            next_chapter_setup="Cliffhanger ending",
            created_at=created_at,
            word_count=1500,
        )

        data = summary.to_dict()
        assert data["chapter_number"] == 2
        assert data["summary"] == "Summary text"
        assert data["key_events"] == ["Event A"]
        assert data["word_count"] == 1500
        assert "created_at" in data

    def test_chapter_summary_from_dict(self):
        """Test creating chapter summary from dictionary."""
        data = {
            "chapter_number": 3,
            "summary": "From dict summary",
            "key_events": ["Event X", "Event Y"],
            "characters": {"Bob": "antagonist"},
            "locations": {"Forest": "mysterious woods"},
            "plot_advancement": "Climax",
            "next_chapter_setup": "Resolution setup",
            "created_at": datetime.now().isoformat(),
            "word_count": 2000,
        }

        summary = ChapterSummary.from_dict(data)
        assert summary.chapter_number == 3
        assert summary.summary == "From dict summary"
        assert len(summary.key_events) == 2
        assert summary.word_count == 2000

    def test_chapter_summary_from_dict_missing_word_count(self):
        """Test from_dict with missing word_count defaults to 0."""
        data = {
            "chapter_number": 4,
            "summary": "Summary without word count",
            "key_events": [],
            "characters": {},
            "locations": {},
            "plot_advancement": "Setup",
            "next_chapter_setup": "Setup",
            "created_at": datetime.now().isoformat(),
        }

        summary = ChapterSummary.from_dict(data)
        assert summary.word_count == 0


class TestGroupSummary:
    """Test GroupSummary dataclass."""

    def test_create_group_summary(self):
        """Test creating a group summary."""
        summary = GroupSummary(
            group_id="group_1_5",
            start_chapter=1,
            end_chapter=5,
            summary="Group summary",
            combined_events=["Event 1", "Event 2"],
            character_arcs={"Hero": "Hero's journey"},
            plot_developments=["Plot point 1"],
            created_at=datetime.now(),
            total_word_count=10000,
        )
        assert summary.group_id == "group_1_5"
        assert summary.start_chapter == 1
        assert summary.end_chapter == 5
        assert len(summary.combined_events) == 2

    def test_group_summary_to_dict(self):
        """Test converting group summary to dictionary."""
        created_at = datetime.now()
        summary = GroupSummary(
            group_id="group_6_10",
            start_chapter=6,
            end_chapter=10,
            summary="Chapters 6-10 summary",
            combined_events=["Big event"],
            character_arcs={"Villain": "Villain's defeat"},
            plot_developments=["Resolution"],
            created_at=created_at,
            total_word_count=25000,
        )

        data = summary.to_dict()
        assert data["group_id"] == "group_6_10"
        assert data["start_chapter"] == 6
        assert data["end_chapter"] == 10
        assert data["total_word_count"] == 25000

    def test_group_summary_from_dict(self):
        """Test creating group summary from dictionary."""
        data = {
            "group_id": "group_11_15",
            "start_chapter": 11,
            "end_chapter": 15,
            "summary": "Mid-novel summary",
            "combined_events": ["Event A"],
            "character_arcs": {"Sidekick": "Development"},
            "plot_developments": ["Subplot resolution"],
            "created_at": datetime.now().isoformat(),
            "total_word_count": 30000,
        }

        summary = GroupSummary.from_dict(data)
        assert summary.group_id == "group_11_15"
        assert summary.total_word_count == 30000

    def test_group_summary_from_dict_missing_word_count(self):
        """Test from_dict with missing total_word_count defaults to 0."""
        data = {
            "group_id": "group_test",
            "start_chapter": 1,
            "end_chapter": 5,
            "summary": "Test group",
            "combined_events": [],
            "character_arcs": {},
            "plot_developments": [],
            "created_at": datetime.now().isoformat(),
        }

        summary = GroupSummary.from_dict(data)
        assert summary.total_word_count == 0


class TestGlobalSummary:
    """Test GlobalSummary dataclass."""

    def test_create_global_summary(self):
        """Test creating a global summary."""
        summary = GlobalSummary(
            project_name="My Novel",
            summary="Novel summary",
            main_plot_arc="Main arc description",
            character_arcs={"Hero": "Hero's complete arc"},
            world_development="World building details",
            themes=["Theme 1", "Theme 2"],
            last_updated=datetime.now(),
            total_chapters_covered=50,
            total_word_count=100000,
        )
        assert summary.project_name == "My Novel"
        assert len(summary.themes) == 2
        assert summary.total_chapters_covered == 50

    def test_global_summary_to_dict(self):
        """Test converting global summary to dictionary."""
        last_updated = datetime.now()
        summary = GlobalSummary(
            project_name="Epic Novel",
            summary="Epic story",
            main_plot_arc="Hero's journey",
            character_arcs={"Protagonist": "Full arc"},
            world_development="Rich world",
            themes=["Love", "Loss", "Redemption"],
            last_updated=last_updated,
            total_chapters_covered=100,
            total_word_count=200000,
        )

        data = summary.to_dict()
        assert data["project_name"] == "Epic Novel"
        assert len(data["themes"]) == 3
        assert data["total_chapters_covered"] == 100
        assert data["total_word_count"] == 200000

    def test_global_summary_from_dict(self):
        """Test creating global summary from dictionary."""
        data = {
            "project_name": "Fantasy Epic",
            "summary": "A tale of magic",
            "main_plot_arc": "Chosen one prophecy",
            "character_arcs": {"Wizard": "Mentor arc"},
            "world_development": "Magical realm",
            "themes": ["Destiny", "Magic"],
            "last_updated": datetime.now().isoformat(),
            "total_chapters_covered": 75,
            "total_word_count": 150000,
        }

        summary = GlobalSummary.from_dict(data)
        assert summary.project_name == "Fantasy Epic"
        assert len(summary.themes) == 2
        assert summary.total_word_count == 150000

    def test_global_summary_from_dict_missing_word_count(self):
        """Test from_dict with missing total_word_count defaults to 0."""
        data = {
            "project_name": "Simple Story",
            "summary": "Short tale",
            "main_plot_arc": "Simple plot",
            "character_arcs": {},
            "world_development": "Small setting",
            "themes": ["Friendship"],
            "last_updated": datetime.now().isoformat(),
            "total_chapters_covered": 10,
        }

        summary = GlobalSummary.from_dict(data)
        assert summary.total_word_count == 0


class TestSummaryStoreConfig:
    """Test SummaryStoreConfig model."""

    def test_default_config(self):
        """Test default configuration."""
        config = SummaryStoreConfig()
        assert config.storage_format == "yaml"
        assert config.auto_backup is True
        assert config.backup_count == 3
        assert config.compress_old_summaries is False

    def test_custom_config(self):
        """Test custom configuration."""
        config = SummaryStoreConfig(
            storage_format="json",
            auto_backup=False,
            backup_count=5,
            compress_old_summaries=True,
        )
        assert config.storage_format == "json"
        assert config.auto_backup is False
        assert config.backup_count == 5
        assert config.compress_old_summaries is True


class TestSummaryStore:
    """Test SummaryStore class."""

    def test_initialization(self, tmp_path):
        """Test summary store initialization."""
        store = SummaryStore(tmp_path)
        assert store.project_root == tmp_path
        assert store.summaries_dir.exists()
        assert store.chapters_dir.exists()
        assert store.groups_dir.exists()

    def test_initialization_with_custom_config(self, tmp_path):
        """Test initialization with custom config."""
        config = SummaryStoreConfig(storage_format="json", backup_count=10)
        store = SummaryStore(tmp_path, config)
        assert store.config.storage_format == "json"
        assert store.config.backup_count == 10

    def test_ensure_directories(self, tmp_path):
        """Test directory creation."""
        store = SummaryStore(tmp_path)
        assert store.chapters_dir.exists()
        assert store.groups_dir.exists()

    def test_get_chapter_summary_path_yaml(self, tmp_path):
        """Test chapter summary path generation for YAML format."""
        config = SummaryStoreConfig(storage_format="yaml")
        store = SummaryStore(tmp_path, config)

        path = store._get_chapter_summary_path(1)
        assert path.parent == store.chapters_dir
        assert path.name == "chapter_001.yaml"

        path = store._get_chapter_summary_path(42)
        assert path.name == "chapter_042.yaml"

    def test_get_chapter_summary_path_json(self, tmp_path):
        """Test chapter summary path generation for JSON format."""
        config = SummaryStoreConfig(storage_format="json")
        store = SummaryStore(tmp_path, config)

        path = store._get_chapter_summary_path(1)
        assert path.name == "chapter_001.json"

    def test_get_group_summary_path_yaml(self, tmp_path):
        """Test group summary path generation for YAML format."""
        config = SummaryStoreConfig(storage_format="yaml")
        store = SummaryStore(tmp_path, config)

        path = store._get_group_summary_path("group_1_5")
        assert path.parent == store.groups_dir
        assert path.name == "group_1_5.yaml"

    def test_get_global_summary_path_yaml(self, tmp_path):
        """Test global summary path generation."""
        config = SummaryStoreConfig(storage_format="yaml")
        store = SummaryStore(tmp_path, config)

        path = store._get_global_summary_path()
        assert path.parent == store.summaries_dir
        assert path.name == "global_summary.yaml"

    def test_get_global_summary_path_json(self, tmp_path):
        """Test global summary path generation for JSON."""
        config = SummaryStoreConfig(storage_format="json")
        store = SummaryStore(tmp_path, config)

        path = store._get_global_summary_path()
        assert path.name == "global_summary.json"

    def test_save_chapter_summary_yaml(self, tmp_path):
        """Test saving chapter summary in YAML format."""
        store = SummaryStore(tmp_path)

        summary = ChapterSummary(
            chapter_number=1,
            summary="Chapter 1 summary",
            key_events=["Opening scene", "Inciting incident"],
            characters={"Alice": "Main character"},
            locations={"Home": "Starting location"},
            plot_advancement="Introduction",
            next_chapter_setup="Setup complete",
            created_at=datetime.now(),
            word_count=1000,
        )

        store.save_chapter_summary(summary)

        path = store._get_chapter_summary_path(1)
        assert path.exists()

        with open(path, "r") as f:
            data = yaml.safe_load(f)
            assert data["chapter_number"] == 1
            assert data["summary"] == "Chapter 1 summary"

    def test_save_chapter_summary_json(self, tmp_path):
        """Test saving chapter summary in JSON format."""
        config = SummaryStoreConfig(storage_format="json")
        store = SummaryStore(tmp_path, config)

        summary = ChapterSummary(
            chapter_number=2,
            summary="Chapter 2 summary",
            key_events=["Event"],
            characters={},
            locations={},
            plot_advancement="Rising action",
            next_chapter_setup="More setup",
            created_at=datetime.now(),
            word_count=1500,
        )

        store.save_chapter_summary(summary)

        path = store._get_chapter_summary_path(2)
        assert path.exists()

        with open(path, "r") as f:
            data = json.load(f)
            assert data["chapter_number"] == 2

    def test_load_chapter_summary_yaml(self, tmp_path):
        """Test loading chapter summary in YAML format."""
        store = SummaryStore(tmp_path)

        summary = ChapterSummary(
            chapter_number=3,
            summary="Chapter 3 content",
            key_events=["Key event"],
            characters={"Bob": "Character"},
            locations={"Office": "Workplace"},
            plot_advancement="Development",
            next_chapter_setup="Cliffhanger",
            created_at=datetime.now(),
            word_count=2000,
        )

        store.save_chapter_summary(summary)
        loaded = store.load_chapter_summary(3)

        assert loaded is not None
        assert loaded.chapter_number == 3
        assert loaded.summary == "Chapter 3 content"
        assert loaded.word_count == 2000

    def test_load_chapter_summary_not_found(self, tmp_path):
        """Test loading non-existent chapter summary."""
        store = SummaryStore(tmp_path)
        loaded = store.load_chapter_summary(999)
        assert loaded is None

    def test_save_group_summary_yaml(self, tmp_path):
        """Test saving group summary in YAML format."""
        store = SummaryStore(tmp_path)

        summary = GroupSummary(
            group_id="chapters_1_5",
            start_chapter=1,
            end_chapter=5,
            summary="First act summary",
            combined_events=["Major event"],
            character_arcs={"Alice": "Introduction"},
            plot_developments=["Plot begins"],
            created_at=datetime.now(),
            total_word_count=10000,
        )

        store.save_group_summary(summary)

        path = store._get_group_summary_path("chapters_1_5")
        assert path.exists()

        with open(path, "r") as f:
            data = yaml.safe_load(f)
            assert data["group_id"] == "chapters_1_5"
            assert data["start_chapter"] == 1

    def test_load_group_summary_yaml(self, tmp_path):
        """Test loading group summary in YAML format."""
        store = SummaryStore(tmp_path)

        summary = GroupSummary(
            group_id="chapters_6_10",
            start_chapter=6,
            end_chapter=10,
            summary="Second act",
            combined_events=["Midpoint climax"],
            character_arcs={"Bob": "Growth"},
            plot_developments=["Subplot resolved"],
            created_at=datetime.now(),
            total_word_count=15000,
        )

        store.save_group_summary(summary)
        loaded = store.load_group_summary("chapters_6_10")

        assert loaded is not None
        assert loaded.group_id == "chapters_6_10"
        assert loaded.total_word_count == 15000

    def test_load_group_summary_not_found(self, tmp_path):
        """Test loading non-existent group summary."""
        store = SummaryStore(tmp_path)
        loaded = store.load_group_summary("nonexistent")
        assert loaded is None

    def test_save_global_summary_yaml(self, tmp_path):
        """Test saving global summary in YAML format."""
        store = SummaryStore(tmp_path)

        summary = GlobalSummary(
            project_name="My Novel",
            summary="Complete novel summary",
            main_plot_arc="Hero's journey",
            character_arcs={"Hero": "Full arc"},
            world_development="Detailed world",
            themes=["Adventure", "Friendship"],
            last_updated=datetime.now(),
            total_chapters_covered=50,
            total_word_count=100000,
        )

        store.save_global_summary(summary)

        path = store._get_global_summary_path()
        assert path.exists()

        with open(path, "r") as f:
            data = yaml.safe_load(f)
            assert data["project_name"] == "My Novel"
            assert data["total_chapters_covered"] == 50

    def test_load_global_summary_yaml(self, tmp_path):
        """Test loading global summary in YAML format."""
        store = SummaryStore(tmp_path)

        summary = GlobalSummary(
            project_name="Epic Saga",
            summary="Epic tale",
            main_plot_arc="Epic journey",
            character_arcs={"Protagonist": "Full development"},
            world_development="Vast world",
            themes=["Heroism", "Sacrifice"],
            last_updated=datetime.now(),
            total_chapters_covered=100,
            total_word_count=200000,
        )

        store.save_global_summary(summary)
        loaded = store.load_global_summary()

        assert loaded is not None
        assert loaded.project_name == "Epic Saga"
        assert loaded.total_word_count == 200000

    def test_load_global_summary_not_found(self, tmp_path):
        """Test loading non-existent global summary."""
        store = SummaryStore(tmp_path)
        loaded = store.load_global_summary()
        assert loaded is None

    def test_list_chapter_summaries(self, tmp_path):
        """Test listing all chapter summaries."""
        store = SummaryStore(tmp_path)

        for i in [1, 2, 5, 10]:
            summary = ChapterSummary(
                chapter_number=i,
                summary=f"Chapter {i}",
                key_events=[],
                characters={},
                locations={},
                plot_advancement="",
                next_chapter_setup="",
                created_at=datetime.now(),
            )
            store.save_chapter_summary(summary)

        chapters = store.list_chapter_summaries()
        assert sorted(chapters) == [1, 2, 5, 10]

    def test_list_chapter_summaries_empty(self, tmp_path):
        """Test listing chapters when none exist."""
        store = SummaryStore(tmp_path)
        chapters = store.list_chapter_summaries()
        assert chapters == []

    def test_list_group_summaries(self, tmp_path):
        """Test listing all group summaries."""
        store = SummaryStore(tmp_path)

        for group_id in ["chapters_1_5", "chapters_6_10", "chapters_11_15"]:
            summary = GroupSummary(
                group_id=group_id,
                start_chapter=1,
                end_chapter=5,
                summary="Group summary",
                combined_events=[],
                character_arcs={},
                plot_developments=[],
                created_at=datetime.now(),
            )
            store.save_group_summary(summary)

        groups = store.list_group_summaries()
        assert "chapters_1_5" in groups
        assert "chapters_6_10" in groups
        assert "chapters_11_15" in groups

    def test_list_group_summaries_empty(self, tmp_path):
        """Test listing groups when none exist."""
        store = SummaryStore(tmp_path)
        groups = store.list_group_summaries()
        assert groups == []

    def test_get_summary_statistics(self, tmp_path):
        """Test getting summary statistics."""
        store = SummaryStore(tmp_path)

        for i in [1, 2, 3]:
            summary = ChapterSummary(
                chapter_number=i,
                summary=f"Chapter {i}",
                key_events=[],
                characters={},
                locations={},
                plot_advancement="",
                next_chapter_setup="",
                created_at=datetime.now(),
                word_count=1000 * i,
            )
            store.save_chapter_summary(summary)

        global_summary = GlobalSummary(
            project_name="Test",
            summary="Summary",
            main_plot_arc="",
            character_arcs={},
            world_development="",
            themes=[],
            last_updated=datetime.now(),
            total_chapters_covered=3,
            total_word_count=6000,
        )
        store.save_global_summary(global_summary)

        stats = store.get_summary_statistics()
        assert stats["chapter_summaries"] == 3
        assert stats["has_global_summary"] is True
        assert stats["total_words_summarized"] == 6000

    def test_get_summary_statistics_empty(self, tmp_path):
        """Test statistics with no summaries."""
        store = SummaryStore(tmp_path)
        stats = store.get_summary_statistics()
        assert stats["chapter_summaries"] == 0
        assert stats["group_summaries"] == 0
        assert stats["has_global_summary"] is False
        assert stats["total_words_summarized"] == 0

    def test_delete_chapter_summary(self, tmp_path):
        """Test deleting a chapter summary."""
        store = SummaryStore(tmp_path)

        summary = ChapterSummary(
            chapter_number=1,
            summary="To be deleted",
            key_events=[],
            characters={},
            locations={},
            plot_advancement="",
            next_chapter_setup="",
            created_at=datetime.now(),
        )
        store.save_chapter_summary(summary)
        assert store._get_chapter_summary_path(1).exists()

        store.delete_chapter_summary(1)
        assert not store._get_chapter_summary_path(1).exists()

    def test_delete_chapter_summary_not_found(self, tmp_path):
        """Test deleting non-existent chapter summary."""
        store = SummaryStore(tmp_path)
        store.delete_chapter_summary(999)

    def test_delete_group_summary(self, tmp_path):
        """Test deleting a group summary."""
        store = SummaryStore(tmp_path)

        summary = GroupSummary(
            group_id="chapters_1_5",
            start_chapter=1,
            end_chapter=5,
            summary="To be deleted",
            combined_events=[],
            character_arcs={},
            plot_developments=[],
            created_at=datetime.now(),
        )
        store.save_group_summary(summary)
        assert store._get_group_summary_path("chapters_1_5").exists()

        store.delete_group_summary("chapters_1_5")
        assert not store._get_group_summary_path("chapters_1_5").exists()

    def test_delete_group_summary_not_found(self, tmp_path):
        """Test deleting non-existent group summary."""
        store = SummaryStore(tmp_path)
        store.delete_group_summary("nonexistent")

    def test_export_summaries_markdown(self, tmp_path):
        """Test exporting summaries to markdown."""
        store = SummaryStore(tmp_path)

        for i in [1, 2]:
            summary = ChapterSummary(
                chapter_number=i,
                summary=f"Chapter {i} summary",
                key_events=[f"Event {i}"],
                characters={},
                locations={},
                plot_advancement="",
                next_chapter_setup="",
                created_at=datetime.now(),
                word_count=1000,
            )
            store.save_chapter_summary(summary)

        global_summary = GlobalSummary(
            project_name="Test Novel",
            summary="Global summary",
            main_plot_arc="Main arc",
            character_arcs={},
            world_development="",
            themes=["Theme"],
            last_updated=datetime.now(),
            total_chapters_covered=2,
            total_word_count=2000,
        )
        store.save_global_summary(global_summary)

        output_path = tmp_path / "export.md"
        store.export_summaries(output_path, format_type="markdown")

        assert output_path.exists()
        content = output_path.read_text()
        assert "Global summary" in content
        assert "Chapter 1 summary" in content

    def test_export_summaries_json(self, tmp_path):
        """Test exporting summaries to JSON."""
        store = SummaryStore(tmp_path)

        summary = ChapterSummary(
            chapter_number=1,
            summary="Test chapter",
            key_events=["Event"],
            characters={},
            locations={},
            plot_advancement="",
            next_chapter_setup="",
            created_at=datetime.now(),
            word_count=1000,
        )
        store.save_chapter_summary(summary)

        output_path = tmp_path / "export.json"
        store.export_summaries(output_path, format_type="json")

        assert output_path.exists()
        data = json.loads(output_path.read_text())
        assert "chapter_summaries" in data
        assert len(data["chapter_summaries"]) == 1

    def test_export_summaries_yaml(self, tmp_path):
        """Test exporting summaries to YAML."""
        store = SummaryStore(tmp_path)

        summary = GroupSummary(
            group_id="chapters_1_5",
            start_chapter=1,
            end_chapter=5,
            summary="Group summary",
            combined_events=["Event"],
            character_arcs={},
            plot_developments=[],
            created_at=datetime.now(),
            total_word_count=5000,
        )
        store.save_group_summary(summary)

        output_path = tmp_path / "export.yaml"
        store.export_summaries(output_path, format_type="yaml")

        assert output_path.exists()
        data = yaml.safe_load(output_path.read_text())
        assert "group_summaries" in data
        assert len(data["group_summaries"]) == 1

    def test_backup_file_yaml(self, tmp_path):
        """Test that backup is created when saving."""
        config = SummaryStoreConfig(auto_backup=True, backup_count=3)
        store = SummaryStore(tmp_path, config)

        summary = ChapterSummary(
            chapter_number=1,
            summary="Original content",
            key_events=[],
            characters={},
            locations={},
            plot_advancement="",
            next_chapter_setup="",
            created_at=datetime.now(),
        )

        store.save_chapter_summary(summary)
        original_path = store._get_chapter_summary_path(1)

        summary.summary = "Updated content"
        store.save_chapter_summary(summary)

        backups = list(
            original_path.parent.glob(f"{original_path.stem}.backup_*{original_path.suffix}")
        )
        assert len(backups) >= 1

    def test_backup_disabled(self, tmp_path):
        """Test that no backup is created when disabled."""
        config = SummaryStoreConfig(auto_backup=False)
        store = SummaryStore(tmp_path, config)

        summary = ChapterSummary(
            chapter_number=1,
            summary="Content",
            key_events=[],
            characters={},
            locations={},
            plot_advancement="",
            next_chapter_setup="",
            created_at=datetime.now(),
        )

        store.save_chapter_summary(summary)
        original_path = store._get_chapter_summary_path(1)

        summary.summary = "Updated"
        store.save_chapter_summary(summary)

        backups = list(
            original_path.parent.glob(f"{original_path.stem}.backup_*{original_path.suffix}")
        )
        assert len(backups) == 0

    def test_cleanup_old_backups(self, tmp_path):
        """Test that old backups are cleaned up."""
        config = SummaryStoreConfig(auto_backup=True, backup_count=2)
        store = SummaryStore(tmp_path, config)

        summary = ChapterSummary(
            chapter_number=1,
            summary="Content",
            key_events=[],
            characters={},
            locations={},
            plot_advancement="",
            next_chapter_setup="",
            created_at=datetime.now(),
        )

        for i in range(5):
            summary.summary = f"Version {i}"
            store.save_chapter_summary(summary)

        original_path = store._get_chapter_summary_path(1)
        backups = list(
            original_path.parent.glob(f"{original_path.stem}.backup_*{original_path.suffix}")
        )
        assert len(backups) <= 2
