"""Tests for draft_manager.py."""

import json
from datetime import datetime

import pytest

from core.draft_manager import (
    DraftManager,
    DraftManagerConfig,
    DraftMetadata,
    DraftStatus,
    DraftVersion,
)


class TestDraftStatus:
    """Tests for DraftStatus enum."""

    def test_draft_status_values(self):
        """Test DraftStatus enum values."""
        assert DraftStatus.DRAFT == "draft"
        assert DraftStatus.ACTIVE == "active"
        assert DraftStatus.ARCHIVED == "archived"


class TestDraftMetadata:
    """Tests for DraftMetadata model."""

    def test_draft_metadata_creation(self):
        """Test creating DraftMetadata."""
        metadata = DraftMetadata(
            chapter_number=1,
            version=1,
            timestamp=datetime.now(),
            word_count=1000,
            regeneration_reason="initial",
            parent_version=None,
            status=DraftStatus.ACTIVE,
            file_path="/path/to/file.md",
            quality_score=0.85,
        )
        assert metadata.chapter_number == 1
        assert metadata.version == 1
        assert metadata.word_count == 1000
        assert metadata.regeneration_reason == "initial"
        assert metadata.parent_version is None
        assert metadata.status == DraftStatus.ACTIVE
        assert metadata.file_path == "/path/to/file.md"
        assert metadata.quality_score == 0.85

    def test_draft_metadata_optional_fields(self):
        """Test DraftMetadata with optional fields."""
        metadata = DraftMetadata(
            chapter_number=1,
            version=1,
            timestamp=datetime.now(),
            word_count=1000,
            status=DraftStatus.DRAFT,
            file_path="/path/to/file.md",
        )
        assert metadata.regeneration_reason is None
        assert metadata.parent_version is None
        assert metadata.quality_score is None


class TestDraftVersion:
    """Tests for DraftVersion model."""

    def test_draft_version_creation(self):
        """Test creating DraftVersion."""
        metadata = DraftMetadata(
            chapter_number=1,
            version=1,
            timestamp=datetime.now(),
            word_count=1000,
            status=DraftStatus.ACTIVE,
            file_path="/path/to/file.md",
        )
        version = DraftVersion(
            metadata=metadata,
            content="Chapter content",
            issues_fixed=["issue1", "issue2"],
        )
        assert version.metadata == metadata
        assert version.content == "Chapter content"
        assert version.issues_fixed == ["issue1", "issue2"]

    def test_draft_version_default_issues(self):
        """Test DraftVersion with default issues_fixed."""
        metadata = DraftMetadata(
            chapter_number=1,
            version=1,
            timestamp=datetime.now(),
            word_count=1000,
            status=DraftStatus.ACTIVE,
            file_path="/path/to/file.md",
        )
        version = DraftVersion(metadata=metadata, content="Content")
        assert version.issues_fixed == []


class TestDraftManager:
    """Tests for DraftManager class."""

    def test_initialization(self, tmp_path):
        """Test DraftManager initialization."""
        manager = DraftManager(str(tmp_path))
        assert manager.project_dir == tmp_path
        assert manager.metadata_file == tmp_path / "draft_metadata.json"
        assert manager._metadata == {}

    def test_load_metadata_empty(self, tmp_path):
        """Test loading metadata when file doesn't exist."""
        manager = DraftManager(str(tmp_path))
        assert manager._metadata == {}

    def test_load_metadata_existing(self, tmp_path):
        """Test loading existing metadata."""
        metadata_file = tmp_path / "draft_metadata.json"
        test_metadata = {
            "chapter_001": {
                "current_version": 1,
                "total_versions": 1,
                "versions": {
                    "v001": {
                        "timestamp": "2024-01-01T00:00:00",
                        "word_count": 1000,
                        "status": "active",
                        "regeneration_reason": "initial",
                        "parent_version": None,
                        "quality_score": None,
                        "suffix": "initial",
                    }
                },
            }
        }
        metadata_file.write_text(json.dumps(test_metadata))

        manager = DraftManager(str(tmp_path))
        assert manager._metadata == test_metadata

    def test_save_metadata(self, tmp_path):
        """Test saving metadata."""
        manager = DraftManager(str(tmp_path))
        manager._metadata = {"chapter_001": {"current_version": 1}}
        manager._save_metadata()

        metadata_file = tmp_path / "draft_metadata.json"
        assert metadata_file.exists()
        with open(metadata_file, "r") as f:
            saved = json.load(f)
        assert saved == {"chapter_001": {"current_version": 1}}

    def test_get_chapter_key(self, tmp_path):
        """Test _get_chapter_key method."""
        manager = DraftManager(str(tmp_path))
        assert manager._get_chapter_key(1) == "chapter_001"
        assert manager._get_chapter_key(10) == "chapter_010"
        assert manager._get_chapter_key(100) == "chapter_100"

    def test_get_chapter_dir(self, tmp_path):
        """Test _get_chapter_dir method."""
        manager = DraftManager(str(tmp_path))
        chapter_dir = manager._get_chapter_dir(1)
        expected = tmp_path / "chapters" / "chapter_001"
        assert chapter_dir == expected

    def test_get_drafts_dir(self, tmp_path):
        """Test _get_drafts_dir method."""
        manager = DraftManager(str(tmp_path))
        drafts_dir = manager._get_drafts_dir(1)
        expected = tmp_path / "chapters" / "chapter_001" / "drafts"
        assert drafts_dir == expected
        assert drafts_dir.exists()

    def test_get_current_file(self, tmp_path):
        """Test _get_current_file method."""
        manager = DraftManager(str(tmp_path))
        current_file = manager._get_current_file(1)
        expected = tmp_path / "chapters" / "chapter_001" / "current.md"
        assert current_file == expected

    def test_get_draft_file(self, tmp_path):
        """Test _get_draft_file method."""
        manager = DraftManager(str(tmp_path))
        draft_file = manager._get_draft_file(1, 2)
        expected = tmp_path / "chapters" / "chapter_001" / "drafts" / "v002_draft.md"
        assert draft_file == expected

    def test_get_version_suffix_no_metadata(self, tmp_path):
        """Test _get_version_suffix when no metadata exists."""
        manager = DraftManager(str(tmp_path))
        suffix = manager._get_version_suffix(1, 1)
        assert suffix == "draft"

    def test_get_version_suffix_with_metadata(self, tmp_path):
        """Test _get_version_suffix with metadata."""
        manager = DraftManager(str(tmp_path))
        manager._metadata = {
            "chapter_001": {
                "versions": {
                    "v001": {"suffix": "initial"},
                }
            }
        }
        suffix = manager._get_version_suffix(1, 1)
        assert suffix == "initial"

    def test_initialize_chapter_new(self, tmp_path):
        """Test initializing a new chapter."""
        manager = DraftManager(str(tmp_path))
        content = "This is the initial content of chapter 1."

        metadata = manager.initialize_chapter(1, content, "initial")

        assert metadata.chapter_number == 1
        assert metadata.version == 1
        assert metadata.word_count == 8
        assert metadata.regeneration_reason == "initial"
        assert metadata.parent_version is None
        assert metadata.status == DraftStatus.ACTIVE

    def test_initialize_chapter_existing(self, tmp_path):
        """Test initializing chapter when it already exists."""
        manager = DraftManager(str(tmp_path))

        manager.initialize_chapter(1, "First version", "initial")
        metadata = manager.initialize_chapter(1, "Second version", "regeneration")

        assert metadata.version == 2
        assert metadata.regeneration_reason == "regeneration"
        assert metadata.parent_version == 1

    def test_create_new_version_not_initialized(self, tmp_path):
        """Test creating new version for uninitialized chapter."""
        manager = DraftManager(str(tmp_path))
        with pytest.raises(ValueError, match="Chapter 1 not initialized"):
            manager.create_new_version(1, "content", "reason")

    def test_create_new_version(self, tmp_path):
        """Test creating new version."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "Initial content", "initial")

        metadata = manager.create_new_version(
            1,
            "Updated content",
            "fix_continuity",
            quality_score=0.9,
            issues_fixed=["continuity_error"],
        )

        assert metadata.version == 2
        assert metadata.word_count == 2
        assert metadata.regeneration_reason == "fix_continuity"
        assert metadata.parent_version == 1
        assert metadata.quality_score == 0.9

    def test_save_draft_content(self, tmp_path):
        """Test _save_draft_content method."""
        manager = DraftManager(str(tmp_path))
        metadata = DraftMetadata(
            chapter_number=1,
            version=1,
            timestamp=datetime.now(),
            word_count=100,
            status=DraftStatus.ACTIVE,
            file_path="/path/to/file.md",
        )

        manager._save_draft_content(1, 1, "Test content", metadata)

        draft_file = manager._get_draft_file(1, 1)
        assert draft_file.exists()
        assert draft_file.read_text() == "Test content"

    def test_archive_current_version_no_file(self, tmp_path):
        """Test _archive_current_version when file doesn't exist."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "content", "initial")

        manager._archive_current_version(1)

        assert manager._metadata["chapter_001"]["current_version"] == 1

    def test_archive_current_version_zero(self, tmp_path):
        """Test _archive_current_version when version is 0."""
        manager = DraftManager(str(tmp_path))
        manager._metadata = {
            "chapter_001": {"current_version": 0, "total_versions": 0, "versions": {}}
        }

        manager._archive_current_version(1)

    def test_set_current_version(self, tmp_path):
        """Test _set_current_version method."""
        manager = DraftManager(str(tmp_path))
        metadata = DraftMetadata(
            chapter_number=1,
            version=2,
            timestamp=datetime.now(),
            word_count=1000,
            regeneration_reason="initial",
            parent_version=1,
            status=DraftStatus.ACTIVE,
            file_path="/path/to/file.md",
            quality_score=0.85,
        )

        manager._metadata = {
            "chapter_001": {"current_version": 1, "total_versions": 1, "versions": {}}
        }
        manager._set_current_version(1, 2, metadata)

        assert manager._metadata["chapter_001"]["current_version"] == 2
        assert manager._metadata["chapter_001"]["total_versions"] == 2
        assert "v002" in manager._metadata["chapter_001"]["versions"]
        version_data = manager._metadata["chapter_001"]["versions"]["v002"]
        assert version_data["word_count"] == 1000
        assert version_data["status"] == "active"
        assert version_data["quality_score"] == 0.85

    def test_generate_suffix_none(self, tmp_path):
        """Test _generate_suffix with None reason."""
        manager = DraftManager(str(tmp_path))
        suffix = manager._generate_suffix(None)
        assert suffix == "draft"

    def test_generate_suffix_known_reasons(self, tmp_path):
        """Test _generate_suffix with known reasons."""
        manager = DraftManager(str(tmp_path))
        assert manager._generate_suffix("initial") == "initial"
        assert manager._generate_suffix("fix_continuity") == "continuity_fix"
        assert manager._generate_suffix("style_improvement") == "style_update"
        assert manager._generate_suffix("regeneration") == "regen"
        assert manager._generate_suffix("manual_edit") == "manual"

    def test_generate_suffix_unknown_reason(self, tmp_path):
        """Test _generate_suffix with unknown reason."""
        manager = DraftManager(str(tmp_path))
        suffix = manager._generate_suffix("unknown_reason")
        assert suffix == "custom"

    def test_get_current_version_not_initialized(self, tmp_path):
        """Test getting current version for uninitialized chapter."""
        manager = DraftManager(str(tmp_path))
        assert manager.get_current_version(1) is None

    def test_get_current_version(self, tmp_path):
        """Test getting current version."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "Content", "initial")

        current = manager.get_current_version(1)
        assert current is not None
        assert current.version == 1
        assert current.chapter_number == 1

    def test_get_version_not_initialized(self, tmp_path):
        """Test getting version for uninitialized chapter."""
        manager = DraftManager(str(tmp_path))
        assert manager.get_version(1, 1) is None

    def test_get_version_not_exists(self, tmp_path):
        """Test getting non-existent version."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "Content", "initial")

        assert manager.get_version(1, 99) is None

    def test_get_version(self, tmp_path):
        """Test getting specific version."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "Content", "initial")

        version = manager.get_version(1, 1)
        assert version is not None
        assert version.version == 1
        assert version.status == DraftStatus.ACTIVE

    def test_list_versions_not_initialized(self, tmp_path):
        """Test listing versions for uninitialized chapter."""
        manager = DraftManager(str(tmp_path))
        assert manager.list_versions(1) == []

    def test_list_versions(self, tmp_path):
        """Test listing all versions."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "V1", "initial")
        manager.create_new_version(1, "V2", "regeneration")
        manager.create_new_version(1, "V3", "fix_continuity")

        versions = manager.list_versions(1)
        assert len(versions) == 3
        assert versions[0].version == 1
        assert versions[1].version == 2
        assert versions[2].version == 3

    def test_get_version_content_not_exists(self, tmp_path):
        """Test getting content for non-existent version."""
        manager = DraftManager(str(tmp_path))
        assert manager.get_version_content(1, 1) is None

    def test_get_version_content(self, tmp_path):
        """Test getting version content."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "Test content", "initial")

        content = manager.get_version_content(1, 1)
        assert content == "Test content"

        manager.create_new_version(1, "New content", "regeneration")
        new_content = manager.get_version_content(1, 2)
        assert new_content == "New content"

    def test_delete_version_not_initialized(self, tmp_path):
        """Test deleting version for uninitialized chapter."""
        manager = DraftManager(str(tmp_path))
        assert manager.delete_version(1, 1) is False

    def test_delete_version_current(self, tmp_path):
        """Test deleting current version raises error."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "Content", "initial")

        with pytest.raises(ValueError, match="Cannot delete current version"):
            manager.delete_version(1, 1)

    def test_delete_version_not_exists(self, tmp_path):
        """Test deleting non-existent version."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "V1", "initial")
        manager.create_new_version(1, "V2", "regeneration")

        assert manager.delete_version(1, 99) is False

    def test_delete_version(self, tmp_path):
        """Test deleting version."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "V1", "initial")
        manager.create_new_version(1, "V2", "regeneration")

        result = manager.delete_version(1, 1)
        assert result is True

        versions = manager.list_versions(1)
        assert len(versions) == 1
        assert versions[0].version == 2

    def test_archive_old_versions_all_keep(self, tmp_path):
        """Test archiving when all versions should be kept."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "V1", "initial")
        manager.create_new_version(1, "V2", "regeneration")

        archived = manager.archive_old_versions(1, keep_recent=5)
        assert archived == 0

    def test_archive_old_versions(self, tmp_path):
        """Test archiving old versions."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "V1", "initial")
        manager.create_new_version(1, "V2", "regeneration")
        manager.create_new_version(1, "V3", "fix_continuity")
        manager.create_new_version(1, "V4", "style_improvement")
        manager.create_new_version(1, "V5", "regeneration")
        manager.create_new_version(1, "V6", "manual_edit")

        archived = manager.archive_old_versions(1, keep_recent=3)
        assert archived == 3

        versions = manager.list_versions(1)
        archived_versions = [v for v in versions if v.status == DraftStatus.ARCHIVED]
        assert len(archived_versions) == 3

    def test_get_chapter_summary_not_initialized(self, tmp_path):
        """Test getting summary for uninitialized chapter."""
        manager = DraftManager(str(tmp_path))
        summary = manager.get_chapter_summary(1)

        assert summary["chapter_number"] == 1
        assert summary["initialized"] is False

    def test_get_chapter_summary(self, tmp_path):
        """Test getting chapter summary."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "Content for chapter one", "initial")

        summary = manager.get_chapter_summary(1)
        assert summary["chapter_number"] == 1
        assert summary["initialized"] is True
        assert summary["current_version"] == 1
        assert summary["total_versions"] == 1
        assert summary["word_count"] == 4
        assert summary["version_count"] == 1

    def test_get_project_summary(self, tmp_path):
        """Test getting project summary."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "Content 1", "initial")
        manager.initialize_chapter(2, "Content 2", "initial")
        manager.initialize_chapter(3, "Content 3", "initial")

        summary = manager.get_project_summary()
        assert summary["total_chapters"] == 3
        assert summary["total_drafts"] == 3
        assert summary["total_words"] == 6
        assert len(summary["chapters"]) == 3
        assert summary["chapters"][0]["chapter_number"] == 1
        assert summary["chapters"][1]["chapter_number"] == 2
        assert summary["chapters"][2]["chapter_number"] == 3

    def test_version_file_naming_with_suffix(self, tmp_path):
        """Test that version files use suffixes from metadata."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "V1", "initial")
        manager.create_new_version(1, "V2", "fix_continuity")
        manager.create_new_version(1, "V3", "style_improvement")

        version_1 = manager.get_version(1, 1)
        version_2 = manager.get_version(1, 2)
        version_3 = manager.get_version(1, 3)

        assert "initial" in version_1.file_path
        assert version_1.regeneration_reason == "initial"
        assert version_2.regeneration_reason == "fix_continuity"
        assert version_3.regeneration_reason == "style_improvement"

    def test_persistence_across_instances(self, tmp_path):
        """Test that metadata persists across manager instances."""
        manager1 = DraftManager(str(tmp_path))
        manager1.initialize_chapter(1, "Content", "initial")
        manager1.create_new_version(1, "Updated", "regeneration")

        manager2 = DraftManager(str(tmp_path))
        versions = manager2.list_versions(1)
        assert len(versions) == 2
        assert versions[0].version == 1
        assert versions[1].version == 2


class TestVersioningToggle:
    """Tests for enable/disable versioning feature."""

    def test_versioning_enabled_by_default(self, tmp_path):
        """Test that versioning is enabled by default."""
        manager = DraftManager(str(tmp_path))
        assert manager.is_versioning_enabled() is True

    def test_config_enable_versioning_true(self, tmp_path):
        """Test DraftManagerConfig with enable_versioning=True."""
        config = DraftManagerConfig(enable_versioning=True)
        manager = DraftManager(str(tmp_path), config=config)
        assert manager.is_versioning_enabled() is True

    def test_config_enable_versioning_false(self, tmp_path):
        """Test DraftManagerConfig with enable_versioning=False."""
        config = DraftManagerConfig(enable_versioning=False)
        manager = DraftManager(str(tmp_path), config=config)
        assert manager.is_versioning_enabled() is False

    def test_initialize_chapter_versioning_disabled(self, tmp_path):
        """Test initialize_chapter when versioning is disabled."""
        config = DraftManagerConfig(enable_versioning=False)
        manager = DraftManager(str(tmp_path), config=config)
        manager.initialize_chapter(1, "Initial content", "initial")

        current_file = tmp_path / "chapters" / "chapter_001" / "current.md"
        assert current_file.exists()
        assert current_file.read_text() == "Initial content"

        versions = manager.list_versions(1)
        assert len(versions) == 0

    def test_create_new_version_versioning_disabled(self, tmp_path):
        """Test create_new_version when versioning is disabled."""
        config = DraftManagerConfig(enable_versioning=False)
        manager = DraftManager(str(tmp_path), config=config)
        manager.initialize_chapter(1, "Initial content", "initial")
        manager.create_new_version(1, "Updated content", "fix")

        current_file = tmp_path / "chapters" / "chapter_001" / "current.md"
        assert current_file.read_text() == "Updated content"

        drafts_dir = tmp_path / "chapters" / "chapter_001" / "drafts"
        assert not drafts_dir.exists()

    def test_multiple_versions_versioning_disabled(self, tmp_path):
        """Test multiple version creates when versioning is disabled."""
        config = DraftManagerConfig(enable_versioning=False)
        manager = DraftManager(str(tmp_path), config=config)
        manager.initialize_chapter(1, "V1", "initial")
        manager.create_new_version(1, "V2", "fix1")
        manager.create_new_version(1, "V3", "fix2")
        manager.create_new_version(1, "V4", "fix3")

        current_file = tmp_path / "chapters" / "chapter_001" / "current.md"
        assert current_file.read_text() == "V4"

        drafts_dir = tmp_path / "chapters" / "chapter_001" / "drafts"
        assert not drafts_dir.exists()

    def test_metadata_file_not_created_when_disabled(self, tmp_path):
        """Test that metadata file is not created when versioning is disabled."""
        config = DraftManagerConfig(enable_versioning=False)
        manager = DraftManager(str(tmp_path), config=config)
        manager.initialize_chapter(1, "Content", "initial")

        metadata_file = tmp_path / "draft_metadata.json"
        assert not metadata_file.exists()

    def test_content_only_mode_comparison(self, tmp_path):
        """Test that content-only mode saves to current.md without drafts folder."""
        config_disabled = DraftManagerConfig(enable_versioning=False)

        disabled_path = tmp_path / "disabled"
        disabled_path.mkdir()
        manager_disabled = DraftManager(str(disabled_path), config=config_disabled)
        manager_disabled.initialize_chapter(1, "Content V1", "initial")
        manager_disabled.create_new_version(1, "Content V2", "fix")

        current_disabled = manager_disabled.get_current_content(1)

        assert current_disabled == "Content V2"

        drafts_dir = disabled_path / "chapters" / "chapter_001" / "drafts"
        assert not drafts_dir.exists()

    def test_archive_current_version_with_existing_file(self, tmp_path):
        """Test _archive_current_version when file exists and version > 0."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "Content to archive", "initial")
        current_file = tmp_path / "chapters" / "chapter_001" / "current.md"
        current_file.parent.mkdir(parents=True, exist_ok=True)
        current_file.write_text("Archived content")
        manager._archive_current_version(1)
        drafts_dir = tmp_path / "chapters" / "chapter_001" / "drafts"
        archived_files = list(drafts_dir.glob("v001_*.md"))
        assert len(archived_files) >= 1
        assert archived_files[0].read_text() == "Archived content"

    def test_delete_version_removes_draft_file(self, tmp_path):
        """Test delete_version removes the draft file when it exists (line 361→364)."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "V1", "initial")
        manager.create_new_version(1, "V2", "regeneration")
        v1_file = manager._get_draft_file(1, 1)
        assert v1_file.exists()
        result = manager.delete_version(1, 1)
        assert result is True
        assert not v1_file.exists()

    def test_archive_old_versions_saves_metadata(self, tmp_path):
        """Test archive_old_versions saves metadata when archiving (lines 379→378, 388→391)."""
        manager = DraftManager(str(tmp_path))
        manager.initialize_chapter(1, "V1", "initial")
        for i in range(2, 7):
            manager.create_new_version(1, f"V{i}", "regeneration")
        archived = manager.archive_old_versions(1, keep_recent=3)
        assert archived == 3
        saved_meta = json.loads((tmp_path / "draft_metadata.json").read_text())
        v1_status = saved_meta["chapter_001"]["versions"]["v001"]["status"]
        assert v1_status == "archived"

    def test_get_current_content_returns_none(self, tmp_path):
        """Test get_current_content returns None when no current file (line 431)."""
        manager = DraftManager(str(tmp_path))
        assert manager.get_current_content(1) is None

    def test_auto_archive_respected_when_enabled(self, tmp_path):
        """Test auto_archive setting is respected."""
        config = DraftManagerConfig(enable_versioning=True, auto_archive=False)
        manager = DraftManager(str(tmp_path), config=config)
        assert manager.config.auto_archive is False

    def test_max_versions_setting(self, tmp_path):
        """Test max_versions_per_chapter setting."""
        config = DraftManagerConfig(enable_versioning=True, max_versions_per_chapter=3)
        manager = DraftManager(str(tmp_path), config=config)
        assert manager.config.max_versions_per_chapter == 3
