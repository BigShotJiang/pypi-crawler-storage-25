"""Tests for object_pool module."""

import threading

import pytest

from core.object_pool import (
    ContentBufferPool,
    ObjectPool,
    ObjectPoolConfig,
    PagedContentBuffer,
    PoolableObject,
    PooledStringBuilder,
    PoolManager,
    PoolStats,
    StringBuilderPool,
    get_global_pool,
    get_pool_manager,
    register_global_pool,
)


class TestPoolableObject:
    """Test PoolableObject base class."""

    def test_reset_not_implemented(self):
        """Test reset raises NotImplementedError."""
        obj = PoolableObject()
        with pytest.raises(NotImplementedError):
            obj.reset()

    def test_validate_default(self):
        """Test validate returns True by default."""
        obj = PoolableObject()
        assert obj.validate() is True


class CustomPoolableObject:
    """Custom poolable object for testing."""

    def __init__(self, value=0):
        self.value = value

    def reset(self):
        """Reset object to initial state."""
        self.value = 0

    def validate(self) -> bool:
        """Validate object is in good state."""
        return self.value >= 0


class InvalidPoolableObject:
    """Poolable object that always fails validation."""

    def reset(self):
        """Reset object."""
        pass

    def validate(self) -> bool:
        """Always fail validation."""
        return False


class TestObjectPoolConfig:
    """Test ObjectPoolConfig model."""

    def test_default_config(self):
        """Test ObjectPoolConfig with default values."""
        config = ObjectPoolConfig()
        assert config.initial_size == 5
        assert config.max_size == 50
        assert config.shrink_threshold == 0.3
        assert config.shrink_interval_seconds == 300
        assert config.enable_validation is True
        assert config.enable_statistics is True

    def test_custom_config(self):
        """Test ObjectPoolConfig with custom values."""
        config = ObjectPoolConfig(
            initial_size=10,
            max_size=100,
            shrink_threshold=0.5,
            shrink_interval_seconds=600,
            enable_validation=False,
            enable_statistics=False,
        )
        assert config.initial_size == 10
        assert config.max_size == 100
        assert config.shrink_threshold == 0.5
        assert config.shrink_interval_seconds == 600
        assert config.enable_validation is False
        assert config.enable_statistics is False


class TestPoolStats:
    """Test PoolStats dataclass."""

    def test_pool_stats_creation(self):
        """Test PoolStats creation."""
        stats = PoolStats(
            total_acquired=10,
            total_released=5,
            total_created=15,
            current_size=10,
            current_available=5,
            peak_size=20,
            validation_failures=1,
        )
        assert stats.total_acquired == 10
        assert stats.total_released == 5
        assert stats.total_created == 15
        assert stats.current_size == 10
        assert stats.current_available == 5
        assert stats.peak_size == 20
        assert stats.validation_failures == 1

    def test_utilization_rate_zero_size(self):
        """Test utilization_rate with zero size."""
        stats = PoolStats(current_size=0, current_available=0)
        assert stats.utilization_rate() == 0.0

    def test_utilization_rate_half_used(self):
        """Test utilization_rate with half objects in use."""
        stats = PoolStats(current_size=10, current_available=5)
        assert stats.utilization_rate() == 0.5

    def test_utilization_rate_fully_used(self):
        """Test utilization_rate with all objects in use."""
        stats = PoolStats(current_size=10, current_available=0)
        assert stats.utilization_rate() == 1.0

    def test_utilization_rate_all_available(self):
        """Test utilization_rate with all objects available."""
        stats = PoolStats(current_size=10, current_available=10)
        assert stats.utilization_rate() == 0.0


class TestObjectPool:
    """Test ObjectPool class."""

    @pytest.fixture
    def pool(self):
        """Create ObjectPool instance with CustomPoolableObject."""
        config = ObjectPoolConfig(
            initial_size=3,
            max_size=10,
            enable_validation=True,
        )
        return ObjectPool(lambda: CustomPoolableObject(), config)

    def test_initialization(self, pool):
        """Test ObjectPool initialization."""
        assert pool.factory is not None
        assert pool.config is not None
        assert len(pool.pool) == 3
        assert pool.stats.total_created == 3
        assert pool.stats.current_size == 3
        assert pool.stats.current_available == 3

    def test_initialization_with_default_config(self):
        """Test initialization with default config."""
        pool = ObjectPool(lambda: CustomPoolableObject())
        assert pool.config == ObjectPoolConfig()

    def test_acquire_from_pool(self, pool):
        """Test acquiring object from pool."""
        obj = pool.acquire()
        assert obj is not None
        assert isinstance(obj, CustomPoolableObject)
        assert pool.stats.total_acquired == 1
        assert pool.stats.current_available == 2
        assert len(pool.in_use) == 1

    def test_acquire_creates_new_object(self, pool):
        """Test acquiring creates new object when pool is empty."""
        for _ in range(3):
            pool.acquire()

        assert len(pool.pool) == 0

        obj = pool.acquire()
        assert obj is not None
        assert pool.stats.total_created == 4
        assert pool.stats.current_size == 4

    def test_acquire_respects_max_size(self):
        """Test acquire respects max_size limit."""
        config = ObjectPoolConfig(initial_size=2, max_size=5)
        pool = ObjectPool(lambda: CustomPoolableObject(), config)

        objects = []
        for _ in range(10):
            obj = pool.acquire()
            if obj:
                objects.append(obj)

        assert pool.stats.current_size <= 5
        assert pool.stats.peak_size <= 5

    def test_acquire_validates_object(self):
        """Test acquire validates object if validation enabled."""
        config = ObjectPoolConfig(initial_size=2, enable_validation=True)
        pool = ObjectPool(lambda: CustomPoolableObject(), config)

        obj = pool.acquire()
        assert obj is not None
        assert pool.stats.validation_failures == 0

    def test_acquire_handles_validation_failure(self):
        """Test acquire handles validation failure."""
        config = ObjectPoolConfig(initial_size=2, enable_validation=True)
        pool = ObjectPool(lambda: InvalidPoolableObject(), config)

        for _ in range(3):
            obj = pool.acquire()
            assert obj is None

        assert pool.stats.validation_failures >= 1

    def test_acquire_with_validation_disabled(self):
        """Test acquire with validation disabled."""
        config = ObjectPoolConfig(initial_size=2, enable_validation=False)
        pool = ObjectPool(lambda: CustomPoolableObject(), config)

        obj = pool.acquire()
        assert obj is not None

    def test_release_back_to_pool(self, pool):
        """Test releasing object back to pool."""
        obj = pool.acquire()
        assert len(pool.in_use) == 1

        pool.release(obj)
        assert len(pool.in_use) == 0
        assert pool.stats.total_released == 1
        assert pool.stats.current_available == 3
        assert obj in pool.pool

    def test_release_resets_object(self, pool):
        """Test release resets object."""
        obj = pool.acquire()
        obj.value = 42

        pool.release(obj)

        assert obj.value == 0

    def test_release_with_full_pool(self):
        """Test release when pool is at max_size."""
        config = ObjectPoolConfig(initial_size=5, max_size=5)
        pool = ObjectPool(lambda: CustomPoolableObject(), config)

        obj1 = pool.acquire()
        assert pool.stats.current_size == 5

        pool.release(obj1)
        assert pool.stats.current_size == 5

    def test_release_object_not_in_use(self, pool):
        """Test releasing object that's not in use."""
        obj = CustomPoolableObject()

        pool.release(obj)
        assert len(pool.in_use) == 0

    def test_clear(self, pool):
        """Test clearing pool."""
        for _ in range(2):
            pool.acquire()

        assert len(pool.pool) == 1
        assert len(pool.in_use) == 2

        pool.clear()

        assert len(pool.pool) == 0
        assert len(pool.in_use) == 0
        assert pool.stats.current_size == 0
        assert pool.stats.current_available == 0

    def test_get_stats(self, pool):
        """Test getting pool statistics."""
        for _ in range(2):
            obj = pool.acquire()
            pool.release(obj)

        stats = pool.get_stats()

        assert stats["total_acquired"] == 2
        assert stats["total_released"] == 2
        assert stats["total_created"] == 3
        assert stats["current_size"] == 3
        assert stats["current_in_use"] == 0
        assert "peak_size" in stats
        assert "utilization_rate" in stats
        assert "validation_failures" in stats

    def test_shrink(self, pool):
        """Test shrinking pool."""
        config = ObjectPoolConfig(initial_size=5, max_size=20, shrink_threshold=0.5)
        pool = ObjectPool(lambda: CustomPoolableObject(), config)

        for _ in range(10):
            obj = pool.acquire()
            pool.release(obj)

        pool.stats.peak_size = 20

        pool.shrink()

        assert pool.stats.current_size >= 5
        assert pool.stats.current_size <= 10

    def test_shrink_to_initial_size(self, pool):
        """Test shrink respects initial_size."""
        config = ObjectPoolConfig(initial_size=3, max_size=10, shrink_threshold=0.5)
        pool = ObjectPool(lambda: CustomPoolableObject(), config)

        pool.stats.peak_size = 8
        pool.stats.current_size = 8

        pool.shrink()

        assert pool.stats.current_size >= 3

    def test_optimize(self, pool):
        """Test optimize method."""
        config = ObjectPoolConfig(initial_size=5, max_size=20, shrink_threshold=0.5)
        pool = ObjectPool(lambda: CustomPoolableObject(), config)

        pool.stats.peak_size = 10
        for _ in range(8):
            obj = pool.acquire()
            pool.release(obj)

        pool.optimize()

        assert pool.stats.current_size < 10

    def test_optimize_no_shrink_needed(self, pool):
        """Test optimize when no shrink needed."""
        for _ in range(2):
            pool.acquire()

        initial_size = pool.stats.current_size

        pool.optimize()

        assert pool.stats.current_size == initial_size

    def test_factory_exception_handling(self):
        """Test factory exception handling."""
        config = ObjectPoolConfig(initial_size=0, max_size=5)
        call_count = [0]

        def failing_factory():
            call_count[0] += 1
            if call_count[0] <= 2:
                raise RuntimeError("Factory failed")
            return CustomPoolableObject()

        pool = ObjectPool(failing_factory, config)

        obj = pool.acquire()
        assert obj is not None
        assert call_count[0] == 3

    def test_thread_safe_acquire_release(self):
        """Test thread-safe acquire and release operations."""
        config = ObjectPoolConfig(initial_size=5, max_size=20)
        pool = ObjectPool(lambda: CustomPoolableObject(), config)

        def worker():
            for _ in range(100):
                obj = pool.acquire()
                if obj:
                    obj.value = 42
                    pool.release(obj)

        threads = [threading.Thread(target=worker) for _ in range(5)]

        for thread in threads:
            thread.start()

        for thread in threads:
            thread.join()

        stats = pool.get_stats()
        assert stats["total_acquired"] == 500
        assert stats["total_released"] == 500

    def test_peak_size_tracking(self):
        """Test peak size is tracked correctly."""
        config = ObjectPoolConfig(initial_size=2, max_size=10)
        pool = ObjectPool(lambda: CustomPoolableObject(), config)

        objects = []
        for _ in range(5):
            obj = pool.acquire()
            if obj:
                objects.append(obj)

        assert pool.stats.peak_size == 5

    def test_multiple_acquire_release_cycles(self, pool):
        """Test multiple acquire/release cycles."""
        for _ in range(10):
            obj = pool.acquire()
            assert obj is not None
            pool.release(obj)

        assert pool.stats.total_acquired == 10
        assert pool.stats.total_released == 10

    def test_acquire_without_reset_method(self):
        """Test acquiring object without reset method."""

        class SimpleObject:
            pass

        pool = ObjectPool(lambda: SimpleObject(), ObjectPoolConfig(initial_size=2))

        obj = pool.acquire()
        pool.release(obj)

        assert len(pool.pool) > 0

    def test_acquire_with_exception_in_reset(self):
        """Test release with exception in reset."""

        class BadObject:
            def reset(self):
                raise RuntimeError("Reset failed")

        pool = ObjectPool(lambda: BadObject(), ObjectPoolConfig(initial_size=2))

        obj = pool.acquire()
        pool.release(obj)

        assert len(pool.pool) == 1

    def test_utilization_rate_in_stats(self, pool):
        """Test utilization_rate is included in stats."""
        pool.acquire()
        pool.acquire()

        stats = pool.get_stats()
        assert "%" in stats["utilization_rate"]


class TestPooledStringBuilder:
    """Test PooledStringBuilder class."""

    def test_initialization(self):
        """Test PooledStringBuilder initialization."""
        builder = PooledStringBuilder()
        assert builder.parts == []
        assert builder.length == 0

    def test_append(self):
        """Test append method."""
        builder = PooledStringBuilder()
        builder.append("Hello")
        builder.append(" ")
        builder.append("World")

        assert len(builder.parts) == 3
        assert builder.length == 11

    def test_build(self):
        """Test build method."""
        builder = PooledStringBuilder()
        builder.append("Hello")
        builder.append(" ")
        builder.append("World")

        result = builder.build()
        assert result == "Hello World"

    def test_reset(self):
        """Test reset method."""
        builder = PooledStringBuilder()
        builder.append("Hello")
        builder.append("World")

        builder.reset()

        assert builder.parts == []
        assert builder.length == 0

    def test_validate(self):
        """Test validate method."""
        builder = PooledStringBuilder()
        builder.append("Hello")
        builder.append("World")

        assert builder.validate() is True

    def test_validate_with_mismatch(self):
        """Test validate with length mismatch."""
        builder = PooledStringBuilder()
        builder.append("Hello")
        builder.length = 100

        assert builder.validate() is False


class TestStringBuilderPool:
    """Test StringBuilderPool singleton."""

    def test_singleton(self):
        """Test StringBuilderPool is singleton."""
        pool1 = StringBuilderPool()
        pool2 = StringBuilderPool()
        assert pool1 is pool2

    def test_acquire(self):
        """Test acquiring string builder."""
        pool = StringBuilderPool()
        builder = pool.acquire()
        assert isinstance(builder, PooledStringBuilder)

    def test_acquire_creates_new_if_empty(self):
        """Test acquire creates new builder if pool is empty."""
        pool = StringBuilderPool()
        builder = pool.acquire()
        assert builder is not None

    def test_release(self):
        """Test releasing string builder."""
        pool = StringBuilderPool()
        builder = pool.acquire()
        pool.release(builder)

    def test_thread_safe_singleton(self):
        """Test singleton is thread-safe."""

        def create_pool():
            return StringBuilderPool()

        pools = []
        threads = [threading.Thread(target=lambda: pools.append(create_pool())) for _ in range(5)]

        for thread in threads:
            thread.start()

        for thread in threads:
            thread.join()

        assert all(p is pools[0] for p in pools)


class TestPagedContentBuffer:
    """Test PagedContentBuffer class."""

    def test_initialization(self):
        """Test PagedContentBuffer initialization."""
        buffer = PagedContentBuffer()
        assert buffer.pages == []
        assert buffer.metadata == {}

    def test_add_page(self):
        """Test add_page method."""
        buffer = PagedContentBuffer()
        buffer.add_page("Page 1")
        buffer.add_page("Page 2")

        assert len(buffer.pages) == 2
        assert buffer.pages[0] == "Page 1"
        assert buffer.pages[1] == "Page 2"

    def test_get_pages(self):
        """Test get_pages method."""
        buffer = PagedContentBuffer()
        buffer.add_page("Page 1")
        buffer.add_page("Page 2")

        pages = buffer.get_pages()
        assert pages == ["Page 1", "Page 2"]

    def test_reset(self):
        """Test reset method."""
        buffer = PagedContentBuffer()
        buffer.add_page("Page 1")
        buffer.metadata["key"] = "value"

        buffer.reset()

        assert buffer.pages == []
        assert buffer.metadata == {}

    def test_validate(self):
        """Test validate method."""
        buffer = PagedContentBuffer()
        assert buffer.validate() is True

    def test_validate_with_pages(self):
        """Test validate with pages."""
        buffer = PagedContentBuffer()
        buffer.add_page("Page 1")
        assert buffer.validate() is True


class TestContentBufferPool:
    """Test ContentBufferPool singleton."""

    def test_singleton(self):
        """Test ContentBufferPool is singleton."""
        pool1 = ContentBufferPool()
        pool2 = ContentBufferPool()
        assert pool1 is pool2

    def test_acquire(self):
        """Test acquiring buffer."""
        pool = ContentBufferPool()
        buffer = pool.acquire()
        assert isinstance(buffer, PagedContentBuffer)

    def test_release(self):
        """Test releasing buffer."""
        pool = ContentBufferPool()
        buffer = pool.acquire()
        pool.release(buffer)


class TestPoolManager:
    """Test PoolManager class."""

    @pytest.fixture
    def manager(self):
        """Create PoolManager instance."""
        return PoolManager()

    def test_initialization(self, manager):
        """Test PoolManager initialization."""
        assert manager.pools == {}
        assert isinstance(manager.lock, type(threading.RLock()))

    def test_register_pool(self, manager):
        """Test registering a pool."""
        pool = ObjectPool(lambda: CustomPoolableObject(), ObjectPoolConfig())
        manager.register_pool("test_pool", pool)

        assert "test_pool" in manager.pools
        assert manager.pools["test_pool"] == pool

    def test_get_pool(self, manager):
        """Test getting pool by name."""
        pool = ObjectPool(lambda: CustomPoolableObject(), ObjectPoolConfig())
        manager.register_pool("test_pool", pool)

        retrieved_pool = manager.get_pool("test_pool")
        assert retrieved_pool == pool

    def test_get_pool_not_found(self, manager):
        """Test getting non-existent pool."""
        pool = manager.get_pool("nonexistent")
        assert pool is None

    def test_optimize_all(self, manager):
        """Test optimizing all pools."""
        pool1 = ObjectPool(lambda: CustomPoolableObject(), ObjectPoolConfig())
        pool2 = ObjectPool(lambda: CustomPoolableObject(), ObjectPoolConfig())

        manager.register_pool("pool1", pool1)
        manager.register_pool("pool2", pool2)

        manager.optimize_all()

    def test_clear_all(self, manager):
        """Test clearing all pools."""
        pool1 = ObjectPool(lambda: CustomPoolableObject(), ObjectPoolConfig())
        pool2 = ObjectPool(lambda: CustomPoolableObject(), ObjectPoolConfig())

        manager.register_pool("pool1", pool1)
        manager.register_pool("pool2", pool2)

        pool1.acquire()
        pool2.acquire()

        manager.clear_all()

        assert pool1.stats.current_size == 0
        assert pool2.stats.current_size == 0

    def test_get_all_stats(self, manager):
        """Test getting statistics for all pools."""
        pool1 = ObjectPool(lambda: CustomPoolableObject(), ObjectPoolConfig())
        pool2 = ObjectPool(lambda: CustomPoolableObject(), ObjectPoolConfig())

        manager.register_pool("pool1", pool1)
        manager.register_pool("pool2", pool2)

        stats = manager.get_all_stats()

        assert "pool1" in stats
        assert "pool2" in stats
        assert "total_created" in stats["pool1"]
        assert "total_created" in stats["pool2"]

    def test_get_all_stats_empty_manager(self, manager):
        """Test getting stats from empty manager."""
        stats = manager.get_all_stats()
        assert stats == {}

    def test_thread_safe_operations(self, manager):
        """Test thread-safe pool operations."""
        pool = ObjectPool(lambda: CustomPoolableObject(), ObjectPoolConfig())
        manager.register_pool("test_pool", pool)

        def worker():
            for _ in range(10):
                retrieved_pool = manager.get_pool("test_pool")
                if retrieved_pool:
                    obj = retrieved_pool.acquire()
                    if obj:
                        retrieved_pool.release(obj)

        threads = [threading.Thread(target=worker) for _ in range(5)]

        for thread in threads:
            thread.start()

        for thread in threads:
            thread.join()


class TestGlobalPoolManager:
    """Test global pool manager functions."""

    def test_get_pool_manager_singleton(self):
        """Test get_pool_manager returns singleton."""
        manager1 = get_pool_manager()
        manager2 = get_pool_manager()
        assert manager1 is manager2

    def test_register_global_pool(self):
        """Test registering pool globally."""
        pool = ObjectPool(lambda: CustomPoolableObject(), ObjectPoolConfig())
        register_global_pool("global_test", pool)

        manager = get_pool_manager()
        retrieved_pool = manager.get_pool("global_test")
        assert retrieved_pool == pool

    def test_get_global_pool(self):
        """Test getting pool from global manager."""
        pool = ObjectPool(lambda: CustomPoolableObject(), ObjectPoolConfig())
        register_global_pool("global_test2", pool)

        retrieved_pool = get_global_pool("global_test2")
        assert retrieved_pool == pool

    def test_get_global_pool_not_found(self):
        """Test getting non-existent global pool."""
        pool = get_global_pool("nonexistent_global")
        assert pool is None

    def test_global_pool_manager_isolation(self):
        """Test global pool manager is properly isolated."""
        pool1 = ObjectPool(lambda: CustomPoolableObject(), ObjectPoolConfig())
        pool2 = ObjectPool(lambda: CustomPoolableObject(), ObjectPoolConfig())

        register_global_pool("pool1", pool1)
        register_global_pool("pool2", pool2)

        stats = get_pool_manager().get_all_stats()
        assert "pool1" in stats
        assert "pool2" in stats
