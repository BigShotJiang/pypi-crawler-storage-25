"""
Comprehensive tests for autonomous_executor.py to increase coverage to 90%+.
Tests edge cases, error handling, and all execution paths.
"""

from pathlib import Path
from unittest.mock import Mock, patch

import pytest

from novel_harness.core.autonomous_executor import (
    AutonomousConfig,
    AutonomousExecutor,
    AutonomousResult,
)
from novel_harness.core.progress_tracker import ExecutionStatus


class TestAutonomousConfig:
    """Test AutonomousConfig configuration."""

    def test_default_config(self):
        """Test default configuration values."""
        config = AutonomousConfig(project_name="test_project")

        assert config.project_name == "test_project"
        assert config.start_phase == "new_novel"
        assert config.end_phase == "verification_phase"
        assert config.human_in_loop is False
        assert config.max_chapters is None
        assert config.provider == "openai"

    def test_custom_config(self):
        """Test custom configuration."""
        config = AutonomousConfig(
            project_name="custom_project",
            start_phase="outline_phase",
            end_phase="writing_phase",
            human_in_loop=True,
            max_chapters=10,
            provider="openai",
        )

        assert config.project_name == "custom_project"
        assert config.start_phase == "outline_phase"
        assert config.end_phase == "writing_phase"
        assert config.human_in_loop is True
        assert config.max_chapters == 10
        assert config.provider == "openai"


class TestAutonomousResult:
    """Test AutonomousResult model."""

    def test_success_result(self):
        """Test successful result."""
        result = AutonomousResult(
            success=True,
            completed_phases=["phase1", "phase2"],
            final_status=ExecutionStatus.COMPLETED,
        )

        assert result.success is True
        assert result.completed_phases == ["phase1", "phase2"]
        assert result.final_status == ExecutionStatus.COMPLETED
        assert result.error is None
        assert result.checkpoint_id is None

    def test_failure_result(self):
        """Test failed result."""
        result = AutonomousResult(
            success=False,
            completed_phases=["phase1"],
            final_status=ExecutionStatus.FAILED,
            error="Test error",
        )

        assert result.success is False
        assert result.error == "Test error"

    def test_paused_result(self):
        """Test paused result."""
        result = AutonomousResult(
            success=False,
            completed_phases=["phase1", "phase2"],
            final_status=ExecutionStatus.PAUSED,
            checkpoint_id="ckpt_123",
            error="Stopped by user",
        )

        assert result.success is False
        assert result.final_status == ExecutionStatus.PAUSED
        assert result.checkpoint_id == "ckpt_123"


class TestAutonomousExecutorInit:
    """Test AutonomousExecutor initialization."""

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_init_with_defaults(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
    ):
        """Test initialization with default configuration."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()

        config = AutonomousConfig(project_name="test_project")
        storage_path = Path("/tmp/test")

        executor = AutonomousExecutor(config, storage_path)

        assert executor.config == config
        assert executor.storage_path == storage_path

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_init_with_human_in_loop(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
    ):
        """Test initialization with human-in-the-loop enabled."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()

        config = AutonomousConfig(project_name="test_project", human_in_loop=True)
        storage_path = Path("/tmp/test")

        executor = AutonomousExecutor(config, storage_path)

        assert executor.config.human_in_loop is True


class TestExecuteMethod:
    """Test execute method."""

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_execute_full_pipeline(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test executing full pipeline."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=Mock())
        mock_progress_instance.initialize = Mock()
        mock_progress_instance.set_status = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_executor_instance = Mock()
        mock_executor_instance.execute_workflow = Mock(return_value={"success": True, "output": {}})
        mock_executor.return_value = mock_executor_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="outline_phase",
            end_phase="outline_phase",
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=False)

        assert isinstance(result, AutonomousResult)
        mock_progress_instance.initialize.assert_called_once()

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_execute_resume_from_checkpoint(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test resuming from checkpoint."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=Mock())
        mock_progress_instance.set_status = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_checkpoint_instance = Mock()
        mock_checkpoint_instance.load_checkpoint = Mock(
            return_value=Mock(
                completed_workflows=["outline_phase"],
                execution_context={},
                progress_state=Mock(),
            )
        )
        mock_checkpoint_instance.validate_checkpoint = Mock(return_value=True)
        mock_checkpoint.return_value = mock_checkpoint_instance

        mock_executor_instance = Mock()
        mock_executor_instance.execute_workflow = Mock(return_value={"success": True, "output": {}})
        mock_executor.return_value = mock_executor_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="character_phase",
            end_phase="character_phase",
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=True)

        assert isinstance(result, AutonomousResult)

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_execute_with_exception(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test execution with exception."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=Mock(completed_phases=[]))
        mock_progress_instance.set_status = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_executor_instance = Mock()
        mock_executor_instance.execute_workflow = Mock(side_effect=Exception("Test error"))
        mock_executor.return_value = mock_executor_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="outline_phase",
            end_phase="outline_phase",
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=False)

        assert result.success is False
        assert result.final_status == ExecutionStatus.FAILED
        assert "Test error" in result.error


class TestHumanCheckpoints:
    """Test human-in-the-loop checkpoint handling."""

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_checkpoint_approval_stop(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test checkpoint stopping execution when not approved."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=Mock())
        mock_progress_instance.initialize = Mock()
        mock_progress_instance.set_status = Mock()
        mock_progress_instance.update_phase = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_handler_instance = Mock()
        mock_handler_instance.should_pause_at_phase = Mock(return_value=True)
        mock_handler_instance.get_checkpoint_for_phase = Mock(
            return_value=Mock(type="approval", message="Approve?")
        )
        mock_decision = Mock()
        mock_decision.approved = False
        mock_decision.input = None
        mock_decision.modifications = None
        mock_handler_instance.handle_checkpoint = Mock(return_value=mock_decision)
        mock_handler.return_value = mock_handler_instance

        mock_executor_instance = Mock()
        mock_executor_instance.execute_workflow = Mock(return_value={"success": True, "output": {}})
        mock_executor.return_value = mock_executor_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="outline_phase",
            end_phase="outline_phase",
            human_in_loop=True,
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=False)

        assert result.success is False
        assert result.final_status == ExecutionStatus.PAUSED
        assert "Stopped by user" in result.error

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_checkpoint_with_user_input(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test checkpoint with user input."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=Mock())
        mock_progress_instance.initialize = Mock()
        mock_progress_instance.set_status = Mock()
        mock_progress_instance.update_phase = Mock()
        mock_progress_instance.complete_phase = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_handler_instance = Mock()
        mock_handler_instance.should_pause_at_phase = Mock(return_value=True)
        mock_handler_instance.get_checkpoint_for_phase = Mock(
            return_value=Mock(type="input", message="Enter input:")
        )
        mock_decision = Mock()
        mock_decision.approved = True
        mock_decision.input = "User provided input"
        mock_decision.modifications = None
        mock_handler_instance.handle_checkpoint = Mock(return_value=mock_decision)
        mock_handler.return_value = mock_handler_instance

        mock_executor_instance = Mock()
        mock_executor_instance.execute_workflow = Mock(return_value={"success": True, "output": {}})
        mock_executor.return_value = mock_executor_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="character_phase",
            end_phase="character_phase",
            human_in_loop=True,
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=False)

        assert result.success is True

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_checkpoint_with_modifications(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test checkpoint with modifications."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=Mock())
        mock_progress_instance.initialize = Mock()
        mock_progress_instance.set_status = Mock()
        mock_progress_instance.update_phase = Mock()
        mock_progress_instance.complete_phase = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_handler_instance = Mock()
        mock_handler_instance.should_pause_at_phase = Mock(return_value=True)
        mock_handler_instance.get_checkpoint_for_phase = Mock(
            return_value=Mock(type="approval", message="Approve?")
        )
        mock_decision = Mock()
        mock_decision.approved = True
        mock_decision.input = None
        mock_decision.modifications = {"key": "value"}
        mock_handler_instance.handle_checkpoint = Mock(return_value=mock_decision)
        mock_handler.return_value = mock_handler_instance

        mock_executor_instance = Mock()
        mock_executor_instance.execute_workflow = Mock(return_value={"success": True, "output": {}})
        mock_executor.return_value = mock_executor_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="outline_phase",
            end_phase="outline_phase",
            human_in_loop=True,
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=False)

        assert result.success is True


class TestWorkflowExecution:
    """Test workflow execution paths."""

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_workflow_with_warning(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test workflow that completes with warnings."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=Mock())
        mock_progress_instance.initialize = Mock()
        mock_progress_instance.set_status = Mock()
        mock_progress_instance.update_phase = Mock()
        mock_progress_instance.complete_phase = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_executor_instance = Mock()
        mock_executor_instance.execute_workflow = Mock(
            return_value={"success": False, "output": {}}
        )
        mock_executor.return_value = mock_executor_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="outline_phase",
            end_phase="outline_phase",
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=False)

        assert result.success is True

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_workflow_execution_exception(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test workflow execution with exception."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=Mock(completed_phases=[]))
        mock_progress_instance.initialize = Mock()
        mock_progress_instance.set_status = Mock()
        mock_progress_instance.update_phase = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_executor_instance = Mock()
        mock_executor_instance.execute_workflow = Mock(
            side_effect=RuntimeError("Workflow execution failed")
        )
        mock_executor.return_value = mock_executor_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="outline_phase",
            end_phase="outline_phase",
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=False)

        assert result.success is False
        assert result.final_status == ExecutionStatus.FAILED


class TestResumeCheckpoint:
    """Test resume from checkpoint functionality."""

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_resume_no_checkpoint_found(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test resume when no checkpoint found."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=Mock())
        mock_progress_instance.set_status = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_checkpoint_instance = Mock()
        mock_checkpoint_instance.load_checkpoint = Mock(return_value=None)
        mock_checkpoint.return_value = mock_checkpoint_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="outline_phase",
            end_phase="outline_phase",
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=True)

        assert result.success is False
        assert result.error == "No checkpoint found"

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_resume_invalid_checkpoint(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test resume with invalid checkpoint."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=Mock())
        mock_progress_instance.set_status = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_checkpoint_instance = Mock()
        mock_checkpoint_instance.load_checkpoint = Mock(return_value=Mock())
        mock_checkpoint_instance.validate_checkpoint = Mock(return_value=False)
        mock_checkpoint.return_value = mock_checkpoint_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="outline_phase",
            end_phase="outline_phase",
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=True)

        assert result.success is False
        assert result.error == "Invalid checkpoint"


class TestGetWorkflowIndex:
    """Test _get_workflow_index method."""

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_get_workflow_index_valid(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test getting index for valid workflow."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()

        config = AutonomousConfig(project_name="test_project")
        executor = AutonomousExecutor(config, tmp_path)

        index = executor._get_workflow_index("outline_phase")
        assert index == 3

        index = executor._get_workflow_index("new_novel")
        assert index == 0

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_get_workflow_index_invalid(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test getting index for invalid workflow."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()

        config = AutonomousConfig(project_name="test_project")
        executor = AutonomousExecutor(config, tmp_path)

        with pytest.raises(ValueError, match="Unknown workflow"):
            executor._get_workflow_index("invalid_workflow")


class TestEdgeCases:
    """Test edge cases and boundary conditions."""

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_skip_new_novel_when_not_start_phase(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test skipping new_novel workflow when not starting phase."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=Mock())
        mock_progress_instance.initialize = Mock()
        mock_progress_instance.set_status = Mock()
        mock_progress_instance.update_phase = Mock()
        mock_progress_instance.complete_phase = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_executor_instance = Mock()
        mock_executor_instance.execute_workflow = Mock(return_value={"success": True, "output": {}})
        mock_executor.return_value = mock_executor_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="character_phase",
            end_phase="character_phase",
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=False)

        assert result.success is True

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_execute_single_phase(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test executing single phase."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=Mock())
        mock_progress_instance.initialize = Mock()
        mock_progress_instance.set_status = Mock()
        mock_progress_instance.update_phase = Mock()
        mock_progress_instance.complete_phase = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_executor_instance = Mock()
        mock_executor_instance.execute_workflow = Mock(return_value={"success": True, "output": {}})
        mock_executor.return_value = mock_executor_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="outline_phase",
            end_phase="outline_phase",
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=False)

        assert result.success is True
        assert len(result.completed_phases) == 1
