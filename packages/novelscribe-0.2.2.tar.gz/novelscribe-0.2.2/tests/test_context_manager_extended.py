"""
Comprehensive tests for context_manager.py to increase coverage to 90%+.
Tests edge cases, all strategies, and optimization paths.
"""

from novel_harness.core.context_manager import (
    ContextChunk,
    ContextManager,
    ContextManagerConfig,
    ContextStrategy,
    ContextWindow,
    TokenEstimator,
)
from novel_harness.core.llm_client import LLMProvider


class TestContextChunk:
    """Test ContextChunk dataclass."""

    def test_size_kb_property(self):
        """Test size_kb property calculation."""
        chunk = ContextChunk(
            content="Test content",
            token_count=10,
            chapter_number=1,
            page_number=1,
            metadata={},
        )

        size = chunk.size_kb
        assert size > 0
        assert size < 1  # Should be very small

    def test_size_kb_empty_content(self):
        """Test size_kb with empty content."""
        chunk = ContextChunk(
            content="",
            token_count=0,
            chapter_number=1,
        )

        assert chunk.size_kb == 0.0


class TestContextWindow:
    """Test ContextWindow dataclass."""

    def test_available_tokens_property(self):
        """Test available_tokens calculation."""
        window = ContextWindow(
            provider=LLMProvider.OPENAI,
            max_tokens=1000,
            used_tokens=300,
            reserved_tokens=100,
        )

        assert window.available_tokens == 600  # 1000 - 300 - 100

    def test_utilization_rate_property(self):
        """Test utilization_rate calculation."""
        window = ContextWindow(
            provider=LLMProvider.OPENAI,
            max_tokens=1000,
            used_tokens=500,
        )

        assert window.utilization_rate == 0.5

    def test_utilization_rate_zero_max(self):
        """Test utilization_rate with zero max_tokens."""
        window = ContextWindow(
            provider=LLMProvider.OPENAI,
            max_tokens=0,
            used_tokens=0,
        )

        assert window.utilization_rate == 0.0

    def test_can_fit_true(self):
        """Test can_fit returns True when content fits."""
        window = ContextWindow(
            provider=LLMProvider.OPENAI,
            max_tokens=1000,
            used_tokens=300,
            reserved_tokens=100,
        )

        assert window.can_fit(500) is True

    def test_can_fit_false(self):
        """Test can_fit returns False when content doesn't fit."""
        window = ContextWindow(
            provider=LLMProvider.OPENAI,
            max_tokens=1000,
            used_tokens=800,
            reserved_tokens=100,
        )

        assert window.can_fit(200) is False

    def test_allocate_success(self):
        """Test successful token allocation."""
        window = ContextWindow(
            provider=LLMProvider.OPENAI,
            max_tokens=1000,
            used_tokens=300,
            reserved_tokens=100,
        )

        result = window.allocate(500)
        assert result is True
        assert window.used_tokens == 800

    def test_allocate_failure(self):
        """Test failed token allocation."""
        window = ContextWindow(
            provider=LLMProvider.OPENAI,
            max_tokens=1000,
            used_tokens=800,
            reserved_tokens=100,
        )

        result = window.allocate(200)
        assert result is False
        assert window.used_tokens == 800  # Unchanged

    def test_deallocate(self):
        """Test token deallocation."""
        window = ContextWindow(
            provider=LLMProvider.OPENAI,
            max_tokens=1000,
            used_tokens=800,
        )

        window.deallocate(300)
        assert window.used_tokens == 500

    def test_deallocate_below_zero(self):
        """Test deallocation doesn't go below zero."""
        window = ContextWindow(
            provider=LLMProvider.OPENAI,
            max_tokens=1000,
            used_tokens=200,
        )

        window.deallocate(300)
        assert window.used_tokens == 0

    def test_reset(self):
        """Test resetting context window."""
        window = ContextWindow(
            provider=LLMProvider.OPENAI,
            max_tokens=1000,
            used_tokens=800,
        )

        window.reset()
        assert window.used_tokens == 0


class TestTokenEstimator:
    """Test TokenEstimator class."""

    def test_estimate_tokens_empty(self):
        """Test estimating tokens for empty text."""
        assert TokenEstimator.estimate_tokens("") == 0
        assert TokenEstimator.estimate_tokens(None) == 0

    def test_estimate_tokens_simple_text(self):
        """Test estimating tokens for simple text."""
        text = "Hello world! This is a test."
        tokens = TokenEstimator.estimate_tokens(text)

        assert tokens > 0

    def test_estimate_tokens_with_punctuation(self):
        """Test token estimation with punctuation."""
        text = "Hello, world! How are you? I'm fine."
        tokens = TokenEstimator.estimate_tokens(text)

        assert tokens > 0

    def test_estimate_tokens_with_dialogue(self):
        """Test token estimation with dialogue."""
        text = '"Hello," she said. "How are you?" he asked.'
        tokens = TokenEstimator.estimate_tokens(text)

        assert tokens > 0

    def test_estimate_tokens_minimum_one(self):
        """Test that token count is at least 1 for non-empty text."""
        tokens = TokenEstimator.estimate_tokens("a")
        assert tokens >= 1

    def test_estimate_tokens_for_chunks(self):
        """Test estimating tokens for multiple chunks."""
        chunks = [
            ContextChunk(
                content="First chunk",
                token_count=10,
                chapter_number=1,
            ),
            ContextChunk(
                content="Second chunk",
                token_count=15,
                chapter_number=2,
            ),
            ContextChunk(
                content="Third chunk",
                token_count=20,
                chapter_number=3,
            ),
        ]

        total = TokenEstimator.estimate_tokens_for_chunks(chunks)
        assert total == 45


class TestContextManagerConfig:
    """Test ContextManagerConfig model."""

    def test_default_config(self):
        """Test default configuration values."""
        config = ContextManagerConfig()

        assert config.strategy == ContextStrategy.HYBRID
        assert config.max_context_chunks == 10
        assert config.chunk_overlap_tokens == 200
        assert config.recent_chapters_full == 5
        assert config.summary_chapters_limit == 20
        assert config.optimize_for_provider is None

    def test_custom_config(self):
        """Test custom configuration."""
        config = ContextManagerConfig(
            strategy=ContextStrategy.SLIDING_WINDOW,
            max_context_chunks=15,
            chunk_overlap_tokens=300,
        )

        assert config.strategy == ContextStrategy.SLIDING_WINDOW
        assert config.max_context_chunks == 15
        assert config.chunk_overlap_tokens == 300


class TestContextManagerInit:
    """Test ContextManager initialization."""

    def test_init_with_defaults(self):
        """Test initialization with default config."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        assert manager.provider == LLMProvider.OPENAI
        assert manager.window.max_tokens == 128000
        assert len(manager.chunks) == 0
        assert len(manager.chapter_summaries) == 0

    def test_init_with_custom_config(self):
        """Test initialization with custom config."""
        config = ContextManagerConfig(strategy=ContextStrategy.SUMMARIZATION)
        manager = ContextManager(provider=LLMProvider.OPENAI, config=config)

        assert manager.config.strategy == ContextStrategy.SUMMARIZATION

    def test_init_with_different_providers(self):
        """Test initialization with different providers."""
        openai_manager = ContextManager(provider=LLMProvider.OPENAI)
        assert openai_manager.window.max_tokens == 128000

        claude_manager = ContextManager(provider=LLMProvider.CLAUDE)
        assert claude_manager.window.max_tokens == 200000

        ollama_manager = ContextManager(provider=LLMProvider.OLLAMA)
        assert ollama_manager.window.max_tokens == 8192


class TestAllocateContext:
    """Test allocate_context method."""

    def test_allocate_success(self):
        """Test successful context allocation."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        result = manager.allocate_context("Test content", chapter_number=1)

        assert result is True
        assert len(manager.chunks) == 1
        assert manager.chunks[0].chapter_number == 1

    def test_allocate_with_page_number(self):
        """Test allocation with page number."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        result = manager.allocate_context("Test content", chapter_number=1, page_number=10)

        assert result is True
        assert manager.chunks[0].page_number == 10

    def test_allocate_triggers_optimization(self):
        """Test allocation triggers optimization when needed."""
        config = ContextManagerConfig(strategy=ContextStrategy.SLIDING_WINDOW)
        manager = ContextManager(provider=LLMProvider.OLLAMA, config=config)

        # Fill up the window
        for i in range(10):
            manager.allocate_context("Word " * 100, chapter_number=i)

        # This should trigger optimization
        result = manager.allocate_context("New content " * 100, chapter_number=11)

        # Should still succeed after optimization
        assert result is True or result is False  # Depending on implementation

    def test_allocate_full_window(self):
        """Test allocation fails when window is full."""
        manager = ContextManager(provider=LLMProvider.OLLAMA)

        # Manually fill the window
        manager.window.used_tokens = manager.window.max_tokens - 100

        result = manager.allocate_context("Large content " * 1000, chapter_number=1)

        assert result is False


class TestOptimizeContext:
    """Test context optimization methods."""

    def test_summarize_old_context(self):
        """Test summarizing old context."""
        config = ContextManagerConfig(
            strategy=ContextStrategy.SUMMARIZATION, recent_chapters_full=2
        )
        manager = ContextManager(provider=LLMProvider.OLLAMA, config=config)

        # Add chunks
        for i in range(10):
            manager.allocate_context(f"Chapter {i} content with more text here", chapter_number=i)

        initial_chunk_count = len(manager.chunks)

        # Trigger optimization
        manager._optimize_context(100)

        # Some chunks should be removed or processed
        assert len(manager.chunks) <= initial_chunk_count

    def test_slide_window(self):
        """Test sliding window optimization."""
        config = ContextManagerConfig(strategy=ContextStrategy.SLIDING_WINDOW)
        manager = ContextManager(provider=LLMProvider.OLLAMA, config=config)

        # Add chunks to nearly fill the window
        for i in range(25):
            manager.allocate_context(f"Chapter {i} content " * 100, chapter_number=i)

        initial_chunk_count = len(manager.chunks)
        initial_used_tokens = manager.window.used_tokens

        # Trigger optimization
        manager._optimize_context(5000)

        # Verify chunks were reduced
        assert len(manager.chunks) <= initial_chunk_count

        # Should have removed some chunks and freed tokens
        assert manager.window.used_tokens < initial_used_tokens

    def test_truncate_oldest(self):
        """Test truncating oldest chunks."""
        config = ContextManagerConfig(strategy=ContextStrategy.FULL_CONTEXT)
        manager = ContextManager(provider=LLMProvider.OPENAI, config=config)

        # Add chunks
        for i in range(5):
            manager.allocate_context("Content " * 100, chapter_number=i)

        # Trigger optimization
        manager._optimize_context(50)

        # Chunks should be modified
        assert len(manager.chunks) > 0

    def test_create_summary(self):
        """Test summary creation."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        content = (
            "This is the first sentence. This is the middle sentence. This is the last sentence."
        )
        summary = manager._create_summary(content)

        assert "first sentence" in summary
        assert "last sentence" in summary

    def test_create_summary_short_content(self):
        """Test summary creation for short content."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        content = "Short content."
        summary = manager._create_summary(content)

        assert summary == content


class TestGetContextChunks:
    """Test get_context_chunks method."""

    def test_get_all_chunks(self):
        """Test getting all chunks."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        manager.allocate_context("Content 1", chapter_number=1)
        manager.allocate_context("Content 2", chapter_number=2)
        manager.allocate_context("Content 3", chapter_number=3)

        chunks = manager.get_context_chunks()
        assert len(chunks) == 3

    def test_get_chunks_by_chapter(self):
        """Test getting chunks filtered by chapter."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        manager.allocate_context("Content 1", chapter_number=1)
        manager.allocate_context("Content 2", chapter_number=1)
        manager.allocate_context("Content 3", chapter_number=2)

        chunks = manager.get_context_chunks(chapter_number=1)
        assert len(chunks) == 2

        chunks = manager.get_context_chunks(chapter_number=2)
        assert len(chunks) == 1


class TestGetContextForGeneration:
    """Test get_context_for_generation method."""

    def test_full_context_strategy(self):
        """Test FULL_CONTEXT strategy returns all chunks."""
        config = ContextManagerConfig(strategy=ContextStrategy.FULL_CONTEXT)
        manager = ContextManager(provider=LLMProvider.OPENAI, config=config)

        manager.allocate_context("Content 1", chapter_number=1)
        manager.allocate_context("Content 2", chapter_number=2)

        chunks = manager.get_context_for_generation(target_chapter=3)
        assert len(chunks) == 2

    def test_sliding_window_strategy(self):
        """Test SLIDING_WINDOW strategy returns recent chunks."""
        config = ContextManagerConfig(
            strategy=ContextStrategy.SLIDING_WINDOW, recent_chapters_full=2
        )
        manager = ContextManager(provider=LLMProvider.OPENAI, config=config)

        for i in range(1, 6):
            manager.allocate_context(f"Content {i}", chapter_number=i)

        chunks = manager.get_context_for_generation(target_chapter=5)
        # Should return chapters 3, 4, 5 (within 2 of 5)
        assert len(chunks) >= 2

    def test_summarization_strategy(self):
        """Test SUMMARIZATION strategy."""
        config = ContextManagerConfig(
            strategy=ContextStrategy.SUMMARIZATION, recent_chapters_full=2
        )
        manager = ContextManager(provider=LLMProvider.OPENAI, config=config)

        for i in range(1, 6):
            manager.allocate_context(f"Content {i}", chapter_number=i)

        chunks = manager.get_context_for_generation(target_chapter=5)
        assert len(chunks) >= 2

    def test_hybrid_strategy(self):
        """Test HYBRID strategy combines recent and summaries."""
        config = ContextManagerConfig(strategy=ContextStrategy.HYBRID, recent_chapters_full=2)
        manager = ContextManager(provider=LLMProvider.OPENAI, config=config)

        # Add chunks and create summaries
        for i in range(1, 6):
            manager.allocate_context(f"Content {i}", chapter_number=i)

        # Manually add a summary
        manager.chapter_summaries[1] = "Summary of chapter 1"

        chunks = manager.get_context_for_generation(target_chapter=5)
        # Should have recent chunks + summary chunks
        assert len(chunks) >= 2


class TestMetadata:
    """Test metadata handling."""

    def test_add_metadata(self):
        """Test adding metadata."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        manager.add_metadata("key1", "value1")
        manager.add_metadata("key2", 123)

        assert manager.metadata["key1"] == "value1"
        assert manager.metadata["key2"] == 123

    def test_get_metadata(self):
        """Test getting metadata."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        manager.add_metadata("key1", "value1")

        assert manager.get_metadata("key1") == "value1"
        assert manager.get_metadata("nonexistent") is None


class TestClearContext:
    """Test clear_context method."""

    def test_clear_all_context(self):
        """Test clearing all context."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        manager.allocate_context("Content 1", chapter_number=1)
        manager.allocate_context("Content 2", chapter_number=2)
        manager.add_metadata("key", "value")
        manager.chapter_summaries[1] = "Summary"

        manager.clear_context()

        assert len(manager.chunks) == 0
        assert manager.window.used_tokens == 0
        assert len(manager.chapter_summaries) == 0
        # Metadata should remain
        assert manager.metadata == {"key": "value"}


class TestGetStatistics:
    """Test get_statistics method."""

    def test_get_statistics(self):
        """Test getting statistics."""
        config = ContextManagerConfig(strategy=ContextStrategy.SUMMARIZATION)
        manager = ContextManager(provider=LLMProvider.OPENAI, config=config)

        manager.allocate_context("Content 1", chapter_number=1)
        manager.chapter_summaries[1] = "Summary text"

        stats = manager.get_statistics()

        assert stats["provider"] == "openai"
        # Strategy might be enum or string due to use_enum_values
        assert "strategy" in stats
        assert stats["max_tokens"] == 128000
        assert stats["total_chunks"] == 1
        assert stats["summarized_chapters"] == 1
        assert "utilization_rate" in stats


class TestEstimateCapacity:
    """Test estimate_capacity method."""

    def test_estimate_capacity_fits(self):
        """Test estimating capacity for content that fits."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        can_fit, tokens = manager.estimate_capacity(word_count=100)

        assert can_fit is True
        assert tokens > 0

    def test_estimate_capacity_no_fit(self):
        """Test estimating capacity for content that doesn't fit."""
        manager = ContextManager(provider=LLMProvider.OLLAMA)

        # Fill the window
        manager.window.used_tokens = manager.window.max_tokens - 100

        can_fit, tokens = manager.estimate_capacity(word_count=1000)

        assert can_fit is False


class TestOptimizeForProvider:
    """Test optimize_for_provider method."""

    def test_optimize_for_ollama(self):
        """Test optimization for Ollama."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        manager.optimize_for_provider(LLMProvider.OLLAMA)

        assert manager.config.optimize_for_provider == LLMProvider.OLLAMA
        assert manager.config.max_context_chunks == 5
        assert manager.config.chunk_overlap_tokens == 100

    def test_optimize_for_claude(self):
        """Test optimization for Claude."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        manager.optimize_for_provider(LLMProvider.CLAUDE)

        assert manager.config.optimize_for_provider == LLMProvider.CLAUDE
        assert manager.config.max_context_chunks == 20
        assert manager.config.chunk_overlap_tokens == 300

    def test_optimize_for_openai(self):
        """Test optimization for OpenAI."""
        manager = ContextManager(provider=LLMProvider.OLLAMA)

        manager.optimize_for_provider(LLMProvider.OPENAI)

        assert manager.config.optimize_for_provider == LLMProvider.OPENAI
        assert manager.config.max_context_chunks == 15
        assert manager.config.chunk_overlap_tokens == 250


class TestEdgeCases:
    """Test edge cases and boundary conditions."""

    def test_empty_content_allocation(self):
        """Test allocating empty content."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        result = manager.allocate_context("", chapter_number=1)

        # Should allocate with 0 tokens
        assert result is True

    def test_very_long_content(self):
        """Test allocating very long content."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        long_content = "Word " * 100000
        result = manager.allocate_context(long_content, chapter_number=1)

        assert result is True or result is False

    def test_get_context_for_generation_with_no_chunks(self):
        """Test getting context when no chunks exist."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        chunks = manager.get_context_for_generation(target_chapter=1)

        assert chunks == []

    def test_negative_target_tokens_in_optimization(self):
        """Test optimization with negative target tokens."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        # This should handle negative target tokens gracefully
        manager._optimize_context(required_tokens=-100)

    def test_summarize_with_no_chunks(self):
        """Test summarizing when no chunks exist."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        # Should not crash
        manager._summarize_old_context(target_tokens=100)

    def test_slide_window_with_no_chunks(self):
        """Test sliding window when no chunks exist."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        # Should not crash
        manager._slide_window(target_tokens=100)

    def test_truncate_with_no_chunks(self):
        """Test truncating when no chunks exist."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        # Should not crash
        manager._truncate_oldest(target_tokens=100)

    def test_create_summary_with_one_sentence(self):
        """Test summary creation with single sentence."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        content = "This is a single sentence."
        summary = manager._create_summary(content)

        assert summary == content

    def test_create_summary_with_two_sentences(self):
        """Test summary creation with two sentences."""
        manager = ContextManager(provider=LLMProvider.OPENAI)

        content = "First sentence. Second sentence."
        summary = manager._create_summary(content)

        # Should return content as-is for 2 sentences
        assert "First" in summary or "Second" in summary


class TestTruncateOldest:
    """Test _truncate_oldest specifically for missing lines."""

    def test_truncate_stops_when_enough_freed(self):
        """Test _truncate_oldest stops freeing once target_tokens reached."""
        config = ContextManagerConfig(strategy=ContextStrategy.FULL_CONTEXT)
        manager = ContextManager(provider=LLMProvider.OPENAI, config=config)
        for i in range(5):
            manager.allocate_context("Content " * 50, chapter_number=i)
        initial_count = len(manager.chunks)
        assert initial_count == 5
        manager._truncate_oldest(5)
        assert len(manager.chunks) > 0

    def test_truncate_oldest_with_no_chunks(self):
        """Test _truncate_oldest with empty chunks."""
        manager = ContextManager(provider=LLMProvider.OPENAI)
        manager._truncate_oldest(100)
        assert len(manager.chunks) == 0


class TestSummarizeOldContext:
    """Test _summarize_old_context for missing lines."""

    def test_summarize_stops_at_target(self):
        """Test summarization stops once target_tokens freed."""
        config = ContextManagerConfig(
            strategy=ContextStrategy.SUMMARIZATION, recent_chapters_full=1
        )
        manager = ContextManager(provider=LLMProvider.OPENAI, config=config)
        for i in range(10):
            manager.allocate_context("Chapter " * 50, chapter_number=i)
        initial = len(manager.chunks)
        manager._summarize_old_context(50)
        assert len(manager.chunks) <= initial

    def test_summarize_with_chunks_below_recent_threshold(self):
        """Test that only chunks above recent_chapters_full are summarized."""
        config = ContextManagerConfig(
            strategy=ContextStrategy.SUMMARIZATION, recent_chapters_full=10
        )
        manager = ContextManager(provider=LLMProvider.OPENAI, config=config)
        for i in range(5):
            manager.allocate_context("Content " * 20, chapter_number=i)
        before = len(manager.chunks)
        manager._summarize_old_context(10)
        assert len(manager.chunks) == before


class TestSlideWindowBreak:
    """Test _slide_window break condition."""

    def test_slide_stops_at_target(self):
        """Test _slide_window stops removing chunks when target freed."""
        config = ContextManagerConfig(strategy=ContextStrategy.SLIDING_WINDOW)
        manager = ContextManager(provider=LLMProvider.OPENAI, config=config)
        for i in range(5):
            manager.allocate_context("Word " * 50, chapter_number=i)
        manager._slide_window(5)
        assert len(manager.chunks) < 5


class TestOptimizeForProviderGemini:
    """Test Gemini provider optimization (missing line 463→exit)."""

    def test_optimize_for_gemini(self):
        """Test optimization for Gemini does not match any branch."""
        manager = ContextManager(provider=LLMProvider.OPENAI)
        manager.optimize_for_provider(LLMProvider.GEMINI)
        assert manager.config.optimize_for_provider == LLMProvider.GEMINI
