"""
Comprehensive tests for WebSocket and Streaming functionality

Tests cover:
- WebSocket connection management
- Event broadcasting
- SSE streaming
- Real-time updates
"""

from datetime import datetime
from unittest.mock import AsyncMock, MagicMock

import pytest

from api.websocket_manager import (
    EventType,
    RealtimeEvent,
    WebSocketManager,
    WSConnection,
    get_websocket_manager,
)


class TestWebSocketManager:
    """Test suite for WebSocketManager"""

    @pytest.fixture
    def manager(self):
        """Create fresh WebSocketManager instance"""
        return WebSocketManager()

    @pytest.fixture
    def mock_websocket(self):
        """Create mock WebSocket"""
        ws = AsyncMock()
        ws.accept = AsyncMock()
        ws.close = AsyncMock()
        ws.send_json = AsyncMock()
        ws.send_text = AsyncMock()
        return ws

    @pytest.mark.asyncio
    async def test_manager_initialization(self, manager):
        """Test manager initialization"""
        assert len(manager.connections) == 0
        assert len(manager.project_connections) == 0
        assert manager.total_connections == 0
        assert manager.total_disconnections == 0

    @pytest.mark.asyncio
    async def test_connect(self, manager, mock_websocket):
        """Test connecting a client"""
        client_id = await manager.connect(mock_websocket, project_name="test-project")

        assert client_id is not None
        assert client_id in manager.connections
        assert "test-project" in manager.project_connections
        assert mock_websocket.accept.called
        assert mock_websocket.send_json.called

    @pytest.mark.asyncio
    async def test_connect_global(self, manager, mock_websocket):
        """Test connecting without project (global)"""
        client_id = await manager.connect(mock_websocket, project_name=None)

        assert client_id is not None
        assert client_id in manager.global_connections
        assert manager.connections[client_id].project_name is None

    @pytest.mark.asyncio
    async def test_disconnect(self, manager, mock_websocket):
        """Test disconnecting a client"""
        client_id = await manager.connect(mock_websocket, project_name="test-project")
        await manager.disconnect(client_id)

        assert client_id not in manager.connections
        assert client_id not in manager.project_connections.get("test-project", set())
        assert mock_websocket.close.called

    @pytest.mark.asyncio
    async def test_send_to_client(self, manager, mock_websocket):
        """Test sending message to specific client"""
        client_id = await manager.connect(mock_websocket)

        message = {"type": "test", "data": "hello"}
        result = await manager.send_to_client(client_id, message)

        assert result is True
        assert mock_websocket.send_json.called

    @pytest.mark.asyncio
    async def test_send_to_nonexistent_client(self, manager):
        """Test sending to nonexistent client"""
        result = await manager.send_to_client("nonexistent", {"test": "data"})
        assert result is False

    @pytest.mark.asyncio
    async def test_broadcast_to_project(self, manager, mock_websocket):
        """Test broadcasting to project"""
        await manager.connect(mock_websocket, project_name="test-project")

        event = RealtimeEvent(type=EventType.PROGRESS, data={"progress": 50})

        count = await manager.broadcast_to_project("test-project", event)

        assert count == 1
        assert mock_websocket.send_json.called

    @pytest.mark.asyncio
    async def test_broadcast_to_empty_project(self, manager):
        """Test broadcasting to project with no connections"""
        event = RealtimeEvent(type=EventType.PROGRESS, data={"progress": 50})

        count = await manager.broadcast_to_project("nonexistent", event)

        assert count == 0

    @pytest.mark.asyncio
    async def test_broadcast_global(self, manager, mock_websocket):
        """Test broadcasting to global connections"""
        await manager.connect(mock_websocket, project_name=None)

        event = RealtimeEvent(
            type=EventType.HEARTBEAT, data={"timestamp": datetime.now().isoformat()}
        )

        count = await manager.broadcast_global(event)

        assert count >= 0

    @pytest.mark.asyncio
    async def test_subscribe(self, manager, mock_websocket):
        """Test subscribing to event types"""
        client_id = await manager.connect(mock_websocket)

        success = manager.subscribe(client_id, [EventType.LOG, EventType.PROGRESS])

        assert success is True
        connection = manager.connections[client_id]
        assert EventType.LOG in connection.subscribed_events
        assert EventType.PROGRESS in connection.subscribed_events

    @pytest.mark.asyncio
    async def test_unsubscribe(self, manager, mock_websocket):
        """Test unsubscribing from event types"""
        client_id = await manager.connect(mock_websocket)

        # First subscribe
        manager.subscribe(client_id, [EventType.LOG, EventType.PROGRESS])

        # Then unsubscribe
        success = manager.unsubscribe(client_id, [EventType.LOG])

        assert success is True
        connection = manager.connections[client_id]
        assert EventType.LOG not in connection.subscribed_events
        assert EventType.PROGRESS in connection.subscribed_events

    @pytest.mark.asyncio
    async def test_handle_ping_message(self, manager, mock_websocket):
        """Test handling ping message"""
        client_id = await manager.connect(mock_websocket)

        message = {"type": "ping"}
        await manager.handle_client_message(client_id, message)

        # Should have received pong
        assert mock_websocket.send_json.called

    @pytest.mark.asyncio
    async def test_handle_subscribe_message(self, manager, mock_websocket):
        """Test handling subscribe message"""
        client_id = await manager.connect(mock_websocket)

        message = {"type": "subscribe", "event_types": ["log", "progress"]}
        await manager.handle_client_message(client_id, message)

        connection = manager.connections[client_id]
        assert EventType.LOG in connection.subscribed_events
        assert EventType.PROGRESS in connection.subscribed_events

    @pytest.mark.asyncio
    async def test_emit_event_to_project(self, manager, mock_websocket):
        """Test emitting event to project"""
        await manager.connect(mock_websocket, project_name="test-project")

        event = RealtimeEvent(type=EventType.LOG, data={"message": "test"}, source="test-project")

        count = await manager.emit_event(event)

        assert count == 1

    @pytest.mark.asyncio
    async def test_get_stats(self, manager, mock_websocket):
        """Test getting statistics"""
        await manager.connect(mock_websocket, project_name="project1")

        stats = manager.get_stats()

        assert "total_connections" in stats
        assert "active_connections" in stats
        assert "total_messages_sent" in stats
        assert stats["total_connections"] == 1

    @pytest.mark.asyncio
    async def test_get_connected_clients(self, manager, mock_websocket):
        """Test getting connected clients count"""
        assert manager.get_connected_clients() == 0

        await manager.connect(mock_websocket)
        assert manager.get_connected_clients() == 1

        await manager.connect(mock_websocket)
        assert manager.get_connected_clients() == 2

    @pytest.mark.asyncio
    async def test_get_clients_for_project(self, manager, mock_websocket):
        """Test getting clients for specific project"""
        await manager.connect(mock_websocket, project_name="project1")
        await manager.connect(mock_websocket, project_name="project1")
        await manager.connect(mock_websocket, project_name="project2")

        clients = manager.get_clients_for_project("project1")

        assert len(clients) == 2


class TestRealtimeEvent:
    """Test suite for RealtimeEvent"""

    def test_event_creation(self):
        """Test creating an event"""
        event = RealtimeEvent(type=EventType.PROGRESS, data={"progress": 50})

        assert event.type == EventType.PROGRESS
        assert event.data["progress"] == 50
        assert event.priority == "normal"

    def test_to_dict(self):
        """Test converting event to dictionary"""
        event = RealtimeEvent(type=EventType.LOG, data={"message": "test"})

        data = event.to_dict()

        assert data["type"] == "log"
        assert data["data"]["message"] == "test"
        assert "timestamp" in data

    def test_to_websocket_message(self):
        """Test converting event to WebSocket message"""
        event = RealtimeEvent(type=EventType.PROGRESS, data={"progress": 75})

        message = event.to_websocket_message()

        assert message["type"] == "progress"
        assert message["data"]["progress"] == 75
        assert "timestamp" in message

    def test_event_types(self):
        """Test all event types"""
        assert EventType.LOG.value == "log"
        assert EventType.PROGRESS.value == "progress"
        assert EventType.STATUS_CHANGE.value == "status_change"
        assert EventType.EXECUTION_START.value == "execution_start"
        assert EventType.EXECUTION_COMPLETE.value == "execution_complete"
        assert EventType.EXECUTION_ERROR.value == "execution_error"
        assert EventType.CHAPTER_COMPLETE.value == "chapter_complete"
        assert EventType.HEARTBEAT.value == "heartbeat"
        assert EventType.SYSTEM_STATUS.value == "system_status"


class TestWSConnection:
    """Test suite for WSConnection"""

    @pytest.fixture
    def mock_websocket(self):
        """Create mock WebSocket"""
        ws = AsyncMock()
        ws.send_json = AsyncMock()
        ws.send_text = AsyncMock()
        return ws

    @pytest.mark.asyncio
    async def test_send_json(self, mock_websocket):
        """Test sending JSON"""
        connection = WSConnection(client_id="test", websocket=mock_websocket)

        await connection.send_json({"test": "data"})

        assert mock_websocket.send_json.called

    @pytest.mark.asyncio
    async def test_send_text(self, mock_websocket):
        """Test sending text"""
        connection = WSConnection(client_id="test", websocket=mock_websocket)

        await connection.send_text("hello")

        assert mock_websocket.send_text.called

    def test_update_ping(self):
        """Test updating ping time"""
        connection = WSConnection(client_id="test", websocket=MagicMock())

        original_ping = connection.last_ping
        connection.update_ping()

        assert connection.last_ping >= original_ping


class TestGlobalInstance:
    """Test global instance management"""

    def test_get_websocket_manager(self):
        """Test getting global manager"""
        # Reset global instance
        import api.websocket_manager as ws_module

        ws_module._ws_manager = None

        manager1 = get_websocket_manager()
        manager2 = get_websocket_manager()

        assert manager1 is manager2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
