"""
Comprehensive tests for missing coverage in logs, streaming, and suggestions routers.
Tests previously uncovered error paths, SSE streaming, and edge cases.
"""

from unittest.mock import MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from api.app import app


class TestLogsRouterMissingCoverage:
    """Tests for uncovered lines in logs router."""

    @pytest.fixture
    def client(self):
        return TestClient(app)

    @pytest.fixture
    def storage_mock(self):
        with patch("api.routers.logs.Storage") as mock:
            yield mock

    def test_get_project_logs_parse_invalid_json(self, client, tmp_path, storage_mock):
        """Test handling of invalid JSON in log file (line 92-94)."""
        log_dir = tmp_path / "test_project" / "logs"
        log_dir.mkdir(parents=True)
        log_file = log_dir / "execution.log"

        with open(log_file, "w") as f:
            f.write(
                '{"timestamp": "2024-01-01T10:00:00", "level": "INFO", "message": "Valid log"}\n'
            )
            f.write("this is not json\n")
            f.write(
                '{"timestamp": "2024-01-01T10:01:00", "level": "ERROR", '
                '"message": "Another valid log"}\n'
            )

        storage_mock.return_value.list_projects.return_value = ["test_project"]
        storage_mock.return_value.project_dir = tmp_path

        response = client.get("/api/v1/logs/test_project")
        assert response.status_code == 200
        data = response.json()
        assert len(data["logs"]) == 2
        assert data["total"] == 2

    def test_get_project_logs_pagination_has_more(self, client, tmp_path, storage_mock):
        """Test pagination has_more calculation (line 99)."""
        log_dir = tmp_path / "test_project" / "logs"
        log_dir.mkdir(parents=True)
        log_file = log_dir / "execution.log"

        with open(log_file, "w") as f:
            for i in range(10):
                f.write(
                    f'{{"timestamp": "2024-01-01T10:0{i}:00", "level": "INFO", '
                    f'"message": "Log {i}"}}\n'
                )

        storage_mock.return_value.list_projects.return_value = ["test_project"]
        storage_mock.return_value.project_dir = tmp_path

        response = client.get("/api/v1/logs/test_project?limit=5&offset=0")
        assert response.status_code == 200
        data = response.json()
        assert len(data["logs"]) == 5
        assert data["has_more"] is True
        assert data["total"] == 10

    def test_get_all_executions_general_exception(self, client, storage_mock):
        """Test general exception handling (line 169-173)."""
        storage_mock.return_value.list_projects.return_value = ["test_project"]

        response = client.get("/api/v1/logs/nonexistent_project")
        assert response.status_code in [404, 500]


class TestStreamingRouterMissingCoverage:
    """Tests for uncovered lines in streaming router."""

    @pytest.fixture
    def client(self):
        return TestClient(app)

    def test_stream_logs_valid_project(self, client):
        """Test stream_logs with valid project name."""
        response = client.get("/api/v1/sse/logs/test_project")
        assert response.status_code in [200, 404]

    def test_stream_status_valid_project(self, client):
        """Test stream_status with valid project name."""
        response = client.get("/api/v1/sse/status/test_project")
        assert response.status_code in [200, 404]

    def test_stream_all_events_valid_project(self, client):
        """Test stream_all_events with valid project name."""
        response = client.get("/api/v1/sse/events/test_project")
        assert response.status_code in [200, 404]


class TestSuggestionsRouterMissingCoverage:
    """Tests for uncovered lines in suggestions router."""

    @pytest.fixture
    def client(self):
        return TestClient(app)

    def test_record_suggestion_invalid_trigger_type(self, client):
        """Test record_suggestion_choice with invalid trigger_type (line 217-223)."""
        response = client.post(
            "/api/v1/suggestions/record",
            json={
                "suggestion_id": "sug_001",
                "project_name": "test_project",
                "accepted": True,
                "user_choice": "accepted",
                "trigger_type": "invalid_trigger",
                "category": "genre",
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is False
        assert "Invalid trigger_type" in data["message"]

    def test_record_suggestion_invalid_category(self, client):
        """Test record_suggestion_choice with invalid category (line 226-232)."""
        response = client.post(
            "/api/v1/suggestions/record",
            json={
                "suggestion_id": "sug_001",
                "project_name": "test_project",
                "accepted": True,
                "user_choice": "accepted",
                "trigger_type": "decision_point",
                "category": "invalid_category",
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is False
        assert "Invalid category" in data["message"]

    def test_record_suggestion_success(self, client):
        """Test successful suggestion recording (line 246-250)."""
        with patch("api.routers.suggestions._get_orchestrator") as mock_orch:
            mock_orchestrator = MagicMock()
            mock_orch.return_value = mock_orchestrator

            response = client.post(
                "/api/v1/suggestions/record",
                json={
                    "suggestion_id": "sug_001",
                    "project_name": "test_project",
                    "accepted": True,
                    "user_choice": "accepted",
                    "trigger_type": "decision_point",
                    "category": "genre",
                },
            )
            assert response.status_code == 200
            data = response.json()
            assert data["success"] is True
            mock_orchestrator.record_suggestion_outcome.assert_called_once()

    def test_record_suggestion_orchestrator_error(self, client):
        """Test handling of orchestrator exception (line 252-257)."""
        with patch("api.routers.suggestions._get_orchestrator") as mock_orch:
            mock_orch.side_effect = Exception("Orchestrator error")

            response = client.post(
                "/api/v1/suggestions/record",
                json={
                    "suggestion_id": "sug_001",
                    "project_name": "test_project",
                    "accepted": True,
                    "user_choice": "accepted",
                    "trigger_type": "decision_point",
                    "category": "genre",
                },
            )
            assert response.status_code == 200
            data = response.json()
            assert data["success"] is False
            assert "Error recording choice" in data["message"]

    def test_get_suggestions_analytics_success(self, client):
        """Test successful analytics retrieval (line 381-388)."""
        with patch("api.routers.suggestions._get_orchestrator") as mock_orch:
            mock_orchestrator = MagicMock()
            mock_orchestrator.get_usage_analytics.return_value = {
                "total_events": 100,
                "acceptance_rate": 0.75,
            }
            mock_orch.return_value = mock_orchestrator

            response = client.get("/api/v1/suggestions/analytics?days=7")
            assert response.status_code == 200
            data = response.json()
            assert data["success"] is True
            assert "analytics" in data

    def test_get_suggestions_analytics_error(self, client):
        """Test analytics error handling (line 387-388)."""
        with patch("api.routers.suggestions._get_orchestrator") as mock_orch:
            mock_orch.side_effect = Exception("Analytics error")

            response = client.get("/api/v1/suggestions/analytics?days=7")
            assert response.status_code == 200
            data = response.json()
            assert data["success"] is False
            assert "error" in data

    def test_get_learning_insights_success(self, client):
        """Test successful insights retrieval (line 404-416)."""
        with (
            patch("api.routers.suggestions._get_kb") as mock_kb,
            patch("api.routers.suggestions.LearningTracker") as mock_tracker,
        ):
            mock_tracker_inst = MagicMock()
            mock_tracker_inst.get_learning_insights.return_value = {
                "period_days": 30,
                "total_events": 50,
                "recommendations": ["improve genre coverage"],
            }
            mock_tracker.return_value = mock_tracker_inst
            mock_kb.return_value = MagicMock()

            response = client.get("/api/v1/suggestions/insights?days=30")
            assert response.status_code == 200
            data = response.json()
            assert data["success"] is True
            assert "insights" in data

    def test_get_learning_insights_error(self, client):
        """Test insights error handling (line 415-416)."""
        with (
            patch("api.routers.suggestions._get_kb") as mock_kb,
            patch("api.routers.suggestions.LearningTracker") as mock_tracker,
        ):
            mock_tracker.side_effect = Exception("Insights error")
            mock_kb.return_value = MagicMock()

            response = client.get("/api/v1/suggestions/insights?days=30")
            assert response.status_code == 200
            data = response.json()
            assert data["success"] is False
            assert "error" in data

    def test_get_promotion_report_success(self, client):
        """Test successful promotion report (line 432-444)."""
        with (
            patch("api.routers.suggestions._get_kb") as mock_kb,
            patch("api.routers.suggestions.LearningTracker") as mock_tracker,
        ):
            mock_tracker_inst = MagicMock()
            mock_tracker_inst.generate_promotion_report.return_value = {
                "period_days": 7,
                "ready_for_promotion": ["sug_001"],
                "near_threshold": ["sug_002"],
            }
            mock_tracker.return_value = mock_tracker_inst
            mock_kb.return_value = MagicMock()

            response = client.get("/api/v1/suggestions/promotion-report?days=7")
            assert response.status_code == 200
            data = response.json()
            assert data["success"] is True
            assert "report" in data

    def test_get_promotion_report_error(self, client):
        """Test promotion report error handling (line 443-444)."""
        with (
            patch("api.routers.suggestions._get_kb") as mock_kb,
            patch("api.routers.suggestions.LearningTracker") as mock_tracker,
        ):
            mock_tracker.side_effect = Exception("Report error")
            mock_kb.return_value = MagicMock()

            response = client.get("/api/v1/suggestions/promotion-report?days=7")
            assert response.status_code == 200
            data = response.json()
            assert data["success"] is False
            assert "error" in data

    def test_get_acceptance_history_with_project_filter(self, client):
        """Test acceptance history with project_id filter (line 359-367)."""
        with (
            patch("api.routers.suggestions._get_kb") as mock_kb,
            patch("api.routers.suggestions.LearningTracker") as mock_tracker,
        ):
            mock_tracker_inst = MagicMock()
            mock_tracker_inst.get_usage_analytics.return_value = {
                "total_events": 25,
                "acceptance_rate": 0.8,
            }
            mock_tracker.return_value = mock_tracker_inst
            mock_kb.return_value = MagicMock()

            response = client.get("/api/v1/suggestions/history?project_id=test_project&days=7")
            assert response.status_code == 200
            data = response.json()
            assert "analytics" in data
            assert data["project_filter"] == "test_project"
            assert data["period_days"] == 7

    def test_promote_suggestion_confirm_false(self, client):
        """Test promote_suggestion without confirmation (line 316-320)."""
        with patch("api.routers.suggestions._get_kb") as mock_kb:
            mock_kb.return_value = MagicMock()

            response = client.post("/api/v1/suggestions/sug_001/promote?confirm=false")
            assert response.status_code == 400
            assert "Confirmation required" in response.text

    def test_promote_suggestion_success(self, client):
        """Test successful suggestion promotion (line 330-334)."""
        with (
            patch("api.routers.suggestions._get_kb") as mock_kb,
            patch("api.routers.suggestions.LearningTracker") as mock_tracker,
        ):
            mock_tracker_inst = MagicMock()
            mock_tracker_inst.promote_to_learned.return_value = True
            mock_tracker.return_value = mock_tracker_inst
            mock_kb.return_value = MagicMock()

            response = client.post("/api/v1/suggestions/sug_001/promote?confirm=true")
            assert response.status_code == 200
            data = response.json()
            assert data["status"] == "success"

    def test_promote_suggestion_not_found(self, client):
        """Test promote_suggestion when suggestion doesn't meet threshold (line 336-341)."""
        with (
            patch("api.routers.suggestions._get_kb") as mock_kb,
            patch("api.routers.suggestions.LearningTracker") as mock_tracker,
        ):
            mock_tracker_inst = MagicMock()
            mock_tracker_inst.promote_to_learned.return_value = False
            mock_tracker.return_value = mock_tracker_inst
            mock_kb.return_value = MagicMock()

            response = client.post("/api/v1/suggestions/sug_001/promote?confirm=true")
            assert response.status_code == 404
            assert "Could not promote suggestion" in response.text
