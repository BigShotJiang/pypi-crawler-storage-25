from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import MagicMock, patch

from core.summary_manager import SummaryManager, SummaryManagerConfig
from core.summary_store import ChapterSummary, GlobalSummary


def _chapter_summary(chapter_number: int, summary: str = "s") -> ChapterSummary:
    return ChapterSummary(
        chapter_number=chapter_number,
        summary=summary,
        key_events=[],
        characters={},
        locations={},
        plot_advancement="",
        next_chapter_setup="",
        created_at=datetime.now(timezone.utc),
        word_count=100,
    )


def test_generate_chapter_summary_saves_and_updates():
    with patch("core.summary_manager.SummaryStore"), patch("core.summary_manager.LLMClient"):
        llm_client = MagicMock()
        llm_client.generate.return_value = MagicMock(content="summary: Hello")
        manager = SummaryManager(Path("/tmp/project"), llm_client)
        with (
            patch.object(manager.store, "save_chapter_summary") as save_chapter,
            patch.object(manager, "_check_and_create_group_summary") as auto_group,
            patch.object(manager, "_update_global_summary_if_needed") as auto_global,
        ):
            result = manager.generate_chapter_summary(1, "content")
            assert result.chapter_number == 1
            save_chapter.assert_called_once()
            auto_group.assert_called_once_with(1)
            auto_global.assert_called_once_with([1])


def test_generate_group_summary_happy_path():
    with patch("core.summary_manager.SummaryStore"), patch("core.summary_manager.LLMClient"):
        llm_client = MagicMock()
        llm_client.generate.return_value = MagicMock(content="group summary")
        manager = SummaryManager(Path("/tmp/project"), llm_client)
        with (
            patch.object(
                manager.store,
                "load_chapter_summary",
                side_effect=[_chapter_summary(1), _chapter_summary(2)],
            ),
            patch.object(manager.store, "save_group_summary") as save_group,
        ):
            result = manager.generate_group_summary(1, 2)
            assert result.start_chapter == 1
            assert result.end_chapter == 2
            save_group.assert_called_once()


def test_generate_group_summary_no_summaries_raises():
    with patch("core.summary_manager.SummaryStore"), patch("core.summary_manager.LLMClient"):
        manager = SummaryManager(Path("/tmp/project"), MagicMock())
        with patch.object(manager.store, "load_chapter_summary", return_value=None):
            raised = False
            try:
                manager.generate_group_summary(1, 2)
            except ValueError:
                raised = True
            assert raised is True


def test_update_global_summary_with_existing_global():
    with patch("core.summary_manager.SummaryStore"), patch("core.summary_manager.LLMClient"):
        llm_client = MagicMock()
        llm_client.generate.return_value = MagicMock(content="new global")
        manager = SummaryManager(Path("/tmp/project"), llm_client)
        existing = GlobalSummary(
            project_name="project",
            summary="old",
            main_plot_arc="arc",
            character_arcs={},
            world_development="",
            themes=[],
            last_updated=datetime.now(timezone.utc),
            total_chapters_covered=5,
            total_word_count=500,
        )
        with (
            patch.object(manager.store, "load_global_summary", return_value=existing),
            patch.object(manager.store, "load_chapter_summary", return_value=_chapter_summary(6)),
            patch.object(manager.store, "save_global_summary") as save_global,
        ):
            result = manager.update_global_summary([6])
            assert result.total_chapters_covered == 6
            assert result.total_word_count == 600
            save_global.assert_called_once()


def test_get_context_for_chapter_uses_global_and_previous():
    with patch("core.summary_manager.SummaryStore"), patch("core.summary_manager.LLMClient"):
        manager = SummaryManager(Path("/tmp/project"), MagicMock())
        global_summary = GlobalSummary(
            project_name="project",
            summary="global",
            main_plot_arc="arc",
            character_arcs={},
            world_development="",
            themes=[],
            last_updated=datetime.now(timezone.utc),
            total_chapters_covered=3,
            total_word_count=300,
        )
        with (
            patch.object(manager, "get_global_summary", return_value=global_summary),
            patch.object(
                manager,
                "get_chapter_summary",
                side_effect=[_chapter_summary(1, "c1"), _chapter_summary(2, "c2")],
            ),
        ):
            context = manager.get_context_for_chapter(3, context_length=2)
            assert "Overall Story Context" in context
            assert "Chapter 1" in context or "Chapter 2" in context


def test_batch_generate_summaries_skip_existing():
    with patch("core.summary_manager.SummaryStore"), patch("core.summary_manager.LLMClient"):
        llm_client = MagicMock()
        llm_client.generate.return_value = MagicMock(content="summary: test")
        manager = SummaryManager(Path("/tmp/project"), llm_client)
        with (
            patch.object(
                manager.store,
                "load_chapter_summary",
                side_effect=[_chapter_summary(1), None, _chapter_summary(2)],
            ),
            patch.object(
                manager, "generate_chapter_summary", return_value=_chapter_summary(2, "new")
            ) as gen,
        ):
            res = manager.batch_generate_summaries({1: "a", 2: "b"}, skip_existing=True)
            assert len(res) == 1
            gen.assert_called_once()


def test_list_missing_summaries_and_stats_proxy():
    with patch("core.summary_manager.SummaryStore"), patch("core.summary_manager.LLMClient"):
        manager = SummaryManager(Path("/tmp/project"), MagicMock())
        with (
            patch.object(manager.store, "list_chapter_summaries", return_value=[1, 3]),
            patch.object(manager.store, "get_summary_statistics", return_value={"ok": True}),
        ):
            missing = manager.list_missing_summaries(4)
            assert missing == [2, 4]
            assert manager.get_summary_statistics() == {"ok": True}


def test_parse_summary_response_yaml_and_fallback():
    with patch("core.summary_manager.SummaryStore"), patch("core.summary_manager.LLMClient"):
        manager = SummaryManager(Path("/tmp/project"), MagicMock())
        parsed = manager._parse_summary_response(
            "summary: S\nkey_events: [A]\ncharacters: {John: hero}"
        )
        assert parsed["summary"] == "S"
        parsed2 = manager._parse_summary_response("not: [valid")
        assert parsed2["summary"] == "not: [valid"


def test_config_flags_disable_auto_updates():
    with patch("core.summary_manager.SummaryStore"), patch("core.summary_manager.LLMClient"):
        cfg = SummaryManagerConfig(enable_auto_grouping=False, enable_auto_global_update=False)
        llm_client = MagicMock()
        llm_client.generate.return_value = MagicMock(content="summary: Hello")
        manager = SummaryManager(Path("/tmp/project"), llm_client, cfg)
        with (
            patch.object(manager, "_check_and_create_group_summary") as auto_group,
            patch.object(manager, "_update_global_summary_if_needed") as auto_global,
        ):
            manager.generate_chapter_summary(1, "content")
            auto_group.assert_not_called()
            auto_global.assert_not_called()


def test_check_and_create_group_summary_when_boundary_and_missing():
    with patch("core.summary_manager.SummaryStore"), patch("core.summary_manager.LLMClient"):
        manager = SummaryManager(Path("/tmp/project"), MagicMock())
        manager.config.chapter_group_size = 5
        with (
            patch.object(manager.store, "load_group_summary", return_value=None),
            patch.object(manager, "generate_group_summary") as gen_group,
        ):
            manager._check_and_create_group_summary(5)
            gen_group.assert_called_once_with(1, 5)


def test_check_and_create_group_summary_ignores_generation_error():
    with patch("core.summary_manager.SummaryStore"), patch("core.summary_manager.LLMClient"):
        manager = SummaryManager(Path("/tmp/project"), MagicMock())
        manager.config.chapter_group_size = 2
        with (
            patch.object(manager.store, "load_group_summary", return_value=None),
            patch.object(manager, "generate_group_summary", side_effect=RuntimeError("x")),
        ):
            manager._check_and_create_group_summary(2)


def test_update_global_summary_if_needed_swallow_errors():
    with patch("core.summary_manager.SummaryStore"), patch("core.summary_manager.LLMClient"):
        manager = SummaryManager(Path("/tmp/project"), MagicMock())
        with patch.object(manager, "update_global_summary", side_effect=RuntimeError("x")):
            manager._update_global_summary_if_needed([1, 2])


def test_update_global_summary_without_valid_chapters_raises():
    with patch("core.summary_manager.SummaryStore"), patch("core.summary_manager.LLMClient"):
        manager = SummaryManager(Path("/tmp/project"), MagicMock())
        with (
            patch.object(manager.store, "load_global_summary", return_value=None),
            patch.object(manager.store, "load_chapter_summary", return_value=None),
        ):
            raised = False
            try:
                manager.update_global_summary([10])
            except ValueError:
                raised = True
            assert raised is True


def test_get_context_for_chapter_without_any_summaries_returns_empty():
    with patch("core.summary_manager.SummaryStore"), patch("core.summary_manager.LLMClient"):
        manager = SummaryManager(Path("/tmp/project"), MagicMock())
        with (
            patch.object(manager, "get_global_summary", return_value=None),
            patch.object(manager, "get_chapter_summary", return_value=None),
        ):
            ctx = manager.get_context_for_chapter(5)
            assert ctx == ""


def test_batch_generate_summaries_skip_existing_false_generates_all():
    with patch("core.summary_manager.SummaryStore"), patch("core.summary_manager.LLMClient"):
        manager = SummaryManager(Path("/tmp/project"), MagicMock())
        with patch.object(
            manager, "generate_chapter_summary", return_value=_chapter_summary(1)
        ) as gen:
            res = manager.batch_generate_summaries({2: "b", 1: "a"}, skip_existing=False)
            assert len(res) == 2
            assert gen.call_count == 2


def test_batch_generate_summaries_handles_generation_exception():
    with patch("core.summary_manager.SummaryStore"), patch("core.summary_manager.LLMClient"):
        manager = SummaryManager(Path("/tmp/project"), MagicMock())
        with patch.object(
            manager,
            "generate_chapter_summary",
            side_effect=[_chapter_summary(1), RuntimeError("x")],
        ):
            res = manager.batch_generate_summaries({1: "a", 2: "b"}, skip_existing=False)
            assert len(res) == 1
