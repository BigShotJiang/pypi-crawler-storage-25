"""
Additional tests for autonomous_executor.py to increase coverage to 90%+.
Tests edge cases, error handling, and resume functionality.
"""

from unittest.mock import Mock, patch

from novel_harness.core.autonomous_executor import (
    AutonomousConfig,
    AutonomousExecutor,
)


class TestWorkflowPhaseExecution:
    """Test workflow phase execution."""

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_workflow_complete_phase_success(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test workflow execution completes phase successfully."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()

        mock_state = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=mock_state)
        mock_progress_instance.initialize = Mock()
        mock_progress_instance.set_status = Mock()
        mock_progress_instance.update_phase = Mock()
        mock_progress_instance.complete_phase = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_checkpoint_instance = Mock()
        mock_checkpoint_instance.create_checkpoint = Mock()
        mock_checkpoint.return_value = mock_checkpoint_instance

        mock_executor_instance = Mock()
        mock_executor_instance.execute_workflow = Mock(return_value={"success": True, "output": {}})
        mock_executor.return_value = mock_executor_instance

        mock_git_instance = Mock()
        mock_git_instance.auto_commit_step = Mock()
        mock_git_manager.return_value = mock_git_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="outline_phase",
            end_phase="outline_phase",
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=False)

        assert result.success is True
        mock_progress_instance.complete_phase.assert_called()

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_workflow_with_warnings(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test workflow execution with warnings."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()

        mock_state = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=mock_state)
        mock_progress_instance.initialize = Mock()
        mock_progress_instance.set_status = Mock()
        mock_progress_instance.update_phase = Mock()
        mock_progress_instance.complete_phase = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_checkpoint_instance = Mock()
        mock_checkpoint_instance.create_checkpoint = Mock()
        mock_checkpoint.return_value = mock_checkpoint_instance

        mock_executor_instance = Mock()
        mock_executor_instance.execute_workflow = Mock(
            return_value={"success": False, "output": {}}  # Warning
        )
        mock_executor.return_value = mock_executor_instance

        mock_git_instance = Mock()
        mock_git_instance.auto_commit_step = Mock()
        mock_git_manager.return_value = mock_git_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="outline_phase",
            end_phase="outline_phase",
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=False)

        assert result.success is True  # Still succeeds despite warnings


class TestResumeExecution:
    """Test resume from checkpoint functionality."""

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_resume_completes_successfully(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test resume completes successfully."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()

        mock_state = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=mock_state)
        mock_progress_instance.set_status = Mock()
        mock_progress_instance.update_phase = Mock()
        mock_progress_instance.complete_phase = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_checkpoint_instance = Mock()
        mock_checkpoint_instance.load_checkpoint = Mock(
            return_value=Mock(
                completed_workflows=["outline_phase"],
                execution_context={},
                progress_state=mock_state,
            )
        )
        mock_checkpoint_instance.validate_checkpoint = Mock(return_value=True)
        mock_checkpoint_instance.create_checkpoint = Mock()
        mock_checkpoint.return_value = mock_checkpoint_instance

        mock_executor_instance = Mock()
        mock_executor_instance.execute_workflow = Mock(return_value={"success": True, "output": {}})
        mock_executor.return_value = mock_executor_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="character_phase",
            end_phase="character_phase",
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=True)

        assert result.success is True

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_resume_with_warnings(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test resume with workflow warnings."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()

        mock_state = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=mock_state)
        mock_progress_instance.set_status = Mock()
        mock_progress_instance.update_phase = Mock()
        mock_progress_instance.complete_phase = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_checkpoint_instance = Mock()
        mock_checkpoint_instance.load_checkpoint = Mock(
            return_value=Mock(
                completed_workflows=["outline_phase"],
                execution_context={},
                progress_state=mock_state,
            )
        )
        mock_checkpoint_instance.validate_checkpoint = Mock(return_value=True)
        mock_checkpoint_instance.create_checkpoint = Mock()
        mock_checkpoint.return_value = mock_checkpoint_instance

        mock_executor_instance = Mock()
        mock_executor_instance.execute_workflow = Mock(
            return_value={"success": False, "output": {}}  # Warning
        )
        mock_executor.return_value = mock_executor_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="character_phase",
            end_phase="character_phase",
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=True)

        assert result.success is True


class TestSkipNewNovelPhase:
    """Test skipping new_novel phase."""

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_skip_new_novel_when_not_start_phase(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test that new_novel is skipped when not the starting phase."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()

        mock_state = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=mock_state)
        mock_progress_instance.initialize = Mock()
        mock_progress_instance.set_status = Mock()
        mock_progress_instance.update_phase = Mock()
        mock_progress_instance.complete_phase = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_checkpoint_instance = Mock()
        mock_checkpoint_instance.create_checkpoint = Mock()
        mock_checkpoint.return_value = mock_checkpoint_instance

        mock_executor_instance = Mock()
        mock_executor_instance.execute_workflow = Mock(return_value={"success": True, "output": {}})
        mock_executor.return_value = mock_executor_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="outline_phase",
            end_phase="outline_phase",
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=False)

        assert result.success is True


class TestCheckpointOperations:
    """Test checkpoint creation during execution."""

    @patch("novel_harness.core.autonomous_executor.StorageFactory")
    @patch("novel_harness.core.autonomous_executor.OpenAIClient")
    @patch("novel_harness.core.autonomous_executor.AgentSystemIntegration")
    @patch("novel_harness.core.autonomous_executor.WorkflowExecutor")
    @patch("novel_harness.core.autonomous_executor.ProgressTracker")
    @patch("novel_harness.core.autonomous_executor.CheckpointManager")
    @patch("novel_harness.core.autonomous_executor.HumanCheckpointHandler")
    @patch("novel_harness.core.autonomous_executor.create_git_manager")
    def test_checkpoint_created_after_phase(
        self,
        mock_git_manager,
        mock_handler,
        mock_checkpoint,
        mock_progress,
        mock_executor,
        mock_agent_integration,
        mock_llm_client,
        mock_storage,
        tmp_path,
    ):
        """Test that checkpoint is created after each phase."""
        mock_storage.create = Mock(return_value=Mock())
        mock_git_manager.return_value = Mock()

        mock_state = Mock()
        mock_progress_instance = Mock()
        mock_progress_instance.get_state = Mock(return_value=mock_state)
        mock_progress_instance.initialize = Mock()
        mock_progress_instance.set_status = Mock()
        mock_progress_instance.update_phase = Mock()
        mock_progress_instance.complete_phase = Mock()
        mock_progress.return_value = mock_progress_instance

        mock_checkpoint_instance = Mock()
        mock_checkpoint_instance.create_checkpoint = Mock()
        mock_checkpoint.return_value = mock_checkpoint_instance

        mock_executor_instance = Mock()
        mock_executor_instance.execute_workflow = Mock(return_value={"success": True, "output": {}})
        mock_executor.return_value = mock_executor_instance

        mock_git_instance = Mock()
        mock_git_instance.auto_commit_step = Mock()
        mock_git_manager.return_value = mock_git_instance

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="outline_phase",
            end_phase="outline_phase",
        )

        executor = AutonomousExecutor(config, tmp_path)
        result = executor.execute(resume=False)

        assert result.success is True
        mock_checkpoint_instance.create_checkpoint.assert_called()
        mock_git_instance.auto_commit_step.assert_called()
