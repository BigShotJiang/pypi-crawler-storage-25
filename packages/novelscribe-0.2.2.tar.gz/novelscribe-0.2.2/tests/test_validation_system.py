"""Tests for ValidationSystem."""

from unittest.mock import Mock

import pytest

from core.validation_system import (
    AdverbOveruseRule,
    ChapterOutlineAlignmentRule,
    CharacterConsistencyRule,
    DialogueAttributionRule,
    DialogueBalanceRule,
    MaxSentenceLengthRule,
    MinimumWordCountRule,
    PassiveVoiceRule,
    RuleCategory,
    SceneLengthRule,
    Severity,
    TimelineContinuityRule,
    ValidationReport,
    ValidationResult,
    ValidationRule,
    ValidationSystem,
)


class TestSeverity:
    """Test Severity enum."""

    def test_severity_values(self):
        assert Severity.ERROR.value == "error"
        assert Severity.WARNING.value == "warning"
        assert Severity.INFO.value == "info"


class TestRuleCategory:
    """Test RuleCategory enum."""

    def test_category_values(self):
        assert RuleCategory.CONTENT.value == "content"
        assert RuleCategory.STRUCTURE.value == "structure"
        assert RuleCategory.STYLE.value == "style"
        assert RuleCategory.CONTINUITY.value == "continuity"


class TestValidationRule:
    """Test ValidationRule class."""

    def test_rule_initialization(self):
        rule = ValidationRule(
            rule_id="test_rule",
            name="Test Rule",
            description="A test rule",
            severity=Severity.WARNING,
            category=RuleCategory.CONTENT,
        )
        assert rule.rule_id == "test_rule"
        assert rule.name == "Test Rule"
        assert rule.severity == Severity.WARNING
        assert rule.enabled is True

    def test_rule_disabled_by_default(self):
        rule = ValidationRule(
            rule_id="test",
            name="Test",
            description="Test",
            severity=Severity.INFO,
            category=RuleCategory.STYLE,
        )
        assert rule.enabled is True

    def test_rule_not_implemented_error(self):
        rule = ValidationRule(
            rule_id="test",
            name="Test",
            description="Test",
            severity=Severity.ERROR,
            category=RuleCategory.CONTENT,
        )
        with pytest.raises(NotImplementedError):
            rule.validate_content("some content")

    def test_rule_callable(self):
        rule = ValidationRule(
            rule_id="test",
            name="Test",
            description="Test",
            severity=Severity.ERROR,
            category=RuleCategory.CONTENT,
        )
        with pytest.raises(NotImplementedError):
            rule("some content")


class TestValidationResult:
    """Test ValidationResult class."""

    def test_result_creation(self):
        rule = ValidationRule(
            rule_id="test",
            name="Test",
            description="Test",
            severity=Severity.ERROR,
            category=RuleCategory.CONTENT,
        )
        result = ValidationResult(
            rule=rule,
            passed=True,
            message="Test passed",
        )
        assert result.passed is True
        assert result.message == "Test passed"
        assert result.location is None

    def test_result_with_context(self):
        rule = ValidationRule(
            rule_id="test",
            name="Test",
            description="Test",
            severity=Severity.WARNING,
            category=RuleCategory.STYLE,
        )
        result = ValidationResult(
            rule=rule,
            passed=False,
            message="Test failed",
            location="line 10",
            suggestion="Fix it",
            context={"key": "value"},
        )
        assert result.location == "line 10"
        assert result.suggestion == "Fix it"
        assert result.context == {"key": "value"}

    def test_result_to_dict(self):
        rule = ValidationRule(
            rule_id="test",
            name="Test",
            description="Test",
            severity=Severity.ERROR,
            category=RuleCategory.CONTENT,
        )
        result = ValidationResult(
            rule=rule,
            passed=False,
            message="Test message",
        )
        d = result.to_dict()
        assert d["rule_id"] == "test"
        assert d["rule_name"] == "Test"
        assert d["passed"] is False
        assert d["message"] == "Test message"


class TestValidationReport:
    """Test ValidationReport class."""

    def test_report_creation(self):
        report = ValidationReport(total_rules_checked=10, passed_rules=8)
        assert report.total_rules_checked == 10
        assert report.passed_rules == 8
        assert report.failed_rules == 0

    def test_success_rate_zero_rules(self):
        report = ValidationReport(total_rules_checked=0)
        assert report.success_rate == 1.0

    def test_success_rate_calculation(self):
        report = ValidationReport(total_rules_checked=10, passed_rules=7)
        assert report.success_rate == 0.7

    def test_get_results_by_severity(self):
        rule1 = ValidationRule(
            rule_id="r1",
            name="R1",
            description="R1",
            severity=Severity.ERROR,
            category=RuleCategory.CONTENT,
        )
        rule2 = ValidationRule(
            rule_id="r2",
            name="R2",
            description="R2",
            severity=Severity.WARNING,
            category=RuleCategory.STYLE,
        )
        results = [
            ValidationResult(rule=rule1, passed=False, message="Error"),
            ValidationResult(rule=rule2, passed=False, message="Warning"),
        ]
        report = ValidationReport(
            total_rules_checked=2,
            passed_rules=0,
            failed_rules=2,
            errors=1,
            warnings=1,
            results=results,
        )
        error_results = report.get_results_by_severity(Severity.ERROR)
        assert len(error_results) == 1

    def test_get_results_by_category(self):
        rule1 = ValidationRule(
            rule_id="r1",
            name="R1",
            description="R1",
            severity=Severity.ERROR,
            category=RuleCategory.CONTENT,
        )
        rule2 = ValidationRule(
            rule_id="r2",
            name="R2",
            description="R2",
            severity=Severity.WARNING,
            category=RuleCategory.STYLE,
        )
        results = [
            ValidationResult(rule=rule1, passed=True, message="OK"),
            ValidationResult(rule=rule2, passed=True, message="OK"),
        ]
        report = ValidationReport(results=results)
        content_results = report.get_results_by_category(RuleCategory.CONTENT)
        assert len(content_results) == 1


class TestValidationSystem:
    """Test ValidationSystem class."""

    def test_initialization(self):
        system = ValidationSystem()
        assert len(system.rules) == 10

    def test_initialization_with_path(self, tmp_path):
        system = ValidationSystem(project_root=tmp_path)
        assert system.project_root == tmp_path

    def test_add_rule(self):
        system = ValidationSystem()
        rule = ValidationRule(
            rule_id="custom",
            name="Custom Rule",
            description="Custom",
            severity=Severity.INFO,
            category=RuleCategory.STYLE,
        )
        system.add_rule(rule)
        assert "custom" in system.rules

    def test_remove_rule(self):
        system = ValidationSystem()
        system.remove_rule("min_word_count")
        assert "min_word_count" not in system.rules

    def test_remove_nonexistent_rule(self):
        system = ValidationSystem()
        system.remove_rule("nonexistent")
        assert len(system.rules) == 10

    def test_enable_rule(self):
        system = ValidationSystem()
        system.rules["min_word_count"].enabled = False
        system.enable_rule("min_word_count")
        assert system.rules["min_word_count"].enabled is True

    def test_disable_rule(self):
        system = ValidationSystem()
        system.disable_rule("min_word_count")
        assert system.rules["min_word_count"].enabled is False

    def test_validate_content_no_context(self):
        system = ValidationSystem()
        content = "Hello world. " * 100
        report = system.validate_content(content)
        assert report.total_rules_checked == 10

    def test_validate_content_with_context(self):
        system = ValidationSystem()
        content = "John walked into the room. Mary was there."
        context = {"character_names": ["John", "Mary"]}
        report = system.validate_content(content, context=context)
        assert report.total_rules_checked == 10

    def test_validate_specific_rules(self):
        system = ValidationSystem()
        content = "Hello world. " * 100
        report = system.validate_content(content, rule_ids=["min_word_count"])
        assert report.total_rules_checked == 1

    def test_validate_handles_exception(self):
        system = ValidationSystem()
        rule = Mock()
        rule.rule_id = "mock"
        rule.validate_content.side_effect = ValueError("Test error")
        system.add_rule(rule)

        content = "Test content"
        report = system.validate_content(content, rule_ids=["mock"])
        assert report.total_rules_checked == 1
        assert report.failed_rules == 1

    def test_get_rules_by_category(self):
        system = ValidationSystem()
        content_rules = system.get_rules_by_category(RuleCategory.CONTENT)
        assert len(content_rules) > 0
        for rule in content_rules:
            assert rule.category == RuleCategory.CONTENT

    def test_get_rules_by_severity(self):
        system = ValidationSystem()
        error_rules = system.get_rules_by_severity(Severity.ERROR)
        assert len(error_rules) > 0
        for rule in error_rules:
            assert rule.severity == Severity.ERROR

    def test_generate_report_summary(self):
        system = ValidationSystem()
        content = "Hello world. " * 100
        report = system.validate_content(content)
        summary = system.generate_report_summary(report)
        assert "Validation Report" in summary
        assert "Rules Checked" in summary


class TestMinimumWordCountRule:
    """Test MinimumWordCountRule."""

    def test_pass_with_sufficient_words(self):
        rule = MinimumWordCountRule(min_words=100)
        content = "word " * 150
        result = rule.validate_content(content)
        assert result.passed is True

    def test_fail_with_insufficient_words(self):
        rule = MinimumWordCountRule(min_words=100)
        content = "word " * 50
        result = rule.validate_content(content)
        assert result.passed is False
        assert result.suggestion is not None


class TestMaxSentenceLengthRule:
    """Test MaxSentenceLengthRule."""

    def test_pass_with_short_sentences(self):
        rule = MaxSentenceLengthRule(max_length=20)
        content = "Short sentence. " * 10
        result = rule.validate_content(content)
        assert result.passed is True

    def test_fail_with_long_sentences(self):
        rule = MaxSentenceLengthRule(max_length=5)
        content = "This is a very long sentence that has many words in it. "
        result = rule.validate_content(content)
        assert result.passed is False


class TestDialogueAttributionRule:
    """Test DialogueAttributionRule."""

    def test_pass_with_proper_attribution(self):
        rule = DialogueAttributionRule(min_attribution_ratio=0.5)
        content = '"Hello," said John. "How are you?" asked Mary.'
        result = rule.validate_content(content)
        assert result.passed is True

    def test_fail_with_no_attribution(self):
        rule = DialogueAttributionRule(min_attribution_ratio=0.5)
        content = '"Hello." "How are you?"'
        result = rule.validate_content(content)
        assert result.passed is False

    def test_pass_with_no_dialogue(self):
        rule = DialogueAttributionRule()
        content = "Just regular text without any dialogue."
        result = rule.validate_content(content)
        assert result.passed is True


class TestCharacterConsistencyRule:
    """Test CharacterConsistencyRule."""

    def test_pass_with_all_characters(self):
        rule = CharacterConsistencyRule()
        content = "John and Mary went to the park. John was happy."
        result = rule.validate_content(content, context={"character_names": ["John", "Mary"]})
        assert result.passed is True

    def test_fail_with_missing_characters(self):
        rule = CharacterConsistencyRule()
        content = "John went to the park."
        result = rule.validate_content(content, context={"character_names": ["John", "Mary"]})
        assert result.passed is False

    def test_pass_with_no_character_context(self):
        rule = CharacterConsistencyRule()
        content = "Some content without character context."
        result = rule.validate_content(content)
        assert result.passed is True


class TestChapterOutlineAlignmentRule:
    """Test ChapterOutlineAlignmentRule."""

    def test_pass_with_all_points(self):
        rule = ChapterOutlineAlignmentRule()
        content = "The hero discovered the treasure. He opened the chest."
        result = rule.validate_content(
            content,
            context={
                "outline_key_points": [
                    "hero discovered the treasure",
                    "opened the chest",
                ]
            },
        )
        assert result.passed is True

    def test_fail_with_missing_points(self):
        rule = ChapterOutlineAlignmentRule()
        content = "The hero went on a journey."
        result = rule.validate_content(
            content,
            context={"outline_key_points": ["hero discovered the treasure"]},
        )
        assert result.passed is False

    def test_pass_with_no_outline_context(self):
        rule = ChapterOutlineAlignmentRule()
        content = "Some content."
        result = rule.validate_content(content)
        assert result.passed is True


class TestTimelineContinuityRule:
    """Test TimelineContinuityRule."""

    def test_pass_with_normal_time_references(self):
        rule = TimelineContinuityRule()
        content = "In the morning, John woke up. By afternoon, he was ready."
        result = rule.validate_content(content, context={"chapter_order": [1, 2]})
        assert result.passed is True

    def test_fail_with_excessive_time_shifts(self):
        rule = TimelineContinuityRule()
        content = "Morning. Afternoon. Evening. Night. Midnight. Dawn. Dusk. Morning."
        result = rule.validate_content(content, context={"chapter_order": [1]})
        assert result.passed is False

    def test_pass_with_no_timeline_context(self):
        rule = TimelineContinuityRule()
        content = "Some content."
        result = rule.validate_content(content)
        assert result.passed is True


class TestPassiveVoiceRule:
    """Test PassiveVoiceRule."""

    def test_pass_with_little_passive_voice(self):
        rule = PassiveVoiceRule(max_ratio=0.05)
        content = "John walked to the store."
        result = rule.validate_content(content)
        assert result.passed is True

    def test_fail_with_excessive_passive_voice(self):
        rule = PassiveVoiceRule(max_ratio=0.05)
        content = "The ball was thrown by John. The window was broken by Mary. The car was driven."
        result = rule.validate_content(content)
        assert result.passed is False


class TestAdverbOveruseRule:
    """Test AdverbOveruseRule."""

    def test_pass_with_little_adverbs(self):
        rule = AdverbOveruseRule(max_ratio=0.03)
        content = "John ran. Mary walked. They talked."
        result = rule.validate_content(content)
        assert result.passed is True

    def test_fail_with_excessive_adverbs(self):
        rule = AdverbOveruseRule(max_ratio=0.02)
        content = "He ran quickly. She walked slowly. They shouted loudly."
        result = rule.validate_content(content)
        assert result.passed is False


class TestDialogueBalanceRule:
    """Test DialogueBalanceRule."""

    def test_pass_with_balanced_dialogue(self):
        rule = DialogueBalanceRule(min_ratio=0.1, max_ratio=0.7)
        content = "Narrative text here. " + '"Hello," said John. ' * 5 + " More narrative."
        result = rule.validate_content(content)
        assert result.passed is True

    def test_fail_with_too_little_dialogue(self):
        rule = DialogueBalanceRule(min_ratio=0.3)
        content = "Very long narrative text. " * 10
        result = rule.validate_content(content)
        assert result.passed is False
        assert "below minimum" in result.message


class TestSceneLengthRule:
    """Test SceneLengthRule."""

    def test_pass_with_single_scene(self):
        rule = SceneLengthRule()
        content = "A single scene with some text. " * 50
        result = rule.validate_content(content)
        assert result.passed is True

    def test_pass_with_good_scene_lengths(self):
        rule = SceneLengthRule(min_words=100, max_words=1000)
        content = "Scene one. " * 200 + "\n\n***\n\n" + "Scene two. " * 200
        result = rule.validate_content(content)
        assert result.passed is True

    def test_fail_with_short_scenes(self):
        rule = SceneLengthRule(min_words=500)
        content = "Short scene. " * 10 + "\n\n***\n\n" + "Another short scene. " * 10
        result = rule.validate_content(content)
        assert result.passed is False
