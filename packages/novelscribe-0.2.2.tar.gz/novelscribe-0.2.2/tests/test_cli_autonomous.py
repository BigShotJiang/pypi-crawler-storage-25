"""
Comprehensive tests for CLI autonomous commands
"""

from datetime import datetime
from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from cli_autonomous import (
    autonomous,
)


class TestAutonomousGroup:
    """Test cases for autonomous command group"""

    def test_autonomous_group_exists(self):
        """Test that autonomous command group exists"""
        assert autonomous is not None

    def test_autonomous_help(self):
        """Test autonomous command help"""
        runner = CliRunner()
        result = runner.invoke(autonomous, ["--help"])

        assert result.exit_code in [0, 1]

    def test_autonomous_subcommands_exist(self):
        """Test that autonomous subcommands are registered"""
        runner = CliRunner()
        result = runner.invoke(autonomous, ["--help"])

        assert result.exit_code in [0, 1]
        output = result.output.lower()
        # Should show available commands
        assert "start" in output or "start" in output
        assert "checkpoints" in output or "checkpoints" in output


class TestStartAutonomous:
    """Test cases for start autonomous command"""

    def test_start_autonomous_help(self):
        """Test start command help"""
        runner = CliRunner()
        result = runner.invoke(autonomous, ["start", "--help"])

        assert result.exit_code in [0, 1]

    def test_start_autonomous_missing_args(self):
        """Test start command with missing arguments"""
        runner = CliRunner()
        result = runner.invoke(autonomous, ["start"])

        assert result.exit_code != 0

    def test_start_autonomous_with_defaults(self):
        """Test start command with default options"""
        runner = CliRunner()
        with patch("cli_autonomous.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path_instance.__truediv__ = MagicMock(return_value=mock_path_instance)
            mock_path.return_value = mock_path_instance

            with patch("cli_autonomous.AutonomousExecutor") as mock_executor:
                mock_instance = MagicMock()
                mock_result = MagicMock()
                mock_result.success = True
                mock_result.completed_phases = ["new_novel", "outline"]
                mock_result.final_status = MagicMock(value="completed")
                mock_result.error = None
                mock_instance.execute.return_value = mock_result
                mock_executor.return_value = mock_instance

                result = runner.invoke(autonomous, ["start", "test-project"], obj={"debug": False})

                # Should handle gracefully
                assert result.exit_code in [0, 1]

    def test_start_autonomous_with_start_phase(self):
        """Test start command with custom start phase"""
        runner = CliRunner()
        with patch("cli_autonomous.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path_instance.__truediv__ = MagicMock(return_value=mock_path_instance)
            mock_path.return_value = mock_path_instance

            with patch("cli_autonomous.AutonomousExecutor") as mock_executor:
                mock_instance = MagicMock()
                mock_result = MagicMock()
                mock_result.success = True
                mock_result.completed_phases = ["character"]
                mock_result.final_status = MagicMock(value="completed")
                mock_result.error = None
                mock_instance.execute.return_value = mock_result
                mock_executor.return_value = mock_instance

                result = runner.invoke(
                    autonomous, ["start", "test-project", "--start-phase", "character_phase"]
                )

                assert result.exit_code in [0, 1]

    def test_start_autonomous_with_end_phase(self):
        """Test start command with custom end phase"""
        runner = CliRunner()
        with patch("cli_autonomous.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path_instance.__truediv__ = MagicMock(return_value=mock_path_instance)
            mock_path.return_value = mock_path_instance

            with patch("cli_autonomous.AutonomousExecutor") as mock_executor:
                mock_instance = MagicMock()
                mock_result = MagicMock()
                mock_result.success = True
                mock_result.completed_phases = ["outline", "character", "worldbuilding"]
                mock_result.final_status = MagicMock(value="completed")
                mock_result.error = None
                mock_instance.execute.return_value = mock_result
                mock_executor.return_value = mock_instance

                result = runner.invoke(
                    autonomous, ["start", "test-project", "--end-phase", "worldbuilding_phase"]
                )

                assert result.exit_code in [0, 1]

    def test_start_autonomous_with_human_in_loop(self):
        """Test start command with human-in-the-loop enabled"""
        runner = CliRunner()
        with patch("cli_autonomous.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path_instance.__truediv__ = MagicMock(return_value=mock_path_instance)
            mock_path.return_value = mock_path_instance

            with patch("cli_autonomous.AutonomousExecutor") as mock_executor:
                mock_instance = MagicMock()
                mock_result = MagicMock()
                mock_result.success = True
                mock_result.completed_phases = ["outline"]
                mock_result.final_status = MagicMock(value="completed")
                mock_result.error = None
                mock_instance.execute.return_value = mock_result
                mock_executor.return_value = mock_instance

                result = runner.invoke(autonomous, ["start", "test-project", "--human-in-loop"])

                assert result.exit_code in [0, 1]

    def test_start_autonomous_with_max_chapters(self):
        """Test start command with max chapters"""
        runner = CliRunner()
        with patch("cli_autonomous.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path_instance.__truediv__ = MagicMock(return_value=mock_path_instance)
            mock_path.return_value = mock_path_instance

            with patch("cli_autonomous.AutonomousExecutor") as mock_executor:
                mock_instance = MagicMock()
                mock_result = MagicMock()
                mock_result.success = True
                mock_result.completed_phases = []
                mock_result.final_status = MagicMock(value="completed")
                mock_result.error = None
                mock_instance.execute.return_value = mock_result
                mock_executor.return_value = mock_instance

                result = runner.invoke(
                    autonomous, ["start", "test-project", "--max-chapters", "20"]
                )

                assert result.exit_code in [0, 1]

    def test_start_autonomous_with_provider(self):
        """Test start command with custom provider"""
        runner = CliRunner()
        with patch("cli_autonomous.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path_instance.__truediv__ = MagicMock(return_value=mock_path_instance)
            mock_path.return_value = mock_path_instance

            with patch("cli_autonomous.AutonomousExecutor") as mock_executor:
                mock_instance = MagicMock()
                mock_result = MagicMock()
                mock_result.success = True
                mock_result.completed_phases = []
                mock_result.final_status = MagicMock(value="completed")
                mock_result.error = None
                mock_instance.execute.return_value = mock_result
                mock_executor.return_value = mock_instance

                result = runner.invoke(
                    autonomous, ["start", "test-project", "--provider", "anthropic"]
                )

                assert result.exit_code in [0, 1]

    def test_start_autonomous_with_resume(self):
        """Test start command with resume flag"""
        runner = CliRunner()
        with patch("cli_autonomous.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = False  # Resume doesn't require existence
            mock_path_instance.__truediv__ = MagicMock(return_value=mock_path_instance)
            mock_path.return_value = mock_path_instance

            with patch("cli_autonomous.AutonomousExecutor") as mock_executor:
                mock_instance = MagicMock()
                mock_result = MagicMock()
                mock_result.success = True
                mock_result.completed_phases = ["outline", "character"]
                mock_result.final_status = MagicMock(value="completed")
                mock_result.error = None
                mock_instance.execute.return_value = mock_result
                mock_executor.return_value = mock_instance

                result = runner.invoke(autonomous, ["start", "test-project", "--resume"])

                assert result.exit_code in [0, 1]

    def test_start_autonomous_with_checkpoint_id(self):
        """Test start command with specific checkpoint ID"""
        runner = CliRunner()
        with patch("cli_autonomous.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = False  # Resume doesn't require existence
            mock_path_instance.__truediv__ = MagicMock(return_value=mock_path_instance)
            mock_path.return_value = mock_path_instance

            with patch("cli_autonomous.AutonomousExecutor") as mock_executor:
                mock_instance = MagicMock()
                mock_result = MagicMock()
                mock_result.success = True
                mock_result.completed_phases = []
                mock_result.final_status = MagicMock(value="completed")
                mock_result.error = None
                mock_instance.execute.return_value = mock_result
                mock_executor.return_value = mock_instance

                result = runner.invoke(
                    autonomous,
                    ["start", "test-project", "--resume", "--checkpoint-id", "checkpoint-123"],
                )

                assert result.exit_code in [0, 1]

    def test_start_autonomous_with_git_commit(self):
        """Test start command with git commit enabled"""
        runner = CliRunner()
        with patch("cli_autonomous.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path_instance.__truediv__ = MagicMock(return_value=mock_path_instance)
            mock_path.return_value = mock_path_instance

            with patch("cli_autonomous.AutonomousExecutor") as mock_executor:
                mock_instance = MagicMock()
                mock_result = MagicMock()
                mock_result.success = True
                mock_result.completed_phases = []
                mock_result.final_status = MagicMock(value="completed")
                mock_result.error = None
                mock_instance.execute.return_value = mock_result
                mock_executor.return_value = mock_instance

                result = runner.invoke(autonomous, ["start", "test-project", "--git-commit"])

                assert result.exit_code in [0, 1]

    def test_start_autonomous_project_not_found(self):
        """Test start command with non-existent project"""
        runner = CliRunner()
        with patch("cli_autonomous.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = False
            mock_path_instance.__truediv__ = MagicMock(return_value=mock_path_instance)
            mock_path.return_value = mock_path_instance

            result = runner.invoke(autonomous, ["start", "nonexistent-project"])

            assert result.exit_code in [0, 1]

    def test_start_autonomous_failure(self):
        """Test start command with execution failure"""
        runner = CliRunner()
        with patch("cli_autonomous.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path_instance.__truediv__ = MagicMock(return_value=mock_path_instance)
            mock_path.return_value = mock_path_instance

            with patch("cli_autonomous.AutonomousExecutor") as mock_executor:
                mock_instance = MagicMock()
                mock_result = MagicMock()
                mock_result.success = False
                mock_result.completed_phases = ["new_novel"]
                mock_result.final_status = MagicMock(value="error")
                mock_result.error = "Execution failed"
                mock_instance.execute.return_value = mock_result
                mock_executor.return_value = mock_instance

                result = runner.invoke(autonomous, ["start", "test-project"])

                assert result.exit_code in [0, 1]

    def test_start_autonomous_with_all_options(self):
        """Test start command with all options"""
        runner = CliRunner()
        with patch("cli_autonomous.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path_instance.__truediv__ = MagicMock(return_value=mock_path_instance)
            mock_path.return_value = mock_path_instance

            with patch("cli_autonomous.AutonomousExecutor") as mock_executor:
                mock_instance = MagicMock()
                mock_result = MagicMock()
                mock_result.success = True
                mock_result.completed_phases = []
                mock_result.final_status = MagicMock(value="completed")
                mock_result.error = None
                mock_instance.execute.return_value = mock_result
                mock_executor.return_value = mock_instance

                result = runner.invoke(
                    autonomous,
                    [
                        "start",
                        "test-project",
                        "--start-phase",
                        "outline_phase",
                        "--end-phase",
                        "writing_phase",
                        "--human-in-loop",
                        "--max-chapters",
                        "10",
                        "--provider",
                        "openai",
                        "--git-commit",
                    ],
                )

                assert result.exit_code in [0, 1]

    def test_start_autonomous_custom_dirs(self):
        """Test start command with custom directories"""
        runner = CliRunner()
        with patch("cli_autonomous.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path_instance.__truediv__ = MagicMock(return_value=mock_path_instance)
            mock_path.return_value = mock_path_instance

            with patch("cli_autonomous.AutonomousExecutor") as mock_executor:
                mock_instance = MagicMock()
                mock_result = MagicMock()
                mock_result.success = True
                mock_result.completed_phases = []
                mock_result.final_status = MagicMock(value="completed")
                mock_result.error = None
                mock_instance.execute.return_value = mock_result
                mock_executor.return_value = mock_instance

                result = runner.invoke(
                    autonomous,
                    [
                        "start",
                        "test-project",
                        "--project-dir",
                        "/custom/path",
                        "--checkpoint-dir",
                        "/custom/checkpoints",
                    ],
                )

                assert result.exit_code in [0, 1]


class TestListCheckpoints:
    """Test cases for list checkpoints command"""

    def test_list_checkpoints_help(self):
        """Test list checkpoints command help"""
        runner = CliRunner()
        result = runner.invoke(autonomous, ["checkpoints", "--help"])

        assert result.exit_code in [0, 1]

    def test_list_checkpoints_basic(self):
        """Test list checkpoints basic execution"""
        runner = CliRunner()
        with patch("core.checkpoint_manager.CheckpointManager") as mock_manager:
            mock_instance = MagicMock()
            mock_instance.list_checkpoints.return_value = []
            mock_manager.return_value = mock_instance

            result = runner.invoke(autonomous, ["checkpoints"])

            # Should handle gracefully
            assert result.exit_code in [0, 1]

    def test_list_checkpoints_with_checkpoints(self):
        """Test list checkpoints with existing checkpoints"""
        runner = CliRunner()
        with patch("core.checkpoint_manager.CheckpointManager") as mock_manager:
            mock_checkpoint = MagicMock()
            mock_checkpoint.checkpoint_id = "checkpoint-123"
            mock_checkpoint.project_name = "test-project"
            mock_checkpoint.progress_state = MagicMock()
            mock_checkpoint.progress_state.progress_percentage = 50.0
            mock_checkpoint.progress_state.status = MagicMock(value="running")
            mock_checkpoint.progress_state.current_phase = "writing"
            mock_checkpoint.completed_workflows = ["workflow1", "workflow2"]
            mock_checkpoint.timestamp = datetime.now()

            mock_instance = MagicMock()
            mock_instance.list_checkpoints.return_value = [mock_checkpoint]
            mock_manager.return_value = mock_instance

            result = runner.invoke(autonomous, ["checkpoints", "--project-name", "test-project"])

            assert result.exit_code in [0, 1]

    def test_list_checkpoints_with_limit(self):
        """Test list checkpoints with limit"""
        runner = CliRunner()
        with patch("core.checkpoint_manager.CheckpointManager") as mock_manager:
            mock_checkpoint = MagicMock()
            mock_checkpoint.checkpoint_id = "checkpoint-1"
            mock_checkpoint.project_name = "test-project"
            mock_checkpoint.progress_state = MagicMock()
            mock_checkpoint.progress_state.progress_percentage = 75.0
            mock_checkpoint.progress_state.status = MagicMock(value="completed")
            mock_checkpoint.progress_state.current_phase = "writing"
            mock_checkpoint.completed_workflows = []
            mock_checkpoint.timestamp = datetime.now()

            mock_instance = MagicMock()
            mock_instance.list_checkpoints.return_value = [mock_checkpoint]
            mock_manager.return_value = mock_instance

            result = runner.invoke(autonomous, ["checkpoints", "--limit", "5"])

            assert result.exit_code in [0, 1]


class TestShowCheckpoint:
    """Test cases for show checkpoint command"""

    def test_show_checkpoint_help(self):
        """Test show checkpoint command help"""
        runner = CliRunner()
        result = runner.invoke(autonomous, ["show-checkpoint", "--help"])

        assert result.exit_code in [0, 1]

    def test_show_checkpoint_missing_args(self):
        """Test show checkpoint with missing arguments"""
        runner = CliRunner()
        result = runner.invoke(autonomous, ["show-checkpoint"])

        assert result.exit_code != 0

    def test_show_checkpoint_not_found(self):
        """Test show checkpoint when not found"""
        runner = CliRunner()
        with patch("core.checkpoint_manager.CheckpointManager") as mock_manager:
            mock_instance = MagicMock()
            mock_instance.load_checkpoint.return_value = None
            mock_manager.return_value = mock_instance

            result = runner.invoke(autonomous, ["show-checkpoint", "nonexistent-checkpoint"])

            assert result.exit_code in [0, 1]

    def test_show_checkpoint_success(self):
        """Test show checkpoint with valid ID"""
        runner = CliRunner()
        with patch("core.checkpoint_manager.CheckpointManager") as mock_manager:
            mock_checkpoint = MagicMock()
            mock_checkpoint.checkpoint_id = "checkpoint-123"
            mock_checkpoint.project_name = "test-project"
            mock_checkpoint.timestamp = datetime.now()
            mock_checkpoint.current_workflow = "writing"
            mock_checkpoint.execution_context = {"key": "value"}

            mock_progress = MagicMock()
            mock_progress.current_phase = "writing"
            mock_progress.completed_phases = ["outline", "character"]
            mock_progress.total_steps = 10
            mock_progress.completed_steps = 5
            mock_progress.progress_percentage = 50.0
            mock_progress.status = MagicMock(value="running")
            mock_progress.current_step = "step-5"
            mock_progress.error = None

            mock_checkpoint.progress_state = mock_progress

            mock_instance = MagicMock()
            mock_instance.load_checkpoint.return_value = mock_checkpoint
            mock_manager.return_value = mock_instance

            result = runner.invoke(autonomous, ["show-checkpoint", "checkpoint-123"])

            assert result.exit_code in [0, 1]


class TestDeleteCheckpoint:
    """Test cases for delete checkpoint command"""

    def test_delete_checkpoint_help(self):
        """Test delete checkpoint command help"""
        runner = CliRunner()
        result = runner.invoke(autonomous, ["delete-checkpoint", "--help"])

        assert result.exit_code in [0, 1]

    def test_delete_checkpoint_missing_args(self):
        """Test delete checkpoint with missing arguments"""
        runner = CliRunner()
        result = runner.invoke(autonomous, ["delete-checkpoint"])

        assert result.exit_code != 0

    def test_delete_checkpoint_not_found(self):
        """Test delete checkpoint when not found"""
        runner = CliRunner()
        with patch("core.checkpoint_manager.CheckpointManager") as mock_manager:
            mock_instance = MagicMock()
            mock_instance.load_checkpoint.return_value = None
            mock_manager.return_value = mock_instance

            result = runner.invoke(autonomous, ["delete-checkpoint", "nonexistent-checkpoint"])

            assert result.exit_code in [0, 1]

    def test_delete_checkpoint_with_force(self):
        """Test delete checkpoint with force flag"""
        runner = CliRunner()
        with patch("core.checkpoint_manager.CheckpointManager") as mock_manager:
            mock_instance = MagicMock()
            mock_instance.delete_checkpoint.return_value = True
            mock_manager.return_value = mock_instance

            result = runner.invoke(autonomous, ["delete-checkpoint", "checkpoint-123", "--force"])

            assert result.exit_code in [0, 1]

    def test_delete_checkpoint_failure(self):
        """Test delete checkpoint when deletion fails"""
        runner = CliRunner()
        with patch("core.checkpoint_manager.CheckpointManager") as mock_manager:
            mock_instance = MagicMock()
            mock_instance.delete_checkpoint.return_value = False
            mock_manager.return_value = mock_instance

            result = runner.invoke(autonomous, ["delete-checkpoint", "checkpoint-123", "--force"])

            assert result.exit_code in [0, 1]


class TestShowProgress:
    """Test cases for show progress command"""

    def test_show_progress_help(self):
        """Test show progress command help"""
        runner = CliRunner()
        result = runner.invoke(autonomous, ["progress", "--help"])

        assert result.exit_code in [0, 1]

    def test_show_progress_missing_args(self):
        """Test show progress with missing arguments"""
        runner = CliRunner()
        result = runner.invoke(autonomous, ["progress"])

        assert result.exit_code != 0

    def test_show_progress_no_state(self):
        """Test show progress when no state found"""
        runner = CliRunner()
        with patch("core.progress_tracker.ProgressTracker") as mock_tracker:
            mock_instance = MagicMock()
            mock_instance.get_state.return_value = None
            mock_tracker.return_value = mock_instance

            result = runner.invoke(autonomous, ["progress", "test-project"])

            assert result.exit_code in [0, 1]

    def test_show_progress_success(self):
        """Test show progress with valid project"""
        runner = CliRunner()
        with patch("core.progress_tracker.ProgressTracker") as mock_tracker:
            mock_state = MagicMock()
            mock_state.current_phase = "writing"
            mock_state.status = MagicMock(value="running")
            mock_state.progress_percentage = 50.0
            mock_state.total_steps = 10
            mock_state.completed_steps = 5
            mock_state.completed_phases = ["outline", "character"]
            mock_state.start_time = datetime.now()
            mock_state.last_update = datetime.now()
            mock_state.error = None

            mock_instance = MagicMock()
            mock_instance.get_state.return_value = mock_state
            mock_tracker.return_value = mock_instance

            result = runner.invoke(autonomous, ["progress", "test-project"])

            assert result.exit_code in [0, 1]

    def test_show_progress_with_error(self):
        """Test show progress with error state"""
        runner = CliRunner()
        with patch("core.progress_tracker.ProgressTracker") as mock_tracker:
            mock_state = MagicMock()
            mock_state.current_phase = "writing"
            mock_state.status = MagicMock(value="error")
            mock_state.progress_percentage = 30.0
            mock_state.total_steps = 10
            mock_state.completed_steps = 3
            mock_state.completed_phases = ["outline"]
            mock_state.start_time = datetime.now()
            mock_state.last_update = datetime.now()
            mock_state.error = "Test error message"

            mock_instance = MagicMock()
            mock_instance.get_state.return_value = mock_state
            mock_tracker.return_value = mock_instance

            result = runner.invoke(autonomous, ["progress", "test-project"])

            assert result.exit_code in [0, 1]
