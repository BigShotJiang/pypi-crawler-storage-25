"""
Unit tests for Suggestion Orchestrator
"""

from unittest.mock import Mock

import pytest

from core.suggestions.knowledge_base import SuggestionKnowledgeBase
from core.suggestions.learning_tracker import LearningTracker
from core.suggestions.models import (
    ProactiveConfig,
    Suggestion,
    SuggestionCategory,
    SuggestionRequest,
    SuggestionSource,
    TriggerType,
)
from core.suggestions.orchestrator import SuggestionOrchestrator


@pytest.fixture
def temp_kb_dir(tmp_path):
    """Create temporary directory for knowledge base data."""
    kb_dir = tmp_path / "suggestions"
    kb_dir.mkdir(parents=True)
    return kb_dir


@pytest.fixture
def mock_kb():
    """Create mock knowledge base."""
    kb = Mock(spec=SuggestionKnowledgeBase)

    suggestions = [
        Suggestion(
            id="scifi_space_opera",
            name="Space Opera",
            description="Epic adventures across galaxies",
            category=SuggestionCategory.GENRE,
            best_for=["Large-scale conflicts", "Multiple alien species", "Complex politics"],
            examples=["Dune", "Foundation"],
            source=SuggestionSource.STATIC,
            acceptance_rate=0.8,
            acceptance_count=10,
            accepted_count=8,
        ),
        Suggestion(
            id="scifi_cyberpunk",
            name="Cyberpunk",
            description="High tech, low life dystopian futures",
            category=SuggestionCategory.GENRE,
            best_for=["Near-future settings", "AI and technology themes", "Social commentary"],
            examples=["Neuromancer", "Snow Crash"],
            source=SuggestionSource.STATIC,
            acceptance_rate=0.7,
            acceptance_count=10,
            accepted_count=7,
        ),
        Suggestion(
            id="workflow_autonomous",
            name="Autonomous Mode",
            description="AI writes entire novel with minimal intervention",
            category=SuggestionCategory.WORKFLOW,
            best_for=["Experienced authors", "Well-defined concepts", "Rapid prototyping"],
            examples=["Quick drafts", "Genre fiction"],
            source=SuggestionSource.STATIC,
            acceptance_rate=0.6,
            acceptance_count=5,
            accepted_count=3,
        ),
    ]

    kb.load_suggestions = Mock(return_value=suggestions)
    kb.get_suggestion = Mock(
        side_effect=lambda sid: next((s for s in suggestions if s.id == sid), None)
    )

    return kb


@pytest.fixture
def mock_tracker():
    """Create mock learning tracker."""
    tracker = Mock(spec=LearningTracker)
    tracker.record_acceptance = Mock()
    tracker.get_usage_analytics = Mock(
        return_value={"period_days": 7, "total_events": 10, "dynamic_acceptance_rate": 0.5}
    )
    return tracker


@pytest.fixture
def orchestrator(mock_kb, mock_tracker):
    """Create orchestrator instance."""
    return SuggestionOrchestrator(kb=mock_kb, tracker=mock_tracker)


class TestSuggestionOrchestrator:
    """Test suite for SuggestionOrchestrator."""

    def test_initialization(self, mock_kb):
        """Test orchestrator initialization."""
        orchestrator = SuggestionOrchestrator(kb=mock_kb)
        assert orchestrator.kb == mock_kb
        assert orchestrator.tracker is None

    def test_initialization_with_tracker(self, mock_kb, mock_tracker):
        """Test orchestrator initialization with tracker."""
        orchestrator = SuggestionOrchestrator(kb=mock_kb, tracker=mock_tracker)
        assert orchestrator.kb == mock_kb
        assert orchestrator.tracker == mock_tracker

    def test_should_suggest_disabled_config(self, orchestrator):
        """Test should_suggest returns False when config disabled."""
        config = ProactiveConfig(enabled=False)
        result = orchestrator.should_suggest(TriggerType.DECISION_POINT, config)
        assert result is False

    def test_should_suggest_user_request_always_true(self, orchestrator):
        """Test should_suggest always true for USER_REQUEST."""
        config = ProactiveConfig(enabled=True)
        result = orchestrator.should_suggest(TriggerType.USER_REQUEST, config)
        assert result is True

    def test_should_suggest_continuous_mode(self, orchestrator):
        """Test should_suggest respects continuous mode."""
        config = ProactiveConfig(enabled=True, continuous=True)
        result = orchestrator.should_suggest(TriggerType.CONTINUOUS, config)
        assert result is True

    def test_should_suggest_continuous_disabled(self, orchestrator):
        """Test should_suggest False when continuous disabled."""
        config = ProactiveConfig(enabled=True, continuous=False)
        result = orchestrator.should_suggest(TriggerType.CONTINUOUS, config)
        assert result is False

    def test_should_suggest_respects_category(self, orchestrator):
        """Test should_suggest respects category configuration."""
        config = ProactiveConfig(
            enabled=True,
            suggestions={SuggestionCategory.GENRE: True, SuggestionCategory.WORKFLOW: False},
        )

        result_genre = orchestrator.should_suggest(TriggerType.DECISION_POINT, config, None)
        # Since project_context is None, it will default to GENRE
        assert result_genre is True

        # Test with a context that would infer workflow
        result_workflow = orchestrator.should_suggest(
            TriggerType.PHASE_TRANSITION, config, {"phase": "review_phase"}
        )
        # review_phase should map to WORKFLOW which is disabled
        assert result_workflow is False

    def test_get_suggestions_returns_no_suggestions_when_disabled(self, orchestrator):
        """Test get_suggestions returns empty response when disabled."""
        config = ProactiveConfig(enabled=False)
        request = SuggestionRequest(
            trigger_type=TriggerType.DECISION_POINT,
            project_id="test_project",
            category=SuggestionCategory.GENRE,
        )

        response = orchestrator.get_suggestions(request, config)

        assert response.show_suggestions is False
        assert len(response.suggestions) == 0

    def test_get_suggestions_filters_by_category(self, orchestrator, mock_kb):
        """Test get_suggestions only returns suggestions for requested category."""
        config = ProactiveConfig(
            enabled=True,
            suggestions={SuggestionCategory.GENRE: True, SuggestionCategory.WORKFLOW: False},
        )
        request = SuggestionRequest(
            trigger_type=TriggerType.DECISION_POINT,
            project_id="test_project",
            category=SuggestionCategory.WORKFLOW,
        )

        response = orchestrator.get_suggestions(request, config)

        assert response.show_suggestions is False

    def test_rank_suggestions_by_acceptance_rate(self, orchestrator):
        """Test rank_suggestions sorts by acceptance rate."""
        suggestions = [
            Suggestion(
                id="low",
                name="Low Rate",
                description="Test",
                category=SuggestionCategory.GENRE,
                best_for=[],
                acceptance_rate=0.3,
                acceptance_count=5,
                accepted_count=1,
            ),
            Suggestion(
                id="high",
                name="High Rate",
                description="Test",
                category=SuggestionCategory.GENRE,
                best_for=[],
                acceptance_rate=0.9,
                acceptance_count=10,
                accepted_count=9,
            ),
            Suggestion(
                id="medium",
                name="Medium Rate",
                description="Test",
                category=SuggestionCategory.GENRE,
                best_for=[],
                acceptance_rate=0.6,
                acceptance_count=5,
                accepted_count=3,
            ),
        ]

        ranked = orchestrator.rank_suggestions(suggestions)

        assert ranked[0].id == "high"
        assert ranked[1].id == "medium"
        assert ranked[2].id == "low"

    def test_rank_suggestions_respects_limit(self, orchestrator):
        """Test rank_suggestions respects limit parameter."""
        suggestions = [
            Suggestion(
                id=f"suggestion_{i}",
                name=f"Suggestion {i}",
                description="Test",
                category=SuggestionCategory.GENRE,
                best_for=[],
                acceptance_rate=0.5 + (i * 0.05),
                acceptance_count=10,
                accepted_count=5 + i,
            )
            for i in range(10)
        ]

        ranked = orchestrator.rank_suggestions(suggestions, limit=4)

        assert len(ranked) == 4

    def test_rank_suggestions_static_boost(self, orchestrator):
        """Test rank_suggestions gives boost to static suggestions."""
        suggestions = [
            Suggestion(
                id="dynamic_high",
                name="Dynamic High",
                description="Test",
                category=SuggestionCategory.GENRE,
                best_for=[],
                source=SuggestionSource.DYNAMIC,
                acceptance_rate=0.8,
                acceptance_count=10,
                accepted_count=8,
            ),
            Suggestion(
                id="static_lower",
                name="Static Lower",
                description="Test",
                category=SuggestionCategory.GENRE,
                best_for=[],
                source=SuggestionSource.STATIC,
                acceptance_rate=0.7,
                acceptance_count=10,
                accepted_count=7,
            ),
        ]

        ranked = orchestrator.rank_suggestions(suggestions)

        assert ranked[0].id == "static_lower"

    def test_format_suggestions_empty(self, orchestrator):
        """Test format_suggestions returns empty string for no suggestions."""
        result = orchestrator.format_suggestions([])
        assert result == ""

    def test_format_suggestions_multi_choice(self, orchestrator):
        """Test format_suggestions creates proper multi-choice format."""
        suggestions = [
            Suggestion(
                id="option1",
                name="Option 1",
                description="First option",
                category=SuggestionCategory.GENRE,
                best_for=["Use case A", "Use case B"],
                examples=["Example A"],
                source=SuggestionSource.STATIC,
                acceptance_rate=0.8,
                acceptance_count=10,
                accepted_count=8,
            ),
            Suggestion(
                id="option2",
                name="Option 2",
                description="Second option",
                category=SuggestionCategory.GENRE,
                best_for=["Use case C"],
                examples=["Example B"],
                source=SuggestionSource.LEARNED,
                acceptance_rate=0.8,
                acceptance_count=10,
                accepted_count=8,
            ),
        ]

        formatted = orchestrator.format_suggestions(suggestions)

        assert "**Option 1: ⭐ Option 1" in formatted
        assert "Option 2: Option 2" in formatted
        assert "First option" in formatted
        assert "Best for: Use case A | Use case B" in formatted
        assert "[80% acceptance]" in formatted

    def test_record_suggestion_outcome(self, orchestrator, mock_tracker):
        """Test record_suggestion_outcome calls tracker."""
        orchestrator.record_suggestion_outcome(
            suggestion_id="test_suggestion",
            accepted=True,
            project_id="test_project",
            user_choice="Option 1",
            trigger_type=TriggerType.DECISION_POINT,
            category=SuggestionCategory.GENRE,
        )

        mock_tracker.record_acceptance.assert_called_once()

    def test_get_usage_analytics(self, orchestrator, mock_tracker):
        """Test get_usage_analytics returns tracker data."""
        analytics = orchestrator.get_usage_analytics(days=7)

        assert analytics["total_events"] == 10
        assert analytics["dynamic_acceptance_rate"] == 0.5

    def test_get_usage_analytics_no_tracker(self, mock_kb):
        """Test get_usage_analytics returns default when no tracker."""
        orchestrator = SuggestionOrchestrator(kb=mock_kb)
        analytics = orchestrator.get_usage_analytics(days=7)

        assert analytics["total_events"] == 0
        assert analytics["dynamic_acceptance_rate"] == 0.0

    def test_infer_category_from_issue_trigger(self, orchestrator):
        """Test _infer_category_from_trigger returns QUALITY for ISSUE_DETECTED."""
        category = orchestrator._infer_category_from_trigger(TriggerType.ISSUE_DETECTED, tuple())
        assert category == SuggestionCategory.QUALITY

    def test_infer_category_from_phase_outline(self, orchestrator):
        """Test _infer_category_from_trigger returns GENRE for outline phase."""
        category = orchestrator._infer_category_from_trigger(
            TriggerType.PHASE_TRANSITION, tuple(sorted({"phase": "outline_creation"}.items()))
        )
        assert category == SuggestionCategory.GENRE

    def test_infer_category_from_phase_writing(self, orchestrator):
        """Test _infer_category_from_trigger returns TECHNICAL for writing phase."""
        category = orchestrator._infer_category_from_trigger(
            TriggerType.PHASE_TRANSITION, tuple(sorted({"phase": "chapter_writing"}.items()))
        )
        assert category == SuggestionCategory.TECHNICAL

    def test_merge_and_deduplicate(self, orchestrator):
        """Test _merge_and_deduplicate removes duplicate suggestions."""
        static = [
            Suggestion(
                id="duplicate",
                name="Duplicate",
                description="Test",
                category=SuggestionCategory.GENRE,
                best_for=[],
            ),
            Suggestion(
                id="static_only",
                name="Static Only",
                description="Test",
                category=SuggestionCategory.GENRE,
                best_for=[],
            ),
        ]

        dynamic = [
            Suggestion(
                id="duplicate",
                name="Duplicate",
                description="Test",
                category=SuggestionCategory.GENRE,
                best_for=[],
                source=SuggestionSource.DYNAMIC,
            ),
            Suggestion(
                id="dynamic_only",
                name="Dynamic Only",
                description="Test",
                category=SuggestionCategory.GENRE,
                best_for=[],
                source=SuggestionSource.DYNAMIC,
            ),
        ]

        merged = orchestrator._merge_and_deduplicate(static, dynamic)

        assert len(merged) == 3
        suggestion_ids = [s.id for s in merged]
        assert "duplicate" in suggestion_ids
        assert "static_only" in suggestion_ids
        assert "dynamic_only" in suggestion_ids

    def test_filter_by_context_genre(self, orchestrator):
        """Test _filter_by_context filters by genre context."""
        suggestions = [
            Suggestion(
                id="scifi",
                name="Sci-Fi",
                description="Test",
                category=SuggestionCategory.GENRE,
                best_for=["Science fiction", "Space exploration"],
            ),
            Suggestion(
                id="fantasy",
                name="Fantasy",
                description="Test",
                category=SuggestionCategory.GENRE,
                best_for=["Magic systems", "Medieval settings"],
            ),
        ]

        filtered = orchestrator._filter_by_context(suggestions, {"genre": "science fiction"})

        assert len(filtered) == 2
        assert any(s.id == "scifi" for s in filtered)

    def test_get_suggestions_full_workflow(self, orchestrator, mock_kb):
        """Test full get_suggestions workflow with realistic inputs."""
        config = ProactiveConfig(enabled=True)
        request = SuggestionRequest(
            trigger_type=TriggerType.DECISION_POINT,
            project_id="test_project",
            category=SuggestionCategory.GENRE,
            language="en",
            max_suggestions=2,
        )

        response = orchestrator.get_suggestions(request, config)

        assert response.show_suggestions is True
        assert response.trigger_type == TriggerType.DECISION_POINT
        assert len(response.suggestions) <= 2
        assert response.formatted_suggestions != ""


class TestSuggestionOrchestratorMissingCoverage:
    """Tests for missing coverage lines in suggestion orchestrator."""

    def test_should_suggest_with_tuple_context(self, orchestrator):
        """Test should_suggest with tuple context (line 80)."""
        config = ProactiveConfig(enabled=True)
        result = orchestrator.should_suggest(
            TriggerType.DECISION_POINT, config, tuple(sorted({"phase": "outline"}.items()))
        )
        assert isinstance(result, bool)

    def test_infer_category_phase_writing_draft(self, orchestrator):
        """Test _infer_category from writing/draft phase (lines 190→194)."""
        category = orchestrator._infer_category_from_trigger(
            TriggerType.PHASE_TRANSITION, tuple(sorted({"phase": "draft_writing"}.items()))
        )
        assert category == SuggestionCategory.TECHNICAL

    def test_infer_category_with_context_category(self, orchestrator):
        """Test _infer_category from context category field (lines 217, 221-224)."""
        category = orchestrator._infer_category_from_trigger(
            TriggerType.DECISION_POINT, tuple(sorted({"category": "quality"}.items()))
        )
        assert category == SuggestionCategory.QUALITY

    def test_infer_category_with_invalid_context_category(self, orchestrator):
        """Test _infer_category with invalid context category (line 221-224)."""
        category = orchestrator._infer_category_from_trigger(
            TriggerType.DECISION_POINT, tuple(sorted({"category": "invalid_cat"}.items()))
        )
        assert category == SuggestionCategory.GENRE

    def test_get_suggestions_with_filter_by_context(self, orchestrator, mock_kb):
        """Test get_suggestions with filter_by_context (line 235)."""
        config = ProactiveConfig(enabled=True)
        request = SuggestionRequest(
            trigger_type=TriggerType.DECISION_POINT,
            project_id="test_project",
            category=SuggestionCategory.GENRE,
            language="en",
            project_context={"filter_by_context": True, "genre": "fantasy"},
        )
        response = orchestrator.get_suggestions(request, config)
        assert response.show_suggestions is True

    def test_record_suggestion_no_tracker(self, mock_kb):
        """Test record_suggestion_outcome with no tracker (line 276, 302→exit)."""
        orchestrator = SuggestionOrchestrator(kb=mock_kb, tracker=None)
        orchestrator.record_suggestion_outcome(
            suggestion_id="test",
            accepted=True,
            project_id="p1",
            user_choice="ok",
            trigger_type=TriggerType.DECISION_POINT,
            category=SuggestionCategory.GENRE,
        )
        mock_kb.update_acceptance_rate.assert_not_called()
