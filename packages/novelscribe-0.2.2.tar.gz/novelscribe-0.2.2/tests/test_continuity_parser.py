from pathlib import Path

import pytest

from core.continuity_parser import (
    ContinuityIssue,
    ContinuityParser,
    IssueType,
    ReportStatus,
    Severity,
)


@pytest.fixture
def temp_project_dir(tmp_path):
    project_dir = tmp_path / "test_novel"
    project_dir.mkdir(parents=True, exist_ok=True)
    return project_dir


@pytest.fixture
def sample_report_content():
    return """# Continuity Report: Test Novel

**Status:** FAIL

## Summary
- Total Issues: 3
- Critical: 1
- Major: 1
- Minor: 1

## Issues

### Issue 1
- **Type:** character
- **Severity:** critical
- **Location:** Chapter 5
**Description:** Character John suddenly knows magic he never learned
**Suggestion:** Add foreshadowing or learning scene earlier

### Issue 2
- **Type:** plot
- **Severity:** major
**Description:** Plot thread introduced in chapter 2 is never resolved
**Suggestion:** Add resolution in chapter 10

### Issue 3
- **Type:** timeline
- **Severity:** minor
**Description:** Timeline inconsistency: Day mentioned as Tuesday but should be Wednesday
**Suggestion:** Fix day reference
"""


@pytest.fixture
def sample_issues():
    return [
        ContinuityIssue(
            issue_type=IssueType.CHARACTER,
            severity=Severity.CRITICAL,
            description="Character inconsistency",
            location="Chapter 5",
            suggestion="Add foreshadowing",
        ),
        ContinuityIssue(
            issue_type=IssueType.PLOT,
            severity=Severity.MAJOR,
            description="Unresolved plot thread",
            location=None,
            suggestion="Add resolution",
        ),
        ContinuityIssue(
            issue_type=IssueType.TIMELINE,
            severity=Severity.MINOR,
            description="Timeline inconsistency",
            location="Chapter 8",
            suggestion="Fix day reference",
        ),
    ]


class TestContinuityParser:
    def test_initialization(self, temp_project_dir):
        parser = ContinuityParser(str(temp_project_dir))
        assert parser.project_dir == temp_project_dir

    def test_parse_report_from_file(self, temp_project_dir, sample_report_content):
        report_file = temp_project_dir / "continuity_report.md"
        report_file.write_text(sample_report_content)

        parser = ContinuityParser(str(temp_project_dir))
        report = parser.parse_report()

        assert report.project_name == "test_novel"
        assert report.total_issues >= 1

    def test_parse_nonexistent_file(self, temp_project_dir):
        parser = ContinuityParser(str(temp_project_dir))

        with pytest.raises(FileNotFoundError):
            parser.parse_report("nonexistent.md")

    def test_generate_report(self, temp_project_dir, sample_issues):
        parser = ContinuityParser(str(temp_project_dir))

        report = parser.generate_report("test_novel", sample_issues)

        assert report.project_name == "test_novel"
        assert report.total_issues == 3
        assert report.critical_count == 1
        assert report.major_count == 1
        assert report.minor_count == 1
        assert report.status == ReportStatus.FAIL

    def test_determine_status_critical(self, temp_project_dir):
        parser = ContinuityParser(str(temp_project_dir))

        assert parser._determine_status(1, 0, 0) == ReportStatus.FAIL
        assert parser._determine_status(2, 5, 0) == ReportStatus.FAIL

    def test_determine_status_warning(self, temp_project_dir):
        parser = ContinuityParser(str(temp_project_dir))

        assert parser._determine_status(0, 3, 0) == ReportStatus.WARNING
        assert parser._determine_status(0, 6, 0) == ReportStatus.FAIL
        assert parser._determine_status(0, 0, 12) == ReportStatus.WARNING

    def test_determine_status_pass(self, temp_project_dir):
        parser = ContinuityParser(str(temp_project_dir))

        assert parser._determine_status(0, 0, 0) == ReportStatus.PASS
        assert parser._determine_status(0, 0, 5) == ReportStatus.PASS
        assert parser._determine_status(0, 2, 3) == ReportStatus.WARNING

    def test_save_report(self, temp_project_dir, sample_issues):
        parser = ContinuityParser(str(temp_project_dir))
        report = parser.generate_report("test_novel", sample_issues)

        output_path = parser.save_report(report)

        assert Path(output_path).exists()

        content = Path(output_path).read_text()
        assert "# Continuity Report" in content
        assert "test_novel" in content
        assert "Total Issues: 3" in content

    def test_filter_issues_by_type(self, temp_project_dir, sample_issues):
        parser = ContinuityParser(str(temp_project_dir))
        report = parser.generate_report("test_novel", sample_issues)

        character_issues = parser.filter_issues_by_type(report, IssueType.CHARACTER)
        plot_issues = parser.filter_issues_by_type(report, IssueType.PLOT)

        assert len(character_issues) == 1
        assert len(plot_issues) == 1
        assert character_issues[0].issue_type == IssueType.CHARACTER

    def test_filter_issues_by_severity(self, temp_project_dir, sample_issues):
        parser = ContinuityParser(str(temp_project_dir))
        report = parser.generate_report("test_novel", sample_issues)

        critical = parser.filter_issues_by_severity(report, Severity.CRITICAL)
        major = parser.filter_issues_by_severity(report, Severity.MAJOR)
        minor = parser.filter_issues_by_severity(report, Severity.MINOR)

        assert len(critical) == 1
        assert len(major) == 1
        assert len(minor) == 1

    def test_get_critical_issues(self, temp_project_dir, sample_issues):
        parser = ContinuityParser(str(temp_project_dir))
        report = parser.generate_report("test_novel", sample_issues)

        critical = parser.get_critical_issues(report)

        assert len(critical) == 1
        assert critical[0].severity == Severity.CRITICAL

    def test_get_major_issues(self, temp_project_dir, sample_issues):
        parser = ContinuityParser(str(temp_project_dir))
        report = parser.generate_report("test_novel", sample_issues)

        major = parser.get_major_issues(report)

        assert len(major) == 1
        assert major[0].severity == Severity.MAJOR

    def test_get_minor_issues(self, temp_project_dir, sample_issues):
        parser = ContinuityParser(str(temp_project_dir))
        report = parser.generate_report("test_novel", sample_issues)

        minor = parser.get_minor_issues(report)

        assert len(minor) == 1
        assert minor[0].severity == Severity.MINOR

    def test_empty_report(self, temp_project_dir):
        parser = ContinuityParser(str(temp_project_dir))
        report = parser.generate_report("test_novel", [])

        assert report.total_issues == 0
        assert report.critical_count == 0
        assert report.major_count == 0
        assert report.minor_count == 0
        assert report.status == ReportStatus.PASS

    def test_report_with_all_critical(self, temp_project_dir):
        parser = ContinuityParser(str(temp_project_dir))

        issues = [
            ContinuityIssue(
                issue_type=IssueType.CHARACTER,
                severity=Severity.CRITICAL,
                description=f"Critical issue {i}",
                location=None,
                suggestion=None,
            )
            for i in range(5)
        ]

        report = parser.generate_report("test_novel", issues)

        assert report.total_issues == 5
        assert report.critical_count == 5
        assert report.status == ReportStatus.FAIL


class TestContinuityIssue:
    def test_issue_creation(self):
        issue = ContinuityIssue(
            issue_type=IssueType.CHARACTER,
            severity=Severity.CRITICAL,
            description="Test issue",
            location="Chapter 1",
            suggestion="Fix it",
        )

        assert issue.issue_type == IssueType.CHARACTER
        assert issue.severity == Severity.CRITICAL
        assert issue.description == "Test issue"
        assert issue.location == "Chapter 1"
        assert issue.suggestion == "Fix it"

    def test_issue_with_optional_fields(self):
        issue = ContinuityIssue(
            issue_type=IssueType.PLOT, severity=Severity.MAJOR, description="Test issue"
        )

        assert issue.location is None
        assert issue.suggestion is None


class TestContinuityParserMarkdownParsing:
    """Test markdown parsing edge cases for full branch coverage."""

    def test_parse_level2_issue_headers(self, temp_project_dir):
        """Test parsing with ## headers covering all severity branches (lines 83-89, 118-127)."""
        report_content = (
            "# Continuity Report: Test Novel\n\n"
            "## Issue 1\n"
            "- **Type:** world\n"
            "- **Severity:** critical\n"
            "**Description:** First issue\n\n"
            "## Issue 2\n"
            "- **Type:** plot\n"
            "- **Severity:** major\n"
            "**Description:** Second issue\n\n"
            "## Issue 3\n"
            "- **Type:** character\n"
            "- **Severity:** minor\n"
            "**Description:** Third issue\n\n"
            "## Issue 4\n"
            "- **Type:** timeline\n"
            "- **Severity:** major\n"
            "**Description:** Fourth issue\n"
        )
        report_file = temp_project_dir / "continuity_report.md"
        report_file.write_text(report_content)

        parser = ContinuityParser(str(temp_project_dir))
        report = parser.parse_report()

        assert report.total_issues == 4
        assert report.critical_count == 1
        assert report.major_count == 2
        assert report.minor_count == 1

    def test_parse_fields_before_issue_header(self, temp_project_dir):
        """Test Type/Severity/Location/Description/Suggestion before any issue header."""
        report_content = (
            "# Continuity Report: Test Novel\n\n"
            "- **Type:** character\n"
            "- **Severity:** major\n"
            "- **Location:** Chapter 1\n"
            "**Description:** Orphan field\n"
            "**Suggestion:** No context\n\n"
            "## Issue 1\n"
            "- **Type:** plot\n"
            "- **Severity:** minor\n"
            "**Description:** Real issue\n"
        )
        report_file = temp_project_dir / "continuity_report.md"
        report_file.write_text(report_content)

        parser = ContinuityParser(str(temp_project_dir))
        report = parser.parse_report()

        assert report.total_issues == 1
        assert report.minor_count == 1

    def test_save_report_creates_parent_dirs(self, temp_project_dir):
        """Test save_report creates parent directories (line 183)."""
        parser = ContinuityParser(str(temp_project_dir))
        issues = [
            ContinuityIssue(
                issue_type=IssueType.CHARACTER,
                severity=Severity.MINOR,
                description="Test",
            )
        ]
        report = parser.generate_report("test_novel", issues)
        output = str(temp_project_dir / "deep" / "nested" / "report.md")
        result = parser.save_report(report, output)
        assert Path(result).exists()

    def test_save_report_with_suggestions(self, temp_project_dir):
        """Test save_report includes suggestions (lines 213-214)."""
        parser = ContinuityParser(str(temp_project_dir))
        issues = [
            ContinuityIssue(
                issue_type=IssueType.CHARACTER,
                severity=Severity.MINOR,
                description="Test issue",
                suggestion="Fix this suggestion",
            )
        ]
        report = parser.generate_report("test_novel", issues)
        output = parser.save_report(report)
        content = Path(output).read_text()
        assert "Fix this suggestion" in content

    def test_save_report_no_issues(self, temp_project_dir):
        """Test save_report with empty issues shows no-issues message (lines 217-219)."""
        parser = ContinuityParser(str(temp_project_dir))
        report = parser.generate_report("test_novel", [])
        output = parser.save_report(report)
        content = Path(output).read_text()
        assert "No issues found" in content

    def test_parse_report_custom_path(self, temp_project_dir):
        """Test parsing report from a custom file path."""
        custom_report = temp_project_dir / "custom_report.md"
        custom_report.write_text(
            "# Continuity Report: Custom\n\n"
            "## Issue 1\n"
            "- **Type:** world\n"
            "- **Severity:** minor\n"
            "**Description:** Test\n"
        )

        parser = ContinuityParser(str(temp_project_dir))
        report = parser.parse_report(str(custom_report))
        assert report.total_issues == 1
        assert report.project_name == temp_project_dir.name

    def test_parse_report_no_issues_end_of_loop(self, temp_project_dir):
        """Test parsing report with no ## issue headers (line 118 False branch)."""
        report_content = "# Continuity Report: Empty\n\nJust a header, no issues.\n"
        report_file = temp_project_dir / "continuity_report.md"
        report_file.write_text(report_content)

        parser = ContinuityParser(str(temp_project_dir))
        report = parser.parse_report()
        assert report.total_issues == 0

    def test_parse_report_critical_last_issue(self, temp_project_dir):
        """Test parsing where last issue is critical (line 121)."""
        report_content = (
            "# Continuity Report\n\n"
            "## Issue 1\n"
            "- **Severity:** minor\n"
            "**Description:** Minor issue\n\n"
            "## Issue 2\n"
            "- **Severity:** critical\n"
            "**Description:** Critical issue\n"
        )
        report_file = temp_project_dir / "continuity_report.md"
        report_file.write_text(report_content)

        parser = ContinuityParser(str(temp_project_dir))
        report = parser.parse_report()
        assert report.critical_count == 1
        assert report.minor_count == 1
