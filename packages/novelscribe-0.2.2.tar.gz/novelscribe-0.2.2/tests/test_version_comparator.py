from unittest.mock import MagicMock, patch

from core.version_comparator import DiffReport, SectionChange, VersionComparator, VersionDiff


def _comparator():
    with patch("core.version_comparator.DraftManager") as dm:
        manager = MagicMock()
        dm.return_value = manager
        comp = VersionComparator("/tmp/project")
    return comp, manager


def test_models_basic():
    c = SectionChange(section_type="added", content="x", location="loc")
    assert c.section_type == "added"
    d = VersionDiff(
        from_version=1, to_version=2, chapter_number=1, word_count_change=10, similarity_score=0.5
    )
    r = DiffReport(version_diff=d, summary="ok")
    assert r.summary == "ok"


def test_compare_versions_and_similarity_and_sections():
    comp, manager = _comparator()
    manager.get_version_content.side_effect = [
        'John said "hi".\n\nIn a room.',
        'John said "hi".\n\nIn a city.',
    ]
    diff = comp.compare_versions(1, 1, 2)
    assert diff.chapter_number == 1
    assert diff.word_count_change != 0 or diff.similarity_score >= 0
    assert isinstance(diff.sections_added, list)


def test_compare_versions_missing_raises():
    comp, manager = _comparator()
    manager.get_version_content.side_effect = [None, "x"]
    raised = False
    try:
        comp.compare_versions(1, 1, 2)
    except ValueError:
        raised = True
    assert raised is True


def test_internal_extractors_and_preservations():
    comp, _ = _comparator()
    assert '"a"' in comp._extract_dialogue('x "a" y')
    names = comp._extract_character_names("John met Sarah")
    assert "John" in names or "Sarah" in names
    scenes = comp._extract_scene_descriptions("They walked into the forest road")
    assert "forest" in scenes or "road" in scenes
    pres = comp._find_key_preservations('John said "hi" in a room', 'John said "hi" in a city room')
    assert isinstance(pres, list)


def test_generate_report_recommendations_and_quality_impact():
    comp, manager = _comparator()
    manager.get_version_content.side_effect = [
        "A short text",
        "Completely different content with many additional words and changed structure",
    ]
    report = comp.generate_diff_report(2, 1, 2)
    assert isinstance(report, DiffReport)
    assert isinstance(report.recommendations, list)
    assert isinstance(report.quality_impact, str)


def test_compare_all_versions_and_progression():
    comp, manager = _comparator()
    v1 = MagicMock(version=1)
    v2 = MagicMock(version=2)
    v3 = MagicMock(version=3)
    manager.list_versions.return_value = [v1, v2, v3]
    manager.get_version_content.side_effect = [
        "one",
        "one two",
        "one two",
        "one two three",
        "one",
        "one two",
        "one two",
        "one two three",
    ]
    diffs = comp.compare_all_versions(5)
    assert len(diffs) == 2
    prog = comp.get_version_progression(5)
    assert prog["total_changes"] == 2
    assert prog["versions"] == [1, 2, 3]


def test_progression_no_versions():
    comp, manager = _comparator()
    manager.list_versions.return_value = []
    prog = comp.get_version_progression(7)
    assert prog["total_changes"] == 0
    assert prog["versions"] == []


def test_private_helpers_summary_reco_quality():
    comp, _ = _comparator()
    diff = VersionDiff(
        from_version=1,
        to_version=2,
        chapter_number=1,
        word_count_change=700,
        similarity_score=0.2,
        sections_added=[SectionChange(section_type="added", content="x", location="l")] * 11,
        sections_removed=[SectionChange(section_type="removed", content="x", location="l")] * 6,
    )
    summary = comp._generate_summary(diff)
    rec = comp._generate_recommendations(diff)
    impact = comp._assess_quality_impact(diff)
    assert "Chapter 1" in summary
    assert len(rec) >= 1
    assert "Major impact" in impact or "Significant impact" in impact


def test_similarity_and_similar_paragraph_helpers():
    comp, _ = _comparator()
    assert comp._calculate_similarity("", "x") == 0.0
    assert comp._calculate_similarity("a b", "a b") == 1.0
    found = comp._find_similar_paragraph("alpha beta", ["alpha gamma", "delta"])
    assert found == "alpha gamma" or found is None
    not_found = comp._find_similar_paragraph("zzz", ["aaa bbb", "ccc"])
    assert not_found is None


def test_recommendations_minimal_change_branch_and_quality_levels():
    comp, _ = _comparator()
    diff = VersionDiff(
        from_version=1,
        to_version=2,
        chapter_number=2,
        word_count_change=10,
        similarity_score=0.9,
    )
    rec = comp._generate_recommendations(diff)
    assert any("Minimal changes detected" in r for r in rec)
    assert "Minor impact" in comp._assess_quality_impact(diff)
    diff2 = VersionDiff(
        from_version=1,
        to_version=2,
        chapter_number=2,
        word_count_change=0,
        similarity_score=0.6,
    )
    assert "Moderate impact" in comp._assess_quality_impact(diff2)
