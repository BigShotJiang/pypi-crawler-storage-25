"""
Tests for CLI pagination commands
"""

from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from cli_pagination import (
    cache,
    paginate,
)


class TestPaginateGroup:
    """Test cases for paginate command group"""

    def test_paginate_group_exists(self):
        """Test that paginate command group exists"""
        assert paginate is not None

    def test_paginate_help(self):
        """Test paginate command help"""
        runner = CliRunner()
        result = runner.invoke(paginate, ["--help"])

        assert result.exit_code == 0
        assert "paginate" in result.output.lower()

    def test_paginate_chapter_command_exists(self):
        """Test that chapter subcommand exists"""
        runner = CliRunner()
        result = runner.invoke(paginate, ["chapter", "--help"])

        assert result.exit_code == 0
        assert "chapter" in result.output.lower()

    def test_paginate_index_command_exists(self):
        """Test that index subcommand exists"""
        runner = CliRunner()
        result = runner.invoke(paginate, ["index", "--help"])

        assert result.exit_code == 0
        assert "index" in result.output.lower()

    def test_paginate_get_range_command_exists(self):
        """Test that get-range subcommand exists"""
        runner = CliRunner()
        result = runner.invoke(paginate, ["get-range", "--help"])

        assert result.exit_code == 0

    def test_paginate_search_command_exists(self):
        """Test that search subcommand exists"""
        runner = CliRunner()
        result = runner.invoke(paginate, ["search", "--help"])

        assert result.exit_code == 0
        assert "search" in result.output.lower()

    def test_paginate_estimate_command_exists(self):
        """Test that estimate subcommand exists"""
        runner = CliRunner()
        result = runner.invoke(paginate, ["estimate", "--help"])

        assert result.exit_code == 0
        assert "estimate" in result.output.lower()


class TestChapterCommand:
    """Test cases for chapter command"""

    def test_chapter_missing_project_name(self):
        """Test chapter command without project name"""
        runner = CliRunner()
        result = runner.invoke(paginate, ["chapter"])

        assert result.exit_code != 0

    def test_chapter_project_not_found(self):
        """Test chapter command with non-existent project"""
        runner = CliRunner()

        with patch("cli_pagination.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = False
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(paginate, ["chapter", "nonexistent-project"])

            assert result.exit_code == 1

    def test_chapter_with_chapter_file_not_found(self):
        """Test chapter command with specific chapter that doesn't exist"""
        runner = CliRunner()

        with patch("cli_pagination.Path") as mock_path, patch("cli_pagination.ChapterPaginator"):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_chapters_dir = MagicMock()
            mock_chapters_dir.exists.return_value = False

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_chapters_dir]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(paginate, ["chapter", "test-project", "--chapter", "5"])

            assert result.exit_code in [0, 1]

    def test_chapter_with_default_options(self):
        """Test chapter command with default options"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.ChapterPaginator") as mock_paginator_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_project_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_page = MagicMock()
            mock_page.page_number = 1
            mock_page.word_count = 500
            mock_page.token_count = 750

            mock_paginator = MagicMock()
            mock_paginator.paginate_chapter.return_value = [mock_page]
            mock_paginator_class.return_value = mock_paginator

            result = runner.invoke(paginate, ["chapter", "test-project"])

            assert result.exit_code in [0, 1]

    def test_chapter_with_chapter_option(self):
        """Test chapter command with chapter option"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.ChapterPaginator") as mock_paginator_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_chapters_dir = MagicMock()
            mock_chapters_dir.exists.return_value = True

            mock_chapter_file = MagicMock()
            mock_chapter_file.exists.return_value = True
            mock_chapter_file.read_text.return_value = "Test chapter content"

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[
                    mock_project_path,
                    mock_chapters_dir,
                    mock_chapters_dir,
                    mock_chapter_file,
                ]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_page = MagicMock()
            mock_page.page_number = 1
            mock_page.word_count = 300
            mock_page.token_count = 450

            mock_paginator = MagicMock()
            mock_paginator.paginate_chapter.return_value = [mock_page]
            mock_paginator_class.return_value = mock_paginator

            result = runner.invoke(paginate, ["chapter", "test-project", "--chapter", "3"])

            assert result.exit_code in [0, 1]

    def test_chapter_with_strategy_token(self):
        """Test chapter command with token strategy"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.ChapterPaginator") as mock_paginator_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_project_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_paginator = MagicMock()
            mock_paginator.paginate_chapter.return_value = []
            mock_paginator_class.return_value = mock_paginator

            result = runner.invoke(paginate, ["chapter", "test-project", "--strategy", "token"])

            assert result.exit_code in [0, 1]

    def test_chapter_with_strategy_scene(self):
        """Test chapter command with scene strategy"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.ChapterPaginator") as mock_paginator_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_project_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_paginator = MagicMock()
            mock_paginator.paginate_chapter.return_value = []
            mock_paginator_class.return_value = mock_paginator

            result = runner.invoke(paginate, ["chapter", "test-project", "--strategy", "scene"])

            assert result.exit_code in [0, 1]

    def test_chapter_with_strategy_paragraph(self):
        """Test chapter command with paragraph strategy"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.ChapterPaginator") as mock_paginator_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_project_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_paginator = MagicMock()
            mock_paginator.paginate_chapter.return_value = []
            mock_paginator_class.return_value = mock_paginator

            result = runner.invoke(paginate, ["chapter", "test-project", "--strategy", "paragraph"])

            assert result.exit_code in [0, 1]

    def test_chapter_with_strategy_semantic(self):
        """Test chapter command with semantic strategy"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.ChapterPaginator") as mock_paginator_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_project_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_paginator = MagicMock()
            mock_paginator.paginate_chapter.return_value = []
            mock_paginator_class.return_value = mock_paginator

            result = runner.invoke(paginate, ["chapter", "test-project", "--strategy", "semantic"])

            assert result.exit_code in [0, 1]

    def test_chapter_with_target_tokens(self):
        """Test chapter command with target_tokens option"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.ChapterPaginator") as mock_paginator_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_project_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_paginator = MagicMock()
            mock_paginator.paginate_chapter.return_value = []
            mock_paginator_class.return_value = mock_paginator

            result = runner.invoke(paginate, ["chapter", "test-project", "--target-tokens", "3000"])

            assert result.exit_code in [0, 1]

    def test_chapter_with_overlap_tokens(self):
        """Test chapter command with overlap_tokens option"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.ChapterPaginator") as mock_paginator_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_project_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_paginator = MagicMock()
            mock_paginator.paginate_chapter.return_value = []
            mock_paginator_class.return_value = mock_paginator

            result = runner.invoke(paginate, ["chapter", "test-project", "--overlap-tokens", "300"])

            assert result.exit_code in [0, 1]

    def test_chapter_with_exception(self):
        """Test chapter command with exception"""
        runner = CliRunner()

        with patch("cli_pagination.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.side_effect = Exception("Test error")
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(paginate, ["chapter", "test-project"])

            assert result.exit_code == 1


class TestIndexCommand:
    """Test cases for index command"""

    def test_index_missing_project_name(self):
        """Test index command without project name"""
        runner = CliRunner()
        result = runner.invoke(paginate, ["index"])

        assert result.exit_code != 0

    def test_index_project_not_found(self):
        """Test index command with non-existent project"""
        runner = CliRunner()

        with patch("cli_pagination.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = False
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(paginate, ["index", "nonexistent-project"])

            assert result.exit_code == 1

    def test_index_success(self):
        """Test index command success"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.MultiChapterManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_project_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_manager = MagicMock()
            mock_manager.build_index.return_value = 10
            mock_manager.get_project_statistics.return_value = {
                "total_chapters": 10,
                "total_words": 50000,
                "total_tokens": 75000,
                "total_pages": 100,
            }
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(paginate, ["index", "test-project"])

            assert result.exit_code in [0, 1]

    def test_index_with_max_chapters(self):
        """Test index command with max_chapters option"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.MultiChapterManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_project_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_manager = MagicMock()
            mock_manager.build_index.return_value = 15
            mock_manager.get_project_statistics.return_value = {
                "total_chapters": 15,
                "total_words": 75000,
                "total_tokens": 110000,
                "total_pages": 150,
            }
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(paginate, ["index", "test-project", "--max-chapters", "15"])

            assert result.exit_code in [0, 1]

    def test_index_with_prefetch_count(self):
        """Test index command with prefetch_count option"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.MultiChapterManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_project_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_manager = MagicMock()
            mock_manager.build_index.return_value = 8
            mock_manager.get_project_statistics.return_value = {
                "total_chapters": 8,
                "total_words": 40000,
                "total_tokens": 60000,
                "total_pages": 80,
            }
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(paginate, ["index", "test-project", "--prefetch-count", "5"])

            assert result.exit_code in [0, 1]

    def test_index_with_exception(self):
        """Test index command with exception"""
        runner = CliRunner()

        with patch("cli_pagination.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.side_effect = Exception("Test error")
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(paginate, ["index", "test-project"])

            assert result.exit_code == 1


class TestGetRangeCommand:
    """Test cases for get-range command"""

    def test_get_range_missing_project_name(self):
        """Test get-range command without project name"""
        runner = CliRunner()
        result = runner.invoke(paginate, ["get-range"])

        assert result.exit_code != 0

    def test_get_range_missing_start(self):
        """Test get-range command without start option"""
        runner = CliRunner()
        result = runner.invoke(paginate, ["get-range", "test-project", "--end", "5"])

        assert result.exit_code != 0

    def test_get_range_missing_end(self):
        """Test get-range command without end option"""
        runner = CliRunner()
        result = runner.invoke(paginate, ["get-range", "test-project", "--start", "1"])

        assert result.exit_code != 0

    def test_get_range_project_not_found(self):
        """Test get-range command with non-existent project"""
        runner = CliRunner()

        with patch("cli_pagination.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = False
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(
                paginate, ["get-range", "test-project", "--start", "1", "--end", "5"]
            )

            assert result.exit_code == 1

    def test_get_range_success(self):
        """Test get-range command success"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.MultiChapterManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_page = MagicMock()
            mock_page.chapter_number = 1
            mock_page.page_number = 1
            mock_page.word_count = 500

            mock_manager = MagicMock()
            mock_manager.build_index.return_value = 5
            mock_manager.get_chapter_range.return_value = [mock_page]
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(
                paginate, ["get-range", "test-project", "--start", "1", "--end", "5"]
            )

            assert result.exit_code in [0, 1]

    def test_get_range_with_max_pages(self):
        """Test get-range command with max_pages option"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.MultiChapterManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_page = MagicMock()
            mock_page.chapter_number = 2
            mock_page.page_number = 1
            mock_page.word_count = 600

            mock_manager = MagicMock()
            mock_manager.build_index.return_value = 3
            mock_manager.get_chapter_range.return_value = [mock_page]
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(
                paginate,
                ["get-range", "test-project", "--start", "1", "--end", "3", "--max-pages", "3"],
            )

            assert result.exit_code in [0, 1]

    def test_get_range_with_exception(self):
        """Test get-range command with exception"""
        runner = CliRunner()

        with patch("cli_pagination.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.side_effect = Exception("Test error")
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(
                paginate, ["get-range", "test-project", "--start", "1", "--end", "5"]
            )

            assert result.exit_code == 1


class TestSearchCommand:
    """Test cases for search command"""

    def test_search_missing_project_name(self):
        """Test search command without project name"""
        runner = CliRunner()
        result = runner.invoke(paginate, ["search"])

        assert result.exit_code != 0

    def test_search_missing_query(self):
        """Test search command without query option"""
        runner = CliRunner()
        result = runner.invoke(paginate, ["search", "test-project"])

        assert result.exit_code != 0

    def test_search_project_not_found(self):
        """Test search command with non-existent project"""
        runner = CliRunner()

        with patch("cli_pagination.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = False
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(paginate, ["search", "test-project", "--query", "test"])

            assert result.exit_code == 1

    def test_search_success(self):
        """Test search command success"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.MultiChapterManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_manager = MagicMock()
            mock_manager.build_index.return_value = 10
            mock_manager.search_chapters.return_value = ["result1", "result2"]
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(
                paginate, ["search", "test-project", "--query", "character development"]
            )

            assert result.exit_code in [0, 1]

    def test_search_with_limit(self):
        """Test search command with limit option"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.MultiChapterManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_manager = MagicMock()
            mock_manager.build_index.return_value = 10
            mock_manager.search_chapters.return_value = ["result1", "result2", "result3"]
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(
                paginate, ["search", "test-project", "--query", "plot", "--limit", "20"]
            )

            assert result.exit_code in [0, 1]

    def test_search_with_exception(self):
        """Test search command with exception"""
        runner = CliRunner()

        with patch("cli_pagination.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.side_effect = Exception("Test error")
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(paginate, ["search", "test-project", "--query", "test"])

            assert result.exit_code == 1


class TestEstimateCommand:
    """Test cases for estimate command"""

    def test_estimate_missing_text(self):
        """Test estimate command without text"""
        runner = CliRunner()
        result = runner.invoke(paginate, ["estimate"])

        assert result.exit_code != 0

    def test_estimate_with_provider_openai(self):
        """Test estimate command with OpenAI provider"""
        runner = CliRunner()

        with (
            patch("cli_pagination.TokenEstimator") as mock_estimator_class,
            patch("cli_pagination.ContextManager") as mock_context_manager_class,
        ):
            mock_estimator = MagicMock()
            mock_estimator.estimate_tokens.return_value = 100
            mock_estimator_class.return_value = mock_estimator

            mock_context_manager = MagicMock()
            mock_context_manager.window.utilization_rate = 0.5
            mock_context_manager.window.available_tokens = 5000
            mock_context_manager.allocate_context.return_value = 2000
            mock_context_manager_class.return_value = mock_context_manager

            result = runner.invoke(
                paginate, ["estimate", "Test text to estimate", "--provider", "openai"]
            )

            assert result.exit_code in [0, 1]

    def test_estimate_with_provider_claude(self):
        """Test estimate command with Claude provider"""
        runner = CliRunner()

        with (
            patch("cli_pagination.TokenEstimator") as mock_estimator_class,
            patch("cli_pagination.ContextManager") as mock_context_manager_class,
        ):
            mock_estimator = MagicMock()
            mock_estimator.estimate_tokens.return_value = 150
            mock_estimator_class.return_value = mock_estimator

            mock_context_manager = MagicMock()
            mock_context_manager.window.utilization_rate = 0.6
            mock_context_manager.window.available_tokens = 8000
            mock_context_manager.allocate_context.return_value = 3000
            mock_context_manager_class.return_value = mock_context_manager

            result = runner.invoke(
                paginate, ["estimate", "Test text to estimate", "--provider", "claude"]
            )

            assert result.exit_code in [0, 1]

    def test_estimate_with_provider_gemini(self):
        """Test estimate command with Gemini provider"""
        runner = CliRunner()

        with (
            patch("cli_pagination.TokenEstimator") as mock_estimator_class,
            patch("cli_pagination.ContextManager") as mock_context_manager_class,
        ):
            mock_estimator = MagicMock()
            mock_estimator.estimate_tokens.return_value = 200
            mock_estimator_class.return_value = mock_estimator

            mock_context_manager = MagicMock()
            mock_context_manager.window.utilization_rate = 0.7
            mock_context_manager.window.available_tokens = 10000
            mock_context_manager.allocate_context.return_value = 4000
            mock_context_manager_class.return_value = mock_context_manager

            result = runner.invoke(
                paginate, ["estimate", "Test text to estimate", "--provider", "gemini"]
            )

            assert result.exit_code in [0, 1]

    def test_estimate_with_strategy_full(self):
        """Test estimate command with full context strategy"""
        runner = CliRunner()

        with (
            patch("cli_pagination.TokenEstimator") as mock_estimator_class,
            patch("cli_pagination.ContextManager") as mock_context_manager_class,
        ):
            mock_estimator = MagicMock()
            mock_estimator.estimate_tokens.return_value = 120
            mock_estimator_class.return_value = mock_estimator

            mock_context_manager = MagicMock()
            mock_context_manager.window.utilization_rate = 0.55
            mock_context_manager.window.available_tokens = 6000
            mock_context_manager.allocate_context.return_value = 2500
            mock_context_manager_class.return_value = mock_context_manager

            result = runner.invoke(
                paginate,
                ["estimate", "Test text to estimate", "--strategy", "full"],
            )

            assert result.exit_code in [0, 1]

    def test_estimate_with_strategy_sliding(self):
        """Test estimate command with sliding window strategy"""
        runner = CliRunner()

        with (
            patch("cli_pagination.TokenEstimator") as mock_estimator_class,
            patch("cli_pagination.ContextManager") as mock_context_manager_class,
        ):
            mock_estimator = MagicMock()
            mock_estimator.estimate_tokens.return_value = 180
            mock_estimator_class.return_value = mock_estimator

            mock_context_manager = MagicMock()
            mock_context_manager.window.utilization_rate = 0.65
            mock_context_manager.window.available_tokens = 7000
            mock_context_manager.allocate_context.return_value = 3500
            mock_context_manager_class.return_value = mock_context_manager

            result = runner.invoke(
                paginate,
                ["estimate", "Test text to estimate", "--strategy", "sliding"],
            )

            assert result.exit_code in [0, 1]

    def test_estimate_with_strategy_summarization(self):
        """Test estimate command with summarization strategy"""
        runner = CliRunner()

        with (
            patch("cli_pagination.TokenEstimator") as mock_estimator_class,
            patch("cli_pagination.ContextManager") as mock_context_manager_class,
        ):
            mock_estimator = MagicMock()
            mock_estimator.estimate_tokens.return_value = 140
            mock_estimator_class.return_value = mock_estimator

            mock_context_manager = MagicMock()
            mock_context_manager.window.utilization_rate = 0.58
            mock_context_manager.window.available_tokens = 6500
            mock_context_manager.allocate_context.return_value = 2800
            mock_context_manager_class.return_value = mock_context_manager

            result = runner.invoke(
                paginate,
                ["estimate", "Test text to estimate", "--strategy", "summarization"],
            )

            assert result.exit_code in [0, 1]

    def test_estimate_with_strategy_hybrid(self):
        """Test estimate command with hybrid strategy"""
        runner = CliRunner()

        with (
            patch("cli_pagination.TokenEstimator") as mock_estimator_class,
            patch("cli_pagination.ContextManager") as mock_context_manager_class,
        ):
            mock_estimator = MagicMock()
            mock_estimator.estimate_tokens.return_value = 160
            mock_estimator_class.return_value = mock_estimator

            mock_context_manager = MagicMock()
            mock_context_manager.window.utilization_rate = 0.62
            mock_context_manager.window.available_tokens = 7200
            mock_context_manager.allocate_context.return_value = 3200
            mock_context_manager_class.return_value = mock_context_manager

            result = runner.invoke(
                paginate,
                ["estimate", "Test text to estimate", "--strategy", "hybrid"],
            )

            assert result.exit_code in [0, 1]

    def test_estimate_with_exception(self):
        """Test estimate command with exception"""
        runner = CliRunner()

        with patch("cli_pagination.TokenEstimator") as mock_estimator_class:
            mock_estimator = MagicMock()
            mock_estimator.estimate_tokens.side_effect = Exception("Estimate error")
            mock_estimator_class.return_value = mock_estimator

            result = runner.invoke(paginate, ["estimate", "Test text"])

            assert result.exit_code == 1


class TestCacheGroup:
    """Test cases for cache command group"""

    def test_cache_group_exists(self):
        """Test that cache command group exists"""
        assert cache is not None

    def test_cache_help(self):
        """Test cache command help"""
        runner = CliRunner()
        result = runner.invoke(cache, ["--help"])

        assert result.exit_code == 0
        assert "cache" in result.output.lower()

    def test_cache_warm_command_exists(self):
        """Test that warm subcommand exists"""
        runner = CliRunner()
        result = runner.invoke(cache, ["warm", "--help"])

        assert result.exit_code == 0
        assert "warm" in result.output.lower()

    def test_cache_stats_command_exists(self):
        """Test that stats subcommand exists"""
        runner = CliRunner()
        result = runner.invoke(cache, ["stats", "--help"])

        assert result.exit_code == 0
        assert "stats" in result.output.lower()

    def test_cache_clear_command_exists(self):
        """Test that clear subcommand exists"""
        runner = CliRunner()
        result = runner.invoke(cache, ["clear", "--help"])

        assert result.exit_code == 0
        assert "clear" in result.output.lower()


class TestWarmCommand:
    """Test cases for warm command"""

    def test_warm_missing_project_name(self):
        """Test warm command without project name"""
        runner = CliRunner()
        result = runner.invoke(cache, ["warm"])

        assert result.exit_code != 0

    def test_warm_project_not_found(self):
        """Test warm command with non-existent project"""
        runner = CliRunner()

        with patch("cli_pagination.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = False
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(cache, ["warm", "nonexistent-project"])

            assert result.exit_code == 1

    def test_warm_success(self):
        """Test warm command success"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.ContextCache") as mock_cache_class,
            patch("cli_pagination.CachedChapterManager") as mock_cached_manager_class,
            patch("cli_pagination.MultiChapterManager") as mock_multi_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_project_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_cache = MagicMock()
            mock_cache.get_statistics.return_value = {
                "hits": 10,
                "current_size_mb": 50.5,
                "utilization_percent": 50.5,
            }
            mock_cache_class.return_value = mock_cache

            mock_cached_manager = MagicMock()
            mock_cached_manager_class.return_value = mock_cached_manager

            mock_multi_manager = MagicMock()
            mock_multi_manager.build_index.return_value = 5
            mock_multi_manager.chapter_references = [1, 2, 3, 4, 5]
            mock_multi_manager_class.return_value = mock_multi_manager

            result = runner.invoke(cache, ["warm", "test-project"])

            assert result.exit_code in [0, 1]

    def test_warm_with_max_size_mb(self):
        """Test warm command with max_size_mb option"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.ContextCache") as mock_cache_class,
            patch("cli_pagination.CachedChapterManager") as mock_cached_manager_class,
            patch("cli_pagination.MultiChapterManager") as mock_multi_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_project_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_cache = MagicMock()
            mock_cache.get_statistics.return_value = {
                "hits": 15,
                "current_size_mb": 150.0,
                "utilization_percent": 75.0,
            }
            mock_cache_class.return_value = mock_cache

            mock_cached_manager = MagicMock()
            mock_cached_manager_class.return_value = mock_cached_manager

            mock_multi_manager = MagicMock()
            mock_multi_manager.build_index.return_value = 8
            mock_multi_manager.chapter_references = [1, 2, 3, 4, 5, 6, 7, 8]
            mock_multi_manager_class.return_value = mock_multi_manager

            result = runner.invoke(cache, ["warm", "test-project", "--max-size-mb", "200"])

            assert result.exit_code in [0, 1]

    def test_warm_with_max_entries(self):
        """Test warm command with max_entries option"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.ContextCache") as mock_cache_class,
            patch("cli_pagination.CachedChapterManager") as mock_cached_manager_class,
            patch("cli_pagination.MultiChapterManager") as mock_multi_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_project_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_cache = MagicMock()
            mock_cache.get_statistics.return_value = {
                "hits": 12,
                "current_size_mb": 80.0,
                "utilization_percent": 60.0,
            }
            mock_cache_class.return_value = mock_cache

            mock_cached_manager = MagicMock()
            mock_cached_manager_class.return_value = mock_cached_manager

            mock_multi_manager = MagicMock()
            mock_multi_manager.build_index.return_value = 6
            mock_multi_manager.chapter_references = [1, 2, 3, 4, 5, 6]
            mock_multi_manager_class.return_value = mock_multi_manager

            result = runner.invoke(cache, ["warm", "test-project", "--max-entries", "150"])

            assert result.exit_code in [0, 1]

    def test_warm_with_exception(self):
        """Test warm command with exception"""
        runner = CliRunner()

        with patch("cli_pagination.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.side_effect = Exception("Test error")
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(cache, ["warm", "test-project"])

            assert result.exit_code == 1


class TestStatsCommand:
    """Test cases for stats command"""

    def test_stats_missing_project_name(self):
        """Test stats command without project name"""
        runner = CliRunner()
        result = runner.invoke(cache, ["stats"])

        assert result.exit_code != 0

    def test_stats_project_not_found(self):
        """Test stats command with non-existent project"""
        runner = CliRunner()

        with patch("cli_pagination.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = False
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(cache, ["stats", "nonexistent-project"])

            assert result.exit_code == 1

    def test_stats_success(self):
        """Test stats command success"""
        runner = CliRunner()

        with (
            patch("cli_pagination.Path") as mock_path,
            patch("cli_pagination.ContextCache") as mock_cache_class,
            patch("cli_pagination.CachedChapterManager") as mock_cached_manager_class,
            patch("cli_pagination.MultiChapterManager") as mock_multi_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_project_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_cache = MagicMock()
            mock_cache.get_statistics.return_value = {
                "total_requests": 100,
                "hits": 80,
                "misses": 20,
                "hit_rate": "80%",
                "evictions": 5,
                "current_entries": 15,
                "current_size_mb": 75.5,
                "utilization_percent": 75.5,
            }
            mock_cache_class.return_value = mock_cache

            mock_cached_manager = MagicMock()
            mock_cached_manager_class.return_value = mock_cached_manager

            mock_multi_manager = MagicMock()
            mock_multi_manager.build_index.return_value = 5
            mock_multi_manager_class.return_value = mock_multi_manager

            result = runner.invoke(cache, ["stats", "test-project"])

            assert result.exit_code in [0, 1]

    def test_stats_with_exception(self):
        """Test stats command with exception"""
        runner = CliRunner()

        with patch("cli_pagination.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.side_effect = Exception("Test error")
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(cache, ["stats", "test-project"])

            assert result.exit_code == 1


class TestClearCommand:
    """Test cases for clear command"""

    def test_clear_missing_project_name(self):
        """Test clear command without project name"""
        runner = CliRunner()
        result = runner.invoke(cache, ["clear"])

        assert result.exit_code != 0

    def test_clear_success(self):
        """Test clear command success"""
        runner = CliRunner()

        with (
            patch("cli_pagination.ContextCache") as mock_cache_class,
            patch("cli_pagination.CachedChapterManager") as mock_cached_manager_class,
        ):
            mock_cache = MagicMock()
            mock_cache_class.return_value = mock_cache

            mock_cached_manager = MagicMock()
            mock_cached_manager_class.return_value = mock_cached_manager

            result = runner.invoke(cache, ["clear", "test-project"])

            assert result.exit_code in [0, 1]

    def test_clear_with_exception(self):
        """Test clear command with exception"""
        runner = CliRunner()

        with (
            patch("cli_pagination.ContextCache") as mock_cache_class,
            patch("cli_pagination.CachedChapterManager") as mock_cached_manager_class,
        ):
            mock_cache = MagicMock()
            mock_cache_class.return_value = mock_cache

            mock_cached_manager = MagicMock()
            mock_cached_manager.invalidate_project.side_effect = Exception("Clear error")
            mock_cached_manager_class.return_value = mock_cached_manager

            result = runner.invoke(cache, ["clear", "test-project"])

            assert result.exit_code == 1
