"""
Comprehensive tests for Parallelism components

Tests cover:
- Agent Execution Queue
- Async Agent Executor
- Phase Parallelizer
"""

import asyncio
import time

import pytest

from core.agent_queue import (
    AgentQueue,
    AgentTask,
    TaskResult,
    TaskStatus,
    get_agent_queue,
    reset_agent_queue,
)
from core.async_executor import (
    AsyncAgentExecutor,
    ExecutionMetrics,
    get_async_executor,
    reset_async_executor,
)


class TestAgentTask:
    """Test suite for AgentTask"""

    def test_task_creation(self):
        """Test creating an agent task"""
        task = AgentTask(task_id="test-1", agent_name="genre_agent", prompt="Analyze sci-fi")

        assert task.task_id == "test-1"
        assert task.agent_name == "genre_agent"
        assert task.prompt == "Analyze sci-fi"
        assert task.priority == 0
        assert task.timeout == 300
        assert task.max_retries == 3
        assert task.dependencies == []

    def test_task_with_dependencies(self):
        """Test task with dependencies"""
        task = AgentTask(
            task_id="test-2",
            agent_name="character_agent",
            prompt="Create hero",
            dependencies=["test-1"],
        )

        assert "test-1" in task.dependencies

    def test_task_priority_comparison(self):
        """Test task priority comparison"""
        task1 = AgentTask(task_id="low", agent_name="agent", prompt="test", priority=1)
        task2 = AgentTask(task_id="high", agent_name="agent", prompt="test", priority=10)

        assert task1 < task2


class TestAgentQueue:
    """Test suite for AgentQueue"""

    @pytest.fixture
    def queue(self):
        """Create fresh queue for each test"""
        reset_agent_queue()
        return AgentQueue(max_concurrent=3)

    @pytest.mark.asyncio
    async def test_queue_initialization(self, queue):
        """Test queue initialization"""
        assert queue.max_concurrent == 3
        assert len(queue.tasks) == 0
        assert len(queue.results) == 0
        assert len(queue.running) == 0

    @pytest.mark.asyncio
    async def test_submit_task(self, queue):
        """Test submitting a task"""
        task = AgentTask(task_id="test-1", agent_name="genre_agent", prompt="Analyze")

        task_id = queue.submit(task)

        assert task_id == "test-1"
        assert "test-1" in queue.tasks
        assert task_id in queue.tasks

    @pytest.mark.asyncio
    async def test_submit_batch(self, queue):
        """Test submitting multiple tasks"""
        tasks = [
            AgentTask(task_id=f"task-{i}", agent_name="agent", prompt=f"task {i}") for i in range(5)
        ]

        task_ids = queue.submit_batch(tasks)

        assert len(task_ids) == 5
        assert all(f"task-{i}" in queue.tasks for i in range(5))

    @pytest.mark.asyncio
    async def test_get_ready_tasks(self, queue):
        """Test getting ready tasks"""
        task1 = AgentTask(task_id="t1", agent_name="a", prompt="p1", priority=1)
        task2 = AgentTask(
            task_id="t2", agent_name="a", prompt="p2", priority=2, dependencies=["t1"]
        )

        queue.submit(task1)
        queue.submit(task2)

        ready = queue.get_ready_tasks()

        assert len(ready) >= 1

    @pytest.mark.asyncio
    async def test_get_ready_tasks_with_dependencies(self, queue):
        """Test getting ready tasks after dependencies complete"""
        task1 = AgentTask(task_id="t1", agent_name="a", prompt="p1")
        task2 = AgentTask(task_id="t2", agent_name="a", prompt="p2", dependencies=["t1"])

        queue.submit(task1)
        queue.submit(task2)

        # Complete task1
        queue.results["t1"] = TaskResult(task_id="t1", agent_name="a", status=TaskStatus.COMPLETED)

        ready = queue.get_ready_tasks()

        assert len(ready) == 1
        assert ready[0].task_id == "t2"

    @pytest.mark.asyncio
    async def test_get_progress(self, queue):
        """Test getting execution progress"""
        task1 = AgentTask(task_id="t1", agent_name="a", prompt="p1")
        task2 = AgentTask(task_id="t2", agent_name="a", prompt="p2")

        queue.submit(task1)
        queue.submit(task2)

        progress = queue.get_progress()

        assert progress["total"] == 2
        assert progress["completed"] == 0
        assert progress["running"] == 0
        assert progress["waiting"] == 2

    @pytest.mark.asyncio
    async def test_execute_simple_task(self, queue):
        """Test executing a simple task"""

        async def mock_executor(name: str, prompt: str, **kwargs):
            await asyncio.sleep(0.1)
            return f"Result for {prompt}"

        task = AgentTask(task_id="test-1", agent_name="test_agent", prompt="test prompt")

        queue.submit(task)
        results = await queue.execute_all(mock_executor)

        assert "test-1" in results
        assert results["test-1"].status == TaskStatus.COMPLETED
        assert results["test-1"].result == "Result for test prompt"

    @pytest.mark.asyncio
    async def test_execute_parallel_tasks(self, queue):
        """Test executing tasks in parallel"""
        execution_times = []

        async def mock_executor(name: str, prompt: str, **kwargs):
            start = time.time()
            await asyncio.sleep(0.2)
            execution_times.append(time.time() - start)
            return f"Done: {prompt}"

        tasks = [
            AgentTask(task_id=f"t{i}", agent_name="agent", prompt=f"task {i}") for i in range(3)
        ]

        start = time.time()
        results = await queue.execute_parallel(tasks, mock_executor)
        total_time = time.time() - start

        assert len(results) == 3
        assert all(r.status == TaskStatus.COMPLETED for r in results.values())

        # Should take ~0.2s (parallel) not 0.6s (sequential)
        assert total_time < 0.5

    @pytest.mark.asyncio
    async def test_task_timeout(self, queue):
        """Test task timeout handling"""

        async def slow_executor(name: str, prompt: str, **kwargs):
            await asyncio.sleep(2)  # Slow

        task = AgentTask(
            task_id="test-timeout",
            agent_name="slow",
            prompt="slow task",
            timeout=0.1,  # Short timeout
        )

        queue.submit(task)
        results = await queue.execute_all(slow_executor)

        assert results["test-timeout"].status == TaskStatus.TIMEOUT
        assert "timed out" in results["test-timeout"].error

    @pytest.mark.asyncio
    async def test_task_error_recovery(self, queue):
        """Test task error recovery with retry"""
        call_count = 0

        async def failing_executor(name: str, prompt: str, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise ValueError("First attempt failed")
            return "Success on retry"

        task = AgentTask(
            task_id="test-retry", agent_name="retry", prompt="retry task", max_retries=3
        )

        queue.submit(task)
        results = await queue.execute_all(failing_executor)

        # Should eventually succeed after retry
        assert results["test-retry"].status == TaskStatus.COMPLETED
        assert call_count >= 2

    @pytest.mark.asyncio
    async def test_priority_execution(self, queue):
        """Test that higher priority tasks execute first"""
        execution_order = []

        async def tracking_executor(name: str, prompt: str, **kwargs):
            execution_order.append(prompt)
            await asyncio.sleep(0.05)
            return f"Done: {prompt}"

        # Add tasks with different priorities
        task1 = AgentTask(task_id="t1", agent_name="a", prompt="low-priority", priority=1)
        task2 = AgentTask(task_id="t2", agent_name="a", prompt="high-priority", priority=10)
        task3 = AgentTask(task_id="t3", agent_name="a", prompt="medium-priority", priority=5)

        queue.submit(task1)
        queue.submit(task2)
        queue.submit(task3)

        await queue.execute_all(tracking_executor)

        # High priority should execute first
        assert execution_order[0] == "high-priority"


class TestAsyncAgentExecutor:
    """Test suite for AsyncAgentExecutor"""

    @pytest.fixture
    def executor(self):
        """Create fresh executor for each test"""
        reset_async_executor()
        return AsyncAgentExecutor(max_concurrent=3)

    def test_executor_initialization(self, executor):
        """Test executor initialization"""
        assert executor.max_concurrent == 3
        assert len(executor.agent_registry) == 0
        assert executor.get_active_count() == 0

    def test_register_agent(self, executor):
        """Test registering an agent"""

        async def mock_agent(prompt, **kwargs):
            return "result"

        executor.register_agent("genre_agent", mock_agent)

        agents = executor.get_registered_agents()
        assert "genre_agent" in agents

    @pytest.mark.asyncio
    async def test_execute_unregistered_agent(self, executor):
        """Test executing unregistered agent raises error"""
        with pytest.raises(ValueError, match="not registered"):
            await executor.execute("unknown_agent", "test")

    @pytest.mark.asyncio
    async def test_execute_single_agent(self, executor):
        """Test executing a single agent"""

        async def mock_agent(prompt, **kwargs):
            await asyncio.sleep(0.1)
            return f"Result: {prompt}"

        executor.register_agent("test_agent", mock_agent)
        result = await executor.execute("test_agent", "test prompt")

        assert result == "Result: test prompt"

    @pytest.mark.asyncio
    async def test_execute_many_parallel(self, executor):
        """Test executing multiple agents in parallel"""
        execution_times = []

        async def mock_agent(prompt, **kwargs):
            start = time.time()
            await asyncio.sleep(0.2)
            execution_times.append(time.time() - start)
            return f"Done: {prompt}"

        executor.register_agent("agent1", mock_agent)
        executor.register_agent("agent2", mock_agent)
        executor.register_agent("agent3", mock_agent)

        start = time.time()
        results = await executor.execute_many(
            [("agent1", "task 1"), ("agent2", "task 2"), ("agent3", "task 3")]
        )
        total_time = time.time() - start

        assert len(results) == 3
        assert total_time < 0.5  # Should be ~0.2s not 0.6s

    @pytest.mark.asyncio
    async def test_execute_with_timeout(self, executor):
        """Test execution timeout"""

        async def slow_agent(prompt, **kwargs):
            await asyncio.sleep(2)
            return "done"

        executor.register_agent("slow", slow_agent)

        with pytest.raises(RuntimeError, match="timed out"):
            await executor.execute("slow", "test", timeout=0.1)

    @pytest.mark.asyncio
    async def test_execute_with_error(self, executor):
        """Test execution error handling"""

        async def failing_agent(prompt, **kwargs):
            raise ValueError("Test error")

        executor.register_agent("failing", failing_agent)

        with pytest.raises(RuntimeError, match="failed"):
            await executor.execute("failing", "test")

    def test_get_metrics(self, executor):
        """Test getting execution metrics"""
        # No metrics yet
        metrics = executor.get_metrics()
        assert metrics["count"] == 0

    def test_reset_metrics(self, executor):
        """Test resetting metrics"""
        # Add some mock metrics
        executor.metrics["test"] = [ExecutionMetrics("test", time.time(), success=True)]

        executor.reset_metrics()

        assert len(executor.metrics) == 0


class TestGlobalInstances:
    """Test global instance management"""

    def test_get_agent_queue(self):
        """Test getting global agent queue"""
        reset_agent_queue()

        queue1 = get_agent_queue()
        queue2 = get_agent_queue()

        assert queue1 is queue2

    def test_get_async_executor(self):
        """Test getting global async executor"""
        reset_async_executor()

        exec1 = get_async_executor()
        exec2 = get_async_executor()

        assert exec1 is exec2

    @pytest.mark.skip(reason="Flaky test - needs investigation")
    def test_get_async_executor_force_new(self):
        """Test forcing new executor instance"""
        reset_async_executor()

        exec1 = get_async_executor()
        get_async_executor(force_new=True)

        assert len(exec1._executors) >= 1


class TestIntegration:
    """Integration tests"""

    @pytest.mark.skip(reason="Flaky integration test - needs refactoring")
    @pytest.mark.asyncio
    async def test_queue_and_executor_integration(self):
        """Test integrating queue with executor"""
        reset_agent_queue()
        reset_async_executor()

        queue = get_agent_queue()
        executor = get_async_executor(max_concurrent=3)

        async def mock_agent(prompt, **kwargs):
            await asyncio.sleep(0.1)
            return f"Result: {prompt}"

        # Register agent
        executor.register_agent("test_agent", mock_agent)

        # Create tasks
        tasks = [
            AgentTask(task_id=f"t{i}", agent_name="test_agent", prompt=f"task {i}")
            for i in range(3)
        ]

        # Execute via queue with executor
        results = await queue.execute_parallel(
            tasks, lambda name, prompt, **kw: executor.execute(name, prompt, **kw)
        )

        assert len(results) == 3
        assert all(r.status == TaskStatus.COMPLETED for r in results.values())

    @pytest.mark.asyncio
    async def test_priority_with_dependencies(self):
        """Test priority and dependencies together"""
        reset_agent_queue()

        queue = get_agent_queue()

        async def mock_agent(name, prompt, **kwargs):
            await asyncio.sleep(0.05)
            return f"Done: {prompt}"

        # Submit tasks: low priority first, then high priority with dependency
        task1 = AgentTask(task_id="t1", agent_name="a", prompt="low-priority", priority=1)
        task2 = AgentTask(
            task_id="t2", agent_name="a", prompt="high-priority", priority=10, dependencies=["t1"]
        )

        queue.submit(task2)  # High priority but waiting
        queue.submit(task1)  # Low priority but ready

        results = await queue.execute_all(mock_agent)

        # Both should complete
        assert results["t1"].status == TaskStatus.COMPLETED
        assert results["t2"].status == TaskStatus.COMPLETED


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
