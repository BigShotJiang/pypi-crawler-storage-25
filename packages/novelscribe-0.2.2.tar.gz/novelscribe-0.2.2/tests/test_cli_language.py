"""Tests for CLI language integration."""

from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from cli import cli


class TestCLILanguageOption:
    """Test global --lang option."""

    def test_lang_option_accepted(self):
        """Test that --lang option is accepted."""
        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "--lang" in result.output

    def test_lang_option_valid_choices(self):
        """Test that --lang accepts valid language codes."""
        runner = CliRunner()

        for lang in ["en", "zh-CN", "zh-TW"]:
            result = runner.invoke(cli, ["--lang", lang, "agents", "--help"])
            assert result.exit_code == 0

    def test_lang_option_invalid_choice(self):
        """Test that --lang rejects invalid language codes."""
        runner = CliRunner()
        result = runner.invoke(cli, ["--lang", "invalid", "agents", "--help"])
        assert result.exit_code != 0
        assert "Invalid value for '--lang'" in result.output


class TestAgentsLanguage:
    """Test agents command with language support."""

    def test_agents_list_displays_language(self):
        """Test that agents list displays current language."""
        runner = CliRunner()
        result = runner.invoke(cli, ["agents", "list"])
        assert result.exit_code == 0
        assert "[Language:" in result.output or "Language:" in result.output

    def test_agents_list_with_explicit_language(self):
        """Test agents list with explicit --lang option."""
        runner = CliRunner()
        result = runner.invoke(cli, ["--lang", "zh-CN", "agents", "list"])
        assert result.exit_code == 0
        assert "[Language: zh-CN]" in result.output

    def test_agents_show_displays_language(self):
        """Test that agents show displays current language."""
        runner = CliRunner()
        result = runner.invoke(cli, ["agents", "show", "outline_agent"])
        assert result.exit_code == 0
        assert "[Language:" in result.output or "Language:" in result.output

    def test_agents_show_with_explicit_language(self):
        """Test agents show with explicit --lang option."""
        runner = CliRunner()
        result = runner.invoke(cli, ["--lang", "zh-TW", "agents", "show", "outline_agent"])
        assert result.exit_code == 0
        assert "[Language: zh-TW]" in result.output


class TestWorkflowsLanguage:
    """Test workflows command with language support."""

    def test_workflows_list_displays_language(self):
        """Test that workflows list displays current language."""
        runner = CliRunner()
        result = runner.invoke(cli, ["workflows", "list"])
        assert result.exit_code == 0
        assert "[Language:" in result.output or "Language:" in result.output

    def test_workflows_list_with_explicit_language(self):
        """Test workflows list with explicit --lang option."""
        runner = CliRunner()
        result = runner.invoke(cli, ["--lang", "zh-CN", "workflows", "list"])
        assert result.exit_code == 0
        assert "[Language: zh-CN]" in result.output

    def test_workflows_show_displays_language(self):
        """Test that workflows show displays current language."""
        runner = CliRunner()
        result = runner.invoke(cli, ["workflows", "show", "new_novel"])
        if result.exit_code != 0:
            pytest.skip("Workflow file not found in test environment")
        assert "[Language:" in result.output or "Language:" in result.output

    def test_workflows_show_with_explicit_language(self):
        """Test workflows show with explicit --lang option."""
        runner = CliRunner()
        result = runner.invoke(cli, ["--lang", "zh-TW", "workflows", "show", "new_novel"])
        if result.exit_code != 0:
            pytest.skip("Workflow file not found in test environment")
        assert "[Language: zh-TW]" in result.output


class TestConfigCommands:
    """Test config commands for language management."""

    def test_config_set_language(self, tmp_path):
        """Test setting default language."""
        runner = CliRunner()

        with patch(
            "core.language_config.LanguageResolver.DEFAULT_CONFIG_PATH", tmp_path / "config.yaml"
        ):
            result = runner.invoke(cli, ["config", "set", "language", "zh-CN"])
            assert result.exit_code == 0
            assert "Default language set to: zh-CN" in result.output

    def test_config_set_invalid_language(self, tmp_path):
        """Test setting invalid language fails."""
        runner = CliRunner()

        with patch(
            "core.language_config.LanguageResolver.DEFAULT_CONFIG_PATH", tmp_path / "config.yaml"
        ):
            result = runner.invoke(cli, ["config", "set", "language", "invalid"])
            assert result.exit_code != 0
            assert "Invalid language code" in result.output

    def test_config_get_language(self, tmp_path):
        """Test getting default language."""
        runner = CliRunner()

        with patch(
            "core.language_config.LanguageResolver.DEFAULT_CONFIG_PATH", tmp_path / "config.yaml"
        ):
            result = runner.invoke(cli, ["config", "get", "language"])
            assert result.exit_code == 0
            assert "Default language:" in result.output

    def test_config_get_all(self, tmp_path):
        """Test getting all configuration."""
        runner = CliRunner()

        with patch(
            "core.language_config.LanguageResolver.DEFAULT_CONFIG_PATH", tmp_path / "config.yaml"
        ):
            result = runner.invoke(cli, ["config", "get"])
            assert result.exit_code == 0
            assert "Current Configuration:" in result.output
            assert "default_language:" in result.output


class TestLanguageContext:
    """Test language context passing through CLI."""

    def test_language_in_context(self):
        """Test that language is stored in click context."""
        runner = CliRunner()

        with patch("cli.cli"):
            ctx = MagicMock()
            ctx.obj = {}

            result = runner.invoke(cli, ["--lang", "zh-CN", "agents", "--help"])
            assert result.exit_code == 0

    def test_language_passed_to_subcommands(self):
        """Test that language is passed to agent/workflow commands."""
        runner = CliRunner()

        result = runner.invoke(cli, ["--lang", "zh-TW", "agents", "list"])
        assert result.exit_code == 0
        assert "zh-TW" in result.output


class TestBackwardCompatibility:
    """Test backward compatibility without language option."""

    def test_agents_list_without_lang(self):
        """Test agents list works without --lang option."""
        runner = CliRunner()
        result = runner.invoke(cli, ["agents", "list"])
        assert result.exit_code == 0
        assert "Available Agents" in result.output

    def test_workflows_list_without_lang(self):
        """Test workflows list works without --lang option."""
        runner = CliRunner()
        result = runner.invoke(cli, ["workflows", "list"])
        assert result.exit_code == 0
        assert "Available Workflows" in result.output

    def test_default_language_when_not_specified(self):
        """Test that default language is English when not specified."""
        runner = CliRunner()
        result = runner.invoke(cli, ["agents", "list"])
        assert result.exit_code == 0
        assert "[Language: en]" in result.output


class TestLanguageHelpText:
    """Test language-related help text."""

    def test_agents_list_shows_language_help(self):
        """Test agents list shows language switching help."""
        runner = CliRunner()
        result = runner.invoke(cli, ["agents", "list"])
        assert result.exit_code == 0
        assert "--lang" in result.output or "language" in result.output.lower()

    def test_workflows_list_shows_language_help(self):
        """Test workflows list shows language switching help."""
        runner = CliRunner()
        result = runner.invoke(cli, ["workflows", "list"])
        assert result.exit_code == 0
        assert "--lang" in result.output

    def test_config_get_shows_valid_languages(self):
        """Test config get shows valid language options."""
        runner = CliRunner()
        result = runner.invoke(cli, ["config", "get"])
        assert result.exit_code == 0
        assert "en, zh-CN, zh-TW" in result.output


class TestIntegrationScenarios:
    """Integration tests for language scenarios."""

    def test_set_language_then_list_agents(self, tmp_path):
        """Test setting default language then listing agents."""
        runner = CliRunner()

        with patch(
            "core.language_config.LanguageResolver.DEFAULT_CONFIG_PATH", tmp_path / "config.yaml"
        ):
            set_result = runner.invoke(cli, ["config", "set", "language", "zh-CN"])
            assert set_result.exit_code == 0

            list_result = runner.invoke(cli, ["agents", "list"])
            assert list_result.exit_code == 0

    def test_override_project_language_with_cli(self, tmp_path):
        """Test overriding project language with CLI option."""
        runner = CliRunner()

        with patch("pathlib.Path.cwd", return_value=tmp_path):
            meta_file = tmp_path / "META.yaml"
            meta_file.write_text("language: zh-TW\n", encoding="utf-8")

            result = runner.invoke(cli, ["--lang", "en", "agents", "list"])
            assert result.exit_code == 0
            assert "[Language: en]" in result.output

    def test_language_persistence(self, tmp_path):
        """Test that language setting is saved to config file."""
        runner = CliRunner()
        config_path = tmp_path / "config.yaml"

        with patch("core.language_config.LanguageResolver.DEFAULT_CONFIG_PATH", config_path):
            result = runner.invoke(cli, ["config", "set", "language", "zh-CN"])
            assert result.exit_code == 0
            assert config_path.exists()

            content = config_path.read_text(encoding="utf-8")
            assert "default_language: zh-CN" in content or "zh-CN" in content
