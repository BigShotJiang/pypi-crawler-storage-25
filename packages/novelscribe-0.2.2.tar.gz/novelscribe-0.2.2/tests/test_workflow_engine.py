"""Tests for workflow engine components."""

from unittest.mock import Mock

import pytest

from core.step_executor import StepExecutor, SystemActionHandler
from core.variable_resolver import VariableResolver
from core.workflow_executor import WorkflowExecutor
from core.workflow_loader import OnFailure, WorkflowLoader, WorkflowStep


@pytest.fixture
def sample_workflow_content():
    """Sample workflow definition content."""
    return """name: test_workflow
version: 1.0.0
description: Test workflow for unit testing
variables:
  project_name: null
  provider: openai
steps:
  - step: 1
    name: Test step
    agent: test_agent
    input:
      test_input: ${project_name}
    output:
      test_output: result
    on_failure: stop
"""


@pytest.fixture
def temp_workflows_dir(tmp_path):
    """Create temporary workflows directory."""
    workflows_dir = tmp_path / "workflows"
    workflows_dir.mkdir()
    return workflows_dir


@pytest.fixture
def workflow_loader(temp_workflows_dir):
    """Create workflow loader fixture."""
    return WorkflowLoader(temp_workflows_dir)


@pytest.fixture
def sample_workflow(temp_workflows_dir, sample_workflow_content):
    """Create sample workflow file."""
    workflow_file = temp_workflows_dir / "test_workflow.yaml"
    workflow_file.write_text(sample_workflow_content)
    return workflow_file


class TestWorkflowLoader:
    """Tests for WorkflowLoader."""

    def test_load_workflow(self, workflow_loader, sample_workflow):
        """Test loading workflow from file."""
        workflow = workflow_loader.load_workflow(sample_workflow)

        assert workflow.name == "test_workflow"
        assert workflow.version == "1.0.0"
        assert workflow.description == "Test workflow for unit testing"
        assert len(workflow.steps) == 1
        assert workflow.steps[0].agent == "test_agent"

    def test_parse_workflow(self, workflow_loader, sample_workflow_content):
        """Test parsing workflow from content."""
        workflow = workflow_loader.parse_workflow(sample_workflow_content)

        assert workflow.name == "test_workflow"
        assert len(workflow.variables) == 2
        assert "project_name" in workflow.variables

    def test_load_nonexistent_file(self, workflow_loader):
        """Test loading nonexistent file."""
        with pytest.raises(FileNotFoundError):
            workflow_loader.load_workflow("nonexistent.yaml")

    def test_invalid_yaml(self, workflow_loader, temp_workflows_dir):
        """Test invalid YAML content."""
        invalid_file = temp_workflows_dir / "invalid.yaml"
        invalid_file.write_text("invalid: [unclosed")

        with pytest.raises(ValueError):
            workflow_loader.load_workflow(invalid_file)

    def test_missing_required_fields(self, workflow_loader, temp_workflows_dir):
        """Test missing required fields."""
        invalid_file = temp_workflows_dir / "invalid.yaml"
        invalid_file.write_text("name: test\n")

        with pytest.raises(ValueError):
            workflow_loader.load_workflow(invalid_file)

    def test_load_all_workflows(self, workflow_loader, sample_workflow):
        """Test loading all workflows."""
        workflows = workflow_loader.load_all_workflows()

        assert len(workflows) == 1
        assert workflows[0].name == "test_workflow"


class TestVariableResolver:
    """Tests for VariableResolver."""

    @pytest.fixture
    def resolver(self):
        """Create variable resolver fixture."""
        return VariableResolver()

    def test_resolve_simple_variable(self, resolver):
        """Test resolving simple variable."""
        resolver.variables = {"name": "test"}

        result = resolver.resolve("${name}")

        assert result == "test"

    def test_resolve_dot_notation(self, resolver):
        """Test resolving dot notation."""
        resolver.variables = {"project": {"meta": {"genre": "fantasy"}}}

        result = resolver.resolve("${project.meta.genre}")

        assert result == "fantasy"

    def test_resolve_step_output(self, resolver):
        """Test resolving step output."""
        resolver.step_outputs = {"previous_step": {"result": "success"}}

        result = resolver.resolve("${previous_step.result}")

        assert result == "success"

    def test_resolve_dict(self, resolver):
        """Test resolving variables in dictionary."""
        resolver.variables = {"name": "test"}

        data = {"key1": "${name}", "key2": "static"}

        result = resolver.resolve_dict(data)

        assert result["key1"] == "test"
        assert result["key2"] == "static"

    def test_resolve_list(self, resolver):
        """Test resolving variables in list."""
        resolver.variables = {"value": "123"}

        data = ["${value}", "static"]

        result = resolver.resolve_list(data)

        assert result[0] == "123"
        assert result[1] == "static"

    def test_evaluate_condition(self, resolver):
        """Test evaluating conditions."""
        resolver.variables = {"status": "FAIL", "status_copy": "FAIL"}

        result = resolver.evaluate_condition("${status} == ${status_copy}")

        assert result is True

    def test_evaluate_numeric_condition(self, resolver):
        """Test evaluating numeric conditions."""
        resolver.variables = {"count": 5}

        result = resolver.evaluate_condition("${count} > 3")

        assert result is True

    def test_set_and_get_variable(self, resolver):
        """Test setting and getting variables."""
        resolver.set_variable("test", "value")

        result = resolver.get_variable("test")

        assert result == "value"


class TestSystemActionHandler:
    """Tests for SystemActionHandler."""

    @pytest.fixture
    def mock_storage(self):
        """Create mock storage."""
        storage = Mock()
        storage.read_yaml.return_value = {"key": "value"}
        storage.read_markdown.return_value = "# Content"
        return storage

    @pytest.fixture
    def mock_git_manager(self):
        """Create mock git manager."""
        git = Mock()
        git.initialize_repository.return_value = None
        git.auto_commit_step.return_value = None
        git.create_milestone_tag.return_value = None
        return git

    @pytest.fixture
    def handler(self, mock_storage, mock_git_manager, tmp_path):
        """Create system action handler fixture."""
        return SystemActionHandler(
            storage=mock_storage, git_manager=mock_git_manager, work_dir=tmp_path
        )

    def test_create_directories(self, handler, tmp_path):
        """Test create_directories action."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        result = handler.execute_action(
            "create_directories", {"directories": ["chapters", "reports"]}, "test_project"
        )

        assert result["success"] is True
        assert (project_dir / "chapters").exists()
        assert (project_dir / "reports").exists()

    def test_load_yaml(self, handler, tmp_path):
        """Test load_yaml action."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()
        (project_dir / "META.yaml").write_text("key: value")

        result = handler.execute_action("load_yaml", {"file": "META.yaml"}, "test_project")

        assert result["success"] is True
        assert "meta" in result

    def test_get_chapter_count(self, handler, tmp_path):
        """Test get_chapter_count action."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()
        chapters_dir = project_dir / "chapters"
        chapters_dir.mkdir()

        for i in range(1, 4):
            (chapters_dir / f"chapter_{i}.md").write_text(f"Chapter {i}")

        result = handler.execute_action("get_chapter_count", {}, "test_project")

        assert result["success"] is True
        assert result["count"] == 3


class TestStepExecutor:
    """Tests for StepExecutor."""

    @pytest.fixture
    def mock_agent_integration(self):
        """Create mock agent integration."""
        integration = Mock()
        integration.execute_agent_step.return_value = {"success": True, "output": "test output"}
        return integration

    @pytest.fixture
    def mock_storage(self):
        """Create mock storage."""
        return Mock()

    @pytest.fixture
    def mock_git_manager(self):
        """Create mock git manager."""
        return Mock()

    @pytest.fixture
    def step_executor(self, mock_agent_integration, mock_storage, mock_git_manager, tmp_path):
        """Create step executor fixture."""
        return StepExecutor(
            agent_integration=mock_agent_integration,
            storage=mock_storage,
            git_manager=mock_git_manager,
            work_dir=tmp_path,
        )

    @pytest.fixture
    def sample_step(self):
        """Create sample workflow step."""
        return WorkflowStep(
            step=1,
            name="Test step",
            agent="test_agent",
            input={"test_input": "${project_name}"},
            output={"result": "output"},
            on_failure=OnFailure.STOP,
        )

    def test_execute_agent_step(self, step_executor, sample_step, mock_agent_integration):
        """Test executing agent step."""
        result = step_executor.execute_step(
            step=sample_step,
            project_name="test_project",
            variables={"project_name": "test_project"},
            step_outputs={},
            config={"provider": "openai"},
        )

        assert result["success"] is True
        assert result["name"] == "Test step"
        mock_agent_integration.execute_agent_step.assert_called_once()

    def test_execute_system_action_step(self, step_executor):
        """Test executing system action step."""
        step = WorkflowStep(
            step=1,
            name="Create directories",
            action="create_directories",
            input={"directories": ["chapters"]},
            on_failure=OnFailure.STOP,
        )

        result = step_executor.execute_step(
            step=step, project_name="test_project", variables={}, step_outputs={}, config={}
        )

        assert result["success"] is True

    def test_conditional_execution_skip(self, step_executor):
        """Test conditional execution with skip."""
        step = WorkflowStep(
            step=1,
            name="Conditional step",
            agent="test_agent",
            condition="${should_run} == false",
            on_failure=OnFailure.STOP,
        )

        result = step_executor.execute_step(
            step=step,
            project_name="test_project",
            variables={"should_run": False},
            step_outputs={},
            config={},
        )

        assert result["skipped"] is True

    def test_conditional_execute(self, step_executor, sample_step, mock_agent_integration):
        """Test conditional execution with execute."""
        step = sample_step
        step.condition = "${should_run} == True"

        result = step_executor.execute_step(
            step=step,
            project_name="test_project",
            variables={"should_run": True},
            step_outputs={},
            config={},
        )

        assert result["skipped"] is False
        mock_agent_integration.execute_agent_step.assert_called_once()


class TestWorkflowExecutor:
    """Tests for WorkflowExecutor."""

    @pytest.fixture
    def mock_agent_integration(self):
        """Create mock agent integration."""
        integration = Mock()
        integration.execute_agent_step.return_value = {"success": True, "output": "test output"}
        return integration

    @pytest.fixture
    def mock_storage(self):
        """Create mock storage."""
        return Mock()

    @pytest.fixture
    def mock_git_manager(self):
        """Create mock git manager."""
        return Mock()

    @pytest.fixture
    def workflow_executor(
        self, temp_workflows_dir, mock_agent_integration, mock_storage, mock_git_manager, tmp_path
    ):
        """Create workflow executor fixture."""
        return WorkflowExecutor(
            workflows_dir=temp_workflows_dir,
            agent_integration=mock_agent_integration,
            storage=mock_storage,
            git_manager=mock_git_manager,
            work_dir=tmp_path,
        )

    def test_execute_workflow(self, workflow_executor, sample_workflow):
        """Test executing workflow."""
        result = workflow_executor.execute_workflow(
            workflow_name="test_workflow",
            project_name="test_project",
            variables={"project_name": "test_project"},
            config={"provider": "openai"},
        )

        assert result["success"] is True
        assert result["workflow"] == "test_workflow"
        assert len(result["executed_steps"]) == 1

    def test_list_workflows(self, workflow_executor, sample_workflow):
        """Test listing workflows."""
        workflows = workflow_executor.list_workflows()

        assert "test_workflow" in workflows
        assert workflows["test_workflow"] == "Test workflow for unit testing"

    def test_get_workflow_info(self, workflow_executor, sample_workflow):
        """Test getting workflow info."""
        info = workflow_executor.get_workflow_info("test_workflow")

        assert info["name"] == "test_workflow"
        assert info["version"] == "1.0.0"
        assert info["step_count"] == 1
