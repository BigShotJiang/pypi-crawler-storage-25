from datetime import datetime, timezone
from unittest.mock import patch

from core.summary_store import (
    ChapterSummary,
    GlobalSummary,
    GroupSummary,
    SummaryStore,
    SummaryStoreConfig,
)


def _chapter(n: int) -> ChapterSummary:
    return ChapterSummary(
        chapter_number=n,
        summary=f"s{n}",
        key_events=["e1"],
        characters={"John": "hero"},
        locations={"city": "A"},
        plot_advancement="p",
        next_chapter_setup="n",
        created_at=datetime.now(timezone.utc),
        word_count=123,
    )


def _group() -> GroupSummary:
    return GroupSummary(
        group_id="chapters_1_2",
        start_chapter=1,
        end_chapter=2,
        summary="g",
        combined_events=[],
        character_arcs={},
        plot_developments=[],
        created_at=datetime.now(timezone.utc),
        total_word_count=246,
    )


def _global() -> GlobalSummary:
    return GlobalSummary(
        project_name="p",
        summary="gs",
        main_plot_arc="arc",
        character_arcs={},
        world_development="w",
        themes=["t"],
        last_updated=datetime.now(timezone.utc),
        total_chapters_covered=2,
        total_word_count=246,
    )


def test_store_yaml_roundtrip_and_lists_and_stats(tmp_path):
    store = SummaryStore(tmp_path, SummaryStoreConfig(storage_format="yaml", auto_backup=False))
    c1 = _chapter(1)
    c2 = _chapter(2)
    store.save_chapter_summary(c1)
    store.save_chapter_summary(c2)
    store.save_group_summary(_group())
    store.save_global_summary(_global())
    assert store.load_chapter_summary(1).summary == "s1"
    assert store.load_group_summary("chapters_1_2").start_chapter == 1
    assert store.load_global_summary().project_name == "p"
    assert store.list_chapter_summaries() == [1, 2]
    assert store.list_group_summaries() == ["chapters_1_2"]
    stats = store.get_summary_statistics()
    assert stats["chapter_summaries"] == 2
    assert stats["group_summaries"] == 1
    assert stats["has_global_summary"] is True


def test_store_json_roundtrip_and_deletes_and_missing(tmp_path):
    store = SummaryStore(tmp_path, SummaryStoreConfig(storage_format="json", auto_backup=False))
    store.save_chapter_summary(_chapter(3))
    store.save_group_summary(_group())
    store.save_global_summary(_global())
    assert store.load_chapter_summary(9) is None
    assert store.load_group_summary("none") is None
    store.delete_chapter_summary(3)
    store.delete_group_summary("chapters_1_2")
    assert store.load_chapter_summary(3) is None
    assert store.load_group_summary("chapters_1_2") is None


def test_backup_cleanup_keeps_only_configured_count(tmp_path):
    cfg = SummaryStoreConfig(storage_format="yaml", auto_backup=True, backup_count=2)
    store = SummaryStore(tmp_path, cfg)
    p = store._get_chapter_summary_path(1)
    store.save_chapter_summary(_chapter(1))
    store.save_chapter_summary(_chapter(1))
    store.save_chapter_summary(_chapter(1))
    backups = list(p.parent.glob(f"{p.stem}.backup_*{p.suffix}"))
    assert len(backups) <= 2


def test_export_markdown_json_yaml(tmp_path):
    store = SummaryStore(tmp_path, SummaryStoreConfig(storage_format="yaml", auto_backup=False))
    store.save_chapter_summary(_chapter(1))
    store.save_group_summary(_group())
    store.save_global_summary(_global())
    md = tmp_path / "out.md"
    js = tmp_path / "out.json"
    ym = tmp_path / "out.yaml"
    store.export_summaries(md, "markdown")
    store.export_summaries(js, "json")
    store.export_summaries(ym, "yaml")
    assert md.exists() and js.exists() and ym.exists()
    assert "Novel Summaries" in md.read_text(encoding="utf-8")


def test_list_parsing_skips_invalid_chapter_files(tmp_path):
    store = SummaryStore(tmp_path, SummaryStoreConfig(storage_format="yaml", auto_backup=False))
    (store.chapters_dir / "chapter_abc.yaml").write_text("x", encoding="utf-8")
    (store.chapters_dir / "chapter_.yaml").write_text("x", encoding="utf-8")
    (store.chapters_dir / "chapter_010.yaml").write_text("x", encoding="utf-8")
    chapters = store.list_chapter_summaries()
    assert chapters == [10]


def test_list_group_summaries_filters_prefix(tmp_path):
    store = SummaryStore(tmp_path, SummaryStoreConfig(storage_format="json", auto_backup=False))
    (store.groups_dir / "chapters_1_5.json").write_text("{}", encoding="utf-8")
    (store.groups_dir / "other_group.json").write_text("{}", encoding="utf-8")
    groups = store.list_group_summaries()
    assert groups == ["chapters_1_5"]


def test_export_with_unknown_format_does_not_raise(tmp_path):
    store = SummaryStore(tmp_path, SummaryStoreConfig(storage_format="yaml", auto_backup=False))
    out = tmp_path / "unknown.out"
    store.export_summaries(out, "unknown")
    assert out.exists() is False


def test_save_data_dispatch_and_invalid_format(tmp_path):
    store = SummaryStore(tmp_path, SummaryStoreConfig(storage_format="yaml", auto_backup=False))
    target = tmp_path / "x.yaml"
    with (
        patch.object(store, "_save_yaml") as save_yaml,
        patch.object(store, "_save_json") as save_json,
    ):
        store._save_data(target, {"a": 1})
        save_yaml.assert_called_once()
        save_json.assert_not_called()

    store.config.storage_format = "json"
    with (
        patch.object(store, "_save_yaml") as save_yaml,
        patch.object(store, "_save_json") as save_json,
    ):
        store._save_data(target, {"a": 1})
        save_json.assert_called_once()
        save_yaml.assert_not_called()

    store.config.storage_format = "toml"
    raised = False
    try:
        store._save_data(target, {"a": 1})
    except ValueError:
        raised = True
    assert raised is True


def test_load_data_dispatch_and_invalid_format(tmp_path):
    store = SummaryStore(tmp_path, SummaryStoreConfig(storage_format="yaml", auto_backup=False))
    target = tmp_path / "x.yaml"
    with (
        patch.object(store, "_load_yaml", return_value={"a": 1}) as load_yaml,
        patch.object(store, "_load_json", return_value={"b": 2}) as load_json,
    ):
        out = store._load_data(target)
        assert out == {"a": 1}
        load_yaml.assert_called_once()
        load_json.assert_not_called()

    store.config.storage_format = "json"
    with (
        patch.object(store, "_load_yaml", return_value={"a": 1}) as load_yaml,
        patch.object(store, "_load_json", return_value={"b": 2}) as load_json,
    ):
        out = store._load_data(target)
        assert out == {"b": 2}
        load_json.assert_called_once()
        load_yaml.assert_not_called()

    store.config.storage_format = "toml"
    raised = False
    try:
        store._load_data(target)
    except ValueError:
        raised = True
    assert raised is True


def test_backup_file_uses_current_timestamp(tmp_path):
    store = SummaryStore(tmp_path, SummaryStoreConfig(storage_format="yaml", auto_backup=True))
    file_path = tmp_path / "summaries" / "chapters" / "chapter_001.yaml"
    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text("x", encoding="utf-8")
    with patch.object(store, "_current_timestamp", return_value="20260101_000000"):
        store._backup_file(file_path)
    backup = file_path.parent / "chapter_001.backup_20260101_000000.yaml"
    assert backup.exists()
