"""
Comprehensive tests for async_executor.py to increase coverage to 90%+.
Tests async execution, concurrency, metrics, and error handling.
"""

import asyncio
import time

import pytest

from novel_harness.core.async_executor import (
    AsyncAgentExecutor,
    ExecutionMetrics,
    get_async_executor,
    reset_async_executor,
)


class TestExecutionMetrics:
    """Test ExecutionMetrics dataclass."""

    def test_metrics_creation(self):
        """Test creating execution metrics."""
        metrics = ExecutionMetrics(
            agent_name="test_agent",
            start_time=time.time(),
        )

        assert metrics.agent_name == "test_agent"
        assert metrics.success is False
        assert metrics.duration == 0.0

    def test_metrics_with_values(self):
        """Test metrics with all values."""
        start = time.time()
        end = start + 5.0
        metrics = ExecutionMetrics(
            agent_name="test_agent",
            start_time=start,
            end_time=end,
            duration=5.0,
            success=True,
            memory_start=1024,
            memory_end=2048,
        )

        assert metrics.duration == 5.0
        assert metrics.success is True
        assert metrics.memory_end == 2048


class TestAsyncAgentExecutorInit:
    """Test AsyncAgentExecutor initialization."""

    def test_init_with_defaults(self):
        """Test initialization with defaults."""
        executor = AsyncAgentExecutor()

        assert executor.max_concurrent == 3
        assert executor.memory_limit_mb == 2048
        assert executor.enable_metrics is True
        assert executor.active_count == 0

    def test_init_with_custom_values(self):
        """Test initialization with custom values."""
        executor = AsyncAgentExecutor(max_concurrent=5, memory_limit_mb=4096, enable_metrics=False)

        assert executor.max_concurrent == 5
        assert executor.memory_limit_mb == 4096
        assert executor.enable_metrics is False


class TestAgentRegistration:
    """Test agent registration."""

    @pytest.mark.asyncio
    async def test_register_agent(self):
        """Test registering an agent."""
        executor = AsyncAgentExecutor()

        async def mock_agent(prompt, **kwargs):
            return "result"

        executor.register_agent("test_agent", mock_agent)

        assert "test_agent" in executor.agent_registry

    @pytest.mark.asyncio
    async def test_get_registered_agents(self):
        """Test getting registered agents."""
        executor = AsyncAgentExecutor()

        async def mock_agent(prompt, **kwargs):
            return "result"

        executor.register_agent("agent1", mock_agent)
        executor.register_agent("agent2", mock_agent)

        agents = executor.get_registered_agents()
        assert "agent1" in agents
        assert "agent2" in agents


class TestExecute:
    """Test execute method."""

    @pytest.mark.asyncio
    async def test_execute_success(self):
        """Test successful agent execution."""
        executor = AsyncAgentExecutor()

        async def mock_agent(prompt, **kwargs):
            return f"processed: {prompt}"

        executor.register_agent("test_agent", mock_agent)

        result = await executor.execute("test_agent", "hello world")

        assert result == "processed: hello world"

    @pytest.mark.asyncio
    async def test_execute_unregistered_agent(self):
        """Test executing unregistered agent raises error."""
        executor = AsyncAgentExecutor()

        with pytest.raises(ValueError, match="not registered"):
            await executor.execute("unknown_agent", "prompt")

    @pytest.mark.asyncio
    async def test_execute_with_timeout(self):
        """Test execution with timeout."""
        executor = AsyncAgentExecutor()

        async def slow_agent(prompt, **kwargs):
            await asyncio.sleep(10)
            return "done"

        executor.register_agent("slow_agent", slow_agent)

        with pytest.raises(RuntimeError, match="timed out"):
            await executor.execute("slow_agent", "prompt", timeout=0.1)

    @pytest.mark.asyncio
    async def test_execute_with_exception(self):
        """Test execution with exception."""
        executor = AsyncAgentExecutor()

        async def failing_agent(prompt, **kwargs):
            raise ValueError("Agent failed")

        executor.register_agent("failing_agent", failing_agent)

        with pytest.raises(RuntimeError, match="Agent 'failing_agent' failed"):
            await executor.execute("failing_agent", "prompt")

    @pytest.mark.asyncio
    async def test_execute_tracks_active_count(self):
        """Test that execution tracks active count."""
        executor = AsyncAgentExecutor()

        async def mock_agent(prompt, **kwargs):
            return "result"

        executor.register_agent("test_agent", mock_agent)

        initial_count = executor.get_active_count()
        await executor.execute("test_agent", "prompt")
        final_count = executor.get_active_count()

        assert final_count == initial_count


class TestExecuteMany:
    """Test execute_many method."""

    @pytest.mark.asyncio
    async def test_execute_many_parallel(self):
        """Test parallel execution of multiple agents."""
        executor = AsyncAgentExecutor(max_concurrent=3)

        async def mock_agent(prompt, **kwargs):
            await asyncio.sleep(0.01)
            return f"result: {prompt}"

        executor.register_agent("agent1", mock_agent)
        executor.register_agent("agent2", mock_agent)
        executor.register_agent("agent3", mock_agent)

        tasks = [
            ("agent1", "task1"),
            ("agent2", "task2"),
            ("agent3", "task3"),
        ]

        results = await executor.execute_many(tasks)

        assert len(results) == 3
        assert "result: task1" in results
        assert "result: task2" in results
        assert "result: task3" in results

    @pytest.mark.asyncio
    async def test_execute_many_stop_on_error(self):
        """Test execution stopping on error."""
        executor = AsyncAgentExecutor()

        call_count = 0

        async def failing_agent(prompt, **kwargs):
            nonlocal call_count
            call_count += 1
            if "fail" in prompt:
                raise ValueError("Failed")
            return f"success: {prompt}"

        executor.register_agent("failing_agent", failing_agent)

        tasks = [
            ("failing_agent", "task1"),
            ("failing_agent", "fail_task"),
            ("failing_agent", "task3"),
        ]

        results = await executor.execute_many(tasks, stop_on_error=True)

        # First succeeds, second fails and stops
        assert len(results) == 2
        assert "success: task1" in results[0]

    @pytest.mark.asyncio
    async def test_execute_many_with_errors(self):
        """Test execution with errors collected."""
        executor = AsyncAgentExecutor()

        async def failing_agent(prompt, **kwargs):
            raise ValueError("Error")

        executor.register_agent("failing_agent", failing_agent)

        tasks = [
            ("failing_agent", "task1"),
            ("failing_agent", "task2"),
        ]

        results = await executor.execute_many(tasks)

        assert len(results) == 2
        assert all("ERROR:" in r for r in results)


class TestExecuteParallel:
    """Test execute_parallel method."""

    @pytest.mark.asyncio
    async def test_execute_parallel(self):
        """Test parallel execution with dependencies."""
        executor = AsyncAgentExecutor(max_concurrent=3)

        async def mock_agent(prompt, **kwargs):
            return f"result: {prompt}"

        executor.register_agent("agent1", mock_agent)
        executor.register_agent("agent2", mock_agent)

        agents = [
            {"name": "agent1", "prompt": "task1"},
            {"name": "agent2", "prompt": "task2"},
        ]

        results = await executor.execute_parallel(agents)

        assert "agent1" in results
        assert "agent2" in results

    @pytest.mark.asyncio
    async def test_execute_parallel_with_dependencies(self):
        """Test parallel execution with dependencies."""
        executor = AsyncAgentExecutor(max_concurrent=3)

        async def mock_agent(prompt, **kwargs):
            return f"result: {prompt}"

        executor.register_agent("agent1", mock_agent)
        executor.register_agent("agent2", mock_agent)

        agents = [
            {"name": "agent1", "prompt": "task1"},
            {"name": "agent2", "prompt": "task2", "dependencies": ["agent1"]},
        ]

        results = await executor.execute_parallel(agents, wait_all=True)

        assert len(results) > 0


class TestMetrics:
    """Test metrics collection."""

    @pytest.mark.asyncio
    async def test_get_metrics_no_data(self):
        """Test getting metrics with no data."""
        executor = AsyncAgentExecutor()

        metrics = executor.get_metrics()

        assert metrics["count"] == 0
        assert metrics["success_rate"] == 0

    @pytest.mark.asyncio
    async def test_get_metrics_specific_agent(self):
        """Test getting metrics for specific agent."""
        executor = AsyncAgentExecutor()

        async def mock_agent(prompt, **kwargs):
            return "result"

        executor.register_agent("test_agent", mock_agent)
        await executor.execute("test_agent", "prompt")

        metrics = executor.get_metrics("test_agent")

        assert metrics["count"] == 1
        assert metrics["success_rate"] == 100

    @pytest.mark.asyncio
    async def test_get_metrics_all_agents(self):
        """Test getting metrics for all agents."""
        executor = AsyncAgentExecutor()

        async def mock_agent(prompt, **kwargs):
            return "result"

        executor.register_agent("agent1", mock_agent)
        executor.register_agent("agent2", mock_agent)

        await executor.execute("agent1", "prompt1")
        await executor.execute("agent2", "prompt2")

        metrics = executor.get_metrics()

        assert metrics["count"] == 2

    @pytest.mark.asyncio
    async def test_reset_metrics(self):
        """Test resetting metrics."""
        executor = AsyncAgentExecutor()

        async def mock_agent(prompt, **kwargs):
            return "result"

        executor.register_agent("test_agent", mock_agent)
        await executor.execute("test_agent", "prompt")

        executor.reset_metrics()

        metrics = executor.get_metrics()
        assert metrics["count"] == 0


class TestContextManager:
    """Test async context manager."""

    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Test using executor as async context manager."""
        async with AsyncAgentExecutor() as executor:
            assert executor is not None


class TestGlobalExecutor:
    """Test global executor functions."""

    @pytest.mark.asyncio
    async def test_get_async_executor(self):
        """Test getting global executor."""
        reset_async_executor()

        executor1 = get_async_executor()
        executor2 = get_async_executor()

        assert executor1 is executor2

    @pytest.mark.asyncio
    async def test_get_async_executor_force_new(self):
        """Test forcing new executor creation."""
        reset_async_executor()

        executor1 = get_async_executor()
        executor2 = get_async_executor(force_new=True)

        assert executor1 is not executor2

    @pytest.mark.asyncio
    async def test_reset_async_executor(self):
        """Test resetting global executor."""
        executor1 = get_async_executor()
        reset_async_executor()
        executor2 = get_async_executor()

        assert executor1 is not executor2


class TestAgentContext:
    """Test agent context."""

    @pytest.mark.asyncio
    async def test_agent_context_set_and_get(self):
        """Test setting and getting agent context."""
        from core.async_executor import agent_context

        ctx = {"agent_name": "test", "prompt": "test_prompt"}
        token = agent_context.set(ctx)

        current = agent_context.get()
        assert current["agent_name"] == "test"

        agent_context.reset(token)

    @pytest.mark.asyncio
    async def test_agent_context_default(self):
        """Test agent context default value."""
        from core.async_executor import agent_context

        default = agent_context.set({})

        assert agent_context.get() == {}

        agent_context.reset(default)


class TestEdgeCases:
    """Test edge cases."""

    @pytest.mark.asyncio
    async def test_execute_with_kwargs(self):
        """Test execution with additional kwargs."""
        executor = AsyncAgentExecutor()

        async def mock_agent(prompt, **kwargs):
            return f"prompt={prompt}, extra={kwargs.get('extra')}"

        executor.register_agent("test_agent", mock_agent)

        result = await executor.execute("test_agent", "hello", extra="world")

        assert "prompt=hello" in result
        assert "extra=world" in result

    @pytest.mark.asyncio
    async def test_get_active_count(self):
        """Test getting active execution count."""
        executor = AsyncAgentExecutor()

        assert executor.get_active_count() == 0

    @pytest.mark.asyncio
    async def test_execute_many_empty_list(self):
        """Test executing with empty task list."""
        executor = AsyncAgentExecutor()

        results = await executor.execute_many([])

        assert results == []

    @pytest.mark.asyncio
    async def test_metrics_disabled(self):
        """Test when metrics are disabled."""
        executor = AsyncAgentExecutor(enable_metrics=False)

        async def mock_agent(prompt, **kwargs):
            return "result"

        executor.register_agent("test_agent", mock_agent)
        await executor.execute("test_agent", "prompt")

        metrics = executor.get_metrics()
        assert metrics["count"] == 0
