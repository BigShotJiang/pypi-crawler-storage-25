"""Test coverage for api/websocket_manager.py."""

import asyncio
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock

import pytest

from api.websocket_manager import (
    EventType,
    RealtimeEvent,
    WebSocketManager,
    WSConnection,
)


class TestEventType:
    def test_event_type_values(self):
        """Test EventType enum values"""
        assert EventType.LOG.value == "log"
        assert EventType.PROGRESS.value == "progress"
        assert EventType.STATUS_CHANGE.value == "status_change"
        assert EventType.HEARTBEAT.value == "heartbeat"


class TestWSConnection:
    def test_connection_creation(self):
        """Test WSConnection creation"""
        websocket = MagicMock()
        connection = WSConnection(
            client_id="test_id",
            websocket=websocket,
            project_name="test_project",
            metadata={"user": "test_user"},
        )
        assert connection.client_id == "test_id"
        assert connection.project_name == "test_project"
        assert connection.metadata == {"user": "test_user"}
        assert isinstance(connection.connected_at, datetime)
        assert isinstance(connection.last_ping, datetime)
        assert connection.subscribed_events == set(EventType)

    def test_send_json_success(self):
        """Test successful JSON sending"""
        websocket = AsyncMock()
        connection = WSConnection(client_id="test", websocket=websocket)

        async def test_send():
            await connection.send_json({"test": "data"})

        asyncio.run(test_send())
        websocket.send_json.assert_called_once()

    def test_send_json_failure(self):
        """Test JSON sending with exception"""
        websocket = AsyncMock(side_effect=Exception("Connection closed"))
        connection = WSConnection(client_id="test", websocket=websocket)

        async def test_send():
            try:
                await connection.send_json({"test": "data"})
            except Exception:
                pass  # Expected exception

        asyncio.run(test_send())

    def test_send_text_success(self):
        """Test successful text sending"""
        websocket = AsyncMock()
        connection = WSConnection(client_id="test", websocket=websocket)

        async def test_send():
            await connection.send_text("test message")

        asyncio.run(test_send())
        websocket.send_text.assert_called_once_with("test message")

    def test_update_ping(self):
        """Test ping time update"""
        connection = WSConnection(client_id="test", websocket=MagicMock())
        old_ping = connection.last_ping
        connection.update_ping()
        assert connection.last_ping > old_ping


class TestRealtimeEvent:
    def test_event_creation(self):
        """Test RealtimeEvent creation"""
        event = RealtimeEvent(
            type=EventType.PROGRESS,
            data={"progress": 50},
            priority="high",
            source="test_source",
        )
        assert event.type == EventType.PROGRESS
        assert event.data == {"progress": 50}
        assert event.priority == "high"
        assert event.source == "test_source"
        assert isinstance(event.timestamp, datetime)

    def test_to_dict(self):
        """Test event to_dict conversion"""
        event = RealtimeEvent(
            type=EventType.LOG,
            data={"message": "test"},
        )
        result = event.to_dict()
        assert result["type"] == "log"
        assert "timestamp" in result
        assert result["data"] == {"message": "test"}
        assert result["priority"] == "normal"

    def test_to_websocket_message(self):
        """Test event to_websocket_message conversion"""
        event = RealtimeEvent(
            type=EventType.PROGRESS,
            data={"progress": 75},
        )
        message = event.to_websocket_message()
        assert message["type"] == "progress"
        assert "timestamp" in message
        assert message["data"] == {"progress": 75}


class TestWebSocketManager:
    @pytest.fixture
    def manager(self):
        """Create a manager instance for testing"""
        return WebSocketManager()

    @pytest.fixture
    def mock_websocket(self):
        """Create a mock WebSocket"""
        websocket = AsyncMock()
        websocket.accept = AsyncMock()
        websocket.send_json = AsyncMock()
        websocket.send_text = AsyncMock()
        websocket.close = AsyncMock()
        return websocket

    def test_manager_initialization(self):
        """Test manager initialization"""
        manager = WebSocketManager()
        assert manager.connections == {}
        assert manager.total_connections == 0
        assert manager.total_disconnections == 0
        assert manager.total_messages_sent == 0

    def test_manager_with_custom_generators(self):
        """Test manager with custom ID and time generators"""

        def custom_id():
            return "custom_id_123"

        def custom_time():
            return datetime(2024, 1, 1, 12, 0, 0)

        manager = WebSocketManager(id_generator=custom_id, time_provider=custom_time)
        assert manager._id_generator == custom_id
        assert manager._time_provider == custom_time

    def test_connect_success(self, manager, mock_websocket):
        """Test successful WebSocket connection"""

        async def test_connect():
            client_id = await manager.connect(mock_websocket, project_name="test_project")
            assert client_id in manager.connections
            assert manager.total_connections == 1

        asyncio.run(test_connect())

    def test_connect_without_project(self, manager, mock_websocket):
        """Test connection without project name"""

        async def test_connect():
            client_id = await manager.connect(mock_websocket)
            assert client_id in manager.global_connections

        asyncio.run(test_connect())

    def test_disconnect_success(self, manager, mock_websocket):
        """Test successful disconnection"""

        async def test_disconnect():
            client_id = await manager.connect(mock_websocket, project_name="test_project")
            await manager.disconnect(client_id)
            assert client_id not in manager.connections
            assert manager.total_disconnections == 1

        asyncio.run(test_disconnect())

    def test_disconnect_nonexistent_client(self, manager):
        """Test disconnecting non-existent client"""

        async def test_disconnect():
            await manager.disconnect("nonexistent_id")
            assert manager.total_disconnections == 0

        asyncio.run(test_disconnect())

    def test_send_to_client_success(self, manager, mock_websocket):
        """Test sending message to specific client"""

        async def test_send():
            client_id = await manager.connect(mock_websocket)
            success = await manager.send_to_client(client_id, {"message": "test"})
            assert success is True
            assert manager.total_messages_sent == 1

        asyncio.run(test_send())

    def test_send_to_client_not_found(self, manager):
        """Test sending to non-existent client"""

        async def test_send():
            success = await manager.send_to_client("nonexistent", {"message": "test"})
            assert success is False

        asyncio.run(test_send())

    def test_send_to_client_raw(self, manager, mock_websocket):
        """Test sending raw text to client"""

        async def test_send():
            client_id = await manager.connect(mock_websocket)
            success = await manager.send_to_client_raw(client_id, "raw text")
            assert success is True

        asyncio.run(test_send())

    def test_broadcast_to_project(self, manager, mock_websocket):
        """Test broadcasting to project clients"""

        async def test_broadcast():
            await manager.connect(mock_websocket, project_name="project1")
            await manager.connect(mock_websocket, project_name="project1")

            event = RealtimeEvent(type=EventType.LOG, data={"message": "test"})
            count = await manager.broadcast_to_project("project1", event)
            assert count == 2

        asyncio.run(test_broadcast())

    def test_broadcast_to_project_no_clients(self, manager):
        """Test broadcasting to project with no clients"""

        async def test_broadcast():
            event = RealtimeEvent(type=EventType.LOG, data={"message": "test"})
            count = await manager.broadcast_to_project("nonexistent", event)
            assert count == 0

        asyncio.run(test_broadcast())

    def test_broadcast_global(self, manager, mock_websocket):
        """Test global broadcasting"""

        async def test_broadcast():
            await manager.connect(mock_websocket)
            await manager.connect(mock_websocket)

            event = RealtimeEvent(type=EventType.PROGRESS, data={"progress": 50})
            count = await manager.broadcast_global(event)
            assert count == 2

        asyncio.run(test_broadcast())

    def test_emit_event_with_source(self, manager, mock_websocket):
        """Test emitting event with source"""

        async def test_emit():
            await manager.connect(mock_websocket, project_name="test_project")

            event = RealtimeEvent(
                type=EventType.LOG, data={"message": "test"}, source="test_project"
            )
            count = await manager.emit_event(event)
            assert count == 1

        asyncio.run(test_emit())

    def test_emit_event_with_data_project(self, manager, mock_websocket):
        """Test emitting event with project in data"""

        async def test_emit():
            await manager.connect(mock_websocket, project_name="test_project")

            event = RealtimeEvent(
                type=EventType.LOG, data={"message": "test", "project": "test_project"}
            )
            count = await manager.emit_event(event)
            assert count == 1

        asyncio.run(test_emit())

    def test_subscribe(self, manager, mock_websocket):
        """Test subscribing to event types"""

        async def test_subscribe():
            client_id = await manager.connect(mock_websocket)
            success = manager.subscribe(client_id, [EventType.LOG, EventType.PROGRESS])
            assert success is True

        asyncio.run(test_subscribe())

    def test_subscribe_nonexistent_client(self, manager):
        """Test subscribing non-existent client"""
        success = manager.subscribe("nonexistent", [EventType.LOG])
        assert success is False

    def test_unsubscribe(self, manager, mock_websocket):
        """Test unsubscribing from event types"""

        async def test_unsubscribe():
            client_id = await manager.connect(mock_websocket)
            manager.subscribe(client_id, [EventType.LOG, EventType.PROGRESS])
            success = manager.unsubscribe(client_id, [EventType.LOG])
            assert success is True

        asyncio.run(test_unsubscribe())

    def test_handle_client_message_subscribe(self, manager, mock_websocket):
        """Test handling subscribe message"""

        async def test_handle():
            client_id = await manager.connect(mock_websocket)
            message = {"type": "subscribe", "event_types": ["log", "progress"]}
            await manager.handle_client_message(client_id, message)
            connection = manager.connections.get(client_id)
            assert EventType.LOG in connection.subscribed_events

        asyncio.run(test_handle())

    def test_handle_client_message_unsubscribe(self, manager, mock_websocket):
        """Test handling unsubscribe message"""

        async def test_handle():
            client_id = await manager.connect(mock_websocket)
            message = {"type": "unsubscribe", "event_types": ["log"]}
            await manager.handle_client_message(client_id, message)
            assert EventType.LOG not in manager.connections[client_id].subscribed_events

        asyncio.run(test_handle())

    def test_handle_client_message_ping(self, manager, mock_websocket):
        """Test handling ping message"""

        async def test_handle():
            client_id = await manager.connect(mock_websocket)
            old_ping = manager.connections[client_id].last_ping
            message = {"type": "ping"}
            await manager.handle_client_message(client_id, message)
            assert manager.connections[client_id].last_ping > old_ping

        asyncio.run(test_handle())

    def test_get_clients_for_project(self, manager, mock_websocket):
        """Test getting clients for project"""

        async def test_get():
            await manager.connect(mock_websocket, project_name="test_project")
            await manager.connect(mock_websocket, project_name="test_project")

            clients = manager.get_clients_for_project("test_project")
            assert len(clients) == 2

        asyncio.run(test_get())

    def test_get_stats(self, manager, mock_websocket):
        """Test getting connection statistics"""

        async def test_stats():
            await manager.connect(mock_websocket)
            await manager.connect(mock_websocket)
            await manager.disconnect(list(manager.connections.keys())[0])

            stats = manager.get_stats()
            assert stats["total_connections"] == 2
            assert stats["total_disconnections"] == 1
            assert stats["active_connections"] == 1

        asyncio.run(test_stats())

    def test_get_connected_clients(self, manager, mock_websocket):
        """Test getting connected clients count"""

        async def test_count():
            await manager.connect(mock_websocket)
            await manager.connect(mock_websocket)

            count = manager.get_connected_clients()
            assert count == 2

        asyncio.run(test_count())

    def test_get_connection_info(self, manager, mock_websocket):
        """Test getting connection info"""

        async def test_info():
            client_id = await manager.connect(
                mock_websocket, project_name="test_project", metadata={"user": "test"}
            )

            info = manager.get_connection_info(client_id)
            assert info is not None
            assert info["client_id"] == client_id
            assert info["project_name"] == "test_project"
            assert info["metadata"] == {"user": "test"}

        asyncio.run(test_info())

    def test_get_connection_info_not_found(self, manager):
        """Test getting info for non-existent connection"""
        info = manager.get_connection_info("nonexistent")
        assert info is None

    def test_broadcast_filters_by_subscription(self, manager, mock_websocket):
        """Test broadcasting filters by subscription"""

        async def test_broadcast():
            client1 = await manager.connect(mock_websocket, project_name="test_project")
            await manager.connect(mock_websocket, project_name="test_project")

            manager.unsubscribe(client1, [EventType.LOG])

            event = RealtimeEvent(type=EventType.LOG, data={"message": "test"})
            count = await manager.broadcast_to_project("test_project", event)
            assert count == 1

        asyncio.run(test_broadcast())


class TestWebSocketManagerHelperMethods:
    """Test extracted helper methods for better testability"""

    def test_create_connection(self):
        """Test _create_connection method"""
        manager = WebSocketManager()
        websocket = MagicMock()

        connection = manager._create_connection(
            client_id="test_id",
            websocket=websocket,
            project_name="test_project",
            metadata={"key": "value"},
        )

        assert connection.client_id == "test_id"
        assert connection.websocket == websocket
        assert connection.project_name == "test_project"
        assert connection.metadata == {"key": "value"}

    def test_create_welcome_event(self):
        """Test _create_welcome_event method"""
        manager = WebSocketManager()
        connection = WSConnection(
            client_id="test_id",
            websocket=MagicMock(),
            project_name="test_project",
            subscribed_events={EventType.LOG, EventType.PROGRESS},
        )

        event = manager._create_welcome_event(connection)
        assert event.type == EventType.HEARTBEAT
        assert event.data["client_id"] == "test_id"
        assert event.data["project"] == "test_project"
        assert "log" in event.data["subscribed_events"]

    def test_get_project_client_ids(self):
        """Test _get_project_client_ids method"""
        manager = WebSocketManager()
        manager.project_connections["test_project"] = {"client1", "client2"}

        ids = manager._get_project_client_ids("test_project")
        assert set(ids) == {"client1", "client2"}

    def test_get_global_client_ids(self):
        """Test _get_global_client_ids method"""
        manager = WebSocketManager()
        manager.global_connections = {"client1", "client2"}

        ids = manager._get_global_client_ids()
        assert set(ids) == {"client1", "client2"}


class TestWebSocketManagerMissingCoverage:
    """Tests for missing coverage in websocket_manager.py."""

    @pytest.mark.asyncio
    async def test_ws_connection_send_json_raises(self):
        """Test WSConnection.send_json re-raises exceptions (line 54-55)."""
        websocket = AsyncMock()
        websocket.send_json.side_effect = RuntimeError("fail")
        connection = WSConnection(client_id="test", websocket=websocket)
        with pytest.raises(RuntimeError):
            await connection.send_json({"test": "data"})

    @pytest.mark.asyncio
    async def test_ws_connection_send_text_raises(self):
        """Test WSConnection.send_text re-raises exceptions (line 61-62)."""
        websocket = AsyncMock()
        websocket.send_text.side_effect = RuntimeError("fail")
        connection = WSConnection(client_id="test", websocket=websocket)
        with pytest.raises(RuntimeError):
            await connection.send_text("test")

    @pytest.mark.asyncio
    async def test_send_to_client_raw_success(self):
        """Test send_to_client_raw sends text successfully (line 280-281)."""
        manager = WebSocketManager()
        websocket = AsyncMock()
        connection = WSConnection(client_id="raw_client", websocket=websocket)
        manager.connections["raw_client"] = connection
        result = await manager.send_to_client_raw("raw_client", "hello")
        assert result is True
        websocket.send_text.assert_called_once_with("hello")

    @pytest.mark.asyncio
    async def test_send_to_client_raw_not_found(self):
        """Test send_to_client_raw when client not found (line 315-318)."""
        manager = WebSocketManager()
        result = await manager.send_to_client_raw("missing", "hello")
        assert result is False

    @pytest.mark.asyncio
    async def test_send_to_client_raw_exception_disconnects(self):
        """Test send_to_client_raw disconnects on exception (line 341-343)."""
        manager = WebSocketManager()
        websocket = AsyncMock()
        websocket.send_text.side_effect = RuntimeError("fail")
        connection = WSConnection(client_id="err_client", websocket=websocket)
        manager.connections["err_client"] = connection
        result = await manager.send_to_client_raw("err_client", "hello")
        assert result is False

    @pytest.mark.asyncio
    async def test_emit_event_with_source(self):
        """Test emit_event with event source (line 381, 398→393)."""
        manager = WebSocketManager()
        websocket = AsyncMock()
        connection = WSConnection(
            client_id="emit_client", websocket=websocket, project_name="proj1"
        )
        manager.connections["emit_client"] = connection
        manager.project_connections["proj1"].add("emit_client")
        event = RealtimeEvent(type=EventType.LOG, data={}, source="proj1")
        count = await manager.emit_event(event)
        assert count == 1

    @pytest.mark.asyncio
    async def test_emit_event_with_project_in_data(self):
        """Test emit_event with project in data (line 423, 459)."""
        manager = WebSocketManager()
        websocket = AsyncMock()
        connection = WSConnection(
            client_id="emit_client2", websocket=websocket, project_name="proj2"
        )
        manager.connections["emit_client2"] = connection
        manager.project_connections["proj2"].add("emit_client2")
        event = RealtimeEvent(type=EventType.LOG, data={"project": "proj2"})
        count = await manager.emit_event(event)
        assert count == 1

    @pytest.mark.asyncio
    async def test_emit_event_broadcast_global(self):
        """Test emit_event with no source or project (line 479→exit)."""
        manager = WebSocketManager()
        websocket = AsyncMock()
        connection = WSConnection(client_id="global_client", websocket=websocket)
        manager.connections["global_client"] = connection
        manager.global_connections.add("global_client")
        event = RealtimeEvent(type=EventType.LOG, data={})
        count = await manager.emit_event(event)
        assert count == 1

    @pytest.mark.asyncio
    async def test_send_to_client_raw_exception_triggers_disconnect(self):
        """Test send_to_client_raw with exception triggers disconnect (line 485→exit)."""
        manager = WebSocketManager()
        websocket = AsyncMock()
        websocket.send_text.side_effect = RuntimeError("boom")
        connection = WSConnection(client_id="dc_client", websocket=websocket)
        manager.connections["dc_client"] = connection
        result = await manager.send_to_client_raw("dc_client", "fail")
        assert result is False

    @pytest.mark.asyncio
    async def test_handle_client_message_ping(self):
        """Test handle_client_message with ping type (line 489→exit, 492→exit)."""
        manager = WebSocketManager()
        websocket = AsyncMock()
        connection = WSConnection(client_id="ping_client", websocket=websocket)
        manager.connections["ping_client"] = connection
        await manager.handle_client_message("ping_client", {"type": "ping"})
        assert connection.last_ping is not None


class TestWebSocketManagerAdditionalCoverage:
    """Tests for remaining missing coverage lines."""

    @pytest.mark.asyncio
    async def test_unregister_removes_subscriptions(self):
        """Test _unregister_connection deletes subscriptions (line 270)."""
        manager = WebSocketManager()
        websocket = AsyncMock()
        client_id = await manager.connect(websocket, project_name="proj")
        manager.subscriptions[client_id] = {EventType.LOG}
        await manager.disconnect(client_id)
        assert client_id not in manager.subscriptions

    @pytest.mark.asyncio
    async def test_close_websocket_exception_suppressed(self):
        """Test _close_websocket suppresses exceptions (lines 280-281)."""
        manager = WebSocketManager()
        websocket = AsyncMock()
        websocket.close.side_effect = RuntimeError("socket closed")
        connection = WSConnection(client_id="c1", websocket=websocket, project_name="p")
        manager.connections["c1"] = connection
        manager.project_connections["p"].add("c1")
        manager.total_connections = 1
        await manager.disconnect("c1")
        assert "c1" not in manager.connections

    @pytest.mark.asyncio
    async def test_send_message_to_connection_exception_disconnects(self):
        """Test _send_message_to_connection disconnects on failure (lines 315-318)."""
        manager = WebSocketManager()
        websocket = AsyncMock()
        websocket.send_json.side_effect = RuntimeError("dead")
        connection = WSConnection(client_id="c1", websocket=websocket, project_name="p")
        manager.connections["c1"] = connection
        manager.project_connections["p"].add("c1")
        result = await manager._send_message_to_connection(connection, {"msg": "test"})
        assert result is False
        assert "c1" not in manager.connections

    @pytest.mark.asyncio
    async def test_broadcast_global_no_clients(self):
        """Test broadcast_global returns 0 when no global clients (line 381)."""
        manager = WebSocketManager()
        event = RealtimeEvent(type=EventType.LOG, data={})
        count = await manager.broadcast_global(event)
        assert count == 0

    @pytest.mark.asyncio
    async def test_broadcast_to_clients_missing_connection(self):
        """Test _broadcast_to_clients when connection missing (line 398→393)."""
        manager = WebSocketManager()
        manager.connections.pop("ghost", None)
        event = RealtimeEvent(type=EventType.LOG, data={})
        count = await manager._broadcast_to_clients(["ghost"], event)
        assert count == 0

    def test_unsubscribe_nonexistent_client(self):
        """Test unsubscribe returns False for non-existent client (line 459)."""
        manager = WebSocketManager()
        result = manager.unsubscribe("nonexistent", [EventType.LOG])
        assert result is False

    @pytest.mark.asyncio
    async def test_handle_subscribe_empty_event_types(self):
        """Test handle_client_message subscribe with empty event_types (line 479→exit)."""
        manager = WebSocketManager()
        websocket = AsyncMock()
        client_id = await manager.connect(websocket)
        old_events = manager.connections[client_id].subscribed_events.copy()
        await manager.handle_client_message(client_id, {"type": "subscribe", "event_types": []})
        assert manager.connections[client_id].subscribed_events == old_events

    @pytest.mark.asyncio
    async def test_handle_unsubscribe_empty_event_types(self):
        """Test handle_client_message unsubscribe with empty event_types (line 485→exit)."""
        manager = WebSocketManager()
        websocket = AsyncMock()
        client_id = await manager.connect(websocket)
        old_events = manager.connections[client_id].subscribed_events.copy()
        await manager.handle_client_message(client_id, {"type": "unsubscribe", "event_types": []})
        assert manager.connections[client_id].subscribed_events == old_events

    @pytest.mark.asyncio
    async def test_handle_ping_unknown_client(self):
        """Test handle_client_message ping for unknown client (line 489→exit, 492→exit)."""
        manager = WebSocketManager()
        await manager.handle_client_message("ghost", {"type": "ping"})
        assert "ghost" not in manager.connections
