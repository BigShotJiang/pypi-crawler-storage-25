"""
Comprehensive tests for agent_registry.py to increase coverage to 90%+.
Tests agent registration, retrieval, and dependency validation.
"""

from pathlib import Path

import pytest

from novel_harness.core.agent import AgentCategory
from novel_harness.core.agent_registry import AgentRegistry
from novel_harness.core.language_config import LanguageCode


class TestAgentRegistryInit:
    """Test AgentRegistry initialization."""

    def test_init_with_string_path(self, tmp_path):
        """Test initialization with string path."""
        registry = AgentRegistry(str(tmp_path))

        assert isinstance(registry.agents_dir, Path)
        assert isinstance(registry.loader, object)

    def test_init_with_path_object(self, tmp_path):
        """Test initialization with Path object."""
        registry = AgentRegistry(tmp_path)

        assert isinstance(registry.agents_dir, Path)

    def test_init_loads_agents(self, tmp_path):
        """Test that initialization loads agents."""
        (tmp_path / "test_agent.md").write_text("""---
name: test_agent
description: Test description
category: analytical
---
Instructions""")

        registry = AgentRegistry(str(tmp_path))

        assert "test_agent" in registry._agents


class TestGetAgent:
    """Test get_agent method."""

    def test_get_existing_agent(self, tmp_path):
        """Test getting existing agent."""
        (tmp_path / "test_agent.md").write_text("""---
name: test_agent
description: Test description
category: analytical
---
Instructions""")

        registry = AgentRegistry(str(tmp_path))
        agent = registry.get_agent("test_agent")

        assert agent is not None
        assert agent.name == "test_agent"

    def test_get_missing_agent(self, tmp_path):
        """Test getting non-existent agent."""
        registry = AgentRegistry(str(tmp_path))

        agent = registry.get_agent("nonexistent")

        assert agent is None


class TestGetAllAgents:
    """Test get_all_agents method."""

    def test_get_all_agents_empty(self, tmp_path):
        """Test getting all agents when empty."""
        registry = AgentRegistry(str(tmp_path))

        agents = registry.get_all_agents()

        assert agents == []

    def test_get_all_agents_with_agents(self, tmp_path):
        """Test getting all agents."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
---
Instructions 1""")
        (tmp_path / "agent2.md").write_text("""---
name: agent2
description: Second agent
category: creative
---
Instructions 2""")

        registry = AgentRegistry(str(tmp_path))
        agents = registry.get_all_agents()

        assert len(agents) == 2
        agent_names = [a.name for a in agents]
        assert "agent1" in agent_names
        assert "agent2" in agent_names


class TestGetAgentsByCategory:
    """Test get_agents_by_category method."""

    def test_get_agents_by_category(self, tmp_path):
        """Test getting agents by category."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
---
Instructions 1""")
        (tmp_path / "agent2.md").write_text("""---
name: agent2
description: Second agent
category: creative
---
Instructions 2""")
        (tmp_path / "agent3.md").write_text("""---
name: agent3
description: Third agent
category: analytical
---
Instructions 3""")

        registry = AgentRegistry(str(tmp_path))
        analytical_agents = registry.get_agents_by_category(AgentCategory.ANALYTICAL)

        assert len(analytical_agents) == 2
        assert all(a.category == AgentCategory.ANALYTICAL for a in analytical_agents)

    def test_get_agents_by_category_none(self, tmp_path):
        """Test getting agents by non-existent category."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
---
Instructions 1""")

        registry = AgentRegistry(str(tmp_path))
        creative_agents = registry.get_agents_by_category(AgentCategory.CREATIVE)

        assert creative_agents == []


class TestValidateDependencies:
    """Test validate_dependencies method."""

    def test_validate_missing_agent(self, tmp_path):
        """Test validating non-existent agent."""
        registry = AgentRegistry(str(tmp_path))

        missing = registry.validate_dependencies("nonexistent")

        assert len(missing) == 1
        assert "not found" in missing[0]

    def test_validate_no_dependencies(self, tmp_path):
        """Test validating agent with no dependencies."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
---
Instructions 1""")

        registry = AgentRegistry(str(tmp_path))
        missing = registry.validate_dependencies("agent1")

        assert missing == []

    def test_validate_satisfied_dependencies(self, tmp_path):
        """Test validating agent with satisfied dependencies."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
---
Instructions 1""")
        (tmp_path / "agent2.md").write_text("""---
name: agent2
description: Second agent
category: analytical
dependencies:
  - agent1
---
Instructions 2""")

        registry = AgentRegistry(str(tmp_path))
        missing = registry.validate_dependencies("agent2")

        assert missing == []

    def test_validate_missing_dependencies(self, tmp_path):
        """Test validating agent with missing dependencies."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
dependencies:
  - nonexistent
---
Instructions 1""")

        registry = AgentRegistry(str(tmp_path))
        missing = registry.validate_dependencies("agent1")

        assert "nonexistent" in missing


class TestGetExecutionOrder:
    """Test get_execution_order method."""

    def test_execution_order_single_agent(self, tmp_path):
        """Test execution order with single agent."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
---
Instructions 1""")

        registry = AgentRegistry(str(tmp_path))
        order = registry.get_execution_order(["agent1"])

        assert order == ["agent1"]

    def test_execution_order_with_dependencies(self, tmp_path):
        """Test execution order with dependencies."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
---
Instructions 1""")
        (tmp_path / "agent2.md").write_text("""---
name: agent2
description: Second agent
category: analytical
dependencies:
  - agent1
---
Instructions 2""")

        registry = AgentRegistry(str(tmp_path))
        order = registry.get_execution_order(["agent1", "agent2"])

        assert order.index("agent1") < order.index("agent2")

    def test_execution_order_circular_dependency(self, tmp_path):
        """Test execution order with circular dependency."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
dependencies:
  - agent2
---
Instructions 1""")
        (tmp_path / "agent2.md").write_text("""---
name: agent2
description: Second agent
category: analytical
dependencies:
  - agent1
---
Instructions 2""")

        registry = AgentRegistry(str(tmp_path))

        with pytest.raises(ValueError, match="Circular dependency"):
            registry.get_execution_order(["agent1", "agent2"])

    def test_execution_order_self_dependency(self, tmp_path):
        """Test execution order with self-dependency."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
dependencies:
  - agent1
---
Instructions 1""")

        registry = AgentRegistry(str(tmp_path))

        with pytest.raises(ValueError, match="Circular dependency"):
            registry.get_execution_order(["agent1"])

    def test_execution_order_empty_list(self, tmp_path):
        """Test execution order with empty list."""
        registry = AgentRegistry(str(tmp_path))
        order = registry.get_execution_order([])

        assert order == []


class TestReloadAgent:
    """Test reload_agent method."""

    def test_reload_existing_agent(self, tmp_path):
        """Test reloading existing agent."""
        agent_file = tmp_path / "agent1.md"
        agent_file.write_text("""---
name: agent1
description: First agent
category: analytical
---
Instructions 1""")

        registry = AgentRegistry(str(tmp_path))

        agent_file.write_text("""---
name: agent1
description: Updated agent
category: analytical
---
Updated instructions""")

        agent = registry.reload_agent("agent1")

        assert agent is not None
        assert agent.description == "Updated agent"

    def test_reload_nonexistent_agent(self, tmp_path):
        """Test reloading non-existent agent."""
        registry = AgentRegistry(str(tmp_path))

        agent = registry.reload_agent("nonexistent")

        assert agent is None


class TestReloadAll:
    """Test reload_all method."""

    def test_reload_all(self, tmp_path):
        """Test reloading all agents."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
---
Instructions 1""")

        registry = AgentRegistry(str(tmp_path))

        (tmp_path / "agent2.md").write_text("""---
name: agent2
description: Second agent
category: analytical
---
Instructions 2""")

        registry.reload_all()

        agents = registry.get_all_agents()
        agent_names = [a.name for a in agents]
        assert "agent1" in agent_names
        assert "agent2" in agent_names


class TestListAgents:
    """Test list_agents method."""

    def test_list_agents(self, tmp_path):
        """Test listing all agents."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
---
Instructions 1""")
        (tmp_path / "agent2.md").write_text("""---
name: agent2
description: Second agent
category: analytical
---
Instructions 2""")

        registry = AgentRegistry(str(tmp_path))
        listing = registry.list_agents()

        assert "agent1" in listing
        assert listing["agent1"] == "First agent"
        assert "agent2" in listing
        assert listing["agent2"] == "Second agent"


class TestGetAgentCount:
    """Test get_agent_count method."""

    def test_get_agent_count_empty(self, tmp_path):
        """Test count with no agents."""
        registry = AgentRegistry(str(tmp_path))

        count = registry.get_agent_count()

        assert count == 0

    def test_get_agent_count_with_agents(self, tmp_path):
        """Test count with agents."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
---
Instructions 1""")
        (tmp_path / "agent2.md").write_text("""---
name: agent2
description: Second agent
category: analytical
---
Instructions 2""")

        registry = AgentRegistry(str(tmp_path))
        count = registry.get_agent_count()

        assert count == 2


class TestAgentExists:
    """Test agent_exists method."""

    def test_agent_exists_true(self, tmp_path):
        """Test checking existing agent."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
---
Instructions 1""")

        registry = AgentRegistry(str(tmp_path))
        exists = registry.agent_exists("agent1")

        assert exists is True

    def test_agent_exists_false(self, tmp_path):
        """Test checking non-existent agent."""
        registry = AgentRegistry(str(tmp_path))
        exists = registry.agent_exists("nonexistent")

        assert exists is False


class TestEdgeCases:
    """Test edge cases."""

    def test_agent_with_multiple_dependencies(self, tmp_path):
        """Test agent with multiple dependencies."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
---
Instructions 1""")
        (tmp_path / "agent2.md").write_text("""---
name: agent2
description: Second agent
category: analytical
---
Instructions 2""")
        (tmp_path / "agent3.md").write_text("""---
name: agent3
description: Third agent
category: analytical
dependencies:
  - agent1
  - agent2
---
Instructions 3""")

        registry = AgentRegistry(str(tmp_path))
        order = registry.get_execution_order(["agent3", "agent1", "agent2"])

        assert order.index("agent1") < order.index("agent3")
        assert order.index("agent2") < order.index("agent3")

    def test_execution_order_subset(self, tmp_path):
        """Test execution order with subset of agents."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
---
Instructions 1""")
        (tmp_path / "agent2.md").write_text("""---
name: agent2
description: Second agent
category: analytical
dependencies:
  - agent1
---
Instructions 2""")
        (tmp_path / "agent3.md").write_text("""---
name: agent3
description: Third agent
category: analytical
---
Instructions 3""")

        registry = AgentRegistry(str(tmp_path))
        # Only request agent2, it should include agent1 as dependency
        order = registry.get_execution_order(["agent1", "agent2"])

        assert "agent1" in order
        assert "agent2" in order
        assert order.index("agent1") < order.index("agent2")


class TestGetExecutionOrderMissingAgent:
    """Test execution order with agent not in registry (lines 134→139, 136→135)."""

    def test_execution_order_with_unknown_agent(self, tmp_path):
        """Test execution order when agent not found but name is in list."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
---
Instructions 1""")
        registry = AgentRegistry(str(tmp_path))
        order = registry.get_execution_order(["agent1", "unknown_agent"])
        assert "agent1" in order
        assert "unknown_agent" in order


class TestSwitchLanguageAndSupported:
    """Test switch_language and get_supported_languages (lines 196-201)."""

    def test_switch_language_same(self, tmp_path):
        """Test switch_language with same language returns early."""
        registry = AgentRegistry(str(tmp_path))
        initial_loader = id(registry.loader)
        registry.switch_language(LanguageCode.EN)
        assert id(registry.loader) == initial_loader

    def test_switch_language_different(self, tmp_path):
        """Test switch_language with different language reloads."""
        registry = AgentRegistry(str(tmp_path))
        initial_loader = id(registry.loader)
        registry.switch_language(LanguageCode.ZH_CN)
        assert id(registry.loader) != initial_loader
        assert registry.language == LanguageCode.ZH_CN

    def test_get_supported_languages(self, tmp_path):
        """Test get_supported_languages returns list."""
        registry = AgentRegistry(str(tmp_path))
        langs = registry.get_supported_languages()
        assert isinstance(langs, list)
