"""Test coverage for core/step_executor.py."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from core.step_executor import StepExecutor, SystemActionHandler
from core.workflow_loader import OnFailure, WorkflowStep


class TestSystemActionHandler:
    @pytest.fixture
    def handler(self):
        """Create a handler instance for testing"""
        storage = MagicMock()
        git_manager = MagicMock()
        work_dir = "/tmp/test"
        return SystemActionHandler(storage, git_manager, work_dir)

    def test_initialization(self, handler):
        """Test handler initialization"""
        assert handler.storage is not None
        assert handler.git_manager is not None
        assert handler.work_dir == Path("/tmp/test")

    def test_execute_action_create_directories(self, handler):
        """Test create_directories action"""
        with patch("pathlib.Path.mkdir"):
            result = handler.execute_action(
                "create_directories", {"directories": ["chapters", "reports"]}, "test_project"
            )
            assert result["success"] is True

    def test_execute_action_git_init(self, handler):
        """Test git_init action"""
        result = handler.execute_action("git_init", {}, "test_project")
        assert result["success"] is True
        handler.git_manager.initialize_repository.assert_called_once()

    def test_execute_action_git_commit(self, handler):
        """Test git_commit action"""
        result = handler.execute_action("git_commit", {"message": "Test commit"}, "test_project")
        assert result["success"] is True
        handler.git_manager.auto_commit_step.assert_called_once()

    def test_execute_action_git_tag(self, handler):
        """Test git_tag action"""
        result = handler.execute_action(
            "git_tag", {"tag": "v1.0", "message": "Version 1.0"}, "test_project"
        )
        assert result["success"] is True

    def test_execute_action_load_yaml(self, handler):
        """Test load_yaml action"""
        handler.storage.read_yaml.return_value = {"key": "value"}
        result = handler.execute_action("load_yaml", {"file": "test.yaml"}, "test_project")
        assert result["success"] is True
        assert result["meta"] == {"key": "value"}

    def test_execute_action_load_markdown(self, handler):
        """Test load_markdown action"""
        handler.storage.read_markdown.return_value = "# Test Content"
        result = handler.execute_action("load_markdown", {"file": "test.md"}, "test_project")
        assert result["success"] is True
        assert result["content"] == "# Test Content"

    def test_execute_action_load_markdown_optional(self, handler):
        """Test load_markdown with optional=True"""
        handler.storage.read_markdown.side_effect = Exception("Not found")
        result = handler.execute_action(
            "load_markdown", {"file": "test.md", "optional": True}, "test_project"
        )
        assert result["success"] is True
        assert result["content"] is None

    def test_execute_action_load_previous_chapters(self, handler):
        """Test load_previous_chapters action"""
        handler.storage.read_markdown.return_value = "Chapter content"
        result = handler.execute_action(
            "load_previous_chapters", {"current_chapter": 3}, "test_project"
        )
        assert result["success"] is True
        assert "chapters" in result

    def test_execute_action_load_chapter_range(self, handler):
        """Test load_chapter_range action"""
        handler.storage.read_markdown.return_value = "Chapter content"
        result = handler.execute_action(
            "load_chapter_range", {"start_chapter": 1, "end_chapter": 3}, "test_project"
        )
        assert result["success"] is True
        assert "chapters" in result

    def test_execute_action_load_all_chapters(self, handler):
        """Test load_all_chapters action"""
        handler.storage.read_markdown.return_value = "Content"
        result = handler.execute_action("load_all_chapters", {"count": 5}, "test_project")
        assert result["success"] is True

    def test_execute_action_check_status(self, handler):
        """Test check_status action"""
        result = handler.execute_action(
            "check_status", {"status": "complete", "condition": "complete"}, "test_project"
        )
        assert result["success"] is True
        assert result["result"] is True

    def test_execute_action_check_issues(self, handler):
        """Test check_issues action"""
        result = handler.execute_action(
            "check_issues", {"issues": ["issue1", "issue2"]}, "test_project"
        )
        assert result["success"] is True
        assert result["result"] is True

    def test_execute_action_get_chapter_count(self, handler):
        """Test get_chapter_count action"""
        with (
            patch("pathlib.Path.exists", return_value=True),
            patch("pathlib.Path.glob", return_value=["file1.md", "file2.md"]),
        ):
            result = handler.execute_action("get_chapter_count", {}, "test_project")
            assert result["success"] is True
            assert result["count"] == 2

    def test_execute_action_get_target_chapter_count(self, handler):
        """Test get_target_chapter_count action"""
        result = handler.execute_action(
            "get_target_chapter_count", {"user_target": 50}, "test_project"
        )
        assert result["success"] is True
        assert result["count"] == 50

    def test_execute_action_generate_report(self, handler):
        """Test generate_report action"""
        result = handler.execute_action("generate_report", {}, "test_project")
        assert result["success"] is True
        assert "final_report" in result

    def test_execute_action_unknown_action(self, handler):
        """Test unknown action"""
        result = handler.execute_action("unknown_action", {}, "test_project")
        assert result["success"] is False
        assert "error" in result

    def test_execute_action_exception_handling(self, handler):
        """Test exception handling in action execution"""
        handler.storage.read_yaml.side_effect = Exception("Read error")
        result = handler.execute_action("load_yaml", {"file": "test.yaml"}, "test_project")
        assert result["success"] is False


class TestStepExecutor:
    @pytest.fixture
    def executor(self):
        """Create an executor instance for testing"""
        agent_integration = MagicMock()
        storage = MagicMock()
        git_manager = MagicMock()
        work_dir = "/tmp/test"
        return StepExecutor(agent_integration, storage, git_manager, work_dir)

    def test_initialization(self, executor):
        """Test executor initialization"""
        assert executor.agent_integration is not None
        assert executor.storage is not None
        assert executor.git_manager is not None
        assert executor.resolver is not None
        assert executor.system_handler is not None

    def test_execute_step_with_condition_met(self, executor):
        """Test executing step when condition is met"""
        step = WorkflowStep(
            step=1,
            name="test_step",
            agent="TestAgent",
            input={"prompt": "test"},
            condition="${value} == 5",
        )
        executor.agent_integration.execute_agent_step.return_value = {"success": True}
        result = executor.execute_step(
            step, "test_project", variables={"value": 5}, step_outputs={}, config={}
        )
        assert result["success"] is True
        assert result["skipped"] is False

    def test_execute_step_with_condition_not_met(self, executor):
        """Test executing step when condition is not met"""
        step = WorkflowStep(
            step=1,
            name="test_step",
            agent="TestAgent",
            input={"prompt": "test"},
            condition="${value} == 10",
        )
        result = executor.execute_step(
            step, "test_project", variables={"value": 5}, step_outputs={}, config={}
        )
        assert result["skipped"] is True
        assert result["success"] is True

    def test_execute_step_with_agent(self, executor):
        """Test executing agent step"""
        step = WorkflowStep(
            step=1, name="agent_step", agent="TestAgent", input={"prompt": "Generate content"}
        )
        executor.agent_integration.execute_agent_step.return_value = {
            "success": True,
            "output": {"content": "Generated"},
        }
        result = executor.execute_step(
            step, "test_project", variables={}, step_outputs={}, config={}
        )
        assert result["success"] is True
        executor.agent_integration.execute_agent_step.assert_called_once()

    def test_execute_step_with_workflow(self, executor):
        """Test executing workflow step"""
        step = WorkflowStep(
            step=1, name="workflow_step", workflow="sub_workflow", input={"var": "value"}
        )
        with patch("core.workflow_executor.WorkflowExecutor") as mock_wf_exec:
            mock_executor = MagicMock()
            mock_executor.execute_workflow.return_value = {"success": True}
            mock_wf_exec.return_value = mock_executor

            result = executor.execute_step(
                step, "test_project", variables={}, step_outputs={}, config={}
            )
            assert result["success"] is True

    def test_execute_step_with_action(self, executor):
        """Test executing system action step"""
        step = WorkflowStep(
            step=1, name="action_step", action="create_directories", input={"directories": ["test"]}
        )
        result = executor.execute_step(
            step, "test_project", variables={}, step_outputs={}, config={}
        )
        assert result["success"] is True

    def test_execute_step_no_step_type(self, executor):
        """Test executing step without agent, workflow, or action"""
        step = WorkflowStep(step=1, name="invalid_step", input={}, on_failure=OnFailure.CONTINUE)
        result = executor.execute_step(
            step, "test_project", variables={}, step_outputs={}, config={}
        )
        assert result["success"] is False
        assert "error" in result

    def test_execute_step_with_on_failure_stop(self, executor):
        """Test step with on_failure=stop raises exception"""
        step = WorkflowStep(
            step=1, name="failing_step", agent="TestAgent", input={}, on_failure=OnFailure.STOP
        )
        executor.agent_integration.execute_agent_step.return_value = {
            "success": False,
            "error": "Test error",
        }
        with pytest.raises(Exception):
            executor.execute_step(step, "test_project", variables={}, step_outputs={}, config={})

    def test_execute_step_with_on_failure_continue(self, executor):
        """Test step with on_failure=continue returns error"""
        step = WorkflowStep(
            step=1, name="failing_step", agent="TestAgent", input={}, on_failure=OnFailure.CONTINUE
        )
        executor.agent_integration.execute_agent_step.return_value = {
            "success": False,
            "error": "Test error",
        }
        result = executor.execute_step(
            step, "test_project", variables={}, step_outputs={}, config={}
        )
        assert result["success"] is False
        assert result["error"] == "Test error"

    def test_execute_step_exception_handling(self, executor):
        """Test exception handling in step execution"""
        step = WorkflowStep(
            step=1, name="error_step", agent="TestAgent", input={}, on_failure=OnFailure.CONTINUE
        )
        executor.agent_integration.execute_agent_step.side_effect = Exception("Unexpected error")
        result = executor.execute_step(
            step, "test_project", variables={}, step_outputs={}, config={}
        )
        assert result["success"] is False

    def test_execute_step_with_input_resolution(self, executor):
        """Test step with variable input resolution"""
        step = WorkflowStep(
            step=1,
            name="test_step",
            agent="TestAgent",
            input={"prompt": "${title}", "count": "${number}"},
        )
        executor.agent_integration.execute_agent_step.return_value = {"success": True}
        executor.execute_step(
            step,
            "test_project",
            variables={"title": "My Novel", "number": 5},
            step_outputs={},
            config={},
        )
        call_args = executor.agent_integration.execute_agent_step.call_args
        assert "My Novel" in str(call_args)
        assert "5" in str(call_args)

    def test_execute_step_with_output_resolution(self, executor):
        """Test step with output resolution"""
        step = WorkflowStep(
            step=1,
            name="test_step",
            agent="TestAgent",
            input={},
            output={"result": "${output.content}"},
        )
        executor.agent_integration.execute_agent_step.return_value = {
            "success": True,
            "output": {"content": "Generated content"},
        }
        result = executor.execute_step(
            step, "test_project", variables={}, step_outputs={}, config={}
        )
        assert result["success"] is True

    def test_load_markdown_non_optional_error_propagates_to_wrapper(self):
        handler = SystemActionHandler(MagicMock(), MagicMock(), "/tmp/test")
        handler.storage.read_markdown.side_effect = RuntimeError("missing")
        result = handler.execute_action("load_markdown", {"file": "x.md"}, "proj")
        assert result["success"] is False

    def test_load_previous_chapters_reads_existing_only(self):
        handler = SystemActionHandler(MagicMock(), MagicMock(), "/tmp/test")

        def fake_exists(self):
            return self.name in {"chapter_1.md", "chapter_3.md"}

        with patch("pathlib.Path.exists", fake_exists):
            handler.storage.read_markdown.side_effect = ["c1", "c3"]
            result = handler.execute_action(
                "load_previous_chapters", {"current_chapter": 4}, "proj"
            )
            assert result["success"] is True
            assert result["chapters"] == "c1\n\nc3"

    def test_load_chapter_range_reads_existing_only(self):
        handler = SystemActionHandler(MagicMock(), MagicMock(), "/tmp/test")

        def fake_exists(self):
            return self.name in {"chapter_2.md", "chapter_4.md"}

        with patch("pathlib.Path.exists", fake_exists):
            handler.storage.read_markdown.side_effect = ["c2", "c4"]
            result = handler.execute_action(
                "load_chapter_range", {"start_chapter": 1, "end_chapter": 4}, "proj"
            )
            assert result["chapters"] == ["c2", "c4"]

    def test_get_chapter_count_zero_when_dir_missing(self):
        handler = SystemActionHandler(MagicMock(), MagicMock(), "/tmp/test")
        with patch("pathlib.Path.exists", return_value=False):
            result = handler.execute_action("get_chapter_count", {}, "proj")
            assert result["count"] == 0

    def test_get_target_chapter_count_from_meta(self):
        handler = SystemActionHandler(MagicMock(), MagicMock(), "/tmp/test")
        with patch("pathlib.Path.exists", return_value=True):
            handler.storage.read_yaml.return_value = {"chapter_count_target": 42}
            result = handler.execute_action("get_target_chapter_count", {}, "proj")
            assert result["count"] == 42

    def test_get_target_chapter_count_default(self):
        handler = SystemActionHandler(MagicMock(), MagicMock(), "/tmp/test")
        with patch("pathlib.Path.exists", return_value=False):
            result = handler.execute_action("get_target_chapter_count", {}, "proj")
            assert result["count"] == 30

    def test_display_summary_action(self):
        handler = SystemActionHandler(MagicMock(), MagicMock(), "/tmp/test")
        result = handler.execute_action("display_summary", {}, "proj")
        assert result["success"] is True
        assert result["summary_displayed"] is True

    def test_execute_step_agent_failure_stop_re_raises(self, executor):
        step = WorkflowStep(step=1, name="s", agent="a", input={}, on_failure=OnFailure.STOP)
        executor.agent_integration.execute_agent_step.side_effect = RuntimeError("boom")
        with pytest.raises(RuntimeError):
            executor.execute_step(step, "p", variables={}, step_outputs={}, config={})
