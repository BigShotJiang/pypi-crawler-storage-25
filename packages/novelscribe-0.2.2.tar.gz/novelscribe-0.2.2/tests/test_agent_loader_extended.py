"""
Comprehensive tests for agent_loader.py to increase coverage to 90%+.
Tests agent loading, parsing, and error handling.
"""

from pathlib import Path

import pytest

from novel_harness.core.agent import AgentCategory
from novel_harness.core.agent_loader import AgentLoader
from novel_harness.core.language_config import LanguageCode


class TestAgentLoaderInit:
    """Test AgentLoader initialization."""

    def test_init_with_string_path(self):
        """Test initialization with string path."""
        loader = AgentLoader("/path/to/agents")

        assert isinstance(loader.agents_dir, Path)
        assert str(loader.agents_dir) == "/path/to/agents"

    def test_init_with_path_object(self):
        """Test initialization with Path object."""
        loader = AgentLoader(Path("/path/to/agents"))

        assert isinstance(loader.agents_dir, Path)


class TestLoadAgent:
    """Test load_agent method."""

    def test_load_agent_file_not_found(self):
        """Test loading non-existent file raises error."""
        loader = AgentLoader("/path/to/agents")

        with pytest.raises(FileNotFoundError, match="Agent file not found"):
            loader.load_agent("/nonexistent/file.md")

    def test_load_agent_empty_file(self, tmp_path):
        """Test loading empty file raises error."""
        agent_file = tmp_path / "test.md"
        agent_file.write_text("")

        loader = AgentLoader(str(tmp_path))

        with pytest.raises(ValueError, match="must start with YAML frontmatter"):
            loader.load_agent(agent_file)


class TestParseAgent:
    """Test parse_agent method."""

    def test_parse_agent_missing_frontmatter(self):
        """Test parsing without YAML frontmatter raises error."""
        loader = AgentLoader("/path/to/agents")

        with pytest.raises(ValueError, match="must start with YAML frontmatter"):
            loader.parse_agent("Just plain text content")

    def test_parse_agent_incomplete_frontmatter(self):
        """Test parsing with incomplete frontmatter raises error."""
        loader = AgentLoader("/path/to/agents")

        # Empty frontmatter with no body
        empty_content = """---
name: test_agent
---
"""
        with pytest.raises(ValueError, match="Missing required field"):
            loader.parse_agent(empty_content)

    def test_parse_agent_invalid_yaml(self):
        """Test parsing with invalid YAML raises error."""
        loader = AgentLoader("/path/to/agents")

        content = """---
name: test_agent
invalid: yaml: content
---
Instructions"""

        with pytest.raises(ValueError, match="Invalid YAML frontmatter"):
            loader.parse_agent(content)

    def test_parse_agent_yaml_not_dict(self):
        """Test parsing with YAML that's not a dict raises error."""
        loader = AgentLoader("/path/to/agents")

        content = """---
- list item
- another item
---
Instructions"""

        with pytest.raises(ValueError, match="YAML frontmatter must be a dictionary"):
            loader.parse_agent(content)

    def test_parse_agent_missing_required_field(self):
        """Test parsing with missing required field raises error."""
        loader = AgentLoader("/path/to/agents")

        content = """---
name: test_agent
description: Test description
---
Instructions"""

        with pytest.raises(ValueError, match="Missing required field"):
            loader.parse_agent(content)

    def test_parse_agent_invalid_category(self):
        """Test parsing with invalid category raises error."""
        loader = AgentLoader("/path/to/agents")

        content = """---
name: test_agent
description: Test description
category: invalid_category
---
Instructions"""

        with pytest.raises(ValueError, match="Invalid agent category"):
            loader.parse_agent(content)

    def test_parse_agent_string_input_schema(self):
        """Test parsing with string instead of list for input."""
        loader = AgentLoader("/path/to/agents")

        content = """---
name: test_agent
description: Test description
category: analytical
input: prompt
---
Instructions"""

        agent = loader.parse_agent(content)

        assert isinstance(agent.input_schema, list)
        assert "prompt" in agent.input_schema

    def test_parse_agent_string_output_schema(self):
        """Test parsing with string instead of list for output."""
        loader = AgentLoader("/path/to/agents")

        content = """---
name: test_agent
description: Test description
category: analytical
input: prompt
output: chapter
---
Instructions"""

        agent = loader.parse_agent(content)

        assert isinstance(agent.output_schema, list)
        assert "chapter" in agent.output_schema

    def test_parse_agent_string_dependencies(self):
        """Test parsing with string instead of list for dependencies."""
        loader = AgentLoader("/path/to/agents")

        content = """---
name: test_agent
description: Test description
category: analytical
input: prompt
dependencies: dep_agent
---
Instructions"""

        agent = loader.parse_agent(content)

        assert isinstance(agent.dependencies, list)
        assert "dep_agent" in agent.dependencies

    def test_parse_agent_with_version(self):
        """Test parsing with explicit version."""
        loader = AgentLoader("/path/to/agents")

        content = """---
name: test_agent
description: Test description
category: analytical
version: 2.0.0
---
Instructions"""

        agent = loader.parse_agent(content)

        assert agent.version == "2.0.0"

    def test_parse_agent_default_version(self):
        """Test parsing uses default version."""
        loader = AgentLoader("/path/to/agents")

        content = """---
name: test_agent
description: Test description
category: analytical
---
Instructions"""

        agent = loader.parse_agent(content)

        assert agent.version == "1.0.0"

    def test_parse_agent_whitespace_handling(self):
        """Test parsing handles whitespace correctly."""
        loader = AgentLoader("/path/to/agents")

        content = """

---
name: test_agent
description: Test description
category: analytical
---

Instructions

"""

        agent = loader.parse_agent(content)

        assert agent.name == "test_agent"
        assert "Instructions" in agent.instructions

    def test_parse_agent_with_file_path(self):
        """Test parsing includes file path."""
        loader = AgentLoader("/path/to/agents")

        content = """---
name: test_agent
description: Test description
category: analytical
---
Instructions"""

        agent = loader.parse_agent(content, Path("/path/to/agent.md"))

        assert agent.file_path == "/path/to/agent.md"

    def test_parse_agent_without_file_path(self):
        """Test parsing without file path."""
        loader = AgentLoader("/path/to/agents")

        content = """---
name: test_agent
description: Test description
category: analytical
---
Instructions"""

        agent = loader.parse_agent(content, None)

        assert agent.file_path is None


class TestLoadAllAgents:
    """Test load_all_agents method."""

    def test_load_all_agents_nonexistent_directory(self):
        """Test loading from non-existent directory."""
        loader = AgentLoader("/nonexistent/directory")

        agents = loader.load_all_agents()

        assert agents == []

    def test_load_all_agents_empty_directory(self, tmp_path):
        """Test loading from empty directory."""
        loader = AgentLoader(str(tmp_path))

        agents = loader.load_all_agents()

        assert agents == []


class TestReloadAgent:
    """Test reload_agent method."""

    def test_reload_agent_not_found(self, tmp_path):
        """Test reloading non-existent agent returns None."""
        loader = AgentLoader(str(tmp_path))

        result = loader.reload_agent("nonexistent_agent")

        assert result is None

    def test_reload_agent_success(self, tmp_path):
        """Test successful agent reload."""
        agent_file = tmp_path / "test_agent.md"
        agent_file.write_text("""---
name: test_agent
description: Test description
category: analytical
---
Instructions""")

        loader = AgentLoader(str(tmp_path))
        result = loader.reload_agent("test_agent")

        assert result is not None
        assert result.name == "test_agent"


class TestEdgeCases:
    """Test edge cases."""

    def test_parse_agent_complex_frontmatter(self):
        """Test parsing with complex frontmatter."""
        loader = AgentLoader("/path/to/agents")

        content = """---
name: test_agent
description: Test description
category: analytical
version: 1.0.0
input:
  - prompt
  - context
output:
  - chapter
  - metadata
dependencies:
  - agent1
  - agent2
---
Instructions content here"""

        agent = loader.parse_agent(content)

        assert agent.name == "test_agent"
        assert agent.category == AgentCategory.ANALYTICAL
        assert len(agent.input_schema) == 2
        assert len(agent.output_schema) == 2
        assert len(agent.dependencies) == 2

    def test_load_agent_from_file(self, tmp_path):
        """Test loading agent from actual file."""
        agent_file = tmp_path / "writer_agent.md"
        agent_file.write_text("""---
name: writer_agent
description: Writer agent for creating content
category: analytical
version: 1.0.0
input:
  - prompt
output:
  - content
dependencies:
  - planner_agent
---
Write the content based on the prompt""")

        loader = AgentLoader(str(tmp_path))
        agent = loader.load_agent(agent_file)

        assert agent.name == "writer_agent"
        assert agent.category == AgentCategory.ANALYTICAL
        assert agent.version == "1.0.0"

    def test_load_all_agents_with_files(self, tmp_path):
        """Test loading all agents from directory."""
        (tmp_path / "agent1.md").write_text("""---
name: agent1
description: First agent
category: analytical
---
Instructions 1""")
        (tmp_path / "agent2.md").write_text("""---
name: agent2
description: Second agent
category: creative
---
Instructions 2""")

        loader = AgentLoader(str(tmp_path))
        agents = loader.load_all_agents()

        assert len(agents) == 2
        agent_names = [a.name for a in agents]
        assert "agent1" in agent_names
        assert "agent2" in agent_names


class TestAgentLoaderCoverageGaps:
    """Tests targeting specific uncovered lines."""

    def test_parse_agent_no_closing_frontmatter(self):
        """Test parsing with only opening frontmatter, no body (line 68)."""
        loader = AgentLoader("/path/to/agents")
        content = "---\nname: test_agent\ndescription: Test\ncategory: analytical"
        with pytest.raises(ValueError, match="must have YAML frontmatter and body"):
            loader.parse_agent(content)

    def test_load_all_agents_non_english_empty_en_fallback_to_root(self, tmp_path):
        """Test load_all_agents non-English falls back to agents_dir (line 150)."""
        (tmp_path / "my_agent.md").write_text(
            "---\nname: my_agent\ndescription: Test\ncategory: analytical\n---\nInstructions"
        )
        loader = AgentLoader(str(tmp_path), LanguageCode.ZH_CN)
        agents = loader.load_all_agents()
        assert len(agents) == 1
        assert agents[0].name == "my_agent"

    def test_load_all_agents_bad_file_prints_warning(self, tmp_path, capsys):
        """Test load_all_agents handles bad agent file gracefully (lines 158-159)."""
        (tmp_path / "bad.md").write_text("not valid frontmatter")
        (tmp_path / "good.md").write_text(
            "---\nname: good\ndescription: Good\ncategory: analytical\n---\nInstructions"
        )
        loader = AgentLoader(str(tmp_path))
        agents = loader.load_all_agents()
        assert len(agents) == 1
        assert agents[0].name == "good"
        captured = capsys.readouterr()
        assert "Warning" in captured.out
        assert "bad.md" in captured.out

    def test_reload_agent_non_english_finds_in_en_dir(self, tmp_path):
        """Test reload_agent non-English falls back to en dir (lines 181-182)."""
        en_dir = tmp_path / "en"
        en_dir.mkdir()
        (en_dir / "my_agent.md").write_text(
            "---\nname: my_agent\ndescription: Test\ncategory: analytical\n---\nInstructions"
        )
        loader = AgentLoader(str(tmp_path), LanguageCode.ZH_CN)
        agent = loader.reload_agent("my_agent")
        assert agent is not None
        assert agent.name == "my_agent"

    def test_reload_agent_non_english_fallback_to_root(self, tmp_path):
        """Test reload_agent non-English falls to agents_dir (line 184)."""
        (tmp_path / "my_agent.md").write_text(
            "---\nname: my_agent\ndescription: Test\ncategory: analytical\n---\nInstructions"
        )
        loader = AgentLoader(str(tmp_path), LanguageCode.ZH_CN)
        agent = loader.reload_agent("my_agent")
        assert agent is not None
        assert agent.name == "my_agent"

    def test_reload_agent_english_fallback_to_root(self, tmp_path):
        """Test reload_agent English falls back to agents_dir when en/ is empty."""
        en_dir = tmp_path / "en"
        en_dir.mkdir()
        (tmp_path / "my_agent.md").write_text(
            "---\nname: my_agent\ndescription: Test\ncategory: analytical\n---\nInstructions"
        )
        loader = AgentLoader(str(tmp_path), LanguageCode.EN)
        agent = loader.reload_agent("my_agent")
        assert agent is not None
        assert agent.name == "my_agent"
