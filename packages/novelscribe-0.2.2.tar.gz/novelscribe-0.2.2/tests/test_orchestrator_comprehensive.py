"""Comprehensive tests for orchestrator coverage improvement."""

from unittest.mock import Mock, patch

import pytest

from core.llm_client import LLMConfig, LLMResponse
from core.orchestrator import (
    ExecutionContext,
    Orchestrator,
    OrchestratorError,
    StepExecutionError,
    VariableResolver,
    create_orchestrator,
)
from core.storage import AgentDefinition, StorageConfig, WorkflowDefinition


class TestVariableResolver:
    """Test VariableResolver class."""

    def test_initialization(self):
        """Test VariableResolver initialization."""
        context = {"name": "test", "value": 123}
        resolver = VariableResolver(context)
        assert resolver.context == context

    def test_resolve_simple_variable(self):
        """Test resolving a simple variable."""
        resolver = VariableResolver({"name": "John"})
        result = resolver.resolve("Hello {name}")
        assert result == "Hello John"

    def test_resolve_nested_variable(self):
        """Test resolving nested variable."""
        resolver = VariableResolver({"user": {"name": "Jane"}})
        result = resolver.resolve("Hello {user.name}")
        assert result == "Hello Jane"

    def test_resolve_multiple_variables(self):
        """Test resolving multiple variables."""
        resolver = VariableResolver({"first": "Hello", "second": "World"})
        result = resolver.resolve("{first} {second}")
        assert result == "Hello World"

    def test_resolve_missing_variable(self):
        """Test resolving missing variable."""
        resolver = VariableResolver({"name": "John"})
        result = resolver.resolve("Hello {missing}")
        assert result == "Hello {missing}"

    def test_resolve_non_string(self):
        """Test resolving non-string template."""
        resolver = VariableResolver({"name": "John"})
        result = resolver.resolve(123)
        assert result == 123

    def test_resolve_empty_template(self):
        """Test resolving empty template."""
        resolver = VariableResolver({})
        result = resolver.resolve("")
        assert result == ""

    def test_resolve_no_variables(self):
        """Test resolving template with no variables."""
        resolver = VariableResolver({})
        result = resolver.resolve("Hello World")
        assert result == "Hello World"

    def test_get_nested_value_simple(self):
        """Test getting simple nested value."""
        resolver = VariableResolver({"name": "John"})
        value = resolver._get_nested_value("name")
        assert value == "John"

    def test_get_nested_value_deep(self):
        """Test getting deeply nested value."""
        resolver = VariableResolver({"a": {"b": {"c": "deep"}}})
        value = resolver._get_nested_value("a.b.c")
        assert value == "deep"

    def test_get_nested_value_not_found(self):
        """Test getting non-existent nested value."""
        resolver = VariableResolver({"name": "John"})
        value = resolver._get_nested_value("missing")
        assert value is None

    def test_get_nested_value_partial_path(self):
        """Test getting value with partial path."""
        resolver = VariableResolver({"a": {"b": "value"}})
        value = resolver._get_nested_value("a.b.c")
        assert value is None


class TestExecutionContext:
    """Test ExecutionContext class."""

    def test_initialization(self):
        """Test ExecutionContext initialization."""
        context = ExecutionContext("test-project", "test-workflow")
        assert context.project_name == "test-project"
        assert context.workflow_name == "test-workflow"
        assert context.variables["project_name"] == "test-project"
        assert context.variables["workflow_name"] == "test-workflow"

    def test_initialization_with_base_path(self):
        """Test ExecutionContext initialization with base path."""
        context = ExecutionContext("test-project", "test-workflow", base_path="/data")
        assert str(context.base_path).endswith("test-project")

    def test_set_variable(self):
        """Test setting a variable."""
        context = ExecutionContext("test-project", "test-workflow")
        context.set_variable("custom", "value")
        assert context.variables["custom"] == "value"

    def test_get_variable(self):
        """Test getting a variable."""
        context = ExecutionContext("test-project", "test-workflow")
        context.set_variable("custom", "value")
        assert context.get_variable("custom") == "value"

    def test_get_variable_default(self):
        """Test getting non-existent variable with default."""
        context = ExecutionContext("test-project", "test-workflow")
        result = context.get_variable("missing", "default")
        assert result == "default"

    def test_add_history_entry(self):
        """Test adding history entry."""
        context = ExecutionContext("test-project", "test-workflow")
        response = LLMResponse(content="test", model="gpt-4", provider="openai")
        context.add_history_entry(
            step_name="step1",
            agent="agent1",
            input_files=["input.md"],
            output_file="output.md",
            response=response,
        )
        assert len(context.history) == 1
        assert context.history[0]["step"] == "step1"
        assert context.history[0]["content"] == "test"

    def test_get_history(self):
        """Test getting history copy."""
        context = ExecutionContext("test-project", "test-workflow")
        response = LLMResponse(content="test", model="gpt-4", provider="openai")
        context.add_history_entry("step1", "agent1", [], "output.md", response)
        history = context.get_history()
        assert len(history) == 1
        history.append({"step": "step2"})
        assert len(context.history) == 1


class TestOrchestratorError:
    """Test OrchestratorError exception."""

    def test_raise_orchestrator_error(self):
        """Test raising OrchestratorError."""
        with pytest.raises(OrchestratorError):
            raise OrchestratorError("Test error")


class TestStepExecutionError:
    """Test StepExecutionError exception."""

    def test_raise_step_execution_error(self):
        """Test raising StepExecutionError."""
        with pytest.raises(StepExecutionError):
            raise StepExecutionError("Step failed")


class TestOrchestrator:
    """Test Orchestrator class."""

    def test_initialization(self):
        """Test Orchestrator initialization."""
        storage = Mock()
        config = LLMConfig(provider="openai", api_key="test-key")
        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            assert orchestrator.storage is storage
            assert orchestrator.llm_config == config

    def test_load_workflow(self):
        """Test loading workflow."""
        storage = Mock()
        workflow = WorkflowDefinition(
            name="test-workflow",
            description="Test",
            version="1.0",
            steps=[],
        )
        storage.read_workflow.return_value = workflow
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            result = orchestrator.load_workflow("workflow.yaml")
            assert result.name == "test-workflow"
            storage.read_workflow.assert_called_once_with("workflow.yaml")

    def test_load_agent(self):
        """Test loading agent."""
        storage = Mock()
        agent = AgentDefinition(
            name="test-agent",
            description="Test agent",
            model="gpt-4",
            system_prompt="You are a test agent.",
        )
        storage.read_agent.return_value = agent
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            result = orchestrator.load_agent("agents/test.md")
            assert result.name == "test-agent"
            storage.read_agent.assert_called_once()

    def test_execute_workflow_empty(self):
        """Test executing empty workflow."""
        storage = Mock()
        workflow = WorkflowDefinition(
            name="test-workflow",
            description="Test",
            version="1.0",
            steps=[],
        )
        storage.read_workflow.return_value = workflow
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            context = orchestrator.execute_workflow("workflow.yaml", "test-project")
            assert context.workflow_name == "test-workflow"
            assert context.project_name == "test-project"

    def test_execute_workflow_with_initial_context(self):
        """Test executing workflow with initial context."""
        storage = Mock()
        workflow = WorkflowDefinition(
            name="test-workflow",
            description="Test",
            version="1.0",
            steps=[],
        )
        storage.read_workflow.return_value = workflow
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            context = orchestrator.execute_workflow(
                "workflow.yaml",
                "test-project",
                initial_context={"custom_var": "custom_value"},
            )
            assert context.get_variable("custom_var") == "custom_value"

    def test_execute_step_missing_agent(self):
        """Test executing step without agent specification."""
        storage = Mock()
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            with pytest.raises(StepExecutionError):
                orchestrator._execute_step({"name": "test-step"}, context)

    def test_evaluate_condition_true(self):
        """Test evaluating true condition."""
        storage = Mock()
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            assert orchestrator._evaluate_condition("true", context) is True
            assert orchestrator._evaluate_condition("yes", context) is True
            assert orchestrator._evaluate_condition("1", context) is True

    def test_evaluate_condition_false(self):
        """Test evaluating false condition."""
        storage = Mock()
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            assert orchestrator._evaluate_condition("false", context) is False
            assert orchestrator._evaluate_condition("no", context) is False
            assert orchestrator._evaluate_condition("0", context) is False

    def test_evaluate_condition_variable(self):
        """Test evaluating condition with variable."""
        storage = Mock()
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")
            context.set_variable("skip", "true")

            assert orchestrator._evaluate_condition("{skip}", context) is True

    def test_load_input_content_markdown(self):
        """Test loading markdown input content."""
        storage = Mock()
        storage.read_markdown.return_value = "# Test Content"
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            content = orchestrator._load_input_content(["test.md"], context)
            assert "test.md" in content
            assert "# Test Content" in content["test.md"]

    def test_load_input_content_yaml(self):
        """Test loading YAML input content."""
        storage = Mock()
        storage.read_yaml.return_value = {"key": "value"}
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            content = orchestrator._load_input_content(["test.yaml"], context)
            assert "test.yaml" in content

    def test_construct_user_prompt_with_input(self):
        """Test constructing user prompt with input content."""
        storage = Mock()
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            step = {"prompt": "Analyze this:"}
            input_content = {"test.md": "# Test Content"}
            prompt = orchestrator._construct_user_prompt(step, input_content, context)

            assert "Analyze this:" in prompt
            assert "# Test Content" in prompt

    def test_construct_user_prompt_with_variable(self):
        """Test constructing user prompt with variable."""
        storage = Mock()
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")
            context.set_variable("name", "John")

            step = {"prompt": "Hello {name}"}
            prompt = orchestrator._construct_user_prompt(step, {}, context)
            assert "Hello John" in prompt

    def test_call_llm(self):
        """Test calling LLM."""
        storage = Mock()
        config = LLMConfig(provider="openai", api_key="test-key")
        agent = AgentDefinition(
            name="test-agent",
            description="Test",
            model="gpt-4",
            system_prompt="You are helpful.",
        )

        mock_client = Mock()
        mock_response = LLMResponse(content="test", model="gpt-4", provider="openai")
        mock_client.generate.return_value = mock_response

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = mock_client
            orchestrator = Orchestrator(storage, config)

            response = orchestrator._call_llm(
                agent,
                "You are helpful.",
                "Hello",
            )
            assert response.content == "test"

    def test_save_output_markdown(self):
        """Test saving markdown output."""
        storage = Mock()
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            orchestrator._save_output("output.md", "# Test Output", context)
            storage.write_markdown.assert_called_once()

    def test_save_output_yaml(self):
        """Test saving YAML output."""
        storage = Mock()
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            orchestrator._save_output("output.yaml", "content", context)
            storage.write_yaml.assert_called_once()

    def test_execute_step_success(self):
        """Test executing step successfully."""
        storage = Mock()
        agent = AgentDefinition(
            name="test-agent",
            description="Test",
            model="gpt-4",
            system_prompt="You are helpful.",
        )
        storage.read_agent.return_value = agent

        mock_client = Mock()
        mock_response = LLMResponse(content="test", model="gpt-4", provider="openai")
        mock_client.generate.return_value = mock_response

        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = mock_client
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            step = {
                "name": "test-step",
                "agent": "test-agent",
                "agent_path": "agents/test.md",
                "prompt": "Hello",
            }
            orchestrator._execute_step(step, context)

            assert len(context.history) == 1
            assert context.history[0]["step"] == "test-step"

    def test_execute_step_with_condition_false(self):
        """Test executing step with false condition."""
        storage = Mock()
        agent = AgentDefinition(
            name="test-agent",
            description="Test",
            model="gpt-4",
            system_prompt="You are helpful.",
        )
        storage.read_agent.return_value = agent

        mock_client = Mock()
        mock_response = LLMResponse(content="test", model="gpt-4", provider="openai")
        mock_client.generate.return_value = mock_response

        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = mock_client
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")
            context.set_variable("skip", "false")

            step = {
                "name": "test-step",
                "agent": "test-agent",
                "agent_path": "agents/test.md",
                "condition": "{skip}",
            }
            orchestrator._execute_step(step, context)

            assert len(context.history) == 0

    def test_execute_step_with_output_file(self):
        """Test executing step with output file."""
        storage = Mock()
        agent = AgentDefinition(
            name="test-agent",
            description="Test",
            model="gpt-4",
            system_prompt="You are helpful.",
        )
        storage.read_agent.return_value = agent

        mock_client = Mock()
        mock_response = LLMResponse(content="test output", model="gpt-4", provider="openai")
        mock_client.generate.return_value = mock_response

        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = mock_client
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            step = {
                "name": "test-step",
                "agent": "test-agent",
                "agent_path": "agents/test.md",
                "prompt": "Hello",
                "output_file": "output.md",
            }
            orchestrator._execute_step(step, context)

            storage.write_markdown.assert_called_once()

    def test_execute_step_llm_error(self):
        """Test executing step with LLM error."""
        from core.llm_client import LLMError

        storage = Mock()
        agent = AgentDefinition(
            name="test-agent",
            description="Test",
            model="gpt-4",
            system_prompt="You are helpful.",
        )
        storage.read_agent.return_value = agent

        mock_client = Mock()
        mock_client.generate.side_effect = LLMError("API error")

        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = mock_client
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            step = {
                "name": "test-step",
                "agent": "test-agent",
                "agent_path": "agents/test.md",
            }
            with pytest.raises(StepExecutionError):
                orchestrator._execute_step(step, context)

    def test_execute_step_with_input_files(self):
        """Test executing step with input files."""
        storage = Mock()
        agent = AgentDefinition(
            name="test-agent",
            description="Test",
            model="gpt-4",
            system_prompt="You are helpful.",
        )
        storage.read_agent.return_value = agent
        storage.read_markdown.return_value = "# Input Content"

        mock_client = Mock()
        mock_response = LLMResponse(content="test", model="gpt-4", provider="openai")
        mock_client.generate.return_value = mock_response

        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = mock_client
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            step = {
                "name": "test-step",
                "agent": "test-agent",
                "agent_path": "agents/test.md",
                "input_files": ["input.md"],
            }
            orchestrator._execute_step(step, context)

            storage.read_markdown.assert_called()

    def test_execute_step_with_variable_in_path(self):
        """Test executing step with variable in path."""
        storage = Mock()
        agent = AgentDefinition(
            name="test-agent",
            description="Test",
            model="gpt-4",
            system_prompt="You are helpful.",
        )
        storage.read_agent.return_value = agent

        mock_client = Mock()
        mock_response = LLMResponse(content="test", model="gpt-4", provider="openai")
        mock_client.generate.return_value = mock_response

        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = mock_client
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")
            context.set_variable("chapter", "1")

            step = {
                "name": "test-step",
                "agent": "test-agent",
                "agent_path": "agents/{chapter}.md",
                "input_files": ["chapters/chapter_{chapter}.md"],
            }
            orchestrator._execute_step(step, context)

            assert len(context.history) == 1

    def test_execute_step_single_agent_call(self):
        """Test executing single agent call."""
        storage = Mock()
        agent = AgentDefinition(
            name="test-agent",
            description="Test",
            model="gpt-4",
            system_prompt="You are helpful.",
        )
        storage.read_agent.return_value = agent

        mock_client = Mock()
        mock_response = LLMResponse(content="test", model="gpt-4", provider="openai")
        mock_client.generate.return_value = mock_response

        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = mock_client
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            response = orchestrator.execute_step(
                agent_path="agents/test.md",
                system_prompt="Custom prompt",
                user_prompt="Hello",
                output_file="output.md",
                context=context,
            )

            assert response.content == "test"
            storage.write_markdown.assert_called_once()

    def test_execute_step_single_agent_no_custom_prompt(self):
        """Test executing single agent call without custom prompt."""
        storage = Mock()
        agent = AgentDefinition(
            name="test-agent",
            description="Test",
            model="gpt-4",
            system_prompt="You are helpful.",
        )
        storage.read_agent.return_value = agent

        mock_client = Mock()
        mock_response = LLMResponse(content="test", model="gpt-4", provider="openai")
        mock_client.generate.return_value = mock_response

        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = mock_client
            orchestrator = Orchestrator(storage, config)

            response = orchestrator.execute_step(
                agent_path="agents/test.md",
                user_prompt="Hello",
            )

            assert response.content == "test"


class TestCreateOrchestrator:
    """Test create_orchestrator function."""

    def test_create_with_defaults(self):
        """Test creating orchestrator with defaults."""
        with patch("core.storage.StorageFactory.create") as mock_storage:
            mock_storage.return_value = Mock()
            with patch("core.llm_client.LLMClientFactory.create") as mock_llm:
                mock_llm.return_value = Mock()
                orchestrator = create_orchestrator()
                assert orchestrator is not None

    def test_create_with_custom_config(self):
        """Test creating orchestrator with custom config."""
        with patch("core.storage.StorageFactory.create") as mock_storage:
            mock_storage.return_value = Mock()
            with patch("core.llm_client.LLMClientFactory.create") as mock_llm:
                mock_llm.return_value = Mock()
                storage_config = StorageConfig(base_path="/custom")
                llm_config = LLMConfig(provider="claude", api_key="test-key")
                orchestrator = create_orchestrator(storage_config, llm_config)
                assert orchestrator is not None


class TestOrchestratorMissingCoverage:
    """Tests for specific missing coverage lines in orchestrator.py."""

    def test_load_agent_relative_path_resolution(self):
        """Test load_agent resolves relative paths (lines 146→151)."""
        storage = Mock()
        agent = AgentDefinition(
            name="test-agent",
            description="Test",
            model="gpt-4",
            system_prompt="You are a test agent.",
        )
        storage.read_agent.return_value = agent
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            result = orchestrator.load_agent("agents/test.md")
            assert result.name == "test-agent"
            called_path = storage.read_agent.call_args[0][0]
            assert not called_path.startswith("agents/")
            assert "agents/test.md" in called_path

    def test_evaluate_condition_non_boolean_string(self):
        """Test _evaluate_condition with non-boolean string (line 241)."""
        storage = Mock()
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            result = orchestrator._evaluate_condition("some_random_string", context)
            assert result is True

            result2 = orchestrator._evaluate_condition("", context)
            assert result2 is False

    def test_load_input_content_exception_handling(self):
        """Test _load_input_content handles exceptions (lines 259-262)."""
        storage = Mock()
        storage.read_markdown.side_effect = FileNotFoundError("File not found")
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            content = orchestrator._load_input_content(["missing.md"], context)
            assert content == {"missing.md": ""}

    def test_save_output_exception_handling(self):
        """Test _save_output raises StepExecutionError on failure (lines 317-318)."""
        storage = Mock()
        storage.write_markdown.side_effect = IOError("Write failed")
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            with pytest.raises(StepExecutionError, match="Failed to save output"):
                orchestrator._save_output("output.md", "content", context)

    def test_load_input_content_yml_extension(self):
        """Test _load_input_content with .yml extension uses read_yaml (line 256)."""
        storage = Mock()
        storage.read_yaml.return_value = {"key": "value"}
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            content = orchestrator._load_input_content(["test.yml"], context)
            assert "test.yml" in content
            storage.read_yaml.assert_called_once_with("test.yml")

    def test_load_input_content_non_md_non_yaml(self):
        """Test _load_input_content with non-md/non-yaml uses read_markdown (line 259)."""
        storage = Mock()
        storage.read_markdown.return_value = "plain text content"
        config = LLMConfig(provider="openai", api_key="test-key")

        with patch("core.llm_client.LLMClientFactory.create") as mock_factory:
            mock_factory.return_value = Mock()
            orchestrator = Orchestrator(storage, config)
            context = ExecutionContext("test-project", "test-workflow")

            content = orchestrator._load_input_content(["data.txt"], context)
            assert content["data.txt"] == "plain text content"
