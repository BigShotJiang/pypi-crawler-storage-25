"""Parameterized tests for logs router covering various protocols and data formats."""

import pytest
from fastapi import HTTPException

from api.models import LogLevel
from api.routers.logs import (
    DEFAULT_LOG_LIMIT,
    DEFAULT_MAX_ITERATIONS,
    DEFAULT_POLL_INTERVAL,
    LogStreamerConfig,
    get_project_log_file,
    parse_log_entries,
    read_log_file,
    validate_project_name,
)


class TestReadLogFileParameterized:
    """Parameterized tests for read_log_file function."""

    @pytest.mark.parametrize(
        "content,expected_count",
        [
            ('{"level": "INFO"}\n', 1),
            ('{"level": "INFO"}\n{"level": "ERROR"}\n', 2),
            ('{"level": "INFO"}\n{"level": "WARNING"}\n{"level": "ERROR"}\n', 3),
            ("", 0),
            ('not json\n{"level": "INFO"}\n', 1),
            ("\n\n\n", 0),
            ('  {"level": "INFO"}  \n', 1),
        ],
    )
    def test_read_various_contents(self, tmp_path, content, expected_count):
        """Test reading various log file contents."""
        log_file = tmp_path / "execution.log"
        log_file.write_text(content)

        result = read_log_file(log_file)
        assert len(result) == expected_count


class TestParseLogEntriesParameterized:
    """Parameterized tests for parse_log_entries function."""

    @pytest.fixture
    def sample_log_data(self):
        """Create sample log data for testing."""
        return [
            {"level": "DEBUG", "message": "Debug message", "execution_id": "exec1"},
            {"level": "INFO", "message": "Info message", "execution_id": "exec1"},
            {"level": "WARNING", "message": "Warning message", "execution_id": "exec2"},
            {"level": "ERROR", "message": "Error message", "execution_id": "exec1"},
            {"level": "CRITICAL", "message": "Critical message", "execution_id": "exec2"},
        ]

    @pytest.mark.parametrize(
        "level_filter,expected_count",
        [
            (None, 5),
            (LogLevel.DEBUG, 1),
            (LogLevel.INFO, 1),
            (LogLevel.WARNING, 1),
            (LogLevel.ERROR, 1),
            (LogLevel.CRITICAL, 1),
        ],
    )
    def test_parse_with_level_filter(self, sample_log_data, level_filter, expected_count):
        """Test parsing with various level filters."""
        result = parse_log_entries(sample_log_data, level=level_filter)
        assert len(result) == expected_count

    @pytest.mark.parametrize(
        "exec_filter,expected_count",
        [
            (None, 5),
            ("exec1", 3),
            ("exec2", 2),
            ("nonexistent", 0),
        ],
    )
    def test_parse_with_execution_filter(self, sample_log_data, exec_filter, expected_count):
        """Test parsing with various execution ID filters."""
        result = parse_log_entries(sample_log_data, execution_id=exec_filter)
        assert len(result) == expected_count

    @pytest.mark.parametrize(
        "level,exec_id,expected_count",
        [
            (LogLevel.INFO, "exec1", 1),
            (LogLevel.ERROR, "exec1", 1),
            (LogLevel.WARNING, "exec2", 1),
            (LogLevel.DEBUG, "exec2", 0),
            (None, "exec1", 3),
            (LogLevel.INFO, None, 1),
        ],
    )
    def test_parse_with_combined_filters(self, sample_log_data, level, exec_id, expected_count):
        """Test parsing with combined level and execution ID filters."""
        result = parse_log_entries(sample_log_data, level=level, execution_id=exec_id)
        assert len(result) == expected_count


class TestLogLevelHandling:
    """Parameterized tests for log level handling."""

    @pytest.mark.parametrize(
        "level_value,expected_level",
        [
            ("DEBUG", LogLevel.DEBUG),
            ("INFO", LogLevel.INFO),
            ("WARNING", LogLevel.WARNING),
            ("ERROR", LogLevel.ERROR),
            ("CRITICAL", LogLevel.CRITICAL),
        ],
    )
    def test_level_parsing(self, level_value, expected_level):
        """Test various log level parsing scenarios."""
        log_data = [{"level": level_value, "message": "Test"}]
        result = parse_log_entries(log_data)
        assert len(result) == 1
        assert result[0].level == expected_level

    def test_invalid_level_skips_entry(self):
        """Test that invalid levels result in skipped entries."""
        log_data = [
            {"level": "INVALID", "message": "Invalid"},
            {"level": "INFO", "message": "Valid"},
        ]
        result = parse_log_entries(log_data)
        assert len(result) == 1
        assert result[0].message == "Valid"


class TestTimestampHandling:
    """Parameterized tests for timestamp handling."""

    @pytest.mark.parametrize(
        "timestamp,should_parse",
        [
            ("2024-01-15T10:00:00", True),
            ("2024-01-15T10:00:00.123456", True),
            ("invalid-timestamp", False),
            ("", False),
        ],
    )
    def test_timestamp_parsing(self, timestamp, should_parse):
        """Test various timestamp formats."""
        log_data = [{"level": "INFO", "message": "Test", "timestamp": timestamp}]
        result = parse_log_entries(log_data)

        if should_parse:
            assert len(result) == 1
            assert result[0].timestamp is not None
        else:
            assert len(result) == 0


class TestPagination:
    """Parameterized tests for pagination."""

    @pytest.fixture
    def large_log_data(self):
        """Create large dataset for pagination testing."""
        return [
            {"level": "INFO", "message": f"Log {i}", "execution_id": f"exec{i % 5}"}
            for i in range(100)
        ]

    @pytest.mark.parametrize(
        "limit,offset,expected_count",
        [
            (10, 0, 10),
            (10, 10, 10),
            (10, 50, 10),
            (10, 90, 10),
            (100, 0, 100),
            (50, 25, 50),
            (25, 75, 25),
            (1, 50, 1),
            (10, 100, 0),
        ],
    )
    def test_pagination_results(self, large_log_data, limit, offset, expected_count):
        """Test pagination slicing of log entries."""
        entries = parse_log_entries(large_log_data)
        paginated = entries[offset : offset + limit]
        assert len(paginated) == expected_count

    @pytest.mark.parametrize(
        "total,limit,expected_has_more",
        [
            (100, 100, False),
            (100, 99, True),
            (50, 25, True),
            (25, 25, False),
            (10, 5, True),
            (1, 1, False),
        ],
    )
    def test_has_more_calculation(self, total, limit, expected_has_more):
        """Test has_more pagination flag calculation."""
        offset = 0
        has_more = offset + limit < total
        assert has_more == expected_has_more


class TestValidateProjectNameParameterized:
    """Parameterized tests for project name validation."""

    @pytest.mark.parametrize(
        "project_name,should_pass",
        [
            ("valid_project", True),
            ("valid-project", True),
            ("valid.project", True),
            ("ValidProject123", True),
            ("a", True),
            ("project/with/slashes", False),
            ("project\\with\\backslashes", False),
            ("project/backslash", False),
        ],
    )
    def test_project_name_validation(self, project_name, should_pass):
        """Test various project name formats."""
        if should_pass:
            validate_project_name(project_name)
        else:
            with pytest.raises(HTTPException) as exc_info:
                validate_project_name(project_name)
            assert exc_info.value.status_code == 400


class TestLogStreamerConfigParameterized:
    """Parameterized tests for LogStreamerConfig."""

    @pytest.mark.parametrize(
        "poll_interval,max_iterations,limit",
        [
            (0.1, 10, 10),
            (1.0, 100, 50),
            (2.0, 1000, 100),
            (0.001, 5, 5),
            (10.0, 500, 200),
        ],
    )
    def test_custom_config_values(self, poll_interval, max_iterations, limit):
        """Test custom configuration values."""
        config = LogStreamerConfig(
            poll_interval=poll_interval,
            max_iterations=max_iterations,
            limit=limit,
        )
        assert config.poll_interval == poll_interval
        assert config.max_iterations == max_iterations
        assert config.limit == limit

    @pytest.mark.parametrize(
        "defaults_to,expected",
        [
            ("poll_interval", DEFAULT_POLL_INTERVAL),
            ("max_iterations", DEFAULT_MAX_ITERATIONS),
            ("limit", DEFAULT_LOG_LIMIT),
        ],
    )
    def test_default_values(self, defaults_to, expected):
        """Test default configuration values."""
        config = LogStreamerConfig()
        assert getattr(config, defaults_to) == expected


class TestMessageHandling:
    """Parameterized tests for message field handling."""

    @pytest.mark.parametrize(
        "message,expected",
        [
            ("Simple message", "Simple message"),
            ("", ""),
            ("Unicode: \u4e16\u754c", "Unicode: \u4e16\u754c"),
            ("Special chars: !@#$%^&*()", "Special chars: !@#$%^&*()"),
            ("Newline\n\t", "Newline\n\t"),
            ("Very " + "long " * 100, "Very " + "long " * 100),
        ],
    )
    def test_message_parsing(self, message, expected):
        """Test various message formats."""
        log_data = [{"level": "INFO", "message": message}]
        result = parse_log_entries(log_data)
        assert len(result) == 1
        assert result[0].message == expected


class TestMetadataHandling:
    """Parameterized tests for metadata field handling."""

    @pytest.mark.parametrize(
        "metadata,expected",
        [
            ({}, {}),
            ({"key": "value"}, {"key": "value"}),
            ({"nested": {"a": 1, "b": 2}}, {"nested": {"a": 1, "b": 2}}),
            ({"list": [1, 2, 3]}, {"list": [1, 2, 3]}),
        ],
    )
    def test_metadata_parsing(self, metadata, expected):
        """Test various metadata formats."""
        log_data = [{"level": "INFO", "message": "Test", "metadata": metadata}]
        result = parse_log_entries(log_data)
        assert len(result) == 1
        assert result[0].metadata == expected


class TestOptionalFields:
    """Parameterized tests for optional field handling."""

    @pytest.mark.parametrize(
        "source,chapter,execution_id",
        [
            ("agent1", 1, "exec1"),
            (None, 1, "exec1"),
            ("agent1", None, "exec1"),
            ("agent1", 1, None),
            (None, None, None),
            ("agent", 10, "exec123"),
        ],
    )
    def test_optional_fields(self, source, chapter, execution_id):
        """Test handling of optional fields."""
        log_data = [
            {
                "level": "INFO",
                "message": "Test",
                "source": source,
                "chapter": chapter,
                "execution_id": execution_id,
            }
        ]
        result = parse_log_entries(log_data)
        assert len(result) == 1
        assert result[0].source == source
        assert result[0].chapter == chapter
        assert result[0].execution_id == execution_id


class TestGetProjectLogFileParameterized:
    """Parameterized tests for get_project_log_file function."""

    @pytest.mark.parametrize(
        "project_name,expected_suffix",
        [
            ("project1", "project1/logs/execution.log"),
            ("my-project", "my-project/logs/execution.log"),
            ("Project123", "Project123/logs/execution.log"),
        ],
    )
    def test_log_file_paths(self, tmp_path, project_name, expected_suffix):
        """Test log file path generation for various project names."""
        project_dir = tmp_path / "base"
        result = get_project_log_file(project_dir, project_name)

        assert result.parts[-3:] == tuple(expected_suffix.split("/"))


class TestEdgeCases:
    """Tests for edge cases and boundary conditions."""

    @pytest.mark.parametrize(
        "content",
        [
            "\t\t\t",
            "\n\n\n\n",
            "   \n   \n   ",
            "\r\n",
        ],
    )
    def test_whitespace_only_content(self, tmp_path, content):
        """Test handling of various whitespace patterns."""
        log_file = tmp_path / "execution.log"
        log_file.write_text(content)

        result = read_log_file(log_file)
        assert result == []

    def test_json_decode_error_handling(self, tmp_path):
        """Test handling of JSON decode errors."""
        log_file = tmp_path / "execution.log"
        log_file.write_text("{invalid json\n{also invalid\n{more invalid\n")

        result = read_log_file(log_file)
        assert result == []

    def test_empty_log_list(self):
        """Test parsing empty list."""
        result = parse_log_entries([])
        assert result == []

    def test_all_fields_missing(self):
        """Test parsing entry with minimal fields."""
        log_data = [{}]
        result = parse_log_entries(log_data)
        assert len(result) == 1
        assert result[0].message == ""
        assert result[0].level == LogLevel.INFO
