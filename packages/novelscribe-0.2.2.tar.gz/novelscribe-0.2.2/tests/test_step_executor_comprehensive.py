"""Comprehensive tests for step executor coverage improvement.

Tests system actions, error handling, edge cases, and file operations.
"""

from pathlib import Path
from unittest.mock import Mock, patch

import pytest

from core.git_manager import GitManager
from core.step_executor import StepExecutor, SystemActionHandler
from core.storage import FileStorage, StorageBackend, StorageConfig
from core.workflow_loader import OnFailure, WorkflowStep


@pytest.fixture
def mock_dependencies(tmp_path):
    """Create mock dependencies."""
    storage = Mock(spec=StorageBackend)
    git_manager = Mock(spec=GitManager)
    agent_integration = Mock()
    resolver = Mock()

    return {
        "storage": storage,
        "git_manager": git_manager,
        "agent_integration": agent_integration,
        "resolver": resolver,
        "work_dir": tmp_path,
    }


@pytest.fixture
def real_storage_backend(tmp_path):
    """Create real FileStorage for tests that need actual file I/O."""
    config = StorageConfig(base_path=str(tmp_path))
    storage = FileStorage(config)
    return storage


@pytest.fixture
def system_action_handler_with_real_storage(real_storage_backend, tmp_path):
    """Create SystemActionHandler with real storage for file I/O tests."""
    git_manager = Mock(spec=GitManager)
    return SystemActionHandler(
        storage=real_storage_backend,
        git_manager=git_manager,
        work_dir=tmp_path,
    )


@pytest.fixture
def system_action_handler(mock_dependencies):
    """Create SystemActionHandler instance for testing."""
    return SystemActionHandler(
        storage=mock_dependencies["storage"],
        git_manager=mock_dependencies["git_manager"],
        work_dir=mock_dependencies["work_dir"],
    )


@pytest.fixture
def step_executor(mock_dependencies):
    """Create StepExecutor instance for testing."""
    return StepExecutor(
        storage=mock_dependencies["storage"],
        git_manager=mock_dependencies["git_manager"],
        agent_integration=mock_dependencies["agent_integration"],
        work_dir=mock_dependencies["work_dir"],
    )


class TestSystemActionHandlerGitTag:
    """Test git_tag system action."""

    def test_git_tag_action(self, system_action_handler, tmp_path):
        """Test git_tag system action."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        system_action_handler.git_manager.create_milestone_tag = Mock(return_value="v1.0")

        input_data = {"tag": "v1.0", "message": "First milestone"}

        result = system_action_handler.execute_action(
            action="git_tag",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert result["tagged"] is True

    def test_git_tag_with_defaults(self, system_action_handler, tmp_path):
        """Test git_tag with default values."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        system_action_handler.git_manager.create_milestone_tag = Mock(return_value="milestone")

        input_data = {}

        result = system_action_handler.execute_action(
            action="git_tag",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True


class TestSystemActionHandlerLoadYaml:
    """Test load_yaml system action."""

    def test_load_yaml_success(self, system_action_handler, tmp_path):
        """Test successful YAML loading."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        yaml_content = {"title": "Test Novel", "author": "Test Author"}
        system_action_handler.storage.read_yaml = Mock(return_value=yaml_content)

        input_data = {"file": "META.yaml"}

        result = system_action_handler.execute_action(
            action="load_yaml",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert result["meta"] == yaml_content

    def test_load_yaml_with_storage_error(self, system_action_handler, tmp_path):
        """Test load_yaml with storage error."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        system_action_handler.storage.read_yaml = Mock(side_effect=Exception("File not found"))

        input_data = {"file": "META.yaml"}

        result = system_action_handler.execute_action(
            action="load_yaml",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is False
        assert "File not found" in result["error"]


class TestSystemActionHandlerLoadMarkdown:
    """Test load_markdown system action."""

    def test_load_markdown_success(self, system_action_handler, tmp_path):
        """Test successful markdown loading."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        markdown_content = "# Chapter 1\n\nThis is a test chapter."
        system_action_handler.storage.read_markdown = Mock(return_value=markdown_content)

        input_data = {"file": "chapters/chapter_1.md"}

        result = system_action_handler.execute_action(
            action="load_markdown",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert result["content"] == markdown_content

    def test_load_markdown_optional_file_not_found(self, system_action_handler, tmp_path):
        """Test loading optional markdown file that doesn't exist."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        system_action_handler.storage.read_markdown = Mock(side_effect=Exception("File not found"))

        input_data = {"file": "notes.md", "optional": True}

        result = system_action_handler.execute_action(
            action="load_markdown",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert result["content"] is None

    def test_load_markdown_required_file_not_found(self, system_action_handler, tmp_path):
        """Test loading required markdown file that doesn't exist."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        system_action_handler.storage.read_markdown = Mock(side_effect=Exception("File not found"))

        input_data = {"file": "required.md", "optional": False}

        result = system_action_handler.execute_action(
            action="load_markdown",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is False
        assert "File not found" in result["error"]


class TestSystemActionHandlerLoadPreviousChapters:
    """Test load_previous_chapters system action."""

    def test_load_previous_chapters(self, system_action_handler_with_real_storage, tmp_path):
        """Test loading previous chapters."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()
        chapters_dir = project_dir / "chapters"
        chapters_dir.mkdir()

        chapter_1 = chapters_dir / "chapter_1.md"
        chapter_2 = chapters_dir / "chapter_2.md"
        chapter_1.write_text("# Chapter 1\n\nContent 1")
        chapter_2.write_text("# Chapter 2\n\nContent 2")

        input_data = {"current_chapter": 3}

        result = system_action_handler_with_real_storage.execute_action(
            action="load_previous_chapters",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert "Chapter 1" in result["chapters"]
        assert "Chapter 2" in result["chapters"]

    def test_load_previous_chapters_with_missing_chapters(
        self, system_action_handler_with_real_storage, tmp_path
    ):
        """Test loading previous chapters when some are missing."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()
        chapters_dir = project_dir / "chapters"
        chapters_dir.mkdir()

        chapter_1 = chapters_dir / "chapter_1.md"
        chapter_1.write_text("# Chapter 1")

        input_data = {"current_chapter": 3}

        result = system_action_handler_with_real_storage.execute_action(
            action="load_previous_chapters",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert "Chapter 1" in result["chapters"]


class TestSystemActionHandlerLoadChapterRange:
    """Test load_chapter_range system action."""

    def test_load_chapter_range(self, system_action_handler_with_real_storage, tmp_path):
        """Test loading chapter range."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()
        chapters_dir = project_dir / "chapters"
        chapters_dir.mkdir()

        chapter_5 = chapters_dir / "chapter_5.md"
        chapter_6 = chapters_dir / "chapter_6.md"
        chapter_5.write_text("# Chapter 5")
        chapter_6.write_text("# Chapter 6")

        input_data = {"start_chapter": 5, "end_chapter": 6}

        result = system_action_handler_with_real_storage.execute_action(
            action="load_chapter_range",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert len(result["chapters"]) == 2
        assert "# Chapter 5" in result["chapters"][0]
        assert "# Chapter 6" in result["chapters"][1]

    def test_load_chapter_range_single_chapter(
        self, system_action_handler_with_real_storage, tmp_path
    ):
        """Test loading single chapter range."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()
        chapters_dir = project_dir / "chapters"
        chapters_dir.mkdir()

        chapter_10 = chapters_dir / "chapter_10.md"
        chapter_10.write_text("# Chapter 10")

        input_data = {"start_chapter": 10, "end_chapter": 10}

        result = system_action_handler_with_real_storage.execute_action(
            action="load_chapter_range",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert len(result["chapters"]) == 1


class TestSystemActionHandlerLoadAllChapters:
    """Test load_all_chapters system action."""

    def test_load_all_chapters(self, system_action_handler_with_real_storage, tmp_path):
        """Test loading all chapters."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()
        chapters_dir = project_dir / "chapters"
        chapters_dir.mkdir()

        for i in range(1, 4):
            chapter = chapters_dir / f"chapter_{i}.md"
            chapter.write_text(f"# Chapter {i}")

        input_data = {"count": 3}

        result = system_action_handler_with_real_storage.execute_action(
            action="load_all_chapters",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert len(result["chapters"]) == 3


class TestSystemActionHandlerCheckStatus:
    """Test check_status system action."""

    def test_check_status_with_condition(self, system_action_handler):
        """Test checking status with condition."""
        input_data = {"status": "completed", "condition": "completed"}

        result = system_action_handler.execute_action(
            action="check_status",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert result["result"] is True

    def test_check_status_condition_not_met(self, system_action_handler):
        """Test checking status when condition not met."""
        input_data = {"status": "pending", "condition": "completed"}

        result = system_action_handler.execute_action(
            action="check_status",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert result["result"] is False

    def test_check_status_without_condition(self, system_action_handler):
        """Test checking status without condition (truthiness)."""
        input_data = {"status": "completed"}

        result = system_action_handler.execute_action(
            action="check_status",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert result["result"] is True

    def test_check_status_empty_status(self, system_action_handler):
        """Test checking empty status."""
        input_data = {"status": ""}

        result = system_action_handler.execute_action(
            action="check_status",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert result["result"] is False


class TestSystemActionHandlerCheckIssues:
    """Test check_issues system action."""

    def test_check_issues_with_issues(self, system_action_handler):
        """Test checking for issues when issues exist."""
        input_data = {"issues": ["error 1", "error 2"]}

        result = system_action_handler.execute_action(
            action="check_issues",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert result["result"] is True

    def test_check_issues_no_issues(self, system_action_handler):
        """Test checking for issues when no issues exist."""
        input_data = {"issues": []}

        result = system_action_handler.execute_action(
            action="check_issues",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert result["result"] is False


class TestSystemActionHandlerGetChapterCount:
    """Test get_chapter_count system action."""

    def test_get_chapter_count_with_chapters(self, system_action_handler, tmp_path):
        """Test getting chapter count when chapters exist."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()
        chapters_dir = project_dir / "chapters"
        chapters_dir.mkdir()

        for i in range(1, 6):
            (chapters_dir / f"chapter_{i}.md").touch()

        input_data = {}

        result = system_action_handler.execute_action(
            action="get_chapter_count",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert result["count"] == 5

    def test_get_chapter_count_no_chapters_directory(self, system_action_handler, tmp_path):
        """Test getting chapter count when chapters directory doesn't exist."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        input_data = {}

        result = system_action_handler.execute_action(
            action="get_chapter_count",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert result["count"] == 0

    def test_get_chapter_count_empty_directory(self, system_action_handler, tmp_path):
        """Test getting chapter count from empty directory."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()
        chapters_dir = project_dir / "chapters"
        chapters_dir.mkdir()

        input_data = {}

        result = system_action_handler.execute_action(
            action="get_chapter_count",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert result["count"] == 0


class TestSystemActionHandlerGetTargetChapterCount:
    """Test get_target_chapter_count system action."""

    def test_get_target_chapter_count_from_user_target(self, system_action_handler, tmp_path):
        """Test getting target chapter count from user input."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        input_data = {"user_target": 50}

        result = system_action_handler.execute_action(
            action="get_target_chapter_count",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert result["count"] == 50

    def test_get_target_chapter_count_from_meta_file(
        self, system_action_handler_with_real_storage, tmp_path
    ):
        """Test getting target chapter count from META.yaml."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        meta_file = project_dir / "META.yaml"
        meta_file.write_text("chapter_count_target: 25")

        input_data = {}

        result = system_action_handler_with_real_storage.execute_action(
            action="get_target_chapter_count",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert result["count"] == 25

    def test_get_target_chapter_count_default(self, system_action_handler, tmp_path):
        """Test getting target chapter count default value."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        system_action_handler.storage.read_yaml = Mock(side_effect=Exception("Not found"))

        input_data = {}

        result = system_action_handler.execute_action(
            action="get_target_chapter_count",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert result["count"] == 30


class TestSystemActionHandlerGenerateReport:
    """Test generate_report system action."""

    def test_generate_report(self, system_action_handler, tmp_path):
        """Test generating final report."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        system_action_handler.storage.write_markdown = Mock()

        input_data = {}

        result = system_action_handler.execute_action(
            action="generate_report",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert "final_report" in result

    def test_generate_report_creates_directory(self, system_action_handler, tmp_path):
        """Test that generate_report creates reports directory."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        written_path = None

        def capture_write(path, content):
            nonlocal written_path
            written_path = path

        system_action_handler.storage.write_markdown = Mock(side_effect=capture_write)

        input_data = {}

        result = system_action_handler.execute_action(
            action="generate_report",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert "reports" in written_path


class TestSystemActionHandlerDisplaySummary:
    """Test display_summary system action."""

    def test_display_summary(self, system_action_handler, tmp_path, capsys):
        """Test displaying completion summary."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        input_data = {}

        result = system_action_handler.execute_action(
            action="display_summary",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert result["summary_displayed"] is True

        captured = capsys.readouterr()
        assert "Novel generation complete" in captured.out


class TestStepExecutorVariableResolution:
    """Test StepExecutor variable resolution."""

    def test_execute_step_with_variable_resolution(self, step_executor):
        """Test step execution with variable resolution."""
        step = WorkflowStep(
            step=1,
            name="test_step",
            agent="writer",
            input={"prompt": "Write chapter {{chapter_number}}"},
            output={"result": "{{response}}"},
        )

        step_executor.resolver.resolve_dict = Mock(
            side_effect=[{"prompt": "Write chapter 5"}, {"result": "Chapter content"}]
        )

        mock_agent_result = {"success": True, "response": "Chapter content"}
        step_executor.agent_integration.execute_agent_step = Mock(return_value=mock_agent_result)

        result = step_executor.execute_step(
            step=step,
            project_name="test_project",
            variables={"chapter_number": 5},
            step_outputs={},
            config={},
        )

        assert result["success"] is True
        assert result["output"]["result"] == "Chapter content"


class TestStepExecutorWorkflowSteps:
    """Test workflow step execution."""

    def test_execute_workflow_step_with_failure(self, step_executor):
        """Test workflow step execution with failure."""
        step = WorkflowStep(
            step=1,
            name="test_step",
            workflow="nested_workflow",
            input={"data": "value"},
            on_failure=OnFailure.CONTINUE,
        )

        step_executor.resolver.resolve_dict = Mock(return_value={"data": "value"})
        step_executor.resolver.resolve_dict = Mock(return_value={})

        with patch("core.workflow_executor.WorkflowExecutor") as mock_executor_class:
            mock_executor = Mock()
            mock_executor_class.return_value = mock_executor
            mock_executor.execute_workflow = Mock(
                return_value={"success": False, "error": "Workflow failed"}
            )

            result = step_executor.execute_step(
                step=step,
                project_name="test_project",
                variables={},
                step_outputs={},
                config={},
            )

            assert result["success"] is False
            assert "error" in result


class TestStepExecutorSystemActions:
    """Test system action step execution."""

    def test_execute_system_action_with_error(self, step_executor):
        """Test system action with error."""
        step = WorkflowStep(
            step=1,
            name="test_step",
            action="create_directories",
            input={"directories": ["test"]},
            on_failure=OnFailure.CONTINUE,
        )

        step_executor.resolver.resolve_dict = Mock(return_value={"directories": ["test"]})
        step_executor.resolver.resolve_dict = Mock(return_value={})

        step_executor.system_handler.execute_action = Mock(
            return_value={"success": False, "error": "Action failed"}
        )

        result = step_executor.execute_step(
            step=step,
            project_name="test_project",
            variables={},
            step_outputs={},
            config={},
        )

        assert result["success"] is False
        assert "Action failed" in result["error"]


class TestStepExecutorExceptions:
    """Test exception handling in StepExecutor."""

    def test_execute_step_with_exception_and_continue(self, step_executor):
        """Test step execution with exception when on_failure=continue."""
        step = WorkflowStep(
            step=1,
            name="test_step",
            agent="writer",
            input={"prompt": "Test"},
            on_failure=OnFailure.CONTINUE,
        )

        step_executor.resolver.resolve_dict = Mock(return_value={"prompt": "Test"})
        step_executor.resolver.resolve_dict = Mock(return_value={})
        step_executor.agent_integration.execute_agent_step = Mock(
            side_effect=Exception("Agent error")
        )

        result = step_executor.execute_step(
            step=step,
            project_name="test_project",
            variables={},
            step_outputs={},
            config={},
        )

        assert result["success"] is False
        assert "Agent error" in result["error"]

    def test_execute_step_with_exception_and_stop(self, step_executor):
        """Test step execution with exception when on_failure=stop."""
        step = WorkflowStep(
            step=1,
            name="test_step",
            agent="writer",
            input={"prompt": "Test"},
            on_failure=OnFailure.STOP,
        )

        step_executor.resolver.resolve_dict = Mock(return_value={"prompt": "Test"})
        step_executor.agent_integration.execute_agent_step = Mock(
            side_effect=Exception("Agent error")
        )

        with pytest.raises(Exception, match="Agent error"):
            step_executor.execute_step(
                step=step,
                project_name="test_project",
                variables={},
                step_outputs={},
                config={},
            )


class TestSystemActionHandlerInitialization:
    """Test SystemActionHandler initialization."""

    def test_initialization_with_path(self, tmp_path):
        """Test initialization with Path work_dir."""
        storage = Mock(spec=StorageBackend)
        git_manager = Mock(spec=GitManager)

        handler = SystemActionHandler(storage=storage, git_manager=git_manager, work_dir=tmp_path)

        assert handler.work_dir == tmp_path
        assert handler.storage == storage
        assert handler.git_manager == git_manager

    def test_initialization_with_string_path(self, tmp_path):
        """Test initialization with string work_dir."""
        storage = Mock(spec=StorageBackend)
        git_manager = Mock(spec=GitManager)

        handler = SystemActionHandler(
            storage=storage, git_manager=git_manager, work_dir=str(tmp_path)
        )

        assert handler.work_dir == tmp_path

    def test_initialization_default_work_dir(self):
        """Test initialization with default work_dir."""
        storage = Mock(spec=StorageBackend)
        git_manager = Mock(spec=GitManager)

        handler = SystemActionHandler(storage=storage, git_manager=git_manager, work_dir=None)

        assert handler.work_dir == Path.cwd()


class TestStepExecutorInitialization:
    """Test StepExecutor initialization."""

    def test_initialization_with_path(self, tmp_path):
        """Test initialization with Path work_dir."""
        storage = Mock(spec=StorageBackend)
        git_manager = Mock(spec=GitManager)
        agent_integration = Mock()

        executor = StepExecutor(
            storage=storage,
            git_manager=git_manager,
            agent_integration=agent_integration,
            work_dir=tmp_path,
        )

        assert executor.work_dir == tmp_path
        assert executor.storage == storage
        assert executor.git_manager == git_manager
        assert executor.agent_integration == agent_integration
