"""Tests for error handling and edge cases."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


class TestErrorHandling:
    """Test error handling in core components."""

    def test_storage_file_not_found(self):
        """Test storage handles missing files gracefully."""
        from core.storage import FileStorage, StorageConfig

        config = StorageConfig(base_path="/tmp/nonexistent")
        storage = FileStorage(config)

        with pytest.raises(Exception):
            storage.read_markdown("nonexistent.md")

    def test_storage_invalid_yaml(self):
        """Test storage handles invalid YAML gracefully."""
        from core.storage import FileStorage, StorageConfig

        config = StorageConfig(base_path="/tmp")
        storage = FileStorage(config)

        # Write invalid YAML
        invalid_yaml_path = Path("/tmp/invalid.yaml")
        invalid_yaml_path.write_text("invalid: yaml: content: [")

        with pytest.raises(Exception):
            storage.read_yaml("invalid.yaml")

        # Cleanup
        if invalid_yaml_path.exists():
            invalid_yaml_path.unlink()

    def test_llm_client_missing_api_key(self):
        """Test LLM client handles missing API key."""
        from core.llm_client import LLMClientFactory, LLMConfig

        # Should not crash on initialization
        config = LLMConfig(provider="openai")
        client = LLMClientFactory.create(config)

        # But should fail when actually calling
        with pytest.raises(Exception):
            # This will fail without API key
            client.complete("Test prompt")


class TestEdgeCases:
    """Test edge cases in system."""

    @pytest.mark.skip(reason="Requires valid workflow file to test properly")
    def test_orchestrator_with_empty_workflow(self):
        """Test orchestrator handles empty workflow."""
        from core.orchestrator import Orchestrator
        from core.storage import FileStorage, StorageConfig

        config = StorageConfig(base_path="/tmp")
        storage = FileStorage(config)

        # Should not crash on initialization
        orchestrator = Orchestrator(storage=storage)
        assert orchestrator is not None

    def test_version_with_invalid_pypi_response(self):
        """Test version manager handles invalid PyPI response."""
        from core.version import VersionManager

        manager = VersionManager()

        # Test with mock that returns invalid data
        with patch("requests.get") as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 404
            mock_get.return_value = mock_response

            result = manager.check_for_updates(verbose=False)
            # Should return None or gracefully handle
            assert result is None or isinstance(result, dict)

    def test_multiple_agent_loading(self):
        """Test loading multiple agents."""
        from core.storage import FileStorage, StorageConfig

        config = StorageConfig(base_path=str(Path(__file__).parent.parent))
        storage = FileStorage(config)

        # Should be able to load agent files that exist
        try:
            agent = storage.read_agent("agents/test_agent.md")
            assert agent.name == "test_agent"
        except Exception:
            # Expected if file doesn't exist
            pass


class TestBoundaryConditions:
    """Test boundary conditions."""

    def test_very_long_project_name(self):
        """Test system handles very long project names."""
        # Project names should be handled without crashing
        long_name = "a" * 1000

        # This should not crash
        assert len(long_name) == 1000

    def test_special_characters_in_paths(self):
        """Test system handles special characters in paths."""
        from core.storage import StorageConfig

        # Should handle special characters gracefully
        try:
            config = StorageConfig(base_path="/tmp/test-project")
            assert config is not None
        except Exception as e:
            pytest.fail(f"Failed to create config with special chars: {e}")

    def test_unicode_in_content(self):
        """Test system handles Unicode content."""
        import tempfile

        from core.storage import FileStorage, StorageConfig

        with tempfile.TemporaryDirectory() as tmpdir:
            config = StorageConfig(base_path=tmpdir)
            storage = FileStorage(config)

            # Write and read Unicode content
            unicode_text = "Hello 世界 🌍 🎉"
            storage.write_markdown("test.md", unicode_text)
            result = storage.read_markdown("test.md")

            assert result == unicode_text


class TestPerformance:
    """Test performance-related edge cases."""

    def test_large_file_handling(self):
        """Test handling of large files."""
        import tempfile

        from core.storage import FileStorage, StorageConfig

        with tempfile.TemporaryDirectory() as tmpdir:
            config = StorageConfig(base_path=tmpdir)
            storage = FileStorage(config)

            # Create a large file
            large_content = "x" * (1024 * 1024)  # 1MB
            storage.write_markdown("large.md", large_content)

            # Should handle without crashing
            result = storage.read_markdown("large.md")
            assert len(result) == len(large_content)

    def test_rapid_operations(self):
        """Test rapid sequential operations."""
        import tempfile

        from core.storage import FileStorage, StorageConfig

        with tempfile.TemporaryDirectory() as tmpdir:
            config = StorageConfig(base_path=tmpdir)
            storage = FileStorage(config)

            # Perform rapid operations
            for i in range(100):
                storage.write_markdown(f"test_{i}.md", f"Content {i}")

            # Should handle without issues
            for i in range(100):
                result = storage.read_markdown(f"test_{i}.md")
                assert f"Content {i}" in result
