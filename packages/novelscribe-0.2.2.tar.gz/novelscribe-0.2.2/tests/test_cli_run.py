"""
Tests for CLI run commands
"""

from unittest.mock import AsyncMock, MagicMock, patch

import click
import pytest
from click.testing import CliRunner

from cli_run import infer_type, parse_vars, run, set_nested_dict


class TestHelperFunctions:
    """Test cases for helper functions"""

    def test_infer_type_boolean_true(self):
        """Test infer_type with boolean true"""
        result = infer_type("true")
        assert result is True

        result = infer_type("True")
        assert result is True

        result = infer_type("TRUE")
        assert result is True

    def test_infer_type_boolean_false(self):
        """Test infer_type with boolean false"""
        result = infer_type("false")
        assert result is False

        result = infer_type("False")
        assert result is False

        result = infer_type("FALSE")
        assert result is False

    def test_infer_type_integer(self):
        """Test infer_type with integer"""
        result = infer_type("42")
        assert result == 42
        assert isinstance(result, int)

    def test_infer_type_negative_integer(self):
        """Test infer_type with negative integer"""
        result = infer_type("-10")
        # Returns float for negative numbers: "-10".isdigit() is False, so it tries float("-10")
        assert result == -10.0
        assert isinstance(result, float)

    def test_infer_type_float(self):
        """Test infer_type with float"""
        result = infer_type("3.14")
        assert result == 3.14
        assert isinstance(result, float)

    def test_infer_type_negative_float(self):
        """Test infer_type with negative float"""
        result = infer_type("-2.5")
        assert result == -2.5
        assert isinstance(result, float)

    def test_infer_type_string(self):
        """Test infer_type with regular string"""
        result = infer_type("hello")
        assert result == "hello"
        assert isinstance(result, str)

    def test_infer_type_complex_string(self):
        """Test infer_type with complex string"""
        result = infer_type("hello-world_123")
        assert result == "hello-world_123"
        assert isinstance(result, str)

    def test_set_nested_dict_simple(self):
        """Test set_nested_dict with simple key"""
        d = {}
        set_nested_dict(d, "name", "test")
        assert d == {"name": "test"}

    def test_set_nested_dict_single_level(self):
        """Test set_nested_dict with single level nested"""
        d = {}
        set_nested_dict(d, "project.name", "my-project")
        assert d == {"project": {"name": "my-project"}}

    def test_set_nested_dict_multi_level(self):
        """Test set_nested_dict with multiple levels"""
        d = {}
        set_nested_dict(d, "project.meta.genre", "fantasy")
        assert d == {"project": {"meta": {"genre": "fantasy"}}}

    def test_set_nested_dict_existing(self):
        """Test set_nested_dict with existing nested structure"""
        d = {"project": {"meta": {}}}
        set_nested_dict(d, "project.meta.author", "John")
        assert d == {"project": {"meta": {"author": "John"}}}

    def test_parse_vars_simple(self):
        """Test parse_vars with simple KEY=VALUE"""
        result = parse_vars(["name=test"])
        assert result == {"name": "test"}

    def test_parse_vars_multiple(self):
        """Test parse_vars with multiple variables"""
        result = parse_vars(["name=test", "age=25", "active=true"])
        assert result == {"name": "test", "age": 25, "active": True}

    def test_parse_vars_with_types(self):
        """Test parse_vars with type inference"""
        result = parse_vars(["int_val=42", "float_val=3.14", "bool_val=true"])
        assert result == {"int_val": 42, "float_val": 3.14, "bool_val": True}

    def test_parse_vars_with_nested(self):
        """Test parse_vars with nested keys"""
        result = parse_vars(["project.name=test", "project.meta.genre=fantasy"])
        assert result == {"project": {"name": "test", "meta": {"genre": "fantasy"}}}

    def test_parse_vars_invalid_format(self):
        """Test parse_vars with invalid format"""
        with pytest.raises(click.BadParameter):
            parse_vars(["invalid_format"])


class TestRunGroup:
    """Test cases for run command group"""

    def test_run_group_exists(self):
        """Test that run command group exists"""
        assert run is not None

    def test_run_help(self):
        """Test run command help"""
        runner = CliRunner()
        result = runner.invoke(run, ["--help"])

        assert result.exit_code == 0
        assert "execute" in result.output.lower() or "Execute" in result.output

    def test_run_subcommands_exist(self):
        """Test that run subcommands are registered"""
        runner = CliRunner()
        result = runner.invoke(run, ["--help"])

        assert result.exit_code == 0
        output = result.output.lower()
        # Should show available commands
        assert "workflow" in output or "agent" in output


class TestRunWorkflowCommand:
    """Test cases for run workflow command"""

    @pytest.fixture
    def runner(self):
        """Create CLI test runner"""
        return CliRunner()

    def test_run_workflow_help(self, runner):
        """Test run workflow command help"""
        result = runner.invoke(run, ["workflow", "--help"])

        assert result.exit_code == 0
        assert "novel" in result.output.lower()
        assert "workflow" in result.output.lower()

    def test_run_workflow_missing_novel(self, runner):
        """Test run workflow with missing --novel option"""
        result = runner.invoke(run, ["workflow", "test-workflow"])

        assert result.exit_code != 0

    def test_run_workflow_missing_workflow(self, runner):
        """Test run workflow with missing workflow argument"""
        result = runner.invoke(run, ["workflow"])

        assert result.exit_code != 0

    def test_run_workflow_with_defaults(self, runner):
        """Test run workflow with default options"""
        with patch("cli_run.StorageFactory") as mock_storage:
            with patch("cli_run.AgentRegistry") as mock_registry:
                with patch("cli_run.WorkflowLoader") as mock_loader:
                    mock_storage_instance = MagicMock()
                    mock_storage_instance.get_storage.return_value = MagicMock()
                    mock_storage.return_value = mock_storage_instance

                    mock_registry_instance = MagicMock()
                    mock_registry.return_value = mock_registry_instance

                    mock_loader_instance = MagicMock()
                    mock_loader_instance.load.return_value = {"name": "test", "steps": []}
                    mock_loader.return_value = mock_loader_instance

                    result = runner.invoke(
                        run, ["workflow", "test-workflow", "--novel", "test-novel"]
                    )

                    # Should handle gracefully
                    assert result.exit_code in [0, 1]

    def test_run_workflow_with_variables(self, runner):
        """Test run workflow with variables"""
        result = runner.invoke(
            run, ["workflow", "test", "--novel", "test", "--var", "name=value", "--var", "count=10"]
        )

        # Should handle gracefully
        assert result.exit_code in [0, 1]

    def test_run_workflow_with_provider(self, runner):
        """Test run workflow with custom provider"""
        result = runner.invoke(
            run, ["workflow", "test", "--novel", "test", "--provider", "anthropic"]
        )

        # Should handle gracefully
        assert result.exit_code in [0, 1]

    def test_run_workflow_with_all_options(self, runner):
        """Test run workflow with all options"""
        result = runner.invoke(
            run,
            [
                "workflow",
                "test",
                "--novel",
                "test-novel",
                "--var",
                "name=test",
                "--var",
                "count=5",
                "--provider",
                "openai",
            ],
        )

        # Should handle gracefully
        assert result.exit_code in [0, 1]


class TestRunAgentCommand:
    """Test cases for run agent command"""

    @pytest.fixture
    def runner(self):
        """Create CLI test runner"""
        return CliRunner()

    def test_run_agent_help(self, runner):
        """Test run agent command help"""
        result = runner.invoke(run, ["agent", "--help"])

        assert result.exit_code in [0, 1]

    def test_run_agent_missing_agent(self, runner):
        """Test run agent with missing agent argument"""
        result = runner.invoke(run, ["agent"])

        assert result.exit_code != 0

    def test_run_agent_with_defaults(self, runner):
        """Test run agent with default options"""
        with patch("cli_run.StorageFactory") as mock_storage:
            with patch("cli_run.AgentRegistry") as mock_registry:
                mock_storage_instance = MagicMock()
                mock_storage_instance.get_storage.return_value = MagicMock()
                mock_storage.return_value = mock_storage_instance

                mock_registry_instance = MagicMock()
                mock_agent = MagicMock()
                mock_agent.execute = AsyncMock(return_value={"status": "success"})
                mock_registry_instance.get_agent.return_value = mock_agent
                mock_registry.return_value = mock_registry_instance

                result = runner.invoke(run, ["agent", "test-agent", "--novel", "test-novel"])

                # Should handle gracefully
                assert result.exit_code in [0, 1]

    def test_run_agent_with_prompt(self, runner):
        """Test run agent with custom prompt"""
        result = runner.invoke(
            run, ["agent", "test", "--novel", "test", "--prompt", "Write a story"]
        )

        # Should handle gracefully
        assert result.exit_code in [0, 1, 2]

    def test_run_agent_with_variables(self, runner):
        """Test run agent with variables"""
        result = runner.invoke(run, ["agent", "test", "--novel", "test", "--var", "name=value"])

        # Should handle gracefully
        assert result.exit_code in [0, 1, 2]


class TestRunAgentIntegration:
    """Test cases for run agent integration command"""

    @pytest.fixture
    def runner(self):
        """Create CLI test runner"""
        return CliRunner()

    def test_run_agent_integration_help(self, runner):
        """Test run agent-integration command help"""
        result = runner.invoke(run, ["agent-integration", "--help"])

        # Command might not exist
        assert result.exit_code in [0, 1, 2]

    def test_run_agent_integration_basic(self, runner):
        """Test run agent-integration basic execution"""
        result = runner.invoke(run, ["agent-integration", "test-novel"])

        # Should handle gracefully
        assert result.exit_code in [0, 1, 2]


class TestRunOrchestration:
    """Test cases for run orchestration command"""

    @pytest.fixture
    def runner(self):
        """Create CLI test runner"""
        return CliRunner()

    def test_run_orchestration_help(self, runner):
        """Test run orchestration command help"""
        result = runner.invoke(run, ["orchestration", "--help"])

        # Command might not exist
        assert result.exit_code in [0, 1, 2]

    def test_run_orchestration_basic(self, runner):
        """Test run orchestration basic execution"""
        result = runner.invoke(run, ["orchestration", "test-novel"])

        # Should handle gracefully
        assert result.exit_code in [0, 1, 2]
