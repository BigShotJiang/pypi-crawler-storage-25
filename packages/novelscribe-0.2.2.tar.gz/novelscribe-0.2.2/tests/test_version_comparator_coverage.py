"""Additional coverage tests for version_comparator.py to reach 100%."""

import pytest

from core.version_comparator import VersionComparator


class TestVersionComparatorCoverage:
    """Test edge cases in version_comparator for full coverage."""

    @pytest.fixture
    def comparator(self, tmp_path):
        """Set up test fixtures."""
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        return VersionComparator(str(project_dir))

    @pytest.fixture
    def project_dir(self, tmp_path):
        """Create project directory for tests."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()
        return project_dir

    def test_identify_sections_exact_match(self, comparator):
        """Test section identification with exact matches."""
        content = "This is paragraph one.\n\nThis is paragraph two."
        sections = comparator._identify_sections(content, content)

        assert len(sections[0]) == 0  # sections_added
        assert len(sections[1]) == 0  # sections_removed
        assert len(sections[2]) == 0  # sections_modified

    def test_identify_sections_all_added(self, comparator):
        """Test section identification when all content is new."""
        from_content = "Old paragraph one."
        to_content = "New paragraph one.\n\nNew paragraph two."

        sections = comparator._identify_sections(from_content, to_content)

        assert len(sections[0]) == 2  # sections_added
        # Old paragraph is removed since it doesn't match
        assert len(sections[1]) == 1  # sections_removed
        assert len(sections[2]) == 0  # sections_modified

    def test_identify_sections_all_removed(self, comparator):
        """Test section identification when all content is removed."""
        from_content = "Old paragraph one.\n\nOld paragraph two."
        to_content = "New paragraph."

        sections = comparator._identify_sections(from_content, to_content)

        assert len(sections[0]) == 1  # sections_added
        assert len(sections[1]) == 2  # sections_removed
        assert len(sections[2]) == 0  # sections_modified

    def test_identify_sections_modified_but_different(self, comparator):
        """Test section identification with modifications but no similar paragraphs."""
        from_content = "Original text about a topic."
        to_content = "Completely different words here."

        sections = comparator._identify_sections(from_content, to_content)

        # Since no similar paragraph is found (similarity < 0.5)
        # it should be treated as added/removed, not modified
        assert len(sections[0]) == 1  # sections_added
        assert len(sections[1]) == 1  # sections_removed

    def test_compare_all_versions_single_version(self, project_dir):
        """Test compare_all_versions with only one version."""
        chapter_dir = project_dir / "chapter_1"
        chapter_dir.mkdir()

        # Create only version 1
        (chapter_dir / "v1.md").write_text("Version 1 content.")

        comparator = VersionComparator(str(project_dir))
        diffs = comparator.compare_all_versions(1)

        assert diffs == []

    def test_compare_all_versions_no_versions(self, project_dir):
        """Test compare_all_versions with no versions."""
        comparator = VersionComparator(str(project_dir))
        diffs = comparator.compare_all_versions(1)

        assert diffs == []

    def test_get_version_progression_no_versions(self, project_dir):
        """Test get_version_progression with no versions."""
        comparator = VersionComparator(str(project_dir))
        progression = comparator.get_version_progression(1)

        assert progression == {
            "chapter_number": 1,
            "versions": [],
            "total_changes": 0,
            "avg_similarity": 0.0,
        }

    def test_calculate_similarity_identical_content(self, comparator):
        """Test similarity calculation with identical content."""
        content = "This is the same content with multiple words to test."
        similarity = comparator._calculate_similarity(content, content)

        assert similarity == 1.0

    def test_calculate_similarity_completely_different(self, comparator):
        """Test similarity calculation with completely different content."""
        content1 = "abc def ghi"
        content2 = "xyz uvw rst"
        similarity = comparator._calculate_similarity(content1, content2)

        assert similarity == 0.0

    def test_extract_scene_descriptions_with_keywords(self, comparator):
        """Test scene description extraction with various keywords."""
        content = """
        The room was dark and gloomy.
        Outside, the forest was bright.
        The castle loomed in the distance.
        The interior was decorated elegantly.
        """
        scenes = comparator._extract_scene_descriptions(content)

        assert len(scenes) > 0
        assert any("room" in scene.lower() for scene in scenes)

    def test_find_similar_paragraph_no_words(self, comparator):
        """Test finding similar paragraph when content has no words."""
        paragraph = "   "
        paragraph_list = ["Test paragraph here"]

        result = comparator._find_similar_paragraph(paragraph, paragraph_list)

        assert result is None

    def test_generate_summary_with_all_fields(self, comparator):
        """Test summary generation with all fields present."""
        from core.version_comparator import SectionChange, VersionDiff

        diff = VersionDiff(
            from_version=1,
            to_version=2,
            chapter_number=1,
            similarity_score=0.75,
            word_count_change=100,
            sections_added=[SectionChange(section_type="added", content="New", location="1")],
            sections_removed=[SectionChange(section_type="removed", content="Old", location="1")],
            sections_modified=[
                SectionChange(section_type="modified", content="Changed", location="1")
            ],
            key_preservations=["Dialogue preserved", "Characters consistent"],
        )

        summary = comparator._generate_summary(diff)

        assert "75.00%" in summary
        assert "New" in summary or "added" in summary.lower()
        assert "Old" in summary or "removed" in summary.lower()
        assert "preserved" in summary.lower()

    def test_assess_quality_impact_boundaries(self, comparator):
        """Test quality impact assessment at boundary values."""
        from core.version_comparator import VersionDiff

        # Test above 0.8 for Minor
        diff_high = VersionDiff(
            from_version=1,
            to_version=2,
            chapter_number=1,
            similarity_score=0.85,
            word_count_change=0,
            sections_added=[],
            sections_removed=[],
            sections_modified=[],
            key_preservations=[],
        )
        impact = comparator._assess_quality_impact(diff_high)
        assert "Minor" in impact

        # Test at 0.75 boundary for Moderate
        diff_mid = VersionDiff(
            from_version=1,
            to_version=2,
            chapter_number=1,
            similarity_score=0.75,
            word_count_change=0,
            sections_added=[],
            sections_removed=[],
            sections_modified=[],
            key_preservations=[],
        )
        impact = comparator._assess_quality_impact(diff_mid)
        assert "Moderate" in impact

        # Test at 0.3 boundary for Significant
        diff_low = VersionDiff(
            from_version=1,
            to_version=2,
            chapter_number=1,
            similarity_score=0.3,
            word_count_change=0,
            sections_added=[],
            sections_removed=[],
            sections_modified=[],
            key_preservations=[],
        )
        impact = comparator._assess_quality_impact(diff_low)
        assert "Major" in impact
