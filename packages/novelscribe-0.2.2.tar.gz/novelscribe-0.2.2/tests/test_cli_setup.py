"""Tests for cli_setup module."""

import os
import tempfile
from pathlib import Path

import pytest

# Test that inquirer3 can be imported
try:
    import importlib.util

    INQUIRER3_AVAILABLE = importlib.util.find_spec("inquirer3") is not None
except ImportError:
    INQUIRER3_AVAILABLE = False


@pytest.mark.skipif(not INQUIRER3_AVAILABLE, reason="inquirer3 module not available")
class TestSetupWizard:
    """Test cases for SetupWizard class."""

    @pytest.fixture
    def temp_dir(self):
        """Create temporary directory for testing."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    @pytest.fixture
    def mock_wizard(self, temp_dir):
        """Create SetupWizard instance with mocked dependencies."""
        from setup_wizard import SetupWizard

        wizard = SetupWizard()
        wizard.install_dir = temp_dir
        wizard.config_dir = temp_dir / ".scribe"
        wizard.env_file = temp_dir / ".env"
        return wizard

    def test_validate_api_key_openai_valid(self, mock_wizard):
        """Test OpenAI API key validation with valid key."""
        valid_key = "sk-1234567890123456789012345678901234567890"
        assert mock_wizard.validate_api_key("openai", valid_key) is True

    def test_validate_api_key_openai_invalid(self, mock_wizard):
        """Test OpenAI API key validation with invalid key."""
        assert mock_wizard.validate_api_key("openai", "invalid") is False
        assert mock_wizard.validate_api_key("openai", "1234567890") is False
        assert mock_wizard.validate_api_key("openai", "") is False

    def test_validate_api_key_anthropic_valid(self, mock_wizard):
        """Test Anthropic API key validation with valid key."""
        valid_key = "sk-ant-1234567890123456789012345678901234567890"
        assert mock_wizard.validate_api_key("anthropic", valid_key) is True

    def test_validate_api_key_anthropic_invalid(self, mock_wizard):
        """Test Anthropic API key validation with invalid key."""
        assert mock_wizard.validate_api_key("anthropic", "sk-1234567890") is False
        assert mock_wizard.validate_api_key("anthropic", "invalid") is False

    def test_validate_api_key_google_valid(self, mock_wizard):
        """Test Google API key validation with valid key."""
        valid_key = "a1B2c3D4e5F6g7H8i9J0k1L2m3N4o5P6"
        assert mock_wizard.validate_api_key("google", valid_key) is True

    def test_validate_api_key_google_invalid(self, mock_wizard):
        """Test Google API key validation with invalid key."""
        assert mock_wizard.validate_api_key("google", "short") is False
        assert mock_wizard.validate_api_key("google", "a" * 31) is False
        assert mock_wizard.validate_api_key("google", "a" * 33) is False

    def test_save_api_key_creates_file(self, mock_wizard):
        """Test that save_api_key creates .env file."""
        mock_wizard.save_api_key("openai", "sk-test123")
        assert mock_wizard.env_file.exists()
        content = mock_wizard.env_file.read_text()
        assert "OPENAI_API_KEY=sk-test123" in content

    def test_save_api_key_secure_permissions(self, mock_wizard):
        """Test that save_api_key sets secure file permissions."""
        mock_wizard.save_api_key("openai", "sk-test123")
        if os.name != "nt":
            stat_info = os.stat(mock_wizard.env_file)
            mode = stat_info.st_mode & 0o777
            assert mode == 0o600

    def test_save_api_key_overwrites_previous(self, mock_wizard):
        """Test that save_api_key overwrites previous keys."""
        mock_wizard.save_api_key("openai", "sk-first")
        mock_wizard.save_api_key("anthropic", "sk-ant-second")
        content = mock_wizard.env_file.read_text()
        assert "sk-first" not in content
        assert "sk-ant-second" in content

    def test_validate_api_key_unknown_provider(self, mock_wizard):
        """Test API key validation with unknown provider."""
        assert mock_wizard.validate_api_key("unknown", "any-key") is False

    def test_env_file_parent_created(self, temp_dir):
        """Test that parent directory is created if needed."""
        from setup_wizard import SetupWizard

        wizard = SetupWizard()
        wizard.install_dir = temp_dir
        wizard.config_dir = temp_dir / ".scribe"
        nested_env = temp_dir / "nested" / "dir" / ".env"
        wizard.env_file = nested_env
        wizard.save_api_key("openai", "sk-test")
        assert nested_env.exists()
        assert nested_env.parent.exists()


class TestCliSetup:
    """Test cases for CLI setup commands."""

    @pytest.fixture
    def runner(self):
        """Create CLI test runner."""
        from click.testing import CliRunner

        return CliRunner()

    def test_apikey_command_validates_openai(self, runner):
        """Test apikey command validates OpenAI format."""
        from cli_setup import apikey  # noqa: F401

        result = runner.invoke(
            apikey,
            ["openai", "invalid-key"],
            obj={"debug": False},
        )
        assert result.exit_code != 0 or "sk-" in result.output

    def test_apikey_command_validates_anthropic(self, runner):
        """Test apikey command validates Anthropic format."""
        pass

    def test_apikey_command_validates_google(self, runner):
        """Test apikey command validates Google format."""
        pass

    def test_apikey_command_writes_env_file(self, runner):
        """Test apikey command writes .env file."""
        pass

    def test_apikey_command_sets_permissions(self, runner):
        """Test apikey command sets secure permissions."""
        pass

    def test_language_command(self, runner):
        """Test language command sets configuration."""
        pass

    def test_install_skill_command_no_trae(self, runner):
        """Test install_skill handles missing Trae directory."""
        pass

    def test_verify_command_all_pass(self, runner):
        """Test verify command when all checks pass."""
        pass

    def test_verify_command_missing_api_key(self, runner):
        """Test verify command reports missing API key."""
        pass

    def test_setup_group_exists(self, runner):
        """Test that setup command group exists."""
        pass


class TestErrorHandling:
    """Test error handling in CLI setup."""

    def test_permission_error_handling(self):
        """Test handling of permission errors."""
        pass

    def test_invalid_provider_handling(self):
        """Test handling of invalid provider."""
        pass

    def test_missing_skill_file_handling(self):
        """Test handling of missing skill file."""
        pass
