"""Tests for progress tracker."""

import shutil
import tempfile
from pathlib import Path

import pytest

from core.progress_tracker import (
    ExecutionStatus,
    ProgressTracker,
)


@pytest.fixture
def temp_storage():
    """Create temporary storage directory."""
    temp_dir = tempfile.mkdtemp()
    yield Path(temp_dir)
    shutil.rmtree(temp_dir, ignore_errors=True)


@pytest.fixture
def progress_tracker(temp_storage):
    """Create progress tracker fixture."""
    return ProgressTracker("test_project", temp_storage)


class TestProgressTracker:
    """Tests for ProgressTracker class."""

    def test_initialize(self, progress_tracker):
        """Test progress tracker initialization."""
        state = progress_tracker.initialize(total_steps=10, start_phase="new_novel")

        assert state.project_name == "test_project"
        assert state.current_phase == "new_novel"
        assert state.total_steps == 10
        assert state.completed_steps == 0
        assert state.progress_percentage == 0.0
        assert state.status == ExecutionStatus.RUNNING
        assert len(state.completed_phases) == 0

    def test_update_phase(self, progress_tracker):
        """Test phase update."""
        progress_tracker.initialize(total_steps=10)
        progress_tracker.update_phase("outline_phase", "Generate outline")

        state = progress_tracker.get_state()
        assert state.current_phase == "outline_phase"
        assert state.current_step == "Generate outline"

    def test_complete_phase(self, progress_tracker):
        """Test phase completion."""
        progress_tracker.initialize(total_steps=10)
        progress_tracker.update_phase("new_novel")
        progress_tracker.complete_phase("new_novel")

        state = progress_tracker.get_state()
        assert "new_novel" in state.completed_phases
        assert state.completed_steps == 1
        assert state.progress_percentage == 10.0

    def test_update_step(self, progress_tracker):
        """Test step update."""
        progress_tracker.initialize(total_steps=10)
        progress_tracker.update_step()

        state = progress_tracker.get_state()
        assert state.completed_steps == 1
        assert state.progress_percentage == 10.0

    def test_set_status(self, progress_tracker):
        """Test status setting."""
        progress_tracker.initialize(total_steps=10)
        progress_tracker.set_status(ExecutionStatus.COMPLETED)

        state = progress_tracker.get_state()
        assert state.status == ExecutionStatus.COMPLETED

    def test_set_status_with_error(self, progress_tracker):
        """Test status setting with error message."""
        progress_tracker.initialize(total_steps=10)
        error_msg = "LLM API timeout"
        progress_tracker.set_status(ExecutionStatus.FAILED, error_msg)

        state = progress_tracker.get_state()
        assert state.status == ExecutionStatus.FAILED
        assert state.error == error_msg

    def test_percentage_calculation(self, progress_tracker):
        """Test progress percentage calculation."""
        progress_tracker.initialize(total_steps=5)

        for i in range(5):
            progress_tracker.update_step()
            state = progress_tracker.get_state()
            expected_percentage = ((i + 1) / 5) * 100
            assert state.progress_percentage == expected_percentage

    def test_get_state_not_initialized(self, progress_tracker):
        """Test get state when not initialized."""
        state = progress_tracker.get_state()
        assert state is None

    def test_save_and_load_state(self, temp_storage):
        """Test state persistence."""
        tracker1 = ProgressTracker("test_project", temp_storage)
        tracker1.initialize(total_steps=10)
        tracker1.update_phase("outline_phase")
        tracker1.complete_phase("outline_phase")

        tracker2 = ProgressTracker("test_project", temp_storage)
        loaded_state = tracker2.load_state()

        assert loaded_state is not None
        assert loaded_state.project_name == "test_project"
        assert loaded_state.current_phase == "outline_phase"
        assert "outline_phase" in loaded_state.completed_phases
        assert loaded_state.progress_percentage == 10.0

    def test_load_nonexistent_state(self, progress_tracker):
        """Test loading state when file doesn't exist."""
        state = progress_tracker.load_state()
        assert state is None

    def test_get_progress_summary(self, progress_tracker):
        """Test progress summary generation."""
        progress_tracker.initialize(total_steps=10)
        progress_tracker.update_phase("outline_phase")
        progress_tracker.complete_phase("outline_phase")

        summary = progress_tracker.get_progress_summary()

        assert summary["project_name"] == "test_project"
        assert summary["current_phase"] == "outline_phase"
        assert summary["completed_steps"] == 1
        assert summary["total_steps"] == 10
        assert summary["progress"] == 10.0
        assert summary["status"] == "running"

    def test_get_progress_summary_not_initialized(self, progress_tracker):
        """Test progress summary when not initialized."""
        summary = progress_tracker.get_progress_summary()

        assert summary["project_name"] == "test_project"
        assert summary["status"] == "not_initialized"
        assert summary["progress"] == 0.0

    def test_multiple_phase_completion(self, progress_tracker):
        """Test completing multiple phases."""
        progress_tracker.initialize(total_steps=5)

        phases = [
            "new_novel",
            "worldbuilding_phase",
            "character_phase",
            "outline_phase",
            "chapter_plan_phase",
        ]

        for phase in phases:
            progress_tracker.update_phase(phase)
            progress_tracker.complete_phase(phase)

        state = progress_tracker.get_state()
        assert len(state.completed_phases) == 5
        assert state.progress_percentage == 100.0

    def test_complete_phase_only_once(self, progress_tracker):
        """Test that completing same phase twice only counts once."""
        progress_tracker.initialize(total_steps=5)
        progress_tracker.update_phase("outline_phase")
        progress_tracker.complete_phase("outline_phase")
        progress_tracker.complete_phase("outline_phase")

        state = progress_tracker.get_state()
        assert state.completed_steps == 1


class TestProgressTrackerCoverageGaps:
    """Tests targeting specific uncovered lines."""

    def test_update_phase_not_initialized(self, progress_tracker):
        """Test update_phase raises when not initialized (line 107)."""
        with pytest.raises(RuntimeError, match="Progress tracker not initialized"):
            progress_tracker.update_phase("phase")

    def test_complete_phase_not_initialized(self, progress_tracker):
        """Test complete_phase raises when not initialized (line 122)."""
        with pytest.raises(RuntimeError, match="Progress tracker not initialized"):
            progress_tracker.complete_phase("phase")

    def test_update_step_not_initialized(self, progress_tracker):
        """Test update_step raises when not initialized (line 136)."""
        with pytest.raises(RuntimeError, match="Progress tracker not initialized"):
            progress_tracker.update_step()

    def test_set_status_not_initialized(self, progress_tracker):
        """Test set_status raises when not initialized (line 159)."""
        with pytest.raises(RuntimeError, match="Progress tracker not initialized"):
            progress_tracker.set_status(ExecutionStatus.FAILED)

    def test_update_percentage_zero_total_steps(self, progress_tracker):
        """Test _update_percentage with zero total steps (line 146 exit)."""
        progress_tracker.initialize(total_steps=0)
        progress_tracker.update_step()
        state = progress_tracker.get_state()
        assert state.progress_percentage == 0.0

    def test_load_state_corrupt_file(self, progress_tracker, temp_storage):
        """Test load_state with corrupt file (lines 194-195)."""
        progress_tracker.progress_file.parent.mkdir(parents=True, exist_ok=True)
        progress_tracker.progress_file.write_text("{invalid json content")
        with pytest.raises(RuntimeError, match="Failed to load progress state"):
            progress_tracker.load_state()

    def test_save_state_not_initialized(self, progress_tracker, temp_storage):
        """Test _save_state when not initialized (line 200)."""
        progress_tracker._save_state()
        assert not progress_tracker.progress_file.exists()
