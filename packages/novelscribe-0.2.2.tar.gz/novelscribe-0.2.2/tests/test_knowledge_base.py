"""
Unit tests for SuggestionKnowledgeBase.
"""

import json
import tempfile
from pathlib import Path

import pytest
import yaml

from core.suggestions.knowledge_base import SuggestionKnowledgeBase
from core.suggestions.models import (
    Suggestion,
    SuggestionCategory,
    SuggestionSource,
)


@pytest.fixture
def temp_data_dir():
    """Create a temporary directory for test data."""
    with tempfile.TemporaryDirectory() as tmpdir:
        data_dir = Path(tmpdir) / "suggestions"
        data_dir.mkdir(parents=True)
        yield data_dir


@pytest.fixture
def mock_genre_data(temp_data_dir):
    """Create mock genre suggestion data."""
    genre_file = temp_data_dir / "genre_suggestions.yaml"

    data = {
        "genre_suggestions": {
            "en": [
                {
                    "id": "genre_test_fantasy",
                    "name": "Test Fantasy",
                    "description": "A test fantasy genre",
                    "best_for": ["Testing", "Examples"],
                    "examples": ["Test Book 1", "Test Book 2"],
                    "acceptance_rate": 0.75,
                    "acceptance_count": 20,
                    "accepted_count": 15,
                }
            ],
            "zh-CN": [
                {
                    "id": "genre_test_fantasy_zh_cn",
                    "name": "测试奇幻",
                    "description": "测试奇幻类型",
                    "best_for": ["测试", "示例"],
                    "examples": ["测试书1", "测试书2"],
                    "acceptance_rate": 0.70,
                    "acceptance_count": 10,
                    "accepted_count": 7,
                }
            ],
        }
    }

    with open(genre_file, "w", encoding="utf-8") as f:
        yaml.dump(data, f, allow_unicode=True)

    return genre_file


@pytest.fixture
def mock_learned_data(temp_data_dir):
    """Create mock learned suggestions data."""
    learned_file = temp_data_dir / "learned_suggestions.json"

    data = {
        "version": "1.0",
        "updated_at": "2026-04-03T12:00:00",
        "suggestions": [
            {
                "id": "learned_genre_custom",
                "name": "Custom Genre",
                "description": "A learned genre suggestion",
                "category": "genre",
                "best_for": ["Custom use cases"],
                "examples": ["Custom Example"],
                "source": "learned",
                "language": "en",
                "acceptance_rate": 0.80,
                "acceptance_count": 5,
                "accepted_count": 4,
                "metadata": {},
            }
        ],
    }

    with open(learned_file, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)

    return learned_file


class TestSuggestionKnowledgeBase:
    """Test SuggestionKnowledgeBase class."""

    def test_initialization(self, temp_data_dir):
        """Test KB initialization."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        assert kb.data_dir == temp_data_dir
        assert isinstance(kb._static_cache, dict)
        assert isinstance(kb._learned_cache, dict)

    def test_load_suggestions_by_category(self, temp_data_dir, mock_genre_data):
        """Test loading suggestions by category."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        suggestions = kb.load_suggestions(SuggestionCategory.GENRE, language="en")

        assert len(suggestions) == 1
        assert suggestions[0].id == "genre_test_fantasy"
        assert suggestions[0].name == "Test Fantasy"
        assert suggestions[0].category == SuggestionCategory.GENRE
        assert suggestions[0].source == SuggestionSource.STATIC

    def test_load_suggestions_multilingual(self, temp_data_dir, mock_genre_data):
        """Test loading suggestions in different languages."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        en_suggestions = kb.load_suggestions(SuggestionCategory.GENRE, language="en")
        zh_suggestions = kb.load_suggestions(SuggestionCategory.GENRE, language="zh-CN")

        # Should get at least English suggestions (KB returns en as fallback)
        assert len(en_suggestions) >= 1
        assert any(s.language == "en" for s in en_suggestions)

        # Should get at least Chinese suggestions
        assert len(zh_suggestions) >= 1
        assert any(s.language == "zh-CN" for s in zh_suggestions)

    def test_load_suggestions_with_learned(self, temp_data_dir, mock_genre_data, mock_learned_data):
        """Test loading suggestions including learned ones."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        suggestions = kb.load_suggestions(
            SuggestionCategory.GENRE, language="en", include_learned=True
        )

        assert len(suggestions) == 2
        suggestion_ids = {s.id for s in suggestions}
        assert "genre_test_fantasy" in suggestion_ids
        assert "learned_genre_custom" in suggestion_ids

    def test_load_suggestions_without_learned(
        self, temp_data_dir, mock_genre_data, mock_learned_data
    ):
        """Test loading suggestions excluding learned ones."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        suggestions = kb.load_suggestions(
            SuggestionCategory.GENRE, language="en", include_learned=False
        )

        assert len(suggestions) == 1
        assert suggestions[0].id == "genre_test_fantasy"
        assert suggestions[0].source == SuggestionSource.STATIC

    def test_get_suggestion_by_id(self, temp_data_dir, mock_genre_data):
        """Test retrieving a specific suggestion by ID."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        suggestion = kb.get_suggestion("genre_test_fantasy")

        assert suggestion is not None
        assert suggestion.id == "genre_test_fantasy"
        assert suggestion.name == "Test Fantasy"

    def test_get_nonexistent_suggestion(self, temp_data_dir):
        """Test retrieving a non-existent suggestion."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        suggestion = kb.get_suggestion("nonexistent")

        assert suggestion is None

    def test_add_suggestion(self, temp_data_dir):
        """Test adding a new learned suggestion."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        new_suggestion = Suggestion(
            id="new_learned",
            name="New Learned",
            description="A new learned suggestion",
            category=SuggestionCategory.WORKFLOW,
            source=SuggestionSource.LEARNED,
        )

        result = kb.add_suggestion(new_suggestion)

        assert result is True
        assert "new_learned" in kb._learned_cache

        retrieved = kb.get_suggestion("new_learned")
        assert retrieved.id == "new_learned"

    def test_add_duplicate_suggestion(self, temp_data_dir):
        """Test adding a duplicate suggestion."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        suggestion = Suggestion(
            id="duplicate",
            name="Duplicate",
            description="Test duplicate",
            category=SuggestionCategory.GENRE,
            source=SuggestionSource.LEARNED,
        )

        kb.add_suggestion(suggestion)
        result = kb.add_suggestion(suggestion)

        assert result is False

    def test_update_acceptance_rate(self, temp_data_dir, mock_genre_data):
        """Test updating acceptance rate for a suggestion."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        kb.update_acceptance_rate("genre_test_fantasy", True)

        suggestion = kb.get_suggestion("genre_test_fantasy")
        assert suggestion.acceptance_count == 21
        assert suggestion.accepted_count == 16
        assert abs(suggestion.acceptance_rate - 0.7619) < 0.001

    def test_get_top_suggestions(self, temp_data_dir, mock_genre_data, mock_learned_data):
        """Test getting top suggestions by acceptance rate."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        top_suggestions = kb.get_top_suggestions(SuggestionCategory.GENRE, language="en", limit=2)

        assert len(top_suggestions) == 2
        assert top_suggestions[0].id == "learned_genre_custom"
        assert top_suggestions[0].acceptance_rate == 0.80
        assert top_suggestions[1].id == "genre_test_fantasy"
        assert top_suggestions[1].acceptance_rate == 0.75

    def test_promote_to_global(self, temp_data_dir):
        """Test promoting a learned suggestion to global."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        suggestion = Suggestion(
            id="promote_me",
            name="Promote Me",
            description="Test promotion",
            category=SuggestionCategory.GENRE,
            source=SuggestionSource.LEARNED,
        )
        kb.add_suggestion(suggestion)

        result = kb.promote_to_global("promote_me")

        assert result is True
        promoted = kb.get_suggestion("promote_me")
        assert promoted.promoted_at is not None

    def test_promote_nonexistent_suggestion(self, temp_data_dir):
        """Test promoting a non-existent suggestion."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        result = kb.promote_to_global("nonexistent")

        assert result is False

    def test_reload_cache(self, temp_data_dir, mock_genre_data):
        """Test reloading the static cache."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        initial_count = len(kb._static_cache)

        kb.reload_cache()

        assert len(kb._static_cache) == initial_count

    def test_get_all_categories(self, temp_data_dir):
        """Test getting all categories."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        categories = kb.get_all_categories()

        assert len(categories) == 4
        assert SuggestionCategory.GENRE in categories
        assert SuggestionCategory.TECHNICAL in categories
        assert SuggestionCategory.WORKFLOW in categories
        assert SuggestionCategory.QUALITY in categories

    def test_get_supported_languages(self, temp_data_dir):
        """Test getting supported languages."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        languages = kb.get_supported_languages()

        assert "en" in languages
        assert "zh-CN" in languages
        assert "zh-TW" in languages

    def test_get_stats(self, temp_data_dir, mock_genre_data, mock_learned_data):
        """Test getting knowledge base statistics."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        stats = kb.get_stats()

        assert stats["total_static_suggestions"] > 0
        assert stats["total_learned_suggestions"] > 0
        assert stats["total_suggestions"] > 0
        assert "genre" in stats["categories"]
        assert stats["categories"]["genre"]["total"] > 0
        assert len(stats["supported_languages"]) == 3

    def test_empty_knowledge_base(self, temp_data_dir):
        """Test KB with no data files."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)

        suggestions = kb.load_suggestions(SuggestionCategory.GENRE)
        assert len(suggestions) == 0

        stats = kb.get_stats()
        assert stats["total_static_suggestions"] == 0
        assert stats["total_learned_suggestions"] == 0


class TestKnowledgeBaseMissingCoverage:
    """Tests for missing coverage in knowledge_base.py."""

    def test_init_with_default_data_dir(self):
        """Test __init__ with None data_dir (line 39)."""
        kb = SuggestionKnowledgeBase(data_dir=None)
        assert kb.data_dir.exists()

    def test_load_category_static_empty_yaml(self, temp_data_dir):
        """Test _load_category_static with empty YAML (line 69)."""
        genre_file = temp_data_dir / "genre_suggestions.yaml"
        genre_file.write_text("")
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)
        assert len(kb._static_cache.get("static_genre", [])) == 0

    def test_load_learned_with_invalid_json(self, temp_data_dir):
        """Test _load_learned with invalid JSON (line 113-114)."""
        learned_file = temp_data_dir / "learned_suggestions.json"
        learned_file.write_text("not json at all")
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)
        assert len(kb._learned_cache) == 0

    def test_update_acceptance_rate_learned_saves(self, temp_data_dir):
        """Test update_acceptance_rate saves for learned source (line 222→exit, 223)."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)
        suggestion = Suggestion(
            id="learned_test",
            name="Test",
            description="Test",
            category=SuggestionCategory.GENRE,
            source=SuggestionSource.LEARNED,
        )
        kb.add_suggestion(suggestion)
        kb.update_acceptance_rate("learned_test", True)
        assert kb.get_suggestion("learned_test").accepted_count == 1

    def test_save_learned_error_handling(self, temp_data_dir):
        """Test _save_learned error handling (line 292-293)."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)
        suggestion = Suggestion(
            id="save_test",
            name="Test",
            description="Test",
            category=SuggestionCategory.GENRE,
            source=SuggestionSource.LEARNED,
        )
        kb.add_suggestion(suggestion)
        kb.data_dir = Path("/nonexistent/path/for/testing")
        kb._save_learned()

    def test_datetime_obj_hook_valid(self):
        """Test _datetime_obj_hook with valid datetime string (line 94-95)."""
        kb = SuggestionKnowledgeBase.__new__(SuggestionKnowledgeBase)
        result = kb._datetime_obj_hook({"created_at": "2024-01-15T10:00:00"})
        assert "created_at" in result

    def test_load_category_static_error_handling(self, temp_data_dir):
        """Test _load_category_static handles exception (line 80→exit)."""
        genre_file = temp_data_dir / "genre_suggestions.yaml"
        genre_file.write_text("{{invalid yaml")
        SuggestionKnowledgeBase(data_dir=temp_data_dir)

    def test_get_suggestion_in_learned_cache(self, temp_data_dir):
        """Test get_suggestion returns from learned cache (line 190)."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)
        suggestion = Suggestion(
            id="learned_find",
            name="Find Me",
            description="Test",
            category=SuggestionCategory.GENRE,
            source=SuggestionSource.LEARNED,
        )
        kb.add_suggestion(suggestion)
        result = kb.get_suggestion("learned_find")
        assert result is not None
        assert result.name == "Find Me"

    def test_reload_cache(self, temp_data_dir):
        """Test reload_cache clears and reloads (line 219→exit)."""
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)
        kb.reload_cache()
        assert len(kb._static_cache) > 0

    def test_stats_counts(self, temp_data_dir):
        """Test get_stats with both static and learned (line 280, 321-324)."""
        genre_file = temp_data_dir / "genre_suggestions.yaml"
        data = {"genre_suggestions": {"en": [{"name": "G1", "description": "D1", "id": "g1"}]}}
        import yaml

        with open(genre_file, "w") as f:
            yaml.dump(data, f)
        kb = SuggestionKnowledgeBase(data_dir=temp_data_dir)
        suggestion = Suggestion(
            id="learned_1",
            name="L1",
            description="D1",
            category=SuggestionCategory.GENRE,
            source=SuggestionSource.LEARNED,
        )
        kb.add_suggestion(suggestion)
        stats = kb.get_stats()
        assert stats["total_learned_suggestions"] == 1
