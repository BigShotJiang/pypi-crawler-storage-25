from datetime import datetime

import pytest
from pydantic import ValidationError

from core.checkpoint_manager import Checkpoint, CheckpointManager
from core.progress_tracker import ExecutionStatus, ProgressState


@pytest.fixture
def temp_checkpoint_dir(tmp_path):
    checkpoint_dir = tmp_path / ".checkpoints"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    return tmp_path


@pytest.fixture
def sample_progress_state():
    return ProgressState(
        project_name="test_novel",
        current_phase="character_phase",
        completed_phases=["new_novel", "worldbuilding_phase"],
        total_steps=8,
        completed_steps=2,
        current_step="develop_characters",
        progress_percentage=25.0,
        start_time=datetime.now(),
        last_update=datetime.now(),
        status=ExecutionStatus.RUNNING,
    )


@pytest.fixture
def sample_checkpoint(sample_progress_state):
    return Checkpoint(
        project_name="test_novel",
        checkpoint_id="ckpt_001",
        timestamp=datetime.now(),
        completed_workflows=["new_novel", "worldbuilding_phase"],
        current_workflow="character_phase",
        execution_context={"novel_title": "Test Novel", "genre": "Fantasy"},
        progress_state=sample_progress_state,
    )


@pytest.fixture
def checkpoint_manager(temp_checkpoint_dir):
    return CheckpointManager(project_name="test_novel", storage_path=temp_checkpoint_dir)


class TestCheckpointModel:
    def test_checkpoint_creation(self, sample_checkpoint):
        assert sample_checkpoint.project_name == "test_novel"
        assert sample_checkpoint.checkpoint_id == "ckpt_001"
        assert len(sample_checkpoint.completed_workflows) == 2
        assert sample_checkpoint.current_workflow == "character_phase"

    def test_checkpoint_required_fields(self):
        with pytest.raises(ValidationError):
            Checkpoint(
                project_name="test",
                checkpoint_id="ckpt_001",
                timestamp=datetime.now(),
                completed_workflows=[],
                current_workflow="test",
                execution_context={},
                progress_state="not_a_progress_state",
            )

    def test_checkpoint_defaults(self, sample_progress_state):
        checkpoint = Checkpoint(
            project_name="test_novel",
            checkpoint_id="ckpt_002",
            timestamp=datetime.now(),
            completed_workflows=[],
            current_workflow=None,
            execution_context={},
            progress_state=sample_progress_state,
        )
        assert checkpoint.current_workflow is None
        assert checkpoint.completed_workflows == []


class TestCheckpointManager:
    def test_initialization(self, checkpoint_manager, temp_checkpoint_dir):
        assert checkpoint_manager.checkpoints_dir.exists()
        assert checkpoint_manager.storage_path == temp_checkpoint_dir

    def test_create_checkpoint(self, checkpoint_manager, sample_progress_state):
        checkpoint = checkpoint_manager.create_checkpoint(
            completed_workflows=["new_novel"],
            current_workflow="worldbuilding_phase",
            execution_context={"test": "context"},
            progress_state=sample_progress_state,
        )

        assert checkpoint.project_name == sample_progress_state.project_name
        assert checkpoint.current_workflow == "worldbuilding_phase"
        assert checkpoint.completed_workflows == ["new_novel"]
        assert checkpoint.execution_context == {"test": "context"}
        assert checkpoint.progress_state == sample_progress_state
        assert len(checkpoint.checkpoint_id) > 0

    def test_create_checkpoint_auto_id(self, checkpoint_manager, sample_progress_state):
        checkpoint1 = checkpoint_manager.create_checkpoint(
            completed_workflows=[],
            current_workflow="test",
            execution_context={},
            progress_state=sample_progress_state,
        )
        import time

        time.sleep(1.1)
        checkpoint2 = checkpoint_manager.create_checkpoint(
            completed_workflows=[],
            current_workflow="test",
            execution_context={},
            progress_state=sample_progress_state,
        )

        assert len(checkpoint1.checkpoint_id) > 0
        assert len(checkpoint2.checkpoint_id) > 0

    def test_save_and_load_checkpoint(self, checkpoint_manager, sample_progress_state):
        created = checkpoint_manager.create_checkpoint(
            completed_workflows=["new_novel"],
            current_workflow="worldbuilding_phase",
            execution_context={"key": "value"},
            progress_state=sample_progress_state,
        )

        loaded = checkpoint_manager.load_checkpoint(created.checkpoint_id)

        assert loaded is not None
        assert loaded.checkpoint_id == created.checkpoint_id
        assert loaded.project_name == created.project_name
        assert loaded.current_workflow == created.current_workflow
        assert loaded.execution_context == created.execution_context
        assert loaded.progress_state.project_name == sample_progress_state.project_name

    def test_load_latest_checkpoint(self, checkpoint_manager, sample_progress_state):
        checkpoint_manager.create_checkpoint(
            completed_workflows=["phase1"],
            current_workflow="phase2",
            execution_context={"order": 1},
            progress_state=sample_progress_state,
        )

        checkpoint_manager.create_checkpoint(
            completed_workflows=["phase1", "phase2"],
            current_workflow="phase3",
            execution_context={"order": 2},
            progress_state=sample_progress_state,
        )

        latest = checkpoint_manager.load_checkpoint()

        assert latest is not None
        assert latest.current_workflow == "phase3"
        assert latest.execution_context["order"] == 2

    def test_load_nonexistent_checkpoint(self, checkpoint_manager):
        loaded = checkpoint_manager.load_checkpoint("nonexistent_id")
        assert loaded is None

    def test_list_checkpoints(self, checkpoint_manager, sample_progress_state):
        checkpoint_manager.create_checkpoint(
            completed_workflows=["phase1"],
            current_workflow="phase2",
            execution_context={},
            progress_state=sample_progress_state,
        )
        import time

        time.sleep(0.01)
        checkpoint_manager.create_checkpoint(
            completed_workflows=["phase1", "phase2"],
            current_workflow="phase3",
            execution_context={},
            progress_state=sample_progress_state,
        )

        checkpoints = checkpoint_manager.list_checkpoints()

        assert len(checkpoints) >= 1
        assert all(isinstance(cp, Checkpoint) for cp in checkpoints)

    def test_list_checkpoints_empty(self, checkpoint_manager):
        checkpoints = checkpoint_manager.list_checkpoints()
        assert checkpoints == []

    def test_list_checkpoints_sorted(self, checkpoint_manager, sample_progress_state):
        checkpoint_manager.create_checkpoint(
            completed_workflows=["phase1"],
            current_workflow="phase2",
            execution_context={},
            progress_state=sample_progress_state,
        )

        import time

        time.sleep(1.1)
        checkpoint_manager.create_checkpoint(
            completed_workflows=["phase1", "phase2"],
            current_workflow="phase3",
            execution_context={},
            progress_state=sample_progress_state,
        )

        checkpoints = checkpoint_manager.list_checkpoints()

        assert len(checkpoints) >= 1

    def test_validate_checkpoint_valid(self, checkpoint_manager, sample_checkpoint):
        is_valid = checkpoint_manager.validate_checkpoint(sample_checkpoint)
        assert is_valid is True

    def test_validate_checkpoint_invalid_progress(self, checkpoint_manager):
        invalid_progress_state = ProgressState(
            project_name="wrong_project",
            current_phase="phase1",
            completed_phases=[],
            total_steps=0,
            completed_steps=0,
            progress_percentage=0.0,
            start_time=datetime.now(),
            last_update=datetime.now(),
            status=ExecutionStatus.RUNNING,
        )
        invalid_checkpoint = Checkpoint(
            project_name="test",
            checkpoint_id="invalid",
            timestamp=datetime.now(),
            completed_workflows=[],
            current_workflow="test",
            execution_context={},
            progress_state=invalid_progress_state,
        )

        is_valid = checkpoint_manager.validate_checkpoint(invalid_checkpoint)
        assert is_valid is False

    def test_delete_checkpoint(self, checkpoint_manager, sample_progress_state):
        created = checkpoint_manager.create_checkpoint(
            completed_workflows=["phase1"],
            current_workflow="phase2",
            execution_context={},
            progress_state=sample_progress_state,
        )

        deleted = checkpoint_manager.delete_checkpoint(created.checkpoint_id)
        assert deleted is True

        loaded = checkpoint_manager.load_checkpoint(created.checkpoint_id)
        assert loaded is None

    def test_delete_nonexistent_checkpoint(self, checkpoint_manager):
        deleted = checkpoint_manager.delete_checkpoint("nonexistent")
        assert deleted is False

    def test_checkpoint_persistence_across_instances(
        self, temp_checkpoint_dir, sample_progress_state
    ):
        manager1 = CheckpointManager(project_name="test_persist", storage_path=temp_checkpoint_dir)
        created = manager1.create_checkpoint(
            completed_workflows=["phase1"],
            current_workflow="phase2",
            execution_context={"persistent": "data"},
            progress_state=sample_progress_state,
        )

        manager2 = CheckpointManager(project_name="test_persist", storage_path=temp_checkpoint_dir)
        loaded = manager2.load_checkpoint(created.checkpoint_id)

        assert loaded is not None
        assert loaded.execution_context == {"persistent": "data"}

    def test_checkpoint_context_handling(self, checkpoint_manager, sample_progress_state):
        context = {
            "novel_title": "Test Novel",
            "genre": "Fantasy",
            "target_words": 80000,
            "chapter_count": 20,
            "nested": {"key": "value"},
        }

        checkpoint = checkpoint_manager.create_checkpoint(
            completed_workflows=[],
            current_workflow="test",
            execution_context=context,
            progress_state=sample_progress_state,
        )

        loaded = checkpoint_manager.load_checkpoint(checkpoint.checkpoint_id)

        assert loaded.execution_context == context
        assert loaded.execution_context["nested"]["key"] == "value"


class TestCheckpointManagerEdgeCases:
    @pytest.mark.skip(reason="Feature not implemented")
    def test_multiple_projects_separation(self, checkpoint_manager, temp_checkpoint_dir):
        project1_state = ProgressState(
            project_name="project1",
            current_phase="phase1",
            completed_phases=[],
            total_steps=5,
            completed_steps=0,
            progress_percentage=0.0,
            start_time=datetime.now(),
            last_update=datetime.now(),
            status=ExecutionStatus.RUNNING,
        )

        project2_state = ProgressState(
            project_name="project2",
            current_phase="phase1",
            completed_phases=[],
            total_steps=5,
            completed_steps=0,
            progress_percentage=0.0,
            start_time=datetime.now(),
            last_update=datetime.now(),
            status=ExecutionStatus.RUNNING,
        )

        checkpoint_manager.create_checkpoint(
            completed_workflows=[],
            current_workflow="phase1",
            execution_context={"project": "1"},
            progress_state=project1_state,
        )

        import time

        time.sleep(1.1)
        checkpoint_manager.create_checkpoint(
            completed_workflows=[],
            current_workflow="phase1",
            execution_context={"project": "2"},
            progress_state=project2_state,
        )

        checkpoints = checkpoint_manager.list_checkpoints()
        assert len(checkpoints) >= 1

        project1_checkpoints = [cp for cp in checkpoints if cp.project_name == "project1"]
        project2_checkpoints = [cp for cp in checkpoints if cp.project_name == "project2"]

        assert len(project1_checkpoints) == 1
        assert len(project2_checkpoints) == 1

    def test_checkpoint_with_empty_context(self, checkpoint_manager, sample_progress_state):
        checkpoint = checkpoint_manager.create_checkpoint(
            completed_workflows=["phase1"],
            current_workflow="phase2",
            execution_context={},
            progress_state=sample_progress_state,
        )

        loaded = checkpoint_manager.load_checkpoint(checkpoint.checkpoint_id)
        assert loaded.execution_context == {}

    def test_checkpoint_with_large_context(self, checkpoint_manager, sample_progress_state):
        large_context = {f"key_{i}": f"value_{i}" * 100 for i in range(50)}

        checkpoint = checkpoint_manager.create_checkpoint(
            completed_workflows=[],
            current_workflow="test",
            execution_context=large_context,
            progress_state=sample_progress_state,
        )

        loaded = checkpoint_manager.load_checkpoint(checkpoint.checkpoint_id)
        assert loaded.execution_context == large_context

    def test_checkpoint_with_special_characters(self, checkpoint_manager, sample_progress_state):
        special_context = {
            "title": "Novel with \"Quotes\" and 'Apostrophes'",
            "description": "Text with\nnewlines\nand\ttabs",
            "unicode": "Unicode characters: 你好 🚀",
        }

        checkpoint = checkpoint_manager.create_checkpoint(
            completed_workflows=[],
            current_workflow="test",
            execution_context=special_context,
            progress_state=sample_progress_state,
        )

        loaded = checkpoint_manager.load_checkpoint(checkpoint.checkpoint_id)
        assert loaded.execution_context == special_context
