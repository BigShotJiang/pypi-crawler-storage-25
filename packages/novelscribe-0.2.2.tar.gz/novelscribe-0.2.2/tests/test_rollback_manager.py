"""Tests for rollback_manager.py."""

from pathlib import Path
from unittest.mock import MagicMock, patch

from core.rollback_manager import (
    RollbackManager,
    RollbackResult,
    RollbackValidation,
)


class TestRollbackResult:
    """Tests for RollbackResult model."""

    def test_rollback_result_creation_success(self):
        """Test creating successful RollbackResult."""
        result = RollbackResult(
            success=True,
            chapter_number=1,
            from_version=3,
            to_version=2,
            backup_created=True,
            backup_path="/backup/path",
            warnings=["Warning message"],
        )
        assert result.success is True
        assert result.chapter_number == 1
        assert result.from_version == 3
        assert result.to_version == 2
        assert result.backup_created is True
        assert result.backup_path == "/backup/path"
        assert result.warnings == ["Warning message"]
        assert result.error_message is None

    def test_rollback_result_creation_failure(self):
        """Test creating failed RollbackResult."""
        result = RollbackResult(
            success=False,
            chapter_number=1,
            from_version=3,
            to_version=2,
            backup_created=False,
            error_message="Rollback failed",
        )
        assert result.success is False
        assert result.error_message == "Rollback failed"

    def test_rollback_result_defaults(self):
        """Test RollbackResult with default values."""
        result = RollbackResult(
            success=True, chapter_number=1, from_version=2, to_version=1, backup_created=False
        )
        assert result.backup_created is False
        assert result.backup_path is None
        assert result.warnings == []
        assert result.error_message is None


class TestRollbackValidation:
    """Tests for RollbackValidation model."""

    def test_rollback_validation_can_rollback(self):
        """Test RollbackValidation when rollback is allowed."""
        validation = RollbackValidation(
            can_rollback=True, reasons=[], warnings=["Warning"], dependency_issues=[]
        )
        assert validation.can_rollback is True
        assert validation.reasons == []
        assert validation.warnings == ["Warning"]
        assert validation.dependency_issues == []

    def test_rollback_validation_cannot_rollback(self):
        """Test RollbackValidation when rollback is not allowed."""
        validation = RollbackValidation(
            can_rollback=False,
            reasons=["Version not found"],
            warnings=[],
            dependency_issues=["Dependency issue"],
        )
        assert validation.can_rollback is False
        assert validation.reasons == ["Version not found"]
        assert validation.dependency_issues == ["Dependency issue"]

    def test_rollback_validation_defaults(self):
        """Test RollbackValidation with default values."""
        validation = RollbackValidation(can_rollback=True)
        assert validation.reasons == []
        assert validation.warnings == []
        assert validation.dependency_issues == []


class TestRollbackManager:
    """Tests for RollbackManager class."""

    def test_initialization(self, tmp_path):
        """Test RollbackManager initialization."""
        manager = RollbackManager(str(tmp_path))
        assert manager.project_dir == tmp_path
        assert manager.draft_manager is not None

    def test_validate_rollback_version_not_found(self, tmp_path):
        """Test validate_rollback when version doesn't exist."""
        manager = RollbackManager(str(tmp_path))

        validation = manager.validate_rollback(1, 99)
        assert validation.can_rollback is False
        assert "Version 99 not found" in validation.reasons[0]

    def test_validate_rollback_no_current_version(self, tmp_path):
        """Test validate_rollback when no current version exists."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "Content", "initial")

        validation = manager.validate_rollback(2, 1)
        assert validation.can_rollback is False
        assert "Version 1 not found" in validation.reasons[0]

    def test_validate_rollback_already_at_target(self, tmp_path):
        """Test validate_rollback when already at target version."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "Content", "initial")

        validation = manager.validate_rollback(1, 1)
        assert validation.can_rollback is False
        assert "Already at version 1" in validation.reasons[0]

    def test_validate_rollback_target_newer_than_current(self, tmp_path):
        """Test validate_rollback when target version is newer."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")

        validation = manager.validate_rollback(1, 5)
        assert validation.can_rollback is False
        assert "Version 5 not found" in validation.reasons[0]

    def test_validate_rollback_success(self, tmp_path):
        """Test validate_rollback success case."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")
        manager.draft_manager.create_new_version(1, "V3", "update")

        validation = manager.validate_rollback(1, 1)
        assert validation.can_rollback is True
        assert validation.reasons == []

    def test_check_for_warnings_multiple_versions(self, tmp_path):
        """Test _check_for_warnings with multiple versions."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")
        manager.draft_manager.create_new_version(1, "V3", "update")

        warnings = manager._check_for_warnings(1, 1, 3)
        assert len(warnings) > 0
        assert "Rolling back 2 versions" in warnings[0]

    def test_check_for_warnings_word_count_diff(self, tmp_path):
        """Test _check_for_warnings with significant word count difference."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "Short", "initial")
        long_content = "word " * 600
        manager.draft_manager.create_new_version(1, long_content, "update")

        warnings = manager._check_for_warnings(1, 1, 2)
        assert any("word count" in w.lower() for w in warnings)

    def test_check_dependencies_no_issues(self, tmp_path):
        """Test _check_dependencies with no dependency issues."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")

        issues = manager._check_dependencies(1, 1)
        assert issues == []

    def test_check_dependencies_with_issues(self, tmp_path):
        """Test _check_dependencies with dependency issues."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")
        manager.draft_manager.create_new_version(1, "V3", "update")

        manager.draft_manager.initialize_chapter(2, "Ch2 V1", "initial")
        manager.draft_manager.create_new_version(
            2, "Ch2 V2", "update", quality_score=0.8, issues_fixed=[]
        )

        issues = manager._check_dependencies(2, 1)
        assert len(issues) >= 0

    def test_rollback_validation_fails(self, tmp_path):
        """Test rollback when validation fails."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "V1", "initial")

        result = manager.rollback(1, 99, create_backup=False, force=False)
        assert result.success is False
        assert "Version 99 not found" in result.error_message

    def test_rollback_dependency_issues_no_force(self, tmp_path):
        """Test rollback with dependency issues without force."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")
        manager.draft_manager.create_new_version(1, "V3", "update")

        result = manager.rollback(1, 2, create_backup=False, force=False)
        assert result.success is True

    def test_create_backup(self, tmp_path):
        """Test _create_backup method."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "Content to backup", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")

        current_file = tmp_path / "chapters" / "chapter_001" / "current.md"
        current_file.write_text("Current content to backup")

        backup_path = manager._create_backup(1, 2)

        assert backup_path is not None
        assert "backup" in backup_path
        assert Path(backup_path).exists()
        assert Path(backup_path).read_text() == "Current content to backup"

    def test_create_backup_no_current_file(self, tmp_path):
        """Test _create_backup when current file doesn't exist."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "Content", "initial")

        current_file = tmp_path / "chapters" / "chapter_001" / "current.md"
        if current_file.exists():
            current_file.unlink()

        backup_path = manager._create_backup(1, 1)
        assert backup_path is not None

    def test_restore_version(self, tmp_path):
        """Test _restore_version method."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")

        manager._restore_version(1, 1, "Restored content")

        current_file = tmp_path / "chapters" / "chapter_001" / "current.md"
        assert current_file.exists()
        assert current_file.read_text() == "Restored content"

    def test_restore_version_creates_directory(self, tmp_path):
        """Test _restore_version creates directory if needed."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "V1", "initial")

        chapter_dir = tmp_path / "chapters" / "chapter_001"
        if chapter_dir.exists():
            import shutil

            shutil.rmtree(chapter_dir)

        manager._restore_version(1, 1, "Content")

        current_file = tmp_path / "chapters" / "chapter_001" / "current.md"
        assert current_file.exists()

    def test_rollback_success(self, tmp_path):
        """Test successful rollback."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "Version 1", "initial")
        manager.draft_manager.create_new_version(1, "Version 2", "update")
        manager.draft_manager.create_new_version(1, "Version 3", "update")

        current_file = tmp_path / "chapters" / "chapter_001" / "current.md"
        current_file.write_text("Current version 3 content")

        result = manager.rollback(1, 2, create_backup=True, force=False)

        assert result.success is True
        assert result.from_version == 3
        assert result.to_version == 2
        assert result.backup_created is True
        assert result.backup_path is not None

        assert current_file.read_text() == "Version 2"

    def test_rollback_force_skip_validation(self, tmp_path):
        """Test rollback with force flag skips validation."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "V1 content", "initial")
        manager.draft_manager.create_new_version(1, "V2 content", "update")
        manager.draft_manager.create_new_version(1, "V3 content", "update")

        current_file = tmp_path / "chapters" / "chapter_001" / "current.md"
        current_file.write_text("Current V3")

        result = manager.rollback(1, 2, create_backup=False, force=True)
        assert result.success is True
        assert current_file.read_text() == "V2 content"

    def test_rollback_content_not_found(self, tmp_path):
        """Test rollback when content cannot be retrieved."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")

        with patch.object(manager.draft_manager, "get_version_content", return_value=None):
            result = manager.rollback(1, 1, create_backup=False, force=True)

        assert result.success is False
        assert "Could not retrieve content" in result.error_message

    def test_rollback_exception_handling(self, tmp_path):
        """Test rollback handles exceptions properly."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "V1 content", "initial")
        manager.draft_manager.create_new_version(1, "V2 content", "update")
        manager.draft_manager.create_new_version(1, "V3 content", "update")

        current_file = tmp_path / "chapters" / "chapter_001" / "current.md"
        current_file.write_text("Current V3")

        with patch.object(manager, "_restore_version", side_effect=RuntimeError("Test error")):
            result = manager.rollback(1, 2, create_backup=False, force=True)

        assert result.success is False
        assert "Test error" in result.error_message

    def test_batch_rollback(self, tmp_path):
        """Test batch_rollback method."""
        manager = RollbackManager(str(tmp_path))

        for i in range(1, 4):
            manager.draft_manager.initialize_chapter(i, f"Ch{i} V1", "initial")
            manager.draft_manager.create_new_version(i, f"Ch{i} V2", "update")

        results = manager.batch_rollback([1, 2, 3], 1, create_backup=False, force=True)

        assert len(results) == 3
        assert results[0].chapter_number == 1
        assert results[1].chapter_number == 2
        assert results[2].chapter_number == 3

    def test_list_backups_no_directory(self, tmp_path):
        """Test list_backups when backup directory doesn't exist."""
        manager = RollbackManager(str(tmp_path))

        backups = manager.list_backups(1)
        assert backups == []

    def test_list_backups(self, tmp_path):
        """Test list_backups method."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "Content", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")
        manager.draft_manager.create_new_version(1, "V3", "update")

        current_file = tmp_path / "chapters" / "chapter_001" / "current.md"
        current_file.write_text("Current content")

        with patch("time.sleep"):
            manager._create_backup(1, 3)
            manager._create_backup(1, 2)
            manager._create_backup(1, 3)

        backups = manager.list_backups(1)

        assert len(backups) >= 1
        assert "size" in backups[0]
        assert "created" in backups[0]
        assert "filename" in backups[0]

    def test_delete_backup_exists(self, tmp_path):
        """Test delete_backup when file exists."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "Content", "initial")
        current_file = tmp_path / "chapters" / "chapter_001" / "current.md"
        current_file.write_text("Content")

        backup_path = manager._create_backup(1, 1)
        backup_filename = Path(backup_path).name

        result = manager.delete_backup(1, backup_filename)
        assert result is True
        assert not Path(backup_path).exists()

    def test_delete_backup_not_exists(self, tmp_path):
        """Test delete_backup when file doesn't exist."""
        manager = RollbackManager(str(tmp_path))

        result = manager.delete_backup(1, "nonexistent.md")
        assert result is False

    def test_cleanup_old_backups_none_to_delete(self, tmp_path):
        """Test cleanup_old_backups when no cleanup needed."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "Content", "initial")

        manager._create_backup(1, 1)

        deleted = manager.cleanup_old_backups(1, keep_recent=5)
        assert deleted == 0

    def test_cleanup_old_backups(self, tmp_path):
        """Test cleanup_old_backups method."""
        manager = RollbackManager(str(tmp_path))

        manager.draft_manager.initialize_chapter(1, "Content", "initial")

        for i in range(5):
            current_file = tmp_path / "chapters" / "chapter_001" / "current.md"
            current_file.write_text(f"Content {i}")
            manager._create_backup(1, 1)

        manager.cleanup_old_backups(1, keep_recent=3)

        backups_after = manager.list_backups(1)

        assert len(backups_after) <= 3


class TestRollbackManagerMissingCoverage:
    """Tests for missing coverage lines in rollback_manager.py."""

    def test_validate_rollback_no_current_version_direct(self, tmp_path):
        """Test validate_rollback when target exists but current doesn't (line 53)."""
        manager = RollbackManager(str(tmp_path))
        manager.draft_manager.initialize_chapter(2, "Content", "initial")
        validation = manager.validate_rollback(2, 1)
        assert validation.can_rollback is False

    def test_validate_rollback_target_newer_than_current_path(self, tmp_path):
        """Test validate_rollback target version newer than current (line 64)."""
        manager = RollbackManager(str(tmp_path))
        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")
        with patch.object(
            manager.draft_manager, "list_versions", return_value=[MagicMock(version=5)]
        ):
            validation = manager.validate_rollback(1, 5)
            assert validation.can_rollback is False

    def test_validate_target_not_in_version_history(self, tmp_path):
        """Test validate_rollback when target not in version list (line 76)."""
        manager = RollbackManager(str(tmp_path))
        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")
        from datetime import datetime

        from core.draft_manager import DraftMetadata

        v1 = DraftMetadata(
            chapter_number=1,
            version=1,
            timestamp=datetime.now(),
            word_count=1,
            regeneration_reason="init",
            status="active",
            file_path="",
        )
        with patch.object(manager.draft_manager, "get_version", side_effect=[v1, v1]):
            with patch.object(manager.draft_manager, "get_current_version", return_value=v1):
                validation = manager.validate_rollback(1, 99)
                assert validation.can_rollback is False

    def test_rollback_dependency_issues_blocks(self, tmp_path):
        """Test rollback blocked by dependency issues (line 174)."""
        manager = RollbackManager(str(tmp_path))
        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")
        manager.draft_manager.create_new_version(1, "V3", "update")
        mock_validation = RollbackValidation(
            can_rollback=True,
            reasons=[],
            warnings=[],
            dependency_issues=["Chapter 2 depends on version 3"],
        )
        with patch.object(manager, "validate_rollback", return_value=mock_validation):
            result = manager.rollback(1, 1, create_backup=False, force=False)
        assert result.success is False
        assert "Dependency issues" in result.error_message

    def test_restore_version_with_no_metadata(self, tmp_path):
        """Test _restore_version when get_version returns None (line 262→exit)."""
        manager = RollbackManager(str(tmp_path))
        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        with patch.object(manager.draft_manager, "get_version", return_value=None):
            manager._restore_version(1, 1, "Restored content")
        current_file = tmp_path / "chapters" / "chapter_001" / "current.md"
        assert current_file.exists()

    def test_restore_version_no_existing_metadata_attr(self, tmp_path):
        """Test _restore_version when draft_manager has no _metadata attr (line 277-286)."""
        manager = RollbackManager(str(tmp_path))
        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager._restore_version(1, 1, "Test content")
        assert hasattr(manager.draft_manager, "_metadata")
        assert "chapter_001" in manager.draft_manager._metadata

    def test_restore_version_missing_chapter_key(self, tmp_path):
        """Test _restore_version when chapter_key not in _metadata (line 280-281)."""
        manager = RollbackManager(str(tmp_path))
        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager._restore_version(1, 1, "Test content")
        assert "chapter_001" in manager.draft_manager._metadata

    def test_quality_score_warning_in_check_warnings(self, tmp_path):
        """Test _check_for_warnings with quality score diff (lines 118-120)."""
        manager = RollbackManager(str(tmp_path))
        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager.draft_manager.create_new_version(
            1, "V2", "update", quality_score=0.3, issues_fixed=[]
        )
        manager.draft_manager.create_new_version(
            1, "V3", "update", quality_score=0.9, issues_fixed=[]
        )
        warnings = manager._check_for_warnings(1, 2, 3)
        assert any("quality" in w.lower() or "score" in w.lower() for w in warnings)


class TestRollbackManagerAdditionalCoverage:
    """Additional tests for remaining missing coverage lines."""

    def test_validate_rollback_target_not_in_version_numbers(self, tmp_path):
        """Test validate_rollback when target not in version numbers list (line 76)."""
        from datetime import datetime
        from unittest.mock import patch

        from core.draft_manager import DraftMetadata

        manager = RollbackManager(str(tmp_path))
        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")

        v1 = DraftMetadata(
            chapter_number=1,
            version=1,
            timestamp=datetime.now(),
            word_count=1,
            status="active",
            file_path="",
        )
        v2 = DraftMetadata(
            chapter_number=1,
            version=2,
            timestamp=datetime.now(),
            word_count=1,
            status="active",
            file_path="",
        )
        with patch.object(manager.draft_manager, "get_version", side_effect=[v1, v2]):
            with patch.object(manager.draft_manager, "get_current_version", return_value=v2):
                with patch.object(manager.draft_manager, "list_versions", return_value=[v1, v2]):
                    validation = manager.validate_rollback(1, 99)
                    assert validation.can_rollback is False

    def test_check_dependencies_with_parent_version(self, tmp_path):
        """Test _check_dependencies when other chapter has parent_version > target."""
        manager = RollbackManager(str(tmp_path))
        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")
        manager.draft_manager.create_new_version(1, "V3", "update")
        manager.draft_manager.initialize_chapter(2, "Ch2 V1", "initial")
        manager.draft_manager.create_new_version(2, "Ch2 V2", "update")
        issues = manager._check_dependencies(1, 1)
        assert len(issues) >= 0

    def test_restore_version_no_metadata_attr(self, tmp_path):
        """Test _restore_version when _metadata attribute missing (line 278)."""
        from datetime import datetime

        from core.draft_manager import DraftMetadata

        manager = RollbackManager(str(tmp_path))
        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        delattr(manager.draft_manager, "_metadata")
        v1 = DraftMetadata(
            chapter_number=1,
            version=1,
            timestamp=datetime.now(),
            word_count=1,
            regeneration_reason="initial",
            status="active",
            file_path="",
        )
        with patch.object(manager.draft_manager, "get_version", return_value=v1):
            with patch.object(manager.draft_manager, "_save_metadata"):
                manager._restore_version(1, 1, "Test content")
        assert "chapter_001" in manager.draft_manager._metadata

    def test_restore_version_chapter_key_not_in_metadata(self, tmp_path):
        """Test _restore_version when chapter_key not in _metadata (line 281)."""
        from datetime import datetime

        from core.draft_manager import DraftMetadata

        manager = RollbackManager(str(tmp_path))
        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        v1 = DraftMetadata(
            chapter_number=1,
            version=1,
            timestamp=datetime.now(),
            word_count=1,
            regeneration_reason="initial",
            status="active",
            file_path="",
        )
        manager.draft_manager._metadata = {"other_key": {}}
        with patch.object(manager.draft_manager, "get_version", return_value=v1):
            manager._restore_version(1, 1, "Test content")
        assert "chapter_001" in manager.draft_manager._metadata

    def test_cleanup_old_backups_deletes_excess(self, tmp_path):
        """Test cleanup_old_backups actually deletes backups (line 360→359)."""
        manager = RollbackManager(str(tmp_path))
        manager.draft_manager.initialize_chapter(1, "Content", "initial")
        backup_dir = tmp_path / "chapters" / "chapter_001" / "backups"
        backup_dir.mkdir(parents=True, exist_ok=True)
        with patch("time.sleep"):
            for i in range(7):
                bf = backup_dir / f"chapter_001_v001_backup_20240101_{i:06d}.md"
                bf.write_text(f"Backup content {i}")
        deleted = manager.cleanup_old_backups(1, keep_recent=3)
        assert deleted >= 4
        remaining = manager.list_backups(1)
        assert len(remaining) <= 3

    def test_validate_no_current_version(self, tmp_path):
        """Test validate_rollback when target exists but current doesn't (line 53)."""
        from datetime import datetime

        from core.draft_manager import DraftMetadata

        manager = RollbackManager(str(tmp_path))
        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")
        v1 = DraftMetadata(
            chapter_number=1,
            version=1,
            timestamp=datetime.now(),
            word_count=1,
            status="active",
            file_path="",
        )
        with patch.object(manager.draft_manager, "get_version", return_value=v1):
            with patch.object(
                manager.draft_manager, "get_current_version", side_effect=[None, None]
            ):
                validation = manager.validate_rollback(1, 1)
                assert validation.can_rollback is False

    def test_validate_target_not_in_version_list(self, tmp_path):
        """Test validate_rollback when target not in version list (line 76)."""
        from datetime import datetime

        from core.draft_manager import DraftMetadata

        manager = RollbackManager(str(tmp_path))
        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")
        v1 = DraftMetadata(
            chapter_number=1,
            version=1,
            timestamp=datetime.now(),
            word_count=1,
            status="active",
            file_path="",
        )
        v2 = DraftMetadata(
            chapter_number=1,
            version=2,
            timestamp=datetime.now(),
            word_count=1,
            status="active",
            file_path="",
        )
        v3 = MagicMock(version=3)
        with patch.object(manager.draft_manager, "get_version", side_effect=[v3, v3]):
            with patch.object(manager.draft_manager, "get_current_version", return_value=v2):
                with patch.object(manager.draft_manager, "list_versions", return_value=[v1, v2]):
                    validation = manager.validate_rollback(1, 3)
                    assert validation.can_rollback is False

    def test_check_warnings_word_and_quality(self, tmp_path):
        """Test _check_for_warnings with word count and quality score (lines 112→125, 119→125)."""
        manager = RollbackManager(str(tmp_path))
        short_content = "word"
        manager.draft_manager.initialize_chapter(1, short_content, "initial")
        long_content = "word " * 900
        manager.draft_manager.create_new_version(
            1, long_content, "update", quality_score=0.9, issues_fixed=[]
        )
        manager.draft_manager.create_new_version(
            1, "short again", "update", quality_score=0.3, issues_fixed=[]
        )
        warnings = manager._check_for_warnings(1, 1, 3)
        assert len(warnings) > 0

    def test_check_dependencies_parent_version_gt_target(self, tmp_path):
        """Test _check_dependencies when parent_version > target (lines 140→132, 142)."""
        from datetime import datetime

        from core.draft_manager import DraftMetadata

        manager = RollbackManager(str(tmp_path))
        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        manager.draft_manager.create_new_version(1, "V2", "update")
        manager.draft_manager.initialize_chapter(2, "Ch2 V1", "initial")
        manager.draft_manager.create_new_version(2, "Ch2 V2", "update")
        ch2_v2 = DraftMetadata(
            chapter_number=2,
            version=2,
            timestamp=datetime.now(),
            word_count=1,
            parent_version=5,
            status="active",
            file_path="",
        )
        with patch.object(manager.draft_manager, "get_current_version", return_value=ch2_v2):
            issues = manager._check_dependencies(1, 1)
            assert len(issues) > 0
            assert any("depends on version" in i for i in issues)

    def test_restore_version_no_metadata_attr_direct(self, tmp_path):
        """Test _restore_version creates _metadata attr when missing (line 278)."""
        from datetime import datetime

        from core.draft_manager import DraftMetadata

        manager = RollbackManager(str(tmp_path))
        manager.draft_manager.initialize_chapter(1, "V1", "initial")
        delattr(manager.draft_manager, "_metadata")
        v1 = DraftMetadata(
            chapter_number=1,
            version=1,
            timestamp=datetime.now(),
            word_count=1,
            regeneration_reason="initial",
            status="active",
            file_path="",
        )
        with patch.object(manager.draft_manager, "get_version", return_value=v1):
            with patch.object(manager.draft_manager, "_save_metadata"):
                manager._restore_version(1, 1, "Test content")
        assert hasattr(manager.draft_manager, "_metadata")
        assert "chapter_001" in manager.draft_manager._metadata
