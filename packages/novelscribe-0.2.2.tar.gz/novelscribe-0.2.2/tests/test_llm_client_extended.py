"""Extended tests for llm_client.py to increase coverage from 50%."""

from unittest.mock import Mock, patch

import pytest

from core.llm_client import (
    LLMClientFactory,
    LLMConfig,
    LLMError,
    LLMProvider,
    LLMResponse,
    OpenAIClient,
)


class TestLLMResponse:
    """Test LLMResponse model."""

    def test_response_creation(self):
        """Test creating LLM response."""
        response = LLMResponse(
            content="Test response",
            model="gpt-4",
            provider="openai",
        )
        assert response.content == "Test response"
        assert response.model == "gpt-4"
        assert response.provider == "openai"
        assert response.tokens_used is None
        assert response.finish_reason is None

    def test_response_with_all_fields(self):
        """Test response with all fields."""
        response = LLMResponse(
            content="Test response",
            model="gpt-4",
            provider="openai",
            tokens_used=100,
            finish_reason="stop",
        )
        assert response.tokens_used == 100
        assert response.finish_reason == "stop"


class TestLLMProvider:
    """Test LLMProvider enum."""

    def test_provider_values(self):
        """Test provider enum values."""
        assert LLMProvider.OPENAI.value == "openai"


class TestOpenAIClient:
    """Test OpenAI client."""

    def setup_method(self):
        """Set up test fixtures."""
        self.config = LLMConfig(
            provider="openai",
            model="gpt-4",
            api_key="test-key",
        )

    @patch("openai.OpenAI")
    def test_openai_client_initialization(self, mock_openai_class):
        """Test OpenAI client initialization."""
        mock_client = Mock()
        mock_openai_class.return_value = mock_client

        client = OpenAIClient(self.config)
        assert client.config == self.config
        assert client.client == mock_client
        mock_openai_class.assert_called_once()

    @patch("openai.OpenAI")
    def test_openai_client_generate_success(self, mock_openai_class):
        """Test successful OpenAI generation."""
        mock_client = Mock()
        mock_response = Mock()
        mock_choice = Mock()
        mock_choice.message.content = "Test content"
        mock_choice.finish_reason = "stop"
        mock_response.choices = [mock_choice]
        mock_response.model = "gpt-4"
        mock_response.usage.prompt_tokens = 10
        mock_response.usage.completion_tokens = 20
        mock_response.usage.total_tokens = 30
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai_class.return_value = mock_client

        client = OpenAIClient(self.config)
        response = client.generate("", "Test prompt")

        assert isinstance(response, LLMResponse)
        assert response.content == "Test content"
        assert response.provider == "openai"
        assert response.model == "gpt-4"
        assert response.tokens_used == 30

    @patch("openai.OpenAI")
    def test_openai_client_generate_with_system_prompt(self, mock_openai_class):
        """Test OpenAI generation with system prompt."""
        mock_client = Mock()
        mock_response = Mock()
        mock_choice = Mock()
        mock_choice.message.content = "Test content"
        mock_choice.finish_reason = "stop"
        mock_response.choices = [mock_choice]
        mock_response.model = "gpt-4"
        mock_response.usage.prompt_tokens = 10
        mock_response.usage.completion_tokens = 20
        mock_response.usage.total_tokens = 30
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai_class.return_value = mock_client

        client = OpenAIClient(self.config)
        response = client.generate(
            "You are a helpful assistant.",
            "Test prompt",
        )

        assert response.content == "Test content"
        # Verify system_prompt was passed
        mock_client.chat.completions.create.assert_called_once()
        call_args = mock_client.chat.completions.create.call_args
        assert call_args.kwargs["messages"][0]["role"] == "system"
        assert "helpful assistant" in call_args.kwargs["messages"][0]["content"]

    def test_openai_client_generate_with_temperature(self):
        """Test OpenAI generation with custom temperature from config."""
        config = LLMConfig(
            provider="openai",
            model="gpt-4",
            api_key="test-key",
            temperature=0.5,
        )

        with patch("openai.OpenAI") as mock_openai_class:
            mock_client = Mock()
            mock_response = Mock()
            mock_choice = Mock()
            mock_choice.message.content = "Test content"
            mock_choice.finish_reason = "stop"
            mock_response.choices = [mock_choice]
            mock_response.model = "gpt-4"
            mock_response.usage.prompt_tokens = 10
            mock_response.usage.completion_tokens = 20
            mock_response.usage.total_tokens = 30
            mock_client.chat.completions.create.return_value = mock_response
            mock_openai_class.return_value = mock_client

            client = OpenAIClient(config)
            response = client.generate("", "Test prompt")

            assert response.content == "Test content"
            # Verify temperature was passed
            call_args = mock_client.chat.completions.create.call_args
            assert call_args.kwargs.get("temperature") == 0.5

    @patch("openai.OpenAI")
    def test_openai_client_generate_error(self, mock_openai_class):
        """Test OpenAI generation with error."""
        mock_client = Mock()
        mock_client.chat.completions.create.side_effect = Exception("API Error")
        mock_openai_class.return_value = mock_client

        client = OpenAIClient(self.config)

        with pytest.raises(LLMError, match="OpenAI API error"):
            client.generate("", "Test prompt")


class TestLLMClientFactoryExtended:
    """Extended tests for LLM client factory."""

    def test_create_openai(self):
        """Test creating OpenAI client via factory."""
        config = LLMConfig(provider="openai", model="gpt-4")
        client = LLMClientFactory.create(config)
        assert isinstance(client, OpenAIClient)

    def test_create_invalid_provider(self):
        """Test creating client with invalid provider."""
        config = LLMConfig(provider="invalid")
        with pytest.raises(LLMError):
            LLMClientFactory.create(config)


class TestLLMConfigExtended:
    """Extended tests for LLM configuration."""

    def test_config_with_max_tokens(self):
        """Test config with max tokens."""
        config = LLMConfig(max_tokens=1000)
        assert config.max_tokens == 1000

    def test_config_with_timeout(self):
        """Test config with timeout."""
        config = LLMConfig(timeout=60)
        assert config.timeout == 60

    def test_config_with_all_parameters(self):
        """Test config with all parameters."""
        config = LLMConfig(
            provider="openai",
            model="gpt-4",
            temperature=0.5,
            max_tokens=2000,
            timeout=60,
            api_key="test-key",
        )
        assert config.provider == "openai"
        assert config.model == "gpt-4"
        assert config.temperature == 0.5
        assert config.max_tokens == 2000
        assert config.timeout == 60
        assert config.api_key == "test-key"


class TestLLMError:
    """Test LLMError exception."""

    def test_error_creation(self):
        """Test creating LLM error."""
        error = LLMError("Test error message")
        assert str(error) == "Test error message"

    def test_error_is_exception(self):
        """Test LLMError is an Exception."""
        assert issubclass(LLMError, Exception)
