"""Comprehensive tests for parallel executor coverage improvement."""

from unittest.mock import Mock

import pytest

from core.parallel_executor import (
    ExecutionGraph,
    ExecutionNode,
    ExecutionResult,
    ExecutionStatus,
    ParallelExecutor,
    get_parallel_executor,
)


class TestExecutionStatus:
    """Test ExecutionStatus enumeration."""

    def test_status_values(self):
        """Test status enum values."""
        assert ExecutionStatus.PENDING.value == "pending"
        assert ExecutionStatus.READY.value == "ready"
        assert ExecutionStatus.RUNNING.value == "running"
        assert ExecutionStatus.COMPLETED.value == "completed"
        assert ExecutionStatus.FAILED.value == "failed"
        assert ExecutionStatus.SKIPPED.value == "skipped"


class TestExecutionNode:
    """Test ExecutionNode dataclass."""

    def test_node_creation(self):
        """Test creating a node."""
        node = ExecutionNode(agent_name="test_agent")
        assert node.agent_name == "test_agent"
        assert node.status == ExecutionStatus.PENDING
        assert node.dependencies == []
        assert node.dependents == []
        assert node.retry_count == 0
        assert node.max_retries == 3

    def test_node_with_dependencies(self):
        """Test node with dependencies."""
        node = ExecutionNode(agent_name="test_agent", dependencies=["dep1", "dep2"])
        assert node.dependencies == ["dep1", "dep2"]

    def test_is_ready_with_no_dependencies(self):
        """Test is_ready with no dependencies."""
        node = ExecutionNode(agent_name="test_agent")
        assert node.is_ready is True

    def test_is_ready_with_completed_dependencies(self):
        """Test is_ready with completed dependencies."""
        node = ExecutionNode(
            agent_name="test_agent",
            dependencies=[ExecutionStatus.COMPLETED, ExecutionStatus.COMPLETED],
        )
        assert node.is_ready is True

    def test_is_ready_with_pending_dependencies(self):
        """Test is_ready with pending dependencies."""
        node = ExecutionNode(
            agent_name="test_agent",
            dependencies=[ExecutionStatus.PENDING, ExecutionStatus.COMPLETED],
        )
        assert node.is_ready is False

    def test_can_run_parallel(self):
        """Test can_run_parallel property."""
        node = ExecutionNode(agent_name="test_agent")
        node.status = ExecutionStatus.READY
        assert node.can_run_parallel is True

    def test_to_dict(self):
        """Test to_dict method."""
        node = ExecutionNode(agent_name="test_agent")
        node.status = ExecutionStatus.COMPLETED
        node.result = "test_result"
        node.start_time = 1.0
        node.end_time = 2.0
        node.duration = 1.0

        result = node.to_dict()
        assert result["agent_name"] == "test_agent"
        assert result["status"] == "completed"
        assert result["duration"] == 1.0


class TestExecutionResult:
    """Test ExecutionResult dataclass."""

    def test_result_creation(self):
        """Test creating a result."""
        result = ExecutionResult(
            success=True,
            completed_nodes=["node1"],
            failed_nodes=[],
            skipped_nodes=[],
            total_duration=1.5,
            node_results={"node1": "result1"},
            errors={},
        )
        assert result.success is True
        assert result.completed_nodes == ["node1"]

    def test_to_dict(self):
        """Test to_dict method."""
        result = ExecutionResult(
            success=True,
            completed_nodes=["node1"],
            failed_nodes=[],
            skipped_nodes=[],
            total_duration=1.5,
            node_results={"node1": "result1"},
            errors={},
            parallel_speedup=2.0,
        )

        result_dict = result.to_dict()
        assert result_dict["success"] is True
        assert result_dict["parallel_speedup"] == "2.00x"


class TestExecutionGraph:
    """Test ExecutionGraph class."""

    def test_graph_creation(self):
        """Test creating an empty graph."""
        graph = ExecutionGraph()
        assert len(graph.nodes) == 0
        assert len(graph.edges) == 0

    def test_add_node(self):
        """Test adding a node to graph."""
        graph = ExecutionGraph()
        node = ExecutionNode(agent_name="agent1")
        graph.add_node(node)

        assert len(graph.nodes) == 1
        assert node.agent_id in graph.nodes

    def test_add_edge(self):
        """Test adding an edge to graph."""
        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2")

        graph.add_node(node1)
        graph.add_node(node2)
        graph.add_edge(node1.agent_id, node2.agent_id)

        assert node2.agent_id in graph.edges[node1.agent_id]
        assert node1.agent_id in node2.dependencies
        assert node2.agent_id in node1.dependents

    def test_get_ready_nodes(self):
        """Test getting ready nodes."""
        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2")

        graph.add_node(node1)
        graph.add_node(node2)
        graph.add_edge(node1.agent_id, node2.agent_id)

        node1.status = ExecutionStatus.READY

        ready = graph.get_ready_nodes()
        assert len(ready) == 1
        assert ready[0].agent_id == node1.agent_id

    def test_topological_sort_linear(self):
        """Test topological sort with linear dependencies."""
        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2")
        node3 = ExecutionNode(agent_name="agent3")

        graph.add_node(node1)
        graph.add_node(node2)
        graph.add_node(node3)

        graph.add_edge(node1.agent_id, node2.agent_id)
        graph.add_edge(node2.agent_id, node3.agent_id)

        order = graph.topological_sort()
        assert order == [node1.agent_id, node2.agent_id, node3.agent_id]

    def test_topological_sort_parallel(self):
        """Test topological sort with parallel branches."""
        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2")
        node3 = ExecutionNode(agent_name="agent3")
        node4 = ExecutionNode(agent_name="agent4")

        graph.add_node(node1)
        graph.add_node(node2)
        graph.add_node(node3)
        graph.add_node(node4)

        graph.add_edge(node1.agent_id, node2.agent_id)
        graph.add_edge(node1.agent_id, node3.agent_id)
        graph.add_edge(node2.agent_id, node4.agent_id)
        graph.add_edge(node3.agent_id, node4.agent_id)

        order = graph.topological_sort()
        assert order[0] == node1.agent_id
        assert order[-1] == node4.agent_id

    def test_topological_sort_with_cycle(self):
        """Test topological sort detects cycles."""
        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2")

        graph.add_node(node1)
        graph.add_node(node2)

        graph.add_edge(node1.agent_id, node2.agent_id)
        graph.add_edge(node2.agent_id, node1.agent_id)

        with pytest.raises(ValueError, match="cycles"):
            graph.topological_sort()

    def test_detect_cycles(self):
        """Test cycle detection."""
        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2")

        graph.add_node(node1)
        graph.add_node(node2)

        graph.add_edge(node1.agent_id, node2.agent_id)
        graph.add_edge(node2.agent_id, node1.agent_id)

        cycles = graph.detect_cycles()
        assert len(cycles) > 0

    def test_validate_success(self):
        """Test graph validation success."""
        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        graph.add_node(node1)

        is_valid, errors = graph.validate()
        assert is_valid is True
        assert len(errors) == 0

    def test_validate_with_cycles(self):
        """Test graph validation with cycles."""
        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2")

        graph.add_node(node1)
        graph.add_node(node2)
        graph.add_edge(node1.agent_id, node2.agent_id)
        graph.add_edge(node2.agent_id, node1.agent_id)

        is_valid, errors = graph.validate()
        assert is_valid is False
        assert len(errors) > 0

    def test_validate_with_missing_dependencies(self):
        """Test graph validation with missing dependencies."""
        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1", dependencies=["missing"])

        graph.add_node(node1)

        is_valid, errors = graph.validate()
        assert is_valid is False
        assert any("missing" in error for error in errors)


class TestParallelExecutor:
    """Test ParallelExecutor class."""

    def test_initialization(self):
        """Test executor initialization."""
        executor = ParallelExecutor(max_workers=4, timeout=100)
        assert executor.max_workers == 4
        assert executor.timeout == 100

    def test_initialization_defaults(self):
        """Test executor initialization with defaults."""
        executor = ParallelExecutor()
        assert executor.max_workers == 4
        assert executor.timeout == 300

    def test_add_progress_callback(self):
        """Test adding progress callback."""
        executor = ParallelExecutor()
        callback = Mock()

        executor.add_progress_callback(callback)
        assert callback in executor.progress_callbacks

    def test_build_graph_from_workflow(self):
        """Test building graph from workflow steps."""
        executor = ParallelExecutor()
        steps = [
            {"agent": "agent1", "dependencies": []},
            {"agent": "agent2", "dependencies": [0]},
            {"agent": "agent3", "dependencies": [0]},
        ]

        graph = executor.build_graph_from_workflow(steps)
        assert len(graph.nodes) == 3

    def test_build_graph_from_workflow_with_string_dependencies(self):
        """Test building graph with string dependencies."""
        executor = ParallelExecutor()
        steps = [
            {"agent": "agent1", "dependencies": []},
            {"agent": "agent2", "dependencies": ["agent1"]},
        ]

        graph = executor.build_graph_from_workflow(steps)
        assert len(graph.nodes) == 2

    def test_execute_parallel_success(self):
        """Test successful parallel execution."""
        executor = ParallelExecutor(max_workers=2)

        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2")
        graph.add_node(node1)
        graph.add_node(node2)

        agent_functions = {
            "agent1": lambda: "result1",
            "agent2": lambda: "result2",
        }

        result = executor.execute_parallel(graph, agent_functions)
        assert result.success is True
        assert len(result.completed_nodes) == 2
        assert len(result.failed_nodes) == 0

    def test_execute_parallel_with_dependencies(self):
        """Test parallel execution with dependencies."""
        executor = ParallelExecutor(max_workers=2)

        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2")

        graph.add_node(node1)
        graph.add_node(node2)
        graph.add_edge(node1.agent_id, node2.agent_id)

        agent_functions = {
            "agent1": lambda: "result1",
            "agent2": lambda: "result2",
        }

        result = executor.execute_parallel(graph, agent_functions)
        assert result.success is True
        assert len(result.completed_nodes) >= 1

    def test_execute_parallel_with_failure(self):
        """Test parallel execution with failure."""
        executor = ParallelExecutor(max_workers=2)

        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2")
        node3 = ExecutionNode(agent_name="agent3")
        graph.add_node(node1)
        graph.add_node(node2)
        graph.add_node(node3)
        graph.add_edge(node1.agent_id, node3.agent_id)
        graph.add_edge(node2.agent_id, node3.agent_id)

        agent_functions = {
            "agent1": lambda: "result1",
            "agent2": lambda: (_ for _ in ()).throw(ValueError("Test error")),
            "agent3": lambda: "result3",
        }

        result = executor.execute_parallel(graph, agent_functions)
        assert result.success is False
        assert len(result.failed_nodes) >= 1
        assert len(result.skipped_nodes) >= 1

    def test_execute_parallel_with_invalid_graph(self):
        """Test parallel execution with invalid graph."""
        executor = ParallelExecutor()

        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1", dependencies=["missing"])
        graph.add_node(node1)

        agent_functions = {"agent1": lambda: "result"}

        result = executor.execute_parallel(graph, agent_functions)
        assert result.success is False
        assert "validation" in result.errors

    def test_execute_parallel_with_context(self):
        """Test parallel execution with context."""
        executor = ParallelExecutor()

        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        graph.add_node(node1)

        def agent_with_context(value=0):
            return value * 2

        agent_functions = {"agent1": agent_with_context}
        context = {"value": 5}

        result = executor.execute_parallel(graph, agent_functions, context)
        assert result.success is True
        assert len(result.completed_nodes) == 1

    def test_execute_sequential_success(self):
        """Test successful sequential execution."""
        executor = ParallelExecutor()

        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2", dependencies=[node1.agent_id])

        graph.add_node(node1)
        graph.add_node(node2)
        graph.add_edge(node1.agent_id, node2.agent_id)

        agent_functions = {
            "agent1": lambda: "result1",
            "agent2": lambda: "result2",
        }

        result = executor.execute_sequential(graph, agent_functions)
        assert result.success is True
        assert len(result.completed_nodes) == 2

    def test_execute_sequential_with_failure(self):
        """Test sequential execution with failure."""
        executor = ParallelExecutor()

        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2", dependencies=[node1.agent_id])

        graph.add_node(node1)
        graph.add_node(node2)
        graph.add_edge(node1.agent_id, node2.agent_id)

        agent_functions = {
            "agent1": lambda: (_ for _ in ()).throw(ValueError("Test error")),
            "agent2": lambda: "result2",
        }

        result = executor.execute_sequential(graph, agent_functions)
        assert result.success is False
        assert len(result.failed_nodes) > 0
        assert len(result.skipped_nodes) > 0

    def test_get_execution_order(self):
        """Test getting execution order."""
        executor = ParallelExecutor()

        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2", dependencies=[node1.agent_id])

        graph.add_node(node1)
        graph.add_node(node2)
        graph.add_edge(node1.agent_id, node2.agent_id)

        order = executor.get_execution_order(graph)
        assert order == [node1.agent_id, node2.agent_id]

    def test_can_execute_parallel(self):
        """Test checking if agents can execute in parallel."""
        executor = ParallelExecutor()

        assert executor.can_execute_parallel(["agent1", "agent2"]) is True
        assert executor.can_execute_parallel(["agent1"]) is False

    def test_estimate_parallel_speedup(self):
        """Test estimating parallel speedup."""
        executor = ParallelExecutor(max_workers=4)

        graph = ExecutionGraph()
        for i in range(3):
            node = ExecutionNode(agent_name=f"agent{i}")
            node.status = ExecutionStatus.READY
            graph.add_node(node)

        speedup = executor.estimate_parallel_speedup(graph)
        assert speedup == 3.0


class TestGlobalParallelExecutor:
    """Test global parallel executor instance."""

    def test_get_parallel_executor(self):
        """Test getting global executor."""
        executor = get_parallel_executor()
        assert executor is not None
        assert isinstance(executor, ParallelExecutor)

    def test_get_parallel_executor_singleton(self):
        """Test global executor is singleton."""
        executor1 = get_parallel_executor()
        executor2 = get_parallel_executor()
        assert executor1 is executor2


class TestParallelExecutorMissingCoverage:
    """Tests for specific missing coverage lines."""

    def test_add_node_creates_edge_entry(self):
        """Test add_node when node_id not in edges (line 118)."""
        graph = ExecutionGraph()
        node = ExecutionNode(agent_name="agent1")
        graph.add_node(node)
        assert node.agent_id in graph.edges

    def test_add_edge_creates_from_id_entry(self):
        """Test add_edge when from_id not in edges (line 124)."""
        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        graph.add_node(node1)
        del graph.edges[node1.agent_id]
        new_node = ExecutionNode(agent_name="agent2")
        graph.add_node(new_node)
        graph.add_edge(node1.agent_id, new_node.agent_id)
        assert node1.agent_id in graph.edges

    def test_add_edge_updates_nodes(self):
        """Test add_edge updates dependency/dependent lists (lines 128→130)."""
        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2")
        graph.add_node(node1)
        graph.add_node(node2)
        graph.add_edge(node1.agent_id, node2.agent_id)
        assert node1.agent_id in node2.dependencies
        assert node2.agent_id in node1.dependents

    def test_add_edge_from_id_not_in_nodes(self):
        """Test add_edge when from_id not in nodes (line 130→exit)."""
        graph = ExecutionGraph()
        node2 = ExecutionNode(agent_name="agent2")
        graph.add_node(node2)
        graph.add_edge("nonexistent", node2.agent_id)
        assert node2.agent_id in graph.edges.get("nonexistent", [])

    def test_notify_progress_callback_exception(self):
        """Test _notify_progress suppresses callback exceptions (lines 282-285)."""
        executor = ParallelExecutor()
        bad_callback = Mock(side_effect=RuntimeError("callback error"))
        executor.add_progress_callback(bad_callback)
        executor._notify_progress("node1", ExecutionStatus.RUNNING)
        bad_callback.assert_called_once()

    def test_execute_parallel_agent_not_found(self):
        """Test execute_parallel when agent function not found (lines 376-379)."""
        executor = ParallelExecutor()
        graph = ExecutionGraph()
        node = ExecutionNode(agent_name="missing_agent")
        graph.add_node(node)

        result = executor.execute_parallel(graph, {"other_agent": lambda: "result"})
        assert result.success is False
        assert len(result.failed_nodes) == 1

    def test_execute_parallel_updates_dependent_ready(self):
        """Test execute_parallel handles dependent status update on completion (line 411)."""
        executor = ParallelExecutor(max_workers=4)
        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2")
        graph.add_node(node1)
        graph.add_node(node2)
        graph.add_edge(node1.agent_id, node2.agent_id)

        result = executor.execute_parallel(
            graph,
            {"agent1": lambda: "r1", "agent2": lambda: "r2"},
        )
        assert result.success is True
        assert len(result.completed_nodes) >= 1

    def test_execute_parallel_skips_dependents_on_failure(self):
        """Test execute_parallel marks dependents as SKIPPED on failure (lines 427→425)."""
        executor = ParallelExecutor(max_workers=2)
        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2")
        graph.add_node(node1)
        graph.add_node(node2)
        graph.add_edge(node1.agent_id, node2.agent_id)

        def fail_agent():
            raise ValueError("intentional failure")

        result = executor.execute_parallel(
            graph,
            {"agent1": fail_agent, "agent2": lambda: "r2"},
        )
        assert result.success is False
        assert node1.agent_id in result.failed_nodes
        assert node2.agent_id in result.skipped_nodes

    def test_execute_sequential_cycle_detection(self):
        """Test execute_sequential handles cycle detection (lines 467-468)."""
        executor = ParallelExecutor()
        graph = ExecutionGraph()
        node1 = ExecutionNode(agent_name="agent1")
        node2 = ExecutionNode(agent_name="agent2")
        graph.add_node(node1)
        graph.add_node(node2)
        graph.add_edge(node1.agent_id, node2.agent_id)
        graph.add_edge(node2.agent_id, node1.agent_id)

        result = executor.execute_sequential(
            graph, {"agent1": lambda: "r1", "agent2": lambda: "r2"}
        )
        assert result.success is False
        assert "topological_sort" in result.errors

    def test_estimate_parallel_speedup_single_node(self):
        """Test estimate_parallel_speedup with single ready node (line 574)."""
        executor = ParallelExecutor(max_workers=4)
        graph = ExecutionGraph()
        node = ExecutionNode(agent_name="agent1")
        node.status = ExecutionStatus.READY
        graph.add_node(node)

        speedup = executor.estimate_parallel_speedup(graph)
        assert speedup == 1.0

    def test_execute_parallel_with_context_to_agent(self):
        """Test _execute_agent passes context as kwargs (line 391→365)."""
        executor = ParallelExecutor()
        node = ExecutionNode(agent_name="agent1")
        context = {"key": "value"}

        def agent_func(key=None):
            return key

        result = executor._execute_agent(node, agent_func, context)
        assert result == "value"

    def test_execute_agent_no_context(self):
        """Test _execute_agent without context (line 536)."""
        executor = ParallelExecutor()
        node = ExecutionNode(agent_name="agent1")

        def agent_func():
            return "no context"

        result = executor._execute_agent(node, agent_func, None)
        assert result == "no context"
