"""Tests for memory_profiler module."""

# ruff: noqa: E402

import pytest

try:
    import psutil  # noqa: F401
except ImportError:
    pytest.skip("psutil not installed", allow_module_level=True)

import json
import time
from datetime import datetime, timedelta, timezone
from unittest.mock import Mock, patch

from core.memory_profiler import (
    MemoryProfiler,
    MemoryProfilerConfig,
    MemorySnapshot,
)


class TestMemorySnapshot:
    """Test MemorySnapshot dataclass."""

    def test_memory_snapshot_creation(self):
        """Test MemorySnapshot creation."""
        snapshot = MemorySnapshot(
            timestamp=datetime.now(timezone.utc),
            total_memory_mb=100.0,
            component_usage={"component1": 50.0, "component2": 30.0},
            object_counts={"obj1": 10, "obj2": 20},
            gc_stats={"gen_0": {"collections": 5}},
            available_memory_mb=800.0,
            system_memory_mb=1000.0,
        )
        assert snapshot.total_memory_mb == 100.0
        assert snapshot.component_usage == {"component1": 50.0, "component2": 30.0}
        assert snapshot.object_counts == {"obj1": 10, "obj2": 20}
        assert snapshot.available_memory_mb == 800.0
        assert snapshot.system_memory_mb == 1000.0

    def test_memory_snapshot_subtraction(self):
        """Test MemorySnapshot subtraction."""
        timestamp1 = datetime.now(timezone.utc)
        timestamp2 = timestamp1 + timedelta(seconds=10)

        snapshot1 = MemorySnapshot(
            timestamp=timestamp1,
            total_memory_mb=100.0,
            component_usage={"component1": 50.0, "component2": 30.0},
            object_counts={},
            gc_stats={},
            available_memory_mb=800.0,
            system_memory_mb=1000.0,
        )

        snapshot2 = MemorySnapshot(
            timestamp=timestamp2,
            total_memory_mb=120.0,
            component_usage={"component1": 60.0, "component2": 35.0, "component3": 10.0},
            object_counts={},
            gc_stats={},
            available_memory_mb=780.0,
            system_memory_mb=1000.0,
        )

        delta = snapshot2 - snapshot1

        assert delta["total_delta_mb"] == 20.0
        assert delta["time_delta_seconds"] == 10.0
        assert delta["component_delta_mb"]["component1"] == 10.0
        assert delta["component_delta_mb"]["component2"] == 5.0
        assert delta["component_delta_mb"]["component3"] == 10.0

    def test_memory_snapshot_subtraction_negative_delta(self):
        """Test MemorySnapshot subtraction with negative delta."""
        timestamp1 = datetime.now(timezone.utc)
        timestamp2 = timestamp1 + timedelta(seconds=10)

        snapshot1 = MemorySnapshot(
            timestamp=timestamp1,
            total_memory_mb=120.0,
            component_usage={"component1": 60.0},
            object_counts={},
            gc_stats={},
            available_memory_mb=800.0,
            system_memory_mb=1000.0,
        )

        snapshot2 = MemorySnapshot(
            timestamp=timestamp2,
            total_memory_mb=100.0,
            component_usage={"component1": 40.0},
            object_counts={},
            gc_stats={},
            available_memory_mb=800.0,
            system_memory_mb=1000.0,
        )

        delta = snapshot2 - snapshot1

        assert delta["total_delta_mb"] == -20.0
        assert delta["component_delta_mb"]["component1"] == -20.0


class TestMemoryProfilerConfig:
    """Test MemoryProfilerConfig model."""

    def test_default_config(self):
        """Test default configuration values."""
        config = MemoryProfilerConfig()
        assert config.enabled is True
        assert config.snapshot_interval_seconds == 60
        assert config.max_snapshots == 1000
        assert config.track_object_counts is True
        assert config.track_gc_stats is True
        assert config.component_filter is None
        assert config.auto_cleanup is True

    def test_custom_config(self):
        """Test custom configuration values."""
        config = MemoryProfilerConfig(
            enabled=False,
            snapshot_interval_seconds=30,
            max_snapshots=500,
            track_object_counts=False,
            track_gc_stats=False,
            component_filter=["component1", "component2"],
            auto_cleanup=False,
        )
        assert config.enabled is False
        assert config.snapshot_interval_seconds == 30
        assert config.max_snapshots == 500
        assert config.track_object_counts is False
        assert config.track_gc_stats is False
        assert config.component_filter == ["component1", "component2"]
        assert config.auto_cleanup is False


class TestMemoryProfiler:
    """Test MemoryProfiler class."""

    @pytest.fixture
    def profiler(self):
        """Create MemoryProfiler instance."""
        config = MemoryProfilerConfig(
            snapshot_interval_seconds=1,
            max_snapshots=10,
            track_object_counts=True,
            track_gc_stats=True,
        )
        return MemoryProfiler(config)

    def test_initialization(self, profiler):
        """Test MemoryProfiler initialization."""
        assert profiler.config.enabled is True
        assert len(profiler.snapshots) == 0
        assert profiler.profiling is False
        assert profiler.snapshot_thread is None
        assert "context_manager" in profiler.component_trackers
        assert "chapter_cache" in profiler.component_trackers

    def test_initialization_with_default_config(self):
        """Test initialization with default config."""
        profiler = MemoryProfiler()
        assert profiler.config.enabled is True
        assert profiler.config.snapshot_interval_seconds == 60
        assert profiler.config.max_snapshots == 1000

    def test_initialize_tracking(self, profiler):
        """Test tracking initialization."""
        profiler._initialize_tracking()
        assert "context_manager" in profiler.component_trackers
        assert "chapter_cache" in profiler.component_trackers
        assert "summary_store" in profiler.component_trackers
        assert "multi_chapter_manager" in profiler.component_trackers
        assert "llm_client" in profiler.component_trackers

    def test_take_snapshot(self, profiler):
        """Test taking a memory snapshot."""
        pytest.importorskip("psutil")

        snapshot = profiler.take_snapshot()

        assert isinstance(snapshot, MemorySnapshot)
        assert snapshot.total_memory_mb > 0
        assert snapshot.available_memory_mb > 0
        assert snapshot.system_memory_mb > 0
        assert len(profiler.snapshots) == 1

    def test_take_snapshot_auto_cleanup(self, profiler):
        """Test automatic snapshot cleanup."""
        profiler.config.max_snapshots = 3

        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            for _ in range(5):
                profiler.take_snapshot()

        assert len(profiler.snapshots) == 3

    def test_start_stop_profiling(self, profiler):
        """Test starting and stopping profiling."""
        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            profiler.start_profiling(interval_seconds=0.1)
            assert profiler.profiling is True
            assert profiler.snapshot_thread is not None

            time.sleep(0.3)

            profiler.stop_profiling()
            assert profiler.profiling is False
            assert len(profiler.snapshots) >= 1

    def test_start_profiling_when_already_profiling(self, profiler):
        """Test starting profiling when already profiling."""
        with patch("core.memory_profiler.psutil"):
            profiler.start_profiling(interval_seconds=1)
            initial_thread = profiler.snapshot_thread

            profiler.start_profiling(interval_seconds=1)

            assert profiler.snapshot_thread == initial_thread

            profiler.stop_profiling()

    def test_stop_profiling_when_not_profiling(self, profiler):
        """Test stopping profiling when not profiling."""
        profiler.stop_profiling()
        assert profiler.profiling is False

    def test_profiling_loop(self, profiler):
        """Test profiling loop functionality."""
        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            profiler._profiling_loop(interval_seconds=0.1)

            time.sleep(0.2)

            profiler.stop_event.set()

    def test_get_component_usage(self, profiler):
        """Test getting component usage."""
        with patch("core.memory_profiler.psutil"):
            usage = profiler._get_component_usage()

            assert isinstance(usage, dict)
            assert "context_manager" in usage or "chapter_cache" in usage

    def test_estimate_module_size(self, profiler):
        """Test estimating module size."""
        test_obj = {"key": "value", "number": 42}
        size = profiler._estimate_module_size(test_obj)

        assert size > 0
        assert isinstance(size, int)

    def test_estimate_module_size_with_dict(self, profiler):
        """Test estimating size of dictionary."""
        test_dict = {"a": 1, "b": 2, "c": 3}
        size = profiler._estimate_module_size(test_dict)

        assert size > 0

    def test_estimate_module_size_with_list(self, profiler):
        """Test estimating size of list."""
        test_list = [1, 2, 3, 4, 5]
        size = profiler._estimate_module_size(test_list)

        assert size > 0

    def test_get_object_counts(self, profiler):
        """Test getting object counts."""
        with patch("core.memory_profiler.psutil"):
            counts = profiler._get_object_counts()

            assert isinstance(counts, dict)

    def test_get_gc_stats(self, profiler):
        """Test getting garbage collection stats."""
        stats = profiler._get_gc_stats()

        assert "collections" in stats
        assert "collected" in stats
        assert "uncollectable" in stats

    def test_get_memory_report_no_snapshots(self, profiler):
        """Test memory report with no snapshots."""
        report = profiler.get_memory_report()

        assert "error" in report
        assert report["error"] == "No snapshots available"

    def test_get_memory_report_with_snapshots(self, profiler):
        """Test memory report with snapshots."""
        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            profiler.take_snapshot()
            time.sleep(0.1)
            profiler.take_snapshot()

            report = profiler.get_memory_report()

            assert "summary" in report
            assert "system" in report
            assert "components" in report
            assert "leaks_detected" in report
            assert report["summary"]["snapshot_count"] == 2

    def test_identify_leaks_no_snapshots(self, profiler):
        """Test leak identification with no snapshots."""
        leaks = profiler.identify_leaks()
        assert leaks == []

    def test_identify_leaks_with_increasing_memory(self, profiler):
        """Test leak detection with increasing memory."""
        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            call_count = [0]

            def memory_side_effect(*args, **kwargs):
                call_count[0] += 1
                return Mock(rss=1024 * 1024 * (100 + call_count[0] * 10))

            mock_process.memory_info.return_value = memory_side_effect()
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            for _ in range(5):
                profiler.take_snapshot()

        leaks = profiler.identify_leaks()
        assert isinstance(leaks, list)

    def test_identify_leaks_stable_memory(self, profiler):
        """Test leak detection with stable memory."""
        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            for _ in range(5):
                profiler.take_snapshot()

        leaks = profiler.identify_leaks()
        assert len(leaks) == 0

    def test_get_component_stats(self, profiler):
        """Test getting component statistics."""
        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            profiler.take_snapshot()
            profiler.take_snapshot()

        stats = profiler.get_component_stats()

        assert isinstance(stats, dict)

    def test_get_component_stats_no_snapshots(self, profiler):
        """Test component stats with no snapshots."""
        stats = profiler.get_component_stats()
        assert stats == {}

    def test_calculate_std_dev(self, profiler):
        """Test standard deviation calculation."""
        values = [10.0, 20.0, 30.0, 40.0, 50.0]
        std_dev = profiler._calculate_std_dev(values)

        assert std_dev > 0
        assert isinstance(std_dev, float)

    def test_calculate_std_dev_single_value(self, profiler):
        """Test standard deviation with single value."""
        values = [10.0]
        std_dev = profiler._calculate_std_dev(values)

        assert std_dev == 0.0

    def test_compare_snapshots(self, profiler):
        """Test comparing two snapshots."""
        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            profiler.take_snapshot()
            time.sleep(0.1)
            profiler.take_snapshot()

        comparison = profiler.compare_snapshots(0, 1)

        assert "time_delta_seconds" in comparison
        assert "memory_delta_mb" in comparison
        assert "component_deltas_mb" in comparison
        assert "snapshot1" in comparison
        assert "snapshot2" in comparison

    def test_compare_snapshots_invalid_indices(self, profiler):
        """Test comparing snapshots with invalid indices."""
        comparison = profiler.compare_snapshots(0, 10)

        assert "error" in comparison
        assert comparison["error"] == "Invalid snapshot indices"

    def test_clear_snapshots(self, profiler):
        """Test clearing all snapshots."""
        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            profiler.take_snapshot()
            profiler.take_snapshot()

        assert len(profiler.snapshots) == 2

        profiler.clear_snapshots()

        assert len(profiler.snapshots) == 0

    def test_export_snapshots(self, profiler, tmp_path):
        """Test exporting snapshots to file."""
        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            profiler.take_snapshot()

        output_path = tmp_path / "snapshots.json"
        profiler.export_snapshots(output_path)

        assert output_path.exists()

        with open(output_path, "r") as f:
            data = json.load(f)

            assert "snapshots" in data
            assert len(data["snapshots"]) == 1
            assert "timestamp" in data["snapshots"][0]
            assert "total_memory_mb" in data["snapshots"][0]

    def test_track_component(self, profiler):
        """Test tracking a component."""
        profiler.track_component("new_component", 50.0)

        assert "new_component" in profiler.component_trackers
        assert profiler.component_trackers["new_component"] == 50.0

    def test_get_current_usage(self, profiler):
        """Test getting current memory usage."""
        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            profiler.take_snapshot()

        usage = profiler.get_current_usage()

        assert usage == pytest.approx(100.0, rel=0.1)

    def test_get_current_usage_no_snapshots(self, profiler):
        """Test getting current usage with no snapshots."""
        usage = profiler.get_current_usage()
        assert usage == 0.0

    def test_get_memory_trend_increasing(self, profiler):
        """Test memory trend detection for increasing memory."""
        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            call_count = [0]

            def memory_side_effect(*args, **kwargs):
                call_count[0] += 1
                return Mock(rss=1024 * 1024 * (100 + call_count[0] * 10))

            mock_process.memory_info.return_value = memory_side_effect()
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            for _ in range(5):
                profiler.take_snapshot()

        trend = profiler.get_memory_trend(window_seconds=300)
        assert trend == "increasing"

    def test_get_memory_trend_decreasing(self, profiler):
        """Test memory trend detection for decreasing memory."""
        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            call_count = [0]

            def memory_side_effect(*args, **kwargs):
                call_count[0] += 1
                return Mock(rss=1024 * 1024 * (200 - call_count[0] * 10))

            mock_process.memory_info.return_value = memory_side_effect()
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            for _ in range(5):
                profiler.take_snapshot()

        trend = profiler.get_memory_trend(window_seconds=300)
        assert trend == "decreasing"

    def test_get_memory_trend_stable(self, profiler):
        """Test memory trend detection for stable memory."""
        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            for _ in range(5):
                profiler.take_snapshot()

        trend = profiler.get_memory_trend(window_seconds=300)
        assert trend == "stable"

    def test_get_memory_trend_insufficient_snapshots(self, profiler):
        """Test memory trend with insufficient snapshots."""
        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            profiler.take_snapshot()

        trend = profiler.get_memory_trend(window_seconds=300)
        assert trend == "stable"

    def test_get_memory_report_system_info(self, profiler):
        """Test memory report includes system information."""
        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            profiler.take_snapshot()

        report = profiler.get_memory_report()

        assert "system" in report
        assert "used_memory_mb" in report["system"]
        assert "available_memory_mb" in report["system"]
        assert "system_memory_mb" in report["system"]
        assert "usage_percent" in report["system"]
        assert report["system"]["usage_percent"] == pytest.approx(10.0, rel=0.1)

    def test_auto_cleanup_disabled(self, profiler):
        """Test auto cleanup disabled."""
        profiler.config.auto_cleanup = False
        profiler.config.max_snapshots = 3

        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            for _ in range(5):
                profiler.take_snapshot()

        assert len(profiler.snapshots) == 5

    def test_track_object_counts_disabled(self, profiler):
        """Test tracking object counts disabled."""
        profiler.config.track_object_counts = False

        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            snapshot = profiler.take_snapshot()

        assert snapshot.object_counts == {}

    def test_track_gc_stats_disabled(self, profiler):
        """Test tracking GC stats disabled."""
        profiler.config.track_gc_stats = False

        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            snapshot = profiler.take_snapshot()

        assert snapshot.gc_stats == {}

    def test_snapshot_ordering(self, profiler):
        """Test snapshots are stored in order."""
        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            profiler.take_snapshot()
            time.sleep(0.1)
            profiler.take_snapshot()
            time.sleep(0.1)
            profiler.take_snapshot()

        assert len(profiler.snapshots) == 3
        assert (
            profiler.snapshots[0].timestamp
            < profiler.snapshots[1].timestamp
            < profiler.snapshots[2].timestamp
        )

    def test_component_trends_in_report(self, profiler):
        """Test component trends in memory report."""
        with patch("core.memory_profiler.psutil") as mock_psutil:
            mock_process = Mock()
            mock_process.memory_info.return_value = Mock(rss=1024 * 1024 * 100)
            mock_psutil.Process.return_value = mock_process
            mock_psutil.virtual_memory.return_value = Mock(
                available=1024 * 1024 * 800, total=1024 * 1024 * 1000
            )

            profiler.take_snapshot()
            time.sleep(0.1)
            profiler.take_snapshot()

        report = profiler.get_memory_report()

        assert "components" in report
        assert isinstance(report["components"], dict)
