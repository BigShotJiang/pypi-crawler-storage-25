"""Test coverage for api/middleware/auth.py."""

import os
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from api.middleware.auth import (
    APIKeyManager,
    AuthConfig,
    AuthMiddleware,
    AuthType,
    TokenManager,
    User,
    get_api_key_manager,
    get_auth_config,
    get_current_user,
    get_token_manager,
    require_auth,
    require_permission,
    require_role,
)


class TestUser:
    def test_has_role_true(self):
        user = User(id="u1", name="Test", roles=["admin", "user"])
        assert user.has_role("admin") is True
        assert user.has_role("user") is True

    def test_has_role_false(self):
        user = User(id="u1", name="Test", roles=["user"])
        assert user.has_role("admin") is False

    def test_has_permission_true(self):
        user = User(id="u1", name="Test", permissions={"read", "write"})
        assert user.has_permission("read") is True
        assert user.has_permission("write") is True

    def test_has_permission_false(self):
        user = User(id="u1", name="Test", permissions={"read"})
        assert user.has_permission("write") is False

    def test_is_admin_true(self):
        user = User(id="u1", name="Admin", roles=["admin"])
        assert user.is_admin() is True

    def test_is_admin_false(self):
        user = User(id="u1", name="User", roles=["user"])
        assert user.is_admin() is False


class TestAuthConfig:
    def test_default_config(self):
        config = AuthConfig()
        assert config.enabled is False
        assert config.auth_type == AuthType.NONE
        assert config.api_key_header == "X-API-Key"
        assert config.token_header == "Authorization"
        assert config.valid_api_keys == {}
        assert config.valid_tokens == {}

    def test_from_env_disabled(self):
        env = {"AUTH_ENABLED": "false", "AUTH_TYPE": "none"}
        with patch.dict(os.environ, env, clear=False):
            with patch.object(os.environ, "get", lambda k, d="": env.get(k, d)):
                config = AuthConfig.from_env()
                assert config.enabled is False

    def test_from_env_api_key(self):
        env = {"AUTH_ENABLED": "true", "AUTH_TYPE": "api_key", "API_KEY": "test-key-123"}
        with patch.dict(os.environ, env, clear=False):
            config = AuthConfig.from_env()
            assert config.enabled is True
            assert config.auth_type == AuthType.API_KEY

    def test_from_env_bearer_token(self):
        env = {"AUTH_ENABLED": "true", "AUTH_TYPE": "bearer_token"}
        with patch.dict(os.environ, env, clear=False):
            config = AuthConfig.from_env()
            assert config.enabled is True
            assert config.auth_type == AuthType.BEARER_TOKEN

    def test_get_env_bool_true_values(self):
        for val in ["true", "1", "yes"]:
            with patch.object(os, "environ", {**os.environ, "AUTH_TEST_KEY": val}):
                result = AuthConfig._get_env_bool("AUTH_TEST_KEY", False)
                assert result is True

    def test_get_env_bool_false_values(self):
        for val in ["false", "0", "no"]:
            with patch.object(os, "environ", {**os.environ, "AUTH_TEST_KEY": val}):
                result = AuthConfig._get_env_bool("AUTH_TEST_KEY", True)
                assert result is False

    def test_get_env_auth_type_api_key(self):
        assert AuthConfig._get_env_auth_type() == AuthType.NONE

    def test_get_env_auth_type_bearer(self):
        assert AuthConfig._get_env_auth_type() == AuthType.NONE


class TestAuthMiddleware:
    def test_init_default(self):
        middleware = AuthMiddleware(MagicMock())
        assert middleware.config.enabled is False
        assert middleware.current_user is None

    def test_init_with_config(self):
        config = AuthConfig(enabled=True, auth_type=AuthType.API_KEY)
        middleware = AuthMiddleware(MagicMock(), config=config)
        assert middleware.config is config

    @pytest.mark.asyncio
    async def test_dispatch_disabled_auth_passes_through(self):
        middleware = AuthMiddleware(MagicMock())
        mock_request = MagicMock()
        mock_call_next = AsyncMock(return_value=MagicMock())
        response = await middleware.dispatch(mock_request, mock_call_next)
        mock_call_next.assert_called_once_with(mock_request)
        assert response is not None

    @pytest.mark.asyncio
    async def test_authenticate_api_key_missing(self):
        config = AuthConfig(enabled=True, auth_type=AuthType.API_KEY)
        middleware = AuthMiddleware(MagicMock(), config=config)
        mock_request = MagicMock()
        mock_request.headers.get.return_value = None
        user = await middleware.authenticate(mock_request)
        assert user is None

    @pytest.mark.asyncio
    async def test_authenticate_api_key_found(self):
        user = User(id="u1", name="Test")
        config = AuthConfig(
            enabled=True, auth_type=AuthType.API_KEY, valid_api_keys={"test-key": user}
        )
        middleware = AuthMiddleware(MagicMock(), config=config)
        mock_request = MagicMock()
        mock_request.headers.get.return_value = "test-key"
        result = await middleware.authenticate(mock_request)
        assert result is user

    @pytest.mark.asyncio
    async def test_authenticate_bearer_missing_header(self):
        config = AuthConfig(enabled=True, auth_type=AuthType.BEARER_TOKEN)
        middleware = AuthMiddleware(MagicMock(), config=config)
        mock_request = MagicMock()
        mock_request.headers.get.return_value = None
        user = await middleware.authenticate(mock_request)
        assert user is None

    @pytest.mark.asyncio
    async def test_authenticate_bearer_wrong_prefix(self):
        config = AuthConfig(enabled=True, auth_type=AuthType.BEARER_TOKEN)
        middleware = AuthMiddleware(MagicMock(), config=config)
        mock_request = MagicMock()
        mock_request.headers.get.return_value = "Basic abc123"
        user = await middleware.authenticate(mock_request)
        assert user is None

    @pytest.mark.asyncio
    async def test_authenticate_bearer_token_found(self):
        user = User(id="u1", name="Test")
        config = AuthConfig(
            enabled=True, auth_type=AuthType.BEARER_TOKEN, valid_tokens={"my-token": user}
        )
        middleware = AuthMiddleware(MagicMock(), config=config)
        mock_request = MagicMock()
        mock_request.headers.get.return_value = "Bearer my-token"
        result = await middleware.authenticate(mock_request)
        assert result is user

    @pytest.mark.asyncio
    async def test_authenticate_no_auth_type(self):
        config = AuthConfig(enabled=True, auth_type=AuthType.NONE)
        middleware = AuthMiddleware(MagicMock(), config=config)
        user = await middleware.authenticate(MagicMock())
        assert user is None

    @pytest.mark.asyncio
    async def test_dispatch_enabled_no_user(self):
        config = AuthConfig(enabled=True, auth_type=AuthType.API_KEY)
        middleware = AuthMiddleware(MagicMock(), config=config)
        mock_request = MagicMock()
        mock_request.headers.get.return_value = None
        from fastapi import HTTPException

        with pytest.raises(HTTPException) as exc_info:
            await middleware.dispatch(mock_request, AsyncMock())
        assert exc_info.value.status_code == 401

    @pytest.mark.asyncio
    async def test_dispatch_enabled_with_user(self):
        user = User(id="u1", name="Test")
        config = AuthConfig(enabled=True, auth_type=AuthType.API_KEY, valid_api_keys={"key": user})
        middleware = AuthMiddleware(MagicMock(), config=config)
        mock_request = MagicMock()
        mock_request.headers.get.return_value = "key"
        mock_call_next = AsyncMock(return_value=MagicMock())
        response = await middleware.dispatch(mock_request, mock_call_next)
        assert response is not None
        assert middleware.current_user is user


class TestRequireDecorators:
    def test_require_auth_with_user(self):
        from fastapi import HTTPException

        mock_func = AsyncMock(return_value={"message": "ok"})

        async def handler(request):
            user = getattr(request.state, "user", None)
            if user is None:
                raise HTTPException(status_code=401)
            return await mock_func(request)

        decorated = require_auth(handler)
        assert callable(decorated)

    def test_require_role(self):
        decorator = require_role("admin")
        mock_func = AsyncMock()
        decorated = decorator(mock_func)
        assert callable(decorated)

    def test_require_permission(self):
        decorator = require_permission("write")
        mock_func = AsyncMock()
        decorated = decorator(mock_func)
        assert callable(decorated)


class TestGetCurrentUser:
    def test_get_current_user_with_user(self):
        mock_request = MagicMock()
        mock_request.state.user = User(id="u1", name="Test")
        user = get_current_user(mock_request)
        assert user.id == "u1"

    def test_get_current_user_without_user(self):
        from fastapi import HTTPException

        mock_request = MagicMock()
        mock_request.state.user = None
        with pytest.raises(HTTPException) as exc_info:
            get_current_user(mock_request)
        assert exc_info.value.status_code == 401


class TestAPIKeyManager:
    def test_create_key(self):
        config = AuthConfig()
        manager = APIKeyManager(config)
        key = manager.create_key(
            "user_001", "Test User", roles=["user"], permissions={"read", "write"}
        )
        assert key is not None
        assert len(key) > 0
        assert key in config.valid_api_keys
        assert config.valid_api_keys[key].name == "Test User"
        assert config.valid_api_keys[key].roles == ["user"]
        assert config.valid_api_keys[key].permissions == {"read", "write"}

    def test_create_key_default_roles(self):
        config = AuthConfig()
        manager = APIKeyManager(config)
        key = manager.create_key("user_002", "Default User")
        assert config.valid_api_keys[key].roles == ["user"]
        assert config.valid_api_keys[key].permissions == {"read"}

    def test_revoke_key_exists(self):
        config = AuthConfig()
        manager = APIKeyManager(config)
        key = manager.create_key("user_003", "Revoke User")
        assert manager.revoke_key(key) is True
        assert key not in config.valid_api_keys

    def test_revoke_key_not_found(self):
        config = AuthConfig()
        manager = APIKeyManager(config)
        assert manager.revoke_key("nonexistent") is False

    def test_get_user_found(self):
        config = AuthConfig()
        manager = APIKeyManager(config)
        key = manager.create_key("user_004", "Get User")
        user = manager.get_user(key)
        assert user is not None
        assert user.id == "user_004"

    def test_get_user_not_found(self):
        config = AuthConfig()
        manager = APIKeyManager(config)
        assert manager.get_user("nonexistent") is None


class TestTokenManager:
    def test_create_token(self):
        config = AuthConfig()
        manager = TokenManager(config)
        token = manager.create_token(
            "user_005",
            "Token User",
            roles=["user"],
            permissions={"read"},
            expiry_hours=24,
        )
        assert token is not None
        assert token in config.valid_tokens
        assert token in manager.token_expiry
        assert config.valid_tokens[token].name == "Token User"

    def test_create_token_expiry(self):
        config = AuthConfig()
        manager = TokenManager(config)
        token = manager.create_token("user_006", "Expiry User", expiry_hours=1)
        expiry = manager.token_expiry[token]
        assert expiry > datetime.now()
        assert expiry < datetime.now() + timedelta(hours=2)

    def test_revoke_token(self):
        config = AuthConfig()
        manager = TokenManager(config)
        token = manager.create_token("user_007", "Revoke Token")
        assert manager.revoke_token(token) is True
        assert token not in config.valid_tokens
        assert token not in manager.token_expiry

    def test_revoke_token_not_found(self):
        config = AuthConfig()
        manager = TokenManager(config)
        assert manager.revoke_token("nonexistent") is False

    def test_get_user_valid_token(self):
        config = AuthConfig()
        manager = TokenManager(config)
        token = manager.create_token("user_008", "Valid Token", expiry_hours=24)
        user = manager.get_user(token)
        assert user is not None
        assert user.id == "user_008"

    def test_get_user_expired_token(self):
        config = AuthConfig()
        manager = TokenManager(config)
        token = manager.create_token("user_009", "Expired Token", expiry_hours=0)
        manager.token_expiry[token] = datetime.now() - timedelta(hours=1)
        user = manager.get_user(token)
        assert user is None

    def test_get_user_not_found(self):
        config = AuthConfig()
        manager = TokenManager(config)
        assert manager.get_user("nonexistent") is None

    def test_cleanup_expired(self):
        config = AuthConfig()
        manager = TokenManager(config)
        token1 = manager.create_token("user_010", "Expired 1", expiry_hours=0)
        manager.create_token("user_011", "Valid 2", expiry_hours=24)
        manager.token_expiry[token1] = datetime.now() - timedelta(hours=1)
        removed = manager.cleanup_expired()
        assert removed >= 1
        assert token1 not in manager.token_expiry


class TestGlobalInstances:
    def setup_method(self):
        import api.middleware.auth as auth_module

        auth_module._auth_config = None
        auth_module._api_key_manager = None
        auth_module._token_manager = None

    def test_get_auth_config(self):
        with patch.object(os.environ, "get", return_value=""):
            config = get_auth_config()
            assert isinstance(config, AuthConfig)

    def test_get_api_key_manager(self):
        with patch.object(os.environ, "get", return_value=""):
            manager = get_api_key_manager()
            assert isinstance(manager, APIKeyManager)

    def test_get_token_manager(self):
        with patch.object(os.environ, "get", return_value=""):
            manager = get_token_manager()
            assert isinstance(manager, TokenManager)

    def test_singleton_pattern(self):
        with patch.object(os.environ, "get", return_value=""):
            mgr1 = get_api_key_manager()
            mgr2 = get_api_key_manager()
            assert mgr1 is mgr2


class TestRequireAuthDecorator:
    """Test require_auth decorator covers lines 214-219."""

    @pytest.mark.asyncio
    async def test_require_auth_raises_without_user(self):
        from fastapi import HTTPException

        async def handler(request):
            pass

        decorated = require_auth(handler)
        mock_request = MagicMock()
        mock_request.state.user = None
        with pytest.raises(HTTPException) as exc_info:
            await decorated(mock_request)
        assert exc_info.value.status_code == 401

    @pytest.mark.asyncio
    async def test_require_auth_passes_with_user(self):
        async def handler(request):
            return "ok"

        decorated = require_auth(handler)
        mock_request = MagicMock()
        mock_request.state.user = User(id="u1", name="Test")
        result = await decorated(mock_request)
        assert result == "ok"


class TestRequireRoleDecorator:
    """Test require_role decorator covers lines 238-247."""

    @pytest.mark.asyncio
    async def test_require_role_no_user(self):
        from fastapi import HTTPException

        async def handler(request):
            return "ok"

        decorated = require_role("admin")(handler)
        mock_request = MagicMock()
        mock_request.state.user = None
        with pytest.raises(HTTPException) as exc_info:
            await decorated(mock_request)
        assert exc_info.value.status_code == 401

    @pytest.mark.asyncio
    async def test_require_role_missing_role(self):
        from fastapi import HTTPException

        async def handler(request):
            return "ok"

        decorated = require_role("admin")(handler)
        mock_request = MagicMock()
        mock_request.state.user = User(id="u1", name="User", roles=["user"])
        with pytest.raises(HTTPException) as exc_info:
            await decorated(mock_request)
        assert exc_info.value.status_code == 403

    @pytest.mark.asyncio
    async def test_require_role_has_role(self):
        async def handler(request):
            return "ok"

        decorated = require_role("admin")(handler)
        mock_request = MagicMock()
        mock_request.state.user = User(id="u1", name="Admin", roles=["admin"])
        result = await decorated(mock_request)
        assert result == "ok"


class TestRequirePermissionDecorator:
    """Test require_permission decorator covers lines 268-278."""

    @pytest.mark.asyncio
    async def test_require_permission_no_user(self):
        from fastapi import HTTPException

        async def handler(request):
            return "ok"

        decorated = require_permission("write")(handler)
        mock_request = MagicMock()
        mock_request.state.user = None
        with pytest.raises(HTTPException) as exc_info:
            await decorated(mock_request)
        assert exc_info.value.status_code == 401

    @pytest.mark.asyncio
    async def test_require_permission_missing(self):
        from fastapi import HTTPException

        async def handler(request):
            return "ok"

        decorated = require_permission("write")(handler)
        mock_request = MagicMock()
        mock_request.state.user = User(id="u1", name="User", permissions={"read"})
        with pytest.raises(HTTPException) as exc_info:
            await decorated(mock_request)
        assert exc_info.value.status_code == 403

    @pytest.mark.asyncio
    async def test_require_permission_has_it(self):
        async def handler(request):
            return "ok"

        decorated = require_permission("write")(handler)
        mock_request = MagicMock()
        mock_request.state.user = User(id="u1", name="Writer", permissions={"read", "write"})
        result = await decorated(mock_request)
        assert result == "ok"


class TestGlobalInstancesCaching:
    """Test get_auth_config/get_api_key_manager/get_token_manager caching (lines 461-479)."""

    def setup_method(self):
        import api.middleware.auth as auth_module

        auth_module._auth_config = None
        auth_module._api_key_manager = None
        auth_module._token_manager = None

    def test_get_auth_config_returns_cached(self):
        config1 = get_auth_config()
        config2 = get_auth_config()
        assert config1 is config2

    def test_get_token_manager_returns_cached(self):
        with patch.object(os.environ, "get", return_value=""):
            mgr1 = get_token_manager()
            mgr2 = get_token_manager()
            assert mgr1 is mgr2
