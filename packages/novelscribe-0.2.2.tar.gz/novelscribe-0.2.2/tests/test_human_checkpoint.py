"""Tests for HumanCheckpoint module."""

from unittest.mock import patch

import pytest

from core.human_checkpoint import (
    CheckpointDecision,
    CheckpointType,
    HumanCheckpoint,
    HumanCheckpointHandler,
)


class TestCheckpointType:
    """Test CheckpointType enum."""

    def test_checkpoint_types(self):
        assert CheckpointType.APPROVAL.value == "approval"
        assert CheckpointType.INPUT.value == "input"
        assert CheckpointType.REVIEW.value == "review"


class TestHumanCheckpoint:
    """Test HumanCheckpoint model."""

    def test_checkpoint_creation(self):
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.APPROVAL,
            message="Please approve",
        )
        assert checkpoint.phase == "phase1"
        assert checkpoint.type == CheckpointType.APPROVAL
        assert checkpoint.message == "Please approve"
        assert checkpoint.required is True

    def test_checkpoint_with_default_value(self):
        checkpoint = HumanCheckpoint(
            phase="input_phase",
            type=CheckpointType.INPUT,
            message="Enter name",
            default_value="John",
        )
        assert checkpoint.default_value == "John"


class TestCheckpointDecision:
    """Test CheckpointDecision model."""

    def test_decision_creation_approved(self):
        decision = CheckpointDecision(approved=True)
        assert decision.approved is True
        assert decision.input is None
        assert decision.modifications is None

    def test_decision_creation_with_input(self):
        decision = CheckpointDecision(approved=True, input="user input")
        assert decision.approved is True
        assert decision.input == "user input"

    def test_decision_creation_with_modifications(self):
        decision = CheckpointDecision(
            approved=True,
            modifications={"key": "value"},
        )
        assert decision.modifications == {"key": "value"}


class TestHumanCheckpointHandler:
    """Test HumanCheckpointHandler class."""

    def test_initialization_disabled(self):
        handler = HumanCheckpointHandler(enabled=False)
        assert handler.enabled is False

    def test_initialization_enabled(self):
        handler = HumanCheckpointHandler(enabled=True)
        assert handler.enabled is True

    def test_should_pause_disabled(self):
        handler = HumanCheckpointHandler(enabled=False)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.APPROVAL,
            message="Test",
        )
        assert handler.should_pause_at_phase("phase1", [checkpoint]) is False

    def test_should_pause_enabled_no_checkpoint(self):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.APPROVAL,
            message="Test",
        )
        assert handler.should_pause_at_phase("other_phase", [checkpoint]) is False

    def test_should_pause_enabled_with_checkpoint(self):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.APPROVAL,
            message="Test",
        )
        assert handler.should_pause_at_phase("phase1", [checkpoint]) is True

    def test_should_pause_multiple_checkpoints(self):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoints = [
            HumanCheckpoint(phase="phase1", type=CheckpointType.APPROVAL, message="1"),
            HumanCheckpoint(phase="phase2", type=CheckpointType.INPUT, message="2"),
        ]
        assert handler.should_pause_at_phase("phase1", checkpoints) is True
        assert handler.should_pause_at_phase("phase2", checkpoints) is True
        assert handler.should_pause_at_phase("phase3", checkpoints) is False

    def test_get_checkpoint_for_phase_found(self):
        handler = HumanCheckpointHandler()
        checkpoints = [
            HumanCheckpoint(phase="phase1", type=CheckpointType.APPROVAL, message="1"),
            HumanCheckpoint(phase="phase2", type=CheckpointType.INPUT, message="2"),
        ]
        result = handler.get_checkpoint_for_phase("phase1", checkpoints)
        assert result is not None
        assert result.phase == "phase1"

    def test_get_checkpoint_for_phase_not_found(self):
        handler = HumanCheckpointHandler()
        checkpoints = [
            HumanCheckpoint(phase="phase1", type=CheckpointType.APPROVAL, message="1"),
        ]
        result = handler.get_checkpoint_for_phase("nonexistent", checkpoints)
        assert result is None

    def test_handle_checkpoint_disabled_raises(self):
        handler = HumanCheckpointHandler(enabled=False)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.APPROVAL,
            message="Test",
        )
        with pytest.raises(RuntimeError, match="Human checkpoints are not enabled"):
            handler.handle_checkpoint(checkpoint)

    @patch("builtins.input")
    def test_handle_approval_checkpoint_yes(self, mock_input):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.APPROVAL,
            message="Approve?",
        )
        mock_input.return_value = "y"

        decision = handler.handle_checkpoint(checkpoint)

        assert decision.approved is True
        mock_input.assert_called_once()

    @patch("builtins.input")
    def test_handle_approval_checkpoint_no(self, mock_input):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.APPROVAL,
            message="Approve?",
        )
        mock_input.return_value = "n"

        decision = handler.handle_checkpoint(checkpoint)

        assert decision.approved is False

    @patch("builtins.input")
    def test_handle_approval_checkpoint_yes_full_word(self, mock_input):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.APPROVAL,
            message="Approve?",
        )
        mock_input.return_value = "yes"

        decision = handler.handle_checkpoint(checkpoint)

        assert decision.approved is True

    @patch("builtins.input")
    def test_handle_approval_checkpoint_retry_invalid(self, mock_input):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.APPROVAL,
            message="Approve?",
        )
        mock_input.side_effect = ["invalid", "y"]

        decision = handler.handle_checkpoint(checkpoint)

        assert decision.approved is True
        assert mock_input.call_count == 2

    @patch("builtins.input")
    def test_handle_approval_checkpoint_keyboard_interrupt(self, mock_input):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.APPROVAL,
            message="Approve?",
        )
        mock_input.side_effect = KeyboardInterrupt()

        decision = handler.handle_checkpoint(checkpoint)

        assert decision.approved is False

    @patch("builtins.input")
    def test_handle_input_checkpoint_with_value(self, mock_input):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.INPUT,
            message="Enter name",
        )
        mock_input.return_value = "John"

        decision = handler.handle_checkpoint(checkpoint)

        assert decision.approved is True
        assert decision.input == "John"

    @patch("builtins.input")
    def test_handle_input_checkpoint_uses_default(self, mock_input):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.INPUT,
            message="Enter name",
            default_value="DefaultName",
        )
        mock_input.return_value = ""

        decision = handler.handle_checkpoint(checkpoint)

        assert decision.approved is True
        assert decision.input == "DefaultName"

    @patch("builtins.input")
    def test_handle_input_checkpoint_optional_skipped(self, mock_input):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.INPUT,
            message="Optional input",
            required=False,
        )
        mock_input.side_effect = KeyboardInterrupt()

        decision = handler.handle_checkpoint(checkpoint)

        assert decision.approved is True

    @patch("builtins.input")
    def test_handle_input_checkpoint_required_interrupted(self, mock_input):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.INPUT,
            message="Enter name",
            required=True,
        )
        mock_input.side_effect = KeyboardInterrupt()

        decision = handler.handle_checkpoint(checkpoint)

        assert decision.approved is False

    @patch("builtins.input")
    def test_handle_review_checkpoint_continue(self, mock_input):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.REVIEW,
            message="Review content",
        )
        mock_input.return_value = "continue"

        decision = handler.handle_checkpoint(checkpoint)

        assert decision.approved is True
        assert decision.modifications is None

    @patch("builtins.input")
    def test_handle_review_checkpoint_continue_shortcut(self, mock_input):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.REVIEW,
            message="Review content",
        )
        mock_input.return_value = "c"

        decision = handler.handle_checkpoint(checkpoint)

        assert decision.approved is True

    @patch("builtins.input")
    def test_handle_review_checkpoint_modify(self, mock_input):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.REVIEW,
            message="Review content",
        )
        mock_input.side_effect = ["modify", '{"key": "value"}']

        decision = handler.handle_checkpoint(checkpoint)

        assert decision.approved is True
        assert decision.modifications == {"key": "value"}

    @patch("builtins.input")
    def test_handle_review_checkpoint_modify_invalid_json(self, mock_input):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.REVIEW,
            message="Review content",
        )
        mock_input.side_effect = ["modify", "invalid json", "continue"]

        decision = handler.handle_checkpoint(checkpoint)

        assert decision.approved is True

    @patch("builtins.input")
    def test_handle_review_checkpoint_stop(self, mock_input):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.REVIEW,
            message="Review content",
        )
        mock_input.return_value = "stop"

        decision = handler.handle_checkpoint(checkpoint)

        assert decision.approved is False

    @patch("builtins.input")
    def test_handle_review_checkpoint_stop_shortcut(self, mock_input):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.REVIEW,
            message="Review content",
        )
        mock_input.return_value = "s"

        decision = handler.handle_checkpoint(checkpoint)

        assert decision.approved is False

    @patch("builtins.input")
    def test_handle_review_checkpoint_invalid_choice(self, mock_input):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.REVIEW,
            message="Review content",
        )
        mock_input.return_value = "invalid"

        decision = handler.handle_checkpoint(checkpoint)

        assert decision.approved is True

    @patch("builtins.input")
    def test_handle_review_checkpoint_keyboard_interrupt(self, mock_input):
        handler = HumanCheckpointHandler(enabled=True)
        checkpoint = HumanCheckpoint(
            phase="phase1",
            type=CheckpointType.REVIEW,
            message="Review content",
        )
        mock_input.side_effect = KeyboardInterrupt()

        decision = handler.handle_checkpoint(checkpoint)

        assert decision.approved is False
