"""Integration tests for api/routers/streaming.py

This test suite provides integration tests for the streaming router endpoints,
testing the complete streaming workflow with mock streaming data sources.

Coverage Target: Integration tests for stream_logs, stream_status, stream_all_events
"""

import json
from unittest.mock import MagicMock, patch

import pytest
from fastapi import FastAPI

from api.routers.streaming import (
    LogStreamerConfig,
    StatusStreamerConfig,
    build_stream_headers,
    create_error_event,
    format_sse,
    generate_log_events,
    generate_status_events,
    parse_event_types,
    router,
    validate_project_name,
)

app = FastAPI()
app.include_router(router, prefix="/api/v1/stream")


class TestStreamingWorkflowIntegration:
    """Integration tests for complete streaming workflows."""

    async def test_log_streaming_generator_with_real_file(self, tmp_path):
        """Test log streaming with real file operations."""
        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO", "message": "Test log 1"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        assert len(events) >= 1
        assert any("connected" in e for e in events)

    async def test_status_streaming_generator_with_mock_execution(self):
        """Test status streaming with mock execution states."""

        storage_checker = MagicMock(return_value=["test_project"])

        mock_execution = MagicMock()
        mock_execution.execution_id = "exec_001"
        mock_execution.status = MagicMock(value="running")
        mock_execution.to_dict.return_value = {
            "execution_id": "exec_001",
            "status": "running",
            "project_name": "test_project",
        }

        task_manager = MagicMock()
        task_manager.get_all_executions.return_value = [mock_execution]

        task_manager_getter = MagicMock(return_value=task_manager)
        config = StatusStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_status_events(
            "test_project",
            storage_checker=storage_checker,
            task_manager_getter=task_manager_getter,
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        connected_events = [e for e in events if "connected" in e]
        assert len(connected_events) >= 1

    async def test_dual_streaming_generator(self, tmp_path):
        """Test simultaneous log and status streaming."""
        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n')

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        task_manager = MagicMock(get_all_executions=MagicMock(return_value=[]))

        config_log = LogStreamerConfig(max_iterations=2, poll_interval=0.001)
        config_status = StatusStreamerConfig(max_iterations=2, poll_interval=0.001)

        log_events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config_log,
        ):
            log_events.append(event)
            if len(log_events) >= 10:
                break

        status_events = []
        async for event in generate_status_events(
            "test_project",
            storage_checker=storage_checker,
            task_manager_getter=MagicMock(return_value=task_manager),
            config=config_status,
        ):
            status_events.append(event)
            if len(status_events) >= 10:
                break

        assert len(log_events) >= 1
        assert len(status_events) >= 1


class TestStreamingEdgeCases:
    """Edge case tests for streaming router."""

    async def test_log_generator_handles_empty_log_file(self, tmp_path):
        """Test log generator with empty log file."""
        log_file = tmp_path / "execution.log"
        log_file.write_text("")

        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=log_file)
        config = LogStreamerConfig(max_iterations=1, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)
            if len(events) >= 5:
                break

        assert len(events) >= 1
        assert any("connected" in e for e in events)

    async def test_log_generator_handles_nonexistent_log_file(self):
        """Test log generator when log file doesn't exist."""
        storage_checker = MagicMock(return_value=["test_project"])
        log_file_provider = MagicMock(return_value=None)
        config = LogStreamerConfig(max_iterations=1, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "test_project",
            storage_checker=storage_checker,
            log_file_provider=log_file_provider,
            config=config,
        ):
            events.append(event)
            if len(events) >= 5:
                break

        assert len(events) >= 1

    async def test_status_generator_handles_no_executions(self):
        """Test status generator when no executions exist."""
        storage_checker = MagicMock(return_value=["test_project"])
        task_manager = MagicMock(get_all_executions=MagicMock(return_value=[]))
        config = StatusStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_status_events(
            "test_project",
            storage_checker=storage_checker,
            task_manager_getter=MagicMock(return_value=task_manager),
            config=config,
        ):
            events.append(event)
            if len(events) >= 5:
                break

        heartbeat_events = [e for e in events if "heartbeat" in e]
        assert len(heartbeat_events) >= 1


class TestStreamingErrorHandling:
    """Error handling tests for streaming router."""

    async def test_storage_checker_returns_empty_list(self):
        """Test generator handles empty project list."""
        storage_checker = MagicMock(return_value=[])
        config = LogStreamerConfig(max_iterations=2, poll_interval=0.001)

        events = []
        async for event in generate_log_events(
            "nonexistent_project",
            storage_checker=storage_checker,
            config=config,
        ):
            events.append(event)
            if len(events) >= 10:
                break

        error_events = [e for e in events if "event: error" in e]
        assert len(error_events) >= 1

    async def test_task_manager_raises_exception(self):
        """Test generator handles task manager exception."""
        storage_checker = MagicMock(return_value=["test_project"])
        task_manager = MagicMock()
        task_manager.get_all_executions.side_effect = Exception("Task manager error")
        config = StatusStreamerConfig(max_iterations=2, poll_interval=0.001)

        async def mock_sleep(*args):
            pass

        with patch("asyncio.sleep", mock_sleep):
            events = []
            async for event in generate_status_events(
                "test_project",
                storage_checker=storage_checker,
                task_manager_getter=MagicMock(return_value=task_manager),
                config=config,
            ):
                events.append(event)
                if len(events) >= 10:
                    break

        error_events = [e for e in events if "event: error" in e]
        assert len(error_events) >= 1

    def test_validate_project_name_with_path_chars(self):
        """Test project name validation with path characters."""
        from fastapi import HTTPException

        with pytest.raises(HTTPException):
            validate_project_name("project/name")

    def test_parse_event_types_whitespace_only(self):
        """Test parsing event types with only whitespace."""
        result = parse_event_types("   ")
        assert result is None

    def test_parse_event_types_many_events(self):
        """Test parsing many comma-separated events."""
        events = ",".join([f"event_{i}" for i in range(50)])
        result = parse_event_types(events)
        assert len(result) == 50

    def test_parse_event_types_with_leading_trailing_spaces(self):
        """Test parsing with leading/trailing spaces."""
        result = parse_event_types("  log , error , warning  ")
        assert result == ["log", "error", "warning"]


class TestStreamingResponseFormat:
    """Tests for SSE response format compliance."""

    def test_sse_format_ends_with_double_newline(self):
        """Test SSE events end with double newline."""
        result = format_sse("test", {"data": "value"})
        assert result.endswith("\n\n")

    def test_sse_format_has_event_prefix(self):
        """Test SSE events have event: prefix."""
        result = format_sse("custom_event", {"key": "value"})
        assert result.startswith("event: custom_event\ndata:")

    def test_sse_format_data_is_json(self):
        """Test SSE data field is valid JSON."""

        result = format_sse("test", {"nested": {"data": [1, 2, 3]}})
        parts = result.split("\ndata: ", 1)
        if len(parts) > 1:
            data_str = parts[1].rstrip("\n\n")
            parsed = json.loads(data_str)
            assert parsed["nested"]["data"] == [1, 2, 3]

    def test_error_event_format(self):
        """Test error event format."""
        result = create_error_event("Test error")
        assert "event: error" in result
        assert "Test error" in result

    def test_stream_headers_complete(self):
        """Test all required headers are present."""
        headers = build_stream_headers()
        required = ["Cache-Control", "Connection", "X-Accel-Buffering"]
        for header in required:
            assert header in headers
