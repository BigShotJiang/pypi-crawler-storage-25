"""Extended tests for low-coverage API routers."""

from datetime import datetime
from unittest.mock import MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from api.app import app


@pytest.fixture
def client():
    """Create test client."""
    return TestClient(app)


class TestStatusRouterExtended:
    """Extended tests for status router."""

    def test_get_project_status_invalid_name_with_slash(self, client):
        """Test that project names with slashes return 404."""
        response = client.get("/api/v1/status/proj/ect")
        assert response.status_code == 404

    def test_get_project_status_with_chapters(self, client):
        """Test getting status for a project with chapters."""
        with patch("api.routers.status.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["my_project"]
            mock_chapter = MagicMock()
            mock_chapter.number = 1
            mock_proj = MagicMock()
            mock_proj.chapters = [mock_chapter]
            mock_proj.meta = {
                "status": "writing",
                "created": datetime.now().isoformat(),
                "updated": datetime.now().isoformat(),
                "phase": "chapters",
            }
            mock_instance.load_project.return_value = mock_proj
            mock_instance.project_dir = MagicMock()
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/status/my_project")
            assert response.status_code == 200
            data = response.json()
            assert data["chapter_count"] == 1
            assert data["last_activity"] is not None

    def test_get_project_status_without_updated_field(self, client):
        """Test getting status when only created field exists."""
        with patch("api.routers.status.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["my_project"]
            mock_proj = MagicMock()
            mock_proj.chapters = []
            mock_proj.meta = {
                "status": "created",
                "created": datetime.now().isoformat(),
            }
            mock_instance.load_project.return_value = mock_proj
            mock_instance.project_dir = MagicMock()
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/status/my_project")
            assert response.status_code == 200
            data = response.json()
            assert data["last_activity"] is not None

    def test_get_project_status_exception_handling(self, client):
        """Test exception handling in get_project_status."""
        with patch("api.routers.status.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["my_project"]
            mock_instance.load_project.side_effect = Exception("Load error")
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/status/my_project")
            assert response.status_code == 500

    def test_get_draft_status_invalid_name(self, client):
        """Test draft status with invalid project name."""
        response = client.get("/api/v1/status/proj/ect/drafts")
        assert response.status_code == 404

    def test_get_draft_status_not_found(self, client):
        """Test draft status for nonexistent project."""
        with patch("api.routers.status.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = []
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/status/nonexistent/drafts")
            assert response.status_code == 404

    def test_get_draft_status_with_chapters_and_versions(self, client, tmp_path):
        """Test draft status with actual chapter versions."""
        project_dir = tmp_path / "my_project"
        drafts_dir = project_dir / "drafts"
        chapter_dir = drafts_dir / "chapter_1"
        chapter_dir.mkdir(parents=True)
        (chapter_dir / "v1.md").write_text("# Version 1")
        (chapter_dir / "v2.md").write_text("# Version 2")

        with patch("api.routers.status.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["my_project"]
            mock_chapter = MagicMock()
            mock_chapter.number = 1
            mock_chapter.current_version = 2
            mock_proj = MagicMock()
            mock_proj.chapters = [mock_chapter]
            mock_instance.load_project.return_value = mock_proj
            mock_instance.project_dir = tmp_path
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/status/my_project/drafts")
            assert response.status_code == 200
            data = response.json()
            assert data["total_chapters"] == 1
            assert data["total_versions"] == 3
            assert data["chapters"][0]["versions"] == 3

    def test_get_draft_status_exception_handling(self, client):
        """Test exception handling in get_draft_status."""
        with patch("api.routers.status.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.return_value = ["my_project"]
            mock_instance.load_project.side_effect = Exception("Load error")
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/status/my_project/drafts")
            assert response.status_code == 500


class TestLogsRouterExtended:
    """Extended tests for logs router."""

    def test_get_project_logs_invalid_name_with_slash(self, client):
        """Test that project names with slashes return 404."""
        response = client.get("/api/v1/logs/proj/ect")
        assert response.status_code == 404

    def test_get_project_logs_exception_handling(self, client):
        """Test exception handling in get_project_logs."""
        with patch("api.routers.logs.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.side_effect = RuntimeError("Storage error")
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/logs/test_project")
            assert response.status_code == 500

    def test_get_execution_logs_exception_handling(self, client):
        """Test exception handling in get_execution_logs."""
        with patch("api.routers.logs.Storage") as mock_storage:
            mock_instance = MagicMock()
            mock_instance.list_projects.side_effect = RuntimeError("Storage error")
            mock_storage.return_value = mock_instance

            response = client.get("/api/v1/logs/test_project/exec_123")
            assert response.status_code == 500

    def test_get_execution_logs_invalid_name(self, client):
        """Test execution logs with invalid project name."""
        response = client.get("/api/v1/logs/proj/ect/exec_123")
        assert response.status_code == 404


class TestStreamingRouterExtended:
    """Extended tests for streaming router."""

    @pytest.mark.skip(reason="Streaming endpoints require running server")
    def test_stream_logs_invalid_project_name(self, client):
        """Test SSE streaming with invalid project name."""
        response = client.get("/api/v1/stream/logs/proj/ect")
        assert response.status_code == 400

    @pytest.mark.skip(reason="Streaming endpoints require running server")
    def test_stream_status_invalid_project_name(self, client):
        """Test status streaming with invalid project name."""
        response = client.get("/api/v1/stream/status/proj/ect")
        assert response.status_code == 400


class TestSuggestionsRouterExtended:
    """Extended tests for suggestions router."""

    def test_list_suggestions_with_filters(self, client):
        """Test listing suggestions with filters."""
        with patch("api.routers.suggestions._get_kb") as mock_kb:
            mock_instance = MagicMock()
            mock_suggestion = MagicMock()
            mock_suggestion.id = "sug_001"
            mock_suggestion.name = "Test Suggestion"
            mock_suggestion.description = "A test"
            mock_suggestion.best_for = []
            mock_suggestion.examples = []
            from core.suggestions.models import SuggestionSource

            mock_suggestion.source = SuggestionSource.STATIC
            mock_suggestion.acceptance_rate = 0.8
            mock_instance.load_suggestions.return_value = [mock_suggestion]
            mock_kb.return_value = mock_instance

            response = client.get("/api/v1/suggestions/?category=genre&source=static")
            assert response.status_code == 200

    def test_get_suggestion_not_found(self, client):
        """Test getting a nonexistent suggestion."""
        with patch("api.routers.suggestions._get_kb") as mock_kb:
            mock_instance = MagicMock()
            mock_instance.get_suggestion.return_value = None
            mock_kb.return_value = mock_instance

            response = client.get("/api/v1/suggestions/nonexistent")
            assert response.status_code == 404

    def test_get_contextual_suggestions_invalid_trigger(self, client):
        """Test contextual suggestions with invalid trigger type."""
        response = client.post("/api/v1/suggestions/get?project_id=p1&trigger_type=invalid_trigger")
        assert response.status_code == 400

    def test_record_suggestion_exception(self, client):
        """Test recording suggestion with exception."""
        with patch("api.routers.suggestions._get_orchestrator") as mock_orch:
            mock_orchestrator = MagicMock()
            mock_orchestrator.record_suggestion_outcome.side_effect = Exception("Record error")
            mock_orch.return_value = mock_orchestrator

            response = client.post(
                "/api/v1/suggestions/record",
                json={
                    "project_name": "p1",
                    "suggestion_id": "sug_001",
                    "accepted": True,
                    "user_choice": "accepted",
                    "trigger_type": "decision_point",
                    "category": "genre",
                },
            )
            assert response.status_code == 200
            data = response.json()
            assert data["success"] is False


@pytest.mark.skipif(True, reason="WebSocket tests require integration testing")
class TestWebSocketRouterExtended:
    """Extended tests for WebSocket router (requires integration)."""

    @pytest.mark.skip(reason="WebSocket endpoint requires running server")
    def test_websocket_endpoint(self):
        """WebSocket endpoint needs integration test."""
        pass
