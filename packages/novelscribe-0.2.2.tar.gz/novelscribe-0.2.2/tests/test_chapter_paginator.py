"""Tests for chapter_paginator module."""

from datetime import datetime
from unittest.mock import patch

import pytest

from core.chapter_paginator import (
    ChapterPage,
    ChapterPaginator,
    PageMetadata,
    PageSplitStrategy,
    PaginationConfig,
)


class TestPageSplitStrategy:
    """Test PageSplitStrategy enum."""

    def test_page_split_strategy_values(self):
        """Test PageSplitStrategy enum values."""
        assert PageSplitStrategy.TOKEN_BASED == "token_based"
        assert PageSplitStrategy.SCENE_BASED == "scene_based"
        assert PageSplitStrategy.PARAGRAPH_BASED == "paragraph_based"
        assert PageSplitStrategy.SEMANTIC == "semantic"


class TestPageMetadata:
    """Test PageMetadata dataclass."""

    def test_page_metadata_creation(self):
        """Test PageMetadata creation."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=1000,
            word_count=500,
            token_count=2500,
        )
        assert metadata.page_number == 1
        assert metadata.start_position == 0
        assert metadata.end_position == 1000
        assert metadata.word_count == 500
        assert metadata.token_count == 2500
        assert metadata.scene_identifier is None
        assert metadata.characters_present == []
        assert metadata.locations_present == []
        assert metadata.key_events == []
        assert isinstance(metadata.created_at, datetime)

    def test_page_metadata_with_optional_fields(self):
        """Test PageMetadata with optional fields."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=1000,
            word_count=500,
            token_count=2500,
            scene_identifier="scene_1",
            characters_present=["Alice", "Bob"],
            locations_present=["Kitchen", "Garden"],
            key_events=["Event 1", "Event 2"],
        )
        assert metadata.scene_identifier == "scene_1"
        assert metadata.characters_present == ["Alice", "Bob"]
        assert metadata.locations_present == ["Kitchen", "Garden"]
        assert metadata.key_events == ["Event 1", "Event 2"]

    def test_page_metadata_to_dict(self):
        """Test PageMetadata to_dict method."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=1000,
            word_count=500,
            token_count=2500,
            scene_identifier="scene_1",
            characters_present=["Alice"],
        )
        result = metadata.to_dict()
        assert result["page_number"] == 1
        assert result["start_position"] == 0
        assert result["end_position"] == 1000
        assert result["word_count"] == 500
        assert result["token_count"] == 2500
        assert result["scene_identifier"] == "scene_1"
        assert result["characters_present"] == ["Alice"]
        assert "created_at" in result


class TestChapterPage:
    """Test ChapterPage dataclass."""

    @pytest.fixture
    def metadata(self):
        """Create PageMetadata fixture."""
        return PageMetadata(
            page_number=1,
            start_position=0,
            end_position=1000,
            word_count=500,
            token_count=2500,
        )

    def test_chapter_page_creation(self, metadata):
        """Test ChapterPage creation."""
        page = ChapterPage(
            page_number=1,
            content="Test content",
            metadata=metadata,
        )
        assert page.page_number == 1
        assert page.content == "Test content"
        assert page.metadata == metadata
        assert page.overlap_content == ""

    def test_chapter_page_with_overlap(self, metadata):
        """Test ChapterPage with overlap content."""
        page = ChapterPage(
            page_number=1,
            content="Test content",
            metadata=metadata,
            overlap_content="Previous content",
        )
        assert page.overlap_content == "Previous content"

    def test_word_count_property(self, metadata):
        """Test word_count property."""
        page = ChapterPage(
            page_number=1,
            content="This is a test content with eight words.",
            metadata=metadata,
        )
        assert page.word_count == 8

    def test_full_content_with_overlap(self, metadata):
        """Test full_content property with overlap."""
        page = ChapterPage(
            page_number=1,
            content="Main content",
            metadata=metadata,
            overlap_content="Overlap",
        )
        assert page.full_content == "Overlap\n\nMain content"

    def test_full_content_without_overlap(self, metadata):
        """Test full_content property without overlap."""
        page = ChapterPage(
            page_number=1,
            content="Main content",
            metadata=metadata,
        )
        assert page.full_content == "Main content"

    def test_get_context_hint_with_scene(self, metadata):
        """Test get_context_hint with scene identifier."""
        metadata.scene_identifier = "Scene 1"
        page = ChapterPage(
            page_number=1,
            content="Content",
            metadata=metadata,
        )
        hint = page.get_context_hint()
        assert "Scene: Scene 1" in hint

    def test_get_context_hint_with_characters(self, metadata):
        """Test get_context_hint with characters."""
        metadata.characters_present = ["Alice", "Bob"]
        page = ChapterPage(
            page_number=1,
            content="Content",
            metadata=metadata,
        )
        hint = page.get_context_hint()
        assert "Characters: Alice, Bob" in hint

    def test_get_context_hint_with_locations(self, metadata):
        """Test get_context_hint with locations."""
        metadata.locations_present = ["Kitchen", "Garden"]
        page = ChapterPage(
            page_number=1,
            content="Content",
            metadata=metadata,
        )
        hint = page.get_context_hint()
        assert "Location: Kitchen, Garden" in hint

    def test_get_context_hint_combined(self, metadata):
        """Test get_context_hint with all fields."""
        metadata.scene_identifier = "Scene 1"
        metadata.characters_present = ["Alice"]
        metadata.locations_present = ["Kitchen"]
        page = ChapterPage(
            page_number=1,
            content="Content",
            metadata=metadata,
        )
        hint = page.get_context_hint()
        assert "Scene: Scene 1" in hint
        assert "Characters: Alice" in hint
        assert "Location: Kitchen" in hint

    def test_get_context_hint_empty(self, metadata):
        """Test get_context_hint with no context."""
        page = ChapterPage(
            page_number=1,
            content="Content",
            metadata=metadata,
        )
        hint = page.get_context_hint()
        assert hint == "Continuing story..."


class TestPaginationConfig:
    """Test PaginationConfig model."""

    def test_pagination_config_defaults(self):
        """Test PaginationConfig with default values."""
        config = PaginationConfig()
        assert config.strategy == PageSplitStrategy.SEMANTIC
        assert config.max_tokens_per_page == 2500
        assert config.target_tokens_per_page == 2000
        assert config.overlap_tokens == 200
        assert config.min_page_tokens == 500
        assert config.preserve_scene_boundaries is True
        assert config.preserve_dialogue_groups is True

    def test_pagination_config_custom(self):
        """Test PaginationConfig with custom values."""
        config = PaginationConfig(
            strategy=PageSplitStrategy.TOKEN_BASED,
            max_tokens_per_page=3000,
            target_tokens_per_page=2500,
            overlap_tokens=300,
            min_page_tokens=600,
            preserve_scene_boundaries=False,
            preserve_dialogue_groups=False,
        )
        assert config.strategy == PageSplitStrategy.TOKEN_BASED
        assert config.max_tokens_per_page == 3000
        assert config.target_tokens_per_page == 2500
        assert config.overlap_tokens == 300
        assert config.min_page_tokens == 600
        assert config.preserve_scene_boundaries is False
        assert config.preserve_dialogue_groups is False


class TestChapterPaginator:
    """Test ChapterPaginator class."""

    @pytest.fixture
    def default_config(self):
        """Create default PaginationConfig."""
        return PaginationConfig()

    @pytest.fixture
    def paginator(self, default_config):
        """Create ChapterPaginator instance."""
        return ChapterPaginator(config=default_config)

    def test_initialization(self, paginator):
        """Test ChapterPaginator initialization."""
        assert paginator.config is not None
        assert paginator.token_estimator is not None

    def test_initialization_with_default_config(self):
        """Test initialization with default config."""
        paginator = ChapterPaginator()
        assert paginator.config == PaginationConfig()

    def test_scene_break_patterns(self, paginator):
        """Test SCENE_BREAK_PATTERNS constant."""
        assert len(paginator.SCENE_BREAK_PATTERNS) == 4
        assert paginator.PARAGRAPH_PATTERN is not None
        assert paginator.SENTENCE_PATTERN is not None
        assert paginator.DIALOGUE_PATTERN is not None

    def test_paginate_chapter_empty_content(self, paginator):
        """Test paginating empty content."""
        pages = paginator.paginate_chapter("", 1)
        assert pages == []

    def test_paginate_chapter_whitespace_only(self, paginator):
        """Test paginating whitespace-only content."""
        pages = paginator.paginate_chapter("   \n\n   ", 1)
        assert pages == []

    def test_paginate_chapter_no_pagination_needed(self, paginator):
        """Test paginating short content that doesn't need pagination."""
        content = "This is a short chapter that doesn't need pagination."

        def mock_estimate_tokens(text):
            return len(text.split()) * 2

        with patch.object(
            paginator.token_estimator, "estimate_tokens", side_effect=mock_estimate_tokens
        ):
            pages = paginator.paginate_chapter(content, 1)
            assert len(pages) == 1
            assert pages[0].content == content
            assert pages[0].page_number == 1

    def test_paginate_chapter_token_based_strategy(self):
        """Test paginating with token-based strategy."""
        config = PaginationConfig(strategy=PageSplitStrategy.TOKEN_BASED)
        paginator = ChapterPaginator(config=config)
        content = "Word " * 200

        # Create a mock that returns reasonable token counts based on content length
        def mock_estimate_tokens(text):
            return len(text.split()) * 2  # Approximate 2 tokens per word

        with patch.object(
            paginator.token_estimator, "estimate_tokens", side_effect=mock_estimate_tokens
        ):
            pages = paginator.paginate_chapter(content, 1)
            assert len(pages) >= 1

    def test_paginate_chapter_scene_based_strategy(self):
        """Test paginating with scene-based strategy."""
        config = PaginationConfig(strategy=PageSplitStrategy.SCENE_BASED)
        paginator = ChapterPaginator(config=config)
        content = "Scene 1\n\n***\n\nScene 2\n\n***\n\nScene 3"

        def mock_estimate_tokens(text):
            return len(text.split()) * 2

        with patch.object(
            paginator.token_estimator, "estimate_tokens", side_effect=mock_estimate_tokens
        ):
            pages = paginator.paginate_chapter(content, 1)
            assert len(pages) >= 1

    def test_paginate_chapter_paragraph_based_strategy(self):
        """Test paginating with paragraph-based strategy."""
        config = PaginationConfig(strategy=PageSplitStrategy.PARAGRAPH_BASED)
        paginator = ChapterPaginator(config=config)
        content = "\n\n".join(["Paragraph " + str(i) for i in range(10)])

        def mock_estimate_tokens(text):
            return len(text.split()) * 2

        with patch.object(
            paginator.token_estimator, "estimate_tokens", side_effect=mock_estimate_tokens
        ):
            pages = paginator.paginate_chapter(content, 1)
            assert len(pages) >= 1

    def test_paginate_chapter_semantic_strategy(self):
        """Test paginating with semantic strategy."""
        config = PaginationConfig(strategy=PageSplitStrategy.SEMANTIC)
        paginator = ChapterPaginator(config=config)
        content = "Scene 1\n\n***\n\nScene 2\n\n***\n\nScene 3"

        def mock_estimate_tokens(text):
            return len(text.split()) * 2

        with patch.object(
            paginator.token_estimator, "estimate_tokens", side_effect=mock_estimate_tokens
        ):
            pages = paginator.paginate_chapter(content, 1)
            assert len(pages) >= 1

    def test_create_single_page(self, paginator):
        """Test creating a single page."""
        content = "Test content"
        with patch.object(paginator.token_estimator, "estimate_tokens", return_value=100):
            page = paginator._create_single_page(content, 1, None)
            assert page.page_number == 1
            assert page.content == content
            assert page.metadata.word_count == 2
            assert page.metadata.token_count == 100

    def test_paginate_by_tokens(self, paginator):
        """Test token-based pagination."""
        content = "Word " * 200

        def mock_estimate_tokens(text):
            return len(text.split()) * 2

        with patch.object(
            paginator.token_estimator, "estimate_tokens", side_effect=mock_estimate_tokens
        ):
            pages = paginator._paginate_by_tokens(content, 1, None)
            assert len(pages) >= 1

    def test_paginate_by_scenes(self, paginator):
        """Test scene-based pagination."""
        content = "Scene 1 content\n\n***\n\nScene 2 content\n\n***\n\nScene 3 content"

        def mock_estimate_tokens(text):
            return len(text.split()) * 2

        with patch.object(
            paginator.token_estimator, "estimate_tokens", side_effect=mock_estimate_tokens
        ):
            pages = paginator._paginate_by_scenes(content, 1, None)
            assert len(pages) >= 1

    def test_paginate_by_scenes_no_scene_breaks(self, paginator):
        """Test scene-based pagination with scene breaks."""
        content = "Just some content with a scene break.\n\n***\n\nMore content here."

        def mock_estimate_tokens(text):
            return len(text.split()) * 2

        with patch.object(
            paginator.token_estimator, "estimate_tokens", side_effect=mock_estimate_tokens
        ):
            pages = paginator._paginate_by_scenes(content, 1, None)
            assert len(pages) >= 1

    def test_paginate_by_paragraphs(self, paginator):
        """Test paragraph-based pagination."""
        content = "\n\n".join([f"Paragraph {i} content here" for i in range(10)])

        def mock_estimate_tokens(text):
            return len(text.split()) * 2

        with patch.object(
            paginator.token_estimator, "estimate_tokens", side_effect=mock_estimate_tokens
        ):
            pages = paginator._paginate_by_paragraphs(content, 1, None)
            assert len(pages) >= 1

    def test_paginate_semantically(self, paginator):
        """Test semantic pagination."""
        content = "Scene 1\n\n***\n\nScene 2\n\n***\n\nScene 3"

        def mock_estimate_tokens(text):
            return len(text.split()) * 2

        with patch.object(
            paginator.token_estimator, "estimate_tokens", side_effect=mock_estimate_tokens
        ):
            pages = paginator._paginate_semantically(content, 1, None)
            assert len(pages) >= 1

    def test_find_safe_split_point(self, paginator):
        """Test finding safe split point."""
        content = "Sentence one. Sentence two. Sentence three. Sentence four."
        split_pos = paginator._find_safe_split_point(content, 30)
        assert split_pos > 0
        assert split_pos <= len(content)

    def test_find_safe_split_point_no_sentence_boundary(self, paginator):
        """Test finding safe split point when no sentence boundary found."""
        content = "Word1 Word2 Word3 Word4 Word5"
        split_pos = paginator._find_safe_split_point(content, 15)
        assert split_pos > 0

    def test_create_page_from_content(self, paginator):
        """Test creating page from content."""
        content = "Test content for creating a page."

        def mock_estimate_tokens(text):
            return len(text.split()) * 2

        with patch.object(
            paginator.token_estimator, "estimate_tokens", side_effect=mock_estimate_tokens
        ):
            page = paginator._create_page_from_content(content, 1, 0, 1, None)
            assert page.page_number == 1
            assert page.content == content
            assert page.metadata.start_position == 0

    def test_enrich_page_metadata_characters(self, paginator):
        """Test enriching page metadata with characters."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=100,
        )
        chapter_metadata = {"characters": ["Alice", "Bob", "Charlie"]}
        content = "Alice and Bob were talking in the garden."

        paginator._enrich_page_metadata(metadata, chapter_metadata, content)

        assert "Alice" in metadata.characters_present
        assert "Bob" in metadata.characters_present
        assert "Charlie" not in metadata.characters_present

    def test_enrich_page_metadata_locations(self, paginator):
        """Test enriching page metadata with locations."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=100,
        )
        chapter_metadata = {"locations": ["Kitchen", "Garden", "Bedroom"]}
        content = "They met in the garden."

        paginator._enrich_page_metadata(metadata, chapter_metadata, content)

        assert "Garden" in metadata.locations_present
        assert "Kitchen" not in metadata.locations_present

    def test_enrich_page_metadata_dialogue(self, paginator):
        """Test enriching page metadata with dialogue."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=100,
        )
        chapter_metadata = {}
        content = 'Alice said "Hello there!" and Bob replied "Hi!"'

        paginator._enrich_page_metadata(metadata, chapter_metadata, content)

        assert len(metadata.key_events) > 0
        assert any("Dialogue:" in event for event in metadata.key_events)

    def test_regenerate_page(self, paginator):
        """Test regenerating a page."""
        original_metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=1000,
            word_count=500,
            token_count=2500,
            scene_identifier="scene_1",
            characters_present=["Alice"],
        )
        original_page = ChapterPage(
            page_number=1,
            content="Original content",
            metadata=original_metadata,
            overlap_content="Overlap",
        )

        new_content = "New regenerated content"

        def mock_estimate_tokens(text):
            return len(text.split()) * 2

        with patch.object(
            paginator.token_estimator, "estimate_tokens", side_effect=mock_estimate_tokens
        ):
            new_page = paginator.regenerate_page(original_page, new_content)

            assert new_page.page_number == 1
            assert new_page.content == new_content
            assert new_page.metadata.scene_identifier == "scene_1"
            assert new_page.metadata.characters_present == ["Alice"]
            assert new_page.overlap_content == "Overlap"

    def test_get_pagination_summary_empty(self, paginator):
        """Test pagination summary with no pages."""
        summary = paginator.get_pagination_summary([])
        assert summary["total_pages"] == 0
        assert summary["total_words"] == 0
        assert summary["total_tokens"] == 0
        assert summary["avg_words_per_page"] == 0
        assert summary["avg_tokens_per_page"] == 0

    def test_get_pagination_summary_with_pages(self, paginator):
        """Test pagination summary with pages."""
        metadata1 = PageMetadata(
            page_number=1, start_position=0, end_position=100, word_count=50, token_count=250
        )
        metadata2 = PageMetadata(
            page_number=2, start_position=100, end_position=200, word_count=50, token_count=250
        )
        pages = [
            ChapterPage(
                page_number=1,
                content="This is content for page one with more words",
                metadata=metadata1,
            ),
            ChapterPage(
                page_number=2,
                content="This is content for page two with more words",
                metadata=metadata2,
            ),
        ]

        summary = paginator.get_pagination_summary(pages)
        assert summary["total_pages"] == 2
        assert summary["total_words"] == 18
        assert summary["total_tokens"] == 500
        assert summary["avg_words_per_page"] == 9
        assert summary["avg_tokens_per_page"] == 250

    def test_get_pagination_summary_with_scenes(self, paginator):
        """Test pagination summary counts scenes."""
        metadata1 = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=250,
            scene_identifier="scene_1",
        )
        metadata2 = PageMetadata(
            page_number=2,
            start_position=100,
            end_position=200,
            word_count=50,
            token_count=250,
            scene_identifier="scene_2",
        )
        pages = [
            ChapterPage(page_number=1, content="Content 1", metadata=metadata1),
            ChapterPage(page_number=2, content="Content 2", metadata=metadata2),
        ]

        summary = paginator.get_pagination_summary(pages)
        assert summary["pages_with_scenes"] == 2

    def test_get_pagination_summary_unique_characters(self, paginator):
        """Test pagination summary counts unique characters."""
        metadata1 = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=250,
            characters_present=["Alice", "Bob"],
        )
        metadata2 = PageMetadata(
            page_number=2,
            start_position=100,
            end_position=200,
            word_count=50,
            token_count=250,
            characters_present=["Bob", "Charlie"],
        )
        pages = [
            ChapterPage(page_number=1, content="Content 1", metadata=metadata1),
            ChapterPage(page_number=2, content="Content 2", metadata=metadata2),
        ]

        summary = paginator.get_pagination_summary(pages)
        assert summary["total_characters"] == 3

    def test_get_pagination_summary_unique_locations(self, paginator):
        """Test pagination summary counts unique locations."""
        metadata1 = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=250,
            locations_present=["Kitchen", "Garden"],
        )
        metadata2 = PageMetadata(
            page_number=2,
            start_position=100,
            end_position=200,
            word_count=50,
            token_count=250,
            locations_present=["Garden", "Bedroom"],
        )
        pages = [
            ChapterPage(page_number=1, content="Content 1", metadata=metadata1),
            ChapterPage(page_number=2, content="Content 2", metadata=metadata2),
        ]

        summary = paginator.get_pagination_summary(pages)
        assert summary["total_locations"] == 3

    def test_paginate_chapter_with_metadata(self, paginator):
        """Test paginating chapter with metadata."""
        content = "Alice and Bob were in the garden."
        chapter_metadata = {
            "characters": ["Alice", "Bob", "Charlie"],
            "locations": ["Kitchen", "Garden", "Bedroom"],
        }

        def mock_estimate_tokens(text):
            return len(text.split()) * 2

        with patch.object(
            paginator.token_estimator, "estimate_tokens", side_effect=mock_estimate_tokens
        ):
            pages = paginator.paginate_chapter(content, 1, chapter_metadata)
            assert len(pages) == 1
            assert "Alice" in pages[0].metadata.characters_present
            assert "Garden" in pages[0].metadata.locations_present

    def test_large_scene_splitting(self, paginator):
        """Test splitting a scene that's too large."""
        content = ("Word " * 150) + "\n\n***\n\n" + ("Word " * 150)

        def mock_estimate_tokens(text):
            return len(text.split()) * 2

        with patch.object(
            paginator.token_estimator, "estimate_tokens", side_effect=mock_estimate_tokens
        ):
            pages = paginator._paginate_by_scenes(content, 1, None)
            assert len(pages) >= 1

    def test_large_paragraph_splitting(self, paginator):
        """Test splitting a paragraph that's too large."""
        content = "Word " * 300

        def mock_estimate_tokens(text):
            return len(text.split()) * 2

        with patch.object(
            paginator.token_estimator, "estimate_tokens", side_effect=mock_estimate_tokens
        ):
            pages = paginator._paginate_by_paragraphs(content, 1, None)
            assert len(pages) >= 1
