"""Unit tests for logs router."""

from unittest.mock import MagicMock

import pytest
from fastapi import HTTPException
from fastapi.responses import StreamingResponse

from api.models import LogEntry, LogLevel, LogsResponse
from api.routers.logs import (
    DEFAULT_LOG_LIMIT,
    DEFAULT_MAX_ITERATIONS,
    DEFAULT_POLL_INTERVAL,
    LogStreamerConfig,
    generate_log_sse_stream,
    get_project_log_file,
    parse_log_entries,
    read_log_file,
    validate_project_name,
)


class TestLogStreamerConfig:
    """Tests for LogStreamerConfig dataclass."""

    def test_default_config(self):
        """Test default configuration values."""
        config = LogStreamerConfig()
        assert config.poll_interval == DEFAULT_POLL_INTERVAL
        assert config.max_iterations == DEFAULT_MAX_ITERATIONS
        assert config.limit == DEFAULT_LOG_LIMIT

    def test_custom_config(self):
        """Test custom configuration values."""
        config = LogStreamerConfig(poll_interval=0.5, max_iterations=100, limit=50)
        assert config.poll_interval == 0.5
        assert config.max_iterations == 100
        assert config.limit == 50


class TestReadLogFile:
    """Tests for read_log_file function."""

    def test_read_empty_file(self, tmp_path):
        """Test reading an empty log file."""
        log_file = tmp_path / "execution.log"
        log_file.touch()

        result = read_log_file(log_file)
        assert result == []

    def test_read_nonexistent_file(self, tmp_path):
        """Test reading a nonexistent file."""
        log_file = tmp_path / "nonexistent.log"

        result = read_log_file(log_file)
        assert result == []

    def test_read_valid_json_lines(self, tmp_path):
        """Test reading valid JSON log lines."""
        log_file = tmp_path / "execution.log"
        log_file.write_text(
            '{"level": "INFO", "message": "test1"}\n{"level": "ERROR", "message": "test2"}\n'
        )

        result = read_log_file(log_file)
        assert len(result) == 2
        assert result[0]["level"] == "INFO"
        assert result[1]["level"] == "ERROR"

    def test_read_mixed_valid_invalid_lines(self, tmp_path):
        """Test reading mixed valid and invalid JSON lines."""
        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\nnot valid json\n{"level": "ERROR"}\n')

        result = read_log_file(log_file)
        assert len(result) == 2
        assert result[0]["level"] == "INFO"
        assert result[1]["level"] == "ERROR"

    def test_read_empty_lines(self, tmp_path):
        """Test reading file with empty lines."""
        log_file = tmp_path / "execution.log"
        log_file.write_text('{"level": "INFO"}\n\n\n{"level": "WARNING"}\n')

        result = read_log_file(log_file)
        assert len(result) == 2

    def test_read_with_whitespace(self, tmp_path):
        """Test reading lines with extra whitespace."""
        log_file = tmp_path / "execution.log"
        log_file.write_text('  {"level": "INFO"}  \n')

        result = read_log_file(log_file)
        assert len(result) == 1
        assert result[0]["level"] == "INFO"


class TestParseLogEntries:
    """Tests for parse_log_entries function."""

    def test_parse_empty_list(self):
        """Test parsing empty log data list."""
        result = parse_log_entries([])
        assert result == []

    def test_parse_valid_entries(self):
        """Test parsing valid log entries."""
        log_data = [
            {"level": "INFO", "message": "Test message"},
            {"level": "ERROR", "message": "Error message"},
        ]

        result = parse_log_entries(log_data)
        assert len(result) == 2
        assert all(isinstance(entry, LogEntry) for entry in result)

    def test_parse_with_level_filter(self):
        """Test parsing with level filter."""
        log_data = [
            {"level": "INFO", "message": "Info message"},
            {"level": "ERROR", "message": "Error message"},
            {"level": "WARNING", "message": "Warning message"},
        ]

        result = parse_log_entries(log_data, level=LogLevel.ERROR)
        assert len(result) == 1
        assert result[0].level == LogLevel.ERROR

    def test_parse_with_execution_id_filter(self):
        """Test parsing with execution_id filter."""
        log_data = [
            {"level": "INFO", "execution_id": "exec1"},
            {"level": "INFO", "execution_id": "exec2"},
            {"level": "INFO", "execution_id": "exec1"},
        ]

        result = parse_log_entries(log_data, execution_id="exec1")
        assert len(result) == 2
        assert all(entry.execution_id == "exec1" for entry in result)

    def test_parse_with_both_filters(self):
        """Test parsing with both level and execution_id filters."""
        log_data = [
            {"level": "ERROR", "execution_id": "exec1"},
            {"level": "ERROR", "execution_id": "exec2"},
            {"level": "INFO", "execution_id": "exec1"},
        ]

        result = parse_log_entries(log_data, level=LogLevel.ERROR, execution_id="exec1")
        assert len(result) == 1
        assert result[0].level == LogLevel.ERROR
        assert result[0].execution_id == "exec1"

    def test_parse_with_timestamp(self):
        """Test parsing entries with timestamp."""
        timestamp = "2024-01-15T10:30:00"
        log_data = [{"level": "INFO", "message": "Test", "timestamp": timestamp}]

        result = parse_log_entries(log_data)
        assert len(result) == 1
        assert result[0].timestamp.isoformat() == timestamp

    def test_parse_with_missing_timestamp(self):
        """Test parsing entries without timestamp uses current time."""
        log_data = [{"level": "INFO", "message": "Test"}]

        result = parse_log_entries(log_data)
        assert len(result) == 1
        assert result[0].timestamp is not None

    def test_parse_with_metadata(self):
        """Test parsing entries with metadata."""
        log_data = [{"level": "INFO", "message": "Test", "metadata": {"key": "value"}}]

        result = parse_log_entries(log_data)
        assert len(result) == 1
        assert result[0].metadata == {"key": "value"}

    def test_parse_with_missing_level_defaults_to_info(self):
        """Test parsing entries without level defaults to INFO."""
        log_data = [{"message": "Test"}]

        result = parse_log_entries(log_data)
        assert len(result) == 1
        assert result[0].level == LogLevel.INFO

    def test_parse_with_chapter(self):
        """Test parsing entries with chapter number."""
        log_data = [{"level": "INFO", "chapter": 5}]

        result = parse_log_entries(log_data)
        assert len(result) == 1
        assert result[0].chapter == 5


class TestGetProjectLogFile:
    """Tests for get_project_log_file function."""

    def test_returns_correct_path(self, tmp_path):
        """Test returns correct log file path."""
        project_dir = tmp_path / "projects"
        project_name = "my_project"

        result = get_project_log_file(project_dir, project_name)

        expected = project_dir / project_name / "logs" / "execution.log"
        assert result == expected


class TestValidateProjectName:
    """Tests for validate_project_name function."""

    def test_valid_project_name(self):
        """Test valid project name passes validation."""
        validate_project_name("my_project")
        validate_project_name("MyProject123")
        validate_project_name("my-project")

    def test_project_name_with_slash_raises(self):
        """Test project name with forward slash raises HTTPException."""
        with pytest.raises(HTTPException) as exc_info:
            validate_project_name("my/project")
        assert exc_info.value.status_code == 400
        assert "Invalid project name" in str(exc_info.value.detail)

    def test_project_name_with_backslash_raises(self):
        """Test project name with backslash raises HTTPException."""
        with pytest.raises(HTTPException) as exc_info:
            validate_project_name("my\\project")
        assert exc_info.value.status_code == 400
        assert "Invalid project name" in str(exc_info.value.detail)


class TestGetProjectLogsEndpoint:
    """Tests for get_project_logs endpoint."""

    async def test_get_project_logs_success(self, tmp_path):
        """Test successful project logs retrieval."""
        from api.routers.logs import get_project_logs

        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_file = project_dir / "logs" / "execution.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.write_text(
            '{"level": "INFO", "message": "Info message"}\n'
            '{"level": "WARNING", "message": "Warning message"}\n'
        )

        mock_storage_provider = MagicMock()
        mock_storage_provider.list_projects.return_value = ["test_project"]
        mock_storage_provider.project_dir = tmp_path

        response = await get_project_logs(
            "test_project",
            storage_provider=lambda: mock_storage_provider,
        )

        assert isinstance(response, LogsResponse)
        assert response.project == "test_project"
        assert len(response.logs) == 2

    async def test_get_project_logs_with_level_filter(self, tmp_path):
        """Test project logs retrieval with level filter."""
        from api.routers.logs import get_project_logs

        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_file = project_dir / "logs" / "execution.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.write_text(
            '{"level": "INFO", "message": "Info message"}\n'
            '{"level": "ERROR", "message": "Error message"}\n'
        )

        mock_storage_provider = MagicMock()
        mock_storage_provider.list_projects.return_value = ["test_project"]
        mock_storage_provider.project_dir = tmp_path

        response = await get_project_logs(
            "test_project",
            level=LogLevel.ERROR,
            storage_provider=lambda: mock_storage_provider,
        )

        assert len(response.logs) == 1
        assert response.logs[0].level == LogLevel.ERROR

    async def test_get_project_logs_pagination(self, tmp_path):
        """Test project logs pagination."""
        from api.routers.logs import get_project_logs

        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_file = project_dir / "logs" / "execution.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.write_text(
            '{"level": "INFO", "message": "Log 1"}\n'
            '{"level": "INFO", "message": "Log 2"}\n'
            '{"level": "INFO", "message": "Log 3"}\n'
        )

        mock_storage_provider = MagicMock()
        mock_storage_provider.list_projects.return_value = ["test_project"]
        mock_storage_provider.project_dir = tmp_path

        response = await get_project_logs(
            "test_project",
            limit=2,
            offset=0,
            storage_provider=lambda: mock_storage_provider,
        )

        assert len(response.logs) == 2
        assert response.total == 3
        assert response.has_more is True

    async def test_get_project_logs_not_found(self):
        """Test project logs with non-existent project."""
        from api.routers.logs import get_project_logs

        mock_storage_provider = MagicMock()
        mock_storage_provider.list_projects.return_value = ["other_project"]

        with pytest.raises(HTTPException) as exc_info:
            await get_project_logs(
                "nonexistent_project",
                storage_provider=lambda: mock_storage_provider,
            )

        assert exc_info.value.status_code == 404

    async def test_get_project_logs_invalid_name(self):
        """Test project logs with invalid project name."""
        from api.routers.logs import get_project_logs

        mock_storage_provider = MagicMock()

        with pytest.raises(HTTPException) as exc_info:
            await get_project_logs(
                "invalid/name",
                storage_provider=lambda: mock_storage_provider,
            )

        assert exc_info.value.status_code == 400

    async def test_get_project_logs_empty_file(self, tmp_path):
        """Test project logs with empty log file."""
        from api.routers.logs import get_project_logs

        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_file = project_dir / "logs" / "execution.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.touch()

        mock_storage_provider = MagicMock()
        mock_storage_provider.list_projects.return_value = ["test_project"]
        mock_storage_provider.project_dir = tmp_path

        response = await get_project_logs(
            "test_project",
            storage_provider=lambda: mock_storage_provider,
        )

        assert response.logs == []
        assert response.total == 0

    async def test_get_project_logs_server_error(self):
        """Test project logs returns 500 on error."""
        from api.routers.logs import get_project_logs

        mock_provider = MagicMock()
        mock_provider.list_projects.side_effect = Exception("Storage error")

        with pytest.raises(HTTPException) as exc_info:
            await get_project_logs(
                "test_project",
                storage_provider=lambda: mock_provider,
            )

        assert exc_info.value.status_code == 500


class TestGetExecutionLogsEndpoint:
    """Tests for get_execution_logs endpoint."""

    async def test_get_execution_logs_success(self, tmp_path):
        """Test successful execution logs retrieval."""
        from api.routers.logs import get_execution_logs

        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_file = project_dir / "logs" / "execution.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.write_text(
            '{"level": "INFO", "execution_id": "exec1", "message": "Exec1 log"}\n'
            '{"level": "INFO", "execution_id": "exec2", "message": "Exec2 log"}\n'
            '{"level": "INFO", "execution_id": "exec1", "message": "Exec1 log 2"}\n'
        )

        mock_storage_provider = MagicMock()
        mock_storage_provider.list_projects.return_value = ["test_project"]
        mock_storage_provider.project_dir = tmp_path

        response = await get_execution_logs(
            "test_project",
            "exec1",
            storage_provider=lambda: mock_storage_provider,
        )

        assert len(response.logs) == 2
        assert all(log.execution_id == "exec1" for log in response.logs)

    async def test_get_execution_logs_not_found(self):
        """Test execution logs with non-existent project."""
        from api.routers.logs import get_execution_logs

        mock_storage_provider = MagicMock()
        mock_storage_provider.list_projects.return_value = []

        with pytest.raises(HTTPException) as exc_info:
            await get_execution_logs(
                "nonexistent_project",
                "exec1",
                storage_provider=lambda: mock_storage_provider,
            )

        assert exc_info.value.status_code == 404

    async def test_get_execution_logs_pagination(self, tmp_path):
        """Test execution logs pagination."""
        from api.routers.logs import get_execution_logs

        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_file = project_dir / "logs" / "execution.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.write_text(
            '{"level": "INFO", "execution_id": "exec1", "message": "Log 1"}\n'
            '{"level": "INFO", "execution_id": "exec1", "message": "Log 2"}\n'
            '{"level": "INFO", "execution_id": "exec1", "message": "Log 3"}\n'
        )

        mock_storage_provider = MagicMock()
        mock_storage_provider.list_projects.return_value = ["test_project"]
        mock_storage_provider.project_dir = tmp_path

        response = await get_execution_logs(
            "test_project",
            "exec1",
            limit=2,
            offset=0,
            storage_provider=lambda: mock_storage_provider,
        )

        assert len(response.logs) == 2
        assert response.total == 3
        assert response.has_more is True


class TestStreamLogsEndpoint:
    """Tests for stream_logs endpoint."""

    async def test_stream_logs_returns_streaming_response(self, tmp_path):
        """Test stream_logs returns StreamingResponse."""
        from api.routers.logs import stream_logs

        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_file = project_dir / "logs" / "execution.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.write_text('{"level": "INFO", "message": "Test"}\n')

        mock_storage_provider = MagicMock()
        mock_storage_provider.list_projects.return_value = ["test_project"]
        mock_storage_provider.project_dir = tmp_path

        response = await stream_logs(
            "test_project",
            storage_provider=lambda: mock_storage_provider,
        )

        assert isinstance(response, StreamingResponse)
        assert response.media_type == "text/event-stream"

    async def test_stream_logs_not_found(self):
        """Test stream_logs with non-existent project."""
        from api.routers.logs import stream_logs

        mock_storage_provider = MagicMock()
        mock_storage_provider.list_projects.return_value = []

        with pytest.raises(HTTPException) as exc_info:
            await stream_logs(
                "nonexistent_project",
                storage_provider=lambda: mock_storage_provider,
            )

        assert exc_info.value.status_code == 404

    async def test_stream_logs_invalid_name(self):
        """Test stream_logs with invalid project name."""
        from api.routers.logs import stream_logs

        mock_storage_provider = MagicMock()

        with pytest.raises(HTTPException) as exc_info:
            await stream_logs(
                "invalid/name",
                storage_provider=lambda: mock_storage_provider,
            )

        assert exc_info.value.status_code == 400


class TestGenerateLogSSEStream:
    """Tests for generate_log_sse_stream function."""

    async def test_generates_initial_events(self, tmp_path):
        """Test generator produces initial events."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)
        log_file = project_dir / "logs" / "execution.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.write_text('{"level": "INFO", "message": "Test log"}\n')

        mock_storage = MagicMock()
        mock_storage.list_projects.return_value = ["test_project"]
        mock_storage.project_dir = tmp_path

        events = []
        async for event in generate_log_sse_stream(
            "test_project",
            storage_provider=lambda: mock_storage,
            config=LogStreamerConfig(poll_interval=0.001, max_iterations=2),
        ):
            events.append(event)
            if len(events) >= 10:
                break

        assert len(events) >= 1

    async def test_project_not_found_yields_error(self, tmp_path):
        """Test generator yields error when project not found."""
        mock_storage = MagicMock()
        mock_storage.list_projects.return_value = []

        events = []
        async for event in generate_log_sse_stream(
            "nonexistent",
            storage_provider=lambda: mock_storage,
            config=LogStreamerConfig(poll_interval=0.001, max_iterations=2),
        ):
            events.append(event)
            if len(events) >= 5:
                break

        error_events = [e for e in events if "error" in e]
        assert len(error_events) >= 1
