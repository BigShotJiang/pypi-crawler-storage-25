"""Tests for memory_monitor module."""

import time
from datetime import datetime, timedelta, timezone
from unittest.mock import Mock

import pytest

from core.memory_monitor import (
    MemoryAction,
    MemoryMonitor,
    MemoryMonitorConfig,
    MemoryThreshold,
    create_default_monitor,
)


class TestMemoryAction:
    """Test MemoryAction enum."""

    def test_memory_action_values(self):
        """Test MemoryAction enum values."""
        assert MemoryAction.LOG.value == "log"
        assert MemoryAction.PRUNE.value == "prune"
        assert MemoryAction.CLEAR.value == "clear"
        assert MemoryAction.ERROR.value == "error"


class TestMemoryThreshold:
    """Test MemoryThreshold dataclass."""

    def test_memory_threshold_creation(self):
        """Test MemoryThreshold creation."""
        threshold = MemoryThreshold(
            name="test_threshold",
            warning_mb=100.0,
            critical_mb=200.0,
            action=MemoryAction.LOG,
        )
        assert threshold.name == "test_threshold"
        assert threshold.warning_mb == 100.0
        assert threshold.critical_mb == 200.0
        assert threshold.action == MemoryAction.LOG
        assert threshold.action_callback is None

    def test_memory_threshold_with_callback(self):
        """Test MemoryThreshold with callback."""
        callback = Mock()
        threshold = MemoryThreshold(
            name="test_threshold",
            warning_mb=100.0,
            critical_mb=200.0,
            action=MemoryAction.LOG,
            action_callback=callback,
        )
        assert threshold.action_callback == callback

    def test_check_critical_level(self):
        """Test threshold check at critical level."""
        threshold = MemoryThreshold(
            name="test", warning_mb=100.0, critical_mb=200.0, action=MemoryAction.LOG
        )
        status = threshold.check(250.0)
        assert status == "critical"

    def test_check_warning_level(self):
        """Test threshold check at warning level."""
        threshold = MemoryThreshold(
            name="test", warning_mb=100.0, critical_mb=200.0, action=MemoryAction.LOG
        )
        status = threshold.check(150.0)
        assert status == "warning"

    def test_check_below_threshold(self):
        """Test threshold check below warning level."""
        threshold = MemoryThreshold(
            name="test", warning_mb=100.0, critical_mb=200.0, action=MemoryAction.LOG
        )
        status = threshold.check(50.0)
        assert status is None

    def test_check_at_warning_boundary(self):
        """Test threshold check at warning boundary."""
        threshold = MemoryThreshold(
            name="test", warning_mb=100.0, critical_mb=200.0, action=MemoryAction.LOG
        )
        status = threshold.check(100.0)
        assert status == "warning"

    def test_check_at_critical_boundary(self):
        """Test threshold check at critical boundary."""
        threshold = MemoryThreshold(
            name="test", warning_mb=100.0, critical_mb=200.0, action=MemoryAction.LOG
        )
        status = threshold.check(200.0)
        assert status == "critical"


class TestMemoryMonitorConfig:
    """Test MemoryMonitorConfig model."""

    def test_default_config(self):
        """Test default configuration values."""
        config = MemoryMonitorConfig()
        assert config.check_interval_seconds == 30
        assert config.enable_trend_analysis is True
        assert config.trend_window_seconds == 300
        assert config.enable_alerts is True
        assert config.enable_auto_actions is True
        assert config.log_threshold_triggers is True

    def test_custom_config(self):
        """Test custom configuration values."""
        config = MemoryMonitorConfig(
            check_interval_seconds=60,
            enable_trend_analysis=False,
            trend_window_seconds=600,
            enable_alerts=False,
            enable_auto_actions=False,
            log_threshold_triggers=False,
        )
        assert config.check_interval_seconds == 60
        assert config.enable_trend_analysis is False
        assert config.trend_window_seconds == 600
        assert config.enable_alerts is False
        assert config.enable_auto_actions is False
        assert config.log_threshold_triggers is False


class TestMemoryMonitor:
    """Test MemoryMonitor class."""

    @pytest.fixture
    def thresholds(self):
        """Create test thresholds."""
        return [
            MemoryThreshold(
                name="low", warning_mb=100.0, critical_mb=200.0, action=MemoryAction.LOG
            ),
            MemoryThreshold(
                name="high", warning_mb=300.0, critical_mb=500.0, action=MemoryAction.PRUNE
            ),
        ]

    @pytest.fixture
    def mock_profiler(self):
        """Create mock memory profiler."""
        profiler = Mock()
        profiler.get_current_usage.return_value = 50.0
        profiler.start_profiling = Mock()
        profiler.stop_profiling = Mock()
        return profiler

    @pytest.fixture
    def monitor(self, thresholds, mock_profiler):
        """Create MemoryMonitor instance."""
        config = MemoryMonitorConfig(check_interval_seconds=1)
        return MemoryMonitor(thresholds=thresholds, config=config, profiler=mock_profiler)

    def test_initialization(self, monitor, thresholds, mock_profiler):
        """Test MemoryMonitor initialization."""
        assert monitor.thresholds == thresholds
        assert monitor.config.check_interval_seconds == 1
        assert monitor.profiler == mock_profiler
        assert monitor.monitoring is False
        assert monitor.monitor_thread is None
        assert len(monitor.triggered_actions) == 0
        assert len(monitor.memory_history) == 0
        assert monitor.max_history_size == 1000
        assert len(monitor.alert_callbacks) == 0

    def test_initialization_without_profiler(self, thresholds):
        """Test initialization without profiler."""
        monitor = MemoryMonitor(thresholds=thresholds)
        assert monitor.profiler is not None

    def test_initialization_with_default_config(self, thresholds):
        """Test initialization with default config."""
        monitor = MemoryMonitor(thresholds=thresholds)
        assert monitor.config.check_interval_seconds == 30
        assert monitor.config.enable_trend_analysis is True

    def test_start_stop_monitoring(self, monitor, mock_profiler):
        """Test starting and stopping monitoring."""
        monitor.start_monitoring()
        assert monitor.monitoring is True
        assert monitor.monitor_thread is not None
        mock_profiler.start_profiling.assert_called_once_with(1)

        monitor.stop_monitoring()
        assert monitor.monitoring is False
        mock_profiler.stop_profiling.assert_called_once()

    def test_start_monitoring_when_already_monitoring(self, monitor):
        """Test starting monitoring when already monitoring."""
        monitor.start_monitoring()
        initial_thread = monitor.monitor_thread

        monitor.start_monitoring()

        assert monitor.monitor_thread == initial_thread

        monitor.stop_monitoring()

    def test_stop_monitoring_when_not_monitoring(self, monitor):
        """Test stopping monitoring when not monitoring."""
        monitor.stop_monitoring()
        assert monitor.monitoring is False

    def test_monitoring_loop(self, monitor, mock_profiler):
        """Test monitoring loop functionality."""
        monitor.start_monitoring()
        time.sleep(0.2)
        monitor.stop_monitoring()
        assert len(mock_profiler.get_current_usage.call_args_list) >= 1

    def test_check_memory_all_passed(self, monitor, mock_profiler):
        """Test check memory when all thresholds pass."""
        mock_profiler.get_current_usage.return_value = 50.0

        result = monitor.check_memory()

        assert result is True
        assert len(monitor.triggered_actions) == 0

    def test_check_memory_warning_triggered(self, monitor, mock_profiler):
        """Test check memory with warning triggered."""
        mock_profiler.get_current_usage.return_value = 150.0

        result = monitor.check_memory()

        assert result is False
        assert len(monitor.triggered_actions) == 1
        assert monitor.triggered_actions[0]["threshold"] == "low"
        assert monitor.triggered_actions[0]["status"] == "warning"

    def test_check_memory_critical_triggered(self, monitor, mock_profiler):
        """Test check memory with critical triggered."""
        mock_profiler.get_current_usage.return_value = 250.0

        result = monitor.check_memory()

        assert result is False
        assert len(monitor.triggered_actions) == 1
        assert monitor.triggered_actions[0]["status"] == "critical"

    def test_check_memory_multiple_thresholds(self, monitor, mock_profiler):
        """Test check memory with multiple thresholds triggered."""
        mock_profiler.get_current_usage.return_value = 400.0

        result = monitor.check_memory()

        assert result is False
        assert len(monitor.triggered_actions) == 2

    def test_get_current_usage(self, monitor, mock_profiler):
        """Test getting current memory usage."""
        mock_profiler.get_current_usage.return_value = 123.45

        usage = monitor.get_current_usage()

        assert usage == 123.45

    def test_trigger_action_log(self, monitor, mock_profiler):
        """Test triggering LOG action."""
        threshold = MemoryThreshold(
            name="test", warning_mb=100.0, critical_mb=200.0, action=MemoryAction.LOG
        )
        mock_profiler.get_current_usage.return_value = 150.0

        monitor.trigger_action(threshold, "warning")

        assert len(monitor.triggered_actions) == 1
        assert monitor.triggered_actions[0]["action"] == "log"
        assert monitor.triggered_actions[0]["result"] == "success"
        assert monitor.triggered_actions[0]["action_performed"] == "Logged warning"

    def test_trigger_action_prune(self, monitor, mock_profiler):
        """Test triggering PRUNE action."""
        threshold = MemoryThreshold(
            name="test", warning_mb=100.0, critical_mb=200.0, action=MemoryAction.PRUNE
        )
        mock_profiler.get_current_usage.return_value = 150.0

        monitor.trigger_action(threshold, "warning")

        assert len(monitor.triggered_actions) == 1
        assert monitor.triggered_actions[0]["action"] == "prune"
        assert monitor.triggered_actions[0]["result"] == "success"

    def test_trigger_action_clear(self, monitor, mock_profiler):
        """Test triggering CLEAR action."""
        threshold = MemoryThreshold(
            name="test", warning_mb=100.0, critical_mb=200.0, action=MemoryAction.CLEAR
        )
        mock_profiler.get_current_usage.return_value = 150.0

        monitor.trigger_action(threshold, "warning")

        assert len(monitor.triggered_actions) == 1
        assert monitor.triggered_actions[0]["action"] == "clear"
        assert monitor.triggered_actions[0]["result"] == "success"

    def test_trigger_action_error(self, monitor, mock_profiler):
        """Test triggering ERROR action."""
        threshold = MemoryThreshold(
            name="test", warning_mb=100.0, critical_mb=200.0, action=MemoryAction.ERROR
        )
        mock_profiler.get_current_usage.return_value = 150.0

        with pytest.raises(MemoryError, match="Memory threshold test exceeded"):
            monitor.trigger_action(threshold, "critical")

    def test_trigger_action_with_callback(self, monitor, mock_profiler):
        """Test triggering action with custom callback."""
        callback = Mock()
        threshold = MemoryThreshold(
            name="test",
            warning_mb=100.0,
            critical_mb=200.0,
            action=MemoryAction.LOG,
            action_callback=callback,
        )
        mock_profiler.get_current_usage.return_value = 150.0

        monitor.trigger_action(threshold, "warning")

        assert len(monitor.triggered_actions) == 1
        assert callback.called
        assert monitor.triggered_actions[0]["action_performed"] == "Executed callback"

    def test_trigger_action_callback_exception(self, monitor, mock_profiler):
        """Test action callback with exception."""
        callback = Mock(side_effect=Exception("Callback failed"))
        threshold = MemoryThreshold(
            name="test",
            warning_mb=100.0,
            critical_mb=200.0,
            action=MemoryAction.LOG,
            action_callback=callback,
        )
        mock_profiler.get_current_usage.return_value = 150.0

        monitor.trigger_action(threshold, "warning")

        assert len(monitor.triggered_actions) == 1
        assert monitor.triggered_actions[0]["result"] == "error"
        assert "Callback failed" in monitor.triggered_actions[0]["error"]

    def test_record_memory(self, monitor):
        """Test recording memory usage."""
        monitor._record_memory(100.0)
        monitor._record_memory(200.0)

        assert len(monitor.memory_history) == 2
        assert monitor.memory_history[0][1] == 100.0
        assert monitor.memory_history[1][1] == 200.0

    def test_record_memory_auto_cleanup(self, monitor):
        """Test automatic memory history cleanup."""
        monitor.max_history_size = 3

        for i in range(5):
            monitor._record_memory(float(i * 100))

        assert len(monitor.memory_history) == 3

    def test_get_trend_increasing(self, monitor):
        """Test trend detection for increasing memory."""
        base_time = datetime.now(timezone.utc)
        monitor.memory_history = [
            (base_time - timedelta(seconds=4), 100.0),
            (base_time - timedelta(seconds=3), 150.0),
            (base_time - timedelta(seconds=2), 200.0),
            (base_time - timedelta(seconds=1), 250.0),
        ]

        trend = monitor.get_trend()

        assert trend == "increasing"

    def test_get_trend_decreasing(self, monitor):
        """Test trend detection for decreasing memory."""
        base_time = datetime.now(timezone.utc)
        monitor.memory_history = [
            (base_time - timedelta(seconds=4), 250.0),
            (base_time - timedelta(seconds=3), 200.0),
            (base_time - timedelta(seconds=2), 150.0),
            (base_time - timedelta(seconds=1), 100.0),
        ]

        trend = monitor.get_trend()

        assert trend == "decreasing"

    def test_get_trend_stable(self, monitor):
        """Test trend detection for stable memory."""
        base_time = datetime.now(timezone.utc)
        monitor.memory_history = [
            (base_time - timedelta(seconds=4), 150.0),
            (base_time - timedelta(seconds=3), 148.0),
            (base_time - timedelta(seconds=2), 152.0),
            (base_time - timedelta(seconds=1), 150.0),
            (base_time, 152.0),
        ]

        trend = monitor.get_trend()

        assert trend == "stable"

    def test_get_trend_insufficient_history(self, monitor):
        """Test trend with insufficient history."""
        monitor.memory_history = [(datetime.now(timezone.utc), 100.0)]

        trend = monitor.get_trend()

        assert trend == "stable"

    def test_get_trend_disabled(self, monitor):
        """Test trend when analysis is disabled."""
        monitor.config.enable_trend_analysis = False

        trend = monitor.get_trend()

        assert trend == "unknown"

    def test_add_alert_callback(self, monitor):
        """Test adding alert callback."""
        callback = Mock()
        monitor.add_alert_callback(callback)

        assert len(monitor.alert_callbacks) == 1
        assert callback in monitor.alert_callbacks

    def test_send_alert(self, monitor, mock_profiler):
        """Test sending alerts."""
        callback1 = Mock()
        callback2 = Mock()
        monitor.alert_callbacks = [callback1, callback2]

        threshold = MemoryThreshold(
            name="test", warning_mb=100.0, critical_mb=200.0, action=MemoryAction.LOG
        )

        monitor._send_alert(threshold, 150.0, "warning")

        callback1.assert_called_once()
        callback2.assert_called_once()

    def test_send_alert_callback_exception(self, monitor, mock_profiler):
        """Test alert callback with exception."""
        callback = Mock(side_effect=Exception("Alert failed"))
        monitor.alert_callbacks = [callback]

        threshold = MemoryThreshold(
            name="test", warning_mb=100.0, critical_mb=200.0, action=MemoryAction.LOG
        )

        monitor._send_alert(threshold, 150.0, "warning")

    def test_get_triggered_actions(self, monitor, mock_profiler):
        """Test getting triggered actions."""
        mock_profiler.get_current_usage.return_value = 150.0

        monitor.check_memory()

        actions = monitor.get_triggered_actions()

        assert len(actions) == 1
        assert actions == monitor.triggered_actions

    def test_get_triggered_actions_copy(self, monitor):
        """Test that triggered actions returns a copy."""
        monitor.triggered_actions = [{"test": "data"}]

        actions = monitor.get_triggered_actions()
        actions.append({"new": "action"})

        assert len(monitor.triggered_actions) == 1

    def test_clear_triggered_actions(self, monitor, mock_profiler):
        """Test clearing triggered actions."""
        mock_profiler.get_current_usage.return_value = 150.0

        monitor.check_memory()
        assert len(monitor.triggered_actions) == 1

        monitor.clear_triggered_actions()

        assert len(monitor.triggered_actions) == 0

    def test_get_status_report(self, monitor, mock_profiler):
        """Test getting status report."""
        mock_profiler.get_current_usage.return_value = 50.0

        report = monitor.get_status_report()

        assert "monitoring" in report
        assert "current_memory_mb" in report
        assert "trend" in report
        assert "thresholds" in report
        assert "triggered_actions_count" in report
        assert "check_interval_seconds" in report
        assert len(report["thresholds"]) == 2

    def test_set_threshold_new(self, monitor):
        """Test setting new threshold."""
        new_threshold = MemoryThreshold(
            name="new_threshold", warning_mb=500.0, critical_mb=1000.0, action=MemoryAction.LOG
        )

        monitor.set_threshold(new_threshold)

        assert len(monitor.thresholds) == 3
        assert new_threshold in monitor.thresholds

    def test_set_threshold_update(self, monitor):
        """Test updating existing threshold."""
        updated_threshold = MemoryThreshold(
            name="low", warning_mb=150.0, critical_mb=250.0, action=MemoryAction.CLEAR
        )

        monitor.set_threshold(updated_threshold)

        assert len(monitor.thresholds) == 2
        assert monitor.thresholds[0].warning_mb == 150.0
        assert monitor.thresholds[0].critical_mb == 250.0
        assert monitor.thresholds[0].action == MemoryAction.CLEAR

    def test_remove_threshold(self, monitor):
        """Test removing threshold."""
        initial_count = len(monitor.thresholds)

        monitor.remove_threshold("low")

        assert len(monitor.thresholds) == initial_count - 1
        assert all(t.name != "low" for t in monitor.thresholds)

    def test_get_memory_history(self, monitor):
        """Test getting memory history."""
        base_time = datetime.now(timezone.utc)
        monitor.memory_history = [
            (base_time - timedelta(seconds=400), 100.0),
            (base_time - timedelta(seconds=200), 150.0),
            (base_time - timedelta(seconds=100), 200.0),
        ]

        history = monitor.get_memory_history(seconds=300)

        assert len(history) == 2

    def test_get_memory_history_all(self, monitor):
        """Test getting all memory history."""
        base_time = datetime.now(timezone.utc)
        monitor.memory_history = [
            (base_time - timedelta(seconds=100), 100.0),
            (base_time - timedelta(seconds=50), 150.0),
        ]

        history = monitor.get_memory_history(seconds=300)

        assert len(history) == 2

    def test_log_threshold_trigger(self, monitor, capsys):
        """Test logging threshold trigger."""
        threshold = MemoryThreshold(
            name="test", warning_mb=100.0, critical_mb=200.0, action=MemoryAction.LOG
        )

        monitor._log_threshold_trigger(threshold, 150.0, "warning")

        captured = capsys.readouterr()
        assert "Memory threshold 'test' triggered" in captured.out
        assert "150.0" in captured.out

    def test_check_memory_with_alerts_disabled(self, monitor, mock_profiler):
        """Test check memory with alerts disabled."""
        monitor.config.enable_alerts = False
        callback = Mock()
        monitor.alert_callbacks = [callback]
        mock_profiler.get_current_usage.return_value = 150.0

        monitor.check_memory()

        assert not callback.called

    def test_check_memory_with_auto_actions_disabled(self, monitor, mock_profiler):
        """Test check memory with auto actions disabled."""
        monitor.config.enable_auto_actions = False
        mock_profiler.get_current_usage.return_value = 150.0

        monitor.check_memory()

        assert len(monitor.triggered_actions) == 0

    def test_start_monitoring_starts_profiler(self, monitor, mock_profiler):
        """Test starting monitoring also starts profiler."""
        monitor.start_monitoring()

        mock_profiler.start_profiling.assert_called_once()

        monitor.stop_monitoring()

    def test_stop_monitoring_stops_profiler(self, monitor, mock_profiler):
        """Test stopping monitoring also stops profiler."""
        monitor.start_monitoring()
        monitor.stop_monitoring()

        mock_profiler.stop_profiling.assert_called_once()

    def test_monitoring_loop_continues_on_error(self, monitor, mock_profiler):
        """Test monitoring loop continues on error."""
        mock_profiler.get_current_usage.side_effect = [Exception("Error"), 100.0, 200.0]

        monitor.config.check_interval_seconds = 0.1
        monitor.start_monitoring()
        time.sleep(0.3)
        monitor.stop_monitoring()

        assert mock_profiler.get_current_usage.call_count >= 2

    def test_status_report_with_different_threshold_statuses(self, monitor, mock_profiler):
        """Test status report with different threshold statuses."""
        mock_profiler.get_current_usage.return_value = 150.0

        report = monitor.get_status_report()

        low_threshold = next(t for t in report["thresholds"] if t["name"] == "low")
        high_threshold = next(t for t in report["thresholds"] if t["name"] == "high")

        assert low_threshold["status"] == "warning"
        assert high_threshold["status"] == "ok"


class TestCreateDefaultMonitor:
    """Test create_default_monitor function."""

    def test_create_default_monitor(self):
        """Test creating default monitor."""
        monitor = create_default_monitor()

        assert isinstance(monitor, MemoryMonitor)
        assert len(monitor.thresholds) == 4

    def test_default_monitor_thresholds(self):
        """Test default monitor has correct thresholds."""
        monitor = create_default_monitor()

        threshold_names = [t.name for t in monitor.thresholds]
        assert "general" in threshold_names
        assert "cache_pruning" in threshold_names
        assert "cache_clearing" in threshold_names
        assert "critical_limit" in threshold_names

    def test_default_monitor_actions(self):
        """Test default monitor has correct actions."""
        monitor = create_default_monitor()

        actions = {t.name: t.action for t in monitor.thresholds}
        assert actions["general"] == MemoryAction.LOG
        assert actions["cache_pruning"] == MemoryAction.PRUNE
        assert actions["cache_clearing"] == MemoryAction.CLEAR
        assert actions["critical_limit"] == MemoryAction.ERROR

    def test_default_monitor_threshold_values(self):
        """Test default monitor threshold values."""
        monitor = create_default_monitor()

        general = next(t for t in monitor.thresholds if t.name == "general")
        assert general.warning_mb == 1000.0
        assert general.critical_mb == 2000.0

        critical = next(t for t in monitor.thresholds if t.name == "critical_limit")
        assert critical.warning_mb == 2500.0
        assert critical.critical_mb == 4000.0
