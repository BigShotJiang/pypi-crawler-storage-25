"""
Comprehensive tests for context_cache.py to increase coverage to 90%+.
Tests context caching, LRU eviction, and prefetching.
"""

import time

from novel_harness.core.context_cache import (
    CacheEntry,
    CacheStatistics,
    ContextCache,
    ContextCacheConfig,
)


class TestCacheEntry:
    """Test CacheEntry dataclass."""

    def test_touch_updates_timestamp(self):
        """Test touch() updates last_accessed."""
        entry = CacheEntry(
            key="test_key",
            content="test_content",
            size_bytes=10,
        )

        initial_time = entry.last_accessed
        time.sleep(0.01)
        entry.touch()

        assert entry.last_accessed > initial_time
        assert entry.access_count == 1


class TestContextCacheConfig:
    """Test ContextCacheConfig model."""

    def test_default_config(self):
        """Test default configuration values."""
        config = ContextCacheConfig()

        assert config.max_size_mb == 100.0
        assert config.max_entries == 100
        assert config.enable_compression is False
        assert config.eviction_policy == "lru"
        assert config.track_access_patterns is True
        assert config.prefetch_enabled is True
        assert config.prefetch_count == 3

    def test_custom_config(self):
        """Test custom configuration."""
        config = ContextCacheConfig(
            max_size_mb=50.0,
            max_entries=50,
            eviction_policy="lfu",
        )

        assert config.max_size_mb == 50.0
        assert config.max_entries == 50
        assert config.eviction_policy == "lfu"


class TestCacheStatistics:
    """Test CacheStatistics class."""

    def test_hit_rate_zero_hits(self):
        """Test hit rate with no hits."""
        stats = CacheStatistics()

        assert stats.hit_rate == 0.0

    def test_hit_rate_with_hits(self):
        """Test hit rate calculation."""
        stats = CacheStatistics()
        stats.record_hit(100)
        stats.record_hit(100)
        stats.record_miss()

        assert stats.hit_rate == 2 / 3

    def test_miss_rate(self):
        """Test miss rate calculation."""
        stats = CacheStatistics()
        stats.record_hit()
        stats.record_miss()

        assert stats.miss_rate == 0.5

    def test_total_requests(self):
        """Test total requests calculation."""
        stats = CacheStatistics()
        stats.record_hit()
        stats.record_hit()
        stats.record_miss()

        assert stats.total_requests == 3

    def test_record_prefetch_hit(self):
        """Test recording prefetch hit."""
        stats = CacheStatistics()
        stats.record_prefetch_hit()

        assert stats.prefetch_hits == 1

    def test_record_bytes_loaded(self):
        """Test recording bytes loaded."""
        stats = CacheStatistics()
        stats.record_bytes_loaded(1000)

        assert stats.total_bytes_loaded == 1000


class TestContextCacheInit:
    """Test ContextCache initialization."""

    def test_init_with_defaults(self):
        """Test initialization with defaults."""
        cache = ContextCache()

        assert cache.config.max_size_mb == 100.0
        assert cache.cache == {}
        assert cache.stats is not None

    def test_init_with_config(self):
        """Test initialization with custom config."""
        config = ContextCacheConfig(max_size_mb=50.0)
        cache = ContextCache(config=config)

        assert cache.config.max_size_mb == 50.0


class TestContextCacheGet:
    """Test cache get operations."""

    def test_get_missing_key(self):
        """Test getting non-existent key."""
        cache = ContextCache()

        result = cache.get("missing_key")

        assert result is None
        assert cache.stats.misses == 1

    def test_get_existing_key(self):
        """Test getting existing key."""
        cache = ContextCache()
        cache.put("test_key", "test_value")

        result = cache.get("test_key")

        assert result == "test_value"
        assert cache.stats.hits == 1


class TestContextCachePut:
    """Test cache put operations."""

    def test_put_new_key(self):
        """Test putting new key."""
        cache = ContextCache()

        cache.put("test_key", "test_value")

        assert "test_key" in cache.cache

    def test_put_string_value(self):
        """Test putting string value."""
        cache = ContextCache()
        cache.put("key", "hello world")

        entry = cache.cache["key"]
        assert entry.size_bytes == len("hello world".encode("utf-8"))

    def test_put_dict_value(self):
        """Test putting dict value."""
        cache = ContextCache()
        cache.put("key", {"a": 1})

        assert "key" in cache.cache

    def test_put_updates_existing(self):
        """Test updating existing key."""
        cache = ContextCache()
        cache.put("key", "old")
        cache.put("key", "new")

        assert cache.cache["key"].content == "new"


class TestContextCacheEviction:
    """Test cache eviction."""

    def test_lru_eviction(self):
        """Test LRU eviction policy configuration."""
        config = ContextCacheConfig(eviction_policy="lru")
        cache = ContextCache(config=config)

        cache.put("key1", "value1")
        cache.put("key2", "value2")
        cache.get("key1")  # Access key1

        # key1 should be in cache with updated access
        assert "key1" in cache.cache
        assert cache.cache["key1"].access_count == 1

    def test_lfu_eviction(self):
        """Test LFU eviction policy configuration."""
        config = ContextCacheConfig(eviction_policy="lfu")
        cache = ContextCache(config=config)

        cache.put("key1", "value1")
        cache.get("key1")  # Access once
        cache.get("key1")  # Access twice
        cache.get("key1")  # Access thrice

        # key1 should have 3 accesses
        assert cache.cache["key1"].access_count == 3


class TestContextCacheInvalidate:
    """Test cache invalidation."""

    def test_invalidate_existing(self):
        """Test invalidating existing key."""
        cache = ContextCache()
        cache.put("key", "value")

        cache.invalidate("key")

        assert "key" not in cache.cache

    def test_invalidate_missing(self):
        """Test invalidating non-existent key."""
        cache = ContextCache()

        cache.invalidate("missing")

        assert cache.stats.evictions == 0


class TestContextCacheClear:
    """Test cache clearing."""

    def test_clear_all(self):
        """Test clearing all entries."""
        cache = ContextCache()
        cache.put("key1", "value1")
        cache.put("key2", "value2")

        cache.clear()

        assert len(cache.cache) == 0
        assert cache.stats.hits == 0
        assert cache.stats.misses == 0


class TestContextCachePrefetch:
    """Test prefetching functionality."""

    def test_prefetch_enabled(self):
        """Test prefetching is enabled by default."""
        cache = ContextCache()

        assert cache.config.prefetch_enabled is True

    def test_prefetch_disabled(self):
        """Test prefetching can be disabled."""
        config = ContextCacheConfig(prefetch_enabled=False)
        cache = ContextCache(config=config)

        assert cache.config.prefetch_enabled is False


class TestContextCachePatterns:
    """Test access pattern tracking."""

    def test_patterns_tracked(self):
        """Test that access patterns are tracked."""
        cache = ContextCache()
        cache.put("key", "value")
        cache.get("key")
        cache.get("key")
        cache.get("key")

        entry = cache.cache["key"]
        assert entry.access_count == 3


class TestContextCacheStats:
    """Test statistics tracking."""

    def test_get_stats(self):
        """Test getting cache statistics."""
        cache = ContextCache()
        cache.put("key", "value")
        cache.get("key")
        cache.get("missing")

        # Access the stats directly
        assert cache.stats.total_requests == 2
        assert cache.stats.hits == 1
        assert cache.stats.misses == 1


class TestContextCacheBulkOperations:
    """Test bulk operations."""

    def test_bulk_put(self):
        """Test putting multiple entries."""
        cache = ContextCache()

        entries = {"key1": "value1", "key2": "value2", "key3": "value3"}
        for key, value in entries.items():
            cache.put(key, value)

        assert len(cache.cache) == 3

    def test_clear_prefix(self):
        """Test clearing entries with prefix."""
        cache = ContextCache()
        cache.put("user:1", "value1")
        cache.put("user:2", "value2")
        cache.put("other:1", "value3")

        # Clear entries with user prefix
        keys_to_remove = [k for k in cache.cache.keys() if k.startswith("user:")]
        for k in keys_to_remove:
            cache.invalidate(k)

        assert "user:1" not in cache.cache
        assert "user:2" not in cache.cache
        assert "other:1" in cache.cache


class TestContextCacheEdgeCases:
    """Test edge cases."""

    def test_empty_key(self):
        """Test putting entry with empty key."""
        cache = ContextCache()
        cache.put("", "value")

        assert "" in cache.cache

    def test_none_value(self):
        """Test putting None value."""
        cache = ContextCache()
        cache.put("key", None)

        assert cache.get("key") is None

    def test_large_value(self):
        """Test putting large value."""
        cache = ContextCache()
        large_value = "x" * 100000
        cache.put("key", large_value)

        assert "key" in cache.cache
