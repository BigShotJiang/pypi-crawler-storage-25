"""Test coverage for core/logger.py."""

import json
import sqlite3
import tempfile
from pathlib import Path

from core.logger import (
    ActionType,
    JSONLogger,
    LLMRequest,
    LogType,
    NovelHarnessLogger,
    RequestStatus,
    SQLiteLogger,
    UserAction,
    log_llm_request,
    log_user_action,
)


class TestLLMRequest:
    def test_basic_creation(self):
        req = LLMRequest(
            request_id="req_123",
            project_name="test_project",
            agent_name="test_agent",
            provider="openai",
            model="gpt-4",
            system_prompt="You are helpful",
            user_prompt="Hello",
            max_tokens=4000,
            temperature=0.7,
            input_tokens=1000,
            output_tokens=500,
            total_tokens=1500,
            cost_usd=0.06,
            latency_ms=1000,
            status=RequestStatus.SUCCESS,
        )
        assert req.request_id == "req_123"
        assert req.provider == "openai"
        assert req.status == RequestStatus.SUCCESS
        assert req.timestamp is not None


class TestUserAction:
    def test_basic_creation(self):
        action = UserAction(
            action_id="act_456",
            action_type=ActionType.CLI,
            user_command="wst run",
            project_name="test_project",
            parameters={"verbose": True},
            result="Success",
            execution_time_ms=500,
            success=True,
        )
        assert action.action_id == "act_456"
        assert action.action_type == ActionType.CLI
        assert action.success is True


class TestJSONLogger:
    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        self.logger = JSONLogger(log_dir=self.temp_dir)

    def test_log_entry(self):
        entry = {"type": "test", "message": "hello"}
        self.logger.log(entry)
        log_files = list(Path(self.temp_dir).glob("*.jsonl"))
        assert len(log_files) == 1
        with open(log_files[0]) as f:
            line = f.readline()
            data = json.loads(line)
            assert data["type"] == "test"
            assert data["message"] == "hello"

    def test_log_multiple_entries_same_day(self):
        self.logger.log({"type": "a", "count": 1})
        self.logger.log({"type": "b", "count": 2})
        log_files = list(Path(self.temp_dir).glob("*.jsonl"))
        with open(log_files[0]) as f:
            lines = f.readlines()
            assert len(lines) == 2


class TestSQLiteLogger:
    def setup_method(self):
        self.db_path = tempfile.mktemp(suffix=".db")
        self.logger = SQLiteLogger(db_path=self.db_path)

    def test_init_db_creates_tables(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [r[0] for r in cursor.fetchall()]
        conn.close()
        assert "llm_requests" in tables
        assert "user_actions" in tables
        assert "token_usage" in tables
        assert "projects" in tables

    def test_log_llm_request(self):
        req = LLMRequest(
            request_id="req_test_001",
            project_name="test_project",
            agent_name="test_agent",
            provider="openai",
            model="gpt-4",
            system_prompt="system",
            user_prompt="user",
            max_tokens=4000,
            temperature=0.7,
            input_tokens=1000,
            output_tokens=500,
            total_tokens=1500,
            cost_usd=0.06,
            latency_ms=1000,
            status=RequestStatus.SUCCESS,
        )
        self.logger.log_llm_request(req)
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM llm_requests WHERE request_id = ?", ("req_test_001",))
        count = cursor.fetchone()[0]
        conn.close()
        assert count == 1

    def test_log_user_action(self):
        action = UserAction(
            action_id="act_test_001",
            action_type=ActionType.API,
            user_command="POST /api/v1/projects",
            project_name="test_project",
            parameters={"name": "my novel"},
            result="Created",
            execution_time_ms=200,
            success=True,
        )
        self.logger.log_user_action(action)
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM user_actions WHERE action_id = ?", ("act_test_001",))
        count = cursor.fetchone()[0]
        conn.close()
        assert count == 1

    def test_log_project_event(self):
        self.logger.log_project_event("test_project", "created", {"genre": "fantasy"})
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM projects WHERE project_name = ?", ("test_project",))
        count = cursor.fetchone()[0]
        conn.close()
        assert count == 1

    def test_update_token_summary(self):
        req = LLMRequest(
            request_id="req_summary_001",
            project_name="test_project",
            agent_name="test_agent",
            provider="openai",
            model="gpt-4",
            system_prompt="",
            user_prompt="",
            max_tokens=1000,
            temperature=0.7,
            input_tokens=1000,
            output_tokens=500,
            total_tokens=1500,
            cost_usd=0.06,
            latency_ms=500,
            status=RequestStatus.SUCCESS,
        )
        self.logger.update_token_summary(req)
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM token_usage")
        count = cursor.fetchone()[0]
        conn.close()
        assert count >= 1


class TestNovelHarnessLogger:
    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()

    def test_init_default(self):
        logger = NovelHarnessLogger(storage_path=self.temp_dir)
        assert logger.enable_json_logs is True
        assert logger.enable_sqlite_logs is True
        assert logger.db_logger is not None
        assert logger.json_logger is not None
        assert logger.cost_calculator is not None

    def test_init_json_only(self):
        logger = NovelHarnessLogger(
            storage_path=self.temp_dir, enable_json_logs=True, enable_sqlite_logs=False
        )
        assert logger.db_logger is None
        assert logger.json_logger is not None

    def test_init_sqlite_only(self):
        logger = NovelHarnessLogger(
            storage_path=self.temp_dir, enable_json_logs=False, enable_sqlite_logs=True
        )
        assert logger.db_logger is not None
        assert logger.json_logger is None

    def test_init_both_disabled(self):
        logger = NovelHarnessLogger(
            storage_path=self.temp_dir, enable_json_logs=False, enable_sqlite_logs=False
        )
        assert logger.db_logger is None
        assert logger.json_logger is None

    def test_log_llm_request(self):
        logger = NovelHarnessLogger(
            storage_path=self.temp_dir, enable_json_logs=False, enable_sqlite_logs=True
        )
        request_id = logger.log_llm_request(
            provider="openai",
            model="gpt-4",
            input_tokens=1000,
            output_tokens=500,
            latency_ms=1000,
            project_name="test_project",
            agent_name="test_agent",
        )
        assert request_id.startswith("req_")
        assert logger.db_logger is not None

    def test_log_llm_request_with_error(self):
        logger = NovelHarnessLogger(
            storage_path=self.temp_dir, enable_json_logs=False, enable_sqlite_logs=True
        )
        request_id = logger.log_llm_request(
            provider="openai",
            model="gpt-4",
            input_tokens=1000,
            output_tokens=0,
            latency_ms=1000,
            error="Timeout",
        )
        assert request_id.startswith("req_")

    def test_log_llm_request_with_cache_hit(self):
        logger = NovelHarnessLogger(
            storage_path=self.temp_dir, enable_json_logs=False, enable_sqlite_logs=True
        )
        request_id = logger.log_llm_request(
            provider="openai",
            model="gpt-4",
            input_tokens=1000,
            output_tokens=500,
            latency_ms=100,
            cache_hit=True,
        )
        assert request_id.startswith("req_")

    def test_log_user_action(self):
        logger = NovelHarnessLogger(
            storage_path=self.temp_dir, enable_json_logs=False, enable_sqlite_logs=True
        )
        action_id = logger.log_user_action(
            action_type=ActionType.CLI,
            user_command="wst run --project mynovel",
            project_name="mynovel",
            parameters={"verbose": True},
            execution_time_ms=500,
            success=True,
        )
        assert action_id.startswith("act_")

    def test_log_project_created(self):
        logger = NovelHarnessLogger(
            storage_path=self.temp_dir, enable_json_logs=False, enable_sqlite_logs=True
        )
        logger.log_project_created("test_project", genre="fantasy", target_words=50000)
        conn = sqlite3.connect(logger.db_logger.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM projects WHERE project_name = ?", ("test_project",))
        count = cursor.fetchone()[0]
        conn.close()
        assert count >= 1

    def test_log_project_deleted(self):
        logger = NovelHarnessLogger(
            storage_path=self.temp_dir, enable_json_logs=False, enable_sqlite_logs=True
        )
        logger.log_project_created("proj_del", genre="sci-fi", target_words=30000)
        logger.log_project_deleted("proj_del")
        conn = sqlite3.connect(logger.db_logger.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM projects WHERE project_name = ?", ("proj_del",))
        count = cursor.fetchone()[0]
        conn.close()
        assert count == 2

    def test_request_to_json(self):
        logger = NovelHarnessLogger(storage_path=self.temp_dir, enable_sqlite_logs=False)
        req = LLMRequest(
            request_id="req_json",
            project_name="test_project",
            agent_name="test_agent",
            provider="openai",
            model="gpt-4",
            system_prompt="You are helpful",
            user_prompt="Hello world",
            max_tokens=4000,
            temperature=0.7,
            input_tokens=1000,
            output_tokens=500,
            total_tokens=1500,
            cost_usd=0.06,
            latency_ms=1000,
            status=RequestStatus.SUCCESS,
        )
        data = logger._request_to_json(req)
        assert data["type"] == LogType.LLM_REQUEST.value
        assert data["request_id"] == "req_json"
        assert data["provider"] == "openai"
        assert data["usage"]["total_tokens"] == 1500

    def test_action_to_json(self):
        logger = NovelHarnessLogger(storage_path=self.temp_dir, enable_sqlite_logs=False)
        action = UserAction(
            action_id="act_json",
            action_type=ActionType.API,
            user_command="POST /api",
            project_name="test_project",
            parameters={},
            result="OK",
            execution_time_ms=100,
            success=True,
        )
        data = logger._action_to_json(action)
        assert data["type"] == LogType.USER_ACTION.value
        assert data["action_id"] == "act_json"
        assert data["action_type"] == "API"

    def test_get_stats(self):
        logger = NovelHarnessLogger(
            storage_path=self.temp_dir, enable_json_logs=False, enable_sqlite_logs=True
        )
        logger.log_llm_request(
            provider="openai",
            model="gpt-4",
            input_tokens=1000,
            output_tokens=500,
            latency_ms=1000,
            error="test error",
        )
        stats = logger.get_stats()
        assert "total_requests" in stats
        assert "total_tokens" in stats
        assert "total_cost_usd" in stats
        assert "error_count" in stats

    def test_get_stats_no_db(self):
        logger = NovelHarnessLogger(
            storage_path=self.temp_dir, enable_json_logs=False, enable_sqlite_logs=False
        )
        stats = logger.get_stats()
        assert "error" in stats

    def test_singleton_instance(self):
        NovelHarnessLogger._instance = None
        instance1 = NovelHarnessLogger.get_instance()
        instance2 = NovelHarnessLogger.get_instance()
        assert instance1 is instance2
        NovelHarnessLogger._instance = None


class TestConvenienceFunctions:
    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        NovelHarnessLogger._instance = None

    def test_log_llm_request_convenience(self):
        request_id = log_llm_request(
            provider="openai",
            model="gpt-4",
            input_tokens=1000,
            output_tokens=500,
            latency_ms=1000,
        )
        assert request_id.startswith("req_")
        NovelHarnessLogger._instance = None

    def test_log_user_action_convenience(self):
        action_id = log_user_action(
            action_type=ActionType.CLI,
            user_command="test command",
            success=True,
        )
        assert action_id.startswith("act_")
        NovelHarnessLogger._instance = None


class TestEnums:
    def test_log_type_values(self):
        assert LogType.LLM_REQUEST.value == "llm_request"
        assert LogType.USER_ACTION.value == "user_action"
        assert LogType.SYSTEM_EVENT.value == "system_event"
        assert LogType.PROJECT_EVENT.value == "project_event"

    def test_action_type_values(self):
        assert ActionType.CLI.value == "CLI"
        assert ActionType.API.value == "API"
        assert ActionType.WEB.value == "WEB"

    def test_request_status_values(self):
        assert RequestStatus.SUCCESS.value == "success"
        assert RequestStatus.ERROR.value == "error"
        assert RequestStatus.TIMEOUT.value == "timeout"
        assert RequestStatus.CANCELLED.value == "cancelled"


class TestLoggerMissingCoverage:
    """Tests for missing coverage in logger.py."""

    def test_json_logger_rotate_old_logs(self, tmp_path):
        """Test JSONLogger.rotate_old_logs compresses old files (lines 118-127)."""

        log_dir = tmp_path / "json"
        log_dir.mkdir()
        logger = JSONLogger(str(log_dir))

        old_file = log_dir / "2020-01-01.jsonl"
        old_file.write_text('{"test": "old"}\n')

        import os
        import time

        old_time = time.time() - (100 * 86400)
        os.utime(old_file, (old_time, old_time))

        logger.rotate_old_logs(days=90)
        assert not old_file.exists()
        compressed = log_dir / "2020-01-01.jsonl.gz"
        assert compressed.exists()

    def test_novel_harness_logger_disabled(self, tmp_path):
        """Test NovelHarnessLogger with json/sqlite disabled."""
        logger = NovelHarnessLogger(
            storage_path=str(tmp_path),
            enable_json_logs=False,
            enable_sqlite_logs=False,
        )
        assert logger.json_logger is None
        assert logger.db_logger is None
        assert logger.token_tracker is None

        request_id = logger.log_llm_request(
            provider="openai",
            model="gpt-4",
            input_tokens=100,
            output_tokens=50,
            latency_ms=100,
        )
        assert request_id.startswith("req_")

        action_id = logger.log_user_action(
            action_type=ActionType.CLI,
            user_command="test",
        )
        assert action_id.startswith("act_")

        logger.log_project_created("test_proj", "fantasy", 50000)
        logger.log_project_deleted("test_proj")

    def test_get_stats_no_db_logger(self, tmp_path):
        """Test get_stats when db_logger disabled (line 543→exit)."""
        logger = NovelHarnessLogger(
            storage_path=str(tmp_path),
            enable_sqlite_logs=False,
        )
        stats = logger.get_stats()
        assert "error" in stats

    def test_log_llm_request_with_error_status(self, tmp_path):
        """Test log_llm_request with error parameter (lines 483→488)."""
        logger = NovelHarnessLogger(storage_path=str(tmp_path))
        request_id = logger.log_llm_request(
            provider="openai",
            model="gpt-4",
            input_tokens=100,
            output_tokens=50,
            latency_ms=100,
            error="Something went wrong",
        )
        assert request_id.startswith("req_")
