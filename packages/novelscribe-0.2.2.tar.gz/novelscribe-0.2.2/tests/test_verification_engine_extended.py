"""
Comprehensive tests for verification_engine.py to increase coverage to 90%+.
Tests verification engine and report generation.
"""

from datetime import datetime
from pathlib import Path
from unittest.mock import Mock, patch

import pytest

from novel_harness.core.continuity_parser import ContinuityReport, ReportStatus
from novel_harness.core.verification_engine import (
    VerificationConfig,
    VerificationEngine,
    VerificationResult,
)


class TestVerificationConfig:
    """Test VerificationConfig model."""

    def test_default_config(self):
        """Test default configuration."""
        config = VerificationConfig()

        assert config.max_iterations == 5
        assert config.stop_on_pass is True
        assert config.stop_on_critical_only is True
        assert config.allow_major_issues is False
        assert config.allow_minor_issues is True
        assert config.max_minor_issues == 10
        assert config.batch_size == 10
        assert config.generate_report is True
        assert config.save_iteration_log is True

    def test_custom_config(self):
        """Test custom configuration."""
        config = VerificationConfig(
            max_iterations=10,
            stop_on_pass=False,
            generate_report=False,
        )

        assert config.max_iterations == 10
        assert config.stop_on_pass is False
        assert config.generate_report is False


class TestVerificationEngine:
    """Test VerificationEngine class."""

    @patch("novel_harness.core.verification_engine.ContinuityParser")
    @patch("novel_harness.core.verification_engine.FixPlanGenerator")
    def test_init(self, mock_plan_gen, mock_parser):
        """Test initialization."""
        mock_parser.return_value = Mock()
        mock_plan_gen.return_value = Mock()

        engine = VerificationEngine("/path/to/project", VerificationConfig())

        assert engine.project_dir == Path("/path/to/project")
        assert engine.config is not None

    @patch("novel_harness.core.verification_engine.ContinuityParser")
    @patch("novel_harness.core.verification_engine.FixPlanGenerator")
    def test_verify_chapter_not_found(self, mock_plan_gen, mock_parser):
        """Test verifying chapter that doesn't exist."""
        mock_parser.return_value = Mock()
        mock_plan_gen.return_value = Mock()

        engine = VerificationEngine("/path/to/project", VerificationConfig())

        with pytest.raises(FileNotFoundError):
            engine.verify_chapter(999)

    @patch("novel_harness.core.verification_engine.ContinuityParser")
    @patch("novel_harness.core.verification_engine.FixPlanGenerator")
    def test_quick_verify(self, mock_plan_gen, mock_parser):
        """Test quick verification."""
        mock_report = Mock(spec=ContinuityReport)
        mock_parser.return_value.parse_report.return_value = mock_report

        engine = VerificationEngine("/path/to/project", VerificationConfig())

        result = engine.quick_verify()

        assert result == mock_report

    @patch("novel_harness.core.verification_engine.ContinuityParser")
    @patch("novel_harness.core.verification_engine.FixPlanGenerator")
    def test_quick_verify_no_report(self, mock_plan_gen, mock_parser):
        """Test quick verification with no report."""
        mock_parser.return_value.parse_report.side_effect = FileNotFoundError()

        engine = VerificationEngine("/path/to/project", VerificationConfig())

        with pytest.raises(RuntimeError, match="No continuity report found"):
            engine.quick_verify()

    @patch("novel_harness.core.verification_engine.ContinuityParser")
    @patch("novel_harness.core.verification_engine.FixPlanGenerator")
    def test_get_fix_plan(self, mock_plan_gen, mock_parser):
        """Test getting fix plan."""
        mock_report = Mock(spec=ContinuityReport)
        mock_parser.return_value.parse_report.return_value = mock_report

        mock_plan = Mock()
        mock_plan_gen.return_value.generate_fix_plan.return_value = mock_plan

        engine = VerificationEngine("/path/to/project", VerificationConfig())

        plan = engine.get_fix_plan()

        assert plan is not None

    @patch("novel_harness.core.verification_engine.ContinuityParser")
    @patch("novel_harness.core.verification_engine.FixPlanGenerator")
    def test_get_fix_plan_no_report(self, mock_plan_gen, mock_parser):
        """Test getting fix plan with no report."""
        mock_parser.return_value.parse_report.side_effect = FileNotFoundError()

        engine = VerificationEngine("/path/to/project", VerificationConfig())

        plan = engine.get_fix_plan()

        assert plan is None

    @patch("novel_harness.core.verification_engine.ContinuityParser")
    @patch("novel_harness.core.verification_engine.FixPlanGenerator")
    def test_save_fix_plan(self, mock_plan_gen, mock_parser):
        """Test saving fix plan."""
        mock_report = Mock(spec=ContinuityReport)
        mock_parser.return_value.parse_report.return_value = mock_report

        mock_plan = Mock()
        mock_plan_gen.return_value.generate_fix_plan.return_value = mock_plan

        engine = VerificationEngine("/path/to/project", VerificationConfig())

        result = engine.save_fix_plan("/output/path.md")

        assert result == "/output/path.md"

    @patch("novel_harness.core.verification_engine.ContinuityParser")
    @patch("novel_harness.core.verification_engine.FixPlanGenerator")
    def test_save_fix_plan_no_plan(self, mock_plan_gen, mock_parser):
        """Test saving fix plan with no plan available."""
        mock_parser.return_value.parse_report.side_effect = FileNotFoundError()

        engine = VerificationEngine("/path/to/project", VerificationConfig())

        with pytest.raises(RuntimeError, match="Cannot generate fix plan"):
            engine.save_fix_plan()

    @patch("novel_harness.core.verification_engine.ContinuityParser")
    @patch("novel_harness.core.verification_engine.FixPlanGenerator")
    def test_get_progress_estimate_with_report(self, mock_plan_gen, mock_parser):
        """Test getting progress estimate with report."""
        mock_report = Mock(spec=ContinuityReport)
        mock_report.total_issues = 5
        mock_report.critical_count = 2
        mock_report.major_count = 2
        mock_report.minor_count = 1
        mock_report.status = ReportStatus.FAIL
        mock_parser.return_value.parse_report.return_value = mock_report

        mock_plan = Mock()
        mock_plan.estimated_iterations = 3
        mock_plan.total_fixes = 5
        mock_plan.critical_fixes = 2
        mock_plan.major_fixes = 2
        mock_plan.minor_fixes = 1
        mock_plan_gen.return_value.generate_fix_plan.return_value = mock_plan

        engine = VerificationEngine("/path/to/project", VerificationConfig())

        estimate = engine.get_progress_estimate()

        assert "5" in estimate

    @patch("novel_harness.core.verification_engine.ContinuityParser")
    @patch("novel_harness.core.verification_engine.FixPlanGenerator")
    def test_get_progress_estimate_passing(self, mock_plan_gen, mock_parser):
        """Test getting progress estimate when already passing."""
        mock_report = Mock(spec=ContinuityReport)
        mock_report.total_issues = 0
        mock_report.critical_count = 0
        mock_report.major_count = 0
        mock_report.minor_count = 0
        mock_report.status = ReportStatus.PASS
        mock_parser.return_value.parse_report.return_value = mock_report

        engine = VerificationEngine("/path/to/project", VerificationConfig())

        estimate = engine.get_progress_estimate()

        assert "meets quality standards" in estimate

    @patch("novel_harness.core.verification_engine.ContinuityParser")
    @patch("novel_harness.core.verification_engine.FixPlanGenerator")
    def test_get_progress_estimate_no_data(self, mock_plan_gen, mock_parser):
        """Test getting progress estimate with no data."""
        mock_parser.return_value.parse_report.side_effect = FileNotFoundError()

        engine = VerificationEngine("/path/to/project", VerificationConfig())

        estimate = engine.get_progress_estimate()

        assert "No verification data available" in estimate


class TestVerificationResult:
    """Test VerificationResult model."""

    def test_verification_result_creation(self):
        """Test creating verification result."""
        result = VerificationResult(
            project_name="test_project",
            passed=True,
            total_iterations=3,
            final_status=ReportStatus.PASS,
            issues_remaining=0,
            critical_issues=0,
            major_issues=0,
            minor_issues=0,
            iterations=[],
            total_execution_time=10.5,
            verification_timestamp=datetime.now(),
        )

        assert result.project_name == "test_project"
        assert result.passed is True
        assert result.total_iterations == 3
        assert result.final_status == ReportStatus.PASS

    def test_verification_result_failed(self):
        """Test creating failed verification result."""
        result = VerificationResult(
            project_name="test_project",
            passed=False,
            total_iterations=5,
            final_status=ReportStatus.FAIL,
            issues_remaining=10,
            critical_issues=3,
            major_issues=5,
            minor_issues=2,
            iterations=[],
            total_execution_time=30.0,
            verification_timestamp=datetime.now(),
        )

        assert result.passed is False
        assert result.issues_remaining == 10
        assert result.critical_issues == 3
