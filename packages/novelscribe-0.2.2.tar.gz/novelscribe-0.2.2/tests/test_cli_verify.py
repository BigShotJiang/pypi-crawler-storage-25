"""
Tests for CLI verification commands
"""

from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from cli_verify import verify


class TestVerifyGroup:
    """Test cases for verify command group"""

    def test_verify_group_exists(self):
        """Test that verify command group exists"""
        assert verify is not None

    def test_verify_help(self):
        """Test verify command help"""
        runner = CliRunner()
        result = runner.invoke(verify, ["--help"])

        assert result.exit_code == 0
        assert "verify" in result.output.lower()

    def test_verify_start_command_exists(self):
        """Test that start subcommand exists"""
        runner = CliRunner()
        result = runner.invoke(verify, ["start", "--help"])

        assert result.exit_code == 0
        assert "start" in result.output.lower()

    def test_verify_report_command_exists(self):
        """Test that report subcommand exists"""
        runner = CliRunner()
        result = runner.invoke(verify, ["report", "--help"])

        assert result.exit_code == 0
        assert "report" in result.output.lower()

    def test_verify_fix_plan_command_exists(self):
        """Test that fix-plan subcommand exists"""
        runner = CliRunner()
        result = runner.invoke(verify, ["fix-plan", "--help"])

        assert result.exit_code == 0
        assert "fix-plan" in result.output.lower()

    def test_verify_estimate_command_exists(self):
        """Test that estimate subcommand exists"""
        runner = CliRunner()
        result = runner.invoke(verify, ["estimate", "--help"])

        assert result.exit_code == 0
        assert "estimate" in result.output.lower()


class TestStartVerification:
    """Test cases for start_verification command"""

    def test_start_missing_project_name(self):
        """Test start command without project name"""
        runner = CliRunner()
        result = runner.invoke(verify, ["start"])

        assert result.exit_code != 0

    def test_start_project_not_found(self):
        """Test start command with non-existent project"""
        runner = CliRunner()
        with patch("cli_verify.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = False
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(verify, ["start", "nonexistent-project"], obj={"debug": False})

            assert result.exit_code == 1

    def test_start_chapter_not_found(self):
        """Test start command with non-existent chapter"""
        runner = CliRunner()
        with patch("cli_verify.Path") as mock_path:
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_chapter_path = MagicMock()
            mock_chapter_path.exists.return_value = False

            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_chapter_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(
                verify, ["start", "test-project", "--chapter", "1"], obj={"debug": False}
            )

            assert result.exit_code == 1

    def test_start_with_default_options(self):
        """Test start command with default options"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_result = MagicMock()
            mock_result.passed = True
            mock_result.total_iterations = 3
            mock_result.issues_remaining = 0
            mock_result.total_execution_time = 10.5
            mock_engine.verify_project.return_value = mock_result
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(verify, ["start", "test-project"], obj={"debug": False})

            assert result.exit_code in [0, 1]

    def test_start_with_chapter_option(self):
        """Test start command with chapter option"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_chapter_path = MagicMock()
            mock_chapter_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_chapter_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_result = MagicMock()
            mock_result.passed = True
            mock_result.total_iterations = 2
            mock_result.issues_remaining = 1
            mock_result.total_execution_time = 5.0
            mock_engine.verify_project.return_value = mock_result
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(
                verify, ["start", "test-project", "--chapter", "5"], obj={"debug": False}
            )

            assert result.exit_code in [0, 1]

    def test_start_with_max_iterations(self):
        """Test start command with max_iterations option"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_result = MagicMock()
            mock_result.passed = True
            mock_result.total_iterations = 7
            mock_result.issues_remaining = 0
            mock_result.total_execution_time = 15.0
            mock_engine.verify_project.return_value = mock_result
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(
                verify, ["start", "test-project", "--max-iterations", "10"], obj={"debug": False}
            )

            assert result.exit_code in [0, 1]

    def test_start_with_allow_major(self):
        """Test start command with allow_major option"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_result = MagicMock()
            mock_result.passed = True
            mock_result.total_iterations = 3
            mock_result.issues_remaining = 5
            mock_result.total_execution_time = 12.0
            mock_engine.verify_project.return_value = mock_result
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(
                verify, ["start", "test-project", "--allow-major"], obj={"debug": False}
            )

            assert result.exit_code in [0, 1]

    def test_start_with_allow_minor(self):
        """Test start command with allow_minor option"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_result = MagicMock()
            mock_result.passed = True
            mock_result.total_iterations = 2
            mock_result.issues_remaining = 8
            mock_result.total_execution_time = 8.0
            mock_engine.verify_project.return_value = mock_result
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(
                verify, ["start", "test-project", "--allow-minor"], obj={"debug": False}
            )

            assert result.exit_code in [0, 1]

    def test_start_with_stop_on_critical(self):
        """Test start command with stop_on_critical option"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_result = MagicMock()
            mock_result.passed = True
            mock_result.total_iterations = 4
            mock_result.issues_remaining = 2
            mock_result.total_execution_time = 9.0
            mock_engine.verify_project.return_value = mock_result
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(
                verify, ["start", "test-project", "--stop-on-critical"], obj={"debug": False}
            )

            assert result.exit_code in [0, 1]

    def test_start_with_max_minor(self):
        """Test start command with max_minor option"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_result = MagicMock()
            mock_result.passed = True
            mock_result.total_iterations = 3
            mock_result.issues_remaining = 7
            mock_result.total_execution_time = 11.0
            mock_engine.verify_project.return_value = mock_result
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(
                verify, ["start", "test-project", "--max-minor", "15"], obj={"debug": False}
            )

            assert result.exit_code in [0, 1]

    def test_start_with_batch_size(self):
        """Test start command with batch_size option"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_result = MagicMock()
            mock_result.passed = True
            mock_result.total_iterations = 5
            mock_result.issues_remaining = 3
            mock_result.total_execution_time = 14.0
            mock_engine.verify_project.return_value = mock_result
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(
                verify, ["start", "test-project", "--batch-size", "20"], obj={"debug": False}
            )

            assert result.exit_code in [0, 1]

    def test_start_with_project_dir(self):
        """Test start command with project_dir option"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_result = MagicMock()
            mock_result.passed = True
            mock_result.total_iterations = 3
            mock_result.issues_remaining = 0
            mock_result.total_execution_time = 10.0
            mock_engine.verify_project.return_value = mock_result
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(
                verify,
                ["start", "test-project", "--project-dir", "/custom/path"],
                obj={"debug": False},
            )

            assert result.exit_code in [0, 1]

    def test_start_report_only(self):
        """Test start command with report_only option"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_report = MagicMock()
            mock_report.status.value = "passed"
            mock_report.total_issues = 5
            mock_report.critical_count = 0
            mock_report.major_count = 2
            mock_report.minor_count = 3
            mock_engine.quick_verify.return_value = mock_report
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(
                verify, ["start", "test-project", "--report-only"], obj={"debug": False}
            )

            assert result.exit_code in [0, 1]

    def test_start_no_report(self):
        """Test start command with no_report option"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_result = MagicMock()
            mock_result.passed = True
            mock_result.total_iterations = 3
            mock_result.issues_remaining = 4
            mock_result.total_execution_time = 11.0
            mock_engine.verify_project.return_value = mock_result
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(
                verify, ["start", "test-project", "--no-report"], obj={"debug": False}
            )

            assert result.exit_code in [0, 1]

    def test_start_verification_failed(self):
        """Test start command when verification fails"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_result = MagicMock()
            mock_result.passed = False
            mock_result.final_status.value = "failed"
            mock_result.issues_remaining = 10
            mock_result.critical_issues = 2
            mock_result.major_issues = 3
            mock_result.minor_issues = 5
            mock_result.total_iterations = 5
            mock_engine.verify_project.return_value = mock_result
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(verify, ["start", "test-project"], obj={"debug": False})

            assert result.exit_code in [0, 1]

    def test_start_with_exception(self):
        """Test start command with exception"""
        runner = CliRunner()

        with patch("cli_verify.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.side_effect = Exception("Test error")
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(verify, ["start", "test-project"], obj={"debug": False})

            assert result.exit_code == 1

    def test_start_with_all_options(self):
        """Test start command with all options"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_chapter_path = MagicMock()
            mock_chapter_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = True
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_chapter_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_result = MagicMock()
            mock_result.passed = True
            mock_result.total_iterations = 6
            mock_result.issues_remaining = 1
            mock_result.total_execution_time = 18.0
            mock_engine.verify_project.return_value = mock_result
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(
                verify,
                [
                    "start",
                    "test-project",
                    "--chapter",
                    "3",
                    "--max-iterations",
                    "8",
                    "--allow-major",
                    "--allow-minor",
                    "--stop-on-critical",
                    "--max-minor",
                    "20",
                    "--batch-size",
                    "15",
                    "--project-dir",
                    "/test",
                ],
                obj={"debug": False},
            )

            assert result.exit_code in [0, 1]


class TestGenerateReport:
    """Test cases for generate_report command"""

    def test_report_missing_project_name(self):
        """Test report command without project name"""
        runner = CliRunner()
        result = runner.invoke(verify, ["report"])

        assert result.exit_code != 0

    def test_report_success(self):
        """Test report command success"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.ContinuityParser") as mock_parser_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_parser = MagicMock()
            mock_report = MagicMock()
            mock_report.status.value = "passed"
            mock_report.total_issues = 8
            mock_report.critical_count = 1
            mock_report.major_count = 2
            mock_report.minor_count = 5
            mock_report.issues = []
            mock_parser.parse_report.return_value = mock_report
            mock_parser_class.return_value = mock_parser

            result = runner.invoke(verify, ["report", "test-project"])

            assert result.exit_code == 0

    def test_report_with_chapter(self):
        """Test report command with chapter option"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.ContinuityParser") as mock_parser_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_parser = MagicMock()
            mock_report = MagicMock()
            mock_report.status.value = "failed"
            mock_report.total_issues = 12
            mock_report.critical_count = 3
            mock_report.major_count = 4
            mock_report.minor_count = 5
            mock_report.issues = []
            mock_parser.parse_report.return_value = mock_report
            mock_parser_class.return_value = mock_parser

            result = runner.invoke(verify, ["report", "test-project", "--chapter", "2"])

            assert result.exit_code == 0

    def test_report_with_project_dir(self):
        """Test report command with project_dir option"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.ContinuityParser") as mock_parser_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_parser = MagicMock()
            mock_report = MagicMock()
            mock_report.status.value = "passed"
            mock_report.total_issues = 0
            mock_report.critical_count = 0
            mock_report.major_count = 0
            mock_report.minor_count = 0
            mock_report.issues = []
            mock_parser.parse_report.return_value = mock_report
            mock_parser_class.return_value = mock_parser

            result = runner.invoke(verify, ["report", "test-project", "--project-dir", "/custom"])

            assert result.exit_code == 0

    def test_report_with_issues(self):
        """Test report command displaying issues"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.ContinuityParser") as mock_parser_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_issue = MagicMock()
            mock_issue.severity.value = "critical"
            mock_issue.issue_type.value = "continuity"
            mock_issue.description = "Test issue"
            mock_issue.location = "Chapter 1"
            mock_issue.suggestion = "Fix this"

            mock_parser = MagicMock()
            mock_report = MagicMock()
            mock_report.status.value = "failed"
            mock_report.total_issues = 1
            mock_report.critical_count = 1
            mock_report.major_count = 0
            mock_report.minor_count = 0
            mock_report.issues = [mock_issue]
            mock_parser.parse_report.return_value = mock_report
            mock_parser_class.return_value = mock_parser

            result = runner.invoke(verify, ["report", "test-project"])

            assert result.exit_code == 0

    def test_report_save_without_output(self):
        """Test report command with save option without output path"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.ContinuityParser") as mock_parser_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_parser = MagicMock()
            mock_report = MagicMock()
            mock_report.status.value = "passed"
            mock_report.total_issues = 3
            mock_report.critical_count = 0
            mock_report.major_count = 1
            mock_report.minor_count = 2
            mock_report.issues = []
            mock_parser.parse_report.return_value = mock_report
            mock_parser.save_report.return_value = "/test/continuity_report.md"
            mock_parser_class.return_value = mock_parser

            result = runner.invoke(verify, ["report", "test-project", "--save"])

            assert result.exit_code == 0

    def test_report_save_with_output(self):
        """Test report command with save and output options"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.ContinuityParser") as mock_parser_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_parser = MagicMock()
            mock_report = MagicMock()
            mock_report.status.value = "passed"
            mock_report.total_issues = 0
            mock_report.critical_count = 0
            mock_report.major_count = 0
            mock_report.minor_count = 0
            mock_report.issues = []
            mock_parser.parse_report.return_value = mock_report
            mock_parser.save_report.return_value = "/custom/report.md"
            mock_parser_class.return_value = mock_parser

            result = runner.invoke(
                verify, ["report", "test-project", "--save", "--output", "/custom/report.md"]
            )

            assert result.exit_code == 0

    def test_report_file_not_found(self):
        """Test report command when file not found"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.ContinuityParser") as mock_parser_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_parser = MagicMock()
            mock_parser.parse_report.side_effect = FileNotFoundError("Report not found")
            mock_parser_class.return_value = mock_parser

            result = runner.invoke(verify, ["report", "test-project"])

            assert result.exit_code == 1

    def test_report_exception(self):
        """Test report command with exception"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.ContinuityParser") as mock_parser_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_parser = MagicMock()
            mock_parser.parse_report.side_effect = Exception("Parse error")
            mock_parser_class.return_value = mock_parser

            result = runner.invoke(verify, ["report", "test-project"])

            assert result.exit_code == 1


class TestCreateFixPlan:
    """Test cases for create_fix_plan command"""

    def test_fix_plan_missing_project_name(self):
        """Test fix-plan command without project name"""
        runner = CliRunner()
        result = runner.invoke(verify, ["fix-plan"])

        assert result.exit_code != 0

    def test_fix_plan_success(self):
        """Test fix-plan command success"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_fix_plan = MagicMock()
            mock_fix_plan.total_fixes = 10
            mock_fix_plan.critical_fixes = 2
            mock_fix_plan.major_fixes = 3
            mock_fix_plan.minor_fixes = 5
            mock_fix_plan.estimated_iterations = 3
            mock_fix_plan.instructions = []
            mock_engine.get_fix_plan.return_value = mock_fix_plan
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(verify, ["fix-plan", "test-project"])

            assert result.exit_code == 0

    def test_fix_plan_with_chapter(self):
        """Test fix-plan command with chapter option"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_fix_plan = MagicMock()
            mock_fix_plan.total_fixes = 5
            mock_fix_plan.critical_fixes = 1
            mock_fix_plan.major_fixes = 2
            mock_fix_plan.minor_fixes = 2
            mock_fix_plan.estimated_iterations = 2
            mock_fix_plan.instructions = []
            mock_engine.get_fix_plan.return_value = mock_fix_plan
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(verify, ["fix-plan", "test-project", "--chapter", "4"])

            assert result.exit_code == 0

    def test_fix_plan_with_project_dir(self):
        """Test fix-plan command with project_dir option"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_fix_plan = MagicMock()
            mock_fix_plan.total_fixes = 7
            mock_fix_plan.critical_fixes = 0
            mock_fix_plan.major_fixes = 4
            mock_fix_plan.minor_fixes = 3
            mock_fix_plan.estimated_iterations = 2
            mock_fix_plan.instructions = []
            mock_engine.get_fix_plan.return_value = mock_fix_plan
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(verify, ["fix-plan", "test-project", "--project-dir", "/test"])

            assert result.exit_code == 0

    def test_fix_plan_show_details(self):
        """Test fix-plan command with show_details option"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_instruction = MagicMock()
            mock_instruction.issue_id = "ISSUE-001"
            mock_instruction.priority = 1
            mock_instruction.agent.value = "editor"
            mock_instruction.severity.value = "major"
            mock_instruction.issue_type.value = "grammar"
            mock_instruction.instructions = "Fix the grammar issue in this sentence"

            mock_engine = MagicMock()
            mock_fix_plan = MagicMock()
            mock_fix_plan.total_fixes = 1
            mock_fix_plan.critical_fixes = 0
            mock_fix_plan.major_fixes = 1
            mock_fix_plan.minor_fixes = 0
            mock_fix_plan.estimated_iterations = 1
            mock_fix_plan.instructions = [mock_instruction]
            mock_engine.get_fix_plan.return_value = mock_fix_plan
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(verify, ["fix-plan", "test-project", "--show-details"])

            assert result.exit_code == 0

    def test_fix_plan_save_without_output(self):
        """Test fix-plan command with save option without output path"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_fix_plan = MagicMock()
            mock_fix_plan.total_fixes = 8
            mock_fix_plan.critical_fixes = 1
            mock_fix_plan.major_fixes = 2
            mock_fix_plan.minor_fixes = 5
            mock_fix_plan.estimated_iterations = 3
            mock_fix_plan.instructions = []
            mock_engine.get_fix_plan.return_value = mock_fix_plan
            mock_engine.save_fix_plan.return_value = "/test/fix_plan.md"
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(verify, ["fix-plan", "test-project", "--save"])

            assert result.exit_code == 0

    def test_fix_plan_save_with_output(self):
        """Test fix-plan command with save and output options"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_fix_plan = MagicMock()
            mock_fix_plan.total_fixes = 3
            mock_fix_plan.critical_fixes = 0
            mock_fix_plan.major_fixes = 1
            mock_fix_plan.minor_fixes = 2
            mock_fix_plan.estimated_iterations = 1
            mock_fix_plan.instructions = []
            mock_engine.get_fix_plan.return_value = mock_fix_plan
            mock_engine.save_fix_plan.return_value = "/custom/fix_plan.md"
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(
                verify,
                ["fix-plan", "test-project", "--save", "--output", "/custom/fix_plan.md"],
            )

            assert result.exit_code == 0

    def test_fix_plan_no_report_found(self):
        """Test fix-plan command when no report found"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_engine.get_fix_plan.return_value = None
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(verify, ["fix-plan", "test-project"])

            assert result.exit_code == 1

    def test_fix_plan_exception(self):
        """Test fix-plan command with exception"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_engine.get_fix_plan.side_effect = Exception("Engine error")
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(verify, ["fix-plan", "test-project"])

            assert result.exit_code == 1


class TestGetEstimate:
    """Test cases for get_estimate command"""

    def test_estimate_missing_project_name(self):
        """Test estimate command without project name"""
        runner = CliRunner()
        result = runner.invoke(verify, ["estimate"])

        assert result.exit_code != 0

    def test_estimate_success(self):
        """Test estimate command success"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_engine.get_progress_estimate.return_value = "Estimated time: 30 minutes"
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(verify, ["estimate", "test-project"])

            assert result.exit_code == 0

    def test_estimate_with_chapter(self):
        """Test estimate command with chapter option"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_engine.get_progress_estimate.return_value = (
                "Estimated time for chapter 5: 10 minutes"
            )
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(verify, ["estimate", "test-project", "--chapter", "5"])

            assert result.exit_code == 0

    def test_estimate_with_project_dir(self):
        """Test estimate command with project_dir option"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_engine.get_progress_estimate.return_value = "Estimated time: 45 minutes"
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(verify, ["estimate", "test-project", "--project-dir", "/custom"])

            assert result.exit_code == 0

    def test_estimate_exception(self):
        """Test estimate command with exception"""
        runner = CliRunner()

        with (
            patch("cli_verify.Path") as mock_path,
            patch("cli_verify.VerificationEngine") as mock_engine_class,
        ):
            mock_path_instance = MagicMock()
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_engine = MagicMock()
            mock_engine.get_progress_estimate.side_effect = Exception("Estimate error")
            mock_engine_class.return_value = mock_engine

            result = runner.invoke(verify, ["estimate", "test-project"])

            assert result.exit_code == 1
