"""Additional coverage tests for llm_optimizer.py to reach 95%+ coverage."""

import time
from unittest.mock import Mock, patch

from core.llm_optimizer import (
    CacheEntry,
    CachePolicy,
    LLMOptimizer,
    LLMOptimizerStats,
    RateLimiter,
)


class TestCacheEntryCoverage:
    """Test CacheEdge case for coverage."""

    def test_cache_entry_post_init_none_response(self):
        """Test CacheEntry __post_init__ with None response."""
        entry = CacheEntry(
            value="test_value",
            created_at=time.time(),
            model="gpt-4",
            policy=CachePolicy.SHORT,
        )
        assert entry.response == "test_value"


class TestRateLimiterCoverage:
    """Test RateLimiter edge cases for coverage."""

    def test_rate_limiter_refill_after_minute(self):
        """Test token refill after a minute passes."""
        limiter = RateLimiter(requests_per_minute=60)
        # Exhaust tokens
        for _ in range(60):
            assert limiter.acquire(1) is True

        # Should be exhausted
        assert limiter.acquire(1) is False

        # Mock time passage
        with patch("time.time", return_value=limiter._last_refill + 61):
            limiter._refill_tokens()
            assert limiter._tokens == 60  # Should have refilled

    def test_rate_limiter_get_available_tokens(self):
        """Test get_available_tokens returns correct count."""
        limiter = RateLimiter(requests_per_minute=60)
        limiter.acquire(30)
        assert limiter.get_available_tokens() == 30


class TestLLMOptimizerCoverage:
    """Test LLMOptimizer edge cases for coverage."""

    def setup_method(self):
        """Set up test fixtures."""
        self.optimizer = LLMOptimizer()

    def test_hash_prompt_deterministic(self):
        """Test that hash_prompt produces consistent results."""
        prompt = "Test prompt"
        model = "gpt-4"

        hash1 = self.optimizer._hash_prompt(prompt, model)
        hash2 = self.optimizer._hash_prompt(prompt, model)

        assert hash1 == hash2
        assert len(hash1) == 64  # SHA256 hex digest length

    def test_estimate_tokens_different_models(self):
        """Test token estimation for different models."""
        text = "This is a test prompt with several words"

        # Default model
        tokens_default = self.optimizer._estimate_tokens(text)
        assert tokens_default > 0

        # Different model (same implementation for now)
        tokens_custom = self.optimizer._estimate_tokens(text, model="gpt-3.5-turbo")
        assert tokens_custom > 0

    def test_estimate_cost_unknown_model(self):
        """Test cost estimation with unknown model returns default."""
        # Unknown model should use default pricing
        cost = self.optimizer._estimate_cost("unknown-model", 1000, 500)
        # Should return a cost value using default gpt-4 pricing
        assert cost > 0.0

    def test_compress_prompt_removes_duplicate_lines(self):
        """Test prompt compression removes consecutive duplicate lines."""
        prompt = """Line 1
Line 2
Line 2
Line 2
Line 3
Line 1
Line 4"""
        compressed = self.optimizer._compress_prompt(prompt)

        lines = compressed.split("\n")
        # No consecutive duplicates
        for i in range(len(lines) - 1):
            assert lines[i] != lines[i + 1]

    def test_add_to_cache_eviction(self):
        """Test cache eviction when cache_size is exceeded."""
        optimizer = LLMOptimizer(cache_size=2)

        optimizer._add_to_cache("key1", "value1")
        optimizer._add_to_cache("key2", "value2")
        optimizer._add_to_cache("key3", "value3")  # Should evict oldest

        assert len(optimizer._cache) == 2
        assert "key1" not in optimizer._cache
        assert "key2" in optimizer._cache
        assert "key3" in optimizer._cache

    def test_get_cached_response_expired_short(self):
        """Test getting expired SHORT cached response."""
        optimizer = LLMOptimizer()

        # Create an expired entry
        expired_time = time.time() - 301
        entry = CacheEntry(
            value="test_value",
            created_at=expired_time,
            model="gpt-4",
            policy=CachePolicy.SHORT,
        )
        optimizer._cache["test_key"] = entry

        result = optimizer._get_cached_response("test_key")
        assert result is None  # Should return None for expired

    def test_get_cached_response_expired_ttl(self):
        """Test getting expired TTL cached response."""
        optimizer = LLMOptimizer()

        # Create an expired entry
        expired_time = time.time() - 301
        entry = CacheEntry(
            value="test_value",
            created_at=expired_time,
            model="gpt-4",
            policy=CachePolicy.TTL,
        )
        optimizer._cache["test_key"] = entry

        result = optimizer._get_cached_response("test_key")
        assert result is None  # Should return None for expired

    def test_clear_expired_cache_default_ttl(self):
        """Test clearing expired cache with default TTL."""
        optimizer = LLMOptimizer()

        # Add entries with different ages using _add_to_cache to manage timestamps
        optimizer._add_to_cache("recent", "value1")
        optimizer._add_to_cache("expired", "value2")

        # Manually expire one entry
        optimizer._cache["expired"] = CacheEntry(
            value="value2",
            created_at=time.time() - 301,
            model="gpt-4",
            policy=CachePolicy.TTL,
        )

        optimizer._clear_expired_cache()

        assert "recent" in optimizer._cache
        assert "expired" not in optimizer._cache

    def test_clear_cache_with_model(self):
        """Test clearing cache for specific model."""
        optimizer = LLMOptimizer()

        optimizer._cache["key1"] = "value1"
        optimizer._cache["key2"] = "value2"

        count = optimizer.clear_cache()
        assert count == 2
        assert len(optimizer._cache) == 0

    def test_batch_call_empty_requests(self):
        """Test batch_call with empty request list."""
        responses = self.optimizer.batch_call([])
        assert responses == []

    def test_optimize_call_wrapper(self):
        """Test optimize_call wraps function correctly."""

        def mock_function(x, y):
            return x + y

        result = self.optimizer.optimize_call(mock_function, 5, 3)
        assert result == 8

    def test_call_llm_with_cache_hit_lru(self):
        """Test call_llm with LRU cache policy hit."""
        optimizer = LLMOptimizer(enable_caching=True)

        # Pre-populate cache
        optimizer._cache["test_hash"] = CacheEntry(
            value="cached_response",
            created_at=time.time(),
            model="gpt-4",
            policy=CachePolicy.LRU,
        )

        with patch.object(optimizer, "_hash_prompt", return_value="test_hash"):
            response = optimizer.call_llm(
                "Test prompt",
                model="gpt-4",
                cache_policy=CachePolicy.LRU,
            )

        assert response == "cached_response"

    def test_call_llm_caches_response(self):
        """Test that call_llm caches successful responses."""
        mock_client = Mock()
        # The implementation calls the client, not client.call
        # We need to make the mock callable
        mock_client.return_value = "LLM response"

        optimizer = LLMOptimizer(enable_caching=True)
        optimizer.set_llm_client(mock_client)

        response = optimizer.call_llm(
            "Test prompt",
            model="gpt-4",
            cache_policy=CachePolicy.SHORT,
        )

        assert response == "LLM response"
        assert len(optimizer._cache) > 0

    def test_get_statistics(self):
        """Test get_statistics returns correct stats."""
        stats = self.optimizer.get_statistics()
        assert isinstance(stats, LLMOptimizerStats)
        assert stats.cache_hits == 0
        assert stats.cache_misses == 0

    def test_get_stats_alias(self):
        """Test get_stats is an alias for get_statistics."""
        stats1 = self.optimizer.get_statistics()
        stats2 = self.optimizer.get_stats()

        assert stats1.cache_hits == stats2.cache_hits
        assert stats1.cache_misses == stats2.cache_misses

    def test_clear_cache_partial(self):
        """Test clearing cache partially with model filter."""
        optimizer = LLMOptimizer()

        # Add entries through call_llm which properly manages timestamps
        mock_client = Mock()
        mock_client.return_value = "response"

        optimizer.set_llm_client(mock_client)

        # Make calls with different models
        with patch.object(optimizer, "_hash_prompt", return_value="hash1"):
            optimizer.call_llm("prompt1", model="gpt-4", cache_policy=CachePolicy.LRU)

        with patch.object(optimizer, "_hash_prompt", return_value="hash2"):
            optimizer.call_llm("prompt2", model="gpt-3.5-turbo", cache_policy=CachePolicy.LRU)

        # Clear only gpt-4 cache
        count = optimizer.clear_cache(model="gpt-4")
        assert count == 1
        assert len(optimizer._cache) == 1
