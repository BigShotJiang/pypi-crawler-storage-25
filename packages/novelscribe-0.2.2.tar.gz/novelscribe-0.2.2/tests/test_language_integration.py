"""Integration tests for multi-language support."""

import os
from pathlib import Path
from unittest.mock import patch

import yaml
from click.testing import CliRunner

from cli import cli
from core.agent_registry import AgentRegistry
from core.language_config import LanguageCode, LanguageResolver
from core.workflow_loader import WorkflowLoader


class TestLanguageResolutionIntegration:
    """Integration tests for language resolution across the system."""

    def test_full_resolution_chain_with_all_sources(self, tmp_path):
        """Test complete resolution chain with all sources available."""
        config_path = tmp_path / "config.yaml"
        config_path.write_text(yaml.dump({"default_language": "zh-TW"}), encoding="utf-8")

        meta_path = tmp_path / "META.yaml"
        meta_path.write_text(yaml.dump({"language": "zh-CN"}), encoding="utf-8")

        with patch.dict(os.environ, {"SCRIBE_LANGUAGE": "en"}):
            resolver = LanguageResolver(
                config_path=config_path,
                project_dir=tmp_path,
            )

            result = resolver.resolve_language()
            assert result == LanguageCode.ZH_CN

    def test_cli_overrides_project_config(self, tmp_path):
        """Test that CLI --lang option overrides project META.yaml."""
        meta_path = tmp_path / "META.yaml"
        meta_path.write_text(yaml.dump({"language": "zh-CN"}), encoding="utf-8")

        runner = CliRunner()

        with patch("pathlib.Path.cwd", return_value=tmp_path):
            result = runner.invoke(cli, ["--lang", "zh-TW", "agents", "list"])
            assert result.exit_code == 0
            assert "zh-TW" in result.output

    def test_project_overrides_user_config(self, tmp_path):
        """Test that project META.yaml overrides user config."""
        config_path = tmp_path / "config.yaml"
        config_path.write_text(yaml.dump({"default_language": "zh-TW"}), encoding="utf-8")

        meta_path = tmp_path / "META.yaml"
        meta_path.write_text(yaml.dump({"language": "zh-CN"}), encoding="utf-8")

        resolver = LanguageResolver(
            config_path=config_path,
            project_dir=tmp_path,
        )

        result = resolver.resolve_language()
        assert result == LanguageCode.ZH_CN

    def test_user_config_overrides_environment(self, tmp_path):
        """Test that user config overrides environment variable."""
        config_path = tmp_path / "config.yaml"
        config_path.write_text(yaml.dump({"default_language": "zh-CN"}), encoding="utf-8")

        with patch.dict(os.environ, {"SCRIBE_LANGUAGE": "zh-TW"}):
            resolver = LanguageResolver(config_path=config_path)
            result = resolver.resolve_language()
            assert result == LanguageCode.ZH_CN


class TestLanguageFallbackBehavior:
    """Tests for language fallback mechanisms."""

    def test_fallback_to_english_from_chinese(self):
        """Test fallback from Chinese to English when zh-CN directory is empty."""
        import agents as agents_pkg

        agents_dir = Path(agents_pkg.__file__).parent

        registry_zh = AgentRegistry(agents_dir, language=LanguageCode.ZH_CN)
        agents_zh = registry_zh.get_all_agents()

        registry_en = AgentRegistry(agents_dir, language=LanguageCode.EN)
        agents_en = registry_en.get_all_agents()

        assert len(agents_zh) == len(agents_en), "Should fallback to English"

    def test_workflow_fallback_to_english(self):
        """Test workflow loader fallback to English."""
        workflows_dir = Path("workflows")

        loader_zh = WorkflowLoader(workflows_dir, language=LanguageCode.ZH_CN)
        workflows_zh = loader_zh.load_all_workflows()

        loader_en = WorkflowLoader(workflows_dir, language=LanguageCode.EN)
        workflows_en = loader_en.load_all_workflows()

        assert len(workflows_zh) == len(workflows_en), "Should fallback to English"

    def test_agent_reload_fallback_chain(self):
        """Test agent reload follows fallback chain."""
        import agents as agents_pkg

        agents_dir = Path(agents_pkg.__file__).parent

        registry = AgentRegistry(agents_dir, language=LanguageCode.ZH_CN)
        agent = registry.get_agent("outline_agent")

        assert agent is not None, "Should find agent via fallback to English"


class TestEndToEndLanguageSwitching:
    """End-to-end tests for language switching scenarios."""

    def test_set_default_then_list_agents(self, tmp_path):
        """Test setting default language then listing agents."""
        runner = CliRunner()

        with patch(
            "core.language_config.LanguageResolver.DEFAULT_CONFIG_PATH", tmp_path / "config.yaml"
        ):
            set_result = runner.invoke(cli, ["config", "set", "language", "zh-CN"])
            assert set_result.exit_code == 0

            list_result = runner.invoke(cli, ["agents", "list"])
            assert list_result.exit_code == 0
            assert "Available Agents" in list_result.output

    def test_switch_language_between_commands(self, tmp_path):
        """Test switching language between different commands."""
        runner = CliRunner()

        with patch("pathlib.Path.cwd", return_value=tmp_path):
            result1 = runner.invoke(cli, ["--lang", "en", "agents", "list"])
            assert result1.exit_code == 0
            assert "[Language: en]" in result1.output

            result2 = runner.invoke(cli, ["--lang", "zh-CN", "agents", "list"])
            assert result2.exit_code == 0
            assert "[Language: zh-CN]" in result2.output

    def test_workflow_with_different_languages(self, tmp_path):
        """Test running workflow with different language settings."""
        runner = CliRunner()

        with patch("pathlib.Path.cwd", return_value=tmp_path):
            for lang in ["en", "zh-CN", "zh-TW"]:
                result = runner.invoke(cli, ["--lang", lang, "workflows", "list"])
                assert result.exit_code == 0
                assert f"[Language: {lang}]" in result.output

    def test_persistent_language_across_sessions(self, tmp_path):
        """Test that language setting persists across CLI sessions."""
        config_path = tmp_path / "config.yaml"

        runner = CliRunner()

        with patch("core.language_config.LanguageResolver.DEFAULT_CONFIG_PATH", config_path):
            result1 = runner.invoke(cli, ["config", "set", "language", "zh-TW"])
            assert result1.exit_code == 0

        with patch("core.language_config.LanguageResolver.DEFAULT_CONFIG_PATH", config_path):
            result2 = runner.invoke(cli, ["config", "get", "language"])
            assert result2.exit_code == 0

            content = config_path.read_text(encoding="utf-8")
            assert "zh-TW" in content or "default_language: zh-TW" in content


class TestMissingLanguageScenarios:
    """Tests for scenarios when language files are missing."""

    def test_missing_zh_directory_fallback(self, tmp_path):
        """Test fallback when zh-CN directory doesn't exist."""
        agents_dir = tmp_path / "agents"
        agents_dir.mkdir()
        en_dir = agents_dir / "en"
        en_dir.mkdir()

        agent_file = en_dir / "test_agent.md"
        agent_file.write_text(
            """---
name: test_agent
version: 1.0.0
category: analytical
description: Test agent
input: []
output: []
dependencies: []
---
Test instructions
""",
            encoding="utf-8",
        )

        registry = AgentRegistry(agents_dir, language=LanguageCode.ZH_CN)
        agents = registry.get_all_agents()

        assert len(agents) == 1, "Should fallback to English"
        assert agents[0].name == "test_agent"

    def test_partial_language_coverage(self, tmp_path):
        """Test scenario where only some agents have translations."""
        agents_dir = tmp_path / "agents"
        agents_dir.mkdir()

        en_dir = agents_dir / "en"
        en_dir.mkdir()

        zh_dir = agents_dir / "zh-CN"
        zh_dir.mkdir()

        agent_en = en_dir / "agent1.md"
        agent_en.write_text(
            """---
name: agent1
version: 1.0.0
category: analytical
description: English agent
input: []
output: []
dependencies: []
---
English instructions
""",
            encoding="utf-8",
        )

        agent_zh = zh_dir / "agent2.md"
        agent_zh.write_text(
            """---
name: agent2
version: 1.0.0
category: analytical
description: Chinese agent
input: []
output: []
dependencies: []
---
Chinese instructions
""",
            encoding="utf-8",
        )

        registry_zh = AgentRegistry(agents_dir, language=LanguageCode.ZH_CN)
        agents_zh = registry_zh.get_all_agents()

        registry_en = AgentRegistry(agents_dir, language=LanguageCode.EN)
        agents_en = registry_en.get_all_agents()

        assert len(agents_zh) == 1, "zh-CN has 1 agent"
        assert len(agents_en) == 1, "English has 1 agent"
        assert agents_zh[0].name == "agent2"
        assert agents_en[0].name == "agent1"

    def test_invalid_language_in_meta(self, tmp_path):
        """Test handling of invalid language code in META.yaml."""
        meta_path = tmp_path / "META.yaml"
        meta_path.write_text(yaml.dump({"language": "invalid-lang"}), encoding="utf-8")

        resolver = LanguageResolver(project_dir=tmp_path)
        result = resolver.resolve_language()

        assert result == LanguageCode.EN, "Should fallback to English"

    def test_empty_meta_file(self, tmp_path):
        """Test handling of empty META.yaml file."""
        meta_path = tmp_path / "META.yaml"
        meta_path.write_text("", encoding="utf-8")

        resolver = LanguageResolver(project_dir=tmp_path)
        result = resolver.resolve_language()

        assert result == LanguageCode.EN, "Should fallback to English"


class TestLanguageSwitchingRealWorld:
    """Real-world scenario tests for language switching."""

    def test_multilingual_project_workflow(self, tmp_path):
        """Test complete workflow in a multilingual project."""
        runner = CliRunner()

        with patch("pathlib.Path.cwd", return_value=tmp_path):
            meta_path = tmp_path / "META.yaml"
            meta_path.write_text(
                yaml.dump(
                    {
                        "project_name": "test_novel",
                        "language": "zh-CN",
                        "genre": "fantasy",
                    }
                ),
                encoding="utf-8",
            )

            result = runner.invoke(cli, ["agents", "list"])
            assert result.exit_code == 0
            assert "[Language: zh-CN]" in result.output

            result = runner.invoke(cli, ["workflows", "list"])
            assert result.exit_code == 0
            assert "[Language: zh-CN]" in result.output

    def test_override_project_language_temporarily(self, tmp_path):
        """Test temporarily overriding project language."""
        runner = CliRunner()

        with patch("pathlib.Path.cwd", return_value=tmp_path):
            meta_path = tmp_path / "META.yaml"
            meta_path.write_text(
                yaml.dump({"project_name": "test", "language": "zh-CN"}),
                encoding="utf-8",
            )

            result_zh = runner.invoke(cli, ["agents", "list"])
            assert "[Language: zh-CN]" in result_zh.output

            result_en = runner.invoke(cli, ["--lang", "en", "agents", "list"])
            assert "[Language: en]" in result_en.output

            result_zh2 = runner.invoke(cli, ["agents", "list"])
            assert "[Language: zh-CN]" in result_zh2.output

    def test_language_persistence_across_reboots(self, tmp_path):
        """Test that language settings persist after simulated restart."""
        config_path = tmp_path / "config.yaml"

        runner = CliRunner()

        with patch("core.language_config.LanguageResolver.DEFAULT_CONFIG_PATH", config_path):
            set_result = runner.invoke(cli, ["config", "set", "language", "zh-TW"])
            assert set_result.exit_code == 0
            assert config_path.exists()

        with patch("core.language_config.LanguageResolver.DEFAULT_CONFIG_PATH", config_path):
            get_result = runner.invoke(cli, ["config", "get", "language"])
            assert get_result.exit_code == 0

            content = config_path.read_text(encoding="utf-8")
            assert "zh-TW" in content or "default_language: zh-TW" in content


class TestBackwardCompatibility:
    """Tests to ensure backward compatibility with existing projects."""

    def test_no_meta_file_works(self, tmp_path):
        """Test that projects without META.yaml still work."""
        runner = CliRunner()

        with patch("pathlib.Path.cwd", return_value=tmp_path):
            result = runner.invoke(cli, ["agents", "list"])
            assert result.exit_code == 0
            assert "[Language: en]" in result.output

    def test_no_language_field_in_meta(self, tmp_path):
        """Test META.yaml without language field."""
        meta_path = tmp_path / "META.yaml"
        meta_path.write_text(
            yaml.dump({"project_name": "test", "genre": "fantasy"}),
            encoding="utf-8",
        )

        runner = CliRunner()

        with patch("pathlib.Path.cwd", return_value=tmp_path):
            result = runner.invoke(cli, ["agents", "list"])
            assert result.exit_code == 0
            assert "[Language: en]" in result.output

    def test_legacy_directory_structure(self):
        """Test that legacy directory structure still works."""
        import agents as agents_pkg

        agents_dir = Path(agents_pkg.__file__).parent

        registry = AgentRegistry(str(agents_dir), language=LanguageCode.EN)
        agents = registry.get_all_agents()

        assert len(agents) >= 12, "Should load agents from legacy structure"


class TestLanguageDisplay:
    """Tests for language display in CLI output."""

    def test_language_shown_in_all_commands(self, tmp_path):
        """Test that language is shown in all relevant commands."""
        runner = CliRunner()

        with patch("pathlib.Path.cwd", return_value=tmp_path):
            commands = [
                ["agents", "list"],
                ["workflows", "list"],
            ]

            for cmd in commands:
                result = runner.invoke(cli, cmd)
                assert result.exit_code == 0
                assert "[Language: en]" in result.output

    def test_language_help_text_shown(self):
        """Test that language help text is shown."""
        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "--lang" in result.output

    def test_valid_languages_listed(self):
        """Test that valid languages are listed in help."""
        runner = CliRunner()
        result = runner.invoke(cli, ["config", "get"])
        assert result.exit_code == 0
        assert "en, zh-CN, zh-TW" in result.output
