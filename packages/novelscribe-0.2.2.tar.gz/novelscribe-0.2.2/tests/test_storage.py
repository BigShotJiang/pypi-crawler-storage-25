"""Tests for storage module."""

import shutil
import tempfile
from pathlib import Path

import pytest

from core.storage import (
    FileNotFoundError,
    FileParseError,
    FileStorage,
    StorageConfig,
    StorageError,
    StorageFactory,
)


@pytest.fixture
def temp_storage():
    """Create temporary storage for testing."""
    temp_dir = tempfile.mkdtemp()
    config = StorageConfig(base_path=temp_dir)
    storage = FileStorage(config)
    yield storage
    shutil.rmtree(temp_dir, ignore_errors=True)


class TestStorageConfig:
    """Tests for StorageConfig."""

    def test_default_config(self):
        """Test default configuration values."""
        config = StorageConfig()
        assert config.backend == "file"
        assert config.base_path == ".novels"
        assert config.cache_enabled is True

    def test_custom_config(self):
        """Test custom configuration values."""
        config = StorageConfig(backend="file", base_path="/tmp/test", cache_enabled=False)
        assert config.backend == "file"
        assert config.base_path == "/tmp/test"
        assert config.cache_enabled is False


class TestFileStorage:
    """Tests for FileStorage class."""

    def test_init_creates_base_path(self, temp_storage):
        """Test that initialization creates base path."""
        assert temp_storage.base_path.exists()
        assert temp_storage.base_path.is_dir()

    def test_write_and_read_markdown(self, temp_storage):
        """Test writing and reading markdown files."""
        content = "# Test Content\n\nThis is a test."
        temp_storage.write_markdown("test.md", content)

        assert temp_storage.exists("test.md")
        read_content = temp_storage.read_markdown("test.md")
        assert read_content == content

    def test_write_markdown_creates_directories(self, temp_storage):
        """Test that writing markdown creates parent directories."""
        content = "Nested content"
        temp_storage.write_markdown("nested/deep/test.md", content)

        assert temp_storage.exists("nested/deep/test.md")
        assert temp_storage.read_markdown("nested/deep/test.md") == content

    def test_read_nonexistent_markdown(self, temp_storage):
        """Test reading nonexistent markdown file raises error."""
        with pytest.raises(FileNotFoundError):
            temp_storage.read_markdown("nonexistent.md")

    def test_write_and_read_yaml(self, temp_storage):
        """Test writing and reading YAML files."""
        data = {"key": "value", "nested": {"item": 123}}
        temp_storage.write_yaml("test.yaml", data)

        assert temp_storage.exists("test.yaml")
        read_data = temp_storage.read_yaml("test.yaml")
        assert read_data == data

    def test_read_nonexistent_yaml(self, temp_storage):
        """Test reading nonexistent YAML file raises error."""
        with pytest.raises(FileNotFoundError):
            temp_storage.read_yaml("nonexistent.yaml")

    def test_read_invalid_yaml(self, temp_storage):
        """Test reading invalid YAML raises parse error."""
        temp_storage.write_markdown("invalid.yaml", "invalid: yaml: content:")

        with pytest.raises(FileParseError):
            temp_storage.read_yaml("invalid.yaml")

    def test_read_agent(self, temp_storage):
        """Test reading agent definition from markdown."""
        agent_content = """---
name: test_agent
description: A test agent
model: gpt-4
temperature: 0.8
max_tokens: 2048
---

This is the system prompt for the test agent."""
        temp_storage.write_markdown("agents/test.md", agent_content)

        agent = temp_storage.read_agent("agents/test.md")

        assert agent.name == "test_agent"
        assert agent.description == "A test agent"
        assert agent.model == "gpt-4"
        assert agent.temperature == 0.8
        assert agent.max_tokens == 2048
        assert agent.system_prompt == "This is the system prompt for the test agent."

    def test_read_agent_missing_frontmatter(self, temp_storage):
        """Test reading agent without frontmatter raises error."""
        temp_storage.write_markdown("invalid.md", "No frontmatter")

        with pytest.raises(FileParseError):
            temp_storage.read_agent("invalid.md")

    def test_read_agent_missing_required_field(self, temp_storage):
        """Test reading agent with missing required field raises error."""
        agent_content = """---
name: test_agent
description: A test agent
---

System prompt"""
        temp_storage.write_markdown("invalid.md", agent_content)

        with pytest.raises(FileParseError):
            temp_storage.read_agent("invalid.md")

    def test_read_workflow(self, temp_storage):
        """Test reading workflow definition from YAML."""
        workflow_data = {
            "name": "test_workflow",
            "description": "A test workflow",
            "steps": [{"agent": "test_agent", "input": ["input.txt"], "output": "output.txt"}],
            "version": "1.0",
        }
        temp_storage.write_yaml("workflows/test.yaml", workflow_data)

        workflow = temp_storage.read_workflow("workflows/test.yaml")

        assert workflow.name == "test_workflow"
        assert workflow.description == "A test workflow"
        assert len(workflow.steps) == 1
        assert workflow.steps[0]["agent"] == "test_agent"
        assert workflow.metadata["version"] == "1.0"

    def test_read_workflow_missing_required_field(self, temp_storage):
        """Test reading workflow with missing required field raises error."""
        workflow_data = {"name": "test_workflow", "steps": []}
        temp_storage.write_yaml("invalid.yaml", workflow_data)

        with pytest.raises(FileParseError):
            temp_storage.read_workflow("invalid.yaml")

    def test_read_workflow_invalid_steps(self, temp_storage):
        """Test reading workflow with non-list steps raises error."""
        workflow_data = {
            "name": "test_workflow",
            "description": "A test workflow",
            "steps": "not a list",
        }
        temp_storage.write_yaml("invalid.yaml", workflow_data)

        with pytest.raises(FileParseError):
            temp_storage.read_workflow("invalid.yaml")

    def test_exists_file(self, temp_storage):
        """Test exists returns True for existing file."""
        temp_storage.write_markdown("test.md", "content")
        assert temp_storage.exists("test.md")

    def test_exists_directory(self, temp_storage):
        """Test exists returns True for existing directory."""
        assert temp_storage.exists(".")

    def test_exists_nonexistent(self, temp_storage):
        """Test exists returns False for nonexistent path."""
        assert not temp_storage.exists("nonexistent.md")

    def test_delete_file(self, temp_storage):
        """Test deleting a file."""
        temp_storage.write_markdown("test.md", "content")
        assert temp_storage.exists("test.md")

        temp_storage.delete("test.md")
        assert not temp_storage.exists("test.md")

    def test_delete_directory(self, temp_storage):
        """Test deleting a directory."""
        temp_storage.write_markdown("dir/test.md", "content")
        assert temp_storage.exists("dir/test.md")

        temp_storage.delete("dir")
        assert not temp_storage.exists("dir/test.md")

    def test_list_files_empty(self, temp_storage):
        """Test listing files in empty directory."""
        files = temp_storage.list_files(".")
        assert files == []

    def test_list_files_with_files(self, temp_storage):
        """Test listing files returns matching files."""
        temp_storage.write_markdown("test1.md", "content1")
        temp_storage.write_markdown("test2.md", "content2")
        temp_storage.write_yaml("test.yaml", {})

        files = temp_storage.list_files(".", "*.md")
        assert len(files) == 2
        assert "test1.md" in files
        assert "test2.md" in files

    def test_resolve_path_absolute(self, temp_storage):
        """Test that absolute paths are not modified."""
        abs_path = "/tmp/test.md"
        resolved = temp_storage._resolve_path(abs_path)
        assert resolved == Path(abs_path)

    def test_resolve_path_relative(self, temp_storage):
        """Test that relative paths are resolved against base path."""
        rel_path = "test.md"
        resolved = temp_storage._resolve_path(rel_path)
        assert temp_storage.base_path in resolved.parents
        assert resolved.name == "test.md"


class TestStorageFactory:
    """Tests for StorageFactory."""

    def test_create_file_storage(self):
        """Test creating file storage through factory."""
        config = StorageConfig(backend="file")
        storage = StorageFactory.create(config)

        assert isinstance(storage, FileStorage)
        assert storage.config == config

    def test_create_unknown_backend(self):
        """Test creating unknown backend raises error."""
        config = StorageConfig(backend="unknown")

        with pytest.raises(StorageError):
            StorageFactory.create(config)

    def test_register_backend(self):
        """Test registering custom backend."""

        class CustomStorage:
            def __init__(self, config):
                self.config = config

        StorageFactory.register_backend("custom", CustomStorage)
        config = StorageConfig(backend="custom")
        storage = StorageFactory.create(config)

        assert isinstance(storage, CustomStorage)
