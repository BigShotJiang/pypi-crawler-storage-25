"""Comprehensive tests for performance profiler coverage improvement."""

import csv
import json
from pathlib import Path

import pytest

from core.performance_profiler import (
    ExecutionProfile,
    ExecutionStatus,
    PerformanceProfiler,
    PerformanceReport,
    ProfileType,
    ProfilingContext,
    get_profiler,
    profile_function,
)


class TestProfileType:
    """Test ProfileType enumeration."""

    def test_profile_type_values(self):
        """Test profile type enum values."""
        assert ProfileType.AGENT.value == "agent"
        assert ProfileType.WORKFLOW.value == "workflow"
        assert ProfileType.LLM_CALL.value == "llm_call"
        assert ProfileType.FILE_IO.value == "file_io"
        assert ProfileType.CUSTOM.value == "custom"


class TestExecutionStatus:
    """Test ExecutionStatus enumeration."""

    def test_status_values(self):
        """Test status enum values."""
        assert ExecutionStatus.PENDING.value == "pending"
        assert ExecutionStatus.RUNNING.value == "running"
        assert ExecutionStatus.COMPLETED.value == "completed"
        assert ExecutionStatus.FAILED.value == "failed"


class TestExecutionProfile:
    """Test ExecutionProfile dataclass."""

    def test_profile_creation(self):
        """Test creating a profile."""
        profile = ExecutionProfile(
            profile_id="test_id",
            name="test_profile",
            profile_type=ProfileType.AGENT,
            start_time=1.0,
        )
        assert profile.profile_id == "test_id"
        assert profile.name == "test_profile"
        assert profile.profile_type == ProfileType.AGENT
        assert profile.status == ExecutionStatus.PENDING

    def test_profile_complete(self):
        """Test completing a profile."""
        profile = ExecutionProfile(
            profile_id="test_id",
            name="test_profile",
            profile_type=ProfileType.AGENT,
            start_time=1.0,
        )
        profile.complete(end_time=3.0)

        assert profile.status == ExecutionStatus.COMPLETED
        assert profile.end_time == 3.0
        assert profile.duration == 2.0

    def test_profile_fail(self):
        """Test failing a profile."""
        profile = ExecutionProfile(
            profile_id="test_id",
            name="test_profile",
            profile_type=ProfileType.AGENT,
            start_time=1.0,
        )
        profile.fail("Test error", end_time=2.5)

        assert profile.status == ExecutionStatus.FAILED
        assert profile.error == "Test error"
        assert profile.duration == 1.5

    def test_to_dict(self):
        """Test to_dict method."""
        profile = ExecutionProfile(
            profile_id="test_id",
            name="test_profile",
            profile_type=ProfileType.AGENT,
            start_time=1.0,
            metadata={"key": "value"},
        )
        profile.complete(end_time=2.0)

        result = profile.to_dict()
        assert result["profile_id"] == "test_id"
        assert result["name"] == "test_profile"
        assert result["duration"] == 1.0
        assert result["metadata"] == {"key": "value"}


class TestPerformanceProfiler:
    """Test PerformanceProfiler class."""

    def test_initialization(self):
        """Test profiler initialization."""
        profiler = PerformanceProfiler()
        assert len(profiler.profiles) == 0
        assert len(profiler.active_profiles) == 0
        assert len(profiler.profile_stack) == 0

    def test_start_profile(self):
        """Test starting a profile."""
        profiler = PerformanceProfiler()
        profile_id = profiler.start_profile("test_profile", ProfileType.AGENT)

        assert profile_id in profiler.profiles
        assert "test_profile" in profiler.active_profiles
        assert profile_id in profiler.profile_stack

        profile = profiler.profiles[profile_id]
        assert profile.name == "test_profile"
        assert profile.status == ExecutionStatus.RUNNING

    def test_start_profile_with_metadata(self):
        """Test starting a profile with metadata."""
        profiler = PerformanceProfiler()
        profile_id = profiler.start_profile(
            "test_profile", ProfileType.AGENT, metadata={"key": "value"}
        )

        profile = profiler.profiles[profile_id]
        assert profile.metadata == {"key": "value"}

    def test_start_profile_parent_child(self):
        """Test parent-child relationship in profiles."""
        profiler = PerformanceProfiler()
        parent_id = profiler.start_profile("parent", ProfileType.WORKFLOW)
        child_id = profiler.start_profile("child", ProfileType.AGENT)

        parent = profiler.profiles[parent_id]
        child = profiler.profiles[child_id]

        assert child.parent_id == parent_id
        assert child_id in parent.sub_profiles

    def test_end_profile_success(self):
        """Test ending a profile successfully."""
        profiler = PerformanceProfiler()
        profile_id = profiler.start_profile("test_profile", ProfileType.AGENT)

        profile = profiler.end_profile(profile_id)

        assert profile.status == ExecutionStatus.COMPLETED
        assert profile.duration is not None
        assert "test_profile" not in profiler.active_profiles

    def test_end_profile_with_error(self):
        """Test ending a profile with error."""
        profiler = PerformanceProfiler()
        profile_id = profiler.start_profile("test_profile", ProfileType.AGENT)

        profile = profiler.end_profile(profile_id, error="Test error")

        assert profile.status == ExecutionStatus.FAILED
        assert profile.error == "Test error"

    def test_end_profile_with_metadata(self):
        """Test ending profile with additional metadata."""
        profiler = PerformanceProfiler()
        profile_id = profiler.start_profile("test_profile", ProfileType.AGENT)

        profile = profiler.end_profile(profile_id, metadata={"result": "success"})

        assert profile.metadata == {"result": "success"}

    def test_end_profile_not_found(self):
        """Test ending non-existent profile."""
        profiler = PerformanceProfiler()

        with pytest.raises(ValueError, match="not found"):
            profiler.end_profile("invalid_id")

    def test_get_profile(self):
        """Test getting a profile by ID."""
        profiler = PerformanceProfiler()
        profile_id = profiler.start_profile("test_profile", ProfileType.AGENT)

        profile = profiler.get_profile(profile_id)
        assert profile is not None
        assert profile.name == "test_profile"

    def test_get_profile_not_found(self):
        """Test getting non-existent profile."""
        profiler = PerformanceProfiler()
        profile = profiler.get_profile("invalid_id")
        assert profile is None

    def test_get_profiles_by_type(self):
        """Test getting profiles by type."""
        profiler = PerformanceProfiler()
        profiler.start_profile("agent1", ProfileType.AGENT)
        profiler.start_profile("agent2", ProfileType.AGENT)
        profiler.start_profile("workflow1", ProfileType.WORKFLOW)

        agent_profiles = profiler.get_profiles_by_type(ProfileType.AGENT)
        workflow_profiles = profiler.get_profiles_by_type(ProfileType.WORKFLOW)

        assert len(agent_profiles) == 2
        assert len(workflow_profiles) == 1

    def test_get_profiles_by_name(self):
        """Test getting profiles by name."""
        profiler = PerformanceProfiler()
        profiler.start_profile("test", ProfileType.AGENT)
        profiler.start_profile("test", ProfileType.AGENT)
        profiler.start_profile("other", ProfileType.WORKFLOW)

        test_profiles = profiler.get_profiles_by_name("test")
        assert len(test_profiles) == 2

    def test_identify_bottlenecks_default_threshold(self):
        """Test identifying bottlenecks with default threshold."""
        profiler = PerformanceProfiler()
        profile_id = profiler.start_profile("slow_operation", ProfileType.AGENT)
        profiler.end_profile(profile_id)

        profile = profiler.profiles[profile_id]
        profile.duration = 6.0

        bottlenecks = profiler.identify_bottlenecks(threshold=5.0)
        assert len(bottlenecks) > 0
        assert "slow_operation" in bottlenecks[0]

    def test_identify_bottlenecks_with_filter(self):
        """Test identifying bottlenecks with type filter."""
        profiler = PerformanceProfiler()
        agent_id = profiler.start_profile("agent", ProfileType.AGENT)
        profiler.end_profile(agent_id)
        profiler.profiles[agent_id].duration = 6.0

        workflow_id = profiler.start_profile("workflow", ProfileType.WORKFLOW)
        profiler.end_profile(workflow_id)
        profiler.profiles[workflow_id].duration = 4.0

        agent_bottlenecks = profiler.identify_bottlenecks(
            threshold=5.0, profile_type=ProfileType.AGENT
        )
        assert len(agent_bottlenecks) == 1

    def test_identify_bottlenecks_sorted(self):
        """Test bottlenecks are sorted by duration."""
        profiler = PerformanceProfiler()
        profile1_id = profiler.start_profile("fast", ProfileType.AGENT)
        profiler.end_profile(profile1_id)
        profiler.profiles[profile1_id].duration = 3.0

        profile2_id = profiler.start_profile("slow", ProfileType.AGENT)
        profiler.end_profile(profile2_id)
        profiler.profiles[profile2_id].duration = 10.0

        bottlenecks = profiler.identify_bottlenecks(threshold=1.0)
        assert "slow" in bottlenecks[0]
        assert "fast" in bottlenecks[1]

    def test_get_report(self):
        """Test getting performance report."""
        profiler = PerformanceProfiler()
        agent_id = profiler.start_profile("agent", ProfileType.AGENT)
        profiler.end_profile(agent_id)

        workflow_id = profiler.start_profile("workflow", ProfileType.WORKFLOW)
        profiler.end_profile(workflow_id)

        report = profiler.get_report()
        assert isinstance(report, PerformanceReport)
        assert len(report.agent_profiles) == 1
        assert len(report.workflow_profiles) == 1
        assert report.total_duration > 0

    def test_calculate_summary(self):
        """Test summary calculation."""
        profiler = PerformanceProfiler()
        agent_id = profiler.start_profile("agent", ProfileType.AGENT)
        profiler.end_profile(agent_id)
        profiler.profiles[agent_id].duration = 2.0

        report = profiler.get_report()
        summary = report.summary

        assert summary["agents"]["count"] == 1
        assert summary["agents"]["avg_duration"] == 2.0
        assert summary["total_profiles"] == 1

    def test_export_data_json(self, tmp_path):
        """Test exporting data as JSON."""
        profiler = PerformanceProfiler()
        agent_id = profiler.start_profile("agent", ProfileType.AGENT)
        profiler.end_profile(agent_id)

        output_path = tmp_path / "performance.json"
        result_path = profiler.export_data(str(output_path), format="json")

        assert Path(result_path).exists()

        with open(result_path) as f:
            data = json.load(f)
            assert "agent_count" in data
            assert "agents" in data

    def test_export_data_csv(self, tmp_path):
        """Test exporting data as CSV."""
        profiler = PerformanceProfiler()
        agent_id = profiler.start_profile("agent", ProfileType.AGENT)
        profiler.end_profile(agent_id)

        output_path = tmp_path / "performance.csv"
        result_path = profiler.export_data(str(output_path), format="csv")

        assert Path(result_path).exists()

        with open(result_path) as f:
            reader = csv.reader(f)
            rows = list(reader)
            assert len(rows) > 1
            assert rows[0][0] == "Profile ID"

    def test_export_data_unsupported_format(self, tmp_path):
        """Test exporting with unsupported format."""
        profiler = PerformanceProfiler()

        with pytest.raises(ValueError, match="Unsupported export format"):
            profiler.export_data(tmp_path / "data.xml", format="xml")

    def test_export_data_with_type_filter(self, tmp_path):
        """Test exporting with type filter."""
        profiler = PerformanceProfiler()
        agent_id = profiler.start_profile("agent", ProfileType.AGENT)
        profiler.end_profile(agent_id)

        workflow_id = profiler.start_profile("workflow", ProfileType.WORKFLOW)
        profiler.end_profile(workflow_id)

        output_path = tmp_path / "performance.json"
        result_path = profiler.export_data(
            str(output_path), format="json", profile_type=ProfileType.AGENT
        )

        with open(result_path) as f:
            data = json.load(f)
            assert "profiles" in data

    def test_clear(self):
        """Test clearing profiler data."""
        profiler = PerformanceProfiler()
        profiler.start_profile("test", ProfileType.AGENT)

        profiler.clear()

        assert len(profiler.profiles) == 0
        assert len(profiler.active_profiles) == 0
        assert len(profiler.profile_stack) == 0

    def test_get_active_profiles(self):
        """Test getting active profiles."""
        profiler = PerformanceProfiler()
        profiler.start_profile("profile1", ProfileType.AGENT)
        profiler.start_profile("profile2", ProfileType.WORKFLOW)

        active = profiler.get_active_profiles()
        assert len(active) == 2

    def test_profile_stack_pop_on_end(self):
        """Test profile stack pops correctly."""
        profiler = PerformanceProfiler()
        profile_id = profiler.start_profile("test", ProfileType.AGENT)
        assert len(profiler.profile_stack) == 1

        profiler.end_profile(profile_id)
        assert len(profiler.profile_stack) == 0


class TestPerformanceReport:
    """Test PerformanceReport dataclass."""

    def test_report_creation(self):
        """Test creating a report."""
        report = PerformanceReport(
            total_duration=10.0,
            agent_profiles=[],
            workflow_profiles=[],
            llm_profiles=[],
            file_io_profiles=[],
            bottlenecks=[],
            summary={},
        )
        assert report.total_duration == 10.0
        assert len(report.agent_profiles) == 0

    def test_report_to_dict(self):
        """Test report to_dict method."""
        profile = ExecutionProfile(
            profile_id="test",
            name="test_profile",
            profile_type=ProfileType.AGENT,
            start_time=1.0,
        )
        profile.complete(end_time=2.0)

        report = PerformanceReport(
            total_duration=10.0,
            agent_profiles=[profile],
            workflow_profiles=[],
            llm_profiles=[],
            file_io_profiles=[],
            bottlenecks=[],
            summary={"total": 1},
        )

        result = report.to_dict()
        assert result["total_duration"] == 10.0
        assert result["agent_count"] == 1
        assert len(result["agents"]) == 1


class TestProfilingContext:
    """Test ProfilingContext context manager."""

    def test_context_manager_success(self):
        """Test context manager with successful execution."""
        profiler = PerformanceProfiler()

        with ProfilingContext(profiler, "test_profile", ProfileType.AGENT):
            pass

        profiles = profiler.get_profiles_by_name("test_profile")
        assert len(profiles) == 1
        assert profiles[0].status == ExecutionStatus.COMPLETED

    def test_context_manager_with_exception(self):
        """Test context manager with exception."""
        profiler = PerformanceProfiler()

        with pytest.raises(ValueError):
            with ProfilingContext(profiler, "test_profile", ProfileType.AGENT):
                raise ValueError("Test error")

        profiles = profiler.get_profiles_by_name("test_profile")
        assert len(profiles) == 1
        assert profiles[0].status == ExecutionStatus.FAILED
        assert "Test error" in profiles[0].error

    def test_context_manager_with_metadata(self):
        """Test context manager with metadata."""
        profiler = PerformanceProfiler()

        with ProfilingContext(
            profiler, "test_profile", ProfileType.AGENT, metadata={"key": "value"}
        ):
            pass

        profile = profiler.get_profiles_by_name("test_profile")[0]
        assert profile.metadata == {"key": "value"}


class TestProfileFunctionDecorator:
    """Test profile_function decorator."""

    def test_decorator_success(self):
        """Test decorator with successful function."""
        profiler = PerformanceProfiler()

        @profile_function(profiler, name="test_func", profile_type=ProfileType.CUSTOM)
        def test_function():
            return "result"

        result = test_function()

        assert result == "result"
        profiles = profiler.get_profiles_by_name("test_func")
        assert len(profiles) == 1
        assert profiles[0].status == ExecutionStatus.COMPLETED

    def test_decorator_with_exception(self):
        """Test decorator with exception."""
        profiler = PerformanceProfiler()

        @profile_function(profiler, name="test_func", profile_type=ProfileType.CUSTOM)
        def test_function():
            raise ValueError("Test error")

        with pytest.raises(ValueError):
            test_function()

        profiles = profiler.get_profiles_by_name("test_func")
        assert len(profiles) == 1
        assert profiles[0].status == ExecutionStatus.FAILED

    def test_decorator_auto_naming(self):
        """Test decorator auto-naming."""
        profiler = PerformanceProfiler()

        @profile_function(profiler, profile_type=ProfileType.CUSTOM)
        def my_function():
            pass

        my_function()

        profiles = profiler.get_profiles_by_name("my_function")
        assert len(profiles) == 1

    def test_decorator_with_global_profiler(self):
        """Test decorator with global profiler."""

        @profile_function(name="test_func", profile_type=ProfileType.CUSTOM)
        def test_function():
            pass

        test_function()

        profiler = get_profiler()
        profiles = profiler.get_profiles_by_name("test_func")
        assert len(profiles) == 1


class TestGlobalProfiler:
    """Test global profiler instance."""

    def test_get_profiler(self):
        """Test getting global profiler."""
        profiler = get_profiler()
        assert profiler is not None
        assert isinstance(profiler, PerformanceProfiler)

    def test_get_profiler_singleton(self):
        """Test global profiler is singleton."""
        profiler1 = get_profiler()
        profiler2 = get_profiler()
        assert profiler1 is profiler2
