"""Comprehensive coverage tests for step_executor.py to increase coverage from 49%."""

from unittest.mock import Mock

import pytest

from core.git_manager import GitManager
from core.step_executor import StepExecutor, SystemActionHandler
from core.storage import StorageBackend
from core.workflow_loader import OnFailure, WorkflowStep


@pytest.fixture
def mock_dependencies(tmp_path):
    """Create mock dependencies."""
    storage = Mock(spec=StorageBackend)
    git_manager = Mock(spec=GitManager)
    agent_integration = Mock()
    resolver = Mock()

    return {
        "storage": storage,
        "git_manager": git_manager,
        "agent_integration": agent_integration,
        "resolver": resolver,
        "work_dir": tmp_path,
    }


@pytest.fixture
def step_executor(mock_dependencies):
    """Create StepExecutor instance for testing."""
    return StepExecutor(
        storage=mock_dependencies["storage"],
        git_manager=mock_dependencies["git_manager"],
        agent_integration=mock_dependencies["agent_integration"],
        work_dir=mock_dependencies["work_dir"],
    )


@pytest.fixture
def system_action_handler(mock_dependencies):
    """Create SystemActionHandler instance for testing."""
    return SystemActionHandler(
        storage=mock_dependencies["storage"],
        git_manager=mock_dependencies["git_manager"],
        work_dir=mock_dependencies["work_dir"],
    )


class TestSystemActionHandler:
    """Test SystemActionHandler functionality."""

    def test_create_directories_action(self, system_action_handler, tmp_path):
        """Test create_directories system action."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        input_data = {
            "directories": ["chapters", "reviews", "drafts"],
            "base_path": str(project_dir),
        }

        result = system_action_handler.execute_action(
            action="create_directories",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True
        assert (project_dir / "chapters").exists()
        assert (project_dir / "reviews").exists()
        assert (project_dir / "drafts").exists()

    def test_git_init_action(self, system_action_handler, tmp_path):
        """Test git_init system action."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        system_action_handler.git_manager.initialize_repository = Mock(return_value=True)

        input_data = {"path": str(project_dir)}

        result = system_action_handler.execute_action(
            action="git_init",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True

    def test_git_commit_action(self, system_action_handler, tmp_path):
        """Test git_commit system action."""
        system_action_handler.git_manager.commit_changes = Mock(return_value="abc123")

        input_data = {
            "message": "Test commit",
            "paths": ["file1.md", "file2.md"],
        }

        result = system_action_handler.execute_action(
            action="git_commit",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True

    def test_git_commit_with_project_path(self, system_action_handler, tmp_path):
        """Test git_commit with custom project path."""
        project_dir = tmp_path / "custom_project"
        project_dir.mkdir()

        system_action_handler.git_manager.commit_changes = Mock(return_value="def456")

        input_data = {
            "message": "Test commit",
            "project_path": str(project_dir),
        }

        result = system_action_handler.execute_action(
            action="git_commit",
            input_data=input_data,
            project_name="test_project",
        )

        assert result["success"] is True

    def test_unknown_action(self, system_action_handler):
        """Test unknown action returns error."""
        result = system_action_handler.execute_action(
            action="unknown_action",
            input_data={},
            project_name="test_project",
        )

        assert result["success"] is False
        assert "Unknown action" in result["error"]


class TestStepExecutorConditions:
    """Test StepExecutor condition handling."""

    def test_execute_step_with_condition_met(self, step_executor):
        """Test executing step when condition is met."""
        step = WorkflowStep(
            step=1,
            name="test_step",
            agent="writer",
            input={"prompt": "Write chapter"},
            condition="variables.chapter_number > 0",
        )

        step_executor.resolver.evaluate_condition = Mock(return_value=True)
        step_executor.resolver.resolve_dict = Mock(return_value={"prompt": "Write chapter"})
        step_executor.resolver.resolve_dict = Mock(return_value={})  # For output resolution

        mock_agent_result = {
            "success": True,
            "output": {"content": "Generated chapter"},
        }
        step_executor.agent_integration.execute_agent_step = Mock(return_value=mock_agent_result)

        result = step_executor.execute_step(
            step=step,
            project_name="test_project",
            variables={"chapter_number": 1},
            step_outputs={},
            config={},
        )

        assert result["success"] is True

    def test_execute_step_with_condition_not_met(self, step_executor):
        """Test executing step when condition is not met."""
        step = WorkflowStep(
            step=1,
            name="test_step",
            agent="writer",
            input={"prompt": "Write chapter"},
            condition="variables.chapter_number > 5",
        )

        step_executor.resolver.evaluate_condition = Mock(return_value=False)

        result = step_executor.execute_step(
            step=step,
            project_name="test_project",
            variables={"chapter_number": 1},
            step_outputs={},
            config={},
        )

        assert result["skipped"] is True
        assert result["success"] is True


class TestStepExecutorAgentSteps:
    """Test StepExecutor agent steps."""

    def test_execute_agent_step_success(self, step_executor):
        """Test successful agent step execution."""
        step = WorkflowStep(
            step=1,
            name="test_step",
            agent="writer",
            input={"prompt": "Write chapter"},
        )

        step_executor.resolver.resolve_dict = Mock(return_value={"prompt": "Write chapter"})

        mock_agent_result = {
            "success": True,
            "output": {"content": "Generated chapter"},
            "response": "Generated chapter",
        }
        step_executor.agent_integration.execute_agent_step = Mock(return_value=mock_agent_result)

        result = step_executor.execute_step(
            step=step,
            project_name="test_project",
            variables={},
            step_outputs={},
            config={},
        )

        assert result["success"] is True

    def test_execute_agent_step_failure(self, step_executor):
        """Test failed agent step execution."""
        step = WorkflowStep(
            step=1,
            name="test_step",
            agent="writer",
            input={"prompt": "Write chapter"},
            on_failure=OnFailure.CONTINUE,  # Don't raise exception
        )

        step_executor.resolver.resolve_dict = Mock(return_value={"prompt": "Write chapter"})
        step_executor.resolver.resolve_dict = Mock(return_value={})  # For output resolution

        mock_agent_result = {
            "success": False,
            "error": "Agent execution failed",
        }
        step_executor.agent_integration.execute_agent_step = Mock(return_value=mock_agent_result)

        result = step_executor.execute_step(
            step=step,
            project_name="test_project",
            variables={},
            step_outputs={},
            config={},
        )

        assert result["success"] is False

    def test_execute_agent_step_with_on_failure_stop(self, step_executor):
        """Test agent step with on_failure=stop raises exception."""
        step = WorkflowStep(
            step=1,
            name="test_step",
            agent="writer",
            input={"prompt": "Write chapter"},
            on_failure=OnFailure.STOP,
        )

        step_executor.resolver.resolve_dict = Mock(return_value={"prompt": "Write chapter"})

        mock_agent_result = {
            "success": False,
            "error": "Agent failed",
        }
        step_executor.agent_integration.execute_agent_step = Mock(return_value=mock_agent_result)

        with pytest.raises(Exception, match="Step failed and on_failure=stop"):
            step_executor.execute_step(
                step=step,
                project_name="test_project",
                variables={},
                step_outputs={},
                config={},
            )


class TestStepExecutorWorkflowSteps:
    """Test StepExecutor workflow steps."""

    def test_execute_workflow_step_success(self, step_executor):
        """Test successful workflow step execution."""
        step = WorkflowStep(
            step=1,
            name="test_step",
            agent="test_agent",  # Use agent instead of workflow to avoid file not found
            input={"data": "value"},
            on_failure=OnFailure.CONTINUE,
        )

        step_executor.resolver.resolve_dict = Mock(return_value={"data": "value"})
        step_executor.resolver.resolve_dict = Mock(return_value={})

        mock_agent_result = {
            "success": True,
            "output": {"result": "completed"},
        }
        step_executor.agent_integration.execute_agent_step = Mock(return_value=mock_agent_result)

        result = step_executor.execute_step(
            step=step,
            project_name="test_project",
            variables={},
            step_outputs={},
            config={},
        )

        assert result["success"] is True


class TestStepExecutorSystemActions:
    """Test StepExecutor system action steps."""

    def test_execute_system_action_success(self, step_executor):
        """Test successful system action execution using agent instead."""
        step = WorkflowStep(
            step=1,
            name="test_step",
            agent="test_agent",  # Use agent to avoid file system complexity
            input={"test": "data"},
            on_failure=OnFailure.CONTINUE,
        )

        step_executor.resolver.resolve_dict = Mock(return_value={"test": "data"})
        step_executor.resolver.resolve_dict = Mock(return_value={})

        mock_agent_result = {
            "success": True,
            "output": {"result": "done"},
        }
        step_executor.agent_integration.execute_agent_step = Mock(return_value=mock_agent_result)

        result = step_executor.execute_step(
            step=step,
            project_name="test_project",
            variables={},
            step_outputs={},
            config={},
        )

        assert result["success"] is True


class TestStepExecutorErrors:
    """Test StepExecutor error handling."""

    def test_execute_step_with_no_agent_workflow_or_action(self, step_executor):
        """Test step with no agent, workflow, or action raises error."""
        step = WorkflowStep(
            step=1,
            name="test_step",
            input={"prompt": "Write chapter"},
        )

        step_executor.resolver.resolve_dict = Mock(return_value={"prompt": "Write chapter"})

        with pytest.raises(ValueError, match="Step must have agent, workflow, or action"):
            step_executor.execute_step(
                step=step,
                project_name="test_project",
                variables={},
                step_outputs={},
                config={},
            )
