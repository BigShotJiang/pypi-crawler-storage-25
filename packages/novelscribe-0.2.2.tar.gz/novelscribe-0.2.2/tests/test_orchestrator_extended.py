"""
Comprehensive tests for orchestrator.py to increase coverage to 90%+.
Tests variable resolution and execution context.
"""

from pathlib import Path
from unittest.mock import Mock

from novel_harness.core.orchestrator import (
    ExecutionContext,
    VariableResolver,
)


class TestVariableResolver:
    """Test VariableResolver class."""

    def test_resolve_simple_variable(self):
        """Test resolving simple variable."""
        resolver = VariableResolver({"name": "Alice"})
        result = resolver.resolve("Hello {name}")
        assert result == "Hello Alice"

    def test_resolve_nested_variable(self):
        """Test resolving nested variable."""
        resolver = VariableResolver({"user": {"Name": "Alice"}})
        result = resolver.resolve("Hello {user.Name}")
        assert result == "Hello Alice"

    def test_resolve_missing_variable(self):
        """Test resolving missing variable returns original."""
        resolver = VariableResolver({})
        result = resolver.resolve("Hello {missing}")
        assert result == "Hello {missing}"

    def test_resolve_non_string(self):
        """Test resolving non-string returns as-is."""
        resolver = VariableResolver({"value": 42})
        result = resolver.resolve(42)
        assert result == 42

    def test_resolve_multiple_variables(self):
        """Test resolving multiple variables."""
        resolver = VariableResolver({"first": "Alice", "last": "Smith"})
        result = resolver.resolve("{first} {last}")
        assert result == "Alice Smith"

    def test_resolve_no_variables(self):
        """Test resolving text without variables."""
        resolver = VariableResolver({"name": "Alice"})
        result = resolver.resolve("Hello World")
        assert result == "Hello World"

    def test_resolve_empty_template(self):
        """Test resolving empty template."""
        resolver = VariableResolver({})
        result = resolver.resolve("")
        assert result == ""


class TestExecutionContext:
    """Test ExecutionContext class."""

    def test_init(self):
        """Test initialization."""
        context = ExecutionContext(
            project_name="test_project",
            workflow_name="test_workflow",
        )
        assert context.project_name == "test_project"
        assert context.workflow_name == "test_workflow"
        assert "project_name" in context.variables
        assert "workflow_name" in context.variables

    def test_init_with_custom_base_path(self):
        """Test initialization with custom base path."""
        context = ExecutionContext(
            project_name="test_project",
            workflow_name="test_workflow",
            base_path="/custom/path",
        )
        assert context.base_path == Path("/custom/path/test_project")

    def test_get_variable(self):
        """Test getting variable."""
        context = ExecutionContext(
            project_name="test_project",
            workflow_name="test_workflow",
        )
        context.variables["key"] = "value"
        result = context.get_variable("key")
        assert result == "value"

    def test_get_variable_missing(self):
        """Test getting missing variable."""
        context = ExecutionContext(
            project_name="test_project",
            workflow_name="test_workflow",
        )
        result = context.get_variable("missing")
        assert result is None

    def test_get_variable_with_default(self):
        """Test getting variable with default value."""
        context = ExecutionContext(
            project_name="test_project",
            workflow_name="test_workflow",
        )
        result = context.get_variable("missing", "default_value")
        assert result == "default_value"

    def test_add_history_entry(self):
        """Test adding history entry."""
        context = ExecutionContext(
            project_name="test_project",
            workflow_name="test_workflow",
        )
        mock_response = Mock()
        mock_response.content = "Test response"
        mock_response.model = "gpt-4"
        context.add_history_entry(
            step_name="step1",
            agent="agent1",
            input_files=["file1.md"],
            output_file="output.md",
            response=mock_response,
        )
        assert len(context.history) == 1
        assert context.history[0]["step"] == "step1"
        assert context.history[0]["agent"] == "agent1"

    def test_get_history(self):
        """Test getting history."""
        context = ExecutionContext("test", "test")
        context.history = [{"step_name": "step1"}, {"step_name": "step2"}]
        result = context.get_history()
        assert len(result) == 2

    def test_variables_property(self):
        """Test variables property returns dict."""
        context = ExecutionContext(
            project_name="test_project",
            workflow_name="test_workflow",
        )
        result = context.variables
        assert isinstance(result, dict)
        assert "project_name" in result

    def test_history_property(self):
        """Test history property returns list."""
        context = ExecutionContext(
            project_name="test_project",
            workflow_name="test_workflow",
        )
        result = context.history
        assert isinstance(result, list)
