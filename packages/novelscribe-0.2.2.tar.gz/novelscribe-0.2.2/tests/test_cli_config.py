"""
Tests for CLI config commands
"""

from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from cli_config import config


class TestConfigGroup:
    """Test cases for config command group"""

    def test_config_group_exists(self):
        """Test that config command group exists"""
        assert config is not None

    def test_config_help(self):
        """Test config command help"""
        runner = CliRunner()
        result = runner.invoke(config, ["--help"])

        assert result.exit_code == 0
        assert "config" in result.output.lower() or "Configuration" in result.output

    def test_config_subcommands_exist(self):
        """Test that config subcommands are registered"""
        runner = CliRunner()
        result = runner.invoke(config, ["--help"])

        assert result.exit_code == 0
        output = result.output.lower()
        # Should show available commands
        assert "set" in output or "get" in output or "list" in output


class TestConfigSet:
    """Test cases for config set command"""

    def test_config_set_help(self):
        """Test config set command help"""
        runner = CliRunner()
        result = runner.invoke(config, ["set", "--help"])

        assert result.exit_code == 0
        assert "language" in result.output.lower()

    def test_config_set_missing_args(self):
        """Test config set with missing arguments"""
        runner = CliRunner()
        result = runner.invoke(config, ["set"])

        assert result.exit_code != 0

    def test_config_set_missing_value(self):
        """Test config set with missing value"""
        runner = CliRunner()
        result = runner.invoke(config, ["set", "language"])

        assert result.exit_code != 0

    def test_config_set_language_valid(self):
        """Test config set with valid language"""
        runner = CliRunner()
        with patch("cli_config.LanguageCode") as mock_lang_code:
            mock_lang_code.return_value = "en"
            with patch("cli_config.LanguageResolver") as mock_resolver:
                mock_instance = MagicMock()
                mock_config = MagicMock()
                mock_config.default_language = "en"
                mock_instance.get_config.return_value = mock_config
                mock_instance.config_path = "/path/to/config"
                mock_resolver.return_value = mock_instance

                result = runner.invoke(config, ["set", "language", "en"])

                # Should handle gracefully
                assert result.exit_code in [0, 1]

    def test_config_set_language_invalid(self):
        """Test config set with invalid language"""
        runner = CliRunner()
        with patch("cli_config.LanguageCode") as mock_lang_code:
            mock_lang_code.side_effect = ValueError("Invalid language code")

            result = runner.invoke(config, ["set", "language", "invalid"])

            assert result.exit_code == 1

    def test_config_set_language_zh_cn(self):
        """Test config set with zh-CN language"""
        runner = CliRunner()
        with patch("cli_config.LanguageCode") as mock_lang_code:
            mock_lang_code.return_value = "zh-CN"
            with patch("cli_config.LanguageResolver") as mock_resolver:
                mock_instance = MagicMock()
                mock_config = MagicMock()
                mock_config.default_language = "zh-CN"
                mock_instance.get_config.return_value = mock_config
                mock_instance.config_path = "/path/to/config"
                mock_resolver.return_value = mock_instance

                result = runner.invoke(config, ["set", "language", "zh-CN"])

                # Should handle gracefully
                assert result.exit_code in [0, 1]

    def test_config_set_language_zh_tw(self):
        """Test config set with zh-TW language"""
        runner = CliRunner()
        with patch("cli_config.LanguageCode") as mock_lang_code:
            mock_lang_code.return_value = "zh-TW"
            with patch("cli_config.LanguageResolver") as mock_resolver:
                mock_instance = MagicMock()
                mock_config = MagicMock()
                mock_config.default_language = "zh-TW"
                mock_instance.get_config.return_value = mock_config
                mock_instance.config_path = "/path/to/config"
                mock_resolver.return_value = mock_instance

                result = runner.invoke(config, ["set", "language", "zh-TW"])

                # Should handle gracefully
                assert result.exit_code in [0, 1]

    def test_config_set_invalid_key(self):
        """Test config set with invalid key"""
        runner = CliRunner()
        result = runner.invoke(config, ["set", "invalid_key", "value"])

        # Should fail with invalid choice
        assert result.exit_code != 0


class TestConfigGet:
    """Test cases for config get command"""

    def test_config_get_help(self):
        """Test config get command help"""
        runner = CliRunner()
        result = runner.invoke(config, ["get", "--help"])

        # Command might not exist
        assert result.exit_code in [0, 1, 2]

    def test_config_get_basic(self):
        """Test config get basic execution"""
        runner = CliRunner()
        result = runner.invoke(config, ["get"])

        # Command might not exist
        assert result.exit_code in [0, 1, 2]


class TestConfigList:
    """Test cases for config list command"""

    def test_config_list_help(self):
        """Test config list command help"""
        runner = CliRunner()
        result = runner.invoke(config, ["list", "--help"])

        # Command might not exist
        assert result.exit_code in [0, 1, 2]

    def test_config_list_basic(self):
        """Test config list basic execution"""
        runner = CliRunner()
        result = runner.invoke(config, ["list"])

        # Command might not exist
        assert result.exit_code in [0, 1, 2]
