"""
Tests for CLI performance commands
"""

from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from cli_performance import performance_cli


class TestPerformanceCLIGroup:
    """Test cases for performance command group"""

    def test_performance_cli_group_exists(self):
        """Test that performance command group exists"""
        assert performance_cli is not None

    def test_performance_cli_help(self):
        """Test performance command help"""
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["--help"])

        assert result.exit_code == 0
        assert "perf" in result.output.lower() or "performance" in result.output.lower()

    def test_performance_cli_profile_command_exists(self):
        """Test that profile subcommand exists"""
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["profile", "--help"])

        assert result.exit_code == 0
        assert "profile" in result.output.lower()

    def test_performance_cli_bottlenecks_command_exists(self):
        """Test that bottlenecks subcommand exists"""
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["bottlenecks", "--help"])

        assert result.exit_code == 0
        assert "bottlenecks" in result.output.lower()

    def test_performance_cli_file_stats_command_exists(self):
        """Test that file-stats subcommand exists"""
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["file-stats", "--help"])

        assert result.exit_code == 0

    def test_performance_cli_llm_stats_command_exists(self):
        """Test that llm-stats subcommand exists"""
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["llm-stats", "--help"])

        assert result.exit_code == 0


class TestProfileCommand:
    """Test cases for profile command"""

    def test_profile_missing_project_name(self):
        """Test profile command without project name"""
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["profile"])

        assert result.exit_code != 0

    def test_profile_with_defaults(self):
        """Test profile command with default options"""
        runner = CliRunner()

        with patch("cli_performance.get_profiler") as mock_profiler:
            mock_instance = MagicMock()
            mock_report = MagicMock()
            mock_report.total_duration = 1.5
            mock_report.summary = {"agents": 2, "tokens": 1000, "cost": 0.05}
            mock_report.bottlenecks = []
            mock_report.to_dict.return_value = {
                "total_duration": 1.5,
                "summary": {"agents": 2},
                "bottlenecks": [],
            }
            mock_instance.get_report.return_value = mock_report
            mock_profiler.return_value = mock_instance

            result = runner.invoke(performance_cli, ["profile", "test-project"])

            assert result.exit_code in [0, 1]

    def test_profile_with_custom_workflow(self):
        """Test profile command with custom workflow"""
        runner = CliRunner()

        with patch("cli_performance.get_profiler") as mock_profiler:
            mock_instance = MagicMock()
            mock_report = MagicMock()
            mock_report.total_duration = 2.0
            mock_report.summary = {"agents": 3}
            mock_report.bottlenecks = []
            mock_report.to_dict.return_value = {"total_duration": 2.0}
            mock_instance.get_report.return_value = mock_report
            mock_profiler.return_value = mock_instance

            result = runner.invoke(
                performance_cli, ["profile", "test-project", "--workflow", "writing_phase"]
            )

            assert result.exit_code in [0, 1]

    def test_profile_with_text_format(self):
        """Test profile command with text format"""
        runner = CliRunner()

        with patch("cli_performance.get_profiler") as mock_profiler:
            mock_instance = MagicMock()
            mock_report = MagicMock()
            mock_report.total_duration = 3.0
            mock_report.summary = {"agents": 5}
            mock_report.bottlenecks = []
            mock_report.to_dict.return_value = {}
            mock_instance.get_report.return_value = mock_report
            mock_profiler.return_value = mock_instance

            result = runner.invoke(performance_cli, ["profile", "test-project", "--format", "text"])

            assert result.exit_code in [0, 1]

    def test_profile_with_json_format(self):
        """Test profile command with JSON format"""
        runner = CliRunner()

        with patch("cli_performance.get_profiler") as mock_profiler:
            mock_instance = MagicMock()
            mock_report = MagicMock()
            mock_report.total_duration = 1.5
            mock_report.summary = {}
            mock_report.bottlenecks = []
            mock_report.to_dict.return_value = {"total_duration": 1.5, "summary": {}}
            mock_instance.get_report.return_value = mock_report
            mock_profiler.return_value = mock_instance

            result = runner.invoke(performance_cli, ["profile", "test-project", "--format", "json"])

            assert result.exit_code in [0, 1]

    def test_profile_with_json_format_and_output(self):
        """Test profile command with JSON format and output file"""
        runner = CliRunner()

        with patch("cli_performance.get_profiler") as mock_profiler:
            mock_instance = MagicMock()
            mock_report = MagicMock()
            mock_report.total_duration = 2.5
            mock_report.summary = {}
            mock_report.bottlenecks = []
            mock_report.to_dict.return_value = {"total_duration": 2.5}
            mock_instance.get_report.return_value = mock_report
            mock_profiler.return_value = mock_instance

            with runner.isolated_filesystem():
                result = runner.invoke(
                    performance_cli,
                    ["profile", "test-project", "--format", "json", "--output", "report.json"],
                )

                assert result.exit_code in [0, 1]

    def test_profile_with_csv_format_with_output(self):
        """Test profile command with CSV format and output file"""
        runner = CliRunner()

        with patch("cli_performance.get_profiler") as mock_profiler:
            mock_instance = MagicMock()
            mock_report = MagicMock()
            mock_report.total_duration = 1.0
            mock_report.summary = {}
            mock_report.bottlenecks = []
            mock_report.to_dict.return_value = {}
            mock_instance.get_report.return_value = mock_report
            mock_instance.export_data = MagicMock()
            mock_profiler.return_value = mock_instance

            with runner.isolated_filesystem():
                result = runner.invoke(
                    performance_cli,
                    ["profile", "test-project", "--format", "csv", "--output", "report.csv"],
                )

                assert result.exit_code in [0, 1]

    def test_profile_with_csv_format_without_output(self):
        """Test profile command with CSV format but no output file"""
        runner = CliRunner()

        with patch("cli_performance.get_profiler") as mock_profiler:
            mock_instance = MagicMock()
            mock_report = MagicMock()
            mock_report.total_duration = 1.5
            mock_report.summary = {}
            mock_report.bottlenecks = []
            mock_report.to_dict.return_value = {}
            mock_instance.get_report.return_value = mock_report
            mock_profiler.return_value = mock_instance

            result = runner.invoke(performance_cli, ["profile", "test-project", "--format", "csv"])

            assert result.exit_code in [0, 1]

    def test_profile_with_bottlenecks(self):
        """Test profile command with bottlenecks detected"""
        runner = CliRunner()

        with patch("cli_performance.get_profiler") as mock_profiler:
            mock_instance = MagicMock()
            mock_report = MagicMock()
            mock_report.total_duration = 10.0
            mock_report.summary = {"agents": 5}
            mock_report.bottlenecks = ["Agent 'writer': 6.0s", "Agent 'editor': 7.0s"]
            mock_report.to_dict.return_value = {}
            mock_instance.get_report.return_value = mock_report
            mock_profiler.return_value = mock_instance

            result = runner.invoke(performance_cli, ["profile", "test-project"])

            assert result.exit_code in [0, 1]

    def test_profile_with_exception(self):
        """Test profile command with exception"""
        runner = CliRunner()

        with patch("cli_performance.get_profiler") as mock_profiler:
            mock_profiler.side_effect = Exception("Profile error")

            result = runner.invoke(performance_cli, ["profile", "test-project"])

            assert result.exit_code == 1


class TestBottlenecksCommand:
    """Test cases for bottlenecks command"""

    def test_bottlenecks_missing_project_name(self):
        """Test bottlenecks command without project name"""
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["bottlenecks"])

        assert result.exit_code != 0

    def test_bottlenecks_with_defaults(self):
        """Test bottlenecks command with default options"""
        runner = CliRunner()

        with patch("cli_performance.get_profiler") as mock_profiler:
            mock_instance = MagicMock()
            mock_instance.identify_bottlenecks.return_value = []
            mock_profiler.return_value = mock_instance

            result = runner.invoke(performance_cli, ["bottlenecks", "test-project"])

            assert result.exit_code in [0, 1]

    def test_bottlenecks_with_threshold(self):
        """Test bottlenecks command with custom threshold"""
        runner = CliRunner()

        with patch("cli_performance.get_profiler") as mock_profiler:
            mock_instance = MagicMock()
            mock_instance.identify_bottlenecks.return_value = [
                "Agent 'writer': 6.0s",
                "Agent 'editor': 7.0s",
            ]
            mock_profiler.return_value = mock_instance

            result = runner.invoke(
                performance_cli, ["bottlenecks", "test-project", "--threshold", "3.0"]
            )

            assert result.exit_code in [0, 1]

    def test_bottlenecks_with_type_agent(self):
        """Test bottlenecks command with agent type filter"""
        runner = CliRunner()

        with patch("cli_performance.get_profiler") as mock_profiler:
            mock_instance = MagicMock()
            mock_instance.identify_bottlenecks.return_value = ["Agent 'writer': 8.0s"]
            mock_profiler.return_value = mock_instance

            result = runner.invoke(
                performance_cli, ["bottlenecks", "test-project", "--type", "agent"]
            )

            assert result.exit_code in [0, 1]

    def test_bottlenecks_with_type_workflow(self):
        """Test bottlenecks command with workflow type filter"""
        runner = CliRunner()

        with patch("cli_performance.get_profiler") as mock_profiler:
            mock_instance = MagicMock()
            mock_instance.identify_bottlenecks.return_value = []
            mock_profiler.return_value = mock_instance

            result = runner.invoke(
                performance_cli, ["bottlenecks", "test-project", "--type", "workflow"]
            )

            assert result.exit_code in [0, 1]

    def test_bottlenecks_with_type_llm(self):
        """Test bottlenecks command with llm type filter"""
        runner = CliRunner()

        with patch("cli_performance.get_profiler") as mock_profiler:
            mock_instance = MagicMock()
            mock_instance.identify_bottlenecks.return_value = ["LLM call: 10.0s"]
            mock_profiler.return_value = mock_instance

            result = runner.invoke(
                performance_cli, ["bottlenecks", "test-project", "--type", "llm"]
            )

            assert result.exit_code in [0, 1]

    def test_bottlenecks_with_type_file_io(self):
        """Test bottlenecks command with file_io type filter"""
        runner = CliRunner()

        with patch("cli_performance.get_profiler") as mock_profiler:
            mock_instance = MagicMock()
            mock_instance.identify_bottlenecks.return_value = []
            mock_profiler.return_value = mock_instance

            result = runner.invoke(
                performance_cli, ["bottlenecks", "test-project", "--type", "file_io"]
            )

            assert result.exit_code in [0, 1]

    def test_bottlenecks_no_bottlenecks_found(self):
        """Test bottlenecks command when no bottlenecks found"""
        runner = CliRunner()

        with patch("cli_performance.get_profiler") as mock_profiler:
            mock_instance = MagicMock()
            mock_instance.identify_bottlenecks.return_value = []
            mock_profiler.return_value = mock_instance

            result = runner.invoke(
                performance_cli, ["bottlenecks", "test-project", "--threshold", "10.0"]
            )

            assert result.exit_code in [0, 1]

    def test_bottlenecks_with_exception(self):
        """Test bottlenecks command with exception"""
        runner = CliRunner()

        with patch("cli_performance.get_profiler") as mock_profiler:
            mock_instance = MagicMock()
            mock_instance.identify_bottlenecks.side_effect = Exception("Bottlenecks error")
            mock_profiler.return_value = mock_instance

            result = runner.invoke(performance_cli, ["bottlenecks", "test-project"])

            assert result.exit_code == 1


class TestFileStatsCommand:
    """Test cases for file-stats command"""

    def test_file_stats_missing_project_name(self):
        """Test file-stats command without project name"""
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["file-stats"])

        assert result.exit_code != 0

    def test_file_stats_success(self):
        """Test file-stats command success"""
        runner = CliRunner()

        with patch("cli_performance.get_file_optimizer") as mock_optimizer:
            mock_instance = MagicMock()
            mock_stats = MagicMock()
            mock_stats.to_dict.return_value = {
                "reads": 100,
                "writes": 50,
                "read_cache_hits": 80,
                "write_cache_hits": 40,
            }
            mock_instance.get_stats.return_value = mock_stats
            mock_instance.get_cache_info.return_value = {
                "size": 10,
                "max_size": 100,
                "hit_rate": 0.8,
                "most_accessed": [("file1.txt", 50), ("file2.txt", 30)],
            }
            mock_instance.get_write_cache_info.return_value = {
                "size": 5,
                "max_size": 50,
                "hits": 40,
            }
            mock_optimizer.return_value = mock_instance

            result = runner.invoke(performance_cli, ["file-stats", "test-project"])

            assert result.exit_code in [0, 1]

    def test_file_stats_with_exception(self):
        """Test file-stats command with exception"""
        runner = CliRunner()

        with patch("cli_performance.get_file_optimizer") as mock_optimizer:
            mock_instance = MagicMock()
            mock_instance.get_stats.side_effect = Exception("Stats error")
            mock_optimizer.return_value = mock_instance

            result = runner.invoke(performance_cli, ["file-stats", "test-project"])

            assert result.exit_code == 1


class TestClearFileCacheCommand:
    """Test cases for clear-file-cache command"""

    def test_clear_file_cache_missing_project_name(self):
        """Test clear-file-cache command without project name"""
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["clear-file-cache"])

        assert result.exit_code != 0

    def test_clear_file_cache_success(self):
        """Test clear-file-cache command success"""
        runner = CliRunner()

        with patch("cli_performance.get_file_optimizer") as mock_optimizer:
            mock_instance = MagicMock()
            mock_instance.clear_cache = MagicMock()
            mock_instance.clear_write_cache = MagicMock()
            mock_optimizer.return_value = mock_instance

            result = runner.invoke(performance_cli, ["clear-file-cache", "test-project"])

            assert result.exit_code in [0, 1]

    def test_clear_file_cache_with_exception(self):
        """Test clear-file-cache command with exception"""
        runner = CliRunner()

        with patch("cli_performance.get_file_optimizer") as mock_optimizer:
            mock_instance = MagicMock()
            mock_instance.clear_cache.side_effect = Exception("Clear error")
            mock_optimizer.return_value = mock_instance

            result = runner.invoke(performance_cli, ["clear-file-cache", "test-project"])

            assert result.exit_code == 1


class TestBenchmarkIOCommand:
    """Test cases for benchmark-io command"""

    def test_benchmark_io_missing_project_name(self):
        """Test benchmark-io command without project name"""
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["benchmark-io"])

        assert result.exit_code != 0

    def test_benchmark_io_with_default_file_size(self):
        """Test benchmark-io command with default file size"""
        runner = CliRunner()

        with patch("cli_performance.get_file_optimizer") as mock_optimizer:
            mock_instance = MagicMock()
            mock_instance.read_file.return_value = "x" * (1024 * 1024)
            mock_instance.write_file = MagicMock()
            mock_optimizer.return_value = mock_instance

            result = runner.invoke(performance_cli, ["benchmark-io", "test-project"])

            assert result.exit_code in [0, 1]

    def test_benchmark_io_with_custom_file_size(self):
        """Test benchmark-io command with custom file size"""
        runner = CliRunner()

        with patch("cli_performance.get_file_optimizer") as mock_optimizer:
            mock_instance = MagicMock()
            mock_instance.read_file.return_value = "x" * (2 * 1024 * 1024)
            mock_instance.write_file = MagicMock()
            mock_optimizer.return_value = mock_instance

            result = runner.invoke(
                performance_cli, ["benchmark-io", "test-project", "--file-size", "2M"]
            )

            assert result.exit_code in [0, 1]

    def test_benchmark_io_with_kilobyte_size(self):
        """Test benchmark-io command with kilobyte size"""
        runner = CliRunner()

        with patch("cli_performance.get_file_optimizer") as mock_optimizer:
            mock_instance = MagicMock()
            mock_instance.read_file.return_value = "x" * 500
            mock_instance.write_file = MagicMock()
            mock_optimizer.return_value = mock_instance

            result = runner.invoke(
                performance_cli, ["benchmark-io", "test-project", "--file-size", "500K"]
            )

            assert result.exit_code in [0, 1]

    def test_benchmark_io_with_exception(self):
        """Test benchmark-io command with exception"""
        runner = CliRunner()

        with patch("cli_performance.get_file_optimizer") as mock_optimizer:
            mock_instance = MagicMock()
            mock_instance.write_file.side_effect = Exception("Benchmark error")
            mock_optimizer.return_value = mock_instance

            result = runner.invoke(performance_cli, ["benchmark-io", "test-project"])

            assert result.exit_code == 1


class TestExecGraphCommand:
    """Test cases for exec-graph command"""

    def test_exec_graph_missing_project_name(self):
        """Test exec-graph command without project name"""
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["exec-graph"])

        assert result.exit_code != 0

    def test_exec_graph_with_defaults(self):
        """Test exec-graph command with default options"""
        runner = CliRunner()

        with patch("cli_performance.get_parallel_executor") as mock_executor:
            mock_instance = MagicMock()
            mock_graph = MagicMock()
            mock_graph.nodes = {
                "node1": MagicMock(agent_name="agent1", dependencies=[]),
                "node2": MagicMock(agent_name="agent2", dependencies=[]),
            }
            mock_graph.validate.return_value = (True, [])
            mock_graph.topological_sort.return_value = ["node1", "node2"]
            mock_graph.get_ready_nodes.return_value = [mock_graph.nodes["node1"]]
            mock_instance.build_graph_from_workflow.return_value = mock_graph
            mock_executor.return_value = mock_instance

            result = runner.invoke(performance_cli, ["exec-graph", "test-project"])

            assert result.exit_code in [0, 1]

    def test_exec_graph_invalid_graph(self):
        """Test exec-graph command with invalid graph"""
        runner = CliRunner()

        with patch("cli_performance.get_parallel_executor") as mock_executor:
            mock_instance = MagicMock()
            mock_graph = MagicMock()
            mock_graph.validate.return_value = (False, ["Cycle detected"])
            mock_instance.build_graph_from_workflow.return_value = mock_graph
            mock_executor.return_value = mock_instance

            result = runner.invoke(performance_cli, ["exec-graph", "test-project"])

            assert result.exit_code in [0, 1]

    def test_exec_graph_with_custom_workflow(self):
        """Test exec-graph command with custom workflow"""
        runner = CliRunner()

        with patch("cli_performance.get_parallel_executor") as mock_executor:
            mock_instance = MagicMock()
            mock_graph = MagicMock()
            mock_graph.validate.return_value = (True, [])
            mock_graph.topological_sort.return_value = ["node1"]
            mock_graph.get_ready_nodes.return_value = []
            mock_instance.build_graph_from_workflow.return_value = mock_graph
            mock_executor.return_value = mock_instance

            result = runner.invoke(
                performance_cli, ["exec-graph", "test-project", "--workflow", "custom"]
            )

            assert result.exit_code in [0, 1]

    def test_exec_graph_with_exception(self):
        """Test exec-graph command with exception"""
        runner = CliRunner()

        with patch("cli_performance.get_parallel_executor") as mock_executor:
            mock_instance = MagicMock()
            mock_instance.build_graph_from_workflow.side_effect = Exception("Graph error")
            mock_executor.return_value = mock_instance

            result = runner.invoke(performance_cli, ["exec-graph", "test-project"])

            assert result.exit_code == 1


class TestParallelCommand:
    """Test cases for parallel command"""

    def test_parallel_missing_project_name(self):
        """Test parallel command without project name"""
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["parallel"])

        assert result.exit_code != 0

    def test_parallel_with_defaults(self):
        """Test parallel command with default options"""
        runner = CliRunner()

        with patch("cli_performance.get_parallel_executor") as mock_executor_class:
            mock_graph = MagicMock()
            mock_graph.nodes = {
                "node1": MagicMock(agent_name="agent1", dependencies=[]),
                "node2": MagicMock(agent_name="agent2", dependencies=[]),
            }

            mock_result = MagicMock()
            mock_result.success = True
            mock_result.completed_nodes = ["node1", "node2"]
            mock_result.failed_nodes = []
            mock_result.skipped_nodes = []
            mock_result.total_duration = 0.5
            mock_result.errors = {}

            mock_executor = MagicMock()
            mock_executor.build_graph_from_workflow.return_value = mock_graph
            mock_executor.execute_parallel.return_value = mock_result
            mock_executor_class.return_value = mock_executor

            result = runner.invoke(performance_cli, ["parallel", "test-project"])

            assert result.exit_code in [0, 1]

    def test_parallel_with_custom_workflow(self):
        """Test parallel command with custom workflow"""
        runner = CliRunner()

        with patch("cli_performance.get_parallel_executor") as mock_executor_class:
            mock_graph = MagicMock()
            mock_graph.nodes = {}

            mock_result = MagicMock()
            mock_result.success = True
            mock_result.completed_nodes = []
            mock_result.failed_nodes = []
            mock_result.skipped_nodes = []
            mock_result.total_duration = 0.3
            mock_result.errors = {}

            mock_executor = MagicMock()
            mock_executor.build_graph_from_workflow.return_value = mock_graph
            mock_executor.execute_parallel.return_value = mock_result
            mock_executor_class.return_value = mock_executor

            result = runner.invoke(
                performance_cli, ["parallel", "test-project", "--workflow", "custom"]
            )

            assert result.exit_code in [0, 1]

    def test_parallel_with_max_workers(self):
        """Test parallel command with custom max workers"""
        runner = CliRunner()

        with patch("cli_performance.get_parallel_executor") as mock_executor_class:
            mock_graph = MagicMock()
            mock_graph.nodes = {}

            mock_result = MagicMock()
            mock_result.success = True
            mock_result.completed_nodes = []
            mock_result.failed_nodes = []
            mock_result.skipped_nodes = []
            mock_result.total_duration = 0.2
            mock_result.errors = {}

            mock_executor = MagicMock()
            mock_executor.build_graph_from_workflow.return_value = mock_graph
            mock_executor.execute_parallel.return_value = mock_result
            mock_executor_class.return_value = mock_executor

            result = runner.invoke(
                performance_cli, ["parallel", "test-project", "--max-workers", "8"]
            )

            assert result.exit_code in [0, 1]

    def test_parallel_with_failures(self):
        """Test parallel command with failed nodes"""
        runner = CliRunner()

        with patch("cli_performance.get_parallel_executor") as mock_executor_class:
            mock_graph = MagicMock()
            mock_graph.nodes = {
                "node1": MagicMock(agent_name="agent1", dependencies=[]),
                "node2": MagicMock(agent_name="agent2", dependencies=[]),
            }

            mock_result = MagicMock()
            mock_result.success = False
            mock_result.completed_nodes = ["node1"]
            mock_result.failed_nodes = ["node2"]
            mock_result.skipped_nodes = []
            mock_result.total_duration = 0.4
            mock_result.errors = {"node2": "Agent failed"}

            mock_executor = MagicMock()
            mock_executor.build_graph_from_workflow.return_value = mock_graph
            mock_executor.execute_parallel.return_value = mock_result
            mock_executor_class.return_value = mock_executor

            result = runner.invoke(performance_cli, ["parallel", "test-project"])

            assert result.exit_code in [0, 1]

    def test_parallel_with_exception(self):
        """Test parallel command with exception"""
        runner = CliRunner()

        with patch("cli_performance.ParallelExecutor") as mock_executor_class:
            mock_instance = MagicMock()
            mock_instance.build_graph_from_workflow.side_effect = Exception("Parallel error")
            mock_executor_class.return_value = mock_instance

            result = runner.invoke(performance_cli, ["parallel", "test-project"])

            assert result.exit_code == 1


class TestLLMStatsCommand:
    """Test cases for llm-stats command"""

    def test_llm_stats_missing_project_name(self):
        """Test llm-stats command without project name"""
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["llm-stats"])

        assert result.exit_code != 0

    def test_llm_stats_success(self):
        """Test llm-stats command success"""
        runner = CliRunner()

        with patch("cli_performance.get_llm_optimizer") as mock_optimizer:
            mock_instance = MagicMock()
            mock_stats = MagicMock()
            mock_stats.to_dict.return_value = {
                "total_calls": 100,
                "cache_hits": 80,
                "cache_misses": 20,
            }
            mock_instance.get_stats.return_value = mock_stats
            mock_instance.get_cache_info.return_value = {
                "size": 50,
                "max_size": 100,
                "oldest_entry": 1234567890,
                "newest_entry": 1234567900,
            }
            mock_instance.get_rate_limit_info.return_value = {
                "openai": {"available": 90, "max": 100},
                "claude": {"available": 45, "max": 50},
            }
            mock_optimizer.return_value = mock_instance

            result = runner.invoke(performance_cli, ["llm-stats", "test-project"])

            assert result.exit_code in [0, 1]

    def test_llm_stats_with_exception(self):
        """Test llm-stats command with exception"""
        runner = CliRunner()

        with patch("cli_performance.get_llm_optimizer") as mock_optimizer:
            mock_instance = MagicMock()
            mock_instance.get_stats.side_effect = Exception("Stats error")
            mock_optimizer.return_value = mock_instance

            result = runner.invoke(performance_cli, ["llm-stats", "test-project"])

            assert result.exit_code == 1


class TestLLMCacheCommand:
    """Test cases for llm-cache command"""

    def test_llm_cache_missing_project_name(self):
        """Test llm-cache command without project name"""
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["llm-cache"])

        assert result.exit_code != 0

    def test_llm_cache_clear_all(self):
        """Test llm-cache command clearing all cache"""
        runner = CliRunner()

        with patch("cli_performance.get_llm_optimizer") as mock_optimizer:
            mock_instance = MagicMock()
            mock_instance.clear_cache.return_value = 50
            mock_optimizer.return_value = mock_instance

            result = runner.invoke(performance_cli, ["llm-cache", "test-project"])

            assert result.exit_code in [0, 1]

    def test_llm_cache_clear_with_model(self):
        """Test llm-cache command clearing specific model cache"""
        runner = CliRunner()

        with patch("cli_performance.get_llm_optimizer") as mock_optimizer:
            mock_instance = MagicMock()
            mock_instance.clear_cache.return_value = 25
            mock_optimizer.return_value = mock_instance

            result = runner.invoke(
                performance_cli, ["llm-cache", "test-project", "--model", "gpt-3.5-turbo"]
            )

            assert result.exit_code in [0, 1]

    def test_llm_cache_with_exception(self):
        """Test llm-cache command with exception"""
        runner = CliRunner()

        with patch("cli_performance.get_llm_optimizer") as mock_optimizer:
            mock_instance = MagicMock()
            mock_instance.clear_cache.side_effect = Exception("Cache error")
            mock_optimizer.return_value = mock_instance

            result = runner.invoke(performance_cli, ["llm-cache", "test-project"])

            assert result.exit_code == 1


class TestEstimateCostCommand:
    """Test cases for estimate-cost command"""

    def test_estimate_cost_missing_project_name(self):
        """Test estimate-cost command without project name"""
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["estimate-cost"])

        assert result.exit_code != 0

    def test_estimate_cost_autonomous_workflow(self):
        """Test estimate-cost command with autonomous workflow"""
        runner = CliRunner()

        with patch("cli_performance.get_llm_optimizer") as mock_optimizer:
            mock_instance = MagicMock()
            mock_instance._estimate_cost.return_value = 5.50
            mock_optimizer.return_value = mock_instance

            result = runner.invoke(
                performance_cli, ["estimate-cost", "test-project", "--workflow", "autonomous"]
            )

            assert result.exit_code in [0, 1]

    def test_estimate_cost_writing_phase_workflow(self):
        """Test estimate-cost command with writing_phase workflow"""
        runner = CliRunner()

        with patch("cli_performance.get_llm_optimizer") as mock_optimizer:
            mock_instance = MagicMock()
            mock_instance._estimate_cost.return_value = 12.75
            mock_optimizer.return_value = mock_instance

            result = runner.invoke(
                performance_cli,
                ["estimate-cost", "test-project", "--workflow", "writing_phase"],
            )

            assert result.exit_code in [0, 1]

    def test_estimate_cost_unknown_workflow(self):
        """Test estimate-cost command with unknown workflow"""
        runner = CliRunner()

        with patch("cli_performance.get_llm_optimizer") as mock_optimizer:
            mock_instance = MagicMock()
            mock_instance._estimate_cost.return_value = 0.0
            mock_optimizer.return_value = mock_instance

            result = runner.invoke(
                performance_cli, ["estimate-cost", "test-project", "--workflow", "unknown"]
            )

            assert result.exit_code in [0, 1]

    def test_estimate_cost_with_exception(self):
        """Test estimate-cost command with exception"""
        runner = CliRunner()

        with patch("cli_performance.get_llm_optimizer") as mock_optimizer:
            mock_instance = MagicMock()
            mock_instance._estimate_cost.side_effect = Exception("Estimate error")
            mock_optimizer.return_value = mock_instance

            result = runner.invoke(
                performance_cli, ["estimate-cost", "test-project", "--workflow", "autonomous"]
            )

            assert result.exit_code == 1


class TestDisplayProfileReportHelper:
    """Test cases for _display_profile_report helper function"""

    def test_display_profile_report_with_summary(self):
        """Test _display_profile_report with summary data"""
        from cli_performance import _display_profile_report

        mock_report = MagicMock()
        mock_report.total_duration = 5.0
        mock_report.summary = {"agents": 3, "tokens": 2000, "cost": 0.10}
        mock_report.bottlenecks = []

        _display_profile_report(mock_report)

    def test_display_profile_report_with_bottlenecks(self):
        """Test _display_profile_report with bottlenecks"""
        from cli_performance import _display_profile_report

        mock_report = MagicMock()
        mock_report.total_duration = 10.0
        mock_report.summary = {"agents": 5}
        mock_report.bottlenecks = ["Agent 'writer': 6.0s", "Agent 'editor': 7.0s"]

        _display_profile_report(mock_report)

    def test_display_profile_report_with_nested_summary(self):
        """Test _display_profile_report with nested summary"""
        from cli_performance import _display_profile_report

        mock_report = MagicMock()
        mock_report.total_duration = 3.0
        mock_report.summary = {"agents": 2, "nested": {"key1": "value1", "key2": "value2"}}
        mock_report.bottlenecks = []

        _display_profile_report(mock_report)

    def test_display_profile_report_no_bottlenecks(self):
        """Test _display_profile_report with no bottlenecks"""
        from cli_performance import _display_profile_report

        mock_report = MagicMock()
        mock_report.total_duration = 2.5
        mock_report.summary = {"agents": 2}
        mock_report.bottlenecks = []

        _display_profile_report(mock_report)
