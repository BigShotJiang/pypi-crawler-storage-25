"""Tests for multi_chapter_manager.py."""

from pathlib import Path
from time import time

from core.chapter_paginator import ChapterPage
from core.multi_chapter_manager import (
    ChapterContent,
    ChapterIndex,
    ChapterLoadStatus,
    ChapterReference,
    MultiChapterManager,
    MultiChapterManagerConfig,
)


class TestChapterLoadStatus:
    """Tests for ChapterLoadStatus enum."""

    def test_status_values(self):
        """Test ChapterLoadStatus enum values."""
        assert ChapterLoadStatus.NOT_LOADED == "not_loaded"
        assert ChapterLoadStatus.LOADING == "loading"
        assert ChapterLoadStatus.LOADED == "loaded"
        assert ChapterLoadStatus.ERROR == "error"


class TestChapterReference:
    """Tests for ChapterReference dataclass."""

    def test_chapter_reference_creation(self):
        """Test creating ChapterReference."""
        ref = ChapterReference(
            chapter_number=1,
            file_path=Path("/path/to/chapter.md"),
            page_count=5,
            word_count=1000,
            token_count=1500,
            status=ChapterLoadStatus.LOADED,
            last_accessed=time(),
            metadata={"key": "value"},
        )
        assert ref.chapter_number == 1
        assert ref.file_path == Path("/path/to/chapter.md")
        assert ref.page_count == 5
        assert ref.word_count == 1000
        assert ref.token_count == 1500
        assert ref.status == ChapterLoadStatus.LOADED
        assert ref.metadata == {"key": "value"}

    def test_is_loaded_property(self):
        """Test is_loaded property."""
        ref_loaded = ChapterReference(
            chapter_number=1,
            file_path=Path("/path"),
            page_count=1,
            word_count=100,
            token_count=150,
            status=ChapterLoadStatus.LOADED,
        )
        assert ref_loaded.is_loaded is True

        ref_not_loaded = ChapterReference(
            chapter_number=1,
            file_path=Path("/path"),
            page_count=1,
            word_count=100,
            token_count=150,
            status=ChapterLoadStatus.NOT_LOADED,
        )
        assert ref_not_loaded.is_loaded is False

    def test_size_kb_property(self):
        """Test size_kb property."""
        ref = ChapterReference(
            chapter_number=1,
            file_path=Path("/path"),
            page_count=1,
            word_count=100,
            token_count=1024,
            status=ChapterLoadStatus.LOADED,
        )
        assert ref.size_kb == 2.0


class TestChapterIndex:
    """Tests for ChapterIndex dataclass."""

    def test_chapter_index_creation(self):
        """Test creating ChapterIndex."""
        index = ChapterIndex(
            chapter_number=1,
            title="Chapter One",
            word_count=1000,
            page_count=5,
            characters={"Alice", "Bob"},
            locations={"Room 1"},
            key_events=["Event 1"],
            outline_summary="Summary",
        )
        assert index.chapter_number == 1
        assert index.title == "Chapter One"
        assert index.word_count == 1000
        assert index.page_count == 5
        assert index.characters == {"Alice", "Bob"}
        assert index.locations == {"Room 1"}
        assert index.key_events == ["Event 1"]
        assert index.outline_summary == "Summary"

    def test_matches_query_title(self):
        """Test matches_query with title."""
        index = ChapterIndex(
            chapter_number=1,
            title="The Beginning",
            word_count=1000,
            page_count=5,
        )
        assert index.matches_query("beginning") is True
        assert index.matches_query("end") is False

    def test_matches_query_character(self):
        """Test matches_query with characters."""
        index = ChapterIndex(
            chapter_number=1,
            title="Chapter One",
            word_count=1000,
            page_count=5,
            characters={"Alice", "Bob"},
        )
        assert index.matches_query("alice") is True
        assert index.matches_query("Charlie") is False

    def test_matches_query_location(self):
        """Test matches_query with locations."""
        index = ChapterIndex(
            chapter_number=1,
            title="Chapter One",
            word_count=1000,
            page_count=5,
            locations={"Castle", "Forest"},
        )
        assert index.matches_query("castle") is True
        assert index.matches_query("Desert") is False

    def test_matches_query_outline(self):
        """Test matches_query with outline summary."""
        index = ChapterIndex(
            chapter_number=1,
            title="Chapter One",
            word_count=1000,
            page_count=5,
            outline_summary="Hero begins journey",
        )
        assert index.matches_query("journey") is True
        assert index.matches_query("battle") is False

    def test_matches_query_no_match(self):
        """Test matches_query with no match."""
        index = ChapterIndex(
            chapter_number=1,
            title="Chapter One",
            word_count=1000,
            page_count=5,
        )
        assert index.matches_query("nonexistent") is False


class TestChapterContent:
    """Tests for ChapterContent dataclass."""

    def test_chapter_content_creation(self):
        """Test creating ChapterContent."""
        from core.chapter_paginator import PageMetadata

        pages = [
            ChapterPage(
                page_number=1,
                content="Page 1 content",
                metadata=PageMetadata(
                    page_number=1,
                    start_position=0,
                    end_position=17,
                    word_count=3,
                    token_count=4,
                ),
            )
        ]
        content = ChapterContent(
            chapter_number=1,
            content="Full content",
            pages=pages,
            metadata={"key": "value"},
            load_time=time(),
            access_count=1,
        )
        assert content.chapter_number == 1
        assert content.content == "Full content"
        assert len(content.pages) == 1
        assert content.metadata == {"key": "value"}
        assert content.access_count == 1

    def test_get_page_exists(self):
        """Test get_page with existing page."""
        from core.chapter_paginator import PageMetadata

        pages = [
            ChapterPage(
                page_number=1,
                content="Page 1",
                metadata=PageMetadata(
                    page_number=1, start_position=0, end_position=6, word_count=2, token_count=2
                ),
            ),
            ChapterPage(
                page_number=2,
                content="Page 2",
                metadata=PageMetadata(
                    page_number=2, start_position=6, end_position=12, word_count=2, token_count=2
                ),
            ),
        ]
        content = ChapterContent(chapter_number=1, content="Full", pages=pages)

        page = content.get_page(2)
        assert page is not None
        assert page.page_number == 2
        assert page.content == "Page 2"

    def test_get_page_not_exists(self):
        """Test get_page with non-existent page."""
        from core.chapter_paginator import PageMetadata

        pages = [
            ChapterPage(
                page_number=1,
                content="Page 1",
                metadata=PageMetadata(
                    page_number=1, start_position=0, end_position=6, word_count=2, token_count=2
                ),
            ),
        ]
        content = ChapterContent(chapter_number=1, content="Full", pages=pages)

        page = content.get_page(99)
        assert page is None

    def test_get_page_range(self):
        """Test get_page_range method."""
        from core.chapter_paginator import PageMetadata

        pages = [
            ChapterPage(
                page_number=1,
                content="P1",
                metadata=PageMetadata(
                    page_number=1, start_position=0, end_position=2, word_count=1, token_count=1
                ),
            ),
            ChapterPage(
                page_number=2,
                content="P2",
                metadata=PageMetadata(
                    page_number=2, start_position=2, end_position=4, word_count=1, token_count=1
                ),
            ),
            ChapterPage(
                page_number=3,
                content="P3",
                metadata=PageMetadata(
                    page_number=3, start_position=4, end_position=6, word_count=1, token_count=1
                ),
            ),
        ]
        content = ChapterContent(chapter_number=1, content="Full", pages=pages)

        range_pages = content.get_page_range(2, 3)
        assert len(range_pages) == 2
        assert range_pages[0].page_number == 2
        assert range_pages[1].page_number == 3


class TestMultiChapterManagerConfig:
    """Tests for MultiChapterManagerConfig model."""

    def test_config_defaults(self):
        """Test MultiChapterManagerConfig with default values."""
        config = MultiChapterManagerConfig()
        assert config.max_loaded_chapters == 50
        assert config.lazy_loading_enabled is True
        assert config.cache_chapters_enabled is True
        assert config.index_characters is True
        assert config.index_locations is True
        assert config.prefetch_ahead == 2

    def test_config_custom(self):
        """Test MultiChapterManagerConfig with custom values."""
        config = MultiChapterManagerConfig(
            max_loaded_chapters=100,
            lazy_loading_enabled=False,
            prefetch_ahead=5,
        )
        assert config.max_loaded_chapters == 100
        assert config.lazy_loading_enabled is False
        assert config.prefetch_ahead == 5


class TestMultiChapterManager:
    """Tests for MultiChapterManager class."""

    def test_initialization(self, tmp_path):
        """Test MultiChapterManager initialization."""
        manager = MultiChapterManager(tmp_path)
        assert manager.project_root == tmp_path
        assert manager.config.max_loaded_chapters == 50
        assert manager.chapter_references == {}
        assert manager.chapter_indices == {}
        assert manager.loaded_content == {}
        assert manager.chapter_order == []

    def test_initialization_custom_config(self, tmp_path):
        """Test initialization with custom config."""
        config = MultiChapterManagerConfig(max_loaded_chapters=10)
        manager = MultiChapterManager(tmp_path, config)
        assert manager.config.max_loaded_chapters == 10

    def test_build_index_no_directory(self, tmp_path):
        """Test build_index when directory doesn't exist."""
        manager = MultiChapterManager(tmp_path)
        count = manager.build_index("nonexistent_project")
        assert count == 0

    def test_build_index(self, tmp_path):
        """Test build_index with chapter files."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)

        (project_dir / "chapter_001.md").write_text("Chapter one content.")
        (project_dir / "chapter_002.md").write_text("Chapter two content with more words.")

        manager = MultiChapterManager(tmp_path)
        count = manager.build_index("test_project")

        assert count == 2
        assert len(manager.chapter_references) == 2
        assert 1 in manager.chapter_references
        assert 2 in manager.chapter_references
        assert manager.chapter_references[1].word_count == 3
        assert manager.chapter_references[2].word_count == 6
        assert len(manager.chapter_order) == 2
        assert manager.chapter_order == [1, 2]

    def test_build_index_skips_invalid_files(self, tmp_path):
        """Test build_index skips files without chapter numbers."""
        project_dir = tmp_path / "test_project"
        project_dir.mkdir(parents=True, exist_ok=True)

        (project_dir / "chapter_001.md").write_text("Content")
        (project_dir / "invalid.md").write_text("Should be skipped")
        (project_dir / "chapter_003.md").write_text("Content")

        manager = MultiChapterManager(tmp_path)
        count = manager.build_index("test_project")

        assert count == 2
        assert 1 in manager.chapter_references
        assert 3 in manager.chapter_references
        assert 2 not in manager.chapter_references

    def test_load_chapter_already_loaded(self, tmp_path):
        """Test load_chapter when already loaded."""
        manager = MultiChapterManager(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir(parents=True)
        (project_dir / "chapter_001.md").write_text("Content")

        manager.build_index("project")

        content = ChapterContent(
            chapter_number=1,
            content="Cached",
            pages=[],
            load_time=time(),
            access_count=1,
        )
        manager.loaded_content[1] = content

        result = manager.load_chapter(1)
        assert result is not None
        assert result.access_count == 2
        assert result.content == "Cached"

    def test_load_chapter_not_found(self, tmp_path):
        """Test load_chapter when chapter doesn't exist."""
        manager = MultiChapterManager(tmp_path)
        result = manager.load_chapter(999)
        assert result is None

    def test_unload_least_recently_used(self, tmp_path):
        """Test _unload_least_recently_used method."""
        manager = MultiChapterManager(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir(parents=True)
        (project_dir / "chapter_001.md").write_text("Content")
        (project_dir / "chapter_002.md").write_text("Content 2")

        manager.build_index("project")

        content1 = ChapterContent(
            chapter_number=1,
            content="Content 1",
            pages=[],
            load_time=1.0,
            access_count=1,
        )
        content2 = ChapterContent(
            chapter_number=2,
            content="Content 2",
            pages=[],
            load_time=2.0,
            access_count=1,
        )

        manager.loaded_content = {1: content1, 2: content2}
        manager.chapter_references[1].status = ChapterLoadStatus.LOADED
        manager.chapter_references[2].status = ChapterLoadStatus.LOADED

        manager._unload_least_recently_used()

        assert 1 not in manager.loaded_content
        assert 2 in manager.loaded_content
        assert manager.chapter_references[1].status == ChapterLoadStatus.NOT_LOADED

    def test_unload_least_recently_used_empty(self, tmp_path):
        """Test _unload_least_recently_used when empty."""
        manager = MultiChapterManager(tmp_path)
        manager._unload_least_recently_used()
        assert manager.loaded_content == {}

    def test_update_index_from_content(self, tmp_path):
        """Test _update_index_from_content method."""
        from core.chapter_paginator import PageMetadata

        manager = MultiChapterManager(tmp_path)

        manager.chapter_indices[1] = ChapterIndex(
            chapter_number=1,
            title="Chapter 1",
            word_count=100,
            page_count=0,
            characters=set(),
            locations=set(),
            key_events=[],
        )

        page1 = ChapterPage(
            page_number=1,
            content="Content",
            metadata=PageMetadata(
                page_number=1,
                start_position=0,
                end_position=7,
                word_count=1,
                token_count=1,
                characters_present=["Alice"],
                locations_present=["Castle"],
                key_events=["Battle"],
            ),
        )

        content = ChapterContent(
            chapter_number=1,
            content="Full",
            pages=[page1],
            load_time=time(),
            access_count=1,
        )

        manager._update_index_from_content(1, content)

        assert manager.chapter_indices[1].page_count == 1
        assert "Alice" in manager.chapter_indices[1].characters
        assert "Castle" in manager.chapter_indices[1].locations
        assert "Battle" in manager.chapter_indices[1].key_events

    def test_update_index_no_index_exists(self, tmp_path):
        """Test _update_index_from_content when index doesn't exist."""
        manager = MultiChapterManager(tmp_path)

        content = ChapterContent(
            chapter_number=1,
            content="Full",
            pages=[],
            load_time=time(),
            access_count=1,
        )

        manager._update_index_from_content(1, content)

        assert 1 not in manager.chapter_indices

    def test_get_chapter_content(self, tmp_path):
        """Test get_chapter_content method."""
        manager = MultiChapterManager(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir(parents=True)
        (project_dir / "chapter_001.md").write_text("Chapter content here")

        manager.build_index("project")

        content = manager.get_chapter_content(1)
        assert content == "Chapter content here"

    def test_get_chapter_content_not_found(self, tmp_path):
        """Test get_chapter_content when chapter doesn't exist."""
        manager = MultiChapterManager(tmp_path)
        content = manager.get_chapter_content(999)
        assert content is None

    def test_get_chapter_pages(self, tmp_path):
        """Test get_chapter_pages method."""
        manager = MultiChapterManager(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir(parents=True)
        (project_dir / "chapter_001.md").write_text("Content")

        manager.build_index("project")

        pages = manager.get_chapter_pages(1)
        assert isinstance(pages, list)

    def test_get_page_content(self, tmp_path):
        """Test get_page_content method."""
        manager = MultiChapterManager(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir(parents=True)
        (project_dir / "chapter_001.md").write_text("Content")

        manager.build_index("project")

        page_content = manager.get_page_content(1, 1)
        assert page_content is not None

    def test_get_page_content_not_found(self, tmp_path):
        """Test get_page_content when chapter doesn't exist."""
        manager = MultiChapterManager(tmp_path)
        page_content = manager.get_page_content(999, 1)
        assert page_content is None

    def test_get_chapter_range(self, tmp_path):
        """Test get_chapter_range method."""
        manager = MultiChapterManager(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir(parents=True)

        for i in range(1, 4):
            (project_dir / f"chapter_00{i}.md").write_text(f"Chapter {i} content")

        manager.build_index("project")

        results = manager.get_chapter_range(1, 3)
        assert len(results) == 3
        assert results[0][0] == 1
        assert results[1][0] == 2
        assert results[2][0] == 3

    def test_search_chapters(self, tmp_path):
        """Test search_chapters method."""
        manager = MultiChapterManager(tmp_path)

        manager.chapter_indices[1] = ChapterIndex(
            chapter_number=1, title="The Beginning", word_count=100, page_count=1
        )
        manager.chapter_indices[2] = ChapterIndex(
            chapter_number=2, title="The Middle", word_count=100, page_count=1
        )
        manager.chapter_indices[3] = ChapterIndex(
            chapter_number=3, title="The End", word_count=100, page_count=1
        )

        results = manager.search_chapters("beginning")
        assert results == [1]

        results = manager.search_chapters("the")
        assert len(results) == 3

    def test_get_chapters_with_character(self, tmp_path):
        """Test get_chapters_with_character method."""
        manager = MultiChapterManager(tmp_path)

        manager.chapter_indices[1] = ChapterIndex(
            chapter_number=1,
            title="Chapter 1",
            word_count=100,
            page_count=1,
            characters={"Alice", "Bob"},
        )
        manager.chapter_indices[2] = ChapterIndex(
            chapter_number=2,
            title="Chapter 2",
            word_count=100,
            page_count=1,
            characters={"Charlie"},
        )
        manager.chapter_indices[3] = ChapterIndex(
            chapter_number=3,
            title="Chapter 3",
            word_count=100,
            page_count=1,
            characters={"Alice"},
        )

        results = manager.get_chapters_with_character("Alice")
        assert sorted(results) == [1, 3]

        results = manager.get_chapters_with_character("Bob")
        assert results == [1]

    def test_get_chapters_with_location(self, tmp_path):
        """Test get_chapters_with_location method."""
        manager = MultiChapterManager(tmp_path)

        manager.chapter_indices[1] = ChapterIndex(
            chapter_number=1,
            title="Chapter 1",
            word_count=100,
            page_count=1,
            locations={"Castle", "Forest"},
        )
        manager.chapter_indices[2] = ChapterIndex(
            chapter_number=2,
            title="Chapter 2",
            word_count=100,
            page_count=1,
            locations={"Desert"},
        )

        results = manager.get_chapters_with_location("Castle")
        assert results == [1]

        results = manager.get_chapters_with_location("Forest")
        assert results == [1]

        results = manager.get_chapters_with_location("Desert")
        assert results == [2]

    def test_get_project_statistics(self, tmp_path):
        """Test get_project_statistics method."""
        manager = MultiChapterManager(tmp_path)

        manager.chapter_references[1] = ChapterReference(
            chapter_number=1,
            file_path=Path("/path1"),
            page_count=1,
            word_count=1000,
            token_count=1500,
        )
        manager.chapter_references[2] = ChapterReference(
            chapter_number=2,
            file_path=Path("/path2"),
            page_count=1,
            word_count=2000,
            token_count=3000,
        )

        manager.chapter_indices[1] = ChapterIndex(
            chapter_number=1,
            title="Ch1",
            word_count=1000,
            page_count=1,
            characters={"Alice"},
            locations={"Castle"},
        )
        manager.chapter_indices[2] = ChapterIndex(
            chapter_number=2,
            title="Ch2",
            word_count=2000,
            page_count=1,
            characters={"Bob"},
            locations={"Forest"},
        )

        manager.loaded_content[1] = ChapterContent(
            chapter_number=1,
            content="",
            pages=[],
            load_time=time(),
            access_count=1,
        )

        stats = manager.get_project_statistics()

        assert stats["total_chapters"] == 2
        assert stats["total_words"] == 3000
        assert stats["total_tokens"] == 4500
        assert stats["loaded_chapters"] == 1
        assert stats["unique_characters"] == 2
        assert stats["unique_locations"] == 2
        assert stats["avg_words_per_chapter"] == 1500
        assert stats["avg_tokens_per_chapter"] == 2250

    def test_get_project_statistics_empty(self, tmp_path):
        """Test get_project_statistics with no chapters."""
        manager = MultiChapterManager(tmp_path)

        stats = manager.get_project_statistics()

        assert stats["total_chapters"] == 0
        assert stats["total_words"] == 0
        assert stats["total_tokens"] == 0
        assert stats["loaded_chapters"] == 0
        assert stats["unique_characters"] == 0
        assert stats["unique_locations"] == 0
        assert stats["avg_words_per_chapter"] == 0
        assert stats["avg_tokens_per_chapter"] == 0

    def test_prefetch_chapters(self, tmp_path):
        """Test prefetch_chapters method."""
        manager = MultiChapterManager(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir(parents=True)

        for i in range(1, 6):
            (project_dir / f"chapter_00{i}.md").write_text(f"Chapter {i}")

        manager.build_index("project")

        manager.prefetch_chapters(1)

        assert 2 in manager.loaded_content
        assert 3 in manager.loaded_content

    def test_clear_cache(self, tmp_path):
        """Test clear_cache method."""
        manager = MultiChapterManager(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir(parents=True)
        (project_dir / "chapter_001.md").write_text("Content")

        manager.build_index("project")
        manager.load_chapter(1)

        assert len(manager.loaded_content) == 1

        manager.clear_cache()

        assert len(manager.loaded_content) == 0
        assert manager.chapter_references[1].status == ChapterLoadStatus.NOT_LOADED

    def test_get_loading_status_loaded(self, tmp_path):
        """Test get_loading_status for loaded chapter."""
        manager = MultiChapterManager(tmp_path)

        manager.loaded_content[1] = ChapterContent(
            chapter_number=1,
            content="",
            pages=[],
            load_time=time(),
            access_count=1,
        )

        status = manager.get_loading_status(1)
        assert status == ChapterLoadStatus.LOADED

    def test_get_loading_status_in_reference(self, tmp_path):
        """Test get_loading_status for chapter in references."""
        manager = MultiChapterManager(tmp_path)

        manager.chapter_references[1] = ChapterReference(
            chapter_number=1,
            file_path=Path("/path"),
            page_count=1,
            word_count=100,
            token_count=150,
            status=ChapterLoadStatus.LOADING,
        )

        status = manager.get_loading_status(1)
        assert status == ChapterLoadStatus.LOADING

    def test_get_loading_status_not_found(self, tmp_path):
        """Test get_loading_status for non-existent chapter."""
        manager = MultiChapterManager(tmp_path)

        status = manager.get_loading_status(999)
        assert status == ChapterLoadStatus.NOT_LOADED

    def test_batch_load_chapters(self, tmp_path):
        """Test batch_load_chapters method."""
        manager = MultiChapterManager(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir(parents=True)

        for i in range(1, 4):
            (project_dir / f"chapter_00{i}.md").write_text(f"Chapter {i}")

        manager.build_index("project")

        results = manager.batch_load_chapters([1, 2, 99])

        assert results[1] is True
        assert results[2] is True
        assert results[99] is False
