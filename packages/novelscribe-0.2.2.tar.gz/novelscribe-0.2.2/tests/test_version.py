"""Tests for version management system."""

from __future__ import annotations

import json
import subprocess
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import MagicMock, patch

from core.version import VersionManager, check_updates, get_version, notify_if_update_available


class TestVersionManager:
    """Test VersionManager class."""

    def test_version_manager_initialization(self):
        """Test VersionManager can be initialized."""
        manager = VersionManager()
        assert manager is not None
        assert hasattr(manager, "current_version")
        assert hasattr(manager, "package_name")
        assert manager.package_name == "novelscribe"

    def test_get_version_info(self):
        """Test getting version info."""
        manager = VersionManager()
        info = manager.get_version_info()
        assert isinstance(info, dict)
        assert "current" in info
        assert "package" in info
        assert info["package"] == "novelscribe"

    def test_is_newer_version_greater(self):
        """Test version comparison with greater version."""
        manager = VersionManager()
        assert manager._is_newer_version("99.0.0") is True

    def test_is_newer_version_equal(self):
        """Test version comparison with equal version."""
        manager = VersionManager()
        assert manager._is_newer_version(manager.current_version) is False

    def test_is_newer_version_smaller(self):
        """Test version comparison with smaller version."""
        manager = VersionManager()
        assert manager._is_newer_version("0.0.1") is False

    def test_get_upgrade_command(self):
        """Test getting upgrade command."""
        manager = VersionManager()
        cmd = manager._get_upgrade_command()
        assert isinstance(cmd, str)
        assert "upgrade" in cmd.lower() or "--upgrade" in cmd.lower()
        assert "novelscribe" in cmd

    @patch("requests.get")
    def test_check_for_updates_success(self, mock_get):
        """Test successful update check."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "info": {"version": "99.0.0", "summary": "Test package"},
            "releases": {"99.0.0": [{"upload_time": "2024-01-01"}]},
        }
        mock_get.return_value = mock_response

        manager = VersionManager()
        result = manager.check_for_updates(verbose=False, force=True)

        if result:
            assert result["update_available"] is True
            assert result["latest"] == "99.0.0"

    @patch("requests.get")
    def test_check_for_updates_no_update(self, mock_get):
        """Test when no update available."""
        manager = VersionManager()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "info": {"version": manager.current_version, "summary": "Test package"}
        }
        mock_get.return_value = mock_response

        result = manager.check_for_updates(verbose=False, force=True)

        if result:
            assert result["update_available"] is False

    @patch("requests.get")
    def test_check_for_updates_network_error(self, mock_get):
        """Test update check with network error."""
        import requests

        mock_get.side_effect = requests.RequestException("Network error")

        manager = VersionManager()
        result = manager.check_for_updates(verbose=False, force=True)

        assert result is None

    def test_cache_write_and_read(self, tmp_path):
        """Test update cache write and read cycle."""
        manager = VersionManager()
        cache_file = tmp_path / "update_cache.json"

        test_data = {
            "current": "0.2.0",
            "latest": "0.3.0",
            "update_available": True,
        }

        with patch.object(VersionManager, "__init__", lambda self: None):
            manager._write_cache = lambda d: cache_file.write_text(json.dumps(d, indent=2))
            manager._read_cache = lambda: (
                json.loads(cache_file.read_text()) if cache_file.exists() else None
            )
            manager._write_cache(test_data)

            cached = manager._read_cache()
            assert cached is not None
            assert cached["latest"] == "0.3.0"

    @patch.object(VersionManager, "check_for_updates")
    @patch("subprocess.run")
    def test_perform_self_update_success(self, mock_run, mock_check):
        """Test successful self-update."""
        mock_check.return_value = {
            "current": "0.2.0",
            "latest": "0.3.0",
            "update_available": True,
        }
        mock_run.return_value = MagicMock(returncode=0)

        manager = VersionManager()
        result = manager.perform_self_update()
        assert result is True

    @patch.object(VersionManager, "check_for_updates")
    def test_perform_self_update_already_latest(self, mock_check):
        """Test self-update when already on latest."""
        mock_check.return_value = {
            "current": "0.2.0",
            "latest": "0.2.0",
            "update_available": False,
        }

        manager = VersionManager()
        result = manager.perform_self_update()
        assert result is True

    @patch.object(VersionManager, "check_for_updates")
    def test_perform_self_update_check_fails(self, mock_check):
        """Test self-update when check fails."""
        mock_check.return_value = None

        manager = VersionManager()
        result = manager.perform_self_update()
        assert result is False

    def test_get_current_version_pyproject_fallback(self):
        """Test _get_current_version falls back to pyproject.toml."""
        manager = VersionManager.__new__(VersionManager)
        with patch("core.version.get_imported_version", side_effect=RuntimeError("broken")):
            with patch("core.version.toml.load", return_value={"project": {"version": "9.9.9"}}):
                with patch.object(Path, "exists", return_value=True):
                    result = manager._get_current_version()
                    assert result == "9.9.9"

    def test_get_current_version_all_fail(self):
        """Test _get_current_version returns 0.0.0 when all methods fail."""
        manager = VersionManager.__new__(VersionManager)
        with patch("core.version.get_imported_version", side_effect=RuntimeError("broken")):
            with patch.object(Path, "exists", return_value=False):
                result = manager._get_current_version()
                assert result == "0.0.0"

    def test_read_cache_file_not_exists(self):
        """Test _read_cache when cache file does not exist."""
        manager = VersionManager()
        with patch.object(Path, "exists", return_value=False):
            assert manager._read_cache() is None

    def test_read_cache_expired(self, tmp_path):
        """Test _read_cache with expired cache entry."""
        cache_file = tmp_path / "update_cache.json"
        old_time = (datetime.now() - timedelta(hours=48)).isoformat()
        cache_file.write_text(json.dumps({"cached_at": old_time, "latest": "1.0.0"}))

        with patch("core.version.CACHE_FILE", cache_file):
            manager = VersionManager()
            result = manager._read_cache()
            assert result is None

    def test_read_cache_corrupt_json(self, tmp_path):
        """Test _read_cache with corrupt JSON."""
        cache_file = tmp_path / "update_cache.json"
        cache_file.write_text("not valid json{{{")

        with patch("core.version.CACHE_FILE", cache_file):
            manager = VersionManager()
            assert manager._read_cache() is None

    def test_read_cache_valid(self, tmp_path):
        """Test _read_cache with valid fresh cache."""
        cache_file = tmp_path / "update_cache.json"
        fresh_time = datetime.now().isoformat()
        cache_file.write_text(
            json.dumps(
                {
                    "cached_at": fresh_time,
                    "latest": "1.0.0",
                    "update_available": True,
                }
            )
        )

        with patch("core.version.CACHE_FILE", cache_file):
            manager = VersionManager()
            result = manager._read_cache()
            assert result is not None
            assert result.get("cached") is True

    def test_write_cache_exception(self):
        """Test _write_cache handles exception silently."""
        manager = VersionManager()
        with patch.object(Path, "mkdir", side_effect=PermissionError("denied")):
            manager._write_cache({"test": True})

    @patch("requests.get")
    def test_check_for_updates_cache_hit(self, mock_get):
        """Test check_for_updates returns cached result when not forced."""
        manager = VersionManager()
        cached_data = {
            "current": manager.current_version,
            "latest": "99.0.0",
            "update_available": True,
            "cached": True,
        }
        with patch.object(manager, "_read_cache", return_value=cached_data):
            result = manager.check_for_updates(force=False)
            assert result == cached_data
            mock_get.assert_not_called()

    @patch("requests.get")
    def test_check_for_updates_verbose_no_update(self, mock_get, capsys):
        """Test verbose mode when already on latest."""
        manager = VersionManager()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "info": {"version": manager.current_version, "summary": "Test"},
            "releases": {},
        }
        mock_get.return_value = mock_response
        with patch.object(manager, "_write_cache"):
            result = manager.check_for_updates(verbose=True, force=True)
            assert result["update_available"] is False
            captured = capsys.readouterr()
            assert "latest version" in captured.out

    @patch("requests.get")
    def test_check_for_updates_verbose_network_error(self, mock_get, capsys):
        """Test verbose mode with network error prints message."""
        import requests

        mock_get.side_effect = requests.RequestException("Connection refused")
        manager = VersionManager()
        result = manager.check_for_updates(verbose=True, force=True)
        assert result is None
        captured = capsys.readouterr()
        assert "Could not check" in captured.out

    @patch("requests.get")
    def test_check_for_updates_verbose_generic_error(self, mock_get, capsys):
        """Test verbose mode with generic exception prints message."""
        mock_get.side_effect = ValueError("bad data")
        manager = VersionManager()
        result = manager.check_for_updates(verbose=True, force=True)
        assert result is None
        captured = capsys.readouterr()
        assert "Error checking" in captured.out

    def test_get_release_notes_exception(self):
        """Test _get_release_notes handles exception gracefully."""
        manager = VersionManager()
        bad_data = MagicMock()
        bad_data.get.side_effect = RuntimeError("boom")
        result = manager._get_release_notes(bad_data, "1.0.0")
        assert result == "Visit PyPI for details"

    def test_get_release_notes_no_summary_or_description(self):
        """Test _get_release_notes with empty info."""
        manager = VersionManager()
        result = manager._get_release_notes({"info": {}}, "1.0.0")
        assert result == "Visit PyPI for details"

    def test_get_release_notes_uses_summary(self):
        """Test _get_release_notes returns summary when available."""
        manager = VersionManager()
        result = manager._get_release_notes(
            {"info": {"summary": "A great novel tool", "description": "x" * 600}}, "1.0.0"
        )
        assert result == "A great novel tool"

    @patch("core.version.subprocess")
    def test_installed_with_pipx_true(self, mock_subprocess):
        """Test _installed_with_pipx returns True."""
        mock_result = MagicMock()
        mock_result.stdout = "novelscribe 0.2.0"
        mock_subprocess.run.return_value = mock_result
        manager = VersionManager()
        assert manager._installed_with_pipx() is True

    @patch("core.version.subprocess")
    def test_installed_with_pipx_false(self, mock_subprocess):
        """Test _installed_with_pipx returns False when not found."""
        mock_result = MagicMock()
        mock_result.stdout = "other-package 1.0"
        mock_subprocess.run.return_value = mock_result
        manager = VersionManager()
        assert manager._installed_with_pipx() is False

    @patch("core.version.subprocess")
    def test_installed_with_pipx_exception(self, mock_subprocess):
        """Test _installed_with_pipx returns False on exception."""
        mock_subprocess.run.side_effect = FileNotFoundError("no pipx")
        manager = VersionManager()
        assert manager._installed_with_pipx() is False

    @patch("core.version.subprocess")
    def test_installed_with_uv_true(self, mock_subprocess):
        """Test _installed_with_uv returns True."""
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_subprocess.run.return_value = mock_result
        manager = VersionManager()
        assert manager._installed_with_uv() is True

    @patch("core.version.subprocess")
    def test_installed_with_uv_false(self, mock_subprocess):
        """Test _installed_with_uv returns False."""
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_subprocess.run.return_value = mock_result
        manager = VersionManager()
        assert manager._installed_with_uv() is False

    @patch("core.version.subprocess")
    def test_installed_with_uv_exception(self, mock_subprocess):
        """Test _installed_with_uv returns False on exception."""
        mock_subprocess.run.side_effect = FileNotFoundError("no uv")
        manager = VersionManager()
        assert manager._installed_with_uv() is False

    @patch("core.version.subprocess")
    def test_installed_with_pip_true(self, mock_subprocess):
        """Test _installed_with_pip returns True."""
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_subprocess.run.return_value = mock_result
        manager = VersionManager()
        assert manager._installed_with_pip() is True

    @patch("core.version.subprocess")
    def test_installed_with_pip_exception(self, mock_subprocess):
        """Test _installed_with_pip returns False on exception."""
        mock_subprocess.run.side_effect = FileNotFoundError("no pip")
        manager = VersionManager()
        assert manager._installed_with_pip() is False

    def test_upgrade_command_pipx(self):
        """Test upgrade command when installed via pipx."""
        manager = VersionManager()
        with patch.object(manager, "_installed_with_pipx", return_value=True):
            assert manager._get_upgrade_command() == "pipx upgrade novelscribe"

    def test_upgrade_command_uv(self):
        """Test upgrade command when installed via uv."""
        manager = VersionManager()
        with patch.object(manager, "_installed_with_pipx", return_value=False):
            with patch.object(manager, "_installed_with_uv", return_value=True):
                assert "uv pip install --upgrade" in manager._get_upgrade_command()

    def test_upgrade_command_pip(self):
        """Test upgrade command falls back to pip."""
        manager = VersionManager()
        with patch.object(manager, "_installed_with_pipx", return_value=False):
            with patch.object(manager, "_installed_with_uv", return_value=False):
                assert manager._get_upgrade_command() == "pip install --upgrade novelscribe"

    def test_is_newer_version_exception(self):
        """Test _is_newer_version returns False on bad input."""
        manager = VersionManager()
        assert manager._is_newer_version("not.a.version") is False

    @patch.object(VersionManager, "check_for_updates")
    @patch("subprocess.run")
    def test_perform_self_update_failure(self, mock_run, mock_check):
        """Test self-update with non-zero return code."""
        mock_check.return_value = {
            "current": "0.2.0",
            "latest": "0.3.0",
            "update_available": True,
        }
        mock_run.return_value = MagicMock(returncode=1, stderr="Permission denied")
        manager = VersionManager()
        assert manager.perform_self_update() is False

    @patch.object(VersionManager, "check_for_updates")
    @patch("subprocess.run")
    def test_perform_self_update_timeout(self, mock_run, mock_check):
        """Test self-update with timeout."""
        mock_check.return_value = {
            "current": "0.2.0",
            "latest": "0.3.0",
            "update_available": True,
        }
        mock_run.side_effect = subprocess.TimeoutExpired(cmd="pip", timeout=120)
        manager = VersionManager()
        assert manager.perform_self_update() is False

    @patch.object(VersionManager, "check_for_updates")
    @patch("subprocess.run")
    def test_perform_self_update_exception(self, mock_run, mock_check):
        """Test self-update with unexpected exception."""
        mock_check.return_value = {
            "current": "0.2.0",
            "latest": "0.3.0",
            "update_available": True,
        }
        mock_run.side_effect = OSError("Something broke")
        manager = VersionManager()
        assert manager.perform_self_update() is False


class TestVersionFunctions:
    """Test version module functions."""

    def test_get_version(self):
        """Test get_version function."""
        ver = get_version()
        assert isinstance(ver, str)
        assert len(ver) > 0

    def test_check_updates(self):
        """Test check_updates function."""
        result = check_updates()
        assert result is None or isinstance(result, dict)

    @patch.object(VersionManager, "check_for_updates")
    def test_notify_if_update_available_with_update(self, mock_check):
        """Test update notification shows when update available."""
        mock_check.return_value = {
            "current": "0.2.0",
            "latest": "0.3.0",
            "update_available": True,
            "upgrade_command": "pip install --upgrade novelscribe",
        }
        notify_if_update_available()

    @patch.object(VersionManager, "check_for_updates")
    def test_notify_if_update_available_no_update(self, mock_check):
        """Test update notification silent when no update."""
        mock_check.return_value = {
            "current": "0.2.0",
            "latest": "0.2.0",
            "update_available": False,
        }
        notify_if_update_available()
