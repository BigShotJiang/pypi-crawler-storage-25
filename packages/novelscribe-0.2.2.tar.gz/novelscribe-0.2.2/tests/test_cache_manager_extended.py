"""
Comprehensive tests for cache_manager.py to increase coverage to 90%+.
Tests edge cases, TTL, hot/cold tracking, and optimization.
"""

from datetime import datetime, timedelta, timezone

from novel_harness.core.cache_manager import (
    CacheEntry,
    CacheManager,
    CacheManagerConfig,
)


class TestCacheEntry:
    """Test CacheEntry dataclass."""

    def test_touch_updates_access_stats(self):
        """Test that touch() updates access statistics."""
        entry = CacheEntry(
            key="test_key",
            value="test_value",
            size_bytes=10,
            access_count=5,
        )

        entry.touch()

        assert entry.access_count == 6
        assert entry.last_accessed is not None

    def test_is_expired_with_expiration(self):
        """Test is_expired returns True when expired."""
        entry = CacheEntry(
            key="test_key",
            value="test_value",
            size_bytes=10,
            expiration_time=datetime.now(timezone.utc) - timedelta(hours=1),
        )

        assert entry.is_expired() is True

    def test_is_expired_without_expiration(self):
        """Test is_expired returns False when no expiration set."""
        entry = CacheEntry(
            key="test_key",
            value="test_value",
            size_bytes=10,
        )

        assert entry.is_expired() is False

    def test_age_seconds(self):
        """Test age_seconds calculation."""
        entry = CacheEntry(
            key="test_key",
            value="test_value",
            size_bytes=10,
            created_at=datetime.now(timezone.utc) - timedelta(seconds=100),
        )

        assert entry.age_seconds() >= 100


class TestCacheManagerConfig:
    """Test CacheManagerConfig."""

    def test_default_config(self):
        """Test default configuration."""
        config = CacheManagerConfig()

        assert config.max_size_mb == 100.0
        assert config.max_entries == 100
        assert config.default_ttl_seconds is None
        assert config.enable_hot_cold_tracking is True
        assert config.hot_threshold == 10
        assert config.cold_threshold == 2

    def test_custom_config(self):
        """Test custom configuration."""
        config = CacheManagerConfig(
            max_size_mb=50.0,
            max_entries=50,
            default_ttl_seconds=3600,
            enable_hot_cold_tracking=False,
        )

        assert config.max_size_mb == 50.0
        assert config.max_entries == 50
        assert config.default_ttl_seconds == 3600
        assert config.enable_hot_cold_tracking is False


class TestCacheManagerInit:
    """Test CacheManager initialization."""

    def test_init_with_defaults(self):
        """Test initialization with defaults."""
        manager = CacheManager()

        assert manager.config is not None
        assert manager.cache == {}
        assert manager.current_size_bytes == 0
        assert manager.hits == 0
        assert manager.misses == 0

    def test_init_with_config(self):
        """Test initialization with custom config."""
        config = CacheManagerConfig(max_size_mb=50.0)
        manager = CacheManager(config=config)

        assert manager.config.max_size_mb == 50.0


class TestCacheManagerGet:
    """Test cache get operations."""

    def test_get_missing_key(self):
        """Test getting non-existent key."""
        manager = CacheManager()

        result = manager.get("missing_key")

        assert result is None
        assert manager.misses == 1

    def test_get_expired_key(self):
        """Test getting expired key."""
        manager = CacheManager()

        entry = CacheEntry(
            key="expired_key",
            value="test_value",
            size_bytes=10,
            expiration_time=datetime.now(timezone.utc) - timedelta(hours=1),
        )
        manager.cache["expired_key"] = entry
        manager.current_size_bytes = 10

        result = manager.get("expired_key")

        assert result is None
        assert "expired_key" not in manager.cache
        assert manager.expirations == 1

    def test_get_valid_key(self):
        """Test getting valid key."""
        manager = CacheManager()
        manager.put("test_key", "test_value")

        result = manager.get("test_key")

        assert result == "test_value"
        assert manager.hits == 1


class TestCacheManagerPut:
    """Test cache put operations."""

    def test_put_new_key(self):
        """Test putting new key."""
        manager = CacheManager()

        manager.put("test_key", "test_value")

        assert "test_key" in manager.cache
        assert manager.cache["test_key"].value == "test_value"

    def test_put_string_value(self):
        """Test putting string value."""
        manager = CacheManager()

        manager.put("str_key", "hello world")

        entry = manager.cache["str_key"]
        assert entry.size_bytes == len("hello world".encode("utf-8"))

    def test_put_dict_value(self):
        """Test putting dict value."""
        manager = CacheManager()

        manager.put("dict_key", {"a": 1, "b": 2})

        assert "dict_key" in manager.cache

    def test_put_list_value(self):
        """Test putting list value."""
        manager = CacheManager()

        manager.put("list_key", [1, 2, 3])

        assert "list_key" in manager.cache

    def test_put_with_ttl(self):
        """Test putting value with TTL."""
        manager = CacheManager()

        manager.put("ttl_key", "test_value", ttl_seconds=3600)

        entry = manager.cache["ttl_key"]
        assert entry.expiration_time is not None
        assert entry.expiration_time > datetime.now(timezone.utc)

    def test_put_with_metadata(self):
        """Test putting value with metadata."""
        manager = CacheManager()

        manager.put("meta_key", "test_value", metadata={"source": "test"})

        entry = manager.cache["meta_key"]
        assert entry.metadata == {"source": "test"}

    def test_put_updates_existing_key(self):
        """Test updating existing key."""
        manager = CacheManager()
        manager.put("existing_key", "old_value")

        manager.put("existing_key", "new_value")

        assert manager.cache["existing_key"].value == "new_value"


class TestCacheManagerEviction:
    """Test cache eviction."""

    def test_eviction_by_size(self):
        """Test eviction when exceeding max size."""
        config = CacheManagerConfig(max_size_mb=0.000001)  # Very small
        manager = CacheManager(config=config)

        manager.put("key1", "x" * 1000)
        manager.put("key2", "y" * 1000)

        assert manager.evictions > 0

    def test_eviction_by_entry_count(self):
        """Test eviction when exceeding max entries."""
        config = CacheManagerConfig(max_entries=3)
        manager = CacheManager(config=config)

        for i in range(5):
            manager.put(f"key{i}", f"value{i}")

        assert len(manager.cache) <= 3
        assert manager.evictions >= 2


class TestCacheManagerInvalidate:
    """Test cache invalidation."""

    def test_invalidate_existing_key(self):
        """Test invalidating existing key."""
        manager = CacheManager()
        manager.put("test_key", "test_value")

        manager.invalidate("test_key")

        assert "test_key" not in manager.cache

    def test_invalidate_missing_key(self):
        """Test invalidating non-existent key."""
        manager = CacheManager()

        manager.invalidate("missing_key")

        assert manager.evictions == 0


class TestCacheManagerClear:
    """Test cache clearing."""

    def test_clear_all_entries(self):
        """Test clearing all entries."""
        manager = CacheManager()
        manager.put("key1", "value1")
        manager.put("key2", "value2")

        manager.clear()

        assert len(manager.cache) == 0
        assert manager.current_size_bytes == 0
        assert manager.hits == 0
        assert manager.misses == 0

    def test_clear_resets_counters(self):
        """Test that clear resets statistics."""
        manager = CacheManager()
        manager.put("key1", "value1")
        manager.get("key1")
        manager.get("missing")

        manager.clear()

        assert manager.evictions == 0
        assert manager.expirations == 0


class TestCacheManagerClearExpired:
    """Test expired entry clearing."""

    def test_clear_expired_entries(self):
        """Test clearing expired entries."""
        manager = CacheManager()

        expired_entry = CacheEntry(
            key="expired",
            value="test",
            size_bytes=10,
            expiration_time=datetime.now(timezone.utc) - timedelta(hours=1),
        )
        manager.cache["expired"] = expired_entry
        manager.current_size_bytes = 10

        valid_entry = CacheEntry(
            key="valid",
            value="test",
            size_bytes=10,
        )
        manager.cache["valid"] = valid_entry
        manager.current_size_bytes += 10

        count = manager.clear_expired()

        assert count == 1
        assert "expired" not in manager.cache
        assert "valid" in manager.cache


class TestCacheManagerWarmCache:
    """Test cache warming."""

    def test_warm_cache_with_loader(self):
        """Test warming cache with loader function."""
        manager = CacheManager()

        def loader(key):
            return f"loaded_{key}"

        manager.warm_cache(["key1", "key2"], loader)

        assert manager.get("key1") == "loaded_key1"
        assert manager.get("key2") == "loaded_key2"

    def test_warm_cache_skips_existing(self):
        """Test that warming skips existing keys."""
        manager = CacheManager()
        manager.put("existing", "original")

        def loader(key):
            return f"loaded_{key}"

        manager.warm_cache(["existing"], loader)

        assert manager.get("existing") == "original"

    def test_warm_cache_handles_loader_error(self):
        """Test that warming handles loader errors."""
        manager = CacheManager()

        def loader(key):
            raise Exception("Loader error")

        manager.warm_cache(["key1"], loader)

        assert manager.get("key1") is None

    def test_warm_cache_skips_none_values(self):
        """Test that warming skips None values."""
        manager = CacheManager()

        def loader(key):
            return None

        manager.warm_cache(["key1"], loader)

        assert manager.get("key1") is None


class TestCacheManagerOptimize:
    """Test cache optimization."""

    def test_optimize_removes_cold(self):
        """Test that optimize removes cold entries."""
        config = CacheManagerConfig(enable_hot_cold_tracking=True)
        manager = CacheManager(config=config)

        for i in range(5):
            manager.put(f"cold{i}", f"value{i}")

        manager.optimize()

        assert len(manager.cache) >= 0

    def test_optimize_without_hot_cold_tracking(self):
        """Test optimize without hot/cold tracking."""
        config = CacheManagerConfig(enable_hot_cold_tracking=False)
        manager = CacheManager(config=config)

        manager.put("key1", "x" * 1000)

        manager.optimize()

        assert "key1" in manager.cache


class TestCacheManagerHotColdKeys:
    """Test hot/cold key identification."""

    def test_identify_hot_keys_disabled(self):
        """Test hot key identification when disabled."""
        config = CacheManagerConfig(enable_hot_cold_tracking=False)
        manager = CacheManager(config=config)

        result = manager.identify_hot_keys()

        assert result == []

    def test_identify_hot_keys_below_threshold(self):
        """Test hot key identification when below threshold."""
        manager = CacheManager()
        manager.put("key1", "value1")

        result = manager.identify_hot_keys()

        assert "key1" not in result

    def test_identify_hot_keys_above_threshold(self):
        """Test hot key identification when above threshold."""
        manager = CacheManager()
        manager.put("key1", "value1")

        for _ in range(15):
            manager.get("key1")

        result = manager.identify_hot_keys()

        assert "key1" in result

    def test_identify_cold_keys_disabled(self):
        """Test cold key identification when disabled."""
        config = CacheManagerConfig(enable_hot_cold_tracking=False)
        manager = CacheManager(config=config)

        result = manager.identify_cold_keys()

        assert result == []


class TestCacheManagerStatistics:
    """Test statistics."""

    def test_get_statistics(self):
        """Test getting statistics."""
        manager = CacheManager()
        manager.put("key1", "value1")
        manager.get("key1")
        manager.get("missing")

        stats = manager.get_statistics()

        assert stats["entries"] == 1
        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert "hit_rate" in stats
        assert "current_size_mb" in stats

    def test_hit_rate_calculation(self):
        """Test hit rate calculation."""
        manager = CacheManager()
        manager.put("key1", "value1")

        for _ in range(3):
            manager.get("key1")

        for _ in range(1):
            manager.get("missing")

        stats = manager.get_statistics()

        assert "75.00%" in stats["hit_rate"]


class TestCacheManagerAccessPattern:
    """Test access pattern analysis."""

    def test_access_pattern_insufficient_data(self):
        """Test access pattern with no history."""
        manager = CacheManager()

        pattern = manager.get_access_pattern()

        assert pattern["pattern"] == "insufficient_data"

    def test_access_pattern_stable(self):
        """Test access pattern with stable pattern."""
        manager = CacheManager()
        manager.put("key1", "value1")
        manager.put("key2", "value2")
        manager.put("key3", "value3")
        manager.put("key4", "value4")
        manager.put("key5", "value5")

        for _ in range(10):
            manager.get("key1")

        pattern = manager.get_access_pattern()

        # Pattern is "stable" when unique_keys < len(cache) * 0.5
        # With 1 unique key out of 5 entries: 1 < 2.5 = True
        assert pattern["pattern"] == "stable"
        assert pattern["total_accesses"] == 10
        assert pattern["unique_keys"] == 1

    def test_access_pattern_diverse(self):
        """Test access pattern with diverse pattern."""
        manager = CacheManager()
        manager.put("key1", "value1")
        manager.put("key2", "value2")

        for _ in range(10):
            manager.get("key1")
            manager.get("key2")

        pattern = manager.get_access_pattern()

        assert pattern["pattern"] == "diverse"


class TestCacheManagerSetTTL:
    """Test TTL setting."""

    def test_set_ttl_existing_key(self):
        """Test setting TTL for existing key."""
        manager = CacheManager()
        manager.put("key1", "value1")

        manager.set_ttl("key1", 3600)

        entry = manager.cache["key1"]
        assert entry.expiration_time is not None

    def test_set_ttl_missing_key(self):
        """Test setting TTL for missing key."""
        manager = CacheManager()

        manager.set_ttl("missing", 3600)

        assert manager.get("missing") is None


class TestCacheManagerGetEntryInfo:
    """Test entry info retrieval."""

    def test_get_entry_info_existing(self):
        """Test getting info for existing entry."""
        manager = CacheManager()
        manager.put("key1", "value1")
        manager.get("key1")

        info = manager.get_entry_info("key1")

        assert info is not None
        assert info["key"] == "key1"
        assert info["access_count"] == 1  # Only touched once during get
        assert "created_at" in info
        assert "last_accessed" in info

    def test_get_entry_info_missing(self):
        """Test getting info for missing entry."""
        manager = CacheManager()

        info = manager.get_entry_info("missing")

        assert info is None


class TestCacheManagerBulkInvalidate:
    """Test bulk invalidation."""

    def test_bulk_invalidate_matching_pattern(self):
        """Test bulk invalidation with matching pattern."""
        manager = CacheManager()
        manager.put("user:1", "value1")
        manager.put("user:2", "value2")
        manager.put("other:1", "value3")

        manager.bulk_invalidate(r"user:\d+")

        assert "user:1" not in manager.cache
        assert "user:2" not in manager.cache
        assert "other:1" in manager.cache

    def test_bulk_invalidate_no_matches(self):
        """Test bulk invalidation with no matches."""
        manager = CacheManager()
        manager.put("key1", "value1")

        manager.bulk_invalidate(r"nonexistent:\d+")

        assert "key1" in manager.cache


class TestCacheManagerGetSizeByKeyType:
    """Test size by key type analysis."""

    def test_size_by_key_type(self):
        """Test getting size by key type."""
        manager = CacheManager()
        manager.put("user:1", "value1")
        manager.put("user:2", "value2")
        manager.put("other:1", "value3")

        size_by_type = manager.get_size_by_key_type()

        assert "user" in size_by_type
        assert "other" in size_by_type

    def test_size_by_key_type_empty(self):
        """Test getting size for empty cache."""
        manager = CacheManager()

        size_by_type = manager.get_size_by_key_type()

        assert size_by_type == {}


class TestCacheManagerEdgeCases:
    """Test edge cases."""

    def test_get_after_clear(self):
        """Test getting key after clear."""
        manager = CacheManager()
        manager.put("key1", "value1")
        manager.clear()

        result = manager.get("key1")

        assert result is None

    def test_put_after_clear(self):
        """Test putting key after clear."""
        manager = CacheManager()
        manager.put("key1", "value1")
        manager.clear()

        manager.put("key1", "new_value")

        assert manager.get("key1") == "new_value"

    def test_large_value(self):
        """Test putting large value."""
        manager = CacheManager()
        large_value = "x" * 10000

        manager.put("large_key", large_value)

        assert "large_key" in manager.cache

    def test_none_value(self):
        """Test putting None value."""
        manager = CacheManager()

        manager.put("none_key", None)

        assert manager.get("none_key") is None

    def test_empty_string_value(self):
        """Test putting empty string."""
        manager = CacheManager()

        manager.put("empty_key", "")

        assert manager.get("empty_key") == ""
