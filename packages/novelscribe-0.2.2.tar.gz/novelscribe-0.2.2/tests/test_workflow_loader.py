"""Tests for WorkflowLoader."""

import tempfile
from pathlib import Path

import pytest

from core.workflow_loader import (
    OnFailure,
    Workflow,
    WorkflowLoader,
    WorkflowStep,
)


class TestWorkflowStep:
    """Test WorkflowStep model."""

    def test_workflow_step_creation(self):
        step = WorkflowStep(
            step=1,
            name="test_step",
            agent="test_agent",
        )
        assert step.step == 1
        assert step.name == "test_step"
        assert step.agent == "test_agent"
        assert step.on_failure == OnFailure.STOP

    def test_workflow_step_with_workflow(self):
        step = WorkflowStep(
            step=1,
            name="nested",
            workflow="sub_workflow",
        )
        assert step.workflow == "sub_workflow"

    def test_workflow_step_with_action(self):
        step = WorkflowStep(
            step=1,
            name="action_step",
            action="validate",
        )
        assert step.action == "validate"

    def test_workflow_step_with_condition(self):
        step = WorkflowStep(
            step=1,
            name="conditional",
            condition="${count} > 5",
        )
        assert step.condition == "${count} > 5"

    def test_workflow_step_with_on_failure_continue(self):
        step = WorkflowStep(
            step=1,
            name="continue_on_fail",
            on_failure=OnFailure.CONTINUE,
        )
        assert step.on_failure == OnFailure.CONTINUE


class TestWorkflow:
    """Test Workflow model."""

    def test_workflow_creation(self):
        workflow = Workflow(
            name="test_workflow",
            description="A test workflow",
        )
        assert workflow.name == "test_workflow"
        assert workflow.version == "1.0.0"
        assert workflow.steps == []

    def test_workflow_with_version(self):
        workflow = Workflow(
            name="test",
            description="Test",
            version="2.0.0",
        )
        assert workflow.version == "2.0.0"

    def test_workflow_with_steps(self):
        step = WorkflowStep(step=1, name="step1")
        workflow = Workflow(
            name="test",
            description="Test",
            steps=[step],
        )
        assert len(workflow.steps) == 1


class TestWorkflowLoader:
    """Test WorkflowLoader."""

    def test_initialization(self):
        loader = WorkflowLoader("/path/to/workflows")
        assert loader.workflows_dir == Path("/path/to/workflows")

    def test_parse_workflow_valid(self):
        loader = WorkflowLoader("/tmp")
        content = """
name: test_workflow
description: A test workflow
steps:
  - step: 1
    name: step1
    agent: test_agent
"""
        workflow = loader.parse_workflow(content)
        assert workflow.name == "test_workflow"
        assert workflow.description == "A test workflow"
        assert len(workflow.steps) == 1
        assert workflow.steps[0].name == "step1"

    def test_parse_workflow_missing_name(self):
        loader = WorkflowLoader("/tmp")
        content = """
description: Missing name
"""
        with pytest.raises(ValueError, match="Missing required field"):
            loader.parse_workflow(content)

    def test_parse_workflow_missing_description(self):
        loader = WorkflowLoader("/tmp")
        content = """
name: Missing description
"""
        with pytest.raises(ValueError, match="Missing required field"):
            loader.parse_workflow(content)

    def test_parse_workflow_invalid_yaml(self):
        loader = WorkflowLoader("/tmp")
        content = """
name: invalid: [unclosed
"""
        with pytest.raises(ValueError, match="Invalid YAML"):
            loader.parse_workflow(content)

    def test_parse_workflow_non_dict(self):
        loader = WorkflowLoader("/tmp")
        content = "just a string"
        with pytest.raises(ValueError, match="must be a dictionary"):
            loader.parse_workflow(content)

    def test_parse_workflow_with_variables(self):
        loader = WorkflowLoader("/tmp")
        content = """
name: test
description: Test
variables:
  var1: value1
  var2: 123
"""
        workflow = loader.parse_workflow(content)
        assert workflow.variables == {"var1": "value1", "var2": 123}

    def test_parse_workflow_with_multiple_steps(self):
        loader = WorkflowLoader("/tmp")
        content = """
name: multi_step
description: Multiple steps
steps:
  - step: 1
    name: step1
    agent: agent1
  - step: 2
    name: step2
    agent: agent2
"""
        workflow = loader.parse_workflow(content)
        assert len(workflow.steps) == 2

    def test_parse_step_variables(self):
        loader = WorkflowLoader("/tmp")
        step_data = {
            "step": 1,
            "name": "test",
            "input": {"key": "value"},
            "output": {"result": "out"},
        }
        result = loader._parse_step_variables(step_data)
        assert result == step_data

    def test_parse_step_variables_with_list(self):
        loader = WorkflowLoader("/tmp")
        step_data = {
            "step": 1,
            "name": "test",
            "items": ["a", "b", "c"],
        }
        result = loader._parse_step_variables(step_data)
        assert result["items"] == ["a", "b", "c"]

    def test_parse_step_variables_non_dict_skipped(self):
        loader = WorkflowLoader("/tmp")
        content = """
name: test
description: Test
steps:
  - not a dict
"""
        workflow = loader.parse_workflow(content)
        assert len(workflow.steps) == 0

    def test_load_workflow_file_not_found(self):
        loader = WorkflowLoader("/tmp")
        with pytest.raises(FileNotFoundError):
            loader.load_workflow("/nonexistent/file.yaml")

    def test_load_all_workflows_nonexistent_dir(self):
        loader = WorkflowLoader("/nonexistent/directory")
        workflows = loader.load_all_workflows()
        assert workflows == []

    def test_reload_workflow_not_found(self):
        loader = WorkflowLoader(tempfile.mkdtemp())
        result = loader.reload_workflow("nonexistent")
        assert result is None

    def test_load_workflow_from_file(self, tmp_path):
        workflow_file = tmp_path / "test.yaml"
        workflow_file.write_text("""
name: file_workflow
description: Loaded from file
""")
        loader = WorkflowLoader(tmp_path)
        workflow = loader.load_workflow(workflow_file)
        assert workflow.name == "file_workflow"

    def test_load_all_workflows(self, tmp_path):
        (tmp_path / "wf1.yaml").write_text("""
name: workflow1
description: First workflow
""")
        (tmp_path / "wf2.yaml").write_text("""
name: workflow2
description: Second workflow
""")
        (tmp_path / "wf3.txt").write_text("not a yaml")
        loader = WorkflowLoader(tmp_path)
        workflows = loader.load_all_workflows()
        assert len(workflows) == 2
        names = {w.name for w in workflows}
        assert "workflow1" in names
        assert "workflow2" in names
