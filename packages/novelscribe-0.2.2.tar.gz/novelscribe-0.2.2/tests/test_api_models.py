"""
Tests for API models
"""

from datetime import datetime

import pytest
from pydantic import ValidationError

from api.models import (
    ErrorResponse,
    ExecutionStatus,
    HealthCheckResponse,
    LogEntry,
    LogLevel,
    LogsResponse,
    ProactiveSuggestions,
    ProjectCreate,
    ProjectResponse,
    ProjectStatus,
    SuggestionChoice,
    SystemStatusResponse,
    WorkflowRunRequest,
    WorkflowRunResponse,
)


class TestSuggestionChoice:
    """Test cases for SuggestionChoice model"""

    def test_suggestion_choice_creation(self):
        """Test creating a SuggestionChoice"""
        suggestion = SuggestionChoice(
            id="suggestion-1",
            name="Add Dialogue",
            description="Add more dialogue to the scene",
            source="continuity_agent",
            best_for=["pacing", "character_development"],
            examples=["Example 1", "Example 2"],
            acceptance_rate=0.75,
        )

        assert suggestion.id == "suggestion-1"
        assert suggestion.name == "Add Dialogue"
        assert suggestion.description == "Add more dialogue to the scene"
        assert suggestion.source == "continuity_agent"
        assert suggestion.best_for == ["pacing", "character_development"]
        assert suggestion.examples == ["Example 1", "Example 2"]
        assert suggestion.acceptance_rate == 0.75

    def test_suggestion_choice_defaults(self):
        """Test SuggestionChoice with default values"""
        suggestion = SuggestionChoice(
            id="suggestion-2",
            name="Fix Grammar",
            description="Fix grammatical errors",
            source="editor_agent",
        )

        assert suggestion.best_for == []
        assert suggestion.examples == []
        assert suggestion.acceptance_rate is None


class TestProactiveSuggestions:
    """Test cases for ProactiveSuggestions model"""

    def test_proactive_suggestions_creation(self):
        """Test creating ProactiveSuggestions"""
        suggestions = ProactiveSuggestions(
            show_suggestions=True,
            trigger_type="chapter_complete",
            formatted_suggestions="<ul><li>Suggestion 1</li></ul>",
            suggestions=[SuggestionChoice(id="s1", name="Test", description="Test", source="test")],
            presented_at=datetime.now(),
        )

        assert suggestions.show_suggestions is True
        assert suggestions.trigger_type == "chapter_complete"
        assert len(suggestions.suggestions) == 1
        assert suggestions.presented_at is not None

    def test_proactive_suggestions_empty(self):
        """Test ProactiveSuggestions with empty suggestions"""
        suggestions = ProactiveSuggestions(show_suggestions=False)

        assert suggestions.show_suggestions is False
        assert suggestions.suggestions == []


class TestEnums:
    """Test cases for enum classes"""

    def test_project_status_values(self):
        """Test ProjectStatus enum values"""
        assert ProjectStatus.CREATED.value == "created"
        assert ProjectStatus.OUTLINING.value == "outlining"
        assert ProjectStatus.WRITING.value == "writing"
        assert ProjectStatus.REVIEW.value == "review"
        assert ProjectStatus.COMPLETED.value == "completed"
        assert ProjectStatus.ERROR.value == "error"

    def test_execution_status_values(self):
        """Test ExecutionStatus enum values"""
        assert ExecutionStatus.PENDING.value == "pending"
        assert ExecutionStatus.RUNNING.value == "running"
        assert ExecutionStatus.COMPLETED.value == "completed"
        assert ExecutionStatus.FAILED.value == "failed"
        assert ExecutionStatus.CANCELLED.value == "cancelled"

    def test_log_level_values(self):
        """Test LogLevel enum values"""
        assert LogLevel.DEBUG.value == "DEBUG"
        assert LogLevel.INFO.value == "INFO"
        assert LogLevel.WARNING.value == "WARNING"
        assert LogLevel.ERROR.value == "ERROR"
        assert LogLevel.CRITICAL.value == "CRITICAL"


class TestProjectCreate:
    """Test cases for ProjectCreate model"""

    def test_project_create_valid(self):
        """Test creating a valid project"""
        project = ProjectCreate(
            name="my-novel", provider="openai", model="gpt-4", description="A fantasy novel"
        )

        assert project.name == "my-novel"
        assert project.provider == "openai"
        assert project.model == "gpt-4"
        assert project.description == "A fantasy novel"

    def test_project_create_minimal(self):
        """Test creating a project with minimal fields"""
        project = ProjectCreate(name="minimal-novel")

        assert project.name == "minimal-novel"
        assert project.provider is None
        assert project.model is None
        assert project.description is None

    def test_project_create_empty_name_fails(self):
        """Test that empty name fails validation"""
        with pytest.raises(ValidationError):
            ProjectCreate(name="")

    def test_project_create_whitespace_name_fails(self):
        """Test that whitespace-only name fails validation"""
        with pytest.raises(ValidationError):
            ProjectCreate(name="   ")

    def test_project_create_name_with_slash_fails(self):
        """Test that name with slash fails validation"""
        with pytest.raises(ValidationError) as exc_info:
            ProjectCreate(name="my/novel")

        assert "cannot contain slashes" in str(exc_info.value)

    def test_project_create_name_with_backslash_fails(self):
        """Test that name with backslash fails validation"""
        with pytest.raises(ValidationError) as exc_info:
            ProjectCreate(name="my\\novel")

        assert "cannot contain slashes" in str(exc_info.value)

    def test_project_create_name_trimmed(self):
        """Test that project name is trimmed"""
        project = ProjectCreate(name="  trimmed-name  ")

        assert project.name == "trimmed-name"

    def test_project_create_name_too_long(self):
        """Test that name over 100 characters fails"""
        with pytest.raises(ValidationError):
            ProjectCreate(name="a" * 101)


class TestProjectResponse:
    """Test cases for ProjectResponse model"""

    def test_project_response_creation(self):
        """Test creating a ProjectResponse"""
        response = ProjectResponse(
            name="my-project",
            status=ProjectStatus.WRITING,
            created_at=datetime.now(),
            location="/path/to/project",
            chapter_count=5,
            description="A great novel",
            meta={"genre": "fantasy"},
        )

        assert response.name == "my-project"
        assert response.status == ProjectStatus.WRITING
        assert response.chapter_count == 5
        assert response.meta["genre"] == "fantasy"

    def test_project_response_defaults(self):
        """Test ProjectResponse with default values"""
        response = ProjectResponse(
            name="test-project",
            status=ProjectStatus.CREATED,
            created_at=datetime.now(),
            location="/path/to/project",
        )

        assert response.chapter_count == 0
        assert response.meta == {}
        assert response.updated_at is None


class TestWorkflowRunRequest:
    """Test cases for WorkflowRunRequest model"""

    def test_workflow_run_request_creation(self):
        """Test creating a WorkflowRunRequest"""
        request = WorkflowRunRequest(
            project_name="my-novel",
            workflow="writing_phase",
            variables={"chapter": 1, "prompt": "Write chapter 1"},
        )

        assert request.project_name == "my-novel"
        assert request.workflow == "writing_phase"
        assert request.variables["chapter"] == 1

    def test_workflow_run_request_defaults(self):
        """Test WorkflowRunRequest with default values"""
        request = WorkflowRunRequest(project_name="test", workflow="autonomous")

        assert request.variables == {}
        assert request.background is True


class TestWorkflowRunResponse:
    """Test cases for WorkflowRunResponse model"""

    def test_workflow_run_response_creation(self):
        """Test creating a WorkflowRunResponse"""
        response = WorkflowRunResponse(
            execution_id="exec-123",
            project="my-novel",
            workflow="writing_phase",
            status=ExecutionStatus.RUNNING,
            started_at=datetime.now(),
            message="Workflow started",
            background=True,
        )

        assert response.execution_id == "exec-123"
        assert response.status == ExecutionStatus.RUNNING
        assert response.background is True


class TestLogEntry:
    """Test cases for LogEntry model"""

    def test_log_entry_creation(self):
        """Test creating a LogEntry"""
        entry = LogEntry(
            timestamp=datetime.now(),
            level=LogLevel.INFO,
            message="Test log message",
            source="test-source",
        )

        assert entry.level == LogLevel.INFO
        assert entry.message == "Test log message"
        assert entry.source == "test-source"

    def test_log_entry_defaults(self):
        """Test LogEntry with default values"""
        entry = LogEntry(timestamp=datetime.now(), level=LogLevel.DEBUG, message="Debug message")

        assert entry.source is None
        assert entry.metadata == {}


class TestLogsResponse:
    """Test cases for LogsResponse model"""

    def test_logs_response_creation(self):
        """Test creating a LogsResponse"""
        response = LogsResponse(
            project="my-novel",
            logs=[LogEntry(timestamp=datetime.now(), level=LogLevel.INFO, message="Test log")],
            total=10,
            offset=0,
            limit=10,
            has_more=False,
        )

        assert response.project == "my-novel"
        assert len(response.logs) == 1
        assert response.total == 10
        assert response.has_more is False


class TestSystemStatusResponse:
    """Test cases for SystemStatusResponse model"""

    def test_system_status_response_creation(self):
        """Test creating a SystemStatusResponse"""
        response = SystemStatusResponse(
            status="healthy",
            version="1.0.0",
            projects_count=10,
            active_executions=5,
            uptime_seconds=3600.0,
        )

        assert response.status == "healthy"
        assert response.version == "1.0.0"
        assert response.projects_count == 10
        assert response.active_executions == 5
        assert response.uptime_seconds == 3600.0


class TestHealthCheckResponse:
    """Test cases for HealthCheckResponse model"""

    def test_health_check_response_creation(self):
        """Test creating a HealthCheckResponse"""
        response = HealthCheckResponse(status="ok", timestamp=datetime.now())

        assert response.status == "ok"
        assert response.timestamp is not None


class TestErrorResponse:
    """Test cases for ErrorResponse model"""

    def test_error_response_creation(self):
        """Test creating an ErrorResponse"""
        response = ErrorResponse(error="Not Found", message="Project not found")

        assert response.error == "Not Found"
        assert response.message == "Project not found"

    def test_error_response_with_details(self):
        """Test ErrorResponse with additional details"""
        response = ErrorResponse(
            error="Validation Error",
            message="Invalid project name",
            details={"field": "name", "reason": "too long"},
        )

        assert response.details["field"] == "name"
