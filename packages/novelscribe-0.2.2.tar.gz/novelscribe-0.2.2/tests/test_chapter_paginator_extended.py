"""
Comprehensive tests for chapter_paginator.py to increase coverage to 90%+.
Tests chapter pagination and page splitting strategies.
"""

from unittest.mock import patch

from core.chapter_paginator import (
    ChapterPage,
    ChapterPaginator,
    PageMetadata,
    PageSplitStrategy,
    PaginationConfig,
)


class TestPageMetadata:
    """Test PageMetadata dataclass."""

    def test_to_dict(self):
        """Test converting to dictionary."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=60,
        )

        result = metadata.to_dict()

        assert result["page_number"] == 1
        assert result["word_count"] == 50
        assert "created_at" in result


class TestChapterPage:
    """Test ChapterPage dataclass."""

    def test_word_count_property(self):
        """Test word count property."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=60,
        )
        page = ChapterPage(
            page_number=1,
            content="Hello world this is a test",
            metadata=metadata,
        )

        assert page.word_count == 6

    def test_full_content_with_overlap(self):
        """Test full content with overlap."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=60,
        )
        page = ChapterPage(
            page_number=1,
            content="New content",
            metadata=metadata,
            overlap_content="Previous content",
        )

        assert "Previous content" in page.full_content
        assert "New content" in page.full_content

    def test_full_content_without_overlap(self):
        """Test full content without overlap."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=60,
        )
        page = ChapterPage(
            page_number=1,
            content="Content only",
            metadata=metadata,
        )

        assert page.full_content == "Content only"

    def test_get_context_hint_with_all(self):
        """Test context hint with all metadata."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=60,
            scene_identifier="Scene 1",
            characters_present=["Alice", "Bob"],
            locations_present=["Castle"],
        )
        page = ChapterPage(
            page_number=1,
            content="Content",
            metadata=metadata,
        )

        hint = page.get_context_hint()
        assert "Scene 1" in hint
        assert "Alice" in hint
        assert "Castle" in hint

    def test_get_context_hint_minimal(self):
        """Test context hint with minimal metadata."""
        metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=100,
            word_count=50,
            token_count=60,
        )
        page = ChapterPage(
            page_number=1,
            content="Content",
            metadata=metadata,
        )

        hint = page.get_context_hint()
        assert hint == "Continuing story..."


class TestPaginationConfig:
    """Test PaginationConfig model."""

    def test_default_config(self):
        """Test default configuration."""
        config = PaginationConfig()

        assert config.strategy == PageSplitStrategy.SEMANTIC
        assert config.max_tokens_per_page == 2500

    def test_custom_config(self):
        """Test custom configuration."""
        config = PaginationConfig(
            strategy=PageSplitStrategy.TOKEN_BASED,
            max_tokens_per_page=3000,
        )

        assert config.strategy == PageSplitStrategy.TOKEN_BASED
        assert config.max_tokens_per_page == 3000


class TestChapterPaginator:
    """Test ChapterPaginator class."""

    def test_init_with_defaults(self):
        """Test initialization with defaults."""
        paginator = ChapterPaginator()

        assert paginator.config.strategy == PageSplitStrategy.SEMANTIC
        assert paginator.config.max_tokens_per_page == 2500

    def test_init_with_config(self):
        """Test initialization with custom config."""
        config = PaginationConfig(
            strategy=PageSplitStrategy.PARAGRAPH_BASED,
            max_tokens_per_page=2000,
        )
        paginator = ChapterPaginator(config=config)

        assert paginator.config.strategy == PageSplitStrategy.PARAGRAPH_BASED

    def test_paginate_short_chapter(self):
        """Test paginating a short chapter."""
        paginator = ChapterPaginator()
        short_chapter = "This is a short chapter."

        pages = paginator.paginate_chapter(short_chapter, chapter_number=1)

        assert len(pages) >= 1
        assert pages[0].page_number == 1

    def test_paginate_with_metadata(self):
        """Test paginating with custom metadata."""
        paginator = ChapterPaginator()
        chapter = "Word " * 100

        pages = paginator.paginate_chapter(chapter, chapter_number=5)

        assert len(pages) > 0
        assert pages[0].metadata.page_number == 1

    def test_paginate_with_options(self):
        """Test paginating with custom options."""
        config = PaginationConfig(strategy=PageSplitStrategy.PARAGRAPH_BASED)
        paginator = ChapterPaginator(config=config)
        chapter = "Paragraph 1\n\nParagraph 2\n\nParagraph 3"

        pages = paginator.paginate_chapter(chapter, chapter_number=1)

        assert len(pages) > 0


class TestPaginationStrategies:
    """Test different pagination strategies."""

    def test_paragraph_based_strategy(self):
        """Test paragraph-based pagination."""
        config = PaginationConfig(strategy=PageSplitStrategy.PARAGRAPH_BASED)
        paginator = ChapterPaginator(config=config)
        chapter = "Para 1\n\nPara 2\n\nPara 3\n\nPara 4\n\nPara 5"

        pages = paginator.paginate_chapter(chapter, chapter_number=1)

        assert len(pages) > 0

    def test_scene_based_strategy(self):
        """Test scene-based pagination."""
        config = PaginationConfig(strategy=PageSplitStrategy.SCENE_BASED)
        paginator = ChapterPaginator(config=config)
        chapter = "Scene 1: Intro\n\nScene 2: Rising\n\nScene 3: Climax"

        pages = paginator.paginate_chapter(chapter, chapter_number=1)

        assert len(pages) > 0

    def test_semantic_strategy(self):
        """Test semantic pagination."""
        config = PaginationConfig(strategy=PageSplitStrategy.SEMANTIC)
        paginator = ChapterPaginator(config=config)
        chapter = "Word " * 1000

        pages = paginator.paginate_chapter(chapter, chapter_number=1)

        assert len(pages) > 0

    def test_token_based_strategy(self):
        """Test token-based pagination."""
        config = PaginationConfig(strategy=PageSplitStrategy.TOKEN_BASED)
        paginator = ChapterPaginator(config=config)
        chapter = "Word " * 2000

        pages = paginator.paginate_chapter(chapter, chapter_number=1)

        assert len(pages) > 0


class TestEdgeCases:
    """Test edge cases."""

    def test_paginate_single_word(self):
        """Test paginating single word."""
        paginator = ChapterPaginator()

        pages = paginator.paginate_chapter("Hello", chapter_number=1)

        assert len(pages) >= 1

    def test_paginate_chapter_number(self):
        """Test that chapter number is set correctly."""
        paginator = ChapterPaginator()
        chapter = "Word " * 100

        pages = paginator.paginate_chapter(chapter, chapter_number=42)

        assert all(p.metadata.page_number == 1 for p in pages)


def _token_mock(text):
    """Estimate tokens as 2x word count."""
    return len(text.split()) * 2


class TestPaginateChaptersStrategyDispatch:
    """Test paginate_chapter dispatches to correct strategy when tokens exceed limit."""

    def _make_mock(self, content, high=3000):
        """Return mock that returns high tokens for full content only."""

        def mock_estimate(text):
            if text == content:
                return high
            return len(text.split()) * 2

        return mock_estimate

    def test_scene_based_dispatch(self):
        """Test SCENE_BASED strategy dispatch (line 165)."""
        config = PaginationConfig(strategy=PageSplitStrategy.SCENE_BASED)
        paginator = ChapterPaginator(config=config)
        content = "Scene one content.\n\n***\n\nScene two content here."
        with patch.object(
            paginator.token_estimator,
            "estimate_tokens",
            side_effect=self._make_mock(content),
        ):
            pages = paginator.paginate_chapter(content, 1)
            assert len(pages) >= 1

    def test_paragraph_based_dispatch(self):
        """Test PARAGRAPH_BASED strategy dispatch (line 167)."""
        config = PaginationConfig(strategy=PageSplitStrategy.PARAGRAPH_BASED)
        paginator = ChapterPaginator(config=config)
        content = "Paragraph one.\n\nParagraph two."
        with patch.object(
            paginator.token_estimator,
            "estimate_tokens",
            side_effect=self._make_mock(content),
        ):
            pages = paginator.paginate_chapter(content, 1)
            assert len(pages) >= 1

    def test_semantic_dispatch(self):
        """Test SEMANTIC strategy dispatch (line 169)."""
        config = PaginationConfig(strategy=PageSplitStrategy.SEMANTIC)
        paginator = ChapterPaginator(config=config)
        content = "Scene one.\n\n***\n\nScene two content here."
        with patch.object(
            paginator.token_estimator,
            "estimate_tokens",
            side_effect=self._make_mock(content),
        ):
            pages = paginator.paginate_chapter(content, 1)
            assert len(pages) >= 1


class TestPaginateByTokensWithMetadata:
    """Test _paginate_by_tokens with metadata enrichment."""

    def test_with_metadata_enrichment(self):
        """Test token pagination with metadata triggers enrichment (line 231)."""
        config = PaginationConfig(strategy=PageSplitStrategy.TOKEN_BASED, target_tokens_per_page=40)
        paginator = ChapterPaginator(config=config)
        content = "Alice and Bob went to the garden " * 50
        metadata = {"characters": ["Alice", "Bob"], "locations": ["garden"]}
        with patch.object(
            paginator.token_estimator,
            "estimate_tokens",
            side_effect=_token_mock,
        ):
            pages = paginator._paginate_by_tokens(content, 1, metadata)
            assert len(pages) >= 2
            assert any("Alice" in p.metadata.characters_present for p in pages)


class TestPaginateByScenesEdgeCases:
    """Test _paginate_by_scenes edge cases."""

    def test_no_scene_breaks_falls_back(self):
        """Test _paginate_by_scenes calls _paginate_semantically when no breaks (line 266)."""
        config = PaginationConfig(strategy=PageSplitStrategy.SCENE_BASED)
        paginator = ChapterPaginator(config=config)
        content = "Just content without breaks."
        result_page = ChapterPage(
            page_number=1,
            content=content,
            metadata=PageMetadata(
                page_number=1,
                start_position=0,
                end_position=len(content),
                word_count=3,
                token_count=6,
            ),
        )
        with (
            patch.object(
                paginator.token_estimator,
                "estimate_tokens",
                side_effect=_token_mock,
            ),
            patch.object(
                paginator,
                "_paginate_semantically",
                return_value=[result_page],
            ) as mock_sem,
        ):
            pages = paginator._paginate_by_scenes(content, 1, None)
            mock_sem.assert_called_once_with(content, 1, None)
            assert len(pages) == 1

    def test_empty_scene_content_skipped(self):
        """Test empty scene content is skipped (line 276)."""
        config = PaginationConfig(strategy=PageSplitStrategy.SCENE_BASED)
        paginator = ChapterPaginator(config=config)
        content = "\n\n***\n\nActual scene content here."
        with patch.object(
            paginator.token_estimator,
            "estimate_tokens",
            side_effect=_token_mock,
        ):
            pages = paginator._paginate_by_scenes(content, 1, None)
            assert len(pages) >= 1

    def test_large_scene_splits_by_tokens(self):
        """Test large scene triggers token sub-pagination (lines 282-288)."""
        config = PaginationConfig(
            strategy=PageSplitStrategy.SCENE_BASED,
            max_tokens_per_page=50,
            target_tokens_per_page=30,
        )
        paginator = ChapterPaginator(config=config)
        content = ("Word " * 100) + "\n\n***\n\n" + "Other scene content."
        with patch.object(
            paginator.token_estimator,
            "estimate_tokens",
            side_effect=_token_mock,
        ):
            pages = paginator._paginate_by_scenes(content, 1, None)
            assert len(pages) >= 2

    def test_scenes_with_metadata_enrichment(self):
        """Test scene pagination with metadata enrichment (line 300)."""
        config = PaginationConfig(strategy=PageSplitStrategy.SCENE_BASED)
        paginator = ChapterPaginator(config=config)
        content = "Alice went to the garden.\n\n***\n\nBob was in the kitchen."
        metadata = {"characters": ["Alice", "Bob"], "locations": ["garden", "kitchen"]}
        with patch.object(
            paginator.token_estimator,
            "estimate_tokens",
            side_effect=_token_mock,
        ):
            pages = paginator._paginate_by_scenes(content, 1, metadata)
            assert len(pages) >= 1


class TestPaginateByParagraphsMultiPage:
    """Test _paginate_by_paragraphs multi-page scenarios."""

    def test_multi_page_with_overflow(self):
        """Test paragraph pagination with page overflow (lines 336-358)."""
        config = PaginationConfig(
            strategy=PageSplitStrategy.PARAGRAPH_BASED,
            target_tokens_per_page=20,
            max_tokens_per_page=30,
        )
        paginator = ChapterPaginator(config=config)
        paragraphs = [f"Paragraph {i} with enough content to fill." for i in range(5)]
        content = "\n\n".join(paragraphs)
        with patch.object(
            paginator.token_estimator,
            "estimate_tokens",
            side_effect=_token_mock,
        ):
            pages = paginator._paginate_by_paragraphs(content, 1, None)
            assert len(pages) >= 2

    def test_oversized_paragraph_in_flow(self):
        """Test oversized paragraph triggers token sub-pagination (lines 346-355)."""
        config = PaginationConfig(
            strategy=PageSplitStrategy.PARAGRAPH_BASED,
            target_tokens_per_page=10,
            max_tokens_per_page=15,
        )
        paginator = ChapterPaginator(config=config)
        content = "Small para here.\n\n" + "Huge content word " * 30
        with patch.object(
            paginator.token_estimator,
            "estimate_tokens",
            side_effect=_token_mock,
        ):
            pages = paginator._paginate_by_paragraphs(content, 1, None)
            assert len(pages) >= 2

    def test_last_page_with_remaining_content(self):
        """Test last page creation with remaining content (lines 361-367)."""
        config = PaginationConfig(
            strategy=PageSplitStrategy.PARAGRAPH_BASED,
            target_tokens_per_page=40,
            max_tokens_per_page=60,
        )
        paginator = ChapterPaginator(config=config)
        content = "Para one.\n\nPara two.\n\nPara three.\n\nPara four."
        with patch.object(
            paginator.token_estimator,
            "estimate_tokens",
            side_effect=_token_mock,
        ):
            pages = paginator._paginate_by_paragraphs(content, 1, None)
            assert len(pages) >= 1
            assert pages[-1].page_number >= 1


class TestPaginateSemanticallyPaths:
    """Test _paginate_semantically both code paths."""

    def test_returns_scene_pages_when_well_sized(self):
        """Test semantic returns scene pages when avg tokens in range (line 380)."""
        config = PaginationConfig(
            strategy=PageSplitStrategy.SEMANTIC,
            min_page_tokens=2,
            max_tokens_per_page=2500,
        )
        paginator = ChapterPaginator(config=config)
        content = "Scene one content.\n\n***\n\nScene two content here."
        with patch.object(
            paginator.token_estimator,
            "estimate_tokens",
            side_effect=_token_mock,
        ):
            pages = paginator._paginate_semantically(content, 1, None)
            assert len(pages) >= 2

    def test_falls_back_to_paragraphs(self):
        """Test semantic falls back to paragraphs when scene pages poor (lines 382-383)."""
        config = PaginationConfig(
            strategy=PageSplitStrategy.SEMANTIC,
            min_page_tokens=5000,
            max_tokens_per_page=2500,
        )
        paginator = ChapterPaginator(config=config)
        content = "Content without breaks."
        scene_page = ChapterPage(
            page_number=1,
            content=content,
            metadata=PageMetadata(
                page_number=1,
                start_position=0,
                end_position=len(content),
                word_count=3,
                token_count=6,
            ),
        )
        with (
            patch.object(
                paginator.token_estimator,
                "estimate_tokens",
                side_effect=_token_mock,
            ),
            patch.object(
                paginator,
                "_paginate_by_scenes",
                return_value=[scene_page],
            ),
        ):
            pages = paginator._paginate_semantically(content, 1, None)
            assert len(pages) >= 1


class TestCreatePageFromContentWithMetadata:
    """Test _create_page_from_content with metadata."""

    def test_with_metadata(self):
        """Test creating page with metadata enrichment (line 424)."""
        config = PaginationConfig()
        paginator = ChapterPaginator(config=config)
        content = "Alice went to the garden."
        metadata = {"characters": ["Alice"]}
        with patch.object(
            paginator.token_estimator,
            "estimate_tokens",
            side_effect=_token_mock,
        ):
            page = paginator._create_page_from_content(content, 1, 0, 1, metadata)
            assert page.page_number == 1
            assert "Alice" in page.metadata.characters_present
