"""Test coverage for cli_workflows.py commands."""

from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from cli_workflows import workflows


class TestWorkflowsGroup:
    def test_workflows_group_exists(self):
        """Test that the workflows command group exists"""
        runner = CliRunner()
        result = runner.invoke(workflows, ["--help"])
        assert result.exit_code == 0
        assert "Workflow exploration and management commands" in result.output


class TestWorkflowsListCommand:
    def test_workflows_list_missing_directory(self):
        """Test workflows list when workflows directory doesn't exist"""
        runner = CliRunner()
        with patch("cli_workflows.Path") as mock_path:
            mock_workflows_dir = MagicMock()
            mock_workflows_dir.exists.return_value = False
            mock_path.return_value = mock_workflows_dir
            mock_path.cwd.return_value = MagicMock()

            result = runner.invoke(workflows, ["list"])
            assert result.exit_code in [0, 1]

    def test_workflows_list_no_workflows_found(self):
        """Test workflows list when no workflows are found"""
        runner = CliRunner()
        with (
            patch("cli_workflows.Path") as mock_path,
            patch("cli_workflows.WorkflowLoader") as mock_loader_class,
        ):
            mock_workflows_dir = MagicMock()
            mock_workflows_dir.exists.return_value = True
            mock_path.return_value = mock_workflows_dir
            mock_path.cwd.return_value = MagicMock()

            mock_loader = MagicMock()
            mock_loader.load_all_workflows.return_value = []
            mock_loader_class.return_value = mock_loader

            result = runner.invoke(workflows, ["list"])
            assert result.exit_code == 0

    def test_workflows_list_success(self):
        """Test successful workflows listing"""
        runner = CliRunner()
        with (
            patch("cli_workflows.Path") as mock_path,
            patch("cli_workflows.WorkflowLoader") as mock_loader_class,
            patch("cli_workflows.get_current_language") as mock_lang,
        ):
            mock_workflows_dir = MagicMock()
            mock_workflows_dir.exists.return_value = True
            mock_path.return_value = mock_workflows_dir
            mock_path.cwd.return_value = MagicMock()

            mock_lang.return_value = "en"

            mock_workflow1 = MagicMock()
            mock_workflow1.name = "new_novel"
            mock_workflow1.description = "Create a new novel project"
            mock_workflow1.version = "1.0"
            mock_workflow1.variables = {"title": None}
            mock_workflow1.steps = []

            mock_workflow2 = MagicMock()
            mock_workflow2.name = "worldbuilding_phase"
            mock_workflow2.description = "World building"
            mock_workflow2.version = "1.0"
            mock_workflow2.variables = {}
            mock_workflow2.steps = []

            mock_workflow3 = MagicMock()
            mock_workflow3.name = "writing_phase"
            mock_workflow3.description = "Writing phase"
            mock_workflow3.version = "1.0"
            mock_workflow3.variables = {}
            mock_workflow3.steps = []

            mock_workflow4 = MagicMock()
            mock_workflow4.name = "autonomous"
            mock_workflow4.description = "Complete autonomous workflow"
            mock_workflow4.version = "1.0"
            mock_workflow4.variables = {}
            mock_workflow4.steps = []

            mock_loader = MagicMock()
            mock_loader.load_all_workflows.return_value = [
                mock_workflow1,
                mock_workflow2,
                mock_workflow3,
                mock_workflow4,
            ]
            mock_loader_class.return_value = mock_loader

            result = runner.invoke(workflows, ["list"])
            assert result.exit_code == 0

    def test_workflows_list_with_language_context(self):
        """Test workflows list with language context"""
        runner = CliRunner()
        with (
            patch("cli_workflows.Path") as mock_path,
            patch("cli_workflows.WorkflowLoader") as mock_loader_class,
            patch("cli_workflows.get_current_language") as mock_lang,
        ):
            mock_workflows_dir = MagicMock()
            mock_workflows_dir.exists.return_value = True
            mock_path.return_value = mock_workflows_dir
            mock_path.cwd.return_value = MagicMock()

            mock_lang.return_value = "zh-CN"

            mock_workflow = MagicMock()
            mock_workflow.name = "new_novel"
            mock_workflow.description = "Create new novel"
            mock_workflow.version = "1.0"
            mock_workflow.variables = {}
            mock_workflow.steps = []

            mock_loader = MagicMock()
            mock_loader.load_all_workflows.return_value = [mock_workflow]
            mock_loader_class.return_value = mock_loader

            ctx = {"lang": "zh-CN"}
            result = runner.invoke(workflows, ["list"], obj=ctx)
            assert result.exit_code == 0

    def test_workflows_list_with_exception(self):
        """Test workflows list handles exceptions"""
        runner = CliRunner()
        with patch("cli_workflows.Path") as mock_path:
            mock_workflows_dir = MagicMock()
            mock_workflows_dir.exists.side_effect = Exception("Test error")
            mock_path.return_value = mock_workflows_dir

            result = runner.invoke(workflows, ["list"])
            assert result.exit_code in [0, 1]

    def test_workflows_list_with_debug(self):
        """Test workflows list with debug mode"""
        runner = CliRunner()
        with patch("cli_workflows.Path") as mock_path:
            mock_workflows_dir = MagicMock()
            mock_workflows_dir.exists.return_value = False
            mock_path.return_value = mock_workflows_dir

            ctx = {"debug": True}
            result = runner.invoke(workflows, ["list"], obj=ctx)
            assert result.exit_code in [0, 1]


class TestWorkflowsShowCommand:
    def test_workflows_show_missing_workflow_name(self):
        """Test workflows show without workflow name argument"""
        runner = CliRunner()
        result = runner.invoke(workflows, ["show"])
        assert result.exit_code != 0

    def test_workflows_show_directory_not_found(self):
        """Test workflows show when workflows directory doesn't exist"""
        runner = CliRunner()
        with patch("cli_workflows.Path") as mock_path:
            mock_workflows_dir = MagicMock()
            mock_workflows_dir.exists.return_value = False
            mock_path.return_value = mock_workflows_dir
            mock_path.cwd.return_value = MagicMock()

            result = runner.invoke(workflows, ["show", "test_workflow"])
            assert result.exit_code in [0, 1]

    def test_workflows_show_workflow_not_found(self):
        """Test workflows show when workflow doesn't exist"""
        runner = CliRunner()
        with (
            patch("cli_workflows.Path") as mock_path,
            patch("cli_workflows.WorkflowLoader") as mock_loader_class,
            patch("cli_workflows.get_current_language") as mock_lang,
        ):
            mock_workflows_dir = MagicMock()
            mock_workflows_dir.exists.return_value = True
            mock_path.return_value = mock_workflows_dir
            mock_path.cwd.return_value = MagicMock()

            mock_lang.return_value = "en"

            mock_loader = MagicMock()
            mock_loader.reload_workflow.return_value = None
            mock_loader.load_all_workflows.return_value = []
            mock_loader_class.return_value = mock_loader

            result = runner.invoke(workflows, ["show", "nonexistent"])
            assert result.exit_code in [0, 1]

    def test_workflows_show_success(self):
        """Test successful workflow show"""
        runner = CliRunner()
        with (
            patch("cli_workflows.Path") as mock_path,
            patch("cli_workflows.WorkflowLoader") as mock_loader_class,
            patch("cli_workflows.get_current_language") as mock_lang,
        ):
            mock_workflows_dir = MagicMock()
            mock_workflows_dir.exists.return_value = True
            mock_path.return_value = mock_workflows_dir
            mock_path.cwd.return_value = MagicMock()

            mock_lang.return_value = "en"

            mock_workflow = MagicMock()
            mock_workflow.name = "test_workflow"
            mock_workflow.description = "Test workflow description"
            mock_workflow.version = "1.0"
            mock_workflow.variables = {"title": None, "genre": "fantasy"}
            mock_workflow.steps = [
                MagicMock(step=1, name="Step 1", agent="TestAgent", workflow=None, action=None),
                MagicMock(step=2, name="Step 2", agent=None, workflow="SubWorkflow", action=None),
                MagicMock(step=3, name="Step 3", agent=None, workflow=None, action="TestAction"),
            ]

            mock_loader = MagicMock()
            mock_loader.reload_workflow.return_value = mock_workflow
            mock_loader.load_all_workflows.return_value = [mock_workflow]
            mock_loader_class.return_value = mock_loader

            result = runner.invoke(workflows, ["show", "test_workflow"])
            assert result.exit_code == 0

    def test_workflows_show_no_variables(self):
        """Test workflows show with workflow that has no variables"""
        runner = CliRunner()
        with (
            patch("cli_workflows.Path") as mock_path,
            patch("cli_workflows.WorkflowLoader") as mock_loader_class,
            patch("cli_workflows.get_current_language") as mock_lang,
        ):
            mock_workflows_dir = MagicMock()
            mock_workflows_dir.exists.return_value = True
            mock_path.return_value = mock_workflows_dir
            mock_path.cwd.return_value = MagicMock()

            mock_lang.return_value = "en"

            mock_workflow = MagicMock()
            mock_workflow.name = "test_workflow"
            mock_workflow.description = "Test workflow"
            mock_workflow.version = "1.0"
            mock_workflow.variables = {}
            mock_workflow.steps = []

            mock_loader = MagicMock()
            mock_loader.reload_workflow.return_value = mock_workflow
            mock_loader.load_all_workflows.return_value = [mock_workflow]
            mock_loader_class.return_value = mock_loader

            result = runner.invoke(workflows, ["show", "test_workflow"])
            assert result.exit_code == 0

    def test_workflows_show_with_language_context(self):
        """Test workflows show with language context"""
        runner = CliRunner()
        with (
            patch("cli_workflows.Path") as mock_path,
            patch("cli_workflows.WorkflowLoader") as mock_loader_class,
            patch("cli_workflows.get_current_language") as mock_lang,
        ):
            mock_workflows_dir = MagicMock()
            mock_workflows_dir.exists.return_value = True
            mock_path.return_value = mock_workflows_dir
            mock_path.cwd.return_value = MagicMock()

            mock_lang.return_value = "zh-CN"

            mock_workflow = MagicMock()
            mock_workflow.name = "test_workflow"
            mock_workflow.description = "Test workflow"
            mock_workflow.version = "1.0"
            mock_workflow.variables = {}
            mock_workflow.steps = []

            mock_loader = MagicMock()
            mock_loader.reload_workflow.return_value = mock_workflow
            mock_loader.load_all_workflows.return_value = [mock_workflow]
            mock_loader_class.return_value = mock_loader

            ctx = {"lang": "zh-CN"}
            result = runner.invoke(workflows, ["show", "test_workflow"], obj=ctx)
            assert result.exit_code == 0

    def test_workflows_show_with_exception(self):
        """Test workflows show handles exceptions"""
        runner = CliRunner()
        with patch("cli_workflows.Path") as mock_path:
            mock_workflows_dir = MagicMock()
            mock_workflows_dir.exists.side_effect = Exception("Test error")
            mock_path.return_value = mock_workflows_dir

            result = runner.invoke(workflows, ["show", "test_workflow"])
            assert result.exit_code in [0, 1]

    def test_workflows_show_with_debug(self):
        """Test workflows show with debug mode"""
        runner = CliRunner()
        with patch("cli_workflows.Path") as mock_path:
            mock_workflows_dir = MagicMock()
            mock_workflows_dir.exists.side_effect = Exception("Debug test error")
            mock_path.return_value = mock_workflows_dir

            ctx = {"debug": True}
            result = runner.invoke(workflows, ["show", "test_workflow"], obj=ctx)
            assert result.exit_code in [0, 1]

    def test_workflows_show_multiple_steps(self):
        """Test workflows show with multiple step types"""
        runner = CliRunner()
        with (
            patch("cli_workflows.Path") as mock_path,
            patch("cli_workflows.WorkflowLoader") as mock_loader_class,
            patch("cli_workflows.get_current_language") as mock_lang,
        ):
            mock_workflows_dir = MagicMock()
            mock_workflows_dir.exists.return_value = True
            mock_path.return_value = mock_workflows_dir
            mock_path.cwd.return_value = MagicMock()

            mock_lang.return_value = "en"

            mock_workflow = MagicMock()
            mock_workflow.name = "complex_workflow"
            mock_workflow.description = "Complex workflow"
            mock_workflow.version = "2.0"
            mock_workflow.variables = {"param": "value"}
            mock_workflow.steps = [
                MagicMock(step=1, name="Agent Step", agent="Agent1", workflow=None, action=None),
                MagicMock(
                    step=2, name="Workflow Step", agent=None, workflow="SubWorkflow1", action=None
                ),
                MagicMock(
                    step=3, name="Action Step", agent=None, workflow=None, action="CustomAction"
                ),
            ]

            mock_loader = MagicMock()
            mock_loader.reload_workflow.return_value = mock_workflow
            mock_loader.load_all_workflows.return_value = [mock_workflow]
            mock_loader_class.return_value = mock_loader

            result = runner.invoke(workflows, ["show", "complex_workflow"])
            assert result.exit_code == 0
