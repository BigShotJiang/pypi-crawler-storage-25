"""Test coverage for core/token_tracker.py."""

import sqlite3
import tempfile
from unittest.mock import MagicMock

import pytest

from core.token_tracker import TokenUsageTracker


@pytest.fixture
def mock_db_logger(self):
    db_path = tempfile.mktemp(suffix=".db")
    from core.logger import SQLiteLogger

    logger = SQLiteLogger(db_path=db_path)
    return logger


class TestTokenUsageTracker:
    """Test TokenUsageTracker class."""

    def setup_method(self):
        self.db_path = tempfile.mktemp(suffix=".db")
        self._request_counter = 0
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS llm_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                request_id TEXT UNIQUE NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                project_name TEXT,
                agent_name TEXT,
                provider TEXT NOT NULL,
                model TEXT NOT NULL,
                system_prompt TEXT,
                user_prompt TEXT,
                max_tokens INTEGER,
                temperature REAL,
                input_tokens INTEGER,
                output_tokens INTEGER,
                total_tokens INTEGER,
                cost_usd REAL,
                latency_ms INTEGER,
                status TEXT NOT NULL,
                error_message TEXT,
                cache_hit INTEGER DEFAULT 0,
                metadata TEXT
            )
        """)
        conn.commit()
        conn.close()

    def _add_request(
        self,
        project_name="test_project",
        agent_name="test_agent",
        provider="openai",
        model="gpt-4",
        input_tokens=1000,
        output_tokens=500,
        cost=0.06,
        latency_ms=1000,
        status="success",
    ):
        self._request_counter += 1
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO llm_requests
                (request_id, project_name, agent_name, provider, model,
                input_tokens, output_tokens, total_tokens, cost_usd, latency_ms, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
            (
                f"req_{self._request_counter}_{id(self)}",
                project_name,
                agent_name,
                provider,
                model,
                input_tokens,
                output_tokens,
                input_tokens + output_tokens,
                cost,
                latency_ms,
                status,
            ),
        )
        conn.commit()
        conn.close()

    def _make_mock_logger(self):
        mock = MagicMock()
        mock.db_path = self.db_path
        return mock

    def test_init(self):
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        assert tracker.db_logger is mock

    def test_get_usage_no_data(self):
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        result = tracker.get_usage()
        assert result["period"] == "30d"
        assert result["total_tokens"] == 0
        assert result["request_count"] == 0

    def test_get_usage_with_data(self):
        self._add_request()
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        result = tracker.get_usage()
        assert result["total_tokens"] > 0
        assert result["request_count"] > 0

    def test_get_usage_filter_by_project(self):
        self._add_request(project_name="proj_a")
        self._add_request(project_name="proj_b")
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        result = tracker.get_usage(project="proj_a")
        assert result["project"] == "proj_a"
        assert result["total_tokens"] > 0

    def test_get_usage_filter_by_provider(self):
        self._add_request(provider="openai")
        self._add_request(provider="anthropic")
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        result = tracker.get_usage(provider="openai")
        assert result["provider"] == "openai"

    def test_get_usage_filter_by_model(self):
        self._add_request(model="gpt-4")
        self._add_request(model="gpt-3.5-turbo")
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        result = tracker.get_usage(model="gpt-4")
        assert result["model"] == "gpt-4"

    def test_get_usage_group_by_day(self):
        self._add_request()
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        result = tracker.get_usage(group_by="day")
        assert "daily" in result

    def test_get_usage_group_by_provider(self):
        self._add_request()
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        result = tracker.get_usage(group_by="provider")
        assert "by_provider" in result

    def test_get_usage_group_by_model(self):
        self._add_request()
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        result = tracker.get_usage(group_by="model")
        assert "by_model" in result

    def test_get_usage_no_db_logger(self):
        tracker = TokenUsageTracker(None)
        result = tracker.get_usage()
        assert "error" in result

    def test_get_cost_breakdown(self):
        self._add_request(provider="openai", model="gpt-4", cost=0.06)
        self._add_request(provider="anthropic", model="claude-3-opus", cost=0.09)
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        result = tracker.get_cost_breakdown()
        assert "breakdown" in result
        assert len(result["breakdown"]) == 2
        assert result["total_cost_usd"] > 0

    def test_get_cost_breakdown_filter_by_project(self):
        self._add_request(project_name="proj_a")
        self._add_request(project_name="proj_b")
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        result = tracker.get_cost_breakdown(project="proj_a")
        assert result["project"] == "proj_a"

    def test_get_cost_breakdown_no_db_logger(self):
        tracker = TokenUsageTracker(None)
        result = tracker.get_cost_breakdown()
        assert "error" in result

    def test_get_top_consumers(self):
        self._add_request(agent_name="agent_a", model="gpt-4")
        self._add_request(agent_name="agent_b", model="gpt-3.5-turbo")
        self._add_request(agent_name="agent_a", model="gpt-4")
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        consumers = tracker.get_top_consumers(limit=10, group_by="agent")
        assert len(consumers) > 0
        assert consumers[0]["consumer"] == "agent_a"

    def test_get_top_consumers_by_project(self):
        self._add_request(project_name="proj_a")
        self._add_request(project_name="proj_b")
        self._add_request(project_name="proj_a")
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        consumers = tracker.get_top_consumers(limit=10, group_by="project")
        assert len(consumers) > 0

    def test_get_top_consumers_no_db_logger(self):
        tracker = TokenUsageTracker(None)
        consumers = tracker.get_top_consumers()
        assert consumers == []

    def test_get_slow_requests(self):
        self._add_request(latency_ms=100)
        self._add_request(latency_ms=10000)
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        slow = tracker.get_slow_requests(threshold_ms=5000, limit=10)
        assert len(slow) == 1
        assert slow[0]["latency_ms"] == 10000

    def test_get_slow_requests_none(self):
        self._add_request(latency_ms=100)
        self._add_request(latency_ms=200)
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        slow = tracker.get_slow_requests(threshold_ms=5000)
        assert len(slow) == 0

    def test_get_slow_requests_no_db_logger(self):
        tracker = TokenUsageTracker(None)
        slow = tracker.get_slow_requests()
        assert slow == []

    def test_get_errors(self):
        self._add_request(status="success")
        self._add_request(status="error", latency_ms=500)
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        errors = tracker.get_errors()
        assert len(errors) >= 1

    def test_get_errors_filter_by_project(self):
        self._add_request(project_name="proj_a", status="error")
        self._add_request(project_name="proj_b", status="error")
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        errors = tracker.get_errors(project="proj_a")
        for err in errors:
            assert err["project"] == "proj_a"

    def test_get_errors_no_db_logger(self):
        tracker = TokenUsageTracker(None)
        errors = tracker.get_errors()
        assert errors == []

    def test_build_date_filter_all(self):
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        result = tracker._build_date_filter("all")
        assert result == "1=1"

    def test_build_date_filter_days(self):
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        result = tracker._build_date_filter("7d")
        assert "7" in result
        assert "days" in result

    def test_build_date_filter_weeks(self):
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        result = tracker._build_date_filter("2w")
        assert "2" in result
        assert "weeks" in result

    def test_build_date_filter_months(self):
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        result = tracker._build_date_filter("1m")
        assert "1" in result
        assert "months" in result

    def test_build_date_filter_invalid(self):
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        result = tracker._build_date_filter("quarter")
        assert result == "1=1"

    def test_get_daily_breakdown(self):
        self._add_request()
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        conn = sqlite3.connect(self.db_path)
        daily = tracker._get_daily_breakdown(conn, "1=1", [])
        conn.close()
        assert len(daily) >= 1
        assert "total_tokens" in daily[0]

    def test_get_provider_breakdown(self):
        self._add_request(provider="openai")
        self._add_request(provider="anthropic")
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        conn = sqlite3.connect(self.db_path)
        providers = tracker._get_provider_breakdown(conn, "1=1", [])
        conn.close()
        assert len(providers) == 2

    def test_get_model_breakdown(self):
        self._add_request(model="gpt-4")
        self._add_request(model="claude-3-opus")
        mock = self._make_mock_logger()
        tracker = TokenUsageTracker(mock)
        conn = sqlite3.connect(self.db_path)
        models = tracker._get_model_breakdown(conn, "1=1", [])
        conn.close()
        assert len(models) == 2
