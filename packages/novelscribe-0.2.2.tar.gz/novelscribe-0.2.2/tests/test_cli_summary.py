"""
Tests for CLI summary commands
"""

from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from cli_summary import (
    summary,
)


class TestSummaryGroup:
    """Test cases for summary command group"""

    def test_summary_group_exists(self):
        """Test that summary command group exists"""
        assert summary is not None

    def test_summary_help(self):
        """Test summary command help"""
        runner = CliRunner()
        result = runner.invoke(summary, ["--help"])

        assert result.exit_code == 0
        assert "summary" in result.output.lower()


class TestGenerateCommand:
    """Test cases for generate command"""

    def test_generate_missing_project_name(self):
        """Test generate command without project name"""
        runner = CliRunner()
        result = runner.invoke(summary, ["generate"])

        assert result.exit_code != 0

    def test_generate_project_not_found(self):
        """Test generate command with non-existent project"""
        runner = CliRunner()

        with patch("cli_summary.Path") as mock_path:
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = False
            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(summary, ["generate", "nonexistent-project"])

            assert result.exit_code == 1

    def test_generate_with_chapter(self):
        """Test generate command with chapter option"""
        runner = CliRunner()

        with (
            patch("cli_summary.Path") as mock_path,
            patch("cli_summary.SummaryManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_chapters_dir = MagicMock()
            mock_chapters_dir.exists.return_value = True

            mock_chapter_file = MagicMock()
            mock_chapter_file.exists.return_value = True
            mock_chapter_file.read_text.return_value = "Chapter content"

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_chapters_dir, mock_chapter_file]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_summary = MagicMock()
            mock_summary.summary = "Test summary"
            mock_summary.key_events = ["event1", "event2"]
            mock_summary.characters = {"char1": "role1"}

            mock_manager = MagicMock()
            mock_manager.get_chapter_summary.return_value = None
            mock_manager.generate_chapter_summary.return_value = mock_summary
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(summary, ["generate", "test-project", "--chapter", "1"])

            assert result.exit_code in [0, 1]

    def test_generate_with_all(self):
        """Test generate command with --all option"""
        runner = CliRunner()

        with (
            patch("cli_summary.Path") as mock_path,
            patch("cli_summary.SummaryManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_chapters_dir = MagicMock()
            mock_chapters_dir.exists.return_value = True
            mock_chapters_dir.glob.return_value = [
                MagicMock(stem="chapter_1", read_text=lambda: "content1"),
                MagicMock(stem="chapter_2", read_text=lambda: "content2"),
            ]

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_chapters_dir]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_summary = MagicMock()
            mock_summary.chapter_number = 1

            mock_manager = MagicMock()
            mock_manager.batch_generate_summaries.return_value = [mock_summary]
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(summary, ["generate", "test-project", "--all"])

            assert result.exit_code in [0, 1]

    def test_generate_missing_options(self):
        """Test generate command without --chapter or --all"""
        runner = CliRunner()

        with patch("cli_summary.Path") as mock_path:
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            result = runner.invoke(summary, ["generate", "test-project"])

            assert result.exit_code == 1


class TestGroupCommand:
    """Test cases for group command"""

    def test_group_missing_project_name(self):
        """Test group command without project name"""
        runner = CliRunner()
        result = runner.invoke(summary, ["group"])

        assert result.exit_code != 0

    def test_group_success(self):
        """Test group command success"""
        runner = CliRunner()

        with (
            patch("cli_summary.Path") as mock_path,
            patch("cli_summary.SummaryManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_group_summary = MagicMock()
            mock_group_summary.summary = "Group summary"

            mock_manager = MagicMock()
            mock_manager.generate_group_summary.return_value = mock_group_summary
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(summary, ["group", "test-project", "--start", "1", "--end", "5"])

            assert result.exit_code in [0, 1]


class TestUpdateGlobalCommand:
    """Test cases for update-global command"""

    def test_update_global_missing_project_name(self):
        """Test update-global command without project name"""
        runner = CliRunner()
        result = runner.invoke(summary, ["update-global"])

        assert result.exit_code != 0

    def test_update_global_success(self):
        """Test update-global command success"""
        runner = CliRunner()

        with (
            patch("cli_summary.Path") as mock_path,
            patch("cli_summary.SummaryManager") as mock_manager_class,
            patch("cli_summary.SummaryStore") as mock_store_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_project_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_global_summary = MagicMock()
            mock_global_summary.total_chapters_covered = 10
            mock_global_summary.summary = "Global summary"
            mock_global_summary.last_updated = "2024-01-01"

            mock_manager = MagicMock()
            mock_manager.update_global_summary.return_value = mock_global_summary
            mock_manager_class.return_value = mock_manager

            mock_store = MagicMock()
            mock_store.list_chapter_summaries.return_value = [1, 2, 3]
            mock_store_class.return_value = mock_store

            result = runner.invoke(summary, ["update-global", "test-project"])

            assert result.exit_code in [0, 1]

    def test_update_global_no_summaries(self):
        """Test update-global command with no existing summaries"""
        runner = CliRunner()

        with (
            patch("cli_summary.Path") as mock_path,
            patch("cli_summary.SummaryManager") as mock_manager_class,
            patch("cli_summary.SummaryStore") as mock_store_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__ = MagicMock(
                side_effect=[mock_project_path, mock_project_path]
            )

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_manager = MagicMock()
            mock_manager_class.return_value = mock_manager

            mock_store = MagicMock()
            mock_store.list_chapter_summaries.return_value = []
            mock_store_class.return_value = mock_store

            result = runner.invoke(summary, ["update-global", "test-project"])

            assert result.exit_code == 1


class TestShowCommand:
    """Test cases for show command"""

    def test_show_missing_project_name(self):
        """Test show command without project name"""
        runner = CliRunner()
        result = runner.invoke(summary, ["show"])

        assert result.exit_code != 0

    def test_show_global_summary(self):
        """Test show command with --global option"""
        runner = CliRunner()

        with (
            patch("cli_summary.Path") as mock_path,
            patch("cli_summary.SummaryStore") as mock_store_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_global_summary = MagicMock()
            mock_global_summary.summary = "Global summary"
            mock_global_summary.total_chapters_covered = 10
            mock_global_summary.last_updated = "2024-01-01"

            mock_store = MagicMock()
            mock_store.load_global_summary.return_value = mock_global_summary
            mock_store_class.return_value = mock_store

            result = runner.invoke(summary, ["show", "test-project", "--global"])

            assert result.exit_code in [0, 1]

    def test_show_chapter_summary(self):
        """Test show command with chapter option"""
        runner = CliRunner()

        with (
            patch("cli_summary.Path") as mock_path,
            patch("cli_summary.SummaryStore") as mock_store_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_chapter_summary = MagicMock()
            mock_chapter_summary.summary = "Chapter summary"
            mock_chapter_summary.key_events = ["event1"]
            mock_chapter_summary.characters = {"char1": "role1"}

            mock_store = MagicMock()
            mock_store.load_chapter_summary.return_value = mock_chapter_summary
            mock_store_class.return_value = mock_store

            result = runner.invoke(summary, ["show", "test-project", "--chapter", "1"])

            assert result.exit_code in [0, 1]


class TestContextCommand:
    """Test cases for context command"""

    def test_context_missing_project_name(self):
        """Test context command without project name"""
        runner = CliRunner()
        result = runner.invoke(summary, ["context"])

        assert result.exit_code != 0

    def test_context_success(self):
        """Test context command success"""
        runner = CliRunner()

        with (
            patch("cli_summary.Path") as mock_path,
            patch("cli_summary.SummaryManager") as mock_manager_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_manager = MagicMock()
            mock_manager.get_context_for_chapter.return_value = "Context"
            mock_manager_class.return_value = mock_manager

            result = runner.invoke(summary, ["context", "test-project", "--chapter", "5"])

            assert result.exit_code in [0, 1]


class TestListCommand:
    """Test cases for list command"""

    def test_list_missing_project_name(self):
        """Test list command without project name"""
        runner = CliRunner()
        result = runner.invoke(summary, ["list"])

        assert result.exit_code != 0

    def test_list_success(self):
        """Test list command success"""
        runner = CliRunner()

        with (
            patch("cli_summary.Path") as mock_path,
            patch("cli_summary.SummaryStore") as mock_store_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_store = MagicMock()
            mock_store.list_chapter_summaries.return_value = [1, 2, 3]
            mock_store.list_group_summaries.return_value = []
            mock_store.load_global_summary.return_value = None
            mock_store_class.return_value = mock_store

            result = runner.invoke(summary, ["list", "test-project"])

            assert result.exit_code in [0, 1]


class TestStatsCommand:
    """Test cases for stats command"""

    def test_stats_missing_project_name(self):
        """Test stats command without project name"""
        runner = CliRunner()
        result = runner.invoke(summary, ["stats"])

        assert result.exit_code != 0

    def test_stats_success(self):
        """Test stats command success"""
        runner = CliRunner()

        with (
            patch("cli_summary.Path") as mock_path,
            patch("cli_summary.SummaryStore") as mock_store_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_store = MagicMock()
            mock_store.get_summary_statistics.return_value = {
                "chapter_summaries": 10,
                "group_summaries": 2,
                "has_global_summary": True,
                "total_words_summarized": 5000,
                "storage_format": "json",
            }
            mock_store_class.return_value = mock_store

            result = runner.invoke(summary, ["stats", "test-project"])

            assert result.exit_code in [0, 1]


class TestExportCommand:
    """Test cases for export command"""

    def test_export_missing_project_name(self):
        """Test export command without project name"""
        runner = CliRunner()
        result = runner.invoke(summary, ["export"])

        assert result.exit_code != 0

    def test_export_success(self):
        """Test export command success"""
        runner = CliRunner()

        with (
            patch("cli_summary.Path") as mock_path,
            patch("cli_summary.SummaryStore") as mock_store_class,
        ):
            mock_project_path = MagicMock()
            mock_project_path.exists.return_value = True

            mock_path_instance = MagicMock()
            mock_path_instance.__truediv__.return_value = mock_project_path

            mock_path.return_value.__truediv__.return_value = mock_path_instance

            mock_store = MagicMock()
            mock_store.export_summaries = MagicMock()
            mock_store_class.return_value = mock_store

            with runner.isolated_filesystem():
                result = runner.invoke(
                    summary, ["export", "test-project", "--output", "summaries.md"]
                )

                assert result.exit_code in [0, 1]
