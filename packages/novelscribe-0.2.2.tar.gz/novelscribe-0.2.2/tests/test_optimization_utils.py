"""Test result caching plugin for pytest.

This plugin caches test results and skips tests that have passed with the same
code version, significantly speeding up repeated test runs.
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
from pathlib import Path

import pytest

CACHE_DIR = Path.home() / ".cache" / "pytest-results"
CACHE_VERSION = "1.0"


def pytest_configure(config):
    """Initialize caching."""
    config.addinivalue_line("markers", "cached: test result can be cached")
    if not os.environ.get("PYTEST_SKIP_CACHE"):
        CACHE_DIR.mkdir(parents=True, exist_ok=True)


def pytest_collection_modifyitems(config, items):
    """Skip cached tests if they passed in the same code version."""
    if os.environ.get("PYTEST_SKIP_CACHE"):
        return

    for item in items:
        item.add_marker(pytest.mark.cached)


def get_source_hash(file_path: str) -> str:
    """Calculate hash of source file content."""
    try:
        path = Path(file_path)
        if path.exists():
            content = path.read_text()
            return hashlib.md5(content.encode()).hexdigest()[:8]
    except Exception:
        pass
    return ""


def get_code_hashes(test_path: str) -> dict[str, str]:
    """Get hashes of all source files used by a test."""
    test_file = Path(test_path)
    if not test_file.exists():
        return {}

    content = test_file.read_text()
    hashes = {str(test_file): hashlib.md5(content.encode()).hexdigest()[:8]}

    for line in content.split("\n"):
        line = line.strip()
        if line.startswith("from ") or line.startswith("import "):
            if " import " in line:
                module = line.split(" import ")[0].replace("from ", "").strip()
            else:
                module = line.replace("import ", "").strip().split(".")[0]

            if module and not module.startswith(".") and module not in sys.stdlib_module_names:
                for ext in ["", ".py"]:
                    for dir_name in ["", "core/", "api/", "agents/", "workflows/"]:
                        possible = Path(module).with_suffix(ext)
                        full_path = Path(".") / dir_name / possible
                        if full_path.exists():
                            hashes[str(full_path)] = get_source_hash(str(full_path))

    return hashes


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """Store test results in cache."""
    outcome = yield
    report = outcome.get_result()

    if os.environ.get("PYTEST_SKIP_CACHE"):
        return

    test_id = item.nodeid.replace("::", "_").replace("/", "_").replace("\\", "_")
    cache_file = CACHE_DIR / f"{test_id}.json"

    result = {
        "version": CACHE_VERSION,
        "test_id": item.nodeid,
        "outcome": report.outcome,
        "code_hashes": get_code_hashes(str(item.fspath)),
    }

    if report.when == "call":
        cache_file.write_text(json.dumps(result, indent=2))


def pytest_runtest_setup(item):
    """Check if test can be skipped due to caching."""
    if os.environ.get("PYTEST_SKIP_CACHE"):
        return

    test_id = item.nodeid.replace("::", "_").replace("/", "_").replace("\\", "_")
    cache_file = CACHE_DIR / f"{test_id}.json"

    if not cache_file.exists():
        return

    try:
        cached = json.loads(cache_file.read_text())

        if cached.get("version") != CACHE_VERSION:
            return

        if cached.get("outcome") != "passed":
            return

        current_hashes = get_code_hashes(str(item.fspath))
        cached_hashes = cached.get("code_hashes", {})

        if current_hashes == cached_hashes:
            pytest.skip("Cached test result (no code changes)")

        for path, current_hash in current_hashes.items():
            cached_hash = cached_hashes.get(path)
            if cached_hash and cached_hash != current_hash:
                return

        pytest.skip("Cached test result (no relevant code changes)")

    except Exception:
        pass
