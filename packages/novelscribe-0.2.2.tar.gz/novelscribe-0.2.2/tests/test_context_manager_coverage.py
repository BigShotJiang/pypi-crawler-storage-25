"""Comprehensive tests for core/context_manager.py to increase coverage."""

from __future__ import annotations

from core.context_manager import ContextManagerConfig, ContextStrategy


class TestContextManagerConfig:
    """Test ContextManagerConfig."""

    def test_default_config(self):
        """Test default configuration."""
        config = ContextManagerConfig()
        assert config.strategy == ContextStrategy.HYBRID
        assert config.max_context_chunks == 10
        assert config.chunk_overlap_tokens == 200
        assert config.recent_chapters_full == 5
        assert config.summary_chapters_limit == 20

    def test_custom_config(self):
        """Test custom configuration."""
        config = ContextManagerConfig(
            strategy=ContextStrategy.SUMMARIZATION,
            max_context_chunks=5,
            chunk_overlap_tokens=100,
            recent_chapters_full=3,
            summary_chapters_limit=10,
        )
        assert config.strategy == ContextStrategy.SUMMARIZATION
        assert config.max_context_chunks == 5
        assert config.chunk_overlap_tokens == 100
        assert config.recent_chapters_full == 3
        assert config.summary_chapters_limit == 10

    def test_config_with_strategy(self):
        """Test configuration with different strategies."""
        config = ContextManagerConfig(strategy=ContextStrategy.FULL_CONTEXT)
        assert config.strategy == ContextStrategy.FULL_CONTEXT

    def test_config_serialization(self):
        """Test config can be serialized."""
        config = ContextManagerConfig()
        data = config.model_dump()
        assert isinstance(data, dict)
        assert "strategy" in data

    def test_config_copy(self):
        """Test config can be copied."""
        config = ContextManagerConfig(max_context_chunks=5)
        config_copy = config.model_copy()
        assert config_copy.max_context_chunks == 5
