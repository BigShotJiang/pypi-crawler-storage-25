"""
Comprehensive tests for agent_queue.py to increase coverage to 90%+.
Tests queue operations, dependencies, retries, and timeout handling.
"""

import asyncio
import time
from unittest.mock import patch

import pytest

from novel_harness.core.agent_queue import (
    AgentQueue,
    AgentTask,
    TaskResult,
    TaskStatus,
    get_agent_queue,
    reset_agent_queue,
)


class TestTaskStatus:
    """Test TaskStatus enum."""

    def test_all_statuses_exist(self):
        """Test all task statuses are defined."""
        assert TaskStatus.PENDING == "pending"
        assert TaskStatus.WAITING == "waiting"
        assert TaskStatus.RUNNING == "running"
        assert TaskStatus.COMPLETED == "completed"
        assert TaskStatus.FAILED == "failed"
        assert TaskStatus.TIMEOUT == "timeout"
        assert TaskStatus.CANCELLED == "cancelled"


class TestAgentTask:
    """Test AgentTask dataclass."""

    def test_task_creation(self):
        """Test creating an agent task."""
        task = AgentTask(
            task_id="test_1",
            agent_name="test_agent",
            prompt="Test prompt",
        )

        assert task.task_id == "test_1"
        assert task.agent_name == "test_agent"
        assert task.prompt == "Test prompt"
        assert task.priority == 0
        assert task.retry_count == 0
        assert task.max_retries == 3

    def test_task_priority_comparison(self):
        """Test task priority comparison."""
        task1 = AgentTask(task_id="1", agent_name="a", prompt="p", priority=1)
        task2 = AgentTask(task_id="2", agent_name="a", prompt="p", priority=5)

        assert task1 < task2

    def test_task_with_dependencies(self):
        """Test task with dependencies."""
        task = AgentTask(
            task_id="child",
            agent_name="agent",
            prompt="prompt",
            dependencies=["parent1", "parent2"],
        )

        assert len(task.dependencies) == 2
        assert "parent1" in task.dependencies

    def test_task_with_metadata(self):
        """Test task with metadata."""
        task = AgentTask(
            task_id="test",
            agent_name="agent",
            prompt="prompt",
            metadata={"key": "value"},
        )

        assert task.metadata == {"key": "value"}


class TestTaskResult:
    """Test TaskResult dataclass."""

    def test_result_creation(self):
        """Test creating a task result."""
        result = TaskResult(
            task_id="test_1",
            agent_name="test_agent",
            status=TaskStatus.PENDING,
        )

        assert result.task_id == "test_1"
        assert result.status == TaskStatus.PENDING
        assert result.result is None
        assert result.error is None


class TestAgentQueueInit:
    """Test AgentQueue initialization."""

    def test_init_with_defaults(self):
        """Test initialization with defaults."""
        queue = AgentQueue()

        assert queue.max_concurrent == 3
        assert queue.tasks == {}
        assert queue.results == {}
        assert queue.running == set()

    def test_init_with_custom_max_concurrent(self):
        """Test initialization with custom concurrency."""
        queue = AgentQueue(max_concurrent=10)

        assert queue.max_concurrent == 10


class TestSubmit:
    """Test task submission."""

    def test_submit_single_task(self):
        """Test submitting a single task."""
        queue = AgentQueue()
        task = AgentTask(task_id="test_1", agent_name="agent", prompt="prompt")

        task_id = queue.submit(task)

        assert task_id == "test_1"
        assert "test_1" in queue.tasks

    def test_submit_task_generates_id(self):
        """Test that submit generates task ID if not provided."""
        queue = AgentQueue()
        task = AgentTask(task_id="", agent_name="agent", prompt="prompt")

        task_id = queue.submit(task)

        assert task_id != ""
        assert task_id in queue.tasks

    def test_submit_with_dependencies(self):
        """Test submitting task with dependencies."""
        queue = AgentQueue()
        task = AgentTask(
            task_id="child",
            agent_name="agent",
            prompt="prompt",
            dependencies=["parent1"],
        )

        queue.submit(task)

        assert "child" in queue.tasks
        assert "parent1" in queue.waiting

    def test_submit_batch(self):
        """Test submitting multiple tasks."""
        queue = AgentQueue()
        tasks = [
            AgentTask(task_id="1", agent_name="a", prompt="p"),
            AgentTask(task_id="2", agent_name="b", prompt="p"),
        ]

        task_ids = queue.submit_batch(tasks)

        assert len(task_ids) == 2
        assert "1" in queue.tasks
        assert "2" in queue.tasks


class TestGetReadyTasks:
    """Test get_ready_tasks method."""

    def test_no_tasks(self):
        """Test with no tasks."""
        queue = AgentQueue()

        ready = queue.get_ready_tasks()

        assert ready == []

    def test_single_task_ready(self):
        """Test single task is ready."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="p"))

        ready = queue.get_ready_tasks()

        assert len(ready) == 1

    def test_task_with_unmet_dependency(self):
        """Test task waiting for dependency."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="p"))
        queue.submit(AgentTask(task_id="2", agent_name="b", prompt="p", dependencies=["1"]))

        # Track task 1 as running (simulating execution in progress)
        queue.running.add("1")

        ready = queue.get_ready_tasks()

        # Task 2 should not be ready because task 1 is still running
        # (even though we didn't complete it, it's in the results check)
        task_ids = [t.task_id for t in ready]
        assert "1" not in task_ids

    def test_task_with_met_dependency(self):
        """Test task after dependency completes."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="p"))
        queue.submit(AgentTask(task_id="2", agent_name="b", prompt="p", dependencies=["1"]))

        # Mark task 1 as completed in results
        queue.results["1"] = TaskResult(task_id="1", agent_name="a", status=TaskStatus.COMPLETED)

        ready = queue.get_ready_tasks()

        # Only task 2 is ready now (task 1 is already completed/skipped)
        assert len(ready) == 1
        assert ready[0].task_id == "2"

    def test_priority_ordering(self):
        """Test tasks are ordered by priority."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="low", agent_name="a", prompt="p", priority=1))
        queue.submit(AgentTask(task_id="high", agent_name="b", prompt="p", priority=10))

        ready = queue.get_ready_tasks()

        assert ready[0].task_id == "high"
        assert ready[1].task_id == "low"


class TestGetWaitingTasks:
    """Test get_waiting_tasks method."""

    def test_no_waiting_tasks(self):
        """Test with no waiting tasks."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="p"))

        waiting = queue.get_waiting_tasks()

        assert len(waiting) == 0

    def test_task_waiting_on_dependency(self):
        """Test task waiting on dependency."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="p"))
        queue.submit(AgentTask(task_id="2", agent_name="b", prompt="p", dependencies=["1"]))

        waiting = queue.get_waiting_tasks()

        assert "2" in waiting
        assert "1" in waiting["2"]


class TestExecuteTask:
    """Test execute_task method."""

    @pytest.mark.asyncio
    async def test_execute_success(self):
        """Test successful task execution."""
        queue = AgentQueue()

        async def executor(name, prompt, **kwargs):
            return f"result: {prompt}"

        task = AgentTask(task_id="1", agent_name="a", prompt="test")
        result = await queue.execute_task(task, executor)

        assert result.status == TaskStatus.COMPLETED
        assert result.result == "result: test"

    @pytest.mark.asyncio
    async def test_execute_timeout(self):
        """Test task timeout."""
        queue = AgentQueue()

        async def slow_executor(name, prompt, **kwargs):
            await asyncio.sleep(10)
            return "done"

        task = AgentTask(task_id="1", agent_name="a", prompt="test", timeout=0.1)
        result = await queue.execute_task(task, slow_executor)

        assert result.status == TaskStatus.TIMEOUT
        assert "timed out" in result.error

    @pytest.mark.asyncio
    async def test_execute_failure(self):
        """Test task failure."""
        queue = AgentQueue()

        async def failing_executor(name, prompt, **kwargs):
            raise ValueError("Execution failed")

        task = AgentTask(task_id="1", agent_name="a", prompt="test")
        result = await queue.execute_task(task, failing_executor)

        assert result.status == TaskStatus.PENDING  # Will retry

    @pytest.mark.asyncio
    async def test_execute_no_more_retries(self):
        """Test task with no retries remaining."""
        queue = AgentQueue()

        async def failing_executor(name, prompt, **kwargs):
            raise ValueError("Execution failed")

        task = AgentTask(task_id="1", agent_name="a", prompt="test", retry_count=3, max_retries=3)
        result = await queue.execute_task(task, failing_executor)

        assert result.status == TaskStatus.FAILED
        assert result.error == "Execution failed"


class TestExecuteAll:
    """Test execute_all method."""

    @pytest.mark.asyncio
    async def test_execute_all_empty(self):
        """Test executing with no tasks."""
        queue = AgentQueue()

        async def executor(name, prompt, **kwargs):
            return "done"

        results = await queue.execute_all(executor)

        assert results == {}

    @pytest.mark.asyncio
    async def test_execute_all_single_task(self):
        """Test executing single task."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="test"))

        async def executor(name, prompt, **kwargs):
            return f"done: {prompt}"

        results = await queue.execute_all(executor)

        assert "1" in results
        assert results["1"].status == TaskStatus.COMPLETED

    @pytest.mark.asyncio
    async def test_execute_all_with_progress_callback(self):
        """Test executing with progress callback."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="test"))

        progress_calls = []

        async def executor(name, prompt, **kwargs):
            return "done"

        def progress_callback(task_id, status):
            progress_calls.append((task_id, status))

        await queue.execute_all(executor, progress_callback)

        assert len(progress_calls) > 0


class TestExecuteParallel:
    """Test execute_parallel method."""

    @pytest.mark.asyncio
    async def test_execute_parallel(self):
        """Test parallel execution."""
        queue = AgentQueue()

        async def executor(name, prompt, **kwargs):
            await asyncio.sleep(0.01)
            return f"done: {prompt}"

        tasks = [
            AgentTask(task_id="1", agent_name="a", prompt="test1"),
            AgentTask(task_id="2", agent_name="b", prompt="test2"),
        ]

        results = await queue.execute_parallel(tasks, executor)

        assert "1" in results
        assert "2" in results


class TestGetProgress:
    """Test get_progress method."""

    def test_empty_queue_progress(self):
        """Test progress with empty queue."""
        queue = AgentQueue()

        progress = queue.get_progress()

        assert progress["total"] == 0
        assert progress["completed"] == 0
        assert progress["progress"] == 0

    def test_progress_with_tasks(self):
        """Test progress with tasks."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="p"))
        queue.submit(AgentTask(task_id="2", agent_name="b", prompt="p"))

        progress = queue.get_progress()

        assert progress["total"] == 2
        assert progress["completed"] == 0


class TestGetResult:
    """Test result retrieval methods."""

    def test_get_result_exists(self):
        """Test getting existing result."""
        queue = AgentQueue()
        result = TaskResult(task_id="1", agent_name="a", status=TaskStatus.COMPLETED)
        queue.results["1"] = result

        retrieved = queue.get_result("1")

        assert retrieved == result

    def test_get_result_not_exists(self):
        """Test getting non-existent result."""
        queue = AgentQueue()

        retrieved = queue.get_result("missing")

        assert retrieved is None

    def test_get_results_by_agent(self):
        """Test getting results by agent name."""
        queue = AgentQueue()
        queue.results["1"] = TaskResult(
            task_id="1", agent_name="agent_a", status=TaskStatus.COMPLETED
        )
        queue.results["2"] = TaskResult(
            task_id="2", agent_name="agent_b", status=TaskStatus.COMPLETED
        )

        results = queue.get_results_by_agent("agent_a")

        assert len(results) == 1
        assert "1" in results


class TestCancel:
    """Test cancellation methods."""

    def test_cancel_task(self):
        """Test cancelling specific task."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="p"))

        result = queue.cancel_task("1")

        assert result is True
        assert queue.tasks["1"].status == TaskStatus.CANCELLED

    def test_cancel_nonexistent_task(self):
        """Test cancelling non-existent task."""
        queue = AgentQueue()

        result = queue.cancel_task("missing")

        assert result is False

    def test_cancel_all(self):
        """Test cancelling all tasks."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="p"))
        queue.submit(AgentTask(task_id="2", agent_name="b", prompt="p"))

        queue.cancel_all()

        assert len(queue.tasks) == 0
        assert len(queue.results) == 0


class TestWaitForCompletion:
    """Test wait_for_completion method."""

    def test_wait_already_complete(self):
        """Test wait when already complete."""
        queue = AgentQueue()

        result = queue.wait_for_completion(timeout=1)

        assert result is True

    def test_wait_timeout(self):
        """Test wait with timeout."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="p"))

        start = time.time()
        result = queue.wait_for_completion(timeout=0.1)
        elapsed = time.time() - start

        assert result is False
        assert elapsed >= 0.1


class TestGlobalQueue:
    """Test global queue functions."""

    @pytest.mark.asyncio
    async def test_get_agent_queue(self):
        """Test getting global agent queue."""
        reset_agent_queue()

        queue1 = get_agent_queue()
        queue2 = get_agent_queue()

        assert queue1 is queue2

    @pytest.mark.asyncio
    async def test_reset_agent_queue(self):
        """Test resetting global queue."""
        queue1 = get_agent_queue()
        reset_agent_queue()
        queue2 = get_agent_queue()

        assert queue1 is not queue2


class TestAgentQueueExtendedCoverage:
    """Tests for missing coverage lines in agent_queue.py."""

    def test_get_ready_tasks_skips_running(self):
        """Test get_ready_tasks skips running tasks (line 161→146)."""
        queue = AgentQueue()
        task = AgentTask(task_id="1", agent_name="a", prompt="p")
        queue.submit(task)
        queue.running.add("1")

        ready = queue.get_ready_tasks()
        assert len(ready) == 0

    def test_get_waiting_tasks_skips_running(self):
        """Test get_waiting_tasks skips running tasks (line 175)."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="p"))
        queue.submit(AgentTask(task_id="2", agent_name="b", prompt="p", dependencies=["1"]))
        queue.running.add("2")

        waiting = queue.get_waiting_tasks()
        assert "2" not in waiting

    @pytest.mark.asyncio
    async def test_execute_task_sync_function(self):
        """Test execute_task with non-coroutine function (line 222)."""
        queue = AgentQueue()

        def sync_executor(name, prompt, metadata):
            return f"sync_result: {prompt}"

        task = AgentTask(task_id="1", agent_name="a", prompt="test")
        result = await queue.execute_task(task, sync_executor)

        assert result.status == TaskStatus.COMPLETED
        assert result.result == "sync_result: test"

    @pytest.mark.asyncio
    async def test_execute_all_waiting_deps_break_completed(self):
        """Test execute_all breaks when waiting deps have completed tasks (lines 286-300)."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="p"))
        queue.submit(AgentTask(task_id="2", agent_name="b", prompt="p", dependencies=["1"]))

        queue.results["2"] = TaskResult(task_id="2", agent_name="b", status=TaskStatus.COMPLETED)

        async def executor(name, prompt, **kwargs):
            return "done"

        results = await queue.execute_all(executor)
        assert "1" in results

    @pytest.mark.asyncio
    async def test_execute_all_waiting_deps_no_pending_tasks(self):
        """Test execute_all when waiting has tasks but none in self.tasks (line 301-302)."""
        queue = AgentQueue()

        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="p"))
        queue.results["1"] = TaskResult(task_id="1", agent_name="a", status=TaskStatus.FAILED)
        queue.running.discard("1")

        queue.submit(
            AgentTask(task_id="2", agent_name="b", prompt="p", dependencies=["nonexistent"])
        )
        queue.running.discard("2")

        async def executor(name, prompt, **kwargs):
            return "done"

        results = await queue.execute_all(executor)
        assert "1" in results

    def test_wait_for_completion_with_waiting_all_completed(self):
        """Test wait_for_completion with waiting tasks that are all completed (lines 401-410)."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="p"))
        queue.submit(AgentTask(task_id="2", agent_name="b", prompt="p", dependencies=["1"]))

        queue.results["1"] = TaskResult(task_id="1", agent_name="a", status=TaskStatus.COMPLETED)
        queue.results["2"] = TaskResult(task_id="2", agent_name="b", status=TaskStatus.COMPLETED)

        result = queue.wait_for_completion(timeout=1)
        assert result is True


class TestCoverageGaps:
    """Tests targeting specific uncovered branches: 161->146, 286-302, 401->410."""

    def test_get_ready_tasks_failed_dependency(self):
        """Cover 161->146: deps_completed False when dep result is FAILED."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="p"))
        queue.submit(AgentTask(task_id="2", agent_name="b", prompt="p", dependencies=["1"]))
        queue.results["1"] = TaskResult(task_id="1", agent_name="a", status=TaskStatus.FAILED)

        ready = queue.get_ready_tasks()

        assert len(ready) == 0

    @pytest.mark.asyncio
    async def test_execute_all_unresolvable_dependency(self):
        """Cover 286-300: waiting block with failed dep, no pending completed -> break."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="p"))
        queue.submit(AgentTask(task_id="2", agent_name="b", prompt="p", dependencies=["1"]))
        queue.results["1"] = TaskResult(task_id="1", agent_name="a", status=TaskStatus.FAILED)

        async def executor(name: str, prompt: str, **kwargs: object) -> str:
            return "done"

        results = await queue.execute_all(executor)
        assert "1" in results
        assert results["1"].status == TaskStatus.FAILED

    @pytest.mark.asyncio
    async def test_execute_all_waiting_continue_path(self):
        """Cover 299 (continue): mock get_waiting_tasks so completed list is non-empty."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="p"))
        queue.results["1"] = TaskResult(task_id="1", agent_name="a", status=TaskStatus.COMPLETED)
        queue.submit(AgentTask(task_id="2", agent_name="b", prompt="p", dependencies=["ghost"]))
        queue.results["2"] = TaskResult(task_id="2", agent_name="b", status=TaskStatus.COMPLETED)

        call_count = 0

        def mock_get_waiting():
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return {"2": ["ghost"]}
            return {}

        async def executor(name: str, prompt: str, **kwargs: object) -> str:
            return "done"

        with patch.object(queue, "get_waiting_tasks", side_effect=mock_get_waiting):
            with patch.object(queue, "get_ready_tasks", return_value=[]):
                results = await queue.execute_all(executor)

        assert "1" in results

    @pytest.mark.asyncio
    async def test_execute_all_waiting_no_pending_tasks(self):
        """Cover 301-302: pending_tasks empty when waiting keys not in self.tasks."""
        queue = AgentQueue()

        async def executor(name: str, prompt: str, **kwargs: object) -> str:
            return "done"

        with patch.object(queue, "get_waiting_tasks", return_value={"ghost": ["dep"]}):
            with patch.object(queue, "get_ready_tasks", return_value=[]):
                results = await queue.execute_all(executor)

        assert results == {}

    def test_wait_for_completion_waiting_all_false(self):
        """Cover 401->410: waiting non-empty, all() False, falls to time.sleep, then timeout."""
        queue = AgentQueue()
        queue.submit(AgentTask(task_id="1", agent_name="a", prompt="p"))
        queue.submit(AgentTask(task_id="2", agent_name="b", prompt="p", dependencies=["1"]))
        queue.results["1"] = TaskResult(task_id="1", agent_name="a", status=TaskStatus.FAILED)

        result = queue.wait_for_completion(timeout=0.3)
        assert result is False
