"""Tests for core.quality_gate module."""

from datetime import datetime
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from core.quality_gate import (
    FixApproach,
    FixSuggestionResponse,
    GateResult,
    QualityGate,
    QualityGateConfig,
    QualityLevel,
)
from core.quality_metrics import QualityMetrics
from core.validation_system import ValidationReport


class TestQualityLevel:
    """Test QualityLevel enum."""

    def test_quality_level_values(self):
        """Test QualityLevel enum has correct values."""
        assert QualityLevel.BRONZE == "bronze"
        assert QualityLevel.SILVER == "silver"
        assert QualityLevel.GOLD == "gold"
        assert QualityLevel.PLATINUM == "platinum"


class TestQualityGateConfig:
    """Test QualityGateConfig class."""

    def test_default_values(self):
        """Test default configuration values."""
        config = QualityGateConfig()
        assert config.min_word_count == 1000
        assert config.max_passive_voice == 0.15
        assert config.min_readability_ease == 60.0
        assert config.min_dialogue_clarity == 0.7
        assert config.min_character_consistency == 0.8
        assert config.min_vocabulary_diversity == 0.4
        assert config.max_adverb_frequency == 0.08
        assert config.min_quality_score == 0.6

    def test_get_bronze_config(self):
        """Test Bronze level configuration."""
        config = QualityGateConfig().get_level_config(QualityLevel.BRONZE)
        assert config.min_word_count == 800
        assert config.max_passive_voice == 0.20
        assert config.min_readability_ease == 50.0
        assert config.min_dialogue_clarity == 0.5
        assert config.min_character_consistency == 0.6
        assert config.min_vocabulary_diversity == 0.3
        assert config.max_adverb_frequency == 0.12
        assert config.min_quality_score == 0.6

    def test_get_silver_config(self):
        """Test Silver level configuration."""
        config = QualityGateConfig().get_level_config(QualityLevel.SILVER)
        assert config.min_word_count == 1000
        assert config.max_passive_voice == 0.15
        assert config.min_readability_ease == 60.0
        assert config.min_dialogue_clarity == 0.7
        assert config.min_character_consistency == 0.8
        assert config.min_vocabulary_diversity == 0.4
        assert config.max_adverb_frequency == 0.08
        assert config.min_quality_score == 0.7

    def test_get_gold_config(self):
        """Test Gold level configuration."""
        config = QualityGateConfig().get_level_config(QualityLevel.GOLD)
        assert config.min_word_count == 1500
        assert config.max_passive_voice == 0.10
        assert config.min_readability_ease == 70.0
        assert config.min_dialogue_clarity == 0.8
        assert config.min_character_consistency == 0.9
        assert config.min_vocabulary_diversity == 0.5
        assert config.max_adverb_frequency == 0.05
        assert config.min_quality_score == 0.8

    def test_get_platinum_config(self):
        """Test Platinum level configuration."""
        config = QualityGateConfig().get_level_config(QualityLevel.PLATINUM)
        assert config.min_word_count == 2000
        assert config.max_passive_voice == 0.05
        assert config.min_readability_ease == 80.0
        assert config.min_dialogue_clarity == 0.9
        assert config.min_character_consistency == 0.95
        assert config.min_vocabulary_diversity == 0.6
        assert config.max_adverb_frequency == 0.03
        assert config.min_quality_score == 0.9

    def test_get_level_config_default(self):
        """Test get_level_config returns self for unknown level."""
        default_config = QualityGateConfig()
        config = default_config.get_level_config(None)
        assert config is default_config


class TestGateResult:
    """Test GateResult model."""

    def test_pass_rate_all_passed(self):
        """Test pass_rate when all criteria pass."""
        result = GateResult(
            gate_level=QualityLevel.SILVER,
            passed=True,
            scores={"word_count": 1500, "passive_voice": 0.1},
            failed_criteria=[],
            recommendations=[],
        )
        assert result.pass_rate == 1.0

    def test_pass_rate_partial_failed(self):
        """Test pass_rate when some criteria fail."""
        result = GateResult(
            gate_level=QualityLevel.SILVER,
            passed=False,
            scores={"word_count": 1500, "passive_voice": 0.1, "readability_ease": 50},
            failed_criteria=["readability_ease"],
            recommendations=[],
        )
        assert result.pass_rate == 2 / 3

    def test_pass_rate_no_criteria(self):
        """Test pass_rate when no criteria."""
        result = GateResult(
            gate_level=QualityLevel.SILVER,
            passed=True,
            scores={},
            failed_criteria=[],
            recommendations=[],
        )
        assert result.pass_rate == 1.0

    def test_overall_score_default(self):
        """Test default overall_score."""
        result = GateResult(
            gate_level=QualityLevel.SILVER,
            passed=True,
            scores={},
            failed_criteria=[],
            recommendations=[],
        )
        assert result.overall_score == 0.0

    def test_timestamp_default(self):
        """Test default timestamp."""
        result = GateResult(
            gate_level=QualityLevel.SILVER,
            passed=True,
            scores={},
            failed_criteria=[],
            recommendations=[],
        )
        assert isinstance(result.timestamp, datetime)


class TestQualityGate:
    """Test QualityGate class."""

    @pytest.fixture
    def quality_gate(self):
        """Create a QualityGate instance for testing."""
        return QualityGate()

    @pytest.fixture
    def mock_metrics(self):
        """Create mock QualityMetrics."""
        metrics = MagicMock(spec=QualityMetrics)
        metrics.word_count = 1200
        metrics.passive_voice_ratio = 0.12
        metrics.flesch_kincaid = 65.0
        metrics.speaker_clarity = 0.75
        metrics.character_consistency = 0.85
        metrics.vocabulary_diversity = 0.45
        metrics.adverb_frequency = 0.07
        metrics.overall_quality_score = 0.75
        return metrics

    def test_init_default_project_root(self, quality_gate):
        """Test initialization with default project root."""
        assert isinstance(quality_gate.project_root, Path)
        assert quality_gate.gate_history == {}

    def test_init_custom_project_root(self):
        """Test initialization with custom project root."""
        custom_path = Path("/custom/path")
        gate = QualityGate(project_root=custom_path)
        assert gate.project_root == custom_path

    def test_load_fix_suggestions_file_not_found(self, tmp_path):
        """Test _load_fix_suggestions when file doesn't exist."""
        gate = QualityGate(project_root=tmp_path)
        assert gate._fix_suggestions_cache == {}

    def test_load_fix_suggestions_yaml_error(self, tmp_path):
        """Test _load_fix_suggestions with invalid YAML."""
        data_dir = tmp_path / "core" / "data" / "suggestions"
        data_dir.mkdir(parents=True)
        quality_file = data_dir / "quality_suggestions.yaml"
        quality_file.write_text("invalid: yaml: content: [")

        gate = QualityGate(project_root=tmp_path)
        assert gate._fix_suggestions_cache == {}

    def test_check_criterion_greater_than_or_equal(self, quality_gate):
        """Test _check_criterion with >= operator."""
        assert quality_gate._check_criterion(10.0, 5.0, ">=") is True
        assert quality_gate._check_criterion(5.0, 5.0, ">=") is True
        assert quality_gate._check_criterion(3.0, 5.0, ">=") is False

    def test_check_criterion_less_than_or_equal(self, quality_gate):
        """Test _check_criterion with <= operator."""
        assert quality_gate._check_criterion(3.0, 5.0, "<=") is True
        assert quality_gate._check_criterion(5.0, 5.0, "<=") is True
        assert quality_gate._check_criterion(7.0, 5.0, "<=") is False

    def test_check_criterion_greater_than(self, quality_gate):
        """Test _check_criterion with > operator."""
        assert quality_gate._check_criterion(7.0, 5.0, ">") is True
        assert quality_gate._check_criterion(5.0, 5.0, ">") is False

    def test_check_criterion_less_than(self, quality_gate):
        """Test _check_criterion with < operator."""
        assert quality_gate._check_criterion(3.0, 5.0, "<") is True
        assert quality_gate._check_criterion(5.0, 5.0, "<") is False

    def test_check_criterion_invalid_operator(self, quality_gate):
        """Test _check_criterion with invalid operator."""
        assert quality_gate._check_criterion(5.0, 5.0, "==") is False

    def test_check_validation_report_bronze(self, quality_gate):
        """Test _check_validation_report for Bronze level."""
        report = ValidationReport(errors=0, warnings=5, total_rules_checked=10, passed_rules=8)
        assert quality_gate._check_validation_report(report, QualityLevel.BRONZE) is True

        report = ValidationReport(errors=1, warnings=0, total_rules_checked=10, passed_rules=9)
        assert quality_gate._check_validation_report(report, QualityLevel.BRONZE) is False

    def test_check_validation_report_silver(self, quality_gate):
        """Test _check_validation_report for Silver level."""
        report = ValidationReport(errors=0, warnings=2, total_rules_checked=10, passed_rules=8)
        assert quality_gate._check_validation_report(report, QualityLevel.SILVER) is True

        report = ValidationReport(errors=0, warnings=3, total_rules_checked=10, passed_rules=7)
        assert quality_gate._check_validation_report(report, QualityLevel.SILVER) is False

        report = ValidationReport(errors=1, warnings=0, total_rules_checked=10, passed_rules=9)
        assert quality_gate._check_validation_report(report, QualityLevel.SILVER) is False

    def test_check_validation_report_gold(self, quality_gate):
        """Test _check_validation_report for Gold level."""
        report = ValidationReport(errors=0, warnings=0, total_rules_checked=10, passed_rules=10)
        assert quality_gate._check_validation_report(report, QualityLevel.GOLD) is True

        report = ValidationReport(errors=0, warnings=1, total_rules_checked=10, passed_rules=9)
        assert quality_gate._check_validation_report(report, QualityLevel.GOLD) is False

    def test_check_validation_report_platinum(self, quality_gate):
        """Test _check_validation_report for Platinum level."""
        report = ValidationReport(
            errors=0, warnings=0, total_rules_checked=25, passed_rules=24
        )  # 0.96 success rate
        assert quality_gate._check_validation_report(report, QualityLevel.PLATINUM) is True

        report = ValidationReport(
            errors=0, warnings=0, total_rules_checked=50, passed_rules=47
        )  # 0.94 success rate
        assert quality_gate._check_validation_report(report, QualityLevel.PLATINUM) is False

    def test_calculate_overall_score(self, quality_gate):
        """Test _calculate_overall_score calculation."""
        scores = {
            "quality_score": 0.8,
            "readability_ease": 70.0,
            "dialogue_clarity": 0.8,
            "character_consistency": 0.9,
            "vocabulary_diversity": 0.5,
            "passive_voice": 0.1,
            "adverb_frequency": 0.05,
            "word_count": 1500,
        }
        config = QualityGateConfig()
        score = quality_gate._calculate_overall_score(scores, config)
        assert 0.0 <= score <= 1.0

    def test_calculate_overall_score_with_validation(self, quality_gate):
        """Test _calculate_overall_score includes validation."""
        scores = {
            "quality_score": 0.8,
            "readability_ease": 70.0,
            "validation": 1.0,
        }
        config = QualityGateConfig()
        score = quality_gate._calculate_overall_score(scores, config)
        assert 0.0 <= score <= 1.0

    def test_check_quality_gate_all_pass(self, quality_gate, mock_metrics):
        """Test check_quality_gate when all criteria pass."""
        result = quality_gate.check_quality_gate(
            "test_project", mock_metrics, target_level=QualityLevel.SILVER
        )
        assert result.passed is True
        assert len(result.failed_criteria) == 0
        assert result.gate_level == QualityLevel.SILVER

    def test_check_quality_gate_with_failures(self, quality_gate):
        """Test check_quality_gate with failing criteria."""
        metrics = MagicMock(spec=QualityMetrics)
        metrics.word_count = 500
        metrics.passive_voice_ratio = 0.25
        metrics.flesch_kincaid = 40.0
        metrics.speaker_clarity = 0.4
        metrics.character_consistency = 0.5
        metrics.vocabulary_diversity = 0.2
        metrics.adverb_frequency = 0.15
        metrics.overall_quality_score = 0.5

        result = quality_gate.check_quality_gate(
            "test_project", metrics, target_level=QualityLevel.SILVER
        )
        assert result.passed is False
        assert len(result.failed_criteria) > 0
        assert len(result.recommendations) > 0

    def test_check_quality_gate_with_validation_report(self, quality_gate, mock_metrics):
        """Test check_quality_gate with validation report."""
        report = ValidationReport(errors=0, warnings=0)
        result = quality_gate.check_quality_gate(
            "test_project", mock_metrics, validation_report=report, target_level=QualityLevel.SILVER
        )
        assert "validation" in result.scores
        assert result.scores["validation"] == 1.0

    def test_check_quality_gate_records_history(self, quality_gate, mock_metrics):
        """Test check_quality_gate records results in history."""
        quality_gate.check_quality_gate(
            "test_project", mock_metrics, target_level=QualityLevel.SILVER
        )
        assert "test_project" in quality_gate.gate_history
        assert len(quality_gate.gate_history["test_project"]) == 1

    def test_determine_urgency_critical(self, quality_gate):
        """Test _determine_urgency for validation failures."""
        urgency = quality_gate._determine_urgency(["validation"], QualityLevel.SILVER)
        assert urgency == "critical"

    def test_determine_urgency_high_level(self, quality_gate):
        """Test _determine_urgency for high quality levels."""
        urgency = quality_gate._determine_urgency(["word_count"], QualityLevel.PLATINUM)
        assert urgency == "high"

    def test_determine_urgency_many_failures(self, quality_gate):
        """Test _determine_urgency with many failed criteria."""
        urgency = quality_gate._determine_urgency(
            ["word_count", "passive_voice", "readability_ease", "dialogue_clarity"],
            QualityLevel.SILVER,
        )
        assert urgency == "high"

    def test_determine_urgency_medium(self, quality_gate):
        """Test _determine_urgency with 2 failures."""
        urgency = quality_gate._determine_urgency(
            ["word_count", "passive_voice"], QualityLevel.SILVER
        )
        assert urgency == "medium"

    def test_determine_urgency_low(self, quality_gate):
        """Test _determine_urgency with single failure."""
        urgency = quality_gate._determine_urgency(["word_count"], QualityLevel.SILVER)
        assert urgency == "low"

    def test_generate_issue_summary_single(self, quality_gate):
        """Test _generate_issue_summary with single issue."""
        summary = quality_gate._generate_issue_summary(["word_count"])
        assert "Word count" in summary

    def test_generate_issue_summary_two(self, quality_gate):
        """Test _generate_issue_summary with two issues."""
        summary = quality_gate._generate_issue_summary(["word_count", "passive_voice"])
        assert "Word count" in summary
        assert "Passive voice" in summary
        assert "and" in summary

    def test_generate_issue_summary_multiple(self, quality_gate):
        """Test _generate_issue_summary with multiple issues."""
        summary = quality_gate._generate_issue_summary(
            ["word_count", "passive_voice", "readability_ease"]
        )
        assert "Word count" in summary
        assert "Passive voice" in summary
        assert "Readability" in summary

    def test_estimate_fix_time_validation(self, quality_gate):
        """Test _estimate_fix_time with validation errors."""
        time = quality_gate._estimate_fix_time(["validation"], QualityLevel.SILVER)
        assert time == "15-30 minutes"

    def test_estimate_fix_time_by_level(self, quality_gate):
        """Test _estimate_fix_time by quality level."""
        assert (
            quality_gate._estimate_fix_time(["word_count"], QualityLevel.BRONZE) == "15-30 minutes"
        )
        assert (
            quality_gate._estimate_fix_time(["word_count"], QualityLevel.SILVER) == "30-60 minutes"
        )
        assert quality_gate._estimate_fix_time(["word_count"], QualityLevel.GOLD) == "45-90 minutes"
        assert quality_gate._estimate_fix_time(["word_count"], QualityLevel.PLATINUM) == "1-2 hours"

    def test_recommend_fix_approach_critical(self, quality_gate):
        """Test _recommend_fix_approach for critical issues."""
        fix1 = FixApproach(
            id="balanced_approach",
            name="Balanced",
            description="Test",
            best_for=[],
            intervention_level="medium",
            speed="fast",
            risk_level="low",
            estimated_effort="low",
        )
        fix2 = FixApproach(
            id="review_approach",
            name="Review",
            description="Test",
            best_for=[],
            intervention_level="medium",
            speed="fast",
            risk_level="low",
            estimated_effort="low",
        )

        recommended = quality_gate._recommend_fix_approach([fix1, fix2], ["validation"])
        assert recommended.id == "balanced_approach"

    def test_recommend_fix_approach_review(self, quality_gate):
        """Test _recommend_fix_approach prefers review."""
        fix1 = FixApproach(
            id="auto_fix",
            name="Auto",
            description="Test",
            best_for=[],
            intervention_level="low",
            speed="fast",
            risk_level="low",
            estimated_effort="low",
        )
        fix2 = FixApproach(
            id="review_approach",
            name="Review",
            description="Test",
            best_for=[],
            intervention_level="medium",
            speed="fast",
            risk_level="low",
            estimated_effort="low",
        )

        recommended = quality_gate._recommend_fix_approach([fix1, fix2], ["word_count"])
        assert recommended.id == "review_approach"

    def test_recommend_fix_approach_first(self, quality_gate):
        """Test _recommend_fix_approach returns first if no match."""
        fix = FixApproach(
            id="manual_fix",
            name="Manual",
            description="Test",
            best_for=[],
            intervention_level="high",
            speed="slow",
            risk_level="medium",
            estimated_effort="high",
        )

        recommended = quality_gate._recommend_fix_approach([fix], ["word_count"])
        assert recommended.id == "manual_fix"

    def test_recommend_fix_approach_none(self, quality_gate):
        """Test _recommend_fix_approach with no fixes."""
        recommended = quality_gate._recommend_fix_approach([], ["word_count"])
        assert recommended is None

    def test_select_relevant_fixes_critical(self, quality_gate):
        """Test _select_relevant_fixes for critical issues."""
        fixes = [
            FixApproach(
                id="strict_fix",
                name="Strict",
                description="Test",
                best_for=[],
                intervention_level="high",
                speed="slow",
                risk_level="high",
                estimated_effort="high",
            ),
            FixApproach(
                id="balanced_fix",
                name="Balanced",
                description="Test",
                best_for=[],
                intervention_level="medium",
                speed="medium",
                risk_level="low",
                estimated_effort="low",
            ),
        ]

        relevant = quality_gate._select_relevant_fixes(["validation"], fixes)
        assert len(relevant) > 0
        assert any(f.id == "strict_fix" for f in relevant)

    def test_select_relevant_fixes_style(self, quality_gate):
        """Test _select_relevant_fixes for style issues."""
        fixes = [
            FixApproach(
                id="auto_fix_style",
                name="Auto Style",
                description="Test",
                best_for=[],
                intervention_level="low",
                speed="fast",
                risk_level="low",
                estimated_effort="low",
            ),
            FixApproach(
                id="review_fix",
                name="Review",
                description="Test",
                best_for=[],
                intervention_level="medium",
                speed="medium",
                risk_level="low",
                estimated_effort="low",
            ),
        ]

        relevant = quality_gate._select_relevant_fixes(["passive_voice", "readability_ease"], fixes)
        assert len(relevant) > 0

    def test_select_relevant_fixes_content(self, quality_gate):
        """Test _select_relevant_fixes for content issues."""
        fixes = [
            FixApproach(
                id="defer_fix",
                name="Defer",
                description="Test",
                best_for=[],
                intervention_level="low",
                speed="fast",
                risk_level="low",
                estimated_effort="low",
            ),
            FixApproach(
                id="manual_fix",
                name="Manual",
                description="Test",
                best_for=[],
                intervention_level="high",
                speed="slow",
                risk_level="medium",
                estimated_effort="high",
            ),
        ]

        relevant = quality_gate._select_relevant_fixes(["word_count", "dialogue_clarity"], fixes)
        assert len(relevant) > 0

    def test_select_relevant_fixes_continuity(self, quality_gate):
        """Test _select_relevant_fixes for character consistency."""
        fixes = [
            FixApproach(
                id="continuity_fix",
                name="Continuity",
                description="Test",
                best_for=[],
                intervention_level="medium",
                speed="medium",
                risk_level="low",
                estimated_effort="low",
            )
        ]

        relevant = quality_gate._select_relevant_fixes(["character_consistency"], fixes)
        assert len(relevant) > 0
        assert relevant[0].id == "continuity_fix"

    def test_select_relevant_fixes_pacing(self, quality_gate):
        """Test _select_relevant_fixes includes pacing."""
        fixes = [
            FixApproach(
                id="pacing_fix",
                name="Pacing",
                description="Test",
                best_for=[],
                intervention_level="medium",
                speed="medium",
                risk_level="low",
                estimated_effort="low",
            )
        ]

        relevant = quality_gate._select_relevant_fixes([], fixes)
        assert len(relevant) > 0

    def test_select_relevant_fixes_limit(self, quality_gate):
        """Test _select_relevant_fixes limits results."""
        fixes = [
            FixApproach(
                id=f"fix_{i}",
                name=f"Fix {i}",
                description="Test",
                best_for=[],
                intervention_level="medium",
                speed="medium",
                risk_level="low",
                estimated_effort="low",
            )
            for i in range(10)
        ]

        relevant = quality_gate._select_relevant_fixes(["word_count"], fixes)
        assert len(relevant) <= 4

    def test_get_fix_suggestions_english(self, quality_gate):
        """Test get_fix_suggestions with English language."""
        response = quality_gate.get_fix_suggestions(
            ["word_count", "passive_voice"], target_level=QualityLevel.SILVER, language="en"
        )
        assert isinstance(response, FixSuggestionResponse)
        assert response.failed_criteria == ["word_count", "passive_voice"]

    def test_get_fix_suggestions_unknown_language(self, quality_gate):
        """Test get_fix_suggestions falls back to English for unknown language."""
        response = quality_gate.get_fix_suggestions(
            ["word_count"], target_level=QualityLevel.SILVER, language="unknown"
        )
        assert isinstance(response, FixSuggestionResponse)

    def test_get_fix_suggestions_fields(self, quality_gate):
        """Test get_fix_suggestions response fields."""
        response = quality_gate.get_fix_suggestions(
            ["word_count"], target_level=QualityLevel.SILVER, language="en"
        )
        assert hasattr(response, "issue_summary")
        assert hasattr(response, "failed_criteria")
        assert hasattr(response, "fix_approaches")
        assert hasattr(response, "urgency_level")
        assert hasattr(response, "estimated_fix_time")
