"""CLI commands for logging system."""

import json
import logging
from datetime import datetime

import click

logger = logging.getLogger("scribe")


@click.group()
def logs():
    """Query and analyze logs."""
    pass


@logs.command()
@click.option("--project", help="Filter by project name")
@click.option("--period", default="30d", help="Time period (7d, 30d, 90d, all)")
@click.option("--provider", help="Filter by provider")
@click.option("--model", help="Filter by model")
@click.option("--group-by", default="day", type=click.Choice(["day", "provider", "model"]))
def tokens(project, period, provider, model, group_by):
    """Show token usage statistics."""
    try:
        from core.logger import get_logger

        log = get_logger()

        if not log.token_tracker:
            click.echo("❌ Token tracking not enabled", err=True)
            return

        usage = log.token_tracker.get_usage(
            project=project, period=period, provider=provider, model=model, group_by=group_by
        )

        if "error" in usage:
            click.echo(f"❌ {usage['error']}", err=True)
            return

        # Print summary
        click.echo("\n📊 Token Usage Report")
        click.echo("=" * 60)
        click.echo(f"Period: {period}")
        if project:
            click.echo(f"Project: {project}")
        if provider:
            click.echo(f"Provider: {provider}")
        if model:
            click.echo(f"Model: {model}")

        click.echo("")
        click.echo(f"Total Input Tokens:  {usage['total_input_tokens']:,}")
        click.echo(f"Total Output Tokens: {usage['total_output_tokens']:,}")
        click.echo(f"Total Tokens:       {usage['total_tokens']:,}")
        click.echo(f"Total Cost:         ${usage['total_cost_usd']:.4f}")
        click.echo(f"Request Count:      {usage['request_count']:,}")
        click.echo(f"Avg Tokens/Request: {usage['avg_tokens_per_request']:,.0f}")
        click.echo(f"Avg Cost/Request:   ${usage['avg_cost_per_request']:.6f}")

        # Print breakdown
        if "daily" in usage and usage["daily"]:
            click.echo("\n📅 Daily Breakdown:")
            click.echo("-" * 60)
            for day in usage["daily"][:10]:
                click.echo(
                    f"  {day['date']}: {day['total_tokens']:>10,} tokens (${day['cost_usd']:.4f})"
                )

        if "by_provider" in usage and usage["by_provider"]:
            click.echo("\n🏢 By Provider:")
            click.echo("-" * 60)
            for item in usage["by_provider"]:
                click.echo(
                    f"  {item['provider']:>15}: {item['total_tokens']:>10,} tokens "
                    f"(${item['cost_usd']:.4f})"
                )

        if "by_model" in usage and usage["by_model"]:
            click.echo("\n🤖 By Model:")
            click.echo("-" * 60)
            for item in usage["by_model"][:10]:
                click.echo(
                    f"  {item['model'][:30]:30}: {item['total_tokens']:>10,} tokens "
                    f"(${item['cost_usd']:.4f})"
                )

        click.echo("")

    except Exception as e:
        logger.error(f"Failed to get token usage: {e}")
        click.echo(f"❌ Error: {e}", err=True)


@logs.command()
@click.option("--project", help="Filter by project name")
@click.option("--period", default="month", help="Time period (7d, 30d, month)")
@click.option("--compare", is_flag=True, help="Compare with previous period")
def costs(project, period, compare):
    """Show cost breakdown by provider and model."""
    try:
        from core.logger import get_logger

        log = get_logger()

        if not log.token_tracker:
            click.echo("❌ Cost tracking not enabled", err=True)
            return

        breakdown = log.token_tracker.get_cost_breakdown(project=project, period=period)

        if "error" in breakdown:
            click.echo(f"❌ {breakdown['error']}", err=True)
            return

        click.echo("\n💰 Cost Breakdown Report")
        click.echo("=" * 60)
        click.echo(f"Period: {period}")
        if project:
            click.echo(f"Project: {project}")

        click.echo("")
        click.echo(f"Total Cost: ${breakdown['total_cost_usd']:.4f}")
        click.echo("")

        click.echo("📊 By Provider/Model:")
        click.echo("-" * 60)

        for item in breakdown["breakdown"]:
            provider = item["provider"]
            model = item["model"]
            cost = item["cost_usd"]
            pct = item["cost_percentage"]

            bar = "█" * int(pct / 2) if pct > 0 else ""
            click.echo(f"  {provider}/{model[:25]:25} ${cost:>8.4f} {pct:>5.1f}% {bar}")

        click.echo("")

    except Exception as e:
        logger.error(f"Failed to get cost breakdown: {e}")
        click.echo(f"❌ Error: {e}", err=True)


@logs.command()
@click.option("--limit", default=100, help="Number of requests to show")
@click.option("--slow", is_flag=True, help="Show only slow requests (>5s)")
@click.option("--errors", is_flag=True, help="Show only failed requests")
@click.option("--project", help="Filter by project")
def requests(limit, slow, errors, project):
    """Show recent LLM requests."""
    try:
        from core.logger import get_logger

        log = get_logger()

        if not log.token_tracker:
            click.echo("❌ Request logging not enabled", err=True)
            return

        if slow:
            data = log.token_tracker.get_slow_requests(threshold_ms=5000, limit=limit)
            click.echo("\n🐌 Slowest Requests (>5s latency)")
        elif errors:
            data = log.token_tracker.get_errors(project=project, limit=limit)
            click.echo("\n❌ Failed Requests")
        else:
            # Get recent requests from database
            if not log.db_logger:
                click.echo("❌ Database logging not enabled", err=True)
                return

            import sqlite3

            conn = sqlite3.connect(log.db_logger.db_path)
            cursor = conn.cursor()

            if project:
                cursor.execute(
                    """
                    SELECT
                        request_id, timestamp, project_name, agent_name,
                        provider, model, total_tokens, cost_usd, latency_ms,
                        status, error_message
                    FROM llm_requests
                    WHERE project_name = ?
                    ORDER BY timestamp DESC
                    LIMIT ?
                    """,
                    [project, limit],
                )
            else:
                cursor.execute(
                    """
                    SELECT
                        request_id, timestamp, project_name, agent_name,
                        provider, model, total_tokens, cost_usd, latency_ms,
                        status, error_message
                    FROM llm_requests
                    ORDER BY timestamp DESC
                    LIMIT ?
                    """,
                    [limit],
                )

            rows = cursor.fetchall()
            conn.close()

            data = []
            for row in rows:
                data.append(
                    {
                        "request_id": row[0],
                        "timestamp": row[1],
                        "project": row[2],
                        "agent": row[3],
                        "provider": row[4],
                        "model": row[5],
                        "total_tokens": row[6],
                        "cost_usd": row[7],
                        "latency_ms": row[8],
                        "status": row[9],
                        "error": row[10],
                    }
                )

            click.echo("\n📝 Recent Requests")

        if not data:
            click.echo("  No requests found")
            return

        click.echo("=" * 80)

        for req in data:
            timestamp = req.get("timestamp", "Unknown")
            if isinstance(timestamp, str):
                try:
                    dt = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
                    timestamp = dt.strftime("%Y-%m-%d %H:%M:%S")
                except ValueError:
                    pass

            agent = req.get("agent") or "Unknown"
            latency = req.get("latency_ms", 0)
            tokens = req.get("total_tokens", 0)
            cost = req.get("cost_usd", 0)
            status = req.get("status", "unknown")
            error = req.get("error")

            status_icon = "✅" if status == "success" else "❌"

            click.echo(
                f"\n{status_icon} {timestamp} | "
                f"{agent[:20]:20} | "
                f"{latency:>6}ms | "
                f"{tokens:>8,} tokens | "
                f"${cost:.4f}"
            )

            if error:
                click.echo(f"   Error: {error[:60]}")

        click.echo("")

    except Exception as e:
        logger.error(f"Failed to get requests: {e}")
        click.echo(f"❌ Error: {e}", err=True)


@logs.command()
@click.option("--limit", default=10, help="Number of consumers to show")
@click.option("--period", default="30d", help="Time period")
@click.option("--group-by", default="agent", type=click.Choice(["agent", "project", "model"]))
def top(limit, period, group_by):
    """Show top token consumers."""
    try:
        from core.logger import get_logger

        log = get_logger()

        if not log.token_tracker:
            click.echo("❌ Token tracking not enabled", err=True)
            return

        consumers = log.token_tracker.get_top_consumers(
            limit=limit, period=period, group_by=group_by
        )

        click.echo(f"\n🏆 Top {limit} Token Consumers")
        click.echo("=" * 80)
        click.echo(f"Period: {period} | Grouped by: {group_by}")
        click.echo("")

        if not consumers:
            click.echo("  No data found")
            return

        for i, consumer in enumerate(consumers, 1):
            name = consumer["consumer"] or "Unknown"
            tokens = consumer["total_tokens"]
            cost = consumer["cost_usd"]
            count = consumer["request_count"]
            avg_latency = consumer["avg_latency_ms"]

            click.echo(
                f"{i:2}. {name[:40]:40} | "
                f"{tokens:>10,} tokens | "
                f"${cost:>8.4f} | "
                f"{count:>5} reqs | "
                f"{avg_latency:>6.0f}ms avg"
            )

        click.echo("")

    except Exception as e:
        logger.error(f"Failed to get top consumers: {e}")
        click.echo(f"❌ Error: {e}", err=True)


@logs.command()
@click.option("--format", default="json", type=click.Choice(["json", "csv"]))
@click.option("--period", default="30d", help="Time period")
@click.option("--project", help="Filter by project")
@click.option("--output", "-o", help="Output file (default: stdout)")
def export(format, period, project, output):
    """Export logs to JSON or CSV."""
    try:
        from core.logger import get_logger

        log = get_logger()

        if not log.db_logger:
            click.echo("❌ Database logging not enabled", err=True)
            return

        import sqlite3

        conn = sqlite3.connect(log.db_logger.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        # Build query
        if period == "all":
            date_filter = "1=1"
        else:
            days = int(period[:-1]) if period.endswith("d") else 30
            date_filter = f"timestamp > datetime('now', '-{days} days')"

        if project:
            where = f"{date_filter} AND project_name = ?"
            params = [project]
        else:
            where = date_filter
            params = []

        cursor.execute(
            f"""
            SELECT
                request_id, timestamp, project_name, agent_name,
                provider, model, input_tokens, output_tokens, total_tokens,
                cost_usd, latency_ms, status, error_message, cache_hit
            FROM llm_requests
            WHERE {where}
            ORDER BY timestamp DESC
        """,
            params,
        )

        rows = cursor.fetchall()
        conn.close()

        # Format output
        if format == "json":
            data = [dict(row) for row in rows]
            output_str = json.dumps(data, indent=2, default=str)
        else:  # csv
            import csv
            import io

            output_str = io.StringIO()
            if rows:
                writer = csv.DictWriter(output_str, fieldnames=rows[0].keys())
                writer.writeheader()
                for row in rows:
                    writer.writerow(dict(row))
            output_str = output_str.getvalue()

        # Write output
        if output:
            with open(output, "w") as f:
                f.write(output_str)
            click.echo(f"✅ Exported {len(rows)} entries to {output}")
        else:
            click.echo(output_str)

    except Exception as e:
        logger.error(f"Failed to export logs: {e}")
        click.echo(f"❌ Error: {e}", err=True)


@logs.command()
def stats():
    """Show logging system statistics."""
    try:
        from core.logger import get_logger

        log = get_logger()

        stats = log.get_stats()

        click.echo("\n📈 Logging System Statistics")
        click.echo("=" * 60)
        click.echo(f"Total Requests:      {stats['total_requests']:,}")
        click.echo(f"Total Tokens:        {stats['total_tokens']:,}")
        click.echo(f"Total Cost:         ${stats['total_cost_usd']:.4f}")
        click.echo(f"Error Count:        {stats['error_count']}")
        click.echo(f"Error Rate:         {stats['error_rate']:.2f}%")
        click.echo(f"Total User Actions: {stats['total_actions']:,}")
        click.echo(f"Requests (24h):     {stats['recent_requests_24h']:,}")
        click.echo("")

    except Exception as e:
        logger.error(f"Failed to get stats: {e}")
        click.echo(f"❌ Error: {e}", err=True)
