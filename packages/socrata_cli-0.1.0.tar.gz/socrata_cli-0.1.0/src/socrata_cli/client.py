from __future__ import annotations

import re
from urllib.parse import urlparse

import typer
from sodapy import Socrata

from .config import get_creds, load_config
from .keychain import get_credentials


_FOUR_BY_FOUR = re.compile(r"^[a-z0-9]{4}-[a-z0-9]{4}$", re.IGNORECASE)
_PUBLIC_CREDS = "public"


def parse_dataset_ref(ref: str) -> tuple[str | None, str]:
    """Return (domain_or_None, dataset_id).

    Accepts:
      "pitq-e56w"                                                        → (None, "pitq-e56w")
      "https://data.sfgov.org/resource/pitq-e56w"                        → ("data.sfgov.org", "pitq-e56w")
      "https://data.sfgov.org/Some-Category/Dataset-Name/pitq-e56w"      → ("data.sfgov.org", "pitq-e56w")
    """
    if ref.startswith("http://") or ref.startswith("https://"):
        parsed = urlparse(ref)
        domain = parsed.netloc
        segments = parsed.path.rstrip("/").split("/")
        for seg in reversed(segments):
            if _FOUR_BY_FOUR.match(seg):
                return domain, seg
        raise ValueError(f"No dataset ID (4x4) found in URL: {ref}")
    if _FOUR_BY_FOUR.match(ref):
        return None, ref
    raise ValueError(
        f"Invalid dataset reference: {ref!r}. "
        "Expected a 4x4 ID (e.g. pitq-e56w) or a full Socrata URL."
    )


def make_client(domain: str, key_id: str, key_secret: str, timeout: int = 10) -> Socrata:
    return Socrata(
        domain,
        app_token=None,
        username=key_id,
        password=key_secret,
        timeout=timeout,
    )


def make_public_client(domain: str, timeout: int = 10) -> Socrata:
    return Socrata(domain, app_token=None, timeout=timeout)


def _enabled_creds_for(cfg, domain: str) -> str | None:
    return next(
        (name for name, c in cfg.creds.items() if c.domain == domain and c.enabled),
        None,
    )


def make_client_for(
    *,
    url_domain: str | None,
    ctx_creds: str | None,
    ctx_domain: str | None,
    ctx_timeout: int,
) -> Socrata:
    """Resolve domain + credentials and return a Socrata client.

    Precedence: URL domain > --domain flag > default_domain.
    Auto-matches the enabled credential set for the resolved domain.
    Falls back to unauthenticated public client when no credential is enabled for the domain.
    """
    domain = url_domain or ctx_domain

    if ctx_creds == _PUBLIC_CREDS:
        if not domain:
            raise typer.BadParameter(
                "--creds public requires a domain. Pass a full URL or use --domain.",
                param_hint="'--creds'",
            )
        return make_public_client(domain, ctx_timeout)

    cfg = load_config()

    if ctx_creds:
        c = get_creds(cfg, ctx_creds)
        if url_domain and url_domain != c.domain:
            raise typer.BadParameter(
                f"Credentials '{ctx_creds}' are for '{c.domain}' "
                f"but the dataset URL points to '{url_domain}'.\n"
                f"To fix: use --creds public for unauthenticated access, "
                f"or add credentials for '{url_domain}' with: "
                f"socrata config creds add <name>",
                param_hint="'--creds'",
            )
        key_id, key_secret = get_credentials(ctx_creds)
        return make_client(domain or c.domain, key_id, key_secret, ctx_timeout)

    if url_domain:
        active = _enabled_creds_for(cfg, url_domain)
        if active:
            key_id, key_secret = get_credentials(active)
            return make_client(url_domain, key_id, key_secret, ctx_timeout)
        return make_public_client(url_domain, ctx_timeout)

    # Bare 4x4 — use default_domain.
    effective_domain = ctx_domain or cfg.default_domain
    if not effective_domain:
        raise typer.BadParameter(
            "No domain could be determined. Pass a full URL, use --domain, "
            "or set a default with: socrata config domain set <domain>",
            param_hint="'DATASET_REF'",
        )
    active = _enabled_creds_for(cfg, effective_domain)
    if active:
        key_id, key_secret = get_credentials(active)
        return make_client(effective_domain, key_id, key_secret, ctx_timeout)
    return make_public_client(effective_domain, ctx_timeout)


def get_client_from_ctx(ctx: "typer.Context", url_domain: str | None = None) -> Socrata:
    obj = ctx.obj or {}
    return make_client_for(
        url_domain=url_domain,
        ctx_creds=obj.get("creds"),
        ctx_domain=obj.get("domain"),
        ctx_timeout=obj.get("timeout", 10),
    )
