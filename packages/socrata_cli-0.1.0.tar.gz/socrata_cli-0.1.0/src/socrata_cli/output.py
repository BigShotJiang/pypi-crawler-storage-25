from __future__ import annotations

import contextlib
import csv
import json
import sys
from enum import Enum
from io import StringIO
from typing import Generator

from rich.console import Console
from rich.table import Table

console = Console()


class OutputFormat(str, Enum):
    table = "table"
    json = "json"
    csv = "csv"


@contextlib.contextmanager
def open_output(path: str | None) -> Generator:
    if path:
        with open(path, "w", newline="", encoding="utf-8") as f:
            yield f
    else:
        yield sys.stdout


def render(rows: list[dict], fmt: OutputFormat, output: str | None = None) -> None:
    if not rows:
        console.print("[yellow]No results.[/yellow]")
        return

    if fmt == OutputFormat.json:
        text = json.dumps(rows, indent=2, default=str)
        with open_output(output) as f:
            f.write(text)
            if f is sys.stdout:
                f.write("\n")
        return

    if fmt == OutputFormat.csv or (fmt == OutputFormat.table and output):
        fieldnames = list(rows[0].keys())
        with open_output(output) as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
        return

    # Rich table to terminal
    table = Table(show_header=True, header_style="bold cyan")
    fieldnames = list(rows[0].keys())
    for col in fieldnames:
        table.add_column(col, overflow="fold")
    for row in rows:
        table.add_row(*[str(row.get(col, "")) for col in fieldnames])
    console.print(table)
