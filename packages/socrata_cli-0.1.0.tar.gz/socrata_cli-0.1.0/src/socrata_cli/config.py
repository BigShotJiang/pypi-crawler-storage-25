from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib
from pathlib import Path

import tomli_w


@dataclass
class CredsConfig:
    domain: str
    enabled: bool = False


@dataclass
class AppConfig:
    default_domain: str | None = None
    creds: dict[str, CredsConfig] = field(default_factory=dict)


def config_path() -> Path:
    d = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "socrata"
    d.mkdir(parents=True, exist_ok=True)
    return d / "config.toml"


def _normalize(creds: dict[str, CredsConfig]) -> None:
    """Ensure at most one enabled cred per domain (first-enabled wins)."""
    seen: set[str] = set()
    for c in creds.values():
        if c.enabled:
            if c.domain in seen:
                c.enabled = False
            else:
                seen.add(c.domain)


def load_config() -> AppConfig:
    p = config_path()
    if not p.exists():
        return AppConfig()
    with p.open("rb") as f:
        data = tomllib.load(f)
    creds = {
        name: CredsConfig(domain=v["domain"], enabled=bool(v.get("enabled", False)))
        for name, v in data.get("creds", {}).items()
    }
    _normalize(creds)
    return AppConfig(
        default_domain=data.get("default_domain"),
        creds=creds,
    )


def save_config(cfg: AppConfig) -> None:
    _normalize(cfg.creds)
    data: dict = {}
    if cfg.default_domain is not None:
        data["default_domain"] = cfg.default_domain
    data["creds"] = {
        name: {"domain": c.domain, "enabled": c.enabled}
        for name, c in cfg.creds.items()
    }
    p = config_path()
    tmp = p.with_suffix(".tmp")
    with tmp.open("wb") as f:
        tomli_w.dump(data, f)
    os.replace(tmp, p)


def get_creds(cfg: AppConfig, name: str) -> CredsConfig:
    if name not in cfg.creds:
        raise KeyError(
            f"Credentials '{name}' not found. "
            "Run `socrata config creds list` to see available credentials."
        )
    return cfg.creds[name]
