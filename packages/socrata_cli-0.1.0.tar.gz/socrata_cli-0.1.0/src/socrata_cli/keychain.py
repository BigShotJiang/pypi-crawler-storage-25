from __future__ import annotations

import keyring
from keyring.errors import KeyringError

SERVICE = "socrata-cli"


def _key(profile: str, slot: str) -> str:
    return f"{profile}:{slot}"


def set_credentials(profile: str, key_id: str, key_secret: str) -> None:
    keyring.set_password(SERVICE, _key(profile, "key_id"), key_id)
    keyring.set_password(SERVICE, _key(profile, "key_secret"), key_secret)


def get_credentials(profile: str) -> tuple[str, str]:
    key_id = keyring.get_password(SERVICE, _key(profile, "key_id"))
    key_secret = keyring.get_password(SERVICE, _key(profile, "key_secret"))
    if key_id is None or key_secret is None:
        raise RuntimeError(
            f"No credentials found for profile '{profile}'. "
            "Run `socrata profile add` to configure."
        )
    return key_id, key_secret


def delete_credentials(profile: str) -> None:
    for slot in ("key_id", "key_secret"):
        try:
            keyring.delete_password(SERVICE, _key(profile, slot))
        except KeyringError:
            pass
