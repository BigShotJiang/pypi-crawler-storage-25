from __future__ import annotations

import logging
from typing import Optional

import typer


class _SodapyHint(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()
        if "app_token" in msg and "throttling" in msg:
            record.msg = "%s Run `socrata config creds add <name>` to add credentials."
            record.args = (msg,)
        return True


logging.getLogger().addFilter(_SodapyHint())

from .commands import dataset
from .commands.config import app as config_app

app = typer.Typer(
    name="socrata",
    help="CLI for the Socrata Open Data API.",
    context_settings={"obj": {}},
)

app.add_typer(config_app, name="config")
app.add_typer(dataset.app, name="dataset")


@app.callback()
def main(
    ctx: typer.Context,
    creds: Optional[str] = typer.Option(
        None, "--creds", "-c", help="Credential set to use (overrides auto-match)"
    ),
    domain: Optional[str] = typer.Option(
        None, "--domain", help="Override domain for this invocation"
    ),
    timeout: int = typer.Option(10, "--timeout", help="Request timeout in seconds"),
) -> None:
    ctx.ensure_object(dict)
    ctx.obj["creds"] = creds
    ctx.obj["domain"] = domain
    ctx.obj["timeout"] = timeout
