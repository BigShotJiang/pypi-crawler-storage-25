from __future__ import annotations

import csv
import json
import sys
from typing import Optional

import typer
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TaskProgressColumn, TextColumn
from rich.table import Table

from ..client import get_client_from_ctx, parse_dataset_ref
from ..output import OutputFormat, console, render

app = typer.Typer(help="Query and download Socrata datasets.")


def _resolve(ctx: typer.Context, dataset_ref: str):
    """Parse dataset_ref and return (client, dataset_id)."""
    url_domain, dataset_id = parse_dataset_ref(dataset_ref)
    client = get_client_from_ctx(ctx, url_domain=url_domain)
    return client, dataset_id


@app.command("query")
def dataset_query(
    ctx: typer.Context,
    dataset_ref: str = typer.Argument(..., help="Dataset 4x4 ID or full Socrata URL"),
    select: Optional[str] = typer.Option(None, "--select", help="Columns to return (SoQL $select)"),
    where: Optional[str] = typer.Option(None, "--where", help="Row filter (SoQL $where)"),
    order: Optional[str] = typer.Option(None, "--order", help="Sort order (SoQL $order)"),
    group: Optional[str] = typer.Option(None, "--group", help="Group by (SoQL $group)"),
    limit: int = typer.Option(1000, "--limit", help="Max rows to return"),
    offset: int = typer.Option(0, "--offset", help="Row offset for pagination"),
    q: Optional[str] = typer.Option(None, "--q", help="Full text search"),
    all_rows: bool = typer.Option(False, "--all", help="Fetch all rows (ignores --limit/--offset)"),
    fmt: OutputFormat = typer.Option(OutputFormat.table, "--format", "-f", help="Output format"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Write to file instead of stdout"),
) -> None:
    """Query a dataset with optional SoQL filters."""
    try:
        client, dataset_id = _resolve(ctx, dataset_ref)
        kwargs: dict = {}
        if select:
            kwargs["select"] = select
        if where:
            kwargs["where"] = where
        if order:
            kwargs["order"] = order
        if group:
            kwargs["group"] = group
        if q:
            kwargs["q"] = q

        with client:
            if all_rows:
                rows = list(client.get_all(dataset_id, **kwargs))
            else:
                kwargs["limit"] = limit
                kwargs["offset"] = offset
                rows = client.get(dataset_id, **kwargs)

        render(rows, fmt, output)
    except (KeyError, RuntimeError, ValueError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
    except Exception as e:
        _handle_requests_error(e)


@app.command("download")
def dataset_download(
    ctx: typer.Context,
    dataset_ref: str = typer.Argument(..., help="Dataset 4x4 ID or full Socrata URL"),
    fmt: str = typer.Option("csv", "--format", "-f", help="Output format: csv, json"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output file (default: <id>.<fmt>)"),
) -> None:
    """Download an entire dataset by streaming all rows."""
    try:
        client, dataset_id = _resolve(ctx, dataset_ref)
        out_path = output or f"{dataset_id}.{fmt}"

        with client:
            rows_iter = client.get_all(dataset_id)

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                TaskProgressColumn(),
                console=console,
                transient=True,
            ) as progress:
                task = progress.add_task(f"Downloading {dataset_id}...", total=None)

                if fmt == "json":
                    all_rows = []
                    count = 0
                    for row in rows_iter:
                        all_rows.append(row)
                        count += 1
                        progress.update(task, description=f"Downloaded {count} rows...")
                    with open(out_path, "w", encoding="utf-8") as f:
                        json.dump(all_rows, f, indent=2, default=str)
                else:
                    # csv (default)
                    count = 0
                    writer = None
                    with open(out_path, "w", newline="", encoding="utf-8") as f:
                        for row in rows_iter:
                            if writer is None:
                                writer = csv.DictWriter(f, fieldnames=list(row.keys()))
                                writer.writeheader()
                            writer.writerow(row)
                            count += 1
                            progress.update(task, description=f"Downloaded {count} rows...")

        console.print(f"[green]Saved {count} rows to {out_path}[/green]")
    except (KeyError, RuntimeError, ValueError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
    except Exception as e:
        _handle_requests_error(e)


@app.command("metadata")
def dataset_metadata(
    ctx: typer.Context,
    dataset_ref: str = typer.Argument(..., help="Dataset 4x4 ID or full Socrata URL"),
) -> None:
    """Show dataset metadata (name, description, columns, update time)."""
    try:
        client, dataset_id = _resolve(ctx, dataset_ref)
        with client:
            meta = client.get_metadata(dataset_id)

        name = meta.get("name", dataset_id)
        description = meta.get("description", "")
        row_count = meta.get("rowsUpdatedAt") or meta.get("viewLastModified")
        updated = meta.get("rowsUpdatedAt")
        created = meta.get("createdAt")

        console.print(Panel(f"[bold]{name}[/bold]\n\n{description}", title="Dataset Info"))

        info_table = Table(show_header=False, box=None)
        info_table.add_column("Key", style="dim")
        info_table.add_column("Value")
        info_table.add_row("ID", dataset_id)
        if created:
            import datetime
            info_table.add_row("Created", datetime.datetime.fromtimestamp(int(created)).strftime("%Y-%m-%d"))
        if updated:
            import datetime
            info_table.add_row("Updated", datetime.datetime.fromtimestamp(int(updated)).strftime("%Y-%m-%d"))
        console.print(info_table)

        columns = meta.get("columns", [])
        if columns:
            col_table = Table(show_header=True, header_style="bold cyan", title="Columns")
            col_table.add_column("Field Name")
            col_table.add_column("Type")
            col_table.add_column("Label")
            for col in columns:
                col_table.add_row(
                    col.get("fieldName", ""),
                    col.get("dataTypeName", ""),
                    col.get("name", ""),
                )
            console.print(col_table)
    except (KeyError, RuntimeError, ValueError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
    except Exception as e:
        _handle_requests_error(e)


@app.command("columns")
def dataset_columns(
    ctx: typer.Context,
    dataset_ref: str = typer.Argument(..., help="Dataset 4x4 ID or full Socrata URL"),
) -> None:
    """List dataset columns with types and descriptions."""
    try:
        client, dataset_id = _resolve(ctx, dataset_ref)
        with client:
            meta = client.get_metadata(dataset_id)

        columns = meta.get("columns", [])
        if not columns:
            console.print("[yellow]No columns found.[/yellow]")
            return

        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("Field Name")
        table.add_column("Type")
        table.add_column("Label")
        table.add_column("Description")

        for col in columns:
            desc = col.get("description", "") or ""
            if len(desc) > 60:
                desc = desc[:57] + "..."
            table.add_row(
                col.get("fieldName", ""),
                col.get("dataTypeName", ""),
                col.get("name", ""),
                desc,
            )

        console.print(table)
    except (KeyError, RuntimeError, ValueError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
    except Exception as e:
        _handle_requests_error(e)


def _handle_requests_error(e: Exception) -> None:
    try:
        import requests
        if isinstance(e, requests.exceptions.HTTPError):
            status = e.response.status_code if e.response is not None else "?"
            body = e.response.text[:500] if e.response is not None else ""
            typer.echo(f"HTTP {status}: {body}", err=True)
            raise typer.Exit(1)
        if isinstance(e, requests.exceptions.ConnectionError):
            typer.echo(f"Connection error: {e}", err=True)
            raise typer.Exit(1)
    except ImportError:
        pass
    typer.echo(f"Unexpected error: {type(e).__name__}: {e}", err=True)
    raise typer.Exit(1)
