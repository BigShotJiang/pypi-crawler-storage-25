from __future__ import annotations

import typer
from rich.table import Table

from ..config import CredsConfig, get_creds, load_config, save_config
from ..keychain import delete_credentials, set_credentials
from ..output import console

app = typer.Typer(help="Manage socrata-cli configuration.")

creds_app = typer.Typer(help="Manage credential sets.")
app.add_typer(creds_app, name="creds")

domain_app = typer.Typer(help="Manage the default domain for bare dataset IDs.")
app.add_typer(domain_app, name="domain")


# ---------------------------------------------------------------------------
# socrata config creds
# ---------------------------------------------------------------------------

@creds_app.command("add")
def creds_add(
    name: str = typer.Argument(..., help="Credential set name"),
) -> None:
    """Add or update a credential set with domain and API key."""
    cfg = load_config()
    if name in cfg.creds:
        overwrite = typer.confirm(f"Credentials '{name}' already exist. Overwrite?", default=False)
        if not overwrite:
            raise typer.Abort()

    domain = typer.prompt("Domain (e.g. data.cityofchicago.org)")
    domain = domain.removeprefix("https://").removeprefix("http://").rstrip("/")

    key_id = typer.prompt("API Key ID")
    key_secret = typer.prompt("API Key Secret", hide_input=True)

    domain_has_enabled = any(
        c.enabled for c in cfg.creds.values() if c.domain == domain
    )
    cfg.creds[name] = CredsConfig(domain=domain, enabled=not domain_has_enabled)

    save_config(cfg)
    set_credentials(name, key_id, key_secret)

    console.print(f"[green]Credentials '{name}' saved.[/green]")
    if cfg.creds[name].enabled:
        console.print(f"[dim]Enabled for {domain}.[/dim]")


@creds_app.command("list")
def creds_list() -> None:
    """List all configured credential sets."""
    cfg = load_config()

    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("Name")
    table.add_column("Domain")
    table.add_column("Default for domain")

    for name, c in cfg.creds.items():
        marker = "[bold green]*[/bold green]" if c.enabled else ""
        table.add_row(name, c.domain, marker)

    table.add_row("public", "[dim]any[/dim]", "")

    if not cfg.creds:
        console.print("[yellow]No credentials configured. Run `socrata config creds add <name>`.[/yellow]")
    else:
        console.print(table)


@creds_app.command("use")
def creds_use(
    name: str = typer.Argument(..., help="Credential set name to enable"),
) -> None:
    """Enable a credential set for its domain (disables others for the same domain)."""
    cfg = load_config()
    c = get_creds(cfg, name)
    for other_name, other in cfg.creds.items():
        if other.domain == c.domain:
            other.enabled = other_name == name
    save_config(cfg)
    console.print(f"[green]'{name}' is now the active credentials for {c.domain}.[/green]")


@creds_app.command("remove")
def creds_remove(
    name: str = typer.Argument(..., help="Credential set name to remove"),
) -> None:
    """Remove a credential set and its stored keys."""
    cfg = load_config()
    c = get_creds(cfg, name)

    typer.confirm(f"Remove credentials '{name}'?", abort=True)

    was_enabled = c.enabled
    domain = c.domain
    del cfg.creds[name]

    if was_enabled and cfg.default_domain == domain:
        still_has_enabled = any(
            other.enabled for other in cfg.creds.values() if other.domain == domain
        )
        if not still_has_enabled:
            cfg.default_domain = None

    save_config(cfg)
    delete_credentials(name)
    console.print(f"[green]Credentials '{name}' removed.[/green]")


# ---------------------------------------------------------------------------
# socrata config domain
# ---------------------------------------------------------------------------

@domain_app.command("set")
def domain_set(
    domain: str = typer.Argument(..., help="Domain to use for bare dataset IDs"),
) -> None:
    """Set the default domain used when only a bare dataset ID is given."""
    domain = domain.removeprefix("https://").removeprefix("http://").rstrip("/")
    cfg = load_config()
    cfg.default_domain = domain
    save_config(cfg)
    console.print(f"[green]Default domain set to '{domain}'.[/green]")


@domain_app.command("remove")
def domain_remove() -> None:
    """Clear the default domain."""
    cfg = load_config()
    cfg.default_domain = None
    save_config(cfg)
    console.print("[green]Default domain cleared.[/green]")
