"""Format-specific adapters."""
