"""Shared domain models."""
