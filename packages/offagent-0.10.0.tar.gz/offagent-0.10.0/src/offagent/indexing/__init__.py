"""Index storage primitives."""
