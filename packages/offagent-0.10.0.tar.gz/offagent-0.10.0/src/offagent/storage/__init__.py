"""Storage-related utilities."""
