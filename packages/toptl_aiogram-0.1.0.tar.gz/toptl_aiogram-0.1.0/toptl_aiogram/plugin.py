"""Core plugin — tracks update entities and autoposts to TOP.TL."""

from __future__ import annotations

import asyncio
import functools
import logging
from typing import Any, Awaitable, Callable, Optional

from aiogram import BaseMiddleware, Dispatcher
from aiogram.types import TelegramObject
from toptl import AsyncAutoposter, AsyncTopTL

logger = logging.getLogger(__name__)


class TopTLPlugin(BaseMiddleware):
    """Tracks update entities + runs an autoposter.

    Instantiated by :func:`setup_toptl`. Acts as an aiogram middleware
    so you can `dp.update.middleware(plugin)`, and exposes the tracked
    counts + a `has_voted` helper for vote-gate logic.
    """

    def __init__(self, client: AsyncTopTL, username: str) -> None:
        super().__init__()
        self._client = client
        self._username = username
        self._user_ids: set[int] = set()
        self._group_ids: set[int] = set()
        self._channel_ids: set[int] = set()
        self._autoposter: Optional[AsyncAutoposter] = None

    # ------------------------------------------------------------------
    # Counts
    # ------------------------------------------------------------------

    @property
    def user_count(self) -> int:
        return len(self._user_ids)

    @property
    def group_count(self) -> int:
        return len(self._group_ids)

    @property
    def channel_count(self) -> int:
        return len(self._channel_ids)

    # ------------------------------------------------------------------
    # Middleware
    # ------------------------------------------------------------------

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        # aiogram wraps every update type through this middleware. Grab
        # the relevant chat / user when present; fall back through the
        # common attribute names aiogram exposes on Message, Callback,
        # MyChatMember, etc.
        from_user = getattr(event, "from_user", None)
        if from_user and from_user.id:
            self._user_ids.add(int(from_user.id))

        chat = getattr(event, "chat", None)
        if chat is not None and getattr(chat, "id", None) is not None:
            chat_type = getattr(chat, "type", "")
            if chat_type in ("group", "supergroup"):
                self._group_ids.add(int(chat.id))
            elif chat_type == "channel":
                self._channel_ids.add(int(chat.id))

        # Make the plugin handle reachable from downstream handlers
        # via `data["toptl"]`. Idempotent, cheap.
        data.setdefault("toptl", self)
        return await handler(event, data)

    # ------------------------------------------------------------------
    # Autoposter lifecycle — wired by setup_toptl
    # ------------------------------------------------------------------

    async def _snapshot(self) -> dict[str, Any]:
        return {
            "member_count": self.user_count,
            "group_count": self.group_count,
            "channel_count": self.channel_count,
        }

    async def _on_startup(self) -> None:
        self._autoposter = AsyncAutoposter(
            client=self._client,
            username=self._username,
            callback=self._snapshot,
            interval_seconds=self._interval_seconds,
            only_on_change=True,
        )
        self._autoposter.start()

    async def _on_shutdown(self) -> None:
        if self._autoposter:
            await self._autoposter.stop()
            self._autoposter = None

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    async def post_now(self) -> None:
        """Flush the current counts to TOP.TL immediately. Fail-safe."""
        try:
            await self._client.post_stats(
                self._username,
                member_count=self.user_count,
                group_count=self.group_count,
                channel_count=self.channel_count,
            )
        except Exception:
            logger.exception("toptl-aiogram: post_stats failed for @%s", self._username)

    async def has_voted(self, user_id: int) -> bool:
        """True iff ``user_id`` has voted for this listing. Errors → False."""
        try:
            result = await self._client.has_voted(self._username, user_id)
            return bool(result.voted)
        except Exception:
            logger.exception("toptl-aiogram: has_voted failed for %s", user_id)
            return False


def setup_toptl(
    dispatcher: Dispatcher,
    client: AsyncTopTL,
    username: str,
    *,
    interval_seconds: float = 30 * 60,
) -> TopTLPlugin:
    """Install the plugin on an aiogram ``Dispatcher``.

    Registers the middleware on the dispatcher's update chain and hooks
    the autoposter to its startup / shutdown lifecycle — so you don't
    have to manage the background task yourself.

    Returns the plugin handle you pass to :func:`vote_required` and use
    for manual :meth:`TopTLPlugin.post_now` calls.
    """
    plugin = TopTLPlugin(client, username)
    plugin._interval_seconds = interval_seconds  # noqa: SLF001

    # Middleware runs on every update type. Using dp.update.middleware
    # instead of dp.message.middleware so we count non-message events
    # (callback queries, chat_member) toward unique users too.
    dispatcher.update.middleware(plugin)

    # Startup/shutdown — aiogram 3 fires these around `start_polling`.
    dispatcher.startup.register(plugin._on_startup)
    dispatcher.shutdown.register(plugin._on_shutdown)

    return plugin


# Handler signature for @vote_required: aiogram message/callback handlers
# take the event as the first positional arg plus optional keyword args.
H = Callable[..., Awaitable[Any]]


def vote_required(
    plugin: TopTLPlugin,
    *,
    message: Optional[str] = None,
    vote_url: Optional[str] = None,
) -> Callable[[H], H]:
    """Decorator that blocks an aiogram handler for users who haven't voted.

    Works on message and callback-query handlers. For any other event
    type, the decorator lets the handler through (there's no user to
    gate against).
    """

    def decorator(func: H) -> H:
        @functools.wraps(func)
        async def wrapper(event: TelegramObject, *args: Any, **kwargs: Any) -> Any:
            from_user = getattr(event, "from_user", None)
            if from_user is None:
                return await func(event, *args, **kwargs)
            if await plugin.has_voted(int(from_user.id)):
                return await func(event, *args, **kwargs)

            text = message or (
                f"Please vote on TOP.TL first: {vote_url}"
                if vote_url
                else "Please vote for this bot on TOP.TL to use this command."
            )

            # Message has .answer; CallbackQuery has .answer + .message.answer.
            if hasattr(event, "answer"):
                try:
                    await event.answer(text)
                    return None
                except Exception:
                    pass
            if hasattr(event, "message") and getattr(event, "message", None) is not None:
                try:
                    await event.message.answer(text)
                except Exception:
                    logger.exception("toptl-aiogram: vote_required reply failed")
            return None

        return wrapper

    return decorator


# Silence the unused-asyncio warning for linters — AsyncAutoposter runs
# its own task loop, so asyncio stays imported for readers who want to
# see that this is async-native.
_ = asyncio
