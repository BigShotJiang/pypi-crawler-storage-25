"""aiogram plugin for TOP.TL.

Install once on your Dispatcher:

    from aiogram import Bot, Dispatcher
    from toptl import AsyncTopTL
    from toptl_aiogram import setup_toptl, vote_required

    bot = Bot("BOT_TOKEN")
    dp = Dispatcher()
    client = AsyncTopTL("toptl_xxx")
    plugin = setup_toptl(dp, client, "mybot")

    @dp.message(Command("premium"))
    @vote_required(plugin, vote_url="https://top.tl/mybot")
    async def premium(message):
        ...

    await dp.start_polling(bot)

`setup_toptl` registers a middleware that learns unique users /
groups / channels from every update, and an asyncio autoposter task
tied to the dispatcher's startup/shutdown hooks.
"""

from .plugin import TopTLPlugin, setup_toptl, vote_required

__all__ = ["TopTLPlugin", "setup_toptl", "vote_required"]
__version__ = "0.1.0"
