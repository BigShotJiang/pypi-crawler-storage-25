"""API endpoints for saving and retrieving model versions."""

import json
import logging

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from atelier.db.engine import get_session
from atelier.db.models import Model, Project
from atelier.schemas import ModelDetail, ModelSaveRequest, ModelSummary
from atelier.schemas.model_save import SplitMetrics, VersionChange
from atelier.services.model_service import build_model_spec, compute_changes

_MAX_VERSION_RETRIES = 5

log = logging.getLogger(__name__)

router = APIRouter(tags=["models"])


@router.post("/models/save")
async def save_model(req: ModelSaveRequest, session: AsyncSession = Depends(get_session)):
    """Persist a fitted model as a new version within its project.

    Uses a retry loop to handle concurrent version increments: if two saves
    race and both pick the same MAX(version)+1, the unique constraint on
    (project_id, version) causes one to fail with IntegrityError.  The loser
    rolls back, re-reads the current max, and retries.
    """
    log.info(
        "[models/save] project_id=%s  response=%s  family=%s  n_terms=%d  "
        "deviance=%s  aic=%s  n_obs=%s  fit_ms=%s",
        req.project_id, req.response, req.family, len(req.terms),
        req.deviance, req.aic, req.n_obs, req.fit_duration_ms,
    )
    if not req.project_id:
        log.warning("[models/save] rejected: no project_id")
        raise HTTPException(status_code=400, detail="project_id is required")

    project = await session.get(Project, req.project_id)
    if not project:
        log.warning("[models/save] project not found: %s", req.project_id)
        raise HTTPException(status_code=404, detail="Project not found")

    spec = build_model_spec(
        dataset_path=req.dataset_path,
        response=req.response,
        family=req.family,
        link=req.link,
        offset=req.offset,
        weights=req.weights,
        terms=[t.model_dump() for t in req.terms],
        split=req.split.model_dump() if req.split else None,
    )

    last_exc: Exception | None = None
    for attempt in range(_MAX_VERSION_RETRIES):
        # Determine next version number within this project
        result = await session.execute(
            select(func.coalesce(func.max(Model.version), 0)).where(
                Model.project_id == req.project_id
            )
        )
        next_version = result.scalar_one() + 1

        model = Model(
            project_id=req.project_id,
            version=next_version,
            name=f"v{next_version}",
            spec=spec,
            status="fitted",
            deviance=req.deviance,
            null_deviance=req.null_deviance,
            aic=req.aic,
            bic=req.bic,
            n_obs=req.n_obs,
            n_validation=req.n_validation,
            n_params=req.n_params,
            fit_duration_ms=req.fit_duration_ms,
            summary_text=req.summary,
            converged=req.converged,
            iterations=req.iterations,
            coef_table_json=json.dumps(req.coef_table) if req.coef_table else None,
            diagnostics_json=json.dumps(req.diagnostics) if req.diagnostics else None,
            generated_code=req.generated_code,
        )

        session.add(model)
        project.n_versions = next_version

        try:
            log.debug(
                "[models/save] attempt %d: committing v%d for project '%s'",
                attempt + 1, next_version, project.name,
            )
            await session.commit()
            await session.refresh(model)
            log.info(
                "[models/save] saved model v%d (id=%s) for project '%s' (id=%s)",
                next_version, model.id, project.name, req.project_id,
            )
            return {
                "id": model.id,
                "version": next_version,
            }
        except IntegrityError as exc:
            last_exc = exc
            log.warning(
                "[models/save] version conflict on v%d (attempt %d), retrying",
                next_version, attempt + 1,
            )
            await session.rollback()
            # Re-fetch project after rollback so it's attached to the session
            project = await session.get(Project, req.project_id)
            if not project:
                raise HTTPException(status_code=404, detail="Project not found")

    log.error("[models/save] exhausted %d retries for project %s", _MAX_VERSION_RETRIES, req.project_id)
    raise HTTPException(
        status_code=409,
        detail=f"Version conflict after {_MAX_VERSION_RETRIES} retries",
    ) from last_exc


def _extract_split_metrics(diag_json: str | None, split: str) -> SplitMetrics:
    """Extract key metrics for a train/test split from stored diagnostics JSON."""
    if not diag_json:
        return SplitMetrics()
    try:
        diag = json.loads(diag_json) if isinstance(diag_json, str) else diag_json
        tt = diag.get("train_test", {})
        data = tt.get(split)
        if not data:
            return SplitMetrics()
        n_obs = data.get("n_obs")
        mean_dev = data.get("loss")
        if mean_dev is None:
            deviance = data.get("deviance")
            mean_dev = round(deviance / n_obs, 6) if deviance is not None and n_obs else None
        return SplitMetrics(
            n_obs=n_obs,
            mean_deviance=mean_dev,
            aic=data.get("aic"),
            gini=data.get("gini"),
        )
    except Exception:
        return SplitMetrics()


@router.get("/models/{project_id}/history")
async def list_models(project_id: str, session: AsyncSession = Depends(get_session)):
    """Return all saved model versions for a project, newest first, with diffs."""
    log.info("[models/history] project_id=%s", project_id)
    result = await session.execute(
        select(Model)
        .where(Model.project_id == project_id)
        .order_by(Model.version.asc())
    )
    rows = result.scalars().all()
    log.info("[models/history] found %d versions for project %s", len(rows), project_id)

    summaries: list[dict] = []
    prev_terms: list[dict] = []

    for m in rows:
        curr_terms = m.spec.get("terms", []) if m.spec else []
        changes = compute_changes(prev_terms, curr_terms) if m.version > 1 else []

        train = _extract_split_metrics(m.diagnostics_json, "train")
        test_metrics = _extract_split_metrics(m.diagnostics_json, "test")

        summaries.append(
            ModelSummary(
                id=m.id,
                version=m.version,
                created_at=m.created_at.isoformat() if m.created_at else "",
                n_terms=len(curr_terms),
                family=m.spec.get("family") if m.spec else None,
                fit_duration_ms=m.fit_duration_ms,
                train=train,
                test=test_metrics if test_metrics.n_obs is not None else None,
                changes=changes,
            ).model_dump()
        )
        prev_terms = curr_terms

    summaries.reverse()  # newest first
    log.debug("[models/history] returning %d summaries", len(summaries))
    return summaries


@router.get("/models/detail/{model_id}")
async def get_model(model_id: str, session: AsyncSession = Depends(get_session)):
    """Return full detail for a single saved model."""
    log.info("[models/detail] model_id=%s", model_id)
    model = await session.get(Model, model_id)
    if not model:
        log.warning("[models/detail] model not found: %s", model_id)
        raise HTTPException(status_code=404, detail="Model not found")
    log.info(
        "[models/detail] returning model v%d  project_id=%s  status=%s  n_obs=%s",
        model.version, model.project_id, model.status, model.n_obs,
    )

    return ModelDetail(
        id=model.id,
        version=model.version,
        created_at=model.created_at.isoformat() if model.created_at else "",
        spec=model.spec or {},
        deviance=model.deviance,
        null_deviance=model.null_deviance,
        aic=model.aic,
        bic=model.bic,
        n_obs=model.n_obs,
        n_validation=model.n_validation,
        n_params=model.n_params,
        fit_duration_ms=model.fit_duration_ms,
        summary=model.summary_text,
        converged=model.converged,
        iterations=model.iterations,
        coef_table=json.loads(model.coef_table_json) if model.coef_table_json else None,
        diagnostics=json.loads(model.diagnostics_json) if model.diagnostics_json else None,
        generated_code=model.generated_code,
    ).model_dump()
