"""
Generic result container for all PyStatistics computations.

The Result class provides a standardized envelope that all domain-specific
results use. This enables shared tooling for timing, logging, reproducibility,
and serialization while allowing domains to define their own parameter structures.

Design decisions:
    - Generic over parameter payload P for type safety
    - info dict for flexible metadata (converged, iterations, diagnostics)
    - timing is optional (don't burden unit tests)
    - provenance for reproducibility (versions, device, algorithm)
    - Immutable (frozen=True) for reproducibility
"""

import sys
from dataclasses import dataclass, field
from typing import TypeVar, Generic, Any

P = TypeVar('P')  # Parameter payload type


# Cached provenance dict. Every Result() construction used to rebuild this
# via three imports; on CPU-only codepaths that triggered a ~800 ms cold
# `import torch` on the first fit (the entire torch module graph loads just
# to read a version string). We now:
#   1. Build the dict once, lazily, on first Result().
#   2. Only probe torch if it is ALREADY imported (sys.modules) — never
#      force-load it. GPU code paths will have imported torch themselves
#      long before the first Result() is constructed.
_PROVENANCE_CACHE: dict[str, Any] | None = None


def _default_provenance() -> dict[str, Any]:
    """Generate minimal provenance metadata (cached after first call)."""
    global _PROVENANCE_CACHE
    if _PROVENANCE_CACHE is not None:
        return dict(_PROVENANCE_CACHE)  # copy; callers treat as their own

    import pystatistics
    provenance: dict[str, Any] = {
        'pystatistics_version': pystatistics.__version__,
    }
    numpy_mod = sys.modules.get('numpy')
    if numpy_mod is not None:
        provenance['numpy_version'] = numpy_mod.__version__
    torch_mod = sys.modules.get('torch')
    if torch_mod is not None:
        provenance['torch_version'] = torch_mod.__version__

    _PROVENANCE_CACHE = provenance
    return dict(provenance)


@dataclass(frozen=True)
class Result(Generic[P]):
    """
    Immutable result envelope for statistical computations.
    
    Type Parameters:
        P: The domain-specific parameter payload type
        
    Attributes:
        params: Domain-specific parameters (coefficients, estimates, etc.)
        info: Structured metadata (method, convergence, diagnostics)
        timing: Execution timing breakdown, or None if not measured
        backend_name: Identifier of the backend that produced this result
        warnings: Non-fatal issues encountered during computation
        provenance: Reproducibility metadata (versions, device, algorithm)
        
    The frozen=True ensures results are immutable after creation, which is
    important for reproducibility and prevents accidental modification.
    
    Examples:
        >>> # Direct method (no convergence notion)
        >>> Result(
        ...     params=LinearParams(coefficients=beta),
        ...     info={'method': 'qr', 'rank': 5},
        ...     timing={'total_seconds': 0.01},
        ...     backend_name='cpu_qr'
        ... )
        
        >>> # Iterative method
        >>> Result(
        ...     params=MVNParams(mu=mu, sigma=sigma),
        ...     info={'method': 'em', 'converged': True, 'iterations': 23},
        ...     timing={'total_seconds': 0.5, 'e_step': 0.3, 'm_step': 0.2},
        ...     backend_name='cpu_em'
        ... )
    """
    params: P
    info: dict[str, Any]
    timing: dict[str, float] | None
    backend_name: str
    warnings: tuple[str, ...] = field(default_factory=tuple)
    provenance: dict[str, Any] = field(default_factory=_default_provenance)
    
    def has_warning(self, substring: str) -> bool:
        """Check if any warning contains the given substring."""
        return any(substring in w for w in self.warnings)
