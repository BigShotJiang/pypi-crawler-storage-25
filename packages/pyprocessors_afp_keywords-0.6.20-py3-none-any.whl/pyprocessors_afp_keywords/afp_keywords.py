import os
from typing import cast

from pydantic import BaseModel, Field
from pymultirole_plugins.v1.processor import ProcessorBase, ProcessorParameters
from pymultirole_plugins.v1.schema import AltText, Document

_home = os.path.expanduser("~")


class AFPKeywordsParameters(ProcessorParameters):
    threshold: float = Field(0.0, description="Score threshold to keep the keyword.")
    as_altText: str = Field(
        "slug",
        description="If defined, generate the slug as an alternative text of the input document.",
    )


class AFPKeywordsProcessor(ProcessorBase):
    """AFP keywords extractor.

    Extracts keywords from document categories and generates a slug
    by joining category labels that exceed the score threshold.
    The slug is stored as an alternative text on the document.
    """

    def process(self, documents: list[Document], parameters: ProcessorParameters) -> list[Document]:
        params: AFPKeywordsParameters = cast(AFPKeywordsParameters, parameters)
        for document in documents:
            labels = []
            if document.categories:
                for cat in document.categories:
                    if cat.score > params.threshold:
                        labels.append(cat.label or cat.labelName)
            slug = "-".join(labels)
            if params.as_altText is not None and len(params.as_altText):
                document.altTexts = document.altTexts or []
                altTexts = [alt for alt in document.altTexts if alt.name != params.as_altText]
                altTexts.append(AltText(name=params.as_altText, text=slug))
                document.altTexts = altTexts
        return documents

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return AFPKeywordsParameters
