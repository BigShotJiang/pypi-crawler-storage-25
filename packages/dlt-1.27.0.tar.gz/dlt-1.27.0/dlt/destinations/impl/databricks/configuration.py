from __future__ import annotations

import dataclasses
from copy import deepcopy
from typing import TYPE_CHECKING, Any, Callable, ClassVar, Dict, Final, List, Optional, Union, cast
from urllib.parse import urlparse

from dlt.common import logger
from dlt.common.configuration.specs.base_configuration import (
    BaseConfiguration,
    CredentialsConfiguration,
    configspec,
)
from dlt.common.typing import TSecretStrValue
from dlt.common.destination.client import DestinationClientDwhWithStagingConfiguration
from dlt.common.configuration.exceptions import ConfigurationValueError
from dlt.common.utils import digest128
from dlt.destinations.impl.databricks.typing import TDatabricksInsertApi

if TYPE_CHECKING:
    from zerobus import ArrowStreamConfigurationOptions, IPCCompression


DATABRICKS_APPLICATION_ID = "dltHub_dlt"
DEFAULT_DATABRICKS_INSERT_API: TDatabricksInsertApi = "copy_into"
# ZSTD was fastest in my benchmarks out of the three `ipc_compression` options
# currently available (NONE, LZ4_FRAME, ZSTD) — NONE (no compression) was slowest
DEFAULT_DATABRICKS_ZEROBUS_IPC_COMPRESSION = "ZSTD"


@configspec
class DatabricksCredentials(CredentialsConfiguration):
    catalog: str = None
    server_hostname: Optional[str] = None
    http_path: Optional[str] = None
    access_token: Optional[TSecretStrValue] = None
    client_id: Optional[TSecretStrValue] = None
    client_secret: Optional[TSecretStrValue] = None
    http_headers: Optional[Dict[str, str]] = None
    session_configuration: Optional[Dict[str, Any]] = None
    """Dict of session parameters that will be passed to `databricks.sql.connect`"""
    connection_parameters: Optional[Dict[str, Any]] = None
    """Additional keyword arguments that are passed to `databricks.sql.connect`"""
    socket_timeout: Optional[int] = 180
    user_agent_entry: Optional[str] = DATABRICKS_APPLICATION_ID

    __config_gen_annotations__: ClassVar[List[str]] = [
        "server_hostname",
        "http_path",
        "catalog",
        "client_id",
        "client_secret",
        "access_token",
    ]

    def on_resolved(self) -> None:
        try:
            from databricks.sdk import WorkspaceClient

            w = WorkspaceClient()
        except Exception:
            w = None

        if not ((self.client_id and self.client_secret) or self.access_token):
            if w is not None:
                try:
                    # attempt context authentication via notebook token
                    self.access_token = (
                        w.dbutils.notebook.entry_point.getDbutils()
                        .notebook()
                        .getContext()
                        .apiToken()
                        .getOrElse(None)
                    )
                except Exception:
                    self.access_token = None

                try:
                    self.access_token = w.config.authenticate
                    logger.info(f"Will attempt to use default auth of type {w.config.auth_type}")
                except Exception:
                    pass

            if not self.access_token:
                raise ConfigurationValueError(
                    "Authentication failed: No valid authentication method detected. "
                    "Provide either `client_id` and `client_secret` for OAuth authentication, "
                    "or `access_token` for token-based authentication."
                )

        if not self.server_hostname or not self.http_path:
            if w is not None:
                # try to get server_hostname from workspace URL
                if not self.server_hostname:
                    try:
                        workspace_url = w.config.host
                        if workspace_url:
                            self.server_hostname = urlparse(workspace_url).hostname
                            logger.info(
                                f"Using server_hostname from workspace: {self.server_hostname}"
                            )
                    except Exception:
                        pass

                # try to get http_path from notebook cluster context
                if not self.http_path:
                    try:
                        notebook_context = (
                            w.dbutils.notebook.entry_point.getDbutils().notebook().getContext()
                        )
                        cluster_id = notebook_context.clusterId().get()
                        workspace_id = notebook_context.workspaceId().get()
                        if cluster_id and workspace_id:
                            self.http_path = f"/sql/protocolv1/o/{workspace_id}/{cluster_id}"
                            logger.info(f"Using http_path from cluster context: {self.http_path}")
                    except Exception:
                        pass

                # fallback: try to fetch warehouse details
                if not self.server_hostname or not self.http_path:
                    try:
                        if w.config.warehouse_id:
                            warehouse = w.warehouses.get(w.config.warehouse_id)
                        else:
                            # for some reason list of warehouses has different type
                            # than a single one
                            warehouse = list(w.warehouses.list())[0]
                        logger.info(
                            "Will attempt to use warehouse"
                            f" {warehouse.id} to get sql connection params"
                        )
                        self.server_hostname = (
                            self.server_hostname or warehouse.odbc_params.hostname
                        )
                        self.http_path = self.http_path or warehouse.odbc_params.path
                    except Exception:
                        pass

        for param in ("catalog", "server_hostname", "http_path"):
            if not getattr(self, param):
                raise ConfigurationValueError(
                    f"Configuration error: Missing required parameter `{param}`. "
                    "Please provide it in the configuration."
                )

    def _get_oauth_credentials(self) -> Optional[Callable[[], Dict[str, str]]]:
        from databricks.sdk.core import Config, oauth_service_principal

        config = Config(
            host=f"https://{self.server_hostname}",
            client_id=self.client_id,
            client_secret=self.client_secret,
        )
        return cast(Callable[[], Dict[str, str]], oauth_service_principal(config))

    def to_connector_params(self) -> Dict[str, Any]:
        conn_params = dict(
            catalog=self.catalog,
            server_hostname=self.server_hostname,
            http_path=self.http_path,
            access_token=self.access_token,
            session_configuration=self.session_configuration or {},
            _socket_timeout=self.socket_timeout,
            **(self.connection_parameters or {}),
        )

        if self.user_agent_entry:
            conn_params["user_agent_entry"] = (
                conn_params.get("user_agent_entry") or self.user_agent_entry
            )

        if self.client_id and self.client_secret:
            conn_params["credentials_provider"] = self._get_oauth_credentials
        elif callable(self.access_token):
            # this is w.config.authenticator
            conn_params["credentials_provider"] = lambda: self.access_token
        else:
            # this is access token
            conn_params["access_token"] = self.access_token
        return conn_params

    def to_workspace_url(self) -> str:
        if not self.server_hostname:
            raise ConfigurationValueError(
                "Cannot construct workspace URL: `server_hostname` is not set."
            )
        return f"https://{self.server_hostname}"

    def __str__(self) -> str:
        return f"databricks://{self.server_hostname}{self.http_path}/{self.catalog}"


@configspec
class DatabricksZerobusCredentials(CredentialsConfiguration):
    client_id: str = None
    client_secret: TSecretStrValue = None


@configspec
class DatabricksZerobusConfiguration(BaseConfiguration):
    endpoint_url: str = None
    """URL of the Zerobus server endpoint."""
    credentials: DatabricksZerobusCredentials = None
    """Credentials to authenticate to the Zerobus server."""
    batch_size: int = 25_000
    """Number of records per batch to ingest into Zerobus."""
    stream_options: Optional[dict[str, Any]] = None
    """Stream configuration options forwarded to `options` argument of `ZerobusSdk.create_arrow_stream()`."""

    def on_partial(self) -> None:
        if not self.endpoint_url:
            return

        if self.credentials is None:
            # we'll attempt to resolve credentials later in `DatabricksClientConfiguration.on_resolved()`
            self.credentials = DatabricksZerobusCredentials()

        self.resolve()

    def to_arrow_stream_configuration_options(self) -> ArrowStreamConfigurationOptions:
        from zerobus import ArrowStreamConfigurationOptions

        options = deepcopy(self.stream_options) if self.stream_options else dict()
        if "ipc_compression" not in options:
            options["ipc_compression"] = DEFAULT_DATABRICKS_ZEROBUS_IPC_COMPRESSION
        options["ipc_compression"] = self._coerce_ipc_compression(options["ipc_compression"])
        return ArrowStreamConfigurationOptions(**options)

    @staticmethod
    def _coerce_ipc_compression(ipc_compression: Union[str, IPCCompression]) -> IPCCompression:
        from zerobus import IPCCompression

        if isinstance(ipc_compression, str):
            return getattr(IPCCompression, ipc_compression)
        return ipc_compression


@configspec
class DatabricksClientConfiguration(DestinationClientDwhWithStagingConfiguration):
    destination_type: Final[str] = dataclasses.field(default="databricks", init=False, repr=False, compare=False)  # type: ignore[misc]
    credentials: DatabricksCredentials = None
    staging_credentials_name: Optional[str] = None
    "If set, credentials with given name will be used in copy command"
    is_staging_external_location: bool = False
    """If true, the temporary credentials are not propagated to the COPY command"""
    staging_volume_name: Optional[str] = None
    """Name of the Databricks managed volume for temporary storage, e.g., <catalog_name>.<database_name>.<volume_name>. Defaults to '_dlt_temp_load_volume' if not set."""
    keep_staged_files: Optional[bool] = True
    """Tells if to keep the files in internal (volume) stage"""
    create_indexes: bool = False
    """Whether PRIMARY KEY or FOREIGN KEY constrains should be created"""
    insert_api: TDatabricksInsertApi = DEFAULT_DATABRICKS_INSERT_API
    """Ingestion backend for `append` write disposition. Can be overridden per resource via `databricks_adapter`."""
    zerobus: Optional[DatabricksZerobusConfiguration] = None
    """Databricks Zerobus Configuration including endpoint and credentials. Required when using the `zerobus` insert API."""

    def __str__(self) -> str:
        """Return displayable destination location"""
        if self.credentials:
            return str(self.credentials)
        else:
            return ""

    def on_resolved(self) -> None:
        if self.zerobus is None:
            return

        if self.zerobus.credentials.client_id and self.zerobus.credentials.client_secret:
            return

        # fall back to main credentials if Zerobus credentials are not fully provided
        if self.credentials.client_id and self.credentials.client_secret:
            self.zerobus.credentials = DatabricksZerobusCredentials(
                client_id=self.credentials.client_id,
                client_secret=self.credentials.client_secret,
            )
            self.zerobus.credentials.resolve()

        if not self.zerobus.credentials.is_resolved():
            raise ConfigurationValueError(
                "`client_id` and `client_secret` are required when"
                " `destination.databricks.zerobus` is configured. Set either"
                " `destination.databricks.zerobus.credentials.client_id` and"
                " `destination.databricks.zerobus.credentials.client_secret`, or"
                " `destination.databricks.credentials.client_id` and"
                " `destination.databricks.credentials.client_secret`."
            )

    def fingerprint(self) -> str:
        """Returns a fingerprint of host part of a connection string"""
        if self.credentials and self.credentials.server_hostname:
            return digest128(self.credentials.server_hostname)
        return ""
