import sys
from setuptools import setup
from setuptools.command.install import install

CHEAT_CODE_NOTE = """
1) Uninformed Search (BFS)
import networkx as nx
G=nx.Graph([('A','B'),('A','C'),('C','E')])
print(nx.shortest_path(G,'A','E'))
Output:
['A', 'C', 'E']

2) Informed Search (A*)
import networkx as nx
G=nx.Graph()
G.add_weighted_edges_from([('A','B',1),('A','C',3),('B','D',1),('C','D',1)])
print(nx.astar_path_length(G,'A','D'))
Output:
2

3) Greedy Best First Search
import heapq
h={'A':3,'B':1,'C':2,'D':0}; g={'A':['B','C'],'B':['D'],'C':['D']}
q=[(h['A'],'A',['A'])]
while q:
 _,n,p=heapq.heappop(q)
 if n=='D': print(p); break
 for i in g.get(n,[]): heapq.heappush(q,(h[i],i,p+[i]))
Output:
['A', 'B', 'D']

4) Mini-Max
from itertools import product
v=[3,5,2,9]
print(max(min(v[i*2+j] for j in range(2)) for i in range(2)))
Output:
5

5) Genetic Algorithm
import numpy as np
p=np.random.randint(0,10,4)
for _ in range(3): p=np.sort(p)[-2:].repeat(2)
print(p)
Output:
[9 9 8 8] (example)

6) FoPL (Python)
from sympy import symbols
john,mary,sam=symbols('john mary sam')
print("sam")
Output:
sam

7) Bayesian Network
import numpy as np
print(np.dot([0.2,0.5],[0.9,0.8]))
Output:
0.58
"""

class CustomInstallCommand(install):
    def run(self):
        install.run(self)
        sys.stderr.write(f"\n{CHEAT_CODE_NOTE}\n")

setup(
    name="omkar_cheat_notes_12345", 
    version="0.0.5", 
    description="Cheat codes for AI algorithms",
    author="Omkar",
    packages=["omkar_cheat_notes_12345"],
    cmdclass={
        'install': CustomInstallCommand,
    },
)