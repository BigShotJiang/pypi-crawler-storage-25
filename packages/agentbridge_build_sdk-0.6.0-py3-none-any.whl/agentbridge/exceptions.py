"""Custom exceptions for AgentBridge SDK"""


class AgentBridgeError(Exception):
    """Base exception for AgentBridge SDK"""
    pass


class AuthenticationError(AgentBridgeError):
    """Raised for invalid or missing API key"""
    pass


class ComplianceError(AgentBridgeError):
    """
    Raised when a decision is rejected by compliance rules.
    
    Attributes:
        verdict: The compliance verdict (reject, escalate, etc.)
        reason: Detailed explanation for rejection
        risk_level: Risk classification (low, medium, high, critical)
        behavioral_drift: Drift analysis results if available
        structuring_detected: Structuring analysis results if available
    """
    def __init__(
        self, 
        verdict: str, 
        reason: str, 
        risk_level: str,
        behavioral_drift: dict = None,
        structuring_detected: dict = None,
        full_report: dict = None
    ):
        self.verdict = verdict
        self.reason = reason
        self.risk_level = risk_level
        self.behavioral_drift = behavioral_drift or {}
        self.structuring_detected = structuring_detected or {}
        self.full_report = full_report or {}
        
        super().__init__(
            f"Compliance violation - {verdict.upper()}: {reason} "
            f"(Risk: {risk_level})"
        )
