"""
AgentBridge SDK - Compliance Black Box for AI Agents in Indian Fintech
Supports RBI FREE-AI Framework, PMLA 2002, and KYC Master Direction compliance
"""

__version__ = "0.6.0"
__author__ = "NOVA • Mohammed Aakhil E"

from .wrapper import monitor
from .exceptions import AgentBridgeError, AuthenticationError, ComplianceError

__all__ = ["monitor", "AgentBridgeError", "AuthenticationError", "ComplianceError"]
