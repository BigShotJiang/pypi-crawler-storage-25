"""Smart monitor() wrapper for transparent compliance integration"""
from typing import Any, Callable, Dict, Optional
import functools
import uuid
import time
import json
from .client import AgentBridgeClient
from .exceptions import ComplianceError, AgentBridgeError


def monitor(
    agent: Any,
    api_key: str,
    base_url: str = "https://agentbridge-test.onrender.com",
    session_id: Optional[str] = None,
    agent_id: Optional[str] = None,
    enable_behavioral_analysis: bool = True,
    enable_structuring_detection: bool = True,
    strict_mode: bool = True,
    verbose: bool = False
):
    """
    Wrap any AI agent with AgentBridge compliance layer.
    
    Provides transparent compliance enforcement with:
    - Real-time policy violation detection
    - Behavioral drift monitoring
    - Structuring pattern detection
    - Groq AI-powered analysis
    - Automatic audit logging
    
    Usage:
        from agentbridge import monitor
        
        # Wrap your agent
        monitored_agent = monitor(my_agent, api_key="ab_xxxx")
        
        # Use exactly like before
        result = monitored_agent.approve_loan(
            amount=45000,
            kyc_verified=True,
            reasoning="Verified income and credit score"
        )
    
    Args:
        agent: Your AI agent instance (any class or callable)
        api_key: AgentBridge API key (get from dashboard)
        base_url: Gateway URL (default: production)
        session_id: Optional session identifier for tracking
        agent_id: Optional agent identifier (auto-detected if not provided)
        enable_behavioral_analysis: Enable drift detection (default: True)
        enable_structuring_detection: Enable pattern detection (default: True)
        strict_mode: Raise ComplianceError on reject (default: True)
        verbose: Print detailed logs to console (default: False)
    
    Returns:
        Wrapped agent with compliance enforcement
    """
    
    client = AgentBridgeClient(api_key=api_key, base_url=base_url)
    current_session = session_id or f"sess_{uuid.uuid4().hex[:12]}"
    agent_name = agent_id or getattr(agent, "__name__", None) or agent.__class__.__name__
    
    if verbose:
        print(f"[AgentBridge] Monitoring agent: {agent_name}")
        print(f"[AgentBridge] Session ID: {current_session}")
    
    def wrap_method(method: Callable, method_name: str) -> Callable:
        """Wrap a single agent method with compliance checks"""
        
        @functools.wraps(method)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            
            # Extract reasoning from kwargs or agent state
            reasoning = (
                kwargs.pop("reasoning", None) or 
                kwargs.pop("explanation", None) or
                getattr(agent, "last_reasoning", None) or 
                getattr(agent, "_reasoning", None) or
                ""
            )
            
            # Build input payload from args and kwargs
            input_data = {
                "method": method_name,
                "args": [str(a) if not isinstance(a, (dict, list, int, float, bool)) else a for a in args],
                "kwargs": {k: v for k, v in kwargs.items() if not k.startswith("_")},
            }
            
            # Extract common fields
            amount = kwargs.get("amount") or kwargs.get("value") or 0
            kyc_verified = kwargs.get("kyc_verified", False)
            is_pep = kwargs.get("is_pep", False)
            confidence = float(kwargs.get("confidence", 0.85))
            
            # Determine action type from method name
            action_type = "approve"
            if "reject" in method_name.lower():
                action_type = "reject"
            elif "escalate" in method_name.lower() or "flag" in method_name.lower():
                action_type = "escalate"
            elif "review" in method_name.lower():
                action_type = "review"
            
            # Build gateway payload
            payload = {
                "session_id": current_session,
                "agent_id": agent_name,
                "user_id": (
                    kwargs.get("user_id") or 
                    kwargs.get("customer_id") or 
                    kwargs.get("beneficiary_id") or
                    "default_user"
                ),
                "action_type": action_type,
                "input": {
                    **input_data,
                    "amount": amount,
                    "kyc_verified": kyc_verified,
                    "is_pep": is_pep,
                },
                "reasoning": str(reasoning),
                "confidence": confidence,
                "output": {},  # Will be filled after execution
                "domain": "fintech",
                "timestamp": time.time(),
            }
            
            if verbose:
                print(f"\n[AgentBridge] Checking compliance for {method_name}...")
                print(f"  Action: {action_type}")
                print(f"  Amount: ₹{amount:,.0f}")
                print(f"  KYC: {kyc_verified}")
            
            # Step 1: Send to compliance gateway for pre-execution check
            try:
                gateway_response = client.decide(payload)
            except ComplianceError as e:
                if verbose:
                    print(f"[AgentBridge] ❌ Compliance rejection: {e.reason}")
                raise
            except Exception as e:
                if verbose:
                    print(f"[AgentBridge] ⚠️ Gateway error: {e}")
                if strict_mode:
                    raise AgentBridgeError(f"Compliance check failed: {e}") from e
                # Continue execution if not in strict mode
                gateway_response = {"verdict": "approve", "risk_level": "unknown"}
            
            verdict = gateway_response.get("verdict", "approve")
            risk_level = gateway_response.get("risk_level", "low")
            
            # Extract enhanced analysis results
            behavioral_drift = gateway_response.get("behavioral_drift", {})
            structuring_detected = gateway_response.get("structuring_detected", {})
            ai_analysis = gateway_response.get("groq_analysis", {})
            
            if verbose:
                print(f"  Verdict: {verdict.upper()}")
                print(f"  Risk: {risk_level.upper()}")
                if behavioral_drift.get("status") == "drift_detected":
                    print(f"  ⚠️ Behavioral drift: {behavioral_drift.get('finding_count')} shifts detected")
                if structuring_detected.get("finding_count", 0) > 0:
                    print(f"  ⚠️ Structuring: {structuring_detected.get('finding_count')} patterns detected")
            
            # Hard reject - block execution
            if verdict == "reject":
                error = ComplianceError(
                    verdict=verdict,
                    reason=gateway_response.get("message") or "Blocked by RBI compliance rules",
                    risk_level=risk_level,
                    behavioral_drift=behavioral_drift,
                    structuring_detected=structuring_detected,
                    full_report=gateway_response
                )
                if verbose:
                    print(f"[AgentBridge] 🚫 BLOCKED: {error.reason}")
                raise error
            
            # Escalate - warn but allow execution
            if verdict == "escalate":
                if verbose:
                    print(f"[AgentBridge] ⚠️ ESCALATED: {gateway_response.get('message')}")
                    print(f"  Proceeding with execution but flagged for review")
            
            # Execute the actual agent method
            try:
                result = method(*args, **kwargs)
                execution_success = True
            except Exception as e:
                if verbose:
                    print(f"[AgentBridge] Agent method failed: {e}")
                result = None
                execution_success = False
                raise
            finally:
                # Record execution time
                latency_ms = int((time.time() - start_time) * 1000)
                
                # Update output with real result (fire and forget)
                try:
                    if isinstance(result, dict):
                        payload["output"] = result
                    else:
                        payload["output"] = {"result": str(result) if result is not None else None}
                    
                    payload["latency_ms"] = latency_ms
                    payload["execution_success"] = execution_success
                    
                    # Log final result (async, non-blocking)
                    client.decide(payload)
                except:
                    pass  # Don't fail user request on logging error
            
            # Return enriched response
            return {
                "verdict": verdict,
                "risk_level": risk_level,
                "risk_score": gateway_response.get("risk_score"),
                "behavioral_drift": behavioral_drift,
                "structuring_detected": structuring_detected,
                "ai_analysis": ai_analysis,
                "result": result,
                "session_id": current_session,
                "latency_ms": latency_ms,
                "compliance_passed": verdict != "reject",
            }
        
        return wrapper
    
    # Apply wrapper to common agent methods
    common_methods = [
        "decide", "approve", "reject", "process", "run", 
        "predict", "execute", "handle", "classify", "__call__"
    ]
    
    for method_name in common_methods:
        if hasattr(agent, method_name) and callable(getattr(agent, method_name)):
            original = getattr(agent, method_name)
            wrapped = wrap_method(original, method_name)
            setattr(agent, method_name, wrapped)
    
    # Support direct call on the agent
    if callable(agent) and not hasattr(agent, "__call__wrapped__"):
        original_call = agent.__call__ if hasattr(agent, "__call__") else agent
        agent.__call__ = wrap_method(original_call, "call")
        agent.__call__wrapped__ = True
    
    # Add utility methods to the agent
    agent._agentbridge_session = current_session
    agent._agentbridge_client = client
    
    if verbose:
        print(f"[AgentBridge] ✓ Agent wrapped successfully\n")
    
    return agent
