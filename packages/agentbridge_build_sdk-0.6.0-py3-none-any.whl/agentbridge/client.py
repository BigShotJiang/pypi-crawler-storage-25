"""HTTP client for AgentBridge gateway communication"""
import httpx
import json
from typing import Any, Dict, Optional
from .exceptions import AgentBridgeError, AuthenticationError


class AgentBridgeClient:
    """
    HTTP client for communicating with AgentBridge compliance gateway.
    
    Handles API authentication, request formatting, and response parsing.
    """
    
    def __init__(
        self, 
        api_key: str, 
        base_url: str = "https://agentbridge-test.onrender.com",
        timeout: float = 20.0
    ):
        """
        Initialize the AgentBridge client.
        
        Args:
            api_key: Your AgentBridge API key (format: ab_xxxxxxx)
            base_url: Gateway URL (default: production endpoint)
            timeout: Request timeout in seconds
        """
        if not api_key or not api_key.startswith("ab_"):
            raise AuthenticationError(
                "Invalid API key format. Must start with 'ab_'"
            )
        
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.client = httpx.Client(timeout=timeout)
        
    def decide(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Send decision to gateway for compliance enforcement and behavioral analysis.
        
        Args:
            payload: Decision data including action, inputs, reasoning, etc.
            
        Returns:
            dict: Gateway response with verdict, risk analysis, behavioral drift,
                  and structuring detection results
                  
        Raises:
            AuthenticationError: If API key is invalid or inactive
            AgentBridgeError: For other gateway errors
        """
        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json"
        }
        
        try:
            response = self.client.post(
                f"{self.base_url}/decide", 
                json=payload, 
                headers=headers
            )
            
            # Handle authentication errors
            if response.status_code == 401:
                raise AuthenticationError("Invalid API key")
            if response.status_code == 403:
                raise AuthenticationError("API key inactive or rate limited")
            
            # Raise for other HTTP errors
            response.raise_for_status()
            
            return response.json()
            
        except httpx.HTTPStatusError as e:
            try:
                error_detail = e.response.json().get("detail", str(e))
            except:
                error_detail = str(e)
            raise AgentBridgeError(f"Gateway error: {error_detail}") from e
            
        except httpx.TimeoutException as e:
            raise AgentBridgeError(
                f"Request timeout after {self.client.timeout}s. "
                "Gateway may be under heavy load."
            ) from e
            
        except Exception as e:
            raise AgentBridgeError(
                f"Failed to connect to AgentBridge: {e}"
            ) from e
    
    def manual_log(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Submit a manual log entry with enhanced behavioral analysis.
        
        This endpoint provides comprehensive compliance analysis including:
        - Behavioral drift detection
        - Structuring pattern detection
        - Groq AI-powered deep analysis
        - Detailed compliance report
        
        Args:
            payload: Log data with api_key, agent_name, action_type, etc.
            
        Returns:
            dict: Complete analysis including drift, structuring, and AI insights
        """
        headers = {
            "Content-Type": "application/json"
        }
        
        # Ensure api_key is in payload for manual logging
        if "api_key" not in payload:
            payload["api_key"] = self.api_key
        
        try:
            response = self.client.post(
                f"{self.base_url}/log-manual",
                json=payload,
                headers=headers
            )
            
            response.raise_for_status()
            return response.json()
            
        except httpx.HTTPStatusError as e:
            try:
                error_detail = e.response.json().get("detail", str(e))
            except:
                error_detail = str(e)
            raise AgentBridgeError(f"Manual logging failed: {error_detail}") from e
            
        except Exception as e:
            raise AgentBridgeError(f"Manual logging error: {e}") from e
    
    def __del__(self):
        """Cleanup HTTP client on deletion"""
        try:
            self.client.close()
        except:
            pass
