def filecopywithoutcomments():
    '''source=input("Enter Source File Name:")
    destination=input("Enter Destination Name:")

    with open(source,"r") as src,open (destination,"w") as dest:
        for line in src:
            if src.startswith("#"):
                continue
            dest.write(line)
        print("File Copied Successfully") '''

def filecountnumberofline():
    '''
    source=input("Enter Source File Name:")

    count=0
    with open(source,"r") as src,open (destination,"w") as dest:
        for line in src:
            count+=1
        print("Number of lines in File is",count)

    '''

def filepercentofvowels():
    '''
    source=input("Enter Source File Name:")
    vowels=0
    total=0
    src=open(source,"r")
    for i in src:
        for j in i:
            if j in "aeiou":
                vowels+=1
            total+=1
    print("Percentage of Vowels:",(vowels/total)*100)
    print("Percentage of Consosnts:",(100-((vowels/total)*100)))
    src.close()
    '''
def filenumberofspaces():
    '''
    source=input("Enter Source File Name:")
    spaces=0
    newlines=0
    tabs=0
    src=open(source,"r")
    for i in src:
        for j in i:
            if j==' ':
                spaces+=1
            elif j=="\t":
                tabs+=1
            else:
                newlines+=1
    print("No of new Lines:",newlines)
    print("No of spaces:",spaces)
    print("No of tabs:",tabs)
    src.close()
    '''
def filecopywithlinenumbers():
    '''
    source=input("Enter the source of file:")
    destination=input("Enter destination file:")
    src=open(source,"r")
    dest=open(destination,"w")
    counter=0
    for i in src:
        count+=1
        dest.write(count)
        dest.write(i)
        dest.write(\n)
    print("Completed")
    src.close()
    dest.close()
    '''


