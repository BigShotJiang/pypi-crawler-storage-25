from .programs import (
    filecopywithoutcomments,
    filecountnumberofline,
    filepercentofvowels,
    filenumberofspaces,
    filecopywithlinenumbers
)

