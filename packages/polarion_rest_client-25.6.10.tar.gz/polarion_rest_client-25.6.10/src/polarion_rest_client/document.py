from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional, Union, Awaitable

from .client import PolarionClient, PolarionAsyncClient
from .resource import PolarionResource, DeepFields
from .error import raise_from_response

# Low-level API endpoints
from polarion_rest_client.openapi.api.documents.post_documents import (
    sync_detailed as _post_documents,
    asyncio_detailed as _post_documents_async,
)
from polarion_rest_client.openapi.api.documents.get_document import (
    sync_detailed as _get_document,
    asyncio_detailed as _get_document_async,
)
from polarion_rest_client.openapi.api.documents.patch_document import (
    sync_detailed as _patch_document,
    asyncio_detailed as _patch_document_async,
)
from polarion_rest_client.openapi.api.documents.branch_document import (
    sync_detailed as _branch_document,
    asyncio_detailed as _branch_document_async,
)
from polarion_rest_client.openapi.api.documents.branch_documents import (
    sync_detailed as _branch_documents,
    asyncio_detailed as _branch_documents_async,
)
from polarion_rest_client.openapi.api.documents.copy_document import (
    sync_detailed as _copy_document,
    asyncio_detailed as _copy_document_async,
)
from polarion_rest_client.openapi.api.documents.merge_document_from_master import (
    sync_detailed as _merge_from_master,
    asyncio_detailed as _merge_from_master_async,
)
from polarion_rest_client.openapi.api.documents.merge_document_to_master import (
    sync_detailed as _merge_to_master,
    asyncio_detailed as _merge_to_master_async,
)
from polarion_rest_client.openapi.api.documents.get_available_enum_options_for_document import (
    sync_detailed as _get_enum_options,
    asyncio_detailed as _get_enum_options_async,
)
from polarion_rest_client.openapi.api.documents.get_available_enum_options_for_document_type import (
    sync_detailed as _get_enum_options_for_type,
    asyncio_detailed as _get_enum_options_for_type_async,
)
from polarion_rest_client.openapi.api.documents.get_current_enumeration_options_for_document import (
    sync_detailed as _get_current_enum_options,
    asyncio_detailed as _get_current_enum_options_async,
)

# Request models
from polarion_rest_client.openapi.models.documents_list_post_request import (
    DocumentsListPostRequest,
)
from polarion_rest_client.openapi.models.documents_single_patch_request import (
    DocumentsSinglePatchRequest,
)
from polarion_rest_client.openapi.models.branch_document_request_body import (
    BranchDocumentRequestBody,
)
from polarion_rest_client.openapi.models.branch_documents_request_body import (
    BranchDocumentsRequestBody,
)
from polarion_rest_client.openapi.models.copy_document_request_body import (
    CopyDocumentRequestBody,
)
from polarion_rest_client.openapi.models.merge_document_request_body import (
    MergeDocumentRequestBody,
)
from polarion_rest_client.openapi.types import UNSET, Unset


# --- Re-implementation of _DeepFields, as used in document_part.py ---
# This is needed because the standard SparseFields model does not
# serialize to the "deepObject" format (fields[resource]=...)
# that the Polarion API expects.
class _DeepFields:
    """
    Small helper that encodes deep-object fields exactly as:
      {'fields[<resource>]': '<value or comma-joined list>'}
    """

    def __init__(self, resource: str, value: Union[str, List[str]]):
        self.resource = resource
        self.value = value

    def to_dict(self) -> Dict[str, Any]:
        v = self.value
        if isinstance(v, list):
            v = ",".join(v)
        return {f"fields[{self.resource}]": v}


def _build_fields_param_for_documents(
    fields_documents: Optional[Union[str, List[str]]],
) -> Union[Unset, DeepFields]:
    """
    Turn `fields_documents` into a deep-object fields parameter
    for the 'documents' resource.
    """
    if not fields_documents:
        return UNSET
    return DeepFields(
        "documents",
        fields_documents
        if isinstance(fields_documents, str)
        else list(fields_documents),
    )


class Document(PolarionResource):
    """
    High-level Document operations built on the generated client API.
    Supports both synchronous and asynchronous clients.

    Available operations:
      • create  (POST  .../documents)
      • get     (GET   .../documents/{documentName})
      • update  (PATCH .../documents/{documentName})
      • branch  (POST  .../documents/{documentName}/actions/branch)
      • branch_documents (POST /all/documents/actions/branch)  — batch
      • copy    (POST  .../documents/{documentName}/actions/copy)
      • merge_from_master (POST .../actions/mergeFromMaster)
      • merge_to_master   (POST .../actions/mergeToMaster)
      • get_available_enum_options       (GET .../fields/{fieldId}/actions/getAvailableOptions)
      • get_available_enum_options_for_type (GET .../documents/fields/{fieldId}/actions/getAvailableOptions)
      • get_current_enum_options         (GET .../fields/{fieldId}/actions/getCurrentOptions)

    Not available in current API spec:
      • list/iter (getDocuments — see commented stubs below)
    """

    def __init__(self, pc: Union[PolarionClient, PolarionAsyncClient]):
        super().__init__(pc)
        self._c = pc.gen  # AuthenticatedClient

        # -------------------------------------------------------------------
        # TODO: implement when Polarion 25.12 is available
        # Enable paging param resolution when list endpoint exists.
        # self._page_param, self._size_param = resolve_page_params(_get_documents)
        # -------------------------------------------------------------------

    # ---------------------------- CREATE ----------------------------
    def create(
        self,
        project_id: str,
        space_id: str,
        *,
        module_name: str,  # documentName to create
        title: Optional[str] = None,
        doc_type: Optional[str] = None,  # e.g. 'req_specification'
        status: Optional[str] = None,    # e.g. 'draft'
        home_page_content: Optional[str] = None,
        home_page_content_type: str = "text/plain",
        auto_suspect: Optional[bool] = None,
        uses_outline_numbering: Optional[bool] = None,
        outline_numbering_prefix: Optional[str] = None,
        rendering_layouts: Optional[List[Mapping[str, Any]]] = None,
        structure_link_role: Optional[str] = None,
        attributes: Optional[Mapping[str, Any]] = None,
    ) -> Union[Dict[str, Any], Awaitable[Dict[str, Any]]]:
        """
        POST /projects/{projectId}/spaces/{spaceId}/documents
        Required: module_name (documentName). Other attributes are optional.
        """
        attrs: Dict[str, Any] = {"moduleName": module_name}
        if title is not None:
            attrs["title"] = title
        if doc_type is not None:
            attrs["type"] = doc_type
        if status is not None:
            attrs["status"] = status
        if home_page_content is not None:
            attrs["homePageContent"] = {
                "type": home_page_content_type,
                "value": home_page_content,
            }
        if auto_suspect is not None:
            attrs["autoSuspect"] = bool(auto_suspect)
        if uses_outline_numbering is not None:
            attrs["usesOutlineNumbering"] = bool(uses_outline_numbering)
        if outline_numbering_prefix is not None:
            attrs["outlineNumbering"] = {"prefix": outline_numbering_prefix}
        if rendering_layouts:
            attrs["renderingLayouts"] = list(rendering_layouts)
        if structure_link_role is not None:
            attrs["structureLinkRole"] = structure_link_role
        if attributes:
            attrs.update(attributes)

        body = DocumentsListPostRequest.from_dict(
            {"data": [{"type": "documents", "attributes": attrs}]}
        )

        # Helper to process response specifically for create return structure
        def _extract_created_doc(resp) -> Dict[str, Any]:
            if resp.status_code in (200, 201) and resp.parsed:
                doc = self._to_dict(resp)
                data = doc.get("data") or []
                return data[0] if isinstance(data, list) and data else doc
            raise_from_response(resp)

        if self.client.is_async:
            async def _do_async():
                resp = await _post_documents_async(
                    client=self._c, project_id=project_id, space_id=space_id, body=body
                )
                return _extract_created_doc(resp)
            return _do_async()
        else:
            resp = _post_documents(
                client=self._c, project_id=project_id, space_id=space_id, body=body
            )
            return _extract_created_doc(resp)

    # ------------------------------ GET ------------------------------
    def get(
        self,
        project_id: str,
        space_id: str,
        document_name: str,
        *,
        fields_documents: Optional[Union[str, List[str]]] = None,
        include: Optional[str] = None,
        revision: Optional[str] = None,
    ) -> Union[Dict[str, Any], Awaitable[Dict[str, Any]]]:
        """GET /projects/{projectId}/spaces/{spaceId}/documents/{documentName}"""
        # Use the custom _DeepFields helper instead of SparseFields
        fields = _build_fields_param_for_documents(fields_documents)

        return self._request(
            _get_document,
            _get_document_async,
            project_id=project_id,
            space_id=space_id,
            document_name=document_name,
            fields=fields,
            include=include if include is not None else UNSET,
            revision=revision if revision is not None else UNSET,
        )

    # ----------------------------- UPDATE -----------------------------
    def update(
        self,
        project_id: str,
        space_id: str,
        document_name: str,
        *,
        title: Optional[str] = None,
        doc_type: Optional[str] = None,
        status: Optional[str] = None,
        home_page_content: Optional[str] = None,
        home_page_content_type: str = "text/plain",
        auto_suspect: Optional[bool] = None,
        uses_outline_numbering: Optional[bool] = None,
        outline_numbering_prefix: Optional[str] = None,
        rendering_layouts: Optional[List[Mapping[str, Any]]] = None,
        workflow_action: Optional[str] = None,  # maps to query param 'workflowAction'
    ) -> Union[Dict[str, Any], Awaitable[Dict[str, Any]]]:
        """
        PATCH /projects/{projectId}/spaces/{spaceId}/documents/{documentName}
        Sends only provided fields.
        """
        attrs: Dict[str, Any] = {}
        if title is not None:
            attrs["title"] = title
        if doc_type is not None:
            attrs["type"] = doc_type
        if status is not None:
            attrs["status"] = status
        if home_page_content is not None:
            attrs["homePageContent"] = {"type": home_page_content_type, "value": home_page_content}
        if auto_suspect is not None:
            attrs["autoSuspect"] = bool(auto_suspect)
        if uses_outline_numbering is not None:
            attrs["usesOutlineNumbering"] = bool(uses_outline_numbering)
        if outline_numbering_prefix is not None:
            attrs["outlineNumbering"] = {"prefix": outline_numbering_prefix}
        if rendering_layouts:
            attrs["renderingLayouts"] = list(rendering_layouts)

        data: Dict[str, Any] = {
            "type": "documents",
            "id": f"{project_id}/{space_id}/{document_name}",
        }
        if attrs:
            data["attributes"] = attrs

        body = DocumentsSinglePatchRequest.from_dict({"data": data})

        # PATCH normally returns 200/204. _request handles returning the body if available.
        return self._request(
            _patch_document,
            _patch_document_async,
            project_id=project_id,
            space_id=space_id,
            document_name=document_name,
            body=body,
            workflow_action=workflow_action if workflow_action is not None else UNSET,
        )

    # ---------------------------- BRANCH ----------------------------
    def branch(
        self,
        project_id: str,
        space_id: str,
        document_name: str,
        *,
        target_project_id: Optional[str] = None,
        target_space_id: Optional[str] = None,
        target_document_name: Optional[str] = None,
        copy_workflow_status_and_signatures: Optional[bool] = None,
        query: Optional[str] = None,
        revision: Optional[str] = None,
    ) -> Union[Dict[str, Any], Awaitable[Dict[str, Any]]]:
        """
        Branch a single document.

        POST .../documents/{documentName}/actions/branch

        Returns the created (branched) document resource.
        """
        body = BranchDocumentRequestBody(
            target_project_id=target_project_id if target_project_id is not None else UNSET,
            target_space_id=target_space_id if target_space_id is not None else UNSET,
            target_document_name=target_document_name if target_document_name is not None else UNSET,
            copy_workflow_status_and_signatures=(
                copy_workflow_status_and_signatures
                if copy_workflow_status_and_signatures is not None else UNSET
            ),
            query=query if query is not None else UNSET,
        )

        def _extract(resp) -> Dict[str, Any]:
            if resp.status_code in (200, 201) and resp.parsed:
                doc = self._to_dict(resp)
                data = doc.get("data")
                if isinstance(data, list):
                    return data[0] if data else doc
                return data if data else doc
            raise_from_response(resp)

        if self.client.is_async:
            async def _do_async():
                resp = await _branch_document_async(
                    client=self._c,
                    project_id=project_id,
                    space_id=space_id,
                    document_name=document_name,
                    body=body,
                    revision=revision if revision is not None else UNSET,
                )
                return _extract(resp)
            return _do_async()
        else:
            resp = _branch_document(
                client=self._c,
                project_id=project_id,
                space_id=space_id,
                document_name=document_name,
                body=body,
                revision=revision if revision is not None else UNSET,
            )
            return _extract(resp)

    # ----------------------- BRANCH DOCUMENTS -------------------------
    def branch_documents(
        self,
        configurations: List[Dict[str, Any]],
    ) -> Union[Dict[str, Any], Awaitable[Dict[str, Any]]]:
        """
        Branch multiple documents in a batch (async job).

        POST /all/documents/actions/branch

        Args:
            configurations: List of dicts, each with at least 'source_document'
                (format: 'projectId/spaceId/documentName') and optional keys:
                source_revision, target_project_id, target_space_id,
                target_document_name, copy_workflow_status_and_signatures,
                query, target_document_title, update_title_heading,
                overwrite_work_items, initialized_fields.

        Returns:
            The job resource (status 202).
        """
        body = BranchDocumentsRequestBody.from_dict({
            "documentConfigurations": [
                {
                    "sourceDocument": cfg["source_document"],
                    **{k: v for k, v in {
                        "sourceRevision": cfg.get("source_revision"),
                        "targetProjectId": cfg.get("target_project_id"),
                        "targetSpaceId": cfg.get("target_space_id"),
                        "targetDocumentName": cfg.get("target_document_name"),
                        "copyWorkflowStatusAndSignatures": cfg.get("copy_workflow_status_and_signatures"),
                        "query": cfg.get("query"),
                        "targetDocumentTitle": cfg.get("target_document_title"),
                        "updateTitleHeading": cfg.get("update_title_heading"),
                        "overwriteWorkItems": cfg.get("overwrite_work_items"),
                        "initializedFields": cfg.get("initialized_fields"),
                    }.items() if v is not None},
                }
                for cfg in configurations
            ]
        })

        def _extract(resp) -> Dict[str, Any]:
            if resp.status_code == 202 and resp.parsed:
                return self._to_dict(resp)
            raise_from_response(resp)

        if self.client.is_async:
            async def _do_async():
                resp = await _branch_documents_async(client=self._c, body=body)
                return _extract(resp)
            return _do_async()
        else:
            resp = _branch_documents(client=self._c, body=body)
            return _extract(resp)

    # ----------------------------- COPY -------------------------------
    def copy(
        self,
        project_id: str,
        space_id: str,
        document_name: str,
        *,
        target_project_id: Optional[str] = None,
        target_space_id: Optional[str] = None,
        target_document_name: Optional[str] = None,
        remove_outgoing_links: Optional[bool] = None,
        link_original_items_with_role: Optional[str] = None,
        revision: Optional[str] = None,
    ) -> Union[Dict[str, Any], Awaitable[Dict[str, Any]]]:
        """
        Copy a document.

        POST .../documents/{documentName}/actions/copy

        Returns the created (copied) document resource.
        """
        body = CopyDocumentRequestBody(
            target_project_id=target_project_id if target_project_id is not None else UNSET,
            target_space_id=target_space_id if target_space_id is not None else UNSET,
            target_document_name=target_document_name if target_document_name is not None else UNSET,
            remove_outgoing_links=remove_outgoing_links if remove_outgoing_links is not None else UNSET,
            link_original_items_with_role=(
                link_original_items_with_role
                if link_original_items_with_role is not None else UNSET
            ),
        )

        def _extract(resp) -> Dict[str, Any]:
            if resp.status_code in (200, 201) and resp.parsed:
                doc = self._to_dict(resp)
                data = doc.get("data")
                if isinstance(data, list):
                    return data[0] if data else doc
                return data if data else doc
            raise_from_response(resp)

        if self.client.is_async:
            async def _do_async():
                resp = await _copy_document_async(
                    client=self._c,
                    project_id=project_id,
                    space_id=space_id,
                    document_name=document_name,
                    body=body,
                    revision=revision if revision is not None else UNSET,
                )
                return _extract(resp)
            return _do_async()
        else:
            resp = _copy_document(
                client=self._c,
                project_id=project_id,
                space_id=space_id,
                document_name=document_name,
                body=body,
                revision=revision if revision is not None else UNSET,
            )
            return _extract(resp)

    # ---------------------- MERGE FROM MASTER -------------------------
    def merge_from_master(
        self,
        project_id: str,
        space_id: str,
        document_name: str,
        *,
        create_baseline: Optional[bool] = None,
        user_filter: Optional[str] = None,
    ) -> Union[Dict[str, Any], Awaitable[Dict[str, Any]]]:
        """
        Merge a document from the master (async job).

        POST .../documents/{documentName}/actions/mergeFromMaster

        Returns the job resource (status 202).
        """
        body = MergeDocumentRequestBody(
            create_baseline=create_baseline if create_baseline is not None else UNSET,
            user_filter=user_filter if user_filter is not None else UNSET,
        )

        def _extract(resp) -> Dict[str, Any]:
            if resp.status_code == 202 and resp.parsed:
                return self._to_dict(resp)
            raise_from_response(resp)

        if self.client.is_async:
            async def _do_async():
                resp = await _merge_from_master_async(
                    client=self._c,
                    project_id=project_id,
                    space_id=space_id,
                    document_name=document_name,
                    body=body,
                )
                return _extract(resp)
            return _do_async()
        else:
            resp = _merge_from_master(
                client=self._c,
                project_id=project_id,
                space_id=space_id,
                document_name=document_name,
                body=body,
            )
            return _extract(resp)

    # ----------------------- MERGE TO MASTER --------------------------
    def merge_to_master(
        self,
        project_id: str,
        space_id: str,
        document_name: str,
        *,
        create_baseline: Optional[bool] = None,
        user_filter: Optional[str] = None,
    ) -> Union[Dict[str, Any], Awaitable[Dict[str, Any]]]:
        """
        Merge a document to the master (async job).

        POST .../documents/{documentName}/actions/mergeToMaster

        Returns the job resource (status 202).
        """
        body = MergeDocumentRequestBody(
            create_baseline=create_baseline if create_baseline is not None else UNSET,
            user_filter=user_filter if user_filter is not None else UNSET,
        )

        def _extract(resp) -> Dict[str, Any]:
            if resp.status_code == 202 and resp.parsed:
                return self._to_dict(resp)
            raise_from_response(resp)

        if self.client.is_async:
            async def _do_async():
                resp = await _merge_to_master_async(
                    client=self._c,
                    project_id=project_id,
                    space_id=space_id,
                    document_name=document_name,
                    body=body,
                )
                return _extract(resp)
            return _do_async()
        else:
            resp = _merge_to_master(
                client=self._c,
                project_id=project_id,
                space_id=space_id,
                document_name=document_name,
                body=body,
            )
            return _extract(resp)

    # --------------- GET AVAILABLE ENUM OPTIONS -----------------------
    def get_available_enum_options(
        self,
        project_id: str,
        space_id: str,
        document_name: str,
        field_id: str,
        *,
        page_size: Optional[int] = None,
        page_number: Optional[int] = None,
    ) -> Union[Dict[str, Any], Awaitable[Dict[str, Any]]]:
        """
        Get available enum options for a specific field on a document.

        GET .../documents/{documentName}/fields/{fieldId}/actions/getAvailableOptions
        """
        return self._request(
            _get_enum_options,
            _get_enum_options_async,
            project_id=project_id,
            space_id=space_id,
            document_name=document_name,
            field_id=field_id,
            pagesize=page_size if page_size is not None else UNSET,
            pagenumber=page_number if page_number is not None else UNSET,
        )

    # ----------- GET AVAILABLE ENUM OPTIONS FOR TYPE ------------------
    def get_available_enum_options_for_type(
        self,
        project_id: str,
        field_id: str,
        *,
        document_type: Optional[str] = None,
        page_size: Optional[int] = None,
        page_number: Optional[int] = None,
    ) -> Union[Dict[str, Any], Awaitable[Dict[str, Any]]]:
        """
        Get available enum options for a field by document type.

        GET /projects/{projectId}/documents/fields/{fieldId}/actions/getAvailableOptions
        """
        return self._request(
            _get_enum_options_for_type,
            _get_enum_options_for_type_async,
            project_id=project_id,
            field_id=field_id,
            type_=document_type if document_type is not None else UNSET,
            pagesize=page_size if page_size is not None else UNSET,
            pagenumber=page_number if page_number is not None else UNSET,
        )

    # ------------ GET CURRENT ENUM OPTIONS ----------------------------
    def get_current_enum_options(
        self,
        project_id: str,
        space_id: str,
        document_name: str,
        field_id: str,
        *,
        page_size: Optional[int] = None,
        page_number: Optional[int] = None,
        revision: Optional[str] = None,
    ) -> Union[Dict[str, Any], Awaitable[Dict[str, Any]]]:
        """
        Get current enumeration options for a specific field on a document.

        GET .../documents/{documentName}/fields/{fieldId}/actions/getCurrentOptions
        """
        return self._request(
            _get_current_enum_options,
            _get_current_enum_options_async,
            project_id=project_id,
            space_id=space_id,
            document_name=document_name,
            field_id=field_id,
            pagesize=page_size if page_size is not None else UNSET,
            pagenumber=page_number if page_number is not None else UNSET,
            revision=revision if revision is not None else UNSET,
        )

    # -------------------------------------------------------------------
    # TODO: implement when Polarion 25.12 is available
    #       (Requires _get_documents, _get_documents_async to be imported)
    #
    # def list(
    #     self,
    #     project_id: str,
    #     space_id: str,
    #     *,
    #     page_number: int = 1,
    #     page_size: int = 100,
    #     query: Optional[str] = None,
    #     sort: Optional[str] = None,
    #     revision: Optional[str] = None,
    #     fields_documents: Optional[Union[str, List[str]]] = None,
    #     include: Optional[str] = None,
    #     chunk_size: int = 200,
    # ) -> Union[List[Dict[str, Any]], Awaitable[List[Dict[str, Any]]]]:
    #     """
    #     List documents with pagination support.
    #     If page_size=-1, fetches all pages.
    #     """
    #     fields = _build_fields_param_for_documents(fields_documents)
    #     return self._list_items(
    #         _get_documents,
    #         _get_documents_async,
    #         page_param=self._page_param,
    #         size_param=self._size_param,
    #         page_number=page_number,
    #         page_size=page_size,     # -1 => handled client-side
    #         chunk_size=chunk_size,
    #         project_id=project_id,
    #         space_id=space_id,
    #         query=query,
    #         sort=sort,
    #         revision=revision,
    #         fields=fields,
    #         include=include,
    #     )
    #
    # def iter(
    #     self,
    #     project_id: str,
    #     space_id: str,
    #     *,
    #     page_size: int = 100,
    #     query: Optional[str] = None,
    #     sort: Optional[str] = None,
    #     revision: Optional[str] = None,
    #     start_page: int = 1,
    #     fields_documents: Optional[Union[str, List[str]]] = None,
    #     include: Optional[str] = None,
    # ) -> Union[Iterator[Dict[str, Any]], AsyncIterator[Dict[str, Any]]]:
    #     """
    #     Iterate over documents page by page.
    #     """
    #     fields = _build_fields_param_for_documents(fields_documents)
    #     return self._iter_items(
    #         _get_documents,
    #         _get_documents_async,
    #         page_param=(self._page_param if self._page_param else None),
    #         size_param=self._size_param,
    #         page_size=page_size,
    #         start_page=start_page,
    #         project_id=project_id,
    #         space_id=space_id,
    #         query=query,
    #         sort=sort,
    #         revision=revision,
    #         fields=fields,
    #         include=include,
    #     )
    #
    # def find_by_title(
    #     self,
    #     project_id: str,
    #     space_id: str,
    #     title: str,
    #     *,
    #     limit: int = 1,
    #     page_size: int = 100,
    #     start_page: int = 1,
    #     query_via_server: bool = True,
    #     strict_match: bool = False,
    #     fields_documents: Optional[Union[str, List[str]]] = None,
    #     include: Optional[str] = None,
    # ) -> Union[List[Dict[str, Any]], Awaitable[List[Dict[str, Any]]]]:
    #     """
    #     Find documents by title.
    #     """
    #     q = f'title:"{title}"' if query_via_server else None
    #     t_lower = title.lower()
    #
    #     # Ensure we have title field for strict match
    #     eff_fields = fields_documents
    #     if strict_match and not eff_fields:
    #          eff_fields = ["id", "type", "title"]
    #
    #     def _matches(item: Dict[str, Any]) -> bool:
    #         val = str((item.get("attributes") or {}).get("title", "")).lower()
    #         return val == t_lower if strict_match else (t_lower in val)
    #
    #     if self.client.is_async:
    #         async def _do_async():
    #             if page_size == -1:
    #                 items = await self.list(
    #                     project_id, space_id, page_number=start_page, page_size=-1,
    #                     query=q, fields_documents=eff_fields, include=include
    #                 )
    #                 if strict_match:
    #                     items = [x for x in items if _matches(x)]
    #                 return items[:limit] if limit > 0 else items
    #
    #             out = []
    #             async for it in self.iter(
    #                 project_id, space_id, page_size=page_size, start_page=start_page,
    #                 query=q, fields_documents=eff_fields, include=include
    #             ):
    #                 # If server did the query, we trust it unless strict_match is requested
    #                 must_check = strict_match or (not query_via_server)
    #                 if must_check and not _matches(it):
    #                     continue
    #                 out.append(it)
    #                 if 0 < limit <= len(out):
    #                     break
    #             return out
    #         return _do_async()
    #
    #     else:
    #         if page_size == -1:
    #             items = self.list(
    #                 project_id, space_id, page_number=start_page, page_size=-1,
    #                 query=q, fields_documents=eff_fields, include=include
    #             )
    #             if strict_match:
    #                 items = [x for x in items if _matches(x)]
    #             return items[:limit] if limit > 0 else items
    #
    #         out = []
    #         for it in self.iter(
    #             project_id, space_id, page_size=page_size, start_page=start_page,
    #             query=q, fields_documents=eff_fields, include=include
    #         ):
    #             must_check = strict_match or (not query_via_server)
    #             if must_check and not _matches(it):
    #                 continue
    #             out.append(it)
    #             if 0 < limit <= len(out):
    #                 break
    #         return out
    # -------------------------------------------------------------------
