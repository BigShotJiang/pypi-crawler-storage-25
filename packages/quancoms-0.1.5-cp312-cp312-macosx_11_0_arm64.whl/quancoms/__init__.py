from .quancoms import *

__doc__ = quancoms.__doc__
if hasattr(quancoms, "__all__"):
    __all__ = quancoms.__all__