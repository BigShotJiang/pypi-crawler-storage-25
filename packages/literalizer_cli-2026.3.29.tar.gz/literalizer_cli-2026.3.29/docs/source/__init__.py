"""Documentation for ``literalizer-cli``."""
