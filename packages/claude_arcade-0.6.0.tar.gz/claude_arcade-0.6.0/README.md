# claude-arcade

Play mini-games in your terminal while Claude thinks.

Hooks into [Claude Code](https://claude.ai/code) so a game launches automatically every time Claude runs a tool — and disappears the moment it's done. Your terminal is fully restored, nothing is lost.

## Install

```bash
pipx install claude-arcade
```

> `pipx` is recommended so the package gets its own isolated environment.  
> Plain `pip install claude-arcade` works too.

## Quick start

```bash
# 1. One-time setup — writes hooks into ~/.claude/settings.json
claude-arcade setup

# 2. Use Claude Code as normal
claude

# The bird game now appears automatically whenever Claude uses a tool.
# It disappears and restores your terminal when Claude is done.
```

## Play manually

```bash
claude-arcade play        # Bird Hunt (default)
claude-arcade play bird   # same thing
```

## Bird Hunt controls

| Key | Action |
|-----|--------|
| Arrow keys / WASD | Move crosshair |
| `SPACE` | Shoot |
| `Q` | Quit |

Birds fly across the screen at different speeds and are worth different points:

| Bird | Points | Speed |
|------|--------|-------|
| `>->` | 3 | Fast |
| `>~~>` | 1 | Normal |
| `>°~°>` | 2 | Slow |

## Remove hooks

```bash
claude-arcade unsetup
```

## How it works

`claude-arcade setup` adds three hooks to `~/.claude/settings.json`:

- **PreToolUse** → `claude-arcade start` — forks a background process that takes over the terminal alternate screen buffer and runs the game.
- **PostToolUse** + **Stop** → `claude-arcade stop` — signals the game to exit and restores your terminal exactly as you left it.

Because the game runs on the [alternate screen buffer](https://invisible-island.net/xterm/ctlseqs/ctlseqs.html#h3-The-Alternate-Screen-Buffer), all of Claude's output is preserved underneath.

## Requirements

- macOS or Linux
- Python 3.9+
- Claude Code CLI

## License

MIT
