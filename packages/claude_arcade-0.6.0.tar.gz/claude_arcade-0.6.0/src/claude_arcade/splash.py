"""Splash screen + game-picker menu for claude-arcade."""

import curses
from typing import Optional

# ---------------------------------------------------------------------------
# Pixel font — 5 rows × 5 cols, pure █ blocks (works on any terminal)
# ---------------------------------------------------------------------------

_F: dict[str, list[str]] = {
    'A': [" ███ ", "█   █", "█████", "█   █", "█   █"],
    'C': [" ████", "█    ", "█    ", "█    ", " ████"],
    'D': ["███  ", "█  █ ", "█  █ ", "█  █ ", "███  "],
    'E': ["█████", "█    ", "████ ", "█    ", "█████"],
    'L': ["█    ", "█    ", "█    ", "█    ", "█████"],
    'R': ["████ ", "█   █", "████ ", "█ █  ", "█  █ "],
    'U': ["█   █", "█   █", "█   █", "█   █", " ███ "],
    ' ': ["   ", "   ", "   ", "   ", "   "],
}

def _word_rows(word: str) -> list[str]:
    rows = [""] * 5
    for i, ch in enumerate(word.upper()):
        glyph = _F.get(ch, _F[' '])
        for r in range(5):
            rows[r] += glyph[r]
            if i < len(word) - 1:
                rows[r] += " "
    return rows

_CLAUDE = _word_rows("CLAUDE")
_ARCADE = _word_rows("ARCADE")

# ---------------------------------------------------------------------------
# Game registry  (imported by cli.py too)
# ---------------------------------------------------------------------------

GAMES = [
    {
        "name":  "Bird Hunt",
        "key":   "bird",
        "desc":  "Shoot sprite birds flying across the screen",
    },
    {
        "name":  "Pong",
        "key":   "pong",
        "desc":  "Classic paddle battle vs the CPU",
    },
]

# ---------------------------------------------------------------------------
# Menu
# ---------------------------------------------------------------------------

def show_menu(stdscr) -> Optional[str]:
    """Render splash + picker. Returns a game key string, or None to quit."""
    curses.curs_set(0)
    stdscr.keypad(True)
    stdscr.nodelay(False)

    if curses.has_colors():
        curses.start_color()
        curses.use_default_colors()
        curses.init_pair(1, curses.COLOR_YELLOW, -1)   # title
        curses.init_pair(2, curses.COLOR_WHITE,  -1)   # normal item
        curses.init_pair(3, curses.COLOR_BLACK,  curses.COLOR_YELLOW)  # selected
        curses.init_pair(4, curses.COLOR_CYAN,   -1)   # footer / dim
        C_TITLE = curses.color_pair(1) | curses.A_BOLD
        C_SEL   = curses.color_pair(3) | curses.A_BOLD
        C_NORM  = curses.color_pair(2)
        C_DIM   = curses.color_pair(4)
    else:
        C_TITLE = curses.A_BOLD
        C_SEL   = curses.A_REVERSE | curses.A_BOLD
        C_NORM  = curses.A_NORMAL
        C_DIM   = curses.A_DIM

    selected = 0

    while True:
        stdscr.erase()
        h, w = stdscr.getmaxyx()

        title_w = len(_CLAUDE[0])
        tx = max(0, (w - title_w) // 2)

        # ── "CLAUDE" ──
        ty = max(1, (h - 22) // 4)
        for dy, row in enumerate(_CLAUDE):
            if ty + dy < h:
                try:
                    stdscr.addstr(ty + dy, tx, row, C_TITLE)
                except curses.error:
                    pass

        # ── "ARCADE" ──
        ay = ty + 6
        for dy, row in enumerate(_ARCADE):
            if ay + dy < h:
                try:
                    stdscr.addstr(ay + dy, tx, row, C_TITLE)
                except curses.error:
                    pass

        # ── divider ──
        div_y = ay + 6
        div   = "─" * min(title_w + 2, w - 2)
        dtx   = max(0, (w - len(div)) // 2)
        try:
            stdscr.addstr(div_y, dtx, div, C_DIM)
        except curses.error:
            pass

        # ── game list ──
        list_y = div_y + 2
        for i, game in enumerate(GAMES):
            gy = list_y + i * 2
            if gy >= h - 2:
                break
            arrow = "▶" if i == selected else " "
            line  = f"  {arrow}  {game['name']:<14}  {game['desc']}"
            attr  = C_SEL if i == selected else C_NORM
            lx    = max(0, (w - len(line)) // 2)
            try:
                stdscr.addstr(gy, lx, line[: w - 1], attr)
            except curses.error:
                pass

        # ── footer ──
        foot = "↑ ↓  Navigate    Enter  Play    Q  Quit"
        fx   = max(0, (w - len(foot)) // 2)
        try:
            stdscr.addstr(h - 1, fx, foot, C_DIM)
        except curses.error:
            pass

        stdscr.refresh()

        key = stdscr.getch()
        if key in (curses.KEY_UP, ord('k'), ord('K')):
            selected = max(0, selected - 1)
        elif key in (curses.KEY_DOWN, ord('j'), ord('J')):
            selected = min(len(GAMES) - 1, selected + 1)
        elif key in (curses.KEY_ENTER, 10, 13):
            return GAMES[selected]["key"]
        elif key in (ord('q'), ord('Q'), 27):
            return None
        # number shortcuts 1, 2, …
        elif ord('1') <= key <= ord('9'):
            idx = key - ord('1')
            if 0 <= idx < len(GAMES):
                return GAMES[idx]["key"]
