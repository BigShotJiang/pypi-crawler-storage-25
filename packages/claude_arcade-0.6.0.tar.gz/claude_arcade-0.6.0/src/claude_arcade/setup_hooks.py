"""Configure (and remove) Claude Code hooks for claude-arcade."""

import json
import os
import shutil
import sys

SETTINGS_PATH = os.path.expanduser("~/.claude/settings.json")


def _load_settings() -> dict:
    if not os.path.exists(SETTINGS_PATH):
        return {}
    try:
        with open(SETTINGS_PATH) as fh:
            return json.load(fh)
    except (json.JSONDecodeError, OSError) as exc:
        print(f"Warning: could not read {SETTINGS_PATH}: {exc}")
        return {}


def _save_settings(settings: dict) -> None:
    os.makedirs(os.path.dirname(SETTINGS_PATH), exist_ok=True)
    with open(SETTINGS_PATH, "w") as fh:
        json.dump(settings, fh, indent=2)
        fh.write("\n")


def _arcade_bin() -> str:
    path = shutil.which("claude-arcade")
    if not path:
        print("Error: 'claude-arcade' not found in PATH.")
        print("Install it first:  pipx install claude-arcade")
        sys.exit(1)
    return path


def _has_arcade_hook(hook_list: list, bin_path: str) -> bool:
    for entry in hook_list:
        for h in entry.get("hooks", []):
            if bin_path in h.get("command", ""):
                return True
    return False


def setup() -> None:
    """Write claude-arcade hooks into ~/.claude/settings.json."""
    bin_path = _arcade_bin()
    settings = _load_settings()
    settings.setdefault("hooks", {})

    start_entry = {
        "matcher": "",
        "hooks": [{"type": "command", "command": f"{bin_path} start"}],
    }
    stop_entry = {
        "matcher": "",
        "hooks": [{"type": "command", "command": f"{bin_path} stop"}],
    }

    added = []
    for event, entry in [
        ("PreToolUse",  start_entry),
        ("PostToolUse", stop_entry),
        ("Stop",        stop_entry),
    ]:
        settings["hooks"].setdefault(event, [])
        if not _has_arcade_hook(settings["hooks"][event], bin_path):
            settings["hooks"][event].append(entry)
            added.append(event)

    _save_settings(settings)

    if added:
        print(f"claude-arcade hooks added for: {', '.join(added)}")
    else:
        print("claude-arcade hooks were already configured — nothing changed.")

    print()
    print(f"Settings file: {SETTINGS_PATH}")
    print()
    print("How it works:")
    print("  • Start Claude Code as usual:  claude")
    print("  • Whenever Claude calls a tool the bird game launches automatically.")
    print("  • The game closes and your terminal is restored when Claude finishes.")
    print()
    print("Play manually at any time:  claude-arcade play")
    print("Remove hooks:               claude-arcade unsetup")


def unsetup() -> None:
    """Remove claude-arcade hooks from ~/.claude/settings.json."""
    if not os.path.exists(SETTINGS_PATH):
        print("No Claude Code settings file found — nothing to remove.")
        return

    bin_path = _arcade_bin()
    settings = _load_settings()
    removed = []

    for event in ("PreToolUse", "PostToolUse", "Stop"):
        original = settings.get("hooks", {}).get(event, [])
        filtered = [
            e for e in original
            if not _has_arcade_hook([e], bin_path)
        ]
        if len(filtered) < len(original):
            settings["hooks"][event] = filtered
            removed.append(event)

    if removed:
        _save_settings(settings)
        print(f"claude-arcade hooks removed from: {', '.join(removed)}")
    else:
        print("No claude-arcade hooks found — nothing to remove.")
