# py_eq_hash

`py_eq_hash` 是一个 Python 包，用于自定义类的 `__eq__` 和 `__hash__` 方法，允许你指定哪些字段参与对象的比较和哈希计算。

## 安装
```bash
pip install py_eq_hash
```