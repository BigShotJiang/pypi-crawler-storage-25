# setup.py
# -*- coding: utf-8 -*-
from setuptools import setup, find_packages

setup(
    name='py_eq_hash',
    version='0.1.0',
    author='TangWei',
    author_email='454083908@qq.com',
    description='A utility for customizing __eq__ and __hash__ methods in Python classes',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    packages=find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)