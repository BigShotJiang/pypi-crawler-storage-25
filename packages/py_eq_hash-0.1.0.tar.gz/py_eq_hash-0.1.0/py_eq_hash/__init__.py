# custom_eq_hash/__init__.py
from .core import include_in_eq_and_hash, BaseClass