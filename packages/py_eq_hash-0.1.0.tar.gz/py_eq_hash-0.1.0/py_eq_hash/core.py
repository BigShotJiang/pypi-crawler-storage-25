# py_eq_hash/core.py

def include_in_eq_and_hash(field_name):
    def decorator(cls):
        if not hasattr(cls, '__included_fields__'):
            cls.__included_fields__ = []
        cls.__included_fields__.append(field_name)
        return cls
    return decorator


class BaseClass:
    def __eq__(self, other):
        if isinstance(other, type(self)):
            included_fields = getattr(self, '__included_fields__', [])
            return all(getattr(self, field) == getattr(other, field) for field in included_fields)
        return False

    def __hash__(self):
        included_fields = getattr(self, '__included_fields__', [])
        return hash(tuple(getattr(self, field) for field in included_fields))
