# v6ctl

The official CLI for the [v6Node](https://v6node.com) API. Deploy and manage VPS nodes, SSH keys, and webhooks — interactively with Rich tables, or scripted with `--json`.

```bash
pipx install v6ctl
v6ctl config set token v6_...
v6ctl nodes list
```

## Install

```bash
pipx install v6ctl     # recommended — isolated, upgradable
pip install v6ctl      # works too
```

No pipx? `brew install pipx` (macOS), `sudo apt install pipx` (Debian/Ubuntu),
or `python3 -m pip install --user pipx && python3 -m pipx ensurepath`.

## Configure

Get a token from the [v6Node dashboard](https://cloud.v6node.com), then:

```bash
v6ctl config set token v6_...
```

Stored at `~/.config/v6ctl/config.json` with mode `0600`. Or set `V6_TOKEN` in
your environment.

## Recipes

### Deploy a node in one line

```bash
v6ctl nodes create -r frankfurt-2 -p 8gb -k laptop -t debian-13
```

Or run `v6ctl nodes create` on a TTY and answer the prompts. Each of
`--region`, `--plan`, `--key`, `--template` takes an ID, slug, or name —
whichever you remember.

### Add a dedicated IPv4 at deploy

```bash
v6ctl nodes create -r frankfurt-2 -p 8gb -k laptop -t debian-13 \
  --address dedicated_ipv4
```

Pin a specific image build with `--flavor <id>`.

### Inspect a node, including every IP

```bash
v6ctl nodes show <pay-id>
v6ctl nodes list -A          # show all IPs (default truncates to 2)
```

### Manage SSH keys

```bash
v6ctl keys list
v6ctl keys create -d "laptop" -k "ssh-ed25519 AAAA..."
```

### Subscribe a webhook to deploy events

```bash
v6ctl webhooks create -u https://example.com/hook -e node.deployed
```

### Browse the catalog

```bash
v6ctl plans          # plans + pricing
v6ctl regions        # available regions
v6ctl templates      # OS templates and flavors
```

### Script it

```bash
v6ctl --json nodes list | jq '.items[].pay_id'
v6ctl --json plans      | jq '.[] | select(.memory_mb >= 4096)'
```

Every command supports `--json` and exits non-zero on failure. In
non-interactive mode (pipe, CI, or `--json`), prompts are disabled and
missing required flags are an error — so CI fails fast instead of hanging.

`v6ctl --help` and `v6ctl <command> --help` are the source of truth for
every flag.

## Configuration precedence

| Source | Priority |
| --- | --- |
| `--flag` on the command line | 1 (highest) |
| Env vars (`V6_TOKEN`, `V6_API_URL`) | 2 |
| Config file `~/.config/v6ctl/config.json` (mode `0600`) | 3 |
| Built-in defaults | 4 (lowest) |

```bash
v6ctl config show       # resolved config, token redacted
v6ctl config path
v6ctl config set api_url https://cloud.v6node.com/api/v1
v6ctl config unset token
```

## Requirements

Python 3.10 or newer.

## License

MIT — see [LICENSE](LICENSE).
