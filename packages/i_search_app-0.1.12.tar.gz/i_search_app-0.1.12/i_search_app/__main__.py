
import asyncio
import importlib
import sys
from typing import Annotated, Optional, Union
import click
import typer
from typer.core import TyperGroup
from typer_injector import InjectingTyper

from i_search_app.cli.cli_common import TUNNEL_ENV_VAR, isatty, set_color_flag, set_verbosity

from i_search_app.exceptions import (    
    ConnectionFailedError,
    ConnectionFailedToUsbmuxdError,
    ConnectionTerminatedError,
    NoDeviceConnectedError,
    PasswordRequiredError, 
)


CONTEXT_SETTINGS = {"help_option_names": ["-h", "--help"], "max_content_width": 400}
CLI_GROUPS = {
    "backup2": "backup",
}

RECONNECT = False


class Pmd3TyperGroup(TyperGroup):

    def get_command(self, ctx: click.Context, cmd_name: str) -> click.Command:
        if cmd_name not in CLI_GROUPS:
            self.handle_invalid_command(ctx, cmd_name)
        return self.import_and_get_command(ctx, cmd_name)

    @staticmethod
    def import_and_get_command(ctx: click.Context, name: str) -> click.Command:
        module_name = f"i_search_app.cli.{CLI_GROUPS[name]}"
        mod = importlib.import_module(module_name)
        # submodules expose a Typer Group named "cli"
        cli: typer.Typer = mod.cli
        return typer.main.get_command(cli)


app = InjectingTyper(
    cls=Pmd3TyperGroup,
    context_settings=CONTEXT_SETTINGS,
    no_args_is_help=True,
    # add_completion=False,
    rich_markup_mode="markdown",
    help=(""),
)


@app.callback()
def _root(
    reconnect: Annotated[
        bool,
        typer.Option(
            "--reconnect",
            help="Automatically reconnect if the device disconnects mid-command.",
            show_default=False,
        ),
    ] = False,
    verbosity: Annotated[
        int,
        typer.Option(
            "--verbose",
            "-v",
            count=True,
            help="Increase logging verbosity (repeat for more detail).",
        ),
    ] = 0,
    color: Annotated[
        bool,
        typer.Option(help="Colorize output; disable with --no-color for plain logs."),
    ] = True,
) -> None:

    global RECONNECT
    RECONNECT = reconnect
    set_verbosity(verbosity)
    set_color_flag(color)

def invoke_cli_with_error_handling() -> bool:

    
    try:
        try:
            app(standalone_mode=False)
        except click.NoSuchOption as e:
            raise PossiblyMisplacedOption.from_no_such_option(e) from e
    
    except NoDeviceConnectedError:
        logger.error("Device is not connected")
        return True
    except ConnectionTerminatedError:
        logger.error("Connection was terminated abruptly")
        return True
    
   
    return False


def main() -> None:
    while invoke_cli_with_error_handling():
        if not RECONNECT:
            break
        try:
            lockdown = asyncio.run(retry_create_using_usbmux(None))
            asyncio.run(lockdown.close())
        except KeyboardInterrupt:
            print("Aborted.")
            break


if __name__ == "__main__":
    main()
