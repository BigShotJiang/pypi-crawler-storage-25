from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from ugbio_core.logger import logger
from ugbio_core.vcf_utils import VcfField, VcfMetaType

from ugbio_featuremap.featuremap_utils import FeatureMapFields, FeatureMapFilters


class TandemRepeatFields(Enum):
    """Tandem Repeat INFO field names."""

    TR_START = "TR_START"
    TR_END = "TR_END"
    TR_SEQ = "TR_SEQ"
    TR_LENGTH = "TR_LENGTH"
    TR_SEQ_UNIT_LENGTH = "TR_SEQ_UNIT_LENGTH"
    TR_DISTANCE = "TR_DISTANCE"


# =============================================================================
# CONFIGURATIONS
# =============================================================================
@dataclass(frozen=True)
class TandemRepeatConfig:
    """Configuration for Tandem Repeat INFO fields added to VCF during TR annotation.

    Use TandemRepeatFields enum for field name access.
    This class provides VCF metadata (type, description) and helper methods.
    """

    info_fields: tuple[VcfField, ...] = (
        VcfField(TandemRepeatFields.TR_START.value, "1", "Integer", "Closest tandem Repeat Start"),
        VcfField(TandemRepeatFields.TR_END.value, "1", "Integer", "Closest Tandem Repeat End"),
        VcfField(TandemRepeatFields.TR_SEQ.value, "1", "String", "Closest Tandem Repeat Sequence"),
        VcfField(TandemRepeatFields.TR_LENGTH.value, "1", "Integer", "Closest Tandem Repeat total length"),
        VcfField(TandemRepeatFields.TR_SEQ_UNIT_LENGTH.value, "1", "Integer", "Closest Tandem Repeat unit length"),
        VcfField(TandemRepeatFields.TR_DISTANCE.value, "1", "Integer", "Closest Tandem Repeat Distance"),
    )

    def get_bcftools_annotate_columns(self) -> str:
        """Return the columns string for bcftools annotate.

        Format: CHROM,POS,INFO/TR_START,INFO/TR_END,...
        """
        info_cols = ",".join(f"{VcfMetaType.INFO.value}/{field.value}" for field in TandemRepeatFields)
        return f"{FeatureMapFields.CHROM.value},{FeatureMapFields.POS.value},{info_cols}"


@dataclass(frozen=True)
class PileupConfig:
    """Configuration for PILEUP-based ref/nonref calculations.

    PILEUP position mapping: L2→ref0, L1→ref1, C→ref2, R1→ref3, R2→ref4
    Reference column mapping: L2→X_PREV2, L1→X_PREV1, C→REF, R1→X_NEXT1, R2→X_NEXT2
    """

    positions: tuple[str, ...] = ("L2", "L1", "C", "R1", "R2")
    bases: tuple[str, ...] = ("A", "C", "G", "T")
    indels: tuple[str, ...] = ("DEL", "INS")

    def get_reference_column(self, position: str) -> str:
        """Get the reference column name for a given position.

        Parameters
        ----------
        position : str
            PILEUP position (L2, L1, C, R1, or R2).

        Returns
        -------
        str
            Reference column name (X_PREV2, X_PREV1, REF, X_NEXT1, or X_NEXT2).

        Raises
        ------
        ValueError
            If position is not recognized.
        """
        position_to_ref_col = {
            "L2": FeatureMapFields.X_PREV2.value,
            "L1": FeatureMapFields.X_PREV1.value,
            "C": FeatureMapFields.REF.value,
            "R1": FeatureMapFields.X_NEXT1.value,
            "R2": FeatureMapFields.X_NEXT2.value,
        }
        if position not in position_to_ref_col:
            raise ValueError(f"Unknown position: {position}. Expected one of {self.positions}")
        return position_to_ref_col[position]

    def get_column_name(self, element: str, position: str, sample_suffix: str) -> str:
        """Get the full PILEUP column name."""
        return f"PILEUP_{element}_{position}{sample_suffix}"

    def get_all_pileup_format_fields(self) -> set[str]:
        """Get all PILEUP FORMAT field names (without sample suffix)."""
        fields = set()
        for pos in self.positions:
            for base in self.bases:
                fields.add(f"PILEUP_{base}_{pos}")
            for indel in self.indels:
                fields.add(f"PILEUP_{indel}_{pos}")
        return fields


# Singleton instances for use throughout the codebase
TR_CONFIG = TandemRepeatConfig()
PILEUP_CONFIG = PileupConfig()


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================
_MAX_DEBUG_REGION_LINES = 10


def _log_regions_bed_preview(regions_bed_file: Path) -> None:
    """Log a limited preview of regions BED file for debug."""
    preview: list[str] = []
    total = 0
    with open(regions_bed_file) as f:
        for line in f:
            total += 1
            if len(preview) < _MAX_DEBUG_REGION_LINES:
                preview.append(line.strip())
    if preview:
        msg = f"Regions BED preview (first {len(preview)} of {total} regions):"
        logger.debug(f"{msg}\n" + "\n".join(preview))


# =============================================================================
# REQUIRED COLUMNS FOR ML INFERENCE
# These are the columns needed from the VCF to compute the model's expected features.
# =============================================================================

# INFO fields required for inference (includes TR fields added by annotation step)
# X_PREV1, X_PREV2, X_NEXT1, X_NEXT2 are needed for ref/nonref calculations
# X_HMER_REF, X_HMER_ALT are homopolymer length features for model inference
REQUIRED_INFO_FIELDS: set[str] = {
    TandemRepeatFields.TR_DISTANCE.value,
    TandemRepeatFields.TR_LENGTH.value,
    TandemRepeatFields.TR_SEQ_UNIT_LENGTH.value,
    FeatureMapFields.X_PREV1.value,
    FeatureMapFields.X_PREV2.value,
    FeatureMapFields.X_NEXT1.value,
    FeatureMapFields.X_NEXT2.value,
    FeatureMapFields.X_HMER_REF.value,
    FeatureMapFields.X_HMER_ALT.value,
}

# FORMAT fields required for inference (per-sample fields)
# These are used directly or for deriving aggregated features
REQUIRED_FORMAT_FIELDS: set[str] = {
    FeatureMapFields.DP.value,  # Read depth -> t_dp, n_dp
    FeatureMapFields.DP_FILT.value,  # Read depth of reads that pass filters -> t_dp_filt, n_dp_filt
    FeatureMapFields.VAF.value,  # Variant allele frequency -> t_vaf, n_vaf
    FeatureMapFields.RAW_VAF.value,  # Raw VAF -> t_raw_vaf, n_raw_vaf
    FeatureMapFields.AD.value,  # Allelic depths -> AD_1 for alt_reads
    FeatureMapFields.MQUAL.value,  # Mapping quality per read -> mean/min/max aggregations
    FeatureMapFields.SNVQ.value,  # SNV quality per read -> mean/min/max aggregations
    FeatureMapFields.MAPQ.value,  # Mapping quality (for count_zero -> map0_count)
    FeatureMapFields.EDIST.value,  # Edit distance -> mean/min/max aggregations
    FeatureMapFields.RL.value,  # Read length -> mean/min/max aggregations
    FeatureMapFields.DUP.value,  # Duplicate flag -> count_duplicate, count_non_duplicate
    FeatureMapFields.REV.value,  # Reverse strand flag -> reverse_count, forward_count
    FeatureMapFields.FILT.value,  # Filter flag -> pass_alt_reads (FILT count non-zero)
    FeatureMapFields.SCST.value,  # Soft clip start -> scst_num_reads (count non-zero)
    FeatureMapFields.SCED.value,  # Soft clip end -> sced_num_reads (count non-zero)
    # PILEUP columns for ref0-4 / nonref0-4 calculations
    *PILEUP_CONFIG.get_all_pileup_format_fields(),
}

# Sample prefixes for tumor (index 0) and normal (index 1)
TUMOR_PREFIX = "t_"
NORMAL_PREFIX = "n_"

DEFAULT_XGB_PROBA_THRESHOLD = 0.6

XGB_PROBA_INFO_FIELD = VcfField(FeatureMapFields.XGB_PROBA.value, "1", "Float", "XGBoost model predicted probability")

GT_FORMAT_FIELD = VcfField(FeatureMapFields.GT.value, "1", "String", "Genotype", meta_type=VcfMetaType.FORMAT)


def lowqual_filter_header_line(threshold: float) -> str:
    """Generate the LowQual FILTER VCF header line for a given xgb_proba threshold."""
    return (
        f"##FILTER=<ID={FeatureMapFilters.LOW_QUAL.value},"
        f'Description="Low confidence variant below calling threshold (xgb_proba<{threshold}).">'
    )
