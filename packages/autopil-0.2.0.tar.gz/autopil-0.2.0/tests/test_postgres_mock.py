"""
Mock-based tests for autopil/db/postgres.py.

These run without a real Postgres connection by patching psycopg2 at the
pool level. They cover the pure functions and the main CRUD methods of all
four store classes.
"""

import hashlib
from contextlib import contextmanager
from datetime import datetime
from unittest.mock import MagicMock, patch, call

import pytest

from autopil.db.postgres import (
    PostgresAuditLog,
    PostgresKeyStore,
    PostgresTenantStore,
    PostgresPolicyStore,
    PostgresSessionStore,
    _compute_pg_chain_hash,
    _hash,
    KEY_PREFIX,
)
from autopil.models import AuditEvent, Decision

POOL_PATCH = "autopil.db.postgres.psycopg2.pool.ThreadedConnectionPool"

# ── mock helpers ──────────────────────────────────────────────────────────────

def _make_cursor(fetchone=None, fetchall=None, rowcount=1):
    cur = MagicMock()
    cur.fetchone.return_value = fetchone
    cur.fetchall.return_value = fetchall if fetchall is not None else []
    cur.rowcount = rowcount
    return cur


def _make_pool(cursor):
    """Return a mock pool whose connections yield `cursor`."""
    # cursor() returns a context manager
    cur_ctx = MagicMock()
    cur_ctx.__enter__ = lambda s: cursor
    cur_ctx.__exit__ = MagicMock(return_value=False)

    conn = MagicMock()
    conn.cursor.return_value = cur_ctx

    pool = MagicMock()
    pool.getconn.return_value = conn
    return pool


@contextmanager
def _patch_pool(cursor):
    """Patch psycopg2 pool; yield pool mock so callers can assert on it."""
    pool = _make_pool(cursor)
    with patch(POOL_PATCH) as mock_cls:
        mock_cls.return_value = pool
        yield pool, cursor


# ── pure functions ─────────────────────────────────────────────────────────────

def test_hash_is_sha256():
    value = "hello"
    assert _hash(value) == hashlib.sha256(value.encode()).hexdigest()


def test_compute_pg_chain_hash_deterministic():
    event = AuditEvent(
        event_id="evt1", session_id="s1", agent_role="analyst",
        user_id="u1", source_id="src1", query="q",
        decision=Decision.ALLOW, policy_name="p", reason="r",
        timestamp=datetime(2024, 1, 1, 0, 0, 0),
    )
    h1 = _compute_pg_chain_hash("GENESIS", event, "tenant1")
    h2 = _compute_pg_chain_hash("GENESIS", event, "tenant1")
    assert h1 == h2
    assert len(h1) == 64  # SHA-256 hex


def test_compute_pg_chain_hash_changes_with_prev():
    event = AuditEvent(
        event_id="evt1", session_id="s1", agent_role="analyst",
        user_id="u1", source_id="src1", query="q",
        decision=Decision.ALLOW, policy_name="p", reason="r",
        timestamp=datetime(2024, 1, 1),
    )
    h1 = _compute_pg_chain_hash("GENESIS", event, "tenant1")
    h2 = _compute_pg_chain_hash("OTHER",   event, "tenant1")
    assert h1 != h2


# ── PostgresAuditLog._row_to_event (no DB, pure logic) ───────────────────────

def _make_audit_row(**kwargs):
    base = {
        "event_id": "evt1", "session_id": "s1", "agent_role": "analyst",
        "user_id": "u1", "source_id": "reports", "query": "test",
        "decision": "ALLOW", "policy_name": "pol", "reason": "ok",
        "timestamp": datetime(2024, 1, 1), "context_hash": None,
        "sensitivity_level": "medium", "source_type": "rest",
        "catalog_enriched": False, "catalog_connection_id": None,
    }
    base.update(kwargs)
    return base


def test_row_to_event_basic():
    with _patch_pool(_make_cursor()) as _:
        log = PostgresAuditLog("postgresql://fake/db")
    row = _make_audit_row()
    event = log._row_to_event(row)
    assert event.event_id == "evt1"
    assert event.decision == Decision.ALLOW
    assert event.source_type == "rest"


def test_row_to_event_parses_iso_timestamp():
    with _patch_pool(_make_cursor()) as _:
        log = PostgresAuditLog("postgresql://fake/db")
    row = _make_audit_row(timestamp="2024-06-15T12:00:00")
    event = log._row_to_event(row)
    assert event.timestamp == datetime(2024, 6, 15, 12, 0, 0)


def test_row_to_event_defaults_source_type():
    with _patch_pool(_make_cursor()) as _:
        log = PostgresAuditLog("postgresql://fake/db")
    row = _make_audit_row()
    del row["source_type"]
    event = log._row_to_event(row)
    assert event.source_type == "rest"


def test_row_to_event_catalog_enriched():
    with _patch_pool(_make_cursor()) as _:
        log = PostgresAuditLog("postgresql://fake/db")
    row = _make_audit_row(catalog_enriched=True, catalog_connection_id="conn_123")
    event = log._row_to_event(row)
    assert event.catalog_enriched is True
    assert event.catalog_connection_id == "conn_123"


# ── PostgresAuditLog.get_session_owner ────────────────────────────────────────

def test_get_session_owner_found():
    cursor = _make_cursor(fetchone=("analyst",))
    with _patch_pool(cursor):
        log = PostgresAuditLog("postgresql://fake/db")
        result = log.get_session_owner("session_123", "tenant1")
    assert result == "analyst"


def test_get_session_owner_not_found():
    cursor = _make_cursor(fetchone=None)
    with _patch_pool(cursor):
        log = PostgresAuditLog("postgresql://fake/db")
        result = log.get_session_owner("unknown_session", "tenant1")
    assert result is None


# ── PostgresAuditLog.verify_chain ────────────────────────────────────────────

def test_verify_chain_empty_db():
    """No events → valid chain, all zeros."""
    cursor = _make_cursor(fetchall=[])
    with _patch_pool(cursor):
        log = PostgresAuditLog("postgresql://fake/db")
        # Patch get_all_events and _get_chain_anchor to return empty
        log.get_all_events = lambda tenant_id: []
        result = log.verify_chain("tenant1")
    assert result["valid"] is True
    assert result["total"] == 0
    assert result["chained"] == 0


def test_verify_chain_no_events_returns_valid():
    """Empty event list → chain is trivially valid."""
    cursor = _make_cursor(fetchall=[])
    with _patch_pool(cursor):
        log = PostgresAuditLog("postgresql://fake/db")
        log.get_all_events = lambda tenant_id: []
        result = log.verify_chain("tenant1")
    assert result["valid"] is True
    assert result["total"] == 0


# ── PostgresKeyStore.validate ─────────────────────────────────────────────────

def test_validate_wrong_prefix_returns_none():
    cursor = _make_cursor()
    with _patch_pool(cursor):
        ks = PostgresKeyStore("postgresql://fake/db")
        call_count_before = cursor.execute.call_count  # _init_db already called execute
        result = ks.validate("sk-not-the-right-prefix-abc123")
    assert result is None
    # validate() must NOT have issued any new DB calls
    assert cursor.execute.call_count == call_count_before


def test_validate_valid_key():
    cursor = _make_cursor(fetchone=("key_abc", "tenant1", False, "admin"))
    with _patch_pool(cursor):
        ks = PostgresKeyStore("postgresql://fake/db")
        plaintext = KEY_PREFIX + "a" * 48
        result = ks.validate(plaintext)
    assert result == {"key_id": "key_abc", "tenant_id": "tenant1", "is_superadmin": False, "scope": "admin"}


def test_validate_inactive_key_returns_none():
    cursor = _make_cursor(fetchone=None)
    with _patch_pool(cursor):
        ks = PostgresKeyStore("postgresql://fake/db")
        plaintext = KEY_PREFIX + "b" * 48
        result = ks.validate(plaintext)
    assert result is None


# ── PostgresKeyStore.revoke ───────────────────────────────────────────────────

def test_revoke_existing_key_returns_true():
    cursor = _make_cursor(rowcount=1)
    with _patch_pool(cursor):
        ks = PostgresKeyStore("postgresql://fake/db")
        assert ks.revoke("key_abc", "tenant1") is True


def test_revoke_nonexistent_key_returns_false():
    cursor = _make_cursor(rowcount=0)
    with _patch_pool(cursor):
        ks = PostgresKeyStore("postgresql://fake/db")
        assert ks.revoke("missing_key", "tenant1") is False


# ── PostgresKeyStore.count ────────────────────────────────────────────────────

def test_key_store_count_global():
    cursor = _make_cursor(fetchone=(7,))
    with _patch_pool(cursor):
        ks = PostgresKeyStore("postgresql://fake/db")
        assert ks.count() == 7


def test_key_store_count_by_tenant():
    cursor = _make_cursor(fetchone=(3,))
    with _patch_pool(cursor):
        ks = PostgresKeyStore("postgresql://fake/db")
        assert ks.count(tenant_id="tenant1") == 3


# ── PostgresTenantStore.create_tenant ─────────────────────────────────────────

def test_create_tenant_returns_id():
    cursor = _make_cursor()
    with _patch_pool(cursor):
        ts = PostgresTenantStore("postgresql://fake/db")
        tenant_id = ts.create_tenant("my_org")
    assert tenant_id.startswith("ten_")
    assert len(tenant_id) > 4


# ── PostgresTenantStore.count ─────────────────────────────────────────────────

def test_tenant_store_count():
    cursor = _make_cursor(fetchone=(2,))
    with _patch_pool(cursor):
        ts = PostgresTenantStore("postgresql://fake/db")
        assert ts.count() == 2


# ── PostgresTenantStore.deactivate_tenant ─────────────────────────────────────

def test_deactivate_tenant_found():
    cursor = _make_cursor(rowcount=1)
    with _patch_pool(cursor):
        ts = PostgresTenantStore("postgresql://fake/db")
        assert ts.deactivate_tenant("tenant1") is True


def test_deactivate_tenant_not_found():
    cursor = _make_cursor(rowcount=0)
    with _patch_pool(cursor):
        ts = PostgresTenantStore("postgresql://fake/db")
        assert ts.deactivate_tenant("ghost") is False


# ── PostgresTenantStore.get_tenant ────────────────────────────────────────────

def test_get_tenant_found():
    fake_row = {
        "tenant_id": "ten_abc", "name": "acme",
        "created_at": datetime(2024, 1, 1), "is_active": True,
    }
    cursor = _make_cursor(fetchone=fake_row)
    with _patch_pool(cursor):
        ts = PostgresTenantStore("postgresql://fake/db")
        result = ts.get_tenant("ten_abc")
    assert result["tenant_id"] == "ten_abc"
    assert result["name"] == "acme"
    assert result["is_active"] is True


def test_get_tenant_not_found():
    cursor = _make_cursor(fetchone=None)
    with _patch_pool(cursor):
        ts = PostgresTenantStore("postgresql://fake/db")
        result = ts.get_tenant("unknown")
    assert result is None


# ── PostgresPolicyStore.upsert ────────────────────────────────────────────────

def test_policy_upsert_insert_new():
    """When no existing policy, INSERT path runs and returns a new policy_id."""
    cursor = _make_cursor(fetchone=None)
    with _patch_pool(cursor):
        ps = PostgresPolicyStore("postgresql://fake/db")
        policy_id = ps.upsert(
            {"name": "analyst_policy", "agent_role": "analyst", "allowed_sources": ["reports"]},
            tenant_id="tenant1",
        )
    assert policy_id.startswith("pol_")


def test_policy_upsert_update_existing():
    """When existing policy found and content differs, UPDATE path runs."""
    # fetchone returns all 10 fields now that upsert does a content diff.
    # Stored agent_role ('old_role') differs from incoming ('analyst') so update triggers.
    cursor = _make_cursor(fetchone=(
        "pol_existing", 1, "old_role", "[]", "[]", "high", "[]", "[]", None, None,
    ))
    with _patch_pool(cursor):
        ps = PostgresPolicyStore("postgresql://fake/db")
        policy_id = ps.upsert(
            {"name": "analyst_policy", "agent_role": "analyst"},
            tenant_id="tenant1",
        )
    assert policy_id == "pol_existing"


# ── KEY_PREFIX constant ───────────────────────────────────────────────────────

def test_key_prefix_value():
    assert KEY_PREFIX == "apl_"


# ── PostgresSessionStore ─────────────────────────────────────────────────────

def test_session_create_no_ttl():
    """create_session with no TTL runs INSERT with NULL expires_at."""
    cursor = _make_cursor()
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        ss.create_session("sid1", "analyst", "u1", "tenant1")
    # The INSERT should have been called (cursor.execute called multiple times
    # during _init_db + create_session; the last call is the INSERT)
    assert cursor.execute.called


def test_session_create_with_ttl():
    """create_session with ttl_minutes passes numeric args to the INTERVAL expression."""
    cursor = _make_cursor()
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        ss.create_session("sid1", "analyst", "u1", "tenant1", ttl_minutes=60)
    calls = cursor.execute.call_args_list
    insert_call = next(
        (c for c in calls if "INSERT INTO sessions" in str(c)), None
    )
    assert insert_call is not None
    args = insert_call[0][1]   # positional args tuple passed to execute
    # ttl_minutes=60 → "60" appears twice (CASE WHEN condition + INTERVAL) + 60 at end
    assert "60" in args
    assert 60 in args


def test_session_get_returns_none_when_missing():
    """get_session returns None when fetchone returns None."""
    cursor = _make_cursor(fetchone=None)
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        result = ss.get_session("nonexistent", "tenant1")
    assert result is None


def test_session_get_returns_dict():
    """get_session maps RealDictCursor row to a plain dict."""
    from datetime import timezone
    now = datetime(2026, 4, 4, 10, 0, 0, tzinfo=timezone.utc)
    row = {
        "session_id":   "sid1",
        "tenant_id":    "tenant1",
        "agent_role":   "analyst",
        "user_id":      "u1",
        "created_at":   now,
        "last_active":  now,
        "expires_at":        None,
        "ttl_minutes":       None,
        "is_revoked":        False,
        "context_hash":      None,
        "revocation_reason": None,
        "revoked_at":        None,
    }
    cursor = _make_cursor(fetchone=row)
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        result = ss.get_session("sid1", "tenant1")
    assert result["session_id"] == "sid1"
    assert result["agent_role"] == "analyst"
    assert result["is_revoked"] is False
    assert result["expires_at"] is None


def test_session_touch_correct_owner():
    """touch_session runs an UPDATE including agent_role in the WHERE clause."""
    cursor = _make_cursor(rowcount=1)
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        result = ss.touch_session("sid1", "tenant1", "analyst")
    assert result is True
    calls = cursor.execute.call_args_list
    update_call = next((c for c in calls if "UPDATE sessions SET last_active" in str(c)), None)
    assert update_call is not None
    assert "analyst" in str(update_call)


def test_session_touch_wrong_owner_returns_false():
    """touch_session returns False when agent_role doesn't match (rowcount=0)."""
    cursor = _make_cursor(rowcount=0)
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        result = ss.touch_session("sid1", "tenant1", "rogue_agent")
    assert result is False


def test_session_revoke_returns_true():
    """revoke_session returns True when rowcount > 0."""
    cursor = _make_cursor(rowcount=1)
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        result = ss.revoke_session("sid1", "tenant1")
    assert result is True


def test_session_revoke_returns_false_when_not_found():
    """revoke_session returns False when rowcount == 0 (session not found)."""
    cursor = _make_cursor(rowcount=0)
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        result = ss.revoke_session("missing", "tenant1")
    assert result is False


def test_session_revoke_writes_reason_and_revoked_at():
    """revoke_session passes reason and NOW() into the UPDATE statement."""
    cursor = _make_cursor(rowcount=1)
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        ss.revoke_session("sid1", "tenant1", reason="fraud_detected")
    calls = cursor.execute.call_args_list
    update_call = next((c for c in calls if "UPDATE sessions" in str(c)), None)
    assert update_call is not None
    sql, params = update_call[0]
    assert "revocation_reason" in sql
    assert "revoked_at" in sql
    assert "fraud_detected" in params


def test_session_revoke_default_reason_is_admin_action():
    """revoke_session defaults to admin_action when reason is not supplied."""
    cursor = _make_cursor(rowcount=1)
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        ss.revoke_session("sid1", "tenant1")
    calls = cursor.execute.call_args_list
    update_call = next((c for c in calls if "UPDATE sessions" in str(c)), None)
    assert update_call is not None
    _, params = update_call[0]
    assert "admin_action" in params


def test_revoke_sessions_by_writes_reason():
    """revoke_sessions_by includes revocation_reason and revoked_at in the UPDATE."""
    cursor = _make_cursor(rowcount=2)
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        ss.revoke_sessions_by("tenant1", agent_role="analyst", reason="policy_violation")
    calls = cursor.execute.call_args_list
    update_call = next((c for c in calls if "UPDATE sessions" in str(c)), None)
    assert update_call is not None
    sql, params = update_call[0]
    assert "revocation_reason" in sql
    assert "policy_violation" in params


def test_session_list_active_only():
    """list_sessions without include_expired uses the filtered WHERE clause."""
    cursor = _make_cursor(fetchall=[])
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        ss.list_sessions("tenant1", include_expired=False)
    calls = cursor.execute.call_args_list
    list_call = next((c for c in calls if "SELECT session_id" in str(c) and "is_revoked" in str(c)), None)
    assert list_call is not None
    assert "expires_at > NOW()" in str(list_call)


def test_session_list_include_expired():
    """list_sessions with include_expired=True uses the unfiltered SELECT."""
    cursor = _make_cursor(fetchall=[])
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        ss.list_sessions("tenant1", include_expired=True)
    calls = cursor.execute.call_args_list
    list_call = next((c for c in calls if "SELECT session_id" in str(c)), None)
    assert list_call is not None
    assert "is_revoked = FALSE" not in str(list_call)


def test_session_is_valid_not_found():
    """is_valid returns (False, 'session_not_found') when get_session returns None."""
    cursor = _make_cursor(fetchone=None)
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        valid, reason = ss.is_valid("nonexistent", "tenant1")
    assert valid is False
    assert reason == "session_not_found"


def test_session_is_valid_revoked():
    """is_valid returns (False, 'session_revoked') for a revoked session."""
    from datetime import timezone
    now = datetime(2026, 4, 4, 10, 0, 0, tzinfo=timezone.utc)
    row = {
        "session_id": "sid1", "tenant_id": "tenant1", "agent_role": "analyst",
        "user_id": "u1", "created_at": now, "last_active": now,
        "expires_at": None, "ttl_minutes": None, "is_revoked": True, "context_hash": None,
        "revocation_reason": "fraud_detected", "revoked_at": now,
    }
    cursor = _make_cursor(fetchone=row)
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        valid, reason = ss.is_valid("sid1", "tenant1")
    assert valid is False
    assert reason == "session_revoked"


def test_session_is_valid_expired():
    """is_valid returns (False, 'session_expired') when expires_at is in the past."""
    from datetime import timezone, timedelta
    past = datetime(2020, 1, 1, tzinfo=timezone.utc)
    row = {
        "session_id": "sid1", "tenant_id": "tenant1", "agent_role": "analyst",
        "user_id": "u1", "created_at": past, "last_active": past,
        "expires_at": past, "ttl_minutes": 60, "is_revoked": False, "context_hash": None,
        "revocation_reason": None, "revoked_at": None,
    }
    cursor = _make_cursor(fetchone=row)
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        valid, reason = ss.is_valid("sid1", "tenant1")
    assert valid is False
    assert reason == "session_expired"


def test_session_is_valid_active():
    """is_valid returns (True, '') for a non-revoked, non-expired session."""
    from datetime import timezone, timedelta
    future = datetime(2099, 1, 1, tzinfo=timezone.utc)
    row = {
        "session_id": "sid1", "tenant_id": "tenant1", "agent_role": "analyst",
        "user_id": "u1",
        "created_at": datetime(2026, 4, 4, tzinfo=timezone.utc),
        "last_active": datetime(2026, 4, 4, tzinfo=timezone.utc),
        "expires_at": future, "ttl_minutes": 60, "is_revoked": False, "context_hash": None,
        "revocation_reason": None, "revoked_at": None,
    }
    cursor = _make_cursor(fetchone=row)
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        valid, reason = ss.is_valid("sid1", "tenant1")
    assert valid is True
    assert reason == ""


def test_session_is_valid_no_expiry():
    """is_valid returns (True, '') when expires_at is None (no TTL)."""
    from datetime import timezone
    now = datetime(2026, 4, 4, tzinfo=timezone.utc)
    row = {
        "session_id": "sid1", "tenant_id": "tenant1", "agent_role": "analyst",
        "user_id": "u1", "created_at": now, "last_active": now,
        "expires_at": None, "ttl_minutes": None, "is_revoked": False, "context_hash": None,
        "revocation_reason": None, "revoked_at": None,
    }
    cursor = _make_cursor(fetchone=row)
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        valid, reason = ss.is_valid("sid1", "tenant1")
    assert valid is True
    assert reason == ""


# ── revoke_sessions_by ────────────────────────────────────────────────────────

def test_revoke_sessions_by_agent_role_issues_update():
    """revoke_sessions_by with agent_role builds WHERE with tenant + role + is_revoked."""
    cursor = _make_cursor(rowcount=3)
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        count = ss.revoke_sessions_by("tenant1", agent_role="analyst")
    assert count == 3
    calls = cursor.execute.call_args_list
    update_call = next((c for c in calls if "UPDATE sessions" in str(c)), None)
    assert update_call is not None
    sql = update_call[0][0]
    assert "is_revoked = TRUE" in sql
    assert "agent_role = %s" in sql
    assert "tenant_id = %s" in sql


def test_revoke_sessions_by_user_id_issues_update():
    """revoke_sessions_by with user_id includes user_id in WHERE clause."""
    cursor = _make_cursor(rowcount=2)
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        count = ss.revoke_sessions_by("tenant1", user_id="alice")
    assert count == 2
    calls = cursor.execute.call_args_list
    update_call = next((c for c in calls if "UPDATE sessions" in str(c)), None)
    assert update_call is not None
    sql = update_call[0][0]
    assert "user_id = %s" in sql


def test_revoke_sessions_by_both_filters_includes_both_clauses():
    """Both agent_role and user_id appear in the WHERE when both are supplied."""
    cursor = _make_cursor(rowcount=1)
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        count = ss.revoke_sessions_by("tenant1", agent_role="analyst", user_id="alice")
    assert count == 1
    calls = cursor.execute.call_args_list
    update_call = next((c for c in calls if "UPDATE sessions" in str(c)), None)
    assert update_call is not None
    sql = update_call[0][0]
    assert "agent_role = %s" in sql
    assert "user_id = %s" in sql


def test_revoke_sessions_by_no_filters_raises():
    """revoke_sessions_by raises ValueError when neither filter is provided."""
    cursor = _make_cursor()
    with _patch_pool(cursor):
        ss = PostgresSessionStore("postgresql://fake/db")
        with pytest.raises(ValueError, match="At least one"):
            ss.revoke_sessions_by("tenant1")
