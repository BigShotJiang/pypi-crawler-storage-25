"""
Tests for autopil/db/__init__.py — create_stores() factory.

Covers the Postgres branch (lines 25-28) using a mocked psycopg2 pool.
The SQLite branch is already heavily covered by the rest of the test suite.
"""

from unittest.mock import MagicMock, patch

import pytest

POOL_PATCH = "autopil.db.postgres.psycopg2.pool.ThreadedConnectionPool"


def _make_pool():
    """Return a mock psycopg2 pool whose connections do nothing."""
    cursor = MagicMock()
    cursor.fetchone.return_value = (1,)
    cursor.fetchall.return_value = []
    cursor.rowcount = 0

    cur_ctx = MagicMock()
    cur_ctx.__enter__ = lambda s: cursor
    cur_ctx.__exit__ = MagicMock(return_value=False)

    conn = MagicMock()
    conn.cursor.return_value = cur_ctx

    pool = MagicMock()
    pool.getconn.return_value = conn
    return pool


# ── create_stores with database_url → Postgres branch ────────────────────────

def test_create_stores_postgres_returns_8_tuple():
    from autopil.db import create_stores

    pool = _make_pool()
    with patch(POOL_PATCH) as mock_cls:
        mock_cls.return_value = pool
        stores = create_stores(database_url="postgresql://fake/db")

    assert len(stores) == 8


def test_create_stores_postgres_correct_types():
    from autopil.db import create_stores
    from autopil.db.postgres import (
        PostgresAuditLog,
        PostgresAlertStore,
        PostgresKeyStore,
        PostgresPolicyStore,
        PostgresSessionStore,
        PostgresTenantStore,
    )
    from autopil.db.sqlite import (
        SQLiteAgentRegistryStore,
        SQLiteLineageStore,
    )

    pool = _make_pool()
    with patch(POOL_PATCH) as mock_cls:
        mock_cls.return_value = pool
        audit, keys, tenants, policies, alerts, lineage, sessions, agents = create_stores(
            database_url="postgresql://fake/db"
        )

    assert isinstance(audit,    PostgresAuditLog)
    assert isinstance(keys,     PostgresKeyStore)
    assert isinstance(tenants,  PostgresTenantStore)
    assert isinstance(policies, PostgresPolicyStore)
    assert isinstance(alerts,   PostgresAlertStore)
    assert isinstance(lineage,  SQLiteLineageStore)
    assert isinstance(sessions, PostgresSessionStore)
    assert isinstance(agents,   SQLiteAgentRegistryStore)


def test_create_stores_sqlite_returns_8_tuple(tmp_path):
    from autopil.db import create_stores

    db = str(tmp_path / "test.db")
    stores = create_stores(db_path=db)
    assert len(stores) == 8


def test_create_stores_sqlite_correct_types(tmp_path):
    from autopil.db import create_stores
    from autopil.db.sqlite import (
        SQLiteAuditLog,
        SQLiteAlertStore,
        SQLiteAgentRegistryStore,
        SQLiteKeyStore,
        SQLiteLineageStore,
        SQLitePolicyStore,
        SQLiteSessionStore,
        SQLiteTenantStore,
    )

    db = str(tmp_path / "test.db")
    audit, keys, tenants, policies, alerts, lineage, sessions, agents = create_stores(db_path=db)

    assert isinstance(audit,    SQLiteAuditLog)
    assert isinstance(keys,     SQLiteKeyStore)
    assert isinstance(tenants,  SQLiteTenantStore)
    assert isinstance(policies, SQLitePolicyStore)
    assert isinstance(alerts,   SQLiteAlertStore)
    assert isinstance(lineage,  SQLiteLineageStore)
    assert isinstance(sessions, SQLiteSessionStore)
    assert isinstance(agents,   SQLiteAgentRegistryStore)
