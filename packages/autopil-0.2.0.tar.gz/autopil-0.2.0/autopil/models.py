from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional
import uuid


class Decision(str, Enum):
    ALLOW = "ALLOW"
    DENY = "DENY"


class KeyScope(str, Enum):
    ADMIN    = "admin"     # full access — all endpoints
    READ     = "read"      # GET endpoints + POST /v1/context/evaluate
    EVALUATE = "evaluate"  # POST /v1/context/evaluate only


class SensitivityLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    RESTRICTED = "restricted"


SENSITIVITY_ORDER = ["low", "medium", "high", "restricted"]


@dataclass
class ContextRequest:
    query: str
    agent_role: str
    user_id: str
    source_id: str
    sensitivity_level: SensitivityLevel = SensitivityLevel.MEDIUM
    session_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = field(default_factory=datetime.utcnow)
    task_type: Optional[str] = None
    session_age_minutes: Optional[int] = None  # elapsed minutes since session created_at; None skips decay


@dataclass
class AgentAction:
    action_id:     str
    event_id:      str          # links to AuditEvent that drove this action
    session_id:    str
    agent_role:    str
    action_type:   str          # e.g. "loan_decision", "tool_call", "response"
    action_detail: dict
    timestamp:     datetime
    outcome:       Optional[str] = None


@dataclass
class AgentRegistryEntry:
    agent_id:     str
    tenant_id:    str
    agent_role:   str
    display_name: str
    status:       str                    # draft | pending_approval | approved | deprecated
    version:      str
    created_at:   datetime
    updated_at:   datetime
    description:  Optional[str] = None
    owner:        Optional[str] = None
    framework:    Optional[str] = None   # langgraph | openai_agents | langchain | etc.
    policy_name:  Optional[str] = None
    created_by:   Optional[str] = None
    approved_by:  Optional[str] = None
    approved_at:  Optional[datetime] = None


@dataclass
class AuditEvent:
    event_id: str
    session_id: str
    agent_role: str
    user_id: str
    source_id: str
    query: str
    decision: Decision
    policy_name: str
    reason: str
    timestamp: datetime
    context_hash: Optional[str] = None
    sensitivity_level: Optional[str] = None   # low | medium | high | restricted
    source_type: str = "rest"                  # rest | mcp | sdk
    catalog_enriched: bool = False
    catalog_connection_id: Optional[str] = None
