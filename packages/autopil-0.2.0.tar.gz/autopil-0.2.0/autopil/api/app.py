"""
AutoPIL REST API
================
All /v1/* routes are tenant-scoped — the tenant is resolved from the API key.
Superadmin routes at /v1/admin/* require a key with is_superadmin=True.

Endpoints:
  POST   /v1/context/evaluate             — evaluate a context request
  GET    /v1/audit/sessions/{id}          — audit trail for a session
  GET    /v1/audit/events                 — all events for this tenant
  GET    /v1/audit/export                 — export audit events as CSV or JSON
  POST   /v1/audit/lineage               — record an agent action linked to an audit event
  GET    /v1/audit/lineage/{event_id}    — retrieve event + all downstream actions (full lineage)
  GET    /v1/audit/stats                  — dashboard stats for this tenant
  GET    /v1/policies                     — loaded policies (DB or YAML fallback)
  POST   /v1/policies/reload              — reload YAML into DB, skipping user-modified policies
  POST   /v1/policies/{name}/restore      — restore a single policy from YAML, clearing user_modified
  POST   /v1/policies                     — create a policy
  PUT    /v1/policies/{name}              — update a policy (saves version, sets user_modified)
  DELETE /v1/policies/{name}              — delete a policy
  GET    /v1/policies/{name}/history      — version history for a policy
  POST   /v1/alerts/rules                 — create alert rule
  GET    /v1/alerts/rules                 — list alert rules
  PUT    /v1/alerts/rules/{rule_id}       — update alert rule
  DELETE /v1/alerts/rules/{rule_id}       — delete alert rule
  GET    /v1/alerts/fired                 — recent alert deliveries
  POST   /v1/keys                         — create API key for this tenant
  GET    /v1/keys                         — list keys for this tenant
  DELETE /v1/keys/{key_id}               — revoke a key
  POST   /v1/admin/tenants               — create tenant (superadmin)
  GET    /v1/admin/tenants               — list all tenants (superadmin)
  DELETE /v1/admin/tenants/{id}          — deactivate tenant (superadmin)
  GET    /v1/sessions                   — list active sessions for this tenant
  GET    /v1/sessions/{id}             — session status (active/expired/revoked)
  DELETE /v1/sessions/{id}            — revoke a session immediately
  DELETE /v1/sessions                  — bulk revoke by agent_role and/or user_id
  GET    /health                         — liveness check (no auth)
"""

import csv
import io
import os
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

import yaml
from fastapi import Depends, FastAPI, HTTPException, Query, Request, Security
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.security import APIKeyHeader
from fastapi.staticfiles import StaticFiles

from autopil.alerting import AlertEngine
from autopil.db import create_stores
from autopil.models import AgentAction, AgentRegistryEntry, AuditEvent, ContextRequest, Decision
from autopil.policy_engine import PolicyEngine
from autopil.session_cleanup import SessionCleanupJob
from autopil import telemetry

from .schemas import (
    AgentActionResponse,
    AgentRegistryEntryResponse,
    RevocationReason,
    AgentRegistryStatsResponse,
    AlertDeliveryResponse,
    AlertRuleResponse,
    AuditEventResponse,
    AuditRetentionResponse,
    AuditTrailResponse,
    ChainVerifyResponse,
    CreateAlertRuleRequest,
    CreateKeyRequest,
    CreateKeyResponse,
    CreatePolicyRequest,
    CreateTenantRequest,
    CreateTenantResponse,
    EvaluateRequest,
    EvaluateResponse,
    HealthResponse,
    KeySummary,
    LineageResponse,
    PolicyDetailResponse,
    PolicyVersionResponse,
    QuickstartRunRequest,
    QuickstartRunResponse,
    QuickstartStatusResponse,
    RecordActionRequest,
    RegisterAgentRequest,
    RotateKeyResponse,
    SessionResponse,
    TenantResponse,
    UpdateAgentRequest,
    UpdateAgentStatusRequest,
    UpdateAlertRuleRequest,
    UpdatePolicyRequest,
)

STATIC_DIR = Path(__file__).parent / "static"

_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


def _load_yaml_policies(path: str) -> list:
    """Load policies from a single YAML file or every *.yaml in a directory tree."""
    p = Path(path)
    files = sorted(p.glob("**/*.yaml")) if p.is_dir() else [p]
    policies = []
    for f in files:
        with open(f) as fh:
            data = yaml.safe_load(fh)
        parts = f.relative_to(p).parts if p.is_dir() else ()
        industry = parts[0] if len(parts) >= 2 else None
        category = Path(parts[1]).stem if len(parts) >= 2 else (Path(parts[0]).stem if len(parts) == 1 else None)
        for pol in data.get("policies", []):
            pol.setdefault("industry", industry)
            pol.setdefault("category", category)
            policies.append(pol)
    return policies


def create_app(
    policy_path: str,
    audit_db: str = "autopil_audit.db",
    database_url: str | None = None,
    session_ttl_minutes: int | None = None,
    session_retention_days: int | None = None,
    session_cleanup_interval: int = 3600,
) -> FastAPI:
    app = FastAPI(
        title="AutoPIL",
        description="Platform Intelligence Layer — context governance for autonomous agents",
        version="0.1.0",
        docs_url="/docs",
        redoc_url="/redoc",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    telemetry.setup()

    # ── shared state ─────────────────────────────────────────────────────────
    (audit_log, key_store, tenant_store, policy_store, alert_store,
     lineage_store, session_store, agent_registry_store) = create_stores(
        database_url=database_url, db_path=audit_db
    )
    alert_engine = AlertEngine(alert_store, audit_log)
    state = {
        "policy_path":           policy_path,
        "audit_db":              database_url or audit_db,
        "engine":                PolicyEngine(policy_path),
        "log":                   audit_log,
        "keys":                  key_store,
        "tenants":               tenant_store,
        "policy_store":          policy_store,
        "alert_store":           alert_store,
        "alert_engine":          alert_engine,
        "lineage_store":         lineage_store,
        "session_store":         session_store,
        "agent_registry_store":  agent_registry_store,
        "session_ttl_minutes":   session_ttl_minutes,
    }

    # ── session cleanup background job ───────────────────────────────────────
    if session_retention_days is not None:
        _cleanup_job = SessionCleanupJob(
            session_store,
            retention_days=session_retention_days,
            interval_seconds=session_cleanup_interval,
        )
        _cleanup_job.start()

    # ── auth dependencies ─────────────────────────────────────────────────────

    def require_api_key(request: Request, raw: str = Security(_api_key_header)) -> dict:
        if not raw:
            raise HTTPException(status_code=401, detail="Missing API key. Set X-API-Key header.")
        info = state["keys"].validate(raw)
        if not info:
            raise HTTPException(status_code=403, detail="Invalid or revoked API key.")
        scope = info.get("scope", "admin")
        method = request.method
        path = request.url.path
        is_evaluate = method == "POST" and path == "/v1/context/evaluate"
        if scope == "evaluate" and not is_evaluate:
            raise HTTPException(
                status_code=403,
                detail="This key is restricted to POST /v1/context/evaluate only.",
            )
        if scope == "read" and method not in {"GET", "HEAD", "OPTIONS"} and not is_evaluate:
            raise HTTPException(
                status_code=403,
                detail="This key is read-only. Write operations require an admin-scoped key.",
            )
        return info  # {"key_id", "tenant_id", "is_superadmin", "scope"}

    def require_superadmin(key_info: dict = Depends(require_api_key)) -> dict:
        if not key_info.get("is_superadmin"):
            raise HTTPException(status_code=403, detail="Superadmin key required.")
        return key_info

    # ── policy engine helper ──────────────────────────────────────────────────

    def _get_engine(tenant_id: str) -> PolicyEngine:
        db_policies = state["policy_store"].list_active(tenant_id)
        if db_policies:
            return PolicyEngine.from_list(db_policies)
        return state["engine"]

    # ── dashboard ─────────────────────────────────────────────────────────────

    @app.get("/", include_in_schema=False)
    def dashboard():
        return FileResponse(str(STATIC_DIR / "index.html"))

    # ── health ────────────────────────────────────────────────────────────────

    @app.get("/health", response_model=HealthResponse, tags=["System"])
    def health():
        return HealthResponse(
            status="ok", version="0.1.0",
            git_sha=(os.environ.get("RENDER_GIT_COMMIT") or os.environ.get("GIT_SHA", ""))[:7] or None,
            policy_file=state["policy_path"], audit_db=state["audit_db"],
        )

    # ── quickstart ────────────────────────────────────────────────────────────

    # Embedded policy — no YAML file required. Demonstrates allow vs deny clearly.
    _QUICKSTART_POLICIES = [
        {
            "name": "quickstart_analyst_policy",
            "agent_role": "analyst",
            "allowed_sources": ["customer_data", "transaction_history", "audit_logs"],
            "denied_sources":  ["pii_vault", "model_weights", "raw_credentials"],
            "max_sensitivity": "high",
        },
        {
            "name": "quickstart_compliance_policy",
            "agent_role": "compliance_bot",
            "allowed_sources": ["audit_logs", "compliance_reports", "transaction_history"],
            "denied_sources":  ["customer_data", "pii_vault", "model_weights"],
            "max_sensitivity": "restricted",
        },
    ]
    _quickstart_engine = PolicyEngine.from_list(_QUICKSTART_POLICIES)

    @app.get("/v1/quickstart/status", response_model=QuickstartStatusResponse, tags=["Quickstart"])
    def quickstart_status(key_info: dict = Depends(require_api_key)):
        """Return whether this tenant has completed the quickstart and how old the tenant is."""
        tenant_id = key_info["tenant_id"]
        tenant = state["tenants"].get_tenant(tenant_id)
        if tenant and tenant.get("created_at"):
            from datetime import timezone
            created = datetime.fromisoformat(tenant["created_at"])
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            age_days = (datetime.now(timezone.utc) - created).days
        else:
            age_days = 0
        events = state["log"].get_all_events(tenant_id=tenant_id)
        completed = any(
            getattr(e, "query", "").startswith("quickstart:") for e in events
        )
        return QuickstartStatusResponse(completed=completed, tenant_age_days=age_days)

    @app.post("/v1/quickstart/run", response_model=QuickstartRunResponse, tags=["Quickstart"])
    def quickstart_run(req: QuickstartRunRequest, key_info: dict = Depends(require_api_key)):
        """Evaluate a request against the built-in quickstart policy and record the event."""
        from autopil.models import ContextRequest, SensitivityLevel as SL
        tenant_id  = key_info["tenant_id"]
        session_id = str(uuid.uuid4())
        cr = ContextRequest(
            query=f"quickstart: access {req.source_id}",
            agent_role=req.agent_role,
            user_id="quickstart_user",
            source_id=req.source_id,
            sensitivity_level=req.sensitivity_level,
            session_id=session_id,
        )
        decision, policy_name, reason = _quickstart_engine.evaluate(cr)
        event = AuditEvent(
            event_id=str(uuid.uuid4()), session_id=session_id,
            agent_role=req.agent_role, user_id="quickstart_user",
            source_id=req.source_id,
            query=cr.query, decision=decision, policy_name=policy_name,
            reason=reason, timestamp=datetime.utcnow(),
            sensitivity_level=req.sensitivity_level.value,
            source_type="rest",
        )
        state["log"].record(event, tenant_id=tenant_id)
        return QuickstartRunResponse(
            decision=decision, policy_name=policy_name, reason=reason,
            event_id=event.event_id, allowed=(decision.value == "ALLOW"),
        )

    # ── tenant management (superadmin only) ───────────────────────────────────

    @app.post("/v1/admin/tenants", response_model=CreateTenantResponse, tags=["Admin"])
    def create_tenant(req: CreateTenantRequest, _: dict = Depends(require_superadmin)):
        """Create a new tenant and return its initial admin API key."""
        try:
            tenant_id = state["tenants"].create_tenant(req.name)
        except Exception as exc:
            if "UNIQUE" in str(exc).upper() or "unique" in str(exc).lower():
                raise HTTPException(status_code=409, detail=f"Tenant name '{req.name}' already exists.")
            raise
        _, admin_key = state["keys"].create_key("admin", tenant_id=tenant_id)
        tenant = state["tenants"].get_tenant(tenant_id)
        return CreateTenantResponse(
            tenant_id=tenant_id,
            name=req.name,
            created_at=tenant["created_at"],
            admin_key=admin_key,
        )

    @app.get("/v1/admin/tenants", response_model=list[TenantResponse], tags=["Admin"])
    def list_tenants(_: dict = Depends(require_superadmin)):
        """List all tenants."""
        return [TenantResponse(**t) for t in state["tenants"].list_tenants()]

    @app.delete("/v1/admin/tenants/{tenant_id}", tags=["Admin"])
    def deactivate_tenant(tenant_id: str, _: dict = Depends(require_superadmin)):
        """Deactivate a tenant. Their keys and audit data are retained."""
        if not state["tenants"].deactivate_tenant(tenant_id):
            raise HTTPException(status_code=404, detail=f"Tenant '{tenant_id}' not found.")
        return {"status": "deactivated", "tenant_id": tenant_id}

    # ── API key management ────────────────────────────────────────────────────

    @app.post("/v1/keys", response_model=CreateKeyResponse, tags=["Keys"])
    def create_key(req: CreateKeyRequest, key_info: dict = Depends(require_api_key)):
        """Create a new API key scoped to the calling tenant."""
        tenant_id = key_info["tenant_id"]
        key_id, plaintext = state["keys"].create_key(
            req.name,
            tenant_id=tenant_id,
            scope=req.scope.value,
            expires_days=req.expires_days,
        )
        keys = state["keys"].list_keys(tenant_id)
        created_at = next(k["created_at"] for k in keys if k["key_id"] == key_id)
        return CreateKeyResponse(key_id=key_id, name=req.name, key=plaintext, created_at=created_at)

    @app.get("/v1/keys", response_model=list[KeySummary], tags=["Keys"])
    def list_keys(key_info: dict = Depends(require_api_key)):
        """List all keys for the calling tenant."""
        return [KeySummary(**k) for k in state["keys"].list_keys(key_info["tenant_id"])]

    @app.post("/v1/keys/{key_id}/rotate", response_model=RotateKeyResponse, tags=["Keys"])
    def rotate_key(key_id: str, key_info: dict = Depends(require_api_key)):
        """Rotate a key: issue a replacement then revoke the old one. New plaintext returned once."""
        result = state["keys"].rotate_key(key_id, key_info["tenant_id"])
        if result is None:
            raise HTTPException(status_code=404, detail=f"Key '{key_id}' not found.")
        new_key_id, plaintext = result
        keys = state["keys"].list_keys(key_info["tenant_id"])
        key_record = next((k for k in keys if k["key_id"] == new_key_id), {})
        return RotateKeyResponse(
            key_id=new_key_id,
            key=plaintext,
            name=key_record.get("name", ""),
            created_at=key_record.get("created_at", ""),
        )

    @app.delete("/v1/keys/{key_id}", tags=["Keys"])
    def revoke_key(key_id: str, key_info: dict = Depends(require_api_key)):
        """Revoke a key. Only keys belonging to the calling tenant can be revoked."""
        if not state["keys"].revoke(key_id, key_info["tenant_id"]):
            raise HTTPException(status_code=404, detail=f"Key '{key_id}' not found or already revoked.")
        return {"status": "revoked", "key_id": key_id}

    # ── context evaluation ────────────────────────────────────────────────────

    @app.post("/v1/context/evaluate", response_model=EvaluateResponse, tags=["Context"])
    def evaluate(req: EvaluateRequest, key_info: dict = Depends(require_api_key)):
        tenant_id = key_info["tenant_id"]

        # ── session lifecycle check ───────────────────────────────────────────
        sess_store = state["session_store"]
        existing = sess_store.get_session(req.session_id, tenant_id)
        if existing is None:
            # First use of this session — register it.
            # TTL resolution: policy-level > global server setting > None (no expiry)
            ttl = state["engine"].get_session_ttl(
                req.agent_role, fallback=state["session_ttl_minutes"]
            )
            sess_store.create_session(
                session_id=req.session_id,
                agent_role=req.agent_role,
                user_id=req.user_id,
                tenant_id=tenant_id,
                ttl_minutes=ttl,
            )
            session_decision = None
        else:
            valid, validity_reason = sess_store.is_valid(req.session_id, tenant_id)
            if not valid:
                session_decision = (
                    Decision.DENY,
                    validity_reason,            # "session_expired" or "session_revoked"
                    f"Session '{req.session_id[:8]}…' is {validity_reason.replace('_', ' ')}",
                )
            else:
                sess_store.touch_session(req.session_id, tenant_id, req.agent_role)
                session_decision = None

        # Compute session age for sensitivity decay (only when session already existed)
        _age: Optional[int] = None
        if existing is not None:
            try:
                from datetime import timezone as _tz
                raw = existing["created_at"]
                if isinstance(raw, str):
                    raw = raw.rstrip("Z")
                    _created = datetime.fromisoformat(raw).replace(tzinfo=_tz.utc)
                else:
                    _created = raw if raw.tzinfo else raw.replace(tzinfo=_tz.utc)
                _age = max(0, int((datetime.now(_tz.utc) - _created).total_seconds() / 60))
            except Exception:
                pass

        request = ContextRequest(
            query=req.query, agent_role=req.agent_role, user_id=req.user_id,
            source_id=req.source_id, sensitivity_level=req.sensitivity_level,
            session_id=req.session_id, task_type=req.task_type,
            session_age_minutes=_age,
        )
        with telemetry.evaluate_span(
            agent_role=req.agent_role,
            source_id=req.source_id,
            tenant_id=tenant_id,
            session_id=req.session_id,
            sensitivity_level=req.sensitivity_level.value,
        ) as otel_span:
            if session_decision:
                decision, policy_name, reason = session_decision
            else:
                decision, policy_name, reason = _get_engine(tenant_id).evaluate(request)
            otel_span.set_result(decision=decision.value, policy_name=policy_name, reason=reason)
        event = AuditEvent(
            event_id=str(uuid.uuid4()), session_id=req.session_id,
            agent_role=req.agent_role, user_id=req.user_id, source_id=req.source_id,
            query=req.query, decision=decision, policy_name=policy_name,
            reason=reason, timestamp=datetime.utcnow(),
            sensitivity_level=req.sensitivity_level.value,
            source_type="rest",
        )
        state["log"].record(event, tenant_id=tenant_id)
        state["alert_engine"].check(event, tenant_id)
        # Chain caller-supplied context hash into the session's accumulated hash
        if decision == Decision.ALLOW and req.context_hash:
            try:
                state["session_store"].update_session_context_hash(
                    req.session_id, tenant_id, req.context_hash
                )
            except Exception:
                pass  # never block a response for hash bookkeeping
        return EvaluateResponse(
            decision=decision, policy_name=policy_name, reason=reason,
            event_id=event.event_id, session_id=req.session_id, timestamp=event.timestamp,
        )

    # ── session management ────────────────────────────────────────────────────

    def _session_status(sess: dict) -> str:
        if sess["is_revoked"]:
            return "revoked"
        if sess["expires_at"] is not None:
            from datetime import timezone
            now = datetime.now(timezone.utc)
            exp = datetime.fromisoformat(sess["expires_at"])
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if now > exp:
                return "expired"
        return "active"

    def _to_session_response(sess: dict) -> SessionResponse:
        return SessionResponse(
            session_id=sess["session_id"],
            agent_role=sess["agent_role"],
            user_id=sess["user_id"],
            created_at=sess["created_at"],
            last_active=sess["last_active"],
            expires_at=sess["expires_at"],
            ttl_minutes=sess["ttl_minutes"],
            is_revoked=sess["is_revoked"],
            status=_session_status(sess),
            context_hash=sess.get("context_hash"),
            revocation_reason=sess.get("revocation_reason"),
            revoked_at=sess.get("revoked_at"),
        )

    @app.get("/v1/sessions", response_model=list[SessionResponse], tags=["Sessions"])
    def list_sessions(
        include_expired: bool = Query(default=False, description="Include expired and revoked sessions"),
        key_info: dict = Depends(require_api_key),
    ):
        """List sessions for this tenant. By default only active (non-expired, non-revoked) sessions."""
        tenant_id = key_info["tenant_id"]
        sessions = state["session_store"].list_sessions(tenant_id, include_expired=include_expired)
        return [_to_session_response(s) for s in sessions]

    @app.get("/v1/sessions/{session_id}", response_model=SessionResponse, tags=["Sessions"])
    def get_session(session_id: str, key_info: dict = Depends(require_api_key)):
        """Return current status of a session."""
        tenant_id = key_info["tenant_id"]
        sess = state["session_store"].get_session(session_id, tenant_id)
        if sess is None:
            raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found.")
        return _to_session_response(sess)

    @app.delete("/v1/sessions/{session_id}", tags=["Sessions"])
    def revoke_session(
        session_id: str,
        reason: RevocationReason = Query(
            default=RevocationReason.admin_action,
            description="Why this session is being revoked",
        ),
        key_info: dict = Depends(require_api_key),
    ):
        """Immediately revoke a session. Any subsequent evaluation on this session will be denied."""
        tenant_id = key_info["tenant_id"]
        if not state["session_store"].revoke_session(session_id, tenant_id, reason=reason.value):
            raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found.")
        return {"status": "revoked", "session_id": session_id, "reason": reason.value}

    @app.delete("/v1/sessions", tags=["Sessions"])
    def bulk_revoke_sessions(
        agent_role: str | None = Query(default=None, description="Revoke all sessions owned by this agent role"),
        user_id:    str | None = Query(default=None, description="Revoke all sessions belonging to this user"),
        reason:     RevocationReason = Query(
            default=RevocationReason.bulk_revocation,
            description="Why these sessions are being revoked",
        ),
        key_info:   dict = Depends(require_api_key),
    ):
        """
        Revoke all active sessions matching the given filters (AND semantics).
        At least one of agent_role or user_id is required — omitting both returns 400.
        """
        if agent_role is None and user_id is None:
            raise HTTPException(
                status_code=400,
                detail="At least one of agent_role or user_id is required.",
            )
        tenant_id = key_info["tenant_id"]
        count = state["session_store"].revoke_sessions_by(
            tenant_id, agent_role=agent_role, user_id=user_id, reason=reason.value
        )
        return {"status": "revoked", "count": count, "agent_role": agent_role, "user_id": user_id, "reason": reason.value}

    # ── audit trail ───────────────────────────────────────────────────────────

    @app.get("/v1/audit/sessions/{session_id}", response_model=AuditTrailResponse, tags=["Audit"])
    def get_session_audit(session_id: str, key_info: dict = Depends(require_api_key)):
        tenant_id = key_info["tenant_id"]
        events = state["log"].get_session_events(session_id, tenant_id)
        if not events:
            raise HTTPException(status_code=404, detail=f"No events found for session '{session_id}'")
        return AuditTrailResponse(
            session_id=session_id, total_events=len(events),
            allowed=sum(1 for e in events if e.decision == Decision.ALLOW),
            denied=sum(1 for e in events if e.decision == Decision.DENY),
            events=[_to_response(e) for e in events],
        )

    @app.get("/v1/audit/verify", response_model=ChainVerifyResponse, tags=["Audit"])
    def verify_audit_chain(key_info: dict = Depends(require_api_key)):
        """Verify tamper-evidence hash chain integrity for this tenant's audit log."""
        result = state["log"].verify_chain(key_info["tenant_id"])
        return ChainVerifyResponse(**result)

    @app.get("/v1/audit/retention", response_model=AuditRetentionResponse, tags=["Audit"])
    def get_audit_retention(key_info: dict = Depends(require_api_key)):
        """Return the active log retention policy for this tenant."""
        return AuditRetentionResponse(
            retention_days=0,
            policy="Automatic purge is disabled. Use DELETE /v1/audit/events to purge manually.",
            anchor=None,
        )

    @app.get("/v1/audit/stats", tags=["Audit"])
    def get_stats(key_info: dict = Depends(require_api_key)):
        tenant_id = key_info["tenant_id"]
        events   = state["log"].get_all_events(tenant_id)
        sessions = list({e.session_id for e in events})
        allowed  = [e for e in events if e.decision == Decision.ALLOW]
        denied   = [e for e in events if e.decision == Decision.DENY]
        roles, sources, by_source_type = {}, {}, {}
        for e in events:
            roles[e.agent_role]  = roles.get(e.agent_role, 0) + 1
            sources[e.source_id] = sources.get(e.source_id, 0) + 1
            st = getattr(e, "source_type", "rest") or "rest"
            if st not in by_source_type:
                by_source_type[st] = {"total": 0, "allowed": 0, "denied": 0}
            by_source_type[st]["total"] += 1
            if e.decision == Decision.ALLOW:
                by_source_type[st]["allowed"] += 1
            else:
                by_source_type[st]["denied"] += 1
        return {
            "total_events":    len(events),
            "allowed":         len(allowed),
            "denied":          len(denied),
            "active_sessions": len(sessions),
            "top_roles":       sorted(roles.items(),   key=lambda x: -x[1])[:5],
            "top_sources":     sorted(sources.items(), key=lambda x: -x[1])[:5],
            "recent_events":   [_to_response(e) for e in reversed(events[-10:])],
            "by_source_type":  by_source_type,
        }

    @app.get("/v1/audit/events", response_model=list[AuditEventResponse], tags=["Audit"])
    def get_all_events(
        decision:   Optional[Decision] = Query(default=None),
        agent_role: Optional[str]      = Query(default=None),
        limit:      int                = Query(default=100, le=1000),
        key_info:   dict               = Depends(require_api_key),
    ):
        tenant_id = key_info["tenant_id"]
        events = state["log"].get_all_events(tenant_id)
        if decision:
            events = [e for e in events if e.decision == decision]
        if agent_role:
            events = [e for e in events if e.agent_role == agent_role]
        return [_to_response(e) for e in events[:limit]]

    _EXPORT_FIELDS = [
        "event_id", "timestamp", "session_id", "agent_role", "user_id",
        "source_id", "query", "decision", "policy_name", "reason", "context_hash",
    ]

    @app.get("/v1/audit/export", tags=["Audit"])
    def export_audit_events(
        format:     str                = Query(default="csv", pattern="^(csv|json)$"),
        decision:   Optional[Decision] = Query(default=None),
        agent_role: Optional[str]      = Query(default=None),
        source_id:  Optional[str]      = Query(default=None),
        from_time:  Optional[datetime] = Query(default=None, alias="from"),
        to_time:    Optional[datetime] = Query(default=None, alias="to"),
        key_info:   dict               = Depends(require_api_key),
    ):
        tenant_id = key_info["tenant_id"]
        events = state["log"].get_all_events(tenant_id)

        if decision:
            events = [e for e in events if e.decision == decision]
        if agent_role:
            events = [e for e in events if e.agent_role == agent_role]
        if source_id:
            events = [e for e in events if e.source_id == source_id]
        if from_time:
            events = [e for e in events if e.timestamp >= from_time]
        if to_time:
            events = [e for e in events if e.timestamp <= to_time]

        timestamp = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")

        if format == "json":
            import json
            payload = json.dumps(
                [
                    {
                        "event_id":     e.event_id,
                        "timestamp":    e.timestamp.isoformat(),
                        "session_id":   e.session_id,
                        "agent_role":   e.agent_role,
                        "user_id":      e.user_id,
                        "source_id":    e.source_id,
                        "query":        e.query,
                        "decision":     e.decision.value,
                        "policy_name":  e.policy_name,
                        "reason":       e.reason,
                        "context_hash": e.context_hash,
                    }
                    for e in events
                ],
                indent=2,
            )
            return StreamingResponse(
                io.BytesIO(payload.encode()),
                media_type="application/json",
                headers={"Content-Disposition": f'attachment; filename="autopil_audit_{timestamp}.json"'},
            )

        # CSV (default)
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=_EXPORT_FIELDS)
        writer.writeheader()
        for e in events:
            writer.writerow({
                "event_id":     e.event_id,
                "timestamp":    e.timestamp.isoformat(),
                "session_id":   e.session_id,
                "agent_role":   e.agent_role,
                "user_id":      e.user_id,
                "source_id":    e.source_id,
                "query":        e.query,
                "decision":     e.decision.value,
                "policy_name":  e.policy_name,
                "reason":       e.reason,
                "context_hash": e.context_hash or "",
            })
        return StreamingResponse(
            io.BytesIO(buf.getvalue().encode()),
            media_type="text/csv",
            headers={"Content-Disposition": f'attachment; filename="autopil_audit_{timestamp}.csv"'},
        )

    # ── action lineage ────────────────────────────────────────────────────────

    @app.post("/v1/audit/lineage", response_model=AgentActionResponse, tags=["Audit"])
    def record_action(req: RecordActionRequest, key_info: dict = Depends(require_api_key)):
        """Record an agent action driven by a specific audit event."""
        tenant_id = key_info["tenant_id"]
        # Verify the event exists and belongs to this tenant
        events = state["log"].get_all_events(tenant_id)
        event = next((e for e in events if e.event_id == req.event_id), None)
        if not event:
            raise HTTPException(status_code=404, detail=f"Audit event '{req.event_id}' not found.")
        action = AgentAction(
            action_id=str(uuid.uuid4()),
            event_id=req.event_id,
            session_id=req.session_id,
            agent_role=event.agent_role,
            action_type=req.action_type,
            action_detail=req.action_detail,
            outcome=req.outcome,
            timestamp=datetime.utcnow(),
        )
        state["lineage_store"].record_action(action, tenant_id)
        return AgentActionResponse(
            action_id=action.action_id, event_id=action.event_id,
            session_id=action.session_id, agent_role=action.agent_role,
            action_type=action.action_type, action_detail=action.action_detail,
            outcome=action.outcome, timestamp=action.timestamp,
        )

    @app.get("/v1/audit/lineage/{event_id}", response_model=LineageResponse, tags=["Audit"])
    def get_lineage(event_id: str, key_info: dict = Depends(require_api_key)):
        """Return the audit event and all downstream actions linked to it."""
        tenant_id = key_info["tenant_id"]
        events = state["log"].get_all_events(tenant_id)
        event = next((e for e in events if e.event_id == event_id), None)
        if not event:
            raise HTTPException(status_code=404, detail=f"Audit event '{event_id}' not found.")
        actions = state["lineage_store"].get_actions_for_event(event_id, tenant_id)
        return LineageResponse(
            event_id=event_id,
            event=_to_response(event),
            actions=[
                AgentActionResponse(
                    action_id=a.action_id, event_id=a.event_id,
                    session_id=a.session_id, agent_role=a.agent_role,
                    action_type=a.action_type, action_detail=a.action_detail,
                    outcome=a.outcome, timestamp=a.timestamp,
                )
                for a in actions
            ],
        )

    # ── policy management ─────────────────────────────────────────────────────

    @app.get("/v1/policies", response_model=list[PolicyDetailResponse], tags=["Policies"])
    def list_policies(
        key_info: dict = Depends(require_api_key),
        industry: Optional[str] = Query(default=None, description="Filter by industry (e.g. healthcare)"),
        category: Optional[str] = Query(default=None, description="Filter by category (e.g. clinical_operations)"),
    ):
        tenant_id = key_info["tenant_id"]
        db_policies = state["policy_store"].list_active(tenant_id)
        source = db_policies if db_policies else [
            {
                "policy_id": "", "version": 0, "created_at": "", "updated_at": "",
                "changed_by": None, "user_modified": False, **p,
                "industry": p.get("industry"),
                "category": p.get("category"),
                "allowed_tasks": p.get("allowed_tasks", []),
                "denied_tasks": p.get("denied_tasks", []),
            }
            for p in _load_yaml_policies(state["policy_path"])
        ]
        if industry:
            source = [p for p in source if p.get("industry") == industry]
        if category:
            source = [p for p in source if p.get("category") == category]
        return [PolicyDetailResponse(**p) for p in source]

    @app.post("/v1/policies/reload", tags=["Policies"])
    def reload_policies(key_info: dict = Depends(require_api_key)):
        tenant_id = key_info["tenant_id"]
        state["engine"] = PolicyEngine(state["policy_path"])
        policies = _load_yaml_policies(state["policy_path"])
        skipped = 0
        imported = 0
        for p in policies:
            existing = state["policy_store"].get(p["name"], tenant_id, p.get("industry"), p.get("category"))
            if existing and existing.get("user_modified"):
                skipped += 1
                continue
            state["policy_store"].upsert(
                {
                    "name":            p["name"],
                    "agent_role":      p["agent_role"],
                    "allowed_sources": p.get("allowed_sources", []),
                    "denied_sources":  p.get("denied_sources", []),
                    "allowed_tasks":   p.get("allowed_tasks", []),
                    "denied_tasks":    p.get("denied_tasks", []),
                    "max_sensitivity": p.get("max_sensitivity", "restricted"),
                    "industry":        p.get("industry"),
                    "category":        p.get("category"),
                    "description":     p.get("description"),
                },
                tenant_id=tenant_id,
                changed_by=key_info["key_id"],
                user_modified=False,
            )
            imported += 1
        return {"status": "reloaded", "policies_imported": imported, "policies_skipped": skipped}

    @app.post("/v1/policies/{policy_id}/restore", response_model=PolicyDetailResponse, tags=["Policies"])
    def restore_policy_from_yaml(policy_id: str, key_info: dict = Depends(require_api_key)):
        """Restore a policy to its YAML definition by policy_id, clearing the user_modified flag."""
        tenant_id = key_info["tenant_id"]
        db_policy = state["policy_store"].get_by_id(policy_id, tenant_id)
        if not db_policy:
            raise HTTPException(status_code=404, detail=f"Policy '{policy_id}' not found.")
        yaml_key = (db_policy["name"], db_policy.get("industry"), db_policy.get("category"))
        yaml_map = {(p["name"], p.get("industry"), p.get("category")): p for p in _load_yaml_policies(state["policy_path"])}
        if yaml_key not in yaml_map:
            raise HTTPException(status_code=404, detail=f"No YAML source found for policy '{db_policy['name']}'.")
        p = yaml_map[yaml_key]
        state["policy_store"].upsert(
            {
                "name":            p["name"],
                "agent_role":      p["agent_role"],
                "allowed_sources": p.get("allowed_sources", []),
                "denied_sources":  p.get("denied_sources", []),
                "allowed_tasks":   p.get("allowed_tasks", []),
                "denied_tasks":    p.get("denied_tasks", []),
                "max_sensitivity": p.get("max_sensitivity", "restricted"),
                "industry":        p.get("industry"),
                "category":        p.get("category"),
                "description":     p.get("description"),
            },
            tenant_id=tenant_id,
            changed_by=key_info["key_id"],
            user_modified=False,
        )
        policy = state["policy_store"].get_by_id(policy_id, tenant_id)
        return PolicyDetailResponse(**policy)

    @app.post("/v1/policies", response_model=PolicyDetailResponse, tags=["Policies"])
    def create_policy(req: CreatePolicyRequest, key_info: dict = Depends(require_api_key)):
        """Create a new policy for this tenant."""
        tenant_id = key_info["tenant_id"]
        if state["policy_store"].get(req.name, tenant_id, req.industry, req.category):
            raise HTTPException(status_code=409, detail=f"Policy '{req.name}' already exists for this industry/category.")
        pid = state["policy_store"].upsert(req.model_dump(), tenant_id=tenant_id, changed_by=key_info["key_id"])
        policy = state["policy_store"].get_by_id(pid, tenant_id)
        return PolicyDetailResponse(**policy)

    @app.put("/v1/policies/{policy_id}", response_model=PolicyDetailResponse, tags=["Policies"])
    def update_policy(policy_id: str, req: UpdatePolicyRequest, key_info: dict = Depends(require_api_key)):
        """Update an existing policy by policy_id. Saves the previous version to history."""
        tenant_id = key_info["tenant_id"]
        policy = state["policy_store"].update_by_id(
            policy_id, req.model_dump(), tenant_id=tenant_id,
            changed_by=key_info["key_id"], user_modified=True,
        )
        if policy is None:
            raise HTTPException(status_code=404, detail=f"Policy '{policy_id}' not found.")
        return PolicyDetailResponse(**policy)

    @app.delete("/v1/policies/{policy_id}", tags=["Policies"])
    def delete_policy(policy_id: str, key_info: dict = Depends(require_api_key)):
        """Soft-delete a policy by policy_id."""
        tenant_id = key_info["tenant_id"]
        if not state["policy_store"].delete_by_id(policy_id, tenant_id):
            raise HTTPException(status_code=404, detail=f"Policy '{policy_id}' not found.")
        return {"status": "deleted", "policy_id": policy_id}

    @app.get("/v1/policies/{policy_id}/history", response_model=list[PolicyVersionResponse], tags=["Policies"])
    def get_policy_history(policy_id: str, key_info: dict = Depends(require_api_key)):
        """Return version history for a policy by policy_id, newest first."""
        tenant_id = key_info["tenant_id"]
        history = state["policy_store"].get_history_by_id(policy_id, tenant_id)
        if not history:
            raise HTTPException(status_code=404, detail=f"No history found for policy '{policy_id}'.")
        return [PolicyVersionResponse(**v) for v in history]

    # ── alert rules ──────────────────────────────────────────────────────────

    @app.post("/v1/alerts/rules", response_model=AlertRuleResponse, tags=["Alerts"])
    def create_alert_rule(req: CreateAlertRuleRequest, key_info: dict = Depends(require_api_key)):
        """Create a new alert rule for this tenant."""
        tenant_id = key_info["tenant_id"]
        rule_id = state["alert_store"].create_rule(req.model_dump(), tenant_id)
        rule = state["alert_store"].get_rule(rule_id, tenant_id)
        return AlertRuleResponse(**rule)

    @app.get("/v1/alerts/rules", response_model=list[AlertRuleResponse], tags=["Alerts"])
    def list_alert_rules(key_info: dict = Depends(require_api_key)):
        """List all alert rules for this tenant."""
        rules = state["alert_store"].list_rules(key_info["tenant_id"])
        return [AlertRuleResponse(**r) for r in rules]

    @app.put("/v1/alerts/rules/{rule_id}", response_model=AlertRuleResponse, tags=["Alerts"])
    def update_alert_rule(rule_id: str, req: UpdateAlertRuleRequest, key_info: dict = Depends(require_api_key)):
        """Update an alert rule."""
        tenant_id = key_info["tenant_id"]
        updates = {k: v for k, v in req.model_dump().items() if v is not None}
        if not state["alert_store"].update_rule(rule_id, updates, tenant_id):
            raise HTTPException(status_code=404, detail=f"Alert rule '{rule_id}' not found.")
        rule = state["alert_store"].get_rule(rule_id, tenant_id)
        return AlertRuleResponse(**rule)

    @app.delete("/v1/alerts/rules/{rule_id}", tags=["Alerts"])
    def delete_alert_rule(rule_id: str, key_info: dict = Depends(require_api_key)):
        """Delete an alert rule."""
        if not state["alert_store"].delete_rule(rule_id, key_info["tenant_id"]):
            raise HTTPException(status_code=404, detail=f"Alert rule '{rule_id}' not found.")
        return {"status": "deleted", "rule_id": rule_id}

    @app.get("/v1/alerts/fired", response_model=list[AlertDeliveryResponse], tags=["Alerts"])
    def list_fired_alerts(
        limit: int = Query(default=50, le=500),
        key_info: dict = Depends(require_api_key),
    ):
        """Return recent alert deliveries for this tenant, newest first."""
        deliveries = state["alert_store"].list_deliveries(key_info["tenant_id"], limit=limit)
        return [AlertDeliveryResponse(**d) for d in deliveries]

    # ── agent registry ────────────────────────────────────────────────────────

    @app.get("/v1/agents", response_model=list[AgentRegistryEntryResponse], tags=["Agents"])
    def list_agents(
        status:    Optional[str] = Query(default=None),
        framework: Optional[str] = Query(default=None),
        owner:     Optional[str] = Query(default=None),
        key_info:  dict = Depends(require_api_key),
    ):
        tenant_id = key_info["tenant_id"]
        entries = state["agent_registry_store"].list_agents(
            tenant_id, status=status, framework=framework, owner=owner
        )
        roles = [e.agent_role for e in entries]
        activity = state["agent_registry_store"].get_activity_stats(roles, tenant_id)
        return [_agent_to_response(e, activity.get(e.agent_role, {})) for e in entries]

    @app.get("/v1/agents/stats/summary", response_model=AgentRegistryStatsResponse, tags=["Agents"])
    def get_agent_stats(key_info: dict = Depends(require_api_key)):
        tenant_id = key_info["tenant_id"]
        entries = state["agent_registry_store"].list_agents(tenant_id)
        counts: dict[str, int] = {"draft": 0, "pending_approval": 0, "approved": 0, "deprecated": 0}
        for e in entries:
            counts[e.status] = counts.get(e.status, 0) + 1
        return AgentRegistryStatsResponse(
            total=len(entries),
            approved=counts["approved"],
            draft=counts["draft"],
            pending_approval=counts["pending_approval"],
            deprecated=counts["deprecated"],
        )

    @app.post("/v1/agents", response_model=AgentRegistryEntryResponse, status_code=201, tags=["Agents"])
    def register_agent(req: RegisterAgentRequest, key_info: dict = Depends(require_api_key)):
        tenant_id = key_info["tenant_id"]
        now = datetime.utcnow()
        entry = AgentRegistryEntry(
            agent_id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            agent_role=req.agent_role,
            display_name=req.display_name,
            description=req.description,
            owner=req.owner,
            framework=req.framework,
            policy_name=req.policy_name,
            status="draft",
            version=req.version,
            created_at=now,
            updated_at=now,
            created_by=key_info.get("key_id"),
        )
        state["agent_registry_store"].create(entry, tenant_id)
        saved = state["agent_registry_store"].get(entry.agent_id, tenant_id)
        return _agent_to_response(saved, {})

    @app.get("/v1/agents/{agent_id}", response_model=AgentRegistryEntryResponse, tags=["Agents"])
    def get_agent(agent_id: str, key_info: dict = Depends(require_api_key)):
        tenant_id = key_info["tenant_id"]
        entry = state["agent_registry_store"].get(agent_id, tenant_id)
        if not entry:
            raise HTTPException(status_code=404, detail="Agent not found.")
        activity = state["agent_registry_store"].get_activity_stats([entry.agent_role], tenant_id)
        return _agent_to_response(entry, activity.get(entry.agent_role, {}))

    @app.put("/v1/agents/{agent_id}", response_model=AgentRegistryEntryResponse, tags=["Agents"])
    def update_agent(agent_id: str, req: UpdateAgentRequest, key_info: dict = Depends(require_api_key)):
        tenant_id = key_info["tenant_id"]
        if not state["agent_registry_store"].update(agent_id, req.model_dump(exclude_none=True), tenant_id):
            raise HTTPException(status_code=404, detail="Agent not found.")
        entry = state["agent_registry_store"].get(agent_id, tenant_id)
        activity = state["agent_registry_store"].get_activity_stats([entry.agent_role], tenant_id)
        return _agent_to_response(entry, activity.get(entry.agent_role, {}))

    @app.patch("/v1/agents/{agent_id}/status", response_model=AgentRegistryEntryResponse, tags=["Agents"])
    def update_agent_status(agent_id: str, req: UpdateAgentStatusRequest, key_info: dict = Depends(require_api_key)):
        valid_statuses = {"draft", "pending_approval", "approved", "deprecated"}
        if req.status not in valid_statuses:
            raise HTTPException(status_code=422, detail=f"Invalid status '{req.status}'.")
        tenant_id = key_info["tenant_id"]
        if not state["agent_registry_store"].update_status(
            agent_id, req.status, tenant_id, approved_by=key_info.get("key_id")
        ):
            raise HTTPException(status_code=404, detail="Agent not found.")
        entry = state["agent_registry_store"].get(agent_id, tenant_id)
        activity = state["agent_registry_store"].get_activity_stats([entry.agent_role], tenant_id)
        return _agent_to_response(entry, activity.get(entry.agent_role, {}))

    # ── helpers ───────────────────────────────────────────────────────────────

    def _agent_to_response(entry, activity: dict) -> AgentRegistryEntryResponse:
        return AgentRegistryEntryResponse(
            agent_id=entry.agent_id,
            agent_role=entry.agent_role,
            display_name=entry.display_name,
            status=entry.status,
            version=entry.version,
            created_at=entry.created_at.isoformat(),
            updated_at=entry.updated_at.isoformat(),
            description=entry.description,
            owner=entry.owner,
            framework=entry.framework,
            policy_name=entry.policy_name,
            created_by=entry.created_by,
            approved_by=entry.approved_by,
            approved_at=entry.approved_at.isoformat() if entry.approved_at else None,
            last_active=activity.get("last_active"),
            event_count_7d=activity.get("event_count_7d", 0),
            deny_rate_7d=activity.get("deny_rate_7d", 0.0),
        )

    def _to_response(e: AuditEvent) -> AuditEventResponse:
        return AuditEventResponse(
            event_id=e.event_id, session_id=e.session_id, agent_role=e.agent_role,
            user_id=e.user_id, source_id=e.source_id, query=e.query,
            decision=e.decision, policy_name=e.policy_name, reason=e.reason,
            timestamp=e.timestamp, context_hash=e.context_hash,
            sensitivity_level=e.sensitivity_level,
            source_type=e.source_type,
        )

    return app
