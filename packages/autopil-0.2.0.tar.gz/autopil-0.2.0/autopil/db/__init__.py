"""
Storage backend factory.

Usage:
    from autopil.db import create_stores

    audit_log, key_store, tenant_store, policy_store, alert_store, lineage_store, session_store, agent_registry_store = create_stores(database_url="postgresql://...")
    audit_log, key_store, tenant_store, policy_store, alert_store, lineage_store, session_store, agent_registry_store = create_stores(db_path="/data/autopil.db")
"""

from .base import AgentRegistryStoreBase, AuditLogBase, AlertStoreBase, KeyStoreBase, LineageStoreBase, SessionStoreBase, TenantStoreBase, PolicyStoreBase


def create_stores(
    database_url: str | None = None,
    db_path: str = "autopil_audit.db",
) -> tuple[AuditLogBase, KeyStoreBase, TenantStoreBase, PolicyStoreBase, AlertStoreBase, LineageStoreBase, SessionStoreBase, AgentRegistryStoreBase]:
    """
    Return (audit_log, key_store, tenant_store, policy_store, alert_store, lineage_store, session_store, agent_registry_store).

    - If database_url is set (postgresql://...) → Postgres backend
    - Otherwise → SQLite backend using db_path
    """
    if database_url:
        from .postgres import (PostgresAuditLog, PostgresKeyStore, PostgresTenantStore,
                                PostgresPolicyStore, PostgresAlertStore, PostgresSessionStore)
        from .sqlite import SQLiteLineageStore, SQLiteAgentRegistryStore
        return (
            PostgresAuditLog(database_url),
            PostgresKeyStore(database_url),
            PostgresTenantStore(database_url),
            PostgresPolicyStore(database_url),
            PostgresAlertStore(database_url),
            SQLiteLineageStore(db_path),          # lineage store always SQLite for now
            PostgresSessionStore(database_url),
            SQLiteAgentRegistryStore(db_path),    # agent registry always SQLite for now
        )

    from .sqlite import (SQLiteAuditLog, SQLiteKeyStore, SQLiteTenantStore,
                         SQLitePolicyStore, SQLiteAlertStore, SQLiteLineageStore,
                         SQLiteSessionStore, SQLiteAgentRegistryStore)
    return (
        SQLiteAuditLog(db_path),
        SQLiteKeyStore(db_path),
        SQLiteTenantStore(db_path),
        SQLitePolicyStore(db_path),
        SQLiteAlertStore(db_path),
        SQLiteLineageStore(db_path),
        SQLiteSessionStore(db_path),
        SQLiteAgentRegistryStore(db_path),
    )


__all__ = ["create_stores", "AgentRegistryStoreBase", "AuditLogBase", "AlertStoreBase",
           "KeyStoreBase", "LineageStoreBase", "SessionStoreBase", "TenantStoreBase",
           "PolicyStoreBase"]
