"""
SQLite backend — default for local development and single-node deployments.
"""

import hashlib
import secrets
import sqlite3
import uuid
from datetime import datetime, timedelta, timezone

from autopil.models import AgentAction, AgentRegistryEntry, AuditEvent, Decision

from .base import AgentRegistryStoreBase, AuditLogBase, AlertStoreBase, KeyStoreBase, LineageStoreBase, SessionStoreBase, TenantStoreBase, PolicyStoreBase

KEY_PREFIX = "apl_"


def _ts_str(ts) -> str:
    """Normalise a timestamp to an ISO-format string regardless of input type."""
    if isinstance(ts, datetime):
        return ts.isoformat()
    return str(ts)


def _hash(key: str) -> str:
    return hashlib.sha256(key.encode()).hexdigest()


def _has_column(conn: sqlite3.Connection, table: str, column: str) -> bool:
    rows = conn.execute(f"PRAGMA table_info({table})").fetchall()
    return any(r[1] == column for r in rows)


class SQLiteAuditLog(AuditLogBase):

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS audit_events (
                    event_id          TEXT PRIMARY KEY,
                    session_id        TEXT NOT NULL,
                    agent_role        TEXT NOT NULL,
                    user_id           TEXT NOT NULL,
                    source_id         TEXT NOT NULL,
                    query             TEXT NOT NULL,
                    decision          TEXT NOT NULL,
                    policy_name       TEXT NOT NULL,
                    reason            TEXT NOT NULL,
                    context_hash      TEXT,
                    timestamp         TEXT NOT NULL,
                    tenant_id         TEXT NOT NULL DEFAULT 'default',
                    sensitivity_level TEXT,
                    source_type       TEXT NOT NULL DEFAULT 'rest'
                )
            """)
            # Migrations: add columns for databases created before these fields existed
            if not _has_column(conn, "audit_events", "tenant_id"):
                conn.execute(
                    "ALTER TABLE audit_events ADD COLUMN tenant_id TEXT NOT NULL DEFAULT 'default'"
                )
            if not _has_column(conn, "audit_events", "sensitivity_level"):
                conn.execute(
                    "ALTER TABLE audit_events ADD COLUMN sensitivity_level TEXT"
                )
            if not _has_column(conn, "audit_events", "source_type"):
                conn.execute(
                    "ALTER TABLE audit_events ADD COLUMN source_type TEXT NOT NULL DEFAULT 'rest'"
                )
            if not _has_column(conn, "audit_events", "catalog_enriched"):
                conn.execute(
                    "ALTER TABLE audit_events ADD COLUMN catalog_enriched INTEGER NOT NULL DEFAULT 0"
                )
            if not _has_column(conn, "audit_events", "catalog_connection_id"):
                conn.execute(
                    "ALTER TABLE audit_events ADD COLUMN catalog_connection_id TEXT"
                )
            conn.commit()

    def record(self, event: AuditEvent, tenant_id: str = "default") -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT INTO audit_events
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    event.event_id,
                    event.session_id,
                    event.agent_role,
                    event.user_id,
                    event.source_id,
                    event.query,
                    event.decision.value,
                    event.policy_name,
                    event.reason,
                    event.context_hash,
                    event.timestamp.isoformat(),
                    tenant_id,
                    event.sensitivity_level,
                    event.source_type,
                    int(event.catalog_enriched),
                    event.catalog_connection_id,
                ),
            )
            conn.commit()

    def get_session_events(self, session_id: str, tenant_id: str = "default") -> list[AuditEvent]:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT * FROM audit_events WHERE session_id = ? AND tenant_id = ? ORDER BY timestamp",
                (session_id, tenant_id),
            ).fetchall()
        return [self._row_to_event(r) for r in rows]

    def get_all_events(self, tenant_id: str = "default") -> list[AuditEvent]:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT * FROM audit_events WHERE tenant_id = ? ORDER BY timestamp",
                (tenant_id,),
            ).fetchall()
        return [self._row_to_event(r) for r in rows]

    def get_session_owner(self, session_id: str, tenant_id: str = "default") -> str | None:
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                """SELECT agent_role FROM audit_events
                   WHERE session_id = ? AND tenant_id = ?
                   ORDER BY timestamp LIMIT 1""",
                (session_id, tenant_id),
            ).fetchone()
        return row[0] if row else None

    def verify_chain(self, tenant_id: str = "default") -> dict:
        with sqlite3.connect(self.db_path) as conn:
            total = conn.execute(
                "SELECT COUNT(*) FROM audit_events WHERE tenant_id = ?", (tenant_id,)
            ).fetchone()[0]
        return {"valid": True, "total": total, "chained": 0, "legacy": total, "broken_at": None}

    def purge_old_events(self, retention_days: int, tenant_id: str | None = None) -> int:
        cutoff = (datetime.utcnow() - timedelta(days=retention_days)).isoformat()
        with sqlite3.connect(self.db_path) as conn:
            if tenant_id:
                cur = conn.execute(
                    "DELETE FROM audit_events WHERE tenant_id = ? AND timestamp < ?",
                    (tenant_id, cutoff),
                )
            else:
                cur = conn.execute(
                    "DELETE FROM audit_events WHERE timestamp < ?", (cutoff,)
                )
            conn.commit()
        return cur.rowcount

    def _row_to_event(self, row) -> AuditEvent:
        return AuditEvent(
            event_id=row[0],
            session_id=row[1],
            agent_role=row[2],
            user_id=row[3],
            source_id=row[4],
            query=row[5],
            decision=Decision(row[6]),
            policy_name=row[7],
            reason=row[8],
            timestamp=datetime.fromisoformat(row[10]),
            context_hash=row[9],
            sensitivity_level=row[12] if len(row) > 12 else None,
            source_type=row[13] if len(row) > 13 else "rest",
            catalog_enriched=bool(row[14]) if len(row) > 14 and row[14] is not None else False,
            catalog_connection_id=row[15] if len(row) > 15 else None,
        )


class SQLiteKeyStore(KeyStoreBase):

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS api_keys (
                    key_id        TEXT PRIMARY KEY,
                    key_hash      TEXT NOT NULL UNIQUE,
                    name          TEXT NOT NULL,
                    created_at    TEXT NOT NULL,
                    last_used     TEXT,
                    is_active     INTEGER NOT NULL DEFAULT 1,
                    tenant_id     TEXT NOT NULL DEFAULT 'default',
                    is_superadmin INTEGER NOT NULL DEFAULT 0
                )
            """)
            # Migrations for pre-multi-tenancy schema
            if not _has_column(conn, "api_keys", "tenant_id"):
                conn.execute(
                    "ALTER TABLE api_keys ADD COLUMN tenant_id TEXT NOT NULL DEFAULT 'default'"
                )
            if not _has_column(conn, "api_keys", "is_superadmin"):
                conn.execute(
                    "ALTER TABLE api_keys ADD COLUMN is_superadmin INTEGER NOT NULL DEFAULT 0"
                )
            if not _has_column(conn, "api_keys", "scope"):
                conn.execute(
                    "ALTER TABLE api_keys ADD COLUMN scope TEXT NOT NULL DEFAULT 'admin'"
                )

    def create_key(self, name: str, tenant_id: str = "default", is_superadmin: bool = False,
                   scope: str = "admin", expires_days: int | None = None) -> tuple[str, str]:
        key_id    = secrets.token_hex(8)
        plaintext = KEY_PREFIX + secrets.token_hex(24)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT INTO api_keys
                   (key_id, key_hash, name, created_at, tenant_id, is_superadmin, scope)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (key_id, _hash(plaintext), name, datetime.utcnow().isoformat(),
                 tenant_id, int(is_superadmin), scope),
            )
        return key_id, plaintext

    def validate(self, plaintext: str) -> dict | None:
        if not plaintext.startswith(KEY_PREFIX):
            return None
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                """SELECT key_id, tenant_id, is_superadmin, scope FROM api_keys
                   WHERE key_hash = ? AND is_active = 1""",
                (_hash(plaintext),),
            ).fetchone()
            if row:
                conn.execute(
                    "UPDATE api_keys SET last_used = ? WHERE key_id = ?",
                    (datetime.utcnow().isoformat(), row[0]),
                )
                return {"key_id": row[0], "tenant_id": row[1], "is_superadmin": bool(row[2]),
                        "scope": row[3]}
        return None

    def list_keys(self, tenant_id: str = "default") -> list[dict]:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                """SELECT key_id, name, created_at, last_used, is_active, tenant_id, is_superadmin, scope
                   FROM api_keys WHERE tenant_id = ? ORDER BY created_at""",
                (tenant_id,),
            ).fetchall()
        return [
            {"key_id": r[0], "name": r[1], "created_at": r[2], "last_used": r[3],
             "is_active": bool(r[4]), "tenant_id": r[5], "is_superadmin": bool(r[6]),
             "scope": r[7]}
            for r in rows
        ]

    def rotate_key(self, key_id: str, tenant_id: str) -> tuple[str, str] | None:
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT name, is_superadmin FROM api_keys WHERE key_id = ? AND tenant_id = ? AND is_active = 1",
                (key_id, tenant_id),
            ).fetchone()
            if not row:
                return None
            name, is_superadmin = row
        new_id, plaintext = self.create_key(name, tenant_id, bool(is_superadmin))
        self.revoke(key_id, tenant_id)
        return new_id, plaintext

    def revoke(self, key_id: str, tenant_id: str = "default") -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cur = conn.execute(
                "UPDATE api_keys SET is_active = 0 WHERE key_id = ? AND tenant_id = ? AND is_active = 1",
                (key_id, tenant_id),
            )
        return cur.rowcount > 0

    def count(self, tenant_id: str | None = None) -> int:
        with sqlite3.connect(self.db_path) as conn:
            if tenant_id:
                return conn.execute(
                    "SELECT COUNT(*) FROM api_keys WHERE tenant_id = ?", (tenant_id,)
                ).fetchone()[0]
            return conn.execute("SELECT COUNT(*) FROM api_keys").fetchone()[0]


class SQLiteTenantStore(TenantStoreBase):

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS tenants (
                    tenant_id  TEXT PRIMARY KEY,
                    name       TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL,
                    is_active  INTEGER NOT NULL DEFAULT 1
                )
            """)

    def create_tenant(self, name: str) -> str:
        tenant_id = "ten_" + secrets.token_hex(8)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT INTO tenants (tenant_id, name, created_at) VALUES (?, ?, ?)",
                (tenant_id, name, datetime.utcnow().isoformat()),
            )
        return tenant_id

    def get_tenant(self, tenant_id: str) -> dict | None:
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT tenant_id, name, created_at, is_active FROM tenants WHERE tenant_id = ?",
                (tenant_id,),
            ).fetchone()
        if not row:
            return None
        return {"tenant_id": row[0], "name": row[1], "created_at": row[2], "is_active": bool(row[3])}

    def list_tenants(self) -> list[dict]:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT tenant_id, name, created_at, is_active FROM tenants ORDER BY created_at"
            ).fetchall()
        return [
            {"tenant_id": r[0], "name": r[1], "created_at": r[2], "is_active": bool(r[3])}
            for r in rows
        ]

    def deactivate_tenant(self, tenant_id: str) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cur = conn.execute(
                "UPDATE tenants SET is_active = 0 WHERE tenant_id = ? AND is_active = 1",
                (tenant_id,),
            )
        return cur.rowcount > 0

    def count(self) -> int:
        with sqlite3.connect(self.db_path) as conn:
            return conn.execute("SELECT COUNT(*) FROM tenants").fetchone()[0]


import json


class SQLitePolicyStore(PolicyStoreBase):

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS policies (
                    policy_id       TEXT PRIMARY KEY,
                    name            TEXT NOT NULL,
                    agent_role      TEXT NOT NULL,
                    allowed_sources TEXT NOT NULL DEFAULT '[]',
                    denied_sources  TEXT NOT NULL DEFAULT '[]',
                    max_sensitivity TEXT NOT NULL DEFAULT 'high',
                    tenant_id       TEXT NOT NULL,
                    created_at      TEXT NOT NULL,
                    updated_at      TEXT NOT NULL,
                    version         INTEGER NOT NULL DEFAULT 1,
                    changed_by      TEXT,
                    is_active       INTEGER NOT NULL DEFAULT 1,
                    allowed_tasks   TEXT NOT NULL DEFAULT '[]',
                    denied_tasks    TEXT NOT NULL DEFAULT '[]',
                    industry        TEXT,
                    category        TEXT,
                    user_modified   INTEGER NOT NULL DEFAULT 0,
                    description     TEXT
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS policy_versions (
                    version_id      TEXT PRIMARY KEY,
                    policy_id       TEXT NOT NULL,
                    name            TEXT NOT NULL,
                    agent_role      TEXT NOT NULL,
                    allowed_sources TEXT NOT NULL DEFAULT '[]',
                    denied_sources  TEXT NOT NULL DEFAULT '[]',
                    max_sensitivity TEXT NOT NULL,
                    version         INTEGER NOT NULL,
                    tenant_id       TEXT NOT NULL,
                    changed_by      TEXT,
                    changed_at      TEXT NOT NULL,
                    allowed_tasks   TEXT NOT NULL DEFAULT '[]',
                    denied_tasks    TEXT NOT NULL DEFAULT '[]',
                    industry        TEXT,
                    category        TEXT
                )
            """)
            # Column migrations for schemas that predate this file's CREATE TABLE
            for table in ("policies", "policy_versions"):
                for col, defn in [
                    ("allowed_tasks", "TEXT NOT NULL DEFAULT '[]'"),
                    ("denied_tasks",  "TEXT NOT NULL DEFAULT '[]'"),
                    ("industry",      "TEXT"),
                    ("category",      "TEXT"),
                ]:
                    if not _has_column(conn, table, col):
                        conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {defn}")
            if not _has_column(conn, "policies", "user_modified"):
                conn.execute("ALTER TABLE policies ADD COLUMN user_modified INTEGER NOT NULL DEFAULT 0")
            if not _has_column(conn, "policies", "description"):
                conn.execute("ALTER TABLE policies ADD COLUMN description TEXT")
            # Constraint migration: replace UNIQUE(name, tenant_id) with functional unique index
            # that allows same name across different (industry, category) combinations.
            idx_exists = conn.execute(
                "SELECT 1 FROM sqlite_master WHERE type='index' AND name='policies_name_industry_category_tenant_uniq'"
            ).fetchone()
            if not idx_exists:
                conn.execute("""
                    CREATE TABLE policies_migrated (
                        policy_id       TEXT PRIMARY KEY,
                        name            TEXT NOT NULL,
                        agent_role      TEXT NOT NULL,
                        allowed_sources TEXT NOT NULL DEFAULT '[]',
                        denied_sources  TEXT NOT NULL DEFAULT '[]',
                        max_sensitivity TEXT NOT NULL DEFAULT 'high',
                        tenant_id       TEXT NOT NULL,
                        created_at      TEXT NOT NULL,
                        updated_at      TEXT NOT NULL,
                        version         INTEGER NOT NULL DEFAULT 1,
                        changed_by      TEXT,
                        is_active       INTEGER NOT NULL DEFAULT 1,
                        allowed_tasks   TEXT NOT NULL DEFAULT '[]',
                        denied_tasks    TEXT NOT NULL DEFAULT '[]',
                        industry        TEXT,
                        category        TEXT,
                        user_modified   INTEGER NOT NULL DEFAULT 0,
                        description     TEXT
                    )
                """)
                conn.execute("""
                    INSERT INTO policies_migrated
                        (policy_id, name, agent_role, allowed_sources, denied_sources,
                         max_sensitivity, tenant_id, created_at, updated_at, version,
                         changed_by, is_active, allowed_tasks, denied_tasks,
                         industry, category, user_modified, description)
                    SELECT policy_id, name, agent_role, allowed_sources, denied_sources,
                           max_sensitivity, tenant_id, created_at, updated_at, version,
                           changed_by, is_active, allowed_tasks, denied_tasks,
                           industry, category, user_modified, description
                    FROM policies
                """)
                conn.execute("DROP TABLE policies")
                conn.execute("ALTER TABLE policies_migrated RENAME TO policies")
                conn.execute("""
                    CREATE UNIQUE INDEX policies_name_industry_category_tenant_uniq
                    ON policies (name, COALESCE(industry, ''), COALESCE(category, ''), tenant_id)
                    WHERE is_active = 1
                """)
            conn.commit()

    def upsert(self, policy: dict, tenant_id: str, changed_by: str | None = None, user_modified: bool = False) -> str:
        name = policy["name"]
        now  = datetime.utcnow().isoformat()
        allowed       = json.dumps(policy.get("allowed_sources", []))
        denied        = json.dumps(policy.get("denied_sources", []))
        allowed_tasks = json.dumps(policy.get("allowed_tasks", []))
        denied_tasks  = json.dumps(policy.get("denied_tasks", []))
        sensitivity   = policy.get("max_sensitivity", "high")
        agent_role    = policy["agent_role"]
        industry      = policy.get("industry")
        category      = policy.get("category")
        description   = policy.get("description")
        um_int        = 1 if user_modified else 0

        with sqlite3.connect(self.db_path) as conn:
            existing = conn.execute(
                """SELECT policy_id, version, agent_role, allowed_sources, denied_sources,
                          max_sensitivity, allowed_tasks, denied_tasks, industry, category,
                          user_modified, description
                   FROM policies
                   WHERE name = ? AND COALESCE(industry, '') = COALESCE(?, '')
                     AND COALESCE(category, '') = COALESCE(?, '')
                     AND tenant_id = ? AND is_active = 1""",
                (name, industry, category, tenant_id),
            ).fetchone()

            if existing:
                policy_id, version = existing[0], existing[1]
                unchanged = (
                    existing[2] == agent_role and
                    existing[3] == allowed and
                    existing[4] == denied and
                    existing[5] == sensitivity and
                    existing[6] == allowed_tasks and
                    existing[7] == denied_tasks and
                    existing[8] == industry and
                    existing[9] == category and
                    existing[10] == um_int and
                    existing[11] == description
                )
                if unchanged:
                    return policy_id
                new_version = version + 1
                conn.execute(
                    """UPDATE policies SET
                       agent_role=?, allowed_sources=?, denied_sources=?,
                       max_sensitivity=?, allowed_tasks=?, denied_tasks=?,
                       industry=?, category=?,
                       updated_at=?, version=?, changed_by=?, user_modified=?, description=?
                       WHERE policy_id=?""",
                    (agent_role, allowed, denied, sensitivity,
                     allowed_tasks, denied_tasks, industry, category,
                     now, new_version, changed_by, um_int, description, policy_id),
                )
                conn.execute(
                    """INSERT INTO policy_versions
                       (version_id, policy_id, name, agent_role, allowed_sources,
                        denied_sources, max_sensitivity, allowed_tasks, denied_tasks,
                        industry, category, version, tenant_id, changed_by, changed_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (secrets.token_hex(8), policy_id, name, agent_role, allowed, denied,
                     sensitivity, allowed_tasks, denied_tasks, industry, category,
                     new_version, tenant_id, changed_by, now),
                )
            else:
                policy_id = "pol_" + secrets.token_hex(8)
                conn.execute(
                    """INSERT INTO policies
                       (policy_id, name, agent_role, allowed_sources, denied_sources,
                        max_sensitivity, allowed_tasks, denied_tasks, industry, category,
                        tenant_id, created_at, updated_at, version, changed_by, user_modified, description)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)""",
                    (policy_id, name, agent_role, allowed, denied, sensitivity,
                     allowed_tasks, denied_tasks, industry, category,
                     tenant_id, now, now, changed_by, um_int, description),
                )
                conn.execute(
                    """INSERT INTO policy_versions
                       (version_id, policy_id, name, agent_role, allowed_sources,
                        denied_sources, max_sensitivity, allowed_tasks, denied_tasks,
                        industry, category, version, tenant_id, changed_by, changed_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)""",
                    (secrets.token_hex(8), policy_id, name, agent_role, allowed, denied,
                     sensitivity, allowed_tasks, denied_tasks, industry, category,
                     tenant_id, changed_by, now),
                )
            conn.commit()
        return policy_id

    def get(self, name: str, tenant_id: str, industry: str | None = None, category: str | None = None) -> dict | None:
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                """SELECT policy_id, name, agent_role, allowed_sources, denied_sources,
                          max_sensitivity, version, created_at, updated_at, changed_by,
                          allowed_tasks, denied_tasks, industry, category, user_modified, description
                   FROM policies
                   WHERE name = ? AND COALESCE(industry, '') = COALESCE(?, '')
                     AND COALESCE(category, '') = COALESCE(?, '')
                     AND tenant_id = ? AND is_active = 1""",
                (name, industry, category, tenant_id),
            ).fetchone()
        return self._row_to_dict(row) if row else None

    def get_by_id(self, policy_id: str, tenant_id: str) -> dict | None:
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                """SELECT policy_id, name, agent_role, allowed_sources, denied_sources,
                          max_sensitivity, version, created_at, updated_at, changed_by,
                          allowed_tasks, denied_tasks, industry, category, user_modified, description
                   FROM policies WHERE policy_id = ? AND tenant_id = ? AND is_active = 1""",
                (policy_id, tenant_id),
            ).fetchone()
        return self._row_to_dict(row) if row else None

    def list_active(self, tenant_id: str) -> list[dict]:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                """SELECT policy_id, name, agent_role, allowed_sources, denied_sources,
                          max_sensitivity, version, created_at, updated_at, changed_by,
                          allowed_tasks, denied_tasks, industry, category, user_modified, description
                   FROM policies WHERE tenant_id = ? AND is_active = 1
                   ORDER BY industry, category, name""",
                (tenant_id,),
            ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def delete(self, name: str, tenant_id: str) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cur = conn.execute(
                "UPDATE policies SET is_active = 0 WHERE name = ? AND tenant_id = ? AND is_active = 1",
                (name, tenant_id),
            )
            conn.commit()
        return cur.rowcount > 0

    def delete_by_id(self, policy_id: str, tenant_id: str) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cur = conn.execute(
                "UPDATE policies SET is_active = 0 WHERE policy_id = ? AND tenant_id = ? AND is_active = 1",
                (policy_id, tenant_id),
            )
            conn.commit()
        return cur.rowcount > 0

    def update_by_id(self, policy_id: str, policy_data: dict, tenant_id: str, changed_by: str | None = None, user_modified: bool = True) -> dict | None:
        now           = datetime.utcnow().isoformat()
        allowed       = json.dumps(policy_data.get("allowed_sources", []))
        denied        = json.dumps(policy_data.get("denied_sources", []))
        allowed_tasks = json.dumps(policy_data.get("allowed_tasks", []))
        denied_tasks  = json.dumps(policy_data.get("denied_tasks", []))
        sensitivity   = policy_data.get("max_sensitivity", "high")
        agent_role    = policy_data["agent_role"]
        industry      = policy_data.get("industry")
        category      = policy_data.get("category")
        description   = policy_data.get("description")
        um_int        = 1 if user_modified else 0

        with sqlite3.connect(self.db_path) as conn:
            existing = conn.execute(
                """SELECT policy_id, version, agent_role, allowed_sources, denied_sources,
                          max_sensitivity, allowed_tasks, denied_tasks, industry, category, user_modified, description
                   FROM policies WHERE policy_id = ? AND tenant_id = ? AND is_active = 1""",
                (policy_id, tenant_id),
            ).fetchone()
            if not existing:
                return None
            version = existing[1]
            unchanged = (
                existing[2] == agent_role and existing[3] == allowed and
                existing[4] == denied and existing[5] == sensitivity and
                existing[6] == allowed_tasks and existing[7] == denied_tasks and
                existing[8] == industry and existing[9] == category and
                existing[10] == um_int and existing[11] == description
            )
            if not unchanged:
                new_version = version + 1
                conn.execute(
                    """UPDATE policies SET
                       agent_role=?, allowed_sources=?, denied_sources=?,
                       max_sensitivity=?, allowed_tasks=?, denied_tasks=?,
                       industry=?, category=?, updated_at=?, version=?, changed_by=?, user_modified=?, description=?
                       WHERE policy_id=?""",
                    (agent_role, allowed, denied, sensitivity, allowed_tasks, denied_tasks,
                     industry, category, now, new_version, changed_by, um_int, description, policy_id),
                )
                conn.execute(
                    """INSERT INTO policy_versions
                       (version_id, policy_id, name, agent_role, allowed_sources,
                        denied_sources, max_sensitivity, allowed_tasks, denied_tasks,
                        industry, category, version, tenant_id, changed_by, changed_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (secrets.token_hex(8), policy_id,
                     conn.execute("SELECT name FROM policies WHERE policy_id=?", (policy_id,)).fetchone()[0],
                     agent_role, allowed, denied, sensitivity, allowed_tasks, denied_tasks,
                     industry, category, new_version, tenant_id, changed_by, now),
                )
                conn.commit()
        return self.get_by_id(policy_id, tenant_id)

    def get_history(self, name: str, tenant_id: str) -> list[dict]:
        with sqlite3.connect(self.db_path) as conn:
            # Get the policy_id first
            row = conn.execute(
                "SELECT policy_id FROM policies WHERE name = ? AND tenant_id = ?",
                (name, tenant_id),
            ).fetchone()
            if not row:
                return []
            policy_id = row[0]
            rows = conn.execute(
                """SELECT version_id, version, agent_role, allowed_sources, denied_sources,
                          max_sensitivity, changed_by, changed_at, allowed_tasks, denied_tasks,
                          industry, category
                   FROM policy_versions WHERE policy_id = ? AND tenant_id = ?
                   ORDER BY version DESC""",
                (policy_id, tenant_id),
            ).fetchall()
        return [
            {
                "version_id":      r[0],
                "version":         r[1],
                "agent_role":      r[2],
                "allowed_sources": json.loads(r[3]),
                "denied_sources":  json.loads(r[4]),
                "max_sensitivity": r[5],
                "changed_by":      r[6],
                "changed_at":      r[7],
                "allowed_tasks":   json.loads(r[8]) if r[8] else [],
                "denied_tasks":    json.loads(r[9]) if r[9] else [],
                "industry":        r[10],
                "category":        r[11],
            }
            for r in rows
        ]

    def get_history_by_id(self, policy_id: str, tenant_id: str) -> list[dict]:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                """SELECT version_id, version, agent_role, allowed_sources, denied_sources,
                          max_sensitivity, changed_by, changed_at, allowed_tasks, denied_tasks,
                          industry, category
                   FROM policy_versions WHERE policy_id = ? AND tenant_id = ?
                   ORDER BY version DESC""",
                (policy_id, tenant_id),
            ).fetchall()
        return [
            {
                "version_id":      r[0],
                "version":         r[1],
                "agent_role":      r[2],
                "allowed_sources": json.loads(r[3]),
                "denied_sources":  json.loads(r[4]),
                "max_sensitivity": r[5],
                "changed_by":      r[6],
                "changed_at":      r[7],
                "allowed_tasks":   json.loads(r[8]) if r[8] else [],
                "denied_tasks":    json.loads(r[9]) if r[9] else [],
                "industry":        r[10],
                "category":        r[11],
            }
            for r in rows
        ]

    def count(self, tenant_id: str) -> int:
        with sqlite3.connect(self.db_path) as conn:
            return conn.execute(
                "SELECT COUNT(*) FROM policies WHERE tenant_id = ? AND is_active = 1",
                (tenant_id,),
            ).fetchone()[0]

    def _row_to_dict(self, row) -> dict:
        return {
            "policy_id":       row[0],
            "name":            row[1],
            "agent_role":      row[2],
            "allowed_sources": json.loads(row[3]),
            "denied_sources":  json.loads(row[4]),
            "max_sensitivity": row[5],
            "version":         row[6],
            "created_at":      row[7],
            "updated_at":      row[8],
            "changed_by":      row[9],
            "allowed_tasks":   json.loads(row[10]) if row[10] else [],
            "denied_tasks":    json.loads(row[11]) if row[11] else [],
            "industry":        row[12] if len(row) > 12 else None,
            "category":        row[13] if len(row) > 13 else None,
            "user_modified":   bool(row[14]) if len(row) > 14 else False,
            "description":     row[15] if len(row) > 15 else None,
        }


class SQLiteAlertStore(AlertStoreBase):

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS alert_rules (
                    rule_id          TEXT PRIMARY KEY,
                    tenant_id        TEXT NOT NULL,
                    name             TEXT NOT NULL,
                    rule_type        TEXT NOT NULL,
                    threshold        INTEGER NOT NULL DEFAULT 5,
                    window_minutes   INTEGER NOT NULL DEFAULT 60,
                    cooldown_minutes INTEGER NOT NULL DEFAULT 60,
                    webhook_url      TEXT,
                    email            TEXT,
                    is_enabled       INTEGER NOT NULL DEFAULT 1,
                    created_at       TEXT NOT NULL,
                    last_fired_at    TEXT
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS alert_deliveries (
                    delivery_id TEXT PRIMARY KEY,
                    rule_id     TEXT NOT NULL,
                    tenant_id   TEXT NOT NULL,
                    fired_at    TEXT NOT NULL,
                    rule_name   TEXT NOT NULL,
                    rule_type   TEXT NOT NULL,
                    detail      TEXT NOT NULL,
                    status      TEXT NOT NULL,
                    error       TEXT
                )
            """)
            conn.commit()

    def create_rule(self, rule: dict, tenant_id: str) -> str:
        rule_id = "alr_" + secrets.token_hex(8)
        now = datetime.utcnow().isoformat()
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT INTO alert_rules
                   (rule_id, tenant_id, name, rule_type, threshold, window_minutes,
                    cooldown_minutes, webhook_url, email, is_enabled, created_at)
                   VALUES (?,?,?,?,?,?,?,?,?,1,?)""",
                (rule_id, tenant_id, rule["name"], rule["rule_type"],
                 rule.get("threshold", 5), rule.get("window_minutes", 60),
                 rule.get("cooldown_minutes", 60),
                 rule.get("webhook_url"), rule.get("email"), now),
            )
            conn.commit()
        return rule_id

    def get_rule(self, rule_id: str, tenant_id: str) -> dict | None:
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT * FROM alert_rules WHERE rule_id=? AND tenant_id=?",
                (rule_id, tenant_id),
            ).fetchone()
        return self._rule_row(row) if row else None

    def list_rules(self, tenant_id: str) -> list[dict]:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT * FROM alert_rules WHERE tenant_id=? ORDER BY created_at",
                (tenant_id,),
            ).fetchall()
        return [self._rule_row(r) for r in rows]

    def update_rule(self, rule_id: str, updates: dict, tenant_id: str) -> bool:
        allowed = {"name", "threshold", "window_minutes", "cooldown_minutes",
                   "webhook_url", "email", "is_enabled"}
        fields = {k: v for k, v in updates.items() if k in allowed}
        if not fields:
            return False
        set_clause = ", ".join(f"{k}=?" for k in fields)
        with sqlite3.connect(self.db_path) as conn:
            cur = conn.execute(
                f"UPDATE alert_rules SET {set_clause} WHERE rule_id=? AND tenant_id=?",
                (*fields.values(), rule_id, tenant_id),
            )
            conn.commit()
        return cur.rowcount > 0

    def delete_rule(self, rule_id: str, tenant_id: str) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cur = conn.execute(
                "DELETE FROM alert_rules WHERE rule_id=? AND tenant_id=?",
                (rule_id, tenant_id),
            )
            conn.commit()
        return cur.rowcount > 0

    def mark_fired(self, rule_id: str, fired_at: str) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "UPDATE alert_rules SET last_fired_at=? WHERE rule_id=?",
                (fired_at, rule_id),
            )
            conn.commit()

    def record_delivery(self, delivery: dict) -> None:
        delivery_id = secrets.token_hex(12)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT INTO alert_deliveries
                   (delivery_id, rule_id, tenant_id, fired_at, rule_name,
                    rule_type, detail, status, error)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (delivery_id, delivery["rule_id"], delivery["tenant_id"],
                 delivery["fired_at"], delivery["rule_name"], delivery["rule_type"],
                 delivery["detail"], delivery["status"], delivery.get("error")),
            )
            conn.commit()

    def list_deliveries(self, tenant_id: str, limit: int = 50) -> list[dict]:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                """SELECT delivery_id, rule_id, tenant_id, fired_at, rule_name,
                          rule_type, detail, status, error
                   FROM alert_deliveries WHERE tenant_id=?
                   ORDER BY fired_at DESC LIMIT ?""",
                (tenant_id, limit),
            ).fetchall()
        return [
            {
                "delivery_id": r[0], "rule_id": r[1], "tenant_id": r[2],
                "fired_at": r[3], "rule_name": r[4], "rule_type": r[5],
                "detail": json.loads(r[6]), "status": r[7], "error": r[8],
            }
            for r in rows
        ]

    def _rule_row(self, row) -> dict:
        return {
            "rule_id": row[0], "tenant_id": row[1], "name": row[2],
            "rule_type": row[3], "threshold": row[4], "window_minutes": row[5],
            "cooldown_minutes": row[6], "webhook_url": row[7], "email": row[8],
            "is_enabled": bool(row[9]), "created_at": row[10], "last_fired_at": row[11],
        }


class SQLiteLineageStore(LineageStoreBase):

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS agent_actions (
                    action_id     TEXT PRIMARY KEY,
                    event_id      TEXT NOT NULL,
                    session_id    TEXT NOT NULL,
                    agent_role    TEXT NOT NULL,
                    action_type   TEXT NOT NULL,
                    action_detail TEXT NOT NULL DEFAULT '{}',
                    outcome       TEXT,
                    timestamp     TEXT NOT NULL,
                    tenant_id     TEXT NOT NULL
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_actions_event_id ON agent_actions(event_id, tenant_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_actions_session_id ON agent_actions(session_id, tenant_id)")
            conn.commit()

    def record_action(self, action: AgentAction, tenant_id: str) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT INTO agent_actions
                   (action_id, event_id, session_id, agent_role, action_type,
                    action_detail, outcome, timestamp, tenant_id)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (
                    action.action_id, action.event_id, action.session_id,
                    action.agent_role, action.action_type,
                    json.dumps(action.action_detail),
                    action.outcome,
                    action.timestamp.isoformat(),
                    tenant_id,
                ),
            )
            conn.commit()

    def get_actions_for_event(self, event_id: str, tenant_id: str) -> list[AgentAction]:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                """SELECT action_id, event_id, session_id, agent_role, action_type,
                          action_detail, outcome, timestamp
                   FROM agent_actions WHERE event_id = ? AND tenant_id = ?
                   ORDER BY timestamp""",
                (event_id, tenant_id),
            ).fetchall()
        return [self._row_to_action(r) for r in rows]

    def get_actions_for_session(self, session_id: str, tenant_id: str) -> list[AgentAction]:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                """SELECT action_id, event_id, session_id, agent_role, action_type,
                          action_detail, outcome, timestamp
                   FROM agent_actions WHERE session_id = ? AND tenant_id = ?
                   ORDER BY timestamp""",
                (session_id, tenant_id),
            ).fetchall()
        return [self._row_to_action(r) for r in rows]

    def _row_to_action(self, row) -> AgentAction:
        return AgentAction(
            action_id=row[0],
            event_id=row[1],
            session_id=row[2],
            agent_role=row[3],
            action_type=row[4],
            action_detail=json.loads(row[5]),
            outcome=row[6],
            timestamp=datetime.fromisoformat(row[7]),
        )


class SQLiteSessionStore(SessionStoreBase):
    """Tracks session lifecycle: creation, activity, TTL expiration, and revocation."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS sessions (
                    session_id         TEXT NOT NULL,
                    tenant_id          TEXT NOT NULL,
                    agent_role         TEXT NOT NULL,
                    user_id            TEXT NOT NULL,
                    created_at         TEXT NOT NULL,
                    last_active        TEXT NOT NULL,
                    expires_at         TEXT,
                    ttl_minutes        INTEGER,
                    is_revoked         INTEGER NOT NULL DEFAULT 0,
                    context_hash       TEXT,
                    revocation_reason  TEXT,
                    revoked_at         TEXT,
                    PRIMARY KEY (session_id, tenant_id)
                )
            """)
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_sessions_tenant ON sessions(tenant_id, created_at)"
            )
            # Migrations: add columns for databases created before this schema
            for col_ddl in (
                "ALTER TABLE sessions ADD COLUMN context_hash TEXT",
                "ALTER TABLE sessions ADD COLUMN revocation_reason TEXT",
                "ALTER TABLE sessions ADD COLUMN revoked_at TEXT",
            ):
                try:
                    conn.execute(col_ddl)
                except sqlite3.OperationalError:
                    pass  # column already exists
            conn.commit()

    def create_session(
        self,
        session_id: str,
        agent_role: str,
        user_id: str,
        tenant_id: str,
        ttl_minutes: int | None = None,
    ) -> None:
        now = datetime.now(timezone.utc)
        expires_at = (
            (now + timedelta(minutes=ttl_minutes)).isoformat()
            if ttl_minutes is not None
            else None
        )
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT OR IGNORE INTO sessions
                   (session_id, tenant_id, agent_role, user_id,
                    created_at, last_active, expires_at, ttl_minutes)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (
                    session_id, tenant_id, agent_role, user_id,
                    now.isoformat(), now.isoformat(),
                    expires_at, ttl_minutes,
                ),
            )
            conn.commit()

    def get_session(self, session_id: str, tenant_id: str) -> dict | None:
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                """SELECT session_id, tenant_id, agent_role, user_id,
                          created_at, last_active, expires_at, ttl_minutes, is_revoked,
                          context_hash, revocation_reason, revoked_at
                   FROM sessions WHERE session_id = ? AND tenant_id = ?""",
                (session_id, tenant_id),
            ).fetchone()
        if row is None:
            return None
        return self._row_to_session(row)

    def touch_session(self, session_id: str, tenant_id: str, agent_role: str) -> bool:
        now = datetime.now(timezone.utc).isoformat()
        with sqlite3.connect(self.db_path) as conn:
            cur = conn.execute(
                """UPDATE sessions SET last_active = ?
                   WHERE session_id = ? AND tenant_id = ? AND agent_role = ?""",
                (now, session_id, tenant_id, agent_role),
            )
            conn.commit()
        return cur.rowcount > 0

    def revoke_session(
        self,
        session_id: str,
        tenant_id: str,
        reason: str = "admin_action",
    ) -> bool:
        now = datetime.now(timezone.utc).isoformat()
        with sqlite3.connect(self.db_path) as conn:
            cur = conn.execute(
                """UPDATE sessions
                   SET is_revoked = 1, revocation_reason = ?, revoked_at = ?
                   WHERE session_id = ? AND tenant_id = ?""",
                (reason, now, session_id, tenant_id),
            )
            conn.commit()
        return cur.rowcount > 0

    def list_sessions(self, tenant_id: str, include_expired: bool = False) -> list[dict]:
        now = datetime.now(timezone.utc).isoformat()
        with sqlite3.connect(self.db_path) as conn:
            if include_expired:
                rows = conn.execute(
                    """SELECT session_id, tenant_id, agent_role, user_id,
                              created_at, last_active, expires_at, ttl_minutes, is_revoked,
                              context_hash, revocation_reason, revoked_at
                       FROM sessions WHERE tenant_id = ?
                       ORDER BY created_at DESC""",
                    (tenant_id,),
                ).fetchall()
            else:
                rows = conn.execute(
                    """SELECT session_id, tenant_id, agent_role, user_id,
                              created_at, last_active, expires_at, ttl_minutes, is_revoked,
                              context_hash, revocation_reason, revoked_at
                       FROM sessions
                       WHERE tenant_id = ?
                         AND is_revoked = 0
                         AND (expires_at IS NULL OR expires_at > ?)
                       ORDER BY created_at DESC""",
                    (tenant_id, now),
                ).fetchall()
        return [self._row_to_session(r) for r in rows]

    def is_valid(self, session_id: str, tenant_id: str) -> tuple[bool, str]:
        session = self.get_session(session_id, tenant_id)
        if session is None:
            return False, "session_not_found"
        if session["is_revoked"]:
            return False, "session_revoked"
        if session["expires_at"] is not None:
            now = datetime.now(timezone.utc)
            expires = datetime.fromisoformat(session["expires_at"])
            if expires.tzinfo is None:
                expires = expires.replace(tzinfo=timezone.utc)
            if now > expires:
                return False, "session_expired"
        return True, ""

    def update_session_context_hash(
        self,
        session_id: str,
        tenant_id: str,
        event_context_hash: str,
    ) -> None:
        import hashlib
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT context_hash FROM sessions WHERE session_id = ? AND tenant_id = ?",
                (session_id, tenant_id),
            ).fetchone()
            if row is None:
                return
            prev = row[0] or ""
            new_hash = hashlib.sha256(
                (prev + event_context_hash).encode()
            ).hexdigest()
            conn.execute(
                "UPDATE sessions SET context_hash = ? WHERE session_id = ? AND tenant_id = ?",
                (new_hash, session_id, tenant_id),
            )
            conn.commit()

    def revoke_sessions_by(
        self,
        tenant_id: str,
        agent_role: str | None = None,
        user_id: str | None = None,
        reason: str = "bulk_revocation",
    ) -> int:
        if agent_role is None and user_id is None:
            raise ValueError("At least one of agent_role or user_id must be provided")
        now = datetime.now(timezone.utc).isoformat()
        clauses = ["tenant_id = ?", "is_revoked = 0"]
        params: list = [reason, now, tenant_id]
        if agent_role is not None:
            clauses.append("agent_role = ?")
            params.append(agent_role)
        if user_id is not None:
            clauses.append("user_id = ?")
            params.append(user_id)
        sql = (
            f"UPDATE sessions SET is_revoked = 1, revocation_reason = ?, revoked_at = ? "
            f"WHERE {' AND '.join(clauses)}"
        )
        with sqlite3.connect(self.db_path) as conn:
            cur = conn.execute(sql, params)
            conn.commit()
        return cur.rowcount

    def purge_expired_sessions(self, retention_days: int) -> int:
        cutoff = (datetime.now(timezone.utc) - timedelta(days=retention_days)).isoformat()
        with sqlite3.connect(self.db_path) as conn:
            cur = conn.execute(
                """DELETE FROM sessions
                   WHERE (is_revoked = 1 AND last_active < ?)
                      OR (expires_at IS NOT NULL AND expires_at < ?)""",
                (cutoff, cutoff),
            )
            conn.commit()
        return cur.rowcount

    def _row_to_session(self, row) -> dict:
        return {
            "session_id":        row[0],
            "tenant_id":         row[1],
            "agent_role":        row[2],
            "user_id":           row[3],
            "created_at":        row[4],
            "last_active":       row[5],
            "expires_at":        row[6],
            "ttl_minutes":       row[7],
            "is_revoked":        bool(row[8]),
            "context_hash":      row[9],
            "revocation_reason": row[10],
            "revoked_at":        row[11],
        }


class SQLiteAgentRegistryStore(AgentRegistryStoreBase):

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS agent_registry (
                    agent_id      TEXT NOT NULL,
                    tenant_id     TEXT NOT NULL,
                    agent_role    TEXT NOT NULL,
                    display_name  TEXT NOT NULL,
                    description   TEXT,
                    owner         TEXT,
                    framework     TEXT,
                    policy_name   TEXT,
                    status        TEXT NOT NULL DEFAULT 'draft',
                    version       TEXT NOT NULL DEFAULT '1.0.0',
                    created_at    TEXT NOT NULL,
                    updated_at    TEXT NOT NULL,
                    created_by    TEXT,
                    approved_by   TEXT,
                    approved_at   TEXT,
                    PRIMARY KEY (agent_id, tenant_id)
                )
            """)
            conn.execute(
                """CREATE UNIQUE INDEX IF NOT EXISTS idx_agent_registry_role_tenant
                   ON agent_registry(agent_role, tenant_id)"""
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_agent_registry_tenant ON agent_registry(tenant_id)"
            )
            conn.commit()

    def ensure_registered(self, agent_role: str, tenant_id: str) -> str:
        now = datetime.utcnow().isoformat()
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT agent_id FROM agent_registry WHERE agent_role = ? AND tenant_id = ?",
                (agent_role, tenant_id),
            ).fetchone()
            if row:
                return row[0]
            agent_id = str(uuid.uuid4())
            display_name = agent_role.replace("_", " ").title()
            conn.execute(
                """INSERT INTO agent_registry
                   (agent_id, tenant_id, agent_role, display_name, status, version,
                    created_at, updated_at)
                   VALUES (?, ?, ?, ?, 'draft', '1.0.0', ?, ?)""",
                (agent_id, tenant_id, agent_role, display_name, now, now),
            )
            conn.commit()
        return agent_id

    def create(self, entry: AgentRegistryEntry, tenant_id: str) -> str:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT OR IGNORE INTO agent_registry
                   (agent_id, tenant_id, agent_role, display_name, description, owner,
                    framework, policy_name, status, version, created_at, updated_at,
                    created_by, approved_by, approved_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    entry.agent_id, tenant_id, entry.agent_role, entry.display_name,
                    entry.description, entry.owner, entry.framework, entry.policy_name,
                    entry.status, entry.version,
                    _ts_str(entry.created_at), _ts_str(entry.updated_at),
                    entry.created_by, entry.approved_by,
                    _ts_str(entry.approved_at) if entry.approved_at else None,
                ),
            )
            conn.commit()
        return entry.agent_id

    def get(self, agent_id: str, tenant_id: str) -> AgentRegistryEntry | None:
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT * FROM agent_registry WHERE agent_id = ? AND tenant_id = ?",
                (agent_id, tenant_id),
            ).fetchone()
        return self._row_to_entry(row) if row else None

    def get_by_role(self, agent_role: str, tenant_id: str) -> AgentRegistryEntry | None:
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT * FROM agent_registry WHERE agent_role = ? AND tenant_id = ?",
                (agent_role, tenant_id),
            ).fetchone()
        return self._row_to_entry(row) if row else None

    def list_agents(
        self,
        tenant_id: str,
        status: str | None = None,
        framework: str | None = None,
        owner: str | None = None,
    ) -> list[AgentRegistryEntry]:
        query = "SELECT * FROM agent_registry WHERE tenant_id = ?"
        params: list = [tenant_id]
        if status:
            query += " AND status = ?"
            params.append(status)
        if framework:
            query += " AND framework = ?"
            params.append(framework)
        if owner:
            query += " AND owner = ?"
            params.append(owner)
        query += " ORDER BY display_name"
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(query, params).fetchall()
        return [self._row_to_entry(r) for r in rows]

    def update(self, agent_id: str, updates: dict, tenant_id: str) -> bool:
        allowed = {"display_name", "description", "owner", "framework", "policy_name", "version"}
        fields = {k: v for k, v in updates.items() if k in allowed}
        if not fields:
            return False
        fields["updated_at"] = datetime.utcnow().isoformat()
        set_clause = ", ".join(f"{k} = ?" for k in fields)
        values = list(fields.values()) + [agent_id, tenant_id]
        with sqlite3.connect(self.db_path) as conn:
            cur = conn.execute(
                f"UPDATE agent_registry SET {set_clause} WHERE agent_id = ? AND tenant_id = ?",
                values,
            )
            conn.commit()
        return cur.rowcount > 0

    def update_status(
        self,
        agent_id: str,
        status: str,
        tenant_id: str,
        approved_by: str | None = None,
    ) -> bool:
        now = datetime.utcnow().isoformat()
        if status == "approved" and approved_by:
            with sqlite3.connect(self.db_path) as conn:
                cur = conn.execute(
                    """UPDATE agent_registry
                       SET status = ?, approved_by = ?, approved_at = ?, updated_at = ?
                       WHERE agent_id = ? AND tenant_id = ?""",
                    (status, approved_by, now, now, agent_id, tenant_id),
                )
                conn.commit()
        else:
            with sqlite3.connect(self.db_path) as conn:
                cur = conn.execute(
                    """UPDATE agent_registry SET status = ?, updated_at = ?
                       WHERE agent_id = ? AND tenant_id = ?""",
                    (status, now, agent_id, tenant_id),
                )
                conn.commit()
        return cur.rowcount > 0

    def get_activity_stats(self, agent_roles: list[str], tenant_id: str, days: int = 7) -> dict:
        if not agent_roles:
            return {}
        cutoff = (datetime.utcnow() - timedelta(days=days)).isoformat()
        placeholders = ",".join("?" * len(agent_roles))
        try:
            with sqlite3.connect(self.db_path) as conn:
                rows = conn.execute(
                    f"""SELECT agent_role,
                               MAX(timestamp)  AS last_active,
                               COUNT(*)        AS total,
                               SUM(CASE WHEN decision = 'DENY' THEN 1 ELSE 0 END) AS denies
                        FROM audit_events
                        WHERE tenant_id = ?
                          AND agent_role IN ({placeholders})
                          AND timestamp >= ?
                        GROUP BY agent_role""",
                    [tenant_id] + agent_roles + [cutoff],
                ).fetchall()
        except sqlite3.OperationalError:
            return {}
        return {
            r[0]: {
                "last_active":    r[1],
                "event_count_7d": r[2],
                "deny_rate_7d":   round(r[3] / r[2], 3) if r[2] > 0 else 0.0,
            }
            for r in rows
        }

    def _row_to_entry(self, row) -> AgentRegistryEntry:
        return AgentRegistryEntry(
            agent_id=row[0],
            tenant_id=row[1],
            agent_role=row[2],
            display_name=row[3],
            description=row[4],
            owner=row[5],
            framework=row[6],
            policy_name=row[7],
            status=row[8],
            version=row[9],
            created_at=datetime.fromisoformat(row[10]),
            updated_at=datetime.fromisoformat(row[11]),
            created_by=row[12],
            approved_by=row[13],
            approved_at=datetime.fromisoformat(row[14]) if row[14] else None,
        )
