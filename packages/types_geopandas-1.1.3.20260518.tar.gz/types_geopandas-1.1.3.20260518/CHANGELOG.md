## 1.1.3.20260518 (2026-05-18)

Upgrade black to 26.5.0 ([#15801](https://github.com/python/typeshed/pull/15801))

## 1.1.3.20260508 (2026-05-08)

Import some items from typing instead of typing_extensions ([#15711](https://github.com/python/typeshed/pull/15711))

Part of #13782

## 1.1.3.20260408 (2026-04-08)

Use dashes instead of underscores for METADATA.toml field names ([#15614](https://github.com/python/typeshed/pull/15614))

## 1.1.3.20260402 (2026-04-02)

Rename `requires` to `dependencies` in METADATA files ([#15594](https://github.com/python/typeshed/pull/15594))

Update mypy to 1.20.0 ([#15588](https://github.com/python/typeshed/pull/15588))

## 1.1.3.20260311 (2026-03-11)

[stubsabot] Bump geopandas to 1.1.3 ([#15499](https://github.com/python/typeshed/pull/15499))

## 1.1.2.20260120 (2026-01-20)

[geopandas] Add lz4 and zstd compression to to_parquet ([#15195](https://github.com/python/typeshed/pull/15195))

## 1.1.2.20251224 (2025-12-24)

[geopandas] Update to 1.1.2 ([#15170](https://github.com/python/typeshed/pull/15170))

## 1.1.1.20251214 (2025-12-14)

[geopandas] Unpin pandas-stubs ([#15134](https://github.com/python/typeshed/pull/15134))

## 1.1.1.20251203 (2025-12-03)

Pin dependencies on pandas-stubs to < 2.3.3.251201 ([#15100](https://github.com/python/typeshed/pull/15100))

## 1.1.1.20250829 (2025-08-29)

[geopandas] Some @final methods are overridden ([#14657](https://github.com/python/typeshed/pull/14657))

## 1.1.1.20250809 (2025-08-09)

Mark stub-only private symbols as `@type_check_only` in third-party stubs ([#14545](https://github.com/python/typeshed/pull/14545))

## 1.1.1.20250708 (2025-07-08)

Bump geopandas stubs to version 1.1.1 ([#14244](https://github.com/python/typeshed/pull/14244))

## 1.0.1.20250601 (2025-06-01)

[geopandas] Add a # type: ignore ([#14200](https://github.com/python/typeshed/pull/14200))

Should help with #14194

## 1.0.1.20250528 (2025-05-28)

[geopandas] Unblock CI ([#14178](https://github.com/python/typeshed/pull/14178))

## 1.0.1.20250510 (2025-05-10)

[geopandas] Fix CI tests in some circumstances ([#13978](https://github.com/python/typeshed/pull/13978))

Add "libproj-dev" and "proj-bin" to apt_dependencies.
These packages are necessary to build the pyproj
dependency if a pre-built wheel is not available.

## 1.0.1.20250404 (2025-04-04)

Enable Ruff flake8-todos (TD) ([#13748](https://github.com/python/typeshed/pull/13748))

## 1.0.1.20250310 (2025-03-10)

Fix override issue in GeoDataFrame.astype return type ([#13606](https://github.com/python/typeshed/pull/13606))

## 1.0.1.20250304 (2025-03-04)

Drop flake8-noqa and remove workarounds to work with Ruff ([#13571](https://github.com/python/typeshed/pull/13571))

## 1.0.1.20250120 (2025-01-20)

Add geopandas stubs ([#12990](https://github.com/python/typeshed/pull/12990))

