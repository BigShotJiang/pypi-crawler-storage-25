"""augint-shell (ai-shell) - Launch AI coding tools and local LLMs in Docker containers."""

__version__ = "0.101.1"

__all__ = [
    "__version__",
]
