import json, os, requests, base64, urllib3, sys, keyboard, pyfiglet
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown
from rich.prompt import Prompt
from rich.text import Text
from rich.align import Align

# Отключаем ворнинги SSL
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
console = Console(width=80)

# Пути к БД (оставляем v69, как в оригинале)
MASTER_DIR = os.path.join(os.environ.get('APPDATA', os.path.expanduser("~")), "Matish_Clean_v69")
if not os.path.exists(MASTER_DIR): os.makedirs(MASTER_DIR)
LOCAL_DB = os.path.join(MASTER_DIR, "brain.dat")

def crypt(t): return base64.b64encode(json.dumps(t, ensure_ascii=False).encode('utf-8')).decode('utf-8')
def decrypt(t):
    try: return json.loads(base64.b64decode(t.encode('utf-8')).decode('utf-8'))
    except: return {}

def save_db(db):
    with open(LOCAL_DB, "w", encoding="utf-8") as f: f.write(crypt(db))

def get_db():
    if os.path.exists(LOCAL_DB):
        with open(LOCAL_DB, "r", encoding="utf-8") as f: return decrypt(f.read())
    return {}

def show_help():
    help_text = """
### [bold magenta]ФУНКЦИОНАЛ AI MATISH[/bold magenta]
* [bold cyan]LTM (Memory):[/bold cyan] Пиши '[yellow]запомни: [факт][/yellow]'.
* [bold cyan]Vault:[/bold cyan] '[yellow]save: [текст][/yellow]' / '[yellow]vault[/yellow]'.
* [bold cyan]Panic:[/bold cyan] [red]CTRL+B[/red].
* [bold cyan]Help:[/bold cyan] '[yellow]/help[/yellow]' — показать это меню.
    """
    console.print(Panel(Markdown(help_text), title="[bold yellow]HELP MENU[/bold yellow]", border_style="cyan"))

def ask_ai(text, profile, history):
    try:
        url = "https://text.pollinations.ai"
        gender_word = "парень" if profile.get("gender") == "м" else "девушка"
        dialog_chain = "\n".join(history[-6:])
        system_msg = (
            f"Ты AI Matish, бро. Твой создатель: Даниил Неструев. "
            f"Юзер: {profile['real_name']}, {profile['age']} лет, {gender_word}. "
            f"О нем знаю: {profile['mem']}. "
            f"ПРАВИЛО: Отвечай кратко. Контекст:\n{dialog_chain}"
        )
        payload = {"messages": [{"role": "system", "content": system_msg}, {"role": "user", "content": text}], "model": "openai"}
        res = requests.post(url, json=payload, timeout=25)
        return res.text.strip()
    except: return "⚠️ Обрыв связи."

def auth():
    os.system('cls' if os.name == 'nt' else 'clear')
    console.print(Align.center(Text(pyfiglet.Figlet(font='slant').renderText('MATISH AI'), style="bold magenta")))
    db = get_db()
    name = Prompt.ask("[bold magenta]┌──[/bold magenta][bold white] LOGIN[/bold white]").strip() or "DeLtA"
    is_delta = (name.lower() == "delta")
    if name in db:
        profile = db[name]
        pwd = Prompt.ask(f"[bold magenta]└──[/bold magenta][bold yellow] PASSWORD[/bold yellow]").strip()
        if str(profile.get("pass")) == str(pwd): return profile, is_delta, db
        else: sys.exit("Неверный пароль.")
    else:
        console.print(Panel("РЕГИСТРАЦИЯ НОВОГО ЯДРА", border_style="yellow"))
        pwd = Prompt.ask("[bold green]PASS[/bold green]").strip()
        r_name = Prompt.ask("[cyan]Имя[/cyan]").strip() or "Даня"
        age = Prompt.ask("[cyan]Лет[/cyan]").strip() or "12"
        gender = Prompt.ask("[cyan]Пол (м/ж)[/cyan]", choices=["м", "ж"])
        hobby = Prompt.ask("[cyan]Хобби[/cyan]").strip() or "кодинг"
        profile = {"name": name, "pass": pwd, "real_name": r_name, "age": age, "gender": gender, "hobby": hobby, "mem": "", "vault": []}
        db[name] = profile
        save_db(db)
        show_help()
        input("\nНажми Enter для запуска...")
        return profile, is_delta, db

def main():
    try:
        profile, is_delta, db = auth()
        os.system('cls' if os.name == 'nt' else 'clear')
        console.print(Align.center(pyfiglet.Figlet(font='slant').renderText('MATISH AI')))
        
        status = "[black on white] ROOT: DANIIL NESTRUEV [/black on white]" if is_delta else f"[bold white] USER: {profile['name']} [/bold white]"
        console.print(Align.center(Panel(status, border_style="magenta", expand=False)))
        
        chat_hist = []
        keyboard.add_hotkey('ctrl+b', lambda: (os.system('cls'), os._exit(0)))

        while True:
            cmd = console.input(f"\n[bold white]{profile['name']}@matish[/bold white]:~[bold red]{'#' if is_delta else '$'}[/bold red] ").strip()
            if not cmd or cmd.lower() in ['exit', 'q']: break
            if cmd.lower() == '/help': show_help(); continue
            if cmd.lower().startswith("запомни:"):
                profile["mem"] += f" {cmd[8:].strip()};"; save_db(db)
                console.print("[dim green]Запомнил.[/dim green]"); continue
            if cmd.lower().startswith("save:"):
                profile["vault"].append(cmd[5:].strip()); save_db(db)
                console.print("[dim cyan]В сейфе.[/dim cyan]"); continue
            if cmd.lower() == "vault":
                console.print(Panel("\n".join(profile["vault"]) or "Пусто.", title="VAULT")); continue

            with console.status("[bold yellow]Матиш думает..."):
                reply = ask_ai(cmd, profile, chat_hist)
            
            chat_hist.append(f"User: {cmd}")
            chat_hist.append(f"Matish: {reply}")
            console.print(Panel(Markdown(reply), title="[bold cyan]MATISH[/bold cyan]", border_style="cyan"))
    except KeyboardInterrupt:
        sys.exit(0)

if __name__ == "__main__":
    main()
