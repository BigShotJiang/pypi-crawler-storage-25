"""infinity_mouse package."""
