def test_import():
    import tversky
    assert tversky is not None

    from tversky import nn as tnn
    assert tnn is not None

def test_similarity():
    from tversky import nn as tnn
    sim_layer = tnn.TverskySimilarity(
        embedding_dim=64,
        fbank_size=128,
        similarity_model='contrast',
        normalize=False
    )

def test_projection():
    from tversky import nn as tnn
    proj_layer = tnn.TverskyProjection(
        embedding_dim=64,
        class_count=10,
        fbank_size=128,
        similarity_model='contrast',
        normalize=False
    )
