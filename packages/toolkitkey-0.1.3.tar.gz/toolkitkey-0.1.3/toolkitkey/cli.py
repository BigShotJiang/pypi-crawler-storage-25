"""CLI entry point for toolkitkey."""

import argparse
import os
import sys

from . import __version__


def get_keys_content():
    """Read and return the contents of keys.txt bundled with the package."""
    keys_path = os.path.join(os.path.dirname(__file__), "keys.txt")
    with open(keys_path, "r", encoding="utf-8") as f:
        return f.read()


def display_full_page(content):
    """Display the complete formatted page with keys and commands."""
    lines = content.splitlines()

    # Separate keys and commands sections
    keys_lines = []
    cmd_lines = []
    in_commands = False

    for line in lines:
        if line.strip() == "---COMMANDS---":
            in_commands = True
            continue
        if in_commands:
            if line.strip():
                cmd_lines.append(line.strip())
        else:
            if line.strip():
                keys_lines.append(line.strip())

    width = 60
    border = "=" * width

    # Header
    print()
    print(border)
    print(f"{'TOOLKITKEY v' + __version__:^{width}}")
    print(f"{'Shared API Keys & Commands':^{width}}")
    print(border)

    # Keys section
    print()
    print(f"  {'API KEYS':^{width - 4}}")
    print(f"  {'-' * (width - 4)}")
    for line in keys_lines:
        if "=" in line:
            name, value = line.split("=", 1)
            value = value.strip('"')
            keys = value.split(",")
            print(f"  {name.strip()}:")
            for i, key in enumerate(keys, 1):
                print(f"    Key {i}: {key.strip()}")
        print()

    # Commands section
    print(f"  {'TOOLKITMAD COMMANDS':^{width - 4}}")
    print(f"  {'-' * (width - 4)}")
    for cmd in cmd_lines:
        if "(" in cmd:
            parts = cmd.split("(", 1)
            print(f"  $ {parts[0].strip()}")
            print(f"    ({parts[1]}")
        else:
            print(f"  $ {cmd}")
    print()
    print(border)
    print()


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="toolkitkey",
        description="Display shared API keys and toolkitmad commands",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"toolkitkey {__version__}",
    )
    parser.add_argument(
        "--key",
        type=str,
        metavar="NAME",
        help="Show keys for a specific person (e.g. AJ, Anantha, adi)",
    )

    args = parser.parse_args()
    content = get_keys_content()

    if args.key:
        # Search for a specific person's keys
        found = False
        for line in content.splitlines():
            line_stripped = line.strip()
            if line_stripped.lower().startswith(args.key.lower() + "="):
                name, value = line_stripped.split("=", 1)
                value = value.strip('"')
                keys = value.split(",")
                print(f"\n  {name.strip()}:")
                for i, key in enumerate(keys, 1):
                    print(f"    Key {i}: {key.strip()}")
                print()
                found = True
                break
        if not found:
            print(f"No keys found for '{args.key}'")
            sys.exit(1)
    else:
        # Show the complete page
        display_full_page(content)


if __name__ == "__main__":
    main()
