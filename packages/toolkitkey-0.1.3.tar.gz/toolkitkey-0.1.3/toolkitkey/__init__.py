"""toolkitkey - Quick access to shared API keys."""

__version__ = "0.1.3"
