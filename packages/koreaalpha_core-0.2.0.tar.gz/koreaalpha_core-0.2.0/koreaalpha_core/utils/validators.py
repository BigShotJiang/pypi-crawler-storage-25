"""입력 검증 유틸리티."""

import re


def validate_kr_stock_code(code: str) -> bool:
    """한국 종목코드(6자리 숫자) 검증."""
    return bool(re.match(r"^\d{6}$", code))


def validate_us_ticker(ticker: str) -> bool:
    """미국 종목코드 검증 (1~5자 영문대문자)."""
    return bool(re.match(r"^[A-Z]{1,5}$", ticker))


def validate_portfolio_weights(weights: list[float], tolerance: float = 0.01) -> bool:
    """포트폴리오 비중 합계가 1.0(100%)인지 검증합니다."""
    total = sum(weights)
    return abs(total - 1.0) <= tolerance


def validate_date_yyyymmdd(date: str) -> bool:
    """YYYYMMDD 형식 날짜 검증."""
    return bool(re.match(r"^\d{8}$", date))
