"""출력 포맷팅 유틸리티."""


def format_percentage(value: float, decimals: int = 2) -> str:
    """숫자를 퍼센트 문자열로 포맷합니다. 0.1234 → '12.34%'"""
    return f"{value * 100:.{decimals}f}%"


def format_currency(value: float, currency: str = "KRW") -> str:
    """금액을 통화 형식으로 포맷합니다. 1234567 → '1,234,567원'"""
    if currency == "KRW":
        if abs(value) >= 1_0000_0000_0000:
            return f"{value / 1_0000_0000_0000:.1f}조원"
        if abs(value) >= 1_0000_0000:
            return f"{value / 1_0000_0000:.0f}억원"
        return f"{value:,.0f}원"
    elif currency == "USD":
        return f"${value:,.2f}"
    return f"{value:,.2f} {currency}"


def format_number(value: float, decimals: int = 2) -> str:
    """숫자를 포맷합니다. 1.2345 → '1.23'"""
    return f"{value:,.{decimals}f}"
