"""한국 시장 특화 모듈.

한국 거래일, 거래 비용, 세금 계산.
공휴일 계산은 korean-holidays 패키지에 위임합니다.
세율은 기본값으로 제공하되 파라미터로 override 가능합니다.
"""

from datetime import date, timedelta

# korean-holidays 패키지에서 공휴일/거래일 계산 위임
from korean_holidays import (
    is_holiday as _is_holiday,
    is_trading_day as is_kr_trading_day,
    get_trading_days,
    count_trading_days,
)

# 기본 세율 (2026년 기준, 변경 시 파라미터로 override)
DEFAULT_SECURITIES_TAX_RATE = 0.0018  # 매도 시 0.18%
DEFAULT_BROKERAGE_FEE_RATE = 0.00015  # 증권사 수수료 (편도)
DEFAULT_DIVIDEND_TAX_RATE = 0.154  # 배당소득세 (원천징수 15.4%)
DEFAULT_OVERSEAS_CGT_RATE = 0.22   # 해외주식 양도소득세 22%
DEFAULT_OVERSEAS_CGT_DEDUCTION = 2_500_000  # 해외주식 양도차익 공제 250만원
DEFAULT_FINANCIAL_INCOME_THRESHOLD = 20_000_000  # 금융소득종합과세 기준 2,000만원


def calc_transaction_cost(
    amount: float,
    is_sell: bool = False,
    brokerage_rate: float = DEFAULT_BROKERAGE_FEE_RATE,
    securities_tax_rate: float = DEFAULT_SECURITIES_TAX_RATE,
) -> float:
    """거래 비용을 계산합니다.

    Args:
        amount: 거래 금액
        is_sell: 매도 여부 (매도 시 증권거래세 추가)
        brokerage_rate: 증권사 수수료율
        securities_tax_rate: 증권거래세율

    Returns:
        총 거래 비용
    """
    cost = abs(amount) * brokerage_rate
    if is_sell:
        cost += abs(amount) * securities_tax_rate
    return cost


def calc_round_trip_cost(
    amount: float,
    brokerage_rate: float = DEFAULT_BROKERAGE_FEE_RATE,
    securities_tax_rate: float = DEFAULT_SECURITIES_TAX_RATE,
) -> float:
    """왕복 거래 비용 (매수+매도)을 계산합니다."""
    buy_cost = calc_transaction_cost(amount, is_sell=False, brokerage_rate=brokerage_rate)
    sell_cost = calc_transaction_cost(amount, is_sell=True, brokerage_rate=brokerage_rate, securities_tax_rate=securities_tax_rate)
    return buy_cost + sell_cost


def calc_dividend_tax(
    dividend: float,
    tax_rate: float = DEFAULT_DIVIDEND_TAX_RATE,
    threshold: float = DEFAULT_FINANCIAL_INCOME_THRESHOLD,
) -> dict:
    """배당소득세를 계산합니다.

    Args:
        dividend: 배당금
        tax_rate: 원천징수 세율 (기본 15.4%)
        threshold: 금융소득종합과세 기준 (기본 2,000만원)

    Returns:
        {"gross": 배당금, "tax": 세금, "net": 세후, "is_over_threshold": 종합과세 대상}
    """
    tax = dividend * tax_rate
    return {
        "gross": round(dividend),
        "tax": round(tax),
        "net": round(dividend - tax),
        "is_over_threshold": dividend > threshold,
    }


def calc_overseas_cgt(
    gain: float,
    tax_rate: float = DEFAULT_OVERSEAS_CGT_RATE,
    deduction: float = DEFAULT_OVERSEAS_CGT_DEDUCTION,
) -> dict:
    """해외주식 양도소득세를 계산합니다 (연간 기준).

    Args:
        gain: 연간 양도차익
        tax_rate: 양도소득세율 (기본 22%)
        deduction: 기본 공제 (기본 250만원)

    Returns:
        {"gain": 차익, "deduction": 공제, "taxable": 과세대상, "tax": 세금, "net": 세후}
    """
    if gain <= 0:
        return {"gain": round(gain), "deduction": 0, "taxable": 0, "tax": 0, "net": round(gain)}
    taxable = max(gain - deduction, 0)
    tax = taxable * tax_rate
    return {
        "gain": round(gain),
        "deduction": deduction,
        "taxable": round(taxable),
        "tax": round(tax),
        "net": round(gain - tax),
    }


def calc_after_tax_return(
    gross_return: float,
    investment: float,
    dividend_income: float = 0,
    overseas_gain: float = 0,
    dividend_tax_rate: float = DEFAULT_DIVIDEND_TAX_RATE,
    overseas_cgt_rate: float = DEFAULT_OVERSEAS_CGT_RATE,
    overseas_cgt_deduction: float = DEFAULT_OVERSEAS_CGT_DEDUCTION,
) -> dict:
    """세후 실질 수익률을 계산합니다.

    Args:
        gross_return: 세전 총 수익률 (예: 0.12 = 12%)
        investment: 투자 원금
        dividend_income: 연간 배당 수입
        overseas_gain: 해외주식 양도차익
        dividend_tax_rate: 배당소득세율
        overseas_cgt_rate: 해외주식 양도소득세율
        overseas_cgt_deduction: 해외주식 양도차익 공제

    Returns:
        {"gross_return": 세전, "after_tax_return": 세후, "total_tax": 총 세금}
    """
    gross_profit = investment * gross_return

    div_tax = dividend_income * dividend_tax_rate if dividend_income > 0 else 0

    overseas_tax = 0
    if overseas_gain > 0:
        taxable = max(overseas_gain - overseas_cgt_deduction, 0)
        overseas_tax = taxable * overseas_cgt_rate

    total_tax = div_tax + overseas_tax
    net_profit = gross_profit - total_tax
    after_tax_return = net_profit / investment if investment > 0 else 0

    return {
        "gross_return": round(gross_return, 6),
        "after_tax_return": round(after_tax_return, 6),
        "total_tax": round(total_tax),
    }
