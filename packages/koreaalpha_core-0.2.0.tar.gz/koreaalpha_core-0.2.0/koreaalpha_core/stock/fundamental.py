"""펀더멘탈 분석 모듈.

PER, PBR, ROE, 부채비율, FCF 등 기본적 분석 지표를 계산합니다.
"""

from dataclasses import dataclass


@dataclass
class FundamentalMetrics:
    """펀더멘탈 지표 종합."""

    per: float | None  # 주가수익비율
    pbr: float | None  # 주가순자산비율
    roe: float | None  # 자기자본이익률
    roa: float | None  # 총자산이익률
    debt_ratio: float | None  # 부채비율
    operating_margin: float | None  # 영업이익률
    net_margin: float | None  # 순이익률
    fcf_yield: float | None  # FCF 수익률
    dividend_yield: float | None  # 배당수익률


def calculate_per(price: float, eps: float, allow_negative: bool = True) -> float | None:
    """주가수익비율(PER)을 계산합니다.

    Args:
        price: 현재 주가
        eps: 주당순이익 (EPS)
        allow_negative: True이면 적자 기업도 음수 PER 반환 (한국 관행)

    Returns:
        PER (eps가 0이면 None)
    """
    if eps == 0:
        return None
    if eps < 0 and not allow_negative:
        return None
    return round(price / eps, 2)


def calculate_pbr(price: float, bps: float) -> float | None:
    """주가순자산비율(PBR)을 계산합니다.

    Args:
        price: 현재 주가
        bps: 주당순자산가치 (BPS)

    Returns:
        PBR
    """
    if bps <= 0:
        return None
    return round(price / bps, 2)


def calculate_roe(net_income: float, equity: float) -> float | None:
    """자기자본이익률(ROE)을 계산합니다.

    Args:
        net_income: 당기순이익
        equity: 자기자본

    Returns:
        ROE (예: 0.15 = 15%)
    """
    if equity <= 0:
        return None
    return round(net_income / equity, 4)


def calculate_roa(net_income: float, total_assets: float) -> float | None:
    """총자산이익률(ROA)을 계산합니다."""
    if total_assets <= 0:
        return None
    return round(net_income / total_assets, 4)


def calculate_debt_ratio(
    total_liabilities: float, equity: float
) -> float | None:
    """부채비율을 계산합니다.

    Args:
        total_liabilities: 총부채
        equity: 자기자본

    Returns:
        부채비율 (예: 1.5 = 150%)
    """
    if equity <= 0:
        return None
    return round(total_liabilities / equity, 4)


def calculate_operating_margin(
    operating_income: float, revenue: float
) -> float | None:
    """영업이익률을 계산합니다."""
    if revenue <= 0:
        return None
    return round(operating_income / revenue, 4)


def calculate_net_margin(net_income: float, revenue: float) -> float | None:
    """순이익률을 계산합니다."""
    if revenue <= 0:
        return None
    return round(net_income / revenue, 4)


def calculate_fcf_yield(
    fcf: float, market_cap: float
) -> float | None:
    """FCF 수익률을 계산합니다.

    Args:
        fcf: 잉여현금흐름 (Free Cash Flow)
        market_cap: 시가총액

    Returns:
        FCF 수익률
    """
    if market_cap <= 0:
        return None
    return round(fcf / market_cap, 4)


def calculate_all_fundamentals(
    price: float,
    eps: float,
    bps: float,
    net_income: float,
    equity: float,
    total_assets: float,
    total_liabilities: float,
    revenue: float,
    operating_income: float,
    fcf: float,
    market_cap: float,
    dividend_per_share: float = 0.0,
) -> FundamentalMetrics:
    """모든 펀더멘탈 지표를 한번에 계산합니다.

    Args:
        price: 현재 주가
        eps: 주당순이익
        bps: 주당순자산
        net_income: 당기순이익
        equity: 자기자본
        total_assets: 총자산
        total_liabilities: 총부채
        revenue: 매출액
        operating_income: 영업이익
        fcf: 잉여현금흐름
        market_cap: 시가총액
        dividend_per_share: 주당배당금

    Returns:
        FundamentalMetrics
    """
    div_yield = round(dividend_per_share / price, 4) if price > 0 else None

    return FundamentalMetrics(
        per=calculate_per(price, eps),
        pbr=calculate_pbr(price, bps),
        roe=calculate_roe(net_income, equity),
        roa=calculate_roa(net_income, total_assets),
        debt_ratio=calculate_debt_ratio(total_liabilities, equity),
        operating_margin=calculate_operating_margin(operating_income, revenue),
        net_margin=calculate_net_margin(net_income, revenue),
        fcf_yield=calculate_fcf_yield(fcf, market_cap),
        dividend_yield=div_yield,
    )
