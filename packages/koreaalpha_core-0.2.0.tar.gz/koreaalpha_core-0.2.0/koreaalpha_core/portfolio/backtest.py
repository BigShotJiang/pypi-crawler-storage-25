"""백테스트 엔진 모듈.

과거 데이터를 기반으로 포트폴리오 성과를 시뮬레이션합니다.
리밸런싱, 거래 비용, 슬리피지를 반영합니다.
"""

from dataclasses import dataclass, field
from datetime import datetime

import numpy as np

from .metrics import PortfolioMetrics, calculate_all_metrics


@dataclass
class BacktestConfig:
    """백테스트 설정."""

    initial_capital: float = 10_000_000  # 초기 자본 (1000만원)
    rebalance_period: str = "monthly"  # monthly, quarterly, yearly, none
    transaction_cost_pct: float = 0.0015  # 편도 거래비용 0.15% (증권사 수수료+세금 근사)
    slippage_pct: float = 0.001  # 슬리피지 0.1%
    start_date: str | None = None
    end_date: str | None = None
    use_kr_trading_days: bool = True  # 한국 거래일 기반 리밸런싱
    dividend_reinvest: bool = False  # 배당 재투자 여부
    dividend_yields: dict[str, float] | None = None  # {자산명: 연간배당수익률}


@dataclass
class RebalanceEvent:
    """리밸런싱 이벤트 기록."""

    date: str
    day_index: int
    trades: dict[str, float]  # 자산명 → 거래금액 (양수=매수, 음수=매도)
    cost: float  # 거래 비용


@dataclass
class BacktestResult:
    """백테스트 결과."""

    config: BacktestConfig
    metrics: PortfolioMetrics
    portfolio_values: list[float]  # 일별 포트폴리오 가치
    dates: list[str]  # 날짜 리스트
    rebalance_events: list[RebalanceEvent]
    total_transaction_cost: float
    allocations: dict[str, float]  # 목표 자산 배분


def _get_rebalance_indices(
    num_days: int,
    period: str,
    dates: list[str] | None = None,
    use_kr_trading_days: bool = False,
) -> list[int]:
    """리밸런싱 시점 인덱스를 반환합니다.

    dates가 YYYYMMDD 형식이고 use_kr_trading_days=True이면
    한국 거래일 기반으로 월/분기/연 첫 거래일에 리밸런싱합니다.
    """
    if period == "none":
        return []

    # 날짜 기반 리밸런싱 (한국 거래일 연동)
    if dates and len(dates) == num_days and use_kr_trading_days:
        from ..kr_market import is_kr_trading_day
        from datetime import date as dt_date

        indices = [0]  # 첫 날 무조건 리밸런싱
        prev_key = _period_key(dates[0], period)

        for i in range(1, num_days):
            cur_key = _period_key(dates[i], period)
            if cur_key != prev_key:
                # 새 기간 시작 → 거래일인지 확인
                try:
                    d = dt_date(int(dates[i][:4]), int(dates[i][4:6]), int(dates[i][6:8]))
                    if is_kr_trading_day(d):
                        indices.append(i)
                        prev_key = cur_key
                except (ValueError, IndexError):
                    indices.append(i)
                    prev_key = cur_key
        return indices

    # 단순 interval 기반 (기존 방식)
    if period == "monthly":
        interval = 21
    elif period == "quarterly":
        interval = 63
    elif period == "yearly":
        interval = 248  # 한국 거래일 기준
    else:
        raise ValueError(f"지원하지 않는 리밸런싱 주기: {period}")

    return list(range(0, num_days, interval))


def _period_key(date_str: str, period: str) -> str:
    """날짜 문자열에서 기간 키를 추출합니다."""
    if period == "monthly":
        return date_str[:6]  # YYYYMM
    elif period == "quarterly":
        month = int(date_str[4:6])
        quarter = (month - 1) // 3 + 1
        return f"{date_str[:4]}Q{quarter}"
    elif period == "yearly":
        return date_str[:4]  # YYYY
    return date_str


def run_backtest(
    asset_prices: dict[str, list[float]],
    allocations: dict[str, float],
    config: BacktestConfig | None = None,
    dates: list[str] | None = None,
) -> BacktestResult:
    """포트폴리오 백테스트를 실행합니다.

    Args:
        asset_prices: {자산명: 일별종가리스트} — 모든 자산의 길이가 같아야 함
        allocations: {자산명: 목표비중} — 합계 1.0
        config: 백테스트 설정
        dates: 날짜 리스트 (선택, 결과 표시용)

    Returns:
        BacktestResult
    """
    if config is None:
        config = BacktestConfig()

    # 검증
    asset_names = list(asset_prices.keys())
    if not asset_names:
        raise ValueError("최소 1개 이상의 자산이 필요합니다.")

    num_days = len(asset_prices[asset_names[0]])
    for name, prices in asset_prices.items():
        if len(prices) != num_days:
            raise ValueError(
                f"자산 '{name}'의 데이터 길이({len(prices)})가 "
                f"다른 자산({num_days})과 다릅니다."
            )

    alloc_sum = sum(allocations.values())
    if abs(alloc_sum - 1.0) > 0.01:
        raise ValueError(f"자산 배분 합계가 1.0이 아닙니다: {alloc_sum:.4f}")

    # 가격 → numpy
    price_arrays = {
        name: np.asarray(prices, dtype=np.float64)
        for name, prices in asset_prices.items()
    }

    # 일별 수익률
    return_arrays = {}
    for name, parr in price_arrays.items():
        rets = np.zeros(num_days)
        rets[1:] = np.diff(parr) / parr[:-1]
        return_arrays[name] = rets

    # 리밸런싱 시점 (거래일 연동)
    rebal_indices = _get_rebalance_indices(
        num_days, config.rebalance_period, dates, config.use_kr_trading_days,
    )

    # 배당 재투자 설정
    daily_div_yields = {}
    if config.dividend_reinvest and config.dividend_yields:
        from .metrics import TRADING_DAYS
        for name, annual_yield in config.dividend_yields.items():
            daily_div_yields[name] = annual_yield / TRADING_DAYS

    # 시뮬레이션
    capital = config.initial_capital
    portfolio_values = np.zeros(num_days)
    holdings = {}  # 자산별 보유 금액
    rebalance_events = []
    total_cost = 0.0

    for day in range(num_days):
        if day == 0 or day in rebal_indices:
            # 리밸런싱 일에도 먼저 당일 수익률 반영 (day 0 제외)
            if day > 0:
                for name in asset_names:
                    if name in holdings:
                        holdings[name] *= 1 + return_arrays[name][day]
                capital = sum(holdings.values())

            # 리밸런싱: 목표 비중으로 재배분
            trades = {}
            cost = 0.0

            for name in asset_names:
                target = capital * allocations.get(name, 0.0)
                current = holdings.get(name, 0.0)
                diff = target - current

                if abs(diff) > 1:  # 1원 이상일 때만 거래
                    trade_cost = abs(diff) * (
                        config.transaction_cost_pct + config.slippage_pct
                    )
                    cost += trade_cost
                    trades[name] = diff

                holdings[name] = target

            capital -= cost
            total_cost += cost

            # 비용 차감 후 holdings 재조정
            if capital > 0 and cost > 0:
                ratio = capital / (capital + cost)
                for name in holdings:
                    holdings[name] *= ratio

            if trades:
                rebalance_events.append(
                    RebalanceEvent(
                        date=dates[day] if dates else f"day_{day}",
                        day_index=day,
                        trades=trades,
                        cost=round(cost, 2),
                    )
                )
        else:
            # 일별 수익률 적용
            for name in asset_names:
                if name in holdings:
                    holdings[name] *= 1 + return_arrays[name][day]

            # 배당 재투자 (일별 배당금을 해당 자산에 재투자)
            if daily_div_yields:
                for name in asset_names:
                    if name in holdings and name in daily_div_yields:
                        div = holdings[name] * daily_div_yields[name]
                        holdings[name] += div

        capital = sum(holdings.values())
        portfolio_values[day] = capital

    # 지표 계산
    metrics = calculate_all_metrics(portfolio_values.tolist())

    return BacktestResult(
        config=config,
        metrics=metrics,
        portfolio_values=portfolio_values.tolist(),
        dates=dates or [f"day_{i}" for i in range(num_days)],
        rebalance_events=rebalance_events,
        total_transaction_cost=round(total_cost, 2),
        allocations=allocations,
    )


def generate_backtest_report(result: BacktestResult) -> dict:
    """백테스트 결과를 리포트 형식으로 변환합니다.

    Returns:
        리포트용 딕셔너리
    """
    m = result.metrics
    return {
        "summary": {
            "initial_capital": result.config.initial_capital,
            "final_value": round(result.portfolio_values[-1], 0),
            "total_return_pct": round(m.total_return * 100, 2),
            "cagr_pct": round(m.cagr * 100, 2),
            "volatility_pct": round(m.volatility * 100, 2),
            "sharpe_ratio": m.sharpe_ratio,
            "sortino_ratio": m.sortino_ratio,
            "mdd_pct": round(m.mdd * 100, 2),
            "mdd_duration_days": m.mdd_duration_days,
            "calmar_ratio": m.calmar_ratio,
        },
        "allocations": result.allocations,
        "rebalance_count": len(result.rebalance_events),
        "total_transaction_cost": result.total_transaction_cost,
        "transaction_cost_pct": round(
            result.total_transaction_cost / result.config.initial_capital * 100,
            4,
        ),
        "period": {
            "start": result.dates[0] if result.dates else None,
            "end": result.dates[-1] if result.dates else None,
            "trading_days": len(result.portfolio_values),
        },
    }
