"""벤치마크 포트폴리오 비교 모듈.

순수 비교 로직 + 등급 계산만 제공합니다.
벤치마크 포트폴리오 정의(종목코드, 비중, ETF 매핑)는 서비스 레벨에서 관리합니다.
"""

from dataclasses import dataclass

from .metrics import PortfolioMetrics, calculate_all_metrics


@dataclass
class ComparisonResult:
    """포트폴리오 vs 벤치마크 비교 결과."""

    benchmark_name: str
    user_metrics: PortfolioMetrics
    benchmark_metrics: PortfolioMetrics
    sharpe_diff: float  # 유저 - 벤치마크
    volatility_ratio: float  # 유저 변동성 / 벤치마크 변동성
    mdd_diff: float  # 유저 MDD - 벤치마크 MDD
    cagr_diff: float  # 유저 CAGR - 벤치마크 CAGR
    grade: str  # A+, A, B+, B, C, D, F


def grade_portfolio(user: PortfolioMetrics, bench: PortfolioMetrics) -> str:
    """벤치마크 대비 등급을 매깁니다.

    Sharpe 40% + CAGR 30% + MDD 30% 가중 평가.

    Returns:
        A+, A, B+, B, C, D, F
    """
    score = 0

    # 샤프 비율 비교 (40% 가중)
    if bench.sharpe_ratio != 0:
        sharpe_ratio = user.sharpe_ratio / bench.sharpe_ratio
        if sharpe_ratio >= 1.3:
            score += 40
        elif sharpe_ratio >= 1.1:
            score += 32
        elif sharpe_ratio >= 0.9:
            score += 24
        elif sharpe_ratio >= 0.7:
            score += 16
        else:
            score += 8
    else:
        if user.sharpe_ratio >= 1.0:
            score += 36
        elif user.sharpe_ratio >= 0.5:
            score += 28
        elif user.sharpe_ratio >= 0:
            score += 20
        else:
            score += 8

    # CAGR 비교 (30% 가중)
    cagr_diff = user.cagr - bench.cagr
    if cagr_diff >= 0.03:
        score += 30
    elif cagr_diff >= 0.01:
        score += 24
    elif cagr_diff >= -0.01:
        score += 18
    elif cagr_diff >= -0.03:
        score += 12
    else:
        score += 6

    # MDD 비교 (30% 가중)
    mdd_diff = user.mdd - bench.mdd
    if mdd_diff >= 0.05:
        score += 30
    elif mdd_diff >= 0.02:
        score += 24
    elif mdd_diff >= -0.02:
        score += 18
    elif mdd_diff >= -0.05:
        score += 12
    else:
        score += 6

    if score >= 90:
        return "A+"
    elif score >= 80:
        return "A"
    elif score >= 70:
        return "B+"
    elif score >= 60:
        return "B"
    elif score >= 50:
        return "C"
    elif score >= 40:
        return "D"
    else:
        return "F"


def compare_with_benchmark(
    user_prices: list[float],
    benchmark_prices: list[float],
    benchmark_name: str = "벤치마크",
    risk_free_rate: float = 0.035,
) -> ComparisonResult:
    """사용자 포트폴리오를 벤치마크와 비교합니다.

    Args:
        user_prices: 사용자 포트폴리오 일별 가치 배열
        benchmark_prices: 벤치마크 일별 가치 배열
        benchmark_name: 벤치마크 표시 이름
        risk_free_rate: 무위험 수익률

    Returns:
        ComparisonResult
    """
    user_m = calculate_all_metrics(user_prices, risk_free_rate)
    bench_m = calculate_all_metrics(benchmark_prices, risk_free_rate)

    vol_ratio = (
        user_m.volatility / bench_m.volatility
        if bench_m.volatility != 0
        else 0.0
    )

    return ComparisonResult(
        benchmark_name=benchmark_name,
        user_metrics=user_m,
        benchmark_metrics=bench_m,
        sharpe_diff=round(user_m.sharpe_ratio - bench_m.sharpe_ratio, 4),
        volatility_ratio=round(vol_ratio, 4),
        mdd_diff=round(user_m.mdd - bench_m.mdd, 6),
        cagr_diff=round(user_m.cagr - bench_m.cagr, 6),
        grade=grade_portfolio(user_m, bench_m),
    )


def compare_with_multiple(
    user_prices: list[float],
    benchmarks: dict[str, list[float]],
    risk_free_rate: float = 0.035,
) -> list[ComparisonResult]:
    """여러 벤치마크와 비교합니다.

    Args:
        user_prices: 사용자 포트폴리오 일별 가치
        benchmarks: {벤치마크이름: 일별가치} 딕셔너리
        risk_free_rate: 무위험 수익률

    Returns:
        ComparisonResult 리스트
    """
    return [
        compare_with_benchmark(user_prices, prices, name, risk_free_rate)
        for name, prices in benchmarks.items()
    ]
