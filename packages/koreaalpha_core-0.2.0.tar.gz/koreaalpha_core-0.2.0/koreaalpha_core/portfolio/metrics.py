"""포트폴리오 성과 지표 계산 모듈.

Sharpe Ratio, MDD, Sortino Ratio, CAGR, 변동성, 베타, 상관계수 등
핵심 지표를 계산합니다. numpy 기반, pandas 의존 없음.
"""

import math
from dataclasses import dataclass

import numpy as np


TRADING_DAYS_US = 252  # 미국 연간 거래일
TRADING_DAYS_KR = 248  # 한국 연간 거래일
TRADING_DAYS = TRADING_DAYS_KR  # 기본값: 한국
DEFAULT_RISK_FREE_RATE = 0.035  # 한국 국고채 기준, 변경 시 이 상수 수정


@dataclass
class PortfolioMetrics:
    """포트폴리오 성과 지표 종합."""

    cagr: float  # 연평균 성장률
    volatility: float  # 연환산 변동성
    sharpe_ratio: float  # 샤프 비율
    sortino_ratio: float  # 소르티노 비율
    mdd: float  # 최대 낙폭 (음수)
    mdd_duration_days: int  # MDD 회복까지 걸린 일수
    calmar_ratio: float  # CAGR / |MDD|
    total_return: float  # 총 수익률
    best_day: float  # 최고 일일 수익률
    worst_day: float  # 최저 일일 수익률
    positive_days_pct: float  # 양의 수익 비율


def calculate_returns(prices: list[float] | np.ndarray) -> np.ndarray:
    """가격 시계열에서 일별 수익률을 계산합니다.

    Args:
        prices: 일별 종가 배열 (최소 2개)

    Returns:
        일별 수익률 배열 (len = len(prices) - 1)
    """
    p = np.asarray(prices, dtype=np.float64)
    if len(p) < 2:
        raise ValueError("최소 2개 이상의 가격 데이터가 필요합니다.")
    if np.any(p[:-1] == 0):
        raise ValueError("가격에 0이 포함되어 있어 수익률을 계산할 수 없습니다.")
    return np.diff(p) / p[:-1]


def calculate_cagr(
    start_value: float, end_value: float, years: float
) -> float:
    """연평균 성장률(CAGR)을 계산합니다.

    Args:
        start_value: 시작 가치
        end_value: 종료 가치
        years: 기간 (년)

    Returns:
        CAGR (예: 0.07 = 7%)
    """
    if start_value <= 0 or years <= 0:
        raise ValueError("start_value와 years는 양수여야 합니다.")
    return (end_value / start_value) ** (1 / years) - 1


def calculate_cagr_from_returns(
    returns: list[float] | np.ndarray,
) -> float:
    """일별 수익률 배열에서 CAGR을 계산합니다."""
    r = np.asarray(returns, dtype=np.float64)
    total = np.prod(1 + r)
    years = len(r) / TRADING_DAYS
    if years <= 0:
        return 0.0
    return total ** (1 / years) - 1


def calculate_volatility(
    returns: list[float] | np.ndarray,
) -> float:
    """연환산 변동성을 계산합니다.

    Args:
        returns: 일별 수익률 배열

    Returns:
        연환산 변동성 (예: 0.15 = 15%)
    """
    r = np.asarray(returns, dtype=np.float64)
    if len(r) < 2:
        raise ValueError("최소 2개 이상의 수익률 데이터가 필요합니다.")
    return float(np.std(r, ddof=1) * math.sqrt(TRADING_DAYS))


def calculate_sharpe_ratio(
    returns: list[float] | np.ndarray,
    risk_free_rate: float = 0.035,
) -> float:
    """샤프 비율을 계산합니다.

    Args:
        returns: 일별 수익률 배열
        risk_free_rate: 연간 무위험 수익률 (기본 3.5% = 한국 국고채 기준)

    Returns:
        연환산 샤프 비율
    """
    r = np.asarray(returns, dtype=np.float64)
    if len(r) < 2:
        raise ValueError("최소 2개 이상의 수익률 데이터가 필요합니다.")

    daily_rf = (1 + risk_free_rate) ** (1 / TRADING_DAYS) - 1
    excess = r - daily_rf
    std = np.std(excess, ddof=1)
    if std == 0:
        return 0.0
    return float(np.mean(excess) / std * math.sqrt(TRADING_DAYS))


def calculate_sortino_ratio(
    returns: list[float] | np.ndarray,
    risk_free_rate: float = 0.035,
) -> float:
    """소르티노 비율을 계산합니다.

    하방 변동성만 사용하여 위험 대비 수익을 평가합니다.

    Args:
        returns: 일별 수익률 배열
        risk_free_rate: 연간 무위험 수익률

    Returns:
        연환산 소르티노 비율
    """
    r = np.asarray(returns, dtype=np.float64)
    if len(r) < 2:
        raise ValueError("최소 2개 이상의 수익률 데이터가 필요합니다.")

    daily_rf = (1 + risk_free_rate) ** (1 / TRADING_DAYS) - 1
    excess = r - daily_rf
    downside = excess[excess < 0]

    if len(downside) == 0:
        return float("inf")  # 하방 없음

    downside_std = np.sqrt(np.mean(downside**2))
    if downside_std == 0:
        return 0.0
    return float(np.mean(excess) / downside_std * math.sqrt(TRADING_DAYS))


def calculate_mdd(prices: list[float] | np.ndarray) -> float:
    """최대 낙폭(Maximum Drawdown)을 계산합니다.

    Args:
        prices: 일별 종가 배열

    Returns:
        MDD (음수, 예: -0.15 = -15%)
    """
    p = np.asarray(prices, dtype=np.float64)
    if len(p) < 2:
        raise ValueError("최소 2개 이상의 가격 데이터가 필요합니다.")

    peak = np.maximum.accumulate(p)
    # peak이 0인 경우 방어
    safe_peak = np.where(peak == 0, 1, peak)
    drawdown = (p - peak) / safe_peak
    return float(np.min(drawdown))


def calculate_mdd_duration(prices: list[float] | np.ndarray) -> int:
    """MDD 회복까지 걸린 최대 일수를 계산합니다.

    Args:
        prices: 일별 종가 배열

    Returns:
        최대 드로다운 기간 (거래일 기준)
    """
    p = np.asarray(prices, dtype=np.float64)
    peak = np.maximum.accumulate(p)
    in_drawdown = p < peak

    max_duration = 0
    current = 0
    for underwater in in_drawdown:
        if underwater:
            current += 1
            max_duration = max(max_duration, current)
        else:
            current = 0
    return max_duration


def calculate_calmar_ratio(cagr: float, mdd: float) -> float:
    """칼마 비율을 계산합니다 (CAGR / |MDD|).

    Args:
        cagr: 연평균 성장률
        mdd: 최대 낙폭 (음수)

    Returns:
        칼마 비율
    """
    if mdd == 0:
        return float("inf") if cagr > 0 else 0.0
    return cagr / abs(mdd)


def calculate_beta(
    returns: list[float] | np.ndarray,
    benchmark_returns: list[float] | np.ndarray,
) -> float:
    """벤치마크 대비 베타를 계산합니다.

    Args:
        returns: 포트폴리오 일별 수익률
        benchmark_returns: 벤치마크 일별 수익률

    Returns:
        베타 계수
    """
    r = np.asarray(returns, dtype=np.float64)
    b = np.asarray(benchmark_returns, dtype=np.float64)

    min_len = min(len(r), len(b))
    r, b = r[:min_len], b[:min_len]

    cov = np.cov(r, b)
    var_benchmark = cov[1, 1]
    if var_benchmark == 0:
        return 0.0
    return float(cov[0, 1] / var_benchmark)


def calculate_correlation(
    returns_a: list[float] | np.ndarray,
    returns_b: list[float] | np.ndarray,
) -> float:
    """두 수익률 시계열의 상관계수를 계산합니다.

    Returns:
        피어슨 상관계수 (-1 ~ 1)
    """
    a = np.asarray(returns_a, dtype=np.float64)
    b = np.asarray(returns_b, dtype=np.float64)
    min_len = min(len(a), len(b))
    return float(np.corrcoef(a[:min_len], b[:min_len])[0, 1])


def calculate_all_metrics(
    prices: list[float] | np.ndarray,
    risk_free_rate: float = 0.035,
) -> PortfolioMetrics:
    """가격 시계열에서 모든 핵심 지표를 한번에 계산합니다.

    Args:
        prices: 일별 종가 배열
        risk_free_rate: 연간 무위험 수익률

    Returns:
        PortfolioMetrics 객체
    """
    p = np.asarray(prices, dtype=np.float64)
    returns = calculate_returns(p)
    years = len(returns) / TRADING_DAYS

    total_return = (p[-1] / p[0]) - 1
    cagr = calculate_cagr(p[0], p[-1], years) if years > 0 else 0.0
    vol = calculate_volatility(returns)
    sharpe = calculate_sharpe_ratio(returns, risk_free_rate)
    sortino = calculate_sortino_ratio(returns, risk_free_rate)
    mdd = calculate_mdd(p)
    mdd_dur = calculate_mdd_duration(p)
    calmar = calculate_calmar_ratio(cagr, mdd)

    return PortfolioMetrics(
        cagr=round(cagr, 6),
        volatility=round(vol, 6),
        sharpe_ratio=round(sharpe, 4),
        sortino_ratio=round(sortino, 4),
        mdd=round(mdd, 6),
        mdd_duration_days=mdd_dur,
        calmar_ratio=round(calmar, 4),
        total_return=round(total_return, 6),
        best_day=round(float(np.max(returns)), 6),
        worst_day=round(float(np.min(returns)), 6),
        positive_days_pct=round(float(np.mean(returns > 0)), 4),
    )


# ── Rolling 지표 ──

def rolling_sharpe(
    returns: list[float] | np.ndarray,
    window: int = 60,
    risk_free_rate: float = 0.035,
) -> np.ndarray:
    """Rolling Sharpe Ratio를 계산합니다.

    Args:
        returns: 일별 수익률
        window: 윈도우 크기 (기본 60거래일 ≈ 3개월)
        risk_free_rate: 연간 무위험 수익률

    Returns:
        Rolling Sharpe 배열 (앞 window-1개는 NaN)
    """
    r = np.asarray(returns, dtype=np.float64)
    daily_rf = (1 + risk_free_rate) ** (1 / TRADING_DAYS) - 1
    excess = r - daily_rf
    result = np.full(len(r), np.nan)
    for i in range(window - 1, len(r)):
        w = excess[i - window + 1 : i + 1]
        std = np.std(w, ddof=1)
        result[i] = float(np.mean(w) / std * math.sqrt(TRADING_DAYS)) if std > 0 else 0.0
    return result


def rolling_volatility(
    returns: list[float] | np.ndarray,
    window: int = 20,
) -> np.ndarray:
    """Rolling 연환산 변동성을 계산합니다.

    Args:
        returns: 일별 수익률
        window: 윈도우 크기 (기본 20거래일 ≈ 1개월)

    Returns:
        Rolling 변동성 배열
    """
    r = np.asarray(returns, dtype=np.float64)
    result = np.full(len(r), np.nan)
    for i in range(window - 1, len(r)):
        w = r[i - window + 1 : i + 1]
        result[i] = float(np.std(w, ddof=1) * math.sqrt(TRADING_DAYS))
    return result


def rolling_beta(
    returns: list[float] | np.ndarray,
    benchmark_returns: list[float] | np.ndarray,
    window: int = 60,
) -> np.ndarray:
    """Rolling Beta를 계산합니다."""
    r = np.asarray(returns, dtype=np.float64)
    b = np.asarray(benchmark_returns, dtype=np.float64)
    min_len = min(len(r), len(b))
    r, b = r[:min_len], b[:min_len]
    result = np.full(min_len, np.nan)
    for i in range(window - 1, min_len):
        wr = r[i - window + 1 : i + 1]
        wb = b[i - window + 1 : i + 1]
        cov = np.cov(wr, wb)
        var_b = cov[1, 1]
        result[i] = float(cov[0, 1] / var_b) if var_b > 0 else 0.0
    return result


# ── Drawdown 시계열 ──

def drawdown_series(prices: list[float] | np.ndarray) -> np.ndarray:
    """전체 Drawdown 시계열을 반환합니다.

    Returns:
        각 시점의 drawdown 비율 배열 (0 이하, 예: -0.15)
    """
    p = np.asarray(prices, dtype=np.float64)
    peak = np.maximum.accumulate(p)
    safe_peak = np.where(peak == 0, 1, peak)
    return (p - peak) / safe_peak


# ── VaR / CVaR ──

def calculate_var(
    returns: list[float] | np.ndarray,
    confidence: float = 0.95,
) -> float:
    """Value at Risk를 계산합니다 (히스토리컬 방법).

    Args:
        returns: 일별 수익률
        confidence: 신뢰수준 (기본 95%)

    Returns:
        VaR (음수, 예: -0.025 = 하루 2.5% 손실 가능)
    """
    r = np.asarray(returns, dtype=np.float64)
    return float(np.percentile(r, (1 - confidence) * 100))


def calculate_cvar(
    returns: list[float] | np.ndarray,
    confidence: float = 0.95,
) -> float:
    """Conditional VaR (Expected Shortfall)을 계산합니다.

    VaR를 초과하는 손실의 평균.

    Returns:
        CVaR (음수)
    """
    r = np.asarray(returns, dtype=np.float64)
    var = calculate_var(r, confidence)
    tail = r[r <= var]
    return float(np.mean(tail)) if len(tail) > 0 else var


# ── 분포 지표 ──

def calculate_skewness(returns: list[float] | np.ndarray) -> float:
    """수익률 분포의 왜도(Skewness)를 계산합니다.

    양수: 우측 꼬리 (긍정적), 음수: 좌측 꼬리 (부정적)
    """
    r = np.asarray(returns, dtype=np.float64)
    n = len(r)
    if n < 3:
        return 0.0
    mean = np.mean(r)
    std = np.std(r, ddof=1)
    if std == 0:
        return 0.0
    return float((n / ((n - 1) * (n - 2))) * np.sum(((r - mean) / std) ** 3))


def calculate_kurtosis(returns: list[float] | np.ndarray) -> float:
    """수익률 분포의 첨도(Excess Kurtosis)를 계산합니다.

    0보다 크면 정규분포보다 꼬리가 두꺼움 (fat tail).
    Fisher 표본 보정 적용 (skewness와 일관).
    """
    r = np.asarray(returns, dtype=np.float64)
    n = len(r)
    if n < 4:
        return 0.0
    mean = np.mean(r)
    std = np.std(r, ddof=1)
    if std == 0:
        return 0.0
    m4 = float(np.sum(((r - mean) / std) ** 4))
    # Fisher 표본 보정
    kurt = (n * (n + 1) * m4) / ((n - 1) * (n - 2) * (n - 3))
    adjust = (3 * (n - 1) ** 2) / ((n - 2) * (n - 3))
    return kurt - adjust


# ── 알파 / 정보비율 ──

def calculate_alpha(
    returns: list[float] | np.ndarray,
    benchmark_returns: list[float] | np.ndarray,
    risk_free_rate: float = 0.035,
) -> float:
    """Jensen's Alpha를 계산합니다.

    Alpha = 포트폴리오 초과수익 - Beta * 벤치마크 초과수익
    """
    r = np.asarray(returns, dtype=np.float64)
    b = np.asarray(benchmark_returns, dtype=np.float64)
    min_len = min(len(r), len(b))
    r, b = r[:min_len], b[:min_len]

    daily_rf = (1 + risk_free_rate) ** (1 / TRADING_DAYS) - 1
    port_excess = np.mean(r) - daily_rf
    bench_excess = np.mean(b) - daily_rf
    beta = calculate_beta(r, b)

    return float((port_excess - beta * bench_excess) * TRADING_DAYS)


def calculate_information_ratio(
    returns: list[float] | np.ndarray,
    benchmark_returns: list[float] | np.ndarray,
) -> float:
    """정보비율 (Information Ratio)을 계산합니다.

    초과수익 / 트래킹에러
    """
    r = np.asarray(returns, dtype=np.float64)
    b = np.asarray(benchmark_returns, dtype=np.float64)
    min_len = min(len(r), len(b))
    active = r[:min_len] - b[:min_len]
    te = np.std(active, ddof=1)
    if te == 0:
        return 0.0
    return float(np.mean(active) / te * math.sqrt(TRADING_DAYS))


# ── 기타 비율 ──

def calculate_omega_ratio(
    returns: list[float] | np.ndarray,
    threshold: float = 0.0,
) -> float:
    """Omega Ratio를 계산합니다.

    threshold 이상 수익의 합 / threshold 이하 손실의 합
    """
    r = np.asarray(returns, dtype=np.float64)
    gains = np.sum(np.maximum(r - threshold, 0))
    losses = np.sum(np.maximum(threshold - r, 0))
    if losses == 0:
        return float("inf")
    return float(gains / losses)


def calculate_tail_ratio(
    returns: list[float] | np.ndarray,
    percentile: float = 5.0,
) -> float:
    """Tail Ratio — 상위 꼬리 / 하위 꼬리 비율.

    1보다 크면 상승 꼬리가 더 두꺼움 (긍정적)
    """
    r = np.asarray(returns, dtype=np.float64)
    upper = np.abs(np.percentile(r, 100 - percentile))
    lower = np.abs(np.percentile(r, percentile))
    if lower == 0:
        return float("inf")
    return float(upper / lower)


# ── 월별/연도별 수익률 ──

def monthly_returns(
    prices: list[float] | np.ndarray,
    dates: list[str] | None = None,
) -> list[dict]:
    """월별 수익률을 계산합니다.

    Args:
        prices: 일별 가격
        dates: YYYYMMDD 형식 날짜 리스트 (None이면 인덱스 기반)

    Returns:
        [{"year": 2025, "month": 1, "return": 0.05}, ...]
    """
    p = np.asarray(prices, dtype=np.float64)
    if dates is None or len(dates) != len(p):
        return []

    result = []
    month_start_price = p[0]
    current_ym = dates[0][:6]

    for i in range(1, len(p)):
        ym = dates[i][:6]
        if ym != current_ym:
            ret = (p[i - 1] / month_start_price) - 1
            result.append({
                "year": int(current_ym[:4]),
                "month": int(current_ym[4:6]),
                "return": round(ret, 6),
            })
            month_start_price = p[i]  # 새 월의 시작가격 = 새 월 첫 날 가격
            current_ym = ym

    # 마지막 월
    ret = (p[-1] / month_start_price) - 1 if month_start_price > 0 else 0.0
    result.append({
        "year": int(current_ym[:4]),
        "month": int(current_ym[4:6]),
        "return": round(ret, 6),
    })
    return result


def annual_returns(
    prices: list[float] | np.ndarray,
    dates: list[str] | None = None,
) -> list[dict]:
    """연도별 수익률을 계산합니다.

    Returns:
        [{"year": 2025, "return": 0.12}, ...]
    """
    p = np.asarray(prices, dtype=np.float64)
    if dates is None or len(dates) != len(p):
        return []

    result = []
    year_start_price = p[0]
    current_year = dates[0][:4]

    for i in range(1, len(p)):
        yr = dates[i][:4]
        if yr != current_year:
            ret = (p[i - 1] / year_start_price) - 1
            result.append({"year": int(current_year), "return": round(ret, 6)})
            year_start_price = p[i]  # 새 연도의 시작가격
            current_year = yr

    ret = (p[-1] / year_start_price) - 1 if year_start_price > 0 else 0.0
    result.append({"year": int(current_year), "return": round(ret, 6)})
    return result


# ── 연속 승/패 ──

def longest_streak(returns: list[float] | np.ndarray) -> dict:
    """최장 연속 승/패 일수를 계산합니다.

    Returns:
        {"win_streak": int, "loss_streak": int}
    """
    r = np.asarray(returns, dtype=np.float64)
    max_win = max_loss = 0
    cur_win = cur_loss = 0
    for ret in r:
        if ret > 0:
            cur_win += 1
            cur_loss = 0
        elif ret < 0:
            cur_loss += 1
            cur_win = 0
        else:
            cur_win = cur_loss = 0
        max_win = max(max_win, cur_win)
        max_loss = max(max_loss, cur_loss)
    return {"win_streak": max_win, "loss_streak": max_loss}


# ── 상관계수 매트릭스 (N×N) ──

def correlation_matrix(
    returns_dict: dict[str, list[float] | np.ndarray],
) -> dict:
    """다중 자산의 상관계수 매트릭스를 계산합니다.

    Args:
        returns_dict: {"자산명": [수익률, ...], ...}

    Returns:
        {"labels": [...], "matrix": [[...], ...]}
    """
    if not returns_dict:
        return {"labels": [], "matrix": []}
    labels = list(returns_dict.keys())
    n = len(labels)
    if n == 1:
        return {"labels": labels, "matrix": [[1.0]]}
    arrays = []
    min_len = min(len(v) for v in returns_dict.values())
    for label in labels:
        arr = np.asarray(returns_dict[label], dtype=np.float64)[:min_len]
        arrays.append(arr)

    mat = np.corrcoef(arrays)
    return {
        "labels": labels,
        "matrix": [[round(float(mat[i][j]), 4) for j in range(n)] for i in range(n)],
    }
