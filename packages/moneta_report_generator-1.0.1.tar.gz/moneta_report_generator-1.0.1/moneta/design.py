"""
Moneta Design System
====================
Centralized brand, color, typography and style definitions for the Moneta
Excel report.  Every tab imports its styles from here so the look-and-feel
is perfectly consistent across the entire workbook.

Design principles (from requirements doc):
- Professional, clean, finance-grade aesthetic
- Traffic-light risk visualization (green / amber / red)
- Indonesia-friendly readability (large numbers, IDR formatting)
- Consistent table structure with banded rows
- Clear section headers with brand color
- Print / PDF optimized
"""

from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side, NamedStyle, numbers
)
from openpyxl.utils import get_column_letter
from copy import copy


# ---------------------------------------------------------------------------
# Brand palette
# ---------------------------------------------------------------------------
class Colors:
    """Moneta brand color constants (hex without leading #)."""
    # Primary — derived from Master Report_Export.xlsx
    NAVY       = "541F5A"   # Deep purple - main headers & section bars
    DARK_BLUE  = "541F5A"   # Section headers (same as primary)
    BLUE       = "002060"   # Sub-headers / accent labels
    LIGHT_BLUE = "D6E4F0"   # Total-row background tint
    PALE_BLUE  = "F2F0F4"   # Very light purple-tinted background
    WHITE      = "FFFFFF"

    # Accent
    GOLD       = "D4A843"   # Accent / highlights / brand mark
    DARK_GOLD  = "B8922E"   # Darker gold
    YELLOW     = "FFFF00"   # Highlight / attention (from master)

    # Traffic lights
    GREEN_BG   = "C6EFCE"
    GREEN_FG   = "006100"
    AMBER_BG   = "FFEB9C"
    AMBER_FG   = "9C6500"
    RED_BG     = "FFC7CE"
    RED_FG     = "9C0006"

    # Neutral
    LIGHT_GRAY = "F2F2F2"
    MEDIUM_GRAY = "D9D9D9"
    DARK_GRAY  = "404040"
    BLACK      = "000000"

    # Fraud severity
    FRAUD_HIGH   = "FF4444"
    FRAUD_MEDIUM = "FF8C00"
    FRAUD_LOW    = "FFD700"
    FRAUD_NONE   = "90EE90"


# ---------------------------------------------------------------------------
# Borders
# ---------------------------------------------------------------------------
_thin_side  = Side(style="thin",  color=Colors.BLACK)
_hair_side  = Side(style="hair",  color=Colors.BLACK)
_medium_side = Side(style="medium", color=Colors.NAVY)

BORDER_THIN   = Border(left=_thin_side, right=_thin_side,
                       top=_thin_side, bottom=_thin_side)
BORDER_HAIR   = Border(left=_hair_side, right=_hair_side,
                       top=_hair_side, bottom=_hair_side)
BORDER_BOTTOM = Border(bottom=Side(style="medium", color=Colors.NAVY))
BORDER_HEADER = Border(left=_thin_side, right=_thin_side,
                       top=_medium_side, bottom=_medium_side)

# ---------------------------------------------------------------------------
# Fonts
# ---------------------------------------------------------------------------
FONT_TITLE     = Font(name="Montserrat", size=18, bold=True, color=Colors.NAVY)
FONT_SUBTITLE  = Font(name="Montserrat", size=13, bold=False, color=Colors.DARK_BLUE)
FONT_SECTION   = Font(name="Montserrat", size=12, bold=True, color=Colors.WHITE)
FONT_HEADER    = Font(name="Montserrat", size=10, bold=True, color=Colors.WHITE)
FONT_SUBHEADER = Font(name="Montserrat", size=10, bold=True, color=Colors.DARK_BLUE)
FONT_BODY      = Font(name="Montserrat", size=10, color=Colors.DARK_GRAY)
FONT_BODY_BOLD = Font(name="Montserrat", size=10, bold=True, color=Colors.DARK_GRAY)
FONT_SMALL     = Font(name="Montserrat", size=9,  color=Colors.DARK_GRAY)
FONT_LINK      = Font(name="Montserrat", size=10, color=Colors.BLUE, underline="single")
FONT_KPI_VALUE = Font(name="Montserrat", size=14, bold=True, color=Colors.NAVY)
FONT_GOLD_TITLE = Font(name="Montserrat", size=20, bold=True, color=Colors.GOLD)
FONT_NAV       = Font(name="Montserrat", size=10, color=Colors.BLUE, underline="single")
FONT_WHITE_BOLD = Font(name="Montserrat", size=10, bold=True, color=Colors.WHITE)
FONT_COVER_COMPANY = Font(name="Montserrat", size=24, bold=True, color=Colors.NAVY)
FONT_COVER_DETAIL  = Font(name="Montserrat", size=12, color=Colors.DARK_GRAY)

# Traffic-light fonts
FONT_GREEN = Font(name="Montserrat", size=10, bold=True, color=Colors.GREEN_FG)
FONT_AMBER = Font(name="Montserrat", size=10, bold=True, color=Colors.AMBER_FG)
FONT_RED   = Font(name="Montserrat", size=10, bold=True, color=Colors.RED_FG)

# ---------------------------------------------------------------------------
# Fills
# ---------------------------------------------------------------------------
FILL_NAVY      = PatternFill("solid", fgColor=Colors.NAVY)
FILL_DARK_BLUE = PatternFill("solid", fgColor=Colors.DARK_BLUE)
FILL_BLUE      = PatternFill("solid", fgColor=Colors.BLUE)
FILL_LIGHT_BLUE = PatternFill("solid", fgColor=Colors.LIGHT_BLUE)
FILL_PALE_BLUE = PatternFill("solid", fgColor=Colors.PALE_BLUE)
FILL_WHITE     = PatternFill("solid", fgColor=Colors.WHITE)
FILL_GOLD      = PatternFill("solid", fgColor=Colors.GOLD)
FILL_LIGHT_GRAY = PatternFill("solid", fgColor=Colors.LIGHT_GRAY)

FILL_GREEN = PatternFill("solid", fgColor=Colors.GREEN_BG)
FILL_AMBER = PatternFill("solid", fgColor=Colors.AMBER_BG)
FILL_RED   = PatternFill("solid", fgColor=Colors.RED_BG)

FILL_FRAUD_HIGH   = PatternFill("solid", fgColor=Colors.FRAUD_HIGH)
FILL_FRAUD_MEDIUM = PatternFill("solid", fgColor=Colors.FRAUD_MEDIUM)
FILL_FRAUD_LOW    = PatternFill("solid", fgColor=Colors.FRAUD_LOW)
FILL_FRAUD_NONE   = PatternFill("solid", fgColor=Colors.FRAUD_NONE)

# ---------------------------------------------------------------------------
# Alignments
# ---------------------------------------------------------------------------
ALIGN_CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
ALIGN_LEFT   = Alignment(horizontal="left",   vertical="center", wrap_text=True)
ALIGN_RIGHT  = Alignment(horizontal="right",  vertical="center", wrap_text=False)
ALIGN_WRAP   = Alignment(horizontal="left",   vertical="top",    wrap_text=True)

# ---------------------------------------------------------------------------
# Number formats
# ---------------------------------------------------------------------------
NUM_FMT_IDR     = '#,##0;[Red] \\(#,##0\\)'
NUM_FMT_IDR_2   = '#,##0.00;[Red] \\(#,##0.00\\)'
NUM_FMT_PCT     = '0.00%'
NUM_FMT_PCT_1   = '0.0%'
NUM_FMT_RATIO   = '0.00"x"'
NUM_FMT_INT     = '#,##0;[Red] \\(#,##0\\)'
NUM_FMT_DATE    = 'DD-MM-YYYY'


# ---------------------------------------------------------------------------
# Navigation
# ---------------------------------------------------------------------------
# Canonical tab names used for hyperlinking throughout the workbook
TAB_NAMES = [
    "Cover",
    "Account Summary",
    "EOD Detailed",
    "EOD Combined",
    "Liquidity",
    "Transaction Summary",
    "P&L Actual",
    "P&L Forecast",
    "Balance Sheet",
    "Financial Metrics",
    "DSCR & DBR",
    "Fraud Analysis",
]


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------

def apply_header_row(ws, row, values, start_col=1):
    """Write a dark-navy header row with white bold text."""
    for i, val in enumerate(values):
        cell = ws.cell(row=row, column=start_col + i, value=val)
        cell.font = FONT_HEADER
        cell.fill = FILL_NAVY
        cell.alignment = ALIGN_CENTER
        cell.border = BORDER_HEADER
    return row


def apply_section_title(ws, row, title, col_span=8, start_col=1):
    """Write a dark-blue section title bar spanning col_span columns."""
    ws.merge_cells(
        start_row=row, start_column=start_col,
        end_row=row, end_column=start_col + col_span - 1
    )
    cell = ws.cell(row=row, column=start_col, value=title)
    cell.font = FONT_SECTION
    cell.fill = FILL_DARK_BLUE
    cell.alignment = ALIGN_LEFT
    cell.border = BORDER_HEADER
    # fill the merged area
    for c in range(start_col + 1, start_col + col_span):
        mc = ws.cell(row=row, column=c)
        mc.fill = FILL_DARK_BLUE
        mc.border = BORDER_HEADER
    return row


def apply_data_row(ws, row, values, start_col=1, is_alt=False,
                   bold_first=False, num_fmt=None):
    """Write a data row with optional alternating tint."""
    fill = FILL_PALE_BLUE if is_alt else FILL_WHITE
    for i, val in enumerate(values):
        cell = ws.cell(row=row, column=start_col + i, value=val)
        cell.font = FONT_BODY_BOLD if (bold_first and i == 0) else FONT_BODY
        cell.fill = fill
        cell.alignment = ALIGN_RIGHT if isinstance(val, (int, float)) else ALIGN_LEFT
        cell.border = BORDER_THIN
        if num_fmt and isinstance(val, (int, float)):
            cell.number_format = num_fmt
    return row


def apply_total_row(ws, row, values, start_col=1, num_fmt=None):
    """Write a bold totals row with gold accent border."""
    for i, val in enumerate(values):
        cell = ws.cell(row=row, column=start_col + i, value=val)
        cell.font = FONT_BODY_BOLD
        cell.fill = FILL_LIGHT_BLUE
        cell.alignment = ALIGN_RIGHT if isinstance(val, (int, float)) else ALIGN_LEFT
        cell.border = Border(
            left=_thin_side, right=_thin_side,
            top=Side(style="medium", color=Colors.GOLD),
            bottom=Side(style="medium", color=Colors.GOLD),
        )
        if num_fmt and isinstance(val, (int, float)):
            cell.number_format = num_fmt
    return row


def traffic_light_cell(ws, row, col, value, thresholds=None, reverse=False):
    """
    Apply traffic-light formatting to a cell.
    thresholds = (amber_threshold, red_threshold)
    If reverse=True, lower is worse (e.g., runway days).
    """
    cell = ws.cell(row=row, column=col, value=value)
    cell.border = BORDER_THIN
    cell.alignment = ALIGN_CENTER

    if thresholds and isinstance(value, (int, float)):
        amber_t, red_t = thresholds
        if reverse:
            if value <= red_t:
                cell.fill, cell.font = FILL_RED, FONT_RED
            elif value <= amber_t:
                cell.fill, cell.font = FILL_AMBER, FONT_AMBER
            else:
                cell.fill, cell.font = FILL_GREEN, FONT_GREEN
        else:
            if value >= red_t:
                cell.fill, cell.font = FILL_RED, FONT_RED
            elif value >= amber_t:
                cell.fill, cell.font = FILL_AMBER, FONT_AMBER
            else:
                cell.fill, cell.font = FILL_GREEN, FONT_GREEN
    elif isinstance(value, bool):
        if value:
            cell.fill, cell.font = FILL_RED, FONT_RED
            cell.value = "YES"
        else:
            cell.fill, cell.font = FILL_GREEN, FONT_GREEN
            cell.value = "No"
    elif isinstance(value, str):
        low = value.lower()
        if low in ("true", "yes", "high"):
            cell.fill, cell.font = FILL_RED, FONT_RED
        elif low in ("false", "no", "low", "none"):
            cell.fill, cell.font = FILL_GREEN, FONT_GREEN
        else:
            cell.fill, cell.font = FILL_AMBER, FONT_AMBER

    return cell


def _sheet_hyperlink(tab_name):
    """
    Build a valid Excel internal hyperlink anchor for a sheet name.
    Sheet names that contain spaces, ampersands, or other special characters
    MUST be wrapped in single-quotes in the anchor string, otherwise Excel
    silently ignores the link.  e.g.  #'EOD Detailed'!A1
    """
    needs_quotes = any(ch in tab_name for ch in (" ", "&", "'", "-", "/", "(", ")"))
    # Escape any embedded single-quotes by doubling them (Excel rule)
    escaped = tab_name.replace("'", "''")
    if needs_quotes:
        return f"#'{escaped}'!A1"
    return f"#{escaped}!A1"


def write_nav_bar(ws, row, current_tab, start_col=1):
    """Write a navigation bar at the given row with Home, Prev, Next, and Top links."""
    col = start_col
    label_cell = ws.cell(row=row, column=col, value="Navigate:")
    label_cell.font = FONT_SMALL
    label_cell.alignment = ALIGN_LEFT
    col += 1

    try:
        idx = TAB_NAMES.index(current_tab)
    except ValueError:
        idx = 0

    # Home Link
    home_cell = ws.cell(row=row, column=col, value="Home")
    home_cell.font = FONT_NAV
    home_cell.hyperlink = _sheet_hyperlink("Cover")
    home_cell.alignment = ALIGN_CENTER
    col += 1

    # Prev Link
    prev_cell = ws.cell(row=row, column=col)
    if idx > 0:
        prev_cell.value = "◀ Prev"
        prev_cell.font = FONT_NAV
        prev_cell.hyperlink = _sheet_hyperlink(TAB_NAMES[idx - 1])
    else:
        prev_cell.value = "(Start)"
        prev_cell.font = FONT_SMALL
    prev_cell.alignment = ALIGN_CENTER
    col += 1

    # Next Link
    next_cell = ws.cell(row=row, column=col)
    if idx < len(TAB_NAMES) - 1:
        next_cell.value = "Next ▶"
        next_cell.font = FONT_NAV
        next_cell.hyperlink = _sheet_hyperlink(TAB_NAMES[idx + 1])
    else:
        next_cell.value = "(End)"
        next_cell.font = FONT_SMALL
    next_cell.alignment = ALIGN_CENTER
    col += 1
    
    # Back to Top Link
    top_cell = ws.cell(row=row, column=col, value="⬆ Top")
    top_cell.font = FONT_NAV
    top_cell.hyperlink = f"A1"
    top_cell.alignment = ALIGN_CENTER
    col += 1

    return row


def auto_width(ws, min_width=10, max_width=35, start_col=1, end_col=None):
    """Auto-fit column widths based on content."""
    if end_col is None:
        end_col = ws.max_column or 1
    for col_idx in range(start_col, end_col + 1):
        max_len = min_width
        col_letter = get_column_letter(col_idx)
        for cell in ws[col_letter]:
            if cell.value is not None:
                length = len(str(cell.value))
                if length > max_len:
                    max_len = length
        ws.column_dimensions[col_letter].width = min(max_len + 3, max_width)


def setup_print(ws, landscape=True, title="Moneta Report", repeat_rows=None):
    """Configure print settings for PDF-friendly output.
    
    If repeat_rows is provided (e.g., '1:5'), those rows will repeat at the top of every printed page.
    """
    ws.sheet_properties.pageSetUpPr = None
    ws.page_setup.orientation = "landscape" if landscape else "portrait"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.page_margins.left = 0.4
    ws.page_margins.right = 0.4
    ws.page_margins.top = 0.5
    ws.page_margins.bottom = 0.5
    ws.page_margins.header = 0.3
    ws.page_margins.footer = 0.3
    ws.oddHeader.center.text = title
    ws.oddFooter.center.text = "Page &P of &N"
    ws.oddFooter.right.text = "Moneta Confidential"
    ws.sheet_properties.tabColor = Colors.NAVY
    
    if repeat_rows:
        ws.print_title_rows = repeat_rows


def freeze_pane(ws, cell_ref="A3"):
    """Freeze panes for easier scrolling."""
    ws.freeze_panes = cell_ref


def safe_get(data, *keys, default=None):
    """Safely navigate nested dicts/lists."""
    current = data
    for key in keys:
        try:
            if isinstance(current, dict):
                current = current[key]
            elif isinstance(current, (list, tuple)):
                current = current[int(key)]
            else:
                return default
        except (KeyError, IndexError, TypeError, ValueError):
            return default
    return current


def parse_number(value, default=0.0):
    """Safely parse a number from various types."""
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return value
    try:
        cleaned = str(value).replace(",", "").replace("x", "").replace("%", "").strip()
        if not cleaned:
            return default
        return float(cleaned)
    except (ValueError, TypeError):
        return default
