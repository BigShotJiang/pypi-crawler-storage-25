"""Tests for CLI argument handling and validation commands."""

import pytest
import runpy
import sys
import re
from io import StringIO
from pathlib import Path
from unittest.mock import patch, MagicMock

from eneru import (
    main, ConfigLoader, __version__, Config, UPSConfig, UPSGroupConfig, MonitorState,
    APIConfig, BehaviorConfig, LoggingConfig, LocalShutdownConfig, VMConfig, ContainersConfig,
    FilesystemsConfig, UnmountConfig, RedundancyGroupConfig,
)
from test_constants import (
    TEST_DISCORD_APPRISE_URL,
    TEST_SLACK_APPRISE_URL,
    TEST_JSON_WEBHOOK_URL,
)


class TestCLIVersion:
    """Test CLI version subcommand."""

    @pytest.mark.unit
    def test_version_subcommand(self, capsys):
        """Test 'eneru version' shows version and exits."""
        with patch.object(sys, "argv", ["eneru", "version"]):
            main()

        captured = capsys.readouterr()
        assert __version__ in captured.out

    @pytest.mark.unit
    def test_bare_eneru_shows_help(self, capsys):
        """Test bare 'eneru' shows help and exits 0."""
        with patch.object(sys, "argv", ["eneru"]):
            with pytest.raises(SystemExit) as exc_info:
                main()
            assert exc_info.value.code == 0

        captured = capsys.readouterr()
        assert "run" in captured.out
        assert "validate" in captured.out
        assert "monitor" in captured.out
        # `tui` is an alias for `monitor` -- both must surface in the
        # top-level help so users discover either spelling.
        assert "tui" in captured.out
        assert re.search(r"\bshutdown\s+remote\b", captured.out)

    @pytest.mark.unit
    def test_python_m_eneru_entrypoint_calls_cli_main(self):
        """``python -m eneru`` must route through the same CLI main."""
        with patch("eneru.cli.main") as cli_main:
            runpy.run_module("eneru.__main__", run_name="__main__")

        cli_main.assert_called_once_with()


class TestCLIRunOverrides:
    """Run-subcommand config overrides."""

    @pytest.mark.unit
    def test_api_bind_and_port_imply_api_enabled(self):
        from argparse import Namespace
        from eneru.cli import _apply_run_overrides

        config = Config(
            ups_groups=[UPSGroupConfig(ups=UPSConfig(name="UPS@host"))],
            api=APIConfig(enabled=False, bind="127.0.0.1", port=9191),
        )
        args = Namespace(
            dry_run=False,
            api=False,
            api_bind="0.0.0.0",
            api_port=9100,
        )

        _apply_run_overrides(config, args)

        assert config.api.enabled is True
        assert config.api.bind == "0.0.0.0"
        assert config.api.port == 9100

    @pytest.mark.unit
    def test_non_root_remote_only_config_allowed(self):
        from eneru.cli import _root_required_reasons

        config = Config(
            ups_groups=[UPSGroupConfig(
                ups=UPSConfig(name="UPS@nut"),
                is_local=False,
            )],
            local_shutdown=LocalShutdownConfig(enabled=False, trigger_on="none"),
        )

        assert _root_required_reasons(config) == []

    @pytest.mark.unit
    def test_non_root_local_config_reports_root_reasons(self):
        from eneru.cli import _root_required_reasons

        config = Config(
            ups_groups=[UPSGroupConfig(
                ups=UPSConfig(name="UPS@host", display_name="Rack"),
                is_local=True,
            )],
            local_shutdown=LocalShutdownConfig(enabled=True),
        )

        reasons = _root_required_reasons(config)

        assert "UPS group 'Rack' is marked is_local" in reasons
        assert "local_shutdown can power off the Eneru host" in reasons

    @pytest.mark.unit
    def test_api_flag_alone_implies_enabled(self):
        from argparse import Namespace
        from eneru.cli import _apply_run_overrides

        config = Config(
            ups_groups=[UPSGroupConfig(ups=UPSConfig(name="UPS@host"))],
            api=APIConfig(enabled=False, bind="127.0.0.1", port=9191),
        )
        args = Namespace(dry_run=False, api=True, api_bind=None, api_port=None)

        _apply_run_overrides(config, args)

        assert config.api.enabled is True
        # bind and port unchanged when not provided
        assert config.api.bind == "127.0.0.1"
        assert config.api.port == 9191

    @pytest.mark.unit
    def test_api_bind_alone_implies_enabled(self):
        from argparse import Namespace
        from eneru.cli import _apply_run_overrides

        config = Config(
            ups_groups=[UPSGroupConfig(ups=UPSConfig(name="UPS@host"))],
            api=APIConfig(enabled=False, bind="127.0.0.1", port=9191),
        )
        args = Namespace(dry_run=False, api=False, api_bind="0.0.0.0", api_port=None)

        _apply_run_overrides(config, args)

        assert config.api.enabled is True
        assert config.api.bind == "0.0.0.0"
        assert config.api.port == 9191

    @pytest.mark.unit
    def test_api_port_alone_implies_enabled(self):
        from argparse import Namespace
        from eneru.cli import _apply_run_overrides

        config = Config(
            ups_groups=[UPSGroupConfig(ups=UPSConfig(name="UPS@host"))],
            api=APIConfig(enabled=False, bind="127.0.0.1", port=9191),
        )
        args = Namespace(dry_run=False, api=False, api_bind=None, api_port=9100)

        _apply_run_overrides(config, args)

        assert config.api.enabled is True
        assert config.api.bind == "127.0.0.1"
        assert config.api.port == 9100

    @pytest.mark.unit
    def test_cli_overrides_yaml_api_disabled(self):
        """CLI flags must flip api.enabled True even when YAML had it False.

        This is the container-healthcheck story: image users should not need
        to author or mount a YAML to enable /health.
        """
        from argparse import Namespace
        from eneru.cli import _apply_run_overrides

        config = Config(
            ups_groups=[UPSGroupConfig(ups=UPSConfig(name="UPS@host"))],
            api=APIConfig(enabled=False, bind="127.0.0.1", port=9191),
        )
        args = Namespace(dry_run=False, api=True, api_bind="0.0.0.0", api_port=9191)

        _apply_run_overrides(config, args)

        assert config.api.enabled is True

    @pytest.mark.unit
    @pytest.mark.parametrize("bad_port", ["0", "-1", "65536", "70000", "abc"])
    def test_api_port_argparse_rejects_out_of_range(self, bad_port, capsys):
        """argparse-time validation: --api-port must be 1..65535 integer.

        Catching this at parse time gives a clear error before any config or
        privilege check fires; previously type=int let -1 / 70000 through.
        """
        with patch.object(sys, "argv", ["eneru", "run", "--api-port", bad_port]):
            with pytest.raises(SystemExit) as exc_info:
                main()
        # argparse always exits 2 on parse-time failures.
        assert exc_info.value.code == 2

    @pytest.mark.unit
    def test_port_int_validator_accepts_boundaries(self):
        from eneru.cli import _port_int

        assert _port_int("1") == 1
        assert _port_int("65535") == 65535
        assert _port_int("9191") == 9191


class TestPrivilegeChecks:
    """Root-vs-non-root startup gating."""

    @pytest.mark.unit
    def test_exit_on_privilege_errors_passes_for_root(self):
        from eneru.cli import _exit_on_privilege_errors

        config = Config(
            ups_groups=[UPSGroupConfig(
                ups=UPSConfig(name="UPS@host"), is_local=True,
            )],
            local_shutdown=LocalShutdownConfig(enabled=True),
        )

        with patch("eneru.cli.os.geteuid", return_value=0, create=True):
            _exit_on_privilege_errors(config)  # Must not raise

    @pytest.mark.unit
    def test_exit_on_privilege_errors_passes_when_geteuid_absent(self):
        """Non-Unix platforms (no os.geteuid) skip the check."""
        from eneru.cli import _exit_on_privilege_errors
        import eneru.cli

        config = Config(
            ups_groups=[UPSGroupConfig(
                ups=UPSConfig(name="UPS@host"), is_local=True,
            )],
            local_shutdown=LocalShutdownConfig(enabled=True),
        )

        # Replace os.geteuid with a sentinel to simulate a platform that
        # doesn't expose it; getattr in cli.py returns None and short-circuits.
        original_geteuid = getattr(eneru.cli.os, "geteuid", None)
        try:
            if original_geteuid is not None:
                del eneru.cli.os.geteuid
            _exit_on_privilege_errors(config)  # Must not raise
        finally:
            if original_geteuid is not None:
                eneru.cli.os.geteuid = original_geteuid

    @pytest.mark.unit
    def test_exit_on_privilege_errors_exits_for_non_root_with_local_features(self, capsys):
        from eneru.cli import _exit_on_privilege_errors

        config = Config(
            ups_groups=[UPSGroupConfig(
                ups=UPSConfig(name="UPS@host", display_name="Rack"),
                is_local=True,
            )],
            local_shutdown=LocalShutdownConfig(enabled=True),
        )

        with patch("eneru.cli.os.geteuid", return_value=1000, create=True):
            with pytest.raises(SystemExit) as exc_info:
                _exit_on_privilege_errors(config)
        assert exc_info.value.code == 1

        out = capsys.readouterr().out
        assert "must run as root" in out
        assert "is marked is_local" in out

    @pytest.mark.unit
    def test_exit_on_privilege_errors_passes_for_non_root_remote_only(self):
        from eneru.cli import _exit_on_privilege_errors

        config = Config(
            ups_groups=[UPSGroupConfig(
                ups=UPSConfig(name="UPS@nut"), is_local=False,
            )],
            local_shutdown=LocalShutdownConfig(enabled=False, trigger_on="none"),
        )

        with patch("eneru.cli.os.geteuid", return_value=1000, create=True):
            _exit_on_privilege_errors(config)  # Must not raise

    @pytest.mark.unit
    def test_eneru_skip_privilege_check_bypass_warns_but_does_not_exit(self, capsys):
        """ENERU_SKIP_PRIVILEGE_CHECK=1 downgrades the fatal check to a warning.

        Used by the E2E workflow so eneru runs as the unprivileged runner
        user (no sudo, no file-ownership churn between tests).
        """
        from eneru.cli import _exit_on_privilege_errors

        config = Config(
            ups_groups=[UPSGroupConfig(
                ups=UPSConfig(name="UPS@host", display_name="Rack"),
                is_local=True,
            )],
            local_shutdown=LocalShutdownConfig(enabled=True),
        )

        with patch("eneru.cli.os.geteuid", return_value=1000, create=True), \
             patch.dict("os.environ", {"ENERU_SKIP_PRIVILEGE_CHECK": "1"}, clear=False):
            _exit_on_privilege_errors(config)  # Must NOT raise

        err = capsys.readouterr().err
        assert "ENERU_SKIP_PRIVILEGE_CHECK" in err
        assert "is marked is_local" in err

    @pytest.mark.unit
    def test_eneru_skip_privilege_check_accepts_true_value(self):
        from eneru.cli import _exit_on_privilege_errors

        config = Config(
            ups_groups=[UPSGroupConfig(
                ups=UPSConfig(name="UPS@host"), is_local=True,
            )],
            local_shutdown=LocalShutdownConfig(enabled=False, trigger_on="none"),
        )

        with patch("eneru.cli.os.geteuid", return_value=1000, create=True), \
             patch.dict("os.environ", {"ENERU_SKIP_PRIVILEGE_CHECK": "true"}, clear=False):
            _exit_on_privilege_errors(config)  # Must not raise

    @pytest.mark.unit
    def test_eneru_skip_privilege_check_unset_still_exits(self):
        """Empty/unset env var must NOT bypass the check."""
        from eneru.cli import _exit_on_privilege_errors

        config = Config(
            ups_groups=[UPSGroupConfig(
                ups=UPSConfig(name="UPS@host"), is_local=True,
            )],
            local_shutdown=LocalShutdownConfig(enabled=False, trigger_on="none"),
        )

        with patch("eneru.cli.os.geteuid", return_value=1000, create=True), \
             patch.dict("os.environ", {"ENERU_SKIP_PRIVILEGE_CHECK": ""}, clear=False):
            with pytest.raises(SystemExit) as exc_info:
                _exit_on_privilege_errors(config)
            assert exc_info.value.code == 1

    @pytest.mark.unit
    @pytest.mark.parametrize("group_kwargs,expected_substring", [
        ({"is_local": True}, "is marked is_local"),
        ({"virtual_machines": VMConfig(enabled=True)}, "virtual_machines enabled"),
        ({"containers": ContainersConfig(enabled=True)}, "containers enabled"),
        ({"filesystems": FilesystemsConfig(unmount=UnmountConfig(enabled=True))},
         "filesystem unmount enabled"),
    ])
    def test_root_required_reasons_per_ups_group_category(self, group_kwargs, expected_substring):
        """Each local feature on a UPS group independently triggers a root-required reason."""
        from eneru.cli import _root_required_reasons

        config = Config(
            ups_groups=[UPSGroupConfig(
                ups=UPSConfig(name="UPS@host", display_name="Rack"),
                **group_kwargs,
            )],
            local_shutdown=LocalShutdownConfig(enabled=False, trigger_on="none"),
        )
        reasons = _root_required_reasons(config)
        assert any(expected_substring in r for r in reasons), reasons

    @pytest.mark.unit
    @pytest.mark.parametrize("group_kwargs,expected_substring", [
        ({"is_local": True}, "is marked is_local"),
        ({"virtual_machines": VMConfig(enabled=True)}, "virtual_machines enabled"),
        ({"containers": ContainersConfig(enabled=True)}, "containers enabled"),
        ({"filesystems": FilesystemsConfig(unmount=UnmountConfig(enabled=True))},
         "filesystem unmount enabled"),
    ])
    def test_root_required_reasons_per_redundancy_group_category(self, group_kwargs, expected_substring):
        """Each local feature on a redundancy group independently triggers a reason."""
        from eneru.cli import _root_required_reasons

        config = Config(
            ups_groups=[UPSGroupConfig(
                ups=UPSConfig(name="UPS@nut"), is_local=False,
            )],
            redundancy_groups=[RedundancyGroupConfig(
                name="rack-a",
                **group_kwargs,
            )],
            local_shutdown=LocalShutdownConfig(enabled=False, trigger_on="none"),
        )
        reasons = _root_required_reasons(config)
        assert any(expected_substring in r for r in reasons), reasons

    @pytest.mark.unit
    def test_local_shutdown_dormant_does_not_require_root(self):
        """trigger_on='none' + all-remote groups means local_shutdown never fires.

        Lock this in so a future "simplification" of the privilege check
        doesn't accidentally start requiring root for a dormant configuration.
        """
        from eneru.cli import _root_required_reasons

        config = Config(
            ups_groups=[UPSGroupConfig(
                ups=UPSConfig(name="UPS@nut"), is_local=False,
            )],
            local_shutdown=LocalShutdownConfig(enabled=True, trigger_on="none"),
        )
        reasons = _root_required_reasons(config)
        assert reasons == []

    @pytest.mark.unit
    def test_no_ups_groups_flags_implicit_single_ups_local_mode(self):
        """Empty ups_groups (legacy single-UPS via top-level `ups:` mapping that
        wasn't promoted to a group) is treated as local-host mode."""
        from eneru.cli import _root_required_reasons

        config = Config(
            ups_groups=[],  # No groups at all
            local_shutdown=LocalShutdownConfig(enabled=False, trigger_on="none"),
        )
        reasons = _root_required_reasons(config)
        assert any("implicit single-UPS local-host mode" in r for r in reasons)

    @pytest.mark.unit
    def test_local_shutdown_with_local_owner_requires_root_even_if_trigger_on_none(self):
        """trigger_on='none' is the multi-UPS knob; with a local-owner group the
        local UPS can still drive the host to shutdown when it goes critical."""
        from eneru.cli import _root_required_reasons

        config = Config(
            ups_groups=[UPSGroupConfig(
                ups=UPSConfig(name="UPS@host"), is_local=True,
            )],
            local_shutdown=LocalShutdownConfig(enabled=True, trigger_on="none"),
        )
        reasons = _root_required_reasons(config)
        assert any("local_shutdown" in r for r in reasons)


class TestRuntimeContextDetection:
    """`eneru validate` reports the runtime context (container/systemd/bare)."""

    @pytest.mark.unit
    def test_dockerenv_marker_detected(self):
        from eneru.cli import _detect_runtime_context

        def fake_exists(self):
            return str(self) == "/.dockerenv"

        with patch("pathlib.Path.exists", new=fake_exists):
            assert _detect_runtime_context() == "container (Docker)"

    @pytest.mark.unit
    def test_podman_containerenv_marker_detected(self):
        from eneru.cli import _detect_runtime_context

        def fake_exists(self):
            return str(self) == "/run/.containerenv"

        with patch("pathlib.Path.exists", new=fake_exists):
            assert _detect_runtime_context() == "container (Podman)"

    @pytest.mark.unit
    def test_container_env_var_detected_known_runtime_capitalized(self):
        from eneru.cli import _detect_runtime_context

        with patch("pathlib.Path.exists", return_value=False), \
             patch.dict("os.environ", {"container": "podman"}, clear=False):
            assert _detect_runtime_context() == "container (Podman)"

    @pytest.mark.unit
    def test_container_env_var_detected_unknown_runtime_passthrough(self):
        from eneru.cli import _detect_runtime_context

        with patch("pathlib.Path.exists", return_value=False), \
             patch.dict("os.environ", {"container": "lxc"}, clear=False):
            assert _detect_runtime_context() == "container (lxc)"

    @pytest.mark.unit
    def test_systemd_invocation_id_detected(self):
        from eneru.cli import _detect_runtime_context

        with patch("pathlib.Path.exists", return_value=False), \
             patch("pathlib.Path.read_text", side_effect=OSError), \
             patch.dict("os.environ", {"INVOCATION_ID": "abc123", "container": ""}, clear=True):
            assert _detect_runtime_context() == "systemd service"

    @pytest.mark.unit
    def test_bare_process_when_no_signals(self):
        from eneru.cli import _detect_runtime_context

        with patch("pathlib.Path.exists", return_value=False), \
             patch("pathlib.Path.read_text", side_effect=OSError), \
             patch.dict("os.environ", {}, clear=True):
            assert _detect_runtime_context() == "bare process"

    @pytest.mark.unit
    def test_container_takes_precedence_over_systemd(self):
        """A systemd unit running inside a container should be reported as container."""
        from eneru.cli import _detect_runtime_context

        def fake_exists(self):
            return str(self) == "/.dockerenv"

        with patch("pathlib.Path.exists", new=fake_exists), \
             patch.dict("os.environ", {"INVOCATION_ID": "abc"}, clear=False):
            assert _detect_runtime_context() == "container (Docker)"

    @pytest.mark.unit
    def test_cgroup_marker_falls_through_to_generic_container(self):
        """Old Docker on cgroup v1 (no /.dockerenv but cgroup path mentions docker)."""
        from eneru.cli import _detect_runtime_context

        def fake_read(self, *args, **kwargs):
            if str(self) == "/proc/1/cgroup":
                return "12:cpu:/docker/abc123\n"
            raise OSError

        with patch("pathlib.Path.exists", return_value=False), \
             patch("pathlib.Path.read_text", new=fake_read), \
             patch.dict("os.environ", {}, clear=True):
            assert _detect_runtime_context() == "container"

    @pytest.mark.unit
    def test_mountinfo_with_docker_path_detects_container(self):
        """Modern Docker on cgroup v2 + cgroupns: cgroup is collapsed but
        mountinfo still has /docker/containers/<id> bind-mount paths."""
        from eneru.cli import _detect_runtime_context

        def fake_read(self, *args, **kwargs):
            if str(self) == "/proc/1/cgroup":
                return "0::/\n"
            if str(self) == "/proc/self/mountinfo":
                return ("123 122 0:9 /docker/containers/abc123/hostname "
                        "/etc/hostname rw - tmpfs tmpfs rw\n")
            raise OSError

        with patch("pathlib.Path.exists", return_value=False), \
             patch("pathlib.Path.read_text", new=fake_read), \
             patch.dict("os.environ", {}, clear=True):
            assert _detect_runtime_context() == "container"

    @pytest.mark.unit
    def test_systemd_via_proc_1_comm_and_journal_stream(self):
        """When INVOCATION_ID isn't set, fall back to PID 1 comm + JOURNAL_STREAM."""
        from eneru.cli import _detect_runtime_context

        def fake_read(self, *args, **kwargs):
            if str(self) == "/proc/1/comm":
                return "systemd\n"
            raise OSError

        with patch("pathlib.Path.exists", return_value=False), \
             patch("pathlib.Path.read_text", new=fake_read), \
             patch.dict("os.environ", {"JOURNAL_STREAM": "8:12345"}, clear=True):
            assert _detect_runtime_context() == "systemd service"


class TestCLIManualRemoteShutdown:
    """Manual remote shutdown drill safety gates."""

    def _remote_config(self, tmp_path):
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "ups:\n"
            "  name: 'TestUPS@localhost'\n"
            "remote_servers:\n"
            "  - name: nas\n"
            "    enabled: true\n"
            "    host: 127.0.0.1\n"
            "    user: root\n"
            "    shutdown_command: 'sudo shutdown -h now'\n"
        )
        return config_file

    @pytest.mark.unit
    def test_real_remote_shutdown_requires_long_confirmation(self, tmp_path, capsys):
        config_file = self._remote_config(tmp_path)
        with patch.object(sys, "argv", [
            "eneru", "shutdown", "remote",
            "-c", str(config_file), "--server", "nas",
        ]):
            with pytest.raises(SystemExit) as exc_info:
                main()
        assert exc_info.value.code == 2
        captured = capsys.readouterr()
        assert "i-really-want" in (captured.out + captured.err)

    @pytest.mark.unit
    def test_remote_shutdown_dry_run_does_not_execute_configured_commands(self, tmp_path):
        config_file = self._remote_config(tmp_path)
        with patch("eneru.cli.run_remote_probe", return_value=(True, "", 1)):
            with patch("eneru.shutdown.remote.RemoteShutdownMixin._run_remote_command") as mock_run:
                with patch.object(sys, "argv", [
                    "eneru", "shutdown", "remote",
                    "-c", str(config_file), "--server", "nas", "--dry-run",
                ]):
                    main()
        mock_run.assert_not_called()

    @pytest.mark.unit
    def test_remote_shutdown_duplicate_server_requires_group(self, tmp_path, capsys):
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "ups:\n"
            "  - name: UPS-A\n"
            "    display_name: rack-a\n"
            "    remote_servers:\n"
            "      - name: nas\n"
            "        enabled: true\n"
            "        host: 10.0.0.10\n"
            "        user: root\n"
            "  - name: UPS-B\n"
            "    display_name: rack-b\n"
            "    remote_servers:\n"
            "      - name: nas\n"
            "        enabled: true\n"
            "        host: 10.0.0.11\n"
            "        user: root\n"
        )

        with patch.object(sys, "argv", [
            "eneru", "shutdown", "remote",
            "-c", str(config_file), "--server", "nas", "--dry-run",
        ]):
            with pytest.raises(SystemExit) as exc_info:
                main()

        assert exc_info.value.code == "ERROR: remote server 'nas' is ambiguous. Use --group. Matches: rack-a, rack-b"

    @pytest.mark.unit
    def test_remote_shutdown_ignores_disabled_servers(self, tmp_path):
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "ups:\n"
            "  name: 'TestUPS@localhost'\n"
            "remote_servers:\n"
            "  - name: nas\n"
            "    enabled: false\n"
            "    host: 127.0.0.1\n"
            "    user: root\n"
        )

        with patch.object(sys, "argv", [
            "eneru", "shutdown", "remote",
            "-c", str(config_file), "--server", "nas", "--dry-run",
        ]):
            with pytest.raises(SystemExit) as exc_info:
                main()

        assert "enabled remote server 'nas' not found" in str(exc_info.value)

    @pytest.mark.unit
    def test_remote_shutdown_log_file_parent_is_created(self, tmp_path):
        from eneru.cli import _CLILogger

        logger = _CLILogger(tmp_path / "drills" / "run.log")

        logger.log("hello")

        assert (tmp_path / "drills" / "run.log").read_text() == "hello\n"


class TestCLITuiAlias:
    """Test that `eneru tui` is registered as an alias for `eneru monitor`."""

    @pytest.mark.unit
    def test_tui_and_monitor_share_handler(self):
        """Both subcommands must dispatch to the same _cmd_monitor handler."""
        from eneru import cli as cli_mod

        for cmd in ("monitor", "tui"):
            with patch.object(sys, "argv", ["eneru", cmd, "--once"]):
                with patch.object(cli_mod, "_cmd_monitor") as mock_handler:
                    main()
                    mock_handler.assert_called_once()

    @pytest.mark.unit
    def test_tui_help_lists_same_options_as_monitor(self, capsys):
        """`eneru tui --help` must list the same options as `eneru monitor --help`.

        We compare the set of option strings (--once, --interval, etc.)
        rather than full text -- argparse's usage-line wrap depends on
        program-name length, so whitespace differs between the two even
        though the options are identical.
        """
        import re

        option_re = re.compile(r"--[a-z][a-z0-9-]+")

        opts_seen = {}
        for cmd in ("monitor", "tui"):
            with patch.object(sys, "argv", ["eneru", cmd, "--help"]):
                with pytest.raises(SystemExit) as exc_info:
                    main()
                assert exc_info.value.code == 0
            opts_seen[cmd] = set(option_re.findall(capsys.readouterr().out))

        assert opts_seen["monitor"] == opts_seen["tui"]
        # Sanity: must include the monitor-specific options, not just
        # the universal --help / --config.
        assert {"--once", "--interval", "--graph", "--time",
                "--events-only", "--verbose", "--length"}.issubset(
            opts_seen["tui"])
        # 5.2.2: --full-history was a transient flag added and removed
        # before release. --length covers the same use case more cleanly
        # (--length 0 = no cap).
        assert "--full-history" not in opts_seen["tui"]


class TestCLICompletion:
    """Test `eneru completion {bash,zsh,fish}` emits a usable script."""

    @pytest.mark.unit
    @pytest.mark.parametrize("shell", ["bash", "zsh", "fish"])
    def test_completion_emits_non_empty_script(self, shell, capsys):
        with patch.object(sys, "argv", ["eneru", "completion", shell]):
            main()
        out = capsys.readouterr().out
        assert len(out) > 100, f"{shell} completion output suspiciously short"
        # Each script must reference 'eneru' so it actually completes
        # the right command.
        assert "eneru" in out

    @pytest.mark.unit
    def test_bash_completion_uses_complete_builtin(self, capsys):
        """The bash script must register itself with `complete -F`."""
        with patch.object(sys, "argv", ["eneru", "completion", "bash"]):
            main()
        out = capsys.readouterr().out
        assert "complete -F _eneru eneru" in out
        # Self-contained: must not call helpers from the bash-completion
        # package. Strip comments before checking so the file's
        # explanatory header (which names these functions to say we
        # *don't* use them) doesn't trigger a false positive.
        code = "\n".join(line.split("#", 1)[0]
                         for line in out.splitlines())
        assert "_init_completion" not in code
        assert "_filedir" not in code

    @pytest.mark.unit
    @pytest.mark.parametrize("shell", ["bash", "zsh", "fish"])
    def test_completion_lists_monitor_event_flags(self, shell, capsys):
        """Packaged completion scripts must track monitor/tui event flags."""
        with patch.object(sys, "argv", ["eneru", "completion", shell]):
            main()
        out = capsys.readouterr().out
        if shell == "fish":
            assert "-l verbose" in out
            assert "-l length" in out
        else:
            assert "--verbose" in out
            assert "--length" in out

    @pytest.mark.unit
    @pytest.mark.parametrize("shell", ["bash", "zsh", "fish"])
    def test_completion_lists_shutdown_remote_flags(self, shell, capsys):
        """Packaged completion scripts must expose manual remote drill flags."""
        with patch.object(sys, "argv", ["eneru", "completion", shell]):
            main()
        out = capsys.readouterr().out
        if shell == "fish":
            for flag in (
                "-l server",
                "-l dry-run",
                "-l i-really-want-to-proceed-with-remote-shutdown",
                "-l no-connectivity-check",
                "-l log-file",
            ):
                assert flag in out
        else:
            for flag in (
                "--server",
                "--dry-run",
                "--i-really-want-to-proceed-with-remote-shutdown",
                "--no-connectivity-check",
                "--log-file",
            ):
                assert flag in out

    @pytest.mark.unit
    def test_invalid_shell_rejected(self):
        """`eneru completion ksh` must fail at argparse, not at file-read."""
        with patch.object(sys, "argv", ["eneru", "completion", "ksh"]):
            with pytest.raises(SystemExit) as exc_info:
                main()
            # argparse exits 2 on invalid choice.
            assert exc_info.value.code == 2


class TestCLIMonitorFlags:
    """Test the --verbose / --length flags on monitor/tui."""

    def _minimal_config(self, tmp_path):
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "ups:\n  name: 'TestUPS@localhost'\n"
            "behavior:\n  dry_run: true\n"
        )
        return config_file

    @pytest.mark.unit
    def test_verbose_short_form_accepted(self, tmp_path):
        """``-v`` adds Diagnostics and reaches run_once as verbose=1."""
        from eneru.tui import run_once
        with patch("eneru.tui.run_once", wraps=run_once) as mock_once:
            config_file = self._minimal_config(tmp_path)
            with patch.object(sys, "argv", ["eneru", "tui",
                                            "-c", str(config_file),
                                            "--once", "--events-only", "-v"]):
                main()
            mock_once.assert_called_once()
            assert mock_once.call_args.kwargs.get("verbose") == 1

    @pytest.mark.unit
    def test_verbose_double_short_form_accepted(self, tmp_path):
        """``-vv`` adds Lifecycle and reaches run_once as verbose=2."""
        from eneru.tui import run_once
        with patch("eneru.tui.run_once", wraps=run_once) as mock_once:
            config_file = self._minimal_config(tmp_path)
            with patch.object(sys, "argv", ["eneru", "tui",
                                            "-c", str(config_file),
                                            "--once", "--events-only", "-vv"]):
                main()
            mock_once.assert_called_once()
            assert mock_once.call_args.kwargs.get("verbose") == 2

    @pytest.mark.unit
    def test_length_default_is_30(self, tmp_path):
        """``--length`` default reaches run_once as 30."""
        from eneru.tui import run_once
        with patch("eneru.tui.run_once", wraps=run_once) as mock_once:
            config_file = self._minimal_config(tmp_path)
            with patch.object(sys, "argv", ["eneru", "tui",
                                            "-c", str(config_file),
                                            "--once", "--events-only"]):
                main()
            assert mock_once.call_args.kwargs.get("length") == 30

    @pytest.mark.unit
    def test_length_explicit_value_accepted(self, tmp_path):
        """``--length 5`` reaches run_once as 5."""
        from eneru.tui import run_once
        with patch("eneru.tui.run_once", wraps=run_once) as mock_once:
            config_file = self._minimal_config(tmp_path)
            with patch.object(sys, "argv", ["eneru", "tui",
                                            "-c", str(config_file),
                                            "--once", "--events-only",
                                            "--length", "5"]):
                main()
            assert mock_once.call_args.kwargs.get("length") == 5

    @pytest.mark.unit
    def test_length_zero_accepted(self, tmp_path):
        """``--length 0`` (no cap) is a valid value."""
        from eneru.tui import run_once
        with patch("eneru.tui.run_once", wraps=run_once) as mock_once:
            config_file = self._minimal_config(tmp_path)
            with patch.object(sys, "argv", ["eneru", "tui",
                                            "-c", str(config_file),
                                            "--once", "--events-only",
                                            "--length", "0"]):
                main()
            assert mock_once.call_args.kwargs.get("length") == 0

    @pytest.mark.unit
    def test_length_negative_rejected(self, tmp_path, capsys):
        """``--length -1`` rejects with argparse exit 2 + clear stderr."""
        config_file = self._minimal_config(tmp_path)
        with patch("eneru.tui.run_once"):
            with patch.object(sys, "argv", ["eneru", "tui",
                                            "-c", str(config_file),
                                            "--once", "--events-only",
                                            "--length", "-1"]):
                with pytest.raises(SystemExit) as exc_info:
                    main()
                assert exc_info.value.code == 2
                err = capsys.readouterr().err
                assert "--length" in err

    @pytest.mark.unit
    def test_length_non_numeric_rejected(self, tmp_path, capsys):
        """``--length foo`` rejects cleanly via the type validator."""
        config_file = self._minimal_config(tmp_path)
        with patch("eneru.tui.run_once"):
            with patch.object(sys, "argv", ["eneru", "tui",
                                            "-c", str(config_file),
                                            "--once", "--events-only",
                                            "--length", "foo"]):
                with pytest.raises(SystemExit) as exc_info:
                    main()
                assert exc_info.value.code == 2

    @pytest.mark.unit
    def test_full_history_flag_no_longer_exists(self, tmp_path, capsys):
        """5.2.2 design: ``--full-history`` was added then removed
        before release. Use ``--length 0`` for the same effect.
        Argparse must reject the flag as unknown."""
        config_file = self._minimal_config(tmp_path)
        with patch("eneru.tui.run_once"):
            with patch.object(sys, "argv", ["eneru", "tui",
                                            "-c", str(config_file),
                                            "--once", "--events-only",
                                            "--full-history"]):
                with pytest.raises(SystemExit) as exc_info:
                    main()
                assert exc_info.value.code == 2
                err = capsys.readouterr().err
                assert "--full-history" in err  # argparse names the bad flag


class TestCLIValidateConfig:
    """Test 'eneru validate' subcommand."""

    @pytest.mark.unit
    def test_validate_config_with_valid_file(self, tmp_path, capsys):
        """Test validating a valid configuration file."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
ups:
  name: "TestUPS@localhost"
  check_interval: 2

behavior:
  dry_run: true
""")

        with patch.object(sys, "argv", [
            "eneru", "validate", "-c", str(config_file)
        ]):
            with pytest.raises(SystemExit) as exc_info:
                main()

            assert exc_info.value.code == 0

        captured = capsys.readouterr()
        assert "Configuration is valid" in captured.out
        assert "TestUPS@localhost" in captured.out
        assert "Dry-run: True" in captured.out

    @pytest.mark.unit
    def test_validate_config_shows_features(self, tmp_path, capsys):
        """Test that validate shows enabled features."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
ups:
  name: "UPS@192.168.1.100"

virtual_machines:
  enabled: true
  max_wait: 60

containers:
  enabled: true
  runtime: podman
  compose_files:
    - "/path/to/compose1.yml"
    - "/path/to/compose2.yml"

remote_servers:
  - name: "Server 1"
    enabled: true
    host: "192.168.1.50"
    user: "admin"
""")

        with patch.object(sys, "argv", [
            "eneru", "validate", "-c", str(config_file)
        ]):
            with pytest.raises(SystemExit) as exc_info:
                main()

            assert exc_info.value.code == 0

        captured = capsys.readouterr()
        assert "Virtual machines" in captured.out
        assert "Containers" in captured.out
        assert "podman" in captured.out
        assert "2 compose file(s)" in captured.out
        assert "Remote server: Server 1" in captured.out

    @pytest.mark.unit
    def test_validate_config_shows_notifications(self, tmp_path, capsys):
        """Test that validate shows notification configuration."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(f"""
ups:
  name: "TestUPS@localhost"

notifications:
  title: "UPS Alert"
  urls:
    - "{TEST_DISCORD_APPRISE_URL}"
    - "{TEST_SLACK_APPRISE_URL}"
""")

        with patch.object(sys, "argv", [
            "eneru", "validate", "-c", str(config_file)
        ]):
            with patch("eneru.cli.APPRISE_AVAILABLE", True):
                with pytest.raises(SystemExit) as exc_info:
                    main()

                assert exc_info.value.code == 0

        captured = capsys.readouterr()
        assert "Notifications:" in captured.out
        assert "2 service(s)" in captured.out
        assert "discord://***" in captured.out
        assert "slack://***" in captured.out
        assert "Title: UPS Alert" in captured.out

    @pytest.mark.unit
    def test_validate_config_nonexistent_file(self, tmp_path, capsys):
        """Validate against a non-existent path: ConfigLoader.load
        prints a warning and falls back to defaults; the resulting
        defaults are valid, so exit is 0.

        The original test asserted only `exit 0` and "Configuration
        is valid", which would have passed even if the typo'd path
        was silently ignored. This now also asserts the fallback
        warning containing the typo'd path appears in stdout, so a
        future regression that swallowed the warning would fail loud.
        Uses tmp_path so the assertion is deterministic across
        environments (the previous hard-coded /nonexistent/path could
        in theory exist on a developer machine).
        """
        typo_path = str(tmp_path / "missing-config.yaml")
        # Sanity: ensure we're not racing a pre-existing file in tmp_path.
        assert not (tmp_path / "missing-config.yaml").exists()
        with patch.object(sys, "argv", [
            "eneru", "validate", "-c", typo_path,
        ]):
            with pytest.raises(SystemExit) as exc_info:
                main()

            assert exc_info.value.code == 0

        captured = capsys.readouterr()
        assert "Configuration is valid" in captured.out
        assert "Config file not found" in captured.out
        assert typo_path in captured.out

    @pytest.mark.unit
    def test_validate_config_without_apprise(self, tmp_path, capsys):
        """Test validate warns when apprise not installed but notifications configured."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(f"""
ups:
  name: "TestUPS@localhost"

notifications:
  urls:
    - "{TEST_DISCORD_APPRISE_URL}"
""")

        with patch.object(sys, "argv", [
            "eneru", "validate", "-c", str(config_file)
        ]):
            with patch("eneru.cli.APPRISE_AVAILABLE", False):
                with pytest.raises(SystemExit) as exc_info:
                    main()

                assert exc_info.value.code == 0

        captured = capsys.readouterr()
        assert "Apprise not installed" in captured.out or "pip install apprise" in captured.out

    @pytest.mark.unit
    def test_validate_config_filesystems(self, tmp_path, capsys):
        """Test validate shows filesystem configuration."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
ups:
  name: "TestUPS@localhost"

filesystems:
  sync_enabled: true
  unmount:
    enabled: true
    mounts:
      - "/mnt/data1"
      - "/mnt/data2"
      - "/mnt/data3"
""")

        with patch.object(sys, "argv", [
            "eneru", "validate", "-c", str(config_file)
        ]):
            with pytest.raises(SystemExit) as exc_info:
                main()

            assert exc_info.value.code == 0

        captured = capsys.readouterr()
        assert "Filesystem sync + unmount 3 mount(s)" in captured.out

    @pytest.mark.unit
    def test_validate_multi_ups_config(self, tmp_path, capsys):
        """Test validate shows multi-UPS overview."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
ups:
  - name: "UPS1@192.168.1.10"
    display_name: "Main UPS"
    is_local: true
    remote_servers:
      - name: "ServerA"
        enabled: true
        host: "192.168.1.20"
        user: "admin"

  - name: "UPS2@192.168.1.11"
    display_name: "Backup UPS"
    remote_servers:
      - name: "ServerB"
        enabled: true
        host: "192.168.1.30"
        user: "admin"
""")

        with patch.object(sys, "argv", [
            "eneru", "validate", "-c", str(config_file)
        ]):
            with pytest.raises(SystemExit) as exc_info:
                main()

            assert exc_info.value.code == 0

        captured = capsys.readouterr()
        assert "multi-UPS" in captured.out
        assert "2 groups" in captured.out
        assert "Main UPS" in captured.out
        assert "Backup UPS" in captured.out
        assert "is_local" in captured.out

    @pytest.mark.unit
    def test_validate_redundancy_groups_section(self, tmp_path, capsys):
        """Validate prints the redundancy_groups summary block — sources,
        quorum settings, remote_servers, and local_resources tags."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
ups:
  - name: "UPS-A"
    display_name: "UPS A"
  - name: "UPS-B"
    display_name: "UPS B"
redundancy_groups:
  - name: "rack-a"
    is_local: true
    ups_sources: ["UPS-A", "UPS-B"]
    min_healthy: 1
    degraded_counts_as: healthy
    unknown_counts_as: degraded
    virtual_machines:
      enabled: true
    containers:
      enabled: true
    remote_servers:
      - name: "node1"
        enabled: true
        host: "node1.lan"
        user: "ops"
local_shutdown:
  enabled: false
  trigger_on: none
""")

        with patch.object(sys, "argv", ["eneru", "validate", "-c", str(config_file)]):
            with pytest.raises(SystemExit) as exc_info:
                main()
            assert exc_info.value.code == 0

        out = capsys.readouterr().out
        assert "Redundancy groups (1)" in out
        assert "rack-a" in out
        assert "[is_local]" in out
        assert "Sources (2): UPS-A, UPS-B" in out
        assert "min_healthy=1" in out
        assert "degraded→healthy" in out
        assert "unknown→degraded" in out
        assert "Remote servers (1): node1" in out
        # Local-resources tags fire only because is_local is true
        assert "Local resources:" in out
        assert "VMs" in out
        assert "containers" in out

    @pytest.mark.unit
    def test_validate_shutdown_sequence_multi_phase_remote(self, tmp_path, capsys):
        """When remote_servers use shutdown_order phases, the sequence
        block prints "Remote servers (N, M phases):" and labels each
        phase with its order key."""
        config_file = tmp_path / "config.yaml"
        # In legacy single-UPS layout, remote_servers is a top-level key
        # (sibling to `ups:`), not nested under it.
        config_file.write_text("""
ups:
  name: "UPS@localhost"
remote_servers:
  - name: "early"
    enabled: true
    host: "h1.lan"
    user: "u"
    shutdown_order: 1
  - name: "mid"
    enabled: true
    host: "h2.lan"
    user: "u"
    shutdown_order: 2
  - name: "late"
    enabled: true
    host: "h3.lan"
    user: "u"
    shutdown_order: 3
""")

        with patch.object(sys, "argv", ["eneru", "validate", "-c", str(config_file)]):
            with pytest.raises(SystemExit) as exc_info:
                main()
            assert exc_info.value.code == 0

        out = capsys.readouterr().out
        # Three explicit phases, three distinct order keys
        assert "Remote servers (3, 3 phases):" in out
        assert "Phase 1 (order=1): early" in out
        assert "Phase 2 (order=2): mid" in out
        assert "Phase 3 (order=3): late" in out

    @pytest.mark.unit
    def test_validate_shutdown_sequence_legacy_parallel_sequential(self, tmp_path, capsys):
        """Legacy `parallel: true/false` flag (without shutdown_order)
        groups remotes into a sequential phase (negative key) and a
        parallel phase, labelled accordingly."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
ups:
  name: "UPS@localhost"
remote_servers:
  - name: "first"
    enabled: true
    host: "h1.lan"
    user: "u"
    parallel: false
  - name: "second"
    enabled: true
    host: "h2.lan"
    user: "u"
    parallel: false
  - name: "third"
    enabled: true
    host: "h3.lan"
    user: "u"
    parallel: true
""")

        with patch.object(sys, "argv", ["eneru", "validate", "-c", str(config_file)]):
            with pytest.raises(SystemExit) as exc_info:
                main()
            assert exc_info.value.code == 0

        out = capsys.readouterr().out
        # Legacy mode labels by execution style, not phase number
        assert "Sequential:" in out
        assert "Parallel:" in out

    @pytest.mark.unit
    def test_validate_handles_unparseable_yaml(self, tmp_path, capsys):
        """If the config file isn't a YAML mapping at the root, validate
        exits 1 and surfaces the parse error inline (covers the
        ConfigValidationLoadError catch in _cmd_validate)."""
        config_file = tmp_path / "config.yaml"
        # Top-level list isn't a valid Eneru config root.
        config_file.write_text("- not\n- a\n- mapping\n")

        with patch.object(sys, "argv", ["eneru", "validate", "-c", str(config_file)]):
            with pytest.raises(SystemExit) as exc_info:
                main()
            assert exc_info.value.code == 1

        out = capsys.readouterr().out
        # The validate command prints "Configuration is INVALID" on any
        # exit_code != 0 path.
        assert "INVALID" in out


class TestCmdRunRouting:
    """`eneru run` routes to UPSGroupMonitor for single-UPS or
    MultiUPSCoordinator for multi-UPS / redundancy configs. Locks
    that the right entry point is picked from the parsed config."""

    @pytest.mark.unit
    def test_multi_ups_routes_to_coordinator(self, tmp_path):
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
ups:
  - name: "UPS-A"
  - name: "UPS-B"
local_shutdown:
  enabled: false
  trigger_on: none
""")
        with patch.object(sys, "argv", ["eneru", "run", "-c", str(config_file),
                                        "--exit-after-shutdown"]), \
             patch.dict("os.environ", {"ENERU_SKIP_PRIVILEGE_CHECK": "1"}, clear=False), \
             patch("eneru.cli.MultiUPSCoordinator") as coord_cls, \
             patch("eneru.cli.UPSGroupMonitor") as mon_cls:
            coord_cls.return_value = MagicMock()
            main()
        coord_cls.assert_called_once()
        mon_cls.assert_not_called()

    @pytest.mark.unit
    def test_redundancy_groups_route_to_coordinator(self, tmp_path):
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
ups:
  - name: "UPS-A"
  - name: "UPS-B"
redundancy_groups:
  - name: "rack"
    ups_sources: ["UPS-A", "UPS-B"]
local_shutdown:
  enabled: false
  trigger_on: none
""")
        with patch.object(sys, "argv", ["eneru", "run", "-c", str(config_file),
                                        "--exit-after-shutdown"]), \
             patch.dict("os.environ", {"ENERU_SKIP_PRIVILEGE_CHECK": "1"}, clear=False), \
             patch("eneru.cli.MultiUPSCoordinator") as coord_cls, \
             patch("eneru.cli.UPSGroupMonitor") as mon_cls:
            coord_cls.return_value = MagicMock()
            main()
        coord_cls.assert_called_once()
        mon_cls.assert_not_called()

    @pytest.mark.unit
    def test_single_ups_routes_to_monitor(self, tmp_path):
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
ups:
  name: "UPS@localhost"
local_shutdown:
  enabled: false
  trigger_on: none
""")
        with patch.object(sys, "argv", ["eneru", "run", "-c", str(config_file),
                                        "--exit-after-shutdown"]), \
             patch.dict("os.environ", {"ENERU_SKIP_PRIVILEGE_CHECK": "1"}, clear=False), \
             patch("eneru.cli.UPSGroupMonitor") as mon_cls, \
             patch("eneru.cli.MultiUPSCoordinator") as coord_cls:
            mon_cls.return_value = MagicMock()
            main()
        mon_cls.assert_called_once()
        coord_cls.assert_not_called()


class TestIterRemoteServerOwners:
    """`_iter_remote_server_owners` yields (label, name, server) for
    every remote server in the config — including redundancy_groups,
    which use a `redundancy:<name>` label prefix."""

    @pytest.mark.unit
    def test_yields_redundancy_group_owners_with_label_prefix(self):
        from eneru.cli import _iter_remote_server_owners
        from eneru import RedundancyGroupConfig, RemoteServerConfig

        config = Config(
            ups_groups=[UPSGroupConfig(
                ups=UPSConfig(name="UPS@host"),
                remote_servers=[
                    RemoteServerConfig(name="ups-target", enabled=True,
                                       host="h1", user="u"),
                ],
            )],
            redundancy_groups=[RedundancyGroupConfig(
                name="rack",
                remote_servers=[
                    RemoteServerConfig(name="rg-target", enabled=True,
                                       host="h2", user="u"),
                ],
            )],
        )
        rows = list(_iter_remote_server_owners(config))
        # First row from ups_groups, second from redundancy_groups
        assert len(rows) == 2
        assert rows[0][0] == "UPS@host"  # owner_label = ups.label
        assert rows[1][0] == "redundancy:rack"
        assert rows[1][2].name == "rg-target"


class TestCLITestNotifications:
    """Test 'eneru test-notifications' subcommand."""

    @pytest.mark.unit
    def test_test_notifications_no_urls(self, tmp_path, capsys):
        """Test that test-notifications fails gracefully when no URLs configured."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
ups:
  name: "TestUPS@localhost"

notifications:
  urls: []
""")

        with patch.object(sys, "argv", [
            "eneru", "test-notifications", "-c", str(config_file)
        ]):
            with pytest.raises(SystemExit) as exc_info:
                main()

            assert exc_info.value.code == 1

        captured = capsys.readouterr()
        assert "No notification URLs configured" in captured.out

    @pytest.mark.unit
    def test_test_notifications_no_apprise(self, tmp_path, capsys):
        """Test that test-notifications fails when apprise not installed."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(f"""
ups:
  name: "TestUPS@localhost"

notifications:
  urls:
    - "{TEST_DISCORD_APPRISE_URL}"
""")

        with patch.object(sys, "argv", [
            "eneru", "test-notifications", "-c", str(config_file)
        ]):
            with patch("eneru.cli.APPRISE_AVAILABLE", False):
                with pytest.raises(SystemExit) as exc_info:
                    main()

                assert exc_info.value.code == 1

        captured = capsys.readouterr()
        assert "Apprise is not installed" in captured.out

    @pytest.mark.unit
    def test_test_notifications_success(self, tmp_path, capsys):
        """Test successful notification test."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(f"""
ups:
  name: "TestUPS@localhost"

notifications:
  title: "Test Title"
  urls:
    - "{TEST_JSON_WEBHOOK_URL}"
""")

        mock_apprise = MagicMock()
        mock_apprise_instance = MagicMock()
        mock_apprise.Apprise.return_value = mock_apprise_instance
        mock_apprise_instance.add.return_value = True
        mock_apprise_instance.notify.return_value = True
        mock_apprise.NotifyType.INFO = "info"

        with patch.object(sys, "argv", [
            "eneru", "test-notifications", "-c", str(config_file)
        ]):
            with patch("eneru.cli.APPRISE_AVAILABLE", True):
                with patch.dict(sys.modules, {"apprise": mock_apprise}):
                    with patch("eneru.cli.apprise", mock_apprise):
                        with pytest.raises(SystemExit) as exc_info:
                            main()

                        assert exc_info.value.code == 0

        captured = capsys.readouterr()
        assert "Test notification sent successfully" in captured.out

    @pytest.mark.unit
    def test_test_notifications_failure(self, tmp_path, capsys):
        """Test failed notification test."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(f"""
ups:
  name: "TestUPS@localhost"

notifications:
  urls:
    - "{TEST_JSON_WEBHOOK_URL}"
""")

        mock_apprise = MagicMock()
        mock_apprise_instance = MagicMock()
        mock_apprise.Apprise.return_value = mock_apprise_instance
        mock_apprise_instance.add.return_value = True
        mock_apprise_instance.notify.return_value = False
        mock_apprise.NotifyType.INFO = "info"

        with patch.object(sys, "argv", [
            "eneru", "test-notifications", "-c", str(config_file)
        ]):
            with patch("eneru.cli.APPRISE_AVAILABLE", True):
                with patch.dict(sys.modules, {"apprise": mock_apprise}):
                    with patch("eneru.cli.apprise", mock_apprise):
                        with pytest.raises(SystemExit) as exc_info:
                            main()

                        assert exc_info.value.code == 1

        captured = capsys.readouterr()
        assert "Failed to send test notification" in captured.out

    @pytest.mark.unit
    def test_test_notifications_invalid_url(self, tmp_path, capsys):
        """Test test-notifications with invalid URL."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
ups:
  name: "TestUPS@localhost"

notifications:
  urls:
    - "invalid://url"
""")

        mock_apprise = MagicMock()
        mock_apprise_instance = MagicMock()
        mock_apprise.Apprise.return_value = mock_apprise_instance
        mock_apprise_instance.add.return_value = False
        mock_apprise.NotifyType.INFO = "info"

        with patch.object(sys, "argv", [
            "eneru", "test-notifications", "-c", str(config_file)
        ]):
            with patch("eneru.cli.APPRISE_AVAILABLE", True):
                with patch.dict(sys.modules, {"apprise": mock_apprise}):
                    with patch("eneru.cli.apprise", mock_apprise):
                        with pytest.raises(SystemExit) as exc_info:
                            main()

                        assert exc_info.value.code == 1

        captured = capsys.readouterr()
        assert "Invalid URL" in captured.out or "No valid notification URLs" in captured.out


class TestCLIDryRun:
    """Test --dry-run CLI flag on run subcommand."""

    @pytest.mark.unit
    def test_dry_run_overrides_config(self, tmp_path):
        """Test that --dry-run overrides config file setting."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
ups:
  name: "TestUPS@localhost"

behavior:
  dry_run: false
""")

        config = ConfigLoader.load(str(config_file))
        assert config.behavior.dry_run is False

        config.behavior.dry_run = True
        assert config.behavior.dry_run is True

    @pytest.mark.unit
    def test_run_refuses_unknown_safety_config_key(self, tmp_path, capsys):
        """The daemon must not start when validation finds hard errors."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
ups:
  name: "TestUPS@localhost"

behavior:
  dry-run: true
""")

        with patch.object(sys, "argv", ["eneru", "run", "-c", str(config_file)]):
            with patch("eneru.cli.UPSGroupMonitor") as mock_monitor:
                with pytest.raises(SystemExit) as exc_info:
                    main()

        assert exc_info.value.code == 1
        mock_monitor.assert_not_called()
        captured = capsys.readouterr()
        assert "behavior.dry-run" in captured.out
        assert "Did you mean 'dry_run'" in captured.out

    @pytest.mark.unit
    def test_run_refuses_malformed_yaml(self, tmp_path, capsys):
        """Malformed YAML must not fall through to daemon startup defaults."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("ups: [broken\n")

        with patch.object(sys, "argv", ["eneru", "run", "-c", str(config_file)]):
            with patch("eneru.cli.UPSGroupMonitor") as mock_monitor:
                with pytest.raises(SystemExit) as exc_info:
                    main()

        assert exc_info.value.code == 1
        mock_monitor.assert_not_called()
        assert "Failed to parse" in capsys.readouterr().out

    @pytest.mark.unit
    def test_run_refuses_non_mapping_yaml_root(self, tmp_path, capsys):
        """A YAML list root is not a valid Eneru config document."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("- just\n- a\n- list\n")

        with patch.object(sys, "argv", ["eneru", "run", "-c", str(config_file)]):
            with patch("eneru.cli.UPSGroupMonitor") as mock_monitor:
                with pytest.raises(SystemExit) as exc_info:
                    main()

        assert exc_info.value.code == 1
        mock_monitor.assert_not_called()
        assert "must be a YAML mapping" in capsys.readouterr().out

    @pytest.mark.unit
    def test_raw_config_validation_loads_empty_yaml_as_empty_mapping(self, tmp_path):
        from eneru.cli import _load_raw_config_for_validation

        config_file = tmp_path / "config.yaml"
        config_file.write_text("")
        args = type("Args", (), {"config": str(config_file)})()

        assert _load_raw_config_for_validation(args) == {}

    @pytest.mark.unit
    def test_validate_checks_unknown_keys_from_default_config_path(
        self, tmp_path, capsys
    ):
        """`eneru validate` without -c still validates the loaded YAML."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
ups:
  name: "TestUPS@localhost"

behavior:
  dry-run: true
""")

        with patch.object(ConfigLoader, "DEFAULT_CONFIG_PATHS", [config_file]):
            with patch.object(sys, "argv", ["eneru", "validate"]):
                with pytest.raises(SystemExit) as exc_info:
                    main()

        assert exc_info.value.code == 1
        captured = capsys.readouterr()
        assert "behavior.dry-run" in captured.out


class TestCLIExitAfterShutdown:
    """Test --exit-after-shutdown CLI flag on run subcommand."""

    @pytest.mark.unit
    def test_exit_after_shutdown_flag_sets_monitor_attribute(self, tmp_path):
        """Test that --exit-after-shutdown flag is passed to UPSGroupMonitor."""
        from eneru import UPSGroupMonitor

        config = Config(ups_groups=[UPSGroupConfig(
            ups=UPSConfig(name="TestUPS@localhost"),
            is_local=True,
        )])

        monitor = UPSGroupMonitor(config)
        assert monitor._exit_after_shutdown is False

        monitor_with_flag = UPSGroupMonitor(config, exit_after_shutdown=True)
        assert monitor_with_flag._exit_after_shutdown is True

    @pytest.mark.unit
    def test_exit_after_shutdown_triggers_exit(self, tmp_path):
        """Test that shutdown sequence exits when flag is set."""
        from eneru import UPSGroupMonitor

        config = Config(
            ups_groups=[UPSGroupConfig(
                ups=UPSConfig(name="TestUPS@localhost"),
                virtual_machines=VMConfig(enabled=False),
                containers=ContainersConfig(enabled=False),
                filesystems=FilesystemsConfig(sync_enabled=False,
                    unmount=UnmountConfig(enabled=False)),
                is_local=True,
            )],
            behavior=BehaviorConfig(dry_run=True),
            logging=LoggingConfig(
                shutdown_flag_file=str(tmp_path / "shutdown-flag"),
                state_file=str(tmp_path / "state"),
                battery_history_file=str(tmp_path / "history"),
            ),
            local_shutdown=LocalShutdownConfig(enabled=False),
        )

        monitor = UPSGroupMonitor(config, exit_after_shutdown=True)
        monitor.state = MonitorState()
        monitor.logger = MagicMock()
        monitor._notification_worker = MagicMock()

        with patch.object(monitor, "_cleanup_and_exit") as mock_exit:
            monitor._execute_shutdown_sequence()
            mock_exit.assert_called_once()

    @pytest.mark.unit
    def test_no_exit_without_flag(self, tmp_path):
        """Test that shutdown sequence does NOT exit when flag is not set."""
        from eneru import UPSGroupMonitor

        config = Config(
            ups_groups=[UPSGroupConfig(
                ups=UPSConfig(name="TestUPS@localhost"),
                virtual_machines=VMConfig(enabled=False),
                containers=ContainersConfig(enabled=False),
                filesystems=FilesystemsConfig(sync_enabled=False,
                    unmount=UnmountConfig(enabled=False)),
                is_local=True,
            )],
            behavior=BehaviorConfig(dry_run=True),
            logging=LoggingConfig(
                shutdown_flag_file=str(tmp_path / "shutdown-flag"),
                state_file=str(tmp_path / "state"),
                battery_history_file=str(tmp_path / "history"),
            ),
            local_shutdown=LocalShutdownConfig(enabled=False),
        )

        monitor = UPSGroupMonitor(config, exit_after_shutdown=False)
        monitor.state = MonitorState()
        monitor.logger = MagicMock()
        monitor._notification_worker = MagicMock()

        with patch.object(monitor, "_cleanup_and_exit") as mock_exit:
            monitor._execute_shutdown_sequence()
            mock_exit.assert_not_called()


class TestCLIConfigPath:
    """Test -c/--config CLI flag."""

    @pytest.mark.unit
    def test_config_short_flag(self, tmp_path, capsys):
        """Test -c flag for specifying config path."""
        config_file = tmp_path / "custom_config.yaml"
        config_file.write_text("""
ups:
  name: "CustomUPS@192.168.1.100"
""")

        with patch.object(sys, "argv", [
            "eneru", "validate", "-c", str(config_file)
        ]):
            with pytest.raises(SystemExit) as exc_info:
                main()

            assert exc_info.value.code == 0

        captured = capsys.readouterr()
        assert "CustomUPS@192.168.1.100" in captured.out

    @pytest.mark.unit
    def test_config_long_flag(self, tmp_path, capsys):
        """Test --config flag for specifying config path."""
        config_file = tmp_path / "my_config.yaml"
        config_file.write_text("""
ups:
  name: "MyUPS@10.0.0.1"
""")

        with patch.object(sys, "argv", [
            "eneru", "validate", "--config", str(config_file)
        ]):
            with pytest.raises(SystemExit) as exc_info:
                main()

            assert exc_info.value.code == 0

        captured = capsys.readouterr()
        assert "MyUPS@10.0.0.1" in captured.out


class TestCLIRemoteList:
    """`eneru remote list` discovery output."""

    def _multi_target_config(self, tmp_path):
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "ups:\n"
            "  - name: UPS-A\n"
            "    display_name: rack-a\n"
            "    is_local: true\n"
            "    remote_servers:\n"
            "      - name: Synology NAS\n"
            "        enabled: true\n"
            "        host: nas.local\n"
            "        user: admin\n"
            "        shutdown_order: 10\n"
            "      - name: Proxmox-1\n"
            "        enabled: true\n"
            "        host: pve1.local\n"
            "        user: root\n"
            "        shutdown_order: 5\n"
            "      - name: dev-box\n"
            "        enabled: false\n"
            "        host: dev.local\n"
            "        user: ubuntu\n"
        )
        return config_file

    @pytest.mark.unit
    def test_remote_list_prints_all_groups(self, tmp_path, capsys):
        config_file = self._multi_target_config(tmp_path)
        with patch.object(sys, "argv", [
            "eneru", "remote", "list", "-c", str(config_file),
        ]):
            main()
        out = capsys.readouterr().out
        assert "REMOTE TARGETS (3 configured, 2 enabled)" in out
        assert "Synology NAS" in out
        assert "Proxmox-1" in out
        assert "dev-box" in out
        # Per-server effective order is what the daemon would actually use,
        # so explicit shutdown_order values must show through.
        assert "10" in out and "5" in out
        # KIND column is present and tags ups groups correctly.
        assert "ups" in out
        # Disabled targets show '—' for ORDER, not a numeric position
        # in a rotation they don't participate in.
        dev_line = next(line for line in out.splitlines() if "dev-box" in line)
        assert "—" in dev_line
        assert "no" in dev_line

    @pytest.mark.unit
    def test_remote_list_group_column_matches_what_shutdown_group_accepts(
        self, tmp_path, capsys,
    ):
        # Regression guard: the GROUP column value must be exactly what
        # `eneru shutdown group --group <X>` accepts (no parentheticals,
        # no `redundancy:` prefix). The CLI resolver looks at name/label
        # for ups groups and name for redundancy groups.
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "ups:\n"
            "  - name: UPS-A\n"
            "    display_name: rack-a\n"
            "    remote_servers:\n"
            "      - name: nas\n"
            "        enabled: true\n"
            "        host: nas.local\n"
            "        user: root\n"
            "redundancy_groups:\n"
            "  - name: rack-pair\n"
            "    ups_sources: [UPS-A]\n"
            "    min_healthy: 1\n"
            "    remote_servers:\n"
            "      - name: vault\n"
            "        enabled: true\n"
            "        host: vault.local\n"
            "        user: root\n"
        )
        with patch.object(sys, "argv", [
            "eneru", "remote", "list", "-c", str(config_file),
        ]):
            main()
        out = capsys.readouterr().out
        # No legacy `name (label)` parenthetical or `redundancy:` prefix.
        assert "(rack-a)" not in out
        assert "redundancy:" not in out
        # The bare group names that --group accepts ARE present.
        nas_line = next(line for line in out.splitlines() if "nas " in line)
        vault_line = next(line for line in out.splitlines() if "vault" in line)
        assert "UPS-A" in nas_line
        assert "rack-pair" in vault_line

    @pytest.mark.unit
    def test_remote_list_shows_user_at_host(self, tmp_path, capsys):
        config_file = self._multi_target_config(tmp_path)
        with patch.object(sys, "argv", [
            "eneru", "remote", "list", "-c", str(config_file),
        ]):
            main()
        out = capsys.readouterr().out
        assert "admin@nas.local" in out
        assert "root@pve1.local" in out

    @pytest.mark.unit
    def test_remote_list_no_targets_exits_nonzero(self, tmp_path, capsys):
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "ups:\n"
            "  name: 'TestUPS@localhost'\n"
        )
        with patch.object(sys, "argv", [
            "eneru", "remote", "list", "-c", str(config_file),
        ]):
            with pytest.raises(SystemExit) as exc_info:
                main()
        assert exc_info.value.code == 1
        assert "No remote targets configured" in capsys.readouterr().out


class TestCLIShutdownGroupRehearsal:
    """`eneru shutdown group --group ...` full-sequence rehearsal."""

    def _ups_group_config(self, tmp_path):
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "ups:\n"
            "  name: 'TestUPS@localhost'\n"
            "  display_name: rack-a\n"
            "remote_servers:\n"
            "  - name: nas\n"
            "    enabled: true\n"
            "    host: 127.0.0.1\n"
            "    user: root\n"
            "    shutdown_command: 'sudo shutdown -h now'\n"
            "local_shutdown:\n"
            "  enabled: false\n"
        )
        return config_file

    def _redundancy_config(self, tmp_path):
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "ups:\n"
            "  - name: UPS-A\n"
            "    display_name: rack-a\n"
            "  - name: UPS-B\n"
            "    display_name: rack-b\n"
            "redundancy_groups:\n"
            "  - name: rack-pair\n"
            "    ups_sources: [UPS-A, UPS-B]\n"
            "    min_healthy: 1\n"
            "    remote_servers:\n"
            "      - name: nas\n"
            "        enabled: true\n"
            "        host: nas.local\n"
            "        user: root\n"
        )
        return config_file

    @pytest.mark.unit
    def test_real_shutdown_requires_long_confirmation(self, tmp_path, capsys):
        config_file = self._ups_group_config(tmp_path)
        with patch.object(sys, "argv", [
            "eneru", "shutdown", "group",
            "-c", str(config_file), "--group", "rack-a",
        ]):
            with pytest.raises(SystemExit) as exc_info:
                main()
        assert exc_info.value.code == 2
        assert "i-really-want-to-proceed-with-group-shutdown" in (
            capsys.readouterr().out
        )

    @pytest.mark.unit
    def test_unknown_group_exits_nonzero(self, tmp_path):
        config_file = self._ups_group_config(tmp_path)
        with patch.object(sys, "argv", [
            "eneru", "shutdown", "group",
            "-c", str(config_file), "--group", "no-such-group",
            "--dry-run",
        ]):
            with pytest.raises(SystemExit) as exc_info:
                main()
        assert "no-such-group" in str(exc_info.value)

    @pytest.mark.unit
    def test_dry_run_invokes_full_sequence_under_dry_run(self, tmp_path):
        config_file = self._ups_group_config(tmp_path)
        with patch(
            "eneru.cli.UPSGroupMonitor"
        ) as mock_monitor_cls:
            mock_monitor = MagicMock()
            mock_monitor_cls.return_value = mock_monitor
            with patch.object(sys, "argv", [
                "eneru", "shutdown", "group",
                "-c", str(config_file), "--group", "rack-a", "--dry-run",
            ]):
                main()
        mock_monitor._execute_shutdown_sequence.assert_called_once()
        # Whatever Config the monitor was instantiated with must have
        # dry_run flipped on; otherwise the rehearsal would be live.
        drill_config = mock_monitor_cls.call_args.args[0]
        assert drill_config.behavior.dry_run is True

    @pytest.mark.unit
    def test_redundancy_group_routes_through_executor(self, tmp_path, capsys):
        config_file = self._redundancy_config(tmp_path)
        with patch(
            "eneru.cli.RedundancyGroupExecutor"
        ) as mock_executor_cls:
            mock_executor = MagicMock()
            mock_executor_cls.return_value = mock_executor
            with patch.object(sys, "argv", [
                "eneru", "shutdown", "group",
                "-c", str(config_file), "--group", "rack-pair", "--dry-run",
            ]):
                main()
        mock_executor.shutdown.assert_called_once()
        # Local poweroff callback is intentionally NOT wired so an
        # operator can't accidentally halt the host with "rehearsal".
        kwargs = mock_executor_cls.call_args.kwargs
        assert kwargs["local_shutdown_callback"] is None
        assert "does not fire local poweroff" in capsys.readouterr().out

    def _is_local_redundancy_config(self, tmp_path):
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "ups:\n"
            "  - name: UPS-A\n"
            "    display_name: rack-a\n"
            "  - name: UPS-B\n"
            "    display_name: rack-b\n"
            "redundancy_groups:\n"
            "  - name: local-pair\n"
            "    ups_sources: [UPS-A, UPS-B]\n"
            "    min_healthy: 1\n"
            "    is_local: true\n"
            "    remote_servers:\n"
            "      - name: nas\n"
            "        enabled: true\n"
            "        host: nas.local\n"
            "        user: root\n"
        )
        return config_file

    @pytest.mark.unit
    def test_is_local_redundancy_confirm_warns_about_destructive_mixins(
        self, tmp_path, capsys,
    ):
        # is_local redundancy + confirm + real execution: the executor
        # still drains VMs/containers/filesystems before the suppressed
        # poweroff. The CLI must explicitly warn about that, not just say
        # "no local poweroff" (which understates the blast radius).
        config_file = self._is_local_redundancy_config(tmp_path)
        with patch("eneru.cli.RedundancyGroupExecutor") as mock_executor_cls:
            mock_executor_cls.return_value = MagicMock()
            with patch.object(sys, "argv", [
                "eneru", "shutdown", "group",
                "-c", str(config_file), "--group", "local-pair",
                "--i-really-want-to-proceed-with-group-shutdown",
            ]):
                main()
        out = capsys.readouterr().out
        assert "WARNING" in out
        assert "local VMs/containers" in out
        assert "unmount configured filesystems" in out

    @pytest.mark.unit
    def test_is_local_redundancy_dry_run_keeps_softer_disclaimer(
        self, tmp_path, capsys,
    ):
        # In dry-run mode no real damage can land, so the softer
        # "rehearsal does not fire local poweroff" line is appropriate.
        config_file = self._is_local_redundancy_config(tmp_path)
        with patch("eneru.cli.RedundancyGroupExecutor") as mock_executor_cls:
            mock_executor_cls.return_value = MagicMock()
            with patch.object(sys, "argv", [
                "eneru", "shutdown", "group",
                "-c", str(config_file), "--group", "local-pair", "--dry-run",
            ]):
                main()
        out = capsys.readouterr().out
        assert "WARNING" not in out
        assert "does not fire local poweroff" in out
