"""SSH-based remote-server shutdown phase.

Owns the multi-server orchestration (sequential vs parallel batching by
``shutdown_order``) plus the per-server lifecycle: ``pre_shutdown_commands``
followed by the final shutdown command.
"""

import shlex
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from eneru.actions import REMOTE_ACTIONS
from eneru.config import RemoteServerConfig
from eneru.utils import run_command


@dataclass
class RemotePreShutdownResult:
    """Best-effort result summary for remote pre-shutdown commands."""

    attempted: int = 0
    failed: int = 0
    timed_out: bool = False
    error: str = ""


@dataclass
class RemoteShutdownResult:
    """Structured result for one remote shutdown worker."""

    server: str
    host: str
    completed: bool = True
    shutdown_sent: bool = False
    dry_run: bool = False
    pre_commands: RemotePreShutdownResult = field(default_factory=RemotePreShutdownResult)
    error: str = ""
    timed_out: bool = False
    crashed: bool = False

    @property
    def success(self) -> bool:
        """Return True only when the final shutdown command was accepted."""
        return (
            self.completed
            and self.shutdown_sent
            and not self.timed_out
            and not self.crashed
            and not self.error
        )


class RemoteShutdownMixin:
    """Mixin: SSH-based remote-server orchestration and shutdown."""

    def _shutdown_remote_servers(self):
        """Shutdown all enabled remote servers via SSH.

        Servers are grouped by their effective shutdown order and processed
        in ascending order.  All servers within a group run in parallel.
        A server alone in its group effectively runs sequentially.

        When shutdown_order is not set, the legacy parallel flag determines
        effective order:
        - parallel: true  (default) -> effective order 0
        - parallel: false -> unique negative orders (run before order 0)
        This preserves exact backward compatibility with existing configs.
        """
        # Imported lazily to avoid a circular import (monitor.py imports
        # this mixin).
        from eneru.monitor import compute_effective_order

        enabled_servers = [s for s in self.config.remote_servers if s.enabled]

        if not enabled_servers:
            return

        # Group servers by effective shutdown order
        ordered = compute_effective_order(enabled_servers)
        phases: Dict[int, List[RemoteServerConfig]] = {}
        for effective, server in ordered:
            phases.setdefault(effective, []).append(server)
        sorted_keys = sorted(phases.keys())

        server_count = len(enabled_servers)
        num_phases = len(sorted_keys)

        if num_phases > 1:
            self._log_message(
                f"🌐 Shutting down {server_count} remote server(s) in {num_phases} phases..."
            )
        elif server_count > 1:
            self._log_message(f"🌐 Shutting down {server_count} remote server(s) in parallel...")
        else:
            self._log_message(f"🌐 Shutting down 1 remote server...")

        results: List[RemoteShutdownResult] = []

        for phase_idx, key in enumerate(sorted_keys, 1):
            phase_servers = phases[key]
            names = ", ".join(s.name or s.host for s in phase_servers)

            if num_phases > 1:
                self._log_message(f"  📋 Phase {phase_idx}/{num_phases} (order={key}): {names}")

            # Use the same deadline-based thread path for one server and
            # many servers. A single unreachable host must not stall the
            # whole shutdown sequence longer than its configured budget.
            results.extend(self._shutdown_servers_parallel(phase_servers))

        # Log summary
        succeeded = sum(1 for result in results if result.success)
        timed_out = sum(1 for result in results if result.timed_out)
        crashed = sum(1 for result in results if result.crashed)
        failed = server_count - succeeded - timed_out - crashed
        icon = "✅" if succeeded == server_count else "⚠️"
        details = [f"{succeeded}/{server_count} succeeded"]
        if failed:
            details.append(f"{failed} failed")
        if timed_out:
            details.append(f"{timed_out} timed out")
        if crashed:
            details.append(f"{crashed} crashed")
        self._log_message(f"  {icon} Remote shutdown complete ({', '.join(details)})")

    def _shutdown_servers_parallel(
        self, servers: List[RemoteServerConfig]
    ) -> List[RemoteShutdownResult]:
        """Shutdown multiple remote servers in parallel using threads.

        Returns one structured result per server.  The join is deadline-based
        so a stuck SSH call cannot multiply the wait by the number of servers.
        """
        def calc_server_timeout(server: RemoteServerConfig) -> int:
            # Explicit None check so a per-command timeout of 0 (e.g. for
            # a command the user wants to fire-and-forget) isn't promoted
            # to server.command_timeout via Python's truthiness.
            pre_cmd_time = sum(
                (cmd.timeout if cmd.timeout is not None else server.command_timeout)
                for cmd in server.pre_shutdown_commands
            )
            return (
                pre_cmd_time
                + server.command_timeout
                + server.connect_timeout
                + server.shutdown_safety_margin
            )

        max_timeout = max(calc_server_timeout(s) for s in servers)

        results: Dict[threading.Thread, RemoteShutdownResult] = {}
        lock = threading.Lock()

        def default_result(
            server: RemoteServerConfig,
            *,
            completed: bool = True,
            error: str = "",
            timed_out: bool = False,
            crashed: bool = False,
        ) -> RemoteShutdownResult:
            return RemoteShutdownResult(
                server=server.name or server.host,
                host=server.host,
                completed=completed,
                shutdown_sent=False,
                pre_commands=RemotePreShutdownResult(),
                error=error,
                timed_out=timed_out,
                crashed=crashed,
            )

        def coerce_result(server: RemoteServerConfig, result) -> RemoteShutdownResult:
            if isinstance(result, RemoteShutdownResult):
                return result
            # Backward-compatible test hook path: older tests monkeypatch
            # _shutdown_remote_server with a function that returns None.
            coerced = default_result(server)
            coerced.shutdown_sent = True
            return coerced

        def shutdown_server_thread(server: RemoteServerConfig):
            """Thread worker for shutting down a single server."""
            result = None
            try:
                try:
                    result = self._shutdown_remote_server(server, deadline=deadline)
                except TypeError as exc:
                    if "unexpected keyword argument 'deadline'" not in str(exc):
                        raise
                    # Backward-compatible test hook path: older tests
                    # monkeypatch _shutdown_remote_server with a function
                    # that accepts only the server argument.
                    result = self._shutdown_remote_server(server)
                result = coerce_result(server, result)
            except Exception as exc:
                # _shutdown_remote_server only catches SSH-style errors;
                # bubbling exceptions (network, AttributeError, OOM…) would
                # otherwise vanish silently in the worker thread.
                display = server.name or server.host
                self._log_message(
                    f"  ❌ Remote shutdown thread for {display} crashed: {exc}"
                )
                result = default_result(server, error=str(exc), crashed=True)
            with lock:
                results[threading.current_thread()] = result

        deadline = time.monotonic() + max_timeout
        threads: List[threading.Thread] = []
        for server in servers:
            t = threading.Thread(
                target=shutdown_server_thread,
                args=(server,),
                name=f"remote-shutdown-{server.name or server.host}",
                daemon=True,
            )
            t.start()
            threads.append(t)

        # Deadline-based join: cap total wait at max_timeout regardless of
        # how many threads are stuck. Per-thread join() with the same
        # max_timeout would stack to N × max_timeout in the worst case.
        for t in threads:
            remaining = max(0.0, deadline - time.monotonic())
            t.join(timeout=remaining)

        still_running = [t for t in threads if t.is_alive()]
        if still_running:
            self._log_message(
                f"  ⚠️ {len(still_running)} remote shutdown(s) still in progress "
                "(continuing with next phase)"
            )

        final_results: List[RemoteShutdownResult] = []
        with lock:
            for thread, server in zip(threads, servers):
                result = results.get(thread)
                if result is None:
                    result = default_result(
                        server,
                        completed=False,
                        timed_out=True,
                        error="remote shutdown worker timed out",
                    )
                final_results.append(result)
        return final_results

    def _run_remote_command(
        self,
        server: RemoteServerConfig,
        command: str,
        timeout: int,
        description: str,
        *,
        deadline: Optional[float] = None,
    ) -> Tuple[bool, str]:
        """Run a single command on a remote server via SSH.

        Returns:
            Tuple of (success, error_message)
        """
        display_name = server.name or server.host

        ssh_cmd = ["ssh"]

        if server.ssh_key_path:
            ssh_cmd.extend(["-i", server.ssh_key_path])

        # Add configured SSH options. Three cases:
        #   1. "-o KEY=VALUE" / "-o KEY VALUE" (single string with space):
        #      split into two argv entries so ssh's getopt parser sees
        #      flag and value separately.
        #   2. Any other "-flag …" form (e.g. "-i", "-p"): pass through
        #      unchanged. Multi-token flags like "-i /path/key" must be
        #      provided as separate ssh_options entries by the user.
        #   3. Bare "KEY=VALUE": prepend "-o" as the implicit form.
        for opt in server.ssh_options:
            if opt.startswith("-o "):
                ssh_cmd.extend(opt.split(None, 1))
            elif opt.startswith("-"):
                ssh_cmd.append(opt)
            else:
                ssh_cmd.extend(["-o", opt])

        ssh_cmd.extend([
            "-o", f"ConnectTimeout={server.connect_timeout}",
            "-o", "BatchMode=yes",  # Prevent password prompts from hanging
            f"{server.user}@{server.host}",
            command
        ])

        # Add buffer to account for SSH connection overhead, unless a
        # shutdown-phase deadline requires a tighter cap. This prevents a
        # hung pre-shutdown command from outliving the phase and later
        # drifting into the final shutdown command.
        command_timeout = timeout + 30
        if deadline is not None:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False, "remote shutdown deadline exceeded"
            command_timeout = max(1, min(command_timeout, int(remaining)))
        exit_code, stdout, stderr = run_command(ssh_cmd, timeout=command_timeout)

        if exit_code == 0:
            return True, ""
        elif exit_code == 124:
            # ``command_timeout`` is the value actually handed to
            # ``run_command`` (timeout + 30 s buffer, capped by the
            # phase deadline). Reporting just ``timeout`` would mislead
            # operators when deadline-capping shrinks the effective
            # window below what was configured per-command.
            if command_timeout != timeout + 30:
                return (
                    False,
                    f"timed out after {command_timeout}s "
                    f"(configured {timeout}s, capped by phase deadline)",
                )
            return False, f"timed out after {timeout}s"
        else:
            error_msg = stderr.strip() if stderr.strip() else f"exit code {exit_code}"
            return False, error_msg

    @staticmethod
    def _remote_deadline_exceeded(deadline: Optional[float] = None) -> bool:
        """Return True when a remote shutdown phase deadline has expired."""
        return deadline is not None and time.monotonic() >= deadline

    def _execute_remote_pre_shutdown(
        self,
        server: RemoteServerConfig,
        *,
        collect_result: bool = False,
        deadline: Optional[float] = None,
    ):
        """Execute pre-shutdown commands on a remote server.

        Returns:
            True once the loop has iterated through every command.
            Per-command failures are logged and execution continues
            (best-effort) — there is no current code path that returns
            False.
        """
        if not server.pre_shutdown_commands:
            if collect_result:
                return RemotePreShutdownResult()
            return True

        display_name = server.name or server.host
        cmd_count = len(server.pre_shutdown_commands)
        result = RemotePreShutdownResult()

        self._log_message(f"  📋 Executing {cmd_count} pre-shutdown command(s)...")

        for idx, cmd_config in enumerate(server.pre_shutdown_commands, 1):
            if self._remote_deadline_exceeded(deadline):
                result.timed_out = True
                result.error = "remote shutdown deadline exceeded before pre-shutdown completed"
                self._log_message(
                    f"    ⚠️ [{idx}/{cmd_count}] Skipping remaining pre-shutdown "
                    "commands: remote shutdown deadline exceeded"
                )
                break

            # Determine timeout
            timeout = cmd_config.timeout
            if timeout is None:
                timeout = server.command_timeout

            # Handle predefined action
            if cmd_config.action:
                action_name = cmd_config.action.lower()

                if action_name not in REMOTE_ACTIONS:
                    self._log_message(
                        f"    ⚠️ [{idx}/{cmd_count}] Unknown action: {action_name} (skipping)"
                    )
                    result.failed += 1
                    continue

                # Validate stop_compose has path BEFORE rendering the
                # template; otherwise the precondition warning becomes
                # dead code (shlex.quote("") would happily produce ''
                # and a future template change might let the bad command
                # slip through).
                if action_name == "stop_compose" and not cmd_config.path:
                    self._log_message(
                        f"    ⚠️ [{idx}/{cmd_count}] stop_compose requires 'path' parameter (skipping)"
                    )
                    result.failed += 1
                    continue

                # Get command template and substitute placeholders.
                # `path` is shlex-quoted because the template embeds it
                # directly into the remote shell — without quoting, a
                # malicious or malformed path could expand $(), `…`, or
                # ${…} on the remote host.
                command_template = REMOTE_ACTIONS[action_name]
                command = command_template.format(
                    timeout=timeout,
                    path=shlex.quote(cmd_config.path or "")
                )
                description = action_name

            # Handle custom command
            elif cmd_config.command:
                command = cmd_config.command
                # Truncate long commands for display
                if len(command) > 50:
                    description = command[:47] + "..."
                else:
                    description = command

            else:
                self._log_message(
                    f"    ⚠️ [{idx}/{cmd_count}] No action or command specified (skipping)"
                )
                result.failed += 1
                continue

            # Log what we're about to do
            self._log_message(f"    ➡️ [{idx}/{cmd_count}] {description} (timeout: {timeout}s)")
            result.attempted += 1

            if self.config.behavior.dry_run:
                self._log_message(f"    🧪 [DRY-RUN] Would execute on {display_name}")
                continue

            # Execute the command
            success, error_msg = self._run_remote_command(
                server, command, timeout, description, deadline=deadline
            )

            if success:
                self._log_message(f"    ✅ [{idx}/{cmd_count}] {description} completed")
            else:
                result.failed += 1
                self._log_message(
                    f"    ⚠️ [{idx}/{cmd_count}] {description} failed: {error_msg} (continuing)"
                )

            if self._remote_deadline_exceeded(deadline):
                result.timed_out = True
                result.error = "remote shutdown deadline exceeded during pre-shutdown"
                self._log_message(
                    "    ⚠️ Remote shutdown deadline reached during pre-shutdown; "
                    "final shutdown command will not be sent"
                )
                break

        if collect_result:
            return result
        return True

    def _shutdown_remote_server(
        self,
        server: RemoteServerConfig,
        *,
        deadline: Optional[float] = None,
    ) -> RemoteShutdownResult:
        """Shutdown a single remote server via SSH.

        Execution order:
        1. Execute pre_shutdown_commands (if any) - best effort
        2. Execute shutdown_command
        """
        display_name = server.name or server.host
        has_pre_cmds = len(server.pre_shutdown_commands) > 0
        result = RemoteShutdownResult(
            server=display_name,
            host=server.host,
            pre_commands=RemotePreShutdownResult(),
        )

        self._log_message(f"🌐 Initiating remote shutdown: {display_name} ({server.host})...")

        # Send notification for remote server shutdown start
        self._send_notification(
            f"🌐 **Remote Shutdown Starting:** {display_name}\n"
            f"Host: {server.host}",
            self.config.NOTIFY_INFO,
            category="shutdown",
        )

        # Execute pre-shutdown commands first
        if has_pre_cmds:
            result.pre_commands = self._execute_remote_pre_shutdown(
                server, collect_result=True, deadline=deadline,
            )

        if result.pre_commands.timed_out or self._remote_deadline_exceeded(deadline):
            result.completed = False
            result.timed_out = True
            result.error = (
                result.pre_commands.error
                or "remote shutdown deadline exceeded before final shutdown command"
            )
            self._log_message(
                f"  ⚠️ Skipping final shutdown command for {display_name}: {result.error}"
            )
            return result

        # Execute final shutdown command
        self._log_message(f"  🔌 Sending shutdown command: {server.shutdown_command}")

        if self.config.behavior.dry_run:
            result.shutdown_sent = True
            result.dry_run = True
            self._log_message(
                f"  🧪 [DRY-RUN] Would send command '{server.shutdown_command}' to "
                f"{server.user}@{server.host}"
            )
            return result

        success, error_msg = self._run_remote_command(
            server,
            server.shutdown_command,
            server.command_timeout,
            "shutdown",
            deadline=deadline,
        )

        if success:
            result.shutdown_sent = True
            self._log_message(f"  ✅ {display_name} shutdown command sent successfully")
            # Per-server success used to fire a notification too; dropped in
            # v5.2 — the "Starting" notification is the per-server signal,
            # the aggregate "Sequence Complete" rolls up the result, and
            # journalctl carries the full trace. Failures still notify
            # because they're the only thing the user actually needs to act
            # on individually.
        else:
            result.error = error_msg
            self._log_message(
                f"  ❌ WARNING: Failed to execute shutdown command on {display_name}: {error_msg}"
            )
            self._send_notification(
                f"❌ **Remote Shutdown Failed:** {display_name}\n"
                f"Error: {error_msg}",
                self.config.NOTIFY_FAILURE,
                category="shutdown",
            )
        return result
