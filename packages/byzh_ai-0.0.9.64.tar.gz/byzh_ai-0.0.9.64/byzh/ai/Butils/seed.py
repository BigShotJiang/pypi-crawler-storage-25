import random
import numpy as np
import torch

def b_set_every_seed(seed=42):
    """
    需要在所有随机行为开始前使用\n
    建议在主代码的第一行先导入执行

    random, numpy, torch
    """
    ##### 设置random的随机数种子
    random.seed(seed)

    ##### 设置numpy的随机数种子
    np.random.seed(seed)

    ##### 设置pytorch的随机数种子
    torch.manual_seed(seed) # CPU 随机数种子
    torch.cuda.manual_seed(seed) # 当前 GPU 的随机种子
    torch.cuda.manual_seed_all(seed) # 所有 GPU 的随机种子

    # 代价: 速度稍微慢一点
    torch.backends.cudnn.deterministic = True # 强制 cuDNN 使用确定性算法
    torch.backends.cudnn.benchmark = False # 关闭 cuDNN 自动寻找最快算法

    # 可传给Dataloader的generator=g
    g = torch.Generator()
    g.manual_seed(seed)

    # =============
    # 拓展: 如果Dataloader的num_workers > 0, 则还要设置worker_init_fn

    return g