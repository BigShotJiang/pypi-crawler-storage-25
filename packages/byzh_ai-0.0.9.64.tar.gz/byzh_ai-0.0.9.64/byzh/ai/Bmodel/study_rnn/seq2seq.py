import random
import torch
import torch.nn as nn
import torch.nn.functional as F

from byzh.ai.Butils import b_get_params

# T: 序列长度
# L: num_layers
class B_Seq2Seq_Encoder(nn.Module):
    """
    Encoder:
        输入 token 序列 -> hidden states -> 最终隐藏状态

    输入:
        x: (B, T_in)
    输出:
        outputs: (B, T_in, H)
        hT: (num_layers, B, H)
    """

    def __init__(
        self,
        vocab_size: int,
        emb_dim: int,
        hidden_size: int,
        num_layers: int = 1,
        pad_idx: int = 0, # 规定词表里 index=0 代表 <pad>
        dropout: float = 0.1,
        batch_first: bool = True
    ):
        super().__init__()
        self.batch_first = batch_first
        # 把“离散的 token id” 映射成 “连续的向量表示（embedding）”
        self.embedding = nn.Embedding(vocab_size, emb_dim, padding_idx=pad_idx)
        # GRU最省事, 也可以换成别的
        self.gru = nn.GRU(
            input_size=emb_dim,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=batch_first,
            dropout=dropout if num_layers > 1 else 0.0
        )

    def forward(self, x):
        """
        x: (B, T_in)
        """
        emb = self.embedding(x)          # (B, T_in, E)
        outputs, hT = self.gru(emb)      # outputs: (B, T_in, H), hT: (L, B, H)
        return outputs, hT


class B_Seq2Seq_Decoder(nn.Module):
    """
    Decoder:
        每次输入一个 token，输出一步预测

    输入:
        y_t: (B,)                当前步输入 token id
        h_prev: (L, B, H)        上一步隐藏状态

    输出:
        logits: (B, vocab_size)
        h_t: (L, B, H)
    """

    def __init__(
        self,
        vocab_size: int,
        emb_dim: int,
        hidden_size: int,
        num_layers: int = 1,
        pad_idx: int = 0, # 规定词表里 index=0 代表 <pad>
        dropout: float = 0.1
    ):
        super().__init__()
        # 把“离散的 token id” 映射成 “连续的向量表示（embedding）”
        self.embedding = nn.Embedding(vocab_size, emb_dim, padding_idx=pad_idx)
        # GRU最省事, 也可以换成别的
        self.gru = nn.GRU(
            input_size=emb_dim,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0
        )
        self.fc = nn.Linear(hidden_size, vocab_size)

    def forward(self, y_t, h_prev):
        """
        y_t: (B,)
        h_prev: (L, B, H)
        """
        emb = self.embedding(y_t)            # (B, E)
        emb = emb.unsqueeze(1)               # (B, 1, E)

        out, h_t = self.gru(emb, h_prev)     # out: (B, 1, H)
        out = out.squeeze(1)                 # out: (B, H)
        logits = self.fc(out)     # (B, vocab_size)

        return logits, h_t


class B_Seq2Seq(nn.Module):
    """
    基础版 Seq2Seq（Encoder-Decoder）
    - 训练时支持 teacher forcing
    - 推理时自回归生成
    """

    def __init__(
        self,
        src_vocab_size: int,
        tgt_vocab_size: int,
        emb_dim: int,
        hidden_size: int,
        num_layers: int = 1,
        src_pad_idx: int = 0,
        tgt_pad_idx: int = 0,
        dropout: float = 0.1,
        bos_idx: int = 1,
        eos_idx: int = 2
    ):
        super().__init__()

        self.encoder = B_Seq2Seq_Encoder(
            vocab_size=src_vocab_size,
            emb_dim=emb_dim,
            hidden_size=hidden_size,
            num_layers=num_layers,
            pad_idx=src_pad_idx,
            dropout=dropout
        )

        self.decoder = B_Seq2Seq_Decoder(
            vocab_size=tgt_vocab_size,
            emb_dim=emb_dim,
            hidden_size=hidden_size,
            num_layers=num_layers,
            pad_idx=tgt_pad_idx,
            dropout=dropout
        )

        self.tgt_vocab_size = tgt_vocab_size
        self.bos_idx = bos_idx
        self.eos_idx = eos_idx

    def forward(self, src, tgt=None, teacher_forcing_ratio: float = 0.5, max_len: int = 50):
        """
        训练:
            src: (B, T_src)
            tgt: (B, T_tgt)   这里通常 tgt[:,0] = <bos>

        推理:
            src: (B, T_src)
            tgt: None

        返回:
            outputs:
                如果训练: (B, T_tgt-1, vocab_size)
                如果推理: (B, max_len, vocab_size)
        """
        B = src.size(0)
        device = src.device

        # 1) 编码
        enc_outputs, hT = self.encoder(src)

        # 2) 初始化 decoder hidden
        dec_hidden = hT

        outputs = []

        # ===== 训练模式 =====
        if tgt is not None:
            T_tgt = tgt.size(1)

            # 第一步输入通常是 <bos>
            dec_input = tgt[:, 0]   # (B,)

            for t in range(1, T_tgt):
                logits, dec_hidden = self.decoder(dec_input, dec_hidden)
                outputs.append(logits)

                teacher_force = random.random() < teacher_forcing_ratio
                top1 = logits.argmax(dim=-1)  # (B,)

                # teacher forcing: 下一个输入用真实 token
                dec_input = tgt[:, t] if teacher_force else top1

            outputs = torch.stack(outputs, dim=1)  # (B, T_tgt-1, vocab_size)
            return outputs

        # ===== 推理模式 =====
        else:
            dec_input = torch.full((B,), self.bos_idx, dtype=torch.long, device=device)

            for _ in range(max_len):
                logits, dec_hidden = self.decoder(dec_input, dec_hidden)
                outputs.append(logits)

                top1 = logits.argmax(dim=-1)
                dec_input = top1

            outputs = torch.stack(outputs, dim=1)  # (B, max_len, vocab_size)
            return outputs


if __name__ == "__main__":
    # ===== 超参数 =====
    B = 4
    T_src = 7
    T_tgt = 6
    src_vocab_size = 100
    tgt_vocab_size = 120
    emb_dim = 32
    hidden_size = 64

    model = B_Seq2Seq(
        src_vocab_size=src_vocab_size,
        tgt_vocab_size=tgt_vocab_size,
        emb_dim=emb_dim,
        hidden_size=hidden_size,
        num_layers=1,
        bos_idx=1,
        eos_idx=2
    )

    src = torch.randint(3, src_vocab_size, (B, T_src))
    tgt = torch.randint(3, tgt_vocab_size, (B, T_tgt))
    tgt[:, 0] = 1  # <bos>

    out = model(src, tgt=tgt, teacher_forcing_ratio=0.5)
    print(out.shape)   # (B, T_tgt-1, tgt_vocab_size)

    out_infer = model(src, tgt=None, max_len=10)
    print(out_infer.shape)  # (B, 10, tgt_vocab_size)

    print(f"参数量: {b_get_params(model)}") # 52_472