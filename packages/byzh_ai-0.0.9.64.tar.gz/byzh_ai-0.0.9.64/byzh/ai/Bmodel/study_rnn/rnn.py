import torch
import torch.nn as nn
import torch.nn.functional as F

from byzh.ai.Butils import b_get_params

####
class B_RNN_Paper(nn.Module):
    """
    工程版 Elman RNN: (使用2个nn.Linear代替2个W和b自动计算)
        h_t = phi( i2h(x_t) + h2h(h_{t-1}) )
        y_t = h2y(h_t)   (可选)

    B = batch size
    T = sequence length
    D = input_size
    H = hidden_size
    C = output_size
    """

    def __init__(self, input_size: int, hidden_size: int, output_size: int = None,
                 nonlinearity: str = "tanh", batch_first: bool = True, bias: bool = True):
        super().__init__()
        assert nonlinearity in ["tanh", "relu"]
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.batch_first = batch_first
        self.nonlinearity = nonlinearity

        # 工程封装：两个线性层
        self.i2h = nn.Linear(input_size, hidden_size, bias=bias) # (D, H)
        self.h2h = nn.Linear(hidden_size, hidden_size, bias=bias) # (H, H)

        # 可选: 给输出层接一个linear
        self.h2y = nn.Linear(hidden_size, output_size, bias=bias) if output_size is not None else None

        self.reset_parameters()

    def _phi(self, x):
        if self.nonlinearity == "tanh":
            return torch.tanh(x)
        else:
            return F.relu(x)

    def step(self, x_t, h_prev) -> torch.Tensor:
        """
        x_t: (B, D)
        h_prev: (B, H)
        """
        pre = self.i2h(x_t) + self.h2h(h_prev)  # (B, H)
        h_t = self._phi(pre) # (B, H)
        return h_t

    def forward(self, x, h0=None, return_sequences=True):
        """
        参数
        ----------
        x : torch.Tensor
            输入序列。
            如果 batch_first=True: shape = (B, T, D)
            如果 batch_first=False: shape = (T, B, D)

        h0 : torch.Tensor | None, default=None
            初始隐藏状态。
            shape = (B, H)
            如果为 None，则自动初始化为全 0。

        return_sequences : bool, default=True
            是否返回完整的隐藏状态序列。
            - True  : 返回所有时间步的隐藏状态
            - False : 只返回最终隐藏状态


        返回
        ----------
        hs : torch.Tensor | None
            所有时间步(1到T)的隐藏状态(h1到hT)。
            如果 return_sequences=True：
                batch_first=True: shape = (B, T, H)
                batch_first=False: shape = (T, B, H)
            如果 return_sequences=False：
                hs = None

        hT : torch.Tensor
            最终时间步的隐藏状态。
            shape = (B, H)

        ys : torch.Tensor | None
            每个时间步(1到T)的输出(y1到yT)。
            仅当 `self.h2y` 存在 且 return_sequences=True 时返回。
            shape:
                batch_first=True: (B, T, C)
                batch_first=False: (T, B, C)
        """
        if not self.batch_first:
            x = x.transpose(0, 1)  # (B,T,D)

        B, T, D = x.shape

        h_t = x.new_zeros(B, self.hidden_size) if h0 is None else h0

        hs = [] if return_sequences else None
        ys = [] if (return_sequences and self.h2y is not None) else None

        for t in range(T):
            h_t = self.step(x[:, t, :], h_t)
            if return_sequences:
                hs.append(h_t)
                if self.h2y is not None:
                    ys.append(self.h2y(h_t))

        hT = h_t

        if return_sequences:
            hs = torch.stack(hs, dim=1)  # (B,T,H)
            if ys is not None:
                ys = torch.stack(ys, dim=1)  # (B,T,C)

            if not self.batch_first:
                hs = hs.transpose(0, 1)  # (T,B,H)
                if ys is not None:
                    ys = ys.transpose(0, 1)

        return hs, hT, ys

    def reset_parameters(self):
        # 一般工程里这套很常见：i2h 用 xavier，h2h 用 orthogonal 更稳
        nn.init.xavier_uniform_(self.i2h.weight)
        nn.init.orthogonal_(self.h2h.weight)

        if self.i2h.bias is not None:
            nn.init.zeros_(self.i2h.bias)
        if self.h2h.bias is not None:
            nn.init.zeros_(self.h2h.bias)

        if self.h2y is not None:
            nn.init.xavier_uniform_(self.h2y.weight)
            if self.h2y.bias is not None:
                nn.init.zeros_(self.h2y.bias)

class B_RNN_Paper_Layers(nn.Module):
    """
    多层 Elman RNN（通过堆叠多个 B_RNN_Paper 实现）

    说明：
    - 第1层输入: input_size
    - 第2~L层输入: hidden_size
    - 可选只在最后一层接 output_size
    """

    def __init__(
        self,
        input_size: int,
        hidden_size: int,
        num_layers: int = 2,
        output_size: int = None,
        nonlinearity: str = "tanh",
        batch_first: bool = True,
        bias: bool = True,
    ):
        super().__init__()
        assert num_layers >= 1

        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.output_size = output_size
        self.batch_first = batch_first
        self.nonlinearity = nonlinearity

        layers = []
        for i in range(num_layers):
            cur_input_size = input_size if i == 0 else hidden_size
            cur_output_size = output_size if i == num_layers - 1 else None

            layer = B_RNN_Paper(
                input_size=cur_input_size,
                hidden_size=hidden_size,
                output_size=cur_output_size,
                nonlinearity=nonlinearity,
                batch_first=batch_first,
                bias=bias,
            )
            layers.append(layer)

        self.layers = nn.ModuleList(layers)

    def forward(self, x, h0_list=None, return_sequences=True):
        """
        参数
        ----------
        x : torch.Tensor
            输入序列
            batch_first=True  -> (B, T, D)
            batch_first=False -> (T, B, D)

        h0_list : list[torch.Tensor] | None
            每一层的初始隐藏状态列表，长度应为 num_layers
            每个元素 shape = (B, H)

        return_sequences : bool
            是否返回最后一层的完整隐藏状态序列

        返回
        ----------
        hs : torch.Tensor | None
            最后一层所有时间步隐藏状态
            batch_first=True  -> (B, T, H)
            batch_first=False -> (T, B, H)

        hT_list : list[torch.Tensor]
            每一层最终隐藏状态
            每个元素 shape = (B, H)

        ys : torch.Tensor | None
            最后一层每个时间步输出
            仅当最后一层设置了 output_size 且 return_sequences=True 时存在
        """
        if h0_list is None:
            h0_list = [None] * self.num_layers
        else:
            assert len(h0_list) == self.num_layers

        out = x
        hT_list = []
        ys = None

        for i, layer in enumerate(self.layers):
            out, hT, ys = layer(out, h0=h0_list[i], return_sequences=True)
            hT_list.append(hT)

        hs = out if return_sequences else None

        if not return_sequences:
            hs = None

        return hs, hT_list, ys


#####
class B_RNN_Paper_Parameter(nn.Module):
    """
    Elman RNN: (使用nn.Parameter手动计算)
        h_t = tanh(x_t W_xh + h_{t-1} W_hh + b_h)
        y_t = h_t W_hy + b_y   (可选)

    说明：
    - 这里用 batch_first=True: 输入 (B, T, D)
    - hidden: (B, H)
    """

    def __init__(
        self, input_size: int,
        hidden_size: int,
        output_size: int = None, # 如果有, 则再加一个特征的映射
        nonlinearity: str = "tanh",
        batch_first: bool = True
    ):
        super().__init__()
        assert nonlinearity in ["tanh", "relu"]
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.batch_first = batch_first
        self.nonlinearity = nonlinearity

        # 对齐论文：三组参数
        self.W_xh = nn.Parameter(torch.empty(input_size, hidden_size)) # (D, H)
        self.W_hh = nn.Parameter(torch.empty(hidden_size, hidden_size)) # (H, H)
        self.b_h = nn.Parameter(torch.zeros(hidden_size)) # (H,)

        if output_size is not None:
            self.W_hy = nn.Parameter(torch.empty(hidden_size, output_size)) # (H, C)
            self.b_y = nn.Parameter(torch.zeros(output_size))
        else:
            self.W_hy, self.b_y = None, None

        self.reset_parameters()

    def reset_parameters(self):
        # 经典初始化：Xavier/Orthogonal 都常见
        nn.init.xavier_uniform_(self.W_xh)
        nn.init.orthogonal_(self.W_hh)
        # b_h, b_y 默认 0

        if self.output_size is not None:
            nn.init.xavier_uniform_(self.W_hy)

    def _phi(self, x):
        if self.nonlinearity == "tanh":
            return torch.tanh(x)
        else:
            return F.relu(x)

    def step(self, x_t, h_prev) -> torch.Tensor:
        """
        单步：$h=tanh(x_t W_xh + h_{t-1} W_hh + b_h)$
        x_t: (B, D)
        h_prev: (B, H)
        return h_t: (B, H)
        """
        pre = x_t @ self.W_xh + h_prev @ self.W_hh + self.b_h
        h_t = self._phi(pre)
        return h_t

    def forward(self, x, h0=None, return_sequences=True):
        """
        x: (B, T, D)
        h0: (B, H) 可选
        return_sequences: 以tensor的B来代替列表返回

        return:
        - hs: (B, T, H) or (T, B, H)  if return_sequences
        - hT: (B, H)
        - ys: (B, T, C) / ... if output_size is not None and return_sequences
        """
        if not self.batch_first:
            x = x.transpose(0, 1)  # -> (B, T, D)

        B, T, D = x.shape

        if h0 is None:
            h_t = x.new_zeros(B, self.hidden_size)
        else:
            h_t = h0

        hs = []
        ys = [] if self.output_size is not None else None

        for t in range(T):
            x_t = x[:, t, :]               # (B, D)
            h_t = self.step(x_t, h_t)      # (B, H)
            if return_sequences:
                hs.append(h_t)

            if self.output_size is not None and return_sequences:
                y_t = h_t @ self.W_hy + self.b_y  # (B, C)
                ys.append(y_t)

        hT = h_t

        if return_sequences:
            hs = torch.stack(hs, dim=1)  # (B, T, H)
            if self.output_size is not None:
                ys = torch.stack(ys, dim=1)  # (B, T, C)
        else:
            hs = None
            ys = None

        if not self.batch_first and return_sequences:
            hs = hs.transpose(0, 1)  # back to (T, B, H)
            if ys is not None:
                ys = ys.transpose(0, 1)

        return hs, hT, ys



####
class B_RNN_Paper_Fast(nn.Module):
    """
    更工程、更快的 Elman RNN: (使用1个nn.Linear代替2个nn.Linear合并计算)
        h_t = phi( linear([x_t, h_{t-1}]) )
        y_t = h2y(h_t) (可选)
    """

    def __init__(self, input_size: int, hidden_size: int, output_size: int = None,
                 nonlinearity: str = "tanh", batch_first: bool = True, bias: bool = True):
        super().__init__()
        assert nonlinearity in ["tanh", "relu"]
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.batch_first = batch_first
        self.nonlinearity = nonlinearity

        # 合并为一次 Linear: (D+H) -> H
        self.xh2h = nn.Linear(input_size + hidden_size, hidden_size, bias=bias)

        self.h2y = nn.Linear(hidden_size, output_size, bias=bias) if output_size is not None else None

        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.xh2h.weight)
        if self.xh2h.bias is not None:
            nn.init.zeros_(self.xh2h.bias)

        if self.h2y is not None:
            nn.init.xavier_uniform_(self.h2y.weight)
            if self.h2y.bias is not None:
                nn.init.zeros_(self.h2y.bias)

    def _phi(self, x):
        if self.nonlinearity == "tanh":
            return torch.tanh(x)
        else:
            return F.relu(x)

    def step(self, x_t, h_prev) -> torch.Tensor:
        inp = torch.cat([x_t, h_prev], dim=-1)  # (B, D+H)
        h_t = self._phi(self.xh2h(inp)) # (B, H)
        return h_t

    def forward(self, x: torch.Tensor, h0: torch.Tensor = None, return_sequences: bool = True):
        if not self.batch_first:
            x = x.transpose(0, 1)  # (B,T,D)

        B, T, D = x.shape

        h_t = x.new_zeros(B, self.hidden_size) if h0 is None else h0

        hs = [] if return_sequences else None
        ys = [] if (return_sequences and self.h2y is not None) else None

        for t in range(T):
            h_t = self.step(x[:, t, :], h_t)
            if return_sequences:
                hs.append(h_t)
                if self.h2y is not None:
                    ys.append(self.h2y(h_t))

        hT = h_t

        if return_sequences:
            hs = torch.stack(hs, dim=1)  # (B,T,H)
            if ys is not None:
                ys = torch.stack(ys, dim=1)  # (B,T,C)

            if not self.batch_first:
                hs = hs.transpose(0, 1)
                if ys is not None:
                    ys = ys.transpose(0, 1)

        return hs, hT, ys

if __name__ == '__main__':
    # ===== 超参数 =====
    B = 50  # batch size
    T = 6  # sequence length
    D = 8  # input_size
    H = 16  # hidden_size
    C = 5  # output_size

    net = B_RNN_Paper(D, H, C, batch_first=True)
    a = torch.randn(B, T, D)
    hs, hT, ys = net(a)
    print(hT.shape)
    print(f"参数量: {b_get_params(net)}")  # 501