# train_seq2seq_date.py
# 完整可运行：Seq2Seq 做日期格式转换
# 任务：
#   输入:  YYYY-MM-DD
#   输出:  DD/MM/YYYY

import random
from dataclasses import dataclass

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader


# =========================
# 1. 固定随机种子
# =========================
def set_seed(seed=2026):
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# =========================
# 2. 词表工具
# =========================
class Vocab:
    def __init__(self, tokens):
        uniq = []
        seen = set()
        for t in tokens:
            if t not in seen:
                uniq.append(t)
                seen.add(t)

        self.token_to_id = {t: i for i, t in enumerate(uniq)}
        self.id_to_token = {i: t for t, i in self.token_to_id.items()}

        self.pad = self.token_to_id["<pad>"]
        self.bos = self.token_to_id["<bos>"]
        self.eos = self.token_to_id["<eos>"]
        self.unk = self.token_to_id["<unk>"]

    def encode(self, tokens):
        return [self.token_to_id.get(t, self.unk) for t in tokens]

    def decode(self, ids, remove_special=True):
        tokens = []
        for i in ids:
            t = self.id_to_token[int(i)]
            if remove_special and t in {"<pad>", "<bos>", "<eos>"}:
                continue
            tokens.append(t)
        return tokens

    def __len__(self):
        return len(self.token_to_id)


# =========================
# 3. 数据生成
# =========================
def random_date():
    year = random.randint(2000, 2030)
    month = random.randint(1, 12)

    # 简化处理，避免复杂闰年逻辑
    if month == 2:
        day = random.randint(1, 28)
    elif month in {4, 6, 9, 11}:
        day = random.randint(1, 30)
    else:
        day = random.randint(1, 31)

    src = f"{year:04d}-{month:02d}-{day:02d}"
    tgt = f"{day:02d}/{month:02d}/{year:04d}"
    return src, tgt


def build_date_samples(n_samples=10000):
    samples = []
    for _ in range(n_samples):
        samples.append(random_date())
    return samples


# =========================
# 4. Dataset
# =========================
class DateFormatDataset(Dataset):
    def __init__(self, samples, src_vocab: Vocab, tgt_vocab: Vocab):
        self.samples = samples
        self.src_vocab = src_vocab
        self.tgt_vocab = tgt_vocab

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        src_text, tgt_text = self.samples[idx]

        # 字符级
        src_tokens = list(src_text)
        tgt_tokens = list(tgt_text)

        src_ids = [self.src_vocab.bos] + self.src_vocab.encode(src_tokens) + [self.src_vocab.eos]
        tgt_ids = [self.tgt_vocab.bos] + self.tgt_vocab.encode(tgt_tokens) + [self.tgt_vocab.eos]

        return {
            "src_text": src_text,
            "tgt_text": tgt_text,
            "src_ids": torch.tensor(src_ids, dtype=torch.long),
            "tgt_ids": torch.tensor(tgt_ids, dtype=torch.long),
        }


def collate_fn(batch, src_pad_idx, tgt_pad_idx):
    src_lens = [len(x["src_ids"]) for x in batch]
    tgt_lens = [len(x["tgt_ids"]) for x in batch]

    max_src = max(src_lens)
    max_tgt = max(tgt_lens)

    src_batch = []
    tgt_batch = []
    src_texts = []
    tgt_texts = []

    for item in batch:
        src_ids = item["src_ids"]
        tgt_ids = item["tgt_ids"]

        src_pad = torch.full((max_src,), src_pad_idx, dtype=torch.long)
        tgt_pad = torch.full((max_tgt,), tgt_pad_idx, dtype=torch.long)

        src_pad[: len(src_ids)] = src_ids
        tgt_pad[: len(tgt_ids)] = tgt_ids

        src_batch.append(src_pad)
        tgt_batch.append(tgt_pad)
        src_texts.append(item["src_text"])
        tgt_texts.append(item["tgt_text"])

    return {
        "src": torch.stack(src_batch, dim=0),   # (B, T_src)
        "tgt": torch.stack(tgt_batch, dim=0),   # (B, T_tgt)
        "src_texts": src_texts,
        "tgt_texts": tgt_texts,
    }


# =========================
# 5. Seq2Seq 模型
# =========================
class Seq2SeqEncoder(nn.Module):
    def __init__(self, vocab_size, emb_dim, hidden_size, num_layers=1, pad_idx=0, dropout=0.1):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, emb_dim, padding_idx=pad_idx)
        self.gru = nn.GRU(
            input_size=emb_dim,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )

    def forward(self, x):
        emb = self.embedding(x)         # (B, T, E)
        outputs, hT = self.gru(emb)     # outputs: (B, T, H), hT: (L, B, H)
        return outputs, hT


class Seq2SeqDecoder(nn.Module):
    def __init__(self, vocab_size, emb_dim, hidden_size, num_layers=1, pad_idx=0, dropout=0.1):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, emb_dim, padding_idx=pad_idx)
        self.gru = nn.GRU(
            input_size=emb_dim,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )
        self.fc = nn.Linear(hidden_size, vocab_size)

    def forward(self, y_t, h_prev):
        emb = self.embedding(y_t).unsqueeze(1)  # (B, 1, E)
        out, h_t = self.gru(emb, h_prev)        # out: (B, 1, H)
        logits = self.fc(out.squeeze(1))        # (B, V)
        return logits, h_t


class Seq2Seq(nn.Module):
    def __init__(
        self,
        src_vocab_size,
        tgt_vocab_size,
        emb_dim,
        hidden_size,
        num_layers=1,
        src_pad_idx=0,
        tgt_pad_idx=0,
        dropout=0.1,
        bos_idx=1,
        eos_idx=2,
    ):
        super().__init__()
        self.encoder = Seq2SeqEncoder(src_vocab_size, emb_dim, hidden_size, num_layers, src_pad_idx, dropout)
        self.decoder = Seq2SeqDecoder(tgt_vocab_size, emb_dim, hidden_size, num_layers, tgt_pad_idx, dropout)

        self.bos_idx = bos_idx
        self.eos_idx = eos_idx
        self.tgt_vocab_size = tgt_vocab_size

    def forward(self, src, tgt=None, teacher_forcing_ratio=0.5, max_len=32):
        B = src.size(0)
        device = src.device

        _, hT = self.encoder(src)
        dec_hidden = hT
        outputs = []

        # 训练
        if tgt is not None:
            T_tgt = tgt.size(1)
            dec_input = tgt[:, 0]  # <bos>

            for t in range(1, T_tgt):
                logits, dec_hidden = self.decoder(dec_input, dec_hidden)
                outputs.append(logits)

                teacher_force = random.random() < teacher_forcing_ratio
                top1 = logits.argmax(dim=-1)
                dec_input = tgt[:, t] if teacher_force else top1

            return torch.stack(outputs, dim=1)  # (B, T_tgt-1, V)

        # 推理
        dec_input = torch.full((B,), self.bos_idx, dtype=torch.long, device=device)

        for _ in range(max_len):
            logits, dec_hidden = self.decoder(dec_input, dec_hidden)
            outputs.append(logits)
            top1 = logits.argmax(dim=-1)
            dec_input = top1

        return torch.stack(outputs, dim=1)  # (B, max_len, V)

    @torch.no_grad()
    def greedy_decode(self, src, max_len=32):
        self.eval()
        logits = self.forward(src, tgt=None, max_len=max_len)      # (B, T, V)
        pred_ids = logits.argmax(dim=-1)                           # (B, T)
        return pred_ids


# =========================
# 6. 评估与训练
# =========================
@torch.no_grad()
def evaluate(model, loader, criterion, tgt_pad_idx, device):
    model.eval()
    total_loss = 0.0
    total_count = 0

    for batch in loader:
        src = batch["src"].to(device)
        tgt = batch["tgt"].to(device)

        logits = model(src, tgt=tgt, teacher_forcing_ratio=0.0)    # (B, T_tgt-1, V)
        target = tgt[:, 1:]                                         # (B, T_tgt-1)

        loss = criterion(logits.reshape(-1, logits.size(-1)), target.reshape(-1))

        n = src.size(0)
        total_loss += loss.item() * n
        total_count += n

    return total_loss / max(total_count, 1)


@torch.no_grad()
def show_examples(model, dataset, tgt_vocab, device, n=10):
    model.eval()
    idxs = random.sample(range(len(dataset)), k=n)

    print("\n===== Example Predictions =====")
    for idx in idxs:
        item = dataset[idx]
        src = item["src_ids"].unsqueeze(0).to(device)
        pred_ids = model.greedy_decode(src, max_len=16)[0].tolist()

        pred_tokens = []
        for tid in pred_ids:
            tok = tgt_vocab.id_to_token[int(tid)]
            if tok == "<eos>":
                break
            if tok not in {"<pad>", "<bos>"}:
                pred_tokens.append(tok)

        pred_text = "".join(pred_tokens)

        print(f"src : {item['src_text']}")
        print(f"tgt : {item['tgt_text']}")
        print(f"pred: {pred_text}")
        print("-" * 40)


# =========================
# 7. main
# =========================
@dataclass
class Config:
    seed: int = 2026
    train_size: int = 12000
    val_size: int = 2000
    batch_size: int = 128
    emb_dim: int = 32
    hidden_size: int = 64
    num_layers: int = 1
    dropout: float = 0.1
    lr: float = 1e-3
    epochs: int = 15
    teacher_forcing_ratio: float = 0.7
    device: str = "cuda" if torch.cuda.is_available() else "cpu"


def main():
    cfg = Config()
    set_seed(cfg.seed)

    # 字符级词表
    src_tokens = ["<pad>", "<bos>", "<eos>", "<unk>"] + list("0123456789-")
    tgt_tokens = ["<pad>", "<bos>", "<eos>", "<unk>"] + list("0123456789/")

    src_vocab = Vocab(src_tokens)
    tgt_vocab = Vocab(tgt_tokens)

    # 数据
    train_samples = build_date_samples(cfg.train_size)
    val_samples = build_date_samples(cfg.val_size)

    train_dataset = DateFormatDataset(train_samples, src_vocab, tgt_vocab)
    val_dataset = DateFormatDataset(val_samples, src_vocab, tgt_vocab)

    train_loader = DataLoader(
        train_dataset,
        batch_size=cfg.batch_size,
        shuffle=True,
        collate_fn=lambda b: collate_fn(b, src_vocab.pad, tgt_vocab.pad),
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=cfg.batch_size,
        shuffle=False,
        collate_fn=lambda b: collate_fn(b, src_vocab.pad, tgt_vocab.pad),
    )

    # 模型
    model = Seq2Seq(
        src_vocab_size=len(src_vocab),
        tgt_vocab_size=len(tgt_vocab),
        emb_dim=cfg.emb_dim,
        hidden_size=cfg.hidden_size,
        num_layers=cfg.num_layers,
        src_pad_idx=src_vocab.pad,
        tgt_pad_idx=tgt_vocab.pad,
        dropout=cfg.dropout,
        bos_idx=tgt_vocab.bos,
        eos_idx=tgt_vocab.eos,
    ).to(cfg.device)

    optimizer = torch.optim.Adam(model.parameters(), lr=cfg.lr)
    criterion = nn.CrossEntropyLoss(ignore_index=tgt_vocab.pad)

    print(f"device: {cfg.device}")
    print(f"params: {sum(p.numel() for p in model.parameters())}")

    for epoch in range(1, cfg.epochs + 1):
        model.train()
        total_loss = 0.0
        total_count = 0

        for batch in train_loader:
            src = batch["src"].to(cfg.device)
            tgt = batch["tgt"].to(cfg.device)

            optimizer.zero_grad()

            logits = model(
                src,
                tgt=tgt,
                teacher_forcing_ratio=cfg.teacher_forcing_ratio
            )  # (B, T_tgt-1, V)

            target = tgt[:, 1:]  # 预测目标是不包含 <bos> 的后续 token

            loss = criterion(
                logits.reshape(-1, logits.size(-1)),
                target.reshape(-1)
            )

            loss.backward()
            optimizer.step()

            n = src.size(0)
            total_loss += loss.item() * n
            total_count += n

        train_loss = total_loss / max(total_count, 1)
        val_loss = evaluate(model, val_loader, criterion, tgt_vocab.pad, cfg.device)

        print(f"epoch {epoch:02d} | train_loss={train_loss:.4f} | val_loss={val_loss:.4f}")

    show_examples(model, val_dataset, tgt_vocab, cfg.device, n=10)


if __name__ == "__main__":
    main()