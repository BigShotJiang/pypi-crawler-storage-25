"""
Databricks test runner for insurance-telematics.
Uploads the repo and runs pytest via the Jobs API.
"""
import os
import subprocess
import sys

# Load creds
env_path = os.path.expanduser("~/.config/burning-cost/databricks.env")
with open(env_path) as f:
    for line in f:
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ[k] = v

from databricks.sdk import WorkspaceClient
from databricks.sdk.service import jobs, compute

w = WorkspaceClient()

# Upload repo to workspace
print("Uploading insurance-telematics to Databricks workspace...")
result = subprocess.run(
    [
        "databricks", "workspace", "import-dir",
        "/home/ralph/repos/insurance-telematics",
        "/Workspace/insurance-telematics",
        "--overwrite",
    ],
    capture_output=True, text=True
)
print(result.stdout)
if result.returncode != 0:
    print(result.stderr)

# Create a one-time run
print("Submitting test job...")
run = w.jobs.submit(
    run_name="insurance-telematics-tests-20250403",
    tasks=[
        jobs.SubmitTask(
            task_key="run_pytest",
            new_cluster=compute.ClusterSpec(
                spark_version="15.4.x-scala2.12",
                node_type_id="m5d.large",
                num_workers=0,
                spark_conf={"spark.master": "local[*]"},
            ),
            notebook_task=jobs.NotebookTask(
                notebook_path="/Workspace/insurance-telematics/notebooks/run_tests",
            ),
        )
    ],
).result()
print(f"Run state: {run.state}")
