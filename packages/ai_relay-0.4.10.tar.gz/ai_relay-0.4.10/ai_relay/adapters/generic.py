"""Generic adapter — wraps any CLI tool by executable name."""

from __future__ import annotations
from typing import Optional
from .base import BaseAdapter


class GenericAdapter(BaseAdapter):
    tool_name = "generic"

    # Map tool name → executable
    _EXECUTABLES: dict[str, str] = {
        "codex": "codex",
        "gemini": "gemini",
        "cortex": "cortex",
    }

    @classmethod
    def build_command(cls, folder: str, model: Optional[str] = None,
                      extra_args: Optional[list[str]] = None) -> list[str]:
        executable = cls._EXECUTABLES.get(cls.tool_name, cls.tool_name)
        cmd = [executable]
        if model:
            cmd += ["--model", model]
        if extra_args:
            cmd += extra_args
        return cmd
