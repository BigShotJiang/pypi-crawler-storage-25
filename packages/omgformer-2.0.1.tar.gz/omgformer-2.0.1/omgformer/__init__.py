"""omgformer v2.0.1 — Paralel Diffusion Dil Modeli"""

from omgformer.configuration import OMGConfig, OMGCONFIG_REGISTRY
from omgformer.layers import (
    RMSNorm,
    RotaryEmbedding,
    GroupedQueryAttention,
    SwiGLUFFN,
    AdaLNModulation,
    SelfCondProjection,
    OMGBlock,
)
from omgformer.modeling import OMGModel, OMGModelOutput, TimestepEmbedding
from omgformer.diffusion import MaskScheduler, ParallelDecoder
from omgformer.tokenization import OMGTokenizer
from omgformer.auto import AutoConfig, AutoModel
from omgformer.pipeline import pipeline
from omgformer.utils import (
    set_seed,
    count_parameters,
    get_model_size_mb,
    get_device,
    tokens_per_second,
    format_number,
)

__version__ = "2.0.1"

__all__ = [
    # Config
    "OMGConfig", "OMGCONFIG_REGISTRY",
    # Layers
    "RMSNorm", "RotaryEmbedding", "GroupedQueryAttention",
    "SwiGLUFFN", "AdaLNModulation", "SelfCondProjection", "OMGBlock",
    # Modeling
    "OMGModel", "OMGModelOutput", "TimestepEmbedding",
    # Diffusion
    "MaskScheduler", "ParallelDecoder",
    # Tokenization
    "OMGTokenizer",
    # Auto
    "AutoConfig", "AutoModel",
    # Pipeline
    "pipeline",
    # Utils
    "set_seed", "count_parameters", "get_model_size_mb",
    "get_device", "tokens_per_second", "format_number",
    # Version
    "__version__",
]
