"""Local update-check helpers for the manual-friendly RAZE release flow."""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import httpx


def _version_parts(value: str) -> list[Any]:
    parts: list[Any] = []
    for part in re.split(r"[^0-9A-Za-z]+", value.strip()):
        if not part:
            continue
        parts.append(int(part) if part.isdigit() else part.lower())
    return parts or [0]


def compare_versions(left: str, right: str) -> int:
    left_parts = _version_parts(left)
    right_parts = _version_parts(right)
    length = max(len(left_parts), len(right_parts))

    for index in range(length):
        left_part = left_parts[index] if index < len(left_parts) else 0
        right_part = right_parts[index] if index < len(right_parts) else 0
        if left_part == right_part:
            continue
        if isinstance(left_part, int) and isinstance(right_part, int):
            return 1 if left_part > right_part else -1
        return 1 if str(left_part) > str(right_part) else -1
    return 0


def load_release_manifest(source: str) -> tuple[dict[str, Any], str]:
    if source.startswith(("http://", "https://")):
        response = httpx.get(source, timeout=10.0, follow_redirects=True)
        response.raise_for_status()
        return response.json(), source

    path = Path(source).expanduser().resolve()
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    return payload, str(path)


def _normalize_release_notes(value: object) -> list[str]:
    if isinstance(value, str):
        text = value.strip()
        return [text] if text else []
    if isinstance(value, list):
        notes: list[str] = []
        for entry in value:
            text = str(entry or "").strip()
            if text:
                notes.append(text)
        return notes
    return []


def build_update_status(
    *,
    current_version: str,
    source: Optional[str],
    default_instructions: Optional[str] = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "status": "not_configured",
        "configured": bool(source),
        "current_version": current_version,
        "checked_version": current_version,
        "latest_version": current_version,
        "update_available": False,
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "published_at": None,
        "source": source,
        "instructions": default_instructions,
        "download_page_url": None,
        "release_notes": [],
        "release_notes_url": None,
        "error": None,
    }

    if not source:
        return payload

    try:
        manifest, normalized_source = load_release_manifest(source)
    except Exception as exc:
        payload["status"] = "error"
        payload["error"] = str(exc)
        return payload

    latest_version = str(
        manifest.get("latest_version")
        or manifest.get("bundle_version")
        or manifest.get("version")
        or current_version
    )
    download_page_url = manifest.get("download_page_url")
    instructions = manifest.get("instructions") or default_instructions
    published_at = manifest.get("published_at")
    release_notes = _normalize_release_notes(manifest.get("release_notes"))
    release_notes_url = manifest.get("release_notes_url")

    payload.update(
        {
            "latest_version": latest_version,
            "source": normalized_source,
            "instructions": instructions,
            "download_page_url": download_page_url,
            "published_at": published_at,
            "release_notes": release_notes,
            "release_notes_url": release_notes_url,
        }
    )

    if compare_versions(latest_version, current_version) > 0:
        payload["status"] = "update_available"
        payload["update_available"] = True
    else:
        payload["status"] = "up_to_date"

    return payload
