from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path

from typer.testing import CliRunner


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "cli"))

from raze_cli import main  # noqa: E402
from raze_cli.runtime_bundle import DEFAULT_RELEASE_MANIFEST_URL, RELEASE_MANIFEST_ENV_VARS  # noqa: E402

runner = CliRunner()


def _empty_bundle_status() -> main.BundleStatus:
    return main.BundleStatus(
        root=None,
        manifest_path=None,
        manifest={},
        components=[],
        bundle_version=None,
        release_manifest_url=None,
        dashboard_mode="unavailable",
        dashboard_source_path=None,
        dashboard_dist_path=None,
        core_path=None,
        managed_runtime=False,
        runtime_env_dir=None,
        runtime_python=None,
        forbidden_entries=[],
    )


def _ready_bundle_status(
    tmp_path: Path,
    *,
    version: str,
    managed_runtime: bool = True,
    release_manifest_url: str | None = "https://example.com/release-manifest.json",
) -> main.BundleStatus:
    root = tmp_path / f"bundle-{version}"
    root.mkdir(parents=True, exist_ok=True)
    dashboard_dist = root / "apps" / "dashboard" / "dist"
    dashboard_dist.mkdir(parents=True, exist_ok=True)
    core_path = root / "services" / "core"
    core_path.mkdir(parents=True, exist_ok=True)
    env_dir = tmp_path / f"env-{version}"

    return main.BundleStatus(
        root=root,
        manifest_path=root / "distribution" / "raze-bundle.json",
        manifest={},
        components=[],
        bundle_version=version,
        release_manifest_url=release_manifest_url,
        dashboard_mode="bundled-static",
        dashboard_source_path=None,
        dashboard_dist_path=dashboard_dist,
        core_path=core_path,
        managed_runtime=managed_runtime,
        runtime_env_dir=env_dir,
        runtime_python=None,
        forbidden_entries=[],
    )


def test_get_source_tree_root_detects_expected_layout(monkeypatch, tmp_path: Path):
    workspace = tmp_path / "raze"
    (workspace / "services" / "core").mkdir(parents=True)
    (workspace / "apps" / "dashboard").mkdir(parents=True)

    monkeypatch.setattr(main, "get_workspace_root", lambda: workspace)

    assert main.get_source_tree_root() == workspace


def test_render_dashboard_command_returns_none_without_source_tree(monkeypatch):
    monkeypatch.setattr(main, "get_source_tree_root", lambda: None)

    assert main._render_dashboard_command(52000) is None


def test_render_dashboard_command_uses_dashboard_source_dir(monkeypatch, tmp_path: Path):
    workspace = tmp_path / "raze"
    dashboard_dir = workspace / "apps" / "dashboard"
    dashboard_dir.mkdir(parents=True)
    (workspace / "services" / "core").mkdir(parents=True)

    monkeypatch.setattr(main, "get_source_tree_root", lambda: workspace)

    command = main._render_dashboard_command(52000)
    assert command == f"cd {dashboard_dir} && npm run dev -- --port 52000"


def test_can_launch_installed_core_returns_false_when_package_is_missing(monkeypatch):
    def fake_find_spec(_name: str):
        raise ModuleNotFoundError("No module named 'raze_core'")

    monkeypatch.setattr(main.importlib.util, "find_spec", fake_find_spec)

    assert main._can_launch_installed_core() is False


def test_dashboard_handles_missing_runtime_without_traceback(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(main, "_bundle_status", lambda explicit_root=None, allow_dev_fallback=True: _empty_bundle_status())
    monkeypatch.setattr(
        main,
        "acquire_managed_bundle",
        lambda **_kwargs: (_ for _ in ()).throw(main.RuntimeAcquisitionError("manifest is unavailable")),
    )

    result = runner.invoke(main.app, ["dashboard"])

    assert result.exit_code == 1
    assert "could not prepare the local runtime automatically" in result.output.lower()
    assert "manifest is unavailable" in result.output.lower()
    assert "raze bootstrap --bundle-dir <bundle-root>" in result.output
    assert "Traceback" not in result.output


def test_setup_skips_dashboard_prompt_when_runtime_is_missing(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(main, "_bundle_status", lambda explicit_root=None, allow_dev_fallback=True: _empty_bundle_status())
    monkeypatch.setattr(main, "_dashboard_launch_ready", lambda status: False)
    monkeypatch.setattr(main, "_create_config", lambda config_path: config_path.write_text("providers: []\n", encoding="utf-8"))

    result = runner.invoke(main.app, ["setup"])

    assert result.exit_code == 0
    assert "Skipping dashboard launch until the managed local runtime is ready." in result.output
    assert "Open the local dashboard after setup?" not in result.output


def test_doctor_reports_missing_runtime_guidance(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(main, "_bundle_status", lambda explicit_root=None, allow_dev_fallback=True: _empty_bundle_status())
    monkeypatch.setattr(main, "_can_launch_installed_core", lambda: False)

    async def raise_missing_core():
        raise RuntimeError("Core unavailable")

    monkeypatch.setattr(main.client, "run_doctor", raise_missing_core)

    result = runner.invoke(main.app, ["doctor"])

    assert result.exit_code == 0
    assert "Bundle:" in result.output
    assert "run raze onboard" in result.output.lower()
    assert "raze bootstrap --bundle-dir <bundle-root>" in result.output


def test_doctor_reports_outdated_bundle_state(monkeypatch, tmp_path: Path):
    bundle_root = tmp_path / "bundle"
    bundle_root.mkdir()
    bundle_status = main.BundleStatus(
        root=bundle_root,
        manifest_path=bundle_root / "distribution" / "raze-bundle.json",
        manifest={},
        components=[],
        bundle_version="1.0.0",
        release_manifest_url=None,
        dashboard_mode="bundled-static",
        dashboard_source_path=None,
        dashboard_dist_path=bundle_root / "apps" / "dashboard" / "dist",
        core_path=bundle_root / "services" / "core",
        managed_runtime=True,
        runtime_env_dir=tmp_path / "env",
        runtime_python=None,
        forbidden_entries=[],
    )

    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(main, "_bundle_status", lambda explicit_root=None, allow_dev_fallback=True: bundle_status)
    monkeypatch.setattr(main, "_can_launch_installed_core", lambda: True)
    monkeypatch.setattr(
        main,
        "load_update_status",
        lambda _data_dir: {
            "status": "update_available",
            "checked_version": "1.0.0",
            "latest_version": "1.0.1",
        },
    )

    async def raise_missing_core():
        raise RuntimeError("Core unavailable")

    monkeypatch.setattr(main.client, "run_doctor", raise_missing_core)

    result = runner.invoke(main.app, ["doctor"])

    assert result.exit_code == 0
    assert "Update state:" in result.output
    assert "latest v1.0.1" in result.output


def test_onboard_prepares_runtime_and_launches_dashboard(monkeypatch, tmp_path: Path):
    bundle_root = tmp_path / "bundle"
    bundle_root.mkdir()
    bundle_status = main.BundleStatus(
        root=bundle_root,
        manifest_path=bundle_root / "distribution" / "raze-bundle.json",
        manifest={},
        components=[],
        bundle_version="1.0.0",
        release_manifest_url=None,
        dashboard_mode="bundled-static",
        dashboard_source_path=None,
        dashboard_dist_path=bundle_root / "apps" / "dashboard" / "dist",
        core_path=bundle_root / "services" / "core",
        managed_runtime=True,
        runtime_env_dir=tmp_path / "env",
        runtime_python=tmp_path / "env" / "Scripts" / "python.exe",
        forbidden_entries=[],
    )
    calls: list[str] = []

    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(main, "_ensure_runtime_bundle", lambda command_label: calls.append(f"bundle:{command_label}") or bundle_status)
    monkeypatch.setattr(main, "_launch_dashboard_flow", lambda status, command_label: calls.append(f"launch:{command_label}:{status.root}"))

    result = runner.invoke(main.app, ["onboard"])

    assert result.exit_code == 0
    assert calls == [f"bundle:onboard", f"launch:onboard:{bundle_root}"]


def test_dashboard_prepares_runtime_and_launches_dashboard(monkeypatch, tmp_path: Path):
    bundle_root = tmp_path / "bundle"
    bundle_root.mkdir()
    bundle_status = main.BundleStatus(
        root=bundle_root,
        manifest_path=bundle_root / "distribution" / "raze-bundle.json",
        manifest={},
        components=[],
        bundle_version="1.0.0",
        release_manifest_url=None,
        dashboard_mode="bundled-static",
        dashboard_source_path=None,
        dashboard_dist_path=bundle_root / "apps" / "dashboard" / "dist",
        core_path=bundle_root / "services" / "core",
        managed_runtime=True,
        runtime_env_dir=tmp_path / "env",
        runtime_python=tmp_path / "env" / "Scripts" / "python.exe",
        forbidden_entries=[],
    )
    calls: list[str] = []

    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(main, "_ensure_runtime_bundle", lambda command_label: calls.append(f"bundle:{command_label}") or bundle_status)
    monkeypatch.setattr(main, "_launch_dashboard_flow", lambda status, command_label: calls.append(f"launch:{command_label}:{status.root}"))

    result = runner.invoke(main.app, ["dashboard"])

    assert result.exit_code == 0
    assert calls == [f"bundle:dashboard", f"launch:dashboard:{bundle_root}"]


def test_release_manifest_source_prefers_environment_override(tmp_path: Path, monkeypatch):
    status = _ready_bundle_status(
        tmp_path,
        version="1.0.0",
        managed_runtime=True,
        release_manifest_url=str(tmp_path / "bundle-release-manifest.json"),
    )

    monkeypatch.setenv("RAZE_RELEASE_MANIFEST_URL", str(tmp_path / "env-release-manifest.json"))

    resolved = main._release_manifest_source(status)

    assert resolved == str((tmp_path / "env-release-manifest.json").resolve())


def test_release_manifest_source_uses_public_runtime_repo_for_fresh_machine(monkeypatch):
    for env_name in RELEASE_MANIFEST_ENV_VARS:
        monkeypatch.delenv(env_name, raising=False)

    resolved = main._release_manifest_source(_empty_bundle_status())

    assert resolved == DEFAULT_RELEASE_MANIFEST_URL
    assert resolved == "https://github.com/mtma1/RazeReleases/releases/latest/download/release-manifest.json"


def test_update_applies_newer_managed_runtime(monkeypatch, tmp_path: Path):
    old_status = _ready_bundle_status(tmp_path, version="1.0.0", managed_runtime=True)
    new_status = _ready_bundle_status(tmp_path, version="1.0.1", managed_runtime=True)
    calls: list[dict] = []

    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setattr(main, "_bundle_status", lambda explicit_root=None, allow_dev_fallback=True: old_status)

    def fake_refresh(status, *, manifest_source=None, quiet=False):
        if status.bundle_version == "1.0.0":
            return {
                "status": "update_available",
                "current_version": "1.0.0",
                "checked_version": "1.0.0",
                "latest_version": "1.0.1",
                "source": "https://example.com/release-manifest.json",
                "instructions": "Run raze update to apply.",
                "release_notes": ["Bug fixes"],
                "release_notes_url": None,
                "download_page_url": None,
            }
        return {
            "status": "up_to_date",
            "current_version": "1.0.1",
            "checked_version": "1.0.1",
            "latest_version": "1.0.1",
            "source": "https://example.com/release-manifest.json",
            "instructions": "Already applied.",
            "release_notes": [],
            "release_notes_url": None,
            "download_page_url": None,
        }

    monkeypatch.setattr(main, "_refresh_update_status", fake_refresh)
    monkeypatch.setattr(
        main,
        "acquire_managed_bundle",
        lambda **kwargs: calls.append(kwargs) or new_status,
    )

    result = runner.invoke(main.app, ["update"])

    assert result.exit_code == 0
    assert "Applied runtime update" in result.output
    assert "v1.0.0" in result.output
    assert "v1.0.1" in result.output
    assert calls == [
        {
            "source": "https://example.com/release-manifest.json",
            "data_dir": tmp_path / "data",
            "workspace_root": main.get_workspace_root(),
        }
    ]


def test_onboard_applies_newer_managed_runtime_before_launch(monkeypatch, tmp_path: Path):
    old_status = _ready_bundle_status(tmp_path, version="1.0.0", managed_runtime=True)
    new_status = _ready_bundle_status(tmp_path, version="1.0.1", managed_runtime=True)
    launched: list[tuple[str | None, str]] = []

    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setattr(main, "_bundle_status", lambda explicit_root=None, allow_dev_fallback=True: old_status)
    monkeypatch.setattr(
        main,
        "_refresh_update_status",
        lambda status, *, manifest_source=None, quiet=False: {
            "status": "update_available" if status.bundle_version == "1.0.0" else "up_to_date",
            "current_version": status.bundle_version,
            "checked_version": status.bundle_version,
            "latest_version": "1.0.1",
            "source": "https://example.com/release-manifest.json",
            "instructions": "Run raze update to apply.",
            "release_notes": [],
            "release_notes_url": None,
            "download_page_url": None,
        },
    )
    monkeypatch.setattr(main, "acquire_managed_bundle", lambda **_kwargs: new_status)
    monkeypatch.setattr(
        main,
        "_launch_dashboard_flow",
        lambda status, command_label: launched.append((status.bundle_version, command_label)),
    )

    result = runner.invoke(main.app, ["onboard"])

    assert result.exit_code == 0
    assert launched == [("1.0.1", "onboard")]
    assert "Applying the managed runtime update for onboard" in result.output


def test_dashboard_keeps_explicit_bundle_when_managed_update_is_available(monkeypatch, tmp_path: Path):
    explicit_status = _ready_bundle_status(tmp_path, version="1.0.0", managed_runtime=False)
    launched: list[tuple[str | None, str]] = []

    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setattr(main, "_bundle_status", lambda explicit_root=None, allow_dev_fallback=True: explicit_status)
    monkeypatch.setattr(
        main,
        "_refresh_update_status",
        lambda status, *, manifest_source=None, quiet=False: {
            "status": "update_available",
            "current_version": status.bundle_version,
            "checked_version": status.bundle_version,
            "latest_version": "1.0.1",
            "source": "https://example.com/release-manifest.json",
            "instructions": "Run raze update to apply.",
            "release_notes": [],
            "release_notes_url": None,
            "download_page_url": None,
        },
    )
    monkeypatch.setattr(
        main,
        "acquire_managed_bundle",
        lambda **_kwargs: (_ for _ in ()).throw(AssertionError("dashboard should not auto-replace an explicit bundle")),
    )
    monkeypatch.setattr(
        main,
        "_launch_dashboard_flow",
        lambda status, command_label: launched.append((status.bundle_version, command_label)),
    )

    result = runner.invoke(main.app, ["dashboard"])

    assert result.exit_code == 0
    assert launched == [("1.0.0", "dashboard")]
    assert "explicit or developer bundle" in result.output


def test_dashboard_continues_with_current_runtime_when_auto_update_fails(monkeypatch, tmp_path: Path):
    old_status = _ready_bundle_status(tmp_path, version="1.0.0", managed_runtime=True)
    launched: list[tuple[str | None, str]] = []

    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setattr(main, "_bundle_status", lambda explicit_root=None, allow_dev_fallback=True: old_status)
    monkeypatch.setattr(
        main,
        "_refresh_update_status",
        lambda status, *, manifest_source=None, quiet=False: {
            "status": "update_available",
            "current_version": status.bundle_version,
            "checked_version": status.bundle_version,
            "latest_version": "1.0.1",
            "source": "https://example.com/release-manifest.json",
            "instructions": "Run raze update to apply.",
            "release_notes": [],
            "release_notes_url": None,
            "download_page_url": None,
        },
    )
    monkeypatch.setattr(
        main,
        "acquire_managed_bundle",
        lambda **_kwargs: (_ for _ in ()).throw(main.RuntimeAcquisitionError("download failed")),
    )
    monkeypatch.setattr(
        main,
        "_launch_dashboard_flow",
        lambda status, command_label: launched.append((status.bundle_version, command_label)),
    )

    result = runner.invoke(main.app, ["dashboard"])

    assert result.exit_code == 0
    assert launched == [("1.0.0", "dashboard")]
    assert "could not apply the runtime update automatically" in result.output.lower()
    assert "continuing with the installed runtime v1.0.0" in result.output.lower()


def test_process_exists_tracks_live_process_lifecycle():
    creation_flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
    process = subprocess.Popen(
        [sys.executable, "-c", "import time; time.sleep(30)"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=creation_flags,
    )

    try:
        time.sleep(0.5)
        assert main._process_exists(process.pid) is True

        process.terminate()
        process.wait(timeout=5)
        time.sleep(0.2)

        assert main._process_exists(process.pid) is False
    finally:
        if process.poll() is None:
            process.kill()
            process.wait(timeout=5)


def test_stop_without_employee_reports_when_runtime_is_not_running(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))

    async def fake_discover_core(*_args, **_kwargs):
        return None

    monkeypatch.setattr(main.client, "discover_core", fake_discover_core)

    result = runner.invoke(main.app, ["stop"])

    assert result.exit_code == 0
    assert "No local RAZE runtime is currently running." in result.output


def test_stop_with_employee_preserves_employee_control(monkeypatch):
    calls: list[str] = []

    async def fake_stop_employee(employee_id: str):
        calls.append(employee_id)
        return {"name": employee_id}

    monkeypatch.setattr(main.client, "stop_employee", fake_stop_employee)

    result = runner.invoke(main.app, ["stop", "research-employee"])

    assert result.exit_code == 0
    assert "Stopped research-employee" in result.output
    assert calls == ["research-employee"]


def test_stop_without_employee_stops_recorded_runtime(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))
    runtime_path = tmp_path / "runtime.json"

    creation_flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
    process = subprocess.Popen(
        [sys.executable, "-c", "import time; time.sleep(60)"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=creation_flags,
    )

    runtime_path.write_text(json.dumps({
        "service": "core",
        "status": "running",
        "core_host": "127.0.0.1",
        "core_port": 52100,
        "dashboard_port": 52000,
        "pid": process.pid,
    }), encoding="utf-8")

    responses = [52100, None]

    async def fake_discover_core(*_args, **_kwargs):
        if responses:
            return responses.pop(0)
        return None

    monkeypatch.setattr(main.client, "discover_core", fake_discover_core)

    try:
        result = runner.invoke(main.app, ["stop"])
        assert result.exit_code == 0
        assert "Local RAZE runtime stopped." in result.output

        for _ in range(40):
            if process.poll() is not None:
                break
            time.sleep(0.1)

        assert process.poll() is not None
        assert not runtime_path.exists()
    finally:
        if process.poll() is None:
            process.kill()
