from __future__ import annotations

import http.server
import json
import shutil
import threading
from pathlib import Path

from raze_cli.runtime_bundle import (
    DEFAULT_RELEASE_MANIFEST_URL,
    RELEASE_MANIFEST_ENV_VARS,
    RuntimeAcquisitionError,
    acquire_managed_bundle,
    find_forbidden_runtime_entries,
    inspect_bundle,
    load_bundle_installation,
    resolve_release_manifest_source,
    resolve_bundle_root,
    save_bundle_installation,
)
from raze_cli.updates import build_update_status, compare_versions, load_release_manifest

ROOT = Path(__file__).resolve().parents[2]
EXPECTED_RUNTIME_RELEASE_MANIFEST_URL = "https://github.com/mtma1/RazeReleases/releases/latest/download/release-manifest.json"


def _write_runtime_bundle(root: Path, version: str) -> Path:
    (root / "distribution").mkdir(parents=True, exist_ok=True)
    (root / "services" / "core").mkdir(parents=True, exist_ok=True)
    (root / "apps" / "dashboard" / "dist").mkdir(parents=True, exist_ok=True)
    (root / "apps" / "dashboard" / "dist" / "index.html").write_text("<html></html>", encoding="utf-8")
    (root / "distribution" / "raze-bundle.json").write_text(
        json.dumps(
            {
                "bundle_version": version,
                "components": {
                    "core": {"label": "Core", "kind": "python-runtime", "path": "services/core", "required": True},
                    "dashboard": {
                        "label": "Dashboard",
                        "kind": "web-runtime",
                        "dist_path": "apps/dashboard/dist",
                        "required": True,
                    },
                },
            }
        ),
        encoding="utf-8",
    )
    return root


def _make_runtime_archive(tmp_path: Path, *, manifest_version: str, internal_version: str | None = None, name: str | None = None) -> Path:
    archive_stem = name or f"raze-runtime-bundle-{manifest_version}"
    source_root = tmp_path / f"{archive_stem}-source"
    _write_runtime_bundle(source_root / "runtime", internal_version or manifest_version)
    return Path(shutil.make_archive(str(tmp_path / archive_stem), "zip", root_dir=source_root))


def _write_release_manifest(tmp_path: Path, *, version: str, field_name: str | None, archive_path: Path | None) -> Path:
    payload = {
        "latest_version": version,
        "bundle_version": version,
    }
    if field_name and archive_path:
        payload[field_name] = archive_path.name
    manifest_path = tmp_path / f"release-manifest-{field_name or 'missing-url'}-{version}.json"
    manifest_path.write_text(json.dumps(payload), encoding="utf-8")
    return manifest_path


def _install_existing_runtime(data_dir: Path, version: str) -> Path:
    root = data_dir / "runtime" / "bundles" / version
    _write_runtime_bundle(root, version)
    save_bundle_installation(root, data_dir=data_dir, source="managed-install")
    return root.resolve()


def _start_redirect_server(
    *,
    manifest_payload: dict,
    bundle_archive_path: Path,
):
    archive_bytes = bundle_archive_path.read_bytes()
    manifest_bytes = json.dumps(manifest_payload).encode("utf-8")

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path == "/releases/download/v1.0.0/release-manifest.json":
                self.send_response(302)
                self.send_header("Location", "/assets/release-manifest.json")
                self.end_headers()
                return

            if self.path == "/assets/release-manifest.json":
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(manifest_bytes)))
                self.end_headers()
                self.wfile.write(manifest_bytes)
                return

            if self.path == "/releases/download/v1.0.0/raze-runtime-bundle-1.0.0.zip":
                self.send_response(302)
                self.send_header("Location", "/assets/raze-runtime-bundle-1.0.0.zip")
                self.end_headers()
                return

            if self.path == "/assets/raze-runtime-bundle-1.0.0.zip":
                self.send_response(200)
                self.send_header("Content-Type", "application/zip")
                self.send_header("Content-Length", str(len(archive_bytes)))
                self.end_headers()
                self.wfile.write(archive_bytes)
                return

            self.send_response(404)
            self.end_headers()

        def log_message(self, format, *args):
            return

    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, thread


def test_resolve_bundle_root_prefers_registered_bundle(monkeypatch, tmp_path: Path):
    data_dir = tmp_path / "data"
    bundle_root = tmp_path / "bundle"
    bundle_root.mkdir()
    save_bundle_installation(bundle_root, data_dir=data_dir, source="test")

    resolved = resolve_bundle_root(data_dir=data_dir, workspace_root=tmp_path / "missing")

    assert resolved == bundle_root.resolve()


def test_default_release_manifest_source_uses_public_runtime_repo(monkeypatch):
    for env_name in RELEASE_MANIFEST_ENV_VARS:
        monkeypatch.delenv(env_name, raising=False)

    assert DEFAULT_RELEASE_MANIFEST_URL == EXPECTED_RUNTIME_RELEASE_MANIFEST_URL
    assert resolve_release_manifest_source(None) == EXPECTED_RUNTIME_RELEASE_MANIFEST_URL


def test_default_release_manifest_source_preserves_environment_override(monkeypatch):
    for env_name in RELEASE_MANIFEST_ENV_VARS:
        monkeypatch.delenv(env_name, raising=False)

    monkeypatch.setenv("RAZE_RELEASE_MANIFEST_URL", "https://example.com/custom-release-manifest.json")

    assert resolve_release_manifest_source(None) == "https://example.com/custom-release-manifest.json"


def test_acquire_managed_bundle_manifest_error_names_source(monkeypatch, tmp_path: Path):
    manifest_url = "https://example.com/missing-release-manifest.json"

    def raise_manifest_error(_source: str):
        raise RuntimeError("404 Not Found")

    monkeypatch.setattr("raze_cli.runtime_bundle.load_release_manifest", raise_manifest_error)

    try:
        acquire_managed_bundle(
            source=manifest_url,
            data_dir=tmp_path / "data",
            workspace_root=tmp_path / "missing",
        )
    except RuntimeAcquisitionError as exc:
        message = str(exc)
        assert manifest_url in message
        assert "RAZE_RELEASE_MANIFEST_URL" in message
        assert "raze bootstrap --bundle-dir <bundle-root>" in message
    else:
        raise AssertionError("Expected RuntimeAcquisitionError for missing release manifest")


def test_resolve_bundle_root_does_not_fallback_when_explicit_path_is_missing(tmp_path: Path):
    resolved = resolve_bundle_root(explicit_root=str(tmp_path / "missing"))

    assert resolved is None


def test_inspect_bundle_reads_manifest_and_detects_bundled_dashboard(tmp_path: Path):
    root = tmp_path / "bundle"
    (root / "distribution").mkdir(parents=True)
    (root / "services" / "core").mkdir(parents=True)
    (root / "apps" / "dashboard" / "dist").mkdir(parents=True)
    (root / "apps" / "dashboard" / "dist" / "index.html").write_text("<html></html>", encoding="utf-8")
    (root / "employees").mkdir()
    (root / "packages" / "shared-specs").mkdir(parents=True)

    manifest = {
        "bundle_version": "1.0.0",
        "components": {
            "core": {"label": "Core", "kind": "python-runtime", "path": "services/core", "required": True},
            "dashboard": {
                "label": "Dashboard",
                "kind": "web-runtime",
                "source_path": "apps/dashboard",
                "dist_path": "apps/dashboard/dist",
                "required": True,
            },
            "employees": {"label": "Employees", "kind": "definitions", "path": "employees", "required": True},
            "shared_specs": {"label": "Shared Specs", "kind": "shared-assets", "path": "packages/shared-specs", "required": True},
        },
    }
    (root / "distribution" / "raze-bundle.json").write_text(json.dumps(manifest), encoding="utf-8")

    status = inspect_bundle(explicit_root=str(root))

    assert status.bundle_version == "1.0.0"
    assert status.dashboard_mode == "bundled-static"
    assert status.dashboard_dist_path == (root / "apps" / "dashboard" / "dist").resolve()
    assert any(component.key == "core" and component.present for component in status.components)


def test_inspect_bundle_resolves_relative_release_manifest_source(tmp_path: Path):
    root = tmp_path / "bundle"
    (root / "distribution").mkdir(parents=True)
    (root / "distribution" / "release-manifest.json").write_text("{}", encoding="utf-8")
    (root / "distribution" / "raze-bundle.json").write_text(
        json.dumps(
            {
                "bundle_version": "1.0.0",
                "release_manifest_url": "distribution/release-manifest.json",
                "components": {},
            }
        ),
        encoding="utf-8",
    )

    status = inspect_bundle(explicit_root=str(root))

    assert status.release_manifest_url == str((root / "distribution" / "release-manifest.json").resolve())


def test_compare_versions_handles_patch_updates():
    assert compare_versions("1.0.1", "1.0.0") > 0
    assert compare_versions("1.0.0", "1.0.0") == 0
    assert compare_versions("0.9.9", "1.0.0") < 0


def test_build_update_status_supports_local_manifest_file(tmp_path: Path):
    manifest_path = tmp_path / "release-manifest.json"
    manifest_path.write_text(
        json.dumps(
            {
                "latest_version": "1.2.0",
                "instructions": "Replace the local bundle manually.",
                "download_page_url": "https://example.com/raze/releases",
            }
        ),
        encoding="utf-8",
    )

    status = build_update_status(current_version="1.0.0", source=str(manifest_path))

    assert status["status"] == "update_available"
    assert status["update_available"] is True
    assert status["latest_version"] == "1.2.0"
    assert status["checked_version"] == "1.0.0"


def test_build_update_status_carries_release_notes(tmp_path: Path):
    manifest_path = tmp_path / "release-manifest.json"
    manifest_path.write_text(
        json.dumps(
            {
                "latest_version": "1.0.1",
                "release_notes": ["First note", "Second note"],
                "release_notes_url": "https://example.com/raze/releases/1.0.1",
            }
        ),
        encoding="utf-8",
    )

    status = build_update_status(current_version="1.0.0", source=str(manifest_path))

    assert status["release_notes"] == ["First note", "Second note"]
    assert status["release_notes_url"] == "https://example.com/raze/releases/1.0.1"


def test_load_release_manifest_follows_redirects(monkeypatch):
    calls: list[dict] = []

    class DummyResponse:
        def raise_for_status(self):
            return None

        def json(self):
            return {"latest_version": "1.0.1"}

    def fake_get(url: str, *, timeout: float, follow_redirects: bool):
        calls.append(
            {
                "url": url,
                "timeout": timeout,
                "follow_redirects": follow_redirects,
            }
        )
        return DummyResponse()

    monkeypatch.setattr("raze_cli.updates.httpx.get", fake_get)

    manifest, normalized_source = load_release_manifest("https://github.com/example/release-manifest.json")

    assert manifest["latest_version"] == "1.0.1"
    assert normalized_source == "https://github.com/example/release-manifest.json"
    assert calls == [
        {
            "url": "https://github.com/example/release-manifest.json",
            "timeout": 10.0,
            "follow_redirects": True,
        }
    ]


def test_distribution_manifest_matches_cli_first_bundle_boundary():
    manifest = json.loads((ROOT / "distribution" / "raze-bundle.json").read_text(encoding="utf-8-sig"))
    include = manifest["distribution"]["include"]
    exclude = manifest["distribution"]["exclude"]

    assert "cli/" not in include
    assert "services/core/" in include
    assert "apps/dashboard/dist/" in include
    assert "employees/" in include
    assert "packages/shared-specs/" in include
    assert "distribution/raze-bundle.json" in include
    assert "docs/" in include
    assert ".raze/" in exclude
    assert ".raze-dev/" in exclude
    assert "tmp/" in exclude
    assert "**/runtime.json" in exclude
    assert "**/config.yaml" in exclude
    assert "**/*.db" in exclude
    assert "**/node_modules/" in exclude
    assert "apps/website/" in exclude


def test_find_forbidden_runtime_entries_detects_local_only_state(tmp_path: Path):
    root = tmp_path / "bundle"
    (root / "distribution").mkdir(parents=True)
    (root / ".env").write_text("secret=value\n", encoding="utf-8")
    (root / "runtime.json").write_text("{}", encoding="utf-8")
    (root / "apps" / "website").mkdir(parents=True)
    (root / "logs").mkdir()
    (root / "data.sqlite3").write_text("", encoding="utf-8")

    forbidden = find_forbidden_runtime_entries(root)

    names = {path.name for path in forbidden}
    assert ".env" in names
    assert "runtime.json" in names
    assert "website" in names
    assert "logs" in names
    assert "data.sqlite3" in names


def test_acquire_managed_bundle_installs_from_local_manifest(tmp_path: Path):
    source_root = tmp_path / "bundle-source"
    bundle_root = source_root / "runtime"
    (bundle_root / "distribution").mkdir(parents=True)
    (bundle_root / "services" / "core").mkdir(parents=True)
    (bundle_root / "apps" / "dashboard" / "dist").mkdir(parents=True)
    (bundle_root / "apps" / "dashboard" / "dist" / "index.html").write_text("<html></html>", encoding="utf-8")
    (bundle_root / "employees").mkdir()
    (bundle_root / "packages" / "shared-specs").mkdir(parents=True)
    (bundle_root / "distribution" / "raze-bundle.json").write_text(
        json.dumps(
            {
                "bundle_version": "1.0.0",
                "components": {
                    "core": {"label": "Core", "kind": "python-runtime", "path": "services/core", "required": True},
                    "dashboard": {
                        "label": "Dashboard",
                        "kind": "web-runtime",
                        "source_path": "apps/dashboard",
                        "dist_path": "apps/dashboard/dist",
                        "required": True,
                    },
                    "employees": {"label": "Employees", "kind": "definitions", "path": "employees", "required": True},
                    "shared_specs": {"label": "Shared Specs", "kind": "shared-assets", "path": "packages/shared-specs", "required": True},
                },
            }
        ),
        encoding="utf-8",
    )

    archive_path = shutil.make_archive(str(tmp_path / "raze-runtime-bundle-1.0.0"), "zip", root_dir=source_root)
    manifest_path = tmp_path / "release-manifest.json"
    manifest_path.write_text(
        json.dumps(
            {
                "latest_version": "1.0.0",
                "bundle_version": "1.0.0",
                "bundle_archive_path": Path(archive_path).name,
                "instructions": "Replace the local runtime bundle manually.",
            }
        ),
        encoding="utf-8",
    )

    status = acquire_managed_bundle(
        source=str(manifest_path),
        data_dir=tmp_path / "data",
        workspace_root=tmp_path / "missing",
    )

    assert status.root == (tmp_path / "data" / "runtime" / "bundles" / "1.0.0").resolve()
    assert status.managed_runtime is True
    assert status.dashboard_mode == "bundled-static"
    installation = load_bundle_installation(tmp_path / "data")
    assert installation["bundle_root"] == str(status.root)


def test_acquire_managed_bundle_accepts_bundle_url_alias(tmp_path: Path):
    archive_path = _make_runtime_archive(tmp_path, manifest_version="1.0.4", name="bundle-url-runtime")
    manifest_path = _write_release_manifest(tmp_path, version="1.0.4", field_name="bundle_url", archive_path=archive_path)

    status = acquire_managed_bundle(
        source=str(manifest_path),
        data_dir=tmp_path / "data",
        workspace_root=tmp_path / "missing",
    )

    assert status.bundle_version == "1.0.4"
    assert status.root == (tmp_path / "data" / "runtime" / "bundles" / "1.0.4").resolve()
    assert load_bundle_installation(tmp_path / "data")["bundle_root"] == str(status.root)


def test_acquire_managed_bundle_accepts_asset_url_alias(tmp_path: Path):
    archive_path = _make_runtime_archive(tmp_path, manifest_version="1.0.4", name="asset-url-runtime")
    manifest_path = _write_release_manifest(tmp_path, version="1.0.4", field_name="asset_url", archive_path=archive_path)

    status = acquire_managed_bundle(
        source=str(manifest_path),
        data_dir=tmp_path / "data",
        workspace_root=tmp_path / "missing",
    )

    assert status.bundle_version == "1.0.4"
    assert status.root == (tmp_path / "data" / "runtime" / "bundles" / "1.0.4").resolve()


def test_acquire_managed_bundle_accepts_other_runtime_url_aliases(tmp_path: Path):
    for field_name in ("url", "download_url", "bundle_archive_url"):
        case_root = tmp_path / field_name
        case_root.mkdir()
        archive_path = _make_runtime_archive(case_root, manifest_version="1.0.4", name=f"{field_name}-runtime")
        manifest_path = _write_release_manifest(case_root, version="1.0.4", field_name=field_name, archive_path=archive_path)

        status = acquire_managed_bundle(
            source=str(manifest_path),
            data_dir=case_root / "data",
            workspace_root=case_root / "missing",
        )

        assert status.bundle_version == "1.0.4"
        assert status.root == (case_root / "data" / "runtime" / "bundles" / "1.0.4").resolve()


def test_acquire_managed_bundle_missing_url_gives_schema_error(tmp_path: Path):
    manifest_path = _write_release_manifest(tmp_path, version="1.0.4", field_name=None, archive_path=None)

    try:
        acquire_managed_bundle(
            source=str(manifest_path),
            data_dir=tmp_path / "data",
            workspace_root=tmp_path / "missing",
        )
    except RuntimeAcquisitionError as exc:
        message = str(exc)
        assert "Manifest schema error" in message
        for field_name in ("bundle_url", "bundle_archive_url", "asset_url", "url", "download_url"):
            assert field_name in message
    else:
        raise AssertionError("Expected RuntimeAcquisitionError for manifest without bundle URL")


def test_acquire_managed_bundle_rejects_internal_version_mismatch_and_removes_bad_bundle(tmp_path: Path):
    archive_path = _make_runtime_archive(
        tmp_path,
        manifest_version="1.0.4",
        internal_version="1.0.3",
        name="mismatched-runtime",
    )
    manifest_path = _write_release_manifest(tmp_path, version="1.0.4", field_name="bundle_url", archive_path=archive_path)
    data_dir = tmp_path / "data"

    try:
        acquire_managed_bundle(
            source=str(manifest_path),
            data_dir=data_dir,
            workspace_root=tmp_path / "missing",
        )
    except RuntimeAcquisitionError as exc:
        message = str(exc)
        assert "version does not match" in message
        assert "v1.0.4" in message
        assert "v1.0.3" in message
    else:
        raise AssertionError("Expected RuntimeAcquisitionError for mismatched internal bundle version")

    assert not (data_dir / "runtime" / "bundles" / "1.0.4").exists()


def test_acquire_managed_bundle_failed_update_rolls_back_to_installed_runtime(tmp_path: Path):
    data_dir = tmp_path / "data"
    old_root = _install_existing_runtime(data_dir, "1.0.3")
    archive_path = _make_runtime_archive(
        tmp_path,
        manifest_version="1.0.4",
        internal_version="1.0.3",
        name="bad-update-runtime",
    )
    manifest_path = _write_release_manifest(tmp_path, version="1.0.4", field_name="asset_url", archive_path=archive_path)

    try:
        acquire_managed_bundle(
            source=str(manifest_path),
            data_dir=data_dir,
            workspace_root=tmp_path / "missing",
        )
    except RuntimeAcquisitionError:
        pass
    else:
        raise AssertionError("Expected RuntimeAcquisitionError for failed update")

    installation = load_bundle_installation(data_dir)
    assert installation["bundle_root"] == str(old_root)
    assert old_root.exists()
    assert not (data_dir / "runtime" / "bundles" / "1.0.4").exists()


def test_acquire_managed_bundle_successful_update_switches_selected_runtime(tmp_path: Path):
    data_dir = tmp_path / "data"
    old_root = _install_existing_runtime(data_dir, "1.0.3")
    archive_path = _make_runtime_archive(tmp_path, manifest_version="1.0.4", name="good-update-runtime")
    manifest_path = _write_release_manifest(tmp_path, version="1.0.4", field_name="download_url", archive_path=archive_path)

    status = acquire_managed_bundle(
        source=str(manifest_path),
        data_dir=data_dir,
        workspace_root=tmp_path / "missing",
    )

    assert old_root.exists()
    assert status.bundle_version == "1.0.4"
    assert status.root == (data_dir / "runtime" / "bundles" / "1.0.4").resolve()
    assert load_bundle_installation(data_dir)["bundle_root"] == str(status.root)


def test_acquire_managed_bundle_rejects_forbidden_files(tmp_path: Path):
    source_root = tmp_path / "bundle-source"
    bundle_root = source_root / "runtime"
    (bundle_root / "distribution").mkdir(parents=True)
    (bundle_root / "services" / "core").mkdir(parents=True)
    (bundle_root / "apps" / "dashboard" / "dist").mkdir(parents=True)
    (bundle_root / "apps" / "dashboard" / "dist" / "index.html").write_text("<html></html>", encoding="utf-8")
    (bundle_root / "employees").mkdir()
    (bundle_root / "packages" / "shared-specs").mkdir(parents=True)
    (bundle_root / "config.yaml").write_text("providers: []\n", encoding="utf-8")
    (bundle_root / "distribution" / "raze-bundle.json").write_text(
        json.dumps(
            {
                "bundle_version": "1.0.0",
                "components": {
                    "core": {"label": "Core", "kind": "python-runtime", "path": "services/core", "required": True},
                    "dashboard": {
                        "label": "Dashboard",
                        "kind": "web-runtime",
                        "source_path": "apps/dashboard",
                        "dist_path": "apps/dashboard/dist",
                        "required": True,
                    },
                    "employees": {"label": "Employees", "kind": "definitions", "path": "employees", "required": True},
                    "shared_specs": {"label": "Shared Specs", "kind": "shared-assets", "path": "packages/shared-specs", "required": True},
                },
            }
        ),
        encoding="utf-8",
    )

    archive_path = shutil.make_archive(str(tmp_path / "raze-runtime-bundle-1.0.0-bad"), "zip", root_dir=source_root)
    manifest_path = tmp_path / "release-manifest-bad.json"
    manifest_path.write_text(
        json.dumps(
            {
                "latest_version": "1.0.0",
                "bundle_version": "1.0.0",
                "bundle_archive_path": Path(archive_path).name,
            }
        ),
        encoding="utf-8",
    )

    try:
        acquire_managed_bundle(
            source=str(manifest_path),
            data_dir=tmp_path / "data",
            workspace_root=tmp_path / "missing",
        )
    except RuntimeAcquisitionError as exc:
        assert "forbidden local files" in str(exc).lower()
    else:
        raise AssertionError("Expected RuntimeAcquisitionError for forbidden bundle content")


def test_acquire_managed_bundle_supports_redirecting_release_urls(tmp_path: Path):
    source_root = tmp_path / "bundle-source"
    bundle_root = source_root / "runtime"
    (bundle_root / "distribution").mkdir(parents=True)
    (bundle_root / "services" / "core").mkdir(parents=True)
    (bundle_root / "apps" / "dashboard" / "dist").mkdir(parents=True)
    (bundle_root / "apps" / "dashboard" / "dist" / "index.html").write_text("<html></html>", encoding="utf-8")
    (bundle_root / "employees").mkdir()
    (bundle_root / "packages" / "shared-specs").mkdir(parents=True)
    (bundle_root / "distribution" / "raze-bundle.json").write_text(
        json.dumps(
            {
                "bundle_version": "1.0.0",
                "components": {
                    "core": {"label": "Core", "kind": "python-runtime", "path": "services/core", "required": True},
                    "dashboard": {
                        "label": "Dashboard",
                        "kind": "web-runtime",
                        "source_path": "apps/dashboard",
                        "dist_path": "apps/dashboard/dist",
                        "required": True,
                    },
                    "employees": {"label": "Employees", "kind": "definitions", "path": "employees", "required": True},
                    "shared_specs": {"label": "Shared Specs", "kind": "shared-assets", "path": "packages/shared-specs", "required": True},
                },
            }
        ),
        encoding="utf-8",
    )

    archive_path = shutil.make_archive(str(tmp_path / "raze-runtime-bundle-1.0.0"), "zip", root_dir=source_root)
    manifest_payload = {
        "latest_version": "1.0.0",
        "bundle_version": "1.0.0",
        "bundle_archive_url": "raze-runtime-bundle-1.0.0.zip",
    }
    server, thread = _start_redirect_server(
        manifest_payload=manifest_payload,
        bundle_archive_path=Path(archive_path),
    )

    try:
        manifest_url = f"http://127.0.0.1:{server.server_port}/releases/download/v1.0.0/release-manifest.json"
        status = acquire_managed_bundle(
            source=manifest_url,
            data_dir=tmp_path / "data",
            workspace_root=tmp_path / "missing",
        )
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2.0)

    assert status.root == (tmp_path / "data" / "runtime" / "bundles" / "1.0.0").resolve()
    assert status.managed_runtime is True
    assert status.dashboard_mode == "bundled-static"
