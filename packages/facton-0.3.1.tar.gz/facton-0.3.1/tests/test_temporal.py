"""Tests for temporal awareness."""

import time

import pytest

from facton import Connection, Entity, Graph


class Person(Entity):
    name: str
    age: int


class Knows(Connection[Person, Person]):
    since: int | None = None


class TestHistory:
    def test_entity_history(self) -> None:
        g = Graph()
        alice = Person(id="alice", name="Alice", age=30)
        g.add(alice)

        alice.age = 31
        g.save(alice)

        history = g.history("alice")
        assert len(history) == 2
        assert history[0].data.age == 30
        assert history[1].data.age == 31

    def test_empty_history(self) -> None:
        g = Graph()
        assert g.history("nonexistent") == []


class TestPointInTime:
    def test_at_timestamp(self) -> None:
        g = Graph()
        alice = Person(id="alice", name="Alice", age=30)
        g.add(alice)

        # Small sleep to ensure distinct timestamps
        time.sleep(0.01)
        checkpoint = time.time()
        time.sleep(0.01)

        alice.age = 31
        g.save(alice)

        # The graph at checkpoint should have age=30
        from datetime import UTC, datetime

        ts = datetime.fromtimestamp(checkpoint, tz=UTC)
        past = g.at(ts)
        old_alice = past.get(Person, "alice")
        assert old_alice is not None
        assert old_alice.age == 30


class TestSnapshot:
    def test_named_snapshot(self) -> None:
        g = Graph()
        g.add(Person(id="alice", name="Alice", age=30))
        g.snapshot("v1")

        time.sleep(0.01)
        g.add(Person(id="bob", name="Bob", age=28))

        past = g.at_snapshot("v1")
        assert past.get(Person, "alice") is not None
        assert past.get(Person, "bob") is None

    def test_missing_snapshot_raises(self) -> None:
        g = Graph()
        with pytest.raises(ValueError, match="not found"):
            g.at_snapshot("nonexistent")


class TestTemporalEdgeCases:
    def test_at_after_remove_and_readd(self) -> None:
        """Point-in-time query sees the correct version across remove/re-add."""
        g = Graph()
        alice = Person(id="alice", name="Alice", age=30)
        g.add(alice)

        time.sleep(0.01)
        checkpoint_v1 = time.time()
        time.sleep(0.01)

        g.remove(alice)
        g.add(Person(id="alice", name="Alice v2", age=31))

        from datetime import UTC, datetime

        past = g.at(datetime.fromtimestamp(checkpoint_v1, tz=UTC))
        old_alice = past.get(Person, "alice")
        assert old_alice is not None
        assert old_alice.age == 30

    def test_history_after_remove_and_readd(self) -> None:
        """History includes all versions across remove and re-add."""
        g = Graph()
        g.add(Person(id="alice", name="Alice", age=30))
        g.remove("alice")
        g.add(Person(id="alice", name="Alice v2", age=31))

        history = g.history("alice")
        # add(30), remove (no data), add(31) — history returns entries with data
        assert len(history) >= 2
        ages = [v.data.age for v in history]
        assert 30 in ages
        assert 31 in ages

    def test_at_with_derived_connections(self) -> None:
        """Derived connections don't break point-in-time entity queries."""
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        g.add(a)
        g.add(b)
        g.derive(a, b, Knows(since=2024))

        time.sleep(0.01)
        g.snapshot("with_derived")

        past = g.at_snapshot("with_derived")
        assert past.get(Person, "a") is not None
        assert past.get(Person, "b") is not None
