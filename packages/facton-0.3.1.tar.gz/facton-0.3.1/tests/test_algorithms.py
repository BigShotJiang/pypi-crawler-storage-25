"""Tests for graph algorithms (shortest path, connected components)."""

from __future__ import annotations

import time
from datetime import date

from facton import Connection, Entity, Field, Graph


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Organization(Entity):
    name: str


class Knows(Connection[Person, Person]):
    since: int | None = None


class WorksAt(Connection[Person, Organization]):
    role: str
    started: date


class TestShortestPath:
    def test_direct_connection(self) -> None:
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Knows(since=2020))

        path = g.shortest_path(alice, bob, Knows)
        assert path is not None
        assert [e.id for e in path] == ["a", "b"]

    def test_multi_hop_path(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        c = Person(id="c", name="C", age=3)
        d = Person(id="d", name="D", age=4)
        for e in (a, b, c, d):
            g.add(e)
        g.connect(a, b, Knows())
        g.connect(b, c, Knows())
        g.connect(c, d, Knows())

        path = g.shortest_path(a, d, Knows)
        assert path is not None
        assert [e.id for e in path] == ["a", "b", "c", "d"]

    def test_no_path_returns_none(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        g.add(a)
        g.add(b)
        # No connection

        assert g.shortest_path(a, b, Knows) is None

    def test_same_node_returns_single(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        g.add(a)

        path = g.shortest_path(a, a, Knows)
        assert path is not None
        assert len(path) == 1
        assert path[0].id == "a"

    def test_finds_shortest_not_any(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        c = Person(id="c", name="C", age=3)
        for e in (a, b, c):
            g.add(e)
        # Direct a→c and longer a→b→c
        g.connect(a, c, Knows())
        g.connect(a, b, Knows())
        g.connect(b, c, Knows())

        path = g.shortest_path(a, c, Knows)
        assert path is not None
        assert len(path) == 2  # a → c directly

    def test_with_cycle(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        c = Person(id="c", name="C", age=3)
        g.add(a)
        g.add(b)
        g.add(c)
        g.connect(a, b, Knows())
        g.connect(b, c, Knows())
        g.connect(c, a, Knows())  # cycle

        path = g.shortest_path(a, c, Knows)
        assert path is not None
        # Direct a→b→c = 3 hops, but via reverse c→a, a is start so a→b→c
        assert len(path) <= 3

    def test_nonexistent_entity(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        g.add(a)
        assert g.shortest_path("a", "zzz", Knows) is None

    def test_bidirectional_finds_reverse(self) -> None:
        """BFS should follow edges in both directions."""
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        g.add(a)
        g.add(b)
        g.connect(b, a, Knows())  # only b→a

        path = g.shortest_path(a, b, Knows)
        assert path is not None
        assert [e.id for e in path] == ["a", "b"]

    def test_empty_graph(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        assert g.shortest_path(a, a, Knows) is None


class TestComponents:
    def test_single_component(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        g.add(a)
        g.add(b)
        g.connect(a, b, Knows())

        comps = g.components(Knows)
        assert len(comps) == 1
        assert comps[0] == {"a", "b"}

    def test_multiple_components(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        c = Person(id="c", name="C", age=3)
        d = Person(id="d", name="D", age=4)
        for e in (a, b, c, d):
            g.add(e)
        g.connect(a, b, Knows())
        g.connect(c, d, Knows())

        comps = g.components(Knows)
        assert len(comps) == 2
        comp_sets = [frozenset(c) for c in comps]
        assert frozenset({"a", "b"}) in comp_sets
        assert frozenset({"c", "d"}) in comp_sets

    def test_isolated_nodes_are_components(self) -> None:
        g = Graph()
        g.add(Person(id="a", name="A", age=1))
        g.add(Person(id="b", name="B", age=2))

        comps = g.components()
        assert len(comps) == 2

    def test_all_connections_when_no_type_filter(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        acme = Organization(id="acme", name="Acme")
        g.add(a)
        g.add(acme)
        g.connect(a, acme, WorksAt(role="Eng", started=date(2022, 1, 1)))

        comps = g.components()
        assert len(comps) == 1
        assert comps[0] == {"a", "acme"}

    def test_single_node(self) -> None:
        g = Graph()
        g.add(Person(id="a", name="A", age=1))
        comps = g.components()
        assert len(comps) == 1
        assert comps[0] == {"a"}

    def test_all_disconnected(self) -> None:
        g = Graph()
        for i in range(5):
            g.add(Person(id=f"p{i}", name=f"P{i}", age=i))
        comps = g.components()
        assert len(comps) == 5

    def test_with_cycle(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        c = Person(id="c", name="C", age=3)
        g.add(a)
        g.add(b)
        g.add(c)
        g.connect(a, b, Knows())
        g.connect(b, c, Knows())
        g.connect(c, a, Knows())

        comps = g.components(Knows)
        assert len(comps) == 1
        assert comps[0] == {"a", "b", "c"}

    def test_empty_graph(self) -> None:
        g = Graph()
        assert g.components() == []
        assert g.components(Knows) == []


class TestAlgorithmPerformance:
    def test_large_graph_shortest_path(self) -> None:
        g = Graph()
        n = 500
        people = [Person(id=f"p{i}", name=f"P{i}", age=i) for i in range(n)]
        for p in people:
            g.add(p)
        for i in range(n - 1):
            g.connect(people[i], people[i + 1], Knows())

        start = time.perf_counter()
        path = g.shortest_path(people[0], people[49], Knows)
        elapsed = time.perf_counter() - start
        assert path is not None
        assert len(path) == 50
        assert elapsed < 1.0

    def test_large_graph_components(self) -> None:
        g = Graph()
        # 5 disconnected chains of 100 each
        for chain in range(5):
            offset = chain * 100
            people = [
                Person(id=f"p{offset + i}", name=f"P{offset + i}", age=i)
                for i in range(100)
            ]
            for p in people:
                g.add(p)
            for i in range(99):
                g.connect(people[i], people[i + 1], Knows())

        comps = g.components(Knows)
        assert len(comps) == 5
        assert all(len(c) == 100 for c in comps)
