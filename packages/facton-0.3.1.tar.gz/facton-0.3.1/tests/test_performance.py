"""Performance and stress tests."""

from __future__ import annotations

import json
import time

from facton import Connection, Entity, Field, Graph


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Organization(Entity):
    name: str


class Knows(Connection[Person, Person]):
    since: int | None = None


class TestPerformance:
    def test_large_graph_add_and_query(self) -> None:
        g = Graph()
        n = 2000
        for i in range(n):
            g.add(Person(id=f"p{i}", name=f"Person {i}", age=i % 100))

        assert g.query(Person).count() == n
        assert len(g._by_type[Person]) == n

    def test_large_graph_connections_and_traversal(self) -> None:
        g = Graph()
        n = 500
        people = [Person(id=f"p{i}", name=f"P{i}", age=i) for i in range(n)]
        for p in people:
            g.add(p)
        # Chain: p0→p1→p2→...→p499
        for i in range(n - 1):
            g.connect(people[i], people[i + 1], Knows())

        assert len(g._connections) == n - 1

        # Traversal should be fast with index
        start = time.perf_counter()
        result = g.traverse(people[0], Knows, depth=10)
        elapsed = time.perf_counter() - start
        assert len(result) == 10
        assert elapsed < 1.0  # should be well under 1s with indexes

    def test_large_graph_serialization_roundtrip(self) -> None:
        g = Graph()
        n = 500
        people = [Person(id=f"p{i}", name=f"P{i}", age=i) for i in range(n)]
        for p in people:
            g.add(p)
        for i in range(n - 1):
            g.connect(people[i], people[i + 1], Knows())

        start = time.perf_counter()
        data = g.to_dict()
        raw = json.dumps(data, default=str)
        restored = json.loads(raw)
        g2 = Graph.from_dict(
            restored,
            type_registry={
                Person.__qualname__: Person,
                Knows.__qualname__: Knows,
            },
        )
        elapsed = time.perf_counter() - start

        assert len(g2._entities) == n
        assert len(g2._connections) == n - 1
        assert elapsed < 5.0

    def test_type_index_query_speed(self) -> None:
        g = Graph()
        for i in range(1000):
            g.add(Person(id=f"p{i}", name=f"P{i}", age=i))
        for i in range(1000):
            g.add(Organization(id=f"o{i}", name=f"O{i}"))

        start = time.perf_counter()
        orgs = g.query(Organization).all()
        elapsed = time.perf_counter() - start

        assert len(orgs) == 1000
        assert elapsed < 0.5
