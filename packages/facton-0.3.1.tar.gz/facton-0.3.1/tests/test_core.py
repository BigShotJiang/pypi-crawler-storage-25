"""Basic tests for facton core types and graph operations."""

from datetime import date

from facton import Connection, Entity, Field, Graph


class Person(Entity):
    name: str
    age: int = Field(ge=0, le=200)
    email: str | None = None
    skills: list[str] = Field(default_factory=list)


class Organization(Entity):
    name: str
    industry: str | None = None


class Knows(Connection[Person, Person]):
    since: int | None = None


class WorksAt(Connection[Person, Organization]):
    role: str
    started: date
    ended: date | None = None


class TestEntity:
    def test_create_person(self) -> None:
        alice = Person(id="alice", name="Alice", age=30)
        assert alice.id == "alice"
        assert alice.name == "Alice"
        assert alice.age == 30
        assert alice.email is None
        assert alice.skills == []

    def test_entity_with_optional_fields(self) -> None:
        bob = Person(
            id="bob",
            name="Bob",
            age=28,
            email="bob@example.com",
            skills=["python", "rust"],
        )
        assert bob.email == "bob@example.com"
        assert bob.skills == ["python", "rust"]

    def test_subtype_polymorphism(self) -> None:
        class Employee(Person):
            employee_id: str
            department: str

        emp = Employee(
            id="emp1",
            name="Carol",
            age=35,
            employee_id="E001",
            department="Engineering",
        )
        assert isinstance(emp, Person)
        assert isinstance(emp, Employee)
        assert emp.department == "Engineering"


class TestGraph:
    def test_add_and_get(self) -> None:
        g = Graph()
        alice = Person(id="alice", name="Alice", age=30)
        g.add(alice)

        result = g.get(Person, "alice")
        assert result is not None
        assert result.name == "Alice"

    def test_add_duplicate_raises(self) -> None:
        g = Graph()
        alice = Person(id="alice", name="Alice", age=30)
        g.add(alice)

        import pytest

        with pytest.raises(ValueError, match="already exists"):
            g.add(Person(id="alice", name="Alice2", age=25))

    def test_remove_entity(self) -> None:
        g = Graph()
        alice = Person(id="alice", name="Alice", age=30)
        g.add(alice)
        g.remove(alice)

        assert g.get(Person, "alice") is None

    def test_query_by_type(self) -> None:
        g = Graph()
        g.add(Person(id="alice", name="Alice", age=30))
        g.add(Person(id="bob", name="Bob", age=28))
        g.add(Organization(id="acme", name="Acme Corp"))

        people = g.query(Person).all()
        assert len(people) == 2

        orgs = g.query(Organization).all()
        assert len(orgs) == 1

    def test_query_returns_subtypes(self) -> None:
        class Employee(Person):
            employee_id: str

        g = Graph()
        g.add(Person(id="alice", name="Alice", age=30))
        g.add(Employee(id="bob", name="Bob", age=28, employee_id="E001"))

        people = g.query(Person).all()
        assert len(people) == 2

        employees = g.query(Employee).all()
        assert len(employees) == 1


class TestConnection:
    def test_connect_entities(self) -> None:
        g = Graph()
        alice = Person(id="alice", name="Alice", age=30)
        bob = Person(id="bob", name="Bob", age=28)
        g.add(alice)
        g.add(bob)

        edge = g.connect(alice, bob, Knows(since=2019))
        assert edge.since == 2019

    def test_connect_different_types(self) -> None:
        g = Graph()
        alice = Person(id="alice", name="Alice", age=30)
        acme = Organization(id="acme", name="Acme Corp", industry="tech")
        g.add(alice)
        g.add(acme)

        edge = g.connect(
            alice,
            acme,
            WorksAt(role="Engineer", started=date(2022, 3, 15)),
        )
        assert edge.role == "Engineer"

    def test_disconnect(self) -> None:
        g = Graph()
        alice = Person(id="alice", name="Alice", age=30)
        bob = Person(id="bob", name="Bob", age=28)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Knows(since=2019))

        g.disconnect(alice, bob, Knows)
        assert g.connections_of(alice, Knows) == []

    def test_remove_entity_cascades_connections(self) -> None:
        g = Graph()
        alice = Person(id="alice", name="Alice", age=30)
        bob = Person(id="bob", name="Bob", age=28)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Knows(since=2019))

        g.remove(bob)
        assert g.connections_of(alice) == []

    def test_connect_missing_entity_raises(self) -> None:
        g = Graph()
        alice = Person(id="alice", name="Alice", age=30)
        bob = Person(id="bob", name="Bob", age=28)
        g.add(alice)

        import pytest

        with pytest.raises(ValueError, match="not found"):
            g.connect(alice, bob, Knows(since=2019))
