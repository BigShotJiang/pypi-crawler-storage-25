"""Multi-step integration workflows that exercise the full graph lifecycle."""

from __future__ import annotations

import tempfile
from datetime import date
from pathlib import Path

from facton import Connection, Entity, Field, Graph, merge, rule


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Organization(Entity):
    name: str


class Knows(Connection[Person, Person]):
    since: int | None = None


class WorksAt(Connection[Person, Organization]):
    role: str
    started: date


class TestFullLifecycleWorkflow:
    def test_build_serialize_load_mutate_snapshot_rollback_rules_serialize(
        self,
    ) -> None:
        """50-operation workflow exercising the full API surface."""
        # --- Phase 1: Build a graph ---
        g = Graph()
        alice = Person(id="alice", name="Alice", age=30)
        bob = Person(id="bob", name="Bob", age=25)
        carol = Person(id="carol", name="Carol", age=35)
        acme = Organization(id="acme", name="Acme Corp")
        g.add(alice)
        g.add(bob)
        g.add(carol)
        g.add(acme)
        g.connect(alice, bob, Knows(since=2019))
        g.connect(bob, carol, Knows(since=2020))
        g.connect(alice, acme, WorksAt(role="Engineer", started=date(2021, 1, 1)))
        g.connect(bob, acme, WorksAt(role="Designer", started=date(2022, 6, 1)))

        assert len(g._entities) == 4
        assert len(g._connections) == 4

        # --- Phase 2: Serialize to file ---
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name
        try:
            g.save_file(path)

            # --- Phase 3: Load from file ---
            registry = {
                cls.__qualname__: cls for cls in (Person, Organization, Knows, WorksAt)
            }
            g2 = Graph.load_file(path, type_registry=registry)
            assert len(g2._entities) == 4
            assert len(g2._connections) == 4
            assert g2.get(Person, "alice").name == "Alice"

            # Verify indexes rebuilt
            assert "alice" in g2._by_type[Person]
            assert len(g2._outgoing.get("alice", [])) == 2

            # --- Phase 4: Mutate the loaded graph ---
            dave = Person(id="dave", name="Dave", age=28)
            g2.add(dave)
            g2.connect(carol, dave, Knows(since=2023))
            g2.save(Person(id="alice", name="Alice", age=31))

            assert g2.get(Person, "alice").age == 31
            assert len(g2._entities) == 5

            # --- Phase 5: Snapshot ---
            g2.snapshot("after_dave")

            # --- Phase 6: Transaction with rollback ---
            import pytest

            with pytest.raises(RuntimeError), g2.transaction() as tx:
                tx.add(Person(id="eve", name="Eve", age=22))
                tx.connect(dave, Person(id="eve", name="Eve", age=22), Knows())
                raise RuntimeError("abort")

            # Eve should not exist after rollback
            assert g2.get(Person, "eve") is None
            assert len(g2._entities) == 5

            # --- Phase 7: Rules ---
            @rule
            def transitive_knows(graph: Graph) -> None:
                for stored in list(graph._connections):
                    if not isinstance(stored.connection, Knows):
                        continue
                    for hop2 in list(graph._outgoing.get(stored.target_id, [])):
                        if not isinstance(hop2.connection, Knows):
                            continue
                        if stored.source_id == hop2.target_id:
                            continue
                        existing = [
                            c
                            for c in graph._outgoing.get(stored.source_id, [])
                            if isinstance(c.connection, Knows)
                            and c.target_id == hop2.target_id
                        ]
                        if not existing:
                            graph.derive(stored.source_id, hop2.target_id, Knows())

            g2.register_rule(transitive_knows)
            g2.run_rules()

            derived = [c for c in g2._connections if c.derived]
            assert len(derived) > 0

            # --- Phase 8: Serialize again ---
            g2.save_file(path)
            g3 = Graph.load_file(path, type_registry=registry)

            assert len(g3._entities) == 5
            assert g3.get(Person, "alice").age == 31
            assert len(g3._connections) >= 5  # originals + derived

            # Derived connections survive roundtrip
            derived_in_g3 = [c for c in g3._connections if c.derived]
            assert len(derived_in_g3) == len(derived)

        finally:
            Path(path).unlink(missing_ok=True)


class TestMergeThenQueryWorkflow:
    def test_merge_independent_graphs_then_traverse(self) -> None:
        """Build two graphs independently, merge, then query and traverse."""
        # Graph A: social network
        g_a = Graph()
        alice = Person(id="alice", name="Alice", age=30)
        bob = Person(id="bob", name="Bob", age=25)
        g_a.add(alice)
        g_a.add(bob)
        g_a.connect(alice, bob, Knows(since=2019))

        # Graph B: different social network
        g_b = Graph()
        carol = Person(id="carol", name="Carol", age=35)
        dave = Person(id="dave", name="Dave", age=28)
        g_b.add(carol)
        g_b.add(dave)
        g_b.connect(carol, dave, Knows(since=2021))

        # Merge
        combined = merge(g_a, g_b)
        assert len(combined._entities) == 4

        # Query across the merged graph
        all_people = combined.query(Person).where(lambda p: p.age >= 28).all()
        names = {p.name for p in all_people}
        assert "Alice" in names
        assert "Carol" in names
        assert "Dave" in names
        assert "Bob" not in names  # age 25

        # Components: two disconnected pairs
        comps = combined.components(Knows)
        assert len(comps) == 2
