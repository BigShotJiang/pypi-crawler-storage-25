"""Tests for constraint enforcement."""

from datetime import date
from typing import ClassVar

import pytest

from facton import Connection, Constraint, Entity, Field, Graph, Unique


class Person(Entity):
    name: str
    email: str = Field(unique=True)

    class Meta:
        constraints: ClassVar[list] = [
            Unique("name", "email"),
        ]


class Organization(Entity):
    name: str


class WorksAt(Connection[Person, Organization]):
    role: str
    started: date
    ended: date | None = None

    class Meta:
        constraints: ClassVar[list] = [
            Constraint.max_per_source(1, where=lambda c: c.ended is None),
        ]


class TestUniqueFieldConstraint:
    def test_unique_field_enforced(self) -> None:
        g = Graph()
        g.add(Person(id="alice", name="Alice", email="alice@example.com"))

        with pytest.raises(ValueError, match="Unique constraint violated"):
            g.add(Person(id="bob", name="Bob", email="alice@example.com"))

    def test_unique_field_allows_different_values(self) -> None:
        g = Graph()
        g.add(Person(id="alice", name="Alice", email="alice@example.com"))
        g.add(Person(id="bob", name="Bob", email="bob@example.com"))
        assert g.query(Person).count() == 2

    def test_unique_field_enforced_on_save(self) -> None:
        g = Graph()
        g.add(Person(id="alice", name="Alice", email="alice@example.com"))
        bob = Person(id="bob", name="Bob", email="bob@example.com")
        g.add(bob)

        bob.email = "alice@example.com"
        with pytest.raises(ValueError, match="Unique constraint violated"):
            g.save(bob)


class TestCompositeUniqueConstraint:
    def test_composite_unique_enforced(self) -> None:
        g = Graph()
        g.add(Person(id="alice", name="Alice", email="alice@example.com"))

        with pytest.raises(ValueError, match="Unique constraint violated"):
            g.add(Person(id="alice2", name="Alice", email="alice@example.com"))

    def test_composite_unique_allows_partial_match(self) -> None:
        g = Graph()
        g.add(Person(id="alice", name="Alice", email="alice@example.com"))
        # Same name, different email — allowed
        g.add(Person(id="alice2", name="Alice", email="alice2@example.com"))
        assert g.query(Person).count() == 2


class TestCardinalityConstraint:
    def test_max_per_source_enforced(self) -> None:
        g = Graph()
        alice = Person(id="alice", name="Alice", email="alice@example.com")
        acme = Organization(id="acme", name="Acme Corp")
        bigco = Organization(id="bigco", name="BigCo")
        g.add(alice)
        g.add(acme)
        g.add(bigco)

        g.connect(
            alice,
            acme,
            WorksAt(role="Engineer", started=date(2022, 1, 1)),
        )

        with pytest.raises(ValueError, match="Cardinality constraint violated"):
            g.connect(
                alice,
                bigco,
                WorksAt(role="Manager", started=date(2024, 1, 1)),
            )

    def test_max_per_source_allows_ended(self) -> None:
        g = Graph()
        alice = Person(id="alice", name="Alice", email="alice@example.com")
        acme = Organization(id="acme", name="Acme Corp")
        bigco = Organization(id="bigco", name="BigCo")
        g.add(alice)
        g.add(acme)
        g.add(bigco)

        # Ended job doesn't count against limit
        g.connect(
            alice,
            acme,
            WorksAt(
                role="Engineer",
                started=date(2020, 1, 1),
                ended=date(2022, 1, 1),
            ),
        )

        # Active job is fine
        g.connect(
            alice,
            bigco,
            WorksAt(role="Manager", started=date(2022, 1, 1)),
        )
        assert len(g.connections_of(alice, WorksAt)) == 2


class TestConstraintEdgeCases:
    def test_disconnect_nonexistent_is_silent(self) -> None:
        from facton import Connection

        class Knows(Connection[Person, Person]):
            since: int | None = None

        g = Graph()
        a = Person(id="a", name="A", email="a@test.com")
        b = Person(id="b", name="B", email="b@test.com")
        g.add(a)
        g.add(b)
        # No connection exists — disconnect should be a no-op
        g.disconnect(a, b, Knows)
        assert len(g._connections) == 0

    def test_unique_field_allows_multiple_nones(self) -> None:
        from facton import Connection

        class Knows(Connection[Person, Person]):
            since: int | None = None

        g = Graph()
        a = Person(id="a", name="A", email="a@test.com")
        b = Person(id="b", name="B", email="b@test.com")
        g.add(a)
        g.add(b)
        # Both with since=None should be allowed
        g.connect(a, b, Knows(since=None))
        g.connect(a, b, Knows(since=None))
        assert len(g._connections) == 2

    def test_duplicate_add_same_id_raises(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", email="a@test.com")
        g.add(a)
        with pytest.raises(ValueError, match="already exists"):
            g.add(Person(id="a", name="A2", email="a2@test.com"))

    def test_cardinality_constraint_enforced(self) -> None:
        class ManagedBy(Connection[Person, Person]):
            class Meta:
                constraints: ClassVar = [Constraint.max_per_source(1)]

        g = Graph()
        a = Person(id="a", name="A", email="a@test.com")
        b = Person(id="b", name="B", email="b@test.com")
        c = Person(id="c", name="C", email="c@test.com")
        g.add(a)
        g.add(b)
        g.add(c)
        g.connect(a, b, ManagedBy())

        with pytest.raises(ValueError):
            g.connect(a, c, ManagedBy())
