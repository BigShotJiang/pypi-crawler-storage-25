"""Tests for Fact[T] property wrapping and annotations."""

from facton import Connection, Entity, Fact, Field, Graph


class Person(Entity):
    name: str
    age: int = Field(ge=0)
    email: str | None = None


class Knows(Connection[Person, Person]):
    since: int | None = None


class TestFactWrapping:
    def test_entity_properties_are_facts(self) -> None:
        alice = Person(id="alice", name="Alice", age=30)
        assert isinstance(alice.name, Fact)
        assert isinstance(alice.age, Fact)

    def test_fact_behaves_as_value(self) -> None:
        alice = Person(id="alice", name="Alice", age=30)
        assert alice.name == "Alice"
        assert alice.name.upper() == "ALICE"
        assert alice.age + 1 == 31
        assert isinstance(alice.name, str)
        assert isinstance(alice.age, int)

    def test_property_annotations(self) -> None:
        alice = Person(id="alice", name="Alice", age=30)
        alice.name.annotate(source="hr_system", confidence=0.95)
        assert alice.name.annotations == {"source": "hr_system", "confidence": 0.95}

    def test_entity_annotations(self) -> None:
        alice = Person(id="alice", name="Alice", age=30)
        alice.annotate(imported_from="batch_42")
        assert alice.entity_annotations == {"imported_from": "batch_42"}

    def test_connection_property_is_fact(self) -> None:
        edge = Knows(since=2019)
        assert isinstance(edge.since, Fact)
        assert edge.since == 2019

    def test_connection_property_annotations(self) -> None:
        edge = Knows(since=2019)
        edge.since.annotate(source="user_input")
        assert edge.since.annotations == {"source": "user_input"}

    def test_none_optional_is_not_fact(self) -> None:
        alice = Person(id="alice", name="Alice", age=30)
        # None values should not be wrapped
        assert alice.email is None

    def test_setattr_wraps_in_fact(self) -> None:
        alice = Person(id="alice", name="Alice", age=30)
        alice.age = 31
        assert isinstance(alice.age, Fact)
        assert alice.age == 31

    def test_fact_identity_after_graph_get(self) -> None:
        g = Graph()
        alice = Person(id="alice", name="Alice", age=30)
        alice.name.annotate(source="hr")
        g.add(alice)

        retrieved = g.get(Person, "alice")
        assert retrieved is not None
        assert retrieved.name.annotations == {"source": "hr"}
