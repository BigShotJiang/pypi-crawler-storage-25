"""Tests for StorageBackend protocol, InMemoryBackend, and JsonFileBackend."""

from __future__ import annotations

from facton import (
    Connection,
    Entity,
    Field,
    Graph,
    InMemoryBackend,
    JsonFileBackend,
    Relation,
    StorageBackend,
)

# --- Test schema ---


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Organization(Entity):
    name: str


class Knows(Connection[Person, Person]):
    since: int | None = None


class WorksAt(Connection[Person, Organization]):
    role: str


class Meeting(Relation):
    topic: str


# --- InMemoryBackend standalone tests ---


class TestInMemoryBackendProtocol:
    def test_satisfies_protocol(self) -> None:
        backend = InMemoryBackend()
        assert isinstance(backend, StorageBackend)


class TestInMemoryBackendEntities:
    def test_save_and_get(self) -> None:
        backend = InMemoryBackend()
        alice = Person(id="a", name="Alice", age=30)
        backend.save(alice)

        result = backend.get("a", Person)
        assert result is not None
        assert result.name == "Alice"

    def test_get_wrong_type_returns_none(self) -> None:
        backend = InMemoryBackend()
        alice = Person(id="a", name="Alice", age=30)
        backend.save(alice)

        assert backend.get("a", Organization) is None

    def test_get_missing_returns_none(self) -> None:
        backend = InMemoryBackend()
        assert backend.get("nope", Person) is None

    def test_has(self) -> None:
        backend = InMemoryBackend()
        alice = Person(id="a", name="Alice", age=30)
        backend.save(alice)

        assert backend.has("a") is True
        assert backend.has("b") is False

    def test_delete(self) -> None:
        backend = InMemoryBackend()
        alice = Person(id="a", name="Alice", age=30)
        backend.save(alice)
        backend.delete("a")

        assert backend.has("a") is False
        assert backend.get("a", Person) is None

    def test_delete_also_removes_connections(self) -> None:
        backend = InMemoryBackend()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        backend.save(alice)
        backend.save(bob)
        backend.save_connection("a", "b", Knows(since=2020))

        backend.delete("a")

        conns = list(backend.query_connections("b", Knows, direction="incoming"))
        assert conns == []

    def test_query_by_type(self) -> None:
        backend = InMemoryBackend()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        acme = Organization(id="acme", name="Acme")
        backend.save(alice)
        backend.save(bob)
        backend.save(acme)

        people = list(backend.query(Person))
        assert len(people) == 2

        orgs = list(backend.query(Organization))
        assert len(orgs) == 1

    def test_save_overwrites(self) -> None:
        backend = InMemoryBackend()
        alice = Person(id="a", name="Alice", age=30)
        backend.save(alice)

        alice_v2 = Person(id="a", name="Alice", age=31)
        backend.save(alice_v2)

        result = backend.get("a", Person)
        assert result is not None
        assert result.age == 31


class TestInMemoryBackendConnections:
    def test_save_and_query_outgoing(self) -> None:
        backend = InMemoryBackend()
        backend.save_connection("a", "b", Knows(since=2020))

        conns = list(backend.query_connections("a", Knows, direction="outgoing"))
        assert len(conns) == 1
        assert conns[0] == ("a", "b", conns[0][2])
        assert conns[0][2].since == 2020

    def test_query_incoming(self) -> None:
        backend = InMemoryBackend()
        backend.save_connection("a", "b", Knows(since=2020))

        conns = list(backend.query_connections("b", Knows, direction="incoming"))
        assert len(conns) == 1
        assert conns[0][0] == "a"

    def test_query_both_directions(self) -> None:
        backend = InMemoryBackend()
        backend.save_connection("a", "b", Knows(since=2020))
        backend.save_connection("c", "a", Knows(since=2021))

        conns = list(backend.query_connections("a", Knows, direction="both"))
        assert len(conns) == 2

    def test_query_wrong_type_empty(self) -> None:
        backend = InMemoryBackend()
        backend.save_connection("a", "b", Knows(since=2020))

        conns = list(backend.query_connections("a", WorksAt, direction="outgoing"))
        assert conns == []

    def test_delete_connection(self) -> None:
        backend = InMemoryBackend()
        backend.save_connection("a", "b", Knows(since=2020))
        backend.save_connection("a", "b", Knows(since=2021))
        backend.delete_connection("a", "b", Knows)

        conns = list(backend.query_connections("a", Knows, direction="outgoing"))
        assert conns == []

    def test_delete_connection_preserves_others(self) -> None:
        backend = InMemoryBackend()
        acme = Organization(id="acme", name="Acme")
        backend.save(acme)
        backend.save_connection("a", "b", Knows(since=2020))
        backend.save_connection("a", "acme", WorksAt(role="Engineer"))

        backend.delete_connection("a", "b", Knows)

        conns = list(backend.query_connections("a", WorksAt, direction="outgoing"))
        assert len(conns) == 1

    def test_derived_flag(self) -> None:
        backend = InMemoryBackend()
        backend.save_connection("a", "b", Knows(since=2020), derived=True)

        # The derived flag is stored on the internal _StoredConnection,
        # not exposed through query_connections tuples. Just verify it
        # doesn't break anything.
        conns = list(backend.query_connections("a", Knows, direction="outgoing"))
        assert len(conns) == 1


class TestInMemoryBackendRelations:
    def test_save_and_query(self) -> None:
        backend = InMemoryBackend()
        m = Meeting(topic="standup")
        backend.save_relation(m)

        results = list(backend.query_relations(Meeting))
        assert len(results) == 1
        assert results[0].topic == "standup"

    def test_delete_relation(self) -> None:
        backend = InMemoryBackend()
        m = Meeting(topic="standup")
        backend.save_relation(m)
        backend.delete_relation(m)

        results = list(backend.query_relations(Meeting))
        assert results == []

    def test_query_filters_by_type(self) -> None:
        class OtherRelation(Relation):
            label: str

        backend = InMemoryBackend()
        backend.save_relation(Meeting(topic="standup"))
        backend.save_relation(OtherRelation(label="x"))

        meetings = list(backend.query_relations(Meeting))
        assert len(meetings) == 1


# --- Graph + backend integration tests ---


class TestGraphBackendIntegration:
    def test_add_entity_writes_through(self) -> None:
        backend = InMemoryBackend()
        g = Graph(backend=backend)
        alice = Person(id="a", name="Alice", age=30)
        g.add(alice)

        assert backend.has("a")
        assert backend.get("a", Person) is not None

    def test_save_entity_writes_through(self) -> None:
        backend = InMemoryBackend()
        g = Graph(backend=backend)
        alice = Person(id="a", name="Alice", age=30)
        g.add(alice)

        alice.age = 31
        g.save(alice)

        result = backend.get("a", Person)
        assert result is not None
        assert result.age == 31

    def test_remove_entity_writes_through(self) -> None:
        backend = InMemoryBackend()
        g = Graph(backend=backend)
        alice = Person(id="a", name="Alice", age=30)
        g.add(alice)
        g.remove(alice)

        assert backend.has("a") is False

    def test_connect_writes_through(self) -> None:
        backend = InMemoryBackend()
        g = Graph(backend=backend)
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Knows(since=2020))

        conns = list(backend.query_connections("a", Knows, direction="outgoing"))
        assert len(conns) == 1
        assert conns[0][1] == "b"

    def test_disconnect_writes_through(self) -> None:
        backend = InMemoryBackend()
        g = Graph(backend=backend)
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Knows(since=2020))
        g.disconnect(alice, bob, Knows)

        conns = list(backend.query_connections("a", Knows, direction="outgoing"))
        assert conns == []

    def test_derive_writes_through(self) -> None:
        backend = InMemoryBackend()
        g = Graph(backend=backend)
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.derive(alice, bob, Knows(since=2020))

        conns = list(backend.query_connections("a", Knows, direction="outgoing"))
        assert len(conns) == 1

    def test_relate_writes_through(self) -> None:
        backend = InMemoryBackend()
        g = Graph(backend=backend)
        m = Meeting(topic="standup")
        g.relate(m)

        results = list(backend.query_relations(Meeting))
        assert len(results) == 1

    def test_remove_cleans_backend_connections(self) -> None:
        backend = InMemoryBackend()
        g = Graph(backend=backend)
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Knows(since=2020))
        g.remove(alice)

        conns = list(backend.query_connections("b", Knows, direction="incoming"))
        assert conns == []

    def test_graph_works_without_backend(self) -> None:
        """All existing behavior preserved when no backend is provided."""
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Knows(since=2020))

        assert g.get(Person, "a") is not None
        assert len(g.connections_of(alice)) == 1


# --- JsonFileBackend standalone tests ---


class TestJsonFileBackendProtocol:
    def test_satisfies_protocol(self, tmp_path) -> None:
        backend = JsonFileBackend(tmp_path / "g.json", types=[Person])
        assert isinstance(backend, StorageBackend)

    def test_creates_file_on_init(self, tmp_path) -> None:
        path = tmp_path / "g.json"
        assert not path.exists()
        JsonFileBackend(path, types=[Person])
        assert path.exists()


class TestJsonFileBackendEntities:
    def test_save_and_get(self, tmp_path) -> None:
        backend = JsonFileBackend(tmp_path / "g.json", types=[Person])
        alice = Person(id="a", name="Alice", age=30)
        backend.save(alice)

        result = backend.get("a", Person)
        assert result is not None
        assert result.name == "Alice"
        assert result.age == 30

    def test_get_wrong_type_returns_none(self, tmp_path) -> None:
        backend = JsonFileBackend(tmp_path / "g.json", types=[Person, Organization])
        alice = Person(id="a", name="Alice", age=30)
        backend.save(alice)

        assert backend.get("a", Organization) is None

    def test_get_missing_returns_none(self, tmp_path) -> None:
        backend = JsonFileBackend(tmp_path / "g.json", types=[Person])
        assert backend.get("nope", Person) is None

    def test_has(self, tmp_path) -> None:
        backend = JsonFileBackend(tmp_path / "g.json", types=[Person])
        alice = Person(id="a", name="Alice", age=30)
        backend.save(alice)

        assert backend.has("a") is True
        assert backend.has("b") is False

    def test_delete(self, tmp_path) -> None:
        backend = JsonFileBackend(tmp_path / "g.json", types=[Person])
        alice = Person(id="a", name="Alice", age=30)
        backend.save(alice)
        backend.delete("a")

        assert backend.has("a") is False

    def test_delete_also_removes_connections(self, tmp_path) -> None:
        backend = JsonFileBackend(tmp_path / "g.json", types=[Person, Knows])
        backend.save(Person(id="a", name="Alice", age=30))
        backend.save(Person(id="b", name="Bob", age=25))
        backend.save_connection("a", "b", Knows(since=2020))
        backend.delete("a")

        conns = list(backend.query_connections("b", Knows, direction="incoming"))
        assert conns == []

    def test_query_by_type(self, tmp_path) -> None:
        backend = JsonFileBackend(tmp_path / "g.json", types=[Person, Organization])
        backend.save(Person(id="a", name="Alice", age=30))
        backend.save(Person(id="b", name="Bob", age=25))
        backend.save(Organization(id="acme", name="Acme"))

        people = list(backend.query(Person))
        assert len(people) == 2

        orgs = list(backend.query(Organization))
        assert len(orgs) == 1

    def test_save_overwrites(self, tmp_path) -> None:
        backend = JsonFileBackend(tmp_path / "g.json", types=[Person])
        backend.save(Person(id="a", name="Alice", age=30))
        backend.save(Person(id="a", name="Alice", age=31))

        result = backend.get("a", Person)
        assert result is not None
        assert result.age == 31

    def test_persists_across_instances(self, tmp_path) -> None:
        path = tmp_path / "g.json"
        b1 = JsonFileBackend(path, types=[Person])
        b1.save(Person(id="a", name="Alice", age=30))

        b2 = JsonFileBackend(path, types=[Person])
        result = b2.get("a", Person)
        assert result is not None
        assert result.name == "Alice"


class TestJsonFileBackendConnections:
    def test_save_and_query_outgoing(self, tmp_path) -> None:
        backend = JsonFileBackend(tmp_path / "g.json", types=[Knows])
        backend.save_connection("a", "b", Knows(since=2020))

        conns = list(backend.query_connections("a", Knows, direction="outgoing"))
        assert len(conns) == 1
        assert conns[0][0] == "a"
        assert conns[0][1] == "b"
        assert conns[0][2].since == 2020

    def test_query_incoming(self, tmp_path) -> None:
        backend = JsonFileBackend(tmp_path / "g.json", types=[Knows])
        backend.save_connection("a", "b", Knows(since=2020))

        conns = list(backend.query_connections("b", Knows, direction="incoming"))
        assert len(conns) == 1
        assert conns[0][0] == "a"

    def test_query_both_directions(self, tmp_path) -> None:
        backend = JsonFileBackend(tmp_path / "g.json", types=[Knows])
        backend.save_connection("a", "b", Knows(since=2020))
        backend.save_connection("c", "a", Knows(since=2021))

        conns = list(backend.query_connections("a", Knows, direction="both"))
        assert len(conns) == 2

    def test_delete_connection(self, tmp_path) -> None:
        backend = JsonFileBackend(tmp_path / "g.json", types=[Knows])
        backend.save_connection("a", "b", Knows(since=2020))
        backend.delete_connection("a", "b", Knows)

        conns = list(backend.query_connections("a", Knows, direction="outgoing"))
        assert conns == []

    def test_delete_connection_preserves_others(self, tmp_path) -> None:
        backend = JsonFileBackend(tmp_path / "g.json", types=[Knows, WorksAt])
        backend.save_connection("a", "b", Knows(since=2020))
        backend.save_connection("a", "acme", WorksAt(role="Engineer"))
        backend.delete_connection("a", "b", Knows)

        conns = list(backend.query_connections("a", WorksAt, direction="outgoing"))
        assert len(conns) == 1


class TestJsonFileBackendRelations:
    def test_save_and_query(self, tmp_path) -> None:
        backend = JsonFileBackend(tmp_path / "g.json", types=[Meeting])
        backend.save_relation(Meeting(topic="standup"))

        results = list(backend.query_relations(Meeting))
        assert len(results) == 1
        assert results[0].topic == "standup"

    def test_delete_relation(self, tmp_path) -> None:
        backend = JsonFileBackend(tmp_path / "g.json", types=[Meeting])
        m = Meeting(topic="standup")
        backend.save_relation(m)
        backend.delete_relation(m)

        results = list(backend.query_relations(Meeting))
        assert results == []


# --- Graph + JsonFileBackend integration tests ---


class TestGraphJsonFileBackendIntegration:
    def test_full_cycle(self, tmp_path) -> None:
        path = tmp_path / "g.json"
        backend = JsonFileBackend(path, types=[Person, Knows])
        g = Graph(backend=backend)

        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Knows(since=2020))

        # Data persisted to disk — new backend reads it back
        b2 = JsonFileBackend(path, types=[Person, Knows])
        assert b2.get("a", Person) is not None
        assert b2.get("b", Person) is not None
        conns = list(b2.query_connections("a", Knows, direction="outgoing"))
        assert len(conns) == 1

    def test_remove_entity_cleans_file(self, tmp_path) -> None:
        backend = JsonFileBackend(tmp_path / "g.json", types=[Person, Knows])
        g = Graph(backend=backend)
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Knows(since=2020))
        g.remove(alice)

        assert backend.has("a") is False
        conns = list(backend.query_connections("b", Knows, direction="incoming"))
        assert conns == []


class TestJsonFileBackendStress:
    def test_large_graph_persistence(self, tmp_path) -> None:
        path = tmp_path / "large.json"
        backend = JsonFileBackend(path, types=[Person, Knows])
        g = Graph(backend=backend)

        n = 200
        people = [Person(id=f"p{i}", name=f"P{i}", age=i) for i in range(n)]
        for p in people:
            g.add(p)
        for i in range(n - 1):
            g.connect(people[i], people[i + 1], Knows())

        # Verify file has all data
        b2 = JsonFileBackend(path, types=[Person, Knows])
        loaded = list(b2.query(Person))
        assert len(loaded) == n

    def test_save_load_save_cycle_consistency(self, tmp_path) -> None:
        """Write graph, load via new backend, mutate, verify consistency."""
        path = tmp_path / "cycle.json"
        backend = JsonFileBackend(path, types=[Person, Knows])
        g = Graph(backend=backend)

        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Knows(since=2020))

        # Simulate fresh process: new backend from same file
        b2 = JsonFileBackend(path, types=[Person, Knows])
        assert b2.get("a", Person) is not None
        assert b2.get("b", Person) is not None

        # Mutate through the new backend
        carol = Person(id="c", name="Carol", age=28)
        b2.save(carol)

        # Third backend reads the updated file
        b3 = JsonFileBackend(path, types=[Person, Knows])
        assert b3.get("c", Person) is not None
        assert b3.get("a", Person) is not None
