"""Tests for transactions."""

import pytest

from facton import Connection, Entity, Graph


class Person(Entity):
    name: str
    age: int


class Knows(Connection[Person, Person]):
    since: int | None = None


class TestWriteTransaction:
    def test_successful_transaction(self) -> None:
        g = Graph()
        with g.transaction() as tx:
            alice = Person(id="alice", name="Alice", age=30)
            bob = Person(id="bob", name="Bob", age=28)
            tx.add(alice)
            tx.add(bob)
            tx.connect(alice, bob, Knows(since=2019))

        assert g.get(Person, "alice") is not None
        assert g.get(Person, "bob") is not None
        assert len(g.connections_of("alice")) == 1

    def test_failed_transaction_rolls_back(self) -> None:
        g = Graph()
        g.add(Person(id="existing", name="Existing", age=40))

        with pytest.raises(ValueError), g.transaction() as tx:
            tx.add(Person(id="alice", name="Alice", age=30))
            # This should fail and roll back alice too
            tx.add(Person(id="existing", name="Dup", age=25))

        # alice should not exist
        assert g.get(Person, "alice") is None
        # existing should still be there
        assert g.get(Person, "existing") is not None

    def test_transaction_rollback_on_exception(self) -> None:
        g = Graph()
        with pytest.raises(RuntimeError), g.transaction() as tx:
            tx.add(Person(id="alice", name="Alice", age=30))
            raise RuntimeError("oops")

        assert g.get(Person, "alice") is None


class TestReadTransaction:
    def test_read_snapshot_isolation(self) -> None:
        g = Graph()
        g.add(Person(id="alice", name="Alice", age=30))

        with g.read() as snapshot:
            # Mutate the original graph
            g.add(Person(id="bob", name="Bob", age=28))

            # Snapshot should not see bob
            assert snapshot.get(Person, "bob") is None
            assert snapshot.get(Person, "alice") is not None

        # Original graph has both
        assert g.get(Person, "bob") is not None


class TestTransactionIndexConsistency:
    def test_rollback_restores_all_indexes(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        g.add(a)

        original_entities = dict(g._entities)
        original_conn_count = len(g._connections)
        original_type_ids = set(g._by_type.get(Person, set()))

        with pytest.raises(RuntimeError), g.transaction() as tx:
            b = Person(id="b", name="B", age=2)
            tx.add(b)
            tx.connect(a, b, Knows())
            raise RuntimeError("forced rollback")

        assert g._entities == original_entities
        assert len(g._connections) == original_conn_count
        assert g._by_type.get(Person, set()) == original_type_ids
        assert len(g._outgoing.get("a", [])) == 0
        assert len(g._outgoing.get("b", [])) == 0

    def test_rollback_after_remove_restores_entity(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        g.add(a)
        g.add(b)
        g.connect(a, b, Knows())

        with pytest.raises(RuntimeError), g.transaction() as tx:
            tx.remove(a)
            raise RuntimeError("forced rollback")

        assert "a" in g._entities
        assert len(g._connections) == 1
        assert "a" in g._by_type[Person]
        assert len(g._outgoing["a"]) == 1


class TestTransactionEdgeCases:
    def test_read_transaction_isolation(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        g.add(a)

        with g.read() as snap:
            # Mutate the live graph
            g.add(Person(id="b", name="B", age=2))

            # Snapshot should not see b
            assert snap.get(Person, "b") is None
            assert snap.get(Person, "a") is not None

    def test_transaction_commit_on_success(self) -> None:
        g = Graph()
        with g.transaction() as tx:
            tx.add(Person(id="a", name="A", age=1))

        assert g.get(Person, "a") is not None

    def test_partial_rollback(self) -> None:
        """Add succeeds, then connect fails → entire tx rolls back."""
        g = Graph()
        a = Person(id="a", name="A", age=1)
        g.add(a)

        with pytest.raises(ValueError), g.transaction() as tx:
            b = Person(id="b", name="B", age=2)
            tx.add(b)
            # Connect to nonexistent entity
            tx.connect(b, Person(id="zzz", name="Z", age=0), Knows())

        # b should not exist after rollback
        assert g.get(Person, "b") is None
        assert len(g._entities) == 1
