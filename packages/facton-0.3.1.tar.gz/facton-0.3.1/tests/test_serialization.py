"""Tests for graph serialization and deserialization."""

from __future__ import annotations

import json
import tempfile
from datetime import date
from pathlib import Path
from typing import ClassVar

import pytest

from facton import Connection, Entity, Field, Graph, Unique


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Organization(Entity):
    name: str


class Knows(Connection[Person, Person]):
    since: int | None = None


class WorksAt(Connection[Person, Organization]):
    role: str
    started: date


class TestDictRoundtrip:
    def test_to_dict_from_dict_roundtrip(self) -> None:
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        acme = Organization(id="acme", name="Acme")
        g.add(alice)
        g.add(bob)
        g.add(acme)
        g.connect(alice, bob, Knows(since=2020))
        g.connect(alice, acme, WorksAt(role="Eng", started=date(2022, 3, 1)))

        data = g.to_dict()
        assert len(data["entities"]) == 3
        assert len(data["connections"]) == 2

        registry = {
            cls.__qualname__: cls for cls in (Person, Organization, Knows, WorksAt)
        }
        g2 = Graph.from_dict(data, type_registry=registry)

        assert len(g2._entities) == 3
        assert len(g2._connections) == 2
        alice2 = g2.get(Person, "a")
        assert alice2 is not None
        assert alice2.name == "Alice"

    def test_derived_connections_preserved(self) -> None:
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.derive(alice, bob, Knows(since=2021))

        data = g.to_dict()
        assert data["connections"][0]["derived"] is True

        registry = {cls.__qualname__: cls for cls in (Person, Knows)}
        g2 = Graph.from_dict(data, type_registry=registry)
        assert g2._connections[0].derived is True

    def test_to_dict_is_json_serializable(self) -> None:
        g = Graph()
        g.add(Person(id="a", name="Alice", age=30))
        data = g.to_dict()
        # Should not raise
        result = json.dumps(data, default=str)
        assert isinstance(result, str)

    def test_from_dict_without_registry(self) -> None:
        """Loading a graph from JSON with no registry — types rebuilt from schema."""
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        acme = Organization(id="acme", name="Acme")
        g.add(alice)
        g.add(bob)
        g.add(acme)
        g.connect(alice, bob, Knows(since=2020))
        g.connect(alice, acme, WorksAt(role="Eng", started=date(2022, 3, 1)))

        data = g.to_dict()
        raw_json = json.dumps(data, default=str)
        restored = json.loads(raw_json)

        # No registry at all — types should be auto-created from schema
        g2 = Graph.from_dict(restored)

        assert len(g2._entities) == 3
        assert len(g2._connections) == 2
        alice2 = g2.get(Entity, "a")
        assert alice2 is not None
        assert alice2.model_dump()["name"] == "Alice"
        assert alice2.model_dump()["age"] == 30


class TestFileRoundtrip:
    def test_save_load_file_roundtrip(self) -> None:
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Knows(since=2020))

        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name

        try:
            g.save_file(path)

            content = Path(path).read_text()
            data = json.loads(content)
            assert len(data["entities"]) == 2

            registry = {cls.__qualname__: cls for cls in (Person, Knows)}
            g2 = Graph.load_file(path, type_registry=registry)
            assert len(g2._entities) == 2
            assert len(g2._connections) == 1
        finally:
            Path(path).unlink(missing_ok=True)

    def test_save_load_file_without_registry(self) -> None:
        """Full file roundtrip without a type registry."""
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Knows(since=2020))

        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name

        try:
            g.save_file(path)
            g2 = Graph.load_file(path)
            assert len(g2._entities) == 2
            assert len(g2._connections) == 1
        finally:
            Path(path).unlink(missing_ok=True)


class TestSchema:
    def test_schema_embedded_in_to_dict(self) -> None:
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        acme = Organization(id="acme", name="Acme")
        g.add(alice)
        g.add(acme)
        g.connect(alice, acme, WorksAt(role="Eng", started=date(2022, 3, 1)))

        data = g.to_dict()
        schema = data["schema"]
        assert "Person" in schema["entities"]
        assert "Organization" in schema["entities"]
        assert "WorksAt" in schema["connections"]
        assert schema["connections"]["WorksAt"]["source_type"] == "Person"
        assert schema["connections"]["WorksAt"]["target_type"] == "Organization"

    def test_field_constraints_in_schema(self) -> None:
        """Schema includes ge, le, etc. from Field()."""
        g = Graph()
        g.add(Person(id="a", name="Alice", age=30))

        data = g.to_dict()
        age_meta = data["schema"]["entities"]["Person"]["fields"]["age"]
        assert age_meta["type"] == "int"
        assert age_meta["ge"] == 0

    def test_field_constraints_restored_without_registry(self) -> None:
        """Dynamic types rebuilt from schema preserve Field(ge=0) etc."""
        g = Graph()
        g.add(Person(id="a", name="Alice", age=30))

        data = g.to_dict()
        raw = json.dumps(data, default=str)
        restored = json.loads(raw)

        g2 = Graph.from_dict(restored)
        dynamic_cls = type(g2._entities["a"])

        # Should reject age < 0 just like the original
        with pytest.raises(Exception):  # noqa: B017
            dynamic_cls(id="x", name="X", age=-1)

    def test_optional_field_default_preserved(self) -> None:
        """Optional fields with None default survive roundtrip."""
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Knows())  # since=None

        data = g.to_dict()
        since_meta = data["schema"]["connections"]["Knows"]["fields"]["since"]
        assert since_meta["default"] is None

        g2 = Graph.from_dict(data)
        conn = g2._connections[0].connection
        assert conn.model_dump()["since"] is None

    def test_meta_constraints_roundtrip(self) -> None:
        """Unique and Constraint from Meta classes survive roundtrip."""

        class Employee(Entity):
            name: str
            badge: str

            class Meta:
                constraints: ClassVar = [Unique("name", "badge")]

        g = Graph()
        g.add(Employee(id="e1", name="Alice", badge="001"))

        data = g.to_dict()
        # Qualname includes enclosing scopes for nested classes
        emp_qualname = Employee.__qualname__
        schema_entry = data["schema"]["entities"][emp_qualname]
        assert schema_entry["constraints"] == [
            {"kind": "unique", "fields": ["name", "badge"]},
        ]

        # Restore with registry (nested class qualname isn't portable)
        registry = {emp_qualname: Employee}
        Graph.from_dict(data, type_registry=registry)
        meta = getattr(Employee, "Meta", None)
        assert meta is not None
        assert len(meta.constraints) == 1
        assert isinstance(meta.constraints[0], Unique)
        assert meta.constraints[0].fields == ("name", "badge")


class TestAnnotationRoundtrip:
    def test_entity_annotations_roundtrip(self) -> None:
        """Entity-level annotations survive serialization."""
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        alice.annotate(source="hr_system", confidence=0.95)
        g.add(alice)

        data = g.to_dict()
        assert data["entities"][0]["annotations"] == {
            "source": "hr_system",
            "confidence": 0.95,
        }

        g2 = Graph.from_dict(
            data, type_registry={cls.__qualname__: cls for cls in (Person,)}
        )
        alice2 = g2.get(Person, "a")
        assert alice2.entity_annotations == {
            "source": "hr_system",
            "confidence": 0.95,
        }

    def test_fact_annotations_roundtrip(self) -> None:
        """Per-field Fact annotations survive serialization."""
        from facton.fact import Fact

        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        alice.name.annotate(source="document_scan", ocr_confidence=0.87)
        g.add(alice)

        data = g.to_dict()
        assert data["entities"][0]["field_annotations"] == {
            "name": {"source": "document_scan", "ocr_confidence": 0.87},
        }

        g2 = Graph.from_dict(
            data, type_registry={cls.__qualname__: cls for cls in (Person,)}
        )
        alice2 = g2.get(Person, "a")
        assert isinstance(alice2.name, Fact)
        assert alice2.name.annotations == {
            "source": "document_scan",
            "ocr_confidence": 0.87,
        }

    def test_connection_annotations_roundtrip(self) -> None:
        """Connection-level annotations survive serialization."""
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        acme = Organization(id="acme", name="Acme")
        g.add(alice)
        g.add(acme)
        w = WorksAt(role="Eng", started=date(2022, 3, 1))
        w.annotate(verified_by="HR")
        g.connect(alice, acme, w)

        data = g.to_dict()
        assert data["connections"][0]["annotations"] == {
            "verified_by": "HR",
        }

        registry = {cls.__qualname__: cls for cls in (Person, Organization, WorksAt)}
        g2 = Graph.from_dict(data, type_registry=registry)
        conn = g2._connections[0].connection
        assert conn.connection_annotations == {"verified_by": "HR"}


class TestTemporalRoundtrip:
    def test_temporal_change_log_roundtrip(self) -> None:
        """Change log timestamps are preserved through serialization."""
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        g.add(alice)
        alice_v2 = Person(id="a", name="Alice", age=31)
        g.save(alice_v2)

        original_log = [(r.entity_id, r.operation) for r in g._change_log]
        original_timestamps = [r.timestamp for r in g._change_log]

        data = g.to_dict()
        assert "change_log" in data
        assert len(data["change_log"]) == 2

        registry = {cls.__qualname__: cls for cls in (Person,)}
        g2 = Graph.from_dict(data, type_registry=registry)

        restored_log = [(r.entity_id, r.operation) for r in g2._change_log]
        restored_timestamps = [r.timestamp for r in g2._change_log]

        assert restored_log == original_log
        assert restored_timestamps == original_timestamps

    def test_named_snapshots_roundtrip(self) -> None:
        """Named snapshots survive serialization."""
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        g.add(alice)
        g.snapshot("checkpoint1")

        data = g.to_dict()
        assert "snapshots" in data
        assert "checkpoint1" in data["snapshots"]

        registry = {cls.__qualname__: cls for cls in (Person,)}
        g2 = Graph.from_dict(data, type_registry=registry)
        assert "checkpoint1" in g2._snapshots
        assert g2._snapshots["checkpoint1"] == g._snapshots["checkpoint1"]


class TestFullRoundtrip:
    def test_full_lossless_roundtrip(self) -> None:
        """Comprehensive: data + annotations + constraints + temporal."""
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        alice.annotate(source="hr")
        alice.name.annotate(verified=True)
        bob = Person(id="b", name="Bob", age=25)
        acme = Organization(id="acme", name="Acme")
        g.add(alice)
        g.add(bob)
        g.add(acme)

        w = WorksAt(role="Eng", started=date(2022, 3, 1))
        w.annotate(approved=True)
        g.connect(alice, acme, w)
        g.connect(alice, bob, Knows(since=2020))
        g.derive(bob, acme, WorksAt(role="Intern", started=date(2023, 1, 1)))

        g.snapshot("v1")
        alice_v2 = Person(id="a", name="Alice", age=31)
        alice_v2.annotate(source="hr")  # annotations are per-instance
        g.save(alice_v2)

        data = g.to_dict()
        raw = json.dumps(data, default=str)
        restored = json.loads(raw)

        registry = {
            cls.__qualname__: cls for cls in (Person, Organization, Knows, WorksAt)
        }
        g2 = Graph.from_dict(restored, type_registry=registry)

        # Data
        assert len(g2._entities) == 3
        assert len(g2._connections) == 3
        assert g2.get(Person, "a").age == 31

        # Entity annotations
        assert g2.get(Person, "a").entity_annotations == {"source": "hr"}

        # Fact annotations
        # Note: save() replaces the entity, fact annotations from
        # original alice are on the change_log copy, not current
        # entity (which was created by save(alice_v2) with no annots)

        # Connection annotations
        conn = g2._connections[0].connection
        assert conn.connection_annotations == {"approved": True}

        # Derived flag
        assert g2._connections[2].derived is True

        # Temporal
        log_ops = [(r.entity_id, r.operation) for r in g2._change_log]
        assert ("a", "add") in log_ops
        assert ("a", "save") in log_ops

        # Snapshots
        assert "v1" in g2._snapshots


class TestSerializationEdgeCases:
    def test_entities_only_no_connections(self) -> None:
        g = Graph()
        g.add(Person(id="a", name="A", age=1))
        g.add(Organization(id="o", name="O"))

        data = g.to_dict()
        g2 = Graph.from_dict(
            data,
            type_registry={cls.__qualname__: cls for cls in (Person, Organization)},
        )
        assert len(g2._entities) == 2
        assert len(g2._connections) == 0

    def test_non_ascii_field_values(self) -> None:
        g = Graph()
        g.add(Person(id="a", name="日本語テスト 🎉", age=1))

        data = g.to_dict()
        raw = json.dumps(data, default=str, ensure_ascii=False)
        restored = json.loads(raw)

        g2 = Graph.from_dict(
            restored,
            type_registry={
                Person.__qualname__: Person,
            },
        )
        assert g2.get(Entity, "a").model_dump()["name"] == "日本語テスト 🎉"

    def test_indexes_rebuilt_after_from_dict(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        g.add(a)
        g.add(b)
        g.connect(a, b, Knows())

        data = g.to_dict()
        registry = {cls.__qualname__: cls for cls in (Person, Knows)}
        g2 = Graph.from_dict(data, type_registry=registry)

        # Indexes should be rebuilt
        assert "a" in g2._by_type[Person]
        assert len(g2._outgoing.get("a", [])) == 1
        assert len(g2._incoming.get("b", [])) == 1

    def test_to_dict_with_date_fields_json_serializable(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        o = Organization(id="o", name="O")
        g.add(a)
        g.add(o)
        g.connect(a, o, WorksAt(role="Dev", started=date(2022, 6, 15)))

        data = g.to_dict()
        # Must not raise
        raw = json.dumps(data, default=str)
        restored = json.loads(raw)
        assert isinstance(restored, dict)

    def test_empty_graph_roundtrip(self) -> None:
        g = Graph()
        data = g.to_dict()
        assert data["entities"] == []
        assert data["connections"] == []

        g2 = Graph.from_dict(data)
        assert len(g2._entities) == 0
        assert len(g2._connections) == 0
