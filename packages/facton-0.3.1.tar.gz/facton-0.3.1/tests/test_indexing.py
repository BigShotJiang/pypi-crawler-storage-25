"""Tests for adjacency and type index maintenance."""

from __future__ import annotations

from facton import Connection, Entity, Field, Graph


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Organization(Entity):
    name: str


class Knows(Connection[Person, Person]):
    since: int | None = None


class TestAdjacencyIndex:
    def test_outgoing_index_populated_on_connect(self) -> None:
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Knows(since=2020))

        assert len(g._outgoing["a"]) == 1
        assert len(g._incoming["b"]) == 1
        assert g._outgoing["a"][0].target_id == "b"

    def test_indexes_updated_on_disconnect(self) -> None:
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Knows(since=2020))
        g.disconnect(alice, bob, Knows)

        assert len(g._outgoing.get("a", [])) == 0
        assert len(g._incoming.get("b", [])) == 0

    def test_indexes_cleaned_on_remove(self) -> None:
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Knows(since=2020))
        g.remove(alice)

        assert len(g._outgoing.get("a", [])) == 0
        assert len(g._incoming.get("b", [])) == 0
        assert len(g._connections) == 0


class TestTypeIndex:
    def test_type_index_populated_on_add(self) -> None:
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        acme = Organization(id="acme", name="Acme")
        g.add(alice)
        g.add(acme)

        assert "a" in g._by_type[Person]
        assert "acme" in g._by_type[Organization]
        assert "a" not in g._by_type[Organization]

    def test_type_index_includes_base_types(self) -> None:
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        g.add(alice)

        # Person IS-A Entity, so should be in both
        assert "a" in g._by_type[Person]
        assert "a" in g._by_type[Entity]

    def test_type_index_cleaned_on_remove(self) -> None:
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        g.add(alice)
        g.remove(alice)

        assert "a" not in g._by_type.get(Person, set())
        assert "a" not in g._by_type.get(Entity, set())

    def test_query_uses_type_index(self) -> None:
        g = Graph()
        for i in range(100):
            g.add(Person(id=f"p{i}", name=f"Person {i}", age=i))
        g.add(Organization(id="org1", name="Org"))

        people = g.query(Person).all()
        assert len(people) == 100

        orgs = g.query(Organization).all()
        assert len(orgs) == 1


class TestIndexConsistency:
    def test_outgoing_incoming_match_connections_list(self) -> None:
        """All entries in _connections must appear in _outgoing and _incoming."""
        g = Graph()
        people = [Person(id=f"p{i}", name=f"P{i}", age=i) for i in range(10)]
        for p in people:
            g.add(p)
        for i in range(9):
            g.connect(people[i], people[i + 1], Knows())

        # Remove a middle entity
        g.remove(people[5])

        # Verify consistency
        all_outgoing = sum(len(v) for v in g._outgoing.values())
        all_incoming = sum(len(v) for v in g._incoming.values())
        assert all_outgoing == len(g._connections)
        assert all_incoming == len(g._connections)

    def test_by_type_matches_entities(self) -> None:
        g = Graph()
        for i in range(20):
            g.add(Person(id=f"p{i}", name=f"P{i}", age=i))
        for i in range(10):
            g.add(Organization(id=f"o{i}", name=f"Org{i}"))

        # Remove some
        g.remove("p5")
        g.remove("p15")
        g.remove("o3")

        person_ids = g._by_type.get(Person, set())
        for pid in person_ids:
            assert pid in g._entities
        for eid, e in g._entities.items():
            if isinstance(e, Person):
                assert eid in person_ids

    def test_complex_add_remove_connect_disconnect_sequence(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        c = Person(id="c", name="C", age=3)
        g.add(a)
        g.add(b)
        g.add(c)
        g.connect(a, b, Knows())
        g.connect(b, c, Knows())
        g.connect(a, c, Knows())
        g.disconnect(a, b, Knows)
        g.remove(c)
        d = Person(id="d", name="D", age=4)
        g.add(d)
        g.connect(a, d, Knows())

        # Verify
        assert len(g._connections) == 1  # only a→d
        assert len(g._outgoing.get("a", [])) == 1
        assert len(g._incoming.get("d", [])) == 1
        assert len(g._outgoing.get("b", [])) == 0
        assert len(g._incoming.get("c", [])) == 0
        assert "c" not in g._by_type.get(Person, set())
        assert "d" in g._by_type[Person]
