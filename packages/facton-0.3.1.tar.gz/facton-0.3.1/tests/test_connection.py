"""Tests for connection type checking and duplicate guards."""

from __future__ import annotations

from datetime import date
from typing import ClassVar

import pytest

from facton import Connection, Entity, Field, Graph


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Organization(Entity):
    name: str


class Knows(Connection[Person, Person]):
    since: int | None = None


class WorksAt(Connection[Person, Organization]):
    role: str
    started: date


class TestConnectionTypeChecking:
    def test_correct_types_accepted(self) -> None:
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        acme = Organization(id="acme", name="Acme")
        g.add(alice)
        g.add(acme)

        conn = g.connect(alice, acme, WorksAt(role="Eng", started=date(2022, 1, 1)))
        assert conn.role == "Eng"

    def test_wrong_source_type_rejected(self) -> None:
        g = Graph()
        acme = Organization(id="acme", name="Acme")
        bigco = Organization(id="bigco", name="BigCo")
        g.add(acme)
        g.add(bigco)

        with pytest.raises(TypeError, match="expects source type Person"):
            g.connect(acme, bigco, WorksAt(role="Eng", started=date(2022, 1, 1)))

    def test_wrong_target_type_rejected(self) -> None:
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)

        with pytest.raises(TypeError, match="expects target type Organization"):
            g.connect(alice, bob, WorksAt(role="Eng", started=date(2022, 1, 1)))

    def test_subtype_accepted(self) -> None:
        class Employee(Person):
            badge: str = ""

        g = Graph()
        emp = Employee(id="e1", name="Emp", age=28, badge="001")
        acme = Organization(id="acme", name="Acme")
        g.add(emp)
        g.add(acme)

        # Employee IS-A Person, so should be accepted
        conn = g.connect(emp, acme, WorksAt(role="Dev", started=date(2023, 1, 1)))
        assert conn.role == "Dev"


class TestDuplicateConnectionGuard:
    def test_duplicate_allowed_by_default(self) -> None:
        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Knows(since=2020))
        g.connect(alice, bob, Knows(since=2021))

        assert len(g._connections) == 2

    def test_unique_endpoints_rejects_duplicate(self) -> None:
        class Friends(Connection[Person, Person]):
            unique_endpoints: ClassVar[bool] = True

        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Friends())

        with pytest.raises(ValueError, match="Duplicate"):
            g.connect(alice, bob, Friends())

    def test_unique_endpoints_allows_different_pairs(self) -> None:
        class Friends(Connection[Person, Person]):
            unique_endpoints: ClassVar[bool] = True

        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        carol = Person(id="c", name="Carol", age=28)
        g.add(alice)
        g.add(bob)
        g.add(carol)
        g.connect(alice, bob, Friends())
        g.connect(alice, carol, Friends())

        assert len(g._connections) == 2

    def test_unique_endpoints_on_derive(self) -> None:
        class Friends(Connection[Person, Person]):
            unique_endpoints: ClassVar[bool] = True

        g = Graph()
        alice = Person(id="a", name="Alice", age=30)
        bob = Person(id="b", name="Bob", age=25)
        g.add(alice)
        g.add(bob)
        g.connect(alice, bob, Friends())

        with pytest.raises(ValueError, match="Duplicate"):
            g.derive(alice, bob, Friends())
