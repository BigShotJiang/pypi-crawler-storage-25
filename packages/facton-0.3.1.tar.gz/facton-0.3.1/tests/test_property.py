"""Property-based tests using Hypothesis."""

from __future__ import annotations

import contextlib
import json

from hypothesis import given, settings
from hypothesis import strategies as st

from facton import Connection, Entity, Field, Graph


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Knows(Connection[Person, Person]):
    since: int | None = None


# --- Strategies ---

person_id_st = st.text(
    alphabet=st.characters(categories=("L", "N")),
    min_size=1,
    max_size=8,
)

person_st = st.builds(
    Person,
    id=person_id_st,
    name=st.text(min_size=1, max_size=20),
    age=st.integers(min_value=0, max_value=120),
)


# --- Operations for stateful testing ---


class Op:
    pass


class AddOp(Op):
    def __init__(self, person: Person) -> None:
        self.person = person


class RemoveOp(Op):
    def __init__(self, id: str) -> None:
        self.id = id


class ConnectOp(Op):
    def __init__(self, src_id: str, tgt_id: str) -> None:
        self.src_id = src_id
        self.tgt_id = tgt_id


class DisconnectOp(Op):
    def __init__(self, src_id: str, tgt_id: str) -> None:
        self.src_id = src_id
        self.tgt_id = tgt_id


def _verify_index_consistency(g: Graph) -> None:
    """Assert all indexes are consistent with the primary data structures."""
    # _by_type should match _entities
    for eid, entity in g._entities.items():
        for cls in type(entity).__mro__:
            if cls is Entity or issubclass(cls, Entity):
                assert eid in g._by_type.get(cls, set()), (
                    f"{eid} missing from _by_type[{cls.__name__}]"
                )

    for cls, ids in g._by_type.items():
        for eid in ids:
            assert eid in g._entities, (
                f"_by_type[{cls.__name__}] contains stale id {eid!r}"
            )

    # _outgoing/_incoming should match _connections
    outgoing_count = sum(len(v) for v in g._outgoing.values())
    incoming_count = sum(len(v) for v in g._incoming.values())
    assert outgoing_count == len(g._connections), (
        f"outgoing count {outgoing_count} != connections {len(g._connections)}"
    )
    assert incoming_count == len(g._connections), (
        f"incoming count {incoming_count} != connections {len(g._connections)}"
    )

    for stored in g._connections:
        assert stored in g._outgoing.get(stored.source_id, []), (
            f"connection {stored.source_id}→{stored.target_id} not in _outgoing"
        )
        assert stored in g._incoming.get(stored.target_id, []), (
            f"connection {stored.source_id}→{stored.target_id} not in _incoming"
        )


class TestPropertyIndexConsistency:
    @given(
        people=st.lists(person_st, min_size=1, max_size=30),
        removals=st.lists(st.integers(min_value=0, max_value=29), max_size=10),
    )
    @settings(max_examples=50)
    def test_random_add_remove_keeps_indexes_consistent(
        self,
        people: list[Person],
        removals: list[int],
    ) -> None:
        g = Graph()

        # Deduplicate by id
        seen: set[str] = set()
        added_ids: list[str] = []
        for p in people:
            if p.id not in seen:
                seen.add(p.id)
                g.add(p)
                added_ids.append(p.id)

        # Remove some
        for idx in removals:
            if idx < len(added_ids):
                eid = added_ids[idx]
                if eid in g._entities:
                    g.remove(eid)

        _verify_index_consistency(g)

    @given(
        n_people=st.integers(min_value=2, max_value=20),
        connections=st.lists(
            st.tuples(
                st.integers(min_value=0, max_value=19),
                st.integers(min_value=0, max_value=19),
            ),
            max_size=30,
        ),
        disconnections=st.lists(
            st.tuples(
                st.integers(min_value=0, max_value=19),
                st.integers(min_value=0, max_value=19),
            ),
            max_size=10,
        ),
    )
    @settings(max_examples=50)
    def test_random_connect_disconnect_keeps_indexes_consistent(
        self,
        n_people: int,
        connections: list[tuple[int, int]],
        disconnections: list[tuple[int, int]],
    ) -> None:
        g = Graph()
        people = [Person(id=f"p{i}", name=f"P{i}", age=i) for i in range(n_people)]
        for p in people:
            g.add(p)

        for src_idx, tgt_idx in connections:
            src = src_idx % n_people
            tgt = tgt_idx % n_people
            if src != tgt:
                with contextlib.suppress(ValueError, TypeError):
                    g.connect(people[src], people[tgt], Knows())

        for src_idx, tgt_idx in disconnections:
            src = src_idx % n_people
            tgt = tgt_idx % n_people
            if src != tgt:
                g.disconnect(people[src], people[tgt], Knows)

        _verify_index_consistency(g)


class TestPropertySerializationRoundtrip:
    @given(
        people=st.lists(person_st, min_size=0, max_size=20),
    )
    @settings(max_examples=30)
    def test_serialization_roundtrip_lossless(
        self,
        people: list[Person],
    ) -> None:
        g = Graph()
        seen: set[str] = set()
        for p in people:
            if p.id not in seen:
                seen.add(p.id)
                g.add(p)

        data = g.to_dict()
        raw = json.dumps(data, default=str)
        restored = json.loads(raw)

        registry = {Person.__qualname__: Person, Knows.__qualname__: Knows}
        g2 = Graph.from_dict(restored, type_registry=registry)

        assert len(g2._entities) == len(g._entities)
        for eid in g._entities:
            original = g._entities[eid]
            loaded = g2._entities.get(eid)
            assert loaded is not None, f"Entity {eid!r} lost in roundtrip"
            assert loaded.model_dump() == original.model_dump()
