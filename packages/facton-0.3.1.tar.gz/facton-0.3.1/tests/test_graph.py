"""Tests for graph operations on empty, self-loop, and remove/re-add scenarios."""

from __future__ import annotations

import pytest

from facton import Connection, Entity, Field, Graph


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Organization(Entity):
    name: str


class Knows(Connection[Person, Person]):
    since: int | None = None


class TestEmptyGraph:
    def test_query_empty_graph(self) -> None:
        g = Graph()
        assert g.query(Person).all() == []
        assert g.query(Person).count() == 0
        assert g.query(Person).first() is None

    def test_to_dict_empty_graph(self) -> None:
        g = Graph()
        data = g.to_dict()
        assert data["entities"] == []
        assert data["connections"] == []

    def test_traverse_empty_graph(self) -> None:
        g = Graph()
        # Start entity not in graph — traverse should return empty
        result = g.traverse("nonexistent", Knows, depth=3)
        assert result == []


class TestSelfLoops:
    def test_connect_self_loop(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        g.add(a)
        conn = g.connect(a, a, Knows(since=2020))
        assert conn.since == 2020
        assert len(g._connections) == 1

    def test_self_loop_index_consistency(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        g.add(a)
        g.connect(a, a, Knows())

        assert len(g._outgoing["a"]) == 1
        assert len(g._incoming["a"]) == 1

    def test_traverse_with_self_loop_no_infinite_loop(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        g.add(a)
        g.add(b)
        g.connect(a, a, Knows())
        g.connect(a, b, Knows())

        result = g.traverse(a, Knows, depth=3)
        assert len(result) == 1  # only b reachable
        assert result[0].id == "b"

    def test_shortest_path_through_self_loop(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        g.add(a)
        g.add(b)
        g.connect(a, a, Knows())
        g.connect(a, b, Knows())

        path = g.shortest_path(a, b, Knows)
        assert path is not None
        assert [e.id for e in path] == ["a", "b"]

    def test_components_with_self_loop(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        g.add(a)
        g.connect(a, a, Knows())

        comps = g.components(Knows)
        assert len(comps) == 1
        assert comps[0] == {"a"}

    def test_disconnect_self_loop(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        g.add(a)
        g.connect(a, a, Knows())
        g.disconnect(a, a, Knows)

        assert len(g._connections) == 0
        assert len(g._outgoing.get("a", [])) == 0
        assert len(g._incoming.get("a", [])) == 0

    def test_remove_entity_with_self_loop(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        g.add(a)
        g.connect(a, a, Knows())
        g.remove(a)

        assert len(g._entities) == 0
        assert len(g._connections) == 0


class TestDoubleRemoveAndStaleOps:
    def test_double_remove_raises(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        g.add(a)
        g.remove(a)

        with pytest.raises(ValueError, match="not found"):
            g.remove(a)

    def test_save_after_remove_raises(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        g.add(a)
        g.remove(a)

        with pytest.raises(ValueError, match="not found"):
            g.save(a)

    def test_connect_after_source_removed_raises(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        g.add(a)
        g.add(b)
        g.remove(a)

        with pytest.raises(ValueError, match="not found"):
            g.connect(a, b, Knows())

    def test_connect_after_target_removed_raises(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        g.add(a)
        g.add(b)
        g.remove(b)

        with pytest.raises(ValueError, match="not found"):
            g.connect(a, b, Knows())

    def test_get_after_remove_returns_none(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        g.add(a)
        g.remove(a)
        assert g.get(Person, "a") is None


class TestRemoveAndReAdd:
    def test_readd_same_id(self) -> None:
        g = Graph()
        a = Person(id="a", name="Alice", age=30)
        g.add(a)
        g.remove(a)

        a2 = Person(id="a", name="Alice v2", age=31)
        g.add(a2)
        assert g.get(Person, "a").name == "Alice v2"

    def test_readd_indexes_correct(self) -> None:
        g = Graph()
        a = Person(id="a", name="Alice", age=30)
        g.add(a)
        g.remove(a)
        a2 = Person(id="a", name="Alice v2", age=31)
        g.add(a2)

        assert "a" in g._by_type[Person]
        assert "a" in g._by_type[Entity]
        assert g.query(Person).count() == 1

    def test_readd_connections_independent(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        g.add(a)
        g.add(b)
        g.connect(a, b, Knows(since=2020))
        g.remove(a)

        a2 = Person(id="a", name="A v2", age=3)
        g.add(a2)
        # Old connection should be gone
        assert len(g.connections_of(a2)) == 0
        assert len(g._outgoing.get("a", [])) == 0
