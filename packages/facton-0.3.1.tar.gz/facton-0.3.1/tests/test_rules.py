"""Tests for the rule system."""

from __future__ import annotations

from typing import Any

from facton import Connection, Entity, Field, Graph, rule


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Knows(Connection[Person, Person]):
    since: int | None = None


class TestRuleSystem:
    def test_decorated_rule_fires(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        g.add(a)
        g.add(b)

        @rule
        def everyone_knows_everyone(graph: Graph) -> None:
            people = graph.query(Person).all()
            for p1 in people:
                for p2 in people:
                    if p1.id != p2.id:
                        existing = [
                            c
                            for c in graph._outgoing.get(p1.id, [])
                            if isinstance(c.connection, Knows) and c.target_id == p2.id
                        ]
                        if not existing:
                            graph.derive(p1, p2, Knows())

        g.register_rule(everyone_knows_everyone)
        g.run_rules()

        # a→b and b→a should be derived
        assert len(g._connections) == 2

    def test_declarative_rule_fires(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        c = Person(id="c", name="C", age=3)
        g.add(a)
        g.add(b)
        g.add(c)
        g.connect(a, b, Knows())
        g.connect(b, c, Knows())

        # Rule: if a knows b and b knows c, then a knows c (transitivity)
        def find_transitive(graph: Graph) -> list[Any]:
            results = []
            for stored_ab in graph._connections:
                if not isinstance(stored_ab.connection, Knows):
                    continue
                for stored_bc in graph._outgoing.get(stored_ab.target_id, []):
                    if not isinstance(stored_bc.connection, Knows):
                        continue
                    if stored_ab.source_id != stored_bc.target_id:
                        # Check not already connected
                        existing = [
                            c
                            for c in graph._outgoing.get(stored_ab.source_id, [])
                            if isinstance(c.connection, Knows)
                            and c.target_id == stored_bc.target_id
                        ]
                        if not existing:
                            results.append((stored_ab.source_id, stored_bc.target_id))
            return results

        def derive_knows(match: tuple[str, str]) -> tuple[str, str, Knows]:
            return (match[0], match[1], Knows())

        g.add_rule("transitivity", when=find_transitive, then=derive_knows)
        g.run_rules()

        # a→c should now exist as derived
        assert len(g._connections) == 3
        derived = [c for c in g._connections if c.derived]
        assert len(derived) == 1
        assert derived[0].source_id == "a"
        assert derived[0].target_id == "c"

    def test_rule_derives_tagged_as_derived(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        g.add(a)
        g.add(b)

        @rule
        def make_conn(graph: Graph) -> None:
            graph.derive(a, b, Knows(since=2024))

        g.register_rule(make_conn)
        g.run_rules()

        assert g._connections[0].derived is True

    def test_run_rules_twice_is_idempotent(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        g.add(a)
        g.add(b)

        @rule
        def link_all(graph: Graph) -> None:
            people = graph.query(Person).all()
            for p1 in people:
                for p2 in people:
                    if p1.id != p2.id:
                        existing = [
                            c
                            for c in graph._outgoing.get(p1.id, [])
                            if isinstance(c.connection, Knows) and c.target_id == p2.id
                        ]
                        if not existing:
                            graph.derive(p1, p2, Knows())

        g.register_rule(link_all)
        g.run_rules()
        count_after_first = len(g._connections)

        g.run_rules()
        count_after_second = len(g._connections)

        assert count_after_first == 2
        assert count_after_second == 2

    def test_cascading_rules(self) -> None:
        """Rule output feeds into a second rule on the next run."""
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        c = Person(id="c", name="C", age=3)
        g.add(a)
        g.add(b)
        g.add(c)
        g.connect(a, b, Knows())

        @rule
        def transitive_knows(graph: Graph) -> None:
            for stored_ab in list(graph._connections):
                if not isinstance(stored_ab.connection, Knows):
                    continue
                for stored_bc in list(graph._outgoing.get(stored_ab.target_id, [])):
                    if not isinstance(stored_bc.connection, Knows):
                        continue
                    if stored_ab.source_id == stored_bc.target_id:
                        continue
                    existing = [
                        c
                        for c in graph._outgoing.get(stored_ab.source_id, [])
                        if isinstance(c.connection, Knows)
                        and c.target_id == stored_bc.target_id
                    ]
                    if not existing:
                        graph.derive(stored_ab.source_id, stored_bc.target_id, Knows())

        g.register_rule(transitive_knows)

        # First run: a→b exists, b→c doesn't yet → nothing derived
        g.run_rules()
        assert len(g._connections) == 1

        # Now add b→c and run again
        g.connect(b, c, Knows())
        g.run_rules()
        # a→b, b→c existed → a→c derived
        assert len(g._connections) == 3
        derived = [c for c in g._connections if c.derived]
        assert len(derived) == 1
        assert derived[0].source_id == "a"
        assert derived[0].target_id == "c"

    def test_conflicting_rules_both_fire(self) -> None:
        """Two rules deriving different connections both produce output."""
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        g.add(a)
        g.add(b)

        @rule
        def rule_forward(graph: Graph) -> None:
            if not graph._outgoing.get("a"):
                graph.derive(a, b, Knows(since=1))

        @rule
        def rule_reverse(graph: Graph) -> None:
            if not graph._outgoing.get("b"):
                graph.derive(b, a, Knows(since=2))

        g.register_rule(rule_forward)
        g.register_rule(rule_reverse)
        g.run_rules()

        assert len(g._connections) == 2
        source_ids = {c.source_id for c in g._connections}
        assert source_ids == {"a", "b"}
