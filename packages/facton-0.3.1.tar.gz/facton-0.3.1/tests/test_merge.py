"""Tests for graph merging."""

from facton import Connection, Entity, Graph, Mapping, merge


class PersonA(Entity):
    name: str
    mrn: str
    email: str | None = None


class SubjectB(Entity):
    name: str
    patient_id: str
    phone: str | None = None


class KnowsA(Connection[PersonA, PersonA]):
    since: int | None = None


class TestMergeSimple:
    def test_merge_no_overlap(self) -> None:
        g_a = Graph()
        g_a.add(PersonA(id="alice", name="Alice", mrn="MRN001"))

        g_b = Graph()
        g_b.add(PersonA(id="bob", name="Bob", mrn="MRN002"))

        merged = merge(g_a, g_b)
        assert merged.get(PersonA, "alice") is not None
        assert merged.get(PersonA, "bob") is not None

    def test_merge_id_collision_prefixed(self) -> None:
        g_a = Graph()
        g_a.add(PersonA(id="p1", name="Alice", mrn="MRN001"))

        g_b = Graph()
        g_b.add(PersonA(id="p1", name="Bob", mrn="MRN002"))

        merged = merge(g_a, g_b)
        assert merged.get(PersonA, "p1") is not None
        assert merged.get(PersonA, "p1").name == "Alice"
        assert merged.get(PersonA, "b:p1") is not None
        assert merged.get(PersonA, "b:p1").name == "Bob"


class TestMergeWithMapping:
    def test_type_and_identity_mapping(self) -> None:
        g_a = Graph()
        g_a.add(PersonA(id="alice", name="Alice", mrn="MRN001"))

        g_b = Graph()
        g_b.add(SubjectB(id="s1", name="Alice B", patient_id="MRN001"))

        mapping = Mapping(
            types={PersonA: SubjectB},
            match_on={PersonA: ("mrn", "patient_id")},
        )

        merged = merge(g_a, g_b, mapping)
        # Should match on MRN001 == patient_id, so only one entity
        alice = merged.get(PersonA, "alice")
        assert alice is not None
        assert alice.name == "Alice"

    def test_no_match_adds_separately(self) -> None:
        g_a = Graph()
        g_a.add(PersonA(id="alice", name="Alice", mrn="MRN001"))

        g_b = Graph()
        g_b.add(SubjectB(id="s1", name="Bob", patient_id="MRN999"))

        mapping = Mapping(
            types={PersonA: SubjectB},
            match_on={PersonA: ("mrn", "patient_id")},
        )

        merged = merge(g_a, g_b, mapping)
        # No match, both should exist
        assert merged.get(PersonA, "alice") is not None
        assert merged.get(SubjectB, "s1") is not None

    def test_provenance_annotations(self) -> None:
        g_a = Graph()
        g_a.add(PersonA(id="alice", name="Alice", mrn="MRN001"))

        g_b = Graph()
        g_b.add(PersonA(id="bob", name="Bob", mrn="MRN002"))

        merged = merge(g_a, g_b)
        alice = merged.get(PersonA, "alice")
        bob = merged.get(PersonA, "bob")
        assert alice.entity_annotations["_source_graph"] == "a"
        assert bob.entity_annotations["_source_graph"] == "b"


class TestMergeEdgeCases:
    def test_merge_two_empty_graphs(self) -> None:
        merged = merge(Graph(), Graph())
        assert len(merged._entities) == 0
        assert len(merged._connections) == 0

    def test_merge_empty_into_populated(self) -> None:
        g_a = Graph()
        g_a.add(PersonA(id="a", name="A", mrn="1"))
        merged = merge(g_a, Graph())
        assert len(merged._entities) == 1

    def test_merge_populated_into_empty(self) -> None:
        g_b = Graph()
        g_b.add(PersonA(id="b", name="B", mrn="2"))
        merged = merge(Graph(), g_b)
        assert len(merged._entities) == 1

    def test_merge_with_connections(self) -> None:
        g_a = Graph()
        a1 = PersonA(id="a1", name="A1", mrn="1")
        a2 = PersonA(id="a2", name="A2", mrn="2")
        g_a.add(a1)
        g_a.add(a2)
        g_a.connect(a1, a2, KnowsA(since=2020))

        g_b = Graph()
        b1 = PersonA(id="b1", name="B1", mrn="3")
        g_b.add(b1)

        merged = merge(g_a, g_b)
        assert len(merged._entities) == 3
        assert len(merged._connections) == 1

    def test_merge_overlapping_connections(self) -> None:
        """Both graphs have connections — both sets are preserved."""
        g_a = Graph()
        a1 = PersonA(id="a1", name="A1", mrn="1")
        a2 = PersonA(id="a2", name="A2", mrn="2")
        g_a.add(a1)
        g_a.add(a2)
        g_a.connect(a1, a2, KnowsA(since=2020))

        g_b = Graph()
        b1 = PersonA(id="b1", name="B1", mrn="3")
        b2 = PersonA(id="b2", name="B2", mrn="4")
        g_b.add(b1)
        g_b.add(b2)
        g_b.connect(b1, b2, KnowsA(since=2021))

        merged = merge(g_a, g_b)
        assert len(merged._entities) == 4
        assert len(merged._connections) == 2

    def test_merge_graph_with_cycle(self) -> None:
        g_a = Graph()
        a1 = PersonA(id="a1", name="A1", mrn="1")
        a2 = PersonA(id="a2", name="A2", mrn="2")
        g_a.add(a1)
        g_a.add(a2)
        g_a.connect(a1, a2, KnowsA())
        g_a.connect(a2, a1, KnowsA())  # cycle

        merged = merge(g_a, Graph())
        assert len(merged._entities) == 2
        assert len(merged._connections) == 2
