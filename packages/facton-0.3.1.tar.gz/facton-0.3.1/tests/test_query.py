"""Tests for the query builder and traversal API."""

from datetime import date

from facton import Connection, Entity, Field, Graph, count


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Organization(Entity):
    name: str
    industry: str | None = None


class Knows(Connection[Person, Person]):
    since: int | None = None


class WorksAt(Connection[Person, Organization]):
    role: str
    started: date


class TestQueryBuilder:
    def test_where_filter(self) -> None:
        g = Graph()
        g.add(Person(id="alice", name="Alice", age=30))
        g.add(Person(id="bob", name="Bob", age=22))
        g.add(Person(id="carol", name="Carol", age=35))

        results = g.query(Person).where(lambda p: p.age > 25).all()
        assert len(results) == 2
        names = {r.name for r in results}
        assert names == {"Alice", "Carol"}

    def test_chained_where(self) -> None:
        g = Graph()
        g.add(Person(id="alice", name="Alice", age=30))
        g.add(Person(id="bob", name="Bob", age=22))
        g.add(Person(id="carol", name="Carol", age=35))

        results = (
            g.query(Person)
            .where(lambda p: p.age > 25)
            .where(lambda p: p.name.startswith("A"))
            .all()
        )
        assert len(results) == 1
        assert results[0].name == "Alice"

    def test_connected_to(self) -> None:
        g = Graph()
        alice = Person(id="alice", name="Alice", age=30)
        acme = Organization(id="acme", name="Acme Corp", industry="tech")
        g.add(alice)
        g.add(Person(id="bob", name="Bob", age=28))
        g.add(acme)
        g.connect(alice, acme, WorksAt(role="Engineer", started=date(2022, 3, 15)))

        results = (
            g.query(Person).connected_to(Organization, via=WorksAt, bind="job").all()
        )
        assert len(results) == 1
        assert results[0].person.name == "Alice"
        row = results[0]
        assert row._data["job.target"].name == "Acme Corp"
        assert row._data["job.role"] == "Engineer"

    def test_count(self) -> None:
        g = Graph()
        g.add(Person(id="alice", name="Alice", age=30))
        g.add(Person(id="bob", name="Bob", age=28))

        assert g.query(Person).count() == 2
        assert g.query(Person).where(lambda p: p.age > 29).count() == 1

    def test_first(self) -> None:
        g = Graph()
        g.add(Person(id="alice", name="Alice", age=30))

        result = g.query(Person).first()
        assert result is not None
        assert result.name == "Alice"

    def test_first_empty(self) -> None:
        g = Graph()
        assert g.query(Person).first() is None

    def test_iter(self) -> None:
        g = Graph()
        g.add(Person(id="alice", name="Alice", age=30))
        g.add(Person(id="bob", name="Bob", age=28))

        names = {p.name for p in g.query(Person)}
        assert names == {"Alice", "Bob"}

    def test_len(self) -> None:
        g = Graph()
        g.add(Person(id="alice", name="Alice", age=30))
        assert len(g.query(Person)) == 1


class TestTraversal:
    def _build_social_graph(self) -> tuple[Graph, Person, Person, Person, Person]:
        g = Graph()
        alice = Person(id="alice", name="Alice", age=30)
        bob = Person(id="bob", name="Bob", age=28)
        carol = Person(id="carol", name="Carol", age=35)
        dave = Person(id="dave", name="Dave", age=40)
        for p in (alice, bob, carol, dave):
            g.add(p)
        g.connect(alice, bob, Knows(since=2019))
        g.connect(bob, carol, Knows(since=2020))
        g.connect(carol, dave, Knows(since=2021))
        return g, alice, bob, carol, dave

    def test_traverse_depth_1(self) -> None:
        g, alice, _bob, *_ = self._build_social_graph()
        result = g.traverse(alice, Knows, depth=1)
        assert len(result) == 1
        assert result[0].id == "bob"

    def test_traverse_depth_2(self) -> None:
        g, alice, *_ = self._build_social_graph()
        result = g.traverse(alice, Knows, depth=2)
        ids = {e.id for e in result}
        assert ids == {"bob", "carol"}

    def test_traverse_depth_range(self) -> None:
        g, alice, *_ = self._build_social_graph()
        # Only hops 2-3 (carol and dave, not bob)
        result = g.traverse(alice, Knows, depth=(2, 3))
        ids = {e.id for e in result}
        assert ids == {"carol", "dave"}

    def test_traverse_exact_depth_only(self) -> None:
        g, alice, *_ = self._build_social_graph()
        # Exact depth=2 should return only carol
        result = g.traverse(alice, Knows, depth=(2, 2))
        ids = {e.id for e in result}
        assert ids == {"carol"}

    def test_traverse_by_id(self) -> None:
        g, *_ = self._build_social_graph()
        result = g.traverse("alice", Knows, depth=1)
        assert len(result) == 1
        assert result[0].id == "bob"

    def test_traverse_no_connections(self) -> None:
        g = Graph()
        alice = Person(id="alice", name="Alice", age=30)
        g.add(alice)
        result = g.traverse(alice, Knows, depth=1)
        assert result == []


class TestAggregation:
    def test_group_by_and_count(self) -> None:
        g = Graph()
        g.add(Person(id="a", name="Alice", age=30))
        g.add(Person(id="b", name="Bob", age=30))
        g.add(Person(id="c", name="Carol", age=25))

        results = (
            g.query(Person)
            .group_by(lambda p: int(p.age))
            .aggregate(count)
            .order_by("value", descending=True)
            .all()
        )

        assert len(results) == 2
        assert results[0].key == 30
        assert results[0].value == 2
        assert results[1].key == 25
        assert results[1].value == 1

    def test_group_by_iter(self) -> None:
        g = Graph()
        g.add(Person(id="a", name="Alice", age=30))
        g.add(Person(id="b", name="Bob", age=25))

        agg = g.query(Person).group_by(lambda p: int(p.age)).aggregate(count)
        assert len(agg) == 2
        keys = {row.key for row in agg}
        assert keys == {25, 30}


class TestTraversalEdgeCases:
    def test_traverse_depth_range(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        b = Person(id="b", name="B", age=2)
        c = Person(id="c", name="C", age=3)
        d = Person(id="d", name="D", age=4)
        for e in (a, b, c, d):
            g.add(e)
        g.connect(a, b, Knows())
        g.connect(b, c, Knows())
        g.connect(c, d, Knows())

        # Only depth 2-3 (skip immediate neighbor)
        result = g.traverse(a, Knows, depth=(2, 3))
        result_ids = {e.id for e in result}
        assert "b" not in result_ids  # depth 1
        assert "c" in result_ids  # depth 2
        assert "d" in result_ids  # depth 3

    def test_traverse_no_neighbors(self) -> None:
        g = Graph()
        a = Person(id="a", name="A", age=1)
        g.add(a)
        result = g.traverse(a, Knows, depth=5)
        assert result == []
