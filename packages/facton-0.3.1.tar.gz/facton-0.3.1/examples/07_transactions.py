"""Transactions — atomic writes and read snapshots.

Run: uv run python examples/07_transactions.py
"""

from facton import Connection, Entity, Graph


class Person(Entity):
    name: str
    age: int


class Knows(Connection[Person, Person]):
    pass


g = Graph()

# ── Atomic commit ──
with g.transaction() as tx:
    alice = Person(id="alice", name="Alice", age=30)
    bob = Person(id="bob", name="Bob", age=28)
    tx.add(alice)
    tx.add(bob)
    tx.connect(alice, bob, Knows())

print(f"After commit: {g.query(Person).count()} people")

# ── Rollback on error ──
try:
    with g.transaction() as tx:
        tx.add(Person(id="carol", name="Carol", age=35))
        raise RuntimeError("oops")
except RuntimeError:
    pass

print(f"After rollback: {g.query(Person).count()} people (Carol not added)")

# ── Read snapshot — isolated from concurrent writes ──
with g.read() as snapshot:
    g.add(Person(id="dave", name="Dave", age=40))
    print(f"Snapshot sees: {snapshot.query(Person).count()}")
    print(f"Live graph has: {g.query(Person).count()}")
