"""Inference rules — derive new facts from existing ones.

Run: uv run python examples/10_rules.py
"""

from facton import Connection, Entity, Graph, rule


class Person(Entity):
    name: str


class Knows(Connection[Person, Person]):
    pass


class Reachable(Connection[Person, Person]):
    hops: int = 0


g = Graph()
x = Person(id="x", name="Xena")
y = Person(id="y", name="Yara")
z = Person(id="z", name="Zara")
g.add(x)
g.add(y)
g.add(z)

g.connect(x, y, Knows())
g.connect(y, z, Knows())


@rule
def transitive_reach(graph: Graph) -> None:
    """If X knows Y and Y knows Z, derive X→Z reachable."""
    for person in graph.query(Person):
        for target in graph.traverse(person, Knows, depth=(2, 2)):
            graph.derive(person, target, Reachable(hops=2))


g.register_rule(transitive_reach)
g.run_rules()

print("Derived connections:")
for c in g._connections:
    if c.derived:
        print(f"  {c.source_id} → {c.target_id} (hops={c.connection.hops})")
