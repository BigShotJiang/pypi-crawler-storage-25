"""Basic entities, connections, and CRUD.

Run: uv run python examples/01_basics.py
"""

from datetime import date

from facton import Connection, Entity, Field, Graph


class Person(Entity):
    name: str
    age: int = Field(ge=0)
    email: str | None = None


class Organization(Entity):
    name: str
    industry: str | None = None


class Knows(Connection[Person, Person]):
    since: int | None = None


class WorksAt(Connection[Person, Organization]):
    role: str
    started: date


g = Graph()

alice = Person(id="alice", name="Alice", age=30, email="alice@example.com")
bob = Person(id="bob", name="Bob", age=28)
acme = Organization(id="acme", name="Acme Corp", industry="tech")

g.add(alice)
g.add(bob)
g.add(acme)

g.connect(alice, bob, Knows(since=2019))
g.connect(alice, acme, WorksAt(role="Engineer", started=date(2022, 3, 15)))

# Retrieve
print(g.get(Person, "alice").name)  # Alice

# Update
alice.age = 31
g.save(alice)
print(f"Updated age: {g.get(Person, 'alice').age}")  # 31

# Query
people = g.query(Person).all()
print(f"People: {[p.name for p in people]}")  # ['Alice', 'Bob']

# Remove
g.remove(bob)
print(f"After removing Bob: {g.query(Person).count()}")  # 1
