"""Query builder — filters, joins, and iteration.

Run: uv run python examples/03_queries.py
"""

from datetime import date

from facton import Connection, Entity, Field, Graph


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Organization(Entity):
    name: str


class WorksAt(Connection[Person, Organization]):
    role: str
    started: date


g = Graph()
alice = Person(id="alice", name="Alice", age=30)
bob = Person(id="bob", name="Bob", age=22)
carol = Person(id="carol", name="Carol", age=35)
acme = Organization(id="acme", name="Acme Corp")

for e in (alice, bob, carol, acme):
    g.add(e)

g.connect(alice, acme, WorksAt(role="Engineer", started=date(2022, 3, 15)))
g.connect(carol, acme, WorksAt(role="Manager", started=date(2020, 1, 1)))

# Filter with .where()
seniors = g.query(Person).where(lambda p: p.age >= 30).all()
print(f"Age >= 30: {[p.name for p in seniors]}")

# Chain multiple filters
result = (
    g.query(Person)
    .where(lambda p: p.age >= 25)
    .where(lambda p: p.name.startswith("A"))
    .first()
)
print(f"Matched: {result.name}")

# Join through connections
rows = g.query(Person).connected_to(Organization, via=WorksAt, bind="job").all()
for row in rows:
    target = row._data["job.target"]
    role = row._data["job.role"]
    print(f"  {row.person.name} → {target.name} as {role}")

# Convenience methods
print(f"Total people: {g.query(Person).count()}")
print(f"First person: {g.query(Person).first().name}")

# Iterate directly
for person in g.query(Person).where(lambda p: p.age < 30):
    print(f"  Under 30: {person.name}")
