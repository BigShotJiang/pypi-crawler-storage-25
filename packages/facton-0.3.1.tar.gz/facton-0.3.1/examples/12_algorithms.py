"""Graph algorithms — shortest path and connected components.

Run: uv run python examples/12_algorithms.py
"""

from facton import Connection, Entity, Graph


class City(Entity):
    name: str


class Road(Connection[City, City]):
    distance_km: int = 0


# Build a road network
g = Graph()
cities = {}
for name in ("Berlin", "Munich", "Hamburg", "Frankfurt", "Cologne", "Stuttgart"):
    city = City(id=name.lower(), name=name)
    g.add(city)
    cities[name] = city

roads = [
    ("Berlin", "Hamburg", 290),
    ("Berlin", "Munich", 585),
    ("Hamburg", "Cologne", 430),
    ("Cologne", "Frankfurt", 190),
    ("Frankfurt", "Stuttgart", 210),
    ("Stuttgart", "Munich", 230),
]
for src, tgt, km in roads:
    g.connect(cities[src], cities[tgt], Road(distance_km=km))

# --- Shortest path ---
path = g.shortest_path(cities["Berlin"], cities["Stuttgart"], Road)
if path:
    names = [c.name for c in path]
    print(f"Berlin → Stuttgart: {' → '.join(names)} ({len(path) - 1} hops)")

path2 = g.shortest_path(cities["Hamburg"], cities["Munich"], Road)
if path2:
    names = [c.name for c in path2]
    print(f"Hamburg → Munich:   {' → '.join(names)} ({len(path2) - 1} hops)")

# --- Connected components ---
comps = g.components(Road)
print(f"\nComponents via Road: {len(comps)}")
for i, comp in enumerate(comps, 1):
    city_names = sorted(g.get(City, cid).name for cid in comp)
    print(f"  Component {i}: {', '.join(city_names)}")

# Add an isolated city to show multiple components
g.add(City(id="vienna", name="Vienna"))
comps = g.components(Road)
print(f"\nAfter adding Vienna (no roads): {len(comps)} components")
