"""Serialization — lossless save and load of graphs to JSON.

The graph embeds its own schema (types, field constraints) and
preserves annotations, temporal history, and named snapshots.
Hand someone the JSON file — they can load it with zero imports.

Run: uv run python examples/11_serialization.py
"""

import json
from datetime import date
from pathlib import Path

from facton import Connection, Entity, Field, Graph

OUTPUT_DIR = Path(__file__).parent / "output"


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Organization(Entity):
    name: str


class WorksAt(Connection[Person, Organization]):
    role: str
    started: date


# Build a graph with annotations
g = Graph()
alice = Person(id="alice", name="Alice", age=30)
alice.annotate(source="hr_system")
alice.name.annotate(verified=True)

bob = Person(id="bob", name="Bob", age=25)
acme = Organization(id="acme", name="Acme Corp")

for e in (alice, bob, acme):
    g.add(e)

w = WorksAt(role="Engineer", started=date(2022, 3, 15))
w.annotate(approved_by="HR")
g.connect(alice, acme, w)
g.connect(bob, acme, WorksAt(role="Designer", started=date(2023, 6, 1)))

g.snapshot("initial")

# --- Serialize ---
data = g.to_dict()
n_ent = len(data["entities"])
n_conn = len(data["connections"])
n_log = len(data.get("change_log", []))
print(f"Serialized: {n_ent} entities, {n_conn} connections")
print(f"Change log: {n_log} entries")
print(f"Snapshots:  {list(data.get('snapshots', {}))}")

schema = data["schema"]
print(
    f"Schema:     {list(schema['entities'])} entities,"
    f" {list(schema['connections'])} connections"
)
age_meta = schema["entities"]["Person"]["fields"]["age"]
print(f"  age field: {age_meta}")

# --- Load with registry (preserves original class identity) ---
registry = {cls.__qualname__: cls for cls in (Person, Organization, WorksAt)}
g2 = Graph.from_dict(data, type_registry=registry)
a2 = g2.get(Person, "alice")
print(f"\nWith registry:    {a2.name}, age {a2.age}")
print(f"  entity annots:  {a2.entity_annotations}")
print(f"  name annots:    {a2.name.annotations}")

conn = g2._connections[0].connection
print(f"  conn annots:    {conn.connection_annotations}")
print(f"  snapshots:      {list(g2._snapshots)}")
print(f"  change_log:     {len(g2._change_log)} entries")

# --- Load WITHOUT registry (zero imports needed) ---
raw = json.dumps(data, default=str)
g3 = Graph.from_dict(json.loads(raw))
a3 = g3.get(Entity, "alice")
d = a3.model_dump()
print(f"\nWithout registry: {d['name']}, age {d['age']}")
print(f"  entity annots:  {a3.entity_annotations}")

# Field constraints are restored on dynamic types
dynamic_cls = type(a3)
try:
    dynamic_cls(id="x", name="X", age=-1)
    print("  age constraint: LOST")
except Exception:
    print("  age constraint: preserved (ge=0)")

# --- File roundtrip ---
OUTPUT_DIR.mkdir(exist_ok=True)
path = OUTPUT_DIR / "graph.json"
g.save_file(path)
print(f"\nSaved to {path} ({path.stat().st_size} bytes)")

g4 = Graph.load_file(path)
n4 = len(g4._entities)
c4 = len(g4._connections)
print(f"Loaded: {n4} entities, {c4} connections")
