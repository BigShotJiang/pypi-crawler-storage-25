"""Subtype polymorphism and embedded objects.

Run: uv run python examples/06_types.py
"""

from facton import Embedded, Entity, Field, Graph


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Employee(Person):
    employee_id: str
    department: str


class Address(Embedded):
    street: str
    city: str
    zip: str


class Contact(Entity):
    name: str
    address: Address | None = None


g = Graph()
g.add(Person(id="alice", name="Alice", age=30))
g.add(Employee(id="bob", name="Bob", age=28, employee_id="E001", department="Eng"))

# Querying Person returns both Person and Employee
print(f"All people: {g.query(Person).count()}")
print(f"Employees only: {g.query(Employee).count()}")

emp = g.query(Employee).first()
print(f"{emp.name} is a Person? {isinstance(emp, Person)}")

# Embedded objects — no separate identity in the graph
frank = Contact(
    id="frank",
    name="Frank",
    address=Address(street="123 Main St", city="Portland", zip="97201"),
)
g.add(frank)
print(f"{frank.name} lives in {frank.address.city}")
