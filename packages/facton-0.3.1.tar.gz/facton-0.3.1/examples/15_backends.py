"""Ephemeral and persistent storage backends.

Run: uv run python examples/15_backends.py
"""

import tempfile
from pathlib import Path

from facton import Connection, Entity, Field, Graph, InMemoryBackend, JsonFileBackend

# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Knows(Connection[Person, Person]):
    since: int | None = None


# ---------------------------------------------------------------------------
# Ephemeral backend (InMemoryBackend)
# ---------------------------------------------------------------------------

print("=== Ephemeral (InMemoryBackend) ===\n")

mem_backend = InMemoryBackend()
g = Graph(backend=mem_backend)

alice = Person(id="alice", name="Alice", age=30)
bob = Person(id="bob", name="Bob", age=25)
g.add(alice)
g.add(bob)
g.connect(alice, bob, Knows(since=2019))

# Backend mirrors Graph state:
print(f"Backend has 'alice': {mem_backend.has('alice')}")
print(f"Backend has 'bob':   {mem_backend.has('bob')}")
conns = list(mem_backend.query_connections("alice", Knows, direction="outgoing"))
print(f"Connections in backend: {len(conns)}")
print(f"  alice -> bob since {conns[0][2].since}")

# Remove an entity — backend cleans up too:
g.remove(bob)
print("\nAfter removing Bob:")
print(f"  Backend has 'bob': {mem_backend.has('bob')}")
outgoing = list(mem_backend.query_connections("alice", Knows, direction="outgoing"))
print(f"  Connections left:  {len(outgoing)}")


# ---------------------------------------------------------------------------
# Persistent backend (JsonFileBackend)
# ---------------------------------------------------------------------------

print("\n\n=== Persistent (JsonFileBackend) ===\n")

# Use a temp directory so the example is self-contained.
with tempfile.TemporaryDirectory() as tmpdir:
    db_path = Path(tmpdir) / "knowledge.json"

    # First session — create and populate the graph
    backend1 = JsonFileBackend(db_path, types=[Person, Knows])
    g1 = Graph(backend=backend1)

    alice = Person(id="alice", name="Alice", age=30)
    bob = Person(id="bob", name="Bob", age=25)
    carol = Person(id="carol", name="Carol", age=28)
    g1.add(alice)
    g1.add(bob)
    g1.add(carol)
    g1.connect(alice, bob, Knows(since=2019))
    g1.connect(bob, carol, Knows(since=2021))

    print(
        f"Session 1: saved {len(list(backend1.query(Person)))} people to {db_path.name}"
    )
    print(f"  File size: {db_path.stat().st_size} bytes")

    # Second session — open the same file, data is still there
    backend2 = JsonFileBackend(db_path, types=[Person, Knows])

    people = list(backend2.query(Person))
    print(f"\nSession 2: loaded {len(people)} people from disk")
    for p in sorted(people, key=lambda p: p.name):
        print(f"  {p.name} (age {p.age})")

    conns = list(backend2.query_connections("alice", Knows, direction="outgoing"))
    print(f"\n  Alice's connections: {len(conns)}")
    for src, tgt, conn in conns:
        print(f"    {src} -> {tgt} (since {conn.since})")

    # Modify from the second session
    backend2.delete("carol")
    assert not backend2.has("carol")
    print("\n  Deleted Carol from session 2 — persisted to disk.")
    print(f"  People remaining: {len(list(backend2.query(Person)))}")
