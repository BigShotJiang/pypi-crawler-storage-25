"""Temporal — history, point-in-time queries, named snapshots.

Run: uv run python examples/08_temporal.py
"""

import time

from facton import Entity, Graph


class Person(Entity):
    name: str
    age: int


g = Graph()
p = Person(id="p1", name="Grace", age=25)
g.add(p)

p.age = 26
g.save(p)

p.age = 27
g.save(p)

# Full history
print("History:")
for v in g.history("p1"):
    print(f"  {v.timestamp.isoformat()}: age={v.data.age}")

# Named snapshot
g.snapshot("v1")
time.sleep(0.01)

p.age = 28
g.save(p)

past = g.at_snapshot("v1")
print(f"\nCurrent age: {g.get(Person, 'p1').age}")
print(f"At 'v1':     {past.get(Person, 'p1').age}")
