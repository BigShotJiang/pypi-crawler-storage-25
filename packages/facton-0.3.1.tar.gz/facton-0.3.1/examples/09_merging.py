"""Graph merging — combine graphs with type and identity mapping.

Run: uv run python examples/09_merging.py
"""

from facton import Entity, Graph, Mapping, merge


class Patient(Entity):
    name: str
    mrn: str


class Subject(Entity):
    name: str
    patient_id: str
    phone: str | None = None


# Two independent graphs describing the same domain differently
hospital_a = Graph()
hospital_a.add(Patient(id="p1", name="Alice Smith", mrn="MRN-001"))
hospital_a.add(Patient(id="p2", name="Bob Jones", mrn="MRN-002"))

hospital_b = Graph()
hospital_b.add(
    Subject(id="s1", name="A. Smith", patient_id="MRN-001", phone="555-0100")
)
hospital_b.add(Subject(id="s2", name="Carol Lee", patient_id="MRN-003"))

# Explicit mapping: Patient.mrn matches Subject.patient_id
mapping = Mapping(
    types={Patient: Subject},
    match_on={Patient: ("mrn", "patient_id")},
)

merged = merge(hospital_a, hospital_b, mapping)

print(f"Merged entities: {len(merged._entities)}")
for eid, entity in merged._entities.items():
    source = entity.entity_annotations.get("_source_graph", "?")
    print(f"  {eid}: {entity.name} (from graph {source})")
