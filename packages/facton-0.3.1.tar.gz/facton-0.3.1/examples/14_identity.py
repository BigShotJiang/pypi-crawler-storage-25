"""Auto-generated IDs, identity equality, and duplicate guards.

Run: uv run python examples/14_identity.py
"""

from typing import ClassVar

from facton import Connection, Entity, Field, Graph

# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Knows(Connection[Person, Person]):
    since: int | None = None


class BestFriend(Connection[Person, Person]):
    """Only one best-friend link per pair."""

    unique_endpoints: ClassVar[bool] = True


# ---------------------------------------------------------------------------
# Auto-generated IDs
# ---------------------------------------------------------------------------

alice = Person(name="Alice", age=30)  # id generated automatically
bob = Person(name="Bob", age=25)  # each gets a unique UUID hex
carol = Person(id="carol", name="Carol", age=28)  # explicit id still works

print(f"Alice id (auto):   {alice.id}")
print(f"Bob   id (auto):   {bob.id}")
print(f"Carol id (explicit): {carol.id}")
assert alice.id != bob.id
assert carol.id == "carol"

# ---------------------------------------------------------------------------
# Identity-based equality
# ---------------------------------------------------------------------------

alice_copy = Person(id=alice.id, name="Alice", age=31)  # same id, different age

print(f"\nalice == alice_copy? {alice == alice_copy}")  # True — same id
print(f"alice == bob?        {alice == bob}")  # False — different id

# Entities are hashable by id, so they work in sets and dicts.
people = {alice, alice_copy, bob}
print(f"Unique people in set: {len(people)}")  # 2, not 3

# ---------------------------------------------------------------------------
# Duplicate connection guard
# ---------------------------------------------------------------------------

g = Graph()
g.add(alice)
g.add(bob)
g.add(carol)

# Regular connections allow duplicates:
g.connect(alice, bob, Knows(since=2019))
g.connect(alice, bob, Knows(since=2020))
print(f"\nKnows connections (duplicates OK): {len(g.connections_of(alice, Knows))}")

# BestFriend has unique_endpoints — second link is rejected:
g.connect(alice, carol, BestFriend())
try:
    g.connect(alice, carol, BestFriend())
except ValueError as exc:
    print(f"Blocked duplicate: {exc}")

print(f"BestFriend connections: {len(g.connections_of(alice, BestFriend))}")
