"""Aggregation — group, count, and sort.

Run: uv run python examples/05_aggregation.py
"""

from facton import Entity, Field, Graph, count


class Person(Entity):
    name: str
    age: int = Field(ge=0)
    city: str = "Unknown"


g = Graph()
g.add(Person(id="a", name="Alice", age=30, city="Portland"))
g.add(Person(id="b", name="Bob", age=30, city="Portland"))
g.add(Person(id="c", name="Carol", age=25, city="Seattle"))
g.add(Person(id="d", name="Dave", age=25, city="Seattle"))
g.add(Person(id="e", name="Eve", age=25, city="Portland"))

# Group by city, count, sort descending
by_city = (
    g.query(Person)
    .group_by(lambda p: str(p.city))
    .aggregate(count)
    .order_by("value", descending=True)
)

for row in by_city:
    print(f"  {row.key}: {row.value} people")

# Group by age
by_age = g.query(Person).group_by(lambda p: int(p.age)).aggregate(count).order_by("key")

print()
for row in by_age:
    print(f"  Age {row.key}: {row.value}")
