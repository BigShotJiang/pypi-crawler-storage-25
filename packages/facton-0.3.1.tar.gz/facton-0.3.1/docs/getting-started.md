# Getting Started

This page walks through the core concepts of Facton in a few minutes.

## Install

```bash
pip install facton
```

Or with [uv](https://docs.astral.sh/uv/):

```bash
uv add facton
```

## Define Your Schema

Entities are the nodes of your graph. Connections are the typed, directed edges.

```python
from facton import Connection, Entity, Field, Graph


class Person(Entity):
    name: str
    age: int = Field(ge=0)
    email: str | None = None


class Knows(Connection[Person, Person]):
    since: int | None = None
```

`Entity` and `Connection` are Pydantic models — you get validation, serialization, and type safety for free.

## Build a Graph

```python
g = Graph()

alice = Person(id="alice", name="Alice", age=30)
bob = Person(id="bob", name="Bob", age=28)
g.add(alice)
g.add(bob)

g.connect(alice, bob, Knows(since=2019))
```

## Query

```python
# All people over 25
results = g.query(Person).where(lambda p: p.age > 25).all()

# First match
oldest = g.query(Person).order_by("age", reverse=True).first()
```

## Traverse

```python
# Direct friends
friends = g.traverse(alice, Knows)

# Friends of friends (up to 2 hops)
fof = g.traverse(alice, Knows, depth=2)
```

## Annotate Facts

Every field on an entity is a `Fact` that can carry provenance metadata.

Attach metadata inline at construction:

```python
from facton import Fact

alice = Person(id="alice", name=Fact("Alice", source="id_scan", confidence=0.98), age=30)
print(alice.name.annotations)
# {'source': 'id_scan', 'confidence': 0.98}
```

Or add annotations after the fact:

```python
alice.name.annotate(verified=True)
```

## Save and Load

```python
# To a JSON file
g.save_file("people.json")

# Back again
g2 = Graph.load_file("people.json")
```

The JSON format is self-describing — it embeds a schema section so you can load a graph without providing type definitions.

## Use a Backend

For persistent storage that mirrors every mutation:

```python
from facton import Graph, JsonFileBackend

backend = JsonFileBackend("data.json")
g = Graph(backend=backend)
# Every add/save/remove/connect is automatically persisted
```

## Next Steps

Explore the [Guide](guide/entities-and-connections.md) for deeper coverage of each feature.
