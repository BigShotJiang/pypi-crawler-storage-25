# Queries

Facton provides a fluent query builder for filtering, sorting, and aggregating entities.

## Basic Queries

```python
from facton import Graph, count

# All people
everyone = g.query(Person).all()

# With a filter
young = g.query(Person).where(lambda p: p.age < 30).all()

# First match
first = g.query(Person).where(lambda p: p.name == "Alice").first()

# Count
n = g.query(Person).count()
```

## Chaining

Queries are fluent — chain `.where()`, `.connected_to()`, `.order_by()`, and more:

```python
results = (
    g.query(Person)
    .where(lambda p: p.age >= 25)
    .connected_to(alice, Knows)
    .order_by("name")
    .all()
)
```

## Select (Projection)

Return specific fields instead of full entities:

```python
names = g.query(Person).select("name").all()
# [{'name': 'Alice'}, {'name': 'Bob'}]

pairs = g.query(Person).select("name", "age").all()
# [{'name': 'Alice', 'age': 30}, ...]
```

## Sorting

```python
by_age = g.query(Person).order_by("age").all()
by_age_desc = g.query(Person).order_by("age", reverse=True).all()
```

## Aggregation

```python
from facton import count

# Group by a field
grouped = g.query(Person).group_by("age").aggregate(count).all()
# [{'age': 30, 'count': 1}, {'age': 28, 'count': 1}]
```

## Iteration

Query results are iterable:

```python
for person in g.query(Person).where(lambda p: p.age > 20):
    print(person.name)
```
