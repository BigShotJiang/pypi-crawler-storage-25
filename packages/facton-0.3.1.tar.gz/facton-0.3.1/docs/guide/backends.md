# Backends

Backends provide pluggable persistence. When a backend is attached to a graph, every mutation is automatically mirrored to the backend.

## Using a Backend

```python
from facton import Graph, InMemoryBackend

backend = InMemoryBackend()
g = Graph(backend=backend)

# All add/save/remove/connect/disconnect/derive/relate calls
# are automatically persisted to the backend
g.add(alice)
```

## Built-In Backends

### InMemoryBackend

An ephemeral reference implementation. Useful for testing:

```python
from facton import InMemoryBackend

backend = InMemoryBackend()
g = Graph(backend=backend)
```

### JsonFileBackend

Persists to a JSON file on disk. Data survives process restarts:

```python
from facton import JsonFileBackend

backend = JsonFileBackend("data.json")
g = Graph(backend=backend)
```

Provide a type registry if you want loaded data to use your existing classes:

```python
backend = JsonFileBackend("data.json", type_registry={
    "Person": Person,
    "Knows": Knows,
})
```

## StorageBackend Protocol

Implement the `StorageBackend` protocol to create custom backends:

```python
from facton import StorageBackend


class MyBackend:
    def save(self, entity): ...
    def load(self, entity_id): ...
    def delete(self, entity_id): ...
    def has(self, entity_id): ...
    def save_connection(self, source_id, target_id, connection, *, derived=False): ...
    def delete_connection(self, source_id, target_id, connection_type): ...
    def query_connections(self, entity_id, connection_type, *, direction="both"): ...
    def save_relation(self, relation): ...
    def delete_relation(self, relation): ...
    def query_relations(self, relation_type): ...
```

The protocol is `runtime_checkable`, so you can verify your implementation with `isinstance(backend, StorageBackend)`.
