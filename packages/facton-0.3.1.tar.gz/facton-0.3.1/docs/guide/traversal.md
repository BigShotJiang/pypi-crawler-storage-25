# Traversal & Algorithms

## Traversal

Walk the graph following connections of a given type:

```python
# Direct connections (1 hop)
friends = g.traverse(alice, Knows)

# Up to N hops
friends_of_friends = g.traverse(alice, Knows, depth=2)

# Specific range of hops
exactly_two_hops = g.traverse(alice, Knows, depth=(2, 2))
at_least_two = g.traverse(alice, Knows, depth=(2, 5))
```

Traversal follows connections in both directions and avoids cycles.

## Shortest Path

Find the shortest path between two entities via BFS:

```python
path = g.shortest_path(alice, charlie, Knows)
if path:
    print(" -> ".join(p.name for p in path))
else:
    print("No path found")
```

Returns a list of entities from start to end (inclusive), or `None` if no path exists.

## Connected Components

Find clusters of connected entities:

```python
# All components (using any connection type)
clusters = g.components()
# [{'alice', 'bob', 'charlie'}, {'dave'}]

# Components via a specific connection type
knows_clusters = g.components(Knows)
```

Returns a list of sets, each containing entity IDs of one component.
