# Transactions

Facton supports atomic write transactions and read-only snapshots.

## Write Transactions

Wrap mutations in a transaction for atomic commit or rollback:

```python
with g.transaction() as tx:
    tx.add(Person(id="eve", name="Eve", age=25))
    tx.connect(alice, eve, Knows(since=2024))
    # all changes commit when the block exits
```

If an exception occurs inside the block, all changes are rolled back:

```python
try:
    with g.transaction() as tx:
        tx.add(Person(id="eve", name="Eve", age=25))
        raise ValueError("something went wrong")
except ValueError:
    pass

# Eve was never added
assert g.get(Person, "eve") is None
```

## Read-Only Snapshots

Take a consistent snapshot for reads that aren't affected by concurrent writes:

```python
with g.read() as snapshot:
    people = snapshot.query(Person).all()
    # snapshot is frozen — mutations to g don't affect it
```
