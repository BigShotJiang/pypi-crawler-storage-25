# Temporal History

Facton tracks every mutation as a timestamped change record.

## Change History

```python
g.add(alice)
alice.age = 31
g.save(alice)

# Full history of an entity
history = g.history("alice")
for record in history:
    print(f"{record.operation} at {record.timestamp}")
```

## Point-in-Time Queries

Retrieve the state of an entity at a specific moment:

```python
from datetime import datetime

past = datetime(2026, 1, 1)
old_alice = g.at(past, "alice")
```

## Named Snapshots

Save and restore named points in time:

```python
g.snapshot("before_migration")

# ... make changes ...

# Retrieve state at that snapshot
old_state = g.at_snapshot("before_migration", "alice")
```
