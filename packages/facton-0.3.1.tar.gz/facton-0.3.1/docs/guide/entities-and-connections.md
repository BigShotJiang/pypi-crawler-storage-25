# Entities & Connections

## Entities

Entities are the nodes of your graph. Define them as Python classes that inherit from `Entity`:

```python
from facton import Entity, Field


class Person(Entity):
    name: str
    age: int = Field(ge=0)
    email: str | None = None
```

### Auto-Generated IDs

The `id` field is optional. Omit it and Facton generates a UUID:

```python
alice = Person(name="Alice", age=30)
print(alice.id)  # e.g. "a1b2c3d4e5f6..."
```

Explicit IDs still work:

```python
bob = Person(id="bob", name="Bob", age=28)
```

### Identity Equality

Entities compare equal by `id` and are hashable:

```python
alice1 = Person(id="alice", name="Alice", age=30)
alice2 = Person(id="alice", name="Alice", age=31)
assert alice1 == alice2  # same id
assert {alice1, alice2} == {alice1}  # deduplicates in sets
```

## Connections

Connections are typed, directed edges between entities:

```python
from facton import Connection


class Knows(Connection[Person, Person]):
    since: int | None = None


class WorksAt(Connection[Person, Organization]):
    role: str
```

The generic parameters `Connection[Source, Target]` declare the endpoint types. Facton enforces these at runtime — connecting incompatible types raises `TypeError`.

### Duplicate Guard

Set `unique_endpoints` to prevent duplicate connections between the same pair:

```python
from typing import ClassVar


class FriendOf(Connection[Person, Person]):
    unique_endpoints: ClassVar[bool] = True
```

## CRUD Operations

```python
from facton import Graph

g = Graph()

# Add
g.add(alice)

# Retrieve
person = g.get(Person, "alice")

# Update
alice.age = 31
g.save(alice)

# Remove (also removes connections)
g.remove(alice)
```

## Connecting and Disconnecting

```python
g.connect(alice, bob, Knows(since=2019))

# All connections involving alice
conns = g.connections_of(alice)

# Only Knows connections
knows_conns = g.connections_of(alice, Knows)

# Remove connections of a type between two entities
g.disconnect(alice, bob, Knows)
```

## Fact Annotations

Every field on an entity or connection is a `Fact` — a value that can carry provenance metadata.

### Inline annotations at construction

Pass a `Fact` object directly to attach metadata when creating an entity or connection:

```python
from facton import Fact

alice = Person(id="alice", name=Fact("Alice", source="passport"), age=30)
print(alice.name.annotations)  # {'source': 'passport'}

edge = g.connect(alice, bob, Knows(since=Fact(2019, source="user_input")))
print(edge.since.annotations)  # {'source': 'user_input'}
```

Plain values still work — they are wrapped in annotation-free `Fact` instances internally.

### Post-construction annotations

Use `.annotate()` to add metadata after the object exists:

```python
alice.name.annotate(confidence=0.99)
print(alice.name.annotations)  # {'source': 'passport', 'confidence': 0.99}
```

Annotations survive serialization round-trips.

## Embedded Types

Use `Embedded` for structured values that aren't standalone entities:

```python
from facton import Embedded


class Address(Embedded):
    street: str
    city: str
    zip_code: str


class Company(Entity):
    name: str
    hq: Address
```

## Relations

For n-ary relationships (connecting more than two entities), use `Relation` and `Role`:

```python
from facton import Relation, Role


class Project(Entity):
    name: str


class Assignment(Relation):
    person: Role[Person]
    project: Role[Project]
    allocation: float  # percentage

g.relate(Assignment(
    person=Role(alice),
    project=Role(project),
    allocation=0.5,
))
```
