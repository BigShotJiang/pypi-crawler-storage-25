# Serialization

Facton provides lossless serialization to and from JSON.

## Dict Round-Trips

```python
data = g.to_dict()   # graph -> dict
g2 = Graph.from_dict(data)  # dict -> graph
```

## File Persistence

```python
g.save_file("graph.json")
g2 = Graph.load_file("graph.json")
```

## What Gets Preserved

The serialization format is self-describing and lossless:

- Entity types and all field values
- Connection types with source/target type info
- Field constraints (`ge`, `le`, `gt`, `lt`, `max_length`, `min_length`, `pattern`, defaults)
- Fact annotations (per-entity, per-field provenance metadata)
- `Meta.constraints` (`Unique`, `Constraint`)
- Derived vs. asserted connections
- Temporal change log and named snapshots
- A `schema` section that describes all types, so the graph can be loaded without a type registry

## Loading Without Code

Because the JSON embeds the schema, you can load a graph without having the original Python classes:

```python
# No imports of Person, Knows, etc. needed
g = Graph.load_file("graph.json")
```

Types are reconstructed automatically with full Pydantic validation.

## Type Registry

If you want loaded entities to use your existing classes (for methods, etc.), provide a type registry:

```python
g = Graph.load_file("graph.json", type_registry={
    "Person": Person,
    "Knows": Knows,
})
```
