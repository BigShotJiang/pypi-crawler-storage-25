# Rules & Inference

Facton supports declarative inference rules that derive new connections from existing data.

## The @rule Decorator

```python
from facton import rule


@rule
def colleagues(g):
    """People who work at the same organization know each other."""
    for org in g.query(Organization).all():
        workers = g.traverse(org, WorksAt)
        for i, a in enumerate(workers):
            for b in workers[i + 1 :]:
                g.derive(a, b, Knows(since=2024))
```

Register and execute:

```python
g.register_rule(colleagues)
g.run_rules()
```

Derived connections are tagged so they can be distinguished from asserted facts.

## Declarative Rules

For simpler patterns, use `add_rule` with `when`/`then` lambdas:

```python
g.add_rule(
    "infer_colleagues",
    when=lambda g: [
        (a, b)
        for org in g.query(Organization).all()
        for a in g.traverse(org, WorksAt)
        for b in g.traverse(org, WorksAt)
        if a.id < b.id
    ],
    then=lambda pair: (pair[0], pair[1], Knows()),
)

g.run_rules()
```

## Derived Connections

Connections created by rules are marked as derived:

```python
for stored in g.connections_of(alice, Knows):
    if stored.derived:
        print(f"Inferred: {stored.source_id} -> {stored.target_id}")
```
