# Constraints

Facton supports uniqueness and cardinality constraints.

## Field Uniqueness

Mark a field as unique using `Field`:

```python
from facton import Entity, Field


class Employee(Entity):
    email: str = Field(unique=True)
    name: str
```

Adding two employees with the same email raises `ValueError`.

## Composite Uniqueness

Enforce uniqueness across a combination of fields:

```python
from facton import Unique


class Flight(Entity):
    airline: str
    number: str
    date: str

    class Meta:
        constraints = [Unique("airline", "number", "date")]
```

## Connection Cardinality

Limit how many connections of a type an entity can have:

```python
from facton import Connection, Constraint


class Manages(Connection[Person, Person]):
    class Meta:
        constraints = [
            Constraint(kind="max_per_target", limit=1),  # one manager per person
        ]
```

Constraint kinds:

- `max_per_source` — limit outgoing connections from a source entity
- `max_per_target` — limit incoming connections to a target entity

Both support an optional `predicate` for conditional enforcement.
