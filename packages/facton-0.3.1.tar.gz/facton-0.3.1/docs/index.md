# Facton

A Python-native knowledge graph library.

Define entities and connections as Python classes. Query, traverse, and annotate
your graph without learning a separate query language.

---

## Why Facton?

- **Pure Python** — no external database, no query language. Your schema is Python classes.
- **Typed from the ground up** — Pydantic models with full validation, generic connections, and IDE autocompletion.
- **Batteries included** — queries, traversal, constraints, transactions, temporal history, serialization, inference rules, and pluggable backends.
- **Lightweight** — single dependency (Pydantic). Runs anywhere Python runs.

## Quick Example

```python
from facton import Connection, Entity, Field, Graph


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Knows(Connection[Person, Person]):
    since: int | None = None


g = Graph()
alice = Person(id="alice", name="Alice", age=30)
bob = Person(id="bob", name="Bob", age=28)
g.add(alice)
g.add(bob)
g.connect(alice, bob, Knows(since=2019))

# Query
seniors = g.query(Person).where(lambda p: p.age >= 30).all()

# Traverse
friends = g.traverse(alice, Knows, depth=2)

# Persist
g.save_file("social.json")
```

## Installation

```bash
pip install facton
```

Requires Python 3.13+.

## Next Steps

- [Getting Started](getting-started.md) — walk through core concepts in 5 minutes
- [Guide](guide/entities-and-connections.md) — deep dives into every feature
- [Changelog](changelog.md) — what's new
