# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.1] - 2026-04-28

### Added

- **Inline Fact annotations**: `Fact(value, **annotations)` accepts metadata
  kwargs at construction time. Pass annotated values directly to entity and
  connection fields (e.g. `Knows(since=Fact(2019, source="user_input"))`).
  Plain values continue to work unchanged.
- **Typed `connect()` return**: `Graph.connect()` now preserves the concrete
  connection subclass in its return type, giving IDEs full autocomplete for
  connection fields.

### Fixed

- **Merge index rebuild**: `merge()` now rebuilds adjacency and type indexes,
  so queries, traversal, and algorithms work on merged graphs.

### Changed

- Added `hypothesis` to dev dependencies for property-based testing.
- Expanded test coverage for merge, backends, rules, and temporal modules.

## [0.3.0] - 2026-04-28

### Added

- **Edge case and performance test suite**: 54 new tests in
  `test_edge_cases.py` covering empty graphs, self-loops, double-remove,
  remove-and-re-add, index consistency after complex mutation sequences,
  transaction rollback index preservation, rule system (`@rule`, declarative
  rules, derived tagging), algorithm edge cases (cycles, bidirectional BFS,
  nonexistent entities), serialization edge cases (entities-only, non-ASCII,
  index rebuild, date fields), transaction edge cases (read isolation, partial
  rollback), constraint edge cases (silent disconnect, multiple Nones,
  cardinality), traversal depth ranges, and performance stress tests (2 000
  entities, 500-node chain traversal/shortest-path, 5×100 component detection,
  large serialization roundtrip). Total test count: 212.

## [0.2.0] - 2026-04-28

### Added

- **In-memory backend**: `InMemoryBackend` reference implementation of
  `StorageBackend`. Graph write-through: when a backend is provided via
  `Graph(backend=...)`, all mutations (add/save/remove, connect/disconnect/derive,
  relate) are mirrored to the backend.
- **JSON file backend**: `JsonFileBackend` persistent implementation that
  serializes entities, connections, and relations to a JSON file on disk.
  Data survives across process restarts.
- **Adjacency index**: `_outgoing`/`_incoming` dicts give O(degree) connection
  lookups instead of O(total connections).
- **Type index**: `_by_type` dict gives O(1) entity-by-type queries instead of
  O(all entities).
- **Connection endpoint type checking**: `connect()` validates that source and
  target entities match the declared generic type parameters. Raises `TypeError`
  on mismatch; subtypes are accepted.
- **Serialization**: `Graph.to_dict()` / `Graph.from_dict()` for dict
  round-trips; `Graph.save_file(path)` / `Graph.load_file(path)` for JSON file
  persistence. Lossless: preserves field constraints (`ge`, `le`, `gt`, `lt`,
  `max_length`, `min_length`, `pattern`, defaults), entity/connection/fact
  annotations, `Meta.constraints` (`Unique`, `Constraint`), temporal change log,
  and named snapshots. JSON embeds a self-describing `schema` section so graphs
  can be loaded without a type registry — types are reconstructed automatically
  with full validation.
- **Shortest path**: `Graph.shortest_path(start, end, connection_type)` — BFS
  over both directions, returns entity list or `None`.
- **Connected components**: `Graph.components(connection_type=None)` — returns
  `list[set[str]]` of entity-id clusters.
- **Backend protocol expansion**: `StorageBackend` now covers connections
  (`save_connection`, `delete_connection`, `query_connections`) and relations
  (`save_relation`, `delete_relation`, `query_relations`).
- **Duplicate connection guard**: Connection types can set
  `unique_endpoints: ClassVar[bool] = True` to prevent duplicate connections
  between the same pair of entities. Enforced on both `connect()` and `derive()`.
- **Auto-generated entity IDs**: `Entity.id` is now optional — omitting it
  generates a UUID hex string. Explicit IDs still work as before.
- **Identity-based entity equality**: `Entity.__eq__` and `__hash__` now use
  the `id` field, so entities with the same id compare equal and are hashable.

### Changed

- **Project structure**: replaced internal `_types/` monolith (14 files) with
  public flat modules (`entity.py`, `connection.py`, `graph.py`, etc.) and a
  `backends/` sub-package (`protocol.py`, `memory.py`, `json_file.py`).
  `graph.py` slimmed from ~1 100 lines to ~480 by extracting serialization to
  `serialization.py` and algorithms to `algorithms.py`. All public imports
  (`from facton import ...`) are unchanged.

### Fixed

- `Connection.__init_subclass__` now extracts generic type args from Pydantic
  MRO metadata instead of `__orig_bases__`, which Pydantic rewrites.
- `Transaction` rollback and `ReadTransaction` snapshot now preserve adjacency
  and type indexes.

## [0.1.0] - 2026-04-28

### Added

- Core types: `Entity`, `Connection`, `Fact`, `Relation`, `Role`, `Embedded`,
  `Field`.
- `Graph` with CRUD (`add`, `get`, `save`, `remove`), `connect`/`disconnect`,
  `relate`.
- Fact wrapping: every property on an entity or connection is a `Fact[T]` that
  inherits from `T` and supports `.annotate()` / `.annotations`.
- Query builder: `graph.query(Type).where(...).connected_to(...).all()` with
  fluent chaining, `select()`, `first()`, `count()`, iteration.
- Aggregation: `group_by()`, `aggregate(count)`, `order_by()`.
- Traversal: `graph.traverse(entity, Type, depth=...)` with range support.
- Constraints: `Unique` (per-field and composite), `Constraint`
  (`max_per_source`, `max_per_target`) with optional predicates.
- Transactions: `graph.transaction()` (atomic write with rollback),
  `graph.read()` (snapshot isolation).
- Temporal: `graph.history(id)`, `graph.at(timestamp)`,
  `graph.snapshot(name)` / `graph.at_snapshot(name)`.
- Graph merging: `merge(a, b, mapping)` with type, identity, and property
  mapping; provenance annotations.
- Inference rules: `@rule` decorator, `graph.add_rule()`, `graph.run_rules()`,
  `graph.derive()`.
- `StorageBackend` protocol for pluggable persistence (not yet wired).
- 10 runnable examples (`examples/01_basics.py` through `examples/10_rules.py`).
- 59 tests across 7 modules; lint clean.
