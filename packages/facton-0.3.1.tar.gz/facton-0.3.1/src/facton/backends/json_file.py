"""JSON-file persistent storage backend."""

from __future__ import annotations

import json
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from facton.connection import Connection
from facton.entity import Entity
from facton.relation import Relation


class JsonFileBackend:
    """``StorageBackend`` that persists data as a JSON file on disk.

    The file is rewritten on every mutation. Reads reload from disk so
    external edits are picked up automatically.

    A *type registry* maps type-name strings to the actual Python classes
    so entities, connections, and relations can be deserialized::

        backend = JsonFileBackend(
            "graph.json",
            types=[Person, Organization, Knows, WorksAt, Meeting],
        )
        g = Graph(backend=backend)
    """

    def __init__(
        self,
        path: str | Path,
        types: list[type] | None = None,
    ) -> None:
        self._path = Path(path)
        self._registry: dict[str, type] = {}
        for t in types or []:
            self._registry[t.__qualname__] = t
        if not self._path.exists():
            self._write({"entities": {}, "connections": [], "relations": []})

    # --- persistence helpers ---

    def _read(self) -> dict[str, Any]:
        return json.loads(self._path.read_text())

    def _write(self, data: dict[str, Any]) -> None:
        self._path.write_text(json.dumps(data, default=str, indent=2))

    def _resolve(self, name: str) -> type | None:
        return self._registry.get(name)

    # --- Entities ---

    def get[T: Entity](self, id: str, kind: type[T]) -> T | None:
        data = self._read()
        record = data.get("entities", {}).get(id)
        if record is None:
            return None
        cls = self._resolve(record["type"])
        if cls is None or not issubclass(cls, kind):
            return None
        return cls.model_validate(record["data"])  # type: ignore[return-value]

    def save(self, entity: Entity) -> None:
        data = self._read()
        data.setdefault("entities", {})[entity.id] = {
            "type": type(entity).__qualname__,
            "data": entity.model_dump(mode="json"),
        }
        self._write(data)

    def delete(self, id: str) -> None:
        data = self._read()
        data.get("entities", {}).pop(id, None)
        data["connections"] = [
            c
            for c in data.get("connections", [])
            if c["source_id"] != id and c["target_id"] != id
        ]
        self._write(data)

    def query[T: Entity](self, kind: type[T]) -> Iterator[T]:
        data = self._read()
        for record in data.get("entities", {}).values():
            cls = self._resolve(record["type"])
            if cls is not None and issubclass(cls, kind):
                yield cls.model_validate(record["data"])  # type: ignore[misc]

    def has(self, id: str) -> bool:
        data = self._read()
        return id in data.get("entities", {})

    # --- Connections ---

    def save_connection(
        self,
        source_id: str,
        target_id: str,
        connection: Connection[Any, Any],
        *,
        derived: bool = False,
    ) -> None:
        data = self._read()
        data.setdefault("connections", []).append(
            {
                "source_id": source_id,
                "target_id": target_id,
                "type": type(connection).__qualname__,
                "data": connection.model_dump(mode="json"),
                "derived": derived,
            }
        )
        self._write(data)

    def delete_connection(
        self,
        source_id: str,
        target_id: str,
        connection_type: type[Connection[Any, Any]],
    ) -> None:
        type_name = connection_type.__qualname__
        data = self._read()
        data["connections"] = [
            c
            for c in data.get("connections", [])
            if not (
                c["source_id"] == source_id
                and c["target_id"] == target_id
                and c["type"] == type_name
            )
        ]
        self._write(data)

    def query_connections(
        self,
        entity_id: str,
        connection_type: type[Connection[Any, Any]],
        *,
        direction: str = "outgoing",
    ) -> Iterator[tuple[str, str, Connection[Any, Any]]]:
        type_name = connection_type.__qualname__
        data = self._read()
        for c in data.get("connections", []):
            if c["type"] != type_name:
                continue
            match = False
            if direction == "outgoing":
                match = c["source_id"] == entity_id
            elif direction == "incoming":
                match = c["target_id"] == entity_id
            elif direction == "both":
                match = c["source_id"] == entity_id or c["target_id"] == entity_id
            if match:
                cls = self._resolve(c["type"])
                if cls is not None:
                    conn = cls.model_validate(c["data"])
                    yield c["source_id"], c["target_id"], conn

    # --- Relations ---

    def save_relation(self, relation: Relation) -> None:
        data = self._read()
        data.setdefault("relations", []).append(
            {
                "type": type(relation).__qualname__,
                "data": relation.model_dump(mode="json"),
            }
        )
        self._write(data)

    def delete_relation(self, relation: Relation) -> None:
        type_name = type(relation).__qualname__
        rel_data = relation.model_dump(mode="json")
        data = self._read()
        data["relations"] = [
            r
            for r in data.get("relations", [])
            if not (r["type"] == type_name and r["data"] == rel_data)
        ]
        self._write(data)

    def query_relations(
        self,
        relation_type: type[Relation],
    ) -> Iterator[Relation]:
        type_name = relation_type.__qualname__
        data = self._read()
        for r in data.get("relations", []):
            if r["type"] == type_name:
                yield relation_type.model_validate(r["data"])
