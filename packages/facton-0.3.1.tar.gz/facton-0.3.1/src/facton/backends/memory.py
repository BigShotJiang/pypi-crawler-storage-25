"""In-memory storage backend."""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

from facton.connection import Connection
from facton.entity import Entity
from facton.relation import Relation


class _StoredConnection:
    """A connection stored with its endpoint ids and derivation flag."""

    __slots__ = ("connection", "derived", "source_id", "target_id")

    def __init__(
        self,
        source_id: str,
        target_id: str,
        connection: Connection[Any, Any],
        *,
        derived: bool = False,
    ) -> None:
        self.source_id = source_id
        self.target_id = target_id
        self.connection = connection
        self.derived = derived


class InMemoryBackend:
    """Reference ``StorageBackend`` implementation backed by plain dicts.

    Useful for testing and as the default backend when no external
    persistence is needed.
    """

    def __init__(self) -> None:
        self._entities: dict[str, Entity] = {}
        self._connections: list[_StoredConnection] = []
        self._relations: list[Relation] = []

    # --- Entities ---

    def get[T: Entity](self, id: str, kind: type[T]) -> T | None:
        entity = self._entities.get(id)
        if entity is not None and isinstance(entity, kind):
            return entity
        return None

    def save(self, entity: Entity) -> None:
        self._entities[entity.id] = entity

    def delete(self, id: str) -> None:
        self._entities.pop(id, None)
        self._connections = [
            c for c in self._connections if c.source_id != id and c.target_id != id
        ]

    def query[T: Entity](self, kind: type[T]) -> Iterator[T]:
        for entity in self._entities.values():
            if isinstance(entity, kind):
                yield entity

    def has(self, id: str) -> bool:
        return id in self._entities

    # --- Connections ---

    def save_connection(
        self,
        source_id: str,
        target_id: str,
        connection: Connection[Any, Any],
        *,
        derived: bool = False,
    ) -> None:
        self._connections.append(
            _StoredConnection(
                source_id=source_id,
                target_id=target_id,
                connection=connection,
                derived=derived,
            )
        )

    def delete_connection(
        self,
        source_id: str,
        target_id: str,
        connection_type: type[Connection[Any, Any]],
    ) -> None:
        self._connections = [
            c
            for c in self._connections
            if not (
                c.source_id == source_id
                and c.target_id == target_id
                and isinstance(c.connection, connection_type)
            )
        ]

    def query_connections(
        self,
        entity_id: str,
        connection_type: type[Connection[Any, Any]],
        *,
        direction: str = "outgoing",
    ) -> Iterator[tuple[str, str, Connection[Any, Any]]]:
        for c in self._connections:
            if not isinstance(c.connection, connection_type):
                continue
            match = False
            if direction == "outgoing":
                match = c.source_id == entity_id
            elif direction == "incoming":
                match = c.target_id == entity_id
            elif direction == "both":
                match = c.source_id == entity_id or c.target_id == entity_id
            if match:
                yield c.source_id, c.target_id, c.connection

    # --- Relations ---

    def save_relation(self, relation: Relation) -> None:
        self._relations.append(relation)

    def delete_relation(self, relation: Relation) -> None:
        self._relations = [r for r in self._relations if r is not relation]

    def query_relations(
        self,
        relation_type: type[Relation],
    ) -> Iterator[Relation]:
        for r in self._relations:
            if isinstance(r, relation_type):
                yield r
