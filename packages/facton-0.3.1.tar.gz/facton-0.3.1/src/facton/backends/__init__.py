"""Storage backend protocol and implementations.

Import from this package or from ``facton`` directly::

    from facton.backends import InMemoryBackend, JsonFileBackend, StorageBackend
    # or
    from facton import InMemoryBackend, JsonFileBackend, StorageBackend
"""

from facton.backends.json_file import JsonFileBackend
from facton.backends.memory import InMemoryBackend
from facton.backends.protocol import StorageBackend

__all__ = [
    "InMemoryBackend",
    "JsonFileBackend",
    "StorageBackend",
]
