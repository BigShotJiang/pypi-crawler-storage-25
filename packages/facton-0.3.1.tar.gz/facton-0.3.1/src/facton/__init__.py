"""Facton — A Python-native knowledge graph library."""

from facton.backends import InMemoryBackend, JsonFileBackend, StorageBackend
from facton.connection import Connection
from facton.constraint import Constraint, Unique
from facton.embedded import Embedded
from facton.entity import Entity
from facton.fact import Fact
from facton.field import Field
from facton.graph import Graph
from facton.merge import Mapping, merge
from facton.query import count
from facton.relation import Relation, Role
from facton.rule import rule

__all__ = [
    "Connection",
    "Constraint",
    "Embedded",
    "Entity",
    "Fact",
    "Field",
    "Graph",
    "InMemoryBackend",
    "JsonFileBackend",
    "Mapping",
    "Relation",
    "Role",
    "StorageBackend",
    "Unique",
    "count",
    "merge",
    "rule",
]
