"""Graph merging — combine two independent graphs with explicit mappings."""

from __future__ import annotations

import contextlib
from dataclasses import dataclass, field

from facton.entity import Entity
from facton.graph import Graph


@dataclass
class Mapping:
    """Declares how types, properties, and identities map across graphs."""

    types: dict[type[Entity], type[Entity]] = field(default_factory=dict)
    properties: dict[str, str] = field(default_factory=dict)
    match_on: dict[type[Entity], tuple[str, str]] = field(default_factory=dict)


def merge(
    graph_a: Graph,
    graph_b: Graph,
    mapping: Mapping | None = None,
) -> Graph:
    """Merge two graphs into a new combined graph.

    When no mapping is provided, entities are combined by id. When a
    mapping is provided, type conversions and identity matching are
    applied.

    Every entity in the merged graph carries a ``_source_graph``
    annotation indicating its origin.
    """
    mapping = mapping or Mapping()
    result = Graph()

    # Index graph_b entities by mapped identity keys
    reverse_type_map = {v: k for k, v in mapping.types.items()}

    # Add all entities from graph_a
    for entity in graph_a._entities.values():
        entity.annotate(_source_graph="a")
        result._entities[entity.id] = entity

    # Add entities from graph_b, handling type mapping and identity matching
    for entity in graph_b._entities.values():
        entity.annotate(_source_graph="b")
        entity_type = type(entity)

        # Check if this type maps to a type in graph_a
        target_type = reverse_type_map.get(entity_type)
        if target_type and target_type in mapping.match_on:
            a_field, b_field = mapping.match_on[target_type]
            b_val = getattr(entity, b_field, None)
            if b_val is not None:
                # Look for a matching entity in graph_a
                matched = False
                for existing in result._entities.values():
                    if isinstance(existing, target_type):
                        a_val = getattr(existing, a_field, None)
                        if a_val == b_val:
                            # Merge: copy non-overlapping properties
                            _merge_properties(existing, entity, mapping.properties)
                            matched = True
                            break
                if matched:
                    continue

        # No match — add with a prefixed id to avoid collisions
        new_id = f"b:{entity.id}" if entity.id in result._entities else entity.id
        # Pydantic models need model_copy for id change
        if new_id != entity.id:
            entity = entity.model_copy(update={"id": new_id})
        result._entities[new_id] = entity

    # Copy connections from both graphs
    result._connections.extend(graph_a._connections)
    result._connections.extend(graph_b._connections)

    # Rebuild indexes so queries, traversal, and algorithms work
    for eid, entity in result._entities.items():
        for cls in type(entity).__mro__:
            if cls is Entity or issubclass(cls, Entity):
                result._by_type[cls].add(eid)
    for stored in result._connections:
        result._outgoing[stored.source_id].append(stored)
        result._incoming[stored.target_id].append(stored)

    return result


def _merge_properties(
    target: Entity,
    source: Entity,
    property_map: dict[str, str],
) -> None:
    """Copy properties from source to target using the property mapping."""
    reverse_map = {v: k for k, v in property_map.items()}
    for fname in type(source).model_fields:
        if fname == "id":
            continue
        mapped_name = reverse_map.get(fname, fname)
        source_val = getattr(source, fname, None)
        target_val = getattr(target, mapped_name, None)
        if source_val is not None and target_val is None:
            with contextlib.suppress(AttributeError, ValueError):
                setattr(target, mapped_name, source_val)
