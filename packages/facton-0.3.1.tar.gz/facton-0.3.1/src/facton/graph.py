"""Graph — the primary interface for storing and querying knowledge."""

from __future__ import annotations

from collections import defaultdict
from typing import TYPE_CHECKING, Any

from facton.connection import Connection
from facton.constraint import Constraint, Unique
from facton.entity import Entity
from facton.query import QueryBuilder
from facton.relation import Relation

if TYPE_CHECKING:
    from facton.backends.protocol import StorageBackend
    from facton.transaction import ReadTransaction, Transaction


from facton.temporal import TemporalMixin


class Graph(TemporalMixin):
    """A knowledge graph that stores entities, connections, and relations.

    Provides CRUD operations, traversal, and query capabilities::

        g = Graph()
        g.add(alice)
        g.connect(alice, bob, Knows(since=2019))
    """

    def __init__(self, *, backend: StorageBackend | None = None) -> None:
        self._entities: dict[str, Entity] = {}
        self._connections: list[_StoredConnection] = []
        self._outgoing: dict[str, list[_StoredConnection]] = defaultdict(list)
        self._incoming: dict[str, list[_StoredConnection]] = defaultdict(list)
        self._by_type: dict[type, set[str]] = defaultdict(set)
        self._relations: list[Relation] = []
        self._rules: dict[str, Any] = {}
        self._decorated_rules: list[Any] = []
        self._backend: StorageBackend | None = backend
        self._init_temporal()

    # --- CRUD ---

    def add(self, entity: Entity) -> Entity:
        """Add an entity to the graph."""
        if entity.id in self._entities:
            msg = f"Entity with id {entity.id!r} already exists"
            raise ValueError(msg)
        self._check_entity_constraints(entity)
        self._entities[entity.id] = entity
        for cls in type(entity).__mro__:
            if cls is Entity or issubclass(cls, Entity):
                self._by_type[cls].add(entity.id)
        if self._backend is not None:
            self._backend.save(entity)
        self._record_change(entity.id, "add", entity)
        return entity

    def get[T: Entity](self, kind: type[T], id: str) -> T | None:
        """Retrieve an entity by type and id."""
        entity = self._entities.get(id)
        if entity is not None and isinstance(entity, kind):
            return entity
        return None

    def save(self, entity: Entity) -> None:
        """Persist updates to an existing entity."""
        if entity.id not in self._entities:
            msg = f"Entity with id {entity.id!r} not found"
            raise ValueError(msg)
        self._check_entity_constraints(entity, exclude_id=entity.id)
        self._entities[entity.id] = entity
        if self._backend is not None:
            self._backend.save(entity)
        self._record_change(entity.id, "save", entity)

    def remove(self, entity: Entity | str) -> None:
        """Remove an entity and its connections from the graph."""
        entity_id = entity if isinstance(entity, str) else entity.id
        if entity_id not in self._entities:
            msg = f"Entity with id {entity_id!r} not found"
            raise ValueError(msg)
        existing = self._entities.pop(entity_id)
        for cls in type(existing).__mro__:
            if cls is Entity or issubclass(cls, Entity):
                self._by_type.get(cls, set()).discard(entity_id)
        if self._backend is not None:
            self._backend.delete(entity_id)
        self._record_change(entity_id, "remove", None)
        removed = [
            c
            for c in self._connections
            if c.source_id == entity_id or c.target_id == entity_id
        ]
        for c in removed:
            self._outgoing[c.source_id].remove(c)
            self._incoming[c.target_id].remove(c)
        self._connections = [
            c
            for c in self._connections
            if c.source_id != entity_id and c.target_id != entity_id
        ]

    # --- Connections ---

    def connect[S: Entity, T: Entity, C: Connection](
        self,
        source: S,
        target: T,
        connection: C,
    ) -> C:
        """Create a directed connection between two entities."""
        if source.id not in self._entities:
            msg = f"Source entity {source.id!r} not found"
            raise ValueError(msg)
        if target.id not in self._entities:
            msg = f"Target entity {target.id!r} not found"
            raise ValueError(msg)
        conn_type = type(connection)
        src_type = getattr(conn_type, "source_type", None)
        tgt_type = getattr(conn_type, "target_type", None)
        if src_type is not None and not isinstance(source, src_type):
            msg = (
                f"{conn_type.__name__} expects source type"
                f" {src_type.__name__}, got {type(source).__name__}"
            )
            raise TypeError(msg)
        if tgt_type is not None and not isinstance(target, tgt_type):
            msg = (
                f"{conn_type.__name__} expects target type"
                f" {tgt_type.__name__}, got {type(target).__name__}"
            )
            raise TypeError(msg)
        self._check_connection_constraints(source.id, target.id, connection)
        self._check_duplicate_connection(source.id, target.id, connection)
        stored = _StoredConnection(
            source_id=source.id,
            target_id=target.id,
            connection=connection,
        )
        self._connections.append(stored)
        self._outgoing[source.id].append(stored)
        self._incoming[target.id].append(stored)
        if self._backend is not None:
            self._backend.save_connection(source.id, target.id, connection)
        return connection

    def disconnect[S: Entity, T: Entity](
        self,
        source: S,
        target: T,
        connection_type: type[Connection[S, T]],
    ) -> None:
        """Remove connections of a given type between two entities."""
        to_remove = [
            c
            for c in self._connections
            if (
                c.source_id == source.id
                and c.target_id == target.id
                and isinstance(c.connection, connection_type)
            )
        ]
        for c in to_remove:
            self._connections.remove(c)
            self._outgoing[c.source_id].remove(c)
            self._incoming[c.target_id].remove(c)
        if self._backend is not None and to_remove:
            self._backend.delete_connection(source.id, target.id, connection_type)

    def connections_of(
        self,
        entity: Entity | str,
        connection_type: type[Connection[Any, Any]] | None = None,
    ) -> list[_StoredConnection]:
        """Return all connections involving an entity."""
        entity_id = entity if isinstance(entity, str) else entity.id
        seen: set[int] = set()
        results: list[_StoredConnection] = []
        for c in self._outgoing.get(entity_id, ()):
            if connection_type is None or isinstance(c.connection, connection_type):
                seen.add(id(c))
                results.append(c)
        for c in self._incoming.get(entity_id, ()):
            if id(c) not in seen and (
                connection_type is None or isinstance(c.connection, connection_type)
            ):
                results.append(c)
        return results

    # --- Relations ---

    def relate(self, relation: Relation) -> Relation:
        """Add an n-ary relation to the graph."""
        self._relations.append(relation)
        if self._backend is not None:
            self._backend.save_relation(relation)
        return relation

    # --- Query ---

    def query[T: Entity](self, kind: type[T]) -> QueryBuilder[T]:
        """Start a query for entities of a given type (including subtypes).

        Returns a ``QueryBuilder`` that supports fluent chaining::

            g.query(Person).where(lambda p: p.age > 25).all()
        """
        return QueryBuilder(self, kind)

    # --- Traversal ---

    def traverse[T: Entity](
        self,
        start: T | str,
        connection_type: type[Connection[Any, Any]],
        *,
        depth: int | tuple[int, int] = 1,
    ) -> list[Entity]:
        """Traverse the graph following connections of a given type.

        ``depth`` can be a single int (exact depth) or a ``(min, max)``
        tuple for a range of hop counts.
        """
        start_id = start if isinstance(start, str) else start.id
        if isinstance(depth, int):
            min_depth, max_depth = 1, depth
        else:
            min_depth, max_depth = depth

        visited: set[str] = {start_id}
        current_frontier: set[str] = {start_id}
        results: list[Entity] = []

        for current_depth in range(1, max_depth + 1):
            next_frontier: set[str] = set()
            for entity_id in current_frontier:
                for stored in self._get_connections_from(entity_id, connection_type):
                    if stored.target_id not in visited:
                        visited.add(stored.target_id)
                        next_frontier.add(stored.target_id)
                # Also follow reverse direction
                for stored in self._get_connections_to(entity_id, connection_type):
                    if stored.source_id not in visited:
                        visited.add(stored.source_id)
                        next_frontier.add(stored.source_id)

            if current_depth >= min_depth:
                for eid in next_frontier:
                    entity = self._entities.get(eid)
                    if entity is not None:
                        results.append(entity)

            current_frontier = next_frontier
            if not current_frontier:
                break

        return results

    # --- Rules ---

    def add_rule(self, name: str, *, when: Any, then: Any) -> None:
        """Register a declarative inference rule."""
        self._rules[name] = {"when": when, "then": then}

    def run_rules(self) -> None:
        """Execute all registered rules (both decorated and declarative)."""
        for rule_fn in self._decorated_rules:
            rule_fn(self)

        for rule_spec in self._rules.values():
            matches = rule_spec["when"](self)
            produce = rule_spec["then"]
            if matches is not None:
                for match in matches:
                    result = produce(match)
                    if result is not None:
                        source, target, conn = result
                        self.derive(source, target, conn)

    def register_rule(self, fn: Any) -> None:
        """Register a decorated @rule function for execution."""
        self._decorated_rules.append(fn)

    # --- Transactions ---

    def transaction(self) -> Transaction:
        """Start a write transaction with atomic commit/rollback."""
        from facton.transaction import Transaction

        return Transaction(self)

    def read(self) -> ReadTransaction:
        """Start a read-only snapshot transaction."""
        from facton.transaction import ReadTransaction

        return ReadTransaction(self)

    # --- Serialization (delegated to facton.serialization) ---

    def to_dict(self) -> dict[str, Any]:
        """Serialize the graph to a self-describing, lossless dict."""
        from facton.serialization import graph_to_dict

        return graph_to_dict(self)

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        *,
        type_registry: dict[str, type] | None = None,
    ) -> Graph:
        """Restore a graph from a dict produced by ``to_dict()``."""
        from facton.serialization import graph_from_dict

        return graph_from_dict(data, type_registry=type_registry)

    def save_file(self, path: str | Any) -> None:
        """Save the graph to a JSON file."""
        from facton.serialization import save_file

        save_file(self, path)

    @classmethod
    def load_file(
        cls,
        path: str | Any,
        *,
        type_registry: dict[str, type] | None = None,
    ) -> Graph:
        """Load a graph from a JSON file created by ``save_file()``."""
        from facton.serialization import load_file

        return load_file(path, type_registry=type_registry)

    # --- Algorithms (delegated to facton.algorithms) ---

    def shortest_path(
        self,
        start: Entity | str,
        end: Entity | str,
        connection_type: type[Connection[Any, Any]],
    ) -> list[Entity] | None:
        """Find the shortest path between two entities via BFS."""
        from facton.algorithms import shortest_path

        return shortest_path(self, start, end, connection_type)

    def components(
        self,
        connection_type: type[Connection[Any, Any]] | None = None,
    ) -> list[set[str]]:
        """Find connected components (undirected)."""
        from facton.algorithms import components

        return components(self, connection_type)

    # --- Derived connections ---

    def derive[S: Entity, T: Entity](
        self,
        source: S | str,
        target: T | str,
        connection: Connection[S, T],
    ) -> Connection[S, T]:
        """Add a derived (inferred) connection to the graph.

        Derived connections are tagged so they can be distinguished from
        asserted facts.
        """
        source_id = source if isinstance(source, str) else source.id
        target_id = target if isinstance(target, str) else target.id
        self._check_duplicate_connection(source_id, target_id, connection)
        stored = _StoredConnection(
            source_id=source_id,
            target_id=target_id,
            connection=connection,
            derived=True,
        )
        self._connections.append(stored)
        self._outgoing[source_id].append(stored)
        self._incoming[target_id].append(stored)
        if self._backend is not None:
            self._backend.save_connection(
                source_id, target_id, connection, derived=True
            )
        return connection

    # --- Internal helpers ---

    def _get_entities_by_type[T: Entity](self, kind: type[T]) -> list[T]:
        """Return all entities matching a type (including subtypes)."""
        ids = self._by_type.get(kind, set())
        return [self._entities[eid] for eid in ids if eid in self._entities]  # type: ignore[misc]

    def _get_connections_from(
        self,
        entity_id: str,
        connection_type: type[Connection[Any, Any]],
    ) -> list[_StoredConnection]:
        """Return outgoing connections of a given type from an entity."""
        return [
            c
            for c in self._outgoing.get(entity_id, ())
            if isinstance(c.connection, connection_type)
        ]

    def _get_connections_to(
        self,
        entity_id: str,
        connection_type: type[Connection[Any, Any]],
    ) -> list[_StoredConnection]:
        """Return incoming connections of a given type to an entity."""
        return [
            c
            for c in self._incoming.get(entity_id, ())
            if isinstance(c.connection, connection_type)
        ]

    def _check_entity_constraints(
        self,
        entity: Entity,
        *,
        exclude_id: str | None = None,
    ) -> None:
        """Validate uniqueness constraints before adding/saving an entity."""
        entity_type = type(entity)
        existing = [
            e
            for e in self._entities.values()
            if isinstance(e, entity_type) and e.id != exclude_id
        ]

        for fname, finfo in entity_type.model_fields.items():
            extra = getattr(finfo, "json_schema_extra", None) or {}
            if extra.get("unique"):
                new_val = getattr(entity, fname)
                if new_val is None:
                    continue
                for other in existing:
                    if getattr(other, fname) == new_val:
                        msg = (
                            f"Unique constraint violated: {entity_type.__name__}"
                            f".{fname} = {new_val!r} already exists"
                        )
                        raise ValueError(msg)

        meta = getattr(entity_type, "Meta", None)
        constraints = getattr(meta, "constraints", []) if meta else []
        for constraint in constraints:
            if isinstance(constraint, Unique):
                new_vals = tuple(getattr(entity, f) for f in constraint.fields)
                if any(v is None for v in new_vals):
                    continue
                for other in existing:
                    other_vals = tuple(getattr(other, f) for f in constraint.fields)
                    if new_vals == other_vals:
                        msg = (
                            f"Unique constraint violated on"
                            f" {entity_type.__name__}"
                            f" for fields {constraint.fields}"
                        )
                        raise ValueError(msg)

    def _check_connection_constraints(
        self,
        source_id: str,
        target_id: str,
        connection: Connection[Any, Any],
    ) -> None:
        """Validate cardinality constraints before adding a connection."""
        conn_type = type(connection)
        meta = getattr(conn_type, "Meta", None)
        constraints = getattr(meta, "constraints", []) if meta else []

        for constraint in constraints:
            if not isinstance(constraint, Constraint):
                continue
            if constraint.kind == "max_per_source":
                matching = [
                    c
                    for c in self._connections
                    if c.source_id == source_id and isinstance(c.connection, conn_type)
                ]
                if constraint.predicate:
                    matching = [
                        c for c in matching if constraint.predicate(c.connection)
                    ]
                if len(matching) >= constraint.limit:
                    msg = (
                        f"Cardinality constraint violated:"
                        f" max {constraint.limit} {conn_type.__name__}"
                        f" per source"
                    )
                    raise ValueError(msg)
            elif constraint.kind == "max_per_target":
                matching = [
                    c
                    for c in self._connections
                    if c.target_id == target_id and isinstance(c.connection, conn_type)
                ]
                if constraint.predicate:
                    matching = [
                        c for c in matching if constraint.predicate(c.connection)
                    ]
                if len(matching) >= constraint.limit:
                    msg = (
                        f"Cardinality constraint violated:"
                        f" max {constraint.limit} {conn_type.__name__}"
                        f" per target"
                    )
                    raise ValueError(msg)

    def _check_duplicate_connection(
        self,
        source_id: str,
        target_id: str,
        connection: Connection[Any, Any],
    ) -> None:
        """Reject duplicate connections when the type opts in."""
        conn_type = type(connection)
        if not getattr(conn_type, "unique_endpoints", False):
            return
        for stored in self._outgoing.get(source_id, ()):
            if stored.target_id == target_id and isinstance(
                stored.connection, conn_type
            ):
                msg = (
                    f"Duplicate {conn_type.__name__} connection"
                    f" from {source_id!r} to {target_id!r}"
                    f" already exists"
                )
                raise ValueError(msg)


class _StoredConnection:
    """Internal storage for a connection with its endpoint ids."""

    __slots__ = ("connection", "derived", "source_id", "target_id")

    def __init__(
        self,
        source_id: str,
        target_id: str,
        connection: Connection[Any, Any],
        *,
        derived: bool = False,
    ) -> None:
        self.source_id = source_id
        self.target_id = target_id
        self.connection = connection
        self.derived = derived
