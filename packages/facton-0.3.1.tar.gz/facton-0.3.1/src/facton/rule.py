"""Rule — inference rules that derive new facts."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any


def rule(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Mark a function as a graph inference rule.

    Decorated functions are stored in the graph and their outputs
    are tagged as derived facts.
    """
    fn._is_graph_rule = True  # type: ignore[attr-defined]
    return fn
