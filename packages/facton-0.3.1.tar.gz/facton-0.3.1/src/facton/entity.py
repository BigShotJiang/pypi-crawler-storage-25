"""Entity — the base class for graph nodes."""

from __future__ import annotations

from typing import Any
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field, field_validator

from facton.fact import Fact, wrap_fact

# Temporary stash for annotations from Fact instances passed to __init__.
# Keyed by id(instance); cleaned up in model_post_init.
_pending_fact_annotations: dict[int, dict[str, dict[str, Any]]] = {}


class Entity(BaseModel):
    """A node in the knowledge graph.

    Subclass this to define typed entities::

        class Person(Entity):
            name: str
            age: int

    Every field value is automatically wrapped in a ``Fact[T]`` so that
    property-level annotations work::

        alice.name.annotate(source="hr_system")

    The ``id`` field is optional — if omitted, a UUID is generated
    automatically::

        alice = Person(name="Alice", age=30)  # id auto-generated
        bob = Person(id="bob", name="Bob", age=25)  # explicit id
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    id: str = Field(default_factory=lambda: uuid4().hex)

    @field_validator("id", mode="before")
    @classmethod
    def _coerce_empty_id(cls, v: Any) -> str:
        if v is None or v == "":
            return uuid4().hex
        return str(v)

    _entity_annotations: dict[str, Any]

    def __init__(self, **data: Any) -> None:
        # Capture annotations from Fact instances before Pydantic coerces them.
        pending: dict[str, dict[str, Any]] = {}
        for key, value in data.items():
            if isinstance(value, Fact) and value._annotations:
                pending[key] = dict(value._annotations)
        _pending_fact_annotations[id(self)] = pending
        super().__init__(**data)

    def model_post_init(self, __context: Any) -> None:
        self._entity_annotations = {}
        pending = _pending_fact_annotations.pop(id(self), {})
        # Wrap field values in Fact[T] instances
        for field_name in type(self).model_fields:
            if field_name == "id":
                continue
            value = object.__getattribute__(self, field_name)
            wrapped = wrap_fact(value)
            if wrapped is not value:
                object.__setattr__(self, field_name, wrapped)
            if field_name in pending:
                fact = object.__getattribute__(self, field_name)
                fact._annotations.update(pending[field_name])

    def __setattr__(self, name: str, value: Any) -> None:
        if name in type(self).model_fields and name != "id":
            value = wrap_fact(value)
        super().__setattr__(name, value)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Entity):
            return NotImplemented
        return self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)

    def annotate(self, **kwargs: Any) -> None:
        """Attach metadata to this entity."""
        self._entity_annotations.update(kwargs)

    @property
    def entity_annotations(self) -> dict[str, Any]:
        """Return annotations on the entity itself."""
        return dict(self._entity_annotations)
