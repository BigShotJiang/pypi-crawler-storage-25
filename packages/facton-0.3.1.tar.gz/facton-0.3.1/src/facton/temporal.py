"""Temporal tracking — change log and point-in-time snapshots."""

from __future__ import annotations

import copy
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from facton.entity import Entity

if TYPE_CHECKING:
    from facton.graph import Graph


class ChangeRecord:
    """A single mutation recorded in the change log."""

    __slots__ = ("data", "entity_id", "operation", "timestamp")

    def __init__(
        self,
        entity_id: str,
        operation: str,
        data: Entity | None,
        timestamp: datetime,
    ) -> None:
        self.entity_id = entity_id
        self.operation = operation
        self.data = data
        self.timestamp = timestamp


class VersionedEntity:
    """An entity at a specific point in time."""

    __slots__ = ("data", "timestamp")

    def __init__(self, data: Entity, timestamp: datetime) -> None:
        self.data = data
        self.timestamp = timestamp


class TemporalMixin:
    """Mixin that adds temporal tracking to a Graph.

    Tracks system time (when mutations were recorded) via a change log.
    Supports ``at()``, ``history()``, and ``snapshot()`` operations.
    """

    def _init_temporal(self) -> None:
        self._change_log: list[ChangeRecord] = []
        self._snapshots: dict[str, datetime] = {}

    def _record_change(
        self,
        entity_id: str,
        operation: str,
        data: Entity | None,
    ) -> None:
        """Record a mutation in the change log."""
        record = ChangeRecord(
            entity_id=entity_id,
            operation=operation,
            data=copy.deepcopy(data) if data is not None else None,
            timestamp=datetime.now(UTC),
        )
        self._change_log.append(record)

    def history(self, entity_id: str) -> list[VersionedEntity]:
        """Return the full change history for an entity."""
        results = []
        for record in self._change_log:
            if record.entity_id == entity_id and record.data is not None:
                results.append(
                    VersionedEntity(data=record.data, timestamp=record.timestamp)
                )
        return results

    def at(self, timestamp: str | datetime) -> Graph:
        """Return a read-only snapshot of the graph at a given timestamp.

        Replays the change log up to the specified time to reconstruct
        the graph state.
        """
        if isinstance(timestamp, str):
            timestamp = datetime.fromisoformat(timestamp)

        from facton.graph import Graph

        snapshot = Graph.__new__(Graph)
        snapshot._entities = {}
        snapshot._connections = []
        snapshot._relations = []
        snapshot._rules = {}
        snapshot._backend = None
        snapshot._change_log = []
        snapshot._snapshots = {}

        for record in self._change_log:
            if record.timestamp > timestamp:
                break
            if record.operation in ("add", "save") and record.data is not None:
                snapshot._entities[record.entity_id] = copy.deepcopy(record.data)
            elif record.operation == "remove":
                snapshot._entities.pop(record.entity_id, None)

        return snapshot

    def snapshot(self, name: str) -> None:
        """Create a named snapshot at the current point in time."""
        self._snapshots[name] = datetime.now(UTC)

    def at_snapshot(self, name: str) -> Graph:
        """Return the graph state at a named snapshot."""
        if name not in self._snapshots:
            msg = f"Snapshot {name!r} not found"
            raise ValueError(msg)
        return self.at(self._snapshots[name])
