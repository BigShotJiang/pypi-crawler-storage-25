"""Query builder for fluent graph queries."""

from __future__ import annotations

from collections.abc import Callable, Iterator
from typing import TYPE_CHECKING, Any

from facton.connection import Connection
from facton.entity import Entity

if TYPE_CHECKING:
    from facton.graph import Graph


class QueryResult:
    """A single row from a query result, accessible by bound names."""

    def __init__(self, data: dict[str, Any]) -> None:
        self._data = data

    def __getattr__(self, name: str) -> Any:
        try:
            return self._data[name]
        except KeyError:
            msg = f"No field {name!r} in query result"
            raise AttributeError(msg) from None


class QueryBuilder[T: Entity]:
    """Fluent query builder for graph entities.

    Supports chaining ``.where()``, ``.connected_to()``, and ``.select()``::

        results = (
            g.query(Person)
            .where(lambda p: p.age > 25)
            .connected_to(Organization, via=WorksAt, bind="job")
            .select("person", "job.target", "job.role")
        )
    """

    def __init__(self, graph: Graph, kind: type[T]) -> None:
        self._graph = graph
        self._kind = kind
        self._filters: list[Callable[[T], bool]] = []
        self._joins: list[_JoinSpec] = []
        self._select_fields: list[str] | None = None

    def where(self, predicate: Callable[[T], bool]) -> QueryBuilder[T]:
        """Filter entities by a predicate."""
        self._filters.append(predicate)
        return self

    def connected_to(
        self,
        target_kind: type[Entity],
        *,
        via: type[Connection[Any, Any]],
        bind: str = "connection",
    ) -> QueryBuilder[T]:
        """Join with connected entities of a given type."""
        self._joins.append(_JoinSpec(target_kind=target_kind, via=via, bind=bind))
        return self

    def select(self, *fields: str) -> QueryBuilder[T]:
        """Select specific fields from the result."""
        self._select_fields = list(fields)
        return self

    def __iter__(self) -> Iterator[T | QueryResult]:
        return iter(self._execute())

    def __len__(self) -> int:
        return len(self._execute())

    def all(self) -> list[T | QueryResult]:
        """Execute and return all results."""
        return self._execute()

    def first(self) -> T | QueryResult | None:
        """Execute and return the first result, or None."""
        results = self._execute()
        return results[0] if results else None

    def count(self) -> int:
        """Return the count of matching entities."""
        return len(self._execute())

    def group_by(self, key: Callable[[T], Any]) -> GroupedQuery[T]:
        """Group results by a key function."""
        entities = self._execute()
        groups: dict[Any, list[Any]] = {}
        for entity in entities:
            k = key(entity)
            groups.setdefault(k, []).append(entity)
        return GroupedQuery(groups)

    def _execute(self) -> list[Any]:
        # Get base entities
        entities = self._graph._get_entities_by_type(self._kind)

        # Apply filters
        for f in self._filters:
            entities = [e for e in entities if f(e)]

        if not self._joins:
            return entities

        # Apply joins
        results: list[QueryResult] = []
        for entity in entities:
            join_matches = self._resolve_joins(entity)
            if join_matches is not None:
                for match in join_matches:
                    row = {"entity": entity, self._kind.__name__.lower(): entity}
                    row.update(match)
                    results.append(QueryResult(row))

        return results

    def _resolve_joins(self, entity: T) -> list[dict[str, Any]] | None:
        """Resolve all join specs for a single entity."""
        current_matches: list[dict[str, Any]] = [{}]

        for join in self._joins:
            next_matches: list[dict[str, Any]] = []
            for existing in current_matches:
                connections = self._graph._get_connections_from(entity.id, join.via)
                for stored in connections:
                    target = self._graph._entities.get(stored.target_id)
                    if target is not None and isinstance(target, join.target_kind):
                        match = dict(existing)
                        match[join.bind] = stored.connection
                        match[f"{join.bind}.target"] = target
                        match[f"{join.bind}.source"] = entity
                        # Also expose connection fields directly
                        for fname in type(stored.connection).model_fields:
                            match[f"{join.bind}.{fname}"] = getattr(
                                stored.connection, fname
                            )
                        next_matches.append(match)
            if not next_matches:
                return None
            current_matches = next_matches

        return current_matches


class _JoinSpec:
    """Internal spec for a join in the query builder."""

    __slots__ = ("bind", "target_kind", "via")

    def __init__(
        self,
        target_kind: type[Entity],
        via: type[Connection[Any, Any]],
        bind: str,
    ) -> None:
        self.target_kind = target_kind
        self.via = via
        self.bind = bind


class GroupedQuery[T]:
    """Result of a group_by operation, supporting aggregation."""

    def __init__(self, groups: dict[Any, list[T]]) -> None:
        self._groups = groups

    def aggregate(self, fn: Callable[[list[Any]], int | float]) -> AggregatedQuery:
        """Apply an aggregation function to each group."""
        results = []
        for key, items in self._groups.items():
            results.append(AggregatedRow(key=key, value=fn(items)))
        return AggregatedQuery(results)


class AggregatedRow:
    """A single row in an aggregated result."""

    __slots__ = ("key", "value")

    def __init__(self, key: Any, value: int | float) -> None:
        self.key = key
        self.value = value


class AggregatedQuery:
    """Result of an aggregation, supporting ordering."""

    def __init__(self, rows: list[AggregatedRow]) -> None:
        self._rows = rows

    def order_by(
        self, field: str = "value", *, descending: bool = False
    ) -> AggregatedQuery:
        """Sort results by key or value."""
        self._rows.sort(key=lambda r: getattr(r, field), reverse=descending)
        return self

    def all(self) -> list[AggregatedRow]:
        """Return all aggregated rows."""
        return list(self._rows)

    def __iter__(self) -> Iterator[AggregatedRow]:
        return iter(self._rows)

    def __len__(self) -> int:
        return len(self._rows)


def count(items: list[Any]) -> int:
    """Aggregation function: count items in a group."""
    return len(items)
