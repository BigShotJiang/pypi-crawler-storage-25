"""Constraint — structural constraints for entities and connections."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field


@dataclass(frozen=True)
class Unique:
    """Composite uniqueness constraint across multiple fields."""

    fields: tuple[str, ...]

    def __init__(self, *fields: str) -> None:
        object.__setattr__(self, "fields", fields)


@dataclass(frozen=True)
class Constraint:
    """A structural constraint on connections or entities."""

    kind: str
    limit: int
    predicate: Callable[..., bool] | None = field(default=None)

    @classmethod
    def max_per_source(
        cls,
        limit: int,
        *,
        where: Callable[..., bool] | None = None,
    ) -> Constraint:
        """At most ``limit`` connections from a single source matching ``where``."""
        return cls(kind="max_per_source", limit=limit, predicate=where)

    @classmethod
    def max_per_target(
        cls,
        limit: int,
        *,
        where: Callable[..., bool] | None = None,
    ) -> Constraint:
        """At most ``limit`` connections to a single target matching ``where``."""
        return cls(kind="max_per_target", limit=limit, predicate=where)
