"""Graph algorithms — shortest path, connected components."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from facton.connection import Connection
from facton.entity import Entity

if TYPE_CHECKING:
    from facton.graph import Graph


def shortest_path(
    graph: Graph,
    start: Entity | str,
    end: Entity | str,
    connection_type: type[Connection[Any, Any]],
) -> list[Entity] | None:
    """Find the shortest path between two entities via BFS.

    Returns a list of entities from start to end (inclusive), or
    ``None`` if no path exists.
    """
    start_id = start if isinstance(start, str) else start.id
    end_id = end if isinstance(end, str) else end.id
    if start_id == end_id:
        entity = graph._entities.get(start_id)
        return [entity] if entity else None

    visited: set[str] = {start_id}
    queue: list[tuple[str, list[str]]] = [(start_id, [start_id])]
    while queue:
        current_id, path = queue.pop(0)
        for stored in graph._outgoing.get(current_id, ()):
            if isinstance(stored.connection, connection_type):
                nid = stored.target_id
                if nid == end_id:
                    return [graph._entities[eid] for eid in [*path, nid]]
                if nid not in visited:
                    visited.add(nid)
                    queue.append((nid, [*path, nid]))
        for stored in graph._incoming.get(current_id, ()):
            if isinstance(stored.connection, connection_type):
                nid = stored.source_id
                if nid == end_id:
                    return [graph._entities[eid] for eid in [*path, nid]]
                if nid not in visited:
                    visited.add(nid)
                    queue.append((nid, [*path, nid]))
    return None


def components(
    graph: Graph,
    connection_type: type[Connection[Any, Any]] | None = None,
) -> list[set[str]]:
    """Find connected components (undirected).

    Returns a list of sets, each containing the entity ids of one
    component. If ``connection_type`` is given, only those edges are
    considered.
    """
    remaining = set(graph._entities.keys())
    result: list[set[str]] = []
    while remaining:
        seed = next(iter(remaining))
        component: set[str] = set()
        frontier = [seed]
        while frontier:
            eid = frontier.pop()
            if eid in component:
                continue
            component.add(eid)
            for stored in graph._outgoing.get(eid, ()):
                if (
                    connection_type is None
                    or isinstance(stored.connection, connection_type)
                ) and stored.target_id not in component:
                    frontier.append(stored.target_id)
            for stored in graph._incoming.get(eid, ()):
                if (
                    connection_type is None
                    or isinstance(stored.connection, connection_type)
                ) and stored.source_id not in component:
                    frontier.append(stored.source_id)
        result.append(component)
        remaining -= component
    return result
