"""Connection — typed binary edges between entities."""

from __future__ import annotations

from typing import Any, ClassVar

from pydantic import BaseModel, ConfigDict

from facton.entity import Entity
from facton.fact import Fact, wrap_fact

# Temporary stash for annotations from Fact instances passed to __init__.
_pending_fact_annotations: dict[int, dict[str, dict[str, Any]]] = {}


class Connection[Source: Entity, Target: Entity](BaseModel):
    """A directed edge between two entities.

    Declare endpoint types using generic syntax::

        class Knows(Connection[Person, Person]):
            since: int | None = None
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    source_type: ClassVar[type[Entity]]
    target_type: ClassVar[type[Entity]]

    _connection_annotations: dict[str, Any]

    def __init__(self, **data: Any) -> None:
        # Capture annotations from Fact instances before Pydantic coerces them.
        pending: dict[str, dict[str, Any]] = {}
        for key, value in data.items():
            if isinstance(value, Fact) and value._annotations:
                pending[key] = dict(value._annotations)
        _pending_fact_annotations[id(self)] = pending
        super().__init__(**data)

    def model_post_init(self, __context: Any) -> None:
        self._connection_annotations = {}
        pending = _pending_fact_annotations.pop(id(self), {})
        for field_name in type(self).model_fields:
            value = object.__getattribute__(self, field_name)
            wrapped = wrap_fact(value)
            if wrapped is not value:
                object.__setattr__(self, field_name, wrapped)
            if field_name in pending:
                fact = object.__getattribute__(self, field_name)
                fact._annotations.update(pending[field_name])

    def __setattr__(self, name: str, value: Any) -> None:
        if name in type(self).model_fields:
            value = wrap_fact(value)
        super().__setattr__(name, value)

    def annotate(self, **kwargs: Any) -> None:
        """Attach metadata to this connection."""
        self._connection_annotations.update(kwargs)

    @property
    def connection_annotations(self) -> dict[str, Any]:
        """Return annotations on the connection itself."""
        return dict(self._connection_annotations)

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        # Extract Source and Target from the parametrized parent in the MRO.
        # Pydantic rewrites __orig_bases__ after __init_subclass__, so we
        # look at __pydantic_generic_metadata__ on MRO entries instead.
        for base in cls.__mro__:
            pgm = getattr(base, "__pydantic_generic_metadata__", None)
            if (
                pgm
                and pgm.get("origin") is Connection
                and len(pgm.get("args", ())) == 2
            ):
                args = pgm["args"]
                if all(isinstance(a, type) for a in args):
                    cls.source_type = args[0]
                    cls.target_type = args[1]
                    break
