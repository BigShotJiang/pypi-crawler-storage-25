"""Relation and Role — n-ary relationships with named roles."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict

from facton.entity import Entity


class Role[T: Entity]:
    """Marker type for a named role in an n-ary relation.

    Used as a type annotation on ``Relation`` fields::

        class Surgery(Relation):
            patient: Role[Person]
            surgeon: Role[Person]
    """

    def __init__(self, entity: T) -> None:
        self.entity = entity


class Relation(BaseModel):
    """An n-ary relationship with named, typed roles.

    Unlike ``Connection`` which is binary and directional, ``Relation``
    supports any number of typed participants.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    _relation_annotations: dict[str, Any]

    def model_post_init(self, __context: Any) -> None:
        self._relation_annotations = {}

    def annotate(self, **kwargs: Any) -> None:
        """Attach metadata to this relation."""
        self._relation_annotations.update(kwargs)

    @property
    def relation_annotations(self) -> dict[str, Any]:
        """Return annotations on the relation itself."""
        return dict(self._relation_annotations)
