"""Fact — a value that carries annotation metadata."""

from __future__ import annotations

from typing import Any, ClassVar


class FactMeta(type):
    """Metaclass that creates Fact[T] subclasses inheriting from T."""

    _cache: ClassVar[dict[type, type]] = {}

    def __getitem__(cls, wrapped_type: type) -> type:
        if wrapped_type in cls._cache:
            return cls._cache[wrapped_type]

        fact_cls = type(
            f"Fact[{wrapped_type.__name__}]",
            (cls, wrapped_type),
            {"_wrapped_type": wrapped_type},
        )
        cls._cache[wrapped_type] = fact_cls
        return fact_cls


class Fact(metaclass=FactMeta):
    """A value that carries annotations.

    ``Fact[str]`` inherits from both ``Fact`` and ``str``, so all ``str``
    methods work transparently while ``.annotate()`` and ``.annotations``
    provide metadata access.
    """

    _wrapped_type: type
    _annotations: dict[str, Any]

    def __new__(cls, value: Any = None, **kwargs: Any) -> Fact:
        if hasattr(cls, "_wrapped_type"):
            instance = cls._wrapped_type.__new__(cls, value)
        elif value is not None:
            # Auto-detect type when called as Fact(value) directly.
            vtype = type(value)
            fact_type = Fact[vtype]
            instance = vtype.__new__(fact_type, value)
        else:
            instance = super().__new__(cls)
        instance._annotations = kwargs
        return instance

    def annotate(self, **kwargs: Any) -> None:
        """Attach metadata to this fact."""
        self._annotations.update(kwargs)

    @property
    def annotations(self) -> dict[str, Any]:
        """Return a copy of the annotations on this fact."""
        return dict(self._annotations)


def wrap_fact(value: Any) -> Any:
    """Wrap a plain value in the corresponding Fact[T] type.

    Returns the value unchanged if it is ``None``, already a ``Fact``,
    or of a type that cannot be subclassed (e.g. ``NoneType``).
    """
    if value is None or isinstance(value, Fact):
        return value
    vtype = type(value)
    # Skip types that can't be subclassed or are containers
    if vtype in (list, dict, set, tuple):
        return value
    try:
        fact_type = Fact[vtype]
        return fact_type(value)
    except (TypeError, ValueError):
        return value
