"""Embedded — a value object owned by its parent entity."""

from __future__ import annotations

from pydantic import BaseModel


class Embedded(BaseModel):
    """A nested value object without its own identity.

    Use ``Embedded`` for structures that are owned by an ``Entity``
    and should not exist independently in the graph.
    """
