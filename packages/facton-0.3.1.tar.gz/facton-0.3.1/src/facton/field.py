"""Field descriptor for Entity and Connection properties."""

from __future__ import annotations

from typing import Any

from pydantic.fields import FieldInfo


def Field(
    default: Any = ...,
    *,
    ge: float | None = None,
    le: float | None = None,
    gt: float | None = None,
    lt: float | None = None,
    unique: bool = False,
    **kwargs: Any,
) -> Any:
    """Declare a field with constraints on an Entity or Connection.

    Wraps Pydantic's ``FieldInfo`` and adds graph-specific metadata
    such as ``unique``.
    """
    json_schema_extra = kwargs.pop("json_schema_extra", {}) or {}
    if unique:
        json_schema_extra["unique"] = True

    return FieldInfo(
        default=default,
        ge=ge,
        le=le,
        gt=gt,
        lt=lt,
        json_schema_extra=json_schema_extra,
        **kwargs,
    )
