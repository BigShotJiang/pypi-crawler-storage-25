"""Transaction support for atomic graph mutations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from facton.connection import Connection
from facton.entity import Entity

if TYPE_CHECKING:
    from facton.graph import Graph


class Transaction:
    """A write transaction that provides atomicity.

    All mutations within a transaction succeed together or fail
    together. Use as a context manager::

        with g.transaction() as tx:
            tx.add(alice)
            tx.add(bob)
            tx.connect(alice, bob, Knows())
    """

    def __init__(self, graph: Graph) -> None:
        self._graph = graph
        # Snapshot state for rollback
        self._snapshot_entities = dict(graph._entities)
        self._snapshot_connections = list(graph._connections)
        self._snapshot_relations = list(graph._relations)
        self._snapshot_outgoing = {k: list(v) for k, v in graph._outgoing.items()}
        self._snapshot_incoming = {k: list(v) for k, v in graph._incoming.items()}
        self._snapshot_by_type = {k: set(v) for k, v in graph._by_type.items()}
        self._committed = False

    def __enter__(self) -> Transaction:
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if exc_type is not None:
            # Rollback on exception
            self._graph._entities = self._snapshot_entities
            self._graph._connections = self._snapshot_connections
            self._graph._relations = self._snapshot_relations
            self._graph._outgoing = self._snapshot_outgoing  # type: ignore[assignment]
            self._graph._incoming = self._snapshot_incoming  # type: ignore[assignment]
            self._graph._by_type = self._snapshot_by_type  # type: ignore[assignment]

    # Delegate mutation methods to the graph
    def add(self, entity: Entity) -> Entity:
        """Add an entity within this transaction."""
        return self._graph.add(entity)

    def connect[S: Entity, T: Entity](
        self,
        source: S,
        target: T,
        connection: Connection[S, T],
    ) -> Connection[S, T]:
        """Connect entities within this transaction."""
        return self._graph.connect(source, target, connection)

    def save(self, entity: Entity) -> None:
        """Save an entity within this transaction."""
        self._graph.save(entity)

    def remove(self, entity: Entity | str) -> None:
        """Remove an entity within this transaction."""
        self._graph.remove(entity)

    def disconnect[S: Entity, T: Entity](
        self,
        source: S,
        target: T,
        connection_type: type[Connection[S, T]],
    ) -> None:
        """Disconnect entities within this transaction."""
        self._graph.disconnect(source, target, connection_type)


class ReadTransaction:
    """A read-only snapshot of the graph.

    Provides consistent reads for the duration of the block::

        with g.read() as snapshot:
            people = snapshot.query(Person).all()
    """

    def __init__(self, graph: Graph) -> None:
        # Create a shallow copy that shares immutable entity objects
        from collections import defaultdict

        from facton.graph import Graph as GraphCls

        self._snapshot = GraphCls.__new__(GraphCls)
        self._snapshot._entities = dict(graph._entities)
        self._snapshot._connections = list(graph._connections)
        self._snapshot._outgoing = defaultdict(
            list, {k: list(v) for k, v in graph._outgoing.items()}
        )
        self._snapshot._incoming = defaultdict(
            list, {k: list(v) for k, v in graph._incoming.items()}
        )
        self._snapshot._by_type = defaultdict(
            set, {k: set(v) for k, v in graph._by_type.items()}
        )
        self._snapshot._relations = list(graph._relations)
        self._snapshot._rules = dict(graph._rules)
        self._snapshot._decorated_rules = list(graph._decorated_rules)
        self._snapshot._backend = None
        self._snapshot._init_temporal()

    def __enter__(self) -> Graph:
        return self._snapshot

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        pass
