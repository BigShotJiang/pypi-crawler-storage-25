# switchy-sdk

Official Python SDK for the [Switchy AI](https://switchy.build) memory, knowledge-graph, and multi-model chat API.

## Install

```bash
pip install switchy-sdk
```

## Quick start

```python
from switchy import Switchy

client = Switchy(api_key="switchy_...")

response = client.chat.complete(
    model="anthropic/claude-sonnet-4",
    message="Summarise my recent project notes",
    memory={"enabled": True, "extractMemories": True},
)

print(response["message"]["content"])
```

## Streaming

```python
for chunk in client.chat.stream(
    model="openai/gpt-5",
    message="Write a haiku about memory",
):
    if chunk.get("type") == "token":
        print(chunk.get("content", ""), end="", flush=True)
```

## Async

```python
import asyncio
from switchy import AsyncSwitchy

async def main():
    async with AsyncSwitchy(api_key="switchy_...") as client:
        res = await client.chat.complete(
            model="anthropic/claude-sonnet-4",
            message="Hello",
        )
        print(res["message"]["content"])

asyncio.run(main())
```

## Memory

```python
# Create a namespace
client.namespaces.create(name="my-project")

# Store a memory frame
client.memory.create_frame(
    "my-project",
    content="User prefers dark mode and TypeScript",
    metadata={"source": "onboarding"},
)

# Contextual retrieval
relevant = client.memory.context("my-project", query="user preferences", limit=5)
```

## Knowledge graph

```python
client.knowledge_graph.create_entity(
    "my-project", name="AuthService", type="service"
)

client.knowledge_graph.create_relation(
    "my-project", source="AuthService", target="User", type="authenticates"
)
```

## Error handling

```python
from switchy import Switchy, SwitchyError, RateLimitError

try:
    client.chat.complete(model="openai/gpt-5", message="hi")
except RateLimitError as e:
    print(f"Rate limited, retry in {e.retry_after}s (limit={e.limit})")
except SwitchyError as e:
    print(f"API error: {e.code} — {e}")
```

## API reference

- `chat.complete(...)` — single-turn completion
- `chat.stream(...)` — SSE streaming iterator
- `models.list(featured=True)` — list available models (350+)
- `namespaces.{create,list,get,update,delete}` — memory namespace management
- `memory.{create_frame,list_frames,context,semantic,search,bridge,consolidate}` — memory operations
- `knowledge_graph.{create_entity,create_relation,query}` — graph operations
- `sessions.{create,list,get}` — session management

Full OpenAPI spec: https://switchy.build/api/v1/openapi.json

## License

MIT
