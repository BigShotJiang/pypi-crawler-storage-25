"""Exception types raised by the Switchy SDK."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional


class SwitchyError(Exception):
    """Base error for all SDK failures."""

    def __init__(
        self,
        message: str,
        code: str = "UNKNOWN",
        status: int = 0,
        details: Optional[Any] = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.status = status
        self.details = details

    def __repr__(self) -> str:
        return f"SwitchyError(code={self.code!r}, status={self.status}, message={self.args[0]!r})"


class RateLimitError(SwitchyError):
    """Raised when the API returns 429 Too Many Requests."""

    def __init__(self, message: str, details: Optional[dict] = None) -> None:
        super().__init__(message, "RATE_LIMIT_EXCEEDED", 429, details)
        details = details or {}
        self.retry_after: int = int(details.get("retryAfter") or 60)
        self.limit: Optional[int] = details.get("limit")
        reset_at = details.get("resetAt")
        self.reset_at: Optional[datetime] = (
            datetime.fromisoformat(reset_at.replace("Z", "+00:00")) if reset_at else None
        )
