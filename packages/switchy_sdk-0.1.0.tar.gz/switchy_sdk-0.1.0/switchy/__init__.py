"""Switchy AI Python SDK.

Install:
    pip install switchy-sdk

Usage:
    from switchy import Switchy
    client = Switchy(api_key="switchy_...")
    res = client.chat.complete(model="anthropic/claude-sonnet-4", message="Hello")
    print(res["message"]["content"])
"""

from .client import Switchy, AsyncSwitchy
from .errors import SwitchyError, RateLimitError

__version__ = "0.1.0"
__all__ = ["Switchy", "AsyncSwitchy", "SwitchyError", "RateLimitError"]
