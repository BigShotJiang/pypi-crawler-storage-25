"""Battle.net OAuth API client.

This module provides access to Battle.net OAuth endpoints,
including user information and authentication.
"""

from typing import Any, Dict

from ..api import BaseApi
from ..types import Locale, Region


class ApiResponse:
    """Wrapper for API responses with metadata."""

    data: Dict[str, Any]
    region: Region
    locale: Locale
    namespace: str


class BattlenetOAuthApi(BaseApi):
    """Battle.net OAuth API client.

    This class provides access to the Battle.net OAuth API endpoints.
    It handles authentication and request formatting for all OAuth related
    endpoints.

    Attributes:
        _client_id: The Blizzard API client ID.
        _client_secret: The Blizzard API client secret.
    """

    def __init__(self, client_id: str, client_secret: str) -> None:
        """Initialize the API client.

        Args:
            client_id: The Blizzard API client ID.
            client_secret: The Blizzard API client secret.
        """
        super().__init__(client_id, client_secret)

    def get_user_info(self, region: Region | str, access_token: str) -> dict[str, Any]:
        """Get basic information about the user associated with the current bearer token.

        Args:
            region: The region to query — either a ``Region`` enum member or
                a bare string (e.g. ``"us"`` or ``Region.US``). Bare strings
                are accepted for ergonomics and parity with the other game APIs.
            access_token: The OAuth access token.

        Returns:
            A dictionary containing user information.

        Raises:
            requests.HTTPError: If the API request fails (raised via
                ``response.raise_for_status()`` in ``BaseApi._make_request``).
        """
        resource = "/oauth/userinfo"
        query_params = {
            "access_token": access_token,
        }
        return super().get_oauth_resource(resource, region, query_params)
