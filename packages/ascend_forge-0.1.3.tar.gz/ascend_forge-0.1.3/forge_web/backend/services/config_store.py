"""Filesystem operations on the configs/ directory."""
import json
import os
from pathlib import Path

from forge.config import ConfigError, validate_config
from forge_web.backend.errors import ApiError
from forge_web.backend.schemas import RawConfig, RepoDetail, RepoSummary


def _config_dir() -> Path:
    d = os.environ.get("FORGE_CONFIG_DIR")
    if d:
        return Path(d)
    return Path.cwd() / "configs"


def _config_path(name: str) -> Path:
    return _config_dir() / f"{name}.json"


def list_repos() -> list[RepoSummary]:
    out: list[RepoSummary] = []
    cdir = _config_dir()
    if not cdir.is_dir():
        return out
    for path in sorted(cdir.glob("*.json")):
        name = path.stem
        try:
            cfg = json.loads(path.read_text())
        except (OSError, json.JSONDecodeError) as e:
            out.append(RepoSummary(name=name, valid=False, validation_error=str(e),
                                   last_modified=path.stat().st_mtime))
            continue
        try:
            validate_config(cfg)
            valid = True
            err = None
        except ConfigError as e:
            valid = False
            err = str(e)
        out.append(RepoSummary(
            name=name,
            description=cfg.get("description", ""),
            tasks=list(cfg.get("tasks", {}).keys()),
            workflows=list(cfg.get("workflows", {}).keys()),
            valid=valid,
            validation_error=err,
            last_modified=path.stat().st_mtime,
        ))
    return out


def get_repo(name: str) -> RepoDetail:
    path = _config_path(name)
    if not path.exists():
        raise ApiError(code="REPO_NOT_FOUND", message=f"repo '{name}' not found", status_code=404)
    try:
        cfg = json.loads(path.read_text())
    except json.JSONDecodeError as e:
        raise ApiError(code="CONFIG_SYNTAX", message=str(e), status_code=422,
                       details={"line": e.lineno, "col": e.colno}) from e
    try:
        validate_config(cfg)
        valid = True
        err = None
    except ConfigError as e:
        valid = False
        err = str(e)
    return RepoDetail(name=name, config=cfg, valid=valid, validation_error=err,
                      last_modified=path.stat().st_mtime)


def read_raw(name: str) -> RawConfig:
    path = _config_path(name)
    if not path.exists():
        raise ApiError(code="REPO_NOT_FOUND", message=f"repo '{name}' not found", status_code=404)
    return RawConfig(name=name, content=path.read_text(), last_modified=path.stat().st_mtime)


def validate_dict(cfg: dict) -> None:
    try:
        validate_config(cfg)
    except ConfigError as e:
        raise ApiError(code="CONFIG_INVALID", message=str(e), status_code=422) from e


def write_raw(name: str, content: str, expected_mtime: float | None) -> RawConfig:
    path = _config_path(name)
    if path.exists() and expected_mtime is not None:
        actual = path.stat().st_mtime
        if abs(actual - expected_mtime) > 1e-6:
            raise ApiError(code="FILE_CONFLICT", message="file modified externally",
                           status_code=409, details={"actual_mtime": actual})
    try:
        cfg = json.loads(content)
    except json.JSONDecodeError as e:
        raise ApiError(code="CONFIG_SYNTAX", message=str(e), status_code=422,
                       details={"line": e.lineno, "col": e.colno}) from e
    validate_dict(cfg)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    return RawConfig(name=name, content=content, last_modified=path.stat().st_mtime)


def create_repo(name: str, content: str) -> RawConfig:
    path = _config_path(name)
    if path.exists():
        raise ApiError(code="REPO_EXISTS", message=f"repo '{name}' already exists", status_code=409)
    return write_raw(name, content, expected_mtime=None)


def delete_repo(name: str) -> None:
    path = _config_path(name)
    if not path.exists():
        raise ApiError(code="REPO_NOT_FOUND", message=f"repo '{name}' not found", status_code=404)
    path.unlink()


def resolve_cli_repo_name(stem: str) -> str:
    """Translate a UI/file-stem repo id into the name the forge CLI uses.

    The web layer keys repos by JSON filename stem, but the CLI keys them by
    the config's internal 'name' field (falling back to stem). When these
    differ, a task submitted under the stem fails with 'repo not found'.

    Raises 404 if the file is missing. Raises 422 if another config declares
    the same 'name' — in that case the CLI cannot disambiguate, so we refuse
    rather than silently executing a different file than the user picked.
    """
    path = _config_path(stem)
    if not path.exists():
        raise ApiError(code="REPO_NOT_FOUND", message=f"repo '{stem}' not found",
                       status_code=404)
    try:
        cfg = json.loads(path.read_text())
    except json.JSONDecodeError as e:
        raise ApiError(code="CONFIG_SYNTAX", message=str(e), status_code=422,
                       details={"line": e.lineno, "col": e.colno}) from e
    cli_name = cfg.get("name", stem)
    cdir = _config_dir()
    if cdir.is_dir():
        conflicts: list[str] = []
        for other in sorted(cdir.glob("*.json")):
            if other == path:
                continue
            try:
                other_cfg = json.loads(other.read_text())
            except (OSError, json.JSONDecodeError):
                continue
            if other_cfg.get("name", other.stem) == cli_name:
                conflicts.append(other.name)
        if conflicts:
            raise ApiError(
                code="CONFIG_NAME_CONFLICT",
                message=(f"config name '{cli_name}' is declared by multiple files "
                         f"({path.name}, {', '.join(conflicts)}); the CLI cannot "
                         "disambiguate. Rename one of the 'name' fields."),
                status_code=422,
                details={"cli_name": cli_name, "file": path.name, "conflicts": conflicts},
            )
    return cli_name
