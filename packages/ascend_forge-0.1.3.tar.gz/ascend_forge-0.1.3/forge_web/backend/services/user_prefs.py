"""User preferences: per-user JSON file storage."""
import copy
import json
import os
import re
from pathlib import Path

_USERNAME_RE = re.compile(r"^[a-zA-Z0-9_-]{2,32}$")

DEFAULT_PREFS = {
    "version": 1,
    "sort": {"column": "started_at", "order": "desc"},
    "filters": {
        "owners": [],
        "statuses": [],
        "commands": [],
        "repos": [],
        "search": "",
    },
    "scope": "all",
}


def _prefs_dir() -> Path:
    return Path.home() / ".forge" / "web_prefs"


def _prefs_path(username: str) -> Path:
    if not _USERNAME_RE.match(username):
        raise ValueError(f"invalid username: {username!r}")
    return _prefs_dir() / f"{username}.json"


def get(username: str) -> dict:
    try:
        p = _prefs_path(username)
    except ValueError:
        return copy.deepcopy(DEFAULT_PREFS)
    if not p.exists():
        return copy.deepcopy(DEFAULT_PREFS)
    try:
        return json.loads(p.read_text())
    except (json.JSONDecodeError, OSError):
        return copy.deepcopy(DEFAULT_PREFS)


def put(username: str, prefs: dict) -> dict:
    p = _prefs_path(username)
    d = _prefs_dir()
    d.mkdir(parents=True, exist_ok=True)
    os.chmod(d, 0o700)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(prefs, indent=2))
    os.chmod(tmp, 0o600)
    tmp.rename(p)
    return prefs
