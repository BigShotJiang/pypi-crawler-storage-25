"""Async tail of a task log file. Yields LogFrame objects."""
import asyncio
import time
from pathlib import Path
from typing import AsyncIterator, Callable

from forge_web.backend.schemas import LogFrame


def _log_path(task_id: str) -> Path:
    return Path.home() / ".forge" / "logs" / f"{task_id}.log"


async def tail(task_id: str, from_offset: int, end_check: Callable[[], bool],
               poll_interval: float = 0.5) -> AsyncIterator[LogFrame]:
    """Yield log lines starting at from_offset until end_check() returns True
    AND no more bytes are available. Always emits a final 'closed' frame.

    end_check is called by the consumer and typically reflects daemon-reported
    task completion."""
    path = _log_path(task_id)
    offset = from_offset
    buf = b""

    while True:
        if not path.exists():
            if end_check():
                yield LogFrame(type="closed", offset=offset, ts=time.time())
                return
            await asyncio.sleep(poll_interval)
            continue

        size = path.stat().st_size
        if size > offset:
            with open(path, "rb") as f:
                f.seek(offset)
                chunk = f.read(size - offset)
            buf += chunk
            offset = size
            while b"\n" in buf:
                line, _, buf = buf.partition(b"\n")
                yield LogFrame(type="line", text=line.decode(errors="replace"),
                              offset=offset - len(buf), ts=time.time())

        if end_check() and path.stat().st_size <= offset:
            if buf:
                yield LogFrame(type="line", text=buf.decode(errors="replace"),
                              offset=offset, ts=time.time())
                buf = b""
            yield LogFrame(type="closed", offset=offset, ts=time.time())
            return

        await asyncio.sleep(poll_interval)
