"""Wraps forge.daemon.DaemonClient with structured errors and Pydantic models."""
from forge.daemon import DaemonClient
from forge_web.backend.errors import ApiError
from forge_web.backend.schemas import DaemonStatus, TaskInfo


TERMINAL_STATES: frozenset[str] = frozenset({"completed", "failed", "cancelled", "interrupted"})


def _client() -> DaemonClient:
    return DaemonClient()


def _ensure_running(c: DaemonClient) -> None:
    if not c.is_daemon_running():
        raise ApiError(code="DAEMON_UNREACHABLE", message="forge daemon is not running",
                       status_code=503)


def _to_task_info(d: dict) -> TaskInfo:
    return TaskInfo(
        task_id=d["task_id"],
        command=d["command"],
        args=d.get("args", {}),
        status=d.get("status", "unknown"),
        started_at=d.get("started_at"),
        pid=d.get("pid"),
        error=d.get("error"),
        config_path=d.get("config_path"),
        owner=d.get("owner"),
        client_ip=d.get("client_ip"),
    )


def status() -> DaemonStatus:
    c = _client()
    if not c.is_daemon_running():
        return DaemonStatus(running=False)
    resp = c.send({"action": "status"})
    if resp.get("status") != "ok":
        return DaemonStatus(running=False)
    tasks = resp.get("tasks", {})
    return DaemonStatus(
        running=True,
        pid=resp.get("pid"),
        pending=tasks.get("pending", 0),
        running_count=tasks.get("running", 0),
        completed=tasks.get("completed", 0),
    )


def submit(command: str, args: dict, config_path: str | None,
           verbose: bool = False,
           owner: str | None = None,
           client_ip: str | None = None) -> str:
    c = _client()
    _ensure_running(c)
    resp = c.send({"action": "submit", "command": command, "args": args,
                   "config_path": config_path, "verbose": verbose,
                   "owner": owner, "client_ip": client_ip})
    if resp.get("status") != "ok":
        raise ApiError(code="DAEMON_ERROR", message=resp.get("message", "unknown daemon error"),
                       status_code=502)
    return resp["task_id"]


def list_tasks(status_filter: str | None = None) -> list[TaskInfo]:
    c = _client()
    if not c.is_daemon_running():
        return []
    req = {"action": "list"}
    if status_filter:
        req["filter"] = status_filter
    resp = c.send(req)
    if resp.get("status") != "ok":
        raise ApiError(code="DAEMON_ERROR", message=resp.get("message", ""), status_code=502)
    return [_to_task_info(t) for t in resp.get("tasks", [])]


def get_task(task_id: str) -> TaskInfo:
    c = _client()
    _ensure_running(c)
    resp = c.send({"action": "get", "task_id": task_id})
    if resp.get("status") != "ok":
        msg = resp.get("message", "")
        if "not found" in msg.lower():
            raise ApiError(code="TASK_NOT_FOUND", message=msg, status_code=404)
        raise ApiError(code="DAEMON_ERROR", message=msg, status_code=502)
    return _to_task_info(resp["task"])


def cancel_task(task_id: str) -> None:
    c = _client()
    _ensure_running(c)
    resp = c.send({"action": "cancel", "task_id": task_id})
    if resp.get("status") != "ok":
        msg = resp.get("message", "")
        if "not found" in msg.lower():
            raise ApiError(code="TASK_NOT_FOUND", message=msg, status_code=404)
        raise ApiError(code="DAEMON_ERROR", message=msg, status_code=502)
