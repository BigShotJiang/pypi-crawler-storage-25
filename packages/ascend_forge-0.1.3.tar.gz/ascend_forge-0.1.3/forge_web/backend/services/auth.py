"""Lightweight auth: scrypt password hashing + HMAC-signed session cookie."""
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from forge_web.backend.errors import ApiError

_USERNAME_RE = re.compile(r"^[a-zA-Z0-9_-]{2,32}$")
_MIN_PASSWORD_LEN = 6


def _users_path() -> Path:
    return Path.home() / ".forge" / "web_users.json"


def _secret_path() -> Path:
    return Path.home() / ".forge" / "web_secret"


def _load_users() -> dict:
    p = _users_path()
    if not p.exists():
        return {"version": 1, "users": {}}
    return json.loads(p.read_text())


def _save_users(data: dict) -> None:
    p = _users_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2))
    os.chmod(tmp, 0o600)
    tmp.rename(p)


def _secret() -> bytes:
    p = _secret_path()
    if p.exists():
        return p.read_bytes()
    p.parent.mkdir(parents=True, exist_ok=True)
    key = secrets.token_bytes(32)
    p.write_bytes(key)
    os.chmod(p, 0o600)
    return key


def _hash_password(password: str, salt: bytes) -> bytes:
    return hashlib.scrypt(
        password.encode(),
        salt=salt,
        n=2**14,
        r=8,
        p=1,
        dklen=32,
    )


def _b64u(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def _from_b64u(s: str) -> bytes:
    pad = 4 - len(s) % 4
    if pad != 4:
        s += "=" * pad
    return base64.urlsafe_b64decode(s)


def register(username: str, password: str) -> None:
    if not _USERNAME_RE.match(username):
        raise ApiError(
            code="VALIDATION_ERROR",
            message="username must be 2-32 chars: letters, digits, _ or -",
            status_code=422,
        )
    if len(password) < _MIN_PASSWORD_LEN:
        raise ApiError(
            code="VALIDATION_ERROR",
            message=f"password must be at least {_MIN_PASSWORD_LEN} characters",
            status_code=422,
        )
    data = _load_users()
    if username in data["users"]:
        raise ApiError(code="USER_EXISTS", message=f"user '{username}' already exists", status_code=409)
    salt = secrets.token_bytes(16)
    h = _hash_password(password, salt)
    data["users"][username] = {
        "password_hash": _b64u(h),
        "salt": _b64u(salt),
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    _save_users(data)


def verify(username: str, password: str) -> bool:
    data = _load_users()
    user = data["users"].get(username)
    if user is None:
        _hash_password(password, b"\x00" * 16)
        return False
    salt = _from_b64u(user["salt"])
    expected = _from_b64u(user["password_hash"])
    actual = _hash_password(password, salt)
    return hmac.compare_digest(actual, expected)


def issue_cookie(username: str) -> str:
    user_b64 = _b64u(username.encode())
    sig = _b64u(hmac.new(_secret(), username.encode(), "sha256").digest())
    return f"{user_b64}.{sig}"


def parse_cookie(value: Optional[str]) -> Optional[str]:
    if not value or "." not in value:
        return None
    try:
        user_b64, sig_b64 = value.rsplit(".", 1)
        username = _from_b64u(user_b64).decode()
        expected_sig = _b64u(hmac.new(_secret(), username.encode(), "sha256").digest())
        if not hmac.compare_digest(sig_b64, expected_sig):
            return None
        return username
    except (ValueError, UnicodeDecodeError):
        return None
