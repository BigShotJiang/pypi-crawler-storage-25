"""Read and compare result records from ~/.forge/results."""
import json
from pathlib import Path

from forge_web.backend.errors import ApiError
from forge_web.backend.schemas import ResultRecord


def _results_dir() -> Path:
    return Path.home() / ".forge" / "results"


def _load(path: Path) -> ResultRecord:
    d = json.loads(path.read_text())
    return ResultRecord(
        repo=d.get("repo", ""),
        test_type=d.get("test_type", ""),
        commit=d.get("commit"),
        timestamp=d.get("timestamp", ""),
        values=d.get("values", {}),
        metadata=d.get("metadata", {}),
    )


def _path(record_id: str) -> Path:
    return _results_dir() / f"{record_id}.json"


def list_results(repo: str | None = None, test_type: str | None = None,
                 commit: str | None = None) -> list[dict]:
    """Return list of {id, record} dicts (id is filename stem)."""
    out: list[dict] = []
    rdir = _results_dir()
    if not rdir.is_dir():
        return out
    for path in sorted(rdir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            rec = _load(path)
        except (OSError, json.JSONDecodeError):
            continue
        if repo and rec.repo != repo:
            continue
        if test_type and rec.test_type != test_type:
            continue
        if commit and rec.commit != commit:
            continue
        out.append({"id": path.stem, "record": rec.model_dump()})
    return out


def get_result(record_id: str) -> ResultRecord:
    p = _path(record_id)
    if not p.exists():
        raise ApiError(code="RESULT_NOT_FOUND", message=f"result '{record_id}' not found",
                       status_code=404)
    return _load(p)


def compare(id_a: str, id_b: str) -> dict:
    a = get_result(id_a)
    b = get_result(id_b)
    out: dict[str, dict] = {}
    for op, va in a.values.items():
        if op in b.values:
            vb = b.values[op]
            delta = vb - va
            pct = (delta / va * 100.0) if va else 0.0
            out[op] = {"baseline": va, "current": vb, "delta": delta, "delta_pct": pct}
        else:
            out[op] = {"baseline": va, "current": None, "delta": None, "delta_pct": None}
    for op, vb in b.values.items():
        if op not in out:
            out[op] = {"baseline": None, "current": vb, "delta": None, "delta_pct": None}
    return {"baseline_id": id_a, "current_id": id_b, "values": out}
