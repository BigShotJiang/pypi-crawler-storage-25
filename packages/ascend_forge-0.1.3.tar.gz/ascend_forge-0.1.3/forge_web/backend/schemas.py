"""Pydantic models for forge web API."""
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field


class DaemonStatus(BaseModel):
    running: bool
    pid: Optional[int] = None
    pending: int = 0
    running_count: int = 0
    completed: int = 0


class RepoSummary(BaseModel):
    name: str
    description: str = ""
    tasks: list[str] = Field(default_factory=list)
    workflows: list[str] = Field(default_factory=list)
    valid: bool = True
    validation_error: Optional[str] = None
    last_modified: float = 0.0


class RepoDetail(BaseModel):
    name: str
    config: dict[str, Any]
    valid: bool = True
    validation_error: Optional[str] = None
    last_modified: float = 0.0


class RawConfig(BaseModel):
    name: str
    content: str
    last_modified: float


class WriteRawRequest(BaseModel):
    content: str
    expected_mtime: Optional[float] = None  # for conflict detection


class TaskSubmitRequest(BaseModel):
    repo: str
    task: str
    args: dict[str, Any] = Field(default_factory=dict)
    workflow: Optional[str] = None
    loop: Optional[dict[str, Any]] = None
    verbose: bool = False


class TaskInfo(BaseModel):
    task_id: str
    command: str
    args: dict[str, Any]
    status: str
    started_at: Optional[str] = None
    pid: Optional[int] = None
    error: Optional[str] = None
    config_path: Optional[str] = None
    owner: Optional[str] = None
    client_ip: Optional[str] = None


class LogFrame(BaseModel):
    type: Literal["line", "closed"]
    text: Optional[str] = None
    exit_code: Optional[int] = None
    offset: int
    ts: float


class ResultRecord(BaseModel):
    repo: str
    test_type: str
    commit: Optional[str] = None
    timestamp: str
    values: dict[str, float] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


class BisectStatus(BaseModel):
    task_id: str
    status: str
    tested_commits: list[dict[str, Any]] = Field(default_factory=list)
    current_commit: Optional[str] = None
    good_commit: Optional[str] = None
    bad_commit: Optional[str] = None
    remaining: int = 0


class BisectStartRequest(BaseModel):
    repo: str
    good: str
    bad: str
    test_type: Optional[str] = None
    args: dict[str, Any] = Field(default_factory=dict)
    verbose: bool = False


class TasksPrefsSort(BaseModel):
    column: Literal[
        "owner", "client_ip", "status", "command", "repo",
        "task_name", "started_at", "task_id"
    ]
    order: Literal["asc", "desc"]


class TasksPrefsFilters(BaseModel):
    owners: list[str] = Field(default_factory=list)
    statuses: list[str] = Field(default_factory=list)
    commands: list[str] = Field(default_factory=list)
    repos: list[str] = Field(default_factory=list)
    search: str = ""


class TasksPrefs(BaseModel):
    version: int = 1
    sort: TasksPrefsSort = Field(
        default_factory=lambda: TasksPrefsSort(column="started_at", order="desc")
    )
    filters: TasksPrefsFilters = Field(default_factory=TasksPrefsFilters)
    scope: Literal["all", "mine"] = "all"
