"""`forge web` CLI entry point."""
from __future__ import annotations

import argparse
import os
import signal
import sys
import threading
import time
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Sequence

import uvicorn

from forge.daemon import Daemon, DaemonClient, is_daemon_running, get_daemon_pid

LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1"}

_DAEMON_READY_TIMEOUT_S = 2.0
_DAEMON_POLL_INTERVAL_S = 0.1


@dataclass
class _DaemonState:
    """Tracks the daemon lifecycle for this `forge web` process."""
    pid: int | None
    started_by_us: bool
    keep: bool
    _stopped: bool = False


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="forge web", description="Local web UI for forge")
    p.add_argument("--host", default="127.0.0.1",
                   help="Bind host (default: 127.0.0.1). Use 0.0.0.0 to expose to LAN.")
    p.add_argument("--port", type=int, default=8765, help="Port (default: 8765)")
    open_grp = p.add_mutually_exclusive_group()
    open_grp.add_argument("--open", dest="open", action="store_const", const=True,
                          help="Auto-open browser")
    open_grp.add_argument("--no-open", dest="open", action="store_const", const=False,
                          help="Do not auto-open browser")
    p.set_defaults(open=None)
    p.add_argument("--dev", action="store_true",
                   help="Print instructions to run backend + Vite dev server separately, then exit")
    p.add_argument("--reload", action="store_true",
                   help="Enable uvicorn auto-reload (for development)")
    daemon_grp = p.add_mutually_exclusive_group()
    daemon_grp.add_argument("--with-daemon", dest="with_daemon",
                            action="store_true",
                            help="Start a forge daemon if none is running, and stop it on exit")
    daemon_grp.add_argument("--no-daemon", dest="with_daemon",
                            action="store_false",
                            help="Do not touch the forge daemon (default)")
    p.set_defaults(with_daemon=False)
    p.add_argument("--keep-daemon", action="store_true",
                   help="With --with-daemon: leave the daemon running after forge web exits")
    return p


def _ensure_daemon() -> tuple[int | None, bool]:
    """Ensure a forge daemon is running.

    Returns (pid_if_started_by_us, started_by_us). If a daemon is already
    running, returns (None, False). If we fork one, returns (child_pid, True).
    Raises RuntimeError if the forked daemon does not become ready within
    _DAEMON_READY_TIMEOUT_S.

    Must be called before any threads are started in the parent process:
    os.fork() inherits file descriptors but not threads, so starting threads
    in the parent first is safe but confusing. Call this before scheduling
    browser opens or starting the server.

    Uses DaemonClient for the post-fork readiness poll because
    forge.daemon.is_daemon_running() (module-level) only checks the PID
    file, which is written before the socket is listening.
    """
    if is_daemon_running():
        print(f"Reusing existing daemon (pid={get_daemon_pid()})")
        return None, False

    pid = os.fork()
    if pid == 0:  # child
        os.setsid()
        Daemon().start(foreground=True)
        os._exit(0)

    # parent: poll socket until ready or timeout
    client = DaemonClient()
    deadline = time.monotonic() + _DAEMON_READY_TIMEOUT_S
    while time.monotonic() < deadline:
        if client.is_daemon_running():
            print(f"Daemon started (pid={pid})")
            return pid, True
        time.sleep(_DAEMON_POLL_INTERVAL_S)

    # timeout: try to reap the child we started
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    # Non-blocking reap: if the SIGTERM hasn't propagated yet, the child
    # becomes a brief zombie until this process exits. Acceptable trade-off
    # versus blocking the CLI on a daemon that's already failed.
    try:
        os.waitpid(pid, os.WNOHANG)
    except ChildProcessError:
        pass
    raise RuntimeError(f"Daemon (pid={pid}) did not become ready within {_DAEMON_READY_TIMEOUT_S}s")


def _stop_daemon_if_needed(state: "_DaemonState") -> None:
    """Stop the daemon if we started it and --keep-daemon was not passed.

    Idempotent: second call is a no-op.
    """
    if state._stopped:
        return
    state._stopped = True

    if not state.started_by_us or state.pid is None:
        return

    if state.keep:
        print(f"Leaving daemon running (pid={state.pid})")
        return

    print(f"Stopping daemon (pid={state.pid})")
    try:
        os.kill(state.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass


def _print_dev_instructions() -> None:
    print("Run these in two terminals:")
    print()
    print("  # Terminal 1 — backend (auto-reload)")
    print("  python -m uvicorn forge_web.backend.main:app --port 8765 --reload")
    print()
    print("  # Terminal 2 — Vite dev server")
    print("  cd forge_web/frontend && npm run dev")
    print()
    print("Then open http://127.0.0.1:5173/")


def _warn_public_bind(host: str) -> None:
    msg = (
        "\nWARNING: binding to a non-loopback address ({host}).\n"
        "forge web has NO authentication. Anyone who can reach this port\n"
        "can read your configs and submit arbitrary tasks to the daemon.\n"
        "Do not expose to untrusted networks.\n"
    ).format(host=host)
    print(msg, file=sys.stderr)


def _warn_missing_frontend() -> None:
    static_dir = Path(__file__).resolve().parent.parent / "static"
    if (static_dir / "index.html").is_file():
        return
    msg = (
        "\nWARNING: frontend bundle not found at {d}.\n"
        "Opening the UI will show a 'Frontend not built' page. Build it with:\n"
        "  cd forge_web/frontend && npm ci && npm run build:embed\n"
        "(Source installs only. Wheels from PyPI ship the frontend prebuilt.)\n"
    ).format(d=static_dir)
    print(msg, file=sys.stderr)


def _schedule_browser_open(url: str, delay_seconds: float = 1.0) -> None:
    threading.Timer(delay_seconds, lambda: webbrowser.open(url)).start()


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)

    if args.dev:
        _print_dev_instructions()
        if args.with_daemon:
            print()
            print("Note: --with-daemon is ignored with --dev; run `forge daemon start` yourself.")
        return 0

    is_loopback = args.host in LOOPBACK_HOSTS
    if not is_loopback:
        _warn_public_bind(args.host)

    _warn_missing_frontend()

    # IMPORTANT: start the daemon (which forks) BEFORE we schedule any
    # threads in this process. os.fork() inherits the parent's FDs but not
    # its threads; starting threads first is confusing, not broken. Keeping
    # them after the fork keeps child process state minimal.
    state = _DaemonState(pid=None, started_by_us=False, keep=args.keep_daemon)
    if args.with_daemon:
        try:
            pid, started_by_us = _ensure_daemon()
        except (RuntimeError, OSError) as e:
            print(f"Failed to start daemon: {e}", file=sys.stderr)
            return 1
        state.pid = pid
        state.started_by_us = started_by_us

    should_open = args.open if args.open is not None else is_loopback
    if should_open:
        url = f"http://{'127.0.0.1' if args.host == '0.0.0.0' else args.host}:{args.port}/"
        _schedule_browser_open(url)

    def _sigterm_handler(signum, frame):  # noqa: ARG001
        _stop_daemon_if_needed(state)
        sys.exit(0)

    if state.started_by_us:
        signal.signal(signal.SIGTERM, _sigterm_handler)

    try:
        uvicorn.run(
            "forge_web.backend.main:app",
            host=args.host,
            port=args.port,
            reload=args.reload,
            log_level="info",
        )
    finally:
        _stop_daemon_if_needed(state)

    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
