"""SPA static mount: serve files, fall back to index.html for client routes."""
from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from starlette.requests import Request


_NOT_BUILT_HTML = """<!doctype html>
<html><head><title>forge web</title></head>
<body style="font-family:ui-sans-serif;padding:3rem;max-width:40rem;margin:0 auto">
<h1>Frontend not built</h1>
<p>The static bundle at <code>forge_web/static/</code> is empty.</p>
<p>Build it with:</p>
<pre style="background:#f4f4f5;padding:1rem;border-radius:6px">
cd forge_web/frontend
npm install
npm run build
npm run sync:static</pre>
<p>Or use <code>forge web --dev</code> to run against the Vite dev server.</p>
</body></html>"""


def mount_static(app: FastAPI, static_dir: Path) -> None:
    """Mount `static_dir` as the SPA root, with client-route fallback.

    If `static_dir` doesn't exist, do nothing (dev mode).
    If `static_dir/index.html` is missing, serve a 'not built' page on /.
    """
    static_dir = Path(static_dir)
    if not static_dir.is_dir():
        return

    index = static_dir / "index.html"

    # Serve bare assets via StaticFiles at /static (for explicit asset URLs),
    # but also intercept arbitrary GET paths to serve index.html for client routes.
    if (static_dir / "assets").is_dir():
        app.mount("/assets", StaticFiles(directory=static_dir / "assets"), name="assets")

    # Serve other top-level static files (favicon, etc.)
    @app.get("/{path:path}", include_in_schema=False, response_model=None)
    async def spa_fallback(request: Request, path: str) -> FileResponse | HTMLResponse:
        # Don't intercept /api (routers handle those; 404 is correct for missing routes)
        if path.startswith("api/") or path.startswith("api"):
            raise HTTPException(status_code=404)

        # Exact file match wins over SPA fallback
        target = static_dir / path if path else index
        if target.is_file():
            return FileResponse(target)

        # SPA client route: serve index.html
        if index.is_file():
            return FileResponse(index)

        return HTMLResponse(_NOT_BUILT_HTML, status_code=404)
