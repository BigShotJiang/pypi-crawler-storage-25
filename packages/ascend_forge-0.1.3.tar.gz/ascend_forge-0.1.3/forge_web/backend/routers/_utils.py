"""Shared utilities for routers."""
from fastapi import Request


def client_ip(request: Request) -> str | None:
    """Extract client IP, preferring X-Forwarded-For over direct connection."""
    xff = request.headers.get("x-forwarded-for")
    if xff:
        return xff.split(",")[0].strip() or None
    return request.client.host if request.client else None
