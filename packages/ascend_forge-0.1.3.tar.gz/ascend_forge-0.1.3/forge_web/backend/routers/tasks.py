"""Routes for /api/tasks and /api/daemon/status."""
import asyncio
import json
from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import StreamingResponse

from forge.loop import normalize_loop_spec
from forge_web.backend.errors import ApiError
from forge_web.backend.routers.auth import current_user
from forge_web.backend.schemas import (
    DaemonStatus,
    TaskInfo,
    TaskSubmitRequest,
)
from forge_web.backend.services import config_store, daemon_proxy
from forge_web.backend.services.daemon_proxy import TERMINAL_STATES as _TERMINAL
from forge_web.backend.routers._utils import client_ip as _client_ip

router = APIRouter(tags=["tasks"])


def _build_args(req: TaskSubmitRequest) -> tuple[str, dict]:
    """Map (repo, task, args, workflow, loop) → (daemon command, args dict).

    The daemon expects forge CLI arg shape: {repo: <name>, ...task-specific...}.
    For workflows we use 'workflow' command with --workflow flag inside extra_args.

    `req.repo` is the JSON file stem used by the web layer; the CLI keys
    repos by the config's internal 'name' field. The caller is responsible
    for passing a CLI-resolved name via `cli_repo` when they differ.
    """
    base = {"repo": req.repo}
    base.update(req.args)

    if req.loop:
        try:
            loop_spec = normalize_loop_spec(req.loop)
        except ValueError as e:
            raise ApiError(code="INVALID_LOOP", message=str(e), status_code=422)
        base.pop(loop_spec.var, None)
        base["loop"] = {
            "var": loop_spec.var,
            "values": loop_spec.values,
            "fail_fast": loop_spec.fail_fast,
        }

    if req.workflow:
        base["workflow"] = req.workflow
        return "workflow", base
    if req.task in {"build"}:
        return "build", base
    if req.task in {"test"} or req.task.startswith("test:"):
        if ":" in req.task:
            base["type"] = req.task.split(":", 1)[1]
        return "test", base
    base["task"] = req.task
    return "task-run", base


@router.post("/api/tasks", status_code=202)
def submit_task(req: TaskSubmitRequest, request: Request,
                user: str = Depends(current_user)) -> dict:
    config_store.get_repo(req.repo)
    cli_repo = config_store.resolve_cli_repo_name(req.repo)
    config_path = None  # daemon uses FORGE_CONFIG_DIR; specific path optional
    command, args = _build_args(req)
    args["repo"] = cli_repo
    task_id = daemon_proxy.submit(
        command=command, args=args, config_path=config_path,
        verbose=req.verbose,
        owner=user,
        client_ip=_client_ip(request),
    )
    return {"task_id": task_id}


@router.get("/api/tasks", response_model=list[TaskInfo])
def list_tasks(status: str | None = None,
               _user: str = Depends(current_user)) -> list[TaskInfo]:
    return daemon_proxy.list_tasks(status_filter=status)


@router.get("/api/tasks/{task_id}", response_model=TaskInfo)
def get_task(task_id: str, _user: str = Depends(current_user)) -> TaskInfo:
    return daemon_proxy.get_task(task_id)


@router.delete("/api/tasks/{task_id}", status_code=204)
def cancel_task(task_id: str, _user: str = Depends(current_user)) -> Response:
    daemon_proxy.cancel_task(task_id)
    return Response(status_code=204)


@router.get("/api/daemon/status", response_model=DaemonStatus)
def daemon_status() -> DaemonStatus:
    return daemon_proxy.status()

@router.get("/api/tasks/{task_id}/events")
async def task_events(task_id: str, request: Request, poll_interval: float = 0.5,
                      _user: str = Depends(current_user)) -> StreamingResponse:
    async def gen():
        last_status = None
        while True:
            if await request.is_disconnected():
                return
            try:
                info = daemon_proxy.get_task(task_id)
            except ApiError as e:
                yield f"event: error\ndata: {json.dumps({'code': e.code, 'message': e.message, 'details': e.details})}\n\n"
                return
            except Exception as e:
                yield f"event: error\ndata: {json.dumps({'code': 'INTERNAL', 'message': str(e) or repr(e)})}\n\n"
                return
            payload = info.model_dump()
            if info.status != last_status:
                yield f"data: {json.dumps(payload)}\n\n"
                last_status = info.status
            if info.status in _TERMINAL:
                return
            await asyncio.sleep(poll_interval)

    return StreamingResponse(gen(), media_type="text/event-stream")
