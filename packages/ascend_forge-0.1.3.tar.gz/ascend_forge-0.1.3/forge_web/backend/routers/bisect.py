"""Routes for /api/bisect."""
import json
from pathlib import Path

from fastapi import APIRouter, Depends, Request

from forge_web.backend.routers.auth import current_user
from forge_web.backend.routers._utils import client_ip as _client_ip
from forge_web.backend.schemas import BisectStartRequest, BisectStatus
from forge_web.backend.services import config_store, daemon_proxy

router = APIRouter(prefix="/api/bisect", tags=["bisect"])


def _checkpoint_path(task_id: str) -> Path:
    return Path.home() / ".forge" / "bisect" / f"{task_id}.json"


@router.post("", status_code=202)
def start_bisect(req: BisectStartRequest, request: Request,
                 user: str = Depends(current_user)) -> dict:
    config_store.get_repo(req.repo)
    args = {"repo": req.repo, "good": req.good, "bad": req.bad}
    if req.test_type:
        args["test_type"] = req.test_type
    args.update(req.args)
    task_id = daemon_proxy.submit(
        command="bisect", args=args, config_path=None,
        verbose=req.verbose,
        owner=user,
        client_ip=_client_ip(request),
    )
    return {"task_id": task_id}


@router.get("/{task_id}", response_model=BisectStatus)
def get_status(task_id: str, _user: str = Depends(current_user)) -> BisectStatus:
    info = daemon_proxy.get_task(task_id)
    tested: list[dict] = []
    ckpt = _checkpoint_path(task_id)
    if ckpt.exists():
        try:
            tested = json.loads(ckpt.read_text()).get("tested_commits", [])
        except (OSError, json.JSONDecodeError):
            tested = []
    return BisectStatus(
        task_id=task_id,
        status=info.status,
        tested_commits=tested,
        current_commit=tested[-1]["commit"] if tested else None,
        good_commit=info.args.get("good"),
        bad_commit=info.args.get("bad"),
        remaining=0,
    )
