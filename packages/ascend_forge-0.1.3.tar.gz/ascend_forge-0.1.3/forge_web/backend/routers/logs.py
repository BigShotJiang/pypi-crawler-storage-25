"""WebSocket route for log tail."""
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from forge_web.backend.services import daemon_proxy, log_streamer
from forge_web.backend.services.daemon_proxy import TERMINAL_STATES as _TERMINAL

router = APIRouter(tags=["logs"])


@router.websocket("/api/logs/{task_id}/stream")
async def stream_logs(ws: WebSocket, task_id: str) -> None:
    await ws.accept()
    from_offset = int(ws.query_params.get("from", "0"))

    def is_done() -> bool:
        try:
            info = daemon_proxy.get_task(task_id)
        except Exception:
            return True
        return info.status in _TERMINAL

    try:
        async for frame in log_streamer.tail(task_id, from_offset=from_offset,
                                              end_check=is_done, poll_interval=0.1):
            await ws.send_json(frame.model_dump())
    except WebSocketDisconnect:
        return
    finally:
        try:
            await ws.close()
        except Exception:
            pass
