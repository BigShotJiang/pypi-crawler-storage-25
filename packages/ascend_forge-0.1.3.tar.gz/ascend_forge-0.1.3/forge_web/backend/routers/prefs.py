"""User preferences routes."""
from fastapi import APIRouter, Depends

from forge_web.backend.routers.auth import current_user
from forge_web.backend.schemas import TasksPrefs
from forge_web.backend.services import user_prefs

router = APIRouter(prefix="/api/users/me", tags=["prefs"])


@router.get("/prefs", response_model=TasksPrefs)
def get_prefs(user: str = Depends(current_user)) -> TasksPrefs:
    data = user_prefs.get(user)
    return TasksPrefs(**data)


@router.put("/prefs", response_model=TasksPrefs)
def put_prefs(body: TasksPrefs, user: str = Depends(current_user)) -> TasksPrefs:
    user_prefs.put(user, body.model_dump())
    return body
