"""Routes for raw config file read/write."""
from fastapi import APIRouter

from forge_web.backend.schemas import RawConfig, WriteRawRequest
from forge_web.backend.services import config_store

router = APIRouter(prefix="/api/repos", tags=["configs"])


@router.get("/{name}/raw", response_model=RawConfig)
def read_raw(name: str) -> RawConfig:
    return config_store.read_raw(name)


@router.put("/{name}/raw", response_model=RawConfig)
def write_raw(name: str, req: WriteRawRequest) -> RawConfig:
    return config_store.write_raw(name, req.content, req.expected_mtime)
