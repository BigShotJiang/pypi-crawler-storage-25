"""Routes for /api/results."""
from fastapi import APIRouter
from pydantic import BaseModel

from forge_web.backend.services import result_reader

router = APIRouter(prefix="/api/results", tags=["results"])


class CompareRequest(BaseModel):
    baseline_id: str
    current_id: str


@router.get("")
def list_results(repo: str | None = None, test_type: str | None = None,
                commit: str | None = None) -> list[dict]:
    return result_reader.list_results(repo=repo, test_type=test_type, commit=commit)


@router.post("/compare")
def compare(req: CompareRequest) -> dict:
    return result_reader.compare(req.baseline_id, req.current_id)


@router.get("/{record_id}")
def get_result(record_id: str) -> dict:
    return result_reader.get_result(record_id).model_dump()
