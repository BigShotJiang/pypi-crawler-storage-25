"""Routes for /api/repos."""
from fastapi import APIRouter
from fastapi.responses import Response
from pydantic import BaseModel

from forge_web.backend.schemas import RawConfig, RepoDetail, RepoSummary
from forge_web.backend.services import config_store

router = APIRouter(prefix="/api/repos", tags=["repos"])


class CreateRepoRequest(BaseModel):
    name: str
    content: str


class ValidateResponse(BaseModel):
    valid: bool
    error: str | None = None


@router.get("", response_model=list[RepoSummary])
def list_repos() -> list[RepoSummary]:
    return config_store.list_repos()


@router.get("/{name}", response_model=RepoDetail)
def get_repo(name: str) -> RepoDetail:
    return config_store.get_repo(name)


@router.post("/{name}/validate", response_model=ValidateResponse)
def validate_repo(name: str) -> ValidateResponse:
    detail = config_store.get_repo(name)
    return ValidateResponse(valid=detail.valid, error=detail.validation_error)


@router.post("", status_code=201, response_model=RawConfig)
def create_repo(req: CreateRepoRequest) -> RawConfig:
    return config_store.create_repo(req.name, req.content)


@router.delete("/{name}", status_code=204)
def delete_repo(name: str) -> Response:
    config_store.delete_repo(name)
    return Response(status_code=204)
