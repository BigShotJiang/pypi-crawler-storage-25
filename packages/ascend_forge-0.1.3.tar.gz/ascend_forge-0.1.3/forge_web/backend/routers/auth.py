"""Auth routes: register, login, logout, me."""
from fastapi import APIRouter, Depends, Request, Response
from pydantic import BaseModel

from forge_web.backend.errors import ApiError
from forge_web.backend.services.auth import issue_cookie, parse_cookie, register, verify

router = APIRouter(prefix="/api/auth", tags=["auth"])

_COOKIE_NAME = "forge_session"
_COOKIE_MAX_AGE = 60 * 60 * 24 * 365  # 1 year


class AuthRequest(BaseModel):
    username: str
    password: str


def _set_session_cookie(response: Response, username: str, request: Request) -> None:
    secure = request.url.scheme == "https"
    response.set_cookie(
        key=_COOKIE_NAME,
        value=issue_cookie(username),
        max_age=_COOKIE_MAX_AGE,
        httponly=True,
        samesite="lax",
        secure=secure,
        path="/",
    )


def current_user(request: Request) -> str:
    cookie = request.cookies.get(_COOKIE_NAME)
    user = parse_cookie(cookie) if cookie else None
    if not user:
        raise ApiError(code="UNAUTHENTICATED", message="login required", status_code=401)
    return user


@router.post("/register")
def do_register(body: AuthRequest, request: Request, response: Response) -> dict:
    register(body.username, body.password)
    _set_session_cookie(response, body.username, request)
    return {"username": body.username}


@router.post("/login")
def do_login(body: AuthRequest, request: Request, response: Response) -> dict:
    if not verify(body.username, body.password):
        raise ApiError(code="INVALID_CREDENTIALS", message="invalid username or password", status_code=401)
    _set_session_cookie(response, body.username, request)
    return {"username": body.username}


@router.post("/logout", status_code=204)
def do_logout() -> Response:
    r = Response(status_code=204)
    r.delete_cookie(key=_COOKIE_NAME, path="/")
    return r


@router.get("/me")
def me(user: str = Depends(current_user)) -> dict:
    return {"username": user}
