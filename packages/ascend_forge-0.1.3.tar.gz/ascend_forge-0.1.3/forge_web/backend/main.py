"""FastAPI app factory."""
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from forge_web.backend.errors import register_error_handlers
from forge_web.backend.routers import bisect, configs, logs, repos, results, tasks
from forge_web.backend.routers import auth as auth_router
from forge_web.backend.routers import prefs as prefs_router
from forge_web.backend.services.auth import parse_cookie
from forge_web.backend.static_spa import mount_static

_AUTH_WHITELIST = {"/api/auth/register", "/api/auth/login", "/api/auth/logout", "/api/auth/me"}


def _default_static_dir() -> Path:
    return Path(__file__).resolve().parent.parent / "static"


def create_app(static_dir: Path | None = None) -> FastAPI:
    app = FastAPI(title="forge web", version="0.1.0")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.middleware("http")
    async def require_auth(request: Request, call_next):
        path = request.url.path
        if path in _AUTH_WHITELIST or not path.startswith("/api/"):
            return await call_next(request)
        cookie = request.cookies.get("forge_session")
        user = parse_cookie(cookie)
        if not user:
            return JSONResponse(
                status_code=401,
                content={"error": {"code": "UNAUTHENTICATED", "message": "login required", "details": None}},
            )
        return await call_next(request)

    register_error_handlers(app)
    app.include_router(auth_router.router)
    app.include_router(repos.router)
    app.include_router(configs.router)
    app.include_router(tasks.router)
    app.include_router(logs.router)
    app.include_router(results.router)
    app.include_router(prefs_router.router)
    app.include_router(bisect.router)

    mount_static(app, static_dir or _default_static_dir())
    return app


app = create_app()
