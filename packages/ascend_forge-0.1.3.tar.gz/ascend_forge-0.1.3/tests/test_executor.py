import pytest
from forge.executor import run_command, CommandResult, CommandError


class TestRunCommand:
    def test_successful_command(self, tmp_path):
        result = run_command("echo hello", working_dir=str(tmp_path))
        assert result.returncode == 0
        assert "hello" in result.stdout

    def test_failed_command(self, tmp_path):
        result = run_command("exit 1", working_dir=str(tmp_path))
        assert result.returncode != 0

    def test_command_with_args(self, tmp_path):
        result = run_command("echo", args=["hello", "world"], working_dir=str(tmp_path))
        assert result.returncode == 0
        assert "hello world" in result.stdout

    def test_command_with_env(self, tmp_path):
        result = run_command(
            "bash -c 'echo $MY_VAR'",
            working_dir=str(tmp_path),
            env={"MY_VAR": "test_value"},
        )
        assert "test_value" in result.stdout

    def test_command_timeout(self, tmp_path):
        result = run_command("sleep 10", working_dir=str(tmp_path), timeout=0.5)
        assert result.timed_out is True

    def test_no_timeout(self, tmp_path):
        result = run_command("echo fast", working_dir=str(tmp_path), timeout=None)
        assert result.returncode == 0

    def test_success_pattern_match(self, tmp_path):
        result = run_command("echo 'Build succeeded OK'", working_dir=str(tmp_path))
        assert result.matches_pattern("Build succeeded")

    def test_success_pattern_no_match(self, tmp_path):
        result = run_command("echo 'Build failed'", working_dir=str(tmp_path))
        assert not result.matches_pattern("succeeded")

    def test_is_successful_exit_code_only(self, tmp_path):
        result = run_command("echo ok", working_dir=str(tmp_path))
        assert result.is_successful() is True

    def test_is_successful_with_pattern(self, tmp_path):
        result = run_command("echo 'Build succeeded'", working_dir=str(tmp_path))
        assert result.is_successful(success_pattern="Build succeeded") is True

    def test_is_successful_pattern_not_found(self, tmp_path):
        result = run_command("echo 'Build done'", working_dir=str(tmp_path))
        assert result.is_successful(success_pattern="Build succeeded") is False

    def test_is_successful_nonzero_exit(self, tmp_path):
        result = run_command("exit 1", working_dir=str(tmp_path))
        assert result.is_successful() is False
