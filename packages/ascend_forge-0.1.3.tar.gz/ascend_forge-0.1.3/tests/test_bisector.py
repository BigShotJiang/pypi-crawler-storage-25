import os
import subprocess
from unittest.mock import patch
import pytest
from forge.bisector import bisect_repo, BisectResult, BisectAbortError
from forge.workflow import WorkflowResult, StepResult
from forge.task import TaskResult


def _create_git_repo_with_commits(tmp_path, num_commits=10):
    """Create a git repo with N commits. Returns (working_dir, commit_list)."""
    repo = tmp_path / "repo"
    repo.mkdir()
    subprocess.run(["git", "init"], cwd=str(repo), capture_output=True)
    subprocess.run(["git", "config", "user.email", "t@t.com"], cwd=str(repo), capture_output=True)
    subprocess.run(["git", "config", "user.name", "T"], cwd=str(repo), capture_output=True)

    (repo / "build.sh").write_text("#!/bin/bash\necho 'Build succeeded'\n")
    (repo / "build.sh").chmod(0o755)
    tests_dir = repo / "tests"
    tests_dir.mkdir()

    commits = []
    for i in range(num_commits):
        (repo / "version.txt").write_text(str(i))
        subprocess.run(["git", "add", "."], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "commit", "-m", f"commit {i}"], cwd=str(repo), capture_output=True)
        commit_hash = subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=str(repo), capture_output=True, text=True
        ).stdout.strip()
        commits.append(commit_hash)
    return str(repo), commits


def _write_accuracy_test(repo_path, bad_from):
    test_script = os.path.join(repo_path, "tests", "run_test.py")
    with open(test_script, "w") as f:
        f.write(
            "#!/usr/bin/env python3\n"
            "import sys\n"
            f"version = int(open('version.txt').read().strip())\n"
            f"if version >= {bad_from}:\n"
            "    print('accuracy FAIL')\n"
            "    sys.exit(1)\n"
            "else:\n"
            "    print('accuracy: 0.99')\n"
            "    print('accuracy PASS')\n"
        )


def _write_performance_test(repo_path, bad_from, good_value=10.0, bad_value=50.0):
    test_script = os.path.join(repo_path, "tests", "run_perf.sh")
    output_dir = os.path.join(repo_path, "tests", "output")
    os.makedirs(output_dir, exist_ok=True)
    with open(test_script, "w") as f:
        f.write(
            "#!/bin/bash\n"
            f"VERSION=$(cat version.txt)\n"
            f"if [ $VERSION -ge {bad_from} ]; then\n"
            f'  echo "op,time_ms" > tests/output/result.csv\n'
            f'  echo "matmul,{bad_value}" >> tests/output/result.csv\n'
            "else\n"
            f'  echo "op,time_ms" > tests/output/result.csv\n'
            f'  echo "matmul,{good_value}" >> tests/output/result.csv\n'
            "fi\n"
        )
    os.chmod(test_script, 0o755)


def _new_accuracy_task_config(repo_path):
    return {
        "name": "test_repo",
        "working_dir": repo_path,
        "tasks": {
            "build": {
                "command": "bash build.sh",
                "working_dir": ".",
                "timeout": 60,
            },
            "accuracy": {
                "command": "python3 tests/run_test.py",
                "working_dir": ".",
                "timeout": 60,
                "success_pattern": "PASS",
                "result": {
                    "type": "stdout",
                    "pattern": "accuracy: ([0-9.]+)",
                },
            },
        },
    }


class TestBisectWorkingDirOverride:
    def test_bisect_extra_vars_overrides_working_dir(self, tmp_path):
        """--arg working_dir=/new/path should override config working_dir in bisect."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 6)
        bad_from = 3
        _write_accuracy_test(repo_path, bad_from)

        config = _new_accuracy_task_config(str(tmp_path / "nonexistent"))
        config["workflows"] = {
            "bisect_pipeline": {"tasks": ["build", "accuracy"]},
        }
        config["bisect"] = {
            "workflows": [{"name": "bisect_pipeline", "repeatable": True}],
        }

        result = bisect_repo(
            config=config, test_type="accuracy",
            good_commit=commits[0], bad_commit=commits[-1],
            extra_vars={"working_dir": repo_path},
        )
        assert result.found_commit == commits[bad_from]

    def test_bisect_extra_vars_repo_root_resolves_working_dir(self, tmp_path):
        """--arg repo_root=/new/path should resolve working_dir={repo_root} in bisect."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 6)
        bad_from = 3
        _write_accuracy_test(repo_path, bad_from)

        config = _new_accuracy_task_config(str(tmp_path / "nonexistent"))
        config["working_dir"] = "{repo_root}"
        config["vars"] = {"repo_root": str(tmp_path / "old_repo")}
        config["workflows"] = {
            "bisect_pipeline": {"tasks": ["build", "accuracy"]},
        }
        config["bisect"] = {
            "workflows": [{"name": "bisect_pipeline", "repeatable": True}],
        }

        result = bisect_repo(
            config=config, test_type="accuracy",
            good_commit=commits[0], bad_commit=commits[-1],
            extra_vars={"repo_root": repo_path},
        )
        assert result.found_commit == commits[bad_from]


class TestBisectCompatibility:
    def test_bisect_legacy_workflow_still_runs(self, tmp_path):
        """Legacy bisect.workflow configs still run through bisect."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 10)
        bad_from = 5
        _write_accuracy_test(repo_path, bad_from)

        config = _new_accuracy_task_config(repo_path)
        config["tasks"]["test_accuracy"] = config["tasks"].pop("accuracy")
        config["workflows"] = {
            "bisect_pipeline": {"tasks": ["build", "test_accuracy"]},
        }
        config["bisect"] = {"workflow": "bisect_pipeline"}

        result = bisect_repo(
            config=config,
            workflow_name="bisect_pipeline",
            test_type="accuracy",
            good_commit=commits[0],
            bad_commit=commits[-1],
        )

        assert result.found_commit == commits[bad_from]

    def test_bisect_build_before_test_legacy_path_still_runs(self, tmp_path):
        """Legacy bisect.build_before_test configs still auto-resolve to a bisect workflow."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 10)
        bad_from = 5
        _write_accuracy_test(repo_path, bad_from)

        config = _new_accuracy_task_config(repo_path)
        config["bisect"] = {"build_before_test": True}

        result = bisect_repo(
            config=config,
            test_type="accuracy",
            good_commit=commits[0],
            bad_commit=commits[-1],
        )

        assert result.found_commit == commits[bad_from]

    def test_bisect_workflows_array_runs(self, tmp_path):
        """New bisect.workflows array configs run successfully."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 10)
        bad_from = 5
        _write_accuracy_test(repo_path, bad_from)

        config = _new_accuracy_task_config(repo_path)
        config["workflows"] = {
            "bisect_pipeline": {"tasks": ["build", "accuracy"]},
        }
        config["bisect"] = {
            "workflows": [{"name": "bisect_pipeline", "repeatable": True}],
        }

        result = bisect_repo(
            config=config,
            test_type="accuracy",
            good_commit=commits[0],
            bad_commit=commits[-1],
        )

        assert result.found_commit == commits[bad_from]

    def test_bisect_workflow_forwards_outlier_detection(self, tmp_path):
        """Bisect forwards bisect-level outlier settings into workflow repeat handling."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 3)

        config = _new_accuracy_task_config(repo_path)
        config["tasks"]["test_accuracy"] = config["tasks"].pop("accuracy")
        config["workflows"] = {
            "bisect_pipeline": {"tasks": ["build", "test_accuracy"]},
        }
        config["bisect"] = {
            "workflow": "bisect_pipeline",
            "outlier_detection": {"max_outlier_ratio": 0.3, "min_samples": 4},
        }

        captured = []

        def fake_run(self, workflow_cfg, tasks, working_dir, repo_name, variables,
                     global_env=None, config=None, repeat=1, repeat_agg="avg",
                     outlier_detection_cfg=None):
            captured.append(outlier_detection_cfg)
            return WorkflowResult(
                success=True,
                step_results=[StepResult(
                    task_name="test_accuracy",
                    task_result=TaskResult(success=True, stdout="", stderr=""),
                )],
                result_values={"value": 1.0},
            )

        with patch("forge.bisector._get_commit_range", return_value=commits), \
                patch("forge.bisector._checkout"), \
                patch("forge.bisector._run_pre_workflow"), \
                patch("forge.bisector._run_post_workflows"), \
                patch("forge.bisector.WorkflowRunner.run", fake_run):
            result = bisect_repo(
                config=config,
                workflow_name="bisect_pipeline",
                test_type="accuracy",
                good_commit=commits[0],
                bad_commit=commits[-1],
                repeat=2,
                repeat_agg="avg_without_outliers",
            )

        assert captured and captured[0] == {"max_outlier_ratio": 0.3, "min_samples": 4}
        assert result.total_steps >= 1

    def test_bisect_performance_baseline_uses_repeat_settings(self, tmp_path):
        """Performance baseline collection should use the same repeat settings as candidate runs."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 3)

        _write_performance_test(repo_path, bad_from=1, good_value=10.0, bad_value=12.0)

        config = {
            "name": "test_repo",
            "working_dir": repo_path,
            "tasks": {
                "build": {
                    "command": "bash build.sh",
                    "working_dir": ".",
                    "timeout": 60,
                },
                "performance": {
                    "command": "bash tests/run_perf.sh",
                    "working_dir": ".",
                    "timeout": 60,
                    "result": {
                        "type": "file",
                        "path": "tests/output/result.csv",
                        "format": "csv",
                        "value_column": 1,
                        "op_column": 0,
                        "header": True,
                        "delimiter": ",",
                    },
                },
            },
            "workflows": {
                "bisect_pipeline": {"tasks": ["build", "performance"]},
            },
            "bisect": {
                "workflow": "bisect_pipeline",
                "outlier_detection": {"max_outlier_ratio": 0.3, "min_samples": 4},
            },
        }

        captured = []

        def fake_run(self, workflow_cfg, tasks, working_dir, repo_name, variables,
                     global_env=None, config=None, repeat=1, repeat_agg="avg",
                     outlier_detection_cfg=None):
            captured.append({
                "commit": variables.get("commit"),
                "repeat": repeat,
                "repeat_agg": repeat_agg,
                "outlier_detection_cfg": outlier_detection_cfg,
            })
            value = 10.0 if variables.get("commit") == commits[0] else 12.0
            return WorkflowResult(
                success=True,
                step_results=[StepResult(
                    task_name="performance",
                    task_result=TaskResult(success=True, stdout="", stderr=""),
                )],
                result_values={"matmul": value},
            )

        with patch("forge.bisector._get_commit_range", return_value=commits[1:]), \
                patch("forge.bisector._checkout"), \
                patch("forge.bisector._run_pre_workflow"), \
                patch("forge.bisector._run_post_workflows"), \
                patch("forge.bisector.WorkflowRunner.run", fake_run):
            result = bisect_repo(
                config=config,
                workflow_name="bisect_pipeline",
                test_type="performance",
                good_commit=commits[0],
                bad_commit=commits[-1],
                repeat=2,
                repeat_agg="avg_without_outliers",
            )

        assert captured[0]["commit"] == commits[0]
        assert captured[0]["repeat"] == 2
        assert captured[0]["repeat_agg"] == "avg_without_outliers"
        assert captured[0]["outlier_detection_cfg"] == {"max_outlier_ratio": 0.3, "min_samples": 4}
        assert captured[1]["repeat"] == 2
        assert captured[1]["repeat_agg"] == "avg_without_outliers"
        assert captured[1]["outlier_detection_cfg"] == {"max_outlier_ratio": 0.3, "min_samples": 4}
        assert result.baseline_value == 10.0

    def test_bisect_legacy_working_dir_still_runs(self, tmp_path):
        """Legacy bisect.working_dir is still honored when git_repo is absent."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 10)
        bad_from = 5
        _write_accuracy_test(repo_path, bad_from)

        config = _new_accuracy_task_config(str(tmp_path / "non_git_repo"))
        config["bisect"] = {
            "working_dir": repo_path,
            "build_before_test": True,
        }

        result = bisect_repo(
            config=config,
            test_type="accuracy",
            good_commit=commits[0],
            bad_commit=commits[-1],
        )

        assert result.found_commit == commits[bad_from]

    def test_bisect_legacy_working_dir_performance_still_runs(self, tmp_path):
        """Legacy bisect.working_dir is honored for performance baseline and bisect runs."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 8)
        bad_from = 4
        _write_performance_test(repo_path, bad_from)

        config = {
            "name": "test_repo",
            "working_dir": str(tmp_path / "non_git_repo"),
            "tasks": {
                "build": {
                    "command": "bash build.sh",
                    "working_dir": ".",
                    "timeout": 60,
                },
                "performance": {
                    "command": "bash tests/run_perf.sh",
                    "working_dir": ".",
                    "timeout": 60,
                    "result": {
                        "type": "file",
                        "path": "tests/output/result.csv",
                        "format": "csv",
                        "value_column": 1,
                        "op_column": 0,
                        "header": True,
                        "delimiter": ",",
                    },
                },
            },
            "bisect": {
                "working_dir": repo_path,
                "build_before_test": True,
            },
        }

        result = bisect_repo(
            config=config,
            test_type="performance",
            good_commit=commits[0],
            bad_commit=commits[-1],
            op_name="matmul",
            regression_pct=50.0,
        )

        assert result.found_commit == commits[bad_from]


class TestBisect:
    def test_bisect_accuracy(self, tmp_path, sample_config):
        """Bisect finds the commit where accuracy test starts failing."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 10)
        bad_from = 5

        test_script = tmp_path / "repo" / "tests" / "run_test.py"
        test_script.write_text(
            "#!/usr/bin/env python3\n"
            "import sys\n"
            f"version = int(open('version.txt').read().strip())\n"
            f"if version >= {bad_from}:\n"
            "    print('accuracy FAIL')\n"
            "    sys.exit(1)\n"
            "else:\n"
            "    print('accuracy: 0.99')\n"
            "    print('accuracy PASS')\n"
        )

        sample_config["working_dir"] = repo_path
        sample_config["tasks"]["accuracy"]["working_dir"] = "."
        sample_config["tasks"]["accuracy"]["command"] = "python3 tests/run_test.py"
        sample_config["tasks"]["accuracy"]["success_pattern"] = "PASS"
        sample_config.setdefault("bisect", {})["build_before_test"] = True

        result = bisect_repo(
            config=sample_config, test_type="accuracy",
            good_commit=commits[0], bad_commit=commits[-1],
        )
        assert result.found_commit == commits[bad_from]

    def test_bisect_performance(self, tmp_path, sample_config):
        """Bisect finds the commit where performance regresses."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 8)
        bad_from = 4

        test_script = tmp_path / "repo" / "tests" / "run_perf.sh"
        output_dir = tmp_path / "repo" / "tests" / "output"
        output_dir.mkdir(parents=True)
        test_script.write_text(
            "#!/bin/bash\n"
            f"VERSION=$(cat version.txt)\n"
            f"if [ $VERSION -ge {bad_from} ]; then\n"
            f'  echo "op,time_ms" > tests/output/result.csv\n'
            f'  echo "matmul,50.0" >> tests/output/result.csv\n'
            "else\n"
            f'  echo "op,time_ms" > tests/output/result.csv\n'
            f'  echo "matmul,10.0" >> tests/output/result.csv\n'
            "fi\n"
        )
        test_script.chmod(0o755)

        sample_config["working_dir"] = repo_path
        sample_config["tasks"]["performance"]["working_dir"] = "."
        sample_config["tasks"]["performance"]["command"] = "bash tests/run_perf.sh"
        sample_config["tasks"]["performance"]["result"]["path"] = "tests/output/result.csv"
        sample_config.setdefault("bisect", {})["build_before_test"] = True
        result = bisect_repo(
            config=sample_config, test_type="performance",
            good_commit=commits[0], bad_commit=commits[-1],
            op_name="matmul", regression_pct=50.0,
        )
        assert result.found_commit == commits[bad_from]

    def test_bisect_with_threshold(self, tmp_path, sample_config):
        """Bisect using absolute threshold."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 6)
        bad_from = 3

        test_script = tmp_path / "repo" / "tests" / "run_perf.sh"
        output_dir = tmp_path / "repo" / "tests" / "output"
        output_dir.mkdir(parents=True)
        test_script.write_text(
            "#!/bin/bash\n"
            f"VERSION=$(cat version.txt)\n"
            f"if [ $VERSION -ge {bad_from} ]; then\n"
            f'  echo "op,time_ms" > tests/output/result.csv\n'
            f'  echo "matmul,20.0" >> tests/output/result.csv\n'
            "else\n"
            f'  echo "op,time_ms" > tests/output/result.csv\n'
            f'  echo "matmul,5.0" >> tests/output/result.csv\n'
            "fi\n"
        )
        test_script.chmod(0o755)

        sample_config["working_dir"] = repo_path
        sample_config["tasks"]["performance"]["working_dir"] = "."
        sample_config["tasks"]["performance"]["command"] = "bash tests/run_perf.sh"
        sample_config["tasks"]["performance"]["result"]["path"] = "tests/output/result.csv"
        sample_config.setdefault("bisect", {})["build_before_test"] = True
        result = bisect_repo(
            config=sample_config, test_type="performance",
            good_commit=commits[0], bad_commit=commits[-1],
            op_name="matmul", threshold=15.0,
        )
        assert result.found_commit == commits[bad_from]

    def test_bisect_regression_from_config(self, tmp_path, sample_config):
        """Config-level regression takes effect when CLI doesn't specify."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 8)
        bad_from = 4

        test_script = tmp_path / "repo" / "tests" / "run_perf.sh"
        output_dir = tmp_path / "repo" / "tests" / "output"
        output_dir.mkdir(parents=True)
        test_script.write_text(
            "#!/bin/bash\n"
            f"VERSION=$(cat version.txt)\n"
            f"if [ $VERSION -ge {bad_from} ]; then\n"
            f'  echo "op,time_ms" > tests/output/result.csv\n'
            f'  echo "matmul,50.0" >> tests/output/result.csv\n'
            "else\n"
            f'  echo "op,time_ms" > tests/output/result.csv\n'
            f'  echo "matmul,10.0" >> tests/output/result.csv\n'
            "fi\n"
        )
        test_script.chmod(0o755)

        sample_config["working_dir"] = repo_path
        sample_config["tasks"]["performance"]["working_dir"] = "."
        sample_config["tasks"]["performance"]["command"] = "bash tests/run_perf.sh"
        sample_config["tasks"]["performance"]["result"]["path"] = "tests/output/result.csv"
        sample_config["bisect"] = {"build_before_test": True, "regression": 50.0}
        result = bisect_repo(
            config=sample_config, test_type="performance",
            good_commit=commits[0], bad_commit=commits[-1],
            op_name="matmul",
        )
        assert result.found_commit == commits[bad_from]

    def test_bisect_cli_overrides_config_regression(self, tmp_path, sample_config):
        """CLI regression_pct overrides config value."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 8)
        bad_from = 4

        test_script = tmp_path / "repo" / "tests" / "run_perf.sh"
        output_dir = tmp_path / "repo" / "tests" / "output"
        output_dir.mkdir(parents=True)
        test_script.write_text(
            "#!/bin/bash\n"
            f"VERSION=$(cat version.txt)\n"
            f"if [ $VERSION -ge {bad_from} ]; then\n"
            f'  echo "op,time_ms" > tests/output/result.csv\n'
            f'  echo "matmul,50.0" >> tests/output/result.csv\n'
            "else\n"
            f'  echo "op,time_ms" > tests/output/result.csv\n'
            f'  echo "matmul,10.0" >> tests/output/result.csv\n'
            "fi\n"
        )
        test_script.chmod(0o755)

        sample_config["working_dir"] = repo_path
        sample_config["tasks"]["performance"]["working_dir"] = "."
        sample_config["tasks"]["performance"]["command"] = "bash tests/run_perf.sh"
        sample_config["tasks"]["performance"]["result"]["path"] = "tests/output/result.csv"
        sample_config["bisect"] = {"build_before_test": True, "regression": 1.0}
        result = bisect_repo(
            config=sample_config, test_type="performance",
            good_commit=commits[0], bad_commit=commits[-1],
            op_name="matmul", regression_pct=50.0,
        )
        assert result.found_commit == commits[bad_from]

    def test_bisect_threshold_from_config(self, tmp_path, sample_config):
        """Config-level threshold takes effect when CLI doesn't specify."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 6)
        bad_from = 3

        test_script = tmp_path / "repo" / "tests" / "run_perf.sh"
        output_dir = tmp_path / "repo" / "tests" / "output"
        output_dir.mkdir(parents=True)
        test_script.write_text(
            "#!/bin/bash\n"
            f"VERSION=$(cat version.txt)\n"
            f"if [ $VERSION -ge {bad_from} ]; then\n"
            f'  echo "op,time_ms" > tests/output/result.csv\n'
            f'  echo "matmul,20.0" >> tests/output/result.csv\n'
            "else\n"
            f'  echo "op,time_ms" > tests/output/result.csv\n'
            f'  echo "matmul,5.0" >> tests/output/result.csv\n'
            "fi\n"
        )
        test_script.chmod(0o755)

        sample_config["working_dir"] = repo_path
        sample_config["tasks"]["performance"]["working_dir"] = "."
        sample_config["tasks"]["performance"]["command"] = "bash tests/run_perf.sh"
        sample_config["tasks"]["performance"]["result"]["path"] = "tests/output/result.csv"
        sample_config["bisect"] = {"build_before_test": True, "threshold": 15.0}
        result = bisect_repo(
            config=sample_config, test_type="performance",
            good_commit=commits[0], bad_commit=commits[-1],
            op_name="matmul",
        )
        assert result.found_commit == commits[bad_from]

    def test_bisect_with_repeat(self, tmp_path, sample_config):
        """Bisect passes repeat to test execution."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 8)
        bad_from = 4

        test_script = tmp_path / "repo" / "tests" / "run_perf.sh"
        output_dir = tmp_path / "repo" / "tests" / "output"
        output_dir.mkdir(parents=True)
        test_script.write_text(
            "#!/bin/bash\n"
            f"VERSION=$(cat version.txt)\n"
            f"if [ $VERSION -ge {bad_from} ]; then\n"
            f'  echo "op,time_ms" > tests/output/result.csv\n'
            f'  echo "matmul,50.0" >> tests/output/result.csv\n'
            "else\n"
            f'  echo "op,time_ms" > tests/output/result.csv\n'
            f'  echo "matmul,10.0" >> tests/output/result.csv\n'
            "fi\n"
        )
        test_script.chmod(0o755)

        sample_config["working_dir"] = repo_path
        sample_config["tasks"]["performance"]["working_dir"] = "."
        sample_config["tasks"]["performance"]["command"] = "bash tests/run_perf.sh"
        sample_config["tasks"]["performance"]["result"]["path"] = "tests/output/result.csv"
        sample_config.setdefault("bisect", {})["build_before_test"] = True
        result = bisect_repo(
            config=sample_config, test_type="performance",
            good_commit=commits[0], bad_commit=commits[-1],
            op_name="matmul", regression_pct=50.0,
            repeat=2, repeat_agg="avg",
        )
        assert result.found_commit == commits[bad_from]

    def test_bisect_accuracy_with_repeat(self, tmp_path, sample_config):
        """Bisect accuracy with repeat for flaky failure detection."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 6)
        bad_from = 3

        test_script = tmp_path / "repo" / "tests" / "run_test.py"
        test_script.write_text(
            "#!/usr/bin/env python3\n"
            "import sys\n"
            f"version = int(open('version.txt').read().strip())\n"
            f"if version >= {bad_from}:\n"
            "    print('accuracy FAIL')\n"
            "    sys.exit(1)\n"
            "else:\n"
            "    print('accuracy: 0.99')\n"
            "    print('accuracy PASS')\n"
        )

        sample_config["working_dir"] = repo_path
        sample_config["tasks"]["accuracy"]["working_dir"] = "."
        sample_config["tasks"]["accuracy"]["command"] = "python3 tests/run_test.py"
        sample_config["tasks"]["accuracy"]["success_pattern"] = "PASS"
        sample_config.setdefault("bisect", {})["build_before_test"] = True
        result = bisect_repo(
            config=sample_config, test_type="accuracy",
            good_commit=commits[0], bad_commit=commits[-1],
            repeat=3,
        )
        assert result.found_commit == commits[bad_from]


class TestBisectWorkflow:
    def test_bisect_with_workflow_accuracy(self, tmp_path, sample_config):
        """Bisect using a workflow instead of hardcoded build+test."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 10)
        bad_from = 5

        test_script = tmp_path / "repo" / "tests" / "run_test.py"
        test_script.write_text(
            "#!/usr/bin/env python3\n"
            "import sys\n"
            f"version = int(open('version.txt').read().strip())\n"
            f"if version >= {bad_from}:\n"
            "    print('accuracy FAIL')\n"
            "    sys.exit(1)\n"
            "else:\n"
            "    print('accuracy: 0.99')\n"
            "    print('accuracy PASS')\n"
        )

        config = {
            "name": "test_repo",
            "working_dir": repo_path,
            "tasks": {
                "build": {
                    "command": "bash build.sh",
                    "working_dir": ".",
                    "timeout": 60,
                },
                "test_accuracy": {
                    "command": "python3 tests/run_test.py",
                    "working_dir": ".",
                    "timeout": 60,
                    "success_pattern": "PASS",
                    "result": {
                        "type": "stdout",
                        "pattern": "accuracy: ([0-9.]+)",
                    },
                },
            },
            "workflows": {
                "bisect_pipeline": {"tasks": ["build", "test_accuracy"]},
            },
            "bisect": {"workflow": "bisect_pipeline"},
        }

        result = bisect_repo(
            config=config, workflow_name="bisect_pipeline",
            good_commit=commits[0], bad_commit=commits[-1],
            test_type="accuracy",
        )
        assert result.found_commit == commits[bad_from]

    def test_bisect_with_workflow_performance(self, tmp_path):
        """Bisect using a workflow for performance regression."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 8)
        bad_from = 4

        test_script = tmp_path / "repo" / "tests" / "run_perf.sh"
        output_dir = tmp_path / "repo" / "tests" / "output"
        output_dir.mkdir(parents=True)
        test_script.write_text(
            "#!/bin/bash\n"
            f"VERSION=$(cat version.txt)\n"
            f"if [ $VERSION -ge {bad_from} ]; then\n"
            f'  echo "op,time_ms" > tests/output/result.csv\n'
            f'  echo "matmul,50.0" >> tests/output/result.csv\n'
            "else\n"
            f'  echo "op,time_ms" > tests/output/result.csv\n'
            f'  echo "matmul,10.0" >> tests/output/result.csv\n'
            "fi\n"
        )
        test_script.chmod(0o755)

        config = {
            "name": "test_repo",
            "working_dir": repo_path,
            "tasks": {
                "build": {
                    "command": "bash build.sh",
                    "working_dir": ".",
                    "timeout": 60,
                },
                "test_performance": {
                    "command": "bash tests/run_perf.sh",
                    "working_dir": ".",
                    "timeout": 60,
                    "result": {
                        "type": "file",
                        "path": "tests/output/result.csv",
                        "format": "csv",
                        "value_column": 1,
                        "op_column": 0,
                        "header": True,
                        "delimiter": ",",
                    },
                },
            },
            "workflows": {
                "bisect_pipeline": {"tasks": ["build", "test_performance"]},
            },
            "bisect": {"workflow": "bisect_pipeline"},
        }

        result = bisect_repo(
            config=config, workflow_name="bisect_pipeline",
            good_commit=commits[0], bad_commit=commits[-1],
            test_type="performance", op_name="matmul", regression_pct=50.0,
        )
        assert result.found_commit == commits[bad_from]

    def test_bisect_workflow_step_failure_skips_commit(self, tmp_path):
        """When a non-judge step fails, the commit is skipped."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 6)

        build_script = tmp_path / "repo" / "build.sh"
        build_script.write_text(
            "#!/bin/bash\n"
            "VERSION=$(cat version.txt)\n"
            "if [ $VERSION -eq 2 ]; then\n"
            "  echo 'Build FAIL'\n"
            "  exit 1\n"
            "fi\n"
            "echo 'Build succeeded'\n"
        )

        test_script = tmp_path / "repo" / "tests" / "run_test.py"
        test_script.write_text(
            "#!/usr/bin/env python3\n"
            "import sys\n"
            "version = int(open('version.txt').read().strip())\n"
            "if version >= 3:\n"
            "    print('FAIL')\n"
            "    sys.exit(1)\n"
            "else:\n"
            "    print('accuracy: 0.99')\n"
            "    print('PASS')\n"
        )

        config = {
            "name": "test_repo",
            "working_dir": repo_path,
            "tasks": {
                "build": {"command": "bash build.sh", "working_dir": ".", "timeout": 60},
                "test_accuracy": {
                    "command": "python3 tests/run_test.py",
                    "working_dir": ".",
                    "timeout": 60,
                    "success_pattern": "PASS",
                    "result": {"type": "stdout", "pattern": "accuracy: ([0-9.]+)"},
                },
            },
            "workflows": {
                "pipeline": {"tasks": ["build", "test_accuracy"]},
            },
            "bisect": {"workflow": "pipeline"},
        }

        result = bisect_repo(
            config=config, workflow_name="pipeline",
            good_commit=commits[0], bad_commit=commits[-1],
            test_type="accuracy",
        )
        assert result.found_commit == commits[3]
        assert result.skipped_steps > 0

    def test_bisect_post_workflow_true(self, tmp_path):
        """post_workflow: true runs the bisect workflow after restoring."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 6)
        bad_from = 3

        test_script = tmp_path / "repo" / "tests" / "run_test.py"
        test_script.write_text(
            "#!/usr/bin/env python3\n"
            "import sys\n"
            "version = int(open('version.txt').read().strip())\n"
            f"if version >= {bad_from}:\n"
            "    print('FAIL')\n"
            "    sys.exit(1)\n"
            "else:\n"
            "    print('accuracy: 0.99')\n"
            "    print('PASS')\n"
        )

        # Track workflow invocations via a marker file
        marker = tmp_path / "post_wf_marker"
        build_script = tmp_path / "repo" / "build.sh"
        build_script.write_text(
            "#!/bin/bash\n"
            f"echo \"build:$(cat version.txt)\" >> {marker}\n"
            "echo 'Build succeeded'\n"
        )

        config = {
            "name": "test_repo",
            "working_dir": repo_path,
            "tasks": {
                "build": {"command": "bash build.sh", "working_dir": ".", "timeout": 60},
                "test_accuracy": {
                    "command": "python3 tests/run_test.py",
                    "working_dir": ".", "timeout": 60,
                    "success_pattern": "PASS",
                    "result": {"type": "stdout", "pattern": "accuracy: ([0-9.]+)"},
                },
            },
            "workflows": {
                "pipeline": {"tasks": ["build", "test_accuracy"]},
            },
            "bisect": {"workflow": "pipeline", "post_workflow": True},
        }

        result = bisect_repo(
            config=config, workflow_name="pipeline",
            good_commit=commits[0], bad_commit=commits[-1],
            test_type="accuracy",
        )
        assert result.found_commit == commits[bad_from]

        # The marker file should show the post-workflow ran a build at the original commit
        marker_lines = marker.read_text().strip().split("\n")
        # Post-workflow should have appended one more build entry after bisect finished
        last_build = marker_lines[-1]
        assert last_build.startswith("build:")
        # The last entry must be from the original HEAD (commits[-1] = version 5),
        # not from a bisect step — confirming post-workflow ran after restore
        assert last_build == f"build:{len(commits) - 1}"

    def test_bisect_post_workflow_named(self, tmp_path):
        """post_workflow as string runs the specified workflow after restoring."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 6)
        bad_from = 3

        test_script = tmp_path / "repo" / "tests" / "run_test.py"
        test_script.write_text(
            "#!/usr/bin/env python3\n"
            "import sys\n"
            "version = int(open('version.txt').read().strip())\n"
            f"if version >= {bad_from}:\n"
            "    print('FAIL')\n"
            "    sys.exit(1)\n"
            "else:\n"
            "    print('accuracy: 0.99')\n"
            "    print('PASS')\n"
        )

        # A separate "restore" workflow that only builds (no test)
        marker = tmp_path / "restore_marker"
        build_script = tmp_path / "repo" / "build.sh"
        build_script.write_text(
            "#!/bin/bash\n"
            f"echo \"restore:$(cat version.txt)\" >> {marker}\n"
            "echo 'Build succeeded'\n"
        )

        config = {
            "name": "test_repo",
            "working_dir": repo_path,
            "tasks": {
                "build": {"command": "bash build.sh", "working_dir": ".", "timeout": 60},
                "test_accuracy": {
                    "command": "python3 tests/run_test.py",
                    "working_dir": ".", "timeout": 60,
                    "success_pattern": "PASS",
                    "result": {"type": "stdout", "pattern": "accuracy: ([0-9.]+)"},
                },
            },
            "workflows": {
                "bisect_pipeline": {"tasks": ["build", "test_accuracy"]},
                "restore_only": {"tasks": ["build"]},
            },
            "bisect": {"workflow": "bisect_pipeline", "post_workflow": "restore_only"},
        }

        result = bisect_repo(
            config=config, workflow_name="bisect_pipeline",
            good_commit=commits[0], bad_commit=commits[-1],
            test_type="accuracy",
        )
        assert result.found_commit == commits[bad_from]

        # restore_only workflow should have run after bisect
        marker_content = marker.read_text().strip()
        lines = marker_content.split("\n")
        # Last entry is from the post-workflow restore
        assert lines[-1].startswith("restore:")

    def test_bisect_no_post_workflow(self, tmp_path):
        """Without post_workflow, no extra workflow runs after restore."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 6)
        bad_from = 3

        test_script = tmp_path / "repo" / "tests" / "run_test.py"
        test_script.write_text(
            "#!/usr/bin/env python3\n"
            "import sys\n"
            "version = int(open('version.txt').read().strip())\n"
            f"if version >= {bad_from}:\n"
            "    print('FAIL')\n"
            "    sys.exit(1)\n"
            "else:\n"
            "    print('accuracy: 0.99')\n"
            "    print('PASS')\n"
        )

        marker = tmp_path / "build_marker"
        build_script = tmp_path / "repo" / "build.sh"
        build_script.write_text(
            "#!/bin/bash\n"
            f"echo \"build:$(cat version.txt)\" >> {marker}\n"
            "echo 'Build succeeded'\n"
        )

        config = {
            "name": "test_repo",
            "working_dir": repo_path,
            "tasks": {
                "build": {"command": "bash build.sh", "working_dir": ".", "timeout": 60},
                "test_accuracy": {
                    "command": "python3 tests/run_test.py",
                    "working_dir": ".", "timeout": 60,
                    "success_pattern": "PASS",
                    "result": {"type": "stdout", "pattern": "accuracy: ([0-9.]+)"},
                },
            },
            "workflows": {
                "pipeline": {"tasks": ["build", "test_accuracy"]},
            },
            "bisect": {"workflow": "pipeline"},
        }

        result = bisect_repo(
            config=config, workflow_name="pipeline",
            good_commit=commits[0], bad_commit=commits[-1],
            test_type="accuracy",
        )
        assert result.found_commit == commits[bad_from]

        # Count build invocations — should only be from bisect steps, no post-workflow
        build_count = len(marker.read_text().strip().split("\n"))
        # Re-run with post_workflow to compare
        marker.unlink()
        config["bisect"]["post_workflow"] = True
        result2 = bisect_repo(
            config=config, workflow_name="pipeline",
            good_commit=commits[0], bad_commit=commits[-1],
            test_type="accuracy",
        )
        build_count_with_post = len(marker.read_text().strip().split("\n"))
        # With post_workflow, there should be one extra build
        assert build_count_with_post == build_count + 1

    def test_bisect_post_workflow_failure_warns(self, tmp_path):
        """post_workflow failure logs warning but doesn't affect bisect result."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 6)
        bad_from = 3

        test_script = tmp_path / "repo" / "tests" / "run_test.py"
        test_script.write_text(
            "#!/usr/bin/env python3\n"
            "import sys\n"
            "version = int(open('version.txt').read().strip())\n"
            f"if version >= {bad_from}:\n"
            "    print('FAIL')\n"
            "    sys.exit(1)\n"
            "else:\n"
            "    print('accuracy: 0.99')\n"
            "    print('PASS')\n"
        )

        config = {
            "name": "test_repo",
            "working_dir": repo_path,
            "tasks": {
                "build": {"command": "bash build.sh", "working_dir": ".", "timeout": 60},
                "test_accuracy": {
                    "command": "python3 tests/run_test.py",
                    "working_dir": ".", "timeout": 60,
                    "success_pattern": "PASS",
                    "result": {"type": "stdout", "pattern": "accuracy: ([0-9.]+)"},
                },
                "failing_restore": {
                    "command": "bash -c 'exit 1'",
                    "working_dir": ".", "timeout": 60,
                },
            },
            "workflows": {
                "pipeline": {"tasks": ["build", "test_accuracy"]},
                "bad_restore": {"tasks": ["failing_restore"]},
            },
            "bisect": {"workflow": "pipeline", "post_workflow": "bad_restore"},
        }

        # Should NOT raise — post_workflow failure is warning only
        result = bisect_repo(
            config=config, workflow_name="pipeline",
            good_commit=commits[0], bad_commit=commits[-1],
            test_type="accuracy",
        )
        assert result.found_commit == commits[bad_from]

    def test_bisect_pre_workflow_runs_once_before_loop(self, tmp_path):
        """pre_workflow runs once before the bisect loop and before commit-specific steps."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 6)
        bad_from = 3

        test_script = tmp_path / "repo" / "tests" / "run_test.py"
        test_script.write_text(
            "#!/usr/bin/env python3\n"
            "import sys\n"
            "version = int(open('version.txt').read().strip())\n"
            f"if version >= {bad_from}:\n"
            "    print('FAIL')\n"
            "    sys.exit(1)\n"
            "else:\n"
            "    print('accuracy: 0.99')\n"
            "    print('PASS')\n"
        )

        marker = tmp_path / "pre_wf_marker"
        build_script = tmp_path / "repo" / "build.sh"
        build_script.write_text(
            "#!/bin/bash\n"
            f"echo \"build:$(cat version.txt)\" >> {marker}\n"
            "echo 'Build succeeded'\n"
        )
        prepare_script = tmp_path / "repo" / "prepare.sh"
        prepare_script.write_text(
            "#!/bin/bash\n"
            f"echo \"prepare:$(cat version.txt)\" >> {marker}\n"
            "echo 'Prepared'\n"
        )
        build_script.chmod(0o755)
        prepare_script.chmod(0o755)

        config = {
            "name": "test_repo",
            "working_dir": repo_path,
            "tasks": {
                "prepare": {"command": "bash prepare.sh", "working_dir": ".", "timeout": 60},
                "build": {"command": "bash build.sh", "working_dir": ".", "timeout": 60},
                "test_accuracy": {
                    "command": "python3 tests/run_test.py",
                    "working_dir": ".", "timeout": 60,
                    "success_pattern": "PASS",
                    "result": {"type": "stdout", "pattern": "accuracy: ([0-9.]+)"},
                },
            },
            "workflows": {
                "prepare_once": {"tasks": ["prepare"]},
                "pipeline": {"tasks": ["build", "test_accuracy"]},
            },
            "bisect": {
                "workflow": "pipeline",
                "pre_workflow": "prepare_once",
            },
        }

        result = bisect_repo(
            config=config, workflow_name="pipeline",
            good_commit=commits[0], bad_commit=commits[-1],
            test_type="accuracy",
        )
        assert result.found_commit == commits[bad_from]

        lines = marker.read_text().strip().split("\n")
        assert lines[0] == f"prepare:{len(commits) - 1}"
        assert lines.count(f"prepare:{len(commits) - 1}") == 1
        assert all(not line.startswith("prepare:") for line in lines[1:])


class TestBisectWorkflowRequired:
    def test_bisect_without_workflow_raises_with_migrate_hint(self, tmp_path):
        """bisect requires workflow field, error includes migrate hint."""
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 6)

        test_script = tmp_path / "repo" / "tests" / "run_test.py"
        test_script.write_text(
            "#!/usr/bin/env python3\n"
            "import sys\n"
            "print('accuracy PASS')\n"
        )

        config = {
            "name": "test_repo",
            "working_dir": repo_path,
            "tasks": {
                "accuracy": {
                    "command": "python3 tests/run_test.py",
                    "working_dir": ".",
                    "success_pattern": "PASS",
                },
            },
            # No workflow defined
            "bisect": {"regression": 10.0},
        }

        with pytest.raises(BisectAbortError, match="forge migrate"):
            bisect_repo(
                config=config,
                good_commit=commits[0], bad_commit=commits[-1],
                test_type="accuracy",
            )

    def test_build_before_test_deprecated_warning(self, tmp_path, sample_config_legacy, capsys):
        """bisect.build_before_test emits stderr warning with migrate hint exactly once."""
        import warnings
        repo_path, commits = _create_git_repo_with_commits(tmp_path, 6)
        bad_from = 3

        test_script = tmp_path / "repo" / "tests" / "run_test.py"
        test_script.write_text(
            "#!/usr/bin/env python3\n"
            "import sys\n"
            f"version = int(open('version.txt').read().strip())\n"
            f"if version >= {bad_from}:\n"
            "    print('accuracy FAIL')\n"
            "    sys.exit(1)\n"
            "else:\n"
            "    print('accuracy: 0.99')\n"
            "    print('accuracy PASS')\n"
        )

        # Use legacy config with build_before_test
        sample_config_legacy["working_dir"] = repo_path
        sample_config_legacy["tests"]["accuracy"]["working_dir"] = "."
        sample_config_legacy["tests"]["accuracy"]["command"] = "python3 tests/run_test.py"
        sample_config_legacy["tests"]["accuracy"]["success_pattern"] = "PASS"
        sample_config_legacy["bisect"] = {"build_before_test": True, "regression": 10.0}

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            result = bisect_repo(
                config=sample_config_legacy,
                good_commit=commits[0], bad_commit=commits[-1],
                test_type="accuracy",
            )
            assert result.found_commit == commits[bad_from]
            # Legacy build/tests fields emit warnings.warn() deprecation
            assert len(w) >= 1
            assert "forge migrate" in str(w[0].message).lower()

        # Check stderr for build_before_test deprecation warning
        captured = capsys.readouterr()
        assert "build_before_test" in captured.err
        assert "forge migrate" in captured.err
        assert captured.err.count("build_before_test") == 1
