import json

from scripts.build_zsearch_raw_result import run_build_zsearch_raw_result
from scripts.export_zsearch_trial_manifest import run_export_trial_manifest


def test_export_zsearch_trial_manifest_records_only_current_trial_csv(tmp_path):
    prof_dir = tmp_path / "PROF_001"
    out_dir = prof_dir / "mindstudio_profiler_output"
    out_dir.mkdir(parents=True)
    csv_path = out_dir / "op_summary_001.csv"
    csv_path.write_text("op,time\nMyOp,10.0\n")
    manifest = tmp_path / "manifest.jsonl"

    run_export_trial_manifest(
        prof_dir=str(prof_dir),
        manifest_path=str(manifest),
        trial_index=3,
    )

    lines = manifest.read_text().splitlines()
    assert len(lines) == 1
    record = json.loads(lines[0])
    assert record["trial_index"] == 3
    assert record["prof_dir"] == str(prof_dir)
    assert record["op_summary_file"] == str(csv_path)


def test_export_zsearch_trial_manifest_auto_increments_trial_index(tmp_path):
    prof_dir = tmp_path / "PROF_002"
    out_dir = prof_dir / "mindstudio_profiler_output"
    out_dir.mkdir(parents=True)
    csv_path = out_dir / "op_summary_001.csv"
    csv_path.write_text("op,time\nMyOp,10.0\n")
    manifest = tmp_path / "manifest.jsonl"
    manifest.write_text(json.dumps({"trial_index": 1, "prof_dir": "/tmp/prev", "op_summary_file": "/tmp/prev.csv"}) + "\n")

    run_export_trial_manifest(
        prof_dir=str(prof_dir),
        manifest_path=str(manifest),
    )

    lines = manifest.read_text().splitlines()
    assert len(lines) == 2
    record = json.loads(lines[-1])
    assert record["trial_index"] == 2
    assert record["op_summary_file"] == str(csv_path)


def test_build_zsearch_raw_result_reads_only_manifested_csvs(tmp_path):
    keep1 = tmp_path / "keep1.csv"
    keep1.write_text("OP Type,Task Duration(us)\nMyOp,10.0\n", encoding="utf-8")
    keep2 = tmp_path / "keep2.csv"
    keep2.write_text("OP Type,Task Duration(us)\nMyOp,12.0\n", encoding="utf-8")
    stray = tmp_path / "stray.csv"
    stray.write_text("OP Type,Task Duration(us)\nMyOp,999.0\n", encoding="utf-8")

    manifest = tmp_path / "manifest.jsonl"
    manifest.write_text(
        json.dumps({"trial_index": 1, "prof_dir": "/tmp/a", "op_summary_file": str(keep1)}) + "\n" +
        json.dumps({"trial_index": 2, "prof_dir": "/tmp/b", "op_summary_file": str(keep2)}) + "\n",
        encoding="utf-8",
    )

    output = tmp_path / "forge_raw_result.json"
    run_build_zsearch_raw_result(
        manifest_path=str(manifest),
        output_path=str(output),
        op_name="MyOp",
        side="evolved",
        precision_passed=True,
        correctness_message="PASS",
        build_success=True,
    )

    data = json.loads(output.read_text(encoding="utf-8"))
    assert "samples" not in data["evolved"]
    assert data["evolved"]["raw_op_summary_files"] == [str(keep1), str(keep2)]
    assert data["evolved"]["warmup_count"] == 0


def test_build_zsearch_raw_result_emits_authoritative_csv_list(tmp_path):
    manifest = tmp_path / "manifest.jsonl"
    csv1 = tmp_path / "trial1.csv"
    csv2 = tmp_path / "trial2.csv"
    csv1.write_text("OP Type,Task Duration(us)\nMyOp,10\n", encoding="utf-8")
    csv2.write_text("OP Type,Task Duration(us)\nMyOp,12\n", encoding="utf-8")
    manifest.write_text(
        "\n".join([
            json.dumps({"trial_index": 1, "prof_dir": "/tmp/prof_1", "op_summary_file": str(csv1)}),
            json.dumps({"trial_index": 2, "prof_dir": "/tmp/prof_2", "op_summary_file": str(csv2)}),
        ]) + "\n",
        encoding="utf-8",
    )

    output = tmp_path / "forge_raw_result.json"
    run_build_zsearch_raw_result(
        manifest_path=str(manifest),
        output_path=str(output),
        op_name="MyOp",
        side="evolved",
        precision_passed=True,
        correctness_message="PASS",
        build_success=True,
        repo_type="omni-ops",
        soc="ascend910b",
        task_type="performance",
    )

    payload = json.loads(output.read_text(encoding="utf-8"))
    evolved = payload["evolved"]
    assert payload["schema_version"] == "1.0"
    assert payload["eval_backend"] == "forge"
    assert payload["task_type"] == "performance"
    assert payload["meta"]["sample_source"] == "raw_op_summary_files"
    assert evolved["raw_op_summary_files"] == [str(csv1), str(csv2)]
    assert "samples" not in evolved
    assert evolved["warmup_count"] == 0
    assert "profile_rows" not in evolved
    assert "pipeline" not in evolved
    assert "pipeline_candidates" not in evolved


def test_build_zsearch_raw_result_preserves_manifest_trial_order(tmp_path):
    manifest = tmp_path / "manifest.jsonl"
    csv1 = tmp_path / "trial10.csv"
    csv2 = tmp_path / "trial11.csv"
    csv1.write_text("OP Type,Task Duration(us)\nMyOp,30\n", encoding="utf-8")
    csv2.write_text("OP Type,Task Duration(us)\nMyOp,20\n", encoding="utf-8")
    manifest.write_text(
        "\n".join([
            json.dumps({"trial_index": 10, "prof_dir": "/tmp/prof_10", "op_summary_file": str(csv1)}),
            json.dumps({"trial_index": 11, "prof_dir": "/tmp/prof_11", "op_summary_file": str(csv2)}),
        ]) + "\n",
        encoding="utf-8",
    )

    output = tmp_path / "forge_raw_result.json"
    run_build_zsearch_raw_result(
        manifest_path=str(manifest),
        output_path=str(output),
        op_name="MyOp",
        side="evolved",
        precision_passed=True,
        correctness_message="PASS",
        build_success=True,
        repo_type="omni-ops",
        soc="ascend910b",
        task_type="performance",
    )

    payload = json.loads(output.read_text(encoding="utf-8"))
    assert payload["evolved"]["raw_op_summary_files"] == [str(csv1), str(csv2)]


def test_build_zsearch_raw_result_supports_wildcard_op_filter(tmp_path):
    csv_path = tmp_path / "sample.csv"
    csv_path.write_text(
        "OP Type,Task Duration(us)\naclnnPromptFlashAttentionV2,10.0\naclnnPromptFlashAttentionV2,12.0\nOtherOp,99.0\n",
        encoding="utf-8",
    )
    manifest = tmp_path / "manifest.jsonl"
    manifest.write_text(
        json.dumps({"trial_index": 1, "prof_dir": "/tmp/a", "op_summary_file": str(csv_path)}) + "\n",
        encoding="utf-8",
    )
    output = tmp_path / "forge_raw_result.json"

    run_build_zsearch_raw_result(
        manifest_path=str(manifest),
        output_path=str(output),
        op_name="PromptFlashAttention",
        op_filter="aclnnPromptFlashAttention*",
        side="evolved",
        precision_passed=True,
        correctness_message="PASS",
        build_success=True,
    )

    data = json.loads(output.read_text(encoding="utf-8"))
    assert "samples" not in data["evolved"]
    assert data["evolved"]["raw_op_summary_files"] == [str(csv_path)]


def test_build_zsearch_raw_result_records_warmup_count(tmp_path):
    csv_path = tmp_path / "trial.csv"
    csv_path.write_text("OP Type,Task Duration(us)\nMyOp,10\n", encoding="utf-8")
    manifest = tmp_path / "manifest.jsonl"
    manifest.write_text(
        json.dumps({"trial_index": 1, "prof_dir": "/tmp/a", "op_summary_file": str(csv_path)}) + "\n",
        encoding="utf-8",
    )
    output = tmp_path / "forge_raw_result.json"

    run_build_zsearch_raw_result(
        manifest_path=str(manifest),
        output_path=str(output),
        op_name="MyOp",
        side="evolved",
        precision_passed=True,
        correctness_message="PASS",
        build_success=True,
        warmup=5,
    )

    data = json.loads(output.read_text(encoding="utf-8"))
    assert data["evolved"]["warmup_count"] == 5
    assert data["evolved"]["raw_op_summary_files"] == [str(csv_path)]
    assert "samples" not in data["evolved"]
    assert data["meta"]["warmup_included_in_csv"] is True
    assert data["meta"]["warmup_count_field"] == "warmup_count"
