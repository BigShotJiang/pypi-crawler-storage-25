import csv
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
SCRIPT = REPO_ROOT / "scripts" / "parse_accuracy_csv.py"


def _run(csv_content: str, tmp_path: Path) -> subprocess.CompletedProcess:
    input_csv = tmp_path / "accuracy.csv"
    input_csv.write_text(csv_content, encoding="utf-8")
    output_csv = tmp_path / "metrics.csv"
    args = [sys.executable, str(SCRIPT), "--csv", str(input_csv), "--output", str(output_csv)]
    return subprocess.run(args, capture_output=True, text=True)


def test_all_pass(tmp_path):
    content = (
        "op,impl,case_type,case_index,result,max_abs_error,max_rel_error,mean_abs_error,mean_rel_error,error\n"
        "flash_attention,ascendc,basic,0,pass,0.001,0.0001,0.0005,0.00005,\n"
        "flash_attention,ascendc,basic,1,pass,0.002,0.0002,0.0010,0.00010,\n"
    )
    result = _run(content, tmp_path)
    assert result.returncode == 0, result.stderr
    out = tmp_path / "metrics.csv"
    rows = list(csv.DictReader(out.read_text(encoding="utf-8").splitlines()))
    metrics = {r["metric"]: r["value"] for r in rows}
    assert metrics["flash_attention_ascendc_basic_0_pass"] == "1"
    assert metrics["flash_attention_ascendc_basic_0_max_abs_error"] == "0.001"
    assert metrics["flash_attention_ascendc_basic_1_pass"] == "1"
    assert metrics["ALL_PASS"] == "1"
    assert metrics["TOTAL_CASES"] == "2"
    assert metrics["PASS_COUNT"] == "2"
    assert metrics["FAIL_COUNT"] == "0"


def test_mixed_pass_fail(tmp_path):
    content = (
        "op,impl,case_type,case_index,result,max_abs_error,max_rel_error,mean_abs_error,mean_rel_error,error\n"
        "flash_attention,ascendc,basic,0,pass,0.001,0.0001,0.0005,0.00005,\n"
        "flash_attention,ascendc,basic,1,fail,0.050,0.0100,0.0200,0.00500,\n"
    )
    result = _run(content, tmp_path)
    assert result.returncode == 1, result.stderr
    out = tmp_path / "metrics.csv"
    rows = list(csv.DictReader(out.read_text(encoding="utf-8").splitlines()))
    metrics = {r["metric"]: r["value"] for r in rows}
    assert metrics["flash_attention_ascendc_basic_0_pass"] == "1"
    assert metrics["flash_attention_ascendc_basic_1_pass"] == "0"
    assert metrics["ALL_PASS"] == "0"
    assert metrics["PASS_COUNT"] == "1"
    assert metrics["FAIL_COUNT"] == "1"


def test_missing_file(tmp_path):
    args = [
        sys.executable, str(SCRIPT),
        "--csv", str(tmp_path / "nonexistent.csv"),
        "--output", str(tmp_path / "out.csv"),
    ]
    result = subprocess.run(args, capture_output=True, text=True)
    assert result.returncode == 1


def test_malformed_result_field(tmp_path):
    content = (
        "op,impl,case_type,case_index,result,max_abs_error,max_rel_error,mean_abs_error,mean_rel_error,error\n"
        "flash_attention,ascendc,basic,0,PASS,0.001,0.0001,0.0005,0.00005,\n"
    )
    result = _run(content, tmp_path)
    # "PASS" != "pass" -> treated as fail
    assert result.returncode == 1
