import io
import os
import subprocess
import logging
from unittest.mock import patch

import pytest
from forge.cli import REPEAT_AG_CHOICES, build_parser, main, _build_task_args, _parse_args_list, _setup_logging
from forge.task import TaskResult


@pytest.fixture
def setup_config_env(tmp_path, write_config, sample_config, mock_repo, monkeypatch):
    """Set up a full environment for CLI testing."""
    sample_config["working_dir"] = str(mock_repo)
    write_config("test_repo", sample_config)
    monkeypatch.setenv("FORGE_CONFIG_DIR", str(tmp_path / "configs"))
    return sample_config


@pytest.fixture(autouse=True)
def _isolate_home(tmp_path, monkeypatch):
    """Keep CLI log writes inside the test temp directory."""
    monkeypatch.setenv("HOME", str(tmp_path))


class TestList:
    def test_list_repos(self, setup_config_env, capsys):
        main(["list"])
        captured = capsys.readouterr()
        assert "test_repo" in captured.out
        assert "Test repo" in captured.out
        assert "使用场景:" not in captured.out

    def test_list_empty(self, tmp_path, monkeypatch, capsys):
        empty_dir = tmp_path / "empty_configs"
        empty_dir.mkdir()
        monkeypatch.setenv("FORGE_CONFIG_DIR", str(empty_dir))
        main(["list"])
        captured = capsys.readouterr()
        assert "No repos configured" in captured.out


class TestShow:
    def test_show_repo(self, setup_config_env, capsys):
        main(["show", "test_repo"])
        captured = capsys.readouterr()
        assert "test_repo" in captured.out
        assert '"usage"' in captured.out
        assert "使用场景:" in captured.out
        assert "使用方法:" in captured.out

    def test_show_nonexistent(self, setup_config_env):
        with pytest.raises(SystemExit):
            main(["show", "nonexistent"])


class TestUsage:
    def test_usage_repo(self, setup_config_env, capsys):
        main(["usage", "test_repo"])
        captured = capsys.readouterr()
        assert "test_repo" in captured.out
        assert "Test repo" in captured.out
        assert "使用场景:" in captured.out
        assert "forge build test_repo --arg op_name=MatMul --arg target=ascend910" in captured.out

    def test_usage_nonexistent(self, setup_config_env):
        with pytest.raises(SystemExit):
            main(["usage", "nonexistent"])


class TestValidate:
    def test_validate_valid(self, setup_config_env, capsys):
        main(["validate", "test_repo"])
        captured = capsys.readouterr()
        assert "valid" in captured.out

    def test_validate_nonexistent(self, setup_config_env):
        with pytest.raises(SystemExit):
            main(["validate", "nonexistent"])


class TestBuild:
    def test_build_repo(self, setup_config_env, capsys):
        main(["build", "test_repo"])
        captured = capsys.readouterr()
        assert "succeeded" in captured.out

    def test_build_help_mentions_json_arg_file_form(self, capsys):
        with pytest.raises(SystemExit):
            main(["build", "--help"])

        captured = capsys.readouterr()
        assert "--arg @vars.json" in captured.out

    def test_build_checks_resolved_build_task_placeholders(self, setup_config_env, write_config, sample_config, capsys):
        config = dict(sample_config)
        config["tasks"] = dict(sample_config["tasks"])
        config["tasks"]["build"] = {"command": "bash build.sh --target {target}"}
        write_config("test_repo", config)

        with pytest.raises(SystemExit):
            main(["build", "test_repo"])

        captured = capsys.readouterr()
        assert "Missing placeholder(s) for current task: {target}" in captured.err
        assert "Use --arg KEY=VALUE or --arg @file.json to provide them." in captured.err


class TestTest:
    def test_run_accuracy_test(self, setup_config_env, mock_repo, capsys):
        test_script = mock_repo / "tests" / "run_test.py"
        test_script.write_text("#!/usr/bin/env python3\nprint('accuracy: 0.99')\nprint('accuracy PASS')\n")
        main(["test", "test_repo", "--type", "accuracy"])
        captured = capsys.readouterr()
        assert "passed" in captured.out

    def test_test_checks_only_selected_task_placeholders(self, setup_config_env, write_config, sample_config, capsys):
        config = dict(sample_config)
        config["tasks"] = dict(sample_config["tasks"])
        config["tasks"]["performance"] = {
            "command": "bash run_perf.sh --device {device}",
            "working_dir": "tests/",
            "timeout": 60,
            "success_pattern": "PASS",
        }
        write_config("test_repo", config)

        with pytest.raises(SystemExit):
            main(["test", "test_repo", "--type", "performance"])

        captured = capsys.readouterr()
        assert "Missing placeholder(s) for current task: {device}" in captured.err

    def test_test_does_not_check_other_task_placeholders(self, setup_config_env, write_config, sample_config, mock_repo, capsys):
        test_script = mock_repo / "tests" / "run_test.py"
        test_script.write_text("#!/usr/bin/env python3\nprint('accuracy: 0.99')\nprint('accuracy PASS')\n")
        config = dict(sample_config)
        config["tests"] = {
            "accuracy": {
                "command": "python3 tests/run_test.py",
                "success_pattern": "PASS",
                "result": {"type": "stdout", "pattern": "accuracy: ([0-9.]+)"},
            },
            "performance": {"command": "python3 bench.py --device {device}", "success_pattern": "PASS"},
        }
        write_config("test_repo", config)

        main(["test", "test_repo", "--type", "accuracy"])

        captured = capsys.readouterr()
        assert "passed" in captured.out
        assert "{device}" not in captured.err


class TestRun:
    def test_run_build_then_test(self, setup_config_env, mock_repo, capsys):
        """run command executes build then test."""
        test_script = mock_repo / "tests" / "run_test.py"
        test_script.write_text("#!/usr/bin/env python3\nprint('accuracy: 0.99')\nprint('accuracy PASS')\n")
        main(["run", "test_repo", "--type", "accuracy"])
        captured = capsys.readouterr()
        assert "Build succeeded" in captured.out
        assert "passed" in captured.out

    def test_run_stops_when_build_task_placeholder_missing(self, setup_config_env, write_config, sample_config, capsys):
        config = dict(sample_config)
        config["tasks"] = dict(sample_config["tasks"])
        config["tasks"]["build"] = {"command": "bash build.sh --target {target}"}
        write_config("test_repo", config)

        with pytest.raises(SystemExit):
            main(["run", "test_repo", "--type", "accuracy"])

        captured = capsys.readouterr()
        assert "Missing placeholder(s) for current task: {target}" in captured.err

    def test_run_stops_when_selected_test_task_placeholder_missing(self, setup_config_env, write_config, sample_config, capsys):
        config = dict(sample_config)
        config["tasks"] = dict(sample_config["tasks"])
        config["tasks"]["accuracy"] = {
            "command": "python3 run_test.py --device {device}",
            "working_dir": "tests/",
            "timeout": 60,
            "success_pattern": "PASS",
        }
        write_config("test_repo", config)

        with pytest.raises(SystemExit):
            main(["run", "test_repo", "--type", "accuracy"])

        captured = capsys.readouterr()
        assert "Missing placeholder(s) for current task: {device}" in captured.err

    def test_run_build_fails_stops(self, setup_config_env, mock_repo):
        """run command stops if build fails."""
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\nexit 1\n")
        with pytest.raises(SystemExit):
            main(["run", "test_repo", "--type", "accuracy"])


class TestRepeatAggChoices:
    def test_repeat_agg_choices_constant_includes_outlier_option(self):
        assert REPEAT_AG_CHOICES == ["avg", "avg_without_outliers", "max"]

    @pytest.mark.parametrize(
        "argv",
        [
            ["test", "repo", "--type", "accuracy", "--repeat-agg", "avg_without_outliers"],
            ["bisect", "repo", "-g", "good", "-b", "bad", "--repeat-agg", "avg_without_outliers"],
            ["run", "repo", "--type", "accuracy", "--repeat-agg", "avg_without_outliers"],
        ],
    )
    def test_repeat_agg_parser_accepts_avg_without_outliers(self, argv):
        args = build_parser().parse_args(argv)
        assert args.repeat_agg == "avg_without_outliers"


class TestParseArgsList:
    def test_parse_args_list_loads_json_file(self, tmp_path):
        arg_file = tmp_path / "args.json"
        arg_file.write_text('{"op_name": "MatMul", "target": "ascend910"}', encoding="utf-8")

        assert _parse_args_list([f"@{arg_file}"]) == {"op_name": "MatMul", "target": "ascend910"}

    def test_parse_args_list_keeps_later_key_value_override(self, tmp_path):
        common_file = tmp_path / "common.json"
        common_file.write_text('{"op_name": "MatMul", "target": "ascend910"}', encoding="utf-8")

        assert _parse_args_list([f"@{common_file}", "target=ascend310"]) == {
            "op_name": "MatMul",
            "target": "ascend310",
        }

    def test_parse_args_list_keeps_later_json_file_override(self, tmp_path):
        common_file = tmp_path / "common.json"
        override_file = tmp_path / "override.json"
        common_file.write_text('{"op_name": "MatMul", "target": "ascend910"}', encoding="utf-8")
        override_file.write_text('{"target": "ascend310", "batch_size": "1"}', encoding="utf-8")

        assert _parse_args_list([f"@{common_file}", f"@{override_file}"]) == {
            "op_name": "MatMul",
            "target": "ascend310",
            "batch_size": "1",
        }

    def test_parse_args_list_reports_missing_json_file(self, tmp_path, capsys):
        missing_file = tmp_path / "missing.json"

        with pytest.raises(SystemExit):
            _parse_args_list([f"@{missing_file}"])

        captured = capsys.readouterr()
        assert "failed to read --arg JSON file" in captured.err

    @pytest.mark.parametrize(
        "content, expected_message",
        [
            ("{", "is not valid JSON"),
            ('["MatMul"]', "must contain a flat JSON object"),
            ('{"op_name": "MatMul", "target": 310}', "must contain only string values"),
        ],
    )
    def test_parse_args_list_reports_invalid_json_file(self, tmp_path, capsys, content, expected_message):
        arg_file = tmp_path / "args.json"
        arg_file.write_text(content, encoding="utf-8")

        with pytest.raises(SystemExit):
            _parse_args_list([f"@{arg_file}"])

        captured = capsys.readouterr()
        assert expected_message in captured.err

    def test_parse_args_list_reports_updated_invalid_item_message(self, capsys):
        with pytest.raises(SystemExit):
            _parse_args_list(["not-valid"])

        captured = capsys.readouterr()
        assert "must be KEY=VALUE or @file.json" in captured.err


class TestBuildTaskArgs:
    def test_build_task_args_loads_arg_json_file(self, tmp_path):
        arg_file = tmp_path / "args.json"
        arg_file.write_text('{"op_name": "MatMul", "target": "ascend910"}', encoding="utf-8")

        args = build_parser().parse_args(["build", "repo", "--arg", f"@{arg_file}"])

        assert _build_task_args(args) == {
            "repo": "repo",
            "extra_args": {
                "op_name": "MatMul",
                "target": "ascend910",
            },
        }

    def test_build_task_args_keeps_reserved_json_keys_as_placeholder_args(self, tmp_path):
        arg_file = tmp_path / "args.json"
        arg_file.write_text('{"repo": "shadow", "commit": "abc123"}', encoding="utf-8")

        args = build_parser().parse_args(["build", "real_repo", "--arg", f"@{arg_file}"])

        assert _build_task_args(args) == {
            "repo": "real_repo",
            "extra_args": {
                "repo": "shadow",
                "commit": "abc123",
            },
        }

    def test_build_task_args_keeps_shortcuts_in_extra_args_when_not_overridden(self):
        args = build_parser().parse_args(["build", "repo", "--cs", "nightly", "--ip", "/opt/Ascend"])

        assert _build_task_args(args) == {
            "repo": "repo",
            "extra_args": {
                "case": "nightly",
                "install_path": "/opt/Ascend",
            },
        }

    def test_build_task_args_includes_supported_daemon_flags(self):
        args = build_parser().parse_args(["build", "repo", "--commit", "abc123", "--step", "install"])

        assert _build_task_args(args) == {
            "repo": "repo",
            "commit": "abc123",
            "step": "install",
        }


class TestDaemonMode:
    def test_run_under_daemon_rejects_unsupported_command(self, capsys):
        args = build_parser().parse_args(["--daemon", "run", "repo", "--type", "accuracy"])

        with pytest.raises(SystemExit):
            main(["--daemon", "run", "repo", "--type", "accuracy"])

        captured = capsys.readouterr()
        assert "--daemon currently supports only bisect, build, test." in captured.err


class TestCmdTask:
    @patch("forge.cli.TaskRunner")
    @patch("forge.cli.resolve_source_env", return_value=None)
    @patch("forge.cli._build_variables", return_value={"working_dir": "/tmp/test_repo", "timestamp": "20260418_000000"})
    @patch("forge.cli._get_configs")
    def test_task_run_passes_repeat_overrides(self, mock_get_configs, mock_build_variables, mock_resolve_source_env, mock_task_runner, sample_config):
        mock_get_configs.return_value = {"repo": sample_config}
        mock_task_runner.return_value.run.return_value = TaskResult(success=True, stdout="", stderr="")

        main(["task-run", "repo", "build", "--repeat", "4", "--repeat-agg", "max"])

        task_cfg = mock_task_runner.return_value.run.call_args.args[0]
        assert task_cfg["repeat"] == 4
        assert task_cfg["repeat_agg"] == "max"
        assert "repeat" not in sample_config["tasks"]["build"]
        assert "repeat_agg" not in sample_config["tasks"]["build"]
        source_env_task_cfg = mock_resolve_source_env.call_args.args[1]
        assert source_env_task_cfg is task_cfg

    @patch("forge.cli.TaskRunner")
    @patch("forge.cli.resolve_source_env", return_value=None)
    @patch("forge.cli._build_variables", return_value={"working_dir": "/tmp/test_repo", "timestamp": "20260418_000000"})
    @patch("forge.cli._get_configs")
    def test_task_run_passes_repeat_without_outlier_agg(self, mock_get_configs, mock_build_variables, mock_resolve_source_env, mock_task_runner, sample_config):
        mock_get_configs.return_value = {"repo": sample_config}
        mock_task_runner.return_value.run.return_value = TaskResult(success=True, stdout="", stderr="")

        main(["task-run", "repo", "build", "--repeat", "4", "--repeat-agg", "avg_without_outliers"])

        task_cfg = mock_task_runner.return_value.run.call_args.args[0]
        assert task_cfg["repeat_agg"] == "avg_without_outliers"


def test_build_variables_includes_config_dir(tmp_path):
    from forge.cli import _build_variables

    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = {
        "working_dir": str(repo),
        "_config_dir": "/tmp/configs",
        "vars": {"manifest_path": "{config_dir}/manifest.jsonl"},
    }

    variables = _build_variables(cfg, {}, None)

    assert variables["config_dir"] == "/tmp/configs"
    assert variables["manifest_path"] == "/tmp/configs/manifest.jsonl"

    def test_task_run_runs_legacy_build(self, setup_config_env, capsys):
        """forge task-run repo build runs the build task from legacy config."""
        main(["task-run", "test_repo", "build"])
        captured = capsys.readouterr()
        assert "succeeded" in captured.out.lower()

    def test_task_run_runs_custom_task(self, setup_config_env, mock_repo, tmp_path, write_config, monkeypatch, capsys):
        """forge task-run repo deploy runs a custom task."""
        (mock_repo / "deploy.sh").write_text("#!/bin/bash\necho 'Deploy succeeded'\n")
        (mock_repo / "deploy.sh").chmod(0o755)
        import json
        config = {
            "name": "test_repo",
            "working_dir": str(mock_repo),
            "build": {"command": "bash build.sh"},
            "tasks": {
                "deploy": {"command": "bash deploy.sh", "timeout": 30}
            }
        }
        write_config("test_repo", config)
        main(["task-run", "test_repo", "deploy"])
        captured = capsys.readouterr()
        assert "succeeded" in captured.out.lower()

    def test_task_not_found(self, setup_config_env):
        with pytest.raises(SystemExit):
            main(["task", "test_repo", "nonexistent"])


class TestCmdWorkflow:
    def test_workflow_success(self, setup_config_env, mock_repo, write_config, capsys):
        """Workflow runs tasks in order."""
        (mock_repo / "deploy.sh").write_text("#!/bin/bash\necho 'Deploy done'\n")
        (mock_repo / "deploy.sh").chmod(0o755)
        import json
        config = {
            "name": "test_repo",
            "working_dir": str(mock_repo),
            "tasks": {
                "build": {"command": "bash build.sh", "timeout": 30},
                "deploy": {"command": "bash deploy.sh", "timeout": 30},
            },
            "workflows": {
                "full": ["build", "deploy"]
            }
        }
        write_config("test_repo", config)
        main(["workflow", "test_repo", "full"])
        captured = capsys.readouterr()
        assert "succeeded" in captured.out.lower()
        assert "build" in captured.out.lower()
        assert "deploy" in captured.out.lower()

    def test_workflow_stops_on_failure(self, setup_config_env, mock_repo, write_config):
        """Workflow stops when a task fails."""
        (mock_repo / "build.sh").write_text("#!/bin/bash\nexit 1\n")
        (mock_repo / "deploy.sh").write_text("#!/bin/bash\necho 'should not run'\n")
        (mock_repo / "deploy.sh").chmod(0o755)
        import json
        config = {
            "name": "test_repo",
            "working_dir": str(mock_repo),
            "tasks": {
                "build": {"command": "bash build.sh", "timeout": 30},
                "deploy": {"command": "bash deploy.sh", "timeout": 30},
            },
            "workflows": {
                "full": ["build", "deploy"]
            }
        }
        write_config("test_repo", config)
        with pytest.raises(SystemExit):
            main(["workflow", "test_repo", "full"])

    def test_workflow_not_found(self, setup_config_env):
        with pytest.raises(SystemExit):
            main(["workflow", "test_repo", "nonexistent"])


class TestDebugFlag:
    def test_debug_flag_enables_logging(self, setup_config_env, capsys):
        """--debug flag enables DEBUG level logging."""
        # Capture logging output
        logger = logging.getLogger("forge")
        old_level = logger.level
        old_handlers = logger.handlers.copy()

        try:
            main(["--debug", "list"])
            # After --debug, logger level should be DEBUG
            assert logger.level == logging.DEBUG
        finally:
            logger.level = old_level
            logger.handlers = old_handlers


class TestLoggingSetup:
    def test_setup_logging_does_not_stack_handlers(self):
        logger = logging.getLogger("forge")
        old_level = logger.level
        old_handlers = logger.handlers.copy()
        try:
            logger.handlers = []

            _setup_logging(False)
            _setup_logging(True)

            assert len(logger.handlers) == 1
            assert logger.level == logging.DEBUG
        finally:
            logger.handlers = old_handlers
            logger.level = old_level

    def test_setup_logging_uses_current_stderr_at_emit_time(self, monkeypatch):
        logger = logging.getLogger("forge")
        old_level = logger.level
        old_handlers = logger.handlers.copy()
        first_stream = io.StringIO()
        second_stream = io.StringIO()
        try:
            logger.handlers = []
            monkeypatch.setattr("forge.cli.sys.stderr", first_stream)
            _setup_logging(False)
            logger.info("first message")

            monkeypatch.setattr("forge.cli.sys.stderr", second_stream)
            _setup_logging(True)
            logger.info("second message")

            assert len(logger.handlers) == 1
            assert logger.level == logging.DEBUG
            assert "INFO: first message" in first_stream.getvalue()
            assert "INFO: second message" not in first_stream.getvalue()
            assert "INFO: second message" in second_stream.getvalue()
        finally:
            logger.handlers = old_handlers
            logger.level = old_level


class TestCmdBisectWorkflow:
    def test_bisect_with_workflow_flag(self, tmp_path, write_config, monkeypatch):
        """forge bisect --workflow uses named workflow, test_type from config."""
        import subprocess

        repo = tmp_path / "bisect_repo"
        repo.mkdir()
        subprocess.run(["git", "init"], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "config", "user.email", "t@t.com"], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "config", "user.name", "T"], cwd=str(repo), capture_output=True)

        (repo / "build.sh").write_text("#!/bin/bash\necho 'Build succeeded'\n")
        (repo / "build.sh").chmod(0o755)
        tests_dir = repo / "tests"
        tests_dir.mkdir()

        commits = []
        for i in range(6):
            (repo / "version.txt").write_text(str(i))
            subprocess.run(["git", "add", "."], cwd=str(repo), capture_output=True)
            subprocess.run(["git", "commit", "-m", f"commit {i}"], cwd=str(repo), capture_output=True)
            h = subprocess.run(["git", "rev-parse", "HEAD"], cwd=str(repo), capture_output=True, text=True).stdout.strip()
            commits.append(h)

        (repo / "tests" / "run_test.py").write_text(
            "#!/usr/bin/env python3\nimport sys\n"
            "v = int(open('version.txt').read().strip())\n"
            "if v >= 3:\n    print('FAIL'); sys.exit(1)\n"
            "else:\n    print('accuracy: 0.99'); print('PASS')\n"
        )
        subprocess.run(["git", "add", "."], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "commit", "-m", "add test"], cwd=str(repo), capture_output=True)
        last = subprocess.run(["git", "rev-parse", "HEAD"], cwd=str(repo), capture_output=True, text=True).stdout.strip()
        commits.append(last)

        config = {
            "name": "test_repo",
            "working_dir": str(repo),
            "tasks": {
                "build": {"command": "bash build.sh", "working_dir": ".", "timeout": 30},
                "test_accuracy": {
                    "command": "python3 tests/run_test.py",
                    "working_dir": ".",
                    "timeout": 30,
                    "success_pattern": "PASS",
                    "result": {"type": "stdout", "pattern": "accuracy: ([0-9.]+)"},
                },
            },
            "workflows": {
                "pipeline": {"tasks": ["build", "test_accuracy"]},
            },
            "bisect": {"workflow": "pipeline", "test_type": "accuracy"},
        }
        write_config("test_repo", config)
        monkeypatch.setenv("FORGE_CONFIG_DIR", str(tmp_path / "configs"))

        main(["bisect", "test_repo", "-g", commits[0], "-b", commits[-1],
              "--workflow", "pipeline"])

    def test_bisect_type_deprecation_warning(self, tmp_path, write_config, monkeypatch, capsys):
        """forge bisect --type emits deprecation warning."""
        import subprocess

        repo = tmp_path / "bisect_repo"
        repo.mkdir()
        subprocess.run(["git", "init"], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "config", "user.email", "t@t.com"], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "config", "user.name", "T"], cwd=str(repo), capture_output=True)

        (repo / "build.sh").write_text("#!/bin/bash\necho 'Build succeeded'\n")
        (repo / "build.sh").chmod(0o755)
        tests_dir = repo / "tests"
        tests_dir.mkdir()

        commits = []
        for i in range(3):
            (repo / "version.txt").write_text(str(i))
            subprocess.run(["git", "add", "."], cwd=str(repo), capture_output=True)
            subprocess.run(["git", "commit", "-m", f"commit {i}"], cwd=str(repo), capture_output=True)
            h = subprocess.run(["git", "rev-parse", "HEAD"], cwd=str(repo), capture_output=True, text=True).stdout.strip()
            commits.append(h)

        (repo / "tests" / "run_test.py").write_text(
            "#!/usr/bin/env python3\nimport sys\n"
            "v = int(open('version.txt').read().strip())\n"
            "if v >= 2:\n    print('FAIL'); sys.exit(1)\n"
            "else:\n    print('accuracy: 0.99'); print('PASS')\n"
        )
        subprocess.run(["git", "add", "."], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "commit", "-m", "add test"], cwd=str(repo), capture_output=True)
        last = subprocess.run(["git", "rev-parse", "HEAD"], cwd=str(repo), capture_output=True, text=True).stdout.strip()
        commits.append(last)

        config = {
            "name": "test_repo",
            "working_dir": str(repo),
            "tasks": {
                "build": {"command": "bash build.sh", "working_dir": ".", "timeout": 30},
                "test_accuracy": {
                    "command": "python3 tests/run_test.py",
                    "working_dir": ".",
                    "timeout": 30,
                    "success_pattern": "PASS",
                },
            },
            "workflows": {
                "pipeline": {"tasks": ["build", "test_accuracy"]},
            },
            "bisect": {"workflow": "pipeline", "test_type": "accuracy"},
        }
        write_config("test_repo", config)
        monkeypatch.setenv("FORGE_CONFIG_DIR", str(tmp_path / "configs"))

        # Passing deprecated --type should emit warning
        main(["bisect", "test_repo", "-g", commits[0], "-b", commits[-1],
              "-t", "accuracy", "--workflow", "pipeline"])
        captured = capsys.readouterr()
        assert "deprecated" in captured.err.lower()

    def test_bisect_reads_test_type_from_config(self, tmp_path, write_config, monkeypatch, capsys):
        """forge bisect reads test_type from bisect.test_type config."""
        import subprocess

        repo = tmp_path / "bisect_repo"
        repo.mkdir()
        subprocess.run(["git", "init"], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "config", "user.email", "t@t.com"], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "config", "user.name", "T"], cwd=str(repo), capture_output=True)

        (repo / "build.sh").write_text("#!/bin/bash\necho 'Build succeeded'\n")
        (repo / "build.sh").chmod(0o755)
        tests_dir = repo / "tests"
        tests_dir.mkdir()

        commits = []
        for i in range(3):
            (repo / "version.txt").write_text(str(i))
            subprocess.run(["git", "add", "."], cwd=str(repo), capture_output=True)
            subprocess.run(["git", "commit", "-m", f"commit {i}"], cwd=str(repo), capture_output=True)
            h = subprocess.run(["git", "rev-parse", "HEAD"], cwd=str(repo), capture_output=True, text=True).stdout.strip()
            commits.append(h)

        (repo / "tests" / "run_test.py").write_text(
            "#!/usr/bin/env python3\nimport sys\n"
            "v = int(open('version.txt').read().strip())\n"
            "if v >= 2:\n    print('FAIL'); sys.exit(1)\n"
            "else:\n    print('accuracy: 0.99'); print('PASS')\n"
        )
        subprocess.run(["git", "add", "."], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "commit", "-m", "add test"], cwd=str(repo), capture_output=True)
        last = subprocess.run(["git", "rev-parse", "HEAD"], cwd=str(repo), capture_output=True, text=True).stdout.strip()
        commits.append(last)

        config = {
            "name": "test_repo",
            "working_dir": str(repo),
            "tasks": {
                "build": {"command": "bash build.sh", "working_dir": ".", "timeout": 30},
                "test_accuracy": {
                    "command": "python3 tests/run_test.py",
                    "working_dir": ".",
                    "timeout": 30,
                    "success_pattern": "PASS",
                },
            },
            "workflows": {
                "pipeline": {"tasks": ["build", "test_accuracy"]},
            },
            "bisect": {"workflow": "pipeline", "test_type": "accuracy"},
        }
        write_config("test_repo", config)
        monkeypatch.setenv("FORGE_CONFIG_DIR", str(tmp_path / "configs"))

        # Without --type, should use config's test_type
        main(["bisect", "test_repo", "-g", commits[0], "-b", commits[-1]])
        captured = capsys.readouterr()
        # Should show "(accuracy)" in output since test_type is from config
        assert "(accuracy)" in captured.out


class TestCmdWorkflowUpdated:
    def test_workflow_new_format_success(self, tmp_path, mock_repo, write_config, monkeypatch, capsys):
        """Workflow with new object format works."""
        (mock_repo / "deploy.sh").write_text("#!/bin/bash\necho 'Deploy done'\n")
        (mock_repo / "deploy.sh").chmod(0o755)
        config = {
            "name": "test_repo",
            "working_dir": str(mock_repo),
            "tasks": {
                "build": {"command": "bash build.sh", "timeout": 30},
                "deploy": {"command": "bash deploy.sh", "timeout": 30},
            },
            "workflows": {
                "full": {"tasks": ["build", "deploy"]}
            },
        }
        write_config("test_repo", config)
        monkeypatch.setenv("FORGE_CONFIG_DIR", str(tmp_path / "configs"))
        main(["workflow", "test_repo", "full"])
        captured = capsys.readouterr()
        assert "succeeded" in captured.out.lower()

    def test_workflow_legacy_format_with_warning(self, tmp_path, mock_repo, write_config, monkeypatch, capsys):
        """Legacy list-format workflow still works with deprecation warning."""
        (mock_repo / "deploy.sh").write_text("#!/bin/bash\necho 'Deploy done'\n")
        (mock_repo / "deploy.sh").chmod(0o755)
        config = {
            "name": "test_repo",
            "working_dir": str(mock_repo),
            "tasks": {
                "build": {"command": "bash build.sh", "timeout": 30},
                "deploy": {"command": "bash deploy.sh", "timeout": 30},
            },
            "workflows": {
                "full": ["build", "deploy"]
            },
        }
        write_config("test_repo", config)
        monkeypatch.setenv("FORGE_CONFIG_DIR", str(tmp_path / "configs"))
        main(["workflow", "test_repo", "full"])
        captured = capsys.readouterr()
        assert "succeeded" in captured.out.lower()


class TestCliTasksFormat:
    def test_cmd_test_with_tasks_field(self, tmp_path, mock_repo, write_config, monkeypatch, capsys):
        """forge test looks for tasks.accuracy."""
        (mock_repo / "tests" / "run_test.py").write_text(
            "#!/usr/bin/env python3\nprint('accuracy: 0.99')\nprint('accuracy PASS')\n"
        )
        config = {
            "name": "test_repo",
            "working_dir": str(mock_repo),
            "tasks": {
                "build": {"command": "bash build.sh", "timeout": 30},
                "accuracy": {
                    "command": "python3 tests/run_test.py",
                    "timeout": 30,
                    "success_pattern": "PASS",
                    "result": {"type": "stdout", "pattern": "accuracy: ([0-9.]+)"},
                },
            },
        }
        write_config("test_repo", config)
        monkeypatch.setenv("FORGE_CONFIG_DIR", str(tmp_path / "configs"))
        main(["test", "test_repo", "-t", "accuracy"])
        captured = capsys.readouterr()
        assert "passed" in captured.out.lower()

    def test_cmd_build_with_tasks_field(self, tmp_path, mock_repo, write_config, monkeypatch, capsys):
        """forge build looks for tasks.build."""
        config = {
            "name": "test_repo",
            "working_dir": str(mock_repo),
            "tasks": {
                "build": {"command": "bash build.sh", "timeout": 30},
            },
        }
        write_config("test_repo", config)
        monkeypatch.setenv("FORGE_CONFIG_DIR", str(tmp_path / "configs"))
        main(["build", "test_repo"])
        captured = capsys.readouterr()
        assert "succeeded" in captured.out.lower()

    def test_cmd_test_unknown_type_shows_migrate_hint(self, tmp_path, mock_repo, write_config, monkeypatch, capsys):
        """forge test with unknown type shows migrate hint."""
        config = {
            "name": "test_repo",
            "working_dir": str(mock_repo),
            "tasks": {
                "build": {"command": "bash build.sh", "timeout": 30},
                "accuracy": {"command": "python3 tests/run_test.py", "timeout": 30},
            },
        }
        write_config("test_repo", config)
        monkeypatch.setenv("FORGE_CONFIG_DIR", str(tmp_path / "configs"))
        with pytest.raises(SystemExit):
            main(["test", "test_repo", "-t", "unknown"])
        captured = capsys.readouterr()
        assert "forge migrate" in captured.err or "migrate" in captured.err.lower()

    def test_cmd_build_no_build_task_shows_migrate_hint(self, tmp_path, mock_repo, write_config, monkeypatch, capsys):
        """forge build with no build task shows migrate hint."""
        config = {
            "name": "test_repo",
            "working_dir": str(mock_repo),
            "tasks": {
                "accuracy": {"command": "python3 tests/run_test.py", "timeout": 30},
            },
        }
        write_config("test_repo", config)
        monkeypatch.setenv("FORGE_CONFIG_DIR", str(tmp_path / "configs"))
        with pytest.raises(SystemExit):
            main(["build", "test_repo"])
        captured = capsys.readouterr()
        assert "forge migrate" in captured.err or "migrate" in captured.err.lower()


class TestLoopCli:
    def test_parse_loop_list_builds_spec(self):
        from forge.cli import _parse_loop_list

        assert _parse_loop_list(["op_name=A", "op_name=B"]) == {
            "var": "op_name",
            "values": ["A", "B"],
            "fail_fast": True,
        }

    def test_parse_loop_list_rejects_mixed_keys(self, capsys):
        from forge.cli import _parse_loop_list

        with pytest.raises(SystemExit):
            _parse_loop_list(["op_name=A", "case=B"])
        assert "all --loop entries must use the same key" in capsys.readouterr().err

    def test_task_run_accepts_loop_argument(self, monkeypatch, tmp_path):
        from forge.cli import main

        cfg = {
            "name": "demo",
            "working_dir": str(tmp_path),
            "tasks": {
                "bench": {
                    "command": "echo",
                    "args": ["{op_name}"],
                    "result": {"type": "stdout", "pattern": r"([0-9.]+)"},
                }
            },
        }
        config_dir = tmp_path / "configs"
        config_dir.mkdir()
        (config_dir / "demo.json").write_text(__import__("json").dumps(cfg))

        captured = {}

        class FakeRunner:
            def run(self, task_cfg, working_dir, repo_name, task_name, variables, **kwargs):
                captured["loop"] = kwargs.get("loop")
                from forge.task import TaskResult
                return TaskResult(success=True, stdout="", stderr="")

        monkeypatch.setattr("forge.cli.TaskRunner", FakeRunner)
        main([
            "--config-dir", str(config_dir),
            "task-run", "demo", "bench",
            "--loop", "op_name=A",
            "--loop", "op_name=B",
        ])

        assert captured["loop"] == {"var": "op_name", "values": ["A", "B"], "fail_fast": True}

