"""End-to-end tests with a virtual operator repository."""

import json
import os
import subprocess
import pytest
from pathlib import Path

from forge.cli import main


BAD_FROM = 5  # commit 5 introduces the problem


@pytest.fixture
def e2e_env(tmp_path, monkeypatch):
    """Create a complete virtual operator repo with git history and config."""
    repo = tmp_path / "mock_op_repo"
    repo.mkdir()

    # Init git repo
    subprocess.run(["git", "init"], cwd=str(repo), capture_output=True, check=True)
    subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=str(repo), capture_output=True)
    subprocess.run(["git", "config", "user.name", "Test"], cwd=str(repo), capture_output=True)

    # Create build.sh
    (repo / "build.sh").write_text("#!/bin/bash\necho 'Build succeeded'\n")
    (repo / "build.sh").chmod(0o755)

    # Create test directory and scripts
    tests_dir = repo / "tests"
    tests_dir.mkdir()
    output_dir = tests_dir / "output"
    output_dir.mkdir()

    # Accuracy test script: FAIL when version >= BAD_FROM
    (tests_dir / "run_accuracy.py").write_text(
        "#!/usr/bin/env python3\n"
        "import sys, os\n"
        "version = int(open(os.path.join(os.path.dirname(__file__), '..', 'version.txt')).read().strip())\n"
        f"if version >= {BAD_FROM}:\n"
        "    print('accuracy: 0.50')\n"
        "    print('accuracy FAIL')\n"
        "    sys.exit(1)\n"
        "else:\n"
        "    print('accuracy: 0.99')\n"
        "    print('accuracy PASS')\n"
    )

    # Performance test script: slow when version >= BAD_FROM
    (tests_dir / "run_perf.sh").write_text(
        "#!/bin/bash\n"
        "SCRIPT_DIR=$(cd \"$(dirname \"$0\")\" && pwd)\n"
        "VERSION=$(cat \"$SCRIPT_DIR/../version.txt\")\n"
        f"if [ $VERSION -ge {BAD_FROM} ]; then\n"
        "  echo 'op,time_ms' > \"$SCRIPT_DIR/output/result.csv\"\n"
        "  echo 'matmul,50.0' >> \"$SCRIPT_DIR/output/result.csv\"\n"
        "else\n"
        "  echo 'op,time_ms' > \"$SCRIPT_DIR/output/result.csv\"\n"
        "  echo 'matmul,10.0' >> \"$SCRIPT_DIR/output/result.csv\"\n"
        "fi\n"
    )
    (tests_dir / "run_perf.sh").chmod(0o755)

    # Create commits
    commits = []
    for i in range(10):
        (repo / "version.txt").write_text(str(i))
        subprocess.run(["git", "add", "."], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "commit", "-m", f"commit {i}"], cwd=str(repo), capture_output=True)
        commit_hash = subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=str(repo), capture_output=True, text=True
        ).stdout.strip()
        commits.append(commit_hash)

    # Create config file
    config_dir = tmp_path / "configs"
    config_dir.mkdir()
    config = {
        "name": "mock_repo",
        "description": "Virtual test operator repo",
        "working_dir": str(repo),
        "build": {
            "command": "bash build.sh",
            "working_dir": ".",
            "timeout": 30,
            "success_pattern": "Build succeeded",
        },
        "tests": {
            "accuracy": {
                "command": "python3 tests/run_accuracy.py",
                "working_dir": ".",
                "timeout": 30,
                "success_pattern": "PASS",
                "result": {
                    "type": "stdout",
                    "pattern": "accuracy: ([0-9.]+)",
                },
            },
            "performance": {
                "command": "bash tests/run_perf.sh",
                "working_dir": ".",
                "timeout": 30,
                "result": {
                    "type": "file",
                    "path": "tests/output/result.csv",
                    "format": "csv",
                    "value_column": 1,
                    "op_column": 0,
                    "header": True,
                    "delimiter": ",",
                },
            },
        },
        "bisect": {
            "build_before_test": True,
        },
    }
    (config_dir / "mock_repo.json").write_text(json.dumps(config, indent=2))

    # Set env
    monkeypatch.setenv("FORGE_CONFIG_DIR", str(config_dir))
    # Use a temp HOME so logs don't pollute real HOME
    monkeypatch.setenv("HOME", str(tmp_path / "home"))

    return {
        "working_dir": str(repo),
        "config_dir": str(config_dir),
        "commits": commits,
        "home": str(tmp_path / "home"),
    }


class TestE2EList:
    def test_list_shows_mock_repo(self, e2e_env, capsys):
        main(["list"])
        captured = capsys.readouterr()
        assert "mock_repo" in captured.out
        assert "Virtual test operator repo" in captured.out


class TestE2EValidate:
    def test_validate_passes(self, e2e_env, capsys):
        main(["validate", "mock_repo"])
        captured = capsys.readouterr()
        assert "valid" in captured.out


class TestE2EBuild:
    def test_build_succeeds(self, e2e_env, capsys):
        main(["build", "mock_repo"])
        captured = capsys.readouterr()
        assert "succeeded" in captured.out

    def test_build_at_commit(self, e2e_env, capsys):
        main(["build", "mock_repo", "--commit", e2e_env["commits"][0]])
        captured = capsys.readouterr()
        assert "succeeded" in captured.out


class TestE2ETestAccuracy:
    def test_accuracy_pass_on_good_commit(self, e2e_env, capsys):
        # Checkout a good commit first
        subprocess.run(
            ["git", "checkout", e2e_env["commits"][0]],
            cwd=e2e_env["working_dir"], capture_output=True,
        )
        main(["test", "mock_repo", "--type", "accuracy"])
        captured = capsys.readouterr()
        assert "passed" in captured.out

    def test_accuracy_fail_on_bad_commit(self, e2e_env):
        subprocess.run(
            ["git", "checkout", e2e_env["commits"][-1]],
            cwd=e2e_env["working_dir"], capture_output=True,
        )
        with pytest.raises(SystemExit):
            main(["test", "mock_repo", "--type", "accuracy"])


class TestE2ETestPerformance:
    def test_performance_extracts_csv_result(self, e2e_env, capsys):
        subprocess.run(
            ["git", "checkout", e2e_env["commits"][0]],
            cwd=e2e_env["working_dir"], capture_output=True,
        )
        main(["test", "mock_repo", "--type", "performance"])
        captured = capsys.readouterr()
        assert "matmul" in captured.out
        assert "10.0" in captured.out


class TestE2EBisect:
    def test_bisect_accuracy_finds_bad_commit(self, e2e_env, capsys):
        commits = e2e_env["commits"]
        main([
            "bisect", "mock_repo",
            "--good", commits[0], "--bad", commits[-1],
            "--type", "accuracy",
        ])
        captured = capsys.readouterr()
        assert commits[BAD_FROM][:8] in captured.out

    def test_bisect_performance_finds_bad_commit(self, e2e_env, capsys):
        commits = e2e_env["commits"]
        main([
            "bisect", "mock_repo",
            "--good", commits[0], "--bad", commits[-1],
            "--type", "performance", "--op", "matmul",
            "--regression", "50",
        ])
        captured = capsys.readouterr()
        assert commits[BAD_FROM][:8] in captured.out


class TestE2ELogging:
    def test_build_creates_log_file(self, e2e_env, capsys):
        main(["build", "mock_repo"])
        log_dir = Path(e2e_env["home"]) / ".forge" / "logs" / "mock_repo"
        assert log_dir.exists()
        log_files = list(log_dir.glob("build_*.log"))
        assert len(log_files) >= 1

    def test_log_contains_command_and_output(self, e2e_env, capsys):
        main(["build", "mock_repo"])
        log_dir = Path(e2e_env["home"]) / ".forge" / "logs" / "mock_repo"
        log_files = sorted(log_dir.glob("build_*.log"))
        content = log_files[-1].read_text()
        assert "Command: bash build.sh" in content
        assert "Build succeeded" in content
        assert "Exit code: 0" in content
        assert "Success: True" in content

    def test_test_creates_log_file(self, e2e_env, capsys):
        subprocess.run(
            ["git", "checkout", e2e_env["commits"][0]],
            cwd=e2e_env["working_dir"], capture_output=True,
        )
        main(["test", "mock_repo", "--type", "accuracy"])
        log_dir = Path(e2e_env["home"]) / ".forge" / "logs" / "mock_repo"
        log_files = list(log_dir.glob("test_accuracy_*.log"))
        assert len(log_files) >= 1

    def test_test_log_contains_output(self, e2e_env, capsys):
        subprocess.run(
            ["git", "checkout", e2e_env["commits"][0]],
            cwd=e2e_env["working_dir"], capture_output=True,
        )
        main(["test", "mock_repo", "--type", "accuracy"])
        log_dir = Path(e2e_env["home"]) / ".forge" / "logs" / "mock_repo"
        log_files = sorted(log_dir.glob("test_accuracy_*.log"))
        content = log_files[-1].read_text()
        assert "accuracy: 0.99" in content
        assert "PASS" in content

    def test_verbose_shows_stdout(self, e2e_env, capsys):
        main(["--verbose", "build", "mock_repo"])
        captured = capsys.readouterr()
        assert "Build succeeded" in captured.out
