"""Tests for resolve_tasks config mapping."""

import pytest
from forge.config import resolve_tasks, ConfigError


class TestResolveTasks:
    def test_tasks_section_returned(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {
                "deploy": {"command": "bash deploy.sh"},
            }
        }
        tasks = resolve_tasks(config)
        assert "deploy" in tasks
        assert tasks["deploy"]["command"] == "bash deploy.sh"

    def test_build_mapped_to_tasks(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "build": {"command": "bash build.sh", "timeout": 600},
        }
        tasks = resolve_tasks(config)
        assert "build" in tasks
        assert tasks["build"]["command"] == "bash build.sh"

    def test_tests_mapped_to_tasks(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tests": {
                "accuracy": {"command": "python3 test.py", "timeout": 300},
                "performance": {"command": "bash perf.sh"},
            }
        }
        tasks = resolve_tasks(config)
        assert "accuracy" in tasks
        assert "performance" in tasks
        assert tasks["accuracy"]["command"] == "python3 test.py"

    def test_tests_source_env_skipped(self):
        """Non-dict entries like source_env at tests level are skipped."""
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tests": {
                "source_env": "/path/to/env.sh",
                "accuracy": {"command": "python3 test.py"},
            }
        }
        tasks = resolve_tasks(config)
        assert "source_env" not in tasks
        assert "accuracy" in tasks

    def test_explicit_tasks_override_legacy(self):
        """Explicit tasks entry wins over legacy mapping on collision."""
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "build": {"command": "old_build.sh"},
            "tasks": {"build": {"command": "new_build.sh"}},
        }
        tasks = resolve_tasks(config)
        assert tasks["build"]["command"] == "new_build.sh"

    def test_merge_legacy_and_tasks(self):
        """Legacy and tasks sections are merged."""
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "build": {"command": "bash build.sh"},
            "tasks": {"deploy": {"command": "bash deploy.sh"}},
        }
        tasks = resolve_tasks(config)
        assert "build" in tasks
        assert "deploy" in tasks

    def test_no_tasks_no_build_no_tests(self):
        config = {"name": "repo", "working_dir": "/tmp"}
        tasks = resolve_tasks(config)
        assert tasks == {}

    def test_validate_tasks_command_required(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {"bad": {"timeout": 30}},
        }
        with pytest.raises(ConfigError, match="command"):
            resolve_tasks(config, validate=True)

    def test_validate_tasks_steps_have_command(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {"multi": {"steps": [{"name": "s1"}]}},
        }
        with pytest.raises(ConfigError, match="command"):
            resolve_tasks(config, validate=True)


class TestResolveTasksNewFormat:
    """Tests for new tasks format with deprecation warnings and migrate hints."""

    def test_tasks_field_direct(self):
        """If tasks field exists, use it directly."""
        config = {
            "tasks": {
                "build": {"command": "make"},
                "accuracy": {"command": "pytest"},
            }
        }
        tasks = resolve_tasks(config)
        assert tasks == config["tasks"]

    def test_no_tasks_no_build_tests_raises_with_migrate_hint(self):
        """If no tasks/build/tests, ConfigError includes 'forge migrate' hint."""
        config = {"name": "test", "working_dir": "/path"}
        with pytest.raises(ConfigError, match="forge migrate"):
            resolve_tasks(config, validate=True)

    def test_legacy_build_tests_deprecated_with_migrate_hint(self):
        """build/tests fields emit deprecation warning with 'forge migrate' hint."""
        import warnings
        config = {
            "build": {"command": "make"},
            "tests": {"accuracy": {"command": "pytest"}},
        }
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            tasks = resolve_tasks(config)
            assert len(w) >= 1
            assert "forge migrate" in str(w[0].message).lower()
        assert tasks["build"] == {"command": "make"}
        assert tasks["accuracy"] == {"command": "pytest"}


class TestRepeatValidation:
    """Tests for repeat and repeat_agg config validation."""

    def test_validate_task_repeat_positive_int(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {"bench": {"command": "python bench.py", "repeat": 3}},
        }
        assert resolve_tasks(config, validate=True)["bench"]["repeat"] == 3

    def test_validate_task_repeat_zero_rejected(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {"bench": {"command": "python bench.py", "repeat": 0}},
        }
        with pytest.raises(ConfigError, match="tasks.bench.repeat must be a positive integer"):
            resolve_tasks(config, validate=True)

    def test_validate_task_repeat_negative_rejected(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {"bench": {"command": "python bench.py", "repeat": -1}},
        }
        with pytest.raises(ConfigError, match="tasks.bench.repeat must be a positive integer"):
            resolve_tasks(config, validate=True)

    def test_validate_task_repeat_string_rejected(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {"bench": {"command": "python bench.py", "repeat": "3"}},
        }
        with pytest.raises(ConfigError, match="tasks.bench.repeat must be a positive integer"):
            resolve_tasks(config, validate=True)

    def test_validate_task_repeat_agg_avg_valid(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {"bench": {"command": "python bench.py", "repeat_agg": "avg"}},
        }
        assert resolve_tasks(config, validate=True)["bench"]["repeat_agg"] == "avg"

    def test_validate_task_repeat_agg_max_valid(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {"bench": {"command": "python bench.py", "repeat_agg": "max"}},
        }
        assert resolve_tasks(config, validate=True)["bench"]["repeat_agg"] == "max"

    def test_validate_task_repeat_agg_min_rejected(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {"bench": {"command": "python bench.py", "repeat_agg": "min"}},
        }
        with pytest.raises(ConfigError, match="tasks.bench.repeat_agg must be one of: avg, max, avg_without_outliers"):
            resolve_tasks(config, validate=True)

    def test_validate_task_repeat_agg_avg_without_outliers_valid(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {"bench": {"command": "python bench.py", "repeat_agg": "avg_without_outliers"}},
        }
        assert resolve_tasks(config, validate=True)["bench"]["repeat_agg"] == "avg_without_outliers"

    def test_validate_task_outlier_detection_valid(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {
                "bench": {
                    "command": "python bench.py",
                    "outlier_detection": {
                        "method": "iqr",
                        "max_outlier_ratio": 0.1,
                        "iqr_multiplier": 1.5,
                        "min_samples": 4,
                    },
                }
            },
        }
        assert resolve_tasks(config, validate=True)["bench"]["outlier_detection"]["method"] == "iqr"

    def test_validate_task_outlier_detection_non_object_rejected(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {
                "bench": {
                    "command": "python bench.py",
                    "outlier_detection": "iqr",
                }
            },
        }
        with pytest.raises(ConfigError, match="tasks.bench.outlier_detection must be an object"):
            resolve_tasks(config, validate=True)

    def test_validate_task_outlier_detection_unknown_key_rejected(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {
                "bench": {
                    "command": "python bench.py",
                    "outlier_detection": {"typo": 1},
                }
            },
        }
        with pytest.raises(ConfigError, match="tasks.bench.outlier_detection.typo is not allowed"):
            resolve_tasks(config, validate=True)

    def test_validate_task_outlier_detection_invalid_method_rejected(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {
                "bench": {
                    "command": "python bench.py",
                    "outlier_detection": {"method": "zscore"},
                }
            },
        }
        with pytest.raises(ConfigError, match="tasks.bench.outlier_detection.method must be: iqr"):
            resolve_tasks(config, validate=True)

    def test_validate_task_outlier_detection_invalid_max_outlier_ratio_rejected(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {
                "bench": {
                    "command": "python bench.py",
                    "outlier_detection": {"max_outlier_ratio": 1.5},
                }
            },
        }
        with pytest.raises(
            ConfigError,
            match="tasks.bench.outlier_detection.max_outlier_ratio must be between 0 and 1",
        ):
            resolve_tasks(config, validate=True)

    def test_validate_task_outlier_detection_bool_max_outlier_ratio_rejected(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {
                "bench": {
                    "command": "python bench.py",
                    "outlier_detection": {"max_outlier_ratio": True},
                }
            },
        }
        with pytest.raises(
            ConfigError,
            match="tasks.bench.outlier_detection.max_outlier_ratio must be between 0 and 1",
        ):
            resolve_tasks(config, validate=True)

    def test_validate_task_outlier_detection_invalid_iqr_multiplier_rejected(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {
                "bench": {
                    "command": "python bench.py",
                    "outlier_detection": {"iqr_multiplier": 0},
                }
            },
        }
        with pytest.raises(ConfigError, match="tasks.bench.outlier_detection.iqr_multiplier must be > 0"):
            resolve_tasks(config, validate=True)

    def test_validate_task_outlier_detection_bool_iqr_multiplier_rejected(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {
                "bench": {
                    "command": "python bench.py",
                    "outlier_detection": {"iqr_multiplier": False},
                }
            },
        }
        with pytest.raises(ConfigError, match="tasks.bench.outlier_detection.iqr_multiplier must be > 0"):
            resolve_tasks(config, validate=True)

    def test_validate_task_outlier_detection_invalid_min_samples_rejected(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {
                "bench": {
                    "command": "python bench.py",
                    "outlier_detection": {"min_samples": 0},
                }
            },
        }
        with pytest.raises(
            ConfigError,
            match="tasks.bench.outlier_detection.min_samples must be a positive integer",
        ):
            resolve_tasks(config, validate=True)

    def test_validate_task_outlier_detection_bool_min_samples_rejected(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {
                "bench": {
                    "command": "python bench.py",
                    "outlier_detection": {"min_samples": True},
                }
            },
        }
        with pytest.raises(
            ConfigError,
            match="tasks.bench.outlier_detection.min_samples must be a positive integer",
        ):
            resolve_tasks(config, validate=True)

    def test_validate_step_repeat_positive_int(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {
                "pipeline": {
                    "steps": [
                        {"name": "bench", "command": "python bench.py", "repeat": 2, "repeat_agg": "avg"}
                    ]
                }
            },
        }
        assert resolve_tasks(config, validate=True)["pipeline"]["steps"][0]["repeat"] == 2

    def test_validate_step_repeat_agg_avg_valid(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {
                "pipeline": {
                    "steps": [
                        {"name": "bench", "command": "python bench.py", "repeat_agg": "avg"}
                    ]
                }
            },
        }
        result = resolve_tasks(config, validate=True)
        assert result["pipeline"]["steps"][0]["repeat_agg"] == "avg"

    def test_validate_step_repeat_string_rejected(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {
                "pipeline": {
                    "steps": [
                        {"name": "bench", "command": "python bench.py", "repeat": "2"}
                    ]
                }
            },
        }
        with pytest.raises(ConfigError, match=r"tasks\.pipeline\.steps\[0\]\.repeat must be a positive integer"):
            resolve_tasks(config, validate=True)

    def test_validate_step_outlier_detection_valid(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {
                "pipeline": {
                    "steps": [
                        {
                            "name": "bench",
                            "command": "python bench.py",
                            "outlier_detection": {"min_samples": 5},
                        }
                    ]
                }
            },
        }
        assert resolve_tasks(config, validate=True)["pipeline"]["steps"][0]["outlier_detection"]["min_samples"] == 5

    def test_validate_step_outlier_detection_invalid_method_rejected(self):
        config = {
            "name": "repo",
            "working_dir": "/tmp",
            "tasks": {
                "pipeline": {
                    "steps": [
                        {
                            "name": "bench",
                            "command": "python bench.py",
                            "outlier_detection": {"method": "zscore"},
                        }
                    ]
                }
            },
        }
        with pytest.raises(
            ConfigError,
            match=r"tasks\.pipeline\.steps\[0\]\.outlier_detection\.method must be: iqr",
        ):
            resolve_tasks(config, validate=True)


class TestValidateConfigTasksFormat:
    """Tests for validate_config with new tasks format."""

    def test_validate_missing_tasks_with_legacy_succeeds(self):
        """validate_config accepts build/tests as valid task definitions."""
        config = {
            "name": "test",
            "working_dir": "/path",
            "build": {"command": "make"},
            "tests": {"accuracy": {"command": "pytest"}},
        }
        from forge.config import validate_config
        validate_config(config)  # Should not raise

    def test_validate_no_tasks_no_build_tests_raises_with_migrate_hint(self):
        """validate_config rejects config with no tasks and includes migrate hint."""
        from forge.config import ConfigError, validate_config
        config = {"name": "test", "working_dir": "/path"}
        with pytest.raises(ConfigError, match="forge migrate"):
            validate_config(config)
