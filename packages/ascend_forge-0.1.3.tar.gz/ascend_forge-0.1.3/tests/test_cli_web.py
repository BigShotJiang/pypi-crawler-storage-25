"""Integration test for `forge web` subcommand."""
from __future__ import annotations

import sys
from unittest.mock import patch

import pytest

from forge.cli import main


def test_web_subcommand_dispatches(capsys: pytest.CaptureFixture[str]) -> None:
    with patch("forge_web.backend.cli.uvicorn.run") as run:
        rc = main(["web", "--no-open", "--port", "9001"])
    assert rc == 0
    run.assert_called_once()
    assert run.call_args.kwargs["port"] == 9001


def test_web_subcommand_missing_extra(monkeypatch: pytest.MonkeyPatch,
                                       capsys: pytest.CaptureFixture[str]) -> None:
    # Simulate forge_web not installed by making the import fail
    monkeypatch.setitem(sys.modules, "forge_web.backend.cli", None)
    rc = main(["web"])
    captured = capsys.readouterr()
    assert rc != 0
    assert "pip install" in captured.err or "pip install" in captured.out
    assert "forge[web]" in captured.err or "forge[web]" in captured.out
