import subprocess
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parent.parent
SCRIPT = REPO_ROOT / "scripts" / "analyze_benchmark_csv.py"


def _write_csv(path: Path, rows: list[tuple[str, float]]) -> None:
    lines = ["OP Type,Task Duration(us)"]
    for op, dur in rows:
        lines.append(f"{op},{dur}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_prof_csv(tmp_path: Path, rows: list[tuple[str, float]]) -> Path:
    prof_dir = tmp_path / "PROF_000"
    out_dir = prof_dir / "mindstudio_profiler_output"
    out_dir.mkdir(parents=True)
    csv_path = out_dir / "op_summary_001.csv"
    _write_csv(csv_path, rows)
    return prof_dir


def _run(prof_dir: Path, **kwargs) -> subprocess.CompletedProcess:
    args = [sys.executable, str(SCRIPT), "--prof-dir", str(prof_dir)]
    for k, v in kwargs.items():
        args.extend([f"--{k.replace('_', '-')}", str(v)])
    return subprocess.run(args, capture_output=True, text=True)


def test_analyze_skips_warmup_and_outputs_mean_of_all_post_warmup(tmp_path):
    rows = [("MyOp", 120.0)] * 5 + [("MyOp", 80.0)] * 20
    prof_dir = _write_prof_csv(tmp_path, rows)

    result = _run(prof_dir, op_filter="MyOp", warmup=5)

    assert result.returncode == 0, result.stderr
    assert "SAMPLES_COUNT=20" in result.stdout
    assert "MEAN_TASK_DURATION_US=80.0" in result.stdout


def test_analyze_filters_unrelated_ops_before_warmup_skip(tmp_path):
    rows = (
        [("OtherOp", 999.0)] * 3
        + [("MyOp", 120.0)] * 5
        + [("AnotherOp", 888.0)] * 2
        + [("MyOp", 80.0)] * 20
    )
    prof_dir = _write_prof_csv(tmp_path, rows)

    result = _run(prof_dir, op_filter="MyOp", warmup=5)

    assert result.returncode == 0, result.stderr
    assert "SAMPLES_COUNT=20" in result.stdout
    assert "MEAN_TASK_DURATION_US=80.0" in result.stdout


def test_analyze_fails_when_samples_insufficient(tmp_path):
    rows = [("MyOp", 100.0)] * 6
    prof_dir = _write_prof_csv(tmp_path, rows)

    result = _run(prof_dir, op_filter="MyOp", warmup=5, min_samples=4)

    assert result.returncode == 1
    assert "insufficient samples" in result.stderr


def test_analyze_fails_on_high_outlier_ratio(tmp_path):
    rows = [("MyOp", 100.0)] * 5 + [("MyOp", 80.0)] * 18 + [("MyOp", 500.0), ("MyOp", 600.0)]
    prof_dir = _write_prof_csv(tmp_path, rows)

    result = _run(prof_dir, op_filter="MyOp", warmup=5, max_outlier_ratio=0.05)

    assert result.returncode == 1
    assert "outlier ratio" in result.stderr


def test_analyze_snake_case_op_filter_matches_pascal(tmp_path):
    rows = [("AiInfraSparseFlashAttentionGqa", 100.0)] * 5 + [("AiInfraSparseFlashAttentionGqa", 80.0)] * 20
    prof_dir = _write_prof_csv(tmp_path, rows)

    result = _run(prof_dir, op_filter="ai_infra_sparse_flash_attention_gqa", warmup=5)

    assert result.returncode == 0, result.stderr
    assert "SAMPLES_COUNT=20" in result.stdout
