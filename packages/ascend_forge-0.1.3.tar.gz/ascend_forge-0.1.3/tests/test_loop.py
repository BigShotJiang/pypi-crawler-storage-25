import pytest

from forge.loop import LoopSpec, normalize_loop_spec, run_loop, validate_loop_var_used
from forge.task import TaskResult
from forge.config import ConfigError


def test_normalize_loop_spec_rejects_empty_var():
    with pytest.raises(ValueError, match="loop.var must be a non-empty string"):
        normalize_loop_spec({"var": " ", "values": ["A"]})


def test_normalize_loop_spec_rejects_empty_values():
    with pytest.raises(ValueError, match="loop.values must contain at least one value"):
        normalize_loop_spec({"var": "op_name", "values": ["", "  "]})


def test_normalize_loop_spec_trims_values_and_defaults_fail_fast():
    spec = normalize_loop_spec({"var": " op_name ", "values": [" A ", "B"]})
    assert spec == LoopSpec(var="op_name", values=["A", "B"], fail_fast=True)


def test_run_loop_injects_each_value_and_prefixes_results():
    seen = []

    def run_once(vars_for_iteration):
        seen.append(dict(vars_for_iteration))
        return TaskResult(
            success=True,
            stdout="",
            stderr="",
            result_values={"value": float(len(seen))},
        )

    result = run_loop(
        LoopSpec(var="op_name", values=["A", "B"]),
        {"working_dir": "/tmp", "op_name": "fixed"},
        run_once,
    )

    assert result.success is True
    assert [item["op_name"] for item in seen] == ["A", "B"]
    assert result.result_values == {"A/value": 1.0, "B/value": 2.0}


def test_run_loop_isolates_iteration_variables():
    seen = []

    def run_once(vars_for_iteration):
        vars_for_iteration["captured"] = vars_for_iteration["op_name"]
        seen.append(dict(vars_for_iteration))
        return TaskResult(success=True, stdout="", stderr="")

    outer = {"working_dir": "/tmp"}
    result = run_loop(LoopSpec(var="op_name", values=["A", "B"]), outer, run_once)

    assert result.success is True
    assert seen[0]["captured"] == "A"
    assert seen[1]["captured"] == "B"
    assert "captured" not in outer
    assert "op_name" not in outer


def test_run_loop_fail_fast_stops_after_first_failure():
    values = []

    def run_once(vars_for_iteration):
        values.append(vars_for_iteration["op_name"])
        return TaskResult(
            success=vars_for_iteration["op_name"] != "B",
            stdout="",
            stderr="boom" if vars_for_iteration["op_name"] == "B" else "",
        )

    result = run_loop(LoopSpec(var="op_name", values=["A", "B", "C"]), {}, run_once)

    assert values == ["A", "B"]
    assert result.success is False
    assert result.failed_value == "B"
    assert result.iterations[-1].error == "boom"


def test_run_loop_continue_on_error_when_fail_fast_false():
    values = []

    def run_once(vars_for_iteration):
        values.append(vars_for_iteration["op_name"])
        return TaskResult(
            success=vars_for_iteration["op_name"] != "B",
            stdout="",
            stderr="boom" if vars_for_iteration["op_name"] == "B" else "",
            result_values={"value": 1.0},
        )

    result = run_loop(
        LoopSpec(var="op_name", values=["A", "B", "C"], fail_fast=False),
        {},
        run_once,
    )

    assert values == ["A", "B", "C"]
    assert result.success is False
    assert result.result_values == {"A/value": 1.0, "B/value": 1.0, "C/value": 1.0}


def test_validate_loop_var_used_accepts_placeholder_presence():
    validate_loop_var_used(LoopSpec(var="op_name", values=["A"]), [{"args": ["{op_name}"]}], "current task")


def test_validate_loop_var_used_rejects_unused_loop_var():
    with pytest.raises(ConfigError, match=r"loop variable \{op_name\} is not used in current task"):
        validate_loop_var_used(LoopSpec(var="op_name", values=["A"]), [{"args": ["{case}"]}], "current task")
