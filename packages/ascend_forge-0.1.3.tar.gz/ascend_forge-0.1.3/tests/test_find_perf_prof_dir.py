import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
SCRIPT = REPO_ROOT / "scripts" / "find_perf_prof_dir.py"


def test_finds_latest_prof_dir(tmp_path):
    # Create two ascend_pt dirs with different mtimes
    asc1 = tmp_path / "20250506_100000_ascend_pt"
    asc1.mkdir()
    prof1 = asc1 / "PROF_001"
    prof1.mkdir()

    asc2 = tmp_path / "20250506_110000_ascend_pt"
    asc2.mkdir()
    prof2 = asc2 / "PROF_002"
    prof2.mkdir()

    args = [sys.executable, str(SCRIPT), str(tmp_path)]
    result = subprocess.run(args, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    assert f"PROF_DIR={prof2}" in result.stdout


def test_missing_ascend_pt(tmp_path):
    args = [sys.executable, str(SCRIPT), str(tmp_path)]
    result = subprocess.run(args, capture_output=True, text=True)
    assert result.returncode == 1
    assert "ascend_pt" in result.stderr.lower() or "not found" in result.stderr.lower()


def test_missing_prof_dir(tmp_path):
    asc = tmp_path / "20250506_100000_ascend_pt"
    asc.mkdir()
    args = [sys.executable, str(SCRIPT), str(tmp_path)]
    result = subprocess.run(args, capture_output=True, text=True)
    assert result.returncode == 1
    assert "PROF" in result.stderr or "not found" in result.stderr.lower()
