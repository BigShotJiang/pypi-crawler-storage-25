import csv
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
SCRIPT = REPO_ROOT / "scripts" / "parse_perf_csv.py"


def _run(csv_content: str, tmp_path: Path) -> subprocess.CompletedProcess:
    input_csv = tmp_path / "perf.csv"
    input_csv.write_text(csv_content, encoding="utf-8")
    output_csv = tmp_path / "metrics.csv"
    args = [sys.executable, str(SCRIPT), "--csv", str(input_csv), "--output", str(output_csv)]
    return subprocess.run(args, capture_output=True, text=True)


def test_normal_parse(tmp_path):
    content = (
        "op,impl,kernel_op,result,max_abs_error,max_rel_error,count,mean_us,min_us,max_us,run_0_us,run_1_us\n"
        "flash_attention,ascendc,flash_attention_custom_0,pass,0.001,0.0001,2,123.456,120.111,130.789,123.4,124.1\n"
    )
    result = _run(content, tmp_path)
    assert result.returncode == 0, result.stderr
    out = tmp_path / "metrics.csv"
    rows = list(csv.DictReader(out.read_text(encoding="utf-8").splitlines()))
    metrics = {r["metric"]: r["value"] for r in rows}
    assert metrics["mean_us"] == "123.456"
    assert metrics["min_us"] == "120.111"
    assert metrics["max_us"] == "130.789"
    assert metrics["accuracy_pass"] == "1"
    assert metrics["max_abs_error"] == "0.001"
    assert metrics["max_rel_error"] == "0.0001"
    assert metrics["count"] == "2"
    assert metrics["run_0_us"] == "123.4"
    assert metrics["run_1_us"] == "124.1"


def test_missing_file(tmp_path):
    args = [
        sys.executable, str(SCRIPT),
        "--csv", str(tmp_path / "nonexistent.csv"),
        "--output", str(tmp_path / "out.csv"),
    ]
    result = subprocess.run(args, capture_output=True, text=True)
    assert result.returncode == 1
