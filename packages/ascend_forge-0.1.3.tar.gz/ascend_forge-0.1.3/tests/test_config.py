# tests/test_config.py
import os
import json
import pytest

from forge.config import load_config, load_all_configs, validate_config, substitute_placeholders, ConfigError, check_task_placeholders


class TestLoadConfig:
    def test_load_valid_config(self, write_config, sample_config):
        path = write_config("repo_a", sample_config)
        config = load_config(path)
        assert config["name"] == "test_repo"
        assert config["tasks"]["build"]["command"] == "bash build.sh"

    def test_load_preserves_multiline_usage(self, write_config, sample_config):
        path = write_config("repo_a", sample_config)
        config = load_config(path)
        assert config["usage"] == sample_config["usage"]
        assert "\n\n使用方法:\n" in config["usage"]
        assert "\n\n示例:\n" in config["usage"]

    def test_load_nonexistent_file(self):
        with pytest.raises(ConfigError, match="not found"):
            load_config("/nonexistent/path.json")

    def test_load_invalid_json(self, tmp_config_dir):
        bad = tmp_config_dir / "bad.json"
        bad.write_text("{invalid json")
        with pytest.raises(ConfigError, match="parse"):
            load_config(bad)


class TestLoadAllConfigs:
    def test_load_all_different_names(self, tmp_config_dir, write_config, sample_config):
        write_config("repo_a", sample_config)
        cfg_b = dict(sample_config)
        cfg_b["name"] = "repo_b"
        write_config("repo_b", cfg_b)
        configs = load_all_configs(str(tmp_config_dir))
        assert "test_repo" in configs
        assert "repo_b" in configs

    def test_load_from_env_var(self, write_config, sample_config, monkeypatch):
        path = write_config("repo_a", sample_config)
        monkeypatch.setenv("FORGE_CONFIG_DIR", str(path.parent))
        configs = load_all_configs()
        assert len(configs) >= 1


class TestValidateConfig:
    def test_valid_config_passes(self, sample_config):
        validate_config(sample_config)

    def test_missing_name_fails(self, sample_config):
        del sample_config["name"]
        with pytest.raises(ConfigError, match="name"):
            validate_config(sample_config)

    def test_missing_working_dir_fails(self, sample_config):
        del sample_config["working_dir"]
        with pytest.raises(ConfigError, match="working_dir"):
            validate_config(sample_config)

    def test_missing_build_command_fails(self, sample_config):
        del sample_config["tasks"]["build"]["command"]
        with pytest.raises(ConfigError, match="command"):
            validate_config(sample_config)

    def test_invalid_result_type_fails(self, sample_config):
        sample_config["tasks"]["accuracy"]["result"]["type"] = "unknown"
        with pytest.raises(ConfigError, match="type"):
            validate_config(sample_config)

    def test_file_result_missing_value_column_fails(self, sample_config):
        del sample_config["tasks"]["performance"]["result"]["value_column"]
        with pytest.raises(ConfigError, match="value_column"):
            validate_config(sample_config)

    def test_timeout_zero_means_no_limit(self, sample_config):
        sample_config["tasks"]["build"]["timeout"] = 0
        validate_config(sample_config)

    def test_timeout_null_means_no_limit(self, sample_config):
        sample_config["tasks"]["build"]["timeout"] = None
        validate_config(sample_config)

    def test_top_level_source_env_allowed(self, sample_config):
        """source_env at config top level should not cause validation error."""
        sample_config["source_env"] = "/path/to/set_env.sh"
        validate_config(sample_config)  # Should not raise

    def test_usage_optional(self, sample_config):
        config = dict(sample_config)
        del config["usage"]
        validate_config(config)


class TestSubstitutePlaceholders:
    def test_substitute_op_name(self):
        args = ["--op", "{op_name}", "--verbose"]
        result = substitute_placeholders(args, {"op_name": "matmul"})
        assert result == ["--op", "matmul", "--verbose"]

    def test_substitute_multiple_placeholders(self):
        args = ["{op_name}", "{commit}", "{working_dir}"]
        result = substitute_placeholders(args, {
            "op_name": "add",
            "commit": "abc123",
            "working_dir": "/home/user/repo",
        })
        assert result == ["add", "abc123", "/home/user/repo"]

    def test_missing_placeholder_raises(self):
        args = ["--op", "{op_name}"]
        with pytest.raises(ConfigError, match="op_name"):
            substitute_placeholders(args, {})

    def test_no_placeholders_unchanged(self):
        args = ["--verbose", "--debug"]
        result = substitute_placeholders(args, {})
        assert result == ["--verbose", "--debug"]

    def test_substitute_in_string(self):
        s = "output/{op_name}_result.csv"
        result = substitute_placeholders(s, {"op_name": "matmul"})
        assert result == "output/matmul_result.csv"


class TestResolveVars:
    def test_vars_reference_each_other(self):
        from forge.config import resolve_vars
        variables = {"base": "/opt/npu", "install_path": "{base}/install"}
        result = resolve_vars(variables)
        assert result["install_path"] == "/opt/npu/install"

    def test_vars_reference_builtin(self):
        from forge.config import resolve_vars
        variables = {"working_dir": "/home/repo", "output": "{working_dir}/out"}
        result = resolve_vars(variables)
        assert result["output"] == "/home/repo/out"

    def test_chained_references(self):
        from forge.config import resolve_vars
        variables = {"a": "x", "b": "{a}/y", "c": "{b}/z"}
        result = resolve_vars(variables)
        assert result["c"] == "x/y/z"

    def test_circular_reference_raises(self):
        from forge.config import resolve_vars
        variables = {"a": "{b}", "b": "{a}"}
        with pytest.raises(ConfigError, match="Circular reference"):
            resolve_vars(variables)

    def test_no_placeholders_unchanged(self):
        from forge.config import resolve_vars
        variables = {"a": "hello", "b": "world"}
        result = resolve_vars(variables)
        assert result == {"a": "hello", "b": "world"}

    def test_self_reference_not_expanded(self):
        from forge.config import resolve_vars
        variables = {"a": "{a}/sub"}
        result = resolve_vars(variables)
        assert result["a"] == "{a}/sub"


    def test_missing_placeholder_raises(self):
        task_cfg = {"command": "bash build.sh --target {target}"}
        with pytest.raises(ConfigError, match=r"Missing placeholder\(s\) for current task: \{target\}"):
            check_task_placeholders(task_cfg, {"working_dir": "/tmp/repo"})

    def test_provided_variable_passes(self, capsys):
        task_cfg = {"command": "bash build.sh --target {target}"}
        check_task_placeholders(task_cfg, {"working_dir": "/tmp/repo", "target": "ascend910"})
        captured = capsys.readouterr()
        assert "target = ascend910" in captured.out

    def test_config_vars_count_as_known(self):
        task_cfg = {"command": "bash build.sh --target {target}"}
        check_task_placeholders(task_cfg, {"working_dir": "/tmp/repo"}, config_vars={"target": "ascend910"})

    def test_capture_vars_not_reported_missing(self, capsys):
        task_cfg = {
            "steps": [
                {
                    "command": "python prepare.py",
                    "capture": {"artifact": "ARTIFACT=(.+)"},
                },
                {
                    "command": "python test.py --artifact {artifact}",
                },
            ]
        }
        check_task_placeholders(task_cfg, {"working_dir": "/tmp/repo"})
        captured = capsys.readouterr()
        assert "artifact = (captured at runtime)" in captured.out


class TestResolveWorkingDirPath:
    def test_absolute_path_unchanged(self, sample_config):
        from forge.config import resolve_working_dir_path
        config = dict(sample_config)
        config["working_dir"] = "/absolute/path"
        result = resolve_working_dir_path(config, "/some/config/dir")
        assert result == "/absolute/path"

    def test_relative_path_resolved_from_config_dir(self, sample_config):
        from forge.config import resolve_working_dir_path
        config = dict(sample_config)
        config["working_dir"] = "../repos/my_repo"
        result = resolve_working_dir_path(config, "/home/user/configs")
        assert result == str(os.path.normpath("/home/user/repos/my_repo"))


from forge.config import resolve_workflows


class TestResolveWorkflows:
    def test_new_format_unchanged(self):
        """Object-format workflows pass through unchanged."""
        config = {
            "workflows": {
                "pipeline": {"tasks": ["build", "test"]}
            }
        }
        result, warnings = resolve_workflows(config)
        assert result == {"pipeline": {"tasks": ["build", "test"]}}
        assert warnings == []

    def test_legacy_list_format_converted(self):
        """Plain list workflows auto-convert to object format."""
        config = {
            "workflows": {
                "pipeline": ["build", "test"]
            }
        }
        result, warnings = resolve_workflows(config)
        assert result == {"pipeline": {"tasks": ["build", "test"]}}
        assert len(warnings) == 1
        assert "pipeline" in warnings[0]

    def test_no_workflows_returns_empty(self):
        """Missing workflows section returns empty dict."""
        config = {}
        result, warnings = resolve_workflows(config)
        assert result == {}
        assert warnings == []

    def test_mixed_formats(self):
        """Mix of old and new format workflows."""
        config = {
            "workflows": {
                "old": ["build", "test"],
                "new": {"tasks": ["build", "deploy", "test"]},
            }
        }
        result, warnings = resolve_workflows(config)
        assert result["old"] == {"tasks": ["build", "test"]}
        assert result["new"] == {"tasks": ["build", "deploy", "test"]}
        assert len(warnings) == 1

    def test_auto_generate_bisect_workflow_build_before_test(self):
        """Auto-generate workflow from bisect.build_before_test=true."""
        config = {
            "bisect": {"build_before_test": True},
        }
        result, warnings = resolve_workflows(config, test_type="accuracy")
        assert "_bisect_auto" in result
        assert result["_bisect_auto"]["tasks"] == ["build", "accuracy"]
        assert len(warnings) == 1
        assert "build_before_test" in warnings[0]

    def test_auto_generate_bisect_workflow_no_build(self):
        """Auto-generate workflow from bisect.build_before_test=false."""
        config = {
            "bisect": {"build_before_test": False},
        }
        result, warnings = resolve_workflows(config, test_type="performance")
        assert "_bisect_auto" in result
        assert result["_bisect_auto"]["tasks"] == ["performance"]

    def test_bisect_workflow_field_no_auto_generate(self):
        """If bisect.workflow is set, don't auto-generate."""
        config = {
            "bisect": {"workflow": "my_pipeline", "build_before_test": True},
            "workflows": {"my_pipeline": {"tasks": ["build", "test_accuracy"]}},
        }
        result, warnings = resolve_workflows(config)
        assert "_bisect_auto" not in result
        assert result["my_pipeline"] == {"tasks": ["build", "test_accuracy"]}
        assert warnings == []

    def test_object_format_with_tasks_passes_through(self):
        """Object-format workflows with 'tasks' pass through unchanged."""
        config = {
            "workflows": {
                "pipeline": {"tasks": ["build", "test"]}
            }
        }
        result, warnings = resolve_workflows(config)
        assert result == {"pipeline": {"tasks": ["build", "test"]}}
        assert warnings == []

    def test_list_format_converts_to_tasks_object(self):
        """Plain list workflows auto-convert to object format with 'tasks'."""
        config = {
            "workflows": {
                "pipeline": ["build", "test"]
            }
        }
        result, warnings = resolve_workflows(config)
        assert result == {"pipeline": {"tasks": ["build", "test"]}}
        assert len(warnings) == 1
        assert '{"tasks": [...]} format' in warnings[0]

    def test_workflow_steps_field_raises_error(self):
        """Workflow object using 'steps' should raise ConfigError."""
        config = {
            "workflows": {
                "pipeline": {"steps": ["build", "test"]}
            }
        }
        with pytest.raises(ConfigError, match=r"workflows\.pipeline\.steps has been removed; use workflows\.pipeline\.tasks instead"):
            resolve_workflows(config)


from forge.config import resolve_bisect_workflows


class TestResolveBisectWorkflows:
    def test_valid_workflows_array(self):
        """Parse valid bisect.workflows array."""
        config = {
            "bisect": {
                "workflows": [
                    {"name": "build", "repeatable": False},
                    {"name": "test", "repeatable": True}
                ]
            },
            "workflows": {
                "build": {"tasks": ["build_task"]},
                "test": {"tasks": ["test_task"]}
            }
        }
        wf_list, workflows_def, warnings = resolve_bisect_workflows(config)
        assert len(wf_list) == 2
        assert wf_list[0]["name"] == "build"
        assert wf_list[0]["repeatable"] is False
        assert len(warnings) == 0

    def test_unknown_workflow_name_raises_error(self):
        """Unknown workflow name should raise ConfigError."""
        config = {
            "bisect": {
                "workflows": [{"name": "nonexistent"}]
            },
            "workflows": {"build": {"tasks": ["x"]}}
        }
        with pytest.raises(ConfigError, match="Workflow 'nonexistent' not found"):
            resolve_bisect_workflows(config)

    def test_empty_workflows_array_raises_error(self):
        """Empty workflows array should raise ConfigError."""
        config = {
            "bisect": {"workflows": []},
            "workflows": {"build": {"tasks": ["x"]}}
        }
        with pytest.raises(ConfigError, match="bisect.workflows must have at least one"):
            resolve_bisect_workflows(config)

    def test_legacy_workflow_string_converted(self):
        """Legacy bisect.workflow string should convert to array."""
        config = {
            "bisect": {"workflow": "test_accuracy"},
            "workflows": {"test_accuracy": {"tasks": ["build", "test"]}}
        }
        wf_list, workflows_def, warnings = resolve_bisect_workflows(config)
        assert len(wf_list) == 1
        assert wf_list[0]["name"] == "test_accuracy"
        assert wf_list[0]["repeatable"] is True
        assert "deprecation" in warnings[0].lower()

    def test_legacy_workflow_string_unknown_raises_error(self):
        """Legacy bisect.workflow with unknown name should raise ConfigError."""
        config = {
            "bisect": {"workflow": "nonexistent"},
            "workflows": {"test_accuracy": {"tasks": ["build", "test"]}}
        }
        with pytest.raises(ConfigError, match="Workflow 'nonexistent' not found"):
            resolve_bisect_workflows(config)

    def test_string_entry_converted_to_dict(self):
        """String entry in workflows array should convert to dict with default repeatable."""
        config = {
            "bisect": {"workflows": ["test_accuracy"]},
            "workflows": {"test_accuracy": {"tasks": ["build", "test"]}}
        }
        wf_list, workflows_def, warnings = resolve_bisect_workflows(config)
        assert len(wf_list) == 1
        assert wf_list[0]["name"] == "test_accuracy"
        assert wf_list[0]["repeatable"] is True
        assert len(warnings) == 0

    def test_entry_missing_name_raises_error(self):
        """Workflow entry missing 'name' field should raise ConfigError."""
        config = {
            "bisect": {"workflows": [{"repeatable": True}]},
            "workflows": {"build": {"tasks": ["x"]}}
        }
        with pytest.raises(ConfigError, match="missing 'name'"):
            resolve_bisect_workflows(config)

    def test_invalid_entry_type_raises_error(self):
        """Invalid workflow entry type should raise ConfigError."""
        config = {
            "bisect": {"workflows": [123]},
            "workflows": {"build": {"tasks": ["x"]}}
        }
        with pytest.raises(ConfigError, match="must be string or dict"):
            resolve_bisect_workflows(config)

    def test_legacy_build_before_test_returns_workflow_map(self):
        """Legacy build_before_test path also returns parsed workflow definitions."""
        config = {
            "bisect": {"build_before_test": True},
        }
        wf_list, workflows_def, warnings = resolve_bisect_workflows(config, test_type="accuracy")
        assert wf_list == [{"name": "_bisect_auto", "repeatable": True}]
        assert workflows_def["_bisect_auto"]["tasks"] == ["build", "accuracy"]
        assert any("build_before_test" in warning for warning in warnings)
