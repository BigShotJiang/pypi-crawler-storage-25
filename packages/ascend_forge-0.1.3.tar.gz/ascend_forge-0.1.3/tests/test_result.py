import json
import os
import pytest
from forge.result import save_result, load_latest_result, load_result_by_commit, compare_results, ResultRecord


class TestSaveResult:
    def test_save_creates_file(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path))
        record = ResultRecord(repo="repo_a", commit="abc1234", test_type="performance", results={"matmul": 12.3, "add": 0.8})
        path = save_result(record)
        assert os.path.exists(path)
        with open(path) as f:
            data = json.load(f)
        assert data["repo"] == "repo_a"
        assert data["results"]["matmul"] == 12.3

    def test_save_creates_directory(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path))
        record = ResultRecord(repo="new_repo", commit="def456", test_type="accuracy", results={"op1": 0.99})
        path = save_result(record)
        assert os.path.exists(path)


class TestLoadResults:
    def test_load_latest(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path))
        r1 = ResultRecord(repo="repo_a", commit="aaa", test_type="performance", results={"op": 10.0})
        r2 = ResultRecord(repo="repo_a", commit="bbb", test_type="performance", results={"op": 20.0})
        save_result(r1)
        save_result(r2)
        latest = load_latest_result("repo_a", "performance")
        assert latest is not None
        assert latest.commit == "bbb"

    def test_load_by_commit(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path))
        record = ResultRecord(repo="repo_a", commit="abc1234", test_type="performance", results={"op": 10.0})
        save_result(record)
        loaded = load_result_by_commit("repo_a", "performance", "abc1234")
        assert loaded is not None
        assert loaded.results["op"] == 10.0

    def test_load_nonexistent(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path))
        assert load_latest_result("nonexistent", "performance") is None


class TestCompareResults:
    def test_compare_performance(self):
        current = {"matmul": 12.3, "add": 0.8}
        baseline = {"matmul": 10.0, "add": 0.7}
        comparison = compare_results(current, baseline)
        assert comparison["matmul"]["current"] == 12.3
        assert comparison["matmul"]["baseline"] == 10.0
        assert comparison["matmul"]["change_pct"] == pytest.approx(23.0)

    def test_compare_with_missing_op(self):
        current = {"matmul": 12.3, "add": 0.8}
        baseline = {"matmul": 10.0}
        comparison = compare_results(current, baseline)
        assert "matmul" in comparison
        assert comparison["add"]["baseline"] is None
