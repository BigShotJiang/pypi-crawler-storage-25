"""Tests for task output visibility feature."""
import os
import tempfile
import time
from pathlib import Path
from unittest.mock import patch, MagicMock
from forge.executor import _run_streaming


def test_streaming_writes_to_task_log(tmp_path):
    """When FORGE_TASK_LOG is set, streaming mode writes to that file."""
    log_file = tmp_path / "task_test.log"
    env = dict(os.environ)
    env["FORGE_TASK_LOG"] = str(log_file)

    result = _run_streaming(
        full_cmd="echo hello && echo world",
        working_dir=".",
        run_env=env,
        timeout=10.0,
    )

    assert result.returncode == 0
    assert log_file.exists()
    content = log_file.read_text()
    assert "hello" in content
    assert "world" in content


def test_start_task_sets_forge_task_log_in_env(mock_repo):
    """start_task() includes FORGE_TASK_LOG in subprocess env."""
    from forge.daemon import TaskManager
    from forge.task_state import save_task_state, TaskState

    state = TaskState(
        task_id="task_envtest2",
        command="echo",
        args={"msg": "hello"},
        status="pending",
    )
    save_task_state(state)

    with patch("forge.daemon.subprocess.Popen") as mock_popen:
        mock_proc = MagicMock()
        mock_proc.pid = 12345
        mock_popen.return_value = mock_proc

        manager = TaskManager()
        started = manager.start_task("task_envtest2")
        assert started, "Task should start"

        # Check env passed to Popen
        call_kwargs = mock_popen.call_args
        env = call_kwargs.kwargs.get("env") or call_kwargs[1].get("env")
        assert "FORGE_TASK_LOG" in env, f"FORGE_TASK_LOG not in env: {env.keys()}"
        assert env["FORGE_TASK_LOG"].endswith("task_envtest2.log"), f"Wrong log path: {env['FORGE_TASK_LOG']}"


def test_show_displays_log_file_tail(tmp_path):
    """read_log_tail returns last N lines of log."""
    from forge.task_output import read_log_tail

    log_file = tmp_path / "task_show.log"
    log_file.write_text("line1\nline2\nline3\nline4\nline5\n")

    # Default tail (100 lines) should show all
    content = read_log_tail(str(log_file), lines=100)
    assert content == "line1\nline2\nline3\nline4\nline5\n"

    # Tail 3 should show last 3
    content = read_log_tail(str(log_file), lines=3)
    assert content == "line3\nline4\nline5\n"


def test_follow_reads_new_content(tmp_path):
    """follow_log calls consumer for new content as it's appended."""
    from forge.task_output import follow_log

    log_file = tmp_path / "task_follow.log"
    log_file.write_text("initial\n")

    collected = []
    def consumer(text):
        collected.append(text)

    import threading
    stop_event = threading.Event()

    def follow():
        follow_log(str(log_file), consumer, stop_event, poll_interval=0.05)

    t = threading.Thread(target=follow)
    t.start()

    # Append new content after the follower starts
    time.sleep(0.15)
    log_file.write_text("initial\nnew1\nnew2\n")

    # Wait for follower to pick up new content
    time.sleep(0.15)
    stop_event.set()
    t.join(timeout=1)

    full_content = "".join(collected)
    assert "new1" in full_content, f"new1 not in {full_content!r}"
    assert "new2" in full_content, f"new2 not in {full_content!r}"


def test_read_log_tail_nonexistent_file(tmp_path):
    """read_log_tail returns empty string for nonexistent files."""
    from forge.task_output import read_log_tail

    content = read_log_tail(str(tmp_path / "nonexistent.log"))
    assert content == ""


def test_task_show_parser_accepts_tail_and_follow_flags():
    """The task show subcommand accepts --tail and --follow flags."""
    from forge.cli import build_parser
    parser = build_parser()

    # Parse with --tail
    args = parser.parse_args(["task", "show", "abc123", "--tail", "50"])
    assert args.action == "show"
    assert args.task_id == "abc123"
    assert args.tail == 50

    # Parse with --follow
    args = parser.parse_args(["task", "show", "abc123", "--follow"])
    assert args.follow == True

    # Parse with both
    args = parser.parse_args(["task", "show", "abc123", "--tail", "20", "--follow"])
    assert args.tail == 20
    assert args.follow == True

    # Parse with defaults
    args = parser.parse_args(["task", "show", "abc123"])
    assert args.tail == 100
    assert args.follow == False
