"""Tests for task state persistence."""

import json
import os
import tempfile
import pytest
from pathlib import Path

from forge.task_state import TaskState, save_task_state, load_task_state, list_task_states, delete_task_state


class TestTaskState:
    def test_task_state_creation(self):
        """TaskState can be created with required fields."""
        state = TaskState(
            task_id="task_001",
            command="test",
            args={"repo": "myrepo", "type": "performance"},
            status="pending",
        )
        assert state.task_id == "task_001"
        assert state.command == "test"
        assert state.status == "pending"

    def test_task_state_to_dict(self):
        """TaskState can be converted to dict for JSON serialization."""
        state = TaskState(
            task_id="task_001",
            command="test",
            args={"repo": "myrepo"},
            status="running",
            progress={"current": 1, "total": 10},
        )
        d = state.to_dict()
        assert d["task_id"] == "task_001"
        assert d["status"] == "running"
        assert d["progress"]["current"] == 1

    def test_task_state_from_dict(self):
        """TaskState can be created from dict."""
        d = {
            "task_id": "task_001",
            "command": "test",
            "args": {"repo": "myrepo"},
            "status": "completed",
            "progress": {"current": 10, "total": 10},
            "started_at": "2026-04-03T10:00:00",
            "pid": 12345,
            "restart_count": 0,
            "max_restarts": 3,
        }
        state = TaskState.from_dict(d)
        assert state.task_id == "task_001"
        assert state.status == "completed"


class TestTaskStatePersistence:
    def test_save_and_load_task_state(self, tmp_path, monkeypatch):
        """Task state can be saved and loaded."""
        monkeypatch.setenv("HOME", str(tmp_path))

        state = TaskState(
            task_id="task_001",
            command="test",
            args={"repo": "myrepo"},
            status="running",
        )
        path = save_task_state(state)
        assert os.path.exists(path)

        loaded = load_task_state("task_001")
        assert loaded.task_id == "task_001"
        assert loaded.status == "running"

    def test_list_task_states(self, tmp_path, monkeypatch):
        """List all task states."""
        monkeypatch.setenv("HOME", str(tmp_path))

        state1 = TaskState(task_id="task_001", command="test", args={}, status="running")
        state2 = TaskState(task_id="task_002", command="bisect", args={}, status="completed")
        save_task_state(state1)
        save_task_state(state2)

        states = list_task_states()
        assert len(states) == 2
        assert states[0].task_id == "task_001"

    def test_list_task_states_with_filter(self, tmp_path, monkeypatch):
        """List task states filtered by status."""
        monkeypatch.setenv("HOME", str(tmp_path))

        state1 = TaskState(task_id="task_001", command="test", args={}, status="running")
        state2 = TaskState(task_id="task_002", command="bisect", args={}, status="completed")
        save_task_state(state1)
        save_task_state(state2)

        running = list_task_states(status="running")
        assert len(running) == 1
        assert running[0].task_id == "task_001"

    def test_delete_task_state(self, tmp_path, monkeypatch):
        """Delete a task state file."""
        monkeypatch.setenv("HOME", str(tmp_path))

        state = TaskState(task_id="task_001", command="test", args={}, status="completed")
        save_task_state(state)

        delete_task_state("task_001")
        assert load_task_state("task_001") is None


def test_task_state_defaults_verbose_false():
    s = TaskState(task_id="t1", command="build", args={})
    assert s.verbose is False


def test_task_state_round_trip_with_verbose():
    s = TaskState(task_id="t1", command="build", args={}, verbose=True)
    d = s.to_dict()
    assert d["verbose"] is True
    s2 = TaskState.from_dict(d)
    assert s2.verbose is True


def test_task_state_from_dict_missing_verbose_defaults_false():
    """Old on-disk JSON without the verbose key must still load."""
    legacy = {"task_id": "t1", "command": "build", "args": {}, "status": "pending"}
    s = TaskState.from_dict(legacy)
    assert s.verbose is False