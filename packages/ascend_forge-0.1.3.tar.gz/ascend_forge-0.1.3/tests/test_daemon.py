"""Tests for daemon functionality."""

import json
import os
import tempfile
import pytest
import socket
import threading
import time

from forge.daemon import DaemonSocketServer, DaemonClient, TaskManager, Daemon
from forge.task_state import TaskState


class TestDaemonSocketServer:
    def test_server_starts_and_stops(self, tmp_path, monkeypatch):
        """Server can start and stop cleanly."""
        monkeypatch.setenv("HOME", str(tmp_path))

        server = DaemonSocketServer()
        assert not server.is_running()

        server.start()
        assert server.is_running()

        server.stop()
        assert not server.is_running()

    def test_client_can_connect(self, tmp_path, monkeypatch):
        """Client can connect to server."""
        monkeypatch.setenv("HOME", str(tmp_path))

        server = DaemonSocketServer()
        server.start()
        time.sleep(0.1)  # Wait for server to start

        client = DaemonClient()
        assert client.is_daemon_running()

        server.stop()

    def test_client_send_status_request(self, tmp_path, monkeypatch):
        """Client can send status request and get response."""
        monkeypatch.setenv("HOME", str(tmp_path))

        server = DaemonSocketServer()
        server.start()
        time.sleep(0.1)

        client = DaemonClient()
        response = client.send({"action": "status"})
        assert response["status"] == "ok"
        assert "pid" in response

        server.stop()


class TestDaemonClient:
    def test_client_fails_gracefully_when_no_server(self, tmp_path, monkeypatch):
        """Client returns error when server is not running."""
        monkeypatch.setenv("HOME", str(tmp_path))

        client = DaemonClient()
        response = client.send({"action": "status"})
        assert response["status"] == "error"
        assert "not running" in response["message"].lower()


class TestTaskManager:
    def test_submit_task(self, tmp_path, monkeypatch):
        """TaskManager can submit a task."""
        from forge.task_state import load_task_state

        monkeypatch.setenv("HOME", str(tmp_path))

        manager = TaskManager()
        state = manager.submit_task(
            command="test",
            args={"repo": "myrepo", "type": "performance", "repeat": 10},
        )
        assert state.task_id.startswith("task_")
        assert state.status == "pending"

        # Verify state was saved
        loaded = load_task_state(state.task_id)
        assert loaded is not None

    def test_start_task(self, tmp_path, monkeypatch):
        """TaskManager can start a task."""
        from forge.task_state import load_task_state
        from unittest.mock import MagicMock

        monkeypatch.setenv("HOME", str(tmp_path))

        # Mock subprocess.Popen to return a fake process
        mock_proc = MagicMock()
        mock_proc.pid = 12345
        monkeypatch.setattr("subprocess.Popen", lambda *args, **kwargs: mock_proc)

        manager = TaskManager()
        state = manager.submit_task(command="test", args={})
        manager.start_task(state.task_id)

        loaded = load_task_state(state.task_id)
        assert loaded.status == "running"
        assert loaded.pid is not None

    def test_cancel_task(self, tmp_path, monkeypatch):
        """TaskManager can cancel a task."""
        from forge.task_state import load_task_state

        monkeypatch.setenv("HOME", str(tmp_path))

        manager = TaskManager()
        state = manager.submit_task(command="test", args={})
        manager.start_task(state.task_id)
        manager.cancel_task(state.task_id)

        loaded = load_task_state(state.task_id)
        assert loaded.status == "cancelled"

    def test_list_tasks(self, tmp_path, monkeypatch):
        """TaskManager can list tasks."""
        monkeypatch.setenv("HOME", str(tmp_path))

        manager = TaskManager()
        manager.submit_task(command="test", args={})
        manager.submit_task(command="bisect", args={})

        tasks = manager.list_tasks()
        assert len(tasks) == 2

    def test_build_command_preserves_op_name_for_build(self, tmp_path, monkeypatch):
        """Build command should forward op_name through the dedicated --op flag."""
        monkeypatch.setenv("HOME", str(tmp_path))

        manager = TaskManager()
        state = TaskState(
            task_id="task_build",
            command="build",
            args={"repo": "myrepo", "op_name": "MatMul", "target": "ascend910"},
            status="pending",
        )

        assert manager._build_command(state) == [
            "forge",
            "build",
            "myrepo",
            "--op",
            "MatMul",
            "--arg",
            "target=ascend910",
        ]

    def test_build_command_forwards_reserved_placeholder_keys_from_extra_args(self, tmp_path, monkeypatch):
        """Reserved placeholder names from daemon extra args should stay as --arg entries."""
        monkeypatch.setenv("HOME", str(tmp_path))

        manager = TaskManager()
        state = TaskState(
            task_id="task_build_extra",
            command="build",
            args={
                "repo": "real_repo",
                "commit": "meta_commit",
                "extra_args": {
                    "repo": "shadow_repo",
                    "commit": "placeholder_commit",
                    "target": "ascend910",
                },
            },
            status="pending",
        )

        assert manager._build_command(state) == [
            "forge",
            "build",
            "real_repo",
            "--commit",
            "meta_commit",
            "--arg",
            "repo=shadow_repo",
            "--arg",
            "commit=placeholder_commit",
            "--arg",
            "target=ascend910",
        ]

    def test_test_command_preserves_repeat_and_compare_flags(self, tmp_path, monkeypatch):
        """Test command should preserve supported daemon flags and extra args."""
        monkeypatch.setenv("HOME", str(tmp_path))

        manager = TaskManager()
        state = TaskState(
            task_id="task_test",
            command="test",
            args={
                "repo": "myrepo",
                "type": "performance",
                "repeat": 3,
                "repeat_agg": "max",
                "baseline": "base123",
                "compare_last": True,
                "op_name": "MatMul",
                "extra_args": {"install_path": "/opt/Ascend"},
            },
            status="pending",
        )

        assert manager._build_command(state) == [
            "forge",
            "test",
            "myrepo",
            "--type",
            "performance",
            "--repeat",
            "3",
            "--repeat-agg",
            "max",
            "--op",
            "MatMul",
            "--baseline",
            "base123",
            "--compare-last",
            "--arg",
            "install_path=/opt/Ascend",
        ]

    def test_bisect_command_preserves_workflow_and_repeat_flags(self, tmp_path, monkeypatch):
        """Bisect command should preserve workflow and repeat daemon flags."""
        monkeypatch.setenv("HOME", str(tmp_path))

        manager = TaskManager()
        state = TaskState(
            task_id="task_bisect",
            command="bisect",
            args={
                "repo": "myrepo",
                "good": "good123",
                "bad": "bad456",
                "workflow": "perf_pipeline",
                "repeat": 2,
                "repeat_agg": "avg_without_outliers",
                "threshold": 1.5,
                "extra_args": {"case": "nightly"},
            },
            status="pending",
        )

        assert manager._build_command(state) == [
            "forge",
            "bisect",
            "myrepo",
            "--good",
            "good123",
            "--bad",
            "bad456",
            "--workflow",
            "perf_pipeline",
            "--repeat",
            "2",
            "--repeat-agg",
            "avg_without_outliers",
            "--threshold",
            "1.5",
            "--arg",
            "case=nightly",
        ]

    def test_task_run_command_forwards_positional_and_flags(self, tmp_path, monkeypatch):
        """task-run command should emit repo + task as positional args and forward flags."""
        monkeypatch.setenv("HOME", str(tmp_path))

        manager = TaskManager()
        state = TaskState(
            task_id="task_taskrun",
            command="task-run",
            args={
                "repo": "myrepo",
                "task": "tile2asc",
                "commit": "abc123",
                "op_name": "MatMul",
                "extra_args": {"install_path": "/opt/Ascend"},
            },
            status="pending",
        )

        assert manager._build_command(state) == [
            "forge",
            "task-run",
            "myrepo",
            "tile2asc",
            "--commit",
            "abc123",
            "--op",
            "MatMul",
            "--arg",
            "install_path=/opt/Ascend",
        ]


    def test_submit_task_persists_verbose_flag(self, tmp_path, monkeypatch):
        """submit_task(..., verbose=True) stores it on TaskState."""
        monkeypatch.setenv("HOME", str(tmp_path))

        manager = TaskManager()
        state = manager.submit_task(command="build", args={"repo": "r"}, verbose=True)
        assert state.verbose is True

        default = manager.submit_task(command="build", args={"repo": "r"})
        assert default.verbose is False

    def test_build_command_prepends_dash_v_when_verbose(self, tmp_path, monkeypatch):
        """-v must appear before the subcommand name so argparse accepts it."""
        monkeypatch.setenv("HOME", str(tmp_path))

        manager = TaskManager()
        state = TaskState(
            task_id="task_v",
            command="build",
            args={"repo": "myrepo"},
            status="pending",
            verbose=True,
        )
        cmd = manager._build_command(state)
        assert cmd[:3] == ["forge", "-v", "build"]
        assert cmd.index("-v") < cmd.index("build")

    def test_build_command_omits_dash_v_when_not_verbose(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path))

        manager = TaskManager()
        state = TaskState(
            task_id="task_nv",
            command="build",
            args={"repo": "myrepo"},
            status="pending",
        )
        cmd = manager._build_command(state)
        assert "-v" not in cmd
        assert cmd[:2] == ["forge", "build"]


class TestDaemon:
    def test_daemon_start_and_stop(self, tmp_path, monkeypatch):
        """Daemon can start and stop."""
        monkeypatch.setenv("HOME", str(tmp_path))

        daemon = Daemon()
        daemon.start()
        time.sleep(0.2)

        assert daemon.is_running()

        daemon.stop()
        assert not daemon.is_running()

    def test_daemon_recovers_interrupted_tasks(self, tmp_path, monkeypatch):
        """Daemon recovers interrupted tasks on start."""
        from forge.task_state import TaskState, save_task_state, load_task_state
        from unittest.mock import MagicMock

        monkeypatch.setenv("HOME", str(tmp_path))

        # Mock subprocess.Popen to return a fake process
        mock_proc = MagicMock()
        mock_proc.pid = 12345
        mock_proc.poll.return_value = None  # Process still running
        monkeypatch.setattr("subprocess.Popen", lambda *args, **kwargs: mock_proc)
        original_kill = os.kill
        def mock_kill(pid, sig):
            if pid == 12345:
                return  # Pretend process exists
            return original_kill(pid, sig)
        monkeypatch.setattr("os.kill", mock_kill)

        # Create an interrupted task
        state = TaskState(
            task_id="task_001",
            command="test",
            args={"repo": "myrepo"},
            status="interrupted",
            restart_count=0,
        )
        save_task_state(state)

        # Start daemon - should find and restart the task
        daemon = Daemon()
        daemon.start()
        time.sleep(0.2)

        # Check task was marked for recovery (it won't actually start without a valid repo)
        loaded = load_task_state("task_001")
        assert loaded.status in ("pending", "running")  # Reset for restart

        daemon.stop()


class TestSystemdService:
    def test_get_service_content(self):
        """get_service_content generates valid systemd service file."""
        from forge.daemon import get_service_content

        content = get_service_content("testuser", "/home/testuser")
        assert "[Unit]" in content
        assert "[Service]" in content
        assert "[Install]" in content
        assert "User=testuser" in content
        assert "WorkingDirectory=/home/testuser" in content
        assert "Restart=on-failure" in content
        assert "forge daemon start --foreground" in content

    def test_install_requires_root(self, monkeypatch):
        """install_systemd_service requires root."""
        from forge.daemon import install_systemd_service

        # Mock geteuid to return non-root
        monkeypatch.setattr("os.geteuid", lambda: 1000)

        result = install_systemd_service()
        assert result is False

    def test_uninstall_requires_root(self, monkeypatch):
        """uninstall_systemd_service requires root."""
        from forge.daemon import uninstall_systemd_service

        # Mock geteuid to return non-root
        monkeypatch.setattr("os.geteuid", lambda: 1000)

        result = uninstall_systemd_service()
        assert result is False


class TestDaemonSubmitProtocol:
    def test_handle_submit_forwards_verbose(self, tmp_path, monkeypatch):
        """The `submit` socket action reads `verbose` and forwards to the manager."""
        monkeypatch.setenv("HOME", str(tmp_path))

        daemon = Daemon()
        captured = {}

        def fake_submit(command, args, config_path=None, verbose=False,
                        owner=None, client_ip=None):
            captured["verbose"] = verbose
            return TaskState(task_id="t1", command=command, args=args,
                             status="pending", verbose=verbose)

        daemon._manager.submit_task = fake_submit  # type: ignore[assignment]
        daemon._manager.start_task = lambda _tid: True  # type: ignore[assignment]

        resp = daemon._handle_request({
            "action": "submit", "command": "build", "args": {"repo": "r"},
            "config_path": None, "verbose": True,
        })
        assert resp == {"status": "ok", "task_id": "t1"}
        assert captured["verbose"] is True

    def test_handle_submit_defaults_verbose_false(self, tmp_path, monkeypatch):
        """A request without `verbose` must default to False (back-compat)."""
        monkeypatch.setenv("HOME", str(tmp_path))

        daemon = Daemon()
        captured = {}

        def fake_submit(command, args, config_path=None, verbose=False,
                        owner=None, client_ip=None):
            captured["verbose"] = verbose
            return TaskState(task_id="t2", command=command, args=args, status="pending")

        daemon._manager.submit_task = fake_submit  # type: ignore[assignment]
        daemon._manager.start_task = lambda _tid: True  # type: ignore[assignment]

        daemon._handle_request({
            "action": "submit", "command": "build", "args": {}, "config_path": None,
        })
        assert captured["verbose"] is False


def test_daemon_builds_task_run_with_loop_args():
    from forge.daemon import TaskManager
    from forge.task_state import TaskState

    state = TaskState(
        task_id="t1",
        command="task-run",
        args={
            "repo": "demo",
            "task": "bench",
            "loop": {"var": "op_name", "values": ["A", "B"], "fail_fast": True},
        },
    )

    cmd = TaskManager()._build_command(state)

    assert cmd == [
        "forge",
        "task-run",
        "demo",
        "bench",
        "--loop",
        "op_name=A",
        "--loop",
        "op_name=B",
    ]


def test_daemon_builds_workflow_command():
    from forge.daemon import TaskManager
    from forge.task_state import TaskState

    state = TaskState(
        task_id="t1",
        command="workflow",
        args={
            "repo": "demo",
            "workflow": "perf_pipeline",
            "loop": {"var": "op_name", "values": ["A"], "fail_fast": True},
            "install_path": "/tmp/install",
        },
    )

    cmd = TaskManager()._build_command(state)

    assert cmd == [
        "forge",
        "workflow",
        "demo",
        "perf_pipeline",
        "--loop",
        "op_name=A",
        "--arg",
        "install_path=/tmp/install",
    ]
