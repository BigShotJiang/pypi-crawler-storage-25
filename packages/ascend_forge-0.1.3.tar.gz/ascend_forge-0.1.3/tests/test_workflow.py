# tests/test_workflow.py
import pytest
from forge.workflow import WorkflowRunner, WorkflowResult, StepResult


class TestWorkflowRunner:
    def test_single_step_workflow_success(self, tmp_path):
        """Workflow with one task succeeds."""
        script = tmp_path / "hello.sh"
        script.write_text("#!/bin/bash\necho 'hello world'\n")
        script.chmod(0o755)

        tasks = {
            "greet": {"command": f"bash {script}", "timeout": 10},
        }
        workflow_cfg = {"tasks": ["greet"]}
        variables = {"working_dir": str(tmp_path), "timestamp": "test"}

        runner = WorkflowRunner()
        result = runner.run(workflow_cfg, tasks, str(tmp_path), "test_repo", variables)

        assert result.success is True
        assert result.failed_step is None
        assert len(result.step_results) == 1
        assert result.step_results[0].task_name == "greet"

    def test_multi_step_workflow_success(self, tmp_path):
        """Workflow with multiple tasks runs all in order."""
        script_a = tmp_path / "a.sh"
        script_a.write_text("#!/bin/bash\necho 'step a'\n")
        script_a.chmod(0o755)
        script_b = tmp_path / "b.sh"
        script_b.write_text("#!/bin/bash\necho 'step b'\n")
        script_b.chmod(0o755)

        tasks = {
            "step_a": {"command": f"bash {script_a}", "timeout": 10},
            "step_b": {"command": f"bash {script_b}", "timeout": 10},
        }
        workflow_cfg = {"tasks": ["step_a", "step_b"]}
        variables = {"working_dir": str(tmp_path), "timestamp": "test"}

        runner = WorkflowRunner()
        result = runner.run(workflow_cfg, tasks, str(tmp_path), "test_repo", variables)

        assert result.success is True
        assert len(result.step_results) == 2
        assert result.step_results[0].task_name == "step_a"
        assert result.step_results[1].task_name == "step_b"

    def test_workflow_stops_on_failure(self, tmp_path):
        """Workflow stops at first failing task."""
        script_fail = tmp_path / "fail.sh"
        script_fail.write_text("#!/bin/bash\nexit 1\n")
        script_fail.chmod(0o755)
        script_ok = tmp_path / "ok.sh"
        script_ok.write_text("#!/bin/bash\necho ok\n")
        script_ok.chmod(0o755)

        tasks = {
            "will_fail": {"command": f"bash {script_fail}", "timeout": 10},
            "should_not_run": {"command": f"bash {script_ok}", "timeout": 10},
        }
        workflow_cfg = {"tasks": ["will_fail", "should_not_run"]}
        variables = {"working_dir": str(tmp_path), "timestamp": "test"}

        runner = WorkflowRunner()
        result = runner.run(workflow_cfg, tasks, str(tmp_path), "test_repo", variables)

        assert result.success is False
        assert result.failed_step == "will_fail"
        assert len(result.step_results) == 1

    def test_workflow_captures_variables_across_steps(self, tmp_path):
        """Captured variables from step N are available in step N+1."""
        script_capture = tmp_path / "capture.sh"
        script_capture.write_text("#!/bin/bash\necho 'OUTPUT_DIR=/tmp/results'\n")
        script_capture.chmod(0o755)
        script_use = tmp_path / "use.sh"
        script_use.write_text("#!/bin/bash\necho \"using $1\"\n")
        script_use.chmod(0o755)

        tasks = {
            "produce": {
                "command": f"bash {script_capture}",
                "timeout": 10,
                "capture": {"out_dir": "OUTPUT_DIR=(.+)"},
            },
            "consume": {
                "command": f"bash {script_use}",
                "args": ["{out_dir}"],
                "timeout": 10,
            },
        }
        workflow_cfg = {"tasks": ["produce", "consume"]}
        variables = {"working_dir": str(tmp_path), "timestamp": "test"}

        runner = WorkflowRunner()
        result = runner.run(workflow_cfg, tasks, str(tmp_path), "test_repo", variables)

        assert result.success is True
        assert "out_dir" in variables
        assert variables["out_dir"] == "/tmp/results"

    def test_workflow_result_values_from_last_step(self, tmp_path):
        """Workflow result_values come from the last step."""
        script_build = tmp_path / "build.sh"
        script_build.write_text("#!/bin/bash\necho 'Build done'\n")
        script_build.chmod(0o755)
        script_test = tmp_path / "test.sh"
        script_test.write_text("#!/bin/bash\necho 'accuracy: 0.95'\n")
        script_test.chmod(0o755)

        tasks = {
            "build": {"command": f"bash {script_build}", "timeout": 10},
            "test": {
                "command": f"bash {script_test}",
                "timeout": 10,
                "result": {"type": "stdout", "pattern": "accuracy: ([0-9.]+)"},
            },
        }
        workflow_cfg = {"tasks": ["build", "test"]}
        variables = {"working_dir": str(tmp_path), "timestamp": "test"}

        runner = WorkflowRunner()
        result = runner.run(workflow_cfg, tasks, str(tmp_path), "test_repo", variables)

        assert result.success is True
        assert result.result_values is not None
        assert result.result_values.get("value") == 0.95


class TestWorkflowRepeat:
    """Tests for WorkflowRunner repeat and aggregation."""

    def test_workflow_repeat_1_returns_single_result(self, tmp_path):
        """repeat=1 should execute once, no aggregation needed."""
        script = tmp_path / "echo.sh"
        script.write_text("#!/bin/bash\necho 'done'\n")
        script.chmod(0o755)

        runner = WorkflowRunner()
        workflow_cfg = {"tasks": ["build"]}
        tasks = {
            "build": {"command": f"bash {script}", "timeout": 10}
        }
        variables = {"working_dir": str(tmp_path), "timestamp": "test"}

        result = runner.run(
            workflow_cfg, tasks, str(tmp_path), "test", variables,
            repeat=1, repeat_agg="avg"
        )
        assert result.success is True
        assert len(result.step_results) == 1

    def test_workflow_repeat_aggregates_success(self, tmp_path):
        """repeat>1 should aggregate success (all must pass)."""
        script = tmp_path / "pass.sh"
        script.write_text("#!/bin/bash\necho 'pass'\n")
        script.chmod(0o755)

        runner = WorkflowRunner()
        workflow_cfg = {"tasks": ["test"]}
        tasks = {
            "test": {"command": f"bash {script}", "timeout": 10}
        }
        variables = {"working_dir": str(tmp_path), "timestamp": "test"}

        result = runner.run(
            workflow_cfg, tasks, str(tmp_path), "test", variables,
            repeat=3, repeat_agg="avg"
        )
        assert result.success is True  # all 3 passed

    def test_workflow_repeat_fails_on_any_failure(self, tmp_path):
        """repeat>1 should fail if any execution fails."""
        script = tmp_path / "fail.sh"
        script.write_text("#!/bin/bash\nexit 1\n")
        script.chmod(0o755)

        runner = WorkflowRunner()
        workflow_cfg = {"tasks": ["test"]}
        tasks = {
            "test": {"command": f"bash {script}", "timeout": 10}
        }
        variables = {"working_dir": str(tmp_path), "timestamp": "test"}

        result = runner.run(
            workflow_cfg, tasks, str(tmp_path), "test", variables,
            repeat=3, repeat_agg="avg"
        )
        assert result.success is False

    def test_workflow_repeat_aggregates_result_values_avg(self, tmp_path):
        """repeat>1 with avg should average result_values."""
        script = tmp_path / "value.sh"
        # Use a counter file to simulate different values each run
        counter_file = tmp_path / "counter.txt"
        counter_file.write_text("0")
        script.write_text(
            "#!/bin/bash\n"
            "cnt=$(cat counter.txt)\n"
            "echo $((cnt + 1)) > counter.txt\n"
            "echo \"latency: $((cnt + 1)).0\"\n"
        )
        script.chmod(0o755)

        runner = WorkflowRunner()
        workflow_cfg = {"tasks": ["test"]}
        tasks = {
            "test": {
                "command": f"bash {script}",
                "timeout": 10,
                "result": {"type": "stdout", "pattern": r"latency: ([0-9.]+)"},
            }
        }
        variables = {"working_dir": str(tmp_path), "timestamp": "test"}

        result = runner.run(
            workflow_cfg, tasks, str(tmp_path), "test", variables,
            repeat=3, repeat_agg="avg"
        )
        assert result.success is True
        assert result.result_values is not None
        # Values will be 1.0, 2.0, 3.0 -> avg = 2.0
        assert result.result_values.get("value") == 2.0

    def test_workflow_repeat_aggregates_result_values_max(self, tmp_path):
        """repeat>1 with max should take maximum of result_values."""
        script = tmp_path / "value.sh"
        counter_file = tmp_path / "counter.txt"
        counter_file.write_text("0")
        script.write_text(
            "#!/bin/bash\n"
            "cnt=$(cat counter.txt)\n"
            "echo $((cnt + 1)) > counter.txt\n"
            "echo \"latency: $((cnt + 1)).0\"\n"
        )
        script.chmod(0o755)

        runner = WorkflowRunner()
        workflow_cfg = {"tasks": ["test"]}
        tasks = {
            "test": {
                "command": f"bash {script}",
                "timeout": 10,
                "result": {"type": "stdout", "pattern": r"latency: ([0-9.]+)"},
            }
        }
        variables = {"working_dir": str(tmp_path), "timestamp": "test"}

        result = runner.run(
            workflow_cfg, tasks, str(tmp_path), "test", variables,
            repeat=3, repeat_agg="max"
        )
        assert result.success is True
        assert result.result_values is not None
        # Values will be 1.0, 2.0, 3.0 -> max = 3.0
        assert result.result_values.get("value") == 3.0

    def test_workflow_repeat_avg_without_outliers_filters_result_values(self, tmp_path):
        """repeat>1 with avg_without_outliers should drop workflow outliers before averaging."""
        script = tmp_path / "value.sh"
        counter_file = tmp_path / "counter.txt"
        counter_file.write_text("0")
        script.write_text(
            "#!/bin/bash\n"
            "cnt=$(cat counter.txt)\n"
            "next=$((cnt + 1))\n"
            "if [ \"$next\" -eq 10 ]; then\n"
            "  next=100\n"
            "fi\n"
            "echo $next > counter.txt\n"
            "echo \"latency: ${next}.0\"\n"
        )
        script.chmod(0o755)

        runner = WorkflowRunner()
        workflow_cfg = {"tasks": ["test"]}
        tasks = {
            "test": {
                "command": f"bash {script}",
                "timeout": 10,
                "result": {"type": "stdout", "pattern": r"latency: ([0-9.]+)"},
            }
        }
        variables = {"working_dir": str(tmp_path), "timestamp": "test"}

        result = runner.run(
            workflow_cfg, tasks, str(tmp_path), "test", variables,
            repeat=10, repeat_agg="avg_without_outliers"
        )
        assert result.success is True
        assert result.result_values is not None
        assert result.result_values.get("value") == pytest.approx(5.0)

    def test_workflow_repeat_avg_without_outliers_fails_when_ratio_exceeded(self, tmp_path):
        """repeat>1 should fail the workflow repeat aggregation when outlier ratio exceeds threshold."""
        script = tmp_path / "value.sh"
        counter_file = tmp_path / "counter.txt"
        counter_file.write_text("0")
        script.write_text(
            "#!/bin/bash\n"
            "cnt=$(cat counter.txt)\n"
            "next=$((cnt + 1))\n"
            "if [ \"$next\" -eq 4 ]; then\n"
            "  next=100\n"
            "fi\n"
            "echo $next > counter.txt\n"
            "echo \"latency: ${next}.0\"\n"
        )
        script.chmod(0o755)

        runner = WorkflowRunner()
        workflow_cfg = {"tasks": ["test"]}
        tasks = {
            "test": {
                "command": f"bash {script}",
                "timeout": 10,
                "result": {"type": "stdout", "pattern": r"latency: ([0-9.]+)"},
            }
        }
        variables = {"working_dir": str(tmp_path), "timestamp": "test"}

        result = runner.run(
            workflow_cfg, tasks, str(tmp_path), "test", variables,
            repeat=4, repeat_agg="avg_without_outliers"
        )
        assert result.success is False
        assert result.failed_step == "test"
        assert result.result_values is not None
        assert result.result_values.get("value") == pytest.approx(2.0)

    def test_workflow_repeat_avg_without_outliers_honors_custom_outlier_detection(self, tmp_path):
        """Custom outlier detection should override default workflow repeat behavior."""
        script = tmp_path / "value.sh"
        counter_file = tmp_path / "counter.txt"
        counter_file.write_text("0")
        script.write_text(
            "#!/bin/bash\n"
            "cnt=$(cat counter.txt)\n"
            "next=$((cnt + 1))\n"
            "if [ \"$next\" -eq 4 ]; then\n"
            "  next=100\n"
            "fi\n"
            "echo $next > counter.txt\n"
            "echo \"latency: ${next}.0\"\n"
        )
        script.chmod(0o755)

        runner = WorkflowRunner()
        workflow_cfg = {"tasks": ["test"]}
        tasks = {
            "test": {
                "command": f"bash {script}",
                "timeout": 10,
                "result": {"type": "stdout", "pattern": r"latency: ([0-9.]+)"},
            }
        }
        variables = {"working_dir": str(tmp_path), "timestamp": "test"}

        result = runner.run(
            workflow_cfg, tasks, str(tmp_path), "test", variables,
            repeat=4, repeat_agg="avg_without_outliers",
            outlier_detection_cfg={"max_outlier_ratio": 0.3, "min_samples": 4},
        )
        assert result.success is True
        assert result.failed_step is None
        assert result.result_values is not None
        assert result.result_values.get("value") == pytest.approx(2.0)

    def test_workflow_repeat_none_treated_as_one(self, tmp_path):
        """repeat=None should be treated as repeat=1."""
        script = tmp_path / "echo.sh"
        script.write_text("#!/bin/bash\necho 'done'\n")
        script.chmod(0o755)

        runner = WorkflowRunner()
        workflow_cfg = {"tasks": ["test"]}
        tasks = {
            "test": {
                "command": f"bash {script}",
                "timeout": 10,
            }
        }
        variables = {"working_dir": str(tmp_path), "timestamp": "test"}

        result = runner.run(
            workflow_cfg, tasks, str(tmp_path), "test", variables,
            repeat=None, repeat_agg="avg"
        )
        assert result.success is True
        assert len(result.step_results) == 1

    def test_workflow_repeat_zero_raises_value_error(self, tmp_path):
        """repeat=0 should raise ValueError."""
        script = tmp_path / "echo.sh"
        script.write_text("#!/bin/bash\necho 'done'\n")
        script.chmod(0o755)

        runner = WorkflowRunner()
        workflow_cfg = {"tasks": ["test"]}
        tasks = {
            "test": {
                "command": f"bash {script}",
                "timeout": 10,
            }
        }
        variables = {"working_dir": str(tmp_path), "timestamp": "test"}

        with pytest.raises(ValueError, match="repeat must be >= 1"):
            runner.run(
                workflow_cfg, tasks, str(tmp_path), "test", variables,
                repeat=0, repeat_agg="avg"
            )

    def test_workflow_repeat_negative_raises_value_error(self, tmp_path):
        """repeat=-1 should raise ValueError."""
        script = tmp_path / "echo.sh"
        script.write_text("#!/bin/bash\necho 'done'\n")
        script.chmod(0o755)

        runner = WorkflowRunner()
        workflow_cfg = {"tasks": ["test"]}
        tasks = {
            "test": {
                "command": f"bash {script}",
                "timeout": 10,
            }
        }
        variables = {"working_dir": str(tmp_path), "timestamp": "test"}

        with pytest.raises(ValueError, match="repeat must be >= 1"):
            runner.run(
                workflow_cfg, tasks, str(tmp_path), "test", variables,
                repeat=-1, repeat_agg="avg"
            )


class TestWorkflowLoop:
    def test_workflow_loop_runs_entire_workflow_per_value(self, tmp_path):
        build_log = tmp_path / "build.log"
        build_script = tmp_path / "build.sh"
        build_script.write_text("#!/bin/bash\necho \"build:$1\" >> build.log\n")
        build_script.chmod(0o755)
        test_script = tmp_path / "test.sh"
        test_script.write_text("#!/bin/bash\necho \"score: $1\"\n")
        test_script.chmod(0o755)

        tasks = {
            "build": {"command": f"bash {build_script}", "args": ["{score}"]},
            "test": {
                "command": f"bash {test_script}",
                "args": ["{score}"],
                "result": {"type": "stdout", "pattern": r"score: ([0-9.]+)"},
            },
        }
        variables = {"working_dir": str(tmp_path), "timestamp": "test"}

        result = WorkflowRunner().run(
            {"tasks": ["build", "test"]},
            tasks,
            str(tmp_path),
            "repo",
            variables,
            loop={"var": "score", "values": ["1", "2"]},
        )

        assert result.success is True
        assert result.result_values == {"1/value": 1.0, "2/value": 2.0}
        assert build_log.read_text().splitlines() == ["build:1", "build:2"]

    def test_workflow_loop_fail_fast_stops_after_failed_value(self, tmp_path):
        script = tmp_path / "maybe_fail.sh"
        script.write_text("#!/bin/bash\nif [ \"$1\" = \"2\" ]; then exit 1; fi\necho \"score: $1\"\n")
        script.chmod(0o755)

        tasks = {
            "test": {
                "command": f"bash {script}",
                "args": ["{score}"],
                "result": {"type": "stdout", "pattern": r"score: ([0-9.]+)"},
            }
        }

        result = WorkflowRunner().run(
            {"tasks": ["test"]},
            tasks,
            str(tmp_path),
            "repo",
            {"working_dir": str(tmp_path), "timestamp": "test"},
            loop={"var": "score", "values": ["1", "2", "3"]},
        )

        assert result.success is False
        assert result.failed_step == "2"
        assert result.result_values == {"1/value": 1.0}
