from forge.bisector import BisectResult, StepRecord
from forge.formatter import format_bisect_table


class TestFormatBisectTable:
    def test_accuracy_table(self):
        result = BisectResult(
            found_commit="cccccccccccc",
            total_steps=3,
            skipped_steps=0,
            step_records=[
                StepRecord(commit="aaaaaaaaaaaa", status="good"),
                StepRecord(commit="bbbbbbbbbbbb", status="good"),
                StepRecord(commit="cccccccccccc", status="bad"),
            ],
        )
        table = format_bisect_table(result, "accuracy")
        assert "PASS" in table
        assert "FAIL" in table
        assert "first bad" in table
        assert "cccccccc" in table
        assert "Total steps: 3" in table

    def test_performance_table(self):
        result = BisectResult(
            found_commit="cccccccccccc",
            total_steps=3,
            skipped_steps=0,
            baseline_value=10.0,
            regression_pct=10.0,
            step_records=[
                StepRecord(commit="aaaaaaaaaaaa", status="good", result_values={"matmul": 10.5}),
                StepRecord(commit="bbbbbbbbbbbb", status="good", result_values={"matmul": 11.0}),
                StepRecord(commit="cccccccccccc", status="bad", result_values={"matmul": 50.0}),
            ],
        )
        table = format_bisect_table(result, "performance", op_name="matmul")
        assert "matmul" in table
        assert "50.0000" in table
        assert "first bad" in table
        assert "Baseline: 10.0000" in table
        assert "+10.0%" in table

    def test_skip_records(self):
        result = BisectResult(
            found_commit="bbbbbbbbbbbb",
            total_steps=3,
            skipped_steps=1,
            step_records=[
                StepRecord(commit="aaaaaaaaaaaa", status="skip", skip_reason="build failed"),
                StepRecord(commit="bbbbbbbbbbbb", status="bad"),
            ],
        )
        table = format_bisect_table(result, "accuracy")
        assert "build failed" in table
        assert "skip" in table

    def test_empty_records(self):
        result = BisectResult(found_commit=None, total_steps=0, step_records=[])
        table = format_bisect_table(result, "accuracy")
        assert table == ""

    def test_performance_with_threshold(self):
        result = BisectResult(
            found_commit="bbbbbbbbbbbb",
            total_steps=2,
            skipped_steps=0,
            threshold=15.0,
            step_records=[
                StepRecord(commit="aaaaaaaaaaaa", status="good", result_values={"matmul": 10.0}),
                StepRecord(commit="bbbbbbbbbbbb", status="bad", result_values={"matmul": 20.0}),
            ],
        )
        table = format_bisect_table(result, "performance")
        assert "Threshold: 15.0" in table
