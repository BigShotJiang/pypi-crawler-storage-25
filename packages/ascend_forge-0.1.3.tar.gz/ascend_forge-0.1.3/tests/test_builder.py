import os
import subprocess
import pytest
from forge.builder import build, BuildResult


class TestBuild:
    def test_build_success(self, mock_repo, sample_config):
        sample_config["working_dir"] = str(mock_repo)
        result = build(sample_config)
        assert result.success is True

    def test_build_failure(self, mock_repo, sample_config):
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\necho 'Build failed'\nexit 1\n")
        sample_config["working_dir"] = str(mock_repo)
        result = build(sample_config)
        assert result.success is False

    def test_build_with_success_pattern(self, mock_repo, sample_config):
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["build"]["success_pattern"] = "Build succeeded"
        result = build(sample_config)
        assert result.success is True

    def test_build_success_pattern_not_matched(self, mock_repo, sample_config):
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["build"]["success_pattern"] = "COMPILATION_OK"
        result = build(sample_config)
        assert result.success is False

    def test_build_timeout(self, mock_repo, sample_config):
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\nsleep 10\n")
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["build"]["timeout"] = 1
        result = build(sample_config)
        assert result.success is False
        assert result.timed_out is True

    def test_build_no_timeout(self, mock_repo, sample_config):
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["build"]["timeout"] = 0
        result = build(sample_config)
        assert result.success is True

    def test_build_with_env(self, mock_repo, sample_config):
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\necho \"HOME=$MY_HOME\"\necho 'Build succeeded'\n")
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["build"]["env"] = {"MY_HOME": "/custom/path"}
        result = build(sample_config)
        assert result.success is True
        assert "/custom/path" in result.stdout

    def test_build_at_commit(self, tmp_path, sample_config):
        repo = tmp_path / "git_repo"
        repo.mkdir()
        subprocess.run(["git", "init"], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=str(repo), capture_output=True)
        (repo / "build.sh").write_text("#!/bin/bash\necho 'Build succeeded'\n")
        (repo / "build.sh").chmod(0o755)
        subprocess.run(["git", "add", "."], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "commit", "-m", "init"], cwd=str(repo), capture_output=True)
        first_commit = subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=str(repo), capture_output=True, text=True
        ).stdout.strip()
        (repo / "build.sh").write_text("#!/bin/bash\necho 'Build v2'\n")
        subprocess.run(["git", "add", "."], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "commit", "-m", "v2"], cwd=str(repo), capture_output=True)

        sample_config["working_dir"] = str(repo)
        sample_config["tasks"]["build"]["success_pattern"] = "Build succeeded"
        result = build(sample_config, commit=first_commit)
        assert result.success is True
        assert "Build succeeded" in result.stdout


class TestBuildArtifacts:
    def test_artifact_exists(self, mock_repo, sample_config):
        """Build succeeds when artifact exists and is fresh."""
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\necho 'Build succeeded'\nmkdir -p output\necho 'data' > output/result.bin\n")
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["build"]["artifacts"] = ["output/result.bin"]
        result = build(sample_config)
        assert result.success is True
        assert result.artifact_errors == []

    def test_artifact_missing(self, mock_repo, sample_config):
        """Build fails when artifact doesn't exist."""
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["build"]["artifacts"] = ["output/nonexistent.bin"]
        result = build(sample_config)
        assert result.success is False
        assert any("not found" in e for e in result.artifact_errors)

    def test_artifact_empty(self, mock_repo, sample_config):
        """Build fails when artifact is empty (0 bytes)."""
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\necho 'Build succeeded'\nmkdir -p output\ntouch output/result.bin\n")
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["build"]["artifacts"] = ["output/result.bin"]
        result = build(sample_config)
        assert result.success is False
        assert any("empty" in e for e in result.artifact_errors)

    def test_artifact_stale(self, mock_repo, sample_config):
        """Build fails when artifact exists but is older than build start."""
        import time
        output_dir = mock_repo / "output"
        output_dir.mkdir()
        stale_file = output_dir / "result.bin"
        stale_file.write_text("old data")
        # Set mtime to the past
        old_time = time.time() - 3600
        os.utime(stale_file, (old_time, old_time))

        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\necho 'Build succeeded'\n")  # doesn't update artifact
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["build"]["artifacts"] = ["output/result.bin"]
        result = build(sample_config)
        assert result.success is False
        assert any("stale" in e for e in result.artifact_errors)

    def test_artifact_glob_pattern(self, mock_repo, sample_config):
        """Glob patterns match multiple artifacts."""
        build_sh = mock_repo / "build.sh"
        build_sh.write_text(
            "#!/bin/bash\necho 'Build succeeded'\n"
            "mkdir -p output\n"
            "echo 'a' > output/op_add.bin\n"
            "echo 'b' > output/op_mul.bin\n"
        )
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["build"]["artifacts"] = ["output/op_*.bin"]
        result = build(sample_config)
        assert result.success is True
        assert result.artifact_errors == []

    def test_artifact_glob_no_match(self, mock_repo, sample_config):
        """Glob pattern that matches nothing fails."""
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["build"]["artifacts"] = ["output/op_*.bin"]
        result = build(sample_config)
        assert result.success is False
        assert any("not found" in e for e in result.artifact_errors)

    def test_no_artifacts_config(self, mock_repo, sample_config):
        """No artifacts field means no check (backward compatible)."""
        sample_config["working_dir"] = str(mock_repo)
        assert "artifacts" not in sample_config["tasks"]["build"]
        result = build(sample_config)
        assert result.success is True


class TestBuildMultiStep:
    def test_multi_step_all_pass(self, mock_repo, sample_config):
        """All steps succeed."""
        (mock_repo / "install.sh").write_text("#!/bin/bash\necho 'Install succeeded'\n")
        (mock_repo / "install.sh").chmod(0o755)
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["build"] = {
            "steps": [
                {"name": "compile", "command": "bash build.sh", "working_dir": "."},
                {"name": "install", "command": "bash install.sh", "working_dir": "."},
            ]
        }
        result = build(sample_config)
        assert result.success is True

    def test_multi_step_first_fails(self, mock_repo, sample_config):
        """First step fails, second should not run."""
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\nexit 1\n")
        (mock_repo / "install.sh").write_text("#!/bin/bash\necho 'should not run'\n")
        (mock_repo / "install.sh").chmod(0o755)
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["build"] = {
            "steps": [
                {"name": "compile", "command": "bash build.sh", "working_dir": "."},
                {"name": "install", "command": "bash install.sh", "working_dir": "."},
            ]
        }
        result = build(sample_config)
        assert result.success is False
        assert "should not run" not in result.stdout

    def test_multi_step_with_artifacts(self, mock_repo, sample_config):
        """Artifact check per step."""
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\necho 'Build succeeded'\nmkdir -p output\necho 'data' > output/lib.so\n")
        (mock_repo / "install.sh").write_text("#!/bin/bash\necho 'Install succeeded'\n")
        (mock_repo / "install.sh").chmod(0o755)
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["build"] = {
            "steps": [
                {"name": "compile", "command": "bash build.sh", "working_dir": ".",
                 "artifacts": ["output/lib.so"]},
                {"name": "install", "command": "bash install.sh", "working_dir": "."},
            ]
        }
        result = build(sample_config)
        assert result.success is True

    def test_multi_step_artifact_missing(self, mock_repo, sample_config):
        """Step artifact check fails."""
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["build"] = {
            "steps": [
                {"name": "compile", "command": "bash build.sh", "working_dir": ".",
                 "artifacts": ["output/nonexistent.so"]},
                {"name": "install", "command": "echo done", "working_dir": "."},
            ]
        }
        result = build(sample_config)
        assert result.success is False
        assert any("not found" in e for e in result.artifact_errors)

    def test_single_command_still_works(self, mock_repo, sample_config):
        """Backward compatibility: single command config unchanged."""
        sample_config["working_dir"] = str(mock_repo)
        result = build(sample_config)
        assert result.success is True

    def test_run_specific_step(self, mock_repo, sample_config):
        """--step runs only the named step."""
        (mock_repo / "install.sh").write_text("#!/bin/bash\necho 'Install succeeded'\n")
        (mock_repo / "install.sh").chmod(0o755)
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["build"] = {
            "steps": [
                {"name": "compile", "command": "bash build.sh", "working_dir": "."},
                {"name": "install", "command": "bash install.sh", "working_dir": "."},
            ]
        }
        result = build(sample_config, step_name="install")
        assert result.success is True
        assert "Install succeeded" in result.stdout
        # compile step should not have run
        assert "Build succeeded" not in result.stdout

    def test_step_not_found(self, mock_repo, sample_config):
        """--step with nonexistent name fails."""
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["build"] = {
            "steps": [
                {"name": "compile", "command": "bash build.sh", "working_dir": "."},
            ]
        }
        result = build(sample_config, step_name="nonexistent")
        assert result.success is False


class TestWorkingDirOverride:
    def test_extra_vars_overrides_working_dir(self, tmp_path, sample_config):
        """--arg working_dir=/new/path should override config working_dir."""
        old_repo = tmp_path / "old_repo"
        old_repo.mkdir()
        (old_repo / "build.sh").write_text("#!/bin/bash\necho 'Build from old repo'\n")
        (old_repo / "build.sh").chmod(0o755)

        new_repo = tmp_path / "new_repo"
        new_repo.mkdir()
        (new_repo / "build.sh").write_text("#!/bin/bash\necho 'Build from new repo'\n")
        (new_repo / "build.sh").chmod(0o755)

        sample_config["working_dir"] = str(old_repo)
        result = build(sample_config, extra_vars={"working_dir": str(new_repo)})
        assert result.success is True
        assert "Build from new repo" in result.stdout

    def test_extra_vars_repo_root_resolves_working_dir(self, tmp_path, sample_config):
        """--arg repo_root=/new/path should resolve working_dir={repo_root}."""
        old_repo = tmp_path / "old_repo"
        old_repo.mkdir()
        (old_repo / "build.sh").write_text("#!/bin/bash\necho 'Build from old repo'\n")
        (old_repo / "build.sh").chmod(0o755)

        new_repo = tmp_path / "new_repo"
        new_repo.mkdir()
        (new_repo / "build.sh").write_text("#!/bin/bash\necho 'Build from new repo'\n")
        (new_repo / "build.sh").chmod(0o755)

        sample_config["working_dir"] = "{repo_root}"
        sample_config["vars"] = {"repo_root": str(old_repo)}
        result = build(sample_config, extra_vars={"repo_root": str(new_repo)})
        assert result.success is True
        assert "Build from new repo" in result.stdout


class TestConfigVars:
    def test_config_vars_substituted(self, mock_repo, sample_config):
        """Config vars are available as placeholders."""
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\necho \"target: $1\"\n")
        sample_config["working_dir"] = str(mock_repo)
        sample_config["vars"] = {"target": "ascend910"}
        sample_config["tasks"]["build"]["args"] = ["{target}"]
        result = build(sample_config)
        assert result.success is True
        assert "target: ascend910" in result.stdout

    def test_cli_overrides_config_vars(self, mock_repo, sample_config):
        """CLI extra_vars override config vars."""
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\necho \"target: $1\"\n")
        sample_config["working_dir"] = str(mock_repo)
        sample_config["vars"] = {"target": "ascend910"}
        sample_config["tasks"]["build"]["args"] = ["{target}"]
        result = build(sample_config, extra_vars={"target": "ascend310"})
        assert result.success is True
        assert "target: ascend310" in result.stdout

    def test_no_vars_backward_compatible(self, mock_repo, sample_config):
        """No vars field works fine (backward compatible)."""
        sample_config["working_dir"] = str(mock_repo)
        assert "vars" not in sample_config
        result = build(sample_config)
        assert result.success is True
