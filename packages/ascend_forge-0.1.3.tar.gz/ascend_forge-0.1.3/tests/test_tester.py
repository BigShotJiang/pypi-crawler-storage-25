import csv
from unittest.mock import patch

import pytest
from forge.tester import run_test, extract_result_from_stdout, extract_result_from_file, TestResult


class TestExtractResultFromStdout:
    def test_extract_single_value(self):
        stdout = "Running test...\naccuracy: 0.9876\nDone."
        value = extract_result_from_stdout(stdout, r"accuracy: ([0-9.]+)")
        assert value == pytest.approx(0.9876)

    def test_extract_no_match(self):
        stdout = "Running test...\nDone."
        value = extract_result_from_stdout(stdout, r"accuracy: ([0-9.]+)")
        assert value is None

    def test_extract_first_group(self):
        stdout = "throughput: 1234.5 ops/s"
        value = extract_result_from_stdout(stdout, r"throughput: ([0-9.]+) ops/s")
        assert value == pytest.approx(1234.5)


class TestExtractResultFromFile:
    def test_csv_with_header(self, tmp_path):
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms,mem_mb\nmatmul,12.3,256\nadd,0.8,64\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",")
        assert results == {"matmul": 12.3, "add": 0.8}

    def test_csv_no_header(self, tmp_path):
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("matmul,12.3\nadd,0.8\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=False, delimiter=",")
        assert results == {"matmul": 12.3, "add": 0.8}

    def test_csv_tab_delimiter(self, tmp_path):
        csv_file = tmp_path / "result.tsv"
        csv_file.write_text("op\ttime\nmatmul\t12.3\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter="\t")
        assert results == {"matmul": 12.3}

    def test_csv_no_op_column(self, tmp_path):
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("time_ms\n12.3\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=0, header=True, delimiter=",")
        assert results == {"0": 12.3}

    def test_csv_specific_op(self, tmp_path):
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nmatmul,12.3\nadd,0.8\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",", op_name="matmul")
        assert results == {"matmul": 12.3}

    def test_unsupported_format(self):
        with pytest.raises(ValueError, match="Unsupported"):
            extract_result_from_file("/some/file.xlsx", format="xlsx", value_column=0)

    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            extract_result_from_file("/nonexistent/file.csv", format="csv", value_column=0)

    def test_aggregate_avg(self, tmp_path):
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nmatmul,10.0\nmatmul,20.0\nmatmul,30.0\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",", aggregate="avg")
        assert results == {"matmul": 20.0}

    def test_aggregate_last(self, tmp_path):
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nmatmul,10.0\nmatmul,20.0\nmatmul,30.0\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",", aggregate="last")
        assert results == {"matmul": 30.0}

    def test_aggregate_min(self, tmp_path):
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nmatmul,10.0\nmatmul,5.0\nmatmul,20.0\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",", aggregate="min")
        assert results == {"matmul": 5.0}

    def test_aggregate_max(self, tmp_path):
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nmatmul,10.0\nmatmul,5.0\nmatmul,20.0\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",", aggregate="max")
        assert results == {"matmul": 20.0}

    def test_aggregate_none_returns_last(self, tmp_path):
        """Without aggregate, returns last value per key (backward compat)."""
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nmatmul,10.0\nmatmul,30.0\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",")
        assert results == {"matmul": 30.0}

    def test_aggregate_multiple_ops(self, tmp_path):
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nmatmul,10.0\nadd,5.0\nmatmul,20.0\nadd,15.0\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",", aggregate="avg")
        assert results == {"matmul": 15.0, "add": 10.0}

    def test_op_name_wildcard(self, tmp_path):
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nmatmul_fp16,10.0\nmatmul_fp32,20.0\nadd_fp16,5.0\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",", op_name="matmul*")
        assert results == {"matmul_fp16": 10.0, "matmul_fp32": 20.0}
        assert "add_fp16" not in results

    def test_op_name_wildcard_question_mark(self, tmp_path):
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nadd_v1,10.0\nadd_v2,20.0\nadd_v10,30.0\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",", op_name="add_v?")
        assert results == {"add_v1": 10.0, "add_v2": 20.0}
        assert "add_v10" not in results

    def test_op_name_exact_still_works(self, tmp_path):
        """Exact match (no wildcards) still works."""
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nmatmul,10.0\nadd,5.0\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",", op_name="matmul")
        assert results == {"matmul": 10.0}

    def test_op_name_wildcard_with_aggregate(self, tmp_path):
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nmatmul_fp16,10.0\nmatmul_fp16,20.0\nmatmul_fp32,30.0\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",", op_name="matmul*", aggregate="avg")
        assert results == {"matmul_fp16": 15.0, "matmul_fp32": 30.0}

    def test_op_name_case_insensitive(self, tmp_path):
        """op_name matching should be case-insensitive (e.g. snake_case vs PascalCase)."""
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nAiInfraSparseFlashAttentionGqa,82.46\nOtherOp,10.0\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",", op_name="aiinfrasparseflashattentiongqa")
        assert results == {"AiInfraSparseFlashAttentionGqa": 82.46}

    def test_op_name_snake_case_vs_pascal_case(self, tmp_path):
        """snake_case op_name should match PascalCase CSV key (normalize underscores)."""
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nAiInfraSparseFlashAttentionGqa,82.46\nOtherOp,10.0\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",", op_name="ai_infra_sparse_flash_attention_gqa")
        assert results == {"AiInfraSparseFlashAttentionGqa": 82.46}

    def test_op_name_snake_case_vs_pascal_case_preserves_key(self, tmp_path):
        """Result dict key should preserve original CSV casing, not the normalized form."""
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nSparseFlashAttnGqa,50.0\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",", op_name="sparse_flash_attn_gqa")
        assert "SparseFlashAttnGqa" in results
        assert results["SparseFlashAttnGqa"] == 50.0

    def test_op_name_snake_case_wildcard_vs_pascal_case(self, tmp_path):
        """snake_case wildcard pattern should match PascalCase CSV keys."""
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nAiInfraSparseFlashAttentionGqa,82.46\nAiInfraOtherOp,10.0\nUnrelatedOp,5.0\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",", op_name="ai_infra*")
        assert results == {"AiInfraSparseFlashAttentionGqa": 82.46, "AiInfraOtherOp": 10.0}
        assert "UnrelatedOp" not in results

    def test_op_name_pascal_case_vs_snake_case_csv(self, tmp_path):
        """PascalCase op_name should match snake_case CSV key (reverse direction)."""
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nmat_mul_fp16,10.0\nadd_fp16,5.0\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",", op_name="MatMulFp16")
        assert results == {"mat_mul_fp16": 10.0}

    def test_op_name_no_match_still_returns_empty(self, tmp_path):
        """Completely unrelated op_name should still return empty dict."""
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nAiInfraSparseFlashAttentionGqa,82.46\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",", op_name="totally_different_op")
        assert results == {}

    def test_op_name_wildcard_case_insensitive(self, tmp_path):
        """Wildcard op_name matching should also be case-insensitive."""
        csv_file = tmp_path / "result.csv"
        csv_file.write_text("op,time_ms\nMatMul_FP16,10.0\nMatMul_FP32,20.0\nAdd_FP16,5.0\n")
        results = extract_result_from_file(str(csv_file), format="csv", value_column=1, op_column=0, header=True, delimiter=",", op_name="matmul*")
        assert results == {"MatMul_FP16": 10.0, "MatMul_FP32": 20.0}


class TestRunTest:
    def test_run_accuracy_test_stdout(self, mock_repo, sample_config):
        test_script = mock_repo / "tests" / "run_test.py"
        test_script.write_text("#!/usr/bin/env python3\nprint('accuracy: 0.9876')\nprint('accuracy PASS')\n")
        sample_config["working_dir"] = str(mock_repo)
        result = run_test(sample_config, test_type="accuracy")
        assert result.success is True
        assert result.result_values is not None

    def test_run_test_failure(self, mock_repo, sample_config):
        test_script = mock_repo / "tests" / "run_test.py"
        test_script.write_text("#!/usr/bin/env python3\nimport sys; sys.exit(1)\n")
        sample_config["working_dir"] = str(mock_repo)
        result = run_test(sample_config, test_type="accuracy")
        assert result.success is False

    def test_run_performance_test_file(self, mock_repo, sample_config):
        test_script = mock_repo / "tests" / "run_perf.sh"
        output_dir = mock_repo / "tests" / "output"
        output_dir.mkdir(parents=True)
        csv_file = output_dir / "result.csv"
        csv_file.write_text("op,time_ms\nmatmul,12.3\nadd,0.8\n")
        test_script.write_text("#!/bin/bash\necho 'done'\n")
        test_script.chmod(0o755)
        sample_config["working_dir"] = str(mock_repo)
        result = run_test(sample_config, test_type="performance")
        assert result.success is True
        assert result.result_values == {"matmul": 12.3, "add": 0.8}

    def test_run_performance_op_not_found_fails(self, mock_repo, sample_config):
        """Test fails when specified op name matches nothing in CSV."""
        test_script = mock_repo / "tests" / "run_perf.sh"
        output_dir = mock_repo / "tests" / "output"
        output_dir.mkdir(parents=True)
        csv_file = output_dir / "result.csv"
        csv_file.write_text("op,time_ms\nmatmul,12.3\nadd,0.8\n")
        test_script.write_text("#!/bin/bash\necho 'done'\n")
        test_script.chmod(0o755)
        sample_config["working_dir"] = str(mock_repo)
        result = run_test(sample_config, test_type="performance", op_name="nonexistent_op")
        assert result.success is False
        assert result.result_values == {}

    def test_stale_csv_result_returns_none(self, mock_repo, sample_config):
        """CSV file not updated by this test run should be detected as stale."""
        import time
        test_script = mock_repo / "tests" / "run_perf.sh"
        output_dir = mock_repo / "tests" / "output"
        output_dir.mkdir(parents=True)
        csv_file = output_dir / "result.csv"
        csv_file.write_text("op,time_ms\nmatmul,12.3\n")
        # Set mtime to the past so it's stale
        old_time = time.time() - 100
        import os
        os.utime(str(csv_file), (old_time, old_time))
        # Test script does NOT update the CSV
        test_script.write_text("#!/bin/bash\necho 'done'\n")
        test_script.chmod(0o755)
        sample_config["working_dir"] = str(mock_repo)
        result = run_test(sample_config, test_type="performance")
        assert result.result_values is None

    def test_run_test_timeout(self, mock_repo, sample_config):
        test_script = mock_repo / "tests" / "run_test.py"
        test_script.write_text("#!/usr/bin/env python3\nimport time; time.sleep(10)\n")
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["accuracy"]["timeout"] = 1
        result = run_test(sample_config, test_type="accuracy")
        assert result.success is False
        assert result.timed_out is True

    def test_op_filter_with_placeholder(self, mock_repo, sample_config):
        """op_filter in result config uses placeholder substitution for CSV matching."""
        test_script = mock_repo / "tests" / "run_perf.sh"
        output_dir = mock_repo / "tests" / "output"
        output_dir.mkdir(parents=True)
        csv_file = output_dir / "result.csv"
        csv_file.write_text("op,time_ms\nMatMulV2_fp16,12.3\nAddV2_fp16,0.8\n")
        test_script.write_text("#!/bin/bash\necho 'done'\n")
        test_script.chmod(0o755)
        sample_config["working_dir"] = str(mock_repo)
        # op_filter maps {op_name} to the actual CSV op name
        sample_config["tasks"]["performance"]["result"]["op_filter"] = "{op_name}V2_fp16"
        result = run_test(sample_config, test_type="performance", op_name="MatMul")
        assert result.success is True
        assert result.result_values == {"MatMulV2_fp16": 12.3}

    def test_op_filter_with_wildcard(self, mock_repo, sample_config):
        """op_filter supports wildcards after placeholder substitution."""
        test_script = mock_repo / "tests" / "run_perf.sh"
        output_dir = mock_repo / "tests" / "output"
        output_dir.mkdir(parents=True)
        csv_file = output_dir / "result.csv"
        csv_file.write_text("op,time_ms\nMatMul_fp16,10.0\nMatMul_fp32,20.0\nAdd_fp16,5.0\n")
        test_script.write_text("#!/bin/bash\necho 'done'\n")
        test_script.chmod(0o755)
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["performance"]["result"]["op_filter"] = "{op_name}*"
        result = run_test(sample_config, test_type="performance", op_name="MatMul")
        assert result.success is True
        assert result.result_values == {"MatMul_fp16": 10.0, "MatMul_fp32": 20.0}
        assert "Add_fp16" not in result.result_values

    def test_repeat_performance_averages(self, mock_repo, sample_config):
        """Repeat=3 runs performance test 3 times and averages results."""
        # Script writes a random-ish value each run using a counter file
        test_script = mock_repo / "tests" / "run_perf.sh"
        output_dir = mock_repo / "tests" / "output"
        output_dir.mkdir(parents=True)
        # Script increments a counter and writes different values each run
        test_script.write_text(
            "#!/bin/bash\n"
            "COUNTER_FILE=tests/output/.counter\n"
            "if [ -f $COUNTER_FILE ]; then\n"
            "  COUNT=$(cat $COUNTER_FILE)\n"
            "else\n"
            "  COUNT=0\n"
            "fi\n"
            "COUNT=$((COUNT + 1))\n"
            "echo $COUNT > $COUNTER_FILE\n"
            "echo 'op,time_ms' > tests/output/result.csv\n"
            "echo \"matmul,${COUNT}0.0\" >> tests/output/result.csv\n"
        )
        test_script.chmod(0o755)
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["performance"]["working_dir"] = "."
        sample_config["tasks"]["performance"]["command"] = "bash tests/run_perf.sh"
        sample_config["tasks"]["performance"]["result"]["path"] = "tests/output/result.csv"
        result = run_test(sample_config, test_type="performance", repeat=3)
        assert result.success is True
        # Values: 10.0, 20.0, 30.0 → avg 20.0
        assert result.result_values["matmul"] == pytest.approx(20.0)

    def test_repeat_ignored_for_accuracy(self, mock_repo, sample_config):
        """Repeat is ignored for accuracy tests."""
        test_script = mock_repo / "tests" / "run_test.py"
        test_script.write_text("#!/usr/bin/env python3\nprint('accuracy: 0.99')\nprint('accuracy PASS')\n")
        sample_config["working_dir"] = str(mock_repo)
        result = run_test(sample_config, test_type="accuracy", repeat=3)
        assert result.success is True

    def test_repeat_uses_same_timestamp_for_task_runner_repeat(self, mock_repo, sample_config):
        """Repeat delegated to TaskRunner keeps the original placeholder env config."""
        test_script = mock_repo / "tests" / "run_perf.sh"
        output_dir = mock_repo / "tests" / "output"
        output_dir.mkdir(parents=True)
        ts_log = mock_repo / "ts_log.txt"
        test_script.write_text(
            "#!/bin/bash\n"
            "echo $FORGE_TS >> " + str(ts_log) + "\n"
            "echo 'op,time_ms' > tests/output/result.csv\n"
            "echo 'matmul,10.0' >> tests/output/result.csv\n"
        )
        test_script.chmod(0o755)
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["performance"]["working_dir"] = "."
        sample_config["tasks"]["performance"]["command"] = "bash tests/run_perf.sh"
        sample_config["tasks"]["performance"]["result"]["path"] = "tests/output/result.csv"
        sample_config["tasks"]["performance"]["env"] = {"FORGE_TS": "{timestamp}"}
        call_count = [0]
        original_make_timestamp = __import__('forge.tester', fromlist=['_make_timestamp'])._make_timestamp
        def mock_timestamp():
            call_count[0] += 1
            return f"20260327_10000{call_count[0]}"
        import forge.tester
        forge.tester._make_timestamp = mock_timestamp
        try:
            result = run_test(sample_config, test_type="performance", repeat=3)
        finally:
            forge.tester._make_timestamp = original_make_timestamp
        assert result.success is True
        assert call_count[0] == 1
        assert ts_log.read_text().splitlines() == ["{timestamp}"] * 3

    @patch("forge.tester.TaskRunner")
    def test_run_test_delegates_repeat_to_task_runner(self, mock_runner_cls, mock_repo, sample_config):
        runner = mock_runner_cls.return_value
        runner.run.return_value = TestResult(success=True, stdout="ok", stderr="", result_values={"matmul": 20.0})
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["performance"]["repeat"] = 2
        sample_config["tasks"]["performance"]["repeat_agg"] = "max"

        result = run_test(sample_config, test_type="performance")

        assert result.success is True
        runner.run.assert_called_once()
        effective_cfg = runner.run.call_args.args[0]
        assert effective_cfg is not sample_config["tasks"]["performance"]
        assert effective_cfg["repeat"] == 2
        assert effective_cfg["repeat_agg"] == "max"

    @patch("forge.tester.TaskRunner")
    def test_run_test_cli_repeat_overrides_config_for_task_runner(self, mock_runner_cls, mock_repo, sample_config):
        runner = mock_runner_cls.return_value
        runner.run.return_value = TestResult(success=True, stdout="ok", stderr="", result_values={"matmul": 30.0})
        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["performance"]["repeat"] = 2
        sample_config["tasks"]["performance"]["repeat_agg"] = "avg"

        run_test(sample_config, test_type="performance", repeat=4, repeat_agg="max")

        runner.run.assert_called_once()
        effective_cfg = runner.run.call_args.args[0]
        assert effective_cfg["repeat"] == 4
        assert effective_cfg["repeat_agg"] == "max"


class TestMultiStepTest:
    def test_multi_step_all_pass(self, mock_repo, sample_config):
        """All steps succeed, result extracted from last step."""
        (mock_repo / "tests" / "step1.sh").write_text("#!/bin/bash\necho 'step1 done'\n")
        (mock_repo / "tests" / "step1.sh").chmod(0o755)
        (mock_repo / "tests" / "step2.py").write_text("#!/usr/bin/env python3\nprint('accuracy: 0.99')\nprint('PASS')\n")

        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["accuracy"] = {
            "steps": [
                {"name": "prepare", "command": "bash step1.sh", "working_dir": "tests/"},
                {"name": "check", "command": "python3 step2.py", "working_dir": "tests/",
                 "success_pattern": "PASS",
                 "result": {"type": "stdout", "pattern": "accuracy: ([0-9.]+)"}},
            ],
            "timeout": 30,
        }
        result = run_test(sample_config, test_type="accuracy")
        assert result.success is True
        assert result.result_values is not None
        assert result.result_values.get("value") == 0.99

    def test_multi_step_first_fails(self, mock_repo, sample_config):
        """First step fails, second step should not run."""
        (mock_repo / "tests" / "fail.sh").write_text("#!/bin/bash\nexit 1\n")
        (mock_repo / "tests" / "fail.sh").chmod(0o755)
        (mock_repo / "tests" / "step2.py").write_text("#!/usr/bin/env python3\nprint('should not run')\n")

        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["accuracy"] = {
            "steps": [
                {"name": "prepare", "command": "bash fail.sh", "working_dir": "tests/"},
                {"name": "check", "command": "python3 step2.py", "working_dir": "tests/"},
            ],
            "timeout": 30,
        }
        result = run_test(sample_config, test_type="accuracy")
        assert result.success is False

    def test_multi_step_with_file_result(self, mock_repo, sample_config):
        """Multi-step with CSV file result extraction."""
        output_dir = mock_repo / "tests" / "output"
        output_dir.mkdir(parents=True)

        (mock_repo / "tests" / "gen.sh").write_text(
            "#!/bin/bash\necho 'op,time_ms' > tests/output/result.csv\necho 'matmul,12.3' >> tests/output/result.csv\n"
        )
        (mock_repo / "tests" / "gen.sh").chmod(0o755)
        (mock_repo / "tests" / "run.sh").write_text("#!/bin/bash\necho 'done'\n")
        (mock_repo / "tests" / "run.sh").chmod(0o755)

        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["performance"] = {
            "steps": [
                {"name": "generate", "command": "bash tests/gen.sh", "working_dir": "."},
                {"name": "run", "command": "bash tests/run.sh", "working_dir": ".",
                 "result": {
                     "type": "file", "path": "tests/output/result.csv", "format": "csv",
                     "value_column": 1, "op_column": 0, "header": True, "delimiter": ","
                 }},
            ],
            "timeout": 30,
        }
        result = run_test(sample_config, test_type="performance")
        assert result.success is True
        assert result.result_values == {"matmul": 12.3}

    def test_multi_step_skip_if_exists(self, mock_repo, sample_config):
        """Step with skip_if_exists skips when file exists."""
        output_dir = mock_repo / "tests" / "output"
        output_dir.mkdir(parents=True)
        # Pre-create the golden file so step 1 gets skipped
        golden = output_dir / "golden.bin"
        golden.write_text("golden data")

        # Step 1 would fail if executed (exit 1), but should be skipped
        (mock_repo / "tests" / "gen.sh").write_text("#!/bin/bash\nexit 1\n")
        (mock_repo / "tests" / "gen.sh").chmod(0o755)
        (mock_repo / "tests" / "run.sh").write_text("#!/bin/bash\necho 'accuracy: 0.99'\necho 'PASS'\n")
        (mock_repo / "tests" / "run.sh").chmod(0o755)

        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["accuracy"] = {
            "steps": [
                {"name": "generate golden", "command": "bash tests/gen.sh", "working_dir": ".",
                 "skip_if_exists": "tests/output/golden.bin"},
                {"name": "check", "command": "bash tests/run.sh", "working_dir": ".",
                 "success_pattern": "PASS",
                 "result": {"type": "stdout", "pattern": "accuracy: ([0-9.]+)"}},
            ],
            "timeout": 30,
        }
        result = run_test(sample_config, test_type="accuracy")
        assert result.success is True  # Step 1 skipped, step 2 ran

    def test_multi_step_no_skip_if_not_exists(self, mock_repo, sample_config):
        """Step with skip_if_exists runs normally when file doesn't exist."""
        (mock_repo / "tests" / "gen.sh").write_text("#!/bin/bash\necho 'generated'\n")
        (mock_repo / "tests" / "gen.sh").chmod(0o755)
        (mock_repo / "tests" / "run.sh").write_text("#!/bin/bash\necho 'accuracy: 0.99'\necho 'PASS'\n")
        (mock_repo / "tests" / "run.sh").chmod(0o755)

        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["accuracy"] = {
            "steps": [
                {"name": "generate golden", "command": "bash tests/gen.sh", "working_dir": ".",
                 "skip_if_exists": "tests/output/nonexistent.bin"},
                {"name": "check", "command": "bash tests/run.sh", "working_dir": ".",
                 "success_pattern": "PASS",
                 "result": {"type": "stdout", "pattern": "accuracy: ([0-9.]+)"}},
            ],
            "timeout": 30,
        }
        result = run_test(sample_config, test_type="accuracy")
        assert result.success is True

    def test_skip_if_artifacts_exist_false(self, mock_repo, sample_config):
        """Step with skip_if_artifacts_exist: false should NOT skip even if artifacts exist."""
        output_dir = mock_repo / "tests" / "output"
        output_dir.mkdir(parents=True)
        # Pre-create the artifact file
        artifact = output_dir / "result.bin"
        artifact.write_text("existing data")

        # Step would be skipped if skip_if_artifacts_exist was true/missing
        # But with explicit false, it should run
        (mock_repo / "tests" / "gen.sh").write_text("#!/bin/bash\necho 'generated'\n")
        (mock_repo / "tests" / "gen.sh").chmod(0o755)

        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["accuracy"] = {
            "steps": [
                {"name": "generate", "command": "bash tests/gen.sh", "working_dir": ".",
                 "artifacts": ["tests/output/result.bin"],
                 "skip_if_artifacts_exist": False},  # explicit false, should NOT skip
            ],
            "timeout": 30,
        }
        result = run_test(sample_config, test_type="accuracy")
        assert result.success is True
        # Verify the step actually ran (not skipped) by checking stdout
        assert "generated" in result.stdout


class TestCapture:
    def test_capture_variable_from_stdout(self, mock_repo, sample_config):
        """Capture a value from step stdout and use in next step."""
        # Step 1: prints "version: 2.5"
        (mock_repo / "tests" / "get_ver.sh").write_text("#!/bin/bash\necho 'version: 2.5'\n")
        (mock_repo / "tests" / "get_ver.sh").chmod(0o755)
        # Step 2: uses captured {my_version} — just echo it to verify
        (mock_repo / "tests" / "use_ver.sh").write_text("#!/bin/bash\necho \"accuracy: 0.99\"\necho \"using version $1\"\necho \"PASS\"\n")
        (mock_repo / "tests" / "use_ver.sh").chmod(0o755)

        sample_config["working_dir"] = str(mock_repo)
        sample_config["tasks"]["accuracy"] = {
            "steps": [
                {
                    "name": "get version",
                    "command": "bash tests/get_ver.sh",
                    "working_dir": ".",
                    "capture": {"my_version": "version: ([0-9.]+)"},
                },
                {
                    "name": "use version",
                    "command": "bash tests/use_ver.sh",
                    "args": ["{my_version}"],
                    "working_dir": ".",
                    "success_pattern": "PASS",
                    "result": {"type": "stdout", "pattern": "accuracy: ([0-9.]+)"},
                },
            ],
            "timeout": 30,
        }
        result = run_test(sample_config, test_type="accuracy")
        assert result.success is True
        assert "using version 2.5" in result.stdout


class TestSourceEnv:
    def test_source_env_injects_variables(self, mock_repo, sample_config):
        """source_env script sets env vars available to test command."""
        # Create env script that sets MY_VAR
        (mock_repo / "set_env.sh").write_text("#!/bin/bash\nexport MY_VAR=hello_from_env\n")
        (mock_repo / "set_env.sh").chmod(0o755)

        # Create test script that checks MY_VAR
        test_script = mock_repo / "tests" / "run_test.py"
        test_script.write_text(
            "#!/usr/bin/env python3\n"
            "import os\n"
            "val = os.environ.get('MY_VAR', 'NOT_SET')\n"
            "print(f'accuracy: 0.99')\n"
            "print(f'MY_VAR={val}')\n"
            "if val == 'hello_from_env':\n"
            "    print('accuracy PASS')\n"
            "else:\n"
            "    print('accuracy FAIL')\n"
            "    import sys; sys.exit(1)\n"
        )

        sample_config["working_dir"] = str(mock_repo)
        sample_config["source_env"] = str(mock_repo / "set_env.sh")
        result = run_test(sample_config, test_type="accuracy")
        assert result.success is True
        assert "MY_VAR=hello_from_env" in result.stdout

    def test_no_source_env(self, mock_repo, sample_config):
        """Without source_env, works normally (backward compatible)."""
        test_script = mock_repo / "tests" / "run_test.py"
        test_script.write_text("#!/usr/bin/env python3\nprint('accuracy: 0.99')\nprint('accuracy PASS')\n")
        sample_config["working_dir"] = str(mock_repo)
        assert "source_env" not in sample_config
        result = run_test(sample_config, test_type="accuracy")
        assert result.success is True

    def test_source_env_top_level(self, mock_repo, sample_config):
        """Top-level source_env applies to all test types."""
        (mock_repo / "set_env.sh").write_text("#!/bin/bash\nexport MY_VAR=from_top_level\n")
        (mock_repo / "set_env.sh").chmod(0o755)

        test_script = mock_repo / "tests" / "run_test.py"
        test_script.write_text(
            "#!/usr/bin/env python3\n"
            "import os\n"
            "val = os.environ.get('MY_VAR', 'NOT_SET')\n"
            "print(f'accuracy: 0.99')\n"
            "print(f'MY_VAR={val}')\n"
            "if val == 'from_top_level':\n"
            "    print('accuracy PASS')\n"
            "else:\n"
            "    import sys; sys.exit(1)\n"
        )

        sample_config["working_dir"] = str(mock_repo)
        # Set source_env at top level (not per-type)
        sample_config["source_env"] = str(mock_repo / "set_env.sh")
        result = run_test(sample_config, test_type="accuracy")
        assert result.success is True
        assert "MY_VAR=from_top_level" in result.stdout

    def test_source_env_type_overrides_top_level(self, mock_repo, sample_config):
        """Per-type source_env overrides top-level source_env."""
        (mock_repo / "env_top.sh").write_text("#!/bin/bash\nexport MY_VAR=from_top\n")
        (mock_repo / "env_top.sh").chmod(0o755)
        (mock_repo / "env_type.sh").write_text("#!/bin/bash\nexport MY_VAR=from_type\n")
        (mock_repo / "env_type.sh").chmod(0o755)

        test_script = mock_repo / "tests" / "run_test.py"
        test_script.write_text(
            "#!/usr/bin/env python3\n"
            "import os\n"
            "val = os.environ.get('MY_VAR', 'NOT_SET')\n"
            "print(f'accuracy: 0.99')\n"
            "print(f'MY_VAR={val}')\n"
            "if val == 'from_type':\n"
            "    print('accuracy PASS')\n"
            "else:\n"
            "    import sys; sys.exit(1)\n"
        )

        sample_config["working_dir"] = str(mock_repo)
        sample_config["source_env"] = str(mock_repo / "env_top.sh")
        sample_config["tasks"]["accuracy"]["source_env"] = str(mock_repo / "env_type.sh")
        result = run_test(sample_config, test_type="accuracy")
        assert result.success is True
        assert "MY_VAR=from_type" in result.stdout

    def test_source_env_relative_path_raises(self, mock_repo, sample_config):
        """Relative source_env path raises ConfigError."""
        from forge.config import ConfigError
        test_script = mock_repo / "tests" / "run_test.py"
        test_script.write_text("#!/usr/bin/env python3\nprint('accuracy: 0.99')\nprint('accuracy PASS')\n")
        sample_config["working_dir"] = str(mock_repo)
        sample_config["source_env"] = "set_env.sh"
        with pytest.raises(ConfigError, match="absolute path"):
            run_test(sample_config, test_type="accuracy")


class TestWorkingDirOverride:
    def test_extra_vars_overrides_working_dir(self, tmp_path, sample_config):
        """--arg working_dir=/new/path should override config working_dir."""
        old_repo = tmp_path / "old_repo"
        old_repo.mkdir()
        (old_repo / "tests").mkdir()
        (old_repo / "tests" / "run_test.py").write_text("#!/usr/bin/env python3\nprint('accuracy: 0.99')\nprint('accuracy PASS')\n")

        new_repo = tmp_path / "new_repo"
        new_repo.mkdir()
        (new_repo / "tests").mkdir()
        test_script = new_repo / "tests" / "run_test.py"
        test_script.write_text("#!/usr/bin/env python3\nprint('accuracy: 0.99')\nprint('accuracy PASS')\n")

        sample_config["working_dir"] = str(old_repo)
        result = run_test(sample_config, test_type="accuracy", extra_vars={"working_dir": str(new_repo)})
        assert result.success is True

    def test_extra_vars_repo_root_resolves_working_dir(self, tmp_path, sample_config):
        """--arg repo_root=/new/path should resolve working_dir={repo_root}."""
        old_repo = tmp_path / "old_repo"
        old_repo.mkdir()
        (old_repo / "tests").mkdir()
        (old_repo / "tests" / "run_test.py").write_text("#!/usr/bin/env python3\nprint('accuracy: 0.99')\nprint('accuracy PASS')\n")

        new_repo = tmp_path / "new_repo"
        new_repo.mkdir()
        (new_repo / "tests").mkdir()
        test_script = new_repo / "tests" / "run_test.py"
        test_script.write_text("#!/usr/bin/env python3\nprint('accuracy: 0.99')\nprint('accuracy PASS')\n")

        sample_config["working_dir"] = "{repo_root}"
        sample_config["vars"] = {"repo_root": str(old_repo)}
        result = run_test(sample_config, test_type="accuracy", extra_vars={"repo_root": str(new_repo)})
        assert result.success is True


class TestConfigVars:
    def test_config_vars_in_test(self, mock_repo, sample_config):
        """Config vars are available in test placeholders."""
        test_script = mock_repo / "tests" / "run_test.py"
        test_script.write_text("#!/usr/bin/env python3\nimport sys\nprint(f'case: {sys.argv[1]}')\nprint('accuracy: 0.99')\nprint('accuracy PASS')\n")
        sample_config["working_dir"] = str(mock_repo)
        sample_config["vars"] = {"my_case": "case_001"}
        sample_config["tasks"]["accuracy"]["args"] = ["{my_case}"]
        result = run_test(sample_config, test_type="accuracy")
        assert result.success is True
        assert "case: case_001" in result.stdout

    def test_cli_overrides_config_vars_in_test(self, mock_repo, sample_config):
        """CLI extra_vars override config vars in tests."""
        test_script = mock_repo / "tests" / "run_test.py"
        test_script.write_text("#!/usr/bin/env python3\nimport sys\nprint(f'case: {sys.argv[1]}')\nprint('accuracy: 0.99')\nprint('accuracy PASS')\n")
        sample_config["working_dir"] = str(mock_repo)
        sample_config["vars"] = {"my_case": "case_001"}
        sample_config["tasks"]["accuracy"]["args"] = ["{my_case}"]
        result = run_test(sample_config, test_type="accuracy", extra_vars={"my_case": "case_999"})
        assert result.success is True
        assert "case: case_999" in result.stdout


class TestRunTestTasksFormat:
    """Tests for run_test() using new tasks field."""

    def test_run_test_from_tasks_field(self, mock_repo, sample_config_tasks):
        """run_test() finds test config in tasks.accuracy."""
        test_script = mock_repo / "tests" / "run_test.py"
        test_script.write_text("#!/usr/bin/env python3\nprint('accuracy: 0.99')\nprint('PASS')\n")
        sample_config_tasks["working_dir"] = str(mock_repo)
        result = run_test(sample_config_tasks, test_type="accuracy")
        assert result.success

    def test_run_test_legacy_tests_field_deprecated(self, mock_repo, sample_config_legacy):
        """run_test() still works with tests field but emits warning."""
        import warnings
        test_script = mock_repo / "tests" / "run_test.py"
        test_script.write_text("#!/usr/bin/env python3\nprint('accuracy: 0.99')\nprint('PASS')\n")
        # Use legacy sample_config_legacy which has tests field
        sample_config_legacy["working_dir"] = str(mock_repo)
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            result = run_test(sample_config_legacy, "accuracy")
            assert len(w) >= 1
            assert "forge migrate" in str(w[0].message).lower()
        assert result.success

    def test_run_test_unknown_type_raises(self, sample_config_tasks):
        """run_test() raises ValueError for unknown test_type."""
        with pytest.raises(ValueError, match="not found in tasks"):
            run_test(sample_config_tasks, test_type="unknown")


@pytest.fixture
def sample_config_tasks():
    """Config with new tasks format."""
    return {
        "name": "test_repo",
        "working_dir": "/tmp/test_repo",
        "tasks": {
            "build": {"command": "bash build.sh"},
            "accuracy": {
                "command": "python3 tests/run_test.py",
                "success_pattern": "PASS",
            },
        },
    }
