"""Tests for the shared task utilities."""

import glob
import logging
import os
import re
import time
from dataclasses import dataclass, field
from unittest.mock import patch, MagicMock

import pytest

from forge.task import (
    resolve_working_dir,
    make_timestamp,
    get_head_commit,
    process_capture,
    get_skip_patterns,
    check_skip_files,
    check_artifacts,
    resolve_glob_vars,
    merge_env,
    _analyze_outliers_iqr,
    extract_results,
    resolve_source_env,
    TaskRunner,
    TaskResult,
    StepResult,
)
from forge.config import ConfigError
from forge.executor import CommandResult


class TestResolveWorkingDir:
    def test_relative(self):
        assert resolve_working_dir("/repo", "src") == os.path.normpath("/repo/src")

    def test_dot(self):
        assert resolve_working_dir("/repo", ".") == os.path.normpath("/repo")

    def test_nested(self):
        assert resolve_working_dir("/repo", "a/b/c") == os.path.normpath("/repo/a/b/c")


class TestMakeTimestamp:
    def test_format(self):
        ts = make_timestamp()
        # Should match YYYYMMDD_HHMMSS
        assert re.match(r"\d{8}_\d{6}", ts)


class TestGetHeadCommit:
    def test_in_git_repo(self, tmp_path):
        import subprocess
        repo = tmp_path / "repo"
        repo.mkdir()
        subprocess.run(["git", "init"], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "config", "user.email", "t@t.com"], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "config", "user.name", "T"], cwd=str(repo), capture_output=True)
        (repo / "f.txt").write_text("x")
        subprocess.run(["git", "add", "."], cwd=str(repo), capture_output=True)
        subprocess.run(["git", "commit", "-m", "init"], cwd=str(repo), capture_output=True)
        commit = get_head_commit(str(repo))
        assert commit is not None
        assert len(commit) == 40

    def test_not_git_repo(self, tmp_path):
        assert get_head_commit(str(tmp_path)) is None


class TestProcessCapture:
    def test_captures_value(self, capsys):
        variables = {}
        process_capture({"ver": r"version: ([0-9.]+)"}, "version: 2.5\n", variables)
        assert variables["ver"] == "2.5"

    def test_no_match_logs_warning(self, caplog):
        variables = {}
        with caplog.at_level(logging.WARNING):
            process_capture({"ver": r"version: ([0-9.]+)"}, "no match here\n", variables)
        assert "ver" not in variables
        assert "did not match" in caplog.text


class TestGetSkipPatterns:
    def test_skip_if_exists_string(self):
        step = {"skip_if_exists": "output/result.bin"}
        patterns = get_skip_patterns(step, {})
        assert patterns == ["output/result.bin"]

    def test_skip_if_exists_list(self):
        step = {"skip_if_exists": ["a.bin", "b.bin"]}
        patterns = get_skip_patterns(step, {})
        assert patterns == ["a.bin", "b.bin"]

    def test_skip_if_artifacts_exist(self):
        step = {"skip_if_artifacts_exist": True, "artifacts": ["lib.so"]}
        patterns = get_skip_patterns(step, {})
        assert patterns == ["lib.so"]

    def test_no_skip(self):
        step = {"command": "echo hi"}
        patterns = get_skip_patterns(step, {})
        assert patterns == []

    def test_placeholder_substitution(self):
        step = {"skip_if_exists": "{working_dir}/out.bin"}
        patterns = get_skip_patterns(step, {"working_dir": "/myrepo"})
        assert patterns == ["/myrepo/out.bin"]


class TestCheckSkipFiles:
    def test_all_found(self, tmp_path):
        (tmp_path / "a.txt").write_text("data")
        found, details = check_skip_files(str(tmp_path), ["a.txt"])
        assert found is True

    def test_not_found(self, tmp_path):
        found, details = check_skip_files(str(tmp_path), ["missing.txt"])
        assert found is False
        assert any("not found" in d for d in details)

    def test_empty_file(self, tmp_path):
        (tmp_path / "empty.txt").write_text("")
        found, details = check_skip_files(str(tmp_path), ["empty.txt"])
        assert found is False
        assert any("empty" in d for d in details)


class TestCheckArtifacts:
    def test_artifact_exists_and_fresh(self, tmp_path):
        start = time.time()
        (tmp_path / "out.bin").write_text("data")
        errors = check_artifacts(str(tmp_path), ["out.bin"], start)
        assert errors == []

    def test_artifact_missing(self, tmp_path):
        errors = check_artifacts(str(tmp_path), ["missing.bin"], time.time())
        assert any("not found" in e for e in errors)

    def test_artifact_empty(self, tmp_path):
        (tmp_path / "empty.bin").write_text("")
        errors = check_artifacts(str(tmp_path), ["empty.bin"], time.time() - 10)
        assert any("empty" in e for e in errors)

    def test_artifact_stale(self, tmp_path):
        f = tmp_path / "old.bin"
        f.write_text("data")
        old_time = time.time() - 3600
        os.utime(str(f), (old_time, old_time))
        errors = check_artifacts(str(tmp_path), ["old.bin"], time.time())
        assert any("stale" in e for e in errors)


class TestResolveGlobVars:
    def test_resolves_glob_to_actual_path(self, tmp_path):
        (tmp_path / "output").mkdir()
        (tmp_path / "output" / "CANN-omni_custom_ops--linux.aarch64.run").write_text("data")
        variables = {"build_artifact": "output/CANN-*.run"}
        resolved = resolve_glob_vars(variables, str(tmp_path))
        assert resolved["build_artifact"] == "output/CANN-omni_custom_ops--linux.aarch64.run"

    def test_picks_most_recent_match(self, tmp_path):
        (tmp_path / "output").mkdir()
        f1 = tmp_path / "output" / "CANN-old--linux.aarch64.run"
        f2 = tmp_path / "output" / "CANN-new--linux.aarch64.run"
        f1.write_text("old")
        f2.write_text("new")
        old_time = time.time() - 3600
        os.utime(str(f1), (old_time, old_time))
        variables = {"build_artifact": "output/CANN-*.run"}
        resolved = resolve_glob_vars(variables, str(tmp_path))
        assert os.path.basename(resolved["build_artifact"]) == "CANN-new--linux.aarch64.run"

    def test_respects_build_start_time(self, tmp_path):
        (tmp_path / "output").mkdir()
        f1 = tmp_path / "output" / "CANN-old--linux.aarch64.run"
        f2 = tmp_path / "output" / "CANN-new--linux.aarch64.run"
        f1.write_text("old")
        f2.write_text("new")
        build_start = time.time()
        old_time = build_start - 3600
        os.utime(str(f1), (old_time, old_time))
        variables = {"build_artifact": "output/CANN-*.run"}
        resolved = resolve_glob_vars(variables, str(tmp_path), build_start)
        assert os.path.basename(resolved["build_artifact"]) == "CANN-new--linux.aarch64.run"

    def test_skips_stale_files_when_start_time_given(self, tmp_path):
        (tmp_path / "output").mkdir()
        f1 = tmp_path / "output" / "CANN-old--linux.aarch64.run"
        f1.write_text("old")
        build_start = time.time()
        old_time = build_start - 3600
        os.utime(str(f1), (old_time, old_time))
        variables = {"build_artifact": "output/CANN-*.run"}
        resolved = resolve_glob_vars(variables, str(tmp_path), build_start)
        assert "build_artifact" not in resolved

    def test_preserves_relative_path(self, tmp_path):
        (tmp_path / "output").mkdir()
        (tmp_path / "output" / "CANN-foo--linux.aarch64.run").write_text("data")
        variables = {"build_artifact": "output/CANN-*.run"}
        resolved = resolve_glob_vars(variables, str(tmp_path))
        assert not os.path.isabs(resolved["build_artifact"])

    def test_preserves_absolute_path(self, tmp_path):
        (tmp_path / "output").mkdir()
        (tmp_path / "output" / "CANN-foo--linux.aarch64.run").write_text("data")
        abs_pattern = str(tmp_path / "output" / "CANN-*.run")
        variables = {"build_artifact": abs_pattern}
        resolved = resolve_glob_vars(variables, str(tmp_path))
        assert os.path.isabs(resolved["build_artifact"])

    def test_no_glob_no_change(self, tmp_path):
        variables = {"build_artifact": "output/fixed.run"}
        resolved = resolve_glob_vars(variables, str(tmp_path))
        assert resolved == {}

    def test_no_match_no_change(self, tmp_path):
        variables = {"build_artifact": "output/CANN-*.run"}
        resolved = resolve_glob_vars(variables, str(tmp_path))
        assert resolved == {}


class TestMergeEnv:
    def test_both_none(self):
        assert merge_env(None, None) is None

    def test_sourced_only(self):
        assert merge_env({"A": "1"}, None) == {"A": "1"}

    def test_step_only(self):
        assert merge_env(None, {"B": "2"}) == {"B": "2"}

    def test_step_overrides_sourced(self):
        result = merge_env({"A": "1", "B": "2"}, {"B": "3"})
        assert result == {"A": "1", "B": "3"}


class TestRepeatOutlierHelpers:
    def test_analyze_outliers_iqr_marks_extreme_value(self):
        analysis = _analyze_outliers_iqr(
            "value",
            [100.0, 101.0, 102.0, 145.0],
            {"method": "iqr", "max_outlier_ratio": 0.5, "iqr_multiplier": 1.5, "min_samples": 4},
        )
        assert analysis.outliers == [145.0]
        assert analysis.failure is False
        assert analysis.filtered_avg == pytest.approx(101.0)

    def test_analyze_outliers_iqr_skips_small_sample_sets(self):
        analysis = _analyze_outliers_iqr(
            "value",
            [10.0, 11.0, 12.0],
            {"method": "iqr", "max_outlier_ratio": 0.1, "iqr_multiplier": 1.5, "min_samples": 4},
        )
        assert analysis.skipped is True
        assert analysis.filtered_avg == pytest.approx(11.0)

    def test_analyze_outliers_iqr_fails_when_ratio_exceeds_threshold(self):
        analysis = _analyze_outliers_iqr(
            "value",
            [100.0, 101.0, 102.0, 145.0],
            {"method": "iqr", "max_outlier_ratio": 0.1, "iqr_multiplier": 1.5, "min_samples": 4},
        )
        assert analysis.outliers == [145.0]
        assert analysis.outlier_ratio == pytest.approx(0.25)
        assert analysis.failure is True

    @pytest.mark.parametrize("cfg_key", ["max_outlier_ratio", "iqr_multiplier", "min_samples"])
    def test_analyze_outliers_iqr_null_overrides_fall_back_to_defaults(self, cfg_key):
        cfg = {"method": "iqr", "max_outlier_ratio": None, "iqr_multiplier": None, "min_samples": None}
        cfg[cfg_key] = None
        analysis = _analyze_outliers_iqr(
            "value",
            [100.0, 101.0, 102.0, 103.0, 104.0, 105.0, 106.0, 107.0, 108.0, 145.0],
            cfg,
        )
        assert analysis.outliers == [145.0]
        assert analysis.filtered_avg == pytest.approx(104.0)
        assert analysis.failure is False


# ============================================================
# Task 2 Tests: TaskRunner base class
# ============================================================

from forge.task import TaskRunner, StepResult


class TestTaskRunnerSingle:
    """Test TaskRunner._run_single via the base class."""

    def test_single_command_success(self, mock_repo):
        """Base TaskRunner runs a single command and returns StepResult."""
        runner = TaskRunner()
        task_cfg = {"command": "bash build.sh", "timeout": 30}
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert isinstance(result, StepResult)
        assert result.success is True
        assert "Build succeeded" in result.stdout

    def test_single_command_failure(self, mock_repo):
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\nexit 1\n")
        runner = TaskRunner()
        task_cfg = {"command": "bash build.sh", "timeout": 30}
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is False

    def test_single_command_timeout(self, mock_repo):
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\nsleep 10\n")
        runner = TaskRunner()
        task_cfg = {"command": "bash build.sh", "timeout": 1}
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is False
        assert result.timed_out is True

    def test_single_with_success_pattern(self, mock_repo):
        runner = TaskRunner()
        task_cfg = {"command": "bash build.sh", "success_pattern": "Build succeeded", "timeout": 30}
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is True

    def test_single_success_pattern_not_matched(self, mock_repo):
        runner = TaskRunner()
        task_cfg = {"command": "bash build.sh", "success_pattern": "NOPE", "timeout": 30}
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is False

    def test_single_with_env(self, mock_repo):
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\necho MY_VAR=$MY_VAR\n")
        runner = TaskRunner()
        task_cfg = {"command": "bash build.sh", "timeout": 30, "env": {"MY_VAR": "hello"}}
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert "MY_VAR=hello" in result.stdout

    def test_single_with_args(self, mock_repo):
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\necho \"args: $@\"\n")
        runner = TaskRunner()
        task_cfg = {"command": "bash build.sh", "args": ["--flag", "val"], "timeout": 30}
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert "args: --flag val" in result.stdout

    def test_step_name_ignored_for_single(self, mock_repo, capsys):
        runner = TaskRunner()
        task_cfg = {"command": "bash build.sh", "timeout": 30}
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables, step_name="compile")
        assert result.success is True
        captured = capsys.readouterr()
        assert "Warning" in captured.err

    def test_single_working_dir_placeholder_substitution(self, mock_repo):
        """working_dir with placeholder should be resolved before use."""
        subdir = mock_repo / "sub"
        subdir.mkdir()
        (subdir / "run.sh").write_text("#!/bin/bash\necho 'hello from sub'\n")
        (subdir / "run.sh").chmod(0o755)
        runner = TaskRunner()
        task_cfg = {"command": "bash run.sh", "working_dir": "{my_subdir}", "timeout": 30}
        variables = {"my_subdir": "sub"}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is True
        assert "hello from sub" in result.stdout


class TestTaskRunnerMultiStep:
    """Test TaskRunner._run_multi_step via the base class."""

    def test_multi_step_all_pass(self, mock_repo):
        (mock_repo / "install.sh").write_text("#!/bin/bash\necho 'Install done'\n")
        (mock_repo / "install.sh").chmod(0o755)
        runner = TaskRunner()
        task_cfg = {
            "steps": [
                {"name": "compile", "command": "bash build.sh"},
                {"name": "install", "command": "bash install.sh"},
            ]
        }
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is True

    def test_multi_step_first_fails(self, mock_repo):
        (mock_repo / "build.sh").write_text("#!/bin/bash\nexit 1\n")
        (mock_repo / "install.sh").write_text("#!/bin/bash\necho 'should not run'\n")
        (mock_repo / "install.sh").chmod(0o755)
        runner = TaskRunner()
        task_cfg = {
            "steps": [
                {"name": "compile", "command": "bash build.sh"},
                {"name": "install", "command": "bash install.sh"},
            ]
        }
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is False
        assert "should not run" not in result.stdout

    def test_multi_step_skip(self, mock_repo):
        (mock_repo / "output.bin").write_text("data")
        (mock_repo / "build.sh").write_text("#!/bin/bash\nexit 1\n")  # would fail if not skipped
        (mock_repo / "install.sh").write_text("#!/bin/bash\necho 'Install done'\n")
        (mock_repo / "install.sh").chmod(0o755)
        runner = TaskRunner()
        task_cfg = {
            "steps": [
                {"name": "compile", "command": "bash build.sh",
                 "skip_if_exists": "output.bin"},
                {"name": "install", "command": "bash install.sh"},
            ]
        }
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is True

    def test_multi_step_capture(self, mock_repo):
        (mock_repo / "get_ver.sh").write_text("#!/bin/bash\necho 'version: 2.5'\n")
        (mock_repo / "get_ver.sh").chmod(0o755)
        (mock_repo / "use_ver.sh").write_text("#!/bin/bash\necho \"using $1\"\n")
        (mock_repo / "use_ver.sh").chmod(0o755)
        runner = TaskRunner()
        task_cfg = {
            "steps": [
                {"name": "get ver", "command": "bash get_ver.sh",
                 "capture": {"my_ver": r"version: ([0-9.]+)"}},
                {"name": "use ver", "command": "bash use_ver.sh",
                 "args": ["{my_ver}"]},
            ]
        }
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is True
        assert "using 2.5" in result.stdout

    def test_multi_step_ignore_failure(self, mock_repo):
        (mock_repo / "build.sh").write_text("#!/bin/bash\nexit 1\n")
        (mock_repo / "install.sh").write_text("#!/bin/bash\necho 'Install done'\n")
        (mock_repo / "install.sh").chmod(0o755)
        runner = TaskRunner()
        task_cfg = {
            "steps": [
                {"name": "compile", "command": "bash build.sh", "ignore_failure": True},
                {"name": "install", "command": "bash install.sh"},
            ]
        }
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is True

    def test_step_name_filter(self, mock_repo):
        (mock_repo / "install.sh").write_text("#!/bin/bash\necho 'Install done'\n")
        (mock_repo / "install.sh").chmod(0o755)
        runner = TaskRunner()
        task_cfg = {
            "steps": [
                {"name": "compile", "command": "bash build.sh"},
                {"name": "install", "command": "bash install.sh"},
            ]
        }
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables, step_name="install")
        assert result.success is True
        assert "Install done" in result.stdout
        assert "Build succeeded" not in result.stdout

    def test_step_name_not_found(self, mock_repo):
        runner = TaskRunner()
        task_cfg = {"steps": [{"name": "compile", "command": "bash build.sh"}]}
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables, step_name="nope")
        assert result.success is False

    def test_default_timeout_used(self, mock_repo):
        """Base class default_timeout = 600."""
        runner = TaskRunner()
        assert runner.default_timeout == 600

    def test_multi_step_task_level_working_dir_placeholder(self, mock_repo):
        """Task-level working_dir placeholder should be resolved for multi-step default."""
        subdir = mock_repo / "mydir"
        subdir.mkdir()
        (subdir / "hello.sh").write_text("#!/bin/bash\necho 'from mydir'\n")
        (subdir / "hello.sh").chmod(0o755)
        runner = TaskRunner()
        task_cfg = {
            "working_dir": "{target_dir}",
            "steps": [
                {"name": "greet", "command": "bash hello.sh"},
            ]
        }
        variables = {"target_dir": "mydir"}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is True
        assert "from mydir" in result.stdout

    def test_multi_step_step_level_working_dir_placeholder(self, mock_repo):
        """Step-level working_dir placeholder should be resolved."""
        subdir = mock_repo / "stepdir"
        subdir.mkdir()
        (subdir / "work.sh").write_text("#!/bin/bash\necho 'from stepdir'\n")
        (subdir / "work.sh").chmod(0o755)
        runner = TaskRunner()
        task_cfg = {
            "steps": [
                {"name": "work", "command": "bash work.sh", "working_dir": "{step_dir}"},
            ]
        }
        variables = {"step_dir": "stepdir"}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is True
        assert "from stepdir" in result.stdout


class TestTaskRunnerSubclass:
    """Test that _post_step and _make_result hooks work."""

    def test_post_step_called(self, mock_repo):
        @dataclass
        class CustomResult:
            success: bool
            stdout: str
            extra: str = ""

        class CustomRunner(TaskRunner):
            def _post_step(self, step_cfg, cmd_result, working_dir, variables, start_time, success):
                if success:
                    return {"extra": "custom_data"}
                return None

            def _make_result(self, success, stdout, stderr, timed_out, post_data):
                return CustomResult(success=success, stdout=stdout, extra=post_data.get("extra", ""))

        runner = CustomRunner()
        task_cfg = {"command": "bash build.sh", "timeout": 30}
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert isinstance(result, CustomResult)
        assert result.extra == "custom_data"

    def test_post_step_success_override(self, mock_repo):
        class FailRunner(TaskRunner):
            def _post_step(self, step_cfg, cmd_result, working_dir, variables, start_time, success):
                return {"success_override": False}

        runner = FailRunner()
        task_cfg = {"command": "bash build.sh", "timeout": 30}
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is False  # overridden even though command succeeded

    def test_post_step_list_accumulation(self, mock_repo):
        """List values in post_data are extended across steps, not overwritten."""
        (mock_repo / "s2.sh").write_text("#!/bin/bash\necho 'ok'\n")
        (mock_repo / "s2.sh").chmod(0o755)

        class ListRunner(TaskRunner):
            def _post_step(self, step_cfg, cmd_result, working_dir, variables, start_time, success):
                return {"errors": [step_cfg.get("name", "?")]}

            def _make_result(self, success, stdout, stderr, timed_out, post_data):
                result = StepResult(success=success, stdout=stdout, stderr=stderr, timed_out=timed_out)
                result.errors = post_data.get("errors", [])
                return result

        runner = ListRunner()
        task_cfg = {
            "steps": [
                {"name": "s1", "command": "bash build.sh"},
                {"name": "s2", "command": "bash s2.sh"},
            ]
        }
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.errors == ["s1", "s2"]  # accumulated, not overwritten


class TestTaskRunnerArtifacts:
    """Test artifact checking built into TaskRunner._post_step."""

    def test_artifact_check_in_base_runner(self, mock_repo):
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\necho 'ok'\nmkdir -p output\necho 'data' > output/lib.so\n")
        runner = TaskRunner()
        task_cfg = {"command": "bash build.sh", "artifacts": ["output/lib.so"], "timeout": 30}
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is True
        assert result.artifact_errors == []

    def test_artifact_missing_fails(self, mock_repo):
        runner = TaskRunner()
        task_cfg = {"command": "bash build.sh", "artifacts": ["output/missing.so"], "timeout": 30}
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is False
        assert any("not found" in e for e in result.artifact_errors)

    def test_glob_artifact_resolves_variable(self, mock_repo):
        """When artifact pattern uses glob, the matching variable is resolved
        to the actual file path so subsequent steps can use it."""
        build_sh = mock_repo / "build.sh"
        build_sh.write_text(
            "#!/bin/bash\necho 'ok'\nmkdir -p output\n"
            "echo 'data' > output/CANN-omni_custom_ops--linux.aarch64.run\n"
        )
        (mock_repo / "install.sh").write_text("#!/bin/bash\necho 'installing'\n")
        (mock_repo / "install.sh").chmod(0o755)
        runner = TaskRunner()
        task_cfg = {
            "steps": [
                {
                    "name": "compile",
                    "command": "bash build.sh",
                    "artifacts": ["{build_artifact}"],
                },
                {
                    "name": "install",
                    "command": "bash install.sh",
                    "args": ["{build_artifact}"],
                },
            ]
        }
        variables = {"working_dir": str(mock_repo), "build_artifact": "output/CANN-*.run"}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is True
        # The variable should have been resolved to the actual filename
        assert "CANN-omni_custom_ops--linux.aarch64.run" in variables["build_artifact"]

    def test_glob_artifact_not_resolved_on_failure(self, mock_repo):
        """If artifact check fails, glob variables should NOT be modified."""
        runner = TaskRunner()
        task_cfg = {
            "command": "bash build.sh",
            "artifacts": ["{build_artifact}"],
            "timeout": 30,
        }
        variables = {"working_dir": str(mock_repo), "build_artifact": "output/CANN-*.run"}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is False
        # Variable should remain unchanged
        assert variables["build_artifact"] == "output/CANN-*.run"


class TestTaskRunnerResultExtraction:
    """Test result extraction built into TaskRunner._post_step."""

    def test_stdout_result_in_base_runner(self, mock_repo):
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\necho 'accuracy: 0.99'\n")
        runner = TaskRunner()
        task_cfg = {
            "command": "bash build.sh", "timeout": 30,
            "result": {"type": "stdout", "pattern": "accuracy: ([0-9.]+)"}
        }
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is True
        assert result.result_values == {"value": 0.99}

    def test_both_artifacts_and_result(self, mock_repo):
        """A single task can have both artifacts and result extraction."""
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\necho 'throughput: 1234'\nmkdir -p output\necho 'data' > output/report.html\n")
        runner = TaskRunner()
        task_cfg = {
            "command": "bash build.sh", "timeout": 30,
            "artifacts": ["output/report.html"],
            "result": {"type": "stdout", "pattern": "throughput: ([0-9.]+)"}
        }
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is True
        assert result.artifact_errors == []
        assert result.result_values == {"value": 1234.0}

    def test_task_result_has_all_fields(self, mock_repo):
        """TaskResult has artifact_errors and result_values."""
        runner = TaskRunner()
        task_cfg = {"command": "bash build.sh", "timeout": 30}
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert isinstance(result, TaskResult)
        assert hasattr(result, "artifact_errors")
        assert hasattr(result, "result_values")

    def test_step_result_is_task_result(self):
        """StepResult is an alias for TaskResult."""
        assert StepResult is TaskResult


class TestSingleTaskRepeat:
    """Task 2: single-task repeat execution and result_values aggregation."""

    @patch("forge.task.run_command")
    def test_single_task_repeat_aggregates_result_values(self, mock_run_command):
        mock_run_command.side_effect = [
            MagicMock(returncode=0, stdout="score=1\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=3\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
        ]
        runner = TaskRunner()
        task_cfg = {
            "command": "python bench.py",
            "repeat": 2,
            "repeat_agg": "avg",
            "result": {"type": "stdout", "pattern": r"score=([0-9.]+)"},
        }
        result = runner.run(task_cfg, "/tmp", "repo", "bench", {"working_dir": "/tmp"})
        assert result.success is True
        assert result.result_values == {"value": 2.0}
        assert mock_run_command.call_count == 2

    @patch("forge.task.run_command")
    def test_single_task_repeat_stops_on_failure(self, mock_run_command):
        mock_run_command.side_effect = [
            MagicMock(returncode=0, stdout="score=1\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=1, stdout="", stderr="boom", timed_out=False, is_successful=lambda success_pattern=None: False),
        ]
        runner = TaskRunner()
        task_cfg = {"command": "python bench.py", "repeat": 3}
        result = runner.run(task_cfg, "/tmp", "repo", "bench", {"working_dir": "/tmp"})
        assert result.success is False
        assert result.stderr == "boom"
        assert mock_run_command.call_count == 2

    @patch("forge.task.run_command")
    def test_single_task_repeat_no_result_values_returns_last(self, mock_run_command):
        mock_run_command.side_effect = [
            MagicMock(returncode=0, stdout="run1\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="run2\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
        ]
        runner = TaskRunner()
        task_cfg = {"command": "python bench.py", "repeat": 2}
        result = runner.run(task_cfg, "/tmp", "repo", "bench", {"working_dir": "/tmp"})
        assert result.success is True
        assert result.result_values is None
        assert "run2" in result.stdout

    @patch("forge.task.run_command")
    def test_single_task_repeat_max_aggregation(self, mock_run_command):
        mock_run_command.side_effect = [
            MagicMock(returncode=0, stdout="score=5\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=9\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=3\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
        ]
        runner = TaskRunner()
        task_cfg = {
            "command": "python bench.py",
            "repeat": 3,
            "repeat_agg": "max",
            "result": {"type": "stdout", "pattern": r"score=([0-9.]+)"},
        }
        result = runner.run(task_cfg, "/tmp", "repo", "bench", {"working_dir": "/tmp"})
        assert result.success is True
        assert result.result_values == {"value": 9.0}

    @patch("forge.task.run_command")
    def test_single_task_repeat_avg_without_outliers_filters_result_values(self, mock_run_command, capsys):
        mock_run_command.side_effect = [
            MagicMock(returncode=0, stdout="score=100\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=101\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=102\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=145\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
        ]
        runner = TaskRunner()
        task_cfg = {
            "command": "python bench.py",
            "repeat": 4,
            "repeat_agg": "avg_without_outliers",
            "outlier_detection": {"max_outlier_ratio": 0.3, "min_samples": 4},
            "result": {"type": "stdout", "pattern": r"score=([0-9.]+)"},
        }
        result = runner.run(task_cfg, "/tmp", "repo", "bench", {"working_dir": "/tmp"})
        assert result.success is True
        assert result.result_values == {"value": 101.0}
        captured = capsys.readouterr()
        assert "filtered_avg=101.00" in captured.out
        assert "outliers=1" in captured.out

    @patch("forge.task.run_command")
    def test_single_task_repeat_avg_without_outliers_preserves_raw_samples(self, mock_run_command):
        mock_run_command.side_effect = [
            MagicMock(returncode=0, stdout="score=100\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=101\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=102\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=145\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
        ]
        runner = TaskRunner()
        task_cfg = {
            "command": "python bench.py",
            "repeat": 4,
            "repeat_agg": "avg_without_outliers",
            "outlier_detection": {"max_outlier_ratio": 0.3, "min_samples": 4},
            "result": {"type": "stdout", "pattern": r"score=([0-9.]+)"},
        }
        result = runner.run(task_cfg, "/tmp", "repo", "bench", {"working_dir": "/tmp"})
        assert result.success is True
        assert result.result_values == {"value": 101.0}
        assert result.raw_result_samples == {"value": [100.0, 101.0, 102.0, 145.0]}
        assert result.outlier_analyses is not None
        assert result.outlier_analyses["value"]["outliers"] == [145.0]
        assert result.outlier_analyses["value"]["filtered_values"] == [100.0, 101.0, 102.0]

    @patch("forge.task.run_command")
    def test_single_task_repeat_avg_without_outliers_fails_when_ratio_exceeded(self, mock_run_command, capsys):
        mock_run_command.side_effect = [
            MagicMock(returncode=0, stdout="score=100\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=101\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=102\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=145\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
        ]
        runner = TaskRunner()
        task_cfg = {
            "command": "python bench.py",
            "repeat": 4,
            "repeat_agg": "avg_without_outliers",
            "outlier_detection": {"max_outlier_ratio": 0.1, "min_samples": 4},
            "result": {"type": "stdout", "pattern": r"score=([0-9.]+)"},
        }
        result = runner.run(task_cfg, "/tmp", "repo", "bench", {"working_dir": "/tmp"})
        assert result.success is False
        captured = capsys.readouterr()
        assert "outlier failure" in captured.out.lower()
        assert "filtered_avg" in captured.out

    @patch("forge.task.run_command")
    def test_single_task_repeat_avg_without_outliers_failure_summary_is_returned(self, mock_run_command):
        mock_run_command.side_effect = [
            MagicMock(returncode=0, stdout="score=100\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=101\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=102\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=145\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
        ]
        runner = TaskRunner()
        task_cfg = {
            "command": "python bench.py",
            "repeat": 4,
            "repeat_agg": "avg_without_outliers",
            "outlier_detection": {"max_outlier_ratio": 0.1, "min_samples": 4},
            "result": {"type": "stdout", "pattern": r"score=([0-9.]+)"},
        }
        result = runner.run(task_cfg, "/tmp", "repo", "bench", {"working_dir": "/tmp"})
        assert result.success is False
        assert "Outlier failure" in result.stderr
        assert "filtered_avg=" in result.stderr


class TestMultiStepRepeat:
    """Task 3: step-level repeat and nested (task+step) repeat aggregation."""

    @patch("forge.task.run_command")
    def test_multi_step_repeat_aggregates_step_result_values(self, mock_run_command):
        mock_run_command.side_effect = [
            MagicMock(returncode=0, stdout="seed=1\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="latency=4\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="latency=6\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
        ]
        runner = TaskRunner()
        task_cfg = {
            "steps": [
                {"name": "prepare", "command": "python prep.py", "capture": {"seed": r"seed=(\d+)"}},
                {
                    "name": "bench",
                    "command": "python bench.py {seed}",
                    "repeat": 2,
                    "repeat_agg": "max",
                    "result": {"type": "stdout", "pattern": r"latency=([0-9.]+)"},
                },
            ]
        }
        variables = {"working_dir": "/tmp"}
        result = runner.run(task_cfg, "/tmp", "repo", "pipeline", variables)
        assert result.success is True
        assert result.result_values == {"value": 6.0}
        assert variables["seed"] == "1"

    @patch("forge.task.run_command")
    def test_task_repeat_and_step_repeat_stack(self, mock_run_command):
        mock_run_command.side_effect = [
            MagicMock(returncode=0, stdout="latency=1\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="latency=2\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="latency=3\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="latency=4\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
        ]
        runner = TaskRunner()
        task_cfg = {
            "repeat": 2,
            "steps": [
                {
                    "name": "bench",
                    "command": "python bench.py",
                    "repeat": 2,
                    "result": {"type": "stdout", "pattern": r"latency=([0-9.]+)"},
                }
            ],
        }
        result = runner.run(task_cfg, "/tmp", "repo", "pipeline", {"working_dir": "/tmp"})
        assert result.success is True
        assert result.result_values == {"value": 2.5}
        assert mock_run_command.call_count == 4

    @patch("forge.task.run_command")
    def test_repeated_capture_latest_value_used(self, mock_run_command):
        """Repeated step capture: later value overwrites earlier; next step sees latest."""
        mock_run_command.side_effect = [
            MagicMock(returncode=0, stdout="token=aaa\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="token=bbb\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="used=bbb\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
        ]
        runner = TaskRunner()
        task_cfg = {
            "steps": [
                {
                    "name": "gen",
                    "command": "python gen.py",
                    "repeat": 2,
                    "capture": {"token": r"token=(\w+)"},
                },
                {
                    "name": "use",
                    "command": "python use.py {token}",
                },
            ]
        }
        variables = {"working_dir": "/tmp"}
        result = runner.run(task_cfg, "/tmp", "repo", "pipeline", variables)
        assert result.success is True
        assert variables["token"] == "bbb"

    @patch("forge.task.run_command")
    def test_repeated_step_failure_stops_immediately(self, mock_run_command):
        """Non-ignore_failure step: first failure stops all further repeats and steps."""
        mock_run_command.side_effect = [
            MagicMock(returncode=0, stdout="ok\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=1, stdout="", stderr="boom", timed_out=False, is_successful=lambda success_pattern=None: False),
            # third call should never happen
            MagicMock(returncode=0, stdout="should not run\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
        ]
        runner = TaskRunner()
        task_cfg = {
            "steps": [
                {
                    "name": "bench",
                    "command": "python bench.py",
                    "repeat": 3,
                }
            ]
        }
        result = runner.run(task_cfg, "/tmp", "repo", "pipeline", {"working_dir": "/tmp"})
        assert result.success is False
        assert mock_run_command.call_count == 2

    @patch("forge.task.run_command")
    def test_repeated_step_ignore_failure_continues(self, mock_run_command):
        """ignore_failure=true: step failure does not stop repeat or subsequent steps."""
        mock_run_command.side_effect = [
            MagicMock(returncode=1, stdout="", stderr="err1", timed_out=False, is_successful=lambda success_pattern=None: False),
            MagicMock(returncode=1, stdout="", stderr="err2", timed_out=False, is_successful=lambda success_pattern=None: False),
            MagicMock(returncode=0, stdout="done\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
        ]
        runner = TaskRunner()
        task_cfg = {
            "steps": [
                {
                    "name": "flaky",
                    "command": "python flaky.py",
                    "repeat": 2,
                    "ignore_failure": True,
                },
                {
                    "name": "final",
                    "command": "python final.py",
                },
            ]
        }
        result = runner.run(task_cfg, "/tmp", "repo", "pipeline", {"working_dir": "/tmp"})
        assert result.success is True
        assert "done" in result.stdout
        assert mock_run_command.call_count == 3

    @patch("forge.task.run_command")
    def test_step_filter_with_step_repeat(self, mock_run_command):
        """--step filter + step-level repeat: only the filtered step runs, repeated."""
        mock_run_command.side_effect = [
            MagicMock(returncode=0, stdout="score=10\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=20\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
        ]
        runner = TaskRunner()
        task_cfg = {
            "steps": [
                {"name": "setup", "command": "python setup.py"},
                {
                    "name": "bench",
                    "command": "python bench.py",
                    "repeat": 2,
                    "repeat_agg": "max",
                    "result": {"type": "stdout", "pattern": r"score=([0-9.]+)"},
                },
            ]
        }
        result = runner.run(task_cfg, "/tmp", "repo", "pipeline", {"working_dir": "/tmp"}, step_name="bench")
        assert result.success is True
        assert result.result_values == {"value": 20.0}
        assert mock_run_command.call_count == 2

    @patch("forge.task.run_command")
    def test_step_filter_with_task_repeat_and_step_repeat(self, mock_run_command):
        """--step filter + task-level repeat + step-level repeat all stack correctly."""
        mock_run_command.side_effect = [
            MagicMock(returncode=0, stdout="v=1\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="v=3\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="v=5\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="v=7\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
        ]
        runner = TaskRunner()
        task_cfg = {
            "repeat": 2,
            "steps": [
                {"name": "setup", "command": "python setup.py"},
                {
                    "name": "bench",
                    "command": "python bench.py",
                    "repeat": 2,
                    "repeat_agg": "avg",
                    "result": {"type": "stdout", "pattern": r"v=([0-9.]+)"},
                },
            ]
        }
        # task repeat=2, step repeat=2 → 4 total bench calls; setup is filtered out
        result = runner.run(task_cfg, "/tmp", "repo", "pipeline", {"working_dir": "/tmp"}, step_name="bench")
        assert result.success is True
        assert mock_run_command.call_count == 4
        # step avg per task-run: run1=(1+3)/2=2.0, run2=(5+7)/2=6.0; task avg=(2+6)/2=4.0
        assert result.result_values == {"value": 4.0}

    @patch("forge.task.run_command")
    def test_step_partial_outlier_detection_inherits_task_overrides(self, mock_run_command):
        mock_run_command.side_effect = [
            MagicMock(returncode=0, stdout="score=100\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=101\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=102\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
            MagicMock(returncode=0, stdout="score=145\n", stderr="", timed_out=False, is_successful=lambda success_pattern=None: True),
        ]
        runner = TaskRunner()
        task_cfg = {
            "outlier_detection": {"max_outlier_ratio": 0.5, "iqr_multiplier": 10.0, "min_samples": 4},
            "steps": [
                {
                    "name": "bench_partial",
                    "command": "python bench.py",
                    "repeat": 4,
                    "repeat_agg": "avg_without_outliers",
                    "outlier_detection": {"min_samples": 4},
                    "result": {"type": "stdout", "pattern": r"score=([0-9.]+)"},
                },
            ]
        }
        result = runner.run(task_cfg, "/tmp", "repo", "pipeline", {"working_dir": "/tmp"}, step_name="bench_partial")
        assert result.success is True
        assert result.result_values == {"value": 112.0}


class TestGlobalEnv:
    def test_global_env_injected(self, mock_repo):
        """global_env is available to commands."""
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\necho \"PROXY=$http_proxy\"\n")
        runner = TaskRunner()
        task_cfg = {"command": "bash build.sh", "timeout": 30}
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables,
                            global_env={"http_proxy": "http://myproxy:8080"})
        assert "PROXY=http://myproxy:8080" in result.stdout

    def test_step_env_overrides_global(self, mock_repo):
        """Step-level env overrides global_env."""
        build_sh = mock_repo / "build.sh"
        build_sh.write_text("#!/bin/bash\necho \"PROXY=$http_proxy\"\n")
        runner = TaskRunner()
        task_cfg = {"command": "bash build.sh", "timeout": 30,
                    "env": {"http_proxy": "http://step-proxy:9090"}}
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables,
                            global_env={"http_proxy": "http://global-proxy:8080"})
        assert "PROXY=http://step-proxy:9090" in result.stdout

    def test_no_global_env_backward_compatible(self, mock_repo):
        """No global_env works fine."""
        runner = TaskRunner()
        task_cfg = {"command": "bash build.sh", "timeout": 30}
        variables = {"working_dir": str(mock_repo)}
        result = runner.run(task_cfg, str(mock_repo), "test_repo", "test", variables)
        assert result.success is True


class TestExtractResults:
    """Tests for extract_results(), especially placeholder error handling."""

    def test_file_result_missing_placeholder_returns_none(self, tmp_path, caplog):
        """When a capture variable is missing, extract_results should return None
        instead of raising ConfigError. This is the fix for the prof_dir crash."""
        cfg = {
            "result": {
                "type": "file",
                "path": "{prof_dir}/output/op_summary.csv",
                "format": "csv",
                "value_column": 1,
            }
        }
        cmd_result = CommandResult(returncode=0, stdout="no PROF match", stderr="", timed_out=False)
        # prof_dir is NOT in variables — simulates failed capture
        variables = {"op_name": "my_op"}
        result = extract_results(cfg, cmd_result, str(tmp_path), variables)
        assert result is None
        assert "Cannot resolve result path" in caplog.text

    def test_file_result_with_resolved_placeholder(self, tmp_path):
        """Normal case: placeholder resolves and file exists with valid CSV data."""
        prof_dir = tmp_path / "PROF_001"
        prof_dir.mkdir()
        csv_file = prof_dir / "summary.csv"
        csv_file.write_text("op,duration\nmatmul,42.5\n")
        cfg = {
            "result": {
                "type": "file",
                "path": "{prof_dir}/summary.csv",
                "format": "csv",
                "value_column": 1,
                "op_column": 0,
                "header": True,
                "delimiter": ",",
            }
        }
        cmd_result = CommandResult(returncode=0, stdout="", stderr="", timed_out=False)
        variables = {"prof_dir": "PROF_001"}
        result = extract_results(cfg, cmd_result, str(tmp_path), variables)
        assert result is not None
        assert result["matmul"] == 42.5

    def test_file_result_timed_out_skips_extraction(self, tmp_path):
        """Timed-out commands should skip result extraction entirely."""
        cfg = {
            "result": {
                "type": "file",
                "path": "{prof_dir}/summary.csv",
                "format": "csv",
                "value_column": 1,
            }
        }
        cmd_result = CommandResult(returncode=1, stdout="", stderr="", timed_out=True)
        variables = {}  # prof_dir missing, but shouldn't matter
        result = extract_results(cfg, cmd_result, str(tmp_path), variables)
        assert result is None

    def test_no_result_config_returns_none(self, tmp_path):
        """No result config means nothing to extract."""
        cfg = {"command": "echo hi"}
        cmd_result = CommandResult(returncode=0, stdout="hi", stderr="", timed_out=False)
        result = extract_results(cfg, cmd_result, str(tmp_path), {})
        assert result is None


class TestMultiStepCaptureFailureIntegration:
    """Integration test: multi-step task where capture fails and file result
    depends on the captured variable. Should not crash."""

    @patch("forge.task.run_command")
    def test_capture_miss_with_file_result_does_not_crash(self, mock_run_command, tmp_path):
        """When capture pattern doesn't match, subsequent file result extraction
        with {captured_var} in path should return None, not raise ConfigError."""
        mock_run_command.return_value = MagicMock(
            returncode=0, stdout="no match here\n", stderr="", timed_out=False,
            is_successful=lambda success_pattern=None: True,
        )
        runner = TaskRunner()
        task_cfg = {
            "steps": [
                {
                    "name": "profile",
                    "command": "echo test",
                    "capture": {"prof_dir": r"(PROF_\w+)"},
                    "result": {
                        "type": "file",
                        "path": "{prof_dir}/output/op_summary.csv",
                        "format": "csv",
                        "value_column": 1,
                    },
                }
            ]
        }
        variables = {"working_dir": str(tmp_path)}
        # Should not raise — should complete gracefully with no result_values
        result = runner.run(task_cfg, str(tmp_path), "test_repo", "profile", variables)
        assert result.success is True
        assert result.result_values is None


class TestResolveSourceEnvGlob:
    """Test resolve_source_env with glob wildcard support."""

    def test_resolves_glob_source_env(self, tmp_path):
        vendors = tmp_path / "vendors"
        vendors.mkdir()
        vendor_dir = vendors / "omni_custom_ops" / "bin"
        vendor_dir.mkdir(parents=True)
        script = vendor_dir / "set_env.bash"
        script.write_text("#!/bin/bash\nexport MY_VAR=hello\n")
        config = {"name": "test"}
        task_cfg = {"source_env": str(tmp_path / "vendors" / "*" / "bin" / "set_env.bash")}
        variables = {"working_dir": str(tmp_path)}
        result = resolve_source_env(config, task_cfg, variables, str(tmp_path))
        assert result is not None
        assert result.get("MY_VAR") == "hello"

    def test_glob_no_match_returns_none(self, tmp_path):
        config = {"name": "test"}
        task_cfg = {"source_env": str(tmp_path / "vendors" / "*" / "bin" / "set_env.bash")}
        variables = {"working_dir": str(tmp_path)}
        result = resolve_source_env(config, task_cfg, variables, str(tmp_path))
        assert result is None

    def test_no_glob_uses_direct_path(self, tmp_path):
        vendor_dir = tmp_path / "vendors" / "omni_custom_ops" / "bin"
        vendor_dir.mkdir(parents=True)
        script = vendor_dir / "set_env.bash"
        script.write_text("#!/bin/bash\nexport MY_VAR=direct\n")
        config = {"name": "test"}
        task_cfg = {"source_env": str(script)}
        variables = {"working_dir": str(tmp_path)}
        result = resolve_source_env(config, task_cfg, variables, str(tmp_path))
        assert result is not None
        assert result.get("MY_VAR") == "direct"


class TestTaskRunnerLoop:
    def test_single_task_loop_runs_each_value(self, tmp_path):
        script = tmp_path / "emit.sh"
        script.write_text("#!/bin/bash\necho \"score: ${1}\"\n")
        script.chmod(0o755)

        runner = TaskRunner()
        result = runner.run(
            {
                "command": f"bash {script}",
                "args": ["{score}"],
                "result": {"type": "stdout", "pattern": r"score: ([0-9.]+)"},
            },
            str(tmp_path),
            "repo",
            "bench",
            {"working_dir": str(tmp_path), "timestamp": "test"},
            loop={"var": "score", "values": ["1", "2"]},
        )

        assert result.success is True
        assert result.result_values == {"1/value": 1.0, "2/value": 2.0}

    def test_task_loop_wraps_existing_repeat_inside_each_value(self, tmp_path):
        script = tmp_path / "emit.sh"
        script.write_text("#!/bin/bash\necho \"score: ${1}\"\n")
        script.chmod(0o755)

        runner = TaskRunner()
        result = runner.run(
            {
                "command": f"bash {script}",
                "args": ["{score}"],
                "repeat": 2,
                "repeat_agg": "avg",
                "result": {"type": "stdout", "pattern": r"score: ([0-9.]+)"},
            },
            str(tmp_path),
            "repo",
            "bench",
            {"working_dir": str(tmp_path), "timestamp": "test"},
            loop={"var": "score", "values": ["3", "5"]},
        )

        assert result.success is True
        assert result.result_values == {"3/value": 3.0, "5/value": 5.0}

    def test_task_loop_capture_does_not_leak_between_values(self, tmp_path):
        script = tmp_path / "capture.sh"
        script.write_text("#!/bin/bash\necho \"CAPTURED=$1\"\n")
        script.chmod(0o755)
        use_script = tmp_path / "use.sh"
        use_script.write_text("#!/bin/bash\necho \"score: $1\"\n")
        use_script.chmod(0o755)

        variables = {"working_dir": str(tmp_path), "timestamp": "test"}
        runner = TaskRunner()
        result = runner.run(
            {
                "steps": [
                    {
                        "name": "capture",
                        "command": f"bash {script}",
                        "args": ["{score}"],
                        "capture": {"captured_score": r"CAPTURED=([0-9.]+)"},
                    },
                    {
                        "name": "use",
                        "command": f"bash {use_script}",
                        "args": ["{captured_score}"],
                        "result": {"type": "stdout", "pattern": r"score: ([0-9.]+)"},
                    },
                ]
            },
            str(tmp_path),
            "repo",
            "bench",
            variables,
            loop={"var": "score", "values": ["7", "9"]},
        )

        assert result.success is True
        assert result.result_values == {"7/value": 7.0, "9/value": 9.0}
        assert "captured_score" not in variables

    def test_task_loop_fail_fast_false_continues_after_failure(self, tmp_path):
        script = tmp_path / "maybe_fail.sh"
        script.write_text("#!/bin/bash\nif [ \"$1\" = \"2\" ]; then exit 1; fi\necho \"score: $1\"\n")
        script.chmod(0o755)

        runner = TaskRunner()
        result = runner.run(
            {
                "command": f"bash {script}",
                "args": ["{score}"],
                "result": {"type": "stdout", "pattern": r"score: ([0-9.]+)"},
            },
            str(tmp_path),
            "repo",
            "bench",
            {"working_dir": str(tmp_path), "timestamp": "test"},
            loop={"var": "score", "values": ["1", "2", "3"], "fail_fast": False},
        )

        assert result.success is False
        assert result.result_values is not None
        assert "1/value" in result.result_values
        assert "3/value" in result.result_values

    def test_task_loop_empty_values_raises(self, tmp_path):
        runner = TaskRunner()
        with pytest.raises(ValueError, match="loop.values must contain at least one value"):
            runner.run(
                {"command": "echo", "args": []},
                str(tmp_path),
                "repo",
                "bench",
                {"working_dir": str(tmp_path), "timestamp": "test"},
                loop={"var": "score", "values": ["", "  "]},
            )
