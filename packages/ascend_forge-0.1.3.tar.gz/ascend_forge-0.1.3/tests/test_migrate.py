import json
import pytest
from forge.migrate import migrate_config


class TestMigrateConfig:
    def test_rename_repo_path(self):
        """repo_path → working_dir."""
        config = {"name": "test", "repo_path": "/path/to/repo"}
        result, changes = migrate_config(config)
        assert "working_dir" in result
        assert result["working_dir"] == "/path/to/repo"
        assert "repo_path" not in result
        assert len(changes) > 0

    def test_remove_test_path_to_vars(self):
        """test_path moves into vars."""
        config = {
            "name": "test",
            "repo_path": "/path/to/repo",
            "test_path": "/path/to/tests",
        }
        result, changes = migrate_config(config)
        assert "test_path" not in result
        assert result.get("vars", {}).get("test_path") == "/path/to/tests"

    def test_replace_repo_path_placeholder(self):
        """{repo_path} → {working_dir} in commands."""
        config = {
            "name": "test",
            "repo_path": "/path/to/repo",
            "tasks": {
                "build": {
                    "command": "make -C {repo_path}",
                    "args": ["--out={repo_path}/build"],
                }
            },
        }
        result, changes = migrate_config(config)
        assert result["tasks"]["build"]["command"] == "make -C {working_dir}"
        assert result["tasks"]["build"]["args"] == ["--out={working_dir}/build"]

    def test_already_migrated_no_changes(self):
        """Config with working_dir already set returns no changes."""
        config = {"name": "test", "working_dir": "/path"}
        result, changes = migrate_config(config)
        assert result == config
        assert changes == []

    def test_preserves_other_fields(self):
        """Migration preserves all non-renamed fields."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "description": "My project",
            "vars": {"foo": "bar"},
            "tasks": {"build": {"command": "make"}},
        }
        result, changes = migrate_config(config)
        assert result["description"] == "My project"
        assert result["vars"]["foo"] == "bar"
        assert result["tasks"]["build"]["command"] == "make"

    def test_test_path_merges_with_existing_vars(self):
        """test_path merges into existing vars without overwriting."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "test_path": "/tests",
            "vars": {"foo": "bar"},
        }
        result, changes = migrate_config(config)
        assert result["vars"]["foo"] == "bar"
        assert result["vars"]["test_path"] == "/tests"


class TestBuildTestsToTasks:
    def test_build_to_tasks(self):
        """build field moves to tasks.build."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "build": {"command": "make"},
        }
        migrated, changes = migrate_config(config)
        assert "tasks" in migrated
        assert migrated["tasks"]["build"] == {"command": "make"}
        assert "build" not in migrated
        assert "build → tasks.build" in changes

    def test_tests_to_tasks_no_prefix(self):
        """tests.accuracy moves to tasks.accuracy (no test_ prefix)."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "tests": {
                "accuracy": {"command": "pytest"},
                "performance": {"command": "perf.sh"},
            },
        }
        migrated, changes = migrate_config(config)
        assert "tasks" in migrated
        assert migrated["tasks"]["accuracy"] == {"command": "pytest"}
        assert migrated["tasks"]["performance"] == {"command": "perf.sh"}
        assert "tests.accuracy → tasks.accuracy" in changes
        assert "tests.performance → tasks.performance" in changes

    def test_tests_source_env_removed_with_warning(self):
        """tests.source_env is removed with a warning in changes."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "tests": {
                "source_env": "/path/to/env.sh",
                "accuracy": {"command": "pytest"},
            },
        }
        migrated, changes = migrate_config(config)
        assert "tasks" in migrated
        assert "accuracy" in migrated["tasks"]
        assert "source_env" not in migrated["tasks"]
        assert any("tests.source_env" in c and "removed" in c for c in changes)

    def test_build_before_test_to_workflow(self):
        """bisect.build_before_test generates workflow and sets bisect.workflows array."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "build": {"command": "make"},
            "tests": {"accuracy": {"command": "pytest"}},
            "bisect": {"build_before_test": True, "regression": 10.0},
        }
        migrated, changes = migrate_config(config)
        assert "workflows" in migrated
        assert "_bisect_default" in migrated["workflows"]
        assert migrated["workflows"]["_bisect_default"]["tasks"] == ["build", "accuracy"]
        assert "workflow" not in migrated["bisect"]
        assert migrated["bisect"]["workflows"] == [{"name": "_bisect_default", "repeatable": True}]
        assert any("bisect.build_before_test → workflow" in c for c in changes)
        assert any("_bisect_default' → bisect.workflows array" in c for c in changes)

    def test_build_before_test_false_to_workflow(self):
        """bisect.build_before_test=false generates workflow without build."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "tests": {"accuracy": {"command": "pytest"}},
            "bisect": {"build_before_test": False, "regression": 10.0},
        }
        migrated, changes = migrate_config(config)
        assert migrated["workflows"]["_bisect_default"]["tasks"] == ["accuracy"]
        assert "workflow" not in migrated["bisect"]
        assert migrated["bisect"]["workflows"] == [{"name": "_bisect_default", "repeatable": True}]

    def test_existing_tasks_preserved(self):
        """If tasks already exists, build/tests merge into it."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "tasks": {"custom": {"command": "echo"}},
            "build": {"command": "make"},
            "tests": {"accuracy": {"command": "pytest"}},
        }
        migrated, changes = migrate_config(config)
        assert migrated["tasks"]["custom"] == {"command": "echo"}
        assert migrated["tasks"]["build"] == {"command": "make"}
        assert migrated["tasks"]["accuracy"] == {"command": "pytest"}

    def test_post_workflow_true_to_explicit(self):
        """bisect.post_workflow=true becomes explicit workflow name, then post_workflows array."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "tests": {"accuracy": {"command": "pytest"}},
            "bisect": {"workflow": "test_pipeline", "post_workflow": True},
        }
        migrated, changes = migrate_config(config)
        assert "workflow" not in migrated["bisect"]
        assert "post_workflow" not in migrated["bisect"]
        assert migrated["bisect"]["workflows"] == [{"name": "test_pipeline", "repeatable": True}]
        assert migrated["bisect"]["post_workflows"] == ["test_pipeline"]
        assert any("post_workflow: true → explicit" in c for c in changes)
        assert any("post_workflow 'test_pipeline' → bisect.post_workflows array" in c for c in changes)

    def test_collision_build_already_in_tasks(self):
        """If tasks.build exists, legacy build is dropped with warning (priority rule)."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "tasks": {"build": {"command": "explicit_build"}},
            "build": {"command": "legacy_build"},
        }
        migrated, changes = migrate_config(config)
        # Explicit tasks.build should be preserved, legacy build dropped
        assert migrated["tasks"]["build"] == {"command": "explicit_build"}
        assert any("build removed" in c and "tasks.build already exists" in c for c in changes)
        assert "build → tasks.build" not in changes

    def test_collision_test_already_in_tasks(self):
        """If tasks.X exists, legacy tests.X is dropped with warning (priority rule)."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "tasks": {"accuracy": {"command": "explicit_accuracy"}},
            "tests": {"accuracy": {"command": "legacy_accuracy"}},
        }
        migrated, changes = migrate_config(config)
        # Explicit tasks.accuracy should be preserved, legacy tests.accuracy dropped
        assert migrated["tasks"]["accuracy"] == {"command": "explicit_accuracy"}
        assert any("tests.accuracy removed" in c and "tasks.accuracy already exists" in c for c in changes)
        assert "tests.accuracy → tasks.accuracy" not in changes

    def test_unknown_non_dict_tests_entry_warning(self):
        """Unknown non-dict entries in tests are removed with warning."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "tests": {
                "unknown_field": "some_value",
                "accuracy": {"command": "pytest"},
            },
        }
        migrated, changes = migrate_config(config)
        assert "accuracy" in migrated["tasks"]
        assert any("tests.unknown_field removed" in c and "non-dict" in c for c in changes)

    def test_build_before_test_no_test_type_warning(self):
        """build_before_test with no test type found is removed with warning."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "build": {"command": "make"},
            "bisect": {"build_before_test": True},
        }
        migrated, changes = migrate_config(config)
        # No workflow should be created since no test type found
        assert "workflows" not in migrated
        assert any("build_before_test removed" in c and "no test task found" in c for c in changes)


class TestBisectWorkflowMigration:
    def test_workflow_string_to_workflows_array(self):
        """bisect.workflow (string) → bisect.workflows array with repeatable."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "bisect": {"workflow": "my_workflow", "regression": 10.0},
        }
        migrated, changes = migrate_config(config)
        assert "workflow" not in migrated["bisect"]
        assert "workflows" in migrated["bisect"]
        assert migrated["bisect"]["workflows"] == [{"name": "my_workflow", "repeatable": True}]
        assert any("workflow 'my_workflow' → bisect.workflows array" in c for c in changes)

    def test_post_workflow_string_to_post_workflows_array(self):
        """bisect.post_workflow (string) → bisect.post_workflows array."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "bisect": {"workflow": "main", "post_workflow": "cleanup"},
        }
        migrated, changes = migrate_config(config)
        assert "workflow" not in migrated["bisect"]
        assert "post_workflow" not in migrated["bisect"]
        assert migrated["bisect"]["workflows"] == [{"name": "main", "repeatable": True}]
        assert migrated["bisect"]["post_workflows"] == ["cleanup"]
        assert any("post_workflow 'cleanup' → bisect.post_workflows array" in c for c in changes)

    def test_post_workflow_true_to_workflows_array(self):
        """bisect.post_workflow: true → uses workflow name → post_workflows array."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "bisect": {"workflow": "my_pipeline", "post_workflow": True},
        }
        migrated, changes = migrate_config(config)
        # Should convert: post_workflow: true → post_workflow: "my_pipeline" → post_workflows: ["my_pipeline"]
        assert "workflow" not in migrated["bisect"]
        assert "post_workflow" not in migrated["bisect"]
        assert migrated["bisect"]["workflows"] == [{"name": "my_pipeline", "repeatable": True}]
        assert migrated["bisect"]["post_workflows"] == ["my_pipeline"]
        assert any("post_workflow: true → explicit 'my_pipeline'" in c for c in changes)
        assert any("post_workflow 'my_pipeline' → bisect.post_workflows array" in c for c in changes)

    def test_post_workflow_true_no_workflow_skipped(self):
        """bisect.post_workflow: true without workflow is skipped gracefully."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "bisect": {"post_workflow": True},
        }
        migrated, changes = migrate_config(config)
        # Should not crash, post_workflow stays True (can't convert without workflow name)
        assert migrated["bisect"]["post_workflow"] is True
        # Should not have any post_workflow migration change
        assert not any("post_workflow: true → explicit" in c for c in changes)

    def test_workflows_already_present_not_overwritten(self):
        """If bisect.workflows already exists, workflow string is removed without conversion."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "bisect": {
                "workflow": "old_workflow",
                "workflows": [{"name": "new_workflow", "repeatable": False}],
            },
        }
        migrated, changes = migrate_config(config)
        # workflow should be removed, but existing workflows should stay
        assert "workflow" not in migrated["bisect"]
        assert migrated["bisect"]["workflows"] == [{"name": "new_workflow", "repeatable": False}]
        # Should NOT have the workflow → workflows migration change
        assert not any("workflow 'old_workflow' → bisect.workflows array" in c for c in changes)

    def test_post_workflows_already_present_not_overwritten(self):
        """If bisect.post_workflows already exists, post_workflow string is removed without conversion."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "bisect": {
                "workflow": "main",
                "post_workflow": "old_cleanup",
                "post_workflows": ["new_cleanup"],
            },
        }
        migrated, changes = migrate_config(config)
        assert "workflow" not in migrated["bisect"]
        assert "post_workflow" not in migrated["bisect"]
        assert migrated["bisect"]["post_workflows"] == ["new_cleanup"]
        # Should have workflow conversion but NOT post_workflow conversion
        assert any("workflow 'main' → bisect.workflows array" in c for c in changes)
        assert not any("post_workflow 'old_cleanup'" in c for c in changes)

    def test_full_bisect_migration(self):
        """Full migration of all bisect fields together."""
        config = {
            "name": "test",
            "repo_path": "/path",
            "tests": {"accuracy": {"command": "pytest"}},
            "bisect": {
                "workflow": "test_pipeline",
                "post_workflow": True,
                "regression": 15.0,
            },
        }
        migrated, changes = migrate_config(config)
        # workflow → workflows array
        assert migrated["bisect"]["workflows"] == [{"name": "test_pipeline", "repeatable": True}]
        # post_workflow: true → explicit → post_workflows array
        assert migrated["bisect"]["post_workflows"] == ["test_pipeline"]
        # Other bisect fields preserved
        assert migrated["bisect"]["regression"] == 15.0
        # Check all changes recorded
        assert any("post_workflow: true → explicit" in c for c in changes)
        assert any("workflow 'test_pipeline' → bisect.workflows array" in c for c in changes)
        assert any("post_workflow 'test_pipeline' → bisect.post_workflows array" in c for c in changes)


class TestMigrateCLI:
    def test_migrate_dry_run(self, tmp_path, monkeypatch, capsys):
        from forge.cli import main

        config_dir = tmp_path / "configs"
        config_dir.mkdir()
        old_config = {"name": "test", "repo_path": "/path/to/repo"}
        (config_dir / "test.json").write_text(json.dumps(old_config))
        monkeypatch.setenv("FORGE_CONFIG_DIR", str(config_dir))

        main(["migrate", "--dry-run"])
        captured = capsys.readouterr()
        assert "dry run" in captured.out
        assert "repo_path" in captured.out

        # File should NOT be modified
        reloaded = json.loads((config_dir / "test.json").read_text())
        assert "repo_path" in reloaded

    def test_migrate_applies_changes(self, tmp_path, monkeypatch, capsys):
        from forge.cli import main

        config_dir = tmp_path / "configs"
        config_dir.mkdir()
        old_config = {"name": "test", "repo_path": "/path/to/repo"}
        (config_dir / "test.json").write_text(json.dumps(old_config))
        monkeypatch.setenv("FORGE_CONFIG_DIR", str(config_dir))

        main(["migrate"])
        captured = capsys.readouterr()
        assert "migrated" in captured.out

        # File SHOULD be modified
        reloaded = json.loads((config_dir / "test.json").read_text())
        assert "working_dir" in reloaded
        assert "repo_path" not in reloaded
