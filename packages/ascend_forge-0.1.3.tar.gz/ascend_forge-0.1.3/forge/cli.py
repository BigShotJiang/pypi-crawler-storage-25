"""CLI entry point for forge."""

import argparse
import time
import json
import logging
import os
import signal
import sys

from forge.config import load_all_configs, validate_config, ConfigError, check_placeholders, check_task_placeholders, resolve_tasks
from forge.builder import build
from forge.tester import run_test
from forge.task import TaskRunner, TaskResult, resolve_source_env
from forge.result import save_result, load_latest_result, load_result_by_commit, compare_results, ResultRecord
from forge.bisector import bisect_repo, BisectAbortError
from forge.formatter import format_bisect_table
from forge.log import set_verbose, set_debug, format_elapsed, bold, dim, green, red, yellow, cyan, magenta
from forge.loop import run_loop, validate_loop_var_used, normalize_loop_spec

logger = logging.getLogger("forge")
REPEAT_AG_CHOICES = ["avg", "avg_without_outliers", "max"]


class _CurrentStderrHandler(logging.Handler):
    def emit(self, record) -> None:
        msg = self.format(record)
        sys.stderr.write(f"{msg}\n")
        flush = getattr(sys.stderr, "flush", None)
        if callable(flush):
            flush()


def _setup_logging(debug: bool) -> None:
    level = logging.DEBUG if debug else logging.INFO
    logger.setLevel(level)
    handler = _CurrentStderrHandler()
    handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    logger.handlers = [handler]


def _get_configs(config_dir: str | None) -> dict:
    try:
        return load_all_configs(config_dir)
    except ConfigError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def _get_config(configs: dict, repo_name: str) -> dict:
    if repo_name not in configs:
        print(f"Error: repo '{repo_name}' not found. Use 'forge list' to see available repos.", file=sys.stderr)
        sys.exit(1)
    cfg = configs[repo_name]
    try:
        validate_config(cfg)
    except ConfigError as e:
        print(f"Config error for '{repo_name}': {e}", file=sys.stderr)
        sys.exit(1)
    # NOTE: do NOT resolve working_dir here. CLI --arg overrides are not yet
    # known at this point, so resolving with only cfg["vars"] would bake in
    # default values of repo_root etc. and silently ignore --arg overrides.
    # Resolution is deferred to _build_variables(), which has extra_vars merged
    # in and writes the final value back to cfg["working_dir"].
    return cfg


def _load_arg_json_file(path_str: str) -> dict[str, str]:
    """Load a flat JSON object from an --arg @file path."""
    try:
        with open(path_str, "r", encoding="utf-8") as f:
            data = json.load(f)
    except OSError as e:
        reason = e.strerror or str(e)
        print(f"Error: failed to read --arg JSON file '{path_str}': {reason}", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError:
        print(f"Error: --arg JSON file '{path_str}' is not valid JSON", file=sys.stderr)
        sys.exit(1)

    if not isinstance(data, dict):
        print(f"Error: --arg JSON file '{path_str}' must contain a flat JSON object", file=sys.stderr)
        sys.exit(1)

    if any(not isinstance(value, str) for value in data.values()):
        print(f"Error: --arg JSON file '{path_str}' must contain only string values", file=sys.stderr)
        sys.exit(1)

    return data


def _parse_args_list(arg_list: list[str] | None) -> dict[str, str]:
    """Parse --arg KEY=VALUE items and @file.json entries into a dict, left to right."""
    if not arg_list:
        return {}
    result = {}
    for item in arg_list:
        if item.startswith("@"):
            result.update(_load_arg_json_file(item[1:]))
            continue
        if "=" not in item:
            print(f"Error: --arg must be KEY=VALUE or @file.json, got '{item}'", file=sys.stderr)
            sys.exit(1)
        key, _, value = item.partition("=")
        result[key] = value
    return result


def _parse_loop_list(loop_list: list[str] | None) -> dict | None:
    """Parse repeated --loop KEY=VALUE entries into a LoopSpec dict."""
    if not loop_list:
        return None
    key_seen = None
    values = []
    for item in loop_list:
        if "=" not in item:
            print(f"Error: --loop must be KEY=VALUE, got '{item}'", file=sys.stderr)
            sys.exit(1)
        key, _, value = item.partition("=")
        key = key.strip()
        if not key:
            print(f"Error: --loop key must be non-empty, got '{item}'", file=sys.stderr)
            sys.exit(1)
        if key_seen is None:
            key_seen = key
        elif key != key_seen:
            print(
                f"Error: all --loop entries must use the same key, got '{key_seen}' and '{key}'",
                file=sys.stderr,
            )
            sys.exit(1)
        values.append(value)
    return {"var": key_seen, "values": values, "fail_fast": True}


def _add_loop_arg(parser):
    parser.add_argument(
        "--loop",
        action="append",
        metavar="KEY=VALUE",
        help="Loop one placeholder over multiple values; repeat for each value",
    )


def _merge_extra_vars(args) -> dict[str, str]:
    """Build extra_vars from --arg, --op, and --cs shortcuts."""
    extra_vars = _parse_args_list(getattr(args, "arg", None))
    op = getattr(args, "op", None)
    if op and "op_name" not in extra_vars:
        extra_vars["op_name"] = op
    cs = getattr(args, "cs", None)
    if cs and "case" not in extra_vars:
        extra_vars["case"] = cs
    ip = getattr(args, "ip", None)
    if ip and "install_path" not in extra_vars:
        extra_vars["install_path"] = ip
    return extra_vars


def cmd_list(args):
    configs = _get_configs(args.config_dir)
    if not configs:
        print("No repos configured.")
        return
    for name, cfg in configs.items():
        desc = cfg.get("description", "")
        print(f"  {name:20s} {desc}")


def cmd_show(args):
    configs = _get_configs(args.config_dir)
    cfg = _get_config(configs, args.repo_name)
    display = {k: v for k, v in cfg.items() if not k.startswith("_")}
    print(json.dumps(display, indent=2, ensure_ascii=False))


def cmd_usage(args):
    configs = _get_configs(args.config_dir)
    cfg = _get_config(configs, args.repo_name)

    print(bold(args.repo_name))
    description = cfg.get("description")
    if description:
        print(description)
    print()

    usage = cfg.get("usage")
    if usage:
        print(usage)
    else:
        print(dim("No usage guide defined in this config."))


def cmd_validate(args):
    configs = _get_configs(args.config_dir)
    cfg = _get_config(configs, args.repo_name)
    try:
        validate_config(cfg)
        print(f"Config for '{args.repo_name}' is valid.")
    except ConfigError as e:
        print(f"Validation error: {e}", file=sys.stderr)
        sys.exit(1)


def _build_variables(cfg: dict, extra_vars: dict, commit: str | None = None) -> dict[str, str]:
    """Build the variables dict used for placeholder substitution."""
    from datetime import datetime
    from forge.config import resolve_vars
    # Start with config-defined vars (lowest priority)
    variables = dict(cfg.get("vars", {}))
    # Built-in variables override config vars
    variables["working_dir"] = cfg["working_dir"]
    variables["config_dir"] = cfg.get("_config_dir", "")
    variables["timestamp"] = datetime.now().strftime("%Y%m%d_%H%M%S")
    # CLI extra_vars override everything
    variables.update(extra_vars)
    # Resolve placeholder references within variable values early,
    # so that working_dir is available for git operations below.
    variables = resolve_vars(variables)
    # Write the resolved working_dir back to cfg so downstream code
    # (builder, tester, workflow runner) sees the final path that
    # honors --arg overrides (e.g. --arg repo_root=...).
    cfg["working_dir"] = variables["working_dir"]
    if commit:
        variables["commit"] = commit
    else:
        # Auto-detect HEAD commit for placeholder pre-check
        import subprocess
        working_dir = variables.get("working_dir", cfg["working_dir"])
        proc = subprocess.run(["git", "rev-parse", "HEAD"], cwd=working_dir, capture_output=True, text=True)
        if proc.returncode == 0:
            variables["commit"] = proc.stdout.strip()
    return variables


def cmd_build(args):
    configs = _get_configs(args.config_dir)
    cfg = _get_config(configs, args.repo_name)

    # Resolve tasks and check if build task exists
    tasks = resolve_tasks(cfg)
    if "build" not in tasks:
        print("Error: 'build' task not defined.", file=sys.stderr)
        print("Hint: Add 'tasks.build' to config or run 'forge migrate' to convert.", file=sys.stderr)
        sys.exit(1)

    extra_vars = _merge_extra_vars(args)
    variables = _build_variables(cfg, extra_vars, args.commit)
    try:
        check_task_placeholders(tasks["build"], variables, cfg.get("vars"))
    except ConfigError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    print(bold(f"Building {args.repo_name}..."))
    t0 = time.time()
    result = build(cfg, commit=args.commit, variables=variables, step_name=args.step)
    if result.success:
        print(green(f"Build succeeded. ({format_elapsed(time.time() - t0)})"))
    else:
        print(red(f"Build failed. ({format_elapsed(time.time() - t0)})"), file=sys.stderr)
        if result.artifact_errors:
            for err in result.artifact_errors:
                print(f"  Artifact check: {err}", file=sys.stderr)
        if result.stderr:
            print(result.stderr, file=sys.stderr)
        sys.exit(1)


def cmd_test(args):
    configs = _get_configs(args.config_dir)
    cfg = _get_config(configs, args.repo_name)

    # Resolve tasks and check if test type exists
    tasks = resolve_tasks(cfg)
    test_type = args.type
    if test_type not in tasks:
        print(f"Error: task '{test_type}' not found. Available: {list(tasks.keys())}", file=sys.stderr)
        print("Hint: Run 'forge migrate' to convert legacy config format.", file=sys.stderr)
        sys.exit(1)

    extra_vars = _merge_extra_vars(args)
    variables = _build_variables(cfg, extra_vars, args.commit)
    try:
        check_task_placeholders(tasks[test_type], variables, cfg.get("vars"))
    except ConfigError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    if args.commit:
        print(bold(f"Building {args.repo_name} at {args.commit[:8]}..."))
        build_result = build(cfg, commit=args.commit, variables=variables)
        if not build_result.success:
            print("Build failed.", file=sys.stderr)
            sys.exit(1)

    print(bold(f"Running {args.type} test on {args.repo_name}..."))
    repeat = getattr(args, "repeat", None)
    repeat_agg = getattr(args, "repeat_agg", None)
    t0 = time.time()
    result = run_test(cfg, args.type, op_name=extra_vars.get("op_name"), commit=args.commit, variables=variables, repeat=repeat, repeat_agg=repeat_agg)

    if result.success:
        print(green(f"Test passed. ({format_elapsed(time.time() - t0)})"))
    else:
        print(red(f"Test failed. ({format_elapsed(time.time() - t0)})"), file=sys.stderr)

    if result.result_values:
        for op, val in result.result_values.items():
            print(f"  {cyan(f'{op}')}: {val}")

        # Compare BEFORE saving (so --compare-last gets previous result)
        if args.baseline:
            baseline_record = load_result_by_commit(args.repo_name, args.type, args.baseline)
            if baseline_record:
                _show_comparison(result.result_values, baseline_record.results)
            else:
                print(f"No saved results for commit {args.baseline}", file=sys.stderr)
        elif args.compare_last:
            last = load_latest_result(args.repo_name, args.type)
            if last:
                _show_comparison(result.result_values, last.results)
            else:
                print("No previous results to compare with.", file=sys.stderr)

        # Save AFTER comparison
        record = ResultRecord(
            repo=args.repo_name, commit=args.commit or "HEAD",
            test_type=args.type, results=result.result_values,
        )
        save_result(record)

    if not result.success:
        sys.exit(1)


def _show_comparison(current: dict, baseline: dict) -> None:
    comparison = compare_results(current, baseline)
    print("\nComparison:")
    for op, data in comparison.items():
        cur = data["current"]
        base = data["baseline"]
        pct = data["change_pct"]
        if cur is not None and base is not None and pct is not None:
            sign = "+" if pct > 0 else ""
            print(f"  {op}: {cur} (current) vs {base} (baseline) | {sign}{pct:.1f}%")
        elif base is None:
            print(f"  {op}: {cur} (new, no baseline)")


def cmd_bisect(args):
    configs = _get_configs(args.config_dir)
    cfg = _get_config(configs, args.repo_name)
    extra_vars = _merge_extra_vars(args)

    workflow_name = getattr(args, "workflow", None) or cfg.get("bisect", {}).get("workflow")

    # Read test_type from config (CLI --type is deprecated)
    legacy_type = getattr(args, "type", None)
    if legacy_type:
        print(yellow("Warning: --type/-t is deprecated. Test type is now read from bisect.test_type config."), file=sys.stderr)

    test_type = cfg.get("bisect", {}).get("test_type", "accuracy")

    desc_parts = [f"Bisecting {args.repo_name} between {args.good[:8]}..{args.bad[:8]}"]
    if workflow_name:
        desc_parts.append(f"(workflow: {workflow_name})")
    if test_type:
        desc_parts.append(f"({test_type})")
    print(bold(" ".join(desc_parts)))

    try:
        result = bisect_repo(
            config=cfg, good_commit=args.good, bad_commit=args.bad,
            workflow_name=workflow_name, test_type=test_type,
            op_name=extra_vars.get("op_name"), regression_pct=args.regression,
            threshold=args.threshold, extra_vars=extra_vars,
            repeat=getattr(args, "repeat", None), repeat_agg=getattr(args, "repeat_agg", None),
        )
    except BisectAbortError as e:
        print(f"Bisect aborted: {e}", file=sys.stderr)
        sys.exit(1)

    if result.found_commit:
        table = format_bisect_table(result, test_type or "accuracy", op_name=extra_vars.get("op_name"))
        if table:
            print(f"\n{table}")
        else:
            print(f"\nFirst bad commit: {result.found_commit}")
            print(f"Total steps: {result.total_steps}, skipped: {result.skipped_steps}")
        if result.commit_range and len(result.commit_range) > 1:
            print(f"(Due to skips, might be in range: {result.commit_range[0][:8]}..{result.commit_range[-1][:8]})")
    else:
        print("Could not determine the bad commit.")
        sys.exit(1)


def cmd_run(args):
    """Build then test in one command."""
    configs = _get_configs(args.config_dir)
    cfg = _get_config(configs, args.repo_name)
    extra_vars = _merge_extra_vars(args)
    variables = _build_variables(cfg, extra_vars, args.commit)
    loop = _parse_loop_list(getattr(args, "loop", None))
    tasks = resolve_tasks(cfg)
    if "build" not in tasks:
        print("Error: 'build' task not defined.", file=sys.stderr)
        print("Hint: Add 'tasks.build' to config or run 'forge migrate' to convert.", file=sys.stderr)
        sys.exit(1)
    if args.type not in tasks:
        print(f"Error: task '{args.type}' not found. Available: {list(tasks.keys())}", file=sys.stderr)
        print("Hint: Run 'forge migrate' to convert legacy config format.", file=sys.stderr)
        sys.exit(1)
    try:
        check_task_placeholders(tasks["build"], variables, cfg.get("vars"))
        check_task_placeholders(tasks[args.type], variables, cfg.get("vars"))
    except ConfigError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    if loop:
        try:
            loop_spec = normalize_loop_spec(loop)
            validate_loop_var_used(loop_spec, [tasks["build"], tasks[args.type]], "build+test")
        except (ConfigError, ValueError) as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

    def handle_result_values(result):
        if not result.result_values:
            return

        for op, val in result.result_values.items():
            print(f"  {cyan(f'{op}')}: {val}")

        if args.baseline:
            baseline_record = load_result_by_commit(args.repo_name, args.type, args.baseline)
            if baseline_record:
                _show_comparison(result.result_values, baseline_record.results)
            else:
                print(f"No saved results for commit {args.baseline}", file=sys.stderr)
        elif args.compare_last:
            last = load_latest_result(args.repo_name, args.type)
            if last:
                _show_comparison(result.result_values, last.results)
            else:
                print("No previous results to compare with.", file=sys.stderr)

        record = ResultRecord(
            repo=args.repo_name, commit=args.commit or "HEAD",
            test_type=args.type, results=result.result_values,
        )
        save_result(record)

    def run_once(iter_variables):
        print(bold(f"Building {args.repo_name}..."))
        t0 = time.time()
        build_result = build(cfg, commit=args.commit, variables=iter_variables, step_name=args.step)
        if not build_result.success:
            print(red(f"Build failed. ({format_elapsed(time.time() - t0)})"), file=sys.stderr)
            if build_result.artifact_errors:
                for err in build_result.artifact_errors:
                    print(f"  Artifact check: {err}", file=sys.stderr)
            if build_result.stderr:
                print(build_result.stderr, file=sys.stderr)
            return TaskResult(
                success=False,
                stdout=build_result.stdout,
                stderr=build_result.stderr,
                timed_out=build_result.timed_out,
                artifact_errors=build_result.artifact_errors,
            )
        print(green(f"Build succeeded. ({format_elapsed(time.time() - t0)})"))

        print(bold(f"Running {args.type} test on {args.repo_name}..."))
        repeat = getattr(args, "repeat", None)
        repeat_agg = getattr(args, "repeat_agg", None)
        t1 = time.time()
        result = run_test(
            cfg,
            args.type,
            op_name=iter_variables.get("op_name"),
            commit=args.commit,
            variables=iter_variables,
            repeat=repeat,
            repeat_agg=repeat_agg,
        )

        if result.success:
            print(green(f"Test passed. ({format_elapsed(time.time() - t1)})"))
        else:
            print(red(f"Test failed. ({format_elapsed(time.time() - t1)})"), file=sys.stderr)
        return result

    if loop:
        loop_result = run_loop(loop, variables, run_once)
        combined_result = TaskResult(
            success=loop_result.success,
            stdout="",
            stderr="",
            result_values=loop_result.result_values,
        )
        handle_result_values(combined_result)
        if not combined_result.success:
            sys.exit(1)
        return

    result = run_once(variables)
    handle_result_values(result)
    if not result.success:
        sys.exit(1)


def cmd_task_run(args):
    """Run a named task."""
    configs = _get_configs(args.config_dir)
    cfg = _get_config(configs, args.repo_name)
    extra_vars = _merge_extra_vars(args)
    loop = _parse_loop_list(getattr(args, "loop", None))

    tasks = resolve_tasks(cfg)
    task_name = args.task_name
    if task_name not in tasks:
        available = list(tasks.keys())
        print(f"Error: task '{task_name}' not found. Available: {available}", file=sys.stderr)
        sys.exit(1)

    task_cfg = tasks[task_name]
    effective_task_cfg = dict(task_cfg)
    if args.repeat is not None:
        effective_task_cfg["repeat"] = args.repeat
    if args.repeat_agg is not None:
        effective_task_cfg["repeat_agg"] = args.repeat_agg
    variables = _build_variables(cfg, extra_vars, args.commit)

    if loop:
        try:
            loop_spec = normalize_loop_spec(loop)
            validate_loop_var_used(loop_spec, [effective_task_cfg], "current task")
        except (ConfigError, ValueError) as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

    print(bold(f"Running task '{task_name}' on {args.repo_name}..."))
    t0 = time.time()
    working_dir = variables["working_dir"]
    runner = TaskRunner()
    sourced_env = resolve_source_env(cfg, effective_task_cfg, variables, working_dir)
    result = runner.run(effective_task_cfg, working_dir, cfg.get("name", "unknown"),
                        task_name, variables, step_name=getattr(args, "step", None),
                        global_env=cfg.get("env"), sourced_env=sourced_env,
                        loop=loop)

    if result.success:
        print(green(f"Task '{task_name}' succeeded. ({format_elapsed(time.time() - t0)})"))
    else:
        print(red(f"Task '{task_name}' failed. ({format_elapsed(time.time() - t0)})"), file=sys.stderr)
        if result.artifact_errors:
            for err in result.artifact_errors:
                print(f"  Artifact check: {err}", file=sys.stderr)
        if result.stderr:
            print(result.stderr, file=sys.stderr)

    if result.result_values:
        for op, val in result.result_values.items():
            print(f"  {cyan(f'{op}')}: {val}")

    if not result.success:
        sys.exit(1)


def cmd_workflow(args):
    """Run a named workflow (sequence of tasks)."""
    configs = _get_configs(args.config_dir)
    cfg = _get_config(configs, args.repo_name)
    extra_vars = _merge_extra_vars(args)
    loop = _parse_loop_list(getattr(args, "loop", None))

    from forge.config import resolve_workflows
    from forge.workflow import WorkflowRunner

    tasks = resolve_tasks(cfg)
    workflows, warnings = resolve_workflows(cfg)
    for w in warnings:
        print(f"  Warning: {w}", file=sys.stderr)

    wf_name = args.workflow_name
    if wf_name not in workflows:
        available = list(workflows.keys())
        print(f"Error: workflow '{wf_name}' not found. Available: {available}", file=sys.stderr)
        sys.exit(1)

    workflow_cfg = workflows[wf_name]
    step_names = workflow_cfg.get("tasks", [])
    if not step_names:
        print(f"Error: workflow '{wf_name}' has no tasks", file=sys.stderr)
        sys.exit(1)

    # Validate all task names
    for task_name in step_names:
        if task_name not in tasks:
            print(f"Error: workflow '{wf_name}' references unknown task '{task_name}'. Available: {list(tasks.keys())}", file=sys.stderr)
            sys.exit(1)

    variables = _build_variables(cfg, extra_vars, args.commit)

    # Pre-check placeholders for all tasks in the workflow
    try:
        for task_name in step_names:
            check_task_placeholders(tasks[task_name], variables, cfg.get("vars"))
    except ConfigError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    if loop:
        try:
            loop_spec = normalize_loop_spec(loop)
            all_task_cfgs = [tasks[t] for t in step_names]
            validate_loop_var_used(loop_spec, all_task_cfgs, f"workflow '{wf_name}'")
        except (ConfigError, ValueError) as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

    print(bold(f"Running workflow '{wf_name}' on {args.repo_name}: {' → '.join(step_names)}"))
    t0 = time.time()

    working_dir = variables["working_dir"]
    runner = WorkflowRunner()
    result = runner.run(
        workflow_cfg, tasks, working_dir, cfg.get("name", "unknown"),
        variables, global_env=cfg.get("env"), config=cfg, loop=loop,
    )

    if result.success:
        print(green(f"\nWorkflow '{wf_name}' succeeded. ({format_elapsed(time.time() - t0)})"))
    else:
        print(red(f"\nWorkflow '{wf_name}' failed at task '{result.failed_step}'. ({format_elapsed(time.time() - t0)})"), file=sys.stderr)
        sys.exit(1)


def cmd_migrate(args):
    """Migrate config files from repo_path/test_path to working_dir."""
    from forge.migrate import migrate_file
    from pathlib import Path

    config_dir = Path(args.config_dir or os.environ.get("FORGE_CONFIG_DIR") or
                      os.path.join(os.path.dirname(__file__), "..", "configs"))

    if not config_dir.is_dir():
        print(f"Error: config directory not found: {config_dir}", file=sys.stderr)
        sys.exit(1)

    dry_run = getattr(args, "dry_run", False)
    total_changes = 0

    for path in sorted(config_dir.glob("*.json")):
        changes = migrate_file(path, dry_run=dry_run)
        if changes:
            label = "(dry run)" if dry_run else "(migrated)"
            print(f"{path.name} {label}:")
            for change in changes:
                print(f"  - {change}")
            total_changes += len(changes)

    if total_changes == 0:
        print("No configs need migration.")
    elif dry_run:
        print(f"\n{total_changes} change(s) would be made. Run without --dry-run to apply.")
    else:
        print(f"\n{total_changes} change(s) applied.")


def cmd_daemon(args):
    """Handle daemon subcommands."""
    from forge.daemon import Daemon, DaemonClient, is_daemon_running, get_daemon_pid

    if args.action == "start":
        if is_daemon_running():
            print(f"Daemon is already running (pid={get_daemon_pid()})")
            return

        daemon = Daemon()
        if args.foreground:
            print(f"Starting daemon in foreground (pid={os.getpid()})...")
            daemon.start(foreground=True)
        else:
            print("Starting daemon in background...")
            # Fork to background
            pid = os.fork()
            if pid == 0:
                # Child process
                os.setsid()
                daemon.start(foreground=True)
            else:
                time.sleep(0.5)
                if is_daemon_running():
                    print(f"Daemon started (pid={get_daemon_pid()})")
                else:
                    print("Failed to start daemon", file=sys.stderr)
                    sys.exit(1)

    elif args.action == "stop":
        client = DaemonClient()
        if not client.is_daemon_running():
            print("Daemon is not running")
            return

        pid = get_daemon_pid()
        try:
            os.kill(pid, signal.SIGTERM)
            time.sleep(0.5)
            print(f"Daemon stopped (pid={pid})")
        except ProcessLookupError:
            print("Daemon process not found")

    elif args.action == "status":
        client = DaemonClient()
        if not client.is_daemon_running():
            print("Daemon is not running")
            return

        response = client.send({"action": "status"})
        if response.get("status") == "ok":
            print(f"Daemon: running (pid={response.get('pid')})")
            tasks = response.get("tasks", {})
            print(f"Tasks: {tasks.get('pending', 0)} pending, {tasks.get('running', 0)} running, {tasks.get('completed', 0)} completed")
        else:
            print("Failed to get daemon status")

    elif args.action == "install":
        from forge.daemon import install_systemd_service, SERVICE_FILE_PATH
        if os.geteuid() != 0:
            print("Error: install requires root privileges. Use: sudo forge daemon install")
            sys.exit(1)
        print("Installing forge-daemon systemd service...")
        if install_systemd_service():
            print(f"Service installed at {SERVICE_FILE_PATH}")
            print("Run 'systemctl status forge-daemon' to check status")
        else:
            print("Failed to install service", file=sys.stderr)
            sys.exit(1)

    elif args.action == "uninstall":
        from forge.daemon import uninstall_systemd_service, SERVICE_FILE_PATH
        if os.geteuid() != 0:
            print("Error: uninstall requires root privileges. Use: sudo forge daemon uninstall")
            sys.exit(1)
        print("Uninstalling forge-daemon systemd service...")
        if uninstall_systemd_service():
            print("Service uninstalled")
        else:
            print("Failed to uninstall service", file=sys.stderr)
            sys.exit(1)


def cmd_task(args):
    """Handle task subcommands."""
    from forge.daemon import DaemonClient
    from forge.task_state import list_task_states

    client = DaemonClient()

    if args.action == "list":
        status_filter = None
        if args.running:
            status_filter = "running"
        elif args.completed:
            status_filter = "completed"
        elif not args.all:
            status_filter = "running"  # Default to running

        if client.is_daemon_running():
            response = client.send({"action": "list", "filter": status_filter})
            tasks = response.get("tasks", [])
        else:
            # Fall back to reading task files directly
            tasks = [t.to_dict() for t in list_task_states(status=status_filter)]

        if not tasks:
            print("No tasks found")
            return

        for task in tasks:
            status = task.get("status", "unknown")
            task_id = task.get("task_id", "?")
            command = task.get("command", "?")
            progress = task.get("progress", {})

            status_str = {
                "pending": yellow("pending"),
                "running": green("running"),
                "completed": green("completed"),
                "failed": red("failed"),
                "cancelled": dim("cancelled"),
                "interrupted": red("interrupted"),
            }.get(status, status)

            print(f"  {task_id}: {command} [{status_str}]")
            if progress:
                current = progress.get("current", 0)
                total = progress.get("total", 0)
                if total > 0:
                    print(f"    Progress: {current}/{total}")

    elif args.action == "cancel":
        if not args.task_id:
            print("Error: task_id required for cancel", file=sys.stderr)
            sys.exit(1)

        if not client.is_daemon_running():
            print("Error: daemon is not running", file=sys.stderr)
            sys.exit(1)

        response = client.send({"action": "cancel", "task_id": args.task_id})
        if response.get("status") == "ok":
            print(f"Task {args.task_id} cancelled")
        else:
            print(f"Error: {response.get('message')}", file=sys.stderr)
            sys.exit(1)

    elif args.action == "resume":
        if not args.task_id:
            print("Error: task_id required for resume", file=sys.stderr)
            sys.exit(1)

        from forge.task_state import load_task_state, save_task_state

        state = load_task_state(args.task_id)
        if not state:
            print(f"Error: task {args.task_id} not found", file=sys.stderr)
            sys.exit(1)

        if state.status not in ("interrupted", "failed"):
            print(f"Error: task is {state.status}, cannot resume", file=sys.stderr)
            sys.exit(1)

        if not client.is_daemon_running():
            print("Error: daemon is not running", file=sys.stderr)
            sys.exit(1)

        # Reset task to pending
        state.status = "pending"
        save_task_state(state)

        response = client.send({"action": "submit", "command": state.command, "args": state.args})
        if response.get("status") == "ok":
            print(f"Task {args.task_id} resumed as {response.get('task_id')}")
        else:
            print(f"Error: {response.get('message')}", file=sys.stderr)
            sys.exit(1)

    elif args.action == "show":
        if not args.task_id:
            print("Error: task_id required for show", file=sys.stderr)
            sys.exit(1)

        from forge.task_state import load_task_state
        state = load_task_state(args.task_id)
        if not state:
            print(f"Error: task {args.task_id} not found", file=sys.stderr)
            sys.exit(1)

        from forge.task_output import read_log_tail, follow_log
        from pathlib import Path
        import signal
        import threading

        log_path = str(Path.home() / ".forge" / "logs" / f"{args.task_id}.log")

        if args.follow:
            # Real-time follow mode
            def consumer(text):
                print(text, end="")
                sys.stdout.flush()

            stop_event = threading.Event()

            def signal_handler(signum, frame):
                stop_event.set()

            old_handler = signal.signal(signal.SIGINT, signal_handler)
            try:
                follow_log(log_path, consumer, stop_event, poll_interval=0.1)
            finally:
                signal.signal(signal.SIGINT, old_handler)
        else:
            # Static display mode
            content = read_log_tail(log_path, lines=args.tail)
            if content:
                print(content, end="")
            else:
                print(f"No output available for task {args.task_id}", file=sys.stderr)


def cmd_web(args):
    """Dispatch to the forge_web CLI entry point."""
    try:
        from forge_web.backend.cli import main as web_main
    except ImportError:
        print(
            "error: the web UI requires the 'web' extra.\n"
            "Install it with: pip install 'ascend-forge[web]'",
            file=sys.stderr,
        )
        return 1
    return web_main(args.web_args)


def _add_common_args(parser):
    """Add --arg, --op, --cs, and --ip to a subparser."""
    parser.add_argument("--arg", action="append", metavar="KEY=VALUE|@FILE",
                        help="Pass variable to config placeholders (e.g. --arg op_name=matmul or --arg @vars.json)")
    parser.add_argument("--op", default=None, help="Shortcut for --arg op_name=VALUE")
    parser.add_argument("--cs", default=None, help="Shortcut for --arg case=VALUE")
    parser.add_argument("--ip", default=None, help="Shortcut for --arg install_path=VALUE")


def _run_under_daemon(args) -> None:
    """Submit the current command to the daemon."""
    from forge.daemon import DaemonClient, is_daemon_running
    supported_commands = {"build", "test", "bisect"}

    if args.command not in supported_commands:
        print(
            f"Error: --daemon currently supports only {', '.join(sorted(supported_commands))}.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Start daemon if not running
    if not is_daemon_running():
        print("Starting daemon...")
        # Fork to start daemon
        pid = os.fork()
        if pid == 0:
            # Child process - start daemon
            os.setsid()
            from forge.daemon import Daemon
            daemon = Daemon()
            daemon.start(foreground=True)
            sys.exit(0)
        else:
            # Wait for daemon to start
            time.sleep(1.0)
            if not is_daemon_running():
                print("Failed to start daemon", file=sys.stderr)
                sys.exit(1)

    # Build task args from parsed arguments
    task_args = _build_task_args(args)

    client = DaemonClient()
    response = client.send({
        "action": "submit",
        "command": args.command,
        "args": task_args,
        "config_path": args.config_dir,
    })

    if response.get("status") == "ok":
        task_id = response.get("task_id")
        print(f"Task submitted: {task_id} (running in background)")
        print(f"Use 'forge task list' to check progress")
        print(f"Use 'forge task show {task_id}' for details")
    else:
        print(f"Error: {response.get('message')}", file=sys.stderr)
        sys.exit(1)


def _build_task_args(args) -> dict:
    """Build task arguments from parsed CLI args."""
    task_args = {}
    extra_args = _parse_args_list(getattr(args, "arg", None))

    if hasattr(args, "repo_name"):
        task_args["repo"] = args.repo_name
    if hasattr(args, "type") and args.type:
        task_args["type"] = args.type
    if hasattr(args, "commit") and args.commit:
        task_args["commit"] = args.commit
    if hasattr(args, "step") and args.step:
        task_args["step"] = args.step
    if hasattr(args, "repeat") and args.repeat:
        task_args["repeat"] = args.repeat
    if hasattr(args, "repeat_agg") and args.repeat_agg:
        task_args["repeat_agg"] = args.repeat_agg
    if hasattr(args, "baseline") and args.baseline:
        task_args["baseline"] = args.baseline
    if hasattr(args, "compare_last") and args.compare_last:
        task_args["compare_last"] = args.compare_last
    if hasattr(args, "workflow") and args.workflow:
        task_args["workflow"] = args.workflow
    if hasattr(args, "good") and args.good:
        task_args["good"] = args.good
    if hasattr(args, "bad") and args.bad:
        task_args["bad"] = args.bad
    if hasattr(args, "regression") and args.regression:
        task_args["regression"] = args.regression
    if hasattr(args, "threshold") and args.threshold:
        task_args["threshold"] = args.threshold
    if hasattr(args, "op") and args.op and "op_name" not in extra_args:
        task_args["op_name"] = args.op
    if hasattr(args, "cs") and args.cs and "case" not in extra_args:
        extra_args["case"] = args.cs
    if hasattr(args, "ip") and args.ip and "install_path" not in extra_args:
        extra_args["install_path"] = args.ip
    loop = _parse_loop_list(getattr(args, "loop", None))
    if loop:
        task_args["loop"] = loop
    if extra_args:
        task_args["extra_args"] = extra_args

    return task_args


def _resolve_test_type(raw: str) -> str:
    """Resolve abbreviated test type to full name."""
    aliases = {"acc": "accuracy", "perf": "performance"}
    return aliases.get(raw, raw)


def build_parser():
    """Build and return the argument parser."""
    parser = argparse.ArgumentParser(prog="forge", description="forge - NPU operator build & test framework")
    parser.add_argument("--config-dir", default=None, help="Config directory path")
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable verbose output")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    parser.add_argument("--daemon", action="store_true", help="Run command under daemon supervision")

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # list
    subparsers.add_parser("list", help="List all configured repos")

    # show
    p_show = subparsers.add_parser("show", help="Show detailed config for a repo")
    p_show.add_argument("repo_name", help="Repository name")

    # usage
    p_usage = subparsers.add_parser("usage", help="Show human-readable usage for a repo")
    p_usage.add_argument("repo_name", help="Repository name")

    # validate
    p_validate = subparsers.add_parser("validate", help="Validate a repo's config")
    p_validate.add_argument("repo_name", help="Repository name")

    # build
    p_build = subparsers.add_parser("build", help="Build an operator repo")
    p_build.add_argument("repo_name", help="Repository name")
    p_build.add_argument("-c", "--commit", default=None, help="Build at a specific commit")
    p_build.add_argument("-s", "--step", default=None, help="Run only the named step (e.g. --step install)")
    _add_common_args(p_build)

    # test
    p_test = subparsers.add_parser("test", help="Run tests on an operator repo")
    p_test.add_argument("repo_name", help="Repository name")
    p_test.add_argument("-t", "--type", required=True, help="Test type (accuracy/acc, performance/perf)")
    p_test.add_argument("-c", "--commit", default=None, help="Test at a specific commit (auto-builds)")
    p_test.add_argument("-b", "--baseline", default=None, help="Compare with results from this commit")
    p_test.add_argument("--compare-last", action="store_true", help="Compare with last saved result")
    p_test.add_argument("--repeat", type=int, default=None, help="Run performance test N times and aggregate results")
    p_test.add_argument("--repeat-agg", default=None, choices=REPEAT_AG_CHOICES, help="Repeat aggregation method (default: avg)")
    _add_common_args(p_test)

    # bisect
    p_bisect = subparsers.add_parser("bisect", help="Bisect to find the commit that introduced a problem")
    p_bisect.add_argument("repo_name", help="Repository name")
    p_bisect.add_argument("-g", "--good", required=True, help="Known good commit")
    p_bisect.add_argument("-b", "--bad", required=True, help="Known bad commit")
    p_bisect.add_argument("-t", "--type", default=None, help="DEPRECATED: test_type is now read from bisect.test_type config")
    p_bisect.add_argument("-w", "--workflow", default=None, help="Workflow name for bisect (overrides config bisect.workflow)")
    p_bisect.add_argument("--regression", type=float, default=None, help="Regression threshold percentage (overrides config, default: 10)")
    p_bisect.add_argument("--threshold", type=float, default=None, help="Absolute performance threshold (overrides config)")
    p_bisect.add_argument("--repeat", type=int, default=None, help="Repeat test N times per bisect step")
    p_bisect.add_argument("--repeat-agg", default=None, choices=REPEAT_AG_CHOICES, help="Repeat aggregation method (default: avg)")
    _add_common_args(p_bisect)

    # run (build + test)
    p_run = subparsers.add_parser("run", help="Build then test in one command")
    p_run.add_argument("repo_name", help="Repository name")
    p_run.add_argument("-t", "--type", required=True, help="Test type (accuracy/acc, performance/perf)")
    p_run.add_argument("-c", "--commit", default=None, help="Build and test at a specific commit")
    p_run.add_argument("-s", "--step", default=None, help="Run only the named build step")
    p_run.add_argument("-b", "--baseline", default=None, help="Compare with results from this commit")
    p_run.add_argument("--compare-last", action="store_true", help="Compare with last saved result")
    p_run.add_argument("--repeat", type=int, default=None, help="Run performance test N times and aggregate results")
    p_run.add_argument("--repeat-agg", default=None, choices=REPEAT_AG_CHOICES, help="Repeat aggregation method (default: avg)")
    _add_common_args(p_run)
    _add_loop_arg(p_run)

    # task-run (run a named task from config)
    p_task_run = subparsers.add_parser("task-run", help="Run a named task from config")
    p_task_run.add_argument("repo_name", help="Repository name")
    p_task_run.add_argument("task_name", help="Task name (from config tasks section, or 'build', 'test_accuracy', etc.)")
    p_task_run.add_argument("-c", "--commit", default=None, help="Run at a specific commit")
    p_task_run.add_argument("-s", "--step", default=None, help="Run only the named step")
    p_task_run.add_argument("--repeat", type=int, default=None, help="Run task N times and aggregate numeric results")
    p_task_run.add_argument("--repeat-agg", default=None, choices=REPEAT_AG_CHOICES, help="Repeat aggregation method (default: avg)")
    _add_common_args(p_task_run)
    _add_loop_arg(p_task_run)

    # workflow (multi-task sequence)
    p_wf = subparsers.add_parser("workflow", help="Run a named workflow (sequence of tasks)")
    p_wf.add_argument("repo_name", help="Repository name")
    p_wf.add_argument("workflow_name", help="Workflow name (from config workflows section)")
    p_wf.add_argument("-c", "--commit", default=None, help="Run at a specific commit")
    _add_common_args(p_wf)
    _add_loop_arg(p_wf)

    # daemon subcommand
    p_daemon = subparsers.add_parser("daemon", help="Manage the forge daemon process")
    p_daemon.add_argument("action", choices=["start", "stop", "status", "install", "uninstall"], help="Daemon action")
    p_daemon.add_argument("--foreground", action="store_true", help="Run daemon in foreground")

    # task subcommand
    p_task = subparsers.add_parser("task", help="Manage background tasks")
    p_task.add_argument("action", choices=["list", "cancel", "resume", "show"], help="Task action")
    p_task.add_argument("task_id", nargs="?", help="Task ID (for cancel/resume/show)")
    p_task.add_argument("--all", action="store_true", help="Show all tasks")
    p_task.add_argument("--running", action="store_true", help="Show only running tasks")
    p_task.add_argument("--completed", action="store_true", help="Show only completed tasks")
    p_task.add_argument("--tail", type=int, default=100,
                        help="Number of last lines to show (default: 100)")
    p_task.add_argument("--follow", action="store_true",
                        help="Follow log output in real-time (Ctrl+C to stop)")

    # migrate subcommand
    p_migrate = subparsers.add_parser("migrate", help="Migrate configs from repo_path to working_dir")
    p_migrate.add_argument("--dry-run", action="store_true", help="Show changes without applying them")

    # web subcommand: dispatch to forge_web.backend.cli, forwarding remaining args
    p_web = subparsers.add_parser("web", help="Start local web UI (requires forge[web] extra)")
    p_web.add_argument("web_args", nargs=argparse.REMAINDER,
                       help="Arguments forwarded to `forge-web`")

    return parser


def main(argv=None):
    # Special-case `web`: forward all remaining args to forge_web.backend.cli
    # without letting the top-level parser try to interpret them. This avoids
    # argparse REMAINDER quirks where leading `--no-open` is misclaimed by the
    # top-level parser.
    raw_argv = list(sys.argv[1:] if argv is None else argv)
    if "web" in raw_argv:
        idx = raw_argv.index("web")
        # Only intercept when `web` is the subcommand (no other positional before it).
        # Top-level options like -v / --debug / --config-dir before `web` are allowed.
        try:
            from forge_web.backend.cli import main as web_main
        except ImportError:
            print(
                "error: the web UI requires the 'web' extra.\n"
                "Install it with: pip install 'ascend-forge[web]'",
                file=sys.stderr,
            )
            return 1
        return web_main(raw_argv[idx + 1:])

    parser = build_parser()
    args = parser.parse_args(argv)
    _setup_logging(args.debug)
    set_verbose(args.verbose)
    set_debug(args.debug)

    # Handle --daemon flag
    daemon_mode = getattr(args, "daemon", False)
    if daemon_mode and args.command not in ("daemon", "task"):
        return _run_under_daemon(args)

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    # Resolve type abbreviations
    if hasattr(args, "type") and args.type:
        args.type = _resolve_test_type(args.type)

    commands = {
        "list": cmd_list,
        "show": cmd_show,
        "usage": cmd_usage,
        "validate": cmd_validate,
        "build": cmd_build,
        "test": cmd_test,
        "bisect": cmd_bisect,
        "run": cmd_run,
        "task-run": cmd_task_run,
        "workflow": cmd_workflow,
        "daemon": cmd_daemon,
        "task": cmd_task,
        "migrate": cmd_migrate,
        "web": cmd_web,
    }
    return commands[args.command](args)


if __name__ == "__main__":
    main()
