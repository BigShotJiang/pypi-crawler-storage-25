"""Shared parameter-list loop execution helpers."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from forge.config import ConfigError, collect_placeholders


@dataclass(eq=True)
class LoopSpec:
    """A single-variable loop specification."""

    var: str
    values: list[str]
    fail_fast: bool = True


@dataclass
class LoopIterationResult:
    """Result metadata for one loop value."""

    value: str
    success: bool
    result_values: dict[str, float] | None = None
    error: str | None = None
    result: Any | None = None


@dataclass
class LoopResult:
    """Aggregated result for a loop execution."""

    success: bool
    iterations: list[LoopIterationResult] = field(default_factory=list)
    result_values: dict[str, float] | None = None
    failed_value: str | None = None
    last_result: Any | None = None


def normalize_loop_spec(raw: LoopSpec | dict[str, Any] | None) -> LoopSpec | None:
    """Validate and normalize a raw loop spec."""
    if raw is None:
        return None
    if isinstance(raw, LoopSpec):
        var = raw.var.strip()
        values = [str(value).strip() for value in raw.values if str(value).strip()]
        fail_fast = raw.fail_fast
    elif isinstance(raw, dict):
        var = str(raw.get("var", "")).strip()
        raw_values = raw.get("values", [])
        if not isinstance(raw_values, list):
            raise ValueError("loop.values must be a list of strings")
        values = [str(value).strip() for value in raw_values if str(value).strip()]
        fail_fast = bool(raw.get("fail_fast", True))
    else:
        raise ValueError("loop must be an object with var and values")

    if not var:
        raise ValueError("loop.var must be a non-empty string")
    if not values:
        raise ValueError("loop.values must contain at least one value")
    return LoopSpec(var=var, values=values, fail_fast=fail_fast)


def validate_loop_var_used(spec: LoopSpec | None, sections: list[Any], context: str) -> None:
    """Ensure the loop variable appears in at least one relevant config section."""
    if spec is None:
        return
    needed: set[str] = set()
    for section in sections:
        needed.update(collect_placeholders(section))
    if spec.var not in needed:
        raise ConfigError(
            f"loop variable {{{spec.var}}} is not used in {context}. "
            "Choose a placeholder referenced by the selected task or workflow."
        )


def run_loop(
    spec: LoopSpec | dict[str, Any],
    variables: dict[str, str],
    run_once: Callable[[dict[str, str]], Any],
) -> LoopResult:
    """Run one callable for each loop value using isolated variables."""
    normalized = normalize_loop_spec(spec)

    iterations: list[LoopIterationResult] = []
    combined: dict[str, float] = {}
    failed_value: str | None = None
    last_result: Any | None = None

    for value in normalized.values:
        iter_vars = dict(variables)
        iter_vars[normalized.var] = value
        result = run_once(iter_vars)
        last_result = result

        success = bool(getattr(result, "success", False))
        result_values = getattr(result, "result_values", None)
        if result_values:
            for key, metric_value in result_values.items():
                combined[f"{value}/{key}"] = metric_value

        error = None
        if not success:
            failed_value = value
            error = getattr(result, "stderr", "")

        iterations.append(
            LoopIterationResult(
                value=value,
                success=success,
                result_values=result_values,
                error=error,
                result=result,
            )
        )

        if not success and normalized.fail_fast:
            break

    success = bool(iterations) and all(item.success for item in iterations)
    if len(iterations) != len(normalized.values):
        success = False

    return LoopResult(
        success=success,
        iterations=iterations,
        result_values=combined or None,
        failed_value=failed_value,
        last_result=last_result,
    )
