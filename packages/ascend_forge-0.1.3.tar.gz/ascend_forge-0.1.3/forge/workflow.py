"""Workflow execution engine — runs named task sequences with variable passing."""

import logging
from dataclasses import dataclass, field

from forge.loop import normalize_loop_spec, run_loop
from forge.task import (
    TaskRunner,
    TaskResult,
    _aggregate_repeat_results,
    _format_outlier_analysis,
    process_capture,
    resolve_source_env,
)

logger = logging.getLogger(__name__)


@dataclass
class StepResult:
    """Result of a single workflow step."""
    task_name: str
    task_result: TaskResult


@dataclass
class WorkflowResult:
    """Result of a complete workflow execution."""
    success: bool
    step_results: list[StepResult] = field(default_factory=list)
    result_values: dict | None = None
    failed_step: str | None = None  # task name, or loop variable value in loop mode


class WorkflowRunner:
    """Execute a workflow: a sequence of named tasks with shared variables."""

    def run(self, workflow_cfg: dict, tasks: dict, working_dir: str,
            repo_name: str, variables: dict, global_env: dict | None = None,
            config: dict | None = None,
            repeat: int | None = 1, repeat_agg: str = "avg",
            outlier_detection_cfg: dict | None = None,
            loop=None) -> WorkflowResult:
        """Run all tasks in a workflow sequentially.

        Args:
            workflow_cfg: Workflow config with "tasks" list of task names.
            tasks: Dict of task_name -> task_config.
            working_dir: Base working directory for tasks.
            repo_name: Name of the repository.
            variables: Shared variables dict (mutated in-place by capture).
            global_env: Global environment variables from config.
            config: Full config dict (for source_env resolution).
            repeat: Number of times to repeat the workflow (default 1). None is treated as 1.
            repeat_agg: Aggregation method for result_values (avg/max, default avg).

        Raises:
            ValueError: If repeat is less than 1.
        """
        # Handle None and validate
        if repeat is None:
            repeat = 1
        if repeat < 1:
            raise ValueError(f"repeat must be >= 1, got {repeat}")

        loop_spec = normalize_loop_spec(loop)
        if loop_spec is not None:
            loop_result = run_loop(
                loop_spec,
                variables,
                lambda iter_vars: self.run(
                    workflow_cfg,
                    tasks,
                    working_dir,
                    repo_name,
                    iter_vars,
                    global_env=global_env,
                    config=config,
                    repeat=repeat,
                    repeat_agg=repeat_agg,
                    outlier_detection_cfg=outlier_detection_cfg,
                    loop=None,
                ),
            )
            last = loop_result.last_result
            return WorkflowResult(
                success=loop_result.success,
                step_results=getattr(last, "step_results", []) if last else [],
                result_values=loop_result.result_values,
                failed_step=loop_result.failed_value,
            )

        if repeat <= 1:
            return self._run_once(workflow_cfg, tasks, working_dir, repo_name,
                                 variables, global_env, config)

        # Multiple runs: aggregate results
        all_results = []
        for i in range(repeat):
            result = self._run_once(workflow_cfg, tasks, working_dir, repo_name,
                                    variables, global_env, config)
            all_results.append(result)
            if not result.success:
                return result  # Fail fast on first failure

        return self._aggregate_workflow_results(
            all_results, repeat_agg, outlier_detection_cfg=outlier_detection_cfg,
        )

    def _run_once(self, workflow_cfg: dict, tasks: dict, working_dir: str,
                  repo_name: str, variables: dict, global_env: dict | None = None,
                  config: dict | None = None) -> WorkflowResult:
        """Execute workflow once. Original run() logic moved here."""
        task_names = workflow_cfg["tasks"]
        step_results = []

        from forge.log import bold, cyan

        for i, task_name in enumerate(task_names):
            task_cfg = tasks[task_name]
            print(f"\n{bold(cyan(f'[{i+1}/{len(task_names)}]'))} {bold(f'Task: {task_name}')}")

            sourced_env = None
            if config:
                sourced_env = resolve_source_env(config, task_cfg, variables, working_dir)

            runner = TaskRunner()
            task_result = runner.run(
                task_cfg, working_dir, repo_name, task_name, variables,
                global_env=global_env, sourced_env=sourced_env,
            )

            step_results.append(StepResult(task_name=task_name, task_result=task_result))

            # For single-step tasks (no sub-steps), handle top-level capture here.
            # Multi-step tasks process capture inside _run_multi_step per sub-step.
            if "capture" in task_cfg and "steps" not in task_cfg and task_result.stdout:
                process_capture(task_cfg["capture"], task_result.stdout, variables)

            if task_result.result_values:
                for op, val in task_result.result_values.items():
                    print(f"  {cyan(f'{op}')}: {val}")

            if not task_result.success:
                return WorkflowResult(
                    success=False,
                    step_results=step_results,
                    failed_step=task_name,
                )

        # result_values from the last step
        last_result_values = None
        if step_results:
            last_result_values = step_results[-1].task_result.result_values

        return WorkflowResult(
            success=True,
            step_results=step_results,
            result_values=last_result_values,
        )

    def _aggregate_workflow_results(self, all_results: list[WorkflowResult],
                                     agg_method: str = "avg",
                                     outlier_detection_cfg: dict | None = None) -> WorkflowResult:
        """Aggregate multiple workflow execution results.

        - success: all must succeed
        - result_values: aggregated by agg_method
        - step_results: from last execution

        Raises:
            ValueError: If all_results is empty.
        """
        if not all_results:
            raise ValueError("Cannot aggregate empty results list")

        # If any failed, return first failure
        for result in all_results:
            if not result.success:
                return result

        all_values = [r.result_values for r in all_results if r.result_values]

        if not all_values:
            # No result_values, return last result
            return all_results[-1]

        if agg_method in {"avg", "max", "avg_without_outliers"}:
            aggregated, _, outlier_analyses = _aggregate_repeat_results(
                all_values, agg_method, outlier_detection_cfg=outlier_detection_cfg,
            )
        else:
            # Preserve the previous fallback behavior for unknown methods.
            aggregated = {}
            for key in all_values[0].keys():
                vals = [v.get(key) for v in all_values if v.get(key) is not None]
                aggregated[key] = vals[-1] if vals else None
            outlier_analyses = []

        any_outlier_failure = False
        for analysis in outlier_analyses:
            print(f"  {_format_outlier_analysis(analysis)}")
            if analysis.failure:
                any_outlier_failure = True

        failed_step = None
        if any_outlier_failure and all_results[-1].step_results:
            failed_step = all_results[-1].step_results[-1].task_name

        return WorkflowResult(
            success=not any_outlier_failure,
            step_results=all_results[-1].step_results,
            result_values=aggregated,
            failed_step=failed_step,
        )
