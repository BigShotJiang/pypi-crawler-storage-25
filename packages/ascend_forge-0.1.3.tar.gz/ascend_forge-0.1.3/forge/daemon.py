"""Daemon process for managing forge tasks."""

import json
import logging
import os
import signal
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Callable

from forge.task_state import (
    TaskState,
    delete_task_state,
    generate_task_id,
    list_task_states,
    load_task_state,
    mark_completed,
    mark_failed,
    mark_interrupted,
    mark_running,
    save_task_state,
)

logger = logging.getLogger(__name__)


def _setup_daemon_logging() -> None:
    """Set up file logging for daemon events to ~/.forge/logs/daemon.log."""
    log_dir = Path.home() / ".forge" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / "daemon.log"
    handler = logging.FileHandler(log_path)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(handler)


def _socket_path() -> Path:
    """Get the Unix socket path."""
    return Path.home() / ".forge" / "daemon.sock"


def _pid_path() -> Path:
    """Get the daemon PID file path."""
    return Path.home() / ".forge" / "daemon.pid"


class DaemonSocketServer:
    """Unix socket server for daemon communication."""

    def __init__(self, handler: Callable[[dict], dict] | None = None):
        self._handler = handler or self._default_handler
        self._socket_path = _socket_path()
        self._running = False
        self._thread: threading.Thread | None = None
        self._server_socket: socket.socket | None = None

    def _default_handler(self, request: dict) -> dict:
        """Default request handler."""
        action = request.get("action")
        if action == "status":
            return {"status": "ok", "pid": os.getpid(), "running": True}
        return {"status": "error", "message": f"Unknown action: {action}"}

    def is_running(self) -> bool:
        """Check if server is running."""
        return self._running

    def start(self) -> None:
        """Start the socket server in a background thread."""
        if self._running:
            return

        # Ensure directory exists
        self._socket_path.parent.mkdir(parents=True, exist_ok=True)

        # Remove stale socket file
        if self._socket_path.exists():
            self._socket_path.unlink()

        self._server_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self._server_socket.bind(str(self._socket_path))
        self._server_socket.listen(5)
        self._server_socket.settimeout(1.0)  # Allow periodic checking for stop

        self._running = True
        self._thread = threading.Thread(target=self._run_server, daemon=True)
        self._thread.start()

        logger.debug(f"Daemon socket server started at {self._socket_path}")

    def _run_server(self) -> None:
        """Run the server loop."""
        while self._running:
            try:
                conn, _ = self._server_socket.accept()
                self._handle_connection(conn)
            except socket.timeout:
                continue  # Check if still running
            except OSError:
                break  # Socket closed

    def _handle_connection(self, conn: socket.socket) -> None:
        """Handle a client connection."""
        try:
            data = b""
            while True:
                chunk = conn.recv(4096)
                if not chunk:
                    break
                data += chunk

            if data:
                request = json.loads(data.decode())
                response = self._handler(request)
                conn.sendall(json.dumps(response).encode())
        except Exception as e:
            logger.error(f"Error handling connection: {e}")
            conn.sendall(json.dumps({"status": "error", "message": str(e)}).encode())
        finally:
            conn.close()

    def stop(self) -> None:
        """Stop the socket server."""
        self._running = False
        if self._server_socket:
            self._server_socket.close()
        if self._socket_path.exists():
            self._socket_path.unlink()
        if self._thread:
            self._thread.join(timeout=2.0)
        logger.debug("Daemon socket server stopped")


class DaemonClient:
    """Client for communicating with the daemon."""

    def __init__(self, timeout: float = 5.0):
        self._socket_path = _socket_path()
        self._timeout = timeout

    def is_daemon_running(self) -> bool:
        """Check if daemon is running."""
        if not self._socket_path.exists():
            return False
        # Try to connect
        try:
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.settimeout(1.0)
            sock.connect(str(self._socket_path))
            sock.close()
            return True
        except (socket.error, socket.timeout):
            return False

    def send(self, request: dict) -> dict:
        """Send a request to the daemon and get response."""
        if not self.is_daemon_running():
            return {"status": "error", "message": "Daemon is not running"}

        try:
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.settimeout(self._timeout)
            sock.connect(str(self._socket_path))
            sock.sendall(json.dumps(request).encode())
            sock.shutdown(socket.SHUT_WR)  # Signal end of request

            data = b""
            while True:
                chunk = sock.recv(4096)
                if not chunk:
                    break
                data += chunk

            sock.close()
            return json.loads(data.decode())
        except socket.timeout:
            return {"status": "error", "message": "Daemon request timed out"}
        except socket.error as e:
            return {"status": "error", "message": f"Socket error: {e}"}


class TaskManager:
    """Manages task lifecycle."""

    def __init__(self):
        self._active_tasks: dict[str, subprocess.Popen] = {}

    def submit_task(self, command: str, args: dict, config_path: str | None = None,
                    verbose: bool = False,
                    owner: str | None = None,
                    client_ip: str | None = None) -> TaskState:
        """Submit a new task."""
        task_id = generate_task_id()
        state = TaskState(
            task_id=task_id,
            command=command,
            args=args,
            config_path=config_path,
            status="pending",
            verbose=verbose,
            owner=owner,
            client_ip=client_ip,
        )
        save_task_state(state)
        logger.info(f"Submitted task {task_id}: {command} (verbose={verbose})")
        return state

    def start_task(self, task_id: str) -> bool:
        """Start a pending task."""
        state = load_task_state(task_id)
        if not state or state.status != "pending":
            return False

        # Build the forge command
        cmd = self._build_command(state)

        # Start the subprocess
        try:
            # Set up task log environment
            log_dir = Path.home() / ".forge" / "logs"
            log_dir.mkdir(parents=True, exist_ok=True)
            task_log_path = str(log_dir / f"{task_id}.log")

            # Build env with FORGE_TASK_LOG
            task_env = dict(os.environ)
            task_env["FORGE_TASK_LOG"] = task_log_path

            # Redirect stdout/stderr to task log file so output is captured
            # even in non-streaming (buffered) mode, and to prevent SIGPIPE
            # when the daemon's own stdout/stderr are closed after daemonization.
            log_fh = open(task_log_path, "a", buffering=1)
            proc = subprocess.Popen(cmd, start_new_session=True, env=task_env,
                                    stdout=log_fh, stderr=log_fh)
            state = mark_running(state, proc.pid)
            save_task_state(state)
            self._active_tasks[task_id] = proc
            logger.info(f"Started task {task_id} (pid={proc.pid})")
            return True
        except Exception as e:
            logger.error(f"Failed to start task {task_id}: {e}")
            state = mark_failed(state, str(e))
            save_task_state(state)
            return False

    def _append_loop_args(self, cmd: list[str], loop: dict | None) -> None:
        if not loop:
            return
        var = loop.get("var")
        if not var:
            return
        for value in loop.get("values", []):
            cmd.extend(["--loop", f"{var}={value}"])

    def _build_command(self, state: TaskState) -> list[str]:
        """Build the forge command from task state."""
        cmd = ["forge"]
        if state.verbose:
            cmd.append("-v")
        cmd.append(state.command)

        args = state.args
        extra_args = args.get("extra_args", {})
        # Args that have dedicated CLI flags
        handled_keys = {
            "repo",
            "type",
            "repeat",
            "repeat_agg",
            "good",
            "bad",
            "commit",
            "step",
            "baseline",
            "compare_last",
            "workflow",
            "regression",
            "threshold",
            "op_name",
            "task",
            "extra_args",
            "loop",
        }

        if state.command == "test":
            if "repo" in args:
                cmd.append(args["repo"])
            if "type" in args:
                cmd.extend(["--type", args["type"]])
            if "repeat" in args:
                cmd.extend(["--repeat", str(args["repeat"])])
            if "repeat_agg" in args:
                cmd.extend(["--repeat-agg", args["repeat_agg"]])
            if "op_name" in args:
                cmd.extend(["--op", args["op_name"]])
            if "baseline" in args:
                cmd.extend(["--baseline", args["baseline"]])
            if "compare_last" in args:
                cmd.append("--compare-last")
        elif state.command == "bisect":
            if "repo" in args:
                cmd.append(args["repo"])
            if "good" in args:
                cmd.extend(["--good", args["good"]])
            if "bad" in args:
                cmd.extend(["--bad", args["bad"]])
            if "type" in args:
                cmd.extend(["--type", args["type"]])
            if "op_name" in args:
                cmd.extend(["--op", args["op_name"]])
            if "workflow" in args:
                cmd.extend(["--workflow", args["workflow"]])
            if "regression" in args:
                cmd.extend(["--regression", args["regression"]])
            if "repeat" in args:
                cmd.extend(["--repeat", str(args["repeat"])])
            if "repeat_agg" in args:
                cmd.extend(["--repeat-agg", args["repeat_agg"]])
            if "threshold" in args:
                cmd.extend(["--threshold", str(args["threshold"])])
        elif state.command == "build":
            if "repo" in args:
                cmd.append(args["repo"])
            if "commit" in args:
                cmd.extend(["--commit", args["commit"]])
            if "step" in args:
                cmd.extend(["--step", args["step"]])
            if "op_name" in args:
                cmd.extend(["--op", args["op_name"]])
        elif state.command == "task-run":
            if "repo" in args:
                cmd.append(args["repo"])
            if "task" in args:
                cmd.append(args["task"])
            if "commit" in args:
                cmd.extend(["--commit", args["commit"]])
            if "step" in args:
                cmd.extend(["--step", args["step"]])
            if "repeat" in args:
                cmd.extend(["--repeat", str(args["repeat"])])
            if "repeat_agg" in args:
                cmd.extend(["--repeat-agg", args["repeat_agg"]])
            if "op_name" in args:
                cmd.extend(["--op", args["op_name"]])
            self._append_loop_args(cmd, args.get("loop"))
        elif state.command == "workflow":
            if "repo" in args:
                cmd.append(args["repo"])
            if "workflow" in args:
                cmd.append(args["workflow"])
            if "commit" in args:
                cmd.extend(["--commit", args["commit"]])
            self._append_loop_args(cmd, args.get("loop"))
            if "op_name" in args:
                cmd.extend(["--op", args["op_name"]])
        # Add other commands as needed

        # Add extra args as --arg KEY=VALUE (for placeholder substitution)
        for key, value in args.items():
            if key not in handled_keys:
                cmd.extend(["--arg", f"{key}={value}"])
        for key, value in extra_args.items():
            cmd.extend(["--arg", f"{key}={value}"])

        return cmd

    def cancel_task(self, task_id: str) -> bool:
        """Cancel a running task."""
        state = load_task_state(task_id)
        if not state:
            return False

        # Kill the process if running
        if task_id in self._active_tasks:
            proc = self._active_tasks[task_id]
            try:
                proc.terminate()
                proc.wait(timeout=5)
            except Exception:
                proc.kill()
            del self._active_tasks[task_id]
        elif state.pid:
            # Try to kill by PID
            try:
                os.kill(state.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass

        state.status = "cancelled"
        state.pid = None
        save_task_state(state)
        logger.info(f"Cancelled task {task_id}")
        return True

    def list_tasks(self, status: str | None = None) -> list[TaskState]:
        """List all tasks."""
        return list_task_states(status=status)

    def get_task(self, task_id: str) -> TaskState | None:
        """Get a task by ID."""
        return load_task_state(task_id)

    def check_task_status(self, task_id: str) -> str | None:
        """Check if a task's process is still running."""
        state = load_task_state(task_id)
        if not state or not state.pid:
            return state.status if state else None

        try:
            os.kill(state.pid, 0)  # Check if process exists
            return "running"
        except ProcessLookupError:
            # Process is dead
            if state.status == "running":
                state = mark_interrupted(state)
                save_task_state(state)
            return state.status


class Daemon:
    """Main daemon process for managing forge tasks."""

    def __init__(self):
        self._manager = TaskManager()
        self._server = DaemonSocketServer(handler=self._handle_request)
        self._running = False
        self._monitor_thread: threading.Thread | None = None
        self._pid_path = _pid_path()

    def is_running(self) -> bool:
        """Check if daemon is running."""
        return self._running

    def start(self, foreground: bool = False) -> None:
        """Start the daemon."""
        if self._running:
            logger.warning("Daemon is already running")
            return

        # Set up daemon logging before fork
        _setup_daemon_logging()

        # Write PID file
        self._pid_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self._pid_path, "w") as f:
            f.write(str(os.getpid()))

        self._running = True

        # Recover interrupted tasks
        self._recover_interrupted_tasks()

        # Start socket server
        self._server.start()

        # Start task monitor
        self._monitor_thread = threading.Thread(target=self._monitor_tasks, daemon=True)
        self._monitor_thread.start()

        logger.info(f"Daemon started (pid={os.getpid()})")

        if foreground:
            self._run_foreground()

    def _run_foreground(self) -> None:
        """Run in foreground mode (blocks until stopped)."""
        try:
            while self._running:
                time.sleep(1.0)
        except KeyboardInterrupt:
            pass
        finally:
            self.stop()

    def stop(self) -> None:
        """Stop the daemon."""
        if not self._running:
            return

        self._running = False
        self._server.stop()

        # Mark running tasks as interrupted
        for task in self._manager.list_tasks(status="running"):
            state = mark_interrupted(task)
            save_task_state(state)

        # Remove PID file
        if self._pid_path.exists():
            self._pid_path.unlink()

        logger.info("Daemon stopped")

    def _handle_request(self, request: dict) -> dict:
        """Handle a client request."""
        action = request.get("action")

        if action == "status":
            return {
                "status": "ok",
                "pid": os.getpid(),
                "running": True,
                "tasks": {
                    "pending": len(self._manager.list_tasks(status="pending")),
                    "running": len(self._manager.list_tasks(status="running")),
                    "completed": len(self._manager.list_tasks(status="completed")),
                }
            }

        elif action == "submit":
            command = request.get("command")
            args = request.get("args", {})
            config_path = request.get("config_path")
            verbose = bool(request.get("verbose", False))
            owner = request.get("owner")
            client_ip = request.get("client_ip")

            state = self._manager.submit_task(command, args, config_path,
                                              verbose=verbose,
                                              owner=owner,
                                              client_ip=client_ip)

            # Auto-start the task
            self._manager.start_task(state.task_id)

            return {"status": "ok", "task_id": state.task_id}

        elif action == "list":
            status_filter = request.get("filter")
            tasks = self._manager.list_tasks(status=status_filter)
            return {
                "status": "ok",
                "tasks": [t.to_dict() for t in tasks]
            }

        elif action == "cancel":
            task_id = request.get("task_id")
            if self._manager.cancel_task(task_id):
                return {"status": "ok", "message": f"Task {task_id} cancelled"}
            return {"status": "error", "message": f"Task {task_id} not found"}

        elif action == "get":
            task_id = request.get("task_id")
            state = self._manager.get_task(task_id)
            if state:
                return {"status": "ok", "task": state.to_dict()}
            return {"status": "error", "message": f"Task {task_id} not found"}

        return {"status": "error", "message": f"Unknown action: {action}"}

    def _recover_interrupted_tasks(self) -> None:
        """Find and restart interrupted tasks."""
        interrupted = list_task_states(status="interrupted")
        for state in interrupted:
            if state.restart_count < state.max_restarts:
                logger.info(f"Recovering interrupted task {state.task_id}")
                state.status = "pending"
                state.restart_count += 1
                save_task_state(state)
                self._manager.start_task(state.task_id)
            else:
                logger.warning(f"Task {state.task_id} exceeded max restarts, marking failed")
                state = mark_failed(state, "Exceeded max restarts")
                save_task_state(state)

    def _monitor_tasks(self) -> None:
        """Monitor running tasks and update their status."""
        while self._running:
            try:
                running = self._manager.list_tasks(status="running")
                for state in running:
                    tid = state.task_id
                    # Use Popen.poll() if we have the process handle (detects zombies)
                    if tid in self._manager._active_tasks:
                        proc = self._manager._active_tasks[tid]
                        rc = proc.poll()
                        if rc is not None:
                            # Process finished
                            if rc == 0:
                                logger.info(f"Task {tid} completed (exit code 0)")
                                state = mark_completed(state)
                            else:
                                logger.warning(f"Task {tid} failed (exit code {rc})")
                                state = mark_failed(state, f"exit code {rc}")
                            save_task_state(state)
                            del self._manager._active_tasks[tid]
                    elif state.pid:
                        # Fallback: check if process is still alive
                        try:
                            os.kill(state.pid, 0)
                        except ProcessLookupError:
                            logger.warning(f"Task {tid} process died")
                            state = mark_interrupted(state)
                            save_task_state(state)
            except Exception as e:
                logger.error(f"Error monitoring tasks: {e}")

            time.sleep(5.0)  # Check every 5 seconds


def is_daemon_running() -> bool:
    """Check if a daemon is currently running."""
    pid_path = _pid_path()
    if not pid_path.exists():
        return False

    try:
        with open(pid_path) as f:
            pid = int(f.read().strip())
        os.kill(pid, 0)  # Check if process exists
        return True
    except (ValueError, ProcessLookupError):
        return False


def get_daemon_pid() -> int | None:
    """Get the daemon PID if running."""
    pid_path = _pid_path()
    if not pid_path.exists():
        return None

    try:
        with open(pid_path) as f:
            return int(f.read().strip())
    except ValueError:
        return None


SERVICE_FILE_PATH = "/etc/systemd/system/forge-daemon.service"


def get_service_content(username: str, home_dir: str) -> str:
    """Generate systemd service file content."""
    return f"""[Unit]
Description=Forge Task Daemon
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/forge daemon start --foreground
Restart=on-failure
RestartSec=5
User={username}
WorkingDirectory={home_dir}
Environment=PATH=/usr/bin:/bin

[Install]
WantedBy=multi-user.target
"""


def install_systemd_service() -> bool:
    """Install forge-daemon as a systemd service.

    Must be run as root (sudo).
    Returns True if successful.
    """
    # Check if running as root
    if os.geteuid() != 0:
        logger.error("install must be run as root (use sudo)")
        return False

    # Get the actual user who invoked sudo
    sudo_user = os.environ.get("SUDO_USER")
    if not sudo_user:
        logger.error("SUDO_USER not set, cannot determine target user")
        return False

    # Get home directory for the user
    import pwd
    try:
        user_info = pwd.getpwnam(sudo_user)
        home_dir = user_info.pw_dir
    except KeyError:
        logger.error(f"User {sudo_user} not found")
        return False

    # Generate service file content
    content = get_service_content(sudo_user, home_dir)

    # Write service file
    try:
        with open(SERVICE_FILE_PATH, "w") as f:
            f.write(content)
        logger.info(f"Written service file to {SERVICE_FILE_PATH}")
    except IOError as e:
        logger.error(f"Failed to write service file: {e}")
        return False

    # Run systemctl commands
    cmds = [
        ["systemctl", "daemon-reload"],
        ["systemctl", "enable", "forge-daemon"],
        ["systemctl", "start", "forge-daemon"],
    ]

    for cmd in cmds:
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            logger.debug(f"Ran: {' '.join(cmd)}")
        except subprocess.CalledProcessError as e:
            logger.error(f"Command failed: {' '.join(cmd)}: {e.stderr}")
            return False

    logger.info("forge-daemon service installed and started")
    return True


def uninstall_systemd_service() -> bool:
    """Uninstall forge-daemon systemd service.

    Must be run as root (sudo).
    Returns True if successful.
    """
    # Check if running as root
    if os.geteuid() != 0:
        logger.error("uninstall must be run as root (use sudo)")
        return False

    # Run systemctl commands to stop and disable
    cmds = [
        ["systemctl", "stop", "forge-daemon"],
        ["systemctl", "disable", "forge-daemon"],
    ]

    for cmd in cmds:
        try:
            subprocess.run(cmd, capture_output=True, text=True)
            logger.debug(f"Ran: {' '.join(cmd)}")
        except subprocess.CalledProcessError as e:
            logger.warning(f"Command may have failed: {' '.join(cmd)}: {e.stderr}")

    # Remove service file
    try:
        if Path(SERVICE_FILE_PATH).exists():
            Path(SERVICE_FILE_PATH).unlink()
            logger.info(f"Removed service file {SERVICE_FILE_PATH}")
    except IOError as e:
        logger.error(f"Failed to remove service file: {e}")
        return False

    # Reload systemd
    try:
        subprocess.run(["systemctl", "daemon-reload"], capture_output=True, text=True, check=True)
    except subprocess.CalledProcessError as e:
        logger.warning(f"daemon-reload failed: {e.stderr}")

    logger.info("forge-daemon service uninstalled")
    return True
