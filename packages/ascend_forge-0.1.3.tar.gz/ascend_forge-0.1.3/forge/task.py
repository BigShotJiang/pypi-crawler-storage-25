"""Shared task execution engine and utilities."""

import csv
import fnmatch
import glob
import logging
import os
import re
import subprocess
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime

from forge.config import get_timeout, substitute_placeholders, ConfigError
from forge.loop import normalize_loop_spec, run_loop

logger = logging.getLogger(__name__)


def resolve_working_dir(base_path: str, relative: str) -> str:
    """Resolve working directory relative to base path."""
    return os.path.normpath(os.path.join(base_path, relative))


def make_timestamp() -> str:
    """Generate timestamp string for filenames."""
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def get_head_commit(repo_path: str) -> str | None:
    """Get current HEAD commit hash."""
    if not os.path.isdir(repo_path):
        return None
    proc = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=repo_path,
        capture_output=True, text=True,
    )
    if proc.returncode == 0:
        return proc.stdout.strip()
    return None


def process_capture(capture_cfg: dict, stdout: str, variables: dict) -> None:
    """Extract values from stdout using regex and inject into variables."""
    for var_name, pattern in capture_cfg.items():
        match = re.search(pattern, stdout)
        if match:
            variables[var_name] = match.group(1)
            from forge.log import magenta
            print(f"    {magenta(f'Captured: {var_name} = {match.group(1)}')}")
            logger.debug(f"Captured variable '{var_name}' from stdout using pattern '{pattern}'")
        else:
            logger.warning(f"Capture pattern '{pattern}' for '{var_name}' did not match")


def get_skip_patterns(step: dict, variables: dict) -> list[str]:
    """Get list of skip patterns from skip_if_exists and skip_if_artifacts_exist."""
    patterns = []
    skip_artifacts_val = step.get("skip_if_artifacts_exist")
    skip_exists_val = step.get("skip_if_exists")

    logger.debug(f"skip_if_artifacts_exist={skip_artifacts_val!r}, skip_if_exists={skip_exists_val!r}")
    logger.debug(f"condition result={bool(skip_artifacts_val and 'artifacts' in step)}")

    if skip_artifacts_val and "artifacts" in step:
        patterns.extend(substitute_placeholders(step["artifacts"], variables))
    skip = step.get("skip_if_exists")
    if skip:
        if isinstance(skip, str):
            skip = [skip]
        patterns.extend(substitute_placeholders(skip, variables))
    logger.debug(f"skip patterns={patterns}")
    return patterns


def check_skip_files(working_dir: str, patterns: list[str]) -> tuple[bool, list[str]]:
    """Check all patterns match non-empty files. Returns (all_found, detail_messages)."""
    details = []
    all_found = True
    for pattern in patterns:
        full_pattern = os.path.join(working_dir, pattern)
        matched = glob.glob(full_pattern)
        if not matched:
            details.append(f"skip_if_exists: {pattern} -> not found")
            all_found = False
        elif not all(os.path.getsize(f) > 0 for f in matched):
            details.append(f"skip_if_exists: {pattern} -> found but empty")
            all_found = False
        else:
            details.append(f"skip_if_exists: {pattern} -> found ({len(matched)} file(s))")
    return all_found, details


def check_artifacts(working_dir: str, patterns: list[str], build_start_time: float) -> list[str]:
    """Check build artifacts exist, are non-empty, and were modified after build started."""
    errors = []
    for pattern in patterns:
        full_pattern = os.path.join(working_dir, pattern)
        matched_files = glob.glob(full_pattern)

        if not matched_files:
            errors.append(f"Artifact not found: {pattern}")
            continue

        for filepath in matched_files:
            stat = os.stat(filepath)
            if stat.st_size == 0:
                errors.append(f"Artifact is empty (0 bytes): {filepath}")
            elif stat.st_mtime < build_start_time - 1:
                # Detailed diagnostics for staleness failure
                mtime_dt = datetime.fromtimestamp(stat.st_mtime)
                start_dt = datetime.fromtimestamp(build_start_time)
                delta_sec = build_start_time - stat.st_mtime
                errors.append(
                    f"Artifact not updated by this build (stale): {filepath}\n"
                    f"    File mtime: {mtime_dt.strftime('%Y-%m-%d %H:%M:%S')} (timestamp: {stat.st_mtime:.2f})\n"
                    f"    Build start: {start_dt.strftime('%Y-%m-%d %H:%M:%S')} (timestamp: {build_start_time:.2f})\n"
                    f"    Delta: {delta_sec:.2f}s (file is older than build start by {delta_sec:.2f}s)"
                )

    return errors


def resolve_glob_vars(variables: dict, working_dir: str, build_start_time: float | None = None) -> dict:
    """Resolve glob patterns in variable values to actual file paths.

    For variables whose values contain glob characters (*, ?, [),
    resolve them against working_dir and update with actual paths.
    When multiple files match, picks the most recently modified one.

    If build_start_time is provided, only considers files modified at or
    after that time (with 1s tolerance, matching check_artifacts logic).

    Returns a dict of resolved variables to update.
    """
    resolved = {}
    for key, val in variables.items():
        if not isinstance(val, str) or not any(c in val for c in ("*", "?", "[")):
            continue

        search_path = val if os.path.isabs(val) else os.path.join(working_dir, val)
        matched = glob.glob(search_path)
        if not matched:
            logger.debug(f"Glob pattern '{val}' did not match any files in {working_dir}")
            continue

        if build_start_time is not None:
            fresh = [f for f in matched if os.path.getmtime(f) >= build_start_time - 1]
            if fresh:
                matched = fresh
            else:
                logger.warning(
                    f"Glob pattern '{val}' matched {len(matched)} file(s) but none are fresh"
                )
                continue

        actual_path = max(matched, key=os.path.getmtime)
        if not os.path.isabs(val):
            try:
                actual_path = os.path.relpath(actual_path, working_dir)
            except ValueError:
                pass

        if actual_path != val:
            resolved[key] = actual_path
            logger.debug(f"Resolved glob variable '{key}': '{val}' -> '{actual_path}'")

    return resolved


def merge_env(sourced_env: dict[str, str] | None, step_env: dict[str, str] | None) -> dict[str, str] | None:
    """Merge sourced env with step-level env. Step env takes precedence."""
    if not sourced_env and not step_env:
        return None
    merged = {}
    if sourced_env:
        merged.update(sourced_env)
    if step_env:
        merged.update(step_env)
    return merged


DEFAULT_OUTLIER_DETECTION = {
    "method": "iqr",
    "max_outlier_ratio": 0.1,
    "iqr_multiplier": 1.5,
    "min_samples": 4,
}


# ============================================================
# Result extraction (moved from tester.py)
# ============================================================

def extract_result_from_stdout(stdout: str, pattern: str) -> float | None:
    """Extract a float value from stdout using a regex with one capture group."""
    match = re.search(pattern, stdout)
    if match:
        return float(match.group(1))
    return None


def extract_result_from_file(path: str, format: str = "csv", value_column: int = 0,
    op_column: int | None = None, header: bool = True, delimiter: str = ",",
    op_name: str | None = None, aggregate: str | None = None) -> dict:
    """Extract result values from a CSV file."""
    if format != "csv":
        raise ValueError(f"Unsupported result file format: {format}. Only 'csv' is supported.")

    if not os.path.exists(path):
        raise FileNotFoundError(f"Result file not found: {path}")

    raw: dict[str, list[float]] = {}
    with open(path, newline="") as f:
        reader = csv.reader(f, delimiter=delimiter)
        rows = list(reader)

    start = 1 if header else 0
    for idx, row in enumerate(rows[start:]):
        value = float(row[value_column])
        if op_column is not None:
            key = str(row[op_column])
        else:
            key = str(idx)
        if op_name and op_column is not None:
            # Normalize: strip underscores and compare case-insensitively
            # so snake_case op_name matches PascalCase CSV keys
            norm_key = key.lower().replace("_", "")
            norm_pat = op_name.lower().replace("_", "")
            if not fnmatch.fnmatch(norm_key, norm_pat):
                continue
        raw.setdefault(key, []).append(value)

    results = {}
    for key, values in raw.items():
        results[key] = _aggregate_values(values, aggregate)

    return results


def _resolve_repeat(cfg: dict) -> int:
    return cfg.get("repeat", 1)


def _resolve_repeat_agg(cfg: dict, fallback: str = "avg") -> str:
    return cfg.get("repeat_agg", fallback)


def _resolve_outlier_detection(cfg: dict, fallback: dict | None = None) -> dict | None:
    outlier_detection = cfg.get("outlier_detection")
    if outlier_detection is None:
        return fallback
    if fallback is None:
        return outlier_detection
    merged = dict(fallback)
    for key, value in outlier_detection.items():
        if value is not None:
            merged[key] = value
    return merged


def _format_outlier_analysis(analysis: "OutlierAnalysis") -> str:
    """Format an outlier-analysis summary for console output."""
    sample_count = len(analysis.samples)
    if analysis.skipped:
        return analysis.message or (
            f"Outlier summary for '{analysis.key}': skipped ({sample_count} sample(s))"
        )

    parts = [
        f"Outlier {'failure' if analysis.failure else 'summary'} for '{analysis.key}':",
        f"samples={sample_count}",
        f"outliers={len(analysis.outliers)}",
        f"outlier_ratio={analysis.outlier_ratio:.2f}",
    ]
    if analysis.filtered_avg is not None:
        parts.append(
            f"filtered_avg={analysis.filtered_avg:.2f} from {len(analysis.filtered_values)}/{sample_count} samples"
        )
    if analysis.failure:
        parts.append(f"threshold={analysis.threshold:.2f}")
    return " | ".join(parts)


def _aggregate_repeat_results(
    all_values: list[dict],
    method: str = "avg",
    outlier_detection_cfg: dict | None = None,
) -> tuple[dict, dict[str, list[float]], list["OutlierAnalysis"]]:
    totals: dict[str, list[float]] = {}
    for values in all_values:
        for key, val in values.items():
            totals.setdefault(key, []).append(val)
    if method == "max":
        return {key: max(vals) for key, vals in totals.items()}, totals, []

    if method == "avg_without_outliers":
        aggregated = {}
        analyses: list["OutlierAnalysis"] = []
        for key, vals in totals.items():
            analysis = _analyze_outliers_iqr(key, vals, outlier_detection_cfg)
            analyses.append(analysis)
            aggregated[key] = analysis.filtered_avg if analysis.filtered_avg is not None else sum(vals) / len(vals)
        return aggregated, totals, analyses

    return {key: sum(vals) / len(vals) for key, vals in totals.items()}, totals, []


def _aggregate_values(values: list[float], method: str | None) -> float:
    """Aggregate a list of values using the specified method."""
    if not values:
        return 0.0
    if method is None:
        return values[-1]
    if method == "last":
        return values[-1]
    elif method == "avg":
        return sum(values) / len(values)
    elif method == "min":
        return min(values)
    elif method == "max":
        return max(values)
    else:
        raise ValueError(f"Unknown aggregate method: {method}. Supported: avg, last, min, max")


def extract_results(cfg, cmd_result, working_dir, variables, op_name=None, start_time=None):
    """Extract result values from a command result based on config."""
    result_cfg = cfg.get("result")
    if not result_cfg or cmd_result.timed_out:
        return None

    # If op_name not explicitly provided, check variables
    if op_name is None:
        op_name = variables.get("op_name")

    if result_cfg["type"] == "stdout":
        value = extract_result_from_stdout(cmd_result.stdout, result_cfg["pattern"])
        if value is not None:
            key = op_name or "value"
            return {key: value}
    elif result_cfg["type"] == "file":
        try:
            file_path = os.path.join(working_dir, substitute_placeholders(result_cfg["path"], variables))
        except ConfigError as e:
            logger.warning(f"Cannot resolve result path: {e}")
            return None
        # Resolve glob patterns (e.g. op_summary_*.csv) to actual file path
        if any(c in file_path for c in ("*", "?", "[")):
            matched = glob.glob(file_path)
            if not matched:
                logger.error(f"Result file not found: {file_path}")
                return None
            file_path = max(matched, key=os.path.getmtime)
        if start_time and os.path.exists(file_path):
            mtime = os.stat(file_path).st_mtime
            if mtime < start_time - 1:
                logger.warning(f"Result file not updated by this test (stale): {file_path}")
                return None
        effective_op = op_name
        if "op_filter" in result_cfg:
            effective_op = substitute_placeholders(result_cfg["op_filter"], variables)
        try:
            return extract_result_from_file(
                path=file_path, format=result_cfg.get("format", "csv"),
                value_column=result_cfg["value_column"], op_column=result_cfg.get("op_column"),
                header=result_cfg.get("header", True), delimiter=result_cfg.get("delimiter", ","),
                op_name=effective_op, aggregate=result_cfg.get("aggregate"),
            )
        except FileNotFoundError:
            logger.error(f"Result file not found: {file_path}")
    return None


# ============================================================
# Source env (moved from tester.py)
# ============================================================

def capture_sourced_env(script_path: str, working_dir: str) -> dict[str, str] | None:
    """Source a shell script and capture the environment variables it sets.

    Runs: bash -c 'source <script> && env' and parses the output.
    Returns dict of env vars that were added or changed, or None on failure.
    """
    if not os.path.exists(script_path):
        logger.warning(f"source_env script not found: {script_path}")
        return None

    try:
        proc_before = subprocess.run(
            "env", shell=True, cwd=working_dir,
            capture_output=True, text=True,
        )
        env_before = _parse_env_output(proc_before.stdout)

        proc_after = subprocess.run(
            f"source {script_path} && env", shell=True, cwd=working_dir,
            capture_output=True, text=True, executable="/bin/bash",
        )
        if proc_after.returncode != 0:
            logger.warning(f"Failed to source {script_path}: {proc_after.stderr}")
            return None
        env_after = _parse_env_output(proc_after.stdout)

        diff = {}
        for key, value in env_after.items():
            if key not in env_before or env_before[key] != value:
                diff[key] = value

        if diff:
            logger.info(f"Sourced {script_path}: {len(diff)} env vars captured")
        return diff if diff else None
    except Exception as e:
        logger.warning(f"Error sourcing {script_path}: {e}")
        return None


def _parse_env_output(output: str) -> dict[str, str]:
    """Parse output of 'env' command into a dict."""
    result = {}
    for line in output.splitlines():
        if "=" in line:
            key, _, value = line.partition("=")
            result[key] = value
    return result


def resolve_source_env(config: dict, task_cfg: dict, variables: dict, working_dir: str) -> dict[str, str] | None:
    """Resolve and capture source_env from config. Checks task > top-level.

    Supports glob wildcards in the source_env path. If the resolved path
    contains *, ?, or [, it is matched against the filesystem and the
    most recently modified match is used.

    Returns captured env vars dict or None.
    """
    from forge.config import ConfigError
    from forge.log import is_verbose

    source_env_raw = task_cfg.get("source_env") or config.get("source_env")
    if not source_env_raw:
        return None

    env_script = substitute_placeholders(source_env_raw, variables)

    # Resolve glob wildcards in source_env path
    if any(c in env_script for c in ("*", "?", "[")):
        search_path = env_script if os.path.isabs(env_script) else os.path.join(working_dir, env_script)
        matched = glob.glob(search_path)
        if matched:
            env_script = max(matched, key=os.path.getmtime)
            logger.debug(f"Resolved source_env glob: '{source_env_raw}' -> '{env_script}'")
        else:
            logger.warning(f"source_env glob pattern did not match any files: {search_path}")
            return None

    if not os.path.isabs(env_script):
        raise ConfigError(
            f"source_env must be an absolute path (after placeholder substitution), "
            f"got relative path: '{env_script}'. Use {{install_path}} or absolute path."
        )
    sourced = capture_sourced_env(env_script, working_dir)
    if sourced and is_verbose():
        print(f"Sourced {env_script}: {len(sourced)} env vars")
        for key, value in sourced.items():
            print(f"  {key}={value}")
    return sourced


# ============================================================
# TaskRunner base class
# ============================================================

from forge.executor import run_command
from forge.log import log_command_result, append_command_log, create_log, is_verbose, format_elapsed, bold, dim, green, red, yellow, cyan, magenta


@dataclass
class TaskResult:
    """Result from a task execution."""
    success: bool
    stdout: str
    stderr: str
    timed_out: bool = False
    artifact_errors: list[str] = field(default_factory=list)
    result_values: dict | None = None
    raw_result_samples: dict[str, list[float]] | None = None
    outlier_analyses: dict[str, dict] | None = None

# Backward-compatible alias
StepResult = TaskResult


@dataclass
class OutlierAnalysis:
    """Result of helper-level outlier analysis for a repeated metric key."""
    key: str
    samples: list[float]
    q1: float | None = None
    q3: float | None = None
    iqr: float | None = None
    lower_bound: float | None = None
    upper_bound: float | None = None
    outliers: list[float] = field(default_factory=list)
    outlier_ratio: float = 0.0
    threshold: float = DEFAULT_OUTLIER_DETECTION["max_outlier_ratio"]
    filtered_values: list[float] = field(default_factory=list)
    filtered_avg: float | None = None
    skipped: bool = False
    failure: bool = False
    message: str = ""


def _merge_outlier_detection_cfg(cfg: dict | None) -> dict:
    """Merge caller config onto the default outlier-detection settings."""
    merged = dict(DEFAULT_OUTLIER_DETECTION)
    if cfg:
        for key, value in cfg.items():
            if value is not None:
                merged[key] = value
    return merged


def _percentile(sorted_values: list[float], p: float) -> float:
    """Compute a percentile from a pre-sorted list using linear interpolation."""
    if not sorted_values:
        raise ValueError("sorted_values must not be empty")
    if len(sorted_values) == 1:
        return sorted_values[0]
    idx = (len(sorted_values) - 1) * p
    lower = int(idx)
    upper = min(lower + 1, len(sorted_values) - 1)
    fraction = idx - lower
    return sorted_values[lower] + (sorted_values[upper] - sorted_values[lower]) * fraction


def _analyze_outliers_iqr(key: str, values: list[float], cfg: dict | None) -> OutlierAnalysis:
    """Analyze IQR outliers for a metric key and return summary metadata."""
    settings = _merge_outlier_detection_cfg(cfg)
    if settings.get("method") != "iqr":
        raise ValueError(f"Unsupported outlier detection method: {settings.get('method')}")

    samples = list(values)
    analysis = OutlierAnalysis(key=key, samples=samples, threshold=settings["max_outlier_ratio"])

    if len(samples) < settings["min_samples"]:
        analysis.skipped = True
        analysis.filtered_values = list(samples)
        analysis.filtered_avg = sum(samples) / len(samples) if samples else None
        analysis.message = (
            f"Outlier analysis skipped for key '{key}': "
            f"only {len(samples)} samples, min_samples={settings['min_samples']}"
        )
        return analysis

    sorted_values = sorted(samples)
    q1 = _percentile(sorted_values, 0.25)
    q3 = _percentile(sorted_values, 0.75)
    iqr = q3 - q1
    lower_bound = q1 - settings["iqr_multiplier"] * iqr
    upper_bound = q3 + settings["iqr_multiplier"] * iqr

    filtered_values = [value for value in samples if lower_bound <= value <= upper_bound]
    outliers = [value for value in samples if value < lower_bound or value > upper_bound]

    analysis.q1 = q1
    analysis.q3 = q3
    analysis.iqr = iqr
    analysis.lower_bound = lower_bound
    analysis.upper_bound = upper_bound
    analysis.filtered_values = filtered_values
    analysis.outliers = outliers
    analysis.outlier_ratio = (len(outliers) / len(samples)) if samples else 0.0
    analysis.filtered_avg = sum(filtered_values) / len(filtered_values) if filtered_values else None
    analysis.failure = analysis.outlier_ratio > settings["max_outlier_ratio"] or not filtered_values
    if analysis.failure and not filtered_values:
        analysis.message = f"Outlier analysis failed for key '{key}': all samples filtered out"
    return analysis


class TaskRunner:
    """Base task execution engine. Subclass and override _post_step/_make_result."""

    default_timeout = 600

    def run(self, task_cfg, base_path, repo_name, label, variables,
            sourced_env=None, step_name=None, global_env=None, loop=None):
        """Entry point: dispatch to single or multi-step execution."""
        logger.debug(f"Running task '{label}' for repo '{repo_name}'")
        loop_spec = normalize_loop_spec(loop)
        if loop_spec is not None:
            loop_result = run_loop(
                loop_spec,
                variables,
                lambda iter_vars: self.run(
                    task_cfg,
                    base_path,
                    repo_name,
                    label,
                    iter_vars,
                    sourced_env=sourced_env,
                    step_name=step_name,
                    global_env=global_env,
                    loop=None,
                ),
            )
            last = loop_result.last_result
            return TaskResult(
                success=loop_result.success,
                stdout=getattr(last, "stdout", "") if last else "",
                stderr=getattr(last, "stderr", "") if last else "",
                timed_out=getattr(last, "timed_out", False) if last else False,
                artifact_errors=getattr(last, "artifact_errors", []) if last else [],
                result_values=loop_result.result_values,
            )
        if "steps" in task_cfg:
            single_run = lambda: self._run_multi_step(
                task_cfg, base_path, repo_name, label, variables,
                sourced_env=sourced_env, step_name=step_name, global_env=global_env,
            )
        else:
            if step_name:
                print(f"  {yellow('Warning')}: --step ignored (no steps defined in config)", file=sys.stderr)
            single_run = lambda: self._run_single(
                task_cfg, base_path, repo_name, label, variables,
                sourced_env=sourced_env, global_env=global_env,
            )
        return self._run_repeat_loop(
            single_run,
            _resolve_repeat(task_cfg),
            _resolve_repeat_agg(task_cfg),
            outlier_detection_cfg=_resolve_outlier_detection(task_cfg),
        )

    def _run_repeat_loop(
        self,
        runner,
        repeat: int,
        repeat_agg: str,
        indent: str = "  ",
        ignore_failure: bool = False,
        outlier_detection_cfg: dict | None = None,
    ):
        """Execute runner() up to repeat times, fail-fast, aggregate result_values."""
        all_values = []
        last_result = None
        for i in range(repeat):
            if repeat > 1:
                print(f"{indent}{bold(f'Run {i + 1}/{repeat}')}")
            result = runner()
            last_result = result
            if not result.success:
                print(f"{indent}{red(f'Failed on run {i + 1}/{repeat}')}")
                if not ignore_failure:
                    return result
            if getattr(result, "result_values", None):
                all_values.append(result.result_values)

        if not all_values:
            return last_result

        aggregated_result_values, raw_result_samples, outlier_analyses = _aggregate_repeat_results(
            all_values,
            repeat_agg,
            outlier_detection_cfg=outlier_detection_cfg,
        )

        any_outlier_failure = False
        outlier_failure_summaries: list[str] = []
        for analysis in outlier_analyses:
            summary = _format_outlier_analysis(analysis)
            print(f"{indent}{summary}")
            if analysis.failure:
                any_outlier_failure = True
                outlier_failure_summaries.append(summary)

        stderr = last_result.stderr
        if outlier_failure_summaries:
            diagnostics = "\n".join(outlier_failure_summaries)
            stderr = f"{stderr}\n{diagnostics}" if stderr else diagnostics

        return TaskResult(
            success=last_result.success and not any_outlier_failure,
            stdout=last_result.stdout,
            stderr=stderr,
            timed_out=last_result.timed_out,
            artifact_errors=last_result.artifact_errors,
            result_values=aggregated_result_values,
            raw_result_samples=raw_result_samples,
            outlier_analyses={
                analysis.key: {
                    "samples": list(analysis.samples),
                    "q1": analysis.q1,
                    "q3": analysis.q3,
                    "iqr": analysis.iqr,
                    "lower_bound": analysis.lower_bound,
                    "upper_bound": analysis.upper_bound,
                    "outliers": list(analysis.outliers),
                    "outlier_ratio": analysis.outlier_ratio,
                    "threshold": analysis.threshold,
                    "filtered_values": list(analysis.filtered_values),
                    "filtered_avg": analysis.filtered_avg,
                    "skipped": analysis.skipped,
                    "failure": analysis.failure,
                    "message": analysis.message,
                }
                for analysis in outlier_analyses
            } or None,
        )

    def _run_single(self, task_cfg, base_path, repo_name, label, variables, sourced_env=None, global_env=None):
        """Execute a single command."""
        raw_working_dir = substitute_placeholders(task_cfg.get("working_dir", "."), variables)
        working_dir = resolve_working_dir(base_path, raw_working_dir)
        timeout = get_timeout(task_cfg.get("timeout", self.default_timeout))

        args = substitute_placeholders(task_cfg.get("args", []), variables)
        command = substitute_placeholders(task_cfg["command"], variables)
        full_cmd = command + (" " + " ".join(args) if args else "")
        logger.debug(f"Single-step command: {full_cmd}")
        logger.debug(f"Working directory: {working_dir}, timeout: {timeout}")

        print(f"  {dim('Command:')} {full_cmd}")
        print(f"  {dim('Working directory:')} {working_dir}")

        env = merge_env(global_env, merge_env(sourced_env, task_cfg.get("env")))
        start_time = time.time()
        cmd_result = run_command(
            command=command, args=args, working_dir=working_dir,
            env=env, timeout=timeout, stream=is_verbose(),
        )
        elapsed = time.time() - start_time
        logger.debug(f"Command elapsed: {elapsed:.2f}s, returncode={cmd_result.returncode}")
        print(f"  {dim('Elapsed:')} {format_elapsed(elapsed)}")

        success = cmd_result.is_successful(success_pattern=task_cfg.get("success_pattern"))

        # Subclass hook — always called (not just on success)
        post_data = {}
        post = self._post_step(task_cfg, cmd_result, working_dir, variables, start_time, success)
        if post:
            post_data = post
            if post.get("success_override") is not None:
                success = post["success_override"]

        log_command_result(
            repo_name=repo_name, label=label, command=full_cmd,
            working_dir=working_dir, returncode=cmd_result.returncode,
            stdout=cmd_result.stdout, stderr=cmd_result.stderr,
            success=success, timed_out=cmd_result.timed_out,
        )

        return self._make_result(success, cmd_result.stdout, cmd_result.stderr,
                                 cmd_result.timed_out, post_data)

    def _run_multi_step(self, task_cfg, base_path, repo_name, label, variables,
                        sourced_env=None, step_name=None, global_env=None):
        """Execute multiple steps sequentially. Fail fast on any step failure."""
        steps = task_cfg["steps"]
        default_timeout = get_timeout(task_cfg.get("timeout", self.default_timeout))
        default_working_dir = substitute_placeholders(task_cfg.get("working_dir", "."), variables)
        logger.debug(f"Multi-step task: {len(steps)} steps, default_working_dir={default_working_dir}")

        # Filter to specific step if requested
        if step_name:
            matched = [s for s in steps if s.get("name") == step_name]
            if not matched:
                available = [s.get("name", f"step {i+1}") for i, s in enumerate(steps)]
                print(f"  {red('Error')}: step '{step_name}' not found. Available: {available}", file=sys.stderr)
                return self._make_result(False, "", f"Step '{step_name}' not found", False, {})
            steps = matched

        all_stdout = []
        all_stderr = []
        post_data = {}
        log_path = create_log(repo_name, label)

        for i, step in enumerate(steps):
            name = step.get("name", f"step {i + 1}")
            working_dir = resolve_working_dir(base_path, substitute_placeholders(step.get("working_dir", default_working_dir), variables))

            print(f"  {bold(cyan(f'Step {i + 1}/{len(steps)}:'))} {bold(name)}")

            # Skip conditions
            skip_patterns = get_skip_patterns(step, variables)
            if skip_patterns:
                all_found, details = check_skip_files(working_dir, skip_patterns)
                for detail in details:
                    print(f"    {detail}")
                if all_found:
                    print(f"    {yellow('Skipped')}")
                    logger.info(f"Step '{name}' skipped: all files present")
                    continue

            step_repeat = _resolve_repeat(step)
            step_repeat_agg = _resolve_repeat_agg(step, fallback=_resolve_repeat_agg(task_cfg))
            step_ignore_failure = bool(step.get("ignore_failure"))

            step_result = self._run_repeat_loop(
                lambda step=step, working_dir=working_dir: self._run_step_once(
                    step, base_path, repo_name, label, variables,
                    default_working_dir=default_working_dir,
                    default_timeout=default_timeout,
                    sourced_env=sourced_env,
                    global_env=global_env,
                    log_path=log_path,
                    step_index=i,
                    step_total=len(steps),
                    shared_post_data=post_data,
                ),
                step_repeat,
                step_repeat_agg,
                indent="    ",
                ignore_failure=step_ignore_failure,
                outlier_detection_cfg=_resolve_outlier_detection(step, fallback=_resolve_outlier_detection(task_cfg)),
            )

            all_stdout.append(step_result.stdout)
            all_stderr.append(step_result.stderr)

            # Use the aggregated result_values from the step repeat loop
            if step_result.result_values is not None:
                post_data["result_values"] = step_result.result_values

            if not step_result.success:
                if step_ignore_failure:
                    print(f"    {yellow('Warning')}: step failed but ignore_failure=true, continuing...")
                else:
                    print(f"  {dim(f'Log saved: {log_path}')}")
                    return self._make_result(False, "\n".join(all_stdout),
                                             "\n".join(all_stderr), step_result.timed_out, post_data)

        print(f"  {dim(f'Log saved: {log_path}')}")
        return self._make_result(True, "\n".join(all_stdout), "\n".join(all_stderr), False, post_data)

    def _run_step_once(self, step, base_path, repo_name, label, variables,
                       default_working_dir=".", default_timeout=600,
                       sourced_env=None, global_env=None,
                       log_path=None, step_index=0, step_total=1,
                       shared_post_data=None):
        """Execute a single step once and return a TaskResult.

        If shared_post_data is provided, accumulates post_data into it
        (list values are extended, others are overwritten) so that
        cross-step post_data accumulation is preserved for subclasses.
        """
        name = step.get("name", f"step {step_index + 1}")
        working_dir = resolve_working_dir(base_path, substitute_placeholders(step.get("working_dir", default_working_dir), variables))
        timeout = get_timeout(step.get("timeout")) if "timeout" in step else default_timeout

        args = substitute_placeholders(step.get("args", []), variables)
        command = substitute_placeholders(step["command"], variables)
        full_cmd = command + (" " + " ".join(args) if args else "")
        logger.debug(f"Step '{name}' command: {full_cmd}")

        print(f"    {dim('Command:')} {full_cmd}")
        print(f"    {dim('Working directory:')} {working_dir}")

        env = merge_env(global_env, merge_env(sourced_env, step.get("env")))
        step_start_time = time.time()
        cmd_result = run_command(
            command=command, args=args, working_dir=working_dir,
            env=env, timeout=timeout, stream=is_verbose(),
        )
        step_elapsed = time.time() - step_start_time
        print(f"    {dim('Elapsed:')} {format_elapsed(step_elapsed)}")

        success = cmd_result.is_successful(success_pattern=step.get("success_pattern"))

        # Capture variables from stdout
        if "capture" in step and cmd_result.stdout:
            process_capture(step["capture"], cmd_result.stdout, variables)

        # Subclass hook
        step_post_data = {}
        post = self._post_step(step, cmd_result, working_dir, variables, step_start_time, success)
        if post:
            step_post_data = post
            if post.get("success_override") is not None:
                success = post["success_override"]

        # Accumulate into shared post_data if provided.
        # result_values is handled separately (aggregated by _run_repeat_loop),
        # so we skip it here to avoid overwriting the aggregated value.
        if shared_post_data is not None:
            for k, v in step_post_data.items():
                if k == "result_values":
                    continue  # handled by caller after _run_repeat_loop
                if isinstance(v, list) and k in shared_post_data and isinstance(shared_post_data[k], list):
                    shared_post_data[k].extend(v)
                else:
                    shared_post_data[k] = v

        if log_path:
            append_command_log(
                log_path=log_path, step_name=name, command=full_cmd,
                working_dir=working_dir, returncode=cmd_result.returncode,
                stdout=cmd_result.stdout, stderr=cmd_result.stderr,
                success=success, timed_out=cmd_result.timed_out,
                artifact_errors=step_post_data.get("artifact_errors"),
            )

        return self._make_result(success, cmd_result.stdout, cmd_result.stderr,
                                 cmd_result.timed_out, step_post_data)

    # === Extension points (can still be overridden by subclasses) ===

    def _post_step(self, step_cfg, cmd_result, working_dir, variables, start_time, success) -> dict | None:
        """Built-in post-processing: artifact checks + result extraction.
        Can be overridden by subclasses for custom behavior."""
        post_data = {}

        # Artifact checking
        if success and "artifacts" in step_cfg:
            patterns = [substitute_placeholders(p, variables) for p in step_cfg["artifacts"]]
            errors = check_artifacts(working_dir, patterns, start_time)
            if errors:
                post_data["artifact_errors"] = errors
                post_data["success_override"] = False
            else:
                # After successful artifact check, resolve any glob variables
                # so subsequent steps see concrete file paths.
                resolved = resolve_glob_vars(variables, working_dir, start_time)
                if resolved:
                    variables.update(resolved)

        # Result extraction
        if "result" in step_cfg and not cmd_result.timed_out:
            values = extract_results(step_cfg, cmd_result, working_dir, variables, start_time=start_time)
            if values is not None:
                post_data["result_values"] = values

        return post_data or None

    def _make_result(self, success, stdout, stderr, timed_out, post_data):
        """Construct TaskResult with artifact_errors and result_values."""
        artifact_errors = [] if success else post_data.get("artifact_errors", [])
        result_values = post_data.get("result_values")
        return TaskResult(
            success=success, stdout=stdout, stderr=stderr,
            timed_out=timed_out,
            artifact_errors=artifact_errors,
            result_values=result_values,
        )
