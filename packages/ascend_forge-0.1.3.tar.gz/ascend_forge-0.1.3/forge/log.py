"""Logging utilities for forge.

Provides file-based log persistence and screen output control.
Logs are saved to ~/.forge/logs/<repo_name>/<command>_<timestamp>.log
"""

import os
import sys
from datetime import datetime
from pathlib import Path


# ============================================================
# ANSI color helpers
# ============================================================

def _use_color() -> bool:
    """Check if stdout supports color output."""
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


def _ansi(code: str, text: str) -> str:
    if _use_color():
        return f"\033[{code}m{text}\033[0m"
    return text


def bold(text: str) -> str:
    return _ansi("1", text)

def dim(text: str) -> str:
    return _ansi("2", text)

def green(text: str) -> str:
    return _ansi("32", text)

def red(text: str) -> str:
    return _ansi("31", text)

def yellow(text: str) -> str:
    return _ansi("33", text)

def cyan(text: str) -> str:
    return _ansi("36", text)

def magenta(text: str) -> str:
    return _ansi("35", text)


# Global verbose flag, set by CLI
_verbose = False


def set_verbose(verbose: bool) -> None:
    global _verbose
    _verbose = verbose


def is_verbose() -> bool:
    return _verbose


# Global debug flag, set by CLI
_debug = False


def set_debug(debug: bool) -> None:
    global _debug
    _debug = debug


def is_debug() -> bool:
    return _debug


def _logs_dir() -> Path:
    return Path.home() / ".forge" / "logs"


def create_log(repo_name: str, label: str) -> str:
    """Create a new log file and return its path."""
    log_dir = _logs_dir() / repo_name
    log_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
    log_path = log_dir / f"{label}_{ts}.log"
    # Create empty file
    with open(log_path, "w") as f:
        f.write(f"Log started: {datetime.now().isoformat()}\n\n")
    return str(log_path)


def append_command_log(
    log_path: str,
    step_name: str,
    command: str,
    working_dir: str,
    returncode: int,
    stdout: str,
    stderr: str,
    success: bool,
    timed_out: bool = False,
    artifact_errors: list[str] | None = None,
) -> None:
    """Append a command execution record to an existing log file."""
    lines = []
    lines.append(f"--- {step_name} ---")
    lines.append(f"Time: {datetime.now().isoformat()}")
    lines.append(f"Command: {command}")
    lines.append(f"Working directory: {working_dir}")
    lines.append(f"Exit code: {returncode}")
    lines.append(f"Timed out: {timed_out}")
    lines.append(f"Success: {success}")
    if artifact_errors:
        lines.append(f"Artifact errors: {artifact_errors}")
    lines.append("")
    lines.append("=== STDOUT ===")
    lines.append(stdout if stdout else "(empty)")
    lines.append("")
    lines.append("=== STDERR ===")
    lines.append(stderr if stderr else "(empty)")
    lines.append("")

    with open(log_path, "a") as f:
        f.write("\n".join(lines) + "\n")

    # Screen output on failure
    if not _verbose and not success:
        reason = []
        if timed_out:
            reason.append("timed out")
        if returncode != 0:
            reason.append(f"exit code {returncode}")
        if artifact_errors:
            for err in artifact_errors:
                reason.append(err)
        if reason:
            print(f"  {red('Failed:')} {', '.join(reason)}", file=sys.stderr)
        if stderr:
            print(f"  {dim('stderr:')} {stderr.strip()}", file=sys.stderr)


def log_command_result(
    repo_name: str,
    label: str,
    command: str,
    working_dir: str,
    returncode: int,
    stdout: str,
    stderr: str,
    success: bool,
    timed_out: bool = False,
) -> str:
    """Write a single command log (backward compat for non-multi-step)."""
    log_path = create_log(repo_name, label)
    append_command_log(
        log_path=log_path, step_name=label, command=command,
        working_dir=working_dir, returncode=returncode,
        stdout=stdout, stderr=stderr, success=success, timed_out=timed_out,
    )
    print(f"  Log saved: {log_path}")
    return log_path


def format_elapsed(seconds: float) -> str:
    """Format elapsed seconds as human-readable string."""
    if seconds < 60:
        return f"{seconds:.0f}s"
    minutes = int(seconds // 60)
    secs = int(seconds % 60)
    if minutes < 60:
        return f"{minutes}m {secs}s"
    hours = minutes // 60
    minutes = minutes % 60
    return f"{hours}h {minutes}m {secs}s"
