"""Git bisect orchestration."""

import logging
import subprocess
import sys
from dataclasses import dataclass, field

from forge.config import ConfigError, resolve_bisect_git_repo, resolve_bisect_workflows, resolve_tasks
from forge.workflow import WorkflowRunner, WorkflowResult

logger = logging.getLogger(__name__)


def _update_bisect_checkpoint(repo_name: str, test_type: str, commit: str, result: str, step: int) -> None:
    """Update checkpoint for bisect recovery."""
    from forge.task_state import list_task_states, save_task_state

    running_tasks = list_task_states(status="running")
    for task in running_tasks:
        if task.args.get("repo") == repo_name and task.args.get("type") == test_type:
            progress = task.progress or {}
            steps = progress.get("steps", [])
            steps.append({"commit": commit, "result": result})
            task.progress = {
                "steps": steps,
                "current_step": step,
            }
            save_task_state(task)
            logger.debug(f"Updated bisect checkpoint: step {step}, commit {commit[:8]} -> {result}")
            break


class BisectAbortError(Exception):
    """Raised when bisect aborts due to too many skips."""
    pass


@dataclass
class StepRecord:
    """Record of a single bisect step."""
    commit: str
    status: str  # "good", "bad", "skip"
    result_values: dict | None = None
    skip_reason: str | None = None


@dataclass
class BisectResult:
    found_commit: str | None
    commit_range: list[str] | None = None
    total_steps: int = 0
    skipped_steps: int = 0
    step_records: list[StepRecord] = field(default_factory=list)
    baseline_value: float | None = None
    regression_pct: float | None = None
    threshold: float | None = None


def bisect_repo(
    config: dict, good_commit: str, bad_commit: str,
    workflow_name: str | None = None, test_type: str | None = None,
    op_name: str | None = None, regression_pct: float | None = None,
    threshold: float | None = None, extra_vars: dict[str, str] | None = None,
    repeat: int | None = None, repeat_agg: str | None = None,
) -> BisectResult:
    bisect_cfg = config.get("bisect", {})

    try:
        bisect_wf_list, workflows, wf_warnings = resolve_bisect_workflows(config, test_type=test_type)
    except ConfigError as e:
        raise BisectAbortError(str(e)) from None
    for warning in wf_warnings:
        print(f"  Warning: {warning}", file=sys.stderr)

    if workflow_name is not None:
        if workflow_name not in workflows:
            raise BisectAbortError(
                f"Workflow '{workflow_name}' not found. Available: {list(workflows.keys())}"
            )
        bisect_wf_list = [{"name": workflow_name, "repeatable": True}]

    tasks = resolve_tasks(config)

    effective_test_type = test_type or bisect_cfg.get("test_type", "accuracy")
    effective_repeat = repeat or bisect_cfg.get("repeat", 1)
    effective_repeat_agg = repeat_agg or bisect_cfg.get("repeat_agg", "avg")
    effective_outlier_detection = bisect_cfg.get("outlier_detection")

    logger.debug(
        f"Starting bisect: good={good_commit[:8]}, bad={bad_commit[:8]}, "
        f"workflows={[w['name'] for w in bisect_wf_list]}"
    )

    if regression_pct is None:
        regression_pct = bisect_cfg.get("regression", 10.0)
    if threshold is None:
        threshold = bisect_cfg.get("threshold")

    # Build variables first so extra_vars can override working_dir,
    # then derive git_repo from the resolved config.
    variables = _build_bisect_variables(config, extra_vars)
    git_repo = resolve_bisect_git_repo(config)
    logger.debug(f"Bisect git repo: {git_repo}")
    original_ref = _get_current_ref(git_repo)

    try:
        commits = _get_commit_range(git_repo, good_commit, bad_commit)
        if not commits:
            return BisectResult(found_commit=None, total_steps=0)

        _run_pre_workflow(
            config, bisect_cfg, tasks, workflows, variables, effective_outlier_detection
        )

        baseline_value = None
        if effective_test_type == "performance" and threshold is None:
            last_wf_name = bisect_wf_list[-1]["name"]
            last_workflow_cfg = workflows[last_wf_name]
            baseline_repeat = effective_repeat if bisect_wf_list[-1].get("repeatable", True) else 1
            baseline_value = _get_perf_baseline(
                config, last_workflow_cfg, tasks, good_commit, variables,
                op_name, baseline_repeat, effective_repeat_agg, effective_outlier_detection,
            )

        lo, hi = 0, len(commits) - 1
        total_steps = 0
        skipped_steps = 0
        skipped_commits = set()
        step_records = []

        while lo < hi:
            mid = (lo + hi) // 2
            commit = commits[mid]

            if commit in skipped_commits:
                found_alt = False
                for offset in range(1, hi - lo + 1):
                    for alt in [mid - offset, mid + offset]:
                        if lo <= alt <= hi and commits[alt] not in skipped_commits:
                            commit = commits[alt]
                            mid = alt
                            found_alt = True
                            break
                    if found_alt:
                        break
                if not found_alt:
                    break

            total_steps += 1
            logger.info(f"Bisect step {total_steps}: testing commit {commit[:8]} ({mid}/{len(commits)})")

            _checkout(git_repo, commit)

            step_vars = dict(variables)
            step_vars["commit"] = commit
            wf_runner = WorkflowRunner()

            last_wf_result = None
            wf_failed_early = False
            failed_wf_name = None

            for wf_entry in bisect_wf_list:
                wf_name = wf_entry["name"]
                repeatable = wf_entry.get("repeatable", True)
                wf_repeat = effective_repeat if repeatable else 1

                workflow_cfg = workflows[wf_name]
                wf_result = wf_runner.run(
                    workflow_cfg, tasks, git_repo,
                    config.get("name", "unknown"), step_vars,
                    global_env=config.get("env"), config=config,
                    repeat=wf_repeat, repeat_agg=effective_repeat_agg,
                    outlier_detection_cfg=effective_outlier_detection,
                )

                if not wf_result.success:
                    if wf_name != bisect_wf_list[-1]["name"]:
                        wf_failed_early = True
                        failed_wf_name = wf_name
                        break
                    last_wf_result = wf_result
                    break

                last_wf_result = wf_result

            if wf_failed_early:
                reason = f"workflow '{failed_wf_name}' failed"
                logger.warning(f"Early workflow failed at {commit[:8]}: {reason}")
                skipped_steps += 1
                skipped_commits.add(commit)
                step_records.append(StepRecord(commit=commit, status="skip", skip_reason=reason))
                _check_skip_limit(skipped_steps, total_steps)
                continue

            if last_wf_result is None or not last_wf_result.success:
                reason = (
                    f"step '{last_wf_result.failed_step}' failed"
                    if last_wf_result and last_wf_result.failed_step
                    else "workflow failed"
                )
                last_wf_name = bisect_wf_list[-1]["name"]
                last_workflow_cfg = workflows[last_wf_name]
                last_step = last_workflow_cfg["tasks"][-1]
                judge_step_failed = last_wf_result and last_wf_result.failed_step == last_step

                if judge_step_failed and effective_test_type == "accuracy":
                    logger.debug(f"Bisect step: testing commit {commit[:8]}, result=bad (test failed)")
                    step_records.append(StepRecord(commit=commit, status="bad", skip_reason=None))
                    hi = mid
                    if all(commits[i] in skipped_commits for i in range(lo, hi)):
                        lo = hi
                    continue

                logger.warning(f"Workflow failed at {commit[:8]}: {reason}")
                skipped_steps += 1
                skipped_commits.add(commit)
                step_records.append(StepRecord(commit=commit, status="skip", skip_reason=reason))
                _check_skip_limit(skipped_steps, total_steps)
                continue

            is_good = _is_commit_good(
                effective_test_type, last_wf_result, op_name, baseline_value, regression_pct, threshold
            )
            step_records.append(StepRecord(
                commit=commit,
                status="good" if is_good else "bad",
                result_values=last_wf_result.result_values,
            ))
            logger.debug(f"Bisect step: testing commit {commit[:8]}, result={'good' if is_good else 'bad'}")

            if is_good:
                lo = mid + 1
            else:
                hi = mid
                if all(commits[i] in skipped_commits for i in range(lo, hi)):
                    lo = hi

        found = commits[lo]
        logger.debug(f"Bisect found bad commit: {found[:8]}")
        result = BisectResult(
            found_commit=found, total_steps=total_steps, skipped_steps=skipped_steps,
            step_records=step_records, baseline_value=baseline_value,
            regression_pct=regression_pct, threshold=threshold,
        )
        if skipped_steps > 0:
            result.commit_range = commits[max(0, lo - skipped_steps):lo + 1]
        return result
    finally:
        print(f"  Restoring to {original_ref}...")
        _checkout(git_repo, original_ref)
        _run_post_workflows(
            config, bisect_cfg, bisect_wf_list, tasks, workflows, variables, original_ref,
            effective_outlier_detection,
        )


def _run_post_workflows(
    config, bisect_cfg, bisect_wf_list, tasks, workflows, variables, original_ref,
    outlier_detection_cfg=None,
):
    """Run post_workflows after bisect restores to original commit.

    Supports both legacy post_workflow and new post_workflows array format.
    """
    post_wf = bisect_cfg.get("post_workflow")
    post_wfs = bisect_cfg.get("post_workflows")

    wf_names = []
    if post_wfs:
        if isinstance(post_wfs, list):
            for entry in post_wfs:
                if isinstance(entry, str):
                    wf_names.append(entry)
                elif isinstance(entry, dict) and "name" in entry:
                    wf_names.append(entry["name"])
        elif isinstance(post_wfs, str):
            wf_names.append(post_wfs)
    elif post_wf:
        if post_wf is True:
            wf_names = [w["name"] for w in bisect_wf_list]
        elif isinstance(post_wf, str):
            wf_names.append(post_wf)

    wf_runner = WorkflowRunner()
    for wf_name in wf_names:
        if wf_name not in workflows:
            logger.warning(f"post_workflow '{wf_name}' not found, skipping")
            continue

        workflow_cfg = workflows[wf_name]
        step_vars = dict(variables)
        step_vars["commit"] = original_ref

        print(f"  Running post-workflow '{wf_name}'...")
        wf_result = wf_runner.run(
            workflow_cfg, tasks, resolve_bisect_git_repo(config), config.get("name", "unknown"),
            step_vars, global_env=config.get("env"), config=config,
            outlier_detection_cfg=outlier_detection_cfg,
        )

        if not wf_result.success:
            logger.warning(
                f"Post-workflow '{wf_name}' failed at step '{wf_result.failed_step}' "
                "(bisect result unaffected)"
            )


def _build_bisect_variables(config, extra_vars):
    """Build variables dict for bisect (without commit — set per step)."""
    from forge.task import make_timestamp

    variables = dict(config.get("vars", {}))
    variables["working_dir"] = resolve_bisect_git_repo(config)
    variables["config_dir"] = config.get("_config_dir", "")
    variables["timestamp"] = make_timestamp()
    if extra_vars:
        variables.update(extra_vars)
    # Resolve placeholder references within variable values
    from forge.config import resolve_vars
    variables = resolve_vars(variables)
    # Write back so downstream code (resolve_bisect_git_repo, wf_runner) sees
    # the final path that honors --arg overrides (e.g. --arg repo_root=...).
    config["working_dir"] = variables["working_dir"]
    return variables


def _is_commit_good(test_type, wf_result, op_name, baseline_value, regression_pct, threshold):
    if test_type == "accuracy":
        return wf_result.success

    result_values = wf_result.result_values
    if result_values is None:
        return False

    if op_name and op_name in result_values:
        value = result_values[op_name]
    elif result_values:
        value = next(iter(result_values.values()))
    else:
        return False

    if threshold is not None:
        return value <= threshold

    if baseline_value is not None and baseline_value > 0:
        allowed = baseline_value * (1 + regression_pct / 100)
        return value <= allowed

    return wf_result.success


def _get_perf_baseline(
    config, workflow_cfg, tasks, good_commit, variables, op_name,
    repeat=1, repeat_agg="avg", outlier_detection_cfg=None,
):
    git_repo = resolve_bisect_git_repo(config)
    _checkout(git_repo, good_commit)

    step_vars = dict(variables)
    step_vars["commit"] = good_commit
    wf_runner = WorkflowRunner()
    wf_result = wf_runner.run(
        workflow_cfg, tasks, git_repo, config.get("name", "unknown"),
        step_vars, global_env=config.get("env"), config=config,
        repeat=repeat, repeat_agg=repeat_agg,
        outlier_detection_cfg=outlier_detection_cfg,
    )

    if wf_result.result_values:
        if op_name and op_name in wf_result.result_values:
            return wf_result.result_values[op_name]
        return next(iter(wf_result.result_values.values()), None)
    return None


def _get_commit_range(repo_path, good, bad):
    proc = subprocess.run(["git", "rev-list", "--reverse", f"{good}..{bad}"], cwd=repo_path, capture_output=True, text=True)
    if proc.returncode != 0:
        return []
    return [c for c in proc.stdout.strip().split("\n") if c]


def _checkout(repo_path, commit):
    print(f"  Checking out commit {commit[:8]}...")
    subprocess.run(["git", "checkout", commit], cwd=repo_path, capture_output=True)


def _get_current_ref(repo_path):
    proc = subprocess.run(["git", "symbolic-ref", "--short", "HEAD"], cwd=repo_path, capture_output=True, text=True)
    if proc.returncode == 0:
        return proc.stdout.strip()
    proc = subprocess.run(["git", "rev-parse", "HEAD"], cwd=repo_path, capture_output=True, text=True)
    return proc.stdout.strip()


def _check_skip_limit(skipped, total):
    if total > 0 and skipped / total > 0.5:
        raise BisectAbortError(f"Too many skips ({skipped}/{total}). Aborting bisect — check build/test configuration.")


def _run_pre_workflow(config, bisect_cfg, tasks, workflows, variables, outlier_detection_cfg=None):
    """Run pre_workflow once before bisect loop (e.g., full deployment)."""
    pre_wf = bisect_cfg.get("pre_workflow")
    if not pre_wf:
        return

    if pre_wf not in workflows:
        logger.warning(f"pre_workflow '{pre_wf}' not found, skipping")
        return

    workflow_cfg = workflows[pre_wf]
    print(f"  Running pre-workflow '{pre_wf}'...")
    wf_runner = WorkflowRunner()
    wf_result = wf_runner.run(
        workflow_cfg, tasks, resolve_bisect_git_repo(config), config.get("name", "unknown"),
        variables, global_env=config.get("env"), config=config,
        outlier_detection_cfg=outlier_detection_cfg,
    )

    if not wf_result.success:
        raise BisectAbortError(f"Pre-workflow '{pre_wf}' failed at step '{wf_result.failed_step}'")

    print(f"  Pre-workflow '{pre_wf}' completed successfully")
