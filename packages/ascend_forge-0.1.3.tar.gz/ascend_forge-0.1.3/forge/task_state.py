"""Task state persistence for daemon mode."""

import json
import logging
import os
from dataclasses import dataclass, field, asdict, fields
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class TaskState:
    """Represents the state of a forge task."""
    task_id: str
    command: str
    args: dict[str, Any]
    status: str = "pending"  # pending, running, completed, failed, cancelled, interrupted
    progress: dict[str, Any] = field(default_factory=dict)
    started_at: str | None = None
    pid: int | None = None
    restart_count: int = 0
    max_restarts: int = 3
    config_path: str | None = None
    error: str | None = None
    verbose: bool = False
    owner: str | None = None
    client_ip: str | None = None

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "TaskState":
        known = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in known})


def _tasks_dir() -> Path:
    """Get the tasks directory path."""
    return Path.home() / ".forge" / "tasks"


def _task_path(task_id: str) -> Path:
    """Get the path to a task state file."""
    return _tasks_dir() / f"{task_id}.json"


def save_task_state(state: TaskState) -> str:
    """Save task state to file. Returns the file path."""
    task_dir = _tasks_dir()
    task_dir.mkdir(parents=True, exist_ok=True)
    path = _task_path(state.task_id)
    with open(path, "w") as f:
        json.dump(state.to_dict(), f, indent=2)
    logger.debug(f"Saved task state: {state.task_id} (status={state.status})")
    return str(path)


def load_task_state(task_id: str) -> TaskState | None:
    """Load task state from file."""
    path = _task_path(task_id)
    if not path.exists():
        return None
    try:
        with open(path) as f:
            data = json.load(f)
        return TaskState.from_dict(data)
    except (json.JSONDecodeError, KeyError) as e:
        logger.error(f"Failed to load task state {task_id}: {e}")
        return None


def list_task_states(status: str | None = None) -> list[TaskState]:
    """List all task states, optionally filtered by status."""
    task_dir = _tasks_dir()
    if not task_dir.exists():
        return []

    states = []
    for path in sorted(task_dir.glob("*.json")):
        try:
            with open(path) as f:
                data = json.load(f)
            state = TaskState.from_dict(data)
            if status is None or state.status == status:
                states.append(state)
        except (json.JSONDecodeError, KeyError) as e:
            logger.warning(f"Skipping corrupted task state {path}: {e}")

    return states


def delete_task_state(task_id: str) -> bool:
    """Delete a task state file. Returns True if deleted."""
    path = _task_path(task_id)
    if path.exists():
        path.unlink()
        logger.debug(f"Deleted task state: {task_id}")
        return True
    return False


def generate_task_id() -> str:
    """Generate a unique task ID."""
    import uuid
    return f"task_{uuid.uuid4().hex[:8]}"


def mark_running(state: TaskState, pid: int) -> TaskState:
    """Mark a task as running with the given PID."""
    state.status = "running"
    state.pid = pid
    state.started_at = datetime.now().isoformat()
    return state


def mark_completed(state: TaskState) -> TaskState:
    """Mark a task as completed."""
    state.status = "completed"
    state.pid = None
    return state


def mark_failed(state: TaskState, error: str | None = None) -> TaskState:
    """Mark a task as failed."""
    state.status = "failed"
    state.pid = None
    state.error = error
    return state


def mark_interrupted(state: TaskState) -> TaskState:
    """Mark a task as interrupted (for recovery)."""
    state.status = "interrupted"
    state.pid = None
    return state