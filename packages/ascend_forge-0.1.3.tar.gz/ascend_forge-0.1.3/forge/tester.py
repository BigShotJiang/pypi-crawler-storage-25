"""Test execution and result extraction (stdout and file)."""

import logging

from forge.config import resolve_tasks
from forge.task import TaskRunner, TaskResult, get_head_commit, extract_result_from_stdout, extract_result_from_file, resolve_source_env

logger = logging.getLogger(__name__)


# Backward-compatible alias
TestResult = TaskResult


def run_test(config: dict, test_type: str, op_name: str | None = None, commit: str | None = None, extra_vars: dict[str, str] | None = None, repeat: int | None = None, repeat_agg: str | None = None, variables: dict[str, str] | None = None) -> TaskResult:
    repo_name = config.get("name", "unknown")

    # Resolve tasks (handles both new 'tasks' and legacy 'build'/'tests' fields)
    tasks = resolve_tasks(config)

    # Find test config by name
    test_cfg = tasks.get(test_type)
    if test_cfg is None:
        raise ValueError(f"Test type '{test_type}' not found in tasks. Available: {list(tasks.keys())}")

    logger.debug(f"Running {test_type} test on '{repo_name}' (op_name={op_name}, commit={commit})")

    if variables is None:
        # Backward-compatible internal variable construction
        variables = dict(config.get("vars", {}))
        variables.update({
            "working_dir": config["working_dir"],
            "config_dir": config.get("_config_dir", ""),
            "timestamp": _make_timestamp(),
        })
        if op_name:
            variables["op_name"] = op_name
        if commit:
            variables["commit"] = commit
        else:
            head = get_head_commit(config["working_dir"])
            if head:
                variables["commit"] = head
        if extra_vars:
            variables.update(extra_vars)
        from forge.config import resolve_vars
        variables = resolve_vars(variables)
    else:
        # Use pre-built variables; honor explicit overrides
        if commit:
            variables["commit"] = commit
        if op_name and "op_name" not in variables:
            variables["op_name"] = op_name

    working_dir = variables["working_dir"]

    # Source environment script: test-specific > top-level
    source_env_raw = test_cfg.get("source_env") or config.get("source_env")
    sourced_env = None
    if source_env_raw:
        # Pass source_env via a task_cfg overlay so resolve_source_env picks it up
        sourced_env = resolve_source_env(
            config, {"source_env": source_env_raw}, variables, working_dir
        )

    effective_repeat = repeat if repeat is not None else test_cfg.get("repeat", 1)
    effective_repeat_agg = repeat_agg if repeat_agg is not None else test_cfg.get("repeat_agg", "avg")
    logger.debug(f"Test repeat={effective_repeat}, repeat_agg={effective_repeat_agg}")

    runner = TaskRunner()
    runner.default_timeout = 300
    label = f"test_{test_type}"

    def _check_op_name(result):
        """Check op_name empty-result condition (test-specific business logic)."""
        if result.success and op_name and result.result_values is not None and not result.result_values:
            logger.warning(f"No matching results for op '{op_name}' in test output")
            return TaskResult(success=False, stdout=result.stdout, stderr=result.stderr,
                             timed_out=result.timed_out, result_values=result.result_values)
        return result

    global_env = config.get("env")
    effective_task_cfg = dict(test_cfg)
    effective_task_cfg["repeat"] = effective_repeat
    effective_task_cfg["repeat_agg"] = effective_repeat_agg

    result = runner.run(effective_task_cfg, working_dir, repo_name, label, variables,
                        sourced_env=sourced_env, global_env=global_env)
    return _check_op_name(result)


def _make_timestamp() -> str:
    from datetime import datetime
    return datetime.now().strftime("%Y%m%d_%H%M%S")
