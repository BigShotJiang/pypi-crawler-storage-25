"""ASCII table formatter for bisect results."""


def format_bisect_table(result, test_type: str, op_name: str | None = None) -> str:
    """Format bisect step records as an ASCII table."""
    if not result.step_records:
        return ""

    if test_type == "accuracy":
        return _format_accuracy_table(result)
    else:
        return _format_performance_table(result, op_name)


def _format_accuracy_table(result) -> str:
    """Format accuracy bisect results."""
    headers = ["Commit", "Result", "Status"]
    rows = []
    for rec in result.step_records:
        commit = rec.commit[:8]
        if rec.status == "skip":
            test_result = rec.skip_reason or "SKIP"
            status = "skip"
        else:
            test_result = "PASS" if rec.status == "good" else "FAIL"
            status = rec.status
        marker = "  <-- first bad" if rec.commit == result.found_commit and rec.status == "bad" else ""
        rows.append([commit, test_result, status + marker])

    lines = _render_table(headers, rows)

    lines.append(f"First bad commit: {result.found_commit[:8] if result.found_commit else 'N/A'}")
    lines.append(f"Total steps: {result.total_steps}, skipped: {result.skipped_steps}")
    return "\n".join(lines)


def _format_performance_table(result, op_name: str | None) -> str:
    """Format performance bisect results."""
    headers = ["Commit", "Op", "Value", "Status"]
    rows = []
    for rec in result.step_records:
        commit = rec.commit[:8]
        if rec.status == "skip":
            rows.append([commit, "-", rec.skip_reason or "SKIP", "skip"])
            continue

        if rec.result_values:
            if op_name and op_name in rec.result_values:
                op_key = op_name
                value = rec.result_values[op_name]
            elif rec.result_values:
                op_key = next(iter(rec.result_values))
                value = rec.result_values[op_key]
            else:
                op_key = "-"
                value = "-"
        else:
            op_key = "-"
            value = "-"

        value_str = f"{value:.4f}" if isinstance(value, float) else str(value)
        marker = "  <-- first bad" if rec.commit == result.found_commit and rec.status == "bad" else ""
        rows.append([commit, op_key, value_str, rec.status + marker])

    lines = _render_table(headers, rows)

    # Summary line
    parts = []
    if result.baseline_value is not None:
        parts.append(f"Baseline: {result.baseline_value:.4f}")
    if result.threshold is not None:
        parts.append(f"Threshold: {result.threshold}")
    elif result.regression_pct is not None:
        parts.append(f"Regression limit: +{result.regression_pct}%")
    if parts:
        lines.append(" | ".join(parts))

    lines.append(f"First bad commit: {result.found_commit[:8] if result.found_commit else 'N/A'}")
    lines.append(f"Total steps: {result.total_steps}, skipped: {result.skipped_steps}")
    return "\n".join(lines)


def _render_table(headers: list[str], rows: list[list[str]]) -> list[str]:
    """Render a simple ASCII table."""
    # Calculate column widths
    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(str(cell)))

    # Build format string
    def _row_str(cells):
        parts = []
        for i, cell in enumerate(cells):
            parts.append(f" {str(cell):<{col_widths[i]}} ")
        return "|" + "|".join(parts) + "|"

    separator = "+" + "+".join("-" * (w + 2) for w in col_widths) + "+"

    lines = [separator, _row_str(headers), separator]
    for row in rows:
        lines.append(_row_str(row))
    lines.append(separator)
    return lines
