"""Config migration: repo_path/test_path → working_dir."""

import copy
import json
from pathlib import Path


def migrate_config(config: dict) -> tuple[dict, list[str]]:
    """Migrate a config dict from old format to new unified format.

    Handles:
    1. repo_path → working_dir (existing)
    2. test_path → vars.test_path (existing)
    3. {repo_path} → {working_dir} placeholder (existing)
    4. build → tasks.build (NEW)
    5. tests.accuracy → tasks.accuracy (NEW, no test_ prefix)
    6. tests.source_env → removed with warning (NEW)
    7. bisect.build_before_test → generate workflow (NEW)
    8. bisect.post_workflow: true → explicit name (NEW)
    9. bisect.workflow (string) → bisect.workflows array (NEW)
    10. bisect.post_workflow (string) → bisect.post_workflows array (NEW)

    Returns (migrated_config, list_of_change_descriptions).
    Does not modify the input dict.
    """
    if "repo_path" not in config and "build" not in config and "tests" not in config and "bisect" not in config:
        return config, []

    result = copy.deepcopy(config)
    changes = []

    # 1. repo_path → working_dir
    if "repo_path" in result:
        result["working_dir"] = result.pop("repo_path")
        changes.append("repo_path → working_dir")

    # 2. test_path → vars.test_path
    if "test_path" in result:
        test_path = result.pop("test_path")
        if "vars" not in result:
            result["vars"] = {}
        result["vars"]["test_path"] = test_path
        changes.append(f"test_path → vars.test_path ({test_path})")

    # 4. build → tasks.build (only if not already present)
    if "build" in result:
        if "tasks" not in result:
            result["tasks"] = {}
        if "build" not in result["tasks"]:
            result["tasks"]["build"] = result.pop("build")
            changes.append("build → tasks.build")
        else:
            result.pop("build")
            changes.append("build removed (tasks.build already exists)")

    # 5-6. tests → tasks (no test_ prefix), source_env removed with warning
    if "tests" in result:
        tests = result.pop("tests")
        if "tasks" not in result:
            result["tasks"] = {}

        for test_name, test_cfg in tests.items():
            if not isinstance(test_cfg, dict):
                # Non-dict entry like tests.source_env
                if test_name == "source_env":
                    changes.append(f"tests.source_env removed (was: {test_cfg}) - configure per-task source_env instead")
                else:
                    changes.append(f"tests.{test_name} removed (non-dict entry, unsupported)")
                continue
            # Move test config to tasks (no prefix) - only if not already present
            if test_name not in result["tasks"]:
                result["tasks"][test_name] = test_cfg
                changes.append(f"tests.{test_name} → tasks.{test_name}")
            else:
                changes.append(f"tests.{test_name} removed (tasks.{test_name} already exists)")

    # 7. bisect.build_before_test → generate workflow
    bisect = result.get("bisect", {})
    if "build_before_test" in bisect and "workflow" not in bisect:
        build_before = bisect.pop("build_before_test")
        # Find test type from tasks (first non-build task)
        test_type = None
        for task_name in result.get("tasks", {}):
            if task_name != "build":
                test_type = task_name
                break
        if test_type:
            if "workflows" not in result:
                result["workflows"] = {}
            wf_tasks = []
            if build_before and "build" in result.get("tasks", {}):
                wf_tasks.append("build")
            wf_tasks.append(test_type)
            wf_name = "_bisect_default"
            result["workflows"][wf_name] = {"tasks": wf_tasks}
            bisect["workflow"] = wf_name
            result["bisect"] = bisect
            changes.append(f"bisect.build_before_test → workflow '{wf_name}'")
        else:
            # No test type found, cannot generate workflow
            changes.append("bisect.build_before_test removed (no test task found to generate workflow)")

    # 8. bisect.post_workflow: true → explicit name (then convert to post_workflows)
    if "bisect" in result and result["bisect"].get("post_workflow") is True:
        wf_name = result["bisect"].get("workflow")
        if wf_name:
            result["bisect"]["post_workflow"] = wf_name
            changes.append(f"bisect.post_workflow: true → explicit '{wf_name}'")

    # 9. bisect.workflow (string) → bisect.workflows array with repeatable
    if "bisect" in result and "workflow" in result["bisect"]:
        if "workflows" not in result["bisect"]:
            wf_name = result["bisect"].pop("workflow")
            result["bisect"]["workflows"] = [{"name": wf_name, "repeatable": True}]
            changes.append(f"bisect.workflow '{wf_name}' → bisect.workflows array")
        else:
            # workflows already exists, just remove the old workflow field
            result["bisect"].pop("workflow")
            changes.append("bisect.workflow removed (workflows already exists)")

    # 10. bisect.post_workflow → bisect.post_workflows array
    if "bisect" in result and "post_workflow" in result["bisect"]:
        post_wf = result["bisect"]["post_workflow"]
        if "post_workflows" not in result["bisect"] and isinstance(post_wf, str):
            # Convert string to array
            result["bisect"].pop("post_workflow")
            result["bisect"]["post_workflows"] = [post_wf]
            changes.append(f"bisect.post_workflow '{post_wf}' → bisect.post_workflows array")
        elif isinstance(post_wf, bool) and not post_wf:
            # post_workflow: false - remove it (no meaning)
            result["bisect"].pop("post_workflow")
            changes.append("bisect.post_workflow removed (was false)")
        elif "post_workflows" in result["bisect"] and isinstance(post_wf, str):
            # post_workflows already exists, remove the old post_workflow field
            result["bisect"].pop("post_workflow")
            changes.append("bisect.post_workflow removed (post_workflows already exists)")
        # Note: post_workflow: True without workflow name is left as-is (can't convert)

    # 3. Replace {repo_path} → {working_dir} in all string values
    count = _replace_placeholder(result, "repo_path", "working_dir")
    if count > 0:
        changes.append(f"{{repo_path}} → {{working_dir}} ({count} occurrences)")

    return result, changes


def _replace_placeholder(obj, old: str, new: str) -> int:
    """Recursively replace {old} with {new} in all string values. Returns count."""
    count = 0
    if isinstance(obj, dict):
        for key in list(obj.keys()):
            if isinstance(obj[key], str):
                if f"{{{old}}}" in obj[key]:
                    obj[key] = obj[key].replace(f"{{{old}}}", f"{{{new}}}")
                    count += 1
            elif isinstance(obj[key], (dict, list)):
                count += _replace_placeholder(obj[key], old, new)
    elif isinstance(obj, list):
        for i, item in enumerate(obj):
            if isinstance(item, str):
                if f"{{{old}}}" in item:
                    obj[i] = item.replace(f"{{{old}}}", f"{{{new}}}")
                    count += 1
            elif isinstance(item, (dict, list)):
                count += _replace_placeholder(item, old, new)
    return count


def migrate_file(path: Path, dry_run: bool = False) -> list[str]:
    """Migrate a single JSON config file. Returns change descriptions."""
    with open(path) as f:
        config = json.load(f)

    migrated, changes = migrate_config(config)

    if changes and not dry_run:
        with open(path, "w") as f:
            json.dump(migrated, f, indent=2, ensure_ascii=False)
            f.write("\n")

    return changes
