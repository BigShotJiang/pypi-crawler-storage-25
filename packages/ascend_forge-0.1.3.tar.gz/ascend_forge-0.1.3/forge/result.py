"""Result persistence and comparison."""

import json
import logging
import os
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class ResultRecord:
    repo: str
    commit: str
    test_type: str
    results: dict[str, float]
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


def _results_dir() -> Path:
    return Path.home() / ".forge" / "results"


def save_result(record: ResultRecord) -> str:
    logger.debug(f"Saving result: repo={record.repo}, commit={record.commit}, test_type={record.test_type}")
    repo_dir = _results_dir() / record.repo
    repo_dir.mkdir(parents=True, exist_ok=True)
    filename = f"{record.test_type}_{record.commit}_{record.timestamp.replace(':', '-')}.json"
    path = repo_dir / filename
    data = {"repo": record.repo, "commit": record.commit, "timestamp": record.timestamp, "type": record.test_type, "results": record.results}
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
    return str(path)


def _load_record_from_file(path: Path) -> ResultRecord:
    with open(path) as f:
        data = json.load(f)
    return ResultRecord(repo=data["repo"], commit=data["commit"], test_type=data["type"], results=data["results"], timestamp=data["timestamp"])


def load_latest_result(repo: str, test_type: str) -> ResultRecord | None:
    logger.debug(f"Loading latest result for {repo}/{test_type}")
    repo_dir = _results_dir() / repo
    if not repo_dir.exists():
        return None
    files = sorted([f for f in repo_dir.glob(f"{test_type}_*.json")], key=lambda f: f.name)
    if not files:
        return None
    return _load_record_from_file(files[-1])


def load_result_by_commit(repo: str, test_type: str, commit: str) -> ResultRecord | None:
    logger.debug(f"Loading result for {repo}/{test_type} at commit {commit}")
    repo_dir = _results_dir() / repo
    if not repo_dir.exists():
        return None
    for path in repo_dir.glob(f"{test_type}_{commit}*.json"):
        return _load_record_from_file(path)
    return None


def compare_results(current: dict[str, float], baseline: dict[str, float]) -> dict[str, dict]:
    all_ops = set(current.keys()) | set(baseline.keys())
    comparison = {}
    for op in sorted(all_ops):
        cur = current.get(op)
        base = baseline.get(op)
        change_pct = None
        if cur is not None and base is not None and base != 0:
            change_pct = ((cur - base) / base) * 100
        comparison[op] = {"current": cur, "baseline": base, "change_pct": change_pct}
    return comparison
