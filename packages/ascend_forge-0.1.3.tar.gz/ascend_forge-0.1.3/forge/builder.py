"""Build command orchestration."""

import logging
import subprocess

from forge.config import resolve_tasks
from forge.task import TaskRunner, TaskResult, make_timestamp, get_head_commit, resolve_source_env
from forge.log import dim

logger = logging.getLogger(__name__)


# Backward-compatible alias
BuildResult = TaskResult


def build(config: dict, commit: str | None = None, extra_vars: dict[str, str] | None = None, step_name: str | None = None, variables: dict[str, str] | None = None) -> TaskResult:
    repo_name = config.get("name", "unknown")

    # Resolve tasks (handles both new 'tasks' and legacy 'build' field)
    tasks = resolve_tasks(config)
    build_cfg = tasks.get("build")
    if build_cfg is None:
        raise ValueError("No 'build' task defined. Available tasks: " + str(list(tasks.keys())))

    if variables is None:
        # Backward-compatible internal variable construction
        variables = dict(config.get("vars", {}))
        variables.update({
            "working_dir": config["working_dir"],
            "config_dir": config.get("_config_dir", ""),
            "timestamp": make_timestamp(),
        })
        if commit:
            variables["commit"] = commit
        else:
            head = get_head_commit(config["working_dir"])
            if head:
                variables["commit"] = head
        if extra_vars:
            variables.update(extra_vars)
        from forge.config import resolve_vars
        variables = resolve_vars(variables)
    else:
        # Use pre-built variables; honor explicit commit override
        if commit:
            variables["commit"] = commit

    repo_path = variables["working_dir"]
    logger.debug(f"Starting build for '{repo_name}' at '{repo_path}'")

    original_branch = None
    stashed = False

    try:
        if commit:
            original_branch, stashed = _checkout_commit(repo_path, commit)

        logger.debug(f"Build variables: {variables}")

        runner = TaskRunner()
        sourced_env = resolve_source_env(config, build_cfg, variables, repo_path)
        return runner.run(build_cfg, repo_path, repo_name, "build", variables,
                          step_name=step_name, global_env=config.get("env"),
                          sourced_env=sourced_env)
    finally:
        if commit and original_branch:
            _restore_branch(repo_path, original_branch, stashed)


def _checkout_commit(repo_path: str, commit: str) -> tuple[str, bool]:
    proc = subprocess.run(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=repo_path, capture_output=True, text=True)
    original_branch = proc.stdout.strip()
    logger.debug(f"Current branch: {original_branch}")

    proc = subprocess.run(["git", "status", "--porcelain"], cwd=repo_path, capture_output=True, text=True)
    stashed = False
    if proc.stdout.strip():
        print(f"  {dim('Stashing uncommitted changes...')}")
        subprocess.run(["git", "stash", "push", "-m", "forge-auto-stash"], cwd=repo_path, capture_output=True)
        stashed = True
        logger.debug(f"Stashed uncommitted changes")

    print(f"  {dim(f'Checking out commit {commit[:8]}...')}")
    subprocess.run(["git", "checkout", commit], cwd=repo_path, capture_output=True)
    logger.debug(f"Checked out commit {commit[:8]}")
    return original_branch, stashed


def _restore_branch(repo_path: str, branch: str, stashed: bool) -> None:
    print(f"  {dim(f'Restoring branch {branch}...')}")
    subprocess.run(["git", "checkout", branch], cwd=repo_path, capture_output=True)
    logger.debug(f"Restored branch: {branch}")
    if stashed:
        print(f"  {dim('Restoring stashed changes...')}")
        subprocess.run(["git", "stash", "pop"], cwd=repo_path, capture_output=True)
        logger.debug(f"Restored stashed changes")
