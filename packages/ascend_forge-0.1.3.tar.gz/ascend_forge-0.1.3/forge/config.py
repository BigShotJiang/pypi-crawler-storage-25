"""Configuration loading, validation, and placeholder substitution."""

import json
import logging
import os
import re
from pathlib import Path

logger = logging.getLogger(__name__)


class ConfigError(Exception):
    """Raised for configuration errors."""
    pass


def load_config(path: str | Path) -> dict:
    """Load a single JSON config file."""
    path = Path(path)
    if not path.exists():
        raise ConfigError(f"Config file not found: {path}")
    try:
        with open(path) as f:
            config = json.load(f)
    except json.JSONDecodeError as e:
        raise ConfigError(f"Failed to parse JSON config {path}: {e}")
    if not isinstance(config, dict):
        raise ConfigError(f"Config file must contain a JSON object: {path}")
    config["_config_dir"] = str(path.parent)
    logger.debug(f"Loaded config from {path}: name={config.get('name', path.stem)}")
    return config


def load_all_configs(config_dir: str | None = None) -> dict[str, dict]:
    """Load all JSON configs from a directory. Returns {name: config}."""
    if config_dir is None:
        config_dir = os.environ.get("FORGE_CONFIG_DIR")
    if config_dir is None:
        config_dir = os.path.join(os.path.dirname(__file__), "..", "configs")
    config_dir = Path(config_dir)
    logger.debug(f"Loading configs from directory: {config_dir}")
    if not config_dir.is_dir():
        raise ConfigError(f"Config directory not found: {config_dir}")
    configs = {}
    name_to_file = {}  # Track which file each name comes from
    for path in sorted(config_dir.glob("*.json")):
        try:
            config = load_config(path)
            name = config.get("name", path.stem)
            if name in configs:
                # Duplicate name found
                import sys
                print(f"Warning: duplicate config name '{name}' in {path.name}, "
                      f"already defined in {name_to_file[name]}. "
                      f"Using {path.name}.", file=sys.stderr)
            configs[name] = config
            name_to_file[name] = path.name
            logger.debug(f"Loaded config '{name}' from {path.name}")
        except ConfigError as e:
            import sys
            print(f"Warning: skipping {path.name}: {e}", file=sys.stderr)
    return configs


def validate_config(config: dict) -> None:
    """Validate a config dict. Raises ConfigError on problems."""
    _require_field(config, "name", "top-level")
    _require_field(config, "working_dir", "top-level")

    # Check for at least one task definition source
    has_tasks = "tasks" in config
    has_build = "build" in config
    has_tests = "tests" in config
    if not (has_tasks or has_build or has_tests):
        raise ConfigError(
            "No tasks defined. Define 'tasks' section or use legacy 'build'/'tests'. "
            "Run 'forge migrate' to convert legacy configs."
        )

    # Validate tasks section if present
    if "tasks" in config:
        tasks_cfg = config["tasks"]
        if not isinstance(tasks_cfg, dict):
            raise ConfigError("tasks must be a dictionary")
        for task_name, task_def in tasks_cfg.items():
            if not isinstance(task_def, dict):
                raise ConfigError(f"tasks.{task_name} must be a dictionary")
            _validate_task_def(task_def, f"tasks.{task_name}")

    # Validate legacy build section
    if "build" in config:
        build_cfg = config["build"]
        if "steps" in build_cfg:
            if not isinstance(build_cfg["steps"], list) or len(build_cfg["steps"]) == 0:
                raise ConfigError("build.steps must be a non-empty list")
            for i, step in enumerate(build_cfg["steps"]):
                _require_field(step, "command", f"build.steps[{i}]")
        else:
            _require_field(build_cfg, "command", "build")

    # Validate legacy tests section
    if "tests" in config:
        for test_name, test_cfg in config["tests"].items():
            if not isinstance(test_cfg, dict):
                continue  # Skip non-test-type entries (e.g. source_env)
            if "steps" in test_cfg:
                # Multi-step mode
                if not isinstance(test_cfg["steps"], list) or len(test_cfg["steps"]) == 0:
                    raise ConfigError(f"tests.{test_name}.steps must be a non-empty list")
                for i, step in enumerate(test_cfg["steps"]):
                    ctx = f"tests.{test_name}.steps[{i}]"
                    _require_field(step, "command", ctx)
                    if "result" in step:
                        _validate_result(step["result"], ctx)
            else:
                # Single-command mode
                _require_field(test_cfg, "command", f"tests.{test_name}")
                if "result" in test_cfg:
                    _validate_result(test_cfg["result"], f"tests.{test_name}")


def _require_field(d: dict, field: str, context: str) -> None:
    if field not in d:
        raise ConfigError(f"Missing required field '{field}' in {context}")


def _validate_result(result: dict, context: str) -> None:
    """Validate a result extraction config block."""
    rtype = result.get("type")
    if rtype not in ("stdout", "file"):
        raise ConfigError(f"{context}.result.type must be 'stdout' or 'file', got '{rtype}'")
    if rtype == "stdout":
        _require_field(result, "pattern", f"{context}.result")
    elif rtype == "file":
        _require_field(result, "path", f"{context}.result")
        _require_field(result, "value_column", f"{context}.result")


def _validate_outlier_detection(d: dict, context: str) -> None:
    """Validate optional outlier detection settings."""
    if "outlier_detection" not in d:
        return

    outlier_detection = d["outlier_detection"]
    if not isinstance(outlier_detection, dict):
        raise ConfigError(f"{context}.outlier_detection must be an object")

    allowed_keys = {"method", "max_outlier_ratio", "iqr_multiplier", "min_samples"}
    for key in outlier_detection:
        if key not in allowed_keys:
            raise ConfigError(f"{context}.outlier_detection.{key} is not allowed")

    method = outlier_detection.get("method", "iqr")
    if method != "iqr":
        raise ConfigError(f"{context}.outlier_detection.method must be: iqr")

    max_outlier_ratio = outlier_detection.get("max_outlier_ratio")
    if max_outlier_ratio is not None:
        if (
            isinstance(max_outlier_ratio, bool)
            or not isinstance(max_outlier_ratio, (int, float))
            or not 0 <= max_outlier_ratio <= 1
        ):
            raise ConfigError(
                f"{context}.outlier_detection.max_outlier_ratio must be between 0 and 1"
            )

    iqr_multiplier = outlier_detection.get("iqr_multiplier")
    if iqr_multiplier is not None:
        if (
            isinstance(iqr_multiplier, bool)
            or not isinstance(iqr_multiplier, (int, float))
            or iqr_multiplier <= 0
        ):
            raise ConfigError(f"{context}.outlier_detection.iqr_multiplier must be > 0")

    min_samples = outlier_detection.get("min_samples")
    if min_samples is not None:
        if not isinstance(min_samples, int) or isinstance(min_samples, bool) or min_samples <= 0:
            raise ConfigError(
                f"{context}.outlier_detection.min_samples must be a positive integer"
            )


def _validate_repeat_fields(d: dict, context: str) -> None:
    """Validate repeat and repeat_agg fields in a task or step definition."""
    repeat = d.get("repeat")
    if repeat is not None and (not isinstance(repeat, int) or isinstance(repeat, bool) or repeat <= 0):
        raise ConfigError(f"{context}.repeat must be a positive integer")

    repeat_agg = d.get("repeat_agg")
    if repeat_agg is not None and repeat_agg not in ("avg", "max", "avg_without_outliers"):
        raise ConfigError(f"{context}.repeat_agg must be one of: avg, max, avg_without_outliers")


def _validate_task_def(task_def: dict, context: str) -> None:
    """Validate a single task definition (command or steps format)."""
    _validate_repeat_fields(task_def, context)
    _validate_outlier_detection(task_def, context)
    if "steps" in task_def:
        if not isinstance(task_def["steps"], list) or len(task_def["steps"]) == 0:
            raise ConfigError(f"{context}.steps must be a non-empty list")
        for i, step in enumerate(task_def["steps"]):
            _validate_repeat_fields(step, f"{context}.steps[{i}]")
            _validate_outlier_detection(step, f"{context}.steps[{i}]")
            _require_field(step, "command", f"{context}.steps[{i}]")
            if "result" in step:
                _validate_result(step["result"], f"{context}.steps[{i}]")
    else:
        _require_field(task_def, "command", context)
        if "result" in task_def:
            _validate_result(task_def["result"], context)


def substitute_placeholders(
    value: str | list[str], variables: dict[str, str]
) -> str | list[str]:
    """Replace {placeholder} tokens in a string or list of strings."""
    if isinstance(value, list):
        return [substitute_placeholders(item, variables) for item in value]

    placeholders = re.findall(r"\{(\w+)\}", value)
    if placeholders:
        logger.debug(f"Substituting placeholders in '{value[:50]}...': {placeholders}")
    for ph in placeholders:
        if ph not in variables:
            raise ConfigError(
                f"Placeholder '{{{ph}}}' not provided. "
                f"Available: {list(variables.keys())}"
            )
    for key, val in variables.items():
        value = value.replace(f"{{{key}}}", val)
    if placeholders:
        logger.debug(f"Substitution result: '{value[:50]}...'")
    return value


def resolve_vars(variables: dict[str, str], max_iterations: int = 10) -> dict[str, str]:
    """Resolve placeholder references within variable values themselves.

    Iteratively substitutes {placeholder} in variable values until no more
    changes occur. Detects circular references by limiting iterations.
    """
    result = dict(variables)
    # Track which keys originally reference other keys (not self)
    cross_refs = set()
    for key, val in result.items():
        if isinstance(val, str):
            for ph in re.findall(r"\{(\w+)\}", val):
                if ph in result and ph != key:
                    cross_refs.add(key)
                    break

    for i in range(max_iterations):
        changed = False
        for key, val in result.items():
            if not isinstance(val, str) or "{" not in val:
                continue
            new_val = val
            for ph in re.findall(r"\{(\w+)\}", val):
                if ph in result and ph != key:
                    new_val = new_val.replace(f"{{{ph}}}", result[ph])
            if new_val != val:
                result[key] = new_val
                changed = True
        if not changed:
            break
    else:
        raise ConfigError(
            f"Circular reference in vars (unresolved after {max_iterations} iterations)"
        )
    # Check: keys that had cross-references should now be fully resolved
    unresolved = []
    for key in cross_refs:
        val = result[key]
        if isinstance(val, str):
            remaining = [ph for ph in re.findall(r"\{(\w+)\}", val) if ph in result]
            if remaining:
                unresolved.append(f"{key} -> {{{remaining[0]}}}")
    if unresolved:
        raise ConfigError(
            f"Circular reference in vars: " + ", ".join(unresolved)
        )
    return result


def collect_placeholders(config_section: dict | list | str) -> set[str]:
    """Recursively collect all {placeholder} names from a config section."""
    found = set()
    if isinstance(config_section, str):
        found.update(re.findall(r"\{(\w+)\}", config_section))
    elif isinstance(config_section, list):
        for item in config_section:
            found.update(collect_placeholders(item))
    elif isinstance(config_section, dict):
        for value in config_section.values():
            found.update(collect_placeholders(value))
    return found


def check_placeholders(config: dict, section: str, variables: dict[str, str]) -> None:
    """Check all placeholders in a config section are provided. Print variable table."""
    if section not in config:
        return
    needed = collect_placeholders(config[section])
    # Collect variables that will be produced by capture at runtime
    captured_vars = _collect_capture_vars(config[section])
    known = set(variables.keys()) | captured_vars | set(config.get("vars", {}).keys())
    missing = needed - known
    if missing:
        raise ConfigError(
            f"Missing placeholder(s) for {section}: {', '.join(f'{{{p}}}' for p in sorted(missing))}. "
            f"Use --arg KEY=VALUE or --arg @file.json to provide them."
        )
    # Print variable table
    used = {k: v for k, v in variables.items() if k in needed}
    if used:
        print("Variables:")
        for key, val in used.items():
            empty_hint = "  (empty)" if val == "" else ""
            print(f"  {key} = {val}{empty_hint}")
    empty_vars = [k for k, v in variables.items() if k in needed and v == ""]
    if empty_vars:
        logger.warning(
            "Placeholder(s) with empty value: %s. "
            "These will be passed as empty strings to commands.",
            ", ".join(f"{{{p}}}" for p in sorted(empty_vars)),
        )
    captured_used = captured_vars & needed
    if captured_used:
        for key in sorted(captured_used):
            print(f"  {key} = (captured at runtime)")


def check_task_placeholders(task_cfg: dict, variables: dict[str, str], config_vars: dict[str, str] | None = None) -> None:
    """Check all placeholders in one resolved task are provided. Print variable table."""
    needed = collect_placeholders(task_cfg)
    captured_vars = _collect_capture_vars(task_cfg)
    known = set(variables.keys()) | captured_vars | set((config_vars or {}).keys())
    missing = needed - known
    if missing:
        raise ConfigError(
            f"Missing placeholder(s) for current task: {', '.join(f'{{{p}}}' for p in sorted(missing))}. "
            f"Use --arg KEY=VALUE or --arg @file.json to provide them."
        )
    used = {k: v for k, v in variables.items() if k in needed}
    if used:
        print("Variables:")
        for key, val in used.items():
            empty_hint = "  (empty)" if val == "" else ""
            print(f"  {key} = {val}{empty_hint}")
    empty_vars = [k for k, v in variables.items() if k in needed and v == ""]
    if empty_vars:
        logger.warning(
            "Placeholder(s) with empty value: %s. "
            "These will be passed as empty strings to commands.",
            ", ".join(f"{{{p}}}" for p in sorted(empty_vars)),
        )
    captured_used = captured_vars & needed
    if captured_used:
        for key in sorted(captured_used):
            print(f"  {key} = (captured at runtime)")


def _collect_capture_vars(config_section) -> set[str]:
    """Recursively collect all variable names defined by 'capture' fields."""
    found = set()
    if isinstance(config_section, dict):
        if "capture" in config_section and isinstance(config_section["capture"], dict):
            found.update(config_section["capture"].keys())
        for value in config_section.values():
            found.update(_collect_capture_vars(value))
    elif isinstance(config_section, list):
        for item in config_section:
            found.update(_collect_capture_vars(item))
    return found


def resolve_working_dir_path(config: dict, config_dir: str) -> str:
    """Resolve working_dir: absolute stays as-is, relative resolves from config_dir."""
    working_dir = config["working_dir"]
    if os.path.isabs(working_dir):
        return working_dir
    return str(os.path.normpath(os.path.join(config_dir, working_dir)))


def get_timeout(timeout_value: int | None) -> float | None:
    """Convert timeout config value to subprocess timeout. 0/None = no limit."""
    if timeout_value is None or timeout_value == 0:
        return None
    return float(timeout_value)


def resolve_tasks(config: dict, validate: bool = False) -> dict[str, dict]:
    """Resolve all tasks from config. Maps legacy build/tests to unified tasks dict.

    Priority: explicit tasks > legacy build/tests (on name collision).

    Emits DeprecationWarning when using legacy build/tests fields.
    Raises ConfigError with migrate hint when no tasks found and validate=True.
    """
    import warnings

    tasks = {}
    has_legacy = False

    # Map legacy build section
    if "build" in config:
        tasks["build"] = config["build"]
        has_legacy = True

    # Map legacy tests section
    if "tests" in config:
        for test_name, test_cfg in config["tests"].items():
            if not isinstance(test_cfg, dict):
                continue  # Skip non-test entries (e.g. source_env string)
            tasks[test_name] = test_cfg
        has_legacy = True

    # Explicit tasks override legacy mappings
    if "tasks" in config:
        tasks.update(config["tasks"])

    # Emit deprecation warning if using legacy fields
    if has_legacy:
        warnings.warn(
            "Config uses deprecated 'build' and/or 'tests' fields. "
            "Run 'forge migrate' to update to the new 'tasks' format.",
            DeprecationWarning,
            stacklevel=2,
        )

    if validate:
        if not tasks:
            raise ConfigError(
                "No tasks defined. Define 'tasks' section or use legacy 'build'/'tests'. "
                "Run 'forge migrate' to convert legacy configs."
            )
        _validate_tasks(tasks)

    return tasks


def _validate_tasks(tasks: dict) -> None:
    """Validate all tasks have required fields."""
    for name, cfg in tasks.items():
        _validate_task_def(cfg, f"tasks.{name}")


def resolve_workflows(config: dict, test_type: str | None = None) -> tuple[dict[str, dict], list[str]]:
    """Resolve workflows from config. Auto-converts legacy formats.

    Returns (workflows_dict, deprecation_warnings).
    """
    warnings = []
    workflows = {}

    raw = config.get("workflows", {})
    for name, wf in raw.items():
        if isinstance(wf, list):
            workflows[name] = {"tasks": wf}
            warnings.append(
                f"Deprecation: workflow '{name}' uses list format. "
                f"Migrate to {{\"tasks\": [...]}} format."
            )
        elif isinstance(wf, dict) and "steps" in wf:
            raise ConfigError(
                f"workflows.{name}.steps has been removed; "
                f"use workflows.{name}.tasks instead"
            )
        else:
            workflows[name] = wf  # pass through, validation catches errors

    # Auto-generate bisect workflow from legacy build_before_test
    bisect_cfg = config.get("bisect", {})
    if "build_before_test" in bisect_cfg and "workflow" not in bisect_cfg:
        if test_type:
            task_names = []
            if bisect_cfg.get("build_before_test", True):
                task_names.append("build")
            task_names.append(test_type)
            workflows["_bisect_auto"] = {"tasks": task_names}
            warnings.append(
                "Deprecation: bisect.build_before_test is deprecated. "
                "Use bisect.workflow instead. Run 'forge migrate' to update your config."
            )

    return workflows, warnings


def resolve_bisect_git_repo(config: dict) -> str:
    """Resolve bisect git repo path, honoring legacy bisect.working_dir."""
    bisect_cfg = config.get("bisect", {})
    return bisect_cfg.get("git_repo") or bisect_cfg.get("working_dir") or config["working_dir"]


def resolve_bisect_workflows(config: dict, test_type: str | None = None) -> tuple[list[dict], dict[str, dict], list[str]]:
    """Resolve bisect.workflows array from config.

    Handles both new array format and legacy single workflow string.
    Also preserves legacy bisect.build_before_test behavior by auto-generating
    a workflow when possible.

    Returns (workflows_list, workflows_def, deprecation_warnings).

    Each workflow in list has: name, repeatable (default True).
    """
    bisect_cfg = config.get("bisect", {})
    warnings = []

    workflows_def, workflow_warnings = resolve_workflows(config, test_type=test_type)
    warnings.extend(workflow_warnings)

    # Check for legacy single workflow format
    if "workflow" in bisect_cfg and "workflows" not in bisect_cfg:
        wf_name = bisect_cfg["workflow"]
        # Validate workflow exists
        if wf_name not in workflows_def:
            available = list(workflows_def.keys())
            raise ConfigError(
                f"Workflow '{wf_name}' not found in workflows definition. "
                f"Available: {available}"
            )
        warnings.append(
            f"Deprecation: bisect.workflow '{wf_name}' uses legacy format. "
            f"Migrate to bisect.workflows array format."
        )
        # Convert to array format
        return [{"name": wf_name, "repeatable": True}], workflows_def, warnings

    # Legacy build_before_test path is handled by resolve_workflows via _bisect_auto
    if "build_before_test" in bisect_cfg and "workflows" not in bisect_cfg and "workflow" not in bisect_cfg:
        if "_bisect_auto" not in workflows_def:
            raise ConfigError(
                "bisect.build_before_test requires a test_type to auto-generate a workflow. "
                "Run 'forge migrate' to convert to bisect.workflows."
            )
        return [{"name": "_bisect_auto", "repeatable": True}], workflows_def, warnings

    # New array format
    wf_array = bisect_cfg.get("workflows", [])

    if not wf_array:
        raise ConfigError(
            "bisect.workflows must have at least one workflow. "
            "Example: bisect.workflows = [{'name': 'build', 'repeatable': false}]. "
            "Run 'forge migrate' to convert legacy bisect config."
        )

    # Validate and normalize each workflow entry
    result = []
    for entry in wf_array:
        if isinstance(entry, str):
            # Shorthand: just workflow name
            if entry not in workflows_def:
                available = list(workflows_def.keys())
                raise ConfigError(
                    f"Workflow '{entry}' not found in workflows definition. "
                    f"Available: {available}"
                )
            result.append({"name": entry, "repeatable": True})
        elif isinstance(entry, dict):
            if "name" not in entry:
                raise ConfigError(
                    f"bisect.workflows entry missing 'name': {entry}"
                )
            wf_name = entry["name"]
            # Validate workflow exists
            if wf_name not in workflows_def:
                available = list(workflows_def.keys())
                raise ConfigError(
                    f"Workflow '{wf_name}' not found in workflows definition. "
                    f"Available: {available}"
                )
            result.append({
                "name": wf_name,
                "repeatable": entry.get("repeatable", True)
            })
        else:
            raise ConfigError(
                f"bisect.workflows entry must be string or dict, got {type(entry).__name__}"
            )

    return result, workflows_def, warnings
