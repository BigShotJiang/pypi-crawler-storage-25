"""Shared subprocess execution with timeout and output capture."""

import os
import re
import shlex
import subprocess
import sys
import threading
import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class CommandResult:
    """Result of a command execution."""
    returncode: int
    stdout: str
    stderr: str
    timed_out: bool = False

    def matches_pattern(self, pattern: str | list[str]) -> bool:
        if isinstance(pattern, list):
            return all(bool(re.search(p, self.stdout)) for p in pattern)
        return bool(re.search(pattern, self.stdout))

    def is_successful(self, success_pattern: str | list[str] | None = None) -> bool:
        if self.returncode != 0:
            return False
        if self.timed_out:
            return False
        if success_pattern is not None:
            return self.matches_pattern(success_pattern)
        return True


class CommandError(Exception):
    pass


def run_command(
    command: str,
    args: list[str] | None = None,
    working_dir: str = ".",
    env: dict[str, str] | None = None,
    timeout: float | None = None,
    stream: bool = False,
) -> CommandResult:
    full_cmd = command
    if args:
        full_cmd += " " + " ".join(shlex.quote(a) for a in args)

    logger.debug(f"Running command: {full_cmd} (dir={working_dir}, timeout={timeout}, stream={stream})")

    run_env = dict(os.environ)
    if env:
        run_env.update(env)

    task_log_path = run_env.get("FORGE_TASK_LOG")
    if stream:
        return _run_streaming(full_cmd, working_dir, run_env, timeout, task_log_path)
    else:
        return _run_buffered(full_cmd, working_dir, run_env, timeout)


def _run_buffered(full_cmd, working_dir, run_env, timeout):
    try:
        proc = subprocess.run(
            full_cmd, shell=True, cwd=working_dir,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            env=run_env, timeout=timeout,
        )
        stdout = proc.stdout.decode(errors="replace")
        stderr = proc.stderr.decode(errors="replace")
        logger.debug(f"Command completed: returncode={proc.returncode}, stdout_len={len(stdout)}, stderr_len={len(stderr)}")
        return CommandResult(returncode=proc.returncode, stdout=stdout, stderr=stderr)
    except subprocess.TimeoutExpired as e:
        stdout = ""
        stderr = ""
        if e.stdout is not None:
            stdout = e.stdout if isinstance(e.stdout, str) else e.stdout.decode(errors="replace")
        if e.stderr is not None:
            stderr = e.stderr if isinstance(e.stderr, str) else e.stderr.decode(errors="replace")
        logger.debug(f"Command timed out after {timeout}s")
        return CommandResult(returncode=-1, stdout=stdout, stderr=stderr, timed_out=True)


def _run_streaming(full_cmd, working_dir, run_env, timeout, task_log_path=None):
    """Run command with real-time output to screen, while capturing full output."""
    if task_log_path is None:
        task_log_path = run_env.get("FORGE_TASK_LOG")
    log_file = None
    if task_log_path:
        log_file = open(task_log_path, "a", buffering=1)  # line buffering
    try:
        proc = subprocess.Popen(
            full_cmd, shell=True, cwd=working_dir,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            env=run_env,
        )

        stdout_lines = []
        stderr_lines = []

        # Read stderr in a background thread to avoid deadlock
        def _read_stderr():
            for line in proc.stderr:
                text = line.decode(errors="replace")
                stderr_lines.append(text)
                print(text, end="", file=sys.stderr)
                if log_file:
                    log_file.write(f"[stderr] {text}")

        stderr_thread = threading.Thread(target=_read_stderr, daemon=True)
        stderr_thread.start()

        # Read stdout in main thread, print in real-time
        for line in proc.stdout:
            text = line.decode(errors="replace")
            stdout_lines.append(text)
            print(text, end="")
            if log_file:
                log_file.write(text)

        # Wait for process and stderr thread
        proc.wait(timeout=timeout)
        stderr_thread.join(timeout=5)

        logger.debug(f"Streaming command completed: returncode={proc.returncode}")
        return CommandResult(
            returncode=proc.returncode,
            stdout="".join(stdout_lines),
            stderr="".join(stderr_lines),
        )
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
        logger.debug(f"Streaming command timed out after {timeout}s")
        return CommandResult(
            returncode=-1,
            stdout="".join(stdout_lines),
            stderr="".join(stderr_lines),
            timed_out=True,
        )
    finally:
        if log_file:
            log_file.close()
