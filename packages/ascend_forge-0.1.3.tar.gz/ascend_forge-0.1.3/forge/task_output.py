"""Task output reading utilities for forge task show."""

import time
import threading
from pathlib import Path


def read_log_tail(log_path: str, lines: int = 100) -> str:
    """Read the last N lines from a log file.

    Returns empty string if file doesn't exist yet.
    """
    path = Path(log_path)
    if not path.exists():
        return ""

    with open(path, "r") as f:
        # Read all lines and return last N
        all_lines = f.readlines()
        tail_lines = all_lines[-lines:] if all_lines else []
        return "".join(tail_lines)


def follow_log(log_path: str, consumer: callable, stop_event: threading.Event, poll_interval: float = 0.1) -> None:
    """Follow a log file, calling consumer for each new line.

    Polls the file every poll_interval seconds.
    Stops when stop_event is set.
    """
    path = Path(log_path)
    if not path.exists():
        # Wait for file to be created
        while not stop_event.is_set():
            if path.exists():
                break
            time.sleep(poll_interval)

    last_size = 0
    if path.exists():
        last_size = path.stat().st_size

    while not stop_event.is_set():
        if not path.exists():
            # File gone, exit
            break
        try:
            current_size = path.stat().st_size
            if current_size > last_size:
                with open(path, "r") as f:
                    f.seek(last_size)
                    new_content = f.read()
                    f.seek(0)
                    # Find where last line ended to avoid partial lines
                    last_newline = new_content.rfind("\n")
                    if last_newline >= 0:
                        new_content = new_content[:last_newline + 1]
                    elif new_content:
                        # No newline at end yet, consume what we have
                        pass
                    if new_content:
                        consumer(new_content)
                last_size = current_size
        except (OSError, IOError):
            break
        time.sleep(poll_interval)