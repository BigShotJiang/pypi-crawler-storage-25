from __future__ import annotations

import logging
import sys
from typing import Any

import structlog

from fastapi_logkit.config import AccessLogOptions, LogKitConfig
from fastapi_logkit.env_util import is_json_logging_environment, resolve_env_name
from fastapi_logkit.processors import add_env_context, add_pino_log_level, strip_event_key

_active_logkit_config: LogKitConfig | None = None

__all__ = [
    "clear_active_logkit_config",
    "configure_logging",
    "get_access_logger",
    "get_active_logkit_config",
    "get_error_logger",
    "resolve_env_name",
    "setup_logging",
]


def get_active_logkit_config() -> LogKitConfig | None:
    """Return the :class:`~fastapi_logkit.config.LogKitConfig` from the last successful
    :func:`setup_logging` / :func:`configure_logging` call, or ``None`` if neither has run.
    """
    return _active_logkit_config


def clear_active_logkit_config() -> None:
    """Clear the stored active config (e.g. between isolated test cases)."""
    global _active_logkit_config
    _active_logkit_config = None


def silence_uvicorn_stderr_enabled(
    *,
    env: str | None = None,
    silence_uvicorn: bool | None = None,
) -> bool:
    if silence_uvicorn is not None:
        return silence_uvicorn
    return is_json_logging_environment(env)


def get_uvicorn_null_log_config() -> dict[str, Any]:
    from fastapi_logkit.integrations.uvicorn import get_uvicorn_null_log_config as _null

    return _null()


def get_uvicorn_log_config_for_run(
    *,
    env: str | None = None,
    silence_uvicorn: bool | None = None,
    config: LogKitConfig | None = None,
) -> dict[str, Any]:
    from fastapi_logkit.integrations.uvicorn import get_uvicorn_log_config_for_run as _cfg

    return _cfg(env=env, silence_uvicorn=silence_uvicorn, config=config)


def _disable_uvicorn_stdlib_loggers(*, env: str | None = None) -> None:
    if not silence_uvicorn_stderr_enabled(env=env):
        return
    for name in (
        "uvicorn",
        "uvicorn.error",
        "uvicorn.access",
        "uvicorn.asgi",
    ):
        log = logging.getLogger(name)
        log.handlers.clear()
        log.propagate = False
        log.disabled = True


def _configure_dev_app_error_logger() -> None:
    log = logging.getLogger("app.error")
    log.handlers.clear()
    log.setLevel(logging.DEBUG)
    log.propagate = False
    h = logging.StreamHandler(sys.stderr)
    h.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s [app.error] %(message)s")
    )
    log.addHandler(h)


def setup_logging(
    *,
    env: str | None = None,
    level: str = "INFO",
    json_logs: bool | None = None,
    silence_uvicorn: bool | None = None,
    access_log_options: AccessLogOptions | None = None,
) -> LogKitConfig:
    """Bootstrap application logging (JSON vs dev console wiring).

    ``env`` and ``level`` are plain strings (**any value is accepted**); only the
    rules below apply inside this package.

    Args:
        env: Arbitrary deployment / runtime environment name string.

            - If ``None``, :func:`~fastapi_logkit.env_util.resolve_env_name`
              resolves to ``development``. Otherwise leading/trailing
              whitespace is stripped and the value is stored as-is.
            - Matching is **case-insensitive** (normalized to lowercase internally).
              If the name is ``production``, ``prod``, or ``staging``, the default
              for ``json_logs`` becomes ``True`` (structlog JSON, Uvicorn stdlib
              loggers suppressed, etc.); otherwise the default ``json_logs`` is
              ``False``.

              ``install_logkit`` enables the access middleware **by default**
              only for ``production`` / ``prod`` (not ``staging``); see
              :func:`~fastapi_logkit.env_util.is_production_environment`.

            Custom labels (e.g. ``sandbox``) are allowed; override with explicit
            ``json_logs=`` when needed.

        level: Minimum structlog binder level name as a string (used only in JSON
            mode).

            - Standard library :mod:`logging` level **names**: ``DEBUG``,
              ``INFO``, ``WARNING``, ``ERROR``, ``CRITICAL``, ``NOTSET``.
            - Normalized to uppercase before lookup (``info`` → ``INFO``).
            - If :mod:`logging` has no such attribute, ``INFO`` is used.

            In dev mode (``json_logs=False``) this value is not applied to
            structlog.

        json_logs: If ``None``, derived from ``env``. May be forced to
            ``True``/``False``.
        silence_uvicorn: If ``None``, defaults to the same rule as ``json_logs``.
        access_log_options: :class:`~fastapi_logkit.config.AccessLogOptions` or
            ``None``.
    """
    env_resolved = resolve_env_name(env)
    level = level.upper()
    if json_logs is None:
        json_logs = is_json_logging_environment(env_resolved)
    if silence_uvicorn is None:
        silence_uvicorn = json_logs

    cfg = LogKitConfig(
        env=env_resolved,
        level=level,
        json_logs=json_logs,
        silence_uvicorn=silence_uvicorn,
        access_log=access_log_options or AccessLogOptions(),
    )
    global _active_logkit_config
    _active_logkit_config = cfg

    if not json_logs:
        _configure_dev_app_error_logger()
        return cfg

    min_level = getattr(logging, level, logging.INFO)

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            add_env_context(env_resolved),
            add_pino_log_level,
            strip_event_key,
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(min_level),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(file=sys.stdout),
        cache_logger_on_first_use=True,
    )

    _disable_uvicorn_stdlib_loggers(env=env_resolved)
    return cfg


def configure_logging(
    *,
    env: str | None = None,
    level: str = "INFO",
    json_logs: bool | None = None,
    silence_uvicorn: bool | None = None,
    access_log_options: AccessLogOptions | None = None,
) -> LogKitConfig:
    """Alias for :func:`setup_logging`. Reads no OS environment variables.

    Argument semantics match :func:`setup_logging`.
    """
    return setup_logging(
        env=env,
        level=level,
        json_logs=json_logs,
        silence_uvicorn=silence_uvicorn,
        access_log_options=access_log_options,
    )


def get_access_logger():
    return structlog.get_logger("access")


def get_error_logger():
    return structlog.get_logger("app.error")
