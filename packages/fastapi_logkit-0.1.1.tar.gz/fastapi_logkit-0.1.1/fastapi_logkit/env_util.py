from __future__ import annotations


def resolve_env_name(env: str | None = None) -> str:
    """Deploy environment label; default ``development`` if ``env`` is omitted (no OS env lookup)."""
    if env is not None:
        return env.strip()
    return "development"


def is_json_logging_environment(env: str | None = None) -> bool:
    key = resolve_env_name(env).strip().lower()
    return key in ("production", "prod", "staging")


def is_production_environment(env: str | None = None) -> bool:
    """Return True only for ``production`` / ``prod`` (used for access middleware defaults; excludes ``staging``)."""
    key = resolve_env_name(env).strip().lower()
    return key in ("production", "prod")
