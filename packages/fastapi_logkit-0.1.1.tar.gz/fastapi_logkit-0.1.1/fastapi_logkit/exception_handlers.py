from __future__ import annotations

import logging
import traceback

from fastapi import Request
from fastapi.exception_handlers import http_exception_handler
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.responses import Response

from fastapi_logkit.bootstrap import get_error_logger
from fastapi_logkit.logkit_scope import ACCESS_MIDDLEWARE_ACTIVE_SCOPE_KEY


async def unhandled_exception_handler(
    request: Request, exc: Exception
) -> Response:
    if isinstance(exc, StarletteHTTPException):
        return await http_exception_handler(request, exc)

    if getattr(request.app.state, "fastapi_logkit_json_logs", False):
        # If AccessLogMiddleware is on, traceback is already stored from try/except;
        # this handler runs later via ServerErrorMiddleware, so logging again would duplicate lines.
        if not request.scope.get(ACCESS_MIDDLEWARE_ACTIVE_SCOPE_KEY):
            get_error_logger().error(
                "unhandled_exception",
                traceBack=traceback.format_exc(),
                endPoint=str(request.url.path),
                method=request.method,
                statusCode=500,
            )
    else:
        logging.getLogger("app.error").exception(
            "unhandled_exception endPoint=%s method=%s",
            str(request.url.path),
            request.method,
        )
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error"},
    )
