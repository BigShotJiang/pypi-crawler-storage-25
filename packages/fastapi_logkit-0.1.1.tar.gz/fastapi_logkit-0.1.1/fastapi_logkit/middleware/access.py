"""Per-request HTTP access logging (structlog, ASGI)."""

from __future__ import annotations

import json
import logging
import time
import traceback
from typing import Any

from fastapi_logkit.bootstrap import get_access_logger
from fastapi_logkit.config import AccessLogOptions
from fastapi_logkit.logkit_scope import (
    ACCESS_MIDDLEWARE_ACTIVE_SCOPE_KEY,
    TRACEBACK_SCOPE_KEY,
)


def _scope_str(value: object) -> str:
    if isinstance(value, bytes):
        return value.decode("latin-1")
    return str(value)


_SENSITIVE_KEYS = frozenset(
    k.lower()
    for k in (
        "password",
        "token",
        "authorization",
        "access_token",
        "refresh_token",
        "secret",
        "api_key",
        "apikey",
    )
)


def _headers_map(scope: dict) -> dict[str, str]:
    out: dict[str, str] = {}
    for key, value in scope.get("headers") or []:
        k = _scope_str(key).lower()
        if k not in out:
            out[k] = _scope_str(value)
    return out


def _client_ip(scope: dict) -> str:
    client = scope.get("client")
    if client and len(client) >= 1:
        return client[0]
    return ""


def _origin_ip(scope: dict, headers: dict[str, str], options: AccessLogOptions) -> str:
    if not options.trust_proxy_headers:
        return _client_ip(scope)
    xff = headers.get("x-forwarded-for")
    if xff:
        return xff.split(",")[0].strip()
    xri = headers.get("x-real-ip")
    if xri:
        return xri.strip()
    return _client_ip(scope)


def _endpoint_template(scope: dict) -> str:
    route = scope.get("route")
    path = getattr(route, "path", None) if route is not None else None
    if path is not None and path != "" and path != b"":
        return _scope_str(path)
    raw = scope.get("path")
    if raw is None or raw == "" or raw == b"":
        return ""
    return _scope_str(raw)


def _mask_sensitive(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {
            str(k): ("***" if str(k).lower() in _SENSITIVE_KEYS else _mask_sensitive(v))
            for k, v in obj.items()
        }
    if isinstance(obj, list):
        return [_mask_sensitive(x) for x in obj]
    return obj


def _parse_body_for_log(raw: bytes, truncated: bool) -> Any:
    if truncated:
        try:
            text = raw.decode("utf-8", errors="replace")
            return text + "…<truncated>"
        except Exception:
            return "<truncated>"
    if not raw:
        return {}
    try:
        parsed = json.loads(raw.decode("utf-8"))
        if isinstance(parsed, (dict, list)):
            return _mask_sensitive(parsed)
        return parsed
    except (json.JSONDecodeError, UnicodeDecodeError):
        return raw.decode("utf-8", errors="replace")


def _access_line_level(status_code: int) -> int:
    if 200 <= status_code < 400:
        return logging.INFO
    if 400 <= status_code < 500:
        return logging.WARNING
    return logging.ERROR


def _should_emit_access_line(status_code: int, options: AccessLogOptions) -> bool:
    threshold = (
        options.access_min_level
        if options.access_min_level is not None
        else logging.INFO
    )
    return _access_line_level(status_code) >= threshold


class AccessLogMiddleware:
    """ASGI: emit one structured access line after the response."""

    def __init__(self, app, options: AccessLogOptions | None = None):
        self.app = app
        self.options = options or AccessLogOptions()

    async def __call__(self, scope: dict, receive, send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        scope[ACCESS_MIDDLEWARE_ACTIVE_SCOPE_KEY] = True

        opts = self.options
        log_body = opts.log_body
        max_body = opts.max_body

        captured = bytearray()
        body_truncated = False

        async def receive_wrapper():
            nonlocal body_truncated
            message = await receive()
            if not log_body:
                return message
            if message["type"] != "http.request":
                return message
            chunk = message.get("body", b"")
            if not body_truncated:
                remaining = max_body - len(captured)
                if remaining > 0:
                    captured.extend(memoryview(chunk)[:remaining])
                if len(chunk) > remaining:
                    body_truncated = True
            return message

        status_holder: dict[str, int | None] = {"code": None}

        async def send_wrapper(message):
            if (
                message["type"] == "http.response.start"
                and status_holder["code"] is None
            ):
                status_holder["code"] = message["status"]
            await send(message)

        recv = receive_wrapper if log_body else receive
        try:
            await self.app(scope, recv, send_wrapper)
        except Exception:
            # Exception handler runs in ServerErrorMiddleware after this finally;
            # capture traceback here in the middleware except path.
            if TRACEBACK_SCOPE_KEY not in scope:
                scope[TRACEBACK_SCOPE_KEY] = traceback.format_exc()
            raise
        finally:
            status_code = status_holder["code"]
            if status_code is None:
                status_code = 500

            if _should_emit_access_line(int(status_code), opts):
                headers = _headers_map(scope)
                method = _scope_str(scope["method"])
                path_params = dict(scope.get("path_params") or {})

                raw_tb = scope.pop(TRACEBACK_SCOPE_KEY, None)
                exc_tb: str | None = None
                if isinstance(raw_tb, str) and raw_tb.strip():
                    exc_tb = raw_tb

                payload: dict[str, Any] = {
                    "statusCode": int(status_code),
                    "userAgent": headers.get("user-agent", ""),
                    "clientIP": _client_ip(scope),
                    "originIP": _origin_ip(scope, headers, opts),
                    "dateTime": int(time.time() * 1000),
                    "endPoint": _endpoint_template(scope),
                    "pathParams": path_params,
                    "method": method,
                    "traceBack": exc_tb,
                }

                if 400 <= int(status_code) < 600 and log_body:
                    payload["requestBody"] = _parse_body_for_log(
                        bytes(captured), body_truncated
                    )

                logger = get_access_logger()
                code = int(status_code)
                if code >= 500:
                    logger.error("http_access", **payload)
                elif code >= 400:
                    logger.warning("http_access", **payload)
                else:
                    logger.info("http_access", **payload)
