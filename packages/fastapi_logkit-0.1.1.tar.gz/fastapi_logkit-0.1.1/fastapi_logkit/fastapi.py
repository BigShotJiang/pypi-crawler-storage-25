from __future__ import annotations

import logging
from dataclasses import replace
from typing import TYPE_CHECKING

from fastapi_logkit.config import AccessLogOptions, LogKitConfig
from fastapi_logkit.exception_handlers import unhandled_exception_handler
from fastapi_logkit.middleware.access import AccessLogMiddleware
from fastapi_logkit.middleware.request_context import RequestContextMiddleware

if TYPE_CHECKING:
    from fastapi import FastAPI


def install_logkit(
    app: FastAPI,
    *,
    config: LogKitConfig | None = None,
    request_context: bool = True,
    access_log: bool | None = None,
    exception_handler: bool = True,
    access_log_options: AccessLogOptions | None = None,
) -> None:
    """Register middleware and the global exception handler.

    Incoming request middleware order (after CORS etc.): RequestContext →
    AccessLog → app (Starlette: the last ``add_middleware`` runs first).

    Therefore AccessLog is registered first and RequestContext second so that
    context is bound before access logs are emitted.

    Pass ``config`` from ``setup_logging`` so the exception handler picks the same
    JSON vs console behaviour as logging.
    """
    from fastapi_logkit.env_util import is_production_environment

    env_name = config.env if config is not None else "development"
    app.state.fastapi_logkit_json_logs = bool(config.json_logs) if config else False

    if access_log is None:
        access_log = is_production_environment(env_name)

    raw_opts = access_log_options or (config.access_log if config else None) or AccessLogOptions()
    if raw_opts.access_min_level is None:
        level_name = config.level.upper() if config else "INFO"
        effective = getattr(logging, level_name, logging.INFO)
        opts = replace(raw_opts, access_min_level=effective)
    else:
        opts = raw_opts

    if access_log:
        app.add_middleware(AccessLogMiddleware, options=opts)
    if request_context:
        app.add_middleware(RequestContextMiddleware)
    if exception_handler:
        app.add_exception_handler(Exception, unhandled_exception_handler)
