from __future__ import annotations

import logging

_PINO_LEVEL_BY_NAME: dict[str, int] = {
    "notset": 0,
    "trace": 10,
    "debug": 20,
    "info": 30,
    "warn": 40,
    "warning": 40,
    "error": 50,
    "critical": 60,
}


def add_pino_log_level(
    _logger: logging.Logger, _method_name: str, event_dict: dict
) -> dict:
    raw = event_dict.pop("level", "info")
    if isinstance(raw, int):
        name = logging.getLevelName(raw)
        if isinstance(name, str):
            key = name.lower()
        else:
            key = "info"
    else:
        key = str(raw).lower()
    event_dict["logLevel"] = _PINO_LEVEL_BY_NAME.get(key, 30)
    return event_dict


def strip_event_key(
    _logger: logging.Logger, _method_name: str, event_dict: dict
) -> dict:
    event_dict.pop("event", None)
    return event_dict


def add_env_context(env: str):
    def processor(_logger: logging.Logger, _method_name: str, event_dict: dict) -> dict:
        event_dict["env"] = env
        return event_dict

    return processor
