"""Scope keys shared between middleware and handlers (avoid duplicate logs).

``Exception`` handlers are wired through Starlette's ``ServerErrorMiddleware`` and
run **after** ``AccessLogMiddleware``'s ``finally``. Tracebacks are therefore
stored on ``scope`` from the middleware ``except`` block.
"""

ACCESS_MIDDLEWARE_ACTIVE_SCOPE_KEY = "_fastapi_logkit_access_mw_active"
TRACEBACK_SCOPE_KEY = "_fastapi_logkit_exc_tb"
