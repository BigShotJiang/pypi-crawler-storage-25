"""Gunicorn logger names and stub for future helpers."""

EXTERNAL_LOGGER_NAMES = [
    "gunicorn",
    "gunicorn.error",
    "gunicorn.access",
]
