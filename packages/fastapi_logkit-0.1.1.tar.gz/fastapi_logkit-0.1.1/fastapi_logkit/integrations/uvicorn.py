from __future__ import annotations

from typing import TYPE_CHECKING, Any

from fastapi_logkit.bootstrap import get_active_logkit_config
from fastapi_logkit.env_util import is_json_logging_environment, resolve_env_name

if TYPE_CHECKING:
    from fastapi_logkit.config import LogKitConfig


def get_uvicorn_null_log_config() -> dict[str, Any]:
    """For Uvicorn ``Config.configure_logging(dict)`` — suppress server noise on stderr/stdout."""
    return {
        "version": 1,
        "disable_existing_loggers": False,
        "handlers": {
            "null": {
                "class": "logging.NullHandler",
            },
        },
        "loggers": {
            "uvicorn": {
                "handlers": ["null"],
                "level": "CRITICAL",
                "propagate": False,
            },
            "uvicorn.error": {
                "handlers": ["null"],
                "level": "CRITICAL",
                "propagate": False,
            },
            "uvicorn.access": {
                "handlers": ["null"],
                "level": "CRITICAL",
                "propagate": False,
            },
            "uvicorn.asgi": {
                "handlers": ["null"],
                "level": "CRITICAL",
                "propagate": False,
            },
        },
    }


def get_uvicorn_log_config_for_run(
    *,
    env: str | None = None,
    silence_uvicorn: bool | None = None,
    config: LogKitConfig | None = None,
) -> dict[str, Any]:
    """For ``uvicorn.run(..., log_config=...)`` — use Uvicorn defaults unless JSON-style silence is on.

    After :func:`~fastapi_logkit.bootstrap.setup_logging`, the last
    :class:`~fastapi_logkit.config.LogKitConfig` is stored; when ``config`` is
    omitted, that active config supplies ``silence_uvicorn`` (see
    :func:`~fastapi_logkit.bootstrap.get_active_logkit_config`). Pass
    ``config=`` to override for a one-off. Explicit ``silence_uvicorn=`` /
    ``env=`` still win when set.
    """
    if silence_uvicorn is None:
        if config is not None:
            silence_uvicorn = config.silence_uvicorn
        else:
            active = get_active_logkit_config()
            if active is not None:
                silence_uvicorn = active.silence_uvicorn
            else:
                resolved = resolve_env_name(env)
                silence_uvicorn = is_json_logging_environment(resolved)
    if silence_uvicorn:
        return get_uvicorn_null_log_config()
    from uvicorn.config import LOGGING_CONFIG

    return LOGGING_CONFIG
