from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class AccessLogOptions:
    """HTTP access middleware options (configure in code instead of env vars).

    ``access_min_level`` is the minimum stdlib :mod:`logging` level number for an
    access line to be emitted (2xx/3xx use ``INFO``, 4xx ``WARNING``, 5xx
    ``ERROR``). ``None`` means :func:`~fastapi_logkit.fastapi.install_logkit`
    seeds it from :class:`LogKitConfig` ``level``; if the middleware is used
    without ``install_logkit``, ``None`` behaves like ``logging.INFO``.
    """

    trust_proxy_headers: bool = False
    log_body: bool = True
    max_body: int = 65536
    access_min_level: int | None = None


@dataclass
class LogKitConfig:
    #: Resolved ``env`` string passed to :func:`~fastapi_logkit.bootstrap.setup_logging`.
    #: Values such as ``production`` / ``prod`` / ``staging`` drive JSON and middleware defaults.
    env: str
    #: Uppercase level name for structlog filtering in JSON mode, e.g. ``INFO``.
    #: Unknown names are treated as ``INFO`` at runtime.
    level: str
    json_logs: bool
    silence_uvicorn: bool
    access_log: AccessLogOptions = field(default_factory=AccessLogOptions)
