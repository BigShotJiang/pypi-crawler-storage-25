from __future__ import annotations

import json
import logging

import structlog

from fastapi_logkit import setup_logging


def test_setup_dev_configures_app_error_handler():
    setup_logging(env="development", json_logs=False)
    log = logging.getLogger("app.error")
    assert log.handlers
    log.handlers.clear()


def test_setup_prod_emits_json_with_log_level_and_env(capsys):
    setup_logging(env="production", json_logs=True, level="INFO")
    structlog.get_logger("test").info("hello_event", extra="f")
    captured = capsys.readouterr()
    line = json.loads(captured.out.strip().splitlines()[-1])
    assert line["logLevel"] == 30
    assert "service" not in line
    assert line["env"] == "production"
