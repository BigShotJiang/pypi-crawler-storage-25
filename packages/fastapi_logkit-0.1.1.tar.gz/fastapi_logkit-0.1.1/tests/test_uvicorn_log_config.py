from __future__ import annotations

from dataclasses import replace

from fastapi_logkit import setup_logging
from fastapi_logkit.bootstrap import (
    clear_active_logkit_config,
    get_active_logkit_config,
    get_uvicorn_log_config_for_run as from_bootstrap,
)
from fastapi_logkit.integrations.uvicorn import get_uvicorn_log_config_for_run


def test_uvicorn_log_config_uses_active_logkit_without_config_arg():
    setup_logging(env="production", json_logs=True, level="INFO")
    d = get_uvicorn_log_config_for_run()
    assert d["loggers"]["uvicorn"]["handlers"] == ["null"]
    assert d["loggers"]["uvicorn.access"]["handlers"] == ["null"]


def test_uvicorn_log_config_bootstrap_alias_matches():
    setup_logging(env="prod", json_logs=True, level="INFO")
    d = from_bootstrap()
    assert d["handlers"]["null"]["class"] == "logging.NullHandler"


def test_active_config_respects_silence_uvicorn_false():
    setup_logging(
        env="production", json_logs=True, silence_uvicorn=False, level="INFO"
    )
    d = get_uvicorn_log_config_for_run()
    assert d["loggers"]["uvicorn"]["handlers"] != ["null"]


def test_uvicorn_explicit_config_overrides_active():
    setup_logging(env="production", json_logs=True, level="INFO")
    base = get_active_logkit_config()
    assert base is not None
    alt = replace(base, silence_uvicorn=False)
    d = get_uvicorn_log_config_for_run(config=alt)
    assert d["loggers"]["uvicorn"]["handlers"] != ["null"]


def test_uvicorn_without_active_falls_back_to_env():
    clear_active_logkit_config()
    d = get_uvicorn_log_config_for_run(env="development")
    assert d["loggers"]["uvicorn"]["handlers"] != ["null"]
