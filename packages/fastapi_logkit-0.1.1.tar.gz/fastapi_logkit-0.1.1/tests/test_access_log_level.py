from __future__ import annotations

import json
import logging

from fastapi import FastAPI
from fastapi.testclient import TestClient

from fastapi_logkit import setup_logging
from fastapi_logkit.config import AccessLogOptions
from fastapi_logkit.fastapi import install_logkit


def test_access_log_suppresses_2xx_when_level_warning(capsys):
    cfg = setup_logging(env="production", json_logs=True, level="WARNING")
    app = FastAPI()
    install_logkit(app, config=cfg, request_context=False, access_log=True)

    @app.get("/ok")
    def ok():
        return {"a": 1}

    client = TestClient(app)
    assert client.get("/ok").status_code == 200
    assert capsys.readouterr().out.strip() == ""


def test_access_log_emits_2xx_when_level_info(capsys):
    cfg = setup_logging(env="production", json_logs=True, level="INFO")
    app = FastAPI()
    install_logkit(app, config=cfg, request_context=False, access_log=True)

    @app.get("/ok")
    def ok():
        return {"a": 1}

    client = TestClient(app)
    assert client.get("/ok").status_code == 200
    line = json.loads(capsys.readouterr().out.strip().splitlines()[-1])
    assert line["statusCode"] == 200
    assert line["endPoint"] == "/ok"


def test_access_log_emits_404_when_level_warning(capsys):
    cfg = setup_logging(env="production", json_logs=True, level="WARNING")
    app = FastAPI()
    install_logkit(app, config=cfg, request_context=False, access_log=True)

    @app.get("/missing")
    def missing():
        from fastapi import HTTPException

        raise HTTPException(status_code=404, detail="nope")

    client = TestClient(app, raise_server_exceptions=False)
    assert client.get("/missing").status_code == 404
    line = json.loads(capsys.readouterr().out.strip().splitlines()[-1])
    assert line["statusCode"] == 404


def test_access_min_level_override_independent_of_setup_level(capsys):
    cfg = setup_logging(env="production", json_logs=True, level="INFO")
    app = FastAPI()
    install_logkit(
        app,
        config=cfg,
        request_context=False,
        access_log=True,
        access_log_options=AccessLogOptions(access_min_level=logging.WARNING),
    )

    @app.get("/ok")
    def ok():
        return {"a": 1}

    client = TestClient(app)
    assert client.get("/ok").status_code == 200
    assert capsys.readouterr().out.strip() == ""
