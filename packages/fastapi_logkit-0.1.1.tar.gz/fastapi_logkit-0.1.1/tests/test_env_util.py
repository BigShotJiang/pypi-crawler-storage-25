from fastapi_logkit.env_util import (
    is_json_logging_environment,
    is_production_environment,
    resolve_env_name,
)


def test_resolve_env_name_explicit():
    assert resolve_env_name("  production  ") == "production"


def test_resolve_env_name_omitted_defaults_to_development():
    assert resolve_env_name(None) == "development"


def test_is_json_logging_environment():
    assert is_json_logging_environment("production") is True
    assert is_json_logging_environment("staging") is True
    assert is_json_logging_environment("development") is False


def test_is_production_environment():
    assert is_production_environment("production") is True
    assert is_production_environment("staging") is False
