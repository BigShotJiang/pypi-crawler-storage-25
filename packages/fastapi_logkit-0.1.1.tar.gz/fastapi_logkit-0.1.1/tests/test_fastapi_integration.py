from __future__ import annotations

import json

from fastapi import FastAPI
from fastapi.testclient import TestClient

from fastapi_logkit import setup_logging
from fastapi_logkit.fastapi import install_logkit


def test_install_logkit_registers_exception_handler_and_http_exception_passthrough(
    capsys,
):
    cfg = setup_logging(env="production", json_logs=True, level="INFO")

    app = FastAPI()
    install_logkit(app, config=cfg, request_context=False, access_log=False)

    @app.get("/boom")
    def boom():
        raise ValueError("nope")

    @app.get("/http")
    def http():
        from fastapi import HTTPException

        raise HTTPException(status_code=418, detail="teapot")

    client = TestClient(app, raise_server_exceptions=False)
    assert client.get("/http").status_code == 418
    res = client.get("/boom")
    assert res.status_code == 500
    out = capsys.readouterr().out
    line = json.loads(out.strip().splitlines()[-1])
    assert line.get("endPoint") == "/boom"
    assert line.get("traceBack") is not None
    assert "ValueError" in line.get("traceBack", "")


def test_access_log_and_exception_handler_no_duplicate_lines_on_500(capsys):
    cfg = setup_logging(env="production", json_logs=True, level="INFO")

    app = FastAPI()
    install_logkit(app, config=cfg, request_context=False, access_log=True)

    @app.get("/boom")
    def boom():
        raise ValueError("x")

    client = TestClient(app, raise_server_exceptions=False)
    assert client.get("/boom").status_code == 500
    events = []
    for raw in capsys.readouterr().out.strip().splitlines():
        if not raw.strip():
            continue
        events.append(json.loads(raw))
    boom_events = [
        ev
        for ev in events
        if "/boom" in str(ev.get("endPoint") or "") or "/boom" in str(ev.get("path") or "")
    ]
    assert len(boom_events) == 1
    ev = boom_events[0]
    assert ev["statusCode"] == 500
    assert ev["traceBack"] is not None
    assert "ValueError" in ev["traceBack"]


def test_install_logkit_middleware_stack():
    app = FastAPI()
    install_logkit(app, request_context=True, access_log=False)
    assert len(app.user_middleware) == 1  # RequestContext only
