# PyPI 지속 관리 가이드

`fastapi-logkit` 패키지를 [PyPI](https://pypi.org/project/fastapi-logkit/)에 올린 뒤 버전을 올리며 유지할 때 따라가면 되는 절차입니다.

## 전제 조건

- **PyPI 계정**이 있어야 하고, 이 프로젝트에 업로드 권한이 있어야 합니다.
- **API 토큰**(Account settings → API tokens)을 발급해 두세요. 업로드 시 비밀번호 대신 사용합니다.

## 새 버전 배포 체크리스트

아래 순서를 한 번에 통과하면 배포로 간주하면 됩니다.

1. **`main`(또는 릴리스 브랜치) 상태 확인**  
   - 릴리스에 포함되지 않을 변경이 섞였는지 확인합니다.

2. **테스트**  
   ```bash
   python -m venv .venv
   source .venv/bin/activate   # Windows: .venv\Scripts\activate
   pip install -e ".[dev]"
   pytest
   ```

3. **`pyproject.toml`에서 버전 올리기**  
   - `[project]`의 `version`만 수정하면 됩니다.  
   - **같은 버전 번호로 PyPI에 다시 올릴 수 없습니다.** 재배포가 필요하면 버전을 반드시 증가시킵니다.

4. **`README.md` 등 메타 확인**  
   - 설명·설치 방법·링크가 현재 코드와 맞는지 봅니다.

5. **빌드**  
   ```bash
   pip install build
   python -m build
   ```
   - `dist/`에 `.tar.gz`(sdist)와 `.whl`이 생성됩니다.  
   - 이 디렉터리는 저장소에서 보통 무시합니다(`.gitignore`에 `dist/` 포함).

6. **실제 패키지로 한 번 더 설치 검증**(선택이지만 권장)  
   ```bash
   pip install dist/fastapi_logkit-*-py3-none-any.whl
   ```
   또는 가상환경을 새로 만든 뒤 wheel만 설치해 smoke test 합니다.

7. **PyPI 업로드**  
   ```bash
   pip install twine
   python -m twine upload dist/*
   ```
   - 사용자 이름: **`__token__`** (그대로 입력)  
   - 비밀번호: 발급한 **`pypi-...` 토큰 전체**  
   - 또는 다음처럼 환경 변수로 넘깁니다.  
     ```bash
     export TWINE_USERNAME=__token__
     export TWINE_PASSWORD=pypi-여기에_토큰
     python -m twine upload dist/*
     ```

8. **설치 확인**  
   ```bash
   pip install fastapi-logkit==<방금_올린_버전>
   ```

## 버전 번호 규칙(SemVer 요약)

- **`MAJOR.MINOR.PATCH`** (예: `0.1.0`)
  - **PATCH**: 버그 수정, 동작 변경 없음에 가까운 수정.
  - **MINOR**: 하위 호환을 유지하는 기능 추가.
  - **MAJOR**: 호환을 깨는 변경.

처음에는 `0.x`로 두고, 공개 API를 안정화한 뒤 `1.0.0`을 올리는 방식이 흔합니다.

## 연습용: TestPyPI

[test.pypi.org](https://test.pypi.org)에 별도 계정을 두고 같은 절차로 올려 볼 수 있습니다.

```bash
python -m twine upload --repository testpypi dist/*
```

설치 테스트:

```bash
pip install -i https://test.pypi.org/simple/ fastapi-logkit==<버전>
```

TestPyPI에만 있는 버전이라면 실제 의존성 패키지는 기본 인덱스와 함께 지정해야 할 수 있습니다. 연습 목적이라면 최소 검증 위주로 쓰면 됩니다.

## 운영 시 주의

- **토큰은 저장소나 채팅에 넣지 말 것.** CI를 쓰면 GitHub/GitLab 등 **Secrets**에만 두고 로그에 출력되지 않게 합니다.
- **실수로 비밀이 유출된 토큰은 즉시 PyPI에서 폐기**하고 새로 발급합니다.
- 배포 직후 `dist/`에서 실험 빌드를 쌓아 두었다면, 다음 릴리스 전에 **`rm -rf dist/*` 후 다시 `python -m build`** 하는 습관이 안전합니다(이전 버전 wheel이 같이 업로드되는 실수 방지).

## 선택 사항

- **Git 태그**: 배포 버전과 맞춰 `v0.2.0` 같은 태그를 붙이면 이력 추적에 좋습니다.
- **`CHANGELOG.md`**: 사용자에게 무엇이 바뀌었는지 요약하면 이슈와 지원 부담이 줄어듭니다.
- **자동 배포**: GitHub Actions 등에서 태그 push 시 `build` + `twine upload`를 돌리는 방식도 많이 쓰입니다. 도입 시 토큰은 반드시 Secret으로만 주입합니다.

## 관련 링크

- 패키지 페이지: [https://pypi.org/project/fastapi-logkit/](https://pypi.org/project/fastapi-logkit/)
- Python 패키징 사용자 가이드: [Packaging Python Projects](https://packaging.python.org/en/latest/tutorials/packaging-projects/)
