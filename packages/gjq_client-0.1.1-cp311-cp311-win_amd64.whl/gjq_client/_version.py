"""gjq-client 版本信息"""

__version__ = "0.1.1"
