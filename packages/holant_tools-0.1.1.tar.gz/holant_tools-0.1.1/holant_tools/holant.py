"""Holant evaluation layer for matchgate networks on genus-g surfaces.

v0.3 (alpha): symbolic Pfaffian + Arf-signed sum over spin structures.

This module complements v0.2's realizability layer (`srp_solve` on the basis
manifold M). v0.2 decides whether a common basis exists; this module
*evaluates* the Holant given the basis and the Kasteleyn-oriented matrices.

For planar (genus 0) matchgate networks, the Holant equals a single Pfaffian
(FKT 1961). For genus-g networks, the Galluccio-Loebl formula gives

    Holant(Omega) = (1 / 2^g) * sum_{theta in Spin(Sigma_g)} Arf(theta) Pf(M_theta)

with |Spin(Sigma_g)| = 2^{2g} and M_theta the Kasteleyn-oriented matrix
indexed by spin structure theta. v0.3-alpha takes the M_theta as input
(deferring automatic Kasteleyn-orientation construction to v0.3-beta) and
implements the evaluation:

    pfaffian(M)                  -- recursive symbolic Pfaffian via first-row expansion
    arf_invariant_genus_1(theta) -- Arf for the four spin structures on the torus
    holant_genus_g(matrices, g)  -- Galluccio-Loebl signed sum

See BOUNDED_GENUS.md for the full design + scope statement.
"""

from __future__ import annotations
from typing import Dict, List, Sequence, Tuple

from sympy import Matrix, Rational, S, Symbol, sympify


# ---------------------------------------------------------------------------
# Pfaffian (symbolic, recursive)
# ---------------------------------------------------------------------------

def pfaffian(M):
    """Pfaffian of a symbolic antisymmetric matrix.

    For a 2n x 2n antisymmetric matrix M, Pf(M) is defined by

        Pf(M)^2 = det(M)

    with a definite sign convention. We compute it via the recursive
    first-row expansion (Galbiati-Maffioli):

        Pf(M) = sum_{j=1}^{2n-1} (-1)^{j+1} M[0, j] * Pf(M with rows/cols 0, j removed)

    Indices here are 0-based. The matrix must have even dimension and be
    antisymmetric (we check the latter via `simplify` on M + M.T being zero).

    Args:
        M: a sympy Matrix.

    Returns:
        sympy expression for Pf(M).
    """
    if not isinstance(M, Matrix):
        M = Matrix(M)
    n = M.shape[0]
    if M.shape[1] != n:
        raise ValueError(f"matrix must be square, got shape {M.shape}")
    if n % 2 != 0:
        # Pfaffian of an odd-dimensional antisymmetric matrix is zero.
        return S.Zero
    if n == 0:
        return S.One
    if n == 2:
        return M[0, 1]

    # Recursive expansion along row 0.
    result = S.Zero
    for j in range(1, n):
        if M[0, j] == 0:
            continue
        # Remove rows/cols 0 and j.
        keep = [i for i in range(n) if i != 0 and i != j]
        minor = M[keep, keep]
        sign = (-1) ** (j + 1)
        result += sign * M[0, j] * pfaffian(minor)
    return result


# ---------------------------------------------------------------------------
# Spin structures on Sigma_g and their Arf invariants
# ---------------------------------------------------------------------------

# A spin structure is an element of (Z/2)^{2g}. We represent it as a tuple
# of 2g bits. For g = 1, this is (epsilon_1, epsilon_2) in {0, 1}^2.

SpinStructure = Tuple[int, ...]


def spin_structures_genus(g: int) -> List[SpinStructure]:
    """Enumerate the 2^{2g} spin structures on Sigma_g.

    Conventional ordering: lexicographic on tuples of 2g bits.
    """
    if g < 0:
        raise ValueError(f"genus must be >= 0, got {g}")
    if g == 0:
        return [()]  # single (trivial) spin structure on the sphere
    structures: List[SpinStructure] = []
    for mask in range(1 << (2 * g)):
        structures.append(tuple((mask >> i) & 1 for i in range(2 * g)))
    return structures


def arf_invariant(theta: SpinStructure) -> int:
    """Arf-invariant sign of a spin structure on Sigma_g.

    Convention. A spin structure theta = (epsilon_1, ..., epsilon_{2g}) is the
    coordinate vector of a quadratic form q_theta on H_1(Sigma_g; Z/2) with
    respect to a symplectic basis {a_1, b_1, ..., a_g, b_g}, where
    q_theta(a_i) = epsilon_{2i-1} and q_theta(b_i) = epsilon_{2i}.

    The Z/2-valued Arf invariant of q is

        Arf(q) = sum_{i=1}^g q(a_i) * q(b_i)  in Z/2.

    The sign returned here is

        sign(theta) = (-1)^{Arf(q_theta)}

    so for genus 1:

        sign((0, 0)) = +1   (Arf = 0)
        sign((0, 1)) = +1   (Arf = 0)
        sign((1, 0)) = +1   (Arf = 0)
        sign((1, 1)) = -1   (Arf = 1)

    For genus 0 the spin structure is trivial and the sign is +1.

    Note on labeling. The "which spin structure is the special one" depends
    on the choice of symplectic basis for H_1(Sigma_g; Z/2). The convention
    above places the negative sign on theta = (1, 1, ..., 1) and other
    Arf-odd structures. When supplying matrices to holant_genus_g, the
    caller must use the same labeling (i.e., the Kasteleyn orientation
    obtained by "twisting" along both homology cycles is M_{(1, 1)}, etc.).
    This matches Cimasoni-Reshetikhin 2007 / Norine 2008.
    """
    if len(theta) == 0:
        return 1  # genus 0
    if len(theta) % 2 != 0:
        raise ValueError(f"spin structure must have even length, got {len(theta)}")
    g = len(theta) // 2
    arf = sum(theta[2 * i] * theta[2 * i + 1] for i in range(g)) % 2
    return 1 if arf == 0 else -1


def arf_invariant_genus_1(theta: SpinStructure) -> int:
    """Arf sign specialised to genus 1.

    Three even structures (Arf = 0, sign +1) and one odd (Arf = 1, sign -1):

        sign((0, 0)) = +1
        sign((0, 1)) = +1
        sign((1, 0)) = +1
        sign((1, 1)) = -1
    """
    if len(theta) != 2:
        raise ValueError(f"genus-1 spin structure must have length 2, got {len(theta)}")
    return arf_invariant(theta)


# ---------------------------------------------------------------------------
# Galluccio-Loebl Holant evaluation
# ---------------------------------------------------------------------------

def holant_genus_g(matrices: Dict[SpinStructure, Matrix], genus: int):
    """Galluccio-Loebl signed sum of Pfaffians over spin structures.

        Holant = (1 / 2^g) * sum_theta Arf(theta) * Pf(M_theta)

    Args:
        matrices: dict mapping spin structure (tuple of 2g bits) to its
            Kasteleyn-oriented antisymmetric matrix M_theta. Must contain
            exactly the 2^{2g} expected spin structures.
        genus: genus g of the surface.

    Returns:
        sympy expression for the Holant.

    For genus 0, the input dict has one entry under key (); the result is
    just Pf(M_()) (the FKT planar Pfaffian).

    For genus 1, the input dict must have 4 entries; the result is
    (1/2) * (Arf-signed sum of the 4 Pfaffians).
    """
    expected = spin_structures_genus(genus)
    if set(matrices.keys()) != set(expected):
        raise ValueError(
            f"matrices dict keys {set(matrices.keys())} do not match the "
            f"expected spin structures {set(expected)} for genus {genus}"
        )

    total = S.Zero
    for theta in expected:
        a = arf_invariant(theta)
        total += a * pfaffian(matrices[theta])

    if genus == 0:
        return total  # division by 2^0 = 1 is a no-op
    return Rational(1, 2 ** genus) * total


def holant_planar(M):
    """Convenience: Holant for a planar (genus 0) matchgrid is just Pf(M)."""
    return pfaffian(M)
