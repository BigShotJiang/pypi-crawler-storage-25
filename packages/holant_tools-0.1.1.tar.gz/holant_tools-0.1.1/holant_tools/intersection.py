"""Intersection of realizability subvarieties on the basis manifold M.

This is the sufficient condition step of the Simultaneous Realizability Problem
(Cai-Lu 2011 Theorem 4.1). v0.1's necessary check (each signature individually
realizable) leaves open whether a common basis exists; this module decides it
by intersecting the per-signature subvarieties B(sigma_i) in M.

Algorithmic shape
-----------------

Each Subvariety has two parity branches; B(sigma_i) is the union. Across N
signatures the joint realizability locus is the union of 2^N branch combinations.
We enumerate the 2^N combinations, collect all equations per combination, and
solve in sympy. If any combination has a non-trivial solution (with u != v in
the chart of M), SRP is feasible.

Solving modes
-------------

* algebraic closure of Q (default): sympy.solve on the polynomial system.
  Returns complex / algebraic-number solutions.
* finite field F_p (modulus argument): brute-force enumeration over F_p^2.
  Needed for problems like Cai-Lu #_7 Pl-Rtw-Mon-3CNF where the realizability
  condition forces a finite-field setting (cube roots of unity in F_7, etc.).

For symmetric signatures this is polynomial-time in input size (Cai-Lu Theorem
4.1). The brute-force F_p mode is O(p^2 * total-equations), fine for small p.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from itertools import product
from typing import List, Optional, Sequence, Tuple

from sympy import Symbol, sympify, Rational, fraction, together, solve, simplify, zoo, oo, nan, S

from .realizability import Subvariety, U, V


@dataclass
class IntersectionResult:
    """Outcome of an SRP intersection computation."""

    feasible: bool
    witness: Optional[dict] = None  # {U: value, V: value} if feasible
    branch_combination: Optional[Tuple[str, ...]] = None  # parity per signature
    all_solutions: List[dict] = field(default_factory=list)
    notes: str = ""

    def __repr__(self) -> str:
        if not self.feasible:
            return f"IntersectionResult(infeasible: {self.notes})"
        w = self.witness or {}
        u_val = w.get(U)
        v_val = w.get(V)
        bc = ", ".join(self.branch_combination) if self.branch_combination else ""
        return (
            f"IntersectionResult(feasible, witness=(u={u_val}, v={v_val}), "
            f"branches=[{bc}])"
        )


def _evaluate_mod_p(expr, u_val: int, v_val: int, p: int) -> Optional[int]:
    """Evaluate a sympy polynomial in U, V at (u_val, v_val) mod p.

    Returns the residue in {0, ..., p-1}, or None if the denominator (after
    substitution) is not invertible mod p (we treat that as "undefined" and
    skip the candidate).
    """
    val = sympify(expr).subs({U: u_val, V: v_val})
    val = together(val)
    num, den = fraction(val)
    try:
        num_i = int(num)
        den_i = int(den)
    except TypeError:
        return None
    if den_i % p == 0:
        return None
    # In F_p: num * den^{-1}.
    try:
        den_inv = pow(den_i % p, -1, p)
    except ValueError:
        return None
    return (num_i * den_inv) % p


def _solve_mod_p(equations: Sequence, p: int) -> List[dict]:
    """Brute-force enumeration of solutions to equations over F_p^2.

    Includes the u != v constraint (chart of M requires invertible basis).
    """
    # Drop equations that are identically zero (trivially satisfied).
    equations = [eq for eq in equations if sympify(eq) != 0]
    solutions = []
    for u_val in range(p):
        for v_val in range(p):
            if u_val == v_val:
                continue
            ok = True
            for eq in equations:
                r = _evaluate_mod_p(eq, u_val, v_val, p)
                if r is None or r != 0:
                    ok = False
                    break
            if ok:
                solutions.append({U: u_val, V: v_val})
    return solutions


def _solve_complex(equations: Sequence) -> List[dict]:
    """Solve a polynomial system in U, V over the algebraic closure of Q.

    Filters out solutions with U == V (excluded by the M chart). When the
    solver leaves a variable free (under-determined system), substitute
    concrete values from a small candidate list until a valid witness emerges.
    """
    # Drop equations that are identically zero (trivially satisfied).
    equations = [eq for eq in equations if sympify(eq) != 0]
    if not equations:
        return [{U: sympify(0), V: sympify(1)}]
    try:
        raw = solve(list(equations), [U, V], dict=True)
    except (NotImplementedError, Exception):
        return []

    candidates = [sympify(c) for c in (0, 1, -1, 2, sympify(1) / 2)]
    out: List[dict] = []
    for sol in raw:
        if U in sol and V in sol:
            if simplify(sympify(sol[U]) - sympify(sol[V])) == 0:
                continue
            out.append({U: sol[U], V: sol[V]})
        elif U in sol:
            expr_u = sympify(sol[U])
            for v_val in candidates:
                u_val = expr_u.subs(V, v_val)
                if u_val in (zoo, oo, -oo, nan, S.ComplexInfinity):
                    continue
                try:
                    if simplify(u_val - v_val) != 0:
                        out.append({U: u_val, V: v_val})
                        break
                except Exception:
                    continue
        elif V in sol:
            expr_v = sympify(sol[V])
            for u_val in candidates:
                v_val = expr_v.subs(U, u_val)
                if v_val in (zoo, oo, -oo, nan, S.ComplexInfinity):
                    continue
                try:
                    if simplify(u_val - v_val) != 0:
                        out.append({U: u_val, V: v_val})
                        break
                except Exception:
                    continue
        else:
            # Both free.
            out.append({U: sympify(0), V: sympify(1)})
    return out


def intersect_subvarieties(
    subvarieties: Sequence[Subvariety],
    modulus: Optional[int] = None,
) -> IntersectionResult:
    """Decide SRP feasibility by intersecting per-signature subvarieties on M.

    Args:
        subvarieties: per-signature Subvariety objects (from realizability_subvariety).
        modulus: if given, solve in F_p; otherwise over the algebraic closure of Q.

    Returns:
        IntersectionResult with feasibility status, a witness basis if feasible,
        and a note describing the branch combination that worked.

    Algorithm:
        For each combination of parity branches across signatures, gather all
        equations and solve. Return the first feasible combination.
    """
    if not subvarieties:
        return IntersectionResult(
            feasible=True,
            witness={U: sympify(0), V: sympify(1)},
            branch_combination=(),
            notes="no signatures: vacuous SRP",
        )

    # For each subvariety, list its non-trivial branches. A trivial subvariety
    # (entire M) contributes one degenerate branch with no equations.
    branch_lists: List[List[Tuple[str, list]]] = []
    for sv in subvarieties:
        if sv.is_trivial:
            branch_lists.append([("trivial", [])])
        else:
            branch_lists.append(sv.branches())

    field_desc = f"F_{modulus}" if modulus is not None else "algebraic closure of Q"
    tried = 0
    for combo in product(*[range(len(bl)) for bl in branch_lists]):
        tried += 1
        labels: List[str] = []
        all_eqs: List = []
        for i, branch_idx in enumerate(combo):
            label, eqs = branch_lists[i][branch_idx]
            labels.append(label)
            all_eqs.extend(eqs)

        if modulus is not None:
            solutions = _solve_mod_p(all_eqs, modulus)
        else:
            solutions = _solve_complex(all_eqs)

        if solutions:
            return IntersectionResult(
                feasible=True,
                witness=solutions[0],
                branch_combination=tuple(labels),
                all_solutions=solutions,
                notes=f"solved over {field_desc} (tried {tried} branch combination(s))",
            )

    return IntersectionResult(
        feasible=False,
        notes=(
            f"no common solution over {field_desc} across {tried} branch "
            f"combination(s)"
        ),
    )
