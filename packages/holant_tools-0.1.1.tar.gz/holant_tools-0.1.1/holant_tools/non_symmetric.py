"""Non-symmetric matchgate signatures and their realisability subvarieties.

v0.3-beta prototype (genuine subvariety-intersection extension of v0.2).

A non-symmetric arity-n matchgate signature has 2^n free values (one per
bit string), not n+1 (one per Hamming weight). Symmetric signatures are a
special case (where sigma_b depends only on |b|).

For arities 2 and 3, realisability reduces to a parity condition on the
standard-basis pullback (Valiant 2008 Propositions 6.1, 6.2). For arity >= 4,
the matchgate identities (Grassmann-Plucker) impose additional constraints
beyond parity; that case is deferred to a follow-on.

This module:
  - NonSymmetricSignature dataclass.
  - pullback_tau_non_symmetric: compute tau = beta^{otimes n}-pullback symbolically
    in the chart beta = [[1, u], [1, v]].
  - realizability_subvariety_non_symmetric: build B(sigma) as a Subvariety
    object compatible with intersect_subvarieties.

See BOUNDED_GENUS.md sibling NON_SYMMETRIC.md for the design + scope statement.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Sequence, Tuple

from sympy import Symbol, symbols, expand, sympify
from sympy.polys.polytools import Poly

from .signatures import SignatureKind
from .realizability import Subvariety, U, V


BitString = Tuple[int, ...]


@dataclass
class NonSymmetricSignature:
    """A non-symmetric matchgate signature of arity n.

    Stored as a dict mapping bit strings of length n to field values. The
    bit string (b_1, ..., b_n) is the input to the matchgate wires; the
    value is the signature entry.

    For arity 2, the four bit strings are (0,0), (0,1), (1,0), (1,1).
    """

    values: Dict[BitString, object]
    arity: int
    kind: SignatureKind = "recognizer"
    name: str = ""

    def __post_init__(self):
        for b, val in self.values.items():
            if len(b) != self.arity:
                raise ValueError(
                    f"signature value has bit string of length {len(b)}, "
                    f"expected {self.arity}"
                )
        # Fill in missing entries as 0.
        for mask in range(1 << self.arity):
            b = tuple((mask >> i) & 1 for i in range(self.arity))
            if b not in self.values:
                self.values[b] = sympify(0)
            else:
                self.values[b] = sympify(self.values[b])

    def is_zero(self) -> bool:
        return all(v == 0 for v in self.values.values())

    def is_symmetric(self) -> bool:
        """True iff sigma_b depends only on |b| (Hamming weight)."""
        by_weight: Dict[int, object] = {}
        for b, val in self.values.items():
            w = sum(b)
            if w in by_weight:
                if sympify(by_weight[w] - val) != 0:
                    return False
            else:
                by_weight[w] = val
        return True

    def __repr__(self) -> str:
        nm = f", name={self.name!r}" if self.name else ""
        entries = ", ".join(
            f"{''.join(str(x) for x in b)}={v}"
            for b, v in sorted(self.values.items())
            if v != 0
        )
        sym = " [symmetric]" if self.is_symmetric() else ""
        return f"NonSymmetricSignature(arity {self.arity}, {{{entries}}}{nm}, {self.kind}{sym})"


# ---------------------------------------------------------------------------
# Pullback via beta^{otimes n}
# ---------------------------------------------------------------------------


def _wire_variables(n: int):
    """Return per-wire variables (s_i, t_i)_{i=0..n-1}."""
    s = symbols(" ".join(f"_s{i}" for i in range(n)))
    t = symbols(" ".join(f"_t{i}" for i in range(n)))
    if n == 1:
        s, t = (s,), (t,)
    return s, t


def pullback_tau_non_symmetric(sig: NonSymmetricSignature) -> Dict[BitString, object]:
    """Compute the standard-basis pullback tau of sigma under beta = [[1, u], [1, v]].

    Each wire transforms identically: s_i -> s_i + t_i, t_i -> u s_i + v t_i.
    The action is beta^{otimes n}, applied on the n wires of the matchgate.

    Returns a dict mapping bit strings to sympy expressions in U, V.
    """
    n = sig.arity
    if n == 0:
        return {(): sig.values[()]} if () in sig.values else {(): sympify(0)}

    s, t = _wire_variables(n)
    # Place-holder variables for the substitution.
    s_new, t_new = _wire_variables(n)
    s_new = tuple(Symbol(f"_S{i}") for i in range(n))
    t_new = tuple(Symbol(f"_T{i}") for i in range(n))

    # Build P_sigma(s_0, t_0, ..., s_{n-1}, t_{n-1}).
    P_sigma = sympify(0)
    for b, val in sig.values.items():
        if val == 0:
            continue
        monomial = sympify(1)
        for i, bi in enumerate(b):
            monomial *= t[i] if bi == 1 else s[i]
        P_sigma += val * monomial

    # Substitute s_i -> S_i + T_i, t_i -> u S_i + v T_i (simultaneously).
    pairs = []
    for i in range(n):
        pairs.append((s[i], s_new[i] + t_new[i]))
        pairs.append((t[i], U * s_new[i] + V * t_new[i]))
    P_tau = expand(P_sigma.subs(pairs, simultaneous=True))
    # Rename the new variables back to s_i, t_i for consistency.
    rename = {}
    for i in range(n):
        rename[s_new[i]] = s[i]
        rename[t_new[i]] = t[i]
    P_tau = P_tau.subs(rename)

    # Extract tau coefficients via Poly.
    variables = list(s) + list(t)
    poly = Poly(P_tau, *variables)
    tau: Dict[BitString, object] = {}
    for mask in range(1 << n):
        b = tuple((mask >> i) & 1 for i in range(n))
        monomial = sympify(1)
        for i, bi in enumerate(b):
            monomial *= t[i] if bi == 1 else s[i]
        coef = poly.coeff_monomial(monomial)
        tau[b] = expand(sympify(coef))
    return tau


# ---------------------------------------------------------------------------
# Realisability subvariety
# ---------------------------------------------------------------------------


def matchgate_identity_arity_4_even(tau: Dict[BitString, object]):
    """Even-parity arity-4 matchgate identity (Grassmann-Pluecker on Pfaffians).

    Returns the polynomial

        tau_0000 * tau_1111 - tau_1100 * tau_0011 + tau_1010 * tau_0101 - tau_1001 * tau_0110

    which must vanish for a parity-respecting arity-4 signature to be matchgate-
    realisable beyond the parity condition alone.

    The four pairs in the identity correspond to the three ways of partitioning
    {1, 2, 3, 4} into two pairs (giving Pfaffian products) plus the
    Pfaffian-of-full-matrix term:

        Pf({1,2,3,4}) * Pf(emptyset)  - Pf({1,2}) * Pf({3,4}) + Pf({1,3}) * Pf({2,4}) - Pf({1,4}) * Pf({2,3})

    The bit-string convention identifies subset S with the bit string with 1s
    at positions in S; tau_S = Pf on (complement of S) or (S itself) depending
    on convention -- the identity has the same form either way.
    """
    needed = [(0,0,0,0), (1,1,1,1), (1,1,0,0), (0,0,1,1), (1,0,1,0), (0,1,0,1), (1,0,0,1), (0,1,1,0)]
    for b in needed:
        if b not in tau:
            raise KeyError(f"tau is missing entry {b}; arity-4 even matchgate identity requires all 8 even-weight entries")
    return (
        tau[(0,0,0,0)] * tau[(1,1,1,1)]
        - tau[(1,1,0,0)] * tau[(0,0,1,1)]
        + tau[(1,0,1,0)] * tau[(0,1,0,1)]
        - tau[(1,0,0,1)] * tau[(0,1,1,0)]
    )


def matchgate_identity_arity_4_odd(tau: Dict[BitString, object]):
    """Odd-parity arity-4 matchgate identity (augmented-Pfaffian Grassmann-Pluecker).

    Returns the polynomial

        tau_1000 * tau_0111 - tau_0100 * tau_1011 + tau_0010 * tau_1101 - tau_0001 * tau_1110

    which must vanish for an odd-parity arity-4 signature to be matchgate-realisable.

    Derivation: Pfaffians of submatrices of a (2n+1)x(2n+1) skew Kasteleyn matrix
    on odd-cardinality subsets of {1,2,3,4} vanish, so the framework cannot directly
    represent odd-parity tau values as Pfaffians. The standard fix is to augment
    the index set with a virtual vertex omega: each odd-parity tau_b corresponds to
    the Pfaffian on the *complement* of b in {1,2,3,4,omega}, including omega, so
    the submatrix has even cardinality.

    The augmentation is a proof technique: the 4-pair identity above is derived by
    Grassmann-Pluecker on the augmented 5x5 skew matrix, and the omega-related
    entries cancel pairwise in the final relation. Verified by direct symbolic
    computation (see tests).

    Pair structure: each weight-1 b paired with its bit-flip complement (weight 3).
    """
    needed = [(1,0,0,0), (0,1,1,1), (0,1,0,0), (1,0,1,1), (0,0,1,0), (1,1,0,1), (0,0,0,1), (1,1,1,0)]
    for b in needed:
        if b not in tau:
            raise KeyError(f"tau is missing entry {b}; arity-4 odd matchgate identity requires all 8 odd-weight entries")
    return (
        tau[(1,0,0,0)] * tau[(0,1,1,1)]
        - tau[(0,1,0,0)] * tau[(1,0,1,1)]
        + tau[(0,0,1,0)] * tau[(1,1,0,1)]
        - tau[(0,0,0,1)] * tau[(1,1,1,0)]
    )


def realizability_subvariety_non_symmetric(sig: NonSymmetricSignature) -> Subvariety:
    """Build the realisability subvariety B(sigma) in the (u, v) chart of M.

    Two parity branches:
        even: tau_b = 0 for all b with sum(b) odd.
        odd:  tau_b = 0 for all b with sum(b) even.

    For arity 4 (even-parity branch only, this session): adds the
    Grassmann-Pluecker matchgate identity equation to the even-parity branch.

    For arity >= 5 and for the odd-parity branch at arity 4: parity is
    necessary but NOT sufficient -- the full matchgate identities (general
    Grassmann-Pluecker / augmented Pfaffian framework) impose additional
    constraints. These cases return parity-only subvarieties and are
    therefore over-approximations of the true realisability locus
    (could report feasibility where the true answer is infeasibility).

    Returns a Subvariety object compatible with intersect_subvarieties.
    """
    n = sig.arity
    if n < 2 or sig.is_zero():
        from .signatures import Signature
        proxy = Signature(values=(0,) * (n + 1), kind=sig.kind, name=sig.name)
        return Subvariety(proxy, [], [], tau=[], is_trivial=True)

    tau = pullback_tau_non_symmetric(sig)

    even_eqs = []  # weight-odd entries zero
    odd_eqs = []   # weight-even entries zero
    for b, val in sorted(tau.items()):
        w = sum(b)
        if w == 0:
            continue  # included separately below
        if w % 2 == 1:
            even_eqs.append(val)
        else:
            odd_eqs.append(val)
    zero_b = tuple([0] * n)
    if zero_b in tau:
        odd_eqs.insert(0, tau[zero_b])

    # Arity-4 matchgate identities (Grassmann-Pluecker, Cai-Lu Thm 2.2).
    if n == 4:
        even_eqs.append(expand(matchgate_identity_arity_4_even(tau)))
        odd_eqs.append(expand(matchgate_identity_arity_4_odd(tau)))

    from .signatures import Signature
    proxy = Signature(values=(0,) * (n + 1), kind=sig.kind, name=sig.name or f"<non-sym arity {n}>")
    sv = Subvariety(proxy, even_eqs, odd_eqs, tau=list(tau.values()), is_trivial=False)
    return sv
