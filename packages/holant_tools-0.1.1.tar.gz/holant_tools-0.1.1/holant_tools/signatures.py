"""Symmetric matchgate signatures and the Cai-Lu 2011 realizability criterion.

Background. A symmetric matchgate signature on n inputs (or outputs) is a
sequence [x_0, x_1, ..., x_n] where x_i is the entry of the matchgate's
signature on the input whose Hamming weight is i. Cai & Lu 2011 (Theorem 2.5)
established the following:

  A symmetric signature [x_0, ..., x_n] is realizable on some basis
  beta = [n, p] in GL_2(F)/~ if and only if there exist constants
  (a, b, c) -- not all zero -- such that

       a * x_k + b * x_{k+1} + c * x_{k+2} = 0  for all k in [0, n-2].

This is a necessary condition for the signature to be realizable on any
basis at all. The characteristic polynomial c*r^2 + b*r + a has roots
that determine which of Cai-Lu's three Forms (Theorems 2.3 / 2.4) the
realizability takes.

v0.1 of this module implements the Theorem 2.5 check. The explicit
construction of the realizability subvariety B_rec(sigma) or B_gen(sigma)
in the basis manifold M -- needed for the intersection step of the full
Simultaneous Realizability Problem solver -- is deferred to v0.2.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Literal, Optional, Sequence

from sympy import Matrix, Symbol, sympify, S


SignatureKind = Literal["recognizer", "generator"]


@dataclass
class Signature:
    """A symmetric signature [x_0, x_1, ..., x_n].

    Length n+1 means arity n. The 'kind' marks whether the signature plays
    the role of a recognizer or a generator in the matchgate construction
    (Valiant 2008 sec. 4, Cai-Lu 2011 sec. 2).
    """

    values: tuple
    kind: SignatureKind = "recognizer"
    name: str = ""

    def __post_init__(self):
        # Coerce values to sympy expressions so we can do symbolic linear algebra.
        self.values = tuple(sympify(v) for v in self.values)

    @property
    def arity(self) -> int:
        return len(self.values) - 1

    def is_zero(self) -> bool:
        return all(v == 0 for v in self.values)

    def __repr__(self) -> str:
        vals = ", ".join(str(v) for v in self.values)
        nm = f", name={self.name!r}" if self.name else ""
        return f"Signature([{vals}], {self.kind}, arity {self.arity}{nm})"


@dataclass
class Recurrence:
    """A linear recurrence  a*x_k + b*x_{k+1} + c*x_{k+2} = 0  on a signature.

    Determined up to a non-zero scalar when the signature is non-degenerate
    in the sense of Cai-Lu Definition 4.2. The characteristic polynomial is
    c*r^2 + b*r + a; its roots determine the Cai-Lu Form (1, 2, or 3).
    """

    a: object
    b: object
    c: object

    def __post_init__(self):
        self.a = sympify(self.a)
        self.b = sympify(self.b)
        self.c = sympify(self.c)

    @property
    def is_trivial(self) -> bool:
        return self.a == 0 and self.b == 0 and self.c == 0

    def characteristic_polynomial(self):
        """c*r^2 + b*r + a  (with r = Symbol('r'))."""
        r = Symbol("r")
        return self.c * r**2 + self.b * r + self.a

    def roots(self):
        """Roots of the characteristic polynomial. Uses sympy.solve."""
        from sympy import solve

        r = Symbol("r")
        return solve(self.characteristic_polynomial(), r)

    def __repr__(self) -> str:
        return f"Recurrence({self.a})*x_k + ({self.b})*x_(k+1) + ({self.c})*x_(k+2) = 0"


def find_recurrence(sig: Signature) -> Optional[Recurrence]:
    """Find (a, b, c) -- a Recurrence -- valid on the signature, or None.

    Implements Cai-Lu 2011 Theorem 2.5: solve the system
        M @ (a, b, c)^T = 0
    where M has rows [x_k, x_{k+1}, x_{k+2}] for k = 0, ..., n-2.

    Returns the first basis vector of the (right) null space of M, or None
    if the null space is trivial. By Theorem 2.5, a non-trivial null space
    exists iff the signature is realizable on some basis.

    Special cases (Cai-Lu Lemma 4.1):
      - arity 0 or 1: trivially realizable on any basis; we return (1, 0, 0)
        as a placeholder Recurrence.
      - zero signature: trivially realizable on any basis; same placeholder.
    """
    n = sig.arity

    if sig.is_zero() or n < 2:
        return Recurrence(1, 0, 0)

    x = sig.values
    rows = [[x[k], x[k + 1], x[k + 2]] for k in range(n - 1)]
    M = Matrix(rows)
    nullspace = M.nullspace()

    if not nullspace:
        return None

    v = nullspace[0]
    return Recurrence(v[0], v[1], v[2])


def is_realizable_somewhere(sig: Signature) -> bool:
    """Is the signature realizable on at least one basis in M?

    By Cai-Lu 2011 Theorem 2.5, this is equivalent to the existence of a
    non-trivial linear recurrence on the signature values.
    """
    return find_recurrence(sig) is not None


def srp_necessary_check(signatures: Sequence[Signature]) -> dict:
    """Necessary-condition check for the Simultaneous Realizability Problem.

    Returns a dict with:
      - feasible_necessary: bool, True iff each signature is individually
        realizable on some basis.
      - per_signature: list of (Signature, Recurrence or None)
      - infeasible_signatures: list of Signatures that fail individual check.

    WARNING: passing this check is *necessary* but NOT *sufficient* for
    joint realizability on a common basis. Two signatures may each be
    realizable on some basis without there being a common basis on which
    both are realizable. The sufficient check requires intersecting the
    realizability subvarieties B_i in the basis manifold M -- deferred to
    v0.2.
    """
    per_sig = []
    infeasible = []
    for sig in signatures:
        rec = find_recurrence(sig)
        per_sig.append((sig, rec))
        if rec is None:
            infeasible.append(sig)

    return {
        "feasible_necessary": len(infeasible) == 0,
        "per_signature": per_sig,
        "infeasible_signatures": infeasible,
    }
