"""Command-line interface for holant-tools.

After `pip install holant-tools`, this is invoked as `holant <subcommand>`.

Subcommands:
  signature    Check whether one signature is realizable on some basis (Cai-Lu Thm 2.5).
  check        Necessary-condition SRP check on a list of signatures.
  solve        Full SRP decision; optional --modulus for finite-field search.
  hardness     Screen a signature family for matchgate-realisability vs hardness candidacy.

Examples:
  holant signature "[1, 0, 1]" --kind recognizer --name EQ_2
  holant check  examples/01_cai_lu_5_1.json
  holant solve  examples/01_cai_lu_5_1.json --modulus 7
  holant hardness examples/01_cai_lu_5_1.json
"""

from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

from . import (
    Signature,
    find_recurrence,
    srp_necessary_check,
    srp_solve,
    hardness_candidate,
    U,
    V,
)


def _load_signatures(file_path: str):
    sigs_file = Path(file_path)
    if not sigs_file.is_file():
        print(f"error: file not found: {sigs_file}", file=sys.stderr)
        return None
    try:
        data = json.loads(sigs_file.read_text())
    except json.JSONDecodeError as e:
        print(f"error: could not parse {sigs_file}: {e}", file=sys.stderr)
        return None
    return [
        Signature(
            values=tuple(entry["values"]),
            kind=entry.get("kind", "recognizer"),
            name=entry.get("name", ""),
        )
        for entry in data
    ]


def cmd_signature(args) -> int:
    try:
        values = json.loads(args.values)
    except json.JSONDecodeError as e:
        print(f"error: could not parse signature values as JSON: {e}", file=sys.stderr)
        return 1
    if not isinstance(values, list):
        print(f"error: signature values must be a JSON list", file=sys.stderr)
        return 1

    sig = Signature(values=tuple(values), kind=args.kind, name=args.name or "")
    print(f"Signature: {sig}")
    print()

    rec = find_recurrence(sig)
    if rec is None:
        print("Cai-Lu Theorem 2.5 (individual realizability): FAIL")
        print("  No non-trivial linear recurrence exists on the signature values.")
        print("  This signature is not realizable on ANY basis.")
        return 0

    print("Cai-Lu Theorem 2.5 (individual realizability): PASS")
    print(f"  Recurrence: ({rec.a})*x_k + ({rec.b})*x_(k+1) + ({rec.c})*x_(k+2) = 0")
    if not rec.is_trivial:
        char = rec.characteristic_polynomial()
        print(f"  Characteristic polynomial: {char}")
        try:
            roots = rec.roots()
            print(f"  Roots: {roots}")
        except Exception as e:
            print(f"  Roots: (could not solve symbolically: {e})")
    print("  -> Realizable on some basis (necessary condition met).")
    return 0


def cmd_check(args) -> int:
    sigs = _load_signatures(args.file)
    if sigs is None:
        return 1
    print(f"Loaded {len(sigs)} signature(s) from {Path(args.file).name}.\n")
    result = srp_necessary_check(sigs)
    for sig, rec in result["per_signature"]:
        status = "PASS" if rec is not None else "FAIL"
        name = sig.name or "<unnamed>"
        print(f"  [{status}] {name} ({sig.kind}, arity {sig.arity})")
        if rec is not None and not rec.is_trivial:
            print(f"        recurrence: ({rec.a}, {rec.b}, {rec.c})")
    print()
    if result["feasible_necessary"]:
        print("SRP necessary-condition check: PASS")
        print("  Every signature is individually realizable on some basis.")
        print("  WARNING: necessary but NOT sufficient for joint realizability.")
        return 0
    n_bad = len(result["infeasible_signatures"])
    print("SRP necessary-condition check: FAIL")
    print(f"  {n_bad} signature(s) not realizable on any basis.")
    return 1


def cmd_solve(args) -> int:
    sigs = _load_signatures(args.file)
    if sigs is None:
        return 1

    print(f"Loaded {len(sigs)} signature(s) from {Path(args.file).name}.")
    if args.modulus is not None:
        print(f"Search field: F_{args.modulus}.")
    else:
        print("Search field: algebraic closure of Q.")
    print()

    result = srp_solve(sigs, modulus=args.modulus)

    print("Per-signature Form classification:")
    for sig, fc in result.individual_results:
        name = sig.name or "<unnamed>"
        if fc is None:
            print(f"  [FAIL] {name} ({sig.kind}, arity {sig.arity}): not realizable on any basis")
        else:
            roots = ", ".join(str(r) for r in fc.roots) if fc.roots else "-"
            print(f"  [{fc.form.value:<10s}] {name} ({sig.kind}, arity {sig.arity}): roots [{roots}]")

    print()
    if result.infeasible_signatures:
        print("SRP: INFEASIBLE")
        print(f"  Individually non-realizable: {[s.name for s in result.infeasible_signatures]}")
        return 1

    print("Realizability subvarieties:")
    for sv in result.subvarieties:
        name = sv.signature.name or "<unnamed>"
        if sv.is_trivial:
            print(f"  {name}: trivial (B = M)")
        else:
            print(
                f"  {name}: even-parity ({len(sv.even_parity_equations)} eqs), "
                f"odd-parity ({len(sv.odd_parity_equations)} eqs)"
            )

    print()
    if result.feasible:
        w = result.witness
        u_val = w.get(U)
        v_val = w.get(V)
        bc = ", ".join(result.intersection.branch_combination) if result.intersection else ""
        print("SRP: FEASIBLE")
        print(f"  Witness basis: u = {u_val}, v = {v_val}")
        print(f"  (chart: beta = [[1, u], [1, v]], so n = (1, 1)^T and p = (u, v)^T)")
        print(f"  Branch combination: [{bc}]")
        print(f"  {result.notes}")
        return 0

    print("SRP: INFEASIBLE")
    print(f"  {result.notes}")
    return 1


def cmd_hardness(args) -> int:
    sigs = _load_signatures(args.file)
    if sigs is None:
        return 1

    print(f"Loaded {len(sigs)} signature(s) from {Path(args.file).name}.\n")
    primes = args.primes if args.primes else None
    report = hardness_candidate(
        sigs, primes_to_try=primes, include_algebraic_closure=not args.skip_q_bar
    )

    print("Per-field SRP screening:")
    for field_label, ok, witness in report.fields_tried:
        status = "feasible" if ok else "infeasible"
        wit_str = f"  witness={witness}" if ok and witness else ""
        print(f"  {field_label:10s} {status}{wit_str}")

    print()
    if report.individual_infeasibility:
        print("VERDICT: family contains an individually non-realisable signature (short-circuit).")
        print(f"  Failed: {report.individual_infeasibility}")
        print(f"  {report.notes}")
        return 1

    if report.is_hardness_candidate:
        print("VERDICT: HARDNESS CANDIDATE")
        print()
        print(report.notes)
        print()
        print("This is a *screening* result. The verdict says the polynomial-time matchgate /")
        print("holographic-algorithm route is unavailable in the chart + fields tried, NOT that")
        print("the problem is provably #P-hard. Other tractability mechanisms may apply, and")
        print("proving hardness requires gadget reductions beyond this tool.")
        return 0

    print("VERDICT: matchgate-realisable")
    print(f"  {report.notes}")
    return 0


def main() -> int:
    p = argparse.ArgumentParser(
        prog="holant",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    p_sig = sub.add_parser(
        "signature", help="check whether a single signature is realizable on some basis"
    )
    p_sig.add_argument("values", help='signature values as JSON list, e.g. "[1, 0, 1]"')
    p_sig.add_argument("--kind", choices=["recognizer", "generator"], default="recognizer")
    p_sig.add_argument("--name", default="", help="signature name (display only)")
    p_sig.set_defaults(func=cmd_signature)

    p_check = sub.add_parser(
        "check", help="necessary-condition SRP check on a list of signatures"
    )
    p_check.add_argument("file", help="path to JSON file with list of signatures")
    p_check.set_defaults(func=cmd_check)

    p_solve = sub.add_parser(
        "solve",
        help="full SRP decision (intersection on M); optional --modulus for F_p",
    )
    p_solve.add_argument("file", help="path to JSON file with list of signatures")
    p_solve.add_argument(
        "--modulus",
        type=int,
        default=None,
        help="finite-field modulus p (search F_p^2); omit to search over algebraic closure of Q",
    )
    p_solve.set_defaults(func=cmd_solve)

    p_hard = sub.add_parser(
        "hardness",
        help="screen a signature family for matchgate-realisability over multiple fields",
    )
    p_hard.add_argument("file", help="path to JSON file with list of signatures")
    p_hard.add_argument(
        "--primes",
        type=int,
        nargs="+",
        default=None,
        help="primes p to try (defaults to 2 3 5 7 11 13)",
    )
    p_hard.add_argument(
        "--skip-q-bar",
        action="store_true",
        help="skip the algebraic-closure-of-Q search (only try the listed primes)",
    )
    p_hard.set_defaults(func=cmd_hardness)

    args = p.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
