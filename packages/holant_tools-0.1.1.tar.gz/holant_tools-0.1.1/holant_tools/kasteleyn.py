"""Automatic Kasteleyn-orientation construction for planar graphs.

A *Kasteleyn orientation* of an embedded planar graph is an orientation of its
edges such that every interior face has an odd number of clockwise-oriented
edges when traversed counterclockwise. Kasteleyn 1963 (and the FKT theorem)
established that the Pfaffian of the resulting skew-symmetric matrix equals
the perfect-matching count of the graph (up to sign).

This module constructs such an orientation from a planar embedding given as
a *rotation system*: for each vertex, the cyclic counterclockwise order of
its incident edges.

The algorithm:

  1. Enumerate the faces of the embedding from the rotation system using the
     standard "next edge in face" rule.
  2. Pick an outer face (we default to the largest face).
  3. Orient each edge arbitrarily (lower-index vertex -> higher-index vertex).
  4. Compute initial parity of each face (number of CCW-traversed edges that
     are against their orientation, mod 2).
  5. Build the dual graph (faces as nodes, edges as connections between
     adjacent faces).
  6. Construct a spanning tree of the dual graph rooted at the outer face.
  7. Traverse the spanning tree in reverse-BFS order (leaves first). For each
     non-root face whose interior-face parity is wrong (we want odd), flip
     the edge connecting that face to its parent in the dual tree. This
     flip toggles the parity of both the face and its parent.
  8. After traversal, all interior faces have odd parity (the outer face's
     parity is "free" by Euler's formula).
  9. Return the skew-symmetric matrix from the final orientation.

Worked example. For the 4-cycle on vertices 1, 2, 3, 4 in CCW order, the
rotation system is:

    {1: [2, 4], 2: [3, 1], 3: [4, 2], 4: [1, 3]}

The algorithm constructs an orientation whose Pfaffian equals 2, the number
of perfect matchings of the 4-cycle. See tests in tests/test_holant_tools.py.

References:
  - Kasteleyn 1963 (introduction of the Pfaffian orientation).
  - Galluccio-Loebl 1999 (general bounded-genus extension).
  - Cimasoni-Reshetikhin 2007 (modern treatment via spin structures).
"""

from __future__ import annotations
from collections import deque
from typing import Any, Dict, List, Sequence, Tuple

from sympy import Matrix


# ---------------------------------------------------------------------------
# Face enumeration
# ---------------------------------------------------------------------------

DirectedEdge = Tuple[Any, Any]
Face = Tuple[DirectedEdge, ...]


def _enumerate_faces(
    rotation_system: Dict[Any, List[Any]],
    edges: Sequence[Tuple[Any, Any]],
) -> List[Face]:
    """Enumerate faces of a planar embedding from a rotation system.

    Rotation system convention: rotation_system[v] is the list of v's
    neighbors in counterclockwise order around v.

    Face-walk rule: from directed edge (u, v), at v find u in v's rotation;
    the next directed edge is (v, prev) where prev is the neighbor immediately
    BEFORE u in CCW order (i.e., immediately clockwise from u at v).
    This traces the face to the LEFT of (u, v) when walking u -> v.
    """
    directed_edges = set()
    for u, v in edges:
        directed_edges.add((u, v))
        directed_edges.add((v, u))

    faces: List[Face] = []
    remaining = set(directed_edges)
    while remaining:
        start = next(iter(remaining))
        face: List[DirectedEdge] = []
        cur = start
        while cur in remaining:
            remaining.remove(cur)
            face.append(cur)
            u, v = cur
            v_neighbors = rotation_system[v]
            if u not in v_neighbors:
                raise ValueError(
                    f"rotation_system at {v} = {v_neighbors} does not contain {u}; "
                    f"rotation system inconsistent with edges"
                )
            idx = v_neighbors.index(u)
            prev_neighbor = v_neighbors[(idx - 1) % len(v_neighbors)]
            cur = (v, prev_neighbor)
        faces.append(tuple(face))
    return faces


def _face_size(face: Face) -> int:
    return len(face)


def _select_outer_face(faces: List[Face]) -> int:
    """Pick the index of the outer face. Default heuristic: the largest face."""
    return max(range(len(faces)), key=lambda i: _face_size(faces[i]))


# ---------------------------------------------------------------------------
# Orientation and parity
# ---------------------------------------------------------------------------

def _initial_orientation(edges: Sequence[Tuple[Any, Any]], vertex_index: Dict[Any, int]) -> Dict[Tuple[Any, Any], int]:
    """Initial orientation: each undirected edge {u, v} oriented as the directed
    pair with smaller vertex_index first.

    Returns a dict: undirected_edge_key -> orientation_sign where the key is the
    canonical tuple (min, max) and the sign is +1 (default: min -> max).
    Edge flips negate the sign.
    """
    orient: Dict[Tuple[Any, Any], int] = {}
    for u, v in edges:
        if vertex_index[u] < vertex_index[v]:
            orient[(u, v)] = +1   # u -> v
        else:
            orient[(v, u)] = +1   # v -> u
    return orient


def _edge_key(u, v, vertex_index):
    """Canonical undirected-edge key (smaller-index, larger-index)."""
    if vertex_index[u] < vertex_index[v]:
        return (u, v)
    return (v, u)


def _directed_against_orientation(
    de: DirectedEdge,
    orient: Dict[Tuple[Any, Any], int],
    vertex_index: Dict[Any, int],
) -> bool:
    """Is the directed edge `de` traversed AGAINST the current orientation?"""
    u, v = de
    key = _edge_key(u, v, vertex_index)
    sign = orient[key]
    # sign +1 means key[0] -> key[1] (i.e., the lower-index vertex points to higher).
    # de is against orientation iff (de == key reversed and sign +1) or (de == key and sign -1).
    if de == key:
        return sign == -1
    else:
        return sign == +1


def _face_parity(
    face: Face,
    orient: Dict[Tuple[Any, Any], int],
    vertex_index: Dict[Any, int],
) -> int:
    """Number of CCW-traversed edges against orientation, mod 2.

    For a Kasteleyn orientation, every interior face must have this parity
    equal to 1 (odd).
    """
    count = 0
    for de in face:
        if _directed_against_orientation(de, orient, vertex_index):
            count += 1
    return count % 2


# ---------------------------------------------------------------------------
# Dual graph + spanning tree
# ---------------------------------------------------------------------------

def _build_dual_adjacency(
    faces: List[Face],
    vertex_index: Dict[Any, int],
) -> Dict[int, List[Tuple[int, Tuple[Any, Any]]]]:
    """For each face index, list of (neighbor face index, canonical edge key).

    Two faces are adjacent in the dual if they share an edge of the primal.
    Each undirected edge of the primal borders exactly two faces.
    """
    # Map canonical edge key -> list of face indices that contain it.
    edge_to_faces: Dict[Tuple[Any, Any], List[int]] = {}
    for fi, face in enumerate(faces):
        for de in face:
            key = _edge_key(de[0], de[1], vertex_index)
            edge_to_faces.setdefault(key, []).append(fi)

    dual_adj: Dict[int, List[Tuple[int, Tuple[Any, Any]]]] = {fi: [] for fi in range(len(faces))}
    for key, face_list in edge_to_faces.items():
        if len(face_list) != 2:
            raise ValueError(
                f"edge {key} borders {len(face_list)} faces (expected 2); "
                f"the planar embedding may be inconsistent"
            )
        f0, f1 = face_list
        dual_adj[f0].append((f1, key))
        dual_adj[f1].append((f0, key))
    return dual_adj


def _dual_spanning_tree(
    dual_adj: Dict[int, List[Tuple[int, Tuple[Any, Any]]]],
    root: int,
) -> Tuple[Dict[int, int], Dict[int, Tuple[Any, Any]], List[int]]:
    """BFS spanning tree of the dual graph rooted at `root`.

    Returns:
      parent: face_idx -> parent_face_idx (root maps to root).
      parent_edge: face_idx -> the primal edge connecting to parent.
      bfs_order: BFS visit order (root first).
    """
    parent: Dict[int, int] = {root: root}
    parent_edge: Dict[int, Tuple[Any, Any]] = {}
    bfs_order: List[int] = [root]
    queue = deque([root])
    while queue:
        f = queue.popleft()
        for nb, edge_key in dual_adj[f]:
            if nb in parent:
                continue
            parent[nb] = f
            parent_edge[nb] = edge_key
            bfs_order.append(nb)
            queue.append(nb)
    return parent, parent_edge, bfs_order


# ---------------------------------------------------------------------------
# Top-level: kasteleyn_orient
# ---------------------------------------------------------------------------

def kasteleyn_orient(
    vertices: Sequence[Any],
    edges: Sequence[Tuple[Any, Any]],
    rotation_system: Dict[Any, List[Any]],
    outer_face_index: int = None,
) -> Matrix:
    """Build a Kasteleyn-oriented skew-symmetric matrix from a planar embedding.

    Args:
        vertices: sequence of vertex labels. The order determines the row /
            column index of the returned matrix.
        edges: list of (u, v) undirected edges.
        rotation_system: dict vertex -> list of neighbors in CCW cyclic order.
        outer_face_index: optional index of the outer face within the enumerated
            faces. If None, the largest face is selected (heuristic).

    Returns:
        A sympy Matrix M of shape (n, n), skew-symmetric, with M[i, j] = +1 if
        the Kasteleyn orientation has an edge vertices[i] -> vertices[j],
        M[i, j] = -1 if vertices[j] -> vertices[i], else 0.

        For a planar bipartite graph (or any planar graph), |Pf(M)| equals the
        number of perfect matchings.

    Raises:
        ValueError if the rotation system is inconsistent with the edge list
        (e.g., an edge {u, v} where u is missing from rotation_system[v]).
    """
    vertex_index = {v: i for i, v in enumerate(vertices)}
    n = len(vertices)

    # 1. Initial orientation.
    orient = _initial_orientation(edges, vertex_index)

    # 2. Face enumeration from the rotation system.
    faces = _enumerate_faces(rotation_system, edges)

    # 3. Outer face.
    if outer_face_index is None:
        outer_face_index = _select_outer_face(faces)

    # 4. Compute parity of each face.
    parity = {fi: _face_parity(faces[fi], orient, vertex_index) for fi in range(len(faces))}

    # 5. Build dual graph + spanning tree rooted at outer face.
    dual_adj = _build_dual_adjacency(faces, vertex_index)
    parent, parent_edge, bfs_order = _dual_spanning_tree(dual_adj, outer_face_index)

    # 6. Traverse in REVERSE BFS order (leaves first). For each non-root face f
    #    with parity 0 (we want 1 for interior faces), flip the parent edge.
    #    Flipping changes parity of both f and parent.
    for f in reversed(bfs_order):
        if f == outer_face_index:
            continue  # outer face's parity is free
        if parity[f] == 0:  # want 1 (odd) for interior
            key = parent_edge[f]
            orient[key] *= -1
            parity[f] ^= 1
            parity[parent[f]] ^= 1

    # 7. Sanity check: every interior face should now have odd parity.
    for fi in range(len(faces)):
        if fi == outer_face_index:
            continue
        if parity[fi] != 1:
            raise RuntimeError(
                f"Kasteleyn-orientation algorithm failed: interior face {fi} "
                f"has parity {parity[fi]} (expected 1). This indicates a bug "
                f"or a non-planar input."
            )

    # 8. Build the skew-symmetric matrix.
    M = Matrix.zeros(n, n)
    for key, sign in orient.items():
        u, v = key   # convention: key[0] -> key[1] when sign = +1
        i = vertex_index[u]
        j = vertex_index[v]
        if sign == +1:
            M[i, j] = 1
            M[j, i] = -1
        else:
            M[i, j] = -1
            M[j, i] = 1
    return M
