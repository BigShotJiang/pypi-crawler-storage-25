"""Example signatures from the holographic-algorithms literature.

Sources:
  - Valiant 2008, "Holographic Algorithms," SIAM J. Comput. 37(5).
  - Cai & Lu 2011, "Holographic Algorithms: From Art to Science,"
    J. Comput. Syst. Sci. 77(1).
"""

from .signatures import Signature


# -------- Cai-Lu 2011 sec. 5.1: #_{2^k-1} Pl-Rtw-Mon-kCNF --------

EQUALITY_2_REC = Signature(values=(1, 0, 1), kind="recognizer", name="EQ_2")
"""Equality on 2 Boolean inputs. Symmetric signature [1, 0, 1] of arity 2.

Used in Cai-Lu sec. 5.1 to encode the variable side of #Pl-Rtw-Mon-kCNF.
"""


def OR_k_GEN(k: int) -> Signature:
    """OR on k Boolean inputs as a generator: signature [0, 1, 1, ..., 1] of arity k.

    Used in Cai-Lu sec. 5.1 to encode the clauses of #Pl-Rtw-Mon-kCNF.
    """
    return Signature(values=(0,) + (1,) * k, kind="generator", name=f"OR_{k}")


# -------- Cai-Lu 2011 sec. 6.1: Not-All-Equal --------


def NAE_k(k: int) -> Signature:
    """Not-All-Equal on k Boolean inputs as a recognizer.

    Signature [0, 1, 1, ..., 1, 0] of arity k: 1 unless all inputs equal.
    """
    return Signature(
        values=(0,) + (1,) * (k - 1) + (0,),
        kind="recognizer",
        name=f"NAE_{k}",
    )


# -------- Cai-Lu 2011 sec. 5.2: #_{2^k-1} Pl-k/2Bip-VC --------

VC_211_DOTS_1_REC = Signature(values=(2, 1, 1), kind="recognizer", name="VC[2,1,1]")
"""Recognizer signature [2, 1, 1, ..., 1] of arity k for the right side of
the regular (k,2)-bipartite vertex cover problem. (Cai-Lu sec. 5.2.)

Note: the precise definition depends on k; this constant is for k = 2.
"""


# -------- Useful test signatures --------

EQUALITY_3_REC = Signature(values=(1, 0, 0, 1), kind="recognizer", name="EQ_3")
"""Equality on 3 Boolean inputs: signature [1, 0, 0, 1]."""

# A signature NOT realizable on any basis (cf. Cai-Lu sec. 5.2 'set of constraints
# that result in empty intersection'):
NON_REALIZABLE_EXAMPLE = Signature(
    values=(1, 1, 1, 0, 1, 0, 1),
    kind="recognizer",
    name="non-realizable-example",
)
"""A constructed example: the only solution to the recurrence system is
trivial, so by Cai-Lu Theorem 2.5 this signature is not realizable on
any basis."""
