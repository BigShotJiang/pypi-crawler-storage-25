"""Hardness-candidate recognition for matchgate Holant problems.

Natural by-product of v0.3-beta-followon: a signature family is matchgate-
realisable iff `srp_solve` returns feasible over SOME field on SOME chart of
the basis manifold $\\mathcal{M}$. If no realising basis is found across the
algebraic closure of $\\mathbf{Q}$ and several small finite fields, the family
is a *candidate* for $\\#\\mathsf{P}$-hardness in the Cai-Lu-Xia dichotomy
framework.

Important caveats (documented prominently because misuse is easy):

1. Not realisable on tried fields is **necessary but not sufficient** for
   $\\#\\mathsf{P}$-hardness. Other tractability mechanisms (bounded treewidth
   via Markov-Shi, planarity, ad-hoc reductions) may still apply. This
   function does not see those mechanisms.

2. The current implementation uses **one chart of $\\mathcal{M}$**
   ($\\beta = [[1, u], [1, v]]$ with $u \\ne v$). A signature family might be
   realisable on $\\mathcal{M}$ but its realising basis could fall outside
   this chart (worked example in `NON_SYMMETRIC.md`: $(0, x, y, 0)$ with
   $x + y \\ne 0$). Infeasibility reports here are scoped to "infeasible in
   the tried chart + tried fields."

3. This is **not a proof of $\\#\\mathsf{P}$-hardness**. Proving hardness
   requires constructing gadget reductions (Cai-Xia and successors); the
   creative mathematical content of those proofs is not automatable. This
   function recognises *candidates* in a screening sense -- "worth
   investigating further as hardness-side" vs "almost certainly poly-time
   via the matchgate route."

The function is therefore most useful as a *first-pass screen* over a family
of signatures the user is curious about. A "hardness candidate" verdict here
suggests that the polynomial-time matchgate route is unavailable; whether
the problem is actually hard requires separate analysis.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple, Union

from .signatures import Signature
from .non_symmetric import NonSymmetricSignature
from .srp_solver import srp_solve, SRPResult


# A "signature input" can be either a symmetric Signature or a NonSymmetricSignature.
SignatureInput = Union[Signature, NonSymmetricSignature]


@dataclass
class HardnessReport:
    """Outcome of a hardness-candidate screen for a signature family."""

    signatures_count: int
    fields_tried: List[Tuple[str, bool, Optional[dict]]] = field(default_factory=list)
    """List of (field_label, was_feasible, witness_dict) per field tried."""

    is_matchgate_realizable_anywhere_tried: bool = False
    """True iff at least one tried field admitted a realising basis."""

    is_hardness_candidate: bool = False
    """True iff no tried field admitted a realising basis. Necessary, not sufficient, for hardness."""

    individual_infeasibility: List[str] = field(default_factory=list)
    """Names of signatures that fail Theorem 2.5 (individually non-realisable) -- these short-circuit."""

    notes: str = ""

    def __repr__(self) -> str:
        if self.individual_infeasibility:
            flag = "individually infeasible (short-circuit)"
        elif self.is_hardness_candidate:
            flag = "HARDNESS CANDIDATE"
        else:
            flag = "matchgate-realisable"
        return (
            f"HardnessReport({self.signatures_count} sigs, {flag}, "
            f"tried {len(self.fields_tried)} fields)"
        )


_DEFAULT_PRIMES = [2, 3, 5, 7, 11, 13]


def hardness_candidate(
    signatures: Sequence[SignatureInput],
    primes_to_try: Optional[Sequence[int]] = None,
    include_algebraic_closure: bool = True,
) -> HardnessReport:
    """Screen a signature family for matchgate-realisability.

    Runs `srp_solve` over the algebraic closure of $\\mathbf{Q}$ (optional) and
    over a list of small finite fields $\\mathbf{F}_p$. If any field admits a
    realising basis, the family is NOT a hardness candidate (it's
    matchgate-realisable in some setting). If no field admits a realising
    basis, the family is a hardness candidate -- *with the caveats in this
    module's docstring*.

    Currently supports symmetric signatures only (via the v0.2 `Signature`
    path). Non-symmetric signatures are accepted in the API for future
    extension once non-symmetric `srp_solve` integration is wired up.

    Args:
        signatures: list of signatures (symmetric or non-symmetric).
        primes_to_try: list of small primes to search F_p over. Defaults to
            [2, 3, 5, 7, 11, 13]. The list is small because the SRP problem
            is rarely sensitive to large primes; the cyclotomic-modulus
            phenomenon (Cai-Lu sec 5.1) is captured by small p that divide
            $2^k - 1$ for small k.
        include_algebraic_closure: whether to also try over the algebraic
            closure of Q. Defaults to True.

    Returns:
        HardnessReport with per-field results, a top-level verdict, and
        caveat notes.

    Raises:
        NotImplementedError: if any input signature is non-symmetric (v0.3-beta
            integration with srp_solve is a follow-on item).
    """
    sym_sigs: List[Signature] = []
    for sig in signatures:
        if isinstance(sig, NonSymmetricSignature):
            if not sig.is_symmetric():
                raise NotImplementedError(
                    "hardness_candidate currently supports only symmetric signatures. "
                    "Non-symmetric integration into srp_solve is v0.3-beta-integration follow-on."
                )
            # Symmetric NonSymmetricSignature: convert via Hamming-weight values.
            n = sig.arity
            vals = []
            for w in range(n + 1):
                # Find any bit string of weight w; all have the same value (since symmetric).
                rep_bit = tuple(1 if i < w else 0 for i in range(n))
                vals.append(sig.values[rep_bit])
            sym_sigs.append(Signature(values=tuple(vals), kind=sig.kind, name=sig.name))
        else:
            sym_sigs.append(sig)

    if primes_to_try is None:
        primes_to_try = list(_DEFAULT_PRIMES)

    fields_tried: List[Tuple[str, bool, Optional[dict]]] = []
    any_feasible = False
    individual_failures: List[str] = []

    # Algebraic closure of Q.
    if include_algebraic_closure:
        result = srp_solve(sym_sigs)
        if result.infeasible_signatures and not individual_failures:
            individual_failures = [s.name or "<unnamed>" for s in result.infeasible_signatures]
        fields_tried.append(("Q-bar", result.feasible, result.witness if result.feasible else None))
        if result.feasible:
            any_feasible = True

    # Finite fields.
    for p in primes_to_try:
        result = srp_solve(sym_sigs, modulus=p)
        if result.infeasible_signatures and not individual_failures:
            individual_failures = [s.name or "<unnamed>" for s in result.infeasible_signatures]
        fields_tried.append((f"F_{p}", result.feasible, result.witness if result.feasible else None))
        if result.feasible:
            any_feasible = True

    is_candidate = not any_feasible and not individual_failures

    if individual_failures:
        notes = (
            f"Short-circuit: signature(s) fail individual realisability (Theorem 2.5): "
            f"{individual_failures}. The family is unrealisable for the trivial reason that "
            f"at least one signature is not matchgate-realisable on any basis."
        )
    elif is_candidate:
        notes = (
            "No realising basis found across the algebraic closure of Q and "
            f"{len(primes_to_try)} small finite fields. The family is a *candidate* "
            "for #P-hardness in the Cai-Lu-Xia dichotomy framework. Caveats: "
            "(1) Necessary but not sufficient for hardness -- other tractability "
            "mechanisms (bounded treewidth, planarity, ad-hoc) may still apply. "
            "(2) Single chart of M only -- a realising basis could exist outside the "
            "tried chart. (3) This is screening, not a hardness proof."
        )
    else:
        feasible_fields = [label for label, ok, _ in fields_tried if ok]
        notes = (
            f"Matchgate-realisable on: {feasible_fields}. The family is NOT a "
            "hardness candidate; the polynomial-time matchgate / holographic-algorithm "
            "route applies."
        )

    return HardnessReport(
        signatures_count=len(sym_sigs),
        fields_tried=fields_tried,
        is_matchgate_realizable_anywhere_tried=any_feasible,
        is_hardness_candidate=is_candidate,
        individual_infeasibility=individual_failures,
        notes=notes,
    )
