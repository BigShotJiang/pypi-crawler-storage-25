"""Form classification + realizability subvarieties on the basis manifold M.

This is v0.2 of the SRP solver. v0.1 (signatures.py) implements Cai-Lu 2011
Theorem 2.5: the *necessary* condition for a symmetric signature to be
realizable on some basis. v0.2 implements the *sufficient* condition piece by
piece: classifying the Form of each realizable signature, building its
realizability subvariety B(sigma) in the basis manifold M = GL_2/~, and
(in intersection.py) intersecting all such subvarieties to decide SRP.

Theoretical setup
=================

The basis manifold M is GL_2(F) modulo the equivalence: rescale each row by
a non-zero scalar, or swap the two rows (Cai-Lu Defn 3.1). M is 2-dimensional.

We work in the open chart

    beta = [[1, u], [1, v]]   with u != v (invertibility).

Here the rows have been rescaled so that the first column is (1, 1)^T. This
covers all bases with both n_0, n_1 != 0; the measure-zero complement is not
needed for SRP feasibility decisions in v0.2.

Form classification (Cai-Lu Theorems 2.3 / 2.4 / 2.5)
------------------------------------------------------

The characteristic polynomial of the linear recurrence
    a*x_k + b*x_(k+1) + c*x_(k+2) = 0
is chi(r) = c*r^2 + b*r + a. Based on its roots:

  * Form 1: two distinct non-zero roots --> realizability subvariety is a
    QUADRATIC CURVE in M.
  * Form 2: repeated non-zero root --> realizability subvariety is a LINE.
  * Form 3: at least one root is zero (or c = 0 / a = 0) --> realizability
    subvariety is a LINE (degenerate quadratic).
  * Degenerate: trivial recurrence (zero signature or arity <= 1) --> the
    signature is trivially realizable on every basis; the subvariety is M.

Realizability subvariety (parity-pullback construction)
--------------------------------------------------------

A symmetric signature sigma is realizable on basis beta as a recognizer iff
the standard-basis pullback

    tau = (beta^{-T})^{otimes n} . sigma                     (*)

is a valid standard-basis symmetric matchgate signature.

Two conditions on tau (Valiant 2008 Propositions 6.1, 6.2 and the Cai-Lu
matchgate identities):

  (A) Matchgate identities: tau satisfies a 2nd-order linear recurrence
      (Theorem 2.5 applied to tau). For symmetric signatures this is the
      complete content of the Grassmann-Plucker identities.
  (B) Parity: tau is supported on either the even-weight entries
      (tau_k = 0 for k odd) or the odd-weight entries (tau_k = 0 for k even).

Condition (A) on tau is automatic once we know sigma satisfies Theorem 2.5,
because the rank of the Hankel matrix is preserved under the symmetric tensor
power action of GL_2 on a symmetric signature. So the realizability
subvariety B(sigma) is cut out by condition (B) alone, evaluated on the
symbolic pullback tau(u, v).

The polynomial form is convenient: identify a symmetric arity-n signature
sigma with the homogeneous polynomial

    P_sigma(s, t) = sum_k  binom(n, k) * sigma_k * s^(n-k) * t^k.

The pullback (*) corresponds to substituting

    s -> s + t,    t -> u*s + v*t

in P_sigma (using the chart beta above; this convention matches the column-
action of beta on dual basis variables). The result is P_tau(s, t), from
which the tau_k are read off as coefficients divided by binomial weights.

Each parity branch contributes ceil((n+1)/2) polynomial equations in (u, v).
The realizability subvariety B(sigma) is the UNION of these two branches
(even-parity AND odd-parity), so SRP intersection must try all 2^N branch
combinations across N signatures.

References
----------
- Valiant, "Holographic Algorithms," SIAM J. Comput. 37(5), 2008,
  Propositions 6.1, 6.2 (realizable arity-2/3 standard signatures).
- Cai & Lu, "Holographic Algorithms: From Art to Science,"
  JCSS 77(1), 2011, Theorems 2.3, 2.4, 2.5 (Form classification),
  Theorem 4.1 (polynomial-time SRP).
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

from sympy import Symbol, symbols, binomial, expand, sqrt, sympify, Matrix
from sympy.polys.polytools import Poly

from .signatures import Signature, Recurrence, find_recurrence


# ---------------------------------------------------------------------------
# Form classification
# ---------------------------------------------------------------------------

class Form(Enum):
    """Cai-Lu classification of realizable symmetric signatures.

    Based on the roots of chi(r) = c*r^2 + b*r + a where (a, b, c) is the
    Theorem 2.5 recurrence.
    """

    FORM_1 = "Form 1"
    """Two distinct non-zero roots. Realizability subvariety is a quadratic curve in M."""

    FORM_2 = "Form 2"
    """Repeated non-zero root. Realizability subvariety is a line in M."""

    FORM_3 = "Form 3"
    """One root zero (or recurrence is linear). Realizability subvariety is a line in M."""

    DEGENERATE = "degenerate"
    """Trivial recurrence (zero signature or arity <= 1). Realizable on all of M."""


@dataclass
class FormClassification:
    """The Cai-Lu Form of a realizable symmetric signature, with its roots."""

    form: Form
    recurrence: Recurrence
    roots: List
    notes: str = ""

    def __repr__(self) -> str:
        roots_str = ", ".join(str(r) for r in self.roots) if self.roots else "-"
        return f"FormClassification({self.form.value}, roots=[{roots_str}], {self.notes})"


def _canonical_recurrence(sig: Signature) -> Optional[Recurrence]:
    """Find the most informative recurrence in the Hankel null space.

    For arity >= 3 with rank-2 Hankel matrix there is a unique recurrence
    (up to scaling). For arity 2 the null space is 2-dimensional and
    find_recurrence may pick a degenerate basis element (e.g., (0, 1, 0))
    that does not reveal the Form. We search the null space for a vector
    where both a and c are non-zero (Form 1 candidate), then fall back.
    """
    n = sig.arity
    if sig.is_zero() or n < 2:
        return Recurrence(0, 0, 0)

    x = sig.values
    rows = [[x[k], x[k + 1], x[k + 2]] for k in range(n - 1)]
    M = Matrix(rows)
    nullspace = M.nullspace()
    if not nullspace:
        return None

    for v in nullspace:
        if v[0] != 0 and v[2] != 0:
            return Recurrence(v[0], v[1], v[2])
    for v in nullspace:
        if v[0] != 0 or v[2] != 0:
            return Recurrence(v[0], v[1], v[2])
    v = nullspace[0]
    return Recurrence(v[0], v[1], v[2])


def classify_form(sig: Signature) -> Optional[FormClassification]:
    """Determine the Cai-Lu Form of a signature, or return None if not realizable.

    Implements Cai-Lu Theorems 2.3 / 2.4 / 2.5. The Form determines the
    geometric shape of B(sigma) in M:
        - Form 1: quadratic curve  (distinct non-zero roots, generic case)
        - Form 2: line             (repeated non-zero root)
        - Form 3: line             (one or both roots zero/infinity)
        - Degenerate: realizable on all of M (zero signature or arity <= 1)

    Method:
        - arity <= 1 or zero signature: Degenerate.
        - arity == 2: distinguish via the discriminant of the binary quadratic
          P_sigma = sigma_0 s^2 + 2 sigma_1 s t + sigma_2 t^2 (the Hankel
          matrix has only one row at arity 2, so the recurrence is non-unique).
        - arity >= 3: canonical recurrence in the Hankel null space (which is
          1-dimensional iff Hankel rank = 2, the generic case for realizable
          arity >= 3), then read off Form from the characteristic polynomial.
    """
    if sig.is_zero() or sig.arity < 2:
        return FormClassification(
            Form.DEGENERATE, Recurrence(0, 0, 0), [],
            "trivial (zero or arity <= 1)",
        )

    if sig.arity == 2:
        return _classify_arity_2(sig)

    # For arity >= 3: check Hankel rank. A rank-1 Hankel means the signature
    # is a pure geometric sequence sigma_k = c r^k (a single tensor power).
    # The null space is 2-dim and the canonical recurrence is non-unique;
    # we handle this as Form 2 (repeated root) directly.
    pure_power = _detect_pure_geometric(sig)
    if pure_power is not None:
        r = pure_power
        rec = Recurrence(r * r, -2 * r, sympify(1))
        return FormClassification(
            Form.FORM_2, rec, [r, r],
            "pure geometric sequence (Hankel rank 1, repeated root)",
        )

    rec = _canonical_recurrence(sig)
    if rec is None:
        return None
    return _classify_from_recurrence(rec)


def _detect_pure_geometric(sig: Signature):
    """Detect sigma_k = c * r^k for some non-zero c, r. Returns r or None.

    A pure tensor-power signature has Hankel rank 1: every adjacent ratio
    sigma_(k+1)/sigma_k equals the same r. Returns None if not pure or if
    sigma_0 = 0 (handled elsewhere).
    """
    x = sig.values
    if x[0] == 0:
        return None
    r = sympify(x[1]) / sympify(x[0])
    for k in range(len(x) - 1):
        if sympify(x[k + 1]) != r * sympify(x[k]):
            return None
    return r


def _classify_arity_2(sig: Signature) -> FormClassification:
    """Form classification for arity-2 signatures.

    The Hankel matrix has only one row, so the recurrence null space is
    2-dimensional and the canonical recurrence alone does not distinguish
    Form 1 from Form 2. We use the discriminant of the binary quadratic
    P_sigma = sigma_0 s^2 + 2 sigma_1 s t + sigma_2 t^2 instead:

        Delta = 4 (sigma_1^2 - sigma_0 sigma_2)

    Delta != 0: two distinct roots (Form 1).
    Delta == 0 and (sigma_0, sigma_2) != (0, 0): repeated finite root (Form 2).
    Delta == 0 and sigma_0 == sigma_2 == 0 and sigma_1 != 0: P = 2 sigma_1 s*t,
        roots at 0 and infinity (Form 3).
    """
    s0, s1, s2 = sig.values
    delta = s1 * s1 - s0 * s2  # discriminant up to factor 4

    if s0 == 0 and s2 == 0 and s1 != 0:
        rec = Recurrence(0, sympify(1), 0)
        return FormClassification(
            Form.FORM_3, rec, [sympify(0)],
            "arity 2, P = sigma_1 * s*t (roots at 0 and infinity)",
        )

    if delta == 0:
        # P_sigma is a perfect square; sigma_k = c r^k with r = sigma_1/sigma_0
        # (or sigma_2/sigma_1 if sigma_0 == 0).
        if s0 != 0:
            r = s1 / s0
        elif s1 != 0:
            r = s2 / s1
        else:
            r = sympify(0)
        # A valid recurrence: r^2 x_k - 2 r x_(k+1) + x_(k+2) = 0.
        rec = Recurrence(r * r, -2 * r, sympify(1))
        return FormClassification(
            Form.FORM_2, rec, [r, r], "arity 2, repeated root (delta = 0)"
        )

    # delta != 0: Form 1 with two distinct roots. Use the canonical recurrence.
    rec = _canonical_recurrence(sig)
    if rec is None:
        return None
    return _classify_from_recurrence(rec)


def _classify_from_recurrence(rec: Recurrence) -> FormClassification:
    """Classify a non-arity-2 signature from its canonical recurrence."""
    a, b, c = sympify(rec.a), sympify(rec.b), sympify(rec.c)

    if a == 0 and b == 0 and c == 0:
        return FormClassification(Form.DEGENERATE, rec, [], "trivial recurrence")

    if a == 0 and c == 0:
        # Recurrence is b * x_(k+1) = 0, i.e., the middle entries of sigma are
        # all zero. P_sigma is c1 s^n + c2 t^n -- two roots at 0 and infinity.
        return FormClassification(
            Form.FORM_3, rec, [sympify(0)],
            "doubly degenerate (a = c = 0, roots at 0 and infinity)",
        )

    if c == 0:
        # b r + a = 0, single root.
        return FormClassification(
            Form.FORM_3, rec, [-a / b], "linear recurrence (c = 0)"
        )

    if a == 0:
        return FormClassification(
            Form.FORM_3, rec, [sympify(0), -b / c], "one root is zero (a = 0)"
        )

    discr = b * b - 4 * a * c
    if discr == 0:
        return FormClassification(
            Form.FORM_2, rec, [-b / (2 * c), -b / (2 * c)],
            "repeated non-zero root",
        )

    r1 = (-b + sqrt(discr)) / (2 * c)
    r2 = (-b - sqrt(discr)) / (2 * c)
    return FormClassification(
        Form.FORM_1, rec, [r1, r2], "two distinct non-zero roots"
    )


# ---------------------------------------------------------------------------
# Realizability subvariety in M
# ---------------------------------------------------------------------------

# Coordinates on the open chart of M.
U = Symbol("u")
V = Symbol("v")


@dataclass
class Subvariety:
    """Realizability subvariety B(sigma) in the (u, v) chart of M.

    The subvariety is the UNION of two parity branches:
        - even-parity: tau_k = 0 for all odd k
        - odd-parity:  tau_k = 0 for all even k
    Each branch is the simultaneous-zero locus of its equation list.

    For SRP intersection we enumerate (2^N) combinations of branches.
    """

    signature: Signature
    even_parity_equations: List
    odd_parity_equations: List
    tau: List = field(default_factory=list)  # raw pullback values for debugging
    is_trivial: bool = False  # signature realizable on all of M

    def branches(self) -> List[Tuple[str, List]]:
        """The parity branches as (label, equations) pairs."""
        return [
            ("even", self.even_parity_equations),
            ("odd", self.odd_parity_equations),
        ]

    def __repr__(self) -> str:
        name = self.signature.name or "<unnamed>"
        if self.is_trivial:
            return f"Subvariety({name}: trivial, B = M)"
        n_even = len(self.even_parity_equations)
        n_odd = len(self.odd_parity_equations)
        return f"Subvariety({name}: {n_even} even-eqs, {n_odd} odd-eqs)"


def _pullback_tau(sig: Signature) -> List:
    """Compute the standard-basis pullback tau of sigma in the chart beta = [[1,u],[1,v]].

    Returns [tau_0, ..., tau_n] as sympy expressions in u, v.
    """
    n = sig.arity
    s = Symbol("_s")
    t = Symbol("_t")
    s2 = Symbol("_s2")
    t2 = Symbol("_t2")

    # P_sigma(s, t) = sum_k binom(n, k) sigma_k s^(n-k) t^k
    P_sigma = sum(
        binomial(n, k) * sig.values[k] * s ** (n - k) * t ** k
        for k in range(n + 1)
    )

    # Pullback: substitute s -> s2 + t2, t -> u s2 + v t2 (simultaneously).
    P_tau_temp = P_sigma.subs([(s, s2 + t2), (t, U * s2 + V * t2)], simultaneous=True)
    P_tau = expand(P_tau_temp.subs({s2: s, t2: t}))

    poly = Poly(P_tau, s, t)
    tau = []
    for k in range(n + 1):
        # Coefficient of s^(n-k) * t^k. Poly.coeff_monomial expects a monomial.
        monom = s ** (n - k) * t ** k
        coef = poly.coeff_monomial(monom)
        tau.append(expand(sympify(coef) / binomial(n, k)))
    return tau


def realizability_subvariety(sig: Signature) -> Subvariety:
    """Build B(sigma) as polynomial equations in (u, v) on the chart of M.

    For non-trivial signatures (arity >= 2, non-zero), computes the pullback
    tau(u, v) and extracts the parity equations:
        - even branch: tau_k(u, v) = 0 for odd k.
        - odd branch:  tau_k(u, v) = 0 for even k.
    A basis (u, v) realizes sigma iff it satisfies one of the two branches.

    For trivial signatures (zero, or arity <= 1), the subvariety is all of M
    and is_trivial=True.
    """
    n = sig.arity
    if n < 2 or sig.is_zero():
        return Subvariety(sig, [], [], tau=[], is_trivial=True)

    tau = _pullback_tau(sig)

    even_eqs = [tau[k] for k in range(1, n + 1, 2)]  # odd k must be zero
    odd_eqs = [tau[k] for k in range(0, n + 1, 2)]   # even k must be zero

    return Subvariety(sig, even_eqs, odd_eqs, tau=tau, is_trivial=False)
