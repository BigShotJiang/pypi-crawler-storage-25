"""holant-tools: decision procedures for matchgate-Holant tractability.

This package implements a polynomial-time decision procedure for whether a set
of matchgate signatures admits a polynomial-time holographic-algorithm route
(Cai-Lu 2011's Simultaneous Realizability Problem, plus extensions). It is
designed as the analysis kernel of a tractability-routing layer that could
sit on top of general-purpose constraint solvers; the kernel itself is the
v0.1 release.

Quick start
-----------

    >>> from holant_tools import from_symmetric, srp_solve
    >>> sigs = [from_symmetric([1, 0, 1], "EQ_2"),
    ...         from_symmetric([0, 1, 1, 1], "OR_3", kind="generator")]
    >>> srp_solve(sigs, modulus=7)
    SRPResult(feasible=True, witness={u: 2, v: 3}, ...)

The above reproduces Cai-Lu 2011 sec 5.1's `#_7 Pl-Rtw-Mon-3CNF` decision:
SRP is feasible over the finite field F_7 with witness basis (u, v) = (2, 3).
The mod-7 phenomenon falls out from the algorithm; it is not configured.

Public API
----------

Constructors:
    from_symmetric(values, name="", kind="recognizer")
    from_non_symmetric(values, arity, name="", kind="recognizer")

Decision procedures:
    srp_solve(signatures, modulus=None)          # full SRP
    hardness_candidate(signatures, primes=...)   # screen for hardness candidates
    is_realizable_somewhere(sig)                 # Cai-Lu Theorem 2.5 (individual)
    classify_form(sig)                           # Cai-Lu Form 1/2/3 classification

Lower-level building blocks:
    realizability_subvariety(sig)                # symmetric
    realizability_subvariety_non_symmetric(sig)  # 2^n-valued
    intersect_subvarieties(subvarieties, modulus=None)

Holant evaluation (genus-g matchgate networks):
    holant_planar(M)                             # FKT planar Pfaffian
    holant_genus_g(matrices, genus)              # Galluccio-Loebl signed sum

CLI: `holant solve`, `holant check`, `holant hardness`, `holant signature`.

Scope
-----

Shipped in v0.1:
- Symmetric matchgate signatures of any arity (Cai-Lu Theorem 2.5 + 4.1).
- Non-symmetric matchgate signatures of arity <= 4, both parity branches,
  with the full Grassmann-Plucker matchgate identities at arity 4.
- Galluccio-Loebl Holant evaluator for genus-g matchgate networks.
- Hardness-candidate screening across Q-bar + small finite fields.
- Single chart of the basis manifold M = GL_2/~.

Not yet shipped (v0.2+ roadmap):
- Non-symmetric arity >= 5 (general Grassmann-Plucker; multiple independent
  matchgate identities per arity).
- Multi-chart coverage of M (second chart for bases with the first row of
  the basis matrix having a zero entry).
- Holant* and Holant^c variants (auxiliary signature seeding).
- Translation layers from SAT / CSP / MILP common formats to Holant
  signatures.
- Automatic Kasteleyn-orientation construction from rotation-system input.

See `docs/holant-tools-theory.md` for the theory and `docs/holant-tools-applications.md` for where Holant
problems show up in practice.

References
----------

[CL11] J.-Y. Cai, P. Lu. *Holographic Algorithms: From Art to Science.*
       J. Comput. Syst. Sci. 77 (1) (2011) 41-61.
[Val08] L. G. Valiant. *Holographic Algorithms.* SIAM J. Comput. 37 (5)
        (2008) 1565-1594.
[GL99] A. Galluccio, M. Loebl. *On the theory of Pfaffian orientations.*
       J. Algebraic Combin. 9 (1999).
"""

__version__ = "0.1.1"

from .signatures import (
    Signature,
    Recurrence,
    find_recurrence,
    is_realizable_somewhere,
    srp_necessary_check,
)
from .realizability import (
    Form,
    FormClassification,
    Subvariety,
    classify_form,
    realizability_subvariety,
    U,
    V,
)
from .intersection import (
    IntersectionResult,
    intersect_subvarieties,
)
from .srp_solver import (
    SRPResult,
    srp_solve,
)
from .holant import (
    pfaffian,
    arf_invariant,
    arf_invariant_genus_1,
    spin_structures_genus,
    holant_genus_g,
    holant_planar,
)
from .non_symmetric import (
    NonSymmetricSignature,
    pullback_tau_non_symmetric,
    realizability_subvariety_non_symmetric,
    matchgate_identity_arity_4_even,
    matchgate_identity_arity_4_odd,
)
from .hardness import (
    HardnessReport,
    hardness_candidate,
)
from .kasteleyn import (
    kasteleyn_orient,
)
from . import examples


# ---------------------------------------------------------------------------
# Ergonomic constructors (the recommended entry points for new users)
# ---------------------------------------------------------------------------

def from_symmetric(values, name="", kind="recognizer"):
    """Construct a symmetric matchgate Signature.

    Args:
        values: iterable of n+1 field values, indexed by Hamming weight.
            For arity n, supply n+1 entries.
        name: optional display name for the signature.
        kind: "recognizer" (default) or "generator".

    Example:
        >>> sig = from_symmetric([1, 0, 1], name="EQ_2")
        >>> sig
        Signature([1, 0, 1], recognizer, arity 2, name='EQ_2')

    Equivalent to `Signature(values=tuple(values), kind=kind, name=name)`.
    """
    return Signature(values=tuple(values), kind=kind, name=name)


def from_non_symmetric(values, arity, name="", kind="recognizer"):
    """Construct a non-symmetric matchgate NonSymmetricSignature.

    Args:
        values: dict mapping bit-string tuples of length `arity` to field values.
            Missing entries default to 0.
        arity: matchgate arity (number of wires).
        name: optional display name.
        kind: "recognizer" (default) or "generator".

    Example:
        >>> # Non-symmetric arity-2: tau_{01} = 1, tau_{10} = -1, rest 0.
        >>> sig = from_non_symmetric({(0, 1): 1, (1, 0): -1}, arity=2, name="asym")
    """
    return NonSymmetricSignature(values=dict(values), arity=arity, kind=kind, name=name)


__all__ = [
    "__version__",
    # Ergonomic constructors
    "from_symmetric",
    "from_non_symmetric",
    # Dataclasses + result types
    "Signature",
    "NonSymmetricSignature",
    "Recurrence",
    "Form",
    "FormClassification",
    "Subvariety",
    "IntersectionResult",
    "SRPResult",
    "HardnessReport",
    "U",
    "V",
    # Decision procedures
    "srp_solve",
    "hardness_candidate",
    "is_realizable_somewhere",
    "classify_form",
    "find_recurrence",
    "srp_necessary_check",
    # Lower-level building blocks
    "realizability_subvariety",
    "realizability_subvariety_non_symmetric",
    "intersect_subvarieties",
    "pullback_tau_non_symmetric",
    "matchgate_identity_arity_4_even",
    "matchgate_identity_arity_4_odd",
    # Holant evaluation
    "pfaffian",
    "arf_invariant",
    "arf_invariant_genus_1",
    "spin_structures_genus",
    "holant_genus_g",
    "holant_planar",
    "kasteleyn_orient",
    # Examples module
    "examples",
]
