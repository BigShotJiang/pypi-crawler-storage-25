"""Top-level SRP (Simultaneous Realizability Problem) solver.

Glues together the v0.2 pieces:
  1. classify_form: Cai-Lu Form of each signature (informational).
  2. realizability_subvariety: build B(sigma_i) in M for each sigma_i.
  3. intersect_subvarieties: decide whether the intersection is non-empty.

The sufficient-condition step that completes Cai-Lu Theorem 4.1.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple

from .signatures import Signature, Recurrence, find_recurrence
from .realizability import (
    FormClassification,
    Subvariety,
    classify_form,
    realizability_subvariety,
)
from .intersection import IntersectionResult, intersect_subvarieties


@dataclass
class SRPResult:
    """Outcome of a full SRP decision."""

    feasible: bool
    witness: Optional[dict] = None
    individual_results: List[Tuple[Signature, Optional[FormClassification]]] = field(
        default_factory=list
    )
    subvarieties: List[Subvariety] = field(default_factory=list)
    intersection: Optional[IntersectionResult] = None
    notes: str = ""

    @property
    def infeasible_signatures(self) -> List[Signature]:
        return [sig for sig, fc in self.individual_results if fc is None]


def srp_solve(
    signatures: Sequence[Signature],
    modulus: Optional[int] = None,
) -> SRPResult:
    """Decide the Simultaneous Realizability Problem (Cai-Lu 2011).

    Args:
        signatures: list of symmetric signatures to be jointly realized.
        modulus: optional finite-field modulus p. If given, search for a
            common basis in F_p; otherwise search over the algebraic closure
            of Q.

    Returns:
        SRPResult with:
            - feasible: True iff all signatures are individually realizable
              AND a common basis exists in M.
            - witness: a basis (u, v) in M realizing all signatures.
            - individual_results: per-signature Form classification (None if
              individually non-realizable).
            - subvarieties: per-signature B(sigma_i).
            - intersection: low-level IntersectionResult.

    A signature that fails Theorem 2.5 (individually non-realizable) makes
    the whole SRP infeasible regardless of basis choice; we short-circuit.
    """
    individual: List[Tuple[Signature, Optional[FormClassification]]] = []
    infeasible_individually: List[Signature] = []
    for sig in signatures:
        fc = classify_form(sig)
        individual.append((sig, fc))
        if fc is None:
            infeasible_individually.append(sig)

    if infeasible_individually:
        names = [s.name or "<unnamed>" for s in infeasible_individually]
        return SRPResult(
            feasible=False,
            individual_results=individual,
            notes=f"individual realizability fails for: {names}",
        )

    subvarieties = [realizability_subvariety(sig) for sig in signatures]
    intersection = intersect_subvarieties(subvarieties, modulus=modulus)

    return SRPResult(
        feasible=intersection.feasible,
        witness=intersection.witness if intersection.feasible else None,
        individual_results=individual,
        subvarieties=subvarieties,
        intersection=intersection,
        notes=intersection.notes,
    )
