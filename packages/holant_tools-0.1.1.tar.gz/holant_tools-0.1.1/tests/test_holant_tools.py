"""Smoke tests for holant-tools.

Run as:
    python -m pytest tests/
or:
    python tests/test_holant_tools.py
"""

from sympy import sympify, simplify, sqrt, I, expand, Matrix, Symbol, symbols

from holant_tools.signatures import (
    Signature,
    find_recurrence,
    is_realizable_somewhere,
    srp_necessary_check,
)
from holant_tools.realizability import (
    Form,
    classify_form,
    realizability_subvariety,
    U,
    V,
)
from holant_tools.intersection import intersect_subvarieties
from holant_tools.srp_solver import srp_solve
from holant_tools.holant import (
    pfaffian,
    arf_invariant,
    arf_invariant_genus_1,
    spin_structures_genus,
    holant_genus_g,
    holant_planar,
)
from holant_tools.non_symmetric import (
    NonSymmetricSignature,
    pullback_tau_non_symmetric,
    realizability_subvariety_non_symmetric,
    matchgate_identity_arity_4_even,
    matchgate_identity_arity_4_odd,
)
from holant_tools.hardness import hardness_candidate, HardnessReport
from holant_tools import examples


def test_eq_2_realizable():
    """[1, 0, 1] satisfies a*x_0 + b*x_1 + c*x_2 = 0  =>  a + c = 0."""
    sig = examples.EQUALITY_2_REC
    rec = find_recurrence(sig)
    assert rec is not None, "EQ_2 should be realizable"
    assert rec.a + rec.c == 0, f"Expected a + c = 0, got {rec}"
    print(f"  test_eq_2_realizable: OK ({rec})")


def test_or_3_realizable():
    """[0, 1, 1, 1] satisfies a recurrence: a*0+b*1+c*1=0, a*1+b*1+c*1=0, a*1+b*1+c*1=0."""
    sig = examples.OR_k_GEN(3)
    rec = find_recurrence(sig)
    assert rec is not None, "OR_3 should be realizable"
    print(f"  test_or_3_realizable: OK ({rec})")


def test_nae_3_realizable():
    """[0, 1, 1, 0] satisfies recurrence (1, -1, 1): x_k - x_{k+1} + x_{k+2} = 0."""
    sig = examples.NAE_k(3)
    rec = find_recurrence(sig)
    assert rec is not None, "NAE_3 should be realizable"
    print(f"  test_nae_3_realizable: OK ({rec})")


def test_non_realizable_caught():
    """A signature where the only recurrence is trivial."""
    sig = examples.NON_REALIZABLE_EXAMPLE
    rec = find_recurrence(sig)
    assert rec is None, f"Expected non-realizable, got {rec}"
    print(f"  test_non_realizable_caught: OK")


def test_zero_signature_trivially_realizable():
    """A zero signature is trivially realizable on any basis."""
    sig = Signature((0, 0, 0, 0), "recognizer", "zero")
    assert is_realizable_somewhere(sig), "Zero signature should be realizable"
    print("  test_zero_signature_trivially_realizable: OK")


def test_srp_necessary_check_cai_lu_5_1():
    """The signatures from Cai-Lu sec. 5.1 each pass individual realizability."""
    sigs = [examples.EQUALITY_2_REC, examples.OR_k_GEN(3)]
    result = srp_necessary_check(sigs)
    assert result["feasible_necessary"], (
        f"Expected pass; got infeasible {result['infeasible_signatures']}"
    )
    print(f"  test_srp_necessary_check_cai_lu_5_1: OK ({len(sigs)} sigs, all realizable)")


def test_srp_necessary_check_with_non_realizable():
    """Mixing realizable and non-realizable: should report failure."""
    sigs = [examples.EQUALITY_2_REC, examples.NON_REALIZABLE_EXAMPLE]
    result = srp_necessary_check(sigs)
    assert not result["feasible_necessary"], "Mixed set should fail necessary check"
    assert len(result["infeasible_signatures"]) == 1
    print("  test_srp_necessary_check_with_non_realizable: OK")


# ---------------------------------------------------------------------------
# v0.2 tests: Form classification
# ---------------------------------------------------------------------------


def test_form_eq_2_is_form_1():
    """EQ_2 = [1, 0, 1]: Form 1 with roots {1, -1}."""
    fc = classify_form(examples.EQUALITY_2_REC)
    assert fc is not None
    assert fc.form == Form.FORM_1
    roots = sorted(fc.roots, key=lambda r: float(r) if r.is_real else 99)
    assert sympify(roots[0]) == -1 and sympify(roots[1]) == 1, f"roots {roots}"
    print(f"  test_form_eq_2_is_form_1: OK ({fc})")


def test_form_or_3_is_form_3():
    """OR_3 = [0, 1, 1, 1]: Form 3 (root zero, a = 0)."""
    fc = classify_form(examples.OR_k_GEN(3))
    assert fc is not None
    assert fc.form == Form.FORM_3
    assert sympify(0) in fc.roots, f"expected 0 in roots, got {fc.roots}"
    print(f"  test_form_or_3_is_form_3: OK ({fc})")


def test_form_nae_3_is_form_1_complex():
    """NAE_3 = [0, 1, 1, 0]: Form 1 with primitive 6th roots of unity."""
    fc = classify_form(examples.NAE_k(3))
    assert fc is not None
    assert fc.form == Form.FORM_1
    expected = {sympify("1/2") + I * sqrt(3) / 2, sympify("1/2") - I * sqrt(3) / 2}
    got = {simplify(r) for r in fc.roots}
    assert got == expected, f"roots {got} != {expected}"
    print(f"  test_form_nae_3_is_form_1_complex: OK ({fc})")


def test_form_pure_geometric_is_form_2():
    """[1, 2, 4, 8, 16]: pure geometric sequence, Form 2 with repeated root r=2."""
    sig = Signature(values=(1, 2, 4, 8, 16), name="geom-r2")
    fc = classify_form(sig)
    assert fc is not None and fc.form == Form.FORM_2
    assert sympify(fc.roots[0]) == 2
    print(f"  test_form_pure_geometric_is_form_2: OK ({fc})")


def test_form_doubly_degenerate():
    """EQ_3 = [1, 0, 0, 1]: Form 3 with doubly-degenerate recurrence (a = c = 0)."""
    fc = classify_form(examples.EQUALITY_3_REC)
    assert fc is not None and fc.form == Form.FORM_3
    print(f"  test_form_doubly_degenerate: OK ({fc})")


def test_form_non_realizable_is_none():
    fc = classify_form(examples.NON_REALIZABLE_EXAMPLE)
    assert fc is None
    print("  test_form_non_realizable_is_none: OK")


# ---------------------------------------------------------------------------
# v0.2 tests: realizability subvariety
# ---------------------------------------------------------------------------


def test_subvariety_eq_2_equations():
    """EQ_2 = [1, 0, 1] subvariety: even-parity {uv + 1 = 0}, odd-parity {u^2 + 1 = 0, v^2 + 1 = 0}."""
    sv = realizability_subvariety(examples.EQUALITY_2_REC)
    assert not sv.is_trivial
    # Even parity: one equation, should be u*v + 1.
    assert len(sv.even_parity_equations) == 1
    assert simplify(sv.even_parity_equations[0] - (U * V + 1)) == 0
    # Odd parity: two equations.
    assert len(sv.odd_parity_equations) == 2
    expected_odd = {U * U + 1, V * V + 1}
    got_odd = {simplify(eq) for eq in sv.odd_parity_equations}
    assert got_odd == expected_odd, f"got {got_odd}, expected {expected_odd}"
    print("  test_subvariety_eq_2_equations: OK")


def test_subvariety_or_3_tau_3_is_v_cubed_form():
    """OR_3 even-parity tau_3 = v^3 + 3v^2 + 3v = (1+v)^3 - 1."""
    sv = realizability_subvariety(examples.OR_k_GEN(3))
    # tau_3 is one of the even-parity equations.
    expected = V * V * V + 3 * V * V + 3 * V  # = (1+v)^3 - 1
    found = any(simplify(eq - expected) == 0 for eq in sv.even_parity_equations)
    assert found, f"could not find (1+v)^3 - 1 in {sv.even_parity_equations}"
    print("  test_subvariety_or_3_tau_3_is_v_cubed_form: OK")


def test_subvariety_zero_signature_trivial():
    sig = Signature(values=(0, 0, 0, 0), kind="recognizer", name="zero")
    sv = realizability_subvariety(sig)
    assert sv.is_trivial
    print("  test_subvariety_zero_signature_trivial: OK")


# ---------------------------------------------------------------------------
# v0.2 tests: intersection (full SRP)
# ---------------------------------------------------------------------------


def test_srp_cai_lu_5_1_feasible_mod_7():
    """Cai-Lu sec 5.1 SRP feasible over F_7 with witness (u, v) = (2, 3)."""
    sigs = [examples.EQUALITY_2_REC, examples.OR_k_GEN(3)]
    result = srp_solve(sigs, modulus=7)
    assert result.feasible, f"expected feasible, got {result}"
    u_val, v_val = result.witness[U], result.witness[V]
    # Either order: (2, 3) or (3, 2) since (u, v) ~ (v, u) on M.
    assert {int(u_val), int(v_val)} == {2, 3}, f"witness {result.witness}"
    print(f"  test_srp_cai_lu_5_1_feasible_mod_7: OK (witness u={u_val}, v={v_val})")


def test_srp_cai_lu_5_1_infeasible_over_Q():
    """Cai-Lu sec 5.1 SRP infeasible over algebraic closure of Q."""
    sigs = [examples.EQUALITY_2_REC, examples.OR_k_GEN(3)]
    result = srp_solve(sigs)
    assert not result.feasible, f"expected infeasible over Q-bar, got {result}"
    print("  test_srp_cai_lu_5_1_infeasible_over_Q: OK")


def test_srp_cai_lu_5_1_infeasible_mod_5():
    """Cai-Lu sec 5.1 SRP infeasible over F_5 (mod 7 is needed for cube roots)."""
    sigs = [examples.EQUALITY_2_REC, examples.OR_k_GEN(3)]
    result = srp_solve(sigs, modulus=5)
    assert not result.feasible
    print("  test_srp_cai_lu_5_1_infeasible_mod_5: OK")


def test_srp_short_circuits_on_individual_infeasibility():
    """If any sigma fails Theorem 2.5, srp_solve short-circuits."""
    sigs = [examples.EQUALITY_2_REC, examples.NON_REALIZABLE_EXAMPLE]
    result = srp_solve(sigs)
    assert not result.feasible
    assert len(result.infeasible_signatures) == 1
    print("  test_srp_short_circuits_on_individual_infeasibility: OK")


def test_srp_eq_2_alone_feasible_over_Q():
    """A single realizable signature has a non-empty B(sigma); SRP feasible."""
    result = srp_solve([examples.EQUALITY_2_REC])
    assert result.feasible
    u_val = result.witness[U]
    v_val = result.witness[V]
    # Witness should lie on one of the parity branches: uv + 1 = 0 or u^2 + 1 = v^2 + 1 = 0.
    branch = result.intersection.branch_combination[0]
    if branch == "even":
        assert simplify(u_val * v_val + 1) == 0
    else:
        assert simplify(u_val * u_val + 1) == 0
        assert simplify(v_val * v_val + 1) == 0
    print(f"  test_srp_eq_2_alone_feasible_over_Q: OK (witness u={u_val}, v={v_val}, branch={branch})")


def test_srp_empty_signature_list_feasible():
    """SRP with no signatures is vacuously feasible."""
    result = srp_solve([])
    assert result.feasible
    print("  test_srp_empty_signature_list_feasible: OK")


# ---------------------------------------------------------------------------
# v0.3-alpha tests: Pfaffian + Arf + Holant evaluator (bounded-genus layer)
# ---------------------------------------------------------------------------


def test_pfaffian_2x2():
    """Pf of a 2x2 antisymmetric matrix is its off-diagonal entry."""
    a = Symbol("a")
    M = Matrix([[0, a], [-a, 0]])
    assert pfaffian(M) == a
    print(f"  test_pfaffian_2x2: OK (Pf = {pfaffian(M)})")


def test_pfaffian_4x4_formula():
    """Pf of generic 4x4: M[0,1]*M[2,3] - M[0,2]*M[1,3] + M[0,3]*M[1,2]."""
    a, b, c, d, e, f = symbols("a b c d e f")
    M = Matrix([[0, a, b, c], [-a, 0, d, e], [-b, -d, 0, f], [-c, -e, -f, 0]])
    pf = pfaffian(M)
    expected = a * f - b * e + c * d
    assert simplify(pf - expected) == 0
    print(f"  test_pfaffian_4x4_formula: OK")


def test_pfaffian_squared_equals_det():
    """Pf(M)^2 = det(M) for antisymmetric M."""
    a, b, c, d, e, f = symbols("a b c d e f")
    M = Matrix([[0, a, b, c], [-a, 0, d, e], [-b, -d, 0, f], [-c, -e, -f, 0]])
    assert simplify(pfaffian(M) ** 2 - M.det()) == 0
    print("  test_pfaffian_squared_equals_det: OK")


def test_pfaffian_odd_dim_is_zero():
    M = Matrix([[0, 1, 2], [-1, 0, 3], [-2, -3, 0]])
    assert pfaffian(M) == 0
    print("  test_pfaffian_odd_dim_is_zero: OK")


def test_pfaffian_4_cycle_planar():
    """The 4-cycle (1-2-3-4-1) as a planar matchgrid: Pf = 2 (two perfect matchings)."""
    M = Matrix([
        [0, 1, 0, 1],
        [-1, 0, 1, 0],
        [0, -1, 0, 1],
        [-1, 0, -1, 0],
    ])
    assert pfaffian(M) == 2
    print(f"  test_pfaffian_4_cycle_planar: OK (Pf = 2 = PerfMatch(C_4))")


def test_arf_invariant_genus_0():
    assert arf_invariant(()) == 1
    print("  test_arf_invariant_genus_0: OK")


def test_arf_invariant_genus_1():
    """Three even (sign +1) and one odd (sign -1)."""
    assert arf_invariant_genus_1((0, 0)) == 1
    assert arf_invariant_genus_1((0, 1)) == 1
    assert arf_invariant_genus_1((1, 0)) == 1
    assert arf_invariant_genus_1((1, 1)) == -1
    print("  test_arf_invariant_genus_1: OK (3 even, 1 odd)")


def test_arf_invariant_genus_2_count():
    """Genus 2: 10 even and 6 odd spin structures (the +1/-1 count formula)."""
    sigs = spin_structures_genus(2)
    assert len(sigs) == 16
    plus = sum(1 for t in sigs if arf_invariant(t) == 1)
    minus = sum(1 for t in sigs if arf_invariant(t) == -1)
    # 2^{g-1}(2^g + 1) even = 2*5 = 10; 2^{g-1}(2^g - 1) odd = 2*3 = 6.
    assert plus == 10 and minus == 6
    print(f"  test_arf_invariant_genus_2_count: OK ({plus} even, {minus} odd)")


def test_spin_structures_count():
    for g in range(4):
        assert len(spin_structures_genus(g)) == max(1, 4 ** g)
    print("  test_spin_structures_count: OK")


def test_holant_planar_is_pfaffian():
    """Genus-0 Holant equals a single Pfaffian (FKT)."""
    M = Matrix([[0, 1, 0, 1], [-1, 0, 1, 0], [0, -1, 0, 1], [-1, 0, -1, 0]])
    assert holant_planar(M) == pfaffian(M)
    holant = holant_genus_g({(): M}, genus=0)
    assert holant == pfaffian(M)
    print("  test_holant_planar_is_pfaffian: OK")


def test_holant_genus_1_identical_matrices_collapses_to_pfaffian():
    """If all 4 matrices are identical, Holant = (1/2)(1+1+1-1) Pf = Pf."""
    M = Matrix([[0, 1, 0, 1], [-1, 0, 1, 0], [0, -1, 0, 1], [-1, 0, -1, 0]])
    matrices = {theta: M for theta in spin_structures_genus(1)}
    h = holant_genus_g(matrices, genus=1)
    assert h == pfaffian(M)
    print(f"  test_holant_genus_1_identical_matrices_collapses_to_pfaffian: OK (h = {h})")


def test_holant_genus_1_formula_structure():
    """Symbolic structural check: Holant = (1/2)(Pf_00 + Pf_01 + Pf_10 - Pf_11)."""
    p00, p01, p10, p11 = symbols("p00 p01 p10 p11")
    # 2x2 antisymmetric matrices with Pf = each symbol.
    M = lambda p: Matrix([[0, p], [-p, 0]])
    matrices = {(0, 0): M(p00), (0, 1): M(p01), (1, 0): M(p10), (1, 1): M(p11)}
    h = holant_genus_g(matrices, genus=1)
    expected = (p00 + p01 + p10 - p11) / 2
    assert simplify(h - expected) == 0
    print(f"  test_holant_genus_1_formula_structure: OK")


def test_holant_genus_g_rejects_wrong_keys():
    """holant_genus_g raises if matrices dict does not have the right spin structures."""
    M = Matrix([[0, 1], [-1, 0]])
    try:
        holant_genus_g({(0, 0): M, (0, 1): M}, genus=1)  # missing (1,0), (1,1)
        assert False, "expected ValueError"
    except ValueError:
        pass
    print("  test_holant_genus_g_rejects_wrong_keys: OK")


# ---------------------------------------------------------------------------
# v0.3-beta tests: non-symmetric matchgate signatures
# ---------------------------------------------------------------------------


def test_non_sym_symmetric_reduction_matches_v0_2():
    """Non-symmetric EQ_2 as (1,0,0,1) reduces to v0.2 EQ_2."""
    from holant_tools.realizability import realizability_subvariety
    nsym = NonSymmetricSignature(values={(0, 0): 1, (1, 1): 1}, arity=2, name="EQ_2-non-sym")
    assert nsym.is_symmetric()
    sv_nsym = realizability_subvariety_non_symmetric(nsym)
    sv_sym = realizability_subvariety(examples.EQUALITY_2_REC)

    # Even-parity: nsym has two equations (tau_{01}, tau_{10}) that are equal symbolically;
    # symmetric version has one (uv + 1). Verify they describe the same locus by checking
    # that both nsym even-eqs reduce to uv + 1.
    for eq in sv_nsym.even_parity_equations:
        assert simplify(eq - (U * V + 1)) == 0, f"got {eq}, expected u*v + 1"
    # Odd-parity equations: should match {u^2+1, v^2+1} (with possibly an extra at index (0,0)).
    nsym_odd = {simplify(e) for e in sv_nsym.odd_parity_equations}
    expected_odd = {U * U + 1, V * V + 1}
    assert expected_odd.issubset(nsym_odd) or nsym_odd == expected_odd
    print("  test_non_sym_symmetric_reduction_matches_v0_2: OK")


def test_non_sym_balanced_asymmetric_arity_2_feasible():
    """(0, 1, -1, 0) is feasible via odd-parity branch in our chart (x + y = 0)."""
    sig = NonSymmetricSignature(values={(0, 1): 1, (1, 0): -1}, arity=2, name="bal-asym")
    assert not sig.is_symmetric()
    sv = realizability_subvariety_non_symmetric(sig)
    res = intersect_subvarieties([sv])
    assert res.feasible, f"expected feasible, got {res}"
    print(f"  test_non_sym_balanced_asymmetric_arity_2_feasible: OK (witness u={res.witness[U]}, v={res.witness[V]})")


def test_non_sym_unbalanced_asymmetric_arity_2_chart_limitation():
    """(0, 2, 3, 0): x + y != 0; realising basis is outside our chart (documented limitation)."""
    sig = NonSymmetricSignature(values={(0, 1): 2, (1, 0): 3}, arity=2, name="unbal-asym")
    sv = realizability_subvariety_non_symmetric(sig)
    res = intersect_subvarieties([sv])
    # Per NON_SYMMETRIC.md, this case is "realisable but outside chart".
    # The prototype correctly reports infeasibility in this chart; full coverage needs chart 2.
    assert not res.feasible
    print(f"  test_non_sym_unbalanced_asymmetric_arity_2_chart_limitation: OK (chart-miss as designed)")


def test_non_sym_is_symmetric_detection():
    """is_symmetric correctly distinguishes symmetric vs non-symmetric input."""
    sym = NonSymmetricSignature(values={(0, 0): 1, (1, 1): 1}, arity=2)
    assert sym.is_symmetric()
    asym = NonSymmetricSignature(values={(0, 1): 1, (1, 0): -1}, arity=2)
    assert not asym.is_symmetric()
    print("  test_non_sym_is_symmetric_detection: OK")


def test_non_sym_arity_3_pullback_structure():
    """Valiant 6.2 case 1 (uniform x=y=z=t=1) is symmetric; arity-3 pullback is correct."""
    sig = NonSymmetricSignature(
        values={(0, 0, 1): 1, (0, 1, 0): 1, (1, 0, 0): 1, (1, 1, 1): 1},
        arity=3,
        name="V6.2-uniform",
    )
    assert sig.is_symmetric()
    tau = pullback_tau_non_symmetric(sig)
    # tau_{(1,1,1)} = (1+u)^? -- check against the v0.2 OR_3-style formula.
    # For sigma = (0,1,1,1) symmetric, tau_{(1,1,1)} comes from the v=1 corner: v^3 + 3v.
    assert simplify(tau[(1, 1, 1)] - (V ** 3 + 3 * V)) == 0
    print("  test_non_sym_arity_3_pullback_structure: OK")


# ---------------------------------------------------------------------------
# v0.3-beta-followon tests: arity-4 matchgate identity (Grassmann-Plücker)
# ---------------------------------------------------------------------------


def test_matchgate_identity_pf_4x4_self_consistency():
    """The arity-4 identity polynomial agrees with the 4x4 Pfaffian identity."""
    from sympy import symbols, Matrix
    from holant_tools.holant import pfaffian

    a, b, c, d, e, f = symbols("a b c d e f")
    M = Matrix([[0, a, b, c], [-a, 0, d, e], [-b, -d, 0, f], [-c, -e, -f, 0]])
    # tau indexed by S = "indices in the 2-element submatrix":
    # tau_{1100} = Pf({1,2}) = a, tau_{0011} = Pf({3,4}) = f, etc.
    # tau_{0000} (empty Pfaffian) = 1, tau_{1111} = Pf(full) = pfaffian(M).
    tau = {
        (0, 0, 0, 0): 1,
        (1, 1, 1, 1): pfaffian(M),
        (1, 1, 0, 0): a, (0, 0, 1, 1): f,
        (1, 0, 1, 0): b, (0, 1, 0, 1): e,
        (1, 0, 0, 1): c, (0, 1, 1, 0): d,
    }
    mg = matchgate_identity_arity_4_even(tau)
    assert simplify(mg) == 0, f"identity polynomial should vanish on the 4x4 Pfaffian; got {simplify(mg)}"
    print("  test_matchgate_identity_pf_4x4_self_consistency: OK")


def test_arity_4_symmetric_reduction_matches_v0_2():
    """Non-symmetric path on symmetric arity-4 EQ_4 agrees with v0.2 path."""
    from holant_tools.realizability import realizability_subvariety
    weights = {0: 1, 1: 0, 2: 0, 3: 0, 4: 1}
    values = {tuple((mask >> i) & 1 for i in range(4)): weights[bin(mask).count("1")] for mask in range(16)}
    nsym = NonSymmetricSignature(values=values, arity=4, name="EQ_4-non-sym")
    assert nsym.is_symmetric()
    sv_n = realizability_subvariety_non_symmetric(nsym)
    res_n = intersect_subvarieties([sv_n])

    sym = Signature(values=(1, 0, 0, 0, 1), kind="recognizer", name="EQ_4")
    sv_s = realizability_subvariety(sym)
    res_s = intersect_subvarieties([sv_s])

    assert res_n.feasible == res_s.feasible
    if res_n.feasible:
        # Both should find a witness on the even branch.
        assert res_n.branch_combination[0] == res_s.branch_combination[0]
    print(f"  test_arity_4_symmetric_reduction_matches_v0_2: OK (both feasible)")


def test_matchgate_identity_arity_4_odd_pf_self_consistency():
    """Odd-parity arity-4 identity vanishes on augmented-Pfaffian construction.

    Build a generic 5x5 skew matrix on indices {1,2,3,4,omega}. Each odd-parity
    tau_b is the Pfaffian on the complement of S(b) in {1,2,3,4,omega} (including
    omega), which has even cardinality. Verify the identity polynomial vanishes
    identically -- this is the derivation that anchors the augmented-Pfaffian
    matchgate identity.
    """
    from sympy import symbols, Matrix
    from holant_tools.holant import pfaffian

    a, b, c, p, d, e, q, f, r, s = symbols("a b c p d e q f r s")
    M = Matrix([
        [0,  a,  b,  c,  p],
        [-a, 0,  d,  e,  q],
        [-b, -d, 0,  f,  r],
        [-c, -e, -f, 0,  s],
        [-p, -q, -r, -s, 0],
    ])

    # tau_b for odd weight b: Pf on complement of S(b) in {1,2,3,4,omega} (= cols not in S(b), plus omega).
    # weight-1 entries (Pfaffian on 4 elements):
    tau = {
        (1, 0, 0, 0): pfaffian(M[[1, 2, 3, 4], [1, 2, 3, 4]]),  # complement {2,3,4,omega}
        (0, 1, 0, 0): pfaffian(M[[0, 2, 3, 4], [0, 2, 3, 4]]),  # complement {1,3,4,omega}
        (0, 0, 1, 0): pfaffian(M[[0, 1, 3, 4], [0, 1, 3, 4]]),  # complement {1,2,4,omega}
        (0, 0, 0, 1): pfaffian(M[[0, 1, 2, 4], [0, 1, 2, 4]]),  # complement {1,2,3,omega}
        # weight-3 entries (Pfaffian on 2 elements):
        (0, 1, 1, 1): pfaffian(M[[0, 4], [0, 4]]),  # complement {1,omega}
        (1, 0, 1, 1): pfaffian(M[[1, 4], [1, 4]]),  # complement {2,omega}
        (1, 1, 0, 1): pfaffian(M[[2, 4], [2, 4]]),  # complement {3,omega}
        (1, 1, 1, 0): pfaffian(M[[3, 4], [3, 4]]),  # complement {4,omega}
    }
    identity = matchgate_identity_arity_4_odd(tau)
    assert simplify(identity) == 0, f"identity should vanish; got {simplify(identity)}"
    print("  test_matchgate_identity_arity_4_odd_pf_self_consistency: OK")


def test_matchgate_identity_arity_4_odd_vacuous_on_symmetric():
    """Odd-parity identity vanishes identically when the pullback is symmetric.

    For a symmetric arity-4 signature, all 4 weight-1 entries of the pullback equal
    some tau_1(u,v) and all 4 weight-3 entries equal some tau_3(u,v). The identity

        tau_1000 * tau_0111 - tau_0100 * tau_1011 + tau_0010 * tau_1101 - tau_0001 * tau_1110

    becomes tau_1 * tau_3 - tau_1 * tau_3 + tau_1 * tau_3 - tau_1 * tau_3 = 0 — trivially
    satisfied for any tau_1, tau_3. So the odd-parity identity imposes no constraint on
    symmetric signatures. (This is why v0.2's symmetric path never needed it.)
    """
    weights = {0: 0, 1: 1, 2: 1, 3: 1, 4: 0}  # symmetric NAE_4-shape
    values = {tuple((mask >> i) & 1 for i in range(4)): weights[bin(mask).count("1")] for mask in range(16)}
    nsym = NonSymmetricSignature(values=values, arity=4)
    tau = pullback_tau_non_symmetric(nsym)
    identity_poly = simplify(matchgate_identity_arity_4_odd(tau))
    assert identity_poly == 0, f"expected identically zero on symmetric, got {identity_poly}"
    print("  test_matchgate_identity_arity_4_odd_vacuous_on_symmetric: OK (identity = 0 identically)")


def test_matchgate_identity_arity_4_odd_distinguishes_asymmetric_cases():
    """Constructive positive + negative test.

    Positive: a matchgate-realizable asymmetric arity-4 odd-parity signature,
    constructed from a 5x5 augmented skew matrix; the identity must hold by
    construction.

    Negative: perturb one entry of the positive example so the identity fails;
    confirm the identity polynomial detects the violation.
    """
    # Constructed from M with augmented row/col omega having entries (1, 2, 3, 4):
    # tau_{1000} = 0, tau_{0100} = 0, tau_{0010} = 4, tau_{0001} = 3,
    # tau_{0111} = 1, tau_{1011} = 2, tau_{1101} = 3, tau_{1110} = 4.
    tau_realizable = {
        (1, 0, 0, 0): 0, (0, 1, 0, 0): 0, (0, 0, 1, 0): 4, (0, 0, 0, 1): 3,
        (0, 1, 1, 1): 1, (1, 0, 1, 1): 2, (1, 1, 0, 1): 3, (1, 1, 1, 0): 4,
    }
    tau_realizable = {b: sympify(v) for b, v in tau_realizable.items()}
    weight_1_vals = {tau_realizable[b] for b in tau_realizable if sum(b) == 1}
    assert len(weight_1_vals) > 1, "test setup: signature must be asymmetric"
    id_val = matchgate_identity_arity_4_odd(tau_realizable)
    assert id_val == 0, f"identity should vanish on realizable; got {id_val}"

    # Perturb tau_0001 from 3 to 5: identity now reads 0*1 - 0*2 + 4*3 - 5*4 = -8.
    tau_violating = dict(tau_realizable)
    tau_violating[(0, 0, 0, 1)] = sympify(5)
    id_val_bad = matchgate_identity_arity_4_odd(tau_violating)
    assert id_val_bad != 0, f"identity should detect violation; got {id_val_bad}"
    assert id_val_bad == -8
    print(f"  test_matchgate_identity_arity_4_odd_distinguishes_asymmetric_cases: OK (realizable=0, perturbed={id_val_bad})")


def test_arity_4_v0_2_rejected_also_rejected_via_non_sym():
    """A symmetric arity-4 [1,1,1,0,1] that v0.2 rejects (no recurrence) is also rejected on the non-symmetric path."""
    sym = Signature(values=(1, 1, 1, 0, 1), kind="recognizer", name="rec-fail")
    assert find_recurrence(sym) is None, "v0.2 prerequisite: should have no recurrence"

    weights = {0: 1, 1: 1, 2: 1, 3: 0, 4: 1}
    values = {tuple((mask >> i) & 1 for i in range(4)): weights[bin(mask).count("1")] for mask in range(16)}
    nsym = NonSymmetricSignature(values=values, arity=4)
    sv = realizability_subvariety_non_symmetric(nsym)
    res = intersect_subvarieties([sv])
    assert not res.feasible
    print("  test_arity_4_v0_2_rejected_also_rejected_via_non_sym: OK")


def test_arity_4_matchgate_identity_reduces_for_symmetric_eq4():
    """For symmetric EQ_4 pullback, matchgate identity reduces to (u^2 - v^2)^2."""
    weights = {0: 1, 1: 0, 2: 0, 3: 0, 4: 1}
    values = {tuple((mask >> i) & 1 for i in range(4)): weights[bin(mask).count("1")] for mask in range(16)}
    nsym = NonSymmetricSignature(values=values, arity=4)
    tau = pullback_tau_non_symmetric(nsym)
    mg = simplify(matchgate_identity_arity_4_even(tau))
    expected = (U * U - V * V) ** 2
    assert simplify(mg - expand(expected)) == 0, f"got {mg}, expected {expand(expected)}"
    print(f"  test_arity_4_matchgate_identity_reduces_for_symmetric_eq4: OK")


# ---------------------------------------------------------------------------
# Hardness recognition tests
# ---------------------------------------------------------------------------


def test_hardness_cai_lu_5_1_not_a_candidate():
    """Cai-Lu sec 5.1 is matchgate-realisable over F_7; not a hardness candidate."""
    sigs = [examples.EQUALITY_2_REC, examples.OR_k_GEN(3)]
    report = hardness_candidate(sigs)
    assert not report.is_hardness_candidate
    assert report.is_matchgate_realizable_anywhere_tried
    # Should be feasible specifically over F_7.
    feasible_fields = [f for f, ok, _ in report.fields_tried if ok]
    assert "F_7" in feasible_fields
    print(f"  test_hardness_cai_lu_5_1_not_a_candidate: OK (realisable on {feasible_fields})")


def test_hardness_individual_infeasibility_short_circuits():
    """A family containing a Theorem-2.5-infeasible signature short-circuits."""
    sigs = [examples.NON_REALIZABLE_EXAMPLE]
    report = hardness_candidate(sigs)
    assert not report.is_hardness_candidate  # not a genuine hardness candidate
    assert not report.is_matchgate_realizable_anywhere_tried  # trivially
    assert len(report.individual_infeasibility) == 1
    print("  test_hardness_individual_infeasibility_short_circuits: OK")


def test_hardness_single_signature_simple_realisable():
    """EQ_2 alone is matchgate-realisable in Q-bar."""
    sigs = [examples.EQUALITY_2_REC]
    report = hardness_candidate(sigs)
    assert not report.is_hardness_candidate
    assert report.is_matchgate_realizable_anywhere_tried
    # Should be feasible over Q-bar (any uv = -1 basis works).
    q_bar_result = [ok for f, ok, _ in report.fields_tried if f == "Q-bar"]
    assert q_bar_result and q_bar_result[0]
    print("  test_hardness_single_signature_simple_realisable: OK")


def test_hardness_modulus_only_realisability():
    """A family realisable only on a specific finite field (mod-7 phenomenon)."""
    # Cai-Lu sec 5.1 is the canonical example.
    sigs = [examples.EQUALITY_2_REC, examples.OR_k_GEN(3)]
    report = hardness_candidate(sigs, primes_to_try=[2, 3, 5])
    # Without F_7 in the list, this should be reported as hardness candidate (a false positive).
    # This test documents the limitation honestly.
    assert report.is_hardness_candidate, (
        "Without F_7, this family looks like a hardness candidate -- "
        "documenting the limitation that the screen is sensitive to the prime list."
    )
    print("  test_hardness_modulus_only_realisability: OK (limitation documented)")


# ---------------------------------------------------------------------------
# Kasteleyn orientation tests (v0.1.1 -- automatic construction from rotation system)
# ---------------------------------------------------------------------------


from holant_tools.kasteleyn import kasteleyn_orient


def test_kasteleyn_c4():
    """C_4 (= K_{2,2}) has 2 perfect matchings; auto-constructed orientation gives |Pf| = 2."""
    vertices = [1, 2, 3, 4]
    edges = [(1, 2), (2, 3), (3, 4), (4, 1)]
    rotation = {1: [2, 4], 2: [3, 1], 3: [4, 2], 4: [1, 3]}
    M = kasteleyn_orient(vertices, edges, rotation)
    assert abs(pfaffian(M)) == 2
    print(f"  test_kasteleyn_c4: OK (|Pf| = 2)")


def test_kasteleyn_k4():
    """K_4 (planar embedding with vertex 4 inside triangle 1-2-3); 3 perfect matchings."""
    vertices = [1, 2, 3, 4]
    edges = [(1, 2), (2, 3), (3, 1), (1, 4), (2, 4), (3, 4)]
    rotation = {1: [2, 4, 3], 2: [3, 4, 1], 3: [1, 4, 2], 4: [1, 2, 3]}
    M = kasteleyn_orient(vertices, edges, rotation)
    assert abs(pfaffian(M)) == 3
    print(f"  test_kasteleyn_k4: OK (|Pf| = 3)")


def test_kasteleyn_bipartite_6cycle():
    """6-cycle worker-task graph (planar bipartite) has 2 perfect matchings."""
    vertices = ['W1', 'W2', 'W3', 'T1', 'T2', 'T3']
    edges = [('W1', 'T1'), ('W1', 'T2'), ('W2', 'T2'),
             ('W2', 'T3'), ('W3', 'T1'), ('W3', 'T3')]
    rotation = {
        'W1': ['T1', 'T2'],
        'T1': ['W3', 'W1'],
        'W3': ['T3', 'T1'],
        'T3': ['W2', 'W3'],
        'W2': ['T2', 'T3'],
        'T2': ['W1', 'W2'],
    }
    M = kasteleyn_orient(vertices, edges, rotation)
    assert abs(pfaffian(M)) == 2
    print(f"  test_kasteleyn_bipartite_6cycle: OK (|Pf| = 2)")


def test_kasteleyn_skew_symmetric():
    """The returned matrix must be skew-symmetric."""
    vertices = [1, 2, 3, 4]
    edges = [(1, 2), (2, 3), (3, 4), (4, 1)]
    rotation = {1: [2, 4], 2: [3, 1], 3: [4, 2], 4: [1, 3]}
    M = kasteleyn_orient(vertices, edges, rotation)
    assert simplify(M + M.T) == 0 * M
    print("  test_kasteleyn_skew_symmetric: OK")


def test_kasteleyn_inconsistent_rotation_raises():
    """Inconsistent rotation system should raise ValueError."""
    vertices = [1, 2, 3]
    edges = [(1, 2), (2, 3), (3, 1)]
    rotation = {1: [2, 3], 2: [3, 1], 3: [2, 1]}  # this is consistent
    try:
        kasteleyn_orient(vertices, edges, rotation)
    except Exception as e:
        raise AssertionError(f"valid rotation should not raise; got {e}")
    # Now inject an inconsistency
    rotation_bad = {1: [2, 3], 2: [3, 1], 3: [5, 1]}  # 5 not a neighbor of 3
    try:
        kasteleyn_orient(vertices, edges, rotation_bad)
        raise AssertionError("expected ValueError on inconsistent rotation system")
    except ValueError:
        pass
    print("  test_kasteleyn_inconsistent_rotation_raises: OK")


def run_all():
    print("admissibility v0.1 + v0.2 + v0.3-alpha + v0.3-beta + v0.3-beta-followon + hardness + kasteleyn smoke tests:")
    print(" v0.1:")
    test_eq_2_realizable()
    test_or_3_realizable()
    test_nae_3_realizable()
    test_non_realizable_caught()
    test_zero_signature_trivially_realizable()
    test_srp_necessary_check_cai_lu_5_1()
    test_srp_necessary_check_with_non_realizable()
    print(" v0.2 -- Form classification:")
    test_form_eq_2_is_form_1()
    test_form_or_3_is_form_3()
    test_form_nae_3_is_form_1_complex()
    test_form_pure_geometric_is_form_2()
    test_form_doubly_degenerate()
    test_form_non_realizable_is_none()
    print(" v0.2 -- subvariety construction:")
    test_subvariety_eq_2_equations()
    test_subvariety_or_3_tau_3_is_v_cubed_form()
    test_subvariety_zero_signature_trivial()
    print(" v0.2 -- intersection + SRP solver:")
    test_srp_cai_lu_5_1_feasible_mod_7()
    test_srp_cai_lu_5_1_infeasible_over_Q()
    test_srp_cai_lu_5_1_infeasible_mod_5()
    test_srp_short_circuits_on_individual_infeasibility()
    test_srp_eq_2_alone_feasible_over_Q()
    test_srp_empty_signature_list_feasible()
    print(" v0.3-alpha -- Pfaffian + Arf:")
    test_pfaffian_2x2()
    test_pfaffian_4x4_formula()
    test_pfaffian_squared_equals_det()
    test_pfaffian_odd_dim_is_zero()
    test_pfaffian_4_cycle_planar()
    test_arf_invariant_genus_0()
    test_arf_invariant_genus_1()
    test_arf_invariant_genus_2_count()
    test_spin_structures_count()
    print(" v0.3-alpha -- Holant evaluator:")
    test_holant_planar_is_pfaffian()
    test_holant_genus_1_identical_matrices_collapses_to_pfaffian()
    test_holant_genus_1_formula_structure()
    test_holant_genus_g_rejects_wrong_keys()
    print(" v0.3-beta -- non-symmetric signatures:")
    test_non_sym_is_symmetric_detection()
    test_non_sym_symmetric_reduction_matches_v0_2()
    test_non_sym_balanced_asymmetric_arity_2_feasible()
    test_non_sym_unbalanced_asymmetric_arity_2_chart_limitation()
    test_non_sym_arity_3_pullback_structure()
    print(" v0.3-beta-followon -- arity-4 Grassmann-Plücker matchgate identity:")
    test_matchgate_identity_pf_4x4_self_consistency()
    test_matchgate_identity_arity_4_odd_pf_self_consistency()
    test_matchgate_identity_arity_4_odd_vacuous_on_symmetric()
    test_matchgate_identity_arity_4_odd_distinguishes_asymmetric_cases()
    test_arity_4_matchgate_identity_reduces_for_symmetric_eq4()
    test_arity_4_symmetric_reduction_matches_v0_2()
    test_arity_4_v0_2_rejected_also_rejected_via_non_sym()
    print(" hardness recognition:")
    test_hardness_cai_lu_5_1_not_a_candidate()
    test_hardness_individual_infeasibility_short_circuits()
    test_hardness_single_signature_simple_realisable()
    test_hardness_modulus_only_realisability()
    print(" Kasteleyn orientation (auto-construction):")
    test_kasteleyn_c4()
    test_kasteleyn_k4()
    test_kasteleyn_bipartite_6cycle()
    test_kasteleyn_skew_symmetric()
    test_kasteleyn_inconsistent_rotation_raises()
    print("All v0.1 + v0.2 + v0.3-alpha + v0.3-beta + v0.3-beta-followon + hardness + kasteleyn tests pass.")


if __name__ == "__main__":
    run_all()
