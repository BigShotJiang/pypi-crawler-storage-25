"""Configuration system for tailtest."""

from tailtest.config.loader import load_config
from tailtest.config.schema import TailtestConfig

__all__ = ["TailtestConfig", "load_config"]
