"""Decorators and helpers for defining tailtest agent tests.

The ``@agent_test`` decorator marks a function as a tailtest test and
attaches configuration metadata (retries, timeout, tags).  The ``Agent``
helper provides static factory methods for creating agent interfaces
inside test files::

    from tailtest import agent_test, Agent, expect

    @agent_test(retries=3, timeout_ms=10000, tags=["smoke"])
    async def test_greeting():
        agent = Agent.from_function(my_agent_fn)
        response = await agent.chat("Hello")
        expect(response).to_contain("hello")
"""

from __future__ import annotations

from functools import wraps
from typing import Any, Callable

from tailtest.runner.interfaces.python_fn import PythonFunctionInterface


def agent_test(
    fn: Callable[..., Any] | None = None,
    *,
    retries: int = 1,
    timeout_ms: int = 30000,
    tags: list[str] | None = None,
) -> Any:
    """Decorator marking a function as a tailtest agent test.

    Can be used bare or with keyword arguments::

        @agent_test
        async def test_basic(): ...

        @agent_test(retries=5, timeout_ms=60000, tags=["slow"])
        async def test_complex(): ...

    The decorator attaches ``_tailtest_test``, ``_tailtest_retries``,
    ``_tailtest_timeout_ms``, and ``_tailtest_tags`` attributes to the
    wrapped function so the test runner can discover and configure it.
    """

    def _decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        @wraps(func)
        async def _wrapper(*args: Any, **kwargs: Any) -> Any:
            return await func(*args, **kwargs)

        # Attach tailtest metadata.
        _wrapper._tailtest_test = True  # type: ignore[attr-defined]
        _wrapper._tailtest_retries = retries  # type: ignore[attr-defined]
        _wrapper._tailtest_timeout_ms = timeout_ms  # type: ignore[attr-defined]
        _wrapper._tailtest_tags = tags or []  # type: ignore[attr-defined]
        return _wrapper

    # Support both @agent_test and @agent_test(...)
    if fn is not None:
        return _decorator(fn)
    return _decorator


class Agent:
    """Helper for creating agent interfaces in test files.

    Provides static factory methods that return ``BaseAgentInterface``
    implementations, hiding the import paths from end users::

        agent = Agent.from_function(my_fn)
        agent = Agent.from_http("http://localhost:8000/chat")
        agent = Agent.from_cli("python my_agent.py")
    """

    @staticmethod
    def from_function(
        fn: Callable[..., Any], name: str | None = None
    ) -> PythonFunctionInterface:
        """Wrap a Python callable as an agent interface.

        Parameters
        ----------
        fn:
            A sync or async callable with signature ``fn(message: str) -> str | dict | AgentResponse``.
        name:
            Optional human-readable name for this agent.
        """
        return PythonFunctionInterface(fn=fn, name=name)

    @staticmethod
    def from_http(url: str, **kwargs: Any) -> Any:
        """Create an HTTP agent interface.

        Parameters
        ----------
        url:
            The agent endpoint URL.
        **kwargs:
            Forwarded to ``HTTPInterface`` (method, headers, body_template, etc.).
        """
        from tailtest.runner.interfaces.http import HTTPInterface

        return HTTPInterface(url=url, **kwargs)

    @staticmethod
    def from_cli(command: str | list[str], **kwargs: Any) -> Any:
        """Create a CLI subprocess agent interface.

        Parameters
        ----------
        command:
            Shell command string or argument list.
        **kwargs:
            Forwarded to ``CLIInterface`` (timeout, etc.).
        """
        from tailtest.runner.interfaces.cli_proc import CLIInterface

        return CLIInterface(command=command, **kwargs)
