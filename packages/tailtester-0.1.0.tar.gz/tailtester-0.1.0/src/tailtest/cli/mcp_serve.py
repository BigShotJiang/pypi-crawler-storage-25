"""tailtest mcp-serve — start the MCP server for IDE integration."""

from __future__ import annotations

import click


@click.command("mcp-serve")
def mcp_serve_cmd() -> None:
    """Start the MCP server on stdio for IDE integration.

    Exposes tailtest capabilities (scan, generate, run, check safety) to
    MCP-compatible IDEs like Cursor and Claude Code.

    \b
    Example MCP config (Claude Code / Cursor):
      {
        "mcpServers": {
          "tailtest": {
            "command": "tailtest",
            "args": ["mcp-serve"]
          }
        }
      }
    """
    from tailtest.mcp.server import main

    main()
