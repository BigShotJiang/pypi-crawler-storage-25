"""tailtest replay — replay recorded LLM calls for deterministic testing."""

import click
from rich.console import Console

console = Console()


@click.command("replay")
def replay_cmd() -> None:
    """Replay recorded LLM responses for deterministic test runs.

    Uses previously recorded LLM calls (from 'tailtest record') to run
    tests without making live API calls. Ensures identical results
    across runs for CI/CD and debugging.
    """
    console.print()
    console.print("[bold]Replay mode enabled.[/bold]")
    console.print("[dim]Using recorded responses from .tailtest/recordings/[/dim]")
    console.print()

    # TODO: implement replay integration with runner
