"""tailtest init — initialize a new Tailtest project."""

import os
from pathlib import Path

import click
from rich.console import Console

console = Console()

DEFAULT_CONFIG = """\
# Tailtest configuration
# See https://github.com/avansaber/tailtest for full docs.

project:
  name: {project_name}
  framework: {framework}

context:
  scan_paths:
    - "."
  ignore:
    - "node_modules"
    - ".venv"
    - "__pycache__"
    - ".git"

runner:
  parallel: 1
  reliability: 1
  cost_limit: null

judge:
  model: "ollama/llama3.2"

redteam:
  enabled: false
  owasp: true

reporting:
  format: text
"""

FRAMEWORK_CHOICES = ["langchain", "crewai", "openai", "anthropic", "pydantic-ai"]

TAILTEST_DIRS = [
    "context",
    "tests/auto",
    "tests/custom",
    "recordings",
    "reports",
    "audit",
]


@click.command("init")
@click.option(
    "--framework",
    type=click.Choice(FRAMEWORK_CHOICES, case_sensitive=False),
    default=None,
    help="AI framework to configure templates for.",
)
def init_cmd(framework: str | None) -> None:
    """Initialize a new Tailtest project in the current directory.

    Creates the .tailtest/ directory structure with default configuration,
    ready for scanning and test generation.
    """
    project_root = Path.cwd()
    tailtest_dir = project_root / ".tailtest"

    if tailtest_dir.exists():
        console.print("[yellow]⚠  .tailtest/ already exists. Re-initializing config.[/yellow]")

    # Create directory structure
    for subdir in TAILTEST_DIRS:
        dir_path = tailtest_dir / subdir
        dir_path.mkdir(parents=True, exist_ok=True)

    # Write default config
    project_name = project_root.name
    fw = framework or "auto"
    config_content = DEFAULT_CONFIG.format(project_name=project_name, framework=fw)
    config_path = tailtest_dir / "config.yaml"
    config_path.write_text(config_content)

    console.print()
    console.print("[bold green]Tailtest initialized successfully.[/bold green]")
    console.print()
    console.print("Created .tailtest/ with:")
    for subdir in TAILTEST_DIRS:
        console.print(f"  [dim].tailtest/{subdir}/[/dim]")
    console.print(f"  [dim].tailtest/config.yaml[/dim]")
    console.print()
    console.print("[bold]Next steps:[/bold]")
    console.print("  1. [cyan]tailtest scan .[/cyan]        Scan your project for agent code")
    console.print("  2. [cyan]tailtest generate[/cyan]      Generate tests from scan results")
    console.print("  3. [cyan]tailtest run[/cyan]           Run the generated tests")
    console.print()
