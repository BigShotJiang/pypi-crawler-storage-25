"""tailtest watch — watch for project changes and update context."""

from __future__ import annotations

import asyncio
from pathlib import Path

import click
from rich.console import Console

console = Console()


@click.command("watch")
@click.argument("path", default=".", type=click.Path(exists=True))
@click.option(
    "--no-generate",
    is_flag=True,
    default=False,
    help="Disable automatic test generation on file changes.",
)
def watch_cmd(path: str, no_generate: bool) -> None:
    """Watch a project directory for changes and update context continuously.

    PATH is the directory to watch (defaults to current directory).
    Runs until interrupted with Ctrl+C. Triggers incremental re-scans
    when agent code, prompts, or tool definitions change and optionally
    auto-generates tests.
    """
    resolved = Path(path).resolve()

    from tailtest.context.sources.watcher import ProjectWatcher

    watcher = ProjectWatcher(resolved, console=console)

    try:
        asyncio.run(watcher.watch(auto_generate=not no_generate))
    except KeyboardInterrupt:
        console.print("\n[bold]Stopped watching.[/bold]")
