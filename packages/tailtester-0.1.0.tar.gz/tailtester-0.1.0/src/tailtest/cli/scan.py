"""tailtest scan — scan an agent project to build context."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

import click
from rich.console import Console

console = Console()


@click.command("scan")
@click.argument("path", default=".", type=click.Path(exists=True))
@click.option(
    "--deep",
    is_flag=True,
    default=False,
    help="Include git history analysis for deeper context.",
)
@click.option(
    "--output",
    type=click.Choice(["json", "text"], case_sensitive=False),
    default="text",
    help="Output format for scan results.",
)
def scan_cmd(path: str, deep: bool, output: str) -> None:
    """Scan an agent project to build context for test generation.

    PATH is the root directory to scan (defaults to current directory).
    Discovers agent code, tool definitions, prompts, and configuration
    to feed into the test generator.
    """
    resolved = Path(path).resolve()
    console.print()
    console.print(f"[bold]Scanning[/bold] [cyan]{resolved}[/cyan] ...")

    if deep:
        console.print("[dim]  Deep mode: including git history analysis[/dim]")

    from tailtest.context.engine import ContextEngine

    engine = ContextEngine()
    result = asyncio.run(engine.scan(resolved, deep=deep))

    # Save context
    tailtest_dir = resolved / ".tailtest"
    if tailtest_dir.exists():
        engine.save_context(result, tailtest_dir / "context")

    console.print()

    if output == "json":
        console.print(json.dumps(result.model_dump(), indent=2))
    else:
        console.print(f"  Framework:    [cyan]{result.framework}[/cyan]")
        if result.framework_version:
            console.print(f"  Version:      [cyan]{result.framework_version}[/cyan]")
        console.print(f"  Tools:        [cyan]{len(result.tools)}[/cyan] discovered")
        console.print(f"  Prompts:      [cyan]{len(result.prompts)}[/cyan] discovered")
        console.print(f"  Agents:       [cyan]{len(result.agents)}[/cyan] discovered")
        console.print(f"  Models:       [cyan]{', '.join(result.models) or 'none'}[/cyan]")
        console.print(f"  Dependencies: [cyan]{len(result.dependencies)}[/cyan]")
        console.print(f"  Env vars:     [cyan]{len(result.env_vars)}[/cyan]")

    console.print()
    console.print("[bold green]Scan complete.[/bold green]")
    if tailtest_dir.exists():
        console.print("[dim]Context saved to .tailtest/context/[/dim]")
    else:
        console.print("[dim]Run 'tailtest init' first to persist context.[/dim]")
    console.print()
