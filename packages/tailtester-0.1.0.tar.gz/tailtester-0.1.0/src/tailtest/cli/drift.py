"""tailtest drift — quality drift detection and baseline management."""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

console = Console()


@click.command("drift")
@click.option(
    "--baseline",
    type=str,
    default=None,
    help="Set baseline from a run ID (e.g. 'run-123').",
)
@click.option(
    "--check",
    is_flag=True,
    default=False,
    help="Compare current traces against the stored baseline.",
)
@click.option(
    "--alert",
    type=click.Choice(["slack", "json", "terminal"]),
    default=None,
    help="Alert channel for drift notifications.",
)
@click.option(
    "--webhook",
    type=str,
    default=None,
    help="Webhook URL for alert delivery (used with --alert slack).",
)
@click.option(
    "--traces-dir",
    type=click.Path(exists=False),
    default=None,
    help="Directory containing trace files to check.",
)
@click.option(
    "--baseline-path",
    type=click.Path(),
    default=None,
    help="Path to baseline JSON file (default: .tailtest/baselines/current.json).",
)
def drift_cmd(
    baseline: str | None,
    check: bool,
    alert: str | None,
    webhook: str | None,
    traces_dir: str | None,
    baseline_path: str | None,
) -> None:
    """Detect quality drift in agent responses.

    Set a baseline from a previous run, then compare current traces
    or responses against it to detect regressions.

    \b
    Examples:
      tailtest drift --baseline run-123     Set baseline from run
      tailtest drift --check                Compare current to baseline
      tailtest drift --check --alert slack --webhook URL
    """
    asyncio.run(
        _drift_async(
            baseline=baseline,
            check=check,
            alert=alert,
            webhook=webhook,
            traces_dir=traces_dir,
            baseline_path=baseline_path,
        )
    )


async def _drift_async(
    baseline: str | None,
    check: bool,
    alert: str | None,
    webhook: str | None,
    traces_dir: str | None,
    baseline_path: str | None,
) -> None:
    """Async implementation of the drift command."""
    from tailtest.production.drift_detector import DriftDetector

    bp = Path(baseline_path) if baseline_path else None
    detector = DriftDetector(baseline_path=bp)

    # --- Set baseline ---
    if baseline:
        console.print()
        console.print(f"[bold]Setting baseline from run:[/bold] [cyan]{baseline}[/cyan]")

        try:
            metrics = await detector.set_baseline_from_run(baseline)
            console.print("[green]Baseline set successfully.[/green]")
            console.print(f"  Responses:    {metrics.total_responses}")
            console.print(f"  Avg latency:  {metrics.avg_latency_ms:.0f}ms")
            console.print(f"  Avg cost:     ${metrics.avg_cost_usd:.4f}")
            console.print(f"  Error rate:   {metrics.error_rate:.1f}%")
            console.print(f"  PII leak:     {metrics.pii_leak_rate:.1f}%")
            console.print(f"  Saved to:     {detector.baseline_path}")
        except FileNotFoundError as exc:
            console.print(f"[red]Error:[/red] {exc}")
            sys.exit(1)
        except ValueError as exc:
            console.print(f"[red]Error:[/red] {exc}")
            sys.exit(1)

        console.print()
        return

    # --- Check drift ---
    if check:
        console.print()
        console.print("[bold]Checking for quality drift...[/bold]")

        if detector.baseline is None:
            console.print(
                "[red]Error:[/red] No baseline found. "
                "Set one first with: tailtest drift --baseline <run-id>"
            )
            sys.exit(1)

        td = Path(traces_dir) if traces_dir else None

        try:
            alerts = await detector.detect_from_traces(td)
        except FileNotFoundError as exc:
            console.print(f"[red]Error:[/red] {exc}")
            sys.exit(1)

        if not alerts:
            console.print("[green]No drift detected. All metrics within baseline thresholds.[/green]")
            console.print()
            return

        # Display alerts
        table = Table(title="Drift Alerts")
        table.add_column("Severity", style="bold")
        table.add_column("Metric")
        table.add_column("Baseline")
        table.add_column("Current")
        table.add_column("Message")

        for a in alerts:
            severity_style = "red" if a.severity == "critical" else "yellow"
            table.add_row(
                f"[{severity_style}]{a.severity.upper()}[/{severity_style}]",
                a.metric_name,
                f"{a.baseline_value:.4f}",
                f"{a.current_value:.4f}",
                a.message,
            )

        console.print(table)

        # --- Send alerts ---
        if alert == "slack" and webhook:
            _send_slack_alert(alerts, webhook)
        elif alert == "json":
            _print_json_alerts(alerts)

        console.print()

        # Exit with non-zero if critical alerts
        if any(a.severity == "critical" for a in alerts):
            sys.exit(1)

        return

    # --- No action specified ---
    console.print()
    console.print("[yellow]No action specified.[/yellow] Use one of:")
    console.print("  tailtest drift --baseline <run-id>   Set baseline")
    console.print("  tailtest drift --check               Check for drift")
    console.print()


def _send_slack_alert(alerts: list, webhook: str) -> None:
    """Send drift alerts to a Slack webhook."""
    try:
        import urllib.request

        blocks = []
        for a in alerts:
            emoji = ":rotating_light:" if a.severity == "critical" else ":warning:"
            blocks.append(
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"{emoji} *{a.severity.upper()}* — {a.metric_name}\n{a.message}",
                    },
                }
            )

        payload = json.dumps(
            {
                "text": f"Tailtest drift alert: {len(alerts)} issue(s) detected",
                "blocks": blocks,
            }
        )

        req = urllib.request.Request(
            webhook,
            data=payload.encode(),
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=10)
        console.print("[green]Slack alert sent.[/green]")

    except Exception as exc:
        console.print(f"[red]Failed to send Slack alert:[/red] {exc}")


def _print_json_alerts(alerts: list) -> None:
    """Print alerts as JSON to stdout."""
    data = [a.to_dict() for a in alerts]
    console.print_json(json.dumps(data, indent=2))
