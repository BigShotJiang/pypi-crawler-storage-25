"""LLM judge engine — evaluates agent responses using an LLM as a judge.

Uses litellm for model-agnostic LLM calls.  Defaults to ``ollama/llama3.2``
(free, local) but any model supported by litellm can be configured via
:class:`~tailtest.config.schema.JudgeConfig`.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass

from tailtest.config.schema import JudgeConfig

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------


@dataclass
class JudgeResult:
    """Structured result from an LLM judge evaluation."""

    passed: bool
    score: float  # 0.0 – 1.0
    reason: str
    cost_usd: float = 0.0
    model: str = ""
    latency_ms: float = 0.0
    raw_response: str = ""


# ---------------------------------------------------------------------------
# System prompt shared by all rubric evaluations
# ---------------------------------------------------------------------------

JUDGE_SYSTEM_PROMPT = """\
You are an impartial judge evaluating an AI assistant's response.

You MUST respond with ONLY a valid JSON object — no markdown fences, no
explanation outside the JSON.  The JSON object must have exactly these keys:

{
  "score": <float between 0.0 and 1.0>,
  "passed": <true or false>,
  "reason": "<one or two sentence explanation>"
}

Rules:
- score 1.0 = perfect, 0.0 = complete failure.
- passed = true when the response meets the criteria, false otherwise.
- reason must be concise and specific.
"""

# ---------------------------------------------------------------------------
# Judge class
# ---------------------------------------------------------------------------


class LLMJudge:
    """Model-agnostic LLM judge backed by ``litellm``.

    Parameters
    ----------
    config:
        Optional :class:`JudgeConfig` overriding the default model /
        temperature.  When *None*, ``ollama/llama3.2`` at temperature 0 is
        used.
    """

    def __init__(self, config: JudgeConfig | None = None) -> None:
        self.config = config or JudgeConfig()

    # --------------------------------------------------------------------- #
    # Public API
    # --------------------------------------------------------------------- #

    async def evaluate(
        self,
        prompt: str,
        response_text: str,
        rubric: str,
        *,
        threshold: float = 0.7,
    ) -> JudgeResult:
        """Ask the LLM judge to evaluate *response_text* against *rubric*.

        Parameters
        ----------
        prompt:
            The original user input / question that produced the response.
        response_text:
            The agent's response text to evaluate.
        rubric:
            The evaluation rubric the judge should apply.
        threshold:
            Minimum ``score`` required for ``passed`` to be ``True``.
            Defaults to 0.7.
        """
        try:
            import litellm  # type: ignore[import-untyped]
        except ImportError:
            return JudgeResult(
                passed=False,
                score=0.0,
                reason=(
                    "litellm is not installed. "
                    "Install it with: pip install litellm"
                ),
                model=self.config.model,
            )

        user_content = (
            f"## Evaluation Rubric\n{rubric}\n\n"
            f"## Original User Input\n{prompt}\n\n"
            f"## AI Assistant Response\n{response_text}\n\n"
            "Evaluate the response according to the rubric above. "
            "Respond with ONLY the JSON object."
        )

        messages = [
            {"role": "system", "content": JUDGE_SYSTEM_PROMPT},
            {"role": "user", "content": user_content},
        ]

        start = time.perf_counter()

        try:
            completion = await litellm.acompletion(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=256,
                timeout=30,
            )
        except Exception as exc:
            return self._handle_llm_error(exc)

        elapsed_ms = (time.perf_counter() - start) * 1000.0

        raw = completion.choices[0].message.content or ""
        cost = self._extract_cost(completion)

        return self._parse_response(
            raw,
            cost=cost,
            latency_ms=elapsed_ms,
            threshold=threshold,
        )

    # --------------------------------------------------------------------- #
    # Internal helpers
    # --------------------------------------------------------------------- #

    def _parse_response(
        self,
        raw: str,
        *,
        cost: float,
        latency_ms: float,
        threshold: float,
    ) -> JudgeResult:
        """Parse the LLM's JSON response into a :class:`JudgeResult`."""
        # Strip markdown code fences if the model wrapped its answer.
        text = raw.strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[-1]
        if text.endswith("```"):
            text = text.rsplit("```", 1)[0]
        text = text.strip()

        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            logger.warning("Judge returned non-JSON response: %s", raw[:200])
            return JudgeResult(
                passed=False,
                score=0.0,
                reason=f"Judge returned unparseable response: {raw[:200]}",
                cost_usd=cost,
                model=self.config.model,
                latency_ms=latency_ms,
                raw_response=raw,
            )

        score = float(data.get("score", 0.0))
        score = max(0.0, min(1.0, score))  # clamp to [0, 1]

        # Use the judge's pass/fail if present, otherwise threshold-based.
        passed = data.get("passed", score >= threshold)

        reason = str(data.get("reason", "No reason provided."))

        return JudgeResult(
            passed=bool(passed),
            score=score,
            reason=reason,
            cost_usd=cost,
            model=self.config.model,
            latency_ms=latency_ms,
            raw_response=raw,
        )

    def _extract_cost(self, completion: object) -> float:
        """Best-effort cost extraction from litellm completion."""
        try:
            import litellm  # type: ignore[import-untyped]

            return float(litellm.completion_cost(completion_response=completion))
        except Exception:
            return 0.0

    def _handle_llm_error(self, exc: Exception) -> JudgeResult:
        """Return a descriptive :class:`JudgeResult` for LLM call failures."""
        msg = str(exc)

        # Detect common Ollama-not-running scenario.
        if any(hint in msg.lower() for hint in ("connection refused", "connect error", "connection error")):
            reason = (
                f"Could not connect to the LLM provider for model "
                f"'{self.config.model}'. If you're using the default Ollama "
                f"model, make sure Ollama is running (`ollama serve`) and the "
                f"model is pulled (`ollama pull llama3.2`). "
                f"Run `tailtest doctor` to diagnose. Original error: {msg}"
            )
        elif "timeout" in msg.lower():
            reason = (
                f"LLM judge call timed out for model '{self.config.model}'. "
                f"The model may be loading or the server is under heavy load. "
                f"Original error: {msg}"
            )
        elif any(hint in msg.lower() for hint in ("api key", "apikey", "authentication", "unauthorized")):
            reason = (
                f"Authentication error for model '{self.config.model}'. "
                f"Make sure the required API key is set in your environment. "
                f"Original error: {msg}"
            )
        else:
            reason = (
                f"LLM judge call failed for model '{self.config.model}': {msg}"
            )

        logger.error("LLM judge error: %s", reason)

        return JudgeResult(
            passed=False,
            score=0.0,
            reason=reason,
            model=self.config.model,
        )
