"""Tone assertion — checks that a response matches expected tone descriptors."""

from __future__ import annotations

from tailtest.assertions.base import BaseAssertion
from tailtest.assertions.llm_judge.judge import LLMJudge
from tailtest.config.schema import JudgeConfig
from tailtest.models import AgentResponse, AssertionResult


TONE_RUBRIC = """\
Evaluate whether the AI assistant's response matches the **expected tone**.

## Expected Tone
The response should be: {descriptors}

## Criteria
1. Does the overall writing style match the expected tone descriptors?
2. Is the tone consistent throughout the entire response?
3. Does the word choice, sentence structure, and phrasing reflect the
   expected tone?
4. Would a reasonable reader perceive the response as having the expected tone?

## Scoring Guide
- 1.0: Perfect tone match — the response clearly and consistently embodies
  all the expected tone descriptors.
- 0.7-0.9: Good match — the response mostly reflects the expected tone with
  minor deviations.
- 0.4-0.6: Partial match — the response sometimes reflects the expected tone
  but is inconsistent or mixed.
- 0.1-0.3: Poor match — the response largely fails to match the expected tone.
- 0.0: Complete mismatch — the tone is the opposite of what was expected.

Set passed=true if the score is >= 0.7, otherwise passed=false.
"""


class ToneAssertion(BaseAssertion):
    """Assert that the agent response matches expected tone descriptors.

    Example::

        assertion = ToneAssertion("professional", "empathetic")
        result = await assertion.evaluate(response)
    """

    def __init__(
        self,
        *descriptors: str,
        config: JudgeConfig | None = None,
    ) -> None:
        if not descriptors:
            raise ValueError("At least one tone descriptor is required.")
        self.descriptors = descriptors
        self._judge = LLMJudge(config)

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        descriptor_str = ", ".join(self.descriptors)
        rubric = TONE_RUBRIC.format(descriptors=descriptor_str)

        prompt = response.metadata.get("prompt", "")

        judge_result = await self._judge.evaluate(
            prompt=prompt,
            response_text=response.content,
            rubric=rubric,
            threshold=0.7,
        )

        return AssertionResult(
            passed=judge_result.passed,
            assertion_type="tone",
            expected=f"Tone: {descriptor_str}",
            actual=judge_result.reason,
            message=(
                f"Tone check {'passed' if judge_result.passed else 'FAILED'} "
                f"(expected: {descriptor_str}, score: {judge_result.score:.2f}): "
                f"{judge_result.reason}"
            ),
            score=judge_result.score,
            cost_usd=judge_result.cost_usd,
        )
