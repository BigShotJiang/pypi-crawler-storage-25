"""Relevance assertion — checks that a response addresses the user's question."""

from __future__ import annotations

from tailtest.assertions.base import BaseAssertion
from tailtest.assertions.llm_judge.judge import LLMJudge
from tailtest.config.schema import JudgeConfig
from tailtest.models import AgentResponse, AssertionResult


RELEVANCE_RUBRIC = """\
Evaluate whether the AI assistant's response is **relevant** to the user's
question.

## User's Question
{question}

## Criteria
1. Does the response directly address what the user asked?
2. Does the response stay on topic without going off on tangents?
3. If the user asked a specific question, does the response provide a
   specific answer (not just general information)?
4. Does the response avoid padding with irrelevant filler content?

## Scoring Guide
- 1.0: Perfectly relevant — directly and specifically addresses the question.
- 0.7-0.9: Mostly relevant — addresses the question but includes some
  tangential information.
- 0.4-0.6: Partially relevant — touches on the topic but fails to directly
  answer the question.
- 0.1-0.3: Mostly irrelevant — the response barely relates to the question.
- 0.0: Completely irrelevant — the response has nothing to do with the
  question.

Set passed=true if the score is >= 0.7, otherwise passed=false.
"""


class RelevanceAssertion(BaseAssertion):
    """Assert that the agent response is relevant to the original question.

    Example::

        assertion = RelevanceAssertion(question="What is the capital of France?")
        result = await assertion.evaluate(response)
    """

    def __init__(
        self,
        question: str,
        config: JudgeConfig | None = None,
    ) -> None:
        self.question = question
        self._judge = LLMJudge(config)

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        rubric = RELEVANCE_RUBRIC.format(question=self.question)

        judge_result = await self._judge.evaluate(
            prompt=self.question,
            response_text=response.content,
            rubric=rubric,
            threshold=0.7,
        )

        return AssertionResult(
            passed=judge_result.passed,
            assertion_type="relevance",
            expected="Response addresses the user's question",
            actual=judge_result.reason,
            message=(
                f"Relevance check {'passed' if judge_result.passed else 'FAILED'} "
                f"(score: {judge_result.score:.2f}): {judge_result.reason}"
            ),
            score=judge_result.score,
            cost_usd=judge_result.cost_usd,
        )
