"""Cost assertion — checks that total LLM cost stays under a threshold."""

from __future__ import annotations

from tailtest.assertions.base import BaseAssertion
from tailtest.models import AgentResponse, AssertionResult


class CostAssertion(BaseAssertion):
    """Assert that ``response.cost_usd`` is below a maximum threshold.

    Example::

        assertion = CostAssertion(max_cost=0.50)
        result = await assertion.evaluate(response)
    """

    def __init__(self, max_cost: float) -> None:
        self.max_cost = max_cost

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        actual_cost = response.cost_usd

        if actual_cost is None:
            return AssertionResult(
                passed=False,
                assertion_type="cost_under",
                expected=self.max_cost,
                actual=None,
                message=(
                    f"Cost data unavailable on response (expected < ${self.max_cost:.4f}). "
                    "Ensure the agent adapter populates cost_usd."
                ),
            )

        passed = actual_cost < self.max_cost
        return AssertionResult(
            passed=passed,
            assertion_type="cost_under",
            expected=self.max_cost,
            actual=actual_cost,
            message=(
                f"Cost ${actual_cost:.4f} is under ${self.max_cost:.4f} threshold"
                if passed
                else (
                    f"Cost ${actual_cost:.4f} exceeds ${self.max_cost:.4f} threshold "
                    f"(over by ${actual_cost - self.max_cost:.4f})"
                )
            ),
        )
