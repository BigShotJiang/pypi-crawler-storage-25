"""Pass@K assertion -- checks if at least 1 of K trials passes a given assertion.

This is the "can the agent ever get this right?" test. Run the agent K times
with the same input and succeed if *any* trial passes the inner assertion.

Reference: Anthropic's pass@k metric for evaluating non-deterministic systems.
"""

from __future__ import annotations

from typing import Any, Protocol

from tailtest.assertions.base import BaseAssertion
from tailtest.models import AgentResponse, AssertionResult


class AgentInterface(Protocol):
    """Minimal protocol for invoking an agent with a text message."""

    async def run(self, message: str) -> AgentResponse: ...


class PassKAssertion(BaseAssertion):
    """Assert that at least 1 of K independent trials passes a given assertion.

    This is useful for measuring whether an agent is *capable* of producing a
    correct response, even if it doesn't do so reliably.

    Example::

        assertion = PassKAssertion(
            k=5,
            assertion=ContainsAssertion(text="order confirmed"),
            agent_interface=my_agent,
            input_message="Place an order for 3 widgets",
        )
        result = await assertion.evaluate(response)  # response is ignored; we re-run the agent

    Args:
        k: Number of independent trials to run.
        assertion: The inner assertion each trial is evaluated against.
        agent_interface: An object with an async ``run(message)`` method.
        input_message: The user message to send to the agent on each trial.
    """

    def __init__(
        self,
        k: int,
        assertion: BaseAssertion,
        agent_interface: Any,
        input_message: str,
    ) -> None:
        if k < 1:
            raise ValueError("k must be >= 1")
        self.k = k
        self.assertion = assertion
        self.agent_interface = agent_interface
        self.input_message = input_message

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        """Run the agent K times and check if at least one trial passes.

        The *response* argument is ignored -- we run the agent ourselves.
        """
        passes = 0
        failures = 0
        last_message = ""

        for _ in range(self.k):
            trial_response = await self.agent_interface.run(self.input_message)
            trial_result = await self.assertion.evaluate(trial_response)
            if trial_result.passed:
                passes += 1
            else:
                failures += 1
                last_message = trial_result.message

        passed = passes >= 1
        pass_rate = passes / self.k

        return AssertionResult(
            passed=passed,
            assertion_type="pass_k",
            expected=f"At least 1/{self.k} trials pass",
            actual=f"{passes}/{self.k} trials passed",
            message=(
                f"pass@{self.k}: {passes}/{self.k} trials passed ({pass_rate:.0%})"
                if passed
                else (
                    f"pass@{self.k} FAILED: 0/{self.k} trials passed. "
                    f"Last failure: {last_message}"
                )
            ),
            score=pass_rate,
        )
