"""Pass^K assertion -- checks if ALL K trials pass a given assertion.

This is the critical customer-facing reliability metric recommended by Anthropic.
A 75% per-trial pass rate yields only ~42% pass^3 (0.75^3 = 0.4219).

Use this to answer: "will the agent reliably get this right every time?"
"""

from __future__ import annotations

from typing import Any

from tailtest.assertions.base import BaseAssertion
from tailtest.models import AgentResponse, AssertionResult


class PassHatKAssertion(BaseAssertion):
    r"""Assert that ALL K independent trials pass a given assertion.

    This is the strictest reliability metric. If per-trial pass rate is *p*,
    the expected pass^k rate is *p^k*, which drops fast:

    - p=0.90, k=3 -> 0.729
    - p=0.85, k=3 -> 0.614
    - p=0.75, k=3 -> 0.422

    Example::

        assertion = PassHatKAssertion(
            k=3,
            assertion=ContainsAssertion(text="order confirmed"),
            agent_interface=my_agent,
            input_message="Place an order for 3 widgets",
        )
        result = await assertion.evaluate(response)

    Args:
        k: Number of independent trials to run.
        assertion: The inner assertion each trial is evaluated against.
        agent_interface: An object with an async ``run(message)`` method.
        input_message: The user message to send to the agent on each trial.
    """

    def __init__(
        self,
        k: int,
        assertion: BaseAssertion,
        agent_interface: Any,
        input_message: str,
    ) -> None:
        if k < 1:
            raise ValueError("k must be >= 1")
        self.k = k
        self.assertion = assertion
        self.agent_interface = agent_interface
        self.input_message = input_message

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        """Run the agent K times and check that every trial passes.

        The *response* argument is ignored -- we run the agent ourselves.
        """
        passes = 0
        first_failure_message = ""

        for i in range(self.k):
            trial_response = await self.agent_interface.run(self.input_message)
            trial_result = await self.assertion.evaluate(trial_response)
            if trial_result.passed:
                passes += 1
            else:
                if not first_failure_message:
                    first_failure_message = (
                        f"Trial {i + 1} failed: {trial_result.message}"
                    )

        passed = passes == self.k
        pass_rate = passes / self.k

        return AssertionResult(
            passed=passed,
            assertion_type="pass_hat_k",
            expected=f"All {self.k}/{self.k} trials pass",
            actual=f"{passes}/{self.k} trials passed",
            message=(
                f"pass^{self.k}: ALL {self.k}/{self.k} trials passed"
                if passed
                else (
                    f"pass^{self.k} FAILED: {passes}/{self.k} trials passed "
                    f"({pass_rate:.0%}). {first_failure_message}"
                )
            ),
            score=pass_rate,
        )
