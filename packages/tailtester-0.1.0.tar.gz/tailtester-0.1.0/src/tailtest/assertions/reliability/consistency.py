"""Consistency assertion -- checks if N runs produce semantically similar outputs.

Uses simple text similarity (difflib.SequenceMatcher) rather than LLM-judged
similarity. The score is the average pairwise similarity across all N responses.
"""

from __future__ import annotations

import difflib
from itertools import combinations
from typing import Any

from tailtest.assertions.base import BaseAssertion
from tailtest.models import AgentResponse, AssertionResult


class ConsistencyAssertion(BaseAssertion):
    """Assert that the agent produces consistent outputs across N runs.

    Runs the agent N times with the same input and computes the average
    pairwise text similarity using ``difflib.SequenceMatcher``.  Passes if
    the average similarity meets or exceeds the threshold.

    Example::

        assertion = ConsistencyAssertion(
            n=5,
            agent_interface=my_agent,
            input_message="What is 2+2?",
            threshold=0.7,
        )
        result = await assertion.evaluate(response)

    Args:
        n: Number of independent trials to run (must be >= 2).
        agent_interface: An object with an async ``run(message)`` method.
        input_message: The user message to send to the agent on each trial.
        threshold: Minimum average pairwise similarity to pass (0.0-1.0).
    """

    def __init__(
        self,
        n: int,
        agent_interface: Any,
        input_message: str,
        threshold: float = 0.7,
    ) -> None:
        if n < 2:
            raise ValueError("n must be >= 2 for consistency checking")
        if not 0.0 <= threshold <= 1.0:
            raise ValueError("threshold must be between 0.0 and 1.0")
        self.n = n
        self.agent_interface = agent_interface
        self.input_message = input_message
        self.threshold = threshold

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        """Run the agent N times and compute average pairwise similarity.

        The *response* argument is ignored -- we run the agent ourselves.
        """
        responses: list[str] = []
        for _ in range(self.n):
            trial_response = await self.agent_interface.run(self.input_message)
            responses.append(trial_response.content)

        avg_similarity = _average_pairwise_similarity(responses)
        passed = avg_similarity >= self.threshold

        return AssertionResult(
            passed=passed,
            assertion_type="consistency",
            expected=f"Average pairwise similarity >= {self.threshold:.2f}",
            actual=f"Average pairwise similarity = {avg_similarity:.4f}",
            message=(
                f"Consistency: {avg_similarity:.4f} >= {self.threshold:.2f} "
                f"across {self.n} runs"
                if passed
                else (
                    f"Consistency FAILED: average similarity {avg_similarity:.4f} "
                    f"< threshold {self.threshold:.2f} across {self.n} runs"
                )
            ),
            score=avg_similarity,
        )


def _average_pairwise_similarity(texts: list[str]) -> float:
    """Compute the average pairwise SequenceMatcher ratio across all texts."""
    if len(texts) < 2:
        return 1.0

    pairs = list(combinations(texts, 2))
    total = sum(
        difflib.SequenceMatcher(None, a, b).ratio() for a, b in pairs
    )
    return total / len(pairs)
