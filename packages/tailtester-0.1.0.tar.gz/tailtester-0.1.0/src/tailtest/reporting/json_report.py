"""JSON reporter — serializes TestSuiteResult to pretty-printed JSON."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from tailtest.models import TestSuiteResult

REPORTS_DIR = Path(".tailtest/reports")


def _default_report_path() -> Path:
    """Generate a timestamped report filename."""
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    return REPORTS_DIR / f"report_{ts}.json"


class JSONReporter:
    """Serialize test suite results to JSON."""

    def generate(self, suite: TestSuiteResult) -> str:
        """Generate a pretty-printed JSON string from a test suite result."""
        data = suite.model_dump(mode="json")
        return json.dumps(data, indent=2, default=str)

    def write(
        self,
        suite: TestSuiteResult,
        output_path: Path | None = None,
    ) -> Path:
        """Write JSON report to disk.

        If *output_path* is ``None`` the report is written to
        ``.tailtest/reports/report_<timestamp>.json``.

        Returns the path the report was written to.
        """
        path = output_path or _default_report_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        json_content = self.generate(suite)
        path.write_text(json_content, encoding="utf-8")
        return path
