"""JUnit XML reporter for CI/CD integration."""

from __future__ import annotations

from pathlib import Path
from xml.etree.ElementTree import Element, SubElement, tostring
from xml.dom.minidom import parseString

from tailtest.models import TestResult, TestSuiteResult


def _classname(result: TestResult) -> str:
    """Derive a JUnit classname from a test result.

    Looks for a ``file:`` tag first, otherwise falls back to a
    name-based heuristic.
    """
    for tag in result.test_case.tags:
        if tag.startswith("file:"):
            # e.g. "tests/test_support.py" -> "test_support"
            return Path(tag[5:]).stem
    # Fallback: strip leading "test_" prefix words
    name = result.test_case.name
    parts = name.split("_")
    # Best-effort: use everything before the last segment as classname
    if len(parts) > 2 and parts[0] == "test":
        return "_".join(parts[:2])
    return "tailtest"


class JUnitReporter:
    """Generate standard JUnit XML reports consumable by CI/CD systems."""

    def generate(self, suite: TestSuiteResult) -> str:
        """Generate a JUnit XML string from a test suite result."""
        root = Element("testsuites")

        ts = SubElement(
            root,
            "testsuite",
            name="tailtest",
            tests=str(suite.total),
            failures=str(suite.failed),
            errors="0",
            skipped=str(suite.skipped),
            time=f"{suite.duration_ms / 1000:.3f}",
        )

        for result in suite.results:
            tc = SubElement(
                ts,
                "testcase",
                name=result.test_case.name,
                classname=_classname(result),
                time=f"{result.duration_ms / 1000:.3f}",
            )

            if not result.passed:
                failed_assertions = [ar for ar in result.assertion_results if not ar.passed]
                for ar in failed_assertions:
                    body_parts: list[str] = []
                    if ar.expected is not None:
                        body_parts.append(f"Expected: {ar.expected}")
                    if ar.actual is not None:
                        actual_str = str(ar.actual)
                        if len(actual_str) > 500:
                            actual_str = actual_str[:497] + "..."
                        body_parts.append(f'Actual: Agent said "{actual_str}"')

                    failure = SubElement(
                        tc,
                        "failure",
                        message=f"{ar.assertion_type} failed",
                        type="AssertionError",
                    )
                    failure.text = "\n".join(body_parts)

            if result.test_case.description:
                props = SubElement(tc, "properties")
                SubElement(
                    props, "property", name="description", value=result.test_case.description
                )

        # Pretty-print
        raw_xml = tostring(root, encoding="unicode")
        dom = parseString(raw_xml)
        pretty = dom.toprettyxml(indent="  ", encoding=None)
        # Remove the extra xml declaration added by toprettyxml (we add our own)
        lines = pretty.splitlines()
        if lines and lines[0].startswith("<?xml"):
            lines[0] = '<?xml version="1.0" encoding="UTF-8"?>'
        return "\n".join(lines)

    def write(self, suite: TestSuiteResult, output_path: Path) -> None:
        """Write JUnit XML to a file."""
        output_path.parent.mkdir(parents=True, exist_ok=True)
        xml_content = self.generate(suite)
        output_path.write_text(xml_content, encoding="utf-8")
