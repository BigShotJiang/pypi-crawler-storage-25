"""Rich-based terminal reporter for tailtest test results."""

from __future__ import annotations

from itertools import groupby

from rich.console import Console
from rich.text import Text

from tailtest.models import AssertionResult, TestResult, TestSuiteResult

VERSION = "0.1.0"

# ── Symbols ──────────────────────────────────────────────────────────────────
SYM_PASS = "\u2713"  # ✓
SYM_FAIL = "\u2717"  # ✗
SYM_WARN = "\u26a0"  # ⚠
SYM_PIPE = "\u2502"  # │
RULE_CHAR = "\u2501"  # ━


def _format_duration(ms: float) -> str:
    """Format milliseconds into a human-friendly string."""
    if ms < 1000:
        return f"{ms:.0f}ms"
    return f"{ms / 1000:.1f}s"


def _format_cost(usd: float) -> str:
    """Format cost in USD."""
    if usd < 0.001:
        return f"${usd:.4f}"
    if usd < 1.0:
        return f"${usd:.3f}"
    return f"${usd:.2f}"


def _derive_source_file(result: TestResult) -> str:
    """Derive a source file path from a test result.

    Uses test_case tags for a 'file:...' tag, otherwise falls back to
    a slugified test name.
    """
    for tag in result.test_case.tags:
        if tag.startswith("file:"):
            return tag[5:]
    # Fallback: synthesize from the test name prefix
    name = result.test_case.name
    parts = name.rsplit("_", 1)
    if len(parts) == 2:
        return f"tests/test_{parts[0]}.py"
    return "tests/tests.py"


def _count_by_type(results: list[TestResult]) -> dict[str, int]:
    """Count tests by assertion type for the header."""
    type_counts: dict[str, int] = {}
    for r in results:
        for ar in r.assertion_results:
            key = ar.assertion_type
            type_counts[key] = type_counts.get(key, 0) + 1
    return type_counts


class TerminalReporter:
    """Rich-based terminal reporter that produces polished CLI output."""

    def __init__(self, console: Console | None = None, verbose: bool = False) -> None:
        self.console = console or Console()
        self.verbose = verbose

    # ── Header ───────────────────────────────────────────────────────────────

    def print_header(
        self,
        agent_info: str,
        test_count: int,
        type_counts: dict[str, int] | None = None,
    ) -> None:
        """Print the test run header."""
        self.console.print()

        # Title line
        title = Text()
        title.append("  tailtest", style="bold cyan")
        title.append(f" v{VERSION}", style="dim")
        title.append(" \u2014 AI Agent Testing Framework", style="dim")
        self.console.print(title)
        self.console.print()

        # Agent line
        if agent_info:
            agent_line = Text("  Agent: ", style="bold")
            agent_line.append(agent_info, style="underline blue")
            self.console.print(agent_line)

        # Test count line
        tests_line = Text(f"  Tests: ", style="bold")
        tests_line.append(f"{test_count} found", style="white")
        if type_counts:
            parts = [f"{v} {k}" for k, v in type_counts.items()]
            tests_line.append(f" ({', '.join(parts)})", style="dim")
        self.console.print(tests_line)

        self.console.print()
        self._print_rule()

    # ── Single test result ───────────────────────────────────────────────────

    def print_result(self, result: TestResult) -> None:
        """Print a single test result (pass/fail with details)."""
        name = result.test_case.name
        duration = _format_duration(result.duration_ms)
        cost = _format_cost(result.cost_usd)

        # Determine status
        has_warning = not result.passed and all(
            ar.passed or ar.assertion_type == "warning" for ar in result.assertion_results
        )

        if result.passed:
            symbol = SYM_PASS
            style = "green"
        elif has_warning:
            symbol = SYM_WARN
            style = "yellow"
        else:
            symbol = SYM_FAIL
            style = "red"

        # Build the result line with right-aligned timing/cost
        width = self.console.width or 80
        left = f"    {symbol} {name}"
        right = f"{duration}   {cost}"
        padding = max(1, width - len(left) - len(right) - 2)

        line = Text()
        line.append(f"    {symbol} ", style=style)
        line.append(name)
        line.append(" " * padding)
        line.append(duration, style="dim")
        line.append("   ", style="dim")
        line.append(cost, style="dim")
        self.console.print(line)

        # Print failure details
        if not result.passed:
            self._print_failure_details(result)

    def _print_failure_details(self, result: TestResult) -> None:
        """Print indented failure details with pipe prefix."""
        failed_assertions = [ar for ar in result.assertion_results if not ar.passed]

        for ar in failed_assertions:
            self.console.print(
                Text(f"      {SYM_PIPE} ", style="red")
                + Text("FAILED: ", style="red bold")
                + Text(ar.message, style="red")
            )
            if ar.actual is not None:
                actual_str = str(ar.actual)
                if len(actual_str) > 120:
                    actual_str = actual_str[:117] + "..."
                self.console.print(
                    Text(f"      {SYM_PIPE} ", style="red")
                    + Text(f'Agent said: "{actual_str}"', style="dim")
                )
            if ar.expected is not None:
                self.console.print(
                    Text(f"      {SYM_PIPE} ", style="red")
                    + Text(f"Expected: {ar.expected}", style="dim")
                )

        # In verbose mode, also show the full agent response
        if self.verbose and result.agent_response.content:
            content = result.agent_response.content
            if len(content) > 200:
                content = content[:197] + "..."
            self.console.print(
                Text(f"      {SYM_PIPE} ", style="dim")
                + Text(f"Response: {content}", style="dim italic")
            )

    # ── File grouping ────────────────────────────────────────────────────────

    def _print_file_group(self, source_file: str, results: list[TestResult]) -> None:
        """Print a group of results under a file heading."""
        self.console.print()
        self.console.print(Text(f"  {source_file}", style="bold"))
        for result in results:
            self.print_result(result)

    # ── Summary ──────────────────────────────────────────────────────────────

    def print_summary(self, suite: TestSuiteResult) -> None:
        """Print the final summary."""
        self.console.print()
        self._print_rule()
        self.console.print()

        warnings = suite.total - suite.passed - suite.failed - suite.skipped

        # Results line
        results_line = Text("  Results: ", style="bold")
        results_line.append(f"{suite.passed} passed", style="green bold")
        if suite.failed > 0:
            results_line.append(", ")
            results_line.append(f"{suite.failed} failed", style="red bold")
        if warnings > 0:
            results_line.append(", ")
            results_line.append(f"{warnings} warning", style="yellow bold")
        if suite.skipped > 0:
            results_line.append(", ")
            results_line.append(f"{suite.skipped} skipped", style="dim")
        self.console.print(results_line)

        # Duration
        duration_line = Text("  Duration: ", style="bold")
        duration_line.append(_format_duration(suite.duration_ms))
        self.console.print(duration_line)

        # Cost
        cost_line = Text("  Cost: ", style="bold")
        cost_line.append(_format_cost(suite.total_cost_usd))
        self.console.print(cost_line)

        # Reliability score if present
        if suite.reliability_score is not None:
            rel_line = Text("  Reliability: ", style="bold")
            pct = suite.reliability_score * 100
            style = "green" if pct >= 90 else "yellow" if pct >= 70 else "red"
            rel_line.append(f"{pct:.1f}%", style=style)
            self.console.print(rel_line)

        self.console.print()

    # ── Full report ──────────────────────────────────────────────────────────

    def report(self, suite: TestSuiteResult, agent_info: str = "") -> None:
        """Print the complete report."""
        type_counts = _count_by_type(suite.results)
        self.print_header(agent_info, suite.total, type_counts)

        # Group results by source file
        keyed = [(self._source_key(r), r) for r in suite.results]
        for source_file, group in groupby(keyed, key=lambda x: x[0]):
            results = [r for _, r in group]
            self._print_file_group(source_file, results)

        self.print_summary(suite)

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _print_rule(self) -> None:
        """Print a horizontal rule."""
        width = min((self.console.width or 80) - 4, 76)
        self.console.print(Text("  " + RULE_CHAR * width, style="dim"))

    @staticmethod
    def _source_key(result: TestResult) -> str:
        """Stable grouping key for a test result."""
        return _derive_source_file(result)
