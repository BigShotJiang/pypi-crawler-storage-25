"""Drift detector — monitors quality drift over time.

Wraps :class:`FailureDetector` with higher-level operations: baseline
management from run IDs, comparison against stored baselines, and
detection from ingested production traces.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from tailtest.models import AgentResponse
from tailtest.production.failure_detector import (
    DriftAlert,
    FailureDetector,
    QualityMetrics,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Default paths
# ---------------------------------------------------------------------------

_DEFAULT_BASELINE_PATH = Path(".tailtest/baselines/current.json")
_DEFAULT_REPORTS_DIR = Path(".tailtest/reports")
_DEFAULT_TRACES_DIR = Path(".tailtest/traces")


class DriftDetector:
    """Monitors quality drift over time.

    Usage::

        detector = DriftDetector()
        await detector.set_baseline_from_run("run-123")
        alerts = await detector.compare_to_baseline(new_responses)
    """

    def __init__(
        self,
        baseline_path: Path | None = None,
        reports_dir: Path | None = None,
    ) -> None:
        self.baseline_path = baseline_path or _DEFAULT_BASELINE_PATH
        self.reports_dir = reports_dir or _DEFAULT_REPORTS_DIR
        self._detector = FailureDetector()

        # Auto-load baseline if file exists
        if self.baseline_path.exists():
            try:
                self._detector.load_baseline(self.baseline_path)
            except Exception:
                logger.warning(
                    "Could not load baseline from %s", self.baseline_path
                )

    # ------------------------------------------------------------------ #
    # Properties
    # ------------------------------------------------------------------ #

    @property
    def baseline(self) -> QualityMetrics | None:
        """The current baseline metrics, or ``None`` if not set."""
        return self._detector.baseline

    @property
    def history(self) -> list[QualityMetrics]:
        """History of computed metrics."""
        return self._detector.history

    # ------------------------------------------------------------------ #
    # Baseline management
    # ------------------------------------------------------------------ #

    async def set_baseline_from_run(self, run_id: str) -> QualityMetrics:
        """Set baseline from a specific test run's results.

        Looks for ``{reports_dir}/{run_id}.json`` (or similar) and extracts
        ``AgentResponse`` data to compute baseline metrics.

        Parameters
        ----------
        run_id:
            Identifier for a previous test run whose results should become
            the quality baseline.

        Returns
        -------
        QualityMetrics
            The computed baseline metrics.
        """
        # Try to find the run report
        report_path = self._find_run_report(run_id)
        if report_path is None:
            raise FileNotFoundError(
                f"No report found for run '{run_id}' in {self.reports_dir}"
            )

        responses = self._extract_responses_from_report(report_path)
        if not responses:
            raise ValueError(
                f"No agent responses found in report for run '{run_id}'"
            )

        metrics = await self._detector.compute_metrics(responses)
        self._detector.set_baseline(metrics)
        self._detector.save_baseline(self.baseline_path)

        logger.info(
            "Baseline set from run '%s' (%d responses)", run_id, len(responses)
        )
        return metrics

    async def set_baseline_from_responses(
        self, responses: list[AgentResponse]
    ) -> QualityMetrics:
        """Set baseline directly from a list of responses.

        Parameters
        ----------
        responses:
            Agent responses to use as the quality baseline.

        Returns
        -------
        QualityMetrics
            The computed baseline metrics.
        """
        metrics = await self._detector.compute_metrics(responses)
        self._detector.set_baseline(metrics)
        self._detector.save_baseline(self.baseline_path)
        return metrics

    # ------------------------------------------------------------------ #
    # Drift comparison
    # ------------------------------------------------------------------ #

    async def compare_to_baseline(
        self, responses: list[AgentResponse]
    ) -> list[DriftAlert]:
        """Compare current responses to baseline.

        Parameters
        ----------
        responses:
            Current batch of agent responses to compare against baseline.

        Returns
        -------
        list[DriftAlert]
            List of alerts for any detected quality drift.
        """
        if self._detector.baseline is None:
            raise ValueError(
                "No baseline set. Use set_baseline_from_run() or "
                "set_baseline_from_responses() first."
            )

        current = await self._detector.compute_metrics(responses)
        return self._detector.detect_drift(current)

    async def detect_from_traces(self, traces_dir: Path | None = None) -> list[DriftAlert]:
        """Detect drift from ingested production traces.

        Reads trace files from ``traces_dir``, converts them to
        ``AgentResponse`` objects, and compares against the stored baseline.

        Parameters
        ----------
        traces_dir:
            Directory containing trace JSON files. Defaults to
            ``.tailtest/traces/``.

        Returns
        -------
        list[DriftAlert]
            List of drift alerts.
        """
        traces_dir = traces_dir or _DEFAULT_TRACES_DIR

        if not traces_dir.exists():
            raise FileNotFoundError(f"Traces directory not found: {traces_dir}")

        responses = self._load_traces(traces_dir)
        if not responses:
            logger.warning("No traces found in %s", traces_dir)
            return []

        return await self.compare_to_baseline(responses)

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #

    def _find_run_report(self, run_id: str) -> Path | None:
        """Find a report file matching the given run ID."""
        if not self.reports_dir.exists():
            return None

        # Try exact match first
        candidates = [
            self.reports_dir / f"{run_id}.json",
            self.reports_dir / f"run-{run_id}.json",
            self.reports_dir / f"report-{run_id}.json",
        ]
        for path in candidates:
            if path.exists():
                return path

        # Try prefix match
        for path in sorted(self.reports_dir.glob("*.json")):
            if run_id in path.stem:
                return path

        return None

    def _extract_responses_from_report(
        self, report_path: Path
    ) -> list[AgentResponse]:
        """Extract AgentResponse objects from a run report JSON file."""
        data = json.loads(report_path.read_text())

        responses: list[AgentResponse] = []

        # Handle TestSuiteResult format
        results = data.get("results", [])
        for result in results:
            agent_resp = result.get("agent_response")
            if agent_resp:
                responses.append(AgentResponse(**agent_resp))

        return responses

    def _load_traces(self, traces_dir: Path) -> list[AgentResponse]:
        """Load AgentResponse objects from trace files."""
        responses: list[AgentResponse] = []

        for trace_file in sorted(traces_dir.glob("*.json")):
            try:
                data = json.loads(trace_file.read_text())

                # Handle single response
                if "content" in data:
                    responses.append(AgentResponse(**data))
                # Handle array of responses
                elif isinstance(data, list):
                    for item in data:
                        if isinstance(item, dict) and "content" in item:
                            responses.append(AgentResponse(**item))
                # Handle wrapped format
                elif "responses" in data:
                    for item in data["responses"]:
                        responses.append(AgentResponse(**item))

            except Exception as exc:
                logger.warning(
                    "Could not parse trace file %s: %s", trace_file, exc
                )

        return responses
