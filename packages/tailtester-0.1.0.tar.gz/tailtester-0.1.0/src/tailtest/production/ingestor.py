"""Trace ingestion pipeline — ingest OTel traces and convert to AgentResponse."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

import httpx

from tailtest.models import AgentResponse, TokenUsage, ToolCall

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class TraceSpan:
    """A single span from an OTel trace."""

    trace_id: str
    span_id: str
    name: str
    start_time: datetime
    end_time: datetime
    attributes: dict = field(default_factory=dict)
    status: str = "ok"
    parent_span_id: str | None = None


@dataclass
class AgentTrace:
    """A complete agent interaction trace."""

    trace_id: str
    spans: list[TraceSpan]
    timestamp: datetime
    agent_response: AgentResponse | None = None

    def to_agent_response(self) -> AgentResponse:
        """Convert trace spans into an AgentResponse for assertion evaluation.

        Follows OpenInference semantic conventions:
        - ``llm.model_name`` for the model
        - ``llm.token_count.prompt``, ``llm.token_count.completion`` for tokens
        - ``output.value`` / ``llm.output_messages`` for content
        - Spans named ``tool.*`` or with ``tool.name`` attribute are tool calls
        """
        if self.agent_response is not None:
            return self.agent_response

        content = ""
        model: str | None = None
        prompt_tokens = 0
        completion_tokens = 0
        cost_usd: float | None = None
        tool_calls: list[ToolCall] = []

        # Sort spans by start time to process in order
        sorted_spans = sorted(self.spans, key=lambda s: s.start_time)

        for span in sorted_spans:
            attrs = span.attributes

            # Extract model name
            if model is None:
                model = (
                    attrs.get("llm.model_name")
                    or attrs.get("gen_ai.request.model")
                    or attrs.get("llm.model")
                )

            # Extract token counts
            pt = attrs.get("llm.token_count.prompt") or attrs.get(
                "gen_ai.usage.prompt_tokens"
            )
            ct = attrs.get("llm.token_count.completion") or attrs.get(
                "gen_ai.usage.completion_tokens"
            )
            if pt is not None:
                prompt_tokens += int(pt)
            if ct is not None:
                completion_tokens += int(ct)

            # Extract cost if present
            span_cost = attrs.get("llm.cost") or attrs.get("gen_ai.usage.cost")
            if span_cost is not None:
                cost_usd = (cost_usd or 0.0) + float(span_cost)

            # Extract output content from the outermost LLM span
            output = attrs.get("output.value") or attrs.get("llm.output_messages")
            if output and not content:
                content = str(output)

            # Extract tool calls from tool spans
            tool_name = attrs.get("tool.name")
            if tool_name or span.name.startswith("tool."):
                resolved_name = tool_name or span.name.removeprefix("tool.")
                tool_args_raw = attrs.get("tool.parameters") or attrs.get(
                    "tool.arguments", "{}"
                )
                try:
                    tool_args = (
                        json.loads(tool_args_raw)
                        if isinstance(tool_args_raw, str)
                        else tool_args_raw
                    )
                except (json.JSONDecodeError, TypeError):
                    tool_args = {}
                tool_result = attrs.get("tool.result") or attrs.get("output.value")
                duration = (
                    (span.end_time - span.start_time).total_seconds() * 1000
                )
                tool_calls.append(
                    ToolCall(
                        name=str(resolved_name),
                        arguments=tool_args if isinstance(tool_args, dict) else {},
                        result=tool_result,
                        duration_ms=duration,
                    )
                )

        # Calculate total latency from earliest start to latest end
        if sorted_spans:
            latest_end = max(s.end_time for s in sorted_spans)
            latency_ms = (
                latest_end - sorted_spans[0].start_time
            ).total_seconds() * 1000
        else:
            latency_ms = 0.0

        total_tokens = prompt_tokens + completion_tokens

        response = AgentResponse(
            content=content,
            tool_calls=tool_calls,
            model=model,
            tokens_used=TokenUsage(
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=total_tokens,
            ),
            latency_ms=latency_ms,
            cost_usd=cost_usd,
            trace_id=self.trace_id,
        )
        self.agent_response = response
        return response


# ---------------------------------------------------------------------------
# OTLP JSON parsing helpers
# ---------------------------------------------------------------------------


def _parse_otlp_timestamp(ts: int | str) -> datetime:
    """Parse an OTLP nanosecond timestamp into a datetime."""
    nanos = int(ts)
    return datetime.fromtimestamp(nanos / 1e9, tz=timezone.utc)


def _extract_attributes(attr_list: list[dict]) -> dict:
    """Convert OTLP attribute list to a flat dict."""
    result: dict = {}
    for attr in attr_list:
        key = attr.get("key", "")
        value_obj = attr.get("value", {})
        # OTLP values have typed wrappers: stringValue, intValue, etc.
        if "stringValue" in value_obj:
            result[key] = value_obj["stringValue"]
        elif "intValue" in value_obj:
            result[key] = int(value_obj["intValue"])
        elif "doubleValue" in value_obj:
            result[key] = float(value_obj["doubleValue"])
        elif "boolValue" in value_obj:
            result[key] = bool(value_obj["boolValue"])
        elif "arrayValue" in value_obj:
            result[key] = value_obj["arrayValue"]
        else:
            result[key] = str(value_obj)
    return result


def _parse_otlp_spans(payload: dict) -> list[TraceSpan]:
    """Parse OTLP/HTTP JSON ``/v1/traces`` payload into TraceSpan objects."""
    spans: list[TraceSpan] = []

    for resource_spans in payload.get("resourceSpans", []):
        for scope_spans in resource_spans.get("scopeSpans", []):
            for raw_span in scope_spans.get("spans", []):
                attrs = _extract_attributes(raw_span.get("attributes", []))
                status_obj = raw_span.get("status", {})
                status_code = status_obj.get("code", 0)
                status = "error" if status_code == 2 else "ok"

                spans.append(
                    TraceSpan(
                        trace_id=raw_span.get("traceId", ""),
                        span_id=raw_span.get("spanId", ""),
                        name=raw_span.get("name", ""),
                        start_time=_parse_otlp_timestamp(
                            raw_span.get("startTimeUnixNano", 0)
                        ),
                        end_time=_parse_otlp_timestamp(
                            raw_span.get("endTimeUnixNano", 0)
                        ),
                        attributes=attrs,
                        status=status,
                        parent_span_id=raw_span.get("parentSpanId") or None,
                    )
                )

    return spans


# ---------------------------------------------------------------------------
# OTLP HTTP receiver (raw asyncio — no heavy framework)
# ---------------------------------------------------------------------------


class _OTLPProtocol(asyncio.Protocol):
    """Simple HTTP/1.1 protocol handler for OTLP/HTTP JSON receiver."""

    def __init__(self, ingestor: TraceIngestor) -> None:
        self._ingestor = ingestor
        self._buffer = b""
        self._transport: asyncio.Transport | None = None

    def connection_made(self, transport: asyncio.Transport) -> None:  # type: ignore[override]
        self._transport = transport

    def data_received(self, data: bytes) -> None:
        self._buffer += data
        # Check if we have the full HTTP request (headers + body)
        if b"\r\n\r\n" not in self._buffer:
            return

        header_end = self._buffer.index(b"\r\n\r\n")
        header_bytes = self._buffer[:header_end]
        body_start = header_end + 4

        # Parse Content-Length
        content_length = 0
        for line in header_bytes.split(b"\r\n"):
            if line.lower().startswith(b"content-length:"):
                content_length = int(line.split(b":")[1].strip())

        # Wait for full body
        body = self._buffer[body_start:]
        if len(body) < content_length:
            return

        body = body[:content_length]

        # Parse the request line
        request_line = header_bytes.split(b"\r\n")[0].decode("utf-8", errors="replace")
        parts = request_line.split(" ")
        method = parts[0] if parts else "GET"
        path = parts[1] if len(parts) > 1 else "/"

        if method == "POST" and path == "/v1/traces":
            try:
                payload = json.loads(body)
                spans = _parse_otlp_spans(payload)
                if spans:
                    # Group spans by trace_id
                    trace_map: dict[str, list[TraceSpan]] = {}
                    for span in spans:
                        trace_map.setdefault(span.trace_id, []).append(span)

                    for trace_id, trace_spans in trace_map.items():
                        earliest = min(s.start_time for s in trace_spans)
                        trace = AgentTrace(
                            trace_id=trace_id,
                            spans=trace_spans,
                            timestamp=earliest,
                        )
                        self._ingestor.traces.append(trace)
                        self._ingestor._trace_count += 1
                        self._ingestor._span_count += len(trace_spans)

                    logger.info(
                        "Ingested %d spans across %d traces",
                        len(spans),
                        len(trace_map),
                    )

                response_body = json.dumps(
                    {"partialSuccess": {}}
                ).encode("utf-8")
                self._send_response(200, response_body)
            except (json.JSONDecodeError, KeyError) as exc:
                error_body = json.dumps(
                    {"error": str(exc)}
                ).encode("utf-8")
                self._send_response(400, error_body)
        elif method == "GET" and path == "/health":
            health = json.dumps(
                {
                    "status": "ok",
                    "traces": self._ingestor._trace_count,
                    "spans": self._ingestor._span_count,
                }
            ).encode("utf-8")
            self._send_response(200, health)
        else:
            self._send_response(404, b'{"error": "not found"}')

        # Reset buffer for next request (keep-alive)
        self._buffer = self._buffer[body_start + content_length:]

    def _send_response(self, status: int, body: bytes) -> None:
        reason = {200: "OK", 400: "Bad Request", 404: "Not Found"}.get(status, "OK")
        header = (
            f"HTTP/1.1 {status} {reason}\r\n"
            f"Content-Type: application/json\r\n"
            f"Content-Length: {len(body)}\r\n"
            f"Connection: keep-alive\r\n"
            f"\r\n"
        )
        if self._transport:
            self._transport.write(header.encode("utf-8") + body)


# ---------------------------------------------------------------------------
# TraceIngestor — the main ingestion orchestrator
# ---------------------------------------------------------------------------


class TraceIngestor:
    """Ingests agent traces from OTLP, Langfuse, LangSmith, or JSON files."""

    def __init__(self, storage_dir: Path | None = None) -> None:
        self.storage_dir = storage_dir or Path(".tailtest/traces")
        self.traces: list[AgentTrace] = []
        self._trace_count: int = 0
        self._span_count: int = 0
        self._server: asyncio.Server | None = None

    # ---- OTLP receiver ----

    async def start_otlp_receiver(self, port: int = 4318) -> asyncio.Server:
        """Start an HTTP OTLP receiver on the given port.

        Accepts ``POST /v1/traces`` in OTLP/HTTP JSON format.
        Returns the asyncio.Server so the caller can manage lifecycle.
        """
        loop = asyncio.get_running_loop()
        server = await loop.create_server(
            lambda: _OTLPProtocol(self),
            "0.0.0.0",
            port,
            reuse_address=True,
        )
        self._server = server
        logger.info("OTLP receiver listening on port %d", port)
        return server

    async def stop_otlp_receiver(self) -> None:
        """Stop the OTLP receiver."""
        if self._server:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
            logger.info("OTLP receiver stopped")

    # ---- Langfuse connector ----

    async def ingest_from_langfuse(
        self,
        url: str,
        public_key: str | None = None,
        secret_key: str | None = None,
        limit: int = 100,
    ) -> int:
        """Pull traces from Langfuse API.

        Args:
            url: Langfuse instance URL (e.g. ``https://cloud.langfuse.com``).
            public_key: Langfuse public key. Falls back to
                ``LANGFUSE_PUBLIC_KEY`` env var.
            secret_key: Langfuse secret key. Falls back to
                ``LANGFUSE_SECRET_KEY`` env var.
            limit: Maximum number of traces to pull per page.

        Returns:
            Number of traces ingested.
        """
        public_key = public_key or os.environ.get("LANGFUSE_PUBLIC_KEY", "")
        secret_key = secret_key or os.environ.get("LANGFUSE_SECRET_KEY", "")

        if not public_key or not secret_key:
            raise ValueError(
                "Langfuse credentials required. Set LANGFUSE_PUBLIC_KEY and "
                "LANGFUSE_SECRET_KEY environment variables or pass them directly."
            )

        base_url = url.rstrip("/")
        ingested = 0
        page = 1

        async with httpx.AsyncClient(timeout=30.0) as client:
            while True:
                resp = await client.get(
                    f"{base_url}/api/public/traces",
                    params={"page": page, "limit": limit},
                    auth=(public_key, secret_key),
                )
                resp.raise_for_status()
                data = resp.json()

                traces_data = data.get("data", [])
                if not traces_data:
                    break

                for raw_trace in traces_data:
                    trace = self._parse_langfuse_trace(raw_trace, base_url, client)
                    self.traces.append(trace)
                    self._trace_count += 1
                    self._span_count += len(trace.spans)
                    ingested += 1

                # Check pagination
                meta = data.get("meta", {})
                total_pages = meta.get("totalPages", 1)
                if page >= total_pages:
                    break
                page += 1

        logger.info("Ingested %d traces from Langfuse", ingested)
        return ingested

    def _parse_langfuse_trace(
        self,
        raw: dict,
        base_url: str = "",
        client: httpx.AsyncClient | None = None,
    ) -> AgentTrace:
        """Convert a Langfuse trace dict to AgentTrace."""
        trace_id = raw.get("id", "")
        timestamp_str = raw.get("timestamp", "")
        try:
            timestamp = datetime.fromisoformat(timestamp_str.replace("Z", "+00:00"))
        except (ValueError, AttributeError):
            timestamp = datetime.now(tz=timezone.utc)

        spans: list[TraceSpan] = []

        # Langfuse traces have observations (generations, spans, events)
        for obs in raw.get("observations", []):
            obs_id = obs.get("id", "")
            obs_type = obs.get("type", "SPAN")
            obs_name = obs.get("name", obs_type)

            start_str = obs.get("startTime", timestamp_str)
            end_str = obs.get("endTime", start_str)
            try:
                start = datetime.fromisoformat(start_str.replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                start = timestamp
            try:
                end = datetime.fromisoformat(end_str.replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                end = start

            attrs: dict = {}
            # Map Langfuse fields to OpenInference attributes
            if obs.get("model"):
                attrs["llm.model_name"] = obs["model"]
            usage = obs.get("usage", {}) or {}
            if usage.get("promptTokens"):
                attrs["llm.token_count.prompt"] = usage["promptTokens"]
            if usage.get("completionTokens"):
                attrs["llm.token_count.completion"] = usage["completionTokens"]
            if obs.get("output"):
                attrs["output.value"] = (
                    json.dumps(obs["output"])
                    if isinstance(obs["output"], dict)
                    else str(obs["output"])
                )
            if obs.get("calculatedTotalCost") is not None:
                attrs["llm.cost"] = obs["calculatedTotalCost"]
            if obs.get("input"):
                attrs["input.value"] = (
                    json.dumps(obs["input"])
                    if isinstance(obs["input"], dict)
                    else str(obs["input"])
                )

            # Detect tool calls
            if obs_type == "SPAN" and obs.get("metadata", {}).get("tool_name"):
                attrs["tool.name"] = obs["metadata"]["tool_name"]
                if obs.get("input"):
                    attrs["tool.parameters"] = (
                        json.dumps(obs["input"])
                        if isinstance(obs["input"], dict)
                        else str(obs["input"])
                    )

            status = "error" if obs.get("level") == "ERROR" else "ok"
            parent = obs.get("parentObservationId")

            spans.append(
                TraceSpan(
                    trace_id=trace_id,
                    span_id=obs_id,
                    name=obs_name,
                    start_time=start,
                    end_time=end,
                    attributes=attrs,
                    status=status,
                    parent_span_id=parent,
                )
            )

        return AgentTrace(
            trace_id=trace_id,
            spans=spans,
            timestamp=timestamp,
        )

    # ---- LangSmith connector ----

    async def ingest_from_langsmith(
        self,
        api_key: str | None = None,
        project_name: str = "default",
        limit: int = 100,
    ) -> int:
        """Pull traces from LangSmith API.

        Args:
            api_key: LangSmith API key. Falls back to ``LANGSMITH_API_KEY``
                env var.
            project_name: LangSmith project name to pull runs from.
            limit: Maximum number of runs to pull per page.

        Returns:
            Number of traces ingested.
        """
        api_key = api_key or os.environ.get("LANGSMITH_API_KEY", "")
        if not api_key:
            raise ValueError(
                "LangSmith API key required. Set LANGSMITH_API_KEY environment "
                "variable or pass it directly."
            )

        base_url = os.environ.get(
            "LANGSMITH_ENDPOINT", "https://api.smith.langchain.com"
        )
        ingested = 0
        offset = 0

        async with httpx.AsyncClient(timeout=30.0) as client:
            while True:
                resp = await client.post(
                    f"{base_url}/runs/query",
                    headers={"x-api-key": api_key},
                    json={
                        "session_name": project_name,
                        "is_root": True,
                        "limit": limit,
                        "offset": offset,
                    },
                )
                resp.raise_for_status()
                data = resp.json()

                runs = data.get("runs", data) if isinstance(data, dict) else data
                if not runs or not isinstance(runs, list):
                    break

                for raw_run in runs:
                    trace = self._parse_langsmith_run(raw_run)
                    self.traces.append(trace)
                    self._trace_count += 1
                    self._span_count += len(trace.spans)
                    ingested += 1

                if len(runs) < limit:
                    break
                offset += limit

        logger.info("Ingested %d traces from LangSmith", ingested)
        return ingested

    def _parse_langsmith_run(self, raw: dict) -> AgentTrace:
        """Convert a LangSmith run dict to AgentTrace."""
        trace_id = raw.get("trace_id", raw.get("id", ""))

        start_str = raw.get("start_time", "")
        end_str = raw.get("end_time", start_str)
        try:
            start = datetime.fromisoformat(str(start_str).replace("Z", "+00:00"))
        except (ValueError, AttributeError):
            start = datetime.now(tz=timezone.utc)
        try:
            end = datetime.fromisoformat(str(end_str).replace("Z", "+00:00"))
        except (ValueError, AttributeError):
            end = start

        attrs: dict = {}
        # Map LangSmith fields to OpenInference attributes
        extras = raw.get("extra", {}) or {}
        metadata = extras.get("metadata", {}) or {}

        model = (
            metadata.get("ls_model_name")
            or extras.get("invocation_params", {}).get("model_name")
        )
        if model:
            attrs["llm.model_name"] = model

        # Token usage
        token_usage = raw.get("token_usage") or raw.get("total_tokens") or {}
        if isinstance(token_usage, dict):
            if token_usage.get("prompt_tokens"):
                attrs["llm.token_count.prompt"] = token_usage["prompt_tokens"]
            if token_usage.get("completion_tokens"):
                attrs["llm.token_count.completion"] = token_usage["completion_tokens"]

        # Output
        outputs = raw.get("outputs", {})
        if outputs:
            output_text = outputs.get("output", outputs.get("text", ""))
            if output_text:
                attrs["output.value"] = str(output_text)
            elif isinstance(outputs, dict):
                attrs["output.value"] = json.dumps(outputs)

        # Cost
        total_cost = raw.get("total_cost")
        if total_cost is not None:
            attrs["llm.cost"] = total_cost

        run_type = raw.get("run_type", "chain")
        if run_type == "tool":
            attrs["tool.name"] = raw.get("name", "")
            inputs = raw.get("inputs", {})
            if inputs:
                attrs["tool.parameters"] = json.dumps(inputs) if isinstance(inputs, dict) else str(inputs)

        status = "error" if raw.get("error") else "ok"

        root_span = TraceSpan(
            trace_id=trace_id,
            span_id=raw.get("id", ""),
            name=raw.get("name", ""),
            start_time=start,
            end_time=end,
            attributes=attrs,
            status=status,
            parent_span_id=raw.get("parent_run_id"),
        )

        # LangSmith child runs become child spans
        spans = [root_span]
        for child in raw.get("child_runs", []):
            child_trace = self._parse_langsmith_run(child)
            for child_span in child_trace.spans:
                child_span.trace_id = trace_id
            spans.extend(child_trace.spans)

        return AgentTrace(
            trace_id=trace_id,
            spans=spans,
            timestamp=start,
        )

    # ---- JSON file ingestion (for testing) ----

    async def ingest_from_json(self, file_path: Path) -> int:
        """Ingest traces from a JSON file.

        Supports two formats:
        1. OTLP JSON (has ``resourceSpans`` key)
        2. Simple format: a list of trace dicts with ``trace_id``, ``spans``,
           and ``timestamp``.

        Returns:
            Number of traces ingested.
        """
        raw = json.loads(file_path.read_text(encoding="utf-8"))

        # OTLP format
        if isinstance(raw, dict) and "resourceSpans" in raw:
            spans = _parse_otlp_spans(raw)
            trace_map: dict[str, list[TraceSpan]] = {}
            for span in spans:
                trace_map.setdefault(span.trace_id, []).append(span)

            for tid, tspans in trace_map.items():
                earliest = min(s.start_time for s in tspans)
                self.traces.append(
                    AgentTrace(trace_id=tid, spans=tspans, timestamp=earliest)
                )
                self._trace_count += 1
                self._span_count += len(tspans)

            logger.info("Ingested %d traces from OTLP JSON file", len(trace_map))
            return len(trace_map)

        # Simple format: list of traces
        traces_list = raw if isinstance(raw, list) else [raw]
        ingested = 0

        for item in traces_list:
            trace_id = item.get("trace_id", f"json-{ingested}")
            ts_str = item.get("timestamp", "")
            try:
                timestamp = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                timestamp = datetime.now(tz=timezone.utc)

            spans: list[TraceSpan] = []
            for raw_span in item.get("spans", []):
                start_str = raw_span.get("start_time", ts_str)
                end_str = raw_span.get("end_time", start_str)
                try:
                    start = datetime.fromisoformat(
                        str(start_str).replace("Z", "+00:00")
                    )
                except (ValueError, AttributeError):
                    start = timestamp
                try:
                    end = datetime.fromisoformat(
                        str(end_str).replace("Z", "+00:00")
                    )
                except (ValueError, AttributeError):
                    end = start

                spans.append(
                    TraceSpan(
                        trace_id=trace_id,
                        span_id=raw_span.get("span_id", ""),
                        name=raw_span.get("name", ""),
                        start_time=start,
                        end_time=end,
                        attributes=raw_span.get("attributes", {}),
                        status=raw_span.get("status", "ok"),
                        parent_span_id=raw_span.get("parent_span_id"),
                    )
                )

            self.traces.append(
                AgentTrace(trace_id=trace_id, spans=spans, timestamp=timestamp)
            )
            self._trace_count += 1
            self._span_count += len(spans)
            ingested += 1

        logger.info("Ingested %d traces from JSON file", ingested)
        return ingested

    # ---- Conversion ----

    def get_agent_responses(self) -> list[AgentResponse]:
        """Convert all ingested traces to AgentResponse objects for evaluation."""
        return [trace.to_agent_response() for trace in self.traces]

    # ---- Persistence ----

    def save_traces(self) -> Path:
        """Persist all traces to ``self.storage_dir`` as JSON.

        Returns:
            Path to the saved file.
        """
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        out_path = self.storage_dir / f"traces-{int(time.time())}.json"

        serializable = []
        for trace in self.traces:
            serializable.append(
                {
                    "trace_id": trace.trace_id,
                    "timestamp": trace.timestamp.isoformat(),
                    "spans": [
                        {
                            "trace_id": s.trace_id,
                            "span_id": s.span_id,
                            "name": s.name,
                            "start_time": s.start_time.isoformat(),
                            "end_time": s.end_time.isoformat(),
                            "attributes": s.attributes,
                            "status": s.status,
                            "parent_span_id": s.parent_span_id,
                        }
                        for s in trace.spans
                    ],
                }
            )

        out_path.write_text(
            json.dumps(serializable, indent=2, default=str),
            encoding="utf-8",
        )
        logger.info("Saved %d traces to %s", len(self.traces), out_path)
        return out_path

    def load_traces(self) -> list[AgentTrace]:
        """Load previously saved traces from ``self.storage_dir``.

        Returns:
            List of loaded traces (also appended to ``self.traces``).
        """
        if not self.storage_dir.exists():
            return []

        loaded: list[AgentTrace] = []
        for json_file in sorted(self.storage_dir.glob("traces-*.json")):
            try:
                raw = json.loads(json_file.read_text(encoding="utf-8"))
                for item in raw:
                    trace_id = item.get("trace_id", "")
                    ts_str = item.get("timestamp", "")
                    try:
                        timestamp = datetime.fromisoformat(
                            ts_str.replace("Z", "+00:00")
                        )
                    except (ValueError, AttributeError):
                        timestamp = datetime.now(tz=timezone.utc)

                    spans = []
                    for rs in item.get("spans", []):
                        start_str = rs.get("start_time", ts_str)
                        end_str = rs.get("end_time", start_str)
                        try:
                            start = datetime.fromisoformat(
                                str(start_str).replace("Z", "+00:00")
                            )
                        except (ValueError, AttributeError):
                            start = timestamp
                        try:
                            end = datetime.fromisoformat(
                                str(end_str).replace("Z", "+00:00")
                            )
                        except (ValueError, AttributeError):
                            end = start

                        spans.append(
                            TraceSpan(
                                trace_id=rs.get("trace_id", trace_id),
                                span_id=rs.get("span_id", ""),
                                name=rs.get("name", ""),
                                start_time=start,
                                end_time=end,
                                attributes=rs.get("attributes", {}),
                                status=rs.get("status", "ok"),
                                parent_span_id=rs.get("parent_span_id"),
                            )
                        )

                    trace = AgentTrace(
                        trace_id=trace_id, spans=spans, timestamp=timestamp
                    )
                    loaded.append(trace)

            except (json.JSONDecodeError, KeyError) as exc:
                logger.warning("Failed to load %s: %s", json_file, exc)

        self.traces.extend(loaded)
        self._trace_count += len(loaded)
        self._span_count += sum(len(t.spans) for t in loaded)
        logger.info("Loaded %d traces from %s", len(loaded), self.storage_dir)
        return loaded

    @property
    def stats(self) -> dict[str, int]:
        """Return current ingestion statistics."""
        responses = self.get_agent_responses()
        with_tools = sum(1 for r in responses if r.tool_calls)
        with_model = sum(1 for r in responses if r.model)
        return {
            "traces": self._trace_count,
            "spans": self._span_count,
            "responses_with_tools": with_tools,
            "responses_with_model": with_model,
        }
