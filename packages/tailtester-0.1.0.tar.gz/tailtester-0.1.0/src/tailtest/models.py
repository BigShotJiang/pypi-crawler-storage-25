"""Core Pydantic models shared across all tailtest modules."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field


class TokenUsage(BaseModel):
    """Token consumption for a single LLM call."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class ToolCall(BaseModel):
    """A single tool/function call made by the agent."""

    name: str
    arguments: dict[str, Any]
    result: Any | None = None
    duration_ms: float | None = None


class AgentResponse(BaseModel):
    """A single response from an AI agent."""

    content: str
    tool_calls: list[ToolCall] = Field(default_factory=list)
    model: str | None = None
    tokens_used: TokenUsage | None = None
    latency_ms: float | None = None
    cost_usd: float | None = None
    trace_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class Message(BaseModel):
    """A single message in a conversation."""

    role: Literal["user", "assistant", "system"]
    content: str


class AssertionResult(BaseModel):
    """Result of evaluating a single assertion against an agent response."""

    passed: bool
    assertion_type: str
    expected: Any
    actual: Any
    message: str
    score: float | None = None
    cost_usd: float = 0


class TestCase(BaseModel):
    """A single test case definition."""

    name: str
    description: str | None = None
    input: str | list[Message]
    assertions: list[str]
    tags: list[str] = Field(default_factory=list)
    timeout_ms: int = 30000
    retries: int = 1


class TestResult(BaseModel):
    """Result of running a single test case."""

    test_case: TestCase
    passed: bool
    assertion_results: list[AssertionResult]
    agent_response: AgentResponse
    duration_ms: float
    cost_usd: float
    timestamp: datetime
    trace_id: str | None = None


class TestSuiteResult(BaseModel):
    """Result of running a full test suite."""

    total: int
    passed: int
    failed: int
    skipped: int
    duration_ms: float
    total_cost_usd: float
    results: list[TestResult]
    reliability_score: float | None = None


class ToolDefinition(BaseModel):
    """Definition of a tool/function available to an agent."""

    name: str
    description: str | None = None
    parameters: dict[str, Any]
    required_params: list[str] = Field(default_factory=list)
    example_input: str | None = None


class PromptDefinition(BaseModel):
    """A prompt discovered in agent source code."""

    content: str
    role: str = "system"
    file_path: str | None = None
    line_number: int | None = None


class AgentDefinition(BaseModel):
    """Definition of a discovered AI agent."""

    name: str | None = None
    framework: str
    tools: list[ToolDefinition] = Field(default_factory=list)
    prompts: list[PromptDefinition] = Field(default_factory=list)
    model: str | None = None
    file_path: str | None = None


class ScanResult(BaseModel):
    """Result of scanning a project for agent definitions."""

    framework: str
    framework_version: str | None = None
    tools: list[ToolDefinition]
    prompts: list[PromptDefinition]
    agents: list[AgentDefinition]
    models: list[str]
    env_vars: list[str]
    dependencies: list[str]
    config_files: list[str]
