"""Entry point for `python -m tailtest`."""

from tailtest.cli.main import cli

cli()
