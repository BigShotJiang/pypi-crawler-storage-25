"""Base class for AI framework detectors."""

from __future__ import annotations

import ast
from abc import ABC, abstractmethod
from pathlib import Path

from tailtest.models import AgentDefinition, PromptDefinition, ToolDefinition


class BaseDetector(ABC):
    """Abstract base for framework-specific AST detectors.

    Each detector knows how to recognise one AI framework (OpenAI, Anthropic,
    etc.) by inspecting the AST of a Python source file.  When the framework is
    detected the detector can then extract tools, prompts and agent definitions
    from that same AST.
    """

    # Human-readable name of the framework this detector covers.
    framework_name: str = "unknown"

    @abstractmethod
    def detect(self, file_path: Path, tree: ast.Module) -> bool:
        """Return True if *tree* uses this framework."""
        ...

    @abstractmethod
    def extract_tools(self, file_path: Path, tree: ast.Module) -> list[ToolDefinition]:
        """Pull tool / function definitions out of the AST."""
        ...

    @abstractmethod
    def extract_prompts(self, file_path: Path, tree: ast.Module) -> list[PromptDefinition]:
        """Pull system / user prompts out of the AST."""
        ...

    @abstractmethod
    def extract_agents(self, file_path: Path, tree: ast.Module) -> list[AgentDefinition]:
        """Pull high-level agent definitions out of the AST."""
        ...

    @abstractmethod
    def extract_models(self, file_path: Path, tree: ast.Module) -> list[str]:
        """Return any model name strings found (e.g. 'gpt-4o')."""
        ...

    # ------------------------------------------------------------------ #
    # Shared AST helpers available to all detectors
    # ------------------------------------------------------------------ #

    @staticmethod
    def _has_import(tree: ast.Module, module: str) -> bool:
        """Check whether *tree* contains ``import <module>`` or
        ``from <module> import ...``."""
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name == module or alias.name.startswith(f"{module}."):
                        return True
            elif isinstance(node, ast.ImportFrom):
                if node.module and (
                    node.module == module or node.module.startswith(f"{module}.")
                ):
                    return True
        return False

    @staticmethod
    def _const_value(node: ast.expr) -> str | None:
        """Return the string value of a Constant node, or None."""
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value
        return None

    @staticmethod
    def _find_keyword(call: ast.Call, name: str) -> ast.keyword | None:
        """Find keyword argument *name* in a Call node."""
        for kw in call.keywords:
            if kw.arg == name:
                return kw
        return None

    @staticmethod
    def _find_calls(tree: ast.Module, attr_name: str) -> list[ast.Call]:
        """Find all ``obj.<attr_name>(...)`` calls in the tree."""
        results: list[ast.Call] = []
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            # obj.attr(...)
            if isinstance(func, ast.Attribute) and func.attr == attr_name:
                results.append(node)
            # obj.a.b.attr(...)  — walk the chain
            elif isinstance(func, ast.Attribute):
                chain = []
                cur: ast.expr = func
                while isinstance(cur, ast.Attribute):
                    chain.append(cur.attr)
                    cur = cur.value
                if chain and chain[0] == attr_name:
                    results.append(node)
        return results
