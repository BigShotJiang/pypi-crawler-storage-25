"""Detector for PydanticAI usage."""

from __future__ import annotations

import ast
from pathlib import Path

from tailtest.models import AgentDefinition, PromptDefinition, ToolDefinition

from .base import BaseDetector


class PydanticAIDetector(BaseDetector):
    """Detects and extracts context from PydanticAI code.

    Recognised patterns
    -------------------
    * ``from pydantic_ai import Agent``
    * ``from pydantic_ai.tools import Tool``
    * ``Agent(model="...", system_prompt="...")``
    * ``@agent.tool`` / ``@agent.tool_plain`` decorated functions
    * ``@agent.system_prompt`` decorated functions
    * ``system_prompt`` parameter on Agent constructor
    """

    framework_name = "pydantic_ai"

    # ---- detection --------------------------------------------------- #

    def detect(self, file_path: Path, tree: ast.Module) -> bool:
        return self._has_import(tree, "pydantic_ai")

    # ---- tools ------------------------------------------------------- #

    def extract_tools(self, file_path: Path, tree: ast.Module) -> list[ToolDefinition]:
        tools: list[ToolDefinition] = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if self._has_agent_tool_decorator(node):
                    tools.append(self._tool_from_funcdef(node))
        return tools

    # ---- prompts ----------------------------------------------------- #

    def extract_prompts(self, file_path: Path, tree: ast.Module) -> list[PromptDefinition]:
        prompts: list[PromptDefinition] = []
        seen: set[str] = set()

        # 1) system_prompt keyword on Agent(...)
        for call in self._agent_constructor_calls(tree):
            kw = self._find_keyword(call, "system_prompt")
            if kw is None:
                continue
            val = self._const_value(kw.value)
            if val and val not in seen:
                seen.add(val)
                prompts.append(PromptDefinition(
                    content=val,
                    role="system",
                    file_path=str(file_path),
                    line_number=getattr(kw, "lineno", None),
                ))

        # 2) @agent.system_prompt decorated functions — use docstring / return value
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            if not self._has_system_prompt_decorator(node):
                continue
            # Try the docstring as the prompt content
            docstring = ast.get_docstring(node)
            if docstring and docstring not in seen:
                seen.add(docstring)
                prompts.append(PromptDefinition(
                    content=docstring,
                    role="system",
                    file_path=str(file_path),
                    line_number=getattr(node, "lineno", None),
                ))
                continue
            # Try a simple return "..." statement
            ret_val = self._single_return_string(node)
            if ret_val and ret_val not in seen:
                seen.add(ret_val)
                prompts.append(PromptDefinition(
                    content=ret_val,
                    role="system",
                    file_path=str(file_path),
                    line_number=getattr(node, "lineno", None),
                ))

        return prompts

    # ---- agents ------------------------------------------------------ #

    def extract_agents(self, file_path: Path, tree: ast.Module) -> list[AgentDefinition]:
        agents: list[AgentDefinition] = []

        for call in self._agent_constructor_calls(tree):
            model = self._model_from_agent(call)
            sys_prompt_kw = self._find_keyword(call, "system_prompt")
            prompts: list[PromptDefinition] = []
            if sys_prompt_kw is not None:
                val = self._const_value(sys_prompt_kw.value)
                if val:
                    prompts.append(PromptDefinition(
                        content=val,
                        role="system",
                        file_path=str(file_path),
                        line_number=getattr(sys_prompt_kw, "lineno", None),
                    ))

            # Try to get a name from the assignment target
            name = self._assignment_target_for(tree, call)

            agents.append(AgentDefinition(
                name=name,
                framework="pydantic_ai",
                prompts=prompts,
                model=model,
                file_path=str(file_path),
            ))

        return agents

    # ---- models ------------------------------------------------------ #

    def extract_models(self, file_path: Path, tree: ast.Module) -> list[str]:
        models: list[str] = []
        seen: set[str] = set()
        for call in self._agent_constructor_calls(tree):
            m = self._model_from_agent(call)
            if m and m not in seen:
                seen.add(m)
                models.append(m)
        return models

    # ================================================================== #
    #  Private helpers
    # ================================================================== #

    # -- finding Agent(...) calls -------------------------------------- #

    @staticmethod
    def _agent_constructor_calls(tree: ast.Module) -> list[ast.Call]:
        """Find all ``Agent(...)`` calls."""
        results: list[ast.Call] = []
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            if isinstance(func, ast.Name) and func.id == "Agent":
                results.append(node)
            elif isinstance(func, ast.Attribute) and func.attr == "Agent":
                results.append(node)
        return results

    # -- model extraction ---------------------------------------------- #

    def _model_from_agent(self, call: ast.Call) -> str | None:
        """Extract model from ``Agent("gpt-4o", ...)`` or ``Agent(model="gpt-4o")``."""
        # keyword: model="..."
        kw = self._find_keyword(call, "model")
        if kw is not None:
            val = self._const_value(kw.value)
            if val:
                return val
        # First positional arg is the model
        if call.args:
            val = self._const_value(call.args[0])
            if val:
                return val
        return None

    # -- decorator inspection ------------------------------------------ #

    @staticmethod
    def _has_agent_tool_decorator(func: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
        """Check for ``@agent.tool``, ``@agent.tool_plain``, or ``@<name>.tool(...)``."""
        for dec in func.decorator_list:
            # @agent.tool / @agent.tool_plain
            if isinstance(dec, ast.Attribute) and dec.attr in ("tool", "tool_plain"):
                return True
            # @agent.tool(...) / @agent.tool_plain(...)
            if (
                isinstance(dec, ast.Call)
                and isinstance(dec.func, ast.Attribute)
                and dec.func.attr in ("tool", "tool_plain")
            ):
                return True
        return False

    @staticmethod
    def _has_system_prompt_decorator(func: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
        """Check for ``@agent.system_prompt`` decorator."""
        for dec in func.decorator_list:
            if isinstance(dec, ast.Attribute) and dec.attr == "system_prompt":
                return True
            if (
                isinstance(dec, ast.Call)
                and isinstance(dec.func, ast.Attribute)
                and dec.func.attr == "system_prompt"
            ):
                return True
        return False

    # -- tool building ------------------------------------------------- #

    @staticmethod
    def _tool_from_funcdef(func: ast.FunctionDef | ast.AsyncFunctionDef) -> ToolDefinition:
        description = ast.get_docstring(func)
        params: dict[str, str] = {}
        for arg in func.args.args:
            if arg.arg in ("self", "ctx"):
                continue
            annotation = ""
            if arg.annotation:
                annotation = ast.dump(arg.annotation)
            params[arg.arg] = annotation
        return ToolDefinition(
            name=func.name,
            description=description,
            parameters=params,
        )

    # -- return-string extraction -------------------------------------- #

    def _single_return_string(self, func: ast.FunctionDef | ast.AsyncFunctionDef) -> str | None:
        """If the function body is a single ``return "..."`` (after docstring), grab it."""
        body = func.body
        # Skip docstring node
        start = 0
        if (
            body
            and isinstance(body[0], ast.Expr)
            and isinstance(body[0].value, ast.Constant)
            and isinstance(body[0].value.value, str)
        ):
            start = 1
        if len(body) - start == 1 and isinstance(body[start], ast.Return):
            return self._const_value(body[start].value) if body[start].value else None
        return None

    # -- assignment target discovery ----------------------------------- #

    @staticmethod
    def _assignment_target_for(tree: ast.Module, call: ast.Call) -> str | None:
        """If ``call`` is the RHS of ``name = Agent(...)``, return *name*."""
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign) and node.value is call:
                if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
                    return node.targets[0].id
        return None
