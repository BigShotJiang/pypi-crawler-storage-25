"""Framework detectors for AI agent code."""

from .anthropic_detector import AnthropicDetector
from .base import BaseDetector
from .crewai_detector import CrewAIDetector
from .generic_detector import GenericDetector
from .langchain_detector import LangChainDetector
from .openai_detector import OpenAIDetector
from .pydantic_ai_detector import PydanticAIDetector

__all__ = [
    "BaseDetector",
    "OpenAIDetector",
    "AnthropicDetector",
    "LangChainDetector",
    "CrewAIDetector",
    "PydanticAIDetector",
    "GenericDetector",
]
