"""Detector for OpenAI SDK usage."""

from __future__ import annotations

import ast
from pathlib import Path

from tailtest.models import AgentDefinition, PromptDefinition, ToolDefinition

from .base import BaseDetector


class OpenAIDetector(BaseDetector):
    """Detects and extracts context from OpenAI Python SDK calls.

    Recognised patterns
    -------------------
    * ``import openai`` / ``from openai import ...``
    * ``client.chat.completions.create(...)``
    * ``openai.ChatCompletion.create(...)``  (legacy)
    * ``messages=[{"role": "system", "content": "..."}]``
    * ``tools=[...]`` / ``functions=[...]`` keyword args
    * ``model="gpt-..."`` keyword args
    """

    framework_name = "openai"

    # ---- detection --------------------------------------------------- #

    def detect(self, file_path: Path, tree: ast.Module) -> bool:
        return self._has_import(tree, "openai")

    # ---- tools ------------------------------------------------------- #

    def extract_tools(self, file_path: Path, tree: ast.Module) -> list[ToolDefinition]:
        tools: list[ToolDefinition] = []
        for call in self._completion_calls(tree):
            tools.extend(self._tools_from_call(call))
        return tools

    # ---- prompts ----------------------------------------------------- #

    def extract_prompts(self, file_path: Path, tree: ast.Module) -> list[PromptDefinition]:
        prompts: list[PromptDefinition] = []
        for call in self._completion_calls(tree):
            prompts.extend(self._prompts_from_call(call, file_path))
        return prompts

    # ---- agents ------------------------------------------------------ #

    def extract_agents(self, file_path: Path, tree: ast.Module) -> list[AgentDefinition]:
        agents: list[AgentDefinition] = []
        for call in self._completion_calls(tree):
            model = self._model_from_call(call)
            tools = self._tools_from_call(call)
            system_prompts = self._prompts_from_call(call, file_path)
            agents.append(
                AgentDefinition(
                    framework="openai",
                    tools=tools,
                    prompts=system_prompts,
                    model=model,
                    file_path=str(file_path),
                )
            )
        return agents

    # ---- models ------------------------------------------------------ #

    def extract_models(self, file_path: Path, tree: ast.Module) -> list[str]:
        models: list[str] = []
        for call in self._completion_calls(tree):
            m = self._model_from_call(call)
            if m:
                models.append(m)
        return models

    # ================================================================== #
    #  Private helpers
    # ================================================================== #

    def _completion_calls(self, tree: ast.Module) -> list[ast.Call]:
        """Find ``*.create(...)`` calls that look like chat completion calls."""
        results: list[ast.Call] = []
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            if self._is_completion_call(node):
                results.append(node)
        return results

    @staticmethod
    def _is_completion_call(call: ast.Call) -> bool:
        """Heuristic: the call is ``<something>.create(...)`` and has a
        ``messages`` or ``model`` keyword arg."""
        func = call.func
        if not isinstance(func, ast.Attribute) or func.attr != "create":
            return False
        # Check for messages or model keyword — dead giveaway
        kw_names = {kw.arg for kw in call.keywords}
        if "messages" in kw_names or "model" in kw_names:
            return True
        # Also accept if the attribute chain contains 'completions' or 'ChatCompletion'
        chain: list[str] = []
        cur: ast.expr = func
        while isinstance(cur, ast.Attribute):
            chain.append(cur.attr)
            cur = cur.value
        return "completions" in chain or "ChatCompletion" in chain

    def _model_from_call(self, call: ast.Call) -> str | None:
        kw = self._find_keyword(call, "model")
        if kw is not None:
            return self._const_value(kw.value)
        return None

    def _prompts_from_call(
        self, call: ast.Call, file_path: Path
    ) -> list[PromptDefinition]:
        """Extract system messages from ``messages=[...]``."""
        prompts: list[PromptDefinition] = []
        kw = self._find_keyword(call, "messages")
        if kw is None:
            return prompts
        if not isinstance(kw.value, ast.List):
            return prompts
        for elt in kw.value.elts:
            prompt = self._system_prompt_from_dict(elt, file_path)
            if prompt:
                prompts.append(prompt)
        return prompts

    def _system_prompt_from_dict(
        self, node: ast.expr, file_path: Path
    ) -> PromptDefinition | None:
        """If *node* is ``{"role": "system", "content": "..."}`` return a
        PromptDefinition."""
        if not isinstance(node, ast.Dict):
            return None
        role: str | None = None
        content: str | None = None
        line_no: int = getattr(node, "lineno", None)
        for key, val in zip(node.keys, node.values):
            k = self._const_value(key) if key else None
            if k == "role":
                role = self._const_value(val)
            elif k == "content":
                content = self._const_value(val)
        if role == "system" and content:
            return PromptDefinition(
                content=content,
                role="system",
                file_path=str(file_path),
                line_number=line_no,
            )
        return None

    def _tools_from_call(self, call: ast.Call) -> list[ToolDefinition]:
        """Extract tool definitions from ``tools=[...]`` or ``functions=[...]``."""
        tools: list[ToolDefinition] = []
        for kw_name in ("tools", "functions"):
            kw = self._find_keyword(call, kw_name)
            if kw is None:
                continue
            if isinstance(kw.value, ast.List):
                for elt in kw.value.elts:
                    td = self._parse_tool_dict(elt)
                    if td:
                        tools.append(td)
        return tools

    def _parse_tool_dict(self, node: ast.expr) -> ToolDefinition | None:
        """Best-effort parse of an OpenAI tool dict literal.

        Handles both the new format::

            {"type": "function", "function": {"name": ..., "description": ..., "parameters": ...}}

        and the legacy format::

            {"name": ..., "description": ..., "parameters": ...}
        """
        if not isinstance(node, ast.Dict):
            return None

        top = self._dict_to_map(node)

        # New format — dig into "function" sub-dict
        func_node = top.get("function")
        if func_node and isinstance(func_node, ast.Dict):
            return self._tool_from_flat_dict(func_node)

        # Legacy / flat format
        return self._tool_from_flat_dict(node)

    def _tool_from_flat_dict(self, node: ast.Dict) -> ToolDefinition | None:
        m = self._dict_to_map(node)
        name_node = m.get("name")
        name = self._const_value(name_node) if name_node else None
        if not name:
            return None
        desc_node = m.get("description")
        desc = self._const_value(desc_node) if desc_node else None
        return ToolDefinition(
            name=name,
            description=desc,
            parameters={},
        )

    @staticmethod
    def _dict_to_map(node: ast.Dict) -> dict[str, ast.expr]:
        """Turn an ast.Dict with Constant string keys into a {str: expr} map."""
        out: dict[str, ast.expr] = {}
        for key, val in zip(node.keys, node.values):
            if key and isinstance(key, ast.Constant) and isinstance(key.value, str):
                out[key.value] = val
        return out
