"""Detector for LangChain / LangGraph usage."""

from __future__ import annotations

import ast
from pathlib import Path

from tailtest.models import AgentDefinition, PromptDefinition, ToolDefinition

from .base import BaseDetector

# Top-level import prefixes that signal LangChain / LangGraph usage.
_LANGCHAIN_MODULES = (
    "langchain",
    "langchain_core",
    "langchain_openai",
    "langchain_anthropic",
    "langchain_community",
    "langgraph",
)

# Model constructor class names and the import prefix they belong to.
_MODEL_CLASSES = (
    "ChatOpenAI",
    "ChatAnthropic",
    "ChatGoogleGenerativeAI",
    "ChatMistralAI",
    "ChatOllama",
    "AzureChatOpenAI",
)


class LangChainDetector(BaseDetector):
    """Detects and extracts context from LangChain / LangGraph code.

    Recognised patterns
    -------------------
    * ``from langchain ...`` / ``from langchain_core ...`` / ``from langgraph ...``
    * ``@tool`` decorated functions
    * ``ChatPromptTemplate.from_messages(...)``, ``SystemMessage(content="...")``
    * ``create_react_agent(...)``, ``AgentExecutor(...)``, ``StateGraph(...)``
    * ``ChatOpenAI(model="...")``, ``ChatAnthropic(model="...")``, etc.
    * ``RunnableSequence``, ``|`` operator chains
    """

    framework_name = "langchain"

    # ---- detection --------------------------------------------------- #

    def detect(self, file_path: Path, tree: ast.Module) -> bool:
        for mod in _LANGCHAIN_MODULES:
            if self._has_import(tree, mod):
                return True
        return False

    # ---- tools ------------------------------------------------------- #

    def extract_tools(self, file_path: Path, tree: ast.Module) -> list[ToolDefinition]:
        tools: list[ToolDefinition] = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if self._has_tool_decorator(node):
                    tools.append(self._tool_from_funcdef(node))
        return tools

    # ---- prompts ----------------------------------------------------- #

    def extract_prompts(self, file_path: Path, tree: ast.Module) -> list[PromptDefinition]:
        prompts: list[PromptDefinition] = []
        seen: set[str] = set()

        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue

            # ChatPromptTemplate.from_messages([...])
            if self._is_call_to(node, "from_messages"):
                prompts.extend(self._prompts_from_messages_call(node, file_path, seen))

            # SystemMessage(content="...")
            if self._is_name_call(node, "SystemMessage"):
                p = self._prompt_from_message_constructor(node, file_path, "system")
                if p and p.content not in seen:
                    seen.add(p.content)
                    prompts.append(p)

            # HumanMessagePromptTemplate — just record its presence
            if self._is_name_call(node, "HumanMessagePromptTemplate"):
                p = self._prompt_from_message_constructor(node, file_path, "user")
                if p and p.content not in seen:
                    seen.add(p.content)
                    prompts.append(p)

        return prompts

    # ---- agents ------------------------------------------------------ #

    def extract_agents(self, file_path: Path, tree: ast.Module) -> list[AgentDefinition]:
        agents: list[AgentDefinition] = []

        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue

            # create_react_agent(...)
            if self._is_name_call(node, "create_react_agent"):
                agents.append(self._agent_from_call(
                    node, file_path, name="react_agent",
                ))

            # AgentExecutor(...)
            if self._is_name_call(node, "AgentExecutor"):
                agents.append(self._agent_from_call(
                    node, file_path, name="agent_executor",
                ))

            # StateGraph(...)  — LangGraph
            if self._is_name_call(node, "StateGraph"):
                agents.append(AgentDefinition(
                    name="langgraph_state_graph",
                    framework="langchain",
                    file_path=str(file_path),
                ))

        return agents

    # ---- models ------------------------------------------------------ #

    def extract_models(self, file_path: Path, tree: ast.Module) -> list[str]:
        models: list[str] = []
        seen: set[str] = set()
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            if self._is_model_constructor(node):
                m = self._model_from_constructor(node)
                if m and m not in seen:
                    seen.add(m)
                    models.append(m)
        return models

    # ================================================================== #
    #  Private helpers
    # ================================================================== #

    # -- decorator inspection ------------------------------------------ #

    @staticmethod
    def _has_tool_decorator(func: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
        """Return True if *func* has a ``@tool`` decorator."""
        for dec in func.decorator_list:
            if isinstance(dec, ast.Name) and dec.id == "tool":
                return True
            if isinstance(dec, ast.Call) and isinstance(dec.func, ast.Name) and dec.func.id == "tool":
                return True
        return False

    @staticmethod
    def _tool_from_funcdef(func: ast.FunctionDef | ast.AsyncFunctionDef) -> ToolDefinition:
        """Build a ToolDefinition from a decorated function."""
        description = ast.get_docstring(func)
        params: dict[str, str] = {}
        for arg in func.args.args:
            if arg.arg == "self":
                continue
            annotation = ""
            if arg.annotation:
                annotation = ast.dump(arg.annotation)
            params[arg.arg] = annotation
        return ToolDefinition(
            name=func.name,
            description=description,
            parameters=params,
        )

    # -- call-shape helpers -------------------------------------------- #

    @staticmethod
    def _is_call_to(call: ast.Call, method: str) -> bool:
        """Check if *call* is ``Something.<method>(...)``."""
        func = call.func
        return isinstance(func, ast.Attribute) and func.attr == method

    @staticmethod
    def _is_name_call(call: ast.Call, name: str) -> bool:
        """Check if *call* is ``<name>(...)`` (bare function / class call)."""
        func = call.func
        if isinstance(func, ast.Name) and func.id == name:
            return True
        if isinstance(func, ast.Attribute) and func.attr == name:
            return True
        return False

    # -- prompt extraction --------------------------------------------- #

    def _prompts_from_messages_call(
        self, call: ast.Call, file_path: Path, seen: set[str],
    ) -> list[PromptDefinition]:
        """Extract prompts from ``ChatPromptTemplate.from_messages([...])``."""
        prompts: list[PromptDefinition] = []
        if not call.args:
            return prompts
        first_arg = call.args[0]
        if not isinstance(first_arg, ast.List):
            return prompts
        for elt in first_arg.elts:
            p = self._prompt_from_tuple_or_call(elt, file_path)
            if p and p.content not in seen:
                seen.add(p.content)
                prompts.append(p)
        return prompts

    def _prompt_from_tuple_or_call(
        self, node: ast.expr, file_path: Path,
    ) -> PromptDefinition | None:
        """Handle ``("system", "You are ...")`` tuples inside from_messages."""
        if isinstance(node, ast.Tuple) and len(node.elts) >= 2:
            role = self._const_value(node.elts[0])
            content = self._const_value(node.elts[1])
            if role and content:
                return PromptDefinition(
                    content=content,
                    role=role,
                    file_path=str(file_path),
                    line_number=getattr(node, "lineno", None),
                )
        # SystemMessage(content="...") inside the list
        if isinstance(node, ast.Call):
            if self._is_name_call(node, "SystemMessage"):
                return self._prompt_from_message_constructor(node, file_path, "system")
            if self._is_name_call(node, "HumanMessage"):
                return self._prompt_from_message_constructor(node, file_path, "user")
        return None

    def _prompt_from_message_constructor(
        self, call: ast.Call, file_path: Path, role: str,
    ) -> PromptDefinition | None:
        """Extract content from ``SystemMessage(content="...")`` or positional arg."""
        # keyword: content="..."
        kw = self._find_keyword(call, "content")
        if kw is not None:
            val = self._const_value(kw.value)
            if val:
                return PromptDefinition(
                    content=val,
                    role=role,
                    file_path=str(file_path),
                    line_number=getattr(call, "lineno", None),
                )
        # positional: SystemMessage("...")
        if call.args:
            val = self._const_value(call.args[0])
            if val:
                return PromptDefinition(
                    content=val,
                    role=role,
                    file_path=str(file_path),
                    line_number=getattr(call, "lineno", None),
                )
        return None

    # -- agent extraction ---------------------------------------------- #

    def _agent_from_call(
        self, call: ast.Call, file_path: Path, *, name: str,
    ) -> AgentDefinition:
        """Build an AgentDefinition from a create_react_agent / AgentExecutor call."""
        model: str | None = None
        # Try 'llm' or 'model' keyword
        for kw_name in ("llm", "model"):
            kw = self._find_keyword(call, kw_name)
            if kw is not None:
                model = self._const_value(kw.value)
                if model:
                    break
        return AgentDefinition(
            name=name,
            framework="langchain",
            model=model,
            file_path=str(file_path),
        )

    # -- model extraction ---------------------------------------------- #

    @staticmethod
    def _is_model_constructor(call: ast.Call) -> bool:
        """Check if *call* constructs a known chat-model class."""
        func = call.func
        name: str | None = None
        if isinstance(func, ast.Name):
            name = func.id
        elif isinstance(func, ast.Attribute):
            name = func.attr
        return name in _MODEL_CLASSES if name else False

    def _model_from_constructor(self, call: ast.Call) -> str | None:
        """Extract the model string from ``ChatOpenAI(model="gpt-4o")``."""
        for kw_name in ("model", "model_name"):
            kw = self._find_keyword(call, kw_name)
            if kw is not None:
                val = self._const_value(kw.value)
                if val:
                    return val
        # First positional arg is sometimes the model name
        if call.args:
            val = self._const_value(call.args[0])
            if val:
                return val
        return None
