"""Read / write scan results to the ``.tailtest/context/`` directory."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

from tailtest.models import ScanResult

logger = logging.getLogger(__name__)

_CONTEXT_DIR = ".tailtest/context"
_SCAN_FILE = "scan.json"
_META_FILE = "meta.json"


def context_dir(project_root: Path) -> Path:
    """Return the ``.tailtest/context/`` directory for *project_root*."""
    return project_root / _CONTEXT_DIR


def save_scan(result: ScanResult, project_root: Path) -> Path:
    """Persist *result* as JSON under ``.tailtest/context/``.

    Returns the path to the written scan file.
    """
    out_dir = context_dir(project_root)
    out_dir.mkdir(parents=True, exist_ok=True)

    scan_path = out_dir / _SCAN_FILE
    scan_path.write_text(
        result.model_dump_json(indent=2),
        encoding="utf-8",
    )

    # Write a small metadata sidecar
    meta_path = out_dir / _META_FILE
    meta = {
        "scanned_at": datetime.now(tz=timezone.utc).isoformat(),
        "framework": result.framework,
        "tool_count": len(result.tools),
        "prompt_count": len(result.prompts),
        "agent_count": len(result.agents),
        "model_count": len(result.models),
    }
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    logger.info("Scan result saved to %s", scan_path)
    return scan_path


def load_scan(project_root: Path) -> ScanResult | None:
    """Load a previously saved scan result, or return None."""
    scan_path = context_dir(project_root) / _SCAN_FILE
    if not scan_path.is_file():
        return None
    try:
        data = json.loads(scan_path.read_text(encoding="utf-8"))
        return ScanResult(**data)
    except (json.JSONDecodeError, ValueError) as exc:
        logger.warning("Could not load scan from %s: %s", scan_path, exc)
        return None


def load_meta(project_root: Path) -> dict | None:
    """Load the metadata sidecar, or return None."""
    meta_path = context_dir(project_root) / _META_FILE
    if not meta_path.is_file():
        return None
    try:
        return json.loads(meta_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, ValueError):
        return None
