"""Test runner engine — the core that discovers, executes, and collects test results.

This is the central module that the CLI ``tailtest run`` command calls.
It orchestrates:

1. **Discovery** — find all test functions in given paths.
2. **Execution** — run each test (with timeout, retries, and optional
   record/replay).
3. **Collection** — aggregate individual ``TestResult`` objects into a
   ``TestSuiteResult``.
4. **Reliability** — optionally run each test N times and compute a
   pass-rate reliability score.

Usage::

    from tailtest.runner.engine import TestRunner, RunConfig

    runner = TestRunner()
    result = await runner.run("tests/", config=RunConfig(reliability=5))
"""

from __future__ import annotations

import asyncio
import inspect
import time
import traceback
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from tailtest.config.schema import TailtestConfig
from tailtest.models import (
    AgentResponse,
    AssertionResult,
    TestCase,
    TestResult,
    TestSuiteResult,
)
from tailtest.runner.discovery import discover_tests
from tailtest.runner.recorder import Recorder, Replayer


# ---------------------------------------------------------------------------
# Run configuration
# ---------------------------------------------------------------------------

@dataclass
class RunConfig:
    """Configuration for a single engine run.

    These settings are typically populated from CLI flags and/or the
    ``tailtest.yaml`` config file.
    """

    # Test selection
    tags: list[str] = field(default_factory=list)
    exclude_tags: list[str] = field(default_factory=list)

    # Execution
    parallel: int = 1  # 1 = sequential; >1 = run up to N tests concurrently
    timeout_ms: int = 30000
    reliability: int = 1  # number of times to run each test
    cost_limit: float | None = None

    # Record / replay
    replay: bool = False
    record: bool = False
    replay_session: str | None = None  # specific session dir to replay

    # Overrides
    model_override: str | None = None
    judge_override: str | None = None

    # CI
    ci: bool = False

    @classmethod
    def from_tailtest_config(cls, config: TailtestConfig, **overrides: Any) -> RunConfig:
        """Build a ``RunConfig`` merging ``TailtestConfig`` defaults with CLI overrides."""
        base = cls(
            parallel=config.testing.parallel,
            timeout_ms=config.testing.timeout_ms,
            cost_limit=config.testing.cost_limit,
        )
        for key, value in overrides.items():
            if hasattr(base, key) and value is not None:
                setattr(base, key, value)
        return base


# ---------------------------------------------------------------------------
# Test execution context (passed into each test function)
# ---------------------------------------------------------------------------

class _TestContext:
    """Internal mutable bag of state accumulated during a single test execution.

    Not exposed to users directly — the engine reads back the collected
    assertion results and response after the test function returns.
    """

    def __init__(self) -> None:
        self.assertion_results: list[AssertionResult] = []
        self.response: AgentResponse | None = None
        self.cost_usd: float = 0.0


# Thread-local-ish context for the currently executing test.
_current_context: _TestContext | None = None


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class TestRunner:
    """The tailtest test runner engine.

    Typical lifecycle::

        runner = TestRunner()
        suite_result = await runner.run("tests/", config=RunConfig())
    """

    def __init__(self) -> None:
        self._recorder: Recorder | None = None
        self._replayer: Replayer | None = None

    # -- Public API ----------------------------------------------------------

    async def run(
        self,
        path: str | Path | None = None,
        config: RunConfig | None = None,
    ) -> TestSuiteResult:
        """Discover and execute all tests, returning an aggregated result.

        Parameters
        ----------
        path:
            A file or directory to search for tests.  Defaults to the
            current working directory.
        config:
            Execution configuration.  Defaults to ``RunConfig()`` with
            all defaults.
        """
        config = config or RunConfig()
        path = Path(path) if path else Path.cwd()

        # Setup record/replay
        self._setup_recording(config)

        run_start = time.perf_counter()
        total_cost = 0.0

        # 1. Discover tests
        test_fns = discover_tests(path)

        # 2. Filter by tags
        test_fns = self._filter_by_tags(test_fns, config)

        if not test_fns:
            return TestSuiteResult(
                total=0,
                passed=0,
                failed=0,
                skipped=0,
                duration_ms=0.0,
                total_cost_usd=0.0,
                results=[],
            )

        # 3. Execute (parallel or sequential)
        if config.parallel > 1 and config.reliability <= 1:
            all_results = await self._run_parallel(test_fns, config)
            total_cost = sum(r.cost_usd for r in all_results)
        else:
            all_results = []
            cost_exceeded = False

            for test_fn in test_fns:
                if cost_exceeded:
                    # Skip remaining tests if cost limit exceeded.
                    result = self._make_skipped_result(test_fn, "cost limit exceeded")
                    all_results.append(result)
                    continue

                if config.reliability > 1:
                    # Reliability mode: run the test N times.
                    reliability_results = await self._run_with_reliability(
                        test_fn, config
                    )
                    all_results.extend(reliability_results)
                    total_cost += sum(r.cost_usd for r in reliability_results)
                else:
                    result = await self._execute_single_test(test_fn, config)
                    all_results.append(result)
                    total_cost += result.cost_usd

                # Check cost limit.
                if config.cost_limit is not None and total_cost >= config.cost_limit:
                    cost_exceeded = True

        # 4. Finalize recording session.
        if self._recorder is not None:
            self._recorder.finalize()

        run_duration = (time.perf_counter() - run_start) * 1000

        passed = sum(1 for r in all_results if r.passed)
        failed = sum(1 for r in all_results if not r.passed and r.trace_id != "__skipped__")
        skipped = sum(1 for r in all_results if r.trace_id == "__skipped__")

        # Compute reliability score if applicable.
        reliability_score: float | None = None
        if config.reliability > 1 and all_results:
            reliability_score = passed / len(all_results)

        return TestSuiteResult(
            total=len(all_results),
            passed=passed,
            failed=failed,
            skipped=skipped,
            duration_ms=run_duration,
            total_cost_usd=total_cost,
            results=all_results,
            reliability_score=reliability_score,
        )

    # -- Recording setup -----------------------------------------------------

    def _setup_recording(self, config: RunConfig) -> None:
        """Initialize recorder or replayer based on config."""
        if config.record:
            self._recorder = Recorder()
        if config.replay:
            self._replayer = Replayer(
                session_dir=config.replay_session,
            )

    # -- Tag filtering -------------------------------------------------------

    @staticmethod
    def _filter_by_tags(
        test_fns: list[Callable[..., Any]], config: RunConfig
    ) -> list[Callable[..., Any]]:
        """Filter test functions by include/exclude tags."""
        if not config.tags and not config.exclude_tags:
            return test_fns

        filtered: list[Callable[..., Any]] = []
        for fn in test_fns:
            fn_tags: list[str] = getattr(fn, "_tailtest_tags", [])

            # Exclude tags take priority.
            if config.exclude_tags and any(t in fn_tags for t in config.exclude_tags):
                continue

            # If include tags specified, function must have at least one.
            if config.tags:
                if any(t in fn_tags for t in config.tags):
                    filtered.append(fn)
            else:
                filtered.append(fn)

        return filtered

    # -- Parallel execution ---------------------------------------------------

    async def _run_parallel(
        self,
        tests: list[Callable[..., Any]],
        config: RunConfig,
    ) -> list[TestResult]:
        """Run tests in parallel with a semaphore limiting concurrency.

        Uses ``config.parallel`` as the maximum number of concurrent tests.
        Results are returned in the same order as the input test list.
        Cost limits are checked after each test completes; once exceeded,
        remaining incomplete tests are not cancelled but no *new* tests
        will start.
        """
        semaphore = asyncio.Semaphore(config.parallel)
        cost_exceeded = False
        total_cost = 0.0
        # Lock protects the shared cost counter
        cost_lock = asyncio.Lock()

        async def run_with_semaphore(
            test_fn: Callable[..., Any],
        ) -> TestResult:
            nonlocal cost_exceeded, total_cost

            # Check cost limit before acquiring semaphore
            if cost_exceeded:
                return self._make_skipped_result(test_fn, "cost limit exceeded")

            async with semaphore:
                # Double-check after acquiring semaphore
                if cost_exceeded:
                    return self._make_skipped_result(test_fn, "cost limit exceeded")

                result = await self._execute_single_test(test_fn, config)

                async with cost_lock:
                    total_cost += result.cost_usd
                    if config.cost_limit is not None and total_cost >= config.cost_limit:
                        cost_exceeded = True

                return result

        tasks = [run_with_semaphore(t) for t in tests]
        return list(await asyncio.gather(*tasks))

    # -- Single test execution -----------------------------------------------

    async def _execute_single_test(
        self,
        test_fn: Callable[..., Any],
        config: RunConfig,
    ) -> TestResult:
        """Execute a single test function with timeout and retries.

        Returns a ``TestResult`` regardless of pass/fail/error.
        """
        retries = getattr(test_fn, "_tailtest_retries", 1)
        timeout_ms = getattr(test_fn, "_tailtest_timeout_ms", config.timeout_ms)
        test_name = getattr(test_fn, "__name__", "unknown_test")
        source_file = getattr(test_fn, "_tailtest_source_file", None)

        last_result: TestResult | None = None

        for attempt in range(retries):
            result = await self._run_once(test_fn, test_name, timeout_ms, source_file)

            if result.passed:
                return result

            last_result = result

        # All retries exhausted — return the last failure.
        assert last_result is not None
        return last_result

    async def _run_once(
        self,
        test_fn: Callable[..., Any],
        test_name: str,
        timeout_ms: int,
        source_file: str | None,
    ) -> TestResult:
        """Run a test function once, capturing assertions and errors."""
        global _current_context
        ctx = _TestContext()
        _current_context = ctx

        start = time.perf_counter()
        assertion_results: list[AssertionResult] = []
        passed = True
        error_message: str | None = None
        response = AgentResponse(content="")

        try:
            coro = self._invoke_test(test_fn)
            await asyncio.wait_for(coro, timeout=timeout_ms / 1000.0)
        except asyncio.TimeoutError:
            passed = False
            error_message = f"Test timed out after {timeout_ms}ms"
            assertion_results.append(
                AssertionResult(
                    passed=False,
                    assertion_type="timeout",
                    expected=f"complete within {timeout_ms}ms",
                    actual="timed out",
                    message=error_message,
                )
            )
        except AssertionError as exc:
            passed = False
            error_message = str(exc)
            # The assertion result was already recorded by expect().
            # Add a catch-all in case it wasn't.
            if not any(not r.passed for r in ctx.assertion_results):
                assertion_results.append(
                    AssertionResult(
                        passed=False,
                        assertion_type="assertion",
                        expected="pass",
                        actual="fail",
                        message=error_message,
                    )
                )
        except Exception as exc:  # noqa: BLE001
            passed = False
            error_message = f"{type(exc).__name__}: {exc}"
            assertion_results.append(
                AssertionResult(
                    passed=False,
                    assertion_type="error",
                    expected="no error",
                    actual=error_message,
                    message=f"Test raised an unexpected exception:\n{traceback.format_exc()}",
                )
            )

        elapsed_ms = (time.perf_counter() - start) * 1000

        # Merge assertion results from the context.
        assertion_results = ctx.assertion_results + assertion_results

        # If all individual assertions passed but we didn't hit an error,
        # the test passes. If we did hit an error, it fails.
        if assertion_results:
            passed = all(r.passed for r in assertion_results)

        # Use the response captured by the test function, if any.
        if ctx.response is not None:
            response = ctx.response

        cost = sum(r.cost_usd for r in assertion_results) + ctx.cost_usd

        # Record the interaction if recording.
        if self._recorder is not None and ctx.response is not None:
            self._recorder.record(test_name, ctx.response)

        _current_context = None

        test_case = TestCase(
            name=test_name,
            description=inspect.getdoc(test_fn),
            input=test_name,
            assertions=[r.assertion_type for r in assertion_results],
            tags=getattr(test_fn, "_tailtest_tags", []),
            timeout_ms=getattr(test_fn, "_tailtest_timeout_ms", 30000),
            retries=getattr(test_fn, "_tailtest_retries", 1),
        )

        return TestResult(
            test_case=test_case,
            passed=passed,
            assertion_results=assertion_results,
            agent_response=response,
            duration_ms=elapsed_ms,
            cost_usd=cost,
            timestamp=datetime.now(tz=timezone.utc),
            trace_id=None,
        )

    async def _invoke_test(self, test_fn: Callable[..., Any]) -> None:
        """Call the test function, handling both sync and async."""
        if inspect.iscoroutinefunction(test_fn):
            await test_fn()
        else:
            result = test_fn()
            # In case a sync function returns a coroutine (unlikely but safe).
            if inspect.isawaitable(result):
                await result

    # -- Reliability mode ----------------------------------------------------

    async def _run_with_reliability(
        self,
        test_fn: Callable[..., Any],
        config: RunConfig,
    ) -> list[TestResult]:
        """Run a single test function ``config.reliability`` times.

        Returns all individual ``TestResult`` instances.
        """
        results: list[TestResult] = []
        for _ in range(config.reliability):
            result = await self._execute_single_test(test_fn, config)
            results.append(result)
        return results

    # -- Skipped result helper -----------------------------------------------

    @staticmethod
    def _make_skipped_result(
        test_fn: Callable[..., Any], reason: str
    ) -> TestResult:
        """Produce a ``TestResult`` for a test that was skipped."""
        test_name = getattr(test_fn, "__name__", "unknown_test")
        return TestResult(
            test_case=TestCase(
                name=test_name,
                input=test_name,
                assertions=[],
                tags=getattr(test_fn, "_tailtest_tags", []),
            ),
            passed=False,
            assertion_results=[
                AssertionResult(
                    passed=False,
                    assertion_type="skipped",
                    expected="run",
                    actual="skipped",
                    message=reason,
                )
            ],
            agent_response=AgentResponse(content=""),
            duration_ms=0.0,
            cost_usd=0.0,
            timestamp=datetime.now(tz=timezone.utc),
            trace_id="__skipped__",
        )


# ---------------------------------------------------------------------------
# Module-level convenience
# ---------------------------------------------------------------------------

async def run_tests(
    path: str | Path | None = None,
    config: RunConfig | None = None,
) -> TestSuiteResult:
    """Convenience wrapper: create a ``TestRunner`` and run tests.

    This is the function the CLI calls::

        result = await run_tests("tests/", config=RunConfig(replay=True))
    """
    runner = TestRunner()
    return await runner.run(path=path, config=config)
