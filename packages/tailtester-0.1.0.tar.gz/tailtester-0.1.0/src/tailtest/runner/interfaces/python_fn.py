"""Agent interface that wraps a plain Python function (sync or async)."""

from __future__ import annotations

import asyncio
import inspect
import time
from typing import Any, Callable

from tailtest.models import AgentResponse, Message
from tailtest.runner.interfaces.base import BaseAgentInterface


class PythonFunctionInterface(BaseAgentInterface):
    """Call an agent implemented as a single Python callable.

    The callable's signature must be ``fn(message: str) -> str | dict | AgentResponse``.
    Both sync and async functions are supported transparently.
    """

    def __init__(self, fn: Callable[..., Any], name: str | None = None) -> None:
        self.fn = fn
        self.name = name or getattr(fn, "__name__", "agent")
        self._is_async = inspect.iscoroutinefunction(fn)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def chat(self, message: str) -> AgentResponse:
        """Send *message* to the wrapped function and return an ``AgentResponse``."""
        start = time.perf_counter()

        if self._is_async:
            result = await self.fn(message)
        else:
            result = await asyncio.to_thread(self.fn, message)

        elapsed_ms = (time.perf_counter() - start) * 1000
        return self._to_response(result, elapsed_ms)

    async def conversation(self, messages: list[Message]) -> AgentResponse:
        """Replay a multi-turn conversation by feeding each user message.

        Only the *last* user message is sent to the function; assistant
        turns are provided purely for context in the prompt.  If the
        function only accepts a single string this is the best we can do
        without requiring a richer protocol.
        """
        last_user_msg = ""
        for msg in reversed(messages):
            if msg.role == "user":
                last_user_msg = msg.content
                break

        if not last_user_msg:
            return AgentResponse(content="", metadata={"error": "no user message found"})

        return await self.chat(last_user_msg)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _to_response(result: Any, elapsed_ms: float) -> AgentResponse:
        """Normalise whatever the function returned into an ``AgentResponse``."""
        if isinstance(result, AgentResponse):
            if result.latency_ms is None:
                result.latency_ms = elapsed_ms
            return result

        if isinstance(result, str):
            return AgentResponse(content=result, latency_ms=elapsed_ms)

        if isinstance(result, dict):
            # Let Pydantic validate; fall back to stuffing the whole dict
            # into ``content`` if the shape does not match.
            try:
                resp = AgentResponse.model_validate(result)
                if resp.latency_ms is None:
                    resp.latency_ms = elapsed_ms
                return resp
            except Exception:  # noqa: BLE001
                return AgentResponse(
                    content=str(result),
                    latency_ms=elapsed_ms,
                    metadata={"raw_dict": result},
                )

        # Anything else: coerce to string.
        return AgentResponse(content=str(result), latency_ms=elapsed_ms)

    def __repr__(self) -> str:
        return f"PythonFunctionInterface(name={self.name!r})"
