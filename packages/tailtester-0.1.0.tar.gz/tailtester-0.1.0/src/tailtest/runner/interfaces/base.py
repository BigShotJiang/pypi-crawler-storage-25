"""Base agent interface for communicating with an AI agent under test."""

from __future__ import annotations

from abc import ABC, abstractmethod

from tailtest.models import AgentResponse, Message


class BaseAgentInterface(ABC):
    """Interface for communicating with an AI agent under test.

    All concrete interfaces (Python function, HTTP, CLI, etc.) must
    implement ``chat`` and ``conversation``.  The runner engine works
    exclusively through this contract so that the agent transport is
    fully decoupled from test execution.
    """

    @abstractmethod
    async def chat(self, message: str) -> AgentResponse:
        """Send a single user message and return the agent response."""
        ...

    @abstractmethod
    async def conversation(self, messages: list[Message]) -> AgentResponse:
        """Send a multi-turn conversation and return the final response."""
        ...

    async def close(self) -> None:
        """Release any held resources (HTTP clients, sub-processes, etc.)."""

    async def __aenter__(self) -> BaseAgentInterface:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        await self.close()
