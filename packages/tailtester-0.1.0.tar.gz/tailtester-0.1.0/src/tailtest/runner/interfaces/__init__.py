"""Agent interface abstractions and factory.

Every interface wraps a different transport (Python callable, HTTP, CLI
subprocess) behind a common ``BaseAgentInterface`` contract so the test
runner can treat all agents identically.
"""

from __future__ import annotations

import importlib
from typing import Any, Callable

from tailtest.config.schema import AgentConfig
from tailtest.runner.interfaces.base import BaseAgentInterface
from tailtest.runner.interfaces.cli_proc import CLIInterface
from tailtest.runner.interfaces.http import HTTPInterface
from tailtest.runner.interfaces.python_fn import PythonFunctionInterface

__all__ = [
    "BaseAgentInterface",
    "CLIInterface",
    "HTTPInterface",
    "PythonFunctionInterface",
    "create_interface",
]


def _import_callable(dotted_path: str) -> Callable[..., Any]:
    """Import a callable from a ``module.path:function_name`` string.

    Raises
    ------
    ValueError
        If the path does not contain a ``:`` separator.
    ImportError
        If the module cannot be imported.
    AttributeError
        If the attribute does not exist in the module.
    TypeError
        If the resolved attribute is not callable.
    """
    if ":" not in dotted_path:
        raise ValueError(
            f"Python function path must use 'module:attribute' format, got {dotted_path!r}"
        )

    module_path, attr_name = dotted_path.rsplit(":", 1)
    module = importlib.import_module(module_path)
    obj = getattr(module, attr_name)
    if not callable(obj):
        raise TypeError(f"{dotted_path!r} resolved to {type(obj).__name__}, expected a callable")
    return obj


def create_interface(config: AgentConfig) -> BaseAgentInterface:
    """Construct the appropriate ``BaseAgentInterface`` from an ``AgentConfig``.

    Parameters
    ----------
    config:
        An ``AgentConfig`` describing the agent transport (HTTP, Python, CLI).

    Returns
    -------
    BaseAgentInterface
        A ready-to-use interface instance.

    Raises
    ------
    ValueError
        If ``config.type`` is unknown or required fields are missing.
    """
    match config.type:
        case "http":
            if not config.url:
                raise ValueError("AgentConfig with type='http' requires a 'url'")
            return HTTPInterface(
                url=config.url,
                method=config.request_method,
                headers=config.request_headers,
                body_template=config.body_template,
                response_content_path=config.response_content_path,
            )

        case "python":
            if not config.function:
                raise ValueError("AgentConfig with type='python' requires a 'function'")
            fn = _import_callable(config.function)
            return PythonFunctionInterface(fn=fn, name=config.function)

        case "cli":
            if not config.command:
                raise ValueError("AgentConfig with type='cli' requires a 'command'")
            return CLIInterface(
                command=config.command,
            )

        case _:
            raise ValueError(f"Unknown agent type: {config.type!r}")
