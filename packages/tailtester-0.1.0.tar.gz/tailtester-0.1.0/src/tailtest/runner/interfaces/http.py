"""Agent interface that communicates over HTTP (REST / SSE)."""

from __future__ import annotations

import json
import time
import uuid
from typing import Any

import httpx

from tailtest.models import AgentResponse, Message
from tailtest.runner.interfaces.base import BaseAgentInterface


class HTTPInterface(BaseAgentInterface):
    """Send messages to an agent exposed as an HTTP endpoint.

    Parameters
    ----------
    url:
        Full URL of the agent endpoint.
    method:
        HTTP method (``POST``, ``PUT``, etc.).  Defaults to ``POST``.
    headers:
        Extra headers sent with every request.
    body_template:
        A JSON string with ``{{input}}`` and ``{{session_id}}`` placeholders
        that are substituted at call time.
    response_content_path:
        Dot-notation path into the JSON response body to extract the agent
        content (e.g. ``"response.text"``).  When *None* the entire response
        body is used as-is.
    timeout:
        Per-request timeout in seconds.
    """

    def __init__(
        self,
        url: str,
        method: str = "POST",
        headers: dict[str, str] | None = None,
        body_template: str = '{"message": "{{input}}"}',
        response_content_path: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        self.url = url
        self.method = method.upper()
        self.headers = headers or {}
        self.body_template = body_template
        self.response_content_path = response_content_path
        self.timeout = timeout
        self._client = httpx.AsyncClient(timeout=timeout)
        self._session_id = uuid.uuid4().hex

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def chat(self, message: str) -> AgentResponse:
        """Send a single message and return the parsed ``AgentResponse``."""
        body_str = (
            self.body_template
            .replace("{{input}}", self._escape_json(message))
            .replace("{{session_id}}", self._session_id)
        )

        try:
            body: Any = json.loads(body_str)
        except json.JSONDecodeError:
            body = body_str  # send as raw text if template isn't valid JSON

        request_headers = {**self.headers}
        if isinstance(body, (dict, list)):
            request_headers.setdefault("Content-Type", "application/json")

        start = time.perf_counter()
        try:
            response = await self._client.request(
                self.method,
                self.url,
                json=body if isinstance(body, (dict, list)) else None,
                content=body if isinstance(body, str) else None,
                headers=request_headers,
            )
            elapsed_ms = (time.perf_counter() - start) * 1000

            if response.status_code >= 400:
                return AgentResponse(
                    content="",
                    latency_ms=elapsed_ms,
                    metadata={
                        "error": f"HTTP {response.status_code}",
                        "body": response.text[:2000],
                    },
                )

            # Detect SSE / streaming responses
            content_type = response.headers.get("content-type", "")
            if "text/event-stream" in content_type:
                return await self._handle_sse(response, elapsed_ms)

            return self._parse_response(response.text, elapsed_ms)

        except httpx.TimeoutException:
            elapsed_ms = (time.perf_counter() - start) * 1000
            return AgentResponse(
                content="",
                latency_ms=elapsed_ms,
                metadata={"error": "timeout", "timeout_seconds": self.timeout},
            )
        except httpx.ConnectError as exc:
            elapsed_ms = (time.perf_counter() - start) * 1000
            return AgentResponse(
                content="",
                latency_ms=elapsed_ms,
                metadata={"error": "connection_error", "detail": str(exc)},
            )
        except httpx.HTTPError as exc:
            elapsed_ms = (time.perf_counter() - start) * 1000
            return AgentResponse(
                content="",
                latency_ms=elapsed_ms,
                metadata={"error": "http_error", "detail": str(exc)},
            )

    async def conversation(self, messages: list[Message]) -> AgentResponse:
        """Send a multi-turn conversation.

        This implementation sends only the last user message through the
        standard ``chat`` path.  If the agent endpoint supports a
        ``messages`` array in its body template (e.g. OpenAI-compatible),
        callers should craft the ``body_template`` accordingly.
        """
        last_user_msg = ""
        for msg in reversed(messages):
            if msg.role == "user":
                last_user_msg = msg.content
                break

        if not last_user_msg:
            return AgentResponse(content="", metadata={"error": "no user message found"})

        return await self.chat(last_user_msg)

    async def close(self) -> None:
        """Close the underlying ``httpx.AsyncClient``."""
        await self._client.aclose()

    # ------------------------------------------------------------------
    # Streaming (SSE)
    # ------------------------------------------------------------------

    async def _handle_sse(
        self,
        response: httpx.Response,
        initial_elapsed_ms: float,
    ) -> AgentResponse:
        """Collect a Server-Sent Events stream into a single response."""
        chunks: list[str] = []
        for line in response.text.splitlines():
            if line.startswith("data:"):
                data = line[len("data:"):].strip()
                if data == "[DONE]":
                    break
                try:
                    payload = json.loads(data)
                    # Support common streaming shapes
                    chunk_text = (
                        payload.get("content")
                        or payload.get("text")
                        or payload.get("delta", {}).get("content")
                        or ""
                    )
                    if chunk_text:
                        chunks.append(chunk_text)
                except json.JSONDecodeError:
                    chunks.append(data)

        return AgentResponse(
            content="".join(chunks),
            latency_ms=initial_elapsed_ms,
            metadata={"streaming": True},
        )

    # ------------------------------------------------------------------
    # Response parsing
    # ------------------------------------------------------------------

    def _parse_response(self, text: str, elapsed_ms: float) -> AgentResponse:
        """Parse the raw response body into an ``AgentResponse``."""
        try:
            data: Any = json.loads(text)
        except json.JSONDecodeError:
            # Plain text response
            return AgentResponse(content=text.strip(), latency_ms=elapsed_ms)

        content = self._extract_path(data) if self.response_content_path else text
        if isinstance(content, dict):
            try:
                resp = AgentResponse.model_validate(content)
                if resp.latency_ms is None:
                    resp.latency_ms = elapsed_ms
                return resp
            except Exception:  # noqa: BLE001
                content = json.dumps(content)

        return AgentResponse(content=str(content), latency_ms=elapsed_ms)

    def _extract_path(self, data: Any) -> Any:
        """Walk a dot-notation path (``a.b.c``) into *data*."""
        if self.response_content_path is None:
            return data

        current = data
        for key in self.response_content_path.split("."):
            if isinstance(current, dict):
                current = current.get(key)
            elif isinstance(current, list) and key.isdigit():
                idx = int(key)
                current = current[idx] if idx < len(current) else None
            else:
                return None
            if current is None:
                return None
        return current

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _escape_json(value: str) -> str:
        """Escape a string so it is safe inside a JSON string literal.

        ``json.dumps`` adds surrounding quotes; we strip them so the
        result can be dropped into an existing template placeholder.
        """
        return json.dumps(value)[1:-1]

    def __repr__(self) -> str:
        return f"HTTPInterface(url={self.url!r}, method={self.method!r})"
