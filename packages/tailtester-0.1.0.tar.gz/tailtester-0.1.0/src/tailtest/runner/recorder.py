"""Record/replay system for deterministic test execution.

In **record** mode the ``Recorder`` intercepts agent responses during a
test run and writes them to ``.tailtest/recordings/<timestamp>/`` as JSON
files keyed by a hash of the request input.

In **replay** mode the ``Replayer`` serves previously recorded responses
instead of making live agent/LLM calls, enabling fast deterministic
reruns without network access.

Storage layout::

    .tailtest/recordings/
      2026-03-31T12-00-00/
        manifest.json          # run metadata
        <hash>.json            # one file per recorded interaction
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from tailtest.models import AgentResponse


# -- Helpers ----------------------------------------------------------------

_RECORDINGS_DIR = Path(".tailtest/recordings")


def _request_key(input_text: str) -> str:
    """Produce a stable, filesystem-safe key from the request input."""
    digest = hashlib.sha256(input_text.encode()).hexdigest()[:16]
    return digest


def _serialize_response(response: AgentResponse) -> dict[str, Any]:
    """Convert an ``AgentResponse`` to a JSON-safe dict."""
    return response.model_dump(mode="json")


def _deserialize_response(data: dict[str, Any]) -> AgentResponse:
    """Reconstruct an ``AgentResponse`` from a JSON-safe dict."""
    return AgentResponse.model_validate(data)


# -- Recorder ----------------------------------------------------------------


class Recorder:
    """Record agent responses for later deterministic replay.

    Parameters
    ----------
    base_dir:
        Root recordings directory.  Defaults to ``.tailtest/recordings/``.
    session_name:
        Optional name for this recording session.  When *None* a
        timestamp string is generated automatically.
    """

    def __init__(
        self,
        base_dir: Path | str | None = None,
        session_name: str | None = None,
    ) -> None:
        self._base_dir = Path(base_dir) if base_dir else _RECORDINGS_DIR
        self._session_name = session_name or datetime.now(
            tz=timezone.utc
        ).strftime("%Y-%m-%dT%H-%M-%S")
        self._session_dir = self._base_dir / self._session_name
        self._interactions: list[dict[str, Any]] = []
        self._initialized = False

    @property
    def session_dir(self) -> Path:
        """Absolute path to this session's recording directory."""
        return self._session_dir

    # -- Public API ----------------------------------------------------------

    def record(self, input_text: str, response: AgentResponse) -> None:
        """Persist a single request/response pair.

        The response is written immediately to disk so that partial
        recordings survive a crash.
        """
        self._ensure_dir()

        key = _request_key(input_text)
        entry: dict[str, Any] = {
            "input": input_text,
            "key": key,
            "recorded_at": datetime.now(tz=timezone.utc).isoformat(),
            "response": _serialize_response(response),
        }

        # Write individual interaction file.
        interaction_path = self._session_dir / f"{key}.json"

        # Handle duplicate keys (same input sent multiple times) by appending
        # a counter suffix.
        if interaction_path.exists():
            counter = 1
            while True:
                candidate = self._session_dir / f"{key}_{counter}.json"
                if not candidate.exists():
                    interaction_path = candidate
                    break
                counter += 1

        interaction_path.write_text(
            json.dumps(entry, indent=2, default=str), encoding="utf-8"
        )
        self._interactions.append(entry)

    def finalize(self) -> Path:
        """Write the session manifest and return the session directory.

        Call this after the test run completes to persist run-level
        metadata.
        """
        self._ensure_dir()
        manifest: dict[str, Any] = {
            "session": self._session_name,
            "finalized_at": datetime.now(tz=timezone.utc).isoformat(),
            "interaction_count": len(self._interactions),
        }
        manifest_path = self._session_dir / "manifest.json"
        manifest_path.write_text(
            json.dumps(manifest, indent=2, default=str), encoding="utf-8"
        )
        return self._session_dir

    # -- Internals -----------------------------------------------------------

    def _ensure_dir(self) -> None:
        if not self._initialized:
            self._session_dir.mkdir(parents=True, exist_ok=True)
            self._initialized = True


# -- Replayer ----------------------------------------------------------------


class Replayer:
    """Replay previously recorded agent responses.

    Parameters
    ----------
    session_dir:
        Path to a specific recording session directory.  When *None*,
        the most recent session under the default recordings directory
        is used.
    base_dir:
        Root recordings directory (used only when *session_dir* is
        *None*).  Defaults to ``.tailtest/recordings/``.
    """

    def __init__(
        self,
        session_dir: Path | str | None = None,
        base_dir: Path | str | None = None,
    ) -> None:
        if session_dir is not None:
            self._session_dir = Path(session_dir)
        else:
            base = Path(base_dir) if base_dir else _RECORDINGS_DIR
            self._session_dir = self._latest_session(base)

        # Load all interactions into an in-memory lookup.
        self._lookup: dict[str, list[dict[str, Any]]] = {}
        self._replay_counters: dict[str, int] = {}
        self._load()

    @property
    def session_dir(self) -> Path:
        return self._session_dir

    # -- Public API ----------------------------------------------------------

    def replay(self, input_text: str) -> AgentResponse | None:
        """Return the recorded response for *input_text*, or ``None``.

        When the same input was recorded multiple times, responses are
        returned in order.
        """
        key = _request_key(input_text)
        entries = self._lookup.get(key)
        if not entries:
            return None

        idx = self._replay_counters.get(key, 0)
        if idx >= len(entries):
            # Re-use the last recording if we've exhausted them.
            idx = len(entries) - 1

        self._replay_counters[key] = idx + 1
        return _deserialize_response(entries[idx]["response"])

    def has(self, input_text: str) -> bool:
        """Return ``True`` if a recording exists for *input_text*."""
        return _request_key(input_text) in self._lookup

    # -- Internals -----------------------------------------------------------

    def _load(self) -> None:
        """Load all JSON interaction files from the session directory."""
        if not self._session_dir.is_dir():
            return

        for json_file in sorted(self._session_dir.glob("*.json")):
            if json_file.name == "manifest.json":
                continue
            try:
                data = json.loads(json_file.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                continue

            key = data.get("key", "")
            if key:
                self._lookup.setdefault(key, []).append(data)

    @staticmethod
    def _latest_session(base_dir: Path) -> Path:
        """Find the most recently created recording session."""
        if not base_dir.is_dir():
            raise FileNotFoundError(
                f"No recordings directory found at {base_dir}. "
                f"Run 'tailtest record' first to create recordings."
            )

        sessions = sorted(
            (d for d in base_dir.iterdir() if d.is_dir()),
            key=lambda d: d.name,
            reverse=True,
        )
        if not sessions:
            raise FileNotFoundError(
                f"No recording sessions found in {base_dir}. "
                f"Run 'tailtest record' first to create recordings."
            )
        return sessions[0]
