"""Generate test files for discovered tool definitions.

For each tool found during scanning, generates tests that verify:
- The tool is invoked when the user sends a relevant message.
- The tool is NOT invoked for unrelated messages.
- If the tool has required parameters, a test that verifies correct arguments.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

from jinja2 import Environment, FileSystemLoader

from tailtest.models import ScanResult, ToolDefinition

logger = logging.getLogger(__name__)

_TEMPLATE_DIR = Path(__file__).parent / "templates"


@dataclass
class _ToolTemplateData:
    """Data object passed into the Jinja2 tool test template."""

    name: str
    description: str | None
    trigger_message: str
    has_params: bool
    required_params: list[str]


@dataclass
class ToolTestGenerator:
    """Generates tool-level test files from scan context.

    For each :class:`ToolDefinition` in the scan result, produces a test file
    containing invocation, negative, and (optionally) argument tests.
    """

    framework: str = "unknown"
    scan_source: str = ".tailtest/context/scan.json"

    def _build_trigger_message(self, tool: ToolDefinition) -> str:
        """Build a user message that should plausibly trigger *tool*.

        Uses the tool's ``example_input`` when available; otherwise
        constructs a reasonable request from the tool name and description.
        """
        if tool.example_input:
            return repr(tool.example_input)

        # Derive a reasonable trigger from name + description
        human_name = tool.name.replace("_", " ")
        if tool.description:
            return repr(f"Please {human_name}: {tool.description}")
        return repr(f"Please use the {human_name} tool.")

    def _prepare_tools(self, tools: list[ToolDefinition]) -> list[_ToolTemplateData]:
        """Convert model definitions to template-ready data."""
        result: list[_ToolTemplateData] = []
        for tool in tools:
            result.append(
                _ToolTemplateData(
                    name=tool.name,
                    description=tool.description,
                    trigger_message=self._build_trigger_message(tool),
                    has_params=bool(tool.required_params),
                    required_params=list(tool.required_params),
                )
            )
        return result

    def generate(
        self,
        context: ScanResult,
        output_dir: Path,
        regenerate: bool = False,
    ) -> list[Path]:
        """Generate tool test files.

        Parameters
        ----------
        context:
            The scan result containing discovered tools.
        output_dir:
            Directory where generated test files will be written.
        regenerate:
            If ``True``, overwrite existing generated test files.

        Returns
        -------
        list[Path]
            Paths to all generated test files.
        """
        if not context.tools:
            logger.info("No tools discovered — skipping tool test generation.")
            return []

        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = output_dir / "test_tools.py"

        if output_path.exists() and not regenerate:
            logger.info(
                "Tool tests already exist at %s (use --regenerate to overwrite).",
                output_path,
            )
            return []

        env = Environment(
            loader=FileSystemLoader(str(_TEMPLATE_DIR)),
            keep_trailing_newline=True,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        template = env.get_template("tool_tests.py.j2")

        from datetime import datetime, timezone

        rendered = template.render(
            scan_source=self.scan_source,
            framework=self.framework,
            timestamp=datetime.now(tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
            agent_type="http",
            agent_config='"http://localhost:8000/chat"',
            tools=self._prepare_tools(context.tools),
        )

        output_path.write_text(rendered, encoding="utf-8")
        logger.info("Generated tool tests: %s", output_path)
        return [output_path]
