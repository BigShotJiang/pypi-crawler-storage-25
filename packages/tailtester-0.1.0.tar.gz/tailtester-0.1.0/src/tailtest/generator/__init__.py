"""Test generator — auto-create test files from scan context."""

from tailtest.generator.engine import TestGenerator

__all__ = ["TestGenerator"]
