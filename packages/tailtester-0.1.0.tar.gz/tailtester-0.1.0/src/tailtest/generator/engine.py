"""Test generator orchestrator.

Coordinates the individual test generators (tool, prompt, safety) to
produce a complete set of auto-generated test files from scan context.
"""

from __future__ import annotations

import logging
from pathlib import Path

from tailtest.generator.prompt_tests import PromptTestGenerator
from tailtest.generator.safety_tests import SafetyTestGenerator
from tailtest.generator.tool_tests import ToolTestGenerator
from tailtest.models import ScanResult

logger = logging.getLogger(__name__)

# Categories that can be selected via --only
CATEGORIES = ("safety", "tools", "prompts", "all")


class TestGenerator:
    """Orchestrates test generation from scan context.

    Delegates to specialised generators for each test category:

    - :class:`ToolTestGenerator` — tests for discovered tools
    - :class:`PromptTestGenerator` — tests for discovered prompts
    - :class:`SafetyTestGenerator` — baseline safety tests (always generated)

    Usage::

        generator = TestGenerator()
        paths = await generator.generate(scan_result, output_dir)
    """

    async def generate(
        self,
        context: ScanResult,
        output_dir: Path,
        regenerate: bool = False,
        only: str = "all",
    ) -> list[Path]:
        """Generate test files from scan context.

        Parameters
        ----------
        context:
            A :class:`ScanResult` containing discovered tools, prompts, and agents.
        output_dir:
            Directory where generated test files will be written
            (typically ``.tailtest/tests/auto/``).
        regenerate:
            If ``True``, overwrite any existing generated test files.
        only:
            Category filter — one of ``"all"``, ``"safety"``, ``"tools"``,
            or ``"prompts"``.

        Returns
        -------
        list[Path]
            Paths to all generated test files.
        """
        output_dir.mkdir(parents=True, exist_ok=True)

        scan_source = ".tailtest/context/scan.json"
        framework = context.framework

        generated: list[Path] = []

        # Safety tests are always generated (unless filtered out)
        if only in ("all", "safety"):
            safety_gen = SafetyTestGenerator(
                framework=framework,
                scan_source=scan_source,
            )
            generated.extend(
                safety_gen.generate(context, output_dir, regenerate=regenerate)
            )

        # Tool tests — only if tools were discovered
        if only in ("all", "tools"):
            tool_gen = ToolTestGenerator(
                framework=framework,
                scan_source=scan_source,
            )
            generated.extend(
                tool_gen.generate(context, output_dir, regenerate=regenerate)
            )

        # Prompt tests — only if prompts were discovered
        if only in ("all", "prompts"):
            prompt_gen = PromptTestGenerator(
                framework=framework,
                scan_source=scan_source,
            )
            generated.extend(
                prompt_gen.generate(context, output_dir, regenerate=regenerate)
            )

        if generated:
            logger.info(
                "Generated %d test file(s) in %s", len(generated), output_dir
            )
        else:
            logger.info("No test files generated (nothing new to create).")

        return generated
