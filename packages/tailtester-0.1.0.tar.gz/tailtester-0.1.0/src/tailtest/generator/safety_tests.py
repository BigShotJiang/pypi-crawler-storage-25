"""Generate baseline safety test files.

Safety tests are always generated regardless of what was discovered
during scanning. They verify fundamental safety properties:
- No PII leakage in responses.
- Resistance to basic prompt injection.
- Refusal of harmful content requests.
- No infinite tool-call loops.
"""

from __future__ import annotations

import logging
from pathlib import Path

from jinja2 import Environment, FileSystemLoader

from tailtest.models import ScanResult

logger = logging.getLogger(__name__)

_TEMPLATE_DIR = Path(__file__).parent / "templates"


class SafetyTestGenerator:
    """Generates baseline safety test files.

    Unlike tool and prompt generators, safety tests are always created
    because every agent should pass these regardless of its purpose.
    """

    def __init__(
        self,
        framework: str = "unknown",
        scan_source: str = ".tailtest/context/scan.json",
    ) -> None:
        self.framework = framework
        self.scan_source = scan_source

    def generate(
        self,
        context: ScanResult,
        output_dir: Path,
        regenerate: bool = False,
    ) -> list[Path]:
        """Generate safety test files.

        Parameters
        ----------
        context:
            The scan result (used for framework metadata only).
        output_dir:
            Directory where generated test files will be written.
        regenerate:
            If ``True``, overwrite existing generated test files.

        Returns
        -------
        list[Path]
            Paths to all generated test files.
        """
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = output_dir / "test_safety.py"

        if output_path.exists() and not regenerate:
            logger.info(
                "Safety tests already exist at %s (use --regenerate to overwrite).",
                output_path,
            )
            return []

        env = Environment(
            loader=FileSystemLoader(str(_TEMPLATE_DIR)),
            keep_trailing_newline=True,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        template = env.get_template("safety_tests.py.j2")

        from datetime import datetime, timezone

        rendered = template.render(
            scan_source=self.scan_source,
            framework=self.framework,
            timestamp=datetime.now(tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
            agent_type="http",
            agent_config='"http://localhost:8000/chat"',
        )

        output_path.write_text(rendered, encoding="utf-8")
        logger.info("Generated safety tests: %s", output_path)
        return [output_path]
