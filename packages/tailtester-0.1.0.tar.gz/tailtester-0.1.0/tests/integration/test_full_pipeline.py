"""Integration tests — full pipeline from scan through test execution."""

from pathlib import Path

import pytest

from tailtest.context.sources.scanner import scan_project
from tailtest.context.store import save_scan, load_scan
from tailtest.models import ScanResult, TestSuiteResult
from tailtest.runner.engine import RunConfig, TestRunner


_HELLO_WORLD_DIR = Path(__file__).resolve().parents[2] / "examples" / "hello-world"


@pytest.fixture
def hello_world_path():
    if not _HELLO_WORLD_DIR.is_dir():
        pytest.skip("examples/hello-world directory not found")
    return _HELLO_WORLD_DIR


# --------------------------------------------------------------------------- #
# Scan + store round-trip
# --------------------------------------------------------------------------- #


async def test_scan_and_store_roundtrip(hello_world_path, tmp_path):
    """Scan hello-world, save to temp dir, load back."""
    result = await scan_project(hello_world_path)
    assert isinstance(result, ScanResult)

    save_scan(result, tmp_path)
    loaded = load_scan(tmp_path)
    assert loaded is not None
    assert loaded.framework == result.framework


# --------------------------------------------------------------------------- #
# Full run on hello-world test file
# --------------------------------------------------------------------------- #


async def test_pipeline_completes_end_to_end(hello_world_path):
    """Running the test engine on hello-world test file should complete."""
    test_file = hello_world_path / "test_support.py"
    if not test_file.is_file():
        pytest.skip("test_support.py not found in hello-world example")

    runner = TestRunner()
    result = await runner.run(test_file, config=RunConfig())
    assert isinstance(result, TestSuiteResult)
    assert result.total > 0


async def test_pipeline_results_match_expected(hello_world_path):
    """hello-world has 6 tests: 5 should pass, 1 should fail (medical advice)."""
    test_file = hello_world_path / "test_support.py"
    if not test_file.is_file():
        pytest.skip("test_support.py not found in hello-world example")

    runner = TestRunner()
    result = await runner.run(test_file, config=RunConfig())
    assert isinstance(result, TestSuiteResult)
    # The hello-world mock agent deliberately fails the "no medical advice" test
    # because it responds with ibuprofen advice. Expected: 5 pass, 1 fail.
    assert result.total == 6
    assert result.passed == 5
    assert result.failed == 1
