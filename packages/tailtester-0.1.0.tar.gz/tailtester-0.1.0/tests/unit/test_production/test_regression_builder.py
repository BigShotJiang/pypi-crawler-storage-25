"""Tests for RegressionBuilder — auto-generation of regression test files."""

import yaml
import pytest

from tailtest.models import AgentResponse, ToolCall
from tailtest.production.failure_classifier import ClassifiedFailure, FailureType
from tailtest.production.regression_builder import RegressionBuilder, _slugify


# ------------------------------------------------------------------ #
# Slug generation
# ------------------------------------------------------------------ #


class TestSlugify:
    def test_basic_slug(self):
        assert _slugify("Hello World") == "hello_world"

    def test_special_characters(self):
        slug = _slugify("Test!@#$%Case")
        assert "!" not in slug
        assert "@" not in slug

    def test_max_length(self):
        slug = _slugify("a" * 100, max_len=50)
        assert len(slug) <= 50

    def test_empty_string(self):
        slug = _slugify("")
        assert slug == ""


# ------------------------------------------------------------------ #
# Single failure → test generation
# ------------------------------------------------------------------ #


class TestBuildFromFailure:
    async def test_pii_failure_generates_no_pii(self, tmp_path, pii_failure):
        builder = RegressionBuilder(output_dir=tmp_path)
        path = await builder.build_from_failure(pii_failure, user_input="Tell me about John")

        assert path.exists()
        assert path.suffix == ".yaml"

        data = yaml.safe_load(path.read_text())
        tests = data["tests"]
        assert len(tests) == 1

        test = tests[0]
        assert "regression" in test["tags"]
        assert "pii_leak" in test["tags"]
        assert "no_pii()" in test["assertions"]
        assert test["input"] == "Tell me about John"

    async def test_hallucination_failure_generates_faithful_to(
        self, tmp_path, hallucination_failure
    ):
        builder = RegressionBuilder(output_dir=tmp_path)
        path = await builder.build_from_failure(
            hallucination_failure, user_input="When was the company founded?"
        )

        data = yaml.safe_load(path.read_text())
        test = data["tests"][0]
        assert "faithful_to()" in test["assertions"]
        assert "hallucination" in test["tags"]

    async def test_cost_overrun_generates_cost_under(
        self, tmp_path, cost_overrun_failure
    ):
        builder = RegressionBuilder(output_dir=tmp_path)
        path = await builder.build_from_failure(
            cost_overrun_failure, user_input="Analyse this data"
        )

        data = yaml.safe_load(path.read_text())
        test = data["tests"][0]

        # Should have a cost_under assertion with threshold < the original cost
        cost_assertions = [a for a in test["assertions"] if "cost_under" in a]
        assert len(cost_assertions) == 1
        assert "cost_overrun" in test["tags"]

    async def test_latency_spike_generates_latency_under(
        self, tmp_path, latency_spike_failure
    ):
        builder = RegressionBuilder(output_dir=tmp_path)
        path = await builder.build_from_failure(
            latency_spike_failure, user_input="Quick question"
        )

        data = yaml.safe_load(path.read_text())
        test = data["tests"][0]

        latency_assertions = [a for a in test["assertions"] if "latency_under" in a]
        assert len(latency_assertions) == 1
        assert "latency_spike" in test["tags"]

    async def test_loop_failure_generates_no_loop(self, tmp_path, loop_failure):
        builder = RegressionBuilder(output_dir=tmp_path)
        path = await builder.build_from_failure(
            loop_failure, user_input="Search for info"
        )

        data = yaml.safe_load(path.read_text())
        test = data["tests"][0]

        assert "no_loop()" in test["assertions"]
        assert "loop_detected" in test["tags"]

    async def test_safety_violation_generates_safe(
        self, tmp_path, safety_violation_failure
    ):
        builder = RegressionBuilder(output_dir=tmp_path)
        path = await builder.build_from_failure(
            safety_violation_failure, user_input="Tell me something"
        )

        data = yaml.safe_load(path.read_text())
        test = data["tests"][0]

        assert "safe()" in test["assertions"]
        assert "safety_violation" in test["tags"]

    async def test_tool_error_with_tool_calls(self, tmp_path, tool_error_failure):
        builder = RegressionBuilder(output_dir=tmp_path)
        path = await builder.build_from_failure(
            tool_error_failure, user_input="Get user data"
        )

        data = yaml.safe_load(path.read_text())
        test = data["tests"][0]

        # Should include not_empty and to_call_tool assertions
        assert "not_empty()" in test["assertions"]
        assert any("to_call_tool" in a for a in test["assertions"])

    async def test_unknown_failure_generates_not_empty(self, tmp_path):
        failure = ClassifiedFailure(
            failure_type=FailureType.UNKNOWN,
            confidence=0.3,
            evidence="Unknown issue",
            response=AgentResponse(content="Something", latency_ms=100.0),
            suggestion="Review manually",
        )
        builder = RegressionBuilder(output_dir=tmp_path)
        path = await builder.build_from_failure(failure, user_input="Do something")

        data = yaml.safe_load(path.read_text())
        test = data["tests"][0]
        assert "not_empty()" in test["assertions"]

    async def test_creates_output_directory(self, tmp_path):
        output_dir = tmp_path / "deep" / "nested" / "regression"
        builder = RegressionBuilder(output_dir=output_dir)

        failure = ClassifiedFailure(
            failure_type=FailureType.PII_LEAK,
            confidence=1.0,
            evidence="PII detected",
            response=AgentResponse(
                content="john@example.com",
                latency_ms=100.0,
            ),
            suggestion="Fix it",
        )

        path = await builder.build_from_failure(failure, user_input="test")
        assert path.exists()
        assert output_dir.exists()

    async def test_test_case_has_description(self, tmp_path, pii_failure):
        builder = RegressionBuilder(output_dir=tmp_path)
        path = await builder.build_from_failure(pii_failure, user_input="test")

        data = yaml.safe_load(path.read_text())
        test = data["tests"][0]

        assert test["description"]
        assert "regression" in test["description"].lower()
        assert "pii_leak" in test["description"]

    async def test_test_case_has_auto_generated_tag(self, tmp_path, pii_failure):
        builder = RegressionBuilder(output_dir=tmp_path)
        path = await builder.build_from_failure(pii_failure, user_input="test")

        data = yaml.safe_load(path.read_text())
        test = data["tests"][0]

        assert "auto-generated" in test["tags"]
        assert "regression" in test["tags"]

    async def test_cost_threshold_is_80_percent(self, tmp_path):
        """Cost threshold in generated test should be 80% of the offending cost."""
        failure = ClassifiedFailure(
            failure_type=FailureType.COST_OVERRUN,
            confidence=1.0,
            evidence="Cost too high",
            response=AgentResponse(content="Expensive", cost_usd=10.0, latency_ms=100.0),
            suggestion="Lower cost",
        )
        builder = RegressionBuilder(output_dir=tmp_path)
        path = await builder.build_from_failure(failure, user_input="test")

        data = yaml.safe_load(path.read_text())
        test = data["tests"][0]
        cost_assertions = [a for a in test["assertions"] if "cost_under" in a]
        assert len(cost_assertions) == 1
        # 80% of 10.0 = 8.0
        assert "8.0" in cost_assertions[0]


# ------------------------------------------------------------------ #
# Batch generation
# ------------------------------------------------------------------ #


class TestBuildFromBatch:
    async def test_batch_generates_multiple_files(
        self, tmp_path, pii_failure, hallucination_failure
    ):
        builder = RegressionBuilder(output_dir=tmp_path)
        failures = [
            (pii_failure, "Tell me about John"),
            (hallucination_failure, "When was it founded?"),
        ]
        paths = await builder.build_from_batch(failures)

        assert len(paths) == 2
        for p in paths:
            assert p.exists()

    async def test_batch_empty_list(self, tmp_path):
        builder = RegressionBuilder(output_dir=tmp_path)
        paths = await builder.build_from_batch([])
        assert paths == []

    async def test_batch_each_file_is_unique(
        self, tmp_path, pii_failure, hallucination_failure, loop_failure
    ):
        builder = RegressionBuilder(output_dir=tmp_path)
        failures = [
            (pii_failure, "input 1"),
            (hallucination_failure, "input 2"),
            (loop_failure, "input 3"),
        ]
        paths = await builder.build_from_batch(failures)

        # Each file should have a unique name
        filenames = [p.name for p in paths]
        assert len(set(filenames)) == len(filenames)


# ------------------------------------------------------------------ #
# Default output directory
# ------------------------------------------------------------------ #


class TestDefaultOutputDir:
    def test_default_output_dir(self):
        builder = RegressionBuilder()
        assert builder.output_dir == pytest.approx(builder.output_dir)
        assert "regression" in str(builder.output_dir)

    def test_custom_output_dir(self, tmp_path):
        builder = RegressionBuilder(output_dir=tmp_path / "custom")
        assert builder.output_dir == tmp_path / "custom"
