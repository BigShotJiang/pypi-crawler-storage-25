"""Tests for FailureDetector — quality metric computation and drift detection."""

import json

import pytest

from tailtest.models import AgentResponse, ToolCall
from tailtest.production.failure_detector import (
    DriftAlert,
    FailureDetector,
    QualityMetrics,
)


# ------------------------------------------------------------------ #
# QualityMetrics serialisation
# ------------------------------------------------------------------ #


class TestQualityMetrics:
    def test_to_dict(self, baseline_metrics):
        d = baseline_metrics.to_dict()
        assert d["total_responses"] == 10
        assert d["avg_latency_ms"] == 130.0
        assert d["avg_cost_usd"] == 0.0023

    def test_from_dict(self):
        data = {
            "total_responses": 5,
            "avg_latency_ms": 200.0,
            "avg_cost_usd": 0.005,
            "error_rate": 10.0,
            "pii_leak_rate": 0.0,
            "avg_tool_calls": 2.0,
            "total_cost_usd": 0.025,
        }
        metrics = QualityMetrics.from_dict(data)
        assert metrics.total_responses == 5
        assert metrics.avg_latency_ms == 200.0

    def test_from_dict_ignores_extra_keys(self):
        data = {
            "total_responses": 3,
            "avg_latency_ms": 100.0,
            "avg_cost_usd": 0.001,
            "error_rate": 0.0,
            "pii_leak_rate": 0.0,
            "avg_tool_calls": 0.0,
            "total_cost_usd": 0.003,
            "extra_key": "should be ignored",
        }
        metrics = QualityMetrics.from_dict(data)
        assert metrics.total_responses == 3

    def test_roundtrip(self, baseline_metrics):
        d = baseline_metrics.to_dict()
        restored = QualityMetrics.from_dict(d)
        assert restored.total_responses == baseline_metrics.total_responses
        assert restored.avg_latency_ms == baseline_metrics.avg_latency_ms
        assert restored.avg_cost_usd == baseline_metrics.avg_cost_usd
        assert restored.error_rate == baseline_metrics.error_rate
        assert restored.pii_leak_rate == baseline_metrics.pii_leak_rate


# ------------------------------------------------------------------ #
# Metric computation
# ------------------------------------------------------------------ #


class TestComputeMetrics:
    async def test_compute_from_healthy_batch(self, healthy_responses):
        detector = FailureDetector()
        metrics = await detector.compute_metrics(healthy_responses)

        assert metrics.total_responses == 3
        assert metrics.avg_latency_ms == pytest.approx(
            (120.0 + 150.0 + 100.0) / 3, rel=1e-2
        )
        assert metrics.avg_cost_usd == pytest.approx(
            (0.002 + 0.003 + 0.002) / 3, rel=1e-2
        )
        assert metrics.error_rate == 0.0
        assert metrics.pii_leak_rate == 0.0
        assert metrics.avg_tool_calls == pytest.approx(1.0)
        assert metrics.total_cost_usd == pytest.approx(0.007, rel=1e-2)

    async def test_compute_empty_batch(self):
        detector = FailureDetector()
        metrics = await detector.compute_metrics([])
        assert metrics.total_responses == 0
        assert metrics.avg_latency_ms == 0.0
        assert metrics.avg_cost_usd == 0.0

    async def test_compute_with_errors(self):
        responses = [
            AgentResponse(content="Good response", latency_ms=100.0, cost_usd=0.001),
            AgentResponse(content="", latency_ms=200.0, cost_usd=0.002),  # empty = error
            AgentResponse(content="   ", latency_ms=150.0, cost_usd=0.001),  # whitespace = error
        ]
        detector = FailureDetector()
        metrics = await detector.compute_metrics(responses)

        assert metrics.total_responses == 3
        assert metrics.error_rate == pytest.approx(200 / 3, rel=1e-1)

    async def test_compute_with_pii(self):
        responses = [
            AgentResponse(content="Call john@example.com", latency_ms=100.0, cost_usd=0.001),
            AgentResponse(content="Clean response", latency_ms=100.0, cost_usd=0.001),
        ]
        detector = FailureDetector()
        metrics = await detector.compute_metrics(responses)

        assert metrics.pii_leak_rate == 50.0

    async def test_compute_with_missing_latency(self):
        responses = [
            AgentResponse(content="Response 1", latency_ms=100.0, cost_usd=0.001),
            AgentResponse(content="Response 2", latency_ms=None, cost_usd=0.002),
        ]
        detector = FailureDetector()
        metrics = await detector.compute_metrics(responses)

        # Only the response with latency should contribute to the average
        assert metrics.avg_latency_ms == 100.0

    async def test_compute_with_missing_cost(self):
        responses = [
            AgentResponse(content="Response 1", latency_ms=100.0, cost_usd=None),
            AgentResponse(content="Response 2", latency_ms=100.0, cost_usd=0.004),
        ]
        detector = FailureDetector()
        metrics = await detector.compute_metrics(responses)

        assert metrics.avg_cost_usd == 0.004
        assert metrics.total_cost_usd == 0.004

    async def test_history_accumulates(self, healthy_responses):
        detector = FailureDetector()
        assert len(detector.history) == 0

        await detector.compute_metrics(healthy_responses)
        assert len(detector.history) == 1

        await detector.compute_metrics(healthy_responses)
        assert len(detector.history) == 2

    async def test_tool_call_counting(self):
        responses = [
            AgentResponse(
                content="Done",
                latency_ms=100.0,
                cost_usd=0.001,
                tool_calls=[
                    ToolCall(name="a", arguments={}),
                    ToolCall(name="b", arguments={}),
                ],
            ),
            AgentResponse(
                content="Done",
                latency_ms=100.0,
                cost_usd=0.001,
                tool_calls=[],
            ),
        ]
        detector = FailureDetector()
        metrics = await detector.compute_metrics(responses)

        assert metrics.avg_tool_calls == 1.0  # (2 + 0) / 2


# ------------------------------------------------------------------ #
# Drift detection
# ------------------------------------------------------------------ #


class TestDriftDetection:
    def test_detect_drift_no_baseline_raises(self):
        detector = FailureDetector()
        current = QualityMetrics(total_responses=1, avg_latency_ms=100.0)
        with pytest.raises(ValueError, match="No baseline set"):
            detector.detect_drift(current)

    def test_detect_drift_no_issues(self, baseline_metrics):
        detector = FailureDetector(baseline=baseline_metrics)
        current = QualityMetrics(
            total_responses=10,
            avg_latency_ms=140.0,  # within 2x
            avg_cost_usd=0.003,  # within 2x
            error_rate=0.0,
            pii_leak_rate=0.0,
        )
        alerts = detector.detect_drift(current)
        assert len(alerts) == 0

    def test_detect_latency_spike(self, baseline_metrics):
        detector = FailureDetector(baseline=baseline_metrics)
        current = QualityMetrics(
            total_responses=10,
            avg_latency_ms=300.0,  # >2x of 130
            avg_cost_usd=0.002,
            error_rate=0.0,
            pii_leak_rate=0.0,
        )
        alerts = detector.detect_drift(current)
        latency_alerts = [a for a in alerts if a.metric_name == "avg_latency_ms"]
        assert len(latency_alerts) == 1
        assert latency_alerts[0].severity == "warning"
        assert "Latency spike" in latency_alerts[0].message

    def test_detect_cost_spike(self, baseline_metrics):
        detector = FailureDetector(baseline=baseline_metrics)
        current = QualityMetrics(
            total_responses=10,
            avg_latency_ms=130.0,
            avg_cost_usd=0.01,  # >2x of 0.0023
            error_rate=0.0,
            pii_leak_rate=0.0,
        )
        alerts = detector.detect_drift(current)
        cost_alerts = [a for a in alerts if a.metric_name == "avg_cost_usd"]
        assert len(cost_alerts) == 1
        assert cost_alerts[0].severity == "warning"

    def test_detect_error_rate_increase(self):
        baseline = QualityMetrics(
            total_responses=10,
            avg_latency_ms=100.0,
            avg_cost_usd=0.002,
            error_rate=5.0,
            pii_leak_rate=0.0,
        )
        detector = FailureDetector(baseline=baseline)
        current = QualityMetrics(
            total_responses=10,
            avg_latency_ms=100.0,
            avg_cost_usd=0.002,
            error_rate=10.0,  # 2x > 1.5x threshold
            pii_leak_rate=0.0,
        )
        alerts = detector.detect_drift(current)
        error_alerts = [a for a in alerts if a.metric_name == "error_rate"]
        assert len(error_alerts) == 1
        assert error_alerts[0].severity == "critical"

    def test_detect_error_rate_from_zero(self, baseline_metrics):
        """Error rate going from 0 to non-zero should alert."""
        detector = FailureDetector(baseline=baseline_metrics)
        current = QualityMetrics(
            total_responses=10,
            avg_latency_ms=130.0,
            avg_cost_usd=0.002,
            error_rate=5.0,  # from 0 to 5
            pii_leak_rate=0.0,
        )
        alerts = detector.detect_drift(current)
        error_alerts = [a for a in alerts if a.metric_name == "error_rate"]
        assert len(error_alerts) == 1
        assert error_alerts[0].severity == "critical"

    def test_detect_pii_leak_increase(self, baseline_metrics):
        """Any PII increase is critical."""
        detector = FailureDetector(baseline=baseline_metrics)
        current = QualityMetrics(
            total_responses=10,
            avg_latency_ms=130.0,
            avg_cost_usd=0.002,
            error_rate=0.0,
            pii_leak_rate=1.0,  # any increase from 0
        )
        alerts = detector.detect_drift(current)
        pii_alerts = [a for a in alerts if a.metric_name == "pii_leak_rate"]
        assert len(pii_alerts) == 1
        assert pii_alerts[0].severity == "critical"

    def test_detect_multiple_issues(self, baseline_metrics):
        """Multiple degradations should produce multiple alerts."""
        detector = FailureDetector(baseline=baseline_metrics)
        current = QualityMetrics(
            total_responses=10,
            avg_latency_ms=500.0,  # spike
            avg_cost_usd=0.01,  # spike
            error_rate=10.0,  # new errors
            pii_leak_rate=5.0,  # PII increase
        )
        alerts = detector.detect_drift(current)
        assert len(alerts) >= 3  # at least latency, cost, error_rate, pii

    def test_no_alert_when_within_threshold(self, baseline_metrics):
        """Slight increases within threshold should not alert."""
        detector = FailureDetector(baseline=baseline_metrics)
        current = QualityMetrics(
            total_responses=10,
            avg_latency_ms=200.0,  # 1.5x, within 2x threshold
            avg_cost_usd=0.003,  # within 2x
            error_rate=0.0,
            pii_leak_rate=0.0,
        )
        alerts = detector.detect_drift(current)
        assert len(alerts) == 0

    def test_drift_alert_has_timestamp(self, baseline_metrics):
        detector = FailureDetector(baseline=baseline_metrics)
        current = QualityMetrics(
            total_responses=10,
            avg_latency_ms=500.0,
            avg_cost_usd=0.002,
            error_rate=0.0,
            pii_leak_rate=0.0,
        )
        alerts = detector.detect_drift(current)
        assert len(alerts) > 0
        assert alerts[0].timestamp  # timestamp is set


# ------------------------------------------------------------------ #
# Baseline persistence
# ------------------------------------------------------------------ #


class TestBaselinePersistence:
    def test_save_and_load_baseline(self, tmp_path, baseline_metrics):
        detector = FailureDetector()
        detector.set_baseline(baseline_metrics)

        path = tmp_path / "baseline.json"
        detector.save_baseline(path)

        assert path.exists()
        loaded = detector.load_baseline(path)
        assert loaded.total_responses == baseline_metrics.total_responses
        assert loaded.avg_latency_ms == baseline_metrics.avg_latency_ms
        assert loaded.avg_cost_usd == baseline_metrics.avg_cost_usd

    def test_save_no_baseline_raises(self, tmp_path):
        detector = FailureDetector()
        with pytest.raises(ValueError, match="No baseline set"):
            detector.save_baseline(tmp_path / "baseline.json")

    def test_save_creates_parent_dirs(self, tmp_path, baseline_metrics):
        detector = FailureDetector()
        detector.set_baseline(baseline_metrics)

        path = tmp_path / "nested" / "dir" / "baseline.json"
        detector.save_baseline(path)
        assert path.exists()

    def test_load_sets_active_baseline(self, tmp_path, baseline_metrics):
        detector = FailureDetector()
        assert detector.baseline is None

        path = tmp_path / "baseline.json"
        path.write_text(json.dumps(baseline_metrics.to_dict()))

        detector.load_baseline(path)
        assert detector.baseline is not None
        assert detector.baseline.total_responses == 10
