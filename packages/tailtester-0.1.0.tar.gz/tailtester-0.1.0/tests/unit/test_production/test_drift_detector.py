"""Tests for DriftDetector — higher-level drift monitoring and baseline management."""

import json

import pytest

from tailtest.models import AgentResponse, ToolCall
from tailtest.production.drift_detector import DriftDetector
from tailtest.production.failure_detector import QualityMetrics


# ------------------------------------------------------------------ #
# Baseline management
# ------------------------------------------------------------------ #


class TestBaselineManagement:
    async def test_set_baseline_from_responses(self, tmp_path, healthy_responses):
        detector = DriftDetector(baseline_path=tmp_path / "baseline.json")
        metrics = await detector.set_baseline_from_responses(healthy_responses)

        assert metrics.total_responses == 3
        assert detector.baseline is not None
        assert (tmp_path / "baseline.json").exists()

    async def test_auto_load_baseline(self, tmp_path, baseline_metrics):
        """Baseline should be auto-loaded if file exists."""
        path = tmp_path / "baseline.json"
        path.write_text(json.dumps(baseline_metrics.to_dict()))

        detector = DriftDetector(baseline_path=path)
        assert detector.baseline is not None
        assert detector.baseline.total_responses == 10

    async def test_no_auto_load_if_missing(self, tmp_path):
        detector = DriftDetector(baseline_path=tmp_path / "nonexistent.json")
        assert detector.baseline is None

    async def test_baseline_property(self, tmp_path, healthy_responses):
        detector = DriftDetector(baseline_path=tmp_path / "baseline.json")
        assert detector.baseline is None

        await detector.set_baseline_from_responses(healthy_responses)
        assert detector.baseline is not None

    async def test_history_property(self, tmp_path, healthy_responses):
        detector = DriftDetector(baseline_path=tmp_path / "baseline.json")
        assert len(detector.history) == 0

        await detector.set_baseline_from_responses(healthy_responses)
        assert len(detector.history) == 1


# ------------------------------------------------------------------ #
# Set baseline from run
# ------------------------------------------------------------------ #


class TestSetBaselineFromRun:
    async def test_from_run_report(self, tmp_path):
        """Set baseline from a run report JSON file."""
        reports_dir = tmp_path / "reports"
        reports_dir.mkdir()

        report_data = {
            "results": [
                {
                    "agent_response": {
                        "content": "Response 1",
                        "latency_ms": 100.0,
                        "cost_usd": 0.002,
                        "tool_calls": [],
                    }
                },
                {
                    "agent_response": {
                        "content": "Response 2",
                        "latency_ms": 150.0,
                        "cost_usd": 0.003,
                        "tool_calls": [],
                    }
                },
            ]
        }
        (reports_dir / "run-123.json").write_text(json.dumps(report_data))

        detector = DriftDetector(
            baseline_path=tmp_path / "baseline.json",
            reports_dir=reports_dir,
        )
        metrics = await detector.set_baseline_from_run("run-123")

        assert metrics.total_responses == 2
        assert detector.baseline is not None

    async def test_from_run_not_found(self, tmp_path):
        reports_dir = tmp_path / "reports"
        reports_dir.mkdir()

        detector = DriftDetector(
            baseline_path=tmp_path / "baseline.json",
            reports_dir=reports_dir,
        )

        with pytest.raises(FileNotFoundError, match="No report found"):
            await detector.set_baseline_from_run("nonexistent")

    async def test_from_run_empty_report(self, tmp_path):
        reports_dir = tmp_path / "reports"
        reports_dir.mkdir()

        (reports_dir / "run-empty.json").write_text(json.dumps({"results": []}))

        detector = DriftDetector(
            baseline_path=tmp_path / "baseline.json",
            reports_dir=reports_dir,
        )

        with pytest.raises(ValueError, match="No agent responses"):
            await detector.set_baseline_from_run("run-empty")

    async def test_from_run_prefix_match(self, tmp_path):
        """Should find report by prefix match."""
        reports_dir = tmp_path / "reports"
        reports_dir.mkdir()

        report_data = {
            "results": [
                {
                    "agent_response": {
                        "content": "Response",
                        "latency_ms": 100.0,
                        "cost_usd": 0.002,
                        "tool_calls": [],
                    }
                }
            ]
        }
        (reports_dir / "my-run-456-2026-03-31.json").write_text(
            json.dumps(report_data)
        )

        detector = DriftDetector(
            baseline_path=tmp_path / "baseline.json",
            reports_dir=reports_dir,
        )
        metrics = await detector.set_baseline_from_run("run-456")
        assert metrics.total_responses == 1


# ------------------------------------------------------------------ #
# Compare to baseline
# ------------------------------------------------------------------ #


class TestCompareToBaseline:
    async def test_compare_no_baseline_raises(self, tmp_path, healthy_responses):
        detector = DriftDetector(baseline_path=tmp_path / "baseline.json")

        with pytest.raises(ValueError, match="No baseline set"):
            await detector.compare_to_baseline(healthy_responses)

    async def test_compare_no_drift(self, tmp_path, healthy_responses):
        detector = DriftDetector(baseline_path=tmp_path / "baseline.json")
        await detector.set_baseline_from_responses(healthy_responses)

        # Compare with same data — no drift
        alerts = await detector.compare_to_baseline(healthy_responses)
        assert len(alerts) == 0

    async def test_compare_detects_latency_drift(self, tmp_path, healthy_responses):
        detector = DriftDetector(baseline_path=tmp_path / "baseline.json")
        await detector.set_baseline_from_responses(healthy_responses)

        # Create degraded responses with high latency
        slow_responses = [
            AgentResponse(
                content="Slow response",
                latency_ms=1000.0,
                cost_usd=0.002,
            )
            for _ in range(3)
        ]
        alerts = await detector.compare_to_baseline(slow_responses)
        latency_alerts = [a for a in alerts if a.metric_name == "avg_latency_ms"]
        assert len(latency_alerts) == 1

    async def test_compare_detects_pii_drift(self, tmp_path, healthy_responses):
        detector = DriftDetector(baseline_path=tmp_path / "baseline.json")
        await detector.set_baseline_from_responses(healthy_responses)

        pii_responses = [
            AgentResponse(
                content="Contact john@example.com",
                latency_ms=100.0,
                cost_usd=0.002,
            ),
        ]
        alerts = await detector.compare_to_baseline(pii_responses)
        pii_alerts = [a for a in alerts if a.metric_name == "pii_leak_rate"]
        assert len(pii_alerts) == 1
        assert pii_alerts[0].severity == "critical"


# ------------------------------------------------------------------ #
# Detect from traces
# ------------------------------------------------------------------ #


class TestDetectFromTraces:
    async def test_detect_from_traces_dir(self, tmp_path, healthy_responses):
        # Set up baseline
        detector = DriftDetector(baseline_path=tmp_path / "baseline.json")
        await detector.set_baseline_from_responses(healthy_responses)

        # Create trace files
        traces_dir = tmp_path / "traces"
        traces_dir.mkdir()

        for i, resp in enumerate(healthy_responses):
            (traces_dir / f"trace_{i}.json").write_text(resp.model_dump_json())

        alerts = await detector.detect_from_traces(traces_dir)
        assert isinstance(alerts, list)

    async def test_detect_from_traces_missing_dir(self, tmp_path, healthy_responses):
        detector = DriftDetector(baseline_path=tmp_path / "baseline.json")
        await detector.set_baseline_from_responses(healthy_responses)

        with pytest.raises(FileNotFoundError):
            await detector.detect_from_traces(tmp_path / "nonexistent")

    async def test_detect_from_traces_array_format(self, tmp_path, healthy_responses):
        detector = DriftDetector(baseline_path=tmp_path / "baseline.json")
        await detector.set_baseline_from_responses(healthy_responses)

        traces_dir = tmp_path / "traces"
        traces_dir.mkdir()

        # Write responses as an array in a single file
        responses_data = [
            json.loads(r.model_dump_json()) for r in healthy_responses
        ]
        (traces_dir / "batch.json").write_text(json.dumps(responses_data))

        alerts = await detector.detect_from_traces(traces_dir)
        assert isinstance(alerts, list)

    async def test_detect_from_traces_wrapped_format(self, tmp_path, healthy_responses):
        detector = DriftDetector(baseline_path=tmp_path / "baseline.json")
        await detector.set_baseline_from_responses(healthy_responses)

        traces_dir = tmp_path / "traces"
        traces_dir.mkdir()

        # Write in wrapped format
        wrapped = {
            "responses": [json.loads(r.model_dump_json()) for r in healthy_responses]
        }
        (traces_dir / "wrapped.json").write_text(json.dumps(wrapped))

        alerts = await detector.detect_from_traces(traces_dir)
        assert isinstance(alerts, list)

    async def test_detect_from_traces_invalid_file(self, tmp_path, healthy_responses):
        """Invalid trace files should be skipped without crashing."""
        detector = DriftDetector(baseline_path=tmp_path / "baseline.json")
        await detector.set_baseline_from_responses(healthy_responses)

        traces_dir = tmp_path / "traces"
        traces_dir.mkdir()

        # Write a valid trace
        (traces_dir / "good.json").write_text(
            healthy_responses[0].model_dump_json()
        )
        # Write an invalid trace
        (traces_dir / "bad.json").write_text("not valid json {{{")

        # Should not raise
        alerts = await detector.detect_from_traces(traces_dir)
        assert isinstance(alerts, list)

    async def test_detect_from_traces_empty_dir(self, tmp_path, healthy_responses):
        detector = DriftDetector(baseline_path=tmp_path / "baseline.json")
        await detector.set_baseline_from_responses(healthy_responses)

        traces_dir = tmp_path / "traces"
        traces_dir.mkdir()

        # Empty directory — no traces
        alerts = await detector.detect_from_traces(traces_dir)
        assert alerts == []
