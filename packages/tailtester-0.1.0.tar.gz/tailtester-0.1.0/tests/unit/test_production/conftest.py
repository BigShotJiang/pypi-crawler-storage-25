"""Shared fixtures for production module tests."""

import pytest

from tailtest.models import AgentResponse, ToolCall, TokenUsage
from tailtest.production.failure_classifier import ClassifiedFailure, FailureType
from tailtest.production.failure_detector import QualityMetrics


@pytest.fixture
def healthy_responses():
    """A batch of healthy agent responses with normal metrics."""
    return [
        AgentResponse(
            content="The weather today is sunny with a high of 72F.",
            latency_ms=120.0,
            cost_usd=0.002,
            tool_calls=[ToolCall(name="weather", arguments={"city": "NYC"})],
        ),
        AgentResponse(
            content="Your order #12345 has been shipped.",
            latency_ms=150.0,
            cost_usd=0.003,
            tool_calls=[ToolCall(name="lookup_order", arguments={"id": "12345"})],
        ),
        AgentResponse(
            content="I've scheduled your meeting for 3pm tomorrow.",
            latency_ms=100.0,
            cost_usd=0.002,
            tool_calls=[
                ToolCall(name="calendar", arguments={"action": "create"}),
            ],
        ),
    ]


@pytest.fixture
def degraded_responses():
    """A batch of responses showing quality degradation."""
    return [
        AgentResponse(
            content="Contact john@example.com for help.",  # PII leak
            latency_ms=500.0,  # High latency
            cost_usd=0.010,  # High cost
        ),
        AgentResponse(
            content="",  # Empty response (error)
            latency_ms=800.0,
            cost_usd=0.015,
        ),
        AgentResponse(
            content="Your SSN is 123-45-6789.",  # PII leak
            latency_ms=600.0,
            cost_usd=0.012,
        ),
    ]


@pytest.fixture
def baseline_metrics():
    """A healthy quality baseline."""
    return QualityMetrics(
        total_responses=10,
        avg_latency_ms=130.0,
        avg_cost_usd=0.0023,
        error_rate=0.0,
        pii_leak_rate=0.0,
        avg_tool_calls=1.0,
        total_cost_usd=0.023,
    )


@pytest.fixture
def pii_failure():
    """A classified PII leak failure."""
    return ClassifiedFailure(
        failure_type=FailureType.PII_LEAK,
        confidence=1.0,
        evidence="Email address detected in response",
        response=AgentResponse(
            content="Contact john@example.com for details.",
            latency_ms=100.0,
            cost_usd=0.002,
        ),
        suggestion="Add a no_pii() assertion.",
    )


@pytest.fixture
def hallucination_failure():
    """A classified hallucination failure."""
    return ClassifiedFailure(
        failure_type=FailureType.HALLUCINATION,
        confidence=0.85,
        evidence="Response contains fabricated information",
        response=AgentResponse(
            content="The company was founded in 1842 by Alexander Graham Bell.",
            latency_ms=200.0,
            cost_usd=0.003,
        ),
        suggestion="Add a faithful_to() assertion.",
    )


@pytest.fixture
def cost_overrun_failure():
    """A classified cost overrun failure."""
    return ClassifiedFailure(
        failure_type=FailureType.COST_OVERRUN,
        confidence=1.0,
        evidence="Cost $2.5000 exceeds threshold $1.0000",
        response=AgentResponse(
            content="Here is a very detailed analysis...",
            latency_ms=5000.0,
            cost_usd=2.50,
        ),
        suggestion="Add a cost_under(1.0) assertion.",
    )


@pytest.fixture
def latency_spike_failure():
    """A classified latency spike failure."""
    return ClassifiedFailure(
        failure_type=FailureType.LATENCY_SPIKE,
        confidence=1.0,
        evidence="Latency 15000ms exceeds threshold 10000ms",
        response=AgentResponse(
            content="Finally got the result.",
            latency_ms=15000.0,
            cost_usd=0.005,
        ),
        suggestion="Add a latency_under(10000) assertion.",
    )


@pytest.fixture
def loop_failure():
    """A classified loop detection failure."""
    return ClassifiedFailure(
        failure_type=FailureType.LOOP_DETECTED,
        confidence=1.0,
        evidence="Tool 'search' called 5 times consecutively",
        response=AgentResponse(
            content="Done processing.",
            latency_ms=3000.0,
            cost_usd=0.05,
            tool_calls=[ToolCall(name="search", arguments={"q": "test"})] * 5,
        ),
        suggestion="Add a no_loop() assertion.",
    )


@pytest.fixture
def tool_error_failure():
    """A classified tool error failure."""
    return ClassifiedFailure(
        failure_type=FailureType.TOOL_ERROR,
        confidence=0.8,
        evidence="Agent returned an empty response.",
        response=AgentResponse(
            content="",
            latency_ms=200.0,
            cost_usd=0.001,
            tool_calls=[
                ToolCall(name="database_query", arguments={"sql": "SELECT * FROM users"}),
            ],
        ),
        suggestion="Check that the agent adapter correctly extracts the response content.",
    )


@pytest.fixture
def safety_violation_failure():
    """A classified safety violation failure."""
    return ClassifiedFailure(
        failure_type=FailureType.SAFETY_VIOLATION,
        confidence=0.9,
        evidence="Response contains harmful content",
        response=AgentResponse(
            content="Here is how to hack a system...",
            latency_ms=150.0,
            cost_usd=0.003,
        ),
        suggestion="Add a safe() assertion.",
    )
