"""Tests for sparkline and trend indicator utilities."""

from __future__ import annotations

import pytest

from tailtest.reporting.sparkline import sparkline, trend_indicator


class TestSparklineFunction:
    def test_sparkline_ascending(self):
        """Ascending values produce chars that increase in height."""
        result = sparkline([1, 2, 3, 4, 5])
        assert len(result) == 5
        # First char should be the shortest, last the tallest
        assert result[0] == "\u2581"
        assert result[-1] == "\u2588"

    def test_sparkline_descending(self):
        """Descending values produce chars that decrease in height."""
        result = sparkline([5, 4, 3, 2, 1])
        assert len(result) == 5
        assert result[0] == "\u2588"
        assert result[-1] == "\u2581"

    def test_sparkline_empty(self):
        """Empty input returns empty string."""
        assert sparkline([]) == ""

    def test_sparkline_single_value(self):
        """Single value produces one mid-height block."""
        result = sparkline([42])
        assert len(result) == 1
        # Single value has span=0, so mid-height block is used
        assert result == "\u2585"

    def test_sparkline_all_same(self):
        """All-same values produce uniform characters."""
        result = sparkline([7, 7, 7, 7])
        assert len(result) == 4
        assert len(set(result)) == 1  # all chars identical

    def test_sparkline_two_values(self):
        """Two values: min gets lowest block, max gets highest."""
        result = sparkline([0, 100])
        assert result[0] == "\u2581"
        assert result[1] == "\u2588"

    def test_sparkline_negative_values(self):
        """Negative values are handled correctly."""
        result = sparkline([-10, -5, 0, 5, 10])
        assert len(result) == 5
        assert result[0] == "\u2581"  # min
        assert result[-1] == "\u2588"  # max


class TestTrendIndicator:
    def test_trend_indicator_up(self):
        """Increasing trend returns up arrow."""
        result = trend_indicator([10, 20, 30, 40, 50, 60])
        assert result == "\u2191"

    def test_trend_indicator_down(self):
        """Decreasing trend returns down arrow."""
        result = trend_indicator([60, 50, 40, 30, 20, 10])
        assert result == "\u2193"

    def test_trend_indicator_flat(self):
        """Flat values return right arrow."""
        result = trend_indicator([50, 50, 50, 50, 50, 50])
        assert result == "\u2192"

    def test_trend_indicator_empty(self):
        """Empty list returns flat arrow."""
        assert trend_indicator([]) == "\u2192"

    def test_trend_indicator_single(self):
        """Single value returns flat arrow."""
        assert trend_indicator([42]) == "\u2192"

    def test_trend_indicator_slightly_up(self):
        """Values with >5% increase return up arrow."""
        # First third avg = 10, last third avg = 20 => 100% increase
        result = trend_indicator([10, 10, 10, 15, 20, 20])
        assert result == "\u2191"

    def test_trend_indicator_slightly_down(self):
        """Values with >5% decrease return down arrow."""
        result = trend_indicator([20, 20, 20, 15, 10, 10])
        assert result == "\u2193"
