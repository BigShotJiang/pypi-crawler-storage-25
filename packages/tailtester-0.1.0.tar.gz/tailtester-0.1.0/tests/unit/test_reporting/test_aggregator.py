"""Tests for ReportAggregator, sparklines, trend indicators, and HTML generation."""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from tailtest.models import (
    AgentResponse,
    AssertionResult,
    TestCase,
    TestResult,
    TestSuiteResult,
)
from tailtest.production.failure_detector import DriftAlert
from tailtest.reporting.aggregator import (
    FlakyTest,
    ReportAggregator,
    TrendPoint,
    TrendReport,
)
from tailtest.reporting.html_report import HTMLReportGenerator
from tailtest.reporting.sparkline import sparkline, trend_indicator


# ── Fixtures ───────────────────────────────────────────────────────────────


def _make_test_result(
    name: str, passed: bool, timestamp: datetime | None = None, cost: float = 0.002
) -> TestResult:
    """Helper to build a TestResult with minimal boilerplate."""
    return TestResult(
        test_case=TestCase(
            name=name,
            input="test input",
            assertions=["contains('hello')"],
        ),
        passed=passed,
        assertion_results=[
            AssertionResult(
                passed=passed,
                assertion_type="contains",
                expected="hello",
                actual="hello world" if passed else "goodbye",
                message="OK" if passed else "FAIL",
            )
        ],
        agent_response=AgentResponse(content="hello world" if passed else "goodbye"),
        duration_ms=150.0,
        cost_usd=cost,
        timestamp=timestamp or datetime.now(timezone.utc),
    )


def _make_suite(
    results: list[TestResult],
    reliability: float | None = None,
) -> TestSuiteResult:
    """Helper to build a TestSuiteResult."""
    passed = sum(1 for r in results if r.passed)
    failed = len(results) - passed
    total_cost = sum(r.cost_usd for r in results)
    total_dur = sum(r.duration_ms for r in results)
    return TestSuiteResult(
        total=len(results),
        passed=passed,
        failed=failed,
        skipped=0,
        duration_ms=total_dur,
        total_cost_usd=total_cost,
        results=results,
        reliability_score=reliability,
    )


def _write_report(reports_dir: Path, suite: TestSuiteResult, index: int = 0) -> Path:
    """Serialize a suite to JSON in the reports directory."""
    reports_dir.mkdir(parents=True, exist_ok=True)
    ts = f"20260101_{index:06d}"
    path = reports_dir / f"report_{ts}.json"
    data = suite.model_dump(mode="json")
    path.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
    return path


@pytest.fixture
def reports_dir(tmp_path: Path) -> Path:
    """Provide a temporary reports directory."""
    return tmp_path / "reports"


@pytest.fixture
def aggregator(reports_dir: Path) -> ReportAggregator:
    """Provide a ReportAggregator pointed at the temp dir."""
    return ReportAggregator(reports_dir=reports_dir)


# ── ReportAggregator: loading ──────────────────────────────────────────────


class TestLoadReports:
    def test_loads_reports_from_directory(
        self, reports_dir: Path, aggregator: ReportAggregator
    ):
        """Reports are loaded and deserialized correctly."""
        now = datetime.now(timezone.utc)
        suite = _make_suite(
            [
                _make_test_result("test_a", True, now),
                _make_test_result("test_b", False, now),
            ]
        )
        _write_report(reports_dir, suite, index=1)

        loaded = aggregator.load_all_reports()
        assert len(loaded) == 1
        assert loaded[0].total == 2
        assert loaded[0].passed == 1
        assert loaded[0].failed == 1

    def test_loads_multiple_reports_sorted(
        self, reports_dir: Path, aggregator: ReportAggregator
    ):
        """Multiple reports are returned in filename (chronological) order."""
        now = datetime.now(timezone.utc)

        suite_1 = _make_suite([_make_test_result("test_a", True, now)])
        suite_2 = _make_suite([_make_test_result("test_a", False, now)])
        _write_report(reports_dir, suite_1, index=1)
        _write_report(reports_dir, suite_2, index=2)

        loaded = aggregator.load_all_reports()
        assert len(loaded) == 2
        assert loaded[0].passed == 1  # first report
        assert loaded[1].failed == 1  # second report

    def test_empty_reports_dir(self, aggregator: ReportAggregator):
        """An empty or non-existent reports dir returns an empty list."""
        loaded = aggregator.load_all_reports()
        assert loaded == []

    def test_skips_malformed_reports(
        self, reports_dir: Path, aggregator: ReportAggregator
    ):
        """Malformed JSON files are skipped without crashing."""
        reports_dir.mkdir(parents=True, exist_ok=True)
        bad_file = reports_dir / "report_20260101_000001.json"
        bad_file.write_text("{ not valid json !!!", encoding="utf-8")

        now = datetime.now(timezone.utc)
        good_suite = _make_suite([_make_test_result("test_a", True, now)])
        _write_report(reports_dir, good_suite, index=2)

        loaded = aggregator.load_all_reports()
        assert len(loaded) == 1

    def test_ignores_non_report_files(
        self, reports_dir: Path, aggregator: ReportAggregator
    ):
        """Files that do not match 'report_*.json' are ignored."""
        reports_dir.mkdir(parents=True, exist_ok=True)
        other = reports_dir / "compliance_20260101.json"
        other.write_text("{}", encoding="utf-8")

        loaded = aggregator.load_all_reports()
        assert loaded == []


# ── ReportAggregator: trend computation ────────────────────────────────────


class TestTrendComputation:
    def test_trend_computation(
        self, reports_dir: Path, aggregator: ReportAggregator
    ):
        """Trend report correctly computes aggregate metrics."""
        now = datetime.now(timezone.utc)

        suite_1 = _make_suite([
            _make_test_result("test_a", True, now, cost=0.001),
            _make_test_result("test_b", True, now, cost=0.002),
        ])
        suite_2 = _make_suite([
            _make_test_result("test_a", True, now, cost=0.003),
            _make_test_result("test_b", False, now, cost=0.004),
        ])
        _write_report(reports_dir, suite_1, index=1)
        _write_report(reports_dir, suite_2, index=2)

        trend = aggregator.trend()

        assert trend.total_runs == 2
        assert len(trend.points) == 2
        # Suite 1: 100% pass, Suite 2: 50% pass -> avg 75%
        assert trend.avg_pass_rate == pytest.approx(75.0)
        assert trend.period == "all"

    def test_trend_with_last_n(
        self, reports_dir: Path, aggregator: ReportAggregator
    ):
        """last_n parameter limits the number of reports used."""
        now = datetime.now(timezone.utc)
        for i in range(5):
            suite = _make_suite([_make_test_result("test_a", True, now)])
            _write_report(reports_dir, suite, index=i)

        trend = aggregator.trend(last_n=2)
        assert trend.total_runs == 2
        assert len(trend.points) == 2

    def test_trend_empty_data(self, aggregator: ReportAggregator):
        """Trend with no reports returns zeroed-out TrendReport."""
        trend = aggregator.trend()

        assert trend.total_runs == 0
        assert trend.points == []
        assert trend.avg_pass_rate == 0.0
        assert trend.avg_cost == 0.0
        assert trend.flaky_tests == []
        assert trend.new_failures == []
        assert trend.fixed_tests == []

    def test_trend_points_have_correct_values(
        self, reports_dir: Path, aggregator: ReportAggregator
    ):
        """Each TrendPoint has the correct pass rate, cost, etc."""
        now = datetime.now(timezone.utc)
        suite = _make_suite([
            _make_test_result("test_a", True, now, cost=0.010),
            _make_test_result("test_b", True, now, cost=0.020),
            _make_test_result("test_c", False, now, cost=0.005),
        ])
        _write_report(reports_dir, suite, index=1)

        trend = aggregator.trend()
        assert len(trend.points) == 1
        pt = trend.points[0]
        assert pt.total_tests == 3
        assert pt.passed == 2
        assert pt.failed == 1
        assert pt.pass_rate == pytest.approx(2 / 3 * 100, rel=1e-2)
        assert pt.cost_usd == pytest.approx(0.035)

    def test_daily_summary(
        self, reports_dir: Path, aggregator: ReportAggregator
    ):
        """Daily summary only includes reports from the last 24 hours."""
        now = datetime.now(timezone.utc)
        old = now - timedelta(hours=48)

        suite_old = _make_suite([_make_test_result("test_a", True, old)])
        suite_new = _make_suite([_make_test_result("test_a", False, now)])
        _write_report(reports_dir, suite_old, index=1)
        _write_report(reports_dir, suite_new, index=2)

        trend = aggregator.daily_summary()
        assert trend.period == "daily"
        # Only the new report should be included (old one is 48h ago).
        assert trend.total_runs == 1

    def test_weekly_summary(
        self, reports_dir: Path, aggregator: ReportAggregator
    ):
        """Weekly summary only includes reports from the last 7 days."""
        now = datetime.now(timezone.utc)
        old = now - timedelta(days=14)

        suite_old = _make_suite([_make_test_result("test_a", True, old)])
        suite_new = _make_suite([_make_test_result("test_a", True, now)])
        _write_report(reports_dir, suite_old, index=1)
        _write_report(reports_dir, suite_new, index=2)

        trend = aggregator.weekly_summary()
        assert trend.period == "weekly"
        assert trend.total_runs == 1


# ── ReportAggregator: flaky test detection ─────────────────────────────────


class TestFlakyDetection:
    def test_flaky_test_detection(
        self, reports_dir: Path, aggregator: ReportAggregator
    ):
        """Tests that alternate between pass and fail are detected as flaky."""
        now = datetime.now(timezone.utc)

        # test_a passes 3 times, fails once -> flaky
        # test_b always passes -> not flaky
        for i, passed in enumerate([True, True, False, True]):
            suite = _make_suite([
                _make_test_result("test_a", passed, now),
                _make_test_result("test_b", True, now),
            ])
            _write_report(reports_dir, suite, index=i)

        flaky = aggregator.detect_flaky_tests(min_runs=3)
        assert len(flaky) == 1
        assert flaky[0].name == "test_a"
        assert flaky[0].total_runs == 4
        assert flaky[0].pass_count == 3
        assert flaky[0].fail_count == 1
        assert flaky[0].flake_rate > 0

    def test_flaky_min_runs_filter(
        self, reports_dir: Path, aggregator: ReportAggregator
    ):
        """Tests with fewer runs than min_runs are excluded."""
        now = datetime.now(timezone.utc)
        for i in range(2):
            suite = _make_suite([
                _make_test_result("test_a", i == 0, now),
            ])
            _write_report(reports_dir, suite, index=i)

        # min_runs=3, but test_a only has 2 runs.
        flaky = aggregator.detect_flaky_tests(min_runs=3)
        assert len(flaky) == 0

    def test_no_flaky_when_always_passes(
        self, reports_dir: Path, aggregator: ReportAggregator
    ):
        """Tests that always pass are not flaky."""
        now = datetime.now(timezone.utc)
        for i in range(5):
            suite = _make_suite([_make_test_result("test_a", True, now)])
            _write_report(reports_dir, suite, index=i)

        flaky = aggregator.detect_flaky_tests(min_runs=3)
        assert len(flaky) == 0

    def test_flake_rate_50_percent(
        self, reports_dir: Path, aggregator: ReportAggregator
    ):
        """A test passing half the time has 100% flake rate."""
        now = datetime.now(timezone.utc)
        for i, passed in enumerate([True, False, True, False]):
            suite = _make_suite([_make_test_result("test_a", passed, now)])
            _write_report(reports_dir, suite, index=i)

        flaky = aggregator.detect_flaky_tests(min_runs=3)
        assert len(flaky) == 1
        assert flaky[0].flake_rate == pytest.approx(100.0)


# ── ReportAggregator: new failure & fixed detection ────────────────────────


class TestNewFailureDetection:
    def test_new_failure_detection(
        self, reports_dir: Path, aggregator: ReportAggregator
    ):
        """A test that was passing but now fails is detected as a new failure."""
        now = datetime.now(timezone.utc)

        suite_1 = _make_suite([
            _make_test_result("test_a", True, now),
            _make_test_result("test_b", True, now),
        ])
        suite_2 = _make_suite([
            _make_test_result("test_a", False, now),  # started failing
            _make_test_result("test_b", True, now),
        ])
        _write_report(reports_dir, suite_1, index=1)
        _write_report(reports_dir, suite_2, index=2)

        new_failures = aggregator.detect_new_failures()
        assert "test_a" in new_failures
        assert "test_b" not in new_failures

    def test_no_new_failures_when_all_pass(
        self, reports_dir: Path, aggregator: ReportAggregator
    ):
        """No new failures when everything passes."""
        now = datetime.now(timezone.utc)
        for i in range(3):
            suite = _make_suite([_make_test_result("test_a", True, now)])
            _write_report(reports_dir, suite, index=i)

        new_failures = aggregator.detect_new_failures()
        assert new_failures == []

    def test_fixed_tests_detection(
        self, reports_dir: Path, aggregator: ReportAggregator
    ):
        """Tests that were failing but now pass appear as fixed."""
        now = datetime.now(timezone.utc)

        suite_1 = _make_suite([
            _make_test_result("test_a", False, now),  # was failing
        ])
        suite_2 = _make_suite([
            _make_test_result("test_a", True, now),  # now passing
        ])
        _write_report(reports_dir, suite_1, index=1)
        _write_report(reports_dir, suite_2, index=2)

        trend = aggregator.trend()
        assert "test_a" in trend.fixed_tests


# ── Sparkline ──────────────────────────────────────────────────────────────


class TestSparkline:
    def test_sparkline_generation(self):
        """Sparkline produces the correct number of characters."""
        values = [1, 3, 5, 7, 5, 3, 1]
        result = sparkline(values)
        assert len(result) == len(values)
        # The middle value (7) should be the tallest block.
        assert result[3] == "\u2588"  # full block for max
        # First and last (1) should be the lowest block.
        assert result[0] == "\u2581"
        assert result[6] == "\u2581"

    def test_sparkline_empty(self):
        """Empty input returns empty string."""
        assert sparkline([]) == ""

    def test_sparkline_constant_values(self):
        """All-same values produce uniform mid-height blocks."""
        result = sparkline([5, 5, 5, 5])
        assert len(result) == 4
        # All characters should be the same (mid-height).
        assert len(set(result)) == 1

    def test_sparkline_single_value(self):
        """Single value produces a single mid-height block."""
        result = sparkline([42])
        assert len(result) == 1

    def test_trend_indicator_increasing(self):
        """Increasing values produce an up arrow."""
        result = trend_indicator([10, 20, 30, 40, 50, 60])
        assert result == "\u2191"  # ↑

    def test_trend_indicator_decreasing(self):
        """Decreasing values produce a down arrow."""
        result = trend_indicator([60, 50, 40, 30, 20, 10])
        assert result == "\u2193"  # ↓

    def test_trend_indicator_flat(self):
        """Flat values produce a right arrow."""
        result = trend_indicator([50, 50, 50, 50, 50, 50])
        assert result == "\u2192"  # →

    def test_trend_indicator_empty(self):
        """Empty or single-element list returns flat indicator."""
        assert trend_indicator([]) == "\u2192"
        assert trend_indicator([42]) == "\u2192"


# ── HTML report generation ─────────────────────────────────────────────────


class TestHTMLReport:
    def _make_trend(self) -> TrendReport:
        """Build a small TrendReport for testing."""
        now = datetime.now(timezone.utc)
        points = [
            TrendPoint(
                timestamp=now - timedelta(days=2),
                pass_rate=90.0,
                total_tests=10,
                passed=9,
                failed=1,
                cost_usd=0.05,
                duration_ms=500.0,
            ),
            TrendPoint(
                timestamp=now - timedelta(days=1),
                pass_rate=80.0,
                total_tests=10,
                passed=8,
                failed=2,
                cost_usd=0.06,
                duration_ms=550.0,
            ),
            TrendPoint(
                timestamp=now,
                pass_rate=95.0,
                total_tests=10,
                passed=9,
                failed=1,
                cost_usd=0.04,
                duration_ms=480.0,
            ),
        ]
        return TrendReport(
            points=points,
            period="test",
            flaky_tests=[
                FlakyTest(
                    name="test_flaky",
                    total_runs=6,
                    pass_count=4,
                    fail_count=2,
                    flake_rate=66.7,
                )
            ],
            new_failures=["test_newly_broken"],
            fixed_tests=["test_just_fixed"],
            avg_pass_rate=88.3,
            avg_cost=0.05,
            total_runs=3,
        )

    def test_html_generation_produces_valid_html(self):
        """HTML report contains essential structural elements."""
        gen = HTMLReportGenerator()
        trend = self._make_trend()
        html = gen.generate(trend)

        assert "<!DOCTYPE html>" in html
        assert "<html" in html
        assert "Tailtest Quality Report" in html
        assert "</html>" in html

    def test_html_contains_summary_cards(self):
        """HTML report includes the summary cards section."""
        gen = HTMLReportGenerator()
        html = gen.generate(self._make_trend())

        assert "Total Runs" in html
        assert "Avg Pass Rate" in html
        assert "Avg Cost" in html

    def test_html_contains_svg_charts(self):
        """HTML report includes SVG chart elements."""
        gen = HTMLReportGenerator()
        html = gen.generate(self._make_trend())

        assert "<svg" in html
        assert "viewBox" in html
        assert "Pass Rate Over Time" in html
        assert "Cost Per Run" in html

    def test_html_contains_flaky_section(self):
        """HTML report includes flaky tests when present."""
        gen = HTMLReportGenerator()
        html = gen.generate(self._make_trend())

        assert "Flaky Tests" in html
        assert "test_flaky" in html

    def test_html_contains_new_failures(self):
        """HTML report includes new failures when present."""
        gen = HTMLReportGenerator()
        html = gen.generate(self._make_trend())

        assert "New Failures" in html
        assert "test_newly_broken" in html

    def test_html_contains_fixed_tests(self):
        """HTML report includes fixed tests when present."""
        gen = HTMLReportGenerator()
        html = gen.generate(self._make_trend())

        assert "Fixed Tests" in html
        assert "test_just_fixed" in html

    def test_html_write_creates_file(self, tmp_path: Path):
        """write() creates the HTML file on disk."""
        gen = HTMLReportGenerator()
        trend = self._make_trend()
        out = tmp_path / "report.html"
        result = gen.write(trend, out)

        assert result == out
        assert out.exists()
        content = out.read_text(encoding="utf-8")
        assert "<!DOCTYPE html>" in content

    def test_html_with_drift_alerts(self):
        """Drift alerts are rendered when provided."""
        gen = HTMLReportGenerator()
        trend = self._make_trend()
        alerts = [
            DriftAlert(
                metric_name="avg_latency_ms",
                baseline_value=100.0,
                current_value=300.0,
                threshold=2.0,
                severity="warning",
                message="Latency spike detected",
            ),
            DriftAlert(
                metric_name="pii_leak_rate",
                baseline_value=0.0,
                current_value=5.0,
                threshold=0.0,
                severity="critical",
                message="PII leak rate increased",
            ),
        ]
        html = gen.generate(trend, drift_alerts=alerts)

        assert "Drift Alerts" in html
        assert "Latency spike detected" in html
        assert "PII leak rate increased" in html
        assert "CRITICAL" in html
        assert "WARNING" in html

    def test_html_with_compliance_data(self):
        """Compliance section is rendered when data is provided."""
        gen = HTMLReportGenerator()
        trend = self._make_trend()
        compliance = {
            "frameworks": [
                {
                    "framework": "OWASP Top 10 for LLMs 2025",
                    "tested": 2,
                    "passed": 1,
                    "verdict": "PARTIAL",
                    "checks": [
                        {
                            "id": "LLM01",
                            "name": "Prompt Injection",
                            "severity": "critical",
                            "passed": True,
                        },
                        {
                            "id": "LLM02",
                            "name": "Insecure Output Handling",
                            "severity": "high",
                            "passed": False,
                        },
                    ],
                }
            ]
        }
        html = gen.generate(trend, compliance_data=compliance)

        assert "Compliance" in html
        assert "Prompt Injection" in html
        assert "LLM01" in html

    def test_html_empty_trend(self):
        """HTML report handles an empty trend gracefully."""
        gen = HTMLReportGenerator()
        trend = TrendReport(
            points=[],
            period="empty",
            flaky_tests=[],
            new_failures=[],
            fixed_tests=[],
            avg_pass_rate=0.0,
            avg_cost=0.0,
            total_runs=0,
        )
        html = gen.generate(trend)
        assert "<!DOCTYPE html>" in html
        assert "Total Runs" in html
