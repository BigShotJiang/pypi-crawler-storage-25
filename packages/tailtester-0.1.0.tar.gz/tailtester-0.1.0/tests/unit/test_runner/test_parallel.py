"""Tests for parallel test execution in the engine."""

import asyncio
import time

import pytest

from tailtest.models import TestSuiteResult
from tailtest.runner.engine import RunConfig, TestRunner


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #


def _write_test_file(path, content):
    """Write a Python test file and return its path."""
    path.write_text(content)
    return path


# --------------------------------------------------------------------------- #
# Parallel runs faster than sequential
# --------------------------------------------------------------------------- #


async def test_parallel_runs_faster_than_sequential(tmp_path):
    """Parallel execution should be significantly faster than sequential
    when tests contain async sleeps."""
    _write_test_file(
        tmp_path / "test_sleeps.py",
        '''\
import asyncio

async def test_sleep_a():
    await asyncio.sleep(0.2)

async def test_sleep_b():
    await asyncio.sleep(0.2)

async def test_sleep_c():
    await asyncio.sleep(0.2)

async def test_sleep_d():
    await asyncio.sleep(0.2)
''',
    )
    runner = TestRunner()

    # Sequential run
    seq_start = time.perf_counter()
    seq_result = await runner.run(tmp_path, config=RunConfig(parallel=1))
    seq_duration = time.perf_counter() - seq_start

    # Parallel run (4 concurrent)
    par_start = time.perf_counter()
    par_result = await runner.run(tmp_path, config=RunConfig(parallel=4))
    par_duration = time.perf_counter() - par_start

    # Both should pass all tests
    assert seq_result.total == 4
    assert seq_result.passed == 4
    assert par_result.total == 4
    assert par_result.passed == 4

    # Parallel should be at least 2x faster (4 sleeps of 0.2s:
    # sequential ~0.8s, parallel ~0.2s)
    assert par_duration < seq_duration * 0.7, (
        f"Parallel ({par_duration:.2f}s) was not significantly faster "
        f"than sequential ({seq_duration:.2f}s)"
    )


# --------------------------------------------------------------------------- #
# Semaphore limits concurrency
# --------------------------------------------------------------------------- #


async def test_parallel_respects_semaphore_limit(tmp_path):
    """With parallel=2, at most 2 tests run concurrently even if more exist."""
    # Use a file to track max concurrent count
    _write_test_file(
        tmp_path / "test_concurrent.py",
        '''\
import asyncio

_counter_lock = asyncio.Lock()
_current = 0
_max_seen = 0

async def _track(duration=0.15):
    global _current, _max_seen
    async with _counter_lock:
        _current += 1
        if _current > _max_seen:
            _max_seen = _current
    await asyncio.sleep(duration)
    async with _counter_lock:
        _current -= 1

async def test_a():
    await _track()

async def test_b():
    await _track()

async def test_c():
    await _track()

async def test_d():
    await _track()
''',
    )
    runner = TestRunner()
    config = RunConfig(parallel=2)
    result = await runner.run(tmp_path, config=config)

    assert result.total == 4
    assert result.passed == 4
    # The overall duration should reflect semaphore limiting:
    # 4 tests with sleep 0.15s, max 2 concurrent = ~0.3s minimum
    # If concurrency were unlimited it would be ~0.15s
    assert result.duration_ms >= 250, (
        f"Duration {result.duration_ms:.0f}ms suggests semaphore wasn't limiting "
        f"concurrency (expected >= 250ms for 4 tests at parallel=2)"
    )


# --------------------------------------------------------------------------- #
# Result ordering
# --------------------------------------------------------------------------- #


async def test_parallel_results_in_correct_order(tmp_path):
    """Results from parallel runs maintain the same order as the input tests."""
    _write_test_file(
        tmp_path / "test_order.py",
        '''\
import asyncio

async def test_aaa():
    """First test — sleeps longest."""
    await asyncio.sleep(0.15)

async def test_bbb():
    """Second test — medium sleep."""
    await asyncio.sleep(0.10)

async def test_ccc():
    """Third test — shortest sleep."""
    await asyncio.sleep(0.05)
''',
    )
    runner = TestRunner()
    result = await runner.run(tmp_path, config=RunConfig(parallel=3))

    assert result.total == 3
    names = [r.test_case.name for r in result.results]
    # gather() preserves the order of the input tasks regardless of
    # which one finishes first.
    assert names == ["test_aaa", "test_bbb", "test_ccc"]


# --------------------------------------------------------------------------- #
# Parallel=1 is sequential
# --------------------------------------------------------------------------- #


async def test_parallel_one_is_sequential(tmp_path):
    """parallel=1 falls through to the sequential code path."""
    _write_test_file(
        tmp_path / "test_seq.py",
        '''\
def test_x():
    pass

def test_y():
    pass
''',
    )
    runner = TestRunner()
    result = await runner.run(tmp_path, config=RunConfig(parallel=1))
    assert result.total == 2
    assert result.passed == 2
    # Verify order is maintained
    names = [r.test_case.name for r in result.results]
    assert names == ["test_x", "test_y"]


# --------------------------------------------------------------------------- #
# Parallel handles failures
# --------------------------------------------------------------------------- #


async def test_parallel_handles_failures(tmp_path):
    """Failures in parallel tests are correctly reported without crashing."""
    _write_test_file(
        tmp_path / "test_mixed.py",
        '''\
import asyncio

async def test_pass_1():
    await asyncio.sleep(0.05)

async def test_fail_1():
    await asyncio.sleep(0.05)
    raise AssertionError("deliberate failure")

async def test_pass_2():
    await asyncio.sleep(0.05)

async def test_fail_2():
    await asyncio.sleep(0.05)
    raise ValueError("unexpected error")
''',
    )
    runner = TestRunner()
    result = await runner.run(tmp_path, config=RunConfig(parallel=4))

    assert result.total == 4
    assert result.passed == 2
    assert result.failed == 2

    # Verify order is preserved
    names = [r.test_case.name for r in result.results]
    assert names == ["test_pass_1", "test_fail_1", "test_pass_2", "test_fail_2"]

    # Verify the right ones passed and failed
    assert result.results[0].passed is True
    assert result.results[1].passed is False
    assert result.results[2].passed is True
    assert result.results[3].passed is False


# --------------------------------------------------------------------------- #
# Cost limit in parallel
# --------------------------------------------------------------------------- #


async def test_parallel_cost_limit(tmp_path):
    """Cost limit is respected during parallel execution."""
    _write_test_file(
        tmp_path / "test_costs.py",
        '''\
def test_a():
    pass

def test_b():
    pass

def test_c():
    pass
''',
    )
    runner = TestRunner()
    # With cost_limit=0.0, the first test runs (0 cost) then limit triggers
    config = RunConfig(parallel=3, cost_limit=0.0)
    result = await runner.run(tmp_path, config=config)

    assert result.total >= 3
    # At least some tests should complete, at least some should be skipped
    # (the exact count depends on timing with parallel execution)
    statuses = [
        "passed" if r.passed and r.trace_id != "__skipped__"
        else "skipped" if r.trace_id == "__skipped__"
        else "failed"
        for r in result.results
    ]
    # At minimum the first test ran (cost 0) and then triggered the limit
    assert "passed" in statuses or "failed" in statuses
