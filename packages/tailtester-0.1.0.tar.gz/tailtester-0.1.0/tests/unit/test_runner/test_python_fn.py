"""Tests for PythonFunctionInterface."""

import pytest

from tailtest.models import AgentResponse
from tailtest.runner.interfaces.python_fn import PythonFunctionInterface


async def test_sync_function_interface():
    """A synchronous function should be wrapped and return an AgentResponse."""

    def my_agent(message: str) -> str:
        return f"Echo: {message}"

    interface = PythonFunctionInterface(fn=my_agent)
    response = await interface.chat("hello")
    assert isinstance(response, AgentResponse)
    assert response.content == "Echo: hello"
    assert response.latency_ms is not None
    assert response.latency_ms > 0


async def test_async_function_interface():
    """An async function should be awaited and return an AgentResponse."""

    async def my_async_agent(message: str) -> str:
        return f"Async echo: {message}"

    interface = PythonFunctionInterface(fn=my_async_agent)
    response = await interface.chat("world")
    assert isinstance(response, AgentResponse)
    assert response.content == "Async echo: world"
    assert response.latency_ms is not None


async def test_function_returning_string():
    """A function returning a plain string should be normalized to AgentResponse."""

    def string_agent(message: str) -> str:
        return "plain text response"

    interface = PythonFunctionInterface(fn=string_agent)
    response = await interface.chat("test")
    assert isinstance(response, AgentResponse)
    assert response.content == "plain text response"


async def test_function_returning_dict():
    """A function returning a dict with AgentResponse fields should be parsed."""

    def dict_agent(message: str) -> dict:
        return {"content": "from dict", "model": "test-model"}

    interface = PythonFunctionInterface(fn=dict_agent)
    response = await interface.chat("test")
    assert isinstance(response, AgentResponse)
    assert response.content == "from dict"
    assert response.model == "test-model"


async def test_function_returning_agent_response():
    """A function returning an AgentResponse directly should be used as-is."""

    def response_agent(message: str) -> AgentResponse:
        return AgentResponse(
            content="direct response",
            cost_usd=0.001,
            model="my-model",
        )

    interface = PythonFunctionInterface(fn=response_agent)
    response = await interface.chat("test")
    assert isinstance(response, AgentResponse)
    assert response.content == "direct response"
    assert response.cost_usd == 0.001
    assert response.model == "my-model"
    # latency_ms should be filled in since the original had None
    assert response.latency_ms is not None


async def test_interface_name_defaults_to_function_name():
    def my_cool_agent(message: str) -> str:
        return "hi"

    interface = PythonFunctionInterface(fn=my_cool_agent)
    assert interface.name == "my_cool_agent"


async def test_interface_custom_name():
    def agent(message: str) -> str:
        return "hi"

    interface = PythonFunctionInterface(fn=agent, name="custom-name")
    assert interface.name == "custom-name"


async def test_interface_repr():
    def agent(message: str) -> str:
        return "hi"

    interface = PythonFunctionInterface(fn=agent, name="test-agent")
    assert "test-agent" in repr(interface)


async def test_conversation_sends_last_user_message():
    """conversation() should extract and send only the last user message."""
    from tailtest.models import Message

    def echo_agent(message: str) -> str:
        return f"Got: {message}"

    interface = PythonFunctionInterface(fn=echo_agent)
    messages = [
        Message(role="user", content="first question"),
        Message(role="assistant", content="first answer"),
        Message(role="user", content="follow up"),
    ]
    response = await interface.conversation(messages)
    assert response.content == "Got: follow up"


async def test_conversation_no_user_message():
    """conversation() with no user messages should return empty content."""
    from tailtest.models import Message

    def agent(message: str) -> str:
        return "should not reach"

    interface = PythonFunctionInterface(fn=agent)
    messages = [
        Message(role="system", content="You are helpful."),
    ]
    response = await interface.conversation(messages)
    assert response.content == ""
