"""Tests for RegexAssertion."""

import pytest

from tailtest.assertions.deterministic.regex import RegexAssertion
from tailtest.models import AgentResponse


async def test_regex_matches():
    response = AgentResponse(content="Order #12345 confirmed.")
    assertion = RegexAssertion(pattern=r"#\d{5}")
    result = await assertion.evaluate(response)
    assert result.passed is True
    assert result.assertion_type == "regex_match"
    assert result.actual == "#12345"


async def test_regex_no_match():
    response = AgentResponse(content="No numbers here.")
    assertion = RegexAssertion(pattern=r"\d{5}")
    result = await assertion.evaluate(response)
    assert result.passed is False
    assert "no match found" in result.message.lower()


async def test_regex_partial_match():
    response = AgentResponse(content="Temperature is 72.5 degrees.")
    assertion = RegexAssertion(pattern=r"\d+\.\d+")
    result = await assertion.evaluate(response)
    assert result.passed is True
    assert result.actual == "72.5"


async def test_regex_complex_pattern():
    response = AgentResponse(content="Status: OK (200)")
    assertion = RegexAssertion(pattern=r"Status:\s+\w+\s+\(\d+\)")
    result = await assertion.evaluate(response)
    assert result.passed is True


async def test_regex_failure_message_includes_pattern():
    response = AgentResponse(content="no match")
    assertion = RegexAssertion(pattern=r"xyz\d+")
    result = await assertion.evaluate(response)
    assert result.passed is False
    assert "xyz\\d+" in result.message
