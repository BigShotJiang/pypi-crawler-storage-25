"""Tests for CostAssertion."""

import pytest

from tailtest.assertions.deterministic.cost import CostAssertion
from tailtest.models import AgentResponse


async def test_cost_under_passes(simple_response):
    assertion = CostAssertion(max_cost=0.01)
    result = await assertion.evaluate(simple_response)
    assert result.passed is True
    assert result.assertion_type == "cost_under"


async def test_cost_under_fails(simple_response):
    assertion = CostAssertion(max_cost=0.001)
    result = await assertion.evaluate(simple_response)
    assert result.passed is False
    assert "exceeds" in result.message


async def test_cost_under_with_none_cost(response_no_cost):
    assertion = CostAssertion(max_cost=0.01)
    result = await assertion.evaluate(response_no_cost)
    assert result.passed is False
    assert "unavailable" in result.message


async def test_cost_under_exact_boundary():
    response = AgentResponse(content="test", cost_usd=0.50)
    assertion = CostAssertion(max_cost=0.50)
    result = await assertion.evaluate(response)
    # Exact boundary: cost is NOT strictly under, so should fail
    assert result.passed is False


async def test_cost_result_shows_difference():
    response = AgentResponse(content="test", cost_usd=0.10)
    assertion = CostAssertion(max_cost=0.05)
    result = await assertion.evaluate(response)
    assert result.passed is False
    # The message should mention the overage
    assert "over by" in result.message


async def test_cost_under_zero():
    response = AgentResponse(content="test", cost_usd=0.0)
    assertion = CostAssertion(max_cost=0.01)
    result = await assertion.evaluate(response)
    assert result.passed is True


async def test_cost_pass_message_format():
    response = AgentResponse(content="test", cost_usd=0.003)
    assertion = CostAssertion(max_cost=0.01)
    result = await assertion.evaluate(response)
    assert result.passed is True
    assert "under" in result.message
