"""Tests for LatencyAssertion."""

import pytest

from tailtest.assertions.deterministic.latency import LatencyAssertion
from tailtest.models import AgentResponse


async def test_latency_under_passes(simple_response):
    assertion = LatencyAssertion(max_ms=500)
    result = await assertion.evaluate(simple_response)
    assert result.passed is True
    assert result.assertion_type == "latency_under"


async def test_latency_under_fails(simple_response):
    assertion = LatencyAssertion(max_ms=100)
    result = await assertion.evaluate(simple_response)
    assert result.passed is False
    assert "exceeds" in result.message


async def test_latency_under_with_none_latency(response_no_latency):
    assertion = LatencyAssertion(max_ms=500)
    result = await assertion.evaluate(response_no_latency)
    assert result.passed is False
    assert "unavailable" in result.message


async def test_latency_exact_boundary():
    response = AgentResponse(content="test", latency_ms=500.0)
    assertion = LatencyAssertion(max_ms=500)
    result = await assertion.evaluate(response)
    # Exact boundary: latency is NOT strictly under, so should fail
    assert result.passed is False


async def test_latency_result_shows_overage():
    response = AgentResponse(content="test", latency_ms=800.0)
    assertion = LatencyAssertion(max_ms=500)
    result = await assertion.evaluate(response)
    assert result.passed is False
    assert "over by" in result.message


async def test_latency_pass_message_format():
    response = AgentResponse(content="test", latency_ms=100.0)
    assertion = LatencyAssertion(max_ms=500)
    result = await assertion.evaluate(response)
    assert result.passed is True
    assert "under" in result.message
