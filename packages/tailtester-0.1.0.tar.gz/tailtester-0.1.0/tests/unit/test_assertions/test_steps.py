"""Tests for StepCountAssertion."""

import pytest

from tailtest.assertions.deterministic.steps import StepCountAssertion
from tailtest.models import AgentResponse, ToolCall


async def test_steps_under_passes(response_with_tools):
    assertion = StepCountAssertion(max_steps=5)
    result = await assertion.evaluate(response_with_tools)
    assert result.passed is True
    assert result.assertion_type == "steps_under"


async def test_steps_under_fails(response_multiple_tools):
    assertion = StepCountAssertion(max_steps=3)
    result = await assertion.evaluate(response_multiple_tools)
    assert result.passed is False
    assert "exceeding" in result.message


async def test_steps_exact_boundary():
    response = AgentResponse(
        content="done",
        tool_calls=[ToolCall(name=f"tool_{i}", arguments={}) for i in range(5)],
    )
    assertion = StepCountAssertion(max_steps=5)
    result = await assertion.evaluate(response)
    # Exact boundary: 5 steps is NOT strictly under 5
    assert result.passed is False


async def test_steps_zero_tools(simple_response):
    assertion = StepCountAssertion(max_steps=1)
    result = await assertion.evaluate(simple_response)
    assert result.passed is True
    assert result.actual == 0


async def test_steps_shows_overage():
    response = AgentResponse(
        content="done",
        tool_calls=[ToolCall(name=f"tool_{i}", arguments={}) for i in range(10)],
    )
    assertion = StepCountAssertion(max_steps=5)
    result = await assertion.evaluate(response)
    assert result.passed is False
    assert "over by 5" in result.message
