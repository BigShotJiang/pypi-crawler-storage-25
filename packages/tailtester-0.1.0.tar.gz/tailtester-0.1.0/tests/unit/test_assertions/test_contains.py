"""Tests for ContainsAssertion and NotContainsAssertion."""

import pytest

from tailtest.assertions.deterministic.contains import (
    ContainsAssertion,
    NotContainsAssertion,
)
from tailtest.models import AgentResponse


async def test_contains_passes_when_text_present(simple_response):
    assertion = ContainsAssertion(text="Hello")
    result = await assertion.evaluate(simple_response)
    assert result.passed is True
    assert result.assertion_type == "contains"


async def test_contains_fails_when_text_absent(simple_response):
    assertion = ContainsAssertion(text="Goodbye")
    result = await assertion.evaluate(simple_response)
    assert result.passed is False
    assert "Goodbye" in result.message


async def test_contains_case_insensitive(simple_response):
    assertion = ContainsAssertion(text="hello", case_insensitive=True)
    result = await assertion.evaluate(simple_response)
    assert result.passed is True


async def test_contains_case_sensitive_fails(simple_response):
    assertion = ContainsAssertion(text="hello", case_insensitive=False)
    result = await assertion.evaluate(simple_response)
    assert result.passed is False


async def test_not_contains_passes(simple_response):
    assertion = NotContainsAssertion(text="error")
    result = await assertion.evaluate(simple_response)
    assert result.passed is True
    assert result.assertion_type == "not_contains"


async def test_not_contains_fails(simple_response):
    assertion = NotContainsAssertion(text="Hello")
    result = await assertion.evaluate(simple_response)
    assert result.passed is False
    assert "Hello" in result.message


async def test_contains_with_empty_string():
    response = AgentResponse(content="Any content here")
    assertion = ContainsAssertion(text="")
    result = await assertion.evaluate(response)
    # Empty string is always contained in any string
    assert result.passed is True


async def test_contains_with_special_characters():
    response = AgentResponse(content="Price is $19.99 (USD)")
    assertion = ContainsAssertion(text="$19.99")
    result = await assertion.evaluate(response)
    assert result.passed is True


async def test_contains_result_has_correct_message(simple_response):
    assertion = ContainsAssertion(text="Hello")
    result = await assertion.evaluate(simple_response)
    assert result.message == "Response contains 'Hello'"


async def test_contains_failure_message_includes_snippet():
    response = AgentResponse(content="Short text")
    assertion = ContainsAssertion(text="missing")
    result = await assertion.evaluate(response)
    assert "missing" in result.message
    assert "Short text" in result.message


async def test_not_contains_case_insensitive():
    response = AgentResponse(content="Hello World")
    assertion = NotContainsAssertion(text="hello", case_insensitive=True)
    result = await assertion.evaluate(response)
    assert result.passed is False
    assert "case-insensitive" in result.message
