"""Tests for LLM judge assertions — mock the litellm.acompletion call."""

from __future__ import annotations

import json
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from tailtest.assertions.llm_judge.custom_rubric import CustomRubricAssertion
from tailtest.assertions.llm_judge.faithfulness import FaithfulnessAssertion
from tailtest.assertions.llm_judge.judge import JudgeResult, LLMJudge
from tailtest.assertions.llm_judge.relevance import RelevanceAssertion
from tailtest.assertions.llm_judge.safety import SafetyAssertion
from tailtest.assertions.llm_judge.tone import ToneAssertion
from tailtest.config.schema import JudgeConfig
from tailtest.models import AgentResponse


# ── Helpers ───────────────────────────────────────────────────────────────────


def _mock_completion(score: float, passed: bool, reason: str, cost: float = 0.001):
    """Build a mock litellm completion response object."""
    content = json.dumps({"score": score, "passed": passed, "reason": reason})
    message = SimpleNamespace(content=content)
    choice = SimpleNamespace(message=message)
    usage = SimpleNamespace(prompt_tokens=100, completion_tokens=50, total_tokens=150)
    return SimpleNamespace(choices=[choice], usage=usage)


def _make_response(content: str = "Test response", **kwargs) -> AgentResponse:
    return AgentResponse(content=content, **kwargs)


# ── LLMJudge core ────────────────────────────────────────────────────────────


class TestLLMJudge:
    async def test_judge_parses_valid_response(self):
        """Judge should parse a valid JSON response correctly."""
        judge = LLMJudge()
        mock_resp = _mock_completion(0.85, True, "Good answer")

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                result = await judge.evaluate(
                    prompt="What is 2+2?",
                    response_text="2+2 is 4",
                    rubric="Check math accuracy",
                )

        assert result.passed is True
        assert result.score == pytest.approx(0.85)
        assert "Good answer" in result.reason

    async def test_judge_handles_connection_error(self):
        """Judge should return a descriptive error on connection failure."""
        judge = LLMJudge()

        with patch("litellm.acompletion", new_callable=AsyncMock, side_effect=ConnectionError("Connection refused")):
            result = await judge.evaluate(
                prompt="test",
                response_text="test",
                rubric="test",
            )

        assert result.passed is False
        assert result.score == 0.0
        assert "connect" in result.reason.lower() or "connection" in result.reason.lower()

    async def test_judge_handles_timeout_error(self):
        """Judge should return a descriptive error on timeout."""
        judge = LLMJudge()

        with patch("litellm.acompletion", new_callable=AsyncMock, side_effect=TimeoutError("Request timeout")):
            result = await judge.evaluate(
                prompt="test",
                response_text="test",
                rubric="test",
            )

        assert result.passed is False
        assert result.score == 0.0
        assert "timeout" in result.reason.lower()


# ── Faithfulness ──────────────────────────────────────────────────────────────


class TestFaithfulnessAssertion:
    async def test_faithfulness_passes_grounded_response(self):
        """Faithfulness should pass when response is grounded in context."""
        mock_resp = _mock_completion(0.95, True, "Fully grounded")

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                assertion = FaithfulnessAssertion(context="Paris is the capital of France.")
                result = await assertion.evaluate(
                    _make_response("The capital of France is Paris.")
                )

        assert result.passed is True
        assert result.assertion_type == "faithfulness"

    async def test_faithfulness_fails_ungrounded(self):
        """Faithfulness should fail when response adds unsupported claims."""
        mock_resp = _mock_completion(0.2, False, "Introduces unsupported claims")

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                assertion = FaithfulnessAssertion(context="Sky is blue.")
                result = await assertion.evaluate(
                    _make_response("The sky is green and made of cheese.")
                )

        assert result.passed is False
        assert "faithfulness" in result.assertion_type


# ── Safety ────────────────────────────────────────────────────────────────────


class TestSafetyAssertion:
    async def test_safety_passes_clean_response(self):
        """Safety should pass for a clean, helpful response."""
        mock_resp = _mock_completion(1.0, True, "Completely safe")

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                assertion = SafetyAssertion()
                result = await assertion.evaluate(
                    _make_response("Here is how to bake a cake: mix flour, eggs, and sugar.")
                )

        assert result.passed is True
        assert result.assertion_type == "safety"

    async def test_safety_fails_harmful(self):
        """Safety should fail for harmful content."""
        mock_resp = _mock_completion(0.1, False, "Contains harmful instructions")

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                assertion = SafetyAssertion()
                result = await assertion.evaluate(
                    _make_response("Harmful content here")
                )

        assert result.passed is False


# ── Tone ──────────────────────────────────────────────────────────────────────


class TestToneAssertion:
    async def test_tone_passes_matching(self):
        """Tone should pass when response matches the expected tone."""
        mock_resp = _mock_completion(0.9, True, "Professional and empathetic tone")

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                assertion = ToneAssertion("professional", "empathetic")
                result = await assertion.evaluate(
                    _make_response("I understand your concern. Let me help you with that right away.")
                )

        assert result.passed is True
        assert result.assertion_type == "tone"

    def test_tone_requires_at_least_one_descriptor(self):
        """ToneAssertion should raise ValueError if no descriptors given."""
        with pytest.raises(ValueError, match="At least one tone descriptor"):
            ToneAssertion()


# ── Relevance ─────────────────────────────────────────────────────────────────


class TestRelevanceAssertion:
    async def test_relevance_passes(self):
        """Relevance should pass when response addresses the question."""
        mock_resp = _mock_completion(0.95, True, "Directly addresses the question")

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                assertion = RelevanceAssertion(question="What is the capital of France?")
                result = await assertion.evaluate(
                    _make_response("The capital of France is Paris.")
                )

        assert result.passed is True
        assert result.assertion_type == "relevance"


# ── Custom rubric ─────────────────────────────────────────────────────────────


class TestCustomRubricAssertion:
    async def test_custom_rubric_passes(self):
        """Custom rubric should pass when criteria are met."""
        mock_resp = _mock_completion(0.85, True, "Meets all rubric criteria")

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                assertion = CustomRubricAssertion(
                    rubric="Response should include a Python code example."
                )
                result = await assertion.evaluate(
                    _make_response("Here is an example: ```python\nprint('hello')\n```")
                )

        assert result.passed is True
        assert result.assertion_type == "custom_rubric"

    async def test_custom_rubric_fails(self):
        """Custom rubric should fail when criteria are not met."""
        mock_resp = _mock_completion(0.3, False, "Does not include code")

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                assertion = CustomRubricAssertion(
                    rubric="Response should include a Python code example."
                )
                result = await assertion.evaluate(
                    _make_response("I think Python is great.")
                )

        assert result.passed is False
