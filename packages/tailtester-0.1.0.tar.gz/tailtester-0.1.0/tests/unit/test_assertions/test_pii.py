"""Tests for PIIAssertion."""

import pytest

from tailtest.assertions.deterministic.pii import PIIAssertion
from tailtest.models import AgentResponse


async def test_no_pii_passes_clean_text(clean_response):
    assertion = PIIAssertion()
    result = await assertion.evaluate(clean_response)
    assert result.passed is True
    assert result.assertion_type == "no_pii"
    assert result.actual == "clean"


async def test_detects_email():
    response = AgentResponse(content="Contact us at support@company.com for help.")
    assertion = PIIAssertion()
    result = await assertion.evaluate(response)
    assert result.passed is False
    assert "email" in result.message.lower() or "Email" in result.message


async def test_detects_phone_number():
    response = AgentResponse(content="Call us at 555-123-4567 for support.")
    assertion = PIIAssertion()
    result = await assertion.evaluate(response)
    assert result.passed is False
    assert "phone" in result.message.lower()


async def test_detects_ssn():
    response = AgentResponse(content="Your SSN is 123-45-6789.")
    assertion = PIIAssertion()
    result = await assertion.evaluate(response)
    assert result.passed is False
    assert "Social Security" in result.message


async def test_detects_credit_card_visa():
    response = AgentResponse(content="Card: 4111-1111-1111-1111")
    assertion = PIIAssertion()
    result = await assertion.evaluate(response)
    assert result.passed is False
    assert "Credit card" in result.message


async def test_detects_credit_card_mastercard():
    response = AgentResponse(content="Card: 5500-0000-0000-0004")
    assertion = PIIAssertion()
    result = await assertion.evaluate(response)
    assert result.passed is False
    assert "Credit card" in result.message


async def test_detects_credit_card_amex():
    response = AgentResponse(content="Card: 3782-822463-10005")
    assertion = PIIAssertion()
    result = await assertion.evaluate(response)
    assert result.passed is False
    assert "Credit card" in result.message


async def test_no_false_positive_on_order_number():
    response = AgentResponse(content="Your order number is ORD-12345-67890.")
    assertion = PIIAssertion()
    result = await assertion.evaluate(response)
    assert result.passed is True


async def test_no_false_positive_on_date():
    response = AgentResponse(content="Your appointment is on 2024-01-15 at 3pm.")
    assertion = PIIAssertion()
    result = await assertion.evaluate(response)
    assert result.passed is True


async def test_multiple_pii_types(response_with_pii):
    assertion = PIIAssertion()
    result = await assertion.evaluate(response_with_pii)
    assert result.passed is False
    # Should detect both email and phone
    assert "Email" in result.message or "email" in result.message
    assert "phone" in result.message.lower()


async def test_no_pii_message_on_pass(clean_response):
    assertion = PIIAssertion()
    result = await assertion.evaluate(clean_response)
    assert "No PII" in result.message


async def test_pii_with_phone_country_code():
    response = AgentResponse(content="Call +1-555-123-4567 for support.")
    assertion = PIIAssertion()
    result = await assertion.evaluate(response)
    assert result.passed is False
