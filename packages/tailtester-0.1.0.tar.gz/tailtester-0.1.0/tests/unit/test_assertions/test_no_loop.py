"""Tests for NoLoopAssertion."""

import pytest

from tailtest.assertions.deterministic.no_loop import NoLoopAssertion
from tailtest.models import AgentResponse, ToolCall


async def test_no_loop_passes_unique_calls():
    response = AgentResponse(
        content="done",
        tool_calls=[
            ToolCall(name="search", arguments={}),
            ToolCall(name="format", arguments={}),
            ToolCall(name="send", arguments={}),
        ],
    )
    assertion = NoLoopAssertion()
    result = await assertion.evaluate(response)
    assert result.passed is True
    assert result.assertion_type == "no_loop"


async def test_no_loop_fails_repeated_calls(response_multiple_tools):
    # response_multiple_tools has "search" called 3 times consecutively
    assertion = NoLoopAssertion(max_repeats=3)
    result = await assertion.evaluate(response_multiple_tools)
    assert result.passed is False
    assert "search" in result.message
    assert "Loop detected" in result.message


async def test_no_loop_custom_threshold():
    response = AgentResponse(
        content="done",
        tool_calls=[
            ToolCall(name="retry", arguments={}) for _ in range(4)
        ],
    )
    # Threshold of 5 should pass with 4 consecutive calls
    assertion = NoLoopAssertion(max_repeats=5)
    result = await assertion.evaluate(response)
    assert result.passed is True

    # Threshold of 4 should fail with 4 consecutive calls
    assertion_strict = NoLoopAssertion(max_repeats=4)
    result_strict = await assertion_strict.evaluate(response)
    assert result_strict.passed is False


async def test_no_loop_passes_non_consecutive():
    response = AgentResponse(
        content="done",
        tool_calls=[
            ToolCall(name="search", arguments={}),
            ToolCall(name="format", arguments={}),
            ToolCall(name="search", arguments={}),
            ToolCall(name="format", arguments={}),
            ToolCall(name="search", arguments={}),
        ],
    )
    # "search" appears 3 times but never consecutively more than 1
    assertion = NoLoopAssertion(max_repeats=2)
    result = await assertion.evaluate(response)
    assert result.passed is True


async def test_no_loop_empty_calls(simple_response):
    assertion = NoLoopAssertion()
    result = await assertion.evaluate(simple_response)
    assert result.passed is True
    assert "no tool calls" in result.actual.lower() or "No tool calls" in result.message


async def test_no_loop_single_call():
    response = AgentResponse(
        content="done",
        tool_calls=[ToolCall(name="search", arguments={})],
    )
    assertion = NoLoopAssertion()
    result = await assertion.evaluate(response)
    assert result.passed is True
