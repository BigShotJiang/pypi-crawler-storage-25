"""Tests for TokensUnderAssertion."""

import pytest

from tailtest.assertions.deterministic.tokens import TokensUnderAssertion
from tailtest.models import AgentResponse, TokenUsage


async def test_tokens_under_passes(response_with_tools):
    assertion = TokensUnderAssertion(max_tokens=500)
    result = await assertion.evaluate(response_with_tools)
    assert result.passed is True
    assert result.assertion_type == "tokens_under"


async def test_tokens_under_fails(response_with_tools):
    assertion = TokensUnderAssertion(max_tokens=100)
    result = await assertion.evaluate(response_with_tools)
    assert result.passed is False
    assert "exceeding" in result.message


async def test_tokens_under_with_none_tokens(response_no_tokens):
    assertion = TokensUnderAssertion(max_tokens=500)
    result = await assertion.evaluate(response_no_tokens)
    assert result.passed is False
    assert "unavailable" in result.message


async def test_tokens_exact_boundary():
    response = AgentResponse(
        content="test",
        tokens_used=TokenUsage(prompt_tokens=50, completion_tokens=50, total_tokens=100),
    )
    assertion = TokensUnderAssertion(max_tokens=100)
    result = await assertion.evaluate(response)
    # Exact boundary: 100 tokens is NOT strictly under 100
    assert result.passed is False


async def test_tokens_result_shows_overage():
    response = AgentResponse(
        content="test",
        tokens_used=TokenUsage(prompt_tokens=100, completion_tokens=100, total_tokens=200),
    )
    assertion = TokensUnderAssertion(max_tokens=150)
    result = await assertion.evaluate(response)
    assert result.passed is False
    assert "over by 50" in result.message
