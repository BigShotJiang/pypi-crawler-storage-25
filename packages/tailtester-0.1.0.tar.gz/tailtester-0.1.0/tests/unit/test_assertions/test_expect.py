"""Tests for the expect() fluent assertion API."""

import pytest

from tailtest.assertions.expect import Expectation, expect
from tailtest.models import AgentResponse, ToolCall, TokenUsage


def test_expect_chaining_passes(simple_response):
    """Chained assertions should all pass without raising."""
    result = expect(simple_response).to_contain("Hello").to_contain("help")
    assert len(result.results) == 2
    assert all(r.passed for r in result.results)


def test_expect_chaining_fails_on_first_failure(simple_response):
    """Chaining should raise AssertionError on the first failure."""
    with pytest.raises(AssertionError, match="Goodbye"):
        expect(simple_response).to_contain("Goodbye").to_contain("Hello")


def test_expect_cost_under(simple_response):
    result = expect(simple_response).cost_under(0.01)
    assert len(result.results) == 1
    assert result.results[0].passed is True


def test_expect_cost_under_fails():
    response = AgentResponse(content="test", cost_usd=0.50)
    with pytest.raises(AssertionError, match="exceeds"):
        expect(response).cost_under(0.10)


def test_expect_to_call_tool(response_with_tools):
    result = expect(response_with_tools).to_call_tool("lookup_order")
    assert len(result.results) == 1
    assert result.results[0].passed is True


def test_expect_no_pii(clean_response):
    result = expect(clean_response).no_pii()
    assert len(result.results) == 1
    assert result.results[0].passed is True


def test_expect_no_pii_fails(response_with_pii):
    with pytest.raises(AssertionError, match="PII detected"):
        expect(response_with_pii).no_pii()


def test_expect_combined_assertions(response_with_tools):
    """Multiple different assertion types in one chain."""
    result = (
        expect(response_with_tools)
        .to_contain("order")
        .cost_under(0.01)
        .to_call_tool("lookup_order")
        .no_pii()
    )
    assert len(result.results) == 4
    assert all(r.passed for r in result.results)


def test_expect_latency_under(simple_response):
    result = expect(simple_response).latency_under(500)
    assert result.results[0].passed is True


def test_expect_not_to_contain(simple_response):
    result = expect(simple_response).not_to_contain("error")
    assert result.results[0].passed is True


def test_expect_returns_expectation_instance(simple_response):
    result = expect(simple_response)
    assert isinstance(result, Expectation)
