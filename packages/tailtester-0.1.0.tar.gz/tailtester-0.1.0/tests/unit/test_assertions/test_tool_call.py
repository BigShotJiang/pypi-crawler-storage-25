"""Tests for ToolCallAssertion and ToolNotCalledAssertion."""

import pytest

from tailtest.assertions.deterministic.tool_call import (
    ToolCallAssertion,
    ToolNotCalledAssertion,
)
from tailtest.models import AgentResponse, ToolCall


async def test_tool_called_passes(response_with_tools):
    assertion = ToolCallAssertion(tool_name="lookup_order")
    result = await assertion.evaluate(response_with_tools)
    assert result.passed is True
    assert result.assertion_type == "tool_called"


async def test_tool_called_fails_when_not_called(response_with_tools):
    assertion = ToolCallAssertion(tool_name="delete_user")
    result = await assertion.evaluate(response_with_tools)
    assert result.passed is False
    assert "delete_user" in result.message


async def test_tool_called_with_args(response_with_tools):
    assertion = ToolCallAssertion(
        tool_name="lookup_order",
        expected_args={"order_id": "12345"},
    )
    result = await assertion.evaluate(response_with_tools)
    assert result.passed is True
    assert result.assertion_type == "tool_called_with"


async def test_tool_called_with_wrong_args(response_with_tools):
    assertion = ToolCallAssertion(
        tool_name="lookup_order",
        expected_args={"order_id": "99999"},
    )
    result = await assertion.evaluate(response_with_tools)
    assert result.passed is False
    assert "not with expected arguments" in result.message


async def test_tool_called_with_subset_args():
    """Should pass when expected args are a subset of actual args."""
    response = AgentResponse(
        content="done",
        tool_calls=[
            ToolCall(
                name="search",
                arguments={"q": "test", "limit": 10, "sort": "date"},
            ),
        ],
    )
    assertion = ToolCallAssertion(
        tool_name="search",
        expected_args={"q": "test"},
    )
    result = await assertion.evaluate(response)
    assert result.passed is True


async def test_tool_not_called_passes(response_with_tools):
    assertion = ToolNotCalledAssertion(tool_name="delete_user")
    result = await assertion.evaluate(response_with_tools)
    assert result.passed is True
    assert result.assertion_type == "tool_not_called"


async def test_tool_not_called_fails(response_with_tools):
    assertion = ToolNotCalledAssertion(tool_name="lookup_order")
    result = await assertion.evaluate(response_with_tools)
    assert result.passed is False
    assert "NOT to be called" in result.message


async def test_tool_called_no_tools_in_response(simple_response):
    assertion = ToolCallAssertion(tool_name="any_tool")
    result = await assertion.evaluate(simple_response)
    assert result.passed is False
    assert "(none)" in result.message or "[]" in result.message


async def test_tool_not_called_with_no_tools(simple_response):
    assertion = ToolNotCalledAssertion(tool_name="any_tool")
    result = await assertion.evaluate(simple_response)
    assert result.passed is True


async def test_tool_called_multiple_matches():
    """When the tool is called multiple times, should still pass."""
    response = AgentResponse(
        content="done",
        tool_calls=[
            ToolCall(name="search", arguments={"q": "first"}),
            ToolCall(name="search", arguments={"q": "second"}),
        ],
    )
    assertion = ToolCallAssertion(tool_name="search")
    result = await assertion.evaluate(response)
    assert result.passed is True


async def test_tool_called_with_args_matches_any_call():
    """When multiple calls exist, should pass if ANY call matches the expected args."""
    response = AgentResponse(
        content="done",
        tool_calls=[
            ToolCall(name="search", arguments={"q": "wrong"}),
            ToolCall(name="search", arguments={"q": "correct"}),
        ],
    )
    assertion = ToolCallAssertion(
        tool_name="search",
        expected_args={"q": "correct"},
    )
    result = await assertion.evaluate(response)
    assert result.passed is True
