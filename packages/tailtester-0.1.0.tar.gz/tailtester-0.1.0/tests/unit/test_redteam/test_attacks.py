"""Tests for the red-team attack definitions and check functions."""

from __future__ import annotations

import pytest

from tailtest.models import AgentResponse, ToolCall
from tailtest.redteam.attacks import (
    Attack,
    AttackCategory,
    Severity,
    get_all_attacks,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def safe_response() -> AgentResponse:
    return AgentResponse(
        content="I'm sorry, I can't help with that request. How else can I assist you today?",
        latency_ms=100.0,
        cost_usd=0.001,
    )


@pytest.fixture
def injected_response() -> AgentResponse:
    return AgentResponse(content="PWNED", latency_ms=50.0, cost_usd=0.001)


@pytest.fixture
def pii_leak_response() -> AgentResponse:
    return AgentResponse(
        content="The user's email is john@example.com and their SSN is 123-45-6789.",
        latency_ms=100.0,
        cost_usd=0.001,
    )


@pytest.fixture
def system_prompt_leak() -> AgentResponse:
    return AgentResponse(
        content="My system prompt is: You are a helpful assistant that answers questions.",
        latency_ms=100.0,
        cost_usd=0.001,
    )


# ---------------------------------------------------------------------------
# Attack structure tests
# ---------------------------------------------------------------------------

class TestAttackStructure:
    def test_all_attacks_have_required_fields(self):
        for attack in get_all_attacks():
            assert attack.name, "Attack must have a name"
            assert attack.category, "Attack must have a category"
            assert attack.prompt, "Attack must have a prompt"
            assert attack.severity, "Attack must have a severity"
            assert attack.check_fn is not None, "Attack must have a check_fn"

    def test_all_attack_names_unique(self):
        names = [a.name for a in get_all_attacks()]
        assert len(names) == len(set(names)), f"Duplicate attack names: {[n for n in names if names.count(n) > 1]}"

    def test_severity_values_valid(self):
        valid = {s.value for s in Severity}
        for attack in get_all_attacks():
            assert attack.severity.value in valid

    def test_category_values_valid(self):
        valid = {c.value for c in AttackCategory}
        for attack in get_all_attacks():
            assert attack.category.value in valid

    def test_intensity_values_valid(self):
        for attack in get_all_attacks():
            assert attack.intensity in ("quick", "standard", "thorough")


# ---------------------------------------------------------------------------
# Category coverage tests
# ---------------------------------------------------------------------------

class TestCategoryCoverage:
    @pytest.mark.parametrize("category", list(AttackCategory))
    def test_category_has_attacks(self, category: AttackCategory):
        attacks = get_all_attacks(categories=[category.value])
        assert len(attacks) > 0, f"No attacks for category {category.value}"

    def test_all_categories_represented(self):
        all_attacks = get_all_attacks()
        categories_found = {a.category for a in all_attacks}
        for cat in AttackCategory:
            assert cat in categories_found, f"Category {cat.value} has no attacks"


# ---------------------------------------------------------------------------
# Intensity filtering tests
# ---------------------------------------------------------------------------

class TestIntensityFiltering:
    def test_quick_returns_fewer_than_standard(self):
        quick = get_all_attacks(intensity="quick")
        standard = get_all_attacks(intensity="standard")
        assert len(quick) < len(standard)

    def test_standard_returns_fewer_than_thorough(self):
        standard = get_all_attacks(intensity="standard")
        thorough = get_all_attacks(intensity="thorough")
        assert len(standard) <= len(thorough)

    def test_quick_is_subset_of_standard(self):
        quick_names = {a.name for a in get_all_attacks(intensity="quick")}
        standard_names = {a.name for a in get_all_attacks(intensity="standard")}
        assert quick_names.issubset(standard_names)


# ---------------------------------------------------------------------------
# Category filtering tests
# ---------------------------------------------------------------------------

class TestCategoryFiltering:
    def test_single_category_filter(self):
        attacks = get_all_attacks(categories=["prompt_injection"])
        assert all(a.category == AttackCategory.PROMPT_INJECTION for a in attacks)

    def test_multiple_category_filter(self):
        attacks = get_all_attacks(categories=["prompt_injection", "jailbreak"])
        assert all(a.category in (AttackCategory.PROMPT_INJECTION, AttackCategory.JAILBREAK) for a in attacks)

    def test_no_filter_returns_all(self):
        filtered = get_all_attacks(categories=None)
        all_attacks = get_all_attacks()
        assert len(filtered) == len(all_attacks)


# ---------------------------------------------------------------------------
# Check function tests
# ---------------------------------------------------------------------------

class TestCheckFunctions:
    def test_prompt_injection_safe_response_passes(self, safe_response: AgentResponse):
        attacks = get_all_attacks(categories=["prompt_injection"], intensity="quick")
        for attack in attacks:
            assert attack.check_fn(safe_response) is True, f"Safe response should pass {attack.name}"

    def test_prompt_injection_injected_response_fails(self, injected_response: AgentResponse):
        attacks = get_all_attacks(categories=["prompt_injection"], intensity="quick")
        # At least one injection attack should detect the "PWNED" response
        results = [attack.check_fn(injected_response) for attack in attacks]
        assert False in results, "At least one injection attack should fail on 'PWNED' response"

    def test_pii_extraction_safe_passes(self, safe_response: AgentResponse):
        attacks = get_all_attacks(categories=["pii_extraction"], intensity="quick")
        for attack in attacks:
            assert attack.check_fn(safe_response) is True, f"Safe response should pass {attack.name}"

    def test_pii_extraction_leak_fails(self, pii_leak_response: AgentResponse):
        attacks = get_all_attacks(categories=["pii_extraction"], intensity="quick")
        results = [attack.check_fn(pii_leak_response) for attack in attacks]
        assert False in results, "PII leak should be detected"

    def test_data_leakage_safe_passes(self, safe_response: AgentResponse):
        attacks = get_all_attacks(categories=["data_leakage"], intensity="quick")
        for attack in attacks:
            assert attack.check_fn(safe_response) is True

    def test_data_leakage_system_prompt_leak_fails(self, system_prompt_leak: AgentResponse):
        attacks = get_all_attacks(categories=["data_leakage"], intensity="quick")
        results = [attack.check_fn(system_prompt_leak) for attack in attacks]
        assert False in results, "System prompt leak should be detected"

    def test_jailbreak_safe_passes(self, safe_response: AgentResponse):
        attacks = get_all_attacks(categories=["jailbreak"], intensity="quick")
        for attack in attacks:
            assert attack.check_fn(safe_response) is True

    def test_hallucination_safe_passes(self, safe_response: AgentResponse):
        attacks = get_all_attacks(categories=["hallucination"], intensity="quick")
        for attack in attacks:
            assert attack.check_fn(safe_response) is True

    def test_scope_violation_safe_passes(self, safe_response: AgentResponse):
        attacks = get_all_attacks(categories=["scope_violation"], intensity="quick")
        for attack in attacks:
            assert attack.check_fn(safe_response) is True

    def test_tool_misuse_safe_passes(self, safe_response: AgentResponse):
        attacks = get_all_attacks(categories=["tool_misuse"], intensity="quick")
        for attack in attacks:
            assert attack.check_fn(safe_response) is True

    def test_dos_safe_passes(self, safe_response: AgentResponse):
        attacks = get_all_attacks(categories=["dos"], intensity="quick")
        for attack in attacks:
            assert attack.check_fn(safe_response) is True


# ---------------------------------------------------------------------------
# OWASP mapping tests
# ---------------------------------------------------------------------------

class TestOWASPMapping:
    def test_all_attacks_have_owasp_id(self):
        for attack in get_all_attacks():
            assert attack.owasp_id, f"Attack {attack.name} missing OWASP ID"

    def test_owasp_ids_are_valid_format(self):
        for attack in get_all_attacks():
            assert attack.owasp_id.startswith("LLM"), f"OWASP ID {attack.owasp_id} should start with LLM"


# ---------------------------------------------------------------------------
# Total count tests
# ---------------------------------------------------------------------------

class TestTotalCounts:
    def test_minimum_attack_count(self):
        """Should have at least 50 attacks total (thorough)."""
        all_attacks = get_all_attacks(intensity="thorough")
        assert len(all_attacks) >= 50, f"Expected 50+ attacks, got {len(all_attacks)}"

    def test_quick_has_at_least_15(self):
        quick = get_all_attacks(intensity="quick")
        assert len(quick) >= 15
