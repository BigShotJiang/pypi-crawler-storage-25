"""Tests for OpenAIDetector — detect and extract OpenAI SDK patterns from ASTs."""

import ast
from pathlib import Path

import pytest

from tailtest.context.detectors.openai_detector import OpenAIDetector
from tailtest.models import PromptDefinition, ToolDefinition


@pytest.fixture
def detector():
    return OpenAIDetector()


@pytest.fixture
def dummy_path(tmp_path):
    return tmp_path / "agent.py"


# --------------------------------------------------------------------------- #
# Detection
# --------------------------------------------------------------------------- #


def test_detects_import_openai(detector, dummy_path):
    """detect() returns True when the file imports openai."""
    source = "import openai\n"
    tree = ast.parse(source)
    assert detector.detect(dummy_path, tree) is True


def test_detects_from_openai_import(detector, dummy_path):
    """detect() returns True for `from openai import OpenAI`."""
    source = "from openai import OpenAI\n"
    tree = ast.parse(source)
    assert detector.detect(dummy_path, tree) is True


def test_returns_false_for_no_openai_import(detector, dummy_path):
    """detect() returns False when openai is not imported."""
    source = "import json\nimport os\n"
    tree = ast.parse(source)
    assert detector.detect(dummy_path, tree) is False


def test_returns_false_for_empty_file(detector, dummy_path):
    """detect() returns False for an empty source file."""
    source = ""
    tree = ast.parse(source)
    assert detector.detect(dummy_path, tree) is False


# --------------------------------------------------------------------------- #
# Prompt extraction
# --------------------------------------------------------------------------- #


def test_extracts_system_prompt_from_messages(detector, dummy_path):
    """extract_prompts() finds system role prompts in messages=[...] kwargs."""
    source = '''\
import openai
client = openai.OpenAI()
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Hello"},
    ],
)
'''
    tree = ast.parse(source)
    prompts = detector.extract_prompts(dummy_path, tree)
    assert len(prompts) == 1
    assert prompts[0].content == "You are a helpful assistant."
    assert prompts[0].role == "system"


def test_no_prompts_when_no_system_message(detector, dummy_path):
    """extract_prompts() returns empty when messages has no system role."""
    source = '''\
import openai
client = openai.OpenAI()
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[
        {"role": "user", "content": "Hello"},
    ],
)
'''
    tree = ast.parse(source)
    prompts = detector.extract_prompts(dummy_path, tree)
    assert len(prompts) == 0


# --------------------------------------------------------------------------- #
# Model extraction
# --------------------------------------------------------------------------- #


def test_extracts_model_name(detector, dummy_path):
    """extract_models() pulls out the model= string from create() calls."""
    source = '''\
import openai
client = openai.OpenAI()
response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "hi"}],
)
'''
    tree = ast.parse(source)
    models = detector.extract_models(dummy_path, tree)
    assert "gpt-4o-mini" in models


# --------------------------------------------------------------------------- #
# Tool extraction
# --------------------------------------------------------------------------- #


def test_extracts_tool_definitions(detector, dummy_path):
    """extract_tools() parses tools=[...] kwarg from create() calls."""
    source = '''\
import openai
client = openai.OpenAI()
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "weather?"}],
    tools=[
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get the current weather",
                "parameters": {"type": "object"},
            },
        }
    ],
)
'''
    tree = ast.parse(source)
    tools = detector.extract_tools(dummy_path, tree)
    assert len(tools) == 1
    assert tools[0].name == "get_weather"
    assert tools[0].description == "Get the current weather"


def test_extracts_legacy_functions_kwarg(detector, dummy_path):
    """extract_tools() also finds tools in the legacy `functions=` kwarg."""
    source = '''\
import openai
openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=[{"role": "user", "content": "hi"}],
    functions=[
        {"name": "search", "description": "Search the web"},
    ],
)
'''
    tree = ast.parse(source)
    tools = detector.extract_tools(dummy_path, tree)
    assert len(tools) == 1
    assert tools[0].name == "search"


# --------------------------------------------------------------------------- #
# Agent extraction
# --------------------------------------------------------------------------- #


def test_extracts_agent_definition(detector, dummy_path):
    """extract_agents() assembles a full AgentDefinition from a create() call."""
    source = '''\
import openai
client = openai.OpenAI()
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[
        {"role": "system", "content": "You are a coding assistant."},
        {"role": "user", "content": "help me code"},
    ],
)
'''
    tree = ast.parse(source)
    agents = detector.extract_agents(dummy_path, tree)
    assert len(agents) == 1
    assert agents[0].framework == "openai"
    assert agents[0].model == "gpt-4o"
    assert len(agents[0].prompts) == 1
    assert agents[0].prompts[0].content == "You are a coding assistant."


# --------------------------------------------------------------------------- #
# Framework name
# --------------------------------------------------------------------------- #


def test_framework_name_is_openai(detector):
    """The detector's framework_name attribute is 'openai'."""
    assert detector.framework_name == "openai"
