"""Tests for the context store — save/load scan results."""

import json

import pytest

from tailtest.context.store import save_scan, load_scan, load_meta, context_dir
from tailtest.models import ScanResult


@pytest.fixture
def sample_scan():
    """A minimal ScanResult for testing persistence."""
    return ScanResult(
        framework="openai",
        framework_version=None,
        tools=[],
        prompts=[],
        agents=[],
        models=["gpt-4o"],
        env_vars=["OPENAI_API_KEY"],
        dependencies=["openai"],
        config_files=[],
    )


# --------------------------------------------------------------------------- #
# Round-trip
# --------------------------------------------------------------------------- #


def test_save_and_load_roundtrip(tmp_path, sample_scan):
    """save_scan then load_scan should return an equivalent ScanResult."""
    save_scan(sample_scan, tmp_path)
    loaded = load_scan(tmp_path)
    assert loaded is not None
    assert loaded.framework == sample_scan.framework
    assert loaded.models == sample_scan.models
    assert loaded.env_vars == sample_scan.env_vars
    assert loaded.dependencies == sample_scan.dependencies


def test_save_creates_directory(tmp_path, sample_scan):
    """save_scan creates the .tailtest/context/ directory if missing."""
    project = tmp_path / "myproject"
    project.mkdir()
    save_scan(sample_scan, project)
    assert (project / ".tailtest" / "context" / "scan.json").is_file()


def test_save_writes_meta_sidecar(tmp_path, sample_scan):
    """save_scan writes a meta.json sidecar next to scan.json."""
    save_scan(sample_scan, tmp_path)
    meta = load_meta(tmp_path)
    assert meta is not None
    assert meta["framework"] == "openai"
    assert "scanned_at" in meta


# --------------------------------------------------------------------------- #
# Missing / corrupted data
# --------------------------------------------------------------------------- #


def test_load_returns_none_for_missing_directory(tmp_path):
    """load_scan returns None when no .tailtest/context/ directory exists."""
    result = load_scan(tmp_path)
    assert result is None


def test_load_returns_none_for_corrupted_json(tmp_path):
    """load_scan returns None when scan.json contains invalid JSON."""
    ctx = context_dir(tmp_path)
    ctx.mkdir(parents=True)
    (ctx / "scan.json").write_text("this is not valid json {{{")
    result = load_scan(tmp_path)
    assert result is None


def test_load_returns_none_for_invalid_schema(tmp_path):
    """load_scan returns None when scan.json is valid JSON but wrong schema."""
    ctx = context_dir(tmp_path)
    ctx.mkdir(parents=True)
    (ctx / "scan.json").write_text(json.dumps({"not": "a scan result"}))
    result = load_scan(tmp_path)
    assert result is None
