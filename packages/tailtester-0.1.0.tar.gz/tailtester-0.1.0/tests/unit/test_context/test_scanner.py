"""Tests for the AST-based project scanner."""

import pytest

from tailtest.context.sources.scanner import scan_project
from tailtest.models import ScanResult


# --------------------------------------------------------------------------- #
# Basic scanning
# --------------------------------------------------------------------------- #


async def test_scans_directory(tmp_path):
    """scan_project() returns a ScanResult when pointed at a directory."""
    (tmp_path / "app.py").write_text("import os\nprint('hello')\n")
    result = await scan_project(tmp_path)
    assert isinstance(result, ScanResult)


async def test_finds_openai_file(tmp_path):
    """scan_project() detects openai framework when a file imports it."""
    source = '''\
import openai
client = openai.OpenAI()
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[
        {"role": "system", "content": "You are helpful."},
        {"role": "user", "content": "Hello"},
    ],
)
'''
    (tmp_path / "agent.py").write_text(source)
    result = await scan_project(tmp_path)
    assert result.framework == "openai"
    assert "gpt-4o" in result.models
    assert len(result.prompts) >= 1


async def test_skips_venv_directory(tmp_path):
    """scan_project() skips .venv directories."""
    venv = tmp_path / ".venv" / "lib"
    venv.mkdir(parents=True)
    (venv / "openai_wrapper.py").write_text("import openai\n")

    # Real source with no LLM
    (tmp_path / "main.py").write_text("print('hello')\n")

    result = await scan_project(tmp_path)
    assert result.framework == "unknown"


async def test_handles_empty_directory(tmp_path):
    """scan_project() returns a valid ScanResult for an empty directory."""
    result = await scan_project(tmp_path)
    assert isinstance(result, ScanResult)
    assert result.framework == "unknown"
    assert result.tools == []
    assert result.prompts == []
    assert result.models == []


async def test_deep_mode_parameter_accepted(tmp_path):
    """scan_project() accepts the deep=True parameter without error."""
    (tmp_path / "app.py").write_text("print('hi')\n")
    # deep=True on a non-git dir should still work (just returns no git prompts)
    result = await scan_project(tmp_path, deep=True)
    assert isinstance(result, ScanResult)


async def test_detects_dependencies_from_requirements(tmp_path):
    """scan_project() reads requirements.txt for dependency info."""
    (tmp_path / "requirements.txt").write_text("openai>=1.0\nhttpx\n")
    (tmp_path / "main.py").write_text("print('hi')\n")
    result = await scan_project(tmp_path)
    assert "openai" in result.dependencies
    assert "httpx" in result.dependencies


async def test_detects_env_vars_in_source(tmp_path):
    """scan_project() finds AI-related env var references."""
    source = '''\
import os
key = os.environ["OPENAI_API_KEY"]
'''
    (tmp_path / "config.py").write_text(source)
    result = await scan_project(tmp_path)
    assert "OPENAI_API_KEY" in result.env_vars


async def test_multiple_frameworks_combined(tmp_path):
    """scan_project() combines framework names when multiple are detected."""
    (tmp_path / "openai_agent.py").write_text('''\
import openai
client = openai.OpenAI()
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "hi"}],
)
''')
    (tmp_path / "anthropic_agent.py").write_text('''\
import anthropic
client = anthropic.Anthropic()
response = client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=1024,
    messages=[{"role": "user", "content": "hi"}],
)
''')
    result = await scan_project(tmp_path)
    assert "openai" in result.framework
    assert "anthropic" in result.framework
