"""Shared fixtures for the tailtest test suite."""

import pytest

from tailtest.models import AgentResponse, ToolCall, TokenUsage


@pytest.fixture
def simple_response():
    """A basic agent response with no tool calls or token data."""
    return AgentResponse(
        content="Hello! How can I help you today?",
        latency_ms=150.0,
        cost_usd=0.003,
        model="test-model",
    )


@pytest.fixture
def response_with_tools():
    """An agent response that includes a tool call and token usage."""
    return AgentResponse(
        content="I found your order. It's being shipped.",
        tool_calls=[
            ToolCall(
                name="lookup_order",
                arguments={"order_id": "12345"},
                result={"status": "shipped"},
            ),
        ],
        latency_ms=250.0,
        cost_usd=0.005,
        tokens_used=TokenUsage(
            prompt_tokens=100, completion_tokens=50, total_tokens=150
        ),
        model="test-model",
    )


@pytest.fixture
def response_with_pii():
    """An agent response that leaks PII (email and phone)."""
    return AgentResponse(
        content="Your email john@example.com is on file. Call us at 555-123-4567.",
        latency_ms=100.0,
        cost_usd=0.002,
    )


@pytest.fixture
def response_no_cost():
    """An agent response with no cost data populated."""
    return AgentResponse(
        content="I can answer that.",
        latency_ms=200.0,
        cost_usd=None,
    )


@pytest.fixture
def response_no_latency():
    """An agent response with no latency data populated."""
    return AgentResponse(
        content="I can answer that.",
        latency_ms=None,
        cost_usd=0.001,
    )


@pytest.fixture
def response_no_tokens():
    """An agent response with no token usage data populated."""
    return AgentResponse(
        content="I can answer that.",
        latency_ms=200.0,
        cost_usd=0.001,
        tokens_used=None,
    )


@pytest.fixture
def response_multiple_tools():
    """An agent response with several tool calls including repeated ones."""
    return AgentResponse(
        content="Done processing.",
        tool_calls=[
            ToolCall(name="search", arguments={"q": "weather"}),
            ToolCall(name="search", arguments={"q": "weather"}),
            ToolCall(name="search", arguments={"q": "weather"}),
            ToolCall(name="format", arguments={"style": "table"}),
            ToolCall(name="send", arguments={"to": "user"}),
        ],
        latency_ms=500.0,
        cost_usd=0.01,
        tokens_used=TokenUsage(
            prompt_tokens=300, completion_tokens=200, total_tokens=500
        ),
        model="test-model",
    )


@pytest.fixture
def clean_response():
    """An agent response with no PII, reasonable cost and latency."""
    return AgentResponse(
        content="The weather today is sunny with a high of 72F.",
        latency_ms=120.0,
        cost_usd=0.002,
        tokens_used=TokenUsage(
            prompt_tokens=50, completion_tokens=30, total_tokens=80
        ),
        model="test-model",
    )
