# OpenAI Assistant Example

A mock travel assistant (WanderAI) simulating OpenAI Agents SDK patterns.
No API key needed -- the agent uses pattern matching to simulate behavior.

## What it demonstrates

- Tool calls: `search_flights`, `search_hotels`, `book_flight`
- System prompt detection by the AST scanner
- Guardrails: refuses medical/legal advice, resists prompt injection
- Intentional bad behavior: hallucinated flights for unknown routes

## Run

```bash
tailtest run examples/openai-assistant/test_travel.py
```

## What to expect

- 7 tests pass
- 1 test fails (`test_hallucination_check`) -- the agent fabricates a non-existent
  flight (WA-999) for unknown routes, demonstrating how tailtest detects hallucination
