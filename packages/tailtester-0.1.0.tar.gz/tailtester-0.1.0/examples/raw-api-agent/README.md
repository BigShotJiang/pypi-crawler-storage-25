# Raw API Agent Example

A mock Python coding assistant simulating direct LLM API usage (litellm / raw HTTP).
No API key needed -- the agent uses pattern matching to simulate behavior.

## What it demonstrates

- Tool calls: `run_code`, `read_file`, `search_docs`
- Safety guardrails: refuses dangerous code execution
- Documentation search with examples
- Intentional bad behavior: recommends deprecated `os.path` instead of `pathlib`

## Run

```bash
tailtest run examples/raw-api-agent/test_coding.py
```

## What to expect

- 5 tests pass
- 1 test fails (`test_recommends_modern_apis`) -- the agent suggests deprecated
  `os.path` patterns instead of modern `pathlib`, demonstrating how tailtest catches
  outdated API recommendations
