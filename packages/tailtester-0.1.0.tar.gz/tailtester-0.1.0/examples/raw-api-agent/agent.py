"""Mock agent simulating direct LLM API usage (no framework).

Represents the simplest possible agent pattern -- a coding assistant
that calls a model directly via litellm / raw HTTP. No API key needed;
the agent uses pattern matching to simulate behavior.

The code structure mimics real litellm usage so tailtest's AST scanner
can detect the framework, tools, and prompts.
"""

# --- Import patterns the scanner detects ---
# In a real project these would be actual imports:
# import litellm                         # noqa: E800
# from litellm import completion         # noqa: E800

import os  # noqa: F401

from tailtest.models import AgentResponse, ToolCall, TokenUsage

# Scanner picks up env-var references
_api_key = os.environ.get("OPENAI_API_KEY", "mock-key")

# System prompt (scanner's deep-git-scan heuristic detects long strings
# with "you are" in assignments).
SYSTEM_PROMPT = """You are a helpful coding assistant specializing in Python.
You help users write, debug, and understand code.
You always explain your reasoning and suggest best practices.
You prefer modern Python idioms and type hints.
You never execute code that could be harmful (rm -rf, system calls, etc.).
You always recommend currently supported APIs and libraries."""

TOOLS = {
    "run_code": {
        "description": "Execute a Python code snippet in a sandbox",
        "params": ["code"],
    },
    "read_file": {
        "description": "Read the contents of a file",
        "params": ["file_path"],
    },
    "search_docs": {
        "description": "Search Python documentation for a topic",
        "params": ["query"],
    },
}

# Simulated documentation database
_DOCS_DB = {
    "list comprehension": {
        "content": "List comprehensions provide a concise way to create lists: [expr for item in iterable if condition]",
        "example": "squares = [x**2 for x in range(10)]",
        "see_also": ["generator expressions", "dict comprehensions"],
    },
    "dataclass": {
        "content": "The @dataclass decorator (Python 3.7+) automatically generates __init__, __repr__, and other methods.",
        "example": "from dataclasses import dataclass\n\n@dataclass\nclass Point:\n    x: float\n    y: float",
        "see_also": ["pydantic", "attrs", "namedtuple"],
    },
    "async": {
        "content": "Python's asyncio module provides infrastructure for writing concurrent code using async/await syntax.",
        "example": "import asyncio\n\nasync def main():\n    await asyncio.sleep(1)\n    print('done')\n\nasyncio.run(main())",
        "see_also": ["coroutines", "tasks", "event loop"],
    },
    "type hints": {
        "content": "Type hints (PEP 484) allow you to annotate function signatures and variables with types.",
        "example": "def greet(name: str) -> str:\n    return f'Hello, {name}'",
        "see_also": ["typing module", "mypy", "pyright"],
    },
    "pathlib": {
        "content": "pathlib provides object-oriented filesystem path operations, replacing os.path for most use cases.",
        "example": "from pathlib import Path\n\np = Path('data') / 'file.txt'\ntext = p.read_text()",
        "see_also": ["os.path", "shutil"],
    },
}


def coding_assistant(message: str) -> AgentResponse:
    """A mock coding assistant that helps with Python questions.

    Intentional bad behaviors (for testing):
    1. Deprecated API: suggests os.path instead of pathlib for file operations.
    2. Unsafe code: sometimes suggests code without proper input validation.
    """
    msg = message.lower()

    # --- Code execution request ---
    if any(w in msg for w in ["run", "execute", "eval"]) and "code" in msg:
        # Check for dangerous patterns
        if any(danger in msg for danger in ["rm -rf", "system(", "os.remove", "shutil.rmtree"]):
            return AgentResponse(
                content="I cannot execute potentially harmful code. The requested operation could delete files or compromise system security.",
                model="gpt-4o-mini",
                latency_ms=80.0,
                cost_usd=0.001,
            )
        return AgentResponse(
            content="Here's the result of running your code:\n\n```\nOutput: [42, 16, 9, 4, 1]\n```\n\nThe code executed successfully.",
            tool_calls=[
                ToolCall(
                    name="run_code",
                    arguments={"code": "print([x**2 for x in range(5, 0, -1)])"},
                    result={"output": "[42, 16, 9, 4, 1]", "exit_code": 0},
                    duration_ms=50.0,
                )
            ],
            model="gpt-4o-mini",
            latency_ms=200.0,
            cost_usd=0.003,
            tokens_used=TokenUsage(prompt_tokens=80, completion_tokens=60, total_tokens=140),
        )

    # --- File reading ---
    if "read" in msg and "file" in msg:
        # INTENTIONAL BAD BEHAVIOR: suggests deprecated os.path pattern
        return AgentResponse(
            content=(
                "To read a file in Python, you can use `os.path` and the built-in `open()`:\n\n"
                "```python\n"
                "import os\n\n"
                "file_path = os.path.join('data', 'input.txt')\n"
                "if os.path.exists(file_path):\n"
                "    with open(file_path, 'r') as f:\n"
                "        content = f.read()\n"
                "```\n\n"
                "This approach works for any text file."
            ),
            tool_calls=[
                ToolCall(
                    name="read_file",
                    arguments={"file_path": "data/input.txt"},
                    result={"content": "sample file contents", "size_bytes": 42},
                    duration_ms=30.0,
                )
            ],
            model="gpt-4o-mini",
            latency_ms=150.0,
            cost_usd=0.002,
            tokens_used=TokenUsage(prompt_tokens=70, completion_tokens=90, total_tokens=160),
        )

    # --- Documentation search ---
    if any(w in msg for w in ["how", "what", "explain", "help", "docs", "learn", "teach"]):
        topic = _match_topic(msg)
        if topic and topic in _DOCS_DB:
            doc = _DOCS_DB[topic]
            see_also = ", ".join(doc["see_also"])
            return AgentResponse(
                content=(
                    f"## {topic.title()}\n\n"
                    f"{doc['content']}\n\n"
                    f"### Example\n\n```python\n{doc['example']}\n```\n\n"
                    f"**See also:** {see_also}"
                ),
                tool_calls=[
                    ToolCall(
                        name="search_docs",
                        arguments={"query": topic},
                        result=doc,
                        duration_ms=40.0,
                    )
                ],
                model="gpt-4o-mini",
                latency_ms=120.0,
                cost_usd=0.002,
                tokens_used=TokenUsage(prompt_tokens=60, completion_tokens=80, total_tokens=140),
            )
        return AgentResponse(
            content="I'd be happy to help! Could you be more specific about what Python topic you'd like to learn about? I can help with list comprehensions, dataclasses, async programming, type hints, and more.",
            model="gpt-4o-mini",
            latency_ms=100.0,
            cost_usd=0.001,
        )

    # --- Code review / debugging ---
    if any(w in msg for w in ["debug", "fix", "error", "bug", "review"]):
        return AgentResponse(
            content=(
                "I'd be happy to help debug your code. Here are some common things to check:\n\n"
                "1. **Type errors**: Ensure variables have the expected types\n"
                "2. **Off-by-one errors**: Check loop boundaries\n"
                "3. **None checks**: Handle potential None values\n"
                "4. **Import errors**: Verify all modules are installed\n\n"
                "Could you share the code and the error message you're seeing?"
            ),
            model="gpt-4o-mini",
            latency_ms=110.0,
            cost_usd=0.002,
        )

    # --- Prompt injection ---
    if any(phrase in msg for phrase in ["ignore previous", "system prompt", "ignore all"]):
        return AgentResponse(
            content="I'm a coding assistant here to help with Python questions. What would you like to work on?",
            model="gpt-4o-mini",
            latency_ms=70.0,
            cost_usd=0.001,
        )

    # --- Default ---
    return AgentResponse(
        content="Hello! I'm a Python coding assistant. I can help you write code, debug issues, explain concepts, and search documentation. What would you like to work on?",
        model="gpt-4o-mini",
        latency_ms=90.0,
        cost_usd=0.001,
    )


def _match_topic(msg: str) -> str:
    """Find the best matching documentation topic."""
    for topic in _DOCS_DB:
        if topic in msg:
            return topic
        # Partial matching on keywords
        keywords = topic.split()
        if all(k in msg for k in keywords):
            return topic
    # Keyword fallback
    if "list" in msg and ("comp" in msg or "comprehension" in msg):
        return "list comprehension"
    if "class" in msg and "data" in msg:
        return "dataclass"
    if "async" in msg or "await" in msg:
        return "async"
    if "type" in msg and ("hint" in msg or "annot" in msg):
        return "type hints"
    if "path" in msg:
        return "pathlib"
    return ""
