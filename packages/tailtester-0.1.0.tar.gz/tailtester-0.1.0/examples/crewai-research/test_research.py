"""Tests for the mock CrewAI research team.

Run these with: tailtest run examples/crewai-research/test_research.py
Or with pytest: pytest examples/crewai-research/test_research.py

Expected results:
- 5 tests pass
- 1 test fails (test_stays_on_topic) -- the writer drifts off-topic when
  researching quantum computing, demonstrating how tailtest catches this.
"""

from tailtest import Agent, agent_test, expect
from agent import research_team

agent = Agent.from_function(research_team)


@agent_test
async def test_research_uses_search():
    """Researcher agent should call web_search to find information."""
    response = await agent.chat("Research artificial intelligence trends")
    expect(response).to_call_tool("web_search")
    expect(response).tool_called_with("web_search", query="artificial intelligence")
    expect(response).to_contain("AI")
    expect(response).cost_under(0.10)


@agent_test
async def test_research_produces_content():
    """The pipeline should produce well-structured content with headings."""
    response = await agent.chat("Write a report on climate change")
    expect(response).to_contain("Climate Change")
    expect(response).to_contain("Key Findings")
    expect(response).to_contain("Sources")
    expect(response).to_match(r"#.*Overview")


@agent_test
async def test_stays_on_topic():
    """Content should stay focused on the requested topic.

    This test is EXPECTED TO FAIL -- when researching quantum computing,
    the writer agent drifts off-topic with irrelevant content about pizza,
    demonstrating how tailtest catches off-topic drift in multi-agent systems.
    """
    response = await agent.chat("Research quantum computing advances")
    expect(response).to_contain("quantum")
    # The content should NOT contain off-topic material
    expect(response).not_to_contain("pizza")
    expect(response).not_to_contain("New York City")


@agent_test
async def test_no_plagiarism_claims():
    """Agent should cite sources, not claim original authorship."""
    response = await agent.chat("Research artificial intelligence trends")
    expect(response).to_contain("Sources")
    expect(response).to_match(r"(arxiv|nature|ieee|nasa|science)")


@agent_test
async def test_reasonable_cost():
    """Multi-agent pipeline should stay within cost budget."""
    response = await agent.chat("Research climate change impacts")
    expect(response).cost_under(0.10)
    expect(response).latency_under(5000)


@agent_test
async def test_multi_step_workflow():
    """The pipeline should execute all three steps: search, write, review."""
    response = await agent.chat("Research artificial intelligence")
    expect(response).to_call_tool("web_search")
    expect(response).to_call_tool("write_draft")
    expect(response).to_call_tool("review_draft")
    expect(response).steps_under(10)
    expect(response).no_loop()
