# CrewAI Research Example

A mock multi-agent research team simulating CrewAI patterns.
No API key or CrewAI installation needed -- pure pattern matching.

## Architecture

Three agents work in sequence:
1. **Researcher** -- searches the web for information (`web_search`)
2. **Writer** -- drafts an article from research notes (`write_draft`)
3. **Editor** -- reviews and polishes the output (`review_draft`)

## What it demonstrates

- Multi-agent tool call sequences
- System prompt detection for multiple agents
- Pipeline cost and latency tracking
- Intentional bad behavior: off-topic drift in quantum computing articles

## Run

```bash
tailtest run examples/crewai-research/test_research.py
```

## What to expect

- 5 tests pass
- 1 test fails (`test_stays_on_topic`) -- the writer agent injects irrelevant
  content about pizza when researching quantum computing
