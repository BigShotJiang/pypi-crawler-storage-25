"""Mock multi-agent system simulating CrewAI patterns.

Simulates a research team with three agents:
  - Researcher: searches the web for information
  - Writer: drafts content from research findings
  - Editor: reviews and polishes the final output

Uses pattern-matching -- no API key or CrewAI installation needed.
The code structure mimics real CrewAI usage so tailtest's scanner can detect it.
"""

# --- Import patterns the scanner detects ---
# In a real project these would be actual imports:
# from crewai import Agent, Task, Crew  # noqa: E800
# import litellm                        # noqa: E800

import os  # noqa: F401

from tailtest.models import AgentResponse, ToolCall, TokenUsage

# Scanner picks up env-var references
_api_key = os.environ.get("OPENAI_API_KEY", "mock-key")

# System prompts for each agent (scanner's deep-git-scan heuristic
# detects long strings with "you are" in assignments).
RESEARCHER_PROMPT = """You are a senior research analyst specializing in technology topics.
Your role is to find accurate, up-to-date information using web searches.
You verify facts from multiple sources before reporting.
You always cite your sources.
You never fabricate information or make up citations."""

WRITER_PROMPT = """You are a professional content writer who transforms research
into clear, engaging articles. Your writing is factual and well-structured.
You never plagiarize and always give credit to original sources.
You write in a neutral, informative tone."""

EDITOR_PROMPT = """You are a meticulous editor who reviews content for accuracy,
clarity, grammar, and style. You ensure the final output is polished and
professional. You flag any unsupported claims."""

# Tool registry for the multi-agent system
TOOLS = {
    "web_search": {
        "description": "Search the web for information on a topic",
        "params": ["query"],
    },
    "write_draft": {
        "description": "Write a content draft from research findings",
        "params": ["topic", "research_notes"],
    },
    "review_draft": {
        "description": "Review and edit a draft for quality",
        "params": ["draft_content"],
    },
}

# Simulated knowledge base for research
_KNOWLEDGE_BASE = {
    "artificial intelligence": {
        "summary": "AI is a branch of computer science focused on building systems capable of performing tasks that typically require human intelligence.",
        "key_points": [
            "Machine learning is a subset of AI that learns from data",
            "Deep learning uses neural networks with many layers",
            "Large language models (LLMs) have transformed NLP since 2017",
            "Key concerns include bias, safety, and alignment",
        ],
        "sources": ["arxiv.org", "nature.com", "ieee.org"],
    },
    "climate change": {
        "summary": "Climate change refers to long-term shifts in global temperatures and weather patterns, primarily driven by human activities since the Industrial Revolution.",
        "key_points": [
            "Global temperatures have risen ~1.1C since pre-industrial times",
            "CO2 levels exceeded 420 ppm in 2024",
            "Renewable energy capacity grew 50% in 2023",
            "The Paris Agreement targets limiting warming to 1.5C",
        ],
        "sources": ["ipcc.ch", "nasa.gov", "nature.com"],
    },
    "quantum computing": {
        "summary": "Quantum computing leverages quantum mechanical phenomena like superposition and entanglement to process information in fundamentally new ways.",
        "key_points": [
            "Qubits can exist in superposition of 0 and 1",
            "Google claimed quantum supremacy in 2019",
            "Practical quantum advantage for real-world problems remains elusive",
            "Key applications: cryptography, drug discovery, optimization",
        ],
        "sources": ["nature.com", "science.org", "arxiv.org"],
    },
}


def research_team(message: str) -> AgentResponse:
    """Simulate a CrewAI-style multi-agent research workflow.

    The pipeline is: Researcher -> Writer -> Editor.

    Intentional bad behaviors (for testing):
    1. Off-topic drift: for certain topics the writer drifts off-topic.
    2. Cost inflation: the multi-agent pipeline accumulates excessive cost
       for simple queries.
    """
    msg = message.lower()
    topic = _detect_topic(msg)
    tool_calls: list[ToolCall] = []
    total_cost = 0.0

    # --- Step 1: Researcher searches for information ---
    knowledge = _KNOWLEDGE_BASE.get(topic)

    if knowledge:
        research_result = {
            "topic": topic,
            "summary": knowledge["summary"],
            "key_points": knowledge["key_points"],
            "sources": knowledge["sources"],
        }
    else:
        # No data -- researcher does a generic search
        research_result = {
            "topic": topic or msg,
            "summary": f"Limited information available on '{topic or msg}'.",
            "key_points": ["Further research needed"],
            "sources": [],
        }

    tool_calls.append(
        ToolCall(
            name="web_search",
            arguments={"query": topic or msg},
            result=research_result,
            duration_ms=150.0,
        )
    )
    total_cost += 0.005

    # --- Step 2: Writer drafts content ---
    if knowledge:
        points_text = "\n".join(f"- {p}" for p in knowledge["key_points"])
        sources_text = ", ".join(knowledge["sources"])

        draft = (
            f"# {topic.title()}: A Comprehensive Overview\n\n"
            f"{knowledge['summary']}\n\n"
            f"## Key Findings\n\n{points_text}\n\n"
            f"## Sources\n\nThis article draws from: {sources_text}."
        )

        # INTENTIONAL BAD BEHAVIOR: off-topic drift for "quantum computing"
        if topic == "quantum computing":
            draft += (
                "\n\n## Bonus: Best Pizza in New York\n\n"
                "While researching quantum computing, we also discovered that "
                "Joe's Pizza on Carmine Street is widely considered the best "
                "pizza in New York City."
            )
    else:
        draft = (
            f"# {(topic or msg).title()}\n\n"
            f"Research on this topic is ongoing. "
            f"We were unable to find comprehensive information at this time."
        )

    tool_calls.append(
        ToolCall(
            name="write_draft",
            arguments={"topic": topic or msg, "research_notes": str(research_result)},
            result={"draft": draft},
            duration_ms=200.0,
        )
    )
    total_cost += 0.008

    # --- Step 3: Editor reviews ---
    if knowledge:
        edited = draft  # Editor approves with minor tweaks
        review_notes = "Content is accurate and well-structured. Approved with minor formatting adjustments."
    else:
        edited = draft
        review_notes = "Content is thin due to limited source material. Flagged for follow-up research."

    tool_calls.append(
        ToolCall(
            name="review_draft",
            arguments={"draft_content": draft},
            result={"edited": edited, "notes": review_notes},
            duration_ms=180.0,
        )
    )
    total_cost += 0.006

    return AgentResponse(
        content=edited,
        tool_calls=tool_calls,
        model="gpt-4o",
        latency_ms=800.0,
        cost_usd=total_cost,
        tokens_used=TokenUsage(prompt_tokens=500, completion_tokens=350, total_tokens=850),
        metadata={
            "pipeline": ["researcher", "writer", "editor"],
            "topic": topic or msg,
        },
    )


def _detect_topic(msg: str) -> str:
    """Match the user message to a known topic."""
    for topic in _KNOWLEDGE_BASE:
        # Check both the full topic name and individual words
        if topic in msg:
            return topic
        # Partial matching
        topic_words = topic.split()
        if len(topic_words) > 1 and all(w in msg for w in topic_words):
            return topic
    # Single-word fallback
    if "ai" in msg.split() or "artificial" in msg:
        return "artificial intelligence"
    if "climate" in msg or "warming" in msg:
        return "climate change"
    if "quantum" in msg:
        return "quantum computing"
    return ""
