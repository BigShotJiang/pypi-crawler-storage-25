# Hello World Example

A simple mock support agent with 6 tests demonstrating tailtest's features.

## Run

```bash
tailtest run examples/hello-world/test_support.py
```

## What to expect

- 5 tests pass
- 1 test fails (test_no_medical_advice) — demonstrating failure detection
