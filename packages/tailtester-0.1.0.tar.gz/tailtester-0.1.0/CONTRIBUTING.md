# Contributing to Tailtest

Thanks for your interest in contributing to tailtest. This guide will get you up and running.

## Development Setup

```bash
# Clone the repo
git clone https://github.com/avansaber/tailtest.git
cd tailtest

# Create a virtual environment
python3.11 -m venv .venv
source .venv/bin/activate

# Install in editable mode with dev dependencies
pip install -e ".[dev]"

# Verify everything works
pytest tests/ -v
tailtest doctor
```

## Running Tests

```bash
# All tests
pytest tests/ -v

# Specific test file
pytest tests/test_assertions.py -v

# With coverage
pytest tests/ --cov=src/tailtest --cov-report=term-missing
```

## Linting and Formatting

```bash
# Check linting
ruff check src/ tests/

# Auto-fix lint issues
ruff check --fix src/ tests/

# Check formatting
ruff format --check src/ tests/

# Auto-format
ruff format src/ tests/

# Type checking
pyright src/
```

All checks must pass before a PR will be merged. The CI pipeline runs these automatically.

## Code Style

- **Python 3.11+** -- use `match` statements, `X | Y` type unions, and modern syntax
- **Pydantic v2** models for all data structures
- **Async by default** -- use `asyncio` for I/O-bound operations
- **Type annotations on everything** -- pyright strict mode is enforced
- **No docstrings on obvious methods** -- yes on public API
- **ruff** handles both linting and formatting (config in `pyproject.toml`)
- **litellm** for all LLM calls -- never use OpenAI SDK directly
- **No telemetry** -- tailtest collects zero data, ever

## PR Process

1. **Fork** the repository
2. **Branch** from `main` (use a descriptive branch name: `feat/new-assertion`, `fix/timeout-bug`)
3. **Write tests** for your changes
4. **Run the full check suite** locally: `ruff check`, `ruff format --check`, `pyright`, `pytest`
5. **Open a PR** against `main` with a clear description of what and why
6. **Address review feedback** -- maintainers will review within a few days

Keep PRs focused. One feature or fix per PR.

## Contribution Areas

Here are the best places to contribute:

- **New assertion types** -- add to `src/tailtest/assertions/` with tests
- **New framework detectors** -- add to `src/tailtest/context/` to support more agent frameworks
- **New red-team attack patterns** -- add to `src/tailtest/redteam/` with OWASP mapping
- **Documentation** -- improve examples, fix typos, add guides
- **Bug fixes** -- check the issue tracker for `good first issue` labels
- **Example projects** -- add to `examples/` showing tailtest with different frameworks

## Project Structure

```
src/tailtest/
  cli/          # Click commands (13 commands)
  context/      # Context engine (code analysis, framework detection)
  generator/    # Test generation (deterministic + LLM-powered)
  assertions/   # Assertion engine (deterministic, LLM-judge, reliability)
  runner/       # Test execution, parallel runner, retry logic
  redteam/      # Red-team engine (attacks, categories, OWASP compliance)
  production/   # Production monitoring
  mcp/          # MCP server (JSON-RPC 2.0 over stdio)
  reporting/    # Output formats (terminal, JSON, JUnit XML, compliance)
  config/       # Configuration loading and defaults
  audit/        # Structured audit logging
tests/          # Tests mirroring src/ structure
```

## Code of Conduct

This project follows the [Contributor Covenant Code of Conduct](https://www.contributor-covenant.org/version/2/1/code_of_conduct/). By participating, you agree to uphold a welcoming, respectful environment for everyone.

## Questions?

Open a discussion or issue on GitHub. We're happy to help.
