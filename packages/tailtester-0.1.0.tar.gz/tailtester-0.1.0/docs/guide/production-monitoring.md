# Production Monitoring

Tailtest provides three production-stage tools: a validation proxy (`guard`), trace ingestion (`ingest`), and drift detection (`drift`).

## `tailtest guard` -- Real-time validation proxy

Intercepts agent requests and responses, runs validation checks in real-time, and logs results to an audit trail.

### Start the proxy

```bash
tailtest guard --upstream http://localhost:3000
```

This starts a proxy on port 8080. Point your client at the proxy instead of the agent directly.

### Options

```bash
tailtest guard --upstream http://localhost:3000 --port 9090
tailtest guard --upstream http://localhost:3000 --block          # Block failing responses (return 422)
tailtest guard --upstream http://localhost:3000 --max-cost 0.50  # USD per request
tailtest guard --upstream http://localhost:3000 --max-latency 10000  # ms
tailtest guard --upstream http://localhost:3000 --audit-dir ./audit/
```

| Option | Default | Description |
|--------|---------|-------------|
| `--port` | `8080` | Proxy listen port |
| `--upstream` | required | Agent endpoint URL |
| `--block` | `false` | Block responses that fail validation (return 422) |
| `--max-cost` | `1.00` | Max cost per request in USD |
| `--max-latency` | `30000` | Max latency per request in ms |
| `--audit-dir` | `.tailtest/audit/` | Where to write audit logs |

### Built-in validation rules

The guard proxy runs these checks on every response:
- **No PII** -- Emails, SSNs, credit cards, phone numbers
- **No loops** -- Detects repeated consecutive tool calls
- **Cost limit** -- Rejects if cost exceeds threshold
- **Latency limit** -- Rejects if response is too slow

### Endpoints

| Endpoint | Description |
|----------|-------------|
| `/_guard/health` | Health check |
| `/_guard/metrics` | Live metrics (JSON) |
| All other paths | Proxied to upstream |

### Live metrics

While running, the proxy displays a live metrics table:

```
Total requests: 142
Passed:         138
Failed:         3
Blocked:        1
Pass rate:      97.2%
Avg latency:    823.4ms
Requests/sec:   2.31
Uptime:         61s
```

---

## `tailtest ingest` -- Trace ingestion

Pull production traces from observability platforms and convert them to `AgentResponse` objects for evaluation.

### OpenTelemetry (OTLP)

```bash
tailtest ingest --otlp                      # Start OTLP/HTTP receiver on port 4318
tailtest ingest --otlp --otlp-port 9411     # Custom port
```

Configure your agent to export traces to `http://localhost:4318/v1/traces`.

### Langfuse

```bash
tailtest ingest --langfuse-url https://cloud.langfuse.com
```

Requires `LANGFUSE_PUBLIC_KEY` and `LANGFUSE_SECRET_KEY` environment variables.

### LangSmith

```bash
tailtest ingest --langsmith
```

Requires `LANGSMITH_API_KEY` environment variable.

### JSON file

```bash
tailtest ingest --json traces.json
```

Accepts OTLP format or a simple JSON array of trace objects.

### Options

| Option | Default | Description |
|--------|---------|-------------|
| `--otlp` | `false` | Start OTLP/HTTP receiver |
| `--otlp-port` | `4318` | OTLP receiver port |
| `--langfuse-url` | none | Langfuse instance URL |
| `--langsmith` | `false` | Pull from LangSmith |
| `--json FILE` | none | Ingest from a JSON file |
| `--save/--no-save` | `true` | Persist traces to `.tailtest/traces/` |
| `--storage-dir` | `.tailtest/traces/` | Trace storage directory |

### What gets extracted

From each trace, tailtest extracts:
- Response content
- Tool calls (name, arguments, results)
- Model info
- Latency
- Token usage
- Cost

These become `AgentResponse` objects you can run assertions against.

---

## `tailtest drift` -- Drift detection

Compare current agent behavior against a stored baseline to detect quality regressions.

### Set a baseline

After a successful test run:

```bash
tailtest drift --baseline run-123
```

This records:
- Total responses
- Average latency
- Average cost
- Error rate
- PII leak rate

### Check for drift

```bash
tailtest drift --check
tailtest drift --check --traces-dir ./my-traces/
```

### Alerts

```bash
tailtest drift --check --alert terminal          # Print alerts
tailtest drift --check --alert json              # JSON output
tailtest drift --check --alert slack --webhook https://hooks.slack.com/...
```

### Drift alert severity

| Severity | Meaning |
|----------|---------|
| `critical` | Major regression -- latency doubled, error rate spiked, PII leaking |
| `warning` | Moderate change -- cost increased, response quality dipped |

### Exit codes

- `0` -- No drift detected (or no critical alerts)
- `1` -- Critical drift detected

### CI integration

```bash
# Set baseline once
tailtest drift --baseline run-latest

# Check on every deploy
tailtest drift --check
```

---

## Failure classification

When guard or drift detects issues, failures are classified:

| Category | Example |
|----------|---------|
| PII leak | Response contains email/SSN/credit card |
| Cost overrun | Single request cost $2.50 (limit $1.00) |
| Latency spike | Response took 45s (limit 30s) |
| Loop detected | Agent called `search` 8 times in a row |
| Quality drift | Average pass rate dropped from 95% to 72% |
| Error spike | Error rate jumped from 1% to 15% |

## Auto-regression test generation

When `tailtest ingest` pulls production traces that show failures, you can use `tailtest generate` to automatically create regression tests from those traces:

```bash
tailtest ingest --langfuse-url https://cloud.langfuse.com
tailtest generate --only safety    # Generate tests covering the failure patterns
```

## Setting baselines

Baselines should be set from a known-good state:

1. Run your full test suite: `tailtest run`
2. Verify all critical tests pass
3. Set baseline: `tailtest drift --baseline <run-id>`
4. Store baseline in version control (`.tailtest/baselines/current.json`)

Update baselines after intentional changes (new model, changed prompts, etc.).
