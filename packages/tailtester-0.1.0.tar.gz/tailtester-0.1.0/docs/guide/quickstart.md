# Quickstart

Get from zero to running agent tests in 5 minutes.

## Install

```bash
pip install tailtester
```

## Initialize your project

```bash
cd your-agent-project/
tailtest init
```

This creates a `.tailtest/` directory with default config, test folders, and audit structure.

You can specify your framework upfront:

```bash
tailtest init --framework langchain
# Options: langchain, crewai, openai, anthropic, pydantic-ai
```

## Scan your project

```bash
tailtest scan .
```

Tailtest parses your source code and discovers:
- **Framework** (LangChain, CrewAI, OpenAI, PydanticAI, etc.)
- **Tools** your agent can call
- **Prompts** (system messages, templates)
- **Agents** (agent definitions, orchestrators)
- **Models** in use (gpt-4o, claude-sonnet, etc.)

Use `--deep` to include git history analysis, or `--output json` for machine-readable output.

## Write your first test

Create `test_agent.py`:

```python
from tailtest import agent_test, Agent, expect

# Wrap your agent function
from my_agent import chat_fn
agent = Agent.from_function(chat_fn)

@agent_test
async def test_greeting():
    """Agent should respond with a helpful greeting."""
    response = await agent.chat("Hello")
    expect(response).to_contain("help")
    expect(response).cost_under(0.01)
    expect(response).latency_under(500)
```

## Run tests

```bash
tailtest run test_agent.py
```

Or run all tests discovered in your project:

```bash
tailtest run
```

### Filter by tags

```bash
tailtest run --tag smoke
tailtest run --tag safety --tag tools
```

### Run in CI mode (JUnit XML output)

```bash
tailtest run --ci
```

## View results

Results print to the terminal by default. For richer reports:

```bash
tailtest report                    # Terminal summary
tailtest report --format html      # HTML report
tailtest report --format html --open  # Generate and open in browser
tailtest report --trend            # Trend across last 30 runs
```

## Next steps

### Auto-generate tests from your scan

```bash
tailtest generate           # Generate tests for all discovered tools/prompts/safety
tailtest generate --only safety   # Safety tests only
tailtest generate --only tools    # Tool tests only
```

### Red-team your agent

```bash
tailtest redteam --quick                  # Fast security scan (~5 min)
tailtest redteam                          # Standard scan
tailtest redteam --thorough --owasp       # Exhaustive + OWASP compliance
```

### Watch for changes

```bash
tailtest watch .
```

Monitors your project for file changes and auto-updates context. Press Ctrl+C to stop.

### Check system health

```bash
tailtest doctor
```

Validates that your LLM judge is reachable, config is valid, and dependencies are installed.
