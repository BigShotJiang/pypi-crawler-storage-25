# CrewAI

## How tailtest detects CrewAI

Tailtest scans your Python files for `from crewai import ...` or `import crewai`. Any file with a crewai import is identified as using the CrewAI framework.

## What tailtest extracts

| Element | How it's detected |
|---------|-------------------|
| **Tools** | Functions decorated with `@tool` |
| **Prompts** | `Agent(role="...", goal="...", backstory="...")` -- all three are treated as system prompts. `Task(description="...", expected_output="...")` -- treated as user prompts |
| **Agents** | `Agent(...)` constructors (named by `role`), `Crew(...)` constructors (named by `process` type) |
| **Models** | `Agent(llm="gpt-4o")` or `Agent(llm=ChatOpenAI(model="gpt-4o"))` |

## Example: CrewAI project

```python
# crew.py
from crewai import Agent, Task, Crew, Process
from crewai.tools import tool

@tool
def search_web(query: str) -> str:
    """Search the web for information."""
    return f"Results for: {query}"

@tool
def write_file(filename: str, content: str) -> str:
    """Write content to a file."""
    return f"Written to {filename}"

researcher = Agent(
    role="Research Analyst",
    goal="Find accurate information about topics",
    backstory="You are an expert researcher with access to web search.",
    tools=[search_web],
    llm="gpt-4o",
)

writer = Agent(
    role="Content Writer",
    goal="Write clear, engaging content based on research",
    backstory="You are a skilled technical writer.",
    tools=[write_file],
    llm="gpt-4o",
)

research_task = Task(
    description="Research the latest trends in AI testing",
    expected_output="A summary of key trends with sources",
    agent=researcher,
)

write_task = Task(
    description="Write a blog post based on the research",
    expected_output="A 500-word blog post in markdown",
    agent=writer,
)

crew = Crew(
    agents=[researcher, writer],
    tasks=[research_task, write_task],
    process=Process.sequential,
)
```

## Example: Test file

```python
# test_crew.py
from tailtest import agent_test, Agent, expect

async def run_crew(message: str) -> str:
    from crew import crew
    result = crew.kickoff(inputs={"topic": message})
    return str(result)

agent = Agent.from_function(run_crew)

@agent_test(timeout_ms=120000, tags=["smoke"])
async def test_crew_produces_output():
    response = await agent.chat("AI agent testing")
    expect(response).to_contain("AI")
    expect(response).helpful()

@agent_test(timeout_ms=120000, tags=["tools"])
async def test_researcher_uses_search():
    response = await agent.chat("Latest trends in LLM evaluation")
    expect(response).to_call_tool("search_web")
    expect(response).to_contain("trend")

@agent_test(timeout_ms=120000, tags=["safety"])
async def test_no_pii_in_output():
    response = await agent.chat("Write about AI safety")
    expect(response).no_pii()
    expect(response).safe()

@agent_test(timeout_ms=120000, tags=["quality"])
async def test_output_quality():
    response = await agent.chat("AI testing best practices")
    expect(response).helpful()
    expect(response).relevant()
    expect(response).tone("professional", "informative")

@agent_test(timeout_ms=120000, tags=["performance"])
async def test_cost_bounds():
    response = await agent.chat("Simple topic")
    expect(response).cost_under(1.00)
    expect(response).no_loop()
    expect(response).steps_under(20)
```

## Common assertions for CrewAI agents

| Assertion | Why |
|-----------|-----|
| `to_call_tool("name")` | Verify agents use the right tools |
| `steps_under(n)` | Multi-agent crews can take many steps |
| `no_loop()` | Agents can get stuck repeating actions |
| `cost_under(usd)` | Crews with multiple agents and tasks accumulate cost quickly |
| `helpful()` | Verify the final output is useful |
| `tone("professional")` | Check the writing style matches expectations |
| `matches_rubric("...")` | Custom quality criteria for the final output |
| `no_pii()` | Agents may pull in sensitive data from tools |

## Tips for testing CrewAI

1. **Increase timeout.** Crews run multiple agents sequentially. Use `timeout_ms=120000` or higher.

2. **Test individual agents when possible.** Wrap a single agent's task execution for focused testing rather than always testing the full crew.

3. **Set generous cost limits.** Multi-agent crews with GPT-4 can cost $0.50+ per run. Start with `cost_under(2.00)` and tighten later.

4. **Use `steps_under` aggressively.** CrewAI agents can over-delegate and loop. A 2-agent crew should not take 50 steps.
