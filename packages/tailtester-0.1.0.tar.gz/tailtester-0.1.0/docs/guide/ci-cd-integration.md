# CI/CD Integration

## GitHub Actions

```yaml
name: Agent Tests
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: "3.11"

      - name: Install dependencies
        run: |
          pip install tailtester
          pip install -r requirements.txt

      - name: Run agent tests
        run: tailtest run --ci

      - name: Upload test results
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: test-results
          path: .tailtest/reports/

      - name: Publish JUnit results
        if: always()
        uses: mikepenz/action-junit-report@v4
        with:
          report_paths: .tailtest/reports/junit.xml
```

### With security scanning

```yaml
name: Agent Tests + Security
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: "3.11"

      - name: Install
        run: |
          pip install tailtester
          pip install -r requirements.txt

      - name: Run tests
        run: tailtest run --ci --tag smoke

      - name: Security scan
        run: tailtest redteam --quick --owasp --report json

      - name: Upload reports
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: tailtest-reports
          path: .tailtest/reports/
```

### With drift detection

```yaml
name: Drift Check
on:
  schedule:
    - cron: '0 */6 * * *'  # Every 6 hours

jobs:
  drift:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: "3.11"

      - name: Install
        run: pip install tailtester

      - name: Check for drift
        run: tailtest drift --check --alert json
```

## GitLab CI

```yaml
stages:
  - test
  - security

agent-tests:
  stage: test
  image: python:3.11
  script:
    - pip install tailtester
    - pip install -r requirements.txt
    - tailtest run --ci
  artifacts:
    when: always
    paths:
      - .tailtest/reports/
    reports:
      junit: .tailtest/reports/junit.xml

security-scan:
  stage: security
  image: python:3.11
  script:
    - pip install tailtester
    - pip install -r requirements.txt
    - tailtest redteam --quick --report json
  artifacts:
    when: always
    paths:
      - .tailtest/reports/
  allow_failure: true
```

## CI mode: `tailtest run --ci`

The `--ci` flag enables:

1. **JUnit XML output** -- Written to `.tailtest/reports/junit.xml`
2. **Strict exit codes** -- Process exits with code 1 on any failure
3. **Machine-readable output** -- Alongside terminal output

```bash
tailtest run --ci
tailtest run --ci --tag smoke           # Only smoke tests
tailtest run --ci --parallel 4          # Parallel execution
tailtest run --ci --cost-limit 5.00     # Abort if cost exceeds $5
```

## Exit codes

| Code | Meaning |
|------|---------|
| `0` | All tests passed |
| `1` | One or more tests failed |

Both `tailtest run` and `tailtest redteam` use these exit codes.

## CLI options for CI

```bash
# Run all tests in CI mode
tailtest run --ci

# Filter by tags
tailtest run --ci --tag smoke --tag critical

# Parallel execution
tailtest run --ci --parallel 4

# Set cost limit
tailtest run --ci --cost-limit 10.00

# Override model for testing
tailtest run --ci --model gpt-4o-mini

# Override judge model
tailtest run --ci --judge ollama/llama3.2

# Replay recorded responses (no live LLM calls)
tailtest run --ci --replay

# Reliability mode (run each test N times)
tailtest run --ci --reliability 5
```

## Report generation in CI

```bash
# Terminal text (default)
tailtest report

# HTML report
tailtest report --format html

# JSON export
tailtest report --format json -o report.json

# Trend data
tailtest report --daily
tailtest report --weekly
tailtest report --trend

# With compliance data
tailtest report --compliance eu-ai-act
tailtest report --compliance nist
tailtest report --compliance soc2
```

## Badge integration

Use exit codes with GitHub's badge system. Example with a passing test run:

```yaml
- name: Run tests
  id: tests
  run: |
    tailtest run --ci --tag smoke
    echo "status=passing" >> $GITHUB_OUTPUT
  continue-on-error: true

- name: Create badge
  uses: schneegans/dynamic-badges-action@v1.7.0
  with:
    auth: ${{ secrets.GIST_TOKEN }}
    gistID: your-gist-id
    filename: tailtest-badge.json
    label: agent tests
    message: ${{ steps.tests.outcome == 'success' && 'passing' || 'failing' }}
    color: ${{ steps.tests.outcome == 'success' && 'green' || 'red' }}
```

## Environment variables

Set these in your CI environment as needed:

| Variable | Used by | Description |
|----------|---------|-------------|
| `OPENAI_API_KEY` | Agent / judge | OpenAI API key |
| `ANTHROPIC_API_KEY` | Agent / judge | Anthropic API key |
| `LANGFUSE_PUBLIC_KEY` | `tailtest ingest` | Langfuse auth |
| `LANGFUSE_SECRET_KEY` | `tailtest ingest` | Langfuse auth |
| `LANGSMITH_API_KEY` | `tailtest ingest` | LangSmith auth |

## Recommended CI pipeline

```
1. tailtest run --ci --tag smoke        # Fast smoke tests (every push)
2. tailtest run --ci                    # Full suite (every merge to main)
3. tailtest redteam --quick             # Security scan (every merge)
4. tailtest redteam --thorough --owasp  # Deep security (weekly/pre-release)
5. tailtest drift --check               # Drift detection (scheduled)
```
