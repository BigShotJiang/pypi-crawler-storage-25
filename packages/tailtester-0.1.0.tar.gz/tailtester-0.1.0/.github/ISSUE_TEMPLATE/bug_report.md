---
name: Bug Report
about: Report a bug to help us improve tailtest
title: "[BUG] "
labels: bug
assignees: ""
---

## Description

A clear and concise description of the bug.

## Steps to Reproduce

1. Install tailtest: `pip install tailtester`
2. Run command: `tailtest ...`
3. See error

## Expected Behavior

What you expected to happen.

## Actual Behavior

What actually happened. Include the full error output if applicable.

## Environment

- **OS:** (e.g., Ubuntu 22.04, macOS 14.2)
- **Python version:** (e.g., 3.11.7)
- **Tailtest version:** (output of `tailtest --version`)
- **LLM provider/model:** (if relevant)
- **Agent framework:** (if relevant, e.g., LangChain, CrewAI)

## Minimal Reproduction

If possible, provide a minimal `tailtest.yaml` or test file that reproduces the issue.

```yaml
# tailtest.yaml or test file content
```

## Additional Context

Any other context about the problem (logs, screenshots, related issues).
