---
name: Feature Request
about: Suggest a feature or improvement for tailtest
title: "[FEATURE] "
labels: enhancement
assignees: ""
---

## Problem

A clear description of the problem this feature would solve.

Example: "I'm frustrated when ..." or "There's no way to ..."

## Proposed Solution

Describe the feature you'd like to see. Be specific about the interface (CLI flags, config options, API).

## Example Usage

Show how you'd use this feature:

```bash
# CLI example
tailtest <new-command> --flag value
```

```yaml
# Config example (tailtest.yaml)
new_option: value
```

## Alternatives Considered

Other approaches you've considered and why they fall short.

## Category

Which area does this feature relate to?

- [ ] New assertion type
- [ ] New framework detector/adapter
- [ ] New red-team attack pattern
- [ ] CLI improvement
- [ ] Reporting/output format
- [ ] MCP server
- [ ] Production monitoring
- [ ] Documentation
- [ ] Other

## Additional Context

Any other context, mockups, or references.
