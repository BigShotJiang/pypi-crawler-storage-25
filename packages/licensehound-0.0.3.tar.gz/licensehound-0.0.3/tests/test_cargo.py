"""Cargo.lock parser tests."""

from __future__ import annotations

from pathlib import Path

from licensehound.parsers.cargo import parse_cargo_lock

FIXTURE = Path(__file__).parent / "fixtures" / "sample-Cargo.lock"


def test_parses_crates_io_packages() -> None:
    pkgs = parse_cargo_lock(FIXTURE)
    names = {p.name for p in pkgs}
    assert "anyhow" in names
    assert "serde" in names


def test_skips_workspace_members() -> None:
    pkgs = parse_cargo_lock(FIXTURE)
    # sample-app has no `source` field — it's a workspace member.
    assert all(p.name != "sample-app" for p in pkgs)


def test_skips_git_dependencies() -> None:
    pkgs = parse_cargo_lock(FIXTURE)
    # git-only-package has source=git+... — not crates.io.
    assert all(p.name != "git-only-package" for p in pkgs)


def test_dedupes_repeated_entries() -> None:
    pkgs = parse_cargo_lock(FIXTURE)
    # anyhow appears twice in the fixture; should be deduped.
    assert sum(1 for p in pkgs if p.name == "anyhow") == 1


def test_license_is_none_pre_enrichment() -> None:
    pkgs = parse_cargo_lock(FIXTURE)
    assert all(p.license is None for p in pkgs)
    assert all(p.ecosystem == "cargo" for p in pkgs)
