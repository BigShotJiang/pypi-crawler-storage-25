"""go.sum parser tests."""

from __future__ import annotations

from pathlib import Path

from licensehound.parsers.go import parse_go_sum

FIXTURE = Path(__file__).parent / "fixtures" / "sample-go.sum"


def test_parses_modules() -> None:
    pkgs = parse_go_sum(FIXTURE)
    names = {p.name for p in pkgs}
    assert "github.com/stretchr/testify" in names
    assert "github.com/google/uuid" in names


def test_skips_go_mod_lines() -> None:
    pkgs = parse_go_sum(FIXTURE)
    # The /go.mod lines are duplicates with version field "v1.8.4/go.mod" — should be skipped.
    assert all(not p.version.endswith("/go.mod") for p in pkgs)


def test_dedupes_repeats() -> None:
    pkgs = parse_go_sum(FIXTURE)
    # uuid appears twice in the fixture (only the zip entries; we already skip /go.mod);
    # parse should dedupe by (name, version).
    assert sum(1 for p in pkgs if p.name == "github.com/google/uuid") == 1


def test_license_is_none_pre_enrichment() -> None:
    pkgs = parse_go_sum(FIXTURE)
    assert all(p.license is None for p in pkgs)
    assert all(p.ecosystem == "go" for p in pkgs)
