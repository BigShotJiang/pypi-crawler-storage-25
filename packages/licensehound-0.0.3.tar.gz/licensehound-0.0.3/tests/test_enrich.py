"""Enricher tests — network calls are stubbed."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from licensehound.types import Package


@pytest.fixture(autouse=True)
def isolated_cache(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("LICENSEHOUND_CACHE", str(tmp_path / "depsdev.json"))
    import importlib

    import licensehound.enrich

    importlib.reload(licensehound.enrich)


class _FakeResp:
    """Minimal urlopen-result stand-in: supports the with-statement and json.load."""

    def __init__(self, payload: dict[str, Any]) -> None:
        self._body = json.dumps(payload).encode()

    def __enter__(self) -> _FakeResp:
        return self

    def __exit__(self, *_: object) -> None:
        return None

    def read(self) -> bytes:
        return self._body


def test_enriches_missing_license(monkeypatch: pytest.MonkeyPatch) -> None:
    import licensehound.enrich as e

    calls: list[str] = []

    def fake_urlopen(url: str, timeout: int) -> _FakeResp:
        calls.append(url)
        return _FakeResp({"licenses": ["MIT"]})

    monkeypatch.setattr(e.urllib.request, "urlopen", fake_urlopen)

    pkg = Package(
        ecosystem="cargo", name="foo", version="1.0.0", license=None, source_lockfile="Cargo.lock"
    )
    out = e.enrich([pkg])
    assert out[0].license == "MIT"
    assert len(calls) == 1


def test_passes_through_already_resolved(monkeypatch: pytest.MonkeyPatch) -> None:
    import licensehound.enrich as e

    def boom(*_a: object, **_k: object) -> None:
        raise AssertionError("urlopen should not be called for already-resolved packages")

    monkeypatch.setattr(e.urllib.request, "urlopen", boom)

    pkg = Package(
        ecosystem="cargo", name="foo", version="1.0.0", license="MIT", source_lockfile="Cargo.lock"
    )
    out = e.enrich([pkg])
    assert out[0].license == "MIT"


def test_caches_results(monkeypatch: pytest.MonkeyPatch) -> None:
    import licensehound.enrich as e

    call_count = [0]

    def fake_urlopen(url: str, timeout: int) -> _FakeResp:
        call_count[0] += 1
        return _FakeResp({"licenses": ["MIT"]})

    monkeypatch.setattr(e.urllib.request, "urlopen", fake_urlopen)

    pkg = Package(
        ecosystem="cargo", name="foo", version="1.0.0", license=None, source_lockfile="Cargo.lock"
    )
    e.enrich([pkg])
    e.enrich([pkg])
    assert call_count[0] == 1  # Second call hit the cache.


def test_dual_license_joined(monkeypatch: pytest.MonkeyPatch) -> None:
    import licensehound.enrich as e

    monkeypatch.setattr(
        e.urllib.request,
        "urlopen",
        lambda *_a, **_k: _FakeResp({"licenses": ["Apache-2.0 OR MIT"]}),
    )
    pkg = Package(
        ecosystem="cargo", name="serde", version="1.0.0", license=None, source_lockfile="Cargo.lock"
    )
    out = e.enrich([pkg])
    assert out[0].license == "Apache-2.0 OR MIT"
