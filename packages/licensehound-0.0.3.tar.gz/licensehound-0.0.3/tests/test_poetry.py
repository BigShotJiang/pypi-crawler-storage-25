"""poetry.lock parser tests."""

from __future__ import annotations

from pathlib import Path

from licensehound.parsers.poetry import parse_poetry_lock

FIXTURE = Path(__file__).parent / "fixtures" / "sample-poetry.lock"


def test_parses_packages() -> None:
    pkgs = parse_poetry_lock(FIXTURE)
    names = {p.name for p in pkgs}
    assert names == {"requests", "urllib3", "internal-package"}


def test_inline_license_preserved() -> None:
    pkgs = parse_poetry_lock(FIXTURE)
    inline = next(p for p in pkgs if p.name == "internal-package")
    assert inline.license == "MIT"


def test_missing_license_is_none() -> None:
    pkgs = parse_poetry_lock(FIXTURE)
    requests_pkg = next(p for p in pkgs if p.name == "requests")
    assert requests_pkg.license is None
