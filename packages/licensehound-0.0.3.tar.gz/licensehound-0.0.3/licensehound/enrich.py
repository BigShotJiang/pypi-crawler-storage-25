"""License enrichment via deps.dev for ecosystems whose lockfiles don't carry
license info inline (Cargo, poetry, go).

deps.dev is a Google service that aggregates package metadata across npm, pip,
Maven, Cargo, Go and others. Free, no auth, ~100req/sec rate limit. Cached
locally at ~/.cache/licensehound/depsdev.json so repeat scans don't hammer
the API.

Honesty rule (mirrored from the parsers): if deps.dev returns no license, we
mark the package as `license=None` rather than guess. The whole point is to
flag what we don't know.
"""

from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Iterable
from pathlib import Path

from licensehound.types import Package

CACHE_PATH = Path(
    os.environ.get("LICENSEHOUND_CACHE", Path.home() / ".cache" / "licensehound" / "depsdev.json")
)
CACHE_TTL_DAYS = 30  # licenses don't change for a published version, but pad anyway
API_BASE = "https://api.deps.dev/v3/systems"

# Map our ecosystem strings to deps.dev system codes.
SYSTEMS = {
    "cargo": "cargo",
    "pypi": "pypi",
    "go": "go",
    "npm": "npm",
}


def _load_cache() -> dict[str, dict[str, object]]:
    if not CACHE_PATH.exists():
        return {}
    try:
        return json.loads(CACHE_PATH.read_text())  # type: ignore[no-any-return]
    except (json.JSONDecodeError, OSError):
        return {}


def _save_cache(cache: dict[str, dict[str, object]]) -> None:
    CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    CACHE_PATH.write_text(json.dumps(cache, sort_keys=True, indent=2))


def _key(ecosystem: str, name: str, version: str) -> str:
    return f"{ecosystem}::{name}@{version}"


def _fresh(entry: dict[str, object]) -> bool:
    fetched_at = float(entry.get("fetched_at", 0.0))  # type: ignore[arg-type]
    age_days = (time.time() - fetched_at) / 86400
    return age_days < CACHE_TTL_DAYS


def _fetch_one(ecosystem: str, name: str, version: str) -> str | None:
    """Hit deps.dev for one (system, name, version). Returns license expression or None."""
    system = SYSTEMS.get(ecosystem)
    if system is None:
        return None
    url = (
        f"{API_BASE}/{system}/packages/"
        f"{urllib.parse.quote(name, safe='')}/versions/"
        f"{urllib.parse.quote(version, safe='')}"
    )
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            data = json.load(r)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise
    licenses = data.get("licenses") or []
    if not licenses:
        return None
    # deps.dev returns a list of expressions; preserve them verbatim joined by AND.
    # Most packages have exactly one entry like "MIT" or "Apache-2.0 OR MIT".
    return " AND ".join(licenses) if len(licenses) > 1 else licenses[0]


def enrich(packages: Iterable[Package]) -> list[Package]:
    """Resolve licenses for any Package whose `license` is None, via deps.dev.

    Idempotent on packages that already have a license (those pass through unchanged).
    """
    cache = _load_cache()
    out: list[Package] = []
    cache_dirty = False

    for pkg in packages:
        if pkg.license is not None:
            out.append(pkg)
            continue
        key = _key(pkg.ecosystem, pkg.name, pkg.version)
        cached = cache.get(key)
        if cached and _fresh(cached):
            license_str = cached.get("license")
        else:
            license_str = _fetch_one(pkg.ecosystem, pkg.name, pkg.version)
            cache[key] = {"license": license_str, "fetched_at": time.time()}
            cache_dirty = True
        out.append(
            Package(
                ecosystem=pkg.ecosystem,
                name=pkg.name,
                version=pkg.version,
                license=license_str if isinstance(license_str, str) else None,
                source_lockfile=pkg.source_lockfile,
            )
        )

    if cache_dirty:
        _save_cache(cache)
    return out
