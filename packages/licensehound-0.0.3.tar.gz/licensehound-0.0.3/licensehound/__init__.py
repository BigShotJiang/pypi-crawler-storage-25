"""LicenseHound — OSS license compliance scanner."""

__version__ = "0.0.3"
