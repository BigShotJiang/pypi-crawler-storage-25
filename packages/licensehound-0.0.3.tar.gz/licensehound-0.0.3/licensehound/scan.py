"""Top-level scan orchestrator."""

from __future__ import annotations

from collections import Counter
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

from licensehound.enrich import enrich
from licensehound.parsers import (
    parse_cargo_lock,
    parse_go_sum,
    parse_package_lock,
    parse_poetry_lock,
    parse_uv_lock,
)
from licensehound.types import Package


@dataclass
class ScanResult:
    packages: list[Package]
    lockfiles: list[tuple[str, int]]  # (path, package count)
    license_counts: Counter[str]
    no_license_count: int
    enriched_count: int  # packages whose license came from deps.dev


_PARSERS = {
    "package-lock.json": parse_package_lock,
    "uv.lock": parse_uv_lock,
    "Cargo.lock": parse_cargo_lock,
    "poetry.lock": parse_poetry_lock,
    "go.sum": parse_go_sum,
}

_SKIP_DIRS = {
    "node_modules",
    ".venv",
    "venv",
    ".git",
    "dist",
    "build",
    "target",  # rust
    ".tox",
    "vendor",  # go convention
    "__pycache__",
}


def find_lockfiles(root: Path) -> list[Path]:
    """Find supported lockfiles under root, skipping common build/dep directories."""
    found: list[Path] = []
    targets = set(_PARSERS.keys())
    for path in root.rglob("*"):
        if path.is_dir():
            continue
        if any(part in _SKIP_DIRS for part in path.parts):
            continue
        if path.name in targets:
            found.append(path)
    return sorted(found)


def scan(root: Path, *, enrich_external: bool = True) -> ScanResult:
    """Walk root, parse every supported lockfile, enrich missing license info, return result."""
    lockfiles = find_lockfiles(root)
    all_packages: list[Package] = []
    counts: list[tuple[str, int]] = []

    for lf in lockfiles:
        parser = _PARSERS.get(lf.name)
        if parser is None:
            continue
        pkgs = parser(lf)
        all_packages.extend(pkgs)
        counts.append((str(lf), len(pkgs)))

    pre_enrich_unknown = sum(1 for p in all_packages if p.license is None)
    if enrich_external and pre_enrich_unknown:
        all_packages = enrich(all_packages)
    post_enrich_unknown = sum(1 for p in all_packages if p.license is None)
    enriched = pre_enrich_unknown - post_enrich_unknown

    return ScanResult(
        packages=all_packages,
        lockfiles=counts,
        license_counts=_count_licenses(all_packages),
        no_license_count=post_enrich_unknown,
        enriched_count=enriched,
    )


def _count_licenses(packages: Iterable[Package]) -> Counter[str]:
    return Counter(p.license for p in packages if p.license)
