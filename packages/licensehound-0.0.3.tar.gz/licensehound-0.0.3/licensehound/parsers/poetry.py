"""poetry.lock parser. Python (poetry).

poetry.lock format: TOML with [[package]] entries that include name + version
but typically no license (poetry resolves it from PyPI on install but doesn't
record it in the lockfile). We resolve via licensehound.enrich.
"""

from __future__ import annotations

import tomllib
from pathlib import Path

from licensehound.types import Package


def parse_poetry_lock(path: Path) -> list[Package]:
    data = tomllib.loads(path.read_text())
    out: list[Package] = []
    seen: set[tuple[str, str]] = set()

    for pkg in data.get("package", []):
        name = pkg.get("name")
        version = pkg.get("version")
        if not name or not version:
            continue
        identity = (name, version)
        if identity in seen:
            continue
        seen.add(identity)

        # Some poetry entries have an inline `license` string for top-level packages
        # (rare but possible); preserve it if present.
        license_raw = pkg.get("license")
        if isinstance(license_raw, dict):
            license_raw = license_raw.get("text") or None
        if not isinstance(license_raw, str):
            license_raw = None

        out.append(
            Package(
                ecosystem="pypi",
                name=name,
                version=version,
                license=license_raw,
                source_lockfile=str(path),
            )
        )

    return out
