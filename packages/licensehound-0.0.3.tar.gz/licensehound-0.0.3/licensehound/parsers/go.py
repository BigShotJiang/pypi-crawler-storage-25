"""go.sum parser. Go modules ecosystem.

go.sum is a flat text file: one line per (module, version, hash-kind, hash).
Each module appears twice — once for `/go.mod` and once for the module zip.
We dedupe by (name, version) and skip the `/go.mod` lines to avoid double-
counting, then enrich license info via deps.dev.
"""

from __future__ import annotations

from pathlib import Path

from licensehound.types import Package


def parse_go_sum(path: Path) -> list[Package]:
    out: list[Package] = []
    seen: set[tuple[str, str]] = set()

    for line in path.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        # Format: "module v1.2.3 h1:HASH=" or "module v1.2.3/go.mod h1:HASH="
        parts = line.split()
        if len(parts) < 3:
            continue
        name, version_field = parts[0], parts[1]
        # Skip the /go.mod lines (they're the manifest hash, not the module zip).
        if version_field.endswith("/go.mod"):
            continue
        version = version_field
        identity = (name, version)
        if identity in seen:
            continue
        seen.add(identity)

        out.append(
            Package(
                ecosystem="go",
                name=name,
                version=version,
                license=None,  # filled in by enrich.py
                source_lockfile=str(path),
            )
        )

    return out
