"""Cargo.lock parser. Rust ecosystem.

Cargo.lock is TOML; each [[package]] entry has name + version + source. License
metadata isn't in the lockfile — we resolve it via licensehound.enrich after
parsing. Local-path packages (workspace members) and packages from sources
other than crates.io are skipped from enrichment.
"""

from __future__ import annotations

import tomllib
from pathlib import Path

from licensehound.types import Package

CRATES_IO_SOURCE_PREFIX = "registry+https://github.com/rust-lang/crates.io-index"


def parse_cargo_lock(path: Path) -> list[Package]:
    data = tomllib.loads(path.read_text())
    out: list[Package] = []
    seen: set[tuple[str, str]] = set()

    for pkg in data.get("package", []):
        name = pkg.get("name")
        version = pkg.get("version")
        if not name or not version:
            continue
        # Skip workspace members (they have no `source` field) — those are the user's own crates.
        if "source" not in pkg:
            continue
        # Skip non-crates.io sources (git deps, path deps) — deps.dev can't enrich those.
        if CRATES_IO_SOURCE_PREFIX not in pkg.get("source", ""):
            continue
        identity = (name, version)
        if identity in seen:
            continue
        seen.add(identity)

        out.append(
            Package(
                ecosystem="cargo",
                name=name,
                version=version,
                license=None,  # filled in by enrich.py
                source_lockfile=str(path),
            )
        )

    return out
