"""c4e2e-agent: secure structured data transfer agent."""

__version__ = "1.0.0"
