"""Wire protocol for c4e2e transport layer.

Wire format per message:
    [1 byte : MessageType]
    [4 bytes BE uint32 : payload length]
    [N bytes : JSON payload]
"""

from __future__ import annotations

import json
import struct
from dataclasses import dataclass, asdict
from enum import IntEnum
from typing import Any


class ProtocolError(Exception):
    pass


class MessageType(IntEnum):
    HELLO           = 0x01
    HELLO_ACK       = 0x02
    TRANSFER_INIT   = 0x10
    FRAGMENT        = 0x11
    TRANSFER_DONE   = 0x12
    TRANSFER_ACK    = 0x13
    WATCHTOWER_PING = 0x20
    ERROR           = 0xFF


_HEADER = struct.Struct("!BL")  # type (1), length (4)
_MAX_PAYLOAD = 64 * 1024 * 1024  # 64 MB hard cap per message


@dataclass
class Message:
    type: MessageType
    payload: bytes

    def to_dict(self) -> dict:
        return json.loads(self.payload)


def encode_message(msg: Message) -> bytes:
    if len(msg.payload) > _MAX_PAYLOAD:
        raise ProtocolError(f"payload exceeds {_MAX_PAYLOAD} bytes")
    return _HEADER.pack(int(msg.type), len(msg.payload)) + msg.payload


def decode_message(data: bytes) -> tuple[Message, bytes]:
    """Return (Message, remaining_bytes). Raises ProtocolError on malformed input."""
    if len(data) < _HEADER.size:
        raise ProtocolError("incomplete header")
    msg_type_raw, payload_len = _HEADER.unpack_from(data)
    if payload_len > _MAX_PAYLOAD:
        raise ProtocolError(f"declared payload {payload_len} exceeds limit")
    total = _HEADER.size + payload_len
    if len(data) < total:
        raise ProtocolError("incomplete payload")
    try:
        msg_type = MessageType(msg_type_raw)
    except ValueError:
        raise ProtocolError(f"unknown message type 0x{msg_type_raw:02x}")
    payload = data[_HEADER.size:total]
    return Message(type=msg_type, payload=payload), data[total:]


def _json_msg(msg_type: MessageType, obj: Any) -> Message:
    return Message(type=msg_type, payload=json.dumps(obj).encode())


# ------------------------------------------------------------------
# Typed message constructors
# ------------------------------------------------------------------

PROTOCOL_VERSION = 1


@dataclass
class Hello:
    version: int
    agent_id: str       # random UUID per session
    pubkey_b64: str     # sender's Ed25519 pubkey (base64)

    def to_message(self) -> Message:
        return _json_msg(MessageType.HELLO, asdict(self))

    @classmethod
    def from_message(cls, msg: Message) -> "Hello":
        d = msg.to_dict()
        return cls(**d)


@dataclass
class HelloAck:
    version: int
    agent_id: str
    pubkey_b64: str

    def to_message(self) -> Message:
        return _json_msg(MessageType.HELLO_ACK, asdict(self))

    @classmethod
    def from_message(cls, msg: Message) -> "HelloAck":
        return cls(**msg.to_dict())


@dataclass
class TransferInit:
    transfer_id: str        # UUID4
    filename: str
    total_size: int
    fragment_count: int
    frag_mode: str          # "none" | "payload" | "transport" | "both"
    sender_pubkey_b64: str  # Ed25519 pubkey — must be in receiver's trusted list
    timestamp_utc: str      # ISO8601 — replay detection

    def to_message(self) -> Message:
        return _json_msg(MessageType.TRANSFER_INIT, asdict(self))

    @classmethod
    def from_message(cls, msg: Message) -> "TransferInit":
        return cls(**msg.to_dict())


@dataclass
class Fragment:
    transfer_id: str
    index: int          # 0-based
    total: int
    data_b64: str       # base64-encoded bytes (c4e2e wire frame or raw chunk)
    hmac_b64: str       # HMAC-SHA256 over (transfer_id || index || total || raw_data)

    def to_message(self) -> Message:
        return _json_msg(MessageType.FRAGMENT, asdict(self))

    @classmethod
    def from_message(cls, msg: Message) -> "Fragment":
        return cls(**msg.to_dict())


@dataclass
class TransferDone:
    transfer_id: str
    total_fragments: int

    def to_message(self) -> Message:
        return _json_msg(MessageType.TRANSFER_DONE, asdict(self))

    @classmethod
    def from_message(cls, msg: Message) -> "TransferDone":
        return cls(**msg.to_dict())


@dataclass
class TransferAck:
    transfer_id: str
    success: bool
    error: str = ""

    def to_message(self) -> Message:
        return _json_msg(MessageType.TRANSFER_ACK, asdict(self))

    @classmethod
    def from_message(cls, msg: Message) -> "TransferAck":
        return cls(**msg.to_dict())


@dataclass
class ErrorMessage:
    code: str
    detail: str

    def to_message(self) -> Message:
        return _json_msg(MessageType.ERROR, asdict(self))

    @classmethod
    def from_message(cls, msg: Message) -> "ErrorMessage":
        return cls(**msg.to_dict())
