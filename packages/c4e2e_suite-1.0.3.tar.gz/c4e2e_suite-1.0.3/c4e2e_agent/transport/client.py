"""Asyncio TLS client for send-mode c4e2e agents."""

from __future__ import annotations

import asyncio
import logging
import ssl
from typing import Optional

from .protocol import Message, decode_message, encode_message
from .server import read_message, write_message

log = logging.getLogger(__name__)

_CONNECT_TIMEOUT = 15.0
_ACK_TIMEOUT = 60.0


class TransportClient:
    """Manages a single TLS connection to a remote receive agent."""

    def __init__(self, ssl_context: ssl.SSLContext) -> None:
        self._ssl = ssl_context
        self._reader: Optional[asyncio.StreamReader] = None
        self._writer: Optional[asyncio.StreamWriter] = None

    async def connect(self, host: str, port: int) -> None:
        self._reader, self._writer = await asyncio.wait_for(
            asyncio.open_connection(host, port, ssl=self._ssl),
            timeout=_CONNECT_TIMEOUT,
        )
        log.info("connected to %s:%d (TLS)", host, port)

    async def send_message(self, msg: Message) -> None:
        if self._writer is None:
            raise RuntimeError("not connected")
        await write_message(self._writer, msg)

    async def receive_message(self, timeout: float = _ACK_TIMEOUT) -> Message:
        if self._reader is None:
            raise RuntimeError("not connected")
        return await read_message(self._reader, timeout=timeout)

    async def close(self) -> None:
        if self._writer:
            try:
                self._writer.close()
                await self._writer.wait_closed()
            except Exception:
                pass
            self._writer = None
            self._reader = None
        log.debug("transport client closed")

    async def __aenter__(self) -> "TransportClient":
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()
