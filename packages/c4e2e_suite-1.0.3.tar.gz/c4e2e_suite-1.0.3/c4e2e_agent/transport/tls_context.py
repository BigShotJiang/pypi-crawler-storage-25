"""TLS context factory with auto-generated self-signed certificates.

Application-layer identity and trust are enforced by the c4e2e Ed25519
model; TLS here provides transport confidentiality and forward secrecy.
"""

from __future__ import annotations

import datetime
import logging
import os
import ssl
from pathlib import Path
from typing import Optional

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID

log = logging.getLogger(__name__)

# CHANGE BEFORE PUBLIC DEPLOYMENT: adjust cert validity to match policy
_CERT_VALID_DAYS = 3650  # 10 years; replace with shorter-lived certs for production PKI


def _generate_self_signed(cert_path: Path, key_path: Path) -> None:
    """Generate an ECDSA P-256 self-signed certificate and write PEM files."""
    key = ec.generate_private_key(ec.SECP256R1())
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "c4e2e"),
        x509.NameAttribute(NameOID.COMMON_NAME, "c4e2e-transport"),
    ])
    now = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + datetime.timedelta(days=_CERT_VALID_DAYS))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .sign(key, hashes.SHA256())
    )
    key_path.write_bytes(
        key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption(),
        )
    )
    key_path.chmod(0o600)
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    cert_path.chmod(0o644)
    log.info("generated self-signed TLS cert: %s", cert_path)


def get_or_create_server_context(cert_dir: Path) -> ssl.SSLContext:
    """Return a TLS server SSLContext, auto-generating a cert if absent."""
    cert_dir.mkdir(parents=True, exist_ok=True)
    cert_path = cert_dir / "server.crt"
    key_path = cert_dir / "server.key"

    if not cert_path.exists() or not key_path.exists():
        _generate_self_signed(cert_path, key_path)

    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(certfile=str(cert_path), keyfile=str(key_path))
    ctx.set_ciphers("ECDHE+AESGCM:ECDHE+CHACHA20")
    # OP_NO_SSLv2 was removed in Python 3.10; minimum_version already excludes SSL 2/3.
    # Use getattr so this works on Python 3.10+ and older versions alike.
    ctx.options |= getattr(ssl, "OP_NO_SSLv2", 0) | getattr(ssl, "OP_NO_SSLv3", 0)
    return ctx


def get_client_context(ca_cert: Optional[Path] = None) -> ssl.SSLContext:
    """Return a TLS client SSLContext.

    If ca_cert is provided, the server certificate is verified against it.
    Otherwise CERT_NONE is used — transport confidentiality is still provided,
    but transport-layer server identity is not verified; c4e2e Ed25519 trust
    handles application-layer identity.
    """
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.set_ciphers("ECDHE+AESGCM:ECDHE+CHACHA20")
    ctx.options |= getattr(ssl, "OP_NO_SSLv2", 0) | getattr(ssl, "OP_NO_SSLv3", 0)

    if ca_cert is not None:
        ctx.verify_mode = ssl.CERT_REQUIRED
        ctx.load_verify_locations(cafile=str(ca_cert))
    else:
        # c4e2e payload-layer trust is the authoritative identity check
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

    return ctx
