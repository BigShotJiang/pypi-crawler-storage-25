"""Asyncio TLS server for receive-mode c4e2e agents."""

from __future__ import annotations

import asyncio
import logging
import ssl
from pathlib import Path
from typing import Awaitable, Callable, Optional

from .protocol import (
    Message,
    MessageType,
    ErrorMessage,
    decode_message,
    encode_message,
)

log = logging.getLogger(__name__)

ConnectionHandler = Callable[[asyncio.StreamReader, asyncio.StreamWriter], Awaitable[None]]

_READ_CHUNK = 65536


class TransportServer:
    """Asyncio TLS server that dispatches accepted connections to a handler."""

    def __init__(
        self,
        host: str,
        port: int,
        ssl_context: ssl.SSLContext,
        handler: ConnectionHandler,
    ) -> None:
        self._host = host
        self._port = port
        self._ssl = ssl_context
        self._handler = handler
        self._server: Optional[asyncio.Server] = None

    async def start(self) -> None:
        self._server = await asyncio.start_server(
            self._dispatch,
            host=self._host,
            port=self._port,
            ssl=self._ssl,
        )
        addr = self._server.sockets[0].getsockname()
        log.info("transport server listening on %s:%s (TLS)", addr[0], addr[1])

    async def stop(self) -> None:
        if self._server:
            self._server.close()
            await self._server.wait_closed()
            log.info("transport server stopped")

    async def _dispatch(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        peer = writer.get_extra_info("peername", "<unknown>")
        log.info("accepted connection from %s", peer)
        try:
            await self._handler(reader, writer)
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("unhandled error in connection from %s", peer)
            try:
                err = ErrorMessage(code="INTERNAL_ERROR", detail="server error")
                writer.write(encode_message(err.to_message()))
                await writer.drain()
            except Exception:
                pass
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass
            log.info("closed connection from %s", peer)


async def read_message(reader: asyncio.StreamReader, timeout: float = 30.0) -> Message:
    """Read exactly one framed Message from the stream."""
    header_raw = await asyncio.wait_for(reader.readexactly(5), timeout=timeout)
    import struct
    _H = struct.Struct("!BL")
    _type, payload_len = _H.unpack(header_raw)
    if payload_len > 64 * 1024 * 1024:
        raise ValueError(f"payload {payload_len} exceeds limit")
    payload = await asyncio.wait_for(reader.readexactly(payload_len), timeout=timeout)
    msg, _ = decode_message(header_raw + payload)
    return msg


async def write_message(writer: asyncio.StreamWriter, msg: Message) -> None:
    writer.write(encode_message(msg))
    await writer.drain()
