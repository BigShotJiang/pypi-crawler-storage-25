"""Fragmentation engine for c4e2e payload and transport splits.

FragMode.PAYLOAD   — data split before encryption; each chunk independently encrypted
FragMode.TRANSPORT — data encrypted once, then ciphertext split into N transport chunks
FragMode.BOTH      — PAYLOAD split then each encrypted chunk is TRANSPORT-split
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import os
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, List

if TYPE_CHECKING:
    from c4e2e.node import Transmitter


class FragMode(str, Enum):
    NONE      = "none"
    PAYLOAD   = "payload"
    TRANSPORT = "transport"
    BOTH      = "both"


@dataclass
class RawFragment:
    """A single fragment ready for wrapping into a transport.Fragment message."""
    transfer_id: str
    index: int
    total: int
    data: bytes       # raw bytes (c4e2e frame or raw chunk depending on mode)
    hmac_bytes: bytes # HMAC-SHA256(frag_hmac_key, transfer_id||index||total||data)


def _compute_hmac(key: bytes, transfer_id: str, index: int, total: int, data: bytes) -> bytes:
    msg = (
        transfer_id.encode()
        + index.to_bytes(4, "big")
        + total.to_bytes(4, "big")
        + data
    )
    return hmac.new(key, msg, hashlib.sha256).digest()


def _split_bytes(data: bytes, n: int) -> List[bytes]:
    """Split data into exactly n roughly equal chunks."""
    if n <= 1:
        return [data]
    size = len(data)
    chunk_size = max(1, (size + n - 1) // n)
    return [data[i:i + chunk_size] for i in range(0, size, chunk_size)]


class Fragmenter:
    """Converts file bytes into a list of RawFragment objects.

    A fresh per-transfer HMAC key (32 random bytes) is generated for each
    call; the caller is responsible for transmitting this key to the receiver
    via the TRANSFER_INIT message (encrypted within the c4e2e payload).
    """

    def fragment(
        self,
        data: bytes,
        filename: str,
        n: int,
        mode: FragMode,
        transmitter: "Transmitter",
        recipient_pubkey_b64: str,
        transfer_id: str,
    ) -> tuple[bytes, List[RawFragment]]:
        """Return (frag_hmac_key, fragments).

        The frag_hmac_key MUST be included in the TRANSFER_INIT payload so
        the receiver can validate per-fragment HMACs.  It is generated fresh
        per transfer and never reused.
        """
        frag_hmac_key = os.urandom(32)

        if mode == FragMode.NONE or n <= 1:
            frame = self._encrypt_chunk(transmitter, data, filename, recipient_pubkey_b64, transfer_id, 0, 1)
            frag = self._make_fragment(frag_hmac_key, transfer_id, 0, 1, frame)
            return frag_hmac_key, [frag]

        if mode == FragMode.PAYLOAD:
            return frag_hmac_key, self._fragment_payload(
                frag_hmac_key, data, filename, n, transmitter, recipient_pubkey_b64, transfer_id
            )

        if mode == FragMode.TRANSPORT:
            return frag_hmac_key, self._fragment_transport(
                frag_hmac_key, data, filename, n, transmitter, recipient_pubkey_b64, transfer_id
            )

        if mode == FragMode.BOTH:
            return frag_hmac_key, self._fragment_both(
                frag_hmac_key, data, filename, n, transmitter, recipient_pubkey_b64, transfer_id
            )

        raise ValueError(f"unknown FragMode: {mode}")

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _encrypt_chunk(
        self,
        transmitter: "Transmitter",
        chunk: bytes,
        filename: str,
        recipient_pubkey_b64: str,
        transfer_id: str,
        chunk_index: int,
        chunk_total: int,
    ) -> bytes:
        import base64 as _b64
        from c4e2e.crypto import b64_to_pubkey

        recipient_pub = b64_to_pubkey(recipient_pubkey_b64)
        frame = transmitter.encrypt(
            name=filename,
            job={
                "data": _b64.b64encode(chunk).decode(),
                "size": len(chunk),
                "chunk_index": chunk_index,
                "chunk_total": chunk_total,
            },
            recipient_pubkey=recipient_pub,
            job_id=f"{transfer_id}-{chunk_index}",
        )
        recipient_pub.destroy()
        return frame

    def _make_fragment(
        self,
        key: bytes,
        transfer_id: str,
        index: int,
        total: int,
        data: bytes,
    ) -> RawFragment:
        return RawFragment(
            transfer_id=transfer_id,
            index=index,
            total=total,
            data=data,
            hmac_bytes=_compute_hmac(key, transfer_id, index, total, data),
        )

    def _fragment_payload(
        self,
        key: bytes,
        data: bytes,
        filename: str,
        n: int,
        transmitter: "Transmitter",
        recipient_pubkey_b64: str,
        transfer_id: str,
    ) -> List[RawFragment]:
        chunks = _split_bytes(data, n)
        total = len(chunks)
        fragments = []
        for i, chunk in enumerate(chunks):
            frame = self._encrypt_chunk(transmitter, chunk, filename, recipient_pubkey_b64, transfer_id, i, total)
            fragments.append(self._make_fragment(key, transfer_id, i, total, frame))
        return fragments

    def _fragment_transport(
        self,
        key: bytes,
        data: bytes,
        filename: str,
        n: int,
        transmitter: "Transmitter",
        recipient_pubkey_b64: str,
        transfer_id: str,
    ) -> List[RawFragment]:
        frame = self._encrypt_chunk(transmitter, data, filename, recipient_pubkey_b64, transfer_id, 0, 1)
        chunks = _split_bytes(frame, n)
        total = len(chunks)
        return [
            self._make_fragment(key, transfer_id, i, total, chunk)
            for i, chunk in enumerate(chunks)
        ]

    def _fragment_both(
        self,
        key: bytes,
        data: bytes,
        filename: str,
        n: int,
        transmitter: "Transmitter",
        recipient_pubkey_b64: str,
        transfer_id: str,
    ) -> List[RawFragment]:
        # Step 1: payload-split and encrypt each chunk
        payload_chunks = _split_bytes(data, n)
        payload_total = len(payload_chunks)
        frames = []
        for i, chunk in enumerate(payload_chunks):
            frame = self._encrypt_chunk(transmitter, chunk, filename, recipient_pubkey_b64, transfer_id, i, payload_total)
            frames.append(frame)

        # Step 2: transport-split each frame; flatten into a single sequence
        # The receiver reconstructs by knowing payload_total from TRANSFER_INIT
        result: List[RawFragment] = []
        global_index = 0
        # total fragments = sum of transport splits; use 2 transport splits per payload chunk
        transport_splits = max(1, n // payload_total) if payload_total > 0 else 1
        all_chunks: List[bytes] = []
        for frame in frames:
            all_chunks.extend(_split_bytes(frame, transport_splits))
        total = len(all_chunks)
        for i, chunk in enumerate(all_chunks):
            result.append(self._make_fragment(key, transfer_id, i, total, chunk))
        return result
