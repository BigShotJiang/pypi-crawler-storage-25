"""Fragment reassembly with bounded buffers, timeout, and replay protection.

Security invariants:
- MAX_BUFFER_BYTES enforced per session (anti-DoS)
- FRAGMENT_TIMEOUT_SECS enforced per session (anti-replay / stall)
- Per-fragment HMAC validated before adding to buffer
- transfer_id replay detected via ReassemblerManager seen-set
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import logging
import time
from typing import Dict, List, Optional, Set, TYPE_CHECKING

from .fragmenter import FragMode, RawFragment

if TYPE_CHECKING:
    from c4e2e.node import Receiver

log = logging.getLogger(__name__)


class ReassemblyError(Exception):
    pass


class HMACError(ReassemblyError):
    pass


class BufferOverflowError(ReassemblyError):
    pass


class TimeoutError(ReassemblyError):
    pass


class ReplayError(ReassemblyError):
    pass


MAX_BUFFER_BYTES = 256 * 1024 * 1024   # 256 MB hard cap per session
FRAGMENT_TIMEOUT_SECS = 120.0


class ReassemblerSession:
    """Holds received fragments for a single transfer until complete."""

    def __init__(self, transfer_id: str, total: int, frag_hmac_key: bytes) -> None:
        self.transfer_id = transfer_id
        self.total = total
        self._key = frag_hmac_key
        self._fragments: Dict[int, bytes] = {}
        self._buffer_bytes = 0
        self._created = time.monotonic()

    def add_fragment(self, frag: RawFragment) -> None:
        if time.monotonic() - self._created > FRAGMENT_TIMEOUT_SECS:
            raise TimeoutError(f"transfer {self.transfer_id} timed out")

        if frag.index in self._fragments:
            raise ReassemblyError(f"duplicate fragment index {frag.index}")

        if frag.total != self.total:
            raise ReassemblyError("fragment total mismatch")

        expected_hmac = _compute_hmac(self._key, frag.transfer_id, frag.index, frag.total, frag.data)
        if not hmac.compare_digest(expected_hmac, frag.hmac_bytes):
            raise HMACError(f"HMAC verification failed for fragment {frag.index}")

        if self._buffer_bytes + len(frag.data) > MAX_BUFFER_BYTES:
            raise BufferOverflowError(f"transfer {self.transfer_id} exceeds buffer limit")

        self._fragments[frag.index] = frag.data
        self._buffer_bytes += len(frag.data)

    def is_complete(self) -> bool:
        return len(self._fragments) == self.total

    def reassemble_raw(self) -> bytes:
        """Concatenate ordered fragments into raw bytes."""
        if not self.is_complete():
            raise ReassemblyError("transfer incomplete")
        return b"".join(self._fragments[i] for i in range(self.total))

    def reassemble(self, mode: FragMode, receiver: "Receiver") -> bytes:
        """Reassemble and decrypt according to the original fragmentation mode.

        Returns final plaintext bytes.
        """
        raw = self.reassemble_raw()

        if mode in (FragMode.NONE, FragMode.TRANSPORT):
            # Single c4e2e frame (no or only transport fragmentation)
            result = receiver.decrypt(raw, write_output=False)
            return base64.b64decode(result["job"]["data"])

        if mode == FragMode.PAYLOAD:
            # Each fragment is a separately encrypted c4e2e frame
            frames = [self._fragments[i] for i in range(self.total)]
            chunks = []
            for frame in frames:
                result = receiver.decrypt(frame, write_output=False)
                chunks.append(base64.b64decode(result["job"]["data"]))
            return b"".join(chunks)

        if mode == FragMode.BOTH:
            # Fragments are sub-chunks of encrypted frames; need to reconstruct frames first
            # The TRANSFER_INIT payload_chunk_total field tells us the number of encrypted frames
            # For now: concatenate all and attempt single decrypt (transport re-assembly)
            # Full BOTH reassembly requires metadata from TRANSFER_INIT (payload_total)
            # This is handled by the caller which passes payload_total separately
            result = receiver.decrypt(raw, write_output=False)
            return base64.b64decode(result["job"]["data"])

        raise ValueError(f"unknown FragMode: {mode}")


def _compute_hmac(key: bytes, transfer_id: str, index: int, total: int, data: bytes) -> bytes:
    msg = (
        transfer_id.encode()
        + index.to_bytes(4, "big")
        + total.to_bytes(4, "big")
        + data
    )
    return hmac.new(key, msg, hashlib.sha256).digest()


class ReassemblerManager:
    """Manages concurrent ReassemblerSession objects; enforces replay protection."""

    _SEEN_TTL = 86400  # 24 hours — transfer_id dedup window

    def __init__(self) -> None:
        self._sessions: Dict[str, ReassemblerSession] = {}
        self._seen: Dict[str, float] = {}  # transfer_id → timestamp
        self._cleanup_task: Optional[asyncio.Task] = None

    def start(self) -> None:
        self._cleanup_task = asyncio.get_event_loop().create_task(self._cleanup_loop())

    def stop(self) -> None:
        if self._cleanup_task:
            self._cleanup_task.cancel()

    def create(
        self,
        transfer_id: str,
        total_fragments: int,
        frag_hmac_key: bytes,
    ) -> ReassemblerSession:
        if transfer_id in self._seen:
            raise ReplayError(f"duplicate transfer_id: {transfer_id}")
        self._seen[transfer_id] = time.monotonic()
        session = ReassemblerSession(transfer_id, total_fragments, frag_hmac_key)
        self._sessions[transfer_id] = session
        return session

    def get(self, transfer_id: str) -> Optional[ReassemblerSession]:
        return self._sessions.get(transfer_id)

    def remove(self, transfer_id: str) -> None:
        self._sessions.pop(transfer_id, None)

    async def _cleanup_loop(self) -> None:
        while True:
            await asyncio.sleep(60)
            now = time.monotonic()
            expired = [
                tid for tid, sess in self._sessions.items()
                if now - sess._created > FRAGMENT_TIMEOUT_SECS
            ]
            for tid in expired:
                log.warning("dropping expired reassembly session: %s", tid)
                self._sessions.pop(tid, None)
            old_seen = [tid for tid, ts in self._seen.items() if now - ts > self._SEEN_TTL]
            for tid in old_seen:
                self._seen.pop(tid, None)
