"""MFA coordinator — runs all required authentication methods.

All configured methods must pass for authenticate() to return True.
Partial success is not accepted.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Dict, List, Optional

from .password import PasswordAuth
from .totp import TOTPAuth
from .hmac_challenge import HMACChallengeAuth
from .yubikey import YubiKeyAuth

log = logging.getLogger(__name__)


@dataclass
class AuthConfig:
    password_db: str
    totp_db: str
    hmac_key_path: Optional[str] = None
    yubikey_client_id: Optional[str] = None
    yubikey_api_key: Optional[str] = None
    yubikey_api_servers: Optional[List[str]] = None


class AuthenticationError(Exception):
    pass


class MFAAuthenticator:
    """Runs all required authentication methods for a given user."""

    def __init__(self, config: AuthConfig) -> None:
        self._password = PasswordAuth(config.password_db)
        self._totp = TOTPAuth(config.totp_db)
        self._hmac = HMACChallengeAuth(config.hmac_key_path)
        self._yubikey = YubiKeyAuth(
            client_id=config.yubikey_client_id,
            api_key=config.yubikey_api_key,
            api_servers=config.yubikey_api_servers,
        )

    def authenticate(
        self,
        user: str,
        required_methods: List[str],
        credentials: Dict[str, str],
    ) -> bool:
        """Return True iff all required_methods pass for user.

        credentials keys: "password", "totp", "hmac_response", "yubikey_otp"
        hmac_response should be hex-encoded bytes.
        """
        if not required_methods:
            raise AuthenticationError("no authentication methods configured for user")

        for method in required_methods:
            if method == "password":
                password = credentials.get("password", "")
                if not self._password.verify(user, password):
                    log.warning("password auth failed for user: %s", user)
                    return False

            elif method == "totp":
                code = credentials.get("totp", "")
                if not self._totp.verify(user, code):
                    log.warning("TOTP auth failed for user: %s", user)
                    return False

            elif method == "hmac":
                response_hex = credentials.get("hmac_response", "")
                try:
                    response_bytes = bytes.fromhex(response_hex)
                except ValueError:
                    log.warning("invalid HMAC response encoding for user: %s", user)
                    return False
                if not self._hmac.verify_response(user, response_bytes):
                    log.warning("HMAC challenge auth failed for user: %s", user)
                    return False

            elif method == "yubikey":
                otp = credentials.get("yubikey_otp", "")
                if not self._yubikey.verify(user, otp):
                    log.warning("YubiKey auth failed for user: %s", user)
                    return False

            else:
                raise AuthenticationError(f"unknown auth method: {method}")

        log.info("authentication succeeded for user: %s (methods: %s)", user, required_methods)
        return True

    @property
    def password_auth(self) -> PasswordAuth:
        return self._password

    @property
    def totp_auth(self) -> TOTPAuth:
        return self._totp

    @property
    def hmac_auth(self) -> HMACChallengeAuth:
        return self._hmac
