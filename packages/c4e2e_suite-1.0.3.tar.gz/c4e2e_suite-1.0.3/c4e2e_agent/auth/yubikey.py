"""YubiKey OTP authentication.

This module is a pluggable stub. It requires:
  - yubico-client installed (pip install yubico-client)
  - yubikey_client_id and yubikey_api_key set in daemon auth config
  - (Optional) yubikey_api_servers for private validation servers

Without these configured, calling verify() raises ConfigurationError.
YubiKey validation requires outbound HTTPS to Yubico servers (or a private
YubiCloud deployment); this is not suitable for airgapped environments.

For airgapped environments, use TOTP or HMAC challenge-response instead.
"""

from __future__ import annotations

import logging
from typing import Optional

log = logging.getLogger(__name__)


class ConfigurationError(Exception):
    pass


class YubiKeyAuth:
    # CHANGE BEFORE PUBLIC DEPLOYMENT:
    # Set yubikey_client_id and yubikey_api_key in daemon auth config.
    # Ensure outbound HTTPS to api.yubico.com is permitted, or configure
    # yubikey_api_servers pointing to a private YubiCloud.

    def __init__(
        self,
        client_id: Optional[str] = None,
        api_key: Optional[str] = None,
        api_servers: Optional[list] = None,
    ) -> None:
        self._client_id = client_id
        self._api_key = api_key
        self._api_servers = api_servers

    def _require_configured(self) -> None:
        if not self._client_id or not self._api_key:
            raise ConfigurationError(
                "YubiKey auth is not configured. "
                "Set auth.yubikey_client_id and auth.yubikey_api_key in daemon config."
            )

    def verify(self, user: str, otp: str) -> bool:
        """Verify a YubiKey OTP. Requires network access to Yubico validation servers."""
        self._require_configured()
        try:
            import yubico_client
        except ImportError:
            raise ConfigurationError(
                "yubico-client is not installed. Run: pip install yubico-client"
            )

        client = yubico_client.Yubico(
            self._client_id,
            self._api_key,
            api_urls=self._api_servers or None,
        )
        try:
            return client.verify(otp)
        except yubico_client.yubico_exceptions.StatusCodeError as exc:
            log.warning("YubiKey verification failed for user %s: %s", user, exc)
            return False
        except Exception:
            log.exception("YubiKey verification error for user %s", user)
            return False
