"""Argon2id password authentication.

Password hashes are stored in a JSON file at auth_config.password_db.
File permissions must be 0600 (enforced on write; verified on load).
"""

from __future__ import annotations

import json
import logging
import os
import stat
from pathlib import Path
from typing import Dict

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError, InvalidHashError

log = logging.getLogger(__name__)

_ph = PasswordHasher(
    time_cost=3,
    memory_cost=65536,   # 64 MB
    parallelism=2,
    hash_len=32,
    salt_len=16,
)


class PasswordAuthError(Exception):
    pass


class PasswordAuth:
    """Verifies user passwords against argon2id hashes stored on disk."""

    def __init__(self, db_path: str) -> None:
        self._path = Path(db_path)

    def _load(self) -> Dict[str, str]:
        if not self._path.exists():
            return {}
        # CHANGE BEFORE PUBLIC DEPLOYMENT: ensure DB file is owned by c4e2e system user
        file_stat = self._path.stat()
        if file_stat.st_mode & (stat.S_IRWXG | stat.S_IRWXO):
            raise PasswordAuthError(f"password DB {self._path} has unsafe permissions")
        return json.loads(self._path.read_text())

    def _save(self, db: Dict[str, str]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(json.dumps(db, indent=2))
        self._path.chmod(0o600)

    def verify(self, user: str, password: str) -> bool:
        db = self._load()
        stored_hash = db.get(user)
        if stored_hash is None:
            # Constant-time rejection: run a dummy verify to avoid user enumeration
            try:
                _ph.verify("$argon2id$v=19$m=65536,t=3,p=2$AAAA$BBBB", "dummy")
            except Exception:
                pass
            return False
        try:
            _ph.verify(stored_hash, password)
            if _ph.check_needs_rehash(stored_hash):
                self.set_password(user, password)
            return True
        except (VerifyMismatchError, VerificationError, InvalidHashError):
            return False

    def set_password(self, user: str, password: str) -> None:
        """Hash and store a user password. Admin-only operation."""
        db = self._load()
        db[user] = _ph.hash(password)
        self._save(db)
        log.info("password updated for user: %s", user)

    def delete_user(self, user: str) -> None:
        db = self._load()
        db.pop(user, None)
        self._save(db)
