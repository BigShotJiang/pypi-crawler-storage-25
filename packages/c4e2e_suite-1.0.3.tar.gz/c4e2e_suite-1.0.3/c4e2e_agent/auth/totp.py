"""TOTP (RFC 6238) authentication using pyotp.

Per-user TOTP secrets are stored in a JSON file at auth_config.totp_db.
Secrets are base32-encoded and stored at rest; the file must be 0600.
"""

from __future__ import annotations

import json
import logging
import os
import stat
from pathlib import Path
from typing import Dict

import pyotp

log = logging.getLogger(__name__)


class TOTPAuthError(Exception):
    pass


class TOTPAuth:
    """Verifies TOTP codes for enrolled users."""

    def __init__(self, db_path: str) -> None:
        self._path = Path(db_path)

    def _load(self) -> Dict[str, str]:
        if not self._path.exists():
            return {}
        file_stat = self._path.stat()
        if file_stat.st_mode & (stat.S_IRWXG | stat.S_IRWXO):
            raise TOTPAuthError(f"TOTP DB {self._path} has unsafe permissions")
        return json.loads(self._path.read_text())

    def _save(self, db: Dict[str, str]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(json.dumps(db, indent=2))
        self._path.chmod(0o600)

    def verify(self, user: str, code: str) -> bool:
        """Return True if code is a valid current TOTP for user."""
        db = self._load()
        secret = db.get(user)
        if secret is None:
            return False
        totp = pyotp.TOTP(secret)
        return totp.verify(code, valid_window=1)

    def enroll(self, user: str) -> str:
        """Generate a new TOTP secret for user. Returns otpauth:// URI for QR scan."""
        secret = pyotp.random_base32()
        db = self._load()
        db[user] = secret
        self._save(db)
        totp = pyotp.TOTP(secret)
        uri = totp.provisioning_uri(name=user, issuer_name="c4e2e")
        log.info("TOTP enrolled for user: %s", user)
        return uri

    def revoke(self, user: str) -> None:
        db = self._load()
        db.pop(user, None)
        self._save(db)
