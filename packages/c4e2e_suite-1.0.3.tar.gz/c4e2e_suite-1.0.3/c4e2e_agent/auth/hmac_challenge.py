"""HMAC challenge-response authentication.

This module is a pluggable stub. It is wired into the MFA framework but
requires explicit configuration (hmac_key_path) before use. Attempting to
use it without configuration raises ConfigurationError.

Protocol:
  1. Server generates a 32-byte random challenge and sends it to the client.
  2. Client computes HMAC-SHA256(shared_key, challenge) and returns the digest.
  3. Server verifies the response.

The shared key is a per-user secret stored in a file referenced by hmac_key_path.
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import os
from pathlib import Path
from typing import Dict, Optional

log = logging.getLogger(__name__)

_CHALLENGE_BYTES = 32


class ConfigurationError(Exception):
    pass


class HMACChallengeAuth:
    # CHANGE BEFORE PUBLIC DEPLOYMENT: set hmac_key_path in daemon auth config
    def __init__(self, key_store_path: Optional[str] = None) -> None:
        self._key_store = Path(key_store_path) if key_store_path else None
        self._pending_challenges: Dict[str, bytes] = {}

    def _require_configured(self) -> None:
        if self._key_store is None:
            raise ConfigurationError(
                "HMAC challenge auth is not configured. "
                "Set auth.hmac_key_path in daemon config before use."
            )

    def _load_user_key(self, user: str) -> bytes:
        self._require_configured()
        key_path = self._key_store / f"{user}.key"
        if not key_path.exists():
            raise ConfigurationError(f"no HMAC key registered for user: {user}")
        return key_path.read_bytes()

    def generate_challenge(self, user: str) -> bytes:
        """Generate a fresh 32-byte challenge for user. Store pending for verify."""
        self._require_configured()
        challenge = os.urandom(_CHALLENGE_BYTES)
        self._pending_challenges[user] = challenge
        return challenge

    def verify_response(self, user: str, response: bytes) -> bool:
        """Verify HMAC-SHA256(user_key, challenge) == response."""
        self._require_configured()
        challenge = self._pending_challenges.pop(user, None)
        if challenge is None:
            log.warning("HMAC: no pending challenge for user %s", user)
            return False
        user_key = self._load_user_key(user)
        expected = hmac.new(user_key, challenge, hashlib.sha256).digest()
        return hmac.compare_digest(expected, response)

    def register_user_key(self, user: str, key_bytes: bytes) -> None:
        """Store a raw 32-byte HMAC key for a user. Admin-only operation."""
        self._require_configured()
        if len(key_bytes) != 32:
            raise ValueError("HMAC key must be exactly 32 bytes")
        key_path = self._key_store / f"{user}.key"
        self._key_store.mkdir(parents=True, exist_ok=True)
        key_path.write_bytes(key_bytes)
        key_path.chmod(0o600)
        log.info("HMAC key registered for user: %s", user)
