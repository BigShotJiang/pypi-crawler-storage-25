"""c4e2e — user-facing CLI for secure structured data transfer.

When the daemon IPC socket is reachable, all operations are routed through
the daemon (policy enforcement + MFA).  In --standalone mode (or when the
daemon is not running) the agent executes operations directly.

Usage examples:
    c4e2e -r WebServer-01 test.txt
    c4e2e -r 192.168.1.233 -P 6080 test.txt
    c4e2e -r WebServer-01 -frag 8 +tp test.txt
    c4e2e -r WebServer-01 --wrap data.json
    c4e2e -r WebServer-01 -w 5 test.txt
    c4e2e -r WebServer-01 --kill test.txt
"""

from __future__ import annotations

import argparse
import asyncio
import getpass
import json
import logging
import os
import sys
from pathlib import Path
from typing import List, Optional

log = logging.getLogger(__name__)

_DEFAULT_SOCKET = "/run/c4e2e/daemon.sock"
_DEFAULT_PORT   = 6080


def _parse_frag_mode(args: argparse.Namespace) -> str:
    """Derive fragmentation mode string from positional +p/+t/+tp flags."""
    return getattr(args, "frag_mode", "none") or "none"


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="c4e2e",
        description="Secure structured data transfer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        prefix_chars="-+",
    )
    p.add_argument("-r", "--recipient", required=False,
                   help="profile name, hostname, or IP address")
    p.add_argument("-P", "--port", type=int, default=None,
                   help="port override (default: from profile or 6080)")
    p.add_argument("-frag", "--frag", type=int, default=1, dest="frag_count",
                   help="number of fragments (default: 1, no fragmentation)")
    p.add_argument("+p", dest="frag_mode", action="store_const", const="payload",
                   default="none", help="payload fragmentation")
    p.add_argument("+t", dest="frag_mode", action="store_const", const="transport",
                   help="transport fragmentation")
    p.add_argument("+tp", dest="frag_mode", action="store_const", const="both",
                   help="payload + transport fragmentation")
    p.add_argument("--blind", action="store_true",
                   help="use ephemeral session (no persistent identity for this transfer)")
    p.add_argument("-w", "--watchtower", type=int, default=0, metavar="MINUTES",
                   help="keep agent alive N minutes after transfer completes")
    p.add_argument("--kill", action="store_true",
                   help="fire-and-forget: do not wait for ACK from receiver")
    p.add_argument("-j", "--jail", action="store_true",
                   help="jail incoming responses (receiver-side)")
    p.add_argument("-je", "--jail-except", metavar="PROFILE",
                   help="jail exception: do not jail from this profile")
    p.add_argument("--wrap", action="store_true",
                   help="wrap file in c4e2e JSON envelope before sending")
    p.add_argument("--standalone", action="store_true",
                   help="bypass daemon, run agent directly (no policy enforcement)")
    p.add_argument("--daemon-socket", default=_DEFAULT_SOCKET,
                   help=f"IPC socket path (default: {_DEFAULT_SOCKET})")
    p.add_argument("--log-level", default="WARNING")

    sub = p.add_subparsers(dest="command")

    # keygen subcommand
    kg = sub.add_parser("keygen", help="generate a new c4e2e keypair")
    kg.add_argument("--out-dir", default=".", help="directory for key files")
    kg.add_argument("--password", action="store_true", help="encrypt private key")

    # profile subcommands
    prof = sub.add_parser("profile", help="manage profiles")
    prof_sub = prof.add_subparsers(dest="profile_cmd")
    prof_sub.add_parser("list", help="list profiles")
    pa = prof_sub.add_parser("add", help="add a profile from YAML file")
    pa.add_argument("file", help="YAML profile file")
    pd = prof_sub.add_parser("delete", help="delete a profile")
    pd.add_argument("name")

    # jail subcommands
    jail = sub.add_parser("jail", help="manage jailed files")
    jail_sub = jail.add_subparsers(dest="jail_cmd")
    jl = jail_sub.add_parser("list", help="list jailed files")
    jl.add_argument("--sender", default=None)
    jr = jail_sub.add_parser("release", help="release a jailed file")
    jr.add_argument("path", help="path to .jaild file")
    jd = jail_sub.add_parser("destroy", help="destroy a jailed file")
    jd.add_argument("path")

    # status
    sub.add_parser("status", help="show daemon status")

    # Positional file argument (for send mode) — dest differs from subcommand 'file' args
    p.add_argument("send_file", nargs="?", metavar="FILE", help="file to send")

    return p


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level.upper(), logging.WARNING),
        format="%(asctime)s %(levelname)s: %(message)s",
    )

    # Handle subcommands that don't require a recipient
    if args.command == "keygen":
        _cmd_keygen(args)
        return
    if args.command == "profile":
        _cmd_profile(args)
        return
    if args.command == "jail":
        _cmd_jail(args)
        return
    if args.command == "status":
        _cmd_status(args)
        return

    # Default: send a file
    if not args.recipient:
        parser.print_help()
        sys.exit(1)
    if not args.send_file:
        print("error: file argument required for send operation", file=sys.stderr)
        sys.exit(1)

    filepath = Path(args.send_file)
    if not filepath.exists():
        print(f"error: file not found: {filepath}", file=sys.stderr)
        sys.exit(1)

    asyncio.run(_cmd_send(args, filepath))


# ------------------------------------------------------------------
# Send
# ------------------------------------------------------------------

async def _cmd_send(args: argparse.Namespace, filepath: Path) -> None:
    frag_mode = _parse_frag_mode(args)
    frag_count = args.frag_count
    watchtower_secs = (args.watchtower or 0) * 60

    if not args.standalone and _daemon_socket_exists(args.daemon_socket):
        await _send_via_daemon(args, filepath, frag_mode, frag_count, watchtower_secs)
    else:
        await _send_standalone(args, filepath, frag_mode, frag_count, watchtower_secs)


async def _send_via_daemon(
    args: argparse.Namespace,
    filepath: Path,
    frag_mode: str,
    frag_count: int,
    watchtower_secs: int,
) -> None:
    from c4e2e_daemon.ipc.client import IPCClient
    from c4e2e_daemon.ipc.protocol import SendRequest, AuthRequest, IPCMessageType

    recipient = args.recipient
    port = args.port

    # Collect credentials interactively
    credentials = _collect_credentials_interactive()

    async with IPCClient(args.daemon_socket) as client:
        # Authenticate
        auth_req = AuthRequest(
            user=_current_user(),
            profile=recipient,
            credentials=credentials,
        )
        auth_resp = await client.request(auth_req)
        if not auth_resp.get("success"):
            print(f"Authentication failed: {auth_resp.get('error', 'denied')}", file=sys.stderr)
            sys.exit(1)

        # Send request
        data = filepath.read_bytes()
        if args.wrap:
            data = _wrap_as_json(data, filepath.name)

        send_req = SendRequest(
            filepath=str(filepath.absolute()),
            recipient=recipient,
            frag_count=frag_count,
            frag_mode=frag_mode,
            watchtower_secs=watchtower_secs,
            jail_response=args.jail,
            kill=args.kill,
        )
        result = await client.request(send_req)
        if result.get("success"):
            print(f"Sent {filepath.name}: {result.get('bytes_sent', 0)} bytes")
        else:
            print(f"Send failed: {result.get('error', 'unknown')}", file=sys.stderr)
            sys.exit(1)


async def _send_standalone(
    args: argparse.Namespace,
    filepath: Path,
    frag_mode: str,
    frag_count: int,
    watchtower_secs: int,
) -> None:
    """Send directly using a local profile config file (no daemon)."""
    from .agent import SendAgent, AgentProfile
    from .fragmentation.fragmenter import FragMode

    profile_path = _find_profile(args.recipient)
    if profile_path is None:
        host, port = _parse_host_port(args.recipient, args.port)
        print(
            "error: no profile found for recipient. "
            "In standalone mode, a profile YAML file is required.",
            file=sys.stderr,
        )
        sys.exit(1)

    import yaml
    with open(profile_path) as f:
        pd = yaml.safe_load(f)

    port = args.port or int(pd.get("port", _DEFAULT_PORT))
    profile = AgentProfile(
        name=pd.get("name", args.recipient),
        host=pd["host"],
        port=port,
        identity_key=os.path.expanduser(pd["identity_key"]),
        trusted_key=pd["trusted_key"],
        x25519_key=os.path.expanduser(pd.get("x25519_key", "")),
        watchtower=watchtower_secs,
        output_dir=pd.get("output_dir", "."),
        tls_cert_dir=pd.get("tls_cert_dir", os.path.expanduser("~/.config/c4e2e/tls")),
        tls_ca=pd.get("tls_ca"),
    )

    data = filepath.read_bytes()
    if args.wrap:
        data = _wrap_as_json(data, filepath.name)

    agent = SendAgent(profile)

    def on_progress(done: int, total: int) -> None:
        print(f"\r  {done}/{total} fragments sent", end="", flush=True)

    result = await agent.send(
        data=data,
        filename=filepath.name,
        frag_mode=FragMode(frag_mode),
        frag_count=frag_count,
        watchtower_secs=watchtower_secs,
        on_progress=on_progress,
    )
    print()
    if result.success:
        print(f"Sent {filepath.name}: {result.bytes_sent} bytes, {result.fragment_count} fragments")
    else:
        print(f"Send failed: {result.error}", file=sys.stderr)
        sys.exit(1)


# ------------------------------------------------------------------
# Subcommand handlers
# ------------------------------------------------------------------

def _cmd_keygen(args: argparse.Namespace) -> None:
    from c4e2e import (
        keygen,
        export_ed25519_private_pem,
        pubkey_to_b64,
        generate_x25519_keypair,
        export_x25519_private_pem,
        x25519_pub_to_b64,
        derive_x25519_public,
    )

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    password: Optional[bytes] = None
    if args.password:
        password = getpass.getpass("Key encryption password: ").encode()

    priv, pub = keygen()
    priv_path = out_dir / "identity.pem"
    pub_path  = out_dir / "identity.pub"
    priv_path.write_bytes(export_ed25519_private_pem(priv, password=password))
    priv_path.chmod(0o600)
    pub_b64 = pubkey_to_b64(pub)
    pub_path.write_text(pub_b64 + "\n")

    x_priv, _ = generate_x25519_keypair()
    transport_path = out_dir / "transport.pem"
    transport_path.write_bytes(export_x25519_private_pem(x_priv, password=password))
    transport_path.chmod(0o600)
    with derive_x25519_public(x_priv) as x_pub:
        transport_pub_b64 = x25519_pub_to_b64(x_pub)

    print(f"Identity private key  -> {priv_path}")
    print(f"Identity public key   -> {pub_path}")
    print(f"Identity key (base64):\n    {pub_b64}")
    print()
    print(f"Transport private key -> {transport_path}")
    print(f"Transport public key (share with senders):\n    {transport_pub_b64}")


def _cmd_profile(args: argparse.Namespace) -> None:
    if args.profile_cmd == "list":
        profiles_dir = _default_profiles_dir()
        if not profiles_dir.exists():
            print("(no profiles)")
            return
        for f in sorted(profiles_dir.glob("*.yaml")):
            print(f.stem)

    elif args.profile_cmd == "add":
        import shutil
        profiles_dir = _default_profiles_dir()
        profiles_dir.mkdir(parents=True, exist_ok=True)
        src = Path(args.file)
        shutil.copy(src, profiles_dir / src.name)
        print(f"profile installed: {src.stem}")

    elif args.profile_cmd == "delete":
        profiles_dir = _default_profiles_dir()
        p = profiles_dir / f"{args.name}.yaml"
        if p.exists():
            p.unlink()
            print(f"profile deleted: {args.name}")
        else:
            print(f"profile not found: {args.name}", file=sys.stderr)


def _cmd_jail(args: argparse.Namespace) -> None:
    if args.jail_cmd == "list":
        asyncio.run(_jail_list_via_daemon(args))
    elif args.jail_cmd == "release":
        asyncio.run(_jail_action_via_daemon("release", args.path, args))
    elif args.jail_cmd == "destroy":
        asyncio.run(_jail_action_via_daemon("destroy", args.path, args))


async def _jail_list_via_daemon(args: argparse.Namespace) -> None:
    from c4e2e_daemon.ipc.client import IPCClient
    from c4e2e_daemon.ipc.protocol import JailListRequest
    async with IPCClient(args.daemon_socket) as client:
        req = JailListRequest(sender=getattr(args, "sender", None))
        result = await client.request(req)
        entries = result.get("entries", [])
        if not entries:
            print("(no jailed files)")
        for e in entries:
            print(e)


async def _jail_action_via_daemon(action: str, jail_path: str, args: argparse.Namespace) -> None:
    from c4e2e_daemon.ipc.client import IPCClient
    from c4e2e_daemon.ipc.protocol import JailActionRequest
    async with IPCClient(args.daemon_socket) as client:
        req = JailActionRequest(action=action, jail_path=jail_path)
        result = await client.request(req)
        if result.get("success"):
            if action == "release":
                out = result.get("output_path", "")
                print(f"released to: {out}")
            else:
                print("destroyed")
        else:
            print(f"error: {result.get('error', 'unknown')}", file=sys.stderr)


def _cmd_status(args: argparse.Namespace) -> None:
    asyncio.run(_status_via_daemon(args))


async def _status_via_daemon(args: argparse.Namespace) -> None:
    from c4e2e_daemon.ipc.client import IPCClient
    from c4e2e_daemon.ipc.protocol import StatusRequest
    if not _daemon_socket_exists(args.daemon_socket):
        print("daemon: not running")
        return
    try:
        async with IPCClient(args.daemon_socket) as client:
            result = await client.request(StatusRequest())
            print(f"daemon: running")
            print(f"  version:  {result.get('version', '?')}")
            print(f"  uptime:   {result.get('uptime_secs', '?')}s")
            print(f"  port:     {result.get('listen_port', '?')}")
            print(f"  profiles: {result.get('profile_count', '?')}")
    except Exception as exc:
        print(f"daemon: error ({exc})", file=sys.stderr)


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _daemon_socket_exists(socket_path: str) -> bool:
    return Path(socket_path).exists()


def _default_profiles_dir() -> Path:
    return Path(os.environ.get("C4E2E_PROFILES_DIR", os.path.expanduser("~/.config/c4e2e/profiles")))


def _find_profile(name: str) -> Optional[Path]:
    for d in [
        _default_profiles_dir(),
        Path("/etc/c4e2e/profiles"),
    ]:
        p = d / f"{name}.yaml"
        if p.exists():
            return p
    return None


def _parse_host_port(recipient: str, port_override: Optional[int]) -> tuple:
    if ":" in recipient:
        host, port_str = recipient.rsplit(":", 1)
        return host, int(port_str)
    return recipient, port_override or _DEFAULT_PORT


def _current_user() -> str:
    import pwd
    return pwd.getpwuid(os.getuid()).pw_name


def _collect_credentials_interactive() -> dict:
    """Prompt for password and optionally TOTP code."""
    creds: dict = {}
    password = getpass.getpass("Password: ")
    creds["password"] = password
    totp_env = os.environ.get("C4E2E_TOTP_CODE")
    if totp_env:
        creds["totp"] = totp_env
    else:
        totp = input("TOTP code (press Enter to skip): ").strip()
        if totp:
            creds["totp"] = totp
    return creds


def _wrap_as_json(data: bytes, filename: str) -> bytes:
    """Wrap binary data in a c4e2e JSON envelope."""
    import base64
    envelope = {
        "c4e2e_wrap": True,
        "filename": filename,
        "encoding": "base64",
        "data": base64.b64encode(data).decode(),
    }
    return json.dumps(envelope).encode()


if __name__ == "__main__":
    main()
