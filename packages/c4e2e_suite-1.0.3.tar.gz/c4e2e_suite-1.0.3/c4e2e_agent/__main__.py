"""c4e2e-agent standalone entry point."""

import argparse
import asyncio
import logging
import sys
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="c4e2e-agent",
        description="c4e2e standalone receive agent",
    )
    parser.add_argument("--config", required=True, help="path to agent YAML config")
    parser.add_argument(
        "--mode",
        choices=["receive"],
        default="receive",
        help="agent mode (currently only receive is supported standalone)",
    )
    parser.add_argument("--log-level", default="INFO", help="logging level")
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    from c4e2e_daemon.profile import ProfileManager
    from c4e2e_daemon.config import DaemonConfig
    from .agent import ReceiveAgent, AgentProfile
    import yaml

    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    agent_cfg = cfg.get("agent", cfg)
    profile = AgentProfile(
        name=agent_cfg.get("name", "standalone"),
        host=agent_cfg.get("host", "0.0.0.0"),
        port=int(agent_cfg.get("port", 6080)),
        identity_key=agent_cfg["identity_key"],
        trusted_key=agent_cfg["trusted_key"],
        x25519_key=agent_cfg.get("x25519_key"),
        watchtower=int(agent_cfg.get("watchtower", 0)),
        jail=bool(agent_cfg.get("jail", False)),
        output_dir=agent_cfg.get("output_dir", "."),
        tls_cert_dir=agent_cfg.get("tls_cert_dir", "/etc/c4e2e/tls"),
        tls_ca=agent_cfg.get("tls_ca"),
    )

    def on_receive(sender_pubkey_b64: str, filename: str, data: bytes) -> None:
        out = Path(profile.output_dir) / filename
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
        logging.getLogger(__name__).info("received %s (%d bytes)", filename, len(data))

    agent = ReceiveAgent(profile=profile, on_receive=on_receive)

    async def run() -> None:
        await agent.start_listening()
        logging.getLogger(__name__).info(
            "c4e2e-agent listening on %s:%d", profile.host, profile.port
        )
        try:
            await asyncio.Event().wait()
        except (KeyboardInterrupt, asyncio.CancelledError):
            pass
        finally:
            await agent.stop()

    asyncio.run(run())


if __name__ == "__main__":
    main()
