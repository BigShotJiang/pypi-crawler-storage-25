"""Interactive setup wizard for c4e2e-daemon.

Run via:  sudo c4e2e-daemon --setup
Re-runnable: detects existing config and offers to update it.
"""

from __future__ import annotations

import getpass
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import yaml


# ---------------------------------------------------------------------------
# Directory layout — (path, mode, owner, group)
# Created during _create_dirs(); all owned by c4e2e except /etc/c4e2e root.
# ---------------------------------------------------------------------------
_REQUIRED_DIRS: List[Tuple[str, int, str, str]] = [
    ("/etc/c4e2e",            0o755, "root",  "c4e2e"),
    ("/etc/c4e2e/auth",       0o700, "c4e2e", "c4e2e"),
    ("/etc/c4e2e/keys",       0o700, "c4e2e", "c4e2e"),
    ("/etc/c4e2e/tls",        0o700, "c4e2e", "c4e2e"),
    ("/etc/c4e2e/jail/keys",  0o700, "c4e2e", "c4e2e"),
    ("/etc/c4e2e/profiles",   0o750, "c4e2e", "c4e2e"),
    ("/var/c4e2e/received",   0o750, "c4e2e", "c4e2e"),
    ("/var/c4e2e/jail",       0o700, "c4e2e", "c4e2e"),
    ("/var/log/c4e2e",        0o750, "c4e2e", "c4e2e"),
]

_BANNER = """
c4e2e-daemon Setup Wizard
=========================
Configures c4e2e-daemon for first-time use or updates an existing installation.
Press Ctrl+C at any time to exit without saving.
"""


class SetupWizard:
    def __init__(self, config_path: str = "/etc/c4e2e/daemon.yaml") -> None:
        self._config_path = Path(config_path)
        self._mode = "basic"
        # Collected configuration values
        self._cfg: Dict = {}
        # List of (username, password, totp_uri) tuples
        self._new_users: List[Tuple[str, str, str]] = []
        # List of profile dicts
        self._new_profiles: List[Dict] = []
        # Per-user policy overrides
        self._policy: Dict[str, Dict] = {}

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def run(self) -> None:
        print(_BANNER)
        self._check_root()
        self._ensure_c4e2e_user()

        existing = self._config_path.exists()
        if existing:
            print(f"Existing configuration found at {self._config_path}")
            if not _ask_yes_no("Update existing configuration?", default=False):
                print("Setup aborted. No changes made.")
                return
            print()

        self._mode = self._ask_mode()
        print()

        if self._mode == "basic":
            self._collect_basic()
        else:
            self._collect_advanced()

        print("\n--- Review ---")
        self._print_summary()
        print()
        if not _ask_yes_no("Apply these settings?", default=True):
            print("Setup aborted. No changes made.")
            return

        self._apply()
        print("\nSetup complete.")
        self._print_next_steps()

    # ------------------------------------------------------------------
    # Pre-flight checks
    # ------------------------------------------------------------------

    def _check_root(self) -> None:
        if os.geteuid() != 0:
            print(
                "Error: c4e2e-daemon --setup must be run as root (or with sudo).",
                file=sys.stderr,
            )
            sys.exit(1)

    def _ensure_c4e2e_user(self) -> None:
        result = subprocess.run(["id", "-u", "c4e2e"], capture_output=True)
        if result.returncode != 0:
            print("Creating c4e2e system user...")
            subprocess.run(
                [
                    "adduser", "--system", "--group",
                    "--no-create-home", "--shell", "/usr/sbin/nologin",
                    "c4e2e",
                ],
                check=True,
            )

    # ------------------------------------------------------------------
    # Mode selection
    # ------------------------------------------------------------------

    def _ask_mode(self) -> str:
        print("Setup mode:")
        print("  1) Basic    — guided setup with recommended defaults (recommended)")
        print("  2) Advanced — full control over all options")
        while True:
            choice = input("Choice [1]: ").strip() or "1"
            if choice == "1":
                return "basic"
            if choice == "2":
                return "advanced"
            print("Please enter 1 or 2.")

    # ------------------------------------------------------------------
    # Collection flows
    # ------------------------------------------------------------------

    def _collect_basic(self) -> None:
        self._collect_network_basic()
        self._collect_keys()
        self._collect_tls_basic()
        self._collect_auth()
        self._collect_profiles()
        self._collect_policy_basic()

    def _collect_advanced(self) -> None:
        self._collect_network_advanced()
        self._collect_keys()
        self._collect_tls_advanced()
        self._collect_auth()
        self._collect_profiles()
        self._collect_policy_advanced()
        self._collect_jail_advanced()
        self._collect_logging_advanced()

    # ------------------------------------------------------------------
    # Network
    # ------------------------------------------------------------------

    def _collect_network_basic(self) -> None:
        print("--- Network ---")
        port = _prompt_int("Listen port", default=6080, min_val=1024, max_val=65535)
        self._cfg["listen_host"] = "0.0.0.0"
        self._cfg["listen_port"] = port

    def _collect_network_advanced(self) -> None:
        print("--- Network ---")
        print("Binding to a specific interface (e.g. 192.168.1.10) is more secure")
        print("than listening on all interfaces (0.0.0.0).")
        host = input("Listen host [0.0.0.0]: ").strip() or "0.0.0.0"
        port = _prompt_int("Listen port", default=6080, min_val=1024, max_val=65535)
        self._cfg["listen_host"] = host
        self._cfg["listen_port"] = port

    # ------------------------------------------------------------------
    # Identity keys
    # ------------------------------------------------------------------

    def _collect_keys(self) -> None:
        print("\n--- Identity Keys ---")
        key_dir = Path("/etc/c4e2e/keys")
        id_pem = key_dir / "identity.pem"
        tr_pem = key_dir / "transport.pem"

        if id_pem.exists() and tr_pem.exists():
            print(f"Existing keys found in {key_dir}")
            regen = _ask_yes_no(
                "Regenerate keypair? (existing keys will be overwritten — "
                "peers must re-register your new public key)",
                default=False,
            )
        else:
            regen = True

        if regen:
            self._generate_keypair(id_pem, tr_pem)

        self._cfg["identity_key"] = str(id_pem)
        self._cfg["x25519_key"] = str(tr_pem)

    def _generate_keypair(self, id_pem: Path, tr_pem: Path) -> None:
        print("Generating Ed25519 + X25519 keypair...")
        try:
            from c4e2e import (
                export_ed25519_private_pem,
                export_x25519_private_pem,
                get_ed25519_public_key_b64,
                get_x25519_public_key_b64,
                keygen,
            )
            pair = keygen()
            id_pem.write_bytes(export_ed25519_private_pem(pair))
            id_pem.chmod(0o600)
            tr_pem.write_bytes(export_x25519_private_pem(pair))
            tr_pem.chmod(0o600)
            _chown(id_pem, "c4e2e", "c4e2e")
            _chown(tr_pem, "c4e2e", "c4e2e")
            ed_pub = get_ed25519_public_key_b64(pair)
            x_pub = get_x25519_public_key_b64(pair)
            print(f"\n  Ed25519 public key (identity):  {ed_pub}")
            print(f"  X25519 public key (transport):  {x_pub}")
            print()
            print("  Save these public keys — share them with peers who need to trust you.")
        except ImportError:
            print(
                "Warning: c4e2e library not importable. Key generation skipped.",
                file=sys.stderr,
            )
            print(
                "Run 'c4e2e keygen' manually after install to generate keys.",
                file=sys.stderr,
            )

    # ------------------------------------------------------------------
    # TLS
    # ------------------------------------------------------------------

    def _collect_tls_basic(self) -> None:
        self._cfg["tls_auto_generate"] = True
        self._cfg["tls"] = {
            "cert": "/etc/c4e2e/tls/server.crt",
            "key": "/etc/c4e2e/tls/server.key",
        }

    def _collect_tls_advanced(self) -> None:
        print("\n--- TLS ---")
        print("Auto-generate creates a self-signed ECDSA P-256 certificate on first run.")
        print("For production, provide a cert from your own PKI instead.")
        auto = _ask_yes_no("Auto-generate self-signed TLS certificate?", default=True)
        self._cfg["tls_auto_generate"] = auto
        if auto:
            self._cfg["tls"] = {
                "cert": "/etc/c4e2e/tls/server.crt",
                "key": "/etc/c4e2e/tls/server.key",
            }
        else:
            cert = input("TLS certificate path: ").strip()
            key  = input("TLS private key path: ").strip()
            ca   = input("CA certificate path (for mTLS; leave blank to skip): ").strip()
            self._cfg["tls"] = {"cert": cert, "key": key}
            if ca:
                self._cfg["tls"]["ca"] = ca

    # ------------------------------------------------------------------
    # Authentication
    # ------------------------------------------------------------------

    def _collect_auth(self) -> None:
        print("\n--- Authentication ---")
        print("At least one user account is required to use the CLI.")
        self._collect_one_user()
        if self._mode == "advanced":
            while _ask_yes_no("Add another user?", default=False):
                self._collect_one_user()

    def _collect_one_user(self) -> None:
        while True:
            username = input("Username: ").strip()
            if username:
                break
            print("Username cannot be empty.")

        while True:
            pw  = getpass.getpass(f"Password for {username} (min 8 chars): ")
            pw2 = getpass.getpass("Confirm password: ")
            if pw != pw2:
                print("Passwords do not match. Try again.")
            elif len(pw) < 8:
                print("Password must be at least 8 characters.")
            else:
                break

        totp_uri = self._enroll_totp(username)
        self._new_users.append((username, pw, totp_uri))

    def _enroll_totp(self, username: str) -> str:
        try:
            from c4e2e_agent.auth.totp import TOTPAuth
            totp = TOTPAuth("/etc/c4e2e/auth/totp.json")
            uri = totp.enroll(username)
            print(f"\nTOTP enrolled for {username}.")
            print("Scan the URI below with Google Authenticator, Authy, or any RFC 6238 app:")
            print(f"\n  {uri}\n")
            input("Press Enter once you have scanned the code...")
            return uri
        except Exception as exc:
            print(f"Warning: TOTP enrollment failed ({exc}). Enroll manually later.", file=sys.stderr)
            return ""

    # ------------------------------------------------------------------
    # Profiles
    # ------------------------------------------------------------------

    def _collect_profiles(self) -> None:
        print("\n--- Profiles ---")
        print("Profiles describe remote peers you can send files to.")
        if not _ask_yes_no("Add a profile now?", default=True):
            return
        self._collect_one_profile()
        if self._mode == "advanced":
            while _ask_yes_no("Add another profile?", default=False):
                self._collect_one_profile()

    def _collect_one_profile(self) -> None:
        name = input("Profile name (e.g. webserver-01): ").strip()
        host = input("Remote host (hostname or IP): ").strip()
        port = _prompt_int("Remote port", default=6080, min_val=1024, max_val=65535)
        pubkey = input("Remote peer Ed25519 public key (base64): ").strip()

        profile: Dict = {
            "name": name,
            "host": host,
            "port": port,
            "trusted_key": pubkey,
            "identity_key": "/etc/c4e2e/keys/identity.pem",
            "x25519_key":   "/etc/c4e2e/keys/transport.pem",
            "required_auth": ["password", "totp"],
            "allowed_operations": ["send"],
            "priority": "P2",
        }

        if self._mode == "advanced":
            jail = _ask_yes_no(
                "Enable jail for files received from this peer? "
                "(re-encrypts files at rest)",
                default=False,
            )
            profile["jail"] = jail
            frag = _prompt_int(
                "Default fragment count (1 = no fragmentation)",
                default=1, min_val=1, max_val=100,
            )
            if frag > 1:
                profile["fragmentation"] = frag
                modes = {"1": "payload", "2": "transport", "3": "both"}
                print("Fragmentation mode:")
                print("  1) payload   — split before encryption")
                print("  2) transport — split after encryption")
                print("  3) both      — split before and after encryption")
                m = input("Mode [2]: ").strip() or "2"
                profile["frag_mode"] = modes.get(m, "transport")

        self._new_profiles.append(profile)

    # ------------------------------------------------------------------
    # Policy
    # ------------------------------------------------------------------

    def _collect_policy_basic(self) -> None:
        for user, _, _ in self._new_users:
            self._policy[user] = {
                "allowed_profiles": ["*"],
                "allowed_operations": ["send", "receive"],
                "max_payload_bytes": 0,
            }

    def _collect_policy_advanced(self) -> None:
        print("\n--- Policy ---")
        print("Per-user access controls. Leave blank to accept defaults.")
        for user, _, _ in self._new_users:
            print(f"\nPolicy for {user}:")
            ops_raw = (
                input("Allowed operations (comma-separated: send,receive) [send,receive]: ").strip()
                or "send,receive"
            )
            ops = [o.strip() for o in ops_raw.split(",") if o.strip()]
            max_bytes = _prompt_int("Max payload bytes (0 = unlimited)", default=0, min_val=0)
            self._policy[user] = {
                "allowed_profiles": ["*"],
                "allowed_operations": ops,
                "max_payload_bytes": max_bytes,
            }

    # ------------------------------------------------------------------
    # Advanced-only options
    # ------------------------------------------------------------------

    def _collect_jail_advanced(self) -> None:
        print("\n--- Jail Storage ---")
        base = (
            input("Jail file base directory [/var/c4e2e/jail]: ").strip()
            or "/var/c4e2e/jail"
        )
        key_store = (
            input("Jail key store directory [/etc/c4e2e/jail/keys]: ").strip()
            or "/etc/c4e2e/jail/keys"
        )
        self._cfg["jail"] = {"base_dir": base, "key_store": key_store}

    def _collect_logging_advanced(self) -> None:
        print("\n--- Logging ---")
        level = (input("Log level (DEBUG/INFO/WARNING/ERROR) [INFO]: ").strip().upper() or "INFO")
        if level not in ("DEBUG", "INFO", "WARNING", "ERROR"):
            level = "INFO"
        self._cfg["log_level"] = level

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------

    def _print_summary(self) -> None:
        host = self._cfg.get("listen_host", "0.0.0.0")
        port = self._cfg.get("listen_port", 6080)
        tls  = "auto-generated" if self._cfg.get("tls_auto_generate", True) else "custom"
        users    = ", ".join(u for u, _, _ in self._new_users) or "(none)"
        profiles = ", ".join(p["name"] for p in self._new_profiles) or "(none)"
        print(f"  Config path:  {self._config_path}")
        print(f"  Listen:       {host}:{port}")
        print(f"  Identity key: {self._cfg.get('identity_key', '/etc/c4e2e/keys/identity.pem')}")
        print(f"  TLS:          {tls}")
        print(f"  Users:        {users}")
        print(f"  Profiles:     {profiles}")

    # ------------------------------------------------------------------
    # Apply
    # ------------------------------------------------------------------

    def _apply(self) -> None:
        print("\nCreating directories...")
        self._create_dirs()
        print("Writing daemon configuration...")
        self._write_daemon_config()
        print("Writing access policy...")
        self._write_policy()
        print("Setting passwords...")
        self._apply_passwords()
        print("Writing profiles...")
        self._write_profiles()
        self._maybe_start_daemon()

    def _create_dirs(self) -> None:
        for path_str, mode, owner, group in _REQUIRED_DIRS:
            p = Path(path_str)
            p.mkdir(parents=True, exist_ok=True)
            p.chmod(mode)
            _chown(p, owner, group)

    def _write_daemon_config(self) -> None:
        cfg_data = {
            "listen_host": self._cfg.get("listen_host", "0.0.0.0"),
            "listen_port": self._cfg.get("listen_port", 6080),
            "identity_key": self._cfg.get("identity_key", "/etc/c4e2e/keys/identity.pem"),
            "x25519_key":   self._cfg.get("x25519_key",   "/etc/c4e2e/keys/transport.pem"),
            "ipc_socket":   "/run/c4e2e/daemon.sock",
            "profiles_dir": "/etc/c4e2e/profiles",
            "policy_file":  "/etc/c4e2e/policy.yaml",
            "output_dir":   "/var/c4e2e/received",
            "tls_auto_generate": self._cfg.get("tls_auto_generate", True),
            "tls": self._cfg.get("tls", {
                "cert": "/etc/c4e2e/tls/server.crt",
                "key":  "/etc/c4e2e/tls/server.key",
            }),
            "auth": {
                "password_db": "/etc/c4e2e/auth/passwords.json",
                "totp_db":     "/etc/c4e2e/auth/totp.json",
            },
            "jail": self._cfg.get("jail", {
                "base_dir":  "/var/c4e2e/jail",
                "key_store": "/etc/c4e2e/jail/keys",
            }),
            "log_file":  "/var/log/c4e2e/daemon.log",
            "log_level": self._cfg.get("log_level", "INFO"),
        }
        self._config_path.write_text(yaml.dump(cfg_data, default_flow_style=False, sort_keys=False))
        self._config_path.chmod(0o640)
        _chown(self._config_path, "c4e2e", "c4e2e")

    def _write_policy(self) -> None:
        policy_path = Path("/etc/c4e2e/policy.yaml")
        users_data: Dict = {}
        for user, _, _ in self._new_users:
            users_data[user] = self._policy.get(user, {
                "allowed_profiles": ["*"],
                "allowed_operations": ["send", "receive"],
                "max_payload_bytes": 0,
            })
        policy_path.write_text(
            yaml.dump({"users": users_data}, default_flow_style=False, sort_keys=False)
        )
        policy_path.chmod(0o640)
        _chown(policy_path, "c4e2e", "c4e2e")

    def _apply_passwords(self) -> None:
        try:
            from c4e2e_agent.auth.password import PasswordAuth
            pw_auth = PasswordAuth("/etc/c4e2e/auth/passwords.json")
            for user, pw, _ in self._new_users:
                pw_auth.set_password(user, pw)
                print(f"  Password set for {user}")
        except Exception as exc:
            print(f"Warning: could not set passwords: {exc}", file=sys.stderr)
            print("Run 'c4e2e-daemon setup-auth --user <user>' to set passwords manually.")

    def _write_profiles(self) -> None:
        profiles_dir = Path("/etc/c4e2e/profiles")
        for profile in self._new_profiles:
            name = profile["name"]
            prof_path = profiles_dir / f"{name}.yaml"
            prof_path.write_text(yaml.dump(profile, default_flow_style=False, sort_keys=False))
            prof_path.chmod(0o640)
            _chown(prof_path, "c4e2e", "c4e2e")
            print(f"  Profile written: {prof_path}")

    def _maybe_start_daemon(self) -> None:
        if not shutil.which("systemctl"):
            print(
                "\nSystemd not detected. Start the daemon manually:\n"
                "  c4e2e-daemon --config /etc/c4e2e/daemon.yaml"
            )
            return
        print()
        if _ask_yes_no("Enable and start c4e2e-daemon now?", default=True):
            subprocess.run(["systemctl", "daemon-reload"], check=False)
            subprocess.run(["systemctl", "enable", "c4e2e-daemon"], check=False)
            result = subprocess.run(["systemctl", "start", "c4e2e-daemon"])
            if result.returncode == 0:
                print("c4e2e-daemon started successfully.")
            else:
                print(
                    "c4e2e-daemon failed to start. Check logs with:\n"
                    "  journalctl -u c4e2e-daemon -n 50",
                    file=sys.stderr,
                )

    def _print_next_steps(self) -> None:
        print()
        print("Next steps:")
        print("  Check status:      systemctl status c4e2e-daemon")
        print("  View logs:         journalctl -u c4e2e-daemon -f")
        print("  Send a file:       c4e2e -r <profile-name> <file>")
        print("  Add a profile:     c4e2e profile add <name.yaml>")
        print("  Add a user:        sudo c4e2e-daemon setup-auth --user <name>")
        print("  Re-run wizard:     sudo c4e2e-daemon --setup")


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

def _ask_yes_no(prompt: str, default: bool = True) -> bool:
    suffix = " [Y/n]" if default else " [y/N]"
    try:
        answer = input(f"{prompt}{suffix} ").strip().lower()
    except EOFError:
        return default
    if not answer:
        return default
    return answer in ("y", "yes")


def _prompt_int(
    prompt: str,
    default: int,
    min_val: int = 0,
    max_val: int = 2 ** 31 - 1,
) -> int:
    while True:
        try:
            raw = input(f"{prompt} [{default}]: ").strip()
        except EOFError:
            return default
        if not raw:
            return default
        try:
            val = int(raw)
            if min_val <= val <= max_val:
                return val
            print(f"  Value must be between {min_val} and {max_val}.")
        except ValueError:
            print("  Please enter an integer.")


def _chown(path: Path, user: str, group: str) -> None:
    if shutil.which("chown"):
        subprocess.run(["chown", f"{user}:{group}", str(path)], check=False, capture_output=True)
