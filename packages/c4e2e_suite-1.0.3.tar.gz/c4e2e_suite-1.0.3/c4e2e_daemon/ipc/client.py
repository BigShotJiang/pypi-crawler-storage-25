"""IPC client for connecting to the c4e2e daemon from the CLI."""

from __future__ import annotations

import asyncio
import struct
from typing import Any, Dict, Optional

from .protocol import decode_ipc, encode_ipc


class IPCClientError(Exception):
    pass


class IPCClient:
    """Async context manager: sends one request, receives one response."""

    def __init__(self, socket_path: str, timeout: float = 120.0) -> None:
        self._path = socket_path
        self._timeout = timeout
        self._reader: Optional[asyncio.StreamReader] = None
        self._writer: Optional[asyncio.StreamWriter] = None

    async def __aenter__(self) -> "IPCClient":
        try:
            self._reader, self._writer = await asyncio.wait_for(
                asyncio.open_unix_connection(self._path),
                timeout=10.0,
            )
        except (FileNotFoundError, ConnectionRefusedError) as exc:
            raise IPCClientError(f"cannot connect to daemon at {self._path}: {exc}") from exc
        return self

    async def __aexit__(self, *_: object) -> None:
        if self._writer:
            try:
                self._writer.close()
                await self._writer.wait_closed()
            except Exception:
                pass

    async def request(self, req: Any) -> Dict[str, Any]:
        """Send a request object (must have .encode()) and return the response dict."""
        if self._writer is None:
            raise IPCClientError("not connected")
        self._writer.write(req.encode())
        await self._writer.drain()
        raw = await asyncio.wait_for(_read_response(self._reader), timeout=self._timeout)
        response, _ = decode_ipc(raw)
        return response


async def _read_response(reader: asyncio.StreamReader) -> bytes:
    header = await reader.readexactly(4)
    (length,) = struct.unpack("!L", header)
    if length > 16 * 1024 * 1024:
        raise ValueError(f"response too large: {length}")
    payload = await reader.readexactly(length)
    return header + payload
