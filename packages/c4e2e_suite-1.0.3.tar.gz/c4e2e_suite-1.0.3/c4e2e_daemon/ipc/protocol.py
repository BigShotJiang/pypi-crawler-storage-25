"""IPC protocol between the c4e2e CLI and the daemon.

Wire format:
    [4 bytes BE uint32: JSON length][JSON payload]

All messages are JSON dicts with a "type" field (IPCMessageType value as int).
"""

from __future__ import annotations

import json
import struct
from dataclasses import dataclass, asdict, field
from enum import IntEnum
from typing import Any, Dict, List, Optional


class IPCMessageType(IntEnum):
    AUTH_REQUEST    = 0x01
    AUTH_RESPONSE   = 0x02
    SEND_REQUEST    = 0x10
    SEND_PROGRESS   = 0x11
    SEND_COMPLETE   = 0x12
    JAIL_LIST       = 0x20
    JAIL_RELEASE    = 0x21
    JAIL_DESTROY    = 0x22
    PROFILE_LIST    = 0x30
    STATUS          = 0xF0
    ERROR           = 0xFF


_HEADER = struct.Struct("!L")
_MAX_IPC_PAYLOAD = 16 * 1024 * 1024  # 16 MB limit on IPC messages


def encode_ipc(obj: Any) -> bytes:
    payload = json.dumps(obj).encode()
    if len(payload) > _MAX_IPC_PAYLOAD:
        raise ValueError("IPC payload exceeds limit")
    return _HEADER.pack(len(payload)) + payload


def decode_ipc(data: bytes) -> tuple[dict, bytes]:
    if len(data) < _HEADER.size:
        raise ValueError("incomplete IPC header")
    (length,) = _HEADER.unpack_from(data)
    if length > _MAX_IPC_PAYLOAD:
        raise ValueError(f"IPC payload {length} exceeds limit")
    total = _HEADER.size + length
    if len(data) < total:
        raise ValueError("incomplete IPC payload")
    obj = json.loads(data[_HEADER.size:total])
    return obj, data[total:]


# ------------------------------------------------------------------
# Typed request/response dataclasses
# ------------------------------------------------------------------

@dataclass
class AuthRequest:
    user: str
    profile: str
    credentials: Dict[str, str]
    type: int = field(default=IPCMessageType.AUTH_REQUEST, init=False)

    def encode(self) -> bytes:
        return encode_ipc(asdict(self))


@dataclass
class SendRequest:
    filepath: str
    recipient: str
    frag_count: int = 1
    frag_mode: str = "none"
    watchtower_secs: int = 0
    jail_response: bool = False
    blind: bool = False
    kill: bool = False
    type: int = field(default=IPCMessageType.SEND_REQUEST, init=False)

    def encode(self) -> bytes:
        return encode_ipc(asdict(self))


@dataclass
class JailListRequest:
    sender: Optional[str] = None
    type: int = field(default=IPCMessageType.JAIL_LIST, init=False)

    def encode(self) -> bytes:
        return encode_ipc(asdict(self))


@dataclass
class JailActionRequest:
    action: str  # "release" | "destroy"
    jail_path: str
    output_dir: Optional[str] = None
    type: int = field(default=0, init=False)

    def __post_init__(self) -> None:
        if self.action == "release":
            self.type = IPCMessageType.JAIL_RELEASE
        else:
            self.type = IPCMessageType.JAIL_DESTROY

    def encode(self) -> bytes:
        return encode_ipc(asdict(self))


@dataclass
class ProfileListRequest:
    type: int = field(default=IPCMessageType.PROFILE_LIST, init=False)

    def encode(self) -> bytes:
        return encode_ipc(asdict(self))


@dataclass
class StatusRequest:
    type: int = field(default=IPCMessageType.STATUS, init=False)

    def encode(self) -> bytes:
        return encode_ipc(asdict(self))


@dataclass
class IPCResponse:
    success: bool
    type: int
    data: Dict[str, Any] = field(default_factory=dict)
    error: str = ""

    def encode(self) -> bytes:
        return encode_ipc(asdict(self))

    @classmethod
    def ok(cls, msg_type: IPCMessageType, **data: Any) -> "IPCResponse":
        return cls(success=True, type=int(msg_type), data=data)

    @classmethod
    def fail(cls, msg_type: IPCMessageType, error: str) -> "IPCResponse":
        return cls(success=False, type=int(msg_type), error=error, data={})
