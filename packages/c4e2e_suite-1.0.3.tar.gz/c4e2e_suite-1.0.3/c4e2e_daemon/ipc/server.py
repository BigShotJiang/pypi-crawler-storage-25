"""Unix domain socket IPC server for the c4e2e daemon.

The socket is created with 0600 permissions; only the daemon's owning
user can connect.  Each connection is handled as a single request/response
cycle (no persistent sessions).
"""

from __future__ import annotations

import asyncio
import logging
import os
import stat
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, Optional

from .protocol import decode_ipc, encode_ipc, IPCMessageType

log = logging.getLogger(__name__)

RequestHandler = Callable[[dict], Awaitable[dict]]


class IPCServer:
    """Asyncio Unix socket server dispatching JSON requests to a handler."""

    def __init__(self, socket_path: str, handler: RequestHandler) -> None:
        self._path = socket_path
        self._handler = handler
        self._server: Optional[asyncio.Server] = None

    async def start(self) -> None:
        socket_dir = Path(self._path).parent
        socket_dir.mkdir(parents=True, exist_ok=True)

        if Path(self._path).exists():
            Path(self._path).unlink()

        self._server = await asyncio.start_unix_server(
            self._dispatch,
            path=self._path,
        )
        # Restrict socket to owner only
        os.chmod(self._path, 0o600)
        log.info("IPC server listening on %s", self._path)

    async def stop(self) -> None:
        if self._server:
            self._server.close()
            await self._server.wait_closed()
        if Path(self._path).exists():
            Path(self._path).unlink(missing_ok=True)
        log.info("IPC server stopped")

    async def _dispatch(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        try:
            raw = await asyncio.wait_for(_read_ipc_message(reader), timeout=30.0)
            request, _ = decode_ipc(raw)
            response = await self._handler(request)
            writer.write(encode_ipc(response))
            await writer.drain()
        except asyncio.TimeoutError:
            log.warning("IPC connection timed out")
        except Exception:
            log.exception("IPC dispatch error")
            try:
                err = {"success": False, "error": "internal error", "type": int(IPCMessageType.ERROR)}
                writer.write(encode_ipc(err))
                await writer.drain()
            except Exception:
                pass
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass


async def _read_ipc_message(reader: asyncio.StreamReader) -> bytes:
    import struct
    header = await reader.readexactly(4)
    (length,) = struct.unpack("!L", header)
    if length > 16 * 1024 * 1024:
        raise ValueError(f"IPC message too large: {length}")
    payload = await reader.readexactly(length)
    return header + payload
