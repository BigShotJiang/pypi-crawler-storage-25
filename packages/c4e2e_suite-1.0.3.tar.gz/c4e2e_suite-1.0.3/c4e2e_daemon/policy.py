"""Policy engine for c4e2e-daemon.

Policy is loaded from a YAML file and evaluated per-request.
Supports hot-reload (call reload() after modifying the policy file).

Policy file format:
    users:
      alice:
        allowed_profiles: ["*"]
        allowed_operations: ["send", "receive"]
        max_payload_bytes: 0
      bob:
        allowed_profiles: ["WebServer-01"]
        allowed_operations: ["send"]
        max_payload_bytes: 104857600   # 100 MB
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List

import yaml

log = logging.getLogger(__name__)


@dataclass
class UserPolicy:
    allowed_profiles: List[str] = field(default_factory=lambda: ["*"])
    allowed_operations: List[str] = field(default_factory=lambda: ["send", "receive"])
    max_payload_bytes: int = 0   # 0 = unlimited


@dataclass
class PolicyDecision:
    allowed: bool
    reason: str


_DEFAULT_POLICY = UserPolicy()


class PolicyEngine:
    """Evaluates user+operation+profile against the loaded policy."""

    def __init__(self, policy_file: str) -> None:
        self._path = Path(policy_file)
        self._users: Dict[str, UserPolicy] = {}
        self._load()

    def _load(self) -> None:
        if not self._path.exists():
            log.warning("policy file not found, using permissive defaults: %s", self._path)
            self._users = {}
            return
        with open(self._path) as f:
            raw = yaml.safe_load(f) or {}
        users_raw = raw.get("users", {})
        self._users = {}
        for user, u_raw in users_raw.items():
            self._users[user] = UserPolicy(
                allowed_profiles=u_raw.get("allowed_profiles", ["*"]),
                allowed_operations=u_raw.get("allowed_operations", ["send", "receive"]),
                max_payload_bytes=int(u_raw.get("max_payload_bytes", 0)),
            )
        log.info("policy loaded: %d users", len(self._users))

    def reload(self) -> None:
        self._load()

    def evaluate(
        self,
        user: str,
        operation: str,
        profile_name: str,
        payload_bytes: int = 0,
    ) -> PolicyDecision:
        upolicy = self._users.get(user, _DEFAULT_POLICY)

        if operation not in upolicy.allowed_operations:
            return PolicyDecision(False, f"operation '{operation}' not permitted for user '{user}'")

        profiles = upolicy.allowed_profiles
        if profiles != ["*"] and profile_name not in profiles:
            return PolicyDecision(False, f"profile '{profile_name}' not permitted for user '{user}'")

        if upolicy.max_payload_bytes > 0 and payload_bytes > upolicy.max_payload_bytes:
            return PolicyDecision(
                False,
                f"payload {payload_bytes} exceeds limit {upolicy.max_payload_bytes} for user '{user}'",
            )

        return PolicyDecision(True, "allowed")
