"""Profile management for c4e2e-daemon."""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

import yaml

log = logging.getLogger(__name__)


class ProfileNotFoundError(Exception):
    pass


class ProfileError(Exception):
    pass


@dataclass
class Profile:
    name: str
    host: str
    port: int
    identity_key: str           # path to Ed25519 signing PEM (sender's identity)
    trusted_key: str            # base64 Ed25519 pubkey of trusted remote
    x25519_key: Optional[str] = None  # path to X25519 transport PEM (receive mode)
    watchtower: int = 0         # seconds; 0 = disabled
    jail: bool = False
    fragmentation: int = 1
    frag_mode: str = "none"     # "none" | "payload" | "transport" | "both"
    allowed_operations: List[str] = field(default_factory=lambda: ["send"])
    required_auth: List[str] = field(default_factory=lambda: ["password"])
    priority: str = "P2"        # used in jail filename (P1=high, P4=low)
    output_dir: str = "/var/c4e2e/received"
    tls_cert_dir: str = "/etc/c4e2e/tls"
    tls_ca: Optional[str] = None

    def resolve_identity_key(self) -> str:
        return os.path.expanduser(self.identity_key)

    def resolve_trusted_key(self) -> str:
        """Return base64 pubkey; if value is a file path, read the public key from it."""
        val = self.trusted_key.strip()
        p = Path(os.path.expanduser(val))
        if p.exists() and p.suffix in (".pub", ".pem"):
            return p.read_text().strip()
        return val


class ProfileManager:
    """Loads, saves, and enumerates profiles from a directory of YAML files."""

    def __init__(self, profiles_dir: str) -> None:
        self._dir = Path(profiles_dir)
        self._dir.mkdir(parents=True, exist_ok=True)

    def load(self, name: str) -> Profile:
        path = self._dir / f"{name}.yaml"
        if not path.exists():
            raise ProfileNotFoundError(f"profile not found: {name}")
        with open(path) as f:
            d = yaml.safe_load(f) or {}
        return _profile_from_dict(d)

    def save(self, profile: Profile) -> None:
        path = self._dir / f"{profile.name}.yaml"
        with open(path, "w") as f:
            yaml.dump(_profile_to_dict(profile), f, default_flow_style=False)
        log.info("saved profile: %s", profile.name)

    def list_profiles(self) -> List[str]:
        return sorted(p.stem for p in self._dir.glob("*.yaml"))

    def delete(self, name: str) -> None:
        path = self._dir / f"{name}.yaml"
        if not path.exists():
            raise ProfileNotFoundError(f"profile not found: {name}")
        path.unlink()
        log.info("deleted profile: %s", name)

    def resolve_host(self, profile: Profile) -> Tuple[str, int]:
        return profile.host, profile.port


def _profile_from_dict(d: dict) -> Profile:
    return Profile(
        name=d["name"],
        host=d["host"],
        port=int(d["port"]),
        identity_key=d["identity_key"],
        trusted_key=d["trusted_key"],
        x25519_key=d.get("x25519_key"),
        watchtower=int(d.get("watchtower", 0)),
        jail=bool(d.get("jail", False)),
        fragmentation=int(d.get("fragmentation", 1)),
        frag_mode=d.get("frag_mode", "none"),
        allowed_operations=d.get("allowed_operations", ["send"]),
        required_auth=d.get("required_auth", ["password"]),
        priority=d.get("priority", "P2"),
        output_dir=d.get("output_dir", "/var/c4e2e/received"),
        tls_cert_dir=d.get("tls_cert_dir", "/etc/c4e2e/tls"),
        tls_ca=d.get("tls_ca"),
    )


def _profile_to_dict(p: Profile) -> dict:
    return {
        "name": p.name,
        "host": p.host,
        "port": p.port,
        "identity_key": p.identity_key,
        "trusted_key": p.trusted_key,
        "x25519_key": p.x25519_key,
        "watchtower": p.watchtower,
        "jail": p.jail,
        "fragmentation": p.fragmentation,
        "frag_mode": p.frag_mode,
        "allowed_operations": p.allowed_operations,
        "required_auth": p.required_auth,
        "priority": p.priority,
        "output_dir": p.output_dir,
        "tls_cert_dir": p.tls_cert_dir,
        "tls_ca": p.tls_ca,
    }
