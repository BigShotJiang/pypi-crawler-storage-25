"""Jail manager for c4e2e-daemon.

Jailed payloads are re-encrypted with a per-transfer AES-256-GCM key
and stored in a protected directory structure.  The jail key is stored
in a separate key_store directory with 0600 permissions.  Neither the
key nor the plaintext is retained in process memory beyond the operation.

Jail file path format:
    <base_dir>/<sender>/<MMDDYYYY>/<HHMM>-<priority>.<ext>.jaild

Key sidecar (same directory, 0600):
    <base_dir>/<sender>/<MMDDYYYY>/<HHMM>-<priority>.<ext>.jaild.kid
    → contains the UUID key_id; the key itself lives in key_store/<key_id>.key

Example jail file:
    /var/c4e2e/jail/remote-01/05222026/0815-P1.bin.jaild

CHANGE BEFORE PUBLIC DEPLOYMENT:
    Replace key_store flat-file storage with an OS keyring, TPM-sealed blob,
    or HSM-backed key store.  The current flat-file approach is protected only
    by filesystem permissions.
"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from .config import JailConfig

log = logging.getLogger(__name__)

_KEY_BYTES  = 32
_NONCE_BYTES = 12
_TAG_BYTES  = 16


@dataclass
class JailEntry:
    sender: str
    date: str         # MMDDYYYY
    time: str         # HHMM
    priority: str     # P1–P4
    extension: str    # original file extension (without dot)
    path: Path        # full path to .jaild file
    key_id: str       # UUID — indexes the key file in key_store


class JailError(Exception):
    pass


class JailManager:
    """Encrypts incoming payloads into the jail directory."""

    def __init__(self, config: JailConfig) -> None:
        self._base = Path(config.base_dir)
        self._key_store = Path(config.key_store)
        self._base.mkdir(parents=True, exist_ok=True)
        self._key_store.mkdir(parents=True, exist_ok=True)
        self._key_store.chmod(0o700)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def jail_payload(
        self,
        sender: str,
        data: bytes,
        filename: str,
        priority: str = "P2",
    ) -> JailEntry:
        """Encrypt data under a fresh random key and store in jail directory."""
        import uuid as _uuid
        now = datetime.utcnow()
        date_str = now.strftime("%m%d%Y")
        time_str = now.strftime("%H%M")
        ext = Path(filename).suffix.lstrip(".") or "bin"

        jail_dir = self._base / _sanitize(sender) / date_str
        jail_dir.mkdir(parents=True, exist_ok=True)
        jail_dir.chmod(0o700)

        key_id = str(_uuid.uuid4())
        jail_key = os.urandom(_KEY_BYTES)
        try:
            ciphertext = _aes256gcm_encrypt(jail_key, data)
            jail_filename = f"{time_str}-{priority}.{ext}.jaild"
            jail_path = jail_dir / jail_filename
            jail_path.write_bytes(ciphertext)
            jail_path.chmod(0o600)

            # Key sidecar: stores key_id only; key bytes live in key_store
            sidecar = jail_path.with_suffix(".jaild.kid")
            sidecar.write_text(key_id)
            sidecar.chmod(0o600)

            # Persist the jail key (only needed for release/decrypt)
            key_path = self._key_store / f"{key_id}.key"
            key_path.write_bytes(jail_key)
            key_path.chmod(0o600)
        finally:
            _zeroize(jail_key)
            del jail_key

        entry = JailEntry(
            sender=_sanitize(sender),
            date=date_str,
            time=time_str,
            priority=priority,
            extension=ext,
            path=jail_path,
            key_id=key_id,
        )
        log.info("jailed: %s (sender: %s..., priority: %s)", jail_filename, sender[:12], priority)
        return entry

    def list_jailed(self, sender: Optional[str] = None) -> List[JailEntry]:
        search_base = self._base / _sanitize(sender) if sender else self._base
        entries = []
        for jaild in sorted(search_base.rglob("*.jaild")):
            entry = _parse_entry(jaild)
            if entry:
                entries.append(entry)
        return entries

    def release(self, entry: JailEntry) -> bytes:
        """Decrypt and return plaintext. Does NOT delete the jail file."""
        key_path = self._key_store / f"{entry.key_id}.key"
        if not key_path.exists():
            raise JailError(f"key not found for: {entry.path.name}")
        jail_key = key_path.read_bytes()
        try:
            return _aes256gcm_decrypt(jail_key, entry.path.read_bytes())
        except Exception as exc:
            raise JailError(f"release failed: {exc}") from exc
        finally:
            _zeroize(jail_key)
            del jail_key

    def destroy(self, entry: JailEntry) -> None:
        """Securely delete the jail file, its sidecar, and its key."""
        _secure_delete(entry.path)
        sidecar = entry.path.with_suffix(".jaild.kid")
        if sidecar.exists():
            sidecar.unlink(missing_ok=True)
        key_path = self._key_store / f"{entry.key_id}.key"
        _secure_delete(key_path)
        log.info("destroyed jail entry: %s", entry.path.name)


# ------------------------------------------------------------------
# AES-256-GCM helpers (uses Python cryptography library)
# ------------------------------------------------------------------

def _aes256gcm_encrypt(key: bytes, plaintext: bytes) -> bytes:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    nonce = os.urandom(_NONCE_BYTES)
    return nonce + AESGCM(key).encrypt(nonce, plaintext, None)


def _aes256gcm_decrypt(key: bytes, data: bytes) -> bytes:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    if len(data) < _NONCE_BYTES + _TAG_BYTES:
        raise JailError("ciphertext too short")
    nonce, body = data[:_NONCE_BYTES], data[_NONCE_BYTES:]
    try:
        return AESGCM(key).decrypt(nonce, body, None)
    except Exception as exc:
        raise JailError(f"decryption failed: {exc}") from exc


def _secure_delete(path: Path) -> None:
    """Overwrite with zeros before unlinking (best-effort; depends on filesystem)."""
    try:
        size = path.stat().st_size
        with open(path, "r+b") as f:
            f.write(b"\x00" * size)
            f.flush()
            os.fsync(f.fileno())
    except Exception:
        pass
    path.unlink(missing_ok=True)


def _zeroize(data: bytes) -> None:
    """Best-effort in-place zeroization of key material."""
    try:
        import ctypes
        ctypes.memset(id(data) + 33, 0, len(data))
    except Exception:
        pass


def _sanitize(name: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_\-.]", "_", name)[:64]


def _parse_entry(path: Path) -> Optional[JailEntry]:
    try:
        # path: <base>/<sender>/<MMDDYYYY>/<HHMM>-<priority>.<ext>.jaild
        parts = path.parts
        sender = parts[-3]
        date_str = parts[-2]
        name = path.name[:-6]  # strip ".jaild"
        time_part, rest = name.split("-", 1)
        priority, ext = rest.split(".", 1)
        sidecar = path.with_suffix(".jaild.kid")
        key_id = sidecar.read_text().strip() if sidecar.exists() else path.stem
        return JailEntry(
            sender=sender,
            date=date_str,
            time=time_part,
            priority=priority,
            extension=ext,
            path=path,
            key_id=key_id,
        )
    except Exception:
        return None
