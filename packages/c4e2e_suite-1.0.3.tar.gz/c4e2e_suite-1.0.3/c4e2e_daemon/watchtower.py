"""Watchtower timer management for c4e2e-daemon.

A watchtower timer keeps an agent session alive for N seconds after the
last transfer completes.  When the timer fires, the registered callback
is invoked (typically: stop the agent or close the connection).
"""

from __future__ import annotations

import asyncio
import logging
from typing import Callable, Dict, Optional

log = logging.getLogger(__name__)


class WatchtowerManager:
    """Manages per-agent countdown timers using asyncio Tasks."""

    def __init__(self) -> None:
        self._timers: Dict[str, asyncio.Task] = {}

    def schedule(
        self,
        agent_id: str,
        timeout_secs: int,
        callback: Callable[[], None],
    ) -> None:
        """Start or restart a watchtower timer for agent_id."""
        self.cancel(agent_id)
        self._timers[agent_id] = asyncio.get_event_loop().create_task(
            self._run(agent_id, timeout_secs, callback)
        )
        log.debug("watchtower set for %s: %ds", agent_id, timeout_secs)

    def reset(self, agent_id: str) -> None:
        """Reset the timer without changing the timeout or callback.

        Since we store the task but not the original args, callers that
        need reset must cancel and re-schedule with original parameters.
        This method cancels and removes the timer; the caller re-schedules.
        """
        self.cancel(agent_id)

    def cancel(self, agent_id: str) -> None:
        task = self._timers.pop(agent_id, None)
        if task and not task.done():
            task.cancel()

    def cancel_all(self) -> None:
        for agent_id in list(self._timers):
            self.cancel(agent_id)

    async def _run(
        self,
        agent_id: str,
        timeout_secs: int,
        callback: Callable[[], None],
    ) -> None:
        try:
            await asyncio.sleep(timeout_secs)
            log.info("watchtower fired for agent: %s", agent_id)
            try:
                callback()
            except Exception:
                log.exception("watchtower callback error for %s", agent_id)
        except asyncio.CancelledError:
            pass
        finally:
            self._timers.pop(agent_id, None)
