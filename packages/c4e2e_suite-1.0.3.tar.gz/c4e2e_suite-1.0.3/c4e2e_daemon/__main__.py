"""c4e2e-daemon entry point."""

import argparse
import asyncio
import logging
import sys


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="c4e2e-daemon",
        description="c4e2e secure transfer daemon",
    )
    parser.add_argument(
        "--config",
        default="/etc/c4e2e/daemon.yaml",
        help="path to daemon YAML config (default: /etc/c4e2e/daemon.yaml)",
    )
    parser.add_argument("--log-level", default=None, help="override log level")
    parser.add_argument(
        "--setup",
        action="store_true",
        help="run the interactive setup wizard (re-runnable; requires root)",
    )
    parser.add_argument(
        "command",
        nargs="?",
        choices=["start", "setup-auth"],
        default="start",
    )
    parser.add_argument(
        "--user",
        help="user name (for setup-auth)",
    )
    parser.add_argument(
        "--method",
        choices=["password", "totp"],
        help="auth method to set up (for setup-auth)",
    )
    args = parser.parse_args()

    if args.setup:
        from .setup import SetupWizard
        SetupWizard(config_path=args.config).run()
        return

    if args.command == "setup-auth":
        _cmd_setup_auth(args)
        return

    # Default: start daemon
    from .config import DaemonConfig
    from .daemon import C4E2EDaemon

    config = DaemonConfig.load(args.config)
    if args.log_level:
        config.log_level = args.log_level.upper()

    daemon = C4E2EDaemon(config)

    async def run() -> None:
        stop_event = asyncio.Event()
        await daemon.start(stop_event=stop_event)
        try:
            await stop_event.wait()
        except (KeyboardInterrupt, asyncio.CancelledError):
            pass
        finally:
            await daemon.stop()

    asyncio.run(run())


def _cmd_setup_auth(args: argparse.Namespace) -> None:
    """Interactive auth setup: register password or enroll TOTP for a user."""
    from .config import DaemonConfig

    config = DaemonConfig.load(args.config)
    user = args.user or input("Username: ").strip()

    if args.method == "password" or (not args.method):
        import getpass
        from c4e2e_agent.auth.password import PasswordAuth
        pw = getpass.getpass(f"New password for {user}: ")
        pw2 = getpass.getpass("Confirm password: ")
        if pw != pw2:
            print("Passwords do not match.", file=sys.stderr)
            sys.exit(1)
        PasswordAuth(config.auth.password_db).set_password(user, pw)
        print(f"Password set for {user}")

    if args.method == "totp" or (not args.method and _ask_yes_no("Enroll TOTP?")):
        from c4e2e_agent.auth.totp import TOTPAuth
        uri = TOTPAuth(config.auth.totp_db).enroll(user)
        print(f"\nTOTP enrolled for {user}.")
        print(f"Scan this URI with your authenticator app:\n\n  {uri}\n")


def _ask_yes_no(prompt: str) -> bool:
    return input(f"{prompt} [y/N] ").strip().lower() == "y"


if __name__ == "__main__":
    main()
