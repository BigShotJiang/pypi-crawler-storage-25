"""C4E2E Daemon — main orchestrator.

Responsibilities:
  - Starts the TLS receive-mode transport server
  - Listens on the Unix IPC socket for CLI requests
  - Evaluates policy and runs MFA before accepting send requests
  - Creates SendAgent tasks for outbound transfers
  - Manages jail, watchtower, and profile lifecycle
  - Handles SIGHUP for config/policy hot-reload
"""

from __future__ import annotations

import asyncio
import logging
import os
import signal
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import DaemonConfig
from .profile import ProfileManager, Profile
from .policy import PolicyEngine
from .jail import JailManager, JailEntry
from .watchtower import WatchtowerManager
from .ipc.protocol import (
    IPCMessageType,
    SendRequest,
    AuthRequest,
    JailListRequest,
    JailActionRequest,
    ProfileListRequest,
    StatusRequest,
)
from .ipc.server import IPCServer

from c4e2e_agent.auth.multi_factor import MFAAuthenticator, AuthConfig as AgentAuthConfig
from c4e2e_agent.agent import SendAgent, ReceiveAgent, AgentProfile
from c4e2e_agent.transport.tls_context import get_or_create_server_context

log = logging.getLogger(__name__)


class C4E2EDaemon:
    """Main daemon class: wires together all subsystems."""

    def __init__(self, config: DaemonConfig) -> None:
        self.config = config
        self._start_time = time.monotonic()

        self._profile_manager = ProfileManager(config.profiles_dir)
        self._policy = PolicyEngine(config.policy_file)
        self._jail = JailManager(config.jail)
        self._watchtower = WatchtowerManager()
        self._mfa = MFAAuthenticator(AgentAuthConfig(
            password_db=config.auth.password_db,
            totp_db=config.auth.totp_db,
            hmac_key_path=config.auth.hmac_key_path,
            yubikey_client_id=config.auth.yubikey_client_id,
            yubikey_api_key=config.auth.yubikey_api_key,
            yubikey_api_servers=config.auth.yubikey_api_servers,
        ))
        self._ipc_server: Optional[IPCServer] = None
        self._receive_agent: Optional[ReceiveAgent] = None
        self._stopped = False
        self._stop_event: Optional[asyncio.Event] = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self, stop_event: Optional[asyncio.Event] = None) -> None:
        self._stop_event = stop_event
        self.config.validate()
        self._setup_logging()

        # Generate TLS cert if needed
        if self.config.tls_auto_generate:
            get_or_create_server_context(Path(self.config.tls.cert).parent)

        # Start receive agent
        default_profile = self._build_default_receive_profile()
        self._receive_agent = ReceiveAgent(
            profile=default_profile,
            on_receive=self._handle_received_payload,
        )
        await self._receive_agent.start_listening()

        # Start IPC server
        self._ipc_server = IPCServer(
            socket_path=self.config.ipc_socket,
            handler=self._handle_ipc_request,
        )
        await self._ipc_server.start()

        # Signal handling
        loop = asyncio.get_event_loop()
        loop.add_signal_handler(signal.SIGHUP, self._on_sighup)
        loop.add_signal_handler(signal.SIGTERM, self._on_sigterm)

        log.info(
            "c4e2e-daemon started (port=%d, profiles=%d)",
            self.config.listen_port,
            len(self._profile_manager.list_profiles()),
        )

    async def stop(self) -> None:
        if self._stopped:
            return
        self._stopped = True
        self._watchtower.cancel_all()
        if self._receive_agent:
            await self._receive_agent.stop()
        if self._ipc_server:
            await self._ipc_server.stop()
        log.info("c4e2e-daemon stopped")

    # ------------------------------------------------------------------
    # IPC request dispatcher
    # ------------------------------------------------------------------

    async def _handle_ipc_request(self, request: dict) -> dict:
        msg_type = request.get("type", -1)

        try:
            if msg_type == IPCMessageType.AUTH_REQUEST:
                return await self._ipc_auth(request)
            if msg_type == IPCMessageType.SEND_REQUEST:
                return await self._ipc_send(request)
            if msg_type == IPCMessageType.JAIL_LIST:
                return self._ipc_jail_list(request)
            if msg_type == IPCMessageType.JAIL_RELEASE:
                return self._ipc_jail_release(request)
            if msg_type == IPCMessageType.JAIL_DESTROY:
                return self._ipc_jail_destroy(request)
            if msg_type == IPCMessageType.PROFILE_LIST:
                return self._ipc_profile_list()
            if msg_type == IPCMessageType.STATUS:
                return self._ipc_status()
        except Exception as exc:
            log.exception("IPC handler error for type %d", msg_type)
            return {"success": False, "error": str(exc), "type": int(IPCMessageType.ERROR)}

        return {"success": False, "error": f"unknown message type: {msg_type}", "type": int(IPCMessageType.ERROR)}

    # ------------------------------------------------------------------
    # IPC handlers
    # ------------------------------------------------------------------

    async def _ipc_auth(self, req: dict) -> dict:
        user = req.get("user", "")
        profile_name = req.get("profile", "")
        credentials = req.get("credentials", {})

        try:
            profile = self._profile_manager.load(profile_name)
        except Exception as exc:
            return {"success": False, "error": str(exc), "type": int(IPCMessageType.AUTH_RESPONSE)}

        decision = self._policy.evaluate(user, "send", profile_name)
        if not decision.allowed:
            return {"success": False, "error": decision.reason, "type": int(IPCMessageType.AUTH_RESPONSE)}

        ok = self._mfa.authenticate(user, profile.required_auth, credentials)
        if not ok:
            return {"success": False, "error": "authentication failed", "type": int(IPCMessageType.AUTH_RESPONSE)}

        return {"success": True, "type": int(IPCMessageType.AUTH_RESPONSE)}

    async def _ipc_send(self, req: dict) -> dict:
        filepath = req.get("filepath", "")
        recipient = req.get("recipient", "")
        frag_count = int(req.get("frag_count", 1))
        frag_mode = req.get("frag_mode", "none")
        watchtower_secs = int(req.get("watchtower_secs", 0))
        kill = bool(req.get("kill", False))

        try:
            data = Path(filepath).read_bytes()
        except Exception as exc:
            return {"success": False, "error": f"cannot read file: {exc}", "type": int(IPCMessageType.SEND_COMPLETE)}

        try:
            profile = self._profile_manager.load(recipient)
        except Exception:
            host, port = _parse_host_port(recipient, self.config.listen_port)
            return {"success": False, "error": f"profile not found: {recipient}", "type": int(IPCMessageType.SEND_COMPLETE)}

        agent_profile = _daemon_profile_to_agent_profile(profile, self.config)
        if req.get("watchtower_secs"):
            agent_profile.watchtower = watchtower_secs

        from c4e2e_agent.fragmentation.fragmenter import FragMode
        agent = SendAgent(agent_profile)
        result = await agent.send(
            data=data,
            filename=Path(filepath).name,
            frag_mode=FragMode(frag_mode),
            frag_count=frag_count,
            watchtower_secs=watchtower_secs,
        )

        if result.success and watchtower_secs > 0 and not kill:
            self._watchtower.schedule(
                result.transfer_id,
                watchtower_secs,
                lambda: log.info("watchtower expired for %s", result.transfer_id),
            )

        return {
            "success": result.success,
            "type": int(IPCMessageType.SEND_COMPLETE),
            "transfer_id": result.transfer_id,
            "bytes_sent": result.bytes_sent,
            "fragment_count": result.fragment_count,
            "error": result.error,
        }

    def _ipc_jail_list(self, req: dict) -> dict:
        sender = req.get("sender")
        entries = self._jail.list_jailed(sender)
        return {
            "success": True,
            "type": int(IPCMessageType.JAIL_LIST),
            "entries": [str(e.path) for e in entries],
        }

    def _ipc_jail_release(self, req: dict) -> dict:
        jail_path_str = req.get("jail_path", "")
        output_dir = req.get("output_dir") or self.config.output_dir
        from .jail import _parse_entry
        entry = _parse_entry(Path(jail_path_str))
        if entry is None:
            return {"success": False, "error": "cannot parse jail entry", "type": int(IPCMessageType.JAIL_RELEASE)}
        try:
            data = self._jail.release(entry)
            out = Path(output_dir) / f"{entry.time}-{entry.priority}.{entry.extension}"
            out.write_bytes(data)
            return {"success": True, "type": int(IPCMessageType.JAIL_RELEASE), "output_path": str(out)}
        except Exception as exc:
            return {"success": False, "error": str(exc), "type": int(IPCMessageType.JAIL_RELEASE)}

    def _ipc_jail_destroy(self, req: dict) -> dict:
        jail_path_str = req.get("jail_path", "")
        from .jail import _parse_entry
        entry = _parse_entry(Path(jail_path_str))
        if entry is None:
            return {"success": False, "error": "cannot parse jail entry", "type": int(IPCMessageType.JAIL_DESTROY)}
        try:
            self._jail.destroy(entry)
            return {"success": True, "type": int(IPCMessageType.JAIL_DESTROY)}
        except Exception as exc:
            return {"success": False, "error": str(exc), "type": int(IPCMessageType.JAIL_DESTROY)}

    def _ipc_profile_list(self) -> dict:
        return {
            "success": True,
            "type": int(IPCMessageType.PROFILE_LIST),
            "profiles": self._profile_manager.list_profiles(),
        }

    def _ipc_status(self) -> dict:
        return {
            "success": True,
            "type": int(IPCMessageType.STATUS),
            "version": "1.0.0",
            "uptime_secs": int(time.monotonic() - self._start_time),
            "listen_port": self.config.listen_port,
            "profile_count": len(self._profile_manager.list_profiles()),
        }

    # ------------------------------------------------------------------
    # Receive callback
    # ------------------------------------------------------------------

    def _handle_received_payload(
        self,
        sender_pubkey_b64: str,
        filename: str,
        data: bytes,
    ) -> None:
        """Called by ReceiveAgent for each successfully decrypted transfer."""
        # Try to find a matching profile for this sender
        profile = self._resolve_sender_profile(sender_pubkey_b64)

        if profile and profile.jail:
            entry = self._jail.jail_payload(
                sender=sender_pubkey_b64[:16],
                data=data,
                filename=filename,
                priority=profile.priority,
            )
            log.info("jailed transfer from %s... → %s", sender_pubkey_b64[:12], entry.path.name)
        else:
            out_dir = Path(profile.output_dir if profile else self.config.output_dir)
            out_dir.mkdir(parents=True, exist_ok=True)
            out = out_dir / filename
            out.write_bytes(data)
            log.info("received %s (%d bytes) → %s", filename, len(data), out)

    def _resolve_sender_profile(self, sender_pubkey_b64: str) -> Optional[Profile]:
        for name in self._profile_manager.list_profiles():
            try:
                p = self._profile_manager.load(name)
                if p.resolve_trusted_key() == sender_pubkey_b64:
                    return p
            except Exception:
                continue
        return None

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _build_default_receive_profile(self) -> AgentProfile:
        """Build a receive AgentProfile that trusts all configured profile senders."""
        all_trusted: List[str] = []
        for name in self._profile_manager.list_profiles():
            try:
                p = self._profile_manager.load(name)
                if "receive" in p.allowed_operations or not p.allowed_operations:
                    key = p.resolve_trusted_key()
                    if key and key not in all_trusted:
                        all_trusted.append(key)
            except Exception:
                continue

        return AgentProfile(
            name="default-receive",
            host="0.0.0.0",
            port=self.config.listen_port,
            identity_key=self.config.identity_key,
            trusted_key=all_trusted[0] if all_trusted else "",
            trusted_keys=all_trusted[1:] if len(all_trusted) > 1 else None,
            x25519_key=self.config.x25519_key,
            tls_cert_dir=str(Path(self.config.tls.cert).parent),
            tls_ca=self.config.tls.ca,
            output_dir=self.config.output_dir,
        )

    def _setup_logging(self) -> None:
        log_dir = Path(self.config.log_file).parent
        log_dir.mkdir(parents=True, exist_ok=True)
        level = getattr(logging, self.config.log_level.upper(), logging.INFO)
        logging.basicConfig(
            level=level,
            format="%(asctime)s %(levelname)s %(name)s: %(message)s",
            handlers=[
                logging.FileHandler(self.config.log_file),
                logging.StreamHandler(),
            ],
        )

    def _on_sighup(self) -> None:
        log.info("SIGHUP received — reloading policy")
        self._policy.reload()

    def _on_sigterm(self) -> None:
        log.info("SIGTERM received — shutting down")
        if self._stop_event is not None:
            self._stop_event.set()


# ------------------------------------------------------------------
# Helper functions
# ------------------------------------------------------------------

def _daemon_profile_to_agent_profile(
    profile: Profile,
    config: DaemonConfig,
) -> AgentProfile:
    return AgentProfile(
        name=profile.name,
        host=profile.host,
        port=profile.port,
        identity_key=profile.resolve_identity_key(),
        trusted_key=profile.resolve_trusted_key(),
        x25519_key=profile.x25519_key,
        watchtower=profile.watchtower,
        jail=profile.jail,
        fragmentation=profile.fragmentation,
        frag_mode=profile.frag_mode,
        output_dir=profile.output_dir,
        tls_cert_dir=str(Path(config.tls.cert).parent),
        tls_ca=config.tls.ca,
    )


def _parse_host_port(recipient: str, default_port: int) -> tuple:
    if ":" in recipient:
        host, port_str = recipient.rsplit(":", 1)
        return host, int(port_str)
    return recipient, default_port
