"""Daemon configuration loading and validation."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

import yaml


class ConfigError(Exception):
    pass


@dataclass
class TLSConfig:
    cert: str
    key: str
    ca: Optional[str] = None

    def validate(self) -> None:
        if not Path(self.cert).exists():
            raise ConfigError(f"TLS cert not found: {self.cert}")
        if not Path(self.key).exists():
            raise ConfigError(f"TLS key not found: {self.key}")


@dataclass
class AuthConfig:
    password_db: str = "/etc/c4e2e/auth/passwords.json"
    totp_db: str = "/etc/c4e2e/auth/totp.json"
    hmac_key_path: Optional[str] = None
    yubikey_client_id: Optional[str] = None
    yubikey_api_key: Optional[str] = None
    yubikey_api_servers: Optional[List[str]] = None


@dataclass
class JailConfig:
    base_dir: str = "/var/c4e2e/jail"
    key_store: str = "/etc/c4e2e/jail/keys"


@dataclass
class DaemonConfig:
    # CHANGE BEFORE PUBLIC DEPLOYMENT: bind to specific interface, not 0.0.0.0
    listen_host: str = "0.0.0.0"
    listen_port: int = 6080
    # Daemon's own identity keypair (receive mode requires these)
    identity_key: str = "/etc/c4e2e/keys/identity.pem"
    x25519_key: str = "/etc/c4e2e/keys/transport.pem"
    ipc_socket: str = "/run/c4e2e/daemon.sock"
    profiles_dir: str = "/etc/c4e2e/profiles"
    policy_file: str = "/etc/c4e2e/policy.yaml"
    output_dir: str = "/var/c4e2e/received"
    tls: TLSConfig = field(default_factory=lambda: TLSConfig(
        cert="/etc/c4e2e/tls/server.crt",
        key="/etc/c4e2e/tls/server.key",
    ))
    auth: AuthConfig = field(default_factory=AuthConfig)
    jail: JailConfig = field(default_factory=JailConfig)
    log_file: str = "/var/log/c4e2e/daemon.log"
    log_level: str = "INFO"
    # Auto-generate TLS cert if absent (default True for first-run convenience)
    tls_auto_generate: bool = True

    @classmethod
    def load(cls, path: str) -> "DaemonConfig":
        with open(path) as f:
            raw = yaml.safe_load(f) or {}
        d = raw.get("daemon", raw)

        tls_raw = d.get("tls", {})
        tls = TLSConfig(
            cert=tls_raw.get("cert", "/etc/c4e2e/tls/server.crt"),
            key=tls_raw.get("key", "/etc/c4e2e/tls/server.key"),
            ca=tls_raw.get("ca"),
        )

        auth_raw = d.get("auth", {})
        auth = AuthConfig(
            password_db=auth_raw.get("password_db", "/etc/c4e2e/auth/passwords.json"),
            totp_db=auth_raw.get("totp_db", "/etc/c4e2e/auth/totp.json"),
            hmac_key_path=auth_raw.get("hmac_key_path"),
            yubikey_client_id=auth_raw.get("yubikey_client_id"),
            yubikey_api_key=auth_raw.get("yubikey_api_key"),
            yubikey_api_servers=auth_raw.get("yubikey_api_servers"),
        )

        jail_raw = d.get("jail", {})
        jail = JailConfig(
            base_dir=jail_raw.get("base_dir", "/var/c4e2e/jail"),
            key_store=jail_raw.get("key_store", "/etc/c4e2e/jail/keys"),
        )

        return cls(
            listen_host=d.get("listen_host", "0.0.0.0"),
            listen_port=int(d.get("listen_port", 6080)),
            identity_key=d.get("identity_key", "/etc/c4e2e/keys/identity.pem"),
            x25519_key=d.get("x25519_key", "/etc/c4e2e/keys/transport.pem"),
            ipc_socket=d.get("ipc_socket", "/run/c4e2e/daemon.sock"),
            profiles_dir=d.get("profiles_dir", "/etc/c4e2e/profiles"),
            policy_file=d.get("policy_file", "/etc/c4e2e/policy.yaml"),
            output_dir=d.get("output_dir", "/var/c4e2e/received"),
            tls=tls,
            auth=auth,
            jail=jail,
            log_file=d.get("log_file", "/var/log/c4e2e/daemon.log"),
            log_level=d.get("log_level", "INFO"),
            tls_auto_generate=bool(d.get("tls_auto_generate", True)),
        )

    def validate(self) -> None:
        for d in [self.profiles_dir, self.output_dir, self.jail.base_dir]:
            Path(d).mkdir(parents=True, exist_ok=True)
        Path(self.jail.key_store).mkdir(parents=True, exist_ok=True)
        Path(self.auth.password_db).parent.mkdir(parents=True, exist_ok=True)
        Path(self.auth.totp_db).parent.mkdir(parents=True, exist_ok=True)

        tls_cert_dir = Path(self.tls.cert).parent
        tls_cert_dir.mkdir(parents=True, exist_ok=True)

        if not self.tls_auto_generate:
            self.tls.validate()
