"""c4e2e-daemon: secure structured data transfer orchestration daemon."""

__version__ = "1.0.0"
