"""Tests for the transport wire protocol."""

import json
import struct
import pytest

from c4e2e_agent.transport.protocol import (
    MessageType,
    Message,
    encode_message,
    decode_message,
    ProtocolError,
    Hello,
    HelloAck,
    TransferInit,
    Fragment,
    TransferDone,
    TransferAck,
    ErrorMessage,
    PROTOCOL_VERSION,
)


class TestEncodeDecodeMessage:
    def test_roundtrip(self):
        msg = Message(type=MessageType.HELLO, payload=b'{"test": 1}')
        encoded = encode_message(msg)
        decoded, remainder = decode_message(encoded)
        assert decoded.type == MessageType.HELLO
        assert decoded.payload == b'{"test": 1}'
        assert remainder == b""

    def test_multiple_messages(self):
        m1 = Message(type=MessageType.HELLO, payload=b"first")
        m2 = Message(type=MessageType.HELLO_ACK, payload=b"second")
        combined = encode_message(m1) + encode_message(m2)
        decoded1, rest = decode_message(combined)
        decoded2, empty = decode_message(rest)
        assert decoded1.type == MessageType.HELLO
        assert decoded2.type == MessageType.HELLO_ACK
        assert empty == b""

    def test_incomplete_header_raises(self):
        with pytest.raises(ProtocolError, match="incomplete header"):
            decode_message(b"\x01")

    def test_incomplete_payload_raises(self):
        header = struct.pack("!BL", int(MessageType.HELLO), 100)
        with pytest.raises(ProtocolError, match="incomplete payload"):
            decode_message(header + b"too short")

    def test_unknown_type_raises(self):
        header = struct.pack("!BL", 0xAB, 0)
        with pytest.raises(ProtocolError, match="unknown message type"):
            decode_message(header)

    def test_oversized_payload_raises(self):
        header = struct.pack("!BL", int(MessageType.HELLO), 64 * 1024 * 1024 + 1)
        with pytest.raises(ProtocolError, match="exceeds limit"):
            decode_message(header)


class TestTypedMessages:
    def test_hello_roundtrip(self):
        h = Hello(version=PROTOCOL_VERSION, agent_id="uuid-1", pubkey_b64="PUBKEY==")
        msg = h.to_message()
        assert msg.type == MessageType.HELLO
        parsed = Hello.from_message(msg)
        assert parsed.version == PROTOCOL_VERSION
        assert parsed.agent_id == "uuid-1"
        assert parsed.pubkey_b64 == "PUBKEY=="

    def test_transfer_init_roundtrip(self):
        init = TransferInit(
            transfer_id="tid-1",
            filename="test.bin",
            total_size=1024,
            fragment_count=4,
            frag_mode="payload",
            sender_pubkey_b64="SENDER==",
            timestamp_utc="2026-05-22T00:00:00Z",
        )
        msg = init.to_message()
        parsed = TransferInit.from_message(msg)
        assert parsed.transfer_id == "tid-1"
        assert parsed.fragment_count == 4
        assert parsed.frag_mode == "payload"

    def test_fragment_roundtrip(self):
        frag = Fragment(
            transfer_id="tid-1",
            index=2,
            total=5,
            data_b64="AAAA",
            hmac_b64="BBBB",
        )
        msg = frag.to_message()
        parsed = Fragment.from_message(msg)
        assert parsed.index == 2
        assert parsed.total == 5
        assert parsed.hmac_b64 == "BBBB"

    def test_transfer_ack_success(self):
        ack = TransferAck(transfer_id="tid-1", success=True)
        msg = ack.to_message()
        parsed = TransferAck.from_message(msg)
        assert parsed.success is True
        assert parsed.error == ""

    def test_transfer_ack_failure(self):
        ack = TransferAck(transfer_id="tid-1", success=False, error="TRUST_FAILURE")
        msg = ack.to_message()
        parsed = TransferAck.from_message(msg)
        assert parsed.success is False
        assert parsed.error == "TRUST_FAILURE"

    def test_error_message(self):
        err = ErrorMessage(code="INTERNAL_ERROR", detail="something went wrong")
        msg = err.to_message()
        assert msg.type == MessageType.ERROR
        parsed = ErrorMessage.from_message(msg)
        assert parsed.code == "INTERNAL_ERROR"
