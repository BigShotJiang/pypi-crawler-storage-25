"""Tests for authentication modules."""

import pytest
from pathlib import Path


@pytest.fixture
def password_db(tmp_path):
    return str(tmp_path / "passwords.json")


@pytest.fixture
def totp_db(tmp_path):
    return str(tmp_path / "totp.json")


class TestPasswordAuth:
    def test_set_and_verify(self, password_db):
        from c4e2e_agent.auth.password import PasswordAuth
        auth = PasswordAuth(password_db)
        auth.set_password("alice", "correct-horse-battery-staple")
        assert auth.verify("alice", "correct-horse-battery-staple") is True

    def test_wrong_password(self, password_db):
        from c4e2e_agent.auth.password import PasswordAuth
        auth = PasswordAuth(password_db)
        auth.set_password("alice", "secret")
        assert auth.verify("alice", "wrong") is False

    def test_unknown_user(self, password_db):
        from c4e2e_agent.auth.password import PasswordAuth
        auth = PasswordAuth(password_db)
        assert auth.verify("ghost", "anything") is False

    def test_delete_user(self, password_db):
        from c4e2e_agent.auth.password import PasswordAuth
        auth = PasswordAuth(password_db)
        auth.set_password("alice", "secret")
        auth.delete_user("alice")
        assert auth.verify("alice", "secret") is False


class TestTOTPAuth:
    def test_enroll_and_verify(self, totp_db):
        from c4e2e_agent.auth.totp import TOTPAuth
        import pyotp
        auth = TOTPAuth(totp_db)
        uri = auth.enroll("bob")
        assert "otpauth://" in uri
        # Extract secret from URI and generate a valid code
        secret = pyotp.parse_uri(uri).secret
        code = pyotp.TOTP(secret).now()
        assert auth.verify("bob", code) is True

    def test_wrong_code(self, totp_db):
        from c4e2e_agent.auth.totp import TOTPAuth
        auth = TOTPAuth(totp_db)
        auth.enroll("bob")
        assert auth.verify("bob", "000000") is False

    def test_unknown_user(self, totp_db):
        from c4e2e_agent.auth.totp import TOTPAuth
        auth = TOTPAuth(totp_db)
        assert auth.verify("ghost", "123456") is False

    def test_revoke(self, totp_db):
        from c4e2e_agent.auth.totp import TOTPAuth
        import pyotp
        auth = TOTPAuth(totp_db)
        uri = auth.enroll("bob")
        secret = pyotp.parse_uri(uri).secret
        code = pyotp.TOTP(secret).now()
        auth.revoke("bob")
        assert auth.verify("bob", code) is False


class TestHMACAuth:
    def test_not_configured_raises(self):
        from c4e2e_agent.auth.hmac_challenge import HMACChallengeAuth, ConfigurationError
        auth = HMACChallengeAuth(key_store_path=None)
        with pytest.raises(ConfigurationError):
            auth.generate_challenge("alice")

    def test_configured_verify(self, tmp_path):
        from c4e2e_agent.auth.hmac_challenge import HMACChallengeAuth
        import hashlib, hmac, os
        auth = HMACChallengeAuth(key_store_path=str(tmp_path))
        key = os.urandom(32)
        auth.register_user_key("alice", key)
        challenge = auth.generate_challenge("alice")
        response = hmac.new(key, challenge, hashlib.sha256).digest()
        assert auth.verify_response("alice", response) is True

    def test_wrong_response(self, tmp_path):
        from c4e2e_agent.auth.hmac_challenge import HMACChallengeAuth
        import os
        auth = HMACChallengeAuth(key_store_path=str(tmp_path))
        auth.register_user_key("alice", os.urandom(32))
        auth.generate_challenge("alice")
        assert auth.verify_response("alice", b"\x00" * 32) is False


class TestMFAAuthenticator:
    def test_password_only(self, password_db, totp_db):
        from c4e2e_agent.auth.multi_factor import MFAAuthenticator, AuthConfig
        config = AuthConfig(password_db=password_db, totp_db=totp_db)
        mfa = MFAAuthenticator(config)
        mfa.password_auth.set_password("alice", "secret")
        assert mfa.authenticate("alice", ["password"], {"password": "secret"}) is True
        assert mfa.authenticate("alice", ["password"], {"password": "wrong"}) is False

    def test_empty_methods_raises(self, password_db, totp_db):
        from c4e2e_agent.auth.multi_factor import MFAAuthenticator, AuthConfig, AuthenticationError
        config = AuthConfig(password_db=password_db, totp_db=totp_db)
        mfa = MFAAuthenticator(config)
        with pytest.raises(AuthenticationError):
            mfa.authenticate("alice", [], {})
