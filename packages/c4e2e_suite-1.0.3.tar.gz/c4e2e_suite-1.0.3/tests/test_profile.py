"""Tests for profile loading and management."""

import tempfile
import pytest
import yaml
from pathlib import Path

from c4e2e_daemon.profile import ProfileManager, Profile, ProfileNotFoundError


@pytest.fixture
def profiles_dir(tmp_path):
    return str(tmp_path / "profiles")


@pytest.fixture
def manager(profiles_dir):
    return ProfileManager(profiles_dir)


def _write_profile(profiles_dir: str, data: dict) -> None:
    p = Path(profiles_dir) / f"{data['name']}.yaml"
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w") as f:
        yaml.dump(data, f)


def test_list_empty(manager):
    assert manager.list_profiles() == []


def test_save_and_load(manager):
    profile = Profile(
        name="test-01",
        host="10.0.0.1",
        port=6080,
        identity_key="/tmp/id.pem",
        trusted_key="AAAA",
    )
    manager.save(profile)
    loaded = manager.load("test-01")
    assert loaded.name == "test-01"
    assert loaded.host == "10.0.0.1"
    assert loaded.port == 6080
    assert loaded.trusted_key == "AAAA"


def test_load_missing(manager):
    with pytest.raises(ProfileNotFoundError):
        manager.load("nonexistent")


def test_list_profiles(manager):
    for name in ["alpha", "beta", "gamma"]:
        profile = Profile(name=name, host="127.0.0.1", port=6080, identity_key="/tmp/id.pem", trusted_key="K")
        manager.save(profile)
    assert manager.list_profiles() == ["alpha", "beta", "gamma"]


def test_delete_profile(manager):
    profile = Profile(name="todelete", host="127.0.0.1", port=6080, identity_key="/tmp/id.pem", trusted_key="K")
    manager.save(profile)
    manager.delete("todelete")
    with pytest.raises(ProfileNotFoundError):
        manager.load("todelete")


def test_profile_resolve_trusted_key_base64(manager):
    profile = Profile(name="x", host="127.0.0.1", port=6080, identity_key="/tmp/id.pem", trusted_key="BASE64KEY==")
    assert profile.resolve_trusted_key() == "BASE64KEY=="


def test_profile_all_trusted_keys(tmp_path):
    from c4e2e_agent.agent import AgentProfile
    p = AgentProfile(
        name="test",
        host="localhost",
        port=6080,
        identity_key="/tmp/id.pem",
        trusted_key="KEY1",
        trusted_keys=["KEY2", "KEY3", "KEY1"],
    )
    keys = p.all_trusted_keys()
    assert "KEY1" in keys
    assert "KEY2" in keys
    assert "KEY3" in keys
    assert keys.count("KEY1") == 1  # deduplicated


def test_profile_required_auth_default():
    profile = Profile(name="x", host="127.0.0.1", port=6080, identity_key="/tmp/id.pem", trusted_key="K")
    assert profile.required_auth == ["password"]


def test_profile_allowed_operations_default():
    profile = Profile(name="x", host="127.0.0.1", port=6080, identity_key="/tmp/id.pem", trusted_key="K")
    assert profile.allowed_operations == ["send"]
