"""Tests for fragmentation and reassembly (protocol-level, no c4e2e crypto)."""

import hashlib
import hmac
import os
import pytest

from c4e2e_agent.fragmentation.fragmenter import _compute_hmac, _split_bytes, FragMode
from c4e2e_agent.fragmentation.reassembler import (
    ReassemblerSession,
    HMACError,
    BufferOverflowError,
    TimeoutError,
    ReplayError,
    MAX_BUFFER_BYTES,
)
from c4e2e_agent.fragmentation.fragmenter import RawFragment


def _make_frag(key, transfer_id, index, total, data):
    return RawFragment(
        transfer_id=transfer_id,
        index=index,
        total=total,
        data=data,
        hmac_bytes=_compute_hmac(key, transfer_id, index, total, data),
    )


class TestSplitBytes:
    def test_single_chunk(self):
        data = b"hello world"
        chunks = _split_bytes(data, 1)
        assert chunks == [data]

    def test_split_exact(self):
        data = bytes(range(100))
        chunks = _split_bytes(data, 4)
        assert b"".join(chunks) == data
        assert len(chunks) == 4

    def test_split_uneven(self):
        data = bytes(range(10))
        chunks = _split_bytes(data, 3)
        assert b"".join(chunks) == data
        assert len(chunks) == 3

    def test_split_more_than_data(self):
        data = b"hi"
        chunks = _split_bytes(data, 5)
        assert b"".join(chunks) == data


class TestComputeHMAC:
    def test_deterministic(self):
        key = os.urandom(32)
        h1 = _compute_hmac(key, "tid", 0, 3, b"data")
        h2 = _compute_hmac(key, "tid", 0, 3, b"data")
        assert h1 == h2

    def test_different_index(self):
        key = os.urandom(32)
        h1 = _compute_hmac(key, "tid", 0, 3, b"data")
        h2 = _compute_hmac(key, "tid", 1, 3, b"data")
        assert h1 != h2

    def test_different_data(self):
        key = os.urandom(32)
        h1 = _compute_hmac(key, "tid", 0, 1, b"data1")
        h2 = _compute_hmac(key, "tid", 0, 1, b"data2")
        assert h1 != h2


class TestReassemblerSession:
    def test_add_and_complete(self):
        key = os.urandom(32)
        tid = "test-transfer-1"
        chunks = [b"chunk0", b"chunk1", b"chunk2"]
        session = ReassemblerSession(tid, 3, key)
        for i, chunk in enumerate(chunks):
            frag = _make_frag(key, tid, i, 3, chunk)
            session.add_fragment(frag)
        assert session.is_complete()
        raw = session.reassemble_raw()
        assert raw == b"chunk0chunk1chunk2"

    def test_hmac_failure(self):
        key = os.urandom(32)
        tid = "hmac-fail"
        bad_frag = RawFragment(
            transfer_id=tid,
            index=0,
            total=1,
            data=b"data",
            hmac_bytes=b"\x00" * 32,
        )
        session = ReassemblerSession(tid, 1, key)
        with pytest.raises(HMACError):
            session.add_fragment(bad_frag)

    def test_duplicate_fragment(self):
        key = os.urandom(32)
        tid = "dup-test"
        frag = _make_frag(key, tid, 0, 2, b"data")
        session = ReassemblerSession(tid, 2, key)
        session.add_fragment(frag)
        with pytest.raises(Exception):
            session.add_fragment(frag)

    def test_total_mismatch(self):
        key = os.urandom(32)
        tid = "mismatch"
        frag = _make_frag(key, tid, 0, 5, b"data")
        session = ReassemblerSession(tid, 3, key)  # expects total=3, frag says 5
        with pytest.raises(Exception):
            session.add_fragment(frag)

    def test_incomplete_not_complete(self):
        key = os.urandom(32)
        tid = "incomplete"
        session = ReassemblerSession(tid, 3, key)
        frag = _make_frag(key, tid, 0, 3, b"data")
        session.add_fragment(frag)
        assert not session.is_complete()
