"""Tests for the jail manager: encrypt, list, release, destroy."""

import os
import pytest
from pathlib import Path

from c4e2e_daemon.config import JailConfig
from c4e2e_daemon.jail import JailManager, JailError


@pytest.fixture
def jail_config(tmp_path):
    return JailConfig(
        base_dir=str(tmp_path / "jail"),
        key_store=str(tmp_path / "jail_keys"),
    )


@pytest.fixture
def jail_manager(jail_config):
    return JailManager(jail_config)


class TestJailManager:
    def test_jail_and_release(self, jail_manager):
        data = b"sensitive payload data"
        entry = jail_manager.jail_payload(
            sender="sender-pubkey-abc123",
            data=data,
            filename="test.bin",
            priority="P2",
        )
        assert entry.path.exists()
        assert entry.path.name.endswith(".jaild")
        assert entry.priority == "P2"
        assert entry.extension == "bin"
        released = jail_manager.release(entry)
        assert released == data

    def test_jail_file_path_format(self, jail_manager):
        entry = jail_manager.jail_payload(
            sender="remote-01",
            data=b"data",
            filename="document.pdf",
            priority="P1",
        )
        # Path: <base>/<sender>/<MMDDYYYY>/<HHMM>-P1.pdf.jaild
        assert entry.path.suffix == ".jaild"
        assert "P1" in entry.path.name
        assert entry.extension == "pdf"

    def test_jail_creates_key_sidecar(self, jail_manager):
        entry = jail_manager.jail_payload(
            sender="test-sender",
            data=b"test data",
            filename="file.bin",
        )
        sidecar = entry.path.with_suffix(".jaild.kid")
        assert sidecar.exists()
        assert sidecar.read_text().strip() == entry.key_id

    def test_destroy_removes_files(self, jail_manager):
        entry = jail_manager.jail_payload(
            sender="destroy-test",
            data=b"to destroy",
            filename="x.bin",
        )
        jail_path = entry.path
        sidecar = jail_path.with_suffix(".jaild.kid")
        jail_manager.destroy(entry)
        assert not jail_path.exists()
        assert not sidecar.exists()

    def test_release_after_destroy_fails(self, jail_manager):
        entry = jail_manager.jail_payload(
            sender="test",
            data=b"data",
            filename="x.bin",
        )
        jail_manager.destroy(entry)
        with pytest.raises((JailError, FileNotFoundError)):
            jail_manager.release(entry)

    def test_list_jailed(self, jail_manager):
        jail_manager.jail_payload("sender-a", b"a", "a.bin")
        jail_manager.jail_payload("sender-a", b"b", "b.bin")
        jail_manager.jail_payload("sender-b", b"c", "c.bin")
        all_entries = jail_manager.list_jailed()
        assert len(all_entries) == 3
        sender_a_entries = jail_manager.list_jailed("sender-a")
        assert len(sender_a_entries) == 2

    def test_jail_file_permissions(self, jail_manager):
        entry = jail_manager.jail_payload("test", b"data", "x.bin")
        import stat
        mode = entry.path.stat().st_mode
        # Verify group/other have no permissions
        assert not (mode & (stat.S_IRWXG | stat.S_IRWXO))

    def test_jail_data_not_plaintext_on_disk(self, jail_manager):
        data = b"SECRET SENSITIVE DATA DO NOT STORE IN PLAIN TEXT"
        entry = jail_manager.jail_payload("test", data, "secret.bin")
        raw_on_disk = entry.path.read_bytes()
        assert data not in raw_on_disk  # must not appear verbatim

    def test_release_wrong_data_raises(self, jail_config, jail_manager, tmp_path):
        """Tampered jail file should fail decryption."""
        entry = jail_manager.jail_payload("test", b"original", "x.bin")
        # Corrupt the ciphertext
        entry.path.write_bytes(b"\x00" * 100)
        with pytest.raises(JailError):
            jail_manager.release(entry)
