# References (Tauri 2.x)

Use these links to verify current behavior, APIs, and configuration details.
Always confirm the app's Tauri version before applying guidance.

- https://v2.tauri.app/develop/features/state/
- https://v2.tauri.app/develop/features/command/
- https://docs.rs/tauri/
