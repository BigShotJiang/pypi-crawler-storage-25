from dkist_processing_test.tasks.exercise_numba import *
from dkist_processing_test.tasks.fail import *
from dkist_processing_test.tasks.fake_science import *
from dkist_processing_test.tasks.high_memory import *
from dkist_processing_test.tasks.movie import *
from dkist_processing_test.tasks.noop import *
from dkist_processing_test.tasks.parse import *
from dkist_processing_test.tasks.quality import *
from dkist_processing_test.tasks.write_l1 import *

# Not used directly, but ensures that the dkist_processing_test_configurations are logged early in a task run
from dkist_processing_test.config import dkist_processing_test_configurations  # isort: skip
