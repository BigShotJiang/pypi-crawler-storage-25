"""Test FITS access for L0 data."""

from astropy.io import fits
from dkist_processing_common.parsers.l0_fits_access import L0FitsAccess


class TestL0FitsAccess(L0FitsAccess):
    """
    Class to provide easy access to L0 headers.

    Parameters
    ----------
    hdu :
        Fits L0 header object

    name : str
        The name of the file that was loaded into this FitsAccess object

    auto_squeeze : bool
        When set to True, dimensions of length 1 will be removed from the array
    """

    def __init__(
        self,
        hdu: fits.ImageHDU | fits.PrimaryHDU | fits.CompImageHDU,
        name: str | None = None,
        auto_squeeze: bool = True,
    ):
        super().__init__(hdu=hdu, name=name, auto_squeeze=auto_squeeze)

        self.modulator_state: int = -1
