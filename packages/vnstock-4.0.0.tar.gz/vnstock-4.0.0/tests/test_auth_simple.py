#!/usr/bin/env python3
"""
Simple test script for auth module flow.
Tests: guest mode -> auth with API key -> verify tier limits
"""

import os
import sys
import json
from pathlib import Path

# Add vnstock to path
sys.path.insert(0, '/Users/mrthinh/Github/vnstock_dev')

def print_section(title):
    """Print a formatted section header"""
    print("\n" + "="*70)
    print(f"  {title}")
    print("="*70)

def test_guest_mode():
    """Test 1: Guest mode - no API key"""
    print_section("TEST 1: GUEST MODE (No API Key)")
    
    import vnstock
    
    # Check status
    print("\n1. Checking status (should be guest)...")
    vnstock.check_status()
    
    # Verify tier
    print("\n2. Verifying guest tier...")
    try:
        from vnai import get_user_tier
        tier_info = get_user_tier()
        print(f"   Tier: {tier_info['tier']}")
        print(f"   Limits: {tier_info['limits']}")
        
        assert tier_info['tier'] == 'guest', f"Expected guest, got {tier_info['tier']}"
        assert tier_info['limits']['per_minute'] == 20, f"Expected 20 req/min, got {tier_info['limits']['per_minute']}"
        print("   ✓ Guest tier confirmed: 20 requests/phút")
    except AssertionError as e:
        print(f"   ✗ Assertion failed: {e}")
        return False
    except Exception as e:
        print(f"   ✗ Error: {e}")
        return False
    
    print("\n✅ TEST 1 PASSED: Guest mode working correctly")
    return True

def test_auth_with_api_key():
    """Test 2: Auth with API key"""
    print_section("TEST 2: AUTH WITH API KEY")
    
    import vnstock
    
    api_key = "vnstock_64e8a8cc902c72d9fc8b396a539155a4"
    
    print(f"\n1. Registering with API key: {api_key[:20]}...")
    result = vnstock.change_api_key(api_key)
    
    if not result:
        print("   ✗ Failed to register API key")
        return False
    
    print("   ✓ API key registered successfully")
    
    # Check status
    print("\n2. Checking status (should show API key)...")
    vnstock.check_status()
    
    print("\n✅ TEST 2 PASSED: Auth with API key working correctly")
    return True

def test_free_tier_limits():
    """Test 3: Free tier limits"""
    print_section("TEST 3: FREE TIER LIMITS")
    
    import vnstock
    
    print("\n1. Verifying free tier...")
    try:
        from vnai import get_user_tier, refresh_tier_cache
        
        # Force refresh to detect new API key
        refresh_tier_cache()
        
        tier_info = get_user_tier()
        print(f"   Tier: {tier_info['tier']}")
        print(f"   Limits: {tier_info['limits']}")
        
        assert tier_info['tier'] == 'free', f"Expected free, got {tier_info['tier']}"
        assert tier_info['limits']['per_minute'] == 60, f"Expected 60 req/min, got {tier_info['limits']['per_minute']}"
        print("   ✓ Free tier confirmed: 60 requests/phút")
    except AssertionError as e:
        print(f"   ✗ Assertion failed: {e}")
        return False
    except Exception as e:
        print(f"   ✗ Error: {e}")
        return False
    
    print("\n✅ TEST 3 PASSED: Free tier limits working correctly")
    return True

def test_api_key_persistence():
    """Test 4: API key persistence"""
    print_section("TEST 4: API KEY PERSISTENCE")
    
    import vnstock
    from vnai import get_user_tier, refresh_tier_cache
    
    print("\n1. Checking if API key persists...")
    
    # Refresh tier cache
    refresh_tier_cache()
    
    # Check tier
    tier_info = get_user_tier()
    print(f"   Current tier: {tier_info['tier']}")
    
    try:
        assert tier_info['tier'] == 'free', f"Expected free, got {tier_info['tier']}"
        print("   ✓ API key persisted correctly")
    except AssertionError as e:
        print(f"   ✗ Assertion failed: {e}")
        return False
    
    print("\n✅ TEST 4 PASSED: API key persistence working correctly")
    return True

def test_api_key_file():
    """Test 5: Verify API key file storage"""
    print_section("TEST 5: API KEY FILE STORAGE")
    
    api_key_file = Path.home() / ".vnstock" / "api_key.json"
    
    print(f"\n1. Checking API key file: {api_key_file}")
    
    if not api_key_file.exists():
        print("   ✗ API key file not found")
        return False
    
    print("   ✓ API key file exists")
    
    # Read and verify content
    print("\n2. Verifying file content...")
    try:
        with open(api_key_file, 'r') as f:
            data = json.load(f)
            api_key = data.get('api_key')
            
            if not api_key:
                print("   ✗ API key not found in file")
                return False
            
            print(f"   API key: {api_key[:20]}...")
            print("   ✓ API key file content verified")
    except Exception as e:
        print(f"   ✗ Error reading file: {e}")
        return False
    
    print("\n✅ TEST 5 PASSED: API key file storage working correctly")
    return True

def main():
    """Run all tests"""
    print("\n" + "="*70)
    print("  VNSTOCK AUTH MODULE TEST SUITE")
    print("="*70)
    
    results = []
    
    # Test 1: Guest mode
    try:
        results.append(("Guest Mode", test_guest_mode()))
    except Exception as e:
        print(f"\n✗ TEST 1 FAILED: {e}")
        import traceback
        traceback.print_exc()
        results.append(("Guest Mode", False))
    
    # Test 2: Auth with API key
    try:
        results.append(("Auth with API Key", test_auth_with_api_key()))
    except Exception as e:
        print(f"\n✗ TEST 2 FAILED: {e}")
        import traceback
        traceback.print_exc()
        results.append(("Auth with API Key", False))
    
    # Test 3: Free tier limits
    try:
        results.append(("Free Tier Limits", test_free_tier_limits()))
    except Exception as e:
        print(f"\n✗ TEST 3 FAILED: {e}")
        import traceback
        traceback.print_exc()
        results.append(("Free Tier Limits", False))
    
    # Test 4: API key persistence
    try:
        results.append(("API Key Persistence", test_api_key_persistence()))
    except Exception as e:
        print(f"\n✗ TEST 4 FAILED: {e}")
        import traceback
        traceback.print_exc()
        results.append(("API Key Persistence", False))
    
    # Test 5: API key file storage
    try:
        results.append(("API Key File Storage", test_api_key_file()))
    except Exception as e:
        print(f"\n✗ TEST 5 FAILED: {e}")
        import traceback
        traceback.print_exc()
        results.append(("API Key File Storage", False))
    
    # Summary
    print_section("TEST SUMMARY")
    print()
    for test_name, passed in results:
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"  {test_name}: {status}")
    
    total = len(results)
    passed = sum(1 for _, p in results if p)
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 ALL TESTS PASSED!")
        return 0
    else:
        print(f"\n⚠️  {total - passed} test(s) failed")
        return 1

if __name__ == "__main__":
    sys.exit(main())
