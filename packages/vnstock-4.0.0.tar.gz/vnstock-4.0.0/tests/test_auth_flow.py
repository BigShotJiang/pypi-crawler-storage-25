#!/usr/bin/env python3
"""
Test script for auth module flow.
Tests: guest mode -> auth with API key -> verify tier limits and financial reports
"""

import os
import sys
import json
from pathlib import Path

# Add vnstock to path
sys.path.insert(0, '/Users/mrthinh/Github/vnstock_dev')

def print_section(title):
    """Print a formatted section header"""
    print("\n" + "="*70)
    print(f"  {title}")
    print("="*70)

def test_guest_mode():
    """Test 1: Guest mode - no API key"""
    print_section("TEST 1: GUEST MODE (No API Key)")
    
    import vnstock
    
    # Check status
    print("\n1. Checking status (should be guest)...")
    vnstock.check_status()
    
    # Try to get tier info
    print("\n2. Getting tier info...")
    try:
        from vnai import get_user_tier
        tier_info = get_user_tier()
        print(f"   Tier: {tier_info['tier']}")
        print(f"   Limits: {tier_info['limits']}")
        assert tier_info['tier'] == 'guest', f"Expected guest, got {tier_info['tier']}"
        assert tier_info['limits']['per_minute'] == 20, f"Expected 20 req/min, got {tier_info['limits']['per_minute']}"
        print("   ✓ Guest tier confirmed: 20 requests/phút")
    except Exception as e:
        print(f"   ✗ Error: {e}")
        return False
    
    # Test financial reports - guest should get 4 periods
    print("\n3. Testing financial reports (guest should get 4 periods)...")
    try:
        from vnstock.explorer.vci import financial
        
        # Get balance sheet for a stock
        df = financial.balance_sheet('ACB', period='year')
        num_periods = len(df)
        print(f"   Balance sheet periods: {num_periods}")
        assert num_periods == 4, f"Expected 4 periods for guest, got {num_periods}"
        print("   ✓ Guest financial reports: 4 periods confirmed")
    except Exception as e:
        print(f"   ✗ Error: {e}")
        return False
    
    print("\n✅ TEST 1 PASSED: Guest mode working correctly")
    return True

def test_auth_with_api_key():
    """Test 2: Auth with API key"""
    print_section("TEST 2: AUTH WITH API KEY")
    
    import vnstock
    
    api_key = "vnstock_64e8a8cc902c72d9fc8b396a539155a4"
    
    print(f"\n1. Registering with API key: {api_key[:20]}...")
    result = vnstock.change_api_key(api_key)
    
    if not result:
        print("   ✗ Failed to register API key")
        return False
    
    print("   ✓ API key registered")
    
    # Check status
    print("\n2. Checking status (should be free)...")
    vnstock.check_status()
    
    # Verify tier changed to free
    print("\n3. Verifying tier changed to free...")
    try:
        from vnai import get_user_tier, refresh_tier_cache
        
        # Force refresh to detect new API key
        refresh_tier_cache()
        
        tier_info = get_user_tier()
        print(f"   Tier: {tier_info['tier']}")
        print(f"   Limits: {tier_info['limits']}")
        assert tier_info['tier'] == 'free', f"Expected free, got {tier_info['tier']}"
        assert tier_info['limits']['per_minute'] == 60, f"Expected 60 req/min, got {tier_info['limits']['per_minute']}"
        print("   ✓ Free tier confirmed: 60 requests/phút")
    except Exception as e:
        print(f"   ✗ Error: {e}")
        return False
    
    print("\n✅ TEST 2 PASSED: Auth with API key working correctly")
    return True

def test_free_tier_limits():
    """Test 3: Free tier limits"""
    print_section("TEST 3: FREE TIER LIMITS")
    
    import vnstock
    
    # Test financial reports - free should get 8 periods
    print("\n1. Testing financial reports (free should get 8 periods)...")
    try:
        from vnstock.explorer.vci import financial
        
        # Get balance sheet for a stock
        df = financial.balance_sheet('ACB', period='year')
        num_periods = len(df)
        print(f"   Balance sheet periods: {num_periods}")
        assert num_periods == 8, f"Expected 8 periods for free, got {num_periods}"
        print("   ✓ Free financial reports: 8 periods confirmed")
    except Exception as e:
        print(f"   ✗ Error: {e}")
        return False
    
    # Test request limits
    print("\n2. Testing request limits (free should allow 60 req/min)...")
    try:
        from vnai import get_user_tier
        tier_info = get_user_tier()
        assert tier_info['limits']['per_minute'] == 60, f"Expected 60 req/min, got {tier_info['limits']['per_minute']}"
        print(f"   ✓ Free tier limits: {tier_info['limits']['per_minute']} requests/phút")
    except Exception as e:
        print(f"   ✗ Error: {e}")
        return False
    
    print("\n✅ TEST 3 PASSED: Free tier limits working correctly")
    return True

def test_api_key_persistence():
    """Test 4: API key persistence"""
    print_section("TEST 4: API KEY PERSISTENCE")
    
    import vnstock
    from vnai import get_user_tier, refresh_tier_cache
    
    print("\n1. Checking if API key persists after refresh...")
    
    # Refresh tier cache
    refresh_tier_cache()
    
    # Check tier
    tier_info = get_user_tier()
    print(f"   Current tier: {tier_info['tier']}")
    assert tier_info['tier'] == 'free', f"Expected free, got {tier_info['tier']}"
    print("   ✓ API key persisted correctly")
    
    print("\n✅ TEST 4 PASSED: API key persistence working correctly")
    return True

def main():
    """Run all tests"""
    print("\n" + "="*70)
    print("  VNSTOCK AUTH MODULE TEST SUITE")
    print("="*70)
    
    results = []
    
    # Test 1: Guest mode
    try:
        results.append(("Guest Mode", test_guest_mode()))
    except Exception as e:
        print(f"\n✗ TEST 1 FAILED: {e}")
        results.append(("Guest Mode", False))
    
    # Test 2: Auth with API key
    try:
        results.append(("Auth with API Key", test_auth_with_api_key()))
    except Exception as e:
        print(f"\n✗ TEST 2 FAILED: {e}")
        results.append(("Auth with API Key", False))
    
    # Test 3: Free tier limits
    try:
        results.append(("Free Tier Limits", test_free_tier_limits()))
    except Exception as e:
        print(f"\n✗ TEST 3 FAILED: {e}")
        results.append(("Free Tier Limits", False))
    
    # Test 4: API key persistence
    try:
        results.append(("API Key Persistence", test_api_key_persistence()))
    except Exception as e:
        print(f"\n✗ TEST 4 FAILED: {e}")
        results.append(("API Key Persistence", False))
    
    # Summary
    print_section("TEST SUMMARY")
    print()
    for test_name, passed in results:
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"  {test_name}: {status}")
    
    total = len(results)
    passed = sum(1 for _, p in results if p)
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 ALL TESTS PASSED!")
        return 0
    else:
        print(f"\n⚠️  {total - passed} test(s) failed")
        return 1

if __name__ == "__main__":
    sys.exit(main())
