import pytest
import importlib
import vnstock
print(f"\nDEBUG: vnstock file: {vnstock.__file__}")
from vnstock.ui._registry import MAP

def test_registry_structure():
    """Verify the basic structure of the MAP registry."""
    assert isinstance(MAP, dict)
    assert "Reference" in MAP
    assert "Market" in MAP
    assert "Fundamental" in MAP
    assert "Retail" in MAP
    assert "Broker" in MAP

def check_entry(entry, path_info):
    """Helper to check a single registry entry."""
    # Redirection entry (tuple of 2 strings)
    if isinstance(entry, tuple) and len(entry) == 2:
        dest_domain, dest_method = entry
        assert dest_domain in MAP, f"Redirection target domain '{dest_domain}' not in MAP (path: {path_info})"
        return

    # Standard entry (tuple of at least 4 items)
    assert isinstance(entry, tuple), f"Entry must be a tuple (path: {path_info})"
    print(f"DEBUG Check entry: {path_info} -> {entry}")
    assert len(entry) >= 4, f"Entry must have at least 4 items (path: {path_info})"
    
    layer, sub_module, class_name, function_name = entry[:4]
    
    # 1. Check module exists
    module_path = ""
    if layer == 'api':
        module_path = f"vnstock.{sub_module}"
    elif layer == 'explorer':
        module_path = f"vnstock.explorer.{sub_module}"
    elif layer == 'connector':
        module_path = f"vnstock.connector.{sub_module}"
    elif layer == 'retail':
        # Retail is a bit special, it might point to another top-level domain
        return
    else:
        pytest.fail(f"Unknown layer '{layer}' (path: {path_info})")

    try:
        module = importlib.import_module(module_path)
    except ImportError:
        pytest.fail(f"Could not import module '{module_path}' (path: {path_info})")

    # 2. Check class/function exists
    if class_name:
        assert hasattr(module, class_name), f"Class '{class_name}' not found in module '{module_path}' (path: {path_info})"
        cls = getattr(module, class_name)
        assert hasattr(cls, function_name), f"Method '{function_name}' not found in class '{class_name}' (path: {path_info})"
    else:
        assert hasattr(module, function_name), f"Function '{function_name}' not found in module '{module_path}' (path: {path_info})"

def test_registry_integrity():
    """Iterate through the entire MAP and verify all references are valid."""
    for domain, methods in MAP.items():
        for method_name, entry in methods.items():
            path = f"{domain}.{method_name}"
            
            # Nested sub-domain handling
            if isinstance(entry, dict):
                for sub_method, sub_entry in entry.items():
                    sub_path = f"{path}.{sub_method}"
                    check_entry(sub_entry, sub_path)
            else:
                check_entry(entry, path)
