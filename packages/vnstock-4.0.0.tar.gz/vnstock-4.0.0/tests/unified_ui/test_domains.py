import pytest
from unittest.mock import MagicMock, patch
from vnstock.ui.market import Market
from vnstock.ui.fundamental import Fundamental
from vnstock.ui.retail import Retail
from vnstock.ui.broker import Broker
import pandas as pd

@pytest.fixture
def mock_df():
    return pd.DataFrame({"test": [1]})

def test_market_equity_ohlcv(mock_df):
    with patch('vnstock.ui._base.BaseUI._dispatch') as mock_dispatch:
        mock_dispatch.return_value = mock_df
        m = Market()
        result = m.equity('VNM').ohlcv()
        # EquityMarket calls 'equity_market'
        mock_dispatch.assert_called_once_with('equity_market', 'ohlcv', source='kbs', resolution='1D', count=100)
        assert result.equals(mock_df)

def test_fundamental_equity_balance_sheet(mock_df):
    with patch('vnstock.ui._base.BaseUI._dispatch') as mock_dispatch:
        mock_dispatch.return_value = mock_df
        f = Fundamental()
        result = f.equity('VNM').balance_sheet()
        # EquityFundamental calls 'equity_fundamental'
        mock_dispatch.assert_called_once_with('equity_fundamental', 'balance_sheet', period='fiscal_year')
        assert result.equals(mock_df)

def test_retail_gold(mock_df):
    with patch('vnstock.ui.domains.retail.commodity.Retail._dispatch') as mock_dispatch:
        mock_dispatch.return_value = mock_df
        r = Retail()
        result = r.gold(source='sjc')
        # Retail domain calls 'retail', 'gold_price_sjc' (legacy logic in commodity.py)
        mock_dispatch.assert_called_once_with('retail', 'gold_price_sjc', date=None)
        assert result.equals(mock_df)

def test_broker_dnse_account(mock_df):
    with patch('vnstock.ui._base.BaseUI._dispatch') as mock_dispatch:
        mock_dispatch.return_value = mock_df
        b = Broker()
        result = b.dnse.account()
        # DNSEBroker calls 'dnse', 'account'
        mock_dispatch.assert_called_once_with('dnse', 'account')
        assert result.equals(mock_df)
