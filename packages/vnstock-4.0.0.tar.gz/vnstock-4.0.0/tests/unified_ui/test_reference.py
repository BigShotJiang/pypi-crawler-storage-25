import pytest
from unittest.mock import MagicMock, patch
from vnstock.ui.reference import Reference
import pandas as pd

@pytest.fixture
def mock_df():
    return pd.DataFrame({"symbol": ["VNM"], "price": [100]})

def test_reference_equity_list(mock_df):
    with patch('vnstock.ui._base.BaseUI._dispatch') as mock_dispatch:
        mock_dispatch.return_value = mock_df
        ref = Reference()
        result = ref.equity().list()
        
        mock_dispatch.assert_called_once_with('Reference', 'equity', 'list', source='kbs')
        assert result.equals(mock_df)

def test_reference_company_overview(mock_df):
    with patch('vnstock.ui._base.BaseUI._dispatch') as mock_dispatch:
        mock_dispatch.return_value = mock_df
        ref = Reference()
        # Test the detail UI (CompanyReference)
        result = ref.company('VNM').info()
        
        mock_dispatch.assert_called_once_with('company', 'info', source='kbs')
        assert result.equals(mock_df)

def test_reference_market_status(mock_df):
    with patch('vnstock.ui._base.BaseUI._dispatch') as mock_dispatch:
        mock_dispatch.return_value = mock_df
        ref = Reference()
        result = ref.market().status()
        
        mock_dispatch.assert_called_once_with('Reference', 'market', 'status')
        assert result.equals(mock_df)

def test_reference_futures_list(mock_df):
    with patch('vnstock.ui._base.BaseUI._dispatch') as mock_dispatch:
        mock_dispatch.return_value = mock_df
        ref = Reference()
        result = ref.futures().list()
        
        mock_dispatch.assert_called_once_with('Reference', 'futures', 'list', source='kbs')
        assert result.equals(mock_df)
