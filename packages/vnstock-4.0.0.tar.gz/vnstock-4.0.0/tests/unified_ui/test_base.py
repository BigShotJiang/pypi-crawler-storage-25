import pytest
from unittest.mock import MagicMock, patch
from vnstock.ui._base import BaseUI
import pandas as pd

class MockUI(BaseUI):
    def test_method(self, *args, **kwargs):
        return self._dispatch('MockDomain', 'test_method', *args, **kwargs)

    def test_nested(self, *args, **kwargs):
        return self._dispatch('MockDomain', 'sub', 'method', *args, **kwargs)

@pytest.fixture
def mock_registry():
    mock_map = {
        "MockDomain": {
            "test_method": ("api", "mock_module", "MockClass", "mock_func", "MOCK", "DataFrame", "Mock doc"),
            "sub": {
                "method": ("explorer", "mock_explorer", None, "mock_exp_func", "MOCK", "DataFrame", "Mock sub doc")
            }
        },
        "RedirDomain": {
            "target": ("MockDomain", "test_method")
        }
    }
    with patch('vnstock.ui._registry.MAP', mock_map):
        yield mock_map

def test_dispatch_class_based(mock_registry):
    ui = MockUI()
    
    with patch('importlib.import_module') as mock_import:
        mock_module = MagicMock()
        mock_class_inst = MagicMock()
        mock_class = MagicMock(return_value=mock_class_inst)
        mock_import.return_value = mock_module
        setattr(mock_module, "MockClass", mock_class)
        
        mock_class_inst.mock_func.return_value = pd.DataFrame({"test": [1]})
        
        result = ui.test_method(param="val")
        
        # Verify class instantiation and method call
        assert mock_class.call_count >= 1
        mock_class_inst.mock_func.assert_called_once_with(param="val")
        assert isinstance(result, pd.DataFrame)

def test_dispatch_module_based(mock_registry):
    ui = MockUI()
    
    with patch('importlib.import_module') as mock_import:
        mock_module = MagicMock()
        mock_import.return_value = mock_module
        
        mock_module.mock_exp_func.return_value = pd.DataFrame({"test": [2]})
        
        result = ui.test_nested()
        
        # Verify function call
        mock_module.mock_exp_func.assert_called_once()
        assert result.iloc[0]["test"] == 2

def test_dispatch_redirection(mock_registry):
    ui = BaseUI()
    
    with patch('importlib.import_module') as mock_import:
        mock_module = MagicMock()
        mock_class_inst = MagicMock()
        mock_class = MagicMock(return_value=mock_class_inst)
        mock_import.return_value = mock_module
        setattr(mock_module, "MockClass", mock_class)
        
        mock_class_inst.mock_func.return_value = "FinalResult"
        
        # RedirDomain.target -> MockDomain.test_method
        result = ui._dispatch('RedirDomain', 'target')
        
        assert result == "FinalResult"
        mock_class_inst.mock_func.assert_called_once()

def test_dispatch_invalid_domain():
    ui = BaseUI()
    # The current implementation returns a generic "not implemented" error
    with pytest.raises(AttributeError, match="Method 'method' not implemented for domain 'Invalid'"):
        ui._dispatch('Invalid', 'method')

def test_dispatch_invalid_method(mock_registry):
    ui = BaseUI()
    with pytest.raises(AttributeError, match="Method 'invalid' not implemented for domain 'MockDomain'"):
        ui._dispatch('MockDomain', 'invalid')
