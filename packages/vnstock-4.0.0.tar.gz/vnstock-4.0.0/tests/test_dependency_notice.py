"""
Test suite for the dependency notice system.
Demonstrates how the new version-specific dependency checking works.
"""

import sys
import pytest
from unittest.mock import patch, MagicMock
from packaging import version


def test_version_requirements_structure():
    """Verify VERSION_REQUIREMENTS has correct structure."""
    from vnstock.constants import VERSION_REQUIREMENTS
    
    assert isinstance(VERSION_REQUIREMENTS, dict)
    assert "3.4.0" in VERSION_REQUIREMENTS
    
    # Each version should have package requirements
    for vnstock_ver, requirements in VERSION_REQUIREMENTS.items():
        assert isinstance(requirements, dict)
        assert "vnai" in requirements
        assert "requests" in requirements
        assert "pandas" in requirements


def test_version_notices_structure():
    """Verify VERSION_NOTICES has correct structure."""
    from vnstock.constants import VERSION_NOTICES
    
    assert isinstance(VERSION_NOTICES, dict)
    
    for vnstock_ver, notice in VERSION_NOTICES.items():
        assert "title" in notice
        assert "release_url" in notice
        assert "critical_notices" in notice
        assert "warnings" in notice
        assert isinstance(notice["critical_notices"], list)
        assert isinstance(notice["warnings"], list)


def test_python_version_support_structure():
    """Verify PYTHON_VERSION_SUPPORT has correct structure."""
    from vnstock.constants import PYTHON_VERSION_SUPPORT
    
    assert isinstance(PYTHON_VERSION_SUPPORT, dict)
    
    for vnstock_ver, py_versions in PYTHON_VERSION_SUPPORT.items():
        assert isinstance(py_versions, list)
        for py_ver in py_versions:
            assert isinstance(py_ver, str)
            parts = py_ver.split(".")
            assert len(parts) == 2


def test_version_comparison():
    """Test version parsing and comparison logic."""
    v1 = version.parse("2.2.3")
    v2 = version.parse("2.9.0")
    
    assert v1 < v2
    assert v2 > v1


def test_detect_environment():
    """Test environment detection."""
    from vnstock.core.utils.upgrade import detect_environment
    
    env = detect_environment()
    assert env in ["Terminal", "Jupyter", "Google Colab", "Other"]


@patch('vnstock.core.utils.upgrade.get_version')
def test_check_dependency_compatibility_missing_package(mock_get_version):
    """Test detection of missing required package."""
    from vnstock.core.utils.upgrade import _check_dependency_compatibility
    
    def side_effect(package):
        if package == "vnstock":
            return "3.4.0"
        raise Exception(f"{package} not installed")
    
    mock_get_version.side_effect = side_effect
    
    has_issues, critical_issues, warnings_list = _check_dependency_compatibility()
    
    # Should detect missing packages
    assert has_issues
    assert len(critical_issues) > 0
    assert any("not installed" in issue for issue in critical_issues)


@patch('vnstock.core.utils.upgrade.get_version')
def test_check_dependency_compatibility_outdated_version(mock_get_version):
    """Test detection of outdated dependency version."""
    from vnstock.core.utils.upgrade import _check_dependency_compatibility
    
    def side_effect(package):
        versions = {
            "vnstock": "3.4.0",
            "vnai": "2.0.0",  # Too old, requires 2.2.3
            "requests": "2.31.0",
            "pandas": "1.5.0",
            "beautifulsoup4": "4.11.0",
            "packaging": "21.0",
        }
        return versions.get(package, "1.0.0")
    
    mock_get_version.side_effect = side_effect
    
    has_issues, critical_issues, warnings_list = _check_dependency_compatibility()
    
    assert has_issues
    assert any("vnai" in issue and "2.0.0" in issue for issue in critical_issues)


@patch('vnstock.core.utils.upgrade.get_version')
def test_check_dependency_compatibility_all_compatible(mock_get_version):
    """Test when all dependencies are compatible."""
    from vnstock.core.utils.upgrade import _check_dependency_compatibility
    
    def side_effect(package):
        versions = {
            "vnstock": "3.4.0",
            "vnai": "2.2.3",
            "requests": "2.31.0",
            "pandas": "1.5.0",
            "beautifulsoup4": "4.11.0",
            "packaging": "21.0",
        }
        return versions.get(package, "1.0.0")
    
    mock_get_version.side_effect = side_effect
    
    has_issues, critical_issues, warnings_list = _check_dependency_compatibility()
    
    # Should not have critical issues for 3.4.0 (no notices defined)
    assert not has_issues or len(critical_issues) == 0


@patch('vnstock.core.utils.upgrade.get_version')
def test_python_version_compatibility_check(mock_get_version):
    """Test Python version compatibility checking."""
    from vnstock.core.utils.upgrade import _check_dependency_compatibility
    
    def side_effect(package):
        versions = {
            "vnstock": "3.4.0",
            "vnai": "2.2.3",
            "requests": "2.31.0",
            "pandas": "1.5.0",
            "beautifulsoup4": "4.11.0",
            "packaging": "21.0",
        }
        return versions.get(package, "1.0.0")
    
    mock_get_version.side_effect = side_effect
    
    # Mock Python version to something unsupported
    with patch('sys.version_info') as mock_version:
        mock_version.major = 3
        mock_version.minor = 9  # Not in supported list
        
        has_issues, critical_issues, warnings_list = _check_dependency_compatibility()
        
        # Should have warning about Python version
        assert any("Python" in warning for warning in warnings_list)


def test_version_notice_content_for_3_5_0():
    """Test that 3.5.0 has appropriate critical notices."""
    from vnstock.constants import VERSION_NOTICES
    
    notice_3_5 = VERSION_NOTICES.get("3.5.0", {})
    
    assert notice_3_5
    assert len(notice_3_5["critical_notices"]) > 0
    assert any("vnai" in notice for notice in notice_3_5["critical_notices"])


def test_requirements_version_ordering():
    """Test that requirements are properly ordered (older to newer)."""
    from vnstock.constants import VERSION_REQUIREMENTS
    
    versions = list(VERSION_REQUIREMENTS.keys())
    parsed_versions = [version.parse(v) for v in versions]
    
    # Verify versions are in ascending order
    for i in range(len(parsed_versions) - 1):
        assert parsed_versions[i] <= parsed_versions[i + 1]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
