#!/usr/bin/env python3
"""
Test suite for Unified Interval Standard.

Validates that all providers support the standardized interval format.
"""

import sys
from typing import List, Tuple
from vnstock.core.utils.interval import normalize_interval
from vnstock.core.types import TimeFrame


def test_normalize_interval() -> bool:
    """Test normalize_interval() with all supported formats."""
    
    test_cases: List[Tuple[str, TimeFrame]] = [
        # Aliases
        ('m', TimeFrame.MINUTE_1),
        ('h', TimeFrame.HOUR_1),
        ('d', TimeFrame.DAY_1),
        ('w', TimeFrame.WEEK_1),
        ('M', TimeFrame.MONTH_1),
        # Standard formats
        ('1m', TimeFrame.MINUTE_1),
        ('5m', TimeFrame.MINUTE_5),
        ('15m', TimeFrame.MINUTE_15),
        ('30m', TimeFrame.MINUTE_30),
        ('1h', TimeFrame.HOUR_1),
        ('4h', TimeFrame.HOUR_4),
        ('1d', TimeFrame.DAY_1),
        ('1D', TimeFrame.DAY_1),
        ('1w', TimeFrame.WEEK_1),
        ('1W', TimeFrame.WEEK_1),
        ('1M', TimeFrame.MONTH_1),
        # Human readable
        ('minute', TimeFrame.MINUTE_1),
        ('hour', TimeFrame.HOUR_1),
        ('day', TimeFrame.DAY_1),
        ('week', TimeFrame.WEEK_1),
        ('month', TimeFrame.MONTH_1),
    ]
    
    print("Testing normalize_interval() with all formats:\n")
    passed = 0
    failed = 0
    
    for interval_input, expected in test_cases:
        try:
            result = normalize_interval(interval_input)
            if result == expected:
                print(f"  ✅ '{interval_input:8}' → {result.value:3}")
                passed += 1
            else:
                expected_val = expected.value
                print(f"  ❌ '{interval_input:8}' → {result.value:3} "
                      f"(exp: {expected_val})")
                failed += 1
        except Exception as e:
            print(f"  ❌ '{interval_input:8}' → Error: {str(e)[:40]}")
            failed += 1
    
    print(f"\nResult: {passed} passed, {failed} failed")
    return failed == 0


def test_invalid_intervals() -> bool:
    """Test error handling for invalid intervals."""
    
    print("\nTesting error handling for invalid intervals:\n")
    
    invalid_intervals = [
        'invalid',
        'xyz',
        'minute5',  # Should be '5m'
        'hour4',    # Should be '4h'
        '2h',       # Only 1h and 4h supported
    ]
    
    passed = 0
    failed = 0
    
    for interval_input in invalid_intervals:
        try:
            result = normalize_interval(interval_input)
            print(f"  ❌ '{interval_input}' should have failed "
                  f"but returned {result}")
            failed += 1
        except ValueError:
            print(f"  ✅ '{interval_input}' correctly rejected")
            passed += 1
        except Exception as e:
            print(f"  ❌ '{interval_input}' unexpected error: "
                  f"{str(e)[:40]}")
            failed += 1
    
    print(f"\nResult: {passed} passed, {failed} failed")
    return failed == 0


def test_default_interval() -> bool:
    """Test default interval (None)."""
    
    print("\nTesting default interval handling:\n")
    
    try:
        result = normalize_interval(None)
        if result == TimeFrame.DAY_1:
            print(f"  ✅ None defaults to {result.value}")
            return True
        else:
            print(f"  ❌ None should default to D but got {result.value}")
            return False
    except Exception as e:
        print(f"  ❌ Error: {str(e)}")
        return False


def test_timeframe_enum() -> bool:
    """Test passing TimeFrame enum directly."""
    
    print("\nTesting direct TimeFrame enum usage:\n")
    
    test_cases: List[TimeFrame] = [
        TimeFrame.MINUTE_1,
        TimeFrame.HOUR_1,
        TimeFrame.DAY_1,
        TimeFrame.WEEK_1,
        TimeFrame.MONTH_1,
    ]
    
    passed = 0
    failed = 0
    
    for timeframe in test_cases:
        try:
            result = normalize_interval(timeframe)
            if result == timeframe:
                print(f"  ✅ {timeframe.name:15} → {result.value}")
                passed += 1
            else:
                expected_val = timeframe.value
                print(f"  ❌ {timeframe.name:15} → {result.value} "
                      f"(expected {expected_val})")
                failed += 1
        except Exception as e:
            print(f"  ❌ {timeframe.name:15} → Error: {str(e)[:40]}")
            failed += 1
    
    print(f"\nResult: {passed} passed, {failed} failed")
    return failed == 0


def main():
    """Run all tests."""
    
    print("=" * 70)
    print("VNSTOCK UNIFIED INTERVAL STANDARD - TEST SUITE")
    print("=" * 70)
    
    results: List[Tuple[str, bool]] = []
    
    results.append(("normalize_interval()", test_normalize_interval()))
    results.append(("Invalid intervals", test_invalid_intervals()))
    results.append(("Default interval", test_default_interval()))
    results.append(("TimeFrame enum", test_timeframe_enum()))
    
    print("\n" + "=" * 70)
    print("TEST SUMMARY")
    print("=" * 70)
    
    passed_tests = sum(1 for _, result in results if result)
    total_tests = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"  {status}: {test_name}")
    
    print(f"\nTotal: {passed_tests}/{total_tests} test suites passed")
    
    if passed_tests == total_tests:
        msg = ("✅ All tests passed! "
               "Unified interval standard working correctly.")
        print(f"\n{msg}")
        return 0
    else:
        print(f"\n❌ {total_tests - passed_tests} test suite(s) failed.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
