"""
Test vnstock wrapper integration with FMP and XNO sources.
"""
from vnstock import Quote
import os

# Test FMP
print('=== Testing FMP with vnstock wrapper ===')
os.environ['FMP_TOKEN'] = 'kOCBp18Ju6QckDMARNAz3BKPvIW8JXTJ'
quote_fmp = Quote(symbol='AAPL', source='FMP')
print(f'✅ FMP Quote initialized: {quote_fmp}')

# Test realtime method
df_realtime = quote_fmp.realtime()
if df_realtime is not None and not df_realtime.empty:
    print(f'✅ FMP realtime() returned {len(df_realtime)} rows')
    print(df_realtime.head(3))
else:
    print('❌ FMP realtime() failed')

print('\n=== Testing XNO with vnstock wrapper ===')
os.environ['XNO_API_KEY'] = 'azzLsQ5wWeldBMxk3IM4ZAm7BuOhxYKH0X6Xz4fKo3IUQiQhHAw1LNrNFJ'
quote_xno = Quote(symbol='HPG', source='XNO')
print(f'✅ XNO Quote initialized: {quote_xno}')

# Test history method
df_history = quote_xno.history(timeframe='m')
if df_history is not None and not df_history.empty:
    print(f'✅ XNO history(timeframe="m") returned {len(df_history)} rows')
    print(df_history.head(3))
    print(f'Date range: {df_history["time"].min()} to {df_history["time"].max()}')
else:
    print('❌ XNO history() failed')
