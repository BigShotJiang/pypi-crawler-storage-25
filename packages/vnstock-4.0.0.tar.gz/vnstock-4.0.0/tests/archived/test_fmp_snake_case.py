"""
Test script to verify FMP Quote class converts column names to snake_case.
"""

import pandas as pd
from unittest.mock import patch
from vnstock.connector.fmp import Quote


def test_short_method_snake_case():
    """Test that short() method converts camelCase columns to snake_case."""
    print("\n" + "=" * 70)
    print("Test 1: short() method - Snake case conversion")
    print("=" * 70)
    
    # Mock API response with camelCase column names
    mock_response = pd.DataFrame({
        'symbol': ['AAPL'],
        'price': [150.5],
        'change': [-2.5],
        'changePercentage': [-1.64],
        'volume': [50000000],
        'dayHigh': [152.0],
        'dayLow': [149.0],
        'yearHigh': [199.62],
        'yearLow': [124.17],
        'marketCap': [2400000000000],
        'priceAvg50': [155.23],
        'priceAvg200': [145.67],
        'previousClose': [153.0],
        'timestamp': [1699000000]
    })
    
    with patch(
        'vnstock.connector.fmp.quote.make_fmp_request',
        return_value=mock_response
    ):
        quote = Quote('AAPL', api_key='test_key', show_log=False)
        result = quote.short()
    
    print("\nOriginal columns (camelCase):")
    print(list(mock_response.columns))
    
    print("\nConverted columns (snake_case):")
    print(list(result.columns))
    
    # Verify all columns are in snake_case (no camelCase)
    for col in result.columns:
        is_snake = col.islower() or '_' in col
        assert is_snake, f"Column '{col}' is not in snake_case!"
    
    # Check specific conversions
    expected_cols = {
        'change_percentage', 'day_high', 'day_low', 'year_high', 'year_low',
        'market_cap', 'price_avg50', 'previous_close'
    }
    
    actual_cols = set(result.columns)
    for expected_col in expected_cols:
        if expected_col not in actual_cols:
            print(f"⚠️  Warning: Expected column '{expected_col}' not found")
        else:
            print(f"✅ Column '{expected_col}' correctly converted")
    
    print("\n✅ Test 1 PASSED: All columns are in snake_case format")


def test_full_method_snake_case():
    """Test that full() method converts camelCase columns to snake_case."""
    print("\n" + "=" * 70)
    print("Test 2: full() method - Snake case conversion")
    print("=" * 70)
    
    # Mock API response with camelCase column names
    mock_response = pd.DataFrame({
        'symbol': ['AAPL'],
        'name': ['Apple Inc.'],
        'price': [150.5],
        'changePercentage': [-1.64],
        'change': [-2.5],
        'volume': [50000000],
        'dayLow': [149.0],
        'dayHigh': [152.0],
        'yearHigh': [199.62],
        'yearLow': [124.17],
        'marketCap': [2400000000000],
        'priceAvg50': [155.23],
        'priceAvg200': [145.67],
        'exchange': ['NASDAQ'],
        'open': [152.0],
        'previousClose': [153.0],
        'timestamp': [1699000000]
    })
    
    with patch(
        'vnstock.connector.fmp.quote.make_fmp_request',
        return_value=mock_response
    ):
        quote = Quote('AAPL', api_key='test_key', show_log=False)
        result = quote.full()
    
    print("\nOriginal columns (camelCase):")
    print(list(mock_response.columns))
    
    print("\nConverted columns (snake_case):")
    print(list(result.columns))
    
    # Verify all columns are in snake_case
    for col in result.columns:
        is_snake = col.islower() or '_' in col
        assert is_snake, f"Column '{col}' is not in snake_case!"
    
    expected_cols = {
        'change_percentage', 'day_low', 'day_high', 'year_high', 'year_low',
        'market_cap', 'price_avg50', 'price_avg200', 'previous_close'
    }
    
    actual_cols = set(result.columns)
    for expected_col in expected_cols:
        if expected_col not in actual_cols:
            print(f"⚠️  Warning: Expected column '{expected_col}' not found")
        else:
            print(f"✅ Column '{expected_col}' correctly converted")
    
    print("\n✅ Test 2 PASSED: All columns are in snake_case format")


def test_history_method_snake_case():
    """Test that history() method converts camelCase columns to snake_case."""
    print("\n" + "=" * 70)
    print("Test 3: history() method - Snake case conversion")
    print("=" * 70)
    
    # Mock API response with camelCase column names and OHLCV structure
    mock_response = pd.DataFrame({
        'date': ['2024-01-01', '2024-01-02'],
        'open': [150.0, 151.0],
        'high': [152.0, 153.0],
        'low': [149.0, 150.0],
        'close': [151.5, 152.5],
        'volume': [50000000, 48000000]
    })
    
    with patch(
        'vnstock.connector.fmp.quote.make_fmp_request',
        return_value=mock_response
    ):
        quote = Quote('AAPL', api_key='test_key', show_log=False)
        result = quote.history(start='2024-01-01', end='2024-01-02')
    
    print("\nOriginal columns:")
    print(list(mock_response.columns))
    
    print("\nConverted columns:")
    print(list(result.columns))
    
    # Check that 'date' was converted to 'time' (OHLCV mapping)
    msg = "Column 'time' (mapped from 'date') not found"
    assert 'time' in result.columns, msg
    print("✅ Column 'date' correctly mapped to 'time'")
    
    # Verify all columns are in snake_case
    for col in result.columns:
        is_snake = col.islower() or '_' in col
        assert is_snake, f"Column '{col}' is not in snake_case!"
    
    print("\n✅ Test 3 PASSED: All columns are in snake_case format")


def test_intraday_method_snake_case():
    """Test that intraday() method converts camelCase columns to snake_case."""
    print("\n" + "=" * 70)
    print("Test 4: intraday() method - Snake case conversion")
    print("=" * 70)
    
    # Mock API response with camelCase column names
    mock_response = pd.DataFrame({
        'date': ['2024-01-01 09:30:00', '2024-01-01 09:35:00'],
        'open': [150.0, 150.5],
        'high': [151.0, 151.5],
        'low': [149.5, 150.0],
        'close': [150.8, 151.2],
        'volume': [5000000, 4800000]
    })
    
    with patch(
        'vnstock.connector.fmp.quote.make_fmp_request',
        return_value=mock_response
    ):
        quote = Quote('AAPL', api_key='test_key', show_log=False)
        result = quote.intraday(interval='5m')
    
    print("\nOriginal columns:")
    print(list(mock_response.columns))
    
    print("\nConverted columns:")
    print(list(result.columns))
    
    # Check that 'date' was converted to 'time'
    assert 'time' in result.columns, \
        "Column 'time' (mapped from 'date') not found"
    print("✅ Column 'date' correctly mapped to 'time'")
    
    # Verify all columns are in snake_case
    for col in result.columns:
        is_snake = col.islower() or '_' in col
        assert is_snake, f"Column '{col}' is not in snake_case!"
    
    print("\n✅ Test 4 PASSED: All columns are in snake_case format")


def test_complex_camel_case():
    """Test conversion of complex camelCase names."""
    print("\n" + "=" * 70)
    print("Test 5: Complex camelCase conversions")
    print("=" * 70)
    
    from vnstock.core.utils.parser import camel_to_snake
    
    test_cases = [
        ('priceAvg50', 'price_avg50'),
        ('yearHigh', 'year_high'),
        ('marketCap', 'market_cap'),
        ('previousClose', 'previous_close'),
        ('changePercentage', 'change_percentage'),
        ('symbol', 'symbol'),  # No change for already lowercase
        ('EPS', 'e_p_s'),  # All caps handling
    ]
    
    print("\nTesting camel_to_snake conversions:")
    for input_val, expected in test_cases:
        result = camel_to_snake(input_val)
        status = "✅" if result == expected else "❌"
        print(f"{status} {input_val:20} → {result:20} "
              f"(expected: {expected})")
        msg = f"Failed: {input_val} → {result} (expected {expected})"
        assert result == expected, msg
    
    print("\n✅ Test 5 PASSED: All complex camelCase conversions are correct")


if __name__ == '__main__':
    print("\n" + "=" * 70)
    print("FMP Quote snake_case Conversion Tests")
    print("=" * 70)
    
    try:
        test_short_method_snake_case()
        test_full_method_snake_case()
        test_history_method_snake_case()
        test_intraday_method_snake_case()
        test_complex_camel_case()
        
        print("\n" + "=" * 70)
        print("✅ ALL TESTS PASSED!")
        print("=" * 70)
        
    except AssertionError as e:
        print(f"\n❌ TEST FAILED: {e}")
        exit(1)
    except Exception as e:
        print(f"\n❌ UNEXPECTED ERROR: {e}")
        import traceback
        traceback.print_exc()
        exit(1)
