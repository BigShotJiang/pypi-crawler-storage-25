#!/usr/bin/env python3
"""
Test script để kiểm tra tất cả providers đã được đăng ký đúng trong ProviderRegistry.
"""

from vnstock.core.registry import ProviderRegistry


def test_all_registrations():
    """Kiểm tra tất cả providers đã được đăng ký."""
    
    print("=" * 60)
    print("KIỂM TRA PROVIDER REGISTRY")
    print("=" * 60)
    
    # Expected registrations
    expected = {
        'quote': ['vci', 'tcbs', 'msn', 'fmp'],
        'listing': ['vci', 'msn'],
        'company': ['vci', 'tcbs'],
        'financial': ['vci', 'tcbs'],
        'trading': ['vci', 'tcbs']
    }
    
    all_good = True
    
    for provider_type, sources in expected.items():
        print(f"\n[{provider_type}]")
        available = ProviderRegistry.list_available(provider_type)
        
        for source in sources:
            if source in available:
                try:
                    provider_cls = ProviderRegistry.get(provider_type, source)
                    print(f"  ✓ {source:10} -> {provider_cls.__module__}.{provider_cls.__name__}")
                except Exception as e:
                    print(f"  ✗ {source:10} -> ERROR: {e}")
                    all_good = False
            else:
                print(f"  ✗ {source:10} -> NOT REGISTERED")
                all_good = False
    
    print("\n" + "=" * 60)
    
    if all_good:
        print("✅ TẤT CẢ PROVIDERS ĐÃ ĐƯỢC ĐĂNG KÝ ĐÚNG!")
    else:
        print("❌ CÓ LỖI TRONG VIỆC ĐĂNG KÝ PROVIDERS!")
    
    print("=" * 60)
    
    return all_good


def test_adapter_initialization():
    """Test khởi tạo các adapter."""
    
    print("\n" + "=" * 60)
    print("KIỂM TRA KHỞI TẠO ADAPTERS")
    print("=" * 60)
    
    from vnstock import Listing, Company, Trading, Quote
    from vnstock.api.financial import Finance
    
    tests = [
        ('Listing VCI', lambda: Listing(source='VCI')),
        # Skip MSN tests vì cần API key và có thể timeout
        # ('Listing MSN', lambda: Listing(source='MSN')),
        ('Quote VCI', lambda: Quote(source='VCI', symbol='TCB')),
        ('Quote TCBS', lambda: Quote(source='TCBS', symbol='TCB')),
        # MSN Quote cần symbol_id đặc biệt, bỏ qua test này
        # ('Quote MSN', lambda: Quote(source='MSN', symbol='TCB')),
        ('Company VCI', lambda: Company(source='VCI', symbol='TCB')),
        ('Company TCBS', lambda: Company(source='TCBS', symbol='TCB')),
        ('Finance VCI', lambda: Finance(source='VCI', symbol='TCB')),
        ('Finance TCBS', lambda: Finance(source='TCBS', symbol='TCB')),
        ('Trading VCI', lambda: Trading(source='VCI', symbol='TCB')),
        ('Trading TCBS', lambda: Trading(source='TCBS', symbol='TCB')),
    ]
    
    all_good = True
    
    for name, init_func in tests:
        try:
            init_func()
            print(f"  ✓ {name}")
        except Exception as e:
            print(f"  ✗ {name} -> ERROR: {e}")
            all_good = False
    
    print("=" * 60)
    
    if all_good:
        print("✅ TẤT CẢ ADAPTERS KHỞI TẠO THÀNH CÔNG!")
    else:
        print("❌ CÓ LỖI KHI KHỞI TẠO ADAPTERS!")
    
    print("=" * 60)
    
    return all_good


if __name__ == '__main__':
    print("\n🔍 BẮT ĐẦU KIỂM TRA TÍCH HỢP PROVIDER REGISTRY\n")
    
    registry_ok = test_all_registrations()
    adapter_ok = test_adapter_initialization()
    
    print("\n" + "=" * 60)
    print("KẾT QUẢ TỔNG QUAN")
    print("=" * 60)
    print(f"Provider Registry: {'✅ PASS' if registry_ok else '❌ FAIL'}")
    print(f"Adapter Init:      {'✅ PASS' if adapter_ok else '❌ FAIL'}")
    print("=" * 60)
    
    if registry_ok and adapter_ok:
        print("\n🎉 TẤT CẢ KIỂM TRA ĐỀU THÀNH CÔNG!")
        exit(0)
    else:
        print("\n⚠️  MỘT SỐ KIỂM TRA THẤT BẠI!")
        exit(1)
