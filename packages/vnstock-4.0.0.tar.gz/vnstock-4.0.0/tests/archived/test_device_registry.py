"""
Test DeviceRegistry functionality
Usage: python3 -m pytest tests/test_device_registry.py -v
"""

import pytest
import json
import tempfile
from pathlib import Path
from unittest.mock import patch
from vnai.scope.device import device_registry, DeviceRegistry


class TestDeviceRegistry:
    """Test DeviceRegistry singleton class"""

    def test_singleton_instance(self):
        """Test that DeviceRegistry is a singleton"""
        registry1 = DeviceRegistry()
        registry2 = DeviceRegistry()
        assert registry1 is registry2, "DeviceRegistry should be singleton"

    def test_device_registry_initialization(self):
        """Test device registry initializes correctly"""
        registry = device_registry
        assert registry is not None, "Device registry should be initialized"
        assert hasattr(registry, 'registry'), "Should have registry dict"
        assert hasattr(registry, 'registry_path'), "Should have registry_path"

    def test_get_device_id_empty_registry(self):
        """Test get_device_id returns None for empty registry"""
        with patch.object(device_registry, 'registry', None):
            result = device_registry.get_device_id()
            assert result is None, "Should return None for empty registry"

    def test_get_device_id_with_cached_id(self):
        """Test get_device_id returns cached ID"""
        test_id = "test_device_id_12345"
        with patch.object(device_registry, 'registry',
                          {"device_id": test_id}):
            result = device_registry.get_device_id()
            assert result == test_id, "Should return cached device_id"

    def test_needs_reregistration_no_registry(self):
        """Test needs_reregistration returns True when no registry"""
        with patch.object(device_registry, 'registry', None):
            result = device_registry.needs_reregistration("1.0.0")
            assert result is True, "Should need registration if no registry"

    def test_needs_reregistration_same_version(self):
        """Test needs_reregistration returns False for same version"""
        mock_registry = {
            "device_id": "test_id",
            "version": "1.2.3"
        }
        with patch.object(device_registry, 'registry', mock_registry):
            result = device_registry.needs_reregistration("1.2.3")
            assert result is False, "Should not need re-registration"

    def test_needs_reregistration_different_version(self):
        """Test needs_reregistration returns True for version change"""
        mock_registry = {
            "device_id": "test_id",
            "version": "1.2.3"
        }
        with patch.object(device_registry, 'registry', mock_registry):
            result = device_registry.needs_reregistration("1.2.4")
            msg = "Should need re-registration on version bump"
            assert result is True, msg

    def test_register_creates_device_id(self):
        """Test register method creates device_id"""
        system_info = {
            "platform": "darwin",
            "python_version": "3.11.5"
        }
        version = "1.2.3"

        with patch.object(device_registry, '_save_registry'):
            device_registry.register(system_info, version)

            assert device_registry.registry is not None
            assert "device_id" in device_registry.registry
            assert "version" in device_registry.registry
            assert device_registry.registry["version"] == version

    def test_register_saves_to_file(self):
        """Test register saves registry to file"""
        system_info = {"platform": "darwin"}
        version = "1.2.3"

        with tempfile.TemporaryDirectory() as tmpdir:
            registry_path = Path(tmpdir) / "device_registry.json"
            with patch.object(device_registry, 'registry_path',
                              registry_path):
                device_registry.register(system_info, version)
                msg = "Registry file should be created"
                assert registry_path.exists(), msg

    def test_get_registry_returns_all_data(self):
        """Test get_registry returns complete registry"""
        mock_registry = {
            "device_id": "test_id",
            "version": "1.2.3",
            "registered_date": "2025-10-24T00:00:00"
        }
        with patch.object(device_registry, 'registry', mock_registry):
            result = device_registry.get_registry()
            assert result == mock_registry, "Should return full registry"

    def test_get_register_date(self):
        """Test get_register_date returns registration date"""
        test_date = "2025-10-24T10:30:00"
        mock_registry = {
            "device_id": "test_id",
            "registered_date": test_date
        }
        with patch.object(device_registry, 'registry', mock_registry):
            result = device_registry.get_register_date()
            assert result == test_date, "Should return registered_date"

    def test_get_register_date_no_registry(self):
        """Test get_register_date returns None for empty registry"""
        with patch.object(device_registry, 'registry', None):
            result = device_registry.get_register_date()
            assert result is None, "Should return None when no registry"

    def test_update_version_changes_version(self):
        """Test update_version updates registry version"""
        mock_registry = {
            "device_id": "test_id",
            "version": "1.2.3"
        }
        with patch.object(device_registry, 'registry', mock_registry):
            with patch.object(device_registry, '_save_registry'):
                device_registry.update_version("1.2.4")
                assert mock_registry["version"] == "1.2.4"

    def test_thread_safety(self):
        """Test DeviceRegistry is thread-safe"""
        import threading

        instances = []

        def get_instance():
            instances.append(DeviceRegistry())

        threads = [threading.Thread(target=get_instance)
                   for _ in range(10)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()

        # All instances should be the same
        for instance in instances[1:]:
            assert instance is instances[0], "All instances should be same"


class TestDeviceRegistryIntegration:
    """Integration tests for DeviceRegistry"""

    def test_registration_workflow(self):
        """Test complete registration workflow"""
        system_info = {
            "platform": "darwin",
            "python_version": "3.11.5"
        }
        version = "1.2.3"

        # Before registration
        needs_reg = device_registry.needs_reregistration(version)
        assert needs_reg, "Should need registration"

        # Register
        with patch.object(device_registry, '_save_registry'):
            device_registry.register(system_info, version)

        # After registration
        assert device_registry.get_device_id() is not None
        assert not device_registry.needs_reregistration(version)

    def test_cache_persistence(self):
        """Test registry persists across instances"""
        system_info = {"platform": "darwin"}
        version = "1.2.3"

        with tempfile.TemporaryDirectory() as tmpdir:
            registry_path = Path(tmpdir) / "device_registry.json"

            # First registration
            with patch.object(device_registry, 'registry_path',
                              registry_path):
                device_registry.register(system_info, version)
                device_id_1 = device_registry.get_device_id()

            # Verify file exists
            assert registry_path.exists()

            # Verify content can be read
            with open(registry_path, 'r') as f:
                data = json.load(f)
                assert data["device_id"] == device_id_1


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
