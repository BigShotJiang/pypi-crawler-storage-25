#!/usr/bin/env python3
"""
Test các wrapper hàm tiêu chuẩn hóa trong VCI Listing class.

Các hàm wrapper này cung cấp truy cập đến dữ liệu thị trường tiêu chuẩn hóa:
- all_indices() - Danh sách tất cả chỉ số
- indices_by_group(group) - Chỉ số theo nhóm
- all_sectors() - Danh sách ngành ICB

Tất cả dữ liệu được lấy từ vnstock.common.indices module.
"""

import sys
import os
import pandas as pd

sys.path.insert(0, os.path.abspath(os.path.join(
    os.path.dirname(__file__), '..')))

from vnstock.explorer.vci import Listing


def test_all_indices():
    """Test all_indices() - Lấy danh sách tất cả chỉ số."""
    print("\n" + "=" * 70)
    print("TEST 1: all_indices() - Danh sách tất cả chỉ số tiêu chuẩn hóa")
    print("=" * 70)

    listing = Listing()
    indices_df = listing.all_indices()

    assert isinstance(indices_df, pd.DataFrame), "Kết quả phải là DataFrame"
    assert len(indices_df) > 0, "Phải có ít nhất 1 chỉ số"
    assert 'symbol' in indices_df.columns, "Phải có cột 'symbol'"
    assert 'name' in indices_df.columns, "Phải có cột 'name'"
    assert 'group' in indices_df.columns, "Phải có cột 'group'"

    print(f"\n✓ Lấy được {len(indices_df)} chỉ số tiêu chuẩn hóa")
    print(f"✓ Columns: {list(indices_df.columns)}")
    print("\nDữ liệu mẫu (5 dòng đầu):")
    print(indices_df.head().to_string(index=False))

    # Kiểm tra một số chỉ số phổ biến
    vn30_exists = 'VN30' in indices_df['symbol'].values
    print(f"\n✓ VN30 trong danh sách: {vn30_exists}")
    print(f"✓ Các nhóm chỉ số: {indices_df['group'].unique().tolist()}")


def test_indices_by_group():
    """Test indices_by_group() - Lọc chỉ số theo nhóm."""
    print("\n" + "=" * 70)
    print("TEST 2: indices_by_group(group) - Chỉ số theo nhóm")
    print("=" * 70)

    listing = Listing()

    # Lấy tất cả chỉ số để tìm các nhóm có sẵn
    all_indices = listing.all_indices()
    groups = all_indices['group'].unique().tolist()

    print(f"\n✓ Tìm thấy {len(groups)} nhóm chỉ số:")
    for group in groups:
        print(f"  - {group}")

    # Test từng nhóm
    print("\nKiểm tra chi tiết cho từng nhóm:")
    for group in groups[:3]:  # Test 3 nhóm đầu
        group_df = listing.indices_by_group(group)

        assert group_df is not None, (
            f"Kết quả cho '{group}' không được None"
        )
        assert isinstance(group_df, pd.DataFrame), (
            f"Kết quả cho '{group}' phải là DataFrame"
        )
        assert len(group_df) > 0, (
            f"Nhóm '{group}' phải có ít nhất 1 chỉ số"
        )

        print(f"\n  Nhóm: {group}")
        print(f"  ✓ Số lượng: {len(group_df)}")
        print(f"  ✓ Chỉ số: {group_df['symbol'].tolist()}")


def test_workflow_example():
    """Ví dụ workflow thực tế sử dụng các hàm."""
    print("\n" + "=" * 70)
    print("VÍ DỤ WORKFLOW THỰC TẾ")
    print("=" * 70)

    listing = Listing()

    # Lấy tất cả chỉ số
    print("\n1. Lấy tất cả chỉ số:")
    all_idx = listing.all_indices()
    print(f"   → Tổng {len(all_idx)} chỉ số")

    # Lọc theo nhóm
    print("\n2. Lọc chỉ số HOSE:")
    hose_idx = listing.indices_by_group('HOSE Indices')
    if hose_idx is not None and not hose_idx.empty:
        print(f"   → {len(hose_idx)} chỉ số HOSE")
        print(f"   → Danh sách: {hose_idx['symbol'].tolist()}")

    # Lấy thông tin từ DataFrame
    print("\n3. Lấy thông tin VN30 từ DataFrame:")
    vn30 = all_idx[all_idx['symbol'] == 'VN30']
    if not vn30.empty:
        print(f"   → Tên: {vn30['name'].values[0]}")
        print(f"   → Nhóm: {vn30['group'].values[0]}")
        print(f"   → Mô tả: {vn30['description'].values[0]}")

    # Lấy sector indices với mapping ICB
    print("\n4. Lấy sector indices:")
    sector_idx = listing.indices_by_group('Sector Indices')
    if sector_idx is not None and not sector_idx.empty:
        print(f"   → {len(sector_idx)} sector indices")
        print(f"   → Danh sách: {sector_idx['symbol'].tolist()}")
        # Hiển thị sector index có mapping sector_id
        vnit = sector_idx[sector_idx['symbol'] == 'VNIT']
        if not vnit.empty and 'sector_id' in vnit.columns:
            print(f"   → VNIT mapping sector_id: "
                  f"{vnit['sector_id'].values[0]}")


def run_all_tests():
    """Chạy tất cả test."""
    print("\n" + "=" * 70)
    print("KIỂM TRA CÁC HÀM WRAPPER TRONG VCI LISTING")
    print("=" * 70)

    try:
        test_all_indices()
        test_indices_by_group()
        test_workflow_example()

        print("\n" + "=" * 70)
        print("✓ TẤT CẢ TEST THÀNH CÔNG")
        print("=" * 70)
        print("\nSử dụng:")
        print("  from vnstock.explorer.vci import Listing")
        print("  listing = Listing()")
        print("  indices = listing.all_indices()")
        print("  hose_idx = listing.indices_by_group('HOSE Indices')")
        print("  sector_idx = listing.indices_by_group('Sector Indices')")

    except AssertionError as e:
        print(f"\n✗ TEST THẤT BẠI: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n✗ LỖI: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    run_all_tests()
