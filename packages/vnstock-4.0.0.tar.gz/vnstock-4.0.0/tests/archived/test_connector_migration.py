#!/usr/bin/env python3
"""
Integration test for FMP and XNO connectors.

Tests that FMP and XNO Quote classes work from the new connector location
and are properly registered in the provider registry.
"""

import sys

def test_connector_imports():
    """Test direct imports from connector module."""
    print("=" * 60)
    print("TEST 1: Direct Connector Imports")
    print("=" * 60)
    
    try:
        from vnstock.connector.fmp import Quote as FMPQuote
        print("✓ FMP Quote imported from vnstock.connector.fmp")
    except ImportError as e:
        print(f"✗ Failed to import FMP Quote: {e}")
        return False
    
    try:
        from vnstock.connector.xno import Quote as XNOQuote
        print("✓ XNO Quote imported from vnstock.connector.xno")
    except ImportError as e:
        print(f"✗ Failed to import XNO Quote: {e}")
        return False
    
    return True


def test_provider_registry():
    """Test that providers are registered correctly."""
    print("\n" + "=" * 60)
    print("TEST 2: Provider Registry")
    print("=" * 60)
    
    try:
        from vnstock.core.base.registry import ProviderRegistry
        from vnstock.core.types import DataCategory
        
        providers = ProviderRegistry.list_providers(DataCategory.QUOTE)
        quote_providers = providers.get('quote', {})
        api_providers = quote_providers.get('api', [])
        
        print(f"Registered Quote providers: {quote_providers}")
        
        if 'fmp' not in api_providers:
            print("✗ FMP provider not registered")
            return False
        print("✓ FMP provider registered")
        
        if 'xno' not in api_providers:
            print("✗ XNO provider not registered")
            return False
        print("✓ XNO provider registered")
        
    except Exception as e:
        print(f"✗ Error checking registry: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True


def test_provider_instantiation():
    """Test that provider classes can be instantiated (without API calls)."""
    print("\n" + "=" * 60)
    print("TEST 3: Provider Instantiation")
    print("=" * 60)
    
    try:
        from vnstock.connector.fmp import Quote as FMPQuote
        
        # Test FMP Quote initialization (will fail on API key, but tests structure)
        try:
            fmp = FMPQuote("AAPL", show_log=False)
            print("✓ FMP Quote instantiated")
        except ValueError as e:
            if "API key" in str(e):
                print(f"✓ FMP Quote structure OK (API key error expected): {e}")
            else:
                raise
    except Exception as e:
        print(f"✗ Error with FMP Quote: {e}")
        return False
    
    try:
        from vnstock.connector.xno import Quote as XNOQuote
        
        # Test XNO Quote initialization (will fail on API key, but tests structure)
        try:
            xno = XNOQuote("VNM", show_log=False)
            print("✓ XNO Quote instantiated")
        except ValueError as e:
            if "API key" in str(e):
                print(f"✓ XNO Quote structure OK (API key error expected): {e}")
            else:
                raise
    except Exception as e:
        print(f"✗ Error with XNO Quote: {e}")
        return False
    
    return True


def test_backward_compatibility():
    """Test that old explorer paths still work (if not removed)."""
    print("\n" + "=" * 60)
    print("TEST 4: Backward Compatibility Check")
    print("=" * 60)
    
    try:
        # Check if old paths still exist
        from vnstock.explorer import fmp as fmp_explorer
        print("⚠ Old FMP explorer path still accessible (not removed yet)")
    except (ImportError, ModuleNotFoundError):
        print("✓ Old FMP explorer path removed or unavailable")
    
    try:
        from vnstock.explorer import xno as xno_explorer
        print("⚠ Old XNO explorer path still accessible (not removed yet)")
    except (ImportError, ModuleNotFoundError):
        print("✓ Old XNO explorer path removed or unavailable")
    
    return True


def test_main_import():
    """Test that connector is imported when importing vnstock."""
    print("\n" + "=" * 60)
    print("TEST 5: Main Module Import")
    print("=" * 60)
    
    try:
        import vnstock
        
        # Check if connector is available
        if hasattr(vnstock, 'connector'):
            print("✓ vnstock.connector available")
        else:
            print("✗ vnstock.connector not available")
            return False
        
        # Check if we can access connectors
        if hasattr(vnstock.connector, 'FMPQuote'):
            print("✓ vnstock.connector.FMPQuote available")
        else:
            print("⚠ vnstock.connector.FMPQuote not directly available")
        
        if hasattr(vnstock.connector, 'XNOQuote'):
            print("✓ vnstock.connector.XNOQuote available")
        else:
            print("⚠ vnstock.connector.XNOQuote not directly available")
        
    except Exception as e:
        print(f"✗ Error with main import: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True


def main():
    """Run all tests."""
    print("\n" + "🧪 " * 20)
    print("CONNECTOR MIGRATION INTEGRATION TESTS")
    print("🧪 " * 20 + "\n")
    
    tests = [
        test_connector_imports,
        test_provider_registry,
        test_provider_instantiation,
        test_backward_compatibility,
        test_main_import,
    ]
    
    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"\n✗ Test failed with exception: {e}")
            import traceback
            traceback.print_exc()
            results.append(False)
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    passed = sum(results)
    total = len(results)
    print(f"Passed: {passed}/{total}")
    
    if all(results):
        print("\n✅ ALL TESTS PASSED!")
        return 0
    else:
        print("\n❌ SOME TESTS FAILED!")
        return 1


if __name__ == "__main__":
    sys.exit(main())
