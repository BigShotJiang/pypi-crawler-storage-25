#!/usr/bin/env python3
"""
Unit test for history() method - URL construction and logic verification.
"""

import inspect
from datetime import datetime, timedelta

from vnstock.explorer.fmp.quote import Quote
from vnstock.explorer.fmp.const import _ENDPOINTS


print("="*80)
print("UNIT TEST: history() METHOD - URL CONSTRUCTION & LOGIC")
print("="*80)

# Use demo key
api_key = 'demo'
symbol = 'AAPL'
q = Quote(symbol, api_key=api_key, show_log=False)

# Test parameters
today = datetime.now()
start = (today - timedelta(days=30)).strftime('%Y-%m-%d')
end = today.strftime('%Y-%m-%d')

print(f"Symbol: {symbol}")
print(f"API Key: {api_key}")
print(f"Date Range: {start} to {end}")

# Test 1: Verify interval validation
print("\n" + "-"*80)
print("TEST 1: INTERVAL VALIDATION")
print("-"*80)

# Valid intervals
valid_eod = ['1D', '1W', '1M']
valid_intraday = ['1m', '5m', '15m', '30m', '1h', '4h']
valid_all = valid_eod + valid_intraday

print(f"✓ Valid EOD intervals: {valid_eod}")
print(f"✓ Valid intraday intervals: {valid_intraday}")
print(f"✓ Total valid: {len(valid_all)} intervals")

# Test 2: Verify method signature
print("\n" + "-"*80)
print("TEST 2: METHOD SIGNATURE VERIFICATION")
print("-"*80)

sig = inspect.signature(q.history)
print(f"history() parameters: {list(sig.parameters.keys())}")
params = sig.parameters

required_params = ['start', 'end', 'interval', 'adj_type']
for param in required_params:
    if param in params:
        default = params[param].default
        print(f"✓ {param}: default={repr(default)}")
    else:
        print(f"❌ {param} NOT FOUND")

# Test 3: Check source code logic for history()
print("\n" + "-"*80)
print("TEST 3: history() SOURCE CODE LOGIC VERIFICATION")
print("-"*80)

history_source = inspect.getsource(q.history)

# history() should ONLY support EOD, not intraday
history_checks = {
    'EOD interval check': "['1D', '1W', '1M']" in history_source,
    'historical-price-eod endpoint': '/historical-price-eod/' in (
        history_source),
    'Resample support (via utility)': 'resample_ohlcv' in history_source,
    'Date filtering': ('&from=' in history_source and
                       '&to=' in history_source),
    'Column normalization': '_normalize_ohlcv_columns' in (
        history_source),
    'Rejects intraday': 'intraday() cho' in history_source,
}

for check_name, result in history_checks.items():
    status = "✓" if result else "❌"
    print(f"{status} {check_name}")

# Test 4: Verify error handling for invalid intervals
print("\n" + "-"*80)
print("TEST 4: INVALID INTERVAL HANDLING")
print("-"*80)

invalid_check = ('ValueError' in history_source or
                 'return None' in history_source)
status = "✓" if invalid_check else "⚠"
print(f"{status} Invalid interval error handling present")

# Test 5: Verify adjustment type support
print("\n" + "-"*80)
print("TEST 5: ADJUSTMENT TYPE SUPPORT (EOD ONLY)")
print("-"*80)

adj_types = ['light', 'full', 'non-split-adjusted',
             'dividend-adjusted']
adj_types_check = all(adj_type in history_source for adj_type in adj_types)
status = "✓" if adj_types_check else "⚠"
print(f"{status} Adjustment types in source/docstring")

# Test 6: Check const.py has correct endpoints
print("\n" + "-"*80)
print("TEST 6: CONST.PY ENDPOINT VERIFICATION")
print("-"*80)

required_endpoints = {
    'historical_price_eod': '/historical-price-eod',
    'historical_chart_1min': '/historical-chart/1min',
    'historical_chart_5min': '/historical-chart/5min',
    'historical_chart_15min': '/historical-chart/15min',
    'historical_chart_30min': '/historical-chart/30min',
    'historical_chart_1hour': '/historical-chart/1hour',
    'historical_chart_4hour': '/historical-chart/4hour',
}

for endpoint_key, endpoint_path in required_endpoints.items():
    if endpoint_key in _ENDPOINTS:
        actual_path = _ENDPOINTS[endpoint_key]
        match = actual_path == endpoint_path
        status = "✓" if match else "❌"
        print(f"{status} {endpoint_key}: {actual_path}")
    else:
        print(f"❌ {endpoint_key}: NOT IN _ENDPOINTS")

# Test 7: Verify intraday() method compatibility
print("\n" + "-"*80)
print("TEST 7: intraday() METHOD COMPATIBILITY")
print("-"*80)

intraday_sig = inspect.signature(q.intraday)
print(f"intraday() parameters: {list(intraday_sig.parameters.keys())}")

intraday_source = inspect.getsource(q.intraday)
intraday_checks = {
    'Uses historical-chart endpoint': '/historical-chart/' in intraday_source,
    'Supports multiple intervals': all(
        interval in intraday_source
        for interval in ['1min', '5min', '15min', '30min', '1hour', '4hour']
    ),
}

for check_name, result in intraday_checks.items():
    status = "✓" if result else "⚠"
    print(f"{status} {check_name}")

print("\n" + "="*80)
print("✓ UNIT TESTS COMPLETED")
print("="*80)
