"""
Test suite for authentication strategy system.

Tests both GitHub (deprecated) and API Key (new) authentication strategies.
"""

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

sys.path.insert(0, '/Users/mrthinh/Github/vnstock_dev')

from vnii.auth_strategy import (
    GitHubAuthStrategy,
    APIKeyAuthStrategy,
    AuthenticationManager
)
from vnii.device_manager import DeviceManager


class TestGitHubAuthStrategy(unittest.TestCase):
    """Test GitHub authentication strategy"""

    def setUp(self):
        """Set up test fixtures"""
        self.project_dir = Path(tempfile.mkdtemp())
        self.strategy = GitHubAuthStrategy(
            self.project_dir,
            repo_owner='test-owner',
            repo_name='test-repo'
        )

    def tearDown(self):
        """Clean up temp files"""
        import shutil
        if self.project_dir.exists():
            shutil.rmtree(self.project_dir)

    def test_strategy_name(self):
        """Test strategy name property"""
        self.assertEqual(self.strategy.name, "GitHub")

    def test_deprecated_flag(self):
        """Test deprecated property"""
        self.assertTrue(self.strategy.deprecated)

    def test_get_credentials_no_token(self):
        """Test get_credentials when no token file exists"""
        credentials = self.strategy.get_credentials()
        self.assertIsNone(credentials)

    def test_get_credentials_manual_token(self):
        """Test get_credentials with manual token.json"""
        token_file = self.project_dir / "token.json"
        token_data = {"access_token": "test_github_token_123"}
        with open(token_file, "w") as f:
            json.dump(token_data, f)

        credentials = self.strategy.get_credentials()
        self.assertEqual(credentials, "test_github_token_123")

    def test_get_credentials_oauth_token(self):
        """Test get_credentials with access_token.json"""
        token_file = self.project_dir / "access_token.json"
        token_data = {"access_token": "oauth_token_456"}
        with open(token_file, "w") as f:
            json.dump(token_data, f)

        credentials = self.strategy.get_credentials()
        self.assertEqual(credentials, "oauth_token_456")

    @patch('requests.get')
    def test_verify_credentials_success(self, mock_get):
        """Test successful GitHub credential verification"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_get.return_value = mock_response

        result = self.strategy.verify_credentials("valid_token")

        self.assertIn("status", result)
        self.assertIn("auth_method", result)
        self.assertEqual(result["auth_method"], "github")

    @patch('requests.get')
    def test_verify_credentials_network_error(self, mock_get):
        """Test credential verification with network error"""
        import requests
        error_msg = "Network error"
        mock_get.side_effect = requests.exceptions.ConnectionError(
            error_msg)

        with self.assertRaises(SystemExit):
            self.strategy.verify_credentials("invalid_token")

    def test_deprecation_warning(self):
        """Test deprecation warning method"""
        # Should not raise
        self.strategy.deprecation_warning()


class TestAPIKeyAuthStrategy(unittest.TestCase):
    """Test API Key authentication strategy"""

    def setUp(self):
        """Set up test fixtures"""
        self.project_dir = Path(tempfile.mkdtemp())
        self.strategy = APIKeyAuthStrategy(
            self.project_dir,
            api_base_url="https://test.vnstocks.com"
        )
        # Mock DeviceManager
        self.mock_device_manager = Mock()
        self.mock_device_manager.get_device_info.return_value = {
            'device_id': 'test_device_123',
            'device_name': 'test-machine',
            'os_type': 'linux',
            'os_version': '5.10.0',
            'machine_info': {'platform': 'Linux'}
        }
        self.strategy.device_manager = self.mock_device_manager

    def tearDown(self):
        """Clean up temp files"""
        import shutil
        if self.project_dir.exists():
            shutil.rmtree(self.project_dir)

    def test_strategy_name(self):
        """Test strategy name property"""
        self.assertEqual(self.strategy.name, "API Key")

    def test_not_deprecated_flag(self):
        """Test deprecated property is False"""
        self.assertFalse(self.strategy.deprecated)

    def test_get_credentials_env_var(self):
        """Test get_credentials from environment variable"""
        os.environ['VNSTOCK_API_KEY'] = 'env_api_key_xyz'
        credentials = self.strategy.get_credentials()
        self.assertEqual(credentials, 'env_api_key_xyz')
        del os.environ['VNSTOCK_API_KEY']

    def test_get_credentials_file(self):
        """Test get_credentials from file"""
        api_key_file = self.project_dir / "api_key.json"
        key_data = {"api_key": "file_api_key_abc"}
        with open(api_key_file, "w") as f:
            json.dump(key_data, f)

        credentials = self.strategy.get_credentials()
        self.assertEqual(credentials, "file_api_key_abc")

    def test_get_credentials_none(self):
        """Test get_credentials when no credentials exist"""
        credentials = self.strategy.get_credentials()
        self.assertIsNone(credentials)

    @patch('requests.Session.post')
    def test_verify_credentials_success(self, mock_post):
        """Test successful API Key credential verification"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'tier': 'golden',
            'devicesUsed': 1,
            'deviceLimit': 3
        }
        mock_post.return_value = mock_response

        result = self.strategy.verify_credentials("valid_api_key")

        self.assertIn("status", result)
        self.assertIn("tier", result)
        self.assertEqual(result["tier"], "golden")
        self.assertEqual(result["auth_method"], "api_key")

    @patch('requests.Session.post')
    def test_verify_credentials_device_limit(self, mock_post):
        """Test credential verification when device limit exceeded"""
        mock_response = Mock()
        mock_response.status_code = 429
        mock_response.json.return_value = {
            'error': 'Device limit exceeded'
        }
        mock_post.return_value = mock_response

        with self.assertRaises(SystemExit) as ctx:
            self.strategy.verify_credentials("valid_api_key")

        self.assertIn("Device limit exceeded", str(ctx.exception))

    @patch('requests.Session.post')
    def test_verify_credentials_no_device_manager(self, mock_post):
        """Test credential verification when DeviceManager not set"""
        strategy = APIKeyAuthStrategy(self.project_dir)
        strategy.device_manager = None

        with self.assertRaises(RuntimeError):
            strategy.verify_credentials("valid_api_key")


class TestAuthenticationManager(unittest.TestCase):
    """Test authentication manager"""

    def setUp(self):
        """Set up test fixtures"""
        self.project_dir = Path(tempfile.mkdtemp())
        self.manager = AuthenticationManager(
            self.project_dir,
            repo_owner='test-owner',
            repo_name='test-repo'
        )

    def tearDown(self):
        """Clean up temp files"""
        import shutil
        if self.project_dir.exists():
            shutil.rmtree(self.project_dir)

    def test_manager_init(self):
        """Test manager initialization"""
        self.assertIn('api_key', self.manager.strategies)
        self.assertIn('github', self.manager.strategies)

    def test_get_available_strategies_empty(self):
        """Test available strategies when none configured"""
        available = self.manager.get_available_strategies()
        # Both strategies should have no credentials
        self.assertEqual(len(available), 0)

    def test_strategy_priority_order(self):
        """Test default strategy priority"""
        # API Key should be first, GitHub second
        self.assertEqual(
            self.manager.strategy_priority,
            ['api_key', 'github']
        )

    def test_set_strategy_priority(self):
        """Test setting custom strategy priority"""
        self.manager.set_strategy_priority(['github', 'api_key'])
        self.assertEqual(
            self.manager.strategy_priority,
            ['github', 'api_key']
        )

    def test_set_invalid_strategy(self):
        """Test error on invalid strategy"""
        with self.assertRaises(ValueError):
            self.manager.set_strategy_priority(['invalid', 'api_key'])

    @patch.object(APIKeyAuthStrategy, 'get_credentials')
    @patch.object(APIKeyAuthStrategy, 'verify_credentials')
    def test_authenticate_api_key(self, mock_verify, mock_get):
        """Test authenticate with API Key strategy"""
        mock_get.return_value = "test_api_key"
        mock_verify.return_value = {
            "status": "verified",
            "auth_method": "api_key"
        }

        result = self.manager.authenticate()

        self.assertEqual(result["auth_method"], "api_key")

    def test_authenticate_no_credentials(self):
        """Test authenticate when no credentials available"""
        result = self.manager.authenticate()

        # Should fallback to free user
        self.assertEqual(result["status"], "free user")
        self.assertIsNone(result.get("auth_method"))

    @patch.object(APIKeyAuthStrategy, 'get_credentials')
    def test_force_strategy_api_key(self, mock_get):
        """Test forcing specific strategy"""
        mock_get.return_value = None

        with self.assertRaises(SystemExit):
            self.manager.force_strategy('api_key')

    def test_force_invalid_strategy(self):
        """Test error on forcing invalid strategy"""
        with self.assertRaises(ValueError):
            self.manager.force_strategy('invalid')


class TestDeviceManager(unittest.TestCase):
    """Test device manager singleton"""

    def tearDown(self):
        """Reset singleton after each test"""
        DeviceManager.reset_singleton()

    def test_singleton_creation(self):
        """Test that DeviceManager creates singleton"""
        dm1 = DeviceManager()
        dm2 = DeviceManager()
        self.assertIs(dm1, dm2)

    def test_device_id_generation(self):
        """Test device ID generation"""
        dm = DeviceManager()
        device_id = dm.device_id

        # Should be 32-char hex string or UUID
        self.assertTrue(len(device_id) in [32, 36])

    def test_get_device_info(self):
        """Test get_device_info returns correct format"""
        dm = DeviceManager()
        info = dm.get_device_info()

        self.assertIn('device_id', info)
        self.assertIn('device_name', info)
        self.assertIn('os_type', info)
        self.assertIn('os_version', info)
        self.assertIn('machine_info', info)

    def test_device_info_consistency(self):
        """Test that device_id remains consistent"""
        DeviceManager.reset_singleton()
        dm1 = DeviceManager()
        id1 = dm1.device_id

        DeviceManager.reset_singleton()
        dm2 = DeviceManager()
        id2 = dm2.device_id

        # Different instances should generate same ID from same system
        self.assertEqual(id1, id2)


if __name__ == '__main__':
    unittest.main()
