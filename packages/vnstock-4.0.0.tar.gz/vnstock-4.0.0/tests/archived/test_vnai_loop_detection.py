"""Test vnai loop detection and promo display"""

import os
os.environ['VNAI_DEBUG'] = '1'  # Enable debug mode

from vnstock import Quote
import time

print("=" * 60)
print("Testing loop detection mechanism")
print("=" * 60)

q = Quote(symbol='VN30', source='TCBS', show_log=False)

print('\nExecuting 100 calls in a loop...\n')
for i in range(100):
    try:
        df = q.history(start='2024-01-01', end='2024-01-10')
        print(f'Call {i+1}: OK - got {len(df)} rows')
    except Exception as e:
        print(f'Call {i+1}: Error - {e}')
        break

print("\n" + "=" * 60)
print("Test completed")
print("=" * 60)
