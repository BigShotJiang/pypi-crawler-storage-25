#!/usr/bin/env python3
"""
Unit test verifying history() and intraday() are properly separated.

history() -> EOD only (1D, 1W, 1M resample)
intraday() -> Intraday only (1m, 5m, 15m, 30m, 1h, 4h)
"""

import inspect

from vnstock.explorer.fmp.quote import Quote
from vnstock.explorer.fmp.const import _ENDPOINTS


print("="*80)
print("UNIT TEST: METHOD SEPARATION")
print("history() <-> intraday() Responsibilities")
print("="*80)

api_key = 'demo'
symbol = 'AAPL'
q = Quote(symbol, api_key=api_key, show_log=False)

# Test 1: Verify method signatures
print("\n" + "-"*80)
print("TEST 1: METHOD SIGNATURES")
print("-"*80)

history_sig = inspect.signature(q.history)
intraday_sig = inspect.signature(q.intraday)

print(f"history() params: {list(history_sig.parameters.keys())}")
print(f"intraday() params: {list(intraday_sig.parameters.keys())}")

history_default_interval = history_sig.parameters['interval'].default
intraday_default_interval = intraday_sig.parameters['interval'].default

print(f"✓ history() default interval: {history_default_interval}")
print(f"✓ intraday() default interval: {intraday_default_interval}")

# Test 2: history() source code analysis
print("\n" + "-"*80)
print("TEST 2: history() IMPLEMENTATION ANALYSIS")
print("-"*80)

history_source = inspect.getsource(q.history)

history_checks = {
    'Supports 1D': "'1D'" in history_source,
    'Supports 1W': "'1W'" in history_source,
    'Supports 1M': "'1M'" in history_source,
    'Uses /historical-price-eod': '/historical-price-eod' in history_source,
    'Has resample logic (via utility)': 'resample_ohlcv' in history_source,
    'Rejects intraday intervals': 'intraday() cho' in history_source,
    'No /historical-chart': '/historical-chart' not in history_source,
}

print("history() should:")
for check, result in history_checks.items():
    status = "✓" if result else "❌"
    print(f"{status} {check}")

# Test 3: intraday() source code analysis
print("\n" + "-"*80)
print("TEST 3: intraday() IMPLEMENTATION ANALYSIS")
print("-"*80)

intraday_source = inspect.getsource(q.intraday)

intraday_checks = {
    'Supports 1min': "'1min'" in intraday_source,
    'Supports 5min': "'5min'" in intraday_source,
    'Supports 15min': "'15min'" in intraday_source,
    'Supports 30min': "'30min'" in intraday_source,
    'Supports 1hour': "'1hour'" in intraday_source,
    'Supports 4hour': "'4hour'" in intraday_source,
    'Uses /historical-chart': '/historical-chart' in intraday_source,
    'Rejects EOD intervals': 'history() cho' in intraday_source,
    'No /historical-price-eod': '/historical-price-eod' not in (
        intraday_source),
}

print("intraday() should:")
for check, result in intraday_checks.items():
    status = "✓" if result else "❌"
    print(f"{status} {check}")

# Test 4: Endpoint verification
print("\n" + "-"*80)
print("TEST 4: ENDPOINT MAPPINGS IN const.py")
print("-"*80)

eod_endpoints = {
    'historical_price_eod': '/historical-price-eod',
}

intraday_endpoints = {
    'historical_chart_1min': '/historical-chart/1min',
    'historical_chart_5min': '/historical-chart/5min',
    'historical_chart_15min': '/historical-chart/15min',
    'historical_chart_30min': '/historical-chart/30min',
    'historical_chart_1hour': '/historical-chart/1hour',
    'historical_chart_4hour': '/historical-chart/4hour',
}

print("\nEOD Endpoints:")
for key, path in eod_endpoints.items():
    if key in _ENDPOINTS:
        actual = _ENDPOINTS[key]
        match = actual == path
        status = "✓" if match else "❌"
        print(f"{status} {key}: {actual}")
    else:
        print(f"❌ {key}: NOT FOUND")

print("\nIntraday Endpoints:")
for key, path in intraday_endpoints.items():
    if key in _ENDPOINTS:
        actual = _ENDPOINTS[key]
        match = actual == path
        status = "✓" if match else "❌"
        print(f"{status} {key}: {actual}")
    else:
        print(f"❌ {key}: NOT FOUND")

# Test 5: Invalid interval handling
print("\n" + "-"*80)
print("TEST 5: INVALID INTERVAL REJECTION")
print("-"*80)

print("\nhistory() with intraday interval:")
result = q.history(interval='5m')
if result is None:
    print("✓ Correctly rejects intraday interval ('5m')")
else:
    print("❌ Should reject intraday interval")

print("\nintraday() with EOD interval:")
result = q.intraday(interval='1D')
if result is None:
    print("✓ Correctly rejects EOD interval ('1D')")
else:
    print("❌ Should reject EOD interval")

# Test 6: Docstring clarity
print("\n" + "-"*80)
print("TEST 6: DOCSTRING CLARITY")
print("-"*80)

history_doc = q.history.__doc__ or ""
intraday_doc = q.intraday.__doc__ or ""

doc_checks = {
    'history() mentions EOD': 'EOD' in history_doc or 'end-of-day' in (
        history_doc),
    'history() mentions history': 'history' in history_doc,
    'history() mentions intraday rejection': (
        'intraday()' in history_doc),
    'intraday() mentions intraday': 'intraday' in intraday_doc,
    'intraday() mentions phút': 'phút' in intraday_doc or (
        'minute' in intraday_doc),
    'intraday() mentions history rejection': 'history()' in intraday_doc,
}

print("Docstring checks:")
for check, result in doc_checks.items():
    status = "✓" if result else "❌"
    print(f"{status} {check}")

print("\n" + "="*80)
print("✓ TEST COMPLETED")
print("="*80)
print("\nSummary:")
print("- history() returns EOD data: 1D (direct), 1W/1M (resample)")
print("- intraday() returns intraday data: 1m, 5m, 15m, 30m, 1h, 4h")
print("- Both methods reject intervals outside their scope")
print("- Both methods guide users to the correct method")
print("="*80)
