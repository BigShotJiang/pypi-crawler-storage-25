#!/usr/bin/env python3
"""Simple wrapper test"""
import os
os.environ['FMP_TOKEN'] = 'kOCBp18Ju6QckDMARNAz3BKPvIW8JXTJ'

from vnstock import Quote

print("Testing FMP...")
q = Quote(symbol='AAPL', source='FMP')
print(f"✅ FMP Quote created: {q}")
