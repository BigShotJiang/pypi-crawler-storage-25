#!/usr/bin/env python3
"""
Integration test for history() and intraday() methods.

Tests EOD data (1D, 1W, 1M) and intraday data (1m, 5m, 15m, 30m, 1h, 4h).
"""

import os
from datetime import datetime, timedelta

from vnstock.explorer.fmp.quote import Quote

print("="*80)
print("INTEGRATION TEST: history() and intraday() METHODS")
print("="*80)

api_key = os.getenv('FMP_TOKEN')
if not api_key:
    print("Note: Using demo key (limited requests)")
    api_key = 'demo'

print(f"API Key: {api_key[:15]}...")

# Test parameters
symbol = 'AAPL'
today = datetime.now()
start = (today - timedelta(days=30)).strftime('%Y-%m-%d')
end = today.strftime('%Y-%m-%d')

print(f"Symbol: {symbol}")
print(f"Date Range: {start} to {end}")

q = Quote(symbol, api_key=api_key, show_log=False)

# Test 1: EOD intervals
print("\n" + "-"*80)
print("TEST 1: EOD INTERVALS (history() method)")
print("-"*80)

eod_intervals = ['1D', '1W', '1M']
for interval in eod_intervals:
    print(f"\nTesting history(interval='{interval}'):")
    try:
        df = q.history(start=start, end=end, interval=interval,
                       adj_type='full')
        if df is not None and not df.empty:
            print(f"✓ EOD {interval} OK")
            print(f"  Shape: {df.shape}")
            print(f"  Columns: {list(df.columns)[:5]}")
            if 'time' in df.columns:
                t_min = df['time'].min()
                t_max = df['time'].max()
                print(f"  Date range: {t_min} to {t_max}")
            if 'close' in df.columns:
                c_min = df['close'].min()
                c_max = df['close'].max()
                print(f"  Close range: {c_min:.2f} to {c_max:.2f}")
        else:
            print("Note: Empty result (may be rate limit)")
    except Exception as e:
        print(f"Error: {e}")

# Test 2: Intraday intervals
print("\n" + "-"*80)
print("TEST 2: INTRADAY INTERVALS (intraday() method)")
print("-"*80)

intraday_intervals = ['1min', '5min', '15min', '30min', '1hour', '4hour']
for interval in intraday_intervals:
    print(f"\nTesting intraday(interval='{interval}'):")
    try:
        df = q.intraday(interval=interval, start=start, end=end)
        if df is not None and not df.empty:
            print(f"✓ Intraday {interval} OK")
            print(f"  Shape: {df.shape}")
            print(f"  Columns: {list(df.columns)[:5]}")
            if 'time' in df.columns:
                t_min = df['time'].min()
                t_max = df['time'].max()
                print(f"  Date range: {t_min} to {t_max}")
                unique_days = df['time'].dt.date.nunique()
                print(f"  Unique trading days: {unique_days}")
                rows_per_day = len(df) / unique_days
                print(f"  Avg rows per day: {rows_per_day:.1f}")
            if 'close' in df.columns:
                c_min = df['close'].min()
                c_max = df['close'].max()
                print(f"  Close range: {c_min:.2f} to {c_max:.2f}")
        else:
            print("Note: Empty result (may be rate limit)")
    except Exception as e:
        print(f"Error: {e}")

# Test 3: Invalid interval rejection
print("\n" + "-"*80)
print("TEST 3: INVALID INTERVAL REJECTION")
print("-"*80)

print("\n1. history() with intraday interval '5min':")
result = q.history(interval='5min')
if result is None:
    print("✓ Correctly rejected intraday interval")
else:
    print("Error: Should reject intraday interval")

print("\n2. intraday() with EOD interval '1D':")
result = q.intraday(interval='1D')
if result is None:
    print("✓ Correctly rejected EOD interval")
else:
    print("Error: Should reject EOD interval")

# Test 4: Default parameters
print("\n" + "-"*80)
print("TEST 4: DEFAULT PARAMETERS")
print("-"*80)

print("\n1. history() default interval should be '1D':")
try:
    df = q.history()
    print("✓ Callable with defaults")
except Exception as e:
    print(f"Error: {e}")

print("\n2. intraday() default interval should be '1min':")
try:
    df = q.intraday()
    print("✓ Callable with defaults")
except Exception as e:
    print(f"Error: {e}")

# Test 5: Adjustment types (EOD only)
print("\n" + "-"*80)
print("TEST 5: ADJUSTMENT TYPES (EOD only)")
print("-"*80)

adj_types = ['light', 'full', 'non-split-adjusted', 'dividend-adjusted']
for adj_type in adj_types:
    print(f"\nTesting history(adj_type='{adj_type}'):")
    try:
        df = q.history(start=start, end=end, interval='1D',
                       adj_type=adj_type)
        if df is not None and not df.empty:
            print(f"✓ OK - Shape: {df.shape}")
        else:
            print("Note: Empty result (may be rate limit)")
    except Exception as e:
        print(f"Error: {e}")

# Test 6: Date filtering
print("\n" + "-"*80)
print("TEST 6: DATE FILTERING (start/end parameters)")
print("-"*80)

print("\n1. history() without date filters:")
try:
    df = q.history(interval='1D')
    if df is not None and not df.empty:
        print(f"✓ OK - Shape: {df.shape}")
    else:
        print("Note: Empty result")
except Exception as e:
    print(f"Error: {e}")

print("\n2. history() with start only:")
try:
    df = q.history(start=start, interval='1D')
    if df is not None and not df.empty:
        print(f"✓ OK - Shape: {df.shape}")
    else:
        print("Note: Empty result")
except Exception as e:
    print(f"Error: {e}")

print("\n3. history() with start and end:")
try:
    df = q.history(start=start, end=end, interval='1D')
    if df is not None and not df.empty:
        print(f"✓ OK - Shape: {df.shape}")
    else:
        print("Note: Empty result")
except Exception as e:
    print(f"Error: {e}")

print("\n4. intraday() with date filters:")
try:
    df = q.intraday(interval='1min', start=start, end=end)
    if df is not None and not df.empty:
        print(f"✓ OK - Shape: {df.shape}")
    else:
        print("Note: Empty result")
except Exception as e:
    print(f"Error: {e}")

print("\n" + "="*80)
print("INTEGRATION TEST COMPLETED")
print("="*80)
print("\nSummary:")
print("- history() returns EOD: 1D, 1W (resample), 1M (resample)")
print("- intraday() returns intraday: 1min, 5min, ..., 4hour")
print("- Both use start/end naming convention (not start_date/end_date)")
print("- Both reject intervals outside their scope")
print("="*80)
