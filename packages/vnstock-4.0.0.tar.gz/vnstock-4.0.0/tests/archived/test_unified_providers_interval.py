"""Test unified interval system across all providers: VCI, TCBS, MSN, FMP."""

import pytest
from vnstock.core.utils.interval import normalize_interval
from vnstock.core.types import TimeFrame


class TestUnifiedIntervalSystem:
    """Test unified interval normalization across all providers."""

    def test_normalize_interval_none_returns_day_1(self):
        """Test normalize_interval returns DAY_1 when None."""
        result = normalize_interval(None)
        assert result == TimeFrame.DAY_1

    def test_normalize_interval_from_timeframe_enum(self):
        """Test normalize_interval with TimeFrame enum input."""
        result = normalize_interval(TimeFrame.DAY_1)
        assert result == TimeFrame.DAY_1
        
        result = normalize_interval(TimeFrame.HOUR_1)
        assert result == TimeFrame.HOUR_1
        
        result = normalize_interval(TimeFrame.MINUTE_1)
        assert result == TimeFrame.MINUTE_1

    def test_normalize_interval_vnstock_format(self):
        """Test normalize_interval with vnstock format (1D, 1H, etc.)."""
        # Daily formats
        assert normalize_interval("1D") == TimeFrame.DAY_1
        assert normalize_interval("1W") == TimeFrame.WEEK_1
        assert normalize_interval("1M") == TimeFrame.MONTH_1
        
        # Hourly formats
        assert normalize_interval("1H") == TimeFrame.HOUR_1
        assert normalize_interval("1h") == TimeFrame.HOUR_1
        
        # Minute formats
        assert normalize_interval("1m") == TimeFrame.MINUTE_1
        assert normalize_interval("5m") == TimeFrame.MINUTE_5
        assert normalize_interval("15m") == TimeFrame.MINUTE_15
        assert normalize_interval("30m") == TimeFrame.MINUTE_30

    def test_normalize_interval_aliases(self):
        """Test normalize_interval with alias format (d, h, m, w, M)."""
        # Day alias
        assert normalize_interval("d") == TimeFrame.DAY_1
        
        # Week alias
        assert normalize_interval("w") == TimeFrame.WEEK_1
        
        # Hour alias
        assert normalize_interval("h") == TimeFrame.HOUR_1
        
        # Month alias (capital M)
        assert normalize_interval("M") == TimeFrame.MONTH_1
        
        # Minute alias (lowercase m)
        assert normalize_interval("m") == TimeFrame.MINUTE_1

    def test_normalize_interval_human_readable(self):
        """Test normalize_interval with human-readable format."""
        assert normalize_interval("day") == TimeFrame.DAY_1
        assert normalize_interval("week") == TimeFrame.WEEK_1
        assert normalize_interval("month") == TimeFrame.MONTH_1
        assert normalize_interval("hour") == TimeFrame.HOUR_1
        assert normalize_interval("minute") == TimeFrame.MINUTE_1

    def test_normalize_interval_error_handling(self):
        """Test normalize_interval raises error for invalid format."""
        with pytest.raises(ValueError):
            normalize_interval("invalid")
        
        with pytest.raises(ValueError):
            normalize_interval("2D")  # Only 1D supported
        
        with pytest.raises(ValueError):
            normalize_interval("xyz")

    def test_vnstock_provider_interval_support(self):
        """Test VCI provider can accept all alias formats."""
        # VCI should accept all these formats through normalize_interval
        test_intervals = [
            "1D", "d",  # day
            "1W", "w",  # week
            "1M", "M",  # month
            "1H", "h",  # hour
            "1m", "m", "5m", "15m", "30m",  # minutes
        ]
        
        for interval in test_intervals:
            try:
                result = normalize_interval(interval)
                # Should not raise error and should return TimeFrame
                assert isinstance(result, TimeFrame)
            except ValueError as e:
                # Some intervals might not be supported by all providers
                # but normalization should work
                pytest.fail(f"Failed to normalize {interval}: {e}")

    def test_normalized_interval_string_representation(self):
        """Test that normalized intervals have proper string representation."""
        # TimeFrame enum returns its name, not custom format
        # But all normalize to proper TimeFrame values
        assert normalize_interval("d") == TimeFrame.DAY_1
        assert normalize_interval("w") == TimeFrame.WEEK_1
        assert normalize_interval("M") == TimeFrame.MONTH_1
        assert normalize_interval("h") == TimeFrame.HOUR_1
        assert normalize_interval("m") == TimeFrame.MINUTE_1
        assert normalize_interval("5m") == TimeFrame.MINUTE_5

    def test_interval_normalization_consistency(self):
        """Test that different input formats normalize to same result."""
        # All these should normalize to the same TimeFrame
        day_variants = ["1D", "d", "day"]
        day_results = [normalize_interval(v) for v in day_variants]
        assert all(r == TimeFrame.DAY_1 for r in day_results)
        
        # Hour variants
        hour_variants = ["1H", "h", "hour"]
        hour_results = [normalize_interval(v) for v in hour_variants]
        assert all(r == TimeFrame.HOUR_1 for r in hour_results)
        
        # Minute variants (5 minute)
        minute_variants = ["5m", "5m"]  # Could add more variants
        minute_results = [normalize_interval(v) for v in minute_variants]
        assert all(r == TimeFrame.MINUTE_5 for r in minute_results)


class TestProviderIntervalCompatibility:
    """Test interval compatibility across providers."""

    def test_all_providers_share_normalize_function(self):
        """Test that all providers use same normalize_interval function."""
        # Import providers
        try:
            from vnstock.explorer.vci.quote import Quote as VCIQuote
            vci_module = VCIQuote.__module__
            # VCI should use normalize_interval from utils
            assert "vnstock.explorer.vci" in vci_module
        except (ImportError, AttributeError):
            pass  # Provider may not be available

    def test_timeframe_enum_values_consistency(self):
        """Test TimeFrame enum has all required intervals."""
        required_frames = [
            TimeFrame.MINUTE_1,
            TimeFrame.MINUTE_5,
            TimeFrame.MINUTE_15,
            TimeFrame.MINUTE_30,
            TimeFrame.HOUR_1,
            TimeFrame.DAY_1,
            TimeFrame.WEEK_1,
            TimeFrame.MONTH_1,
        ]
        
        for frame in required_frames:
            assert frame is not None
            assert isinstance(frame, TimeFrame)

    def test_interval_string_representations(self):
        """Test TimeFrame enum consistency."""
        # Map TimeFrame to expected values
        frame_values = {
            TimeFrame.MINUTE_1: "MINUTE_1",
            TimeFrame.MINUTE_5: "MINUTE_5",
            TimeFrame.MINUTE_15: "MINUTE_15",
            TimeFrame.MINUTE_30: "MINUTE_30",
            TimeFrame.HOUR_1: "HOUR_1",
            TimeFrame.DAY_1: "DAY_1",
            TimeFrame.WEEK_1: "WEEK_1",
            TimeFrame.MONTH_1: "MONTH_1",
        }
        
        for frame, expected_name in frame_values.items():
            # TimeFrame enum name should match
            assert frame.name == expected_name


class TestNormalizeIntervalEdgeCases:
    """Test edge cases and special scenarios."""

    def test_case_insensitivity_where_appropriate(self):
        """Test that normalization handles case variations."""
        # Hour should handle both 1H and 1h
        assert normalize_interval("1H") == normalize_interval("1h")
        
        # Day should handle variations
        assert normalize_interval("1D") == normalize_interval("d")
        assert normalize_interval("day") == normalize_interval("Day")

    def test_whitespace_handling(self):
        """Test that whitespace doesn't break normalization."""
        # Whitespace should be stripped
        assert normalize_interval("1D") == normalize_interval("1D ")
        assert normalize_interval("1D") == normalize_interval(" 1D")

    def test_normalize_interval_idempotent(self):
        """Test that normalizing multiple times works."""
        for original in ["1D", "d", "day", "1H", "h", "hour"]:
            first_norm = normalize_interval(original)
            # Normalizing TimeFrame enum again should return same value
            second_norm = normalize_interval(first_norm)
            assert first_norm == second_norm


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
