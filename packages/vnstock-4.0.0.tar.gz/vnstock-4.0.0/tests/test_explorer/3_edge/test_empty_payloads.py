"""Edge case tests for empty API payloads."""

import pytest
import pandas as pd
from unittest.mock import patch, MagicMock
from vnstock.explorer.fmarket.fund import Fund
from vnstock.explorer.misc.exchange_rate import vcb_exchange_rate
from vnstock.explorer.misc.gold_price import sjc_gold_price
from vnstock.explorer.msn.listing import Listing
from vnstock.explorer.tcbs.trading import Trading
from vnstock.explorer.vci.quote import Quote


class TestEmptyPayloads:
    """Test handling of empty API payloads."""
    
    @patch('vnstock.explorer.fmarket.fund.requests.get')
    def test_fmarket_empty_data_array(self, mock_get):
        """Test fmarket handling empty data array."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": []}
        mock_get.return_value = mock_response
        
        fund = Fund()
        result = fund.listing()
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 0
    
    @patch('vnstock.explorer.misc.exchange_rate.requests.get')
    def test_exchange_rate_null_data(self, mock_get):
        """Test exchange rate handling null data."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": None}
        mock_get.return_value = mock_response
        
        exchange_rate = ExchangeRate()
        result = exchange_rate.listing()
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 0
    
    @patch('vnstock.explorer.msn.listing.requests.get')
    def test_msn_listing_empty_response(self, mock_get):
        """Test MSN listing handling empty response."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {}
        mock_get.return_value = mock_response
        
        listing = Listing()
        result = listing.all_symbols()
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 0
    
    @patch('vnstock.explorer.tcbs.trading.requests.get')
    def test_tcbs_trading_missing_data_key(self, mock_get):
        """Test TCBS trading handling missing data key."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"results": []}
        mock_get.return_value = mock_response
        
        trading = Trading()
        result = trading.history(symbol="VNM", start_date="2023-01-01", end_date="2023-01-02")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 0
    
    @patch('vnstock.explorer.vci.quote.requests.get')
    def test_vci_quote_empty_string_response(self, mock_get):
        """Test VCI quote handling empty string response."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": ""}
        mock_get.return_value = mock_response
        
        quote = Quote()
        result = quote.history(symbol="VNM", start_date="2023-01-01", end_date="2023-01-02")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 0
