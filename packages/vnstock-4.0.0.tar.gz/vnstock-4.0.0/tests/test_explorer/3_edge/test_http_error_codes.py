"""Edge case tests for HTTP error codes."""

import pytest
from unittest.mock import patch, MagicMock
from requests.exceptions import RequestException, Timeout, ConnectionError
from vnstock.explorer.fmarket.fund import Fund
from vnstock.explorer.misc.exchange_rate import ExchangeRate
from vnstock.explorer.msn.listing import Listing
from vnstock.explorer.tcbs.trading import Trading


class TestHttpErrorCodes:
    """Test handling of HTTP error codes."""
    
    @patch('vnstock.explorer.fmarket.fund.requests.get')
    def test_fmarket_404_error(self, mock_get):
        """Test fmarket handling 404 error."""
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.raise_for_status.side_effect = RequestException("404 Not Found")
        mock_get.return_value = mock_response
        
        fund = Fund()
        with pytest.raises(RequestException):
            fund.listing()
    
    @patch('vnstock.explorer.misc.exchange_rate.requests.get')
    def test_exchange_rate_500_error(self, mock_get):
        """Test exchange rate handling 500 error."""
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.raise_for_status.side_effect = RequestException("500 Internal Server Error")
        mock_get.return_value = mock_response
        
        exchange_rate = ExchangeRate()
        with pytest.raises(RequestException):
            exchange_rate.listing()
    
    @patch('vnstock.explorer.msn.listing.requests.get')
    def test_msn_listing_timeout_error(self, mock_get):
        """Test MSN listing handling timeout error."""
        mock_get.side_effect = Timeout("Request timed out")
        
        listing = Listing()
        with pytest.raises(Timeout):
            listing.all_symbols()
    
    @patch('vnstock.explorer.tcbs.trading.requests.get')
    def test_tcbs_trading_connection_error(self, mock_get):
        """Test TCBS trading handling connection error."""
        mock_get.side_effect = ConnectionError("Connection failed")
        
        trading = Trading()
        with pytest.raises(ConnectionError):
            trading.history(symbol="VNM", start_date="2023-01-01", end_date="2023-01-02")
    
    @patch('vnstock.explorer.fmarket.fund.requests.get')
    def test_fmarket_429_rate_limit(self, mock_get):
        """Test fmarket handling 429 rate limit error."""
        mock_response = MagicMock()
        mock_response.status_code = 429
        mock_response.raise_for_status.side_effect = RequestException("429 Too Many Requests")
        mock_get.return_value = mock_response
        
        fund = Fund()
        with pytest.raises(RequestException):
            fund.listing()
    
    @patch('vnstock.explorer.misc.exchange_rate.requests.get')
    def test_exchange_rate_401_unauthorized(self, mock_get):
        """Test exchange rate handling 401 unauthorized error."""
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_response.raise_for_status.side_effect = RequestException("401 Unauthorized")
        mock_get.return_value = mock_response
        
        exchange_rate = ExchangeRate()
        with pytest.raises(RequestException):
            exchange_rate.listing()
    
    @patch('vnstock.explorer.msn.listing.requests.get')
    def test_msn_listing_403_forbidden(self, mock_get):
        """Test MSN listing handling 403 forbidden error."""
        mock_response = MagicMock()
        mock_response.status_code = 403
        mock_response.raise_for_status.side_effect = RequestException("403 Forbidden")
        mock_get.return_value = mock_response
        
        listing = Listing()
        with pytest.raises(RequestException):
            listing.all_symbols()
    
    @patch('requests.get')
    def test_generic_request_exception(self, mock_get):
        """Test handling generic request exception."""
        mock_get.side_effect = RequestException("Generic request error")
        
        fund = Fund()
        with pytest.raises(RequestException):
            fund.listing()
