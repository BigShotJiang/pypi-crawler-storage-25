"""Edge case tests for malformed JSON responses."""

import pytest
import pandas as pd
from unittest.mock import patch, MagicMock
from vnstock.explorer.fmarket.fund import Fund
from vnstock.explorer.misc.exchange_rate import ExchangeRate
from vnstock.explorer.msn.listing import Listing
from vnstock.explorer.tcbs.trading import Trading
import json


class TestMalformedJson:
    """Test handling of malformed JSON responses."""
    
    @patch('vnstock.explorer.fmarket.fund.requests.get')
    def test_fmarket_invalid_json_structure(self, mock_get):
        """Test fmarket handling invalid JSON structure."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.side_effect = json.JSONDecodeError("Invalid JSON", "", 0)
        mock_get.return_value = mock_response
        
        fund = Fund()
        with pytest.raises(json.JSONDecodeError):
            fund.listing()
    
    @patch('vnstock.explorer.misc.exchange_rate.requests.get')
    def test_exchange_rate_partial_json_data(self, mock_get):
        """Test exchange rate handling partial JSON data."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {"currency": "USD", "buy": 25400},  # Missing 'sell' field
                {"currency": "EUR", "buy": 27800, "sell": 27900}
            ]
        }
        mock_get.return_value = mock_response
        
        exchange_rate = ExchangeRate()
        result = exchange_rate.listing()
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2
        # Should handle missing fields gracefully
    
    @patch('vnstock.explorer.msn.listing.requests.get')
    def test_msn_listing_wrong_data_types(self, mock_get):
        """Test MSN listing handling wrong data types."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {"symbol": "VNM", "name": "Vinamilk", "market_cap": "1500000000000"},  # String instead of number
                {"symbol": "FPT", "name": 123, "market_cap": 800000000000}  # Number instead of string
            ]
        }
        mock_get.return_value = mock_response
        
        listing = Listing()
        result = listing.all_symbols()
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2
    
    @patch('vnstock.explorer.tcbs.trading.requests.get')
    def test_tcbs_trading_null_values(self, mock_get):
        """Test TCBS trading handling null values."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "symbol": "VNM",
                    "date": "2023-01-01",
                    "open": 75000,
                    "high": None,  # Null value
                    "low": 74000,
                    "close": 75500,
                    "volume": 1000000
                }
            ]
        }
        mock_get.return_value = mock_response
        
        trading = Trading()
        result = trading.history(symbol="VNM", start_date="2023-01-01", end_date="2023-01-02")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 1
        assert pd.isna(result.iloc[0]["high"])
    
    @patch('requests.get')
    def test_response_not_json(self, mock_get):
        """Test handling non-JSON response."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.side_effect = AttributeError("Response is not JSON")
        mock_get.return_value = mock_response
        
        fund = Fund()
        with pytest.raises(AttributeError):
            fund.listing()
