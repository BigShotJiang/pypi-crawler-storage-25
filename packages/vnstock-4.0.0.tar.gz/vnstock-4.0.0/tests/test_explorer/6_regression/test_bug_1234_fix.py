"""Regression test for bug #1234 fix."""

import pytest
import pandas as pd
from unittest.mock import patch, MagicMock
from vnstock.explorer.tcbs.trading import Trading


class TestBug1234Fix:
    """Regression test for bug #1234: Trading history date parsing issue."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.trading = Trading()
    
    @patch('vnstock.explorer.tcbs.trading.requests.get')
    def test_trading_history_date_format_handling(self, mock_get):
        """
        Regression test for bug #1234:
        Trading history should handle various date formats correctly.
        Previously, dates in 'DD/MM/YYYY' format were not parsed properly.
        """
        # Mock response with various date formats
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "symbol": "VNM",
                    "date": "01/01/2023",  # DD/MM/YYYY format
                    "open": 75000,
                    "high": 76000,
                    "low": 74000,
                    "close": 75500,
                    "volume": 1000000
                },
                {
                    "symbol": "VNM",
                    "date": "2023-01-02",  # YYYY-MM-DD format
                    "open": 75500,
                    "high": 76500,
                    "low": 75000,
                    "close": 76000,
                    "volume": 1200000
                },
                {
                    "symbol": "VNM",
                    "date": "03-Jan-2023",  # DD-MMM-YYYY format
                    "open": 76000,
                    "high": 77000,
                    "low": 75500,
                    "close": 76500,
                    "volume": 1100000
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.trading.history(symbol="VNM", start_date="2023-01-01", end_date="2023-01-03")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 3
        
        # Check that all dates are parsed correctly
        dates = pd.to_datetime(result["date"])
        assert all(dates.year == 2023)
        assert dates.iloc[0].month == 1
        assert dates.iloc[0].day == 1
        assert dates.iloc[1].month == 1
        assert dates.iloc[1].day == 2
        assert dates.iloc[2].month == 1
        assert dates.iloc[2].day == 3
    
    @patch('vnstock.explorer.tcbs.trading.requests.get')
    def test_trading_history_invalid_date_handling(self, mock_get):
        """
        Regression test for bug #1234:
        Trading history should handle invalid dates gracefully.
        """
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "symbol": "VNM",
                    "date": "32/01/2023",  # Invalid date
                    "open": 75000,
                    "high": 76000,
                    "low": 74000,
                    "close": 75500,
                    "volume": 1000000
                },
                {
                    "symbol": "VNM",
                    "date": "2023-13-01",  # Invalid month
                    "open": 75500,
                    "high": 76500,
                    "low": 75000,
                    "close": 76000,
                    "volume": 1200000
                },
                {
                    "symbol": "VNM",
                    "date": "valid-date",  # Non-date string
                    "open": 76000,
                    "high": 77000,
                    "low": 75500,
                    "close": 76500,
                    "volume": 1100000
                }
            ]
        }
        mock_get.return_value = mock_response
        
        # Should handle invalid dates gracefully, either by skipping or setting to NaT
        result = self.trading.history(symbol="VNM", start_date="2023-01-01", end_date="2023-01-03")
        
        assert isinstance(result, pd.DataFrame)
        # The implementation should either filter out invalid dates or set them to NaT
        assert len(result) <= 3  # May be less if invalid dates are filtered out
