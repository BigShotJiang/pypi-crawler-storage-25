"""Functional tests for misc exchange rate explorer."""

import pytest
import pandas as pd
from unittest.mock import patch, MagicMock
from vnstock.explorer.misc.exchange_rate import ExchangeRate


class TestMiscExchangeRate:
    """Test misc exchange rate explorer functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.exchange_rate = ExchangeRate()
    
    @patch('vnstock.explorer.misc.exchange_rate.requests.get')
    def test_exchange_rate_listing_success(self, mock_get):
        """Test successful exchange rate listing retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "currency": "USD",
                    "buy": 25450,
                    "sell": 25500,
                    "update_time": "2023-01-01 10:00:00"
                },
                {
                    "currency": "EUR",
                    "buy": 27800,
                    "sell": 27900,
                    "update_time": "2023-01-01 10:00:00"
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.exchange_rate.listing()
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2
        assert "currency" in result.columns
        assert "buy" in result.columns
        assert "sell" in result.columns
        assert result.iloc[0]["currency"] == "USD"
    
    @patch('vnstock.explorer.misc.exchange_rate.requests.get')
    def test_exchange_rate_history_success(self, mock_get):
        """Test successful exchange rate history retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {"date": "2023-01-01", "currency": "USD", "rate": 25450},
                {"date": "2023-01-02", "currency": "USD", "rate": 25480},
                {"date": "2023-01-03", "currency": "USD", "rate": 25500}
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.exchange_rate.history(currency="USD", start_date="2023-01-01", end_date="2023-01-03")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 3
        assert "date" in result.columns
        assert "currency" in result.columns
        assert "rate" in result.columns
        assert result.iloc[0]["rate"] == 25400
    
    def test_exchange_rate_initialization(self):
        """Test exchange rate class initialization."""
        exchange_rate = ExchangeRate()
        assert exchange_rate is not None
        assert hasattr(exchange_rate, 'listing')
        assert hasattr(exchange_rate, 'history')
