"""Functional tests for VCI trading explorer."""

import pytest
import pandas as pd
from unittest.mock import patch, MagicMock
from vnstock.explorer.vci.trading import Trading


class TestVciTrading:
    """Test VCI trading explorer functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.trading = Trading()
    
    @patch('vnstock.explorer.vci.trading.requests.get')
    def test_trading_history_success(self, mock_get):
        """Test successful trading history retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "symbol": "VNM",
                    "date": "2023-01-01",
                    "open": 75000,
                    "high": 76000,
                    "low": 74000,
                    "close": 75500,
                    "volume": 1000000,
                    "value": 75500000000
                },
                {
                    "symbol": "VNM",
                    "date": "2023-01-02",
                    "open": 75500,
                    "high": 76500,
                    "low": 75000,
                    "close": 76000,
                    "volume": 1200000,
                    "value": 91200000000
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.trading.history(symbol="VNM", start_date="2023-01-01", end_date="2023-01-02")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2
        assert "symbol" in result.columns
        assert "date" in result.columns
        assert "open" in result.columns
        assert "high" in result.columns
        assert "low" in result.columns
        assert "close" in result.columns
        assert "volume" in result.columns
        assert result.iloc[0]["symbol"] == "VNM"
    
    @patch('vnstock.explorer.vci.trading.requests.get')
    def test_trading_intraday_success(self, mock_get):
        """Test successful intraday trading data retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "symbol": "VNM",
                    "time": "09:15:00",
                    "price": 75000,
                    "volume": 10000,
                    "match_type": "LO"
                },
                {
                    "symbol": "VNM",
                    "time": "09:16:00",
                    "price": 75100,
                    "volume": 5000,
                    "match_type": "LO"
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.trading.intraday(symbol="VNM", page_size=10)
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2
        assert "symbol" in result.columns
        assert "time" in result.columns
        assert "price" in result.columns
        assert "volume" in result.columns
        assert result.iloc[0]["symbol"] == "VNM"
    
    @patch('vnstock.explorer.vci.trading.requests.get')
    def test_trading_price_depth_success(self, mock_get):
        """Test successful price depth data retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": {
                "symbol": "VNM",
                "timestamp": "2023-01-01 10:00:00",
                "bid": [
                    {"price": 75400, "volume": 10000},
                    {"price": 75300, "volume": 15000}
                ],
                "ask": [
                    {"price": 75500, "volume": 8000},
                    {"price": 75600, "volume": 12000}
                ]
            }
        }
        mock_get.return_value = mock_response
        
        result = self.trading.price_depth(symbol="VNM")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) > 0
        assert "symbol" in result.columns
        assert result.iloc[0]["symbol"] == "VNM"
    
    def test_trading_initialization(self):
        """Test trading class initialization."""
        trading = Trading()
        assert trading is not None
        assert hasattr(trading, 'history')
        assert hasattr(trading, 'intraday')
        assert hasattr(trading, 'price_depth')
