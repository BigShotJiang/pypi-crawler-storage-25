"""Functional tests for TCBS trading explorer."""

import pytest
import pandas as pd
from unittest.mock import patch, MagicMock
from vnstock.explorer.tcbs.trading import Trading


class TestTcbsTrading:
    """Test TCBS trading explorer functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.trading = Trading()
    
    @patch('vnstock.explorer.tcbs.trading.requests.get')
    def test_trading_history_success(self, mock_get):
        """Test successful trading history retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "symbol": "VNM",
                    "date": "2023-01-01",
                    "open": 75000,
                    "high": 76000,
                    "low": 74000,
                    "close": 75500,
                    "volume": 1000000,
                    "value": 75500000000
                },
                {
                    "symbol": "VNM",
                    "date": "2023-01-02",
                    "open": 75500,
                    "high": 76500,
                    "low": 75000,
                    "close": 76000,
                    "volume": 1200000,
                    "value": 91200000000
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.trading.history(symbol="VNM", start_date="2023-01-01", end_date="2023-01-02")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2
        assert "symbol" in result.columns
        assert "date" in result.columns
        assert "open" in result.columns
        assert "high" in result.columns
        assert "low" in result.columns
        assert "close" in result.columns
        assert "volume" in result.columns
        assert result.iloc[0]["symbol"] == "VNM"
    
    @patch('vnstock.explorer.tcbs.trading.requests.get')
    def test_trading_intraday_success(self, mock_get):
        """Test successful intraday trading data retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "symbol": "VNM",
                    "time": "09:15:00",
                    "price": 75000,
                    "volume": 10000,
                    "match_type": "LO"
                },
                {
                    "symbol": "VNM",
                    "time": "09:16:00",
                    "price": 75100,
                    "volume": 5000,
                    "match_type": "LO"
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.trading.intraday(symbol="VNM", page_size=10)
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2
        assert "symbol" in result.columns
        assert "time" in result.columns
        assert "price" in result.columns
        assert "volume" in result.columns
        assert result.iloc[0]["symbol"] == "VNM"
    
    @patch('vnstock.explorer.tcbs.trading.requests.get')
    def test_trading_foreign_trading_success(self, mock_get):
        """Test successful foreign trading data retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "symbol": "VNM",
                    "date": "2023-01-01",
                    "foreign_buy_volume": 500000,
                    "foreign_buy_value": 37500000000,
                    "foreign_sell_volume": 300000,
                    "foreign_sell_value": 22500000000,
                    "foreign_net_volume": 200000,
                    "foreign_net_value": 15000000000
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.trading.foreign_trading(symbol="VNM", start_date="2023-01-01", end_date="2023-01-01")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 1
        assert "symbol" in result.columns
        assert "foreign_buy_volume" in result.columns
        assert "foreign_sell_volume" in result.columns
        assert "foreign_net_volume" in result.columns
        assert result.iloc[0]["symbol"] == "VNM"
    
    def test_trading_initialization(self):
        """Test trading class initialization."""
        trading = Trading()
        assert trading is not None
        assert hasattr(trading, 'history')
        assert hasattr(trading, 'intraday')
        assert hasattr(trading, 'foreign_trading')
