"""Functional tests for MSN listing explorer."""

import pytest
import pandas as pd
from unittest.mock import patch, MagicMock
from vnstock.explorer.msn.listing import Listing


class TestMsnListing:
    """Test MSN listing explorer functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.listing = Listing()
    
    @patch('vnstock.explorer.msn.listing.requests.get')
    def test_listing_all_symbols_success(self, mock_get):
        """Test successful all symbols listing retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "symbol": "VNM",
                    "name": "Vinamilk",
                    "exchange": "HOSE",
                    "sector": "Food & Beverage",
                    "market_cap": 1500000000000
                },
                {
                    "symbol": "FPT",
                    "name": "FPT Corporation",
                    "exchange": "HOSE",
                    "sector": "Technology",
                    "market_cap": 800000000000
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.listing.all_symbols()
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2
        assert "symbol" in result.columns
        assert "name" in result.columns
        assert "exchange" in result.columns
        assert result.iloc[0]["symbol"] == "VNM"
    
    @patch('vnstock.explorer.msn.listing.requests.get')
    def test_listing_by_exchange_success(self, mock_get):
        """Test successful symbols listing by exchange retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "symbol": "VNM",
                    "name": "Vinamilk",
                    "exchange": "HOSE",
                    "sector": "Food & Beverage"
                },
                {
                    "symbol": "VIC",
                    "name": "Vingroup",
                    "exchange": "HOSE",
                    "sector": "Real Estate"
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.listing.by_exchange("HOSE")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2
        assert "symbol" in result.columns
        assert "exchange" in result.columns
        assert all(result["exchange"] == "HOSE")
    
    @patch('vnstock.explorer.msn.listing.requests.get')
    def test_listing_by_sector_success(self, mock_get):
        """Test successful symbols listing by sector retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "symbol": "FPT",
                    "name": "FPT Corporation",
                    "exchange": "HOSE",
                    "sector": "Technology"
                },
                {
                    "symbol": "CMG",
                    "name": "Công ty Cổ phần Mạng Việt Nam",
                    "exchange": "HNX",
                    "sector": "Technology"
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.listing.by_sector("Technology")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2
        assert "sector" in result.columns
        assert all(result["sector"] == "Technology")
    
    def test_listing_initialization(self):
        """Test listing class initialization."""
        listing = Listing()
        assert listing is not None
        assert hasattr(listing, 'all_symbols')
        assert hasattr(listing, 'by_exchange')
        assert hasattr(listing, 'by_sector')
