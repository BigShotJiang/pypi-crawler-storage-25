"""Functional tests for VCI financial explorer."""

import pytest
import pandas as pd
from unittest.mock import patch, MagicMock
from vnstock.explorer.vci.financial import Financial


class TestVciFinancial:
    """Test VCI financial explorer functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.financial = Financial()
    
    @patch('vnstock.explorer.vci.financial.requests.get')
    def test_financial_income_statement_success(self, mock_get):
        """Test successful income statement retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "symbol": "VNM",
                    "year": 2023,
                    "quarter": 4,
                    "revenue": 50000000000000,
                    "gross_profit": 15000000000000,
                    "net_profit": 8000000000000,
                    "eps": 7500
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.financial.income_statement(symbol="VNM", period="quarter", language="vi")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 1
        assert "symbol" in result.columns
        assert "year" in result.columns
        assert "quarter" in result.columns
        assert "revenue" in result.columns
        assert result.iloc[0]["symbol"] == "VNM"
    
    @patch('vnstock.explorer.vci.financial.requests.get')
    def test_financial_balance_sheet_success(self, mock_get):
        """Test successful balance sheet retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "symbol": "VNM",
                    "year": 2023,
                    "quarter": 4,
                    "total_assets": 100000000000000,
                    "total_liabilities": 30000000000000,
                    "total_equity": 70000000000000,
                    "cash_and_equivalents": 15000000000000
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.financial.balance_sheet(symbol="VNM", period="quarter", language="vi")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 1
        assert "symbol" in result.columns
        assert "total_assets" in result.columns
        assert "total_equity" in result.columns
        assert result.iloc[0]["symbol"] == "VNM"
    
    @patch('vnstock.explorer.vci.financial.requests.get')
    def test_financial_cash_flow_success(self, mock_get):
        """Test successful cash flow retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "symbol": "VNM",
                    "year": 2023,
                    "quarter": 4,
                    "operating_cash_flow": 12000000000000,
                    "investing_cash_flow": -5000000000000,
                    "financing_cash_flow": -3000000000000,
                    "free_cash_flow": 7000000000000
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.financial.cash_flow(symbol="VNM", period="quarter", language="vi")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 1
        assert "symbol" in result.columns
        assert "operating_cash_flow" in result.columns
        assert "free_cash_flow" in result.columns
        assert result.iloc[0]["symbol"] == "VNM"
    
    @patch('vnstock.explorer.vci.financial.requests.get')
    def test_financial_ratios_success(self, mock_get):
        """Test successful financial ratios retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "symbol": "VNM",
                    "year": 2023,
                    "quarter": 4,
                    "pe_ratio": 15.5,
                    "pb_ratio": 3.2,
                    "roe": 0.25,
                    "debt_to_equity": 0.43,
                    "current_ratio": 2.1
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.financial.ratios(symbol="VNM", period="quarter", language="vi")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 1
        assert "symbol" in result.columns
        assert "pe_ratio" in result.columns
        assert "roe" in result.columns
        assert result.iloc[0]["symbol"] == "VNM"
    
    def test_financial_initialization(self):
        """Test financial class initialization."""
        financial = Financial()
        assert financial is not None
        assert hasattr(financial, 'income_statement')
        assert hasattr(financial, 'balance_sheet')
        assert hasattr(financial, 'cash_flow')
        assert hasattr(financial, 'ratios')
