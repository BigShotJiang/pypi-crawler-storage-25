"""Functional tests for fmarket fund explorer."""

import pytest
import pandas as pd
from unittest.mock import patch, MagicMock
from vnstock.explorer.fmarket.fund import Fund


class TestFmarketFund:
    """Test fmarket fund explorer functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.fund = Fund()
    
    @patch('vnstock.core.utils.client.send_request')
    def test_fund_listing_success(self, mock_get):
        """Test successful fund listing retrieval."""
        # Mock response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "fundId": "1",
                    "fundName": "Test Fund",
                    "fundShortName": "TF",
                    "fundType": "Equity",
                    "nav": 10000.5,
                    "managementFee": 1.5
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.fund.listing()
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 1
        assert "fundId" in result.columns
        assert "fundName" in result.columns
        assert result.iloc[0]["fundName"] == "Test Fund"
    
    @patch('vnstock.core.utils.client.send_request')
    def test_fund_filter_success(self, mock_get):
        """Test successful fund filter retrieval."""
        # Mock response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "shortName": "Test Fund",
                    "name": "Test Fund Full Name",
                    "id": "1",
                    "code": "TF"
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.fund.filter(symbol="TF")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 1
        assert "shortName" in result.columns
        assert result.iloc[0]["shortName"] == "Test Fund"
    
    def test_fund_initialization(self):
        """Test fund class initialization."""
        fund = Fund()
        assert fund is not None
        assert hasattr(fund, 'listing')
        assert hasattr(fund, 'details')
        assert hasattr(fund, 'filter')
        assert hasattr(fund, 'top_holding')
        assert hasattr(fund, 'industry_holding')
        assert hasattr(fund, 'nav_report')
        assert hasattr(fund, 'asset_holding')
