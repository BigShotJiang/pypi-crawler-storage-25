"""Functional tests for misc gold price explorer."""

import pytest
import pandas as pd
from unittest.mock import patch, MagicMock
from vnstock.explorer.misc.gold_price import GoldPrice


class TestMiscGoldPrice:
    """Test misc gold price explorer functionality."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.gold_price = GoldPrice()
    
    @patch('vnstock.explorer.misc.gold_price.requests.get')
    def test_gold_price_listing_success(self, mock_get):
        """Test successful gold price listing retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {
                    "type": "SJC 1L",
                    "buy": 7500000,
                    "sell": 7550000,
                    "update_time": "2023-01-01 10:00:00"
                },
                {
                    "type": "PNJ 1L",
                    "buy": 7490000,
                    "sell": 7540000,
                    "update_time": "2023-01-01 10:00:00"
                }
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.gold_price.listing()
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2
        assert "type" in result.columns
        assert "buy" in result.columns
        assert "sell" in result.columns
        assert result.iloc[0]["type"] == "SJC 1L"
    
    @patch('vnstock.explorer.misc.gold_price.requests.get')
    def test_gold_price_history_success(self, mock_get):
        """Test successful gold price history retrieval."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {"date": "2023-01-01", "type": "SJC 1L", "buy": 7400000, "sell": 7450000},
                {"date": "2023-01-02", "type": "SJC 1L", "buy": 7450000, "sell": 7500000},
                {"date": "2023-01-03", "type": "SJC 1L", "buy": 7500000, "sell": 7550000}
            ]
        }
        mock_get.return_value = mock_response
        
        result = self.gold_price.history(gold_type="SJC 1L", start_date="2023-01-01", end_date="2023-01-03")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 3
        assert "date" in result.columns
        assert "type" in result.columns
        assert "buy" in result.columns
        assert "sell" in result.columns
        assert result.iloc[0]["buy"] == 7400000
    
    def test_gold_price_initialization(self):
        """Test gold price class initialization."""
        gold_price = GoldPrice()
        assert gold_price is not None
        assert hasattr(gold_price, 'listing')
        assert hasattr(gold_price, 'history')
