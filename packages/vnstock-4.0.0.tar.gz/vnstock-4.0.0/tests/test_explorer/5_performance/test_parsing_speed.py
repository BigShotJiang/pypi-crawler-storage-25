"""Performance tests for parsing speed."""

import pytest
import time
import pandas as pd
from unittest.mock import patch, MagicMock
from vnstock.explorer.fmarket.fund import Fund
from vnstock.explorer.misc.exchange_rate import ExchangeRate
from vnstock.explorer.msn.listing import Listing
from vnstock.explorer.tcbs.trading import Trading


class TestParsingSpeed:
    """Performance tests for parsing speed."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.fund = Fund()
        self.exchange_rate = ExchangeRate()
        self.listing = Listing()
        self.trading = Trading()
    
    @patch('vnstock.explorer.fmarket.fund.requests.get')
    def test_fmarket_large_dataset_parsing(self, mock_get):
        """Test fmarket parsing speed with large dataset."""
        # Mock large dataset (1000 funds)
        large_dataset = [
            {
                "fundId": str(i),
                "fundName": f"Test Fund {i}",
                "fundShortName": f"TF{i}",
                "fundType": "Equity",
                "nav": 10000.5 + i,
                "managementFee": 1.5
            }
            for i in range(1000)
        ]
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": large_dataset}
        mock_get.return_value = mock_response
        
        # Measure parsing time
        start_time = time.time()
        result = self.fund.listing()
        end_time = time.time()
        
        parsing_time = end_time - start_time
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 1000
        assert parsing_time < 1.0  # Should parse 1000 items in under 1 second
    
    @patch('vnstock.explorer.msn.listing.requests.get')
    def test_msn_listing_large_dataset_parsing(self, mock_get):
        """Test MSN listing parsing speed with large dataset."""
        # Mock large dataset (2000 symbols)
        large_dataset = [
            {
                "symbol": f"SYM{i:04d}",
                "name": f"Test Company {i}",
                "exchange": "HOSE" if i % 2 == 0 else "HNX",
                "sector": ["Technology", "Banking", "Real Estate", "Manufacturing"][i % 4],
                "market_cap": (i + 1) * 1000000000
            }
            for i in range(2000)
        ]
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": large_dataset}
        mock_get.return_value = mock_response
        
        # Measure parsing time
        start_time = time.time()
        result = self.listing.all_symbols()
        end_time = time.time()
        
        parsing_time = end_time - start_time
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2000
        assert parsing_time < 2.0  # Should parse 2000 items in under 2 seconds
    
    @patch('vnstock.explorer.tcbs.trading.requests.get')
    def test_tcbs_trading_large_history_parsing(self, mock_get):
        """Test TCBS trading parsing speed with large history."""
        # Mock large dataset (365 days of data)
        large_dataset = [
            {
                "symbol": "VNM",
                "date": f"2023-{(i//30 + 1):02d}-{(i%30 + 1):02d}",
                "open": 75000 + i,
                "high": 76000 + i,
                "low": 74000 + i,
                "close": 75500 + i,
                "volume": 1000000 + i * 1000,
                "value": (75500 + i) * (1000000 + i * 1000)
            }
            for i in range(365)
        ]
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": large_dataset}
        mock_get.return_value = mock_response
        
        # Measure parsing time
        start_time = time.time()
        result = self.trading.history(symbol="VNM", start_date="2023-01-01", end_date="2023-12-31")
        end_time = time.time()
        
        parsing_time = end_time - start_time
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 365
        assert parsing_time < 1.5  # Should parse 365 items in under 1.5 seconds
    
    @patch('vnstock.explorer.misc.exchange_rate.requests.get')
    def test_exchange_rate_memory_usage(self, mock_get):
        """Test exchange rate memory usage with large dataset."""
        # Mock large dataset (5000 historical records)
        large_dataset = [
            {
                "date": f"2023-{(i//100 + 1):02d}-{(i%30 + 1):02d}",
                "currency": "USD",
                "rate": 25400 + i % 100
            }
            for i in range(5000)
        ]
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": large_dataset}
        mock_get.return_value = mock_response
        
        # Measure memory usage by checking DataFrame size
        result = self.exchange_rate.history(currency="USD", start_date="2023-01-01", end_date="2023-12-31")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 5000
        
        # Check memory usage (should be reasonable)
        memory_usage = result.memory_usage(deep=True).sum()
        assert memory_usage < 10 * 1024 * 1024  # Less than 10MB
    
    def test_multiple_classes_instantiation_performance(self):
        """Test performance of instantiating multiple explorer classes."""
        classes = [Fund, ExchangeRate, Listing, Trading]
        
        start_time = time.time()
        instances = [cls() for cls in classes]
        end_time = time.time()
        
        instantiation_time = end_time - start_time
        
        assert len(instances) == 4
        assert instantiation_time < 0.1  # Should instantiate 4 classes in under 0.1 seconds
