"""Integration tests for live MSN listing functionality."""

import pytest
import pandas as pd
from vnstock.explorer.msn.listing import Listing
from vnstock.explorer.msn.quote import Quote


class TestLiveMsnListing:
    """Integration tests for MSN listing with live data."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.listing = Listing()
        self.quote = Quote()
    
    @pytest.mark.integration
    @pytest.mark.slow
    def test_live_all_symbols_listing(self):
        """Test live all symbols listing."""
        result = self.listing.all_symbols()
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) > 0
        assert "symbol" in result.columns
        assert "name" in result.columns
        assert "exchange" in result.columns
        
        # Check for common symbols
        symbols = result["symbol"].tolist()
        assert any(symbol in symbols for symbol in ["VNM", "FPT", "VIC"])
    
    @pytest.mark.integration
    @pytest.mark.slow
    def test_live_hose_listing(self):
        """Test live HOSE symbols listing."""
        result = self.listing.by_exchange("HOSE")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) > 0
        assert "symbol" in result.columns
        assert "exchange" in result.columns
        
        # All symbols should be from HOSE
        assert all(result["exchange"] == "HOSE")
    
    @pytest.mark.integration
    @pytest.mark.slow
    def test_live_hnx_listing(self):
        """Test live HNX symbols listing."""
        result = self.listing.by_exchange("HNX")
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) > 0
        assert "symbol" in result.columns
        assert "exchange" in result.columns
        
        # All symbols should be from HNX
        assert all(result["exchange"] == "HNX")
    
    @pytest.mark.integration
    @pytest.mark.slow
    def test_live_listing_to_quote_workflow(self):
        """Test workflow from listing to quote data."""
        # Get symbols from listing
        listing_result = self.listing.all_symbols()
        assert len(listing_result) > 0
        
        # Get first symbol
        test_symbol = listing_result.iloc[0]["symbol"]
        
        # Get quote data for this symbol
        quote_result = self.quote.history(
            symbol=test_symbol, 
            start_date="2023-01-01", 
            end_date="2023-01-31"
        )
        
        assert isinstance(quote_result, pd.DataFrame)
        if len(quote_result) > 0:
            assert "symbol" in quote_result.columns
            assert quote_result.iloc[0]["symbol"] == test_symbol
    
    @pytest.mark.integration
    @pytest.mark.slow
    def test_live_multiple_exchanges_workflow(self):
        """Test workflow across multiple exchanges."""
        # Get symbols from different exchanges
        hose_symbols = self.listing.by_exchange("HOSE")
        hnx_symbols = self.listing.by_exchange("HNX")
        
        assert len(hose_symbols) > 0
        assert len(hnx_symbols) > 0
        
        # Verify exchanges are different
        hose_exchanges = set(hose_symbols["exchange"])
        hnx_exchanges = set(hnx_symbols["exchange"])
        
        assert "HOSE" in hose_exchanges
        assert "HNX" in hnx_exchanges
        assert hose_exchanges != hnx_exchanges
