"""
Registry for vnstock Unified UI.
Maps UI methods to native vnstock API/Explorer functions.
"""

# Structure: {domain: {method: (layer, sub_module, class_name, function_name, source, return_type, summary)}}
# layer: 'api', 'explorer', 'connector'

MAP = {
    # Legacy flat domains (kept for backward compatibility where it makes sense)
    "retail": {
        "gold": ("explorer", "misc.gold_price", None, "sjc_gold_price", "SJC/BTMC", "DataFrame", "Unified gold price (use source='sjc' or 'btmc')."),
        "gold_price_sjc": ("explorer", "misc.gold_price", None, "sjc_gold_price", "SJC", "DataFrame", "Get SJC gold price."),
        "gold_price_btmc": ("explorer", "misc.gold_price", None, "btmc_goldprice", "BTMC", "DataFrame", "Get Bao Tin Minh Chau gold price."),
        "exchange_rate": ("explorer", "misc.exchange_rate", None, "vcb_exchange_rate", "VCB", "DataFrame", "Get exchange rate from Vietcombank."),
    },
    "company": {
        "info": ("api", "api.company", "Company", "info", "KBS", "DataFrame", "Get company info/overview."),
        "shareholders": ("api", "api.company", "Company", "shareholders", "KBS", "DataFrame", "List major shareholders."),
        "officers": ("api", "api.company", "Company", "officers", "KBS", "DataFrame", "List company leadership."),
        "subsidiaries": ("api", "api.company", "Company", "subsidiaries", "KBS", "DataFrame", "List subsidiaries."),
        "ownership": ("api", "api.company", "Company", "ownership", "KBS", "DataFrame", "Company ownership structure."),
        "insider_trading": ("api", "api.company", "Company", "insider_trading", "KBS", "DataFrame", "Insider trading history."),
        "capital_history": ("api", "api.company", "Company", "capital_history", "KBS", "DataFrame", "Capital change history."),
        "news": ("api", "api.company", "Company", "news", "KBS", "DataFrame", "Company related news."),
        "events": ("api", "api.company", "Company", "events", "KBS", "DataFrame", "Upcoming corporate events."),
    },
    "equity_market": {
        "ohlcv": ("api", "api.quote", "Quote", "ohlcv", "KBS", "DataFrame", "Historical OHLCV bars."),
        "quote": ("api", "api.trading", "Trading", "price_board", "KBS", "DataFrame", "Real-time pricing board data."),
        "trades": ("api", "api.quote", "Quote", "intraday", "KBS", "DataFrame", "Tick-by-tick trade tape."),
    },
    "index_market": {
        "ohlcv": ("api", "api.quote", "Quote", "ohlcv", "KBS", "DataFrame", "Historical OHLCV bars for indices."),
    },
    "etf_market": {
        "ohlcv": ("api", "api.quote", "Quote", "ohlcv", "KBS", "DataFrame", "Historical OHLCV bars for ETFs."),
        "quote": ("api", "api.trading", "Trading", "price_board", "KBS", "DataFrame", "Real-time pricing for ETFs."),
        "trades": ("api", "api.quote", "Quote", "intraday", "KBS", "DataFrame", "Tick-by-tick trades for ETFs."),
    },
    "futures_market": {
        "ohlcv": ("api", "api.quote", "Quote", "ohlcv", "KBS", "DataFrame", "Historical OHLCV bars for Futures."),
        "quote": ("api", "api.trading", "Trading", "price_board", "KBS", "DataFrame", "Real-time pricing for Futures."),
        "trades": ("api", "api.quote", "Quote", "intraday", "KBS", "DataFrame", "Tick-by-tick trades for Futures."),
    },
    "warrant_market": {
        "ohlcv": ("api", "api.quote", "Quote", "ohlcv", "KBS", "DataFrame", "Historical OHLCV bars for Warrants."),
        "quote": ("api", "api.trading", "Trading", "price_board", "KBS", "DataFrame", "Real-time pricing for Warrants."),
        "trades": ("api", "api.quote", "Quote", "intraday", "KBS", "DataFrame", "Tick-by-tick trades for Warrants."),
    },

    # New High-Fidelity Domain Structure (Layer 4)
    "Reference": {
        "company": {
            "info": ("api", "api.company", "Company", "info", "KBS", "DataFrame", "Get company overview."),
            "shareholders": ("api", "api.company", "Company", "shareholders", "KBS", "DataFrame", "List major shareholders."),
            "officers": ("api", "api.company", "Company", "officers", "KBS", "DataFrame", "List company leadership."),
            "subsidiaries": ("api", "api.company", "Company", "subsidiaries", "KBS", "DataFrame", "List subsidiaries."),
            "ownership": ("api", "api.company", "Company", "ownership", "KBS", "DataFrame", "Company ownership structure."),
            "insider_trading": ("api", "api.company", "Company", "insider_trading", "KBS", "DataFrame", "Insider trading history."),
            "capital_history": ("api", "api.company", "Company", "capital_history", "KBS", "DataFrame", "Capital change history."),
            "news": ("api", "api.company", "Company", "news", "KBS", "DataFrame", "Company related news."),
            "events": ("api", "api.company", "Company", "events", "KBS", "DataFrame", "Upcoming corporate events."),
        },
        "equity": {
            "list": ("api", "api.listing", "Listing", "all_symbols", "KBS", "DataFrame", "List all equity symbols."),
            "list_by_group": ("api", "api.listing", "Listing", "symbols_by_group", "KBS", "DataFrame", "List equities by group."),
            "list_by_industry": ("api", "api.listing", "Listing", "symbols_by_industries", "VCI", "DataFrame", "List equities by industry."),
            "list_by_exchange": ("api", "api.listing", "Listing", "symbols_by_exchange", "KBS", "DataFrame", "List symbols by exchange/board."),
        },
        "index": {
            "list": ("api", "common.indices", None, "get_all_indices", "KBS", "DataFrame", "List all market indices."),
            "members": ("api", "api.listing", "Listing", "symbols_by_group", "KBS", "DataFrame", "List constituents of an index."),
            "groups": ("api", "api.listing", "Listing", "get_supported_groups", "KBS", "DataFrame", "List supported index groups."),
            "info": ("api", "common.indices", None, "get_all_indices", "KBS", "DataFrame", "Get all market indices metadata."),
            "info_single": ("api", "common.indices", None, "get_index_info", "KBS", "Dict", "Get specific index metadata."),
        },



        "etf": {
            "list": ("api", "api.listing", "Listing", "all_etf", "KBS", "DataFrame", "List all trackers/ETFs."),

        },
        "futures": {
            "list": ("api", "api.listing", "Listing", "all_future_indices", "KBS", "DataFrame", "List all futures instruments."),
            "info": ("api", "api.listing", "Listing", "futures_specifications", "KBS", "Dict", "Get futures specifications."),
        },
        "warrant": {
            "list": ("api", "api.listing", "Listing", "all_covered_warrant", "KBS", "DataFrame", "List all covered warrants."),
            "info": ("api", "api.listing", "Listing", "warrant_specifications", "KBS", "Dict", "Get warrant specifications."),
        },
        "bond": {
            "corporate": ("api", "api.listing", "Listing", "all_bonds", "KBS", "DataFrame", "List all corporate bonds."),
            "government": ("api", "api.listing", "Listing", "all_government_bonds", "VCI", "DataFrame", "List all government bonds."),

        },

        "fund": {
            "list": ("explorer", "fmarket.fund", "Fund", "listing", "FMarket", "DataFrame", "List all mutual funds."),

            "top_holding": ("explorer", "fmarket.fund", "Fund", "top_holding", "FMarket", "DataFrame", "Fund top holdings."),
            "industry_holding": ("explorer", "fmarket.fund", "Fund", "industry_holding", "FMarket", "DataFrame", "Fund industry allocation."),
            "nav_report": ("explorer", "fmarket.fund", "Fund", "nav_report", "FMarket", "DataFrame", "Fund NAV performance."),
            "asset_holding": ("explorer", "fmarket.fund", "Fund", "asset_holding", "FMarket", "DataFrame", "Fund asset allocation."),
        },
        "industry": {
            "list": ("api", "api.listing", "Listing", "industries_icb", "VCI", "DataFrame", "ICB industry classification."),
            "sectors": ("api", "api.listing", "Listing", "symbols_by_industries", "KBS", "DataFrame", "List symbols grouped by industry."),
        },
        "events": {
            "calendar": ("api", "api.company", "Company", "events", "KBS", "DataFrame", "Retrieve events calendar."),
            "market": ("api", "api.company", "Company", "events", "KBS", "DataFrame", "Market-wide events."),
        },

        "market": {
            "status": ("api", "api.listing", "Listing", "market_status", "KBS", "Dict", "Get live market status."),
        },
        "search": {
            "symbol": ("api", "api.listing", "Listing", "search_symbol", "MSN", "DataFrame", "Search for symbols globally."),
            "info": ("api", "api.listing", "Listing", "info", "MSN", "DataFrame", "Search for detailed asset information."),
        }



    },
    "Market": {
        "quote": ("api", "api.trading", "Trading", "price_board", "KBS", "DataFrame", "Global real-time quote."),
        "equity": {
            "ohlcv": ("api", "api.quote", "Quote", "ohlcv", "KBS", "DataFrame", "Historical OHLCV bars."),
            "quote": ("api", "api.trading", "Trading", "price_board", "KBS", "DataFrame", "Real-time pricing board data."),
            "trades": ("api", "api.quote", "Quote", "intraday", "KBS", "DataFrame", "Tick-by-tick trade tape."),
        },
        "index": {
            "ohlcv": ("api", "api.quote", "Quote", "ohlcv", "KBS", "DataFrame", "Historical OHLCV bars for indices."),
        },
        "etf": {
            "ohlcv": ("api", "api.quote", "Quote", "ohlcv", "KBS", "DataFrame", "Historical OHLCV bars for ETFs."),
            "quote": ("api", "api.trading", "Trading", "price_board", "KBS", "DataFrame", "Real-time pricing for ETFs."),
            "trades": ("api", "api.quote", "Quote", "intraday", "KBS", "DataFrame", "Tick-by-tick trades for ETFs."),
        },
        "futures": {
            "ohlcv": ("api", "api.quote", "Quote", "ohlcv", "KBS", "DataFrame", "Historical OHLCV bars for Futures."),
            "quote": ("api", "api.trading", "Trading", "price_board", "KBS", "DataFrame", "Real-time pricing for Futures."),
            "trades": ("api", "api.quote", "Quote", "intraday", "KBS", "DataFrame", "Tick-by-tick trades for Futures."),
        },
        "warrant": {
            "ohlcv": ("api", "api.quote", "Quote", "ohlcv", "KBS", "DataFrame", "Historical OHLCV bars for Warrants."),
            "quote": ("api", "api.trading", "Trading", "price_board", "KBS", "DataFrame", "Real-time pricing for Warrants."),
            "trades": ("api", "api.quote", "Quote", "intraday", "KBS", "DataFrame", "Tick-by-tick trades for Warrants."),
        },
        "forex": {
            "ohlcv": ("explorer", "msn.quote", "Quote", "history", "MSN", "DataFrame", "Historical OHLCV bars for forex."),
        },
        "fund": {
            "history": ("explorer", "fmarket.fund", "Fund", "nav_report", "FMarket", "DataFrame", "Fund NAV history."),
            "nav": ("explorer", "fmarket.fund", "Fund", "nav_report", "FMarket", "DataFrame", "Fund NAV history."),
            "top_holding": ("explorer", "fmarket.fund", "Fund", "top_holding", "FMarket", "DataFrame", "Top holdings of the fund."),
            "industry_holding": ("explorer", "fmarket.fund", "Fund", "industry_holding", "FMarket", "DataFrame", "Industry allocation of the fund."),
            "asset_holding": ("explorer", "fmarket.fund", "Fund", "asset_holding", "FMarket", "DataFrame", "Asset class allocation of the fund."),
        },
        "commodity": {
            "ohlcv": ("explorer", "msn.quote", "Quote", "history", "MSN", "DataFrame", "Historical OHLCV for commodities."),
        },
        "crypto": {
            "ohlcv": ("explorer", "msn.quote", "Quote", "history", "MSN", "DataFrame", "Historical OHLCV for crypto."),
        }
    },
    "Fundamental": {
        "equity": {
            "balance_sheet": ("api", "api.financial", "Finance", "balance_sheet", "KBS", "DataFrame", "Get balance sheet."),
            "cash_flow": ("api", "api.financial", "Finance", "cash_flow", "KBS", "DataFrame", "Get cash flow."),
            "income_statement": ("api", "api.financial", "Finance", "income_statement", "KBS", "DataFrame", "Get income statement."),
            "ratios": ("api", "api.financial", "Finance", "ratio", "KBS", "DataFrame", "Financial ratios."),
        }
    },
    "Retail": {
        "gold": ("retail", "gold"), # Reference to top-level retail
    },
    "Broker": {
        "dnse": {
            "login": ("connector", "dnse.trade", "Trade", "login", "DNSE", "None", "Login to account."),
            "account": ("connector", "dnse.trade", "Trade", "account", "DNSE", "DataFrame", "Generic account info."),
            "sub_accounts": ("connector", "dnse.trade", "Trade", "sub_accounts", "DNSE", "DataFrame", "List sub-accounts."),
            "account_balance": ("connector", "dnse.trade", "Trade", "account_balance", "DNSE", "DataFrame", "Sub-account balance."),
            "order_list": ("connector", "dnse.trade", "Trade", "order_list", "DNSE", "DataFrame", "Order history."),
            "order_detail": ("connector", "dnse.trade", "Trade", "order_detail", "DNSE", "DataFrame", "Order details."),
            "place_order": ("connector", "dnse.trade", "Trade", "place_order", "DNSE", "DataFrame", "Place new order."),
            "cancel_order": ("connector", "dnse.trade", "Trade", "cancel_order", "DNSE", "DataFrame", "Cancel order."),
            "trade_capacities": ("connector", "dnse.trade", "Trade", "trade_capacities", "DNSE", "DataFrame", "Buying power."),
            "deals_list": ("connector", "dnse.trade", "Trade", "deals_list", "DNSE", "DataFrame", "Open deals."),
            "loan_packages": ("connector", "dnse.trade", "Trade", "loan_packages", "DNSE", "DataFrame", "Loan packages."),
            "email_otp": ("connector", "dnse.trade", "Trade", "email_otp", "DNSE", "None", "Request OTP."),
            "get_trading_token": ("connector", "dnse.trade", "Trade", "get_trading_token", "DNSE", "str", "Trading token."),
        },
    }
}
