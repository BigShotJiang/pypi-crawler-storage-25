#!/usr/bin/env python3
"""
Validation script for Phase 2 Device Registration implementation
Usage: python3 dev/validate_phase2.py
"""

import sys
from pathlib import Path

# Add project to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))


def check_file_exists(file_path: str, description: str) -> bool:
    """Check if file exists"""
    path = Path(file_path)
    exists = path.exists()
    status = "✓" if exists else "✗"
    print(f"  {status} {description}: {file_path}")
    return exists


def check_class_exists(file_path: str, class_name: str) -> bool:
    """Check if class exists in file"""
    try:
        path = Path(file_path)
        with open(path, 'r') as f:
            content = f.read()
            exists = f"class {class_name}" in content
            status = "✓" if exists else "✗"
            print(f"  {status} Class '{class_name}' in {file_path}")
            return exists
    except Exception as e:
        print(f"  ✗ Error checking {file_path}: {e}")
        return False


def check_method_exists(file_path: str, method_name: str) -> bool:
    """Check if method exists in file"""
    try:
        path = Path(file_path)
        with open(path, 'r') as f:
            content = f.read()
            exists = f"def {method_name}" in content
            status = "✓" if exists else "✗"
            print(f"  {status} Method '{method_name}' in {file_path}")
            return exists
    except Exception as e:
        print(f"  ✗ Error checking {file_path}: {e}")
        return False


def check_string_in_file(file_path: str, search_string: str,
                         description: str) -> bool:
    """Check if string exists in file"""
    try:
        path = Path(file_path)
        with open(path, 'r') as f:
            content = f.read()
            exists = search_string in content
            status = "✓" if exists else "✗"
            print(f"  {status} {description}")
            return exists
    except Exception as e:
        print(f"  ✗ Error checking {file_path}: {e}")
        return False


def main():
    """Run validation checks"""
    print("\n" + "=" * 70)
    print("PHASE 2: Device Registration Implementation Validation")
    print("=" * 70 + "\n")

    all_pass = True

    # Check 1: DeviceRegistry class exists
    print("1. Checking DeviceRegistry Implementation...")
    print("-" * 70)
    device_file = "vnai/scope/device.py"
    all_pass &= check_file_exists(device_file, "DeviceRegistry file")
    all_pass &= check_class_exists(device_file, "DeviceRegistry")
    all_pass &= check_method_exists(device_file, "get_device_id")
    all_pass &= check_method_exists(device_file, "register")
    all_pass &= check_method_exists(device_file, "needs_reregistration")
    all_pass &= check_method_exists(device_file, "get_registry")
    print()

    # Check 2: vnai/__init__.py integration
    print("2. Checking vnai/__init__.py Integration...")
    print("-" * 70)
    vnai_file = "vnai/__init__.py"
    all_pass &= check_file_exists(vnai_file, "vnai/__init__.py file")
    all_pass &= check_string_in_file(
        vnai_file,
        "from vnai.scope.device import device_registry",
        "DeviceRegistry import"
    )
    all_pass &= check_string_in_file(
        vnai_file,
        "device_registry.needs_reregistration",
        "Version check in initialize()"
    )
    all_pass &= check_string_in_file(
        vnai_file,
        "device_registry.register",
        "Device registration call"
    )
    print()

    # Check 3: relay.py optimization
    print("3. Checking vnai/flow/relay.py Optimization...")
    print("-" * 70)
    relay_file = "vnai/flow/relay.py"
    all_pass &= check_file_exists(relay_file, "relay.py file")
    all_pass &= check_string_in_file(
        relay_file,
        "from vnai.scope.device import device_registry",
        "DeviceRegistry import in relay.py"
    )
    all_pass &= check_string_in_file(
        relay_file,
        "device_registry.get_device_id",
        "Cached device_id usage"
    )
    all_pass &= check_string_in_file(
        relay_file,
        "lightweight",
        "Lightweight payload comment"
    )
    print()

    # Check 4: Test files
    print("4. Checking Test Files...")
    print("-" * 70)
    test_file = "tests/test_device_registry.py"
    all_pass &= check_file_exists(test_file, "test_device_registry.py")
    all_pass &= check_class_exists(test_file, "TestDeviceRegistry")
    all_pass &= check_method_exists(test_file, "test_singleton_instance")
    all_pass &= check_method_exists(
        test_file, "test_needs_reregistration_same_version"
    )
    print()

    # Check 5: Documentation
    print("5. Checking Documentation Files...")
    print("-" * 70)
    docs = [
        ("licensing_docs/PHASE_2_IMPLEMENTATION.md",
         "Phase 2 Implementation Guide"),
        ("licensing_docs/PHASE_2_PROGRESS.md", "Phase 2 Progress Report"),
        ("licensing_docs/PHASE_2_SUMMARY.md", "Phase 2 Summary")
    ]
    for doc_file, desc in docs:
        all_pass &= check_file_exists(doc_file, desc)
    print()

    # Summary
    print("=" * 70)
    if all_pass:
        print("✓ ALL VALIDATION CHECKS PASSED!")
        print("=" * 70)
        msg = "Phase 2 Implementation Status: COMPLETE & READY FOR TESTING"
        print(f"\n{msg}\n")
        return 0
    else:
        print("✗ SOME VALIDATION CHECKS FAILED!")
        print("=" * 70)
        print("\nPlease review the issues above and fix them.\n")
        return 1


if __name__ == "__main__":
    sys.exit(main())
