#!/usr/bin/env python3
"""
Test script để minh họa và kiểm tra các hàm wrapper mới
trong VCI Listing class.

Các hàm wrapper này cung cấp truy cập đến dữ liệu tiêu chuẩn hóa về:
- Chỉ số thị trường (indices)
- Ngành ICB (sectors)
- Sàn giao dịch (exchanges)

Tất cả dữ liệu được lấy từ vnstock.common.indices module.
"""

import sys
import os

sys.path.insert(0, os.path.abspath('.'))

from vnstock.explorer.vci import Listing


def test_vci_listing_wrappers():
    """Test tất cả các hàm wrapper mới trong VCI Listing."""

    print("=" * 60)
    print("TEST VCI LISTING WRAPPER FUNCTIONS")
    print("=" * 60)

    # Khởi tạo VCI Listing instance
    listing = Listing(show_log=True)
    print("✓ Khởi tạo VCI Listing thành công\n")

    # =========================================================================
    # Test 1: all_indices() - Danh sách tất cả chỉ số
    # =========================================================================
    print("1. TEST: all_indices() - Danh sách tất cả chỉ số tiêu chuẩn hóa")
    print("-" * 50)

    try:
        indices_df = listing.all_indices()
        print(f"✓ Lấy được {len(indices_df)} chỉ số")
        print("Sample data (5 dòng đầu):")
        print(indices_df.head().to_string(index=False))
        print(f"\nColumns: {list(indices_df.columns)}")
        print()
    except Exception as e:
        print(f"✗ Lỗi: {e}\n")

    # =========================================================================
    # Test 2: indices_by_group() - Chỉ số theo nhóm
    # =========================================================================
    print("2. TEST: indices_by_group() - Chỉ số theo nhóm")
    print("-" * 50)

    test_groups = ['HOSE Indices', 'Sector Indices', 'Investment Indices']

    for group in test_groups:
        try:
            group_df = listing.indices_by_group(group)
            if group_df is not None and not group_df.empty:
                print(f"✓ Nhóm '{group}': {len(group_df)} chỉ số")
                print(group_df[['symbol', 'name']].to_string(index=False))
            else:
                print(f"⚠ Nhóm '{group}': Không có dữ liệu")
            print()
        except Exception as e:
            print(f"✗ Lỗi với nhóm '{group}': {e}\n")

    # =========================================================================
    # Test 3: index_info() - Thông tin chi tiết chỉ số
    # =========================================================================
    print("3. TEST: index_info() - Thông tin chi tiết chỉ số")
    print("-" * 50)

    test_symbols = ['VN30', 'VNIT', 'VN100', 'VNX50']

    for symbol in test_symbols:
        try:
            info = listing.index_info(symbol)
            if info:
                print(f"✓ {symbol}: {info['name']}")
                print(f"  Mô tả: {info['description']}")
                print(f"  Nhóm: {info['group']}")
                print(f"  ID: {info['index_id']}")
            else:
                print(f"⚠ {symbol}: Không tìm thấy thông tin")
            print()
        except Exception as e:
            print(f"✗ Lỗi với {symbol}: {e}\n")

    # =========================================================================
    # Test 4: all_index_groups() - Danh sách nhóm chỉ số
    # =========================================================================
    print("4. TEST: all_index_groups() - Danh sách nhóm chỉ số")
    print("-" * 50)

    try:
        groups = listing.all_index_groups()
        print(f"✓ Tất cả nhóm chỉ số: {groups}")
        print()
    except Exception as e:
        print(f"✗ Lỗi: {e}\n")

    # =========================================================================
    # Test 5: all_sectors() - Danh sách ngành ICB
    # =========================================================================
    print("5. TEST: all_sectors() - Danh sách ngành ICB")
    print("-" * 50)

    try:
        sectors_df = listing.all_sectors()
        print(f"✓ Lấy được {len(sectors_df)} ngành")
        print("Sample data (5 dòng đầu):")
        print(sectors_df.head().to_string(index=False))
        print()
    except Exception as e:
        print(f"✗ Lỗi: {e}\n")

    # =========================================================================
    # Test 6: sector_name() - Tên ngành từ ID
    # =========================================================================
    print("6. TEST: sector_name() - Tên ngành từ ID")
    print("-" * 50)

    test_sector_ids = [126, 130, 138, 999]  # 999 không tồn tại

    for sector_id in test_sector_ids:
        try:
            name = listing.sector_name(sector_id)
            if name:
                print(f"✓ Sector ID {sector_id}: {name}")
            else:
                print(f"⚠ Sector ID {sector_id}: Không tìm thấy")
        except Exception as e:
            print(f"✗ Lỗi với sector_id {sector_id}: {e}")
    print()

    # =========================================================================
    # Test 7: all_exchanges() - Danh sách sàn giao dịch
    # =========================================================================
    print("7. TEST: all_exchanges() - Danh sách sàn giao dịch")
    print("-" * 50)

    try:
        exchanges = listing.all_exchanges()
        print(f"✓ Tất cả sàn giao dịch: {exchanges}")
        print()
    except Exception as e:
        print(f"✗ Lỗi: {e}\n")

    # =========================================================================
    # Test 8: exchange_name() - Tên sàn từ mã
    # =========================================================================
    print("8. TEST: exchange_name() - Tên sàn từ mã")
    print("-" * 50)

    test_codes = ['HOSE', 'HNX', 'UPCOM', 'INVALID']

    for code in test_codes:
        try:
            name = listing.exchange_name(code)
            if name:
                print(f"✓ {code}: {name}")
            else:
                print(f"⚠ {code}: Không tìm thấy")
        except Exception as e:
            print(f"✗ Lỗi với {code}: {e}")
    print()

    # =========================================================================
    # Summary
    # =========================================================================
    print("=" * 60)
    print("TÓM TẮT KIỂM TRA")
    print("=" * 60)
    print("✓ Tất cả 8 hàm wrapper đã được test")
    print("✓ Dữ liệu được lấy từ vnstock.common.indices")
    print("✓ Interface thống nhất với pandas DataFrame")
    print("✓ Có thể sử dụng trực tiếp qua VCI Listing instance")
    print("\nVí dụ sử dụng:")
    print("  listing = Listing()")
    print("  indices = listing.all_indices()")
    print("  vn30_info = listing.index_info('VN30')")
    print("  sectors = listing.all_sectors()")


if __name__ == "__main__":
    test_vci_listing_wrappers()
