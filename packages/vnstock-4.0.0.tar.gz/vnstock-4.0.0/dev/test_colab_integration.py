#!/usr/bin/env python3
"""
Test script để kiểm tra tính năng Google Colab Drive integration
"""

import sys
import os
from pathlib import Path


def test_colab_detection():
    """Test phát hiện môi trường Colab"""
    print("\n" + "="*70)
    print("TEST 1: Phát hiện môi trường Colab")
    print("="*70)
    
    from vnstock.core.utils.env import is_colab
    
    result = is_colab()
    print(f"Kết quả: {'Đang chạy trên Colab' if result else 'Không phải Colab'}")
    
    # Kiểm tra module
    has_colab_module = 'google.colab' in sys.modules
    print(f"google.colab module: {'Có' if has_colab_module else 'Không'}")
    
    return result


def test_vnstock_path():
    """Test lấy đường dẫn vnstock"""
    print("\n" + "="*70)
    print("TEST 2: Đường dẫn .vnstock")
    print("="*70)
    
    from vnstock.core.utils.env import get_vnstock_path, is_colab
    
    path = get_vnstock_path()
    print(f"Đường dẫn .vnstock: {path}")
    print(f"Tồn tại: {path.exists()}")
    
    if is_colab():
        expected = Path("/content/drive/MyDrive/.vnstock")
        if path.exists():
            status = "✅ PASS" if path == expected else "⚠️  Dùng path khác"
        else:
            status = "⚠️  Drive chưa mount"
    else:
        expected = Path.home() / ".vnstock"
        status = "✅ PASS" if path == expected else "❌ FAIL"
    
    print(f"Trạng thái: {status}")
    return path


def test_const_paths():
    """Test các constants trong const.py"""
    print("\n" + "="*70)
    print("TEST 3: Constants trong const.py")
    print("="*70)
    
    from vnstock.core.config.const import PROJECT_DIR, ID_DIR
    
    print(f"PROJECT_DIR: {PROJECT_DIR}")
    print(f"ID_DIR: {ID_DIR}")
    print(f"PROJECT_DIR tồn tại: {PROJECT_DIR.exists()}")
    print(f"ID_DIR tồn tại: {ID_DIR.exists()}")
    
    return PROJECT_DIR, ID_DIR


def test_vnai_inspector():
    """Test vnai inspector paths"""
    print("\n" + "="*70)
    print("TEST 4: vnai Inspector paths")
    print("="*70)
    
    from vnai.scope.profile import inspector
    
    print(f"home_dir: {inspector.home_dir}")
    print(f"project_dir: {inspector.project_dir}")
    print(f"id_dir: {inspector.id_dir}")
    
    print(f"\nproject_dir tồn tại: {inspector.project_dir.exists()}")
    print(f"id_dir tồn tại: {inspector.id_dir.exists()}")
    
    return inspector


def test_colab_helpers():
    """Test các helper functions"""
    print("\n" + "="*70)
    print("TEST 5: Helper functions")
    print("="*70)
    
    from vnstock.core.utils.env import (
        get_colab_install_command,
        is_colab
    )
    
    if is_colab():
        cmd = get_colab_install_command()
        print(f"Lệnh cài đặt:\n{cmd}")
    else:
        print("Không phải Colab, bỏ qua test này")


def test_sys_path():
    """Test sys.path integration"""
    print("\n" + "="*70)
    print("TEST 6: sys.path integration")
    print("="*70)
    
    from vnstock.core.utils.env import is_colab
    
    if is_colab():
        drive_path = "/content/drive/MyDrive/.vnstock"
        in_path = drive_path in sys.path
        print(f"Drive path trong sys.path: {in_path}")
        
        if in_path:
            print(f"✅ PASS - Drive path đã được thêm vào sys.path")
        else:
            print(f"⚠️  WARNING - Drive path chưa có trong sys.path")
            print(f"Có thể cần chạy setup_colab_drive()")
    else:
        print("Không phải Colab, bỏ qua test này")


def test_file_operations():
    """Test khả năng đọc/ghi file"""
    print("\n" + "="*70)
    print("TEST 7: File operations")
    print("="*70)
    
    from vnstock.core.utils.env import get_vnstock_path
    
    path = get_vnstock_path()
    test_file = path / "test_file.txt"
    
    try:
        # Tạo thư mục nếu chưa có
        path.mkdir(parents=True, exist_ok=True)
        
        # Test ghi file
        with open(test_file, 'w') as f:
            f.write("Test content")
        print(f"✅ Ghi file thành công: {test_file}")
        
        # Test đọc file
        with open(test_file, 'r') as f:
            content = f.read()
        print(f"✅ Đọc file thành công: {content}")
        
        # Xóa file test
        test_file.unlink()
        print(f"✅ Xóa file test thành công")
        
        return True
        
    except Exception as e:
        print(f"❌ FAIL: {e}")
        return False


def run_all_tests():
    """Chạy tất cả các tests"""
    print("\n" + "🚀 "*(35//2))
    print("VNSTOCK GOOGLE COLAB DRIVE INTEGRATION TEST SUITE")
    print("🚀 "*(35//2) + "\n")
    
    results = {}
    
    try:
        results['colab_detection'] = test_colab_detection()
        results['vnstock_path'] = test_vnstock_path()
        results['const_paths'] = test_const_paths()
        results['vnai_inspector'] = test_vnai_inspector()
        test_colab_helpers()
        test_sys_path()
        results['file_ops'] = test_file_operations()
        
    except Exception as e:
        print(f"\n❌ Lỗi khi chạy tests: {e}")
        import traceback
        traceback.print_exc()
    
    # Summary
    print("\n" + "="*70)
    print("TỔNG KẾT")
    print("="*70)
    
    is_colab_env = results.get('colab_detection', False)
    
    if is_colab_env:
        print("\n✅ Đang chạy trên Google Colab")
        print("\nĐể sử dụng Drive persistence:")
        print("1. Mount Google Drive")
        print("2. Chạy: setup_colab_drive()")
        print("3. Cài đặt: !pip install --target=/content/drive/MyDrive/.vnstock vnstock")  # noqa: E501
    else:
        print("\n📍 Đang chạy trên môi trường local/standard")
        print("Drive persistence chỉ hoạt động trên Google Colab")
    
    print("\n" + "="*70 + "\n")


if __name__ == "__main__":
    run_all_tests()
