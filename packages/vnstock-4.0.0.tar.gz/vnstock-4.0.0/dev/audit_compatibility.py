#!/usr/bin/env python3
"""
Audit script: Detect Python 3.12+ compatibility issues in vnai/vnii modules.

Checks for:
- pkg_resources usage (deprecated in Python 3.12)
- importlib.metadata usage (recommended for Python 3.8+)
- Hardcoded version strings

Usage:
    python3 dev/audit_compatibility.py
"""

import re
import sys
from pathlib import Path

# ANSI colors
RED = '\033[91m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
RESET = '\033[0m'
BOLD = '\033[1m'


class CompatibilityAuditor:
    """Audit Python version compatibility"""
    
    def __init__(self):
        self.project_root = Path(__file__).parent.parent
        self.modules_to_check = [
            self.project_root / 'vnai',
            self.project_root / 'vnii',
            self.project_root / 'vnstock' / 'core' / 'utils'
        ]
        
        self.patterns = {
            'pkg_resources': r'\bpkg_resources\b',
            'importlib_metadata': r'importlib\.metadata',
            'pkg_resources_import': (
                r'from\s+pkg_resources\s+import|import\s+pkg_resources'
            ),
            'metadata_import': (
                r'from\s+importlib\.metadata\s+import|'
                r'import\s+importlib\.metadata'
            ),
            'version_function': r'(get_|)version\([\'"]([^\'"]+)[\'"]\)',
        }
        
        self.findings = {
            'pkg_resources_usage': [],
            'metadata_usage': [],
            'version_calls': [],
            'issues': []
        }
    
    def audit(self) -> int:
        """Run audit across all modules"""
        print(f"{BOLD}{BLUE}🔍 Starting Python Compatibility Audit...{RESET}\n")
        
        for module_path in self.modules_to_check:
            if not module_path.exists():
                print(f"{YELLOW}⚠️  Module not found: {module_path}{RESET}")
                continue
            
            self._audit_directory(module_path)
        
        return self._generate_report()
    
    def _audit_directory(self, directory: Path) -> None:
        """Recursively audit Python files in directory"""
        for py_file in directory.rglob('*.py'):
            # Skip cache and build directories
            if '__pycache__' in str(py_file) or '.egg' in str(py_file):
                continue
            
            self._audit_file(py_file)
    
    def _audit_file(self, file_path: Path) -> None:
        """Audit single Python file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = content.split('\n')
        except Exception as e:
            print(f"{RED}❌ Error reading {file_path}: {e}{RESET}")
            return
        
        rel_path = file_path.relative_to(self.project_root)
        
        # Check for pkg_resources usage
        pkg_resources_matches = []
        for i, line in enumerate(lines, 1):
            # Skip comments
            if line.strip().startswith('#'):
                continue
            if re.search(self.patterns['pkg_resources'], line):
                pkg_resources_matches.append({
                    'file': rel_path,
                    'line': i,
                    'content': line.strip()
                })
        
        # Check for importlib.metadata usage
        metadata_matches = []
        for i, line in enumerate(lines, 1):
            if re.search(self.patterns['importlib_metadata'], line):
                metadata_matches.append({
                    'file': rel_path,
                    'line': i,
                    'content': line.strip()
                })
        
        # Check for version() calls
        version_matches = []
        for i, line in enumerate(lines, 1):
            if re.search(self.patterns['version_function'], line):
                version_matches.append({
                    'file': rel_path,
                    'line': i,
                    'content': line.strip()
                })
        
        # Store findings
        if pkg_resources_matches:
            self.findings['pkg_resources_usage'].extend(pkg_resources_matches)
        if metadata_matches:
            self.findings['metadata_usage'].extend(metadata_matches)
        if version_matches:
            self.findings['version_calls'].extend(version_matches)
    
    def _generate_report(self) -> int:
        """Generate audit report"""
        print(f"\n{BOLD}{'='*70}")
        print("COMPATIBILITY AUDIT REPORT")
        print(f"{'='*70}{RESET}\n")
        
        # pkg_resources findings (CRITICAL for Python 3.12+)
        if self.findings['pkg_resources_usage']:
            print(
                f"{RED}{BOLD}🚨 CRITICAL: pkg_resources Usage Found"
                f" (Python 3.12+ incompatible){RESET}"
            )
            print(f"   {RED}This will break on Python 3.12+{RESET}\n")
            
            for finding in self.findings['pkg_resources_usage']:
                print(f"   {finding['file']}:{finding['line']}")
                print(f"   └─ {finding['content']}\n")
            
            self.findings['issues'].append({
                'severity': 'CRITICAL',
                'issue': 'pkg_resources usage',
                'count': len(self.findings['pkg_resources_usage']),
                'recommendation': 'Replace with importlib.metadata'
            })
        else:
            print(f"{GREEN}✅ No pkg_resources usage found{RESET}\n")
        
        # importlib.metadata findings (GOOD)
        if self.findings['metadata_usage']:
            msg = (
                f"{GREEN}{BOLD}✅ GOOD: importlib.metadata Usage Found"
                f" (Python 3.8+){RESET}"
            )
            print(msg + "\n")
            
            for finding in self.findings['metadata_usage']:
                print(f"   {finding['file']}:{finding['line']}")
                print(f"   └─ {finding['content']}\n")
        else:
            msg = (
                f"{YELLOW}ℹ️  No importlib.metadata usage found "
                f"(module may not check versions){RESET}"
            )
            print(msg + "\n")
        
        # Version call analysis
        if self.findings['version_calls']:
            print(f"{BLUE}{BOLD}📊 Version Calls Found:{RESET}\n")
            
            for finding in self.findings['version_calls']:
                print(f"   {finding['file']}:{finding['line']}")
                print(f"   └─ {finding['content']}\n")
        
        # Summary
        print(f"\n{BOLD}{'='*70}")
        print("SUMMARY")
        print(f"{'='*70}{RESET}\n")
        
        critical_count = len(self.findings['pkg_resources_usage'])
        good_count = len(self.findings['metadata_usage'])
        
        if critical_count > 0:
            print(f"{RED}❌ Python 3.12+ COMPATIBILITY ISSUES DETECTED{RESET}")
            msg_critical = (
                f"   {RED}• {critical_count} file(s) with "
                f"pkg_resources{RESET}"
            )
            print(msg_critical)
            msg_good = (
                f"   {GREEN}• {good_count} file(s) with "
                f"importlib.metadata{RESET}"
            )
            print(msg_good + "\n")
            
            print(f"{BOLD}RECOMMENDATIONS:{RESET}")
            print("   1. Replace pkg_resources with importlib.metadata")
            msg_rec = "   2. Ensure try/except blocks for package version"
            print(msg_rec + " checks")
            print("   3. Test on Python 3.12 before release\n")
            
            return 1  # Error code
        else:
            msg_success = (
                f"{GREEN}✅ No Python 3.12+ compatibility issues "
                f"found!{RESET}"
            )
            print(msg_success + "\n")
            return 0  # Success code


def main():
    """Run compatibility audit"""
    auditor = CompatibilityAuditor()
    exit_code: int = auditor.audit()
    sys.exit(exit_code)


if __name__ == '__main__':
    main()
