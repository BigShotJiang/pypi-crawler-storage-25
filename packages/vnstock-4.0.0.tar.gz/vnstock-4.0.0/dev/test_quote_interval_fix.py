#!/usr/bin/env python3
"""Test that Quote.history() preserves time for minute-based intervals."""

import sys
from datetime import datetime, timedelta

# Add parent directory to path
sys.path.insert(0, '/Users/mrthinh/Github/vnstock_dev')

from vnstock.explorer.vci.quote import Quote


def test_quote_interval_time_preservation():
    """Test that different intervals preserve appropriate time information."""
    print("Testing Quote.history() interval time preservation...")
    print("-" * 60)

    symbol = 'ACB'
    quote = Quote(symbol)

    # Test data
    start_date = '2025-01-02'
    test_cases = [
        ('1D', False, "Daily interval - should be date only"),
        ('1m', True, "Minute interval - should have HH:MM:SS"),
        ('5m', True, "5-minute interval - should have HH:MM:SS"),
        ('15m', True, "15-minute interval - should have HH:MM:SS"),
        ('30m', True, "30-minute interval - should have HH:MM:SS"),
        ('1H', True, "Hourly interval - should have HH:MM:SS"),
    ]

    for interval, should_have_time, description in test_cases:
        print(f"\n📊 Testing: {description}")
        print(f"   Interval: {interval}")

        try:
            df = quote.history(start=start_date, interval=interval)

            if df.empty:
                print(f"   ⚠️ No data returned for {interval}")
                continue

            # Check time column
            time_col = df['time'].iloc[0]
            time_str = str(time_col)

            print(f"   Sample time value: {time_str}")
            print(f"   Type: {type(time_col).__name__}")

            # Check if time has time component
            has_time_component = ':' in time_str

            if should_have_time:
                if has_time_component:
                    print(f"   ✅ PASS: Time preserved (has HH:MM:SS)")
                else:
                    print(f"   ❌ FAIL: Time NOT preserved (should have HH:MM:SS)")
            else:
                if not has_time_component:
                    print(f"   ✅ PASS: Date only (correct for daily)")
                else:
                    print(f"   ⚠️ Has time component (might be OK)")

            # Show sample of data
            print(f"   First 2 rows:")
            print(f"   {df[['time', 'open', 'close']].head(2).to_string(index=False)}")

        except Exception as e:
            print(f"   ❌ ERROR: {str(e)}")

    print("\n" + "=" * 60)
    print("Test completed!")


if __name__ == '__main__':
    test_quote_interval_time_preservation()
