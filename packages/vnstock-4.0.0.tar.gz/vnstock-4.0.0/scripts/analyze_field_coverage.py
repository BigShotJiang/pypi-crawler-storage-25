"""
Analyze field coverage gaps and identify mismatches between standardized fields
and actual fields in the profiled data.
"""

import json
import logging
from pathlib import Path
from collections import defaultdict
from typing import Dict, List, Set, Tuple
import pandas as pd

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class FieldCoverageAnalyzer:
    """Analyze field coverage and identify gaps."""
    
    def __init__(self, profile_dir: str = 'data/kbs_financial_profiles'):
        """Initialize analyzer."""
        self.profile_dir = Path(profile_dir)
        self.all_fields = defaultdict(lambda: defaultdict(set))
        self.field_details = {}
        self.mismatches = defaultdict(list)
        
    def load_profiled_data(self) -> Dict[str, Dict]:
        """Load all profiled data."""
        logger.info(f"Loading profiled data from {self.profile_dir}...")
        
        profiled_data = {}
        json_files = list(self.profile_dir.glob('*.json'))
        json_files = [f for f in json_files if f.name != 'errors.json']
        
        for json_file in json_files:
            try:
                with open(json_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    symbol = data.get('symbol')
                    if symbol:
                        profiled_data[symbol] = data
            except Exception as e:
                logger.warning(f"Error loading {json_file}: {e}")
        
        logger.info(f"Loaded {len(profiled_data)} symbols")
        return profiled_data
    
    def extract_all_fields(self, profiled_data: Dict[str, Dict]):
        """Extract all fields from profiled data."""
        logger.info("Extracting all fields...")
        
        for symbol, symbol_data in profiled_data.items():
            reports = symbol_data.get('reports', {})
            
            for report_type, report_data in reports.items():
                for period_type, period_data in report_data.items():
                    fields = period_data.get('fields', [])
                    
                    for field in fields:
                        field_id = field.get('item_id')
                        if not field_id:
                            continue
                        
                        # Store field details
                        if field_id not in self.field_details:
                            self.field_details[field_id] = {
                                'item': field.get('item'),
                                'item_en': field.get('item_en'),
                                'unit': field.get('unit'),
                                'levels': field.get('levels'),
                                'symbols': set(),
                                'report_types': set(),
                                'first_seen': symbol
                            }
                        
                        self.field_details[field_id]['symbols'].add(symbol)
                        self.field_details[field_id]['report_types'].add(report_type)
                        self.all_fields[report_type][period_type].add(field_id)
    
    def analyze_coverage_gaps(self) -> Dict:
        """Analyze coverage gaps in field definitions."""
        logger.info("Analyzing coverage gaps...")
        
        # Load reference fields
        ref_file = self.profile_dir / 'aggregated' / 'field_reference.csv'
        if not ref_file.exists():
            logger.warning("Field reference not found")
            return {}
        
        ref_df = pd.read_csv(ref_file)
        standardized_fields = set(ref_df['field_id'].astype(str))
        
        # Find all actual fields
        all_actual_fields = set()
        for report_dict in self.all_fields.values():
            for field_ids in report_dict.values():
                all_actual_fields.update(str(f) for f in field_ids)
        
        # Identify gaps
        missing_from_standard = all_actual_fields - standardized_fields
        extra_in_standard = standardized_fields - all_actual_fields
        
        analysis = {
            'total_standardized_fields': len(standardized_fields),
            'total_actual_fields': len(all_actual_fields),
            'coverage_percentage': (len(standardized_fields & all_actual_fields) / len(all_actual_fields) * 100) if all_actual_fields else 0,
            'missing_from_standard': missing_from_standard,
            'extra_in_standard': extra_in_standard,
            'field_details': self.field_details
        }
        
        return analysis
    
    def analyze_field_frequency(self) -> pd.DataFrame:
        """Analyze field frequency across symbols and reports."""
        logger.info("Analyzing field frequency...")
        
        rows = []
        for field_id, details in self.field_details.items():
            row = {
                'field_id': field_id,
                'item_vi': details['item'],
                'item_en': details['item_en'],
                'symbol_count': len(details['symbols']),
                'report_types': '|'.join(sorted(details['report_types'])),
                'coverage_pct': (len(details['symbols']) / 1586 * 100) if details['symbols'] else 0,
                'first_seen': details['first_seen']
            }
            rows.append(row)
        
        df = pd.DataFrame(rows)
        df = df.sort_values('symbol_count', ascending=False)
        
        logger.info(f"Created frequency analysis with {len(df)} fields")
        return df
    
    def identify_mismatches(self, profiled_data: Dict[str, Dict]) -> Dict:
        """Identify field mismatches by company and report type."""
        logger.info("Identifying field mismatches...")
        
        mismatches = defaultdict(lambda: defaultdict(list))
        
        for symbol, symbol_data in profiled_data.items():
            reports = symbol_data.get('reports', {})
            
            for report_type, report_data in reports.items():
                for period_type, period_data in report_data.items():
                    fields = period_data.get('fields', [])
                    
                    for field in fields:
                        field_id = field.get('item_id')
                        item = field.get('item')
                        item_en = field.get('item_en')
                        
                        # Check if field is in standardized set
                        if field_id and field_id not in self.field_details:
                            mismatches[symbol][report_type].append({
                                'field_id': field_id,
                                'item': item,
                                'item_en': item_en,
                                'period_type': period_type
                            })
        
        return dict(mismatches)
    
    def generate_report(self) -> str:
        """Generate comprehensive analysis report."""
        logger.info("Generating report...")
        
        profiled_data = self.load_profiled_data()
        self.extract_all_fields(profiled_data)
        
        coverage = self.analyze_coverage_gaps()
        frequency = self.analyze_field_frequency()
        mismatches = self.identify_mismatches(profiled_data)
        
        report = []
        report.append("=" * 80)
        report.append("FIELD COVERAGE ANALYSIS REPORT")
        report.append("=" * 80)
        
        report.append(f"\n--- Coverage Summary ---")
        report.append(f"Total Standardized Fields: {coverage.get('total_standardized_fields', 0)}")
        report.append(f"Total Actual Fields: {coverage.get('total_actual_fields', 0)}")
        report.append(f"Coverage Percentage: {coverage.get('coverage_percentage', 0):.1f}%")
        
        missing = coverage.get('missing_from_standard', set())
        if missing:
            report.append(f"\n--- Missing from Standard ({len(missing)} fields) ---")
            for field_id in sorted(missing)[:20]:
                details = self.field_details.get(field_id, {})
                report.append(f"  {field_id}: {details.get('item', 'N/A')}")
            if len(missing) > 20:
                report.append(f"  ... and {len(missing) - 20} more")
        
        extra = coverage.get('extra_in_standard', set())
        if extra:
            report.append(f"\n--- Extra in Standard ({len(extra)} fields) ---")
            for field_id in sorted(extra)[:10]:
                report.append(f"  {field_id}")
        
        report.append(f"\n--- Top 20 Most Common Fields ---")
        top_20 = frequency.head(20)
        for idx, row in top_20.iterrows():
            report.append(
                f"{row['field_id']:4} - {row['item_vi'][:40]:40} "
                f"({row['symbol_count']:4} symbols, {row['coverage_pct']:5.1f}%)"
            )
        
        report.append(f"\n--- Symbols with Mismatches ---")
        mismatch_count = sum(len(v) for v in mismatches.values())
        report.append(f"Total symbols with mismatches: {len(mismatches)}")
        report.append(f"Total mismatches: {mismatch_count}")
        
        if mismatches:
            report.append(f"\nSample mismatches (first 5 symbols):")
            for symbol, reports in list(mismatches.items())[:5]:
                report.append(f"\n  {symbol}:")
                for report_type, fields in reports.items():
                    report.append(f"    {report_type}: {len(fields)} mismatches")
                    for field in fields[:2]:
                        report.append(f"      - {field['field_id']}: {field['item']}")
        
        report.append("\n" + "=" * 80)
        
        return "\n".join(report)
    
    def save_analysis(self):
        """Save analysis results to files."""
        profiled_data = self.load_profiled_data()
        self.extract_all_fields(profiled_data)
        
        # Save frequency analysis
        frequency = self.analyze_field_frequency()
        freq_file = self.profile_dir / 'aggregated' / 'field_coverage_analysis.csv'
        frequency.to_csv(freq_file, index=False, encoding='utf-8')
        logger.info(f"Saved frequency analysis to {freq_file}")
        
        # Save mismatches
        mismatches = self.identify_mismatches(profiled_data)
        mismatch_file = self.profile_dir / 'aggregated' / 'field_mismatches.json'
        with open(mismatch_file, 'w', encoding='utf-8') as f:
            # Convert sets to lists for JSON serialization
            json_mismatches = {}
            for symbol, reports in mismatches.items():
                json_mismatches[symbol] = {}
                for report_type, fields in reports.items():
                    json_mismatches[symbol][report_type] = fields
            json.dump(json_mismatches, f, ensure_ascii=False, indent=2)
        logger.info(f"Saved mismatches to {mismatch_file}")
        
        # Save coverage analysis
        coverage = self.analyze_coverage_gaps()
        coverage_file = self.profile_dir / 'aggregated' / 'coverage_analysis.json'
        with open(coverage_file, 'w', encoding='utf-8') as f:
            coverage_data = {
                'total_standardized_fields': coverage.get('total_standardized_fields'),
                'total_actual_fields': coverage.get('total_actual_fields'),
                'coverage_percentage': coverage.get('coverage_percentage'),
                'missing_from_standard_count': len(coverage.get('missing_from_standard', set())),
                'extra_in_standard_count': len(coverage.get('extra_in_standard', set()))
            }
            json.dump(coverage_data, f, ensure_ascii=False, indent=2)
        logger.info(f"Saved coverage analysis to {coverage_file}")


if __name__ == '__main__':
    analyzer = FieldCoverageAnalyzer()
    
    # Generate and print report
    report = analyzer.generate_report()
    print(report)
    
    # Save analysis
    analyzer.save_analysis()
