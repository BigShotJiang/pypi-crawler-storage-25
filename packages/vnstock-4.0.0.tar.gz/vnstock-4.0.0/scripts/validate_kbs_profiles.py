"""
Utility script to validate and inspect KBS financial profiles.
Useful for checking data quality and debugging issues.
"""

import json
import logging
from pathlib import Path
from collections import defaultdict
from typing import Dict, List
import pandas as pd

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ProfileValidator:
    """Validate and inspect KBS financial profiles."""
    
    def __init__(self, profile_dir: str = 'data/kbs_financial_profiles'):
        """Initialize validator."""
        self.profile_dir = Path(profile_dir)
        
    def validate_profiles(self) -> Dict:
        """
        Validate all profile files.
        
        Returns:
            Dictionary with validation results
        """
        logger.info("Validating profiles...")
        
        results = {
            'total_files': 0,
            'valid_files': 0,
            'invalid_files': 0,
            'total_symbols': 0,
            'symbols_by_exchange': defaultdict(int),
            'report_types_found': set(),
            'errors': []
        }
        
        json_files = list(self.profile_dir.glob('*.json'))
        json_files = [f for f in json_files if f.name != 'errors.json']
        
        results['total_files'] = len(json_files)
        
        for json_file in json_files:
            try:
                with open(json_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                # Validate structure
                if 'symbol' not in data:
                    results['invalid_files'] += 1
                    results['errors'].append(f"{json_file.name}: Missing 'symbol'")
                    continue
                
                symbol = data['symbol']
                exchange = data.get('exchange', 'UNKNOWN')
                reports = data.get('reports', {})
                
                if not reports:
                    results['invalid_files'] += 1
                    results['errors'].append(f"{symbol}: No reports found")
                    continue
                
                results['valid_files'] += 1
                results['total_symbols'] += 1
                results['symbols_by_exchange'][exchange] += 1
                
                for report_type in reports.keys():
                    results['report_types_found'].add(report_type)
                    
            except json.JSONDecodeError as e:
                results['invalid_files'] += 1
                results['errors'].append(f"{json_file.name}: JSON decode error - {e}")
            except Exception as e:
                results['invalid_files'] += 1
                results['errors'].append(f"{json_file.name}: {str(e)}")
        
        results['report_types_found'] = sorted(list(results['report_types_found']))
        return results
    
    def check_errors(self) -> Dict:
        """
        Check error log.
        
        Returns:
            Dictionary with error statistics
        """
        error_file = self.profile_dir / 'errors.json'
        
        if not error_file.exists():
            return {'total_errors': 0, 'errors': []}
        
        try:
            with open(error_file, 'r', encoding='utf-8') as f:
                errors = json.load(f)
            
            error_types = defaultdict(int)
            for error in errors:
                error_msg = error.get('error', 'Unknown')
                # Extract error type
                if 'rate limit' in error_msg.lower():
                    error_types['rate_limit'] += 1
                elif 'not found' in error_msg.lower():
                    error_types['not_found'] += 1
                elif 'timeout' in error_msg.lower():
                    error_types['timeout'] += 1
                else:
                    error_types['other'] += 1
            
            return {
                'total_errors': len(errors),
                'error_types': dict(error_types),
                'sample_errors': errors[:5]
            }
        except Exception as e:
            return {'error': str(e)}
    
    def inspect_symbol(self, symbol: str) -> Dict:
        """
        Inspect a specific symbol's profile.
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Profile data for the symbol
        """
        symbol_file = self.profile_dir / f"{symbol}.json"
        
        if not symbol_file.exists():
            return {'error': f"Profile not found for {symbol}"}
        
        try:
            with open(symbol_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Create summary
            summary = {
                'symbol': data.get('symbol'),
                'exchange': data.get('exchange'),
                'processed_at': data.get('processed_at'),
                'reports': {}
            }
            
            for report_type, report_data in data.get('reports', {}).items():
                report_summary = {}
                for period_type, period_data in report_data.items():
                    fields = period_data.get('fields', [])
                    report_summary[period_type] = {
                        'field_count': len(fields),
                        'sample_fields': [f['item_id'] for f in fields[:3]]
                    }
                summary['reports'][report_type] = report_summary
            
            return summary
        except Exception as e:
            return {'error': str(e)}
    
    def get_field_statistics(self) -> Dict:
        """
        Get statistics about fields across all profiles.
        
        Returns:
            Dictionary with field statistics
        """
        logger.info("Calculating field statistics...")
        
        field_counts = defaultdict(int)
        report_type_counts = defaultdict(int)
        period_type_counts = defaultdict(int)
        
        json_files = list(self.profile_dir.glob('*.json'))
        json_files = [f for f in json_files if f.name != 'errors.json']
        
        for json_file in json_files:
            try:
                with open(json_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                for report_type, report_data in data.get('reports', {}).items():
                    report_type_counts[report_type] += 1
                    
                    for period_type, period_data in report_data.items():
                        period_type_counts[period_type] += 1
                        
                        fields = period_data.get('fields', [])
                        field_counts[len(fields)] += 1
                        
            except Exception as e:
                logger.warning(f"Error processing {json_file}: {e}")
        
        return {
            'field_count_distribution': dict(field_counts),
            'report_type_coverage': dict(report_type_counts),
            'period_type_coverage': dict(period_type_counts),
        }
    
    def print_report(self):
        """Print validation report."""
        logger.info("=" * 80)
        logger.info("KBS PROFILE VALIDATION REPORT")
        logger.info("=" * 80)
        
        # Validate profiles
        results = self.validate_profiles()
        
        logger.info("\n--- Profile Files ---")
        logger.info(f"Total files: {results['total_files']}")
        logger.info(f"Valid files: {results['valid_files']}")
        logger.info(f"Invalid files: {results['invalid_files']}")
        logger.info(f"Total symbols: {results['total_symbols']}")
        
        logger.info("\n--- Symbols by Exchange ---")
        for exchange, count in sorted(results['symbols_by_exchange'].items()):
            logger.info(f"{exchange}: {count} symbols")
        
        logger.info(f"\n--- Report Types Found ---")
        for report_type in results['report_types_found']:
            logger.info(f"  - {report_type}")
        
        # Check errors
        error_results = self.check_errors()
        logger.info(f"\n--- Errors ---")
        logger.info(f"Total errors: {error_results.get('total_errors', 0)}")
        if error_results.get('error_types'):
            for error_type, count in error_results['error_types'].items():
                logger.info(f"  {error_type}: {count}")
        
        # Field statistics
        field_stats = self.get_field_statistics()
        logger.info(f"\n--- Field Statistics ---")
        logger.info(f"Report type coverage: {field_stats['report_type_coverage']}")
        logger.info(f"Period type coverage: {field_stats['period_type_coverage']}")
        
        if results['invalid_files'] > 0:
            logger.info(f"\n--- Sample Errors ---")
            for error in results['errors'][:5]:
                logger.info(f"  {error}")
        
        logger.info("=" * 80)
        
        return results, error_results, field_stats


if __name__ == '__main__':
    import sys
    
    validator = ProfileValidator()
    
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        if command == 'inspect' and len(sys.argv) > 2:
            symbol = sys.argv[2].upper()
            result = validator.inspect_symbol(symbol)
            print(json.dumps(result, indent=2, ensure_ascii=False))
        elif command == 'report':
            validator.print_report()
        else:
            print("Usage:")
            print("  python validate_kbs_profiles.py report")
            print("  python validate_kbs_profiles.py inspect SYMBOL")
    else:
        validator.print_report()
