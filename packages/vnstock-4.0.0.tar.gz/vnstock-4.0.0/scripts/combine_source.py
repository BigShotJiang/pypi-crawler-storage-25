import os

def collect_files(root_dir, ext=".py"):
    filepaths = []
    for dirpath, _, filenames in os.walk(root_dir):
        for f in filenames:
            if f.endswith(ext):
                filepaths.append(os.path.join(dirpath, f))
    return sorted(filepaths)

def build_markdown(filepaths, output_file, base_dir):
    with open(output_file, "w", encoding="utf-8") as out:
        out.write("# Mã nguồn thư viện vnstock\n\n")
        out.write("Tài liệu này bao gồm toàn bộ mã nguồn của thư viện `vnstock` cho mục đích đăng ký bản quyền.\n\n")
        for fp in filepaths:
            rel_path = os.path.relpath(fp, base_dir)
            out.write(f"## {rel_path}\n\n")
            out.write("```python\n")
            with open(fp, "r", encoding="utf-8") as f:
                out.write(f.read())
            out.write("\n```\n\n")

if __name__ == "__main__":
    base_dir = "/Users/mrthinh/Github/vnstock"
    target_dir = os.path.join(base_dir, "vnstock")
    output_md = os.path.join(base_dir, "vnstock_source.md")
    
    files = collect_files(target_dir)
    print(f"Found {len(files)} Python files.")
    build_markdown(files, output_md, base_dir)
    print(f"Successfully wrote everything to {output_md}")
