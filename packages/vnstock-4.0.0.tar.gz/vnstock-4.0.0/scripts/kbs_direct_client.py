"""
Direct KBS API client for fetching financial data without vnstock library constraints.
Bypasses vnstock's rate limiting logic by making direct HTTP requests to KBS endpoints.
"""

import json
import time
import logging
from typing import Dict, Optional, List
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logger = logging.getLogger(__name__)


class KBSDirectClient:
    """Direct HTTP client for KBS API endpoints."""
    
    # KBS API endpoints
    BASE_URL = 'https://kbbuddywts.kbsec.com.vn'
    SAS_FINANCE_URL = f'{BASE_URL}/sas/kbsv-stock-data-store/stock/finance-info'
    IIS_LISTING_URL = f'{BASE_URL}/iis-server/investment/stock/search/data'
    
    # Report type codes
    REPORT_TYPES = {
        'income_statement': 'KQKD',
        'balance_sheet': 'CDKT',
        'cash_flow': 'LCTT',
        'ratio': 'CSTC',
    }
    
    def __init__(self, timeout: int = 30, max_retries: int = 3):
        """
        Initialize KBS direct client.
        
        Args:
            timeout: Request timeout in seconds
            max_retries: Maximum retries for failed requests
        """
        self.timeout = timeout
        self.max_retries = max_retries
        self.session = self._create_session()
        
    def _create_session(self) -> requests.Session:
        """Create requests session with retry strategy."""
        session = requests.Session()
        
        # Configure retry strategy
        retry_strategy = Retry(
            total=self.max_retries,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET"]
        )
        
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        # Set user agent
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        })
        
        return session
    
    def get_symbols(self, exchange: str = 'HOSE') -> List[str]:
        """
        Fetch stock symbols for an exchange.
        
        Args:
            exchange: Exchange code (HOSE, HNX, UPCOM)
            
        Returns:
            List of stock symbols
        """
        try:
            params = {
                'type': 'stock',
                'exchange': exchange,
                'pageSize': 10000
            }
            
            logger.info(f"Fetching symbols for {exchange}...")
            response = self.session.get(
                self.IIS_LISTING_URL,
                params=params,
                timeout=self.timeout
            )
            response.raise_for_status()
            
            data = response.json()
            symbols = []
            
            # API returns a direct list of items
            if isinstance(data, list):
                for item in data:
                    if isinstance(item, dict):
                        # Extract symbol (case-insensitive key lookup)
                        symbol = item.get('symbol') or item.get('Symbol') or item.get('code') or item.get('Code')
                        if symbol:
                            symbols.append(symbol)
            elif isinstance(data, dict) and 'data' in data:
                # Handle wrapped response
                items = data['data']
                if isinstance(items, list):
                    for item in items:
                        if isinstance(item, dict):
                            symbol = item.get('symbol') or item.get('Symbol') or item.get('code') or item.get('Code')
                            if symbol:
                                symbols.append(symbol)
            
            logger.info(f"Found {len(symbols)} symbols on {exchange}")
            return symbols
            
        except Exception as e:
            logger.error(f"Error fetching symbols for {exchange}: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return []
    
    def get_financial_data(
        self,
        symbol: str,
        report_type: str = 'income_statement',
        period_type: str = 'year',
        page: int = 1,
        page_size: int = 4
    ) -> Optional[Dict]:
        """
        Fetch financial data directly from KBS API.
        
        Args:
            symbol: Stock symbol
            report_type: Type of report (income_statement, balance_sheet, cash_flow, ratio)
            period_type: Period type (year or quarter)
            page: Page number
            page_size: Records per page
            
        Returns:
            Raw API response or None if failed
        """
        try:
            # Map report type to API code
            api_report_type = self.REPORT_TYPES.get(report_type, 'KQKD')
            
            # Map period type to API code (1=year, 2=quarter)
            api_period_type = 1 if period_type == 'year' else 2
            
            # Build URL
            url = f'{self.SAS_FINANCE_URL}/{symbol}'
            
            # Build params
            params = {
                'page': page,
                'pageSize': page_size,
                'type': api_report_type,
                'unit': 1000,
                'termtype': api_period_type,
            }
            
            # Add language ID for most report types
            if report_type != 'cash_flow':
                params['languageid'] = 1
            else:
                # Cash flow uses different parameter names
                params['code'] = symbol
                params['termType'] = api_period_type
            
            logger.debug(f"Fetching {report_type} for {symbol}...")
            
            response = self.session.get(
                url,
                params=params,
                timeout=self.timeout
            )
            response.raise_for_status()
            
            data = response.json()
            
            # Check if response has data
            if isinstance(data, dict):
                if 'data' in data and data['data']:
                    return data['data']
                elif 'Content' in data:
                    return data
            
            return None
            
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                logger.debug(f"No data found for {symbol} - {report_type}")
            else:
                logger.warning(f"HTTP error for {symbol} - {report_type}: {e}")
            return None
        except Exception as e:
            logger.warning(f"Error fetching {report_type} for {symbol}: {e}")
            return None
    
    def fetch_all_financial_data(
        self,
        symbol: str,
        report_types: Optional[List[str]] = None,
        period_types: Optional[List[str]] = None
    ) -> Dict:
        """
        Fetch all financial data for a symbol.
        
        Args:
            symbol: Stock symbol
            report_types: List of report types to fetch (default: all)
            period_types: List of period types to fetch (default: all)
            
        Returns:
            Dictionary with all financial data
        """
        if report_types is None:
            report_types = list(self.REPORT_TYPES.keys())
        if period_types is None:
            period_types = ['year', 'quarter']
        
        result = {
            'symbol': symbol,
            'reports': {}
        }
        
        for report_type in report_types:
            report_data = {}
            
            for period_type in period_types:
                data = self.get_financial_data(
                    symbol,
                    report_type=report_type,
                    period_type=period_type
                )
                
                if data:
                    report_data[period_type] = data
            
            if report_data:
                result['reports'][report_type] = report_data
        
        return result
    
    def close(self):
        """Close the session."""
        self.session.close()


class KBSDataFetcher:
    """High-level fetcher for KBS financial data with caching and error handling."""
    
    def __init__(self, timeout: int = 30, request_delay: float = 0.1):
        """
        Initialize fetcher.
        
        Args:
            timeout: Request timeout in seconds
            request_delay: Delay between requests in seconds
        """
        self.client = KBSDirectClient(timeout=timeout)
        self.request_delay = request_delay
        self.last_request_time = 0
    
    def _rate_limit(self):
        """Apply rate limiting between requests."""
        elapsed = time.time() - self.last_request_time
        if elapsed < self.request_delay:
            time.sleep(self.request_delay - elapsed)
        self.last_request_time = time.time()
    
    def fetch_symbol_data(
        self,
        symbol: str,
        report_types: Optional[List[str]] = None
    ) -> Optional[Dict]:
        """
        Fetch all financial data for a symbol with rate limiting.
        
        Args:
            symbol: Stock symbol
            report_types: List of report types to fetch
            
        Returns:
            Dictionary with financial data or None if failed
        """
        try:
            self._rate_limit()
            
            data = self.client.fetch_all_financial_data(
                symbol,
                report_types=report_types,
                period_types=['year', 'quarter']
            )
            
            if data.get('reports'):
                return data
            
            return None
            
        except Exception as e:
            logger.error(f"Error fetching data for {symbol}: {e}")
            return None
    
    def fetch_exchange_symbols(self, exchange: str) -> List[str]:
        """
        Fetch symbols for an exchange.
        
        Args:
            exchange: Exchange code (HOSE, HNX, UPCOM)
            
        Returns:
            List of symbols
        """
        self._rate_limit()
        return self.client.get_symbols(exchange)
    
    def close(self):
        """Close the client."""
        self.client.close()


if __name__ == '__main__':
    # Test the client
    logging.basicConfig(level=logging.INFO)
    
    fetcher = KBSDataFetcher(request_delay=0.5)
    
    # Test fetching symbols
    symbols = fetcher.fetch_exchange_symbols('HOSE')
    print(f"Found {len(symbols)} symbols on HOSE")
    
    # Test fetching data for a symbol
    if symbols:
        symbol = symbols[0]
        data = fetcher.fetch_symbol_data(symbol)
        if data:
            print(f"Successfully fetched data for {symbol}")
            print(f"Reports: {list(data.get('reports', {}).keys())}")
        else:
            print(f"No data found for {symbol}")
    
    fetcher.close()
