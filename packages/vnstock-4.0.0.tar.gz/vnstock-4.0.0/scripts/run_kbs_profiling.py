"""
Main entry point for KBS financial fields profiling workflow.
Orchestrates the complete profiling and aggregation process.
"""

import sys
import argparse
import logging
from pathlib import Path
from datetime import datetime

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description='KBS Financial Fields Profiling Workflow',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run full workflow (profile + aggregate)
  python run_kbs_profiling.py --full

  # Run only profiling
  python run_kbs_profiling.py --profile --workers 10

  # Run only aggregation
  python run_kbs_profiling.py --aggregate

  # Validate existing profiles
  python run_kbs_profiling.py --validate

  # Inspect specific symbol
  python run_kbs_profiling.py --inspect ACB
        """
    )
    
    parser.add_argument(
        '--full',
        action='store_true',
        help='Run complete workflow (profile + aggregate)'
    )
    parser.add_argument(
        '--profile',
        action='store_true',
        help='Run profiling step only'
    )
    parser.add_argument(
        '--aggregate',
        action='store_true',
        help='Run aggregation step only'
    )
    parser.add_argument(
        '--validate',
        action='store_true',
        help='Validate existing profiles'
    )
    parser.add_argument(
        '--inspect',
        type=str,
        metavar='SYMBOL',
        help='Inspect specific symbol profile'
    )
    parser.add_argument(
        '--workers',
        type=int,
        default=10,
        metavar='N',
        help='Number of parallel workers for profiling (default: 10)'
    )
    parser.add_argument(
        '--output-dir',
        type=str,
        default='data/kbs_financial_profiles',
        metavar='DIR',
        help='Output directory for profiles (default: data/kbs_financial_profiles)'
    )
    
    args = parser.parse_args()
    
    # If no action specified, show help
    if not any([args.full, args.profile, args.aggregate, args.validate, args.inspect]):
        parser.print_help()
        return 1
    
    logger.info("=" * 80)
    logger.info("KBS Financial Fields Profiling Workflow")
    logger.info(f"Started at: {datetime.now().isoformat()}")
    logger.info("=" * 80)
    
    try:
        # Profile step
        if args.full or args.profile:
            logger.info("\n[1/2] Starting Profiling Step...")
            from profile_kbs_financial_fields import FinancialFieldProfiler
            
            profiler = FinancialFieldProfiler(output_dir=args.output_dir)
            profiler.run(max_workers=args.workers)
            
            logger.info("✓ Profiling completed successfully")
        
        # Aggregate step
        if args.full or args.aggregate:
            logger.info("\n[2/2] Starting Aggregation Step...")
            from aggregate_kbs_financial_fields import FinancialFieldAggregator
            
            aggregator = FinancialFieldAggregator(input_dir=args.output_dir)
            aggregator.run()
            
            logger.info("✓ Aggregation completed successfully")
        
        # Validate step
        if args.validate:
            logger.info("\nValidating Profiles...")
            from validate_kbs_profiles import ProfileValidator
            
            validator = ProfileValidator(profile_dir=args.output_dir)
            validator.print_report()
        
        # Inspect step
        if args.inspect:
            logger.info(f"\nInspecting Symbol: {args.inspect.upper()}...")
            from validate_kbs_profiles import ProfileValidator
            import json
            
            validator = ProfileValidator(profile_dir=args.output_dir)
            result = validator.inspect_symbol(args.inspect.upper())
            print(json.dumps(result, indent=2, ensure_ascii=False))
        
        logger.info("\n" + "=" * 80)
        logger.info("Workflow completed successfully!")
        logger.info(f"Finished at: {datetime.now().isoformat()}")
        logger.info("=" * 80)
        
        return 0
        
    except Exception as e:
        logger.error(f"\n✗ Workflow failed with error: {str(e)}", exc_info=True)
        logger.info("=" * 80)
        return 1


if __name__ == '__main__':
    sys.exit(main())
