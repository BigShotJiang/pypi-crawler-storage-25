"""
Final field mapping with complete conflict resolution using field IDs.
"""

import json
import pandas as pd
from pathlib import Path
from typing import Dict

class FinalFieldMapper:
    """Final field mapper with complete conflict resolution."""
    
    def __init__(self):
        self.load_existing_mappings()
        self.resolve_all_conflicts()
        self.create_unique_mappings()
    
    def load_existing_mappings(self):
        """Load existing field mappings."""
        try:
            with open('data/kbs_financial_profiles/aggregated/field_snake_case_mappings.json', 'r', encoding='utf-8') as f:
                self.existing_mappings = json.load(f)
            print(f"Loaded {len(self.existing_mappings)} existing mappings")
        except Exception as e:
            print(f"Error loading existing mappings: {e}")
            self.existing_mappings = {}
    
    def resolve_all_conflicts(self):
        """Resolve all conflicts by ensuring unique names."""
        # Track used names
        used_names = set()
        self.unique_mappings = {}
        
        for field_id, mapping in self.existing_mappings.items():
            base_name = mapping['snake_case']
            
            # If name is already used, append field_id
            if base_name in used_names:
                unique_name = f"{base_name}_{field_id}"
            else:
                unique_name = base_name
            
            used_names.add(unique_name)
            
            self.unique_mappings[field_id] = {
                'original_vi': mapping['original_vi'],
                'original_en': mapping['original_en'],
                'snake_case': unique_name,
                'base_name': base_name,
                'was_conflict': base_name != unique_name
            }
        
        print(f"Resolved to {len(used_names)} unique names")
    
    def create_standardized_mappings(self):
        """Create standardized mappings with common financial terms."""
        # Create standardized mapping for common financial terms
        standardized_mappings = {}
        
        # Common financial terms mapping
        term_mappings = {
            # Income Statement
            'interest_income': 'interest_income',
            'interest_expense': 'interest_expense',
            'net_interest_income': 'net_interest_income',
            'fee_commission_income': 'fee_commission_income',
            'fee_commission_expense': 'fee_commission_expense',
            'net_fee_commission_income': 'net_fee_commission_income',
            'net_fx_trading_income': 'net_fx_trading_income',
            'net_trading_securities_income': 'net_trading_securities_income',
            'net_investment_securities_income': 'net_investment_securities_income',
            'other_income': 'other_income',
            'other_expenses': 'other_expenses',
            'net_other_income': 'net_other_income',
            'capital_contribution_income': 'capital_contribution_income',
            'operating_expenses': 'operating_expenses',
            'operating_profit': 'operating_profit',
            'credit_loss_provision': 'credit_loss_provision',
            'profit_before_tax': 'profit_before_tax',
            'corporate_income_tax': 'corporate_income_tax',
            'current_income_tax_expense': 'current_income_tax_expense',
            'deferred_income_tax_expense': 'deferred_income_tax_expense',
            'net_profit_after_tax': 'net_profit_after_tax',
            'minority_interest': 'minority_interest',
            'net_profit_attributable_parent': 'net_profit_attributable_parent',
            'earnings_per_share': 'earnings_per_share',
            
            # Balance Sheet
            'fixed_assets': 'fixed_assets',
            'tangible_fixed_assets': 'tangible_fixed_assets',
            'intangible_fixed_assets': 'intangible_fixed_assets',
            'finance_leased_fixed_assets': 'finance_leased_fixed_assets',
            'fixed_assets_cost': 'fixed_assets_cost',
            'accumulated_depreciation': 'accumulated_depreciation',
            'other_long_term_investments': 'other_long_term_investments',
            'investment_provision': 'investment_provision',
            'investment_properties': 'investment_properties',
            'investment_properties_cost': 'investment_properties_cost',
            'accumulated_depreciation_investment': 'accumulated_depreciation_investment',
            'other_assets': 'other_assets',
            'accounts_receivable': 'accounts_receivable',
            'deferred_tax_assets': 'deferred_tax_assets',
            'goodwill': 'goodwill',
            'other_assets_provision': 'other_assets_provision',
            'total_assets': 'total_assets',
            
            # Liabilities
            'government_borrowings': 'government_borrowings',
            'other_credit_institution_borrowings': 'other_credit_institution_borrowings',
            'other_credit_institution_deposits': 'other_credit_institution_deposits',
            'deferred_tax_liabilities': 'deferred_tax_liabilities',
            'other_liabilities': 'other_liabilities',
            'valuable_papers_issued': 'valuable_papers_issued',
            'investment_trust_capital': 'investment_trust_capital',
            'derivatives': 'derivatives',
            'customer_deposits': 'customer_deposits',
            'interest_receivable': 'interest_receivable',
            'total_liabilities': 'total_liabilities',
            
            # Equity
            'credit_institution_capital': 'credit_institution_capital',
            'charter_capital': 'charter_capital',
            'reserves': 'reserves',
            'credit_institution_reserves': 'credit_institution_reserves',
            'construction_investment_reserves': 'construction_investment_reserves',
            'other_capital': 'other_capital',
            'preferred_stock': 'preferred_stock',
            'treasury_shares': 'treasury_shares',
            'share_premium': 'share_premium',
            'undistributed_earnings': 'undistributed_earnings',
            'non_controlling_interest': 'non_controlling_interest',
            'total_liabilities_equity': 'total_liabilities_equity',
            
            # Cash Flow
            'net_cash_from_operations': 'net_cash_from_operations',
            'net_cash_from_investing': 'net_cash_from_investing',
            'net_cash_from_financing': 'net_cash_from_financing',
            'purchase_fixed_assets': 'purchase_fixed_assets',
            'proceeds_from_sale_fixed_assets': 'proceeds_from_sale_fixed_assets',
            'cost_of_sale_fixed_assets': 'cost_of_sale_fixed_assets',
            'purchase_investment_properties': 'purchase_investment_properties',
            'proceeds_from_sale_investment_properties': 'proceeds_from_sale_investment_properties',
            'cost_of_sale_investment_properties': 'cost_of_sale_investment_properties',
            'equity_issuance_proceeds': 'equity_issuance_proceeds',
            'change_customer_deposits': 'change_customer_deposits',
            'change_valuable_papers_issued': 'change_valuable_papers_issued',
            'change_investment_trust_capital': 'change_investment_trust_capital',
            'change_derivatives': 'change_derivatives',
            'change_other_operating_liabilities': 'change_other_operating_liabilities',
        }
        
        # Apply standardized mappings where possible
        self.standardized_mappings = {}
        for field_id, mapping in self.unique_mappings.items():
            base_name = mapping['base_name']
            
            # Check if base name matches any standardized term
            standardized_name = term_mappings.get(base_name, mapping['snake_case'])
            
            # Ensure uniqueness
            if standardized_name in [m['snake_case'] for m in self.standardized_mappings.values()]:
                standardized_name = f"{standardized_name}_{field_id}"
            
            self.standardized_mappings[field_id] = {
                'original_vi': mapping['original_vi'],
                'original_en': mapping['original_en'],
                'snake_case': standardized_name,
                'base_name': base_name,
                'was_conflict': mapping['was_conflict'],
                'was_standardized': standardized_name != mapping['snake_case']
            }
    
    def create_unique_mappings(self):
        """Create final unique mappings."""
        self.create_standardized_mappings()
        
        # Final check for uniqueness
        final_names = [m['snake_case'] for m in self.standardized_mappings.values()]
        if len(final_names) != len(set(final_names)):
            # Force uniqueness with field IDs
            used_names = set()
            for field_id, mapping in self.standardized_mappings.items():
                name = mapping['snake_case']
                if name in used_names:
                    mapping['snake_case'] = f"{name}_{field_id}"
                used_names.add(mapping['snake_case'])
    
    def save_final_mappings(self, output_file: str = 'field_snake_case_standardized.json'):
        """Save final standardized mappings."""
        output_path = Path('data/kbs_financial_profiles/aggregated') / output_file
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(self.standardized_mappings, f, ensure_ascii=False, indent=2)
        print(f"Saved standardized mappings to {output_path}")
    
    def create_csv_output(self):
        """Create CSV output for easy review."""
        rows = []
        for field_id, mapping in self.standardized_mappings.items():
            rows.append({
                'field_id': field_id,
                'original_vi': mapping['original_vi'],
                'original_en': mapping['original_en'],
                'final_snake_case': mapping['snake_case'],
                'base_name': mapping['base_name'],
                'was_conflict': mapping['was_conflict'],
                'was_standardized': mapping['was_standardized']
            })
        
        df = pd.DataFrame(rows)
        df = df.sort_values('final_snake_case')
        
        output_path = Path('data/kbs_financial_profiles/aggregated') / 'field_snake_case_standardized.csv'
        df.to_csv(output_path, index=False, encoding='utf-8')
        print(f"Saved standardized CSV to {output_path}")
        
        return df
    
    def generate_report(self) -> str:
        """Generate final mapping report."""
        report = []
        report.append("=" * 100)
        report.append("FINAL STANDARDIZED FIELD MAPPING REPORT")
        report.append("=" * 100)
        
        report.append(f"\nTotal Fields: {len(self.standardized_mappings)}")
        
        # Statistics
        conflicts = sum(1 for m in self.standardized_mappings.values() if m['was_conflict'])
        standardized = sum(1 for m in self.standardized_mappings.values() if m['was_standardized'])
        
        report.append(f"Fields with conflicts: {conflicts}")
        report.append(f"Fields standardized: {standardized}")
        
        # Check uniqueness
        final_names = [m['snake_case'] for m in self.standardized_mappings.values()]
        unique_names = set(final_names)
        
        report.append(f"Unique snake_case names: {len(unique_names)}")
        
        if len(final_names) == len(unique_names):
            report.append("✅ All field names are unique!")
        else:
            report.append("⚠️  WARNING: Still have duplicate names!")
        
        report.append(f"\n--- Sample Standardized Mappings ---")
        # Show some examples
        examples = []
        for field_id, mapping in list(self.standardized_mappings.items())[:30]:
            examples.append(
                f"{field_id:4} -> {mapping['snake_case']:40} "
                f"({mapping['original_vi'][:30]:30})"
            )
        
        for example in examples:
            report.append(example)
        
        report.append("\n" + "=" * 100)
        
        return "\n".join(report)


def main():
    """Main function."""
    print("Creating final standardized field mappings...")
    
    mapper = FinalFieldMapper()
    
    # Generate report
    report = mapper.generate_report()
    print(report)
    
    # Save final mappings
    mapper.save_final_mappings()
    
    # Create CSV
    df = mapper.create_csv_output()
    
    print(f"\n✅ Final standardized field mapping completed successfully!")
    print(f"Total unique field names: {len(set(df['final_snake_case']))}")


if __name__ == '__main__':
    main()
