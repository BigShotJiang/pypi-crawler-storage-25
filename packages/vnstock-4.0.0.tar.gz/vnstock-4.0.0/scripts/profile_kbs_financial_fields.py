"""
Script to profile financial report fields from KBS data source.
Fetches financial data for all stocks across HOSE, HNX, and UPCOM exchanges
and saves the raw data for later aggregation and analysis.
"""

import json
import time
import logging
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict, Optional, Tuple
import pandas as pd
from collections import defaultdict

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('profile_kbs_financial.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Import direct KBS client
from kbs_direct_client import KBSDataFetcher


class FinancialFieldProfiler:
    """Profile financial report fields from KBS data source."""
    
    def __init__(self, output_dir: str = 'data/kbs_financial_profiles', request_delay: float = 0.1):
        """
        Initialize the profiler.
        
        Args:
            output_dir: Directory to save profiling data
            request_delay: Delay between requests in seconds (for rate limiting)
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.exchanges = ['HOSE', 'HNX', 'UPCOM']
        self.report_types = ['income_statement', 'balance_sheet', 'cash_flow', 'ratio']
        self.period_types = ['year', 'quarter']
        
        # Initialize KBS direct client
        self.fetcher = KBSDataFetcher(timeout=30, request_delay=request_delay)
        
        # Data storage
        self.field_data = defaultdict(lambda: defaultdict(list))
        self.errors = []
        self.processed_count = 0
        self.failed_count = 0
        
    def get_symbols(self) -> Dict[str, List[str]]:
        """
        Get all stock symbols from each exchange.
        
        Returns:
            Dictionary mapping exchange to list of symbols
        """
        logger.info("Fetching stock symbols from KBS...")
        symbols_by_exchange = {}
        
        try:
            for exchange in self.exchanges:
                exchange_symbols = self.fetcher.fetch_exchange_symbols(exchange)
                symbols_by_exchange[exchange] = exchange_symbols
                logger.info(f"Found {len(exchange_symbols)} stocks on {exchange}")
                
        except Exception as e:
            logger.error(f"Error fetching symbols: {e}")
            raise
        
        return symbols_by_exchange
    
    def fetch_financial_data(
        self, 
        symbol: str, 
        report_type: str, 
        period_type: str
    ) -> Optional[Dict]:
        """
        Fetch financial data for a symbol from raw KBS API.
        
        Args:
            symbol: Stock symbol
            report_type: Type of report (income_statement, balance_sheet, cash_flow, ratio)
            period_type: Period type (year or quarter)
            
        Returns:
            Dictionary with field information or None if failed
        """
        try:
            # Fetch raw data from KBS API
            raw_data = self.fetcher.client.get_financial_data(
                symbol,
                report_type=report_type,
                period_type=period_type
            )
            
            if not raw_data:
                return None
            
            # Extract field information from raw API response
            field_info = {
                'symbol': symbol,
                'report_type': report_type,
                'period_type': period_type,
                'timestamp': datetime.now().isoformat(),
                'raw_response': raw_data,
                'fields': []
            }
            
            # Parse fields from raw response
            fields = self._parse_fields_from_raw_data(raw_data, report_type)
            field_info['fields'] = fields
            
            return field_info if fields else None
            
        except Exception as e:
            error_msg = f"Error fetching {report_type} for {symbol} ({period_type}): {str(e)}"
            logger.warning(error_msg)
            self.errors.append({
                'symbol': symbol,
                'report_type': report_type,
                'period_type': period_type,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            })
            return None
    
    def _parse_fields_from_raw_data(self, raw_data: Dict, report_type: str) -> List[Dict]:
        """
        Parse field information from raw KBS API response.
        
        Args:
            raw_data: Raw API response
            report_type: Type of report
            
        Returns:
            List of field dictionaries
        """
        fields = []
        
        try:
            # Handle different response structures
            if isinstance(raw_data, dict):
                # Check for Content key (used in some responses)
                if 'Content' in raw_data:
                    content = raw_data['Content']
                    
                    # Get the appropriate key based on report type
                    if report_type == 'income_statement':
                        report_key = 'Kết quả kinh doanh'
                    elif report_type == 'balance_sheet':
                        report_key = 'Cân đối kế toán'
                    elif report_type == 'cash_flow':
                        # Try both types of cash flow
                        if 'Lưu chuyển tiền tệ gián tiếp' in content:
                            report_key = 'Lưu chuyển tiền tệ gián tiếp'
                        elif 'Lưu chuyển tiền tệ trực tiếp' in content:
                            report_key = 'Lưu chuyển tiền tệ trực tiếp'
                        else:
                            report_key = None
                    elif report_type == 'ratio':
                        # Combine all ratio groups
                        ratio_groups = [
                            'Nhóm chỉ số Định giá',
                            'Nhóm chỉ số Sinh lợi',
                            'Nhóm chỉ số Tăng trưởng',
                            'Nhóm chỉ số Thanh khoản',
                            'Nhóm chỉ số Chất lượng tài sản'
                        ]
                        for group_key in ratio_groups:
                            if group_key in content:
                                fields.extend(self._extract_fields_from_list(content[group_key]))
                        return fields
                    else:
                        report_key = None
                    
                    if report_key and report_key in content:
                        fields = self._extract_fields_from_list(content[report_key])
                
                # Handle direct list response
                elif isinstance(raw_data, list):
                    fields = self._extract_fields_from_list(raw_data)
            
            elif isinstance(raw_data, list):
                fields = self._extract_fields_from_list(raw_data)
        
        except Exception as e:
            logger.warning(f"Error parsing fields from raw data: {e}")
        
        return fields
    
    def _extract_fields_from_list(self, data_list: List) -> List[Dict]:
        """
        Extract field information from a list of records.
        
        Args:
            data_list: List of field records
            
        Returns:
            List of field dictionaries
        """
        fields = []
        
        for record in data_list:
            if not isinstance(record, dict):
                continue
            
            field = {
                'item': record.get('Name', ''),
                'item_en': record.get('NameEn', ''),
                'item_id': record.get('ID', record.get('Name', '')),
                'unit': record.get('Unit', ''),
                'levels': record.get('Levels', 0),
                'row_number': record.get('RowNumber', record.get('ID', 0)),
            }
            
            # Only add if has meaningful data
            if field['item'] or field['item_en']:
                fields.append(field)
        
        return fields
    
    def process_symbol(
        self, 
        symbol: str, 
        exchange: str,
        max_retries: int = 3
    ) -> bool:
        """
        Process all financial reports for a symbol.
        
        Args:
            symbol: Stock symbol
            exchange: Exchange name
            max_retries: Maximum number of retries on rate limit
            
        Returns:
            True if successful, False otherwise
        """
        try:
            symbol_data = {
                'symbol': symbol,
                'exchange': exchange,
                'processed_at': datetime.now().isoformat(),
                'reports': {}
            }
            
            # Fetch each report type
            for report_type in self.report_types:
                report_data = {}
                
                # Try both year and quarter periods
                for period_type in self.period_types:
                    field_info = self.fetch_financial_data(
                        symbol, 
                        report_type, 
                        period_type
                    )
                    
                    if field_info:
                        report_data[period_type] = field_info
                
                if report_data:
                    symbol_data['reports'][report_type] = report_data
            
            # Save symbol data
            if symbol_data['reports']:
                output_file = self.output_dir / f"{symbol}.json"
                with open(output_file, 'w', encoding='utf-8') as f:
                    json.dump(symbol_data, f, ensure_ascii=False, indent=2)
                
                self.processed_count += 1
                logger.info(f"✓ Processed {symbol} ({exchange}) - {len(symbol_data['reports'])} report types")
                return True
            else:
                logger.warning(f"✗ No data found for {symbol} ({exchange})")
                self.failed_count += 1
                return False
                
        except Exception as e:
            logger.error(f"Error processing {symbol}: {str(e)}")
            self.errors.append({
                'symbol': symbol,
                'exchange': exchange,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            })
            self.failed_count += 1
            return False
    
    def run(self, max_workers: int = 10):
        """
        Run the profiling process with parallel execution.
        
        Args:
            max_workers: Number of parallel threads
        """
        logger.info("=" * 80)
        logger.info("Starting KBS Financial Fields Profiling")
        logger.info("=" * 80)
        
        start_time = time.time()
        
        try:
            # Get all symbols
            symbols_by_exchange = self.get_symbols()
            total_symbols = sum(len(symbols) for symbols in symbols_by_exchange.values())
            logger.info(f"Total symbols to process: {total_symbols}")
            
            # Process symbols with thread pool
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {}
                
                for exchange, symbols in symbols_by_exchange.items():
                    for symbol in symbols:
                        future = executor.submit(self.process_symbol, symbol, exchange)
                        futures[future] = (symbol, exchange)
                
                # Track progress
                completed = 0
                for future in as_completed(futures):
                    completed += 1
                    symbol, exchange = futures[future]
                    
                    try:
                        result = future.result()
                    except Exception as e:
                        logger.error(f"Task failed for {symbol}: {e}")
                    
                    # Progress update every 50 symbols
                    if completed % 50 == 0:
                        elapsed = time.time() - start_time
                        rate = completed / elapsed
                        remaining = (total_symbols - completed) / rate if rate > 0 else 0
                        logger.info(
                            f"Progress: {completed}/{total_symbols} "
                            f"({100*completed/total_symbols:.1f}%) - "
                            f"ETA: {remaining/60:.1f}m"
                        )
            
            # Summary
            elapsed = time.time() - start_time
            logger.info("=" * 80)
            logger.info("Profiling Complete")
            logger.info(f"Processed: {self.processed_count} symbols")
            logger.info(f"Failed: {self.failed_count} symbols")
            logger.info(f"Total time: {elapsed/60:.2f} minutes")
            logger.info(f"Output directory: {self.output_dir}")
            logger.info("=" * 80)
            
            # Save error log
            if self.errors:
                error_file = self.output_dir / 'errors.json'
                with open(error_file, 'w', encoding='utf-8') as f:
                    json.dump(self.errors, f, ensure_ascii=False, indent=2)
                logger.info(f"Errors saved to {error_file}")
        
        finally:
            # Clean up
            self.fetcher.close()


if __name__ == '__main__':
    profiler = FinancialFieldProfiler(output_dir='data/kbs_financial_profiles')
    profiler.run(max_workers=10)
