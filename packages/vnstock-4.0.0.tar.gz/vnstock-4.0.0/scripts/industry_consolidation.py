"""
Industry-based financial data consolidation and analysis.
Consolidates financial metrics by industry for comparative analysis.
"""

import json
import logging
from pathlib import Path
from collections import defaultdict
from typing import Dict, List, Optional, Tuple
import pandas as pd
import numpy as np

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class IndustryConsolidator:
    """Consolidate and analyze financial data by industry."""
    
    def __init__(self, profile_dir: str = 'data/kbs_financial_profiles'):
        """
        Initialize consolidator.
        
        Args:
            profile_dir: Directory containing profiled data
        """
        self.profile_dir = Path(profile_dir)
        self.industry_symbols = {}
        self.industry_data = defaultdict(lambda: defaultdict(list))
        self.industry_stats = {}
        
    def load_industry_mapping(self) -> Dict[str, str]:
        """
        Load industry mapping from vnstock Listing.
        
        Returns:
            Dictionary mapping symbol to industry
        """
        logger.info("Loading industry mapping...")
        
        try:
            from vnstock import Listing
            listing = Listing(source='KBS')
            df = listing.symbols_by_industries()
            
            industry_map = dict(zip(df['symbol'], df['industry_name']))
            logger.info(f"Loaded industry mapping for {len(industry_map)} symbols")
            
            return industry_map
        except Exception as e:
            logger.error(f"Error loading industry mapping: {e}")
            return {}
    
    def load_profiled_data(self) -> Dict[str, Dict]:
        """Load all profiled data."""
        logger.info(f"Loading profiled data from {self.profile_dir}...")
        
        profiled_data = {}
        json_files = list(self.profile_dir.glob('*.json'))
        json_files = [f for f in json_files if f.name != 'errors.json']
        
        for json_file in json_files:
            try:
                with open(json_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    symbol = data.get('symbol')
                    if symbol:
                        profiled_data[symbol] = data
            except Exception as e:
                logger.warning(f"Error loading {json_file}: {e}")
        
        logger.info(f"Loaded {len(profiled_data)} symbols")
        return profiled_data
    
    def consolidate_by_industry(self, profiled_data: Dict[str, Dict], 
                               industry_map: Dict[str, str]):
        """
        Consolidate financial data by industry.
        
        Args:
            profiled_data: Profiled financial data
            industry_map: Symbol to industry mapping
        """
        logger.info("Consolidating data by industry...")
        
        for symbol, symbol_data in profiled_data.items():
            industry = industry_map.get(symbol, 'Unknown')
            
            if industry not in self.industry_symbols:
                self.industry_symbols[industry] = []
            self.industry_symbols[industry].append(symbol)
            
            # Extract field information
            reports = symbol_data.get('reports', {})
            for report_type, report_data in reports.items():
                for period_type, period_data in report_data.items():
                    fields = period_data.get('fields', [])
                    
                    for field in fields:
                        field_id = field.get('item_id')
                        if field_id:
                            self.industry_data[industry][report_type].append({
                                'symbol': symbol,
                                'field_id': field_id,
                                'item': field.get('item'),
                                'item_en': field.get('item_en'),
                                'period_type': period_type
                            })
        
        logger.info(f"Consolidated data for {len(self.industry_symbols)} industries")
    
    def analyze_industry_field_coverage(self) -> pd.DataFrame:
        """
        Analyze field coverage by industry.
        
        Returns:
            DataFrame with industry field coverage statistics
        """
        logger.info("Analyzing industry field coverage...")
        
        rows = []
        for industry, symbols in self.industry_symbols.items():
            # Count unique fields by report type
            field_counts = defaultdict(set)
            
            for report_type, fields_list in self.industry_data[industry].items():
                for field_info in fields_list:
                    field_id = field_info['field_id']
                    field_counts[report_type].add(field_id)
            
            row = {
                'industry': industry,
                'symbol_count': len(symbols),
                'income_statement_fields': len(field_counts.get('income_statement', set())),
                'balance_sheet_fields': len(field_counts.get('balance_sheet', set())),
                'cash_flow_fields': len(field_counts.get('cash_flow', set())),
                'ratio_fields': len(field_counts.get('ratio', set())),
                'total_unique_fields': sum(len(f) for f in field_counts.values())
            }
            rows.append(row)
        
        df = pd.DataFrame(rows)
        df = df.sort_values('symbol_count', ascending=False)
        
        logger.info(f"Created industry coverage analysis for {len(df)} industries")
        return df
    
    def get_industry_field_comparison(self, report_type: str = 'income_statement') -> pd.DataFrame:
        """
        Get field comparison across industries.
        
        Args:
            report_type: Type of report to analyze
            
        Returns:
            DataFrame with field presence by industry
        """
        logger.info(f"Analyzing {report_type} field comparison across industries...")
        
        # Collect all fields for this report type
        all_fields = set()
        for industry_fields in self.industry_data.values():
            for field_info in industry_fields.get(report_type, []):
                all_fields.add(field_info['field_id'])
        
        # Create matrix
        rows = []
        for field_id in sorted(all_fields):
            row = {'field_id': field_id}
            
            for industry in sorted(self.industry_symbols.keys()):
                # Count symbols in industry that have this field
                symbol_count = 0
                for field_info in self.industry_data[industry].get(report_type, []):
                    if field_info['field_id'] == field_id:
                        symbol_count += 1
                
                industry_symbol_count = len(self.industry_symbols[industry])
                coverage_pct = (symbol_count / industry_symbol_count * 100) if industry_symbol_count > 0 else 0
                
                row[industry] = coverage_pct
            
            rows.append(row)
        
        df = pd.DataFrame(rows)
        logger.info(f"Created field comparison matrix with {len(df)} fields")
        return df
    
    def calculate_industry_statistics(self) -> Dict[str, Dict]:
        """
        Calculate statistics for each industry.
        
        Returns:
            Dictionary with industry statistics
        """
        logger.info("Calculating industry statistics...")
        
        stats = {}
        for industry, symbols in self.industry_symbols.items():
            field_counts = defaultdict(set)
            
            for report_type, fields_list in self.industry_data[industry].items():
                for field_info in fields_list:
                    field_id = field_info['field_id']
                    field_counts[report_type].add(field_id)
            
            stats[industry] = {
                'symbol_count': len(symbols),
                'income_statement_fields': len(field_counts.get('income_statement', set())),
                'balance_sheet_fields': len(field_counts.get('balance_sheet', set())),
                'cash_flow_fields': len(field_counts.get('cash_flow', set())),
                'ratio_fields': len(field_counts.get('ratio', set())),
                'total_fields': sum(len(f) for f in field_counts.values()),
                'avg_fields_per_symbol': sum(len(f) for f in field_counts.values()) / len(symbols) if symbols else 0
            }
        
        return stats
    
    def generate_industry_report(self) -> str:
        """Generate comprehensive industry analysis report."""
        logger.info("Generating industry report...")
        
        industry_map = self.load_industry_mapping()
        profiled_data = self.load_profiled_data()
        self.consolidate_by_industry(profiled_data, industry_map)
        
        coverage_df = self.analyze_industry_field_coverage()
        stats = self.calculate_industry_statistics()
        
        report = []
        report.append("=" * 80)
        report.append("INDUSTRY-BASED FINANCIAL DATA CONSOLIDATION REPORT")
        report.append("=" * 80)
        
        report.append(f"\n--- Industry Summary ---")
        report.append(f"Total Industries: {len(self.industry_symbols)}")
        report.append(f"Total Symbols: {sum(len(s) for s in self.industry_symbols.values())}")
        
        report.append(f"\n--- Industry Breakdown ---")
        for _, row in coverage_df.iterrows():
            report.append(
                f"{row['industry']:40} - {row['symbol_count']:4} symbols, "
                f"{row['total_unique_fields']:4} fields"
            )
        
        report.append(f"\n--- Field Coverage by Report Type ---")
        report.append(f"{'Industry':40} {'Income':8} {'Balance':8} {'CashFlow':8} {'Ratio':8}")
        report.append("-" * 80)
        for _, row in coverage_df.iterrows():
            report.append(
                f"{row['industry']:40} {row['income_statement_fields']:8} "
                f"{row['balance_sheet_fields']:8} {row['cash_flow_fields']:8} "
                f"{row['ratio_fields']:8}"
            )
        
        report.append(f"\n--- Top 10 Industries by Symbol Count ---")
        top_10 = coverage_df.head(10)
        for idx, row in top_10.iterrows():
            report.append(
                f"{idx+1:2}. {row['industry']:40} - {row['symbol_count']:4} symbols"
            )
        
        report.append("\n" + "=" * 80)
        
        return "\n".join(report)
    
    def save_industry_analysis(self):
        """Save industry analysis to files."""
        industry_map = self.load_industry_mapping()
        profiled_data = self.load_profiled_data()
        self.consolidate_by_industry(profiled_data, industry_map)
        
        output_dir = self.profile_dir / 'aggregated'
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Save industry coverage
        coverage_df = self.analyze_industry_field_coverage()
        coverage_file = output_dir / 'industry_coverage.csv'
        coverage_df.to_csv(coverage_file, index=False, encoding='utf-8')
        logger.info(f"Saved industry coverage to {coverage_file}")
        
        # Save industry field comparison
        comparison_df = self.get_industry_field_comparison('income_statement')
        comparison_file = output_dir / 'industry_field_comparison.csv'
        comparison_df.to_csv(comparison_file, index=False, encoding='utf-8')
        logger.info(f"Saved field comparison to {comparison_file}")
        
        # Save industry statistics
        stats = self.calculate_industry_statistics()
        stats_file = output_dir / 'industry_statistics.json'
        with open(stats_file, 'w', encoding='utf-8') as f:
            json.dump(stats, f, ensure_ascii=False, indent=2)
        logger.info(f"Saved statistics to {stats_file}")
        
        # Save industry symbols mapping
        symbols_file = output_dir / 'industry_symbols.json'
        with open(symbols_file, 'w', encoding='utf-8') as f:
            json.dump(self.industry_symbols, f, ensure_ascii=False, indent=2)
        logger.info(f"Saved symbols mapping to {symbols_file}")


if __name__ == '__main__':
    consolidator = IndustryConsolidator()
    
    # Generate and print report
    report = consolidator.generate_industry_report()
    print(report)
    
    # Save analysis
    consolidator.save_industry_analysis()
