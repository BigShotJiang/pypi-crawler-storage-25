"""
Standardized snake_case field mapping for KBS financial data.
Creates consistent field names based on field coverage analysis.
"""

import re
import json
import pandas as pd
from pathlib import Path
from typing import Dict, Tuple

class FieldNameNormalizer:
    """Normalize Vietnamese and English field names to snake_case."""
    
    def __init__(self):
        self.field_mappings = {}
        self.load_field_data()
        self.create_mappings()
    
    def load_field_data(self):
        """Load field data from coverage analysis."""
        try:
            df = pd.read_csv('data/kbs_financial_profiles/aggregated/field_coverage_analysis.csv')
            self.field_data = df[['field_id', 'item_vi', 'item_en']].to_dict('records')
            print(f"Loaded {len(self.field_data)} fields from coverage analysis")
        except Exception as e:
            print(f"Error loading field data: {e}")
            self.field_data = []
    
    def normalize_vietnamese_to_snake_case(self, text: str) -> str:
        """Convert Vietnamese text to snake_case."""
        if not text:
            return ""
        
        # Remove numbering and special characters
        text = re.sub(r'^[\d\.\s]*', '', text.strip())
        
        # Replace Vietnamese characters
        vietnamese_map = {
            'á': 'a', 'à': 'a', 'ả': 'a', 'ã': 'a', 'ạ': 'a',
            'ă': 'a', 'ắ': 'a', 'ằ': 'a', 'ẳ': 'a', 'ẵ': 'a', 'ặ': 'a',
            'â': 'a', 'ấ': 'a', 'ầ': 'a', 'ẩ': 'a', 'ẫ': 'a', 'ậ': 'a',
            'é': 'e', 'è': 'e', 'ẻ': 'e', 'ẽ': 'e', 'ẹ': 'e',
            'ê': 'e', 'ế': 'e', 'ề': 'e', 'ể': 'e', 'ễ': 'e', 'ệ': 'e',
            'í': 'i', 'ì': 'i', 'ỉ': 'i', 'ĩ': 'i', 'ị': 'i',
            'ó': 'o', 'ò': 'o', 'ỏ': 'o', 'õ': 'o', 'ọ': 'o',
            'ô': 'o', 'ố': 'o', 'ồ': 'o', 'ổ': 'o', 'ỗ': 'o', 'ộ': 'o',
            'ơ': 'o', 'ớ': 'o', 'ờ': 'o', 'ở': 'o', 'ỡ': 'o', 'ợ': 'o',
            'ú': 'u', 'ù': 'u', 'ủ': 'u', 'ũ': 'u', 'ụ': 'u',
            'ư': 'u', 'ứ': 'u', 'ừ': 'u', 'ử': 'u', 'ữ': 'u', 'ự': 'u',
            'ý': 'y', 'ỳ': 'y', 'ỷ': 'y', 'ỹ': 'y', 'ỵ': 'y',
            'đ': 'd',
            'Á': 'A', 'À': 'A', 'Ả': 'A', 'Ã': 'A', 'Ạ': 'A',
            'Ă': 'A', 'Ắ': 'A', 'Ằ': 'A', 'Ẳ': 'A', 'Ẵ': 'A', 'Ặ': 'A',
            'Â': 'A', 'Ấ': 'A', 'Ầ': 'A', 'Ẩ': 'A', 'Ẫ': 'A', 'Ậ': 'A',
            'É': 'E', 'È': 'E', 'Ẻ': 'E', 'Ẽ': 'E', 'Ẹ': 'E',
            'Ê': 'E', 'Ế': 'E', 'Ề': 'E', 'Ể': 'E', 'Ễ': 'E', 'Ệ': 'E',
            'Í': 'I', 'Ì': 'I', 'Ỉ': 'I', 'Ĩ': 'I', 'Ị': 'I',
            'Ó': 'O', 'Ò': 'O', 'Ỏ': 'O', 'Õ': 'O', 'Ọ': 'O',
            'Ô': 'O', 'Ố': 'O', 'Ồ': 'O', 'Ổ': 'O', 'Ỗ': 'O', 'Ộ': 'O',
            'Ơ': 'O', 'Ớ': 'O', 'Ờ': 'O', 'Ở': 'O', 'Ỡ': 'O', 'Ợ': 'O',
            'Ú': 'U', 'Ù': 'U', 'Ủ': 'U', 'Ũ': 'U', 'Ụ': 'U',
            'Ư': 'U', 'Ứ': 'U', 'Ừ': 'U', 'Ử': 'U', 'Ữ': 'U', 'Ự': 'U',
            'Ý': 'Y', 'Ỳ': 'Y', 'Ỷ': 'Y', 'Ỹ': 'Y', 'Ỵ': 'Y',
            'Đ': 'D'
        }
        
        for viet_char, eng_char in vietnamese_map.items():
            text = text.replace(viet_char, eng_char)
        
        # Remove special characters and convert to snake_case
        text = re.sub(r'[^\w\s]', '', text)
        text = re.sub(r'\s+', '_', text.strip())
        text = re.sub(r'_+', '_', text)
        text = text.lower()
        
        return text
    
    def normalize_english_to_snake_case(self, text: str) -> str:
        """Convert English text to snake_case."""
        if not text:
            return ""
        
        # Remove numbering and special characters
        text = re.sub(r'^[\d\.\s]*', '', text.strip())
        
        # Handle parentheses content
        text = re.sub(r'\([^)]*\)', '', text)
        
        # Remove special characters and convert to snake_case
        text = re.sub(r'[^\w\s]', '', text)
        text = re.sub(r'\s+', '_', text.strip())
        text = re.sub(r'_+', '_', text)
        text = text.lower()
        
        return text
    
    def create_special_mappings(self) -> Dict[str, str]:
        """Create special mappings for common financial terms."""
        return {
            # Income Statement
            'thu_nhap_lai': 'interest_income',
            'chi_phi_lai': 'interest_expense',
            'thu_nhap_lai_thuan': 'net_interest_income',
            'thu_nhap_hoat_dong_dich_vu': 'fee_commission_income',
            'chi_phi_hoat_dong_dich_vu': 'fee_commission_expense',
            'lai_lo_thuan_hoat_dong_dich_vu': 'net_fee_commission_income',
            'lai_lo_thuan_kinh_doanh_ngoai_hoi': 'net_fx_trading_income',
            'lai_lo_thuan_mua_ban_chung_khoan_kinh_doanh': 'net_trading_securities_income',
            'lai_lo_thuan_mua_ban_chung_khoan_dau_tu': 'net_investment_securities_income',
            'thu_nhap_khac': 'other_income',
            'chi_phi_khac': 'other_expenses',
            'lai_lo_thuan_khac': 'net_other_income',
            'thu_nhap_gop_von': 'capital_contribution_income',
            'chi_phi_hoat_dong': 'operating_expenses',
            'loi_nhuan_thuan_hoat_dong_kinh_doanh': 'operating_profit',
            'chi_phi_du_phong_rui_ro_tin_dung': 'credit_loss_provision',
            'loi_nhuan_truoc_thue': 'profit_before_tax',
            'chi_phi_thue_tndn': 'corporate_income_tax',
            'chi_phi_thue_tndn_hien_hanh': 'current_income_tax_expense',
            'chi_phi_thue_tndn_hoan_lai': 'deferred_income_tax_expense',
            'loi_nhuan_sau_thue': 'net_profit_after_tax',
            'loi_ich_co_dong_thieu_so': 'minority_interest',
            'loi_nhuan_sau_thue_co_dong_ngan_hang_me': 'net_profit_attributable_parent',
            'lai_co_ban_tren_co_phieu': 'earnings_per_share',
            
            # Balance Sheet
            'tai_san_co_dinh': 'fixed_assets',
            'tai_san_co_dinh_hinh': 'tangible_fixed_assets',
            'tai_san_co_dinh_vo_hinh': 'intangible_fixed_assets',
            'tai_san_co_dinh_thue_tai_chinh': 'finance_leased_fixed_assets',
            'nguyen_gia_tscd': 'fixed_assets_cost',
            'hao_mon_tscd': 'accumulated_depreciation',
            'dau_tu_dai_han_khac': 'other_long_term_investments',
            'du_phong_giam_gia_dau_tu_dai_han': 'investment_provision',
            'bat_dong_san_dau_tu': 'investment_properties',
            'nguyen_gia_bdsdt': 'investment_properties_cost',
            'hao_mon_bdsdt': 'accumulated_depreciation_investment_properties',
            'tai_san_co_khac': 'other_assets',
            'cac_khoan_phai_thu': 'accounts_receivable',
            'tai_san_thue_tndn_hoan_lai': 'deferred_tax_assets',
            'loi_the_thuong_mai': 'goodwill',
            'du_phong_rui_ro_tai_san_co_khac': 'other_assets_provision',
            'tong_cong_tai_san': 'total_assets',
            
            # Liabilities
            'khoan_no_chinh_phu': 'government_borrowings',
            'vay_cac_tctd_khac': 'other_credit_institution_borrowings',
            'tien_gui_cac_tctd_khac': 'other_credit_institution_deposits',
            'thue_tndn_hoan_lai_phai_tra': 'deferred_tax_liabilities',
            'cac_khoan_no_khac': 'other_liabilities',
            'phat_hanh_giay_to_co_gia': 'valuable_papers_issued',
            'von_tai_trong_uy_thac_dau_tu': 'investment_trust_capital',
            'con_cu_tai_chinh_phai_sinh': 'derivatives',
            'tien_gui_khach_hang': 'customer_deposits',
            'cac_khoan_lai_phi_phai_thu': 'interest_receivable',
            'tong_no_phai_tra': 'total_liabilities',
            
            # Equity
            'von_cua_tctd': 'credit_institution_capital',
            'von_dieu_le': 'charter_capital',
            'von_cac_quy': 'reserves',
            'quy_cua_tctd': 'credit_institution_reserves',
            'von_dau_tu_xdcb': 'construction_investment_reserves',
            'von_khac': 'other_capital',
            'co_phieu_uu_dai': 'preferred_stock',
            'co_phieu_quy': 'treasury_shares',
            'thang_du_von_co_phieu': 'share_premium',
            'loi_nhuan_chua_phan_phoi': 'undistributed_earnings',
            'loi_ich_co_dong_khong_kiem_soat': 'non_controlling_interest',
            'tong_no_phai_tra_va_von_chu_so_huu': 'total_liabilities_equity',
            
            # Cash Flow
            'luu_chuyen_tien_thuan_hoat_dong_kinh_doanh': 'net_cash_from_operations',
            'luu_chuyen_tien_thuan_hoat_dong_dau_tu': 'net_cash_from_investing',
            'luu_chuyen_tien_thuan_hoat_dong_tai_chinh': 'net_cash_from_financing',
            'mua_samp_tai_san_co_dinh': 'purchase_fixed_assets',
            'tien_thu_thanh_ly_nhuong_ban_tscd': 'proceeds_from_sale_fixed_assets',
            'tien_chi_thanh_ly_nhuong_ban_tscd': 'cost_of_sale_fixed_assets',
            'mua_samp_bat_dong_san_dau_tu': 'purchase_investment_properties',
            'tien_thu_ban_thanh_ly_bat_dong_san_dau_tu': 'proceeds_from_sale_investment_properties',
            'tien_chi_ban_thanh_ly_bat_dong_san_dau_tu': 'cost_of_sale_investment_properties',
            'tang_von_co_phieu': 'equity_issuance_proceeds',
            'tang_giam_tien_gui_khach_hang': 'change_customer_deposits',
            'tang_giam_phathanh_giay_to_co_gia': 'change_valuable_papers_issued',
            'tang_giam_von_tai_trong': 'change_investment_trust_capital',
            'tang_giam_con_cu_tai_chinh': 'change_derivatives',
            'tang_giam_con_no_hoat_dong': 'change_other_operating_liabilities',
            
            # Ratios
            'roa': 'return_on_assets',
            'roe': 'return_on_equity',
            'nim': 'net_interest_margin',
            'casa_ratio': 'current_account_savings_ratio',
            'npl_ratio': 'non_performing_loan_ratio',
            'cost_to_income_ratio': 'cost_income_ratio',
            'loan_to_deposit_ratio': 'loan_deposit_ratio',
            'equity_to_assets_ratio': 'equity_assets_ratio',
        }
    
    def create_mappings(self):
        """Create field mappings for all fields."""
        special_mappings = self.create_special_mappings()
        
        for field in self.field_data:
            field_id = str(field['field_id'])
            item_vi = field['item_vi']
            item_en = field['item_en']
            
            # Try special mappings first
            normalized_vi = self.normalize_vietnamese_to_snake_case(item_vi)
            normalized_en = self.normalize_english_to_snake_case(item_en)
            
            # Check if normalized Vietnamese matches special mapping
            snake_case_name = None
            for key, value in special_mappings.items():
                if normalized_vi == key or normalized_en == key.replace('_', ''):
                    snake_case_name = value
                    break
            
            # If no special mapping found, use normalized Vietnamese
            if not snake_case_name:
                snake_case_name = normalized_vi if normalized_vi else normalized_en
            
            # Fallback to field_id if still empty
            if not snake_case_name:
                snake_case_name = f"field_{field_id}"
            
            self.field_mappings[field_id] = {
                'original_vi': item_vi,
                'original_en': item_en,
                'snake_case': snake_case_name,
                'normalized_vi': normalized_vi,
                'normalized_en': normalized_en
            }
    
    def get_mapping(self, field_id: str) -> Dict:
        """Get mapping for a field ID."""
        return self.field_mappings.get(str(field_id), {})
    
    def get_all_mappings(self) -> Dict:
        """Get all field mappings."""
        return self.field_mappings
    
    def save_mappings(self, output_file: str = 'field_snake_case_mappings.json'):
        """Save mappings to JSON file."""
        output_path = Path('data/kbs_financial_profiles/aggregated') / output_file
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(self.field_mappings, f, ensure_ascii=False, indent=2)
        print(f"Saved mappings to {output_path}")
    
    def generate_mapping_report(self) -> str:
        """Generate a report of field mappings."""
        report = []
        report.append("=" * 100)
        report.append("SNAKE_CASE FIELD MAPPING REPORT")
        report.append("=" * 100)
        
        report.append(f"\nTotal Fields Mapped: {len(self.field_mappings)}")
        
        # Group by first letter
        by_letter = {}
        for field_id, mapping in self.field_mappings.items():
            first_char = mapping['snake_case'][0].upper() if mapping['snake_case'] else 'OTHER'
            if first_char not in by_letter:
                by_letter[first_char] = []
            by_letter[first_char].append((field_id, mapping))
        
        report.append(f"\nField Distribution by First Letter:")
        for letter in sorted(by_letter.keys()):
            count = len(by_letter[letter])
            report.append(f"  {letter}: {count} fields")
        
        report.append(f"\nSample Mappings (First 50):")
        sorted_fields = sorted(self.field_mappings.items(), key=lambda x: x[1]['snake_case'])
        
        for i, (field_id, mapping) in enumerate(sorted_fields[:50]):
            report.append(
                f"{field_id:4} -> {mapping['snake_case']:40} "
                f"({mapping['original_vi'][:30]:30})"
            )
        
        report.append(f"\n" + "=" * 100)
        
        return "\n".join(report)


def main():
    """Main function to generate field mappings."""
    print("Creating snake_case field mappings...")
    
    normalizer = FieldNameNormalizer()
    
    # Generate and print report
    report = normalizer.generate_mapping_report()
    print(report)
    
    # Save mappings
    normalizer.save_mappings()
    
    # Create CSV for easy review
    mappings = normalizer.get_all_mappings()
    rows = []
    for field_id, mapping in mappings.items():
        rows.append({
            'field_id': field_id,
            'original_vi': mapping['original_vi'],
            'original_en': mapping['original_en'],
            'snake_case': mapping['snake_case'],
            'normalized_vi': mapping['normalized_vi'],
            'normalized_en': mapping['normalized_en']
        })
    
    df = pd.DataFrame(rows)
    df = df.sort_values('snake_case')
    
    output_path = Path('data/kbs_financial_profiles/aggregated') / 'field_snake_case_mappings.csv'
    df.to_csv(output_path, index=False, encoding='utf-8')
    print(f"Saved CSV mappings to {output_path}")
    
    # Check for potential conflicts
    snake_case_names = [m['snake_case'] for m in mappings.values()]
    duplicates = set([name for name in snake_case_names if snake_case_names.count(name) > 1])
    
    if duplicates:
        print(f"\n⚠️  WARNING: Found {len(duplicates)} duplicate snake_case names:")
        for dup in sorted(duplicates):
            print(f"  - {dup}")
    else:
        print(f"\n✅ No duplicate snake_case names found")
    
    print(f"\n✅ Field mapping creation completed successfully!")


if __name__ == '__main__':
    main()
