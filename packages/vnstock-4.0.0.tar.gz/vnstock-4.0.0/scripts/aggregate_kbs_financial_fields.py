"""
Script to aggregate and analyze profiled financial fields from KBS data.
Creates a comprehensive reference table of all possible fields across all companies,
exchanges, and company types.
"""

import json
import logging
from pathlib import Path
from datetime import datetime
from collections import defaultdict
from typing import Dict, List, Set, Tuple
import pandas as pd

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('aggregate_kbs_financial.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class FinancialFieldAggregator:
    """Aggregate and analyze profiled financial fields."""
    
    def __init__(self, input_dir: str = 'data/kbs_financial_profiles'):
        """
        Initialize the aggregator.
        
        Args:
            input_dir: Directory containing profiled data
        """
        self.input_dir = Path(input_dir)
        self.output_dir = self.input_dir / 'aggregated'
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Data structures
        self.all_fields = defaultdict(lambda: defaultdict(set))  # report_type -> period_type -> set of field_ids
        self.field_details = {}  # field_id -> field details
        self.symbol_fields = defaultdict(lambda: defaultdict(set))  # symbol -> report_type -> set of field_ids
        self.exchange_fields = defaultdict(lambda: defaultdict(set))  # exchange -> report_type -> set of field_ids
        
    def load_profiled_data(self) -> Dict[str, Dict]:
        """
        Load all profiled data from JSON files.
        
        Returns:
            Dictionary mapping symbol to profile data
        """
        logger.info(f"Loading profiled data from {self.input_dir}...")
        
        profiled_data = {}
        json_files = list(self.input_dir.glob('*.json'))
        
        # Filter out aggregated files
        json_files = [f for f in json_files if f.name != 'errors.json']
        
        logger.info(f"Found {len(json_files)} profile files")
        
        for json_file in json_files:
            try:
                with open(json_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    symbol = data.get('symbol')
                    if symbol:
                        profiled_data[symbol] = data
            except Exception as e:
                logger.warning(f"Error loading {json_file}: {e}")
        
        logger.info(f"Loaded {len(profiled_data)} symbols")
        return profiled_data
    
    def extract_field_information(self, profiled_data: Dict[str, Dict]):
        """
        Extract and aggregate field information from profiled data.
        
        Args:
            profiled_data: Dictionary of profiled data by symbol
        """
        logger.info("Extracting field information...")
        
        for symbol, symbol_data in profiled_data.items():
            exchange = symbol_data.get('exchange', 'UNKNOWN')
            reports = symbol_data.get('reports', {})
            
            for report_type, report_data in reports.items():
                for period_type, period_data in report_data.items():
                    fields = period_data.get('fields', [])
                    
                    for field in fields:
                        field_id = field.get('item_id')
                        
                        if not field_id:
                            continue
                        
                        # Store field details (use first occurrence)
                        if field_id not in self.field_details:
                            self.field_details[field_id] = {
                                'item': field.get('item'),
                                'item_en': field.get('item_en'),
                                'item_id': field_id,
                                'unit': field.get('unit'),
                                'levels': field.get('levels'),
                                'first_seen_symbol': symbol,
                                'first_seen_report': report_type,
                            }
                        
                        # Track field occurrences
                        self.all_fields[report_type][period_type].add(field_id)
                        self.symbol_fields[symbol][report_type].add(field_id)
                        self.exchange_fields[exchange][report_type].add(field_id)
    
    def create_field_reference_table(self) -> pd.DataFrame:
        """
        Create a comprehensive reference table of all fields.
        
        Returns:
            DataFrame with field reference information
        """
        logger.info("Creating field reference table...")
        
        rows = []
        
        for field_id, details in self.field_details.items():
            # Count occurrences across report types and periods
            occurrence_count = 0
            report_types_found = set()
            period_types_found = set()
            
            for report_type, period_dict in self.all_fields.items():
                for period_type, field_ids in period_dict.items():
                    if field_id in field_ids:
                        occurrence_count += 1
                        report_types_found.add(report_type)
                        period_types_found.add(period_type)
            
            row = {
                'field_id': field_id,
                'item_vi': details.get('item'),
                'item_en': details.get('item_en'),
                'unit': details.get('unit'),
                'levels': details.get('levels'),
                'occurrence_count': occurrence_count,
                'report_types': '|'.join(sorted(report_types_found)),
                'period_types': '|'.join(sorted(period_types_found)),
                'first_seen_symbol': details.get('first_seen_symbol'),
                'first_seen_report': details.get('first_seen_report'),
            }
            rows.append(row)
        
        df = pd.DataFrame(rows)
        df = df.sort_values('occurrence_count', ascending=False)
        
        logger.info(f"Created reference table with {len(df)} unique fields")
        return df
    
    def create_report_type_matrix(self) -> pd.DataFrame:
        """
        Create a matrix showing field coverage by report type and period.
        
        Returns:
            DataFrame with report type coverage matrix
        """
        logger.info("Creating report type matrix...")
        
        rows = []
        
        for report_type in sorted(self.all_fields.keys()):
            period_dict = self.all_fields[report_type]
            
            for period_type in sorted(period_dict.keys()):
                field_ids = period_dict[period_type]
                
                row = {
                    'report_type': report_type,
                    'period_type': period_type,
                    'unique_fields': len(field_ids),
                    'field_ids': '|'.join(sorted(str(f) for f in field_ids))
                }
                rows.append(row)
        
        df = pd.DataFrame(rows)
        logger.info(f"Created report type matrix with {len(df)} combinations")
        return df
    
    def create_exchange_coverage(self) -> pd.DataFrame:
        """
        Create coverage analysis by exchange.
        
        Returns:
            DataFrame with exchange coverage information
        """
        logger.info("Creating exchange coverage analysis...")
        
        rows = []
        
        for exchange in sorted(self.exchange_fields.keys()):
            report_dict = self.exchange_fields[exchange]
            
            for report_type in sorted(report_dict.keys()):
                field_ids = report_dict[report_type]
                
                row = {
                    'exchange': exchange,
                    'report_type': report_type,
                    'unique_fields': len(field_ids),
                    'field_ids': '|'.join(sorted(str(f) for f in field_ids))
                }
                rows.append(row)
        
        df = pd.DataFrame(rows)
        logger.info(f"Created exchange coverage with {len(df)} combinations")
        return df
    
    def create_field_frequency_analysis(self) -> pd.DataFrame:
        """
        Create frequency analysis of fields across symbols.
        
        Returns:
            DataFrame with field frequency information
        """
        logger.info("Creating field frequency analysis...")
        
        field_symbol_count = defaultdict(int)
        field_exchange_count = defaultdict(lambda: defaultdict(int))
        
        for symbol, report_dict in self.symbol_fields.items():
            # Get exchange for this symbol
            exchange = 'UNKNOWN'
            for ex_name, ex_fields in self.exchange_fields.items():
                for report_type, fields in ex_fields.items():
                    # This is a simplified approach - in real scenario, we'd track exchange properly
                    pass
            
            for report_type, field_ids in report_dict.items():
                for field_id in field_ids:
                    field_symbol_count[field_id] += 1
        
        rows = []
        for field_id, count in sorted(field_symbol_count.items(), key=lambda x: x[1], reverse=True):
            details = self.field_details.get(field_id, {})
            row = {
                'field_id': field_id,
                'item_vi': details.get('item'),
                'item_en': details.get('item_en'),
                'symbol_count': count,
                'frequency_pct': 0,  # Will be calculated after
            }
            rows.append(row)
        
        df = pd.DataFrame(rows)
        
        # Calculate frequency percentage
        total_symbols = len(self.symbol_fields)
        if total_symbols > 0:
            df['frequency_pct'] = (df['symbol_count'] / total_symbols * 100).round(2)
        
        logger.info(f"Created frequency analysis with {len(df)} fields")
        return df
    
    def save_results(self, 
                     reference_df: pd.DataFrame,
                     matrix_df: pd.DataFrame,
                     exchange_df: pd.DataFrame,
                     frequency_df: pd.DataFrame):
        """
        Save aggregated results to files.
        
        Args:
            reference_df: Field reference table
            matrix_df: Report type matrix
            exchange_df: Exchange coverage
            frequency_df: Field frequency analysis
        """
        logger.info(f"Saving results to {self.output_dir}...")
        
        # Save as Excel with multiple sheets
        excel_file = self.output_dir / 'kbs_financial_fields_reference.xlsx'
        with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
            reference_df.to_excel(writer, sheet_name='Field Reference', index=False)
            matrix_df.to_excel(writer, sheet_name='Report Type Matrix', index=False)
            exchange_df.to_excel(writer, sheet_name='Exchange Coverage', index=False)
            frequency_df.to_excel(writer, sheet_name='Field Frequency', index=False)
        
        logger.info(f"✓ Saved Excel report: {excel_file}")
        
        # Save as CSV files
        reference_df.to_csv(self.output_dir / 'field_reference.csv', index=False, encoding='utf-8')
        matrix_df.to_csv(self.output_dir / 'report_type_matrix.csv', index=False, encoding='utf-8')
        exchange_df.to_csv(self.output_dir / 'exchange_coverage.csv', index=False, encoding='utf-8')
        frequency_df.to_csv(self.output_dir / 'field_frequency.csv', index=False, encoding='utf-8')
        
        logger.info("✓ Saved CSV files")
        
        # Save as JSON
        json_file = self.output_dir / 'field_details.json'
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(self.field_details, f, ensure_ascii=False, indent=2)
        
        logger.info(f"✓ Saved JSON details: {json_file}")
    
    def print_summary(self, 
                      reference_df: pd.DataFrame,
                      matrix_df: pd.DataFrame,
                      exchange_df: pd.DataFrame,
                      frequency_df: pd.DataFrame):
        """
        Print summary statistics.
        
        Args:
            reference_df: Field reference table
            matrix_df: Report type matrix
            exchange_df: Exchange coverage
            frequency_df: Field frequency analysis
        """
        logger.info("=" * 80)
        logger.info("AGGREGATION SUMMARY")
        logger.info("=" * 80)
        
        logger.info(f"\nTotal unique fields: {len(reference_df)}")
        logger.info(f"Total symbols processed: {len(self.symbol_fields)}")
        logger.info(f"Total exchanges: {len(self.exchange_fields)}")
        
        logger.info("\n--- Report Type Coverage ---")
        for _, row in matrix_df.iterrows():
            logger.info(
                f"{row['report_type']:20} ({row['period_type']:10}): "
                f"{row['unique_fields']:4} fields"
            )
        
        logger.info("\n--- Exchange Coverage ---")
        for _, row in exchange_df.iterrows():
            logger.info(
                f"{row['exchange']:10} - {row['report_type']:20}: "
                f"{row['unique_fields']:4} fields"
            )
        
        logger.info("\n--- Top 10 Most Common Fields ---")
        top_10 = frequency_df.head(10)
        for idx, row in top_10.iterrows():
            logger.info(
                f"{row['field_id']:40} - "
                f"Found in {row['symbol_count']:4} symbols ({row['frequency_pct']:5.1f}%)"
            )
        
        logger.info("\n--- Field Distribution by Occurrence ---")
        occurrence_dist = reference_df['occurrence_count'].value_counts().sort_index()
        for count, freq in occurrence_dist.items():
            logger.info(f"Fields appearing {count:2} times: {freq:4} fields")
        
        logger.info("=" * 80)
    
    def run(self):
        """Run the aggregation process."""
        logger.info("=" * 80)
        logger.info("Starting KBS Financial Fields Aggregation")
        logger.info("=" * 80)
        
        # Load profiled data
        profiled_data = self.load_profiled_data()
        
        if not profiled_data:
            logger.error("No profiled data found!")
            return
        
        # Extract field information
        self.extract_field_information(profiled_data)
        
        # Create analysis tables
        reference_df = self.create_field_reference_table()
        matrix_df = self.create_report_type_matrix()
        exchange_df = self.create_exchange_coverage()
        frequency_df = self.create_field_frequency_analysis()
        
        # Save results
        self.save_results(reference_df, matrix_df, exchange_df, frequency_df)
        
        # Print summary
        self.print_summary(reference_df, matrix_df, exchange_df, frequency_df)
        
        logger.info(f"\nResults saved to: {self.output_dir}")
        logger.info("=" * 80)


if __name__ == '__main__':
    aggregator = FinancialFieldAggregator(input_dir='data/kbs_financial_profiles')
    aggregator.run()
