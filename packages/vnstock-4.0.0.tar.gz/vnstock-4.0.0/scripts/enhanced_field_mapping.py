"""
Enhanced field mapping with conflict resolution for duplicate snake_case names.
"""

import json
import pandas as pd
from pathlib import Path
from typing import Dict, List, Tuple

class EnhancedFieldMapper:
    """Enhanced field mapper with conflict resolution."""
    
    def __init__(self):
        self.load_existing_mappings()
        self.resolve_conflicts()
        self.create_final_mappings()
    
    def load_existing_mappings(self):
        """Load existing field mappings."""
        try:
            with open('data/kbs_financial_profiles/aggregated/field_snake_case_mappings.json', 'r', encoding='utf-8') as f:
                self.existing_mappings = json.load(f)
            print(f"Loaded {len(self.existing_mappings)} existing mappings")
        except Exception as e:
            print(f"Error loading existing mappings: {e}")
            self.existing_mappings = {}
    
    def resolve_conflicts(self):
        """Resolve duplicate snake_case names."""
        # Find duplicates
        snake_case_counts = {}
        for field_id, mapping in self.existing_mappings.items():
            snake_case = mapping['snake_case']
            if snake_case not in snake_case_counts:
                snake_case_counts[snake_case] = []
            snake_case_counts[snake_case].append((field_id, mapping))
        
        # Identify conflicts
        self.conflicts = {k: v for k, v in snake_case_counts.items() if len(v) > 1}
        self.conflict_resolutions = {}
        
        print(f"Found {len(self.conflicts)} snake_case conflicts to resolve")
        
        # Resolve conflicts
        for snake_case, field_list in self.conflicts.items():
            resolutions = {}
            
            for field_id, mapping in field_list:
                original_vi = mapping['original_vi']
                original_en = mapping['original_en']
                
                # Create unique name based on context
                if 'TSCĐ' in original_vi or 'fixed assets' in original_en.lower():
                    new_name = f"{snake_case}_fixed_assets"
                elif 'BĐSĐT' in original_vi or 'investment' in original_en.lower():
                    new_name = f"{snake_case}_investment"
                elif 'tài sản' in original_vi.lower() or 'asset' in original_en.lower():
                    new_name = f"{snake_case}_asset"
                elif 'tỷ giá' in original_vi.lower() or 'exchange' in original_en.lower():
                    new_name = f"{snake_case}_exchange"
                elif 'danh giá lại' in original_vi.lower() or 'revaluation' in original_en.lower():
                    new_name = f"{snake_case}_revaluation"
                elif 'quỹ' in original_vi.lower() or 'fund' in original_en.lower():
                    new_name = f"{snake_case}_fund"
                elif 'vốn' in original_vi.lower() or 'capital' in original_en.lower():
                    new_name = f"{snake_case}_capital"
                elif 'thuế' in original_vi.lower() or 'tax' in original_en.lower():
                    new_name = f"{snake_case}_tax"
                elif 'lợi nhuận' in original_vi.lower() or 'profit' in original_en.lower():
                    new_name = f"{snake_case}_profit"
                elif 'cổ đông' in original_vi.lower() or 'shareholder' in original_en.lower():
                    new_name = f"{snake_case}_shareholder"
                elif 'cổ phiếu' in original_vi.lower() or 'stock' in original_en.lower():
                    new_name = f"{snake_case}_stock"
                else:
                    # Use field_id as suffix
                    new_name = f"{snake_case}_{field_id}"
                
                resolutions[field_id] = new_name
            
            self.conflict_resolutions[snake_case] = resolutions
    
    def create_final_mappings(self):
        """Create final mappings with resolved conflicts."""
        self.final_mappings = {}
        
        for field_id, mapping in self.existing_mappings.items():
            snake_case = mapping['snake_case']
            
            # Check if this field has a conflict
            if snake_case in self.conflict_resolutions:
                final_snake_case = self.conflict_resolutions[snake_case][field_id]
            else:
                final_snake_case = snake_case
            
            self.final_mappings[field_id] = {
                'original_vi': mapping['original_vi'],
                'original_en': mapping['original_en'],
                'snake_case': final_snake_case,
                'original_normalized': mapping['snake_case'],
                'was_conflict': snake_case in self.conflict_resolutions
            }
    
    def save_final_mappings(self, output_file: str = 'field_snake_case_final.json'):
        """Save final mappings."""
        output_path = Path('data/kbs_financial_profiles/aggregated') / output_file
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(self.final_mappings, f, ensure_ascii=False, indent=2)
        print(f"Saved final mappings to {output_path}")
    
    def create_csv_output(self):
        """Create CSV output for easy review."""
        rows = []
        for field_id, mapping in self.final_mappings.items():
            rows.append({
                'field_id': field_id,
                'original_vi': mapping['original_vi'],
                'original_en': mapping['original_en'],
                'final_snake_case': mapping['snake_case'],
                'original_normalized': mapping['original_normalized'],
                'was_conflict': mapping['was_conflict']
            })
        
        df = pd.DataFrame(rows)
        df = df.sort_values('final_snake_case')
        
        output_path = Path('data/kbs_financial_profiles/aggregated') / 'field_snake_case_final.csv'
        df.to_csv(output_path, index=False, encoding='utf-8')
        print(f"Saved final CSV to {output_path}")
        
        return df
    
    def generate_report(self) -> str:
        """Generate conflict resolution report."""
        report = []
        report.append("=" * 100)
        report.append("ENHANCED FIELD MAPPING - CONFLICT RESOLUTION REPORT")
        report.append("=" * 100)
        
        report.append(f"\nTotal Fields: {len(self.final_mappings)}")
        report.append(f"Conflicts Resolved: {len(self.conflicts)}")
        
        report.append(f"\n--- Conflict Resolutions ---")
        for snake_case, resolutions in self.conflict_resolutions.items():
            report.append(f"\nOriginal: {snake_case}")
            for field_id, new_name in resolutions.items():
                original_vi = self.existing_mappings[field_id]['original_vi']
                report.append(f"  {field_id}: {new_name} ({original_vi[:40]:40})")
        
        report.append(f"\n--- Final Field Distribution ---")
        final_names = [m['snake_case'] for m in self.final_mappings.values()]
        unique_names = set(final_names)
        report.append(f"Unique snake_case names: {len(unique_names)}")
        
        # Check for remaining conflicts
        if len(final_names) != len(unique_names):
            remaining_duplicates = [name for name in final_names if final_names.count(name) > 1]
            report.append(f"\n⚠️  WARNING: Still have {len(remaining_duplicates)} conflicts:")
            for dup in set(remaining_duplicates):
                report.append(f"  - {dup}")
        else:
            report.append(f"\n✅ All conflicts resolved successfully!")
        
        report.append("\n" + "=" * 100)
        
        return "\n".join(report)


def main():
    """Main function."""
    print("Creating enhanced field mappings with conflict resolution...")
    
    mapper = EnhancedFieldMapper()
    
    # Generate report
    report = mapper.generate_report()
    print(report)
    
    # Save final mappings
    mapper.save_final_mappings()
    
    # Create CSV
    df = mapper.create_csv_output()
    
    print(f"\n✅ Enhanced field mapping completed successfully!")
    print(f"Final unique field names: {len(set(df['final_snake_case']))}")


if __name__ == '__main__':
    main()
