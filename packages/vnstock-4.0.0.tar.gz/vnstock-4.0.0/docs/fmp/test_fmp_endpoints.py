"""
Test script để kiểm thử tất cả FMP endpoints và phân tích cấu trúc dữ liệu.
"""

import os
import sys

# Add to path
sys.path.insert(0, '/Users/mrthinh/Github/vnstock_dev')

def test_all_endpoints():
    """Test tất cả endpoints và in ra cấu trúc dữ liệu"""
    
    # Import trực tiếp
    from vnstock.explorer.fmp.config import FMPConfig, make_fmp_request
    
    print("\n" + "="*80)
    print("FMP ENDPOINT TESTING")
    print("="*80)
    
    # Check API key
    api_key = os.getenv('FMP_TOKEN')
    if not api_key:
        print("❌ Không tìm thấy FMP_TOKEN")
        return
    
    print(f"✓ API Key: {api_key[:15]}...")
    
    config = FMPConfig(api_key=api_key, show_log=True)
    
    # Test cases
    test_cases = [
        # Listing endpoints
        ("search_symbol", {"query": "AAPL"}, "Search Symbol"),
        ("stock_list", {}, "Stock List"),
        ("etf_list", {}, "ETF List"),
        ("available_traded", {}, "Available Traded"),
        
        # Quote endpoints
        ("quote", {"symbol": "AAPL"}, "Quote Full"),
        ("quote_short", {"symbol": "AAPL"}, "Quote Short"),
        ("historical_chart_1day", {"symbol": "AAPL"}, "Historical 1D"),
        
        # Company endpoints
        ("profile", {"symbol": "AAPL"}, "Company Profile"),
        ("key_executives", {"symbol": "AAPL"}, "Key Executives"),
        ("stock_news", {"symbol": "AAPL"}, "Stock News"),
        
        # Financial endpoints
        ("income_statement", {"symbol": "AAPL"}, "Income Statement"),
        ("balance_sheet", {"symbol": "AAPL"}, "Balance Sheet"),
        ("ratios", {"symbol": "AAPL"}, "Financial Ratios"),
        
        # Rating endpoints
        ("rating", {"symbol": "AAPL"}, "Rating"),
        ("analyst_estimates", {"symbol": "AAPL"}, "Analyst Estimates"),
    ]
    
    results = []
    
    for endpoint_name, params, description in test_cases:
        print("\n" + "-"*80)
        print(f"Testing: {description} ({endpoint_name})")
        print("-"*80)
        
        try:
            # Build URL
            if "query" in params:
                url = config.get_endpoint_url(endpoint_name, query=params["query"])
            elif "symbol" in params:
                url = config.get_endpoint_url(endpoint_name, symbol=params["symbol"])
            else:
                url = config.get_endpoint_url(endpoint_name)
            
            # Add limit for some endpoints
            if endpoint_name in ['stock_news', 'income_statement', 'balance_sheet', 'ratios']:
                url += "&limit=2"
            
            print(f"URL: {url[:100]}...")
            
            # Make request
            df = make_fmp_request(url, timeout=30, show_log=False)
            
            if df is not None and not df.empty:
                print(f"✓ SUCCESS - Shape: {df.shape}")
                print(f"Columns: {list(df.columns)[:10]}")  # First 10 columns
                print(f"\nSample data:")
                print(df.head(2))
                
                results.append({
                    'endpoint': endpoint_name,
                    'description': description,
                    'status': 'SUCCESS',
                    'shape': df.shape,
                    'columns': list(df.columns)
                })
            else:
                print(f"❌ EMPTY RESPONSE")
                results.append({
                    'endpoint': endpoint_name,
                    'description': description,
                    'status': 'EMPTY',
                    'shape': None,
                    'columns': None
                })
                
        except Exception as e:
            print(f"❌ ERROR: {e}")
            results.append({
                'endpoint': endpoint_name,
                'description': description,
                'status': 'ERROR',
                'error': str(e)
            })
    
    # Summary
    print("\n" + "="*80)
    print("TEST SUMMARY")
    print("="*80)
    
    success_count = sum(1 for r in results if r['status'] == 'SUCCESS')
    total_count = len(results)
    
    print(f"\nTotal tests: {total_count}")
    print(f"Success: {success_count}")
    print(f"Failed: {total_count - success_count}")
    
    print("\n" + "-"*80)
    print("DETAILED RESULTS:")
    print("-"*80)
    
    for r in results:
        status_icon = "✓" if r['status'] == 'SUCCESS' else "❌"
        print(f"{status_icon} {r['description']:30} | {r['status']:10} | {r.get('shape', 'N/A')}")
    
    # Column analysis
    print("\n" + "="*80)
    print("COLUMN ANALYSIS")
    print("="*80)
    
    for r in results:
        if r['status'] == 'SUCCESS' and r['columns']:
            print(f"\n{r['description']}:")
            print(f"  Columns ({len(r['columns'])}): {', '.join(r['columns'][:15])}")
            if len(r['columns']) > 15:
                print(f"  ... and {len(r['columns']) - 15} more")

if __name__ == '__main__':
    test_all_endpoints()
