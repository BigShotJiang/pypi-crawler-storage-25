"""
Direct test script - bypass vnstock __init__.py
"""

import os
import sys
import requests
import pandas as pd

# Direct imports
sys.path.insert(0, '/Users/mrthinh/Github/vnstock_dev')

def test_fmp_api_direct():
    """Test FMP API trực tiếp"""
    
    api_key = os.getenv('FMP_TOKEN')
    if not api_key:
        print("❌ Không tìm thấy FMP_TOKEN")
        return
    
    print("="*80)
    print("FMP API DIRECT TESTING")
    print("="*80)
    print(f"API Key: {api_key[:15]}...")
    
    base_url = "https://financialmodelingprep.com/stable"
    
    # Test cases
    tests = [
        ("Search", f"/search-symbol?query=AAPL&limit=3&apikey={api_key}"),
        ("Quote", f"/quote?symbol=AAPL&apikey={api_key}"),
        ("Quote Short", f"/quote-short?symbol=AAPL&apikey={api_key}"),
        ("Profile", f"/profile?symbol=AAPL&apikey={api_key}"),
        ("Stock News", f"/stock-news?symbol=AAPL&limit=2&apikey={api_key}"),
        ("Income Statement", f"/income-statement?symbol=AAPL&period=annual&limit=2&apikey={api_key}"),
        ("Balance Sheet", f"/balance-sheet-statement?symbol=AAPL&period=annual&limit=2&apikey={api_key}"),
        ("Ratios", f"/ratios?symbol=AAPL&period=annual&limit=2&apikey={api_key}"),
        ("Rating", f"/rating?symbol=AAPL&apikey={api_key}"),
        ("Key Executives", f"/key-executives?symbol=AAPL&apikey={api_key}"),
        ("Historical 1D", f"/historical-chart/1day?symbol=AAPL&apikey={api_key}"),
        ("Stock List", f"/stock/list?apikey={api_key}"),
        ("ETF List", f"/etf/list?apikey={api_key}"),
    ]
    
    results = []
    
    for name, endpoint in tests:
        print("\n" + "-"*80)
        print(f"Testing: {name}")
        print("-"*80)
        
        url = f"{base_url}{endpoint}"
        print(f"URL: {url[:80]}...")
        
        try:
            response = requests.get(url, timeout=30)
            
            print(f"Status: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                
                if isinstance(data, list):
                    if len(data) > 0:
                        df = pd.DataFrame(data)
                        print(f"✓ SUCCESS - Shape: {df.shape}")
                        print(f"Columns: {list(df.columns)}")
                        print(f"\nFirst row:")
                        print(df.head(1).to_dict('records')[0] if not df.empty else "Empty")
                        
                        results.append({
                            'name': name,
                            'status': 'SUCCESS',
                            'shape': df.shape,
                            'columns': list(df.columns),
                            'dtypes': df.dtypes.to_dict()
                        })
                    else:
                        print("❌ Empty list")
                        results.append({'name': name, 'status': 'EMPTY_LIST'})
                        
                elif isinstance(data, dict):
                    if 'historical' in data:
                        # Historical data format
                        hist_df = pd.DataFrame(data['historical'])
                        print(f"✓ SUCCESS (Historical) - Shape: {hist_df.shape}")
                        print(f"Columns: {list(hist_df.columns)}")
                        print(f"Symbol: {data.get('symbol', 'N/A')}")
                        
                        results.append({
                            'name': name,
                            'status': 'SUCCESS',
                            'shape': hist_df.shape,
                            'columns': list(hist_df.columns),
                            'dtypes': hist_df.dtypes.to_dict()
                        })
                    else:
                        # Single object
                        df = pd.json_normalize(data)
                        print(f"✓ SUCCESS (Object) - Shape: {df.shape}")
                        print(f"Columns: {list(df.columns)[:10]}")
                        
                        results.append({
                            'name': name,
                            'status': 'SUCCESS',
                            'shape': df.shape,
                            'columns': list(df.columns)
                        })
                else:
                    print(f"❌ Unexpected type: {type(data)}")
                    results.append({'name': name, 'status': 'UNEXPECTED_TYPE'})
                    
            else:
                print(f"❌ HTTP {response.status_code}")
                print(f"Response: {response.text[:200]}")
                results.append({'name': name, 'status': f'HTTP_{response.status_code}'})
                
        except Exception as e:
            print(f"❌ ERROR: {e}")
            results.append({'name': name, 'status': 'ERROR', 'error': str(e)})
    
    # Summary
    print("\n" + "="*80)
    print("SUMMARY")
    print("="*80)
    
    success = [r for r in results if r['status'] == 'SUCCESS']
    print(f"\nTotal: {len(results)}")
    print(f"Success: {len(success)}")
    print(f"Failed: {len(results) - len(success)}")
    
    print("\n" + "-"*80)
    print("ALL RESULTS:")
    print("-"*80)
    for r in results:
        icon = "✓" if r['status'] == 'SUCCESS' else "❌"
        shape = r.get('shape', 'N/A')
        print(f"{icon} {r['name']:20} | {r['status']:15} | {shape}")
    
    # Data type analysis
    print("\n" + "="*80)
    print("DATA TYPE ANALYSIS")
    print("="*80)
    
    for r in success:
        print(f"\n{r['name']}:")
        print(f"  Shape: {r['shape']}")
        print(f"  Columns: {', '.join(r['columns'][:10])}")
        if len(r['columns']) > 10:
            print(f"  ... and {len(r['columns']) - 10} more")
        
        if 'dtypes' in r:
            print(f"  Data types:")
            for col, dtype in list(r['dtypes'].items())[:5]:
                print(f"    {col}: {dtype}")

if __name__ == '__main__':
    test_fmp_api_direct()
