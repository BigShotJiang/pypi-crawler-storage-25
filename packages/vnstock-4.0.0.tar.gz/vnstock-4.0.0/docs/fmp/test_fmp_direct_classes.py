"""
Direct class test - import modules trực tiếp
"""

import os
import sys
import importlib.util

# Load modules trực tiếp
def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

base = '/Users/mrthinh/Github/vnstock_dev/vnstock/explorer/fmp'

# Load dependencies first
const = load_module('fmp_const', f'{base}/const.py')
config = load_module('fmp_config', f'{base}/config.py')
listing = load_module('fmp_listing', f'{base}/listing.py')
quote = load_module('fmp_quote', f'{base}/quote.py')
company = load_module('fmp_company', f'{base}/company.py')
financial = load_module('fmp_financial', f'{base}/financial.py')

print("="*80)
print("FMP MODULE DIRECT TEST")
print("="*80)

api_key = os.getenv('FMP_TOKEN')
print(f"API Key: {api_key[:15]}...")

# Test Listing
print("\n" + "-"*80)
print("TEST LISTING")
print("-"*80)
try:
    lst = listing.Listing(api_key=api_key, show_log=False)
    result = lst.search('AAPL', limit=3)
    if result is not None and not result.empty:
        print(f"✓ Search OK - Shape: {result.shape}")
        print(result)
    else:
        print("❌ Search failed")
except Exception as e:
    print(f"❌ Error: {e}")

# Test Quote
print("\n" + "-"*80)
print("TEST QUOTE")
print("-"*80)
try:
    q = quote.Quote('AAPL', api_key=api_key, show_log=False)
    result = q.realtime()
    if result is not None and not result.empty:
        print(f"✓ Realtime OK - Shape: {result.shape}")
        print(result[['symbol', 'price', 'change', 'volume']])
    else:
        print("❌ Realtime failed")
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()

# Test Company
print("\n" + "-"*80)
print("TEST COMPANY")
print("-"*80)
try:
    c = company.Company('AAPL', api_key=api_key, show_log=False)
    
    print("\n1. Profile:")
    result = c.profile()
    if result is not None and not result.empty:
        print(f"✓ Profile OK - Shape: {result.shape}")
        print(f"Company: {result['companyName'].iloc[0]}")
        print(f"CEO: {result['ceo'].iloc[0]}")
    else:
        print("❌ Profile failed")
    
    print("\n2. Executives:")
    result = c.executives()
    if result is not None and not result.empty:
        print(f"✓ Executives OK - Shape: {result.shape}")
        print(result[['title', 'name']].head(3))
    else:
        print("❌ Executives failed")
        
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()

# Test Financial
print("\n" + "-"*80)
print("TEST FINANCIAL")
print("-"*80)
try:
    f = financial.Financial('AAPL', api_key=api_key, show_log=False)
    
    print("\n1. Income Statement:")
    result = f.income_statement(period='annual', limit=2)
    if result is not None and not result.empty:
        print(f"✓ Income Statement OK - Shape: {result.shape}")
        print(f"Date dtype: {result['date'].dtype}")
        print(result[['date', 'symbol', 'revenue', 'netIncome']])
    else:
        print("❌ Income Statement failed")
    
    print("\n2. Ratios:")
    result = f.ratios(period='annual', limit=2)
    if result is not None and not result.empty:
        print(f"✓ Ratios OK - Shape: {result.shape}")
        cols = ['symbol', 'date', 'priceToEarningsRatio']
        if all(c in result.columns for c in cols):
            print(result[cols])
    else:
        print("❌ Ratios failed")
        
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "="*80)
print("✓ TEST COMPLETED")
print("="*80)
