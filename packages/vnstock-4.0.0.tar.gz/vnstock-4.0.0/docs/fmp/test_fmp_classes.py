"""
Test script để kiểm tra các FMP classes hoạt động đúng.
"""

import os
import sys

sys.path.insert(0, '/Users/mrthinh/Github/vnstock_dev')

# Import trực tiếp
from vnstock.explorer.fmp.listing import Listing
from vnstock.explorer.fmp.quote import Quote
from vnstock.explorer.fmp.company import Company
from vnstock.explorer.fmp.financial import Financial


def test_listing():
    """Test Listing class"""
    print("\n" + "="*80)
    print("TEST LISTING CLASS")
    print("="*80)
    
    listing = Listing(show_log=False)
    
    print("\n1. Search AAPL:")
    result = listing.search('AAPL', limit=3)
    if result is not None and not result.empty:
        print(f"✓ Shape: {result.shape}")
        print(f"Columns: {list(result.columns)}")
        print(result)
    else:
        print("❌ Failed")


def test_quote():
    """Test Quote class"""
    print("\n" + "="*80)
    print("TEST QUOTE CLASS")
    print("="*80)
    
    quote = Quote('AAPL', show_log=False)
    
    print("\n1. Realtime quote:")
    result = quote.realtime()
    if result is not None and not result.empty:
        print(f"✓ Shape: {result.shape}")
        print(f"Columns: {list(result.columns)}")
        print(result[['symbol', 'price', 'change', 'volume']])
    else:
        print("❌ Failed")
    
    print("\n2. Full quote:")
    result = quote.full_quote()
    if result is not None and not result.empty:
        print(f"✓ Shape: {result.shape}")
        print(f"Price: ${result['price'].iloc[0]}")
        print(f"Market Cap: ${result['marketCap'].iloc[0]:,.0f}")
    else:
        print("❌ Failed")


def test_company():
    """Test Company class"""
    print("\n" + "="*80)
    print("TEST COMPANY CLASS")
    print("="*80)
    
    company = Company('AAPL', show_log=False)
    
    print("\n1. Company profile:")
    result = company.profile()
    if result is not None and not result.empty:
        print(f"✓ Shape: {result.shape}")
        print(f"Company: {result['companyName'].iloc[0]}")
        print(f"Sector: {result['sector'].iloc[0]}")
        print(f"CEO: {result['ceo'].iloc[0]}")
    else:
        print("❌ Failed")
    
    print("\n2. Key executives:")
    result = company.executives()
    if result is not None and not result.empty:
        print(f"✓ Shape: {result.shape}")
        print(f"Executives count: {len(result)}")
        print(result[['title', 'name']].head(3))
    else:
        print("❌ Failed")


def test_financial():
    """Test Financial class"""
    print("\n" + "="*80)
    print("TEST FINANCIAL CLASS")
    print("="*80)
    
    financial = Financial('AAPL', show_log=False)
    
    print("\n1. Income statement:")
    result = financial.income_statement(period='annual', limit=2)
    if result is not None and not result.empty:
        print(f"✓ Shape: {result.shape}")
        print(f"Columns: {len(result.columns)}")
        if 'date' in result.columns:
            print(f"Date type: {result['date'].dtype}")
        print(result[['date', 'symbol', 'revenue', 'netIncome']].head())
    else:
        print("❌ Failed")
    
    print("\n2. Balance sheet:")
    result = financial.balance_sheet(period='annual', limit=2)
    if result is not None and not result.empty:
        print(f"✓ Shape: {result.shape}")
        print(result[['date', 'symbol', 'totalAssets', 'totalLiabilities']].head())
    else:
        print("❌ Failed")
    
    print("\n3. Financial ratios:")
    result = financial.ratios(period='annual', limit=2)
    if result is not None and not result.empty:
        print(f"✓ Shape: {result.shape}")
        cols = ['symbol', 'date', 'priceToEarningsRatio', 'priceToBookRatio']
        print(result[cols].head())
    else:
        print("❌ Failed")


def main():
    """Main test"""
    api_key = os.getenv('FMP_TOKEN')
    if not api_key:
        print("❌ Không tìm thấy FMP_TOKEN")
        print("Chạy: export FMP_TOKEN=your_key")
        return
    
    print("="*80)
    print("FMP CLASSES TEST")
    print("="*80)
    print(f"API Key: {api_key[:15]}...")
    
    try:
        test_listing()
        test_quote()
        test_company()
        test_financial()
        
        print("\n" + "="*80)
        print("✓ ALL TESTS COMPLETED")
        print("="*80)
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    main()
