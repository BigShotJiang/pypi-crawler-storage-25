"""
Simple test script để test FMP API trực tiếp.
"""

import os
import sys
sys.path.insert(0, '/Users/mrthinh/Github/vnstock_dev')

# Import trực tiếp từ module
from vnstock.explorer.fmp.listing import Listing
from vnstock.explorer.fmp.quote import Quote

def main():
    print("\n" + "="*60)
    print("FMP API SIMPLE TEST")
    print("="*60)
    
    # Check API key
    api_key = os.getenv('FMP_TOKEN')
    print(f"\nAPI Key: {api_key[:10]}..." if api_key else "No API key found")
    
    # Test 1: Search
    print("\n1. TEST SEARCH")
    print("-" * 60)
    try:
        listing = Listing(show_log=True)
        result = listing.search('AAPL', limit=3)
        if result is not None and not result.empty:
            print("✓ Search thành công!")
            print(result)
        else:
            print("❌ Search trả về rỗng")
    except Exception as e:
        print(f"❌ Lỗi: {e}")
        import traceback
        traceback.print_exc()
    
    # Test 2: Quote
    print("\n2. TEST QUOTE")
    print("-" * 60)
    try:
        quote = Quote('AAPL', show_log=True)
        result = quote.short()  # Get short real-time quote
        if result is not None and not result.empty:
            print("✓ Quote thành công!")
            print(result)
        else:
            print("❌ Quote trả về rỗng")
    except Exception as e:
        print(f"❌ Lỗi: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main()
