"""
Script to fetch FMP API documentation and analyze current endpoints.
This will help us understand the new API structure and update our library accordingly.
"""

import requests
from bs4 import BeautifulSoup
import json
import re
from urllib.parse import urljoin, urlparse
import pandas as pd
from typing import Dict, List, Optional
import time
import os

class FMPDocumentationFetcher:
    """Fetch and parse FMP API documentation."""
    
    def __init__(self):
        self.base_url = "https://site.financialmodelingprep.com"
        self.docs_url = "https://site.financialmodelingprep.com/developer/docs"
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        })
        self.endpoints = {}
        self.sections = [
            'search', 'directory', 'company', 'quote', 
            'statements', 'chart', 'economics', 'calendar'
        ]
        
    def fetch_main_docs(self) -> str:
        """Fetch the main documentation page."""
        try:
            print("Fetching main documentation page...")
            response = self.session.get(self.docs_url, timeout=30)
            response.raise_for_status()
            return response.text
        except Exception as e:
            print(f"Error fetching main docs: {e}")
            return ""
    
    def parse_main_page(self, html_content: str) -> Dict:
        """Parse the main documentation page to find all sections and endpoints."""
        soup = BeautifulSoup(html_content, 'html.parser')
        endpoints_data = {}
        
        # Find all sections with endpoints
        for section in self.sections:
            print(f"\n=== Parsing section: {section} ===")
            section_data = self.parse_section(soup, section)
            if section_data:
                endpoints_data[section] = section_data
                
        return endpoints_data
    
    def parse_section(self, soup: BeautifulSoup, section: str) -> Dict:
        """Parse a specific section to extract endpoints."""
        section_data = {
            'endpoints': [],
            'description': '',
            'examples': []
        }
        
        # Find section by ID or heading
        section_element = soup.find(id=section)
        if not section_element:
            # Try to find by heading text
            headings = soup.find_all(['h1', 'h2', 'h3', 'h4'])
            for heading in headings:
                if section.lower() in heading.get_text().lower():
                    section_element = heading
                    break
        
        if not section_element:
            print(f"Section {section} not found")
            return section_data
            
        # Find all code blocks and API endpoints in this section
        current = section_element.find_next_sibling()
        while current and current.name not in ['h1', 'h2']:
            if current.name == 'pre' or 'code' in str(current.get('class', [])):
                code_text = current.get_text()
                # Look for API URLs
                api_urls = re.findall(r'https://financialmodelingprep\.com/api/[^\s\'"]+', code_text)
                for url in api_urls:
                    endpoint_info = self.parse_endpoint_url(url)
                    if endpoint_info:
                        section_data['endpoints'].append(endpoint_info)
            
            # Get description text
            if current.name in ['p', 'div'] and current.get_text().strip():
                if not section_data['description']:
                    section_data['description'] = current.get_text().strip()[:200]
                    
            current = current.find_next_sibling()
            
        return section_data
    
    def parse_endpoint_url(self, url: str) -> Optional[Dict]:
        """Parse an API endpoint URL to extract information."""
        try:
            parsed = urlparse(url)
            path_parts = parsed.path.split('/')
            
            if len(path_parts) < 3:
                return None
                
            endpoint_info = {
                'url': url,
                'version': path_parts[2] if path_parts[2].startswith('v') else 'v3',
                'category': path_parts[3] if len(path_parts) > 3 else '',
                'endpoint': '/'.join(path_parts[3:]) if len(path_parts) > 3 else '',
                'method': 'GET',  # FMP is mostly GET
                'parameters': self.parse_url_parameters(parsed.query)
            }
            
            return endpoint_info
            
        except Exception as e:
            print(f"Error parsing endpoint {url}: {e}")
            return None
    
    def parse_url_parameters(self, query_string: str) -> List[str]:
        """Extract parameter names from query string."""
        if not query_string:
            return []
            
        params = []
        for param in query_string.split('&'):
            if '=' in param:
                param_name = param.split('=')[0]
                if param_name != 'apikey':
                    params.append(param_name)
        return params
    
    def fetch_section_details(self, section: str) -> Dict:
        """Fetch detailed information for a specific section."""
        section_url = f"{self.docs_url}#{section}"
        try:
            print(f"Fetching details for section: {section}")
            response = self.session.get(section_url, timeout=30)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            return self.parse_section(soup, section)
            
        except Exception as e:
            print(f"Error fetching section {section}: {e}")
            return {}
    
    def test_endpoints(self, api_key: str = "demo") -> Dict:
        """Test discovered endpoints with demo API key."""
        test_results = {}
        
        for section, data in self.endpoints.items():
            print(f"\n=== Testing {section} endpoints ===")
            section_results = []
            
            for endpoint in data.get('endpoints', [])[:3]:  # Test first 3 endpoints
                url = endpoint['url']
                if 'apikey=' not in url:
                    url += f"{'&' if '?' in url else '?'}apikey={api_key}"
                
                try:
                    print(f"Testing: {url}")
                    response = self.session.get(url, timeout=10)
                    
                    result = {
                        'url': url,
                        'status_code': response.status_code,
                        'success': response.status_code == 200,
                        'error': None,
                        'sample_data': None
                    }
                    
                    if response.status_code == 200:
                        try:
                            data = response.json()
                            if isinstance(data, list) and len(data) > 0:
                                result['sample_data'] = data[0]
                                result['data_type'] = 'list'
                                result['length'] = len(data)
                            elif isinstance(data, dict):
                                result['sample_data'] = {k: v for i, (k, v) in enumerate(data.items()) if i < 5}
                                result['data_type'] = 'dict'
                                result['keys'] = list(data.keys())
                        except Exception as e:
                            result['error'] = f"JSON parse error: {e}"
                    else:
                        result['error'] = response.text[:200]
                        
                    section_results.append(result)
                    time.sleep(0.5)  # Rate limiting
                    
                except Exception as e:
                    section_results.append({
                        'url': url,
                        'status_code': None,
                        'success': False,
                        'error': str(e),
                        'sample_data': None
                    })
                    
            test_results[section] = section_results
            
        return test_results
    
    def save_results(self, endpoints_data: Dict, test_results: Dict = None):
        """Save the fetched documentation and test results."""
        # Save endpoints data
        with open('fmp_endpoints.json', 'w') as f:
            json.dump(endpoints_data, f, indent=2)
        print("\nEndpoints data saved to fmp_endpoints.json")
        
        # Save test results
        if test_results:
            with open('fmp_test_results.json', 'w') as f:
                json.dump(test_results, f, indent=2)
            print("Test results saved to fmp_test_results.json")
        
        # Create summary
        self.create_summary(endpoints_data, test_results)
    
    def create_summary(self, endpoints_data: Dict, test_results: Dict = None):
        """Create a human-readable summary."""
        summary = []
        summary.append("# FMP API Documentation Analysis")
        summary.append(f"Analysis Date: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        summary.append("")
        
        for section, data in endpoints_data.items():
            summary.append(f"## {section.upper()} Section")
            summary.append(f"Description: {data.get('description', 'N/A')}")
            summary.append(f"Endpoints found: {len(data.get('endpoints', []))}")
            summary.append("")
            
            for i, endpoint in enumerate(data.get('endpoints', [])[:5]):  # Show first 5
                summary.append(f"### Endpoint {i+1}")
                summary.append(f"- URL: {endpoint['url']}")
                summary.append(f"- Category: {endpoint['category']}")
                summary.append(f"- Parameters: {', '.join(endpoint['parameters'])}")
                summary.append("")
        
        # Add test results summary
        if test_results:
            summary.append("## Test Results Summary")
            for section, results in test_results.items():
                working_endpoints = sum(1 for r in results if r['success'])
                total_endpoints = len(results)
                summary.append(f"- {section}: {working_endpoints}/{total_endpoints} working")
            summary.append("")
        
        with open('fmp_analysis_summary.md', 'w') as f:
            f.write('\n'.join(summary))
        print("Summary saved to fmp_analysis_summary.md")
    
    def run_analysis(self, test_api: bool = False, api_key: str = "demo"):
        """Run complete documentation analysis."""
        print("Starting FMP API documentation analysis...")
        
        # Fetch main documentation
        html_content = self.fetch_main_docs()
        if not html_content:
            print("Failed to fetch documentation")
            return
        
        # Parse endpoints
        self.endpoints = self.parse_main_page(html_content)
        
        print(f"\nFound {sum(len(data.get('endpoints', [])) for data in self.endpoints.values())} total endpoints")
        
        # Test endpoints if requested
        test_results = None
        if test_api:
            print("\nTesting endpoints...")
            test_results = self.test_endpoints(api_key)
        
        # Save results
        self.save_results(self.endpoints, test_results)
        
        print("\nAnalysis complete!")
        return self.endpoints, test_results


def main():
    """Main function to run the documentation fetcher."""
    fetcher = FMPDocumentationFetcher()
    
    # Get API key from environment or use demo
    api_key = os.getenv('FMP_TOKEN', 'demo')
    print(f"Using API key: {'***' + api_key[-4:] if len(api_key) > 4 else 'demo'}")
    
    # Run analysis
    endpoints, test_results = fetcher.run_analysis(test_api=True, api_key=api_key)
    
    # Print quick summary
    print("\n" + "="*50)
    print("QUICK SUMMARY")
    print("="*50)
    
    for section, data in endpoints.items():
        endpoint_count = len(data.get('endpoints', []))
        print(f"{section.upper()}: {endpoint_count} endpoints")
    
    if test_results:
        print("\nTEST RESULTS:")
        for section, results in test_results.items():
            working = sum(1 for r in results if r['success'])
            total = len(results)
            print(f"{section}: {working}/{total} working")


if __name__ == "__main__":
    main()