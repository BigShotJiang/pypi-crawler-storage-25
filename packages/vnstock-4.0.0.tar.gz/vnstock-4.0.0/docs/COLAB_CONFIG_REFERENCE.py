"""
Vnstock Google Colab Setup Configuration
File này chứa các configuration options cho Colab Drive integration
"""

# ============================================================================
# GOOGLE COLAB CONFIGURATION
# ============================================================================

# Đường dẫn mặc định trên Google Drive
COLAB_DRIVE_MOUNT_PATH = "/content/drive"
COLAB_VNSTOCK_DIR = "/content/drive/MyDrive/.vnstock"

# Tự động mount Drive khi detect Colab?
AUTO_MOUNT_DRIVE = True

# Tự động thêm Drive path vào sys.path?
AUTO_ADD_TO_SYS_PATH = True

# Tự động tạo thư mục nếu chưa có?
AUTO_CREATE_DIRECTORIES = True

# Force mount lại Drive?
FORCE_REMOUNT = False

# Hiển thị hướng dẫn setup khi lần đầu?
SHOW_SETUP_INSTRUCTIONS = True

# ============================================================================
# LOCAL CONFIGURATION
# ============================================================================

# Thư mục local mặc định (khi không ở Colab)
LOCAL_VNSTOCK_DIR = "~/.vnstock"

# ============================================================================
# PACKAGE INSTALLATION
# ============================================================================

# Target directory cho pip install
# Nếu ở Colab: sử dụng Drive path
# Nếu local: sử dụng virtual env hoặc site-packages
INSTALL_TARGET = COLAB_VNSTOCK_DIR  # Auto-selected based on environment

# Packages cần cài đặt
REQUIRED_PACKAGES = [
    "vnstock",
]

OPTIONAL_PACKAGES = [
    "pandas",
    "pandas-datareader",
    "matplotlib",
    "plotly",
]

# ============================================================================
# FILE STRUCTURE
# ============================================================================

# Thư mục con bên trong .vnstock
SUBDIRECTORIES = {
    "id": "Machine ID & environment info",
    "config": "Configuration files",
    "cache": "Cached data",
    "logs": "Log files",
}

# ============================================================================
# LOGGING
# ============================================================================

# Log level cho Colab setup
LOG_LEVEL = "INFO"  # DEBUG, INFO, WARNING, ERROR

# Lưu log vào file?
SAVE_LOGS = True

LOG_FILE = f"{COLAB_VNSTOCK_DIR}/setup.log"

# ============================================================================
# TIMEOUT & RETRY
# ============================================================================

# Timeout cho mount Drive (seconds)
MOUNT_TIMEOUT = 30

# Số lần retry khi mount fail
MOUNT_RETRIES = 3

# Delay giữa các retry (seconds)
RETRY_DELAY = 2

# ============================================================================
# ADVANCED OPTIONS
# ============================================================================

# Kiểm tra kết nối Drive sau khi mount?
VERIFY_MOUNT = True

# Tự động cleanup old files?
AUTO_CLEANUP = False

# Cleanup older than (days)
CLEANUP_DAYS = 30

# Compression cho backup?
USE_COMPRESSION = False

# ============================================================================
# ENVIRONMENT DETECTION
# ============================================================================

# Các marker để detect Colab
COLAB_MARKERS = [
    'google.colab',
    'COLAB_GPU',
    'COLAB_RELEASE_TAG',
]

# Các marker để detect local environment
LOCAL_MARKERS = [
    'VIRTUAL_ENV',
    'CONDA_DEFAULT_ENV',
]

# ============================================================================
# USAGE EXAMPLES
# ============================================================================

"""
EXAMPLE 1: Auto Setup (Recommended)
========================================
from vnstock.core.utils.env import setup_colab_drive
setup_colab_drive()

import vnstock
stock = vnstock.Vnstock().stock('VNM', source='VCI')


EXAMPLE 2: Manual Setup
========================================
from google.colab import drive
import sys, os

drive.mount('/content/drive')
DRIVE_PATH = "/content/drive/MyDrive/.vnstock"
sys.path.insert(0, DRIVE_PATH)

!pip install --target={DRIVE_PATH} vnstock

import vnstock


EXAMPLE 3: Custom Configuration
========================================
from vnstock.core.utils.colab_drive import ColabDriveManager

manager = ColabDriveManager()
manager.mount_drive(force=True)  # Force remount
manager.initialize_drive_environment()

# Now use vnstock
import vnstock
"""

# ============================================================================
# MIGRATION GUIDE
# ============================================================================

"""
Từ Local Setup sang Colab Drive:

1. Backup cấu hình local:
   cp ~/.vnstock ~/vnstock_backup

2. Setup Colab Drive:
   from vnstock.core.utils.env import setup_colab_drive
   setup_colab_drive()

3. Migrate dữ liệu:
   cp ~/vnstock_backup/* /content/drive/MyDrive/.vnstock/

4. Sử dụng Colab:
   Các phiên sau sẽ tự động dùng Drive
"""

# ============================================================================
# TROUBLESHOOTING
# ============================================================================

"""
Problem 1: ModuleNotFoundError: No module named 'vnstock'
Solution:
  - Kiểm tra sys.path: print(sys.path)
  - Kiểm tra DRIVE_PATH tồn tại: os.path.exists(DRIVE_PATH)
  - Restart kernel nếu cần

Problem 2: Drive mount failed
Solution:
  - Kiểm tra kết nối internet
  - Dùng force_remount=True
  - Kiểm tra Drive access permissions

Problem 3: Disk quota exceeded
Solution:
  - Kiểm tra dung lượng Drive: df -h /content/drive
  - Xóa các files cũ không cần
  - Xóa cache: rm -rf ~/.vnstock/cache

Problem 4: Permission denied
Solution:
  - Kiểm tra Drive permissions
  - Reauthorize: drive.mount(..., force_remount=True)
  - Kiểm tra user account
"""
