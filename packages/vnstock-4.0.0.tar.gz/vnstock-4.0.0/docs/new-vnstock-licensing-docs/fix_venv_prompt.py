#!/usr/bin/env python3
"""Fix venv prompt to remove f-string prefix"""
import re

def fix_prompt():
    with open('vnstock-installer.py', 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Remove f-string prefix from lines that don't need interpolation
    replacements = [
        (r'f"\\n1\. Tạo/dùng \.venv', r'"\\n1. Tạo/dùng .venv'),
        (r'f"\\n2\. Chỉ định đường dẫn môi trường ảo riêng', r'"\\n2. Chỉ định đường dẫn môi trường ảo riêng'),
        (r'f"\\n3\. Dùng Python hệ thống', r'"\\n3. Dùng Python hệ thống'),
        (r'f"\\nChọn \(1-3, Enter = 1\):', r'"\\nChọn (1-3, Enter = 1):'),
        (r'f"\\n1\. Create/use \.venv', r'"\\n1. Create/use .venv'),
        (r'f"\\n2\. Specify custom virtual environment path', r'"\\n2. Specify custom virtual environment path'),
        (r'f"\\n3\. Use system Python', r'"\\n3. Use system Python'),
        (r'f"\\nSelect \(1-3, Enter = 1\):', r'"\\nSelect (1-3, Enter = 1):'),
    ]
    
    for pattern, replacement in replacements:
        content = re.sub(pattern, replacement, content)
    
    with open('vnstock-installer.py', 'w', encoding='utf-8') as f:
        f.write(content)
    
    print("✅ Fixed venv prompt f-strings")

if __name__ == '__main__':
    fix_prompt()
