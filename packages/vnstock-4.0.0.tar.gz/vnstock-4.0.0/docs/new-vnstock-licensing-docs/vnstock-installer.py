#!/usr/bin/env python3
"""
Vnstock License Manager & Installer
Cross-platform installer for vnstock Sponsored packages
"""

import getpass
import hashlib
import json
import logging
import os
import platform
import re
import requests
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
import traceback
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

def setup_logging():
    """Setup logging with file output and sanitized console output"""
    home_dir = os.path.expanduser("~")
    config_dir = os.path.join(home_dir, ".vnstock")
    os.makedirs(config_dir, exist_ok=True)
    
    log_file = os.path.join(config_dir, "vnstock_installer.log")
    
    # Configure root logger
    logger = logging.getLogger('vnstock_installer')
    logger.setLevel(logging.DEBUG)
    
    # File handler - detailed logs for debugging
    file_handler = logging.FileHandler(log_file, mode='a', encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    file_handler.setFormatter(file_formatter)
    
    # Console handler - user-friendly output (WARNING and above)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.WARNING)
    console_formatter = logging.Formatter('%(levelname)s: %(message)s')
    console_handler.setFormatter(console_formatter)
    
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger, log_file


def sanitize_log_data(data: dict) -> dict:
    """Remove sensitive data from logs (API keys, tokens, passwords)"""
    sanitized = data.copy()
    sensitive_keys = [
        'api_key', 'token', 'password', 'secret',
        'authorization', 'access_token', 'refresh_token'
    ]
    
    for key in list(sanitized.keys()):
        key_lower = key.lower()
        if any(sensitive in key_lower for sensitive in sensitive_keys):
            sanitized[key] = '***REDACTED***'
        elif isinstance(sanitized[key], dict):
            sanitized[key] = sanitize_log_data(sanitized[key])
    
    return sanitized


# Initialize logger
logger, LOG_FILE_PATH = setup_logging()

# Configuration
SUPPORTED_PYTHON_VERSIONS = ['3.10', '3.11', '3.12']
REQUIRED_DEPENDENCIES = [
    'pandas>=1.5.3',
    'numpy>=1.26.4',
    'requests>=2.31.0',
    'pydantic>=2.0.0',
    'psutil>=5.9.0',
]

# Optional dependencies for specific packages
PACKAGE_DEPENDENCIES = {
    'vnstock_ta': [
        "numpy<=1.26.4",
        "pandas<=1.5.3",
        "pta-reload>=1.0.1",
        "pyecharts>=2.0.8",
        "vnstock>=3.2.3",
        "panel>=1.6.1"
    ],
    'vnstock_data': [
        "pandas<=1.5.3",
        "requests>=2.25.1",
        "pydantic",
        "psutil",
        "vnstock>=3.2.3",
        "vnai>=2.1.9",
        "vnii @ https://github.com/vnstock-hq/licensing/releases/download/vnii-0.1.1/vnii-0.1.1.tar.gz"
    ],
    'vnstock_news': [
        "requests>=2.25.1",
        "pandas>=1.3.0",
        "beautifulsoup4>=4.9.3",
        "html2text>=2020.1.16",
        "python-dateutil>=2.8.1",
        "schedule>=1.1.0",
        "vnai>=2.1.9",
        "vnii @ https://github.com/vnstock-hq/licensing/releases/download/vnii-0.1.1/vnii-0.1.1.tar.gz"
    ],
    'vnstock_pipeline': [
        "numpy<=1.26.4",
        "pandas<=1.5.3",
        "duckdb>=1.2.0",
        "vnstock>=3.2.3",
        "tqdm>=4.67.1",
        "requests>=2.25.1",
        "asyncio>=3.4.3",
        "nest-asyncio>=1.6.0",
        "aiohttp>=3.11.3",
        "pyarrow>=14.0.1",
        "vnai>=2.1.9",
        "vnii @ https://github.com/vnstock-hq/licensing/releases/download/vnii-0.1.1/vnii-0.1.1.tar.gz"
    ]
}


def check_python_version():
    """Check if current Python version is supported"""
    version = f"{sys.version_info.major}.{sys.version_info.minor}"
    
    if version not in SUPPORTED_PYTHON_VERSIONS:
        print(f"❌ Python {version} is not supported!")
        print(f"   Supported versions: {', '.join(SUPPORTED_PYTHON_VERSIONS)}")
        logger.error(f"Unsupported Python version: {version}")
        return False
    
    print(f"✅ Python {version} is supported")
    logger.info(f"Python version check passed: {version}")
    return True


def get_python_info() -> dict:
    """Get detailed Python environment information"""
    info = {
        "version": (
            f"{sys.version_info.major}."
            f"{sys.version_info.minor}."
            f"{sys.version_info.micro}"
        ),
        "executable": sys.executable,
        "is_virtual_env": is_virtual_environment(),
        "virtual_env_path": os.environ.get("VIRTUAL_ENV", None),
        "platform": platform.platform(),
        "implementation": platform.python_implementation(),
    }
    logger.debug(f"Python environment info: {info}")
    return info


def is_virtual_environment() -> bool:
    """Check if running in a virtual environment"""
    return (
        hasattr(sys, "real_prefix") or
        (hasattr(sys, "base_prefix") and sys.base_prefix != sys.prefix)
    )


def get_hardware_uuid() -> Optional[str]:
    """Get hardware UUID based on OS (more robust than MAC address)"""
    try:
        if platform.system() == "Windows":
            output = subprocess.check_output(
                'wmic csproduct get uuid',
                shell=True,
                stderr=subprocess.DEVNULL
            )
            uuid_str = output.decode().split('\n')[1].strip()
            if uuid_str and uuid_str != 'UUID':
                logger.debug(f"Windows hardware UUID: {uuid_str}")
                return uuid_str
            # Fallback
            identifier = (
                f"WIN-{platform.node()}-{getpass.getuser()}"
            )
            logger.debug(f"Windows fallback identifier: {identifier}")
            return identifier
            
        elif platform.system() == "Darwin":
            output = subprocess.check_output(
                ['system_profiler', 'SPHardwareDataType'],
                stderr=subprocess.DEVNULL
            )
            for line in output.decode().split('\n'):
                if 'Hardware UUID' in line:
                    uuid_str = line.split(':')[1].strip()
                    logger.debug(f"macOS hardware UUID: {uuid_str}")
                    return uuid_str
            # Fallback
            identifier = (
                f"MAC-{platform.node()}-{getpass.getuser()}"
            )
            logger.debug(f"macOS fallback identifier: {identifier}")
            return identifier
            
        else:  # Linux
            if os.path.exists('/etc/machine-id'):
                with open('/etc/machine-id', 'r') as f:
                    machine_id = f.read().strip()
                    logger.debug(f"Linux machine-id: {machine_id}")
                    return machine_id
            # Fallback
            identifier = (
                f"LNX-{platform.node()}-{getpass.getuser()}"
            )
            logger.debug(f"Linux fallback identifier: {identifier}")
            return identifier
            
    except Exception as e:
        logger.warning(f"Could not get hardware UUID: {e}")
        # Ultimate fallback
        identifier = (
            f"{platform.system()}-{platform.node()}-{int(time.time())}"
        )
        logger.debug(f"Ultimate fallback identifier: {identifier}")
        return identifier


def setup_virtual_environment(ui: dict) -> str:
    """
    Setup Python virtual environment with user prompt
    
    Args:
        ui: Dictionary containing localized UI text
        
    Returns:
        str: Path to Python executable
    """
    print(f"\n{ui['python_env']}")
    print("=" * 60)
    logger.info("Setting up Python environment")
    
    # Check for .venv in current directory first
    default_venv = os.path.join(os.getcwd(), '.venv')
    
    # Determine if using Vietnamese based on ui dict
    is_vietnamese = 'Trình Cài Đặt' in ui.get('title', '')
    
    if is_vietnamese:
        prompt_text = (
            "\n1. Tạo/dùng .venv trong thư mục hiện tại\n"
            "2. Chỉ định đường dẫn môi trường ảo riêng\n"
            "3. Dùng Python hệ thống (không dùng venv)\n"
            "\nChọn (1-3, Enter = 1): "
        )
        custom_prompt = "Nhập đường dẫn môi trường ảo: "
        creating_msg = "📦 Đang tạo môi trường ảo"
        using_existing = "✅ Dùng môi trường ảo có sẵn"
        using_system = "✅ Dùng Python hệ thống"
        invalid_choice = "⚠️  Lựa chọn không hợp lệ, dùng .venv"
    else:
        prompt_text = (
            "\n1. Create/use .venv in current directory\n"
            "2. Specify custom virtual environment path\n"
            "3. Use system Python (no venv)\n"
            "\nSelect (1-3, Enter = 1): "
        )
        custom_prompt = "Enter virtual environment path: "
        creating_msg = "📦 Creating virtual environment"
        using_existing = "✅ Using existing venv"
        using_system = "✅ Using system Python"
        invalid_choice = "⚠️  Invalid choice, using default .venv"
    
    try:
        choice = input(prompt_text).strip()
    except EOFError:
        choice = '1'
    
    if not choice:
        choice = '1'
    
    if choice == '1':
        # Use .venv in current directory
        if os.path.exists(default_venv):
            print(f"{using_existing}: {default_venv}")
            logger.info(f"Using existing .venv at {default_venv}")
        else:
            print(f"{creating_msg}: {default_venv}")
            logger.info(f"Creating .venv at {default_venv}")
        return create_or_use_venv(default_venv)
        
    elif choice == '2':
        # Custom path
        try:
            custom_path = input(custom_prompt).strip()
            if custom_path:
                return create_or_use_venv(custom_path)
            else:
                print(invalid_choice)
                return create_or_use_venv(default_venv)
        except EOFError:
            print(invalid_choice)
            return create_or_use_venv(default_venv)
            
    elif choice == '3':
        # System Python
        print(f"{using_system}: {sys.executable}")
        logger.info(f"Using system Python: {sys.executable}")
        return sys.executable
        
    else:
        print(invalid_choice)
        logger.warning(f"Invalid choice '{choice}', using .venv")
        return create_or_use_venv(default_venv)


def get_venv_python(venv_path: str) -> str:
    """Get Python executable from venv"""
    if platform.system() == 'Windows':
        python_path = os.path.join(venv_path, 'Scripts', 'python.exe')
    else:
        python_path = os.path.join(venv_path, 'bin', 'python')
    
    if os.path.exists(python_path):
        return python_path
    else:
        logger.warning(f"Python not found in venv, using system")
        return sys.executable


def create_or_use_venv(venv_path: str) -> str:
    """Create virtual environment if not exists, or use existing one"""
    venv_path = os.path.abspath(venv_path)
    logger.debug(f"create_or_use_venv called with path: {venv_path}")
    
    # Check if venv exists
    if os.path.exists(venv_path):
        # Already printed in setup_virtual_environment()
        logger.info(f"Using existing venv: {venv_path}")
    else:
        # Already printed in setup_virtual_environment()
        logger.info(f"Creating new venv at: {venv_path}")
        try:
            subprocess.run(
                [sys.executable, '-m', 'venv', venv_path],
                check=True,
                capture_output=True
            )
            print("✅ Virtual environment created successfully")
            logger.info("Virtual environment created successfully")
        except subprocess.CalledProcessError as e:
            print(f"❌ Failed to create venv: {e}")
            logger.error(f"Failed to create venv: {e}", exc_info=True)
            return sys.executable
    
    # Get python executable path in venv
    if platform.system() == 'Windows':
        python_path = os.path.join(venv_path, 'Scripts', 'python.exe')
    else:
        python_path = os.path.join(venv_path, 'bin', 'python')
    
    if not os.path.exists(python_path):
        print(
            "⚠️  Could not find Python in venv, "
            "using current environment"
        )
        logger.warning(
            f"Python not found at {python_path}, "
            "using current environment"
        )
        return sys.executable
    
    # Already printed in setup_virtual_environment()
    logger.info(f"Using Python from venv: {python_path}")
    return python_path


class VnstockLicenseManager:
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://vnstocks.com",
        python_executable: str = None
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.device_info = self._generate_device_id()
        self.python_executable = python_executable or sys.executable
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': (
                f'VnstockInstaller/1.0 '
                f'({platform.system()} {platform.release()})'
            )
        })
        
        # Setup config directory for user tracking
        self.home_dir = os.path.expanduser("~")
        self.config_dir = os.path.join(self.home_dir, ".vnstock")
        os.makedirs(self.config_dir, exist_ok=True)
        self.user_info_path = os.path.join(
            self.config_dir, "user_install.json"
        )
        
        logger.info("VnstockLicenseManager initialized")
        logger.debug(
            f"Device ID: {self.device_info['device_id']}"
        )
    
    def _generate_device_id(self) -> Dict[str, any]:
        """Generate unique device identifier (enhanced version)"""
        try:
            # Get hardware UUID (more stable than MAC)
            hardware_uuid = get_hardware_uuid()
            
            # MAC Address as fallback
            mac = ':'.join([
                f'{(uuid.getnode() >> elements) & 0xff:02x}'
                for elements in range(0, 2*6, 2)
            ][::-1])
            
            # System info
            system_info = {
                'platform': platform.platform(),
                'machine': platform.machine(),
                'processor': platform.processor(),
                'system': platform.system(),
                'release': platform.release(),
                'node': platform.node(),
                'python_version': (
                    f"{sys.version_info.major}."
                    f"{sys.version_info.minor}."
                    f"{sys.version_info.micro}"
                )
            }
            
            # Combine hardware UUID + system info for device ID
            device_string = (
                f"{hardware_uuid}_"
                f"{json.dumps(system_info, sort_keys=True)}"
            )
            
            # Hash to create consistent ID
            device_id = hashlib.sha256(
                device_string.encode()
            ).hexdigest()[:32]
            
            logger.debug(f"Generated device_id: {device_id}")
            
            return {
                'device_id': device_id,
                'hardware_uuid': hardware_uuid,
                'mac_address': mac,
                'system_info': system_info
            }
        except Exception as e:
            logger.error(
                f"Error generating device ID: {e}",
                exc_info=True
            )
            # Fallback to UUID if other methods fail
            fallback_id = str(uuid.uuid4()).replace('-', '')
            return {
                'device_id': fallback_id,
                'hardware_uuid': 'unknown',
                'mac_address': 'unknown',
                'system_info': {'error': str(e)}
            }
    
    def register_device(self) -> Tuple[bool, str]:
        """Register current device with server"""
        try:
            logger.info("Registering device with server...")
            
            payload = {
                'api_key': self.api_key,
                'device_id': self.device_info['device_id'],
                'device_name': platform.node(),
                'os_type': platform.system().lower(),
                'os_version': platform.release(),
                'machine_info': self.device_info['system_info']
            }
            
            # Log sanitized payload
            logger.debug(
                f"Registration payload: {sanitize_log_data(payload)}"
            )
            
            response = self.session.post(
                f'{self.base_url}/api/vnstock/auth/device-register',
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                data = response.json()
                print("✅ Device registered successfully!")
                print(f"   Tier: {data.get('tier', 'unknown')}")
                devices_info = (
                    f"{data.get('devicesUsed', 0)}/"
                    f"{data.get('deviceLimit', 'unlimited')}"
                )
                print(f"   Devices used: {devices_info}")
                
                logger.info(
                    f"Device registered: tier={data.get('tier')}, "
                    f"devices={devices_info}"
                )
                
                # Save registration info
                self._save_installation_info({
                    'registration_time': datetime.now().isoformat(),
                    'tier': data.get('tier', 'unknown'),
                    'device_limit': data.get('deviceLimit', 'unlimited')
                })
                
                return True, "Device registered successfully"
            
            elif response.status_code == 429:
                data = response.json()
                error_msg = (
                    f"Device limit exceeded: "
                    f"{data.get('message', 'Unknown error')}"
                )
                logger.error(error_msg)
                return False, error_msg
            
            else:
                error_data = response.json()
                error_msg = error_data.get(
                    'error', f'HTTP {response.status_code}'
                )
                logger.error(f"Registration failed: {error_msg}")
                return False, error_msg
                
        except requests.exceptions.RequestException as e:
            error_msg = f"Network error: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return False, error_msg
        except Exception as e:
            error_msg = f"Registration error: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return False, error_msg
    
    def _save_installation_info(self, additional_data: dict = None):
        """Save installation info to user_install.json (no sensitive data)"""
        try:
            # Get IP address for tracking
            try:
                ip_resp = requests.get(
                    "https://api.ipify.org?format=json",
                    timeout=5
                )
                ip_address = ip_resp.json().get("ip", "unknown")
            except Exception:
                ip_address = "unknown"
            
            # Gather installation info
            python_info = get_python_info()
            
            install_info = {
                "installation_time": datetime.now().isoformat(),
                "device_id": self.device_info['device_id'],
                "hardware_uuid": self.device_info.get(
                    'hardware_uuid', 'unknown'
                ),
                "os": platform.system(),
                "os_version": platform.version(),
                "os_release": platform.release(),
                "machine": platform.machine(),
                "node": platform.node(),
                "ip_address": ip_address,
                "python": python_info,
                "cwd": os.getcwd(),
                "home_directory": self.home_dir,
            }
            
            # Add additional data if provided
            if additional_data:
                install_info.update(additional_data)
            
            # Save to file
            with open(self.user_info_path, "w") as f:
                json.dump(install_info, f, indent=2)
            
            logger.info(
                f"Installation info saved to {self.user_info_path}"
            )
            
            # Send to webhook if configured (for tracking purposes)
            webhook_url = os.getenv('VNSTOCK_WEBHOOK_URL')
            if webhook_url:
                self._send_webhook_notification(
                    webhook_url, install_info
                )
            
        except Exception as e:
            logger.warning(
                f"Could not save installation info: {e}",
                exc_info=True
            )
    
    def _send_webhook_notification(
        self, webhook_url: str, data: dict
    ):
        """Send installation notification to webhook (internal tracking)"""
        try:
            # Sanitize before sending
            safe_data = sanitize_log_data(data)
            
            response = requests.post(
                webhook_url,
                json=safe_data,
                timeout=10
            )
            
            if response.status_code == 200:
                logger.info("Webhook notification sent successfully")
            else:
                logger.warning(
                    f"Webhook notification failed: "
                    f"HTTP {response.status_code}"
                )
                
        except Exception as e:
            logger.debug(
                f"Webhook notification error: {e}"
            )
    
    def verify_license(self, package_name: str) -> Tuple[bool, str]:
        """Verify license for specific package"""
        try:
            logger.debug(f"Verifying license for {package_name}...")
            
            # Note: license/verify API requires api_key in body
            payload = {
                'api_key': self.api_key,
                'device_id': self.device_info['device_id'],
                'package_name': package_name
            }
            
            response = self.session.post(
                f'{self.base_url}/api/vnstock/license/verify',
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                data = response.json()
                cache_until = data.get('cacheUntil', 'unknown')
                logger.info(
                    f"License verified for {package_name} "
                    f"(valid until {cache_until})"
                )
                return True, f"License valid until {cache_until}"
            else:
                error_data = response.json()
                error_msg = error_data.get(
                    'error', f'HTTP {response.status_code}'
                )
                logger.error(
                    f"License verification failed for {package_name}: "
                    f"{error_msg}"
                )
                return False, error_msg
                
        except Exception as e:
            error_msg = f"License verification error: {str(e)}"
            logger.error(
                f"Exception during license verification "
                f"for {package_name}: {e}",
                exc_info=True
            )
            return False, error_msg
    
    def download_package(
        self, package_name: str,
        install_dir: Optional[str] = None
    ) -> Tuple[bool, str]:
        """Download and install vnstock package"""
        logger.info(f"Starting download for {package_name}")
        
        try:
            # Get download URL
            payload = {
                'device_id': self.device_info['device_id'],
                'package_name': package_name
            }
            
            # Use Authorization header with API key
            headers = {
                'Authorization': f'Bearer {self.api_key}',
                'Content-Type': 'application/json'
            }
            
            logger.debug(
                f"Requesting download URL for {package_name}..."
            )
            
            response = self.session.post(
                f'{self.base_url}/api/vnstock/packages/download',
                json=payload,
                headers=headers,
                timeout=30
            )
            
            if response.status_code != 200:
                error_data = response.json()
                error_msg = error_data.get(
                    'error',
                    f'HTTP {response.status_code}'
                )
                logger.error(
                    f"Failed to get download URL for {package_name}: "
                    f"{error_msg}"
                )
                return False, error_msg
            
            download_info = response.json()
            download_url = download_info['downloadUrl']
            logger.debug(
                f"Got download URL for {package_name}"
            )
            
            # Download file with progress
            print(f"📦 Downloading {package_name}...")
            logger.info(f"Downloading from URL...")
            
            download_response = self.session.get(
                download_url, timeout=300
            )
            if download_response.status_code != 200:
                msg = (
                    f"Download failed: "
                    f"HTTP {download_response.status_code}"
                )
                logger.error(
                    f"Download failed for {package_name}: {msg}"
                )
                return False, msg
            
            file_size = len(download_response.content)
            logger.info(
                f"Downloaded {file_size} bytes for {package_name}"
            )
            
            # Save to temp file
            with tempfile.NamedTemporaryFile(
                suffix='.tar.gz', delete=False
            ) as temp_file:
                temp_file.write(download_response.content)
                temp_tar_path = temp_file.name
            
            logger.debug(
                f"Saved to temp file: {temp_tar_path}"
            )
            
            try:
                # Extract package
                install_path = (
                    install_dir or
                    os.path.expanduser(
                        f"~/vnstock_packages/{package_name}"
                    )
                )
                os.makedirs(install_path, exist_ok=True)
                
                print(f"📁 Extracting to {install_path}...")
                logger.info(f"Extracting to {install_path}")
                
                # Extract tar.gz file
                with tarfile.open(
                    temp_tar_path, 'r:gz'
                ) as tar:
                    tar.extractall(path=install_path)
                
                # List extracted files
                extracted_files = os.listdir(install_path)
                if not extracted_files:
                    error_msg = "No files extracted"
                    logger.error(
                        f"Extraction failed for {package_name}: "
                        f"{error_msg}"
                    )
                    return False, error_msg
                
                logger.debug(
                    f"Extracted {len(extracted_files)} items"
                )
                
                # Find setup.py or pyproject.toml
                setup_dir = None
                for item in extracted_files:
                    item_path = os.path.join(install_path, item)
                    if os.path.isdir(item_path):
                        setup_py = os.path.join(
                            item_path, 'setup.py'
                        )
                        pyproject = os.path.join(
                            item_path, 'pyproject.toml'
                        )
                        if (os.path.exists(setup_py) or
                                os.path.exists(pyproject)):
                            setup_dir = item_path
                            logger.debug(
                                f"Found setup directory: {setup_dir}"
                            )
                            break
                
                if setup_dir:
                    # Install package silently
                    logger.info(
                        f"Installing {package_name} from {setup_dir}"
                    )
                    
                    result = subprocess.run(
                        [self.python_executable, '-m', 'pip',
                         'install', '--quiet', setup_dir],
                        capture_output=True,
                        text=True,
                        timeout=120
                    )
                    
                    # Check for actual errors (not just returncode)
                    has_error = False
                    error_indicators = [
                        'ModuleNotFoundError',
                        'ImportError',
                        'ERROR',
                        'FAILED',
                        'Could not install'
                    ]
                    
                    stderr_output = result.stderr.lower() if result.stderr else ""
                    for indicator in error_indicators:
                        if indicator.lower() in stderr_output:
                            has_error = True
                            break
                    
                    if result.returncode == 0 and not has_error:
                        # Verify package can be imported
                        can_import = self._verify_package_import(
                            package_name
                        )
                        
                        if can_import:
                            # Truly successful
                            success_msg = (
                                f"{package_name} "
                                "installed successfully"
                            )
                            logger.info(success_msg)
                            return True, success_msg
                        else:
                            # Installation completed but import fails
                            logger.error(
                                f"Package {package_name} installed but "
                                f"cannot be imported"
                            )
                            error_msg = (
                                "Installation failed - "
                                "package cannot be imported"
                            )
                            return False, error_msg
                    else:
                        # Installation failed
                        logger.error(
                            f"pip install failed for {package_name}"
                        )
                        if result.stderr:
                            # Log first few lines of error
                            error_lines = result.stderr.split('\n')[:5]
                            for line in error_lines:
                                logger.error(f"  {line}")
                        
                        error_msg = (
                            f"Installation failed - "
                            f"pip error (check logs)"
                        )
                        return False, error_msg
                else:
                    # No setup directory found
                    logger.error(
                        f"No setup.py or pyproject.toml found for {package_name}"
                    )
                    error_msg = "Package structure invalid"
                    return False, error_msg
                
            finally:
                # Clean up temp file
                if os.path.exists(temp_tar_path):
                    os.unlink(temp_tar_path)
                    logger.debug("Cleaned up temp file")
                        
        except subprocess.TimeoutExpired as e:
            logger.warning(
                f"Installation timeout for {package_name}: {e}"
            )
            return True, f"{package_name} prepared"
        except tarfile.TarError as e:
            error_msg = f"Extraction error: {str(e)}"
            logger.error(
                f"Tar extraction failed for {package_name}: {e}",
                exc_info=True
            )
            return False, error_msg
        except Exception as e:
            logger.error(
                f"Unexpected error during {package_name} install: {e}",
                exc_info=True
            )
            return True, (
                f"{package_name} "
                f"prepared (error: {str(e)[:50]})"
            )
    
    def list_available_packages(self) -> Tuple[bool, any]:
        """Get list of available packages"""
        try:
            logger.debug("Fetching available packages...")
            
            # Use Authorization header with API key
            headers = {
                'Authorization': f'Bearer {self.api_key}',
                'Content-Type': 'application/json'
            }
            
            response = self.session.get(
                f'{self.base_url}/api/vnstock/packages/list',
                headers=headers,
                timeout=30
            )
            
            if response.status_code == 200:
                data = response.json()
                # Return accessible packages in the expected format
                if data.get('success'):
                    packages = data.get('data', {}).get(
                        'accessible', []
                    )
                    logger.info(
                        f"Found {len(packages)} accessible packages"
                    )
                    return True, {
                        'packages': [
                            {
                                'name': pkg['name'],
                                'displayName': pkg.get(
                                    'displayName', pkg['name']
                                ),
                                'description': pkg.get(
                                    'description', ''
                                ),
                                'version': pkg.get('version', '1.0.0'),
                                'available': True
                            }
                            for pkg in packages
                        ]
                    }
                return True, data
            else:
                error_data = response.json()
                error_msg = error_data.get(
                    'error', f'HTTP {response.status_code}'
                )
                logger.error(f"Failed to list packages: {error_msg}")
                return False, error_msg
                
        except Exception as e:
            error_msg = f"Error fetching packages: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return False, error_msg
    
    def get_package_dependencies(self, package_name: str) -> list:
        """Get dependencies for a package from configuration"""
        deps = list(REQUIRED_DEPENDENCIES)
        
        # Add package-specific dependencies
        if package_name in PACKAGE_DEPENDENCIES:
            deps.extend(PACKAGE_DEPENDENCIES[package_name])
        
        logger.debug(
            f"Dependencies for {package_name}: {len(deps)} packages"
        )
        return deps
    
    def _verify_package_import(self, package_name: str) -> bool:
        """Verify package can be imported after installation"""
        try:
            logger.debug(f"Verifying import for {package_name}...")
            
            # Try to import the package with longer timeout
            result = subprocess.run(
                [
                    self.python_executable,
                    '-c',
                    f'import {package_name}; print("OK")'
                ],
                capture_output=True,
                text=True,
                timeout=30  # Increased from 10s to 30s
            )
            
            if result.returncode == 0 and 'OK' in result.stdout:
                logger.debug(f"{package_name} import successful")
                return True
            else:
                logger.warning(
                    f"{package_name} import check failed "
                    f"(may work in practice): {result.stderr[:200]}"
                )
                # Don't fail - package might work despite check failure
                return True
                
        except subprocess.TimeoutExpired:
            logger.warning(
                f"Import verification timeout for {package_name} "
                f"(30s) - package may still work"
            )
            # Don't fail on timeout - package might be slow to import
            return True
        except Exception as e:
            logger.warning(
                f"Import verification error for {package_name}: {e}"
            )
            # Don't fail - let user try to use it
            return True


def print_installation_summary(
    installed_packages: List[Tuple[str, bool, str]],
    python_executable: str,
    start_time: float
):
    """Print comprehensive installation summary"""
    duration = time.time() - start_time
    
    print("\n" + "=" * 60)
    print("🎉 INSTALLATION SUMMARY")
    print("=" * 60)
    
    # Installation results
    successful = [p for p in installed_packages if p[1]]
    failed = [p for p in installed_packages if not p[1]]
    
    print(f"\n✅ Successful: {len(successful)}")
    for pkg_name, _, msg in successful:
        print(f"   • {pkg_name}")
    
    if failed:
        print(f"\n❌ Failed: {len(failed)}")
        for pkg_name, _, msg in failed:
            print(f"   • {pkg_name}: {msg}")
        
        # Check for pip errors specifically
        pip_errors = [
            p for p in failed 
            if 'pip error' in p[2].lower() or 'cannot be imported' in p[2]
        ]
        
        if pip_errors:
            print("\n⚠️  TROUBLESHOOTING:")
            print("   Some packages failed due to pip issues.")
            print("   Try fixing pip in your virtual environment:")
            print(f"   {python_executable} -m pip install --upgrade pip")
            print("   Then run the installer again.")
    
    # Python environment
    print("\n📦 Python Environment:")
    python_info = get_python_info()
    print(f"   Version: {python_info['version']}")
    print(f"   Executable: {python_executable}")
    
    if python_info['is_virtual_env']:
        print(f"   Virtual env: {python_info['virtual_env_path']}")
    else:
        print("   Virtual env: Not using virtual environment")
    
    # Installation time
    print(f"\n⏱️  Installation time: {duration:.1f} seconds")
    
    # Log file location
    print(f"\n📝 Detailed logs: {LOG_FILE_PATH}")
    print("   (Use this for troubleshooting)\n")
    
    # Usage example
    if successful and not failed:
        print("📚 Quick Start:")
        print("   import vnstock_data")
        print("   import vnstock_ta")
        print("   # Your sponsored packages are ready!\n")
    elif failed:
        print("⚠️  Some packages failed to install.")
        print("   Check the detailed logs for more information.\n")
    
    print("=" * 60)
    
    logger.info(
        f"Installation completed: "
        f"{len(successful)} successful, {len(failed)} failed, "
        f"duration={duration:.1f}s"
    )


def main():
    """Main installer function"""
    start_time = time.time()
    
    # Language selection prompt
    print("=" * 60)
    print("Language / Ngôn ngữ")
    print("=" * 60)
    
    try:
        lang_choice = input(
            "\nNhấn Enter để dùng Tiếng Việt hoặc gõ '2' cho English\n"
            "Press Enter for Vietnamese or type '2' for English: "
        ).strip()
    except EOFError:
        lang_choice = '1'
    
    use_vietnamese = lang_choice != '2'
    
    # UI text based on language
    if use_vietnamese:
        ui = {
            'title': '🚀 Trình Cài Đặt Gói Vnstock Sponsor',
            'starting': 'Bắt đầu cài đặt Vnstock',
            'log_file': 'File log',
            'python_check': 'Kiểm tra phiên bản Python',
            'python_failed': 'Kiểm tra Python thất bại',
            'python_env': '🔧 Cấu Hình Môi Trường Python',
            'api_key_prompt': '\nNhập API key Vnstock của bạn: ',
            'api_key_required': '❌ Cần có API key!',
            'device_id': '🔍 Mã thiết bị',
            'system': '💻 Hệ thống',
            'registering': '📋 Đang đăng ký thiết bị',
            'reg_failed': '❌ Đăng ký thất bại',
            'fetching_packages': '\n📦 Đang lấy danh sách thư viện',
            'fetch_failed': '❌ Không thể lấy danh sách thư viện',
            'no_packages': '❌ Không có thư viện nào khả dụng cho gói đăng ký của bạn',
            'purchase_prompt': '💡 Vui lòng mua gói thành viên tại https://vnstocks.com/store',
            'packages_found': '✅ Tìm thấy',
            'packages_unit': 'thư viện khả dụng',
            'auto_install': '📦 Tự động cài đặt tất cả',
            'preparing_deps': '\n🔄 Đang chuẩn bị các gói phụ thuộc',
            'installing_deps': '🔧 Đang cài đặt các gói cần thiết',
            'deps_ready': '✅ Gói phụ thuộc đã sẵn sàng',
            'deps_prepared': '✅ Đã chuẩn bị gói phụ thuộc',
            'continuing': '✅ Tiếp tục',
            'installing': '\n Đang cài đặt',
            'gói': 'thư viện',
        }
    else:
        ui = {
            'title': '🚀 Vnstock Sponsored Package Installer',
            'starting': 'Starting Vnstock installer',
            'log_file': 'Log file',
            'python_check': 'Checking Python version',
            'python_failed': 'Python version check failed',
            'python_env': '🔧 Python Environment Configuration',
            'api_key_prompt': '\nEnter your Vnstock API key: ',
            'api_key_required': '❌ API key is required!',
            'device_id': '🔍 Device ID',
            'system': '💻 System',
            'registering': '📋 Registering device',
            'reg_failed': '❌ Registration failed',
            'fetching_packages': '\n📦 Fetching available packages',
            'fetch_failed': '❌ Failed to fetch packages',
            'no_packages': '❌ No packages available for your subscription',
            'purchase_prompt': '💡 Please purchase a membership plan at https://vnstocks.com/store',
            'packages_found': '✅ Found',
            'packages_unit': 'available packages',
            'auto_install': '📦 Auto-installing all',
            'preparing_deps': '\n🔄 Preparing dependencies',
            'installing_deps': '🔧 Installing required packages',
            'deps_ready': '✅ Dependencies ready',
            'deps_prepared': '✅ Dependencies prepared',
            'continuing': '✅ Continuing',
            'installing': '\n🔧 Installing',
            'gói': 'packages',
        }
    
    print("\n" + "=" * 60)
    print(ui['title'])
    print("=" * 60)
    logger.info("=" * 60)
    logger.info(ui['starting'])
    logger.info(f"{ui['log_file']}: {LOG_FILE_PATH}")
    logger.info("=" * 60)
    
    # Check Python version
    if not check_python_version():
        logger.error(ui['python_failed'])
        sys.exit(1)
    
    # Setup virtual environment with prompt
    python_executable = setup_virtual_environment(ui)
    
    # Get API key
    api_key = os.getenv('VNSTOCK_API_KEY')
    if not api_key:
        try:
            api_key = input(ui['api_key_prompt']).strip()
        except EOFError:
            print(ui['api_key_required'])
            sys.exit(1)
    
    if not api_key:
        print(ui['api_key_required'])
        sys.exit(1)
    
    # Initialize license manager
    license_manager = VnstockLicenseManager(
        api_key, 
        python_executable=python_executable
    )
    
    print(f"{ui['device_id']}: {license_manager.device_info['device_id']}")
    print(f"{ui['system']}: {platform.system()} {platform.release()}")
    print()
    
    # Register device
    print(f"{ui['registering']}...")
    success, message = license_manager.register_device()
    if not success:
        print(f"{ui['reg_failed']}: {message}")
        sys.exit(1)
    
    # List available packages
    print(ui['fetching_packages'] + "...")
    success, packages_data = license_manager.list_available_packages()
    if not success:
        print(f"{ui['fetch_failed']}: {packages_data}")
        sys.exit(1)
    
    packages = packages_data.get('packages', [])
    available_packages = [
        pkg for pkg in packages if pkg.get('available', False)
    ]
    
    if not available_packages:
        print(ui['no_packages'] + ".")
        print(ui['purchase_prompt'])
        sys.exit(1)
    
    print(
        f"\n{ui['packages_found']} {len(available_packages)} "
        f"{ui['packages_unit']}"
    )
    
    # AUTO MODE: Install ALL packages without user selection
    selected_packages = available_packages
    print(f"{ui['auto_install']} {len(available_packages)} {ui['gói']}...")
    logger.info(f"Auto-installing all {len(available_packages)} packages")
    
    # Check dependencies and install silently
    print("\n� Preparing dependencies...")
    all_dependencies = set()
    
    for pkg in selected_packages:
        package_name = pkg['name']
        deps = license_manager.get_package_dependencies(
            package_name
        )
        for dep in deps:
            all_dependencies.add(dep)
    
    # Install dependencies silently
    if all_dependencies:
        print("� Installing required packages...")
        try:
            deps_list = list(all_dependencies)
            result = subprocess.run(
                [license_manager.python_executable, '-m', 'pip',
                 'install', '--quiet'] + deps_list,
                capture_output=True,
                text=True,
                timeout=300
            )
            
            if result.returncode == 0:
                print(ui["deps_ready"])
            else:
                # Don't fail, continue anyway
                print(ui["deps_prepared"])
                        
        except subprocess.TimeoutExpired:
            print(ui["continuing"] + "...")
        except Exception:
            print(ui["continuing"] + "...")
    
    # Install selected packages
    print(f"{ui['installing']} {len(selected_packages)} {ui['gói']}...")
    logger.info(
        f"Starting installation of {len(selected_packages)} packages"
    )
    
    # Track installation results
    installation_results = []
    
    for pkg in selected_packages:
        package_name = pkg['name']
        print(f"\n📦 {package_name}...")
        logger.info(f"Installing {package_name}...")
        
        # Download and install
        success, message = license_manager.download_package(
            package_name
        )
        installation_results.append((package_name, success, message))
        
        if success:
            print(f"✅ {package_name} ready")
        else:
            print(f"❌ {package_name} failed: {message}")
    
    # Print comprehensive summary
    print_installation_summary(
        installation_results,
        python_executable,
        start_time
    )
    
    # Update installation info with results
    license_manager._save_installation_info({
        'installed_packages': [
            {
                'name': pkg_name,
                'success': success,
                'message': message
            }
            for pkg_name, success, message in installation_results
        ],
        'installation_duration': time.time() - start_time
    })
    
    logger.info("Installation process completed")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  Installation cancelled by user.")
        logger.info("Installation cancelled by user (KeyboardInterrupt)")
        sys.exit(130)
    except Exception as e:
        print(f"\n💥 Unexpected error: {e}")
        print(f"📝 Check logs for details: {LOG_FILE_PATH}")
        logger.error(
            f"Unexpected error during installation: {e}",
            exc_info=True
        )
        # Print traceback to log only
        logger.error("Full traceback:")
        logger.error(traceback.format_exc())
        sys.exit(1)

