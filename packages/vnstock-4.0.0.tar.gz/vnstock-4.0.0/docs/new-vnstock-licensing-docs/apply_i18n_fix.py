#!/usr/bin/env python3
"""
Script to apply i18n (internationalization) fixes to vnstock-installer.py
Adds Vietnamese as default language with English option
"""
import re

def apply_fixes():
    """Apply all i18n fixes to installer"""
    with open('vnstock-installer.py', 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Fix 1: Replace hardcoded strings in dependency installation section
    content = re.sub(
        r'print\("\\n🔄 Preparing dependencies\.\.\."\)',
        'print(ui["preparing_deps"] + "...")',
        content
    )
    
    content = re.sub(
        r'print\("🔧 Installing required packages\.\.\."\)',
        'print(ui["installing_deps"] + "...")',
        content
    )
    
    content = re.sub(
        r'print\("✅ Dependencies ready"\)',
        'print(ui["deps_ready"])',
        content
    )
    
    content = re.sub(
        r'print\("✅ Dependencies prepared"\)',
        'print(ui["deps_prepared"])',
        content
    )
    
    content = re.sub(
        r'print\("✅ Continuing\.\.\."\)',
        'print(ui["continuing"] + "...")',
        content
    )
    
    # Fix 2: Replace package installation messages
    content = re.sub(
        r'print\(f"📦 Auto-installing all \{len\(available_packages\)\} packages\.\.\."\)',
        'print(f"{ui[\'auto_install\']} {len(available_packages)} {ui[\'gói\']}...")',
        content
    )
    
    content = re.sub(
        r'print\(f"\\n🔧 Installing \{len\(selected_packages\)\} package\(s\)\.\.\."\)',
        'print(f"{ui[\'installing\']} {len(selected_packages)} {ui[\'gói\']}...")',
        content
    )
    
    # Write back
    with open('vnstock-installer.py', 'w', encoding='utf-8') as f:
        f.write(content)
    
    print("✅ Applied i18n fixes successfully")
    print("📝 Changes:")
    print("  - Dependency preparation messages")
    print("  - Package installation messages")
    print("  - All strings now use ui dictionary")

if __name__ == '__main__':
    apply_fixes()
