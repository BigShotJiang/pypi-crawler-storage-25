#!/usr/bin/env python3
"""
Quick Reference: Sử dụng vnstock với Provider Registry System

Sau khi fix provider registration, tất cả các adapter đều hoạt động đúng.
"""

# ============================================================
# 1. LISTING - Danh sách mã chứng khoán
# ============================================================

from vnstock import Listing

# VCI source
listing_vci = Listing(source='VCI')
all_symbols = listing_vci.all_symbols()
print(f"VCI: {len(all_symbols)} mã cổ phiếu")

by_industries = listing_vci.symbols_by_industries(lang='vi')
by_exchange = listing_vci.symbols_by_exchange(lang='en')

# MSN source (cần API key từ MSN)
# listing_msn = Listing(source='MSN')


# ============================================================
# 2. QUOTE - Giá chứng khoán  
# ============================================================

from vnstock import Quote

# VCI source
quote_vci = Quote(source='VCI', symbol='TCB')
price_history = quote_vci.history(start='2024-01-01', end='2024-12-31')
print(f"VCI Quote: {len(price_history)} ngày giao dịch")

# TCBS source
quote_tcbs = Quote(source='TCBS', symbol='TCB')
intraday = quote_tcbs.intraday()

# MSN source (cần symbol_id đặc biệt)
# quote_msn = Quote(source='MSN', symbol='TCB', symbol_id='xxx')

# FMP source (API connector)
# quote_fmp = Quote(source='FMP', symbol='AAPL')


# ============================================================
# 3. COMPANY - Thông tin công ty
# ============================================================

from vnstock import Company

# VCI source
company_vci = Company(source='VCI', symbol='TCB')
overview = company_vci.overview()
profile = company_vci.profile()
officers = company_vci.officers()
shareholders = company_vci.shareholders()

# TCBS source  
company_tcbs = Company(source='TCBS', symbol='TCB')
overview_tcbs = company_tcbs.overview()
dividends = company_tcbs.dividends()


# ============================================================
# 4. FINANCIAL - Báo cáo tài chính
# ============================================================

from vnstock.api.financial import Finance

# VCI source
finance_vci = Finance(source='VCI', symbol='TCB', period='quarter')
balance_sheet = finance_vci.balance_sheet()
income_statement = finance_vci.income_statement()
cash_flow = finance_vci.cash_flow()
ratio = finance_vci.ratio()

# TCBS source
finance_tcbs = Finance(source='TCBS', symbol='TCB', period='quarter')
ratio_tcbs = finance_tcbs.ratio()


# ============================================================
# 5. TRADING - Thông tin giao dịch
# ============================================================

from vnstock import Trading

# VCI source
trading_vci = Trading(source='VCI', symbol='TCB')
price_depth = trading_vci.price_depth()

# TCBS source
trading_tcbs = Trading(source='TCBS', symbol='TCB')
price_board = trading_tcbs.price_board(symbols=['TCB', 'VCB', 'HPG'])


# ============================================================
# 6. KIỂM TRA PROVIDERS AVAILABLE
# ============================================================

from vnstock.core.registry import ProviderRegistry

# Liệt kê tất cả providers
all_providers = ProviderRegistry.list_all()
print("\nAll registered providers:")
for module, sources in all_providers.items():
    print(f"  {module}: {', '.join(sources)}")

# Kiểm tra provider cụ thể
available_quote_sources = ProviderRegistry.list_available('quote')
print(f"\nQuote sources: {available_quote_sources}")

# Debug info
print("\n" + ProviderRegistry.debug_info())


# ============================================================
# 7. ERROR HANDLING
# ============================================================

try:
    # Source không tồn tại
    invalid = Listing(source='INVALID_SOURCE')
except ValueError as e:
    print(f"\nError: {e}")
    # Output: Provider 'listing/invalid_source' not found. Available: ['vci', 'msn']

try:
    # Source không hỗ trợ module
    invalid = Finance(source='MSN', symbol='TCB')  # MSN không có Financial
except ValueError as e:
    print(f"\nError: {e}")
    # Output: Provider 'financial/msn' not found. Available: ['vci', 'tcbs']


print("\n✅ All examples completed successfully!")
