"""
Helper utilities for vnstock_data Unified UI.
Provides tools to easily explore API structure and documentation.
"""

import inspect
import pandas as pd
from typing import Any, Optional, Set

# Backward compatibility / deprecated methods to exclude from tree
_DEPRECATED_METHODS = {
    # Market deprecated methods
    'pe', 'pb', 'evaluation',
    # Macro deprecated legacy API (will be removed 31/8/2026)
    'gdp', 'cpi', 'industry_prod', 'import_export', 'retail', 
    'fdi', 'money_supply', 'population_labor',  # Economy methods
    'exchange_rate', 'interest_rate',  # Currency methods
    # Reference deprecated methods
    'derivatives',  # Use futures() and warrant() directly instead
}

# Backward compatible aliases (relays to primary methods)
_BACKWARD_COMPAT_ALIASES = {
    # Market aliases
    'price_board',      # Alias for quote()
    'history',          # Alias for ohlcv()
    'intraday',         # Alias for trades()
    'price_depth',      # Alias for order_book()
    'trading_stats',    # Alias for session_stats()
    'put_through',      # Alias for block_trades()
    'matched_by_price', # Alias for volume_profile()
    # Reference aliases
    'by_group',         # Alias for list_by_group() (equity & index)
    'by_exchange',      # Alias for list_by_exchange() (equity)
    # Note: 'futures' is now a primary navigation method at Reference level, not an alias
}

# Top-level market endpoints (hidden at Market layer level, visible under equity/index)
_MARKET_TOPLEVEL_ENDPOINTS_HIDE = {
    'quote',  # Hide multi-symbol quote at Market level (already exposed per-symbol in equity()/index())
}

def _is_endpoint_method(method: Any) -> bool:
    """
    Check if a method is an endpoint (returns data/DataFrame, not a domain object).
    Endpoints are actual data-returning methods that dispatch to providers,
    not relay methods that call other layer methods.
    """
    try:
        # Get return type annotation if available
        annotations = getattr(method, '__annotations__', {})
        return_type = annotations.get('return')
        
        # Check if returns DataFrame or related types (endpoint)
        if return_type:
            type_str = str(return_type)
            if 'DataFrame' in type_str or 'Series' in type_str or 'dict' in type_str or 'list' in type_str:
                # Now verify it's NOT a relay method
                try:
                    source = inspect.getsource(method)
                    # Relay methods call other layer methods (Analytics, Macro, etc)
                    if 'Analytics()' in source or 'Macro()' in source or 'Reference()' in source:
                        return False  # It's a relay method, not an endpoint
                    # If it returns DataFrame and is NOT a relay method, it's an endpoint
                    # (whether it uses _dispatch or direct implementation like vnstock.common.indices)
                    return True
                except (OSError, TypeError):
                    # If we can't get source but have DataFrame annotation, assume endpoint
                    return True
        
        # If no annotation, check if it's a dispatch method (which returns DataFrame)
        # This covers both _dispatch() and _dispatch_and_format()
        try:
            source = inspect.getsource(method)
            if '_dispatch' in source:
                return True
        except (OSError, TypeError):
            pass
            
        return False
    except (OSError, TypeError):
        return False

def _should_include_method(name: str, method: Any, is_macro_layer: bool = False, parent_name: str = "") -> bool:
    """Determine if a method should be displayed in the API tree.
    
    Args:
        name: Method name
        method: Method object
        is_macro_layer: True if this is the Macro layer
        parent_name: Parent class/layer name (e.g., 'Market' at top level)
    """
    # Skip private methods
    if name.startswith('_'):
        return False
    
    # Skip non-callable attributes (unless it's a property being inspected for navigation)
    if not callable(method) and not isinstance(method, property):
        return False
    
    # Skip backward compatibility aliases (always)
    if name in _BACKWARD_COMPAT_ALIASES:
        return False
    
    # Skip deprecated methods at appropriate layers
    if name in _DEPRECATED_METHODS:
        # Deprecated Macro methods: hide at Macro layer (not sub-domains)
        # Deprecated Reference methods: hide in Reference layer
        if is_macro_layer or (name == 'derivatives' and parent_name == 'Reference'):
            return False
    
    # Skip top-level Market endpoints (e.g., 'quote' at Market level, but show at equity/index)
    if parent_name == 'Market' and name in _MARKET_TOPLEVEL_ENDPOINTS_HIDE:
        return False
    
    return True

def _get_public_methods(obj: Any, include_intermediate: bool = False, parent_name: str = "") -> list:
    """
    Helper to extract public callable methods from an object, excluding dunders and unwanted methods.
    
    Args:
        obj: Object to extract methods from
        include_intermediate: If True, include navigation methods (returns domain objects).
                            If False, only include endpoint methods (returns data).
        parent_name: Parent class name for context-aware filtering (e.g., 'Market')
    """
    methods = []
    
    # Determine the object type to apply context-aware filtering
    obj_type_name = type(obj).__name__
    is_macro_layer = obj_type_name == 'Macro'
    
    for name, method in inspect.getmembers(obj, predicate=inspect.ismethod):
        if not _should_include_method(name, method, is_macro_layer, parent_name):
            continue
            
        # For intermediate mode, check if it returns a domain object (navigation)
        if not include_intermediate:
            # Filter to endpoint methods only (return data)
            if not _is_endpoint_method(method):
                continue
        
        methods.append((name, method))
    
    return methods

def show_doc(obj: Any) -> None:
    """
    Prints the complete docstring and signature of a function or class.
    
    Args:
        obj: Function, method, class or its name as string (e.g., 'Market', 'Reference').
             When using strings, the object will be automatically resolved from vnstock_data UI.
    """
    # Resolve string to object if possible
    if isinstance(obj, str):
        try:
            from vnstock_data import ui
            clean_name = obj.replace('()', '').strip()
            parts = clean_name.split('.')
            if hasattr(ui, parts[0]):
                cls = getattr(ui, parts[0])
                current_obj = cls() if inspect.isclass(cls) else cls
                
                valid = True
                for part in parts[1:]:
                    if hasattr(current_obj, part):
                        attr = getattr(current_obj, part)
                        if inspect.ismethod(attr) or inspect.isfunction(attr):
                            # Try to instantiate the domain for the next nested object
                            sig = inspect.signature(attr)
                            kwargs = {}
                            for param in sig.parameters.values():
                                if param.default == inspect.Parameter.empty and param.name != 'self':
                                    if param.name == 'symbol':
                                        if 'crypto' in part: kwargs[param.name] = 'BTC'
                                        elif 'forex' in part: kwargs[param.name] = 'USDVND'
                                        elif 'commodity' in part: kwargs[param.name] = 'GC=F'
                                        elif 'index' in part: kwargs[param.name] = 'VNINDEX'
                                        else: kwargs[param.name] = 'VIC'
                                    elif param.name == 'index':
                                        kwargs[param.name] = 'VNINDEX'
                                    else:
                                        kwargs[param.name] = None
                            try:
                                current_obj = attr(**kwargs)
                            except Exception:
                                valid = False
                                break
                        else:
                            current_obj = attr
                    else:
                        valid = False
                        break
                
                if valid:
                    obj = current_obj
        except Exception:
            pass

    if isinstance(obj, str):
        print(f"Could not resolve documentation for: '{obj}'")
        print("Tip: Use the object directly (if imported) or its name as a string (e.g., show_doc('Market')).")
        return

    try:
        sig = inspect.signature(obj)
        print(f"Signature: \033[92m{obj.__name__}{sig}\033[0m\n")
    except (ValueError, TypeError, AttributeError):
        pass
    
    doc = inspect.getdoc(obj)
    if doc:
        print(doc)
    else:
        name = getattr(obj, '__name__', type(obj).__name__)
        print(f"No documentation available for {name}.")

def show_api(layer: Optional[Any] = None, show_navigation: bool = True) -> None:
    """
    Displays a visual API Tree of available endpoints.
    Only shows endpoint methods (returning data), hiding backward compatible aliases.
    
    Args:
        layer: (Optional) Limit display to a specific Layer (e.g., Market(), 'Market'). 
               If empty (None), displays all 6 library layers.
        show_navigation: If True, displays intermediate navigation methods (returning domain objects).
                        Default is True.
    """
    display_title = ""
    # Resolve string layer to instance
    if isinstance(layer, str):
        try:
            from vnstock_data import ui
            clean_name = layer.replace('()', '').strip()
            parts = clean_name.split('.')
            
            if hasattr(ui, parts[0]):
                cls = getattr(ui, parts[0])
                # Classes typically need instantiation for getmembers(ismethod) to work well
                if inspect.isclass(cls):
                    obj = cls()
                else:
                    obj = cls
                
                # Navigate down the dotted path
                valid = True
                for part in parts[1:]:
                    if hasattr(obj, part):
                        attr = getattr(obj, part)
                        
                        # If it's a method/function, call it to get the sub-domain
                        if inspect.ismethod(attr) or inspect.isfunction(attr):
                            sig = inspect.signature(attr)
                            kwargs = {}
                            for param in sig.parameters.values():
                                if param.default == inspect.Parameter.empty and param.name != 'self':
                                    # Use context-appropriate symbols
                                    if param.name == 'symbol':
                                        if 'crypto' in part: kwargs[param.name] = 'BTC'
                                        elif 'forex' in part: kwargs[param.name] = 'USDVND'
                                        elif 'commodity' in part: kwargs[param.name] = 'GC=F'
                                        elif 'index' in part: kwargs[param.name] = 'VNINDEX'
                                        else: kwargs[param.name] = 'VIC'
                                    elif param.name == 'index':
                                        kwargs[param.name] = 'VNINDEX'
                                    else:
                                        kwargs[param.name] = None
                            try:
                                obj = attr(**kwargs)
                            except Exception:
                                valid = False
                                break
                        else:
                            obj = attr
                    else:
                        valid = False
                        break
                
                if valid:
                    layer = obj
                    display_title = clean_name
        except Exception:
            pass
    
    def _is_navigation_method(method: Any) -> bool:
        """Check if method returns a domain object (navigation, not data)."""
        try:
            return_annotation = method.__annotations__.get('return')
            if return_annotation:
                # Handle string forward references
                if isinstance(return_annotation, str):
                    # Common names for domain objects in our library
                    domain_suffixes = ('Market', 'Reference', 'Insights', 'Fundamental', 'Macro', 'Analytics')
                    if any(suffix in return_annotation for suffix in domain_suffixes):
                        return True
                    return False
                
                type_str = str(return_annotation)
                # If returns a custom type (not DataFrame, dict, list, etc), it's navigation
                if 'DataFrame' not in type_str and 'Series' not in type_str and 'dict' not in type_str and 'list' not in type_str:
                    try:
                        if return_annotation.__module__ != 'builtins':
                            return True
                    except AttributeError:
                        # Fallback for types that don't have __module__ (like some Unions)
                        pass
            return False
        except (AttributeError, TypeError):
            return False
    
    def print_tree(
        node: Any, 
        prefix: str = "", 
        is_last: bool = True, 
        title: str = "",
        level: int = 0,
        show_nav: bool = False,
        parent_name: str = "",
        title_suffix: str = ""
    ) -> None:
        # Safeguard against traversing non-domain objects (like pandas DataFrames)
        if not hasattr(node, '__class__') or type(node).__module__.split('.')[0] not in ('vnstock_data', '__main__'):
            return
            
        connector = "└── " if is_last else "├── "
        display_name = title or (node.__name__ if hasattr(node, '__name__') else type(node).__name__)
        
        # Determine if this is the Macro layer
        is_macro = type(node).__name__ == 'Macro'
        
        # Set parent name for this node (used for context-aware filtering)
        node_parent_name = parent_name or type(node).__name__
        
        # Print current node
        print(f"{prefix}{connector}\033[96m{display_name}\033[0m{title_suffix}")
        
        # Get public methods, excluding deprecated/backward-compat
        if hasattr(node, '__class__') and not inspect.isroutine(node):
            # First get all endpoint methods
            endpoint_methods = _get_public_methods(node, include_intermediate=False, parent_name=node_parent_name)
            
            # Show endpoint methods
            for i, (name, method) in enumerate(endpoint_methods):
                is_last_item = (i == len(endpoint_methods) - 1) if not show_nav else False
                child_prefix = prefix + ("    " if is_last else "│   ")
                
                # Extract return annotation
                return_annotation = ""
                try:
                    ret = method.__annotations__.get('return')
                    if ret:
                        if hasattr(ret, '__name__'):
                            ret_str = ret.__name__
                        else:
                            ret_str = str(ret).replace('typing.', '').replace('pandas.core.frame.', '').replace('pandas.core.series.', '')
                            if 'Optional' in ret_str:
                                ret_str = ret_str.replace('Optional[', '').replace(']', '') + ' | None'
                        return_annotation = f" -> \033[90m{ret_str}\033[0m"
                except Exception:
                    pass
                    
                # Extract source from registry
                source_str = ""
                try:
                    if hasattr(node, '_domain_name') and hasattr(node, '_sources_config'):
                        from vnstock_data.ui.config import get_route
                        route = get_route(node._domain_name, name, node._sources_config)
                        source_str = f" \033[93m[{route[0].upper()}]\033[0m"
                except Exception:
                    pass

                # Extract short description from docstring
                doc_str = ""
                doc = inspect.getdoc(method)
                if doc:
                    first_line = doc.split('\n')[0].strip()
                    if len(first_line) > 100:
                        first_line = first_line[:97] + "..."
                    doc_str = f" \033[90m# {first_line}\033[0m"

                tree_char = '└── ' if is_last_item else '├── '
                print(f"{child_prefix}{tree_char}\033[92m{name}()\033[0m{source_str}{return_annotation}{doc_str}")
            
            # Optionally show navigation methods (and recurse)
            if show_nav:
                nav_items = []
                # Find navigation methods
                for name, method in inspect.getmembers(node, predicate=inspect.ismethod):
                    if not _should_include_method(name, method, is_macro_layer=is_macro, parent_name=node_parent_name):
                        continue
                    if _is_navigation_method(method):
                        nav_items.append((name, method, 'method'))
                
                # Find property-based navigation
                for name, attr in inspect.getmembers(type(node)):
                    if isinstance(attr, property):
                        # Use consistent filtering logic
                        if not _should_include_method(name, attr, is_macro_layer=is_macro, parent_name=node_parent_name):
                            continue
                        try:
                            val = getattr(node, name)
                            if val is not None and type(val).__module__.startswith('vnstock_data'):
                                nav_items.append((name, val, 'property'))
                        except Exception as e:
                            pass
                
                # Sort alphabetically
                nav_items.sort(key=lambda x: x[0])
                
                for i, (name, item, item_type) in enumerate(nav_items):
                    is_last_item = (i == len(nav_items) - 1)
                    child_prefix = prefix + ("    " if is_last else "│   ")
                    
                    # Extract short description for navigation
                    nav_doc_str = ""
                    if item_type == 'method':
                        doc = inspect.getdoc(item)
                    else:
                        prop = getattr(type(node), name)
                        doc = inspect.getdoc(prop)
                    
                    if doc:
                        first_line = doc.split('\n')[0].strip()
                        if len(first_line) > 100:
                            first_line = first_line[:97] + "..."
                        nav_doc_str = f" \033[90m# {first_line}\033[0m"

                    if item_type == 'property':
                        print_tree(item, child_prefix, is_last_item, name, level + 1, show_nav=True, parent_name="", title_suffix=nav_doc_str)
                    else:
                        try:
                            # Execute navigation method to get sub-domain
                            sig = inspect.signature(item)
                            kwargs = {}
                            for param in sig.parameters.values():
                                if param.default == inspect.Parameter.empty and param.name != 'self':
                                    # Mock required parameters
                                    if param.name == 'symbol':
                                        # Use context-appropriate symbols for navigation demo
                                        if 'crypto' in name: kwargs[param.name] = 'BTC'
                                        elif 'forex' in name: kwargs[param.name] = 'USDVND'
                                        elif 'commodity' in name: kwargs[param.name] = 'GC=F'
                                        elif 'index' in name: kwargs[param.name] = 'VNINDEX'
                                        else: kwargs[param.name] = 'VIC'
                                    elif param.name == 'index':
                                        kwargs[param.name] = 'VNINDEX'
                                    else:
                                        kwargs[param.name] = None
                            
                            sub_node = item(**kwargs)
                            print_tree(sub_node, child_prefix, is_last_item, name + "()", level + 1, show_nav=True, parent_name="", title_suffix=nav_doc_str)
                        except Exception as e:
                            # Fallback if execution fails - just print the navigation method
                            tree_char = '└── ' if is_last_item else '├── '
                            print(f"{child_prefix}{tree_char}\033[94m{name}()\033[0m{nav_doc_str}")
                        except Exception as e:
                            # Fallback if execution fails - just print the navigation method
                            tree_char = '└── ' if is_last_item else '├── '
                            print(f"{child_prefix}{tree_char}\033[94m{name}()  [Navigation]\033[0m")


    if layer is not None:
        title_str = f" - {display_title}" if display_title else ""
        print(f"\n\033[1mAPI STRUCTURE TREE{title_str}\033[0m")
        print_tree(layer, "", True, "", 0, show_nav=show_navigation)
    else:
        from vnstock_data.ui import Reference, Market, Insights, Fundamental, Macro, Analytics
        print("\n\033[1mAPI STRUCTURE TREE - VNSTOCK_DATA (Unified UI Endpoints)\033[0m")
        print("vnstock_data")
        layers = [
            ("Reference", Reference()),
            ("Market", Market()),
            ("Fundamental", Fundamental()),
            ("Analytics", Analytics()),
            ("Macro", Macro()),
            ("Insights", Insights())
        ]
        
        for i, (name, obj) in enumerate(layers):
            is_last = (i == len(layers) - 1)
            print_tree(obj, "", is_last, name, 0, show_nav=show_navigation)
            
    if show_navigation:
        print("\n\033[90mTip: Sử dụng show_doc(node) để đọc docstring.\033[0m")
        print("\033[90m[Navigation] = Intermediate methods returning domain objects\033[0m\n")
    else:
        print("\n\033[90mTip: Sử dụng show_doc(node) để đọc docstring.\033[0m")
        print("\033[90mHint: show_api() để hiển thị cây đầy đủ với navigation methods.\033[0m\n")
