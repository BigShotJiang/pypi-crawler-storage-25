"""
Market Data Schema Mappings.
Layer 2 output standardization across all instrument types.
"""

SCHEMA_MAP = {}
STANDARD_COLUMNS = {}

# The canonical structure of data fields for each endpoint
_STANDARD_COLS_DEF = {
    "ohlcv": [
        "time", "open", "high", "low", "close", "volume", "value", "ticker"
    ],
    "trades": [
        "time", "price", "volume", "side", "match_type", "id"
    ],
    "order_book": [
        "bid_price_1", "bid_vol_1", "bid_price_2", "bid_vol_2", "bid_price_3", "bid_vol_3",
        "bid_price_4", "bid_vol_4", "bid_price_5", "bid_vol_5", "bid_price_6", "bid_vol_6",
        "bid_price_7", "bid_vol_7", "bid_price_8", "bid_vol_8", "bid_price_9", "bid_vol_9",
        "bid_price_10", "bid_vol_10",
        "ask_price_1", "ask_vol_1", "ask_price_2", "ask_vol_2", "ask_price_3", "ask_vol_3",
        "ask_price_4", "ask_vol_4", "ask_price_5", "ask_vol_5", "ask_price_6", "ask_vol_6",
        "ask_price_7", "ask_vol_7", "ask_price_8", "ask_vol_8", "ask_price_9", "ask_vol_9",
        "ask_price_10", "ask_vol_10"
    ],
    "quote": [
        "symbol", "exchange", "reference_price", "ceiling_price", "floor_price",
        "open_price", "high_price", "low_price", "close_price",
        "match_price", "match_vol", "total_volume",
        "bid_price_1", "bid_vol_1", "bid_price_2", "bid_vol_2", "bid_price_3", "bid_vol_3",
        "ask_price_1", "ask_vol_1", "ask_price_2", "ask_vol_2", "ask_price_3", "ask_vol_3",
        "basis", "open_interest", "foreign_buy_volume", "foreign_sell_volume"
    ],
    "volume_profile": [
        "price", "buy_volume", "sell_volume", "unknown_volume", "total_volume", "match_percent"
    ],
    "block_trades": [
        "symbol", "time", "exchange", "match_price", "match_volume", "trading_date", "reference_price", "floor_price"
    ],
    "odd_lot": [
        "symbol", "exchange", "reference_price", "ceiling_price", "floor_price",
        "open_price", "high_price", "low_price", "close_price",
        "match_price", "match_vol", "total_volume",
        "bid_price_1", "bid_vol_1", "bid_price_2", "bid_vol_2", "bid_price_3", "bid_vol_3",
        "ask_price_1", "ask_vol_1", "ask_price_2", "ask_vol_2", "ask_price_3", "ask_vol_3",
        "basis", "open_interest", "foreign_buy_volume", "foreign_sell_volume"
    ],
    "summary": [
        "high_52w", "low_52w", "dividend", "beta", "eps", "bvps", "market_cap",
        "pe", "pb", "roe", "change_1m", "change_1y", "dividend_yield", "foreign_ownership_pct"
    ],
    "futures_summary": [
        "symbol", "exchange", "reference_price", "ceiling_price", "floor_price",
        "open_interest", "basis", "first_trading_date", "last_trading_date",
        "underlying_symbol", "foreign_buy_volume", "foreign_sell_volume"
    ],
    "warrant_summary": [
        "symbol", "exchange", "reference_price", "ceiling_price", "floor_price",
        "open_price", "high_price", "low_price", "close_price",
        "break_even_point", "intrinsic_value", "underlying_price"
    ],
    "index_summary": [
        "symbol", "time", "close_price", "price_change", "percent_change", "open_price",
        "high_price", "low_price", "reference_price", "advances", "declines", "no_change",
        "accumulated_volume", "accumulated_value", "total_volume", "put_through_volume",
        "put_through_value", "previous_close"
    ],
    "average_price": ["mins", "price", "close_time"],
    "price_ticker": ["symbol", "price"],
    "book_ticker": ["symbol", "bid_price_1", "bid_vol_1", "ask_price_1", "ask_vol_1"],
    "rolling_window_ticker": [
        "symbol", "price_change", "price_change_percent", "weighted_avg_price",
        "open_price", "high_price", "low_price", "last_price", "volume", 
        "quote_volume", "open_time", "close_time", "first_id", "last_id", "count"
    ],
    "reference_price": ["symbol", "reference_price", "timestamp"],
}

# The actual mapping from KBS explorer to UI Standard names
# Note: Many KBS explorer classes already output mostly clean names via internal maps,
# but we enforce standard naming compliance for the UI via this layer.
_KBS_MAPPINGS = {
    "ohlcv": {
        "time": "time", "open": "open", "high": "high", "low": "low", "close": "close",
        "volume": "volume", "value": "value", "ticker": "ticker", "symbol": "ticker"
    },
    "trades": {
        "time": "time", "price": "price", "volume": "volume", "side": "side",
        "match_type": "match_type", "id": "id"
    },
    "order_book": {
        # Assuming kbs explorer already outputs 'bid_price_1', etc.
        # Since vnstock standardizes order book internally.
        "bid_price_1": "bid_price_1", "bid_vol_1": "bid_vol_1",
        "ask_price_1": "ask_price_1", "ask_vol_1": "ask_vol_1",
        # We auto-map up to 10 levels dynamically in the registry builder below
    },
    "quote": {
        "symbol": "symbol", "exchange": "exchange", 
        "reference_price": "reference_price", "ceiling_price": "ceiling_price", "floor_price": "floor_price",
        "close_price": "close_price", "match_price": "match_price", "current_vol": "match_vol", "total_trades": "total_volume",
        "open_price": "open_price", "high_price": "high_price", "low_price": "low_price",
        "basis": "basis", "open_interest": "open_interest", 
        "foreign_buy_volume": "foreign_buy_volume", "foreign_sell_volume": "foreign_sell_volume"
    },
    "volume_profile": {
        "price": "price", "buyVol": "buy_volume", "sellVol": "sell_volume", 
        "unknownVol": "unknown_volume", "totalVol": "total_volume", "percent": "match_percent"
    },
    "block_trades": {
        "symbol": "symbol", "time": "time", "exchange": "exchange", "match_price": "match_price", 
        "match_volume": "match_volume", "trading_date": "trading_date", 
        "reference_price": "reference_price", "floor_price": "floor_price"
    },
    "odd_lot": {
        "symbol": "symbol", "exchange": "exchange", 
        "reference_price": "reference_price", "ceiling_price": "ceiling_price", "floor_price": "floor_price",
        "close_price": "close_price", "match_price": "match_price", "current_vol": "match_vol", "total_trades": "total_volume",
        "open_price": "open_price", "high_price": "high_price", "low_price": "low_price",
        "basis": "basis", "open_interest": "open_interest", 
        "foreign_buy_volume": "foreign_buy_volume", "foreign_sell_volume": "foreign_sell_volume"
    },
    "summary": {
        "MAP52": "high_52w", "MIP52": "low_52w", "DIV": "dividend",
        "BT": "beta", "EPS": "eps", "BVPS": "bvps", "MC": "market_cap",
        "PER": "pe", "PBR": "pb", "ROE": "roe", "CMCM": "change_1m",
        "CMCY": "change_1y", "YD": "dividend_yield", "FTO": "foreign_ownership_pct"
    },
    "futures_summary": {
        "symbol": "symbol", "exchange": "exchange",
        "reference_price": "reference_price", "ceiling_price": "ceiling_price", "floor_price": "floor_price",
        "open_interest": "open_interest", "basis": "basis",
        "first_trading_date": "first_trading_date", "last_trading_date": "last_trading_date",
        "underlying_symbol": "underlying_symbol",
        "foreign_buy_volume": "foreign_buy_volume", "foreign_sell_volume": "foreign_sell_volume"
    },
    "warrant_summary": {
        "symbol": "symbol", "SB": "symbol", "exchange": "exchange", "EX": "exchange",
        "reference_price": "reference_price", "RE": "reference_price",
        "ceiling_price": "ceiling_price", "CL": "ceiling_price",
        "floor_price": "floor_price", "FL": "floor_price",
        "open_price": "open_price", "OP": "open_price",
        "high_price": "high_price", "HI": "high_price",
        "low_price": "low_price", "LO": "low_price",
        "close_price": "close_price", "CP": "close_price",
        "break_even_point": "break_even_point", "intrinsic_value": "intrinsic_value",
        "CPR": "underlying_price"
    },
    "index_summary": {
        "symbol": "symbol", "timestamp": "time", "close_price": "close_price",
        "price_change": "price_change", "percent_change": "percent_change",
        "open_price": "open_price", "high_price": "high_price", "low_price": "low_price",
        "reference_price": "reference_price", "advances": "advances",
        "declines": "declines", "no_change": "no_change",
        "accumulated_volume": "accumulated_volume", "accumulated_value": "accumulated_value",
        "total_volume": "total_volume", "put_through_volume": "put_through_volume",
        "put_through_value": "put_through_value", "previous_close": "previous_close"
    }
}

# Auto-generate maps for levels 1 to 10 for order_book
for side in ["bid", "ask"]:
    for level in range(1, 11):
        p_col = f"{side}_price_{level}"
        v_col = f"{side}_vol_{level}"
        _KBS_MAPPINGS["order_book"][p_col] = p_col
        _KBS_MAPPINGS["order_book"][v_col] = v_col
        
        if level <= 3:
            _KBS_MAPPINGS["quote"][p_col] = p_col
            _KBS_MAPPINGS["quote"][v_col] = v_col
            _KBS_MAPPINGS["odd_lot"][p_col] = p_col
            _KBS_MAPPINGS["odd_lot"][v_col] = v_col

# Dynamically build domains across asset classes
_DOMAINS = [
    "market.equity", "market.index", "market.futures", "market.warrant", 
    "market.etf", "market.market_wide", "market.crypto", "market.forex", "market.commodity"
]

for domain in _DOMAINS:
    for method, cols in _STANDARD_COLS_DEF.items():
        key = f"{domain}.{method}"
        
        # Build Standard Columns list
        STANDARD_COLUMNS[key] = cols
        
        # Build Schema Map per provider
        SCHEMA_MAP[key] = {
            "kbs": _KBS_MAPPINGS.get(method, {}).copy(),
            "fxsb": _KBS_MAPPINGS.get(method, {}).copy() # FXSB outputs standardized OHLCV names
        }

# Inject Specialized Schema mappings beyond the generic universal types if needed
# e.g market.equity.foreign_flow
STANDARD_COLUMNS["market.index.summary"] = _STANDARD_COLS_DEF["index_summary"]
SCHEMA_MAP["market.index.summary"] = {
    "kbs": _KBS_MAPPINGS["index_summary"].copy()
}

STANDARD_COLUMNS["market.futures.summary"] = _STANDARD_COLS_DEF["futures_summary"]
SCHEMA_MAP["market.futures.summary"] = {
    "kbs": _KBS_MAPPINGS["futures_summary"].copy()
}

STANDARD_COLUMNS["market.warrant.summary"] = _STANDARD_COLS_DEF["warrant_summary"]
SCHEMA_MAP["market.warrant.summary"] = {
    "kbs": _KBS_MAPPINGS["warrant_summary"].copy()
}

STANDARD_COLUMNS["market.equity.foreign_flow"] = [
    "trading_date", "buy_vol", "buy_val", "sell_vol", "sell_val", "net_vol", "net_val"
]
SCHEMA_MAP["market.equity.foreign_flow"] = {
    "vci": {
         "trading_date": "trading_date", 
         "fr_buy_volume_total": "buy_vol", 
         "fr_buy_value_total": "buy_val",
         "fr_sell_volume_total": "sell_vol", 
         "fr_sell_value_total": "sell_val",
         "fr_net_volume_total": "net_vol", 
         "fr_net_value_total": "net_val"
    }
}

STANDARD_COLUMNS["market.equity.proprietary_flow"] = [
    "trading_date", "buy_vol", "buy_val", "sell_vol", "sell_val", "net_vol", "net_val"
]
SCHEMA_MAP["market.equity.proprietary_flow"] = {
    "vci": {
         "trading_date": "trading_date", 
         "total_buy_trade_volume": "buy_vol", 
         "total_buy_trade_value": "buy_val",
         "total_sell_trade_volume": "sell_vol", 
         "total_sell_trade_value": "sell_val",
         "total_trade_net_volume": "net_vol", 
         "total_trade_net_value": "net_val"
    }
}

ENUM_MAP = {
    "match_type": {
        "buy": "Buy",
        "sell": "Sell",
        "B": "Buy",
        "S": "Sell",
        "unknown": "Unknown",
        "U": "Unknown",
        "" : "Unknown"
    },
    "exchange": {
        "HSX": "HOSE",
        # "1": "HOSE",
        "HNX": "HNX",
        # "2": "HNX",
        "UPCOM": "UPCOM",
        # "3": "UPCOM"
    }
}

SUMMARY_GLOSSARY = {
    "vi": {
        "high_52w": "Cao 52 Tuần",
        "low_52w": "Thấp 52 Tuần",
        "dividend": "Cổ tức tiền mặt",
        "beta": "Hệ số Beta",
        "eps": "Lãi cơ bản trên cổ phiếu",
        "bvps": "Giá trị sổ sách",
        "market_cap": "Vốn hóa thị trường",
        "pe": "Chỉ số P/E",
        "pb": "Chỉ số P/B",
        "roe": "Tỷ suất lợi nhuận trên vốn CSH",
        "change_1m": "Thay đổi giá 1 tháng",
        "change_1y": "Thay đổi giá 1 năm",
        "dividend_yield": "Tỷ suất cổ tức",
        "foreign_ownership_pct": "% Nước ngoài sở hữu",
        "open_interest": "Vị thế mở (OI)",
        "basis": "Độ lệch (Basis)",
        "first_trading_date": "Ngày GD đầu tiên",
        "last_trading_date": "Ngày GD cuối cùng",
        "underlying_symbol": "Mã tài sản cơ sở",
        "break_even_point": "Điểm hòa vốn",
        "intrinsic_value": "Giá trị nội tại",
        "underlying_price": "Giá tài sản cơ sở"
    },
    "en": {
        "high_52w": "52-Week High",
        "low_52w": "52-Week Low",
        "dividend": "Cash Dividend",
        "beta": "Beta",
        "eps": "EPS",
        "bvps": "Book Value Per Share",
        "market_cap": "Market Cap",
        "pe": "P/E Ratio",
        "pb": "P/B Ratio",
        "roe": "Return on Equity",
        "change_1m": "1-Month Price Change",
        "change_1y": "1-Year Price Change",
        "dividend_yield": "Dividend Yield",
        "foreign_ownership_pct": "Foreign Ownership %",
        "open_interest": "Open Interest (OI)",
        "basis": "Basis",
        "first_trading_date": "First Trading Date",
        "last_trading_date": "Last Trading Date",
        "underlying_symbol": "Underlying Symbol",
        "break_even_point": "Break Even Point",
        "intrinsic_value": "Intrinsic Value",
        "underlying_price": "Underlying Price"
    }
}
