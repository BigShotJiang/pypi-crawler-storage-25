"""
Search Schemas.
"""

SCHEMA_MAP = {
    "search.symbol": {
        "fxsb": {
            "symbol": "symbol",
            "symbol_id": "symbol",
            "exchange": "category",
            "name": "description",
            "description": "description",
            "name_en": "description"
        }
    },
    "search.info": {
        "msn": {
            "symbol": "symbol",
            "symbol_id": "symbol_id",
            "exchange_name": "exchange",
            "short_name": "short_name",
            "friendly_name": "name",
            "eng_name": "name_en",
            "description": "description",
            "local_name": "name_local"
        },
        "dukascopy": {
            "symbol": "symbol",
            "code": "symbol_id",
            "name": "name",
            "description": "description",
            "type": "exchange",
            "country_code": "name_local"
        }
    }
}

STANDARD_COLUMNS = {
    "search.symbol": [
        "symbol", "name", "exchange", "short_name", "description", "name_en", "name_local", "symbol_id"
    ],
    "search.info": [
        "symbol", "name", "exchange", "short_name", "description", "name_en", "name_local", "symbol_id"
    ]
}
