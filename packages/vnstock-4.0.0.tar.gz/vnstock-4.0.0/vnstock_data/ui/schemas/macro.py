"""
Macro Schema Definitions.
Layer 6 - Enforcement of Macroeconomic and Commodity data.
"""

# Macro indicators and Commodity prices return Time-Series data naturally from SPL and MBK.
# We map the standard fields to ensure consistency.

SCHEMA_MAP = {
    "macro.economy": {
        "mbk": {} # Empty map -> passthrough, keep all columns but standardized via `standardize_columns`
    },
    "macro.currency": {
        "mbk": {}
    },
    "macro.commodity": {
        "spl": {}
    }
}

STANDARD_COLUMNS = {
    # `report_time` is strictly enforced across all Layer 6 outputs
    "macro.economy": ["report_time"],
    "macro.currency": ["report_time"],
    "macro.commodity": ["report_time", "open", "high", "low", "close", "volume", "buy", "sell", "ron95", "ron92", "oil_do"]
}

ENUM_MAP = {}
