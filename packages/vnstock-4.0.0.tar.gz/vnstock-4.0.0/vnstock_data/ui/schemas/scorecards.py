"""
Sector Scorecards for Fundamental Analysis (Institutional Grade).
Defines exhaustive subsets of critical financial indicators optimized for deep DuPont and Health Check analysis, mirroring TCBS's exact hierarchy.
"""

from .dictionary import FundamentalKeys as F

# TCBS-Style Section Headers for Financial Health Display
# Dynamically built from SCORECARDS to ensure only available fields are included
def get_financial_health_sections(scorecard_key: str):
    """
    Build financial health sections dynamically from SCORECARDS configuration.
    This ensures only fields that are actually available in the data are included.
    """
    if scorecard_key not in SCORECARDS:
        scorecard_key = "generic"
    
    scorecard = SCORECARDS[scorecard_key]
    
    sections = []
    
    # Income Statement section
    is_fields = scorecard.get("fundamental.equity.income_statement", [])
    if is_fields:
        # Filter out growth metrics for cleaner display
        is_fields_filtered = [f for f in is_fields if f not in [F.QOQ_GROWTH, F.YOY_GROWTH]]
        if is_fields_filtered:
            sections.append({
                "header": "I. KẾT QUẢ KINH DOANH",
                "fields": is_fields_filtered
            })
    
    # Balance Sheet section
    bs_fields = scorecard.get("fundamental.equity.balance_sheet", [])
    if bs_fields:
        sections.append({
            "header": "II. BẢNG CÂN ĐỐI KẾ TOÁN",
            "fields": bs_fields
        })
    
    # Cash Flow section
    cf_fields = scorecard.get("fundamental.equity.cash_flow", [])
    if cf_fields:
        sections.append({
            "header": "III. LƯU CHUYỂN TIỀN TỆ",
            "fields": cf_fields
        })
    
    # Ratios section
    ratio_fields = scorecard.get("fundamental.equity.ratio", [])
    if ratio_fields:
        sections.append({
            "header": "IV. TỶ SỐ TÀI CHÍNH",
            "fields": ratio_fields
        })
    
    return sections

SCORECARDS = {
    "generic": {
        "fundamental.equity.income_statement": [
            F.NET_REVENUE,
            F.QOQ_GROWTH,
            F.YOY_GROWTH,
            F.COST_OF_GOODS_SOLD,
            F.GROSS_PROFIT,
            F.OPERATING_EXPENSES,
            F.OPERATING_PROFIT,
            F.INTEREST_EXPENSES,
            F.PROFIT_BEFORE_TAX,
            F.NET_PROFIT_AFTER_TAX,
            F.PROFIT_AFTER_TAX_FOR_SHAREHOLDERS_OF_PARENT_COMPANY,
        ],
        "fundamental.equity.balance_sheet": [
            F.A_SHORT_TERM_ASSETS,
            F.CASH_AND_CASH_EQUIVALENTS,
            F.SHORT_TERM_FINANCIAL_INVESTMENTS,
            F.SHORT_TERM_TRADE_ACCOUNTS_RECEIVABLE,
            F.INVENTORIES,
            F.LONG_TERM_ASSETS,
            F.FIXED_ASSETS,
            F.TOTAL_ASSETS,
            F.LIABILITIES,
            F.SHORT_TERM_BORROWINGS_AND_FINANCIAL_LEASES,
            F.LONG_TERM_BORROWINGS_AND_FINANCIAL_LEASES,
            F.OWNERS_EQUITY,
            F.OWNERS_CAPITAL,
        ],
        "fundamental.equity.cash_flow": [
            F.NET_CASH_FLOWS_FROM_OPERATING_ACTIVITIES,
            F.NET_CASH_FLOWS_FROM_INVESTING_ACTIVITIES,
            F.NET_CASH_FLOWS_FROM_FINANCING_ACTIVITIES,
            "capex",
        ],
        "fundamental.equity.ratio": [
            F.P_E, F.P_B, F.P_S, F.TRAILING_EPS, F.BOOK_VALUE_PER_SHARE, F.DIVIDEND_YIELD,
            F.EV_EBIT, F.EV_EBITDA,
            F.GROSS_PROFIT_MARGIN, F.OPERATING_PROFIT_MARGIN, F.POST_TAX_MARGIN,
            F.ROE, F.ROA, F.CASH_CIRCULATION, F.DAYS_INVENTORY, F.DAYS_PAYABLE, F.DAYS_RECEIVABLE,
            F.DEBT_TO_EQUITY, F.DEBT_ON_EBITDA, F.CAPEX_ON_FIXED_ASSET
        ]
    },
    "banking": {
        "fundamental.equity.income_statement": [
            F.NET_INTEREST_INCOME,
            F.NET_FEE_AND_COMMISSION_INCOME,
            F.NET_GAIN_LOSS_FROM_INVESTMENT_ACTIVITIES,
            F.NET_OTHER_INCOME,
            F.TOTAL_OPERATING_INCOME,
            F.QOQ_GROWTH,
            F.YOY_GROWTH,
            F.PROVISION_FOR_CREDIT_LOSSES,
            F.PROFIT_BEFORE_PROVISION,
            F.OPERATING_EXPENSES,
            F.PROFIT_BEFORE_TAX,
            F.NET_PROFIT_AFTER_TAX,
            F.PROFIT_AFTER_TAX_FOR_SHAREHOLDERS_OF_PARENT_COMPANY,
        ],
        "fundamental.equity.balance_sheet": [
            F.CASH_AND_CASH_EQUIVALENTS,
            F.DEPOSITS_WITH_SBV,
            F.DEPOSITS_AT_OTHER_CREDIT_INSTITUTIONS,
            F.LOANS_TO_OTHER_CREDIT_INSTITUTIONS,
            F.INVESTMENT_SECURITIES,
            F.CUSTOMER_LOANS,
            F.BAD_DEBTS,
            F.PROVISION_FOR_CUSTOMER_LOANS,
            F.NET_CUSTOMER_LOANS,
            F.FIXED_ASSETS,
            F.INTEREST_AND_FEES_RECEIVABLE,
            F.OTHER_ASSETS,
            F.TOTAL_ASSETS,
            F.DEPOSITS_FROM_OTHER_CREDIT_INSTITUTIONS,
            F.BORROWINGS_FROM_OTHER_CREDIT_INSTITUTIONS,
            F.DEBTS_TO_GOVERNMENT_AND_SBV,
            F.CUSTOMER_DEPOSITS,
            F.VALUABLE_PAPERS_ISSUED,
            F.INTEREST_AND_FEES_PAYABLE,
            F.OTHER_PAYABLES,
            F.TOTAL_ASSETS,
            F.BAD_DEBTS,
            F.LIABILITIES,
            F.OWNERS_CAPITAL,
            F.CREDIT_INSTITUTION_FUNDS,
            F.UNDISTRIBUTED_EARNINGS_AFTER_TAX,
            F.OWNERS_EQUITY,
            F.MINORITY_INTEREST,
        ],
        "fundamental.equity.cash_flow": [
            F.NET_CASH_FLOWS_FROM_OPERATING_ACTIVITIES,
            F.NET_CASH_FLOWS_FROM_INVESTING_ACTIVITIES,
            F.NET_CASH_FLOWS_FROM_FINANCING_ACTIVITIES,
        ],
        "fundamental.equity.ratio": [
            F.P_E, F.P_B, F.TRAILING_EPS, F.BOOK_VALUE_PER_SHARE,
            F.ROE, F.ROA, F.NIM, F.COST_OF_FUNDS,
            F.NII_TO_TOI, F.CIR, F.PROFIT_BEFORE_PROVISION_TO_TOI, F.PAT_TO_TOI,
            F.LOANS_TO_EARNING_ASSETS, F.LOANS_TO_TOTAL_ASSETS, F.LOANS_TO_DEPOSITS, F.DEPOSITS_TO_EARNING_ASSETS,
            F.NPL_RATIO, F.NPL_WRITE_OFF_RATIO, F.NPL_COVERAGE_RATIO, F.NPL_TO_TOTAL_ASSETS,
            F.EQUITY_TO_TOTAL_ASSETS, F.DEBT_TO_EQUITY, F.LIQUID_ASSETS_TO_LIABILITIES, F.EQUITY_TO_LOANS
        ]
    },

    "securities": {
        "fundamental.equity.income_statement": [
            F.NET_REVENUE,
            F.QOQ_GROWTH,
            F.YOY_GROWTH,
            F.COST_OF_GOODS_SOLD,
            F.GROSS_PROFIT,
            F.OPERATING_EXPENSES,
            F.OPERATING_PROFIT,
            F.INTEREST_EXPENSES,
            F.PROFIT_BEFORE_TAX,
            F.NET_PROFIT_AFTER_TAX,
            F.PROFIT_AFTER_TAX_FOR_SHAREHOLDERS_OF_PARENT_COMPANY,
            F.NET_GAIN_LOSS_FROM_TRADING_SECURITIES,
            F.GAIN_FROM_DISPOSAL_OF_FVTPL_ASSETS,
            F.GAIN_FROM_REVALUATION_OF_FVTPL_ASSETS,
            F.DIVIDENDS_AND_INTEREST_FROM_FVTPL_ASSETS,
            F.NET_GAIN_LOSS_FROM_INVESTMENT_SECURITIES,
            F.INTEREST_INCOME_FROM_LOANS,
            F.BROKERAGE_REVENUE,
        ],
        "fundamental.equity.balance_sheet": [
            F.A_SHORT_TERM_ASSETS,
            F.CASH_AND_CASH_EQUIVALENTS,
            F.SHORT_TERM_FINANCIAL_INVESTMENTS,
            F.SHORT_TERM_TRADE_ACCOUNTS_RECEIVABLE,
            F.INVENTORIES,
            F.LONG_TERM_ASSETS,
            F.LONG_TERM_FINANCIAL_INVESTMENTS,
            F.FIXED_ASSETS,
            F.TOTAL_ASSETS,
            F.LIABILITIES,
            F.SHORT_TERM_BORROWINGS_AND_FINANCIAL_LEASES,
            F.LONG_TERM_BORROWINGS_AND_FINANCIAL_LEASES,
            F.OWNERS_EQUITY,
            F.OWNERS_CAPITAL,
            F.FVTPL_ASSETS,
            F.AVAILABLE_FOR_SALE_SECURITIES,
            F.HELD_TO_MATURITY_INVESTMENTS,
            F.MARGIN_LOANS,
            F.CUSTOMER_DEPOSITS,
        ],
        "fundamental.equity.cash_flow": [
            F.NET_CASH_FLOWS_FROM_OPERATING_ACTIVITIES,
            F.NET_CASH_FLOWS_FROM_INVESTING_ACTIVITIES,
            F.NET_CASH_FLOWS_FROM_FINANCING_ACTIVITIES,
            "capex",
        ],
        "fundamental.equity.ratio": [
            F.P_E, F.P_B, F.TRAILING_EPS, F.BOOK_VALUE_PER_SHARE,
            F.ROE, F.ROA, F.GROSS_PROFIT_MARGIN, F.OPERATING_PROFIT_MARGIN,
            F.DEBT_TO_EQUITY, F.LIQUID_ASSETS_TO_LIABILITIES
        ]
    },
    "insurance": {
        "fundamental.equity.income_statement": [
            F.NET_REVENUE,
            F.QOQ_GROWTH,
            F.YOY_GROWTH,
            F.COST_OF_GOODS_SOLD,
            F.GROSS_PROFIT,
            F.OPERATING_EXPENSES,
            F.OPERATING_PROFIT,
            F.INTEREST_EXPENSES,
            F.PROFIT_BEFORE_TAX,
            F.NET_PROFIT_AFTER_TAX,
            F.PROFIT_AFTER_TAX_FOR_SHAREHOLDERS_OF_PARENT_COMPANY,
        ],
        "fundamental.equity.balance_sheet": [
            F.A_SHORT_TERM_ASSETS,
            F.CASH_AND_CASH_EQUIVALENTS,
            F.SHORT_TERM_FINANCIAL_INVESTMENTS,
            F.SHORT_TERM_TRADE_ACCOUNTS_RECEIVABLE,
            F.INVENTORIES,
            F.LONG_TERM_ASSETS,
            F.LONG_TERM_FINANCIAL_INVESTMENTS,
            F.FIXED_ASSETS,
            F.TOTAL_ASSETS,
            F.LIABILITIES,
            F.SHORT_TERM_BORROWINGS_AND_FINANCIAL_LEASES,
            F.LONG_TERM_BORROWINGS_AND_FINANCIAL_LEASES,
            F.OWNERS_EQUITY,
            F.OWNERS_CAPITAL,
        ],
        "fundamental.equity.cash_flow": [
            F.NET_CASH_FLOWS_FROM_OPERATING_ACTIVITIES,
            F.NET_CASH_FLOWS_FROM_INVESTING_ACTIVITIES,
            F.NET_CASH_FLOWS_FROM_FINANCING_ACTIVITIES,
        ],
        "fundamental.equity.ratio": [
            F.P_E, F.P_B, F.TRAILING_EPS, F.BOOK_VALUE_PER_SHARE,
            F.ROE, F.ROA, F.GROSS_PROFIT_MARGIN, F.OPERATING_PROFIT_MARGIN,
            F.DEBT_TO_EQUITY, F.LIQUID_ASSETS_TO_LIABILITIES
        ]
    }
}
