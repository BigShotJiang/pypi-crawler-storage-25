"""
Warrant schemas mapping definitions.
"""
SCHEMA_MAP = {
    "derivatives.warrant.info": {
        "kbs": {
            "SB": "symbol",
            "IN": "issuer",
            "ULS": "underlying_symbol",
            "EP": "exercise_price",
            "ER": "exercise_ratio",
            "LTD": "last_trading_date",
            "EX": "exchange",
            "LS": "listed_share",
            "CWT": "warrant_type",
            "CPR": "underlying_price",
            "RE": "reference_price",
            "CL": "ceiling_price",
            "FL": "floor_price",
            "CP": "match_price",
            "TV": "total_volume",
            "FR": "foreign_room",
            "FB": "foreign_buy_volume",
            "FS": "foreign_sell_volume",
            # Calculated fields built in explorer
            "break_even_point": "break_even_point",
            "break_even_point_diff": "break_even_point_diff",
            "intrinsic_value": "intrinsic_value"
        }
    }
}

STANDARD_COLUMNS = {
    "derivatives.warrant.info": [
        "symbol", "name", "isin", "issuer", "underlying_symbol", 
        "exercise_price", "exercise_ratio", "issue_date", "first_trading_date", 
        "last_trading_date", "maturity_date", "listed_share", "exchange", 
        "warrant_type", "underlying_price", "reference_price", "ceiling_price", 
        "floor_price", "match_price", "total_volume", "foreign_room", "foreign_buy_volume", "foreign_sell_volume",
        "break_even_point", "break_even_point_diff", "intrinsic_value"
    ]
}

ENUM_MAP = {
    "warrant_type": {
        "CWT": "Call",
        "C": "Call",
        "PWT": "Put",
        "P": "Put"
    },
    "exchange": {
        "HSX": "HOSE",
        # "1": "HOSE",
        "HNX": "HNX",
        "XHNF": "HNX",
        # "2": "HNX",
        "UPCOM": "UPCOM",
        # "3": "UPCOM"
    }
}

PROFILE_GLOSSARY = {
    "vi": {
        "symbol": "Mã chứng khoán",
        "name": "Tên",
        "full_name": "Tên đầy đủ",
        "isin": "Mã ISIN",
        "issuer": "Tổ chức phát hành",
        "underlying_symbol": "Mã CK cơ sở",
        "exercise_price": "Giá thực hiện",
        "exercise_ratio": "Tỷ lệ chuyển đổi",
        "issue_date": "Ngày phát hành",
        "first_trading_date": "Ngày giao dịch đầu tiên",
        "last_trading_date": "Ngày giao dịch cuối cùng",
        "maturity_date": "Ngày đáo hạn",
        "listed_share": "Khối lượng niêm yết",
        "exchange": "Sàn giao dịch",
        "warrant_type": "Loại chứng quyền",
        "underlying_price": "Giá CK cơ sở",
        "reference_price": "Giá tham chiếu",
        "ceiling_price": "Giá trần",
        "floor_price": "Giá sàn",
        "open_price": "Giá mở cửa",
        "high_price": "Giá cao nhất",
        "low_price": "Giá thấp nhất",
        "close_price": "Giá đóng cửa",
        "match_price": "Giá khớp lệnh",
        "total_volume": "Tổng khối lượng giao dịch",
        "foreign_room": "Room khối ngoại còn lại",
        "foreign_buy_volume": "KL Khối ngoại mua",
        "foreign_sell_volume": "KL Khối ngoại bán",
        "break_even_point": "Điểm hòa vốn",
        "break_even_point_diff": "Tỷ lệ chênh lệch điểm hòa vốn (%)",
        "intrinsic_value": "Giá trị nội tại",
        "open_interest": "Khối lượng mở (OI)",
        "basis": "Độ lệch (Basis)",
    },
    "en": {
        "symbol": "Symbol",
        "name": "Name",
        "full_name": "Full Name",
        "isin": "ISIN",
        "issuer": "Issuer",
        "underlying_symbol": "Underlying Symbol",
        "exercise_price": "Exercise Price",
        "exercise_ratio": "Exercise Ratio",
        "issue_date": "Issue Date",
        "first_trading_date": "First Trading Date",
        "last_trading_date": "Last Trading Date",
        "maturity_date": "Maturity Date",
        "listed_share": "Listed Volume",
        "exchange": "Exchange",
        "warrant_type": "Warrant Type",
        "underlying_price": "Underlying Price",
        "reference_price": "Reference Price",
        "ceiling_price": "Ceiling Price",
        "floor_price": "Floor Price",
        "open_price": "Open Price",
        "high_price": "High Price",
        "low_price": "Low Price",
        "close_price": "Close Price",
        "match_price": "Match Price",
        "total_volume": "Total Volume",
        "foreign_room": "Foreign Room Remaining",
        "foreign_buy_volume": "Foreign Buy Volume",
        "foreign_sell_volume": "Foreign Sell Volume",
        "break_even_point": "Break-even Premium",
        "break_even_point_diff": "Break-even Premium (%)",
        "intrinsic_value": "Intrinsic Value",
        "open_interest": "Open Interest (OI)",
        "basis": "Basis",
    }
}
