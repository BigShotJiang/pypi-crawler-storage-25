"""
Industry schemas mapping definitions.
"""
SCHEMA_MAP = {
    "industry.list": {
        "vci": {
            "icb_code": "icb_code",
            "icb_name": "icb_name",
            "level": "icb_level"
        }
    }
}

STANDARD_COLUMNS = {
    "industry.list": [
         "icb_code", "icb_name", "icb_name_en", "icb_level"
    ]
}
