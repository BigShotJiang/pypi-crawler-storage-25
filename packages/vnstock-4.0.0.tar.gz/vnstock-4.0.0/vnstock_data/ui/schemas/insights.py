"""
Insights Schema Mapping Definitions.
Layer 7 output standardization for Ranking, Valuation, etc.
"""

SCHEMA_MAP = {
    # Ranking
    "insights.ranking.gainer": {
        "vnd": {
            "symbol": "symbol", "index": "exchange", "last_price": "last_price",
            "last_updated": "last_updated", "price_change_1d": "price_change_1d",
            "price_change_pct_1d": "price_change_pct_1d", "accumulated_value": "total_value",
            "avg_volume_20d": "avg_volume_20d", "volume_spike_20d_pct": "volume_spike_20d_pct"
        }
    },
    "insights.ranking.loser": {
        "vnd": {
            "symbol": "symbol", "index": "exchange", "last_price": "last_price",
            "last_updated": "last_updated", "price_change_1d": "price_change_1d",
            "price_change_pct_1d": "price_change_pct_1d", "accumulated_value": "total_value"
        }
    },
    "insights.ranking.value": {
        "vnd": {
            "symbol": "symbol", "index": "exchange", "last_price": "last_price",
            "last_updated": "last_updated", "price_change_1d": "price_change_1d",
            "price_change_pct_1d": "price_change_pct_1d", "accumulated_value": "total_value"
        }
    },
    "insights.ranking.volume": {
        "vnd": {
            "symbol": "symbol", "index": "exchange", "last_price": "last_price",
            "last_updated": "last_updated", "price_change_1d": "price_change_1d",
            "price_change_pct_1d": "price_change_pct_1d", "accumulated_value": "total_value",
            "avg_volume_20d": "avg_volume_20d", "volume_spike_20d_pct": "volume_spike_20d_pct"
        }
    },
    "insights.ranking.deal": {
        "vnd": {
            "symbol": "symbol", "index": "exchange", "last_price": "last_price",
            "last_updated": "last_updated", "price_change_1d": "price_change_1d",
            "price_change_pct_1d": "price_change_pct_1d", "accumulated_value": "total_value",
            "deal_volume_spike_20d_pct": "deal_volume_spike_20d_pct"
        }
    },
    "insights.ranking.foreign_buy": {
        "vnd": {
            "symbol": "symbol", "date": "date", "net_value": "net_value"
        }
    },
    "insights.ranking.foreign_sell": {
        "vnd": {
            "symbol": "symbol", "date": "date", "net_value": "net_value"
        }
    },
    
    # Valuation
    "insights.valuation.pe": {
        "vnd": {"pe": "pe"} # Keeping simple
    },
    "insights.valuation.pb": {
        "vnd": {"pb": "pb"}
    },
    "insights.valuation.evaluation": {
        "vnd": {"pe": "pe", "pb": "pb"}
    },
    
    # Screener
    "insights.screener.filter": {
        "vci": {
            "ticker": "symbol",
            "market_price": "price",
            "daily_price_change_percent": "price_change_percent",
            "adtv30_days": "avg_value_30d",
            "trading_value_adtv10_days": "avg_value_10d",
            "avg_volume30_days": "avg_volume_30d",
            "price_return3_month": "price_return_3m",
            "price_fluctuation30_days": "price_fluctuation_30d",
            "outperforms_index3_month": "outperforms_index_3m",
            "rs3_month": "rs_3m",
            "ttm_pe": "pe",
            "ttm_pb": "pb",
            "ttm_roe": "roe",
            "npatmi_growth_yoy_qm1": "profit_growth_yoy",
            "es_volume_vs_avg_volume30_days": "volume_breakout_30d",
            "en_organ_name": "company_name_en",
            "en_organ_short_name": "short_name_en",
            "vi_organ_name": "company_name",
            "vi_organ_short_name": "short_name",
            "icb_code_lv2": "icb_code2",
            "en_sector": "industry_en",
            "icb_code_lv4": "icb_code4",
            "ema_time": "ema_time",
            "match_price_time": "match_price_time",
            "ema20": "ema_20",
            "price_ema20": "price_ema_20",
            "ema20_ema50": "ema_20_ema_50",
            "ema50_ema200": "ema_50_ema_200",
            "macd_signal_line": "macd_signal"
        }
    }
}

STANDARD_COLUMNS = {
    # We will use flexible standards for Insights as they vary wildly depending on analysis focus
    # For now, defining just the crucial ones
    "insights.ranking.gainer": ["symbol", "exchange", "last_price", "last_updated", "price_change_1d", "price_change_pct_1d", "total_value", "avg_volume_20d", "volume_spike_20d_pct"],
    "insights.ranking.loser": ["symbol", "exchange", "last_price", "last_updated", "price_change_1d", "price_change_pct_1d", "total_value"],
    "insights.ranking.value": ["symbol", "exchange", "last_price", "last_updated", "price_change_1d", "price_change_pct_1d", "total_value"],
    "insights.ranking.volume": ["symbol", "exchange", "last_price", "last_updated", "price_change_1d", "price_change_pct_1d", "total_value", "avg_volume_20d", "volume_spike_20d_pct"],
    "insights.ranking.deal": ["symbol", "exchange", "last_price", "last_updated", "price_change_1d", "price_change_pct_1d", "total_value", "deal_volume_spike_20d_pct"],
    "insights.ranking.foreign_buy": ["symbol", "date", "net_value"],
    "insights.ranking.foreign_sell": ["symbol", "date", "net_value"],
    "insights.valuation.pe": ["pe"],
    "insights.valuation.pb": ["pb"],
    "insights.valuation.evaluation": ["pe", "pb"]
}

ENUM_MAP = {
    "exchange": {
        "VNINDEX": "HOSE",
        "HNXINDEX": "HNX",
        "UPCOMINDEX": "UPCOM",
        "HSX": "HOSE"
    },
    "column_name": {
        "ticker": "symbol",
        "market_price": "price",
        "daily_price_change_percent": "price_change_percent",
        "adtv30_days": "avg_value_30d",
        "trading_value_adtv10_days": "avg_value_10d",
        "avg_volume30_days": "avg_volume_30d",
        "price_return3_month": "price_return_3m",
        "price_fluctuation30_days": "price_fluctuation_30d",
        "outperforms_index3_month": "outperforms_index_3m",
        "rs3_month": "rs_3m",
        "ttm_pe": "pe",
        "ttm_pb": "pb",
        "ttm_roe": "roe",
        "npatmi_growth_yoy_qm1": "profit_growth_yoy",
        "es_volume_vs_avg_volume30_days": "volume_breakout_30d",
        "en_organ_name": "company_name_en",
        "en_organ_short_name": "short_name_en",
        "vi_organ_name": "company_name",
        "vi_organ_short_name": "short_name",
        "icb_code_lv2": "industry_code_lv2",
        "en_sector": "industry_en",
        "vi_sector": "industry",
        "icb_code_lv4": "sub_industry_code",
        "ema_time": "ema_date",
        "match_price_time": "match_time",
        "ema20": "ema_20",
        "price_ema20": "price_ema_20",
        "ema20_ema50": "ema_20_ema_50",
        "ema50_ema200": "ema_50_ema_200",
        "macd_signal_line": "macd_signal"
    }
}
