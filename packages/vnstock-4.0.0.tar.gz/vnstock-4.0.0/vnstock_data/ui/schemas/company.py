"""
Company schemas mapping definitions.
"""
SCHEMA_MAP = {
    "company.info": {
        "vci": {
            "symbol": "symbol",
            "organ_name": "name",
            "company_profile": "profile",
            "sector": "sector",
            "issue_share": "issued_share"
        },
        "kbs": {
            "symbol": "symbol",
            "business_model": "profile",
            "history": "history",
            "charter_capital": "charter_capital",
            "num_employees": "num_employees",
            "listing_date": "listing_date",
            "founded_date": "founded_date",
            "exchange": "exchange",
            "website": "website",
            "address": "address",
            "tax_id": "tax_id",
            "phone": "phone",
            "email": "email",
        }
    },
    "company.shareholders": {
        "vci": {
            "symbol": "symbol",
            "share_holder": "name",
            "share_own_percent": "rate",
            "quantity": "total_shares",
            "update_date": "date"
        },
        "kbs": {
            "name": "name",
            "shares_owned": "total_shares",
            "ownership_percentage": "rate",
            "update_date": "date"
        }
    },
    "company.officers": {
        "vci": {
            "symbol": "symbol",
            "officer_name": "name",
            "officer_position": "position",
            "officer_own_percent": "rate",
            "officer_own_quantity": "total_shares"
        },
        "kbs": {
            "name": "name",
            "position": "position",
            "from_date": "from_date",
            "owner_code": "owner_code"
        }
    },
    "company.subsidiaries": {
        "vci": {
            "organ_name": "name",
            "ownership_percent": "rate",
            "sub_organ_code": "sub_symbol",
            "type": "type",
            "charter_capital": "charter_capital"
        },
        "kbs": {
            "name": "name",
            "ownership_percent": "rate",
            "charter_capital": "charter_capital",
            "currency": "currency",
            "type": "type"
        }
    },
    "company.margin_ratio": {
        "kbs": {
            "CompanyCode": "broker_code",
            "Name": "broker_name",
            "MarginRate": "margin_rate",
            "PrevMarginRate": "prev_margin_rate",
            "ClosedDate": "updated_at",
            "MarginPer": "margin_per",
        }
    }
}

STANDARD_COLUMNS = {
    "company.info": [
        "symbol", "name", "short_name", "exchange", "sector", "industry",
        "profile", "history", "num_employees", "founded_date", "listing_date",
        "charter_capital", "issued_share", "website", "address", "phone", "email", "tax_id"
    ],
    "company.shareholders": [
        "symbol", "name", "total_shares", "rate", "date"
    ],
    "company.officers": [
        "symbol", "name", "position", "from_date", "total_shares", "rate"
    ],
    "company.subsidiaries": [
        "symbol", "name", "rate", "sub_symbol", "charter_capital", "type"
    ],
    "company.margin_ratio": [
        "broker_code", "broker_name", "margin_rate", "prev_margin_rate", "margin_per", 
        "updated_at"
    ]
}

ENUM_MAP = {
    "type": {
        "công ty con": "Subsidiary",
        "công ty liên kết": "Affiliate"
    }
}
