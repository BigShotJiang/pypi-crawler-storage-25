"""
Events schemas mapping definitions.
"""
SCHEMA_MAP = {
    "events.calendar": {
        "vci": {
            "ticker": "symbol",
            "event_name_vi": "event_name",
            "organ_name_vi": "organ_name",
            "event_title_vi": "event_title",
            "exright_date": "ex_right_date",
            "record_date": "record_date",
            "payout_date": "payout_date",
            "public_date": "public_date",
            "issue_date": "issue_date",
            "value_per_share": "value",
            "exercise_ratio": "ratio",
            "event_code": "event_type"
        }
    },
    "events.market": {
        "vnstock": {
            "date": "date",
            "event": "event_name",
            "type": "event_type",
            "duration": "duration"
        }
    }
}

STANDARD_COLUMNS = {
    "events.calendar": [
        "symbol", "event_name", "event_title", "ex_right_date", "record_date", 
        "payout_date", "value", "ratio", "organ_name", "public_date", "issue_date", "event_type"
    ],
    "events.market": [
        "date", "event_name", "event_type", "duration"
    ]
}
