"""
UI Master Data Dictionary.

This module acts as the single source of truth for Unified API Financial Reporting standard columns.
It contains hardcoded, strict mapping variables defining exact English snake_case keys for accounting fields.
All data sources (KBS, MAS, VCI, TCBS) MUST map their native languages to these standard keys.
"""

from typing import Dict

# ==============================================================================
# FINANCIAL REPORTS - STANDARD ENGLISH SNAKE CASE KEYS
# ==============================================================================

class FundamentalKeys:
    # INCOME STATEMENT (Manufacturing & General)
    REVENUE = "revenue"
    DEDUCTION_FROM_REVENUE = "deduction_from_revenue"
    NET_REVENUE = "net_revenue"
    COST_OF_GOODS_SOLD = "cost_of_goods_sold"
    GROSS_PROFIT = "gross_profit"
    FINANCIAL_INCOME = "financial_income"
    FINANCIAL_EXPENSES = "financial_expenses"
    INTEREST_EXPENSES = "interest_expenses"
    OF_WHICH_INTEREST_EXPENSES = "of_which_interest_expenses"
    SHARE_OF_ASSOCIATES_AND_JOINT_VENTURES_RESULT = "share_of_associates_and_joint_ventures_result"
    SELLING_EXPENSES = "selling_expenses"
    GENERAL_AND_ADMINISTRATIVE_EXPENSES = "general_and_administrative_expenses"
    OPERATING_PROFIT = "operating_profit"
    OTHER_INCOME = "other_income"
    OTHER_EXPENSES = "other_expenses"
    OTHER_PROFIT = "other_profit"
    PROFIT_BEFORE_TAX = "profit_before_tax"
    CURRENT_CORPORATE_INCOME_TAX_EXPENSES = "current_corporate_income_tax_expenses"
    DEFERRED_INCOME_TAX_EXPENSES = "deferred_income_tax_expenses"
    NET_PROFIT_AFTER_TAX = "net_profit_after_tax"
    MINORITY_INTEREST = "minority_interest"
    PROFIT_AFTER_TAX_FOR_SHAREHOLDERS_OF_PARENT_COMPANY = "profit_after_tax_for_shareholders_of_parent_company"
    EARNINGS_PER_SHARE = "earnings_per_share"
    DILUTED_EARNINGS_PER_SHARE = "diluted_earnings_per_share"

    # INCOME STATEMENT (Banking & Securities)
    INTEREST_INCOME_AND_SIMILAR_INCOME = "interest_income_and_similar_income"
    INTEREST_EXPENSE_AND_SIMILAR_EXPENSES = "interest_expense_and_similar_expenses"
    NET_INTEREST_INCOME = "net_interest_income"
    FEE_AND_COMMISSION_INCOME = "fee_and_commission_income"
    FEE_AND_COMMISSION_EXPENSES = "fee_and_commission_expenses"
    NET_FEE_AND_COMMISSION_INCOME = "net_fee_and_commission_income"
    NET_GAIN_LOSS_FROM_FOREIGN_CURRENCIES_AND_GOLD_TRADING = "net_gain_loss_from_foreign_currencies_and_gold_trading"
    NET_GAIN_LOSS_FROM_TRADING_SECURITIES = "net_gain_loss_from_trading_securities"
    NET_GAIN_LOSS_FROM_INVESTMENT_SECURITIES = "net_gain_loss_from_investment_securities"
    NET_OTHER_INCOME = "net_other_income"
    INCOME_FROM_CAPITAL_CONTRIBUTION_AND_LONG_TERM_INVESTMENTS = "income_from_capital_contribution_and_long_term_investments"
    OPERATING_EXPENSES = "operating_expenses"
    OPERATING_PROFIT_BEFORE_PROVISION_FOR_CREDIT_LOSSES = "operating_profit_before_provision_for_credit_losses"
    PROVISION_FOR_CREDIT_LOSSES = "provision_for_credit_losses"
    CORPORATE_INCOME_TAX = "corporate_income_tax"
    GAIN_FROM_DISPOSAL_OF_FVTPL_ASSETS = "gain_from_disposal_of_fvtpl_assets"
    GAIN_FROM_REVALUATION_OF_FVTPL_ASSETS = "gain_from_revaluation_of_fvtpl_assets"
    DIVIDENDS_AND_INTEREST_FROM_FVTPL_ASSETS = "dividends_and_interest_from_fvtpl_assets"
    INTEREST_INCOME_FROM_LOANS = "interest_income_from_loans"
    LOSS_FROM_DISPOSAL_OF_FVTPL_ASSETS = "loss_from_disposal_of_fvtpl_assets"
    LOSS_FROM_REVALUATION_OF_FVTPL_ASSETS = "loss_from_revaluation_of_fvtpl_assets"
    BROKERAGE_EXPENSES = "brokerage_expenses"

    # SUPPLEMENTARY SPECIALIZED KPIs (Banks, Brokers, Insurance)
    CUSTOMER_LOANS = "customer_loans"
    CUSTOMER_DEPOSITS = "customer_deposits"
    BROKERAGE_REVENUE = "brokerage_revenue"
    FVTPL_ASSETS = "fvtpl_assets"
    MARGIN_LOANS = "margin_loans"
    NET_INSURANCE_PREMIUM = "net_insurance_premium"
    CLAIM_EXPENSES = "claim_expenses"

    # BANKING ADVANCED B/S
    DEPOSITS_WITH_SBV = "deposits_with_sbv"
    DEPOSITS_AT_OTHER_CREDIT_INSTITUTIONS = "deposits_at_other_credit_institutions"
    LOANS_TO_OTHER_CREDIT_INSTITUTIONS = "loans_to_other_credit_institutions"
    INVESTMENT_SECURITIES = "investment_securities"
    BAD_DEBTS = "bad_debts"
    PROVISION_FOR_CUSTOMER_LOANS = "provision_for_customer_loans"
    NET_CUSTOMER_LOANS = "net_customer_loans"
    INTEREST_AND_FEES_RECEIVABLE = "interest_and_fees_receivable"
    DEPOSITS_FROM_OTHER_CREDIT_INSTITUTIONS = "deposits_from_other_credit_institutions"
    BORROWINGS_FROM_OTHER_CREDIT_INSTITUTIONS = "borrowings_from_other_credit_institutions"
    DEBTS_TO_GOVERNMENT_AND_SBV = "debts_to_government_and_sbv"
    VALUABLE_PAPERS_ISSUED = "valuable_papers_issued"
    INTEREST_AND_FEES_PAYABLE = "interest_and_fees_payable"
    CREDIT_INSTITUTION_FUNDS = "credit_institution_funds"

    # BANKING ADVANCED I/S
    NET_GAIN_LOSS_FROM_INVESTMENT_ACTIVITIES = "net_gain_loss_from_investment_activities"
    TOTAL_OPERATING_INCOME = "total_operating_income"
    PROFIT_BEFORE_PROVISION = "profit_before_provision"

    # BALANCE SHEET (Assets)
    ASSETS = "assets"
    A_SHORT_TERM_ASSETS = "a_short_term_assets"
    CURRENT_ASSETS = "current_assets"
    CASH_AND_CASH_EQUIVALENTS = "cash_and_cash_equivalents"
    CASH = "cash"
    CASH_EQUIVALENTS = "cash_equivalents"
    SHORT_TERM_FINANCIAL_INVESTMENTS = "short_term_financial_investments"
    AVAILABLE_FOR_SALE_SECURITIES = "available_for_sale_securities"
    HELD_TO_MATURITY_INVESTMENTS = "held_to_maturity_investments"
    SHORT_TERM_RECEIVABLES = "short_term_receivables"
    SHORT_TERM_TRADE_ACCOUNTS_RECEIVABLE = "short_term_trade_accounts_receivable"
    SHORT_TERM_PREPAYMENTS_TO_SUPPLIERS = "short_term_prepayments_to_suppliers"
    SHORT_TERM_INTER_COMPANY_RECEIVABLES = "short_term_inter_company_receivables"
    SHORT_TERM_LOAN_RECEIVABLES = "short_term_loan_receivables"
    OTHER_SHORT_TERM_RECEIVABLES = "other_short_term_receivables"
    PROVISION_FOR_SHORT_TERM_DOUBTFUL_DEBTS = "provision_for_short_term_doubtful_debts"
    INVENTORIES = "inventories"
    PROVISION_FOR_DECLINE_IN_VALUE_OF_INVENTORIES = "provision_for_decline_in_value_of_inventories"
    OTHER_SHORT_TERM_ASSETS = "other_short_term_assets"
    SHORT_TERM_PREPAYMENTS = "short_term_prepayments"
    VALUE_ADDED_TAX_TO_BE_RECLAIMED = "value_added_tax_to_be_reclaimed"
    TAXES_AND_OTHER_RECEIVABLES_FROM_STATE_AUTHORITIES = "taxes_and_other_receivables_from_state_authorities"

    LONG_TERM_ASSETS = "long_term_assets"
    LONG_TERM_RECEIVABLES = "long_term_receivables"
    LONG_TERM_TRADE_RECEIVABLES = "long_term_trade_receivables"
    LONG_TERM_PREPAYMENTS_TO_SUPPLIERS = "long_term_prepayments_to_suppliers"
    CAPITAL_AT_INTER_COMPANY = "capital_at_inter_company"
    LONG_TERM_INTER_COMPANY_RECEIVABLES = "long_term_inter_company_receivables"
    LONG_TERM_LOAN_RECEIVABLES = "long_term_loan_receivables"
    OTHER_LONG_TERM_RECEIVABLES = "other_long_term_receivables"
    PROVISION_FOR_LONG_TERM_DOUBTFUL_DEBTS = "provision_for_long_term_doubtful_debts"
    FIXED_ASSETS = "fixed_assets"
    TANGIBLE_FIXED_ASSETS = "tangible_fixed_assets"
    COST = "cost"
    ACCUMULATED_DEPRECIATION = "accumulated_depreciation"
    FINANCIAL_LEASED_FIXED_ASSETS = "financial_leased_fixed_assets"
    INTANGIBLE_FIXED_ASSETS = "intangible_fixed_assets"
    INVESTMENT_PROPERTIES = "investment_properties"
    LONG_TERM_ASSETS_IN_PROGRESS = "long_term_assets_in_progress"
    CONSTRUCTION_IN_PROGRESS = "construction_in_progress"
    LONG_TERM_FINANCIAL_INVESTMENTS = "long_term_financial_investments"
    INVESTMENTS_IN_SUBSIDIARIES = "investments_in_subsidiaries"
    INVESTMENTS_IN_ASSOCIATES_JOINT_VENTURES = "investments_in_associates_joint_ventures"
    INVESTMENTS_IN_OTHER_ENTITIES = "investments_in_other_entities"
    PROVISION_FOR_DIMINUTION_IN_VALUE_OF_LONG_TERM_INVESTMENTS = "provision_for_diminution_in_value_of_long_term_investments"
    OTHER_LONG_TERM_INVESTMENTS = "other_long_term_investments"
    OTHER_LONG_TERM_ASSETS = "other_long_term_assets"
    LONG_TERM_PREPAYMENTS = "long_term_prepayments"
    DEFERRED_INCOME_TAX_ASSETS = "deferred_income_tax_assets"
    GOODWILL = "goodwill"
    TOTAL_ASSETS = "total_assets"

    # BALANCE SHEET (Liabilities & Owners Equity)
    LIABILITIES = "liabilities"
    SHORT_TERM_LIABILITIES = "short_term_liabilities"
    SHORT_TERM_TRADE_ACCOUNTS_PAYABLE = "short_term_trade_accounts_payable"
    SHORT_TERM_ADVANCES_FROM_CUSTOMERS = "short_term_advances_from_customers"
    TAXES_AND_OTHER_PAYABLES_TO_STATE_AUTHORITIES = "taxes_and_other_payables_to_state_authorities"
    PAYABLE_TO_EMPLOYEES = "payable_to_employees"
    SHORT_TERM_ACRRUED_EXPENSES = "short_term_acrrued_expenses"
    SHORT_TERM_INTER_COMPANY_PAYABLES = "short_term_inter_company_payables"
    SHORT_TERM_UNEARNED_REVENUE = "short_term_unearned_revenue"
    OTHER_SHORT_TERM_PAYABLES = "other_short_term_payables"
    SHORT_TERM_BORROWINGS_AND_FINANCIAL_LEASES = "short_term_borrowings_and_financial_leases"
    PROVISION_FOR_SHORT_TERM_LIABILITIES = "provision_for_short_term_liabilities"
    BONUS_AND_WELFARE_FUND = "bonus_and_welfare_fund"

    LONG_TERM_LIABILITIES = "long_term_liabilities"
    LONG_TERM_TRADE_PAYABLES = "long_term_trade_payables"
    LONG_TERM_ADVANCES_FROM_CUSTOMERS = "long_term_advances_from_customers"
    LONG_TERM_ACRRUED_EXPENSES = "long_term_acrrued_expenses"
    LONG_TERM_INTER_COMPANY_PAYABLES = "long_term_inter_company_payables"
    LONG_TERM_UNEARNED_REVENUE = "long_term_unearned_revenue"
    OTHER_LONG_TERM_LIABILITIES = "other_long_term_liabilities"
    LONG_TERM_BORROWINGS_AND_FINANCIAL_LEASES = "long_term_borrowings_and_financial_leases"
    CONVERTIBLE_BONDS = "convertible_bonds"
    PREFERRED_STOCK = "preferred_stock"
    DEFERRED_INCOME_TAX_LIABILITIES = "deferred_income_tax_liabilities"
    PROVISION_FOR_LONG_TERM_LIABILITIES = "provision_for_long_term_liabilities"

    OWNERS_EQUITY = "owners_equity"
    OWNERS_CAPITAL = "owners_capital"
    SHARE_PREMIUM = "share_premium"
    OTHER_CAPITAL_OF_OWNERS = "other_capital_of_owners"
    TREASURY_SHARES = "treasury_shares"
    ASSETS_REVALUATION_DIFFERENCES = "assets_revaluation_differences"
    FOREIGN_EXCHANGE_DIFFERENCES = "foreign_exchange_differences"
    INVESTMENT_AND_DEVELOPMENT_FUND = "investment_and_development_fund"
    UNDISTRIBUTED_EARNINGS_AFTER_TAX = "undistributed_earnings_after_tax"
    REALIZED_RETAINED_EARNINGS = "realized_retained_earnings"
    UNREALIZED_RETAINED_EARNINGS = "unrealized_retained_earnings"
    TOTAL_LIABILITIES_EQUITY = "total_liabilities_equity"

    # CASH FLOW
    NET_CASH_FLOWS_FROM_OPERATING_ACTIVITIES = "net_cash_flows_from_operating_activities"
    NET_CASH_FLOWS_FROM_INVESTING_ACTIVITIES = "net_cash_flows_from_investing_activities"
    NET_CASH_FLOWS_FROM_FINANCING_ACTIVITIES = "net_cash_flows_from_financing_activities"
    NET_CASH_FLOWS_DURING_THE_PERIOD = "net_cash_flows_during_the_period"
    CASH_AND_CASH_EQUIVALENTS_AT_BEGINNING_OF_THE_PERIOD = "cash_and_cash_equivalents_at_beginning_of_the_period"
    CASH_AND_CASH_EQUIVALENTS_AT_END_OF_THE_PERIOD = "cash_and_cash_equivalents_at_end_of_the_period"

    # RATIOS
    TRAILING_EPS = "trailing_eps"
    BOOK_VALUE_PER_SHARE = "book_value_per_share"
    P_E = "pe"
    P_B = "pb"
    P_S = "ps"
    DIVIDEND_YIELD = "dividend_yield"
    BETA = "beta"
    EV_EBIT = "ev_ebit"
    EV_EBITDA = "ev_ebitda"
    
    # BANKING ADVANCED RATIOS
    ROE = "roe"
    ROA = "roa"
    NIM = "nim"
    COST_OF_FUNDS = "cost_of_funds"
    NII_TO_TOI = "nii_to_toi"
    CIR = "cir"
    PROFIT_BEFORE_PROVISION_TO_TOI = "profit_before_provision_to_toi"
    PAT_TO_TOI = "pat_to_toi"
    LOANS_TO_EARNING_ASSETS = "loans_to_earning_assets"
    LOANS_TO_TOTAL_ASSETS = "loans_to_total_assets"
    LOANS_TO_DEPOSITS = "loans_to_deposits"
    DEPOSITS_TO_EARNING_ASSETS = "deposits_to_earning_assets"
    NPL_RATIO = "npl_ratio"
    NPL_WRITE_OFF_RATIO = "npl_write_off_ratio"
    NPL_COVERAGE_RATIO = "npl_coverage_ratio"
    NPL_TO_TOTAL_ASSETS = "npl_to_total_assets"
    EQUITY_TO_TOTAL_ASSETS = "equity_to_total_assets"
    DEBT_TO_EQUITY = "debt_to_equity"
    LIQUID_ASSETS_TO_LIABILITIES = "liquid_assets_to_liabilities"
    EQUITY_TO_LOANS = "equity_to_loans"
    
    # ADDITIONAL GENERIC GROWTH / PROFIT MARGIN RATIOS
    YOY_GROWTH = "yoy_growth"
    QOQ_GROWTH = "qoq_growth"
    GROSS_PROFIT_MARGIN = "gross_profit_margin"
    OPERATING_PROFIT_MARGIN = "operating_profit_margin"
    POST_TAX_MARGIN = "post_tax_margin"
    CASH_CIRCULATION = "cash_circulation"
    DAYS_INVENTORY = "days_inventory"
    DAYS_PAYABLE = "days_payable"
    DAYS_RECEIVABLE = "days_receivable"
    DEBT_ON_EBITDA = "debt_on_ebitda"
    CAPEX_ON_FIXED_ASSET = "capex_on_fixed_asset"
    OTHER_ASSETS = "other_assets"
    OTHER_PAYABLES = "other_payables"


# ==============================================================================
# VIETNAMESE LOCALIZATION (TCBS Standard)
# ==============================================================================
FUNDAMENTAL_VI_LABELS = {
    # Income Statement
    FundamentalKeys.NET_INTEREST_INCOME: "Thu nhập lãi thuần",
    FundamentalKeys.NET_FEE_AND_COMMISSION_INCOME: "Lãi thuần từ HĐ dịch vụ",
    FundamentalKeys.NET_GAIN_LOSS_FROM_INVESTMENT_ACTIVITIES: "Lãi thuần từ HĐ đầu tư",
    FundamentalKeys.NET_OTHER_INCOME: "Lãi thuần từ HĐ khác",
    FundamentalKeys.TOTAL_OPERATING_INCOME: "Tổng thu nhập HĐ (TOI)",
    FundamentalKeys.YOY_GROWTH: "YoY%",
    FundamentalKeys.QOQ_GROWTH: "QoQ%",
    
    # Additional MAS-specific fields
    "cash_gold_precious_stones": "Tiền mặt, vàng bạc, đá quý",
    "provision_for_loans_to_other_credit_institutions": "Dự phòng rủi ro cho vay TCTD khác",
    "trading_securities": "Chứng khoán kinh doanh",
    "provision_for_decline_in_trading_securities": "Dự phòng giảm giá CK kinh doanh",
    "derivatives_and_other_financial_assets": "Công cụ phái sinh và tài sản tài chính khác",
    "purchased_debts": "Mua nợ",
    "provision_for_debt_purchase_activities": "Dự phòng rủi ro hoạt động mua nợ",
    "available_for_sale_investment_securities": "CK đầu tư sẵn sàng để bán",
    "held_to_maturity_investment_securities": "CK đầu tư giữ đến ngày đáo hạn",
    "provision_for_decline_in_investment_securities": "Dự phòng giảm giá CK đầu tư",
    "investment_in_subsidiaries": "Đầu tư vào công ty con",
    "investment_in_associates": "Đầu tư vào công ty liên doanh, liên kết",
    "other_long_term_investments": "Đầu tư dài hạn khác",
    "provision_for_decline_in_long_term_investments": "Dự phòng giảm giá đầu tư dài hạn",
    "tangible_fixed_assets": "Tài sản cố định hữu hình",
    "original_cost_of_fixed_assets": "Nguyên giá TSCĐ",
    "depreciation_of_fixed_assets": "Hao mòn TSCĐ",
    "finance_lease_fixed_assets": "Tài sản cố định thuê tài chính",
    "intangible_fixed_assets": "Tài sản cố định vô hình",
    "original_cost_of_investment_properties": "Nguyên giá BĐSĐT",
    "depreciation_of_investment_properties": "Hao mòn BĐSĐT",
    "receivables": "Các khoản phải thu",
    "deferred_tax_assets": "Tài sản thuế TNDN hoãn lại",
    "goodwill": "Lợi thế thương mại",
    "provision_for_other_on_balance_sheet_assets": "Dự phòng rủi ro tài sản nội bảng khác",
    "derivatives_and_other_financial_liabilities": "Công cụ phái sinh và nợ tài chính khác",
    "sponsored_capital": "Vốn tài trợ, ủy thác đầu tư",
    "deferred_tax_liabilities": "Thuế TNDN hoãn lại phải trả",
    "other_provisions": "Dự phòng rủi ro khác",
    "credit_institution_capital": "Vốn của TCTD",
    "charter_capital": "Vốn điều lệ",
    "investment_in_construction_capital": "Vốn đầu tư XDCB",
    "share_premium": "Thặng dư vốn cổ phần",
    "treasury_shares": "Cổ phiếu quỹ",
    "preferred_shares": "Cổ phiếu ưu đãi",
    "other_capital": "Vốn khác",
    
    # Cash Flow additional fields
    "interest_and_similar_income_received": "Thu nhập lãi và tương tự nhận được",
    "interest_and_similar_expenses_paid": "Chi phí lãi và tương tự đã trả",
    "service_income_received": "Thu nhập từ hoạt động dịch vụ",
    "net_cash_from_trading_activities": "Chênh lệch thực thu/thực chi KD",
    "other_income": "Thu nhập khác",
    "cash_from_debt_write_offs": "Tiền thu từ xử lý xóa nợ",
    "payments_for_employees_and_management": "Chi trả nhân viên và quản lý",
    "net_cash_from_operating_activities_before_working_capital_changes": "LCTT KD trước thay đổi vốn lưu động",
    "changes_in_operating_assets": "Thay đổi tài sản hoạt động",
    "increase_decrease_in_deposits_and_loans_to_other_credit_institutions": "(Tăng)/Giảm tiền gửi và cho vay TCTD khác",
    "increase_decrease_in_trading_securities": "(Tăng)/Giảm kinh doanh chứng khoán",
    "increase_decrease_in_derivatives_and_other_financial_instruments": "(Tăng)/Giảm công cụ phái sinh",
    "increase_decrease_in_loans_to_customers": "(Tăng)/Giảm cho vay khách hàng",
    "decrease_in_provisions_for_loss": "Giảm nguồn dự phòng",
    "other_changes_in_operating_assets": "(Tăng)/Giảm khác tài sản hoạt động",
    "changes_in_operating_liabilities": "Thay đổi công nợ hoạt động",
    "increase_decrease_in_debts_to_government_and_sbv": "Tăng/(Giảm) nợ Chính phủ và NHNN",
    "increase_decrease_in_deposits_and_borrowings_from_credit_institutions": "Tăng/(Giảm) tiền gửi, vay TCTD",
    "increase_decrease_in_customer_deposits": "Tăng/(Giảm) tiền gửi khách hàng",
    "increase_decrease_in_issued_valuable_papers": "Tăng/(Giảm) phát hành giấy tờ có giá",
    "increase_decrease_in_sponsored_capital": "Tăng/(Giảm) vốn tài trợ, ủy thác đầu tư",
    "increase_decrease_in_derivatives_and_other_financial_liabilities": "Tăng/(Giảm) công cụ phái sinh",
    "other_changes_in_operating_liabilities": "Tăng/(Giảm) khác công nợ hoạt động",
    "payments_from_credit_institution_funds": "Chi từ các quỹ của TCTD",
    "purchase_of_fixed_assets": "Mua sắm tài sản cố định",
    "receipts_from_disposal_of_fixed_assets": "Tiền thu từ thanh lý TSCĐ",
    "payments_from_disposal_of_fixed_assets": "Tiền chi từ thanh lý TSCĐ",
    "purchase_of_investment_properties": "Mua sắm bất động sản đầu tư",
    "receipts_from_sale_of_investment_properties": "Tiền thu từ bán BĐSĐT",
    "payments_from_sale_of_investment_properties": "Tiền chi từ bán BĐSĐT",
    "payments_for_investment_in_other_entities": "Tiền chi đầu tư góp vốn đơn vị khác",
    "receipts_from_investment_in_other_entities": "Tiền thu đầu tư góp vốn đơn vị khác",
    "dividends_and_profit_from_long_term_investments": "Cổ tức và lợi nhuận từ đầu tư dài hạn",
    "increase_in_capital_from_contribution_and_or_share_issuance": "Tăng vốn từ góp vốn/phát hành cổ phiếu",
    "receipts_from_long_term_valuable_papers_and_long_term_borrowings": "Tiền thu từ GTGT dài hạn và vay dài hạn",
    "payments_for_long_term_valuable_papers_and_long_term_borrowings": "Tiền chi GTGT dài hạn và vay dài hạn",
    "dividends_paid_to_shareholders": "Cổ tức trả cho cổ đông",
    "payments_for_treasury_shares": "Tiền chi mua cổ phiếu quỹ",
    "receipts_from_treasury_shares": "Tiền thu bán cổ phiếu quỹ",
    "net_cash_flow_for_the_period": "Lưu chuyển tiền thuần trong kỳ",
    "cash_and_cash_equivalents_at_beginning_of_period": "Tiền và tương đương tiền đầu kỳ",
    "adjustment_for_exchange_rate_changes": "Điều chỉnh thay đổi tỷ giá",
    "cash_and_cash_equivalents_at_end_of_period": "Tiền và tương đương tiền cuối kỳ",
    
    # Valuation Ratios
    FundamentalKeys.P_E: "P/E",
    FundamentalKeys.P_B: "P/B",
    FundamentalKeys.P_S: "P/S",
    FundamentalKeys.TRAILING_EPS: "EPS (Trailing)",
    FundamentalKeys.BOOK_VALUE_PER_SHARE: "BVPS",
    FundamentalKeys.DIVIDEND_YIELD: "Tỷ suất cổ tức",
    FundamentalKeys.EV_EBIT: "EV/EBIT",
    FundamentalKeys.EV_EBITDA: "EV/EBITDA",
    FundamentalKeys.ROE: "ROE",
    FundamentalKeys.ROA: "ROA",
    FundamentalKeys.GROSS_PROFIT_MARGIN: "Tỷ suất lợi nhuận gộp",
    FundamentalKeys.OPERATING_PROFIT_MARGIN: "Tỷ suất lợi nhuận hoạt động",
    FundamentalKeys.DEBT_TO_EQUITY: "Tỷ lệ nợ/Vốn",
    FundamentalKeys.LIQUID_ASSETS_TO_LIABILITIES: "Tỷ lệ tài sản lỏng/Nợ",
    FundamentalKeys.PROVISION_FOR_CREDIT_LOSSES: "Chi phí dự phòng",
    FundamentalKeys.PROFIT_BEFORE_PROVISION: "Lợi nhuận trước dự phòng",
    FundamentalKeys.OPERATING_EXPENSES: "Chi phí hoạt động",
    FundamentalKeys.PROFIT_BEFORE_TAX: "LN trước thuế",
    FundamentalKeys.NET_PROFIT_AFTER_TAX: "LN sau thuế",
    FundamentalKeys.PROFIT_AFTER_TAX_FOR_SHAREHOLDERS_OF_PARENT_COMPANY: "LNST & CĐ thiểu số",
    FundamentalKeys.NET_REVENUE: "Doanh thu thuần",
    FundamentalKeys.COST_OF_GOODS_SOLD: "Giá vốn hàng bán",
    FundamentalKeys.GROSS_PROFIT: "Lợi nhuận gộp",
    FundamentalKeys.OPERATING_PROFIT: "LN hoạt động KD",
    FundamentalKeys.INTEREST_EXPENSES: "Chi phí lãi vay",
    
    # Balance Sheet
    FundamentalKeys.A_SHORT_TERM_ASSETS: "Tài sản ngắn hạn",
    FundamentalKeys.CASH_AND_CASH_EQUIVALENTS: "Tiền & tương đương",
    FundamentalKeys.SHORT_TERM_FINANCIAL_INVESTMENTS: "Đầu tư ngắn hạn",
    FundamentalKeys.SHORT_TERM_TRADE_ACCOUNTS_RECEIVABLE: "Phải thu khách hàng",
    FundamentalKeys.INVENTORIES: "Hàng tồn kho",
    FundamentalKeys.LONG_TERM_ASSETS: "Tài sản dài hạn",
    FundamentalKeys.FIXED_ASSETS: "Tài sản cố định",
    FundamentalKeys.LONG_TERM_FINANCIAL_INVESTMENTS: "Đầu tư TC dài hạn",
    FundamentalKeys.TOTAL_ASSETS: "Tổng tài sản",
    
    FundamentalKeys.DEPOSITS_WITH_SBV: "Tiền gửi tại NHNN",
    FundamentalKeys.DEPOSITS_AT_OTHER_CREDIT_INSTITUTIONS: "Tiền gửi TCTD khác",
    FundamentalKeys.LOANS_TO_OTHER_CREDIT_INSTITUTIONS: "Cho vay TCTD khác",
    FundamentalKeys.INVESTMENT_SECURITIES: "Chứng khoán đầu tư",
    FundamentalKeys.CUSTOMER_LOANS: "Cho vay khách hàng",
    FundamentalKeys.BAD_DEBTS: "Nợ xấu",
    FundamentalKeys.PROVISION_FOR_CUSTOMER_LOANS: "Dự phòng cho vay KH",
    FundamentalKeys.NET_CUSTOMER_LOANS: "Cho vay KH ròng",
    FundamentalKeys.INTEREST_AND_FEES_RECEIVABLE: "Lãi, phí phải thu",
    FundamentalKeys.OTHER_ASSETS: "Tài sản khác",
    
    FundamentalKeys.LIABILITIES: "Tổng nợ phải trả",
    FundamentalKeys.SHORT_TERM_BORROWINGS_AND_FINANCIAL_LEASES: "Vay ngắn hạn",
    FundamentalKeys.LONG_TERM_BORROWINGS_AND_FINANCIAL_LEASES: "Vay dài hạn",
    
    FundamentalKeys.DEPOSITS_FROM_OTHER_CREDIT_INSTITUTIONS: "Tiền gửi của TCTD",
    FundamentalKeys.BORROWINGS_FROM_OTHER_CREDIT_INSTITUTIONS: "Vay các TCTD",
    FundamentalKeys.DEBTS_TO_GOVERNMENT_AND_SBV: "Nợ CP & NHNN",
    FundamentalKeys.CUSTOMER_DEPOSITS: "Tiền gửi khách hàng",
    FundamentalKeys.VALUABLE_PAPERS_ISSUED: "PH giấy tờ có giá",
    FundamentalKeys.INTEREST_AND_FEES_PAYABLE: "Lãi & phí phải trả",
    FundamentalKeys.OTHER_PAYABLES: "Nợ phải trả khác",
    
    FundamentalKeys.OWNERS_CAPITAL: "Vốn điều lệ",
    FundamentalKeys.CREDIT_INSTITUTION_FUNDS: "Quỹ của TCTD",
    FundamentalKeys.UNDISTRIBUTED_EARNINGS_AFTER_TAX: "Lợi nhuận chưa PP",
    FundamentalKeys.OWNERS_EQUITY: "Vốn chủ sở hữu",
    FundamentalKeys.MINORITY_INTEREST: "Lợi ích không kiểm soát",
    
    # Cash flow
    FundamentalKeys.NET_CASH_FLOWS_FROM_OPERATING_ACTIVITIES: "Từ HĐ kinh doanh",
    FundamentalKeys.NET_CASH_FLOWS_FROM_INVESTING_ACTIVITIES: "Từ HĐ đầu tư",
    FundamentalKeys.NET_CASH_FLOWS_FROM_FINANCING_ACTIVITIES: "Từ HĐ tài chính",
    "capex": "Chi phí đầu tư",

    # Securities & Options
    FundamentalKeys.FVTPL_ASSETS: "Tài sản FVTPL",
    FundamentalKeys.AVAILABLE_FOR_SALE_SECURITIES: "Tài sản AFS",
    FundamentalKeys.HELD_TO_MATURITY_INVESTMENTS: "Đầu tư HTM",
    FundamentalKeys.MARGIN_LOANS: "Cho vay margin",
    FundamentalKeys.BROKERAGE_REVENUE: "Doanh thu môi giới",
    FundamentalKeys.NET_GAIN_LOSS_FROM_TRADING_SECURITIES: "Lãi/Lỗ FVTPL",
    FundamentalKeys.GAIN_FROM_DISPOSAL_OF_FVTPL_ASSETS: "Lãi bán FVTPL",
    FundamentalKeys.GAIN_FROM_REVALUATION_OF_FVTPL_ASSETS: "Lãi đánh giá lại FVTPL",
    FundamentalKeys.DIVIDENDS_AND_INTEREST_FROM_FVTPL_ASSETS: "Cổ tức & lãi từ FVTPL",
    FundamentalKeys.NET_GAIN_LOSS_FROM_INVESTMENT_SECURITIES: "Lãi/Lỗ AFS/HTM",
    FundamentalKeys.INTEREST_INCOME_FROM_LOANS: "Lãi từ cho vay",
    FundamentalKeys.LOSS_FROM_DISPOSAL_OF_FVTPL_ASSETS: "Lỗ bán FVTPL",
    FundamentalKeys.LOSS_FROM_REVALUATION_OF_FVTPL_ASSETS: "Lỗ đánh giá lại FVTPL",
    FundamentalKeys.BROKERAGE_EXPENSES: "Chi phí môi giới",
    
    # Insurance
    FundamentalKeys.NET_INSURANCE_PREMIUM: "Doanh thu phí bảo hiểm thuần",
    FundamentalKeys.CLAIM_EXPENSES: "Chi phí bồi thường",
    FundamentalKeys.FINANCIAL_INCOME: "Doanh thu hoạt động tài chính",
}

