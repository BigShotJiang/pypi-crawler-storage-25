"""
Equity schemas mapping definitions.
"""
SCHEMA_MAP = {
    "equity.list": {
        "vci": {
            "symbol": "symbol",
            "organ_name": "org_name",
            "icb_name3": "icb_name",
            "exchange": "exchange",
            "type": "listing_type"
        },
        "kbs": {}
    }
}

STANDARD_COLUMNS = {
    "equity.list": [
        "symbol", "org_name", "exchange", "icb_name", "listing_type"
    ]
}
