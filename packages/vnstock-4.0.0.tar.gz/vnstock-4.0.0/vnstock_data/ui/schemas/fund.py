"""
Fund Schema Definitions.
"""

# We enforce strict column selections for listings, and `report_time` mapping for time series.

SCHEMA_MAP = {
    "reference.fund.list": {
        "fmarket": {
            "short_name": "ticker",
            "name": "organ_name",
            "fund_type": "fund_type",
            "fund_owner_name": "organ_short_name",
            "management_fee": "management_fee",
            "inception_date": "inception_date",
            "nav": "nav",
            "nav_update_at": "nav_update_at"
        }
    },
    "market.fund.history": {
        "fmarket": {
            "date": "time",
            "nav_per_unit": "nav"
        }
    },
    "market.fund.top_holding": {
        "fmarket": {
            "stock_code": "ticker",
            "industry": "industry",
            "net_asset_percent": "net_asset_percent",
            "type_asset": "asset_type",
            "update_at": "update_at"
        }
    },
    "market.fund.industry_holding": {
        "fmarket": {
            "industry": "industry",
            "net_asset_percent": "net_asset_percent"
        }
    },
    "market.fund.asset_holding": {
        "fmarket": {
            "asset_percent": "asset_percent",
            "asset_type": "asset_type"
        }
    }
}

STANDARD_COLUMNS = {
    "reference.fund.list": [
        "ticker", "organ_name", "organ_short_name", "fund_type",
        "management_fee", "inception_date", "nav", "nav_update_at"
    ],
    "market.fund.history": ["time", "nav"],
    "market.fund.top_holding": ["update_at", "ticker", "industry", "net_asset_percent", "asset_type"],
    "market.fund.industry_holding": ["industry", "net_asset_percent"],
    "market.fund.asset_holding": ["asset_type", "asset_percent"]
}

ENUM_MAP = {
    "fund_type": {
        "Quỹ cổ phiếu": "equity_fund",
        "Quỹ cân bằng": "balanced_fund",
        "Quỹ trái phiếu": "bond_fund"
    },
    "asset_type": {
        "STOCK": "equity",
        "BOND": "bond",
        "Cổ phiếu": "equity",
        "Trái phiếu": "bond",
        "Tiền và tương đương tiền": "cash_and_equivalents",
        "Khác": "others"
    }
}
