"""
Core standardization logic for UI Reference Layer.
"""
from typing import Any, Dict

# Central registry for all schema mappings
_SCHEMA_REGISTRY: Dict[str, Dict[str, Dict[str, str]]] = {}
_STANDARD_COLS_REGISTRY: Dict[str, list] = {}
_ENUM_REGISTRY: Dict[str, Dict[str, str]] = {}

def register_schemas(schema_map: dict, standard_cols: dict, enum_map: dict = None):
    """Register schema maps, standard columns, and optional enum value maps."""
    _SCHEMA_REGISTRY.update(schema_map)
    _STANDARD_COLS_REGISTRY.update(standard_cols)
    if enum_map:
        _ENUM_REGISTRY.update(enum_map)

def standardize_columns(df: Any, domain_method: str, source: str, strict: bool = False, filter_unmapped: bool = False) -> Any:
    """
    Standardize dataframe columns based on registered native schema mappings.
    
    Args:
        df: Pandas DataFrame from provider.
        domain_method: Key representing the domain method (e.g., 'company.profile').
        source: Provider source (e.g., 'vci').
        strict: If True, filters out any columns not part of the standard schema.
        filter_unmapped: If True, filters out columns that aren't natively mapped or standard.
    """
    import pandas as pd
    import unicodedata
    
    if not isinstance(df, pd.DataFrame):
        return df

    if df.empty:
        return df
        
    mapping = _SCHEMA_REGISTRY.get(domain_method, {}).get(source)
    if mapping:
        # Normalize the mapping keys to NFC to handle NFD anomalies (especially on macOS)
        norm_map = {unicodedata.normalize('NFC', str(k)): v for k, v in mapping.items()}
        # Normalize dataframe columns and apply the mapping
        rename_map = {col: norm_map[unicodedata.normalize('NFC', str(col))] 
                      for col in df.columns if unicodedata.normalize('NFC', str(col)) in norm_map}
        df = df.rename(columns=rename_map)
        
        # Aggregate duplicated columns resulting from mapping (e.g., Selling + G&A)
        # We ensure numeric coercion to avoid string concatenation
        if any(df.columns.duplicated()):
            # Coerce all columns to numeric before summing to avoid string concatenation issues
            # We iterate through each column individually to handle potential duplicated names returning DataFrames
            new_cols = []
            for i in range(len(df.columns)):
                col_name = df.columns[i]
                col_data = df.iloc[:, i]
                if col_name not in ['ticker', 'period']:
                    col_data = pd.to_numeric(col_data, errors='coerce')
                new_cols.append(col_data)
            df = pd.concat(new_cols, axis=1)
            
            # Sum up duplicated columns while preserving others
            df = df.T.groupby(level=0).sum(min_count=1).T
        
        if filter_unmapped:
            standard_cols = _STANDARD_COLS_REGISTRY.get(domain_method, [])
            mapped_keys = list(norm_map.values())
            keep_cols = [c for c in df.columns if c in mapped_keys or c in standard_cols]
            df = df[keep_cols]
        
    if strict:
        # Keep only standardized columns if they exist in the df
        standard_cols = _STANDARD_COLS_REGISTRY.get(domain_method, [])
        if standard_cols:
            keep_cols = [col for col in standard_cols if col in df.columns]
            df = df[keep_cols]
            
    # Apply Enum Mappings if defined
    for col, val_map in _ENUM_REGISTRY.items():
        if col in df.columns:
            # We use replace to map values without altering values not in the map
            df[col] = df[col].replace(val_map)

    return df
