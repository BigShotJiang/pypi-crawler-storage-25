"""
UI Module - Unified Interface for vnstock-data
"""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from vnstock_data.ui.reference import Reference
    from vnstock_data.ui.market import Market
    from vnstock_data.ui.insights import Insights
    from vnstock_data.ui.fundamental import Fundamental
    from vnstock_data.ui.macro import Macro
    from vnstock_data.ui.analytics import Analytics

__all__ = ["Reference", "Market", "Insights", "Fundamental", "Macro", "Analytics", "show_api", "show_doc"]

def __getattr__(name: str) -> Any:
    """
    Lazy load UI modules using PEP 562. 
    Allows IDE autocomplete and type hints to work correctly.
    """
    if name == "Reference":
        from vnstock_data.ui.reference import Reference as _Reference
        return _Reference
    elif name == "Market":
        from vnstock_data.ui.market import Market as _Market
        return _Market
    elif name == "Insights":
        from vnstock_data.ui.insights import Insights as _Insights
        return _Insights
    elif name == "Fundamental":
        from vnstock_data.ui.fundamental import Fundamental as _Fundamental
        return _Fundamental
    elif name == "Macro":
        from vnstock_data.ui.macro import Macro as _Macro
        return _Macro
    elif name == "Analytics":
        from vnstock_data.ui.analytics import Analytics as _Analytics
        return _Analytics
    
    elif name == "show_api":
        from vnstock_data.ui.helper import show_api as _show_api
        return _show_api
    elif name == "show_doc":
        from vnstock_data.ui.helper import show_doc as _show_doc
        return _show_doc
    
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
