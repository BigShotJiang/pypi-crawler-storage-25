"""
Market Data Layer Entry Point.
"""

from __future__ import annotations
from typing import List, TYPE_CHECKING
import pandas as pd

if TYPE_CHECKING:
    from vnstock_data.ui.domains.market.equity import EquityMarket
    from vnstock_data.ui.domains.market.derivatives import DerivativesMarket, FuturesMarket, WarrantMarket
    from vnstock_data.ui.domains.market.fund import FundMarket
    from vnstock_data.ui.domains.market.etf import ETFMarket
    from vnstock_data.ui.domains.market.crypto import CryptoMarket
    from vnstock_data.ui.domains.market.forex import ForexMarket
    from vnstock_data.ui.domains.market.commodity import CommodityMarket
    
from vnstock_data.ui._base import BaseDomain
from vnstock_data.ui._registry import MARKET_SOURCES

class Market:
    """
    Market Data Layer (Layer 2).
    Provides access to real-time and historical pricing data across all asset classes.
    """
    
    def __init__(self, index: str = 'VNINDEX', random_agent: bool = False, show_log: bool = False, **kwargs):
        self._index = index
        self._deprecated_warned = False
        
    def _warn_deprecate(self):
        if not getattr(self, '_deprecated_warned', False):
            import warnings
            warnings.warn(
                "Market methods pe(), pb(), evaluation() will be removed on 2026-08-31. "
                "Please use the new structure: `Analytics().valuation(index).pe()` instead.",
                PendingDeprecationWarning,
                stacklevel=3
            )
            self._deprecated_warned = True

    def pe(self, duration: str = '5Y') -> pd.DataFrame:
        self._warn_deprecate()
        from vnstock_data.ui.analytics import Analytics
        return Analytics().valuation(index=self._index).pe(duration=duration)

    def pb(self, duration: str = '5Y') -> pd.DataFrame:
        self._warn_deprecate()
        from vnstock_data.ui.analytics import Analytics
        return Analytics().valuation(index=self._index).pb(duration=duration)

    def evaluation(self, duration: str = '5Y') -> pd.DataFrame:
        self._warn_deprecate()
        from vnstock_data.ui.analytics import Analytics
        return Analytics().valuation(index=self._index).evaluation(duration=duration)
    
    def equity(self, symbol: str) -> 'EquityMarket':
        """Access equity market data."""
        from vnstock_data.ui.domains.market.equity import EquityMarket
        return EquityMarket(symbol)

    def index(self, symbol: str, **kwargs) -> 'IndexMarket':
        """Access index market data."""
        from vnstock_data.ui.domains.market.index import IndexMarket
        return IndexMarket(symbol, **kwargs)

    def futures(self, symbol: str) -> 'FuturesMarket':
        """Access futures market data."""
        from vnstock_data.ui.domains.market.derivatives import FuturesMarket
        return FuturesMarket(symbol)

    def warrant(self, symbol: str) -> 'WarrantMarket':
        """Access warrant market data."""
        from vnstock_data.ui.domains.market.derivatives import WarrantMarket
        return WarrantMarket(symbol)

    def etf(self, symbol: str) -> 'ETFMarket':
        """Access ETF market data."""
        from vnstock_data.ui.domains.market.etf import ETFMarket
        return ETFMarket(symbol)

    def fund(self, symbol: str = None) -> 'FundMarket':
        """
        Access historical NAVs and portfolio compositions for a specific Mutual Fund.
        """
        from vnstock_data.ui.domains.market.fund import FundMarket
        return FundMarket(symbol=symbol)

    def crypto(self, symbol: str, **kwargs) -> 'CryptoMarket':
        """Access crypto market data (e.g., 'BTC')."""
        from vnstock_data.ui.domains.market.crypto import CryptoMarket
        return CryptoMarket(symbol, **kwargs)

    def forex(self, symbol: str, **kwargs) -> 'ForexMarket':
        """Access forex market data (e.g., 'USDVND')."""
        from vnstock_data.ui.domains.market.forex import ForexMarket
        return ForexMarket(symbol, **kwargs)

    def commodity(self, symbol: str, **kwargs) -> 'CommodityMarket':
        """Access commodity market data (e.g., 'GC=F')."""
        from vnstock_data.ui.domains.market.commodity import CommodityMarket
        return CommodityMarket(symbol, **kwargs)

    def quote(self, symbols_list: List[str], **kwargs) -> pd.DataFrame:
        """
        Real-time multi-symbol pricing snapshot.
        """
        domain = BaseDomain("market.market_wide", MARKET_SOURCES)
        kwargs["symbols_list"] = symbols_list
        kwargs["get_all"] = True
        return domain._dispatch("quote", **kwargs)

    def price_board(self, symbols_list: List[str], **kwargs) -> pd.DataFrame:
        """
        [Backward Compatible Alias] Relays to `.quote()`.
        Provides real-time multi-symbol pricing snapshot.
        """
        return self.quote(symbols_list, **kwargs)
