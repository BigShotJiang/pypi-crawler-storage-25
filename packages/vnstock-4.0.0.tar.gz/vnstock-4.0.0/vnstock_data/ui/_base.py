"""
Base classes for UI domains and details.
"""

from typing import Optional, Any, Dict, List
import pandas as pd
from vnstock_data.core.registry import ProviderRegistry
from vnstock_data.ui._registry import REFERENCE_SOURCES, MARKET_SOURCES, FUNDAMENTAL_SOURCES

class BaseDomain:
    """
    Abstract base class for domain objects (e.g., Equity, Industry).
    Handles dispatching calls to the registered data provider.
    """
    def __init__(self, domain_name: str, layer_sources: Dict):
        self._domain_name = domain_name
        self._sources_config = layer_sources

    def _dispatch(self, method_name: str, **kwargs) -> pd.DataFrame:
        """
        Dispatches a method call to the underlying provider.
        """
        from vnstock_data.ui.config import get_route
        
        # Get route (checks overrides first, then defaults)
        source_name, module_name, class_name, provider_method = get_route(
            self._domain_name, method_name, self._sources_config
        )
        
        # Ensure the underlying module is imported so it registers itself natively
        from vnstock_data.core.registry import ProviderRegistry
        if not ProviderRegistry.is_registered(module_name, source_name):
            import importlib
            try:
                importlib.import_module(f"vnstock_data.explorer.{source_name}.{module_name}")
            except ImportError:
                pass
                
        # Resolve the provider class using the registry
        provider_cls = ProviderRegistry.get(module_name, source_name)
        if not provider_cls:
             # Fallback or error if not found in registry (though it should be if registered)
             # NOTE: vnstock_data registry might store by (category, source) or similar.
             # Checking vnstock_data/core/registry.py usage: ProviderRegistry.register('company', 'vci', Company)
             # So we need to know the 'category' used in registration.
             # In _registry.py we stored ("vci", "company", "Company", "overview")
             # where "company" is the category/module name in registry terms.
             provider_cls = ProviderRegistry.get(module_name, source_name)
        
        if not provider_cls:
            raise ValueError(f"Provider not found for {source_name}.{module_name}")

        # Instantiate provider. 
        # BaseDomain providers (like Listing) typically use default args or configured defaults.
        # We do NOT pass kwargs to __init__ as they are meant for the method.
        # If we need to configure the provider, we should do it via separate init args.
        try:
            provider_instance = provider_cls() 
        except TypeError:
            # If provider requires args, we might need a more sophisticated factory or config
             # For now, most listing providers don't strictly require args
             # But if they do, we might need to handle it.
             # Let's try to inspect signature? No, let's just default to empty for now.
             provider_instance = provider_cls()
        
        # Call the method
        if not hasattr(provider_instance, provider_method):
            raise AttributeError(f"Provider {class_name} has no method {provider_method}")
            
        method = getattr(provider_instance, provider_method)
        
        # Filter kwargs to only include arguments accepted by the method
        import inspect
        sig = inspect.signature(method)
        params = sig.parameters
        
        # Check if method accepts **kwargs
        has_kwargs = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values())
        
        if not has_kwargs:
            # Filter to only accepted named arguments
            kwargs = {k: v for k, v in kwargs.items() if k in params}
            
        result = method(**kwargs)
        
        # Standardize result (International Standard)
        key = f"{self._domain_name}.{method_name}"
        from vnstock_data.ui.schemas import standardize_columns
        result = standardize_columns(result, key, source_name, strict=True)
        
        return result


class BaseDetail:
    """
    Abstract base class for symbol-specific detailed views (e.g., Company Profile).
    """
    def __init__(self, symbol: str, domain_name: str, layer_sources: Dict, **kwargs):
        self.symbol = symbol
        self._domain_name = domain_name
        self._sources_config = layer_sources
        self._kwargs = kwargs

    def _dispatch(self, method_name: str, **kwargs) -> pd.DataFrame:
        """
        Dispatches a method call to the underlying provider for a specific symbol.
        """
        from vnstock_data.ui.config import get_route
        
        # Get route (checks overrides first, then defaults)
        source_name, module_name, class_name, provider_method = get_route(
            self._domain_name, method_name, self._sources_config
        )
        
        # Ensure the underlying module is imported so it registers itself natively
        from vnstock_data.core.registry import ProviderRegistry
        if not ProviderRegistry.is_registered(module_name, source_name):
            import importlib
            try:
                importlib.import_module(f"vnstock_data.explorer.{source_name}.{module_name}")
            except ImportError:
                pass
                
        # Resolve provider
        provider_cls = ProviderRegistry.get(module_name, source_name)
        if not provider_cls:
            raise ValueError(f"Provider not found for {source_name}.{module_name}")

        # Instantiate provider with symbol
        # Assuming Detail providers (like Company) take symbol as first arg in __init__
        try:
            provider_instance = provider_cls(symbol=self.symbol, **self._kwargs)
        except TypeError:
            # Fallback for providers that might not take symbol in init or kwargs
            try:
                provider_instance = provider_cls(symbol=self.symbol)
            except TypeError:
                provider_instance = provider_cls(self.symbol)

        if not hasattr(provider_instance, provider_method):
            raise AttributeError(f"Provider {class_name} has no method {provider_method}")
            
        method = getattr(provider_instance, provider_method)
        
        # Filter kwargs to only include arguments accepted by the method
        import inspect
        sig = inspect.signature(method)
        params = sig.parameters
        
        # Check if method accepts **kwargs
        has_kwargs = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values())
        
        if not has_kwargs:
            # Filter to only accepted named arguments
            kwargs = {k: v for k, v in kwargs.items() if k in params}
            
        result = method(**kwargs)
        
        # Standardize result (International Standard)
        key = f"{self._domain_name}.{method_name}"
        from vnstock_data.ui.schemas import standardize_columns
        result = standardize_columns(result, key, source_name, strict=True)
        
        return result
