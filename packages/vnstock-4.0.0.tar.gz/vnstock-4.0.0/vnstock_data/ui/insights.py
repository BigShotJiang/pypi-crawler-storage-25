"""
Insights Module Entry Point (Layer 7).
Acts as the central orchestrator for analytical insights.
"""

from vnstock_data.ui.domains.insights.ranking import RankingReference
from vnstock_data.ui.domains.insights.screener import ScreenerReference
class Insights:
    """
    Central API Gateway for Layer 4 - Insights & Analytics (Unified UI).
    Provides market ranking, valuation multiples, and analytical insights.
    
    ✅ METHODS AVAILABLE (7 total across 1 domain):
    
    Ranking Domain (7 methods) - Market top movers:
        - gainer()        - Top stocks with highest price increase
        - loser()         - Top stocks with highest price decrease
        - value()         - Top stocks by trading value
        - volume()        - Top stocks by volume spikes
        - deal()          - Top stocks by put-through/deal volume
        - foreign_buy()   - Top stocks by foreign net buy value
        - foreign_sell()  - Top stocks by foreign net sell value
    
    Example:
        ins = Insights()
        
        # Ranking methods
        gainers = ins.ranking().gainer(index='VNINDEX', limit=10)
        volume_movers = ins.ranking().volume(index='VNINDEX', limit=10)
    """
    
    def ranking(self) -> RankingReference:
        """
        Access market ranking metrics - Top movers by various criteria (Insights Layer).
        
        Methods available (7 total):
            - gainer(index, limit)      - Top gainers
            - loser(index, limit)       - Top losers
            - value(index, limit)       - Top by trading value
            - volume(index, limit)      - Top by volume spikes
            - deal(index, limit)        - Top by put-through volume
            - foreign_buy(date, limit)  - Top by foreign net buy
            - foreign_sell(date, limit) - Top by foreign net sell
        
        Returns:
            RankingReference: Domain gateway providing top movers
        """
        return RankingReference()
        
    def screener(self) -> ScreenerReference:
        """
        Access stock screener functionality (Insights Layer).
        
        Returns:
            ScreenerReference: Domain gateway providing stock screening tools
        """
        return ScreenerReference()
