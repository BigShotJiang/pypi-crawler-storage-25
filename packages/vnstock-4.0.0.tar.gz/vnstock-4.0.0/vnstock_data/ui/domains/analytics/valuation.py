"""
Valuation Domain (Insights Layer).
"""

import pandas as pd
from vnstock_data.ui._base import BaseDomain
from vnstock_data.ui.schemas.core import standardize_columns
from vnstock_data.ui._registry import INSIGHTS_SOURCES

class MarketValuation(BaseDomain):
    """
    Market Valuation Insights.
    Wraps provider methods (like vnd.market.Market) to provide
    historical P/E and P/B ratios for an index.
    """
    def __init__(self, index: str = "VNINDEX"):
        super().__init__(domain_name="insights.valuation", layer_sources=INSIGHTS_SOURCES)
        self.index = index

    def _dispatch_custom(self, method_name: str, **kwargs) -> pd.DataFrame:
        """
        Custom dispatch to inject the index parameter during initialization
        for providers that require it (like vnd.market.Market).
        """
        from vnstock_data.ui.config import get_route
        from vnstock_data.core.registry import ProviderRegistry
        import importlib
        
        source_name, module_name, class_name, provider_method = get_route(
            self._domain_name, method_name, self._sources_config
        )
        
        if not ProviderRegistry.is_registered(module_name, source_name):
            try:
                importlib.import_module(f"vnstock_data.explorer.{source_name}.{module_name}")
            except ImportError:
                pass
                
        provider_cls = ProviderRegistry.get(module_name, source_name)
        if not provider_cls:
            raise ValueError(f"Provider not found for {source_name}.{module_name}")

        provider_instance = provider_cls(index=self.index)
        method = getattr(provider_instance, provider_method)
        df = method(**kwargs)
        
        return standardize_columns(df, f"{self._domain_name}.{method_name}", source_name, strict=True)

    def pe(self, duration: str = '5Y', **kwargs) -> pd.DataFrame:
        """Retrieves P/E (Price-to-Earnings) ratio data."""
        return self._dispatch_custom("pe", duration=duration, **kwargs)

    def pb(self, duration: str = '5Y', **kwargs) -> pd.DataFrame:
        """Retrieves P/B (Price-to-Book) ratio data."""
        return self._dispatch_custom("pb", duration=duration, **kwargs)

    def evaluation(self, duration: str = '5Y', **kwargs) -> pd.DataFrame:
        """Retrieves an overview of the market with both P/E and P/B ratios."""
        return self._dispatch_custom("evaluation", duration=duration, **kwargs)
