"""
Fund Reference Domain (Layer 1).
Wraps the `fmarket.fund` module for global fund operations like listing.
"""

import pandas as pd
from vnstock_data.ui._base import BaseDomain
from vnstock_data.ui._registry import REFERENCE_SOURCES
from vnstock_data.ui.schemas.core import standardize_columns

class FundReference(BaseDomain):
    """
    Access point for listing mutual funds.
    """

    def __init__(self):
        super().__init__(domain_name="reference.fund", layer_sources=REFERENCE_SOURCES)

    def list(self) -> pd.DataFrame:
        """
        Extracts the list of all available mutual funds.
        """
        df = self._dispatch("list")
        if df is None or df.empty:
            return pd.DataFrame()

        from vnstock_data.ui.config import get_route
        source_name, _, _, _ = get_route(self._domain_name, "list", self._sources_config)
        return standardize_columns(df, f"{self._domain_name}.list", source_name, strict=True)
