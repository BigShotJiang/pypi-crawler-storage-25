"""
Warrant domain reference structure.
"""
import pandas as pd
from vnstock_data.ui._base import BaseDetail, BaseDomain
from vnstock_data.ui._registry import REFERENCE_SOURCES

class WarrantReference(BaseDetail):
    """
    Reference Data Layer for Covered Warrants.
    """
    def __init__(self, symbol: str = None):
        if symbol is None:
            super().__init__("WARRANT", "derivatives.warrant", REFERENCE_SOURCES)
            self._is_listing = True
        else:
            super().__init__(symbol, "derivatives.warrant", REFERENCE_SOURCES)
            self._is_listing = False

    def list(self) -> pd.DataFrame:
        """
        List all available covered warrants.
        """
        domain = BaseDomain("derivatives.warrant", REFERENCE_SOURCES)
        return domain._dispatch("list")

    def info(self) -> pd.DataFrame:
        """
        Get info and realtime information for the specific covered warrant.
        
        Returns:
            pd.DataFrame: A standardized dataframe with warrant details.
        """
        return self._dispatch("info")

class FuturesReference(BaseDetail):
    """
    Reference Data Layer for Index Futures.
    """
    def __init__(self, symbol: str = None):
        # If symbol is provided, it's symbol-specific profile
        # If symbol is None, it's for listing all futures (called from Reference.futures())
        if symbol is None:
            # Listing mode - use dummy symbol
            super().__init__("FUTURES", "derivatives.futures", REFERENCE_SOURCES)
            self._is_listing = True
        else:
            # Symbol-specific mode (e.g., reference.futures('VN30F2503').profile())
            super().__init__(symbol, "derivatives.futures", REFERENCE_SOURCES)
            self._is_listing = False
        
    def list(self) -> pd.DataFrame:
        """
        List all available futures indices with metadata.
        
        Returns:
            DataFrame with futures information
        """
        # Create a temporary BaseDomain to dispatch
        domain = BaseDomain("derivatives.futures", REFERENCE_SOURCES)
        return domain._dispatch("list")
        
    def info(self) -> pd.DataFrame:
        """
        Get info and realtime information for the specific index future.
        """
        return self._dispatch("info")

class DerivativesReference:
    """
    Derivatives domain wrapper containing Futures and Warrants.
    """
    def warrant(self, symbol: str = None) -> WarrantReference:
        """
        Access covered warrant profile and reference data.
        
        Args:
            symbol (str, optional): Warrant symbol (e.g., 'CACB2511').
        """
        return WarrantReference(symbol)

    def futures(self, symbol: str = None) -> FuturesReference:
        """
        Access index futures profile and reference data.
        
        Args:
            symbol (str, optional): Future symbol (e.g., 'VN30F2503').
        """
        return FuturesReference(symbol)
