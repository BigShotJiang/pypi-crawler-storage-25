"""
Company Reference Domain.
"""

from typing import Optional
import pandas as pd
from vnstock_data.ui._base import BaseDetail
from vnstock_data.ui._registry import REFERENCE_SOURCES

class CompanyReference(BaseDetail):
    """
    Company Reference Data (Layer 1).
    Wraps functionality for retrieving company-specific static data.
    """
    def __init__(self, symbol: str):
        super().__init__(symbol=symbol, domain_name="company", layer_sources=REFERENCE_SOURCES)

    def info(self) -> pd.DataFrame:
        """Get company info/overview."""
        return self._dispatch("info")

    def shareholders(self) -> pd.DataFrame:
        """Get company shareholders."""
        return self._dispatch("shareholders")

    def officers(self, filter_by: str = 'working') -> pd.DataFrame:
        """
        Get company officers.
        
        Args:
            filter_by (str): 'working', 'resigned', or 'all'. Default 'working'.
        """
        return self._dispatch("officers", filter_by=filter_by)

    def subsidiaries(self, filter_by: str = 'all') -> pd.DataFrame:
        """
        Get company subsidiaries.
        
        Args:
             filter_by (str): 'all', 'subsidiary', 'affiliate'. Default 'all'.
        """
        return self._dispatch("subsidiaries", filter_by=filter_by)

    def news(self) -> pd.DataFrame:
        """Get company news."""
        return self._dispatch("news")

    def events(self) -> pd.DataFrame:
        """Get company events."""
        return self._dispatch("events")

    def margin_ratio(self) -> pd.DataFrame:
        """Get margin lending ratio for the company across brokers."""
        return self._dispatch("margin_ratio")
