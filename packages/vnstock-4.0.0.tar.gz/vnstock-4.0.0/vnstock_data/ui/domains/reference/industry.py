"""
Industry Reference Domain.
"""

import pandas as pd
from vnstock_data.ui._base import BaseDomain
from vnstock_data.ui._registry import REFERENCE_SOURCES

class IndustryReference(BaseDomain):
    """
    Industry Reference Data (Layer 1).
    """
    def __init__(self):
        super().__init__(domain_name="industry", layer_sources=REFERENCE_SOURCES)

    def list(self, lang: str = 'vi') -> pd.DataFrame:
        """
        List ICB industry classifications for all symbols in the market.
        Uses VCI as the data source over KBS because VCI provides deeper ICB levels (up to 4 levels).
        
        Note: The underlying data source may not be available in all environments 
        (e.g., might be blocked on Google Colab).
        
        Args:
            lang (str): Language code 'vi' or 'en'. Default 'vi'.
        """
        df = self._dispatch("list")
        
        if lang == 'vi':
            if 'en_icb_name' in df.columns:
                df = df.drop(columns=['en_icb_name'])
        elif lang == 'en':
            if 'icb_name' in df.columns:
                df = df.drop(columns=['icb_name'])
                
        return df

    def sectors(self, icb_code: str = None, lang: str = 'vi') -> pd.DataFrame:
        """
        List all symbols by their industry sectors.
        
        Args:
            icb_code (str, optional): Filter by a specific ICB code.
            lang (str): Language code 'vi' or 'en'. Default 'vi'.
        """
        df = self._dispatch("sectors", lang=lang)
        if df is not None and not df.empty and icb_code is not None:
            df = df[df['icb_code'] == icb_code].reset_index(drop=True)
        return df
