"""
ETF Reference Domain (Layer 1).
"""

import pandas as pd
from vnstock_data.ui._base import BaseDomain
from vnstock_data.ui._registry import REFERENCE_SOURCES

class ETFReference(BaseDomain):
    """
    ETF Reference Data (Layer 1).
    """

    def __init__(self):
        super().__init__(domain_name="etf", layer_sources=REFERENCE_SOURCES)

    def list(self) -> pd.DataFrame:
        """
        List all Exchange-Traded Funds (ETFs) available in the market.
        """
        df = self._dispatch("list")
        if df is None or df.empty:
            return pd.DataFrame()
        return df
