"""
Search Reference Domain.
"""

from typing import Optional
import pandas as pd
from vnstock_data.ui._base import BaseDomain
from vnstock_data.ui._registry import REFERENCE_SOURCES

class SearchReference(BaseDomain):
    """
    Search Reference Data.
    Provides access to cross-domain search for symbols (stocks, crypto, forex, indices) globally.
    """
    def __init__(self):
        super().__init__(domain_name="search", layer_sources=REFERENCE_SOURCES)

    def symbol(self, query: str, locale: Optional[str] = None, limit: Optional[int] = 10) -> pd.DataFrame:
        """
        Retrieves a list of symbols from the market matching the query.
        Backed by FXSB Listing to find global financial instruments.
        
        Args:
            query (str): Search keyword to find the symbol.
            locale (str, optional): Target language/locale to filter results (e.g., 'vi-vn', 'en-us').
            limit (int, optional): Max number of results. Defaults to 10.
            
        Returns:
            pd.DataFrame: List of matched symbols and their descriptions.
        """
        return self._dispatch("symbol", query=query, locale=locale, limit=limit)

    def info(self, query: str, locale: Optional[str] = None, limit: Optional[int] = 10) -> pd.DataFrame:
        """
        Retrieves detailed global asset information directly via MSN logic to support deep lookup.
        
        Args:
            query (str): Search keyword to find the symbol metadata.
            locale (str, optional): Target language/locale to filter results.
            limit (int, optional): Max number of results. Defaults to 10.
            
        Returns:
            pd.DataFrame: List of matched assets and full descriptions.
        """
        return self._dispatch("info", query=query, locale=locale, limit=limit)
