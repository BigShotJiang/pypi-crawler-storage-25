"""
Index Reference Domain.
"""
from typing import Dict, Any, Optional

import pandas as pd
from vnstock_data.ui._base import BaseDomain
from vnstock_data.ui._registry import REFERENCE_SOURCES

class IndexDetail:
    """
    Detailed information for a specific index.
    """
    def __init__(self, index_symbol: str, sources_config=None):
        self.symbol = index_symbol
        self._sources_config = sources_config
        # We need a domain to dispatch calls for IndexDetail
        self._domain = BaseDomain(domain_name="index", layer_sources=REFERENCE_SOURCES)
        self._domain._sources_config = self._sources_config

    def members(self) -> pd.Series:
        """
        List constituents/members of the index.
        """
        group = self.symbol.upper()
        if group == 'VNINDEX':
            group = 'HOSE'
        elif group == 'HNXINDEX':
            group = 'HNX'
        elif group == 'UPCOMINDEX':
            group = 'UPCOM'
            
        return self._domain._dispatch("members", group=group)
        
    def info(self) -> pd.DataFrame:
        """Get complete information for this index."""
        from vnstock.common import indices
        data = indices.get_index_info(self.symbol)
        if not data:
            return pd.DataFrame()
        return pd.DataFrame([data])
        
    def description(self) -> Optional[str]:
        """Get description for this index."""
        from vnstock.common import indices
        return indices.get_index_description(self.symbol)

class IndexReference(BaseDomain):
    """
    Index Reference Data (Layer 1).
    Acts as a Hub for index listings and navigating to specific index details.
    """
    def __init__(self):
        super().__init__(domain_name="index", layer_sources=REFERENCE_SOURCES)

    def __call__(self, symbol: str) -> IndexDetail:
        """
        Access details for a specific index.
        
        Args:
            symbol (str): Index symbol (e.g., 'VN30').
            
        Returns:
            IndexDetail: Object to access index-specific data.
        """
        return IndexDetail(symbol, self._sources_config)

    def groups(self) -> pd.DataFrame:
        """
        List all supported index groups and categories.
        """
        return self._dispatch("groups")

    def members(self, group: str) -> pd.Series:
        """
        List constituents/members of the specified index.
        
        Args:
            group (str): Index symbol (e.g., 'VN30').
        """
        return self(group).members()

    def list(self) -> pd.DataFrame:
        """
        List all standardized market indices with metadata.
        
        Returns:
            DataFrame with columns:
            - symbol: Index symbol (VN30, VNIT, etc.)
            - name: Index name
            - description: Vietnamese description
            - full_name: Full English name
            - group: Index group (HOSE Indices, Sector Indices, etc.)
            - index_id: Unique index ID
            - sector_id: ICB sector ID (for sector indices only)
        """
        from vnstock.common import indices as market_indices
        return market_indices.get_all_indices()
    
    def list_by_group(self, group: str = 'VN30') -> pd.DataFrame:
        """
        List market indices by group/category.
        
        Args:
            group (str): Index group name (e.g., 'vn30', 'Hose'). Default 'VN30'.
        
        Returns:
            DataFrame with index information filtered by group.
        """
        from vnstock.common import indices as market_indices
        
        if isinstance(group, str):
            group_upper = group.upper().strip()
            
            # Try exact match first
            if group in market_indices.get_all_index_groups():
                return market_indices.get_indices_by_group(group)
                
            # Try substring match
            for g in market_indices.get_all_index_groups():
                if group_upper in g.upper():
                    return market_indices.get_indices_by_group(g)
                    
        return pd.DataFrame() # Return empty DataFrame if not found
