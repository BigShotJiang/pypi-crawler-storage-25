"""
Bond Reference Domain (Layer 1).
"""

import pandas as pd
from vnstock_data.ui._base import BaseDomain
from vnstock_data.ui._registry import REFERENCE_SOURCES

class BondReference(BaseDomain):
    """
    Bond Reference Data (Layer 1).
    """

    def __init__(self):
        super().__init__(domain_name="bond", layer_sources=REFERENCE_SOURCES)

    def list(self, bond_type: str = 'all'):
        """
        List bonds available in the market.
        
        Args:
            bond_type (str): Type of bond to filter ('all', 'corporate', 'government'). Default is 'all'.
                             - If 'corporate' or 'government', returns a pandas Series of symbols.
                             - If 'all', returns a pandas DataFrame with 'symbol' and 'type' columns.
                             
        Note: The government bond data source might be restricted in some environments (e.g., Google Colab).
        """
        import logging
        valid_types = ['all', 'corporate', 'government']
        if bond_type not in valid_types:
            raise ValueError(f"Invalid bond_type: {bond_type}. Must be one of {valid_types}.")
            
        if bond_type == 'corporate':
            return self._dispatch("corporate")
        elif bond_type == 'government':
            return self._dispatch("government")
            
        # If 'all', combine both
        corp = self._dispatch("corporate")
        
        try:
            gov = self._dispatch("government")
        except Exception as e:
            logging.warning(f"Could not fetch government bonds (source may be blocked): {e}")
            gov = pd.Series(dtype='object')
            
        df_corp = pd.DataFrame({'symbol': corp, 'type': 'corporate'}) if getattr(corp, 'empty', True) is False else pd.DataFrame(columns=['symbol', 'type'])
        df_gov = pd.DataFrame({'symbol': gov, 'type': 'government'}) if getattr(gov, 'empty', True) is False else pd.DataFrame(columns=['symbol', 'type'])
        
        return pd.concat([df_corp, df_gov], ignore_index=True)
