"""
Market Reference domain.
"""

import pandas as pd
from typing import Optional
from vnstock_data.ui._base import BaseDomain
from vnstock_data.ui._registry import REFERENCE_SOURCES

class MarketReference(BaseDomain):
    """
    Market Reference Data.
    Provides access to live market status.
    """
    def __init__(self):
        super().__init__(domain_name="market", layer_sources=REFERENCE_SOURCES)

    def status(self, **kwargs) -> pd.DataFrame:
        """
        Retrieve live stock market status (OPEN, CLOSED, ATO, ATC, etc.)
        from the default data source.
        
        Returns:
            pd.DataFrame: Live market status for various exchanges.
        """
        return self._dispatch("status", **kwargs)
