"""
Events Reference domain.
"""

from typing import Optional
import pandas as pd
from vnstock_data.ui._base import BaseDomain
from vnstock_data.ui._registry import REFERENCE_SOURCES

class EventsReference(BaseDomain):
    """
    Events Reference Data.
    Provides access to market events, news, and other time-bound occurrences.
    """
    def __init__(self):
        super().__init__(domain_name="events", layer_sources=REFERENCE_SOURCES)

    def calendar(self, start: Optional[str] = None, end: Optional[str] = None, 
                 event_type: Optional[str] = None,
                 page: int = 0, limit: int = 20000) -> pd.DataFrame:
        """
        Retrieve events calendar (dividends, AGM, new listings, ...) from the default data source.
        
        Args:
            start (str, optional): Start date (YYYY-MM-DD). Defaults to the current date.
            end (str, optional): End date (YYYY-MM-DD). Defaults to the current date.
            event_type (str, optional): Type of event or event group:
                - 'dividend': Returns dividends, share issuance
                - 'insider': Returns insider trading, major shareholders
                - 'agm': Returns shareholder meetings
                - 'others': Returns other fluctuations
                - Or a specific eventCode (e.g., 'ISS,DIV')
            page (int): Page index. Defaults to 0.
            limit (int): Number of records per page. Defaults to 20000.
            
        Returns:
            pd.DataFrame: Standardized list of events.
        """
        return self._dispatch("calendar", start=start, end=end, event_type=event_type, page=page, limit=limit)

    def market(self, start: Optional[str] = None, end: Optional[str] = None, 
               event_type: Optional[str] = None) -> pd.DataFrame:
        """
        Retrieve special stock market events (holidays, system incidents, ...)
        
        Uses a static internal database from the vnstock library.
        
        Args:
            start (str, optional): Start date (YYYY-MM-DD). Defaults to all events.
            end (str, optional): End date (YYYY-MM-DD). Defaults to all events.
            event_type (str, optional): Event type ('Holiday', 'Suspension', 'Compensation').
            
        Returns:
            pd.DataFrame: List of market events.
        """
        # Attempt to import MARKET_EVENTS from vnstock core utils
        # User renamed module to market_events (preferred)
        market_events_dict = {}
        try:
            from vnstock.core.utils import market_events
            market_events_dict = getattr(market_events, 'MARKET_EVENTS', {})
        except ImportError:
            # Fallback for older versions or if standard import fails
            try:
                import importlib
                # Try new name via importlib
                market_events_mod = importlib.import_module('vnstock.core.utils.market_events')
                market_events_dict = getattr(market_events_mod, 'MARKET_EVENTS', {})
            except ImportError:
                # Try old hyphenated name as last resort
                try:
                    market_events_mod = importlib.import_module('vnstock.core.utils.market-events')
                    market_events_dict = getattr(market_events_mod, 'MARKET_EVENTS', {})
                except ImportError:
                    # Final manual fallback attempt
                    import sys
                    import os
                    try:
                        import vnstock
                        utils_dir = os.path.join(os.path.dirname(vnstock.__file__), 'core', 'utils')
                        # Try both filenames
                        for fname in ['market_events.py', 'market-events.py']:
                            market_events_path = os.path.join(utils_dir, fname)
                            if os.path.exists(market_events_path):
                                import importlib.util
                                spec = importlib.util.spec_from_file_location("market_events_ext", market_events_path)
                                module = importlib.util.module_from_spec(spec)
                                spec.loader.exec_module(module)
                                market_events_dict = getattr(module, 'MARKET_EVENTS', {})
                                break
                    except Exception as e:
                        from vnstock.core.utils.logger import get_logger
                        logger = get_logger(__name__)
                        logger.warning(f"Failed to load market events: {str(e)}. Please ensure you have vnstock v3.4.3+ installed.")
                        pass
                
        if not market_events_dict:
            return pd.DataFrame()
            
        # Convert dictionary to List of records for pandas DataFrame
        records = []
        for date_str, details in market_events_dict.items():
            record = {"date": date_str}
            record.update(details)
            records.append(record)
            
        df = pd.DataFrame(records)
        
        # Apply standard schema renaming
        from vnstock_data.ui._registry import REFERENCE_SOURCES
        from vnstock_data.ui._base import BaseDomain
        
        # We manually apply standard columns to match the architecture style
        from vnstock_data.ui.schemas.events import SCHEMA_MAP, STANDARD_COLUMNS
        schema = SCHEMA_MAP.get("events.market", {}).get("vnstock", {})
        stand_cols = STANDARD_COLUMNS.get("events.market", [])
        
        if not df.empty and schema:
            df.rename(columns=schema, inplace=True)
            
        # Ensure standard columns exist with NaN if missing
        for col in stand_cols:
            if col not in df.columns:
                df[col] = pd.NA
                
        # Filter columns
        df = df[stand_cols]
        
        # Apply start, end, event_type filtering
        if not df.empty:
            df['date'] = pd.to_datetime(df['date'])
            
            if start:
                try:
                    df = df[df['date'] >= pd.to_datetime(start)]
                except Exception:
                    pass
            if end:
                try:
                    df = df[df['date'] <= pd.to_datetime(end)]
                except Exception:
                    pass
            if event_type:
                df = df[df['event_type'].str.lower() == event_type.lower()]
                
            # Convert date back to string format if desired or keep as datetime
            # Leaving as datetime64[ns] to be consistent with calendar() refinement
            
        return df.reset_index(drop=True)
