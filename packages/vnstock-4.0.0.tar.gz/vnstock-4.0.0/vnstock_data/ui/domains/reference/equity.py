"""
Equity Reference Domain.
"""

import pandas as pd
from vnstock_data.ui._base import BaseDomain
from vnstock_data.ui._registry import REFERENCE_SOURCES

class EquityReference(BaseDomain):
    """
    Equity Reference Data (Layer 1).
    """
    def __init__(self):
        super().__init__(domain_name="equity", layer_sources=REFERENCE_SOURCES)

    def list(self) -> pd.DataFrame:
        """List all equity symbols."""
        return self._dispatch("list")

    def list_by_group(self, group: str) -> pd.DataFrame:
        """
        List equities by group (e.g., VN30, HOSE).
        
        Args:
            group (str): Group code (VN30, HOSE, HNX, etc.)
        """
        return self._dispatch("by_group", group=group)
    def list_by_industry(self, icb_code: str = None, lang: str = 'vi') -> pd.DataFrame:
        """
        List equities by industry (ICB classification).
        
        Args:
            icb_code (str, optional): The ICB code to filter by (e.g., '8773'). If None, returns all.
            lang (str): Language ('vi' or 'en'). Default 'vi'.
            
        Returns:
            DataFrame: List of symbols related to the industry with ICB info.
        """
        df = self._dispatch("by_industry", lang=lang)
        if df is not None and not df.empty and icb_code is not None:
            df = df[df['icb_code'] == icb_code].reset_index(drop=True)
        return df

    # Backward compatibility alias
    def by_group(self, group: str) -> pd.DataFrame:
        """[DEPRECATED] Use list_by_group() instead."""
        return self.list_by_group(group)

    def list_by_exchange(self) -> pd.DataFrame:
        """List all equities organized by exchange."""
        return self._dispatch("by_exchange")
    
    # Backward compatibility alias
    def by_exchange(self) -> pd.DataFrame:
        """[DEPRECATED] Use list_by_exchange() instead."""
        return self.list_by_exchange()
