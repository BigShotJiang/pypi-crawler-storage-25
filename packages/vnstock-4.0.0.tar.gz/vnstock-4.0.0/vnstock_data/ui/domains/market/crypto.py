"""
Crypto Market Data Domain.
"""

import pandas as pd
from vnstock_data.ui.domains.market.base import BaseMarketData
from vnstock_data.ui._registry import MARKET_SOURCES


class CryptoMarket(BaseMarketData):
    """
    Crypto Market Data (Layer 2) – Unified UI interface for cryptocurrency.

    Core methods (inherited from BaseMarketData, shared schema with all asset classes):
    ──────────────────────────────────────────────────────────────────────────────────
    ohlcv(interval, limit, mode)   OHLCV bars; mode=None (default, chart-opt) or 'raw'
    trades(limit, mode)            Time & Sales; mode='raw' (default) or 'aggregate'
    order_book(limit)              L2 Market Depth (bid/ask levels)
    quote()                        24-hour rolling quote snapshot

    Extended methods (Crypto-specific, universal naming):
    ─────────────────────────────────────────────────────
    trade_history   → GET /api/v3/historicalTrades (older trades by ID)
    vwap            → GET /api/v3/avgPrice         (volume-weighted avg price)
    daily_stats     → GET /api/v3/ticker/tradingDay(trading-day session stats)
    last_price      → GET /api/v3/ticker/price     (last traded price, LTP)
    rolling_stats   → GET /api/v3/ticker           (rolling-window statistics)
    reference_price(mode)
        mode='price' → GET /api/v3/referencePrice
        mode='calc'  → GET /api/v3/referencePrice/calculation
    """

    # session_stats / trading_stats not applicable for crypto
    session_stats = None
    trading_stats = None

    def __init__(self, symbol: str, **kwargs):
        super().__init__(symbol=symbol, domain_name="market.crypto", layer_sources=MARKET_SOURCES, **kwargs)

    # Override trades to expose the mode parameter
    def trades(self, limit: int = 500, mode: str = "raw", **kwargs) -> pd.DataFrame:
        """
        Tick-by-tick trade tape (Time & Sales).

        Args:
            limit (int): Number of records (default 500, max 1000).
            mode (str):
                - ``'raw'`` (default) – individual fills. Binance: ``GET /api/v3/trades``
                - ``'aggregate'`` – compressed fills (same price & direction merged).
                  Binance: ``GET /api/v3/aggTrades``

        Returns:
            pd.DataFrame: Schema ``[time, price, volume, side, match_type, id]``
        """
        return self._dispatch("trades", limit=limit, mode=mode, **kwargs)

    # ── Extended ──────────────────────────────────────────────────────────

    def trade_history(self, **kwargs) -> pd.DataFrame:
        """Historical trade look-up by ID. Binance: ``GET /api/v3/historicalTrades``"""
        return self._dispatch("trade_history", **kwargs)

    def vwap(self, **kwargs) -> pd.DataFrame:
        """Volume-Weighted Average Price. Binance: ``GET /api/v3/avgPrice``"""
        return self._dispatch("vwap", **kwargs)

    def daily_stats(self, **kwargs) -> pd.DataFrame:
        """Trading-day session statistics. Binance: ``GET /api/v3/ticker/tradingDay``"""
        return self._dispatch("daily_stats", **kwargs)

    def last_price(self, **kwargs) -> pd.DataFrame:
        """Last Traded Price (LTP). Binance: ``GET /api/v3/ticker/price``"""
        return self._dispatch("last_price", **kwargs)

    def rolling_stats(self, **kwargs) -> pd.DataFrame:
        """Rolling-window price-change statistics. Binance: ``GET /api/v3/ticker``"""
        return self._dispatch("rolling_stats", **kwargs)

    def reference_price(self, mode: str = "price", **kwargs) -> pd.DataFrame:
        """
        Reference / indicative price.

        Args:
            mode (str):
                - ``'price'`` (default) – reference price. Binance: ``GET /api/v3/referencePrice``
                - ``'calc'`` – calculation breakdown. Binance: ``GET /api/v3/referencePrice/calculation``

        Note: Returns empty DataFrame if symbol has no reference price.
        """
        return self._dispatch("reference_price", mode=mode, **kwargs)
