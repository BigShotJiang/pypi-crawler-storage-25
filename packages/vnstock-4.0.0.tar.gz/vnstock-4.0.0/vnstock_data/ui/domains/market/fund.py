"""
Fund Market Domain (Layer 2).
Wraps the `fmarket.fund` module for NAV history and portfolio holdings.
"""

import pandas as pd
from vnstock_data.ui._base import BaseDetail
from vnstock_data.ui._registry import MARKET_SOURCES
from vnstock_data.ui.schemas.core import standardize_columns

class FundMarket(BaseDetail):
    """
    Access point for fetching a specific fund's historical data and portfolio details.
    """

    def __init__(self, symbol: str):
        super().__init__(symbol=symbol, domain_name="market.fund", layer_sources=MARKET_SOURCES)

    def _dispatch_and_format(self, method_name: str, **kwargs) -> pd.DataFrame:
        df = self._dispatch(method_name, **kwargs)
        if df.empty:
            return df
            
        from vnstock_data.ui.config import get_route
        source_name, _, _, _ = get_route(self._domain_name, method_name, self._sources_config)
        
        base_domain = "market.fund"
        # We use strict=False to ensure we don't accidentally drop crucial details 
        # but the schema will still rename `date` -> `report_time` if configured
        return standardize_columns(df, f"{base_domain}.{method_name}", source_name, strict=False)

    def history(self, **kwargs) -> pd.DataFrame:
        """
        Extracts the historical Net Asset Value (NAV) of the fund over time.
        """
        return self._dispatch_and_format("history", **kwargs)

    def top_holding(self, **kwargs) -> pd.DataFrame:
        """
        Extracts the top equity/bond holdings of the fund.
        """
        return self._dispatch_and_format("top_holding", **kwargs)

    def industry_holding(self, **kwargs) -> pd.DataFrame:
        """
        Extracts the industry weighting inside the fund's portfolio.
        """
        return self._dispatch_and_format("industry_holding", **kwargs)

    def asset_holding(self, **kwargs) -> pd.DataFrame:
        """
        Extracts the asset allocation (Equities vs Cash/Bonds) of the fund.
        """
        return self._dispatch_and_format("asset_holding", **kwargs)
