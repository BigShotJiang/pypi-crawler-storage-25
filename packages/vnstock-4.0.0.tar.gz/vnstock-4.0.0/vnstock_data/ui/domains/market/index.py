"""
Index Market Data Domain.
"""

from vnstock_data.ui.domains.market.base import BaseMarketData
from vnstock_data.ui._registry import MARKET_SOURCES
import pandas as pd

class IndexMarket(BaseMarketData):
    """
    Index Market Data (Layer 2).
    """
    # Unsupported for indices
    trades = None
    intraday = None
    order_book = None
    price_depth = None
    def __init__(self, symbol: str, **kwargs):
        scope = kwargs.pop("scope", "")
        sources_config = MARKET_SOURCES.copy()
        if scope == "global":
            sources_config["market.index"] = {
                "ohlcv":    ("dukascopy", "quote", "Quote", "history"),
                "intraday": ("dukascopy", "quote", "Quote", "intraday"),
            }
        super().__init__(symbol=symbol, domain_name="market.index", layer_sources=sources_config, **kwargs)

    def trade_history(self, **kwargs) -> pd.DataFrame:
        """
        Historical trading statistics (price, volume, value) for Indices.
        """
        return self._dispatch("price_history", **kwargs)
