from vnstock_data.ui.domains.market.base import BaseMarketData
from vnstock_data.ui._registry import MARKET_SOURCES

class ETFMarket(BaseMarketData):
    """
    Electronic Traded Funds (ETF) market data domain.
    Provides access to quotes, trades, and history for ETF symbols.
    """
    def __init__(self, symbol: str):
        super().__init__(symbol, "market.etf", MARKET_SOURCES)
