"""
Forex Market Data Domain.
"""

from vnstock_data.ui.domains.market.base import BaseMarketData
from vnstock_data.ui._registry import MARKET_SOURCES

class ForexMarket(BaseMarketData):
    """
    Forex Market Data (Layer 2).
    Provides access to historical pricing data for foreign exchange pairs via FXSB source.
    """
    # Unsupported for forex currently
    trades = None
    intraday = None
    order_book = None
    price_depth = None
    session_stats = None
    trading_stats = None

    def __init__(self, symbol: str, **kwargs):
        super().__init__(symbol=symbol, domain_name="market.forex", layer_sources=MARKET_SOURCES, **kwargs)
