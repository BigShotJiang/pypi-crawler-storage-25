"""
Derivatives Market Data Domain.
"""

from vnstock_data.ui.domains.market.base import BaseMarketData
from vnstock_data.ui._registry import MARKET_SOURCES

class FuturesMarket(BaseMarketData):
    """
    Futures Market Data (Layer 2).
    """
    # Unsupported for now
    session_stats = None

    def __init__(self, symbol: str):
        super().__init__(symbol=symbol, domain_name="market.futures", layer_sources=MARKET_SOURCES)

class WarrantMarket(BaseMarketData):
    """
    Warrant Market Data (Layer 2).
    """
    # Unsupported for now
    session_stats = None

    def __init__(self, symbol: str):
        super().__init__(symbol=symbol, domain_name="market.warrant", layer_sources=MARKET_SOURCES)

class DerivativesMarket:
    """
    Derivatives market wrapper containing Futures and Warrants.
    Provides nested access to derivatives market data.
    """
    def futures(self, symbol: str) -> FuturesMarket:
        """
        Access futures market data.
        
        Args:
            symbol (str): Futures symbol (e.g., 'VN30F2503', 'VN100F2503').
        """
        return FuturesMarket(symbol)

    def warrant(self, symbol: str) -> WarrantMarket:
        """
        Access warrant market data.
        
        Args:
            symbol (str): Warrant symbol (e.g., 'CACB2511', 'VICW-VIC26A').
        """
        return WarrantMarket(symbol=symbol)
