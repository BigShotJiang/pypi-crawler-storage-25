"""
Base classes for unified Market Data access (Layer 2).
Provides the universal market data namespace across all instrument types.
"""

from typing import Dict, Any, Optional, List
import pandas as pd
from vnstock_data.ui._base import BaseDetail

class BaseMarketData(BaseDetail):
    """
    Unified base class for fetching market data across all asset classes
    (Equity, Index, Futures, Warrant).
    
    Provides standardized methods aligned with international schemas
    (OHLCV, Time & Sales, Order Book, Quote Snapshots) while retaining
    familiar terminology for backward compatibility.
    """
    
    def ohlcv(self, **kwargs) -> pd.DataFrame:
        """
        Historical OHLCV bars.
        
        Args:
            start (str): Start date (YYYY-MM-DD). Optional if count_back is provided.
            end (str): End date (YYYY-MM-DD). Default is today.
            interval (str): Timeframe interval ('1D', '1W', '1M', '1m', '5m', '15m', '1H').
            count_back (int): Number of bars to fetch backward from end date.
            
        Returns:
            pd.DataFrame: OHLCV data adhering to `market.ohlcv` schema.
        """
        return self._dispatch("ohlcv", **kwargs)

    def history(self, **kwargs) -> pd.DataFrame:
        """
        [Backward Compatible Alias] Relays to `.ohlcv()`.
        Provides historical candlestick bars.
        """
        return self.ohlcv(**kwargs)

    def trades(self, limit: int = 1000, **kwargs) -> pd.DataFrame:
        """
        Real-time or intraday tick-by-tick trading tape (Time & Sales).
        
        Args:
            limit (int): Number of records to fetch (default: 1000).
            page (int): Page number (default: 1).
            get_all (bool): Fetch all available data (default: False).
            
        Returns:
            pd.DataFrame: Intraday ticks adhering to `market.trades` schema.
        """
        if "page_size" not in kwargs:
            kwargs["page_size"] = limit
        return self._dispatch("trades", **kwargs)

    def intraday(self, **kwargs) -> pd.DataFrame:
        """
        [Backward Compatible Alias] Relays to `.trades()`.
        Provides intraday tick-by-tick data.
        """
        return self.trades(**kwargs)

    def order_book(self, **kwargs) -> pd.DataFrame:
        """
        Order book levels (Best Bid/Ask L2/L3).
        
        Returns:
            pd.DataFrame: Order book adhering to `market.order_book` schema.
        """
        if "symbols_list" not in kwargs:
            kwargs["symbols_list"] = [self.symbol]
        return self._dispatch("order_book", **kwargs)

    def price_depth(self, **kwargs) -> pd.DataFrame:
        """
        [Backward Compatible Alias] Relays to `.order_book()`.
        Provides order book levels.
        """
        return self.order_book(**kwargs)

    def quote(self, **kwargs) -> pd.DataFrame:
        """
        Real-time single-symbol pricing snapshot.
        If the underlying provider expects `symbols_list`, it injects `[self.symbol]`.
        
        Returns:
            pd.DataFrame: Quote snapshot adhering to `market.quote` schema.
        """
        # Inject symbols_list if required by provider
        if "symbols_list" not in kwargs:
            kwargs["symbols_list"] = [self.symbol]
            
        kwargs["get_all"] = True
        return self._dispatch("quote", **kwargs)

    def price_board(self, **kwargs) -> pd.DataFrame:
        """
        [Backward Compatible Alias] Relays to `.quote()`.
        Provides real-time single-symbol pricing snapshot.
        """
        return self.quote(**kwargs)

    def session_stats(self, **kwargs) -> pd.DataFrame:
        """
        End-of-session aggregate statistics.
        
        Returns:
            pd.DataFrame: Session statistics.
        """
        return self._dispatch("session_stats", **kwargs)

    def trading_stats(self, **kwargs) -> pd.DataFrame:
        """
        [Backward Compatible Alias] Relays to `.session_stats()`.
        Provides end-of-session aggregate statistics.
        """
        return self.session_stats(**kwargs)

    def summary(self, **kwargs) -> pd.DataFrame:
        """
        Stock Info / Snapshot summary metrics including pricing, 
        52-week ranges, and fundamental ratios.

        Returns:
            pd.DataFrame: Snapshot metrics adhering to `market.summary` schema.
        """
        return self._dispatch("summary", **kwargs)
