"""
Equity Market Data Domain.
"""

import pandas as pd
from typing import Optional
from vnstock_data.ui.domains.market.base import BaseMarketData
from vnstock_data.ui._registry import MARKET_SOURCES

class EquityMarket(BaseMarketData):
    """
    Equity Market Data (Layer 2).
    Provides standard methods (history, intraday, price_depth, price_board)
    plus specialized flow and statistics models for Equities.
    """
    def __init__(self, symbol: str):
        super().__init__(symbol=symbol, domain_name="market.equity", layer_sources=MARKET_SOURCES)

    def foreign_flow(self, **kwargs) -> pd.DataFrame:
        """
        Historical or daily foreign buy/sell volume and value.
        """
        return self._dispatch("foreign_flow", **kwargs)

    def trade_history(self, **kwargs) -> pd.DataFrame:
        """
        Historical trading statistics (price, volume, value) for Equities.
        """
        return self._dispatch("price_history", **kwargs)

    def proprietary_flow(self, **kwargs) -> pd.DataFrame:
        """
        Trade data for proprietary desks (Tự doanh).
        """
        return self._dispatch("proprietary_flow", **kwargs)

    def box_trades(self):
        pass # Placeholder to avoid syntax error on replace, implementing block_trades below
        
    def block_trades(self, limit: int = 1000, **kwargs) -> pd.DataFrame:
        """
        Real-time or historical data for negotiated/block trades (giao dịch thoả thuận).
        
        Args:
            limit (int): Number of records to fetch (default: 1000).
        """
        if "page_size" not in kwargs:
            kwargs["page_size"] = limit
        return self._dispatch("block_trades", **kwargs)

    def put_through(self, **kwargs) -> pd.DataFrame:
        """Alias for block_trades (Negotiated Trades)."""
        return self.block_trades(**kwargs)

    def odd_lot(self, **kwargs) -> pd.DataFrame:
        """
        Real-time pricing or trades for odd-lot execution (Lô lẻ).
        """
        if "symbols_list" not in kwargs:
            kwargs["symbols_list"] = [self.symbol]
        return self._dispatch("odd_lot", **kwargs)

    def volume_profile(self, **kwargs) -> pd.DataFrame:
        """
        Aggregated volume distributed across executed price levels (Volume Profile).
        """
        return self._dispatch("volume_profile", **kwargs)

    def matched_by_price(self, **kwargs) -> pd.DataFrame:
        """Alias for volume_profile."""
        return self.volume_profile(**kwargs)
