from typing import Optional, Union, Dict, List
import pandas as pd
from vnstock_data.ui._base import BaseDomain
from vnstock_data.ui._registry import INSIGHTS_SOURCES

class ScreenerReference(BaseDomain):
    """
    Sub-domain UI model for the Stock Screener feature.
    Part of Layer 7 - Insights. Provides comprehensive data on all stock criteria
    allowing users to convert to a DataFrame and perform custom filtering using Pandas.
    """
    def __init__(self):
        super().__init__(domain_name="insights.screener", layer_sources=INSIGHTS_SOURCES)

    def _dispatch(self, method_name: str, **kwargs) -> pd.DataFrame:
        """
        Overwrite the _dispatch to use strict=False.
        We want to return ALL data fields from the screener, so dropping columns is not ideal.
        """
        from vnstock_data.ui.config import get_route
        from vnstock_data.core.registry import ProviderRegistry
        import importlib
        
        source_name, module_name, class_name, provider_method = get_route(
            self._domain_name, method_name, self._sources_config
        )
        
        if not ProviderRegistry.is_registered(module_name, source_name):
            try:
                importlib.import_module(f"vnstock_data.explorer.{source_name}.{module_name}")
            except ImportError:
                pass
                
        provider_cls = ProviderRegistry.get(module_name, source_name)
        if not provider_cls:
            raise ValueError(f"Provider not found for {source_name}.{module_name}")
            
        provider_instance = provider_cls()
        method = getattr(provider_instance, provider_method)
        result = method(**kwargs)
        
        key = f"{self._domain_name}.{method_name}"
        from vnstock_data.ui.schemas.core import standardize_columns
        result = standardize_columns(result, key, source_name, strict=False)
        
        return result

    def criteria(self, lang: str = "vi", **kwargs) -> pd.DataFrame:
        """
        Retrieves the mapping list of criteria to explain field names (data columns).
        
        Args:
            lang (str): Language ('vi' or 'en'). Defaults to 'vi'.
            **kwargs: Additional parameters passed to the provider adapter.
            
        Returns:
            pd.DataFrame: DataFrame mapping the field names.
        """
        return self._dispatch("criteria", lang=lang, **kwargs)
        
    def filter(self, limit: int = 2000, **kwargs) -> pd.DataFrame:
        """
        Retrieves full market data (all stocks) with all available criteria (ratios, metrics)
        returning a comprehensive DataFrame of the market.
        Users can apply advanced filtering logic directly on this DataFrame using Pandas.
        
        Args:
            limit (int): Maximum number of records to retrieve. Defaults to 2000.
            **kwargs: Additional parameters passed to the provider adapter.
            
        Returns:
            pd.DataFrame: Screener data DataFrame containing hundreds of metrics.
        """
        return self._dispatch("filter", limit=limit, **kwargs)
