"""
Ranking Domain (Insights Layer).
"""

import pandas as pd
from vnstock_data.ui._base import BaseDomain
from vnstock_data.ui.schemas.core import standardize_columns
from vnstock_data.ui._registry import INSIGHTS_SOURCES

class RankingReference(BaseDomain):
    """
    Market Ranking Insights.
    Wraps provider methods (like vnd.insight.TopStock) to identify
    market movers based on volume, value, foreign flow, etc.
    """
    def __init__(self):
        super().__init__(domain_name="insights.ranking", layer_sources=INSIGHTS_SOURCES)

    def _dispatch_and_format(self, method_name: str, **kwargs) -> pd.DataFrame:
        df = self._dispatch(method_name, **kwargs)
        from vnstock_data.ui.config import get_route
        source_name, _, _, _ = get_route(self._domain_name, method_name, self._sources_config)
        return standardize_columns(df, f"{self._domain_name}.{method_name}", source_name, strict=True)

    def gainer(self, index: str = 'VNINDEX', limit: int = 10, **kwargs) -> pd.DataFrame:
        """Top 10 stocks with highest price increase."""
        return self._dispatch_and_format("gainer", index=index, limit=limit, **kwargs)

    def loser(self, index: str = 'VNINDEX', limit: int = 10, **kwargs) -> pd.DataFrame:
        """Top 10 stocks with highest price decrease."""
        return self._dispatch_and_format("loser", index=index, limit=limit, **kwargs)

    def value(self, index: str = 'VNINDEX', limit: int = 10, **kwargs) -> pd.DataFrame:
        """Top 10 stocks with highest trading value."""
        return self._dispatch_and_format("value", index=index, limit=limit, **kwargs)

    def volume(self, index: str = 'VNINDEX', limit: int = 10, **kwargs) -> pd.DataFrame:
        """Top 10 stocks with highest volume spikes."""
        return self._dispatch_and_format("volume", index=index, limit=limit, **kwargs)
        
    def deal(self, index: str = 'VNINDEX', limit: int = 10, **kwargs) -> pd.DataFrame:
        """Top 10 stocks with highest put-through/deal volume spikes."""
        return self._dispatch_and_format("deal", index=index, limit=limit, **kwargs)

    def foreign_buy(self, date: str = None, limit: int = 10, **kwargs) -> pd.DataFrame:
        """Top 10 stocks with highest foreign net buy value."""
        return self._dispatch_and_format("foreign_buy", date=date, limit=limit, **kwargs)

    def foreign_sell(self, date: str = None, limit: int = 10, **kwargs) -> pd.DataFrame:
        """Top 10 stocks with highest foreign net sell value."""
        return self._dispatch_and_format("foreign_sell", date=date, limit=limit, **kwargs)
