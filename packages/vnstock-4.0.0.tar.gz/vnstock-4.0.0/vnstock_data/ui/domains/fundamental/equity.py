"""
Equity Fundamental Domain (Layer 3).
Wraps the `kbs.financial.Finance` module.
"""

import pandas as pd
from vnstock_data.ui._base import BaseDetail
from vnstock_data.ui.schemas.core import standardize_columns
from vnstock_data.ui._registry import FUNDAMENTAL_SOURCES

class EquityFundamental(BaseDetail):
    """
    Access point for fetching company financial statements and valuation ratios.
    """

    def __init__(self, symbol: str):
        super().__init__(symbol=symbol, domain_name="equity.fundamental", layer_sources=FUNDAMENTAL_SOURCES)

    def _resolve_scorecard(self, scorecard: str) -> str:
        """Resolves auto scorecard into exact sector keys based on literal text definitions"""
        _alias_map = {"bank": "banking", "sec": "securities", "ins": "insurance"}
        if scorecard in _alias_map:
            scorecard = _alias_map[scorecard]
            
        if scorecard == "auto":
            from vnstock_data.ui import Reference
            try:
                info_df = Reference().company(self.symbol).info()
                if not info_df.empty:
                    # Support both 'industry' and 'sector' column names
                    col = 'industry' if 'industry' in info_df.columns else 'sector' if 'sector' in info_df.columns else None
                    if col:
                        sector = str(info_df[col].iloc[0])
                        # Banking
                        if sector.startswith("Ngân hàng") or "bank" in sector.lower():
                            return "banking"
                        # Securities / Financial Services
                        elif sector.startswith("Dịch vụ tài chính") or "chứng khoán" in sector.lower() or "financial services" in sector.lower():
                            return "securities"
                        # Insurance
                        elif "Bảo hiểm" in sector or "insurance" in sector.lower():
                            return "insurance"
            except Exception:
                pass
            return "generic"
        return scorecard

    def _dispatch_and_format(self, method_name: str, scorecard: str = None, filter_unmapped: bool = None, **kwargs) -> pd.DataFrame:
        """
        Dispatches method to KBS Finance and standardizes columns without strict trimming.
        Financial statements vary widely depending on sector, so we use `strict=False`
        to preserve all snake_cased accounting fields.
        """
        # Request standard item_id codes from KBS
        api_kwargs = kwargs.copy()
        if "display_mode" not in api_kwargs:
            from vnstock_data.explorer.kbs.financial import FieldDisplayMode
            api_kwargs["display_mode"] = FieldDisplayMode.STD
            
        # FORCE backend to always return Vietnamese so our string dictionary matches perfectly
        api_kwargs.pop('lang', None)
            
        df = self._dispatch(method_name, **api_kwargs)
        if df.empty:
            return df
            
        # 1. Standardize columns
        from vnstock_data.ui.config import get_route
        source_name, _, _, _ = get_route(self._domain_name, method_name, self._sources_config)
        base_domain = "fundamental.equity"
        scorecard_key = self._resolve_scorecard(scorecard)
        
        if filter_unmapped is None:
            # Traditional calls (scorecard=None) should return full data.
            # Standardized calls (scorecard provided) should be filtered.
            filter_unmapped = (scorecard_key is not None)
            
        df = standardize_columns(df, f"{base_domain}.{method_name}", source_name, strict=False, filter_unmapped=filter_unmapped)
        
        # 2. Enforce Time-Series Shape (Rows = Period, Columns = Metrics) for AI compatibility
        # KBS output structure: ['item', 'item_id', '2024', '2023', '2022', ...]
        if 'item_id' in df.columns:
            # Set 'item_id' as index temporarily
            df_t = df.set_index('item_id')
            
            # Identify period columns (usually years or quarters, numeric or numeric-Q)
            period_cols = [c for c in df_t.columns if str(c).replace('-', 'Q').replace('Q', '1').isdigit()]
            
            if period_cols:
                # Transpose only the period columns
                df_t = df_t[period_cols].transpose()
                
                # Reset index to make period a column
                df_t = df_t.reset_index()
                # Rename 'index' to 'period'
                df_t = df_t.rename(columns={'index': 'period'})
                
                # Add ticker
                df_t.insert(1, 'ticker', self.symbol)
                
                # Sort ascending by period
                df = df_t.sort_values('period').reset_index(drop=True)
                
        # 2.5 Deduplicate identical columns resulting from multi-mapped native indices
        df = df.loc[:, ~df.columns.duplicated(keep="first")]
                
        # 3. Post-transpose Scorecard strict filtering
        if scorecard_key:
            from vnstock_data.ui.schemas.scorecards import SCORECARDS
            card_cols = SCORECARDS.get(scorecard_key, {}).get(f"{base_domain}.{method_name}", [])
            if card_cols:
                keep = [c for c in df.columns if c in card_cols or c in ["period", "ticker", "report_period"]]
                df = df[keep]
                
        # 4. Vietnamese Localization if requested
        if kwargs.get("lang") == "vi":
            from vnstock_data.ui.schemas.dictionary import FUNDAMENTAL_VI_LABELS
            df = df.rename(columns=FUNDAMENTAL_VI_LABELS)
            
        return df

    def ratio(self, scorecard: str = None, **kwargs) -> pd.DataFrame:
        """
        Extracts key financial ratios (P/E, ROE, Debt/Equity, etc.).
        
        Returns:
            pd.DataFrame: Ratios pivoted by period.
        """
        return self._dispatch_and_format("ratio", scorecard=scorecard, **kwargs)

    def income_statement(self, scorecard: str = None, **kwargs) -> pd.DataFrame:
        """
        Extracts Income Statement.
        """
        return self._dispatch_and_format("income_statement", scorecard=scorecard, **kwargs)

    def balance_sheet(self, scorecard: str = None, **kwargs) -> pd.DataFrame:
        """
        Extracts Balance Sheet.
        """
        return self._dispatch_and_format("balance_sheet", scorecard=scorecard, **kwargs)

    def cash_flow(self, scorecard: str = None, **kwargs) -> pd.DataFrame:
        """
        Extracts Cash Flow statement.
        """
        return self._dispatch_and_format("cash_flow", scorecard=scorecard, **kwargs)
        
    def note(self, **kwargs) -> pd.DataFrame:
        """
        Extracts Footnotes (Thuyết minh Báo cáo tài chính).
        Note: This method doesn't accept display_mode parameter.
        """
        # Note doesn't support display_mode, so remove it before dispatching
        kwargs.pop('display_mode', None)
        df = self._dispatch("note", **kwargs)
        if df.empty:
            return df
        
        # Standardize columns
        from vnstock_data.ui.config import get_route
        from vnstock_data.ui.schemas.core import standardize_columns
        source_name, _, _, _ = get_route(self._domain_name, "note", self._sources_config)
        return standardize_columns(df, f"{self._domain_name}.note", source_name, strict=False, filter_unmapped=False)

    def financial_health(self, scorecard: str = "auto", reports: list[str] = None, **kwargs) -> pd.DataFrame:
        """
        Aggregates Balance Sheet, Income Statement, Cash Flow, and Ratios into a single unified health matrix
        with TCBS-style section headers and proper field ordering.
        
        Args:
            scorecard: 'auto' (detect via ICB), 'banking', 'securities', 'insurance', 'generic'.
            reports: A list specifying which datasets to merge. Defaults to all 4 fundamental reports.
                     Options: ["income_statement", "balance_sheet", "cash_flow", "ratio"]
        """
        # Display warning about data standardization complexity
        print("\033[93m" + "⚠️ MIỄN TRỪ TRÁCH NHIỆM: Dữ liệu tài chính được chuẩn hóa và tổng hợp dựa trên các nguồn thông tin công khai. "
              "Mặc dù cấu trúc báo cáo được thiết kế dựa trên tiêu chuẩn tham chiếu từ hệ thống phân tích của TCBS nhằm đảm bảo tính nhất quán, "
              "người dùng cần lưu ý rằng do sự khác biệt trong phương pháp hạch toán và độ trễ dữ liệu giữa các nguồn, "
              "các chỉ số có thể tồn tại sai số hoặc khác biệt so với các nền tảng tham chiếu khác. Thông tin này chỉ mang tính chất tham khảo. "
              "Người dùng cam kết tự rà soát và chịu toàn bộ trách nhiệm đối với mọi quyết định sử dụng dữ liệu này trong các hoạt động đầu tư." + "\033[0m")

        dfs = []
        if reports is None:
            reports = ["income_statement", "balance_sheet", "cash_flow", "ratio"]
        
        # 1. Fetch individual segments (they are already translated and filtered internally)
        for method_name in reports:
            domain_method = getattr(self, method_name)
            df = domain_method(scorecard=scorecard, **kwargs)
            if not df.empty:
                if "ticker" in df.columns:
                    df = df.drop(columns=["ticker"])
                dfs.append(df.set_index("period"))
            
        if not dfs:
            return pd.DataFrame()
            
        # 2. Horizontal align strictly on index [period]
        df_merged = pd.concat(dfs, axis=1, join='outer')
        
        # Mathematically merge duplicated columns (e.g., FVTPL + AFS) to sum up sub-components properly
        df_merged = df_merged.T.groupby(level=0).sum(min_count=1).T.reset_index()
        
        # 3. Apply TCBS-style ordering with section headers
        scorecard_key = self._resolve_scorecard(scorecard)
        df_ordered = self._apply_tcbs_ordering(df_merged, scorecard_key, **kwargs)
        
        # Calculate derived fields for banking sector
        if scorecard_key == "banking":
            from vnstock_data.ui.schemas.dictionary import FUNDAMENTAL_VI_LABELS
            from vnstock_data.ui.schemas.dictionary import FundamentalKeys as F
            
            # Calculate TOTAL_OPERATING_INCOME (TOI) from income components
            income_cols = {
                'net_interest_income': 'Thu nhập lãi thuần',
                'net_fee_and_commission_income': 'Lãi thuần từ HĐ dịch vụ',
                'net_gain_loss_from_investment_activities': 'Lãi thuần từ HĐ đầu tư',
                'net_other_income': 'Lãi thuần từ HĐ khác'
            }
            
            # Check if all income components exist
            existing_income_cols = [col for col in income_cols.values() if col in df_ordered.columns]
            if len(existing_income_cols) >= 2:
                df_ordered['Tổng thu nhập HĐ (TOI)'] = df_ordered[existing_income_cols].sum(axis=1, min_count=1)
        
        # Handle limit parameter: take the most recent periods first
        # Default to 16 periods. If limit is 0 or explicitly None, fetch all.
        limit = kwargs.get('limit', 16)
        if limit and limit > 0:
            # Sort descending to get most recent periods first
            df_ordered = df_ordered.sort_values(by='period', ascending=False)
            # Take only the most recent N periods
            df_ordered = df_ordered.head(limit)
            # Sort back to ascending (oldest first)
            df_ordered = df_ordered.sort_values(by='period', ascending=True)
        else:
            # Sort by period in ascending order (oldest first)
            df_ordered = df_ordered.sort_values(by='period', ascending=True)
        
        # Re-inject ticker dynamically
        df_ordered.insert(0, 'ticker', self.symbol)
        
        return df_ordered
    
    def _apply_tcbs_ordering(self, df: pd.DataFrame, scorecard_key: str, **kwargs) -> pd.DataFrame:
        """
        Apply TCBS-style section headers and field ordering to the financial health data.
        Creates a structured output with section headers as index values.
        """
        from vnstock_data.ui.schemas.scorecards import get_financial_health_sections
        from vnstock_data.ui.schemas.dictionary import FUNDAMENTAL_VI_LABELS
        
        # Get the ordering configuration for the scorecard
        order_config = get_financial_health_sections(scorecard_key)
        
        # Create ordered list of metrics with section headers
        ordered_metrics = []
        
        for section in order_config:
            section_header = section["header"]
            section_fields = section["fields"]
            
            # Check if this section has any available fields
            has_available_fields = False
            available_section_fields = []
            
            for field in section_fields:
                field_name = None
                if field in df.columns:
                    field_name = field
                elif kwargs.get("lang") == "vi":
                    vi_label = FUNDAMENTAL_VI_LABELS.get(field)
                    if vi_label and vi_label in df.columns:
                        field_name = vi_label
                
                if field_name:
                    has_available_fields = True
                    available_section_fields.append(field_name)
            
            # Add section header only if it has available fields
            if has_available_fields:
                ordered_metrics.append(section_header)
                ordered_metrics.extend(available_section_fields)
        
        # Filter to only include metrics that exist in the dataframe
        final_metrics = []
        for metric in ordered_metrics:
            if metric in df.columns:
                final_metrics.append(metric)
        
        # Reorder the dataframe columns
        if final_metrics:
            # Keep period and ticker columns if they exist
            base_columns = []
            if 'period' in df.columns:
                base_columns.append('period')
            if 'ticker' in df.columns:
                base_columns.append('ticker')
            
            # Combine base columns with ordered metrics
            ordered_columns = base_columns + [col for col in final_metrics if col not in base_columns]
            df_ordered = df[ordered_columns].copy()
        else:
            df_ordered = df.copy()
        
        return df_ordered
