"""
Economy Reference Domain (Layer 6).
Wraps the `mbk.macro.Macro` module for generic macroeconomic indicators.
"""

import pandas as pd
from vnstock_data.ui._base import BaseDetail
from vnstock_data.ui.schemas.core import standardize_columns
from vnstock_data.ui._registry import MACRO_SOURCES

class EconomyReference(BaseDetail):
    """
    Access point for fetching macroeconomic data such as GDP, CPI, FDI, etc.
    """

    def __init__(self):
        # We use a dummy symbol since macro indicators are system-wide
        super().__init__(symbol="MACRO", domain_name="macro.economy", layer_sources=MACRO_SOURCES)

    def _dispatch_and_format(self, method_name: str, **kwargs) -> pd.DataFrame:
        """
        Dispatches method to MBK Macro and standardizes columns without strict trimming.
        """
        df = self._dispatch(method_name, **kwargs)
        if df.empty:
            return df
            
        from vnstock_data.ui.config import get_route
        source_name, _, _, _ = get_route(self._domain_name, method_name, self._sources_config)
        
        base_domain = "macro.economy"
        return standardize_columns(df, f"{base_domain}.{method_name}", source_name, strict=False)

    def gdp(self, **kwargs) -> pd.DataFrame:
        """GDP data."""
        return self._dispatch_and_format("gdp", **kwargs)

    def cpi(self, **kwargs) -> pd.DataFrame:
        """Consumer Price Index data."""
        return self._dispatch_and_format("cpi", **kwargs)
        
    def industry_prod(self, **kwargs) -> pd.DataFrame:
        """Industrial Production data."""
        return self._dispatch_and_format("industry_prod", **kwargs)

    def import_export(self, **kwargs) -> pd.DataFrame:
        """Import/Export macro data."""
        return self._dispatch_and_format("import_export", **kwargs)

    def retail(self, **kwargs) -> pd.DataFrame:
        """Retail macro data."""
        return self._dispatch_and_format("retail", **kwargs)
        
    def fdi(self, **kwargs) -> pd.DataFrame:
        """Foreign Direct Investment data."""
        return self._dispatch_and_format("fdi", **kwargs)
        
    def money_supply(self, **kwargs) -> pd.DataFrame:
        """Money supply data."""
        return self._dispatch_and_format("money_supply", **kwargs)
        
    def population_labor(self, **kwargs) -> pd.DataFrame:
        """Population and Labor data."""
        return self._dispatch_and_format("population_labor", **kwargs)
