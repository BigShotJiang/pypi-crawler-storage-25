"""
Currency Reference Domain (Layer 6).
Wraps the `mbk.macro.Macro.exchange_rate` module.
"""

import pandas as pd
from vnstock_data.ui._base import BaseDetail
from vnstock_data.ui.schemas.core import standardize_columns
from vnstock_data.ui._registry import MACRO_SOURCES

class CurrencyReference(BaseDetail):
    """
    Access point for fetching currency exchange rates.
    """

    def __init__(self):
        super().__init__(symbol="MACRO", domain_name="macro.currency", layer_sources=MACRO_SOURCES)

    def _dispatch_and_format(self, method_name: str, **kwargs) -> pd.DataFrame:
        """
        Dispatches method to MBK Macro and standardizes columns without strict trimming.
        """
        df = self._dispatch(method_name, **kwargs)
        if df.empty:
            return df
            
        from vnstock_data.ui.config import get_route
        source_name, _, _, _ = get_route(self._domain_name, method_name, self._sources_config)
        
        base_domain = "macro.currency"
        return standardize_columns(df, f"{base_domain}.{method_name}", source_name, strict=False)

    def exchange_rate(self, **kwargs) -> pd.DataFrame:
        """Foreign exchange rates."""
        return self._dispatch_and_format("exchange_rate", **kwargs)

    def interest_rate(self, **kwargs) -> pd.DataFrame:
        """Interest rates data."""
        return self._dispatch_and_format("interest_rate", **kwargs)
