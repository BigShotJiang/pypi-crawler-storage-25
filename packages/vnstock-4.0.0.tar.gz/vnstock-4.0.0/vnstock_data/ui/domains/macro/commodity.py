"""
Commodity Market Domain (Layer 6).
Wraps the `spl.commodity.CommodityPrice` module for global and local commodity prices.
"""

import pandas as pd
from vnstock_data.ui._base import BaseDetail
from vnstock_data.ui.schemas.core import standardize_columns
from vnstock_data.ui._registry import MACRO_SOURCES

class CommodityReference(BaseDetail):
    """
    Access point for fetching commodity prices (Gold, Gas, Oil, Steel, etc.).
    """

    def __init__(self):
        super().__init__(symbol="MACRO", domain_name="macro.commodity", layer_sources=MACRO_SOURCES)

    def _dispatch_and_format(self, method_name: str, **kwargs) -> pd.DataFrame:
        """
        Dispatches method to SPL CommodityPrice and standardizes columns.
        """
        df = self._dispatch(method_name, **kwargs)
        if df.empty:
            return df
            
        from vnstock_data.ui.config import get_route
        source_name, _, _, _ = get_route(self._domain_name, method_name, self._sources_config)
        
        base_domain = "macro.commodity"
        df = standardize_columns(df, f"{base_domain}.{method_name}", source_name, strict=False)
        
        # SPL returns index as 'time', let's format it properly as explicitly requested by time-series standard
        if df.index.name == 'time' or df.index.name == 'report_time':
             df = df.reset_index()
             if 'time' in df.columns:
                 df = df.rename(columns={'time': 'report_time'})
             # Force 'report_time' to be datetime if not already
             df['report_time'] = pd.to_datetime(df['report_time'])
             df = df.set_index('report_time')
             
        return df

    def gold(self, market: str = "VN", **kwargs) -> pd.DataFrame:
        """
        Gold prices.
        
        Args:
            market (str): 'VN' for Vietnam SJC/local gold, 'GLOBAL' for GC=F international futures.
        """
        if str(market).upper() == "GLOBAL":
            return self._dispatch_and_format("gold_global", **kwargs)
        return self._dispatch_and_format("gold_vn", **kwargs)

    def gas(self, market: str = "VN", **kwargs) -> pd.DataFrame:
        """
        Gas prices. Note: 'GLOBAL' returns natural gas futures. 'VN' returns aggregated RON/DO prices.
        """
        if str(market).upper() == "GLOBAL":
            return self._dispatch_and_format("gas_natural", **kwargs)
        return self._dispatch_and_format("gas_vn", **kwargs)

    def oil_crude(self, **kwargs) -> pd.DataFrame:
        """Crude Oil prices."""
        return self._dispatch_and_format("oil_crude", **kwargs)

    def coke(self, **kwargs) -> pd.DataFrame:
        """Coke (Coal) prices."""
        return self._dispatch_and_format("coke", **kwargs)

    def steel(self, market: str = "GLOBAL", **kwargs) -> pd.DataFrame:
        """Steel prices. 'GLOBAL' for HRC1!, 'VN' for D10."""
        if str(market).upper() == "VN":
            return self._dispatch_and_format("steel_d10", **kwargs)
        return self._dispatch_and_format("steel_hrc", **kwargs)

    def iron_ore(self, **kwargs) -> pd.DataFrame:
        """Iron ore prices."""
        return self._dispatch_and_format("iron_ore", **kwargs)

    def fertilizer_ure(self, **kwargs) -> pd.DataFrame:
        """Fertilizer URE prices."""
        return self._dispatch_and_format("fertilizer_ure", **kwargs)

    def soybean(self, **kwargs) -> pd.DataFrame:
        """Soybean prices."""
        return self._dispatch_and_format("soybean", **kwargs)

    def corn(self, **kwargs) -> pd.DataFrame:
        """Corn prices."""
        return self._dispatch_and_format("corn", **kwargs)

    def sugar(self, **kwargs) -> pd.DataFrame:
        """Sugar prices."""
        return self._dispatch_and_format("sugar", **kwargs)

    def pork(self, market: str = "VN", **kwargs) -> pd.DataFrame:
        """Pork prices. 'VN' for local North Pig, 'CHINA' for China market."""
        if str(market).upper() == "CHINA":
            return self._dispatch_and_format("pork_china", **kwargs)
        return self._dispatch_and_format("pork_vn", **kwargs)
