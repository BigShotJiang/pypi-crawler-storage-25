"""
Configuration module for UI Data Routing Overrides.

Provides the ability to dynamically override the data routing logic. 
This is useful when:
1. A default API source breaks and needs to be patched quickly.
2. A user wants to provide a custom "patchwork" data source (e.g., just one method from ACBS)
   without building a full provider module.
"""

from typing import Dict, Tuple

# Format: {"domain.method": ("source_name", "provider_type", "provider_class", "provider_method")}
# Example: {"equity.list": ("acbs", "listing", "ACBSListing", "get_equities")}
ROUTE_OVERRIDES: Dict[str, Tuple[str, str, str, str]] = {}

def set_route(domain_method: str, source: str, provider_type: str, class_name: str, method: str):
    """
    Override the default data source routing for a specific UI method.
    (Make sure to register your custom class via ProviderRegistry.register() first)
    
    Args:
        domain_method: The UI method to override (e.g., 'company.profile')
        source: The source name (e.g., 'acbs')
        provider_type: The provider type category in registry (e.g., 'company', 'listing')
        class_name: The name of the custom class (mostly for logging)
        method: The method to call on the provider instance
    """
    ROUTE_OVERRIDES[domain_method] = (source, provider_type, class_name, method)

def get_route(domain: str, method: str, default_sources: Dict) -> Tuple[str, str, str, str]:
    """
    Get the routing configuration for a specific domain and method, checking overrides first.
    """
    key = f"{domain}.{method}"
    if key in ROUTE_OVERRIDES:
        return ROUTE_OVERRIDES[key]
        
    domain_sources = default_sources.get(domain, {})
    if method not in domain_sources:
        raise NotImplementedError(f"Method '{method}' not implemented for domain '{domain}'")
        
    return domain_sources[method]

def clear_route_overrides():
    """Clear all custom route overrides."""
    ROUTE_OVERRIDES.clear()
