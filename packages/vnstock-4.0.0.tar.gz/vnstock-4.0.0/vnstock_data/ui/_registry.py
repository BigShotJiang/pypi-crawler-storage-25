"""
Registry module for mapping UI methods to underlying data sources.
"""

from typing import Dict, Tuple, Any

# Ensure FXSB explorers are registered
try:
    from vnstock_data.explorer.fxsb.quote import Quote as FXSBQuote
    from vnstock_data.explorer.fxsb.listing import Listing as FXSBListing
    from vnstock_data.core.registry import ProviderRegistry as UIProviderRegistry
    UIProviderRegistry.register('quote', 'fxsb', FXSBQuote)
    UIProviderRegistry.register('listing', 'fxsb', FXSBListing)
except ImportError:
    pass

# Ensure Dukascopy explorers are registered
try:
    from vnstock_data.explorer.dukas.quote import Quote as DukascopyQuote
    from vnstock_data.explorer.dukas.listing import Listing as DukascopyListing
    from vnstock_data.core.registry import ProviderRegistry as UIProviderRegistry
    UIProviderRegistry.register('quote', 'dukascopy', DukascopyQuote)
    UIProviderRegistry.register('listing', 'dukascopy', DukascopyListing)
except ImportError:
    pass

# Ensure Binance connectors are registered
try:
    from vnstock_data.connector.binance.spot.market import SpotMarket as BinanceSpotMarket
    from vnstock_data.core.registry import ProviderRegistry as UIProviderRegistry
    UIProviderRegistry.register('spot.market', 'binance', BinanceSpotMarket)
except ImportError:
    pass

# Mapping format:
# "domain": {
#     "method_name": ("source_name", "module_name", "class_name", "method_name")
# }

# ═══════════════════════════════════════════════════════════════════════════
# LAYER 1: REFERENCE DATA SOURCES
# ═══════════════════════════════════════════════════════════════════════════

REFERENCE_SOURCES: Dict[str, Dict[str, Tuple[str, str, str, str]]] = {
    # Company Domain
    "company": {
        "info": ("vci", "company", "Company", "overview"),
        "shareholders": ("vci", "company", "Company", "shareholders"),
        "officers": ("vci", "company", "Company", "officers"),
        "subsidiaries": ("vci", "company", "Company", "subsidiaries"),
        "news": ("vci", "company", "Company", "news"),
        "events": ("vci", "company", "Company", "events"),
        "margin_ratio": ("kbs", "company", "Company", "margin_ratio"),
    },
    
    # Industry Domain
    "industry": {
        "list": ("vci", "listing", "Listing", "industries_icb"),
        "sectors": ("vci", "listing", "Listing", "symbols_by_industries"),
    },
    
    # Equity Domain
    "equity": {
        "list": ("vci", "listing", "Listing", "all_symbols"),
        "by_group": ("vci", "listing", "Listing", "symbols_by_group"),
        "by_exchange": ("vci", "listing", "Listing", "symbols_by_exchange"),
        "by_industry": ("vci", "listing", "Listing", "symbols_by_industries"),
    },
    
    # Index Domain - Using symbols_by_group with specific index codes or future indices
    "index": {
        "list": ("kbs", "listing", "Listing", "all_indices"),
        "groups": ("kbs", "listing", "Listing", "get_supported_groups"),
        "members": ("kbs", "listing", "Listing", "symbols_by_group"),
        "futures": ("vci", "listing", "Listing", "all_future_indices"),
        # We can add more specific index listings here as we identify them
    },
    
    # Warrant Domain (Using new patchwork integration pattern)
    "reference.warrant": {
        "list": ("kbs", "derivatives", "Warrant", "list"),
    },
    "reference.fund": {
        "list": ("fmarket", "fund", "Fund", "listing"),
    },
    
    "etf": {
        "list": ("kbs", "listing", "Listing", "all_etf"),
    },
    
    "bond": {
        "corporate": ("kbs", "listing", "Listing", "all_bonds"),
        "government": ("vci", "listing", "Listing", "all_government_bonds"),
    },
    
    # Derivatives Detailed Reference
    "derivatives.warrant": {
        "info": ("kbs", "derivatives", "KBSDerivatives", "warrant_profile"),
        "list": ("vci", "listing", "Listing", "all_covered_warrant"),
    },
    "derivatives.futures": {
        "info": ("kbs", "derivatives", "KBSDerivatives", "future_profile"),
        "list": ("vci", "listing", "Listing", "all_future_indices"),
    },
    
    # Events Domain
    "events": {
        "calendar": ("vci", "event", "Event", "calendar"),
    },
    
    # Search Domain
    "search": {
        # Global instruments (Forex / Commodity / Index / Crypto) via Dukascopy
        "symbol":      ("dukascopy", "listing", "Listing", "search_symbol"),
        "instruments": ("dukascopy", "listing", "Listing", "all_symbols"),
        # Vietnamese equities / other via MSN fallback to Dukascopy for global coverage
        "info":        ("dukascopy", "listing", "Listing", "search_symbol"),
    },
    
    # Market Domain
    "market": {
        "status": ("mas", "market", "Market", "status"),
    },
}

# ═══════════════════════════════════════════════════════════════════════════
# LAYER 2: MARKET DATA SOURCES
# ═══════════════════════════════════════════════════════════════════════════

MARKET_SOURCES: Dict[str, Dict[str, Tuple[str, str, str, str]]] = {
    # ═══════════════════════════════════════════════════════════════════════════
    # EQUITY MARKET
    # ═══════════════════════════════════════════════════════════════════════════
    "market.equity": {
        "ohlcv":            ("kbs", "quote", "Quote", "history"),
        "price_history":    ("vci", "trading", "Trading", "price_history"),
        "trades":           ("kbs", "quote", "Quote", "intraday"),
        "order_book":       ("kbs", "trading", "Trading", "price_board"),
        "quote":            ("kbs", "trading", "Trading", "price_board"),
        "session_stats":    ("vci", "trading", "Trading", "summary"), # Using VCI until KBS adds explicitly
        "foreign_flow":     ("vci", "trading", "Trading", "foreign_trade"),
        "proprietary_flow": ("vci", "trading", "Trading", "prop_trade"),
        "block_trades":     ("kbs", "trading", "Trading", "put_through"),
        "odd_lot":          ("kbs", "trading", "Trading", "odd_lot"),
        "volume_profile":   ("kbs", "trading", "Trading", "matched_by_price"),
        "summary":          ("kbs", "quote", "Quote", "summary"),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # INDEX MARKET
    # ═══════════════════════════════════════════════════════════════════════════
    "market.index": {
        "ohlcv":            ("kbs", "quote", "Quote", "history"),
        "price_history":    ("vci", "trading", "Trading", "price_history"),
        "quote":            ("kbs", "trading", "Trading", "price_board"),
        "summary":          ("kbs", "trading", "Trading", "index_summary"),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # DERIVATIVES MARKET
    # ═══════════════════════════════════════════════════════════════════════════
    "market.futures": {
        "ohlcv":            ("kbs", "quote", "Quote", "history"),
        "quote":            ("kbs", "trading", "Trading", "price_board"),
        "trades":           ("kbs", "quote", "Quote", "intraday"),
        "order_book":       ("kbs", "trading", "Trading", "price_board"),
        "summary":          ("kbs", "derivatives", "KBSDerivatives", "future_profile"),
    },
    
    "market.warrant": {
        "ohlcv":            ("kbs", "quote", "Quote", "history"),
        "quote":            ("kbs", "trading", "Trading", "price_board"),
        "trades":           ("kbs", "quote", "Quote", "intraday"),
        "order_book":       ("kbs", "trading", "Trading", "price_board"),
        "summary":          ("kbs", "derivatives", "KBSDerivatives", "warrant_profile"),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # GLOBAL ASSETS MARKET (Binance)
    # ═══════════════════════════════════════════════════════════════════════════
    "market.crypto": {
        # ── Core (shared schema with all asset classes) ──────────────────
        "ohlcv":          ("binance", "spot.market", "SpotMarket", "ohlcv"),
        "trades":         ("binance", "spot.market", "SpotMarket", "intraday"),
        "order_book":     ("binance", "spot.market", "SpotMarket", "order_book"),
        "quote":          ("binance", "spot.market", "SpotMarket", "quote"),
        # ── Extended (Crypto-specific, universal names) ──────────────────
        "trade_history":  ("binance", "spot.market", "SpotMarket", "trade_history"),
        "vwap":           ("binance", "spot.market", "SpotMarket", "vwap"),
        "daily_stats":    ("binance", "spot.market", "SpotMarket", "daily_stats"),
        "last_price":     ("binance", "spot.market", "SpotMarket", "last_price"),
        "rolling_stats":  ("binance", "spot.market", "SpotMarket", "rolling_stats"),
        "reference_price":("binance", "spot.market", "SpotMarket", "reference_price"),
    },
    
    "market.forex": {
        # Primary: Dukascopy (Forex pairs – EUR-USD, USD-JPY, GBP-USD…)
        "ohlcv":    ("dukascopy", "quote", "Quote", "history"),
        "intraday": ("dukascopy", "quote", "Quote", "intraday"),
    },

    "market.commodity": {
        # Primary: Dukascopy (Gold XAUUSD.CMD-USD, Silver XAGUSD.CMD-USD, Oil…)
        "ohlcv":    ("dukascopy", "quote", "Quote", "history"),
        "intraday": ("dukascopy", "quote", "Quote", "intraday"),
    },
    
    "market.etf": {
        "ohlcv":            ("kbs", "quote", "Quote", "history"),
        "trades":           ("kbs", "quote", "Quote", "intraday"),
        "order_book":       ("kbs", "trading", "Trading", "price_board"),
        "quote":            ("kbs", "trading", "Trading", "price_board"),
        "session_stats":    ("vci", "trading", "Trading", "summary"),
        "foreign_flow":     ("vci", "trading", "Trading", "foreign_trade"),
        "proprietary_flow": ("vci", "trading", "Trading", "prop_trade"),
        "block_trades":     ("kbs", "trading", "Trading", "put_through"),
        "odd_lot":          ("kbs", "trading", "Trading", "odd_lot"),
        "volume_profile":   ("kbs", "trading", "Trading", "matched_by_price"),
        "summary":          ("kbs", "quote", "Quote", "summary"),
    },
    
    "market.fund": {
        "history":          ("fmarket", "fund", "FundDetails", "nav_report"),
        "top_holding":      ("fmarket", "fund", "FundDetails", "top_holding"),
        "industry_holding": ("fmarket", "fund", "FundDetails", "industry_holding"),
        "asset_holding":    ("fmarket", "fund", "FundDetails", "asset_holding"),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MARKET-WIDE
    # ═══════════════════════════════════════════════════════════════════════════
    "market.market_wide": {
        "quote":            ("kbs", "trading", "Trading", "price_board"),
    },
}

# ═══════════════════════════════════════════════════════════════════════════
# LAYER 3: FUNDAMENTAL DATA SOURCES
# ═══════════════════════════════════════════════════════════════════════════

FUNDAMENTAL_SOURCES: Dict[str, Dict[str, Tuple[str, str, str, str]]] = {
    "equity.fundamental": {
        "income_statement": ("mas", "financial", "Finance", "income_statement"),
        "balance_sheet":    ("mas", "financial", "Finance", "balance_sheet"),
        "cash_flow":        ("mas", "financial", "Finance", "cash_flow"),
        "ratio":            ("mas", "financial", "Finance", "ratio"),
        "note":             ("vci", "financial", "Finance", "note")
    }
}

# ═══════════════════════════════════════════════════════════════════════════
# LAYER 7: INSIGHTS SOURCES
# ═══════════════════════════════════════════════════════════════════════════

INSIGHTS_SOURCES: Dict[str, Dict[str, Tuple[str, str, str, str]]] = {
    "insights.screener": {
        "criteria": ("vci", "screener", "Screener", "get_criteria"),
        "filter": ("vci", "screener", "Screener", "filter"),
    },
    "insights.valuation": {
        "pe": ("vnd", "market", "Market", "pe"),
        "pb": ("vnd", "market", "Market", "pb"),
        "evaluation": ("vnd", "market", "Market", "evaluation"),
    },
    "insights.ranking": {
        "gainer": ("vnd", "insight", "TopStock", "gainer"),
        "loser": ("vnd", "insight", "TopStock", "loser"),
        "value": ("vnd", "insight", "TopStock", "value"),
        "volume": ("vnd", "insight", "TopStock", "volume"),
        "foreign_buy": ("vnd", "insight", "TopStock", "foreign_buy"),
        "foreign_sell": ("vnd", "insight", "TopStock", "foreign_sell"),
        "deal": ("vnd", "insight", "TopStock", "deal"),
    }
}

# ═══════════════════════════════════════════════════════════════════════════
# LAYER 6: MACRO SOURCES
# ═══════════════════════════════════════════════════════════════════════════

MACRO_SOURCES: Dict[str, Dict[str, Tuple[str, str, str, str]]] = {
    "macro.economy": {
        "gdp": ("mbk", "macro", "Macro", "gdp"),
        "cpi": ("mbk", "macro", "Macro", "cpi"),
        "industry_prod": ("mbk", "macro", "Macro", "industry_prod"),
        "import_export": ("mbk", "macro", "Macro", "import_export"),
        "retail": ("mbk", "macro", "Macro", "retail"),
        "fdi": ("mbk", "macro", "Macro", "fdi"),
        "money_supply": ("mbk", "macro", "Macro", "money_supply"),
        "population_labor": ("mbk", "macro", "Macro", "population_labor"),
    },
    "macro.currency": {
        "exchange_rate": ("mbk", "macro", "Macro", "exchange_rate"),
        "interest_rate": ("mbk", "macro", "Macro", "interest_rate"),
    },
    "macro.commodity": {
        "gold_vn": ("spl", "commodity", "CommodityPrice", "gold_vn"),
        "gold_global": ("spl", "commodity", "CommodityPrice", "gold_global"),
        "gas_vn": ("spl", "commodity", "CommodityPrice", "gas_vn"),
        "gas_natural": ("spl", "commodity", "CommodityPrice", "gas_natural"),
        "oil_crude": ("spl", "commodity", "CommodityPrice", "oil_crude"),
        "coke": ("spl", "commodity", "CommodityPrice", "coke"),
        "steel_d10": ("spl", "commodity", "CommodityPrice", "steel_d10"),
        "steel_hrc": ("spl", "commodity", "CommodityPrice", "steel_hrc"),
        "iron_ore": ("spl", "commodity", "CommodityPrice", "iron_ore"),
        "fertilizer_ure": ("spl", "commodity", "CommodityPrice", "fertilizer_ure"),
        "soybean": ("spl", "commodity", "CommodityPrice", "soybean"),
        "corn": ("spl", "commodity", "CommodityPrice", "corn"),
        "sugar": ("spl", "commodity", "CommodityPrice", "sugar"),
        "pork_vn": ("spl", "commodity", "CommodityPrice", "pork_north_vn"),
        "pork_china": ("spl", "commodity", "CommodityPrice", "pork_china"),
    }
}
