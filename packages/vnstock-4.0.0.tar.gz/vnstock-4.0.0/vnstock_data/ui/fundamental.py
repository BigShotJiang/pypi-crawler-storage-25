"""
Fundamental Module Entry Point (Layer 3).
"""

from vnstock_data.ui.domains.fundamental.equity import EquityFundamental
import pandas as pd

class EquityFundamentalProxy:
    """
    Proxy to support both:
    1. fun.equity("TCB").cash_flow(...)
    2. fun.equity.cash_flow("TCB", ...)
    """
    def __call__(self, symbol: str) -> EquityFundamental:
        return EquityFundamental(symbol)

    def ratio(self, symbol: str, **kwargs) -> pd.DataFrame:
        return EquityFundamental(symbol).ratio(**kwargs)

    def income_statement(self, symbol: str, **kwargs) -> pd.DataFrame:
        return EquityFundamental(symbol).income_statement(**kwargs)

    def balance_sheet(self, symbol: str, **kwargs) -> pd.DataFrame:
        return EquityFundamental(symbol).balance_sheet(**kwargs)

    def cash_flow(self, symbol: str, **kwargs) -> pd.DataFrame:
        return EquityFundamental(symbol).cash_flow(**kwargs)

    def note(self, symbol: str, **kwargs) -> pd.DataFrame:
        return EquityFundamental(symbol).note(**kwargs)

    def financial_health(self, symbol: str, scorecard: str = "auto", **kwargs) -> pd.DataFrame:
        """
        Combines Income Statement, Balance Sheet, and Ratios into a single summarized matrix using TCBS scorecard conventions.
        """
        return EquityFundamental(symbol).financial_health(scorecard=scorecard, **kwargs)


class Fundamental:
    """
    Central API Gateway for Layer 3 - Fundamental Data (Unified UI).
    Provides financial statements, ratios, and diagnostic analysis for equities.
    
    ✅ METHODS AVAILABLE (5 total):
    
    equity(symbol) → EquityFundamental object with 5 methods:
        - ratio()               → Financial ratios (P/E, ROE, Debt/Equity, etc.)
        - income_statement()    → Revenue, expenses, profit (quarterly/annual)
        - balance_sheet()       → Assets, liabilities, equity position
        - cash_flow()           → Operating, investing, financing cash flows
        - note()                → Footnotes and disclosures (Thuyết minh)
    
    Example:
        fund = Fundamental()
        vic = fund.equity('VIC')
        
        ratios = vic.ratio()                    # 12 periods
        income = vic.income_statement()         # 12 periods
        balance = vic.balance_sheet()           # 12 periods
        cash = vic.cash_flow()                  # 12 periods
        notes = vic.note()                      # All footnotes
    """
    
    @property
    def equity(self) -> EquityFundamentalProxy:
        """
        Access financial data for a specific corporate equity (Fundamental Layer).
        
        Args:
            symbol (str): The stock ticker symbol (e.g. 'VIC', 'VNM', 'FPT')
            
        Returns:
            EquityFundamental: Object with 5 methods for financial analysis:
                - ratio()          - Key financial ratios
                - income_statement()- Income statement (12+ periods)
                - balance_sheet()  - Balance sheet (12+ periods)
                - cash_flow()      - Cash flow statement (12+ periods)
                - note()           - Financial disclosures/footnotes
        
        Example:
            fund = Fundamental()
            vic_data = fund.equity('VIC')
            ratios = vic_data.ratio()
        """
        return EquityFundamentalProxy()
