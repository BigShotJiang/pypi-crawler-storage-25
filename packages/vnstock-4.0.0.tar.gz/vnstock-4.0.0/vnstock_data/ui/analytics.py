"""
Analytics Module Entry Point (Layer 4).
"""

from vnstock_data.ui.domains.analytics.valuation import MarketValuation

class Analytics:
    """
    Central API Gateway for Layer 4 - Analytics (Unified UI).
    Provides valuation models, risk metrics, and quality scores.
    
    ✅ METHODS AVAILABLE:
    
    val = Analytics().valuation('VNINDEX')
    pe_data = val.pe(duration='5Y')
    """
    
    def valuation(self, index: str = "VNINDEX") -> MarketValuation:
        """
        Access historical valuation multiples for market indices (Analytics Layer).
        
        Methods available (3 total):
            - pe(duration)         - P/E ratio (Price-to-Earnings) historical
            - pb(duration)         - P/B ratio (Price-to-Book) historical
            - evaluation(duration) - Market evaluation (P/E + P/B overview)
        
        Args:
            index (str): Market index code (e.g. 'VNINDEX', 'HNX')
        
        Returns:
            MarketValuation: Valuation metrics gateway for the specified index
        """
        return MarketValuation(index=index)
