"""
Macro Module Entry Point (Layer 6).

Supports both new structure (recommended) and deprecated legacy API for backward compatibility.
Legacy methods will be removed after 31/8/2026.
"""

import warnings
import pandas as pd
from typing import Optional, Union, Any
from vnstock_data.ui.domains.macro.economy import EconomyReference
from vnstock_data.ui.domains.macro.commodity import CommodityReference
from vnstock_data.ui.domains.macro.currency import CurrencyReference

class Macro:
    """
    Central API Gateway for Layer 6 - Macroeconomic Data (Unified UI).
    
    ✅ NEW STRUCTURE (Recommended):
        m = Macro()
        
        # 📊 Economy Indicators (8 methods)
        m.economy().gdp()
        m.economy().cpi()
        m.economy().industry_prod()
        m.economy().import_export()
        m.economy().retail()
        m.economy().fdi()
        m.economy().money_supply()
        m.economy().population_labor()
        
        # 💰 Commodity Prices (11 methods)
        m.commodity().gold(market='VN')        # Vietnam SJC gold or GLOBAL futures
        m.commodity().gas(market='VN')         # Vietnam RON/DO or GLOBAL natural gas
        m.commodity().oil_crude()              # Crude oil futures
        m.commodity().coke()                   # Coal/Coke prices
        m.commodity().steel(market='GLOBAL')   # HRC1! global or D10 Vietnam
        m.commodity().iron_ore()               # Iron ore prices
        m.commodity().fertilizer_ure()         # URE fertilizer
        m.commodity().soybean()                # Soybean prices
        m.commodity().corn()                   # Corn prices
        m.commodity().sugar()                  # Sugar prices
        m.commodity().pork(market='VN')        # Vietnam North Pig or China market
        
        # 💱 Currency & Interest Rates (2 methods)
        m.currency().exchange_rate()           # Foreign exchange rates (USD, JPY, EUR, etc.)
        m.currency().interest_rate()           # VND deposit/lending rates
    
    ❌ LEGACY STRUCTURE (Deprecated, will be removed 31/8/2026):
        m = Macro()
        m.gdp()  # Shows deprecation warning
        m.exchange_rate()  # Shows deprecation warning
    """
    
    def economy(self) -> EconomyReference:
        """
        Access standard macroeconomic indicators (Macro Layer - Economy Domain).
        
        Methods available (8 total):
            - gdp()                  → GDP data (quarterly, annual)
            - cpi()                  → Consumer Price Index (monthly, annual)
            - industry_prod()        → Industrial Production Index
            - import_export()        → Import/Export statistics
            - retail()               → Retail sales volume
            - fdi()                  → Foreign Direct Investment flows
            - money_supply()         → Credit/Money supply (M0, M1, M2)
            - population_labor()     → Population and labor force statistics
        
        Returns:
            EconomyReference: Domain gateway for economy indicators
        
        Example:
            m = Macro()
            gdp_df = m.economy().gdp(length='5Y')  # Get 5 years of GDP data
        """
        return EconomyReference()
        
    def commodity(self) -> CommodityReference:
        """
        Access global and local commodity prices (Macro Layer - Commodity Domain).
        
        Methods available (11 total):
            - gold(market='VN'|'GLOBAL')        → Gold prices (Vietnam SJC or international futures)
            - gas(market='VN'|'GLOBAL')         → Gas prices (Vietnam RON/DO or natural gas futures)
            - oil_crude()                       → Crude oil futures (WTI, Brent)
            - coke()                            → Coal/Coke prices
            - steel(market='GLOBAL'|'VN')       → Steel (HRC1! global or D10 Vietnam)
            - iron_ore()                        → Iron ore prices
            - fertilizer_ure()                  → Urea fertilizer prices
            - soybean()                         → Soybean futures
            - corn()                            → Corn futures
            - sugar()                           → Sugar futures
            - pork(market='VN'|'CHINA')         → Pork prices (Vietnam or China market)
        
        Returns:
            CommodityReference: Domain gateway for commodity prices
        
        Example:
            m = Macro()
            gold_vn = m.commodity().gold(market='VN')
            gold_global = m.commodity().gold(market='GLOBAL')
            steel = m.commodity().steel(market='GLOBAL')
        """
        return CommodityReference()
        
    def currency(self) -> CurrencyReference:
        """
        Access foreign exchange rates and interest rate data (Macro Layer - Currency Domain).
        
        Methods available (2 total):
            - exchange_rate()       → Foreign exchange rates (USD, JPY, EUR, GBP, etc.) vs VND
            - interest_rate()       → VND deposit/lending rates (overnight, 1M, 3M, 6M, 12M)
        
        Returns:
            CurrencyReference: Domain gateway for currency and interest rates
        
        Example:
            m = Macro()
            fx_rates = m.currency().exchange_rate(length='1Y')
            int_rates = m.currency().interest_rate(length='1Y')
        """
        return CurrencyReference()
    
    # =====================================================
    # DEPRECATED LEGACY API (will be removed 31/8/2026)
    # =====================================================
    
    def _show_deprecation(self, method_name: str) -> None:
        """Show deprecation warning with migration guidance (bilingual: Vietnamese + English)."""
        new_method_map = {
            'gdp': 'Macro().economy().gdp()',
            'cpi': 'Macro().economy().cpi()',
            'industry_prod': 'Macro().economy().industry_prod()',
            'import_export': 'Macro().economy().import_export()',
            'retail': 'Macro().economy().retail()',
            'fdi': 'Macro().economy().fdi()',
            'money_supply': 'Macro().economy().money_supply()',
            'population_labor': 'Macro().economy().population_labor()',
            'exchange_rate': 'Macro().currency().exchange_rate()',
            'interest_rate': 'Macro().currency().interest_rate()',
        }
        
        new_api = new_method_map.get(method_name, f'Macro().economy().{method_name}()')
        warnings.warn(
            f"[DEPRECATED] Macro.{method_name}() cấu trúc method sẽ thay đổi sau 31/8/2026 sau ngày 31/8/2026. "
            f"Vui lòng sử dụng {new_api} thay thế. | "
            f"Macro.{method_name}() is deprecated and will be removed after 31/8/2026. "
            f"Please use {new_api} instead.",
            DeprecationWarning,
            stacklevel=3
        )
    
    def gdp(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "quarter",
        keep_label: bool = False,
        length: Optional[Union[str, int]] = None,
        **kwargs
    ) -> pd.DataFrame:
        """[DEPRECATED] GDP data. | Dữ liệu GDP — cấu trúc method sẽ thay đổi sau 31/8/2026, dùng Macro().economy().gdp() thay thế."""
        self._show_deprecation('gdp')
        return self.economy().gdp(
            start=start, end=end, period=period, keep_label=keep_label, length=length, **kwargs
        )

    def cpi(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "month",
        length: Optional[Union[str, int]] = None,
        **kwargs
    ) -> pd.DataFrame:
        """[DEPRECATED] Consumer Price Index. | Chỉ số giá tiêu dùng CPI — cấu trúc method sẽ thay đổi sau 31/8/2026, dùng Macro().economy().cpi() thay thế."""
        self._show_deprecation('cpi')
        return self.economy().cpi(start=start, end=end, period=period, length=length, **kwargs)

    def industry_prod(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "month",
        length: Optional[Union[str, int]] = None,
        **kwargs
    ) -> pd.DataFrame:
        """[DEPRECATED] Industrial Production. | Sản xuất công nghiệp — cấu trúc method sẽ thay đổi sau 31/8/2026, dùng Macro().economy().industry_prod() thay thế."""
        self._show_deprecation('industry_prod')
        return self.economy().industry_prod(start=start, end=end, period=period, length=length, **kwargs)

    def import_export(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "month",
        length: Optional[Union[str, int]] = None,
        **kwargs
    ) -> pd.DataFrame:
        """[DEPRECATED] Import-Export data. | Dữ liệu Xuất - Nhập khẩu — cấu trúc method sẽ thay đổi sau 31/8/2026, dùng Macro().economy().import_export() thay thế."""
        self._show_deprecation('import_export')
        return self.economy().import_export(start=start, end=end, period=period, length=length, **kwargs)

    def retail(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "month",
        length: Optional[Union[str, int]] = None,
        **kwargs
    ) -> pd.DataFrame:
        """[DEPRECATED] Retail sales. | Bán lẻ — cấu trúc method sẽ thay đổi sau 31/8/2026, dùng Macro().economy().retail() thay thế."""
        self._show_deprecation('retail')
        return self.economy().retail(start=start, end=end, period=period, length=length, **kwargs)

    def fdi(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "month",
        length: Optional[Union[str, int]] = None,
        **kwargs
    ) -> pd.DataFrame:
        """[DEPRECATED] Foreign Direct Investment. | Đầu tư trực tiếp nước ngoài FDI — cấu trúc method sẽ thay đổi sau 31/8/2026, dùng Macro().economy().fdi() thay thế."""
        self._show_deprecation('fdi')
        return self.economy().fdi(start=start, end=end, period=period, length=length, **kwargs)

    def money_supply(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "month",
        length: Optional[Union[str, int]] = None,
        **kwargs
    ) -> pd.DataFrame:
        """[DEPRECATED] Money Supply. | Tín dụng — cấu trúc method sẽ thay đổi sau 31/8/2026, dùng Macro().economy().money_supply() thay thế."""
        self._show_deprecation('money_supply')
        return self.economy().money_supply(start=start, end=end, period=period, length=length, **kwargs)

    def population_labor(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "year",
        length: Optional[Union[str, int]] = None,
        **kwargs
    ) -> pd.DataFrame:
        """[DEPRECATED] Population and Labor. | Dân số và lao động — cấu trúc method sẽ thay đổi sau 31/8/2026, dùng Macro().economy().population_labor() thay thế."""
        self._show_deprecation('population_labor')
        return self.economy().population_labor(start=start, end=end, period=period, length=length, **kwargs)

    def exchange_rate(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "day",
        length: Optional[Union[str, int]] = None,
        **kwargs
    ) -> pd.DataFrame:
        """[DEPRECATED] Exchange Rates. | Tỷ giá hối đoái — cấu trúc method sẽ thay đổi sau 31/8/2026, dùng Macro().currency().exchange_rate() thay thế."""
        self._show_deprecation('exchange_rate')
        return self.currency().exchange_rate(start=start, end=end, period=period, length=length, **kwargs)

    def interest_rate(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "day",
        format: str = "pivot",
        length: Optional[Union[str, int]] = None,
        **kwargs
    ) -> pd.DataFrame:
        """[DEPRECATED] Interest Rates. | Lãi suất — cấu trúc method sẽ thay đổi sau 31/8/2026, dùng Macro().currency().interest_rate() thay thế."""
        self._show_deprecation('interest_rate')
        return self.currency().interest_rate(start=start, end=end, period=period, format=format, length=length, **kwargs)
