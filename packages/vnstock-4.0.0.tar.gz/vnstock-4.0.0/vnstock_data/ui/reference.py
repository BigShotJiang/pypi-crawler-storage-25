"""
Reference Layer Entry Point.
"""

from vnstock_data.ui.domains.reference.company import CompanyReference
from vnstock_data.ui.domains.reference.industry import IndustryReference
from vnstock_data.ui.domains.reference.equity import EquityReference
from vnstock_data.ui.domains.reference.index import IndexReference
from vnstock_data.ui.domains.reference.derivatives import DerivativesReference, WarrantReference, FuturesReference
from vnstock_data.ui.domains.reference.fund import FundReference
from vnstock_data.ui.domains.reference.etf import ETFReference
from vnstock_data.ui.domains.reference.bond import BondReference
from vnstock_data.ui.domains.reference.events import EventsReference
from vnstock_data.ui.domains.reference.search import SearchReference
from vnstock_data.ui.domains.reference.market import MarketReference

class Reference:
    """
    Reference Data Layer (Layer 1).
    Provides access to static/master data for various domains.
    """
    
    def company(self, symbol: str) -> CompanyReference:
        """
        Access company-specific reference data.
        
        Args:
            symbol (str): Ticker symbol (e.g., 'VNM', 'TCB').
        """
        return CompanyReference(symbol)

    def futures(self, symbol: str = None) -> FuturesReference:
        """
        Access index futures reference data (listing or symbol-specific info).
        
        Args:
            symbol (str, optional): Futures symbol (e.g., 'VN30F2503', 'VN30F1M').
                                    If None, returns listing interface.
            
        Example:
            r = Reference()
            # List all futures indices
            futures_list = r.futures().list()
            
            # Get specific futures info
            futures_info = r.futures('VN30F2503').info()
        """
        return FuturesReference(symbol)

    def warrant(self, symbol: str = None) -> WarrantReference:
        """
        Access covered warrant reference data (info, specifications, pricing).
        
        Args:
            symbol (str): Warrant symbol (e.g., 'CACB2511', 'CACB25C100').
            
        Example:
            r = Reference()
            warrant_info = r.warrant('CACB2511').info()
        """
        return WarrantReference(symbol)

    @property
    def industry(self) -> IndustryReference:
        """Access industry reference data."""
        return IndustryReference()

    @property
    def fund(self) -> FundReference:
        """
        Master data for Mutual Funds (Chứng Chỉ Quỹ).
        """
        return FundReference()

    @property
    def etf(self) -> ETFReference:
        """Access ETF reference data."""
        return ETFReference()

    @property
    def equity(self) -> EquityReference:
        """Access equity reference data."""
        return EquityReference()

    @property
    def index(self) -> IndexReference:
        """Access index reference data."""
        return IndexReference()

    @property
    def bond(self) -> BondReference:
        """Access bond reference data."""
        return BondReference()

    @property
    def events(self) -> EventsReference:
        """Access events reference data (calendar, etc.)."""
        return EventsReference()

    @property
    def search(self) -> SearchReference:
        """Access global symbol search."""
        return SearchReference()

    @property
    def market(self) -> MarketReference:
        """Access live market status."""
        return MarketReference()

    def derivatives(self) -> DerivativesReference:
        """
        [DEPRECATED] Access derivatives reference data.
        
        To fix: Replace `Reference().derivatives().futures(symbol).info()` with `Reference().futures(symbol).info()`
        
        Examples:
            # Old way (will raise warning):
            r.derivatives().futures('VN30F2503').info()
            
            # New direct way:
            r.futures('VN30F2503').info()
        
        Returns:
            DerivativesReference: Provides access to .warrant() and .futures() sub-domains.
        """
        import warnings
        warnings.warn(
            "Reference.derivatives() is deprecated. Use Reference.futures(symbol) or Reference.warrant(symbol) directly. "
            "Example: r.futures('VN30F2503').info() instead of r.derivatives().futures('VN30F2503').info(). "
            "Deprecated method will be removed after 31/8/2026.",
            DeprecationWarning,
            stacklevel=2
        )
        return DerivativesReference()
