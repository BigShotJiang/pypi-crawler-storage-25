"""
Dukascopy Provider – OHLCV & Tick data module.

Market data from the Dukascopy Historical Data feed (jetta.dukas.com).

Available REST endpoints:
    GET /v1/candles/minute/{symbol}/{side}/{year}/{month}/{day}
        → Minute candles for one calendar day.
    GET /v1/candles/day/{symbol}/{side}
        → Full daily candle history (no date parameter).
    GET /v1/ticks/{symbol}/{year}/{month}/{day}/{hour}
        → Tick data for one hour.

All other timeframes (1h, 4h, 1w, 1M) are computed by resampling:
    1h / 4h  → fetch 1m data per day, resample
    1w / 1M  → fetch full daily history, resample

API Response Format
───────────────────
Dukascopy returns **delta-encoded** compressed arrays:
  - ``timestamp``  – Unix ms of the first bar's open time.
  - ``shift``      – Bar duration in ms.
  - ``multiplier`` – Price precision (e.g. 0.001 means integers represent 0.001 units).
  - ``times``      – Cumulative time-step deltas (int); absolute = timestamp + cumsum(times)*shift
  - ``opens/highs/lows/closes`` – Cumulative price deltas; absolute = open + cumsum(deltas)*multiplier
  - ``volumes``    – Raw (non-delta) volume values.
"""

from __future__ import annotations

import datetime
from typing import Optional, Union
from itertools import accumulate

import pandas as pd
import requests

from vnstock.core.utils.logger import get_logger
from vnai import agg_execution

logger = get_logger(__name__)

from vnstock_data.core.utils.user_agent import get_headers
from vnstock_data.explorer.dukas.const import _BASE_URL, _COMMON_SYMBOL_MAP, _SYMBOL_SUFFIX_PATTERN

def _clean_symbol(symbol: str) -> str:
    """Normalise a Dukascopy symbol code.

    Accepts both the verbose instrument code (e.g. ``USA500.IDX-USD``) and the
    short user-facing form (e.g. ``USA500``).  Both are converted to the exact
    code expected by the API.

    Currently a no-op transformation – the API accepts the full code directly.
    The helper exists as a central place to add further normalization if needed.
    """
    import re
    return re.sub(_SYMBOL_SUFFIX_PATTERN, '', symbol.strip().upper())

# Maps normalised interval → (fetch_endpoint, resample_rule | None)
# fetch_endpoint: 'minute' → per-day minute API, 'day' → full daily history API
_INTERVAL_FETCH = {
    '1m':  ('minute', None),
    '1h':  ('minute', '1h'),
    '4h':  ('minute', '4h'),
    '1d':  ('day',    None),
    '1w':  ('day',    '1W'),
    '1M':  ('day',    '1MS'),
}

# Intervals that need per-day minute fetching (slow – date-range iteration)
_MINUTE_BASED = {'1m', '1h', '4h'}


def _session() -> requests.Session:
    s = requests.Session()
    s.headers.update(get_headers('DUKASCOPY', random_agent=False, browser='chrome', platform='macos'))
    # Ensure JSON accept header is set explicitly for this API
    s.headers['accept'] = 'application/json, text/plain, */*'
    return s


def _decode_candles(data: dict, tz: str = 'Asia/Ho_Chi_Minh') -> pd.DataFrame:
    """Decode Dukascopy delta-compressed candle response into a DataFrame."""
    ts    = data['timestamp']
    mul   = data['multiplier']
    shift = data['shift']

    times  = list(accumulate(data['times']))
    opens  = list(accumulate(data['opens']))
    highs  = list(accumulate(data['highs']))
    lows   = list(accumulate(data['lows']))
    closes = list(accumulate(data['closes']))
    vols   = data.get('volumes', [0] * len(times))

    records = [
        {
            'time':   pd.Timestamp(ts + times[i] * shift, unit='ms'),
            'open':   opens[i]  * mul,
            'high':   highs[i]  * mul,
            'low':    lows[i]   * mul,
            'close':  closes[i] * mul,
            'volume': vols[i] if i < len(vols) else 0,
        }
        for i in range(len(times))
    ]
    df = pd.DataFrame(records)
    if not df.empty:
        # Convert Dukascopy GMT (UTC) epoch ms to requested TZ and retain naive format
        df['time'] = df['time'].dt.tz_localize('UTC').dt.tz_convert(tz).dt.tz_localize(None)
    return df


def _decode_ticks(data: dict, tz: str = 'Asia/Ho_Chi_Minh') -> pd.DataFrame:
    """Decode Dukascopy delta-compressed tick response into a DataFrame."""
    ts  = data['timestamp']
    mul = data['multiplier']

    times = list(accumulate(data['times']))
    asks  = list(accumulate(data['asks']))
    bids  = list(accumulate(data['bids']))
    ask_v = data.get('askVolumes', [])
    bid_v = data.get('bidVolumes', [])

    records = [
        {
            'time':       pd.Timestamp(ts + times[i], unit='ms'),
            'ask':        asks[i] * mul,
            'bid':        bids[i] * mul,
            'ask_volume': ask_v[i] if i < len(ask_v) else 0,
            'bid_volume': bid_v[i] if i < len(bid_v) else 0,
        }
        for i in range(len(times))
    ]
    df = pd.DataFrame(records)
    if not df.empty:
        df['time'] = df['time'].dt.tz_localize('UTC').dt.tz_convert(tz).dt.tz_localize(None)
        df['price'] = round((df['ask'] + df['bid']) / 2, 6)
    return df


def _safe_get(session: requests.Session, url: str) -> Optional[dict]:
    """GET with timeout. Returns None on 404 or empty data (no bars for that period)."""
    try:
        r = session.get(url, timeout=15)
    except requests.exceptions.Timeout:
        raise ConnectionError(f"Dukascopy timed out (15s): {url}")
    except requests.exceptions.RequestException as e:
        raise ConnectionError(f"Dukascopy connection error: {e}")

    if r.status_code == 404:
        return None
    if r.status_code != 200:
        raise ValueError(f"Dukascopy HTTP {r.status_code}: {url}")

    try:
        data = r.json()
    except Exception:
        return None

    return data if data and data.get('times') else None


class Quote:
    """
    Dukascopy market data – OHLCV (candles) and tick data.

    Supports Forex, Commodities, Global Indices, Stocks, and Crypto.

    Symbol format (use the ``code`` field from Dukascopy instruments list):
        FX:     ``EUR-USD``, ``USD-JPY``, ``GBP-USD``
        IDX:    ``USA500.IDX-USD``, ``GER30.IDX-EUR``, ``JPN225.IDX-JPY``
        CMD:    ``COFFEE.CMD-USX``, ``OIL.CMD-USD``, ``WHEAT.CMD-USX``
        STK:    ``AAPL.NYSE-USD``, ``AMZN.NSD-USD``
        CRYPTO: ``BTCUSD``, ``ETHUSD``

    Supported intervals: ``1m``, ``1h``, ``4h``, ``1d``, ``1w``, ``1M``

    Side options:
        ``'bid'`` (default), ``'ask'``, ``'mid'`` (average of bid + ask)

    Note:
        ``1h``, ``4h``, ``1w``, ``1M`` are computed by resampling lower-frequency data.
    """

    def __init__(self, symbol: str, show_log: bool = False, **kwargs):
        self.timezone = kwargs.get('timezone', 'Asia/Ho_Chi_Minh')
        # Accept both short form (EUR-USD) and verbose (EUR-USD.FX or USA500.IDX-USD)
        raw_sym = symbol.strip().upper()
        
        # 1. Fast path: check explicit hardcoded mapping for standard/divergent symbols
        if raw_sym in _COMMON_SYMBOL_MAP:
            self.symbol = _COMMON_SYMBOL_MAP[raw_sym]
        else:
            # 2. Lazy load listing to resolve short symbols to full API codes
            try:
                from vnstock_data.explorer.dukas.listing import Listing
                listing_data = Listing(show_log=False).all_symbols(to_df=False)
                
                # Exact match on full code
                matched = next((x for x in listing_data if x['code'].upper() == raw_sym), None)
                
                if not matched:
                    # Match on short friendly UI format, e.g. EURUSD or USA500
                    matched = next((x for x in listing_data if x['symbol'].upper() == raw_sym), None)
                    
                if not matched:
                    # Robust flat alphanumeric fallback for legacy symbols
                    import re
                    cleaned_input = re.sub(r'[^A-Z0-9]', '', raw_sym)
                    matched = next((x for x in listing_data if re.sub(r'[^A-Z0-9]', '', x['code'].upper()) == cleaned_input), None)
                
                self.symbol = matched['code'] if matched else raw_sym
            except Exception:
                self.symbol = raw_sym
            
        self.data_source = 'Dukascopy'
        self.show_log = show_log
        if not show_log:
            logger.setLevel('CRITICAL')

    # ── Internal helpers ──────────────────────────────────────────────────

    def _fetch_day_history(self, session: requests.Session, side: str) -> pd.DataFrame:
        """Fetch the full daily candle history (one request)."""
        url = f"{_BASE_URL}/candles/day/{self.symbol}/{side.upper()}"
        data = _safe_get(session, url)
        return _decode_candles(data, tz=self.timezone) if data else pd.DataFrame()

    def _fetch_minute_range(
        self,
        session: requests.Session,
        side: str,
        start_date: datetime.date,
        end_date: datetime.date,
    ) -> pd.DataFrame:
        """Fetch per-day minute candles over a date range."""
        frames = []
        current = start_date
        while current <= end_date:
            url = (
                f"{_BASE_URL}/candles/minute/{self.symbol}/{side.upper()}"
                f"/{current.year}/{current.month}/{current.day}"
            )
            data = _safe_get(session, url)
            if data:
                frames.append(_decode_candles(data, tz=self.timezone))
            current += datetime.timedelta(days=1)
        return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()

    def _mid(self, df_bid: pd.DataFrame, df_ask: pd.DataFrame) -> pd.DataFrame:
        """Compute mid-price from two equally-shaped bid/ask DataFrames."""
        if df_bid.empty:
            return pd.DataFrame()
        df = df_bid.copy()
        if not df_ask.empty and len(df_ask) == len(df_bid):
            for col in ('open', 'high', 'low', 'close'):
                df[col] = round((df[col] + df_ask[col]) / 2, 6)
        return df

    # ── Public API ────────────────────────────────────────────────────────

    @agg_execution("Dukascopy.ext")
    def history(
        self,
        start: str = "",
        end: str = "",
        interval: str = "1d",
        side: str = "bid",
        length: int = 500,
        to_df: bool = True,
        **kwargs,
    ) -> Union[pd.DataFrame, str]:
        """
        Fetch historical OHLCV candlestick data.

        Args:
            start (str): Start date ``YYYY-MM-DD``. Leave blank to use ``length``.
            end (str): End date ``YYYY-MM-DD``. Defaults to today (UTC).
            interval (str): Timeframe – ``1m``, ``1h``, ``4h``, ``1d``, ``1w``, ``1M``.
            side (str): Price side –
                ``'bid'`` (default), ``'ask'``, or ``'mid'`` (bid+ask midpoint).
            length (int): Maximum number of bars returned (tail truncation). Default 500.
            to_df (bool): Return DataFrame (default) or JSON string.

        Returns:
            pd.DataFrame: ``[time, open, high, low, close, volume]``

        Note:
            - ``1h``, ``4h`` are resampled from 1-minute data (slower).
            - ``1w``, ``1M`` are resampled from daily history.
            - All timestamps are timezone-naive UTC.
        """
        interval_norm = interval.strip()
        # Normalise aliases
        _alias = {'1H': '1h', '4H': '4h', '1D': '1d', '1W': '1w'}
        interval_norm = _alias.get(interval_norm.upper(), interval_norm.lower())
        # Keep 1M uppercase for pandas
        if interval_norm == '1m' and interval.endswith('M'):
            interval_norm = '1M'

        if interval_norm not in _INTERVAL_FETCH:
            supported_intervals = ", ".join(_INTERVAL_FETCH)
            raise ValueError(
                f"Interval '{interval}' not supported by Dukascopy. "
                f"Supported: {supported_intervals}"
            )

        fetch_endpoint, resample_rule = _INTERVAL_FETCH[interval_norm]
        use_side = side.lower()
        session  = _session()
        today    = datetime.datetime.utcnow().date()
        # For minute data, ensure we don't request future dates
        # API uses UTC, so we check against UTC date
        if end:
            end_date = pd.to_datetime(end).date()
            if end_date >= today:
                # If requested date is today or future, use previous available day
                end_date = today - datetime.timedelta(days=1)
        else:
            # Default to yesterday for minute data (most recent available)
            end_date = today - datetime.timedelta(days=1)

        # ── Per-day minute fetch ──────────────────────────
        if fetch_endpoint == 'minute':
            bars_per_day = {'1m': 1440, '1h': 24, '4h': 6}
            if not start:
                days_needed = max(5, (length // bars_per_day.get(interval_norm, 24)) + 3)
                start_date = end_date - datetime.timedelta(days=days_needed)
            else:
                start_date = pd.to_datetime(start).date()

            # Walk end_date back to last weekday (markets closed on weekends)
            fetch_end = end_date
            while fetch_end.weekday() >= 5:  # 5=Sat, 6=Sun
                fetch_end -= datetime.timedelta(days=1)

            if use_side == 'mid':
                df_bid = self._fetch_minute_range(session, 'BID', start_date, fetch_end)
                df_ask = self._fetch_minute_range(session, 'ASK', start_date, fetch_end)
                df = self._mid(df_bid, df_ask)
            else:
                df = self._fetch_minute_range(session, use_side.upper(), start_date, fetch_end)

        # ── Full daily history fetch ──────────────────────
        else:
            if use_side == 'mid':
                df_bid = self._fetch_day_history(session, 'BID')
                df_ask = self._fetch_day_history(session, 'ASK')
                df = self._mid(df_bid, df_ask)
            else:
                df = self._fetch_day_history(session, use_side.upper())

        if df.empty:
            return pd.DataFrame()

        # ── Resample if needed ────────────────────────────
        if resample_rule:
            df = df.set_index('time')
            df = (
                df.resample(resample_rule, label='left', closed='left')
                .agg({'open': 'first', 'high': 'max', 'low': 'min',
                      'close': 'last',  'volume': 'sum'})
                .dropna()
                .reset_index()
            )

        # ── Filter by start / end ─────────────────────────
        df = df.sort_values('time').reset_index(drop=True)
        if start:
            df = df[df['time'] >= pd.to_datetime(start)]
        if end:
            df = df[df['time'] <= pd.to_datetime(end_date) + pd.Timedelta(days=1)]

        # ── Tail truncation ───────────────────────────────
        df = df.tail(length).reset_index(drop=True)

        # Ensure tz-naive timestamps
        if hasattr(df['time'], 'dt') and df['time'].dt.tz is not None:
            df['time'] = df['time'].dt.tz_localize(None)

        df.source = self.data_source
        return df if to_df else df.to_json(orient='records')

    @agg_execution("Dukascopy.ext")
    def intraday(
        self,
        date: str = "",
        hour: int = None,
        to_df: bool = True,
        **kwargs,
    ) -> Union[pd.DataFrame, str]:
        """
        Fetch tick-level data for a specific date and UTC hour.

        Args:
            date (str): Date ``YYYY-MM-DD``. Defaults to today (UTC).
            hour (int | None): UTC hour (0–23). Defaults to the current UTC hour.
            to_df (bool): Return DataFrame (default) or JSON string.

        Returns:
            pd.DataFrame: ``[time, ask, bid, price, ask_volume, bid_volume]``
        """
        session = _session()
        now     = datetime.datetime.utcnow()
        d = pd.to_datetime(date).date() if date else now.date()
        h = hour if hour is not None else now.hour

        url = f"{_BASE_URL}/ticks/{self.symbol}/{d.year}/{d.month}/{d.day}/{h}"
        data = _safe_get(session, url)
        if not data:
            return pd.DataFrame()

        df = _decode_ticks(data, tz=self.timezone)
        if hasattr(df['time'], 'dt') and df['time'].dt.tz is not None:
            df['time'] = df['time'].dt.tz_localize(None)

        df.source = self.data_source
        return df if to_df else df.to_json(orient='records')


# Register provider
from vnstock_data.core.registry import ProviderRegistry  # noqa: E402, F401
ProviderRegistry.register('quote', 'dukascopy', Quote)
