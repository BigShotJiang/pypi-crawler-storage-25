"""
Dukascopy Provider – Listing module.

Instrument discovery for the Dukascopy data feed.
All symbols from https://jetta.dukascopy.com/v1/instruments,
organized and searchable by code, description, or instrument type.

Supported instrument types:
  FX    – Forex currency pairs (EUR-USD, USD-JPY, GBP-USD…)
  IDX   – Global indices (USA500.IDX-USD, GER30.IDX-EUR, JPN225.IDX-JPY…)
  CMD   – Commodities (XAUUSD.CMD-USD, XAGUSD.CMD-USD, COFFEE.CMD-USX…)
  STK   – Individual stocks (AAPL.NYSE-USD, META.NSD-USD…)
  CFD   – Contract-for-Difference instruments
  CRYPTO– Cryptocurrencies (BTCUSD, ETHUSD…)
"""

from typing import Optional, Union
import re as _re
import pandas as pd
import requests

from vnstock.core.utils.logger import get_logger
from vnstock_data.core.utils.user_agent import get_headers
from vnai import agg_execution

logger = get_logger(__name__)

from vnstock_data.explorer.dukas.const import (
    _BASE_URL,
    _SYMBOL_SUFFIX_PATTERN,
    _PLATFORM_GROUP_MAP
)

# Removes verbose API-specific suffixes for user-facing symbol display.
_SUFFIX_RE = _re.compile(_SYMBOL_SUFFIX_PATTERN)

def _clean_code(code: str) -> str:
    """Return user-friendly symbol: strip exchange/asset-class suffixes and hyphens.
    e.g. EUR-USD -> EURUSD.
    """
    cleaned = _SUFFIX_RE.sub('', code)
    return cleaned.replace('-', '')

class Listing:
    """
    Dukascopy instrument discovery.

    Retrieves the full catalogue from ``GET /v1/instruments``
    and provides filtering/search utilities.

    Supported instrument types
    ──────────────────────────
    FX      Currency pairs        EUR-USD, USD-JPY, GBP-USD
    IDX     Global indices        USA500.IDX-USD, GER30.IDX-EUR
    CMD     Commodities           XAUUSD.CMD-USD, COFFEE.CMD-USX
    STK     Individual stocks     AAPL.NYSE-USD, META.NSD-USD
    CFD     CFDs
    CRYPTO  Cryptocurrencies      BTCUSD, ETHUSD

    Example
    -------
    >>> from vnstock_data import Reference
    >>> ref = Reference()
    >>> ref.instruments().all_symbols(instrument_type='IDX')
    """

    def __init__(self, show_log: bool = False, **kwargs):
        self.data_source = 'Dukascopy'
        self.base_url = _BASE_URL
        self.show_log = show_log
        if not show_log:
            logger.setLevel('CRITICAL')

    def _fetch_instruments(self) -> list:
        try:
            r = requests.get(
                f"{self.base_url}/instruments",
                headers=get_headers('DUKASCOPY', random_agent=False, browser='chrome', platform='macos'),
                timeout=15,
            )
        except requests.exceptions.Timeout:
            raise ConnectionError("Dukascopy instruments request timed out (15s). Check network.")
        except requests.exceptions.RequestException as e:
            raise ConnectionError(f"Dukascopy connection error: {e}")

        if r.status_code != 200:
            raise ValueError(f"Dukascopy instruments error: HTTP {r.status_code}")

        data = r.json()
        return data.get('instruments', data) if isinstance(data, dict) else data

    @agg_execution("Dukascopy.ext")
    def all_symbols(
        self,
        instrument_type: Optional[str] = None,
        to_df: bool = True,
    ) -> Union[pd.DataFrame, list]:
        """
        Retrieve the full instrument catalogue from Dukascopy.

        Args:
            instrument_type (str | None): Filter by type – ``'FX'``, ``'IDX'``,
                ``'CMD'``, ``'STK'``, ``'CFD'``, ``'CRYPTO'``. ``None`` = all.
            to_df (bool): Return DataFrame (default) or raw list.

        Returns:
            pd.DataFrame: Schema ``[code, name, description, type, country_code,
                pip_value, price_scale]``
        """
        raw = self._fetch_instruments()

        records = []
        for item in raw:
            group = item.get('platformGroupId', '')
            itype = _PLATFORM_GROUP_MAP.get(group, group)
            raw_code = item.get('code', '')
            records.append({
                'symbol':       _clean_code(raw_code),   # user-friendly short code
                'code':         raw_code,                 # full API code (for direct use)
                'name':         item.get('name', ''),
                'description':  item.get('description', '') or '',
                'type':         itype,
                'country_code': item.get('countryCode', ''),
                'pip_value':    item.get('pipValue'),
                'price_scale':  item.get('priceScale'),
            })

        if instrument_type:
            itype_filter = instrument_type.upper()
            records = [r for r in records if r['type'] == itype_filter]

        itype_str = instrument_type or 'all'
        if self.show_log:
            logger.info(f"Dukascopy: {len(records)} instruments found (type={itype_str})")

        if not to_df:
            return records

        df = pd.DataFrame(records)
        df.source = self.data_source
        return df

    @agg_execution("Dukascopy.ext")
    def search_symbol(
        self,
        query: str,
        instrument_type: Optional[str] = None,
        to_df: bool = True,
    ) -> Union[pd.DataFrame, list]:
        """
        Search instruments by keyword (matches code or description).

        Args:
            query (str): Search keyword.
            instrument_type (str | None): Optional type filter.
            to_df (bool): Return DataFrame or raw list.

        Returns:
            pd.DataFrame: Filtered instrument list.
        """
        df = self.all_symbols(instrument_type=instrument_type, to_df=True)
        if df.empty:
            return df

        q = query.lower()
        mask = (
            df['symbol'].str.lower().str.contains(q, na=False) |
            df['code'].str.lower().str.contains(q, na=False) |
            df['description'].str.lower().str.contains(q, na=False)
        )
        result = df[mask].reset_index(drop=True)

        if self.show_log:
            logger.info(f"Dukascopy search '{query}': {len(result)} results")

        if not to_df:
            return result.to_dict('records')
        return result


# Register provider
from vnstock_data.core.registry import ProviderRegistry  # noqa: E402, F401
ProviderRegistry.register('listing', 'dukascopy', Listing)
