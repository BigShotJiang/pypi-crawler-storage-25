"""Constants and hardcoded symbol mappings for the Dukascopy data provider."""

_BASE_URL = "https://jetta.dukascopy.com/v1"

# API suffix patterns that appear in Dukascopy symbol codes.
# These are stripped from the symbol before sending the API request so that
# users can pass cleaner identifiers (e.g. "USA500" instead of "USA500.IDX-USD").
# Full verbose codes from the instruments list are also accepted as-is.
_SYMBOL_SUFFIX_PATTERN = r'(?:\.(?:IDX|CMD|NYSE|NSD|LMAX|SB)[\-/][A-Z]{3})?$'

_PLATFORM_GROUP_MAP = {
    'FX_MAJOR':   'FX',
    'FX_MINOR':   'FX',
    'FX_EXOTIC':  'FX',
    'FX_METAL':   'METAL',
    'BULLION':    'METAL',
    'CFD_CMD':    'CMD',
    'CFD_IDX':    'IDX',
    'CFD_STK':    'STK',
    'CFD_CRYPTO': 'CRYPTO',
    'CFD_ETF':    'ETF'
}

# Explicit mapping for commonly used global symbols (e.g. TradingView / generic standard)
# to Dukascopy's specific naming conventions. This acts as a reliable fast-path to prevent
# fuzzy mapping assumptions.
_COMMON_SYMBOL_MAP = {
    # ------------------
    # Indices (IDX)
    # ------------------
    "SPX":      "USA500.IDX-USD",   # S&P 500 Index
    "USA500":   "USA500.IDX-USD",
    "NDX":      "USATECH.IDX-USD",  # Nasdaq 100 Tech Index
    "USATECH":  "USATECH.IDX-USD",
    "US100":    "USATECH.IDX-USD",
    "DJI":      "USA30.IDX-USD",    # Dow Jones Industrial Average 30
    "USA30":    "USA30.IDX-USD",
    "RUT":      "USSC2000.IDX-USD", # US Small Cap 2000 (Russell 2000)
    "VIX":      "VOL.IDX-USD",      # Volatility Index
    "DXY":      "DOLLAR.IDX-USD",   # US Dollar Index
    
    "GER30":    "DEU.IDX-EUR",      # DAX (Germany 40)
    "GER40":    "DEU.IDX-EUR",
    "DAX":      "DEU.IDX-EUR",
    "UK100":    "GBR.IDX-GBP",      # FTSE 100
    "FTSE":     "GBR.IDX-GBP",
    "EU50":     "EUS.IDX-EUR",      # EuroStoxx 50
    "EUSTX50":  "EUS.IDX-EUR",
    "FRA40":    "FRA.IDX-EUR",      # CAC 40
    "CAC40":    "FRA.IDX-EUR",
    
    "JPN225":   "JPN.IDX-JPY",      # Nikkei 225
    "NK225":    "JPN.IDX-JPY",
    "HK50":     "HKG.IDX-HKD",      # Hang Seng
    "HSI":      "HKG.IDX-HKD",
    "AUS200":   "AUS.IDX-AUD",      # ASX 200 (Australia)
    "CHINA50":  "CHI.IDX-USD",      # China A50
    "SGP":      "SGD.IDX-SGD",      # Singapore Blue Chip
    "ESP35":    "ESP.IDX-EUR",      # Spain 35
    "ITA40":    "ITA.IDX-EUR",      # Italy 40
    "NLD25":    "NLD.IDX-EUR",      # Netherlands 25
    "PLN20":    "PLN.IDX-PLN",      # Poland 20
    "ZAR40":    "SOA.IDX-ZAR",      # South Africa 40
    "USBD10Y":  "BND.IDX-USD",      # US Bond 10 YR
    
    # ------------------
    # Commodities (CMD)
    # ------------------
    "WTI":      "LIGHT.CMD-USD",    # WTI Crude Oil
    "USOIL":    "LIGHT.CMD-USD",
    "UKOIL":    "BRENT.CMD-USD",    # Brent Crude Oil
    "BRENT":    "BRENT.CMD-USD",
    "NATGAS":   "GAS.CMD-USD",      # Natural Gas
    "NG":       "GAS.CMD-USD",
    "GAS":      "GAS.CMD-USD",
    "COPPER":   "COPPER.CMD-USD",   # Copper
    "HGCOPPER": "HGCOPPER.CMD-USD", # High Grade Copper
    "COFFEE":   "COFFEE.CMD-USX",   # Coffee
    "COCOA":    "COCOA.CMD-USX",    # Cocoa
    "COTTON":   "COTTON.CMD-USX",   # Cotton
    "SUGAR":    "SUGAR.CMD-USD",    # Sugar
    "SOYBEAN":  "SOYBEAN.CMD-USX",  # Soybean
    "OJUICE":   "OJUICE.CMD-USX",   # Orange Juice
    "DIESEL":   "DIESEL.CMD-USD",   # Diesel
    
    # ------------------
    # Metals (METAL)
    # ------------------
    "XAUUSD":   "XAU-USD",          # Gold vs USD
    "XAUEUR":   "XAU-EUR",          # Gold vs EUR
    "XAGUSD":   "XAG-USD",          # Silver vs USD
    "XAGEUR":   "XAG-EUR",          # Silver vs EUR
    "PLAT":     "PLAT.CMD-USD",     # Platinum (classified as CMD)
    "PALLAD":   "PALLAD.CMD-USD",   # Palladium (classified as CMD)
}
