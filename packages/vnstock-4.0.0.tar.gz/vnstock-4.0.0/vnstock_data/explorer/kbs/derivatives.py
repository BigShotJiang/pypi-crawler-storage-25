"""
Patchwork data source for KBS Covered Warrants.
"""

import pandas as pd
import requests
from vnstock_data.core.registry import ProviderRegistry

class KBSDerivatives:
    """
    KBS implementation for fetching derivatives data (Warrants, Futures).
    """
    def __init__(self, symbol: str = None):
        """Standard detail provider initialization."""
        self.symbol = symbol

    def warrant_profile(self, symbol: str = None) -> pd.DataFrame:
        """
        Fetch the detailed profile and realtime statistics of a covered warrant.
        
        Args:
            symbol (str): Optional warrant symbol. Defaults to instance symbol.
        """
        target_symbol = symbol or self.symbol
        if not target_symbol:
            raise ValueError("Warrant symbol is required")
            
        url = "https://kbbuddywts.kbsec.com.vn/iis-server/investment/stock/iss"
        headers = {
            "sec-ch-ua-platform": '"macOS"',
            "Referer": "https://kbbuddywts.kbsec.com.vn/",
            "sec-ch-ua": '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
            "sec-ch-ua-mobile": "?0",
            "x-lang": "vi",
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36",
            "Accept": "application/json, text/plain, */*",
            "DNT": "1",
            "Content-Type": "application/json"
        }
        data = {"code": target_symbol}
        
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        
        json_data = response.json()
        if not json_data:
            return pd.DataFrame()
            
        df = pd.DataFrame(json_data)
        
        # Normalize exchange codes
        from vnstock_data.explorer.kbs.const import _EXCHANGE_CODE_MAP
        if "EX" in df.columns:
            df["EX"] = df["EX"].map(lambda x: _EXCHANGE_CODE_MAP.get(x, x) if pd.notna(x) else x)
        
        # Convert pricing columns from VND to thousands of VND (ngàn đồng) to match convention
        price_cols = ["EP", "CPR", "RE", "CL", "FL", "CP", "AP", "B1", "B2", "B3", "S1", "S2", "S3", "OP"]
        for col in price_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce') / 1000

        # Standardize warrant type
        if "CWT" in df.columns:
            warrant_type_map = {"C": "Call", "P": "Put"}
            df["CWT"] = df["CWT"].map(lambda x: warrant_type_map.get(str(x).upper(), x))

        # Calculate Break Even Point & Indicators (if necessary columns are present)
        # Ratio ER is purely string "2:1" or similar in KBS
        if "EP" in df.columns and "ER" in df.columns and "CP" in df.columns:
            try:
                # Extract numeric ratio (e.g. "2:1" -> 2.0 / 1.0 = 2.0)
                # Some ratios might be "5.000:1" or "2:1"
                ratio_str = df["ER"].astype(str).str.split(':')
                ratio_val = pd.to_numeric(ratio_str.str[0], errors='coerce') / pd.to_numeric(ratio_str.str[1], errors='coerce')
                
                # Break Even Point (Điểm hoà vốn) = Exercise Price + (Warrant Match Price * Ratio)
                # Note: This formula is for Call Warrants (CWT='C')
                # KBS Data: EP, CP are now in thousands
                # CWT is Call/'C' or Put/'P'. usually vnmarket only has Call warrants.
                
                df["break_even_point"] = df["EP"] + (df["CP"] * ratio_val)
                
                if "CPR" in df.columns:
                    # ĐHV - Giá TT = break_even_point - current_underlying_price
                    df["break_even_point_diff"] = df["break_even_point"] - df["CPR"]
                    # Intrinsic Value (Giá trị nội tại) = max(0, Underlying Price - Exercise Price) / Ratio
                    df["intrinsic_value"] = ((df["CPR"] - df["EP"]) / ratio_val).clip(lower=0)
            except Exception:
                pass
            
        return df

    def future_profile(self, symbol: str = None) -> pd.DataFrame:
        """
        Fetch the detailed profile and realtime statistics of an index future.
        
        Args:
            symbol (str): Optional futures symbol. Defaults to instance symbol.
        """
        from vnstock_data.explorer.kbs.const import _DERIVATIVE_MAP
        from vnstock_data.core.utils.parser import safe_convert_derivative_symbol
        target_symbol = symbol or self.symbol
        if not target_symbol:
            raise ValueError("Future symbol is required")
            
        target_symbol = safe_convert_derivative_symbol(target_symbol)
            
        url = "https://kbbuddywts.kbsec.com.vn/iis-server/investment/derivative/iss"
        headers = {
            "sec-ch-ua-platform": '"macOS"',
            "Referer": "https://kbbuddywts.kbsec.com.vn/DER",
            "sec-ch-ua": '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
            "sec-ch-ua-mobile": "?0",
            "x-lang": "vi",
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36",
            "Accept": "application/json, text/plain, */*",
            "DNT": "1",
            "Content-Type": "application/json"
        }
        data = {"code": target_symbol}
        
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        
        json_data = response.json()
        if not json_data:
            return pd.DataFrame()
            
        if isinstance(json_data, dict) and 'data' in json_data:
            json_data = json_data['data']
            
        if not isinstance(json_data, list):
            return pd.DataFrame()
            
        df = pd.DataFrame(json_data)
        
        # Apply column mapping
        df = df.rename(columns=_DERIVATIVE_MAP)
        
        # Normalize exchange codes
        from vnstock_data.explorer.kbs.const import _EXCHANGE_CODE_MAP
        if 'exchange' in df.columns:
            df['exchange'] = df['exchange'].map(
                lambda x: _EXCHANGE_CODE_MAP.get(x, x) if pd.notna(x) else x
            )
        
        # Convert timestamp to datetime
        if 'time' in df.columns:
            df['time'] = pd.to_datetime(df['time'], unit='ms', errors='coerce')
            
        # Select basic profile columns to avoid repeating price board data
        profile_cols = [
            'symbol', 'full_name', 'underlying_symbol', 'exchange',
            'first_trading_date', 'last_trading_date',
            'reference_price', 'ceiling_price', 'floor_price',
            'open_price', 'high_price', 'low_price', 'close_price',
            'open_interest', 'basis', 'foreign_buy_volume', 'foreign_sell_volume'
        ]
        
        # Keep only available columns
        available_cols = [col for col in profile_cols if col in df.columns]
        df = df[available_cols]
        
        return df


# Register the patchwork source dynamically
ProviderRegistry.register('derivatives', 'kbs', KBSDerivatives)
