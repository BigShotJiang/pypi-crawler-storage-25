"""Trading module for KB Securities (KBS) data source."""

import pandas as pd
import json
import re
from datetime import datetime
from typing import Optional, List
from vnai import agg_execution
from vnstock.core.utils.logger import get_logger
from vnstock.core.utils.parser import get_asset_type, camel_to_snake
from vnstock.core.utils.client import send_request, ProxyConfig
from vnstock_data.core.utils.user_agent import get_headers
from vnstock_data.explorer.kbs.const import (
    _IIS_BASE_URL, _STOCK_TRADE_HISTORY_URL,
    _PUT_THROUGH_HISTORY_URL, _STOCK_MATCHED_BY_PRICE_URL,
    _STOCK_ISS_URL, _ODD_LOT_ISS_URL, _PUT_THROUGH_ISS_URL, _DERIVATIVE_ISS_URL,
    _PRICE_BOARD_MAP, _ODD_LOT_MAP, _TRADE_HISTORY_MAP,
    _PUT_THROUGH_MAP, _MATCHED_BY_PRICE_MAP, _DERIVATIVE_MAP,
    _INDEX_SUMMARY_URL, _INDEX_SUMMARY_MAP, _INDEX_SYMBOL_TO_CODE,
    _PRICE_BOARD_STANDARD_COLUMNS, _PUT_THROUGH_STANDARD_COLUMNS, _DERIVATIVE_STANDARD_COLUMNS,
    _KBS_TO_SCHEMA_MAP, _EXCLUDED_COLUMNS, _EXCHANGE_CODE_MAP
)

logger = get_logger(__name__)


class Trading:
    """
    Lớp truy cập dữ liệu giao dịch từ KB Securities (KBS).
    """

    def __init__(
        self,
        symbol: Optional[str] = None,
        random_agent: Optional[bool] = False,
        proxy_config: Optional[ProxyConfig] = None,
        show_log: Optional[bool] = False,
        proxy_mode: Optional[str] = None,
        proxy_list: Optional[List[str]] = None,
    ):
        """
        Khởi tạo Trading client cho KBS.

        Args:
            symbol: Mã chứng khoán (VD: 'ACB', 'VNM'). Optional cho market-wide queries.
            random_agent: Sử dụng user agent ngẫu nhiên. Mặc định False.
            proxy_config: Cấu hình proxy. Mặc định None.
            show_log: Hiển thị log debug. Mặc định False.
            proxy_mode: Chế độ proxy (try, rotate, random, single). Mặc định None.
            proxy_list: Danh sách proxy URLs. Mặc định None.
        """
        self.symbol = symbol.upper() if symbol else None
        self.data_source = 'KBS'
        self.base_url = _IIS_BASE_URL
        self.headers = get_headers(data_source=self.data_source, random_agent=random_agent)
        self.show_log = show_log
        
        # Handle proxy configuration
        if proxy_config is None:
            # Create ProxyConfig from individual arguments
            p_mode = proxy_mode if proxy_mode else 'try'
            # If user provides list, set request_mode to PROXY
            req_mode = 'direct'
            if proxy_list and len(proxy_list) > 0:
                req_mode = 'proxy'
                
            self.proxy_config = ProxyConfig(
                proxy_mode=p_mode,
                proxy_list=proxy_list,
                request_mode=req_mode
            )
        else:
            self.proxy_config = proxy_config

        if self.symbol:
            self.asset_type = get_asset_type(self.symbol)

        if not show_log:
            logger.setLevel('CRITICAL')

    @agg_execution("KBS.ext")
    def price_history(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        limit: int = 1000,
        page: int = 1,
        show_log: Optional[bool] = False,
    ) -> pd.DataFrame:
        """
        Truy xuất dữ liệu lịch sử giá kết hợp giao dịch khớp lệnh/thoả thuận (OHLCV + Stats)
        Hàm này mô phỏng sát nhất với cấu trúc price_history truyền thống của VCI.
        
        Args:
            start: Ngày bắt đầu (YYYY-MM-DD).
            end: Ngày kết thúc (YYYY-MM-DD).
            limit: Số bản ghi trả về tối đa.
            page: Phân trang (offset/page index).
            
        Returns:
            DataFrame dữ liệu lịch sử.
        """
        if not self.symbol:
            raise ValueError("Symbol is required for price_history method.")
            
        url = f'{_IIS_BASE_URL}/{self.symbol}/historical-quotes'
        params = {
            'limit': limit,
            'offset': page
        }
        
        if start and end:
            params['startDate'] = start
            params['endDate'] = end
            
        json_data = send_request(
            url=url,
            headers=self.headers,
            method="GET",
            params=params,
            show_log=show_log or self.show_log,
            proxy_list=self.proxy_config.proxy_list,
            proxy_mode=self.proxy_config.proxy_mode,
            request_mode=self.proxy_config.request_mode
        )
        
        if not json_data:
            return pd.DataFrame()
            
        df = pd.DataFrame(json_data)
        if df.empty:
            return df
            
        # Map cột theo schema chung (tương tự VCI)
        rename_map = {
            'TradingDate': 'trading_date',
            'StockCode': 'symbol',
            'Change': 'price_change',
            'PerChange': 'percent_price_change',
            'ClosePrice': 'close',
            'MT_TotalVol': 'matched_volume',
            'MT_TotalVal': 'matched_value',
            'PT_TotalVol': 'deal_volume',
            'PT_TotalVal': 'deal_value',
            'AvrPrice': 'average_price',
            'HighestPrice': 'high',
            'LowestPrice': 'low',
            'TotalBuyTrade': 'total_buy_trade',
            'TotalBuyVol': 'total_buy_trade_volume',
            'TotalSellTrade': 'total_sell_trade',
            'TotalSellVol': 'total_sell_trade_volume',
            'CeilingPrice': 'ceiling_price',
            'FloorPrice': 'floor_price'
        }
        
        df = df.rename(columns=rename_map)
        
        if 'trading_date' in df.columns:
            df['trading_date'] = pd.to_datetime(df['trading_date'], format='%d/%m/%Y', errors='coerce')
            
        # Tính toán open bằng close - change hoặc tổng volume
        if 'matched_volume' in df.columns and 'deal_volume' in df.columns:
            df['total_volume'] = df['matched_volume'] + df['deal_volume']
        if 'matched_value' in df.columns and 'deal_value' in df.columns:
            df['total_value'] = df['matched_value'] + df['deal_value']
            
        if 'symbol' in df.columns:
            df = df.drop(columns=['symbol'])
            
        df.attrs['symbol'] = self.symbol
        df.attrs['source'] = self.data_source
        return df

    @agg_execution("KBS.ext")
    def order_stats(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        limit: int = 1000,
        page: int = 1,
        show_log: Optional[bool] = False,
    ) -> pd.DataFrame:
        """
        Khởi tạo alias cho thống kê cung cầu (Order Statistics).
        Vì KBS đã trả về thông tin Tổng Lượng Mua/Bán trong dữ liệu Historical Quotes,
        ta uỷ quyền qua price_history.
        """
        df = self.price_history(start=start, end=end, limit=limit, page=page, show_log=show_log)
        if df.empty:
            return df
        # Loc các field cần thiết
        expected_cols = [
            'trading_date', 'close', 'average_price', 'price_change',
            'matched_volume', 'total_buy_trade_volume', 'total_sell_trade_volume',
            'total_buy_trade', 'total_sell_trade',
        ]
        available_cols = [c for c in expected_cols if c in df.columns]
        df = df[available_cols]
        df.attrs['category'] = 'order_stats'
        df.attrs['symbol'] = self.symbol
        return df

    @agg_execution("KBS.ext")
    def foreign_trade(self, top: int = 10, show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Lấy top Giao dịch của nhà đầu tư nước ngoài (Realtime Ranking).
        API này trả về top các mã dựa trên ranking chứ không truy xuất theo từng mã (KBS không cấp).
        Do đó nếu self.symbol đã gán, API này sẽ lờ đi và dùng `top`.
        """
        url = f'{_IIS_BASE_URL}/rtranking/foreignTotal'
        params = {'top': top}
        json_data = send_request(
            url=url, headers=self.headers, method="GET", params=params, 
            show_log=show_log or self.show_log, proxy_list=self.proxy_config.proxy_list,
            proxy_mode=self.proxy_config.proxy_mode, request_mode=self.proxy_config.request_mode
        )
        if not json_data:
            return pd.DataFrame()
        df = pd.DataFrame(json_data)
        # Mapping properties
        rename_map = {
            'SB': 'symbol', 'EX': 'exchange', 'RE': 'reference_price',
            'CL': 'ceiling_price', 'FL': 'floor_price', 'CP': 'match_price',
            'FB': 'foreign_buy_volume', 'FS': 'foreign_sell_volume', 'FT': 'foreign_total_volume'
        }
        df = df.rename(columns=rename_map)
        df.attrs['category'] = 'foreign_trade'
        df.attrs['source'] = self.data_source
        return df



    @agg_execution("KBS.ext")
    def matched_by_price(
        self,
        show_log: Optional[bool] = False,
    ) -> pd.DataFrame:
        """
        Truy xuất dữ liệu khớp lệnh theo từng mức giá.

        Args:
            show_log: Hiển thị log debug.

        Returns:
            DataFrame chứa dữ liệu khớp lệnh theo giá với các cột chuẩn hóa.

        Examples:
            >>> trading = Trading('ACB')
            >>> df = trading.matched_by_price()

        Raises:
            ValueError: Nếu không có symbol được chỉ định.
        """
        if not self.symbol:
            raise ValueError("Symbol is required for matched_by_price method.")

        url = f'{_STOCK_MATCHED_BY_PRICE_URL}/{self.symbol}'

        json_data = send_request(
            url=url,
            headers=self.headers,
            method="GET",
            show_log=show_log or self.show_log,
            proxy_list=self.proxy_config.proxy_list,
            proxy_mode=self.proxy_config.proxy_mode,
            request_mode=self.proxy_config.request_mode
        )

        if not json_data:
            return pd.DataFrame()

        # Convert to DataFrame
        df = pd.DataFrame(json_data)

        # Apply column mapping
        df = df.rename(columns=_MATCHED_BY_PRICE_MAP)

        # Add metadata
        df.attrs['symbol'] = self.symbol
        df.attrs['source'] = self.data_source

        if show_log or self.show_log:
            logger.info(
                f'Truy xuất thành công dữ liệu khớp lệnh theo giá cho {self.symbol}.'
            )

        return df

    @agg_execution("KBS.ext")
    def index_summary(
        self,
        show_log: Optional[bool] = False,
    ) -> pd.DataFrame:
        """
        Truy xuất thông tin tóm tắt (Snapshot) cho các chỉ số thị trường.

        Chấp nhận mã symbol (VNINDEX, VN30, ...) và tự động mapping sang mã KBS (HOSE, 30, ...).
        Nếu không có symbol, mặc định lấy toàn bộ các chỉ số chính.

        Args:
            show_log: Hiển thị log debug.

        Returns:
            DataFrame chứa thông tin tóm tắt chỉ số với các cột chuẩn hóa.
        """
        import requests

        url = _INDEX_SUMMARY_URL
        
        # Determine codes to fetch
        if self.symbol:
            target_code = _INDEX_SYMBOL_TO_CODE.get(self.symbol)
            if not target_code:
                # Fallback to symbol if not in mapping, but likely invalid for this endpoint
                target_code = self.symbol
            payload = {'code': target_code}
        else:
            # Default to all major indices
            payload = {'code': 'HOSE,30,100,HNX,HNX30,UPCOM'}

        try:
            # Build headers
            headers_index = self.headers.copy()
            headers_index.update({
                'Accept-Language': 'en-US,en;q=0.9,vi;q=0.8',
                'Connection': 'keep-alive',
                'Content-Type': 'application/json',
                'DNT': '1',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-origin',
                'x-lang': 'vi'
            })
            
            response = requests.post(
                url,
                headers=headers_index,
                data=json.dumps(payload),
                timeout=30
            )
            if response.status_code in [200, 201]:
                json_data = response.json()
            else:
                return pd.DataFrame()
        except Exception as e:
            if show_log or self.show_log:
                logger.error(f"Failed to fetch index summary data: {str(e)}")
            return pd.DataFrame()

        if not json_data or not isinstance(json_data, list):
            return pd.DataFrame()

        # Convert to DataFrame
        df = pd.DataFrame(json_data)

        # Apply column mapping
        df = df.rename(columns=_INDEX_SUMMARY_MAP)

        # Reverse map symbols if possible
        # KBS codes to our standard symbols
        code_to_symbol = {v: k for k, v in _INDEX_SYMBOL_TO_CODE.items()}
        if 'MC' in json_data[0]: # MC is the original key for code
             # We need to find the raw code to reverse map
             df['symbol'] = df['MC'].map(lambda x: code_to_symbol.get(str(x), x))
        
        # Scale prices
        price_cols = [
            'close_price', 'price_change', 'open_price', 'high_price', 
            'low_price', 'reference_price', 'previous_close'
        ]
        for col in price_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        
        # Scale values and volumes
        num_cols = [
            'accumulated_volume', 'accumulated_value', 'total_volume',
            'put_through_value', 'put_through_volume', 'advances', 'declines', 'no_change'
        ]
        for col in num_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')

        # Convert timestamp
        if 'timestamp' in df.columns:
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms', errors='coerce')

        # Add metadata
        df.attrs['source'] = self.data_source
        if self.symbol:
            df.attrs['symbol'] = self.symbol

        if show_log or self.show_log:
            logger.info(f'Truy xuất thành công tóm tắt cho {len(df)} chỉ số.')

        return df

    def _fetch_stock_board(
        self,
        symbols_list: List[str],
        show_log: Optional[bool] = False,
    ) -> pd.DataFrame:
        """
        Fetch stock board (lô chẵn) data from /stock/iss endpoint.
        
        Args:
            symbols_list: List of stock symbols.
            show_log: Show debug logs.
            
        Returns:
            DataFrame with stock board data.
        """
        import requests
        
        if isinstance(symbols_list, str):
            symbols_list = [symbols_list]
            
        url = _STOCK_ISS_URL
        payload = {'code': ','.join(symbols_list)}
        
        try:
            # Build headers for stock ISS endpoint
            headers_stock = self.headers.copy()
            headers_stock.update({
                'Accept-Language': 'en-US,en;q=0.9,vi;q=0.8',
                'Connection': 'keep-alive',
                'Content-Type': 'application/json',
                'DNT': '1',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-origin',
                'x-lang': 'vi'
            })
            
            response = requests.post(
                url,
                headers=headers_stock,
                data=json.dumps(payload),
                timeout=30
            )
            if response.status_code in [200, 201]:
                json_data = response.json()
            else:
                return pd.DataFrame()
        except Exception as e:
            if show_log or self.show_log:
                logger.error(f"Failed to fetch stock board data: {str(e)}")
            return pd.DataFrame()
        
        if not json_data or not isinstance(json_data, list):
            return pd.DataFrame()
        
        # Convert to DataFrame
        df = pd.DataFrame(json_data)
        
        # Apply column mapping
        df = df.rename(columns=_PRICE_BOARD_MAP)
        
        # Convert timestamp to datetime
        if 'timestamp' in df.columns:
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms', errors='coerce')
        
        return df

    def _fetch_put_through_board(
        self,
        symbols_list: List[str],
        show_log: Optional[bool] = False,
    ) -> pd.DataFrame:
        """
        Fetch put-through board (thỏa thuận) data.
        
        Note: The put-through ISS endpoint doesn't exist. Use put_through() method instead
        which fetches from /put-through/trade/history endpoint and returns all put-through data.
        
        Args:
            symbols_list: List of stock symbols.
            show_log: Show debug logs.
            
        Returns:
            DataFrame with put-through board data filtered by symbols.
        """
        # Use put_through() method to fetch data, then filter by symbols
        df = self.put_through(exchange='HOSE', page=1, show_log=show_log)
        
        if isinstance(symbols_list, str):
            symbols_list = [symbols_list]
            
        # Handle duplicate columns
        df = df.loc[:, ~df.columns.duplicated(keep='first')]
        
        # Filter to requested symbols
        if 'symbol' in df.columns and len(df) > 0:
            df = df[df['symbol'].isin(symbols_list)].reset_index(drop=True)
        
        return df

    def _fetch_derivative_board(
        self,
        symbols_list: List[str],
        show_log: Optional[bool] = False,
    ) -> pd.DataFrame:
        """
        Fetch derivative board data.
        
        Args:
            symbols_list: List of derivative symbols.
            show_log: Show debug logs.
            
        Returns:
            DataFrame with derivative board data.
        """
        import requests
        
        if isinstance(symbols_list, str):
            symbols_list = [symbols_list]
            
        url = _DERIVATIVE_ISS_URL
        payload = {'code': ','.join(symbols_list)}
        
        try:
            # Build headers
            headers_deriv = self.headers.copy()
            headers_deriv.update({
                'Accept-Language': 'en-US,en;q=0.9,vi;q=0.8',
                'Connection': 'keep-alive',
                'Content-Type': 'application/json',
                'DNT': '1',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-origin',
                'x-lang': 'vi'
            })
            
            response = requests.post(
                url,
                headers=headers_deriv,
                data=json.dumps(payload),
                timeout=30
            )
            if response.status_code in [200, 201]:
                json_data = response.json()
            else:
                return pd.DataFrame()
        except Exception as e:
            if show_log or self.show_log:
                logger.error(f"Failed to fetch derivative board data: {str(e)}")
            return pd.DataFrame()
        
        if not json_data:
            return pd.DataFrame()

        if isinstance(json_data, dict) and 'data' in json_data:
            json_data = json_data['data']
            
        if not isinstance(json_data, list):
            return pd.DataFrame()
        
        # Convert to DataFrame
        df = pd.DataFrame(json_data)
        
        # Apply column mapping
        df = df.rename(columns=_DERIVATIVE_MAP)
        
        # Convert timestamp to datetime
        if 'time' in df.columns:
            df['time'] = pd.to_datetime(df['time'], unit='ms', errors='coerce')
        
        return df

    @agg_execution("KBS.ext")
    def price_board(
        self,
        symbols_list: List[str],
        board: str = 'stock',
        exchange: str = 'HOSE',
        show_log: Optional[bool] = False,
        get_all: bool = False,
    ) -> pd.DataFrame:
        """
        Fetch real-time price board for a list of symbols.

        Unified interface for fetching price data from various board types:
        - stock: Standard board (even lots)
        - odd_lot: Odd-lot trades
        - put_through: Negotiated/Put-through trades
        - derivatives: Index futures

        Args:
            symbols_list (List[str]): List of symbols (e.g., ['ACB', 'VNM']).
            board (str): Board type ('stock', 'odd_lot', 'put_through', 'derivatives').
            exchange (str): Exchange ('HOSE', 'HNX', 'UPCOM').
            show_log (bool): Display debug logs.
            get_all (bool): If True, return all raw columns. Otherwise, standard columns.
        """
        if not symbols_list:
            raise ValueError("symbols_list không được để trống.")

        if isinstance(symbols_list, str):
            symbols_list = [symbols_list]

        valid_boards = ['stock', 'odd_lot', 'put_through', 'derivatives']
        if board not in valid_boards:
            raise ValueError(
                f"board không hợp lệ. Các giá trị hợp lệ: {valid_boards}"
            )

        # Normalize symbols to uppercase
        symbols_list = [s.upper() for s in symbols_list]

        # Route to appropriate endpoint based on board type
        dfs_to_concat = []

        if board == 'stock':
            # Stock board (lô chẵn) - auto-detect derivatives for mixed lists
            from vnstock.core.utils.parser import get_asset_type
            from vnstock_data.core.utils.parser import safe_convert_derivative_symbol
            
            stock_symbols = []
            deriv_symbols = []
            index_symbols = []
            
            for s in symbols_list:
                asset_type = get_asset_type(s)
                if asset_type == 'derivative':
                    deriv_symbols.append(s)
                elif asset_type == 'index':
                    index_symbols.append(s)
                else:
                    stock_symbols.append(s)
                    
            if stock_symbols:
                df_stock = self._fetch_stock_board(stock_symbols, show_log)
                dfs_to_concat.append((df_stock, _PRICE_BOARD_STANDARD_COLUMNS))
                
            if deriv_symbols:
                query_symbols = [safe_convert_derivative_symbol(s) for s in deriv_symbols]
                df_deriv = self._fetch_derivative_board(query_symbols, show_log)
                dfs_to_concat.append((df_deriv, _DERIVATIVE_STANDARD_COLUMNS))

            if index_symbols:
                df_index = self.index_summary(show_log=show_log)
                if not df_index.empty and 'symbol' in df_index.columns:
                    target_indices = [s.upper() for s in index_symbols]
                    df_index = df_index[df_index['symbol'].isin(target_indices)].reset_index(drop=True)
                if not df_index.empty:
                    dfs_to_concat.append((df_index, list(df_index.columns)))
                
            data_labels = []
            if stock_symbols: data_labels.append('cơ sở')
            if deriv_symbols: data_labels.append('phái sinh')
            if index_symbols: data_labels.append('chỉ số')
            
            data_label = 'hỗn hợp (' + ' & '.join(data_labels) + ')' if len(data_labels) > 1 else (data_labels[0] if data_labels else 'lô chẵn')

        elif board == 'odd_lot':
            # Odd-lot board (lô lẻ) - use /odd-lot/iss endpoint
            df_odd = self.odd_lot(symbols_list=symbols_list, exchange=exchange, show_log=show_log)
            dfs_to_concat.append((df_odd, _PRICE_BOARD_STANDARD_COLUMNS))
            data_label = 'lô lẻ'

        elif board == 'derivatives':
            from vnstock_data.core.utils.parser import safe_convert_derivative_symbol
            # Convert any old format symbols to new KRX format before querying
            query_symbols = [safe_convert_derivative_symbol(s) for s in symbols_list]
            
            # Derivatives board - use /derivative/iss endpoint
            df_deriv = self._fetch_derivative_board(query_symbols, show_log)
            dfs_to_concat.append((df_deriv, _DERIVATIVE_STANDARD_COLUMNS))
            data_label = 'phái sinh'

        else:  # put_through
            # Put-through board (thỏa thuận) - use /put-through/iss endpoint
            df_pt = self._fetch_put_through_board(symbols_list, show_log)
            dfs_to_concat.append((df_pt, _PUT_THROUGH_STANDARD_COLUMNS))
            data_label = 'thỏa thuận'

        # Filter and combine dfs
        processed_dfs = []
        for df, std_cols in dfs_to_concat:
            if len(df) > 0:
                if not get_all:
                    # Keep only standard columns that exist in the dataframe
                    available_cols = [col for col in std_cols if col in df.columns]
                    df = df[available_cols]
                else:
                    # Remove unclear/meaningless columns from get_all output
                    cols_to_keep = [col for col in df.columns if col not in _EXCLUDED_COLUMNS]
                    df = df[cols_to_keep]
                processed_dfs.append(df)

        if processed_dfs:
            df = pd.concat(processed_dfs, ignore_index=True)
            # Normalize exchange codes (HSX → HOSE for VCI compatibility)
            if 'exchange' in df.columns:
                df['exchange'] = df['exchange'].map(
                    lambda x: _EXCHANGE_CODE_MAP.get(x, x) if pd.notna(x) else x
                )
        else:
            df = pd.DataFrame()

        # Update metadata
        df.attrs['symbols'] = symbols_list
        df.attrs['board'] = board
        df.attrs['source'] = self.data_source
        df.attrs['get_all'] = get_all

        if show_log or self.show_log:
            logger.info(
                f'Truy xuất thành công bảng giá {data_label} cho {len(symbols_list)} mã chứng khoán.'
            )

        return df

    @agg_execution("KBS.ext")
    def odd_lot(
        self,
        symbols_list: Optional[List[str]] = None,
        exchange: str = 'HOSE',
        show_log: Optional[bool] = False,
    ) -> pd.DataFrame:
        """
        Truy xuất dữ liệu giao dịch lô lẻ (odd-lot) cho danh sách mã chứng khoán.

        Note: Phương thức này là alias cho price_board() với data_type='odd_lot'.
        Khuyến nghị sử dụng price_board(symbols_list, data_type='odd_lot') thay vì phương thức này.

        Args:
            symbols_list: Danh sách mã chứng khoán. Nếu None, truy xuất toàn bộ sàn.
            exchange: Sàn giao dịch ('HOSE', 'HNX', 'UPCOM'). Mặc định 'HOSE'.
            show_log: Hiển thị log debug.

        Returns:
            DataFrame chứa dữ liệu giao dịch lô lẻ với các cột chuẩn hóa.

        Examples:
            >>> trading = Trading()
            >>> df = trading.odd_lot(symbols_list=['AAA', 'AAM'])
            >>> df_all = trading.odd_lot(exchange='HOSE')

        Raises:
            ValueError: Nếu exchange không hợp lệ.
        """
        valid_exchanges = ['HOSE', 'HNX', 'UPCOM']
        if exchange not in valid_exchanges:
            raise ValueError(
                f"Exchange không hợp lệ. Các giá trị hợp lệ: {valid_exchanges}"
            )

        url = f'{_IIS_BASE_URL}/odd-lot/iss'
        
        if symbols_list:
            if isinstance(symbols_list, str):
                symbols_list = [symbols_list]
            # Normalize symbols to uppercase
            symbols_list = [s.upper() for s in symbols_list]
            payload = {
                'code': ','.join(symbols_list)
            }
        else:
            # Get all odd-lot data for the exchange
            payload = {
                'exchange': exchange
            }

        # odd_lot endpoint requires direct request due to 201 status code
        # and specific header requirements
        import requests
        try:
            # Build complete headers for odd_lot endpoint
            headers_oddlot = self.headers.copy()
            headers_oddlot.update({
                'Accept-Language': 'en-US,en;q=0.9,vi;q=0.8',
                'Connection': 'keep-alive',
                'Content-Type': 'application/json',
                'DNT': '1',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-origin',
                'x-lang': 'vi'
            })
            
            response = requests.post(
                url,
                headers=headers_oddlot,
                data=json.dumps(payload),
                timeout=30
            )
            if response.status_code in [200, 201]:
                json_data = response.json()
            else:
                return pd.DataFrame()
        except Exception as e:
            if show_log or self.show_log:
                logger.error(f"Failed to fetch odd_lot data: {str(e)}")
            return pd.DataFrame()

        if not json_data:
            return pd.DataFrame()

        if not isinstance(json_data, list):
            # API might return {"message": "..."} on error, so guard against non-list
            return pd.DataFrame()

        # Convert to DataFrame
        df = pd.DataFrame(json_data)

        # Apply column mapping
        df = df.rename(columns=_ODD_LOT_MAP)

        # Convert timestamp to datetime
        if 'timestamp' in df.columns:
            df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')

        # Add metadata
        if symbols_list:
            df.attrs['symbols'] = symbols_list
        df.attrs['exchange'] = exchange
        df.attrs['source'] = self.data_source

        if show_log or self.show_log:
            if symbols_list:
                logger.info(
                    f'Truy xuất thành công {len(df)} bản ghi giao dịch lô lẻ cho {len(symbols_list)} mã chứng khoán.'
                )
            else:
                logger.info(
                    f'Truy xuất thành công {len(df)} bản ghi giao dịch lô lẻ cho sàn {exchange}.'
                )

        return df

    @agg_execution("KBS.ext")
    def put_through(
        self,
        exchange: str = 'HOSE',
        symbol: Optional[str] = None,
        page: int = 1,
        page_size: int = 1000,
        show_log: Optional[bool] = False,
    ) -> pd.DataFrame:
        """
        Truy xuất dữ liệu giao dịch thỏa thuận (put-through) theo sàn.

        Args:
            exchange: Sàn giao dịch ('HOSE', 'HNX', 'UPCOM'). Mặc định 'HOSE'.
            symbol: Mã chứng khoán để lọc (VD: 'ACB'). Nếu None, lấy toàn bộ sàn.
            page: Số trang. Mặc định 1.
            page_size: Số lượng bản ghi mỗi trang. Mặc định 1000.
            show_log: Hiển thị log debug.

        Returns:
            DataFrame chứa dữ liệu giao dịch thỏa thuận với các cột chuẩn hóa.

        Examples:
            >>> trading = Trading()
            >>> df = trading.put_through(exchange='HOSE', page=1)

        Raises:
            ValueError: Nếu exchange không hợp lệ.
        """
        valid_exchanges = ['HOSE', 'HNX', 'UPCOM']
        if exchange not in valid_exchanges:
            raise ValueError(
                f"Exchange không hợp lệ. Các giá trị hợp lệ: {valid_exchanges}"
            )

        url = f'{_PUT_THROUGH_HISTORY_URL}/{exchange}'
        
        params = {
            'page': page,
            'pageSize': page_size,
        }

        json_data = send_request(
            url=url,
            headers=self.headers,
            method="GET",
            params=params,
            show_log=show_log or self.show_log,
            proxy_list=self.proxy_config.proxy_list,
            proxy_mode=self.proxy_config.proxy_mode,
            request_mode=self.proxy_config.request_mode
        )

        if not json_data:
            return pd.DataFrame()

        # Extract data from response structure
        if isinstance(json_data, dict) and 'data' in json_data:
            json_data = json_data['data']
        
        if not json_data or not isinstance(json_data, list):
            return pd.DataFrame()

        # Convert to DataFrame
        df = pd.DataFrame(json_data)

        # Apply column mapping
        df = df.rename(columns=_PUT_THROUGH_MAP)
        
        # Drop duplicate columns that arise from multiple raw keys mapping to the same standard name
        df = df.loc[:, ~df.columns.duplicated()]

        # Convert timestamp to datetime
        if 'timestamp' in df.columns:
            df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')

        # Filter by symbol if provided
        target_symbol = symbol or self.symbol
        if target_symbol and 'symbol' in df.columns:
            df = df[df['symbol'] == target_symbol.upper()].reset_index(drop=True)

        # Add metadata
        df.attrs['exchange'] = exchange
        df.attrs['source'] = self.data_source
        df.attrs['page'] = page

        if show_log or self.show_log:
            logger.info(
                f'Truy xuất thành công {len(df)} bản ghi giao dịch thỏa thuận cho sàn {exchange}.'
            )

        return df

# Register provider
from vnstock_data.core.registry import ProviderRegistry  # noqa: E402, F401
ProviderRegistry.register('trading', 'kbs', Trading)
