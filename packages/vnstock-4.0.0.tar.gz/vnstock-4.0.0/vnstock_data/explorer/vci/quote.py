"""History module for VCI."""

import pandas as pd
from datetime import datetime, timedelta
from vnstock.core.utils.lookback import get_start_date_from_lookback
from vnai import agg_execution
from typing import Dict, Optional, Union, List
from vnstock.explorer.vci.const import (
    _TRADING_URL, _INTERVAL_MAP, 
    _OHLC_MAP, _RESAMPLE_MAP, _OHLC_DTYPE, _INTRADAY_URL, 
    _INTRADAY_MAP, _INTRADAY_DTYPE, _INDEX_MAPPING
)

from vnstock_data.explorer.vci.const import _PRICE_DEPTH_MAP

from vnstock.core.models import TickerModel
from vnstock.core.utils.logger import get_logger
from vnstock.core.utils.market import trading_hours
from vnstock.core.utils.parser import get_asset_type
from vnstock.core.utils.interval import normalize_interval
from vnstock_data.core.utils.client import send_request, ProxyConfig
from vnstock_data.core.utils.user_agent import get_headers
from vnstock_data.core.utils.transform import ohlc_to_df, intraday_to_df
from vnstock_data.core.types import SubscriptionTier, DataQuality, UpdateFrequency

logger = get_logger(__name__)

class Quote:
    """
    Cấu hình truy cập dữ liệu lịch sử giá chứng khoán từ VCI.
    Cho phép cấu hình proxy thông qua object ProxyConfig.
    
    Hỗ trợ các tính năng proxy nâng cao:
    - auto_fetch: Tự động lấy proxy từ proxyscrape API
    - validate_proxies: Kiểm tra tính hợp lệ của proxy
    - prefer_speed: Ưu tiên proxy có tốc độ tốt nhất
    """
    def __init__(
        self, 
        symbol, 
        random_agent=False, 
        proxy_config: Optional[ProxyConfig]=None, 
        show_log=True,
        proxy_mode: Optional[str] = None,
        proxy_list: Optional[List[str]] = None
    ):
        self.symbol = symbol.upper()
        self.data_source = 'VCI'
        self._history = None  # Cache for historical data
        self.asset_type = get_asset_type(self.symbol)
        self.base_url = _TRADING_URL
        self.headers = get_headers(data_source=self.data_source, random_agent=random_agent)
        self.interval_map = _INTERVAL_MAP
        self.show_log = show_log
        
        # Handle proxy configuration
        if proxy_config is None:
            # Create ProxyConfig from individual arguments
            p_mode = proxy_mode if proxy_mode else 'try'
            # If user provides list, set request_mode to PROXY
            req_mode = 'direct'
            if proxy_list and len(proxy_list) > 0:
                req_mode = 'proxy'
                
            self.proxy_config = ProxyConfig(
                proxy_mode=p_mode,
                proxy_list=proxy_list,
                request_mode=req_mode
            )
        else:
            self.proxy_config = proxy_config

        if not show_log:
            logger.setLevel('CRITICAL')

        if 'INDEX' in self.symbol:
            self.symbol = self._index_validation()

    def _index_validation(self) -> str:
        """
        If symbol contains 'INDEX' substring, validate it with _INDEX_MAPPING.
        """
        if self.symbol not in _INDEX_MAPPING.keys():
            raise ValueError("Không tìm thấy mã chứng khoán " + self.symbol + ". Các giá trị hợp lệ: " + ', '.join(_INDEX_MAPPING.keys()))
        return _INDEX_MAPPING[self.symbol]

    def _input_validation(self, start: str, end: str, interval: str):
        """
        Validate input data
        """
        # Normalize interval using vnstock's core utility
        try:
            normalized_tf = normalize_interval(interval)
            normalized_interval = normalized_tf.value
        except ValueError:
            raise ValueError(f"Giá trị interval không hợp lệ: {interval}. Vui lòng chọn: 1m, 5m, 15m, 30m, 1H, 4h, 1D, 1W, 1M")
        
        ticker = TickerModel(symbol=self.symbol, start=start, end=end, interval=normalized_interval)

        if ticker.interval not in self.interval_map:
            raise ValueError(f"Giá trị interval không hỗ trợ bởi VCI: {ticker.interval}. Các interval được hỗ trợ: 1m, 5m, 15m, 30m, 1H, 1D, 1W, 1M")

        return ticker

    @agg_execution("VCI.ext")
    def history(self, start: Optional[str]=None, end: Optional[str]=None, interval: Optional[str]="1D", 
                to_df: Optional[bool]=True, show_log: Optional[bool]=False, 
                count_back: Optional[int]=None, floating: Optional[int]=2,
                length: Optional[Union[str, int]] = None) -> Union[pd.DataFrame, str]:
        """
        Tải lịch sử giá của mã chứng khoán từ nguồn dữ liệu VCI.

        Tham số:
            - start (tùy chọn): thời gian bắt đầu lấy dữ liệu (YYYY-MM-DD). Bắt buộc nếu không có length hoặc count_back.
            - end (tùy chọn): thời gian kết thúc lấy dữ liệu. Mặc định là None, chương trình tự động lấy thời điểm hiện tại.
            - interval (tùy chọn): Khung thời gian trích xuất dữ liệu. Mặc định là "1D".
            - to_df (tùy chọn): Chuyển đổi dữ liệu lịch sử trả về dưới dạng DataFrame. Mặc định là True.
            - show_log (tùy chọn): Hiển thị thông tin log. Mặc định là False.
            - count_back (tùy chọn): Số lượng dữ liệu trả về từ thời điểm cuối.
            - floating (tùy chọn): Số chữ số thập phân cho giá. Mặc định là 2.
            - length (tùy chọn): Khoảng thời gian phân tích (vd: '3M', 150, '100b').
        """
        # Set end date to today if not provided
        if end is None:
            end = datetime.now().strftime("%Y-%m-%d")

        # Calculate start if not provided
        if start is None:
            # Check if length defines bars
            if length is not None:
                length_str = str(length)
                if length_str.endswith('b'):
                    # Length defines number of bars
                    count_back = int(length_str[:-1])
                    # Approximate start for initial validation (refined by count_back later)
                    start = get_start_date_from_lookback(lookback_length=length_str, end_date=end)
                else:
                    # Length defines time period
                    start = get_start_date_from_lookback(lookback_length=length_str, end_date=end)
            elif count_back is not None:
                # Estimate start based on count_back and interval
                if interval == '1D':
                    start = (datetime.strptime(end, "%Y-%m-%d") - timedelta(days=count_back * 2)).strftime("%Y-%m-%d")
                elif interval == '1H':
                    start = (datetime.strptime(end, "%Y-%m-%d") - timedelta(days=count_back // 6)).strftime("%Y-%m-%d")
                elif interval == '1m':
                    start = (datetime.strptime(end, "%Y-%m-%d") - timedelta(days=1)).strftime("%Y-%m-%d")
                else:
                    start = get_start_date_from_lookback(lookback_length='1M', end_date=end)
            else:
                raise ValueError("Tham số 'start' là bắt buộc nếu không cung cấp 'length' hoặc 'count_back'.")

        # Validate inputs
        ticker = self._input_validation(start, end, interval)

        start_time = datetime.strptime(ticker.start, "%Y-%m-%d")
        
        # Calculate end timestamp
        if end is not None:
            end_time = datetime.strptime(ticker.end, "%Y-%m-%d") + pd.Timedelta(days=1)
            if start_time > end_time:
                raise ValueError("Thời gian bắt đầu không thể lớn hơn thời gian kết thúc.")
            end_stamp = int(end_time.timestamp())
        else:
            end_time = datetime.now() + pd.Timedelta(days=1)
            end_stamp = int(end_time.timestamp())

        interval_value = self.interval_map[ticker.interval]

        # Tự động tính count_back nếu không truyền vào
        auto_count_back = 1000
        business_days = pd.bdate_range(start=start_time, end=end_time)

        if count_back is None and end is not None:
            # Lấy giá trị interval đã mapping
            interval_mapped = interval_value
            
            if interval_mapped == "ONE_DAY":
                # Sử dụng bdate_range để đếm số ngày làm việc (không tính thứ 7, chủ nhật)
                auto_count_back = len(business_days) + 1
            elif interval_mapped == "ONE_HOUR":
                # Tính số ngày làm việc và nhân với số giờ giao dịch mỗi ngày (6.5 giờ)
                auto_count_back = len(business_days) * 6.5 + 1
            elif interval_mapped == "ONE_MINUTE":
                # Tính số ngày làm việc và nhân với số phút giao dịch mỗi ngày (6.5 * 60 phút)
                auto_count_back = len(business_days) * 6.5 * 60 + 1
        else:
            auto_count_back = count_back if count_back is not None else 1000

        # Prepare request
        url = f'{self.base_url}chart/OHLCChart/gap-chart'
        payload = {
            "timeFrame": interval_value,
            "symbols": [self.symbol],
            "to": end_stamp,
            "countBack": auto_count_back
        }

        # Use the send_request utility from api_client
        json_data = send_request(
            url=url, 
            headers=self.headers, 
            method="POST", 
            payload=payload, 
            show_log=show_log,
            proxy_list=self.proxy_config.proxy_list,
            proxy_mode=self.proxy_config.proxy_mode,
            request_mode=self.proxy_config.request_mode
        )

        if not json_data:
            raise ValueError("Không tìm thấy dữ liệu. Vui lòng kiểm tra lại mã chứng khoán hoặc thời gian truy xuất.")
        
        # Use the ohlc_to_df utility from data_transform
        df = ohlc_to_df(
            data=json_data[0], 
            column_map=_OHLC_MAP, 
            dtype_map=_OHLC_DTYPE, 
            asset_type=self.asset_type, 
            symbol=self.symbol, 
            source=self.data_source, 
            interval=ticker.interval, 
            floating=floating,
            resample_map=_RESAMPLE_MAP
        )

        # trim the data to the start time
        df = df[df['time'] >= start_time].reset_index(drop=True)

        if count_back is not None:
            df = df.tail(count_back)

        if to_df:
            return df
        else:
            return df.to_json(orient='records')

    @agg_execution("VCI.ext")
    def intraday(self, page_size: Optional[int]=100, last_time: Optional[str]=None, 
                to_df: Optional[bool]=True, show_log: bool=False) -> Union[pd.DataFrame, str]:
        """
        Truy xuất dữ liệu khớp lệnh của mã chứng khoán bất kỳ từ nguồn dữ liệu VCI

        Tham số:
            - page_size (tùy chọn): Số lượng dữ liệu trả về trong một lần request. Mặc định là 100. 
            - last_time (tùy chọn): Thời gian cắt dữ liệu, dùng để lấy dữ liệu sau thời gian cắt. Mặc định là None.
            - to_df (tùy chọn): Chuyển đổi dữ liệu lịch sử trả về dưới dạng DataFrame. Mặc định là True.
            - show_log (tùy chọn): Hiển thị thông tin log giúp debug dễ dàng. Mặc định là False.
        """
        # Validator: Intraday data is not supported for indices
        if self.asset_type == 'index':
            raise ValueError(f"Dữ liệu intraday không được hỗ trợ cho chỉ số {self.symbol}.")

        market_status = trading_hours(None)
        if market_status['is_trading_hour'] is False and market_status['data_status'] == 'preparing':
            raise ValueError(str(market_status['time']) + ": Dữ liệu khớp lệnh không thể truy cập trong thời gian chuẩn bị phiên mới. Vui lòng quay lại sau.")

        if self.symbol is None:
            raise ValueError("Vui lòng nhập mã chứng khoán cần truy xuất khi khởi tạo Trading Class.")

        if page_size > 30_000:
            logger.warning("Bạn đang yêu cầu truy xuất quá nhiều dữ liệu, điều này có thể gây lỗi quá tải.")

        url = f'{self.base_url}{_INTRADAY_URL}/LEData/getAll'
        payload = {
            "symbol": self.symbol,
            "limit": page_size,
            "truncTime": last_time
        }

        # Fetch data using the send_request utility
        data = send_request(
            url=url, 
            headers=self.headers, 
            method="POST", 
            payload=payload, 
            show_log=show_log,
            proxy_list=self.proxy_config.proxy_list,
            proxy_mode=self.proxy_config.proxy_mode,
            request_mode=self.proxy_config.request_mode,
            auto_fetch=self.proxy_config.auto_fetch,
            validate_proxies=self.proxy_config.validate_proxies,
            prefer_speed=self.proxy_config.prefer_speed
        )

        # Transform data using intraday_to_df utility
        df = intraday_to_df(
            data=data, 
            column_map=_INTRADAY_MAP, 
            dtype_map=_INTRADAY_DTYPE, 
            symbol=self.symbol, 
            asset_type=self.asset_type, 
            source=self.data_source
        )

        if to_df:
            return df
        else:
            return df.to_json(orient='records')

    @agg_execution("VCI.ext")
    def price_depth(self, to_df: Optional[bool]=True, show_log: Optional[bool]=False) -> Union[pd.DataFrame, str]:
        """
        Truy xuất thống kê độ bước giá & khối lượng khớp lệnh của mã chứng khoán bất kỳ từ nguồn dữ liệu VCI.

        Tham số:
            - to_df (tùy chọn): Chuyển đổi dữ liệu lịch sử trả về dưới dạng DataFrame. Mặc định là True.
            - show_log (tùy chọn): Hiển thị thông tin log giúp debug dễ dàng. Mặc định là False.
        """
        market_status = trading_hours(None)
        if market_status['is_trading_hour'] is False and market_status['data_status'] == 'preparing':
            raise ValueError(str(market_status['time']) + ": Dữ liệu khớp lệnh không thể truy cập trong thời gian chuẩn bị phiên mới. Vui lòng quay lại sau.")

        if self.symbol is None:
            raise ValueError("Vui lòng nhập mã chứng khoán cần truy xuất khi khởi tạo Trading Class.")

        url = f'{self.base_url}{_INTRADAY_URL}/AccumulatedPriceStepVol/getSymbolData'
        payload = {
            "symbol": self.symbol
        }

        # Fetch data using the send_request utility
        data = send_request(
            url=url, 
            headers=self.headers, 
            method="POST", 
            payload=payload, 
            show_log=show_log,
            proxy_list=self.proxy_config.proxy_list,
            proxy_mode=self.proxy_config.proxy_mode,
            request_mode=self.proxy_config.request_mode,
            auto_fetch=self.proxy_config.auto_fetch,
            validate_proxies=self.proxy_config.validate_proxies,
            prefer_speed=self.proxy_config.prefer_speed
        )

        # Process the data to DataFrame
        df = pd.DataFrame(data)
        
        # Select columns in _PRICE_DEPTH_MAP values and rename them
        df = df[_PRICE_DEPTH_MAP.keys()]
        df.rename(columns=_PRICE_DEPTH_MAP, inplace=True)
        
        df.source = self.data_source

        if to_df:
            return df
        else:
            return df.to_json(orient='records')

# Register provider
from vnstock_data.core.registry import ProviderRegistry  # noqa: E402, F401
ProviderRegistry.register('quote', 'vci', Quote)
