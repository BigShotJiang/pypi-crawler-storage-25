"""Listing module."""

# Đồ thị giá, đồ thị dư mua dư bán, đồ thị mức giá vs khối lượng, thống kê hành vi thị tường
from typing import Dict, Optional
from datetime import datetime
from vnstock.explorer.vci.const import _GROUP_CODE, _TRADING_URL, _GRAPHQL_URL

import json
import pandas as pd
from vnstock.core.utils.parser import camel_to_snake
from vnstock.core.utils.logger import get_logger
from vnstock.core.utils.transform import drop_cols_by_pattern, reorder_cols
from vnstock_data.core.utils.client import send_request
from vnstock_data.core.utils.user_agent import get_headers
from vnai import agg_execution
logger = get_logger(__name__)

class Listing:
    """
    Cấu hình truy cập dữ liệu lịch sử giá chứng khoán từ VCI.
    """
    def __init__(self, random_agent:Optional[bool]=False, show_log:Optional[bool]=False):
        self.data_source = 'VCI'
        self.base_url = _TRADING_URL
        self.headers = get_headers(data_source=self.data_source, random_agent=random_agent)
        self.show_log = show_log
        if not show_log:
            logger.setLevel('CRITICAL')

    @agg_execution("VCI.ext")
    def all_symbols (self, show_log:Optional[bool]=False, to_df:Optional[bool]=True) -> Dict:
        """
        Truy xuất danh sách toàn. bộ mã và tên các cổ phiếu trên thị trường Việt Nam.

        Tham số:
            - show_log (tùy chọn): Hiển thị thông tin log giúp debug dễ dàng. Mặc định là False.
            - to_df (tùy chọn): Chuyển đổi dữ liệu danh sách mã cổ phiếu trả về dưới dạng DataFrame. Mặc định là True. Đặt là False để trả về dữ liệu dạng JSON.
        """
        df = self.symbols_by_exchange(show_log=show_log, to_df=True)
        df = df.query('type == "STOCK"').reset_index(drop=True)
        df = df[['symbol', 'organ_name']]

        if to_df:
            return df
        else:
            json_data = df.to_json(orient='records')
            return json_data
        
    @agg_execution("VCI.ext")
    def symbols_by_industries (self, lang:str='vi', show_log: Optional[bool]=False, to_df:Optional[bool]=True):
        """
        Truy xuất thông tin phân ngành icb của các mã cổ phiếu trên thị trường Việt Nam.

        Tham số:
            - show_log (tùy chọn): Hiển thị thông tin log giúp debug dễ dàng. Mặc định là False.
            - to_df (tùy chọn): Chuyển đổi dữ liệu danh sách mã cổ phiếu trả về dưới dạng DataFrame. Mặc định là True. Đặt là False để trả về dữ liệu dạng JSON.
        """
        if lang not in ['vi', 'en']:
            raise ValueError("Tham số lang phải là 'vi' hoặc 'en'.")

        lang_code = '1' if lang == 'vi' else '2'
        url = f"https://iq.vietcap.com.vn/api/iq-insight-service/v2/company/search-bar?language={lang_code}"

        # Use the send_request utility from api_client
        json_data = send_request(
            url=url, 
            headers=self.headers, 
            method="GET", 
            show_log=show_log
        )

        if not json_data or 'data' not in json_data:
            raise ValueError("Không tìm thấy dữ liệu. Vui lòng kiểm tra lại.")

        if show_log:
            logger.info(f'Truy xuất thành công dữ liệu danh sách phân ngành icb.')

        parsed_data = []
        for company in json_data['data']:
            symbol = company.get('code')
            organ_name = company.get('name')
            com_type_code = company.get('comTypeCode')
            
            for level in range(1, 5):
                icb_key = f'icbLv{level}'
                if icb_key in company and company[icb_key] is not None:
                    parsed_data.append({
                        'symbol': symbol,
                        'organ_name': organ_name,
                        'com_type_code': com_type_code,
                        'icb_level': level,
                        'icb_code': company[icb_key].get('code'),
                        'icb_name': company[icb_key].get('name')
                    })

        df = pd.DataFrame(parsed_data)
        
        if not df.empty:
            # Filter out empty ICB codes
            df = df[df['icb_code'].notna() & (df['icb_code'] != '')]
            # Sort by symbol and level
            df = df.sort_values(by=['symbol', 'icb_level']).reset_index(drop=True)
            df = df[['symbol', 'organ_name', 'com_type_code', 'icb_level', 'icb_code', 'icb_name']]
        
        df.source = "VCI"

        if to_df:
            return df
        else:
            json_data = df.to_json(orient='records')
            return json_data

    @agg_execution("VCI.ext")
    def symbols_by_exchange(self, lang:str='vi', show_log:Optional[bool]=False, to_df:Optional[bool]=True):
        """
        Truy xuất thông tin niêm yết theo sàn của các mã cổ phiếu trên thị trường Việt Nam.

        Tham số:
                - show_log (tùy chọn): Hiển thị thông tin log giúp debug dễ dàng. Mặc định là False.
                - to_df (tùy chọn): Chuyển đổi dữ liệu danh sách mã cổ phiếu trả về dưới dạng DataFrame. Mặc định là True. Đặt là False để trả về dữ liệu dạng JSON.
        """
        if lang not in ['vi', 'en']:
            raise ValueError("Tham số lang phải là 'vi' hoặc 'en'.")

        url = self.base_url + '/price/symbols/getAll'
        
        # Use the send_request utility from api_client
        json_data = send_request(
            url=url, 
            headers=self.headers, 
            method="GET", 
            payload=None,
            show_log=show_log
        )

        if not json_data:
            raise ValueError("Không tìm thấy dữ liệu. Vui lòng kiểm tra lại.")

        if show_log:
            logger.info(f'Truy xuất dữ liệu thành công cho {len(json_data)} mã.')

        df = pd.DataFrame(json_data)

        df.columns = [camel_to_snake(col) for col in df.columns]
        df = df.rename(columns={'board': 'exchange'})
        df = reorder_cols(df, ['symbol', 'exchange', 'type'], position='first')
        df = df.drop(columns=['id'])

        if lang == 'vi':
            df = drop_cols_by_pattern(df, ['en_'])
        else:
            df = df.drop(columns=['organ_name', 'organ_short_name'])
            # rename columns for those contain 'en_' with 'en_' removed
            df.columns = [col.replace('en_', '') for col in df.columns]

        if to_df:
            # Set metadata attributes
            df.source = "VCI"
            return df
        else:
            json_data = df.to_json(orient='records')
            return json_data

    @agg_execution("VCI.ext")
    def industries_icb (self, show_log: Optional[bool]=False, to_df:Optional[bool]=True):
        """
        Truy xuất thông tin phân ngành icb của các mã cổ phiếu trên thị trường Việt Nam.

        Tham số:
            - show_log (tùy chọn): Hiển thị thông tin log giúp debug dễ dàng. Mặc định là False.
            - to_df (tùy chọn): Chuyển đổi dữ liệu danh sách mã cổ phiếu trả về dưới dạng DataFrame. Mặc định là True. Đặt là False để trả về dữ liệu dạng JSON.
        """
        url = "https://iq.vietcap.com.vn/api/iq-insight-service/v1/sectors/icb-codes"

        # Use the send_request utility from api_client
        json_data = send_request(
            url=url, 
            headers=self.headers, 
            method="GET", 
            show_log=show_log
        )

        if not json_data:
            raise ValueError("Không tìm thấy dữ liệu. Vui lòng kiểm tra lại.")

        if show_log:
            logger.info(f'Truy xuất thành công dữ liệu danh sách phân ngành icb.')

        df = pd.DataFrame(json_data['data'])
        df = df.rename(columns={
            'name': 'icb_code',
            'viSector': 'icb_name',
            'enSector': 'en_icb_name',
            'icbLevel': 'level'
        })
        
        if not df.empty:
            df = df[['icb_name', 'en_icb_name', 'icb_code', 'level']]
            df = df.sort_values(by=['icb_code']).reset_index(drop=True)

        df.source = "VCI"

        if to_df:
            return df
        else:
            json_data = df.to_json(orient='records')
            return json_data

    @agg_execution("VCI.ext")
    def symbols_by_group (self, group: str ='VN30', show_log:Optional[bool]=False, to_df:Optional[bool]=True):
        """
        Truy xuất danh sách các mã cổ phiếu theo tên nhóm trên thị trường Việt Nam.

        Tham số:
            - group (tùy chọn): Tên nhóm cổ phiếu. Mặc định là 'VN30'. Các mã có thể là: HOSE, VN30, VNMidCap, VNSmallCap, VNAllShare, VN100, ETF, HNX, HNX30, HNXCon, HNXFin, HNXLCap, HNXMSCap, HNXMan, UPCOM, FU_INDEX (mã chỉ số hợp đồng tương lai), CW (chứng quyền).
            - show_log (tùy chọn): Hiển thị thông tin log giúp debug dễ dàng. Mặc định là False.
            - to_df (tùy chọn): Chuyển đổi dữ liệu danh sách mã cổ phiếu trả về dưới dạng DataFrame. Mặc định là True. Đặt là False để trả về dữ liệu dạng JSON.
        """
        if group not in _GROUP_CODE:
            raise ValueError(f"Invalid group. Group must be in {_GROUP_CODE}")
        
        url = self.base_url + f'/price/symbols/getByGroup?group={group}'

        # Use the send_request utility from api_client
        json_data = send_request(
            url=url, 
            headers=self.headers, 
            method="GET", 
            payload=None,
            show_log=show_log
        )

        if show_log:
            logger.info(f'Truy xuất thành công dữ liệu danh sách mã CP theo nhóm.')

        df = pd.DataFrame(json_data)

        if to_df:
            if not json_data:
                raise ValueError("JSON data is empty or not provided.")
            # Set metadata attributes
            df.source = "VCI"
            return df['symbol']
        else:
            json_data = df.to_json(orient='records')
            return json_data

    @agg_execution("VCI.ext")
    def all_future_indices (self, show_log:Optional[bool]=False, to_df:Optional[bool]=True):
        return self.symbols_by_group(group='FU_INDEX', show_log=show_log, to_df=to_df)

    @agg_execution("VCI.ext")
    def all_government_bonds (self, show_log:Optional[bool]=False, to_df:Optional[bool]=True):
        return self.symbols_by_group(group='FU_BOND', show_log=show_log, to_df=to_df)

    @agg_execution("VCI.ext")
    def all_covered_warrant (self, show_log:Optional[bool]=False, to_df:Optional[bool]=True):
        return self.symbols_by_group(group='CW', show_log=show_log, to_df=to_df)

    @agg_execution("VCI.ext")
    def all_bonds (self, show_log:Optional[bool]=False, to_df:Optional[bool]=True):
        return self.symbols_by_group(group='BOND', show_log=show_log, to_df=to_df)

    @agg_execution("VCI.ext")
    def all_etf (self, show_log:Optional[bool]=False, to_df:Optional[bool]=True):
        """
        Truy xuất danh sách mã quỹ ETF.
        """
        return self.symbols_by_group(group='ETF', show_log=show_log, to_df=to_df)



# Register provider
from vnstock_data.core.registry import ProviderRegistry  # noqa: E402, F401
ProviderRegistry.register('listing', 'vci', Listing)
