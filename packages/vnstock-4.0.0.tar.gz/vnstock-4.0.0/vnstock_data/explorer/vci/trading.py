from typing import List, Optional, Union, Dict, Any
import json
import time
from datetime import datetime
import pandas as pd
import requests
from vnai import agg_execution

# vnstock core utilities
from vnstock.core.utils.logger import get_logger
from vnstock.core.utils.parser import get_asset_type, camel_to_snake, flatten_data
from vnstock.core.utils.transform import flatten_hierarchical_index
from vnstock.explorer.vci.const import _TRADING_URL

# vnstock_data utilities
from vnstock_data.core.utils.client import ProxyConfig, send_request
from vnstock_data.core.utils.user_agent import get_headers
from vnstock_data.core.utils.parser import filter_columns_by_language
from vnstock_data.core.utils.validation import validate_date
from vnstock_data.explorer.vci.const import (
    _VCIQ_URL, _VCI_MARKET_INDICES_URL, _VCI_COMPANY_URL, _VCI_INDEX_MAPPING,
    _REPORT_RESOLUTION, _ODD_LOT_URL, _PUT_THROUGH_URL,
    _ODD_LOT_MAP, _PUT_THROUGH_MAP, _ODD_LOT_STANDARD_COLUMNS, 
    _PUT_THROUGH_STANDARD_COLUMNS, _STOCK_BOARD_STANDARD_COLUMNS,
    _PRICE_BOARD_STANDARD_COLUMNS, _VCI_TO_SCHEMA_MAP
)

logger = get_logger(__name__)

class Trading:
    """
    Truy xuất dữ liệu giao dịch của mã chứng khoán từ nguồn dữ liệu VCI.
    """
    def __init__(self, symbol:Optional[str]=None, random_agent=False, proxy_config:Optional[ProxyConfig]=None, show_log:Optional[bool]=False):
        self.symbol = symbol.upper() if symbol else ""
        self.asset_type = get_asset_type(self.symbol) if self.symbol else None
        
        if self.asset_type == 'index' and self.symbol in _VCI_INDEX_MAPPING:
            self.symbol = _VCI_INDEX_MAPPING[self.symbol]
            
        self.base_url = _VCIQ_URL
        self.headers = get_headers(data_source='VCI', random_agent=random_agent)
        self.proxy_config = proxy_config if proxy_config is not None else ProxyConfig()
        if not show_log:
            logger.setLevel('CRITICAL')
        self.show_log = show_log

    def _process_dates(self, start: Optional[str], end: Optional[str]) -> tuple[Optional[str], Optional[str]]:
        """
        Validate and process start/end dates for API requests.
        
        Args:
            start (str, optional): Start date in YYYY-mm-dd format
            end (str, optional): End date in YYYY-mm-dd format
            
        Returns:
            tuple: Processed dates in YYYYMMDD format or (None, None) if invalid
        """
        if start and end:
            if not validate_date(start) or not validate_date(end):
                logger.error("Invalid date format. Please use the format YYYY-mm-dd.")
                return None, None
            else:
                # Convert dates to YYYYMMDD format for API
                return start.replace('-', ''), end.replace('-', '')
        return None, None

    def _fetch_data(self, endpoint: str, params: dict) -> dict:
        """
        Core function to fetch data from VCI API endpoints.
        
        Args:
            endpoint (str): API endpoint path (e.g., 'price-history-summary')
            params (dict): Query parameters for the API request
            
        Returns:
            dict: Raw JSON response from VCI API
            
        Raises:
            requests.exceptions.RequestException: For HTTP-related errors
            ValueError: For JSON parsing errors
        """
        # Build full API URL
        if self.asset_type == 'index':
            if endpoint in ['price-history', 'price-history-summary']:
                url = f'{_VCI_MARKET_INDICES_URL}/history'
                params['index'] = self.symbol
            else:
                url = f'{_VCI_MARKET_INDICES_URL}/{endpoint}'
                params['index'] = self.symbol
        else:
            url = f'{_VCI_COMPANY_URL}/{self.symbol}/{endpoint}'
        
        try:
            # Make API request using send_request and proxy config
            data = send_request(
                url,
                headers=self.headers,
                method="GET",
                params=params,
                show_log=self.show_log,
                proxy_list=self.proxy_config.proxy_list,
                proxy_mode=self.proxy_config.proxy_mode,
                request_mode=self.proxy_config.request_mode
            )
            if self.show_log:
                logger.info(f"Successfully fetched data from {endpoint} for {self.symbol}")
            return data
        except Exception as e:
            logger.error(f"Error fetching data from {endpoint} for {self.symbol}: {e}")
            raise

    def _to_dataframe(self, data: dict, data_path: Optional[list] = None) -> pd.DataFrame:
        """
        Convert API response data to pandas DataFrame with flexible data path extraction.
        
        Args:
            data (dict): Raw JSON response from API
            data_path (list, optional): Path to extract data from nested structure 
                                       (e.g., ['data'] or ['data', 'content'])
                                       If None, defaults to ['data']
            
        Returns:
            pd.DataFrame: Processed DataFrame with snake_case columns
        """
        try:
            # Set default data path if not provided
            if data_path is None:
                data_path = ['data']
            
            # Navigate through the nested structure using the path
            extracted_data = data
            for key in data_path:
                if isinstance(extracted_data, dict) and key in extracted_data:
                    extracted_data = extracted_data[key]
                else:
                    # Path not found, log warning and return empty DataFrame
                    logger.warning(f"Data path {data_path} not found in response for {self.symbol}")
                    return pd.DataFrame()
            
            # Check if we have valid data
            if not extracted_data:
                logger.warning(f"No data found at path {data_path} for {self.symbol}")
                return pd.DataFrame()
            
            # Convert to DataFrame based on data structure
            if isinstance(extracted_data, list):
                # List of records
                df = pd.DataFrame(extracted_data)
            elif isinstance(extracted_data, dict):
                # Single record/dict
                df = pd.DataFrame([extracted_data])
            else:
                # Unexpected data type
                logger.error(f"Unexpected data type at path {data_path}: {type(extracted_data)}")
                return pd.DataFrame()
            
            # Convert column names from camelCase to snake_case
            if not df.empty:
                df.columns = [camel_to_snake(col) for col in df.columns]
            
            return df
            
        except (KeyError, TypeError, Exception) as e:
            logger.error(f"Unexpected error processing data for {self.symbol}: {e}")
            raise

    def _process_bid_ask_data(self, item: Dict[str, Any], row: Dict[str, Any]) -> None:
        """
        Extract and process bid/ask prices and volumes from item data.
        
        Args:
            item (dict): Raw item data from API response
            row (dict): Row dictionary to populate with bid/ask data
        """
        try:
            bid_ask_data = item.get('bidAsk', {})
            
            # Process bid prices and volumes
            bid_prices = bid_ask_data.get('bidPrices', [])
            for i, bid in enumerate(bid_prices, start=1):
                row[f'bidAsk_bid_{i}_price'] = bid.get('price')
                row[f'bidAsk_bid_{i}_volume'] = bid.get('volume')
            
            # Process ask prices and volumes
            ask_prices = bid_ask_data.get('askPrices', [])
            for i, ask in enumerate(ask_prices, start=1):
                row[f'bidAsk_ask_{i}_price'] = ask.get('price')
                row[f'bidAsk_ask_{i}_volume'] = ask.get('volume')
        except (KeyError, TypeError, AttributeError) as e:
            logger.debug(f"Error processing bid/ask data for {self.symbol}: {e}")

    def _normalize_exchange_code(self, df: pd.DataFrame, column_name: str) -> None:
        """
        Normalize exchange codes (HSX → HOSE) for consistency.
        
        Args:
            df (pd.DataFrame): DataFrame to normalize
            column_name (str): Column name to normalize
        """
        if column_name in df.columns:
            df[column_name] = df[column_name].map(
                lambda x: 'HOSE' if x == 'HSX' else x
            )

    def _flatten_price_board_columns(self, df: pd.DataFrame, separator: str = '_', 
                                     drop_levels: Optional[Union[int, List[int]]] = None) -> pd.DataFrame:
        """
        Flatten hierarchical columns in price board DataFrame.
        
        Args:
            df (pd.DataFrame): DataFrame with MultiIndex columns
            separator (str): Separator for flattened column names
            drop_levels (int or list): Levels to drop during flattening
            
        Returns:
            pd.DataFrame: DataFrame with flattened columns
        """
        df_flattened = flatten_hierarchical_index(
            df, 
            separator=separator,
            drop_levels=drop_levels,
            handle_duplicates=True
        )
        
        # Normalize exchange in flattened columns
        self._normalize_exchange_code(df_flattened, 'listing_exchange')
        
        return df_flattened

    def _fetch_stock_board(self, symbols_list: List[str], 
                           show_log: Optional[bool] = False,
                           flatten_columns: Optional[bool] = True,
                           separator: Optional[str] = '_',
                           drop_levels: Optional[Union[int, List[int]]] = None) -> pd.DataFrame:
        """
        Internal method to fetch stock board (lô chẵn) data.
        
        Args:
            symbols_list (List[str]): List of stock symbols to fetch
            show_log (bool): Show logging information (default: False)
            flatten_columns (bool): Flatten hierarchical columns (default: True)
            separator (str): Separator for flattened column names (default: '_')
            drop_levels (int or list): Levels to drop during flattening (default: None)
            
        Returns:
            pd.DataFrame: Stock board data with normalized columns
        """
        url = f'{_TRADING_URL}price/symbols/getList'
        payload = json.dumps({"symbols": symbols_list})

        if show_log:
            logger.info(f'Requested URL: {url} with query payload: {payload}')
        
        try:
            data = send_request(
                url,
                headers=self.headers,
                method="POST",
                payload=json.loads(payload),
                show_log=show_log,
                proxy_list=self.proxy_config.proxy_list,
                proxy_mode=self.proxy_config.proxy_mode,
                request_mode=self.proxy_config.request_mode
            )
        except Exception as e:
            logger.error(f"Failed to fetch price board data: {e}")
            raise

        if not data:
            raise ConnectionError("Tải dữ liệu không thành công hoặc không có dữ liệu trả về.")

        # Initialize an empty list to hold all row dictionaries
        rows = []

        # Process each item in the JSON data
        for item in data:
            try:
                # Prepare nested dictionaries with higher indices: 'listing', 'bidAsk', 'match'
                item_data = {
                    'listing': item.get('listingInfo', {}),
                    'bidAsk': item.get('bidAsk', {}),
                    'match': item.get('matchPrice', {})
                }

                # Flatten the nested dictionary while preserving the hierarchy in the keys
                row = flatten_data(item_data)

                # Add bid and ask prices and volumes using helper method
                self._process_bid_ask_data(item, row)
                
                # Append the row dictionary to the list
                rows.append(row)
            except Exception as e:
                logger.warning(f"Error processing item in price_board: {e}")
                continue

        if not rows:
            logger.warning(f"No valid data rows found for symbols: {symbols_list}")
            return pd.DataFrame()

        # Convert the list of dictionaries to a DataFrame
        combine_df = pd.DataFrame(rows)

        # Transform column names using camel_to_snake and create a MultiIndex
        combine_df.columns = pd.MultiIndex.from_tuples([
            tuple(camel_to_snake(part) for part in c.split('_', 1)) for c in combine_df.columns
        ])

        # Define columns to drop
        drop_columns = [
            ('bid_ask', 'code'), ('bid_ask', 'symbol'), ('bid_ask', 'session'), 
            ('bid_ask', 'received_time'), ('bid_ask', 'message_type'), ('bid_ask', 'time'), 
            ('bid_ask', 'bid_prices'), ('bid_ask', 'ask_prices'),
            ('listing', 'code'), ('listing', 'exercise_price'), ('listing', 'exercise_ratio'), 
            ('listing', 'maturity_date'), ('listing', 'underlying_symbol'), ('listing', 'issuer_name'), 
            ('listing', 'received_time'), ('listing', 'message_type'), ('listing', 'en_organ_name'), 
            ('listing', 'en_organ_short_name'), ('listing', 'organ_short_name'), ('listing', 'ticker'),
            ('match', 'code'), ('match', 'symbol'), ('match', 'received_time'), 
            ('match', 'message_type'), ('match', 'time'), ('match', 'session')
        ]
        
        # Drop columns only if they exist in the DataFrame
        combine_df = combine_df.drop(columns=[col for col in drop_columns if col in combine_df.columns])

        # Rename column for board inside listing to exchange
        combine_df = combine_df.rename(columns={'board': 'exchange'}, level=1)
        
        # Normalize exchange codes: HSX → HOSE (for consistency with KBS and API parameters)
        self._normalize_exchange_code(combine_df, ('listing', 'exchange'))

        # Flatten columns if requested (now default True)
        if flatten_columns:
            combine_df = self._flatten_price_board_columns(
                combine_df, 
                separator=separator,
                drop_levels=drop_levels
            )

        combine_df.attrs['source'] = 'VCI'

        return combine_df

    def _normalize_unified_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Normalize VCI unified format data - standardize data types and units.
        
        Data Type Standards (semantic correctness):
        - All prices (open, high, low, close, ceiling, floor, reference, average, bid/ask): float64
          (Rationale: API provides with decimal precision, maintaining accuracy)
        - All volumes (bid_vol, ask_vol, total_trades, foreign_volumes): int64
          (Rationale: Share counts are integers)
        - total_value: float64, scaled to VND from millions
          (VCI provides in triệu đ, scale ×1,000,000 to match KBS in VND)
        - Percentages (percent_change): float64
        - Identifiers (symbol, exchange): str
        - Timestamp (time): int64
        
        Unit Conversion:
        - total_value: 771888.25 (triệu đ) → 771888.25 × 1,000,000 = 771,888,250,000 (VND)
        
        Args:
            df (pd.DataFrame): VCI unified format DataFrame (after column renaming to flat structure)
            
        Returns:
            pd.DataFrame: Normalized DataFrame with consistent data types
        """
        if df is None or df.empty:
            return df
        
        df = df.copy()
        
        # Ensure columns are flat strings (in case hierarchical MultiIndex passed)
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.map(lambda x: '_'.join(str(i) for i in x) if isinstance(x, tuple) else x)
        
        # 1. Scale total_value: Convert from triệu đ to đồng (VND)
        #    VCI raw: 771888.25 (triệu đ) 
        #    Target: 771888.25 × 1,000,000 = 771,888,250,000 (VND) ← matches KBS
        #    Type: float64 (preserve precision)
        if 'total_value' in df.columns:
            try:
                # Scale from millions to VND, keep as float64
                df['total_value'] = (df['total_value'] * 1_000_000).astype('float64')
            except Exception as e:
                logger.warning(f"Could not scale total_value: {e}")
        
        # 2. Normalize price columns to float64 (maintain decimal precision from API)
        #    ALL prices keep precision: 21700.0, 21773.138..., etc.
        #    Type: float64 (not int64)
        #    Includes: ceiling_price, floor_price, reference_price, open_price,
        #              high_price, low_price, close_price, average_price,
        #              bid_price_1/2/3, ask_price_1/2/3
        try:
            price_cols = [c for c in df.columns if isinstance(c, str) and 'price' in c.lower()]
            for col in price_cols:
                if col in df.columns:
                    df[col] = df[col].astype('float64')
        except Exception as e:
            logger.warning(f"Could not normalize price columns: {e}")
        
        # 3. Normalize volume columns to int64 (shares are discrete)
        #    Includes: bid_vol_1/2/3, ask_vol_1/2/3, total_trades, 
        #              foreign_buy_volume, foreign_sell_volume
        try:
            volume_cols = [c for c in df.columns if isinstance(c, str) and 
                          ('vol' in c.lower() or 'volume' in c.lower() or 'trades' in c.lower())]
            for col in volume_cols:
                if col in df.columns and df[col].dtype != 'object':
                    df[col] = df[col].astype('int64')
        except Exception as e:
            logger.warning(f"Could not normalize volume columns: {e}")
        
        # 4. Calculate derived columns
        #    price_change: float64 (difference of two floats)
        #    percent_change: float64 (percentage with decimals)
        if 'reference_price' in df.columns and 'close_price' in df.columns:
            try:
                df['price_change'] = (df['close_price'] - df['reference_price']).astype('float64')
                df['percent_change'] = (df['price_change'] / df['reference_price'] * 100).round(2)
            except Exception as e:
                logger.warning(f"Could not calculate price_change/percent_change: {e}")
        
        # 5. Add timestamp as 'time' (Unix timestamp in milliseconds)
        #    Format: int64 (milliseconds since epoch)
        try:
            current_time_ms = int(time.time() * 1000)
            df['time'] = current_time_ms
        except Exception as e:
            logger.warning(f"Could not add time column: {e}")
        
        return df

    @agg_execution("VCI.ext")
    def price_board(self, symbols_list: List[str],
                    board: str = 'stock',
                    exchange: str = 'HOSE',
                    show_log: Optional[bool] = False,
                    get_all: bool = False,
                    get_unified: bool = False) -> pd.DataFrame:
        """
        Truy xuất bảng giá realtime cho danh sách mã chứng khoán.

        Unified interface để lấy dữ liệu giá từ ba loại bảng giá:
        - stock: Lô chẵn (giao dịch thông thường)
        - odd_lot: Lô lẻ (giao dịch lô lẻ)
        - put_through: Thỏa thuận (giao dịch thỏa thuận)

        Args:
            symbols_list (List[str]): Danh sách mã chứng khoán (VD: ['ACB', 'VNM', 'HPG']).
            board (str): Loại bảng giá ('stock', 'odd_lot', 'put_through'). Mặc định 'stock'.
            exchange (str): Sàn giao dịch ('HOSE', 'HNX', 'UPCOM'). Mặc định 'HOSE'.
            show_log (bool): Hiển thị log debug.
            get_all (bool): Nếu True, trả về tất cả các cột. Nếu False (mặc định), chỉ trả về các cột tiêu chuẩn.
            get_unified (bool): Nếu True, transform VCI's prefixed columns sang unified schema (khớp với KBS).
                               Nếu False (mặc định), trả về VCI's native format (backward compatible).

        Returns:
            pd.DataFrame: DataFrame chứa thông tin giá realtime.
            - get_unified=False (default): VCI's native format với prefixed columns (listing_*, match_*, bid_ask_*)
            - get_unified=True: Unified schema khớp với KBS (symbol, time, exchange, close_price, ...)

        Examples:
            >>> trading = Trading('ACB')
            >>> df = trading.price_board(['ACB', 'VNM', 'HPG'])  # VCI native format
            >>> df = trading.price_board(['ACB', 'VNM', 'HPG'], get_unified=True)  # Unified with KBS
            >>> df = trading.price_board(['AAA', 'AAM'], board='odd_lot')  # Odd-lot board
            >>> df = trading.price_board(['SCR'], board='put_through')  # Put-through board

        Raises:
            ValueError: Nếu symbols_list trống hoặc board không hợp lệ.
        """
        if not symbols_list:
            raise ValueError("symbols_list không được để trống.")

        valid_boards = ['stock', 'odd_lot', 'put_through']
        if board not in valid_boards:
            raise ValueError(f"board không hợp lệ. Các giá trị hợp lệ: {valid_boards}")

        # Normalize symbols to uppercase
        symbols_list = [s.upper() for s in symbols_list]

        if board == 'stock':
            # Stock board (lô chẵn) - use /price/symbols/getList endpoint
            # Returns realtime order book data with listing info, match prices, and bid/ask queues
            # Keep hierarchical structure by default (match original vnstock behavior)
            df = self._fetch_stock_board(symbols_list, show_log=show_log, flatten_columns=False)
            data_label = 'lô chẵn'
            standard_cols = _STOCK_BOARD_STANDARD_COLUMNS

        elif board == 'odd_lot':
            # Odd-lot board (lô lẻ) - use odd_lot method
            df = self.odd_lot(symbols_list=symbols_list, exchange=exchange, show_log=show_log)
            data_label = 'lô lẻ'
            standard_cols = _ODD_LOT_STANDARD_COLUMNS
        else:  # put_through
            # Put-through board (thỏa thuận) - use put_through method
            df = self.put_through(exchange=exchange, show_log=show_log)
            # Filter by symbols if provided
            if len(df) > 0 and symbols_list:
                df = df[df['symbol'].isin(symbols_list)].reset_index(drop=True)
            data_label = 'thỏa thuận'
            standard_cols = _PUT_THROUGH_STANDARD_COLUMNS

        # Filter columns based on get_all parameter and get_unified transformation
        if len(df) > 0:
            # Apply unified schema transformation if requested (only for stock board)
            if get_unified and board == 'stock':
                from vnstock_data.explorer.vci.const import _VCI_TO_SCHEMA_MAP
                
                # Step 1: Ensure columns are flat strings (required for rename mapping)
                if isinstance(df.columns, pd.MultiIndex):
                    # Flatten hierarchical columns to snake_case format: (prefix, name) → prefix_name
                    df.columns = df.columns.map(lambda x: f"{x[0]}_{x[1]}" if isinstance(x, tuple) else x)
                
                # Step 2: Transform VCI's prefixed columns to unified schema
                df = df.rename(columns=_VCI_TO_SCHEMA_MAP)
                
                # Step 3: Normalize data types and values for KBS compatibility
                df = self._normalize_unified_data(df)
                
                standard_cols = _PRICE_BOARD_STANDARD_COLUMNS
                
                # Step 4: Filter to standard columns if not get_all
                if not get_all:
                    available_cols = [col for col in standard_cols if col in df.columns]
                    df = df[available_cols]
            else:
                # For native VCI format (get_unified=False), keep all columns by default
                # This maintains backward compatibility with original vnstock behavior
                pass
            
            # Normalize exchange codes (HSX → HOSE for consistency)
            if 'exchange' in df.columns:
                df['exchange'] = df['exchange'].map(
                    lambda x: 'HOSE' if x == 'HSX' else x if pd.notna(x) else x
                )
            elif ('listing', 'exchange') in df.columns:
                df[('listing', 'exchange')] = df[('listing', 'exchange')].map(
                    lambda x: 'HOSE' if x == 'HSX' else x if pd.notna(x) else x
                )

        # Update metadata
        df.attrs['symbols'] = symbols_list
        df.attrs['board'] = board
        df.attrs['exchange'] = exchange
        df.attrs['source'] = 'VCI'
        df.attrs['get_all'] = get_all
        df.attrs['get_unified'] = get_unified

        if show_log or self.show_log:
            mode_label = 'unified' if get_unified else 'native'
            logger.info(f'Truy xuất thành công bảng giá {data_label} ({mode_label}) cho {len(symbols_list)} mã chứng khoán.')

        return df

    @agg_execution("VCI.ext")
    def summary(self, resolution: str = '1D', start: Optional[str] = None, 
                end: Optional[str] = None, limit: Optional[int] = 100):
        """
        Truy xuất thống kê giao dịch của mã chứng khoán được chọn.
        
        Args:
            resolution (str): Time resolution for data (default: '1D')
            start (str, optional): Start date in YYYY-mm-dd format
            end (str, optional): End date in YYYY-mm-dd format
            limit (int): Maximum number of records to return (default: 100)
            
        Returns:
            pd.DataFrame: Trading summary data as DataFrame with snake_case columns
        """
        # Validate and process date parameters
        start_date, end_date = self._process_dates(start, end)
        
        # Set up request parameters
        params = {
            'timeFrame': _REPORT_RESOLUTION.get(resolution, 'ONE_DAY'),
            'page': 0,
            'size': limit
        }
        
        # Add date range if provided
        if start_date and end_date:
            params.update({
                'fromDate': start_date,
                'toDate': end_date
            })
        
        # Fetch data using core function
        data = self._fetch_data('price-history-summary', params)
        
        # Convert to DataFrame
        df = self._to_dataframe(data, ['data'])
        # replace foreign to fr in column names if exists
        if not df.empty and any('foreign' in col for col in df.columns):
            df.columns = df.columns.str.replace('foreign', 'fr', regex=False)
        return df

    @agg_execution("VCI.ext")
    def price_history (self, resolution: str = '1D', start: Optional[str] = None, 
                     end: Optional[str] = None, get_all: Optional[bool] = False, limit: Optional[int] = 100):
        """
        Retrieve price history data for the selected stock.
        
        Args:
            resolution (str): Time resolution for data (default: '1D')
            start (str, optional): Start date in YYYY-mm-dd format
            end (str, optional): End date in YYYY-mm-dd format
            get_all (bool, optional): Whether to get all records, including data for foreign trades, or not (default: False)
            limit (int): Maximum number of records to return (default: 100)
            
        Returns:
            pd.DataFrame: Price history data as DataFrame with snake_case columns
        """
        # Validate and process date parameters
        start_date, end_date = self._process_dates(start, end)
        
        # Set up request parameters
        params = {
            'timeFrame': _REPORT_RESOLUTION.get(resolution, 'ONE_DAY'),
            'page': 0,
            'size': limit
        }
        
        # Add date range if provided
        if start_date and end_date:
            params.update({
                'fromDate': start_date,
                'toDate': end_date
            })
        
        # Fetch data using core function
        data = self._fetch_data('price-history', params)
        
        # Handle potential missing or malformed data
        df = self._to_dataframe(data, ['data', 'content'])
        # Replace foreign to fr in column names if exists
        df.columns = df.columns.str.replace('foreign', 'fr', regex=False)
        
        # Define columns to drop and rename mappings
        cols_to_drop = ['id', 'ticker', 'stock_type', 'time_frame', 'index']
        rename_map = {
            'open_price': 'open',
            'close_price': 'close', 
            'highest_price': 'high',
            'lowest_price': 'low',
            'total_match_volume': 'matched_volume',
            'total_match_value': 'matched_value',
            'total_deal_volume': 'deal_volume',
            'total_deal_value': 'deal_value'
        }
        
        # Drop columns only if they exist
        df = df.drop(columns=[col for col in cols_to_drop if col in df.columns])
        
        # Convert trading_date to datetime if exists
        if 'trading_date' in df.columns:
            df['trading_date'] = pd.to_datetime(df['trading_date'])

        if get_all is False:
            # Drop all columns contain fr_ prefix
            df = df.drop(columns=[col for col in df.columns if 'fr_' in col])
            
        # Rename columns only if they exist
        df = df.rename(columns={k:v for k,v in rename_map.items() if k in df.columns})        
        return df
    
    # TO-DO: Tạo 1 hàm helper tách thông tin giao dịch nước ngoài từ hàm price_history

    @agg_execution("VCI.ext")
    def foreign_trade(self, resolution: str = '1D', start: Optional[str] = None, 
                     end: Optional[str] = None, limit: Optional[int] = 100):
        df = self.price_history(resolution=resolution, start=start, end=end, get_all=True, limit=limit)
        df = df[["trading_date"] + [col for col in df.columns if col.startswith("fr_")]]
        return df

    @agg_execution("VCI.ext")
    def prop_trade (self, resolution: str = '1D', start: Optional[str] = None, 
                           end: Optional[str] = None, limit: Optional[int] = 100):
        """
        Retrieve proprietary trading history for the selected stock.
        
        Args:
            resolution (str): Time resolution for data (default: '1D')
            start (str, optional): Start date in YYYY-mm-dd format
            end (str, optional): End date in YYYY-mm-dd format
            limit (int): Maximum number of records to return (default: 100)
            
        Returns:
            pd.DataFrame: Proprietary trading data as DataFrame with snake_case columns
        """
        # Validate and process date parameters
        start_date, end_date = self._process_dates(start, end)
        
        # Set up request parameters
        params = {
            'timeFrame': _REPORT_RESOLUTION.get(resolution, 'ONE_DAY'),
            'page': 0,
            'size': limit
        }
        
        # Add date range if provided
        if start_date and end_date:
            params.update({
                'fromDate': start_date,
                'toDate': end_date
            })
        
        # Fetch data using core function
        data = self._fetch_data('proprietary-history', params)
        
        # Handle potential missing or malformed data
        df = self._to_dataframe(data, ['data', 'content'])
        # replace proprietary to prop in column names if exists
        df.columns = df.columns.str.replace('proprietary', 'prop', regex=False)
        
        # Define columns to drop
        cols_to_drop = ['id', 'ticker', 'organ_code', 'time_frame']
        
        # Drop columns only if they exist
        df = df.drop(columns=[col for col in cols_to_drop if col in df.columns])
        
        # Convert trading_date to datetime if exists
        if 'trading_date' in df.columns:
            try:
                df['trading_date'] = pd.to_datetime(df['trading_date'])
            except Exception as e:
                logger.warning(f"Failed to convert trading_date to datetime: {e}")
                
        # Drop rows where all values are NaN
        df = df.dropna(how='all')
        
        # Reset index after dropping rows
        df = df.reset_index(drop=True)
        
        return df
    
    @agg_execution("VCI.ext")
    def insider_deal (self, limit: Optional[int] = 100, lang: str = 'vi'):
        """
        Retrieve insider transaction data for the selected stock.
        
        Args:
            limit (int): Maximum number of records to return (default: 100)
            
        Returns:
            pd.DataFrame: Insider transaction data as DataFrame with snake_case columns
        """
        # Set up request parameters (no date filtering for insider transactions)
        params = {
            'page': 0,
            'size': limit
        }
        
        # Fetch data using core function
        data = self._fetch_data('insider-transaction', params)
        
        # Handle potential missing or malformed data
        df = self._to_dataframe(data, ['data', 'content'])
        df = filter_columns_by_language(df, lang=lang)  # Filter columns based on language preference
        # Define columns to drop
        cols_to_drop = ['id', 'ticker', 'organ_code', 'display_date1', 'display_date2', 
                       'event_code', 'action_type_code', 'icb_code_lv1']
        
        # Drop columns only if they exist
        df = df.drop(columns=[col for col in cols_to_drop if col in df.columns])
        
        # Convert date columns to datetime
        date_columns = ['start_date', 'end_date', 'public_date'] 
        for col in date_columns:
            if col in df.columns:
                try:
                    df[col] = pd.to_datetime(df[col], errors='coerce')
                except Exception as e:
                    logger.warning(f"Failed to convert {col} to datetime: {e}")
                    
        # Drop rows where all values are NaN
        df = df.dropna(how='all')
        
        # Reset index after dropping rows
        df = df.reset_index(drop=True)
        
        return df

    @agg_execution("VCI.ext")
    def odd_lot(self, symbols_list: Optional[List[str]] = None, 
                exchange: str = 'HOSE',
                show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Truy xuất dữ liệu giao dịch lô lẻ (odd-lot) cho danh sách mã chứng khoán.

        Args:
            symbols_list (List[str], optional): Danh sách mã chứng khoán. Nếu None, truy xuất toàn bộ sàn.
            exchange (str): Sàn giao dịch ('HOSE', 'HNX', 'UPCOM'). Mặc định 'HOSE'.
            show_log (bool): Hiển thị log debug.

        Returns:
            pd.DataFrame: Dữ liệu giao dịch lô lẻ với các cột chuẩn hóa.

        Examples:
            >>> trading = Trading('ACB')
            >>> df = trading.odd_lot(symbols_list=['ACB', 'VNM'])
            >>> df = trading.odd_lot(exchange='HOSE')

        Raises:
            ValueError: Nếu exchange không hợp lệ.
        """
        valid_exchanges = ['HOSE', 'HNX', 'UPCOM']
        if exchange not in valid_exchanges:
            raise ValueError(f"Exchange không hợp lệ. Các giá trị hợp lệ: {valid_exchanges}")

        url = _ODD_LOT_URL
        
        if symbols_list:
            # Normalize symbols to uppercase
            symbols_list = [s.upper() for s in symbols_list]
            payload = {"symbols": symbols_list}
        else:
            # Get all odd-lot data for the exchange
            payload = {"exchange": exchange}

        if show_log or self.show_log:
            logger.info(f'Requested URL: {url} with payload: {payload}')

        try:
            data = send_request(
                url,
                headers=self.headers,
                method="POST",
                payload=json.loads(json.dumps(payload)),
                show_log=show_log or self.show_log,
                proxy_list=self.proxy_config.proxy_list,
                proxy_mode=self.proxy_config.proxy_mode,
                request_mode=self.proxy_config.request_mode
            )
        except Exception as e:
            logger.error(f"Failed to fetch odd_lot data: {str(e)}")
            return pd.DataFrame()

        if not data or not isinstance(data, list):
            return pd.DataFrame()

        # Process data similar to price_board
        rows = []
        for item in data:
            try:
                # Extract matchPrice data for odd_lot
                match_price = item.get('matchPrice', {})
                if not match_price:
                    continue
                
                row = {
                    'symbol': item.get('listingInfo', {}).get('symbol'),
                    'price': match_price.get('matchPrice'),
                    'volume': match_price.get('matchVol'),
                    'highest': match_price.get('highest'),
                    'lowest': match_price.get('lowest'),
                    'open': match_price.get('openPrice'),
                    'avg_price': match_price.get('avgMatchPrice'),
                    'accumulated_volume': match_price.get('accumulatedVolume'),
                    'accumulated_value': match_price.get('accumulatedValue'),
                    'session': match_price.get('session'),
                    'time': match_price.get('time'),
                }
                
                rows.append(row)
            except Exception as e:
                logger.warning(f"Error processing odd_lot item: {e}")
                continue

        if not rows:
            logger.warning(f"No valid odd_lot data found for exchange {exchange}")
            return pd.DataFrame()

        df = pd.DataFrame(rows)
        
        # Keep only standard columns
        standard_cols = [col for col in _ODD_LOT_STANDARD_COLUMNS if col in df.columns]
        df = df[standard_cols]
        
        # Convert timestamp to datetime
        if 'time' in df.columns:
            df['time'] = pd.to_datetime(df['time'], errors='coerce')

        # Add metadata
        if symbols_list:
            df.attrs['symbols'] = symbols_list
        df.attrs['exchange'] = exchange
        df.attrs['source'] = 'VCI'

        if show_log or self.show_log:
            if symbols_list:
                logger.info(f'Truy xuất thành công {len(df)} bản ghi giao dịch lô lẻ cho {len(symbols_list)} mã chứng khoán.')
            else:
                logger.info(f'Truy xuất thành công {len(df)} bản ghi giao dịch lô lẻ cho sàn {exchange}.')

        return df

    @agg_execution("VCI.ext")
    def put_through(self, exchange: str = 'HOSE',
                    show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Truy xuất dữ liệu giao dịch thỏa thuận (put-through) theo sàn.

        Args:
            exchange (str): Sàn giao dịch ('HOSE', 'HNX', 'UPCOM'). Mặc định 'HOSE'.
            show_log (bool): Hiển thị log debug.

        Returns:
            pd.DataFrame: Dữ liệu giao dịch thỏa thuận với các cột chuẩn hóa.

        Examples:
            >>> trading = Trading('ACB')
            >>> df = trading.put_through(exchange='HOSE')

        Raises:
            ValueError: Nếu exchange không hợp lệ.
        """
        valid_exchanges = ['HOSE', 'HNX', 'UPCOM']
        if exchange not in valid_exchanges:
            raise ValueError(f"Exchange không hợp lệ. Các giá trị hợp lệ: {valid_exchanges}")

        url = _PUT_THROUGH_URL
        params = {'group': exchange}

        if show_log or self.show_log:
            logger.info(f'Requested URL: {url} with params: {params}')

        try:
            data = send_request(
                url,
                headers=self.headers,
                method="GET",
                params=params,
                show_log=show_log or self.show_log,
                proxy_list=self.proxy_config.proxy_list,
                proxy_mode=self.proxy_config.proxy_mode,
                request_mode=self.proxy_config.request_mode
            )
        except Exception as e:
            logger.error(f"Failed to fetch put_through data: {str(e)}")
            return pd.DataFrame()

        if not data or not isinstance(data, list):
            return pd.DataFrame()

        # Process data
        rows = []
        for item in data:
            try:
                row = {
                    'symbol': item.get('symbol'),
                    'price': item.get('ptMatchPrice'),
                    'volume': item.get('ptMatchVolume'),
                    'change': item.get('ptChange'),
                    'change_percent': item.get('ptChangePercent'),
                    'match_value': item.get('ptMatchValue'),
                    'accumulated_volume': item.get('ptAccumulatedVolume'),
                    'accumulated_value': item.get('ptAccumulatedValue'),
                    'time': item.get('time'),
                }
                
                rows.append(row)
            except Exception as e:
                logger.warning(f"Error processing put_through item: {e}")
                continue

        if not rows:
            logger.warning(f"No valid put_through data found for exchange {exchange}")
            return pd.DataFrame()

        df = pd.DataFrame(rows)
        

        
        # Convert timestamp to datetime
        if 'time' in df.columns:
            df['time'] = pd.to_datetime(df['time'], errors='coerce')

        # Add metadata
        df.attrs['exchange'] = exchange
        df.attrs['source'] = 'VCI'

        if show_log or self.show_log:
            logger.info(f'Truy xuất thành công {len(df)} bản ghi giao dịch thỏa thuận cho sàn {exchange}.')

        return df

    # @agg_execution("VCI.ext")
    # def trading_stats (self, start:Optional[str]='2000-01-01', end:Optional[str]='2099-12-31', limit:Optional[int]=5000, offset:Optional[int]=0, dropna:Optional[bool]=True, to_df:Optional[bool]=True):
    #     """
    #     Truy xuất thống kê lịch sử giao dịch của mã chứng khoán được chọn.

    #     Tham số:
    #         - limit (tùy chọn): Số lượng bản ghi trả về. Mặc định là 100.
    #         - offset (tùy chọn): Số lượng bản ghi bỏ qua. Mặc định là 0.
    #         - from_date (tùy chọn): Ngày bắt đầu lấy dữ liệu theo định dạng YYYY-mm-dd. Mặc định là '2000-01-01'.
    #         - to_date (tùy chọn): Ngày kết thúc lấy dữ liệu theo định dạng YYYY-mm-dd. Mặc định là '2099-12-31'.
    #     """
    #     # loop through start and end date to validate date format and show log if invalid
    #     if not validate_date(start) or not validate_date(end):
    #         logger.error(f"Invalid date format. Please use the format YYYY-mm-dd.")
    #         return None

    #     payload = "{\"query\":\"query Query($ticker: String!, $offset: Int!, $offsetInsider: Int!, $limit: Int!, $fromDate: String!, $toDate: String!) {\\n  TickerPriceHistory(\\n    ticker: $ticker\\n    offset: $offset\\n    limit: $limit\\n    fromDate: $fromDate\\n    toDate: $toDate\\n  ) {\\n    history {\\n      tradingDate\\n      stockType\\n      ceilingPrice\\n      floorPrice\\n      referencePrice\\n      openPrice\\n      closePrice\\n      matchPrice\\n      priceChange\\n      percentPriceChange\\n      highestPrice\\n      lowestPrice\\n      averagePrice\\n      totalMatchVolume\\n      totalMatchValue\\n      totalDealVolume\\n      totalDealValue\\n      totalVolume\\n      totalValue\\n      foreignNetTradingVolume\\n      foreignNetTradingValue\\n      foreignBuyValueMatched\\n      foreignBuyVolumeMatched\\n      foreignSellValueMatched\\n      foreignSellVolumeMatched\\n      foreignBuyValueDeal\\n      foreignBuyVolumeDeal\\n      foreignSellValueDeal\\n      foreignSellVolumeDeal\\n      foreignBuyValueTotal\\n      foreignBuyVolumeTotal\\n      foreignSellValueTotal\\n      foreignSellVolumeTotal\\n      foreignTotalRoom\\n      foreignCurrentRoom\\n      foreignHoldingVolume\\n      suspension\\n      delist\\n      haltResumeFlag\\n      split\\n      benefit\\n      meeting\\n      notice\\n      totalTrade\\n      totalBuyTrade\\n      totalBuyTradeVolume\\n      totalSellTrade\\n      totalSellTradeVolume\\n      referencePriceAdjusted\\n      openPriceAdjusted\\n      closePriceAdjusted\\n      priceChangeAdjusted\\n      percentPriceChangeAdjusted\\n      highestPriceAdjusted\\n      lowestPriceAdjusted\\n      unMatchedBuyTradeVolume\\n      unMatchedSellTradeVolume\\n      difVolumeBuySell\\n      averageVolumeBuyOrder\\n      averageVolumeSellOrder\\n      __typename\\n    }\\n    totalRecords\\n    __typename\\n  }\\n  OrganizationDeals(\\n    ticker: $ticker\\n    offset: $offsetInsider\\n    limit: $limit\\n    fromDate: $fromDate\\n    toDate: $toDate\\n  ) {\\n    history {\\n      id\\n      organCode\\n      tradeTypeCode\\n      dealTypeCode\\n      actionTypeCode\\n      tradeStatusCode\\n      traderOrganCode\\n      shareBeforeTrade\\n      ownershipBeforeTrade\\n      shareRegister\\n      shareAcquire\\n      shareAfterTrade\\n      ownershipAfterTrade\\n      startDate\\n      endDate\\n      sourceUrl\\n      publicDate\\n      ticker\\n      traderPersonId\\n      traderName\\n      en_TraderName\\n      positionShortName\\n      en_PositionShortName\\n      positionName\\n      en_PositionName\\n      __typename\\n    }\\n    totalRecords\\n    __typename\\n  }\\n}\\n\",\"variables\":{\"ticker\":\"VCI\",\"limit\":15,\"offset\":0,\"offsetInsider\":0,\"fromDate\":\"2000-01-01\",\"toDate\":\"2100-01-01\"}}"
    #     payload_json = json.loads(payload)
    #     payload_json['variables']['limit'] = limit
    #     payload_json['variables']['ticker'] = self.symbol
    #     payload_json['variables']['offset'] = offset
    #     payload_json['variables']['fromDate'] = start
    #     payload_json['variables']['toDate'] = end

    #     # convert payload_json to string
    #     payload_json = json.dumps(payload_json)

    #     if self.show_log:
    #         logger.info(f"Querying data from {url}, payload: {payload_json}")

    #     response = requests.post(_GRAPHQL_URL, data=payload_json, headers=self.headers)
    #     if response.status_code != 200:
    #         logger.error(f"Error {response.status_code}: {response.text}")
    #         return None
    #     data = response.json()

    #     if self.show_log:
    #         logger.info(f"Response data: {data}")

    #     data = data['data']['TickerPriceHistory']['history']
    #     df = pd.DataFrame(data)

    #     try:
    #         # drop columns: '__typename'
    #         df = df.drop(columns=['__typename', 'stockType'])
    #         # convert column names to snake case
    #         df.columns = [camel_to_snake(col) for col in df.columns]
    #         # rename columns: un_matched_buy_trade_volume, un_matched_sell_trade_volume
    #         df = df.rename(columns={'un_matched_buy_trade_volume':'unmatched_buy_trade_volume', 
    #                                 'un_matched_sell_trade_volume':'unmatched_sell_trade_volume',
    #                                 'trading_date': 'time',
    #                                 # 'open_price': 'open',
    #                                 # 'close_price': 'close',
    #                                 # 'highest_price': 'high',
    #                                 # 'lowest_price': 'low',
    #                                 })

    #         if dropna:
    #             df = df.dropna(how='all')
    #             # drop rows that all values are zero
    #             # df = df[(df != 0).any(axis=1)]  # drop rows where all values are 0
                
    #             # # Handle columns where all values are zero
    #             zero_columns = [col for col in df.columns if df[col].sum() == 0]
    #             df = df.drop(columns=zero_columns)

    #         # convert trading_date to datetime from unix timestamp
    #         df['time'] = pd.to_datetime(df['time'], unit='ms')
    #         # sort by time column
    #         df = df.sort_values(by='time', ascending=False).reset_index(drop=True)

    #     except Exception as e:
    #         logger.error(f'Error details: {e}')

    #     # Add metadata attributes
    #     df.attrs['name'] = self.symbol
    #     df.attrs['category'] = self.asset_type
    #     df.attrs['source'] = 'VCI'

    #     if to_df:
    #         return df
    #     else:
    #         return df.to_dict(orient='records')
        
    # @agg_execution("VCI.ext")
    # def side_stats (self, dropna:Optional[bool]=True, to_df:Optional[bool]=True):
    #     """
    #     Truy xuất dữ liệu cung cầu của mã chứng khoán được chọn.
    #     """

    #     url = f'{_TRADING_URL}price/symbols/getList'
    #     payload = {"symbols": ["VN30F2406"]}
    #     # payload_json = json.loads(payload)
    #     payload['symbols'] = [self.symbol]

    #     if self.show_log:
    #         logger.info(f"Querying data from {url}, payload: {payload}")

    #     response = requests.post(url, headers=self.headers, data=json.dumps(payload))
        
    #     if response.status_code != 200:
    #         logger.error(f"Error {response.status_code}: {response.text}")
    #         return None
        
    #     data = response.json()[0]

    #     if self.show_log:
    #         logger.info(f"Response data: {data}")

    #     listing_info = data['listingInfo']
    #     bid_ask = data['bidAsk']
    #     match_info = data['matchPrice']

    #     return listing_info, bid_ask, match_info

# Register provider
from vnstock_data.core.registry import ProviderRegistry  # noqa: E402, F401
ProviderRegistry.register('trading', 'vci', Trading)
