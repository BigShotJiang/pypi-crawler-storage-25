"""
VCI Events Explorer module.
"""

from typing import Dict, Optional, Union
import pandas as pd
from vnstock.core.utils.logger import get_logger
from vnstock.core.utils.parser import camel_to_snake
from vnstock_data.core.utils.client import send_request
from vnstock_data.core.utils.user_agent import get_headers
from vnstock_data.explorer.vci.const import _VCI_EVENTS_URL
from vnai import agg_execution
from datetime import datetime

logger = get_logger(__name__)

class Event:
    """
    Class to manage event information from the VCI data source.
    """
    def __init__(self, random_agent: bool = False, show_log: bool = False):
        self.headers = get_headers(data_source='VCI', random_agent=random_agent)
        self.show_log = show_log
        if not show_log:
            logger.setLevel('CRITICAL')

    @agg_execution("VCI.ext")
    def calendar(self, start: str = None, end: str = None, 
                 event_type: Optional[str] = None,
                 page: int = 0, limit: int = 20000, 
                 show_log: bool = False) -> pd.DataFrame:
        """
        Retrieve events calendar (dividends, AGM, new listings, ...) from VCI.
        
        Args:
            start (str): Start date (YYYY-MM-DD). If None, defaults to the current date.
            end (str): End date (YYYY-MM-DD). If None, defaults to the current date.
            event_type (str, optional): Type of event or event group:
                - 'dividend': Returns dividends, share issuance (ISS, DIV)
                - 'insider': Returns insider trading, major shareholders (DDIND, DDRP, DDINS)
                - 'agm': Returns shareholder meetings (EGME, AGME, AGMR)
                - 'others': Returns other fluctuations (MOVE, MA, NLIS, AIS, RETU, OTHE, SUSP)
                - Or a specific eventCode (e.g., 'ISS,DIV')
            page (int): Page index. Defaults to 0.
            limit (int): Number of records per page. Defaults to 20000.
            show_log (bool): Show logs.
            
        Returns:
            pd.DataFrame: List of events.
        """
        if start is None:
            start = datetime.now().strftime('%Y-%m-%d')
        if end is None:
            end = start
            
        # VCI API uses YYYYMMDD format for dates in query params
        vci_from_date = start.replace('-', '').replace('/', '')
        vci_to_date = end.replace('-', '').replace('/', '')
        
        url = f"{_VCI_EVENTS_URL}?fromDate={vci_from_date}&toDate={vci_to_date}&page={page}&size={limit}"
        
        # Friendly event_type mapping
        event_type_map = {
            'dividend': 'ISS,DIV',
            'insider': 'DDIND,DDRP,DDINS',
            'agm': 'EGME,AGME,AGMR',
            'others': 'MOVE,MA,NLIS,AIS,RETU,OTHE,SUSP'
        }
        
        if event_type:
            event_code = event_type_map.get(event_type.lower(), event_type)
            event_code_encoded = event_code.replace(',', '%2C')
            url += f"&eventCode={event_code_encoded}"
        
        headers = self.headers.copy()
        headers.update({
            'Accept': 'application/json',
            'Accept-Language': 'en-US,en;q=0.9,vi;q=0.8',
            'Connection': 'keep-alive',
            'DNT': '1',
            'Origin': 'https://trading.vietcap.com.vn',
            'Referer': 'https://trading.vietcap.com.vn/',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-site',
            'sec-ch-ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
        })

        if show_log or self.show_log:
            logger.info(f"Fetching events calendar from {start} to {end} (type: {event_type})")

        response = send_request(
            url=url,
            headers=headers,
            method="GET",
            show_log=show_log or self.show_log
        )
        
        if not response or 'data' not in response or 'content' not in response['data']:
            return pd.DataFrame()
            
        df = pd.DataFrame(response['data']['content'])
        
        if df.empty:
            return df
            
        # Standardize column names to snake_case
        df.columns = [camel_to_snake(col) for col in df.columns]
        
        # Convert date columns to datetime objects
        date_cols = ['display_date1', 'display_date2', 'public_date', 'issue_date', 'record_date', 'exright_date', 'payout_date']
        for col in date_cols:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col], format='ISO8601', errors='coerce')
                
        return df

# Register provider
from vnstock_data.core.registry import ProviderRegistry
ProviderRegistry.register('event', 'vci', Event)
