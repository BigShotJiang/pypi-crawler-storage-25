"""
Module quản lý thông tin báo cáo tài chính từ nguồn dữ liệu VCI.
"""

import json
import pandas as pd
from typing import Optional, Dict, Tuple, Union
from .const import _VCIQ_URL, _IQ_FINANCE_REPORT
from vnstock.explorer.vci.const import _GRAPHQL_URL, _UNIT_MAP, SUPPORTED_LANGUAGES
from vnstock.core.utils.parser import get_asset_type, camel_to_snake
from vnstock.core.utils.logger import get_logger
from vnstock.core.utils.transform import reorder_cols
from vnstock_data.core.utils.client import send_request, ProxyConfig
from vnstock_data.core.utils.user_agent import get_headers
from vnstock_data.core.utils.parser import vn_to_snake_case
from vnstock_data.core.utils.transform import generate_period, remove_pattern_columns
from vnai import agg_execution

logger = get_logger(__name__)

class Finance:
    """
    Truy xuất thông tin báo cáo tài chính của một công ty theo mã chứng khoán từ nguồn dữ liệu VCI.

    Tham số:
        - symbol (str): Mã chứng khoán của công ty cần truy xuất thông tin.
        - period (str): Chu kỳ báo cáo tài chính cần truy xuất. Mặc định là 'quarter'.
        - get_all (bool): Trả về tất cả các trường dữ liệu hoặc chỉ các trường chọn lọc. Mặc định là True.
        - show_log (bool): Hiển thị thông tin log hoặc không. Mặc định là True.
    """

    def __init__(self, symbol: str, period: Optional[Union[str, None]] = None, 
                 get_all: Optional[bool] = True, proxy_config: Optional[ProxyConfig] = None, 
                 show_log: Optional[bool] = False):
        """
        Khởi tạo đối tượng Finance với các tham số cho việc truy xuất dữ liệu báo cáo tài chính.
        """
        self.symbol = symbol.upper()
        self.asset_type = get_asset_type(self.symbol)
        self.headers = get_headers(data_source='VCI')
        self.base_url = _VCIQ_URL
        self.show_log = show_log
        self.proxy_config = proxy_config if proxy_config is not None else ProxyConfig()

        if not show_log:
            logger.setLevel('CRITICAL')

        # Validate input for period
        if period not in ['year', 'quarter'] and period != None:
            raise ValueError("Kỳ báo cáo tài chính không hợp lệ. Chỉ chấp nhận 'year' hoặc 'quarter' hoặc None.")
        
        # If asset_type is not stock, raise error
        if self.asset_type not in ['stock']:
            raise ValueError("Mã chứng khoán không hợp lệ. Chỉ cổ phiếu mới có thông tin.")
            
        self.period = period
        self.get_all = get_all

    @staticmethod
    def duplicated_columns_handling(df_or_mapping, target_col_name=None):
        """
        Handle duplicated column names in a DataFrame or column mapping DataFrame.
        
        Parameters:
            - df_or_mapping (pd.DataFrame): Either a DataFrame with potentially duplicated columns
            or a mapping DataFrame with columns that may have duplicated values.
            - target_col_name (str, optional): When handling a mapping DataFrame, this is the column
            to check for duplicates. When None, assumes we're handling DataFrame columns directly.
        
        Returns:
            pd.DataFrame: DataFrame with resolved column duplications.
        """
        if target_col_name is not None:
            # Original behavior for handling mapping DataFrames
            # Duplicated subset
            duplicated_subset = df_or_mapping[df_or_mapping[target_col_name].duplicated()].copy()
            # Non-duplicated subset
            non_duplicated_subset = df_or_mapping[~df_or_mapping[target_col_name].duplicated()].copy()
            # Replace values in the duplicated columns by appending the field_name
            duplicated_subset[target_col_name] = df_or_mapping['name'] + ' - ' + df_or_mapping['field_name']
            # Combine the two subsets
            return pd.concat([non_duplicated_subset, duplicated_subset])
        else:
            # New behavior for handling DataFrame columns directly
            df = df_or_mapping.copy()
            # Find columns that have any duplicates at all
            duplicate_mask = df.columns.duplicated(keep=False)
            duplicated_col_names = df.columns[duplicate_mask].unique()

            if len(duplicated_col_names) > 0:
                new_columns = df.columns.tolist()
                for col_name in duplicated_col_names:
                    # Find all indices where this column name appears
                    indices = [i for i, name in enumerate(new_columns) if name == col_name]
                    # For each duplicate (starting from the 2nd), add underscores as prefix
                    for dup_idx, idx in enumerate(indices):
                        if dup_idx == 0:
                            continue  # First occurrence remains unchanged
                        new_col_name = ('_' * dup_idx) + col_name
                        # Ensure uniqueness in case the new name already exists
                        while new_col_name in new_columns:
                            dup_idx += 1
                            new_col_name = ('_' * dup_idx) + col_name
                        new_columns[idx] = new_col_name
                df.columns = new_columns
            return df
    
    def _get_ratio_dict(self, lang:str='vi', format:str='dict', style:str='readable', show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Lấy từ điển ánh xạ cho tất cả các chỉ số tài chính từ nguồn VCI.

        Tham số:
            - lang (str): Ngôn ngữ của báo cáo. Mặc định là 'en'.
            - format (str): Định dạng trả về. Mặc định là 'dict', lựa chọn khác có thể là 'dataframe'.
            - style (str): Định dạng trả về. Mặc định là 'readable', lựa chọn khác có thể là 'code'.
            - show_log (bool): Hiển thị thông tin log hoặc không. Mặc định là False.
            
        Returns:
            pd.DataFrame: DataFrame chứa ánh xạ giữa 'field_name', 'name', 'en_name', 'type', 'order', 'unit'.
        """
        # Validate language
        if lang not in SUPPORTED_LANGUAGES:
            raise ValueError("Ngôn ngữ '" + lang + "' không hợp lệ. Chỉ chấp nhận " + ', '.join(SUPPORTED_LANGUAGES) + ".")

        # Validate format
        if format not in ['dict', 'dataframe']:
            raise ValueError("Định dạng '" + str(format) + "' không hợp lệ. Chỉ chấp nhận 'dict' hoặc 'dataframe'.")

        url = f'{self.base_url}/v1/company/{self.symbol}/financial-statement/metrics'
        
        if show_log:
            logger.debug(f"Requesting financial ratio data from {url}")
        
        # Use api_client.send_request instead of direct requests
        response_data = send_request(
            url=url,
            headers=self.headers,
            method="GET",
            payload=None,
            show_log=show_log,
            proxy_list=self.proxy_config.proxy_list,
            proxy_mode=self.proxy_config.proxy_mode,
            request_mode=self.proxy_config.request_mode
        )
        
        data = response_data['data']

        combine_ls = []
        for key in data.keys():
            df = pd.DataFrame(data[key])
            df['report_name'] = key
            df = df[['report_name', 'field', 'parent', 'titleEn', 'titleVi', 'fullTitleVi', 'fullTitleEn']]
            combine_ls.append(df)

        df = pd.concat(combine_ls)
        # Cột mới: full_name và en_full_name
        # Cột loại bỏ : unit,
        df = df.rename(columns={'field': 'field_name', 'titleVi': 'name', 'titleEn': 'en_name', 'fullTitleVi': 'full_name', 'fullTitleEn': 'en_full_name'})

        if format == 'dict':
            if lang == 'vi':
                if style == 'readable':
                    return df.set_index('field_name')['name'].to_dict()
                elif style == 'code':
                    return {
                        vn_to_snake_case(str(k).lower()): vn_to_snake_case(str(v).lower())
                        for k, v in df.set_index('field_name')['name'].to_dict().items()
                        if pd.notna(k) and pd.notna(v)
                    }
            elif lang == 'en':
                if style == 'code':
                    return {
                        str(k).lower(): str(v).lower().replace(' ', '_')
                        for k, v in df.set_index('field_name')['en_name'].to_dict().items()
                        if pd.notna(k) and pd.notna(v)
                    }
                elif style == 'readable':
                    return {
                        k: v for k, v in df.set_index('field_name')['en_full_name'].to_dict().items()
                        if pd.notna(k) and pd.notna(v)
                    }
        else:
            return df

    def _get_old_ratio_dict(self, show_log: Optional[bool] = False, 
                       get_all: Optional[bool] = False) -> pd.DataFrame:
        """
        Lấy từ điển ánh xạ cho tất cả các chỉ số tài chính từ nguồn VCI.

        Tham số:
            - show_log (bool): Hiển thị thông tin log hoặc không. Mặc định là False.
            - get_all (bool): Lấy tất cả cột hoặc không. Mặc định là False.
            
        Returns:
            pd.DataFrame: DataFrame chứa ánh xạ giữa 'field_name', 'name', 'en_name', 'type', 'order', 'unit'.
        """
        
        payload = "{\"query\":\"query Query {\\n  ListFinancialRatio {\\n    id\\n    type\\n    name\\n    unit\\n    isDefault\\n    fieldName\\n    en_Type\\n    en_Name\\n    tagName\\n    comTypeCode\\n    order\\n    __typename\\n  }\\n}\\n\",\"variables\":{}}"
        
        payload_json = json.loads(payload)
        
        if show_log:
            logger.debug(f"Requesting financial ratio data from {_GRAPHQL_URL}. payload: {payload}")
        
        # Use api_send_request instead of direct requests
        response_data = send_request(
            url=_GRAPHQL_URL,
            headers=self.headers,
            method="POST",
            payload=payload_json,
            show_log=show_log,
            proxy_list=self.proxy_config.proxy_list,
            proxy_mode=self.proxy_config.proxy_mode,
            request_mode=self.proxy_config.request_mode
        )
        
        data = response_data['data']['ListFinancialRatio']
        df = pd.DataFrame(data)
        df.columns = [camel_to_snake(col).replace('__', '_') for col in df.columns]
        
        effective_get_all = get_all if get_all is not None else self.get_all
        selected_columns = ['field_name', 'name', 'en_name', 'type', 'order', 'unit', 'com_type_code']
        df['unit'] = df['unit'].map(_UNIT_MAP)
        
        if effective_get_all is False:
            df = df[selected_columns]
            
        df.columns = [col.replace('__', '_') for col in df.columns]
        return df

    def _get_report(self, report_type:Union[str, None] = None, lang: Optional[str] = 'en', 
                   show_log: Optional[bool] = False, 
                   mode: Optional[str] = 'final', 
                   style: Optional[str] = 'readable',
                   get_all: Optional[bool] = False) -> Union[
                       Tuple[Dict[str, pd.DataFrame], pd.DataFrame], pd.DataFrame]:
        """
        Lấy dữ liệu báo cáo tài chính cho một công ty từ nguồn VCI.
        
        Tham số:
            - report_type (str): Loại báo cáo tài chính bao gồm 'income_statement', 'balance_sheet', 'cash_flow' và 'note'
            - lang (str): Ngôn ngữ của báo cáo. Mặc định là 'en'.
            - show_log (bool): Hiển thị thông tin log hoặc không. Mặc định là False.
            - mode (str): Chế độ báo cáo. Mặc định là 'final' trả về dữ liệu đã xử lý sau quá trình ánh xạ. 
              Chế độ khác là 'raw' trả về dữ liệu thô chứa tên mã cho tất cả các trường.
            - style (str): Chế độ tên cột. Mặc định là 'readable' trả về tên cột dễ đọc. 
              Chế độ khác là 'code' trả về tên cột mã hóa.
            - get_all (bool): Trả về tất cả các trường dữ liệu hoặc chỉ các trường chọn lọc. Mặc định là False.
              
        Returns:
            Union[Tuple[Dict[str, pd.DataFrame], pd.DataFrame], pd.DataFrame]: 
                Nếu mode='final': Trả về tuple gồm dictionary các báo cáo chính và DataFrame cho các báo cáo khác
                Nếu mode='raw': Trả về DataFrame dữ liệu thô
        """
        # Validate language
        if lang not in SUPPORTED_LANGUAGES:
            supported_languages_str = ", ".join(SUPPORTED_LANGUAGES)
            raise ValueError(f"Ngôn ngữ không hợp lệ: '{lang}'. Các ngôn ngữ được hỗ trợ: {supported_languages_str}.")

        # Validate report_type should be in _IQ_FINANCE_REPORT keys
        if report_type not in _IQ_FINANCE_REPORT.keys():
            raise ValueError("Loại báo cáo tài chính không hợp lệ: '" + str(report_type) + "'. Các loại báo cáo tài chính được hỗ trợ: " + ', '.join(_IQ_FINANCE_REPORT.keys()) + ".")
        else:
            report_type = _IQ_FINANCE_REPORT[report_type]

        
        if report_type == 'RATIO':
            params = {}
            url = f'https://iq.vietcap.com.vn/api/iq-insight-service/v1/company/{self.symbol}/statistics-financial'
        else:
            url = f'https://iq.vietcap.com.vn/api/iq-insight-service/v1/company/{self.symbol}/financial-statement'
            params = {"section": report_type}
        
        if show_log:
            logger.debug(f"Requesting financial report data from {url}. payload: {params}")
        
        # Use api_client.send_request instead of direct requests
        response_data = send_request(
            url=url,
            headers=self.headers,
            method="GET",
            params=params,
            payload=None,
            show_log=show_log,
            proxy_list=self.proxy_config.proxy_list,
            proxy_mode=self.proxy_config.proxy_mode,
            request_mode=self.proxy_config.request_mode
        )
        
        # Extract relevant data
        try:
            if response_data is None or 'data' not in response_data or response_data['data'] is None:
                error_msg = "No data received from the API"
                if show_log:
                    logger.error(f"{error_msg}. Response: {response_data}")
                raise ValueError(error_msg)
            data = response_data['data']

            if report_type == 'RATIO':
                # data là list
                if not isinstance(data, list):
                    error_msg = f"Unexpected data format for ratio. Expected list, got {type(data).__name__}"
                    if show_log:
                        logger.error(f"{error_msg}. Data: {data}")
                    raise ValueError(error_msg)
                df = pd.DataFrame(data)
                if df.empty:
                    error_msg = "No valid ratio data found in the response"
                    if show_log:
                        logger.error(f"{error_msg}. Data: {data}")
                    raise ValueError(error_msg)
                combined_df = df
            else:
                # data là dict
                if not isinstance(data, dict):
                    error_msg = f"Unexpected data format. Expected dict, got {type(data).__name__}"
                    if show_log:
                        logger.error(f"{error_msg}. Data: {data}")
                    raise ValueError(error_msg)
                df_list = []
                for period, period_data in data.items():
                    if period_data:
                        df = pd.DataFrame(period_data)
                        if not df.empty:
                            df['report_period'] = period[:-1]
                            df_list.append(df)
                if not df_list:
                    error_msg = "No valid data found in the response"
                    if show_log:
                        logger.error(f"{error_msg}. Data: {data}")
                    raise ValueError(error_msg)
                combined_df = pd.concat(df_list, ignore_index=True)

            if mode == 'final':
                final_df = self._ratio_mapping(
                    report_df=combined_df, 
                    lang=lang, 
                    style=style, 
                    get_all=get_all, 
                    show_log=show_log
                )
                return final_df
            elif mode == 'raw':
                return combined_df
            else:
                error_msg = f"Invalid mode: {mode}. Must be 'final' or 'raw'."
                logger.error(error_msg)
                raise ValueError(error_msg)
        except Exception as e:
            logger.error(f"Error processing financial report data: {e}", exc_info=True)
            raise

    @agg_execution("VCI.ext")
    def _ratio_mapping(self, report_df: pd.DataFrame, lang: Optional[str] = 'vi', style: str = 'readable', get_all: Optional[bool] = False, show_log: Optional[bool] = False):
        """
        A dedicated method to map the financial ratio DataFrame columns to the dictionary ratio_dict.

        Parameters:
            - report_df (pd.DataFrame): The DataFrame containing the financial ratio from the function _get_report().
            - lang (str): The language of the report. Default is 'vi'.
            - style (str): The style of the report. Default is 'readable'.
            - get_all (bool): Whether to get all raw columns or just essential columns. Default is False for removing optional columns.
            - show_log (bool): Whether to show log messages. Default is False.

        Returns:
            - pd.DataFrame: A DataFrame containing the financial ratio data.
        """
        # Validate language
        if lang not in SUPPORTED_LANGUAGES:
            supported_languages_str = ", ".join(SUPPORTED_LANGUAGES)
            raise ValueError("Ngôn ngữ không hợp lệ: '" + str(lang) + "'. Các ngôn ngữ được hỗ trợ: " + supported_languages_str + ".")
        
        # Validate style
        if style not in ['readable', 'code']:
            raise ValueError("Chế độ không hợp lệ: '" + str(style) + "'. Chế độ được hỗ trợ: 'readable' cho tên hiển thị hoặc 'code' cho tên mã.")

        ratio_dict = self._get_ratio_dict(lang=lang, style=style, format='dict')

        report_df.columns = [ratio_dict[col] if col in ratio_dict else col for col in report_df.columns]
        # Bổ sung tạo cột lengthReport và yearReport nếu thiếu (áp dụng cho dữ liệu ratio)
        if 'lengthReport' not in report_df.columns and 'quarter' in report_df.columns:
            report_df['lengthReport'] = report_df['quarter']
        if 'yearReport' not in report_df.columns and 'year' in report_df.columns:
            report_df['yearReport'] = report_df['year']
        # Bổ sung sinh report_period nếu thiếu
        if 'report_period' not in report_df.columns:
            if 'quarter' in report_df.columns:
                # Nếu quarter==5 thì là báo cáo năm
                report_df['report_period'] = report_df['quarter'].apply(lambda x: 'year' if x == 5 else 'quarter')
            else:
                report_df['report_period'] = 'year'
        # Điều chỉnh lengthReport: nếu quarter==5 thì lengthReport=4 (để period không ra dạng YYYY-Q5)
        if 'quarter' in report_df.columns and 'lengthReport' in report_df.columns:
            mask = report_df['quarter'] == 5
            report_df.loc[mask, 'lengthReport'] = 4
        report_df = generate_period(report_df)
        report_df = reorder_cols(report_df, cols=['period', 'report_period', 'organCode', 'ticker', 'createDate', 'updateDate', 'yearReport', 'lengthReport', 'publicDate'], position='first')
        if lang == 'en':
            report_df = report_df.set_index('period')
        elif lang == 'vi':
            if style == 'readable':
                report_df = report_df.rename(columns={'period': 'Kỳ báo cáo', 'ticker': 'Mã CP'})
                report_df = report_df.set_index('Kỳ báo cáo')
            elif style == 'code':
                report_df = report_df.rename(columns={'period': 'ky_bao_cao', 'ticker': 'cp'})
                report_df = report_df.set_index('ky_bao_cao')

        if get_all == False:
            # Chỉ drop các cột nếu thực sự tồn tại trong DataFrame
            drop_cols = ['organCode', 'createDate', 'updateDate', 'yearReport', 'lengthReport', 'publicDate']
            cols_to_drop = [col for col in drop_cols if col in report_df.columns]
            if cols_to_drop:
                report_df = report_df.drop(columns=cols_to_drop)

            try:
                # Loại bỏ các cột theo pattern mặc định
                report_df = remove_pattern_columns(report_df, ['bsa', 'bsb', 'bsi', 'bss', 'nob', 'nos', 'cfa', 'cfs', 'cfi', 'isa', 'isb', 'isi', 'iss'])
                
                # Loại bỏ các cột dạng mã (isb25, bsa10...) mà không có mapping (vẫn còn là mã) và có giá trị null
                import re
                code_pattern = re.compile(r'^[a-z]{2,3}\d+$', re.IGNORECASE)
                cols_to_drop = []
                for col in report_df.columns:
                    if code_pattern.match(str(col)):
                        # Nếu cột toàn null hoặc người dùng muốn loại bỏ các mã thô
                        if report_df[col].isna().all() or True: # Force drop unmapped codes as requested
                            cols_to_drop.append(col)
                
                if cols_to_drop:
                    report_df = report_df.drop(columns=cols_to_drop)
                    
            except Exception as e:
                logger.error(f"Error removing pattern columns: {e}")
                raise
            finally:
                return report_df
        else:
            return report_df

    def _get_financial_report(self, report_type: str, period: Optional[str] = None, lang: Optional[str] = 'en', 
                             mode: Optional[str] = 'final', style: Optional[str] = 'readable',
                             get_all: Optional[bool] = False, dropna: Optional[bool] = True, show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Internal method to retrieve and filter financial reports by type and period.
        """
        # Validate supported lang values
        if lang not in SUPPORTED_LANGUAGES:
            raise ValueError("Ngôn ngữ không hợp lệ: '" + str(lang) + "'. Các ngôn ngữ được hỗ trợ: " + ', '.join(SUPPORTED_LANGUAGES) + ".")

        # Validate report_type: balance_sheet, income_statement, cash_flow, note
        if report_type not in ['balance_sheet', 'income_statement', 'cash_flow', 'note', 'ratio']:
            raise ValueError("Loại báo cáo tài chính không hợp lệ: '" + str(report_type) + "'. Các loại báo cáo tài chính được hỗ trợ: 'balance_sheet', 'income_statement', 'cash_flow', 'note'.")

        df = self._get_report(report_type=report_type, lang=lang, mode=mode, style=style, get_all=get_all, show_log=show_log)

        # Nếu period là None hoặc không phải 'year' hoặc 'quarter' thì trả về toàn bộ DataFrame
        if period is None or period not in ['year', 'quarter']:
            if report_type == 'balance_sheet':
                df = self.duplicated_columns_handling(df)
            return df
        # Nếu period là 'year' hoặc 'quarter', chỉ lọc các kỳ tương ứng
        period_key = period
        if 'report_period' in df.columns:
            mask = df['report_period'].astype(str).str.contains(period_key, case=False, regex=False)
            filtered = df[mask].copy()
            if filtered.empty:
                logger.warning(f"Không tìm thấy kỳ báo cáo {period_key} trong cột report_period.")
            if report_type == 'balance_sheet':
                filtered = self.duplicated_columns_handling(filtered)
            return filtered
        else:
            logger.error("Không thể lọc theo kỳ báo cáo: Không tìm thấy cột report_period.")
            if report_type == 'balance_sheet':
                df = self.duplicated_columns_handling(df)
            return df

    @agg_execution("VCI.ext")
    def balance_sheet(self, period: Optional[str] = None, lang: Optional[str] = 'en', 
                    mode: Optional[str] = 'final', 
                    style: Optional[str] = 'readable',
                    get_all: Optional[bool] = False,
                    dropna: Optional[bool] = True, 
                    show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Trích xuất dữ liệu bảng cân đối kế toán cho một công ty từ nguồn VCI.

        Tham số:
            - period (str): Kỳ báo cáo tài chính. Mặc định là None.
            - lang (str): Ngôn ngữ của báo cáo. Mặc định là 'en'.
            - mode (str): Chế độ trả về dữ liệu. Mặc định là 'final' cho dữ liệu đã qua xử lý tên, nếu mode='raw' thì trả về DataFrame dữ liệu thô cho lưu trữ cơ sở dữ liệu.
            - style (str): Chế độ hiển thị tên cột. Mặc định là 'readable' cho tên hiển thị, hoặc 'code' cho tên mã dạng snake_case không dấu.
            - get_all (bool): Có lấy tất cả các cột hay không. Mặc định là False để lấy các cột quan trọng.
            - dropna (bool): Có loại bỏ các cột với tất cả giá trị 0 hay không. Mặc định là False.
            - show_log (bool): Hiển thị thông tin log hoặc không. Mặc định là False.
            
        Returns:
            pd.DataFrame: DataFrame chứa dữ liệu bảng cân đối kế toán.
        """
        df = self._get_financial_report(
            report_type='balance_sheet', period=period, lang=lang, mode=mode, style=style,
            get_all=get_all, dropna=dropna, show_log=show_log
        )

        # if year_period in df.columns then drop it
        if 'year_period' in df.columns:
            df = df.drop(columns='year_period')

        return df

    @agg_execution("VCI.ext")
    def income_statement(self, period: Optional[str] = None, lang: Optional[str] = 'en', 
                    mode: Optional[str] = 'final', 
                    style: Optional[str] = 'readable',
                    get_all: Optional[bool] = False,
                    dropna: Optional[bool] = True, 
                    show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Trích xuất dữ liệu báo cáo kết quả kinh doanh cho một công ty từ nguồn VCI.

        Tham số:
            - period (str): Kỳ báo cáo tài chính. Mặc định là None.
            - lang (str): Ngôn ngữ của báo cáo. Mặc định là 'en'.
            - mode (str): Chế độ trả về dữ liệu. Mặc định là 'final' cho dữ liệu đã qua xử lý tên, nếu mode='raw' thì trả về DataFrame dữ liệu thô cho lưu trữ cơ sở dữ liệu.
            - style (str): Chế độ hiển thị tên cột. Mặc định là 'readable' cho tên hiển thị, hoặc 'code' cho tên mã dạng snake_case không dấu.
            - get_all (bool): Có lấy tất cả các cột hay không. Mặc định là False để lấy các cột quan trọng.
            - dropna (bool): Có loại bỏ các cột với tất cả giá trị 0 hay không. Mặc định là False.
            - show_log (bool): Hiển thị thông tin log hoặc không. Mặc định là False.
            
        Returns:
            pd.DataFrame: DataFrame chứa dữ liệu báo cáo kết quả kinh doanh.
        """
        return self._get_financial_report(
            report_type='income_statement', period=period, lang=lang, mode=mode, style=style,
            get_all=get_all, dropna=dropna, show_log=show_log
        )

    @agg_execution("VCI.ext")
    def cash_flow(self, period: Optional[str] = None, lang: Optional[str] = 'en', 
                    mode: Optional[str] = 'final', 
                    style: Optional[str] = 'readable',
                    get_all: Optional[bool] = False,
                    dropna: Optional[bool] = True, 
                    show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Trích xuất dữ liệu báo cáo lưu chuyển tiền tệ của công ty từ nguồn VCI.

        Tham số:
            - period (str): Kỳ báo cáo tài chính. Mặc định là None.
            - lang (str): Ngôn ngữ của báo cáo. Mặc định là 'en'.
            - mode (str): Chế độ trả về dữ liệu. Mặc định là 'final' cho dữ liệu đã qua xử lý tên, nếu mode='raw' thì trả về DataFrame dữ liệu thô cho lưu trữ cơ sở dữ liệu.
            - style (str): Chế độ hiển thị tên cột. Mặc định là 'readable' cho tên hiển thị, hoặc 'code' cho tên mã dạng snake_case không dấu.
            - get_all (bool): Có lấy tất cả các cột hay không. Mặc định là False để lấy các cột quan trọng.
            - dropna (bool): Có loại bỏ các cột với tất cả giá trị 0 hay không. Mặc định là False.
            - show_log (bool): Hiển thị thông tin log hoặc không. Mặc định là False.
            
        Returns:
            pd.DataFrame: DataFrame chứa dữ liệu báo cáo lưu chuyển tiền tệ.
        """
        return self._get_financial_report(
            report_type='cash_flow', period=period, lang=lang, mode=mode, style=style,
            get_all=get_all, dropna=dropna, show_log=show_log
        )

    @agg_execution("VCI.ext")
    def note(self, period: Optional[str] = None, lang: Optional[str] = 'en', 
                    mode: Optional[str] = 'final', 
                    style: Optional[str] = 'readable',
                    get_all: Optional[bool] = False,
                    dropna: Optional[bool] = True, 
                    show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Trích xuất dữ liệu thuyến minh báo cáo tài chính công ty từ nguồn VCI.

        Tham số:
            - period (str): Kỳ báo cáo tài chính. Mặc định là None.
            - lang (str): Ngôn ngữ của báo cáo. Mặc định là 'en'.
            - mode (str): Chế độ trả về dữ liệu. Mặc định là 'final' cho dữ liệu đã qua xử lý tên, nếu mode='raw' thì trả về DataFrame dữ liệu thô cho lưu trữ cơ sở dữ liệu.
            - style (str): Chế độ hiển thị tên cột. Mặc định là 'readable' cho tên hiển thị, hoặc 'code' cho tên mã dạng snake_case không dấu.
            - get_all (bool): Có lấy tất cả các cột hay không. Mặc định là False để lấy các cột quan trọng.
            - dropna (bool): Có loại bỏ các cột với tất cả giá trị 0 hay không. Mặc định là False.
            - show_log (bool): Hiển thị thông tin log hoặc không. Mặc định là False.
            
        Returns:
            pd.DataFrame: DataFrame chứa dữ liệu thuyên minh báo cáo tài chính.
        """
        return self._get_financial_report(
            report_type='note', period=period, lang=lang, mode=mode, style=style,
            get_all=get_all, dropna=dropna, show_log=show_log
        )

    @agg_execution("VCI.ext")
    def ratio(self, period: Optional[str] = None, lang: Optional[str] = 'en', 
             mode: Optional[str] = 'final', style: Optional[str] = 'readable',
             get_all: Optional[bool] = False, dropna: Optional[bool] = True, show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Trích xuất dữ liệu báo cáo tỷ lệ tài chính của công ty từ nguồn VCI.

        Tham số:
            - period (str): Kỳ báo cáo tài chính. Mặc định là None.
            - lang (str): Ngôn ngữ của báo cáo. Mặc định là 'en'.
            - mode (str): Chế độ trả về dữ liệu. Mặc định là 'final' cho dữ liệu đã qua xử lý tên, nếu mode='raw' thì trả về DataFrame dữ liệu thô cho lưu trữ cơ sở dữ liệu.
            - style (str): Chế độ hiển thị tên cột. Mặc định là 'readable' cho tên hiển thị, hoặc 'code' cho tên mã dạng snake_case không dấu.
            - get_all (bool): Có lấy tất cả các cột hay không. Mặc định là False để lấy các cột quan trọng.
            - dropna (bool): Có loại bỏ các cột với tất cả giá trị 0 hay không. Mặc định là False.
            - show_log (bool): Hiển thị thông tin log hoặc không. Mặc định là False.
            
        Returns:
            pd.DataFrame: DataFrame chứa dữ liệu báo cáo tỷ lệ tài chính.
        """
        df = self._get_financial_report(report_type='ratio', period=period, lang=lang, mode=mode, style='code',
            get_all=get_all, dropna=dropna, show_log=show_log)

        # Đổi tên cột theo style và lang
        if style == 'code':
            # Đảm bảo tất cả cột đều là snake_case không dấu
            from vnstock_data.core.utils.parser import vn_to_snake_case
            df.columns = [vn_to_snake_case(str(col)) for col in df.columns]
        elif style == 'readable':
            from .const import RATIO_COLUMN_MAP_EN, RATIO_COLUMN_MAP_VI
            if lang == 'vi':
                col_map = RATIO_COLUMN_MAP_VI
            else:
                col_map = RATIO_COLUMN_MAP_EN
            # Map cột nếu có, giữ nguyên nếu không có trong dict
            df.columns = [col_map.get(str(col), str(col)) for col in df.columns]

        # if the year and quarter columns are exist, remove them
        for col in ['year', 'quarter']:
            if col in df.columns:
                df = df.drop(columns=col)
                
        return df
        
# Register provider
from vnstock_data.core.registry import ProviderRegistry  # noqa: E402, F401
ProviderRegistry.register('financial', 'vci', Finance)
