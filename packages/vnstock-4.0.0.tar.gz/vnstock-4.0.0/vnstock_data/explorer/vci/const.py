_VCIQ_URL = 'https://iq.vietcap.com.vn/api/iq-insight-service'
_VCI_EVENTS_URL = f'{_VCIQ_URL}/v1/events'
_VCI_MARKET_INDICES_URL = f'{_VCIQ_URL}/v1/market-indices'
_VCI_COMPANY_URL = f'{_VCIQ_URL}/v1/company'

_TRADING_URL = 'https://trading.vietcap.com.vn/api'
_ODD_LOT_URL = f'{_TRADING_URL}/price/symbols/oddLot/getList'
_PUT_THROUGH_URL = f'{_TRADING_URL}/price/putThrough/allIntradayPutThrough'

_REPORT_RESOLUTION = {
    '1D': 'ONE_DAY',
    '1W': 'ONE_WEEK',
    '1M': 'ONE_MONTH',
    '1Q': 'ONE_QUARTER',
    '1Y': 'ONE_YEAR',
}

# Mapping for odd_lot output columns
_ODD_LOT_MAP = {
    'symbol': 'symbol',
    'matchPrice': 'price',
    'matchVol': 'volume',
    'highest': 'highest',
    'lowest': 'lowest',
    'openPrice': 'open',
    'avgMatchPrice': 'avg_price',
    'accumulatedVolume': 'accumulated_volume',
    'accumulatedValue': 'accumulated_value',
    'session': 'session',
    'time': 'time',
    'board': 'exchange',
}

# Mapping for put_through output columns
_PUT_THROUGH_MAP = {
    'symbol': 'symbol',
    'ptMatchPrice': 'price',
    'ptMatchVolume': 'volume',
    'ptChange': 'change',
    'ptChangePercent': 'change_percent',
    'ptMatchValue': 'match_value',
    'ptAccumulatedVolume': 'accumulated_volume',
    'ptAccumulatedValue': 'accumulated_value',
    'time': 'time',
}

# Standard columns for odd_lot (common across sources)
_ODD_LOT_STANDARD_COLUMNS = [
    'symbol', 'price', 'volume', 'highest', 'lowest', 'open', 
    'avg_price', 'accumulated_volume', 'accumulated_value', 'session', 'time', 'exchange'
]

# VCI Index Symbol Mapping to map clean names from users to VCI's internal API expected names
_VCI_INDEX_MAPPING = {
    # Major Market Indices
    'VNINDEX': 'VNINDEX',
    'VNI': 'VNINDEX',
    'HNX': 'HNXIndex',
    'HNXINDEX': 'HNXIndex',
    'UPCOM': 'HNXUpcomIndex',
    'UPCOMINDEX': 'HNXUpcomIndex',
    
    # HOSE Indices
    'VN30': 'VN30',
    'VNMID': 'VNMID',
    'VNSML': 'VNSML',
    'VN100': 'VN100',
    'VNALL': 'VNALL',
    'VNSI': 'VNSI',
    
    # Sector Indices (HOSE)
    'VNIT': 'VNIT',
    'VNIND': 'VNIND',
    'VNCONS': 'VNCONS',
    'VNCOND': 'VNCOND',
    'VNHEAL': 'VNHEAL',
    'VNENE': 'VNENE',
    'VNUTI': 'VNUTI',
    'VNREAL': 'VNREAL',
    'VNFIN': 'VNFIN',
    'VNMAT': 'VNMAT',
    
    # Investment Indices (HOSE)
    'VNDIAMOND': 'VNDIAMOND',
    'VNFINLEAD': 'VNFINLEAD',
    'VNFINSELECT': 'VNFINSELECT',
    
    # VNX Indices
    'VNX50': 'VNX50',
    'VNXALL': 'VNXALL',
    
    # HNX Sub-Indices
    'HNX30': 'HNX30',
    'HNXFIN': 'HNXFin',
    'HNXFINANCIALS': 'HNXFin',
    'HNXCON': 'HNXCon',
    'HNXCONSTRUCTION': 'HNXCon',
    'HNXLCAP': 'HNXLCap',
    'HNXLARGECAP': 'HNXLCap',
    'HNXMAN': 'HNXMan',
    'HNXMANUFACTURING': 'HNXMan',
    'HNXMSCAP': 'HNXMSCap',
    'HNXMIDSMALLCAP': 'HNXMSCap',
    
    # UPCOM Sub-Indices
    'UPCOMLAR': 'UPCOMLargeIndex',
    'UPCOMMID': 'UPCOMMediumIndex',
    'UPCOMSML': 'UPCOMSmallIndex',
}

# Standard columns for put_through (common across sources)
_PUT_THROUGH_STANDARD_COLUMNS = [
    'symbol', 'time', 'exchange', 'match_price', 'match_volume', 
    'trading_date', 'reference_price', 'floor_price'
]

# Standard columns for stock board realtime (lô chẵn) - VCI specific
# Note: VCI's API returns nested structure that results in prefixed column names
# (listing_*, match_*, bid_ask_*). These are VCI's actual column names after flattening.
_STOCK_BOARD_STANDARD_COLUMNS = [
    'listing_symbol',                    # Mã CK
    'listing_exchange',                  # Sàn (HOSE/HNX/UPCOM)
    'listing_ceiling',                   # Giá trần từ danh mục niêm yết
    'listing_floor',                     # Giá sàn từ danh mục niêm yết
    'listing_ref_price',                 # Giá tham chiếu từ danh mục niêm yết
    'match_open_price',                  # Mở cửa (từ khớp lệnh thực tế)
    'match_highest',                     # Cao nhất
    'match_lowest',                      # Thấp nhất
    'match_match_price',                 # Giá khớp hiện tại
    'match_avg_match_price',             # Giá trung bình
    'match_match_vol',                   # Khối lượng giao dịch hiện tại
    'match_accumulated_volume',          # Khối lượng tích lũy
    'match_accumulated_value',           # Giá trị tích lũy
    'bid_ask_bid_1_price',               # Giá mua 1
    'bid_ask_bid_1_volume',              # KL mua 1
    'bid_ask_bid_2_price',               # Giá mua 2
    'bid_ask_bid_2_volume',              # KL mua 2
    'bid_ask_bid_3_price',               # Giá mua 3
    'bid_ask_bid_3_volume',              # KL mua 3
    'bid_ask_ask_1_price',               # Giá bán 1
    'bid_ask_ask_1_volume',              # KL bán 1
    'bid_ask_ask_2_price',               # Giá bán 2
    'bid_ask_ask_2_volume',              # KL bán 2
    'bid_ask_ask_3_price',               # Giá bán 3
    'bid_ask_ask_3_volume',              # KL bán 3
    'match_foreign_buy_volume',          # KL NN mua
    'match_foreign_sell_volume',         # KL NN bán
]

# Standard columns for price board output (stock, odd_lot, put_through)
# Unified schema for both VCI and KBS - used for transforming VCI's prefixed columns
_PRICE_BOARD_STANDARD_COLUMNS = [
    'symbol',               # Mã CK
    'time',                 # Thời điểm
    'exchange',             # Sàn
    'ceiling_price',        # Giá trần
    'floor_price',          # Giá sàn
    'reference_price',      # Giá tham chiếu
    'open_price',           # Mở cửa
    'high_price',           # Cao nhất
    'low_price',            # Thấp nhất
    'close_price',          # Đóng cửa / Giá khớp hiện tại
    'average_price',        # Giá trung bình
    'total_trades',         # Tổng KL giao dịch
    'total_value',          # Tổng GT giao dịch
    'price_change',         # Thay đổi giá
    'percent_change',       # % Thay đổi
    'bid_price_1',          # Giá mua 1 (CORE)
    'bid_vol_1',            # KL mua 1 (CORE)
    'bid_price_2',          # Giá mua 2 (CORE)
    'bid_vol_2',            # KL mua 2 (CORE)
    'bid_price_3',          # Giá mua 3 (CORE)
    'bid_vol_3',            # KL mua 3 (CORE)
    'ask_price_1',          # Giá bán 1 (CORE)
    'ask_vol_1',            # KL bán 1 (CORE)
    'ask_price_2',          # Giá bán 2 (CORE)
    'ask_vol_2',            # KL bán 2 (CORE)
    'ask_price_3',          # Giá bán 3 (CORE)
    'ask_vol_3',            # KL bán 3 (CORE)
    'foreign_buy_volume',   # KL NN mua
    'foreign_sell_volume',  # KL NN bán
]

# Standard columns for derivative board
_DERIVATIVE_STANDARD_COLUMNS = [
    'symbol',
    'underlying_symbol',
    'time',
    'exchange',
    'ceiling_price',
    'floor_price',
    'reference_price',
    'open_price',
    'high_price',
    'low_price',
    'close_price',
    'basis',
    'open_interest',
    'total_trades',
    'total_value',
    'price_change',
    'percent_change',
    'bid_price_1',
    'bid_vol_1',
    'bid_price_2',
    'bid_vol_2',
    'bid_price_3',
    'bid_vol_3',
    'ask_price_1',
    'ask_vol_1',
    'ask_price_2',
    'ask_vol_2',
    'ask_price_3',
    'ask_vol_3',
    'foreign_buy_volume',
    'foreign_sell_volume',
    'last_trading_date',
]

_VCI_TO_SCHEMA_MAP = {
    'listing_symbol': 'symbol',
    'listing_exchange': 'exchange',
    'match_highest': 'high_price',
    'match_lowest': 'low_price',
    'match_open_price': 'open_price',
    'listing_ceiling': 'ceiling_price',
    'listing_floor': 'floor_price',
    'listing_ref_price': 'reference_price',
    'match_avg_match_price': 'average_price',
    'match_accumulated_volume': 'total_trades',
    'match_accumulated_value': 'total_value',
    'bid_ask_bid_1_price': 'bid_price_1',
    'bid_ask_bid_1_volume': 'bid_vol_1',
    'bid_ask_bid_2_price': 'bid_price_2',
    'bid_ask_bid_2_volume': 'bid_vol_2',
    'bid_ask_bid_3_price': 'bid_price_3',
    'bid_ask_bid_3_volume': 'bid_vol_3',
    'bid_ask_ask_1_price': 'ask_price_1',
    'bid_ask_ask_1_volume': 'ask_vol_1',
    'bid_ask_ask_2_price': 'ask_price_2',
    'bid_ask_ask_2_volume': 'ask_vol_2',
    'bid_ask_ask_3_price': 'ask_price_3',
    'bid_ask_ask_3_volume': 'ask_vol_3',
    'match_foreign_buy_volume': 'foreign_buy_volume',
    'match_foreign_sell_volume': 'foreign_sell_volume',
    'match_open_interest': 'open_interest',
    'match_underlying': 'underlying_symbol',
    'match_match_price': 'close_price',
    'listing_last_trading_date': 'last_trading_date',
}

_PRICE_DEPTH_MAP = {
                    'priceStep':'price',
                    'accumulatedVolume': 'volume',
                    'accumulatedBuyVolume' : 'buy_volume',
                    'accumulatedSellVolume' : 'sell_volume',
                    'accumulatedUndefinedVolume': 'undefined_volume',
                    }

_IQ_FINANCE_REPORT = {'balance_sheet': 'BALANCE_SHEET',
                    'income_statement': 'INCOME_STATEMENT',
                    'cash_flow': 'CASH_FLOW',
                    'note': 'NOTE',
                    'ratio': 'RATIO'}


# Mapping for ratio output columns: Vietnamese and English
# Dùng cho chuẩn hóa tên cột đầu ra hàm ratio

RATIO_COLUMN_MAP_EN = {
    'report_period': 'report_period',
    'ratioTTMId': 'Ratio TTM Id',
    'ratioType': 'Ratio Type',
    'numberOfSharesMktCap': 'Outstanding Shares (mil)',
    'marketCap': 'Market Cap',
    'dividendYield': 'Dividend Yield (%)',
    'pe': 'P/E',
    'pb': 'P/B',
    'ps': 'P/S',
    'priceToCashFlow': 'Price/Cash Flow',
    'evToEbitda': 'EV/EBITDA',
    'cashRatio': 'Cash Ratio',
    'quickRatio': 'Quick Ratio',
    'currentRatio': 'Current Ratio',
    'ownersEquity': 'Owners Equity',
    'debtPerEquity': 'Debt/Equity',
    'debtToEquity': 'Debt to Equity',
    'roe': 'ROE (%)',
    'roa': 'ROA (%)',
    'daySaleOutstanding': 'Days Sales Outstanding',
    'daysInventoryOutstanding': 'Days Inventory Outstanding',
    'daysPayableOutstanding': 'Days Payable Outstanding',
    'grossMargin': 'Gross Margin (%)',
    'ebitMargin': 'EBIT Margin (%)',
    'preTaxProfitMargin': 'Pre-tax Profit Margin (%)',
    'afterTaxProfitMargin': 'After-tax Profit Margin (%)',
    'assetTurnover': 'Asset Turnover',
    'netInterestMargin': 'Net Interest Margin',
    'averageYieldOnEarningAssets': 'Avg Yield on Earning Assets',
    'averageCostOfFinancing': 'Avg Cost of Financing',
    'nonAndInterestIncome': 'Non-interest Income',
    'costToIncome': 'Cost/Income Ratio',
    'loansGrowth': 'Loans Growth (%)',
    'depositGrowth': 'Deposit Growth (%)',
    'equityToLiabilities': 'Equity/Total Liabilities',
    'equityToLoans': 'Equity/Loans',
    'totalEquityTotalAsset': 'Equity/Total Assets',
    'ldrLoanDepositRatio': 'LDR (%)',
    'npl': 'NPL (%)',
    'loansLossReservesToNPLs': 'Loan Loss Reserves/NPLs',
    'loansLossReserveToLoans': 'Loan Loss Reserve/Loans',
    'provisionToOutstandingLoans': 'Provision/Outstanding Loans',
    'ebit': 'EBIT',
    'ebitda': 'EBITDA',
    'roic': 'ROIC',
    'cashCycle': 'Cash Cycle',
    'fixedAssetTurnover': 'Fixed Asset Turnover',
    'financialLeverage': 'Financial Leverage',
    'cir': 'CIR',
    'car': 'CAR',
    'equity': 'Equity',
    'casaRatio': 'CASA Ratio',
    'current_deposits': 'Current Deposits',
    'margin_deposits': 'Margin Deposits',
    'deposits_for_special_purposes': 'Deposits for Special Purposes',
    'deposits_from_customers': 'Deposits from Customers',
    'ratioYearId': 'Ratio Year Id',
}

RATIO_COLUMN_MAP_VI = {
    'report_period': 'Kỳ báo cáo',
    'year': 'Năm',
    'quarter': 'Quý',
    'ratioTTMId': 'Mã TTM',
    'ratioType': 'Loại tỷ lệ',
    'numberOfSharesMktCap': 'Số CP lưu hành (triệu)',
    'marketCap': 'Vốn hóa',
    'dividendYield': 'Tỷ suất cổ tức (%)',
    'pe': 'P/E',
    'pb': 'P/B',
    'ps': 'P/S',
    'priceToCashFlow': 'Giá/ Dòng tiền',
    'evToEbitda': 'EV/EBITDA',
    'cashRatio': 'Hệ số thanh toán tiền',
    'quickRatio': 'Hệ số thanh toán nhanh',
    'currentRatio': 'Hệ số thanh toán hiện hành',
    'ownersEquity': 'Vốn chủ sở hữu',
    'debtPerEquity': 'Nợ/Vốn chủ',
    'debtToEquity': 'Nợ trên vốn chủ',
    'roe': 'ROE (%)',
    'roa': 'ROA (%)',
    'daySaleOutstanding': 'Số ngày phải thu',
    'daysInventoryOutstanding': 'Số ngày tồn kho',
    'daysPayableOutstanding': 'Số ngày phải trả',
    'grossMargin': 'Biên LN gộp (%)',
    'ebitMargin': 'Biên EBIT (%)',
    'preTaxProfitMargin': 'Biên LN trước thuế (%)',
    'afterTaxProfitMargin': 'Biên LN sau thuế (%)',
    'assetTurnover': 'Vòng quay tài sản',
    'netInterestMargin': 'Biên lãi thuần',
    'averageYieldOnEarningAssets': 'Lãi suất bình quân tài sản sinh lãi',
    'averageCostOfFinancing': 'Chi phí vốn bình quân',
    'nonAndInterestIncome': 'Thu nhập ngoài lãi',
    'costToIncome': 'Tỷ lệ CIR',
    'loansGrowth': 'Tăng trưởng cho vay (%)',
    'depositGrowth': 'Tăng trưởng tiền gửi (%)',
    'equityToLiabilities': 'Vốn chủ/Tổng nợ',
    'equityToLoans': 'Vốn chủ/Cho vay',
    'totalEquityTotalAsset': 'Vốn chủ/Tổng tài sản',
    'ldrLoanDepositRatio': 'LDR (%)',
    'npl': 'Nợ xấu (%)',
    'loansLossReservesToNPLs': 'DP rủi ro/Nợ xấu',
    'loansLossReserveToLoans': 'DP rủi ro/Cho vay',
    'provisionToOutstandingLoans': 'Trích lập DP/Cho vay',
    'ebit': 'EBIT',
    'ebitda': 'EBITDA',
    'roic': 'ROIC',
    'cashCycle': 'Chu kỳ tiền',
    'fixedAssetTurnover': 'Vòng quay TS cố định',
    'financialLeverage': 'Đòn bẩy tài chính',
    'cir': 'CIR',
    'car': 'CAR',
    'equity': 'Vốn chủ sở hữu',
    'casaRatio': 'Tỷ lệ CASA',
    'tien_gui_khong_ky_han': 'Tiền gửi không kỳ hạn',
    'tien_gui_ky_quy': 'Tiền gửi ký quỹ',
    'tien_gui_cho_nhung_muc_dich_rieng_biet': 'Tiền gửi mục đích riêng biệt',
    'tien_gui_cua_khach_hang': 'Tiền gửi khách hàng',
    'ratioYearId': 'Mã năm tỷ lệ',
}
