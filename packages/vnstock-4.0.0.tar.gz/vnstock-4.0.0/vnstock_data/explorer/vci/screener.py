"""Screener module."""

from typing import Dict, Optional, List, Any, Union
import json
import pandas as pd
from vnstock.core.utils.parser import camel_to_snake
from vnstock.core.utils.logger import get_logger
from vnstock_data.core.utils.client import send_request
from vnstock_data.core.utils.user_agent import get_headers
from vnai import agg_execution

logger = get_logger(__name__)

_SCREENER_PAGING_URL = "https://iq.vietcap.com.vn/api/iq-insight-service/v1/screening/paging"
_SCREENER_CRITERIA_URL = "https://iq.vietcap.com.vn/api/iq-insight-service/v1/screening/criteria"

_DEFAULT_SCREENER_PAYLOAD = {
    "page": 0,
    "pageSize": 50,
    "sortFields": [],
    "sortOrders": [],
    "filter": [
        {
            "name": "sectorLv1",
            "conditionOptions": [
                {"type": "value", "value": "1000"},
                {"type": "value", "value": "3000"},
                {"type": "value", "value": "2000"},
                {"type": "value", "value": "0001"},
                {"type": "value", "value": "6000"},
                {"type": "value", "value": "4000"},
                {"type": "value", "value": "7000"},
                {"type": "value", "value": "5000"},
                {"type": "value", "value": "8600"},
                {"type": "value", "value": "8301"},
                {"type": "value", "value": "9000"},
                {"type": "value", "value": "8500"},
                {"type": "value", "value": "8700"}
            ]
        },
        {
            "name": "exchange",
            "conditionOptions": [
                {"type": "value", "value": "hsx"},
                {"type": "value", "value": "hnx"},
                {"type": "value", "value": "upcom"}
            ]
        },
        {
            "name": "marketCap",
            "conditionOptions": [{"from": 0, "to": 2000000000000000}]
        },
        {
            "name": "marketPrice",
            "conditionOptions": [{"from": 0, "to": 2000000}]
        },
        {
            "name": "dailyPriceChangePercent",
            "conditionOptions": [{"from": -15, "to": 15}]
        },
        {
            "name": "adtv",
            "extraName": "30Days",
            "conditionOptions": [{"from": 0, "to": 2000000000000}]
        },
        {
            "name": "avgVolume",
            "extraName": "30Days",
            "conditionOptions": [{"from": 0, "to": 200000000}]
        },
        {
            "name": "esVolumeVsAvgVolume",
            "extraName": "30Days",
            "conditionOptions": [{"from": -900, "to": 900}]
        },
        {
            "name": "stockStrength",
            "conditionOptions": [{"from": 0, "to": 100}]
        },
        {
            "name": "rs",
            "extraName": "3Month",
            "conditionOptions": [{"from": 0, "to": 100}]
        },
        {
            "name": "rsi",
            "conditionOptions": [{"from": 0, "to": 100}]
        },
        {
            "name": "priceEma",
            "extraName": "ema20",
            "conditionOptions": [{"from": -50, "to": 50}]
        },
        {
            "name": "ema20Ema50",
            "conditionOptions": [{"from": -50, "to": 50}]
        },
        {
            "name": "ema50Ema200",
            "conditionOptions": [{"from": -50, "to": 50}]
        },
        {
            "name": "priceReturn",
            "extraName": "3Month",
            "conditionOptions": [{"from": -100, "to": 100}]
        },
        {
            "name": "outperformsIndex",
            "extraName": "3Month",
            "conditionOptions": [{"from": -100, "to": 100}]
        },
        {
            "name": "priceFluctuation",
            "extraName": "30Days",
            "conditionOptions": [{"from": -100, "to": 100}]
        },
        {
            "name": "macd",
            "conditionOptions": [{"from": -200000, "to": 200000}]
        },
        {
            "name": "histogram",
            "conditionOptions": [{"from": -5000, "to": 5000}]
        },
        {
            "name": "adx",
            "conditionOptions": [{"from": 0, "to": 100}]
        },
        {
            "name": "stockTrend",
            "conditionOptions": [{"type": "value", "value": "STRONG_UPTREND"}]
        },
        {
            "name": "aoTrend",
            "conditionOptions": [{"type": "value", "value": "ABOVE_ZERO"}]
        },
        {
            "name": "ttmPe",
            "conditionOptions": [{"from": 0, "to": 100}]
        },
        {
            "name": "ttmPb",
            "conditionOptions": [{"from": 0, "to": 100}]
        },
        {
            "name": "ttmRoe",
            "conditionOptions": [{"from": -50, "to": 50}]
        },
        {
            "name": "npatmiGrowth",
            "extraName": "Yoy",
            "extraName2": "Qm1",
            "conditionOptions": [{"from": -100, "to": 500}]
        },
        {
            "name": "revenueGrowth",
            "extraName": "Yoy",
            "conditionOptions": [{"from": -100, "to": 500}]
        },
        {
            "name": "netMargin",
            "conditionOptions": [{"from": -100, "to": 100}]
        },
        {
            "name": "grossMargin",
            "conditionOptions": [{"from": -100, "to": 100}]
        }
    ]
}

class Screener:
    """
    Screener API cho VCI. Truy cập bộ lọc cổ phiếu với tất cả các tiêu chí.
    """
    def __init__(self, random_agent:Optional[bool]=False, show_log:Optional[bool]=False):
        self.data_source = 'VCI'
        self.headers = get_headers(data_source=self.data_source, random_agent=random_agent)
        # Bổ sung các header cần thiết cho API Insight Service
        self.headers.update({
            'Accept': 'application/json',
            'Accept-Language': 'en-US,en;q=0.9,vi;q=0.8',
            'Origin': 'https://trading.vietcap.com.vn',
            'Referer': 'https://trading.vietcap.com.vn/',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-site',
            'Content-Type': 'application/json'
        })
        self.show_log = show_log
        if not show_log:
            logger.setLevel('CRITICAL')

    @agg_execution("VCI.ext")
    def get_criteria(self, lang: str = 'vi', show_log: Optional[bool] = False, to_df: Optional[bool] = True) -> Union[pd.DataFrame, Dict]:
        """
        Lấy cấu trúc mapping tên tiêu chí và định nghĩa readable của các fields từ VCI Screener.
        """
        json_data = send_request(
            url=_SCREENER_CRITERIA_URL,
            headers=self.headers,
            method="GET",
            show_log=show_log
        )
        if not json_data or 'data' not in json_data:
            raise ValueError("Không thể lấy dữ liệu criteria.")
            
        data = json_data['data']
        if not to_df:
            return data
            
        # Parse into a mapping structure
        rows = []
        for item in data:
            if not isinstance(item, dict):
                continue
            name = item.get('name')
            category = item.get('category')
            options = item.get('conditionOptions', [])
            
            # Nếu có ExtraName thì tên field lúc fetch sẽ ghép lại, ta chỉ mapping cơ bản
            snake_name = camel_to_snake(name) if name else None
            
            if lang == 'vi':
                readable_name = item.get('viName', name)
            else:
                readable_name = item.get('enName', name)
                
            rows.append({
                'category': category,
                'field_name': name,
                'column_name': snake_name,
                'readable_name': readable_name,
                'select_type': item.get('selectType')
            })
            
        df = pd.DataFrame(rows)
        df.attrs['source'] = 'VCI'
        return df

    @agg_execution("VCI.ext")
    def filter(self, show_log: Optional[bool] = False, to_df: Optional[bool] = True, limit: int = 2000) -> Union[pd.DataFrame, List[Dict]]:
        """
        Lấy dữ liệu của tất cả cổ phiếu thỏa mãn cấu hình bộ lọc mặc định rộng nhất.
        User sẽ dùng pandas dataframe để tự phân tích và filter thêm.
        
        Args:
            show_log (bool, optional): Hiển thị log. Defaults to False.
            to_df (bool, optional): Trả về DataFrame. Defaults to True.
            limit (int, optional): Giới hạn số lượng bản ghi trả về. Defaults to 2000 (do thị trường VN có hơn 1600 mã).
        """
        results = []
        page = 0
        page_size = 50
        payload = _DEFAULT_SCREENER_PAYLOAD.copy()
        
        while True:
            payload['page'] = page
            payload['pageSize'] = page_size
            
            json_data = send_request(
                url=_SCREENER_PAGING_URL,
                headers=self.headers,
                method="POST",
                payload=payload,
                show_log=show_log
            )
            
            if not json_data or 'data' not in json_data or 'content' not in json_data['data']:
                break
                
            content = json_data['data']['content']
            if not content:
                break
                
            results.extend(content)
            
            if len(results) >= limit or len(content) < page_size:
                break
                
            page += 1
            
        if not to_df:
            return results[:limit]
            
        if not results:
            return pd.DataFrame()
            
        df = pd.DataFrame(results[:limit])
        df.columns = [camel_to_snake(col) for col in df.columns]
        df.attrs['source'] = 'VCI'
        
        # Cleanup duplicated or internal ID fields if they exist
        if 'id' in df.columns:
            df = df.drop(columns=['id'])
            
        return df

# Register provider
from vnstock_data.core.registry import ProviderRegistry  # noqa: E402
ProviderRegistry.register('screener', 'vci', Screener)
