"""History module for MAS."""

from typing import Dict, Optional, Union, List
from typing import Dict, Optional, Union, List
from datetime import datetime, timedelta
import pandas as pd
from vnstock.core.utils.lookback import get_start_date_from_lookback
from vnai import agg_execution
from vnstock_data.explorer.mas.const import (_CHART_URL, _OHLC_MAP, _INTERVAL_MAP, _OHLC_DTYPE, _RESAMPLE_MAP, _INDEX_MAPPING, _INTRADAY_MAP, _INTRADAY_DTYPE, _PRICE_DEPTH_MAP
)
from vnstock.core.models import TickerModel
from vnstock.core.utils.logger import get_logger
from vnstock.core.utils.market import trading_hours
from vnstock.core.utils.parser import get_asset_type
from vnstock.core.utils.interval import normalize_interval
from vnstock_data.core.utils.client import send_request, ProxyConfig
from vnstock_data.core.utils.user_agent import get_headers
from vnstock_data.core.utils.transform import ohlc_to_df, intraday_to_df
from vnstock_data.core.types import SubscriptionTier, DataQuality, UpdateFrequency

logger = get_logger(__name__)

class Quote:
    """
    Cấu hình truy cập dữ liệu lịch sử giá chứng khoán từ MAS.
    
    Hỗ trợ các tính năng proxy nâng cao:
    - auto_fetch: Tự động lấy proxy từ proxyscrape API
    - validate_proxies: Kiểm tra tính hợp lệ của proxy
    - prefer_speed: Ưu tiên proxy có tốc độ tốt nhất
    """
    def __init__(
        self, 
        symbol, 
        random_agent=False, 
        proxy_config: Optional[ProxyConfig]=None, 
        show_log=True,
        proxy_mode: Optional[str] = None,
        proxy_list: Optional[List[str]] = None
    ):
        self.symbol = symbol.upper()
        self.data_source = 'MAS'
        self._history = None  # Cache for historical data
        self.asset_type = get_asset_type(self.symbol)
        self.base_url = _CHART_URL
        self.headers = get_headers(data_source=self.data_source, random_agent=random_agent)
        self.interval_map = _INTERVAL_MAP
        self.show_log = show_log
        
        # Handle proxy configuration
        if proxy_config is None:
            # Create ProxyConfig from individual arguments
            p_mode = proxy_mode if proxy_mode else 'try'
            # If user provides list, set request_mode to PROXY
            req_mode = 'direct'
            if proxy_list and len(proxy_list) > 0:
                req_mode = 'proxy'
                
            self.proxy_config = ProxyConfig(
                proxy_mode=p_mode,
                proxy_list=proxy_list,
                request_mode=req_mode
            )
        else:
            self.proxy_config = proxy_config

        if not show_log:
            logger.setLevel('CRITICAL')

        if 'INDEX' in self.symbol:
            self.symbol = self._index_validation()

    def _index_validation(self) -> str:
        """
        If symbol contains 'INDEX' substring, validate it with _INDEX_MAPPING.
        """
        if self.symbol not in _INDEX_MAPPING.keys():
            raise ValueError("Không tìm thấy mã chứng khoán " + self.symbol + ". Các giá trị hợp lệ: " + ', '.join(_INDEX_MAPPING.keys()))
        return _INDEX_MAPPING[self.symbol]

    def _input_validation(self, start: str, end: str, interval: str):
        """
        Validate input data
        """
        # Normalize interval using vnstock's core utility
        try:
            normalized_tf = normalize_interval(interval)
            normalized_interval = normalized_tf.value
        except ValueError:
            raise ValueError(f"Giá trị interval không hợp lệ: {interval}. Vui lòng chọn: 1m, 5m, 15m, 30m, 1H, 4h, 1D, 1W, 1M")
        
        ticker = TickerModel(symbol=self.symbol, start=start, end=end, interval=normalized_interval)

        if ticker.interval not in self.interval_map:
            raise ValueError(f"Giá trị interval không hỗ trợ bởi MAS: {ticker.interval}. Các interval được hỗ trợ: 1m, 5m, 15m, 30m, 1H, 1D, 1W, 1M")

        return ticker

    @agg_execution("MAS.ext")
    def history(self, start: Optional[str]=None, end: Optional[str]=None, interval: Optional[str]="1D", 
                to_df: Optional[bool]=True, show_log: Optional[bool]=False, 
                count_back: Optional[int]=None, floating: Optional[int]=2,
                length: Optional[Union[str, int]] = None) -> Union[pd.DataFrame, str]:
        """
        Tải lịch sử giá của mã chứng khoán từ nguồn dữ liệu MAS.

        Tham số:
            - start (tùy chọn): thời gian bắt đầu lấy dữ liệu (YYYY-MM-DD). Bắt buộc nếu không có length hoặc count_back.
            - end (tùy chọn): thời gian kết thúc lấy dữ liệu. Mặc định là None, chương trình tự động lấy thời điểm hiện tại.
            - interval (tùy chọn): Khung thời gian trích xuất dữ liệu. Mặc định là "1D".
            - to_df (tùy chọn): Chuyển đổi dữ liệu lịch sử trả về dưới dạng DataFrame. Mặc định là True.
            - show_log (tùy chọn): Hiển thị thông tin log. Mặc định là False.
            - count_back (tùy chọn): Số lượng dữ liệu trả về từ thời điểm cuối.
            - floating (tùy chọn): Số chữ số thập phân cho giá. Mặc định là 2.
            - length (tùy chọn): Khoảng thời gian phân tích (vd: '3M', 150, '100b').
        """
        # Set end date to today if not provided
        if end is None:
            end = datetime.now().strftime("%Y-%m-%d")

        # Calculate start if not provided
        if start is None:
            # Check if length defines bars
            if length is not None:
                length_str = str(length)
                if length_str.endswith('b'):
                    # Length defines number of bars
                    count_back = int(length_str[:-1])
                    # Approximate start for initial validation (refined by count_back later)
                    start = get_start_date_from_lookback(lookback_length=length_str, end_date=end)
                else:
                    # Length defines time period
                    start = get_start_date_from_lookback(lookback_length=length_str, end_date=end)
            elif count_back is not None:
                # Estimate start based on count_back and interval
                if interval == '1D':
                    start = (datetime.strptime(end, "%Y-%m-%d") - timedelta(days=count_back * 2)).strftime("%Y-%m-%d")
                elif interval == '1H':
                    start = (datetime.strptime(end, "%Y-%m-%d") - timedelta(days=count_back // 6)).strftime("%Y-%m-%d")
                elif interval == '1m':
                    start = (datetime.strptime(end, "%Y-%m-%d") - timedelta(days=1)).strftime("%Y-%m-%d")
                else:
                    start = get_start_date_from_lookback(lookback_length='1M', end_date=end)
            else:
                raise ValueError("Tham số 'start' là bắt buộc nếu không cung cấp 'length' hoặc 'count_back'.")
        # Validate inputs
        ticker = self._input_validation(start, end, interval)

        start_time = datetime.strptime(ticker.start, "%Y-%m-%d")
        
        # Calculate end timestamp
        if end is not None:
            end_time = datetime.strptime(ticker.end, "%Y-%m-%d") + pd.Timedelta(days=1)
            if start_time > end_time:
                raise ValueError("Thời gian bắt đầu không thể lớn hơn thời gian kết thúc.")
            end_stamp = int(end_time.timestamp())
        else:
            end_stamp = int((datetime.now() + pd.Timedelta(days=1)).timestamp())

        start_stamp = int(start_time.timestamp())
        interval_value = self.interval_map[ticker.interval]

        # Prepare request
        url = self.base_url + 'tradingview/history'
        params = {
            "symbol": [self.symbol],
            "resolution": interval_value,
            "from": start_stamp,
            "to": end_stamp
        }

        # Use the send_request utility from api_client
        json_data = send_request(
            url=url, 
            headers=self.headers, 
            method="GET", 
            params=params,
            payload=None, 
            show_log=show_log
        )

        if not json_data:
            raise ValueError("Không tìm thấy dữ liệu. Vui lòng kiểm tra lại mã chứng khoán hoặc thời gian truy xuất.")

        # Use the ohlc_to_df utility from data_transform
        df = ohlc_to_df(
            data=json_data, 
            column_map=_OHLC_MAP, 
            dtype_map=_OHLC_DTYPE, 
            asset_type=self.asset_type, 
            symbol=self.symbol, 
            source=self.data_source, 
            interval=ticker.interval, 
            floating=floating,
            resample_map=_RESAMPLE_MAP
        )

        if count_back is not None:
            df = df.tail(count_back)

        if to_df:
            return df
        else:
            return df.to_json(orient='records')

    @agg_execution("MAS.ext")
    def intraday(self, page_size: Optional[int]=100, last_time: Optional[str]=None, 
                to_df: Optional[bool]=True, get_all:bool=False, show_log: bool=False) -> Union[pd.DataFrame, str]:
        """
        Truy xuất dữ liệu khớp lệnh của mã chứng khoán bất kỳ từ nguồn dữ liệu MAS

        Tham số:
            - page_size (tùy chọn): Số lượng dữ liệu trả về trong một lần request. Mặc định là 100. 
            - last_time (tùy chọn): Thời gian cắt dữ liệu, dùng để lấy dữ liệu sau thời gian cắt. Mặc định là None.
            - to_df (tùy chọn): Chuyển đổi dữ liệu lịch sử trả về dưới dạng DataFrame. Mặc định là True.
            - get_all (tùy chọn): Lấy tất cả các cột trả về từ API thay vì chỉ các cột chuẩn hoá. Mặc định là False.
            - show_log (tùy chọn): Hiển thị thông tin log giúp debug dễ dàng. Mặc định là False.
        """
        # Validator: Intraday data is not supported for indices
        if self.asset_type == 'index':
            raise ValueError(f"Dữ liệu intraday không được hỗ trợ cho chỉ số {self.symbol}.")

        market_status = trading_hours(None)
        if market_status['is_trading_hour'] is False and market_status['data_status'] == 'preparing':
            raise ValueError(str(market_status['time']) + ": Dữ liệu khớp lệnh không thể truy cập trong thời gian chuẩn bị phiên mới. Vui lòng quay lại sau.")

        if self.symbol is None:
            raise ValueError("Vui lòng nhập mã chứng khoán cần truy xuất khi khởi tạo Trading Class.")

        if page_size > 30_000:
            logger.warning("Bạn đang yêu cầu truy xuất quá nhiều dữ liệu, điều này có thể gây lỗi quá tải.")

        url = self.base_url + f'market/{self.symbol}/quote'
        params = {
            "symbol": self.symbol,
            "fetchCount": page_size,
        }

        # Fetch data using the send_request utility
        data = send_request(
            url=url, 
            headers=self.headers, 
            method="GET", 
            params=params,
            payload=None, 
            show_log=show_log
        )

        # Transform data using intraday_to_df utility
        df = intraday_to_df(
            data=data['data'], 
            column_map=_INTRADAY_MAP, 
            dtype_map=_INTRADAY_DTYPE, 
            symbol=self.symbol, 
            asset_type=self.asset_type, 
            source=self.data_source
        )

        if get_all:
            return df
        else:
            selected_cols = ['time', 'price', 'volume', 'match_type']
            df = df[selected_cols]

        if to_df:
            return df
        else:
            return df.to_json(orient='records')

    @agg_execution("MAS.ext")
    def price_depth(self, get_all:bool=False, to_df: Optional[bool]=True, show_log: Optional[bool]=False) -> Union[pd.DataFrame, str]:
        """
        Truy xuất thống kê độ bước giá & khối lượng khớp lệnh của mã chứng khoán bất kỳ từ nguồn dữ liệu MAS.

        Tham số:
            - get_all (tùy chọn): Lấy tất cả các cột trả về từ API thay vì chỉ các cột chuẩn hoá. Mặc định là False.
            - to_df (tùy chọn): Chuyển đổi dữ liệu lịch sử trả về dưới dạng DataFrame. Mặc định là True.
            - show_log (tùy chọn): Hiển thị thông tin log giúp debug dễ dàng. Mặc định là False.
        """
        market_status = trading_hours(None)
        if market_status['is_trading_hour'] is False and market_status['data_status'] == 'preparing':
            raise ValueError(str(market_status['time']) + ": Dữ liệu khớp lệnh không thể truy cập trong thời gian chuẩn bị phiên mới. Vui lòng quay lại sau.")

        if self.symbol is None:
            raise ValueError("Vui lòng nhập mã chứng khoán cần truy xuất khi khởi tạo Trading Class.")

        url = self.base_url + 'market/quoteSummary'
        params = {
            "symbol": self.symbol
        }

        # Fetch data using the send_request utility
        data = send_request(
            url=url, 
            headers=self.headers, 
            method="GET", 
            params=params,
            payload=None, 
            show_log=show_log
        )

        # Process the data to DataFrame
        df = pd.DataFrame(data)
        
        # Select columns in _PRICE_DEPTH_MAP values and rename them
        df = df[_PRICE_DEPTH_MAP.keys()]
        df.rename(columns=_PRICE_DEPTH_MAP, inplace=True)

        if get_all == False:
            selected_cols = ['price', 'volume', 'buy_volume', 'sell_volume', 'undefined_volume']
            df = df[selected_cols]
        
        df.source = self.data_source

        if to_df:
            return df
        else:
            return df.to_json(orient='records')

# Register provider
from vnstock_data.core.registry import ProviderRegistry  # noqa: E402, F401
ProviderRegistry.register('quote', 'mas', Quote)
