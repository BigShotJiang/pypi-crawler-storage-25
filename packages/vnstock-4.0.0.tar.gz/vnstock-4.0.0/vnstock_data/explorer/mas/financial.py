"""
Module quản lý thông tin báo cáo tài chính từ nguồn dữ liệu MAS.
"""

import json
import pandas as pd
from typing import Optional
from vnstock_data.explorer.mas.const import (
    _FINANCIAL_URL, 
    _FINANCIAL_REPORT_MAP, 
    _FINANCIAL_REPORT_PERIOD_MAP, 
    SUPPORTED_LANGUAGES
)
from vnstock_data.core.utils.user_agent import get_headers
from vnstock_data.core.utils.parser import get_asset_type
from vnstock.core.utils.transform import replace_in_column_names, flatten_hierarchical_index, reorder_cols
from vnai import agg_execution
from vnstock.core.utils.logger import get_logger
from vnstock.core.utils.client import send_request
from vnstock.core.utils.parser import camel_to_snake

logger = get_logger(__name__)

class Finance:
    """
    Truy xuất thông tin báo cáo tài chính của một công ty theo mã chứng khoán từ nguồn dữ liệu MAS.

    Tham số:
        - symbol (str): Mã chứng khoán của công ty cần truy xuất thông tin.
        - period (str): Chu kỳ báo cáo tài chính cần truy xuất. Mặc định là 'quarter'.
        - get_all (bool): Trả về tất cả các trường dữ liệu hoặc chỉ các trường chọn lọc. Mặc định là True.
        - show_log (bool): Hiển thị thông tin log hoặc không. Mặc định là True.
    """

    def __init__(self, symbol: str, period: Optional[str] = 'quarter', 
                 get_all: Optional[bool] = True, show_log: Optional[bool] = True):
        """
        Khởi tạo đối tượng Finance với các tham số cho việc truy xuất dữ liệu báo cáo tài chính.
        """
        self.symbol = symbol.upper()
        self.asset_type = get_asset_type(self.symbol)
        self.base_url = _FINANCIAL_URL
        # The basic GraphQL query template. Report type and period will be replaced later.
        self.query_params = (
            """query{vsFinancialReportList(StockCode:"TARGET_SYMBOL",Type:"TARGET_TYPE",TermType:"TARGET_PERIOD"){_id,ID,TermCode,YearPeriod,Content{Values{Name,NameEn,Value}}}}"""
        )
        self.headers = get_headers(data_source='MAS')
        self.show_log = show_log
        if not show_log:
            logger.setLevel('CRITICAL')

        # Validate input for period.
        if period not in ['year', 'quarter']:
            raise ValueError("Kỳ báo cáo tài chính không hợp lệ. Chỉ chấp nhận 'year' hoặc 'quarter'.")
        # Save the raw period for internal use.
        self.raw_period = period  
        # The mapped period value is used in the API query.
        self.period = _FINANCIAL_REPORT_PERIOD_MAP.get(period)

        # Only stock asset type is allowed.
        if self.asset_type not in ['stock']:
            raise ValueError("Mã chứng khoán không hợp lệ. Chỉ cổ phiếu mới có thông tin.")
            
        self.get_all = get_all

    def _flatten_content(self, content, lang: str) -> dict:
        """
        Flatten a nested content structure based on the language.

        Args:
            content: A nested data structure (typically a list with a dict containing key 'Values').
            lang (str): 'en' or 'vi'; uses 'NameEn' for 'en' and 'Name' for 'vi'.

        Returns:
            dict: Mapping of selected (trimmed) names to their values.
        """
        if isinstance(content, list):
            for item in content:
                if isinstance(item, dict) and 'Values' in item:
                    flattened = {}
                    for sub_item in item['Values']:
                        if isinstance(sub_item, dict):
                            key = (sub_item.get('NameEn', '').strip() 
                                   if lang.lower() == 'en' 
                                   else sub_item.get('Name', '').strip())
                            if key:
                                flattened[key] = sub_item.get('Value')
                    return flattened
        return {}

    def _parse_nested_data(self, df: pd.DataFrame, lang: str) -> pd.DataFrame:
        """
        Apply _flatten_content to the 'content' column, convert to DataFrame, and
        concatenate with the original DataFrame (dropping 'content').

        Args:
            df (pd.DataFrame): DataFrame with a 'content' column.
            lang (str): 'en' or 'vi'.

        Returns:
            pd.DataFrame: Merged DataFrame.
        """
        flattened_series = df['content'].apply(lambda content: self._flatten_content(content, lang))
        flattened_df = pd.DataFrame(flattened_series.tolist())
        result_df = pd.concat([df.drop('content', axis=1, errors='ignore'), flattened_df], axis=1)
        return result_df

    def _clean_columns(self, df: pd.DataFrame, period_type: str) -> pd.DataFrame:
        """
        Clean and reformat DataFrame columns by creating a 'period' column based on period_type
        and dropping unneeded columns.

        For "year":
          - Use 'year_period' as 'period'.
          - Drop _id, id, term_code.
        For "quarter":
          - Create period as "year_period-term_code".
          - Drop 'year_period', _id, id, and term_code.

        Args:
            df (pd.DataFrame): DataFrame that may contain '_id', 'id', 'term_code', 'year_period'.
            period_type (str): "year" or "quarter".

        Returns:
            pd.DataFrame: Cleaned DataFrame.
        """
        period_type = period_type.lower()
        if period_type == 'year':
            df['period'] = df['year_period'] if 'year_period' in df.columns else None
        elif period_type == 'quarter':
            if 'year_period' in df.columns and 'term_code' in df.columns:
                df['period'] = df['year_period'].astype(str) + '-' + df['term_code'].astype(str)
            else:
                df['period'] = None
            if 'year_period' in df.columns:
                df = df.drop('year_period', axis=1, errors='ignore')
        else:
            raise ValueError("period_type must be either 'year' or 'quarter'")
        
        # Drop unneeded columns if they exist.
        cols_to_drop = ['_id', 'id', 'term_code']
        existing_cols = [col for col in cols_to_drop if col in df.columns]
        return df.drop(columns=existing_cols, errors='ignore')

    def _get_report(self, report_type: str, period: Optional[str], 
                    lang: Optional[str], dropna: bool, show_log: bool) -> pd.DataFrame:
        """
        A general method to query and process a financial report.

        Args:
            report_type (str): Report type such as 'balance_sheet', 'income_statement',
                               'cash_flow', 'ratio', or 'annual_plan'.
            period (str): Either 'year' or 'quarter'. If None, defaults to the instance period.
            lang (str): 'en' or 'vi'.
            dropna (bool): Whether to drop columns with all NaN values.
            show_log (bool): Whether to show log details during the request.

        Returns:
            pd.DataFrame: Processed DataFrame with report data.
        """
        # Validate language.
        if lang not in SUPPORTED_LANGUAGES:
            raise ValueError("Ngôn ngữ không hợp lệ: '" + lang + "'. Hỗ trợ: " + ', '.join(SUPPORTED_LANGUAGES) + ".")
        
        # Determine the period values.
        if period is None:
            raw_period = self.raw_period
            mapped_period = self.period
        elif period not in ['year', 'quarter']:
            raise ValueError("Kỳ báo cáo tài chính không hợp lệ. Chỉ chấp nhận 'year' hoặc 'quarter'.")
        else:
            raw_period = period
            mapped_period = _FINANCIAL_REPORT_PERIOD_MAP.get(period)

        # Build the query.
        url = self.base_url + 'financialReport'
        query = (
            self.query_params
                .replace("TARGET_SYMBOL", self.symbol)
                .replace("TARGET_TYPE", _FINANCIAL_REPORT_MAP[report_type])
                .replace("TARGET_PERIOD", mapped_period)
        )
        params = {'query': query}

        # Send the request.
        data = send_request(
            url=url, 
            headers=self.headers, 
            method="GET", 
            params=params,
            payload=None, 
            show_log=show_log
        )
        df = pd.DataFrame(data)
        # Convert column names to snake_case.
        df.columns = [camel_to_snake(col) for col in df.columns]

        if df.empty:
            logger.warning("No data found for symbol " + str(self.symbol) + " in period " + str(mapped_period) + ".")
            return pd.DataFrame()

        # Parse and flatten nested content.
        df = self._parse_nested_data(df, lang)
        # Clean columns based on period type.
        df = self._clean_columns(df, period_type=raw_period)
        # Reorder columns to have period first
        df = reorder_cols(df, ['period'], position='first')
        if dropna:
            df = df.dropna(axis=1, how='all')
        return df

    @agg_execution("MAS.ext")
    def balance_sheet(self, period: Optional[str] = None, lang: Optional[str] = 'vi', 
                      dropna: Optional[bool] = True, show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Trích xuất dữ liệu bảng cân đối kế toán từ nguồn MAS.
        """
        return self._get_report('balance_sheet', period, lang, dropna, show_log)

    @agg_execution("MAS.ext")
    def income_statement(self, period: Optional[str] = None, lang: Optional[str] = 'vi', 
                         dropna: Optional[bool] = True, show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Trích xuất dữ liệu báo cáo kết quả kinh doanh từ nguồn MAS.
        """
        return self._get_report('income_statement', period, lang, dropna, show_log)

    @agg_execution("MAS.ext")
    def cash_flow(self, period: Optional[str] = None, lang: Optional[str] = 'vi', 
                  dropna: Optional[bool] = True, show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Trích xuất dữ liệu báo cáo lưu chuyển tiền tệ từ nguồn MAS.
        """
        return self._get_report('cash_flow', period, lang, dropna, show_log)

    @agg_execution("MAS.ext")
    def ratio (self, period: Optional[str] = None, lang: Optional[str] = 'vi', 
              dropna: Optional[bool] = True, show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Trích xuất dữ liệu báo cáo tỉ lệ tài chính từ nguồn MAS.
        """
        return self._get_report('ratio', period, lang, dropna, show_log)

    @agg_execution("MAS.ext")
    def annual_plan (self, period: Optional[str] = 'year', lang: Optional[str] = 'vi', 
                dropna: Optional[bool] = True, show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Trích xuất dữ liệu báo cáo dự kiến từ nguồn MAS.
        """
        # validate the period, only year is accepted
        if period not in ['year']:
            raise ValueError("Báo cáo chỉ tiêu kế hoạch chỉ chấp nhận giá trị year.")
        df = self._get_report('annual_plan', period, lang, dropna, show_log)
        # if year_period is in columns, drop it
        if 'year_period' in df.columns:
            df = df.drop('year_period', axis=1, errors='ignore')
        return df

# Register provider
from vnstock_data.core.registry import ProviderRegistry  # noqa: E402, F401
ProviderRegistry.register('financial', 'mas', Finance)
