_CHART_URL = 'https://masboard.masvn.com/api/v1/'
_FINANCIAL_URL = 'https://masboard.masvn.com/api/v2/vs/'

_INDEX_MAPPING = {'VNINDEX': 'VN-INDEX', 'HNXINDEX': 'HNXIndex', 'UPCOMINDEX': 'HNXUpcomIndex'}

# Mapping for OHLC data
_INTERVAL_MAP = {'1m' : '1',
            '1D' : '1D',
            '5m' : '5', # only 1 and 1D are strictly required
            '15m' : '15',
            '30m' : '30',
            '1H' : '60',
            '1W' : '1W',
            '1M' : '1M'
            }


_OHLC_MAP = {
    't': 'time',
    'o': 'open',
    'h': 'high',
    'l': 'low',
    'c': 'close',
    'v': 'volume',
}

_OHLC_DTYPE = {
    "time": "datetime64[ns]", 
    "open": "float64",
    "high": "float64",
    "low": "float64",
    "close": "float64",
    "volume": "int64",
}

_RESAMPLE_MAP = {
            '5m' : '5min',
            '15m' : '15min',
            '30m' : '30min',
            '1H' : '1H',
            '1W' : '1W',
            '1M' : 'M'
            }

_INTRADAY_MAP = {
                'ti':'time',
                'c':'price',
                'mv':'volume',
                'va': 'value',
                'mb':'match_type',
                # Additional fields
                'h':'high',
                'l':'low',
                'ch':'change',
                'r': 'change_pct',
                'vo':'agg_volume',
                }

_INTRADAY_DTYPE = {
                    "time": "datetime64[ns]",
                    "price": "float64",
                    "volume": "int64",
                    "value": "float64",
                    "match_type": "str",
                    "high": "float64",
                    "low": "float64",
                    "change": "float64",
                    "change_pct": "float64",
                    "volume": "int64",
                }


_PRICE_DEPTH_MAP = {
                    'price':'price',
                    'volume': 'volume',
                    'buyVolume' : 'buy_volume',
                    'sellVolume' : 'sell_volume',
                    'bsVolume': 'undefined_volume',
                    'buyRate':'buy_rate',
                    'sellRate':'sell_rate',
                    'bsRate':'undefined_rate',
                    'rate': 'rate',
                    }


_FINANCIAL_REPORT_PERIOD_MAP = {'year': 'Y', 'quarter': 'Q'}

_FINANCIAL_REPORT_MAP = {'balance_sheet': 'CDKT',
                            'income_statement': 'KQKD',
                            'cash_flow': 'LCTT',
                            'ratio': 'CSTC',
                            'annual_plan': 'CTKH'}

SUPPORTED_LANGUAGES = ['en', 'vi']