"""Market module for MAS."""

from typing import Optional, Union
import pandas as pd
from vnai import agg_execution
from vnstock.core.utils.logger import get_logger
from vnstock.core.utils.parser import camel_to_snake
from vnstock_data.core.utils.client import send_request
from vnstock_data.core.utils.user_agent import get_headers

logger = get_logger(__name__)

class Market:
    """
    Truy xuất thông tin trạng thái thị trường chung từ MAS.
    """
    def __init__(self, random_agent=False, show_log=True):
        self.data_source = 'MAS'
        self.base_url = 'https://masboard.masvn.com/api/v1/market/'
        
        self.headers = get_headers(data_source=self.data_source, random_agent=random_agent)
        
        if not show_log:
            logger.setLevel('CRITICAL')

    @agg_execution("MAS.ext")
    def status(self, to_df: Optional[bool]=True, show_log: Optional[bool]=False) -> Union[pd.DataFrame, str]:
        """
        Lấy trạng thái thực tế của thị trường (ví dụ: OPEN, CLOSED, ATO, ATC)
        Đầu ra là danh sách trạng thái các sàn HOSE, HNX, UPCOM.
        
        Tham số:
            - to_df (tùy chọn): Chuyển đổi dữ liệu trả về dưới dạng DataFrame. Mặc định là True.
            - show_log (tùy chọn): Hiển thị thông tin log giúp debug dễ dàng. Mặc định là False.
        """
        url = self.base_url + 'marketStatus'
        
        json_data = send_request(
            url=url, 
            headers=self.headers, 
            method="GET", 
            payload=None, 
            show_log=show_log
        )
        
        if not json_data:
            raise ValueError("Không thể lấy dữ liệu trạng thái thị trường.")
            
        df = pd.DataFrame(json_data)
        
        # Format timestamps if present to readable datetime in Vietnam timezone
        for col in ['time', 'lastTradingDate', 'lastMarketInit']:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col], unit='ms').dt.tz_localize('UTC').dt.tz_convert('Asia/Ho_Chi_Minh').dt.tz_localize(None)
                
        # Standardize column names to snake_case
        df.columns = [camel_to_snake(col) for col in df.columns]
        
        # Mapping to international unified UI conventions
        rename_map = {
            'market': 'exchange',
            'type': 'asset_type',
            'time': 'timestamp'
        }
        df = df.rename(columns=rename_map)
        
        # Filter to retain only important/standard data columns
        keep_cols = ['exchange', 'asset_type', 'status', 'timestamp', 'last_trading_date']
        df = df[[col for col in keep_cols if col in df.columns]]
                
        if to_df:
            return df
        return df.to_json(orient='records')

# Register provider
from vnstock_data.core.registry import ProviderRegistry  # noqa: E402, F401
ProviderRegistry.register('market', 'mas', Market)
