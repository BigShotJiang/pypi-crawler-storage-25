# Base URL for accessing MaybankTrade's macroeconomic data API.
_BASE_URL = 'https://data.maybanktrade.com.vn/'

# API endpoint for the macroeconomic report with normalized types.
MACRO_DATA = 'data/reportdatatopbynormtype'

# Mapping for report period codes; currently, only the 'quarter' period is supported.
REPORT_PERIOD = {   
    'day': '1',
    'month': '2',
    'quarter': '3',
    'year': '4',
}

# Mapping for report type codes corresponding to various economic indicators.
TYPE_ID = {
    'gdp': '43',
    'cpi': '52',
    'industrial_production': '46', # Sản xuất công nghiệp
    'export_import': '48', # Xuất- Nhập khẩu
    'retail': '47', # Bán lẻ
    'fdi': '50',
    'money_supply': '51', # Tín dụng
    'exchange_rate': '53', # Tỷ giá
    'population_labor': '55', # Dân số - Lao động
    'interest_rate': '66', # Lãi suất
}