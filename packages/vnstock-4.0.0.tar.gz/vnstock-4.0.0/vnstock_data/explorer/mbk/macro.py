import pandas as pd
from datetime import datetime, date
from typing import Optional, Union
from vnstock.core.utils.lookback import get_start_date_from_lookback
from vnai import agg_execution
from vnstock.core.utils.parser import camel_to_snake
from vnstock.core.utils.transform import reorder_cols
from vnstock_data.core.utils.client import send_request
from vnstock_data.core.utils.user_agent import get_headers
from vnstock_data.explorer.mbk.const import _BASE_URL, MACRO_DATA, REPORT_PERIOD, TYPE_ID

def process_report_dates(df, last_updated_col, keep_label=True):
    """
    Processes input series index to clean up and convert it to YYYY-mm-dd format.

    Parameters:
    df (pd.DataFrame): DataFrame whose index contains date information.
    last_updated_col (str): Column name in df with the last updated dates (format 'YYYY-mm-dd' or datetime.date).
    keep_label (bool): Whether to keep the original index as a column named 'original_index'.

    Returns:
    pd.DataFrame: DataFrame with two additional columns:
        - report_time (converted to 'YYYY-mm-dd')
        - report_type (extracted from original index)
    """

    report_times = []
    report_types = []

    for idx, last_updated in zip(df.index, df[last_updated_col]):
        if isinstance(last_updated, date):
            last_updated_date = last_updated
        else:
            last_updated_date = datetime.strptime(str(last_updated), "%Y-%m-%d").date()

        # Hỗ trợ các trường hợp index: 'Quý 1/2024', '6 tháng/2024', '9 tháng/2024', 'Năm/2024', '2024'
        if '/' in str(idx):
            type_part, year = str(idx).split('/')
            year = int(year)
        else:
            # Nếu chỉ là năm, ví dụ '2024'
            type_part = str(idx)
            try:
                year = int(type_part)
                type_part = "Năm"
            except ValueError:
                raise ValueError(f"Unrecognized report type: {type_part}")

        if "Quý" in type_part:
            quarter = int(type_part.split(' ')[1])
            month = quarter * 3
            report_date = date(year, month, 1)
            # Adjust year if the report is Q4 and the last update is in the next year
            if quarter == 4 and last_updated_date.year > year:
                report_date = date(year, 12, 31)
            report_type = f"Quý {quarter}"
        elif "6 tháng" in type_part:
            report_date = date(year, 6, 30)
            report_type = "6 tháng"
        elif "9 tháng" in type_part:
            report_date = date(year, 9, 30)
            report_type = "9 tháng"
        elif "Năm" in type_part or type_part.isdigit():
            report_date = date(year, 12, 31)
            report_type = "Năm"
        else:
            raise ValueError(f"Unrecognized report type: {type_part}")

        report_times.append(report_date.strftime("%Y-%m-%d"))
        report_types.append(report_type)


    df = df.copy()
    if keep_label:
        df['label'] = df.index

    df.index = report_times
    df['report_type'] = report_types

    return df

class Macro:
    """
    A dedicated class for fetching macroeconomic data from MaybankTrade's API.

    This class abstracts the common logic for retrieving macroeconomic data
    (GDP, CPI, etc.) via a generalized data fetching method.

    Attributes:
        start (str): The default start period in the format 'YYYY-MM'.
        end (str): The default end period in the format 'YYYY-MM'.
        headers (dict): HTTP headers including a User-Agent for making requests.
        show_log (bool): Flag to enable or disable logging for debugging.
        data_source (str): Constant data source identifier ('MBK').

    Methods:
        _fetch_macro_data(indicator: str, start: str, end: str, period: str) -> pd.DataFrame:
            Internal method to fetch and standardize data for a given indicator.
        gdp(start: str, end: str, period: str) -> pd.DataFrame:
            Fetches and returns standardized GDP data.
        cpi(start: str, end: str, period: str) -> pd.DataFrame:
            Fetches and returns standardized CPI data.
    """

    def __init__(self, random_agent: bool = False, show_log: bool = False):
        """
        Initializes the Macro class with a date range and API configuration.

        Args:
            random_agent (bool, optional): Use a random user agent if True. Defaults to False.
            show_log (bool, optional): Toggle logging output. Defaults to False.
        """
        self.data_source = 'MBK'

        # Geneexchange_rate HTTP headers using the given data source and user agent options.
        self.headers = get_headers(data_source=self.data_source, random_agent=random_agent)
        self.headers['content-type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        self.show_log = show_log

    def _fetch_macro_data(self, indicator: str, start: Optional[str] = None, end: Optional[str] = None, period: str = 'quarter', length: Optional[Union[str, int]] = None) -> pd.DataFrame:
        """
        Internal method to fetch and process macroeconomic data for a given indicator.

        This method validates the date inputs based on the indicator type,
        constructs a raw-text payload, sends an API request, and processes the returned data.

        Args:
            indicator (str): The economic indicator key as defined in TYPE_ID (e.g., 'gdp', 'cpi', 'exchange_rate').
            start (str): Start date. For 'exchange_rate', the format must be 'YYYY-mm-dd';
                        for other indicators, the format must be 'YYYY-mm'.
            end (str): End date. For 'exchange_rate', the format must be 'YYYY-mm-dd';
                    for other indicators, the format must be 'YYYY-mm'.
            period (str, optional): Report period type. Commonly 'quarter' or 'day'. Defaults to 'quarter'.

        Raises:
            ValueError: If the report period is unsupported, if date formats are invalid,
                        or if the indicator code is not found in the TYPE_ID mapping.

        Returns:
            pd.DataFrame: A DataFrame containing the standardized macroeconomic data with 'report_time' as the index.
        """
        # Construct the API URL.
        url = f"{_BASE_URL}{MACRO_DATA}"

        # Retrieve the period code from REPORT_PERIOD.
        period_code = REPORT_PERIOD.get(period)
        if period_code is None:
            raise ValueError(f"Unsupported report period type: {period}")

        # Process date parts depending on the indicator type and period.
        # Determine end date
        if end is None:
            end_date_str = datetime.now().strftime("%Y-%m-%d")
        else:
            end_str = str(end)
            if len(end_str) == 4 and end_str.isdigit():
                end_date_str = f"{end_str}-12-31"
            elif len(end_str) == 7 and '-' in end_str:
                year, month = map(int, end_str.split('-'))
                end_date_str = pd.Period(f"{year}-{month}", freq='M').end_time.strftime("%Y-%m-%d")
            else:
                end_date_str = end_str

        # Determine start date
        if start is None:
            if length is not None:
                length_str = str(length).upper()
                if length_str.endswith('B'):
                    # Convert bars to days roughly for macro data
                    length_str = length_str[:-1] + 'D'
                    start_date_str = get_start_date_from_lookback(lookback_length=length_str, end_date=end_date_str)
                elif length_str.isdigit():
                    if period == 'day':
                        length_str += 'D'
                        start_date_str = get_start_date_from_lookback(lookback_length=length_str, end_date=end_date_str)
                    else:
                        # Fetch a massive window natively to prevent empty sets for delayed macro publications
                        start_date_str = get_start_date_from_lookback(lookback_length='20Y', end_date=end_date_str)
                else:
                    start_date_str = get_start_date_from_lookback(lookback_length=length_str, end_date=end_date_str)
            else:
                # Default lookback if both start and length are None
                default_lookback = '1Y' if period == 'day' else '10Y'
                start_date_str = get_start_date_from_lookback(lookback_length=default_lookback, end_date=end_date_str)
        else:
            start_str = str(start)
            if len(start_str) == 4 and start_str.isdigit():
                start_date_str = f"{start_str}-01-01"
            elif len(start_str) == 7 and '-' in start_str:
                start_date_str = f"{start_str}-01"
            else:
                start_date_str = start_str

        start_parts = start_date_str.split('-')
        end_parts = end_date_str.split('-')
        
        start_year = start_parts[0]
        end_year = end_parts[0]
        
        if indicator in ['exchange_rate', 'interest_rate'] and period == 'day':
            start_period = start_date_str
            end_period = end_date_str
        else:
            if period == 'year':
                start_period = '0'
                end_period = '0'
            else:
                start_month = start_parts[1]
                end_month = end_parts[1]

                if period == 'quarter':
                    start_quarter = (int(start_month) - 1) // 3
                    end_quarter = (int(end_month) - 1) // 3
                    start_period = str(start_quarter)
                    end_period = str(end_quarter)
                elif period == 'month':
                    start_period = str(int(start_month))
                    end_period = str(int(end_month))
                else:
                    start_period = '0'
                    end_period = '0'

        # Retrieve the indicator code from the TYPE_ID mapping.
        indicator_code = TYPE_ID.get(indicator)
        if indicator_code is None:
            raise ValueError(f"{indicator} report type code is not defined in TYPE_ID mapping")

        # Construct the payload as a raw text query string.
        payload = (
            f"type={period_code}"
            f"&fromYear={start_year}"
            f"&toYear={end_year}"
            f"&from={start_period}"
            f"&to={end_period}"
            f"&normTypeID={indicator_code}"
        )

        # Make the API POST request using the raw payload.
        data = send_request(
            url=url,
            headers=self.headers,
            method="POST",
            payload=payload,
            show_log=self.show_log
        )

        # Convert the JSON response to a DataFrame.
        df = pd.DataFrame(data)

        # Standardize column names by converting from camelCase to snake_case.
        df.columns = [camel_to_snake(col) for col in df.columns]
        # Clean column names by removing certain prefixes and suffix patterns.
        df.columns = (
            df.columns
            .str.replace('tern_', '', regex=False)
            .str.replace('norm_', '', regex=False)
            .str.replace('term_', '', regex=False)
            .str.replace('from_', '', regex=False)
            .str.replace('_code', '', regex=False)
        )

        # Filter out empty schema placeholder rows returned when no data is available
        if 'report_time' in df.columns:
            df = df[df['report_time'] != '0'].copy()

        # Clean the 'day' column by removing the '/Date(' prefix and ')/' suffix,
        # then convert the numeric timestamp (in milliseconds) to datetime and extract the date.
        day_numeric = pd.to_numeric(
            df['day']
            .str.replace('/Date(', '', regex=False)
            .str.replace(')/', '', regex=False)
        )
        df['day'] = pd.to_datetime(day_numeric, unit='ms').dt.date

        # Drop unnecessary columns.
        drop_columns = ['report_data_id', 'id', 'year', 'group_id', 'css_style', 'type_id']
        df = df.drop(columns=drop_columns, errors='ignore')

        # Reorder columns: place 'report_time' as the first column and 'unit' and 'source' at the end.
        df = reorder_cols(df, cols=['unit', 'source'], position='last')
        df = reorder_cols(df, cols=['report_time'], position='first')

        # If 'report_time' contains values with "Tháng " (e.g., "Tháng 12/2024"),
        # remove the prefix and convert the remaining "MM/YYYY" into the last day of that month.
        if df['report_time'].str.contains("Tháng ").any():
            # Remove the "Tháng " prefix.
            df['report_time'] = df['report_time'].str.replace("Tháng ", "", regex=False)
            # Convert "MM/YYYY" format to the last day of the month.
            df['report_time'] = df['report_time'].apply(
                lambda x: pd.Period(x, freq='M').end_time.date() if isinstance(x, str) else x
            )

        # Set 'report_time' as the index of the DataFrame.
        df.set_index('report_time', inplace=True)
        df = df.sort_index(ascending=True)
        # rename day column to last_updated
        df.rename(columns={'day': 'last_updated'}, inplace=True)

        if length is not None and str(length).isdigit():
            df = df.tail(int(length)).copy()

        return df

    @agg_execution("MBK")
    def gdp(self, start: Optional[str] = None, end: Optional[str] = None, period: str = 'quarter', keep_label: bool = False, length: Optional[Union[str, int]] = None) -> pd.DataFrame:
        """
        Fetches GDP data for the specified period.

        Args:
            start (str, optional): Start date in the format 'YYYY-MM'. Defaults to '2015-01'.
            end (str, optional): End date in the format 'YYYY-MM'. Defaults to '2025-04'.
            period (str, optional): Report period type. Defaults to 'quarter'.

        Returns:
            pd.DataFrame: A DataFrame containing the standardized GDP data.
        """
        # period can be only quarter and year
        if period not in ['quarter', 'year']:
            raise ValueError(f"Unsupported report period type: {period}")

        df = self._fetch_macro_data('gdp', start, end, period, length=length)
        # process the index column to turn into standardized label
        df = process_report_dates(df, last_updated_col='last_updated', keep_label=keep_label)
        # set the index name to report_time
        df.index.name = 'report_time'
        # sort values
        df = df.sort_values(['last_updated', 'group_name', 'name'])
        return df

    @agg_execution("MBK")
    def cpi(self, start: Optional[str] = None, end: Optional[str] = None, period: str = 'month', length: Optional[Union[str, int]] = None) -> pd.DataFrame:
        """
        Fetches CPI data for the specified period.

        Args:
            start (str, optional): Start date in the format 'YYYY-MM'. Defaults to '2015-01'.
            end (str, optional): End date in the format 'YYYY-MM'. Defaults to '2025-04'.
            period (str, optional): Report period type. Defaults to 'quarter'.

        Returns:
            pd.DataFrame: A DataFrame containing the standardized CPI data.
        """
        # period can be only month and year
        if period not in ['month', 'year']:
            raise ValueError(f"Unsupported report period type: {period}")

        df = self._fetch_macro_data('cpi', start, end, period, length=length)
        # if group_name in df, drop it
        if 'group_name' in df.columns:
            df = df.drop(columns=['group_name'])
        return df

    @agg_execution("MBK")
    def industry_prod (self, start: Optional[str] = None, end: Optional[str] = None, period: str = 'month', length: Optional[Union[str, int]] = None) -> pd.DataFrame:
        """
        Fetches Industrial Production data for the specified period.

        Args:
            start (str, optional): Start date in the format 'YYYY-MM'. Defaults to '2015-01'.
            end (str, optional): End date in the format 'YYYY-MM'. Defaults to '2025-04'.
            period (str, optional): Report period type. Defaults to 'quarter'.

        Returns:
            pd.DataFrame: A DataFrame containing the standardized Industrial Production data.
        """
        # period can be only month and year
        if period not in ['month', 'year']:
            raise ValueError(f"Unsupported report period type: {period}")

        return self._fetch_macro_data('industrial_production', start, end, period, length=length)

    @agg_execution("MBK")
    def import_export (self, start: Optional[str] = None, end: Optional[str] = None, period: str = 'month', length: Optional[Union[str, int]] = None) -> pd.DataFrame:
        """
        Fetches Import-Export data for the specified period.

        Args:
            start (str, optional): Start date in the format 'YYYY-MM'. Defaults to '2015-01'.
            end (str, optional): End date in the format 'YYYY-MM'. Defaults to '2025-04'.
            period (str, optional): Report period type. Defaults to 'quarter'.

        Returns:
            pd.DataFrame: A DataFrame containing the standardized Import-Export data.
        """
        # period can be only month and year
        if period not in ['month', 'year']:
            raise ValueError(f"Unsupported report period type: {period}")

        df = self._fetch_macro_data('export_import', start, end, period, length=length)
        # if group_name in df, drop it
        if 'group_name' in df.columns:
            df = df.drop(columns=['group_name'])
        return df

    @agg_execution("MBK")
    def retail (self, start: Optional[str] = None, end: Optional[str] = None, period: str = 'month', length: Optional[Union[str, int]] = None) -> pd.DataFrame:
        """
        Fetches Retail data for the specified period.

        Args:
            start (str, optional): Start date in the format 'YYYY-MM'. Defaults to '2015-01'.
            end (str, optional): End date in the format 'YYYY-MM'. Defaults to '2025-04'.
            period (str, optional): Report period type. Defaults to 'quarter'.

        Returns:
            pd.DataFrame: A DataFrame containing the standardized Retail data.
        """
        # period can be only month and year
        if period not in ['month', 'year']:
            raise ValueError(f"Unsupported report period type: {period}")
        
        df = self._fetch_macro_data('retail', start, end, period, length=length)

        # if group_name in df, drop it
        if 'group_name' in df.columns:
            df = df.drop(columns=['group_name'])
        return df
    
    @agg_execution("MBK")
    def fdi (self, start: Optional[str] = None, end: Optional[str] = None, period: str = 'month', length: Optional[Union[str, int]] = None) -> pd.DataFrame:
        """
        Fetches Foreign Direct Investment data for the specified period.

        Args:
            start (str, optional): Start date in the format 'YYYY-MM'. Defaults to '2015-01'.
            end (str, optional): End date in the format 'YYYY-MM'. Defaults to '2025-04'.
            period (str, optional): Report period type. Defaults to 'quarter'.

        Returns:
            pd.DataFrame: A DataFrame containing the standardized Foreign Direct Investment data.
        """
        # period can be only month and year
        if period not in ['month', 'year']:
            raise ValueError(f"Unsupported report period type: {period}")

        return self._fetch_macro_data('fdi', start, end, period, length=length)
    
    @agg_execution("MBK")
    def money_supply (self, start: Optional[str] = None, end: Optional[str] = None, period: str = 'month', length: Optional[Union[str, int]] = None) -> pd.DataFrame:
        """
        Fetches money supply data for the specified period.

        Args:
            start (str, optional): Start date in the format 'YYYY-MM'. Defaults to '2015-01'.
            end (str, optional): End date in the format 'YYYY-MM'. Defaults to '2025-04'.
            period (str, optional): Report period type. Defaults to 'quarter'.

        Returns:
            pd.DataFrame: A DataFrame containing the standardized Foreign Direct Investment data.
        """
        # period can be only month and year
        if period not in ['month', 'year']:
            raise ValueError(f"Unsupported report period type: {period}")

        df = self._fetch_macro_data('money_supply', start, end, period, length=length)
        # if group_name in df, drop it
        if 'group_name' in df.columns:
            df = df.drop(columns=['group_name'])
        return df
    
    @agg_execution("MBK")
    def interest_rate (self, start: Optional[str] = None, end: Optional[str] = None, period: str = 'day', format: str = 'pivot', length: Optional[Union[str, int]] = None) -> pd.DataFrame:
        """
        Fetches Interest Rate data for the specified period.

        Args:
            start (str, optional): Start date in the format 'YYYY-MM-DD'. Defaults to '2025-01-02'.
            end (str, optional): End date in the format 'YYYY-MM-DD'. Defaults to '2025-04-10'.
            period (str, optional): Report period type. Defaults to 'day'.
            format (str, optional): Format of the returned DataFrame. Options: 'pivot' (default wide table) or 'long' (raw flat table).

        Returns:
            pd.DataFrame: A DataFrame containing the standardized Interest Rate data.
        """
        # period can be only day and year
        if period not in ['day', 'year']:
            raise ValueError(f"Unsupported report period type: {period}")
            
        if format not in ['pivot', 'long']:
            raise ValueError(f"Unsupported format type: {format}. Use 'pivot' or 'long'.")

        df = self._fetch_macro_data('interest_rate', start, end, period, length=length)
        df.index = pd.to_datetime(df.index, dayfirst=True)
        
        if format == 'pivot':
            df = df.pivot_table(
                index='report_time', 
                columns=['group_name', 'name'], 
                values='value'
            )
            df = df.sort_index(axis=1, level=[0, 1])
            # Normalize báo cáo: fill các giá trị trước đó xuống cho các ngày không có báo cáo cập nhật
            df = df.ffill()
            
        return df

    @agg_execution("MBK")
    def exchange_rate (self, start: Optional[str] = None, end: Optional[str] = None, period: str = 'day', length: Optional[Union[str, int]] = None) -> pd.DataFrame:
        """
        Fetches Real Interest exchange_rate data for the specified period.

        Args:
            start (str, optional): Start date in the format 'YYYY-MM'. Defaults to '2015-01'.
            end (str, optional): End date in the format 'YYYY-MM'. Defaults to '2025-04'.
            period (str, optional): Report period type. Defaults to 'quarter'.

        Returns:
            pd.DataFrame: A DataFrame containing the standardized Real Interest exchange_rate data.
        """
        # period can be only month and year
        if period not in ['day', 'year']:
            raise ValueError(f"Unsupported report period type: {period}")

        df = self._fetch_macro_data('exchange_rate', start, end, period, length=length)
        # if group_name in df, drop it
        if 'group_name' in df.columns:
            df = df.drop(columns=['group_name'])

        df.index = pd.to_datetime(df.index, dayfirst=True)
        return df

    @agg_execution("MBK")
    def population_labor (self, start: Optional[str] = None, end: Optional[str] = None, period: str = 'year', length: Optional[Union[str, int]] = None) -> pd.DataFrame:
        """
        Fetches Population and Labor data for the specified period.

        Args:
            start (str, optional): Start date in the format 'YYYY-MM'. Defaults to '2015-01'.
            end (str, optional): End date in the format 'YYYY-MM'. Defaults to '2025-04'.
            period (str, optional): Report period type. Defaults to 'quarter'.

        Returns:
            pd.DataFrame: A DataFrame containing the standardized Population and Labor data.
        """
        # period can be only month and year
        if period not in ['month', 'year']:
            raise ValueError(f"Unsupported report period type: {period}")

        df = self._fetch_macro_data('population_labor', start, end, period, length=length)
        # if group_name in df, drop it
        if 'group_name' in df.columns:
            df = df.drop(columns=['group_name'])
        return df

# Register provider
from vnstock_data.core.registry import ProviderRegistry  # noqa: E402, F401
ProviderRegistry.register('macro', 'mbk', Macro)
