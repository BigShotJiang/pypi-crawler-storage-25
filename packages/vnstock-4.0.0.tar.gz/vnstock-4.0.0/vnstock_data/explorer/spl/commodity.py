import pandas as pd
from datetime import datetime
from zoneinfo import ZoneInfo
from .spl_fetcher import SPLFetcher
from typing import Dict, Any, Optional, List, Union
from datetime import timedelta
from vnstock.core.utils.lookback import get_start_date_from_lookback
from vnai import agg_execution
from vnstock.core.utils.logger import get_logger

logger = get_logger(__name__)

class CommodityPrice:
    """
    Lớp cung cấp các phương thức để lấy dữ liệu giá hàng hóa từ nguồn SPL.
    """

    def __init__(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None, show_log: Optional[bool] = False):
        """
        Khởi tạo đối tượng CommodityPrice với tùy chọn ngày bắt đầu và kết thúc mặc định.

        Các tham số:
            start (str, optional): Ngày bắt đầu mặc định (định dạng 'YYYY-MM-DD'). Mặc định là None.
            end (str, optional): Ngày kết thúc mặc định (định dạng 'YYYY-MM-DD'). Mặc định là None.
            length (str, int, optional): Khoảng thời gian mặc định cần lấy dữ liệu. Mặc định là '1Y'.
        """
        self.fetcher = SPLFetcher()
        self.default_start = start
        self.default_end = end
        self.default_length = length if length is not None else '1Y'

        if not show_log:
            logger.setLevel('CRITICAL')

    def _fetch_commodity(
        self,
        ticker: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
        interval: str = "1d",
        columns: Optional[List] = None,
        length: Optional[Union[str, int]] = None
    ) -> pd.DataFrame:
        """
        Lấy dữ liệu giá hàng hóa từ API SPL.

        Các tham số:
            ticker (str): Mã hàng hóa cần lấy dữ liệu.
            start (str, optional): Ngày bắt đầu (định dạng 'YYYY-MM-DD').
                Ưu tiên tham số nếu có, mặc định là giá trị khởi tạo.
            end (str, optional): Ngày kết thúc (định dạng 'YYYY-MM-DD').
                Ưu tiên tham số nếu có, mặc định là giá trị khởi tạo.
            interval (str, optional): Khoảng thời gian (mặc định '1d').
            columns (List, optional): Danh sách cột cần lấy.
                Mặc định là None (lấy tất cả).
        
        Giá trị trả về:
            pd.DataFrame: Dữ liệu giá hàng hóa với time làm index.
        """
        # Ưu tiên giá trị tham số, fallback về giá trị mặc định
        end_val = end or self.default_end
        if end_val is None:
            end_val = datetime.now().strftime("%Y-%m-%d")
        
        # Calculate start logic similar to KBS/VCI
        start_val = start
        if start_val is None:
            # Determine effective length: method arg > class default
            eff_length = length if length is not None else self.default_length
            
            if eff_length is not None:
                if str(eff_length).isdigit():
                    # Fetch a massive lookback window natively to prevent empty sets for delayed commodity publications
                    start_val = get_start_date_from_lookback(lookback_length='20Y', end_date=end_val)
                else:    
                    length_str = str(eff_length).upper()
                    if length_str.endswith('B'):
                        # Convert bars to days roughly for commodity data
                        length_str = length_str[:-1] + 'D'
                    start_val = get_start_date_from_lookback(lookback_length=length_str, end_date=end_val)
            else:
                # If no length, use default_start or default logic
                start_val = self.default_start

        params = {
            "ticker": ticker,
            "interval": interval,
            "type": "commodity",
        }

        # Múi giờ Việt Nam (GMT+7)
        vn_tz = ZoneInfo("Asia/Ho_Chi_Minh")
        
        start = start_val
        end = end_val

        if start:
            # Chuyển đổi sang datetime với múi giờ VN, bắt đầu 00:00:00
            dt_start = datetime.strptime(start, "%Y-%m-%d")
            dt_start = dt_start.replace(
                hour=0, minute=0, second=0, microsecond=0, tzinfo=vn_tz
            )
            params["from"] = int(dt_start.timestamp())
            
        if end:
            # Chuyển đổi sang datetime với múi giờ VN, kết thúc 23:59:59
            dt_end = datetime.strptime(end, "%Y-%m-%d")
            dt_end = dt_end.replace(
                hour=23, minute=59, second=59, microsecond=999999,
                tzinfo=vn_tz
            )
            params["to"] = int(dt_end.timestamp())

        self.fetcher.validate(params)
        raw_data = self.fetcher.fetch(
            endpoint="/historical/prices/ohlcv",
            params=params
        )
        df = self.fetcher.to_dataframe(raw_data["data"])
        
        # Chuyển đổi cột time sang datetime với múi giờ VN
        df["time"] = pd.to_datetime(df["time"])
        if df["time"].dt.tz is None:
            df["time"] = df["time"].dt.tz_localize(vn_tz)
        else:
            df["time"] = df["time"].dt.tz_convert(vn_tz)

        # bỏ time zone và chuẩn hoá về đầu ngày để tránh lỗi concat mismatch gộp cột null
        df["time"] = df["time"].dt.tz_localize(None).dt.normalize()
        
        # Đặt time làm index
        df.set_index("time", inplace=True)


        # Trả về các cột được chọn nếu có
        if columns is not None:
            df = df[columns]
            
        if length is not None and str(length).isdigit():
            df = df.tail(int(length)).copy()
            
        return df
        

    def _gold_vn_buy(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá vàng Việt Nam (mua vào)."""
        return self._fetch_commodity("GOLD:VN:BUY", start, end, columns=['close'], length=length)

    def _gold_vn_sell(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá vàng Việt Nam (bán ra)."""
        return self._fetch_commodity("GOLD:VN:SELL", start, end, columns=['close'], length=length)
    
    @agg_execution("SPL.ext")
    def gold_vn(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá vàng Việt Nam."""
        buy = self._gold_vn_buy(start, end, length=length)
        sell = self._gold_vn_sell(start, end, length=length)
        # return as Pandas DataFrame
        df = pd.concat([buy, sell], axis=1)
        df.columns = ["buy", "sell"]
        # Chuẩn hoá giữ giá trị ngày trước đó nếu 1 trong 2 chiều chưa/không cập nhật
        df = df.ffill()
        return df

    @agg_execution("SPL.ext")
    def gold_global(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá vàng thế giới."""
        return self._fetch_commodity("GC=F", start, end, length=length)

    @agg_execution("SPL.ext")
    def _gas_ron92(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá xăng RON92 tại Việt Nam."""
        return self._fetch_commodity("GAS:RON92:VN", start, end, columns=['close'], length=length)

    @agg_execution("SPL.ext")
    def _gas_ron95(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá xăng RON95 tại Việt Nam."""
        return self._fetch_commodity("GAS:RON95:VN", start, end, columns=['close'], length=length)

    @agg_execution("SPL.ext")
    def _oil_do(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá dầu DO tại Việt Nam."""
        return self._fetch_commodity("GAS:DO:VN", start, end, columns=['close'], length=length)

    @agg_execution("SPL.ext")
    def gas_vn(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá xăng và dầu DO tại Việt Nam."""
        ron92 = self._gas_ron92(start, end, length=length)
        ron95 = self._gas_ron95(start, end, length=length)
        oil_do = self._oil_do(start, end, length=length)
        df = pd.concat([ron95, ron92, oil_do], axis=1)
        df.columns = ["ron95", "ron92", "oil_do"]
        # Chuẩn hoá giữ giá trị ngày trước đó nếu 1 trong các kỳ không cập nhật toàn bộ
        df = df.ffill()
        return df

    @agg_execution("SPL.ext")
    def oil_crude(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá dầu thô."""
        return self._fetch_commodity("CL=F", start, end, length=length)

    @agg_execution("SPL.ext")
    def gas_natural(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá khí thiên nhiên."""
        return self._fetch_commodity("NG=F", start, end, length=length)

    @agg_execution("SPL.ext")
    def coke(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá than cốc."""
        return self._fetch_commodity("ICEEUR:NCF1!", start, end, length=length)

    @agg_execution("SPL.ext")
    def steel_d10(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá thép D10 tại Việt Nam."""
        return self._fetch_commodity("STEEL:D10:VN", start, end, columns=['close'], length=length)

    @agg_execution("SPL.ext")
    def iron_ore(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá quặng sắt."""
        return self._fetch_commodity("COMEX:TIO1!", start, end, length=length)

    @agg_execution("SPL.ext")
    def steel_hrc(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá thép HRC."""
        return self._fetch_commodity("COMEX:HRC1!", start, end, length=length)

    @agg_execution("SPL.ext")
    def fertilizer_ure(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá phân ure."""
        return self._fetch_commodity("CBOT:UME1!", start, end, length=length)

    @agg_execution("SPL.ext")
    def soybean(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá đậu tương."""
        return self._fetch_commodity("ZM=F", start, end, length=length)

    @agg_execution("SPL.ext")
    def corn(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá ngô (bắp)."""
        return self._fetch_commodity("ZC=F", start, end, length=length)

    @agg_execution("SPL.ext")
    def sugar(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá đường."""
        return self._fetch_commodity("SB=F", start, end, length=length)

    @agg_execution("SPL.ext")
    def pork_north_vn(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá heo hơi miền Bắc Việt Nam."""
        return self._fetch_commodity("PIG:NORTH:VN", start, end, columns=['close'], length=length)

    @agg_execution("SPL.ext")
    def pork_china(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """Lấy giá heo hơi Trung Quốc."""
        return self._fetch_commodity("PIG:CHINA", start, end, columns=['close'], length=length)

# Register provider
from vnstock_data.core.registry import ProviderRegistry  # noqa: E402, F401
ProviderRegistry.register('commodity', 'spl', CommodityPrice)
