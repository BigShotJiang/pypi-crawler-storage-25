_BASE_URL = "https://s.cafef.vn/Ajax/PageNew/DataHistory"

_CAFEF_INDEX_MAPPING = {
    'VNINDEX': 'HOSE',
    'HOSE': 'HOSE',
    'UPCOMINDEX': 'UPCOM',
    'UPCOM': 'UPCOM',
    'HNXINDEX': 'HNX',
    'HNX': 'HNX',
    'VN30': 'VN30'
}

_CAFEF_INDEX_BASE_URL = "https://cafef.vn/du-lieu/Ajax/PageNew/DataGDNN"

_INDEX_PRICE_HISTORY_MAP = {
    'TradeDate': 'time',
    'OpenPrice': 'open',
    'HighPrice': 'high',
    'LowPrice': 'low',
    'ClosePrice': 'close',
    'AdjustPrice': 'adjusted_price',
    'Volume': 'matched_volume',
    'TotalValue': 'matched_value',
    'AgreedVolume': 'deal_volume',
    'AgreedValue': 'deal_value',
    'ChangePrice': 'change'
}

_INDEX_FOREIGN_TRADE_MAP = {
    'TradeDate': 'time',
    'NetVolume': 'fr_net_volume',
    'NetValue': 'fr_net_value',
    'BuyVolume': 'fr_buy_volume',
    'BuyValue': 'fr_buy_value',
    'SellVolume': 'fr_sell_volume',
    'SellValue': 'fr_sell_value',
    'Percent': 'fr_ownership' 
}

_INDEX_ORDER_STATS_MAP = {
    'TradeDate': 'time',
    'ChangePrice': 'change',
    'BuyOrderCount': 'buy_orders',
    'SellOrderCount': 'sell_orders',
    'BuyVolume': 'buy_volume',
    'SellVolume': 'sell_volume',
    'BuySellDiff': 'volume_diff',
    'BuyAverage': 'avg_buy_order_volume',
    'SellAverage': 'avg_sell_order_volume'
}

_PRICE_HISTORY_MAP = {
    'Ngay': 'time',
    'GiaMoCua': 'open',
    'GiaCaoNhat': 'high',
    'GiaThapNhat': 'low',
    'GiaDongCua': 'close',
    'GiaDieuChinh': 'adjusted_price',
    'ThayDoi': 'change',
    'change_pct': 'change_pct',
    'KhoiLuongKhopLenh': 'matched_volume',
    'GiaTriKhopLenh': 'matched_value',
    'KLThoaThuan': 'deal_volume',
    'GtThoaThuan': 'deal_value',
}

_FOREIGN_TRADE_MAP = {
    'Ngay': 'time',
    'KLGDRong': 'fr_net_volume',
    'GTDGRong': 'fr_net_value',
    'ThayDoi': 'change',
    'KLMua': 'fr_buy_volume',
    'GtMua': 'fr_buy_value',
    'KLBan': 'fr_sell_volume',
    'GtBan': 'fr_sell_value',
    'RoomConLai': 'fr_remaining_room',
    'DangSoHuu': 'fr_ownership'
}

_PROP_TRADE_MAP = {
    "Symbol": "symbol",
    "Date": "time",
    "KLcpMua": "prop_buy_volume",
    "KlcpBan": "prop_sell_volume",
    "GtMua": "prop_buy_value",
    "GtBan": "prop_sell_value"
}

_ORDER_STATS_MAP = {
    "Date": "time",
    "ThayDoi": "change",
    "SoLenhMua": "buy_orders",
    "SoLenhDatBan": "sell_orders",
    "KLDatMua": "buy_volume",
    "KLDatBan": "sell_volume",
    "ChenhLechKL": "volume_diff",
    "KLTB1LenhMua": "avg_buy_order_volume",
    "KLTB1LenhBan": "avg_sell_order_volume"
}

_INSIDER_DEAL_MAP = {
    "Stock": "symbol",
    "HolderID": "holder_id",
    "TransactionMan": "transaction_man",
    "TransactionManPosition": "transaction_man_position",
    "RelatedManPosition": "related_man_position",
    "RelatedMan": "related_man",
    "VolumeBeforeTransaction": "volume_before_transaction",
    "PlanBuyVolume": "plan_buy_volume",
    "PlanSellVolume": "plan_sell_volume",
    "PlanBeginDate": "plan_begin_date",
    "PlanEndDate": "plan_end_date",
    "RealBuyVolume": "real_buy_volume",
    "RealSellVolume": "real_sell_volume",
    "RealEndDate": "real_end_date",
    "PublishedDate": "published_date",
    "OrderDate": "order_date",
    "VolumeAfterTransaction": "volume_after_transaction",
    "TransactionNote": "transaction_note",
    "ShareHolderCode": "shareholder_code",
    "TyLeSoHuu": "ownership_percentage",
}