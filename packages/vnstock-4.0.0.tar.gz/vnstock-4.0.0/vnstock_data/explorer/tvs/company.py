"""
Module quản lý thông tin công ty từ nguồn dữ liệu VCI.
"""

import json
import pandas as pd
from typing import Dict, Optional, Union, List
from vnstock.core.utils.logger import get_logger
from vnstock_data.core.utils.user_agent import get_headers
from vnstock_data.core.utils.client import send_request
from vnstock_data.core.utils.user_agent import get_headers
from vnstock.core.utils.transform import clean_html_dict, flatten_dict_to_df, flatten_list_to_df, reorder_cols, drop_cols_by_pattern
from vnstock.core.utils.parser import get_asset_type, camel_to_snake
from vnai import agg_execution  # Import the decorator from vnai package
from vnstock_data.explorer.tvs.const import _BASE_URL
import copy

logger = get_logger(__name__)

class Company:
    """
    Class (lớp) quản lý các thông tin liên quan đến công ty từ nguồn dữ liệu VCI.

    Tham số:
        - symbol (str): Mã chứng khoán của công ty cần truy xuất thông tin.
        - random_agent (bool): Sử dụng user-agent ngẫu nhiên hoặc không. Mặc định là False.
        - to_df (bool): Chuyển đổi dữ liệu thành DataFrame hoặc không. Mặc định là True.
        - show_log (bool): Hiển thị thông tin log hoặc không. Mặc định là False.
    """
    def __init__(self, symbol: str, random_agent: bool = False, 
                 to_df: Optional[bool] = True, show_log: Optional[bool] = False):
        """
        Khởi tạo đối tượng Company với các tham số cho việc truy xuất dữ liệu.
        """
        self.symbol = symbol.upper()
        self.asset_type = get_asset_type(self.symbol)
        
        # Validate if symbol is a stock
        if self.asset_type not in ['stock']:
            raise ValueError("Mã chứng khoán không hợp lệ. Chỉ cổ phiếu mới có thông tin.")
            
        self.headers = get_headers(data_source='TVS', random_agent=random_agent)
        self.show_log = show_log
        self.to_df = to_df
        
        if not show_log:
            logger.setLevel('CRITICAL')

    def _fetch_data(self, url) -> Dict:
        """
        Phương thức riêng để lấy dữ liệu công ty từ nguồn VCI.
        
        Returns:
            Dict: Dữ liệu thô về công ty từ API.
        """
        if self.show_log:
            logger.debug(f"Requesting data for {self.symbol} from {url}. payload: {payload}")

        # Use centralized API client instead of direct requests
        response_data = send_request(
            url=url,
            headers=self.headers,
            method="POST",
            payload=payload,
            show_log=self.show_log
        )
        
        return response_data
    
    @agg_execution('TVS.ext')
    def overview(self) -> Union[Dict, pd.DataFrame]:
        """
        Lấy thông tin tổng quan về công ty từ nguồn dữ liệu VCI.
        
        Returns:
            Union[Dict, pd.DataFrame]: Thông tin tổng quan về công ty dưới dạng từ điển hoặc DataFrame.
        """
        url = f"{_BASE_URL}Dashboard/GetComanyInfo?ticker={self.symbol}"
        data = self._fetch_data(url)
        
        if not data:
            logger.warning(f"No data available for {self.symbol}")
            return None
        
        df = pd.DataFrame(data, index=[0])
        df.columns = [camel_to_snake(col) for col in df.columns]
        df = df.rename(columns={'ticker': 'symbol'})
        
        if self.to_df:
            return df
        else:
            return data.to_dict(orient='records')[0] if not data.empty else {}