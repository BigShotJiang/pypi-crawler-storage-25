"""History module for ForexSB."""

import struct
import gzip
import datetime
from typing import Dict, Optional, Union
import pandas as pd
import requests

from vnstock.core.utils.lookback import get_start_date_from_lookback
from vnai import agg_execution

from vnstock.core.models import TickerModel
from vnstock.core.utils.logger import get_logger
from vnstock.core.utils.interval import normalize_interval
from vnstock_data.core.utils.user_agent import get_headers

# Import the core _OHLC_MAP if available, else define it.
try:
    from vnstock.explorer.vci.const import _OHLC_MAP
except ImportError:
    _OHLC_MAP = {
        "time": "time",
        "open": "open",
        "high": "high",
        "low": "low",
        "close": "close",
        "volume": "volume"
    }

logger = get_logger(__name__)

# ForexSB Dukascopy support
_FXSB_INTERVAL_MAP = {
    '1m': '1',
    '5m': '5',
    '15m': '15',
    '30m': '30',
    '1H': '30',
    '4H': '30',
    '1D': '30',
    '1W': '30'
}

class Quote:
    """
    Cấu hình truy cập dữ liệu lịch sử giá cho các cặp ngoại tệ từ ForexSB.
    """
    def __init__(
        self, 
        symbol: str, 
        random_agent: bool = False, 
        show_log: bool = False,
        **kwargs
    ):
        self.symbol = symbol.upper()
        self.data_source = 'FXSB'
        self.base_url = 'https://data.forexsb.com/datafeed/data/dukascopy/'
        self.interval_map = _FXSB_INTERVAL_MAP
        self.show_log = show_log
        
        if not show_log:
            logger.setLevel('CRITICAL')

    def _input_validation(self, start: str, end: str, interval: str):
        """
        Validate input data format and interval.
        """
        try:
            if str(interval).upper() in ['H4', '4H']:
                normalized_interval = '4H'
            else:
                normalized_tf = normalize_interval(interval)
                normalized_interval = normalized_tf.value
        except ValueError:
            raise ValueError(f"Giá trị interval không hợp lệ: {interval}.")
        
        if normalized_interval not in self.interval_map:
            supported_intervals = ", ".join(self.interval_map.keys())
            raise ValueError(f"Giá trị interval không được FXSB hỗ trợ: {normalized_interval}. Hỗ trợ cơ bản và mở rộng: {supported_intervals}")
            
        ticker = TickerModel(symbol=self.symbol, start=start, end=end, interval=normalized_interval)
        return ticker

    @agg_execution("FXSB.ext")
    def history(
        self, 
        start: str = "", 
        end: str = "", 
        interval: str = "1D", 
        to_df: bool = True, 
        show_log: bool = False, 
        length: Union[str, int] = 100_000,
        floating: int = 5
    ) -> Union[pd.DataFrame, str]:
        """
        Tải dữ liệu OHLC từ file .lb.gz của ForexSB.

        Tham số:
            - start (tùy chọn): thời gian bắt đầu lấy dữ liệu (YYYY-MM-DD). 
            - end (tùy chọn): thời gian kết thúc lấy dữ liệu.
            - interval (tùy chọn): Khung thời gian.
            - to_df (tùy chọn): Chuyển đổi về DataFrame.
            - count_back (tùy chọn): Giới hạn số bars cuối cùng. Mặc định là 100,000 để an toàn,
                                     có thể lấy toàn bộ file nếu cần.
            - length (tùy chọn): khoảng thời gian quy ước.
        """
        if not end:
            end = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d")

        if not start:
            if length:
                length_str = str(length).lower()
                if length_str.endswith('b'):
                    length = int(length_str[:-1])
                elif length_str.isdigit():
                    length = int(length_str)
                else:
                    start = get_start_date_from_lookback(lookback_length=str(length).upper(), end_date=end)
            else:
                length = 100_000
                
        ticker = self._input_validation(start if start else "1970-01-01", end, interval)
        fx_interval = self.interval_map[ticker.interval]
        
        url = f"{self.base_url}{self.symbol}{fx_interval}.lb.gz"
        
        try:
            response = requests.get(
                url, 
                headers=get_headers('FXSB', random_agent=False, browser='chrome', platform='macos'), 
                timeout=15
            )
        except requests.exceptions.Timeout:
            raise ConnectionError(
                f"ForexSB request timed out sau 15 giây cho symbol {self.symbol} (interval={ticker.interval}). "
                f"Kiểm tra kết nối mạng hoặc thử lại sau. URL: {url}"
            )
        except requests.exceptions.RequestException as e:
            raise ConnectionError(f"ForexSB connection error: {e}. URL: {url}")
        if response.status_code != 200:
            raise ValueError(f"Không thể truy xuất dữ liệu từ ForexSB cho symbol {self.symbol} (Status {response.status_code}). URL: {url}")
            
        try:
            if response.content[:2] == b'\x1f\x8b':
                decompressed = gzip.decompress(response.content)
            else:
                decompressed = response.content
        except Exception as e:
            raise ValueError(f"Lỗi khi giải nén dữ liệu: {e}")

        # The structure is 28 bytes per record: I I I I I I I (Time, Open, High, Low, Close, Vol, Extra)
        # We can optimize extraction using iter_unpack
        records = []
        record_size = 28
        total_records = len(decompressed) // record_size
        
        # If count_back is given, we can optimize by only parsing the tail
        # Wait, if `start` is provided, we must parse from the end until we hit start, or parse everything and filter.
        # It's quick enough to parse everything in pandas/python. Let's process the whole buffer.
        
        unpack_iter = struct.iter_unpack('<IIIIIII', decompressed)
        columns = ["time", "open", "high", "low", "close", "volume", "extra"]
        
        df = pd.DataFrame(unpack_iter, columns=columns)
        
        # Data conversion
        # Vectorized manipulation is magnitudes faster!
        # ForexSB stores time as Minutes since 2000-01-01 00:00:00!
        df['time'] = pd.to_datetime(df['time'], unit='m', origin='2000-01-01', utc=True)
        # Optional: remove timezone info to match typical unified UI standard (local or naive GMT)
        df['time'] = df['time'].dt.tz_localize(None)
        
        df['open'] = df['open'] / 100000
        df['high'] = df['high'] / 100000
        df['low'] = df['low'] / 100000
        df['close'] = df['close'] / 100000
        
        # Drop the extra column
        df = df.drop(columns=['extra'])
        
        # Determine if we need to aggregate
        if ticker.interval in ['1H', '4H', '1D', '1W']:
            df.set_index('time', inplace=True)
            rule = ticker.interval.replace('H', 'h').replace('D', 'D').replace('W', 'W')
            df = df.resample(rule, label='left', closed='left').agg({
                'open': 'first',
                'high': 'max',
                'low': 'min',
                'close': 'last',
                'volume': 'sum'
            }).dropna().reset_index()
        
        # Filter by start and end using DataFrame logic
        if start is not None and start != "":
            start_date = pd.to_datetime(start)
            df = df[df['time'] >= start_date]
        if end is not None and end != "":
            # Note end may be just YYYY-MM-DD so we add timezone naive bounds correctly
            end_date = pd.to_datetime(end) + pd.Timedelta(days=1)
            df = df[df['time'] < end_date]
            
        df = df.reset_index(drop=True)
        
        if length and isinstance(length, int) and length > 0:
            df = df.tail(length).reset_index(drop=True)
        else:
            # Default safeguard limit up to 100,000 rows max if no explicit bounds enforce otherwise
            # safeguard
            if df.shape[0] > 100_000:
                df = df.tail(100_000).reset_index(drop=True)

        if floating is not None:
            df = df.round(floating)

        df.source = self.data_source

        if to_df:
            return df
        else:
            return df.to_json(orient='records')

# Register provider
from vnstock_data.core.registry import ProviderRegistry  # noqa: E402, F401
ProviderRegistry.register('quote', 'fxsb', Quote)
