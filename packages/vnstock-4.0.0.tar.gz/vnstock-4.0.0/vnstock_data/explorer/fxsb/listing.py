"""Listing module for ForexSB."""

import json
import gzip
from typing import Dict, Optional, Union
import pandas as pd
from vnstock.core.utils.logger import get_logger
from vnai import agg_execution

logger = get_logger(__name__)

from vnstock_data.core.utils.user_agent import get_headers

class Listing:
    """
    Cấu hình truy cập danh sách symbol từ ForexSB.
    """
    def __init__(self, random_agent:Optional[bool]=False, show_log:Optional[bool]=False):
        self.data_source = 'FXSB'
        self.base_url = 'https://data.forexsb.com/datafeed/info/premium.json.gz'
        self.show_log = show_log
        if not show_log:
            logger.setLevel('CRITICAL')

    @agg_execution("FXSB.ext")
    def all_symbols(self, show_log:Optional[bool]=False, to_df:Optional[bool]=True) -> Union[pd.DataFrame, str, Dict]:
        """
        Truy xuất danh sách các mã hỗ trợ (Forex, Crypto, v.v) từ ForexSB.
        """
        import requests
        
        response = requests.get(
            self.base_url,
            headers=get_headers('FXSB', random_agent=False, browser='chrome', platform='macos')
        )
        if response.status_code != 200:
            raise ValueError(f"Không thể truy cập dữ liệu symbol từ ForexSB. Status: {response.status_code}")
        
        try:
            # Check if it was purely auto-decompressed by requests
            if response.content[:2] == b'\x1f\x8b':
                decompressed = gzip.decompress(response.content)
            else:
                decompressed = response.content
            # The JSON structure is at the root layer mapping symbol to details
            data = json.loads(decompressed)
        except Exception as e:
            raise ValueError(f"Lỗi khi giải nén hoặc parse dữ liệu: {e}")
            
        symbols = data
        
        if show_log:
            logger.info(f'Tìm thấy {len(symbols)} biểu tượng.')
            
        if to_df:
            records = list(symbols.values())
            df = pd.DataFrame(records)
            df.source = self.data_source
            return df
        else:
            return symbols

    @agg_execution("FXSB.ext")
    def search_symbol(self, query: str, show_log: Optional[bool] = False, to_df: Optional[bool] = True) -> Union[pd.DataFrame, str]:
        """
        Tìm kiếm các mã hỗ trợ trên ForexSB dựa vào từ khóa (tìm theo symbol hoặc description).
        
        Tham số:
            - query (str): Từ khóa tìm kiếm.
            - show_log (bool): Hiển thị log dữ liệu.
            - to_df (bool): Trả về DataFrame hay JSON string.
        """
        df = self.all_symbols(show_log=False, to_df=True)
        if df.empty:
            if not to_df:
                return "[]"
            return df
        
        q = query.lower()
        mask = df['symbol'].str.lower().str.contains(q, na=False) | \
               df['description'].str.lower().str.contains(q, na=False)
               
        filtered_df = df[mask].reset_index(drop=True)
        
        if show_log:
            logger.info(f"Tìm thấy {len(filtered_df)} kết quả khớp với từ khóa '{query}'")
            
        if to_df:
            return filtered_df
        else:
            return filtered_df.to_json(orient='records')

# Register provider
from vnstock_data.core.registry import ProviderRegistry  # noqa: E402, F401
ProviderRegistry.register('listing', 'fxsb', Listing)
