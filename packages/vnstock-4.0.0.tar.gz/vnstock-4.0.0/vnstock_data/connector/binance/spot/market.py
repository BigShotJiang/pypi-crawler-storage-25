import pandas as pd
from vnstock_data.connector.binance.spot._base import BinanceSpotBase


class SpotMarket:
    """
    Binance Spot Market Data – Implementation Layer.

    All public REST endpoints are exposed with **provider-agnostic names**
    aligned with the Vnstock Unified UI naming convention (mirrors FIX / Bloomberg
    terminology where applicable). The Unified UI facade delegates to these methods
    via the registry.

    Endpoint mapping (method → Binance REST endpoint):
    ────────────────────────────────────────────────────
    ohlcv           → GET /api/v3/uiKlines       (display-optimised candlesticks)
    ohlcv_raw       → GET /api/v3/klines          (raw candlesticks, full fields)
    trades          → GET /api/v3/trades           (mode='raw', default)
                    → GET /api/v3/aggTrades        (mode='aggregate')
    trade_history   → GET /api/v3/historicalTrades (older trades by ID)
    order_book      → GET /api/v3/depth            (L2 Market Depth)
    quote           → GET /api/v3/ticker/24hr      (24-h rolling quote snapshot)
    vwap            → GET /api/v3/avgPrice         (Volume-Weighted Average Price)
    daily_stats     → GET /api/v3/ticker/tradingDay(trading-day session stats)
    last_price      → GET /api/v3/ticker/price     (last traded price)
    rolling_stats   → GET /api/v3/ticker           (rolling-window statistics)
    reference_price → GET /api/v3/referencePrice   (reference / indicative price)
    reference_calc  → GET /api/v3/referencePrice/calculation

    Connector-only (not exposed in Unified UI):
    ────────────────────────────────────────────
    bbo             → GET /api/v3/ticker/bookTicker(best bid / offer)
    """

    def __init__(self, symbol: str):
        self.symbol = symbol

    # ── helpers ───────────────────────────────────────────────────────────

    def _format_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """Convert camelCase → snake_case, coerce timestamps & numerics."""
        if df.empty:
            return df

        mapper = {
            c: ''.join(['_' + x.lower() if x.isupper() else x for x in c]).lstrip('_')
            for c in df.columns
        }
        df.rename(columns=mapper, inplace=True)
        # Deduplicate overlapping names (e.g. 'm' and 'M' both → 'm')
        df = df.loc[:, ~df.columns.duplicated()].copy()

        # Timestamp columns → datetime64[ns] (timezone-naive)
        for col in ("time", "open_time", "close_time", "timestamp"):
            if col in df.columns:
                df[col] = pd.to_datetime(df[col], unit="ms").dt.tz_localize(None)

        non_numeric = {"symbol", "side", "match_type", "id",
                       "time", "open_time", "close_time", "timestamp"}
        for col in df.columns:
            if col not in non_numeric:
                df[col] = pd.to_numeric(df[col], errors="coerce")

        return df

    # ── OHLCV (primary, display-optimised) ────────────────────────────────

    def ohlcv(self, interval: str = "1d", start_time: int = None,
              end_time: int = None, limit: int = 500, mode: str = None,
              **kwargs) -> pd.DataFrame:
        """
        Historical OHLCV candlestick bars.

        Args:
            interval (str): Timeframe – ``1s``, ``1m``–``30m``, ``1h``–``12h``,
                ``1d``, ``3d``, ``1w``, ``1M``.
            limit (int): Number of bars (default 500, max 1000).
            mode (str | None):
                - ``None`` (default) – chart-optimised UIKlines that filters
                  anomalous data. Binance: ``GET /api/v3/uiKlines``.
                - ``'raw'`` – full kline with extra fields (``quote_volume``,
                  ``trades``, ``taker_buy_base_vol``, ``taker_buy_quote_vol``).
                  Binance: ``GET /api/v3/klines``.
        """
        cols_base = [
            "time", "open", "high", "low", "close", "volume",
            "close_time", "quote_volume", "trades",
            "taker_buy_base_vol", "taker_buy_quote_vol", "ignore",
        ]
        params = {"symbol": self.symbol.upper(), "interval": interval, "limit": limit}
        if start_time:
            params["startTime"] = start_time
        if end_time:
            params["endTime"] = end_time

        endpoint = "/api/v3/klines" if mode == "raw" else "/api/v3/uiKlines"
        data = BinanceSpotBase._request(endpoint, params)
        if not data:
            return pd.DataFrame()

        df = pd.DataFrame(data, columns=cols_base)
        df = self._format_columns(df)

        if mode == "raw":
            return df.drop(columns=["ignore"], errors="ignore")
        return df[["time", "open", "high", "low", "close", "volume"]]

    # ── Order Book / Market Depth ─────────────────────────────────────────

    def order_book(self, limit: int = 10, **kwargs) -> pd.DataFrame:
        """
        L2 order book depth – top N bid/ask price levels.

        Binance endpoint: ``GET /api/v3/depth``
        """
        params = {"symbol": self.symbol.upper(), "limit": limit}
        data = BinanceSpotBase._request("/api/v3/depth", params)
        if not data:
            return pd.DataFrame()

        row = {}
        for i, bid in enumerate(data.get("bids", [])[:limit]):
            row[f"bid_price_{i + 1}"] = float(bid[0])
            row[f"bid_vol_{i + 1}"] = float(bid[1])
        for i, ask in enumerate(data.get("asks", [])[:limit]):
            row[f"ask_price_{i + 1}"] = float(ask[0])
            row[f"ask_vol_{i + 1}"] = float(ask[1])

        return pd.DataFrame([row])

    # ── Trades (Time & Sales) ─────────────────────────────────────────────

    def intraday(self, limit: int = 500, mode: str = "raw",
                 start_time: int = None, end_time: int = None, **kwargs) -> pd.DataFrame:
        """
        Tick-by-tick trade tape (Time & Sales).

        Args:
            limit (int): Number of records (default 500, max 1000).
            mode (str):
                - ``'raw'`` (default) – individual fills from ``GET /api/v3/trades``.
                - ``'aggregate'`` – compressed fills aggregated at same price &
                  direction, from ``GET /api/v3/aggTrades``.  Consecutive fills at
                  the same price and side are merged into one record.
            start_time (int): Unix ms – used only with ``mode='aggregate'``.
            end_time (int): Unix ms – used only with ``mode='aggregate'``.

        Returns:
            pd.DataFrame: Schema ``[time, price, volume, side, match_type, id]``
        """
        if mode == "aggregate":
            params = {"symbol": self.symbol.upper(), "limit": limit}
            if start_time:
                params["startTime"] = start_time
            if end_time:
                params["endTime"] = end_time
            data = BinanceSpotBase._request("/api/v3/aggTrades", params)
            if not data:
                return pd.DataFrame()
            df = pd.DataFrame(data)
            rename_map = {"T": "time", "p": "price", "q": "volume", "a": "id"}
            df.rename(columns={k: v for k, v in rename_map.items() if k in df.columns}, inplace=True)
            df = self._format_columns(df)
            if "m" in df.columns:
                df["side"] = df["m"].apply(lambda x: "Sell" if x else "Buy")
            df["match_type"] = "Aggregate"
        else:
            # mode="raw"
            params = {"symbol": self.symbol.upper(), "limit": limit}
            data = BinanceSpotBase._request("/api/v3/trades", params)
            if not data:
                return pd.DataFrame()
            df = pd.DataFrame(data)
            if "qty" in df.columns:
                df.rename(columns={"qty": "volume"}, inplace=True)
            df = self._format_columns(df)
            if "is_buyer_maker" in df.columns:
                df["side"] = df["is_buyer_maker"].apply(lambda x: "Sell" if x else "Buy")
            df["match_type"] = "Normal"

        cols = ["time", "price", "volume", "side", "match_type", "id"]
        return df[[c for c in cols if c in df.columns]]

    # ── Trade History ─────────────────────────────────────────────────────

    def trade_history(self, limit: int = 500, from_id: int = None, **kwargs) -> pd.DataFrame:
        """
        Historical trade look-up (paginate by trade ID for older data).

        Binance endpoint: ``GET /api/v3/historicalTrades``
        """
        params = {"symbol": self.symbol.upper(), "limit": limit}
        if from_id:
            params["fromId"] = from_id
        data = BinanceSpotBase._request("/api/v3/historicalTrades", params)
        if not data:
            return pd.DataFrame()

        df = pd.DataFrame(data)
        if "qty" in df.columns:
            df.rename(columns={"qty": "volume"}, inplace=True)
        df = self._format_columns(df)
        if "is_buyer_maker" in df.columns:
            df["side"] = df["is_buyer_maker"].apply(lambda x: "Sell" if x else "Buy")
        df["match_type"] = "Historical"
        cols = ["time", "price", "volume", "side", "match_type", "id"]
        return df[[c for c in cols if c in df.columns]]

    # ── Quote / 24h Snapshot ──────────────────────────────────────────────

    def quote(self, **kwargs) -> pd.DataFrame:
        """
        24-hour rolling price-change statistics (quote snapshot).

        Binance endpoint: ``GET /api/v3/ticker/24hr``
        """
        params = {"symbol": self.symbol.upper()}
        data = BinanceSpotBase._request("/api/v3/ticker/24hr", params)
        if not data:
            return pd.DataFrame()
        return self._format_columns(pd.DataFrame([data]))

    # ── VWAP ──────────────────────────────────────────────────────────────

    def vwap(self, **kwargs) -> pd.DataFrame:
        """
        Volume-Weighted Average Price over the last N minutes.

        Binance endpoint: ``GET /api/v3/avgPrice``
        """
        params = {"symbol": self.symbol.upper()}
        data = BinanceSpotBase._request("/api/v3/avgPrice", params)
        if not data:
            return pd.DataFrame()
        return self._format_columns(pd.DataFrame([data]))

    # ── Daily Session Stats ───────────────────────────────────────────────

    def daily_stats(self, **kwargs) -> pd.DataFrame:
        """
        Trading-day stats (open, high, low, close, volume for the current day).

        Binance endpoint: ``GET /api/v3/ticker/tradingDay``
        """
        params = {"symbol": self.symbol.upper()}
        data = BinanceSpotBase._request("/api/v3/ticker/tradingDay", params)
        if not data:
            return pd.DataFrame()
        return self._format_columns(pd.DataFrame([data]))

    # ── Last Traded Price (LTP) ───────────────────────────────────────────

    def last_price(self, **kwargs) -> pd.DataFrame:
        """
        Most-recent last traded price – ultra-lightweight single-field response.

        Binance endpoint: ``GET /api/v3/ticker/price``
        """
        params = {"symbol": self.symbol.upper()}
        data = BinanceSpotBase._request("/api/v3/ticker/price", params)
        if not data:
            return pd.DataFrame()
        return self._format_columns(pd.DataFrame([data]))

    # ── Rolling-Window Stats ──────────────────────────────────────────────

    def rolling_stats(self, window_size: str = "1d", **kwargs) -> pd.DataFrame:
        """
        Rolling-window price-change statistics over a custom window.

        Binance endpoint: ``GET /api/v3/ticker``
        """
        params = {"symbol": self.symbol.upper(), "windowSize": window_size}
        data = BinanceSpotBase._request("/api/v3/ticker", params)
        if not data:
            return pd.DataFrame()
        df = pd.DataFrame([data] if isinstance(data, dict) else data)
        return self._format_columns(df)

    # ── Reference / Indicative Price ──────────────────────────────────────

    def reference_price(self, mode: str = "price", **kwargs) -> pd.DataFrame:
        """
        Reference (indicative) price for mark / liquidation calculations.

        Args:
            mode (str):
                - ``'price'`` (default) – reference price only.
                  Binance: ``GET /api/v3/referencePrice``.
                - ``'calc'`` – detailed calculation breakdown.
                  Binance: ``GET /api/v3/referencePrice/calculation``.

        Note: Not all symbols have a reference price; returns empty DataFrame if unavailable.
        """
        endpoint = (
            "/api/v3/referencePrice/calculation"
            if mode == "calc"
            else "/api/v3/referencePrice"
        )
        data = BinanceSpotBase._request(endpoint, {"symbol": self.symbol.upper()})
        if not data:
            return pd.DataFrame()
        return self._format_columns(pd.DataFrame([data]))

    # ── Connector-only: Best Bid / Offer (not in Unified UI) ─────────────

    def bbo(self, **kwargs) -> pd.DataFrame:
        """
        Best Bid / Offer (top-of-book snapshot, single price level).

        This is a connector-only method not exposed in the Unified UI facade,
        because ``order_book(limit=1)`` provides equivalent information with a
        richer schema.  Use this when you need the absolute minimalist payload.

        Binance endpoint: ``GET /api/v3/ticker/bookTicker``
        """
        params = {"symbol": self.symbol.upper()}
        data = BinanceSpotBase._request("/api/v3/ticker/bookTicker", params)
        if not data:
            return pd.DataFrame()
        df = pd.DataFrame([data])
        df.rename(columns={
            "bidPrice": "bid_price_1", "bidQty": "bid_vol_1",
            "askPrice": "ask_price_1", "askQty": "ask_vol_1",
        }, inplace=True)
        return self._format_columns(df)
