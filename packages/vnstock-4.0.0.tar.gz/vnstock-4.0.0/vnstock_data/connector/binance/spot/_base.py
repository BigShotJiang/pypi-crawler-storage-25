import requests
import logging
from tenacity import retry, stop_after_attempt, wait_exponential

logger = logging.getLogger(__name__)

class BinanceSpotBase:
    """
    Base client for interacting with the Binance Spot API.
    Handles basic request execution, error handling, and robust retries via tenacity.
    """
    BASE_URLS = [
        "https://api.binance.com",
        "https://api-gcp.binance.com",
        "https://api1.binance.com",
        "https://api2.binance.com",
        "https://api3.binance.com",
        "https://api4.binance.com"
    ]
    _current_url_index = 0

    @classmethod
    def _get_base_url(cls) -> str:
        return cls.BASE_URLS[cls._current_url_index]

    @classmethod
    def _rotate_url(cls):
        cls._current_url_index = (cls._current_url_index + 1) % len(cls.BASE_URLS)
        logger.warning(f"Rotated Binance base URL to {cls._get_base_url()}")
    
    @classmethod
    @retry(stop=stop_after_attempt(5), wait=wait_exponential(multiplier=1, min=2, max=10), reraise=True)
    def _request(cls, endpoint: str, params: dict = None) -> dict | list:
        """
        Execute a GET request to the given endpoint with rotational domain fallbacks.
        Only retries on 429, 5xx or Network connection failures.
        """
        url = f"{cls._get_base_url()}{endpoint}"
        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            if e.response.status_code in [429, 500, 502, 503, 504]:
                cls._rotate_url()
                logger.warning(f"Rotated Binance URL. Retryable HTTP {e.response.status_code} on {url}")
                raise
            else:
                logger.error(f"Client Error {e.response.status_code} on {url}: {e.response.text}")
                return {}
        except requests.exceptions.RequestException as e:
            cls._rotate_url()
            logger.warning(f"Rotated Binance URL. Network Error on {url}: {str(e)}")
            err_msg = e.response.text if hasattr(e.response, 'text') else str(e)
            logger.error(f"RequestException on {url}: {err_msg}")
            raise
        except Exception as e:
            logger.error(f"Error requesting {url}: {e}")
            raise
