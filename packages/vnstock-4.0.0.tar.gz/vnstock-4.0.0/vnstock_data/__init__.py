# from vnstock_data.explorer.cafef import Trading
# from vnstock_data.explorer.vnd import Listing, Quote, TopStock
# from vnstock_data.explorer.vci import Finance
# from vnstock_data.explorer.spl.commodity import CommodityPrice
# from vnstock_data.explorer.vnd.market import Market
# -----
# from vnstock_data.explorer.vci import Trading
# from vnstock_data.explorer.vds import Quote

__version__ = "3.0.0"

from .api.quote import Quote
from .api.company import Company
from .api.financial import Finance
from .api.listing import Listing
from .api.trading import Trading
from .api.commodity import CommodityPrice
from .api.insight import TopStock
from .explorer.fmarket import Fund
from .enums import IndexGroup

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .ui.reference import Reference
    from .ui.market import Market
    from .ui.insights import Insights
    from .ui.fundamental import Fundamental
    from .ui.macro import Macro
    from .ui.analytics import Analytics
    from .ui.helper import show_api, show_doc

__all__ = [
    "Quote",
    "Company", 
    "Finance", 
    "Listing", 
    "Trading", 
    "CommodityPrice", 
    "TopStock", 
    "Fund",
    "Reference",
    "Market",
    "Insights",
    "Fundamental",
    "Macro",
    "Analytics",
    "show_api",
    "show_doc",
]

def __getattr__(name: str) -> Any:
    """
    Lazy load UI modules at root level using PEP 562. 
    Allows IDE autocomplete and type hints to work correctly.
    """
    if name == "Reference":
        from .ui.reference import Reference as _Reference
        return _Reference
    elif name == "Market":
        from .ui.market import Market as _Market
        return _Market
    elif name == "Insights":
        from .ui.insights import Insights as _Insights
        return _Insights
    elif name == "Fundamental":
        from .ui.fundamental import Fundamental as _Fundamental
        return _Fundamental
    elif name == "Macro":
        from .ui.macro import Macro as _Macro
        return _Macro
    elif name == "Analytics":
        from .ui.analytics import Analytics as _Analytics
        return _Analytics
    elif name == "show_api":
        from .ui.helper import show_api as _show_api
        return _show_api
    elif name == "show_doc":
        from .ui.helper import show_doc as _show_doc
        return _show_doc
    
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

# Display smart startup messages
try:
    from .core.utils.startup import display_startup_messages
    display_startup_messages()
except Exception:
    pass

