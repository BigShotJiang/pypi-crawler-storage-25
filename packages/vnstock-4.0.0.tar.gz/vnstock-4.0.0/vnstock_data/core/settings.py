"""
Configuration management for vnstock_data.

This module re-exports vnstock's core settings to provide a unified
configuration interface for both vnstock and vnstock_data users.

vnstock_data users can import configuration from here, which references
vnstock's professional configuration management system.
"""

# Re-export vnstock's configuration classes and functions
from vnstock.core.settings import (
    APIKeyConfig,
    NetworkConfig,
    CacheConfig,
    VnstockConfig,
    get_config,
    set_config,
    reset_config,
    get_api_key,
    set_api_key,
    get_timeout,
    set_timeout,
    is_debug_mode,
    set_debug_mode,
)

# Alias for convenience (vnstock_data specific naming)
VnstockDataConfig = VnstockConfig

__all__ = [
    "APIKeyConfig",
    "NetworkConfig",
    "CacheConfig",
    "VnstockConfig",
    "VnstockDataConfig",  # Alias for vnstock_data users
    "get_config",
    "set_config",
    "reset_config",
    "get_api_key",
    "set_api_key",
    "get_timeout",
    "set_timeout",
    "is_debug_mode",
    "set_debug_mode",
]
