"""
Configuration for Startup Messages.
Messages defined here will be displayed to users when they import vnstock_data,
based on the constraints (max_displays, expires_at).
"""

from typing import List, Dict, Any

# Define the active startup messages
STARTUP_MESSAGES: List[Dict[str, Any]] = [
    {
        "id": "helper_tools_v1",
        "text": "\033[93m💡 Tip: vnstock_data vừa ra mắt 2 hàm tiện ích: `show_api(layer)` để hiển thị sơ đồ các hàm có sẵn và `show_doc(method)` để đọc nhanh tài liệu. (from vnstock_data import show_api, show_doc)\033[0m",
        "max_displays": 3,
        "expires_at": "2026-03-31T00:00:00"  # Format: ISO 8601 (YYYY-MM-DDTHH:MM:SS)
    }
]
