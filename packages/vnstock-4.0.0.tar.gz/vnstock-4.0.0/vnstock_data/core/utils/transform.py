import pytz
import pandas as pd
from bs4 import BeautifulSoup
from typing import Dict, Any, List, Optional, Union
from datetime import datetime, timedelta, time
from vnstock.core.utils.parser import localize_timestamp
from vnstock.core.utils.transform import get_trading_date
from vnstock.core.utils.interval import normalize_interval
from vnstock.core.types import TimeFrame

def generate_period(df):
    required_columns = ['yearReport', 'lengthReport', 'report_period']
    for col in required_columns:
        if col not in df.columns:
            raise ValueError(f"Thiếu cột {col} trong df")
    
    df.loc[:, 'period'] = df.apply(lambda x: str(x['yearReport']) if x['report_period'] == 'year' else str(x['yearReport']) + "-Q" + str(x['lengthReport']), axis=1)
    return df

def remove_pattern_columns(df: pd.DataFrame, patterns: List[str]) -> pd.DataFrame:
    """
    Remove columns from a DataFrame that contains any of the given patterns in their names
    
    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame
    patterns : List[str]
        List of patterns to remove
    
    Returns
    -------
    pd.DataFrame
        DataFrame with columns that match the given patterns removed
    
    Examples
    --------
    >>> df = pd.DataFrame({'FooBar': [1, 2], 'BarFoo': [3, 4]})
    >>> remove_pattern_columns(df, ['foo'])
       BarFoo
    0       3
    1       4
    """
    columns_to_remove = [col for col in df.columns if any(pattern in col.lower() for pattern in patterns)]
    df.drop(columns=columns_to_remove, inplace=True)
    return df


def clean_numeric_string(s: Any) -> Any:
    """
    Loại bỏ dấu phân nhóm (',' hoặc NBSP), chuẩn hoá dấu thập phân về '.'
    """
    if not isinstance(s, str):
        return s
    s = s.replace('\u00A0', '').replace(',', '')
    # Nếu chỉ có một dấu ',' (nghĩa decimal), chuyển thành '.'
    if s.count('.') == 0 and s.count(',') == 1:
        s = s.replace(',', '.')
    return s.strip()

def process_match_types(df, asset_type, source):
    """
    Process match_type labels with special handling for stock ATO/ATC transactions.
    
    For VCI:
        - Replace 'b' with 'Buy' and 's' with 'Sell'.
        - Missing values are represented by the string 'unknown'.
    For MAS:
        - Replace 'BUY' with 'Buy' and 'SELL' with 'Sell'.
        - Fill in NaN values with 'unknown'.
    For TCBS:
        - Replace 'BU' with 'Buy' and 'SD' with 'Sell'.
        - Missing values are assumed to be an empty string.
    For KBS:
        - Replace 'B' with 'Buy' and 'S' with 'Sell'.
        - Missing values are assumed to be an empty string.
    
    Once basic replacements are done, if the asset type is 'stock' and missing
    match_type values are present, the code will mark the ATO (at the earliest
    morning transaction in the 9:13–9:17 window) and ATC (at the latest afternoon
    transaction in the 14:43–14:47 window) within each trading day.
    
    Parameters:
        df (DataFrame): The input DataFrame with a 'time' and 'match_type' column.
        asset_type (str): The asset type (for example, 'stock').
        source (str): The data source (e.g., 'VCI', 'MAS', 'TCBS', or 'KBS').
        
    Returns:
        DataFrame: The modified DataFrame with updated match_type values.
    """
    # --- Basic replacement and normalization ---
    if source == 'VCI':
        df['match_type'] = df['match_type'].replace({'b': 'Buy', 's': 'Sell'})
    elif source == 'MAS':
        df['match_type'] = df['match_type'].replace({'BUY': 'Buy', 'SELL': 'Sell'})
        df['match_type'] = df['match_type'].fillna('unknown')
    elif source == 'TCBS':
        df['match_type'] = df['match_type'].replace({'BU': 'Buy', 'SD': 'Sell'})
    elif source == 'KBS':
        df['match_type'] = df['match_type'].replace({'B': 'Buy', 'S': 'Sell'})
    
    # Determine the unknown value to check for based on the source
    unknown_val = 'unknown' if source in ['VCI', 'MAS'] else ''
    
    # --- Process ATO/ATC labeling for stock assets ---
    # Only run ATO/ATC logic if match_type contains missing values
    if asset_type == 'stock' and (df['match_type'].eq(unknown_val).any() or df['match_type'].eq('').any()):
        # Sort by time and add a temporary date column to group by trading day
        df = df.sort_values('time')
        df['date'] = df['time'].dt.date
        
        # Group by date and process each day
        def process_day(day_df):
            # Identify rows with missing match_type
            unknown_df = day_df[day_df['match_type'] == unknown_val]
            if unknown_df.empty:
                return day_df

            # Morning session: filter for transactions between 9:13 and 9:17
            morning_df = unknown_df[
                (unknown_df['time'].dt.hour == 9) &
                (unknown_df['time'].dt.minute.between(13, 17))
            ]
            if not morning_df.empty:
                # Set the earliest transaction time as ATO
                min_idx = morning_df['time'].idxmin()
                day_df.loc[min_idx, 'match_type'] = 'ATO'
            
            # Afternoon session: filter for transactions between 14:43 and 14:47
            afternoon_df = unknown_df[
                (unknown_df['time'].dt.hour == 14) &
                (unknown_df['time'].dt.minute.between(43, 47))
            ]
            if not afternoon_df.empty:
                # Set the latest transaction time as ATC
                max_idx = afternoon_df['time'].idxmax()
                day_df.loc[max_idx, 'match_type'] = 'ATC'
            
            return day_df
        
        # Apply the processing function to each trading day
        try:
            df = df.groupby('date', group_keys=False).apply(process_day, include_groups=False)
        except TypeError:
            df = df.groupby('date', group_keys=False).apply(process_day)
        # Drop date column if it exists
        if 'date' in df.columns:
            df.drop(columns=['date'], inplace=True)
    
    return df

def ohlc_to_df(data: Dict[str, Any], column_map: Dict[str, str], dtype_map: Dict[str, str],
              asset_type: str, symbol: str, source: str, interval: str = "1D",
              floating: int = 2, resample_map: Optional[Dict[str, str]] = None) -> pd.DataFrame:
    """
    Convert OHLC data from any source to standardized DataFrame format.
    
    Supports all 14 intervals: 1m, 5m, 15m, 30m, 1H, 4h, 1D, 1W, 1M
    """
    if not data:
        raise ValueError("Input data is empty or not provided.")
    
    # Normalize interval to TimeFrame enum
    try:
        timeframe = normalize_interval(interval)
    except ValueError as e:
        raise ValueError(f"Invalid interval '{interval}': {str(e)}")
        
    # Handle different data source formats
    if source == 'TCBS':
        # TCBS data is already a list of dictionaries
        df = pd.DataFrame(data)
        # Apply column mapping directly through rename
        df.rename(columns=column_map, inplace=True)
    else:
        # VCI and other sources
        # Select and rename columns using dictionary comprehension
        columns_of_interest = {key: column_map[key] for key in column_map.keys() if key in data}
        df = pd.DataFrame(data)[columns_of_interest.keys()].rename(columns=column_map)
    
    # Ensure all required columns exist
    required_columns = ['time', 'open', 'high', 'low', 'close', 'volume']
    missing_columns = [col for col in required_columns if col not in df.columns]
    if missing_columns:
        cols_list = df.columns.tolist()
        raise ValueError(f"Missing required columns: {missing_columns}. Available columns: {cols_list}")
    
    # Standard column order
    df = df[['time', 'open', 'high', 'low', 'close', 'volume']]
    
    # Time conversion - handle different formats based on source
    if 'time' in df.columns:
        if source == 'VCI':
            # VCI uses integer timestamps (seconds)
            df['time'] = pd.to_datetime(df['time'].astype(int), unit='s').dt.tz_localize('UTC')
            df['time'] = df['time'].dt.tz_convert('Asia/Ho_Chi_Minh')
        elif source == 'MAS':
            # MAS returns the time value in seconds (with fractional seconds)
            df['time'] = pd.to_datetime(df['time'].astype(float), unit='s') \
                            .dt.tz_localize('UTC') \
                            .dt.tz_convert('Asia/Ho_Chi_Minh')
        else:
            # TCBS and others might use string formats
            df['time'] = pd.to_datetime(df['time'], errors='coerce')

    
    # Price scaling for non-index/derivative assets
    if asset_type not in ["index", "derivative"]:
        df[["open", "high", "low", "close"]] = df[["open", "high", "low", "close"]].div(1000)
    
    # Round price columns
    df[["open", "high", "low", "close"]] = df[["open", "high", "low", "close"]].round(floating)
    
    # Resample if needed - support all 14 intervals
    # Build resample map for all intervals if not provided
    if resample_map is None:
        resample_map = _get_default_resample_map()
    
    # Check if resampling is needed (not a base interval)
    base_intervals = [TimeFrame.MINUTE_1, TimeFrame.HOUR_1, TimeFrame.DAY_1]
    if timeframe not in base_intervals and resample_map:
        if timeframe.value in resample_map:
            df = df.set_index('time').resample(resample_map[timeframe.value]).agg({
                'open': 'first',
                'high': 'max',
                'low': 'min',
                'close': 'last',
                'volume': 'sum'
            })\
            .dropna(subset=['open', 'close'])\
            .reset_index()
    
    # Apply data types
    for col, dtype in dtype_map.items():
        if col in df.columns:
            if dtype == "datetime64[ns]" and hasattr(df[col], 'dt') and df[col].dt.tz is not None:
                df[col] = df[col].dt.tz_localize(None)  # Remove timezone info
                if timeframe in [TimeFrame.DAY_1, TimeFrame.DAILY]:
                    df[col] = df[col].dt.date
            df[col] = df[col].astype(dtype)
    
    # Add metadata
    df.name = symbol
    df.category = asset_type
    df.source = source
    
    return df


def _get_default_resample_map() -> Dict[str, str]:
    """
    Get default resample frequency mapping for all 14 intervals.
    
    Returns:
        dict: Mapping of TimeFrame value to pandas resample frequency
    """
    return {
        # Minute intervals
        '1m': '1min',
        '5m': '5min',
        '15m': '15min',
        '30m': '30min',
        # Hour intervals
        '1H': '1H',
        '4h': '4H',
        # Day/Week/Month intervals
        '1D': '1D',
        '1W': '1W',
        '1M': '1MS',  # Month start
    }

def intraday_to_df(
    data: List[Dict[str, Any]],
    column_map: Dict[str, str],
    dtype_map: Dict[str, str],
    symbol: str,
    asset_type: str,
    source: str
) -> pd.DataFrame:
    """
    Convert intraday trading data to standardized DataFrame format,
    với:
      - Tiền xử lý chuỗi số cho price/volume
      - Map scale dựa trên source (không hardcode /1000)
      - Kiểm soát NaN, rounding volume an toàn
      - Xử lý time, match_type như trước
    """
    # --- Early exit ---
    if not data:
        empty_df = pd.DataFrame(columns=list(column_map.values()))
        empty_df.attrs['symbol'] = symbol
        empty_df.category = asset_type
        empty_df.source = source
        return empty_df

    df = pd.DataFrame(data)

    # --- Chọn & rename columns ---
    available = [c for c in column_map if c in df.columns]
    if not available:
        expected = list(column_map)
        got = df.columns.tolist()
        raise ValueError(f"Expected columns {expected} not found, got {got}")
    df = df[available].rename(columns={k: column_map[k] for k in available})

    # --- Làm sạch & chuyển numeric ---
    for col in ('price', 'volume'):
        if col in df.columns:
            # Tiền xử lý chuỗi
            df[col] = df[col].map(clean_numeric_string)
            # Chuyển sang float, lỗi thành NaN
            df[col] = pd.to_numeric(df[col], errors='coerce')
            n_bad = df[col].isna().sum()
            if n_bad:
                msg = "[Warning] " + str(n_bad) + " giá trị ở '" + col + "' không parse được, chuyển thành NaN"
                print(msg)

    # --- Scale price theo source ---
    scale_map = {'VCI': 1000, 'MAS': 1000}
    scale = scale_map.get(source, 1)
    if 'price' in df.columns:
        df['price'] = df['price'] / scale

    # --- Volume: round & cast int ---
    if 'volume' in df.columns:
        vol = df['volume'].fillna(0)
        # Kiểm tra nếu có decimal
        mask = (vol % 1 != 0)
        if mask.any():
            bad_count = int(mask.sum())
            msg = f"[Info] {bad_count} giá trị volume có decimal, sẽ làm tròn"
            print(msg)
        df['volume'] = vol.round().astype(int)

    # --- Xử lý cột time như trước ---
    if 'time' in df.columns:
        trading_date = get_trading_date()

        if source == 'VCI':
            df['time'] = localize_timestamp(df['time'].astype(int), unit='s')
        elif source == 'MAS':
            df['time'] = localize_timestamp(df['time'].astype(int), unit='ms')
            df['time'] = df['time'].dt.floor('s')
        else:  # TCBS
            sample = str(df['time'].iloc[0]) if not df.empty else ''
            if ':' in sample and len(sample) <= 8:
                df['time'] = df['time'].apply(
                    lambda x: datetime.combine(
                        trading_date,
                        datetime.strptime(x, '%H:%M:%S').time()
                    ) if isinstance(x, str) and ':' in x else pd.NaT
                )
                df['time'] = localize_timestamp(df['time'], return_string=False)
            else:
                df['time'] = pd.to_datetime(df['time'], format='%Y-%m-%d %H:%M:%S', errors='coerce')
                if df['time'].dt.tz is None:
                    df['time'] = localize_timestamp(df['time'], return_string=False)

    # --- Process match types như bạn đã định nghĩa ---
    if 'match_type' in df.columns:
        df = process_match_types(df, asset_type, source)

    # --- Sort, reset index & apply dtype ---
    if 'time' in df.columns:
        df = df.sort_values('time')
    df = df.reset_index(drop=True)

    # Áp dtype_map (không tính time)
    type_map = {k: v for k, v in dtype_map.items() if k in df.columns and k != 'time'}
    if type_map:
        df = df.astype(type_map)

    # --- Metadata ---
    df.attrs['symbol'] = symbol
    df.category = asset_type
    df.source = source

    return df