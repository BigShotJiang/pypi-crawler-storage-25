"""
Proxy data structures and utilities for vnstock_data.
"""

from dataclasses import dataclass, field
from typing import Optional
from datetime import datetime


@dataclass
class Proxy:
    """Proxy information with metadata."""
    
    protocol: str  # HTTP, HTTPS, SOCKS5
    ip: str
    port: int
    country: Optional[str] = None
    speed: Optional[float] = None  # milliseconds
    last_checked: Optional[datetime] = None
    
    def __str__(self) -> str:
        """String representation of proxy."""
        return f"{self.protocol}://{self.ip}:{self.port}"
    
    def __repr__(self) -> str:
        """Detailed representation of proxy."""
        return (
            f"Proxy(protocol={self.protocol}, ip={self.ip}, port={self.port}, "
            f"country={self.country}, speed={self.speed}, last_checked={self.last_checked})"
        )
    
    def is_valid(self) -> bool:
        """
        Check if proxy is still valid.
        
        A proxy is considered valid if it was checked within the last 24 hours.
        If never checked, it's considered valid.
        
        Returns:
            bool: True if proxy is valid, False otherwise
        """
        if self.last_checked is None:
            return True
        
        time_diff = datetime.now() - self.last_checked
        return time_diff.days < 1
    
    def to_dict(self) -> dict:
        """Convert proxy to dictionary."""
        return {
            "protocol": self.protocol,
            "ip": self.ip,
            "port": self.port,
            "country": self.country,
            "speed": self.speed,
            "last_checked": self.last_checked.isoformat() if self.last_checked else None,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "Proxy":
        """Create proxy from dictionary."""
        last_checked = data.get("last_checked")
        if last_checked and isinstance(last_checked, str):
            last_checked = datetime.fromisoformat(last_checked)
        
        return cls(
            protocol=data["protocol"],
            ip=data["ip"],
            port=data["port"],
            country=data.get("country"),
            speed=data.get("speed"),
            last_checked=last_checked,
        )
