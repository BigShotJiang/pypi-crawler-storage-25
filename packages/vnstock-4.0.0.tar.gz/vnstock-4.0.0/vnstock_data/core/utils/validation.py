from datetime import datetime
from typing import Optional
import logging

# Try to import vnstock logger, fallback to standard logging
try:
    from vnstock.core.utils.logger import get_logger
except ImportError:
    # Fallback: create logger using stdlib if vnstock logger not available
    def get_logger(name: str) -> logging.Logger:
        return logging.getLogger(name)

from vnstock_data.core.types import (
    DataCategory,
    DataSource,
    ProviderType,
    MarketType,
    ExchangeType,
    SubscriptionTier,
    DataQuality,
    UpdateFrequency,
    CacheStrategy,
)

logger = get_logger(__name__)


def validate_date(date_str: str) -> bool:
    """
    Validate date string format in the format YYYY-mm-dd.
    
    Args:
        date_str: Date string to validate
    
    Returns:
        bool: True if valid, False otherwise
    """
    try:
        datetime.strptime(date_str, '%Y-%m-%d')
        return True
    except ValueError:
        logger.error(f"Invalid date format: {date_str}. Please use the format YYYY-mm-dd.")
        return False


def validate_data_category(category: str) -> Optional[DataCategory]:
    """
    Validate and normalize data category.
    
    Args:
        category: Category string to validate
    
    Returns:
        Optional[DataCategory]: Validated category or None if invalid
    """
    try:
        return DataCategory(category.lower())
    except ValueError:
        options = [c.value for c in DataCategory]
        logger.error(f"Invalid data category: {category}. Valid options: {options}")
        return None


def validate_provider_type(provider_type: str) -> Optional[ProviderType]:
    """
    Validate and normalize provider type.
    
    Args:
        provider_type: Provider type string to validate
    
    Returns:
        Optional[ProviderType]: Validated type or None if invalid
    """
    try:
        return ProviderType(provider_type.lower())
    except ValueError:
        options = [p.value for p in ProviderType]
        logger.error(f"Invalid provider type: {provider_type}. Valid options: {options}")
        return None


def validate_market_type(market_type: str) -> Optional[MarketType]:
    """
    Validate and normalize market type.
    
    Args:
        market_type: Market type string to validate
    
    Returns:
        Optional[MarketType]: Validated type or None if invalid
    """
    try:
        return MarketType(market_type.lower())
    except ValueError:
        options = [m.value for m in MarketType]
        logger.error(f"Invalid market type: {market_type}. Valid options: {options}")
        return None


def validate_exchange_type(exchange_type: str) -> Optional[ExchangeType]:
    """
    Validate and normalize exchange type.
    
    Args:
        exchange_type: Exchange type string to validate
    
    Returns:
        Optional[ExchangeType]: Validated type or None if invalid
    """
    try:
        return ExchangeType(exchange_type.lower())
    except ValueError:
        options = [e.value for e in ExchangeType]
        logger.error(f"Invalid exchange type: {exchange_type}. Valid options: {options}")
        return None


def validate_subscription_tier(tier: str) -> Optional[SubscriptionTier]:
    """
    Validate and normalize subscription tier.
    
    Args:
        tier: Tier string to validate
    
    Returns:
        Optional[SubscriptionTier]: Validated tier or None if invalid
    """
    try:
        return SubscriptionTier(tier.lower())
    except ValueError:
        options = [t.value for t in SubscriptionTier]
        logger.error(f"Invalid subscription tier: {tier}. Valid options: {options}")
        return None


def validate_data_source(source: str) -> Optional[DataSource]:
    """
    Validate and normalize data source.
    
    Args:
        source: Source string to validate
    
    Returns:
        Optional[DataSource]: Validated source or None if invalid
    """
    try:
        return DataSource(source.lower())
    except ValueError:
        options = [s.value for s in DataSource]
        logger.error(f"Invalid data source: {source}. Valid options: {options}")
        return None


def check_subscription_access(tier: SubscriptionTier, source: DataSource, category: DataCategory) -> tuple[bool, str]:
    """
    Check if subscription tier can access a specific data source and category.
    
    Args:
        tier: User's subscription tier
        source: Data source to access
        category: Data category to access
    
    Returns:
        tuple[bool, str]: (can_access, error_message)
    """
    from vnstock_data.core.types import SubscriptionConfig
    
    # Check data source access
    if not SubscriptionConfig.can_access_source(tier, source):
        return False, f"Subscription tier {tier.value} cannot access data source {source.value}. Required: Bronze or higher."
    
    # Check data category access
    if not SubscriptionConfig.can_access_category(tier, category):
        return False, f"Subscription tier {tier.value} cannot access data category {category.value}. Required: Bronze or higher."
    
    return True, "Access granted"


def validate_data_quality(quality: str) -> Optional[DataQuality]:
    """
    Validate and normalize data quality level.
    
    Args:
        quality: Quality string to validate
    
    Returns:
        Optional[DataQuality]: Validated quality or None if invalid
    """
    try:
        return DataQuality(quality.lower())
    except ValueError:
        options = [q.value for q in DataQuality]
        logger.error(f"Invalid data quality: {quality}. Valid options: {options}")
        return None


def validate_update_frequency(frequency: str) -> Optional[UpdateFrequency]:
    """
    Validate and normalize update frequency.
    
    Args:
        frequency: Frequency string to validate
    
    Returns:
        Optional[UpdateFrequency]: Validated frequency or None if invalid
    """
    try:
        return UpdateFrequency(frequency.lower())
    except ValueError:
        options = [f.value for f in UpdateFrequency]
        logger.error(f"Invalid update frequency: {frequency}. Valid options: {options}")
        return None


def validate_cache_strategy(strategy: str) -> Optional[CacheStrategy]:
    """
    Validate and normalize cache strategy.
    
    Args:
        strategy: Strategy string to validate
    
    Returns:
        Optional[CacheStrategy]: Validated strategy or None if invalid
    """
    try:
        return CacheStrategy(strategy.lower())
    except ValueError:
        options = [s.value for s in CacheStrategy]
        logger.error(f"Invalid cache strategy: {strategy}. Valid options: {options}")
        return None
