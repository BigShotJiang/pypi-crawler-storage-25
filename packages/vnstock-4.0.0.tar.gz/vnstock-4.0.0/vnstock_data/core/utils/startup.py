"""
Utility module for managing and displaying startup messages via logging.
Tracks message display counts using a local JSON state file.

To suppress startup messages, configure logging in your code:
    import logging
    logging.getLogger('vnstock_data.core.utils.startup').setLevel(logging.WARNING)

Or set environment variable:
    export VNSTOCK_STARTUP_LOG_LEVEL=WARNING
"""

import os
import json
import logging
import datetime
from pathlib import Path

from vnstock_data.core.config.messages import STARTUP_MESSAGES

logger = logging.getLogger(__name__)

def _get_state_file_path() -> Path:
    """Get the path to the local state file for tracking startup messages."""
    home_dir = Path.home()
    vnstock_dir = home_dir / ".vnstock"
    
    # Create directory if it doesn't exist
    if not vnstock_dir.exists():
        try:
            vnstock_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            # Silently fail if no write permission to home directory
            pass
            
    return vnstock_dir / "startup_state.json"

def _load_state() -> dict:
    """Load the message display state from the local JSON file."""
    state_file = _get_state_file_path()
    try:
        if state_file.exists():
            with open(state_file, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return {}

def _save_state(state: dict) -> None:
    """Save the message display state to the local JSON file."""
    state_file = _get_state_file_path()
    try:
        # Check if directory exists, if not, try to create it again
        if not state_file.parent.exists():
            state_file.parent.mkdir(parents=True, exist_ok=True)
            
        with open(state_file, 'w', encoding='utf-8') as f:
            json.dump(state, f)
    except Exception:
        pass

def display_startup_messages() -> None:
    """
    Check and display active startup messages based on configured constraints.
    Updates the display count in the local state file.
    """
    state_updated = False
    state = _load_state()
    current_time = datetime.datetime.now()

    for msg in STARTUP_MESSAGES:
        msg_id = msg.get("id")
        text = msg.get("text", "")
        max_displays = msg.get("max_displays")
        expires_at_str = msg.get("expires_at")

        if not msg_id or not text:
            continue

        # Check expiration date
        if expires_at_str:
            try:
                expires_at = datetime.datetime.fromisoformat(expires_at_str)
                if current_time > expires_at:
                    continue  # Message has expired
            except ValueError:
                pass # Invalid date format, ignore expiration

        # Check display count
        display_count = state.get(msg_id, 0)
        if max_displays is not None and display_count >= max_displays:
            continue  # Max displays reached

        # Display the message
        logger.info(text)

        # Update state
        state[msg_id] = display_count + 1
        state_updated = True

    if state_updated:
        _save_state(state)
