import random
from vnstock.core.utils.user_agent import HEADERS_MAPPING_SOURCE, DEFAULT_HEADERS
from vnstock_data.core.utils.browser_profiles import USER_AGENTS

VDS_HEADERS = {
  'Accept': 'application/json, text/javascript, */*; q=0.01',
  'Accept-Language': 'en-US,en;q=0.9',
  'Connection': 'keep-alive',
  'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
  'Sec-Fetch-Dest': 'empty',
  'Sec-Fetch-Mode': 'cors',
  'Sec-Fetch-Site': 'same-origin',
  'X-Requested-With': 'XMLHttpRequest',
  'sec-ch-ua-mobile': '?0',
  'sec-ch-ua-platform': '"Windows"'
}

# Add headers mapping for VDSC
HEADERS_MAPPING_SOURCE['VND'] = {'Referer': 'https://mkw.vndirect.com.vn', 'Origin': 'https://mkw.vndirect.com.vn'}
HEADERS_MAPPING_SOURCE['VDS'] = {'Referer': 'https://livedragon.vdsc.com.vn/general/intradayBoard.rv', 'Origin': 'https://livedragon.vdsc.com.vn'}
HEADERS_MAPPING_SOURCE['FIALDA'] = {'Referer': 'https://fwt.fialda.com/', 'Origin': 'https://fwt.fialda.com'}
HEADERS_MAPPING_SOURCE['FIINTRADE'] = {'Referer': 'https://fiintrade.vn', 'Origin': 'https://fiintrade.vn/'}
HEADERS_MAPPING_SOURCE['FIDT'] = {'Referer': 'https://portal.fidt.vn', 'Origin': 'https://portal.fidt.vn/'}
HEADERS_MAPPING_SOURCE['CAFEF'] = {'Referer': 'https://s.cafef.vn/lich-su-giao-dich-vnindex-3.chn', 'Origin': 'https://s.cafef.vn/lich-su-giao-dich-vnindex-3.chn'}
HEADERS_MAPPING_SOURCE['MAS'] = {'Referer': 'https://masboard.masvn.com', 'Origin': 'https://masboard.masvn.com'}
HEADERS_MAPPING_SOURCE['MBK'] = {'Referer': 'https://data.maybanktrade.com.vn', 'Origin': 'https://data.maybanktrade.com.vn'}
HEADERS_MAPPING_SOURCE['TVS'] = {'Referer': 'https://ifin.tvsi.com.vn/', 'Origin': 'https://ifin.tvsi.com.vn/'}
HEADERS_MAPPING_SOURCE['KBS'] = {'Referer': 'https://kbbuddywts.kbsec.com.vn/6d054136-b880-4c8b-887b-90311120d1c4', 'Origin': 'https://kbbuddywts.kbsec.com.vn'}
HEADERS_MAPPING_SOURCE['DUKASCOPY'] = {'Referer': 'https://widgets.dukascopy.com/en/historical-data-export', 'Origin': 'https://widgets.dukascopy.com'}
HEADERS_MAPPING_SOURCE['FXSB'] = {'Referer': 'https://data.forexsb.com/data-app', 'Origin': 'https://data.forexsb.com'}
HEADERS_MAPPING_SOURCE['VCI'] = {'Referer': 'https://trading.vietcap.com.vn/', 'Origin': 'https://trading.vietcap.com.vn'}

BROWSER_PROFILES = {
    "chrome": {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    },
    "safari": {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_2_1) AppleWebKit/605.1.15 Version/16.3 Safari/605.1.15",
    },
    "coccoc": {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:110.0) Gecko/20100101 Firefox/110.0 CocCocBrowser/123.0",
    },
    "firefox": {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0",
    },
    "brave": {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Brave/120.0.0.0 Safari/537.36",
    },
    "vivaldi": {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Vivaldi/6.2.3105.58 Safari/537.36",
    },
}

def get_headers(
    data_source: str = 'SSI',
    random_agent: bool = True,
    browser: str = 'chrome',
    platform: str = 'windows'
) -> dict:
    """
    Generate browser-like headers with optional referer/origin and realistic User-Agent.

    Args:
        data_source (str): Predefined data source (e.g., 'SSI', 'VND').
        random_agent (bool): Whether to use a random browser/platform User-Agent.
        browser (str): Browser name to simulate if not random.
        platform (str): Platform name to simulate if not random.

    Returns:
        dict: HTTP headers with realistic settings.
    """
    ref_origin = HEADERS_MAPPING_SOURCE.get(data_source.upper(), {})
    referer = ref_origin.get("Referer", "")
    origin = ref_origin.get("Origin", "")

    # Determine browser/platform
    if random_agent:
        browser = random.choice(list(USER_AGENTS.keys()))
        platform = random.choice(list(USER_AGENTS[browser].keys()))

    ua = USER_AGENTS.get(browser.lower(), {}).get(platform.lower())

    if not ua:
        # Fallback to first available platform under chrome or first browser available
        ua = USER_AGENTS.get("chrome", {}).get("windows")
        if not ua:
            # As a last resort, pick any user agent
            for b in USER_AGENTS.values():
                if isinstance(b, dict):
                    ua = next(iter(b.values()))
                    break

    headers = DEFAULT_HEADERS.copy()
    headers["User-Agent"] = ua
    if referer:
        headers["Referer"] = referer
    if origin:
        headers["Origin"] = origin
    return headers