"""
Các tiện ích chung cho vnstock_data package.

Module này re-export các utilities có sẵn trong vnstock_data.core.utils 
để dễ dàng import và sử dụng.
"""

# Import từ các module utils của vnstock_data
from .validation import *
from .parser import *
from .transform import *
from .client import *
from .user_agent import *

# Các hàm và class chính được export
__all__ = [
    # validation
    'validate_date',
    'validate_date_input',
    
    # parser
    'camel_to_snake',
    'get_asset_type',
    'vn_to_snake_case',
    'filter_columns_by_language',
    'days_between',
    
    # transform
    'generate_period',
    'remove_pattern_columns',
    'ohlc_to_df',
    'intraday_to_df',
    'reorder_cols',
    
    # client
    'send_request',
    'ProxyConfig',
    
    # user_agent
    'get_headers',
]
