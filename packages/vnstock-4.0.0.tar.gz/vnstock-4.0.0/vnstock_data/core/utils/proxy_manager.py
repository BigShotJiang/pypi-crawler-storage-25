"""
Proxy manager for vnstock_data.

Provides functionality to fetch, test, and manage proxies with speed tracking
and intelligent selection strategies.
"""

import requests
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum
from vnstock.core.utils.logger import get_logger

from .proxy import Proxy

logger = get_logger(__name__)


class ProxyManager:
    """
    Manages proxy fetching, testing, and selection.
    
    Features:
    - Fetch proxies from proxyscrape API
    - Test proxy connectivity and speed
    - Track proxy metadata (speed, last_checked, country)
    - Select proxies based on different strategies
    - Maintain proxy cache
    """
    
    # proxyscrape API endpoint
    PROXYSCRAPE_API = "https://api.proxyscrape.com/v2/"
    
    def __init__(self, timeout: int = 5):
        """
        Initialize ProxyManager.
        
        Args:
            timeout: Request timeout in seconds (default: 5)
        """
        self.timeout = timeout
        self.proxy_cache: Dict[str, Proxy] = {}
        self.last_fetch: Optional[datetime] = None
    
    def fetch_proxies(
        self,
        limit: int = 10,
        protocol: str = "http",
        ssl: str = "all",
        anonymity: str = "all",
        country: Optional[str] = None,
    ) -> List[Proxy]:
        """
        Fetch proxies from proxyscrape API.
        
        Args:
            limit: Number of proxies to fetch (default: 10)
            protocol: Protocol type - http, socks4, socks5 (default: http)
            ssl: SSL support - yes, no, all (default: all)
            anonymity: Anonymity level - elite, anonymous, transparent, all (default: all)
            country: Country code filter (optional)
        
        Returns:
            List[Proxy]: List of fetched proxies
        
        Raises:
            requests.RequestException: If API request fails
        """
        try:
            params = {
                "request": "getproxies",
                "format": "json",
                "protocol": protocol,
                "ssl": ssl,
                "anonymity": anonymity,
                "limit": limit,
                "simplified": "true",
            }
            
            if country:
                params["country"] = country
            
            logger.info(f"Fetching {limit} proxies from proxyscrape API...")
            response = requests.get(
                self.PROXYSCRAPE_API,
                params=params,
                timeout=self.timeout
            )
            response.raise_for_status()
            
            data = response.json()
            proxies = []
            
            if data.get("proxies"):
                for proxy_data in data["proxies"]:
                    proxy = Proxy(
                        protocol=protocol.upper(),
                        ip=proxy_data.get("ip"),
                        port=int(proxy_data.get("port", 0)),
                        country=proxy_data.get("country"),
                        last_checked=datetime.now(),
                    )
                    proxies.append(proxy)
                    self.proxy_cache[str(proxy)] = proxy
            
            self.last_fetch = datetime.now()
            logger.info(f"Successfully fetched {len(proxies)} proxies")
            return proxies
        
        except requests.RequestException as e:
            logger.error(f"Failed to fetch proxies: {e}")
            raise
    
    def test_proxies(
        self,
        proxies: List[Proxy],
        test_url: str = "https://httpbin.org/ip",
        timeout: Optional[int] = None,
    ) -> List[Proxy]:
        """
        Test proxy connectivity and measure speed.
        
        Args:
            proxies: List of proxies to test
            test_url: URL to test proxy against (default: httpbin.org)
            timeout: Request timeout in seconds (default: self.timeout)
        
        Returns:
            List[Proxy]: List of valid proxies with speed measurements
        """
        if timeout is None:
            timeout = self.timeout
        
        valid_proxies = []
        
        for proxy in proxies:
            try:
                proxy_dict = {"http": str(proxy), "https": str(proxy)}
                
                start_time = datetime.now()
                response = requests.get(
                    test_url,
                    proxies=proxy_dict,
                    timeout=timeout
                )
                end_time = datetime.now()
                
                if response.status_code == 200:
                    # Calculate speed in milliseconds
                    speed = (end_time - start_time).total_seconds() * 1000
                    proxy.speed = speed
                    proxy.last_checked = datetime.now()
                    valid_proxies.append(proxy)
                    logger.debug(f"Proxy {proxy} is valid (speed: {speed:.2f}ms)")
                
            except (requests.RequestException, Exception) as e:
                logger.debug(f"Proxy {proxy} failed: {e}")
                continue
        
        logger.info(f"Tested {len(proxies)} proxies, {len(valid_proxies)} are valid")
        return valid_proxies
    
    def get_best_proxy(self, proxies: List[Proxy]) -> Optional[Proxy]:
        """
        Get proxy with best speed.
        
        Args:
            proxies: List of proxies to choose from
        
        Returns:
            Optional[Proxy]: Proxy with best speed, or None if list is empty
        """
        if not proxies:
            return None
        
        # Filter proxies with speed measurements
        proxies_with_speed = [p for p in proxies if p.speed is not None]
        
        if not proxies_with_speed:
            return proxies[0]
        
        # Return proxy with minimum speed (fastest)
        best = min(proxies_with_speed, key=lambda p: p.speed)
        logger.debug(f"Best proxy selected: {best} (speed: {best.speed:.2f}ms)")
        return best
    
    def select_proxy(
        self,
        proxies: List[Proxy],
        mode: str = "best"
    ) -> Optional[Proxy]:
        """
        Select proxy based on mode.
        
        Args:
            proxies: List of proxies to choose from
            mode: Selection mode - best, random, first (default: best)
        
        Returns:
            Optional[Proxy]: Selected proxy, or None if list is empty
        """
        if not proxies:
            return None
        
        if mode == "best":
            return self.get_best_proxy(proxies)
        elif mode == "random":
            import random
            return random.choice(proxies)
        elif mode == "first":
            return proxies[0]
        else:
            logger.warning(f"Unknown selection mode: {mode}, using 'first'")
            return proxies[0]
    
    def validate_proxy(self, proxy: Proxy) -> bool:
        """
        Validate if proxy is still working.
        
        Args:
            proxy: Proxy to validate
        
        Returns:
            bool: True if proxy is valid, False otherwise
        """
        try:
            proxy_dict = {"http": str(proxy), "https": str(proxy)}
            response = requests.get(
                "https://httpbin.org/ip",
                proxies=proxy_dict,
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                proxy.last_checked = datetime.now()
                return True
            return False
        
        except Exception as e:
            logger.debug(f"Proxy validation failed: {e}")
            return False
    
    def get_cached_proxies(self) -> List[Proxy]:
        """
        Get all cached proxies.
        
        Returns:
            List[Proxy]: List of cached proxies
        """
        return list(self.proxy_cache.values())
    
    def clear_cache(self) -> None:
        """Clear proxy cache."""
        self.proxy_cache.clear()
        logger.info("Proxy cache cleared")
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """
        Get cache statistics.
        
        Returns:
            Dict: Cache statistics including size, last fetch time, etc.
        """
        valid_proxies = [p for p in self.proxy_cache.values() if p.is_valid()]
        
        return {
            "total_cached": len(self.proxy_cache),
            "valid_proxies": len(valid_proxies),
            "last_fetch": self.last_fetch.isoformat() if self.last_fetch else None,
            "cache_size": len(self.proxy_cache),
        }
