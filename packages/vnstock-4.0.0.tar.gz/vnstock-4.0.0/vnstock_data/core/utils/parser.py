import re
import urllib.parse
import pandas as pd
import unicodedata
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
import math

def get_asset_type(symbol: str) -> str:
    """
    Xác định loại tài sản dựa trên mã chứng khoán được cung cấp.

    Tham số: 
        - symbol (str): Mã chứng khoán hoặc mã chỉ số.
    
    Trả về:
        - 'index' nếu mã chứng khoán là mã chỉ số.
        - 'stock' nếu mã chứng khoán là mã cổ phiếu.
        - 'derivative' nếu mã chứng khoán là mã hợp đồng tương lai hoặc quyền chọn.
        - 'bond' nếu mã chứng khoán là mã trái phiếu (chính phủ hoặc doanh nghiệp).
        - 'coveredWarr' nếu mã chứng khoán là mã chứng quyền.
    """
    symbol = symbol.upper()
    
    # Index symbols
    if symbol in [
        'VNINDEX', 'HNXINDEX', 'UPCOMINDEX', 'VN30', 'VN100', 'HNX30',
        'VNSML', 'VNMID', 'VNALL', 'VNREAL', 'VNMAT', 'VNIT', 'VNHEAL',
        'VNFINSELECT', 'VNFIN', 'VNENE', 'VNDIAMOND', 'VNCONS', 'VNCOND'
    ]:
        return 'index'
    
    # Stock symbols (assumed to have 3 characters)
    elif len(symbol) == 3:
        return 'stock'
    
    # For symbols that could be derivative or bond (length 7 or 9)
    elif len(symbol) in [7, 9]:
        # VN30 derivative patterns:
        fm_pattern = re.compile(r'^VN30F\d{1,2}M$')
        ym_pattern = re.compile(r'^VN30F\d{4}$')
        
        # Bond patterns:
        # Government bond: e.g., GB05F2506 or GB10F2024
        gov_bond_pattern = re.compile(r'^GB\d{2}F\d{4}$')
        # Company bond: e.g., BAB122032; exclude those starting with VN30F.
        comp_bond_pattern = re.compile(r'^(?!VN30F)[A-Z]{3}\d{6}$')
        
        if gov_bond_pattern.match(symbol) or comp_bond_pattern.match(symbol):
            return 'bond'
        elif fm_pattern.match(symbol) or ym_pattern.match(symbol):
            return 'derivative'
        else:
            raise ValueError('Invalid derivative or bond symbol. Symbol must be in format of VN30F1M, VN30F2024, GB10F2024, or for company bonds, e.g., BAB122032')
    
    # Covered warrant symbols (assumed to have 8 characters)
    elif len(symbol) == 8:
        return 'coveredWarr'
    
    else:
        raise ValueError('Invalid symbol. Your symbol format is not recognized!')

def encode_url(string:str, safe:str=''):
    """
    Encode a string to url format.
    """
    return urllib.parse.quote(string, safe=safe)

def days_between (start: str, end: str, format: str = '%m/%d/%Y') -> int:
    """
    Calculate the number of days between two given datestrings.

    Parameters:
        start (str): The start date string.
        end (str): The end date string.
        format (str): The format of the date strings. Default is '%m/%d/%Y'.
        
    Returns:
        int: The number of days between the two dates.
    """
    start = pd.to_datetime(start, format=format)
    end = pd.to_datetime(end, format=format)
    days = (end - start).days
    return days

def lookback_date(period: str) -> str:
    """
    Calculates the start date based on a lookback period.

    Parameters:
        period (str): Lookback period (e.g., '1D', '5M', '10Y').
                      D = days, M = months, Y = years.

    Returns:
        str: Calculated start date in YYYY-MM-DD format.

    Raises:
        ValueError: If the period format is invalid.
    """
    try:
        unit = period[-1].upper()
        value = int(period[:-1])
        if unit == 'D':
            start_date = datetime.now() - timedelta(days=value)
        elif unit == 'M':
            start_date = datetime.now() - timedelta(days=value * 30)
        elif unit == 'Y':
            start_date = datetime.now() - timedelta(days=value * 365)
        else:
            raise ValueError("Invalid period format. Use 'D', 'M', or 'Y' for days, months, or years.")
        return start_date.strftime('%Y-%m-%d')
    except Exception as e:
        raise ValueError(f"Error parsing period: {e}")

def filter_columns_by_language(df: pd.DataFrame, lang: str) -> pd.DataFrame:
    """
    Filter DataFrame columns based on language preference.
    
    Args:
        df (pd.DataFrame): Input DataFrame with multilingual columns
        lang (str): Language preference ("vi", "en", or "both")
        
    Returns:
        pd.DataFrame: DataFrame with filtered columns based on language preference
    """
    if lang.lower() == "both":
        # Return all columns without filtering
        return df
    
    # Get all column names
    all_columns = df.columns.tolist()
    
    # Identify language-specific columns
    vi_columns = [col for col in all_columns if col.endswith('_vi')]
    en_columns = [col for col in all_columns if col.endswith('_en')]
    
    # Get base columns (no language suffix)
    base_columns = [col for col in all_columns if not (col.endswith('_vi') or col.endswith('_en'))]
    
    if lang.lower() == "vi":
        # Keep base columns + Vietnamese columns, drop English columns
        columns_to_keep = base_columns + vi_columns
        filtered_df = df[columns_to_keep].copy()
        
        # Rename Vietnamese columns to remove '_vi' suffix for cleaner names
        rename_dict = {col: col.replace('_vi', '') for col in vi_columns}
        filtered_df = filtered_df.rename(columns=rename_dict)
        
    elif lang.lower() == "en":
        # Keep base columns + English columns, drop Vietnamese columns  
        columns_to_keep = base_columns + en_columns
        filtered_df = df[columns_to_keep].copy()
        
        # Rename English columns to remove '_en' suffix for cleaner names
        rename_dict = {col: col.replace('_en', '') for col in en_columns}
        filtered_df = filtered_df.rename(columns=rename_dict)
        
    else:
        # Invalid language parameter, log warning and return original DataFrame
        logger.warning(f"Invalid language parameter '{lang}'. Use 'vi', 'en', or 'both'. Returning all columns.")
        return df
    
    return filtered_df

def vn_to_snake_case(text: str) -> str:
    """
    Convert Vietnamese text with diacritics to unaccented, lowercase, snake_case string.
    """
    # Normalize unicode and remove diacritics
    text = unicodedata.normalize('NFD', text)
    text = ''.join([c for c in text if unicodedata.category(c) != 'Mn'])
    # Replace special Vietnamese characters (dự phòng cho mọi trường hợp unicode)
    VN_CHAR_MAP = {
        'đ': 'd', 'Đ': 'd',
        'ô': 'o', 'Ô': 'o',
        'ư': 'u', 'Ư': 'u',
        'ê': 'e', 'Ê': 'e',
        'ă': 'a', 'Ă': 'a',
        'â': 'a', 'Â': 'a',
    }
    for src, tgt in VN_CHAR_MAP.items():
        text = text.replace(src, tgt)

    # Lowercase
    text = text.lower()
    # Replace non-word chars with underscore
    text = re.sub(r'[^a-z0-9]+', '_', text)
    # Remove leading/trailing underscores
    text = text.strip('_')
    # Collapse multiple underscores
    text = re.sub(r'_+', '_', text)
    return text

def get_derivative_maturity_date(symbol_suffix: str, reference_date: date = None) -> date:
    """
    Calculate the maturity date for a derivative symbol suffix.
    
    Args:
        symbol_suffix: Suffix like 'F2506' (explicit) or 'F1M', 'F1Q' (relative).
        reference_date: Reference date for relative calculation (default: today).
        
    Returns:
        date: The maturity date (3rd Thursday of the month).
    """
    if reference_date is None:
        reference_date = date.today()
        
    maturity_month = reference_date.month
    maturity_year = reference_date.year
    
    # Parse explicit format FyyMM (e.g., F2506)
    if len(symbol_suffix) == 5 and symbol_suffix.startswith('F') and symbol_suffix[1:].isdigit():
        yy = int(symbol_suffix[1:3])
        mm = int(symbol_suffix[3:5])
        maturity_year = 2000 + yy
        maturity_month = mm
    
    # Parse relative format FnM/FnQ
    elif symbol_suffix.startswith('F') and len(symbol_suffix) == 3:
        # Determine current month's expiry to decide baseline
        # Calculate 3rd Thursday of reference month
        def get_expiry(y, m):
            d = date(y, m, 1)
            days_to_thursday = (3 - d.weekday() + 7) % 7
            return d + timedelta(days=days_to_thursday + 14)
            
        current_expiry = get_expiry(reference_date.year, reference_date.month)
        
        # If today > expiry, start counting from next month
        base_date = reference_date
        if reference_date > current_expiry:
             base_date = reference_date + relativedelta(months=1)
        
        if symbol_suffix == 'F1M':
             target_date = base_date
        elif symbol_suffix == 'F2M':
             target_date = base_date + relativedelta(months=1)
        elif symbol_suffix == 'F1Q':
             # Next quarter month in [3, 6, 9, 12]
             # Find first quarter month >= base_date month
             current_month = base_date.month
             quarter_months = [3, 6, 9, 12]
             target_month = next((m for m in quarter_months if m >= current_month), None)
             
             if target_month is None:
                 # Next year March
                 target_date = date(base_date.year + 1, 3, 1)
             else:
                 target_date = date(base_date.year, target_month, 1)
                 
        elif symbol_suffix == 'F2Q':
             # Find F1Q then next quarter
             current_month = base_date.month
             quarter_months = [3, 6, 9, 12]
             target_month = next((m for m in quarter_months if m >= current_month), None)
             
             if target_month is None:
                 # F1Q is next year Mar -> F2Q is Jun
                 target_date = date(base_date.year + 1, 6, 1)
             else:
                 # Move to next quarter month
                 idx = quarter_months.index(target_month)
                 if idx + 1 < len(quarter_months):
                      target_date = date(base_date.year, quarter_months[idx+1], 1)
                 else:
                      # Next year Mar
                      target_date = date(base_date.year + 1, 3, 1)
        else:
             # Default fallback if unknown suffix
             return reference_date

        if 'target_date' in locals():
            maturity_year = target_date.year
            maturity_month = target_date.month

    # Calculate 3rd Thursday of the determined maturity month
    d = date(maturity_year, maturity_month, 1)
    days_to_thursday = (3 - d.weekday() + 7) % 7
    maturity_date = d + timedelta(days=days_to_thursday + 14)
    
    return maturity_date

def convert_derivative_symbol(symbol: str, reference_date: date = None) -> str:
    """
    Convert old derivative symbol (e.g. VN30F2506, GB05F2506) to new KRX format (e.g. 41I1F7000).
    Effective from May 2025.
    
    Format: 41 + Underlying + Year + Month + 000
    Length: 9 chars.
    Reference: https://owa.hnx.vn/ftp//PORTALNEW/HEADER_IMAGES/20250428/21.04.2025_Tai%20lieu%20huong%20dan%20quy%20uoc%20ma%20giao%20dich%20moi%20ckps_final.pdf
    """
    symbol = symbol.upper()
    
    # 1. Parse Segments
    # Underlying mappings
    underlying_map = {
        'VN30': 'I1',
        'VN100': 'I2', 
        'GB05': 'B5', # Gov Bond 5Y
        'GB10': 'BA', # Gov Bond 10Y
    }
    
    underlying_code = None
    suffix = None
    
    # Find underlying code by matching prefix
    for prefix, code in underlying_map.items():
        if symbol.startswith(prefix):
            underlying_code = code
            suffix = symbol[len(prefix):]
            break
            
    if not underlying_code:
        raise ValueError("Unknown underlying asset for symbol {}. Supported prefixes: {}".format(symbol, ', '.join(underlying_map.keys())))
        
    # 2. Determine Maturity Year/Month
    if reference_date is None:
        # Check if suffix implies year/month directly first to avoid unnecessary date logic dependence if explicit
        pass 
        
    mat_date = get_derivative_maturity_date(suffix, reference_date)
    mat_year = mat_date.year
    mat_month = mat_date.month
        
    # 3. Map to KRX Codes
    
    # Year Code (30 year cycle)
    year_cycle_index = (mat_year - 2010) % 30 # 0 to 29
    
    # Alphabet: A-W excluding I, O, U
    # A B C D E F G H J K L M N P Q R S T V W
    alphabet = "ABCDEFGHJKLMNPQRSTVW" 
    
    if 0 <= year_cycle_index <= 9:
        year_code = str(year_cycle_index)
    else:
        # Index 10 -> A (index 0 in alphabet)
        year_code = alphabet[year_cycle_index - 10]
        
    # Month Code
    if 1 <= mat_month <= 9:
        month_code = str(mat_month)
    else:
        month_codes = {10: 'A', 11: 'B', 12: 'C'}
        month_code = month_codes[mat_month]
        
    # 4. Construct
    # Mẫu: 41 + Underlying + Year + Month + 000
    krx_symbol = f"41{underlying_code}{year_code}{month_code}000"
    
    return krx_symbol

def safe_convert_derivative_symbol(symbol: str, reference_date: date = None) -> str:
    """
    Safely convert derivative symbol to KRX format. If it's already KRX or an error occurs,
    returns the original symbol.
    """
    try:
        # Simple heuristic to identify KRX derivative symbols
        if len(symbol) == 9 and symbol.startswith("41"):
            return symbol
        return convert_derivative_symbol(symbol, reference_date)
    except Exception:
        return symbol
