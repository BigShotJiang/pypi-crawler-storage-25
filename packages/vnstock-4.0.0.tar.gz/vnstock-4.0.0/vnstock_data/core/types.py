"""
Type definitions for vnstock_data.

Re-exports vnstock's core types for compatibility while adding
custom types specific to vnstock_data's broader data coverage.
"""

from enum import Enum
from typing import TypedDict, Optional, Any, List
from datetime import datetime

# Try to import vnstock's core types, with fallback to stub definitions
try:
    from vnstock.core.types import (
        ProviderType,
        MarketType,
        ExchangeType,
        TimeFrame,
    )
except ImportError:
    # Fallback: Define stub types if vnstock is not available
    class ProviderType(str, Enum):
        """Stub: Provider types from vnstock."""
        STOCK = "stock"
        FUTURE = "future"
        OPTION = "option"
    
    class MarketType(str, Enum):
        """Stub: Market types from vnstock."""
        STOCK = "stock"
        DERIVATIVE = "derivative"
        FUND = "fund"
    
    class ExchangeType(str, Enum):
        """Stub: Exchange types from vnstock."""
        HOSE = "hose"
        HNX = "hnx"
        UPCOM = "upcom"
    
    class TimeFrame(str, Enum):
        """Stub: Time frames from vnstock."""
        D1 = "1D"
        H4 = "4H"
        H1 = "1H"
        M15 = "15m"
        M5 = "5m"
        M1 = "1m"

# Custom enums for vnstock_data (broader coverage than vnstock)

class DataCategory(str, Enum):
    """Data categories supported by vnstock_data (extends vnstock's categories)."""
    # Stock market data
    QUOTE = "quote"
    COMPANY = "company"
    FINANCIAL = "financial"
    TRADING = "trading"
    LISTING = "listing"
    SCREENER = "screener"
    # Additional categories in vnstock_data
    MACRO = "macro"  # Macroeconomic data (GDP, CPI, etc.)
    COMMODITY = "commodity"  # Commodity prices (gold, gas, etc.)
    MARKET = "market"  # Market evaluation metrics (P/E, P/B)
    INSIGHT = "insight"  # Market insights and analysis
    FUND = "fund"  # Fund data


class DataSource(str, Enum):
    """Data sources available in vnstock_data (more comprehensive than vnstock)."""
    # Stock quote and company data sources
    VCI = "vci"  # VCI (Vietcap)
    VND = "vnd"  # VND (VNDirect)
    MAS = "mas"  # MAS (Mirae Assets)
    # Commodity and energy data
    SPL = "spl"  # Simplize
    # Macroeconomic data
    MBK = "mbk"  # Maybank KimEng
    # Trading and market data
    CAFEF = "cafef" 
    # Fund data
    FMARKET = "fmarket"  
    # Additional sources
    TVS = "tvs"  
    VDS = "vds"  


# vnstock_data specific enums

class SubscriptionTier(str, Enum):
    """User subscription tier levels for vnstock_data."""
    GUEST = "guest"        # Chưa đăng nhập, 15 requests/phút
    BASIC = "basic"        # Đăng nhập cơ bản, 60 requests/phút
    BRONZE = "bronze"      # Subscription tier 1, 300 requests/phút
    SILVER = "silver"      # Subscription tier 2, 300 requests/phút
    GOLDEN = "golden"      # Subscription tier 3, 300 requests/phút


class DataQuality(str, Enum):
    """Data quality levels."""
    RAW = "raw"
    CLEANED = "cleaned"
    VALIDATED = "validated"
    PREMIUM = "premium"


class UpdateFrequency(str, Enum):
    """Data update frequency."""
    REAL_TIME = "real_time"
    HOURLY = "hourly"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"


class CacheStrategy(str, Enum):
    """Cache strategy for data."""
    NO_CACHE = "no_cache"
    SHORT_TERM = "short_term"  # 1 hour
    MEDIUM_TERM = "medium_term"  # 1 day
    LONG_TERM = "long_term"  # 1 week


# vnstock_data specific TypedDicts

class PremiumQuoteData(TypedDict, total=False):
    """Extended quote data for premium users."""
    symbol: str
    price: float
    change: float
    change_pct: float
    volume: int
    timestamp: datetime
    # Premium fields
    bid_ask_spread: Optional[float]
    implied_volatility: Optional[float]
    options_chain: Optional[dict]
    technical_indicators: Optional[dict]

class DataSourceInfo(TypedDict):
    """Information about a data source."""
    name: str
    provider: str
    update_frequency: UpdateFrequency
    data_quality: DataQuality
    subscription_required: bool
    tier: SubscriptionTier

class UserProfile(TypedDict):
    """User profile information."""
    user_id: str
    subscription_tier: SubscriptionTier
    api_key: str
    rate_limit: int
    cache_strategy: CacheStrategy
    created_at: datetime
    expires_at: Optional[datetime]

class SubscriptionFeatures(TypedDict):
    """Features available for each subscription tier."""
    tier: SubscriptionTier
    requests_per_minute: int
    requests_per_hour: int
    requests_per_day: int
    data_sources: List[DataSource]
    data_categories: List[DataCategory]
    real_time_data: bool
    historical_data: bool
    advanced_analytics: bool
    api_access: bool
    priority_support: bool
    custom_indicators: bool
    export_formats: List[str]
    webhooks: bool
    email_notifications: bool

class RateLimitInfo(TypedDict):
    """Rate limiting information for user."""
    tier: SubscriptionTier
    current_requests: int
    limit_per_minute: int
    limit_per_hour: int
    limit_per_day: int
    reset_time: datetime
    remaining_requests: int


# Helper classes

class FileTypes:
    """MIME type mappings."""
    CSV = "text/csv"
    JSON = "application/json"
    EXCEL = "application/vnd.ms-excel"
    PARQUET = "application/octet-stream"
    FEATHER = "application/octet-stream"


class ParameterNames:
    """Standardized parameter names."""
    SYMBOL = "symbol"
    START_DATE = "start_date"
    END_DATE = "end_date"
    INTERVAL = "interval"
    LIMIT = "limit"
    OFFSET = "offset"
    SORT = "sort"
    ORDER = "order"


class MethodNames:
    """Standardized method names."""
    GET_QUOTE = "get_quote"
    GET_HISTORY = "get_history"
    GET_FINANCIALS = "get_financials"
    GET_INTRADAY = "get_intraday"
    SCREEN = "screen"


class SubscriptionConfig:
    """Configuration for subscription tiers."""
    
    TIER_LIMITS = {
        SubscriptionTier.GUEST: {
            "requests_per_minute": 15,
            "requests_per_hour": 15 * 60,
            "requests_per_day": 15 * 60 * 24,
        },
        SubscriptionTier.BASIC: {
            "requests_per_minute": 60,
            "requests_per_hour": 60 * 60,
            "requests_per_day": 60 * 60 * 24,
        },
        SubscriptionTier.BRONZE: {
            "requests_per_minute": 200,
            "requests_per_hour": 200 * 60,
            "requests_per_day": 200 * 60 * 24,
        },
        SubscriptionTier.SILVER: {
            "requests_per_minute": 500,
            "requests_per_hour": 500 * 60,
            "requests_per_day": 500 * 60 * 24,
        },
        SubscriptionTier.GOLDEN: {
            "requests_per_minute": 1000,
            "requests_per_hour": 1000 * 60,
            "requests_per_day": 1000 * 60 * 24,
        },
    }
    
    TIER_FEATURES = {
        SubscriptionTier.GUEST: {
            "data_sources": [DataSource.VCI],
            "data_categories": [DataCategory.QUOTE],
            "real_time_data": False,
            "historical_data": True,
            "advanced_analytics": False,
            "api_access": False,
            "priority_support": False,
            "custom_indicators": False,
            "export_formats": ["json"],
            "webhooks": False,
            "email_notifications": False,
        },
        SubscriptionTier.BASIC: {
            "data_sources": [DataSource.VCI, DataSource.VND, DataSource.MAS],
            "data_categories": [DataCategory.QUOTE, DataCategory.COMPANY],
            "real_time_data": True,
            "historical_data": True,
            "advanced_analytics": False,
            "api_access": True,
            "priority_support": False,
            "custom_indicators": False,
            "export_formats": ["json", "csv"],
            "webhooks": False,
            "email_notifications": False,
        },
        SubscriptionTier.BRONZE: {
            "data_sources": [DataSource.VCI, DataSource.VND, DataSource.MAS, DataSource.CAFEF],
            "data_categories": [DataCategory.QUOTE, DataCategory.COMPANY, DataCategory.FINANCIAL],
            "real_time_data": True,
            "historical_data": True,
            "advanced_analytics": True,
            "api_access": True,
            "priority_support": True,
            "custom_indicators": False,
            "export_formats": ["json", "csv", "excel"],
            "webhooks": False,
            "email_notifications": True,
        },
        SubscriptionTier.SILVER: {
            "data_sources": [DataSource.VCI, DataSource.VND, DataSource.MAS, DataSource.CAFEF, DataSource.SPL],
            "data_categories": [DataCategory.QUOTE, DataCategory.COMPANY, DataCategory.FINANCIAL, DataCategory.TRADING],
            "real_time_data": True,
            "historical_data": True,
            "advanced_analytics": True,
            "api_access": True,
            "priority_support": True,
            "custom_indicators": True,
            "export_formats": ["json", "csv", "excel", "parquet"],
            "webhooks": True,
            "email_notifications": True,
        },
        SubscriptionTier.GOLDEN: {
            "data_sources": list(DataSource),
            "data_categories": list(DataCategory),
            "real_time_data": True,
            "historical_data": True,
            "advanced_analytics": True,
            "api_access": True,
            "priority_support": True,
            "custom_indicators": True,
            "export_formats": ["json", "csv", "excel", "parquet", "feather"],
            "webhooks": True,
            "email_notifications": True,
        },
    }
    
    @classmethod
    def get_rate_limit(cls, tier: SubscriptionTier) -> dict:
        """Get rate limits for a subscription tier."""
        return cls.TIER_LIMITS[tier]
    
    @classmethod
    def get_features(cls, tier: SubscriptionTier) -> dict:
        """Get features available for a subscription tier."""
        return cls.TIER_FEATURES[tier]
    
    @classmethod
    def can_access_source(cls, tier: SubscriptionTier, source: DataSource) -> bool:
        """Check if tier can access a data source."""
        return source in cls.TIER_FEATURES[tier]["data_sources"]
    
    @classmethod
    def can_access_category(cls, tier: SubscriptionTier, category: DataCategory) -> bool:
        """Check if tier can access a data category."""
        return category in cls.TIER_FEATURES[tier]["data_categories"]


__all__ = [
    # Imported from vnstock
    "DataCategory",
    "ProviderType",
    "MarketType",
    "ExchangeType",
    "TimeFrame",
    "DataSource",
    # vnstock_data specific enums
    "SubscriptionTier",
    "DataQuality",
    "UpdateFrequency",
    "CacheStrategy",
    # TypedDicts
    "PremiumQuoteData",
    "DataSourceInfo",
    "UserProfile",
    # Helper classes
    "FileTypes",
    "ParameterNames",
    "MethodNames",
]
