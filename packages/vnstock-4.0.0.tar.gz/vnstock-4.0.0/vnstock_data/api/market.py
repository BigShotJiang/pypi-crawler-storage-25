# vnstock_data/api/market.py

from vnstock_data.base import BaseAdapter, dynamic_method

class Market(BaseAdapter):
    _module_name = 'market'
    SUPPORTED_SOURCES = ['vnd']

    def __init__(self, source: str = 'vnd', **kwargs):
        source_lower = source.lower()
        if source_lower not in self.SUPPORTED_SOURCES:
            raise ValueError(
                "Lớp Market chỉ nhận giá trị tham số source là 'VND'. " +
                "Nhưng nhận được '" + source + "'."
            )
        super().__init__(source=source_lower, **kwargs)

    @dynamic_method
    def pe(self, duration: str = '5Y'):
        """
        Retrieves P/E ratio data for the given duration.
        """
        # implementation is delegated to vnstock_data.explorer.vnd.market.Market.pe
        pass

    @dynamic_method
    def pb(self, duration: str = '5Y'):
        """
        Retrieves P/B ratio data for the given duration.
        """
        pass

    @dynamic_method
    def evaluation(self, duration: str = '5Y'):
        """
        Retrieves combined P/E and P/B data for the given duration.
        """
        pass
