# vnstock_data/api/macro.py

from vnstock_data.base import BaseAdapter, dynamic_method
from typing import Optional, Union

class Macro(BaseAdapter):
    """
    Adapter for macroeconomic data from multiple providers (e.g. MBK).
    
    Usage:
        from vnstock_data.api.macro import Macro
        m = Macro(source="mbk", random_agent=False, show_log=False)
        df = m.gdp(start="2015-01", end="2025-04", period="quarter")
    """
    _module_name = "macro"

    def __init__(
        self,
        source: str = "mbk",
        random_agent: bool = False,
        show_log: bool = False
    ):
        # Validate the source to only accept mbk
        if source != "mbk":
            raise ValueError("Lớp Macro không hỗ trợ thay đổi tham số source.")
        # BaseAdapter will discover vnstock_data.explorer.<real_source>.macro
        # and pass only the kwargs its __init__ accepts (random_agent, show_log).
        super().__init__(
            source=source,
            random_agent=random_agent,
            show_log=show_log
        )

    @dynamic_method
    def gdp(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "quarter",
        keep_label: bool = False,
        length: Optional[Union[str, int]] = None
    ):
        """
        Fetch GDP series.
        """
        # implementation is in explorer.<source>.macro.Macro.gdp
        pass

    @dynamic_method
    def cpi(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "month",
        length: Optional[Union[str, int]] = None
    ):
        """
        Fetch CPI series.
        """
        pass

    @dynamic_method
    def industry_prod(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "month",
        length: Optional[Union[str, int]] = None
    ):
        """
        Fetch Industrial Production series.
        """
        pass

    @dynamic_method
    def import_export(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "month",
        length: Optional[Union[str, int]] = None
    ):
        """
        Fetch Import-Export series.
        """
        pass

    @dynamic_method
    def retail(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "month",
        length: Optional[Union[str, int]] = None
    ):
        """
        Fetch Retail sales series.
        """
        pass

    @dynamic_method
    def fdi(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "month",
        length: Optional[Union[str, int]] = None
    ):
        """
        Fetch Foreign Direct Investment series.
        """
        pass

    @dynamic_method
    def money_supply(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "month",
        length: Optional[Union[str, int]] = None
    ):
        """
        Fetch Money Supply series.
        """
        pass

    @dynamic_method
    def exchange_rate(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "day",
        length: Optional[Union[str, int]] = None
    ):
        """
        Fetch Exchange Rate series.
        """
        pass

    @dynamic_method
    def interest_rate(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "day",
        format: str = "pivot",
        length: Optional[Union[str, int]] = None
    ):
        """
        Fetch Interest Rate series.
        """
        pass

    @dynamic_method
    def population_labor(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        period: str = "year",
        length: Optional[Union[str, int]] = None
    ):
        """
        Fetch Population and Labor series.
        """
        pass
