# vnstock/api/listing.py

from typing import Any, Union
from functools import wraps
from tenacity import retry, stop_after_attempt, wait_exponential
from vnstock_data.config import Config
from vnstock_data.base import BaseAdapter, dynamic_method
from vnstock_data.enums import IndexGroup


def source_required(func):
    """Decorator to ensure source is specified for source-specific methods.
    
    This decorator is applied BEFORE @retry so that ValueError from missing source
    is raised immediately without retry logic.
    """
    method_name = func.__name__

    @wraps(func)
    def wrapper(self, *args, **kwargs):
        # Check provider before any retry logic
        if self._provider is None:
            raise ValueError(
                "Method '" + method_name + "()' requires a data source. " +
                "Initialize with Listing(source='vci'|'kbs'|'vnd') " +
                "or use source-independent methods like all_indices(), indices_by_group()."
            )
        return func(self, *args, **kwargs)

    return wrapper


def _normalize_index_group(group: Union[str, IndexGroup]) -> str:
    """
    Normalize short index group names to their full names.
    
    Accepts both enum values and string values:
        'HOSE' or IndexGroup.HOSE -> 'HOSE Indices'
        'SECTOR' or IndexGroup.SECTOR -> 'Sector Indices'
        'INVESTMENT' or IndexGroup.INVESTMENT -> 'Investment Indices'
        'VNX' or IndexGroup.VNX -> 'VNX Indices'
    
    Args:
        group: Index group name or IndexGroup enum value
        
    Returns:
        Full name of the index group, or original value if not mapped
    """
    if group is None:
        return None
    
    # If it's an IndexGroup enum, use its full_name property
    if isinstance(group, IndexGroup):
        return group.full_name
    
    # Otherwise treat as string
    group_upper = str(group).upper().strip()
    mapping = {
        'HOSE': 'HOSE Indices',
        'SECTOR': 'Sector Indices',
        'INVESTMENT': 'Investment Indices',
        'VNX': 'VNX Indices',
    }
    
    # Return mapped value if exists, otherwise return original (in case it's already full name)
    return mapping.get(group_upper, group)


class Listing(BaseAdapter):
    _module_name = "listing"
    """
    Adapter for listing data:
      - all_symbols
      - symbols_by_industries
      - symbols_by_exchange
      - industries_icb
      - symbols_by_group
      - all_future_indices
      - all_government_bonds
      - all_covered_warrant
      - all_bonds

    Usage:
        lst = Listing(source="vci", random_agent=False, show_log=True)
        df = lst.all_symbols(to_df=True)
        df2 = lst.symbols_by_exchange(lang="en")
        idx = lst.industries_icb()
        group = lst.symbols_by_group(group="VN30")
        fu = lst.all_future_indices()
    """
    def __init__(
        self,
        source: str = None,
        random_agent: bool = False,
        show_log: bool = False
    ):
        # Validate the source if provided
        if source is not None and source.lower() not in ["vci", "kbs", "vnd"]:
            raise ValueError(
                "Lớp Listing chỉ nhận giá trị tham số source là 'VCI', 'KBS' "
                "hoặc 'VND'."
            )
        # BaseAdapter will discover vnstock_data.explorer.<real_source>.listing
        # and pass only the kwargs its __init__ accepts (random_agent, show_log).
        self.source = source
        self.show_log = show_log
        self._provider = None

        if source is not None:
            super().__init__(
                source=source,
                random_agent=random_agent,
                show_log=show_log
            )

    def _ensure_provider(self, method_name: str):
        """Ensure provider is initialized for source-specific methods."""
        if self._provider is None:
            raise ValueError(
                "Method '" + method_name + "()' requires a data source. " +
                "Initialize with Listing(source='vci'|'kbs'|'vnd') or use " +
                "source-independent methods like all_indices(), " +
                "indices_by_group()."
            )

    @source_required
    @retry(
        stop=stop_after_attempt(Config.RETRIES),
        wait=wait_exponential(
            multiplier=Config.BACKOFF_MULTIPLIER,
            min=Config.BACKOFF_MIN,
            max=Config.BACKOFF_MAX
        )
    )
    @dynamic_method
    def all_symbols(self, *args: Any, **kwargs: Any) -> Any:
        """Retrieve all symbols (filtered to STOCK)."""
        pass

    @source_required
    @retry(
        stop=stop_after_attempt(Config.RETRIES),
        wait=wait_exponential(
            multiplier=Config.BACKOFF_MULTIPLIER,
            min=Config.BACKOFF_MIN,
            max=Config.BACKOFF_MAX
        )
    )
    @dynamic_method
    def symbols_by_industries(self, *args: Any, **kwargs: Any) -> Any:
        """Retrieve symbols grouped by ICB industries."""
        pass

    @source_required
    @retry(
        stop=stop_after_attempt(Config.RETRIES),
        wait=wait_exponential(
            multiplier=Config.BACKOFF_MULTIPLIER,
            min=Config.BACKOFF_MIN,
            max=Config.BACKOFF_MAX
        )
    )
    @dynamic_method
    def symbols_by_exchange(self, *args: Any, **kwargs: Any) -> Any:
        """Retrieve symbols by exchange/board."""
        pass

    @source_required
    @retry(
        stop=stop_after_attempt(Config.RETRIES),
        wait=wait_exponential(
            multiplier=Config.BACKOFF_MULTIPLIER,
            min=Config.BACKOFF_MIN,
            max=Config.BACKOFF_MAX
        )
    )
    @dynamic_method
    def industries_icb(self, *args: Any, **kwargs: Any) -> Any:
        """Retrieve ICB code hierarchy and mapping."""
        pass

    @source_required
    @retry(
        stop=stop_after_attempt(Config.RETRIES),
        wait=wait_exponential(
            multiplier=Config.BACKOFF_MULTIPLIER,
            min=Config.BACKOFF_MIN,
            max=Config.BACKOFF_MAX
        )
    )
    @dynamic_method
    def symbols_by_group(self, *args: Any, **kwargs: Any) -> Any:
        """Retrieve symbols by predefined group (VN30, HNX30, CW, etc.)."""
        pass

    # shortcuts that delegate to symbols_by_group
    @source_required
    @retry(
        stop=stop_after_attempt(Config.RETRIES),
        wait=wait_exponential(
            multiplier=Config.BACKOFF_MULTIPLIER,
            min=Config.BACKOFF_MIN,
            max=Config.BACKOFF_MAX
        )
    )
    def all_future_indices(self, **kwargs: Any) -> Any:
        """Retrieve all futures indices (group='FU_INDEX')."""
        return self.symbols_by_group(group="FU_INDEX", **kwargs)

    @source_required
    @retry(
        stop=stop_after_attempt(Config.RETRIES),
        wait=wait_exponential(
            multiplier=Config.BACKOFF_MULTIPLIER,
            min=Config.BACKOFF_MIN,
            max=Config.BACKOFF_MAX
        )
    )
    @source_required
    @dynamic_method
    def all_government_bonds(self, *args: Any, **kwargs: Any) -> Any:
        """Retrieve all government bonds."""
        pass

    @source_required
    @retry(
        stop=stop_after_attempt(Config.RETRIES),
        wait=wait_exponential(
            multiplier=Config.BACKOFF_MULTIPLIER,
            min=Config.BACKOFF_MIN,
            max=Config.BACKOFF_MAX
        )
    )
    def all_covered_warrant(self, **kwargs: Any) -> Any:
        """Retrieve all covered warrants (group='CW')."""
        return self.symbols_by_group(group="CW", **kwargs)

    @source_required
    @retry(
        stop=stop_after_attempt(Config.RETRIES),
        wait=wait_exponential(
            multiplier=Config.BACKOFF_MULTIPLIER,
            min=Config.BACKOFF_MIN,
            max=Config.BACKOFF_MAX
        )
    )
    def all_bonds(self, **kwargs: Any) -> Any:
        """Retrieve all bonds (group='BOND')."""
        return self.symbols_by_group(group="BOND", **kwargs)

    @source_required
    @retry(
        stop=stop_after_attempt(Config.RETRIES),
        wait=wait_exponential(
            multiplier=Config.BACKOFF_MULTIPLIER,
            min=Config.BACKOFF_MIN,
            max=Config.BACKOFF_MAX
        )
    )
    @dynamic_method
    def all_etf(self, *args: Any, **kwargs: Any) -> Any:
        """Retrieve all ETF (exchange-traded funds)."""
        pass

    @retry(
        stop=stop_after_attempt(Config.RETRIES),
        wait=wait_exponential(
            multiplier=Config.BACKOFF_MULTIPLIER,
            min=Config.BACKOFF_MIN,
            max=Config.BACKOFF_MAX
        )
    )
    def all_indices(self, *args: Any, **kwargs: Any) -> Any:
        """
        Retrieve all standardized market indices with metadata.

        Returns:
            DataFrame with columns:
            - symbol: Index symbol (VN30, VNIT, etc.)
            - name: Index name
            - description: Vietnamese description
            - full_name: Full English name
            - group: Index group (HOSE Indices, Sector Indices, etc.)
            - index_id: Unique index ID
            - sector_id: ICB sector ID (for sector indices only)
        """
        from vnstock.common import indices as market_indices
        return market_indices.get_all_indices()

    @retry(
        stop=stop_after_attempt(Config.RETRIES),
        wait=wait_exponential(
            multiplier=Config.BACKOFF_MULTIPLIER,
            min=Config.BACKOFF_MIN,
            max=Config.BACKOFF_MAX
        )
    )
    def indices_by_group(self, *args: Any, **kwargs: Any) -> Any:
        """
        Retrieve standardized market indices by group/category.

        Args:
            group (str or IndexGroup): Index group name. Accepts both short names, 
                enum values, and full names:
                - 'HOSE', IndexGroup.HOSE, or 'HOSE Indices' - HOSE market indices
                - 'SECTOR', IndexGroup.SECTOR, or 'Sector Indices' - Sector indices
                - 'INVESTMENT', IndexGroup.INVESTMENT, or 'Investment Indices' - Investment indices
                - 'VNX', IndexGroup.VNX, or 'VNX Indices' - VNX market indices

        Returns:
            DataFrame with index information filtered by group,
            or None if group not found.

        Examples:
            >>> from vnstock_data.api.listing import Listing
            >>> from vnstock_data.enums import IndexGroup
            >>> lst = Listing()
            >>> # Using string short names
            >>> lst.indices_by_group('HOSE')
            >>> # Using enum values
            >>> lst.indices_by_group(IndexGroup.SECTOR)
            >>> # Using full names
            >>> lst.indices_by_group('HOSE Indices')
        """
        from vnstock.common import indices as market_indices
        # Extract group from args or kwargs
        group = kwargs.get('group')
        if group is None and len(args) > 0:
            group = args[0]
        
        # Normalize short names or enum values to full names
        group = _normalize_index_group(group)
        
        return market_indices.get_indices_by_group(group)
