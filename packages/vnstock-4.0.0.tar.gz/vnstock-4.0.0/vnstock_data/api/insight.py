# vnstock_data/api/insight.py

from vnstock_data.base import BaseAdapter, dynamic_method

class TopStock(BaseAdapter):
    """
    Adapter for VND TopStock “insight” APIs.  Only supports source="vnd".
    """
    _module_name = "insight"
    SUPPORTED_SOURCES = ['vnd']

    def __init__(self, source: str = 'vnd', **kwargs):
        source_lower = source.lower()
        if source_lower not in self.SUPPORTED_SOURCES:
            raise ValueError(
                "Lớp TopStock chỉ nhận giá trị tham số source là 'VND'. " +
                "Nhưng nhận được '" + source + "'."
            )
        super().__init__(source=source_lower, **kwargs)

    @dynamic_method
    def gainer(self, index: str = 'VNINDEX', limit: int = 10):
        """
        Top 10 gainers in the given index.
        """
        pass

    @dynamic_method
    def loser(self, index: str = 'VNINDEX', limit: int = 10):
        """
        Top 10 losers in the given index.
        """
        pass

    @dynamic_method
    def value(self, index: str = 'VNINDEX', limit: int = 10):
        """
        Top 10 by trading value in the given index.
        """
        pass

    @dynamic_method
    def volume(self, index: str = 'VNINDEX', limit: int = 10):
        """
        Top 10 by abnormal volume in the given index.
        """
        pass

    @dynamic_method
    def deal(self, index: str = 'VNINDEX', limit: int = 10):
        """
        Top 10 by block trade volume in the given index.
        """
        pass

    @dynamic_method
    def foreign_buy(self, date: str = None, limit: int = 10):
        """
        Top 10 net foreign buys on the given date.
        """
        pass

    @dynamic_method
    def foreign_sell(self, date: str = None, limit: int = 10):
        """
        Top 10 net foreign sells on the given date.
        """
        pass
