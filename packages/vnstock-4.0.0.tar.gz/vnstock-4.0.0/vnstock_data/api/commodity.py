# vnstock_data/api/commodity.py

from vnstock_data.base import BaseAdapter, dynamic_method
from typing import Optional, Union

class CommodityPrice(BaseAdapter):
    """
    Adapter for commodity prices from various SPL‐based providers.

    Usage:
        from vnstock_data.api.commodity import CommodityPrice
        c = CommodityPrice(source="spl", start="2024-01-01", end="2024-04-01", show_log=False)
        df = c.gold_vn()
    """
    _module_name = "commodity"

    def __init__(
        self,
        source: str = "spl",
        start: Optional[str] = None,
        end: Optional[str] = None,
        length: Optional[Union[str, int]] = None,
        show_log: bool = False
    ):
        # Validate the source to only accept spl
        if source.lower() != "spl":
            raise ValueError("Lớp Commodity chỉ nhận giá trị tham số source là 'SPL'.")
        # BaseAdapter __init__ signature is (source, symbol=None, **kwargs)
        # SPL’s CommodityPrice expects start, end, show_log
        super().__init__(
            source=source,
            symbol=None,
            start=start,
            end=end,
            length=length,
            show_log=show_log
        )

    @dynamic_method
    def gold_vn(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None):
        """Vietnam gold prices (buy & sell)."""
        pass

    @dynamic_method
    def gold_global(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None):
        """Global gold price."""
        pass

    @dynamic_method
    def gas_vn(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None):
        """Vietnam gasoline & diesel prices."""
        pass

    @dynamic_method
    def oil_crude(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None):
        """Crude oil price."""
        pass

    @dynamic_method
    def gas_natural(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None):
        """Natural gas price."""
        pass

    @dynamic_method
    def coke(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None):
        """Coke price."""
        pass

    @dynamic_method
    def steel_d10(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None):
        """Vietnam rebar D10 price."""
        pass

    @dynamic_method
    def iron_ore(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None):
        """Iron ore price."""
        pass

    @dynamic_method
    def steel_hrc(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None):
        """Hot‑rolled coil (HRC) steel price."""
        pass

    @dynamic_method
    def fertilizer_ure(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None):
        """Urea fertilizer price."""
        pass

    @dynamic_method
    def soybean(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None):
        """Soybean price."""
        pass

    @dynamic_method
    def corn(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None):
        """Corn price."""
        pass

    @dynamic_method
    def sugar(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None):
        """Sugar price."""
        pass

    @dynamic_method
    def pork_north_vn(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None):
        """Northern Vietnam live hog price."""
        pass

    @dynamic_method
    def pork_china(self, start: Optional[str] = None, end: Optional[str] = None, length: Optional[Union[str, int]] = None):
        """China live hog price."""
        pass
