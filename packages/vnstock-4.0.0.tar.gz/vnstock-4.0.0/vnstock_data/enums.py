"""
Enumerations for vnstock_data library.

Provides standardized enum types for common parameters and options.
"""

from enum import Enum


class IndexGroup(str, Enum):
    """
    Enumeration for standardized market index groups.
    
    Provides short names for easy reference with automatic mapping to full names.
    Inherits from str for ease of use with string-based APIs.
    
    Examples:
        >>> from vnstock_data.enums import IndexGroup
        >>> IndexGroup.HOSE
        <IndexGroup.HOSE: 'HOSE'>
        >>> IndexGroup.HOSE.value
        'HOSE'
        >>> IndexGroup.HOSE.full_name
        'HOSE Indices'
    """
    HOSE = "HOSE"
    SECTOR = "SECTOR"
    INVESTMENT = "INVESTMENT"
    VNX = "VNX"
    
    @property
    def full_name(self) -> str:
        """Get the full name of the index group."""
        mapping = {
            "HOSE": "HOSE Indices",
            "SECTOR": "Sector Indices",
            "INVESTMENT": "Investment Indices",
            "VNX": "VNX Indices",
        }
        return mapping[self.value]
    
    def __str__(self) -> str:
        """Return the short name as string representation."""
        return self.value
