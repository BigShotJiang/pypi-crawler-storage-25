---
variable: TfForPeng_Belopp
display_name: "Tillfällig föräldrapenning, ersättningsbelopp"
tags:
  - topic/income
  - topic/social-insurance
  - type/variable
source: "lisa-bakgrundsfakta-1990-2017"
---

#### **Tillfällig föräldrapenning, ersättningsbelopp TfForPeng_Belopp**

**TfForPeng_Belopp**

(1994–)

Beloppet anges i hundratals kronor.

Utbetalt belopp under året för tillfällig föräldrapenning, står i relation till utbetalda dagar med tillfällig föräldrapenning. Utbetalt belopp avser ersättningsperioden.

*För ytterligare information, se under Tillfällig föräldrapenning för vård av barn* ([[ForVAB]]).

(1994–)

Antal utbetalda bruttodagar under året med graviditetspenningen.

Graviditetspenningen kan betalas ut som hel (100 procent), tre fjärdedels (75 procent), halv (50 procent), en fjärdedels (25 procent) eller en åttondels ersättning (12,5 procent). Antal bruttodagar visar antal dagar under ett år oavsett ovan omfattning.

Graviditetspenning[^73] är en ersättning som gravida kvinnor kan få p.g.a. risker i arbetsmiljön eller ett fysiskt ansträngande arbete. Graviditetspenning betalas endast ut om arbetsgivaren inte kan omplacera eller erbjuda den gravida kvinnan arbetsuppgifter som går att utföra trots graviditeten.

Graviditetspenning p.g.a. risker i arbetsmiljön som kan skada barnet betalas ut under hela graviditeten. Graviditet p.g.a. fysiskt ansträngande arbete kan betalas ut i 50 dagar från och med den 60:e dagen före den beräknade födseln. De sista 10 dagarna innan beräknad födsel kan kvinnan alltså inte få ersättning med graviditetspenning, dock med föräldrapenning. Arbetsförmågan måste vara nedsatt med minst en fjärdedel.

[^73]: När ersättningen infördes 1980 hette den Havandeskapspenning. Ersättningen ändrade namn 2011 till Graviditetspenning.
