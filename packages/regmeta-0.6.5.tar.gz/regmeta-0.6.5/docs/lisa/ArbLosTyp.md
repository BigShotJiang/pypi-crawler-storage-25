---
variable: ArbLosTyp
display_name: "Förekomst av arbetslöshetsersättning"
tags:
  - topic/employment
  - topic/income
  - type/variable
source: "lisa-bakgrundsfakta-1990-2017"
---

#### **Förekomst av arbetslöshetsersättning ArbLosTyp**

ArbLosTyp

Markering för om individ under aktuellt år erhållit någon arbetslöshetsersättning.

*AKassa, [[KAS]]* (1990–1998), *[[KASEES]]* (1994–1997) och *[[AMK]]* (1994–1997).

*För mer detaljerad information om förändrat regelverk, ändrade ersättningsnivåer m.m. som kan påverka denna variabel över tid, se under respektive inkomstslag under Arbetslöshet.*

(1996–)

Antal dagar i sökandekategori[^87]:

• Tillfällig timanställning (22)

Har funnits som en egen sökandekategori sedan 1996-04. De arbetssökande tillfälligt timanställda är att, tillsammans med de deltidsarbetslösa, betrakta som undersysselsatta. Till skillnad från dem som tillhör sökandekategori 21 (deltidsarbetslösa) saknar de tillfälligt timanställda ett fast arbetsschema. Arbetet är av tillfällig karaktär (s.k. springvikarier, behovsanställda). Före 1996–04 var 80 procent av de arbetslösa timanställda registrerade som arbetslösa, medan 20 procent av dem var registrerade som deltidsarbetslösa.

År 2005 införs strängare riktlinjer för att tillhöra denna sökandekategori. Arbetets omfattning måste bedömas uppgå till minst åtta timmar per vecka i genomsnitt under en månad.

Personer med tillfällig timanställning som påbörjar ett program parallellt med sin timanställning ska registreras med programmets kod.

*Antal dagar för varje individ och år räknas fram med hjälp av inskrivningsoch avaktualiseringsdatum för aktuell sökandekategori[^88] .*

**Antal personer som någon gång under respektive år har tillhört sökandekategori tillfällig timanställning (sökandekategori 22)**

| År   | Antal   |
|------|---------|
| 1996 | 123 171 |
| 1997 | 194 128 |
| 1998 | 230 610 |
| 1999 | 248 079 |
| 2000 | 238 455 |
| 2001 | 212 620 |
| 2002 | 211 103 |
| 2003 | 221 719 |
| 2004 | 247 140 |
| 2005 | 256 332 |
| 2006 | 258 928 |
| 2007 | 225 949 |

| År   | Antal   |
|------|---------|
| 2008 | 180 006 |
| 2009 | 169 003 |
| 2010 | 165 137 |
| 2011 | 147 411 |
| 2012 | 148 423 |
| 2013 | 146 769 |
| 2014 | 128 963 |
| 2015 | 116 613 |
| 2016 | 110 048 |
| 2017 | 101 636 |

*Antal dagar i tillfällig timanställning är för vissa personer överskattad. Förmodligen är detta problem större vad gäller de tillfälligt timanställda än vad gäller exempelvis arbetslösa på heltid.*

[^87]: Inom parentes anges sökandekategorinummer i Arbetsförmedlingens sökanderegister.
[^88]: Dessa data har härletts från Arbetsförmedlingens Datalager som omfattar samtliga händelser (=arbetssökandeperioder) från och med 1991-08. För information avseende bearbetningen av data från Datalagret, se bilaga 2.
