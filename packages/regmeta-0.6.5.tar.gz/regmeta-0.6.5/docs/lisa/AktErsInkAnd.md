---
variable: AktErsInkAnd
display_name: "Andel/grad för aktivitetsersättning (inkomstrelaterad)"
tags:
  - topic/employment
  - topic/social-insurance
  - type/variable
source: "lisa-bakgrundsfakta-1990-2017"
---

#### **Andel/grad för aktivitetsersättning (inkomstrelaterad) AktErsInkAnd**

AktErsInkAnd

(2003–)

Ger information om vilken grad av aktivitetsersättningen som erhållits vid sista utbetalning under året.

Kodförteckning:

00 = 0/0, 0 % utbetalt

01 = 1/1, 100 % utbetalt

02 = 1/2, 50 % utbetalt

03 = 3/4, 75 % utbetalt

04 = 1/4, 25 % utbetalt
