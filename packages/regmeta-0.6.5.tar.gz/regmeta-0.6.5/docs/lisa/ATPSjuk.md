---
variable: ATPSjuk
display_name: "Sjukbidrag från folkpension, egenförmån"
tags:
  - topic/social-insurance
  - type/variable
source: "lisa-bakgrundsfakta-1990-2017"
---

**Sjukbidrag från folkpension, egenförmån ATPSjuk**

ATPSiuk

(1990–1992)

Beloppet anges i hundratal kronor.

(1993–2002)

Beloppet anges i hundratal kronor.

*Variabeln härleds utifrån det ATP-belopp som betalats ut under aktuellt år och den ATP-kod för egenförmån som anger typ av ATP-pension den 31/12 aktuellt år[^125] (för beskrivning av ATP-kod se under ATP-kod för egenförmån sid. 231).*

Förtidspension/Sjukbidrag från ATP avser inkomståret oavsett år för händelse.

För att få förtidspension från ATP måste man dels uppfylla villkoren för rätt till förtidspension/sjukbidrag från folkpensioneringen, dels haft ATP-grundande inkomster under ett visst antal år.

Förtidspension och sjukbidrag skall i princip motsvara den ålderspension som man skulle ha fått om man inte blivit invalidiserad före 65 års ålder.

Från och med år *2003* upphör förtidspension och sjukbidrag som ersättningssystem. I stället införs ersättningsslagen sjukersättning och aktivitetsersättning.

[^125]: Alternativt: Anger typ av ATP-pension vid sista utbetalning under året.
