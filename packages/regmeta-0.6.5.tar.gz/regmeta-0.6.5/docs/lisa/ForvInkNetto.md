---
variable: ForvInkNetto
display_name: "Summa inkomst av förvärvskälla inkl. underskott av näringsverksamhet"
tags:
  - topic/income
  - type/variable
source: "lisa-bakgrundsfakta-1990-2017"
---

**Summa inkomst av förvärvskälla inkl. underskott av näringsverksamhet ForvInkNetto**

ForvInkNetto

(2004–)

Beloppet anges i hundratals kronor.

Summerar variablerna *Kontant bruttolön* ([[LoneInk]]) och *Nettoinkomst av näringsverksamhet* ([[InkFNetto]]). Även negativa värden förekommer.

Även sjuklön ingår i *Summa inkomst av förvärvskälla*. Lagen om sjuklön infördes 1992. Från och med 1/1 1997 till och med 31/3 1998 omfattar sjuklöneperioden 28 dagar. Från och med 1/7 2003 till och med 31/12 2004 omfattar sjuklöneperioden 21 dagar, medan den under övriga perioder omfattar de 14 första dagarna av sjukfallet.

(2004–)

Beloppet anges i hundratals kronor.

Summerar variablerna *Kontant bruttolön* ([[LoneInk]]) och *Nettoinkomst av aktiv näringsverksamhet* ([[InkFNettoA]]). Även negativa värden förekommer.

Även sjuklön ingår i Summa inkomst av förvärvskälla. Lagen om sjuklön infördes 1992. Från och med 1/1 1997 till och med 31/3 1998 omfattar sjuklöneperioden 28 dagar. Från och med 1/7 2003 till och med 31/12 2004 omfattar sjuklöneperioden 21 dagar, medan den under övriga perioder omfattar de 14 första dagarna av sjukfallet.
