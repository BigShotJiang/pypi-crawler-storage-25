---
variable: HavPeng_Ndag
display_name: "Graviditetspenning, antal nettodagar"
tags:
  - topic/income
  - topic/social-insurance
  - type/variable
source: "lisa-bakgrundsfakta-1990-2017"
---

#### **Graviditetspenning, antal nettodagar HavPeng_Ndag**

HavPeng_Ndag

(1994–)

Antal utbetalda nettodagar under året med graviditetspenningen.

Graviditetspenningen kan betalas ut som hel (100 procent), tre fjärdedels (75 procent), halv (50 procent), en fjärdedels (25 procent) eller en åttondels ersättning (12,5 procent). Antal nettodagar är bruttodagar \*omfattningen under ett år.

10 \* hel omfattning = 10 nettodagar,

10 \* tre kvarts omfattning = 7,5 nettodagar,

10 \* halv omfattning = 5 nettodagar,

10 \* en kvarts omfattning = 2,5 nettodagar,

10 \* en åttondels omfattning = 1,25 dagar

*För ytterligare information, se under Graviditetspenning, antal bruttodagar* ([[HavPeng_Bdag]]).
