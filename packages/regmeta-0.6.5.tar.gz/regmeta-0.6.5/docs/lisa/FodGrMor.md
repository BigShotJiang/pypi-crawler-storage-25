---
variable: FodGrMor
display_name: "Moderns födelseland, gruppering EU15"
tags:
  - topic/demographic
  - type/variable
source: "lisa-bakgrundsfakta-1990-2017"
---

#### **Moderns födelseland, gruppering EU15 FodGrMor**

FodGrMor

Grupperas som födelseland, se *Eget födelseland* ([[FodGrEg]]).

Moderns födelseland finns i en icke årgångsbunden databastabell. Tabellen omfattar samtliga personer i LISA-populationen.

*I övrigt se under Moderns födelseland* (FodelseLandNamnMor).
