---
variable: AktErs_Ndag_MiDAS
display_name: "Aktivitetsersättning, antal nettodagar"
tags:
  - topic/employment
  - topic/social-insurance
  - type/variable
source: "lisa-bakgrundsfakta-1990-2017"
---

#### **Aktivitetsersättning, antal nettodagar AktErs_Ndag_MiDAS**

[[AktErs]]*Ndaq*MiDAS

(2003–)

Antal utbetalda nettodagar under året med aktivitetsersättning.

Aktivitetsersättning kan betalas ut som hel (100 procent), tre fjärdedels (75 procent), halv (50 procent) eller en fjärdedels (25 procent). Antal nettodagar är bruttodagar \*omfattningen under ett år.

- 10 \* hel omfattning = 10 nettodagar,
- 10 \* tre kvarts omfattning = 7,5 nettodagar,
- 10 \* halv omfattning = 5 nettodagar,
- 10 \* en kvarts omfattning = 2,5 nettodagar

*För ytterligare information om aktivitetsersättning se under Sjukersättning* ([[SjukErs]]).

(2003–)

Beloppet anges i hundratal kronor.

Utbetalt belopp under året för aktivitetsersättning, står i relation till utbetalda dagar med aktivitetsersättning. Utbetalt belopp avser ersättningsperioden.

*För ytterligare information om aktivitetsersättning se under Sjukersättning* ([[SjukErs]]).
