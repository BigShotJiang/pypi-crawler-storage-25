---
variable: KU3CfarNr
display_name: "Arbetsställe (tredje största förvärvskälla)"
tags:
  - topic/identifier
  - type/variable
source: "lisa-bakgrundsfakta-1990-2017"
---

#### **Arbetsställe (tredje största förvärvskälla) KU3CFARNr**

**KU3CFARNr**

Det arbetsställe som kan kopplas till den förvärvskälla som enligt Jobbregistret gett individen tredje störst inkomstbelopp i form av löneinkomst eller inkomst av näringsverksamhet[^37] under aktuellt år[^38] . Arbetsstället identifieras med hjälp av en arbetsställeidentitet (CFAR-nummer).

Se även beskrivning under *Arbetsställe (november)* (CFARNr_LISA).

*Vid utlämnade av data från LISA ersätts KU3CFARNr av ett nytt löpnummer.*

[^37]: 1990-2003 ingår endast inkomst av aktiv näringsverksamhet.
[^38]: 1990 utgjordes underlaget till företagarinkomsten av Inkomst av rörelse/Inkomst av Jordbruksfastighet (brukad) för 1989.
