from collections import OrderedDict
import json
import requests
import urllib.parse
import os

from .statuses import (
    HTTP_STATUS_TOO_MANY_REQUESTS,
)
from .request import (
    request_encode,
    PageRequestObject,
)
from .response import (
    PageResponseObject,
    json_to_response,
    response_to_json,
)


class RemoteServer(object):
    """
    Crawler buddy communication class
    """

    def __init__(self, remote_server=None, timeout_s=30):
        self.remote_server = remote_server
        if not self.remote_server:
            self.remote_server = RemoteServer.get_remote_server_location()

        self.timeout_s = timeout_s

    def get_remote_server_location():
        CRAWLER_BUDDY_SERVER = os.environ.get("CRAWLER_BUDDY_SERVER")
        CRAWLER_BUDDY_PORT = os.environ.get("CRAWLER_BUDDY_PORT")
        if CRAWLER_BUDDY_SERVER and CRAWLER_BUDDY_PORT:
            return f"http://{CRAWLER_BUDDY_SERVER}:{CRAWLER_BUDDY_PORT}"

    def get_getj(self, request=None, url=None):
        """
        @returns None in case of error
        """
        if url and not request:
            request = PageRequestObject(url)
            request.url = url
            request.url = request.url.strip()

        if not request or not request.url:
            return

        link = self.remote_server
        link = f"{link}/getj"

        return self.perform_remote_call(link_call=link, request=request)

    def get_feedsj(self, request=None, url=None):
        """
        @returns None in case of error
        """

        if url and not request:
            request = PageRequestObject(url)
            request.url = url
            request.url = request.url.strip()

        if not request or not request.url:
            return

        link = self.remote_server
        link = f"{link}/feedsj"

        return self.perform_remote_call(link, request)

    def get_socialj(self, request=None, url=None):
        """
        @returns None in case of error
        """

        if url and not request:
            request = PageRequestObject(url)
            request.url = url
            request.url = request.url.strip()

        if not request or not request.url:
            return

        link = self.remote_server
        link = f"{link}/socialj"

        return self.perform_remote_call(link, request)

    def get_linkj(self, request=None, url=None):
        """
        @returns None in case of error
        """
        if url and not request:
            request = PageRequestObject(url)
            request.url = url
            request.url = request.url.strip()

        if not request or not request.url:
            return

        link = self.remote_server
        link = f"{link}/linkj"

        return self.perform_remote_call(link, request)

    def get_pingj(self, request=None, url=None):
        """
        @returns None in case of error
        """
        if url and not request:
            request = PageRequestObject(url)
            request.url = url
            request.url = request.url.strip()

        if not request or not request.url:
            return

        link = self.remote_server
        link = f"{link}/pingj"

        json = self.perform_remote_call_with_retry(link, request)
        if json:
            return json.get("status")

    def perform_remote_call_with_retry(self, link_call, request):
        """
        This function may make the call several times (in case server is busy).
        This could be dangerous, so not doing it right now
        """

        return self.perform_remote_call(link_call, request)

    def perform_remote_call(self, link_call, request):
        """
        @param link_call Remote server endpoint
        @param url Url for which we call Remote server

        Note: there should always be a timeout. Server might stop responding,
        it could have hanged, etc.
        """
        url = request.url

        encoded_request = request_encode(request)

        link_call = f"{link_call}?{encoded_request}"

        text = None

        # it is hard to think of a good deafult value
        timeout_s = 60
        if request.timeout_s is not None:
            # remote server will have timeout_s we add some wiggle room for transmission
            timeout_s = request.timeout_s
            timeout_s += 5

        print(f"Remote server: Calling {link_call}")

        try:
            with requests.get(url=link_call, timeout=timeout_s, verify=False) as result:
                text = result.text
        except Exception as E:
            print("Remote error. " + str(E))
            return

        if not text:
            print("Remote error. No text")
            return

        # print("Calling:{}".format(link))

        json_obj = None
        try:
            json_obj = json.loads(text)
        except ValueError as E:
            print(
                "Url:{} Remote error. Value error in response".format(link_call, text)
            )
            print(str(E))
            return
        except TypeError as E:
            print("Url:{} Remote error. Type error response".format(link_call, text))
            print(str(E))
            return

        if "success" in json_obj and not json_obj["success"]:
            print("Url:{} Remote error. Not a success".format(link_call))
            return
        return json_obj

    def get_properties(self, url=None, request=None):
        json_obj = self.get_getj(url=url, request=request)

        if json_obj:
            return RemoteServer.read_properties_section("Properties", json_obj)

        return json_obj

    def read_properties_section(section_name, all_properties):
        if not all_properties:
            return

        if "success" in all_properties and not all_properties["success"]:
            # print("Url:{} Remote error. Not a success".format(link))
            print("Remote error. Not a success")
            return False

        for properties in all_properties:
            if section_name == properties["name"]:
                return properties["data"]

    def get_responses(all_properties):
        if not all_properties:
            return

        responses = OrderedDict()

        streams_data = RemoteServer.read_properties_section("Streams", all_properties)
        if streams_data and len(streams_data) > 0:
            for item in streams_data:
                response_data = streams_data[item]
                response = json_to_response(response_data)
                if response.url:
                    responses[item] = response

        return responses

    def get_response(all_properties):
        responses = RemoteServer.get_responses(all_properties)
        if not responses:
            return

        if "Default" in responses:
            return responses["Default"]
        for url in responses:
            return responses[url]

    def encode(data):
        return urllib.parse.quote(data, safe="")

    def get_infoj(self):
        link = self.remote_server
        link = f"{link}/infoj"

        timeout_s = 10

        try:
            with requests.get(url=link, timeout=timeout_s, verify=False) as result:
                text = result.text
        except Exception as E:
            print("Remote error. " + str(E))
            return

        if not text:
            print("Remote error. No text")
            return

        # print("Calling:{}".format(link))

        json_obj = None
        try:
            json_obj = json.loads(text)
            return json_obj
        except ValueError as E:
            print(
                "Url:{} Remote error. Value error in response".format(link_call, text)
            )
            print(str(E))
            return
        except TypeError as E:
            print("Url:{} Remote error. Type error response".format(link_call, text))
            print(str(E))
            return

    def set(self, response, crawl_id=None, url=None, crawler_name=None, handler_name=None):
        """
        args - params
        """
        timeout_s = 60
        remote_server = self.remote_server

        response_json = response_to_json(response)

        params = {}
        if url:
            params["url"] = url
        if crawl_id:
            params["crawl_id"] = crawl_id
        if crawler_name:
            params["crawler_name"] = crawler_name
        if handler_name:
            params["handler_name"] = handler_name

        link_call = f"{remote_server}/set"
        try:
            r = requests.post(url=link_call,
                          timeout=timeout_s,
                          verify=False,
                          json=response_json,
                          params=params)
            r.close()

            if r.status_code == 200:
                return True

            #r.raise_for_status()

        except requests.RequestException as E:
            print(str(response_json))

    def findj(self, crawl_id=None, url=None, crawler_name=None, handler_name=None):
        timeout_s = 60
        remote_server = self.remote_server

        link_call = f"{remote_server}/findj"

        params = {}
        if url:
            params["url"] = url
        if crawl_id:
            params["crawl_id"] = crawl_id
        if crawler_name:
            params["crawler_name"] = crawler_name
        if handler_name:
            params["handler_name"] = handler_name

        with requests.get(link_call, params=params) as response:
            if response.status_code == 200:
                try:
                    data = response.json()
                    return data
                except Exception as E:
                    print("Response content is not valid JSON. {}".format(E))
