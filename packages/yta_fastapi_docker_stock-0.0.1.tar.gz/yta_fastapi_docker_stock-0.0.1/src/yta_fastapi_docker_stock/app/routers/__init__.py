from fastapi import APIRouter
from fastapi.responses import JSONResponse


PREFIX = f''

router = APIRouter(
    prefix = PREFIX
)

@router.get('/check-status')
def route_check_status(
) -> JSONResponse:
    return JSONResponse(
        {
            'error': False,
            'message': 'Hello World!'
        },
        status_code = 200
    )