from yta_stock import Stock
from fastapi import APIRouter
from fastapi.responses import JSONResponse, StreamingResponse


PREFIX = f'/stock'

router = APIRouter(
    prefix = PREFIX
)

@router.get('/image')
def get_stock_image(
    query: str
    # TODO: Add 'ids_to_ignore' to avoid repeated
) -> JSONResponse:
    stock = Stock(do_ignore_repeated = False)

    # To show it in the web navigator
    # return StreamingResponse(
    #     stock.videos.stream_random(
    #         query = query,
    #         # TODO: We need to handle this somehow
    #         ids_to_ignore = []
    #     ),
    #     media_type = 'image/png',
    #     headers = {
    #         "Content-Disposition": "inline"
    #     }
    # )

    # To let it be downloaded
    return StreamingResponse(
        stock.images.stream_random(
            query = query,
            # TODO: We need to handle this somehow
            ids_to_ignore = []
        ),
        media_type = 'application/octet-stream',
        headers = {
            "Content-Disposition": "attachment; filename=image.png"
        }
    )

@router.get('/video')
def get_stock_video(
    query: str
    # TODO: Add 'ids_to_ignore' to avoid repeated
) -> JSONResponse:
    stock = Stock(do_ignore_repeated = False)

    # To show it in the web navigator
    # return StreamingResponse(
    #     stock.videos.stream_random(
    #         query = query,
    #         # TODO: We need to handle this somehow
    #         ids_to_ignore = []
    #     ),
    #     media_type = 'video/mp4',
    #     headers = {
    #         "Content-Disposition": "inline"
    #     }
    # )

    # To let it be downloaded
    return StreamingResponse(
        stock.videos.stream_random(
            query = query,
            # TODO: We need to handle this somehow
            ids_to_ignore = []
        ),
        media_type = 'application/octet-stream',
        headers = {
            "Content-Disposition": "attachment; filename=video.mp4"
        }
    )
