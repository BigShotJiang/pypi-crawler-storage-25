from fastapi.responses import StreamingResponse
import requests


CHUNK_SIZE = 8192

def _stream_video_response_from_url(
    url: str,
    filename: str
) -> StreamingResponse:
    """
    *For internal use only*

    Stream a video that has been received from a url as
    a response.
    """
    response = requests.get(url, stream = True)

    return StreamingResponse(
        response.iter_content(chunk_size = CHUNK_SIZE),
        media_type = "video/mp4",
        headers = {
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Length": response.headers.get("content-length"),
        },
    )