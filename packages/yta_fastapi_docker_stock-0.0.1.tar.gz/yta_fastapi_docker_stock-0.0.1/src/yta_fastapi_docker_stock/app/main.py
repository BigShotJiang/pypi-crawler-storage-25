from yta_fastapi_docker_stock.app.routers import router as general_router
from yta_fastapi_docker_stock.app.routers.stock import router as stock_router
from fastapi import FastAPI


app = FastAPI()

# Include all the routers we have
app.include_router(general_router)
app.include_router(stock_router)