# Youtube Autonomous FastAPI Docker Stock Module

The module that is providing the functionality related to stock videos and images (downloading them) through a FastAPI that is included and isolated in a Docker container but exposed to the internal and general FastAPI.

### Endpoints

#### GET
No endpoints yet

#### POST
No endpoints yet