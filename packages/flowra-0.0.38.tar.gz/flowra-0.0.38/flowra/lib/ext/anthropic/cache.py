"""Anthropic prompt caching hook bundles.

Composable hook bundles that set ``cache_control`` on blocks and tools
via ``AnthropicBlockExtra`` / ``AnthropicToolExtra`` typed accessors.

Each bundle handles one caching slot (system, tools, or messages).
The ``NonTransient*`` bundles respect the ``transient`` hint on
blocks/messages/tools — transient content is not cached. The ``*All*``
bundles cache the last block regardless of ``transient``.
"""

import dataclasses
from collections.abc import Sequence

from ....agent import AgentRuntime, Event, HookSubscription
from ....llm import LLMData, LLMRequest, Message
from ....llm.providers.anthropic_vertex import AnthropicCacheable
from ...chat import SaveHistoryEvent
from ...tool_loop import PrepareLLMRequestEvent

type HookTarget = AgentRuntime | HookSubscription


def _resolve_hooks(target: HookTarget) -> HookSubscription:
    if isinstance(target, HookSubscription):
        return target
    return target.hooks


__all__ = [
    "AnthropicCacheAllMessages",
    "AnthropicCacheAllSystemMessages",
    "AnthropicCacheAllTools",
    "AnthropicCacheHistoryMessages",
    "AnthropicCacheNonTransientMessages",
    "AnthropicCacheNonTransientSystemMessages",
    "AnthropicCacheNonTransientTools",
]

_HISTORY_BREAKPOINT_KEY = "_anthropic_history_cache_breakpoint"


# -- Helpers --


def _set_cache(obj: LLMData) -> None:
    AnthropicCacheable(cache_control={"type": "ephemeral"}).write_to(obj)


def _clear_cache(obj: LLMData) -> None:
    AnthropicCacheable(cache_control=None).write_to(obj)


def _clear_message_cache(messages: Sequence[Message]) -> None:
    for m in messages:
        for b in m.blocks:
            _clear_cache(b)


def _cache_last_block(messages: Sequence[Message]) -> None:
    if not messages:
        return
    _clear_message_cache(messages)
    last = messages[-1]
    if last.blocks:
        _set_cache(last.blocks[-1])


def _cache_last_non_transient_block(messages: Sequence[Message]) -> None:
    if not messages:
        return
    _clear_message_cache(messages)
    target_idx = -1
    for i in range(len(messages)):
        if messages[i].transient:
            break
        target_idx = i
    if target_idx >= 0:
        msg = messages[target_idx]
        if msg.blocks:
            block_idx = -1
            for j in range(len(msg.blocks)):
                if msg.blocks[j].transient:
                    break
                block_idx = j
            if block_idx >= 0:
                _set_cache(msg.blocks[block_idx])


# -- System message caching --


class AnthropicCacheAllSystemMessages:
    """Cache the last block of the last system message."""

    __slots__ = ()

    def install(self, target: HookTarget) -> None:
        _resolve_hooks(target).on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if request.system:
            _cache_last_block(request.system)


class AnthropicCacheNonTransientSystemMessages:
    """Cache the last non-transient block in the non-transient prefix."""

    __slots__ = ()

    def install(self, target: HookTarget) -> None:
        _resolve_hooks(target).on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if request.system:
            _cache_last_non_transient_block(request.system)


# -- Tool caching --


class AnthropicCacheAllTools:
    """Cache the last tool definition."""

    __slots__ = ()

    def install(self, target: HookTarget) -> None:
        _resolve_hooks(target).on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if not request.tools:
            return
        for tool in request.tools:
            _clear_cache(tool)
        _set_cache(request.tools[-1])


class AnthropicCacheNonTransientTools:
    """Cache the last non-transient tool in the non-transient prefix."""

    __slots__ = ()

    def install(self, target: HookTarget) -> None:
        _resolve_hooks(target).on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if not request.tools:
            return
        for tool in request.tools:
            _clear_cache(tool)
        target_idx = -1
        for i in range(len(request.tools)):
            if request.tools[i].transient:
                break
            target_idx = i
        if target_idx >= 0:
            _set_cache(request.tools[target_idx])


# -- Message caching --


class AnthropicCacheAllMessages:
    """Cache the last block of the last message."""

    __slots__ = ()

    def install(self, target: HookTarget) -> None:
        _resolve_hooks(target).on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if request.messages:
            _cache_last_block(request.messages)


class AnthropicCacheNonTransientMessages:
    """Cache the last non-transient block in the non-transient prefix."""

    __slots__ = ()

    def install(self, target: HookTarget) -> None:
        _resolve_hooks(target).on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if request.messages:
            _cache_last_non_transient_block(request.messages)


class AnthropicCacheHistoryMessages:
    """Cache the last message that was in history before the current turn.

    Hooks into ``SaveHistoryEvent`` to mark the last message with a metadata
    breakpoint. In ``PrepareLLMRequestEvent``, finds that marker and sets
    ``cache_control`` on its last block. This avoids cache invalidation on
    every new user message — the cache breakpoint stays on the history boundary.

    Requires ``ChatAgent`` (which emits ``SaveHistoryEvent``).
    """

    __slots__ = ()

    def install(self, target: HookTarget) -> None:
        hooks = _resolve_hooks(target)
        hooks.on(SaveHistoryEvent, self.on_save_history)
        hooks.on(PrepareLLMRequestEvent, self.on_prepare)

    @staticmethod
    def on_save_history(event: Event[SaveHistoryEvent]) -> None:
        messages = event.data.messages
        if not messages:
            return
        last = messages[-1]
        if last.blocks:
            messages[-1] = dataclasses.replace(last, metadata={**last.metadata, _HISTORY_BREAKPOINT_KEY: True})

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if not request.messages:
            return

        _clear_message_cache(request.messages)

        breakpoint_idx = -1
        for i, m in enumerate(request.messages):
            if m.metadata.get(_HISTORY_BREAKPOINT_KEY):
                breakpoint_idx = i

        if breakpoint_idx >= 0:
            msg = request.messages[breakpoint_idx]
            if msg.blocks:
                _set_cache(msg.blocks[-1])
