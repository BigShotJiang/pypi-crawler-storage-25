import base64
import json
from collections.abc import AsyncIterator
from typing import Any, ClassVar

from openai import AsyncOpenAI
from openai.types import CompletionUsage
from openai.types.chat import ChatCompletion
from openai.types.chat.chat_completion_message_function_tool_call import ChatCompletionMessageFunctionToolCall

from ..blocks import AssistantBlock, MediaBlock, TextBlock, ThinkingBlock, ToolResultBlock, ToolUseBlock
from ..messages import AssistantMessage, Message, SystemMessage, UserMessage
from ..openai_schema import make_schema_strict
from ..pricing import estimate_cost as pricing_estimate_cost
from ..provider import LLMProvider
from ..request import LLMRequest
from ..response import LLMResponse, StopReason, Usage
from ..schema_formatting import format_output_schema_for_description
from ..stream import ContentComplete, StreamEvent, TextDelta
from ..tools import Tool

__all__ = [
    "OpenAIProvider",
]


class OpenAIProvider(LLMProvider):
    __slots__ = ("__client", "__owns_client")

    __USAGE_KNOWN_FIELDS: ClassVar[set[str]] = {
        "prompt_tokens",
        "completion_tokens",
        "total_tokens",
        "prompt_tokens_details",
        "completion_tokens_details",
    }

    def __init__(
        self,
        *,
        client: AsyncOpenAI | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        organization: str | None = None,
        owns_client: bool = False,
    ) -> None:
        if client is not None:
            self.__client = client
            self.__owns_client = owns_client
        elif api_key is not None:
            self.__client = AsyncOpenAI(api_key=api_key, base_url=base_url, organization=organization)
            self.__owns_client = True
        else:
            raise ValueError("Either 'client' or 'api_key' must be provided")

    async def aclose(self) -> None:
        if self.__owns_client:
            await self.__client.close()

    async def call(self, request: LLMRequest) -> LLMResponse:
        return await self.__call_llm(request)

    async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
        kwargs = self.__build_kwargs(request)

        async with self.__client.chat.completions.stream(**kwargs) as api_stream:
            async for event in api_stream:
                if event.type == "content.delta":
                    yield TextDelta(text=event.delta)

            completion = await api_stream.get_final_completion()

        yield ContentComplete(response=self.__convert_response(completion, request.model))

    def __build_kwargs(self, request: LLMRequest) -> dict[str, Any]:
        openai_messages: list[dict[str, Any]] = []

        for message in request.system:
            openai_messages.extend(self.__convert_message(message))
        for message in request.messages:
            openai_messages.extend(self.__convert_message(message))

        kwargs: dict[str, Any] = {
            "model": request.model,
            "messages": openai_messages,
            "max_tokens": request.max_tokens or 4096,
        }

        if request.temperature is not None:
            kwargs["temperature"] = request.temperature

        if request.top_p is not None:
            kwargs["top_p"] = request.top_p

        if request.stop_sequences:
            kwargs["stop"] = request.stop_sequences

        if request.tools:
            kwargs["tools"] = [self.__convert_tool(tool) for tool in request.tools]

        if request.json_schema:
            strict_schema = make_schema_strict(request.json_schema)
            kwargs["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": "response",
                    "strict": True,
                    "schema": strict_schema,
                },
            }

        return kwargs

    async def __call_llm(self, request: LLMRequest) -> LLMResponse:
        kwargs = self.__build_kwargs(request)
        response: ChatCompletion = await self.__client.chat.completions.create(**kwargs)
        return self.__convert_response(response, request.model)

    @classmethod
    def __convert_message(cls, message: Message) -> list[dict[str, Any]]:
        match message:
            case SystemMessage(blocks=blocks):
                text = "\n\n".join(b.text for b in blocks)
                return [{"role": "system", "content": text}]

            case UserMessage(blocks=blocks):
                result: list[dict[str, Any]] = []
                content_parts: list[dict[str, Any]] = []

                for block in blocks:
                    match block:
                        case TextBlock(text=text):
                            content_parts.append({"type": "text", "text": text})
                        case MediaBlock(data=data, media_type=media_type, filename=filename):
                            b64 = base64.b64encode(data).decode()
                            data_uri = f"data:{media_type};base64,{b64}"
                            if media_type.startswith("image/"):
                                content_parts.append({"type": "image_url", "image_url": {"url": data_uri}})
                            else:
                                file_data: dict[str, str] = {"file_data": data_uri}
                                if filename:
                                    file_data["filename"] = filename
                                content_parts.append({"type": "file", "file": file_data})
                        case ToolResultBlock(tool_use_id=tool_use_id, content=content, is_error=is_error):
                            if content_parts:
                                result.append({"role": "user", "content": cls.__simplify_content(content_parts)})
                                content_parts = []
                            tool_msg: dict[str, Any] = {
                                "role": "tool",
                                "content": content,
                                "tool_call_id": tool_use_id,
                            }
                            if is_error:
                                tool_msg["content"] = f"Error: {content}"
                            result.append(tool_msg)

                if content_parts:
                    result.append({"role": "user", "content": cls.__simplify_content(content_parts)})

                return result

            case AssistantMessage(blocks=blocks):
                text_parts: list[str] = []
                tool_calls: list[dict[str, Any]] = []

                for block in blocks:
                    match block:
                        case TextBlock(text=text):
                            text_parts.append(text)
                        case ToolUseBlock(id=id_, name=name, input=input_):
                            arguments = input_ if isinstance(input_, str) else json.dumps(input_ or {})
                            tool_calls.append(
                                {
                                    "id": id_,
                                    "type": "function",
                                    "function": {
                                        "name": name,
                                        "arguments": arguments,
                                    },
                                }
                            )
                        case ThinkingBlock():
                            pass  # not supported by OpenAI API

                msg: dict[str, Any] = {"role": "assistant"}
                if text_parts:
                    msg["content"] = "\n".join(text_parts)
                if tool_calls:
                    msg["tool_calls"] = tool_calls

                return [msg]

    @staticmethod
    def __simplify_content(parts: list[dict[str, Any]]) -> str | list[dict[str, Any]]:
        if len(parts) == 1 and parts[0]["type"] == "text":
            return parts[0]["text"]
        return parts

    @staticmethod
    def __convert_tool(tool: Tool) -> dict[str, Any]:
        description = tool.description
        if tool.output_schema:
            description += format_output_schema_for_description(tool.output_schema)

        return {
            "type": "function",
            "function": {
                "name": tool.name,
                "description": description,
                "parameters": tool.input_schema or {"type": "object", "properties": {}},
            },
        }

    @classmethod
    def __convert_response(cls, response: ChatCompletion, model: str) -> LLMResponse:
        choice = response.choices[0] if response.choices else None

        blocks: list[AssistantBlock] = []
        stop_reason = StopReason.OTHER
        stop_sequence: str | None = None

        if choice:
            if choice.message.content:
                blocks.append(TextBlock(text=choice.message.content))

            if choice.message.tool_calls:
                for tc in choice.message.tool_calls:
                    if not isinstance(tc, ChatCompletionMessageFunctionToolCall):
                        continue
                    blocks.append(
                        ToolUseBlock(
                            id=tc.id,
                            name=tc.function.name,
                            input=tc.function.arguments,
                        )
                    )

            match choice.finish_reason:
                case "stop":
                    stop_reason = StopReason.END_TURN
                case "length":
                    stop_reason = StopReason.MAX_TOKENS
                case "tool_calls":
                    stop_reason = StopReason.TOOL_USE
                case _:
                    stop_reason = StopReason.OTHER

        usage = cls.__convert_usage(response.usage, model) if response.usage else None

        extra: dict[str, Any] = {}
        if choice and choice.finish_reason:
            extra["provider_stop_reason"] = choice.finish_reason
        if response.id:
            extra["id"] = response.id

        return LLMResponse(
            messages=[AssistantMessage(blocks=blocks)],
            stop_reason=stop_reason,
            stop_sequence=stop_sequence,
            usage=usage,
            extra=extra,
        )

    @classmethod
    def __convert_usage(cls, usage_obj: CompletionUsage, model: str) -> Usage:
        cache_read = 0
        if usage_obj.prompt_tokens_details and usage_obj.prompt_tokens_details.cached_tokens:
            cache_read = usage_obj.prompt_tokens_details.cached_tokens

        input_tokens = max(0, usage_obj.prompt_tokens - cache_read)

        raw = usage_obj.model_dump(mode="json")
        extra: dict[str, Any] = {k: v for k, v in raw.items() if k not in cls.__USAGE_KNOWN_FIELDS and v is not None}

        pd = usage_obj.prompt_tokens_details
        if pd and pd.audio_tokens:
            extra["prompt_audio_tokens"] = pd.audio_tokens

        cd = usage_obj.completion_tokens_details
        reasoning_tokens = 0
        if cd:
            if cd.reasoning_tokens:
                extra["reasoning_tokens"] = cd.reasoning_tokens
                reasoning_tokens = int(cd.reasoning_tokens)
            if cd.audio_tokens:
                extra["completion_audio_tokens"] = cd.audio_tokens

        cost = pricing_estimate_cost(
            model,
            provider="openai",
            input_tokens=input_tokens,
            output_tokens=usage_obj.completion_tokens,
            cache_read_tokens=cache_read,
            reasoning_tokens=reasoning_tokens,
        )
        return Usage(
            input_tokens=input_tokens,
            output_tokens=usage_obj.completion_tokens,
            cache_read_input_tokens=cache_read,
            cost_usd=cost.total if cost is not None else None,
            cost=cost,
            extra=extra,
        )
