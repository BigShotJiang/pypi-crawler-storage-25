# Working with LLMs

Flowra provides a provider-agnostic LLM interface. This guide covers provider
setup, streaming, structured output, extended thinking, prompt caching, and
tool search.

For the basics (making a call, using ChatAgent), see
[Getting Started](getting-started.md).

## Providers

Flowra ships four providers. Each lives in its own module to avoid pulling in
unnecessary dependencies.

### AnthropicVertexProvider (Claude via Vertex AI)

```bash
pip install flowra[anthropic]
```

```python
from flowra.llm.providers.anthropic_vertex import AnthropicVertexProvider

# From credentials:
async with AnthropicVertexProvider(
    project="my-gcp-project",
    location="us-east5",
    credentials="<base64-encoded service account JSON>",
) as provider:
    ...

# Or with a pre-configured client:
from anthropic import AsyncAnthropicVertex
async with AnthropicVertexProvider(client=my_client) as provider:
    ...
```

### OpenAIProvider (OpenAI and compatible APIs)

```bash
pip install flowra[openai]
```

```python
from flowra.llm.providers.openai import OpenAIProvider

async with OpenAIProvider(api_key="sk-...") as provider:
    ...

# Custom base URL (e.g. Inception AI, local LLM servers):
async with OpenAIProvider(
    api_key="sk-...",
    base_url="https://api.inceptionlabs.ai/v1",
) as provider:
    ...
```

### OpenAIResponsesProvider (OpenAI Responses API)

```bash
pip install flowra[openai]
```

```python
from flowra.llm.providers.openai_responses import OpenAIResponsesProvider

async with OpenAIResponsesProvider(api_key="sk-...") as provider:
    ...
```

Uses the OpenAI Responses API instead of Chat Completions. Supports all
Responses API features including tool search with deferred tool loading.
Use this provider when you need tool search or want the Responses API
benefits (better caching, improved performance on reasoning models).

### GoogleVertexProvider (Gemini via Vertex AI)

```bash
pip install flowra[google]
```

```python
from flowra.llm.providers.google_vertex import GoogleVertexProvider

async with GoogleVertexProvider(
    project="my-gcp-project",
    location="us-east5",
    credentials="<base64-encoded service account JSON>",
) as provider:
    ...
```

## Making calls

All providers implement the same interface:

```python
from flowra.llm import LLMRequest, TextBlock, UserMessage

request = LLMRequest(
    model="claude-sonnet-4-5@20250929",
    messages=[UserMessage(blocks=[TextBlock(text="Hello!")])],
    max_tokens=256,
)

response = await provider.call(request)
print(response.message.blocks[0].text)
print(response.usage.input_tokens, response.usage.output_tokens)
print(response.usage.cost_usd)  # estimated cost
```

## Streaming

Stream text token by token. `ContentComplete` at the end carries the full
response:

```python
from flowra.llm import TextDelta, ThinkingDelta, ContentComplete

async for event in provider.stream(request):
    match event:
        case TextDelta(text=text):
            print(text, end="", flush=True)
        case ThinkingDelta(text=text):
            print(f"[thinking] {text}", end="")
        case ContentComplete(response=response):
            print()
            # response.usage, response.stop_reason, etc.
```

When using `ChatAgent` or `ToolLoopAgent`, you don't call `stream()` directly —
register a `TextDeltaEvent` handler and the agent switches to streaming
automatically (see [Getting Started — Streaming](getting-started.md#streaming)).

## Structured output (JSON schema)

Force the LLM to return JSON matching a schema:

```python
response = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[UserMessage(blocks=[TextBlock(text="Three European capitals")])],
        json_schema={
            "type": "object",
            "properties": {"cities": {"type": "array", "items": {"type": "string"}}},
            "required": ["cities"],
        },
        max_tokens=256,
    )
)
```

How each provider handles it:

- **Anthropic** — prompt injection + validation + retries (up to `max_schema_retries`).
  Returns `StopReason.SCHEMA_VALIDATION_FAILED` if all retries fail.
- **OpenAI (Chat Completions)** — native `response_format` with strict mode.
- **OpenAI (Responses API)** — native `text.format` with strict mode.
- **Google** — native `response_schema` with JSON mime type.

## Extended thinking

Enable the model's reasoning/thinking mode for complex tasks.

### Anthropic (Claude)

```python
response = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[UserMessage(blocks=[TextBlock(text="Solve step by step...")])],
        max_tokens=8192,
        extra=build_extra(AnthropicRequestExtra(thinking_budget_tokens=4000)),
    )
)

for block in response.message.blocks:
    if isinstance(block, ThinkingBlock):
        print(f"[thinking] {block.text}")
    elif isinstance(block, TextBlock):
        print(block.text)
```

### Google (Gemini)

```python
from flowra.llm import build_extra
from flowra.llm.providers.google_vertex import GoogleRequestExtra

# Gemini 3 — thinking level
extra=build_extra(GoogleRequestExtra(thinking_level="medium"))

# Gemini 2.5 — thinking budget
extra=build_extra(GoogleRequestExtra(thinking_budget=4096))
```

When using `ChatAgent`/`ToolLoopAgent`, pass `extra` through `LLMConfig`:

```python
from flowra.lib import LLMConfig
from flowra.llm import build_extra
from flowra.llm.providers.anthropic_vertex import AnthropicRequestExtra

config = LLMConfig(
    model="claude-sonnet-4-5@20250929",
    max_tokens=8192,
    extra=build_extra(AnthropicRequestExtra(thinking_budget_tokens=4000)),
)
```

## Prompt caching (Anthropic)

Anthropic supports caching parts of the prompt to reduce cost and latency on
repeated calls. Flowra provides composable hook bundles that set cache
breakpoints automatically.

### Quick setup

```python
from flowra.agent import HookSubscription
from flowra.lib.ext.anthropic import ANTHROPIC_CACHE_ALL

hooks = HookSubscription()
ANTHROPIC_CACHE_ALL.install(hooks)
# pass hooks to AgentRuntime via services={HookSubscription: hooks, ...}
```

`ANTHROPIC_CACHE_ALL` caches system messages, tools, and the last conversation
message — covers the most common case.

### Available presets

| Preset                    | Caches                                                                                       |
|---------------------------|----------------------------------------------------------------------------------------------|
| `ANTHROPIC_CACHE_ALL`     | System messages + tools + last message                                                       |
| `ANTHROPIC_CACHE_SESSION` | System messages + tools + last history message (excludes current turn). Requires `ChatAgent` |

### Individual bundles

For fine-grained control, install individual bundles (all are pre-instantiated constants):

| Constant                                        | What it caches                                                          |
|-------------------------------------------------|-------------------------------------------------------------------------|
| `ANTHROPIC_CACHE_ALL_SYSTEM_MESSAGES`           | Last block of the last system message                                   |
| `ANTHROPIC_CACHE_NON_TRANSIENT_SYSTEM_MESSAGES` | Last non-transient system block (stops at first transient)              |
| `ANTHROPIC_CACHE_ALL_TOOLS`                     | Last tool definition                                                    |
| `ANTHROPIC_CACHE_NON_TRANSIENT_TOOLS`           | Last non-transient tool (stops at first transient)                      |
| `ANTHROPIC_CACHE_ALL_MESSAGES`                  | Last block of the last message                                          |
| `ANTHROPIC_CACHE_NON_TRANSIENT_MESSAGES`        | Last non-transient message block (stops at first transient)             |
| `ANTHROPIC_CACHE_HISTORY_MESSAGES`              | Last history message (before current turn)                              |

```python
from flowra.lib.ext.anthropic import (
    ANTHROPIC_CACHE_ALL_SYSTEM_MESSAGES,
    ANTHROPIC_CACHE_ALL_TOOLS,
    ANTHROPIC_CACHE_HISTORY_MESSAGES,
)

hooks = HookSubscription()
ANTHROPIC_CACHE_ALL_SYSTEM_MESSAGES.install(hooks)
ANTHROPIC_CACHE_ALL_TOOLS.install(hooks)
ANTHROPIC_CACHE_HISTORY_MESSAGES.install(hooks)
```

### The `transient` hint

Blocks and messages can be marked `transient=True` to indicate non-permanent
content. This affects two things:

1. **Caching** — "NonTransient" bundles skip transient blocks when placing cache
   breakpoints, preventing cache invalidation from injected context that changes
   on every call.
2. **Session history** — `ChatAgent` automatically strips transient messages when
   saving conversation history. Transient content (e.g. injected context,
   ephemeral reminders) won't accumulate across turns.

```python
from flowra.llm import TextBlock, UserMessage

# Transient block — won't be cached by NonTransient bundles:
TextBlock(text="Current time: 12:00", transient=True)

# Transient message — won't be saved to session history:
UserMessage(blocks=[TextBlock(text="[system reminder]")], transient=True)
```

### Custom caching logic

Subscribe to `PrepareLLMRequestEvent` and modify the request directly:

```python
from flowra.lib.tool_loop import PrepareLLMRequestEvent

def my_cache_hook(event):
    request = event.data.request
    # Use the typed accessor to set cache_control:
    # AnthropicCacheable(block).cache_control = {"type": "ephemeral"}
    event.data.request = modified_request

hooks.on(PrepareLLMRequestEvent, my_cache_hook)
```

## Tool search

When an agent has many tools (50+), tool definitions consume a large chunk of
the context, and the LLM's ability to pick the right tool degrades. Tool search
solves this with deferred tool loading — tools are sent with only names and
descriptions, and a server-side search tool discovers full definitions on demand.

### Anthropic

```python
from flowra.lib.ext.anthropic import AnthropicToolSearch

ext = AnthropicToolSearch()
ext.install(hooks)
```

Reduces token usage by ~85% while maintaining tool selection accuracy.

| Parameter   | Default                  | Description                                           |
|-------------|--------------------------|-------------------------------------------------------|
| `variant`   | `ToolSearchVariant.BM25` | `BM25` (natural language) or `REGEX` (regex patterns) |
| `predicate` | `None`                   | Optional `(Tool) -> bool` — only defer matching tools |

```python
from flowra.lib.ext.anthropic import AnthropicToolSearch, ToolSearchVariant

# Defer only admin tools:
AnthropicToolSearch(predicate=lambda t: t.name.startswith("admin_")).install(hooks)

# Use regex variant:
AnthropicToolSearch(variant=ToolSearchVariant.REGEX).install(hooks)
```

### OpenAI

Requires `OpenAIResponsesProvider` and models that support tool search
(gpt-5.4+).

```python
from flowra.lib.ext.openai import OpenAIToolSearch

ext = OpenAIToolSearch()
ext.install(hooks)
```

| Parameter   | Default | Description                                           |
|-------------|---------|-------------------------------------------------------|
| `predicate` | `None`  | Optional `(Tool) -> bool` — only defer matching tools |

```python
# Defer only admin tools:
OpenAIToolSearch(predicate=lambda t: t.name.startswith("admin_")).install(hooks)
```

### How it works

1. Before each LLM call, selected tools are marked with `defer_loading: true`
   and a search tool is added to the request
2. The model receives only tool names and descriptions — no full schemas
3. When the model needs a tool, it calls the search tool with a query
4. The API returns full definitions of matching tools
5. The model invokes the discovered tools normally — transparent to the agent

## Cost tracking

Every `LLMResponse` includes token usage and estimated cost:

```python
response = await provider.call(request)

usage = response.usage
print(usage.input_tokens)                  # input tokens (excludes cached)
print(usage.output_tokens)                 # output tokens
print(usage.cache_read_input_tokens)       # tokens read from cache
print(usage.cache_creation_input_tokens)   # tokens written to cache
print(usage.cost_usd)                      # total estimated cost in USD
```

`Usage` supports addition — accumulate across multiple calls:

```python
total_usage = response1.usage + response2.usage
print(total_usage.cost_usd)
```

---

**Prev:** [Architecture](architecture.md) | **Next:** [Tools](tools.md)
