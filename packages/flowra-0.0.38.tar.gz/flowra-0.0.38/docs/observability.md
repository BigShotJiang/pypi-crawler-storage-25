# Observability

Flowra provides two observability mechanisms: **events** (point-in-time
notifications) and **spans** (start/end pairs for operations). Both are
delivered via `runtime.hooks`. On top of these primitives, Flowra ships
integrations with MLflow and OpenTelemetry.

## Events

Events are point-in-time notifications emitted during agent execution. Register
handlers via `runtime.hooks.on()`:

```python
from flowra.agent import AgentRuntime
from flowra.lib.observability import TextDeltaEvent

runtime = AgentRuntime(agents={...}, services={...})
runtime.hooks.on(TextDeltaEvent, lambda e: print(e.data.text, end="", flush=True))
```

Some events are **mutable** — your handler can modify the event data to influence
execution. For example, `UserMessageEvent` lets you rewrite messages before the
LLM sees them.

### Pre-built events

Events from `ToolLoopAgent` (and `ChatAgent`, which uses it internally):

| Event                    | When                     | Mutable?                                      |
|--------------------------|--------------------------|-----------------------------------------------|
| `UserMessageEvent`       | User message received    | `messages`                                    |
| `MessageAcceptedEvent`   | After message accepted   | —                                             |
| `StartIterationEvent`    | Each tool loop iteration | `additional_messages`                         |
| `PrepareLLMRequestEvent` | Before LLM call          | `request`                                     |
| `TextReasoningEvent`     | Each text block in LLM response | —                                        |
| `ThinkingEvent`          | Each thinking block in LLM response | —                                    |
| `ServerToolCallEvent`    | Server-side tool call (e.g. tool search) | —                               |
| `ServerToolResultEvent`  | Server-side tool result   | —                                             |
| `BeforeToolCallEvent`    | Before tool execution    | `tool_use`, `tool_definition`                 |
| `AfterToolCallEvent`     | After tool execution     | `result`, `error_kind`, `additional_messages` |
| `ResultMessageEvent`     | LLM finished (END_TURN)  | `continue_messages`                           |

Streaming events (from `flowra.lib.observability`):

| Event                | When                         |
|----------------------|------------------------------|
| `TextDeltaEvent`     | Each streamed text chunk     |
| `ThinkingDeltaEvent` | Each streamed thinking chunk |

Import lifecycle events from `flowra.lib.tool_loop`, streaming events from
`flowra.lib.observability`.

### Event context

Every event is wrapped in `Event[T]` with a `context` field — the execution
path from root to the agent that emitted the event:

```python
from flowra.agent import AgentRuntime, Event
from flowra.lib.tool_loop import BeforeToolCallEvent

def on_before_tool(event: Event[BeforeToolCallEvent]) -> None:
    agent_path = event.context.frame.agent.path
    tool_name = event.data.tool_use.name
    print(f"[{agent_path}] calling {tool_name}")

runtime = AgentRuntime(agents={...}, services={...})
runtime.hooks.on(BeforeToolCallEvent, on_before_tool)
```

Use `event.context.find_spec(SpecType)` to walk the execution stack and find
the spec of a parent agent — useful for identifying which model or session is
active.

## Spans

Spans track operations with a start and end. Register handlers via
`runtime.hooks.on_span()`. The handler receives an `Event[T]` (same envelope
as regular hooks, with execution context) and returns a `SpanExitHandler` —
a callback invoked at close time:

```python
from flowra.agent import AgentRuntime, AgentSpan, Event, SpanExitHandler

runtime = AgentRuntime(agents={...}, services={...})

def on_agent(event: Event[AgentSpan]) -> SpanExitHandler:
    span = event.data
    print(f"▶ agent started: {span.agent_info.path}")
    def on_end(error: BaseException | None = None) -> None:
        print(f"◀ agent ended: {span.agent_info.path} result={span.result}")
    return on_end

runtime.hooks.on_span(AgentSpan, on_agent)
```

### Span types

Engine-level spans (from `flowra.agent`):

| Span        | When            | Fields                                 |
|-------------|-----------------|----------------------------------------|
| `AgentSpan` | Agent lifecycle | `agent_info`, `spec`, `result`         |
| `StepSpan`  | Step invocation | `agent_info`, `step`, `spec`, `result` |

LLM/tool spans (from `flowra.lib.observability`):

| Span           | When           | Fields                             |
|----------------|----------------|------------------------------------|
| `LLMCallSpan`  | LLM call       | `request`, `response`              |
| `ToolCallSpan` | Tool execution | `tool_use`, `result`, `error_kind` |

Spans are mutable — fields like `response` and `result` are `None` at open time
and populated before close.

### Example: console span tree

```python
from flowra.agent import AgentRuntime, AgentSpan, Event, SpanExitHandler, StepSpan
from flowra.lib.observability import LLMCallSpan, ToolCallSpan

runtime = AgentRuntime(agents={...}, services={...})
indent = 0

def on_agent(event: Event[AgentSpan]) -> SpanExitHandler:
    span = event.data
    global indent
    print("  " * indent + f"▶ agent:{span.agent_info.path}")
    indent += 1
    def on_end(error: BaseException | None = None) -> None:
        global indent
        indent -= 1
        print("  " * indent + f"◀ agent:{span.agent_info.path}")
    return on_end

def on_llm(event: Event[LLMCallSpan]) -> SpanExitHandler:
    span = event.data
    print("  " * indent + f"🤖 llm_call ({span.request.model})")
    def on_end(error: BaseException | None = None) -> None:
        if span.response:
            u = span.response.usage
            print("  " * indent + f"   → {u.input_tokens}in/{u.output_tokens}out")
    return on_end

def on_tool(event: Event[ToolCallSpan]) -> SpanExitHandler:
    span = event.data
    print("  " * indent + f"🔧 tool:{span.tool_use.name}")
    def on_end(error: BaseException | None = None) -> None:
        if span.result:
            print("  " * indent + f"   → {span.result.content[:80]}")
    return on_end

runtime.hooks.on_span(AgentSpan, on_agent)
runtime.hooks.on_span(LLMCallSpan, on_llm)
runtime.hooks.on_span(ToolCallSpan, on_tool)
```

## MLflow integration

Maps spans to MLflow traces for a visual UI with token usage, cost tracking,
and session grouping.

**Install:** `pip install flowra[mlflow]`

```python
from flowra.agent import AgentRuntime
from flowra.ext.mlflow import MLFLOW_TRACING

runtime = AgentRuntime(agents={...}, services={...})
MLFLOW_TRACING.install(
    runtime,
    experiment_name="my-experiment",
    session_id="chat-session-123",   # groups multi-turn traces together
)
```

### What gets traced

| Span           | MLflow type | Default           |
|----------------|-------------|-------------------|
| `AgentSpan`    | AGENT       | on                |
| `StepSpan`     | CHAIN       | **off** (verbose) |
| `LLMCallSpan`  | CHAT_MODEL  | on                |
| `ToolCallSpan` | TOOL        | on                |

LLM spans use OpenAI-compatible message format — MLflow renders them with the
structured chat UI.

### Viewing traces

```bash
uv run mlflow ui --port 5050
# Open http://localhost:5050
```

### Parameters

```python
MLFLOW_TRACING.install(
    runtime,
    experiment_name="flowra",
    session_id="chat-123",       # or a callable: lambda: current_session_id
    trace_agents=True,
    trace_steps=False,           # usually too verbose
    trace_llm_calls=True,
    trace_tool_calls=True,
)
```

## OpenTelemetry integration

Maps spans to OTel spans with [GenAI semantic conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/).
Works with any OTel backend — Jaeger, Grafana Tempo, Datadog, Honeycomb, etc.

**Install:** `pip install flowra[otel]`

```python
from flowra.agent import AgentRuntime
from flowra.ext.otel import OTEL_TRACING

runtime = AgentRuntime(agents={...}, services={...})
OTEL_TRACING.install(runtime)
```

You configure your own `TracerProvider` and exporter — Flowra just creates spans.

### Setup example (Jaeger)

```bash
docker run -d --name jaeger -p 16686:16686 -p 4317:4317 jaegertracing/all-in-one
```

```python
from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

provider = TracerProvider(resource=Resource.create({"service.name": "my-service"}))
provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter(endpoint="http://localhost:4317")))
trace.set_tracer_provider(provider)
```

### GenAI attributes

OTel spans include standard GenAI attributes:

- `gen_ai.request.model`, `gen_ai.request.temperature`, `gen_ai.request.max_tokens`
- `gen_ai.usage.input_tokens`, `gen_ai.usage.output_tokens`
- `gen_ai.usage.cost` — total cost in USD
- `gen_ai.agent.name` — agent path (e.g. `app/chat/tool_loop`)
- `gen_ai.tool.name`, `gen_ai.tool.call.id`
- `flowra.tool.error_kind` — error classification

### Parameters

```python
OTEL_TRACING.install(
    runtime,
    tracer_name="flowra",
    trace_agents=True,
    trace_steps=True,
    trace_llm_calls=True,
    trace_tool_calls=True,
    capture_content=False,       # tool arguments/results (off for privacy)
    session_id="my-session",     # gen_ai.conversation.id
)
```

## Integration with external tracing context

Both integrations automatically detect and attach to an existing tracing context.
If your application already creates spans (e.g. a FastAPI middleware, a gRPC
interceptor, or business-logic code), flowra's spans become children of the
external span.

### MLflow

If a span was created with `with mlflow.start_span()` or `@mlflow.trace`, flowra
detects it via `mlflow.get_current_active_span()` and nests inside:

```python
import mlflow
from flowra.agent import AgentRuntime
from flowra.ext.mlflow import MLFLOW_TRACING

runtime = AgentRuntime(agents={...}, services={...})
MLFLOW_TRACING.install(runtime, experiment_name="my-experiment")

# External MLflow span — flowra spans become children
with mlflow.start_span(name="my_business_logic"):
    result = await runtime.run(agent=MyAgent, spec=MySpec(...))
```

### OpenTelemetry

If a span was created with `tracer.start_as_current_span()`, flowra detects it
via `trace.get_current_span()` and nests inside:

```python
from opentelemetry import trace
from flowra.agent import AgentRuntime
from flowra.ext.otel import OTEL_TRACING

runtime = AgentRuntime(agents={...}, services={...})
OTEL_TRACING.install(runtime)

app_tracer = trace.get_tracer("my_app")

# External OTel span — flowra spans become children
with app_tracer.start_as_current_span("my_business_logic"):
    result = await runtime.run(agent=MyAgent, spec=MySpec(...))
```

### Priority

Internal flowra context (from parent agent/step spans) takes priority over
external context. External context is only used when there is no flowra parent —
i.e. at the root of the flowra execution.

## Choosing the right tracing setup

| Setup                   | Best for                                         | What you get                                          |
|-------------------------|--------------------------------------------------|-------------------------------------------------------|
| MLflow only             | ML experiments, prompt debugging                 | Rich LLM UI, chat preview, cost tracking, sessions    |
| OTel only               | Production services with existing OTel           | Standard GenAI spans in Jaeger/Grafana/Datadog        |
| Both independently      | Full picture, two UIs                            | MLflow for LLM details + OTel for distributed tracing |
| MLflow with OTel export | MLflow UI + OTel backend, single instrumentation | MLflow spans forwarded to OTel collector              |

Decision tree:

```
Do you use OTel in your service already?
├── No → MLflow only (simplest, best LLM UI)
└── Yes
    ├── Do you need MLflow's LLM-specific UI?
    │   ├── No → OTel only (standard, lightweight)
    │   └── Yes
    │       ├── Do you want one trace ID across both?
    │       │   ├── Yes → MLflow with OTel export
    │       │   └── No → Both independently
    │       └── Do you need standard GenAI semconv attributes?
    │           ├── Yes → Both independently (OTel uses gen_ai.*)
    │           └── No → MLflow with OTel export (simpler)
```

### Both independently

Two independent span trees — MLflow for LLM-specific analysis, OTel for
distributed tracing. Traces are not linked (different trace IDs).

```python
from flowra.agent import AgentRuntime
from flowra.ext.mlflow import MLFLOW_TRACING
from flowra.ext.otel import OTEL_TRACING

runtime = AgentRuntime(agents={...}, services={...})
MLFLOW_TRACING.install(runtime, experiment_name="my-experiment")
OTEL_TRACING.install(runtime)
```

### MLflow with OTel export

MLflow is built on OTel internally. With dual export enabled, MLflow sends
spans to both backends — no `OTEL_TRACING.install()` needed. Single trace ID
shared between both.

Trade-off: MLflow uses its own attribute names (`mlflow.chat.tokenUsage`, etc.)
rather than `gen_ai.*`, so OTel backends won't recognize them as standard GenAI
spans.

```python
from flowra.agent import AgentRuntime
from flowra.ext.mlflow import MLFLOW_TRACING

runtime = AgentRuntime(agents={...}, services={...})
MLFLOW_TRACING.install(runtime, experiment_name="my-experiment")
```

```bash
pip install flowra[mlflow] opentelemetry-exporter-otlp

# Enable dual export:
export OTEL_EXPORTER_OTLP_TRACES_ENDPOINT="http://localhost:4317"
export MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT="true"
export OTEL_SERVICE_NAME="my-service"

# Optional: merge into your service's trace tree (e.g. FastAPI → flowra → LLM):
export MLFLOW_USE_DEFAULT_TRACER_PROVIDER="false"
```

---

**Prev:** [Patterns](patterns.md)
