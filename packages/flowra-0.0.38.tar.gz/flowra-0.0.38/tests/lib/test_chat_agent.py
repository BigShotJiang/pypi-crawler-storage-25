import dataclasses

from flowra.agent import AgentRuntime, Event, HookSubscription, InMemorySessionStorage
from flowra.lib import LLMConfig
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec
from flowra.lib.tool_loop import UserMessageEvent
from flowra.llm import (
    AssistantMessage,
    LLMProvider,
    LLMRequest,
    LLMResponse,
    StopReason,
    SystemMessage,
    TextBlock,
    ToolUseBlock,
    Usage,
    UserMessage,
)
from flowra.tools import ToolRegistry, get_local_tool, tool


class TestChatAgent:
    async def test_single_turn(self) -> None:
        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="Hello!")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=10, output_tokens=5),
                )

        provider = MockProvider()
        async with await ToolRegistry.create([]) as registry:
            config = ChatConfig(
                llm_config=LLMConfig(model="test"),
                system=[],
            )
            runtime = AgentRuntime(
                agents={"chat": ChatAgent},
                services={
                    ToolRegistry: registry,
                    ChatConfig: config,
                    LLMProvider: provider,
                },
            )

            result = await runtime.run(
                agent=ChatAgent,
                spec=ChatSpec(user_message="Hi"),
            )

            assert isinstance(result, ChatResult)
            assert result.response == "Hello!"
            assert result.usage is not None
            assert result.usage.input_tokens == 10
            assert result.usage.output_tokens == 5

    async def test_multi_turn_session_accumulates(self) -> None:
        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0
                self.requests: list[LLMRequest] = []

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                self.requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text=f"Response {self.call_count}")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=10, output_tokens=5),
                )

        provider = MockProvider()
        storage = InMemorySessionStorage()
        async with await ToolRegistry.create([]) as registry:
            config = ChatConfig(
                llm_config=LLMConfig(model="test"),
                system=[],
            )
            runtime = AgentRuntime(
                agents={"chat": ChatAgent},
                storage=storage,
                services={
                    ToolRegistry: registry,
                    ChatConfig: config,
                    LLMProvider: provider,
                },
            )

            # Turn 1
            result1 = await runtime.run(
                agent=ChatAgent,
                spec=ChatSpec(user_message="First"),
                storage_key="chat",
            )
            assert isinstance(result1, ChatResult)
            assert result1.response == "Response 1"

            # Turn 2 — LLM should see session history from turn 1
            # No cleanup needed: child node IDs are unique per run (r1.0, r2.0, etc.)
            result2 = await runtime.run(
                agent=ChatAgent,
                spec=ChatSpec(user_message="Second"),
                storage_key="chat",
            )
            assert isinstance(result2, ChatResult)
            assert result2.response == "Response 2"

            # Check that turn 2 LLM request included history from turn 1
            turn2_request = provider.requests[1]
            # History: user("First") + assistant("Response 1")
            # Turn messages: user("Second")
            # Total: 3 messages
            assert len(turn2_request.messages) == 3

            # First message should be the user message from turn 1
            assert isinstance(turn2_request.messages[0], UserMessage)
            assert isinstance(turn2_request.messages[0].blocks[0], TextBlock)
            assert turn2_request.messages[0].blocks[0].text == "First"

            # Second should be assistant response from turn 1
            assert isinstance(turn2_request.messages[1], AssistantMessage)
            assert isinstance(turn2_request.messages[1].blocks[0], TextBlock)
            assert turn2_request.messages[1].blocks[0].text == "Response 1"

            # Third should be the new user message for turn 2
            assert isinstance(turn2_request.messages[2], UserMessage)
            assert isinstance(turn2_request.messages[2].blocks[0], TextBlock)
            assert turn2_request.messages[2].blocks[0].text == "Second"

    async def test_tool_use_turn(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class GreetParams:
            name: str

        @tool("greet")
        def greet_tool(params: GreetParams) -> str:
            """Greet someone."""
            return f"Hello, {params.name}!"

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.call_count = 0

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.call_count += 1
                if self.call_count == 1:
                    return LLMResponse(
                        messages=[
                            AssistantMessage(blocks=[ToolUseBlock(id="call_1", name="greet", input={"name": "World"})])
                        ],
                        stop_reason=StopReason.TOOL_USE,
                        usage=Usage(input_tokens=10, output_tokens=20),
                    )
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="I greeted World for you!")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=30, output_tokens=15),
                )

        provider = MockProvider()
        async with await ToolRegistry.create([get_local_tool(greet_tool)]) as registry:
            config = ChatConfig(
                llm_config=LLMConfig(model="test"),
                system=[],
            )
            runtime = AgentRuntime(
                agents={"chat": ChatAgent},
                services={
                    ToolRegistry: registry,
                    ChatConfig: config,
                    LLMProvider: provider,
                },
            )

            result = await runtime.run(
                agent=ChatAgent,
                spec=ChatSpec(user_message="Greet the world"),
            )

            assert isinstance(result, ChatResult)
            assert result.response == "I greeted World for you!"
            # Usage should be aggregated across both LLM calls
            assert result.usage is not None
            assert result.usage.input_tokens == 40
            assert result.usage.output_tokens == 35

    async def test_none_response_when_no_text(self) -> None:
        class MockProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                # Assistant message with no text blocks (only tool use, then end turn)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        async with await ToolRegistry.create([]) as registry:
            config = ChatConfig(
                llm_config=LLMConfig(model="test"),
                system=[],
            )
            runtime = AgentRuntime(
                agents={"chat": ChatAgent},
                services={
                    ToolRegistry: registry,
                    ChatConfig: config,
                    LLMProvider: provider,
                },
            )

            result = await runtime.run(
                agent=ChatAgent,
                spec=ChatSpec(user_message="Hi"),
            )

            assert isinstance(result, ChatResult)
            assert result.response is None
            assert result.usage is None

    async def test_on_user_message_hook(self) -> None:
        def augment_user_message(event: Event[UserMessageEvent]) -> None:
            user_message = event.data.messages[0]
            # Add a system reminder after the user message
            reminder = UserMessage(
                blocks=[TextBlock(text="[Remember: be helpful]")],
                transient=True,
            )
            event.data.messages = [user_message, reminder]

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.requests: list[LLMRequest] = []

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="OK")])],
                    stop_reason=StopReason.END_TURN,
                )

        provider = MockProvider()
        async with await ToolRegistry.create([]) as registry:
            config = ChatConfig(
                llm_config=LLMConfig(model="test"),
                system=[],
            )
            hooks = HookSubscription()
            hooks.on(UserMessageEvent, augment_user_message)
            runtime = AgentRuntime(
                agents={"chat": ChatAgent},
                services={
                    ToolRegistry: registry,
                    ChatConfig: config,
                    HookSubscription: hooks,
                    LLMProvider: provider,
                },
            )

            result = await runtime.run(
                agent=ChatAgent,
                spec=ChatSpec(user_message="Hello"),
            )

            assert isinstance(result, ChatResult)
            assert result.response == "OK"

            # LLM should have received 2 messages: original user message + reminder
            assert len(provider.requests) == 1
            llm_messages = provider.requests[0].messages
            assert len(llm_messages) == 2
            assert isinstance(llm_messages[0], UserMessage)
            assert isinstance(llm_messages[0].blocks[0], TextBlock)
            assert llm_messages[0].blocks[0].text == "Hello"
            assert isinstance(llm_messages[1], UserMessage)
            assert isinstance(llm_messages[1].blocks[0], TextBlock)
            assert llm_messages[1].blocks[0].text == "[Remember: be helpful]"

    async def test_transient_messages_auto_filtered_from_history(self) -> None:
        """Transient messages are automatically stripped from session history."""

        def inject_reminder(event: Event[UserMessageEvent]) -> None:
            user_message = event.data.messages[0]
            reminder = UserMessage(
                blocks=[TextBlock(text="[transient reminder]")],
                transient=True,
            )
            event.data.messages = [user_message, reminder]

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.requests: list[LLMRequest] = []

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="OK")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=10, output_tokens=5),
                )

        provider = MockProvider()
        storage = InMemorySessionStorage()
        async with await ToolRegistry.create([]) as registry:
            config = ChatConfig(
                llm_config=LLMConfig(model="test"),
                system=[],
            )
            hooks = HookSubscription()
            hooks.on(UserMessageEvent, inject_reminder)
            runtime = AgentRuntime(
                agents={"chat": ChatAgent},
                storage=storage,
                services={
                    ToolRegistry: registry,
                    ChatConfig: config,
                    HookSubscription: hooks,
                    LLMProvider: provider,
                },
            )

            # Turn 1: reminder is injected but should be filtered from session
            await runtime.run(
                agent=ChatAgent,
                spec=ChatSpec(user_message="Hello"),
                storage_key="chat",
            )

            # Turn 1 LLM saw the reminder (2 user messages + no session history)
            assert len(provider.requests[0].messages) == 2

            # Turn 2: session should NOT contain the transient reminder
            await runtime.run(
                agent=ChatAgent,
                spec=ChatSpec(user_message="Again"),
                storage_key="chat",
            )

            # Turn 2 LLM: session(user "Hello" + assistant "OK") + turn(user "Again" + reminder)
            # The transient reminder from turn 1 should NOT be in session history
            turn2_messages = provider.requests[1].messages
            assert len(turn2_messages) == 4
            assert isinstance(turn2_messages[0], UserMessage)
            assert turn2_messages[0].blocks[0].text == "Hello"  # type: ignore[union-attr]
            assert isinstance(turn2_messages[1], AssistantMessage)
            assert turn2_messages[1].blocks[0].text == "OK"  # type: ignore[union-attr]
            assert isinstance(turn2_messages[2], UserMessage)
            assert turn2_messages[2].blocks[0].text == "Again"  # type: ignore[union-attr]
            assert isinstance(turn2_messages[3], UserMessage)
            assert turn2_messages[3].blocks[0].text == "[transient reminder]"  # type: ignore[union-attr]

    async def test_transient_auto_filtered_even_without_hook(self) -> None:
        """Transient messages are auto-filtered from session even without explicit SaveHistoryEvent hook."""

        def inject_reminder(event: Event[UserMessageEvent]) -> None:
            user_message = event.data.messages[0]
            reminder = UserMessage(
                blocks=[TextBlock(text="[transient]")],
                transient=True,
            )
            event.data.messages = [user_message, reminder]

        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.requests: list[LLMRequest] = []

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="OK")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=10, output_tokens=5),
                )

        provider = MockProvider()
        storage = InMemorySessionStorage()
        async with await ToolRegistry.create([]) as registry:
            config = ChatConfig(
                llm_config=LLMConfig(model="test"),
                system=[],
            )
            hooks = HookSubscription()
            hooks.on(UserMessageEvent, inject_reminder)
            runtime = AgentRuntime(
                agents={"chat": ChatAgent},
                storage=storage,
                services={
                    ToolRegistry: registry,
                    ChatConfig: config,
                    HookSubscription: hooks,
                    LLMProvider: provider,
                },
            )

            await runtime.run(
                agent=ChatAgent,
                spec=ChatSpec(user_message="Hello"),
                storage_key="chat",
            )
            await runtime.run(
                agent=ChatAgent,
                spec=ChatSpec(user_message="Again"),
                storage_key="chat",
            )

            # Transient reminder auto-filtered from session
            # Turn 2: session(user "Hello" + assistant "OK") + turn(user "Again" + transient)
            turn2_messages = provider.requests[1].messages
            assert len(turn2_messages) == 4
            assert turn2_messages[0].blocks[0].text == "Hello"  # type: ignore[union-attr]
            assert turn2_messages[1].blocks[0].text == "OK"  # type: ignore[union-attr]
            assert turn2_messages[2].blocks[0].text == "Again"  # type: ignore[union-attr]
            assert turn2_messages[3].blocks[0].text == "[transient]"  # type: ignore[union-attr]

    async def test_system_messages_prepended_to_session(self) -> None:
        class MockProvider(LLMProvider):
            def __init__(self) -> None:
                self.requests: list[LLMRequest] = []

            async def call(self, request: LLMRequest) -> LLMResponse:
                self.requests.append(request)
                return LLMResponse(
                    messages=[AssistantMessage(blocks=[TextBlock(text="OK")])],
                    stop_reason=StopReason.END_TURN,
                    usage=Usage(input_tokens=10, output_tokens=5),
                )

        provider = MockProvider()
        storage = InMemorySessionStorage()
        async with await ToolRegistry.create([]) as registry:
            config = ChatConfig(
                llm_config=LLMConfig(model="test"),
                system=[SystemMessage(blocks=[TextBlock(text="You are helpful.")])],
            )
            runtime = AgentRuntime(
                agents={"chat": ChatAgent},
                storage=storage,
                services={
                    ToolRegistry: registry,
                    ChatConfig: config,
                    LLMProvider: provider,
                },
            )

            await runtime.run(
                agent=ChatAgent,
                spec=ChatSpec(user_message="Hello"),
                storage_key="chat",
            )
            await runtime.run(
                agent=ChatAgent,
                spec=ChatSpec(user_message="Again"),
                storage_key="chat",
            )

            # Turn 1: system in request.system, user in request.messages
            turn1_system = provider.requests[0].system
            turn1_messages = provider.requests[0].messages
            assert len(turn1_system) == 1
            assert isinstance(turn1_system[0], SystemMessage)
            assert turn1_system[0].blocks[0].text == "You are helpful."
            assert len(turn1_messages) == 1
            assert turn1_messages[0].blocks[0].text == "Hello"  # type: ignore[union-attr]

            # Turn 2: system in request.system, session(user, assistant) + user in request.messages
            turn2_system = provider.requests[1].system
            turn2_messages = provider.requests[1].messages
            assert len(turn2_system) == 1
            assert isinstance(turn2_system[0], SystemMessage)
            assert turn2_system[0].blocks[0].text == "You are helpful."
            assert len(turn2_messages) == 3
            assert turn2_messages[0].blocks[0].text == "Hello"  # type: ignore[union-attr]
            assert turn2_messages[1].blocks[0].text == "OK"  # type: ignore[union-attr]
            assert turn2_messages[2].blocks[0].text == "Again"  # type: ignore[union-attr]
