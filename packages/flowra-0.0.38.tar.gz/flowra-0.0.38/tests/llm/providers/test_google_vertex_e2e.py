import base64
import json
import os
from collections.abc import AsyncIterator

import pytest
from google import genai
from google.oauth2 import service_account

from flowra.llm import (
    ContentComplete,
    LLMRequest,
    StopReason,
    SystemMessage,
    TextBlock,
    TextDelta,
    ThinkingBlock,
    Tool,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)
from flowra.llm.providers.google_vertex import GoogleVertexProvider

# Gemini is inherently flaky — retry all tests in this module
pytestmark = pytest.mark.flaky(reruns=2)


def _make_provider(location: str | None = None) -> GoogleVertexProvider:
    project = os.environ["VERTEX_PROJECT_NAME"]
    loc = location or os.environ["VERTEX_LOCATION"]
    creds_json = base64.b64decode(os.environ["VERTEX_CREDENTIALS"].encode()).decode()
    creds_info = json.loads(creds_json)
    creds = service_account.Credentials.from_service_account_info(creds_info).with_scopes(
        ["https://www.googleapis.com/auth/cloud-platform.read-only"]
    )
    client = genai.Client(vertexai=True, project=project, location=loc, credentials=creds)
    return GoogleVertexProvider(client=client, owns_client=True)


@pytest.fixture
async def provider() -> AsyncIterator[GoogleVertexProvider]:
    async with _make_provider() as p:
        yield p


@pytest.fixture
async def global_provider() -> AsyncIterator[GoogleVertexProvider]:
    async with _make_provider(location="global") as p:
        yield p


async def test_simple_text_response(provider: GoogleVertexProvider) -> None:
    request = LLMRequest(
        model="gemini-2.5-flash-lite",
        messages=[
            UserMessage(blocks=[TextBlock(text="Reply with exactly: hello")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    assert len(response.message.blocks) > 0
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    assert "hello" in text.lower()


async def test_system_message(provider: GoogleVertexProvider) -> None:
    request = LLMRequest(
        model="gemini-2.5-flash-lite",
        system=[
            SystemMessage(blocks=[TextBlock(text="You are a bot that only replies with the word 'pong'.")]),
        ],
        messages=[
            UserMessage(blocks=[TextBlock(text="ping")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    assert "pong" in text.lower()


async def test_tool_use(provider: GoogleVertexProvider) -> None:
    tool = Tool(
        name="get_weather",
        description="Get the current weather for a city.",
        input_schema={
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "City name"},
            },
            "required": ["city"],
        },
    )
    request = LLMRequest(
        model="gemini-2.5-flash-lite",
        messages=[
            UserMessage(blocks=[TextBlock(text="What's the weather in Paris?")]),
        ],
        tools=[tool],
        max_tokens=256,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.TOOL_USE
    tool_uses = [b for b in response.message.blocks if isinstance(b, ToolUseBlock)]
    assert len(tool_uses) >= 1
    assert tool_uses[0].name == "get_weather"
    assert isinstance(tool_uses[0].input, dict)
    assert tool_uses[0].input["city"].lower() == "paris"


async def test_tool_use_roundtrip(provider: GoogleVertexProvider) -> None:
    tool = Tool(
        name="get_temperature",
        description="Get temperature for a city. Returns temperature in Celsius.",
        input_schema={
            "type": "object",
            "properties": {
                "city": {"type": "string"},
            },
            "required": ["city"],
        },
    )

    request1 = LLMRequest(
        model="gemini-2.5-flash-lite",
        messages=[
            UserMessage(blocks=[TextBlock(text="What is the temperature in London?")]),
        ],
        tools=[tool],
        max_tokens=256,
    )
    response1 = await provider.call(request1)
    print(response1)

    assert response1.stop_reason == StopReason.TOOL_USE
    tool_use = next(b for b in response1.message.blocks if isinstance(b, ToolUseBlock))

    request2 = LLMRequest(
        model="gemini-2.5-flash-lite",
        messages=[
            UserMessage(blocks=[TextBlock(text="What is the temperature in London?")]),
            response1.message,
            UserMessage(blocks=[ToolResultBlock(tool_use_id=tool_use.id, content="15")]),
        ],
        tools=[tool],
        max_tokens=256,
    )
    response2 = await provider.call(request2)
    print(response2)

    assert response2.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response2.message.blocks if isinstance(b, TextBlock))
    assert "15" in text


async def test_json_schema(provider: GoogleVertexProvider) -> None:
    request = LLMRequest(
        model="gemini-2.5-flash-lite",
        messages=[
            UserMessage(blocks=[TextBlock(text="List three European capital cities.")]),
        ],
        json_schema={
            "type": "object",
            "properties": {
                "cities": {
                    "type": "array",
                    "items": {"type": "string"},
                },
            },
            "required": ["cities"],
        },
        max_tokens=256,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    parsed = json.loads(text)
    assert "cities" in parsed
    assert isinstance(parsed["cities"], list)
    assert len(parsed["cities"]) == 3


async def test_usage_is_returned(provider: GoogleVertexProvider) -> None:
    request = LLMRequest(
        model="gemini-2.5-flash-lite",
        messages=[
            UserMessage(blocks=[TextBlock(text="Say hi")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.usage is not None
    assert response.usage.input_tokens > 0
    assert response.usage.output_tokens > 0


async def test_stream_simple_text(provider: GoogleVertexProvider) -> None:
    request = LLMRequest(
        model="gemini-2.5-flash-lite",
        messages=[
            UserMessage(blocks=[TextBlock(text="Reply with exactly: hello")]),
        ],
        max_tokens=64,
    )

    events = []
    async for event in provider.stream(request):
        events.append(event)

    text_deltas = [e for e in events if isinstance(e, TextDelta)]
    completes = [e for e in events if isinstance(e, ContentComplete)]
    assert len(text_deltas) > 0
    assert len(completes) == 1
    assert completes[0].response.stop_reason == StopReason.END_TURN


async def test_tool_use_with_union_schema(provider: GoogleVertexProvider) -> None:
    """Gemini flash-lite occasionally returns MALFORMED_FUNCTION_CALL with union schemas."""
    import dataclasses

    import marshmallow_recipe as mr

    @dataclasses.dataclass
    class Dog:
        breed: str

    @dataclasses.dataclass
    class Cat:
        color: str

    @dataclasses.dataclass
    class AnimalSpec:
        animal: Dog | Cat
        nickname: str

    schema = mr.json_schema(AnimalSpec)
    tool = Tool(
        name="register_animal",
        description="Register an animal. If it's a dog, provide breed. If it's a cat, provide color.",
        input_schema=schema,
    )
    request = LLMRequest(
        model="gemini-2.5-flash-lite",
        messages=[
            UserMessage(blocks=[TextBlock(text="Register a golden retriever dog with nickname Buddy.")]),
        ],
        tools=[tool],
        max_tokens=256,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.TOOL_USE
    tool_uses = [b for b in response.message.blocks if isinstance(b, ToolUseBlock)]
    assert len(tool_uses) >= 1
    assert tool_uses[0].name == "register_animal"

    input_ = tool_uses[0].input
    assert isinstance(input_, dict)
    spec = mr.load(AnimalSpec, input_)
    assert isinstance(spec.animal, Dog)
    assert "retriever" in spec.animal.breed.lower() or "golden" in spec.animal.breed.lower()


async def test_json_schema_with_union(provider: GoogleVertexProvider) -> None:
    import dataclasses

    import marshmallow_recipe as mr

    @dataclasses.dataclass
    class Dog:
        breed: str

    @dataclasses.dataclass
    class Cat:
        color: str

    @dataclasses.dataclass
    class AnimalSpec:
        animal: Dog | Cat
        nickname: str

    schema = mr.json_schema(AnimalSpec)

    request_dog = LLMRequest(
        model="gemini-2.5-flash-lite",
        messages=[
            UserMessage(blocks=[TextBlock(text="Describe a golden retriever dog named Buddy.")]),
        ],
        json_schema=schema,
        max_tokens=256,
    )
    response = await provider.call(request_dog)
    print(response)
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    spec = mr.load(AnimalSpec, json.loads(text))
    assert isinstance(spec.animal, Dog)
    assert "buddy" in spec.nickname.lower()

    request_cat = LLMRequest(
        model="gemini-2.5-flash-lite",
        messages=[
            UserMessage(blocks=[TextBlock(text="Describe a black cat named Whiskers.")]),
        ],
        json_schema=schema,
        max_tokens=256,
    )
    response = await provider.call(request_cat)
    print(response)
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    spec = mr.load(AnimalSpec, json.loads(text))
    assert isinstance(spec.animal, Cat)
    assert "whiskers" in spec.nickname.lower()


async def test_max_tokens_truncation(provider: GoogleVertexProvider) -> None:
    request = LLMRequest(
        model="gemini-2.5-flash-lite",
        messages=[
            UserMessage(blocks=[TextBlock(text="Write a long essay about the history of mathematics.")]),
        ],
        max_tokens=5,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.MAX_TOKENS


async def test_thinking(global_provider: GoogleVertexProvider) -> None:
    request = LLMRequest(
        model="gemini-3.1-flash-lite-preview",
        messages=[
            UserMessage(blocks=[TextBlock(text="What is 15 * 37? Think step by step.")]),
        ],
        max_tokens=8192,
        extra={"google": {"thinking_level": "low"}},
    )
    response = await global_provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    thinking_blocks = [b for b in response.message.blocks if isinstance(b, ThinkingBlock)]
    text_blocks = [b for b in response.message.blocks if isinstance(b, TextBlock)]
    assert len(thinking_blocks) > 0
    assert len(text_blocks) > 0
    assert "555" in text_blocks[0].text


async def test_thinking_tool_use_roundtrip(provider: GoogleVertexProvider) -> None:
    """Thinking mode + tool use: verifies thought_signature is preserved across turns."""
    tool = Tool(
        name="get_temperature",
        description="Get temperature for a city. Returns temperature in Celsius.",
        input_schema={
            "type": "object",
            "properties": {
                "city": {"type": "string"},
            },
            "required": ["city"],
        },
    )

    # Step 1: ask with thinking + tools
    request1 = LLMRequest(
        model="gemini-2.5-flash",
        messages=[
            UserMessage(blocks=[TextBlock(text="What is the temperature in London?")]),
        ],
        tools=[tool],
        max_tokens=8192,
        extra={"google": {"thinking_budget": 4096}},
    )
    response1 = await provider.call(request1)
    print(response1)

    assert response1.stop_reason == StopReason.TOOL_USE
    tool_use = next(b for b in response1.message.blocks if isinstance(b, ToolUseBlock))

    # Step 2: send tool result back (with full assistant message including thought_signature)
    request2 = LLMRequest(
        model="gemini-2.5-flash",
        messages=[
            UserMessage(blocks=[TextBlock(text="What is the temperature in London?")]),
            response1.message,
            UserMessage(blocks=[ToolResultBlock(tool_use_id=tool_use.id, content="15")]),
        ],
        tools=[tool],
        max_tokens=8192,
        extra={"google": {"thinking_budget": 4096}},
    )
    response2 = await provider.call(request2)
    print(response2)

    assert response2.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response2.message.blocks if isinstance(b, TextBlock))
    assert "15" in text


async def test_thinking_tool_use_roundtrip_gemini3(global_provider: GoogleVertexProvider) -> None:
    """Gemini 3 thinking + tool use: thought_signature is mandatory for function calls."""
    tool = Tool(
        name="get_temperature",
        description="Get temperature for a city. Returns temperature in Celsius.",
        input_schema={
            "type": "object",
            "properties": {
                "city": {"type": "string"},
            },
            "required": ["city"],
        },
    )

    request1 = LLMRequest(
        model="gemini-3.1-flash-lite-preview",
        messages=[
            UserMessage(blocks=[TextBlock(text="What is the temperature in London?")]),
        ],
        tools=[tool],
        max_tokens=8192,
        extra={"google": {"thinking_level": "LOW"}},
    )
    response1 = await global_provider.call(request1)
    print(response1)

    assert response1.stop_reason == StopReason.TOOL_USE
    tool_use = next(b for b in response1.message.blocks if isinstance(b, ToolUseBlock))

    # Step 2: send tool result back — Gemini 3 requires thought_signature on function_call parts
    request2 = LLMRequest(
        model="gemini-3.1-flash-lite-preview",
        messages=[
            UserMessage(blocks=[TextBlock(text="What is the temperature in London?")]),
            response1.message,
            UserMessage(blocks=[ToolResultBlock(tool_use_id=tool_use.id, content="15")]),
        ],
        tools=[tool],
        max_tokens=8192,
        extra={"google": {"thinking_level": "LOW"}},
    )
    response2 = await global_provider.call(request2)
    print(response2)

    assert response2.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response2.message.blocks if isinstance(b, TextBlock))
    assert "15" in text
