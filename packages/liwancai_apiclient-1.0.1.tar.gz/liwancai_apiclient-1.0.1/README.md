# ApiClient

动态API客户端库，支持链式调用和自动方法解析。

**注意**: 包在PyPI上的名称是 `liwancai-ApiClient`，但导入时使用 `ApiClient`

## 安装

```bash
pip install liwancai-ApiClient
```

## 使用

### 基本用法

```python
# 导入整个包的所有功能
from ApiClient import *

# 创建API客户端实例
client = ApiClient("https://api.example.com")

# 设置认证token
client.set_authtoken("your_token_here")

# 链式调用API
result = client.users.Get_profile(user_id=123)
print(result)
```

### 链式调用语法

ApiClient支持链式调用，自动解析方法和路径：

```python
# GET 请求：以 Get_ 开头的方法
result = client.api.users.Get_list(page=1, size=10)

# POST 请求：其他方法
result = client.api.users.create(name="张三", email="zhangsan@example.com")

# 多级路径
result = client.admin.system.logs.Get_recent(hours=24)
```

### 路径转换规则

ApiClient会自动转换链式调用的路径：

| 链式调用 | HTTP方法 | 实际URL | 说明 |
|---------|---------|---------|------|
| `client.users.Get_profile` | GET | `/users/profile` | Get_前缀表示GET方法 |
| `client.users.create` | POST | `/users/create` | 默认POST方法 |
| `client.admin.users.Get_list` | GET | `/admin/users/list` | 多级路径支持 |

### 命名转换规则

- **Group部分**（除最后一个部分外）：转为小写
- **接口名**（最后一个部分）：
  - 如果是GET请求，去掉`Get_`前缀后转为kebab-case
  - 其他请求直接转为kebab-case

示例：
- `Get_profile` → `profile`（GET请求，去掉Get_前缀）
- `createUser` → `create-user`（POST请求）
- `GetAPIList` → `api-list`（GET请求，去掉Get_前缀）

## API参考

### ApiClient类

#### 构造函数
```python
ApiClient(base_url="https://api.liwancai.com")
```

参数：
- `base_url` (str): API基础URL，默认为liwancai API

#### 方法

##### set_authtoken(token)
设置认证token

参数：
- `token` (str): 认证token

##### __getattr__(name)
开始链式调用

参数：
- `name` (str): 路径第一部分

### APIProxy类

内部使用的代理类，负责链式调用的路径收集和方法解析。

## 示例

### 完整示例

```python
from ApiClient import ApiClient

# 创建客户端
client = ApiClient("https://api.example.com")
client.set_authtoken("your_jwt_token")

# 获取用户列表
users = client.users.Get_list(page=1, size=20)

# 创建新用户
new_user = client.users.create(
    name="李四",
    email="lisi@example.com",
    role="user"
)

# 获取用户详情
user_detail = client.users.Get_detail(user_id=123)

# 更新用户信息
updated_user = client.users.update(
    user_id=123,
    name="王五",
    email="wangwu@example.com"
)

# 删除用户
delete_result = client.users.delete(user_id=123)
```

### 错误处理

```python
try:
    result = client.users.Get_profile(user_id=999)
    print("请求成功:", result)
except Exception as e:
    print("请求失败:", e)
```

## 依赖

- `requests>=2.25.0` - HTTP请求库
- `liwancai-PyLog>=1.0.0` - 日志库

## 许可证

MIT License