import requests
from   LOG                import log

class ApiClient:
    """动态 API 客户端"""
    def __init__(self, base_url: str="https://api.liwancai.com"):
        self.base_url = base_url.rstrip('/')### 去掉末尾的斜杠
        self.session = requests.Session()### 初始化会话
        self.session.headers.update({
            "Content-Type": "application/json"
        }) # 添加通用 headers，如认证信息等
    def set_authtoken(self, token: str):
        """设置认证 token"""
        self.session.headers["Authorization"] = f"Bearer {token}"
    def __getattr__(self, name: str) -> 'ApiProxy':
        # 入口：开始链式调用
        return ApiProxy(self, [name])
    def _parse_response(self, response):
        """统一解析响应，直接返回 data"""
        try:
            rst = response.json()
            if rst.get('code',-1)!=200: log.Error(rst)
            return rst['data']
        except ValueError: # 如果不是JSON，返回原始文本
            return response.content

class ApiProxy:
    """延迟解析的 API 代理"""
    def __init__(self, client: 'ApiClient', path_parts: list = None):
        self._client = client
        self._path_parts = path_parts or []  # 收集链式调用的所有部分
    def __getattr__(self, name: str) -> 'ApiProxy':
        # 链式调用：继续收集路径部分
        return ApiProxy(self._client, self._path_parts + [name])
    def __call__(self, **kwargs):
        # 最终调用：解析路径和方法
        method, api_path = self._parse_path(self._path_parts)
        # 构建完整 URL
        url = f"{self._client.base_url}/{api_path}"
        # 发送请求
        log.Info(f"发送请求： {method} {url} {kwargs}")
        if method == "GET":
            response = self._client.session.get(url, params=kwargs)
        else:
            response = self._client.session.post(url, json=kwargs)
        # 统一解析响应
        return self._client._parse_response(response)
    def _parse_path(self, parts: list) -> tuple:
        """
        解析路径部分，区分方法和路径
        
        规则：
        1. 以 Get_ 开头 → GET 方法，去掉前缀
        2. 其他 → POST 方法
        3. 除最后一个部分外，都是 Group（转为小写）
        4. 最后一部分是接口名（kebab-case）
        """
        if not parts:  raise ValueError("API 路径不能为空")
        # 检查是否是 GET 请求
        last_part = parts[-1]
        if last_part.startswith("Get_") or last_part.startswith("get_"):
            # 严格大小写：Get_ 开头表示 GET
            method = "GET"
            parts[-1] = last_part[4:]  # 去掉 Get_ 前缀
        else:
            method = "POST"
        # 转换路径格式
        # 除最后一个外，都是 Group（小写）
        # 最后一个是接口名（kebab-case）
        groups = [p.lower() for p in parts[:-1]]
        endpoint = self._to_kebab_case(parts[-1])
        # 构建路径
        path_parts = groups + [endpoint]
        api_path = "/".join(path_parts)
        return method, api_path
    
    @staticmethod
    def _to_kebab_case(name: str) -> str:
        """
        处理驼峰 + 下划线混合命名，转换为 kebab-case
        """
        result = []
        for i, char in enumerate(name):
            if char == '_':
                result.append('-')
            elif char.isupper() and i > 0 and name[i-1] != '_':
                # 大写字母前加横线（除了开头和紧跟下划线的）
                if name[i-1].islower():
                    result.append('-')
                result.append(char.lower())
            else:
                result.append(char.lower())
        return ''.join(result)