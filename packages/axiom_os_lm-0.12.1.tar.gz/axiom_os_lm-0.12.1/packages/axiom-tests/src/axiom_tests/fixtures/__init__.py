# Copyright (c) 2026 B-Tree Ventures, LLC. Apache-2.0 licensed.
"""Reusable pytest fixtures for AEOS-conformant extensions.

Each submodule contributes one or more fixtures. They are all aggregated
through the ``axiom_tests.plugin`` pytest11 entry point so that installing
``axiom-tests`` makes them available everywhere.
"""
