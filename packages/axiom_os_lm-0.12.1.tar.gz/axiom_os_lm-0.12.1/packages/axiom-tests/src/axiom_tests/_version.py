# Copyright (c) 2026 B-Tree Ventures, LLC. Apache-2.0 licensed.
"""Single source of truth for the axiom-tests package version."""

__version__ = "0.1.0"

__all__ = ["__version__"]
