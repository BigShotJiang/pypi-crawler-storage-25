# Copyright (c) 2026 B-Tree Ventures, LLC. Apache-2.0 licensed.
"""JSON Schemas shipped with axiom-tests.

Files here are treated as package data. ``axiom_tests._manifest.load_schema``
reads the AEOS manifest schema out of this package via ``importlib.resources``.
"""
