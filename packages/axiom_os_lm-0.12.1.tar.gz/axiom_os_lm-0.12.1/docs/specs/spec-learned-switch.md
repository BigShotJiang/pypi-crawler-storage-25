# Technical Specification: LearnedSwitch

**Spec:** LearnedSwitch — Graduated-Autonomy Classification Primitive
**Owner:** Benjamin Booth
**Status:** Draft
**Last Updated:** 2026-04-19
**Parent PRD:** [prd-learned-switch.md](../prds/prd-learned-switch.md)

---

## Table of Contents

- [1) Overview](#1-overview)
- [2) Data Model](#2-data-model)
- [3) Lifecycle State Machine](#3-lifecycle-state-machine)
- [4) Core Algorithm](#4-core-algorithm)
- [5) Training Pipeline](#5-training-pipeline)
- [6) Drift Detection](#6-drift-detection)
- [7) Confidence Calibration](#7-confidence-calibration)
- [8) Storage Format](#8-storage-format)
- [9) Cross-Language Contract](#9-cross-language-contract)
- [10) Code Generation (Zero-Dependency Mode)](#10-code-generation-zero-dependency-mode)
- [11) Federation Extension](#11-federation-extension)
- [12) Axiom Deployment Details](#12-axiom-deployment-details)
- [13) Research Instrumentation](#13-research-instrumentation)
- [14) Approval & Governance](#14-approval--governance)

---

## 1) Overview

LearnedSwitch is a classification primitive with four lifecycle phases.
It wraps a user-provided rule function and optionally an ML classifier,
managing the transition between them based on accumulated outcome data.

**Invariants (hold in every phase):**

1. Every invocation produces an output. The switch never returns
   "I don't know" — it always falls back to the rule.
2. Every invocation is logged with sufficient data to retrain.
3. Phase transitions are monotonic within a deployment window
   (no oscillation) unless auto-revert triggers.
4. The rule function is never modified by the switch. It's a
   pure, deterministic, user-provided function.
5. Thread safety: concurrent `classify()` calls are safe.
   Concurrent `record_outcome()` calls are safe. Model swap
   during inference is atomic.

---

## 2) Data Model

### 2.1 Input Contract

```
Input: Any (user-defined type)
FeatureVector: float[] (extracted from Input by user-provided function)
Output: str | int (classification label — discrete, finite set)
Outcome: enum { CORRECT, INCORRECT(correction: Output), OVERRIDE(to: Output), ESCALATED, UNKNOWN }
```

The user provides:
- `rule: (Input) → Output` — deterministic classification function
- `feature_extractor: (Input) → float[]` — converts input to numeric features
- `labels: str[]` — exhaustive list of valid output labels

### 2.2 Outcome Record

Each outcome appended to the outcome log:

```
OutcomeRecord:
  id: uuid
  timestamp: ISO 8601
  input_features: float[]       # Feature vector (not raw input — privacy)
  input_hash: str               # SHA-256 of raw input (for dedup, not stored)
  rule_output: Output           # What the rule would have said
  ml_output: Output | null      # What the ML said (null in Phase 0)
  ml_confidence: float | null   # ML confidence (null in Phase 0)
  actual_output: Output         # What was actually used
  source: "rule" | "ml" | "rule_fallback"
  outcome: Outcome              # Recorded later via callback
  outcome_timestamp: ISO 8601 | null  # When outcome was recorded
  phase: int                    # Phase at time of invocation
  model_version: str | null     # Model version used (null in Phase 0)
```

### 2.3 Switch State

```
SwitchState:
  name: str                     # Unique identifier for this switch
  phase: Phase (0-3)
  phase_entered_at: ISO 8601
  model_version: str | null
  model_trained_at: ISO 8601 | null
  model_training_data_hash: str | null
  model_performance: ModelPerformance | null
  rule_performance: RulePerformance
  config: SwitchConfig
  feature_stats: FeatureStats   # Running mean/variance per feature
  
ModelPerformance:
  accuracy: float
  precision_per_class: dict[Output, float]
  recall_per_class: dict[Output, float]
  f1_per_class: dict[Output, float]
  confidence_mean: float
  confidence_std: float
  evaluated_on: int             # Number of outcomes in evaluation
  evaluated_at: ISO 8601

RulePerformance:
  accuracy: float
  evaluated_on: int
  evaluated_at: ISO 8601
```

### 2.4 Configuration

```
SwitchConfig:
  # Confidence
  confidence_threshold: float = 0.85
  
  # Retraining
  retrain_min_outcomes: int = 100
  retrain_schedule: duration | null = "24h"
  retrain_on_drift: bool = true
  
  # Phase transition
  shadow_min_outcomes: int = 50
  shadow_min_duration: duration = "7d"
  transition_significance: float = 0.05  # p-value threshold
  transition_min_improvement: float = 0.0  # ML must be at least this much better
  ml_primary_sustained_window: duration = "30d"
  ml_primary_max_fallback_rate: float = 0.05
  
  # Safety
  safety_critical: bool = false
  edge_case_test_set: list[TestCase] | null = null
  max_phase: Phase = Phase.ML_PRIMARY  # Cap phase (e.g., ML_WITH_FALLBACK for safety-critical)
  
  # Auto-revert
  revert_error_multiplier: float = 2.0
  revert_window: duration = "24h"
  revert_confidence_floor: float = 0.3
  
  # Model
  model_type: "gradient_boosted_tree" | "logistic_regression" | "random_forest" = "gradient_boosted_tree"
  max_tree_depth: int = 6
  
  # Storage
  outcome_log_format: "jsonl" | "sqlite" | "postgres" = "jsonl"
```

---

## 3) Lifecycle State Machine

```mermaid
graph TD
    subgraph Lifecycle["LearnedSwitch Lifecycle"]
        P0["Phase 0: RULE<br/>Deterministic only<br/>Logging outcomes"]
        P1["Phase 1: SHADOW<br/>ML trains + predicts<br/>Rule still decides"]
        P2["Phase 2: ML_WITH_FALLBACK<br/>ML decides if confident<br/>Rule catches uncertainty"]
        P3["Phase 3: ML_PRIMARY<br/>ML decides always<br/>Rule = circuit breaker"]
    end

    P0 -->|"outcomes ≥ shadow_min_outcomes"| P1
    P1 -->|"ML significantly better<br/>+ shadow_min_duration met<br/>+ edge cases pass"| P2
    P2 -->|"sustained superiority<br/>+ fallback_rate < threshold<br/>+ sustained_window met"| P3

    P3 -->|"error spike OR<br/>confidence collapse OR<br/>distribution shift"| P1
    P2 -->|"error spike OR<br/>confidence collapse"| P1
    P1 -->|"ML worse than rule<br/>after retraining"| P0

    style Lifecycle fill:#1a1a2e,color:#fff
    style P0 fill:#2d6f4a,color:#fff
    style P1 fill:#4a6f2d,color:#fff
    style P2 fill:#6f6f2d,color:#fff
    style P3 fill:#6f4a2d,color:#fff
```

**Transition guards:**

| Transition | Guard | Approval Required |
|---|---|---|
| P0 → P1 | `outcome_count >= shadow_min_outcomes` | No (automatic) |
| P1 → P2 | `ml_accuracy > rule_accuracy` with `p < transition_significance` AND `shadow_duration >= shadow_min_duration` AND (edge_case_test_set is null OR all pass) | Yes if `safety_critical` |
| P2 → P3 | `ml_superiority_sustained >= ml_primary_sustained_window` AND `fallback_rate < ml_primary_max_fallback_rate` AND `phase <= max_phase` | Yes if `safety_critical` |
| P2/P3 → P1 | `ml_error_rate > rule_error_rate * revert_error_multiplier` over `revert_window` OR `mean_confidence < revert_confidence_floor` | No (automatic safety) |
| P1 → P0 | ML retrained but still worse than rule | No (automatic) |

---

## 4) Core Algorithm

### 4.1 classify()

```python
def classify(self, input: Input) -> SwitchResult:
    features = self.feature_extractor(input)
    rule_output = self.rule(input)
    self._update_feature_stats(features)
    
    if self.phase == Phase.RULE:
        self._log_invocation(features, rule_output, None, None, "rule")
        return SwitchResult(output=rule_output, source="rule", confidence=1.0, phase=self.phase)
    
    # Phase 1, 2, or 3: ML classifier exists
    ml_output, ml_confidence = self.model.predict(features)
    
    if self.phase == Phase.SHADOW:
        # ML predicts but rule decides
        self._log_invocation(features, rule_output, ml_output, ml_confidence, "rule")
        if ml_output != rule_output:
            self._log_disagreement(features, rule_output, ml_output, ml_confidence)
        return SwitchResult(output=rule_output, source="rule", confidence=1.0, phase=self.phase)
    
    if self.phase == Phase.ML_WITH_FALLBACK:
        if ml_confidence >= self.config.confidence_threshold:
            self._log_invocation(features, rule_output, ml_output, ml_confidence, "ml")
            return SwitchResult(output=ml_output, source="ml", confidence=ml_confidence, phase=self.phase)
        else:
            self._log_invocation(features, rule_output, ml_output, ml_confidence, "rule_fallback")
            return SwitchResult(output=rule_output, source="rule_fallback", confidence=1.0, phase=self.phase)
    
    if self.phase == Phase.ML_PRIMARY:
        # Circuit breaker: check for anomaly
        if self._is_anomalous(features, ml_confidence):
            self._log_invocation(features, rule_output, ml_output, ml_confidence, "rule_fallback")
            self._log_anomaly(features, ml_confidence)
            return SwitchResult(output=rule_output, source="rule_fallback", confidence=1.0, phase=self.phase)
        
        self._log_invocation(features, rule_output, ml_output, ml_confidence, "ml")
        return SwitchResult(output=ml_output, source="ml", confidence=ml_confidence, phase=self.phase)
```

### 4.2 record_outcome()

```python
def record_outcome(self, input: Input, output: Output, outcome: Outcome):
    features = self.feature_extractor(input)
    input_hash = sha256(serialize(input))
    
    record = OutcomeRecord(
        input_features=features,
        input_hash=input_hash,
        outcome=outcome,
        outcome_timestamp=now(),
        # ... match to original invocation by input_hash + output
    )
    self.outcome_log.append(record)
    
    # Check if retraining should trigger
    if self._should_retrain():
        self._retrain()
    
    # Check if phase transition should trigger
    self._check_phase_transition()
```

### 4.3 Anomaly Detection (Circuit Breaker)

```python
def _is_anomalous(self, features: list[float], confidence: float) -> bool:
    # Confidence collapse
    if confidence < self.config.revert_confidence_floor:
        return True
    
    # Feature distribution shift (per-feature z-score)
    for i, f in enumerate(features):
        z = abs(f - self.feature_stats.mean[i]) / max(self.feature_stats.std[i], 1e-8)
        if z > 4.0:  # 4 sigma — very unusual
            return True
    
    return False
```

---

## 5) Training Pipeline

Training runs in a separate process (or thread) from inference.
Model swap is atomic.

### 5.1 Training Steps

```
1. Load outcome log → filter to records with known outcomes
2. Split: 80% train, 20% validation (stratified by label)
3. Extract features + labels from outcome records
4. Train model (sklearn, configured type)
5. Evaluate on validation set → ModelPerformance
6. Compare to rule performance on same validation set
7. Export model to ONNX
8. If validation passes:
   a. Write ONNX file to storage
   b. Atomic pointer swap (new model replaces old in inference)
   c. Update SwitchState with new model version + performance
9. If validation fails:
   a. Log failure reason
   b. Retain current model (or rule)
```

### 5.2 ONNX Export

```python
from skl2onnx import convert_sklearn
from skl2onnx.common.data_types import FloatTensorType

def export_to_onnx(model, n_features: int, output_path: str):
    initial_type = [("features", FloatTensorType([None, n_features]))]
    onnx_model = convert_sklearn(model, initial_types=initial_type)
    with open(output_path, "wb") as f:
        f.write(onnx_model.SerializeToString())
```

### 5.3 Statistical Validation

Phase transition requires statistical significance:

```python
from scipy.stats import binomtest

def ml_significantly_better(ml_outcomes, rule_outcomes, significance=0.05):
    """Test whether ML error rate is significantly lower than rule error rate."""
    ml_errors = sum(1 for o in ml_outcomes if o.outcome != Outcome.CORRECT)
    rule_errors = sum(1 for o in rule_outcomes if o.outcome != Outcome.CORRECT)
    n = len(ml_outcomes)
    
    # Null hypothesis: ML error rate >= rule error rate
    # Alternative: ML error rate < rule error rate
    rule_error_rate = rule_errors / len(rule_outcomes)
    result = binomtest(ml_errors, n, rule_error_rate, alternative="less")
    
    return result.pvalue < significance
```

---

## 6) Drift Detection

Two types of drift monitored:

### 6.1 Feature Drift (Input Distribution Shift)

Kolmogorov-Smirnov test on each feature's distribution, comparing
recent window to training data distribution:

```python
from scipy.stats import ks_2samp

def detect_feature_drift(recent_features, training_features, threshold=0.01):
    """Returns list of drifted feature indices."""
    drifted = []
    for i in range(len(recent_features[0])):
        recent_col = [f[i] for f in recent_features]
        training_col = [f[i] for f in training_features]
        stat, pvalue = ks_2samp(recent_col, training_col)
        if pvalue < threshold:
            drifted.append(i)
    return drifted
```

### 6.2 Concept Drift (Output Distribution Shift)

The relationship between features and correct labels changes over
time. Detected by monitoring rolling error rate:

```python
def detect_concept_drift(outcomes, window=100):
    """Returns True if recent error rate significantly exceeds baseline."""
    if len(outcomes) < window * 2:
        return False
    
    baseline = outcomes[:-window]
    recent = outcomes[-window:]
    
    baseline_errors = sum(1 for o in baseline if o.outcome != Outcome.CORRECT) / len(baseline)
    recent_errors = sum(1 for o in recent if o.outcome != Outcome.CORRECT) / len(recent)
    
    return recent_errors > baseline_errors * 2.0  # configurable multiplier
```

**Response to drift:** Trigger retraining. If retrained model still
shows drift, auto-revert to previous phase.

---

## 7) Confidence Calibration

Raw ML confidence scores are often miscalibrated. LearnedSwitch
applies Platt scaling (sigmoid calibration) to ensure that "85%
confidence" actually means "correct 85% of the time."

```python
from sklearn.calibration import CalibratedClassifierCV

def train_with_calibration(model, X_train, y_train, X_cal, y_cal):
    """Train model, then calibrate confidence on held-out set."""
    model.fit(X_train, y_train)
    calibrated = CalibratedClassifierCV(model, method="sigmoid", cv="prefit")
    calibrated.fit(X_cal, y_cal)
    return calibrated
```

Calibration is re-evaluated at each retraining. If calibration
degrades (reliability diagram shows significant deviation), the
confidence threshold is automatically tightened (more fallbacks)
until recalibration corrects it.

---

## 8) Storage Format

### 8.1 Outcome Log (JSONL, default)

```jsonl
{"id":"a1b2c3","ts":"2026-04-18T10:00:00Z","features":[0.5,1.2,0.0,3.1],"input_hash":"abc123","rule_out":"fast_path","ml_out":"deferred","ml_conf":0.72,"actual":"fast_path","source":"rule","outcome":null,"phase":1,"model_ver":"v2"}
{"id":"a1b2c3","ts":"2026-04-18T10:05:00Z","outcome":"correct","outcome_ts":"2026-04-18T10:05:00Z"}
```

Two record types: invocation records (at classify time) and
outcome records (at record_outcome time). Linked by `id`.

### 8.2 State File (JSON)

```json
{
  "schema_version": 1,
  "name": "signal_triage",
  "phase": 2,
  "phase_entered_at": "2026-04-10T00:00:00Z",
  "model_version": "v3",
  "model_trained_at": "2026-04-17T14:00:00Z",
  "model_training_data_hash": "sha256:abc123...",
  "model_performance": {
    "accuracy": 0.94,
    "f1_per_class": {"fast_path": 0.96, "deferred": 0.91, "urgent": 0.88}
  },
  "rule_performance": {
    "accuracy": 0.82,
    "evaluated_on": 4280
  },
  "feature_stats": {
    "mean": [0.5, 1.1, 0.2, 2.8],
    "std": [0.3, 0.8, 0.1, 1.2],
    "count": 4280
  },
  "config": { ... }
}
```

### 8.3 Model File

ONNX binary at `{storage_root}/{name}/model_v{N}.onnx`.
Previous versions retained for rollback:
`model_v1.onnx`, `model_v2.onnx`, `model_v3.onnx` (current).

---

## 9) Cross-Language Contract

All implementations MUST provide identical:

### 9.1 Public API

```
LearnedSwitch(name, rule, feature_extractor, labels, config, storage)
  .classify(input) → SwitchResult { output, source, confidence, phase }
  .record_outcome(input, output, outcome)
  .status() → SwitchStatus { phase, model_version, outcomes_total, error_rates, ... }
  .retrain() → RetrainResult  // manual trigger
  .reset(phase) → void        // manual phase override (admin)
  .export_model(path) → void  // export current ONNX model
  .export_codegen(language, path) → void  // export decision tree as native code
```

### 9.2 Configuration Schema

JSON Schema for `SwitchConfig`. Identical across languages.
Configuration loaded from JSON/YAML file or programmatic construction.

### 9.3 Storage Interface

```
Storage:
  .load_state() → SwitchState | null
  .save_state(state) → void
  .append_outcome(record) → void
  .load_outcomes(since: timestamp | null) → OutcomeRecord[]
  .load_model(version: str) → bytes (ONNX)
  .save_model(version: str, data: bytes) → void
```

Built-in implementations: `FileStorage` (default, works everywhere),
`SqliteStorage` (for embedded), `PostgresStorage` (for server).

### 9.4 Telemetry Interface

```
TelemetrySink:
  .on_classify(result: SwitchResult) → void
  .on_outcome(record: OutcomeRecord) → void
  .on_retrain(result: RetrainResult) → void
  .on_phase_transition(from: Phase, to: Phase, reason: str) → void
  .on_drift_detected(drift_type: str, details: dict) → void
```

Built-in implementations: `NoopSink` (default), `CallbackSink`
(user-provided function), `JsonlSink` (file logging).

---

## 10) Code Generation (Zero-Dependency Mode)

For environments where ONNX Runtime is unavailable (embedded,
edge nodes, WASM), LearnedSwitch can export a trained decision
tree as native source code in the target language.

### 10.1 Supported Targets

| Target | Output | Inference Dependency |
|--------|--------|---------------------|
| Python | `.py` file with nested if/else | None |
| Rust | `.rs` file with match arms | None |
| TypeScript | `.ts` file with if/else | None |
| Go | `.go` file with if/else | None |
| Java | `.java` file with if/else | None |
| C | `.c` file with if/else | None |
| WASM | `.wasm` via Rust compilation | None at runtime |

### 10.2 Generation Algorithm

```python
def export_tree_as_code(tree, feature_names, class_names, language):
    """Walk sklearn DecisionTree, emit native code."""
    # Recursive tree walk → emit if/else in target language
    # Each leaf emits: return (class_label, confidence)
    # Confidence = class_probability at leaf
```

### 10.3 Limitations

- Only tree-based models (decision tree, random forest, gradient
  boosted trees)
- No online retraining in codegen mode (model is baked into source)
- To update: retrain in Python, re-export, recompile
- Confidence scores are leaf-level class probabilities (less
  granular than ONNX continuous output)

---

## 11) Federation Extension

When LearnedSwitch instances at different institutions classify
the same decision type (e.g., "signal triage"), their outcome
data can be aggregated to train better models faster.

### 11.1 Federated Training Protocol

```
1. Each node trains a local model on its outcome data
2. On federation sync cycle:
   a. Each node exports model weights (not raw outcome data)
   b. Coordinator aggregates weights (federated averaging)
   c. Aggregated model distributed to all nodes
   d. Each node validates aggregated model against local
      validation set before accepting
3. If local validation fails:
   a. Node retains its local model
   b. Disagreement logged for research analysis
```

### 11.2 Privacy Guarantees

- Raw outcome data NEVER leaves the institution
- Only model weights (ONNX parameters) are shared
- Optional: differential privacy noise added to weights
  before sharing (configurable epsilon)
- Feature extractors may differ across institutions
  (same feature semantics, different raw inputs) — the
  ONNX model operates on the feature vector, not raw input

### 11.3 Cross-Institutional Validation

The research paper should measure:
- Does federated averaging improve accuracy vs. local-only training?
- At what institutional count does federation outperform local?
- How much distribution mismatch can federation tolerate before
  hurting accuracy?
- Is there a "free rider" problem (institution contributes little
  data but benefits from aggregated model)?

---

## 12) Axiom Deployment Details

### 12.1 Signal Triage (Deployment #1)

**Location:** `axiom/src/axiom/extensions/builtins/signals/triage.py`

**Rule (Phase 0):**
```python
def triage_rule(signal: Signal) -> TriageResult:
    if signal.signal_type == "security_alert":
        return TriageResult(tier="fast_path", priority="urgent")
    if signal.source in ("gitlab_diff", "github") and signal.confidence >= 0.9:
        return TriageResult(tier="fast_path", priority="background")
    if signal.signal_type in ("blocker", "action_item") and signal.confidence >= 0.8:
        return TriageResult(tier="fast_path", priority="normal")
    return TriageResult(tier="deferred", priority="normal")
```

**Feature extractor:**
```python
def extract_triage_features(signal: Signal) -> list[float]:
    return [
        SOURCES.index(signal.source),           # source type (ordinal)
        TYPES.index(signal.signal_type),         # signal type (ordinal)
        signal.confidence,                       # confidence (continuous)
        len(signal.people),                      # people mentioned (count)
        len(signal.initiatives),                 # initiatives mentioned (count)
        len(signal.raw_text),                    # text length (proxy for complexity)
        hour_of_day(signal.timestamp),           # time features
        day_of_week(signal.timestamp),
    ]
```

**Outcome signal:** When a signal is triaged to `fast_path` but later
requires LLM synthesis (human escalates or template notification is
insufficient), that's an `INCORRECT` outcome. When a signal is triaged
to `deferred` but could have been handled by template (human or system
confirms trivial handling), that's also `INCORRECT`.

**Expected crossover:** ~200-500 outcomes (2-3 weeks of classroom operation).

### 12.2 Intent Classification (Deployment #2)

**Location:** `axiom/src/axiom/core/retrieval_policy.py`

**Rule (Phase 0):**
```python
INTENT_KEYWORDS = {
    "lookup": ["what is", "define", "syntax", "how to"],
    "synthesis": ["compare", "contrast", "relationship between"],
    "diagnosis": ["why", "error", "not working", "debug"],
    "teaching": ["explain", "help me understand", "what does this mean"],
    "operations": ["status", "current", "right now"],
    "research": ["survey", "state of", "across", "comprehensive"],
}

def intent_rule(query: str) -> str:
    query_lower = query.lower()
    for intent, keywords in INTENT_KEYWORDS.items():
        if any(kw in query_lower for kw in keywords):
            return intent
    return "lookup"  # default
```

**Feature extractor:**
```python
def extract_intent_features(query: str) -> list[float]:
    return [
        len(query),                                  # query length
        query.count("?"),                            # question marks
        len(query.split()),                          # word count
        # keyword presence flags (one per keyword set)
        *[float(any(kw in query.lower() for kw in kws))
          for kws in INTENT_KEYWORDS.values()],
        # session context (if available)
        session_turn_number,                         # how deep in conversation
        time_since_last_query,                       # seconds
    ]
```

**Outcome signal:** RAG relevance score of the retrieval results.
If intent-guided retrieval scores > 0.7 relevance: `CORRECT`.
If < 0.5 and a different intent would have scored higher: `INCORRECT`
with correction label. Measured by comparing retrieval quality across
all intent strategies and checking if the selected one was optimal.

**Expected crossover:** ~500-1000 outcomes (intent is harder to learn
because the outcome signal is indirect — retrieval quality, not
direct human feedback).

### 12.3 Interaction Classification (Deployment #3)

**Location:** `axiom/src/axiom/extensions/builtins/classroom/classifier.py`

**Rule (Phase 0):** Keyword/regex-based per-turn labeling (Q&A if
contains question mark + factual answer; Generative if LLM produced
code/LaTeX/calculation; etc.)

**Outcome signal:** Instructor reviews and corrects labels during
weekly synthesis review. Each correction is an `OVERRIDE` outcome.

**Expected crossover:** ~100-300 outcomes (instructor corrections
are high-quality direct labels — fast convergence expected).

---

## 13) Research Instrumentation

Every LearnedSwitch instance logs data needed for the research paper:

### 13.1 Transition Curve Data

For each deployment, record at each retraining:
- Outcome count at time of retraining
- ML accuracy on validation set
- Rule accuracy on same validation set
- Phase at time of evaluation
- Whether transition guard passed

This produces a curve: `accuracy_delta(ML - rule)` vs. `outcome_count`.
The crossover point is where this curve first crosses zero with
statistical significance.

### 13.2 Category Classification

Each deployment is tagged with its category attributes:
- Outcome latency (seconds / minutes / hours / days)
- Distribution stability (stable / moderate / unstable)
- Label cardinality (number of output classes)
- Feature dimensionality
- Outcome quality (direct human label / indirect metric / inferred)

The paper analyzes whether these attributes predict the crossover
point. Hypothesis: direct human labels + stable distribution +
low cardinality → fastest crossover.

### 13.3 Federation Comparison

For deployments running on federated nodes:
- Local-only training accuracy at each retraining
- Federated training accuracy at each retraining
- Number of contributing institutions
- Distribution divergence between institutions (KL divergence)

The paper analyzes whether federation accelerates the crossover
and under what conditions.

### 13.4 Export Format

All research data exportable as:
- Parquet files (for statistical analysis in R/Python)
- CSV (for spreadsheet review)
- JSON (for programmatic access)

Command: `learned-switch export --format parquet --output ./research_data/`

---

## 14) Approval & Governance

LearnedSwitch ships a first-class governance model. Phase transitions
that swap the active ML head (P1→P2, P2→P3, and any auto-revert) are
routed through an `ApprovalBackend` before the pointer update takes
effect. The user-authored rule is never modified by the library — it
remains as the circuit-breaker floor.

### 14.1 Design constraints

- **Library-first.** The approval model ships in the standalone
  library with zero runtime dependencies beyond ONNX Runtime.
  Consumer systems (Axiom, enterprise deployments) plug in via a
  single protocol; the library never knows the consumer exists.
- **Rule stays code, ML head is data.** Updates swap a pointer in
  `active.json` that names the ONNX head file. No code redeploy at
  adoption or rollback.
- **Excellent zero-config defaults.** The default mode is `manual`
  with file-based proposal storage and a local CLI. Most users
  never need to touch any of §14 to get a safe, working system.

### 14.2 Proposal schema

Every phase-transition event produces a content-addressed JSON
record in `./learnedswitch/proposals/<id>.json`:

```json
{
  "id": "<sha256 of canonicalized JSON minus this field>",
  "switch_name": "signal_triage",
  "author": "ben",
  "proposed_at": "2026-04-19T10:42:00Z",
  "transition": {
    "from_phase": "ML_WITH_FALLBACK",
    "to_phase": "ML_PRIMARY",
    "reason": "sustained_superiority"
  },
  "old_head_hash": "<sha256>",
  "proposed_head_hash": "<sha256>",
  "evidence": {
    "n_samples": 4280,
    "p_value": 0.004,
    "ml_accuracy": 0.93,
    "rule_accuracy": 0.82,
    "beat_pct": 11.0,
    "flip_rate": 0.06,
    "shadow_period_hours": 72,
    "mean_confidence": 0.89,
    "confidence_collapse_detected": false,
    "drift_detected": null
  },
  "context": {
    "outcome_window_start": "2026-04-16T10:00:00Z",
    "outcome_window_end": "2026-04-19T10:00:00Z",
    "fallback_rate": 0.04
  },
  "auto_approved": false,
  "approved_by": null,
  "approved_at": null,
  "adoption_effective_at": null
}
```

ID is the SHA-256 of the canonicalized record (minus the `id` and
approval fields). Callers mirroring proposals into external stores
can verify authenticity via hash without custom signing.

### 14.3 ApprovalBackend protocol

```
ApprovalBackend:
  .evaluate(proposal: Proposal) → ApprovalDecision
  .on_adoption(proposal: Proposal) → void   # called after pointer update
  .on_revert(proposal: Proposal, reason: str) → void

ApprovalDecision:
  .outcome: "approve" | "reject" | "defer"
  .approver_identity: str          # opaque to the library
  .reason: str                     # audit text
  .adoption_effective_at: Timestamp | null   # null = immediate
```

Built-in implementations:

| Backend | Behavior |
|---|---|
| `ManualBackend` (default) | Always returns `defer`; proposal stays in `proposals/` until a `learnedswitch approve <id>` CLI call or explicit API approval |
| `ConservativeBackend` | Evaluates numeric preconditions (§14.4); returns `approve` only if all hold, else `defer`. Adoption delayed by `adoption_delay_hours`. |
| `StrictBackend` | Always returns `defer`. Intended for safety-critical switches where the caller's consumer-layer backend takes over. |

Custom backends implement the protocol and are injected via
`LearnedSwitch(..., approval_backend=...)`.

### 14.4 Conservative preconditions

`ConservativeBackend` returns `approve` iff **all** of the
following hold against the proposal's evidence payload:

```python
@dataclass
class ConservativePreconditions:
    min_samples: int = 1000
    min_p_value: float = 0.01
    min_beat_pct: float = 2.0
    max_flip_rate: float = 0.05
    shadow_period_hours: int = 24
    adoption_delay_hours: int = 1
    forbid_if_safety_critical: bool = True
    forbid_if_confidence_collapse_detected: bool = True
    forbid_if_drift_detected_types: tuple = ("input_distribution_shift",)
```

Any single violation → `defer` with the failed precondition named
in `reason`. Audit trail records which precondition failed for
debugging.

Overrides via dict:
```python
LearnedSwitch(..., automation={"mode": "conservative",
                               "min_samples": 5000,
                               "adoption_delay_hours": 4})
```

### 14.5 On-proposal callback

Optional hook for consumers that want push-style notification
without implementing a full `ApprovalBackend`:

```python
def notify(proposal: Proposal) -> None:
    send_slack_message(f"New LearnedSwitch proposal: {proposal.id}")

switch = LearnedSwitch(..., on_proposal=notify)
```

Called synchronously after proposal write, before backend
`evaluate`. Exceptions are logged and swallowed — a broken notifier
must never block the proposal lifecycle.

### 14.6 File layout

```
./learnedswitch/
  proposals/               # pending + historical proposals (JSON)
    <id>.json
  heads/                   # content-addressed ONNX heads
    <sha256>.onnx
  active.json              # { "head": "<hash>", "approved_by": "ben", "at": "..." }
  history.jsonl            # append-only adoption + revert log
  outcomes.jsonl           # (existing) outcome log
  config.json              # (existing) switch config
```

All storage operations go through the `Storage` interface (§9.3),
so non-file backends (SQLite, Postgres) work identically. File
layout above is the `FileStorage` default.

### 14.7 CLI

```
learnedswitch list [--switch <name>] [--status pending|approved|rejected]
learnedswitch show <id>
learnedswitch approve <id> [--as <identity>]
learnedswitch reject <id> [--reason <text>] [--as <identity>]
learnedswitch revert [--switch <name>] [--to <head-hash>]
learnedswitch status [<name>]
```

`--as` specifies approver identity (defaults to `$USER`). The
library treats identity as an opaque string; consumer-layer backends
can choose to verify it against a keystore, Axiom principal
registry, etc.

### 14.8 Consumer integration boundary

The standalone library stops here. Consumer-specific capabilities
live entirely outside the library:

| Capability | Lives in |
|---|---|
| Axiom-principal signature verification | `AxiomApprovalBackend` in the Axiom codebase |
| Proposal mirror → `MemoryFragment(episodic)` | Axiom consumer layer (subscribes to `on_proposal`) |
| EVE daily-brief surfacing of pending proposals | Axiom consumer layer |
| MCP tool for Claude-Code-based approval | Axiom consumer layer (tool delegates to library's approve API) |
| RACI fallback when author unreachable | `AxiomApprovalBackend` |
| Webhook fanout (Slack / Teams / PagerDuty) | Consumer wires `on_proposal` |
| Federated proposal propagation | Consumer layer (future; see §11) |

The library's CLI and file-based store are sufficient to run a
production deployment with zero consumer integration. Consumer
layers are additive, never load-bearing.
_Copyright (c) 2026 B-Tree Ventures, LLC. Apache-2.0 licensed._
