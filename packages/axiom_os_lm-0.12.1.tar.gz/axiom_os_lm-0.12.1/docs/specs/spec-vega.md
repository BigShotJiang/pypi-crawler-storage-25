# Technical Specification: Vega

**Spec:** Vega — Trust Infrastructure for Agentic AI
**Owner:** Benjamin Booth
**Status:** Draft — Phase 1 extraction scoped
**Last Updated:** 2026-04-21
**Parent PRD:** [prd-vega.md](../prds/prd-vega.md)

---

## 1) Overview

Vega is the trust, governance, and federation plane within the Axiom codebase. It ships as a distinct PyPI package (`vega-trust`) extracted from Axiom's `federation/` and `security/` modules; as a bundled dependency of Axiom itself; and as a server daemon for gateway and federation-peer deployments. Vega is not a separate codebase — it is a configured profile of Axiom with a distinct commercial and marketing identity.

### Core invariants

1. **Authorization is deterministic.** No LLM output gates access control. LLMs may advise; deterministic code decides. Per `spec-security.md §2`.
2. **Provenance is immutable.** Vega signatures on principals, attestations, and classification stamps are fixed at write-time. Updates produce new records with chain-of-custody linkage.
3. **Federation is additive, never required.** All Vega operations work on a single-node deployment without federation peers. Federation enables cross-node capabilities; it never creates a dependency.
4. **Enforcement at the server boundary.** Clients cannot bypass Vega. Every authorization, classification, and federation operation is handled by server-side code that the client cannot modify.
5. **Standards-first.** Vega integrates with OIDC, Envoy ExtAuthz, DNSSEC, A2A, Sigstore, OpenTelemetry via their published contracts, not proprietary extensions.

---

## 2) Architecture

### 2.1 Five Deployment Shapes

Vega ships one codebase, deploys in five configurations:

```mermaid
graph TD
    subgraph Codebase["Single Vega Codebase"]
        Core["Core primitives:<br/>identity, trust profiles,<br/>classification, RACI,<br/>federation protocol"]
    end

    Core --> S1["Shape 1: Embedded library<br/>(pip install vega-trust)"]
    Core --> S2["Shape 2: Bundled with Axiom<br/>(pip install axiom)"]
    Core --> S3["Shape 3: Gateway daemon<br/>(docker run vega-gateway)"]
    Core --> S4["Shape 4: Verification-only<br/>(pip install vega-trust-verify)"]
    Core --> S5["Shape 5: Federation peer<br/>(vega server)"]

    style Codebase fill:#2d4a6f,color:#fff
    style Core fill:#2d4a6f,color:#fff
    style S1 fill:#4a6f2d,color:#fff
    style S2 fill:#4a6f2d,color:#fff
    style S3 fill:#6f4a2d,color:#fff
    style S4 fill:#2d6f4a,color:#fff
    style S5 fill:#6f2d4a,color:#fff
```

Each shape is a subset of the codebase:
- Shape 1: only the Python library imports; no services running
- Shape 2: Vega bundled; Axiom runtime hosts all Vega services
- Shape 3: Vega gateway process only; no agent runtime
- Shape 4: verification subset of Shape 1 (lightweight)
- Shape 5: full Vega server with V-EGA agent

### 2.2 Package Structure

```
vega-trust/                          (PyPI package)
├── src/vega/
│   ├── __init__.py
│   ├── identity/
│   │   ├── keypair.py               # Ed25519 generation, storage
│   │   ├── principal.py             # @name:context resolution
│   │   ├── attestation.py           # multi-authority signatures
│   │   └── oidc.py                  # OIDC token validation
│   ├── trust/
│   │   ├── profile.py               # TrustProfile model
│   │   ├── category.py              # RACI category taxonomy
│   │   ├── raci_gate.py             # RaciGate class
│   │   └── slider.py                # slider heuristic logic
│   ├── classification/
│   │   ├── stamp.py                 # ClassificationStamp
│   │   ├── filter.py                # filter_by_ceiling utility
│   │   ├── export_control.py        # EAR/ITAR gates
│   │   └── spillage.py              # spillage detection
│   ├── federation/
│   │   ├── a2a.py                   # A2A protocol client
│   │   ├── peer.py                  # Federation peer model
│   │   ├── manifest.py              # Manifest channel sync
│   │   ├── discovery.py             # mDNS + DNS-SD + DNSSEC
│   │   └── resolution.py            # Resolution protocol (per design-resolution-protocol.md)
│   ├── verify/
│   │   └── signature.py             # Artifact signature verification
│   ├── server/
│   │   ├── app.py                   # FastAPI server for gateway shape
│   │   ├── ext_authz.py             # Envoy ExtAuthz gRPC
│   │   ├── opa_compat.py            # OPA-compatible HTTP API
│   │   └── vigil.py                 # V-EGA agent (Shape 5 only)
│   ├── cli/
│   │   ├── main.py                  # vega command dispatch
│   │   └── commands/                # subcommands
│   └── telemetry.py                 # OpenTelemetry spans
├── tests/
├── docs/
└── pyproject.toml
```

---

## 3) Data Model

### 3.1 Identity

```python
@dataclass(frozen=True)
class Keypair:
    public: bytes          # Ed25519 public key, 32 bytes
    private: bytes | None  # Ed25519 private key, 32 bytes; None for remote-only
    fingerprint: str       # SHA-256 of public, grouped by 4s

@dataclass(frozen=True)
class Principal:
    name: str              # "ben-booth"
    context: str           # "ut-austin"
    keypair: Keypair
    attestations: list[Attestation]  # institutional signatures

    def qualified_name(self) -> str:
        return f"@{self.name}:{self.context}"

@dataclass(frozen=True)
class Attestation:
    subject: Principal
    issuer: Principal
    claim: dict            # {"role": "faculty", "clearance": "restricted"}
    issued_at: datetime
    expires_at: datetime
    signature: bytes       # Ed25519 signature over canonical claim encoding
```

### 3.2 Trust Profile

```python
@dataclass(frozen=True)
class SliderPosition(IntEnum):
    ALWAYS_PROMPT = 0
    AUTO_APPROVE_WITH_AUDIT = 1
    AUTO_APPROVE_SILENT = 2
    REFUSE = 3

@dataclass(frozen=True)
class TrustProfile:
    name: str                           # "classroom-default"
    description: str
    categories: dict[str, SliderPosition]
    version: int
    issuer: Principal
    signature: bytes
    created_at: datetime
```

Built-in categories include:
- `knowledge_promotion` (per maturity tier)
- `cross_federation_data_pull`
- `classified_content_access`
- `export_controlled_content_access`
- `agent_spawn`
- `tool_execution` (subcategorized by action category)
- `federation_admission`
- `financial_action`

Extensions can add categories via registration.

### 3.3 Classification Stamp

Per `spec-classification-boundary.md §2`:

```python
@dataclass(frozen=True)
class ClassificationStamp:
    level: ClassificationLevel          # UNCLASSIFIED, CUI, SECRET, TS, etc.
    compartments: set[str]              # SCI compartments
    export_control: ExportControl       # EAR99, ITAR, 10CFR810, none
    proprietary: Proprietary            # contract-governed restrictions
    provenance: Provenance              # originator, creation context
    issued_at: datetime
    signature: bytes
```

### 3.4 Federation Peer

```python
@dataclass(frozen=True)
class FederationPeer:
    identity: Principal
    endpoint: str                       # https://vega.example.edu:8443
    capabilities: list[Capability]
    relationship: Relationship          # cluster, partner, federated
    admitted_at: datetime
    membership_manifest: Manifest
    last_heartbeat: datetime | None
```

### 3.5 RACI Gate Decision

```python
@dataclass(frozen=True)
class RaciDecision(Enum):
    ALLOW = "allow"
    ALLOW_WITH_AUDIT = "allow_with_audit"
    PROMPT_HUMAN = "prompt_human"
    REFUSE = "refuse"

@dataclass(frozen=True)
class RaciGateResult:
    decision: RaciDecision
    reason: str                        # human-readable
    category: str                      # which category drove the decision
    audit_record_id: str | None        # ID of audit entry if logged
```

---

## 4) API Contracts

### 4.1 Python Library API (Shapes 1, 2, 4)

```python
from vega.identity import Principal, Keypair, OIDCValidator
from vega.trust import TrustProfile, RaciGate
from vega.classification import ClassificationStamp, filter_by_ceiling
from vega.federation import A2AClient, FederationPeer
from vega.verify import verify_signature

# Identity
principal = Principal.load("@ben:ut-austin")
oidc = OIDCValidator(issuer="https://login.ut-austin.edu", audience="axiom")
principal = oidc.resolve(token=bearer_token)

# Trust profile
profile = TrustProfile.load("classroom-default")
gate = RaciGate(principal=principal, profile=profile)

# Authorization
result = gate.evaluate(
    category="tool_execution",
    action="delete_document",
    resource=doc_id,
    context={"doc_classification": stamp},
)
if result.decision == RaciDecision.REFUSE:
    raise PermissionDenied(result.reason)

# Classification
filtered_chunks = filter_by_ceiling(chunks, principal.clearance)

# Federation
peer_client = A2AClient(peer_endpoint="https://vega.inl.gov:8443")
response = await peer_client.send_message(
    from_principal=principal,
    to_agent="curio@inl",
    message=msg,
)

# Verification (Shape 4)
is_valid = verify_signature(
    artifact_path="dendra-0.5.0.whl",
    signature_path="dendra-0.5.0.whl.sig",
    expected_signer="@axiom-labs:release",
)
```

### 4.2 Gateway HTTP API (Shape 3)

OPA-compatible at `/v1/data/*`:

```
POST /v1/data/vega/authz
  Request body: {"input": {"principal": "@alice:ut", "action": "read", "resource": "..."}}
  Response: {"result": {"allow": true, "reason": "trust_profile:classroom-default", "audit_id": "..."}}
```

Vega-specific endpoints:

```
POST /classify
  {content: "...", context: {principal: "..."}}
  → 200 {classification: {...}, filtered: "..."}

POST /federation/resolve
  {capability: "...", constraints: {...}}
  → 200 {providers: [...], delegation_chain: [...]}

POST /verify
  {artifact_hash: "...", signature: "..."}
  → 200 {valid: true, signer: "...", attestation_chain: [...]}

GET /.well-known/vega-manifest.json
  → Vega instance's advertised capabilities and federation status
```

### 4.3 Envoy ExtAuthz gRPC API (Shape 3)

Implements the Envoy `envoy.service.auth.v3.Authorization` service contract:

```protobuf
service Authorization {
  rpc Check(CheckRequest) returns (CheckResponse);
}
```

Vega translates Envoy's request context (headers, source, destination) into principal + action + resource + context, applies trust profile, returns allow/deny with optional header modifications (e.g., adding classification stamp to authorized responses).

Existing Envoy/Istio deployments adopt Vega by pointing their `envoy.filters.http.ext_authz` at Vega's gRPC service. No application-level code changes.

### 4.4 CLI API

```
vega identity create <name> --context <context>
vega identity show <principal>
vega identity sign <file> [--key <path>]

vega trust profile create <name>
vega trust profile show <name>
vega trust profile edit <name>
vega trust profile share <name> [--to <peer>]

vega federation peer init --node-id <principal>
vega federation peer join --invitation-token <token>
vega federation peer list
vega federation peer quarantine <peer>
vega federation peer recover <peer>

vega classification stamp <file> --level <level>
vega classification validate <file>

vega audit query [--principal ...] [--since ...] [--category ...]
vega audit export --format parquet --output <path>

vega verify <artifact> --signature <sig>

vega server --profile gateway    # Shape 3
vega server --profile peer       # Shape 5
```

---

## 5) Integration Points

### 5.1 OIDC / Enterprise IAM

Vega's `OIDCValidator` accepts tokens from any OIDC-compliant provider. Configuration specifies:

- Issuer URL
- Audience
- JWKS endpoint (auto-discovered via `.well-known/openid-configuration`)
- Claim mapping (which JWT claim maps to Vega principal name / clearance / role)

Pre-configured templates for AWS IAM Identity Center, Azure AD, Okta, InCommon (universities), PIV/CAC (federal government).

```python
from vega.identity import OIDCValidator

validator = OIDCValidator(
    issuer="https://identity.ut-austin.edu",
    audience="vega",
    principal_claim="preferred_username",
    clearance_claim="custom:clearance",
)

principal = validator.resolve(token=jwt_bearer_token)
```

### 5.2 Envoy / Service Mesh

Per §4.3. Envoy's ExtAuthz HTTP/gRPC contract is implemented by Vega's gateway. Istio, Emissary, Gloo, Ambassador, and Kong all support ExtAuthz — all can adopt Vega with configuration only.

### 5.3 DNSSEC + DNS-SD

Per `docs/working/design-resolution-protocol.md`. Vega federation discovery uses:

```
_vega._tcp.example.edu.  IN SRV  10 100 8443  vega.example.edu.
                         IN TXT  "v=1" "federation=triga-consortium"
                         IN RRSIG ...
```

Joining peers validate the DNSSEC chain before accepting SRV records as authoritative. Prevents DNS spoofing during federation bootstrap.

### 5.4 Sigstore

Artifact signing uses Sigstore's OIDC-to-cert flow. Signers authenticate with their institutional OIDC; Sigstore issues a short-lived certificate; Vega records the certificate + signature in the audit trail.

No long-lived signing keys required. Keyless signing aligns with industry best practices (used by Kubernetes, npm, PyPI).

### 5.5 OpenTelemetry

Every Vega operation emits an OTel span:
- `vega.identity.resolve` — span per principal resolution
- `vega.trust.evaluate` — span per RACI gate evaluation
- `vega.classification.filter` — span per content filter
- `vega.federation.rpc` — span per A2A call

Tenants can route to their existing observability stack (Datadog, Honeycomb, Prometheus, Langfuse).

### 5.6 A2A Protocol

Vega is a v0.3+ A2A-compliant implementation. Every Vega principal can serve as an A2A agent, publishing an Agent Card at `/.well-known/agent-card.json`. Federation participants discover each other via A2A before escalating to deeper Vega trust semantics.

---

## 6) V-EGA Federation Agent

### 6.1 Responsibilities

V-EGA is an always-on agent included in Shape 5 (federation peer) deployments. It handles:

- **Peer health monitoring.** Heartbeat tracking, availability alerts.
- **Manifest freshness verification.** Detects stale or replayed manifests.
- **Trust profile re-validation.** Applies the validated classification pattern: observes agent behavior, flags drift, proposes trust-profile adjustments to humans.
- **Quarantine initiation.** Detects compromised peers; initiates quarantine protocol.
- **Recovery ceremony participation.** Guides human operators through trust re-establishment.
- **RACI escalation context.** When a RACI gate escalates to human review, V-EGA provides contextual information (prior similar decisions, trust profile derivation, classification rationale).
- **Federated finding cross-validation.** Consults peer Vega agents when CURI-O or equivalent produces findings that would benefit from multi-institutional corroboration.

### 6.2 Character Convention

V-EGA follows the Axiom agent-naming convention (WALL-E-style): two-syllable, hyphenated, all-caps. Evokes "vigilance" without negative surveillance connotations.

Agent identity: `vigil@{node-context}` (e.g., `vigil@rascal:ut-austin`).

### 6.3 Boundary with Other Agents

V-EGA has no authorization power. It advises humans, cross-validates findings, and monitors — but every action goes through the same deterministic RACI gate as any other agent's actions. Per core invariant 1 (authorization is deterministic).

### 6.4 Optional, Not Required

Shapes 1-4 do not run V-EGA. Only Shape 5 (federation peer) includes V-EGA automatically. Operators can disable V-EGA in favor of pure human operation if preferred.

---

## 7) Migration from Current Axiom Code

### 7.1 Source Paths Being Extracted

From `axiom/src/axiom/` into `vega-trust/src/vega/`:

| Current Path | Destination |
|---|---|
| `federation/` | `src/vega/federation/` |
| `security/` | `src/vega/trust/` + `src/vega/classification/` |
| `identity/` | `src/vega/identity/` |

### 7.2 Public API Surface Axiom Retains

After extraction, Axiom imports Vega:

```python
# Before (in Axiom code)
from axiom.federation import FederationPeer
from axiom.security.raci import RaciGate

# After
from vega.federation import FederationPeer
from vega.trust import RaciGate
```

Axiom `pyproject.toml` gains:

```toml
dependencies = [
    ...
    "vega-trust>=0.1.0,<0.2.0",
]
```

### 7.3 Breaking Changes

Extraction should be a **move-only refactor** for Phase 1. No API changes, no behavior changes. Import paths change; everything else stays identical.

Version: Axiom's next release after extraction (probably 0.14.0) is the first that imports `vega-trust`. Upgrade path for Axiom consumers: `pip install --upgrade axiom` automatically pulls in `vega-trust`.

### 7.4 Deprecation Policy

Axiom's existing `axiom.federation`, `axiom.security`, `axiom.identity` modules become compatibility shims for one minor version cycle:

```python
# axiom/federation/__init__.py (shim)
import warnings
warnings.warn(
    "axiom.federation has moved to vega.federation. "
    "This shim will be removed in axiom 0.16.",
    DeprecationWarning,
)
from vega.federation import *  # noqa
```

After 0.16, shims are deleted; consumers must import from `vega.*` directly.

---

## 8) Testing Strategy

### 8.1 Unit tests

Each module in `vega-trust/src/vega/*/` has unit tests in `vega-trust/tests/unit/`. Target: 90%+ coverage on identity, trust, classification, verify modules.

### 8.2 Integration tests

- **Two-node federation test.** Two Vega instances join a federation, exchange manifests, perform cross-node authz. Runs in CI via Docker Compose.
- **Envoy ExtAuthz integration.** Envoy proxy deployed alongside Vega gateway; canary request flows through; authz decision verified.
- **OIDC integration.** Mock OIDC IdP issues tokens; Vega validates; principal resolution verified.

### 8.3 Compatibility tests

Axiom's test suite runs against Vega main + Vega latest-release. Breakage detected before Vega releases.

Consumer tests: sample LangChain app, sample CrewAI crew — both integrate Vega via embedded library; trust profile and RACI gate behavior verified end-to-end.

### 8.4 Security tests

Per ADR-025 threat model:
- Identity spoofing attempts (T-ID1 through T-ID4)
- Manifest replay/rollback (T-MB1)
- Eclipse attack simulation (T-MB2)
- Cross-domain spillage (T-CL2)

Red-team suite via promptfoo-style adversarial scenarios on classification-aware tool calls.

### 8.5 Performance tests

- Authorization decision latency (single-node library): target p99 < 50ms
- Gateway HTTP authz throughput: target 10K req/sec on single node
- Federation resolution latency: target p99 < 500ms across three-peer federation

---

## 9) Security Model

Per `spec-security.md §2` (deterministic/model-mediated boundary):

- **Authorization is deterministic.** No LLM in the authorization path.
- **LLM may advise.** V-EGA uses LLM for anomaly explanation, policy suggestions — never for approval.
- **Humans decide escalations.** RACI `PROMPT_HUMAN` outcomes always reach a real human.
- **Audit trail is append-only.** Per ADR-011 (`locked_append_jsonl`). Tamper evidence via hash chains.
- **Cryptographic identity end-to-end.** Every principal, manifest, attestation, and classification stamp is Ed25519-signed.

Threat model per ADR-025 (14 threat categories, mitigations for each). Defense in depth: attacker must bypass all of cryptographic identity, membership manifest validation, classification stamp enforcement, trust profile authorization, audit logging, and human escalation to achieve unauthorized access.

---

## 10) Open Questions

1. **V-EGA name confirmation.** Fallbacks: WAR-DEN, SEN-TRI.
2. **Domain and repo name.** `vega-trust` as both PyPI package and GitHub repo is one option; alternatives include `vegaprotocol-trust`, `vega-trust-infra`.
3. **Gateway distribution.** Docker Hub vs. ghcr.io vs. Quay — pick one primary.
4. **Foundation stewardship.** CNCF sandbox, LF AI project, or independent initially? Timing affects IP strategy.
5. **Commercial license terms.** Apache 2.0 + commercial-features-separately-licensed vs. open-core with dual licensing. OTC guidance needed.
6. **Integration test hosting.** Integration repo (`axiom-integration`) runs nightly tests across Axiom + Vega + Dendra + Keplo + Vyzier; where and how? Self-hosted runners on Rascal vs. GitHub Actions.

---

## 11) Revision History

| Date | Change | Author |
|---|---|---|
| 2026-04-21 | Initial draft | Benjamin Booth |
