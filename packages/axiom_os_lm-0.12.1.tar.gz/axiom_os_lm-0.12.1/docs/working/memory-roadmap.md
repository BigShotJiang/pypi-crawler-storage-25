# Memory Platform — Consolidated Roadmap

**Status:** Active draft (2026-04-26)
**Owner:** Ben Booth
**Purpose:** One ordered priority list across every memory-related plan: PRD phases, ADR stages, spec follow-ups, tooling, benchmarks. The PRD + ADR each describe slices of the work; this doc resolves them into a single sequence.
**Replaces (when conflicts arise):** PRD-memory §8 timeline, ADR-033 Migration table, ad-hoc tracking in working notes.

---

## 1. What's in flight (audit)

### 1.1 Already shipped (Phase 0 + Phase 1 + part of Phase 2)

| What | Where | Status |
|---|---|---|
| Layered architecture commitment | ADR-033 | shipped |
| Federation policy primitives (Visibility / Classification / Trust / Gateway protocol) | spec-federation-policy + axiom.vega.federation.policy | shipped |
| MemoryFragment.visibility + .classification fields | axiom.memory.fragment | shipped |
| L1 dual-write adapter (Stage 1) | axiom.memory.adapters | shipped |
| RecentActivityProjection (Stage 3 first inhabitant) | axiom.memory.projections | shipped |
| Stage 3 perf optimization (101× projection speedup) | axiom.artifacts.registry SQLiteBackend.find_fragments + index | shipped |
| Stage 2 minimum-viable concept graph | axiom.memory.graph | shipped |
| Stage 2 deterministic text extractor + classification gate | axiom.memory.graph.DeterministicTextExtractor + ExtractorRegistry | shipped |
| Compliance suite (12/14 invariants pass) | tests/memory/test_compliance.py + memory_compliance marker | shipped |
| Periodic benchmark CI | .github/workflows/memory-benchmarks.yml | shipped |
| Baseline + Stage 3 + integrated benchmark JSONs | docs/working/memory-benchmarks-baseline-*.json | pinned |
| Build_memory_stack ergonomic bootstrap | axiom.memory.bootstrap | shipped |
| prd-memory + spec-memory + spec-federation-policy + benchmarks | docs/{prds,specs,working}/ | shipped |
| Adjacent-spec amend-PRs (knowledge-graph, session-store, agent-state-management) | docs/specs/spec-*.md | shipped |
| Three open questions decided (concept identity, time-travel, lint gradient) | spec-memory §14 + prd-memory §9 | shipped |

That's a substantial Phase 1 + early Phase 2 + early Stage 3. **The platform is real today — the prioritization question now is "what defends the claim and unblocks adoption."**

### 1.2 In the queue (everything else)

Grouped by category, not yet ordered:

**Tooling (extension-author affordances)**

- [tool-1] `axi ext init --memory=<profile>` — scaffold a manifest + a build_memory_stack call
- [tool-2] `axi ext lint --memory` — manifest-vs-source cross-checker (the §9.6 patterns)
- [tool-3] `axi ext shadow-audit <ext>` — runtime audit tool
- [tool-4] `MigrateToMemory` helper for existing bespoke stores

**Spec simplification (lower the cost of doing the right thing)**

- [doc-1] spec-memory Quick Start + Choose Your Path navigation
- [doc-2] working/memory-quickstart.md — 1-page extension-author getting-started
- [doc-3] working/memory-interop.md — MCP / OASF / Letta / Mem0 mapping

**Performance + scale**

- [perf-1] Stage-3-of-L2: evidence-table refactor (the quadratic write-cost finding)
- [perf-2] Async extractor execution (per spec I13)
- [perf-3] Projection cache layer (when measurement says it's worth it)

**Public benchmarks (defend the "best memory platform" claim)**

- [bench-1] LongMemEval — first run + comparison vs Mem0 v0.1
- [bench-2] LoCoMo — long conversational memory
- [bench-3] MemBench — episodic recall

**Spec follow-ups (advanced capabilities)**

- [spec-1] spec-memory-reflection — Park et al. consolidation
- [spec-2] spec-memory-hierarchy — MIRIX hierarchy operationalized (working → recall → archival)
- [spec-3] spec-memory-storage-discipline — ADR-033 follow-up; lint rule details + audit format

**Stage 4–6 architecture**

- [arch-4] Stage 4 — blob store extraction; manifest-as-projection
- [arch-5] Stage 5 — federation gateway end-to-end (closes compliance C4 + C9)
- [arch-6] Stage 6 — second-extension proof (chat or research-loop on the same primitives)

**Compliance debt**

- [comp-1] C4 — gateway scope-internal isolation (lands with Stage 5)
- [comp-2] C9 — hop-bound enforcement (lands with Stage 5)

**Per-extension migration (PRD references but not yet written)**

- [ext-1] classroom PRD addendum: per-persona memory affordances + concrete extension ↔ archetype mapping
- [ext-2] chat extension PRD memory section
- [ext-3] research extension PRD memory section (when the extension exists)

---

## 2. Strategic frame — three forcing constraints

What's driving the ordering:

1. **Classroom Prague v0 must keep working.** Anything that risks the shipped behavior is post-Prague.
2. **"Best memory platform" is defended by tests, not docs.** Public benchmarks are how the claim survives a competitive audit. They should land as soon as Stage 2 stabilizes (which it has — minimum-viable shipped, evidence-table refactor pending).
3. **Adoption stalls without ergonomics.** The spec is the contract; the tooling is what extension authors actually use. Tooling-without-spec is risky; spec-without-tooling is friction.

The order below resolves these constraints.

---

## 3. Recommended priority order

### Tier 1 — defend the claim + unblock authors (next ~1-2 weeks)

| # | Item | Why this tier | Effort |
|---|---|---|---|
| 1 | **[doc-1] spec-memory Quick Start + Choose Your Path** | Without this, the spec is unusable as an onboarding doc. ~95% of extension authors should never need to read past §1. | 0.5 day |
| 2 | **[tool-1] `axi ext init --memory=<profile>`** | Authors who scaffold from a template start lint-clean. Specs become invisible to the typical author. | 1 day |
| 3 | **[tool-2] `axi ext lint --memory`** | The "we have policy" claim only works if it catches drift at PR time. Today the policy lives in the spec; this tool enforces it. | 1-2 days |
| 4 | **[doc-2] working/memory-quickstart.md** | One-page getting-started for extension authors. Linked from spec Quick Start. | 0.5 day |
| 5 | **[bench-1] LongMemEval first run** | Defends the "best memory platform" claim measurably. Even if the first number is at-parity (not surplus), publishing it is what makes the claim defensible. Post-Stage 2 is the right time — concept graph is online. | 2 days |
| 6 | **[perf-1] Stage-3-of-L2 evidence-table refactor** | Surfaced by integrated benchmark; quadratic write-cost gap. Blocks scale measurement at 100k+. Half-day with tests. | 0.5 day |

**Tier 1 total: ~5-6 days of focused work.** Outcome: authors have spec navigation + scaffolding + lint enforcement + first defensible public-benchmark number + Stage 2 perf at scale.

### Tier 2 — next round of capabilities (next ~2-3 weeks)

| # | Item | Why this tier | Effort |
|---|---|---|---|
| 7 | **[spec-1] spec-memory-reflection** | The biggest user-visible value beyond episodic recall. Park et al. style consolidation: episodes → semantic facts via periodic synthesis. Specced first, then implemented. | 1 day spec + 2-3 days impl |
| 8 | **[tool-3] `axi ext shadow-audit <ext>`** | Runtime audit tool. Once lint is in place, this is the operator-side complement. | 1 day |
| 9 | **[bench-2] LoCoMo** | Second public benchmark. Strengthens the comparison surface. | 1-2 days |
| 10 | **[perf-2] Async extractor execution** | Required for chat-extension working memory (synchronous extractor blocks chat). Useful even before the chat extension consumes Stage 6. | 1 day |
| 11 | **[doc-3] working/memory-interop.md** | MCP / OASF / Letta / Mem0 adapter shapes. Gives the third-party agent author a "I can plug in" claim. | 1 day |

**Tier 2 total: ~7-9 days.** Outcome: reflection capability shipped, second benchmark defended, chat extension unblocked.

### Tier 3 — post-Prague architecture (next ~1 month)

| # | Item | Why this tier |
|---|---|---|
| 12 | **[arch-4] Stage 4 — blob store extraction** | Materials at scale; manifests become projections. Touches the materials path; classroom v0 is already shipped, so post-Prague is the safe landing. |
| 13 | **[spec-2] spec-memory-hierarchy** | Working → recall → archival operationalized. Sets up Stage 6 chat working-memory. |
| 14 | **[arch-5] Stage 5 — federation gateway** | Closes compliance C4 + C9. Post-Prague because the v0 cohort doesn't yet need cross-cohort federation. |
| 15 | **[bench-3] MemBench** | Third public benchmark. Quarterly cadence. |
| 16 | **[tool-4] MigrateToMemory helper** | Becomes load-bearing once a second extension migrates off bespoke storage. |

**Tier 3 total: 2-3 weeks once started.**

### Tier 4 — second-extension proof + extension-team docs

| # | Item |
|---|---|
| 17 | **[arch-6] Stage 6 — second extension proof** (chat or research-loop migrates) |
| 18 | **[ext-1] classroom PRD addendum: per-persona memory mapping** |
| 19 | **[ext-2] chat extension PRD memory section** |
| 20 | **[ext-3] research extension PRD memory section** |

These land naturally as the consuming extensions evolve; no tight schedule.

---

## 4. What's wrong with the current PRD timeline

prd-memory §8 says:

| Phase | Window | Deliverable |
|---|---|---|
| Phase 2 | 2 wk | Stage 2 — L2 concept graph |
| Phase 3 | 2 wk | Stage 3 — additional projections + reflection |
| Phase 4 | post-Prague | Stage 4 — blob store extraction |
| Phase 5 | post-Prague | Stage 5 — federation gateway |
| Phase 6 | quarter+ | Stage 6 — second-extension proof |

**Two corrections vs the current state + the right priorities:**

- **Phase 2 is largely done.** Minimum-viable concept graph + extractor + classification gate shipped. What's left is Stage-3-of-L2 (evidence-table refactor) + cross-extension extractor development. PRD should reflect this.
- **The PRD doesn't include tooling, benchmarks, or simplification.** These are the actual unblocking items right now per Tier 1 above. They're tied for higher priority than reflection (Phase 3 in the PRD).

**Recommended PRD §8 update** — see §6 below.

---

## 5. What's wrong with the ADR-033 migration table

ADR-033 stages are correct in shape but the table doesn't cover non-architectural work (tooling, benchmarks, docs). It's the architecture-only roadmap; this doc is the platform-wide one. They cooperate:

| ADR-033 stage | This roadmap's coverage |
|---|---|
| Stage 1 (dual-write) | shipped |
| Stage 2 (graph) | minimum-viable shipped; Stage-3-of-L2 perf refactor in Tier 1 (#6) |
| Stage 3 (projections) | first inhabitant shipped + perf optimized; reflection projection in Tier 2 (#7) |
| Stage 4 (blob extraction) | Tier 3 (#12) |
| Stage 5 (federation gateway) | Tier 3 (#14); compliance C4 + C9 land here |
| Stage 6 (second-extension) | Tier 4 (#17) |

ADR-033 stays the architecture commitment; this roadmap stays the platform-wide priority order.

---

## 6. Recommended PRD §8 + ADR-033 updates

If accepted, two small edits:

**prd-memory.md §8 timeline** — replace the existing table with:

```
Phase 1 (shipped)        Architecture committed; first L1+L3 path; Stage 1 + minimum-viable Stage 2; benchmarks pinned
Phase 2 (current, 1-2wk) Tier 1: docs, tooling, first public benchmark, Stage-3-of-L2 perf
Phase 3 (next, 2-3wk)    Tier 2: reflection, audit tool, more benchmarks, async extractors
Phase 4 (post-Prague)    Tier 3: blob extraction, hierarchy, federation gateway, more benchmarks
Phase 5 (later)          Tier 4: second-extension proof, per-extension memory addenda
```

**ADR-033 Migration path** — no change. The ADR's stages are the architectural skeleton; the roadmap supplies the platform-wide ordering.

---

## 7. What this means concretely for the next session

If the recommendation is accepted, the next session does exactly **Tier 1, in this order**:

1. spec-memory Quick Start + Choose Your Path (0.5 day)
2. `axi ext init --memory=<profile>` scaffold (1 day)
3. `axi ext lint --memory` linter (1-2 days)
4. memory-quickstart.md (0.5 day)
5. LongMemEval first run + report (2 days)
6. Stage-3-of-L2 evidence-table refactor (0.5 day)

Five working days of focused work. Outcome at the end:

- An extension author goes from `axi ext init my-thing --memory=collaborative-learning` to a working memory-correct extension in <5 minutes
- Lint catches drift at PR time, not audit time
- One public benchmark number defends the "best memory platform" claim measurably
- Scale measurement at 100k+ unblocked

That's the most leverage available right now.

---

## 8. Decisions needed from product owner

Two judgment calls before Tier 1 starts:

1. **Is LongMemEval the right first public benchmark?** Alternatives: LoCoMo (longer-form conversational), MemBench (episodic recall), or a custom Axiom benchmark that exercises differentiation surfaces directly. Recommendation: LongMemEval because it's the most-cited and gives apples-to-apples comparison with Mem0 / Letta / MemGPT.

2. **`axi ext init` scope.** The tool exists in spec but not in code. Should it be a fresh implementation or extend an existing scaffolding command (if one exists in `axi ext` already)? Recommendation: extend if available, else greenfield.

If both are "your call," Tier 1 proceeds with the defaults above.