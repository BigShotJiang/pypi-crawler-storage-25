#!/usr/bin/env python3
# Copyright (c) 2026 The University of Texas at Austin
# SPDX-License-Identifier: Apache-2.0
"""Integrated memory benchmark — exercises L1 + L2 + L3 together.

Per ``working/memory-benchmarks.md §5`` (custom Axiom benchmarks).
Where ``memory-benchmarks-baseline.py`` measures L1 + L3 in isolation,
this harness drives the full layered stack via ``build_memory_stack``:

  - L1 writes via CompositionService (signed, audited, classified)
  - L2 extraction fires on every write (deterministic text extractor)
  - L3 projection runs over the resulting concept graph + L1 log

Output: machine-readable JSON dict on stdout. Captured in dated files
under ``docs/working/`` and summarized in
``working/memory-benchmarks-trend.md``.

Run:
    python3 docs/working/memory-benchmarks-integrated.py
"""

from __future__ import annotations

import json
import sys
import tempfile
import time
from pathlib import Path


def _make_stack(tmp: Path):
    from axiom.memory.bootstrap import build_memory_stack
    return build_memory_stack(scope_id="bench-scope", data_root=tmp)


def _write_with_extraction(stack, *, n: int, base_index: int = 0) -> tuple[float, dict]:
    """Returns (elapsed_ms_total, totals dict from extractors)."""
    totals = {"concepts": 0, "edges": 0, "fragments": 0}
    t0 = time.perf_counter()
    for i in range(base_index, base_index + n):
        fragment = stack.composition.write(
            content={
                "event_time": f"2026-04-26T1{i % 10}:{(i // 10) % 60:02d}:00+00:00",
                "classroom_id": "bench-scope",
                "question": (
                    f"What is criticality and how do control rods "
                    f"affect reactor power #{i}"
                ),
                "had_answer": True,
                "citations_count": 1,
                "mode": "ask",
            },
            cognitive_type="episodic",
            principal_id=f"s{i % 30}",
            agents=set(),
            resources=set(),
        )
        summary = stack.extractors.run_for_fragment(fragment)
        totals["fragments"] += 1
        totals["concepts"] += summary["concepts"]
        totals["edges"] += summary["edges"]
    elapsed_ms = (time.perf_counter() - t0) * 1000.0
    return elapsed_ms, totals


def _bench_recent_projection(stack) -> float:
    from axiom.memory.projections import TaskSpec
    proj = stack.recent_activity(window_n=5)
    t0 = time.perf_counter()
    proj.project(
        TaskSpec(task_type="recent_activity", scope="bench-scope"),
        principal_id="s0",
    )
    return (time.perf_counter() - t0) * 1000.0


def _bench_concept_neighbors(stack, *, seed_name: str = "criticality") -> float:
    from axiom.memory.graph import canonical_concept_id
    seed_id = canonical_concept_id(seed_name)
    t0 = time.perf_counter()
    stack.graph.neighbors(seed_id, hops=1)
    return (time.perf_counter() - t0) * 1000.0


def _log(msg: str) -> None:
    print(f"# {msg}", file=sys.stderr, flush=True)


def main() -> int:
    results: dict = {"baseline_run_at": time.strftime("%Y-%m-%dT%H:%M:%S%z")}

    tmp = Path(tempfile.mkdtemp())
    _log(f"tmp={tmp}")
    stack = _make_stack(tmp)
    _log("stack built")

    # 1k writes through full stack
    _log("writing 1k fragments through L1 + L2 ...")
    write_1k_ms, totals_1k = _write_with_extraction(stack, n=1000)
    _log(f"  write 1k: {write_1k_ms/1000:.2f} ms/frag; "
         f"concepts={stack.graph.concept_count()} "
         f"edges={stack.graph.edge_count()}")
    proj_1k_ms = _bench_recent_projection(stack)
    neighbors_1k_ms = _bench_concept_neighbors(stack)
    _log(f"  projection {proj_1k_ms:.2f} ms; neighbors {neighbors_1k_ms:.2f} ms")

    results["integrated_1k"] = {
        "write_ms_total": round(write_1k_ms, 1),
        "write_ms_per_fragment_full_stack": round(write_1k_ms / 1000, 3),
        "concepts_extracted": totals_1k["concepts"],
        "edges_inferred": totals_1k["edges"],
        "concept_count": stack.graph.concept_count(),
        "edge_count": stack.graph.edge_count(),
        "recent_projection_ms": round(proj_1k_ms, 2),
        "neighbors_ms": round(neighbors_1k_ms, 2),
    }

    # +2k more writes — Stage 2 v0 upserts are SELECT+INSERT+COMMIT per
    # concept which compounds at scale. Batched upserts + async
    # extraction are Stage 3 of L2; until then we cap the integrated
    # benchmark at 3k cumulative fragments to keep the harness fast.
    _log("writing +2k more fragments ...")
    write_2k_ms, totals_2k = _write_with_extraction(stack, n=2000, base_index=1000)
    _log(f"  write 2k: {write_2k_ms/2000:.2f} ms/frag (cumulative 3k); "
         f"concepts={stack.graph.concept_count()} "
         f"edges={stack.graph.edge_count()}")
    proj_3k_ms = _bench_recent_projection(stack)
    neighbors_3k_ms = _bench_concept_neighbors(stack)
    _log(f"  projection @ 3k {proj_3k_ms:.2f} ms; "
         f"neighbors {neighbors_3k_ms:.2f} ms")

    results["integrated_3k"] = {
        "write_+2k_ms_total": round(write_2k_ms, 1),
        "write_+2k_ms_per_fragment_full_stack": round(write_2k_ms / 2000, 3),
        "concepts_extracted_+2k": totals_2k["concepts"],
        "edges_inferred_+2k": totals_2k["edges"],
        "concept_count_total": stack.graph.concept_count(),
        "edge_count_total": stack.graph.edge_count(),
        "recent_projection_ms": round(proj_3k_ms, 2),
        "neighbors_ms": round(neighbors_3k_ms, 2),
    }

    # Concept-graph-aware retrieval — fetch concepts a memory subject
    # has touched, then traverse to neighbors (the "what should I look
    # at next?" query archetype any extension consumes).
    from axiom.memory.graph import canonical_concept_id
    seed = canonical_concept_id("criticality")
    t0 = time.perf_counter()
    neighbors = stack.graph.neighbors(seed, hops=2)
    two_hop_ms = (time.perf_counter() - t0) * 1000.0
    results["integrated_3k"]["neighbors_2hop_ms"] = round(two_hop_ms, 2)
    results["integrated_3k"]["neighbors_2hop_count"] = len(neighbors)

    print(json.dumps(results, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
