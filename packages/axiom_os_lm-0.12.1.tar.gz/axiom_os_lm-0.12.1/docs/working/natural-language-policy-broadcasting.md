# Natural-Language Policy Broadcasting to Agent Swarms

**Document type:** Architecture Design  
**Author:** Benjamin Booth  •  **Status:** Draft  •  **Last updated:** 2026-04-13

---

## Core Feature

An authorized human speaks a directive in plain language, it's interpreted as a structured RACI policy change, and it propagates instantly to every relevant agent instance across a federation — scoped, temporary, revocable.

This is the primitive that lets humans **govern agent swarms conversationally, in real-time, at whatever granularity they need.**

## Why This Matters

Existing systems force a choice:
- **Autonomous agents** — powerful but ungovernable at scale. You can't adjust 12 agents' permissions in real-time during a class.
- **Locked-down agents** — controllable but rigid. You configure each one individually via config files, and changes take effect on restart.

Natural-language policy broadcasting is the third option: agents are autonomous by default within their RACI bounds, and authorized humans can **reshape those bounds conversationally, at any scope, in real-time**.

## The Primitive

### Addressing

| Address | Scope | Authorization |
|---------|-------|---------------|
| `@curio` | Your own instance | Any participant |
| `@student07-curio` | A specific named instance | Invitation rules apply |
| `@all-curios` | Every instance of an agent type in scope | Authorized role (instructor, PI, admin) |
| `@all-agents` | Every agent in scope | Authorized role |

### Interpretation

The human speaks natural language. WALL-E (the Loop agent, always present) interprets the directive and translates it to structured RACI policy:

```
Instructor: @all-curios you may freely share public findings with 
            each other and proactively suggest connections. Do not 
            share restricted-tier content.

WALL-E:     Interpreted as RACI policy update:
            scope: classroom/prague-ne-2026
            expires: end of current period (or explicit revocation)
            changes:
              - topic: finding_sharing(public)
                R: curio, I: student
              - topic: cross_node_suggestion
                R: curio, I: student  
              - topic: finding_sharing(restricted)
                action: blocked
            
            Apply to 12 CURI-O instances? [y/N]
```

The human confirms. WALL-E propagates. Every CURI-O in the classroom federation updates its RACI state.

### Scope & Expiry

Policy broadcasts are always scoped and temporary:

- **Scope** is inferred from context: if you're in a classroom, the scope is that classroom's federation. If you're in a multi-institutional federation session, the scope is that federation. If you're in a 1:1 chat, the scope is your own agents.
- **Expiry** defaults to end-of-period (classroom) or end-of-session (general). Can be explicitly set: "for the next hour," "until I say otherwise," "for this assignment."
- **Revocation** is immediate: `@all-curios return to default permissions` resets to the Course/project manifest defaults.
- **No permission creep.** A grant that isn't explicitly permanent dies when its scope ends.

### Propagation

Policy changes propagate via the existing federation heartbeat. For direct peers, propagation is near-instant (next heartbeat, typically seconds). For transitive peers (gossip), propagation follows the digest exchange cycle.

## Applications

### Classroom (primary proving ground)

**Open collaboration for a research week:**
```
Instructor: @all-curios this week you may proactively suggest 
            connections between student research loops.
```

**Tighten for an exam:**
```
Instructor: @all-curios pause all cross-student activity. 
            Students work independently until further notice.
```

**Seed a class discussion:**
```
Instructor: @all-curios summarize your owner's current research 
            hypothesis in one sentence. Post to the class feed.
```

**Directed collaboration:**
```
Instructor: @student03-curio and @student07-curio compare your 
            findings on coolant chemistry and surface contradictions.
```

### Multi-Institutional Research

**PI opens a coordinated research sprint:**
```
PI: @all-curios for the next two weeks, actively scan peer 
    findings for contradictions with your local corpus. Flag 
    anything with confidence > 0.7 that conflicts.
```

**PI restricts scope before a publication deadline:**
```
PI: @all-agents do not share any findings externally until 
    the paper is submitted. Internal federation only.
```

### Facility Operations

**Shift supervisor adjusts agent behavior for a maintenance window:**
```
Supervisor: @all-eves escalate any anomaly signals immediately 
            during this maintenance period. Lower your threshold.
```

## Relationship to Existing Primitives

| Primitive | Role |
|-----------|------|
| **RACI model** | The permission representation — what agents can/can't do, per topic |
| **@agent addressing** | The routing mechanism — who receives the directive |
| **Federation heartbeat** | The propagation mechanism — how policy reaches remote agents |
| **Period / scope boundaries** | The expiry mechanism — when grants automatically revaporate |
| **WALL-E** | The interpreter — translates natural language to structured RACI |

This feature composes entirely from existing primitives. The new thing is the **composition**: natural language → WALL-E interpretation → RACI update → federation propagation → automatic expiry.

## Implementation Priority

**Advanced feature.** Requires all of the following to be in place first:
- RACI model (exists)
- @agent addressing (designed, not yet implemented)
- Federation heartbeat with digest exchange (designed, not yet implemented)
- Period/scope boundaries (designed, not yet implemented)
- WALL-E natural-language → structured-policy interpretation (new capability)

Target: post-MVP. The classroom MVP (Prague summer 2026) uses static RACI defaults from the Course manifest. Natural-language policy broadcasting is the advanced version that replaces manual configuration with conversational governance.

## Open Questions

1. **Confirmation UX** — Should WALL-E always confirm before propagating? Or should low-risk changes (tightening permissions) propagate immediately while loosening requires confirmation?
2. **Conflict resolution** — What if two authorized humans broadcast conflicting policies? Last-write-wins? Or does the higher-authority role take precedence?
3. **Audit** — Every policy broadcast must be logged with: who said it, what WALL-E interpreted, what changed, when it expires. This is the audit trail for "why could the agents do X during that period?"
4. **Delegation** — Can an instructor delegate broadcast authority to a TA? Scoped delegation (TA can adjust CURI-O permissions but not EVE permissions)?

---

*This document captures the core concept. Implementation details will be specified in a tech spec when the prerequisite primitives are in place.*
_Copyright (c) 2026 B-Tree Ventures, LLC. Apache-2.0 licensed._
