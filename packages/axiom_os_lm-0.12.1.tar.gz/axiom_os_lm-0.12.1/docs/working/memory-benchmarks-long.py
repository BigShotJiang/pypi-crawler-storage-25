#!/usr/bin/env python3
# Copyright (c) 2026 The University of Texas at Austin
# SPDX-License-Identifier: Apache-2.0
"""Long memory benchmark — checkpoints at 1k, 3k, 10k, 30k cumulative fragments.

Sister of memory-benchmarks-integrated.py. Where the integrated harness caps
at 3k to keep CI fast, this one runs the long course — meant to be invoked
manually at end-of-phase to confirm the layered stack scales as the architecture
promises.

Scaling expectations after Stage-3-of-L2 evidence-table refactor (commit
2f0a339): per-fragment write cost should be flat (O(1) upserts via indexed
sibling tables). If the cumulative ms-per-fragment grows non-linearly between
checkpoints, we have a perf regression.

Output: machine-readable JSON dict on stdout. Captured in dated files under
``docs/working/`` and summarized in ``working/memory-benchmarks-trend.md``.

Run:
    python3 docs/working/memory-benchmarks-long.py > docs/working/memory-benchmarks-long-$(date +%Y-%m-%d).json
"""

from __future__ import annotations

import json
import sys
import tempfile
import time
from pathlib import Path


def _make_stack(tmp: Path):
    from axiom.memory.bootstrap import build_memory_stack
    return build_memory_stack(scope_id="bench-scope", data_root=tmp)


def _write_with_extraction(stack, *, n: int, base_index: int = 0) -> tuple[float, dict]:
    totals = {"concepts": 0, "edges": 0, "fragments": 0}
    t0 = time.perf_counter()
    for i in range(base_index, base_index + n):
        fragment = stack.composition.write(
            content={
                "event_time": f"2026-04-28T1{i % 10}:{(i // 10) % 60:02d}:00+00:00",
                "classroom_id": "bench-scope",
                "question": (
                    f"What is criticality and how do control rods "
                    f"affect reactor power #{i}"
                ),
                "had_answer": True,
                "citations_count": 1,
                "mode": "ask",
            },
            cognitive_type="episodic",
            principal_id=f"s{i % 30}",
            agents=set(),
            resources=set(),
            accountable_human_id=f"@s{i % 30}:bench",
        )
        summary = stack.extractors.run_for_fragment(fragment)
        totals["fragments"] += 1
        totals["concepts"] += summary["concepts"]
        totals["edges"] += summary["edges"]
    elapsed_ms = (time.perf_counter() - t0) * 1000.0
    return elapsed_ms, totals


def _bench_recent_projection(stack) -> float:
    from axiom.memory.projections import TaskSpec
    proj = stack.recent_activity(window_n=5)
    t0 = time.perf_counter()
    proj.project(
        TaskSpec(task_type="recent_activity", scope="bench-scope"),
        principal_id="s0",
    )
    return (time.perf_counter() - t0) * 1000.0


def _bench_concept_neighbors(stack, *, seed_name: str = "criticality") -> float:
    from axiom.memory.graph import canonical_concept_id
    seed_id = canonical_concept_id(seed_name)
    t0 = time.perf_counter()
    stack.graph.neighbors(seed_id, hops=1)
    return (time.perf_counter() - t0) * 1000.0


def _bench_concept_neighbors_2hop(stack, *, seed_name: str = "criticality") -> tuple[float, int]:
    from axiom.memory.graph import canonical_concept_id
    seed_id = canonical_concept_id(seed_name)
    t0 = time.perf_counter()
    neighbors = stack.graph.neighbors(seed_id, hops=2)
    return (time.perf_counter() - t0) * 1000.0, len(neighbors)


def _checkpoint(
    stack, *, label: str, write_ms: float, totals: dict, base_count: int
) -> dict:
    cumulative = base_count + totals["fragments"]
    proj_ms = _bench_recent_projection(stack)
    n_ms = _bench_concept_neighbors(stack)
    n2_ms, n2_count = _bench_concept_neighbors_2hop(stack)
    return {
        "label": label,
        "cumulative_fragments": cumulative,
        "batch_write_ms_total": round(write_ms, 1),
        "batch_write_ms_per_fragment": round(write_ms / max(1, totals["fragments"]), 3),
        "concepts_extracted_in_batch": totals["concepts"],
        "edges_inferred_in_batch": totals["edges"],
        "concept_count_total": stack.graph.concept_count(),
        "edge_count_total": stack.graph.edge_count(),
        "recent_projection_ms": round(proj_ms, 2),
        "neighbors_1hop_ms": round(n_ms, 2),
        "neighbors_2hop_ms": round(n2_ms, 2),
        "neighbors_2hop_count": n2_count,
    }


def _log(msg: str) -> None:
    print(f"# {msg}", file=sys.stderr, flush=True)


def main() -> int:
    results: dict = {
        "benchmark_run_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "checkpoints": [],
    }

    tmp = Path(tempfile.mkdtemp())
    _log(f"tmp={tmp}")
    stack = _make_stack(tmp)
    _log("stack built")

    # Checkpoint plan: 0 → 1k → 3k → 10k → 30k cumulative
    checkpoint_targets = [1000, 2000, 7000, 20000]
    base_count = 0
    for target in checkpoint_targets:
        _log(f"writing {target} fragments (cumulative target {base_count + target}) ...")
        ms, totals = _write_with_extraction(stack, n=target, base_index=base_count)
        cp = _checkpoint(stack, label=f"{base_count + target}_fragments",
                         write_ms=ms, totals=totals, base_count=base_count)
        results["checkpoints"].append(cp)
        _log(
            f"  cumulative {cp['cumulative_fragments']}: "
            f"{cp['batch_write_ms_per_fragment']:.3f} ms/frag; "
            f"concepts={cp['concept_count_total']} edges={cp['edge_count_total']}; "
            f"proj={cp['recent_projection_ms']} ms; "
            f"n1hop={cp['neighbors_1hop_ms']} ms; "
            f"n2hop={cp['neighbors_2hop_ms']} ms ({cp['neighbors_2hop_count']} found)"
        )
        base_count += target

    print(json.dumps(results, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
