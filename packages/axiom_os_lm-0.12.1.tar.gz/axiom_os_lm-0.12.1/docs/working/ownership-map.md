# IP Ownership Map

**Status:** Authoritative (pending UT OTC formalization)
**Owner:** Benjamin Booth
**Last updated:** 2026-04-20
**Parent:** [brand-product-strategy.md](brand-product-strategy.md)

This document is the authoritative source of truth for per-path
copyright attribution in the axiom repository. It resolves
ambiguity when a file's logical product can't be inferred from its
path alone. The SPDX header in each source file must match this map;
when they disagree, this map wins.

---

## Why this exists

The axiom repository hosts code owned by multiple entities pending
extraction into separate repositories per the
[brand & product strategy](brand-product-strategy.md):

- **B-Tree Ventures, LLC** — commercial operator of Axiom (and Dendra
  in its own repo)
- **The University of Texas at Austin** — institutional owner of
  Vega, KEP-LO (Keplo), and NeutronOS

The repo-root `LICENSE` (Apache 2.0) and `NOTICE` (dual attribution)
govern distribution; this map governs per-file attribution.

---

## Path → owner table

Paths below the listed prefix inherit the owner unless overridden
by a more specific line. When a file contains material contribution
from both owners, the **joint** column applies.

### B-Tree Ventures, LLC (Axiom)

| Path | Product | Notes |
|---|---|---|
| `src/axiom/` (root + modules below, except where overridden) | Axiom | Core agent platform |
| `src/axiom/infra/` | Axiom | Gateway, prompts, tracing env, orchestrator, services |
| `src/axiom/memory/` | Axiom | CompositionService, fragments, ownership, policy, trust |
| `src/axiom/identity/` | Axiom | Ed25519 keypair, principals |
| `src/axiom/rag/` | Axiom | Retriever, RRF, citation, RPE, context blocks |
| `src/axiom/artifacts/` | Axiom | ArtifactRegistry + SQLite/in-memory backends |
| `src/axiom/agents/` | Axiom | Turn classifier, agent base class |
| `src/axiom/evals/` | Axiom | Eval harness |
| `src/axiom/research/` | Axiom | Research loop (CURI-O) |
| `src/axiom/medallion/` | Axiom | Export + pseudonymization primitives |
| `src/axiom/setup/` | Axiom | Install, llamafile bootstrap |
| `src/axiom/integrations/` | Axiom | Generic integration frameworks (LMS factory, etc.) |
| `src/axiom/policy/` | Axiom | Write-policy transforms |
| `src/axiom/axiom_cli.py` | Axiom | Top-level CLI entrypoint |
| `src/axiom/extensions/` (framework only — contracts, discovery, scaffold, CLI, mcp_generation) | Axiom | Extension SDK |
| `src/axiom/extensions/builtins/` — all non-classroom, non-federation builtins (diagnostics, signals, chat, publishing, hygiene, release, research, memory, http, agents, update, status, settings, db, connect, directive, ide, install, log, note, rag, repo, test) | Axiom | Base agents + platform utilities |

### The University of Texas at Austin (Vega — federation + governance)

| Path | Product | Notes |
|---|---|---|
| `src/axiom/federation/` | Vega | Identity binding, cohort registry, trust graph, inference catalog |
| `src/axiom/security/` | Vega | (If present) Classification, RACI, content gating |
| `src/axiom/memory/cohort_registry.py` | Vega | Federation addressing — carve-out from memory/ |
| `src/axiom/extensions/builtins/federation/` | Vega | `axi federation` / `axi nodes` / `axi knowledge` / `axi research` / `axi security` CLIs |
| `docs/adrs/adr-022*.md` | Vega | Identity roots + membership |
| `docs/adrs/adr-023*.md` | Vega | Topology, lifecycle, propagation |
| `docs/adrs/adr-024*.md` | Vega | Root availability, delegation, FROST |
| `docs/adrs/adr-025*.md` | Vega | Threat model |
| `docs/adrs/adr-027*.md` | Vega | Federated memory |
| `docs/adrs/adr-028*.md` | Vega | Trust graph |
| `docs/adrs/adr-029*.md` | Vega | Federation composition (meta-ADR) |
| `docs/adrs/adr-030*.md` | Vega | Federated inference |
| `docs/specs/spec-classification-boundary.md` | Vega | Classification spec |
| `docs/specs/spec-security.md` | Vega | Security spec |
| `docs/prds/prd-federation.md` | Vega | Federation PRD |
| `docs/working/design-resolution-protocol.md` | Vega | Resolution protocol design |
| `tests/federation/` | Vega | Federation unit tests |
| `tests/federation_lifecycle/` | Vega | Federation scenario tests |
| `tests/findings/` | Vega | Finding propagation tests |

### The University of Texas at Austin (KEP-LO — classroom + learning analytics)

| Path | Product | Notes |
|---|---|---|
| `src/axiom/extensions/builtins/classroom/` | KEP-LO | Course manifest, enrollment, Q&A, grade ledger, tracing, tools, rails, checkpoints, archive, publish, harvest |
| `docs/prds/prd-classroom.md` | KEP-LO | Classroom PRD |
| `docs/specs/spec-classroom.md` | KEP-LO | Classroom spec |
| `docs/specs/spec-classroom-generate-shortcuts.md` | KEP-LO | Open WebUI adapter |
| `docs/specs/spec-extension-ui-protocol.md` | KEP-LO | UI protocol (education-driven) |
| `docs/working/design-instructor-prep-workflow.md` | KEP-LO | FW-1 design |
| `docs/working/design-course-conclusion-workflow.md` | KEP-LO | FW-4 design |
| `docs/working/langfuse-setup.md` | KEP-LO | Classroom observability runbook |
| `docs/working/canvas-setup.md` | KEP-LO | LMS integration runbook |
| `docs/working/prague-deployment-runbook.md` | KEP-LO | Prague deployment |
| `tests/classroom_unit/` | KEP-LO | Classroom unit tests |
| `tests/classroom_e2e/` | KEP-LO | Classroom end-to-end journeys |

---

## Mixed paths — judgment calls

These paths host files owned by different products side-by-side. The
SPDX header per file is the source of truth.

### `docs/adrs/`

Each ADR attributes by subject:

- **Axiom** (B-Tree): ADR-001..021, 026 (memory ownership), anything
  that's base-platform scope
- **Vega** (UT): ADR-022, 023, 024, 025, 027, 028, 029, 030 (see
  federation / classification scope above)
- **KEP-LO** (UT): ADRs about classroom lifecycle (none yet explicit;
  tracked as mixed)

### `docs/papers/`

Research papers attribute by lead product:

- `axiom-composition-emergence.md` → Axiom (B-Tree)
- Any future Prague-classroom paper → KEP-LO (UT)
- Any future federated-training paper → Dendra (B-Tree) / Vega (UT)
  co-authored; requires explicit joint attribution

### `scripts/` and `tests/cli/`

By what they exercise:

- Scripts / tests for `axi` base commands → Axiom
- Scripts / tests for `axi federation` / `axi nodes` / `axi
  knowledge` → Vega
- Scripts / tests for `axi classroom` → KEP-LO

### `runtime/` and `.venv/`

Gitignored. Not attributed.

### Repository root files

| File | Owner |
|---|---|
| `LICENSE` | Jointly applicable (repo-level) |
| `NOTICE` | Jointly applicable (repo-level) |
| `AGENTS.md`, `CLAUDE.md` (symlink) | Axiom (onboarding doc) |
| `pyproject.toml` | Axiom (package definition) |
| `.github/` | Owner of the workflow it serves |

---

## Joint-ownership handling

When a single file has material contribution from both B-Tree and UT:

1. **Default response:** split the file. If `classroom/foo.py` needs
   help from a B-Tree primitive, that primitive belongs in
   `src/axiom/<module>/` and `classroom/foo.py` imports it. Applied
   consistently, joint files are rare.
2. **When splitting isn't practical:** the file carries joint SPDX
   attribution:
   ```python
   # Copyright (c) 2026 B-Tree Ventures, LLC
   # Copyright (c) 2026 The University of Texas at Austin
   # SPDX-License-Identifier: Apache-2.0
   ```
   The `joint-files.md` (future) registry enumerates these so they
   stay tracked for extraction.

---

## Extraction-readiness checklist

A path is extraction-ready when:

- [ ] Every `.py` file has an SPDX header matching this map
- [ ] No import from the other entity's product (e.g., `classroom/*`
      doesn't import `federation/*`; `federation/*` doesn't import
      `classroom/*`)
- [ ] Tests colocated with the code, or mirrored under `tests/` with
      same attribution
- [ ] Documentation (PRDs, specs, ADRs) living at repo-root `docs/`
      is ready to move with its code

This checklist is run before extraction; it's not a blocker for
current development.

---

## Change log

- **2026-04-20** — Initial map. Apache 2.0 + open-core business model
  confirmed. UT OTC engagement outstanding.
_Copyright (c) 2026 B-Tree Ventures, LLC. Apache-2.0 licensed._
