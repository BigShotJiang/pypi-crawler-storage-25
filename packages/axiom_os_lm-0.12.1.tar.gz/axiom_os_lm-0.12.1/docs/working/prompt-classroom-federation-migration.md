# Sister-session prompt — finish Tier 1c on classroom + federation

Ben is running a parallel Claude session ("Keplo session") that owns the
`classroom/` and `federation/` subtrees. The Tier 1c migration sweep
landed 9 renames / deletes / merges + 14-extension AEOS-compliance
sweep on `origin/main` this week, but intentionally skipped those two
subtrees because the Keplo session is actively evolving them. This
prompt delegates the completion of those two rows to that session.

Paste everything below the `────` into the Keplo session (after the
CWD is set to `/Users/ben/Projects/UT_Computational_NE/axiom/`).

────

# System prompt — finish Tier 1c on `classroom/` and `federation/`

You are completing the Tier 1c extension migration sweep on the
`classroom/` and `federation/` built-in extensions. Every other row in
the Tier 1c tracker landed on `origin/main` between 2026-04-22 and
2026-04-24; these two rows were deferred to you because you own these
subtrees. Your job is to apply the established template, push, and
report back.

## Working directory + environment

`/Users/ben/Projects/UT_Computational_NE/axiom/`. Activate the venv:
```
source /Users/ben/Projects/UT_Computational_NE/.venv/bin/activate
```

Origin is `https://github.com/b-tree-labs/axiom-os.git`. `main` is
authoritative; push with `git push origin main` (no tags — the
publish workflow fires only on `v*` tags).

## Safety

- Never skip hooks. The pre-push hook runs ruff + the full test suite;
  both must pass before origin accepts the push.
- If ruff finds pre-existing lint in files unrelated to your
  migration, run `ruff check src/ --select E,F,W --ignore E501 --fix
  --unsafe-fixes` and include the cleanup in your commit.
- If pre-push tests fail because the parallel Axiom session landed
  something breaking, rebase on `origin/main` and re-run before
  pushing again.
- Do not touch anything outside `src/axiom/extensions/builtins/classroom/`
  and the Vega consolidation surface described below. The parallel
  session owns everything else.
- Commit locally, merge fast-forward to main, push to origin. No
  tags. No force-push.

## Read first

1. `docs/conventions/the-axiomatic-way.md` — the doctrine you're
   applying (especially principles #3 naming, #7 agent identity
   canonical, #8 skills learned, #10 extensions portable).
2. `docs/specs/spec-aeos-0.1.md` — the AEOS 0.1 spec. Especially:
   - §4.1 agent (persona.md contract)
   - §5.1.1 flat-vs-compound layout (built-ins are flat)
   - §5.2 required files (built-in relaxed set)
   - §6 manifest schema
3. `docs/working/tier-1c-migration-tracker.md` — the checkbox list
   you're completing (classroom + federation rows).
4. `docs/working/competitive-parity-gaps.md` — the living catalog.
   Add entries when your migration surfaces capability gaps vs. peer
   harnesses.
5. `docs/adrs/adr-031-extension-self-containment.md` — the
   extension-self-containment decision that governs classroom's
   eventual extraction to Keplo's own repo AND the Vega
   pre-extraction consolidation.
6. `docs/working/plan-vega-extraction.md` — if it exists; the
   extraction plan for federation → vega.

## Reference commits — study before you code

Two commits landed the template you're matching. Read their diffs and
commit messages:

```
git show 761ef2b   # dfib_agent → diagnostics (with persona split)
git show 4bcc1a9   # memory_cmd → memory (simple rename, cmd-only)
git show 67869de   # neut_agent → chat (agent dissolution + recreation)
git show 7bf1023   # AEOS flat-builtin schema + tool alignment
```

The pattern in 3 sentences: rename directory, rewrite the manifest
against the AEOS 0.1 schema with `builtin = true` and
`[[extension.provides]]` blocks, split the agent's SKILLS.md into
`agents/<name>/persona.md` (agent-internal) + the standalone skills
that remain (as `skills/<name>/SKILL.md` if any), add
`tests/unit_tests/test_standard.py` inheriting
`ExtensionStandardTests`, update imports + tracker, commit.

## Template per extension

1. Create branch `feat/migrate-<name>` off current `main` (after `git
   pull --rebase origin main`).
2. Rewrite `axiom-extension.toml` against AEOS 0.1:
   - Drop pre-AEOS fields: `author`, `kind`, `module`,
     `[[cli.commands]]` (replace with `[[extension.provides]]` with
     `kind = "cmd"`).
   - Add/keep: `name` (purpose-name, already clean for these two),
     `version`, `description`, `license`, `owner`,
     `aeos_version = "0.1.0"`, `builtin = true`.
   - Add `[extension.compatibility]` with `python = ">= 3.11"` and
     `axiom = ">= 0.10"`.
   - Convert every legacy capability declaration into a
     `[[extension.provides]]` block.
   - **NOTE on transitional schema relaxation**: the AEOS schema's
     root `additionalProperties` was relaxed to `true` in commit
     `e760bab` so legacy `[agent]` / `[[connections]]` /
     `[[agent.watchers]]` blocks parse during the transition. Prefer
     moving your declarations to `[[extension.provides]]` form;
     retain the legacy form only if the runtime still reads it and
     translation would break behavior. Note any retained legacy
     blocks in the commit message so we can re-tighten the schema
     later.
3. For agent-hosting extensions (classroom's CHALK-E, federation's
   V-EGA), split the persona per AEOS §4.1:
   - `agents/<agent-snake>/persona.md` — role, identity,
     authorization model. Extract from the existing `SKILLS.md`. See
     `src/axiom/extensions/builtins/diagnostics/agents/d_fib/persona.md`
     for the canonical shape.
   - `agents/<agent-snake>/__init__.py` — short package docstring.
   - Declare the agent in the manifest with `[[extension.provides]]
     kind = "agent"`, `name = "<agent-snake>"`,
     `entry = "axiom.extensions.builtins.<ext>.<module>:<Class>"`,
     `persona = "agents/<agent-snake>/persona.md"`.
4. Update `__init__.py` docstring to describe the extension's
   purpose, not the agent.
5. Create `tests/unit_tests/test_standard.py` matching the pattern in
   `src/axiom/extensions/builtins/diagnostics/tests/unit_tests/test_standard.py`
   — pytest class subclassing `ExtensionStandardTests` with one
   fixture pointing at `axiom-extension.toml`.
6. Create `tests/conftest.py`, `tests/unit_tests/__init__.py`,
   `tests/integration_tests/__init__.py` (these can be minimal
   copyright-headered files matching diagnostics').
7. Run the conformance gate:
   ```
   axi ext lint src/axiom/extensions/builtins/<name>
   axi ext scan src/axiom/extensions/builtins/<name>
   python -m pytest src/axiom/extensions/builtins/<name>/tests/unit_tests/test_standard.py -q
   python -m pytest tests/ packages/axiom-tests/tests/ -q --ignore=tests/classroom_e2e
   ```
   `lint` may show WARN-level `AEOS040` "compound-layout
   subdirectory missing" findings — those are acceptable. `scan` must
   return all PASS. `test_standard` must pass. Full suite must pass.
8. Update `docs/working/tier-1c-migration-tracker.md`: mark the row
   `[x] landed YYYY-MM-DD`.
9. Commit with message format:
   ```
   migrate(<ext>): <action> — Tier 1c conformance pass

   <body explaining what landed, what was retained in transitional
   form, what this unlocks>

   Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
   ```
10. Fast-merge: `git checkout main && git pull --rebase origin main
    && git merge --ff-only feat/migrate-<name> && git push origin main`.

## Specific scope

### Row 1: `classroom/`

- Purpose name already correct (`classroom/`). This is a **layout +
  manifest + persona split** migration, not a rename.
- Agent inside: **CHALK-E**. Persona at
  `classroom/agents/chalke/persona.md` (the path is already
  partially populated — `classroom/agents/chalke/SKILLS.md` exists;
  extract persona content, leave SKILLS.md in place for now as
  reference).
- This extension is the largest in the repo. Inspect every top-level
  file and decide: retain, move to a capability-kind subdirectory,
  or leave in place.
- Eventual extraction to Keplo's own repo per ADR-031 — apply
  extension-self-containment discipline now (docs/ and tests/ are
  already co-located; manifest gets the AEOS-shape treatment; don't
  add new cross-tree imports).
- Classroom has many live tests. Run the full test suite after your
  manifest rewrite; if anything breaks due to import path changes,
  fix it in the same commit.

### Row 2: `federation/` — DO NOT TOUCH

**Updated 2026-04-24**: Ben directed the Axiom session to do the full
ADR-031 Phase 3 Vega consolidation (Interpretation B in the earlier
draft of this prompt). That work moves `src/axiom/{federation,identity,
security}/` into `src/axiom/vega/{federation,identity,trust}/` with
compatibility shims at the old import paths.

Skip this row. It's owned by the Axiom session and lands separately.

If your classroom work depends on `axiom.federation`, `axiom.identity`,
or `axiom.security` imports, those continue to work via
`DeprecationWarning`-emitting shims through Axiom 0.15.x. Do not
update your imports to `axiom.vega.*` in your migration commit — that
would couple your classroom work to consolidation timing. Update
imports as a separate followup after the consolidation lands.

## Ongoing hygiene

- **Parity-gap tracking**: if persona extraction or manifest rewrites
  surface capabilities that peer harnesses don't have (or vice
  versa), add an entry to `docs/working/competitive-parity-gaps.md`.
- **Schema drift**: if the AEOS manifest schema blocks a legitimate
  declaration you need, don't just relax `additionalProperties`
  further. Either (a) move the declaration to a proper
  `[[extension.provides]]` block, or (b) add a scoped optional
  section to the schema with rationale in the commit message.
- **Commit pacing**: one commit per row (classroom commit, then
  federation commit). Fast-merge + push after each passes. This
  matches the atomicity of the earlier migrations and keeps the
  parallel Axiom session's view current.

## Report back

When both rows are checked in the tracker and pushed to origin:

1. Two commit hashes + subjects.
2. Final test count (pre-push gate).
3. End-to-end smoke of each migrated extension:
   - `axi ext lint src/axiom/extensions/builtins/<ext>`
   - `axi ext scan src/axiom/extensions/builtins/<ext>`
   - `python -m pytest src/axiom/extensions/builtins/<ext>/tests/unit_tests/test_standard.py -q`
4. Whether you chose Interpretation A or B for federation, and why.
5. Any transitional schema retentions (`[agent]`,
   `[[connections]]`, etc.) so the Axiom session can re-tighten later.
6. Parity-gap entries you added.
7. Anything that diverged from the template, with a one-line why.

Proceed without mid-sweep confirmation unless something reveals a
structural issue requiring doctrine change.

────

End of sister-session prompt.
