# Axiom Memory — Competitive Analysis

**Status:** Living doc (2026-04-28)
**Owner:** Ben Booth
**Forcing context:** "How does our memory system stack up against other competitors?"
**Related:** `working/memory-benchmarks.md`, `working/memory-benchmarks-trend.md`, `working/memory-maturity-benchmarks.md`, `spec-memory.md`, `spec-memory-maturity.md`, `adr-033-layered-memory-architecture.md`, `adr-034-plan-and-agent-pipeline.md`, `adr-035-human-principal-binding.md`.

---

## 1. The bottom line up front

Axiom is **structurally more ambitious** than the SaaS-flavored competitors and **directly leads on six dimensions** none of them treat as primitives:

1. **Federation as architectural primitive** — cohort-to-cohort with classification-aware projection.
2. **Classification stamps** (CUI/EAR/ITAR/Part 810/proprietary) at the fragment level.
3. **Accountable-human binding** propagated across federation (ADR-035) — every action attributable to a named human, by construction.
4. **Replay determinism** with declared envelope + strict mode (DPM-aligned).
5. **Cohort persistence** with schema_version + decoder registry + pinned-fixture release gate.
6. **Plans-as-memory** — plans + agent runs are first-class queryable, federable, replayable fragments (ADR-034).

Axiom is **behind** the SaaS competitors on five operational dimensions:

1. Production maturity / live deployments.
2. Hosted SaaS offering (we are self-host only by design — but there is no managed Axiom-as-a-service today).
3. Public benchmark scores (LoCoMo / LongMemEval / MemBench — we have the harness specced; haven't run them yet).
4. Framework-integration breadth (Mem0 ships 21 official integrations; Axiom's external integrations are narrower).
5. Temporal-fact validity windows as a primitive (Zep's signature; we have timestamped fragments but not validity-bound facts yet).

The opening insight: most "agent memory" products solve **"give my agent persistent memory"** (a single-tenant developer-ergonomics problem). Axiom solves **"give institutions, cohorts, and federations memory that's accountable, classified, replayable, and lasts decades"** (a different problem with overlapping primitives). The right comparison frame is Kubernetes vs. Docker Compose: same vocabulary, different ambition.

---

## 2. The competitor field — who does what

| Product | Primary market | Core architecture | OSS | Hosted SaaS | Status (Apr 2026) |
|---|---|---|---|---|---|
| **Mem0** | Drop-in agent memory | Vector + graph + reranker; managed | Apache 2.0 + cloud | Yes (OpenMemory Cloud) | Production; AWS partnership; Cassandra + Valkey backends. 21-framework integrations. Industry-leading developer ergonomics. |
| **Letta (was MemGPT)** | Stateful agent platform | 3-tier hierarchy (Core / Recall / Archival); runtime-managed promotion | Apache 2.0 | Yes | Production; Letta Code coding agent (Apr 2026); Conversations API for shared memory; remote environments. |
| **Zep / Graphiti** | Temporal knowledge graph for agents | Episode + semantic-entity + community subgraphs; facts with validity windows | Apache 2.0 (Graphiti); commercial Zep | Yes | Production; LongMemEval +18.5% accuracy / 90% lower latency vs. baseline; strong RAG positioning. |
| **Cognee** | KG-first AI memory | ECL pipeline (Extract → Cognify → Load); vector + graph hybrid | Apache 2.0 | Self-host primary | Production; 1M+ pipelines/month; 70+ companies; $7.5M seed; 38+ source connectors. |
| **MemMachine** | Research / open framework | Ground-truth-preserving memory + retrieval-stage opts | Open | — | Currently leads LoCoMo (0.9169) and LongMemEval (93%) public benchmarks. |
| **Supermemory / SuperLocalMemory** | Personal memory OS | Local-first; user-data-sovereign | Open | — | Niche; benchmark presence; smaller community. |
| **LangMem (LangChain)** | Memory primitive for LangGraph | Pluggable memory store within LangGraph | Open | LangSmith | Embedded in LangGraph workflows; primitive layer, not a product. |
| **OpenAI Assistants threads / Anthropic memory** | LLM-vendor memory | Thread-scoped + (Anthropic) cross-thread profile memory | Closed | Yes | Single-vendor lock-in; opaque internals. |

**Headline observation:** the field is converging on **hybrid vector + graph retrieval + temporal facts + dynamic forgetting**. That convergence is *good for us* — every primitive on that list is in our stack. Where we diverge is the *architectural commitments* layered on top.

---

## 3. Capability matrix — Axiom vs. the field

Each row scores: ✅ shipped / 🟡 partial or speced / ❌ not in roadmap.

### 3.1 Memory primitives

| Capability | Axiom | Mem0 | Letta | Zep | Cognee |
|---|---|---|---|---|---|
| Vector retrieval | ✅ (via classroom RAG, generic via AskPipeline) | ✅ | ✅ (Recall) | ✅ | ✅ |
| Graph (concept) layer | ✅ (ADR-033 L2 + canonical_concept_id) | ✅ | 🟡 | ✅ (Graphiti) | ✅ |
| Hybrid vector+graph | ✅ (Stage 2 integrated) | ✅ | 🟡 | ✅ | ✅ |
| Temporal facts with validity windows | 🟡 (timestamps; not validity-bound facts) | 🟡 | 🟡 | ✅ (signature feature) | 🟡 |
| Tiered memory (hot/warm/cold/archive) | 🟡 (specced in spec-memory-maturity §3; M-O sweep Phase 2) | 🟡 (decay) | ✅ (Core/Recall/Archival) | 🟡 | 🟡 |
| Knowledge maturity layers (L0–L5) | ✅ (specced + RAG implementation; unified maturity in spec) | ❌ | ❌ | 🟡 (community subgraph) | ✅ (cognify pipeline) |
| Dynamic forgetting / decay | 🟡 (ForgetRequest + spec; full implementation Phase 2) | ✅ (mature) | ✅ (compression) | 🟡 | 🟡 |
| Pluggable embedding | ✅ | ✅ | ✅ | ✅ | ✅ |
| Concept extraction | ✅ (DeterministicTextExtractor + ExtractorRegistry) | ✅ | 🟡 | ✅ | ✅ |

### 3.2 Architectural primitives Axiom leads on

| Capability | Axiom | Mem0 | Letta | Zep | Cognee |
|---|---|---|---|---|---|
| **Federation: cohort-to-cohort** with classification-aware projection | ✅ (Stage 5a gateway shipped) | ❌ (single-tenant) | ❌ | ❌ | ❌ |
| **Classification stamps** (CUI/EAR/ITAR/Part 810/proprietary) | ✅ (`ClassificationStamp` + visibility horizon) | ❌ (metadata tags) | ❌ | ❌ | ❌ |
| **Accountable-human binding** propagated across federation | ✅ (ADR-035 mandatory; gateway preserves) | ❌ (account-level) | ❌ | ❌ | ❌ |
| **Replay determinism** with envelope + strict mode | ✅ (ReplayEnvelope + fingerprint + envelopes_equivalent) | ❌ | 🟡 (snapshot) | ❌ | ❌ |
| **Schema versioning + cohort persistence** with release-gate fixture replay | ✅ (memory-persistence-plan + decoder registry + pinned cohort-Prague-v1 fixture) | ❌ | ❌ | ❌ | ❌ |
| **Plans-as-memory** (queryable / federable / replayable plan + run fragments) | ✅ (ADR-034 + persistence) | ❌ | 🟡 (run history) | ❌ | ❌ |
| **Provenance immutability** `(T, U, A, R)` quad on every fragment | ✅ | 🟡 | 🟡 | 🟡 | 🟡 |
| **DPM** (append-only event log + task-conditioned projection) | ✅ (Vasundra Srinivasan paper alignment) | ❌ | ❌ | ❌ | ❌ |
| **Proof-bound plan steps** (test/typecheck/structural/retrieval/attestation/replay/null) | ✅ (ADR-034 §D2 + `proof.py`) | ❌ | ❌ | ❌ | ❌ |
| **ModelStrategy** runtime LLM-assembly resolution gated by classification + budget + reachability | ✅ (spec-model-routing §13 + 4 builtin strategies) | ❌ | ❌ | ❌ | ❌ |
| **Visibility horizons** (SCOPE_INTERNAL → REQUEST_GATED → PEERS_DECLARED → FEDERATION_BOUND → PUBLIC) | ✅ | ❌ | ❌ | ❌ | ❌ |
| **AEOS extension manifest** with classification-gated tools | ✅ (spec-aeos-0.1) | ❌ | 🟡 (skills) | ❌ | ❌ |

### 3.3 Operational dimensions where competitors lead

| Dimension | Axiom | Mem0 | Letta | Zep | Cognee |
|---|---|---|---|---|---|
| Hosted SaaS | ❌ (self-host only by design) | ✅ (OpenMemory Cloud) | ✅ | ✅ | 🟡 (self-host primary) |
| Public benchmark scores published | ❌ (specced; not run) | ✅ (LoCoMo + DMR) | ✅ (DMR) | ✅ (94.8% DMR / +18.5% LongMemEval) | 🟡 |
| Production-scale references | 🟡 (Prague is first cohort) | ✅ (AWS, enterprises) | ✅ (Letta Code, enterprise) | ✅ | ✅ (1M pipelines/mo, 70+ companies) |
| Framework integration breadth | 🟡 (chat/classroom/research; AskPipeline pattern) | ✅ (21 official integrations) | ✅ | ✅ | ✅ (Claude SDK, OpenAI Agents, LangGraph, n8n, Neptune, Neo4j) |
| Distributed storage backends | 🟡 (SQLite primary; Postgres + SeaweedFS in node profiles) | ✅ (Cassandra, Valkey, Neptune, etc.) | ✅ | ✅ | ✅ (Neptune, Neo4j, etc.) |
| Funding / commercial backing | UT + B-Tree Ventures (no dedicated raise) | Series A + AWS partnership | Series A | Series A | $7.5M seed |
| Time-to-deploy for a developer | ~10 min (axi install) | ~3 min (managed) | ~5 min | ~5 min | 6-line install |

### 3.4 Compliance + governance

| Capability | Axiom | Mem0 | Letta | Zep | Cognee |
|---|---|---|---|---|---|
| Multi-tenant isolation by default | ✅ (scope-isolated; default-deny) | 🟡 (metadata + per-request tenant) | ✅ | ✅ | ✅ |
| Regulated-data primitives (CUI/HIPAA/GDPR) | ✅ (ClassificationStamp) | 🟡 (compliance posture) | 🟡 | 🟡 | 🟡 |
| Audit trail with immutable provenance | ✅ (every write + every L1+ derivation) | 🟡 | 🟡 | ✅ (validity windows) | 🟡 |
| Right-to-be-forgotten / retraction | ✅ (ForgetRequest + audit-preserved) | 🟡 | 🟡 | 🟡 | 🟡 |
| Air-gap / SCIF deployable | ✅ (no cloud dependency) | ❌ (managed) | 🟡 | 🟡 | ✅ |
| Regulatory boundary aware (10 CFR 810, ITAR, EAR) | ✅ (spec-classification-boundary) | ❌ | ❌ | ❌ | ❌ |

---

## 4. Per-competitor honest takes

### 4.1 Mem0 — the developer-ergonomics champion

**What they do best:** lowest-friction integration. Drop the SDK in, get persistent memory, ship. 21-framework support means whatever you're building, there's a recipe. Dynamic forgetting + priority scoring is mature. AWS Neptune partnership signals enterprise traction.

**Where they're structurally limited (vs. Axiom):**
- Single-tenant by design with metadata-tag partitioning. No cohort-to-cohort federation with classification-aware projection.
- No regulatory primitives — compliance is a posture claim, not an architectural commitment.
- No replay determinism guarantee.
- Memory-as-state, not memory-as-evidence; provenance is shallow.

**What we should learn from them:** UX. `axi memory` should be as cheap to integrate as Mem0. The 21-framework integration list is a forcing function — any agent harness in the market should be able to consume Axiom memory in <10 lines.

### 4.2 Letta (formerly MemGPT) — the stateful-agent platform

**What they do best:** the runtime *manages* memory promotion (Core ↔ Recall ↔ Archival) so application code doesn't have to. Letta Code (Apr 2026) is a meaningful coding-agent product. Conversations API (Jan 2026) for shared memory across parallel sessions is genuinely innovative. Skills + subagents shipped.

**Where they're structurally limited:**
- Memory hierarchy is per-agent, not per-cohort. No federation.
- No classification primitives.
- Stateful-agent abstraction couples memory tightly to one agent identity — no clean accountable-human-acting-through-multiple-agents story.

**What we should learn from them:** the runtime-promotes-memory pattern is right. Our spec-memory-maturity §4 M-O sweep + EVE crystallization captures this; we just have to ship it (Phase 2).

### 4.3 Zep / Graphiti — the temporal-graph leader

**What they do best:** facts with validity windows. "Kendra loves Adidas shoes (as of March 2026)" as a first-class graph entity is the right primitive for any agent that handles changing user state. Best public benchmark scores: 94.8% DMR, +18.5% LongMemEval, 90% latency reduction.

**Where they're structurally limited:**
- Single-tenant temporal graphs; no federation.
- Validity windows on facts are local; no cross-cohort fact reconciliation.
- Compliance is bolt-on metadata, not architecture.

**What we should learn from them:** **add validity-window facts as a first-class type in the L2 concept graph**. Today our concept edges are persistent; an edge with a validity window is a different shape. This is a real Axiom gap. Tracked as a follow-on.

### 4.4 Cognee — the knowledge-graph-first OSS

**What they do best:** the ECL pipeline is the right shape for ingest-heavy workflows. 38+ source connectors. Plugs into Claude Agent SDK + OpenAI Agents SDK + LangGraph + Neptune + Neo4j. Production scale — 1M pipelines/month. We already analyzed Cognee in `working/cognee-vs-build-study.md` and decided to *build patterns, not adopt code* — that decision still holds.

**Where they're structurally limited (vs. our needs):**
- No federation, no classification, no accountable-human binding.
- Knowledge graph is a derivation of ingested data, not a sovereign substrate.
- Strong on "extract knowledge from documents"; weaker on "track every action a federated agent took under whose accountability".

**What we should learn from them:** the ECL pipeline shape (Extract → Cognify → Load) maps cleanly to our Layer 2 extractors. Their 38-connector breadth is the kind of integration sprawl that makes a memory layer *useful* in practice. Our extension manifest plus AEOS reach declarations should produce a similar connector universe; we just need to publish the recipes.

### 4.5 MemMachine — the benchmark leader

**What they do best:** retrieval-stage optimizations that drive 0.9169 on LoCoMo (gpt-4.1-mini) and 93% on LongMemEval. Public-benchmark posture is exemplary — they publish numbers, expose methodology, take corrections.

**Where they're limited:**
- Research-grade rather than production-grade; less commercial polish than Mem0/Zep.
- No claim on federation/classification/persistence-across-decades — they don't try.

**What we should learn from them:** the **benchmark publication discipline**. The day Axiom publishes LoCoMo + LongMemEval scores is the day we earn comparison-table inclusion. Until then, we're an asterisk. (Our `working/memory-benchmarks.md` already commits to this; just need to run it.)

### 4.6 LLM-vendor memory (OpenAI / Anthropic)

**What they do:** thread-scoped memory + (Anthropic) cross-thread profile memory. Tightly integrated with the LLM API.

**Why they don't compete with us:** vendor lock-in. Closed source. No federation. No classification. The cohorts we serve cannot run on these.

---

## 5. Where we genuinely lead — the six leap-aheads

### 5.1 Federation as architectural primitive

No competitor has cohort-to-cohort federation with classification-aware projection. Multi-tenancy in their world means "metadata-tagged isolation in a single store"; in ours it means "Prague's coordinator runs its own Axiom, federates plan + memory projections to Austin's Axiom subject to declared visibility horizons + classification stamps + accountable-human propagation."

**Why this matters:** any cohort that spans institutions (research collaborations, multi-site programs, classroom networks, regulated supply chains) needs this. *Nobody else even tries.*

### 5.2 Classification as a primitive, not a posture

Mem0 et al. claim "compliance posture" as a marketing line. Axiom encodes CUI / EAR / ITAR / Part 810 / proprietary as a `ClassificationStamp` field on every fragment. The federation gateway enforces it at projection time. The audit trail records every cross.

**Why this matters:** for any DOE / DoD / DOE-NEUP / NRC-adjacent use case, this is the difference between "architecture review passes" and "architecture review fails."

### 5.3 Accountable-human binding by construction (ADR-035)

Every fragment carries `accountable_human_id` mandatory + `delegation_chain`. Federation gateway preserves the chain across cohort handoff — never strippable.

**Why this matters:** the next regulatory wave for AI is going to be accountability-grade attestation. Codex's accountability ends at an OpenAI account; ours ends at a named human, propagated across institutional boundaries. *This is a marketing claim that's a marketing claim because it's an architectural claim*.

### 5.4 Replay determinism + cohort persistence

ReplayEnvelope captures what's deterministic; declares what isn't. Strict mode raises if anything escapes. schema_version + decoder registry guarantees a cohort's fragment fixtures decode under every Axiom release through cohort end-of-life.

**Why this matters:** the Prague Summer 2026 cohort's memory will still be queryable + replayable in 2031 when the next cohort comes through. Mem0's plans don't outlive a model deprecation.

### 5.5 Plans-as-memory

ADR-034 makes plans + agent runs first-class memory fragments — queryable, federable, replayable. "Show me every plan in this scope that touched the safety-analysis tool" is an Axiom query. Codex / Claude Code / Cursor cannot answer that.

### 5.6 Knowledge maturity model with proof-bound promotion

L0–L5 (Data → Patterns → Facts → Frameworks → Application → Wisdom) with explicit promotion gates. Plan-step proofs (test/typecheck/structural/retrieval/attestation/replay) are first-class L2-fact candidates. Cognee has the ingest-side maturity; nobody has the verification-side maturity *and* the outcome-validation closure.

---

## 6. Where we're behind — honest gap closure

### 6.1 Public benchmark scores

**Gap:** Mem0/Zep/Letta/MemMachine all publish LoCoMo + LongMemEval scores. We don't. Without numbers, every "best memory platform" claim is hot air.

**Fix:** Run the benchmark suite specced in `working/memory-benchmarks.md` against the current build. Publish results in `working/memory-benchmarks-trend.md`. Quarterly cadence.

**Cost:** 1–2 person-weeks for first run; quarterly thereafter is automation.

**Priority:** P0 before any external "best-in-class" claim.

### 6.2 Hosted SaaS

**Gap:** Mem0 / Letta / Zep all have managed offerings. Axiom is self-host only.

**Fix:** Optional. Hosted Axiom is a B-Tree Ventures business decision, not an architectural one. The cohorts we serve (regulated, federated, sovereign) tend to *prefer* self-host. SaaS adoption is a different demographic. Decision needed.

**Recommendation:** prioritize air-gap deployability + per-cohort packaging over a hosted offering. The competitive moat is "Axiom runs where your regulator says it has to," not "Axiom runs in our cloud."

### 6.3 Validity-window facts

**Gap:** Zep's signature feature is facts with explicit validity windows. Our concept edges are timeless.

**Fix:** Add `valid_from` + `valid_until` to concept edges. Post-Prague Phase 2 work in spec-memory-maturity. Tracked as new follow-on item.

### 6.4 Framework integration breadth

**Gap:** Mem0's 21 official integrations is a force multiplier. Our integrations are narrower (classroom, chat, research-loop in-tree).

**Fix:** Two moves:
- Publish `axiom-memory` standalone Python package + LangGraph adapter + Claude Agent SDK adapter + Mastra adapter. Each is a thin wrapper over `MemoryStack` / `AskPipeline` / `MemoryBackedPlanStore`. Goal: <50 lines per adapter.
- Make `axi ext init` scaffold extension shells that consume memory through the canonical contracts.

**Priority:** P1 post-Prague; gates external adoption.

### 6.5 Production-scale references

**Gap:** Cognee 1M pipelines/mo, Mem0 enterprise customers. Axiom has Prague as first live cohort.

**Fix:** Get Prague live. Publish a case study post-semester. Then expand to (a) Austin NEUP partners, (b) Charles University, (c) other educational federations. Volume + names earn credibility.

**Priority:** Prague execution is the gate. Everything else depends on it.

### 6.6 Production maturity

**Gap:** Phase 2 of memory roadmap (M-O sweep, tier rotation, container sandbox, real model-strategy resolution from `models.toml`) hasn't shipped. Long-scale benchmark surfaced 10k inflection point — Server-class deployments without M-O sweep degrade past 10k cumulative fragments.

**Fix:** Phase 2 work is queued. Trend doc tracks the regression.

**Priority:** P0 between Prague and second-cohort onboarding.

---

## 7. Public-benchmark plan (the credibility tap)

The fastest move from "interesting architectural claims" to "comparison-table inclusion" is publishing numbers. Concrete plan:

1. **LoCoMo** — already specced in `working/memory-benchmarks.md`. Run against the integrated build (post-#76 persistence). Report as p50/p95 retrieval accuracy + per-task type breakdowns. Publish trend entry within 2 weeks.
2. **LongMemEval (LongMemEvalS subset)** — run with gpt-4.1-mini as judge, mirroring MemMachine's methodology. Publish.
3. **Internal Axiom benchmarks** — `working/memory-benchmarks-long.py` already runs to 30k cumulative; surface the inflection-point data as an honest known-limit publication.
4. **Memory maturity benchmarks** — already specced in `working/memory-maturity-benchmarks.md`. Run alongside LoCoMo; surface promotion precision @ 90d as the Axiom-distinctive metric nobody else measures.

**Discipline commitment:** every quarterly run lands as a trend entry. If a metric regresses, we say so. If we beat a competitor, we say so. Honest beats marketing.

---

## 8. Positioning summary — how we talk about this

Two-sentence elevator pitch (internal-aligned, can be marketed):

> Axiom is the memory layer for AI systems that span institutions, classifications, and decades. Where Mem0 and Letta give your single agent persistent memory, Axiom gives your *cohort* — humans + agents across organizations — accountable, classified, replayable memory that outlives any one model deprecation, by architecture.

**Three positioning bullets** (use in talks / pitches):

- **Federation-native, not metadata-tagged.** Cohort-to-cohort with classification-aware projection. Not single-tenant with tenant tags.
- **Accountable by construction.** Every action carries a named human, propagated across federation. Architecture, not posture.
- **Built to last.** schema_version + cohort persistence. Prague's first plan in 2026 is replayable in 2031.

**What we don't claim** (yet):

- "We beat Zep on LongMemEval" — until we publish a number, this is unsubstantiated.
- "Production-grade at enterprise scale" — Prague is first live cohort; honest about that.
- "Drop-in for any LangGraph workflow" — adapter package is on the roadmap; not shipped.

---

## 9. Revisit cadence

This doc is a living comparison. Update triggers:

- A competitor ships a primitive we lead on (e.g., Letta announces federation): revisit positioning.
- We publish benchmark results: update §3.3 row "Public benchmark scores published".
- A new competitor enters the field: add row to §2 + per-competitor take to §4.
- Quarterly: re-read all of §4 — vendor positioning shifts faster than architecture.

Owner: Ben Booth. Next scheduled review: 2026-07-31 (post-Prague semester).

---

## 10. Appendix — sources

The state-of-the-field data above synthesizes:

- Mem0 docs + 2026 state-of-AI-agent-memory blog post.
- Letta blog (Letta Code launch Apr 2026; Conversations API Jan 2026; Remote Environments Mar 2026).
- Zep + Graphiti research paper (arxiv 2501.13956) + LongMemEval results.
- Cognee technical pages + funding announcement.
- MemMachine benchmark publication (LoCoMo 0.9169 / LongMemEval 93%).
- Multiple comparison surveys (Atlan, MachineLearningMastery, vectorize.io, n1n.ai, blog.bymar.co, Spheron).
- LongMemEval (arxiv 2410.10813), LoCoMo (snap-research.github.io/locomo).

Specific URLs captured at research time. Not all citations preserved here — strategic doc, not academic. The point is that Axiom's leap-aheads (federation, classification, accountability, replay, persistence, plans-as-memory) are *not* present in the surveyed competitor field as of Apr 2026.
