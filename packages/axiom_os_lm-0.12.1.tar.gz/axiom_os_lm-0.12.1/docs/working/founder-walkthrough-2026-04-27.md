# Founder Walkthrough — Classroom Beta · 2026-04-27

**Goal:** ~30 minutes. Run every Tier A+B+C flow on your laptop against HEAD. Capture friction inline. This is the gate before Ondrej sees anything — if you hit it, he'll hit it harder.

**Mindset:** You are an instructor at "Generic University" preparing your first course. You are not a developer. If you find yourself reaching for the source code to answer a question, that's a friction-log entry — Ondrej won't have that option.

**Friction log lives at the bottom.** As you go, drop one-liners under each step's "Notes" or in the catch-all log. Don't fix things mid-walk; just record.

---

## Pre-flight (5 min)

```bash
# 1. Workspace + venv active?
cd /Users/ben/Projects/UT_Computational_NE/axiom
which axi   # should resolve to /Users/ben/Projects/UT_Computational_NE/.venv/bin/axi
axi --version

# 2. Subcommand parity vs HEAD
axi classroom --help | head -20    # should show all 24 subcommands

# 3. Rascal reachable + key set
echo "$RASCAL_API_KEY"   # should be non-empty (rascal-llm700 or new cohort key)
curl -sk https://rascal.austin.utexas.edu:41883/v1/models -H "Authorization: Bearer $RASCAL_API_KEY" | head -5

# 4. VPN check
ping -c 1 rascal.austin.utexas.edu
```

**Notes / friction:**
- (drop one-liner here)

---

## Step 1 — Create classroom from demo (5 min)

```bash
axi classroom prep from-demo --help    # read first; understand what it clones
axi classroom prep from-demo
```

**What to look for:**
- Does it tell you what it just created? Classroom id, course id, where files live?
- Is the output visually clean (Rich console) or wall-of-text?
- Does `axi classroom prep status` show a coherent picture afterward?

**Notes:**
-

---

## Step 2 — Upload course materials (the dogfood path) (7 min)

This is the path Ondrej will use. We're testing it ourselves first.

Pick **one real document** from your laptop — a PDF, a Markdown lecture note, anything ~5–50 pages. Not a fixture file; a real document you'd actually teach from.

```bash
axi classroom prep corpus --help
axi classroom prep corpus <path/to/your/document>
# or whatever the actual flag shape is — read help first
```

**What to look for:**
- Did it ingest? How long did it take?
- Where did the indexed bytes go? (Should be reachable from `prep status`.)
- Does `axi classroom prep corpus --preview <query>` (or equivalent) actually retrieve sensible chunks from your document?
- If you re-run with the same file, does it dedupe or re-ingest?
- **Critical:** can a non-developer figure this out from `--help` alone, or did you need to read source?

**Notes:**
-

---

## Step 3 — Set system prompt (3 min)

```bash
axi classroom prep prompt --help
axi classroom prep tune-prompt   # the one-shot variant
```

**What to look for:**
- Does the default prompt make sense for an arbitrary classroom (not UT-specific)?
- Can you preview how the prompt + a sample query renders?

**Notes:**
-

---

## Step 4 — RAG policy + dry-run as student (5 min)

```bash
axi classroom prep rag --help
axi classroom prep rag    # pick whatever default

axi classroom prep dry-run-enhanced
```

**What to look for:**
- The dry-run impersonates a student. Does it actually feel like a student session?
- Does it pull from your uploaded corpus (Step 2)? Cite chunks?
- Latency on first response — note it. This is your baseline for Prague-from-Austin RTT.

**Notes:**
-

---

## Step 5 — Tier B+C surfaces (5 min)

You've prepped a classroom. Now exercise the live student surfaces.

```bash
# As instructor:
axi classroom briefs       # student briefs management
axi classroom modes        # learning modes (tutor / quiz / reflect / review)
axi classroom quiz         # quiz generation/management
axi classroom doctor       # platform health for this classroom

# As student (use --as-student or the dry-run identity):
axi classroom me           # student-side: my session memory
axi classroom me --memory  # transparency view per project_classroom_memory_transparency.md
axi classroom ask "<a real question about your uploaded document>"
axi classroom ask-instructor "<message>"
axi classroom threads
```

**What to look for:**
- Which subcommands work cleanly?
- Which are confusing / under-documented / need a polish pass?
- Does `axi classroom me --memory` actually surface what the coordinator logged?

**Notes:**
-

---

## Step 6 — Friction log (catch-all)

Drop everything you noticed that didn't fit a step:

- (visual / Rich-console issues)
- (confusing terminology)
- (commands that should exist but don't)
- (commands that exist but shouldn't)
- (places where I had to read source)
- (places where the system did the right thing without me asking — keep these!)

---

## After you're done

Hand this file back to me with the friction log filled in. I'll convert each entry into a GitLab issue (per your "always update GitLab issues" instruction) and triage by show-stopper / polish / post-Prague.

If anything is a hard blocker (can't proceed past it), stop and ping me — we fix in real time before Ondrej sees the path tomorrow.
