# Copyright (c) 2026 B-Tree Ventures, LLC
# SPDX-License-Identifier: Apache-2.0

"""Apply SPDX copyright headers per the ownership map.

Runs against any of the three working repos (axiom/, Neutron_OS/,
dendra/) and inserts a two-line SPDX header at the top of each
``.py``, ``.toml``, and test file. Existing headers are left alone.
Markdown files get a single-line footer attribution added if absent.

Usage:
    # Dry-run — list files that would change:
    python scripts/apply_copyright_headers.py --repo <path> --dry-run

    # Apply:
    python scripts/apply_copyright_headers.py --repo <path>

Repo-specific defaults:
- axiom/ uses ``docs/working/ownership-map.md`` + hardcoded path
  prefixes in this script (authoritative map for ambiguous paths).
- dendra/ is single-owner B-Tree.
- Neutron_OS/ is single-owner UT.

Skipped paths: ``runtime/``, ``.venv/``, ``.git/``, ``__pycache__/``,
``node_modules/``, ``build/``, ``dist/``, ``*.egg-info/``, symlinks.
"""

from __future__ import annotations

import argparse
import os
import sys
from dataclasses import dataclass
from pathlib import Path


# ---------------------------------------------------------------------------
# Copyright strings
# ---------------------------------------------------------------------------


BTREE = "Copyright (c) 2026 B-Tree Ventures, LLC"
UT = "Copyright (c) 2026 The University of Texas at Austin"
SPDX = "SPDX-License-Identifier: Apache-2.0"


@dataclass(frozen=True)
class OwnerSpec:
    """Which owner a path resolves to. ``joint`` means both."""

    btree: bool
    ut: bool

    @property
    def joint(self) -> bool:
        return self.btree and self.ut

    def copyright_lines(self) -> list[str]:
        out = []
        if self.btree:
            out.append(BTREE)
        if self.ut:
            out.append(UT)
        return out


# ---------------------------------------------------------------------------
# Ownership map — axiom repo (the only mixed-ownership repo)
# ---------------------------------------------------------------------------

# Ordered: first match wins. Prefixes are repo-relative POSIX paths.
_AXIOM_PATH_OWNERS: list[tuple[str, OwnerSpec]] = [
    # --- UT-owned: Vega (federation + governance) ---
    ("src/axiom/federation/", OwnerSpec(False, True)),
    ("src/axiom/security/", OwnerSpec(False, True)),
    ("src/axiom/memory/cohort_registry.py", OwnerSpec(False, True)),
    ("src/axiom/extensions/builtins/federation/", OwnerSpec(False, True)),
    ("tests/federation/", OwnerSpec(False, True)),
    ("tests/federation_lifecycle/", OwnerSpec(False, True)),
    ("tests/findings/", OwnerSpec(False, True)),
    ("tests/routing/", OwnerSpec(False, True)),  # EC classification tests
    ("tests/memory/test_cohort_registry", OwnerSpec(False, True)),  # Vega carve-out
    ("tests/test_federation_", OwnerSpec(False, True)),  # root-level federation tests
    ("tests/test_ec_screening", OwnerSpec(False, True)),  # classification
    ("docs/adrs/adr-022", OwnerSpec(False, True)),
    ("docs/adrs/adr-023", OwnerSpec(False, True)),
    ("docs/adrs/adr-024", OwnerSpec(False, True)),
    ("docs/adrs/adr-025", OwnerSpec(False, True)),
    ("docs/adrs/adr-027", OwnerSpec(False, True)),
    ("docs/adrs/adr-028", OwnerSpec(False, True)),
    ("docs/adrs/adr-029", OwnerSpec(False, True)),
    ("docs/adrs/adr-030", OwnerSpec(False, True)),
    ("docs/specs/spec-classification-boundary", OwnerSpec(False, True)),
    ("docs/specs/spec-security", OwnerSpec(False, True)),
    ("docs/prds/prd-federation", OwnerSpec(False, True)),
    ("docs/working/design-resolution-protocol", OwnerSpec(False, True)),
    # --- UT-owned: KEP-LO (classroom) ---
    ("src/axiom/extensions/builtins/classroom/", OwnerSpec(False, True)),
    ("tests/classroom/", OwnerSpec(False, True)),
    ("tests/classroom_unit/", OwnerSpec(False, True)),
    ("tests/classroom_e2e/", OwnerSpec(False, True)),
    ("docs/prds/prd-classroom", OwnerSpec(False, True)),
    ("docs/specs/spec-classroom", OwnerSpec(False, True)),
    ("docs/specs/spec-extension-ui-protocol", OwnerSpec(False, True)),
    ("docs/working/design-instructor-prep-workflow", OwnerSpec(False, True)),
    ("docs/working/design-course-conclusion-workflow", OwnerSpec(False, True)),
    ("docs/working/langfuse-setup", OwnerSpec(False, True)),
    ("docs/working/canvas-setup", OwnerSpec(False, True)),
    ("docs/working/prague-deployment-runbook", OwnerSpec(False, True)),
    # --- B-Tree-owned: Axiom (catch-all default) ---
    # Anything not matched above falls through to BTREE below.
]


def _axiom_owner(rel_path: str) -> OwnerSpec:
    for prefix, owner in _AXIOM_PATH_OWNERS:
        if rel_path.startswith(prefix):
            return owner
    return OwnerSpec(True, False)  # default: Axiom → B-Tree


def _single_owner(owner: OwnerSpec):
    def resolver(_rel_path: str) -> OwnerSpec:
        return owner

    return resolver


# ---------------------------------------------------------------------------
# Repo-specific resolvers
# ---------------------------------------------------------------------------


_REPO_RESOLVERS = {
    "axiom": _axiom_owner,
    "Neutron_OS": _single_owner(OwnerSpec(False, True)),  # UT
    "dendra": _single_owner(OwnerSpec(True, False)),  # B-Tree
}


# ---------------------------------------------------------------------------
# File filtering
# ---------------------------------------------------------------------------


_SKIP_DIR_NAMES = {
    "__pycache__", ".venv", ".git", "node_modules",
    "build", "dist", "runtime",
}

_SKIP_EXACT_DIRS = {
    "docs/_tools/generated",
}

_SKIP_SUFFIXES = {
    ".pyc", ".pyo", ".so", ".dylib", ".db", ".sqlite", ".lock",
    ".log", ".zip", ".gz", ".tar", ".png", ".jpg", ".jpeg", ".pdf",
    ".ico", ".svg", ".woff", ".woff2", ".ttf",
}


def _should_skip(rel_path: str, is_symlink: bool) -> bool:
    if is_symlink:
        return True
    parts = rel_path.split("/")
    if any(p in _SKIP_DIR_NAMES for p in parts):
        return True
    if any(parent in _SKIP_EXACT_DIRS for parent in _iter_parent_dirs(rel_path)):
        return True
    if any(rel_path.endswith(suffix) for suffix in _SKIP_SUFFIXES):
        return True
    if rel_path.endswith(".egg-info"):
        return True
    # Lockfiles
    if rel_path.endswith(("poetry.lock", "package-lock.json", "uv.lock", "Cargo.lock")):
        return True
    return False


def _iter_parent_dirs(rel_path: str):
    parts = rel_path.split("/")
    for i in range(1, len(parts)):
        yield "/".join(parts[:i])


# ---------------------------------------------------------------------------
# Header insertion — per file type
# ---------------------------------------------------------------------------


def _py_header(owner: OwnerSpec) -> str:
    lines = [f"# {ln}" for ln in owner.copyright_lines()]
    lines.append(f"# {SPDX}")
    return "\n".join(lines) + "\n\n"


def _toml_header(owner: OwnerSpec) -> str:
    return _py_header(owner)  # TOML uses # comments too


def _yaml_header(owner: OwnerSpec) -> str:
    return _py_header(owner)  # YAML uses # comments


def _sh_header(owner: OwnerSpec) -> str:
    return _py_header(owner)  # Shell uses # comments


def _md_footer(owner: OwnerSpec) -> str:
    """Single-line italicized footer for Markdown docs."""
    names = " and ".join(owner.copyright_lines())
    return f"\n\n_{names}. Apache-2.0 licensed._\n"


# Signal markers used to detect an already-headed file.
_HEADER_MARKERS = (
    "SPDX-License-Identifier:",
    "Copyright (c) 2026",
)


def _has_header(content: str, head_lines: int = 8) -> bool:
    head = "\n".join(content.splitlines()[:head_lines])
    return any(marker in head for marker in _HEADER_MARKERS)


def _has_md_footer(content: str, tail_lines: int = 6) -> bool:
    tail_text = "\n".join(content.splitlines()[-tail_lines:])
    return any(marker in tail_text for marker in _HEADER_MARKERS)


# ---------------------------------------------------------------------------
# Applying the header
# ---------------------------------------------------------------------------


def _apply_py(path: Path, owner: OwnerSpec) -> bool:
    content = path.read_text(encoding="utf-8")
    if _has_header(content):
        return False

    header = _py_header(owner)
    # Preserve a shebang on line 1 if present.
    if content.startswith("#!"):
        shebang, rest = content.split("\n", 1)
        new = f"{shebang}\n{header}{rest}"
    else:
        new = header + content

    path.write_text(new, encoding="utf-8")
    return True


def _apply_toml(path: Path, owner: OwnerSpec) -> bool:
    content = path.read_text(encoding="utf-8")
    if _has_header(content):
        return False
    path.write_text(_toml_header(owner) + content, encoding="utf-8")
    return True


def _apply_md(path: Path, owner: OwnerSpec) -> bool:
    content = path.read_text(encoding="utf-8")
    if _has_md_footer(content):
        return False
    # Trim any trailing blank lines before appending.
    trimmed = content.rstrip("\n") + "\n"
    path.write_text(trimmed + _md_footer(owner).lstrip("\n"), encoding="utf-8")
    return True


def _apply_shebang_script(path: Path, owner: OwnerSpec) -> bool:
    return _apply_py(path, owner)  # Same logic — preserve shebang.


_EXT_HANDLERS = {
    ".py": _apply_py,
    ".toml": _apply_toml,
    ".yaml": _apply_toml,
    ".yml": _apply_toml,
    ".sh": _apply_shebang_script,
    ".md": _apply_md,
}


# ---------------------------------------------------------------------------
# Walker
# ---------------------------------------------------------------------------


def apply(repo_root: Path, resolver, *, dry_run: bool) -> dict[str, int]:
    """Walk the repo; apply headers where missing. Returns a summary dict."""
    stats = {"scanned": 0, "changed": 0, "skipped_binary": 0, "already": 0}

    for root, dirs, files in os.walk(repo_root):
        # Prune skip-dirs before descent.
        dirs[:] = [
            d for d in dirs if d not in _SKIP_DIR_NAMES
        ]
        for fname in files:
            abs_path = Path(root) / fname
            rel_path = abs_path.relative_to(repo_root).as_posix()
            stats["scanned"] += 1

            if _should_skip(rel_path, abs_path.is_symlink()):
                continue

            ext = abs_path.suffix
            handler = _EXT_HANDLERS.get(ext)
            if handler is None:
                continue

            owner = resolver(rel_path)
            if not owner.btree and not owner.ut:
                continue

            try:
                content_sample = abs_path.read_text(encoding="utf-8")
            except (UnicodeDecodeError, OSError):
                stats["skipped_binary"] += 1
                continue

            # Detect already-present header using the sample.
            if ext == ".md":
                already = _has_md_footer(content_sample)
            else:
                already = _has_header(content_sample)

            if already:
                stats["already"] += 1
                continue

            if dry_run:
                print(f"would-apply [{_summary_tag(owner)}] {rel_path}")
                stats["changed"] += 1
            else:
                if handler(abs_path, owner):
                    stats["changed"] += 1
                    print(f"applied     [{_summary_tag(owner)}] {rel_path}")

    return stats


def _summary_tag(owner: OwnerSpec) -> str:
    if owner.joint:
        return "JOINT"
    if owner.btree:
        return "BT   "
    if owner.ut:
        return "UT   "
    return "NONE "


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--repo", required=True,
        help="Path to the repo root (axiom, Neutron_OS, or dendra).",
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)

    repo_root = Path(args.repo).resolve()
    if not repo_root.is_dir():
        print(f"Not a directory: {repo_root}", file=sys.stderr)
        return 1

    repo_name = repo_root.name
    resolver = _REPO_RESOLVERS.get(repo_name)
    if resolver is None:
        print(
            f"Unknown repo {repo_name!r}; expected one of "
            f"{sorted(_REPO_RESOLVERS.keys())}",
            file=sys.stderr,
        )
        return 1

    print(f"Scanning {repo_root} ({repo_name})...")
    stats = apply(repo_root, resolver, dry_run=args.dry_run)

    print()
    print("Summary:")
    print(f"  scanned:        {stats['scanned']}")
    print(f"  changed:        {stats['changed']}")
    print(f"  already-tagged: {stats['already']}")
    print(f"  binary-skipped: {stats['skipped_binary']}")
    if args.dry_run:
        print("\nDry run — no files modified.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
