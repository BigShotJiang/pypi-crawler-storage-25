# Copyright (c) 2026 B-Tree Ventures, LLC
# SPDX-License-Identifier: Apache-2.0

"""Extension system for Neutron OS.

Discovers, loads, and manages user-space extensions from:
  1. .neut/extensions/   (project-local)
  2. ~/.neut/extensions/  (user-level, cross-project)
"""
