# Copyright (c) 2026 The University of Texas at Austin
# SPDX-License-Identifier: Apache-2.0

"""Test config for the classroom extension.

``axiom-tests`` is a ``pytest11`` plugin — installing it in the active
environment is sufficient for its fixtures to be available here. This
file exists so contributors have an obvious place to add local
fixtures as the suite grows.
"""
