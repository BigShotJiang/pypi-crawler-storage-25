# Copyright (c) 2026 The University of Texas at Austin
# SPDX-License-Identifier: Apache-2.0

"""In-process Canvas API mock for testing.

Not a real HTTP server — a request-response simulator that the
CanvasLMSProvider can talk to via a test adapter. Maintains in-memory
state (courses, enrollments, assignments, submissions) and responds
to the same method calls the real Canvas adapter makes.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class CanvasMockServer:
    """Simulates the Canvas REST API for test isolation."""

    url: str = "mock://canvas"
    _courses: dict[str, dict] = field(default_factory=dict)
    _enrollments: dict[str, list[dict]] = field(default_factory=dict)
    _assignments: dict[str, list[dict]] = field(default_factory=dict)
    _submissions: dict[str, list[dict]] = field(default_factory=dict)
    _next_assignment_id: int = field(default=1000)
    _next_submission_id: int = field(default=2000)

    def add_course(self, course_id: str, name: str) -> None:
        self._courses[course_id] = {"id": course_id, "name": name}
        self._enrollments.setdefault(course_id, [])
        self._assignments.setdefault(course_id, [])

    def add_enrollment(self, course_id: str, enrollment: dict) -> None:
        self._enrollments.setdefault(course_id, []).append(enrollment)

    def drop_enrollment(self, course_id: str, user_id: str) -> None:
        self._enrollments[course_id] = [
            e for e in self._enrollments.get(course_id, []) if e["user_id"] != user_id
        ]

    # -- API-like methods that the Canvas adapter calls ---------------------

    def api_get_enrollments(self, course_id: str) -> list[dict]:
        return list(self._enrollments.get(course_id, []))

    def api_get_user(self, course_id: str, user_id: str) -> dict | None:
        for e in self._enrollments.get(course_id, []):
            if e["user_id"] == user_id:
                return e
        return None

    def api_put_grade(
        self,
        course_id: str,
        assignment_id: str,
        student_id: str,
        score: float,
        comment: str = "",
    ) -> dict:
        # Check student exists
        user = self.api_get_user(course_id, student_id)
        if user is None:
            return {"error": f"student {student_id} not found", "success": False}

        self._next_submission_id += 1
        sub_id = str(self._next_submission_id)
        sub = {
            "id": sub_id,
            "assignment_id": assignment_id,
            "user_id": student_id,
            "score": score,
            "comment": comment,
        }
        self._submissions.setdefault(course_id, []).append(sub)
        return {"success": True, "id": sub_id}

    def api_create_assignment(
        self,
        course_id: str,
        name: str,
        description: str = "",
        points_possible: float = 100,
        due_at: str = "",
    ) -> dict:
        self._next_assignment_id += 1
        aid = str(self._next_assignment_id)
        assignment = {
            "id": aid,
            "name": name,
            "description": description,
            "points_possible": points_possible,
            "due_at": due_at,
        }
        self._assignments.setdefault(course_id, []).append(assignment)
        return {"success": True, "id": aid}
