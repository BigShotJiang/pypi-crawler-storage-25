# Copyright (c) 2026 The University of Texas at Austin
# SPDX-License-Identifier: Apache-2.0

"""Canvas LMS provider — concrete implementation of LMSProvider for Instructure Canvas.

Uses the Canvas REST API (or a mock for testing) to sync roster,
push grades, create assignments, and detect enrollment changes.

For real Canvas: uses the `canvasapi` library (optional dependency).
For testing: accepts a CanvasMockServer via config["_mock_server"].
"""

from __future__ import annotations

from typing import Optional

from .base import (
    AssignmentCreateResult,
    EnrollmentChanges,
    GradePushResult,
    LMSProvider,
    LMSStudent,
)


class CanvasLMSProvider(LMSProvider):
    """Canvas LMS integration following the ADR-012 provider pattern."""

    _log_prefix = "canvas-lms"
    _required_config = ("api_url", "api_token")
    _fingerprint_fields = ("api_url",)

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self._api_url: str = config["api_url"]
        self._api_token: str = config["api_token"]
        # For testing: inject a mock server. Production: this is None.
        self._mock = config.get("_mock_server")

    def available(self) -> bool:
        """Check if Canvas is reachable."""
        if self._mock:
            return True
        try:
            import requests

            resp = requests.get(
                f"{self._api_url}/api/v1/users/self",
                headers={"Authorization": f"Bearer {self._api_token}"},
                timeout=5,
            )
            return resp.status_code == 200
        except Exception:
            return False

    def get_roster(self, course_id: str) -> list[LMSStudent]:
        enrollments = self._get_enrollments(course_id)
        return [
            LMSStudent(
                student_id=e["user_id"],
                name=e.get("name", ""),
                email=e.get("email", ""),
                role="student",
            )
            for e in enrollments
            if e.get("type", "").lower() in ("studentenrollment", "student")
        ]

    def push_grade(
        self,
        course_id: str,
        assignment_id: str,
        student_id: str,
        score: float,
        comment: str = "",
    ) -> GradePushResult:
        if self._mock:
            result = self._mock.api_put_grade(course_id, assignment_id, student_id, score, comment)
            if result.get("success"):
                return GradePushResult(
                    success=True,
                    canvas_submission_id=result["id"],
                )
            return GradePushResult(
                success=False,
                message=result.get("error", "unknown error"),
            )

        # Real Canvas API
        try:
            import requests

            resp = requests.put(
                f"{self._api_url}/api/v1/courses/{course_id}"
                f"/assignments/{assignment_id}/submissions/{student_id}",
                headers={"Authorization": f"Bearer {self._api_token}"},
                json={
                    "submission": {
                        "posted_grade": str(score),
                    },
                    "comment": {"text_comment": comment} if comment else {},
                },
                timeout=10,
            )
            if resp.status_code in (200, 201):
                data = resp.json()
                return GradePushResult(
                    success=True,
                    canvas_submission_id=str(data.get("id", "")),
                )
            return GradePushResult(
                success=False,
                message=f"Canvas returned {resp.status_code}: {resp.text[:200]}",
            )
        except Exception as exc:
            return GradePushResult(success=False, message=str(exc))

    def create_assignment(
        self,
        course_id: str,
        name: str,
        description: str = "",
        points_possible: float = 100,
        due_at: str = "",
    ) -> AssignmentCreateResult:
        if self._mock:
            result = self._mock.api_create_assignment(
                course_id, name, description, points_possible, due_at
            )
            return AssignmentCreateResult(
                success=True,
                canvas_assignment_id=result["id"],
            )

        try:
            import requests

            resp = requests.post(
                f"{self._api_url}/api/v1/courses/{course_id}/assignments",
                headers={"Authorization": f"Bearer {self._api_token}"},
                json={
                    "assignment": {
                        "name": name,
                        "description": description,
                        "points_possible": points_possible,
                        "due_at": due_at or None,
                        "submission_types": ["online_text_entry"],
                        "published": True,
                    }
                },
                timeout=10,
            )
            if resp.status_code in (200, 201):
                data = resp.json()
                return AssignmentCreateResult(
                    success=True,
                    canvas_assignment_id=str(data.get("id", "")),
                )
            return AssignmentCreateResult(
                success=False,
                message=f"Canvas returned {resp.status_code}: {resp.text[:200]}",
            )
        except Exception as exc:
            return AssignmentCreateResult(success=False, message=str(exc))

    def get_student(self, course_id: str, student_id: str) -> Optional[LMSStudent]:
        enrollments = self._get_enrollments(course_id)
        for e in enrollments:
            if e["user_id"] == student_id and e.get("type", "").lower() in (
                "studentenrollment",
                "student",
            ):
                return LMSStudent(
                    student_id=e["user_id"],
                    name=e.get("name", ""),
                    email=e.get("email", ""),
                    role="student",
                )
        return None

    def sync_enrollment_changes(
        self,
        course_id: str,
        known_student_ids: list[str],
    ) -> EnrollmentChanges:
        current_roster = self.get_roster(course_id)
        current_ids = {s.student_id for s in current_roster}
        known_ids = set(known_student_ids)

        added = [s for s in current_roster if s.student_id not in known_ids]
        dropped_ids = known_ids - current_ids
        dropped = [LMSStudent(student_id=sid, name="", email="") for sid in dropped_ids]
        return EnrollmentChanges(added=added, dropped=dropped)

    # -- internal -----------------------------------------------------------

    def _get_enrollments(self, course_id: str) -> list[dict]:
        if self._mock:
            return self._mock.api_get_enrollments(course_id)

        try:
            import requests

            enrollments = []
            url = f"{self._api_url}/api/v1/courses/{course_id}/enrollments"
            headers = {"Authorization": f"Bearer {self._api_token}"}
            while url:
                resp = requests.get(url, headers=headers, timeout=10)
                if resp.status_code != 200:
                    return []
                enrollments.extend(resp.json())
                # Canvas pagination via Link header
                links = resp.headers.get("Link", "")
                url = None
                for part in links.split(","):
                    if 'rel="next"' in part:
                        url = part.split(";")[0].strip(" <>")
            return enrollments
        except Exception:
            return []
