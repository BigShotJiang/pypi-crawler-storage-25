"""Integration tests for the agents extension."""
