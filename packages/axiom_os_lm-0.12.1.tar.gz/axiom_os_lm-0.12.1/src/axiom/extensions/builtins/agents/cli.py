# Copyright (c) 2026 B-Tree Ventures, LLC
# SPDX-License-Identifier: Apache-2.0

"""CLI handler for `axi agents` — agent service lifecycle management.

Usage:
    axi agents status              Show running/stopped state for all agents
    axi agents start [name]        Start one or all always-on agents
    axi agents stop [name]         Stop one or all always-on agents
    axi agents logs [name]         Tail service log output
    axi agents register            Register all daemon agents as system services
    axi agents unregister [name]   Remove service registrations
"""

from __future__ import annotations

import argparse
import sys
import time
from dataclasses import dataclass

from axiom.extensions.contracts import Extension


@dataclass
class RegistrationResult:
    """Outcome of registering a single daemon agent as an OS service."""

    agent_name: str
    registered: bool  # install() returned True
    started: bool  # start() returned True
    provider: str = ""
    error: str = ""

    @property
    def ok(self) -> bool:
        return self.registered and self.started


def register_all_daemon_agents() -> list[RegistrationResult]:
    """Register a single per-slot Background Service (idempotent).

    Background Service pattern — replaces the pre-0.11.1 model of one OS-level
    service registration per always-on agent. After this call:
      - There is exactly one launchd plist / systemd timer per slot.
      - That background-service process discovers all daemon agents at runtime
        and dispatches due heartbeats every 30 seconds.
      - Any pre-0.11.1 per-agent service registrations are cleaned up
        automatically (per Ben 2026-04-29: "automatically fix whatever
        you see, today").

    The reason for the change is operator-visible: in macOS Login Items
    each per-agent registration appeared as its own "axi" entry; with N
    daemon agents the list bloated to N indistinguishable entries. The
    Background Service collapses that to one entry per slot, named
    "{ProductName}-Background-Service" (Axiom-Background-Service for
    axi-platform; NeutronOS-Background-Service when rebranded — host
    admins see who to call for help).

    Never raises; failures are reported in returned results.
    """
    cleanup_results = _cleanup_legacy_per_agent_services()
    results: list[RegistrationResult] = list(cleanup_results)

    try:
        agents = _discover_agent_extensions()
    except Exception as exc:  # pragma: no cover — discovery should not crash
        results.append(
            RegistrationResult(
                agent_name="<discovery>", registered=False, started=False, error=str(exc)
            )
        )
        return results

    # Daemon agents whose manifests *would* be registered (visible to operator
    # in `axi agents status`). The background service dispatches them at runtime.
    daemons = [e for e in agents if e.agent and e.agent.is_always_on and e.agent.is_registrable]
    if not daemons:
        # No daemon agents → no background service needed.
        return results

    try:
        mgr = _make_background_service_manager()
        installed = mgr.install()
        started = mgr.start() if installed else False
        results.append(
            RegistrationResult(
                agent_name="background-service",
                registered=bool(installed),
                started=bool(started),
                provider=mgr.provider_name,
                error="" if installed and started else "background-service install or start returned False",
            )
        )
    except Exception as exc:
        results.append(
            RegistrationResult(
                agent_name="background-service",
                registered=False,
                started=False,
                error=str(exc),
            )
        )
    return results


def _cleanup_legacy_per_agent_services() -> list[RegistrationResult]:
    """Remove any pre-0.11.1 per-agent OS service registrations on this slot.

    Pre-0.11.1 we installed one service per agent (com.axi-platform.<agent>-agent.plist
    on macOS, neut-<agent>-agent.{service,timer} on Linux). Post-0.11.1 there
    is exactly one background service. This function scans for the legacy pattern
    and cleans up; idempotent.

    Returns a RegistrationResult per cleanup so the operator sees what was
    removed. Never raises.
    """
    import platform

    results: list[RegistrationResult] = []
    if platform.system() == "Darwin":
        results.extend(_cleanup_legacy_launchd())
    elif platform.system() == "Linux":
        results.extend(_cleanup_legacy_systemd())
    return results


def _cleanup_legacy_launchd() -> list[RegistrationResult]:
    """Remove stale launchd plists from this slot.

    Two cleanup passes:
      1. **Pre-0.11.1 per-agent plists** — `com.<pkg>.<agent>-agent.plist`
         from any installed portfolio member.
      2. **Cross-brand Background Service plists** — when the operator
         installed (e.g.) NeutronOS over Axiom, the previously-registered
         `com.axi-platform.background-service.plist` is now stale and
         must be replaced by `com.neutron-os.background-service.plist`.
         This pass finds and removes any portfolio-member Background
         Service plist that doesn't match the *current* brand.

    Both passes are driven by the entry-points-discovered portfolio
    member list, so future products (X-Foo, Y-Bar, ...) participate
    automatically without axi-platform changes.
    """
    import subprocess
    from pathlib import Path

    from axiom.infra.branding import discover_portfolio_members, get_branding

    current_pkg = get_branding().package_name
    launch_agents_dir = Path.home() / "Library" / "LaunchAgents"
    if not launch_agents_dir.exists():
        return []

    current_bg_plist = f"com.{current_pkg}.background-service.plist"
    members = discover_portfolio_members()
    # Always include the current brand even if entry-points discovery
    # hasn't propagated (e.g., on first install before the new wheel
    # is fully imported).
    portfolio_pkgs = {m.package_name for m in members} | {current_pkg}

    results: list[RegistrationResult] = []

    # Pass 1: pre-0.11.1 per-agent plists from any portfolio member.
    for pkg in portfolio_pkgs:
        legacy_pattern = f"com.{pkg}.*-agent.plist"
        for plist_path in launch_agents_dir.glob(legacy_pattern):
            results.extend(_unload_and_remove_plist(plist_path))

    # Pass 2: cross-brand Background Service plists (other portfolio
    # member's BS plist is stale; the current brand's wins).
    for pkg in portfolio_pkgs:
        if pkg == current_pkg:
            continue
        cross_brand = launch_agents_dir / f"com.{pkg}.background-service.plist"
        if cross_brand.exists():
            results.extend(_unload_and_remove_plist(cross_brand))

    _ = current_bg_plist  # documentation: this is the survivor; never cleaned up
    _ = subprocess  # used inside the helper
    return results


def _unload_and_remove_plist(plist_path) -> list[RegistrationResult]:
    """Helper: unload a plist via launchctl, remove the file, return one result."""
    import subprocess

    label = plist_path.stem
    try:
        subprocess.run(
            ["launchctl", "unload", str(plist_path)],
            capture_output=True,
            timeout=10,
        )
        plist_path.unlink(missing_ok=True)
        return [
            RegistrationResult(
                agent_name=f"<legacy-cleanup:{label}>",
                registered=False,
                started=False,
                error="",
            )
        ]
    except Exception as exc:
        return [
            RegistrationResult(
                agent_name=f"<legacy-cleanup:{label}>",
                registered=False,
                started=False,
                error=f"cleanup failed: {exc}",
            )
        ]


def _cleanup_legacy_systemd() -> list[RegistrationResult]:
    """Remove stale systemd user units from this slot.

    Two cleanup passes (mirror of the launchd path):
      1. **Pre-0.11.1 per-agent timers** — `neut-<agent>-agent.{service,timer}`
         under any prefix the portfolio uses (currently `neut-` for both
         axi-platform and neutron-os; future portfolio members may use
         a different prefix and self-declare via entry-points).
      2. **Cross-brand Background Service units** — if a previous brand
         registered `<other-prefix>-background-service.{service,timer}`
         and the current brand is different, clean up the stale.
    """
    import subprocess
    from pathlib import Path

    from axiom.infra.branding import get_branding

    unit_dir = Path.home() / ".config" / "systemd" / "user"
    if not unit_dir.exists():
        return []

    # The unit-prefix is currently "neut-" for both portfolio members
    # we ship today (axi-platform + neutron-os both use it for back-compat
    # with NeutronOS-rebrand expectations). Future portfolio members
    # using a different unit prefix should declare it in their portfolio
    # entry-point metadata; tracked as a follow-up.
    bg_basename = "neut-background-service"
    legacy_pattern_service = "neut-*-agent.service"
    legacy_pattern_timer = "neut-*-agent.timer"

    results: list[RegistrationResult] = []
    seen_units: set[str] = set()
    for pattern in (legacy_pattern_service, legacy_pattern_timer):
        for unit_path in unit_dir.glob(pattern):
            stem = unit_path.stem
            if stem == bg_basename:
                continue
            if stem in seen_units:
                continue
            seen_units.add(stem)
            try:
                subprocess.run(
                    ["systemctl", "--user", "disable", "--now", f"{stem}.timer"],
                    capture_output=True,
                    timeout=10,
                )
                (unit_dir / f"{stem}.service").unlink(missing_ok=True)
                (unit_dir / f"{stem}.timer").unlink(missing_ok=True)
                results.append(
                    RegistrationResult(
                        agent_name=f"<legacy-cleanup:{stem}>",
                        registered=False,
                        started=False,
                        error="",
                    )
                )
            except Exception as exc:
                results.append(
                    RegistrationResult(
                        agent_name=f"<legacy-cleanup:{stem}>",
                        registered=False,
                        started=False,
                        error=f"cleanup failed: {exc}",
                    )
                )

    _ = get_branding  # cross-brand systemd cleanup is a follow-up; today both
    # portfolio members use the same `neut-` prefix and the BS unit name is
    # the same, so the cross-brand case reduces to "BS unit gets rewritten
    # in place" — no cross-prefix cleanup needed yet.

    if results:
        try:
            subprocess.run(
                ["systemctl", "--user", "daemon-reload"], capture_output=True, timeout=10
            )
        except Exception:
            pass
    return results


def missing_daemon_agents() -> list[str]:
    """Return names of always-on agents whose OS service is not installed.

    Used by the CLI self-heal hook as a cheap drift detector. Never raises.
    """
    try:
        agents = _discover_agent_extensions()
    except Exception:
        return []
    missing: list[str] = []
    for ext in agents:
        if not (ext.agent and ext.agent.is_always_on):
            continue
        try:
            mgr = _make_service_manager(ext)
            info = mgr.status()
            if info.status == "not_installed":
                missing.append(ext.name)
        except Exception:
            # Treat errors as "unknown" — don't add to missing list to avoid noise.
            pass
    return missing


# ---------------------------------------------------------------------------
# Discovery helpers
# ---------------------------------------------------------------------------


def _discover_agent_extensions() -> list[Extension]:
    """Find all extensions with an [agent] section.

    Lifecycle visibility is gated on the presence of `[agent]` in the
    manifest, NOT on the top-level `[extension] kind` (which defaults
    to "tool" for every agent-bearing extension we ship — release,
    hygiene, publishing, signals, model_corral). Daemon vs. lazy is
    further filtered downstream by `agent.is_always_on`.
    """
    from axiom.extensions.discovery import discover_extensions

    return [ext for ext in discover_extensions() if ext.agent is not None]


_BACKGROUND_SERVICE_INTERVAL_SECS = 30


def _background_service_binary_name() -> str:
    """Brand-aware wrapper binary name installed via console_scripts.

    Axiom installs ship `Axiom-Background-Service`. NeutronOS installs
    add their own (e.g., `NeutronOS-Background-Service`) in their
    pyproject and we use that instead — host admins reading macOS Login
    Items see who to call for help based on what they think they
    installed.
    """
    from axiom.infra.branding import get_branding

    product = get_branding().product_name.replace(" ", "-")
    return f"{product}-Background-Service"


def _make_background_service_manager():
    """Create a ServiceManager for the per-slot Background Service.

    The Background Service is a single OS service that wakes every 30s and
    dispatches all due agent heartbeats. One entry per slot in macOS
    Login Items (vs. one per agent before 0.11.1); same scaling on
    Linux systemd. ADR-036 §D3 slot identity becomes operationally
    visible here once F7 (slot-aware service naming) ships in Phase 2.

    Wrapper-binary resolution order (handles the brand-installed-but-
    its-own-wrapper-not-yet-present case):

      1. Try the current brand's wrapper (e.g., `NeutronOS-Background-Service`
         when neutron-os is the active brand).
      2. Fall back to `Axiom-Background-Service` — always present
         because axi-platform is a transitive dep of every portfolio
         package, and axi-platform always installs this wrapper. Logs a
         one-line warning so the operator sees the fallback was used.
      3. Last resort: pass the literal name to the OS service manager;
         the registration will fail loudly with "binary not found"
         rather than silently mis-fire.
    """
    import logging
    import shutil

    from axiom.infra.branding import get_branding
    from axiom.infra.services import ServiceManager

    log = logging.getLogger(__name__)
    binary_name = _background_service_binary_name()
    binary_path = shutil.which(binary_name)
    if binary_path is None:
        fallback = "Axiom-Background-Service"
        fallback_path = shutil.which(fallback)
        if fallback_path is not None:
            log.warning(
                "Wrapper binary %r not found; falling back to %r. "
                "If you intended the current brand to provide its own wrapper, "
                "ensure its package declares the console_script.",
                binary_name,
                fallback,
            )
            binary_path = fallback_path
        else:
            binary_path = binary_name  # let ServiceManager surface the error

    pkg = get_branding().package_name

    return ServiceManager(
        name="background-service",
        binary=binary_path,
        args=[],
        interval_secs=_BACKGROUND_SERVICE_INTERVAL_SECS,
        service_id=f"com.{pkg}.background-service",
    )


def _make_service_manager(ext: Extension):
    """Create a ServiceManager for an agent extension (LEGACY).

    Pre-0.11.1 used per-agent service registration. Post-0.11.1 we use
    the Background Service pattern (`_make_background_service_manager`). This
    legacy helper is kept only for callers that still need per-agent
    paths (e.g., introspection of legacy registrations during cleanup).
    Do NOT use for new registrations — use the Background Service.
    """
    import os
    import re

    from axiom.infra.branding import get_branding
    from axiom.infra.services import ServiceManager

    cli = get_branding().cli_name

    # Resolve [agent.env] from the manifest with ${VAR} substitution from
    # the operator's current os.environ at install time. ADR-036 §D9 makes
    # this the auditable, manifest-declared opt-in path for any env beyond
    # the bounded PATH + LANG/LC_ALL the platform always provides.
    env: dict[str, str] = {}
    if ext.agent and ext.agent.env:
        var_re = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")
        for key, value in ext.agent.env.items():
            env[key] = var_re.sub(lambda m: os.environ.get(m.group(1), ""), value)

    return ServiceManager(
        name=f"{ext.name}-agent",
        binary=cli,
        args=_agent_service_args(ext),
        env=env,
        interval_secs=ext.agent.heartbeat_interval if ext.agent else 0,
    )


def _agent_service_args(ext: Extension) -> list[str]:
    """Build the argv the systemd timer fires on each heartbeat tick.

    Reads ``[agent] heartbeat_command`` from the extension manifest — a
    space-separated string like ``"mo health --json"`` that becomes a
    oneshot command. Callers MUST gate registration on
    ``ext.agent.is_registrable`` so agents without a declared
    heartbeat_command don't end up with a crash-looping invocation (the
    v0.9.0–v0.10.2 regression that motivated this design).
    """
    if ext.agent and ext.agent.heartbeat_command:
        return ext.agent.heartbeat_command.split()
    # Defensive: if caller failed to gate on is_registrable, emit a
    # command that will fail fast and obviously rather than loop.
    return ["--invalid-no-heartbeat-command-configured"]


def _get_service_status(ext: Extension) -> str:
    """Get the service status string for an agent."""

    mgr = _make_service_manager(ext)
    info = mgr.status()
    return info.status


def _find_agent(agents: list[Extension], name: str) -> Extension | None:
    """Find an agent by name (matches extension name or CLI noun)."""
    for ext in agents:
        if ext.name == name:
            return ext
        for cmd in ext.cli_commands:
            if cmd.noun == name:
                return ext
    return None


# ---------------------------------------------------------------------------
# Command handlers
# ---------------------------------------------------------------------------


def _cmd_status(args) -> int:
    agents = _discover_agent_extensions()
    if not agents:
        print("No agent extensions with lifecycle configuration found.")
        return 0

    # Background Service status — the single OS-level surface (Login Items / systemd timer).
    coord_mgr = _make_background_service_manager()
    coord_info = coord_mgr.status()
    coord_color_map = {
        "running": "\033[32m",
        "starting": "\033[33m",
        "stopped": "\033[33m",
        "failed": "\033[31m",
        "not_installed": "\033[90m",
        "unknown": "\033[90m",
    }
    coord_color = coord_color_map.get(coord_info.status, "")
    coord_label = "not installed" if coord_info.status == "not_installed" else coord_info.status
    coord_status_str = f"{coord_color}{coord_label}\033[0m" if coord_color else coord_label
    binary_name = _background_service_binary_name()

    print(f"Background Service: {binary_name}")
    print("=" * 60)
    print(f"  Status:    {coord_status_str} ({coord_info.provider})")
    print(f"  Cadence:   every {_BACKGROUND_SERVICE_INTERVAL_SECS}s")
    print()

    # Per-agent view — what the Background Service is dispatching, not what's
    # registered as an OS service (those are no longer per-agent).
    print("Agents (dispatched by Background Service)")
    print("=" * 60)
    print(f"  {'Agent':<20} {'Startup':<10} {'Interval':<10} {'Last run':<20}")
    print(f"  {'-' * 20} {'-' * 10} {'-' * 10} {'-' * 20}")

    last_runs = _bg_last_runs()
    now = time.time()
    for ext in agents:
        interval = f"{ext.agent.heartbeat_interval}s"
        startup = ext.agent.startup
        last_run = last_runs.get(ext.name)
        if last_run is None:
            last_run_str = "—"
        else:
            elapsed = now - last_run
            last_run_str = _format_elapsed(elapsed) + " ago"
        print(f"  {ext.name:<20} {startup:<10} {interval:<10} {last_run_str:<20}")

    # Watchers summary
    print()
    for ext in agents:
        if ext.agent.watchers:
            enabled = [w for w in ext.agent.watchers if w.enabled]
            if enabled:
                names = ", ".join(w.name for w in enabled)
                print(f"  {ext.name} watchers: {names}")

    print()
    return 0


def _bg_last_runs() -> dict[str, float]:
    """Read the background service's per-agent last-run timestamps."""
    from axiom.agents.background_service import StateStore, _state_path

    try:
        return StateStore(_state_path()).load()
    except Exception:
        return {}


def _format_elapsed(seconds: float) -> str:
    """Compact human-friendly elapsed-time formatter."""
    if seconds < 60:
        return f"{seconds:.0f}s"
    if seconds < 3600:
        return f"{seconds / 60:.0f}m"
    if seconds < 86400:
        return f"{seconds / 3600:.1f}h"
    return f"{seconds / 86400:.1f}d"


def _cmd_start(args) -> int:
    """Start the per-slot Background Service (which dispatches all daemon agents).

    Pre-0.11.1 this command accepted an agent name to start an individual
    agent; post-0.11.1 there is exactly one Background Service per slot. The
    name argument is accepted but ignored (with a one-line note) so old
    muscle memory doesn't error out.
    """
    name = getattr(args, "name", None)
    if name:
        print(
            f"Note: post-0.11.1 there is exactly one Background Service per slot "
            f"(starting it; '{name}' would be dispatched by the Background Service)."
        )

    print("Starting Background Service...")
    results = register_all_daemon_agents()
    rc = 0
    for r in results:
        if r.agent_name.startswith("<legacy-cleanup:"):
            print(f"  Cleaned up legacy unit: {r.agent_name[16:-1]}")
        elif r.ok:
            print(f"  Background Service: running ({r.provider})")
        else:
            print(f"  Failed: {r.agent_name} — {r.error or 'unknown'}")
            rc = 1
    return rc


def _cmd_stop(args) -> int:
    """Stop the per-slot Background Service. Stops all agents because they're
    dispatched by the Background Service.
    """
    name = getattr(args, "name", None)
    if name:
        print(
            f"Note: post-0.11.1 there is exactly one Background Service per slot "
            f"(stopping it; '{name}' was dispatched by the Background Service)."
        )

    mgr = _make_background_service_manager()
    if mgr.stop():
        print("  background-service: stopped")
        return 0
    print("  background-service: failed to stop (may not be running)")
    return 1


def _cmd_register(args) -> int:
    """Register all daemon agents as system services."""
    results = register_all_daemon_agents()
    if not results:
        print("No daemon agents to register.")
        return 0

    print("Registering Background Service...")
    rc = 0
    for r in results:
        if r.agent_name.startswith("<legacy-cleanup:"):
            # Legacy cleanup is success when error is empty; the
            # RegistrationResult.ok=False is misleading here because nothing
            # was meant to be "registered" — cleanup is removal, not install.
            label = r.agent_name[len("<legacy-cleanup:") : -1]
            if not r.error:
                print(f"  Cleaned up legacy unit: {label}")
            else:
                print(f"  Cleanup failed: {label} — {r.error}")
                rc = 1
        elif r.ok:
            print(f"  Registered: {r.agent_name} ({r.provider})")
        else:
            detail = r.error or "install or start failed"
            print(f"  Failed: {r.agent_name} — {detail}")
            rc = 1
    return rc


def _cmd_unregister(args) -> int:
    """Unregister the per-slot Background Service + clean up any legacy per-agent units."""
    name = getattr(args, "name", None)
    if name:
        print(
            f"Note: post-0.11.1 there is exactly one Background Service per slot "
            f"(unregistering it; '{name}' was dispatched by the Background Service)."
        )

    rc = 0
    cleanup = _cleanup_legacy_per_agent_services()
    for r in cleanup:
        print(f"  Cleaned up legacy unit: {r.agent_name[16:-1] if r.agent_name.startswith('<legacy-cleanup:') else r.agent_name}")

    mgr = _make_background_service_manager()
    if mgr.uninstall():
        print("  Unregistered: background-service")
    else:
        print("  Failed to unregister background-service")
        rc = 1
    return rc


def _cmd_logs(args) -> int:
    from axiom.infra.paths import get_user_state_dir

    agents = _discover_agent_extensions()
    name = getattr(args, "name", None)

    if name:
        ext = _find_agent(agents, name)
        if ext is None:
            print(f"Unknown agent: {name}")
            return 1
        agents = [ext]

    services_dir = get_user_state_dir() / "services"
    for ext in agents:
        stdout_log = services_dir / f"{ext.name}-agent.stdout.log"
        stderr_log = services_dir / f"{ext.name}-agent.stderr.log"

        print(f"--- {ext.name} ---")
        for log_path in (stdout_log, stderr_log):
            if log_path.exists():
                lines = log_path.read_text(encoding="utf-8").splitlines()
                for line in lines[-20:]:
                    print(f"  {line}")
            else:
                print(f"  No log: {log_path.name}")
        print()

    return 0


# ---------------------------------------------------------------------------
# CLI parser
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="axi agents",
        description="Manage always-on agent services",
    )
    sub = parser.add_subparsers(dest="action")

    sub.add_parser("status", help="Show agent service status")

    start_p = sub.add_parser("start", help="Start one or all agents")
    start_p.add_argument("name", nargs="?", help="Agent name (omit for all)")

    stop_p = sub.add_parser("stop", help="Stop one or all agents")
    stop_p.add_argument("name", nargs="?", help="Agent name (omit for all)")

    sub.add_parser("register", help="Register all daemon agents as system services")

    unreg_p = sub.add_parser("unregister", help="Remove service registrations")
    unreg_p.add_argument("name", nargs="?", help="Agent name (omit for all)")

    logs_p = sub.add_parser("logs", help="Tail agent service logs")
    logs_p.add_argument("name", nargs="?", help="Agent name (omit for all)")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if not args.action:
        args.action = "status"

    handlers = {
        "status": _cmd_status,
        "start": _cmd_start,
        "stop": _cmd_stop,
        "register": _cmd_register,
        "unregister": _cmd_unregister,
        "logs": _cmd_logs,
    }

    handler = handlers.get(args.action)
    if handler is None:
        parser.print_help()
        return 1

    return handler(args)


if __name__ == "__main__":
    sys.exit(main())
