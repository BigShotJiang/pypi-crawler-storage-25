"""Integration tests for the chat extension."""
