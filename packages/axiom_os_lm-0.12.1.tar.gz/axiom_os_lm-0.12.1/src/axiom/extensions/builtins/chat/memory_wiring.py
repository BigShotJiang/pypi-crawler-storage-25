# Copyright (c) 2026 B-Tree Ventures, LLC
# SPDX-License-Identifier: Apache-2.0

"""Wire long-term memory into a bare ``axi chat`` agent.

When the user has run ``axi federation init`` (or any equivalent that
persisted a node identity), every chat session belongs to a principal.
This module bootstraps a ``CompositionService`` for that principal and
attaches it to the chat agent so:

- Each turn writes a ``prompt_composition`` episodic fragment via the
  agent's existing observability hook.
- The ``inject_session_memory`` cascade in ``agent._build_system_prompt``
  pulls prior-session episodic fragments back into the system prompt,
  giving cross-session continuity.
- ``axi memory show <principal>`` returns real fragments instead of
  "_No prior fragments_".

Without an identity (fresh install, classroom-only flow, etc.) the
function is a no-op — chat keeps working in stateless mode, and the
classroom path retains its own composition wiring.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .agent import ChatAgent

log = logging.getLogger(__name__)


def _principal_id_from_identity() -> str | None:
    """Derive a Matrix-style ``@name:context`` principal from local identity."""
    try:
        from axiom.vega.federation.identity import load_identity
    except Exception:
        return None
    identity = load_identity()
    if identity is None:
        return None
    display = identity.display_name or ""
    if not display:
        return None
    # display_name is conventionally already ``name:context`` (e.g. "ben:laptop").
    # Normalise to the @name:context form per feedback_principal_naming.
    return display if display.startswith("@") else f"@{display}"


def attach_memory(agent: "ChatAgent") -> bool:
    """Bootstrap a ``CompositionService`` for the chat agent's principal.

    Returns True iff memory was wired (identity found, MemoryStack built,
    agent + session attributes set). Returns False on graceful degradation.
    """
    principal_id = _principal_id_from_identity()
    if not principal_id:
        log.debug("attach_memory: no identity → chat runs stateless")
        return False
    try:
        from axiom.memory.bootstrap import build_memory_stack

        stack = build_memory_stack(scope_id="chat")
    except Exception as exc:
        log.warning("attach_memory: build_memory_stack failed: %s", exc)
        return False

    agent._composition = stack.composition  # type: ignore[attr-defined]
    # Session is a dataclass without a principal_id field; setting an
    # attribute is fine (transient — re-resolved on resume).
    try:
        agent.session.principal_id = principal_id  # type: ignore[attr-defined]
    except Exception:
        # Highly defensive — Session is a regular dataclass; this should never fail.
        log.debug("attach_memory: could not set session.principal_id")
    return True


__all__ = ["attach_memory"]
