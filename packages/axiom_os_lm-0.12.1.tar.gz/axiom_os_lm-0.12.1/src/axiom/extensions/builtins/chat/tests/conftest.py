# Copyright (c) 2026 B-Tree Ventures, LLC. Apache-2.0 licensed.
"""Test config for the chat extension."""
