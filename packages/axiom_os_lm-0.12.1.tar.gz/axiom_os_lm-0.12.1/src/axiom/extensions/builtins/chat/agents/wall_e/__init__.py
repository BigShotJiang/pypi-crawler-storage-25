# Copyright (c) 2026 B-Tree Ventures, LLC
# SPDX-License-Identifier: Apache-2.0

"""WALL-E — Loop agent (the platform protagonist).

Persona at ``persona.md``; runtime entrypoints live in the parent
``chat/`` package. Consumer layers rebrand him: NeutronOS → ``Neut``,
others → their own name. Under the hood, it's always WALL-E.
"""
