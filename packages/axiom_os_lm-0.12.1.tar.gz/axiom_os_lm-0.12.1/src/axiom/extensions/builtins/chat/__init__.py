# Copyright (c) 2026 B-Tree Ventures, LLC
# SPDX-License-Identifier: Apache-2.0

"""Interactive conversational agent.

Houses **WALL-E**, the Loop agent in the platform's REPL cycle. WALL-E
is the user-facing protagonist — humans talk to WALL-E, and WALL-E
dispatches to EVE / CURI-O / PR-T / M-O / D-FIB as needed. See
``agents/wall_e/persona.md`` for WALL-E's role definition.

Consumer layers rebrand the face per Axiomatic Way principle #7
(NeutronOS surfaces him as ``Neut``); the underlying agent identity is
canonical.
"""
