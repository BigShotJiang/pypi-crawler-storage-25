# Copyright (c) 2026 B-Tree Ventures, LLC. Apache-2.0 licensed.
"""Built-in providers for ``axi ext``.

Each verb lives in its own module; the registry imports them lazily so
import-time cost of unused verbs stays zero.
"""
