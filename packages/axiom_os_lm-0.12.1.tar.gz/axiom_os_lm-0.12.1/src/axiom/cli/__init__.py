# Copyright (c) 2026 B-Tree Ventures, LLC. Apache-2.0 licensed.
"""Axiom CLI infrastructure.

This package hosts reusable CLI scaffolding shared across ``axi`` subcommands.
The extension-lifecycle (``axi ext``) provider framework lives in
:mod:`axiom.cli.ext`.
"""
