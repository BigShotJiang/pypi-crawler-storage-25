# Copyright (c) 2026 B-Tree Ventures, LLC
# SPDX-License-Identifier: Apache-2.0

"""Turn/session classifier — generic intent classification (§5.4 / §2.8).

Classifies conversation turns into multi-label intent categories:
q_and_a, generative, exploratory, debugging, metacognitive, fun.

Domain-agnostic core. Extensions wrap this with their own domain
concerns — e.g. classroom's `turn_classifier.py` adds learning-
objective keyword matching on top.

Two backends:
1. Deterministic keyword heuristics — standalone, runs offline.
2. Optional LLM classifier callable — higher quality; takes
   precedence when provided.

Operates on user turns only (assistant replies are ignored for
intent classification).

Dendra integration (optional)
-----------------------------
Axiom is **Dendra-ready**, not Dendra-dependent. When Dendra is
installed (``pip install axiom[learning]``), the deterministic rule
is wrapped in a :class:`~dendra.LearnedSwitch` via the
:mod:`axiom.infra.dendra_adapter` shim so every Phase-0 decision
is recorded to an outcome log and ground truth can be fed back via
:func:`record_turn_outcome`. When Dendra is NOT installed, this
module behaves exactly as it did pre-integration: no outcome log,
no switch, identical return values. See
``dendra/docs/working/dendra-axiom-decoupling-policy.md``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional

from axiom.infra import dendra_adapter


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class SessionClassification:
    """Result of classifying a single session."""

    session_id: str
    principal_id: str  # user/student/operator identifier
    labels: list[str] = field(default_factory=list)
    topics: list[str] = field(default_factory=list)
    rationale: Optional[str] = None


# ---------------------------------------------------------------------------
# Deterministic keyword heuristics
# ---------------------------------------------------------------------------


_GENERATIVE_VERBS = (
    "write", "generate", "create", "produce", "build", "code",
    "draft", "compose", "make me a", "make a",
)

_DEBUGGING_TOKENS = (
    "error", "exception", "traceback", "bug", "broken", "not working",
    "crash", "fails", "failed", "doesn't work", "stuck on",
)

_METACOGNITIVE_TOKENS = (
    "i'm struggling", "i'm confused", "reflect", "my approach",
    "how am i doing", "what am i missing", "why do i keep",
    "help me understand why", "what should i focus on",
)

_FUN_TOKENS = (
    "joke", "lol", "haha", "🙂", "weekend", "movie",
)


def user_text(turns: list[dict]) -> str:
    """Concatenate user turn contents, lowercased. Exported so extensions
    that want to run their own heuristics on the same text can reuse it."""
    parts = []
    for t in turns:
        if t.get("role") == "user":
            parts.append(str(t.get("content", "")))
    return "\n".join(parts).lower()


_INTENT_LABELS = (
    "q_and_a",
    "generative",
    "debugging",
    "metacognitive",
    "fun",
    "exploratory",
)


def _keyword_label_list(text: str) -> list[str]:
    """Raw keyword heuristic — the library's circuit-breaker floor.

    Kept as a bare function (no decoration) so that the Dendra switch's
    rule can call it and the public :func:`deterministic_labels` can call
    it too without re-entering the switch.
    """
    labels: list[str] = []

    if "?" in text:
        labels.append("q_and_a")
    if any(v in text for v in _GENERATIVE_VERBS):
        labels.append("generative")
    if any(tok in text for tok in _DEBUGGING_TOKENS):
        labels.append("debugging")
    if any(tok in text for tok in _METACOGNITIVE_TOKENS):
        labels.append("metacognitive")
    if any(tok in text for tok in _FUN_TOKENS):
        labels.append("fun")

    if not labels:
        labels.append("exploratory")

    return labels


# ---------------------------------------------------------------------------
# Dendra switch — Phase 0 (RULE) outcome logging
# ---------------------------------------------------------------------------
#
# Multi-label adaptation note
# ---------------------------
# Dendra's current API is single-label. The classifier emits multi-label
# results (e.g. ``["q_and_a", "generative"]``). We adopt option (b) from
# the integration brief: collapse the label-set into a single combo
# string (``"q_and_a+generative"``) at the switch boundary and store
# that in the outcome log. Public callers of :func:`deterministic_labels`
# still receive ``list[str]`` — no behavior regression.
#
# When Dendra gains multi-label support (or we graduate to Phase 1+ and
# want a per-label head) we can revisit and split into 6 per-label
# switches without changing the caller contract.


def _combo_from_labels(labels: list[str]) -> str:
    """Join multi-label output as a single stable string for the switch log."""
    # Preserve the canonical ordering from _INTENT_LABELS so equivalent
    # label-sets always map to the same combo string.
    order = {label: i for i, label in enumerate(_INTENT_LABELS)}
    return "+".join(sorted(set(labels), key=lambda lbl: order.get(lbl, 99)))


def _combo_label_rule(text: str) -> str:
    """The rule the Dendra switch wraps — collapses to a combo string."""
    return _combo_from_labels(_keyword_label_list(text))


turn_classifier_switch = dendra_adapter.optional_switch(
    name="turn_classifier",
    rule=_combo_label_rule,
    labels=list(_INTENT_LABELS),
    author="@axiom:turn-classifier",
)
"""The Dendra ``LearnedSwitch`` when Dendra is installed; ``None``
otherwise. See :mod:`axiom.infra.dendra_adapter`."""


def deterministic_labels(text: str) -> list[str]:
    """Apply keyword heuristics to extract multi-label intent categories.

    When Dendra is installed, additionally routes the call through the
    outcome-log side effect (via the adapter shim). The primary return
    shape is unchanged — ``list[str]`` — for all callers, whether or
    not Dendra is present.
    """
    labels = _keyword_label_list(text)
    # Side-effect-only observation: the shim swallows all errors and
    # no-ops gracefully when Dendra isn't installed.
    dendra_adapter.safe_classify(turn_classifier_switch, text)
    return labels


def record_turn_outcome(
    *,
    text: str,
    labels: list[str],
    outcome: str = "unknown",
    source: str = "rule",
    confidence: float = 1.0,
) -> None:
    """Record ground-truth (or inferred) outcome for a prior classification.

    Callers invoke this when truth becomes available — quiz scoring,
    teacher feedback, downstream routing success, etc. The output is
    stored as a combo string (``"q_and_a+generative"``) matching the
    switch's single-label contract.

    ``outcome`` is one of ``"correct"`` / ``"incorrect"`` / ``"unknown"``.
    When Dendra is not installed, this function is a no-op (nothing to
    record against).
    """
    dendra_adapter.safe_record_outcome(
        turn_classifier_switch,
        input=text,
        output=_combo_from_labels(labels),
        outcome=dendra_adapter.outcome_enum_value(outcome),
        source=source,
        confidence=confidence,
    )


# ---------------------------------------------------------------------------
# Classifier protocol
# ---------------------------------------------------------------------------


LLMClassifier = Callable[..., dict]
"""Signature: (turns, **kw) → {labels, topics, rationale}"""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def classify_session(
    turns: list[dict],
    session_id: str,
    principal_id: str,
    classifier: Optional[LLMClassifier] = None,
    **classifier_kwargs,
) -> SessionClassification:
    """Classify a session into intent labels.

    If `classifier` is supplied, it takes precedence — called with
    (turns=..., **classifier_kwargs) and expected to return
    {labels, topics, rationale}.
    """
    if classifier is not None:
        result = classifier(turns=turns, **classifier_kwargs)
        return SessionClassification(
            session_id=session_id,
            principal_id=principal_id,
            labels=list(result.get("labels", [])),
            topics=list(result.get("topics", [])),
            rationale=result.get("rationale"),
        )

    text = user_text(turns)
    return SessionClassification(
        session_id=session_id,
        principal_id=principal_id,
        labels=deterministic_labels(text),
        topics=[],  # core classifier doesn't know about domain topics
        rationale="deterministic keyword heuristics",
    )


def classify_batch(
    sessions: dict[str, list[dict]],
    classifier: Optional[LLMClassifier] = None,
    principal_id_key: str = "principal_id",
    **classifier_kwargs,
) -> list[SessionClassification]:
    """Classify many sessions in one pass.

    `sessions` is {session_id: [turns]}. Principal id is pulled from
    the first turn that has `principal_id_key` (defaults to
    "principal_id"; classroom overrides with "student_id").
    """
    results = []
    for session_id, turns in sessions.items():
        pid = ""
        for t in turns:
            if t.get(principal_id_key):
                pid = t[principal_id_key]
                break
        results.append(
            classify_session(
                turns=turns,
                session_id=session_id,
                principal_id=pid,
                classifier=classifier,
                **classifier_kwargs,
            )
        )
    return results


def annotate_traces(
    traces: list[dict],
    classifications: list[SessionClassification],
) -> list[dict]:
    """Propagate labels + topics from classifications to each trace in
    the session. Returns a new list (does not mutate input)."""
    by_session = {c.session_id: c for c in classifications}
    out = []
    for t in traces:
        sid = t.get("session_id")
        new_t = dict(t)
        c = by_session.get(sid) if sid else None
        if c:
            new_t["labels"] = list(c.labels)
            new_t["topics"] = list(c.topics)
        out.append(new_t)
    return out
