"""Tests for axiom.chat — agent addressing primitives."""
