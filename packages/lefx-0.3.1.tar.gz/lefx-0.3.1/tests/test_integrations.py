"""Tests for LEF integration utilities (LangChain and LangGraph wrappers)."""

from unittest.mock import AsyncMock, MagicMock

import pytest

from lef.integrations.langchain import (
    create_async_chain_target,
    create_chain_target,
)
from lef.integrations.langgraph import (
    create_async_graph_target,
    create_graph_target,
)


class TestCreateChainTarget:
    def test_basic_invocation(self):
        mock_chain = MagicMock()
        mock_chain.invoke.return_value = {"answer": "Paris"}

        target = create_chain_target(mock_chain)
        result = target({"question": "Capital of France?"})

        assert result == {"answer": "Paris"}
        mock_chain.invoke.assert_called_once()

    def test_with_input_mapper(self):
        mock_chain = MagicMock()
        mock_chain.invoke.return_value = {"answer": "42"}

        target = create_chain_target(
            mock_chain,
            input_mapper=lambda x: {"q": x["question"]},
        )
        target({"question": "What is 6*7?"})

        mock_chain.invoke.assert_called_once_with({"q": "What is 6*7?"}, config=None)

    def test_with_output_mapper(self):
        mock_chain = MagicMock()
        mock_chain.invoke.return_value = "raw output"

        target = create_chain_target(
            mock_chain,
            output_mapper=lambda x: {"answer": x},
        )
        result = target({"question": "test"})
        assert result == {"answer": "raw output"}

    def test_auto_convert_message_content(self):
        mock_chain = MagicMock()
        mock_result = MagicMock()
        mock_result.content = "Hello!"
        mock_chain.invoke.return_value = mock_result

        target = create_chain_target(mock_chain)
        result = target({"question": "test"})
        assert result == {"answer": "Hello!"}

    def test_auto_convert_string(self):
        mock_chain = MagicMock()
        mock_chain.invoke.return_value = "plain text"

        target = create_chain_target(mock_chain)
        result = target({"question": "test"})
        assert result == {"answer": "plain text"}

    def test_auto_convert_other(self):
        mock_chain = MagicMock()
        mock_chain.invoke.return_value = 42

        target = create_chain_target(mock_chain)
        result = target({"question": "test"})
        assert result == {"output": "42"}

    def test_with_config(self):
        mock_chain = MagicMock()
        mock_chain.invoke.return_value = {"answer": "ok"}

        target = create_chain_target(mock_chain, config={"tags": ["test"]})
        target({"question": "test"})

        mock_chain.invoke.assert_called_once_with({"question": "test"}, config={"tags": ["test"]})


class TestCreateAsyncChainTarget:
    @pytest.mark.asyncio
    async def test_basic_invocation(self):
        mock_chain = MagicMock()
        mock_chain.ainvoke = AsyncMock(return_value={"answer": "Paris"})

        target = create_async_chain_target(mock_chain)
        result = await target({"question": "Capital?"})
        assert result == {"answer": "Paris"}

    @pytest.mark.asyncio
    async def test_with_mappers(self):
        mock_chain = MagicMock()
        mock_chain.ainvoke = AsyncMock(return_value="raw")

        target = create_async_chain_target(
            mock_chain,
            input_mapper=lambda x: {"q": x["question"]},
            output_mapper=lambda x: {"answer": x},
        )
        result = await target({"question": "test"})
        assert result == {"answer": "raw"}


class TestCreateGraphTarget:
    def test_basic_invocation(self):
        mock_graph = MagicMock()
        mock_graph.invoke.return_value = {"messages": ["Hello"]}

        target = create_graph_target(mock_graph)
        result = target({"question": "test"})

        assert result == {"messages": ["Hello"]}

    def test_with_mappers(self):
        mock_graph = MagicMock()
        mock_graph.invoke.return_value = {"messages": ["response"]}

        target = create_graph_target(
            mock_graph,
            input_mapper=lambda x: {"messages": [x["question"]]},
            output_mapper=lambda x: {"answer": x["messages"][-1]},
        )
        result = target({"question": "test"})
        assert result == {"answer": "response"}


class TestCreateAsyncGraphTarget:
    @pytest.mark.asyncio
    async def test_basic_invocation(self):
        mock_graph = MagicMock()
        mock_graph.ainvoke = AsyncMock(return_value={"messages": ["Hi"]})

        target = create_async_graph_target(mock_graph)
        result = await target({"question": "test"})
        assert result == {"messages": ["Hi"]}
