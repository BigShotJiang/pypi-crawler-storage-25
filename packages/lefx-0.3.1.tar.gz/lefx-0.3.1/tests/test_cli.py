"""Tests for LEF CLI."""

import json

import pytest

from lef.cli import _load_config, _resolve_evaluator, main


class TestResolveEvaluator:
    def test_builtin_scorer(self):
        evaluator = _resolve_evaluator("exact_match")
        assert callable(evaluator)
        assert hasattr(evaluator, "key")
        assert evaluator.key == "exact_match"

    def test_builtin_scorer_contains(self):
        evaluator = _resolve_evaluator("contains")
        assert callable(evaluator)

    def test_unknown_evaluator(self):
        with pytest.raises(ValueError, match="Cannot import"):
            _resolve_evaluator("nonexistent_evaluator")

    def test_dotted_import_colon(self):
        evaluator = _resolve_evaluator("lef.scorers.builtin:exact_match")
        assert callable(evaluator)

    def test_dotted_import_dot(self):
        evaluator = _resolve_evaluator("lef.scorers.builtin.exact_match")
        assert callable(evaluator)


class TestLoadConfig:
    def test_load_json(self, tmp_path):
        config = {"dataset": "test", "evaluators": ["exact_match"]}
        path = tmp_path / "config.json"
        path.write_text(json.dumps(config))

        result = _load_config(str(path))
        assert result["dataset"] == "test"
        assert result["evaluators"] == ["exact_match"]

    def test_load_yaml(self, tmp_path):
        try:
            import yaml
        except ImportError:
            pytest.skip("PyYAML not installed")

        config = {"dataset": "test", "evaluators": ["exact_match"]}
        path = tmp_path / "config.yaml"
        path.write_text(yaml.dump(config))

        result = _load_config(str(path))
        assert result["dataset"] == "test"

    def test_unsupported_format(self, tmp_path):
        path = tmp_path / "config.txt"
        path.write_text("hello")

        with pytest.raises(ValueError, match="Config file must be"):
            _load_config(str(path))


class TestResolveJudgeFactory:
    """Verify that judge factories are properly instantiated."""

    def test_judge_factory_returns_callable(self):
        evaluator = _resolve_evaluator("correctness_judge")
        assert callable(evaluator)
        # Judge factories return the judge instance (not the factory)
        assert not hasattr(evaluator, "__name__") or evaluator.__name__ != "correctness_judge"

    def test_scorer_not_called(self):
        evaluator = _resolve_evaluator("exact_match")
        # Scorers are returned directly, not called
        assert hasattr(evaluator, "key")
        assert evaluator.key == "exact_match"


class TestMainCLI:
    def test_no_command_shows_help(self, capsys):
        result = main([])
        assert result == 2

    def test_run_missing_config(self):
        result = main(["run", "/nonexistent/config.yaml"])
        assert result == 1

    def test_malformed_threshold_no_equals(self, tmp_path):
        """CLI should handle --threshold without '=' gracefully."""
        import yaml

        config = {
            "target": "lef.scorers.builtin:exact_match",
            "dataset": "nonexistent",
            "evaluators": ["exact_match"],
        }
        config_path = tmp_path / "config.yaml"
        config_path.write_text(yaml.dump(config))

        result = main(["run", str(config_path), "--threshold", "bad_input"])
        assert result == 1  # Should fail gracefully, not crash

    def test_malformed_threshold_bad_value(self, tmp_path):
        """CLI should handle --threshold with non-numeric value."""
        import yaml

        config = {
            "target": "lef.scorers.builtin:exact_match",
            "dataset": "nonexistent",
            "evaluators": ["exact_match"],
        }
        config_path = tmp_path / "config.yaml"
        config_path.write_text(yaml.dump(config))

        result = main(["run", str(config_path), "--threshold", "key=notanumber"])
        assert result == 1
