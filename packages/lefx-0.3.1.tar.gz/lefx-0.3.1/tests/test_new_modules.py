"""Tests for LEF output.py, compare.py, and cache.py modules."""

from __future__ import annotations

import csv
import json
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from unittest.mock import patch

import pytest

from lef.cache import ResultCache
from lef.compare import (
    ComparisonReport,
    compare_results,
    delete_baseline,
    list_baselines,
    load_baseline,
    save_baseline,
)
from lef.output import (
    export_csv,
    export_json,
    export_junit_xml,
    export_markdown,
    export_results,
    format_results_table,
)

# ---------------------------------------------------------------------------
# Helpers: mock LangSmith ExperimentResults-style data
# ---------------------------------------------------------------------------


def _make_experiment_rows(*score_dicts):
    """Build a list of LangSmith ExperimentResultRow-style dicts.

    Each ``score_dicts`` entry maps metric key to score value.
    Returns dicts with ``evaluation_results`` containing ``results``.
    """
    rows = []
    for scores in score_dicts:
        results = [{"key": k, "score": v} for k, v in scores.items()]
        rows.append({"evaluation_results": {"results": results}})
    return rows


def _make_flat_results(*score_dicts):
    """Build a flat list[dict] result format (key/score dicts)."""
    flat = []
    for scores in score_dicts:
        for k, v in scores.items():
            flat.append({"key": k, "score": v})
    return flat


@pytest.fixture
def experiment_results():
    """LangSmith-style ExperimentResultRow list with two rows and two metrics."""
    return _make_experiment_rows(
        {"correctness": 0.9, "safety": 1.0},
        {"correctness": 0.8, "safety": 0.95},
    )


@pytest.fixture
def flat_results():
    """Flat list-of-dict results (key/score pairs)."""
    return _make_flat_results(
        {"correctness": 0.9},
        {"correctness": 0.8},
        {"safety": 1.0},
        {"safety": 0.95},
    )


# ===========================================================================
# Tests for output.py
# ===========================================================================


class TestFormatResultsTable:
    """Tests for format_results_table()."""

    def test_returns_table_with_metric_names(self, experiment_results):
        """Table output contains metric names from experiment-style results."""
        table = format_results_table(experiment_results)
        assert isinstance(table, str)
        assert "correctness" in table
        assert "safety" in table

    def test_contains_computed_averages(self, experiment_results):
        """Table displays correct average scores."""
        table = format_results_table(experiment_results)
        # correctness avg = (0.9 + 0.8) / 2 = 0.85
        assert "0.8500" in table
        # safety avg = (1.0 + 0.95) / 2 = 0.975
        assert "0.9750" in table

    def test_header_present(self, experiment_results):
        """Table header is included."""
        table = format_results_table(experiment_results)
        assert "LEF Evaluation Results" in table

    def test_empty_results(self):
        """Empty results produce a friendly no-data message."""
        table = format_results_table([])
        assert "No evaluation results" in table

    def test_with_flat_dict_results(self, flat_results):
        """Works with flat list[dict] format as well."""
        table = format_results_table(flat_results)
        assert "correctness" in table
        assert "safety" in table

    def test_threshold_all_pass(self, experiment_results):
        """Thresholds that are met show PASS and overall passed message."""
        table = format_results_table(
            experiment_results, thresholds={"correctness": 0.5, "safety": 0.5}
        )
        assert "PASS" in table
        assert "ALL THRESHOLDS PASSED" in table

    def test_threshold_fail(self, experiment_results):
        """Thresholds that are not met show FAIL and overall failed message."""
        table = format_results_table(experiment_results, thresholds={"correctness": 0.99})
        assert "FAIL" in table
        assert "SOME THRESHOLDS FAILED" in table

    def test_threshold_mixed(self, experiment_results):
        """Mixed pass/fail thresholds show both statuses."""
        # safety avg=0.975 >= 0.9 (pass), correctness avg=0.85 < 0.9 (fail)
        table = format_results_table(
            experiment_results, thresholds={"correctness": 0.9, "safety": 0.9}
        )
        assert "PASS" in table
        assert "FAIL" in table
        assert "SOME THRESHOLDS FAILED" in table


class TestExportJson:
    """Tests for export_json()."""

    def test_writes_valid_json_with_summary_and_rows(self, tmp_path, experiment_results):
        """Exported JSON is valid and contains summary, rows, and metadata."""
        out = tmp_path / "results.json"
        export_json(experiment_results, out)

        data = json.loads(out.read_text())
        assert "summary" in data
        assert "rows" in data
        assert "metadata" in data
        assert isinstance(data["summary"], dict)
        assert isinstance(data["rows"], list)

    def test_summary_contains_correct_averages(self, tmp_path, experiment_results):
        """Summary averages match expected values."""
        out = tmp_path / "results.json"
        export_json(experiment_results, out)

        data = json.loads(out.read_text())
        assert pytest.approx(data["summary"]["correctness"], abs=1e-4) == 0.85
        assert pytest.approx(data["summary"]["safety"], abs=1e-4) == 0.975

    def test_rows_populated(self, tmp_path, experiment_results):
        """Per-row data is included in the export."""
        out = tmp_path / "results.json"
        export_json(experiment_results, out)

        data = json.loads(out.read_text())
        assert len(data["rows"]) == 2

    def test_metadata_stored(self, tmp_path, experiment_results):
        """Custom metadata is preserved in the export."""
        out = tmp_path / "results.json"
        export_json(experiment_results, out, metadata={"run_id": "abc123"})

        data = json.loads(out.read_text())
        assert data["metadata"]["run_id"] == "abc123"

    def test_default_empty_metadata(self, tmp_path, experiment_results):
        """When no metadata is given, an empty dict is stored."""
        out = tmp_path / "results.json"
        export_json(experiment_results, out)

        data = json.loads(out.read_text())
        assert data["metadata"] == {}

    def test_creates_parent_directories(self, tmp_path, experiment_results):
        """Parent directories are created automatically."""
        out = tmp_path / "deep" / "nested" / "results.json"
        export_json(experiment_results, out)
        assert out.exists()


class TestExportCsv:
    """Tests for export_csv()."""

    def test_writes_valid_csv_with_headers(self, tmp_path, experiment_results):
        """Exported CSV has correct headers and data rows."""
        out = tmp_path / "results.csv"
        export_csv(experiment_results, out)

        with open(out) as f:
            reader = csv.reader(f)
            rows = list(reader)

        header = rows[0]
        assert header[0] == "example_id"
        assert "correctness" in header
        assert "safety" in header
        # 2 experiment rows -> 2 data rows + 1 header
        assert len(rows) == 3

    def test_score_values_present(self, tmp_path, experiment_results):
        """Score values appear in the CSV output."""
        out = tmp_path / "results.csv"
        export_csv(experiment_results, out)

        text = out.read_text()
        assert "0.9" in text

    def test_empty_results_no_file(self, tmp_path):
        """Empty results do not create a CSV file."""
        out = tmp_path / "empty.csv"
        export_csv([], out)
        assert not out.exists()

    def test_single_metric(self, tmp_path):
        """Works correctly with a single metric."""
        results = _make_experiment_rows({"accuracy": 0.77})
        out = tmp_path / "results.csv"
        export_csv(results, out)

        with open(out) as f:
            reader = csv.reader(f)
            rows = list(reader)

        assert rows[0] == ["example_id", "accuracy"]
        assert rows[1][1] == "0.77"


class TestExportJunitXml:
    """Tests for export_junit_xml()."""

    def test_writes_valid_xml(self, tmp_path, experiment_results):
        """Exported XML is well-formed with a testsuite root element."""
        out = tmp_path / "results.xml"
        export_junit_xml(experiment_results, out)

        tree = ET.parse(out)
        root = tree.getroot()
        assert root.tag == "testsuite"
        assert root.attrib["name"] == "lef-evaluation"

    def test_testcases_per_metric(self, tmp_path, experiment_results):
        """Each metric key becomes a testcase element."""
        out = tmp_path / "results.xml"
        export_junit_xml(experiment_results, out)

        tree = ET.parse(out)
        root = tree.getroot()
        testcases = root.findall("testcase")
        names = {tc.attrib["name"] for tc in testcases}
        assert names == {"correctness", "safety"}

    def test_failure_on_threshold_breach(self, tmp_path, experiment_results):
        """Testcase has <failure> child when average is below threshold."""
        out = tmp_path / "results.xml"
        export_junit_xml(experiment_results, out, thresholds={"correctness": 0.99})

        tree = ET.parse(out)
        root = tree.getroot()
        assert root.attrib["failures"] == "1"

        tc = root.find("testcase[@name='correctness']")
        failure = tc.find("failure")
        assert failure is not None
        assert failure.attrib["type"] == "ThresholdFailure"
        assert "correctness" in failure.attrib["message"]

    def test_pass_when_above_threshold(self, tmp_path, experiment_results):
        """No <failure> child when score meets threshold."""
        out = tmp_path / "results.xml"
        export_junit_xml(experiment_results, out, thresholds={"correctness": 0.5})

        tree = ET.parse(out)
        root = tree.getroot()
        assert root.attrib["failures"] == "0"

        tc = root.find("testcase[@name='correctness']")
        assert tc.find("failure") is None

    def test_custom_suite_name(self, tmp_path, experiment_results):
        """Custom suite_name attribute is set on the testsuite element."""
        out = tmp_path / "results.xml"
        export_junit_xml(experiment_results, out, suite_name="my-suite")

        tree = ET.parse(out)
        assert tree.getroot().attrib["name"] == "my-suite"

    def test_properties_contain_scores(self, tmp_path, experiment_results):
        """Testcase properties include average_score and sample_count."""
        out = tmp_path / "results.xml"
        export_junit_xml(experiment_results, out)

        tree = ET.parse(out)
        tc = tree.getroot().find("testcase[@name='correctness']")
        props = {
            p.attrib["name"]: p.attrib["value"] for p in tc.find("properties").findall("property")
        }
        assert props["average_score"] == "0.8500"
        assert props["sample_count"] == "2"


class TestExportResults:
    """Tests for export_results() auto-detection from file extension."""

    def test_auto_detect_json(self, tmp_path, experiment_results):
        """Detects .json extension and exports JSON."""
        out = tmp_path / "out.json"
        export_results(experiment_results, out)
        data = json.loads(out.read_text())
        assert "summary" in data

    def test_auto_detect_csv(self, tmp_path, experiment_results):
        """Detects .csv extension and exports CSV."""
        out = tmp_path / "out.csv"
        export_results(experiment_results, out)
        assert out.exists()
        assert "example_id" in out.read_text()

    def test_auto_detect_xml(self, tmp_path, experiment_results):
        """Detects .xml extension and exports JUnit XML."""
        out = tmp_path / "out.xml"
        export_results(experiment_results, out)
        tree = ET.parse(out)
        assert tree.getroot().tag == "testsuite"

    def test_json_with_metadata(self, tmp_path, experiment_results):
        """Metadata is passed through to JSON export."""
        out = tmp_path / "out.json"
        export_results(experiment_results, out, metadata={"env": "ci"})
        data = json.loads(out.read_text())
        assert data["metadata"]["env"] == "ci"

    def test_xml_with_thresholds(self, tmp_path, experiment_results):
        """Thresholds are passed through to JUnit XML export."""
        out = tmp_path / "out.xml"
        export_results(experiment_results, out, thresholds={"correctness": 0.99})
        tree = ET.parse(out)
        assert tree.getroot().attrib["failures"] == "1"

    def test_auto_detect_markdown(self, tmp_path, experiment_results):
        """Detects .md extension and exports Markdown."""
        out = tmp_path / "out.md"
        export_results(experiment_results, out)
        content = out.read_text()
        assert "# LEF Evaluation Report" in content

    def test_unsupported_extension_raises(self, tmp_path, experiment_results):
        """Unsupported file extension raises ValueError."""
        with pytest.raises(ValueError, match="Unsupported output format"):
            export_results(experiment_results, tmp_path / "out.txt")


# ===========================================================================
# Tests for output.py — export_markdown
# ===========================================================================


class TestExportMarkdown:
    """Tests for export_markdown() Markdown report generation."""

    def test_basic_markdown(self, tmp_path, experiment_results):
        """Generates valid Markdown with header and table."""
        out = tmp_path / "report.md"
        export_markdown(experiment_results, out)
        content = out.read_text()
        assert "# LEF Evaluation Report" in content
        assert "## Summary" in content
        assert "| Metric |" in content
        assert "correctness" in content

    def test_markdown_with_thresholds(self, tmp_path, experiment_results):
        """Thresholds add Status column and verdict."""
        out = tmp_path / "report.md"
        export_markdown(experiment_results, out, thresholds={"correctness": 0.5})
        content = out.read_text()
        assert "Threshold" in content
        assert "PASS" in content

    def test_markdown_threshold_fail(self, tmp_path, experiment_results):
        """Failing threshold shows FAIL status."""
        out = tmp_path / "report.md"
        export_markdown(experiment_results, out, thresholds={"correctness": 0.99})
        content = out.read_text()
        assert "FAIL" in content
        assert "SOME THRESHOLDS FAILED" in content

    def test_markdown_with_metadata(self, tmp_path, experiment_results):
        """Metadata appears in the report header."""
        out = tmp_path / "report.md"
        export_markdown(experiment_results, out, metadata={"env": "staging", "version": "1.0"})
        content = out.read_text()
        assert "**env**: staging" in content
        assert "**version**: 1.0" in content

    def test_markdown_per_example_table(self, tmp_path, experiment_results):
        """Per-example results table is included."""
        out = tmp_path / "report.md"
        export_markdown(experiment_results, out)
        content = out.read_text()
        assert "## Per-Example Results" in content

    def test_markdown_empty_results(self, tmp_path):
        """Empty results produce a minimal report."""
        out = tmp_path / "report.md"
        export_markdown([], out)
        content = out.read_text()
        assert "No evaluation results" in content

    def test_markdown_creates_parent_dirs(self, tmp_path, experiment_results):
        """Parent directories are created if they don't exist."""
        out = tmp_path / "deep" / "nested" / "report.md"
        export_markdown(experiment_results, out)
        assert out.exists()


# ===========================================================================
# Tests for compare.py
# ===========================================================================


class TestBaselineSaveAndLoad:
    """Tests for save_baseline() / load_baseline() round-trip."""

    def test_save_and_load_round_trip(self, tmp_path, flat_results):
        """Saved baseline can be loaded back with matching data."""
        path = save_baseline("v1", flat_results, baselines_dir=tmp_path)
        assert path.exists()

        loaded = load_baseline("v1", baselines_dir=tmp_path)
        assert loaded["name"] == "v1"
        assert "summary" in loaded
        assert pytest.approx(loaded["summary"]["correctness"], abs=1e-4) == 0.85

    def test_save_with_metadata(self, tmp_path, flat_results):
        """Metadata is preserved through save/load cycle."""
        save_baseline("meta", flat_results, metadata={"branch": "main"}, baselines_dir=tmp_path)
        loaded = load_baseline("meta", baselines_dir=tmp_path)
        assert loaded["metadata"]["branch"] == "main"

    def test_load_nonexistent_raises(self, tmp_path):
        """Loading a missing baseline raises FileNotFoundError."""
        with pytest.raises(FileNotFoundError):
            load_baseline("nonexistent", baselines_dir=tmp_path)

    def test_save_returns_path_object(self, tmp_path, flat_results):
        """save_baseline returns a Path pointing to the baseline file."""
        path = save_baseline("test", flat_results, baselines_dir=tmp_path)
        assert isinstance(path, Path)
        assert path.suffix == ".json"

    def test_save_overwrites_existing(self, tmp_path):
        """Re-saving with the same name overwrites the previous baseline."""
        save_baseline("x", _make_flat_results({"m": 0.5}), baselines_dir=tmp_path)
        save_baseline("x", _make_flat_results({"m": 0.9}), baselines_dir=tmp_path)

        loaded = load_baseline("x", baselines_dir=tmp_path)
        assert pytest.approx(loaded["summary"]["m"], abs=1e-9) == 0.9

    def test_per_key_scores_stored(self, tmp_path, flat_results):
        """per_key_scores field contains raw score lists."""
        save_baseline("pks", flat_results, baselines_dir=tmp_path)
        loaded = load_baseline("pks", baselines_dir=tmp_path)
        assert "per_key_scores" in loaded
        assert "correctness" in loaded["per_key_scores"]


class TestListBaselines:
    """Tests for list_baselines()."""

    def test_empty_directory(self, tmp_path):
        """Empty directory returns empty list."""
        assert list_baselines(baselines_dir=tmp_path) == []

    def test_nonexistent_directory(self, tmp_path):
        """Non-existent directory returns empty list."""
        assert list_baselines(baselines_dir=tmp_path / "nope") == []

    def test_returns_saved_baselines(self, tmp_path):
        """Lists all saved baselines with name, path, and summary."""
        save_baseline("alpha", _make_flat_results({"m": 0.8}), baselines_dir=tmp_path)
        save_baseline("beta", _make_flat_results({"m": 0.9}), baselines_dir=tmp_path)

        baselines = list_baselines(baselines_dir=tmp_path)
        names = {b["name"] for b in baselines}
        assert names == {"alpha", "beta"}
        assert len(baselines) == 2

        for b in baselines:
            assert "name" in b
            assert "path" in b
            assert "summary" in b

    def test_summary_scores_in_listing(self, tmp_path):
        """Each listed baseline includes its summary scores."""
        save_baseline("x", _make_flat_results({"acc": 0.77}), baselines_dir=tmp_path)
        baselines = list_baselines(baselines_dir=tmp_path)
        assert pytest.approx(baselines[0]["summary"]["acc"], abs=1e-4) == 0.77


class TestDeleteBaseline:
    """Tests for delete_baseline()."""

    def test_delete_existing(self, tmp_path):
        """Deleting an existing baseline returns True and removes the file."""
        save_baseline("todel", _make_flat_results({"m": 1.0}), baselines_dir=tmp_path)
        assert delete_baseline("todel", baselines_dir=tmp_path) is True
        assert not (tmp_path / "todel.json").exists()
        assert list_baselines(baselines_dir=tmp_path) == []

    def test_delete_nonexistent(self, tmp_path):
        """Deleting a nonexistent baseline returns False."""
        assert delete_baseline("nope", baselines_dir=tmp_path) is False


class TestCompareResults:
    """Tests for compare_results()."""

    def test_stable_scores(self):
        """Identical scores produce stable status with no regressions."""
        current = _make_flat_results({"accuracy": 0.85})
        baseline = _make_flat_results({"accuracy": 0.85})
        report = compare_results(current, baseline)

        assert not report.has_regressions
        assert len(report.regressions) == 0
        assert len(report.improvements) == 0
        assert report.diffs[0]["status"] == "stable"

    def test_regression_detected(self):
        """Lower current score is flagged as regression."""
        current = _make_flat_results({"accuracy": 0.7})
        baseline = _make_flat_results({"accuracy": 0.9})
        report = compare_results(current, baseline)

        assert report.has_regressions is True
        assert len(report.regressions) == 1
        assert report.regressions[0]["key"] == "accuracy"
        assert report.regressions[0]["delta"] < 0
        assert report.regressions[0]["status"] == "regression"

    def test_improvement_detected(self):
        """Higher current score is flagged as improvement."""
        current = _make_flat_results({"accuracy": 0.95})
        baseline = _make_flat_results({"accuracy": 0.7})
        report = compare_results(current, baseline)

        assert not report.has_regressions
        assert len(report.improvements) == 1
        assert report.improvements[0]["key"] == "accuracy"
        assert report.improvements[0]["status"] == "improvement"

    def test_new_metric(self):
        """A metric only in current is flagged as 'new'."""
        current = _make_flat_results({"old": 0.8, "new_metric": 0.9})
        baseline = _make_flat_results({"old": 0.8})
        report = compare_results(current, baseline)

        new_diffs = [d for d in report.diffs if d["status"] == "new"]
        assert len(new_diffs) == 1
        assert new_diffs[0]["key"] == "new_metric"
        assert new_diffs[0]["current"] == 0.9
        assert new_diffs[0]["baseline"] is None

    def test_removed_metric(self):
        """A metric only in baseline is flagged as 'removed'."""
        current = _make_flat_results({"m": 0.8})
        baseline = _make_flat_results({"m": 0.8, "old_metric": 0.7})
        report = compare_results(current, baseline)

        removed = [d for d in report.diffs if d["status"] == "removed"]
        assert len(removed) == 1
        assert removed[0]["key"] == "old_metric"
        assert removed[0]["current"] is None
        assert removed[0]["baseline"] == 0.7

    def test_tolerance_suppresses_small_regression(self):
        """A score drop within tolerance is classified as stable."""
        current = _make_flat_results({"accuracy": 0.84})
        baseline = _make_flat_results({"accuracy": 0.85})
        report = compare_results(current, baseline, tolerance=0.02)

        assert not report.has_regressions
        assert report.diffs[0]["status"] == "stable"

    def test_tolerance_does_not_suppress_large_regression(self):
        """A score drop exceeding tolerance is still flagged."""
        current = _make_flat_results({"accuracy": 0.7})
        baseline = _make_flat_results({"accuracy": 0.9})
        report = compare_results(current, baseline, tolerance=0.05)

        assert report.has_regressions

    def test_with_baseline_dict_summary_key(self):
        """Accepts a baseline dict with 'summary' key (from load_baseline)."""
        current = _make_flat_results({"accuracy": 0.6})
        baseline_dict = {
            "name": "v1",
            "summary": {"accuracy": 0.9},
            "per_key_scores": {"accuracy": [0.9]},
            "metadata": {},
        }
        report = compare_results(current, baseline_dict)
        assert report.has_regressions
        assert report.regressions[0]["key"] == "accuracy"

    def test_with_current_dict_summary_key(self):
        """Accepts current as a dict with 'summary' key."""
        current_dict = {"summary": {"accuracy": 0.5}}
        baseline = _make_flat_results({"accuracy": 0.9})
        report = compare_results(current_dict, baseline)
        assert report.has_regressions

    def test_multiple_metrics_mixed(self):
        """Mixed improvement, regression, and stable across metrics."""
        current = _make_flat_results({"accuracy": 0.95, "safety": 0.5, "fluency": 0.8})
        baseline = _make_flat_results({"accuracy": 0.8, "safety": 0.9, "fluency": 0.8})
        report = compare_results(current, baseline)

        statuses = {d["key"]: d["status"] for d in report.diffs}
        assert statuses["accuracy"] == "improvement"
        assert statuses["safety"] == "regression"
        assert statuses["fluency"] == "stable"
        assert report.has_regressions
        assert len(report.regressions) == 1
        assert len(report.improvements) == 1

    def test_new_and_removed_together(self):
        """Both new and removed metrics appear in a single comparison."""
        current = _make_flat_results({"new_metric": 0.9})
        baseline_dict = {"summary": {"old_metric": 0.8}}
        report = compare_results(current, baseline_dict)

        statuses = {d["key"]: d["status"] for d in report.diffs}
        assert statuses["new_metric"] == "new"
        assert statuses["old_metric"] == "removed"


class TestComparisonReportFormatTable:
    """Tests for ComparisonReport.format_table()."""

    def test_format_table_produces_output(self):
        """format_table() returns a non-empty string with header."""
        report = ComparisonReport(
            diffs=[
                {
                    "key": "m",
                    "current": 0.9,
                    "baseline": 0.7,
                    "delta": 0.2,
                    "status": "improvement",
                }
            ],
            regressions=[],
            improvements=[
                {
                    "key": "m",
                    "current": 0.9,
                    "baseline": 0.7,
                    "delta": 0.2,
                    "status": "improvement",
                }
            ],
            has_regressions=False,
        )
        table = report.format_table()
        assert "LEF Comparison Report" in table
        assert "m" in table
        assert "IMPROVEMENT" in table.upper()
        assert "PASS (no regressions)" in table

    def test_format_table_shows_regressions(self):
        """Regression section and FAIL appear when regressions exist."""
        report = ComparisonReport(
            diffs=[
                {
                    "key": "safety",
                    "current": 0.5,
                    "baseline": 0.9,
                    "delta": -0.4,
                    "status": "regression",
                }
            ],
            regressions=[
                {
                    "key": "safety",
                    "current": 0.5,
                    "baseline": 0.9,
                    "delta": -0.4,
                    "status": "regression",
                }
            ],
            improvements=[],
            has_regressions=True,
        )
        table = report.format_table()
        assert "REGRESSIONS:" in table
        assert "FAIL (regressions detected)" in table

    def test_format_table_new_and_removed(self):
        """New and removed metrics display N/A values."""
        report = ComparisonReport(
            diffs=[
                {"key": "new_m", "current": 0.8, "baseline": None, "delta": None, "status": "new"},
                {
                    "key": "old_m",
                    "current": None,
                    "baseline": 0.7,
                    "delta": None,
                    "status": "removed",
                },
            ],
            regressions=[],
            improvements=[],
            has_regressions=False,
        )
        table = report.format_table()
        assert "N/A" in table
        assert "new_m" in table
        assert "old_m" in table

    def test_to_dict(self):
        """to_dict() returns serializable representation."""
        report = ComparisonReport(
            diffs=[{"key": "x", "current": 1.0, "baseline": 1.0, "delta": 0.0, "status": "stable"}],
            regressions=[],
            improvements=[],
            has_regressions=False,
        )
        d = report.to_dict()
        assert "diffs" in d
        assert "has_regressions" in d
        assert d["has_regressions"] is False


# ===========================================================================
# Tests for cache.py
# ===========================================================================


class TestResultCacheWrap:
    """Tests for ResultCache.wrap() synchronous caching."""

    def test_cache_miss_then_hit(self, tmp_path):
        """First call is a miss (calls target), second is a hit (cached)."""
        call_count = 0

        def target(inputs):
            nonlocal call_count
            call_count += 1
            return {"answer": inputs["q"].upper()}

        cache = ResultCache(cache_dir=tmp_path / "cache")
        cached = cache.wrap(target)

        result1 = cached({"q": "hello"})
        assert result1 == {"answer": "HELLO"}
        assert call_count == 1

        result2 = cached({"q": "hello"})
        assert result2 == {"answer": "HELLO"}
        assert call_count == 1  # target NOT called again

    def test_different_inputs_separate_entries(self, tmp_path):
        """Different inputs produce separate cache entries."""
        call_count = 0

        def target(inputs):
            nonlocal call_count
            call_count += 1
            return {"echo": inputs["val"]}

        cache = ResultCache(cache_dir=tmp_path / "cache")
        cached = cache.wrap(target)

        r1 = cached({"val": "a"})
        r2 = cached({"val": "b"})
        assert r1 != r2
        assert call_count == 2

        # Both should now be hits
        cached({"val": "a"})
        cached({"val": "b"})
        assert call_count == 2

    def test_wrapped_function_name(self, tmp_path):
        """Wrapped function has a descriptive __name__."""

        def my_func(inputs):
            return inputs

        cache = ResultCache(cache_dir=tmp_path / "cache")
        cached = cache.wrap(my_func)
        assert cached.__name__ == "cached_my_func"
        assert cached.__wrapped__ is my_func

    def test_kwargs_passed_through(self, tmp_path):
        """Extra kwargs are forwarded to the original target."""
        received_kwargs = {}

        def target(inputs, **kwargs):
            received_kwargs.update(kwargs)
            return inputs

        cache = ResultCache(cache_dir=tmp_path / "cache")
        cached = cache.wrap(target)
        cached({"x": 1}, extra="value")
        assert received_kwargs["extra"] == "value"


class TestResultCacheWrapAsync:
    """Tests for ResultCache.wrap_async() async caching."""

    async def test_async_cache_miss_then_hit(self, tmp_path):
        """Async wrapper caches results the same as sync."""
        call_count = 0

        async def target(inputs):
            nonlocal call_count
            call_count += 1
            return {"val": 42}

        cache = ResultCache(cache_dir=tmp_path / "cache")
        cached = cache.wrap_async(target)

        out1 = await cached({"q": "test"})
        assert out1 == {"val": 42}
        assert call_count == 1

        out2 = await cached({"q": "test"})
        assert out2 == {"val": 42}
        assert call_count == 1  # hit

    async def test_async_different_inputs(self, tmp_path):
        """Async wrapper distinguishes different inputs."""
        call_count = 0

        async def target(inputs):
            nonlocal call_count
            call_count += 1
            return inputs

        cache = ResultCache(cache_dir=tmp_path / "cache")
        cached = cache.wrap_async(target)

        await cached({"a": 1})
        await cached({"b": 2})
        assert call_count == 2

        # Repeat: both hits
        await cached({"a": 1})
        await cached({"b": 2})
        assert call_count == 2

    async def test_async_wrapped_name(self, tmp_path):
        """Async wrapped function has descriptive __name__."""

        async def my_async_fn(inputs):
            return inputs

        cache = ResultCache(cache_dir=tmp_path / "cache")
        cached = cache.wrap_async(my_async_fn)
        assert cached.__name__ == "cached_my_async_fn"
        assert cached.__wrapped__ is my_async_fn

    async def test_async_stats_tracked(self, tmp_path):
        """Async hits and misses are correctly tracked in stats."""

        async def target(inputs):
            return "ok"

        cache = ResultCache(cache_dir=tmp_path / "cache")
        cached = cache.wrap_async(target)

        await cached({"x": 1})  # miss
        await cached({"x": 1})  # hit

        assert cache.stats == {"hits": 1, "misses": 1}


class TestResultCacheClear:
    """Tests for ResultCache.clear()."""

    def test_clear_removes_entries(self, tmp_path):
        """clear() removes cached files and returns count."""

        def target(inputs):
            return inputs

        cache = ResultCache(cache_dir=tmp_path / "cache")
        cached = cache.wrap(target)
        cached({"x": 1})
        cached({"x": 2})

        count = cache.clear()
        assert count == 2
        assert list((tmp_path / "cache").glob("*.json")) == []

    def test_clear_empty_cache(self, tmp_path):
        """Clearing a non-existent cache directory returns 0."""
        cache = ResultCache(cache_dir=tmp_path / "nonexistent")
        assert cache.clear() == 0

    def test_clear_resets_ability_to_cache(self, tmp_path):
        """After clear, previously cached inputs are treated as misses."""
        call_count = 0

        def target(inputs):
            nonlocal call_count
            call_count += 1
            return "result"

        cache = ResultCache(cache_dir=tmp_path / "cache")
        cached = cache.wrap(target)

        cached({"q": "test"})
        assert call_count == 1

        cache.clear()

        cached({"q": "test"})
        assert call_count == 2  # miss again after clear


class TestResultCacheStats:
    """Tests for ResultCache.stats property."""

    def test_initial_stats(self, tmp_path):
        """Fresh cache has zero hits and misses."""
        cache = ResultCache(cache_dir=tmp_path / "cache")
        assert cache.stats == {"hits": 0, "misses": 0}

    def test_stats_after_usage(self, tmp_path):
        """Stats correctly count hits and misses."""

        def target(inputs):
            return inputs

        cache = ResultCache(cache_dir=tmp_path / "cache")
        cached = cache.wrap(target)

        cached({"a": 1})  # miss
        cached({"b": 2})  # miss
        cached({"a": 1})  # hit
        cached({"a": 1})  # hit

        assert cache.stats == {"hits": 2, "misses": 2}


class TestResultCacheTTL:
    """Tests for TTL expiration in ResultCache."""

    def test_ttl_expiration(self, tmp_path):
        """Expired cache entries are treated as misses."""
        call_count = 0

        def target(inputs):
            nonlocal call_count
            call_count += 1
            return "result"

        cache = ResultCache(cache_dir=tmp_path / "cache", ttl_seconds=1)
        cached = cache.wrap(target)

        # First call: miss
        cached({"q": "test"})
        assert call_count == 1

        # Patch time to simulate expiry
        with patch("lef.cache.time") as mock_time:
            mock_time.time.return_value = time.time() + 1000
            cached({"q": "test"})
            assert call_count == 2  # expired -> miss -> calls target

    def test_ttl_not_expired(self, tmp_path):
        """Non-expired cache entries remain as hits."""
        call_count = 0

        def target(inputs):
            nonlocal call_count
            call_count += 1
            return "result"

        cache = ResultCache(cache_dir=tmp_path / "cache", ttl_seconds=3600)
        cached = cache.wrap(target)

        cached({"q": "test"})
        assert call_count == 1

        cached({"q": "test"})
        assert call_count == 1  # still valid -> hit

    def test_ttl_zero_always_expires(self, tmp_path):
        """TTL of 0 means entries expire immediately on next read."""
        call_count = 0

        def target(inputs):
            nonlocal call_count
            call_count += 1
            return {"v": call_count}

        cache = ResultCache(cache_dir=tmp_path / "cache", ttl_seconds=0)
        cached = cache.wrap(target)

        cached({"q": "test"})
        cached({"q": "test"})

        assert call_count == 2
        assert cache.stats["misses"] == 2
        assert cache.stats["hits"] == 0
