"""Tests for LEF core module: types, base classes, and decorators."""

import pytest

from lef.core.base import BaseEvaluator
from lef.core.decorators import _normalize_result, evaluator, scorer
from lef.core.types import EvalResult, EvalResultBatch, JudgeModel


class TestEvalResult:
    def test_basic_creation(self):
        result = EvalResult(key="test", score=0.8)
        assert result.key == "test"
        assert result.score == 0.8
        assert result.comment is None
        assert result.metadata == {}

    def test_bool_score(self):
        result = EvalResult(key="test", score=True)
        assert result.score is True

    def test_with_metadata(self):
        result = EvalResult(key="test", score=0.5, metadata={"detail": "info"})
        assert result.metadata["detail"] == "info"


class TestEvalResultBatch:
    def test_summary(self):
        batch = EvalResultBatch(
            results=[
                EvalResult(key="accuracy", score=1.0),
                EvalResult(key="accuracy", score=0.5),
                EvalResult(key="speed", score=0.8),
            ]
        )
        summary = batch.summary
        assert summary["accuracy"] == 0.75
        assert summary["speed"] == 0.8

    def test_empty_summary(self):
        batch = EvalResultBatch()
        assert batch.summary == {}

    def test_bool_scores_in_summary(self):
        batch = EvalResultBatch(
            results=[
                EvalResult(key="pass", score=True),
                EvalResult(key="pass", score=False),
            ]
        )
        assert batch.summary["pass"] == 0.5


class TestJudgeModel:
    def test_str_conversion(self):
        assert str(JudgeModel.GPT_4O) == "openai:gpt-4o"
        assert str(JudgeModel.CLAUDE_SONNET) == "anthropic:claude-sonnet-4-20250514"


class TestBaseEvaluator:
    def test_subclass(self, sample_inputs, sample_outputs, sample_reference_outputs):
        class MyEvaluator(BaseEvaluator):
            key = "test_eval"

            def evaluate(self, *, inputs, outputs, reference_outputs=None, **kwargs):
                match = outputs.get("answer") == (reference_outputs or {}).get("answer")
                return EvalResult(key=self.key, score=match)

        ev = MyEvaluator()
        result = ev(
            inputs=sample_inputs, outputs=sample_outputs, reference_outputs=sample_reference_outputs
        )
        assert result.score is True
        assert result.key == "test_eval"

    def test_wrong_answer(self, sample_inputs, wrong_outputs, sample_reference_outputs):
        class MyEvaluator(BaseEvaluator):
            key = "test_eval"

            def evaluate(self, *, inputs, outputs, reference_outputs=None, **kwargs):
                match = outputs.get("answer") == (reference_outputs or {}).get("answer")
                return EvalResult(key=self.key, score=match)

        ev = MyEvaluator()
        result = ev(
            inputs=sample_inputs, outputs=wrong_outputs, reference_outputs=sample_reference_outputs
        )
        assert result.score is False


class TestScorerDecorator:
    def test_basic_scorer(self, sample_inputs, sample_outputs, sample_reference_outputs):
        @scorer(key="my_score")
        def my_scorer(*, inputs, outputs, reference_outputs=None, **kwargs):
            return outputs.get("answer") == (reference_outputs or {}).get("answer")

        result = my_scorer(
            inputs=sample_inputs,
            outputs=sample_outputs,
            reference_outputs=sample_reference_outputs,
        )
        assert isinstance(result, EvalResult)
        assert result.key == "my_score"
        assert result.score == 1.0

    def test_scorer_returns_float(self, sample_inputs, sample_outputs):
        @scorer(key="float_score")
        def my_scorer(*, inputs, outputs, **kwargs):
            return 0.75

        result = my_scorer(inputs=sample_inputs, outputs=sample_outputs)
        assert result.score == 0.75

    def test_scorer_returns_eval_result(self, sample_inputs, sample_outputs):
        @scorer(key="full_result")
        def my_scorer(*, inputs, outputs, **kwargs):
            return EvalResult(key="custom", score=0.9, comment="good")

        result = my_scorer(inputs=sample_inputs, outputs=sample_outputs)
        assert result.key == "custom"  # Preserved from EvalResult
        assert result.score == 0.9

    def test_scorer_default_key(self, sample_inputs, sample_outputs):
        @scorer()
        def my_function_name(*, inputs, outputs, **kwargs):
            return True

        assert my_function_name.key == "my_function_name"

    def test_evaluator_alias(self, sample_inputs, sample_outputs):
        @evaluator(key="alias_test")
        def my_eval(*, inputs, outputs, **kwargs):
            return True

        result = my_eval(inputs=sample_inputs, outputs=sample_outputs)
        assert result.key == "alias_test"


class TestNormalizeResult:
    def test_bool_true(self):
        result = _normalize_result(True, "test")
        assert result.score == 1.0

    def test_bool_false(self):
        result = _normalize_result(False, "test")
        assert result.score == 0.0

    def test_float(self):
        result = _normalize_result(0.5, "test")
        assert result.score == 0.5

    def test_dict(self):
        result = _normalize_result({"score": 0.7, "comment": "ok"}, "test")
        assert result.score == 0.7
        assert result.comment == "ok"

    def test_eval_result_passthrough(self):
        er = EvalResult(key="original", score=1.0)
        result = _normalize_result(er, "test")
        assert result.key == "original"

    def test_unsupported_type(self):
        with pytest.raises(TypeError, match="unsupported type"):
            _normalize_result([1, 2, 3], "test")
