"""Extended tests for online evaluation: aevaluate_recent and create_rule_config alias."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from lef.online.tracing import OnlineEvaluator, create_rule, create_rule_config


class TestCreateRuleConfigAlias:
    """Tests that create_rule is an alias for create_rule_config."""

    def test_alias_is_same_function(self):
        assert create_rule is create_rule_config

    def test_create_rule_config_returns_dict(self):
        evaluator = MagicMock()
        result = create_rule_config(
            name="test-rule",
            evaluator=evaluator,
            project_name="my-project",
            sampling_rate=0.5,
        )
        assert isinstance(result, dict)
        assert result["name"] == "test-rule"
        assert result["evaluator"] is evaluator
        assert result["project_name"] == "my-project"
        assert result["sampling_rate"] == 0.5

    def test_create_rule_config_defaults(self):
        evaluator = MagicMock()
        result = create_rule_config(name="rule", evaluator=evaluator)
        assert result["sampling_rate"] == 1.0
        assert result["project_name"] is None

    def test_alias_call_matches(self):
        evaluator = MagicMock()
        r1 = create_rule(name="r", evaluator=evaluator, sampling_rate=0.3)
        r2 = create_rule_config(name="r", evaluator=evaluator, sampling_rate=0.3)
        assert r1 == r2


class TestOnlineEvaluatorAevaluateRecent:
    """Tests for OnlineEvaluator.aevaluate_recent."""

    @patch("lef.online.tracing.evaluate_run")
    @patch("lef.online.tracing.Client")
    async def test_aevaluate_recent_basic(self, mock_client_cls, mock_eval_run):
        client = MagicMock()
        mock_client_cls.return_value = client

        run1 = MagicMock()
        run1.id = "run-1"
        run2 = MagicMock()
        run2.id = "run-2"
        client.list_runs.return_value = [run1, run2]

        mock_eval_run.return_value = [{"key": "safety", "score": 1.0}]

        online = OnlineEvaluator(project_name="my-project")
        online.add_evaluator(MagicMock())

        results = await online.aevaluate_recent(limit=5)

        assert len(results) == 2
        assert results[0] == [{"key": "safety", "score": 1.0}]
        client.list_runs.assert_called_once_with(
            project_name="my-project",
            limit=5,
            run_type=None,
        )

    @patch("lef.online.tracing.evaluate_run")
    @patch("lef.online.tracing.Client")
    async def test_aevaluate_recent_with_run_type(self, mock_client_cls, mock_eval_run):
        client = MagicMock()
        mock_client_cls.return_value = client
        client.list_runs.return_value = []

        online = OnlineEvaluator(project_name="proj")
        online.add_evaluator(MagicMock())

        await online.aevaluate_recent(limit=10, run_type="chain")

        client.list_runs.assert_called_once_with(
            project_name="proj",
            limit=10,
            run_type="chain",
        )

    @patch("lef.online.tracing.evaluate_run")
    @patch("lef.online.tracing.Client")
    async def test_aevaluate_recent_empty_runs(self, mock_client_cls, mock_eval_run):
        client = MagicMock()
        mock_client_cls.return_value = client
        client.list_runs.return_value = []

        online = OnlineEvaluator(project_name="proj")
        online.add_evaluator(MagicMock())

        results = await online.aevaluate_recent(limit=5)
        assert results == []
        mock_eval_run.assert_not_called()

    @patch("lef.online.tracing.evaluate_run")
    @patch("lef.online.tracing.Client")
    async def test_aevaluate_recent_max_concurrency(self, mock_client_cls, mock_eval_run):
        """aevaluate_recent should accept max_concurrency parameter."""
        client = MagicMock()
        mock_client_cls.return_value = client

        runs = [MagicMock(id=f"run-{i}") for i in range(5)]
        client.list_runs.return_value = runs

        mock_eval_run.return_value = [{"key": "s", "score": 1.0}]

        online = OnlineEvaluator(project_name="proj")
        online.add_evaluator(MagicMock())

        results = await online.aevaluate_recent(limit=5, max_concurrency=2)

        assert len(results) == 5
        assert mock_eval_run.call_count == 5

    @patch("lef.online.tracing.evaluate_run")
    @patch("lef.online.tracing.Client")
    async def test_aevaluate_recent_passes_evaluators_and_client(
        self, mock_client_cls, mock_eval_run
    ):
        """Each evaluate_run call should receive the evaluators and client."""
        client = MagicMock()
        mock_client_cls.return_value = client

        run1 = MagicMock()
        run1.id = "run-abc"
        client.list_runs.return_value = [run1]

        eval1 = MagicMock()
        mock_eval_run.return_value = [{"key": "q", "score": 0.5}]

        online = OnlineEvaluator(project_name="proj")
        online.add_evaluator(eval1)

        await online.aevaluate_recent(limit=1)

        mock_eval_run.assert_called_once_with(
            "run-abc",
            evaluators=[eval1],
            client=online.client,
        )

    @patch("lef.online.tracing.evaluate_run")
    @patch("lef.online.tracing.Client")
    async def test_aevaluate_recent_with_custom_client(self, mock_client_cls, mock_eval_run):
        """Custom client should be used throughout."""
        custom_client = MagicMock()
        run1 = MagicMock()
        run1.id = "run-custom"
        custom_client.list_runs.return_value = [run1]

        mock_eval_run.return_value = [{"key": "s", "score": 1.0}]

        online = OnlineEvaluator(project_name="proj", client=custom_client)
        online.add_evaluator(MagicMock())

        await online.aevaluate_recent(limit=1)

        custom_client.list_runs.assert_called_once()
        mock_eval_run.assert_called_once()
        assert mock_eval_run.call_args.kwargs["client"] is custom_client

    @patch("lef.online.tracing.evaluate_run")
    @patch("lef.online.tracing.Client")
    async def test_aevaluate_recent_default_limit(self, mock_client_cls, mock_eval_run):
        """Default limit should be 10."""
        client = MagicMock()
        mock_client_cls.return_value = client
        client.list_runs.return_value = []

        online = OnlineEvaluator(project_name="proj")
        online.add_evaluator(MagicMock())

        await online.aevaluate_recent()

        client.list_runs.assert_called_once_with(
            project_name="proj",
            limit=10,
            run_type=None,
        )
