"""Tests for LEF judges module.

These tests verify the judge factory functions produce callable evaluators
without actually calling the LLM APIs.
"""

from unittest.mock import MagicMock, patch

from lef.core.types import JudgeModel
from lef.judges.llm import (
    answer_relevance_judge,
    code_correctness_judge,
    conciseness_judge,
    correctness_judge,
    create_judge,
    faithfulness_judge,
    hallucination_judge,
    plan_adherence_judge,
    rag_groundedness_judge,
    rag_helpfulness_judge,
    rag_retrieval_relevance_judge,
    response_quality_judge,
    safety_judge,
    tool_selection_judge,
    toxicity_judge,
)


class TestCreateJudge:
    @patch("lef.judges.llm.create_llm_as_judge")
    def test_creates_judge(self, mock_create):
        mock_create.return_value = MagicMock()
        create_judge(
            "Is this correct? {inputs} {outputs}",
            feedback_key="test",
        )
        mock_create.assert_called_once_with(
            prompt="Is this correct? {inputs} {outputs}",
            model="openai:gpt-4o",
            feedback_key="test",
            system=None,
            few_shot_examples=None,
        )

    @patch("lef.judges.llm.create_llm_as_judge")
    def test_custom_model(self, mock_create):
        mock_create.return_value = MagicMock()
        create_judge("test", model=JudgeModel.CLAUDE_SONNET, feedback_key="test")
        assert mock_create.call_args[1]["model"] == "anthropic:claude-sonnet-4-20250514"


class TestPrebuiltJudges:
    """Verify each pre-built judge factory creates a callable."""

    @patch("lef.judges.llm.create_llm_as_judge")
    def test_correctness_judge(self, mock_create):
        mock_create.return_value = MagicMock()
        judge = correctness_judge()
        assert judge is not None
        mock_create.assert_called_once()
        assert mock_create.call_args[1]["feedback_key"] == "correctness"

    @patch("lef.judges.llm.create_llm_as_judge")
    def test_conciseness_judge(self, mock_create):
        mock_create.return_value = MagicMock()
        conciseness_judge()
        assert mock_create.call_args[1]["feedback_key"] == "conciseness"

    @patch("lef.judges.llm.create_llm_as_judge")
    def test_hallucination_judge(self, mock_create):
        mock_create.return_value = MagicMock()
        hallucination_judge()
        assert mock_create.call_args[1]["feedback_key"] == "hallucination"

    @patch("lef.judges.llm.create_llm_as_judge")
    def test_answer_relevance_judge(self, mock_create):
        mock_create.return_value = MagicMock()
        answer_relevance_judge()
        assert mock_create.call_args[1]["feedback_key"] == "answer_relevance"

    @patch("lef.judges.llm.create_llm_as_judge")
    def test_toxicity_judge(self, mock_create):
        mock_create.return_value = MagicMock()
        toxicity_judge()
        assert mock_create.call_args[1]["feedback_key"] == "toxicity"

    @patch("lef.judges.llm.create_llm_as_judge")
    def test_rag_groundedness_judge(self, mock_create):
        mock_create.return_value = MagicMock()
        rag_groundedness_judge()
        assert mock_create.call_args[1]["feedback_key"] == "rag_groundedness"

    @patch("lef.judges.llm.create_llm_as_judge")
    def test_rag_helpfulness_judge(self, mock_create):
        mock_create.return_value = MagicMock()
        rag_helpfulness_judge()
        assert mock_create.call_args[1]["feedback_key"] == "rag_helpfulness"

    @patch("lef.judges.llm.create_llm_as_judge")
    def test_rag_retrieval_relevance_judge(self, mock_create):
        mock_create.return_value = MagicMock()
        rag_retrieval_relevance_judge()
        assert mock_create.call_args[1]["feedback_key"] == "rag_retrieval_relevance"

    @patch("lef.judges.llm.create_llm_as_judge")
    def test_code_correctness_judge(self, mock_create):
        mock_create.return_value = MagicMock()
        code_correctness_judge()
        assert mock_create.call_args[1]["feedback_key"] == "code_correctness"

    @patch("lef.judges.llm.create_llm_as_judge")
    def test_plan_adherence_judge(self, mock_create):
        mock_create.return_value = MagicMock()
        plan_adherence_judge()
        assert mock_create.call_args[1]["feedback_key"] == "plan_adherence"

    @patch("lef.judges.llm.create_llm_as_judge")
    def test_faithfulness_judge(self, mock_create):
        mock_create.return_value = MagicMock()
        faithfulness_judge()
        assert mock_create.call_count == 1

    @patch("lef.judges.llm.create_llm_as_judge")
    def test_response_quality_judge(self, mock_create):
        mock_create.return_value = MagicMock()
        response_quality_judge()
        assert mock_create.call_count == 1

    @patch("lef.judges.llm.create_llm_as_judge")
    def test_tool_selection_judge(self, mock_create):
        mock_create.return_value = MagicMock()
        tool_selection_judge()
        assert mock_create.call_count == 1

    @patch("lef.judges.llm.create_llm_as_judge")
    def test_safety_judge(self, mock_create):
        mock_create.return_value = MagicMock()
        safety_judge()
        assert mock_create.call_count == 1

    @patch("lef.judges.llm.create_llm_as_judge")
    def test_custom_model_on_judge(self, mock_create):
        mock_create.return_value = MagicMock()
        correctness_judge(model=JudgeModel.CLAUDE_HAIKU)
        assert mock_create.call_args[1]["model"] == "anthropic:claude-haiku-4-5-20251001"
