"""Tests for LEF trajectory evaluator wrappers."""

from lef.core.types import JudgeModel
from lef.judges.trajectory import create_trajectory_evaluator, create_trajectory_judge


class TestCreateTrajectoryEvaluator:
    def test_creates_evaluator_default(self):
        evaluator = create_trajectory_evaluator()
        assert callable(evaluator)

    def test_import_error_message(self):
        """Verify helpful error when agentevals not installed."""
        # This test would only fail if agentevals IS installed, which it is
        # So we test that it works when installed
        evaluator = create_trajectory_evaluator(match_mode="superset")
        assert callable(evaluator)

    def test_match_modes(self):
        for mode in ["strict", "unordered", "subset", "superset"]:
            evaluator = create_trajectory_evaluator(match_mode=mode)
            assert callable(evaluator)


class TestCreateTrajectoryJudge:
    def test_creates_judge(self):
        judge = create_trajectory_judge()
        assert callable(judge)

    def test_custom_model(self):
        judge = create_trajectory_judge(model=JudgeModel.CLAUDE_SONNET)
        assert callable(judge)
