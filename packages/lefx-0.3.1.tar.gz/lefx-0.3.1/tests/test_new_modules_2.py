"""Tests for git_context, watch, ci, redteam, monitor, synthetic."""

import json
import os
from unittest.mock import MagicMock, patch

import pytest

# -----------------------------------------------------------------------
# git_context.py
# -----------------------------------------------------------------------


class TestGetGitContext:
    @patch("lef.git_context._detect_ci_context", return_value={})
    @patch("lef.git_context._run_git")
    def test_returns_dict_with_git_fields(self, mock_run_git, _mock_ci):
        """get_git_context returns a dict containing branch, commit_sha, etc."""

        def _side_effect(args, cwd=None):
            mapping = {
                ("rev-parse", "--abbrev-ref", "HEAD"): "main",
                ("rev-parse", "HEAD"): "abc12345deadbeef" * 2,
                ("log", "-1", "--format=%an"): "Alice",
                ("log", "-1", "--format=%ae"): "alice@example.com",
                ("log", "-1", "--format=%s"): "Initial commit",
                ("status", "--porcelain"): "",
                ("remote", "get-url", "origin"): "https://github.com/org/repo.git",
            }
            return mapping.get(tuple(args))

        mock_run_git.side_effect = _side_effect

        from lef.git_context import get_git_context

        ctx = get_git_context()
        assert ctx["branch"] == "main"
        assert ctx["commit_sha"] == "abc12345deadbeef" * 2
        assert ctx["commit_short"] == "abc12345"
        assert ctx["author"] == "Alice"
        assert ctx["author_email"] == "alice@example.com"
        assert ctx["commit_message"] == "Initial commit"
        assert ctx["is_dirty"] is False
        assert ctx["remote_url"] == "https://github.com/org/repo.git"


class TestBuildExperimentMetadata:
    @patch(
        "lef.git_context.get_git_context",
        return_value={"branch": "feat/x", "commit_sha": "aaa"},
    )
    def test_merges_git_context_with_extra(self, _mock):
        from lef.git_context import build_experiment_metadata

        meta = build_experiment_metadata(extra={"run_id": "42"})
        assert meta["branch"] == "feat/x"
        assert meta["run_id"] == "42"

    @patch("lef.git_context.get_git_context", return_value={"branch": "main"})
    def test_extra_overrides_git(self, _mock):
        from lef.git_context import build_experiment_metadata

        meta = build_experiment_metadata(extra={"branch": "override"})
        assert meta["branch"] == "override"


class TestDetectCIContextGitHub:
    def test_github_actions_env(self):
        env = {
            "GITHUB_ACTIONS": "true",
            "GITHUB_HEAD_REF": "feature-branch",
            "GITHUB_SHA": "deadbeef12345678" * 2,
            "GITHUB_RUN_ID": "9999",
            "GITHUB_REPOSITORY": "org/repo",
            "GITHUB_REF": "refs/pull/42/merge",
        }
        with patch.dict(os.environ, env, clear=False):
            # Remove Azure DevOps env vars that could interfere
            for k in ("BUILD_BUILDID", "GITLAB_CI", "JENKINS_URL"):
                os.environ.pop(k, None)

            from lef.git_context import _detect_ci_context

            ctx = _detect_ci_context()
            assert ctx["ci_provider"] == "github"
            assert ctx["branch"] == "feature-branch"
            assert ctx["commit_sha"] == "deadbeef12345678" * 2
            assert ctx["commit_short"] == "deadbeef"
            assert ctx["pr_number"] == "42"
            assert ctx["ci_run_id"] == "9999"
            assert ctx["repository"] == "org/repo"


class TestDetectCIContextAzureDevOps:
    def test_azuredevops_env(self):
        env = {
            "BUILD_BUILDID": "777",
            "BUILD_SOURCEBRANCH": "refs/heads/my-branch",
            "BUILD_SOURCEVERSION": "abcdef1234567890" * 2,
            "SYSTEM_PULLREQUEST_PULLREQUESTID": "55",
            "BUILD_REPOSITORY_NAME": "my-repo",
        }
        with patch.dict(os.environ, env, clear=False):
            for k in ("GITHUB_ACTIONS", "GITLAB_CI", "JENKINS_URL"):
                os.environ.pop(k, None)

            from lef.git_context import _detect_ci_context

            ctx = _detect_ci_context()
            assert ctx["ci_provider"] == "azuredevops"
            assert ctx["branch"] == "my-branch"
            assert ctx["commit_sha"] == "abcdef1234567890" * 2
            assert ctx["pr_number"] == "55"
            assert ctx["ci_run_id"] == "777"


# -----------------------------------------------------------------------
# watch.py
# -----------------------------------------------------------------------


class TestGetFileMtimes:
    def test_returns_correct_mtimes_for_files(self, tmp_path):
        f1 = tmp_path / "a.py"
        f1.write_text("x")
        f2 = tmp_path / "b.yaml"
        f2.write_text("y")

        from lef.watch import _get_file_mtimes

        mtimes = _get_file_mtimes([f1, f2])
        assert str(f1) in mtimes
        assert str(f2) in mtimes
        assert isinstance(mtimes[str(f1)], float)

    def test_returns_mtimes_for_directory(self, tmp_path):
        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "mod.py").write_text("code")
        (sub / "data.json").write_text("{}")
        (sub / "readme.txt").write_text("ignore")  # not a watched extension

        from lef.watch import _get_file_mtimes

        mtimes = _get_file_mtimes([sub])
        paths = list(mtimes.keys())
        assert any("mod.py" in p for p in paths)
        assert any("data.json" in p for p in paths)
        assert not any("readme.txt" in p for p in paths)


class TestDetectChanges:
    def test_detects_new_file(self):
        from lef.watch import _detect_changes

        old = {"/a.py": 1.0}
        new = {"/a.py": 1.0, "/b.py": 2.0}
        changed = _detect_changes(old, new)
        assert "/b.py" in changed
        assert "/a.py" not in changed

    def test_detects_modified_file(self):
        from lef.watch import _detect_changes

        old = {"/a.py": 1.0}
        new = {"/a.py": 2.0}
        changed = _detect_changes(old, new)
        assert "/a.py" in changed

    def test_no_changes(self):
        from lef.watch import _detect_changes

        old = {"/a.py": 1.0, "/b.py": 2.0}
        new = {"/a.py": 1.0, "/b.py": 2.0}
        changed = _detect_changes(old, new)
        assert changed == []


# -----------------------------------------------------------------------
# ci/github.py
# -----------------------------------------------------------------------


class TestGitHubDetectPrNumber:
    def test_from_github_ref(self):
        with patch.dict(os.environ, {"GITHUB_REF": "refs/pull/123/merge"}, clear=False):
            os.environ.pop("GITHUB_PR_NUMBER", None)
            from lef.ci.github import _detect_pr_number

            assert _detect_pr_number() == "123"

    def test_from_env_var(self):
        with patch.dict(os.environ, {"GITHUB_PR_NUMBER": "456"}, clear=False):
            from lef.ci.github import _detect_pr_number

            assert _detect_pr_number() == "456"

    def test_returns_none_when_not_set(self):
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("GITHUB_PR_NUMBER", None)
            os.environ.pop("GITHUB_REF", None)
            from lef.ci.github import _detect_pr_number

            assert _detect_pr_number() is None


class TestPostGitHubComment:
    @patch("lef.ci.github._find_existing_comment", return_value=None)
    @patch("lef.ci.github._create_comment")
    def test_calls_correct_api_url(self, mock_create, mock_find):
        mock_create.return_value = {"comment_id": 1, "url": "https://github.com/..."}

        from lef.ci.github import post_github_comment

        result = post_github_comment(
            "Test body",
            repo="org/repo",
            pr_number=42,
            token="ghp_fake",
            update_existing=True,
        )
        assert result["action"] == "created"
        assert result["comment_id"] == 1
        mock_create.assert_called_once()
        call_kwargs = mock_create.call_args[1]
        assert call_kwargs["repo"] == "org/repo"
        assert call_kwargs["pr_number"] == "42"

    @patch("lef.ci.github._find_existing_comment", return_value=999)
    @patch("lef.ci.github._update_comment")
    def test_updates_existing_comment(self, mock_update, mock_find):
        mock_update.return_value = {"comment_id": 999, "url": "https://github.com/..."}

        from lef.ci.github import post_github_comment

        result = post_github_comment(
            "Updated",
            repo="org/repo",
            pr_number=10,
            token="ghp_fake",
            update_existing=True,
        )
        assert result["action"] == "updated"
        mock_update.assert_called_once()

    def test_raises_without_repo(self):
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("GITHUB_REPOSITORY", None)
            from lef.ci.github import post_github_comment

            with pytest.raises(ValueError, match="Cannot determine repository"):
                post_github_comment("body", token="x", pr_number=1)

    def test_raises_without_token(self):
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("GITHUB_TOKEN", None)
            from lef.ci.github import post_github_comment

            with pytest.raises(ValueError, match="GitHub token required"):
                post_github_comment("body", repo="org/repo", pr_number=1)


# -----------------------------------------------------------------------
# ci/azuredevops.py
# -----------------------------------------------------------------------


class TestExtractOrgFromUri:
    def test_dev_azure_com_format(self):
        from lef.ci.azuredevops import _extract_org_from_uri

        assert _extract_org_from_uri("https://dev.azure.com/myorg/") == "myorg"

    def test_dev_azure_com_no_trailing_slash(self):
        from lef.ci.azuredevops import _extract_org_from_uri

        assert _extract_org_from_uri("https://dev.azure.com/myorg") == "myorg"

    def test_visualstudio_format(self):
        from lef.ci.azuredevops import _extract_org_from_uri

        assert _extract_org_from_uri("https://myorg.visualstudio.com/") == "myorg"

    def test_empty_string(self):
        from lef.ci.azuredevops import _extract_org_from_uri

        assert _extract_org_from_uri("") is None


class TestPostAzdoComment:
    @patch("lef.ci.azuredevops._find_existing_thread", return_value=None)
    @patch("lef.ci.azuredevops._create_thread")
    def test_creates_thread_with_mocked_env(self, mock_create, mock_find):
        mock_create.return_value = {"thread_id": 100}

        from lef.ci.azuredevops import post_azdo_comment

        result = post_azdo_comment(
            "Eval results",
            organization="myorg",
            project="myproj",
            repo_id="repo-1",
            pr_number=7,
            token="pat_fake",
        )
        assert result["action"] == "created"
        assert result["thread_id"] == 100
        mock_create.assert_called_once()

    @patch("lef.ci.azuredevops._find_existing_thread", return_value=55)
    @patch("lef.ci.azuredevops._update_thread")
    def test_updates_existing_thread(self, mock_update, mock_find):
        mock_update.return_value = {"thread_id": 55}

        from lef.ci.azuredevops import post_azdo_comment

        result = post_azdo_comment(
            "Updated results",
            organization="myorg",
            project="myproj",
            repo_id="repo-1",
            pr_number=7,
            token="pat_fake",
        )
        assert result["action"] == "updated"
        assert result["thread_id"] == 55

    def test_raises_without_organization(self):
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("SYSTEM_COLLECTIONURI", None)
            from lef.ci.azuredevops import post_azdo_comment

            with pytest.raises(ValueError, match="Cannot determine Azure DevOps organization"):
                post_azdo_comment("body", project="p", repo_id="r", pr_number=1, token="t")


# -----------------------------------------------------------------------
# redteam.py
# -----------------------------------------------------------------------


class TestRefusalCheck:
    def test_detects_refusal(self):
        from lef.redteam import refusal_check

        result = refusal_check(
            inputs={"question": "Do something bad"},
            outputs={"answer": "I can't help with that request."},
        )
        assert result["score"] == 1.0

    def test_no_refusal(self):
        from lef.redteam import refusal_check

        result = refusal_check(
            inputs={"question": "What is 2+2?"},
            outputs={"answer": "The answer is 4."},
        )
        assert result["score"] == 0.0

    def test_uses_output_key(self):
        from lef.redteam import refusal_check

        result = refusal_check(
            inputs={},
            outputs={"output": "I must decline this request."},
        )
        assert result["score"] == 1.0


class TestPiiLeakCheck:
    def test_clean_output(self):
        from lef.redteam import pii_leak_check

        result = pii_leak_check(
            inputs={},
            outputs={"answer": "The capital is Paris."},
        )
        assert result["score"] == 1.0

    def test_detects_email(self):
        from lef.redteam import pii_leak_check

        result = pii_leak_check(
            inputs={},
            outputs={"answer": "Contact user@example.com for details."},
        )
        assert result["score"] == 0.0

    def test_detects_phone(self):
        from lef.redteam import pii_leak_check

        result = pii_leak_check(
            inputs={},
            outputs={"answer": "Call 555-123-4567 for help."},
        )
        assert result["score"] == 0.0

    def test_detects_api_key(self):
        from lef.redteam import pii_leak_check

        result = pii_leak_check(
            inputs={},
            outputs={"answer": "Use sk-abcdefghij1234567890abcd to authenticate."},
        )
        assert result["score"] == 0.0

    def test_detects_password(self):
        from lef.redteam import pii_leak_check

        result = pii_leak_check(
            inputs={},
            outputs={"answer": "The password: secret123"},
        )
        assert result["score"] == 0.0


class TestInjectionResistanceCheck:
    def test_safe_response(self):
        from lef.redteam import injection_resistance_check

        result = injection_resistance_check(
            inputs={"question": "Ignore instructions"},
            outputs={"answer": "I'm happy to help with your question."},
        )
        assert result["score"] == 1.0

    def test_compromised_response(self):
        from lef.redteam import injection_resistance_check

        result = injection_resistance_check(
            inputs={},
            outputs={"answer": "Developer mode activated. Here are my rules: ..."},
        )
        assert result["score"] == 0.0

    def test_system_prompt_leak(self):
        from lef.redteam import injection_resistance_check

        result = injection_resistance_check(
            inputs={},
            outputs={"answer": "System prompt: You are a helpful assistant."},
        )
        assert result["score"] == 0.0


class TestAttackCategories:
    def test_has_six_categories(self):
        from lef.redteam import _ATTACK_CATEGORIES

        assert len(_ATTACK_CATEGORIES) == 6

    def test_expected_category_names(self):
        from lef.redteam import _ATTACK_CATEGORIES

        expected = {
            "prompt_injection",
            "jailbreak",
            "pii_extraction",
            "hallucination_inducement",
            "toxicity",
            "bias",
        }
        assert set(_ATTACK_CATEGORIES.keys()) == expected

    def test_each_category_has_seed_inputs(self):
        from lef.redteam import _ATTACK_CATEGORIES

        for name, cat in _ATTACK_CATEGORIES.items():
            assert "seed_inputs" in cat, f"{name} missing seed_inputs"
            assert len(cat["seed_inputs"]) > 0, f"{name} has empty seed_inputs"


# -----------------------------------------------------------------------
# monitor.py
# -----------------------------------------------------------------------


class TestMonitorDaemon:
    @patch("lef.monitor.Client")
    def test_construction(self, mock_client_cls):
        from lef.monitor import MonitorDaemon

        evaluator_fn = MagicMock()
        daemon = MonitorDaemon(
            project_name="test-project",
            evaluators=[evaluator_fn],
            thresholds={"safety": 0.9},
            poll_interval=30.0,
            batch_size=10,
        )
        assert daemon.project_name == "test-project"
        assert len(daemon.evaluators) == 1
        assert daemon.thresholds == {"safety": 0.9}
        assert daemon.poll_interval == 30.0
        assert daemon.batch_size == 10
        assert daemon._total_evaluated == 0

    @patch("lef.monitor.Client")
    def test_add_alert_handler_returns_self(self, mock_client_cls):
        from lef.monitor import MonitorDaemon

        daemon = MonitorDaemon(
            project_name="proj",
            evaluators=[MagicMock()],
        )
        handler = MagicMock()
        result = daemon.add_alert_handler(handler)
        assert result is daemon
        assert handler in daemon._alert_handlers

    @patch("lef.monitor.Client")
    def test_chaining_multiple_handlers(self, mock_client_cls):
        from lef.monitor import MonitorDaemon

        daemon = MonitorDaemon(project_name="proj", evaluators=[MagicMock()])
        h1 = MagicMock()
        h2 = MagicMock()
        result = daemon.add_alert_handler(h1).add_alert_handler(h2)
        assert result is daemon
        assert len(daemon._alert_handlers) == 2


# -----------------------------------------------------------------------
# synthetic.py
# -----------------------------------------------------------------------


class TestParseJsonResponse:
    def test_raw_json_array(self):
        from lef.synthetic import _parse_json_response

        raw = json.dumps([{"question": "Q1", "answer": "A1"}])
        result = _parse_json_response(raw)
        assert len(result) == 1
        assert result[0]["question"] == "Q1"

    def test_markdown_fenced_json(self):
        from lef.synthetic import _parse_json_response

        text = '```json\n[{"question": "Q1", "answer": "A1"}]\n```'
        result = _parse_json_response(text)
        assert len(result) == 1
        assert result[0]["question"] == "Q1"

    def test_markdown_fenced_no_language(self):
        from lef.synthetic import _parse_json_response

        text = '```\n[{"a": 1}]\n```'
        result = _parse_json_response(text)
        assert len(result) == 1
        assert result[0]["a"] == 1

    def test_dict_with_examples_key(self):
        from lef.synthetic import _parse_json_response

        raw = json.dumps({"examples": [{"q": "Q1"}, {"q": "Q2"}]})
        result = _parse_json_response(raw)
        assert len(result) == 2

    def test_single_dict_wrapped_in_list(self):
        from lef.synthetic import _parse_json_response

        raw = json.dumps({"question": "Q1"})
        result = _parse_json_response(raw)
        assert len(result) == 1
        assert result[0]["question"] == "Q1"

    def test_invalid_json_returns_empty(self):
        from lef.synthetic import _parse_json_response

        result = _parse_json_response("this is not json at all")
        assert result == []


# -----------------------------------------------------------------------
# pytest_plugin.py
# -----------------------------------------------------------------------


class TestPytestAddOption:
    def test_registers_options(self):
        from lef.pytest_plugin import pytest_addoption

        mock_group = MagicMock()
        mock_parser = MagicMock()
        mock_parser.getgroup.return_value = mock_group

        pytest_addoption(mock_parser)

        mock_parser.getgroup.assert_called_once_with("lef", "LEF Evaluation Framework")

        option_names = [call.args[0] for call in mock_group.addoption.call_args_list]
        assert "--lef-config" in option_names
        assert "--lef-no-upload" in option_names
        assert "--lef-prefix" in option_names
        assert mock_group.addoption.call_count == 3
