"""Tests for lef.online.tracing module."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from lef.core.types import EvalResult
from lef.online.tracing import OnlineEvaluator, create_rule, evaluate_run


class TestEvaluateRun:
    """Tests for evaluate_run function."""

    @patch("lef.online.tracing.Client")
    def test_evaluates_run_with_dict_result(self, mock_client_cls):
        client = MagicMock()
        mock_run = MagicMock()
        mock_run.id = "run-123"
        mock_run.inputs = {"question": "What is 2+2?"}
        mock_run.outputs = {"answer": "4"}
        client.read_run.return_value = mock_run

        evaluator = MagicMock(return_value={"key": "correctness", "score": 0.9})

        results = evaluate_run("run-123", evaluators=[evaluator], client=client)

        assert len(results) == 1
        assert results[0]["key"] == "correctness"
        assert results[0]["score"] == 0.9
        client.create_feedback.assert_called_once()

    @patch("lef.online.tracing.Client")
    def test_evaluates_run_with_eval_result(self, mock_client_cls):
        client = MagicMock()
        mock_run = MagicMock()
        mock_run.id = "run-456"
        mock_run.inputs = {"q": "test"}
        mock_run.outputs = {"a": "result"}
        client.read_run.return_value = mock_run

        eval_result = EvalResult(key="quality", score=0.8, comment="Good")
        evaluator = MagicMock(return_value=eval_result)

        results = evaluate_run("run-456", evaluators=[evaluator], client=client)

        assert len(results) == 1
        assert results[0]["key"] == "quality"
        assert results[0]["score"] == 0.8

    @patch("lef.online.tracing.Client")
    def test_evaluates_with_multiple_evaluators(self, mock_client_cls):
        client = MagicMock()
        mock_run = MagicMock()
        mock_run.id = "run-789"
        mock_run.inputs = {"q": "test"}
        mock_run.outputs = {"a": "result"}
        client.read_run.return_value = mock_run

        eval1 = MagicMock(return_value={"key": "score1", "score": 1.0})
        eval2 = MagicMock(return_value={"key": "score2", "score": 0.5})

        results = evaluate_run("run-789", evaluators=[eval1, eval2], client=client)

        assert len(results) == 2
        assert client.create_feedback.call_count == 2

    @patch("lef.online.tracing.Client")
    def test_handles_bool_score(self, mock_client_cls):
        client = MagicMock()
        mock_run = MagicMock()
        mock_run.id = "run-bool"
        mock_run.inputs = {}
        mock_run.outputs = {}
        client.read_run.return_value = mock_run

        evaluator = MagicMock(return_value={"key": "pass", "score": True})
        evaluate_run("run-bool", evaluators=[evaluator], client=client)

        feedback_call = client.create_feedback.call_args
        assert feedback_call.kwargs["score"] == 1.0

    @patch("lef.online.tracing.Client")
    def test_handles_raw_value_result(self, mock_client_cls):
        client = MagicMock()
        mock_run = MagicMock()
        mock_run.id = "run-raw"
        mock_run.inputs = {}
        mock_run.outputs = {}
        client.read_run.return_value = mock_run

        evaluator = MagicMock(return_value=0.75)
        results = evaluate_run("run-raw", evaluators=[evaluator], client=client)

        assert results[0]["key"] == "score"
        assert results[0]["score"] == 0.75

    @patch("lef.online.tracing.Client")
    def test_uses_default_client_when_none_provided(self, mock_client_cls):
        mock_client_cls.return_value = MagicMock()
        mock_run = MagicMock()
        mock_run.id = "run-default"
        mock_run.inputs = {}
        mock_run.outputs = {}
        mock_client_cls.return_value.read_run.return_value = mock_run

        evaluator = MagicMock(return_value={"key": "s", "score": 1.0})
        evaluate_run("run-default", evaluators=[evaluator])

        mock_client_cls.assert_called_once()


class TestCreateRule:
    """Tests for create_rule function."""

    def test_returns_config_dict(self):
        evaluator = MagicMock()
        rule = create_rule(
            name="safety-check",
            evaluator=evaluator,
            project_name="my-project",
            sampling_rate=0.5,
        )

        assert rule["name"] == "safety-check"
        assert rule["evaluator"] is evaluator
        assert rule["project_name"] == "my-project"
        assert rule["sampling_rate"] == 0.5

    def test_default_sampling_rate(self):
        rule = create_rule(name="test", evaluator=MagicMock())
        assert rule["sampling_rate"] == 1.0

    def test_optional_project_name(self):
        rule = create_rule(name="test", evaluator=MagicMock())
        assert rule["project_name"] is None


class TestOnlineEvaluator:
    """Tests for OnlineEvaluator class."""

    @patch("lef.online.tracing.Client")
    def test_init(self, mock_client_cls):
        evaluator = OnlineEvaluator(project_name="my-project")
        assert evaluator.project_name == "my-project"
        assert evaluator._evaluators == []

    @patch("lef.online.tracing.Client")
    def test_add_evaluator_chaining(self, mock_client_cls):
        online = OnlineEvaluator(project_name="proj")
        eval1 = MagicMock()
        eval2 = MagicMock()
        result = online.add_evaluator(eval1).add_evaluator(eval2)
        assert result is online
        assert len(online._evaluators) == 2

    @patch("lef.online.tracing.evaluate_run")
    @patch("lef.online.tracing.Client")
    def test_evaluate_run_delegates(self, mock_client_cls, mock_eval_run):
        mock_eval_run.return_value = [{"key": "s", "score": 1.0}]
        online = OnlineEvaluator(project_name="proj")
        eval1 = MagicMock()
        online.add_evaluator(eval1)

        results = online.evaluate_run("run-id")

        mock_eval_run.assert_called_once_with(
            "run-id",
            evaluators=[eval1],
            client=online.client,
        )
        assert results == [{"key": "s", "score": 1.0}]

    @patch("lef.online.tracing.evaluate_run")
    @patch("lef.online.tracing.Client")
    def test_evaluate_recent(self, mock_client_cls, mock_eval_run):
        client = MagicMock()
        mock_client_cls.return_value = client

        run1 = MagicMock()
        run1.id = "run-1"
        run2 = MagicMock()
        run2.id = "run-2"
        client.list_runs.return_value = [run1, run2]

        mock_eval_run.return_value = [{"key": "s", "score": 1.0}]

        online = OnlineEvaluator(project_name="proj")
        online.add_evaluator(MagicMock())

        results = online.evaluate_recent(limit=5)

        assert len(results) == 2
        client.list_runs.assert_called_once_with(
            project_name="proj",
            limit=5,
            run_type=None,
        )

    @patch("lef.online.tracing.evaluate_run")
    @patch("lef.online.tracing.Client")
    def test_evaluate_recent_with_run_type(self, mock_client_cls, mock_eval_run):
        client = MagicMock()
        mock_client_cls.return_value = client
        client.list_runs.return_value = []
        mock_eval_run.return_value = []

        online = OnlineEvaluator(project_name="proj")
        online.evaluate_recent(limit=10, run_type="chain")

        client.list_runs.assert_called_once_with(
            project_name="proj",
            limit=10,
            run_type="chain",
        )

    @patch("lef.online.tracing.Client")
    def test_custom_client(self, mock_client_cls):
        custom_client = MagicMock()
        online = OnlineEvaluator(project_name="proj", client=custom_client)
        assert online.client is custom_client
