"""Tests for LEF built-in scorers and custom scorer utilities."""

from lef.core.types import EvalResult
from lef.scorers.builtin import contains, exact_match, json_match, regex_match
from lef.scorers.custom import create_composite_scorer, create_scorer


class TestExactMatch:
    def test_match(self):
        result = exact_match(
            inputs={"q": "test"},
            outputs={"answer": "Paris"},
            reference_outputs={"answer": "Paris"},
        )
        assert result.score == 1.0

    def test_no_match(self):
        result = exact_match(
            inputs={"q": "test"},
            outputs={"answer": "London"},
            reference_outputs={"answer": "Paris"},
        )
        assert result.score == 0.0

    def test_whitespace_handling(self):
        result = exact_match(
            inputs={"q": "test"},
            outputs={"answer": "  Paris  "},
            reference_outputs={"answer": "Paris"},
        )
        assert result.score == 1.0

    def test_no_reference(self):
        result = exact_match(
            inputs={"q": "test"},
            outputs={"answer": "Paris"},
            reference_outputs=None,
        )
        assert result.score == 0.0


class TestContains:
    def test_contains(self):
        result = contains(
            inputs={},
            outputs={"answer": "The capital of France is Paris."},
            reference_outputs={"answer": "Paris"},
        )
        assert result.score == 1.0

    def test_case_insensitive(self):
        result = contains(
            inputs={},
            outputs={"answer": "PARIS is great"},
            reference_outputs={"answer": "paris"},
        )
        assert result.score == 1.0

    def test_not_contains(self):
        result = contains(
            inputs={},
            outputs={"answer": "London"},
            reference_outputs={"answer": "Paris"},
        )
        assert result.score == 0.0


class TestRegexMatch:
    def test_match(self):
        result = regex_match(
            inputs={},
            outputs={"answer": "The answer is 42."},
            reference_outputs={"pattern": r"\d+"},
        )
        assert result.score == 1.0

    def test_no_match(self):
        result = regex_match(
            inputs={},
            outputs={"answer": "no numbers here"},
            reference_outputs={"pattern": r"\d+"},
        )
        assert result.score == 0.0

    def test_no_pattern(self):
        result = regex_match(
            inputs={},
            outputs={"answer": "test"},
            reference_outputs={"answer": "test"},
        )
        assert result.score == 0.0


class TestJsonMatch:
    def test_full_match(self):
        result = json_match(
            inputs={},
            outputs={"data": {"name": "Alice", "age": 30}},
            reference_outputs={"data": {"name": "Alice", "age": 30}},
        )
        assert result.score == 1.0

    def test_partial_match(self):
        result = json_match(
            inputs={},
            outputs={"data": {"name": "Alice", "age": 25}},
            reference_outputs={"data": {"name": "Alice", "age": 30}},
        )
        assert result.score == 0.5

    def test_no_reference(self):
        result = json_match(
            inputs={},
            outputs={"data": {"name": "Alice"}},
            reference_outputs=None,
        )
        assert result.score == 0.0

    def test_json_string_parsing(self):
        result = json_match(
            inputs={},
            outputs={"data": '{"name": "Alice"}'},
            reference_outputs={"data": '{"name": "Alice"}'},
        )
        assert result.score == 1.0


class TestCreateScorer:
    def test_basic(self):
        def my_fn(*, inputs, outputs, **kwargs):
            return 0.8

        s = create_scorer("my_metric", my_fn)
        result = s(inputs={}, outputs={})
        assert isinstance(result, EvalResult)
        assert result.score == 0.8
        assert result.key == "my_metric"


class TestCompositeScorer:
    def test_mean_aggregation(self):
        from lef.core.decorators import scorer

        @scorer(key="a")
        def scorer_a(*, inputs, outputs, **kwargs):
            return 1.0

        @scorer(key="b")
        def scorer_b(*, inputs, outputs, **kwargs):
            return 0.5

        composite = create_composite_scorer("mean_score", [scorer_a, scorer_b], aggregation="mean")
        result = composite(inputs={}, outputs={})
        assert result.score == 0.75

    def test_min_aggregation(self):
        from lef.core.decorators import scorer

        @scorer(key="c")
        def scorer_c(*, inputs, outputs, **kwargs):
            return 1.0

        @scorer(key="d")
        def scorer_d(*, inputs, outputs, **kwargs):
            return 0.3

        composite = create_composite_scorer("min_score", [scorer_c, scorer_d], aggregation="min")
        result = composite(inputs={}, outputs={})
        assert result.score == 0.3

    def test_all_pass(self):
        from lef.core.decorators import scorer

        @scorer(key="e")
        def scorer_e(*, inputs, outputs, **kwargs):
            return 0.8

        @scorer(key="f")
        def scorer_f(*, inputs, outputs, **kwargs):
            return 0.3

        composite = create_composite_scorer(
            "all_pass", [scorer_e, scorer_f], aggregation="all_pass"
        )
        result = composite(inputs={}, outputs={})
        assert result.score == 0.0  # 0.3 < 1.0 and 0.8 < 1.0, fails
