"""Extended tests for LEF CLI: _resolve_target, _validate_config, and judge factory resolution."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from lef.cli import _resolve_evaluator, _resolve_target, _validate_config


class TestResolveTarget:
    """Tests for _resolve_target."""

    def test_direct_import(self):
        """Direct import path without trailing () returns the object as-is."""
        target = _resolve_target("lef.scorers.builtin:exact_match")
        assert callable(target)
        assert hasattr(target, "key")
        assert target.key == "exact_match"

    def test_factory_pattern_calls_object(self):
        """Trailing () should call the imported object (factory pattern)."""
        with patch("lef.cli._import_object") as mock_import:
            factory = MagicMock()
            factory.return_value = "created_target"
            mock_import.return_value = factory

            result = _resolve_target("myapp.agent:create_target()")

            mock_import.assert_called_once_with("myapp.agent:create_target")
            factory.assert_called_once_with()
            assert result == "created_target"

    def test_non_factory_does_not_call(self):
        """Without trailing (), the object should NOT be called."""
        with patch("lef.cli._import_object") as mock_import:
            obj = MagicMock()
            mock_import.return_value = obj

            result = _resolve_target("myapp.agent:invoke")

            mock_import.assert_called_once_with("myapp.agent:invoke")
            obj.assert_not_called()
            assert result is obj

    def test_invalid_import_raises(self):
        """An invalid import path should raise ValueError."""
        with pytest.raises(ValueError, match="Cannot import"):
            _resolve_target("nonexistent_thing")

    def test_dotted_import(self):
        """Dotted path (no colon) should also work for direct imports."""
        target = _resolve_target("lef.scorers.builtin.exact_match")
        assert callable(target)

    def test_factory_with_real_callable(self):
        """Factory pattern with a real Python callable."""
        # Use a real callable that returns something
        with patch("lef.cli._import_object") as mock_import:
            mock_import.return_value = lambda: {"target": True}

            result = _resolve_target("mymodule:make_target()")
            assert result == {"target": True}


class TestValidateConfig:
    """Tests for _validate_config."""

    def test_valid_config_no_warnings(self):
        config = {
            "target": "myapp:invoke",
            "dataset": "my-dataset",
            "evaluators": ["exact_match"],
        }
        warnings = _validate_config(config, "test.yaml")
        assert warnings == []

    def test_unknown_keys_warning(self):
        config = {
            "target": "myapp:invoke",
            "dataset": "my-dataset",
            "evaluators": ["exact_match"],
            "unknown_key": "value",
            "another_bad_key": 42,
        }
        warnings = _validate_config(config, "test.yaml")
        assert len(warnings) == 1
        assert "Unknown config keys" in warnings[0]
        assert "another_bad_key" in warnings[0]
        assert "unknown_key" in warnings[0]

    def test_missing_evaluators_warning(self):
        config = {
            "target": "myapp:invoke",
            "dataset": "my-dataset",
        }
        warnings = _validate_config(config, "test.yaml")
        assert any("evaluators" in w for w in warnings)

    def test_empty_evaluators_warning(self):
        config = {
            "target": "myapp:invoke",
            "dataset": "my-dataset",
            "evaluators": [],
        }
        warnings = _validate_config(config, "test.yaml")
        assert any("evaluators" in w for w in warnings)

    def test_missing_target_warning(self):
        config = {
            "dataset": "my-dataset",
            "evaluators": ["exact_match"],
        }
        warnings = _validate_config(config, "test.yaml")
        assert any("target" in w for w in warnings)

    def test_missing_dataset_warning(self):
        config = {
            "target": "myapp:invoke",
            "evaluators": ["exact_match"],
        }
        warnings = _validate_config(config, "test.yaml")
        assert any("dataset" in w for w in warnings)

    def test_all_missing_gives_multiple_warnings(self):
        config = {}
        warnings = _validate_config(config, "empty.yaml")
        # Should warn about missing evaluators, target, and dataset
        assert len(warnings) == 3

    def test_valid_keys_accepted(self):
        """All valid keys should not produce unknown-key warnings."""
        config = {
            "target": "myapp:invoke",
            "dataset": "ds",
            "evaluators": ["exact_match"],
            "experiment_prefix": "test",
            "description": "desc",
            "thresholds": {"correctness": 0.8},
            "max_concurrency": 5,
            "num_repetitions": 2,
            "upload_results": True,
            "input_keys": ["question"],
            "output_keys": ["answer"],
            "metadata": {"version": "1.0"},
        }
        warnings = _validate_config(config, "full.yaml")
        assert warnings == []

    def test_filepath_included_in_warning(self):
        config = {"bogus": True, "target": "t", "dataset": "d", "evaluators": ["e"]}
        warnings = _validate_config(config, "my_config.yaml")
        assert any("my_config.yaml" in w for w in warnings)


class TestResolveEvaluatorJudgeFactory:
    """Verify judge factory resolution calls the factory."""

    def test_judge_factory_is_called(self):
        """Judge factories in _JUDGE_FACTORIES should be called (instantiated)."""
        with patch("lef.cli.importlib.import_module") as mock_import:
            mock_module = MagicMock()
            factory_fn = MagicMock(return_value="judge_instance")
            mock_module.correctness_judge = factory_fn
            mock_import.return_value = mock_module

            result = _resolve_evaluator("correctness_judge")

            factory_fn.assert_called_once_with()
            assert result == "judge_instance"

    def test_scorer_not_called_as_factory(self):
        """Scorers should be returned directly, not called."""
        evaluator = _resolve_evaluator("exact_match")
        assert hasattr(evaluator, "key")
        assert evaluator.key == "exact_match"

    def test_all_judge_factories_resolve(self):
        """All entries in _JUDGE_FACTORIES should resolve without error."""
        from lef.cli import _JUDGE_FACTORIES

        for name in _JUDGE_FACTORIES:
            evaluator = _resolve_evaluator(name)
            assert callable(evaluator), f"{name} did not resolve to a callable"
