"""Tests for LEF configuration."""

import os

from lef.config import LefConfig
from lef.core.types import JudgeModel


class TestLefConfig:
    def test_defaults(self):
        config = LefConfig()
        assert config.langsmith_project == "default"
        assert config.tracing_enabled is True
        assert config.default_judge_model == JudgeModel.GPT_4O
        assert config.max_concurrency == 5

    def test_from_env(self, monkeypatch):
        monkeypatch.setenv("LANGCHAIN_API_KEY", "test-key")
        monkeypatch.setenv("LANGCHAIN_PROJECT", "test-project")
        monkeypatch.setenv("LANGCHAIN_TRACING_V2", "false")

        config = LefConfig.from_env()
        assert config.langsmith_api_key == "test-key"
        assert config.langsmith_project == "test-project"
        assert config.tracing_enabled is False

    def test_apply(self, monkeypatch):
        config = LefConfig(
            langsmith_api_key="my-key",
            langsmith_project="my-project",
            tracing_enabled=True,
        )
        config.apply()
        assert os.environ["LANGCHAIN_API_KEY"] == "my-key"
        assert os.environ["LANGCHAIN_PROJECT"] == "my-project"
        assert os.environ["LANGCHAIN_TRACING_V2"] == "true"
