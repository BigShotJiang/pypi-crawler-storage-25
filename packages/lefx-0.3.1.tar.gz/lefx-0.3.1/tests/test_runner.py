"""Tests for lef.datasets.runner module."""

from __future__ import annotations

import uuid
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from lef.datasets.runner import (
    EvalRunner,
    _to_examples,
    arun_eval,
    create_dataset,
    run_comparative_eval,
    run_eval,
)


class TestToExamples:
    """Tests for _to_examples helper."""

    def test_converts_dicts_to_examples(self):
        data = [
            {"inputs": {"question": "Q1"}, "outputs": {"answer": "A1"}},
            {"inputs": {"question": "Q2"}, "outputs": {"answer": "A2"}},
        ]
        examples = _to_examples(data)
        assert len(examples) == 2
        assert examples[0].inputs == {"question": "Q1"}
        assert examples[0].outputs == {"answer": "A1"}
        assert examples[1].inputs == {"question": "Q2"}

    def test_handles_missing_outputs(self):
        data = [{"inputs": {"question": "Q1"}}]
        examples = _to_examples(data)
        assert examples[0].inputs == {"question": "Q1"}
        assert examples[0].outputs is None

    def test_flat_dict_treated_as_inputs(self):
        data = [{"question": "Q1", "answer": "A1"}]
        examples = _to_examples(data)
        assert examples[0].inputs == {"question": "Q1", "answer": "A1"}

    def test_each_example_gets_unique_id(self):
        data = [{"inputs": {"q": "1"}}, {"inputs": {"q": "2"}}]
        examples = _to_examples(data)
        assert examples[0].id != examples[1].id

    def test_reference_outputs_key_accepted(self):
        """Data dicts with 'reference_outputs' should be treated like 'outputs'."""
        data = [{"inputs": {"q": "Q1"}, "reference_outputs": {"answer": "A1"}}]
        examples = _to_examples(data)
        assert examples[0].outputs == {"answer": "A1"}

    def test_outputs_key_preferred_over_reference_outputs(self):
        """When both 'outputs' and 'reference_outputs' exist, 'outputs' wins."""
        data = [{"inputs": {"q": "Q1"}, "outputs": {"a": "A"}, "reference_outputs": {"a": "B"}}]
        examples = _to_examples(data)
        assert examples[0].outputs == {"a": "A"}

    def test_empty_list(self):
        assert _to_examples([]) == []


class TestCreateDataset:
    """Tests for create_dataset."""

    @patch("lef.datasets.runner.Client")
    def test_creates_new_dataset(self, mock_client_cls):
        from langsmith.utils import LangSmithNotFoundError

        client = MagicMock()
        client.read_dataset.side_effect = LangSmithNotFoundError("not found")
        mock_dataset = MagicMock()
        mock_dataset.id = uuid.uuid4()
        client.create_dataset.return_value = mock_dataset

        result = create_dataset(
            "test-dataset",
            examples=[{"inputs": {"q": "Q1"}, "outputs": {"a": "A1"}}],
            client=client,
        )

        assert result == str(mock_dataset.id)
        client.create_dataset.assert_called_once_with(dataset_name="test-dataset", description=None)
        client.create_example.assert_called_once()

    @patch("lef.datasets.runner.Client")
    def test_reuses_existing_dataset(self, mock_client_cls):
        client = MagicMock()
        mock_dataset = MagicMock()
        mock_dataset.id = uuid.uuid4()
        client.read_dataset.return_value = mock_dataset

        result = create_dataset(
            "existing-dataset",
            examples=[{"inputs": {"q": "Q1"}}],
            client=client,
        )

        assert result == str(mock_dataset.id)
        client.create_dataset.assert_not_called()

    @patch("lef.datasets.runner.Client")
    def test_flat_dicts_with_input_keys(self, mock_client_cls):
        client = MagicMock()
        mock_dataset = MagicMock()
        mock_dataset.id = uuid.uuid4()
        client.read_dataset.return_value = mock_dataset

        create_dataset(
            "ds",
            examples=[{"question": "Q1", "answer": "A1"}],
            input_keys=["question"],
            output_keys=["answer"],
            client=client,
        )

        call_kwargs = client.create_example.call_args
        assert call_kwargs.kwargs["inputs"] == {"question": "Q1"}
        assert call_kwargs.kwargs["outputs"] == {"answer": "A1"}


class TestRunEval:
    """Tests for run_eval."""

    @patch("lef.datasets.runner.evaluate")
    def test_run_eval_with_dataset_name(self, mock_evaluate):
        mock_evaluate.return_value = "results"
        target = MagicMock()

        result = run_eval(
            target,
            data="my-dataset",
            evaluators=[MagicMock()],
            experiment_prefix="test",
        )

        assert result == "results"
        call_kwargs = mock_evaluate.call_args.kwargs
        assert call_kwargs["data"] == "my-dataset"
        assert call_kwargs["experiment_prefix"] == "test"

    @patch("lef.datasets.runner.evaluate")
    def test_run_eval_with_local_data(self, mock_evaluate):
        mock_evaluate.return_value = "results"
        target = MagicMock()
        data = [{"inputs": {"q": "Q1"}, "outputs": {"a": "A1"}}]

        run_eval(target, data=data, evaluators=[MagicMock()])

        # Should convert to Example objects
        call_kwargs = mock_evaluate.call_args.kwargs
        assert call_kwargs["data"] is not data  # converted

    @patch("lef.datasets.runner.evaluate")
    def test_run_eval_no_upload(self, mock_evaluate):
        run_eval(
            MagicMock(),
            data="ds",
            evaluators=[MagicMock()],
            upload_results=False,
        )
        call_kwargs = mock_evaluate.call_args.kwargs
        assert call_kwargs["upload_results"] is False

    @patch("lef.datasets.runner.evaluate")
    def test_run_eval_with_summary_evaluators(self, mock_evaluate):
        summary_eval = MagicMock()
        run_eval(
            MagicMock(),
            data="ds",
            evaluators=[MagicMock()],
            summary_evaluators=[summary_eval],
        )
        call_kwargs = mock_evaluate.call_args.kwargs
        assert call_kwargs["summary_evaluators"] == [summary_eval]

    @patch("lef.datasets.runner.evaluate")
    def test_run_eval_repetitions(self, mock_evaluate):
        run_eval(
            MagicMock(),
            data="ds",
            evaluators=[MagicMock()],
            num_repetitions=3,
        )
        call_kwargs = mock_evaluate.call_args.kwargs
        assert call_kwargs["num_repetitions"] == 3


class TestArunEval:
    """Tests for arun_eval."""

    @patch("lef.datasets.runner.aevaluate")
    @pytest.mark.asyncio
    async def test_arun_eval_wraps_sync_target(self, mock_aevaluate):
        """Sync targets should be auto-wrapped for langsmith.aevaluate()."""
        mock_aevaluate.return_value = "results"

        def sync_target(inputs):
            return {"answer": "yes"}

        await arun_eval(
            sync_target,
            data=[{"inputs": {"q": "Q1"}, "outputs": {"a": "A1"}}],
            evaluators=[MagicMock()],
            upload_results=False,
        )

        # The target passed to aevaluate should be async (wrapped)
        call_args = mock_aevaluate.call_args
        actual_target = call_args[0][0]
        import asyncio

        assert asyncio.iscoroutinefunction(actual_target)

    @patch("lef.datasets.runner.aevaluate")
    @pytest.mark.asyncio
    async def test_arun_eval_preserves_async_target(self, mock_aevaluate):
        """Async targets should be passed through unchanged."""
        mock_aevaluate.return_value = "results"

        async def async_target(inputs):
            return {"answer": "yes"}

        await arun_eval(
            async_target,
            data="my-dataset",
            evaluators=[MagicMock()],
        )

        call_args = mock_aevaluate.call_args
        actual_target = call_args[0][0]
        assert actual_target is async_target

    @patch("lef.datasets.runner.aevaluate")
    @pytest.mark.asyncio
    async def test_arun_eval_with_local_data(self, mock_aevaluate):
        mock_aevaluate.return_value = "results"

        async def target(inputs):
            return {"answer": "yes"}

        data = [{"inputs": {"q": "Q1"}, "outputs": {"a": "A1"}}]
        await arun_eval(target, data=data, evaluators=[MagicMock()])

        call_kwargs = mock_aevaluate.call_args.kwargs
        assert call_kwargs["data"] is not data  # converted to Example objects


class TestRunComparativeEval:
    """Tests for run_comparative_eval."""

    @patch("lef.datasets.runner.evaluate_comparative")
    def test_comparative_eval(self, mock_eval_comp):
        mock_eval_comp.return_value = "comparison"
        result = run_comparative_eval(
            experiments=["exp-a", "exp-b"],
            evaluators=[MagicMock()],
        )
        assert result == "comparison"
        mock_eval_comp.assert_called_once()


class TestEvalRunner:
    """Tests for EvalRunner class."""

    def test_fluent_interface(self):
        runner = EvalRunner(dataset="my-dataset")
        eval1 = MagicMock()
        eval2 = MagicMock()
        result = runner.add_evaluator(eval1).add_evaluator(eval2)
        assert result is runner
        assert len(runner._evaluators) == 2

    def test_add_evaluators_batch(self):
        runner = EvalRunner(dataset="my-dataset")
        evals = [MagicMock(), MagicMock()]
        runner.add_evaluators(evals)
        assert len(runner._evaluators) == 2

    def test_add_summary_evaluator(self):
        runner = EvalRunner(dataset="my-dataset")
        summary = MagicMock()
        result = runner.add_summary_evaluator(summary)
        assert result is runner
        assert len(runner._summary_evaluators) == 1

    @patch("lef.datasets.runner.evaluate")
    def test_run(self, mock_evaluate):
        mock_evaluate.return_value = "results"
        runner = EvalRunner(dataset="my-dataset", experiment_prefix="test")
        runner.add_evaluator(MagicMock())

        result = runner.run(target=MagicMock())
        assert result == "results"

    @patch("lef.datasets.runner.aevaluate")
    @pytest.mark.asyncio
    async def test_arun(self, mock_aevaluate):
        mock_aevaluate.return_value = "async-results"
        runner = EvalRunner(dataset="my-dataset")
        runner.add_evaluator(MagicMock())

        result = await runner.arun(target=AsyncMock())
        assert result == "async-results"

    def test_default_values(self):
        runner = EvalRunner(dataset="ds")
        assert runner.experiment_prefix is None
        assert runner.upload_results is True
        assert runner.num_repetitions == 1
        assert runner.max_concurrency is None
        assert runner._evaluators == []
        assert runner._summary_evaluators == []
