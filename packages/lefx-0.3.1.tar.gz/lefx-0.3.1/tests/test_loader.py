"""Tests for LEF dataset loader (YAML, JSON, CSV)."""

import json

import pytest

from lef.datasets.loader import _normalize_examples, load_examples


@pytest.fixture
def tmp_dir(tmp_path):
    return tmp_path


class TestLoadExamplesJSON:
    def test_structured_format(self, tmp_dir):
        data = [
            {"inputs": {"question": "What is 2+2?"}, "outputs": {"answer": "4"}},
            {"inputs": {"question": "Capital of France?"}, "outputs": {"answer": "Paris"}},
        ]
        path = tmp_dir / "examples.json"
        path.write_text(json.dumps(data))

        result = load_examples(path)
        assert len(result) == 2
        assert result[0]["inputs"]["question"] == "What is 2+2?"
        assert result[0]["outputs"]["answer"] == "4"

    def test_with_examples_key(self, tmp_dir):
        data = {
            "examples": [
                {"inputs": {"q": "test"}, "outputs": {"a": "result"}},
            ]
        }
        path = tmp_dir / "examples.json"
        path.write_text(json.dumps(data))

        result = load_examples(path)
        assert len(result) == 1

    def test_flat_format_with_keys(self, tmp_dir):
        data = [
            {"question": "What is 2+2?", "answer": "4"},
            {"question": "Capital?", "answer": "Paris"},
        ]
        path = tmp_dir / "examples.json"
        path.write_text(json.dumps(data))

        result = load_examples(path, input_keys=["question"], output_keys=["answer"])
        assert len(result) == 2
        assert result[0]["inputs"] == {"question": "What is 2+2?"}
        assert result[0]["outputs"] == {"answer": "4"}

    def test_flat_format_no_keys(self, tmp_dir):
        data = [{"question": "test", "answer": "result"}]
        path = tmp_dir / "examples.json"
        path.write_text(json.dumps(data))

        result = load_examples(path)
        assert result[0]["inputs"] == {"question": "test", "answer": "result"}
        assert result[0]["outputs"] is None


class TestLoadExamplesCSV:
    def test_basic_csv(self, tmp_dir):
        csv_content = "question,answer\nWhat is 2+2?,4\nCapital?,Paris\n"
        path = tmp_dir / "examples.csv"
        path.write_text(csv_content)

        result = load_examples(path, input_keys=["question"], output_keys=["answer"])
        assert len(result) == 2
        assert result[0]["inputs"]["question"] == "What is 2+2?"
        assert result[0]["outputs"]["answer"] == "4"

    def test_csv_no_keys(self, tmp_dir):
        csv_content = "question,answer\ntest,result\n"
        path = tmp_dir / "examples.csv"
        path.write_text(csv_content)

        result = load_examples(path)
        assert result[0]["inputs"] == {"question": "test", "answer": "result"}


class TestLoadExamplesYAML:
    def test_yaml_loading(self, tmp_dir):
        yaml_content = """
- inputs:
    question: "What is 2+2?"
  outputs:
    answer: "4"
- inputs:
    question: "Capital of France?"
  outputs:
    answer: "Paris"
"""
        path = tmp_dir / "examples.yaml"
        path.write_text(yaml_content)

        try:
            result = load_examples(path)
            assert len(result) == 2
        except ImportError:
            pytest.skip("PyYAML not installed")

    def test_yml_extension(self, tmp_dir):
        yaml_content = "- inputs:\n    q: test\n"
        path = tmp_dir / "examples.yml"
        path.write_text(yaml_content)

        try:
            result = load_examples(path)
            assert len(result) == 1
        except ImportError:
            pytest.skip("PyYAML not installed")


class TestUnsupportedFormat:
    def test_unsupported_extension(self, tmp_dir):
        path = tmp_dir / "examples.txt"
        path.write_text("hello")

        with pytest.raises(ValueError, match="Unsupported file format"):
            load_examples(path)


class TestNormalizeExamples:
    def test_already_structured(self):
        raw = [{"inputs": {"q": "test"}, "outputs": {"a": "result"}}]
        result = _normalize_examples(raw)
        assert result[0]["inputs"] == {"q": "test"}
        assert result[0]["outputs"] == {"a": "result"}

    def test_flat_with_keys(self):
        raw = [{"question": "test", "answer": "result", "extra": "data"}]
        result = _normalize_examples(raw, input_keys=["question"], output_keys=["answer"])
        assert result[0]["inputs"] == {"question": "test"}
        assert result[0]["outputs"] == {"answer": "result"}

    def test_flat_no_keys(self):
        raw = [{"key": "value"}]
        result = _normalize_examples(raw)
        assert result[0]["inputs"] == {"key": "value"}
        assert result[0]["outputs"] is None

    def test_reference_outputs_key_accepted(self):
        raw = [{"inputs": {"q": "test"}, "reference_outputs": {"a": "result"}}]
        result = _normalize_examples(raw)
        assert result[0]["outputs"] == {"a": "result"}

    def test_outputs_preferred_over_reference_outputs(self):
        raw = [{"inputs": {"q": "test"}, "outputs": {"a": "A"}, "reference_outputs": {"a": "B"}}]
        result = _normalize_examples(raw)
        assert result[0]["outputs"] == {"a": "A"}
