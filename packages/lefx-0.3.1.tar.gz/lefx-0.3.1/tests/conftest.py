"""Shared test fixtures for LEF tests."""

import pytest


@pytest.fixture
def sample_inputs():
    return {"question": "What is the capital of France?"}


@pytest.fixture
def sample_outputs():
    return {"answer": "Paris"}


@pytest.fixture
def sample_reference_outputs():
    return {"answer": "Paris"}


@pytest.fixture
def wrong_outputs():
    return {"answer": "London"}


@pytest.fixture
def empty_outputs():
    return {"answer": ""}
