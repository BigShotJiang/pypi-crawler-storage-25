"""Tests for summary evaluators: pass_rate and mean_score."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from lef.scorers.builtin import mean_score, pass_rate


def _make_run(feedback_stats: dict | None = None) -> MagicMock:
    """Create a mock run with feedback_stats."""
    run = MagicMock()
    if feedback_stats is not None:
        run.feedback_stats = feedback_stats
    else:
        # Simulate a run with no feedback_stats attribute
        del run.feedback_stats
    return run


class TestPassRate:
    """Tests for pass_rate summary evaluator."""

    def test_all_passing(self):
        summary = pass_rate(threshold=0.5)
        runs = [
            _make_run({"correctness": {"avg": 1.0}, "safety": {"avg": 0.9}}),
            _make_run({"correctness": {"avg": 0.8}, "safety": {"avg": 1.0}}),
        ]
        result = summary(runs, [])
        assert result["key"] == "pass_rate"
        assert result["score"] == 1.0

    def test_some_failing(self):
        summary = pass_rate(threshold=0.8)
        runs = [
            _make_run({"correctness": {"avg": 1.0}}),
            _make_run({"correctness": {"avg": 0.5}}),  # below threshold
        ]
        result = summary(runs, [])
        assert result["key"] == "pass_rate"
        assert result["score"] == 0.5

    def test_all_failing(self):
        summary = pass_rate(threshold=1.0)
        runs = [
            _make_run({"correctness": {"avg": 0.5}}),
            _make_run({"correctness": {"avg": 0.3}}),
        ]
        result = summary(runs, [])
        assert result["score"] == 0.0

    def test_empty_runs(self):
        summary = pass_rate()
        result = summary([], [])
        assert result["score"] == 0.0

    def test_no_feedback_counts_as_failing(self):
        """Runs with no feedback are treated as failing (conservative)."""
        summary = pass_rate()
        runs = [
            _make_run({}),  # empty feedback dict
            _make_run({"correctness": {"avg": 1.0}}),
        ]
        result = summary(runs, [])
        assert result["score"] == 0.5

    def test_custom_key(self):
        summary = pass_rate(key="my_pass_rate")
        result = summary([_make_run({})], [])
        assert result["key"] == "my_pass_rate"

    def test_default_threshold_is_1(self):
        """Default threshold=1.0 means only perfect scores pass."""
        summary = pass_rate()
        runs = [
            _make_run({"correctness": {"avg": 0.99}}),
        ]
        result = summary(runs, [])
        assert result["score"] == 0.0  # 0.99 < 1.0

    def test_scalar_feedback_values(self):
        """Feedback values can be plain floats instead of dicts."""
        summary = pass_rate(threshold=0.5)
        runs = [
            _make_run({"correctness": 0.8}),
            _make_run({"correctness": 0.3}),  # below 0.5
        ]
        result = summary(runs, [])
        assert result["score"] == 0.5

    def test_no_feedback_stats_attribute(self):
        """Runs without feedback_stats attribute count as failing (conservative)."""
        summary = pass_rate()
        run = MagicMock(spec=[])  # no attributes at all
        result = summary([run], [])
        # hasattr check returns False, feedback={}, empty -> failing
        assert result["score"] == 0.0


class TestMeanScore:
    """Tests for mean_score summary evaluator."""

    def test_basic_mean(self):
        summary = mean_score("correctness")
        runs = [
            _make_run({"correctness": {"avg": 1.0}}),
            _make_run({"correctness": {"avg": 0.5}}),
        ]
        result = summary(runs, [])
        assert result["key"] == "correctness_mean"
        assert result["score"] == 0.75

    def test_custom_key(self):
        summary = mean_score("correctness", key="my_custom_mean")
        runs = [_make_run({"correctness": {"avg": 0.8}})]
        result = summary(runs, [])
        assert result["key"] == "my_custom_mean"

    def test_missing_scorer_key(self):
        """When no runs have the requested scorer key, score is 0.0."""
        summary = mean_score("nonexistent_key")
        runs = [
            _make_run({"correctness": {"avg": 1.0}}),
        ]
        result = summary(runs, [])
        assert result["score"] == 0.0
        assert "No 'nonexistent_key' scores found" in result["comment"]

    def test_empty_runs(self):
        summary = mean_score("correctness")
        result = summary([], [])
        assert result["score"] == 0.0

    def test_partial_runs_with_scorer_key(self):
        """Only runs that have the scorer key should be included in the mean."""
        summary = mean_score("correctness")
        runs = [
            _make_run({"correctness": {"avg": 0.6}}),
            _make_run({"safety": {"avg": 1.0}}),  # no correctness
            _make_run({"correctness": {"avg": 0.4}}),
        ]
        result = summary(runs, [])
        assert result["score"] == 0.5  # mean of 0.6 and 0.4
        assert "2" in result["comment"]  # "Mean of 2 'correctness' scores"

    def test_scalar_feedback_values(self):
        """Feedback values can be plain floats instead of dicts."""
        summary = mean_score("quality")
        runs = [
            _make_run({"quality": 0.9}),
            _make_run({"quality": 0.7}),
        ]
        result = summary(runs, [])
        assert result["score"] == pytest.approx(0.8)

    def test_default_key_format(self):
        """Default key should be '{scorer_key}_mean'."""
        summary = mean_score("safety")
        runs = [_make_run({"safety": {"avg": 1.0}})]
        result = summary(runs, [])
        assert result["key"] == "safety_mean"

    def test_no_feedback_stats_attribute(self):
        """Runs without feedback_stats attribute are skipped."""
        summary = mean_score("correctness")
        run = MagicMock(spec=[])  # no attributes
        result = summary([run], [])
        assert result["score"] == 0.0
