"""Tests for lef.integrations.remote module."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from lef.integrations.remote import (
    create_async_remote_target,
    create_remote_target,
)


class TestCreateRemoteTarget:
    @patch("lef.integrations.remote._http_post")
    def test_default_body_and_output(self, mock_post):
        mock_post.return_value = {"output": {"answer": "42"}}

        target = create_remote_target("https://example.com/invoke")
        result = target({"question": "What is 6*7?"})

        assert result == {"answer": "42"}
        mock_post.assert_called_once_with(
            "https://example.com/invoke",
            json_body={"input": {"question": "What is 6*7?"}},
            headers=None,
            timeout=60.0,
        )

    @patch("lef.integrations.remote._http_post")
    def test_with_headers(self, mock_post):
        mock_post.return_value = {"output": "ok"}

        target = create_remote_target(
            "https://example.com/invoke",
            headers={"x-api-key": "secret"},
        )
        target({"q": "test"})

        call_kwargs = mock_post.call_args
        assert call_kwargs.kwargs["headers"] == {"x-api-key": "secret"}

    @patch("lef.integrations.remote._http_post")
    def test_with_input_mapper(self, mock_post):
        mock_post.return_value = {"output": {"answer": "yes"}}

        target = create_remote_target(
            "https://example.com/invoke",
            input_mapper=lambda inputs: {
                "input": {"messages": [{"role": "user", "content": inputs["question"]}]}
            },
        )
        target({"question": "Hello?"})

        body = mock_post.call_args.kwargs["json_body"]
        assert body == {"input": {"messages": [{"role": "user", "content": "Hello?"}]}}

    @patch("lef.integrations.remote._http_post")
    def test_with_output_mapper(self, mock_post):
        mock_post.return_value = {
            "output": {"messages": [{"content": "The answer is 42"}]},
        }

        target = create_remote_target(
            "https://example.com/invoke",
            output_mapper=lambda resp: {"answer": resp["output"]["messages"][-1]["content"]},
        )
        result = target({"question": "test"})

        assert result == {"answer": "The answer is 42"}

    @patch("lef.integrations.remote._http_post")
    def test_string_output(self, mock_post):
        mock_post.return_value = {"output": "plain text"}

        target = create_remote_target("https://example.com/invoke")
        result = target({"q": "test"})

        assert result == {"answer": "plain text"}

    @patch("lef.integrations.remote._http_post")
    def test_dict_response_without_output_key(self, mock_post):
        mock_post.return_value = {"answer": "42", "confidence": 0.95}

        target = create_remote_target("https://example.com/invoke")
        result = target({"q": "test"})

        assert result == {"answer": "42", "confidence": 0.95}

    @patch("lef.integrations.remote._http_post")
    def test_custom_timeout(self, mock_post):
        mock_post.return_value = {"output": "ok"}

        target = create_remote_target("https://example.com/invoke", timeout=120.0)
        target({"q": "test"})

        assert mock_post.call_args.kwargs["timeout"] == 120.0


class TestCreateAsyncRemoteTarget:
    @patch("lef.integrations.remote._async_http_post")
    @pytest.mark.asyncio
    async def test_basic(self, mock_post):
        mock_post.return_value = {"output": {"answer": "yes"}}

        target = create_async_remote_target("https://example.com/invoke")
        result = await target({"q": "test"})

        assert result == {"answer": "yes"}

    @patch("lef.integrations.remote._async_http_post")
    @pytest.mark.asyncio
    async def test_with_mappers(self, mock_post):
        mock_post.return_value = {"result": "mapped"}

        target = create_async_remote_target(
            "https://example.com/invoke",
            input_mapper=lambda x: {"custom": x},
            output_mapper=lambda r: {"answer": r["result"]},
        )
        result = await target({"q": "test"})

        assert result == {"answer": "mapped"}
