"""Tests for LEF threshold/assertion helpers."""

import pytest

from lef.assertions import EvalAssertionError, assert_scores, check_scores
from lef.core.types import EvalResult, EvalResultBatch


class TestAssertScores:
    def test_passing_thresholds(self):
        results = [
            EvalResult(key="accuracy", score=0.9),
            EvalResult(key="accuracy", score=0.85),
        ]
        # Should not raise
        assert_scores(results, {"accuracy": 0.8})

    def test_failing_threshold(self):
        results = [
            EvalResult(key="accuracy", score=0.5),
            EvalResult(key="accuracy", score=0.6),
        ]
        with pytest.raises(EvalAssertionError) as exc_info:
            assert_scores(results, {"accuracy": 0.8})
        assert len(exc_info.value.failures) == 1
        assert exc_info.value.failures[0]["key"] == "accuracy"

    def test_missing_key(self):
        results = [EvalResult(key="accuracy", score=0.9)]
        with pytest.raises(EvalAssertionError):
            assert_scores(results, {"safety": 0.8})

    def test_with_eval_result_batch(self):
        batch = EvalResultBatch(
            results=[
                EvalResult(key="accuracy", score=0.9),
                EvalResult(key="accuracy", score=0.95),
            ]
        )
        assert_scores(batch, {"accuracy": 0.8})

    def test_with_dict_results(self):
        results = [
            {"key": "accuracy", "score": 0.9},
            {"key": "accuracy", "score": 0.8},
        ]
        assert_scores(results, {"accuracy": 0.8})

    def test_bool_scores(self):
        results = [
            EvalResult(key="pass", score=True),
            EvalResult(key="pass", score=True),
            EvalResult(key="pass", score=False),
        ]
        # Average is ~0.67
        with pytest.raises(EvalAssertionError):
            assert_scores(results, {"pass": 0.8})

    def test_multiple_thresholds(self):
        results = [
            EvalResult(key="accuracy", score=0.9),
            EvalResult(key="safety", score=0.5),
        ]
        with pytest.raises(EvalAssertionError) as exc_info:
            assert_scores(results, {"accuracy": 0.8, "safety": 0.9})
        assert len(exc_info.value.failures) == 1
        assert exc_info.value.failures[0]["key"] == "safety"

    def test_error_message_format(self):
        results = [EvalResult(key="accuracy", score=0.5)]
        with pytest.raises(EvalAssertionError, match="Evaluation thresholds not met"):
            assert_scores(results, {"accuracy": 0.8})


class TestCheckScores:
    def test_passing(self):
        results = [EvalResult(key="accuracy", score=0.9)]
        report = check_scores(results, {"accuracy": 0.8})
        assert report["accuracy"]["passed"] is True
        assert report["accuracy"]["actual"] == 0.9

    def test_failing(self):
        results = [EvalResult(key="accuracy", score=0.5)]
        report = check_scores(results, {"accuracy": 0.8})
        assert report["accuracy"]["passed"] is False
        assert report["accuracy"]["actual"] == 0.5
        assert report["accuracy"]["threshold"] == 0.8

    def test_missing_key_defaults_zero(self):
        results = [EvalResult(key="accuracy", score=0.9)]
        report = check_scores(results, {"safety": 0.5})
        assert report["safety"]["passed"] is False
        assert report["safety"]["actual"] == 0.0


class TestExperimentResultsFormat:
    """Test assertions work with LangSmith ExperimentResults-like structures."""

    def test_experiment_result_rows(self):
        """assert_scores should handle ExperimentResultRow dicts."""
        # Simulate what LangSmith ExperimentResults yields
        mock_rows = [
            {
                "run": None,
                "example": None,
                "evaluation_results": {
                    "results": [
                        type("ER", (), {"key": "correctness", "score": 0.9})(),
                        type("ER", (), {"key": "safety", "score": 1.0})(),
                    ]
                },
            },
            {
                "run": None,
                "example": None,
                "evaluation_results": {
                    "results": [
                        type("ER", (), {"key": "correctness", "score": 0.8})(),
                        type("ER", (), {"key": "safety", "score": 0.9})(),
                    ]
                },
            },
        ]
        # Should pass
        assert_scores(mock_rows, {"correctness": 0.8, "safety": 0.9})

        # Should fail
        with pytest.raises(EvalAssertionError):
            assert_scores(mock_rows, {"correctness": 0.9})

    def test_objects_with_key_and_score_attrs(self):
        """assert_scores should handle objects with key/score attributes."""
        mock_results = [
            type("Result", (), {"key": "test", "score": 0.85})(),
            type("Result", (), {"key": "test", "score": 0.95})(),
        ]
        assert_scores(mock_results, {"test": 0.8})
