"""Tests for LEF config integration: set_config/get_config and runner fallback."""

from __future__ import annotations

from unittest.mock import MagicMock

import lef.config as config_module
from lef.config import LefConfig, get_config, set_config
from lef.core.types import JudgeModel
from lef.datasets.runner import _build_eval_kwargs


class TestSetGetConfig:
    """Tests for set_config and get_config."""

    def setup_method(self):
        """Reset global config before each test."""
        config_module._active_config = None

    def teardown_method(self):
        """Clean up global config after each test."""
        config_module._active_config = None

    def test_get_config_returns_none_by_default(self):
        assert get_config() is None

    def test_set_config_then_get(self):
        cfg = LefConfig(max_concurrency=10)
        set_config(cfg)
        assert get_config() is cfg
        assert get_config().max_concurrency == 10

    def test_set_config_overwrites_previous(self):
        cfg1 = LefConfig(max_concurrency=3)
        cfg2 = LefConfig(max_concurrency=20)
        set_config(cfg1)
        set_config(cfg2)
        assert get_config() is cfg2
        assert get_config().max_concurrency == 20

    def test_apply_sets_active_config(self, monkeypatch):
        # Prevent actual env var side-effects from leaking
        monkeypatch.setenv("LANGCHAIN_PROJECT", "default")
        monkeypatch.setenv("LANGCHAIN_TRACING_V2", "true")

        cfg = LefConfig(max_concurrency=7, langsmith_api_key="test-key-123")
        cfg.apply()
        assert get_config() is cfg

    def test_apply_sets_env_vars(self, monkeypatch):
        monkeypatch.setenv("LANGCHAIN_PROJECT", "old-project")
        monkeypatch.setenv("LANGCHAIN_TRACING_V2", "false")

        import os

        cfg = LefConfig(
            langsmith_api_key="my-key",
            langsmith_project="new-project",
            tracing_enabled=True,
        )
        cfg.apply()

        assert os.environ["LANGCHAIN_API_KEY"] == "my-key"
        assert os.environ["LANGCHAIN_PROJECT"] == "new-project"
        assert os.environ["LANGCHAIN_TRACING_V2"] == "true"

    def test_config_preserves_all_fields(self):
        cfg = LefConfig(
            langsmith_api_key="key",
            langsmith_project="proj",
            tracing_enabled=False,
            default_judge_model=JudgeModel.CLAUDE_SONNET,
            max_concurrency=42,
        )
        set_config(cfg)
        active = get_config()
        assert active.langsmith_api_key == "key"
        assert active.langsmith_project == "proj"
        assert active.tracing_enabled is False
        assert active.default_judge_model == JudgeModel.CLAUDE_SONNET
        assert active.max_concurrency == 42


class TestBuildEvalKwargsConfigFallback:
    """Tests for _build_eval_kwargs using active config for max_concurrency."""

    def setup_method(self):
        config_module._active_config = None

    def teardown_method(self):
        config_module._active_config = None

    def test_no_config_no_explicit_concurrency(self):
        """When no config and no explicit max_concurrency, should be None."""
        kwargs = _build_eval_kwargs(
            data="my-dataset",
            evaluators=[MagicMock()],
        )
        assert kwargs["max_concurrency"] is None

    def test_falls_back_to_config_max_concurrency(self):
        """When config is set and max_concurrency not explicit, use config value."""
        cfg = LefConfig(max_concurrency=15)
        set_config(cfg)

        kwargs = _build_eval_kwargs(
            data="my-dataset",
            evaluators=[MagicMock()],
        )
        assert kwargs["max_concurrency"] == 15

    def test_explicit_concurrency_overrides_config(self):
        """Explicit max_concurrency should take precedence over config."""
        cfg = LefConfig(max_concurrency=15)
        set_config(cfg)

        kwargs = _build_eval_kwargs(
            data="my-dataset",
            evaluators=[MagicMock()],
            max_concurrency=3,
        )
        assert kwargs["max_concurrency"] == 3

    def test_explicit_zero_concurrency_not_overridden(self):
        """Explicit max_concurrency=0 should not trigger config fallback.

        Note: 0 is falsy but not None, so it should not be replaced.
        """
        cfg = LefConfig(max_concurrency=15)
        set_config(cfg)

        # 0 is not None so the fallback should NOT kick in
        kwargs = _build_eval_kwargs(
            data="my-dataset",
            evaluators=[MagicMock()],
            max_concurrency=0,
        )
        assert kwargs["max_concurrency"] == 0

    def test_config_default_max_concurrency_is_5(self):
        """The default LefConfig max_concurrency is 5."""
        cfg = LefConfig()
        set_config(cfg)

        kwargs = _build_eval_kwargs(
            data="my-dataset",
            evaluators=[MagicMock()],
        )
        assert kwargs["max_concurrency"] == 5
