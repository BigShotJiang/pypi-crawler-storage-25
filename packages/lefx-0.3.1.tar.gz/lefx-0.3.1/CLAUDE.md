# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What is this project?

LEF (LangSmith Evaluation Framework) is a plug-and-play evaluation system for LangChain, LangGraph, and LangSmith projects. It wraps `langsmith`, `openevals`, and `agentevals` into a unified framework with built-in QA/CI support.

**PyPI package:** `lefx` (install with `pip install lefx`, import with `import lef`)

## Common Commands

```bash
# Install dependencies
uv sync --extra dev --extra all

# Run all tests
uv run pytest

# Run a single test file
uv run pytest tests/test_scorers.py

# Run a single test by name
uv run pytest tests/test_scorers.py -k "test_exact_match"

# Lint
uv run ruff check src/ tests/

# Lint with auto-fix
uv run ruff check --fix src/ tests/

# Format
uv run ruff format src/ tests/

# Type check
uv run mypy src/

# Run the CLI
uv run lef run <config.yaml>
```

## Using LEF for Evaluations (AI Quick Reference)

LEF is designed to be easy for AI agents to use. Here are the most common patterns:

### Evaluate a function against a local dataset

```python
from lef import run_eval, exact_match, correctness_judge, check_scores

results = run_eval(
    target=lambda inputs: {"answer": my_chain.invoke(inputs)},
    data="path/to/dataset.yaml",          # YAML/JSON/CSV or LangSmith dataset name
    evaluators=[exact_match, correctness_judge()],
    upload_results=False,                  # set True to upload to LangSmith
)

# Check pass/fail
report = check_scores(results, {"correctness": 0.8})
all_passed = all(v["passed"] for v in report.values())
```

### Test a deployed HTTP endpoint

```python
from lef import create_remote_target, run_eval, export_markdown, correctness_judge

target = create_remote_target(
    "https://my-endpoint.com/invoke",
    headers={"Authorization": "Bearer ..."},
    input_mapper=lambda inputs: {"query": inputs["question"]},
    output_mapper=lambda resp: {"answer": resp["response"]},
)
results = run_eval(target, data="qa_data.yaml", evaluators=[correctness_judge()])
export_markdown(results, "report.md", thresholds={"correctness": 0.8})
```

### Create a custom scorer

```python
from lef import scorer

@scorer(key="is_valid")
def is_valid(*, outputs, **kwargs) -> bool:
    return bool(outputs.get("answer", "").strip())
```

### YAML dataset format

```yaml
- inputs:
    question: "What is Python?"
  outputs:
    answer: "A programming language"
```

### CLI usage

```bash
lef run eval_config.yaml --output report.md --threshold correctness=0.8
lef qa https://endpoint/invoke --data data.yaml --output report.md
```

### Key imports cheatsheet

| Task | Import |
|------|--------|
| Run evals | `from lef import run_eval, arun_eval` |
| Built-in scorers | `from lef import exact_match, contains, regex_match, json_match` |
| LLM judges | `from lef import correctness_judge, safety_judge, hallucination_judge` |
| Custom scorer | `from lef import scorer` |
| Assertions | `from lef import assert_scores, check_scores` |
| Remote target | `from lef import create_remote_target` |
| Export | `from lef import export_markdown, export_json, export_csv, export_junit_xml` |
| Baselines | `from lef import save_baseline, load_baseline, compare_results` |
| Load local data | `from lef import load_examples` |

## Architecture

Source lives in `src/lef/`. All public API is exported from `src/lef/__init__.py` via `__all__` (85 exports).

### Key design decisions

- **EvalResult is a `dict` subclass** (not a Pydantic model) — this is required because LangSmith's `evaluate()` expects dict-like results. It also provides property access (`.key`, `.score`, `.comment`, `.metadata`).
- **Dual-signature compatibility** — all evaluators accept both LangSmith's legacy `(run, example)` and new-style `(inputs=, outputs=, reference_outputs=)` keyword signatures. The `@scorer` decorator in `core/decorators.py` handles this normalization.
- **Decorators normalize return types** — `@scorer` accepts `bool`, `float`, `int`, `dict`, or `EvalResult` returns and always produces a LangSmith-compatible dict.
- **openevals judges are thin wrappers** — `judges/llm.py` factory functions (e.g., `correctness_judge()`) wrap `openevals.create_llm_as_judge()` with LEF defaults and return callables.
- **Local datasets don't need LangSmith** — `load_examples()` from `datasets/loader.py` supports YAML/JSON/CSV. Combined with `upload_results=False`, evaluation runs fully offline.

### Module layout

**Core:**
- `core/types.py` — `EvalResult`, `EvalResultBatch`, `JudgeModel` enum, evaluator protocols
- `core/base.py` — `BaseEvaluator`, `AsyncBaseEvaluator` abstract classes
- `core/decorators.py` — `@scorer` and `@evaluator` decorators

**Scorers & Judges:**
- `scorers/builtin.py` — Rule-based scorers: `exact_match`, `contains`, `regex_match`, `json_match`, `mean_score`, `pass_rate`
- `scorers/custom.py` — `create_scorer`, `create_composite_scorer` factories
- `judges/llm.py` — 20+ LLM-as-judge factories (correctness, safety, hallucination, RAG, etc.)
- `judges/trajectory.py` — Agent trajectory evaluators wrapping `agentevals`

**Data & Runner:**
- `datasets/runner.py` — `run_eval`, `arun_eval`, `EvalRunner`, `create_dataset`
- `datasets/loader.py` — `load_examples` for local YAML/JSON/CSV files

**CLI:**
- `cli.py` — CLI entry point with 7 subcommands: `run`, `compare`, `baseline`, `qa`, `monitor`, `redteam`, `dataset`

**Integrations:**
- `integrations/langchain.py` — LangChain chain evaluation
- `integrations/langgraph.py` — LangGraph graph evaluation
- `integrations/remote.py` — HTTP endpoint targets (`create_remote_target`)

**Output & Export:**
- `output.py` — Terminal tables + JSON/CSV/JUnit XML/Markdown export
- `compare.py` — Baseline management and experiment comparison
- `assertions.py` — Threshold assertions for CI gating (`assert_scores`, `check_scores`)

**Operations:**
- `git_context.py` — Git-aware experiment metadata (branch, commit, CI detection)
- `cache.py` — Content-addressable result caching with TTL
- `watch.py` — File-watching mode for iterative development
- `ci/github.py` — GitHub PR comment integration
- `ci/azuredevops.py` — Azure DevOps PR comment integration
- `pytest_plugin.py` — pytest plugin with `lef_eval` fixture (entry point: `pytest11`)
- `synthetic.py` — Synthetic dataset generation from documents/traces
- `monitor.py` — Production monitoring daemon with threshold alerting
- `redteam.py` — Adversarial red-team testing with 6 attack categories
- `online/tracing.py` — Online evaluation of production LangSmith runs

## Testing

- All tests in `tests/`, using pytest with `asyncio_mode = "auto"` (no need for `@pytest.mark.asyncio`)
- Tests mock LLM APIs via `unittest.mock.patch` — no real API calls needed
- Shared fixtures in `tests/conftest.py`: `sample_inputs`, `sample_outputs`, `sample_reference_outputs`, `wrong_outputs`, `empty_outputs`

## When Adding New Evaluators

1. Add the factory function to `src/lef/judges/llm.py` (for LLM judges) or `src/lef/scorers/builtin.py` (for rule-based)
2. Export from the sub-package `__init__.py`
3. Export from the top-level `src/lef/__init__.py` and add to `__all__`
4. Add to `_BUILTIN_EVALUATORS` in `src/lef/cli.py` for CLI support
5. Add tests in `tests/`
6. Update the README table
