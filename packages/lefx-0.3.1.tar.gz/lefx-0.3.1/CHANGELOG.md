# Changelog

All notable changes to LEF will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.1] - 2026-04-01

### Added
- **Markdown export**: `export_markdown()` generates human-readable reports with summary tables, per-example results, and pass/fail threshold indicators
- **AI-friendly quick reference**: README and CLAUDE.md include copy-paste patterns for Claude Code and AI assistants
- **QA endpoint example**: Complete working example for testing deployed endpoints (`examples/qa_endpoint_eval.py`)
- **QA dataset example**: Sample YAML dataset for endpoint testing (`examples/qa_dataset.yaml`)
- **QA config example**: CLI config for endpoint evaluation (`examples/qa_endpoint_suite.yaml`)
- **Key imports cheatsheet**: CLAUDE.md includes quick lookup table for common imports
- 85 public API exports (up from 84)

### Changed
- Renamed PyPI package from `lef` to `lefx` (install with `pip install lefx`, import remains `import lef`)
- `export_results()` now auto-detects `.md` extension for Markdown export
- CLI `--output` flag now supports `.md` files across `run` and `qa` subcommands
- Updated all examples and docs to reference `lefx` install name

## [0.2.0] - 2026-03-28

### Added
- **Result export**: JSON, CSV, and JUnit XML export via `--output` flag and `export_results()` API
- **Rich terminal output**: `format_results_table()` with per-metric summary, min/max/avg, and threshold pass/fail
- **Git-aware metadata**: Auto-injects branch, commit SHA, author into experiment metadata; detects CI environments (GitHub Actions, Azure DevOps, GitLab CI, Jenkins)
- **Baseline management**: `save_baseline()`, `load_baseline()`, `compare_results()` for regression detection; `lef baseline list/delete` CLI
- **Experiment comparison**: `ComparisonReport` with table/markdown output and `compare_experiments()` for LangSmith experiments
- **Result caching**: `ResultCache` with content-addressable hashing and TTL for avoiding re-invocation of expensive targets
- **Watch mode**: `--watch` flag for auto-rerun on file changes during iterative development
- **CI/CD PR comments**: `post_github_comment()` and `post_azdo_comment()` for posting results to GitHub and Azure DevOps PRs
- **QA endpoint testing**: `lef qa` subcommand for testing deployed HTTP endpoints against datasets
- **pytest plugin**: `lef_eval` fixture and config-file collection via `pytest11` entry point
- **Synthetic data generation**: `generate_from_docs()`, `generate_from_traces()`, `generate_adversarial()`, `diversify_dataset()`
- **Production monitoring**: `MonitorDaemon` for continuous evaluation of LangSmith runs with threshold alerting
- **Red-team testing**: `run_redteam()` with 6 attack categories (prompt injection, jailbreak, PII extraction, hallucination inducement, toxicity, bias) and 3 built-in safety scorers
- **Remote targets**: HTTP URLs supported as targets in config files via `create_remote_target()`
- **File path targets**: Target functions can be referenced by file path (`/path/to/file.py:function`)
- **Multi-config composition**: Pass multiple YAML configs to merge evaluators, thresholds, and metadata
- **CLI subcommands**: `compare`, `baseline`, `qa`, `monitor`, `redteam`, `dataset` (pull/push/diff/generate)
- **`--version` flag**: `lef -v` / `lef --version` shows version
- `py.typed` marker for PEP 561 type information
- 84 public API exports (up from 52)

### Fixed
- Outputs kwarg override bug in dual-signature resolution across decorators and base classes
- `pass_rate` treating missing feedback as passing (now correctly treats as failing)
- Client reuse in `online/tracing.py` (singleton default client avoids per-call overhead)
- GitHub API URL for comment updates (was missing `/issues/` path segment)
- Monitor `_seen_run_ids` used unordered set for eviction (now uses OrderedDict)
- `compare_results()` now handles baseline dict format for both parameters
- `_load_config()` rejects non-dict YAML (empty files, arrays) with clear error
- Malformed config files produce clean error messages instead of raw tracebacks
- Duplicate `-v`/`--verbose` flag between parent and run subparser
- `lef` with no arguments now exits with code 2 (was incorrectly 0)

### Changed
- Version bumped to 0.2.0
- Development Status classifier changed from Alpha to Beta
- `-v` flag changed from `--verbose` to `--version` (use `--verbose` for debug logging)
- `pyproject.toml` extras now use self-references to avoid duplicate version pins

## [0.1.0] - 2024-12-01

### Added
- Core evaluation framework with `EvalResult`, `EvalResultBatch`, and `JudgeModel` types
- `@scorer` and `@evaluator` decorators for creating LangSmith-compatible evaluators
- Built-in scorers: `exact_match`, `contains`, `regex_match`, `json_match`
- Custom scorer factories: `create_scorer`, `create_composite_scorer`
- 14 pre-built LLM-as-Judge evaluators (correctness, safety, hallucination, RAG, etc.)
- Custom judge creation via `create_judge()` with openevals integration
- Agent trajectory evaluation via `create_trajectory_evaluator` and `create_trajectory_judge`
- Dataset runner: `run_eval`, `arun_eval`, `EvalRunner`, `create_dataset`
- Local dataset loading from YAML, JSON, and CSV files
- Online evaluation: `evaluate_run`, `OnlineEvaluator`, `create_rule`
- LangChain integration: `evaluate_chain`, `create_chain_target` (sync + async)
- LangGraph integration: `evaluate_graph`, `create_graph_target` (sync + async)
- CI/CD gating with `assert_scores` and `check_scores`
- CLI tool (`lef run`) for running evaluation suites from config files
- `LefConfig` for environment-based configuration
- Dual-signature compatibility (legacy `run, example` and new-style kwargs)
- 222 tests with full mocking (no API calls required)
- Comprehensive README with quick-start examples and API reference
