"""Continuous monitoring daemon for production evaluation.

Polls LangSmith for new runs and evaluates them on a schedule,
with support for alerting when scores drop below thresholds.
"""

from __future__ import annotations

import asyncio
import collections
import logging
import signal
import sys
import time
from collections.abc import Callable, Sequence
from typing import Any

from langsmith import Client

from lef.online.tracing import evaluate_run

logger = logging.getLogger(__name__)


class MonitorDaemon:
    """Long-running evaluation monitor for production LangSmith projects.

    Continuously polls for new runs and evaluates them, tracking scores
    and triggering alerts when thresholds are violated.

    Example::

        from lef.judges import safety_judge, correctness_judge

        monitor = MonitorDaemon(
            project_name="my-chatbot",
            evaluators=[safety_judge(), correctness_judge()],
            thresholds={"safety": 0.9, "correctness": 0.7},
            poll_interval=60,
        )
        monitor.add_alert_handler(lambda alert: print(f"ALERT: {alert}"))
        monitor.run()  # Blocks until interrupted
    """

    def __init__(
        self,
        *,
        project_name: str,
        evaluators: Sequence[Callable[..., Any]],
        thresholds: dict[str, float] | None = None,
        poll_interval: float = 60.0,
        batch_size: int = 20,
        run_type: str | None = None,
        client: Client | None = None,
    ):
        self.project_name = project_name
        self.evaluators = list(evaluators)
        self.thresholds = thresholds or {}
        self.poll_interval = poll_interval
        self.batch_size = batch_size
        self.run_type = run_type
        self.client = client or Client()
        self._alert_handlers: list[Callable[[dict[str, Any]], Any]] = []
        self._seen_run_ids: collections.OrderedDict[str, None] = collections.OrderedDict()
        self._score_history: dict[str, list[float]] = {}
        self._running = False
        self._total_evaluated = 0

    def add_alert_handler(self, handler: Callable[[dict[str, Any]], Any]) -> MonitorDaemon:
        """Register an alert callback. Returns self for chaining.

        The handler receives a dict with:
            - type: "threshold_violation" | "score_drop"
            - key: metric name
            - score: current score
            - threshold: configured threshold (if applicable)
            - message: human-readable alert message
        """
        self._alert_handlers.append(handler)
        return self

    def run(self) -> None:
        """Run the monitor synchronously. Blocks until Ctrl+C."""
        self._running = True

        def _handle_signal(sig: int, frame: Any) -> None:
            print("\nStopping monitor...")
            self._running = False

        signal.signal(signal.SIGINT, _handle_signal)
        signal.signal(signal.SIGTERM, _handle_signal)

        print(f"LEF Monitor started for project '{self.project_name}'")
        print(f"  Evaluators: {len(self.evaluators)}")
        print(f"  Thresholds: {self.thresholds or 'none'}")
        print(f"  Poll interval: {self.poll_interval}s")
        print(f"  Batch size: {self.batch_size}")
        print("Press Ctrl+C to stop.\n")

        while self._running:
            try:
                self._poll_and_evaluate()
            except Exception as exc:
                logger.error("Monitor poll error: %s", exc)
                print(f"Error during poll: {exc}", file=sys.stderr)

            # Sleep in small intervals so we can respond to signals
            elapsed = 0.0
            while elapsed < self.poll_interval and self._running:
                time.sleep(min(1.0, self.poll_interval - elapsed))
                elapsed += 1.0

        print(f"\nMonitor stopped. Total runs evaluated: {self._total_evaluated}")

    async def arun(self) -> None:
        """Run the monitor asynchronously."""
        self._running = True

        print(f"LEF Monitor started for project '{self.project_name}'")
        print(f"  Evaluators: {len(self.evaluators)}")
        print(f"  Poll interval: {self.poll_interval}s")
        print("Press Ctrl+C to stop.\n")

        try:
            while self._running:
                try:
                    await asyncio.to_thread(self._poll_and_evaluate)
                except Exception as exc:
                    logger.error("Monitor poll error: %s", exc)
                await asyncio.sleep(self.poll_interval)
        except asyncio.CancelledError:
            pass

        print(f"\nMonitor stopped. Total runs evaluated: {self._total_evaluated}")

    def _poll_and_evaluate(self) -> None:
        """Poll for new runs and evaluate them."""
        runs = list(
            self.client.list_runs(
                project_name=self.project_name,
                limit=self.batch_size,
                run_type=self.run_type,
            )
        )

        new_runs = [r for r in runs if str(r.id) not in self._seen_run_ids]

        if not new_runs:
            logger.debug("No new runs found")
            return

        logger.info("Found %d new runs to evaluate", len(new_runs))

        for run in new_runs:
            run_id = str(run.id)
            self._seen_run_ids[run_id] = None

            try:
                results = evaluate_run(
                    run_id,
                    evaluators=self.evaluators,
                    client=self.client,
                )
                self._total_evaluated += 1

                # Process results and check thresholds
                for result in results:
                    key = result.get("key", "score")
                    raw_score = result.get("score")
                    score = float(raw_score) if raw_score is not None else 0.0

                    # Track history
                    self._score_history.setdefault(key, []).append(score)

                    # Check thresholds
                    if key in self.thresholds and score < self.thresholds[key]:
                        self._fire_alert(
                            {
                                "type": "threshold_violation",
                                "key": key,
                                "score": score,
                                "threshold": self.thresholds[key],
                                "run_id": run_id,
                                "message": (
                                    f"Score '{key}' = {score:.4f} is below "
                                    f"threshold {self.thresholds[key]:.4f} "
                                    f"for run {run_id}"
                                ),
                            }
                        )

            except Exception as exc:
                logger.warning("Failed to evaluate run %s: %s", run_id, exc)

        # Keep seen_run_ids bounded (OrderedDict preserves insertion order)
        while len(self._seen_run_ids) > 10000:
            self._seen_run_ids.popitem(last=False)  # Remove oldest

    def _fire_alert(self, alert: dict[str, Any]) -> None:
        """Fire an alert to all registered handlers."""
        logger.warning("ALERT: %s", alert["message"])
        for handler in self._alert_handlers:
            try:
                handler(alert)
            except Exception as exc:
                logger.error("Alert handler failed: %s", exc)

    @property
    def stats(self) -> dict[str, Any]:
        """Return monitoring statistics."""
        return {
            "total_evaluated": self._total_evaluated,
            "seen_runs": len(self._seen_run_ids),
            "score_history": {
                k: {
                    "count": len(v),
                    "avg": sum(v) / len(v) if v else 0.0,
                    "min": min(v) if v else 0.0,
                    "max": max(v) if v else 0.0,
                }
                for k, v in self._score_history.items()
            },
        }
