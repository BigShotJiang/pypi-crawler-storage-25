"""Threshold and assertion helpers for CI/CD gating.

Use these to fail pipelines when evaluation scores drop below acceptable levels.
"""

from __future__ import annotations

import logging
from typing import Any

from lef.core.types import EvalResult, EvalResultBatch

logger = logging.getLogger(__name__)


class EvalAssertionError(AssertionError):
    """Raised when an evaluation threshold is not met."""

    def __init__(self, failures: list[dict[str, Any]]):
        self.failures = failures
        lines = ["Evaluation thresholds not met:"]
        for f in failures:
            lines.append(f"  - {f['key']}: got {f['actual']:.4f}, expected >= {f['threshold']:.4f}")
        super().__init__("\n".join(lines))


def _extract_scores(results: Any) -> dict[str, list[float]]:
    """Extract {key: [scores]} from any result format.

    Handles:
    - list[EvalResult] (LEF native)
    - list[dict] with 'key' and 'score' fields
    - EvalResultBatch
    - LangSmith ExperimentResults (iterable of ExperimentResultRow)
    """
    scores: dict[str, list[float]] = {}

    if isinstance(results, EvalResultBatch):
        for r in results.results:
            val = float(r.score)
            scores.setdefault(r.key, []).append(val)
        return scores

    for row in results:
        # LangSmith ExperimentResultRow is a TypedDict with
        # {run, example, evaluation_results} where evaluation_results
        # has a "results" key containing EvaluationResult objects
        if isinstance(row, dict) and "evaluation_results" in row:
            eval_results = row["evaluation_results"]
            # evaluation_results is a TypedDict with "results" key
            inner = eval_results.get("results", []) if isinstance(eval_results, dict) else []
            for er in inner:
                key = getattr(er, "key", None) or (er.get("key") if isinstance(er, dict) else None)
                score = getattr(er, "score", None)
                if score is None and isinstance(er, dict):
                    score = er.get("score", 0.0)
                if key is not None and score is not None:
                    val = float(score)
                    scores.setdefault(key, []).append(val)
        elif isinstance(row, EvalResult):
            val = float(row.score)
            scores.setdefault(row.key, []).append(val)
        elif isinstance(row, dict):
            key = row.get("key", "score")
            score = row.get("score", 0.0)
            val = float(score)
            scores.setdefault(key, []).append(val)
        elif hasattr(row, "key") and hasattr(row, "score"):
            # LangSmith EvaluationResult (Pydantic) or similar
            val = float(row.score)
            scores.setdefault(row.key, []).append(val)

    return scores


def _summarize(results: Any) -> dict[str, float]:
    """Compute average scores per key from any result format."""
    scores = _extract_scores(results)
    return {k: sum(v) / len(v) for k, v in scores.items()}


def assert_scores(
    results: Any,
    thresholds: dict[str, float],
) -> None:
    """Assert that average scores meet minimum thresholds.

    Computes the average score for each key across all results and raises
    ``EvalAssertionError`` if any key falls below its threshold.

    Args:
        results: Evaluation results — accepts any of:
            - ``list[EvalResult]`` (LEF native)
            - ``EvalResultBatch``
            - ``list[dict]`` with 'key' and 'score'
            - LangSmith ``ExperimentResults`` from ``run_eval()``
        thresholds: Mapping of metric key -> minimum acceptable average score.

    Raises:
        EvalAssertionError: If any threshold is not met.

    Example::

        results = run_eval(target=my_app, data="qa-set", evaluators=[...])
        assert_scores(results, {"correctness": 0.8, "safety": 0.95})
    """
    summary = _summarize(results)

    failures = []
    for key, threshold in thresholds.items():
        actual = summary.get(key)
        if actual is None:
            failures.append({"key": key, "actual": 0.0, "threshold": threshold})
            logger.warning("Threshold key '%s' not found in results", key)
        elif actual < threshold:
            failures.append({"key": key, "actual": actual, "threshold": threshold})

    if failures:
        raise EvalAssertionError(failures)

    logger.info("All thresholds passed: %s", thresholds)


def check_scores(
    results: Any,
    thresholds: dict[str, float],
) -> dict[str, dict[str, Any]]:
    """Check scores against thresholds without raising.

    Returns a dict per key with 'passed', 'actual', and 'threshold' fields.

    Example::

        report = check_scores(results, {"correctness": 0.8})
        if not all(v["passed"] for v in report.values()):
            print("Some thresholds failed!")
    """
    summary = _summarize(results)

    report = {}
    for key, threshold in thresholds.items():
        actual = summary.get(key, 0.0)
        report[key] = {
            "passed": actual >= threshold,
            "actual": actual,
            "threshold": threshold,
        }
    return report
