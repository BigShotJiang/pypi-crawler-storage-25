"""Git context detection for experiment tagging.

Automatically detects branch, commit SHA, author, and other git metadata
to attach to evaluation experiments for branch comparison workflows.
"""

from __future__ import annotations

import logging
import os
import subprocess
from typing import Any

logger = logging.getLogger(__name__)


def get_git_context(repo_path: str | None = None) -> dict[str, Any]:
    """Detect git context from the current repository.

    Returns a dict with keys:
        - branch: current branch name
        - commit_sha: full commit hash
        - commit_short: short (8-char) commit hash
        - author: commit author name
        - author_email: commit author email
        - commit_message: first line of commit message
        - is_dirty: whether working tree has uncommitted changes
        - remote_url: origin remote URL (if available)

    Also checks CI environment variables (GitHub Actions, Azure DevOps,
    GitLab CI, Jenkins) for branch/commit info that may not be available
    from git directly (e.g., in detached HEAD state).

    Returns an empty dict if not in a git repository.
    """
    context: dict[str, Any] = {}

    # Try CI environment variables first (more reliable in CI)
    ci_context = _detect_ci_context()
    context.update(ci_context)

    # Then fill in from git
    git_context = _detect_git_context(repo_path)
    for k, v in git_context.items():
        if k not in context or not context[k]:
            context[k] = v

    if context:
        logger.debug("Git context: %s", {k: v for k, v in context.items() if k != "commit_message"})

    return context


def _run_git(args: list[str], cwd: str | None = None) -> str | None:
    """Run a git command and return stdout, or None on failure."""
    try:
        result = subprocess.run(
            ["git"] + args,
            capture_output=True,
            text=True,
            timeout=5,
            cwd=cwd,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass
    return None


def _detect_git_context(repo_path: str | None = None) -> dict[str, Any]:
    """Extract git metadata from the local repository."""
    context: dict[str, Any] = {}

    branch = _run_git(["rev-parse", "--abbrev-ref", "HEAD"], cwd=repo_path)
    if branch is None:
        return {}  # Not a git repo

    context["branch"] = branch

    sha = _run_git(["rev-parse", "HEAD"], cwd=repo_path)
    if sha:
        context["commit_sha"] = sha
        context["commit_short"] = sha[:8]

    author = _run_git(["log", "-1", "--format=%an"], cwd=repo_path)
    if author:
        context["author"] = author

    email = _run_git(["log", "-1", "--format=%ae"], cwd=repo_path)
    if email:
        context["author_email"] = email

    msg = _run_git(["log", "-1", "--format=%s"], cwd=repo_path)
    if msg:
        context["commit_message"] = msg

    dirty = _run_git(["status", "--porcelain"], cwd=repo_path)
    context["is_dirty"] = bool(dirty)

    remote = _run_git(["remote", "get-url", "origin"], cwd=repo_path)
    if remote:
        context["remote_url"] = remote

    return context


def _detect_ci_context() -> dict[str, Any]:
    """Detect branch/commit from CI environment variables."""
    context: dict[str, Any] = {}

    # GitHub Actions
    if os.environ.get("GITHUB_ACTIONS"):
        context["ci_provider"] = "github"
        context["branch"] = os.environ.get("GITHUB_HEAD_REF") or os.environ.get(
            "GITHUB_REF_NAME", ""
        )
        context["commit_sha"] = os.environ.get("GITHUB_SHA", "")
        if context["commit_sha"]:
            context["commit_short"] = context["commit_sha"][:8]
        pr_number = os.environ.get("GITHUB_PR_NUMBER") or _extract_pr_number(
            os.environ.get("GITHUB_REF", "")
        )
        if pr_number:
            context["pr_number"] = pr_number
        context["ci_run_id"] = os.environ.get("GITHUB_RUN_ID", "")
        context["repository"] = os.environ.get("GITHUB_REPOSITORY", "")

    # Azure DevOps
    elif os.environ.get("BUILD_BUILDID"):
        context["ci_provider"] = "azuredevops"
        context["branch"] = os.environ.get("BUILD_SOURCEBRANCH", "").replace("refs/heads/", "")
        context["commit_sha"] = os.environ.get("BUILD_SOURCEVERSION", "")
        if context["commit_sha"]:
            context["commit_short"] = context["commit_sha"][:8]
        pr_number = os.environ.get("SYSTEM_PULLREQUEST_PULLREQUESTID")
        if pr_number:
            context["pr_number"] = pr_number
        context["ci_run_id"] = os.environ.get("BUILD_BUILDID", "")
        context["repository"] = os.environ.get("BUILD_REPOSITORY_NAME", "")

    # GitLab CI
    elif os.environ.get("GITLAB_CI"):
        context["ci_provider"] = "gitlab"
        context["branch"] = os.environ.get("CI_COMMIT_BRANCH", "") or os.environ.get(
            "CI_MERGE_REQUEST_SOURCE_BRANCH_NAME", ""
        )
        context["commit_sha"] = os.environ.get("CI_COMMIT_SHA", "")
        if context["commit_sha"]:
            context["commit_short"] = context["commit_sha"][:8]
        context["ci_run_id"] = os.environ.get("CI_PIPELINE_ID", "")

    # Jenkins
    elif os.environ.get("JENKINS_URL"):
        context["ci_provider"] = "jenkins"
        context["branch"] = os.environ.get("GIT_BRANCH", "").replace("origin/", "")
        context["commit_sha"] = os.environ.get("GIT_COMMIT", "")
        if context["commit_sha"]:
            context["commit_short"] = context["commit_sha"][:8]
        context["ci_run_id"] = os.environ.get("BUILD_NUMBER", "")

    return context


def _extract_pr_number(ref: str) -> str | None:
    """Extract PR number from GitHub ref like 'refs/pull/123/merge'."""
    parts = ref.split("/")
    if len(parts) >= 3 and parts[1] == "pull":
        return parts[2]
    return None


def build_experiment_metadata(
    *,
    extra: dict[str, Any] | None = None,
    repo_path: str | None = None,
) -> dict[str, Any]:
    """Build experiment metadata dict with git context and optional extras.

    Intended for use as the ``metadata`` argument to ``run_eval()``.
    """
    metadata = get_git_context(repo_path=repo_path)
    if extra:
        metadata.update(extra)
    return metadata
