"""Local dataset loading from YAML, JSON, and CSV files.

Enables version-controlled test cases alongside prompts and code.
"""

from __future__ import annotations

import csv
import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def load_examples(
    path: str | Path,
    *,
    input_keys: list[str] | None = None,
    output_keys: list[str] | None = None,
) -> list[dict[str, Any]]:
    """Load evaluation examples from a local file.

    Supports YAML (.yaml/.yml), JSON (.json), and CSV (.csv) formats.

    Expected format (YAML/JSON): a list of objects with ``inputs`` and
    optionally ``outputs`` keys. If examples are flat dicts, use ``input_keys``
    and ``output_keys`` to specify which fields are inputs vs. outputs.

    CSV: column headers become keys. Use ``input_keys``/``output_keys`` to
    split columns into inputs and outputs.

    Args:
        path: Path to the dataset file.
        input_keys: Keys to treat as inputs (for flat dict / CSV formats).
        output_keys: Keys to treat as reference outputs.

    Returns:
        A list of dicts with 'inputs' and optionally 'outputs' keys,
        ready for ``create_dataset()`` or direct use with ``evaluate()``.

    Example::

        # examples.yaml:
        # - inputs:
        #     question: "What is 2+2?"
        #   outputs:
        #     answer: "4"

        examples = load_examples("examples.yaml")
        results = run_eval(target=my_fn, data=examples, evaluators=[...])
    """
    filepath = Path(path)
    suffix = filepath.suffix.lower()

    if suffix in (".yaml", ".yml"):
        raw = _load_yaml(filepath)
    elif suffix == ".json":
        raw = _load_json(filepath)
    elif suffix == ".csv":
        raw = _load_csv(filepath)
    else:
        raise ValueError(f"Unsupported file format '{suffix}'. Supported: .yaml, .yml, .json, .csv")

    logger.info("Loaded %d examples from %s", len(raw), filepath)
    return _normalize_examples(raw, input_keys=input_keys, output_keys=output_keys)


def _load_yaml(path: Path) -> list[dict[str, Any]]:
    """Load examples from a YAML file."""
    try:
        import yaml
    except ImportError as exc:
        raise ImportError(
            "PyYAML is required for YAML dataset loading. Install with: pip install pyyaml"
        ) from exc

    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f)

    if isinstance(data, list):
        return data
    if isinstance(data, dict) and "examples" in data:
        return data["examples"]
    raise ValueError(f"YAML file must contain a list or a dict with 'examples' key: {path}")


def _load_json(path: Path) -> list[dict[str, Any]]:
    """Load examples from a JSON file."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    if isinstance(data, list):
        return data
    if isinstance(data, dict) and "examples" in data:
        return data["examples"]
    raise ValueError(f"JSON file must contain a list or a dict with 'examples' key: {path}")


def _load_csv(path: Path) -> list[dict[str, Any]]:
    """Load examples from a CSV file."""
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return list(reader)


def _normalize_examples(
    raw: list[dict[str, Any]],
    *,
    input_keys: list[str] | None = None,
    output_keys: list[str] | None = None,
) -> list[dict[str, Any]]:
    """Normalize raw data into {inputs, outputs} format."""
    normalized = []
    for item in raw:
        if "inputs" in item:
            # Already in the right format; accept both "outputs" and "reference_outputs"
            normalized.append(
                {
                    "inputs": item["inputs"],
                    "outputs": item.get("outputs") or item.get("reference_outputs"),
                }
            )
        elif input_keys:
            inputs = {k: item[k] for k in input_keys if k in item}
            outputs = (
                {k: item[k] for k in output_keys if k in item} if output_keys else None
            ) or None
            normalized.append({"inputs": inputs, "outputs": outputs})
        else:
            # Treat entire dict as inputs
            normalized.append({"inputs": item, "outputs": None})

    return normalized
