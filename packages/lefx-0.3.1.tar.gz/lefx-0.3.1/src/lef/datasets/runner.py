"""Dataset-driven evaluation runner.

Wraps langsmith.evaluate() with a higher-level API that makes it easy to
run evaluations against LangSmith datasets with multiple evaluators.
"""

from __future__ import annotations

import asyncio
import functools
import inspect
import logging
import uuid
from collections.abc import Callable, Sequence
from datetime import UTC, datetime
from typing import Any

from langsmith import Client, aevaluate, evaluate
from langsmith.evaluation import evaluate_comparative
from langsmith.schemas import Example
from langsmith.utils import LangSmithNotFoundError

logger = logging.getLogger(__name__)

_DATASET_SENTINEL = uuid.UUID("00000000-0000-0000-0000-000000000000")


def _to_examples(data: list[dict[str, Any]]) -> list[Example]:
    """Convert a list of dicts to LangSmith Example objects.

    Each dict should have 'inputs' and optionally 'outputs' keys.
    """
    now = datetime.now(UTC)
    examples = []
    for item in data:
        inputs = item.get("inputs", item)
        outputs = item.get("outputs") or item.get("reference_outputs")
        examples.append(
            Example(
                id=uuid.uuid4(),
                dataset_id=_DATASET_SENTINEL,
                inputs=inputs,
                outputs=outputs,
                created_at=now,
            )
        )
    return examples


def create_dataset(
    name: str,
    *,
    examples: list[dict[str, Any]],
    description: str | None = None,
    input_keys: list[str] | None = None,
    output_keys: list[str] | None = None,
    client: Client | None = None,
) -> str:
    """Create or update a LangSmith dataset from examples.

    If a dataset with the given name already exists, it is reused
    and examples are appended to it.

    Args:
        name: The dataset name in LangSmith.
        examples: List of dicts, each with 'inputs' and optionally 'outputs' keys.
        description: Optional dataset description.
        input_keys: Keys to extract as inputs (if examples are flat dicts).
        output_keys: Keys to extract as outputs (if examples are flat dicts).
        client: Optional LangSmith client instance.

    Returns:
        The dataset ID as a string.
    """
    ls_client = client or Client()

    # Upsert: use existing dataset if it already exists
    try:
        dataset = ls_client.read_dataset(dataset_name=name)
        logger.info("Using existing dataset '%s' (%s)", name, dataset.id)
    except LangSmithNotFoundError:
        dataset = ls_client.create_dataset(
            dataset_name=name,
            description=description,
        )
        logger.info("Created new dataset '%s' (%s)", name, dataset.id)

    for ex in examples:
        if "inputs" in ex:
            inputs = ex["inputs"]
            outputs = ex.get("outputs") or ex.get("reference_outputs")
        elif input_keys:
            inputs = {k: ex[k] for k in input_keys if k in ex}
            outputs = {k: ex[k] for k in (output_keys or []) if k in ex} or None
        else:
            inputs = ex
            outputs = None

        ls_client.create_example(
            inputs=inputs,
            outputs=outputs,
            dataset_id=dataset.id,
        )

    logger.info("Added %d examples to dataset '%s'", len(examples), name)
    return str(dataset.id)


def _build_eval_kwargs(
    *,
    data: str | list[dict[str, Any]],
    evaluators: Sequence[Callable[..., Any]],
    summary_evaluators: Sequence[Callable[..., Any]] | None = None,
    experiment_prefix: str | None = None,
    description: str | None = None,
    max_concurrency: int | None = None,
    num_repetitions: int = 1,
    client: Client | None = None,
    metadata: dict[str, Any] | None = None,
    upload_results: bool = True,
) -> dict[str, Any]:
    """Build kwargs dict for langsmith.evaluate / aevaluate.

    If ``max_concurrency`` is None and an active :class:`LefConfig` exists,
    its ``max_concurrency`` value is used as a default.
    """
    from lef.config import get_config

    eval_data: Any = data
    if isinstance(data, list):
        eval_data = _to_examples(data)

    # Fall back to LefConfig.max_concurrency when not explicitly provided
    if max_concurrency is None:
        active = get_config()
        if active is not None:
            max_concurrency = active.max_concurrency

    kwargs: dict[str, Any] = {
        "data": eval_data,
        "evaluators": list(evaluators),
        "experiment_prefix": experiment_prefix,
        "max_concurrency": max_concurrency,
        "client": client,
        "metadata": metadata,
    }
    if summary_evaluators:
        kwargs["summary_evaluators"] = list(summary_evaluators)
    if description:
        kwargs["description"] = description
    if num_repetitions > 1:
        kwargs["num_repetitions"] = num_repetitions
    if not upload_results:
        kwargs["upload_results"] = False
    return kwargs


def run_eval(
    target: Callable[..., Any],
    *,
    data: str | list[dict[str, Any]],
    evaluators: Sequence[Callable[..., Any]],
    summary_evaluators: Sequence[Callable[..., Any]] | None = None,
    experiment_prefix: str | None = None,
    description: str | None = None,
    max_concurrency: int | None = None,
    num_repetitions: int = 1,
    client: Client | None = None,
    metadata: dict[str, Any] | None = None,
    upload_results: bool = True,
) -> Any:
    """Run an evaluation against a LangSmith dataset or local examples.

    Args:
        target: The function/chain/agent to evaluate.
        data: LangSmith dataset name/ID, or a list of local example dicts.
        evaluators: Row-level evaluator functions.
        summary_evaluators: Experiment-level evaluators (aggregate metrics).
        experiment_prefix: Optional prefix for the experiment name.
        description: Optional description for the experiment.
        max_concurrency: Max parallel evaluations. Falls back to LefConfig
            if not specified.
        num_repetitions: Number of times to repeat each example.
        client: Optional LangSmith client instance.
        metadata: Optional metadata to attach to the experiment.
        upload_results: Whether to upload results to LangSmith (default True).

    Returns:
        The LangSmith ExperimentResults object.
    """
    kwargs = _build_eval_kwargs(
        data=data,
        evaluators=evaluators,
        summary_evaluators=summary_evaluators,
        experiment_prefix=experiment_prefix,
        description=description,
        max_concurrency=max_concurrency,
        num_repetitions=num_repetitions,
        client=client,
        metadata=metadata,
        upload_results=upload_results,
    )
    logger.info(
        "Running evaluation: data=%s, evaluators=%d, prefix=%s",
        data if isinstance(data, str) else f"{len(data)} examples",
        len(evaluators),
        experiment_prefix,
    )
    return evaluate(target, **kwargs)


async def arun_eval(
    target: Callable[..., Any],
    *,
    data: str | list[dict[str, Any]],
    evaluators: Sequence[Callable[..., Any]],
    summary_evaluators: Sequence[Callable[..., Any]] | None = None,
    experiment_prefix: str | None = None,
    description: str | None = None,
    max_concurrency: int | None = None,
    num_repetitions: int = 1,
    client: Client | None = None,
    metadata: dict[str, Any] | None = None,
    upload_results: bool = True,
) -> Any:
    """Async version of run_eval.

    The target can be either sync or async. If a sync function is passed,
    it is automatically wrapped to be compatible with langsmith.aevaluate().
    """
    # langsmith.aevaluate() requires an async target; wrap sync functions.
    # The wrapper must accept 'inputs' as a positional arg to pass langsmith's
    # signature inspection.
    async_target = target
    if not asyncio.iscoroutinefunction(target) and not inspect.isasyncgenfunction(target):

        @functools.wraps(target)
        async def _async_wrapper(inputs: dict[str, Any], **kw: Any) -> Any:
            return target(inputs, **kw)

        async_target = _async_wrapper

    kwargs = _build_eval_kwargs(
        data=data,
        evaluators=evaluators,
        summary_evaluators=summary_evaluators,
        experiment_prefix=experiment_prefix,
        description=description,
        max_concurrency=max_concurrency,
        num_repetitions=num_repetitions,
        client=client,
        metadata=metadata,
        upload_results=upload_results,
    )
    return await aevaluate(async_target, **kwargs)


def run_comparative_eval(
    experiments: Sequence[str],
    *,
    evaluators: Sequence[Callable[..., Any]],
    client: Client | None = None,
) -> Any:
    """Run a comparative evaluation across multiple experiments (A/B testing).

    Args:
        experiments: List of experiment names/IDs to compare.
        evaluators: Evaluators that score comparative results.
        client: Optional LangSmith client instance.

    Returns:
        The LangSmith comparative evaluation results.
    """
    return evaluate_comparative(
        experiments=list(experiments),
        evaluators=list(evaluators),
        client=client,
    )


class EvalRunner:
    """High-level evaluation runner with fluent interface.

    Example::

        runner = EvalRunner(dataset="my-dataset")
        runner.add_evaluator(correctness_judge())
        runner.add_evaluator(exact_match)
        results = runner.run(target=my_chain.invoke)
    """

    def __init__(
        self,
        *,
        dataset: str | list[dict[str, Any]],
        experiment_prefix: str | None = None,
        description: str | None = None,
        client: Client | None = None,
        metadata: dict[str, Any] | None = None,
        max_concurrency: int | None = None,
        num_repetitions: int = 1,
        upload_results: bool = True,
    ):
        self.dataset = dataset
        self.experiment_prefix = experiment_prefix
        self.description = description
        self.client = client
        self.metadata = metadata or {}
        self.max_concurrency = max_concurrency
        self.num_repetitions = num_repetitions
        self.upload_results = upload_results
        self._evaluators: list[Callable[..., Any]] = []
        self._summary_evaluators: list[Callable[..., Any]] = []

    def add_evaluator(self, evaluator: Callable[..., Any]) -> EvalRunner:
        """Add a row-level evaluator. Returns self for chaining."""
        self._evaluators.append(evaluator)
        return self

    def add_evaluators(self, evaluators: Sequence[Callable[..., Any]]) -> EvalRunner:
        """Add multiple row-level evaluators. Returns self for chaining."""
        self._evaluators.extend(evaluators)
        return self

    def add_summary_evaluator(self, evaluator: Callable[..., Any]) -> EvalRunner:
        """Add an experiment-level summary evaluator. Returns self for chaining."""
        self._summary_evaluators.append(evaluator)
        return self

    def run(self, target: Callable[..., Any]) -> Any:
        """Run the evaluation synchronously."""
        return run_eval(
            target,
            data=self.dataset,
            evaluators=self._evaluators,
            summary_evaluators=self._summary_evaluators or None,
            experiment_prefix=self.experiment_prefix,
            description=self.description,
            max_concurrency=self.max_concurrency,
            num_repetitions=self.num_repetitions,
            client=self.client,
            metadata=self.metadata,
            upload_results=self.upload_results,
        )

    async def arun(self, target: Callable[..., Any]) -> Any:
        """Run the evaluation asynchronously."""
        return await arun_eval(
            target,
            data=self.dataset,
            evaluators=self._evaluators,
            summary_evaluators=self._summary_evaluators or None,
            experiment_prefix=self.experiment_prefix,
            description=self.description,
            max_concurrency=self.max_concurrency,
            num_repetitions=self.num_repetitions,
            client=self.client,
            metadata=self.metadata,
            upload_results=self.upload_results,
        )
