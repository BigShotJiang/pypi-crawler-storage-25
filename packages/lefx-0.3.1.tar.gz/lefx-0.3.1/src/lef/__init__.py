"""LEF - LangSmith Evaluation Framework.

A plug-and-play evaluation system for LangChain, LangGraph, and LangSmith projects.

Quick start::

    from lef import scorer, run_eval, correctness_judge, exact_match

    # Create a custom scorer with a decorator
    @scorer(key="has_answer")
    def has_answer(*, inputs, outputs, **kwargs):
        return bool(outputs.get("answer"))

    # Run evals against a LangSmith dataset
    results = run_eval(
        target=my_chain.invoke,
        data="my-dataset",
        evaluators=[correctness_judge(), exact_match, has_answer],
    )
"""

__version__ = "0.3.1"

# Core
# Assertions
from lef.assertions import EvalAssertionError, assert_scores, check_scores

# Cache
from lef.cache import ResultCache

# CI integrations
from lef.ci import post_azdo_comment, post_github_comment

# Compare & baselines
from lef.compare import (
    ComparisonReport,
    compare_experiments,
    compare_results,
    delete_baseline,
    list_baselines,
    load_baseline,
    save_baseline,
)

# Config
from lef.config import LefConfig
from lef.core import (
    AsyncBaseEvaluator,
    BaseEvaluator,
    EvalResult,
    EvalResultBatch,
    JudgeModel,
    evaluator,
    scorer,
)

# Dataset runner
from lef.datasets import (
    EvalRunner,
    arun_eval,
    create_dataset,
    load_examples,
    run_comparative_eval,
    run_eval,
)

# Git context
from lef.git_context import build_experiment_metadata, get_git_context

# Integrations
from lef.integrations import (
    aevaluate_chain,
    aevaluate_graph,
    create_async_chain_target,
    create_async_graph_target,
    create_async_remote_target,
    create_chain_target,
    create_graph_target,
    create_remote_target,
    evaluate_chain,
    evaluate_graph,
)

# Judges - core quality
from lef.judges import (
    answer_relevance_judge,
    code_correctness_judge,
    conciseness_judge,
    correctness_judge,
    create_judge,
    create_trajectory_evaluator,
    create_trajectory_judge,
    faithfulness_judge,
    hallucination_judge,
    plan_adherence_judge,
    rag_groundedness_judge,
    rag_helpfulness_judge,
    rag_retrieval_relevance_judge,
    response_quality_judge,
    safety_judge,
    tool_selection_judge,
    toxicity_judge,
)

# Monitor
from lef.monitor import MonitorDaemon

# Online evaluation
from lef.online import OnlineEvaluator, create_rule, create_rule_config, evaluate_run

# Output formatting & export
from lef.output import (
    export_csv,
    export_json,
    export_junit_xml,
    export_markdown,
    export_results,
    format_results_table,
)

# Red-teaming
from lef.redteam import (
    injection_resistance_check,
    pii_leak_check,
    refusal_check,
    run_redteam,
)

# Built-in scorers
from lef.scorers import (
    contains,
    create_composite_scorer,
    create_scorer,
    exact_match,
    json_match,
    mean_score,
    pass_rate,
    regex_match,
)

# Synthetic data generation
from lef.synthetic import (
    diversify_dataset,
    generate_adversarial,
    generate_from_docs,
    generate_from_traces,
)

# Watch mode (F5)
from lef.watch import watch_and_run

__all__ = [
    # Version
    "__version__",
    # Core
    "AsyncBaseEvaluator",
    "BaseEvaluator",
    "EvalResult",
    "EvalResultBatch",
    "JudgeModel",
    "evaluator",
    "scorer",
    # Judges - core quality
    "answer_relevance_judge",
    "code_correctness_judge",
    "conciseness_judge",
    "correctness_judge",
    "create_judge",
    "faithfulness_judge",
    "hallucination_judge",
    "plan_adherence_judge",
    "response_quality_judge",
    "safety_judge",
    "tool_selection_judge",
    "toxicity_judge",
    # Judges - RAG
    "rag_groundedness_judge",
    "rag_helpfulness_judge",
    "rag_retrieval_relevance_judge",
    # Judges - trajectory
    "create_trajectory_evaluator",
    "create_trajectory_judge",
    # Datasets
    "EvalRunner",
    "arun_eval",
    "create_dataset",
    "load_examples",
    "run_comparative_eval",
    "run_eval",
    # Online
    "OnlineEvaluator",
    "create_rule",
    "create_rule_config",
    "evaluate_run",
    # Scorers
    "contains",
    "create_composite_scorer",
    "create_scorer",
    "exact_match",
    "json_match",
    "mean_score",
    "pass_rate",
    "regex_match",
    # Integrations
    "aevaluate_chain",
    "aevaluate_graph",
    "create_async_chain_target",
    "create_async_graph_target",
    "create_async_remote_target",
    "create_chain_target",
    "create_graph_target",
    "create_remote_target",
    "evaluate_chain",
    "evaluate_graph",
    # Config
    "LefConfig",
    # Assertions
    "EvalAssertionError",
    "assert_scores",
    "check_scores",
    # Output & export (F1, F6)
    "export_csv",
    "export_json",
    "export_junit_xml",
    "export_markdown",
    "export_results",
    "format_results_table",
    # Git context (F2)
    "build_experiment_metadata",
    "get_git_context",
    # Compare & baselines (F3, F10)
    "ComparisonReport",
    "compare_experiments",
    "compare_results",
    "delete_baseline",
    "list_baselines",
    "load_baseline",
    "save_baseline",
    # Cache (F4)
    "ResultCache",
    # CI integrations (F8)
    "post_azdo_comment",
    "post_github_comment",
    # Monitor (F14)
    "MonitorDaemon",
    # Red-teaming (F17)
    "injection_resistance_check",
    "pii_leak_check",
    "refusal_check",
    "run_redteam",
    # Watch mode (F5)
    "watch_and_run",
    # Synthetic generation (F13)
    "diversify_dataset",
    "generate_adversarial",
    "generate_from_docs",
    "generate_from_traces",
]
