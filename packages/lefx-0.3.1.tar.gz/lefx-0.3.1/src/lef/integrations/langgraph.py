"""LangGraph integration for LEF.

Provides utilities for evaluating LangGraph StateGraphs and agents
against LangSmith datasets.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import Any

from lef.datasets.runner import arun_eval, run_eval


def create_graph_target(
    graph: Any,
    *,
    input_mapper: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
    output_mapper: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
    config: dict[str, Any] | None = None,
) -> Callable[[dict[str, Any]], dict[str, Any]]:
    """Wrap a compiled LangGraph graph as an evaluation target.

    Args:
        graph: A compiled LangGraph StateGraph (must have .invoke() method).
        input_mapper: Optional function to transform dataset inputs into
            the graph's expected input format.
        output_mapper: Optional function to transform graph outputs into
            the format expected by evaluators.
        config: Optional RunnableConfig to pass to graph.invoke().

    Returns:
        A callable suitable for use as a target in langsmith.evaluate().
    """

    def _target(inputs: dict[str, Any]) -> dict[str, Any]:
        graph_input = input_mapper(inputs) if input_mapper else inputs
        result = graph.invoke(graph_input, config=config)
        return output_mapper(result) if output_mapper else result

    return _target


def create_async_graph_target(
    graph: Any,
    *,
    input_mapper: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
    output_mapper: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
    config: dict[str, Any] | None = None,
) -> Callable[..., Any]:
    """Wrap a compiled LangGraph graph as an async evaluation target.

    Args:
        graph: A compiled LangGraph StateGraph (must have .ainvoke() method).
        input_mapper: Optional input transformation function.
        output_mapper: Optional output transformation function.
        config: Optional RunnableConfig.

    Returns:
        An async callable suitable for use with aevaluate().
    """

    async def _target(inputs: dict[str, Any]) -> dict[str, Any]:
        graph_input = input_mapper(inputs) if input_mapper else inputs
        result = await graph.ainvoke(graph_input, config=config)
        return output_mapper(result) if output_mapper else result

    return _target


def evaluate_graph(
    graph: Any,
    *,
    data: str | list[dict[str, Any]],
    evaluators: Sequence[Callable[..., Any]],
    input_mapper: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
    output_mapper: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
    config: dict[str, Any] | None = None,
    summary_evaluators: Sequence[Callable[..., Any]] | None = None,
    experiment_prefix: str | None = None,
    description: str | None = None,
    max_concurrency: int | None = None,
    num_repetitions: int = 1,
    client: Any | None = None,
    metadata: dict[str, Any] | None = None,
    upload_results: bool = True,
) -> Any:
    """Evaluate a LangGraph graph against a dataset.

    Convenience function combining create_graph_target() + run_eval().
    """
    target = create_graph_target(
        graph, input_mapper=input_mapper, output_mapper=output_mapper, config=config
    )
    return run_eval(
        target,
        data=data,
        evaluators=evaluators,
        summary_evaluators=summary_evaluators,
        experiment_prefix=experiment_prefix,
        description=description,
        max_concurrency=max_concurrency,
        num_repetitions=num_repetitions,
        client=client,
        metadata=metadata,
        upload_results=upload_results,
    )


async def aevaluate_graph(
    graph: Any,
    *,
    data: str | list[dict[str, Any]],
    evaluators: Sequence[Callable[..., Any]],
    input_mapper: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
    output_mapper: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
    config: dict[str, Any] | None = None,
    summary_evaluators: Sequence[Callable[..., Any]] | None = None,
    experiment_prefix: str | None = None,
    description: str | None = None,
    max_concurrency: int | None = None,
    num_repetitions: int = 1,
    client: Any | None = None,
    metadata: dict[str, Any] | None = None,
    upload_results: bool = True,
) -> Any:
    """Async evaluate a LangGraph graph against a dataset."""
    target = create_async_graph_target(
        graph, input_mapper=input_mapper, output_mapper=output_mapper, config=config
    )
    return await arun_eval(
        target,
        data=data,
        evaluators=evaluators,
        summary_evaluators=summary_evaluators,
        experiment_prefix=experiment_prefix,
        description=description,
        max_concurrency=max_concurrency,
        num_repetitions=num_repetitions,
        client=client,
        metadata=metadata,
        upload_results=upload_results,
    )
