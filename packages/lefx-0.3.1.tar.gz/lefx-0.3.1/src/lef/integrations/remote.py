"""Remote target integration for evaluating deployed LangSmith/LangGraph endpoints.

Provides helpers for creating evaluation targets that call remote HTTP APIs,
such as LangSmith Deployments (LangGraph Platform) or any REST endpoint.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

logger = logging.getLogger(__name__)


def create_remote_target(
    url: str,
    *,
    headers: dict[str, str] | None = None,
    input_mapper: Callable[[dict[str, Any]], Any] | None = None,
    output_mapper: Callable[[Any], dict[str, Any]] | None = None,
    timeout: float = 60.0,
) -> Callable[[dict[str, Any]], dict[str, Any]]:
    """Create an evaluation target that calls a remote HTTP endpoint.

    Works with LangSmith Deployments (LangGraph Platform), LangServe,
    or any REST API that accepts JSON POST requests.

    The endpoint should accept a JSON body and return a JSON response.
    By default, the request body is ``{"input": <inputs>}`` and the
    response is expected to have an ``"output"`` key containing the result.
    Use ``input_mapper`` / ``output_mapper`` to customize this.

    Args:
        url: The endpoint URL (e.g., ``"https://my-deployment.langsmith.dev/invoke"``).
        headers: Optional HTTP headers (e.g., ``{"x-api-key": "..."}``).
        input_mapper: Optional function to transform dataset inputs into the
            request body. Default: ``{"input": inputs}``.
        output_mapper: Optional function to transform the JSON response into
            a dict suitable for evaluators. Default: extracts ``response["output"]``.
        timeout: HTTP request timeout in seconds (default 60).

    Returns:
        A callable ``(inputs: dict) -> dict`` suitable for ``run_eval(target=...)``.

    Example::

        # LangSmith Deployment (LangGraph Platform)
        target = create_remote_target(
            "https://my-assistant.langsmith.dev/runs/stream",
            headers={"x-api-key": os.environ["LANGSMITH_API_KEY"]},
            input_mapper=lambda inputs: {
                "input": {"messages": [{"role": "user", "content": inputs["question"]}]},
            },
            output_mapper=lambda resp: {
                "answer": resp["output"]["messages"][-1]["content"],
            },
        )

        results = run_eval(target=target, data=examples, evaluators=[...])
    """

    def _target(inputs: dict[str, Any]) -> dict[str, Any]:
        body = input_mapper(inputs) if input_mapper else {"input": inputs}
        response_data = _http_post(url, json_body=body, headers=headers, timeout=timeout)

        if output_mapper:
            return output_mapper(response_data)

        # Default: extract "output" key from response
        if isinstance(response_data, dict) and "output" in response_data:
            output = response_data["output"]
            if isinstance(output, dict):
                return output
            if isinstance(output, str):
                return {"answer": output}
            return {"output": str(output)}

        # Fallback: return the whole response as-is
        if isinstance(response_data, dict):
            return response_data
        return {"output": str(response_data)}

    return _target


def create_async_remote_target(
    url: str,
    *,
    headers: dict[str, str] | None = None,
    input_mapper: Callable[[dict[str, Any]], Any] | None = None,
    output_mapper: Callable[[Any], dict[str, Any]] | None = None,
    timeout: float = 60.0,
) -> Callable[..., Any]:
    """Async version of :func:`create_remote_target`.

    Returns an async callable for use with ``arun_eval`` or ``aevaluate_graph``.
    """

    async def _target(inputs: dict[str, Any]) -> dict[str, Any]:
        body = input_mapper(inputs) if input_mapper else {"input": inputs}
        response_data = await _async_http_post(
            url, json_body=body, headers=headers, timeout=timeout
        )

        if output_mapper:
            return output_mapper(response_data)

        if isinstance(response_data, dict) and "output" in response_data:
            output = response_data["output"]
            if isinstance(output, dict):
                return output
            if isinstance(output, str):
                return {"answer": output}
            return {"output": str(output)}

        if isinstance(response_data, dict):
            return response_data
        return {"output": str(response_data)}

    return _target


def _http_post(
    url: str,
    *,
    json_body: Any,
    headers: dict[str, str] | None = None,
    timeout: float = 60.0,
) -> Any:
    """Make a sync HTTP POST request, preferring httpx if available."""
    try:
        import httpx

        try:
            with httpx.Client(timeout=timeout) as client:
                resp = client.post(url, json=json_body, headers=headers or {})
                resp.raise_for_status()
                return resp.json()
        except httpx.HTTPStatusError as exc:
            raise ConnectionError(
                f"Remote target returned HTTP {exc.response.status_code} for {url}"
            ) from exc
        except httpx.ConnectError as exc:
            raise ConnectionError(f"Cannot connect to remote target at {url}: {exc}") from exc
        except httpx.TimeoutException as exc:
            raise TimeoutError(f"Remote target at {url} timed out after {timeout}s") from exc
    except ImportError:
        pass

    # Fallback to urllib (always available)
    import json
    import urllib.error
    import urllib.request

    data = json.dumps(json_body).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json", **(headers or {})},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise ConnectionError(f"Remote target returned HTTP {exc.code} for {url}") from exc
    except urllib.error.URLError as exc:
        raise ConnectionError(f"Cannot connect to remote target at {url}: {exc.reason}") from exc
    except TimeoutError as exc:
        raise TimeoutError(f"Remote target at {url} timed out after {timeout}s") from exc


async def _async_http_post(
    url: str,
    *,
    json_body: Any,
    headers: dict[str, str] | None = None,
    timeout: float = 60.0,
) -> Any:
    """Make an async HTTP POST request, preferring httpx if available."""
    try:
        import httpx

        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                resp = await client.post(url, json=json_body, headers=headers or {})
                resp.raise_for_status()
                return resp.json()
        except httpx.HTTPStatusError as exc:
            raise ConnectionError(
                f"Remote target returned HTTP {exc.response.status_code} for {url}"
            ) from exc
        except httpx.ConnectError as exc:
            raise ConnectionError(f"Cannot connect to remote target at {url}: {exc}") from exc
        except httpx.TimeoutException as exc:
            raise TimeoutError(f"Remote target at {url} timed out after {timeout}s") from exc
    except ImportError:
        pass

    # Fallback: run sync urllib in a thread
    import asyncio

    return await asyncio.to_thread(
        _http_post, url, json_body=json_body, headers=headers, timeout=timeout
    )
