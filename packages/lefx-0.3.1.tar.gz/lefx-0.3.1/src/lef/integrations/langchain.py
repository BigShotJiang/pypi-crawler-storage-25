"""LangChain integration for LEF.

Provides utilities for evaluating LangChain chains and runnables
against LangSmith datasets.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import Any

from lef.datasets.runner import arun_eval, run_eval


def create_chain_target(
    chain: Any,
    *,
    input_mapper: Callable[[dict[str, Any]], Any] | None = None,
    output_mapper: Callable[[Any], dict[str, Any]] | None = None,
    config: dict[str, Any] | None = None,
) -> Callable[[dict[str, Any]], dict[str, Any]]:
    """Wrap a LangChain Runnable/Chain as an evaluation target.

    Args:
        chain: A LangChain Runnable (must have .invoke() method).
        input_mapper: Optional function to transform dataset inputs.
        output_mapper: Optional function to transform chain outputs into dicts.
        config: Optional RunnableConfig.

    Returns:
        A callable suitable for use as a target in langsmith.evaluate().
    """

    def _target(inputs: dict[str, Any]) -> dict[str, Any]:
        chain_input = input_mapper(inputs) if input_mapper else inputs
        result = chain.invoke(chain_input, config=config)

        if output_mapper:
            return output_mapper(result)

        # Auto-convert common LangChain output types
        if hasattr(result, "content"):
            return {"answer": result.content}
        if isinstance(result, str):
            return {"answer": result}
        if isinstance(result, dict):
            return result
        return {"output": str(result)}

    return _target


def create_async_chain_target(
    chain: Any,
    *,
    input_mapper: Callable[[dict[str, Any]], Any] | None = None,
    output_mapper: Callable[[Any], dict[str, Any]] | None = None,
    config: dict[str, Any] | None = None,
) -> Callable[..., Any]:
    """Wrap a LangChain Runnable/Chain as an async evaluation target.

    Args:
        chain: A LangChain Runnable (must have .ainvoke() method).
        input_mapper: Optional function to transform dataset inputs.
        output_mapper: Optional function to transform chain outputs into dicts.
        config: Optional RunnableConfig.

    Returns:
        An async callable suitable for use with aevaluate().
    """

    async def _target(inputs: dict[str, Any]) -> dict[str, Any]:
        chain_input = input_mapper(inputs) if input_mapper else inputs
        result = await chain.ainvoke(chain_input, config=config)

        if output_mapper:
            return output_mapper(result)

        if hasattr(result, "content"):
            return {"answer": result.content}
        if isinstance(result, str):
            return {"answer": result}
        if isinstance(result, dict):
            return result
        return {"output": str(result)}

    return _target


def evaluate_chain(
    chain: Any,
    *,
    data: str | list[dict[str, Any]],
    evaluators: Sequence[Callable[..., Any]],
    input_mapper: Callable[[dict[str, Any]], Any] | None = None,
    output_mapper: Callable[[Any], dict[str, Any]] | None = None,
    config: dict[str, Any] | None = None,
    summary_evaluators: Sequence[Callable[..., Any]] | None = None,
    experiment_prefix: str | None = None,
    description: str | None = None,
    max_concurrency: int | None = None,
    num_repetitions: int = 1,
    client: Any | None = None,
    metadata: dict[str, Any] | None = None,
    upload_results: bool = True,
) -> Any:
    """Evaluate a LangChain chain against a dataset.

    Convenience function combining create_chain_target() + run_eval().
    """
    target = create_chain_target(
        chain, input_mapper=input_mapper, output_mapper=output_mapper, config=config
    )
    return run_eval(
        target,
        data=data,
        evaluators=evaluators,
        summary_evaluators=summary_evaluators,
        experiment_prefix=experiment_prefix,
        description=description,
        max_concurrency=max_concurrency,
        num_repetitions=num_repetitions,
        client=client,
        metadata=metadata,
        upload_results=upload_results,
    )


async def aevaluate_chain(
    chain: Any,
    *,
    data: str | list[dict[str, Any]],
    evaluators: Sequence[Callable[..., Any]],
    input_mapper: Callable[[dict[str, Any]], Any] | None = None,
    output_mapper: Callable[[Any], dict[str, Any]] | None = None,
    config: dict[str, Any] | None = None,
    summary_evaluators: Sequence[Callable[..., Any]] | None = None,
    experiment_prefix: str | None = None,
    description: str | None = None,
    max_concurrency: int | None = None,
    num_repetitions: int = 1,
    client: Any | None = None,
    metadata: dict[str, Any] | None = None,
    upload_results: bool = True,
) -> Any:
    """Async evaluate a LangChain chain against a dataset."""
    target = create_async_chain_target(
        chain, input_mapper=input_mapper, output_mapper=output_mapper, config=config
    )
    return await arun_eval(
        target,
        data=data,
        evaluators=evaluators,
        summary_evaluators=summary_evaluators,
        experiment_prefix=experiment_prefix,
        description=description,
        max_concurrency=max_concurrency,
        num_repetitions=num_repetitions,
        client=client,
        metadata=metadata,
        upload_results=upload_results,
    )
