"""Utilities for creating custom scorers with minimal boilerplate."""

from __future__ import annotations

import logging
from collections.abc import Callable, Sequence
from typing import Any

from lef.core.decorators import scorer as scorer_decorator
from lef.core.types import EvalResult

logger = logging.getLogger(__name__)


def create_scorer(
    key: str,
    fn: Callable[..., float | bool | dict[str, Any] | EvalResult],
) -> Callable[..., Any]:
    """Create a LangSmith-compatible scorer from a simple function.

    Alternative to the @scorer decorator for when you want to create
    scorers dynamically (e.g., from configuration).

    Args:
        key: The evaluation metric key name.
        fn: A function that takes (inputs, outputs, reference_outputs) kwargs
            and returns a score (float, bool, dict, or EvalResult).

    Returns:
        A LangSmith-compatible evaluator function.

    Example::

        def my_logic(*, inputs, outputs, **kwargs):
            return len(outputs.get("answer", "")) > 10

        length_check = create_scorer("min_length", my_logic)
    """
    return scorer_decorator(key=key)(fn)


def create_composite_scorer(
    key: str,
    scorers: Sequence[Callable[..., Any]],
    *,
    aggregation: str = "mean",
) -> Callable[..., Any]:
    """Create a composite scorer that combines multiple scorers.

    Args:
        key: The evaluation metric key for the composite score.
        scorers: List of scorer functions to combine.
        aggregation: How to combine scores - "mean", "min", "max", or "all_pass".

    Returns:
        A LangSmith-compatible evaluator function.

    Example::

        composite = create_composite_scorer(
            "quality",
            scorers=[exact_match, contains],
            aggregation="max",
        )
    """

    def _composite(
        *,
        inputs: dict[str, Any],
        outputs: dict[str, Any],
        reference_outputs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> EvalResult:
        scores: list[float] = []

        for s in scorers:
            result = s(inputs=inputs, outputs=outputs, reference_outputs=reference_outputs)
            if isinstance(result, EvalResult):
                score_val = float(result.score) if isinstance(result.score, bool) else result.score
            elif isinstance(result, dict):
                raw = result.get("score", 0.0)
                score_val = float(raw) if isinstance(raw, bool) else raw
            elif isinstance(result, bool):
                score_val = 1.0 if result else 0.0
            else:
                score_val = float(result)
            scores.append(score_val)

        if not scores:
            logger.warning("Composite scorer '%s': no scorers produced results", key)

        if aggregation == "mean":
            final = sum(scores) / len(scores) if scores else 0.0
        elif aggregation == "min":
            final = min(scores) if scores else 0.0
        elif aggregation == "max":
            final = max(scores) if scores else 0.0
        elif aggregation == "all_pass":
            final = 1.0 if scores and all(s >= 1.0 for s in scores) else 0.0
        else:
            raise ValueError(f"Unknown aggregation: {aggregation}")

        return EvalResult(
            key=key,
            score=final,
            comment=f"Composite ({aggregation}) of {len(scores)} scorers",
            metadata={"individual_scores": scores},
        )

    return scorer_decorator(key=key)(_composite)
