"""Built-in scorer functions for common evaluation patterns.

All scorers follow the LangSmith evaluator signature and can be passed
directly to langsmith.evaluate().
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from lef.core.decorators import scorer

logger = logging.getLogger(__name__)


@scorer(key="exact_match")
def exact_match(
    *,
    inputs: dict[str, Any],
    outputs: dict[str, Any],
    reference_outputs: dict[str, Any] | None = None,
    **kwargs: Any,
) -> bool:
    """Check if the output exactly matches the reference output.

    Compares the 'answer' key by default, or the first matching key
    between outputs and reference_outputs.
    """
    if not reference_outputs:
        return False

    # Check all matching keys between outputs and reference_outputs
    matched_any = False
    for key in reference_outputs:
        if key in outputs:
            if str(outputs[key]).strip() != str(reference_outputs[key]).strip():
                return False
            matched_any = True

    if not matched_any and reference_outputs and outputs:
        logger.warning(
            "exact_match: no overlapping keys between outputs %s and "
            "reference_outputs %s. Check your output_mapper.",
            list(outputs.keys()),
            list(reference_outputs.keys()),
        )

    return matched_any


@scorer(key="contains")
def contains(
    *,
    inputs: dict[str, Any],
    outputs: dict[str, Any],
    reference_outputs: dict[str, Any] | None = None,
    **kwargs: Any,
) -> bool:
    """Check if the output contains the reference text.

    Looks for reference_outputs values within the corresponding output values.
    """
    if not reference_outputs:
        return False

    # Check all matching keys
    matched_any = False
    for key in reference_outputs:
        if key in outputs:
            if str(reference_outputs[key]).lower() not in str(outputs[key]).lower():
                return False
            matched_any = True

    return matched_any


@scorer(key="regex_match")
def regex_match(
    *,
    inputs: dict[str, Any],
    outputs: dict[str, Any],
    reference_outputs: dict[str, Any] | None = None,
    **kwargs: Any,
) -> bool:
    """Check if the output matches a regex pattern from reference_outputs.

    Expects reference_outputs to have a 'pattern' key with the regex pattern.
    Matches against the 'answer' or first key in outputs.
    """
    if not reference_outputs or "pattern" not in reference_outputs:
        return False

    pattern = reference_outputs["pattern"]
    output_text = str(outputs.get("answer", next(iter(outputs.values()), "")))

    try:
        return bool(re.search(pattern, output_text))
    except re.error:
        return False


@scorer(key="json_match")
def json_match(
    *,
    inputs: dict[str, Any],
    outputs: dict[str, Any],
    reference_outputs: dict[str, Any] | None = None,
    **kwargs: Any,
) -> float:
    """Compare JSON outputs field by field, returning fraction of matching fields.

    Expects outputs and reference_outputs to have JSON-serializable values
    under matching keys.
    """
    if not reference_outputs:
        return 0.0

    # Try to parse JSON strings if needed
    def _parse(val: Any) -> Any:
        if isinstance(val, str):
            try:
                return json.loads(val)
            except (json.JSONDecodeError, TypeError):
                return val
        return val

    total_fields = 0
    matching_fields = 0

    for key in reference_outputs:
        if key in outputs:
            ref_val = _parse(reference_outputs[key])
            out_val = _parse(outputs[key])

            if isinstance(ref_val, dict) and isinstance(out_val, dict):
                for field in ref_val:
                    total_fields += 1
                    if field in out_val and out_val[field] == ref_val[field]:
                        matching_fields += 1
            else:
                total_fields += 1
                if ref_val == out_val:
                    matching_fields += 1

    return matching_fields / total_fields if total_fields > 0 else 0.0


# ---------------------------------------------------------------------------
# Summary evaluators (experiment-level, used with summary_evaluators= param)
# ---------------------------------------------------------------------------


def pass_rate(threshold: float = 1.0, key: str = "pass_rate") -> Any:
    """Create a summary evaluator that computes the pass rate across all rows.

    A row "passes" if **all** of its evaluator scores are >= ``threshold``.

    Args:
        threshold: Minimum score for a row to be considered passing (default 1.0).
        key: The feedback key for the summary result.

    Returns:
        A summary evaluator callable for use with ``summary_evaluators=``.

    Example::

        results = run_eval(
            target=my_app,
            data=examples,
            evaluators=[exact_match, safety_judge()],
            summary_evaluators=[pass_rate(threshold=0.8)],
        )
    """

    def _summary(runs: list[Any], examples: list[Any]) -> dict[str, Any]:
        if not runs:
            return {"key": key, "score": 0.0}

        passing = 0
        for run in runs:
            feedback = run.feedback_stats if hasattr(run, "feedback_stats") else {}
            if feedback:
                if all(
                    (v.get("avg", 0) if isinstance(v, dict) else v) >= threshold
                    for v in feedback.values()
                ):
                    passing += 1
            else:
                logger.warning(
                    "pass_rate: run %s has no feedback_stats, treating as failing",
                    getattr(run, "id", "unknown"),
                )

        return {"key": key, "score": passing / len(runs)}

    return _summary


def mean_score(scorer_key: str, *, key: str | None = None) -> Any:
    """Create a summary evaluator that computes the mean of a specific scorer.

    Args:
        scorer_key: The evaluator key to aggregate (e.g., "correctness").
        key: The feedback key for the summary result. Defaults to
            ``"{scorer_key}_mean"``.

    Returns:
        A summary evaluator callable.

    Example::

        results = run_eval(
            target=my_app,
            data=examples,
            evaluators=[correctness_judge()],
            summary_evaluators=[mean_score("correctness")],
        )
    """
    result_key = key or f"{scorer_key}_mean"

    def _summary(runs: list[Any], examples: list[Any]) -> dict[str, Any]:
        scores: list[float] = []
        for run in runs:
            feedback = run.feedback_stats if hasattr(run, "feedback_stats") else {}
            if scorer_key in feedback:
                val = feedback[scorer_key]
                scores.append(val.get("avg", 0.0) if isinstance(val, dict) else float(val))

        if not scores:
            return {"key": result_key, "score": 0.0, "comment": f"No '{scorer_key}' scores found"}

        return {
            "key": result_key,
            "score": sum(scores) / len(scores),
            "comment": f"Mean of {len(scores)} '{scorer_key}' scores",
        }

    return _summary
