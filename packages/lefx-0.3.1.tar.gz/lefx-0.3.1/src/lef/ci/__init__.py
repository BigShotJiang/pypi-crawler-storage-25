"""CI/CD integrations for LEF (GitHub, Azure DevOps).

Provides automated PR comment posting with evaluation results and
comparison reports for continuous integration pipelines.
"""

from lef.ci.azuredevops import post_azdo_comment
from lef.ci.github import post_github_comment

__all__ = [
    "post_azdo_comment",
    "post_github_comment",
]
