"""GitHub PR comment integration for LEF.

Posts evaluation results and comparison reports as PR comments
using the GitHub REST API.
"""

from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.request
from typing import Any

logger = logging.getLogger(__name__)


def post_github_comment(
    body: str,
    *,
    repo: str | None = None,
    pr_number: str | int | None = None,
    token: str | None = None,
    update_existing: bool = True,
    comment_marker: str = "<!-- lef-eval-results -->",
) -> dict[str, Any]:
    """Post or update a PR comment on GitHub with evaluation results.

    Args:
        body: Markdown body of the comment.
        repo: Repository in "owner/repo" format. Auto-detected from
            GITHUB_REPOSITORY env var if not provided.
        pr_number: PR number. Auto-detected from GITHUB_REF env var
            if not provided.
        token: GitHub token. Falls back to GITHUB_TOKEN env var.
        update_existing: If True, updates an existing LEF comment
            instead of creating a new one (uses comment_marker).
        comment_marker: Hidden HTML marker to identify LEF comments.

    Returns:
        Dict with 'comment_id', 'url', and 'action' ('created' or 'updated').

    Raises:
        ValueError: If repo or PR number cannot be determined.
        ConnectionError: If the GitHub API call fails.
    """
    repo = repo or os.environ.get("GITHUB_REPOSITORY")
    if not repo:
        raise ValueError(
            "Cannot determine repository. Set GITHUB_REPOSITORY env var or pass repo= argument."
        )

    if pr_number is None:
        pr_number = _detect_pr_number()
    if pr_number is None:
        raise ValueError(
            "Cannot determine PR number. Set GITHUB_PR_NUMBER env var or pass pr_number= argument."
        )

    token = token or os.environ.get("GITHUB_TOKEN")
    if not token:
        raise ValueError("GitHub token required. Set GITHUB_TOKEN env var or pass token= argument.")

    full_body = f"{comment_marker}\n{body}"

    # Try to find and update existing comment
    if update_existing:
        existing_id = _find_existing_comment(
            repo=repo,
            pr_number=str(pr_number),
            token=token,
            marker=comment_marker,
        )
        if existing_id:
            result = _update_comment(
                repo=repo,
                comment_id=existing_id,
                body=full_body,
                token=token,
            )
            result["action"] = "updated"
            logger.info("Updated existing GitHub comment %s", existing_id)
            return result

    # Create new comment
    result = _create_comment(
        repo=repo,
        pr_number=str(pr_number),
        body=full_body,
        token=token,
    )
    result["action"] = "created"
    logger.info("Created new GitHub comment on PR #%s", pr_number)
    return result


def _detect_pr_number() -> str | None:
    """Auto-detect PR number from environment."""
    # Direct env var
    pr = os.environ.get("GITHUB_PR_NUMBER")
    if pr:
        return pr

    # Extract from GITHUB_REF (refs/pull/123/merge)
    ref = os.environ.get("GITHUB_REF", "")
    parts = ref.split("/")
    if len(parts) >= 3 and parts[1] == "pull":
        return parts[2]

    return None


def _github_api(
    method: str,
    url: str,
    *,
    token: str,
    body: dict[str, Any] | None = None,
) -> Any:
    """Make a GitHub API request."""
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github.v3+json",
        "Content-Type": "application/json",
    }

    data = json.dumps(body).encode("utf-8") if body else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        error_body = exc.read().decode("utf-8") if exc.fp else ""
        raise ConnectionError(f"GitHub API error {exc.code}: {error_body}") from exc
    except urllib.error.URLError as exc:
        raise ConnectionError(f"GitHub API connection error: {exc.reason}") from exc


def _find_existing_comment(
    *,
    repo: str,
    pr_number: str,
    token: str,
    marker: str,
) -> int | None:
    """Find an existing LEF comment by marker."""
    url = f"https://api.github.com/repos/{repo}/issues/{pr_number}/comments?per_page=100"
    try:
        comments = _github_api("GET", url, token=token)
        for comment in comments:
            if isinstance(comment, dict) and marker in comment.get("body", ""):
                return comment["id"]
    except ConnectionError:
        logger.warning("Failed to search for existing comments")
    return None


def _create_comment(
    *,
    repo: str,
    pr_number: str,
    body: str,
    token: str,
) -> dict[str, Any]:
    """Create a new PR comment."""
    url = f"https://api.github.com/repos/{repo}/issues/{pr_number}/comments"
    result = _github_api("POST", url, token=token, body={"body": body})
    return {"comment_id": result["id"], "url": result.get("html_url", "")}


def _update_comment(
    *,
    repo: str,
    comment_id: int,
    body: str,
    token: str,
) -> dict[str, Any]:
    """Update an existing comment."""
    url = f"https://api.github.com/repos/{repo}/issues/comments/{comment_id}"
    result = _github_api("PATCH", url, token=token, body={"body": body})
    return {"comment_id": result["id"], "url": result.get("html_url", "")}
