"""Azure DevOps PR comment integration for LEF.

Posts evaluation results and comparison reports as PR comments
using the Azure DevOps REST API.
"""

from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.request
from typing import Any

logger = logging.getLogger(__name__)


def post_azdo_comment(
    body: str,
    *,
    organization: str | None = None,
    project: str | None = None,
    repo_id: str | None = None,
    pr_number: str | int | None = None,
    token: str | None = None,
    update_existing: bool = True,
    comment_marker: str = "<!-- lef-eval-results -->",
) -> dict[str, Any]:
    """Post or update a PR comment on Azure DevOps with evaluation results.

    Args:
        body: Markdown body of the comment.
        organization: Azure DevOps organization name. Auto-detected from
            SYSTEM_COLLECTIONURI env var if not provided.
        project: Azure DevOps project name. Auto-detected from
            SYSTEM_TEAMPROJECT env var if not provided.
        repo_id: Repository ID or name. Auto-detected from
            BUILD_REPOSITORY_ID env var.
        pr_number: PR number. Auto-detected from
            SYSTEM_PULLREQUEST_PULLREQUESTID env var.
        token: Personal Access Token or System.AccessToken.
            Falls back to SYSTEM_ACCESSTOKEN or AZURE_DEVOPS_PAT env var.
        update_existing: If True, updates existing LEF thread.
        comment_marker: Hidden HTML marker to identify LEF comments.

    Returns:
        Dict with 'thread_id' and 'action' ('created' or 'updated').

    Raises:
        ValueError: If required parameters cannot be determined.
        ConnectionError: If the Azure DevOps API call fails.
    """
    organization = organization or _extract_org_from_uri(os.environ.get("SYSTEM_COLLECTIONURI", ""))
    if not organization:
        raise ValueError(
            "Cannot determine Azure DevOps organization. "
            "Set SYSTEM_COLLECTIONURI env var or pass organization= argument."
        )

    project = project or os.environ.get("SYSTEM_TEAMPROJECT")
    if not project:
        raise ValueError(
            "Cannot determine project. Set SYSTEM_TEAMPROJECT env var or pass project= argument."
        )

    repo_id = repo_id or os.environ.get("BUILD_REPOSITORY_ID")
    if not repo_id:
        raise ValueError(
            "Cannot determine repository. Set BUILD_REPOSITORY_ID"
            " env var or pass repo_id= argument."
        )

    if pr_number is None:
        pr_number = os.environ.get("SYSTEM_PULLREQUEST_PULLREQUESTID")
    if pr_number is None:
        raise ValueError(
            "Cannot determine PR number. "
            "Set SYSTEM_PULLREQUEST_PULLREQUESTID env var or pass pr_number= argument."
        )

    token = token or os.environ.get("SYSTEM_ACCESSTOKEN") or os.environ.get("AZURE_DEVOPS_PAT")
    if not token:
        raise ValueError(
            "Azure DevOps token required. Set SYSTEM_ACCESSTOKEN or AZURE_DEVOPS_PAT env var."
        )

    full_body = f"{comment_marker}\n{body}"
    base_url = f"https://dev.azure.com/{organization}/{project}/_apis/git/repositories/{repo_id}/pullRequests/{pr_number}/threads"

    # Try to find and update existing thread
    if update_existing:
        existing_thread = _find_existing_thread(
            base_url=base_url,
            token=token,
            marker=comment_marker,
        )
        if existing_thread:
            result = _update_thread(
                base_url=base_url,
                thread_id=existing_thread,
                body=full_body,
                token=token,
            )
            result["action"] = "updated"
            logger.info("Updated existing Azure DevOps thread %s", existing_thread)
            return result

    # Create new thread
    result = _create_thread(
        base_url=base_url,
        body=full_body,
        token=token,
    )
    result["action"] = "created"
    logger.info("Created new Azure DevOps comment on PR #%s", pr_number)
    return result


def _extract_org_from_uri(uri: str) -> str | None:
    """Extract organization from SYSTEM_COLLECTIONURI like https://dev.azure.com/org/."""
    if not uri:
        return None
    # https://dev.azure.com/myorg/ -> myorg
    parts = uri.rstrip("/").split("/")
    if len(parts) >= 4 and "dev.azure.com" in uri:
        return parts[-1]
    # https://myorg.visualstudio.com/ -> myorg
    if ".visualstudio.com" in uri:
        host = uri.split("//")[-1].split(".")[0]
        return host
    return None


def _azdo_api(
    method: str,
    url: str,
    *,
    token: str,
    body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Make an Azure DevOps API request."""
    import base64

    auth = base64.b64encode(f":{token}".encode()).decode()
    headers = {
        "Authorization": f"Basic {auth}",
        "Content-Type": "application/json",
    }

    data = json.dumps(body).encode("utf-8") if body else None
    # Azure DevOps API versioning
    separator = "&" if "?" in url else "?"
    versioned_url = f"{url}{separator}api-version=7.1"

    req = urllib.request.Request(versioned_url, data=data, headers=headers, method=method)

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        error_body = exc.read().decode("utf-8") if exc.fp else ""
        raise ConnectionError(f"Azure DevOps API error {exc.code}: {error_body}") from exc
    except urllib.error.URLError as exc:
        raise ConnectionError(f"Azure DevOps API connection error: {exc.reason}") from exc


def _find_existing_thread(
    *,
    base_url: str,
    token: str,
    marker: str,
) -> int | None:
    """Find an existing LEF comment thread by marker."""
    try:
        result = _azdo_api("GET", base_url, token=token)
        for thread in result.get("value", []):
            comments = thread.get("comments", [])
            if comments and marker in comments[0].get("content", ""):
                return thread["id"]
    except ConnectionError:
        logger.warning("Failed to search for existing Azure DevOps threads")
    return None


def _create_thread(
    *,
    base_url: str,
    body: str,
    token: str,
) -> dict[str, Any]:
    """Create a new PR comment thread."""
    payload = {
        "comments": [{"parentCommentId": 0, "content": body, "commentType": 1}],
        "status": 1,  # Active
    }
    result = _azdo_api("POST", base_url, token=token, body=payload)
    return {"thread_id": result.get("id")}


def _update_thread(
    *,
    base_url: str,
    thread_id: int,
    body: str,
    token: str,
) -> dict[str, Any]:
    """Update the first comment in an existing thread."""
    url = f"{base_url}/{thread_id}/comments/1"
    _azdo_api("PATCH", url, token=token, body={"content": body})
    return {"thread_id": thread_id}
