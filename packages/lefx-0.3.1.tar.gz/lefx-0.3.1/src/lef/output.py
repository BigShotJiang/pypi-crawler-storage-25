"""Rich terminal output, result formatting, and export (JSON, CSV, JUnit XML).

Provides table-formatted terminal output with per-evaluator scores and
export to structured formats for CI artifact consumption.
"""

from __future__ import annotations

import csv
import json
import logging
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

from lef.assertions import _extract_scores

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Score extraction helpers
# ---------------------------------------------------------------------------


def _collect_rows(results: Any) -> list[dict[str, Any]]:
    """Extract per-row result dicts from any result format.

    Returns a list of dicts with keys like:
        {"example_id": ..., "scores": {"key": score, ...}}
    """
    rows: list[dict[str, Any]] = []

    for idx, row in enumerate(results):
        scores: dict[str, float] = {}
        example_id = str(idx + 1)

        if isinstance(row, dict) and "evaluation_results" in row:
            # LangSmith ExperimentResultRow
            if "example" in row and hasattr(row["example"], "id"):
                example_id = str(row["example"].id)[:8]
            eval_results = row["evaluation_results"]
            inner = eval_results.get("results", []) if isinstance(eval_results, dict) else []
            for er in inner:
                key = getattr(er, "key", None) or (er.get("key") if isinstance(er, dict) else None)
                score = getattr(er, "score", None)
                if score is None and isinstance(er, dict):
                    score = er.get("score", 0.0)
                if key is not None and score is not None:
                    scores[key] = float(score)
        elif isinstance(row, dict):
            key = row.get("key", "score")
            score = row.get("score", 0.0)
            scores[key] = float(score)
        elif hasattr(row, "key") and hasattr(row, "score"):
            scores[row.key] = float(row.score)

        if scores:
            rows.append({"example_id": example_id, "scores": scores})

    return rows


# ---------------------------------------------------------------------------
# Terminal output
# ---------------------------------------------------------------------------


def format_results_table(results: Any, thresholds: dict[str, float] | None = None) -> str:
    """Format evaluation results as a terminal-friendly table.

    Returns a multi-line string with per-example scores, summary stats,
    and optional pass/fail indicators against thresholds.
    """
    scores_by_key = _extract_scores(results)
    if not scores_by_key:
        return "No evaluation results to display."

    keys = sorted(scores_by_key.keys())

    # Compute summary
    summary: dict[str, dict[str, float]] = {}
    for k in keys:
        vals = scores_by_key[k]
        avg = sum(vals) / len(vals) if vals else 0.0
        mn = min(vals) if vals else 0.0
        mx = max(vals) if vals else 0.0
        summary[k] = {"avg": avg, "min": mn, "max": mx, "count": len(vals)}

    # Build table
    lines: list[str] = []
    lines.append("")
    lines.append("=" * 70)
    lines.append("  LEF Evaluation Results")
    lines.append("=" * 70)
    lines.append("")

    # Summary table
    header = f"  {'Metric':<30} {'Avg':>8} {'Min':>8} {'Max':>8} {'N':>5}"
    lines.append(header)
    lines.append("  " + "-" * 62)

    for k in keys:
        s = summary[k]
        status = ""
        if thresholds and k in thresholds:
            status = " PASS" if s["avg"] >= thresholds[k] else " FAIL"
        lines.append(
            f"  {k:<30} {s['avg']:>8.4f} {s['min']:>8.4f} "
            f"{s['max']:>8.4f} {int(s['count']):>5}{status}"
        )

    lines.append("")

    # Threshold summary
    if thresholds:
        lines.append("  Thresholds:")
        all_pass = True
        for k, thresh in sorted(thresholds.items()):
            actual = summary.get(k, {}).get("avg", 0.0)
            passed = actual >= thresh
            if not passed:
                all_pass = False
            mark = "PASS" if passed else "FAIL"
            lines.append(f"    {k}: {actual:.4f} >= {thresh:.4f} [{mark}]")

        lines.append("")
        if all_pass:
            lines.append("  Result: ALL THRESHOLDS PASSED")
        else:
            lines.append("  Result: SOME THRESHOLDS FAILED")

    lines.append("=" * 70)
    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Export: JSON
# ---------------------------------------------------------------------------


def export_json(results: Any, path: str | Path, *, metadata: dict[str, Any] | None = None) -> None:
    """Export evaluation results to a JSON file."""
    scores_by_key = _extract_scores(results)
    summary = {k: sum(v) / len(v) for k, v in scores_by_key.items()}
    rows = _collect_rows(results)

    output = {
        "summary": summary,
        "rows": rows,
        "metadata": metadata or {},
    }

    filepath = Path(path)
    filepath.parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, default=str)

    logger.info("Exported JSON results to %s", filepath)


# ---------------------------------------------------------------------------
# Export: CSV
# ---------------------------------------------------------------------------


def export_csv(results: Any, path: str | Path) -> None:
    """Export evaluation results to a CSV file."""
    rows = _collect_rows(results)
    if not rows:
        logger.warning("No results to export to CSV.")
        return

    # Collect all score keys
    all_keys: set[str] = set()
    for row in rows:
        all_keys.update(row["scores"].keys())
    sorted_keys = sorted(all_keys)

    filepath = Path(path)
    filepath.parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["example_id"] + sorted_keys)
        for row in rows:
            writer.writerow([row["example_id"]] + [row["scores"].get(k, "") for k in sorted_keys])

    logger.info("Exported CSV results to %s", filepath)


# ---------------------------------------------------------------------------
# Export: JUnit XML
# ---------------------------------------------------------------------------


def export_junit_xml(
    results: Any,
    path: str | Path,
    *,
    thresholds: dict[str, float] | None = None,
    suite_name: str = "lef-evaluation",
) -> None:
    """Export evaluation results as JUnit XML for CI systems.

    Each metric key becomes a test case. A test case fails if its average
    score is below the corresponding threshold.
    """
    scores_by_key = _extract_scores(results)
    thresholds = thresholds or {}

    testsuite = ET.Element("testsuite", name=suite_name, tests=str(len(scores_by_key)))
    failures = 0

    for key in sorted(scores_by_key.keys()):
        vals = scores_by_key[key]
        avg = sum(vals) / len(vals) if vals else 0.0

        testcase = ET.SubElement(
            testsuite,
            "testcase",
            name=key,
            classname="lef.evaluators",
            time="0",
        )

        threshold = thresholds.get(key)
        if threshold is not None and avg < threshold:
            failures += 1
            failure = ET.SubElement(
                testcase,
                "failure",
                message=f"{key}: {avg:.4f} < {threshold:.4f}",
                type="ThresholdFailure",
            )
            failure.text = f"Average score {avg:.4f} below threshold {threshold:.4f}"

        # Add score as a property
        props = ET.SubElement(testcase, "properties")
        ET.SubElement(props, "property", name="average_score", value=f"{avg:.4f}")
        ET.SubElement(props, "property", name="sample_count", value=str(len(vals)))

    testsuite.set("failures", str(failures))

    filepath = Path(path)
    filepath.parent.mkdir(parents=True, exist_ok=True)
    tree = ET.ElementTree(testsuite)
    ET.indent(tree, space="  ")
    tree.write(filepath, encoding="unicode", xml_declaration=True)

    logger.info(
        "Exported JUnit XML to %s (%d tests, %d failures)",
        filepath,
        len(scores_by_key),
        failures,
    )


# ---------------------------------------------------------------------------
# Export: Markdown
# ---------------------------------------------------------------------------


def export_markdown(
    results: Any,
    path: str | Path,
    *,
    thresholds: dict[str, float] | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Export evaluation results as a Markdown report.

    Produces a human-readable Markdown file with a summary table,
    per-example detail rows, and optional pass/fail threshold checks.
    Ideal for PR comments, documentation, or sharing results.

    Args:
        results: Evaluation results (any LEF/LangSmith result format).
        path: Output file path (should end in .md).
        thresholds: Optional score thresholds for pass/fail indicators.
        metadata: Optional metadata dict to include in the report header.
    """
    scores_by_key = _extract_scores(results)
    rows = _collect_rows(results)

    if not scores_by_key:
        filepath = Path(path)
        filepath.parent.mkdir(parents=True, exist_ok=True)
        filepath.write_text("# LEF Evaluation Report\n\nNo evaluation results.\n", encoding="utf-8")
        return

    keys = sorted(scores_by_key.keys())

    lines: list[str] = []
    lines.append("# LEF Evaluation Report")
    lines.append("")

    # Metadata section
    if metadata:
        for mk, mv in metadata.items():
            lines.append(f"- **{mk}**: {mv}")
        lines.append("")

    # Summary table
    lines.append("## Summary")
    lines.append("")
    if thresholds:
        lines.append("| Metric | Avg | Min | Max | N | Threshold | Status |")
        lines.append("|--------|-----|-----|-----|---|-----------|--------|")
    else:
        lines.append("| Metric | Avg | Min | Max | N |")
        lines.append("|--------|-----|-----|-----|---|")

    all_pass = True
    for k in keys:
        vals = scores_by_key[k]
        avg = sum(vals) / len(vals) if vals else 0.0
        mn = min(vals) if vals else 0.0
        mx = max(vals) if vals else 0.0
        n = len(vals)

        if thresholds and k in thresholds:
            t = thresholds[k]
            passed = avg >= t
            if not passed:
                all_pass = False
            status = "PASS" if passed else "FAIL"
            lines.append(f"| {k} | {avg:.4f} | {mn:.4f} | {mx:.4f} | {n} | {t:.4f} | {status} |")
        elif thresholds:
            lines.append(f"| {k} | {avg:.4f} | {mn:.4f} | {mx:.4f} | {n} | - | - |")
        else:
            lines.append(f"| {k} | {avg:.4f} | {mn:.4f} | {mx:.4f} | {n} |")

    lines.append("")

    # Threshold verdict
    if thresholds:
        if all_pass:
            lines.append("**Result: ALL THRESHOLDS PASSED**")
        else:
            lines.append("**Result: SOME THRESHOLDS FAILED**")
        lines.append("")

    # Per-example detail table
    if rows:
        lines.append("## Per-Example Results")
        lines.append("")
        lines.append("| Example | " + " | ".join(keys) + " |")
        lines.append("|" + "---------|" * (len(keys) + 1))

        for row in rows:
            cells = [f"{row['scores'].get(k, '-')}" for k in keys]
            lines.append(f"| {row['example_id']} | " + " | ".join(cells) + " |")

        lines.append("")

    filepath = Path(path)
    filepath.parent.mkdir(parents=True, exist_ok=True)
    filepath.write_text("\n".join(lines), encoding="utf-8")

    logger.info("Exported Markdown report to %s", filepath)


# ---------------------------------------------------------------------------
# Auto-detect export format
# ---------------------------------------------------------------------------


def export_results(
    results: Any,
    path: str | Path,
    *,
    thresholds: dict[str, float] | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Export results, auto-detecting format from file extension.

    Supported: .json, .csv, .xml (JUnit), .md (Markdown)
    """
    filepath = Path(path)
    suffix = filepath.suffix.lower()

    if suffix == ".json":
        export_json(results, filepath, metadata=metadata)
    elif suffix == ".csv":
        export_csv(results, filepath)
    elif suffix == ".xml":
        export_junit_xml(results, filepath, thresholds=thresholds)
    elif suffix == ".md":
        export_markdown(results, filepath, thresholds=thresholds, metadata=metadata)
    else:
        raise ValueError(f"Unsupported output format '{suffix}'. Supported: .json, .csv, .xml, .md")
