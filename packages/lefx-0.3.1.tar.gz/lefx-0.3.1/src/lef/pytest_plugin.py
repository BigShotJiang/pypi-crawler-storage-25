"""pytest plugin for LEF evaluations.

Integrates LEF evaluations into pytest test suites so that evals
run alongside regular unit tests.

Usage::

    # In conftest.py or any test file
    from lef.pytest_plugin import lef_eval

    def test_correctness(lef_eval):
        results = lef_eval(
            target=my_chain.invoke,
            data="examples.yaml",
            evaluators=[exact_match, correctness_judge()],
            thresholds={"correctness": 0.8, "exact_match": 0.9},
        )
        # Results are automatically asserted against thresholds
        # and reported in pytest output

Or via config files::

    # pytest --lef-config eval_suite.yaml
    # Automatically discovers and runs eval configs as test cases

Or as a fixture::

    @pytest.mark.lef(config="eval_suite.yaml")
    def test_my_eval():
        pass  # Eval is run by the marker
"""

from __future__ import annotations

import logging
from collections.abc import Callable, Sequence
from pathlib import Path
from typing import Any

import pytest

logger = logging.getLogger(__name__)


def pytest_addoption(parser: Any) -> None:
    """Add LEF-specific command-line options to pytest."""
    group = parser.getgroup("lef", "LEF Evaluation Framework")
    group.addoption(
        "--lef-config",
        action="append",
        default=[],
        help="Path to LEF eval config file(s). Each config becomes a test case.",
    )
    group.addoption(
        "--lef-no-upload",
        action="store_true",
        default=False,
        help="Disable uploading results to LangSmith.",
    )
    group.addoption(
        "--lef-prefix",
        default=None,
        help="Override experiment prefix for all LEF evals.",
    )


def pytest_configure(config: Any) -> None:
    """Register the 'lef' marker."""
    config.addinivalue_line(
        "markers",
        "lef(config=None, thresholds=None): mark a test as a LEF evaluation",
    )


def pytest_collect_file(parent: Any, file_path: Path) -> Any:
    """Collect LEF config files passed via --lef-config."""
    if not hasattr(parent, "config"):
        return None
    configs = parent.config.getoption("--lef-config", default=[])
    if str(file_path) in configs:
        return LefConfigFile.from_parent(parent, path=file_path)
    return None


class LefConfigFile(pytest.File):
    """A pytest collector for LEF config files."""

    def collect(self) -> Any:
        yield LefConfigItem.from_parent(self, name=f"lef:{self.path.name}")


class LefConfigItem(pytest.Item):
    """A pytest test item that runs a LEF evaluation from a config file."""

    def runtest(self) -> None:
        from lef.cli import _load_config, _resolve_evaluator, _resolve_target, _validate_config

        config = _load_config(str(self.path))

        # Validate
        warnings = _validate_config(config, str(self.path))
        for w in warnings:
            logger.warning(w)

        # Apply CLI overrides
        if self.config.getoption("--lef-no-upload"):
            config["upload_results"] = False
        prefix = self.config.getoption("--lef-prefix")
        if prefix:
            config["experiment_prefix"] = prefix

        # Resolve components
        evaluator_names = config.get("evaluators") or []
        evaluators = [_resolve_evaluator(name) for name in evaluator_names]
        if not evaluators:
            pytest.fail("No evaluators specified in config file.")

        target_ref = config.get("target")
        if not target_ref:
            pytest.fail("No target specified in config file.")
        target = _resolve_target(target_ref)

        # Resolve dataset
        from lef.datasets.loader import load_examples
        from lef.datasets.runner import run_eval

        dataset_ref = config.get("dataset", "")
        if dataset_ref and Path(dataset_ref).exists():
            data: str | list[dict[str, Any]] = load_examples(
                dataset_ref,
                input_keys=config.get("input_keys"),
                output_keys=config.get("output_keys"),
            )
        else:
            data = dataset_ref

        # Run eval
        results = run_eval(
            target,
            data=data,
            evaluators=evaluators,
            experiment_prefix=config.get("experiment_prefix"),
            max_concurrency=config.get("max_concurrency"),
            upload_results=config.get("upload_results", True),
        )

        # Check thresholds
        thresholds = config.get("thresholds", {})
        if thresholds:
            from lef.assertions import EvalAssertionError, assert_scores

            try:
                assert_scores(results, thresholds)
            except EvalAssertionError as exc:
                pytest.fail(str(exc))

    def repr_failure(self, excinfo: Any, style: Any = None) -> str:
        return str(excinfo.value)

    def reportinfo(self) -> Any:
        return self.path, 0, f"lef eval: {self.path.name}"


@pytest.fixture
def lef_eval(request: Any) -> Callable[..., Any]:
    """pytest fixture for running LEF evaluations inline.

    Usage::

        def test_my_eval(lef_eval):
            results = lef_eval(
                target=my_fn,
                data=[{"inputs": {"q": "hi"}, "outputs": {"a": "hello"}}],
                evaluators=[exact_match],
                thresholds={"exact_match": 1.0},
            )
    """

    def _run(
        target: Callable[..., Any],
        *,
        data: str | list[dict[str, Any]],
        evaluators: Sequence[Callable[..., Any]],
        thresholds: dict[str, float] | None = None,
        **kwargs: Any,
    ) -> Any:
        from lef.datasets.runner import run_eval

        # Default to no upload in tests
        kwargs.setdefault("upload_results", False)

        results = run_eval(target, data=data, evaluators=evaluators, **kwargs)

        if thresholds:
            from lef.assertions import EvalAssertionError, assert_scores

            try:
                assert_scores(results, thresholds)
            except EvalAssertionError as exc:
                pytest.fail(str(exc))

        return results

    return _run
