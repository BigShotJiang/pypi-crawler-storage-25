"""Configuration management for LEF.

Handles LangSmith connection settings, default model configurations,
and project-level eval settings.
"""

from __future__ import annotations

import os

from pydantic import BaseModel, Field

from lef.core.types import JudgeModel


class LefConfig(BaseModel):
    """Configuration for the LEF evaluation framework.

    Settings can be provided directly or loaded from environment variables.

    Example::

        # From environment (recommended)
        config = LefConfig.from_env()

        # Or explicit
        config = LefConfig(
            langsmith_api_key="lsv2_...",
            default_judge_model=JudgeModel.CLAUDE_SONNET,
        )
    """

    langsmith_api_key: str | None = Field(
        default=None,
        description="LangSmith API key. Falls back to LANGCHAIN_API_KEY env var.",
    )
    langsmith_project: str = Field(
        default="default",
        description="Default LangSmith project name.",
    )
    tracing_enabled: bool = Field(
        default=True,
        description="Whether LangSmith tracing is enabled.",
    )
    default_judge_model: JudgeModel = Field(
        default=JudgeModel.GPT_4O,
        description="Default model for LLM-as-Judge evaluators.",
    )
    max_concurrency: int = Field(
        default=5,
        description="Default max concurrency for evaluation runs.",
    )

    @classmethod
    def from_env(cls) -> LefConfig:
        """Create configuration from environment variables."""
        return cls(
            langsmith_api_key=os.environ.get("LANGCHAIN_API_KEY"),
            langsmith_project=os.environ.get("LANGCHAIN_PROJECT", "default"),
            tracing_enabled=os.environ.get("LANGCHAIN_TRACING_V2", "true").lower()
            in ("true", "1", "yes"),
        )

    def apply(self) -> None:
        """Apply this configuration to the environment and set as active config."""
        if self.langsmith_api_key:
            os.environ["LANGCHAIN_API_KEY"] = self.langsmith_api_key
        os.environ["LANGCHAIN_PROJECT"] = self.langsmith_project
        os.environ["LANGCHAIN_TRACING_V2"] = str(self.tracing_enabled).lower()
        set_config(self)


# Module-level active configuration
_active_config: LefConfig | None = None


def set_config(config: LefConfig) -> None:
    """Set the active LEF configuration.

    Once set, ``run_eval`` and other functions will use ``max_concurrency``
    from this config as a default (can still be overridden per-call).

    Example::

        config = LefConfig(max_concurrency=10, default_judge_model=JudgeModel.CLAUDE_SONNET)
        config.apply()  # Sets env vars AND activates the config
    """
    global _active_config  # noqa: PLW0603
    _active_config = config


def get_config() -> LefConfig | None:
    """Get the active LEF configuration, if one has been set."""
    return _active_config
