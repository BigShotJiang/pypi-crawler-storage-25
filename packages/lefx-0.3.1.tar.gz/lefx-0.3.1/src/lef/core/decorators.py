"""Decorator-based evaluator and scorer creation for LEF.

These decorators make it trivial to turn simple functions into
LangSmith-compatible evaluators.
"""

from __future__ import annotations

import asyncio
import functools
from collections.abc import Callable
from typing import Any

from lef.core.types import EvalResult


def scorer(
    key: str | None = None,
) -> Callable[..., Any]:
    """Decorator to create a scorer from a simple function.

    The decorated function should return a float (0-1), bool, or an EvalResult.
    The result is always normalized to a dict that LangSmith accepts natively.

    Example::

        @scorer(key="exact_match")
        def exact_match(*, inputs, outputs, reference_outputs, **kwargs):
            return outputs.get("answer") == reference_outputs.get("answer")

        # Use directly with langsmith.evaluate()
        from langsmith import evaluate
        evaluate(my_target, data="my-dataset", evaluators=[exact_match])
    """

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        eval_key = key or fn.__name__

        if asyncio.iscoroutinefunction(fn):

            @functools.wraps(fn)
            async def async_wrapper(
                run: Any = None,
                example: Any = None,
                *,
                inputs: dict[str, Any] | None = None,
                outputs: dict[str, Any] | None = None,
                reference_outputs: dict[str, Any] | None = None,
                **kwargs: Any,
            ) -> EvalResult:
                inputs, outputs, reference_outputs = _resolve_args(
                    run, example, inputs, outputs, reference_outputs
                )
                result = await fn(
                    inputs=inputs,
                    outputs=outputs,
                    reference_outputs=reference_outputs,
                    **kwargs,
                )
                return _normalize_result(result, eval_key)

            async_wrapper.key = eval_key  # type: ignore[attr-defined]
            return async_wrapper
        else:

            @functools.wraps(fn)
            def sync_wrapper(
                run: Any = None,
                example: Any = None,
                *,
                inputs: dict[str, Any] | None = None,
                outputs: dict[str, Any] | None = None,
                reference_outputs: dict[str, Any] | None = None,
                **kwargs: Any,
            ) -> EvalResult:
                inputs, outputs, reference_outputs = _resolve_args(
                    run, example, inputs, outputs, reference_outputs
                )
                result = fn(
                    inputs=inputs,
                    outputs=outputs,
                    reference_outputs=reference_outputs,
                    **kwargs,
                )
                return _normalize_result(result, eval_key)

            sync_wrapper.key = eval_key  # type: ignore[attr-defined]
            return sync_wrapper

    return decorator


def evaluator(
    key: str | None = None,
) -> Callable[..., Any]:
    """Alias for @scorer - creates a LangSmith-compatible evaluator from a function.

    Example::

        @evaluator(key="contains_keyword")
        def contains_keyword(*, inputs, outputs, **kwargs):
            keyword = inputs.get("keyword", "")
            return keyword.lower() in outputs.get("answer", "").lower()
    """
    return scorer(key=key)


def _resolve_args(
    run: Any,
    example: Any,
    inputs: dict[str, Any] | None,
    outputs: dict[str, Any] | None,
    reference_outputs: dict[str, Any] | None,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any] | None]:
    """Resolve arguments from either new-style kwargs or legacy run/example objects."""
    if inputs is None and run is not None:
        inputs = run.inputs if hasattr(run, "inputs") else {}
        if outputs is None:
            outputs = run.outputs if hasattr(run, "outputs") else {}
    if reference_outputs is None and example is not None:
        reference_outputs = example.outputs if hasattr(example, "outputs") else {}
    return inputs or {}, outputs or {}, reference_outputs


def _normalize_result(result: Any, key: str) -> EvalResult:
    """Convert a raw evaluator return value into an EvalResult.

    EvalResult inherits from dict, making it natively compatible
    with LangSmith's evaluate() which checks isinstance(result, dict).
    """
    if isinstance(result, EvalResult):
        return result
    if isinstance(result, dict):
        return EvalResult(
            key=result.get("key", key),
            score=result.get("score", 0.0),
            comment=result.get("comment"),
            metadata=result.get("metadata", {}),
        )
    if isinstance(result, bool):
        return EvalResult(key=key, score=float(result))
    if isinstance(result, (int, float)):
        return EvalResult(key=key, score=float(result))
    raise TypeError(
        f"Evaluator '{key}' returned unsupported type {type(result).__name__}. "
        "Expected EvalResult, dict, bool, int, or float."
    )
