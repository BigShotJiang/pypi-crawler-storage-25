"""Core type definitions for LEF."""

from __future__ import annotations

from enum import StrEnum
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, Field


class EvalResult(dict):  # type: ignore[type-arg]
    """Standard evaluation result returned by all LEF evaluators.

    Inherits from ``dict`` so that ``isinstance(result, dict)`` is True,
    which is required for LangSmith's ``evaluate()`` to accept the result.
    Also provides named attribute access (``result.key``, ``result.score``).
    """

    def __init__(
        self,
        *,
        key: str,
        score: float | bool,
        comment: str | None = None,
        metadata: dict[str, Any] | None = None,
    ):
        super().__init__(key=key, score=score)
        if comment is not None:
            self["comment"] = comment
        if metadata:
            self["metadata"] = metadata

    @property
    def key(self) -> str:
        return self["key"]

    @property
    def score(self) -> float | bool:
        return self["score"]

    @property
    def comment(self) -> str | None:
        return self.get("comment")

    @property
    def metadata(self) -> dict[str, Any]:
        return self.get("metadata", {})

    def model_dump(self) -> dict[str, Any]:
        """Pydantic-style serialization for compatibility."""
        return dict(self)

    def __repr__(self) -> str:
        return (
            f"EvalResult(key={self.key!r}, score={self.score!r}, "
            f"comment={self.comment!r}, metadata={self.metadata!r})"
        )


class EvalResultBatch(BaseModel):
    """A collection of evaluation results from a batch run."""

    results: list[Any] = Field(default_factory=list)
    dataset_name: str | None = None
    experiment_name: str | None = None

    @property
    def summary(self) -> dict[str, float]:
        """Compute average scores per key."""
        scores: dict[str, list[float]] = {}
        for r in self.results:
            score = r.score if hasattr(r, "score") else r.get("score", 0.0)
            key = r.key if hasattr(r, "key") else r.get("key", "score")
            val = float(score)
            scores.setdefault(key, []).append(val)
        return {k: sum(v) / len(v) for k, v in scores.items()}


class JudgeModel(StrEnum):
    """Supported LLM-as-Judge model providers using openevals format."""

    GPT_4O = "openai:gpt-4o"
    GPT_4O_MINI = "openai:gpt-4o-mini"
    CLAUDE_SONNET = "anthropic:claude-sonnet-4-20250514"
    CLAUDE_HAIKU = "anthropic:claude-haiku-4-5-20251001"


@runtime_checkable
class Evaluator(Protocol):
    """Protocol for synchronous evaluators compatible with LangSmith."""

    def __call__(
        self,
        *,
        inputs: dict[str, Any],
        outputs: dict[str, Any],
        reference_outputs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> EvalResult | dict[str, Any]: ...


@runtime_checkable
class AsyncEvaluator(Protocol):
    """Protocol for async evaluators compatible with LangSmith."""

    async def __call__(
        self,
        *,
        inputs: dict[str, Any],
        outputs: dict[str, Any],
        reference_outputs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> EvalResult | dict[str, Any]: ...
