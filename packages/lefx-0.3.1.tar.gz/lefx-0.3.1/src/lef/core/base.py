"""Base evaluator classes for LEF."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from lef.core.types import EvalResult


class BaseEvaluator(ABC):
    """Abstract base class for all LEF evaluators.

    Subclass this to create custom evaluators that integrate seamlessly
    with LangSmith's `evaluate()` function.

    Example::

        class MyEvaluator(BaseEvaluator):
            key = "my_metric"

            def evaluate(self, *, inputs, outputs, reference_outputs=None, **kwargs):
                score = 1.0 if outputs.get("answer") == reference_outputs.get("answer") else 0.0
                return EvalResult(key=self.key, score=score)

        # Use directly with langsmith.evaluate()
        from langsmith import evaluate
        evaluate(my_target, data="my-dataset", evaluators=[MyEvaluator()])
    """

    key: str = "base"

    @abstractmethod
    def evaluate(
        self,
        *,
        inputs: dict[str, Any],
        outputs: dict[str, Any],
        reference_outputs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> EvalResult:
        """Run the evaluation and return a result."""
        ...

    def __call__(
        self,
        run: Any = None,
        example: Any = None,
        *,
        inputs: dict[str, Any] | None = None,
        outputs: dict[str, Any] | None = None,
        reference_outputs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> EvalResult:
        """Make the evaluator callable, compatible with both LangSmith signatures.

        Supports both:
        - New-style: evaluator(inputs=..., outputs=..., reference_outputs=...)
        - Legacy-style: evaluator(run, example) where run/example are LangSmith objects
        """
        if inputs is None and run is not None:
            inputs = run.inputs if hasattr(run, "inputs") else {}
            if outputs is None:
                outputs = run.outputs if hasattr(run, "outputs") else {}
        if reference_outputs is None and example is not None:
            reference_outputs = example.outputs if hasattr(example, "outputs") else {}

        return self.evaluate(
            inputs=inputs or {},
            outputs=outputs or {},
            reference_outputs=reference_outputs,
            **kwargs,
        )


class AsyncBaseEvaluator(ABC):
    """Async version of BaseEvaluator for async evaluation pipelines."""

    key: str = "base"

    @abstractmethod
    async def aevaluate(
        self,
        *,
        inputs: dict[str, Any],
        outputs: dict[str, Any],
        reference_outputs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> EvalResult:
        """Run the async evaluation and return a result."""
        ...

    async def __call__(
        self,
        run: Any = None,
        example: Any = None,
        *,
        inputs: dict[str, Any] | None = None,
        outputs: dict[str, Any] | None = None,
        reference_outputs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> EvalResult:
        if inputs is None and run is not None:
            inputs = run.inputs if hasattr(run, "inputs") else {}
            if outputs is None:
                outputs = run.outputs if hasattr(run, "outputs") else {}
        if reference_outputs is None and example is not None:
            reference_outputs = example.outputs if hasattr(example, "outputs") else {}

        return await self.aevaluate(
            inputs=inputs or {},
            outputs=outputs or {},
            reference_outputs=reference_outputs,
            **kwargs,
        )
