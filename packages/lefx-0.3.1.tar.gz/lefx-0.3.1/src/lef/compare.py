"""Experiment comparison and baseline management.

Compare evaluation results across experiments to detect regressions,
save baselines for branch comparison workflows, and output diff reports.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from langsmith import Client

from lef.assertions import _extract_scores

logger = logging.getLogger(__name__)

# Default location for baseline storage
_BASELINE_DIR = Path(".lef") / "baselines"


# ---------------------------------------------------------------------------
# Baseline persistence
# ---------------------------------------------------------------------------


def save_baseline(
    name: str,
    results: Any,
    *,
    metadata: dict[str, Any] | None = None,
    baselines_dir: str | Path | None = None,
) -> Path:
    """Save evaluation results as a named baseline for future comparison.

    Args:
        name: Baseline name (e.g., "main", "v1.2", "pre-refactor").
        results: Evaluation results (any format supported by _extract_scores).
        metadata: Optional metadata to store alongside scores.
        baselines_dir: Directory to store baselines. Default: .lef/baselines/

    Returns:
        Path to the saved baseline file.
    """
    base_dir = Path(baselines_dir) if baselines_dir else _BASELINE_DIR
    base_dir.mkdir(parents=True, exist_ok=True)

    scores = _extract_scores(results)
    summary = {k: sum(v) / len(v) for k, v in scores.items()}

    baseline_data = {
        "name": name,
        "summary": summary,
        "per_key_scores": {k: v for k, v in scores.items()},
        "metadata": metadata or {},
    }

    filepath = base_dir / f"{name}.json"
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(baseline_data, f, indent=2, default=str)

    logger.info("Saved baseline '%s' to %s", name, filepath)
    return filepath


def load_baseline(
    name: str,
    *,
    baselines_dir: str | Path | None = None,
) -> dict[str, Any]:
    """Load a previously saved baseline.

    Args:
        name: Baseline name.
        baselines_dir: Directory containing baselines.

    Returns:
        Baseline data dict with 'name', 'summary', 'per_key_scores', 'metadata'.

    Raises:
        FileNotFoundError: If baseline does not exist.
    """
    base_dir = Path(baselines_dir) if baselines_dir else _BASELINE_DIR
    filepath = base_dir / f"{name}.json"

    if not filepath.exists():
        raise FileNotFoundError(f"Baseline '{name}' not found at {filepath}")

    with open(filepath, encoding="utf-8") as f:
        return json.load(f)


def list_baselines(
    *,
    baselines_dir: str | Path | None = None,
) -> list[dict[str, Any]]:
    """List all saved baselines.

    Returns:
        List of dicts with 'name', 'path', 'summary' for each baseline.
    """
    base_dir = Path(baselines_dir) if baselines_dir else _BASELINE_DIR
    if not base_dir.exists():
        return []

    baselines = []
    for f in sorted(base_dir.glob("*.json")):
        try:
            with open(f, encoding="utf-8") as fh:
                data = json.load(fh)
            baselines.append(
                {
                    "name": data.get("name", f.stem),
                    "path": str(f),
                    "summary": data.get("summary", {}),
                }
            )
        except (json.JSONDecodeError, KeyError):
            logger.warning("Skipping invalid baseline file: %s", f)

    return baselines


def delete_baseline(
    name: str,
    *,
    baselines_dir: str | Path | None = None,
) -> bool:
    """Delete a saved baseline. Returns True if deleted, False if not found."""
    base_dir = Path(baselines_dir) if baselines_dir else _BASELINE_DIR
    filepath = base_dir / f"{name}.json"
    if filepath.exists():
        filepath.unlink()
        logger.info("Deleted baseline '%s'", name)
        return True
    return False


# ---------------------------------------------------------------------------
# Comparison logic
# ---------------------------------------------------------------------------


def compare_results(
    current: Any,
    baseline: Any,
    *,
    tolerance: float = 0.0,
) -> ComparisonReport:
    """Compare current results against a baseline.

    Args:
        current: Current evaluation results.
        baseline: Baseline to compare against. Can be:
            - Raw results (any format supported by _extract_scores)
            - A baseline dict from load_baseline() (with 'summary' key)
        tolerance: Allowed regression amount before flagging (default 0.0).

    Returns:
        ComparisonReport with per-key diffs and overall pass/fail.
    """
    # Extract summaries
    if isinstance(baseline, dict) and "summary" in baseline:
        baseline_summary = baseline["summary"]
    else:
        baseline_scores = _extract_scores(baseline)
        baseline_summary = {k: sum(v) / len(v) for k, v in baseline_scores.items()}

    if isinstance(current, dict) and "summary" in current:
        current_summary = current["summary"]
    else:
        current_scores = _extract_scores(current)
        current_summary = {k: sum(v) / len(v) for k, v in current_scores.items()}

    all_keys = sorted(set(list(current_summary.keys()) + list(baseline_summary.keys())))

    diffs: list[dict[str, Any]] = []
    regressions: list[dict[str, Any]] = []
    improvements: list[dict[str, Any]] = []

    for key in all_keys:
        current_val = current_summary.get(key)
        baseline_val = baseline_summary.get(key)

        diff_entry: dict[str, Any] = {"key": key}

        if current_val is not None and baseline_val is not None:
            delta = current_val - baseline_val
            diff_entry.update(
                {
                    "current": current_val,
                    "baseline": baseline_val,
                    "delta": delta,
                    "status": (
                        "regression"
                        if delta < -tolerance
                        else ("improvement" if delta > tolerance else "stable")
                    ),
                }
            )
            if delta < -tolerance:
                regressions.append(diff_entry)
            elif delta > tolerance:
                improvements.append(diff_entry)
        elif current_val is not None:
            diff_entry.update(
                {
                    "current": current_val,
                    "baseline": None,
                    "delta": None,
                    "status": "new",
                }
            )
        else:
            diff_entry.update(
                {
                    "current": None,
                    "baseline": baseline_val,
                    "delta": None,
                    "status": "removed",
                }
            )

        diffs.append(diff_entry)

    return ComparisonReport(
        diffs=diffs,
        regressions=regressions,
        improvements=improvements,
        has_regressions=len(regressions) > 0,
    )


class ComparisonReport:
    """Result of comparing two experiment runs."""

    def __init__(
        self,
        *,
        diffs: list[dict[str, Any]],
        regressions: list[dict[str, Any]],
        improvements: list[dict[str, Any]],
        has_regressions: bool,
    ):
        self.diffs = diffs
        self.regressions = regressions
        self.improvements = improvements
        self.has_regressions = has_regressions

    def format_table(self) -> str:
        """Format comparison as a terminal-friendly table."""
        lines: list[str] = []
        lines.append("")
        lines.append("=" * 72)
        lines.append("  LEF Comparison Report")
        lines.append("=" * 72)
        lines.append("")

        header = f"  {'Metric':<28} {'Baseline':>10} {'Current':>10} {'Delta':>10} {'Status':>10}"
        lines.append(header)
        lines.append("  " + "-" * 70)

        for d in self.diffs:
            base_str = f"{d['baseline']:.4f}" if d["baseline"] is not None else "   N/A"
            curr_str = f"{d['current']:.4f}" if d["current"] is not None else "   N/A"
            delta_str = f"{d['delta']:+.4f}" if d["delta"] is not None else "   N/A"
            status = d["status"].upper()
            lines.append(
                f"  {d['key']:<28} {base_str:>10} {curr_str:>10} {delta_str:>10} {status:>10}"
            )

        lines.append("")
        if self.regressions:
            lines.append(f"  REGRESSIONS: {len(self.regressions)}")
            for r in self.regressions:
                lines.append(
                    f"    - {r['key']}: {r['delta']:+.4f}"
                    f" ({r['baseline']:.4f} -> {r['current']:.4f})"
                )
        if self.improvements:
            lines.append(f"  IMPROVEMENTS: {len(self.improvements)}")
            for i in self.improvements:
                lines.append(
                    f"    + {i['key']}: {i['delta']:+.4f}"
                    f" ({i['baseline']:.4f} -> {i['current']:.4f})"
                )

        lines.append("")
        result = (
            "PASS (no regressions)" if not self.has_regressions else "FAIL (regressions detected)"
        )
        lines.append(f"  Result: {result}")
        lines.append("=" * 72)
        lines.append("")
        return "\n".join(lines)

    def format_markdown(self) -> str:
        """Format comparison as Markdown (for PR comments)."""
        lines: list[str] = []
        lines.append("## LEF Evaluation Comparison")
        lines.append("")

        # Summary
        if self.has_regressions:
            lines.append(
                f"**Result: REGRESSIONS DETECTED** ({len(self.regressions)} metric(s) regressed)"
            )
        else:
            lines.append("**Result: All metrics stable or improved**")
        lines.append("")

        # Table
        lines.append("| Metric | Baseline | Current | Delta | Status |")
        lines.append("|--------|----------|---------|-------|--------|")

        for d in self.diffs:
            base_str = f"{d['baseline']:.4f}" if d["baseline"] is not None else "N/A"
            curr_str = f"{d['current']:.4f}" if d["current"] is not None else "N/A"
            delta_str = f"{d['delta']:+.4f}" if d["delta"] is not None else "N/A"
            status_emoji = {
                "regression": "regression",
                "improvement": "improvement",
                "stable": "stable",
                "new": "new",
                "removed": "removed",
            }.get(d["status"], d["status"])
            lines.append(f"| {d['key']} | {base_str} | {curr_str} | {delta_str} | {status_emoji} |")

        lines.append("")
        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """Convert to a serializable dict."""
        return {
            "diffs": self.diffs,
            "regressions": self.regressions,
            "improvements": self.improvements,
            "has_regressions": self.has_regressions,
        }


# ---------------------------------------------------------------------------
# LangSmith experiment comparison
# ---------------------------------------------------------------------------


def compare_experiments(
    current_name: str,
    baseline_name: str,
    *,
    client: Client | None = None,
    tolerance: float = 0.0,
) -> ComparisonReport:
    """Compare two LangSmith experiments by name.

    Fetches results from LangSmith and computes a diff.

    Args:
        current_name: Name/prefix of the current experiment.
        baseline_name: Name/prefix of the baseline experiment.
        client: Optional LangSmith client.
        tolerance: Allowed regression amount.

    Returns:
        ComparisonReport.
    """
    ls_client = client or Client()

    current_results = list(ls_client.get_test_results(project_name=current_name))
    baseline_results = list(ls_client.get_test_results(project_name=baseline_name))

    return compare_results(current_results, baseline_results, tolerance=tolerance)
