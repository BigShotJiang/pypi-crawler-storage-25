"""LLM-as-Judge evaluators built on top of openevals.

Provides pre-configured judges and a simple factory for creating custom ones.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, cast

from openevals.llm import create_llm_as_judge
from openevals.prompts import (
    ANSWER_RELEVANCE_PROMPT,
    CODE_CORRECTNESS_PROMPT,
    CONCISENESS_PROMPT,
    CORRECTNESS_PROMPT,
    HALLUCINATION_PROMPT,
    PLAN_ADHERENCE_PROMPT,
    RAG_GROUNDEDNESS_PROMPT,
    RAG_HELPFULNESS_PROMPT,
    RAG_RETRIEVAL_RELEVANCE_PROMPT,
    TOXICITY_PROMPT,
)

from lef.core.types import JudgeModel
from lef.judges.prompts import (
    FAITHFULNESS_PROMPT,
    RESPONSE_QUALITY_PROMPT,
    SAFETY_PROMPT,
    TOOL_SELECTION_PROMPT,
)


def create_judge(
    prompt: str,
    *,
    model: str | JudgeModel = JudgeModel.GPT_4O,
    feedback_key: str = "score",
    system: str | None = None,
    few_shot_examples: list[dict[str, Any]] | None = None,
) -> Callable[..., Any]:
    """Create an LLM-as-Judge evaluator using openevals.

    This is a thin wrapper around ``openevals.llm.create_llm_as_judge`` that
    provides a cleaner interface and integrates with LEF's type system.

    Args:
        prompt: The evaluation prompt template. Use {inputs}, {outputs},
            and {reference_outputs} as placeholders.
        model: The judge model to use (openevals provider:model format).
        feedback_key: The key name for the evaluation result.
        system: Optional system message for the judge.
        few_shot_examples: Optional few-shot examples for in-context learning.

    Returns:
        A callable evaluator compatible with langsmith.evaluate().
    """
    return create_llm_as_judge(
        prompt=prompt,
        model=str(model),
        feedback_key=feedback_key,
        system=system,
        few_shot_examples=cast(Any, few_shot_examples),
    )


# ---------------------------------------------------------------------------
# Pre-built judges: core quality
# ---------------------------------------------------------------------------


def correctness_judge(*, model: str | JudgeModel = JudgeModel.GPT_4O) -> Callable[..., Any]:
    """Evaluate whether outputs match expected reference outputs."""
    return create_llm_as_judge(
        prompt=CORRECTNESS_PROMPT, model=str(model), feedback_key="correctness"
    )


def conciseness_judge(*, model: str | JudgeModel = JudgeModel.GPT_4O) -> Callable[..., Any]:
    """Evaluate response conciseness."""
    return create_llm_as_judge(
        prompt=CONCISENESS_PROMPT, model=str(model), feedback_key="conciseness"
    )


def hallucination_judge(*, model: str | JudgeModel = JudgeModel.GPT_4O) -> Callable[..., Any]:
    """Detect hallucinated content not supported by inputs/context."""
    return create_llm_as_judge(
        prompt=HALLUCINATION_PROMPT, model=str(model), feedback_key="hallucination"
    )


def answer_relevance_judge(*, model: str | JudgeModel = JudgeModel.GPT_4O) -> Callable[..., Any]:
    """Evaluate whether the answer is relevant to the question."""
    return create_llm_as_judge(
        prompt=ANSWER_RELEVANCE_PROMPT, model=str(model), feedback_key="answer_relevance"
    )


def toxicity_judge(*, model: str | JudgeModel = JudgeModel.GPT_4O) -> Callable[..., Any]:
    """Detect toxic, offensive, or harmful content."""
    return create_llm_as_judge(prompt=TOXICITY_PROMPT, model=str(model), feedback_key="toxicity")


# ---------------------------------------------------------------------------
# Pre-built judges: RAG
# ---------------------------------------------------------------------------


def rag_groundedness_judge(*, model: str | JudgeModel = JudgeModel.GPT_4O) -> Callable[..., Any]:
    """Evaluate whether the response is grounded in retrieved context."""
    return create_llm_as_judge(
        prompt=RAG_GROUNDEDNESS_PROMPT, model=str(model), feedback_key="rag_groundedness"
    )


def rag_helpfulness_judge(*, model: str | JudgeModel = JudgeModel.GPT_4O) -> Callable[..., Any]:
    """Evaluate whether the RAG response is helpful to the user."""
    return create_llm_as_judge(
        prompt=RAG_HELPFULNESS_PROMPT, model=str(model), feedback_key="rag_helpfulness"
    )


def rag_retrieval_relevance_judge(
    *,
    model: str | JudgeModel = JudgeModel.GPT_4O,
) -> Callable[..., Any]:
    """Evaluate whether retrieved documents are relevant to the query."""
    return create_llm_as_judge(
        prompt=RAG_RETRIEVAL_RELEVANCE_PROMPT,
        model=str(model),
        feedback_key="rag_retrieval_relevance",
    )


# ---------------------------------------------------------------------------
# Pre-built judges: code
# ---------------------------------------------------------------------------


def code_correctness_judge(*, model: str | JudgeModel = JudgeModel.GPT_4O) -> Callable[..., Any]:
    """Evaluate correctness of generated code."""
    return create_llm_as_judge(
        prompt=CODE_CORRECTNESS_PROMPT, model=str(model), feedback_key="code_correctness"
    )


def plan_adherence_judge(*, model: str | JudgeModel = JudgeModel.GPT_4O) -> Callable[..., Any]:
    """Evaluate whether the output adheres to a specified plan."""
    return create_llm_as_judge(
        prompt=PLAN_ADHERENCE_PROMPT, model=str(model), feedback_key="plan_adherence"
    )


# ---------------------------------------------------------------------------
# Pre-built judges: custom LEF prompts
# ---------------------------------------------------------------------------


def faithfulness_judge(*, model: str | JudgeModel = JudgeModel.GPT_4O) -> Callable[..., Any]:
    """Evaluate faithfulness to source context."""
    return create_judge(prompt=FAITHFULNESS_PROMPT, model=model, feedback_key="faithfulness")


def response_quality_judge(*, model: str | JudgeModel = JudgeModel.GPT_4O) -> Callable[..., Any]:
    """Evaluate overall response quality (correctness, completeness, clarity, relevance)."""
    return create_judge(
        prompt=RESPONSE_QUALITY_PROMPT, model=model, feedback_key="response_quality"
    )


def tool_selection_judge(*, model: str | JudgeModel = JudgeModel.GPT_4O) -> Callable[..., Any]:
    """Evaluate agent tool selection accuracy."""
    return create_judge(prompt=TOOL_SELECTION_PROMPT, model=model, feedback_key="tool_selection")


def safety_judge(*, model: str | JudgeModel = JudgeModel.GPT_4O) -> Callable[..., Any]:
    """Evaluate response safety (harmful content, bias, sensitive topics, info leaks)."""
    return create_judge(prompt=SAFETY_PROMPT, model=model, feedback_key="safety")
