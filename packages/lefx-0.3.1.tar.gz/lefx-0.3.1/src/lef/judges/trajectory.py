"""Agent trajectory evaluators built on top of agentevals.

Provides trajectory matching and LLM-based trajectory evaluation
for LangGraph agents and multi-step workflows.

Requires the ``agentevals`` package: ``pip install lef[agents]``
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from lef.core.types import JudgeModel


def create_trajectory_evaluator(
    *,
    match_mode: str = "superset",
) -> Callable[..., Any]:
    """Create a trajectory match evaluator for agent tool call sequences.

    Compares the agent's actual tool call sequence against a reference
    trajectory using one of several matching strategies.

    Args:
        match_mode: How to compare trajectories. One of:
            - ``"strict"``: identical messages in identical order
            - ``"unordered"``: same messages, any order
            - ``"subset"``: output is a subset of reference
            - ``"superset"``: output is a superset of reference (recommended)

    Returns:
        A callable evaluator compatible with langsmith.evaluate().

    Example::

        traj_eval = create_trajectory_evaluator(match_mode="superset")
        results = run_eval(
            target=my_agent,
            data="agent-dataset",
            evaluators=[traj_eval],
        )
    """
    try:
        from agentevals.trajectory.match import create_trajectory_match_evaluator
    except ImportError as exc:
        raise ImportError(
            "agentevals is required for trajectory evaluation. "
            "Install with: pip install lef[agents]"
        ) from exc

    return create_trajectory_match_evaluator(trajectory_match_mode=match_mode)


def create_trajectory_judge(
    *,
    model: str | JudgeModel = JudgeModel.GPT_4O,
    agent_description: str | None = None,
) -> Callable[..., Any]:
    """Create an LLM-as-judge trajectory evaluator.

    Uses an LLM to evaluate agent trajectories without requiring
    a reference trajectory. The judge assesses whether the agent
    took reasonable steps to accomplish the task.

    Args:
        model: The judge model to use.
        agent_description: Optional description of the agent's purpose,
            helps the judge understand expected behavior.

    Returns:
        A callable evaluator compatible with langsmith.evaluate().
    """
    try:
        from agentevals.trajectory.llm import create_trajectory_llm_as_judge
    except ImportError as exc:
        raise ImportError(
            "agentevals is required for trajectory evaluation. "
            "Install with: pip install lef[agents]"
        ) from exc

    kwargs: dict[str, Any] = {"model": str(model)}
    if agent_description:
        kwargs["agent_description"] = agent_description

    return create_trajectory_llm_as_judge(**kwargs)
