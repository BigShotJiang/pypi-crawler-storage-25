"""CLI entry point for the LEF evaluation framework.

Commands::

    lef run eval_suite.yaml                 # Run evaluation from config
    lef run eval_suite.yaml --watch         # Watch mode with auto-rerun
    lef run eval_suite.yaml --output r.json # Export results
    lef run config1.yaml config2.yaml       # Multi-config composition

    lef compare --baseline main --current feature-branch
    lef baseline save main                  # Save current results as baseline
    lef baseline list                       # List saved baselines
    lef baseline delete old-baseline        # Delete a baseline

    lef qa https://my-endpoint/invoke       # QA a deployed endpoint
    lef monitor --project my-chatbot        # Continuous production monitoring
    lef redteam config.yaml                 # Red-team adversarial testing

    lef dataset pull my-dataset -o data.yaml
    lef dataset push data.yaml --name my-dataset
    lef dataset diff v1.yaml v2.yaml
    lef dataset generate --from-docs docs/  # Synthetic generation
"""

from __future__ import annotations

import argparse
import importlib
import json
import logging
import sys
from pathlib import Path
from typing import Any


def _get_version() -> str:
    """Get the package version."""
    from lef import __version__

    return __version__


logger = logging.getLogger(__name__)

# Map of built-in evaluator names to their import paths
_BUILTIN_EVALUATORS = {
    # Scorers
    "exact_match": "lef.scorers.builtin:exact_match",
    "contains": "lef.scorers.builtin:contains",
    "regex_match": "lef.scorers.builtin:regex_match",
    "json_match": "lef.scorers.builtin:json_match",
    # Judges (factories - need to be called)
    "correctness_judge": "lef.judges.llm:correctness_judge",
    "conciseness_judge": "lef.judges.llm:conciseness_judge",
    "hallucination_judge": "lef.judges.llm:hallucination_judge",
    "answer_relevance_judge": "lef.judges.llm:answer_relevance_judge",
    "toxicity_judge": "lef.judges.llm:toxicity_judge",
    "rag_groundedness_judge": "lef.judges.llm:rag_groundedness_judge",
    "rag_helpfulness_judge": "lef.judges.llm:rag_helpfulness_judge",
    "rag_retrieval_relevance_judge": "lef.judges.llm:rag_retrieval_relevance_judge",
    "code_correctness_judge": "lef.judges.llm:code_correctness_judge",
    "plan_adherence_judge": "lef.judges.llm:plan_adherence_judge",
    "faithfulness_judge": "lef.judges.llm:faithfulness_judge",
    "response_quality_judge": "lef.judges.llm:response_quality_judge",
    "tool_selection_judge": "lef.judges.llm:tool_selection_judge",
    "safety_judge": "lef.judges.llm:safety_judge",
    # Summary evaluators (factories - need to be called)
    "pass_rate": "lef.scorers.builtin:pass_rate",
}

# Judge factories that need to be called to get an evaluator instance
_JUDGE_FACTORIES = {
    "correctness_judge",
    "conciseness_judge",
    "hallucination_judge",
    "answer_relevance_judge",
    "toxicity_judge",
    "rag_groundedness_judge",
    "rag_helpfulness_judge",
    "rag_retrieval_relevance_judge",
    "code_correctness_judge",
    "plan_adherence_judge",
    "faithfulness_judge",
    "response_quality_judge",
    "tool_selection_judge",
    "safety_judge",
    "pass_rate",
}


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _import_object(name: str) -> Any:
    """Import a Python object by dotted path or file path.

    Supports three formats:
    - ``"mymodule.evals:my_evaluator"`` (colon separator)
    - ``"mymodule.evals.my_evaluator"`` (dot separator)
    - ``"/path/to/file.py:my_evaluator"`` (file path with colon)
    """
    if ":" in name:
        module_path, attr = name.rsplit(":", 1)
        # Check if module_path is a file path
        if Path(module_path).is_file():
            module = _import_from_file(module_path)
        else:
            module = importlib.import_module(module_path)
        return getattr(module, attr)
    if "." in name:
        module_path, attr = name.rsplit(".", 1)
        module = importlib.import_module(module_path)
        return getattr(module, attr)
    raise ValueError(
        f"Cannot import '{name}'. Use a dotted import path "
        "(e.g., 'mymodule.evals:my_evaluator' or "
        "'/path/to/file.py:my_evaluator')."
    )


def _import_from_file(filepath: str) -> Any:
    """Import a module from a file path using importlib."""
    import importlib.util

    path = Path(filepath).resolve()
    module_name = path.stem
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load module from {filepath}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def _resolve_evaluator(name: str) -> Any:
    """Resolve an evaluator by name or import path."""
    if name in _BUILTIN_EVALUATORS:
        module_path, attr = _BUILTIN_EVALUATORS[name].rsplit(":", 1)
        module = importlib.import_module(module_path)
        evaluator = getattr(module, attr)
        # Judge factories need to be called to create an instance
        if name in _JUDGE_FACTORIES:
            return evaluator()
        return evaluator

    return _import_object(name)


def _resolve_target(target_ref: str) -> Any:
    """Resolve a target by import path, HTTP URL, or calling as factory."""
    # HTTP URL → create remote target
    if target_ref.startswith(("http://", "https://")):
        from lef.integrations.remote import create_remote_target

        logger.info("Creating remote target for %s", target_ref)
        return create_remote_target(target_ref)

    is_factory = target_ref.endswith("()")
    import_path = target_ref.rstrip("()")
    obj = _import_object(import_path)
    if is_factory:
        logger.info("Calling target factory: %s", import_path)
        return obj()
    return obj


def _load_config(path: str) -> dict[str, Any]:
    """Load an eval suite config from YAML or JSON."""
    filepath = Path(path)
    if filepath.suffix in (".yaml", ".yml"):
        try:
            import yaml
        except ImportError as exc:
            raise ImportError(
                "PyYAML is required for YAML config files. Install with: pip install pyyaml"
            ) from exc
        with open(filepath, encoding="utf-8") as f:
            data = yaml.safe_load(f)
            if not isinstance(data, dict):
                raise ValueError(
                    f"Config file must contain a YAML mapping, "
                    f"got {type(data).__name__}: {filepath}"
                )
            return data
    elif filepath.suffix == ".json":
        with open(filepath, encoding="utf-8") as f:
            return json.load(f)
    else:
        raise ValueError(f"Config file must be .yaml, .yml, or .json: {filepath}")


def _merge_configs(configs: list[dict[str, Any]]) -> dict[str, Any]:
    """Merge multiple config dicts (F15: multi-config composition).

    Later configs override earlier ones. Lists (evaluators, summary_evaluators)
    are concatenated. Dicts (thresholds, metadata) are merged.
    """
    merged: dict[str, Any] = {}
    list_keys = {"evaluators", "summary_evaluators"}
    dict_keys = {"thresholds", "metadata"}

    for config in configs:
        for k, v in config.items():
            if k in list_keys and k in merged and isinstance(merged[k], list):
                merged[k] = merged[k] + (v if isinstance(v, list) else [v])
            elif k in dict_keys and k in merged and isinstance(merged[k], dict):
                merged[k] = {**merged[k], **v}
            else:
                merged[k] = v

    return merged


_VALID_CONFIG_KEYS = {
    "target",
    "dataset",
    "evaluators",
    "summary_evaluators",
    "experiment_prefix",
    "description",
    "thresholds",
    "max_concurrency",
    "num_repetitions",
    "upload_results",
    "input_keys",
    "output_keys",
    "metadata",
}


def _validate_config(config: dict[str, Any], filepath: str) -> list[str]:
    """Validate a config dict and return a list of warning messages."""
    warnings = []
    unknown = set(config.keys()) - _VALID_CONFIG_KEYS
    if unknown:
        warnings.append(
            f"Unknown config keys in {filepath}: {', '.join(sorted(unknown))}. "
            f"Valid keys: {', '.join(sorted(_VALID_CONFIG_KEYS))}"
        )
    if not config.get("evaluators"):
        warnings.append("No 'evaluators' key found in config. Did you mean 'evaluators' (plural)?")
    if not config.get("target"):
        warnings.append("No 'target' key found in config.")
    if not config.get("dataset"):
        warnings.append("No 'dataset' key found in config.")
    return warnings


def _parse_thresholds(threshold_args: list[str] | None) -> dict[str, float] | None:
    """Parse --threshold key=value arguments into a dict.

    Returns None if no thresholds given, the parsed dict on success,
    or raises SystemExit-free ValueError on bad input so callers can
    return an exit code.
    """
    if not threshold_args:
        return None
    thresholds: dict[str, float] = {}
    for t in threshold_args:
        if "=" not in t:
            print(
                f"Error: Invalid threshold format '{t}'. Expected 'key=value'.",
                file=sys.stderr,
            )
            raise ValueError(t)
        key, val = t.split("=", 1)
        try:
            thresholds[key] = float(val)
        except ValueError:
            print(
                f"Error: Invalid threshold value '{val}' for '{key}'.",
                file=sys.stderr,
            )
            raise
    return thresholds


# ---------------------------------------------------------------------------
# 'run' command
# ---------------------------------------------------------------------------


def run_command(args: argparse.Namespace) -> int:
    """Execute the 'run' subcommand."""
    from lef.assertions import EvalAssertionError, assert_scores
    from lef.datasets.loader import load_examples
    from lef.datasets.runner import run_eval
    from lef.git_context import build_experiment_metadata
    from lef.output import export_results, format_results_table

    # Load and merge configs (F15: multi-config composition)
    try:
        configs = [_load_config(p) for p in args.config]
    except (ValueError, Exception) as exc:
        print(f"Error loading config: {exc}", file=sys.stderr)
        return 1
    config = _merge_configs(configs) if len(configs) > 1 else configs[0]

    # Validate config
    for warning in _validate_config(config, args.config[0]):
        logger.warning(warning)

    # CLI overrides
    if args.prefix:
        config["experiment_prefix"] = args.prefix
    if args.no_upload:
        config["upload_results"] = False

    # Merge thresholds
    thresholds = config.get("thresholds", {})
    try:
        cli_thresholds = _parse_thresholds(args.threshold)
    except ValueError:
        return 1
    if cli_thresholds:
        thresholds.update(cli_thresholds)

    # Resolve dataset
    dataset_ref = config.get("dataset") or ""
    data: str | list[dict[str, Any]]
    if dataset_ref and Path(dataset_ref).exists():
        data = load_examples(
            dataset_ref,
            input_keys=config.get("input_keys"),
            output_keys=config.get("output_keys"),
        )
        logger.info("Loaded %d examples from %s", len(data), dataset_ref)
    else:
        data = dataset_ref

    # Resolve evaluators
    evaluator_names = config.get("evaluators") or []
    evaluators = [_resolve_evaluator(name) for name in evaluator_names]
    if not evaluators:
        print("Error: No evaluators specified in config.", file=sys.stderr)
        return 1

    # Resolve summary evaluators
    summary_evaluator_names = config.get("summary_evaluators") or []
    summary_evaluators = [_resolve_evaluator(name) for name in summary_evaluator_names] or None

    # Resolve target
    target_ref = config.get("target")
    if not target_ref:
        print("Error: No 'target' specified in config.", file=sys.stderr)
        return 1
    target = _resolve_target(target_ref)

    # F4: Result caching
    if getattr(args, "cache", False):
        from lef.cache import ResultCache

        cache = ResultCache()
        target = cache.wrap(target)
        logger.info("Result caching enabled")

    # Coerce types
    max_concurrency = config.get("max_concurrency")
    if max_concurrency is not None:
        try:
            max_concurrency = int(max_concurrency)
        except (ValueError, TypeError):
            print(
                f"Error: 'max_concurrency' must be an integer, got '{max_concurrency}'.",
                file=sys.stderr,
            )
            return 1
    num_repetitions = int(config.get("num_repetitions", 1))

    # F2: Git-aware metadata
    metadata = build_experiment_metadata(extra=config.get("metadata"))

    def _do_run() -> int:
        """Execute one evaluation run."""
        print(f"Running evaluation with {len(evaluators)} evaluator(s)...")
        try:
            results = run_eval(
                target,
                data=data,
                evaluators=evaluators,
                summary_evaluators=summary_evaluators,
                experiment_prefix=config.get("experiment_prefix"),
                description=config.get("description"),
                max_concurrency=max_concurrency,
                num_repetitions=num_repetitions,
                metadata=metadata,
                upload_results=config.get("upload_results", True),
            )
        except Exception as exc:
            print(f"Error: Evaluation failed: {exc}", file=sys.stderr)
            logger.debug("Evaluation error details", exc_info=True)
            return 2

        # F6: Rich terminal output
        print(format_results_table(results, thresholds=thresholds or None))

        # F1: Export results
        output_path = getattr(args, "output", None)
        if output_path:
            export_results(results, output_path, thresholds=thresholds, metadata=metadata)
            print(f"Results exported to {output_path}")

        # F8: PR comment
        if getattr(args, "github_comment", False) or getattr(args, "azdo_comment", False):
            _post_ci_comment(results, thresholds, args)

        # F3/F10: Save baseline
        baseline_name = getattr(args, "save_baseline", None)
        if baseline_name:
            from lef.compare import save_baseline

            save_baseline(baseline_name, results, metadata=metadata)
            print(f"Saved baseline '{baseline_name}'")

        # F3: Compare against baseline
        baseline_ref = getattr(args, "baseline", None)
        if baseline_ref:
            from lef.compare import compare_results, load_baseline

            baseline_data = load_baseline(baseline_ref)
            report = compare_results(results, baseline_data)
            print(report.format_table())
            if report.has_regressions:
                return 1

        # Check thresholds
        if thresholds:
            try:
                assert_scores(results, thresholds)
                print("All thresholds passed!")
            except EvalAssertionError as e:
                print(f"\nFAILED: {e}", file=sys.stderr)
                return 1

        return 0

    # F5: Watch mode
    if getattr(args, "watch", False):
        from lef.watch import watch_and_run

        watch_paths = [args.config[0]]
        if dataset_ref and Path(dataset_ref).exists():
            watch_paths.append(dataset_ref)
        watch_and_run(_do_run, watch_paths=watch_paths)
        return 0

    return _do_run()


def _post_ci_comment(results: Any, thresholds: dict[str, float], args: argparse.Namespace) -> None:
    """Post results as a CI PR comment."""
    from lef.output import format_results_table

    body = format_results_table(results, thresholds=thresholds or None)

    if getattr(args, "github_comment", False):
        try:
            from lef.ci.github import post_github_comment

            post_github_comment(body)
            print("Posted results to GitHub PR.")
        except Exception as exc:
            logger.warning("Failed to post GitHub comment: %s", exc)

    if getattr(args, "azdo_comment", False):
        try:
            from lef.ci.azuredevops import post_azdo_comment

            post_azdo_comment(body)
            print("Posted results to Azure DevOps PR.")
        except Exception as exc:
            logger.warning("Failed to post Azure DevOps comment: %s", exc)


# ---------------------------------------------------------------------------
# 'compare' command
# ---------------------------------------------------------------------------


def compare_command(args: argparse.Namespace) -> int:
    """Execute the 'compare' subcommand."""
    from lef.compare import compare_results, load_baseline

    try:
        baseline = load_baseline(args.baseline)
    except FileNotFoundError:
        print(f"Error: Baseline '{args.baseline}' not found.", file=sys.stderr)
        return 1

    try:
        current = load_baseline(args.current)
    except FileNotFoundError:
        print(f"Error: Baseline '{args.current}' not found.", file=sys.stderr)
        return 1

    tolerance = getattr(args, "tolerance", 0.0)
    report = compare_results(current, baseline, tolerance=tolerance)
    print(report.format_table())

    if getattr(args, "output", None):
        import json

        with open(args.output, "w") as f:
            json.dump(report.to_dict(), f, indent=2, default=str)
        print(f"Comparison exported to {args.output}")

    return 1 if report.has_regressions else 0


# ---------------------------------------------------------------------------
# 'baseline' command
# ---------------------------------------------------------------------------


def baseline_command(args: argparse.Namespace) -> int:
    """Execute the 'baseline' subcommand."""
    from lef.compare import delete_baseline, list_baselines

    action = args.baseline_action

    if action == "list":
        baselines = list_baselines()
        if not baselines:
            print("No baselines saved. Use 'lef run config.yaml --save-baseline NAME' to save one.")
            return 0
        print(f"\n{'Name':<20} {'Metrics':<40}")
        print("-" * 60)
        for b in baselines:
            metrics = ", ".join(f"{k}={v:.4f}" for k, v in b["summary"].items())
            print(f"{b['name']:<20} {metrics:<40}")
        print()
        return 0

    elif action == "delete":
        if not args.name:
            print("Error: baseline name required.", file=sys.stderr)
            return 1
        if delete_baseline(args.name):
            print(f"Deleted baseline '{args.name}'.")
        else:
            print(f"Baseline '{args.name}' not found.")
        return 0

    print("Unknown baseline action. Use 'list' or 'delete'.")
    return 1


# ---------------------------------------------------------------------------
# 'qa' command
# ---------------------------------------------------------------------------


def qa_command(args: argparse.Namespace) -> int:
    """Execute the 'qa' subcommand."""
    from lef.assertions import EvalAssertionError, assert_scores
    from lef.datasets.loader import load_examples
    from lef.datasets.runner import run_eval
    from lef.integrations.remote import create_remote_target
    from lef.output import format_results_table

    # Create remote target
    headers = {}
    for h in args.header or []:
        if ":" not in h:
            print(f"Error: Invalid header format '{h}'. Expected 'Key: Value'.", file=sys.stderr)
            return 1
        key, val = h.split(":", 1)
        headers[key.strip()] = val.strip()

    target = create_remote_target(
        args.url,
        headers=headers or None,
        timeout=args.timeout,
    )

    # Load dataset
    if not args.data:
        print("Error: --data is required for QA command.", file=sys.stderr)
        return 1

    if Path(args.data).exists():
        data: str | list[dict[str, Any]] = load_examples(args.data)
    else:
        data = args.data

    # Resolve evaluators
    evaluator_names = args.evaluators or ["correctness_judge", "safety_judge"]
    evaluators = [_resolve_evaluator(name) for name in evaluator_names]

    print(f"QA testing {args.url} with {len(evaluators)} evaluator(s)...")
    try:
        results = run_eval(
            target,
            data=data,
            evaluators=evaluators,
            experiment_prefix=args.prefix or "qa",
            upload_results=not args.no_upload,
        )
    except Exception as exc:
        print(f"Error: QA evaluation failed: {exc}", file=sys.stderr)
        return 2

    # Parse thresholds
    try:
        thresholds = _parse_thresholds(args.threshold) or {}
    except ValueError:
        return 1
    print(format_results_table(results, thresholds=thresholds or None))

    if getattr(args, "output", None):
        from lef.output import export_results

        export_results(results, args.output, thresholds=thresholds)

    if thresholds:
        try:
            assert_scores(results, thresholds)
            print("All QA thresholds passed!")
        except EvalAssertionError as e:
            print(f"\nFAILED: {e}", file=sys.stderr)
            return 1

    return 0


# ---------------------------------------------------------------------------
# 'monitor' command
# ---------------------------------------------------------------------------


def monitor_command(args: argparse.Namespace) -> int:
    """Execute the 'monitor' subcommand."""
    from lef.monitor import MonitorDaemon

    evaluator_names = args.evaluators or ["safety_judge", "correctness_judge"]
    evaluators = [_resolve_evaluator(name) for name in evaluator_names]

    try:
        thresholds = _parse_thresholds(args.threshold) or {}
    except ValueError:
        return 1

    daemon = MonitorDaemon(
        project_name=args.project,
        evaluators=evaluators,
        thresholds=thresholds,
        poll_interval=args.interval,
        batch_size=args.batch_size,
        run_type=args.run_type,
    )

    daemon.run()
    return 0


# ---------------------------------------------------------------------------
# 'redteam' command
# ---------------------------------------------------------------------------


def redteam_command(args: argparse.Namespace) -> int:
    """Execute the 'redteam' subcommand."""
    from lef.redteam import run_redteam

    # Resolve target
    if args.config:
        config = _load_config(args.config)
        target_ref = config.get("target")
        if not target_ref:
            print("Error: No 'target' in config.", file=sys.stderr)
            return 1
        target = _resolve_target(target_ref)
    elif args.target:
        target = _resolve_target(args.target)
    else:
        print("Error: Provide either a config file or --target.", file=sys.stderr)
        return 1

    categories = args.categories.split(",") if args.categories else None

    print("Running red-team evaluation...")
    try:
        report = run_redteam(
            target,
            categories=categories,
            count_per_category=args.count,
            generate_additional=not args.seed_only,
            upload_results=not args.no_upload,
        )
    except Exception as exc:
        print(f"Error: Red-team failed: {exc}", file=sys.stderr)
        return 2

    # Display results
    print(f"\nRed-team complete: {report['total_examples']} examples tested")
    print("\nScores:")
    for key, score in report.get("overall", {}).items():
        print(f"  {key}: {score:.4f}")

    if report.get("alerts"):
        print("\nALERTS:")
        for alert in report["alerts"]:
            print(f"  - {alert}")
        return 1

    print("\nAll red-team checks passed!")
    return 0


# ---------------------------------------------------------------------------
# 'dataset' command
# ---------------------------------------------------------------------------


def dataset_command(args: argparse.Namespace) -> int:
    """Execute the 'dataset' subcommand."""
    action = args.dataset_action

    if action == "pull":
        return _dataset_pull(args)
    elif action == "push":
        return _dataset_push(args)
    elif action == "diff":
        return _dataset_diff(args)
    elif action == "generate":
        return _dataset_generate(args)

    print(f"Unknown dataset action: {action}", file=sys.stderr)
    return 1


def _dataset_pull(args: argparse.Namespace) -> int:
    """Pull a LangSmith dataset to a local file."""
    import yaml
    from langsmith import Client

    client = Client()
    examples = list(client.list_examples(dataset_name=args.name))

    data = []
    for ex in examples:
        entry: dict[str, Any] = {"inputs": ex.inputs}
        if ex.outputs:
            entry["outputs"] = ex.outputs
        data.append(entry)

    output_path = args.output or f"{args.name}.yaml"
    with open(output_path, "w", encoding="utf-8") as f:
        yaml.dump(data, f, default_flow_style=False, allow_unicode=True)

    print(f"Pulled {len(data)} examples from '{args.name}' to {output_path}")
    return 0


def _dataset_push(args: argparse.Namespace) -> int:
    """Push a local dataset to LangSmith."""
    from lef.datasets.loader import load_examples
    from lef.datasets.runner import create_dataset

    examples = load_examples(args.file)
    name = args.name or Path(args.file).stem

    dataset_id = create_dataset(name, examples=examples, description=args.description)
    print(f"Pushed {len(examples)} examples to '{name}' (ID: {dataset_id})")
    return 0


def _dataset_diff(args: argparse.Namespace) -> int:
    """Diff two local dataset files."""
    from lef.datasets.loader import load_examples

    data_a = load_examples(args.file_a)
    data_b = load_examples(args.file_b)

    # Simple structural diff
    print(f"\nDataset A: {args.file_a} ({len(data_a)} examples)")
    print(f"Dataset B: {args.file_b} ({len(data_b)} examples)")
    print()

    if len(data_a) != len(data_b):
        print(f"  Size difference: {len(data_a)} vs {len(data_b)}")

    # Compare overlapping examples by input
    inputs_a = {json.dumps(ex.get("inputs", {}), sort_keys=True) for ex in data_a}
    inputs_b = {json.dumps(ex.get("inputs", {}), sort_keys=True) for ex in data_b}

    only_a = inputs_a - inputs_b
    only_b = inputs_b - inputs_a
    common = inputs_a & inputs_b

    print(f"  Common inputs: {len(common)}")
    print(f"  Only in A: {len(only_a)}")
    print(f"  Only in B: {len(only_b)}")

    if only_a:
        print("\n  Examples only in A (showing first 3):")
        for inp in list(only_a)[:3]:
            print(f"    {inp[:100]}...")

    if only_b:
        print("\n  Examples only in B (showing first 3):")
        for inp in list(only_b)[:3]:
            print(f"    {inp[:100]}...")

    print()
    return 0


def _dataset_generate(args: argparse.Namespace) -> int:
    """Generate synthetic dataset from documents."""
    import yaml

    from lef.synthetic import generate_from_docs

    # Load documents
    docs_path = Path(args.source)
    documents: list[str] = []

    if docs_path.is_file():
        with open(docs_path, encoding="utf-8") as f:
            documents.append(f.read())
    elif docs_path.is_dir():
        for fp in sorted(docs_path.glob("**/*")):
            if fp.suffix in (".txt", ".md", ".rst", ".html"):
                try:
                    with open(fp, encoding="utf-8") as f:
                        documents.append(f.read())
                except UnicodeDecodeError:
                    continue
    else:
        print(f"Error: Source path not found: {docs_path}", file=sys.stderr)
        return 1

    if not documents:
        print("Error: No documents found.", file=sys.stderr)
        return 1

    print(f"Generating from {len(documents)} document(s)...")
    examples = generate_from_docs(
        documents,
        count_per_doc=args.count,
        style=args.style,
    )

    output_path = args.output or "generated_dataset.yaml"
    with open(output_path, "w", encoding="utf-8") as f:
        yaml.dump(examples, f, default_flow_style=False, allow_unicode=True)

    print(f"Generated {len(examples)} examples to {output_path}")
    return 0


# ---------------------------------------------------------------------------
# CLI parser construction
# ---------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    """Build the complete CLI argument parser."""
    parser = argparse.ArgumentParser(
        prog="lef",
        description="LEF - LangSmith Evaluation Framework CLI",
    )
    parser.add_argument(
        "-v",
        "-V",
        "--version",
        action="version",
        version=f"%(prog)s {_get_version()}",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose logging",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # --- 'run' subcommand ---
    run_p = subparsers.add_parser("run", help="Run evaluation suite from config file(s)")
    run_p.add_argument(
        "config",
        nargs="+",
        help="Config file path(s). Multiple files are merged (F15).",
    )
    run_p.add_argument("--prefix", help="Override experiment prefix")
    run_p.add_argument("--no-upload", action="store_true", help="Don't upload to LangSmith")
    run_p.add_argument(
        "--threshold",
        action="append",
        help="Score threshold (key=value). Repeatable.",
    )
    run_p.add_argument(
        "--output",
        "-o",
        help="Export results to file (.json, .csv, .xml, .md)",
    )
    run_p.add_argument(
        "--watch",
        "-w",
        action="store_true",
        help="Watch mode: re-run on file changes",
    )
    run_p.add_argument("--cache", action="store_true", help="Cache target outputs between runs")
    run_p.add_argument("--baseline", help="Compare against a saved baseline")
    run_p.add_argument("--save-baseline", help="Save results as a named baseline")
    run_p.add_argument(
        "--github-comment",
        action="store_true",
        help="Post results as GitHub PR comment",
    )
    run_p.add_argument(
        "--azdo-comment",
        action="store_true",
        help="Post results as Azure DevOps PR comment",
    )

    # --- 'compare' subcommand ---
    cmp_p = subparsers.add_parser("compare", help="Compare two baselines/experiments")
    cmp_p.add_argument("--baseline", required=True, help="Baseline name to compare against")
    cmp_p.add_argument("--current", required=True, help="Current results name")
    cmp_p.add_argument(
        "--tolerance",
        type=float,
        default=0.0,
        help="Regression tolerance (default 0.0)",
    )
    cmp_p.add_argument("--output", "-o", help="Export comparison to JSON file")

    # --- 'baseline' subcommand ---
    base_p = subparsers.add_parser("baseline", help="Manage saved baselines")
    base_sub = base_p.add_subparsers(dest="baseline_action")
    base_sub.add_parser("list", help="List saved baselines")
    del_p = base_sub.add_parser("delete", help="Delete a saved baseline")
    del_p.add_argument("name", help="Baseline name to delete")

    # --- 'qa' subcommand ---
    qa_p = subparsers.add_parser("qa", help="QA test a deployed endpoint")
    qa_p.add_argument("url", help="Endpoint URL to test")
    qa_p.add_argument("--data", "-d", required=True, help="Dataset file or LangSmith dataset name")
    qa_p.add_argument(
        "--evaluators",
        "-e",
        nargs="+",
        help="Evaluator names (default: correctness, safety)",
    )
    qa_p.add_argument("--threshold", action="append", help="Score threshold (key=value)")
    qa_p.add_argument("--header", "-H", action="append", help="HTTP header (Key: Value)")
    qa_p.add_argument(
        "--timeout",
        type=float,
        default=60.0,
        help="HTTP timeout seconds (default 60)",
    )
    qa_p.add_argument("--prefix", help="Experiment prefix")
    qa_p.add_argument("--no-upload", action="store_true", help="Don't upload to LangSmith")
    qa_p.add_argument("--output", "-o", help="Export results to file (.json, .csv, .xml, .md)")

    # --- 'monitor' subcommand ---
    mon_p = subparsers.add_parser("monitor", help="Continuously monitor production runs")
    mon_p.add_argument("--project", "-p", required=True, help="LangSmith project name")
    mon_p.add_argument("--evaluators", "-e", nargs="+", help="Evaluator names")
    mon_p.add_argument("--threshold", action="append", help="Alert threshold (key=value)")
    mon_p.add_argument(
        "--interval",
        type=float,
        default=60.0,
        help="Poll interval seconds (default 60)",
    )
    mon_p.add_argument("--batch-size", type=int, default=20, help="Runs per poll (default 20)")
    mon_p.add_argument("--run-type", help="Filter by run type (chain, llm, tool)")

    # --- 'redteam' subcommand ---
    rt_p = subparsers.add_parser("redteam", help="Run adversarial red-team evaluation")
    rt_p.add_argument("config", nargs="?", help="Config file with target definition")
    rt_p.add_argument(
        "--target",
        help="Target function (e.g. myapp.chain:invoke)",
    )
    rt_p.add_argument(
        "--categories",
        help=(
            "Comma-separated attack categories. Available: "
            "prompt_injection, jailbreak, pii_extraction, "
            "hallucination_inducement, toxicity, bias"
        ),
    )
    rt_p.add_argument(
        "--count",
        type=int,
        default=5,
        help="Examples per category (default 5)",
    )
    rt_p.add_argument(
        "--seed-only",
        action="store_true",
        help="Use only seed examples, skip LLM generation",
    )
    rt_p.add_argument("--no-upload", action="store_true", help="Don't upload to LangSmith")

    # --- 'dataset' subcommand ---
    ds_p = subparsers.add_parser("dataset", help="Dataset management commands")
    ds_sub = ds_p.add_subparsers(dest="dataset_action")

    pull_p = ds_sub.add_parser("pull", help="Pull LangSmith dataset to local file")
    pull_p.add_argument("name", help="LangSmith dataset name")
    pull_p.add_argument("--output", "-o", help="Output file path (default: <name>.yaml)")

    push_p = ds_sub.add_parser("push", help="Push local dataset to LangSmith")
    push_p.add_argument("file", help="Local dataset file")
    push_p.add_argument("--name", help="Dataset name (default: filename)")
    push_p.add_argument("--description", help="Dataset description")

    diff_p = ds_sub.add_parser("diff", help="Diff two local dataset files")
    diff_p.add_argument("file_a", help="First dataset file")
    diff_p.add_argument("file_b", help="Second dataset file")

    gen_p = ds_sub.add_parser("generate", help="Generate synthetic dataset from documents")
    gen_p.add_argument(
        "source",
        help="Document file (.txt, .md, .pdf) or directory",
    )
    gen_p.add_argument(
        "--output",
        "-o",
        help="Output file (default: generated_dataset.yaml)",
    )
    gen_p.add_argument(
        "--count",
        type=int,
        default=5,
        help="QA pairs per document (default 5)",
    )
    gen_p.add_argument(
        "--style",
        choices=["factual", "reasoning", "conversational"],
        default="factual",
        help=(
            "Generation style: factual (fact-based Q&A), "
            "reasoning (multi-step), conversational (natural)"
        ),
    )

    return parser


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    """Main CLI entry point."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    # Setup logging
    log_level = logging.DEBUG if getattr(args, "verbose", False) else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

    command_map = {
        "run": run_command,
        "compare": compare_command,
        "baseline": baseline_command,
        "qa": qa_command,
        "monitor": monitor_command,
        "redteam": redteam_command,
        "dataset": dataset_command,
    }

    handler = command_map.get(args.command)
    if handler:
        return handler(args)

    parser.print_help(sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
