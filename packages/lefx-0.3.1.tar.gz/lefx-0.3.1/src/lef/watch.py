"""Watch mode for automatic re-evaluation on file changes.

Monitors config files, dataset files, and source directories for changes
and re-triggers evaluation runs automatically.
"""

from __future__ import annotations

import contextlib
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def _get_file_mtimes(paths: list[Path]) -> dict[str, float]:
    """Get modification times for a list of files/directories."""
    mtimes: dict[str, float] = {}
    for p in paths:
        if p.is_file():
            with contextlib.suppress(OSError):
                mtimes[str(p)] = p.stat().st_mtime
        elif p.is_dir():
            for root, _dirs, files in os.walk(p):
                for f in files:
                    if f.endswith((".py", ".yaml", ".yml", ".json", ".csv")):
                        fp = Path(root) / f
                        with contextlib.suppress(OSError):
                            mtimes[str(fp)] = fp.stat().st_mtime
    return mtimes


def _detect_changes(
    old_mtimes: dict[str, float],
    new_mtimes: dict[str, float],
) -> list[str]:
    """Detect which files changed between two snapshots."""
    changed: list[str] = []
    for path, mtime in new_mtimes.items():
        if path not in old_mtimes or old_mtimes[path] != mtime:
            changed.append(path)
    return changed


def watch_and_run(
    run_fn: Any,
    *,
    watch_paths: list[str | Path],
    interval: float = 2.0,
    on_change: Any | None = None,
) -> None:
    """Watch files and re-run evaluation when changes are detected.

    Args:
        run_fn: Callable to execute on each change (and initially).
            Should be a no-arg callable that runs the evaluation.
        watch_paths: List of files and directories to watch.
        interval: Polling interval in seconds (default 2.0).
        on_change: Optional callback when changes detected.
            Called with list of changed file paths.

    Runs indefinitely until interrupted with Ctrl+C.

    Example::

        def do_eval():
            results = run_eval(target=my_fn, data="examples.yaml", evaluators=[...])
            print(format_results_table(results))

        watch_and_run(do_eval, watch_paths=["config.yaml", "examples.yaml", "src/"])
    """
    resolved_paths = [Path(p) for p in watch_paths]

    print(f"Watching {len(resolved_paths)} path(s) for changes (polling every {interval}s)...")
    print("Press Ctrl+C to stop.\n")

    # Initial run
    print("=" * 60)
    print("  Initial evaluation run")
    print("=" * 60)
    try:
        run_fn()
    except Exception as exc:
        print(f"Error during evaluation: {exc}", file=sys.stderr)

    # Watch loop
    mtimes = _get_file_mtimes(resolved_paths)

    try:
        while True:
            time.sleep(interval)
            new_mtimes = _get_file_mtimes(resolved_paths)
            changed = _detect_changes(mtimes, new_mtimes)

            if changed:
                print(f"\nDetected changes in {len(changed)} file(s):")
                for c in changed[:5]:
                    print(f"  - {c}")
                if len(changed) > 5:
                    print(f"  ... and {len(changed) - 5} more")
                print()

                if on_change:
                    on_change(changed)

                print("=" * 60)
                print("  Re-running evaluation")
                print("=" * 60)
                try:
                    run_fn()
                except Exception as exc:
                    print(f"Error during evaluation: {exc}", file=sys.stderr)

                mtimes = new_mtimes

    except KeyboardInterrupt:
        print("\nWatch mode stopped.")
