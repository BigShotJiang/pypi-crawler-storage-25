"""Result caching for evaluation targets.

Caches target function outputs to avoid expensive re-invocations when
iterating on evaluators. Uses content-addressable hashing of inputs.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_CACHE_DIR = Path(".lef") / "cache"


def _hash_inputs(inputs: dict[str, Any]) -> str:
    """Create a deterministic hash of input dict."""
    serialized = json.dumps(inputs, sort_keys=True, default=str)
    return hashlib.sha256(serialized.encode()).hexdigest()[:16]


class ResultCache:
    """On-disk cache for target function outputs.

    Caches the result of ``target(inputs)`` so that re-running evals with
    different evaluators doesn't require re-calling the (expensive) target.

    Example::

        cache = ResultCache()
        cached_target = cache.wrap(my_chain.invoke)

        # First run: calls my_chain.invoke for each input
        run_eval(target=cached_target, data=examples, evaluators=[judge1])

        # Second run: uses cached outputs, only re-evaluates
        run_eval(target=cached_target, data=examples, evaluators=[judge2])
    """

    def __init__(
        self,
        *,
        cache_dir: str | Path | None = None,
        ttl_seconds: int | None = None,
    ):
        self.cache_dir = Path(cache_dir) if cache_dir else _CACHE_DIR
        self.ttl_seconds = ttl_seconds
        self._hits = 0
        self._misses = 0

    def wrap(self, target: Callable[..., Any]) -> Callable[..., Any]:
        """Wrap a target function with caching.

        Returns a new callable that checks the cache before invoking
        the original target.
        """
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        def cached_target(inputs: dict[str, Any], **kwargs: Any) -> Any:
            cache_key = _hash_inputs(inputs)
            cached = self._read(cache_key)
            if cached is not None:
                self._hits += 1
                logger.debug("Cache HIT for %s", cache_key)
                return cached

            self._misses += 1
            logger.debug("Cache MISS for %s", cache_key)
            result = target(inputs, **kwargs)
            self._write(cache_key, result)
            return result

        cached_target.__name__ = f"cached_{getattr(target, '__name__', 'target')}"
        cached_target.__wrapped__ = target  # type: ignore[attr-defined]
        return cached_target

    def wrap_async(self, target: Callable[..., Any]) -> Callable[..., Any]:
        """Wrap an async target function with caching."""
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        async def cached_target(inputs: dict[str, Any], **kwargs: Any) -> Any:
            cache_key = _hash_inputs(inputs)
            cached = self._read(cache_key)
            if cached is not None:
                self._hits += 1
                return cached

            self._misses += 1
            result = await target(inputs, **kwargs)
            self._write(cache_key, result)
            return result

        cached_target.__name__ = f"cached_{getattr(target, '__name__', 'target')}"
        cached_target.__wrapped__ = target  # type: ignore[attr-defined]
        return cached_target

    def _read(self, key: str) -> Any | None:
        """Read a cached result, respecting TTL."""
        filepath = self.cache_dir / f"{key}.json"
        if not filepath.exists():
            return None

        try:
            with open(filepath, encoding="utf-8") as f:
                data = json.load(f)

            if self.ttl_seconds is not None:
                cached_at = data.get("_cached_at", 0)
                if time.time() - cached_at >= self.ttl_seconds:
                    filepath.unlink(missing_ok=True)
                    return None

            return data.get("result")
        except (json.JSONDecodeError, KeyError, OSError):
            return None

    def _write(self, key: str, result: Any) -> None:
        """Write a result to cache."""
        filepath = self.cache_dir / f"{key}.json"
        try:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump({"result": result, "_cached_at": time.time()}, f, default=str)
        except (TypeError, OSError) as exc:
            logger.warning("Failed to cache result for %s: %s", key, exc)

    def clear(self) -> int:
        """Clear all cached results. Returns number of entries cleared."""
        if not self.cache_dir.exists():
            return 0
        count = 0
        for f in self.cache_dir.glob("*.json"):
            f.unlink()
            count += 1
        logger.info("Cleared %d cached entries", count)
        return count

    @property
    def stats(self) -> dict[str, int]:
        """Return cache hit/miss statistics."""
        return {"hits": self._hits, "misses": self._misses}
