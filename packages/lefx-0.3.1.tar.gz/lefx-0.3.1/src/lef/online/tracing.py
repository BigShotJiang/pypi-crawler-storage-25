"""Online/tracing evaluation - evaluate LangSmith runs in real-time.

Provides utilities for setting up online evaluators that automatically
score runs as they come in via LangSmith tracing.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable, Sequence
from typing import Any

from langsmith import Client

logger = logging.getLogger(__name__)

_default_client: Client | None = None


def _get_default_client() -> Client:
    """Return a module-level shared Client to avoid creating one per call."""
    global _default_client  # noqa: PLW0603
    if _default_client is None:
        _default_client = Client()
    return _default_client


def evaluate_run(
    run_id: str,
    *,
    evaluators: Sequence[Callable[..., Any]],
    client: Client | None = None,
) -> list[dict[str, Any]]:
    """Evaluate an existing LangSmith run by its ID.

    Fetches the run from LangSmith and applies the given evaluators.
    Results are posted as feedback on the run.

    Args:
        run_id: The LangSmith run ID to evaluate.
        evaluators: List of evaluator functions to score the run.
        client: Optional LangSmith client instance.

    Returns:
        List of evaluation result dicts.

    Example::

        from lef.judges import correctness_judge
        results = evaluate_run(
            "run-uuid-here",
            evaluators=[correctness_judge()],
        )
    """
    ls_client = client or _get_default_client()
    run = ls_client.read_run(run_id)
    logger.info("Evaluating run %s with %d evaluators", run_id, len(evaluators))

    results = []
    for evaluator in evaluators:
        ref_outputs = None
        if (
            hasattr(run, "reference_example")
            and run.reference_example
            and hasattr(run.reference_example, "outputs")
        ):
            ref_outputs = run.reference_example.outputs

        result = evaluator(
            inputs=run.inputs or {},
            outputs=run.outputs or {},
            reference_outputs=ref_outputs,
        )

        if isinstance(result, dict):
            result_dict = result
        elif hasattr(result, "model_dump"):
            result_dict = result.model_dump()
        else:
            result_dict = {"key": "score", "score": result}
        key = result_dict.get("key", "score")
        score = result_dict.get("score", 0.0)
        comment = result_dict.get("comment")

        ls_client.create_feedback(
            run_id=run.id,
            key=key,
            score=float(score) if isinstance(score, (int, float)) else (1.0 if score else 0.0),
            comment=comment,
        )
        results.append(result_dict)

    return results


def create_rule_config(
    *,
    name: str,
    evaluator: Callable[..., Any],
    project_name: str | None = None,
    sampling_rate: float = 1.0,
) -> dict[str, Any]:
    """Create an online evaluation rule configuration dict.

    Returns a config dict for use with custom polling or webhook handlers.
    This does **not** register anything with LangSmith — to set up
    automated online evaluation, use the LangSmith UI or API directly.

    Args:
        name: Name for the evaluation rule.
        evaluator: The evaluator function to run on matching traces.
        project_name: The LangSmith project to attach the rule to.
        sampling_rate: Fraction of runs to evaluate (0.0 to 1.0).

    Returns:
        A rule configuration dict.

    Example::

        from lef.judges import safety_judge

        rule = create_rule_config(
            name="safety-check",
            evaluator=safety_judge(),
            project_name="my-chatbot",
            sampling_rate=0.1,  # Evaluate 10% of runs
        )
    """
    return {
        "name": name,
        "evaluator": evaluator,
        "project_name": project_name,
        "sampling_rate": sampling_rate,
    }


# Backwards-compatible alias
create_rule = create_rule_config


class OnlineEvaluator:
    """Manages online evaluation of LangSmith runs.

    Provides a convenient interface for evaluating runs from a specific
    project, with support for filtering and batch processing.

    Example::

        online = OnlineEvaluator(project_name="my-chatbot")
        online.add_evaluator(safety_judge())
        online.add_evaluator(response_quality_judge())

        # Evaluate recent runs
        results = online.evaluate_recent(limit=100)

        # Evaluate a specific run
        result = online.evaluate_run("run-id")
    """

    def __init__(
        self,
        *,
        project_name: str,
        client: Client | None = None,
    ):
        self.project_name = project_name
        self.client = client or Client()
        self._evaluators: list[Callable[..., Any]] = []

    def add_evaluator(self, evaluator: Callable[..., Any]) -> OnlineEvaluator:
        """Add an evaluator. Returns self for chaining."""
        self._evaluators.append(evaluator)
        return self

    def evaluate_run(self, run_id: str) -> list[dict[str, Any]]:
        """Evaluate a single run by ID."""
        return evaluate_run(
            run_id,
            evaluators=self._evaluators,
            client=self.client,
        )

    def evaluate_recent(
        self,
        *,
        limit: int = 10,
        run_type: str | None = None,
    ) -> list[list[dict[str, Any]]]:
        """Evaluate the most recent runs in the project.

        Args:
            limit: Maximum number of runs to evaluate.
            run_type: Optional filter by run type (e.g., "chain", "llm", "tool").

        Returns:
            List of evaluation result lists, one per run.
        """
        runs = self.client.list_runs(
            project_name=self.project_name,
            limit=limit,
            run_type=run_type,
        )

        all_results = []
        for run in runs:
            run_results = evaluate_run(
                str(run.id),
                evaluators=self._evaluators,
                client=self.client,
            )
            all_results.append(run_results)

        return all_results

    async def aevaluate_recent(
        self,
        *,
        limit: int = 10,
        run_type: str | None = None,
        max_concurrency: int = 5,
    ) -> list[list[dict[str, Any]]]:
        """Async evaluate the most recent runs with concurrency.

        Args:
            limit: Maximum number of runs to evaluate.
            run_type: Optional filter by run type (e.g., "chain", "llm", "tool").
            max_concurrency: Max runs to evaluate in parallel (default 5).

        Returns:
            List of evaluation result lists, one per run.
        """
        runs = self.client.list_runs(
            project_name=self.project_name,
            limit=limit,
            run_type=run_type,
        )

        semaphore = asyncio.Semaphore(max_concurrency)

        async def _eval_one(run_id: str) -> list[dict[str, Any]]:
            async with semaphore:
                return await asyncio.to_thread(
                    evaluate_run,
                    run_id,
                    evaluators=self._evaluators,
                    client=self.client,
                )

        tasks = [_eval_one(str(run.id)) for run in runs]
        return list(await asyncio.gather(*tasks))
