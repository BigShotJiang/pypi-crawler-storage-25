"""LangGraph evaluation - Evaluate agents and graphs.

Shows how to evaluate LangGraph StateGraphs with LEF,
including input/output mapping and agent-specific evaluators.
"""

from typing import Annotated, TypedDict

from lef import (
    evaluate_graph,
    create_graph_target,
    correctness_judge,
    tool_selection_judge,
    scorer,
    run_eval,
)


# --- Define a simple LangGraph agent (example skeleton) ---

class AgentState(TypedDict):
    """Example agent state."""
    messages: list
    answer: str


# In a real project, you'd build your graph here:
#
#   from langgraph.graph import StateGraph
#   builder = StateGraph(AgentState)
#   builder.add_node("agent", agent_node)
#   builder.add_node("tools", tool_node)
#   ...
#   app = builder.compile()


# --- Custom agent evaluator ---

@scorer(key="uses_tools")
def uses_tools(*, inputs, outputs, **kwargs):
    """Check if the agent used any tools (from message history)."""
    messages = outputs.get("messages", [])
    for msg in messages:
        if hasattr(msg, "type") and msg.type == "tool":
            return True
        if isinstance(msg, dict) and msg.get("type") == "tool":
            return True
    return False


@scorer(key="conversation_length")
def conversation_length(*, inputs, outputs, **kwargs):
    """Score based on conversation efficiency (fewer messages = better)."""
    messages = outputs.get("messages", [])
    # Ideal: 2-4 messages (user + assistant + maybe tools)
    n = len(messages)
    if n <= 4:
        return 1.0
    elif n <= 8:
        return 0.7
    elif n <= 15:
        return 0.4
    return 0.2


# --- Evaluate a LangGraph graph ---

def evaluate_my_agent(app):
    """Evaluate a compiled LangGraph app.

    Args:
        app: A compiled LangGraph StateGraph.
    """
    results = evaluate_graph(
        app,
        data="agent-eval-dataset",
        evaluators=[
            correctness_judge(),
            tool_selection_judge(),
            uses_tools,
            conversation_length,
        ],
        # Map dataset inputs to graph format
        input_mapper=lambda x: {
            "messages": [("user", x["question"])],
            "answer": "",
        },
        # Map graph output to evaluator format
        output_mapper=lambda x: {
            "answer": x.get("answer", ""),
            "messages": x.get("messages", []),
        },
        experiment_prefix="agent-v1",
    )
    return results


# --- Alternative: manual target wrapping ---

def evaluate_with_manual_target(app):
    """Shows how to manually create a target for more control."""
    target = create_graph_target(
        app,
        input_mapper=lambda x: {"messages": [("user", x["question"])]},
        output_mapper=lambda x: {"answer": x["messages"][-1].content},
    )

    return run_eval(
        target=target,
        data="agent-eval-dataset",
        evaluators=[correctness_judge()],
    )


if __name__ == "__main__":
    print("This example requires a compiled LangGraph app.")
    print("See the README for full setup instructions.")
    print()
    print("Quick usage:")
    print("  from lef import evaluate_graph")
    print("  results = evaluate_graph(app, data='my-dataset', evaluators=[...])")
