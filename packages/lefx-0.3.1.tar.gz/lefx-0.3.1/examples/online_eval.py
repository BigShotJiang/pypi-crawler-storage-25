"""Online evaluation - Evaluate LangSmith runs in real-time.

Shows how to evaluate existing runs and set up ongoing evaluation
for production monitoring.
"""

from lef import (
    OnlineEvaluator,
    evaluate_run,
    safety_judge,
    response_quality_judge,
    scorer,
)


# --- Evaluate a single run ---

def evaluate_single_run(run_id: str):
    """Evaluate an existing LangSmith run by ID."""
    results = evaluate_run(
        run_id,
        evaluators=[
            safety_judge(),
            response_quality_judge(),
        ],
    )
    for r in results:
        print(f"  {r.get('key')}: {r.get('score')}")
    return results


# --- Monitor a project's runs ---

def monitor_project():
    """Set up ongoing evaluation for a LangSmith project."""
    online = OnlineEvaluator(project_name="my-chatbot-production")
    online.add_evaluator(safety_judge())
    online.add_evaluator(response_quality_judge())

    # Evaluate the 50 most recent runs
    results = online.evaluate_recent(limit=50)
    print(f"Evaluated {len(results)} runs")
    return results


# --- Custom online scorer for latency ---

@scorer(key="acceptable_latency")
def acceptable_latency(*, inputs, outputs, **kwargs):
    """Check if response was generated within acceptable time.

    Note: In a real setup, you'd extract latency from the run metadata.
    """
    latency_ms = outputs.get("latency_ms", 0)
    if latency_ms < 1000:
        return 1.0
    elif latency_ms < 3000:
        return 0.7
    elif latency_ms < 5000:
        return 0.3
    return 0.0


if __name__ == "__main__":
    print("Online evaluation examples:")
    print()
    print("  # Evaluate a specific run")
    print("  evaluate_single_run('your-run-id')")
    print()
    print("  # Monitor recent runs in a project")
    print("  monitor_project()")
