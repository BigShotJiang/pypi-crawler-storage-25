"""LEF Quickstart - Get running with evaluations in minutes.

This example shows the simplest way to use LEF to evaluate
a LangChain chain against a LangSmith dataset.

Prerequisites:
    pip install lefx[all]
    export LANGCHAIN_API_KEY=your-key
    export OPENAI_API_KEY=your-key
"""

from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate

from lef import (
    EvalRunner,
    correctness_judge,
    exact_match,
    scorer,
)


# 1. Define your chain
prompt = ChatPromptTemplate.from_template("Answer this question concisely: {question}")
llm = ChatOpenAI(model="gpt-4o-mini")
chain = prompt | llm


# 2. Create a simple target function for evaluation
def target(inputs: dict) -> dict:
    result = chain.invoke({"question": inputs["question"]})
    return {"answer": result.content}


# 3. Create a custom scorer (optional - shows how easy it is)
@scorer(key="has_answer")
def has_answer(*, inputs, outputs, **kwargs):
    """Check that the output actually contains an answer."""
    return bool(outputs.get("answer", "").strip())


# 4. Run evaluation
if __name__ == "__main__":
    runner = EvalRunner(
        dataset="my-qa-dataset",  # Create this dataset in LangSmith first
        experiment_prefix="quickstart-v1",
    )
    runner.add_evaluators([
        correctness_judge(),  # LLM-as-Judge for correctness
        exact_match,          # Exact string match
        has_answer,           # Custom scorer
    ])

    results = runner.run(target=target)
    print("Evaluation complete! Check LangSmith for results.")
