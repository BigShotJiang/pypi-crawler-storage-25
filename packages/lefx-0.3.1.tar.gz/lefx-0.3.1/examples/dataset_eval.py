"""Dataset-driven evaluation - Create datasets and run evals.

Shows how to create LangSmith datasets programmatically and
run evaluations against them.
"""

from lef import (
    EvalRunner,
    create_dataset,
    correctness_judge,
    exact_match,
    contains,
    run_eval,
    run_comparative_eval,
)
from lef.datasets.runner import run_comparative_eval


def my_chain_v1(inputs: dict) -> dict:
    """V1 of your chain - placeholder."""
    return {"answer": "Paris"}


def my_chain_v2(inputs: dict) -> dict:
    """V2 of your chain - placeholder."""
    return {"answer": "The capital of France is Paris."}


# --- Create a dataset programmatically ---

def create_example_dataset():
    dataset_id = create_dataset(
        "geography-qa",
        examples=[
            {
                "inputs": {"question": "What is the capital of France?"},
                "outputs": {"answer": "Paris"},
            },
            {
                "inputs": {"question": "What is the capital of Japan?"},
                "outputs": {"answer": "Tokyo"},
            },
            {
                "inputs": {"question": "What is the largest continent?"},
                "outputs": {"answer": "Asia"},
            },
        ],
        description="Geography Q&A evaluation dataset",
    )
    print(f"Created dataset: {dataset_id}")
    return dataset_id


# --- Run evaluation with EvalRunner ---

def run_with_runner():
    runner = EvalRunner(
        dataset="geography-qa",
        experiment_prefix="geo-v1",
        max_concurrency=3,
    )
    runner.add_evaluators([
        correctness_judge(),
        exact_match,
        contains,
    ])
    return runner.run(target=my_chain_v1)


# --- Compare two versions ---

def compare_versions():
    evaluators = [correctness_judge(), exact_match]

    # Run both versions
    run_eval(
        my_chain_v1,
        data="geography-qa",
        evaluators=evaluators,
        experiment_prefix="geo-v1",
    )
    run_eval(
        my_chain_v2,
        data="geography-qa",
        evaluators=evaluators,
        experiment_prefix="geo-v2",
    )

    # Compare them
    results = run_comparative_eval(
        experiments=["geo-v1", "geo-v2"],
        evaluators=evaluators,
    )
    return results


if __name__ == "__main__":
    create_example_dataset()
    results = run_with_runner()
    print("Evaluation complete!")
