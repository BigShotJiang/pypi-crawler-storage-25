"""LLM-as-Judge examples - Using LLM judges to evaluate outputs.

Shows how to use pre-built judges, create custom judges,
and use different judge models.
"""

from lef import (
    create_judge,
    correctness_judge,
    faithfulness_judge,
    safety_judge,
    response_quality_judge,
    JudgeModel,
    run_eval,
)


def target(inputs: dict) -> dict:
    """Your chain/agent goes here. This is a placeholder."""
    return {"answer": f"The answer to '{inputs['question']}' is 42."}


# --- Pre-built judges ---

# Correctness judge using GPT-4o (default)
correctness = correctness_judge()

# Same but using Claude as the judge
correctness_claude = correctness_judge(model=JudgeModel.CLAUDE_SONNET)

# Faithfulness judge for RAG systems
faithfulness = faithfulness_judge()

# Safety judge
safety = safety_judge()

# Response quality judge
quality = response_quality_judge()


# --- Custom judge ---

custom_judge = create_judge(
    prompt="""Evaluate whether this response is suitable for a professional audience.

User question: {inputs}
Assistant response: {outputs}

Score 1.0 if professional, 0.0 if not. Explain your reasoning.""",
    model="openai:gpt-4o",
    feedback_key="professionalism",
)


# --- Run with multiple judges ---

if __name__ == "__main__":
    results = run_eval(
        target=target,
        data="my-qa-dataset",
        evaluators=[
            correctness,
            quality,
            safety,
            custom_judge,
        ],
        experiment_prefix="judges-demo",
    )
    print("Done! Check LangSmith for detailed results.")
