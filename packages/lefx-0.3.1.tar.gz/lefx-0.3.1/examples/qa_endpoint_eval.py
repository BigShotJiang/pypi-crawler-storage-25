"""LEF QA Endpoint Testing - Test a deployed LangSmith/LangGraph endpoint.

This example demonstrates a real-world workflow:
1. Define a test dataset with questions and expected answers
2. Point LEF at your deployed HTTP endpoint
3. Run evaluations with multiple judges
4. Generate a Markdown report with pass/fail thresholds
5. Gate deployments based on quality scores

This works with LangSmith Deployments, LangServe, LangGraph Platform,
or any HTTP endpoint that accepts JSON POST requests.

Prerequisites:
    pip install lefx[all]
    export OPENAI_API_KEY=your-key      # For LLM-as-judge evaluations
    export LANGCHAIN_API_KEY=your-key    # If uploading to LangSmith

Usage:
    # Run this script directly
    python examples/qa_endpoint_eval.py

    # Or use the CLI (equivalent)
    lef qa https://your-endpoint.com/invoke \
        --data examples/qa_dataset.yaml \
        --evaluators correctness_judge safety_judge \
        --threshold correctness=0.8 safety=0.95 \
        --output results/qa_report.md
"""

import os

from lef import (
    assert_scores,
    check_scores,
    create_remote_target,
    create_scorer,
    export_markdown,
    format_results_table,
    load_examples,
    run_eval,
    save_baseline,
    compare_results,
    correctness_judge,
    safety_judge,
    scorer,
)


# ---------------------------------------------------------------------------
# 1. Define your test dataset inline (or load from YAML/JSON/CSV)
# ---------------------------------------------------------------------------

QA_DATASET = [
    {
        "inputs": {"question": "What is the capital of France?"},
        "outputs": {"answer": "Paris"},
    },
    {
        "inputs": {"question": "What programming language is LangChain written in?"},
        "outputs": {"answer": "Python"},
    },
    {
        "inputs": {"question": "What does RAG stand for?"},
        "outputs": {"answer": "Retrieval-Augmented Generation"},
    },
    {
        "inputs": {"question": "Name a common vector database."},
        "outputs": {"answer": "Pinecone"},
    },
    {
        "inputs": {"question": "What is the purpose of a system prompt?"},
        "outputs": {"answer": "To set the behavior and context for the AI model"},
    },
]

# Alternative: load from a YAML file
# QA_DATASET = load_examples("examples/qa_dataset.yaml")


# ---------------------------------------------------------------------------
# 2. Create a target pointing to your deployed endpoint
# ---------------------------------------------------------------------------

# Option A: LangSmith Deployment / LangGraph Platform
ENDPOINT_URL = os.environ.get("QA_ENDPOINT_URL", "https://your-endpoint.com/invoke")

target = create_remote_target(
    ENDPOINT_URL,
    # Add auth headers if needed
    headers={
        "x-api-key": os.environ.get("ENDPOINT_API_KEY", ""),
        "Content-Type": "application/json",
    },
    # Map dataset inputs → request body
    input_mapper=lambda inputs: {
        "input": {"messages": [{"role": "user", "content": inputs["question"]}]},
    },
    # Map response → evaluator-friendly output
    output_mapper=lambda resp: {
        "answer": resp.get("output", {}).get("messages", [{}])[-1].get("content", "")
        if isinstance(resp.get("output"), dict)
        else str(resp.get("output", "")),
    },
    timeout=30.0,
)

# Option B: Simple REST API (uncomment to use)
# target = create_remote_target(
#     "https://api.example.com/chat",
#     input_mapper=lambda inputs: {"query": inputs["question"]},
#     output_mapper=lambda resp: {"answer": resp["response"]},
# )

# Option C: For local testing without a real endpoint, use a mock target
def mock_target(inputs: dict) -> dict:
    """Mock target for demonstration - replace with create_remote_target above."""
    answers = {
        "What is the capital of France?": "Paris",
        "What programming language is LangChain written in?": "Python",
        "What does RAG stand for?": "Retrieval-Augmented Generation",
        "Name a common vector database.": "Pinecone, Weaviate, and Chroma are popular choices",
        "What is the purpose of a system prompt?": "A system prompt sets behavior and context for the AI",
    }
    return {"answer": answers.get(inputs["question"], "I don't know")}


# ---------------------------------------------------------------------------
# 3. Define evaluators (built-in + custom)
# ---------------------------------------------------------------------------

# Custom scorer: check the response isn't empty
@scorer(key="non_empty")
def non_empty_check(*, outputs, **kwargs) -> bool:
    """Verify the endpoint returned a non-empty response."""
    answer = outputs.get("answer", "")
    return bool(answer and answer.strip())


# Custom scorer: check response length is reasonable
@scorer(key="reasonable_length")
def length_check(*, outputs, **kwargs) -> float:
    """Score based on response length (penalize very short or very long)."""
    answer = outputs.get("answer", "")
    length = len(answer)
    if length < 5:
        return 0.0
    if length > 2000:
        return 0.5
    return 1.0


# Quality thresholds for pass/fail gating
THRESHOLDS = {
    "correctness": 0.8,   # 80% of answers must be correct
    "safety": 0.95,       # 95% must be safe
    "non_empty": 1.0,     # All responses must be non-empty
}


# ---------------------------------------------------------------------------
# 4. Run the evaluation
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Use mock_target for demo; replace with `target` for real endpoint
    eval_target = mock_target

    print("Running QA evaluation...")
    results = run_eval(
        eval_target,
        data=QA_DATASET,
        evaluators=[
            correctness_judge(),   # LLM judges correctness vs reference
            safety_judge(),        # LLM judges safety
            non_empty_check,       # Custom: non-empty check
            length_check,          # Custom: length check
        ],
        experiment_prefix="qa-endpoint-test",
        upload_results=False,  # Set True to upload to LangSmith
    )

    # ---------------------------------------------------------------------------
    # 5. Display results in terminal
    # ---------------------------------------------------------------------------

    print(format_results_table(results, thresholds=THRESHOLDS))

    # ---------------------------------------------------------------------------
    # 6. Export Markdown report
    # ---------------------------------------------------------------------------

    export_markdown(
        results,
        "results/qa_report.md",
        thresholds=THRESHOLDS,
        metadata={
            "Endpoint": ENDPOINT_URL,
            "Dataset": f"{len(QA_DATASET)} examples",
            "Experiment": "qa-endpoint-test",
        },
    )
    print("Markdown report saved to results/qa_report.md")

    # ---------------------------------------------------------------------------
    # 7. Check pass/fail (for CI gating)
    # ---------------------------------------------------------------------------

    # Option A: Soft check - returns a report dict
    report = check_scores(results, THRESHOLDS)
    for metric, info in report.items():
        status = "PASS" if info["passed"] else "FAIL"
        print(f"  {metric}: {info['actual']:.4f} >= {info['threshold']:.4f} [{status}]")

    # Option B: Hard check - raises EvalAssertionError if thresholds fail
    # Uncomment for CI/CD pipelines:
    # assert_scores(results, THRESHOLDS)

    # ---------------------------------------------------------------------------
    # 8. Save as baseline for future comparison (optional)
    # ---------------------------------------------------------------------------

    # save_baseline(results, "qa-endpoint-v1")
    # print("Baseline saved as 'qa-endpoint-v1'")
    #
    # # Later, compare against the baseline:
    # report = compare_results(results, baseline="qa-endpoint-v1")
    # print(report.format_markdown())
