"""Custom scorers - Build your own evaluation metrics.

Shows multiple ways to create custom scorers:
1. @scorer decorator (simplest)
2. BaseEvaluator subclass (most flexible)
3. create_scorer() factory (dynamic creation)
4. Composite scorers (combine multiple scorers)
"""

from lef import (
    scorer,
    evaluator,
    BaseEvaluator,
    EvalResult,
    run_eval,
    exact_match,
    contains,
)
from lef.scorers import create_scorer, create_composite_scorer


# --- Method 1: @scorer decorator (recommended for simple cases) ---

@scorer(key="response_length")
def response_length(*, inputs, outputs, **kwargs):
    """Score based on response length (normalized to 0-1)."""
    answer = outputs.get("answer", "")
    # Normalize: 0 for empty, 1.0 for 500+ chars
    return min(len(answer) / 500.0, 1.0)


@scorer(key="no_hallucination_markers")
def no_hallucination_markers(*, inputs, outputs, **kwargs):
    """Check that response doesn't contain common hallucination markers."""
    markers = ["I think", "I believe", "I'm not sure", "probably", "might be"]
    answer = outputs.get("answer", "").lower()
    return not any(marker.lower() in answer for marker in markers)


@evaluator(key="format_check")  # @evaluator is an alias for @scorer
def format_check(*, inputs, outputs, **kwargs):
    """Check output format requirements."""
    answer = outputs.get("answer", "")
    checks = {
        "not_empty": bool(answer.strip()),
        "reasonable_length": 10 < len(answer) < 5000,
        "no_error_messages": "error" not in answer.lower(),
    }
    passed = sum(checks.values())
    return EvalResult(
        key="format_check",
        score=passed / len(checks),
        comment=f"Passed {passed}/{len(checks)} checks: {checks}",
    )


# --- Method 2: BaseEvaluator subclass (for complex evaluators) ---

class SemanticSimilarityEvaluator(BaseEvaluator):
    """Evaluator that checks semantic similarity using embeddings.

    This is a skeleton - plug in your embedding model of choice.
    """

    key = "semantic_similarity"

    def __init__(self, threshold: float = 0.8):
        self.threshold = threshold

    def evaluate(self, *, inputs, outputs, reference_outputs=None, **kwargs):
        if not reference_outputs:
            return EvalResult(key=self.key, score=0.0, comment="No reference outputs")

        # Placeholder - replace with actual embedding similarity
        output_text = str(outputs.get("answer", ""))
        ref_text = str(reference_outputs.get("answer", ""))

        # Simple word overlap as placeholder for embedding similarity
        output_words = set(output_text.lower().split())
        ref_words = set(ref_text.lower().split())

        if not ref_words:
            return EvalResult(key=self.key, score=0.0)

        overlap = len(output_words & ref_words) / len(ref_words)
        return EvalResult(
            key=self.key,
            score=overlap,
            comment=f"Word overlap: {overlap:.2f} (threshold: {self.threshold})",
        )


# --- Method 3: create_scorer() factory (for dynamic creation) ---

def make_keyword_scorer(keywords: list[str]):
    """Dynamically create a scorer that checks for required keywords."""

    def _check(*, inputs, outputs, **kwargs):
        answer = outputs.get("answer", "").lower()
        found = sum(1 for kw in keywords if kw.lower() in answer)
        return found / len(keywords) if keywords else 0.0

    return create_scorer(f"keywords_{'_'.join(keywords[:3])}", _check)


# --- Method 4: Composite scorer ---

quality_composite = create_composite_scorer(
    "overall_quality",
    scorers=[response_length, no_hallucination_markers, format_check],
    aggregation="mean",
)

strict_composite = create_composite_scorer(
    "strict_pass",
    scorers=[exact_match, no_hallucination_markers],
    aggregation="all_pass",
)


# --- Usage ---

if __name__ == "__main__":
    def target(inputs: dict) -> dict:
        return {"answer": "Paris is the capital of France."}

    results = run_eval(
        target=target,
        data="my-dataset",
        evaluators=[
            response_length,
            no_hallucination_markers,
            format_check,
            SemanticSimilarityEvaluator(threshold=0.7),
            make_keyword_scorer(["paris", "capital", "france"]),
            quality_composite,
        ],
        experiment_prefix="custom-scorers",
    )
    print("Done!")
