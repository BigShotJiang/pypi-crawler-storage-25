# LEF Walkthrough: Financial Assistant Chatbot Evaluation

A complete guide to evaluating a **LangGraph financial assistant chatbot** using LEF — from local development through CI/CD to production monitoring on LangSmith Deployments Hybrid (AWS EKS).

---

## Table of Contents

- [Phase 1: Local Development](#phase-1-local-development)
- [Phase 2: CI/CD Pipeline Integration](#phase-2-cicd-pipeline-integration)
- [Phase 3: Remote / Deployed Evaluation](#phase-3-remote--deployed-evaluation)
- [Phase 4: Advanced Patterns](#phase-4-advanced-patterns)

---

## Phase 1: Local Development

### Installation

```bash
# With pip
pip install lefx[all]

# With uv (recommended)
uv add lefx[all]

# Minimal (no LLM judges or trajectory evaluation)
pip install lefx
```

> **Note:** The PyPI package name is `lefx`, but the import remains `import lef`.

The `[all]` extra installs `openevals`, `agentevals`, `httpx`, `pyyaml`, and other optional dependencies.

### Your LangGraph Financial Chatbot

Assume you have a LangGraph agent like this:

```python
# myapp/agent.py
from langgraph.graph import StateGraph, MessagesState

def financial_assistant(state: MessagesState) -> MessagesState:
    """Your agent node — calls LLM, looks up market data, etc."""
    ...

graph = StateGraph(MessagesState)
graph.add_node("assistant", financial_assistant)
graph.set_entry_point("assistant")
app = graph.compile()
```

The agent takes `MessagesState` (a dict with a `"messages"` list) and returns updated messages. This is the standard LangGraph pattern.

### Creating a Local Test Dataset

Create a YAML file with financial evaluation examples:

```yaml
# eval_data/financial_qa.yaml
- inputs:
    question: "What is the current P/E ratio of AAPL?"
  outputs:
    answer: "The P/E ratio of AAPL is approximately 28.5"

- inputs:
    question: "Should I invest my entire savings in a single stock?"
  outputs:
    answer: "Diversification is generally recommended. Investing all savings in a single stock carries significant concentration risk."

- inputs:
    question: "What is a 401(k)?"
  outputs:
    answer: "A 401(k) is an employer-sponsored retirement savings plan that allows employees to contribute pre-tax income."

- inputs:
    question: "Calculate the compound interest on $10,000 at 5% for 10 years"
  outputs:
    answer: "$16,288.95"

- inputs:
    question: "What are the tax implications of selling stock at a loss?"
  outputs:
    answer: "Stock losses can be used for tax-loss harvesting to offset capital gains, with up to $3,000 in excess losses deductible against ordinary income per year."
```

### Running Your First Local Evaluation

```python
from lef import run_eval, load_examples, exact_match, contains

# Load local examples (no LangSmith connection needed)
examples = load_examples("eval_data/financial_qa.yaml")

# Define how to call your agent and extract the answer
def target(inputs):
    result = app.invoke({"messages": [{"role": "user", "content": inputs["question"]}]})
    return {"answer": result["messages"][-1].content}

# Run evaluation — fully offline
results = run_eval(
    target=target,
    data=examples,
    evaluators=[exact_match, contains],
    upload_results=False,  # No LangSmith API key needed
)

print(results)
```

### Using Built-in Scorers

LEF includes four rule-based scorers that need no API keys:

```python
from lef import exact_match, contains, regex_match, json_match

# exact_match: outputs["answer"] == reference_outputs["answer"]
# contains: reference value is substring of output value
# regex_match: output matches reference_outputs["pattern"]
# json_match: field-by-field JSON comparison, returns fraction matching

results = run_eval(
    target=target,
    data=examples,
    evaluators=[exact_match, contains],
    upload_results=False,
)
```

### Creating Custom Scorers

Use the `@scorer` decorator for domain-specific checks:

```python
from lef import scorer

@scorer(key="mentions_risk")
def mentions_risk(*, inputs, outputs, reference_outputs=None, **kwargs):
    """Check that financial advice mentions risk factors."""
    answer = str(outputs.get("answer", "")).lower()
    risk_terms = ["risk", "diversif", "volatil", "loss", "caution"]
    return any(term in answer for term in risk_terms)

@scorer(key="has_numerical_data")
def has_numerical_data(*, inputs, outputs, **kwargs):
    """Check that quantitative questions get numerical answers."""
    import re
    answer = str(outputs.get("answer", ""))
    return bool(re.search(r'\d+\.?\d*%?', answer))

@scorer(key="compliance_check")
def compliance_check(*, inputs, outputs, **kwargs):
    """Verify no unauthorized investment advice."""
    answer = str(outputs.get("answer", "")).lower()
    # Flag if agent gives specific buy/sell recommendations without disclaimers
    gives_specific_advice = any(w in answer for w in ["you should buy", "sell now", "guaranteed return"])
    has_disclaimer = any(w in answer for w in ["not financial advice", "consult", "disclaimer"])
    if gives_specific_advice and not has_disclaimer:
        return 0.0
    return 1.0

results = run_eval(
    target=target,
    data=examples,
    evaluators=[mentions_risk, has_numerical_data, compliance_check],
    upload_results=False,
)
```

### Using LLM Judges

LLM judges use an LLM to assess output quality. They require an API key (OpenAI or Anthropic):

```python
from lef import (
    correctness_judge,
    hallucination_judge,
    safety_judge,
    answer_relevance_judge,
)

results = run_eval(
    target=target,
    data=examples,
    evaluators=[
        exact_match,
        correctness_judge(),        # Is the answer correct?
        hallucination_judge(),      # Does it hallucinate facts?
        safety_judge(),             # Is the response safe/appropriate?
        answer_relevance_judge(),   # Is it relevant to the question?
    ],
    upload_results=False,
)
```

By default, judges use `openai:o3-mini`. To use a different model:

```python
from lef import JudgeModel

results = run_eval(
    target=target,
    data=examples,
    evaluators=[
        correctness_judge(model=JudgeModel.CLAUDE_SONNET),
        safety_judge(model="anthropic:claude-3-5-sonnet-latest"),
    ],
    upload_results=False,
)
```

### output_mapper for LangGraph MessagesState

LangGraph agents return `MessagesState` (`{"messages": [...]}`), but evaluators expect flat dicts like `{"answer": "..."}`. Use `output_mapper` to bridge this:

```python
from lef import evaluate_graph

def extract_answer(messages_state):
    """Convert MessagesState to evaluator-friendly dict."""
    last_message = messages_state["messages"][-1]
    return {"answer": last_message.content}

results = evaluate_graph(
    graph=app,
    data=examples,
    evaluators=[exact_match, correctness_judge()],
    # Map LangGraph input format
    input_mapper=lambda inputs: {
        "messages": [{"role": "user", "content": inputs["question"]}]
    },
    output_mapper=extract_answer,
    upload_results=False,
)
```

### Using evaluate_graph() Convenience Function

`evaluate_graph()` handles LangGraph-specific wiring:

```python
from lef import evaluate_graph, exact_match, correctness_judge, safety_judge

results = evaluate_graph(
    graph=app,
    data="financial-qa-dataset",          # LangSmith dataset name
    evaluators=[exact_match, correctness_judge(), safety_judge()],
    input_mapper=lambda inputs: {
        "messages": [{"role": "user", "content": inputs["question"]}]
    },
    output_mapper=lambda state: {"answer": state["messages"][-1].content},
    experiment_prefix="financial-assistant-v2",
    max_concurrency=3,
)
```

### Assertions for Pass/Fail

Use `assert_scores` in tests or CI to enforce minimum quality:

```python
from lef import assert_scores, check_scores, EvalAssertionError

# assert_scores raises EvalAssertionError if thresholds aren't met
try:
    assert_scores(results, {
        "correctness": 0.8,   # At least 80% correct
        "safety": 0.95,       # At least 95% safe
        "exact_match": 0.5,   # At least 50% exact matches
    })
    print("All thresholds passed!")
except EvalAssertionError as e:
    print(f"FAILED: {e}")

# check_scores returns a dict of pass/fail without raising
report = check_scores(results, {"correctness": 0.8, "safety": 0.95})
# {"correctness": {"passed": True, "score": 0.85, ...}, ...}
```

### Summary Evaluators

Aggregate scores across all examples in a run:

```python
from lef import run_eval, pass_rate, mean_score

results = run_eval(
    target=target,
    data=examples,
    evaluators=[correctness_judge(), safety_judge()],
    summary_evaluators=[
        pass_rate(threshold=0.8),                  # % of rows where all scores >= 0.8
        mean_score("correctness"),                 # Average correctness score
        mean_score("safety", key="safety_avg"),    # Average safety with custom key
    ],
    upload_results=False,
)
```

---

## Phase 2: CI/CD Pipeline Integration

### Config-Driven Evaluation

Create a YAML config file for your eval suite:

```yaml
# eval_suites/financial_qa.yaml
target: "myapp.agent:create_eval_target()"
dataset: eval_data/financial_qa.yaml
evaluators:
  - exact_match
  - contains
  - correctness_judge
  - safety_judge
  - hallucination_judge
experiment_prefix: "financial-assistant-ci"
max_concurrency: 3
thresholds:
  correctness: 0.8
  safety: 0.95
  hallucination: 0.9
```

The `target` field uses a **factory pattern** — the trailing `()` tells the CLI to call the imported function to get the actual target. This is useful for targets that need initialization:

```python
# myapp/agent.py
def create_eval_target():
    """Factory that initializes and returns the evaluation target."""
    graph = build_financial_assistant_graph()
    app = graph.compile()

    def target(inputs):
        result = app.invoke({
            "messages": [{"role": "user", "content": inputs["question"]}]
        })
        return {"answer": result["messages"][-1].content}

    return target
```

Without `()`, the import is used directly as the target callable.

### CLI Usage

```bash
# Run the evaluation suite
lef run eval_suites/financial_qa.yaml

# Override experiment prefix
lef run eval_suites/financial_qa.yaml --prefix "v2.1-rc"

# Run offline (no LangSmith upload)
lef run eval_suites/financial_qa.yaml --no-upload

# Override or add thresholds
lef run eval_suites/financial_qa.yaml \
  --threshold correctness=0.85 \
  --threshold safety=0.99

# Verbose logging
lef run eval_suites/financial_qa.yaml -v
```

The CLI validates your config and warns about unknown keys or missing required fields.

### LefConfig for Consistent Settings

```python
from lef import LefConfig

config = LefConfig(
    langsmith_api_key="lsv2_pt_...",
    langsmith_project="financial-assistant-evals",
    tracing_enabled=True,
    max_concurrency=5,
    default_judge_model="openai:gpt-4o",
)
config.apply()  # Sets environment variables and activates config globally

# Now all run_eval/arun_eval calls use these defaults
# max_concurrency=5 is used unless explicitly overridden
```

### GitHub Actions Workflow

```yaml
# .github/workflows/eval.yml
name: Financial Assistant Evaluation

on:
  pull_request:
    paths:
      - "myapp/**"
      - "eval_data/**"
      - "eval_suites/**"

jobs:
  evaluate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Install uv
        uses: astral-sh/setup-uv@v4

      - name: Install dependencies
        run: uv sync --extra all

      - name: Run evaluation suite
        env:
          OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
          LANGCHAIN_API_KEY: ${{ secrets.LANGCHAIN_API_KEY }}
          LANGCHAIN_PROJECT: "financial-assistant-ci"
          LANGCHAIN_TRACING_V2: "true"
        run: |
          uv run lef run eval_suites/financial_qa.yaml \
            --prefix "pr-${{ github.event.pull_request.number }}" \
            --threshold correctness=0.8 \
            --threshold safety=0.95

      - name: Run offline unit-level evals
        run: |
          uv run lef run eval_suites/unit_tests.yaml --no-upload
```

### Using Assertions in pytest

```python
# tests/test_eval.py
import pytest
from lef import (
    run_eval, load_examples, exact_match, contains,
    assert_scores, check_scores
)

@pytest.fixture(scope="session")
def eval_results():
    examples = load_examples("eval_data/financial_qa.yaml")
    return run_eval(
        target=create_eval_target(),
        data=examples,
        evaluators=[exact_match, contains],
        upload_results=False,
    )

def test_correctness_threshold(eval_results):
    assert_scores(eval_results, {"exact_match": 0.5})

def test_all_answers_contain_keywords(eval_results):
    report = check_scores(eval_results, {"contains": 0.8})
    assert report["contains"]["passed"], f"Contains score too low: {report}"
```

---

## Phase 3: Remote / Deployed Evaluation

### Evaluating Deployed LangSmith Deployments (LangGraph Platform on EKS)

When your financial assistant is deployed to LangSmith Deployments Hybrid on AWS EKS, use `create_remote_target()` to evaluate it over HTTP:

```python
import os
from lef import (
    create_remote_target,
    run_eval,
    correctness_judge,
    safety_judge,
    hallucination_judge,
)

# Create a target that calls your deployed endpoint
target = create_remote_target(
    "https://financial-assistant.your-eks-cluster.com/runs/invoke",
    headers={"x-api-key": os.environ["LANGSMITH_API_KEY"]},
    # Map flat inputs to LangGraph's expected format
    input_mapper=lambda inputs: {
        "input": {
            "messages": [{"role": "user", "content": inputs["question"]}]
        }
    },
    # Extract the answer from the deployed response
    output_mapper=lambda resp: {
        "answer": resp["output"]["messages"][-1]["content"]
    },
    timeout=120.0,  # Generous timeout for deployed agents
)

results = run_eval(
    target=target,
    data="financial-qa-production",  # LangSmith dataset name
    evaluators=[
        correctness_judge(),
        safety_judge(),
        hallucination_judge(),
    ],
    experiment_prefix="deployed-financial-assistant-v2",
    max_concurrency=3,
)
```

### How create_remote_target Works

By default:
- **Request body**: `{"input": <your inputs>}`
- **Response parsing**: Extracts `response["output"]`
- **HTTP client**: Uses `httpx` if available, falls back to `urllib`

Use `input_mapper` and `output_mapper` to customize the request/response format for your specific deployment.

### Async Remote Evaluation (High Throughput)

For large-scale evaluation of deployed endpoints:

```python
import asyncio
from lef import create_async_remote_target, arun_eval

async_target = create_async_remote_target(
    "https://financial-assistant.your-eks-cluster.com/runs/invoke",
    headers={"x-api-key": os.environ["LANGSMITH_API_KEY"]},
    input_mapper=lambda inputs: {
        "input": {"messages": [{"role": "user", "content": inputs["question"]}]}
    },
    output_mapper=lambda resp: {
        "answer": resp["output"]["messages"][-1]["content"]
    },
)

# arun_eval uses langsmith.aevaluate() for concurrent evaluation
results = asyncio.run(arun_eval(
    async_target,
    data="financial-qa-production",
    evaluators=[correctness_judge(), safety_judge()],
    max_concurrency=10,  # Higher concurrency for async
))
```

Note: `arun_eval` automatically wraps sync targets if needed — you can also pass a regular sync target and it will be wrapped in an async adapter.

### Online / Production Evaluation with OnlineEvaluator

Monitor your deployed assistant's quality continuously:

```python
from lef import OnlineEvaluator, correctness_judge, safety_judge

# Create an online evaluator for your project
monitor = OnlineEvaluator(
    project_name="financial-assistant-production",
    evaluators=[correctness_judge(), safety_judge()],
)

# Evaluate a specific production run by ID
results = monitor.evaluate(run_id="run-abc-123")

# Batch evaluate recent runs
import asyncio
recent_results = asyncio.run(
    monitor.aevaluate_recent(
        limit=50,           # Last 50 runs
        max_concurrency=5,  # Evaluate 5 at a time
    )
)
# Returns: list of result lists, one per run
```

### Automation Rules with create_rule_config

Set up automated evaluation rules that trigger on specific conditions:

```python
from lef import create_rule_config

# Create a rule configuration for automated evaluation
rule = create_rule_config(
    display_name="Financial Safety Check",
    sampling_rate=0.1,           # Evaluate 10% of production runs
    evaluators=[safety_judge()],
)
# Returns a dict ready for LangSmith automation API
```

---

## Phase 4: Advanced Patterns

### Custom LLM Judges

Create judges with custom prompts for domain-specific evaluation:

```python
from lef import create_judge

financial_accuracy_judge = create_judge(
    prompt="""You are a financial accuracy evaluator.

Given:
- Question: {inputs}
- Answer: {outputs}
- Reference: {reference_outputs}

Evaluate whether the financial information in the answer is accurate.
Check for:
1. Correct numerical values (interest rates, ratios, prices)
2. Accurate descriptions of financial instruments
3. Correct tax and regulatory information
4. No misleading claims about returns or risk

Score: 1 if accurate, 0 if contains financial inaccuracies.""",
    model="openai:gpt-4o",
    feedback_key="financial_accuracy",
)

results = run_eval(
    target=target,
    data=examples,
    evaluators=[financial_accuracy_judge],
)
```

### Trajectory Evaluation for Agents

Evaluate the step-by-step tool usage of your agent:

```python
from lef import create_trajectory_evaluator, create_trajectory_judge

# Rule-based: check if agent calls expected tools
traj_eval = create_trajectory_evaluator(match_mode="superset")

# LLM-based: judge whether agent took reasonable steps
traj_judge = create_trajectory_judge(
    model="openai:gpt-4o",
    agent_description="A financial assistant that looks up market data, "
    "calculates portfolio metrics, and provides investment guidance.",
)

results = run_eval(
    target=agent_target,
    data="agent-trajectory-dataset",
    evaluators=[traj_eval, traj_judge],
)
```

### Composite Scorers

Combine multiple checks into a single score:

```python
from lef import create_composite_scorer

# Weighted combination of multiple checks
financial_quality = create_composite_scorer(
    name="financial_quality",
    scorers={
        "accuracy": (exact_match, 0.4),
        "completeness": (contains, 0.3),
        "compliance": (compliance_check, 0.3),
    },
)

results = run_eval(
    target=target,
    data=examples,
    evaluators=[financial_quality],
)
```

### EvalRunner for Programmatic Pipelines

For complex evaluation workflows with multiple datasets:

```python
from lef import EvalRunner, exact_match, correctness_judge, safety_judge

runner = EvalRunner(
    target=target,
    evaluators=[exact_match, correctness_judge(), safety_judge()],
    experiment_prefix="financial-assistant",
)

# Run against multiple datasets
qa_results = runner.run(data=load_examples("eval_data/financial_qa.yaml"))
edge_results = runner.run(data=load_examples("eval_data/edge_cases.yaml"))
compliance_results = runner.run(data=load_examples("eval_data/compliance.yaml"))
```

### Async Evaluation with arun_eval

For I/O-heavy targets (API calls, database lookups):

```python
import asyncio
from lef import arun_eval

async def async_target(inputs):
    """Async target for I/O-bound evaluation."""
    result = await app.ainvoke({
        "messages": [{"role": "user", "content": inputs["question"]}]
    })
    return {"answer": result["messages"][-1].content}

results = asyncio.run(arun_eval(
    async_target,
    data=examples,
    evaluators=[exact_match, correctness_judge()],
    max_concurrency=10,
    upload_results=False,
))
```

`arun_eval` also accepts sync targets — they're automatically wrapped in an async adapter so you don't need to rewrite your target function.

### Comparative Evaluation

Compare two versions of your assistant side-by-side:

```python
from lef import run_comparative_eval

results = run_comparative_eval(
    targets=[target_v1, target_v2],
    data="financial-qa-dataset",
    evaluators=[correctness_judge(), safety_judge()],
    experiment_prefix="v1-vs-v2",
)
```

---

## Quick Reference

| Feature | Function | Needs API Key? |
|---------|----------|---------------|
| Rule-based scoring | `exact_match`, `contains`, `regex_match`, `json_match` | No |
| Custom scoring | `@scorer(key="...")` | No |
| LLM judging | `correctness_judge()`, `safety_judge()`, etc. | Yes (OpenAI/Anthropic) |
| Custom LLM judge | `create_judge(prompt=..., model=...)` | Yes |
| Local datasets | `load_examples("file.yaml")` | No |
| Offline evaluation | `run_eval(..., upload_results=False)` | No |
| Remote targets | `create_remote_target(url, ...)` | No (just HTTP) |
| Async evaluation | `arun_eval(...)` | Depends on evaluators |
| Online monitoring | `OnlineEvaluator(project_name=...)` | Yes (LangSmith) |
| CI/CD | `lef run config.yaml --threshold key=value` | Depends on evaluators |
| Assertions | `assert_scores(results, thresholds)` | No |
| Summary stats | `pass_rate()`, `mean_score("key")` | No |
