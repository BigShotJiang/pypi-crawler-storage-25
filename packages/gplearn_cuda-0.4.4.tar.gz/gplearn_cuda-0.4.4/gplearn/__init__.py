"""gplearn-CUDA: GPU-accelerated Genetic Programming in Python.

This project is a high-performance CUDA extension of the original ``gplearn`` 
library by Trevor Stephens.

"""
__version__ = '0.4.4'

__all__ = ['genetic', 'functions', 'fitness']

from ._program import clear_kernel_cache
