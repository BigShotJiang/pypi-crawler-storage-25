# MyLang Compiler

> A statically-typed programming language that compiles to Python — built from scratch in Python with zero dependencies.

## Install

```bash
pip install mylang-compiler
```

## Quick Start

Create a file `hello.myl`:

```
program HelloWorld
  let name: text = "World"
  print "Hello, " + name + "!"
endprogram
```

Compile and run:

```bash
mylang hello.myl
```

Output:
```
Hello, World!
```

## CLI Flags

```bash
mylang hello.myl                  # compile + run (clean output)
mylang hello.myl --phases         # show all 7 compiler phases
mylang hello.myl --show-tokens    # Phase 1: token stream
mylang hello.myl --show-ast       # Phase 2: Abstract Syntax Tree
mylang hello.myl --show-symbols   # Phase 3: symbol table
mylang hello.myl --show-tac       # Phase 4: Three Address Code
mylang hello.myl --show-python    # Phase 5: generated Python source
mylang hello.myl --compile-only   # compile only, don't execute
```

## Bundled Examples

After installing, run any example:

```bash
python -c "import os, mylang; print(os.path.dirname(mylang.__file__))"
```

Copy that path and run:

```bash
mylang <path>\examples\01_hello.myl
mylang <path>\examples\02_control_flow.myl --phases
mylang <path>\examples\03_functions.myl
mylang <path>\examples\05_showcase.myl
mylang <path>\examples\new_features.myl
```

## The 7 Compiler Phases

```
Source (.myl)
    │
    ▼  Phase 1 — Lexical Analysis     tokens from raw text
    ▼  Phase 2 — Syntax Analysis      Abstract Syntax Tree
    ▼  Phase 3 — Semantic Analysis    type & scope checking
    ▼  Phase 4 — Intermediate Rep.    Three Address Code
    ▼  Phase 5 — Code Generation      emit Python source
    ▼  Phase 6 — Optimisation         constant folding, dead code
    ▼  Phase 7 — Execute              run via Python runtime
```

## Language Features

| Feature | Syntax |
|---|---|
| Variable | `let age: num = 25` |
| Function | `fun add(a: num, b: num) as num` |
| If / else | `if x > 0 then ... else ... endif` |
| For loop | `for i from 1 to 10 step 1` |
| While | `while x > 0 begin ... end` |
| Repeat N | `repeat 5 times begin ... end` |
| Do-while | `do ... while cond enddo` |
| Switch | `switch x begin case 1: ... endswitch` |
| Struct | `struct Point begin x: num endstruct` |
| Pointer | `let p: ptr = &x` then `*p = 10` |
| Type check | `type(expression)` |
| Debug step | `thinkstep expression` |

## Run Without Installing

```bash
python -m mylang hello.myl
```

## Built For

Compiler Design coursework. All 7 phases are in separate, self-contained files under `mylang/`.
36/36 tests passing across all phases.
