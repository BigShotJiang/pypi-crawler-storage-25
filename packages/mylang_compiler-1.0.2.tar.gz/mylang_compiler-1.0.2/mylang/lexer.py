"""
MyLang Compiler — Phase 1: Lexical Analyser (Lexer)
====================================================
Converts raw source code text into a stream of tokens.
Each token is a (type, value, line_number) triple.

Token types:
  Keywords    : program, endprogram, let, be, as, if, then, else, endif,
                repeat, times, begin, end, fun, endfun, return,
                print, input, and, or, not, true, false
  Types       : num, text, bool, decimal
  Literals    : NUMBER, DECIMAL, STRING, BOOLEAN
  Identifiers : NAME
  Operators   : PLUS, MINUS, STAR, SLASH, MOD, POWER
  Comparison  : EQ, NEQ, LT, GT, LTE, GTE
  Assignment  : ASSIGN (=)
  Punctuation : LPAREN, RPAREN, LBRACKET, RBRACKET, COMMA, COLON, DOT
  Special     : NEWLINE, EOF
"""

import re
from dataclasses import dataclass
from typing import List, Optional


# ─────────────────────────────────────────────
#  Token definition
# ─────────────────────────────────────────────

@dataclass
class Token:
    type: str
    value: str
    line: int

    def __repr__(self):
        return f"Token({self.type}, {self.value!r}, line={self.line})"


# ─────────────────────────────────────────────
#  All reserved keywords of MyLang
# ─────────────────────────────────────────────

KEYWORDS = {
    # Program structure
    "program", "endprogram",
    # Variables
    "let", "be", "as",
    # Types
    "num", "text", "bool", "decimal",
    # Conditionals
    "if", "then", "else", "endif",
    # Loops
    "repeat", "times", "while", "do", "endwhile", "enddo", "for", "from", "to", "step", "endfor",
    # Switch-case
    "switch", "case", "default", "endswitch",
    # Structs
    "struct", "endstruct",
    # Functions
    "fun", "endfun", "return", "call",
    # Types and Pointers
    "num", "text", "bool", "decimal", "ptr", "type", "list",
    # I/O
    "print", "input",
    # Boolean logic
    "and", "or", "not",
    # Boolean literals
    "true", "false",
    # Block delimiters
    "begin", "end",
}

# ─────────────────────────────────────────────
#  Token patterns (ordered — first match wins)
# ─────────────────────────────────────────────

TOKEN_PATTERNS = [
    # Whitespace (skip — but track newlines separately)
    ("NEWLINE",    r"\n"),
    ("SKIP",       r"[ \t\r]+"),
    # Comments  ## this is a comment
    ("COMMENT",    r"##[^\n]*"),
    # Decimal before int (order matters)
    ("DECIMAL",    r"\d+\.\d+"),
    ("NUMBER",     r"\d+"),
    # String literals  "hello"
    ("STRING",     r'"[^"]*"'),
    # Operators
    ("POWER",      r"\*\*"),
    ("PLUS",       r"\+"),
    ("MINUS",      r"-"),
    ("STAR",       r"\*"),
    ("SLASH",      r"/"),
    ("MOD",        r"%"),
    # Comparison (two-char before one-char)
    ("NEQ",        r"!="),
    ("LTE",        r"<="),
    ("GTE",        r">="),
    ("EQ",         r"=="),
    ("LT",         r"<"),
    ("GT",         r">"),
    # Assignment
    ("ASSIGN",     r"="),
    # Punctuation
    ("LPAREN",     r"\("),
    ("RPAREN",     r"\)"),
    ("LBRACKET",   r"\["),
    ("RBRACKET",   r"\]"),
    ("COMMA",      r","),
    ("COLON",      r":"),
    ("DOT",        r"\."),
    ("ADDR",       r"&"),
    ("ARROW",      r"->"),
    # Identifiers and keywords
    ("NAME",       r"[A-Za-z_][A-Za-z0-9_]*"),
]

MASTER_PATTERN = re.compile(
    "|".join(f"(?P<{name}>{pat})" for name, pat in TOKEN_PATTERNS)
)


# ─────────────────────────────────────────────
#  LexerError
# ─────────────────────────────────────────────

class LexerError(Exception):
    def __init__(self, message: str, line: int):
        super().__init__(f"[Lexer Error] Line {line}: {message}")
        self.line = line


# ─────────────────────────────────────────────
#  Lexer class
# ─────────────────────────────────────────────

class Lexer:
    """
    Tokenises a MyLang source string.

    Usage:
        lexer = Lexer(source_code)
        tokens = lexer.tokenise()
    """

    def __init__(self, source: str):
        self.source = source
        self.line = 1

    def tokenise(self) -> List[Token]:
        tokens: List[Token] = []

        for match in MASTER_PATTERN.finditer(self.source):
            kind = match.lastgroup
            value = match.group()

            if kind == "SKIP" or kind == "COMMENT":
                continue
            elif kind == "NEWLINE":
                self.line += 1
                # Emit NEWLINE only when it would follow a meaningful token
                if tokens and tokens[-1].type not in ("NEWLINE",):
                    tokens.append(Token("NEWLINE", "\\n", self.line - 1))
            elif kind == "NAME":
                # Promote to KEYWORD if in reserved set
                if value.lower() in KEYWORDS:
                    tokens.append(Token(value.upper(), value, self.line))
                else:
                    tokens.append(Token("NAME", value, self.line))
            elif kind == "STRING":
                # Strip surrounding quotes
                tokens.append(Token("STRING", value[1:-1], self.line))
            elif kind == "DECIMAL":
                tokens.append(Token("DECIMAL", value, self.line))
            elif kind == "NUMBER":
                tokens.append(Token("NUMBER", value, self.line))
            else:
                tokens.append(Token(kind, value, self.line))

        # Check for any characters that didn't match anything
        matched_chars = sum(len(m.group()) for m in MASTER_PATTERN.finditer(self.source))
        if matched_chars < len(self.source):
            raise LexerError("Unexpected character in source code.", self.line)

        tokens.append(Token("EOF", "", self.line))
        return tokens


# ─────────────────────────────────────────────
#  Pretty-print helper (for debugging/demo)
# ─────────────────────────────────────────────

def print_tokens(tokens: List[Token]):
    print(f"\n{'─'*50}")
    print(f"  {'TOKEN TYPE':<20} {'VALUE':<20} LINE")
    print(f"{'─'*50}")
    for tok in tokens:
        if tok.type == "NEWLINE":
            continue
        print(f"  {tok.type:<20} {repr(tok.value):<20} {tok.line}")
    print(f"{'─'*50}\n")
