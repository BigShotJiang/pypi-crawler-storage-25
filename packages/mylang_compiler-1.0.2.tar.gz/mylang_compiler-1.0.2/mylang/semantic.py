"""
MyLang Compiler — Phase 3: Semantic Analyser
=============================================
Walks the AST and enforces:
  1. Variables must be declared before use (scope checking)
  2. Type compatibility in assignments and operations
  3. Functions must be declared before call (forward decl allowed via 2-pass)
  4. Return type matching
  5. No re-declaration of the same variable in the same scope

Implements the GLAP model's Symbol Table as a scoped stack,
as referenced in the IJIRT research paper.

Symbol table entry:
  { name: str, kind: 'var'|'fun', type: str, params: [...], line: int }
"""

from typing import Dict, List, Optional
from ast_nodes import *


# ─────────────────────────────────────────────
#  Symbol Table (stack-based scoped table)
# ─────────────────────────────────────────────

class SymbolTable:
    """
    A stack of scopes.
    Push a new scope on function/block entry.
    Pop it on exit.
    Lookup walks from inner to outer.
    """

    def __init__(self):
        # Each scope is a dict: name -> symbol_record
        self.scopes: List[Dict[str, dict]] = [{}]  # global scope

    def push_scope(self):
        self.scopes.append({})

    def pop_scope(self):
        if len(self.scopes) > 1:
            self.scopes.pop()

    def declare(self, name: str, kind: str, sym_type: str,
                params=None, line: int = 0):
        current = self.scopes[-1]
        if name in current:
            raise SemanticError(
                f"'{name}' is already declared in this scope.", line
            )
        current[name] = {
            "name": name,
            "kind": kind,
            "type": sym_type,
            "params": params or [],
            "line": line,
        }

    def lookup(self, name: str) -> Optional[dict]:
        for scope in reversed(self.scopes):
            if name in scope:
                return scope[name]
        return None

    def lookup_required(self, name: str, line: int) -> dict:
        sym = self.lookup(name)
        if sym is None:
            raise SemanticError(f"'{name}' is not declared.", line)
        return sym

    def dump(self):
        # Collect all symbols across scopes
        rows = []
        for i, scope in enumerate(self.scopes):
            scope_label = "global" if i == 0 else f"scope {i}"
            for sym in scope.values():
                params = ", ".join(
                    p["name"] + ":" + p["type"] for p in sym.get("params", [])
                )
                rows.append((sym["name"], sym["kind"], sym["type"], params, str(sym["line"]), scope_label))

        # Column widths
        headers = ("Name", "Kind", "Type", "Params", "Line", "Scope")
        col_w = [len(h) for h in headers]
        for row in rows:
            for i, cell in enumerate(row):
                col_w[i] = max(col_w[i], len(cell))

        sep   = "+-" + "-+-".join("-" * w for w in col_w) + "-+"
        hdr   = "| " + " | ".join(h.ljust(col_w[i]) for i, h in enumerate(headers)) + " |"

        print("\n" + sep)
        print(hdr)
        print(sep)
        for row in rows:
            print("| " + " | ".join(cell.ljust(col_w[i]) for i, cell in enumerate(row)) + " |")
        print(sep + "\n")


# ─────────────────────────────────────────────
#  SemanticError
# ─────────────────────────────────────────────

class SemanticError(Exception):
    def __init__(self, message: str, line: int = 0):
        super().__init__(f"[Semantic Error] Line {line}: {message}")
        self.line = line


# ─────────────────────────────────────────────
#  Type compatibility rules
# ─────────────────────────────────────────────

NUMERIC_TYPES = {"num", "decimal"}

def types_compatible(t1: str, t2: str) -> bool:
    """Are t1 and t2 compatible for assignment/operation?"""
    if t1 == t2:
        return True
    # num and decimal are interchangeable
    if t1 in NUMERIC_TYPES and t2 in NUMERIC_TYPES:
        return True
    # struct types (lenient check)
    if t1 == "struct" or t2 == "struct":
        return True
    return False

def result_type(op: str, t1: str, t2: str) -> str:
    """What type does a binary op on t1 and t2 produce?"""
    if op == ".":
        return "unknown" # Member access
    if op == "=":
        return t2 # Assignment result is the value type
    if op in ("+", "-", "*", "/", "**", "%"):
        if t1 in NUMERIC_TYPES and t2 in NUMERIC_TYPES:
            return "decimal" if "decimal" in (t1, t2) else "num"
        # text + anything  or  anything + text  → text  (auto str() convert in codegen)
        if op == "+" and (t1 == "text" or t2 == "text"):
            return "text"
    if op in ("==", "!=", "<", ">", "<=", ">="):
        return "bool"
    if op in ("and", "or"):
        return "bool"
    return "unknown"


# ─────────────────────────────────────────────
#  Semantic Analyser
# ─────────────────────────────────────────────

class SemanticAnalyser:
    """
    Walks the AST, populates the symbol table,
    and raises SemanticError on any violation.

    Usage:
        analyser = SemanticAnalyser()
        analyser.analyse(ast)
        analyser.symbol_table.dump()
    """

    def __init__(self):
        self.symbol_table = SymbolTable()
        self.current_function_return_type: Optional[str] = None
        self.errors: List[str] = []

    def analyse(self, node: ASTNode):
        self._visit(node)

    # ─────────────────────────────────────────
    #  Visitor dispatch
    # ─────────────────────────────────────────

    def _visit(self, node: ASTNode) -> Optional[str]:
        """Visit a node and return its type (for expressions)."""
        method = f"_visit_{node.__class__.__name__}"
        visitor = getattr(self, method, self._generic_visit)
        return visitor(node)

    def _generic_visit(self, node: ASTNode):
        # Visit children generically
        for val in node.__dict__.values():
            if isinstance(val, ASTNode):
                self._visit(val)
            elif isinstance(val, list):
                for item in val:
                    if isinstance(item, ASTNode):
                        self._visit(item)

    # ─────────────────────────────────────────
    #  Program
    # ─────────────────────────────────────────

    def _visit_ProgramNode(self, node: ProgramNode):
        # First pass: register all function definitions (so they can call each other)
        for stmt in node.body:
            if isinstance(stmt, FunctionDef):
                params_info = [{"name": p.name, "type": p.param_type} for p in stmt.params]
                self.symbol_table.declare(
                    stmt.name, "fun", stmt.return_type or "void",
                    params=params_info, line=stmt.line
                )
        # Second pass: fully analyse everything
        for stmt in node.body:
            self._visit(stmt)

    # ─────────────────────────────────────────
    #  Declarations
    # ─────────────────────────────────────────

    def _visit_VarDecl(self, node: VarDecl):
        val_type = self._visit(node.value)
        # Allow input() to assign any type
        if val_type and val_type != "unknown":
            if not types_compatible(node.var_type, val_type):
                raise SemanticError(
                    f"Type mismatch: cannot assign '{val_type}' to variable of type '{node.var_type}'.",
                    node.line
                )
        self.symbol_table.declare(node.name, "var", node.var_type, line=node.line)

    def _visit_Assign(self, node: Assign):
        sym = self.symbol_table.lookup_required(node.name, node.line)
        if sym["kind"] != "var":
            raise SemanticError(f"'{node.name}' is a function, not a variable.", node.line)
        val_type = self._visit(node.value)
        if val_type and val_type != "unknown":
            if not types_compatible(sym["type"], val_type):
                raise SemanticError(
                    f"Type mismatch: cannot assign '{val_type}' to '{node.name}' (type '{sym['type']}').",
                    node.line
                )

    # ─────────────────────────────────────────
    #  Expressions
    # ─────────────────────────────────────────

    def _visit_NumberLiteral(self, node) -> str:
        return "num"

    def _visit_DecimalLiteral(self, node) -> str:
        return "decimal"

    def _visit_StringLiteral(self, node) -> str:
        return "text"

    def _visit_BoolLiteral(self, node) -> str:
        return "bool"

    def _visit_Identifier(self, node: Identifier) -> str:
        sym = self.symbol_table.lookup_required(node.name, node.line)
        return sym["type"]

    def _visit_BinaryOp(self, node: BinaryOp) -> str:
        t1 = self._visit(node.left)
        t2 = self._visit(node.right)
        res = result_type(node.op, t1, t2)
        if res == "unknown" and node.op not in (".", "="):
             # Only throw if it's a numeric op on non-numeric types
             if node.op in ("+", "-", "*", "/", "%", "**"):
                 raise SemanticError(f"Operator '{node.op}' cannot be applied to types '{t1}' and '{t2}'.", node.line)
        return res

    def _visit_UnaryOp(self, node: UnaryOp) -> str:
        t = self._visit(node.operand)
        if node.op == "not":
            if t != "bool":
                raise SemanticError(f"'not' requires a bool, got '{t}'.", node.line)
            return "bool"
        if node.op == "-":
            if t not in NUMERIC_TYPES:
                raise SemanticError(f"Unary '-' requires a num or decimal, got '{t}'.", node.line)
            return t
        return "unknown"

    def _visit_FunctionCall(self, node: FunctionCall) -> str:
        sym = self.symbol_table.lookup_required(node.name, node.line)
        if sym["kind"] not in ("fun", "struct"):
            raise SemanticError(f"'{node.name}' is not callable.", node.line)

        # Check args...
        for arg in node.args:
            self._visit(arg)

        return sym["type"]

    def _visit_ListLiteral(self, node: ListLiteral) -> str:
        for el in node.elements:
            self._visit(el)
        return "list"

    def _visit_IndexAccess(self, node: IndexAccess) -> str:
        self._visit(node.target)
        idx_type = self._visit(node.index)
        if idx_type != "num":
            raise SemanticError("List index must be of type 'num'.", node.line)
        return "unknown"

    # ─────────────────────────────────────────
    #  Statements
    # ─────────────────────────────────────────

    def _visit_PrintStmt(self, node: PrintStmt):
        self._visit(node.value)

    def _visit_PointerAssign(self, node: PointerAssign):
        # Verify the pointer variable is declared
        self.symbol_table.lookup_required(node.target, node.line)
        self._visit(node.value)

    def _visit_InputStmt(self, node: InputStmt) -> str:
        return "unknown"  # input returns whatever the user types

    def _visit_ReturnStmt(self, node: ReturnStmt):
        if node.value:
            ret_type = self._visit(node.value)
            if self.current_function_return_type and ret_type:
                if not types_compatible(self.current_function_return_type, ret_type):
                    raise SemanticError(
                        f"Return type mismatch: function expects '{self.current_function_return_type}', got '{ret_type}'.",
                        node.line
                    )

    # ─────────────────────────────────────────
    #  Control flow
    # ─────────────────────────────────────────

    def _visit_IfStmt(self, node: IfStmt):
        cond_type = self._visit(node.condition)
        if cond_type and cond_type != "bool" and cond_type != "unknown":
            raise SemanticError(
                f"If condition must be bool, got '{cond_type}'.", node.line
            )
        self.symbol_table.push_scope()
        for stmt in node.then_body:
            self._visit(stmt)
        self.symbol_table.pop_scope()

        if node.else_body:
            self.symbol_table.push_scope()
            for stmt in node.else_body:
                self._visit(stmt)
            self.symbol_table.pop_scope()

    def _visit_RepeatStmt(self, node: RepeatStmt):
        count_type = self._visit(node.count)
        if count_type and count_type not in NUMERIC_TYPES:
            raise SemanticError(f"Repeat count must be a number, got '{count_type}'.", node.line)
        self.symbol_table.push_scope()
        for stmt in node.body:
            self._visit(stmt)
        self.symbol_table.pop_scope()

    def _visit_WhileStmt(self, node: WhileStmt):
        self._visit(node.condition)
        self.symbol_table.push_scope()
        for stmt in node.body: self._visit(stmt)
        self.symbol_table.pop_scope()

    def _visit_DoWhileStmt(self, node: DoWhileStmt):
        self.symbol_table.push_scope()
        for stmt in node.body: self._visit(stmt)
        self.symbol_table.pop_scope()
        self._visit(node.condition)

    def _visit_SwitchStmt(self, node: SwitchStmt):
        self._visit(node.expression)
        for case in node.cases:
            self.symbol_table.push_scope()
            if case.value: self._visit(case.value)
            for stmt in case.body: self._visit(stmt)
            self.symbol_table.pop_scope()

    def _visit_StructDef(self, node: StructDef):
        # Register struct type
        self.symbol_table.declare(node.name, "struct", "struct", line=node.line)

    def _visit_TypeCheck(self, node: TypeCheck) -> str:
        self._visit(node.expression)
        return "text"

    def _visit_AddressOf(self, node: AddressOf) -> str:
        self.symbol_table.lookup_required(node.target, node.line)
        return "ptr"

    def _visit_Dereference(self, node: Dereference) -> str:
        self._visit(node.target)
        return "unknown"  # Hard to determine without full type system

    def _visit_IndexAccess(self, node: IndexAccess) -> str:
        self._visit(node.target)
        self._visit(node.index)
        return "unknown"

    def _visit_ListLiteral(self, node: ListLiteral) -> str:
        for el in node.elements: self._visit(el)
        return "list"

    def _visit_ForStmt(self, node: ForStmt):
        self.symbol_table.push_scope()
        self.symbol_table.declare(node.var, "var", "num", line=node.line)
        self._visit(node.start)
        self._visit(node.end)
        self._visit(node.step)
        for stmt in node.body:
            self._visit(stmt)
        self.symbol_table.pop_scope()

    # ─────────────────────────────────────────
    #  Functions
    # ─────────────────────────────────────────

    def _visit_FunctionDef(self, node: FunctionDef):
        # Symbol already registered in first pass of ProgramNode
        prev_return_type = self.current_function_return_type
        self.current_function_return_type = node.return_type

        self.symbol_table.push_scope()
        for param in node.params:
            self.symbol_table.declare(param.name, "var", param.param_type, line=param.line)
        for stmt in node.body:
            self._visit(stmt)
        self.symbol_table.pop_scope()

        self.current_function_return_type = prev_return_type
