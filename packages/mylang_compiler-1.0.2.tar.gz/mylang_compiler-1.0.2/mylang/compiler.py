"""
MyLang Compiler — Main Entry Point
====================================
Orchestrates all 6 phases of compilation:

  Phase 1: Lexical Analysis    (lexer.py)
  Phase 2: Syntax Analysis     (parser.py)
  Phase 3: Semantic Analysis   (semantic.py)
  Phase 4: IR / Code Gen       (codegen.py)
  Phase 5: Optimisation        (built into codegen.py)
  Phase 6: Output & Execution  (this file)

Usage:
  python compiler.py <source.myl>            # compile and run (output only)
  python compiler.py <source.myl> --phases   # show all compiler phases
  python compiler.py <source.myl> --show-tokens
  python compiler.py <source.myl> --show-ast
  python compiler.py <source.myl> --show-symbols
  python compiler.py <source.myl> --show-tac
  python compiler.py <source.myl> --show-python
  python compiler.py <source.myl> --compile-only
"""

import sys
import os
import subprocess
import argparse

sys.path.insert(0, os.path.dirname(__file__))

from lexer import Lexer, LexerError, print_tokens
from parser import Parser, ParseError
from semantic import SemanticAnalyser, SemanticError
from codegen import CodeGenerator
from ast_nodes import print_ast
from tac import TACGenerator


class C:
    RESET  = "\033[0m"
    BOLD   = "\033[1m"
    RED    = "\033[91m"
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    BLUE   = "\033[94m"
    CYAN   = "\033[96m"
    GRAY   = "\033[90m"


def banner(title: str):
    print(f"\n{C.CYAN}{C.BOLD}{'─'*55}")
    print(f"  {title}")
    print(f"{'─'*55}{C.RESET}")


def phase_ok(n: int, name: str):
    print(f"{C.GREEN}  ✓ Phase {n} — {name}{C.RESET}")


def phase_err(n: int, name: str, msg: str):
    print(f"{C.RED}  ✗ Phase {n} — {name}{C.RESET}")
    print(f"{C.RED}    {msg}{C.RESET}")


def compile_source(source: str, filename: str, args) -> str:
    verbose = args.phases or any([
        args.show_tokens, args.show_ast,
        args.show_symbols, args.show_tac, args.show_python
    ])

    if verbose:
        banner(f"MyLang Compiler  ▸  {filename}")

    # Phase 1
    try:
        lexer = Lexer(source)
        tokens = lexer.tokenise()
        if verbose: phase_ok(1, "Lexical Analysis")
        if args.show_tokens or args.phases:
            print_tokens(tokens)
    except LexerError as e:
        phase_err(1, "Lexical Analysis", str(e))
        sys.exit(1)

    # Phase 2
    try:
        parser = Parser(tokens)
        ast = parser.parse()
        if verbose: phase_ok(2, "Syntax Analysis (Parser)")
        if args.show_ast or args.phases:
            banner("Abstract Syntax Tree")
            print_ast(ast)
    except ParseError as e:
        phase_err(2, "Syntax Analysis (Parser)", str(e))
        sys.exit(1)

    # Phase 3
    try:
        analyser = SemanticAnalyser()
        analyser.analyse(ast)
        if verbose: phase_ok(3, "Semantic Analysis")
        if args.show_symbols or args.phases:
            analyser.symbol_table.dump()
    except SemanticError as e:
        phase_err(3, "Semantic Analysis", str(e))
        sys.exit(1)

    # Phase 4
    try:
        tac_gen = TACGenerator()
        tac_gen.generate(ast)
        if verbose: phase_ok(4, "Intermediate Representation (TAC)")
        if args.show_tac or args.phases:
            tac_gen.dump()
    except Exception as e:
        phase_err(4, "TAC Generation", str(e))
        sys.exit(1)

    # Phase 5+6
    try:
        gen = CodeGenerator()
        python_code = gen.generate(ast)
        if verbose: phase_ok(5, "Code Generation")
        if verbose: phase_ok(6, "Optimisation (constant folding, dead code)")
        if args.show_python or args.phases:
            banner("Generated Python Code")
            for i, line in enumerate(python_code.split("\n"), 1):
                print(f"  {C.GRAY}{i:3}{C.RESET}  {line}")
    except Exception as e:
        phase_err(5, "Code Generation", str(e))
        sys.exit(1)

    return python_code


def run_compiler(args):
    source_path = args.source

    if not os.path.exists(source_path):
        print(f"{C.RED}Error: File not found: {source_path}{C.RESET}")
        sys.exit(1)

    with open(source_path, "r", encoding="utf-8") as f:
        source = f.read()

    python_code = compile_source(source, os.path.basename(source_path), args)

    out_path = source_path.replace(".myl", ".py")
    if not source_path.endswith(".myl"):
        out_path = source_path + ".py"

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(python_code)

    verbose = args.phases or any([
        args.show_tokens, args.show_ast,
        args.show_symbols, args.show_tac, args.show_python
    ])
    if verbose:
        phase_ok(7, f"Output written → {out_path}")

    if args.compile_only:
        if verbose:
            print(f"\n{C.YELLOW}Compile-only mode: not executing.{C.RESET}\n")
        return

    if verbose:
        banner("Program Output")

    out_abs = os.path.abspath(out_path)
    result = subprocess.run(
        [sys.executable, os.path.basename(out_abs)],
        capture_output=False,
        cwd=os.path.dirname(out_abs)
    )

    if result.returncode != 0:
        print(f"\n{C.RED}Program exited with error code {result.returncode}{C.RESET}")


def main():
    p = argparse.ArgumentParser(
        description="MyLang Compiler — transpiles .myl files to Python",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    p.add_argument("source", help="Path to .myl source file")

    p.add_argument("--phases",       action="store_true", help="Show all compiler phases (tokens, AST, symbols, TAC, python)")
    p.add_argument("--show-tokens",  action="store_true", dest="show_tokens",  help="Show the token stream")
    p.add_argument("--show-ast",     action="store_true", dest="show_ast",     help="Show the Abstract Syntax Tree")
    p.add_argument("--show-symbols", action="store_true", dest="show_symbols", help="Show the Symbol Table")
    p.add_argument("--show-tac",     action="store_true", dest="show_tac",     help="Show the Three Address Code")
    p.add_argument("--show-python",  action="store_true", dest="show_python",  help="Show the generated Python code")
    p.add_argument("--compile-only", action="store_true", help="Compile but do not execute")

    args = p.parse_args()
    run_compiler(args)


if __name__ == "__main__":
    main()
