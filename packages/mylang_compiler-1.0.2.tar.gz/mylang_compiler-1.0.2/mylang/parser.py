"""
MyLang Compiler — Phase 2: Syntax Analyser (Parser)
====================================================
Implements a hand-written Recursive Descent Parser.
Takes the token list from the Lexer and builds an AST.

Grammar summary (BNF):
  program        ::= 'program' NAME NEWLINE stmt* 'endprogram'
  stmt           ::= var_decl | assign | if_stmt | repeat_stmt |
                     while_stmt | for_stmt | fun_def | return_stmt |
                     print_stmt | call_stmt | NEWLINE
  var_decl       ::= 'let' NAME ':' TYPE '=' expr
  assign         ::= NAME '=' expr
  if_stmt        ::= 'if' expr 'then' NEWLINE stmt* ('else' NEWLINE stmt*)? 'endif'
  repeat_stmt    ::= 'repeat' expr 'times' 'begin' NEWLINE stmt* 'end'
  while_stmt     ::= 'while' expr 'do' NEWLINE stmt* 'endwhile'
  for_stmt       ::= 'for' NAME 'from' expr 'to' expr ('step' expr)? NEWLINE stmt* 'endfor'
  fun_def        ::= 'fun' NAME '(' params ')' ('as' TYPE)? NEWLINE stmt* 'endfun'
  print_stmt     ::= 'print' expr
  call_stmt      ::= 'call' NAME '(' args ')'
  expr           ::= or_expr
  or_expr        ::= and_expr ('or' and_expr)*
  and_expr       ::= not_expr ('and' not_expr)*
  not_expr       ::= 'not' not_expr | comparison
  comparison     ::= addition (('==' | '!=' | '<' | '>' | '<=' | '>=') addition)?
  addition       ::= term (('+' | '-') term)*
  term           ::= power (('*' | '/' | '%') power)*
  power          ::= unary ('**' unary)*
  unary          ::= '-' unary | primary
  primary        ::= NUMBER | DECIMAL | STRING | 'true' | 'false' |
                     NAME('[' expr ']')? | NAME'('args')' | '(' expr ')' | list_lit
"""

from typing import List, Optional
from lexer import Token, LexerError
from ast_nodes import *


class ParseError(Exception):
    def __init__(self, message: str, line: int):
        super().__init__(f"[Parser Error] Line {line}: {message}")
        self.line = line


class Parser:
    """
    Recursive descent parser for MyLang.

    Usage:
        parser = Parser(tokens)
        ast = parser.parse()
    """

    def __init__(self, tokens: List[Token]):
        # Filter out NEWLINEs from between statements — we track position by token type
        self.tokens = tokens
        self.pos = 0

    # ─────────────────────────────────────────
    #  Utility methods
    # ─────────────────────────────────────────

    def current(self) -> Token:
        return self.tokens[self.pos]

    def peek(self, offset=1) -> Token:
        idx = self.pos + offset
        if idx < len(self.tokens):
            return self.tokens[idx]
        return self.tokens[-1]  # EOF

    def advance(self) -> Token:
        tok = self.tokens[self.pos]
        self.pos += 1
        return tok

    def skip_newlines(self):
        while self.current().type == "NEWLINE":
            self.advance()

    def expect(self, *types) -> Token:
        self.skip_newlines()
        tok = self.current()
        if tok.type not in types:
            expected = " or ".join(types)
            raise ParseError(
                f"Expected {expected}, got {tok.type!r} ({tok.value!r})",
                tok.line
            )
        return self.advance()

    def match(self, *types) -> bool:
        self.skip_newlines()
        return self.current().type in types

    def match_inline(self, *types) -> bool:
        """Match without skipping newlines — used inside expression chains
        so that operators on the next line are not accidentally consumed."""
        return self.current().type in types

    def optional(self, *types) -> Optional[Token]:
        self.skip_newlines()
        if self.current().type in types:
            return self.advance()
        return None

    # ─────────────────────────────────────────
    #  Entry point
    # ─────────────────────────────────────────

    def parse(self) -> ProgramNode:
        self.skip_newlines()
        self.expect("PROGRAM")
        name_tok = self.expect("NAME")
        name = name_tok.value
        line = name_tok.line

        body = self.parse_body("ENDPROGRAM")
        self.expect("ENDPROGRAM")
        self.skip_newlines()

        return ProgramNode(name=name, body=body, line=line)

    # ─────────────────────────────────────────
    #  Body parsing (list of statements)
    # ─────────────────────────────────────────

    def parse_body(self, *stop_tokens) -> List[ASTNode]:
        stmts = []
        while True:
            self.skip_newlines()
            if self.current().type in stop_tokens or self.current().type == "EOF":
                break
            stmt = self.parse_stmt()
            if stmt is not None:
                stmts.append(stmt)
        return stmts

    # ─────────────────────────────────────────
    #  Statement dispatcher
    # ─────────────────────────────────────────

    def parse_stmt(self) -> Optional[ASTNode]:
        self.skip_newlines()
        tok = self.current()

        if tok.type == "LET":
            return self.parse_var_decl()
        elif tok.type == "IF":
            return self.parse_if()
        elif tok.type == "REPEAT":
            return self.parse_repeat()
        elif tok.type == "WHILE":
            return self.parse_while()
        elif tok.type == "DO":
            return self.parse_do_while()
        elif tok.type == "SWITCH":
            return self.parse_switch()
        elif tok.type == "STRUCT":
            return self.parse_struct_def()
        elif tok.type == "FOR":
            return self.parse_for()
        elif tok.type == "TYPE":
            return self.parse_type_stmt()
        elif tok.type == "FUN":
            return self.parse_function_def()
        elif tok.type == "RETURN":
            return self.parse_return()
        elif tok.type == "PRINT":
            return self.parse_print()
        elif tok.type == "CALL":
            return self.parse_call_stmt()
        elif tok.type == "NAME":
            # Check for assignment: target = expr
            # Target can be name, name[idx], name.member, or *ptr
            if self.peek().type in ("ASSIGN", "LBRACKET", "DOT", "ARROW"):
                return self.parse_assign()
            # Or just a call without 'call' keyword: myFunc(args)
            elif self.peek().type == "LPAREN":
                return self.parse_bare_call()
            else:
                raise ParseError(f"Unexpected identifier {tok.value!r}", tok.line)
        elif tok.type == "STAR": # *ptr = val
             return self.parse_assign()
        elif tok.type == "NEWLINE":
            self.advance()
            return None
        else:
            raise ParseError(
                f"Unexpected token {tok.type!r} ({tok.value!r})", tok.line
            )

    # ─────────────────────────────────────────
    #  Variable declaration
    #  let name: type = expr
    # ─────────────────────────────────────────

    def parse_var_decl(self) -> VarDecl:
        line = self.current().line
        self.expect("LET")
        name = self.expect("NAME").value
        self.expect("COLON")
        var_type = self.expect("NUM", "TEXT", "BOOL", "DECIMAL", "PTR", "NAME", "LIST").value
        self.expect("ASSIGN")
        value = self.parse_expr()
        return VarDecl(name=name, var_type=var_type, value=value, line=line)

    # ─────────────────────────────────────────
    #  Assignment
    #  name = expr
    # ─────────────────────────────────────────

    def parse_assign(self) -> ASTNode:
        line = self.current().line
        
        # Parse the left hand side (target)
        if self.match("STAR"):
            self.advance()
            target = self.parse_primary()
            self.expect("ASSIGN")
            value = self.parse_expr()
            ptr_name = self._get_target_name(target)
            return PointerAssign(target=ptr_name, value=value, line=line)
        
        # For member access or index access
        target_node = self.parse_primary()
        self.expect("ASSIGN")
        value = self.parse_expr()
        
        if isinstance(target_node, Identifier):
            return Assign(name=target_node.name, value=value, line=line)
        elif isinstance(target_node, IndexAccess):
            # Special node for index assign
            return BinaryOp(left=target_node, op="=", right=value, line=line)
        elif isinstance(target_node, BinaryOp) and target_node.op == ".":
            # Special node for member assign
            return BinaryOp(left=target_node, op="=", right=value, line=line)
        
        raise ParseError("Invalid assignment target", line)

    def _get_target_name(self, node):
        if isinstance(node, Identifier): return node.name
        if isinstance(node, BinaryOp): return f"{self._get_target_name(node.left)}.{self._get_target_name(node.right)}"
        return "unknown"

    # ─────────────────────────────────────────
    #  If statement
    #  if expr then
    #    ...
    #  else
    #    ...
    #  endif
    # ─────────────────────────────────────────

    def parse_if(self) -> IfStmt:
        line = self.current().line
        self.expect("IF")
        condition = self.parse_expr()
        self.expect("THEN")

        then_body = self.parse_body("ELSE", "ENDIF")
        else_body = []

        if self.match("ELSE"):
            self.advance()
            else_body = self.parse_body("ENDIF")

        self.expect("ENDIF")
        return IfStmt(condition=condition, then_body=then_body, else_body=else_body, line=line)

    # ─────────────────────────────────────────
    #  Repeat loop
    #  repeat expr times begin
    #    ...
    #  end
    # ─────────────────────────────────────────

    def parse_repeat(self) -> RepeatStmt:
        line = self.current().line
        self.expect("REPEAT")
        count = self.parse_expr()
        self.expect("TIMES")
        self.expect("BEGIN")
        body = self.parse_body("END")
        self.expect("END")
        return RepeatStmt(count=count, body=body, line=line)

    # ─────────────────────────────────────────
    #  While loop
    #  while expr do
    #    ...
    #  endwhile
    # ─────────────────────────────────────────

    def parse_while(self) -> WhileStmt:
        line = self.current().line
        self.expect("WHILE")
        condition = self.parse_expr()
        self.expect("DO")
        body = self.parse_body("ENDWHILE")
        self.expect("ENDWHILE")
        return WhileStmt(condition=condition, body=body, line=line)

    def parse_do_while(self) -> DoWhileStmt:
        line = self.current().line
        self.expect("DO")
        body = self.parse_body("WHILE")
        self.expect("WHILE")
        condition = self.parse_expr()
        self.expect("ENDDO")
        return DoWhileStmt(condition=condition, body=body, line=line)

    def parse_switch(self) -> SwitchStmt:
        line = self.current().line
        self.expect("SWITCH")
        expr = self.parse_expr()
        self.expect("BEGIN")
        cases = []
        while not self.match("ENDSWITCH", "EOF"):
            if self.match("CASE"):
                self.expect("CASE")
                val = self.parse_expr()
                self.expect("COLON")
                body = self.parse_body("CASE", "DEFAULT", "ENDSWITCH")
                cases.append(CaseStmt(value=val, body=body, line=line))
            elif self.match("DEFAULT"):
                self.expect("DEFAULT")
                self.expect("COLON")
                body = self.parse_body("CASE", "ENDSWITCH")
                cases.append(CaseStmt(value=None, body=body, line=line))
            else:
                self.advance() # Skip unexpected tokens inside switch
        self.expect("ENDSWITCH")
        return SwitchStmt(expression=expr, cases=cases, line=line)

    def parse_struct_def(self) -> StructDef:
        line = self.current().line
        self.expect("STRUCT")
        name = self.expect("NAME").value
        self.expect("BEGIN")
        fields = []
        while not self.match("ENDSTRUCT", "EOF"):
            if self.match("NAME"):
                fname = self.advance().value
                self.expect("COLON")
                ftype = self.expect("NUM", "TEXT", "BOOL", "DECIMAL", "NAME").value
                fields.append(StructField(name=fname, field_type=ftype, line=line))
            else:
                self.advance()
        self.expect("ENDSTRUCT")
        return StructDef(name=name, fields=fields, line=line)

    def parse_type_stmt(self) -> TypeCheck:
        line = self.current().line
        self.expect("TYPE")
        self.expect("LPAREN")
        expr = self.parse_expr()
        self.expect("RPAREN")
        return TypeCheck(expression=expr, line=line)

    # ─────────────────────────────────────────
    #  For loop
    #  for x from 1 to 10 step 1
    #    ...
    #  endfor
    # ─────────────────────────────────────────

    def parse_for(self) -> ForStmt:
        line = self.current().line
        self.expect("FOR")
        var = self.expect("NAME").value
        self.expect("FROM")
        start = self.parse_expr()
        self.expect("TO")
        end = self.parse_expr()

        # step is optional — defaults to 1
        if self.match("STEP"):
            self.advance()
            step = self.parse_expr()
        else:
            step = NumberLiteral(value=1, line=line)

        body = self.parse_body("ENDFOR")
        self.expect("ENDFOR")
        return ForStmt(var=var, start=start, end=end, step=step, body=body, line=line)

    # ─────────────────────────────────────────
    #  Function definition
    #  fun name(param: type, ...) as return_type
    #    ...
    #  endfun
    # ─────────────────────────────────────────

    def parse_function_def(self) -> FunctionDef:
        line = self.current().line
        self.expect("FUN")
        name = self.expect("NAME").value
        self.expect("LPAREN")
        params = self.parse_params()
        self.expect("RPAREN")

        return_type = None
        if self.match("AS"):
            self.advance()
            return_type = self.expect("NUM", "TEXT", "BOOL", "DECIMAL").value

        body = self.parse_body("ENDFUN")
        self.expect("ENDFUN")
        return FunctionDef(name=name, params=params, return_type=return_type, body=body, line=line)

    def parse_params(self) -> List[Param]:
        params = []
        if self.match("RPAREN"):
            return params
        while True:
            self.skip_newlines()
            pname = self.expect("NAME").value
            self.expect("COLON")
            ptype = self.expect("NUM", "TEXT", "BOOL", "DECIMAL").value
            params.append(Param(name=pname, param_type=ptype, line=self.current().line))
            if not self.match("COMMA"):
                break
            self.advance()  # consume comma
        return params

    # ─────────────────────────────────────────
    #  Return statement
    # ─────────────────────────────────────────

    def parse_return(self) -> ReturnStmt:
        line = self.current().line
        self.expect("RETURN")
        # If nothing follows on the same logical line, return None
        if self.current().type in ("NEWLINE", "EOF", "ENDFUN"):
            return ReturnStmt(value=None, line=line)
        return ReturnStmt(value=self.parse_expr(), line=line)

    # ─────────────────────────────────────────
    #  Print statement
    # ─────────────────────────────────────────

    def parse_print(self) -> PrintStmt:
        line = self.current().line
        self.expect("PRINT")
        value = self.parse_expr()
        return PrintStmt(value=value, line=line)

    # ─────────────────────────────────────────
    #  Function call as statement: call f(args)
    # ─────────────────────────────────────────

    def parse_call_stmt(self) -> FunctionCall:
        line = self.current().line
        self.expect("CALL")
        name = self.expect("NAME").value
        self.expect("LPAREN")
        args = self.parse_args()
        self.expect("RPAREN")
        return FunctionCall(name=name, args=args, line=line)

    def parse_bare_call(self) -> FunctionCall:
        """funcname(args) without 'call' keyword — allowed as a statement"""
        line = self.current().line
        name = self.expect("NAME").value
        self.expect("LPAREN")
        args = self.parse_args()
        self.expect("RPAREN")
        return FunctionCall(name=name, args=args, line=line)

    def parse_args(self) -> List[ASTNode]:
        args = []
        if self.match("RPAREN"):
            return args
        while True:
            self.skip_newlines()
            args.append(self.parse_expr())
            if not self.match("COMMA"):
                break
            self.advance()
        return args

    # ─────────────────────────────────────────
    #  Expression hierarchy (precedence climbing)
    # ─────────────────────────────────────────

    def parse_expr(self) -> ASTNode:
        return self.parse_or()

    def parse_or(self) -> ASTNode:
        left = self.parse_and()
        while self.match_inline("OR"):
            op = self.advance().value
            right = self.parse_and()
            left = BinaryOp(left=left, op=op, right=right, line=left.line)
        return left

    def parse_and(self) -> ASTNode:
        left = self.parse_not()
        while self.match_inline("AND"):
            op = self.advance().value
            right = self.parse_not()
            left = BinaryOp(left=left, op=op, right=right, line=left.line)
        return left

    def parse_not(self) -> ASTNode:
        if self.match_inline("NOT"):
            line = self.current().line
            self.advance()
            return UnaryOp(op="not", operand=self.parse_not(), line=line)
        return self.parse_comparison()

    def parse_comparison(self) -> ASTNode:
        left = self.parse_addition()
        while self.match_inline("EQ", "NEQ", "LT", "GT", "LTE", "GTE"):
            op = self.advance().value
            right = self.parse_addition()
            left = BinaryOp(left=left, op=op, right=right, line=left.line)
        return left

    def parse_addition(self) -> ASTNode:
        left = self.parse_term()
        while self.match_inline("PLUS", "MINUS"):
            op = self.advance().value
            right = self.parse_term()
            left = BinaryOp(left=left, op=op, right=right, line=left.line)
        return left

    def parse_term(self) -> ASTNode:
        left = self.parse_power()
        while self.match_inline("STAR", "SLASH", "MOD"):
            op = self.advance().value
            right = self.parse_power()
            left = BinaryOp(left=left, op=op, right=right, line=left.line)
        return left

    def parse_power(self) -> ASTNode:
        left = self.parse_unary()
        if self.match_inline("POWER"):
            op = self.advance().value
            right = self.parse_unary()
            return BinaryOp(left=left, op=op, right=right, line=left.line)
        return left

    def parse_unary(self) -> ASTNode:
        if self.match_inline("MINUS"):
            line = self.current().line
            self.advance()
            return UnaryOp(op="-", operand=self.parse_unary(), line=line)
        elif self.match_inline("STAR"):
            line = self.current().line
            self.advance()
            operand = self.parse_unary()
            return Dereference(target=operand, line=line)
        elif self.match_inline("ADDR"):
            line = self.current().line
            self.advance()
            target = self.expect("NAME").value
            return AddressOf(target=target, line=line)

        return self.parse_primary()

    def parse_primary(self) -> ASTNode:
        tok = self.current()

        # Number
        if tok.type == "NUMBER":
            self.advance()
            return NumberLiteral(value=int(tok.value), line=tok.line)

        # Decimal
        if tok.type == "DECIMAL":
            self.advance()
            return DecimalLiteral(value=float(tok.value), line=tok.line)

        # String
        if tok.type == "STRING":
            self.advance()
            return StringLiteral(value=tok.value, line=tok.line)

        # Boolean
        if tok.type in ("TRUE", "FALSE"):
            self.advance()
            return BoolLiteral(value=(tok.type == "TRUE"), line=tok.line)

        # Type check expression
        if tok.type == "TYPE":
            return self.parse_type_stmt()

        # Input
        if tok.type == "INPUT":
            self.advance()
            prompt = self.parse_primary()
            return InputStmt(prompt=prompt, line=tok.line)

        # List literal [1, 2, 3]
        if tok.type == "LBRACKET":
            return self.parse_list_literal()

        # Grouped expression (expr)
        if tok.type == "LPAREN":
            self.advance()
            expr = self.parse_expr()
            self.expect("RPAREN")
            return expr

        # Name — could be variable, function call, indexed access, or member access
        if tok.type == "NAME":
            name = self.advance().value
            node = Identifier(name=name, line=tok.line)

            # Check for function call: name(args)
            if self.match_inline("LPAREN"):
                self.advance()
                args = self.parse_args()
                self.expect("RPAREN")
                node = FunctionCall(name=name, args=args, line=tok.line)
            # Check for array index: name[expr]
            elif self.match_inline("LBRACKET"):
                self.advance()
                index = self.parse_expr()
                self.expect("RBRACKET")
                node = IndexAccess(target=node, index=index, line=tok.line)

            # Check for struct member access: node.member or node->member
            while self.match_inline("DOT", "ARROW"):
                self.advance()
                member = self.expect("NAME").value
                node = BinaryOp(left=node, op=".", right=Identifier(name=member, line=tok.line), line=tok.line)

            return node

        raise ParseError(f"Unexpected token {tok.type!r} ({tok.value!r}) in expression", tok.line)

    def parse_list_literal(self) -> ListLiteral:
        line = self.current().line
        self.expect("LBRACKET")
        elements = []
        if not self.match("RBRACKET"):
            while True:
                elements.append(self.parse_expr())
                if not self.match("COMMA"):
                    break
                self.advance()
        self.expect("RBRACKET")
        return ListLiteral(elements=elements, line=line)
