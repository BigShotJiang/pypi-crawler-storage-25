"""
mylang — CLI entry point installed by pip.
Invoked as: mylang <file.myl> [flags]
"""
import sys
import os

# Ensure the package's own directory is on the path so the
# original compiler.py can find its siblings (lexer, parser, etc.)
sys.path.insert(0, os.path.dirname(__file__))

from mylang.compiler import main  # noqa: E402

def run():
    main()

if __name__ == "__main__":
    run()
