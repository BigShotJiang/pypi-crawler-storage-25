
"""
MyLang Compiler — Three Address Code (TAC) Generator
"""
from ast_nodes import *

class TACInstruction:
    def __init__(self, op, arg1=None, arg2=None, result=None):
        self.op = op
        self.arg1 = arg1
        self.arg2 = arg2
        self.result = result

    def __repr__(self):
        res = f"{self.result} = " if self.result else ""
        if self.op == "label": return f"{self.arg1}:"
        if self.op == "goto": return f"goto {self.arg1}"
        if self.op == "if": return f"if {self.arg1} goto {self.result}"
        if self.op == "print": return f"print {self.arg1}"
        if self.op == "return": return f"return {self.arg1}"
        if self.op == "=": return f"{self.result} = {self.arg1}"
        if self.op == "call": return f"{self.result} = call {self.arg1}({self.arg2})"
        if self.op == "type": return f"{self.result} = type({self.arg1})"
        
        args = f"{self.arg1}"
        if self.arg2: args += f" {self.op} {self.arg2}"
        return f"{res}{args}"

class TACGenerator:
    def __init__(self):
        self.instructions = []
        self.temp_count = 0
        self.label_count = 0

    def new_temp(self):
        self.temp_count += 1
        return f"t{self.temp_count}"

    def new_label(self):
        self.label_count += 1
        return f"L{self.label_count}"

    def emit(self, op, arg1=None, arg2=None, result=None):
        self.instructions.append(TACInstruction(op, arg1, arg2, result))

    def generate(self, node):
        if isinstance(node, ProgramNode):
            for stmt in node.body:
                self.generate(stmt)
        
        elif isinstance(node, NumberLiteral) or isinstance(node, DecimalLiteral) or \
             isinstance(node, StringLiteral) or isinstance(node, BoolLiteral):
            return str(node.value)
        
        elif isinstance(node, Identifier):
            return node.name
        
        elif isinstance(node, VarDecl):
            val = self.generate(node.value)
            self.emit("=", val, result=node.name)
        
        elif isinstance(node, Assign):
            val = self.generate(node.value)
            self.emit("=", val, result=node.name)
        
        elif isinstance(node, BinaryOp):
            left = self.generate(node.left)
            right = self.generate(node.right)
            temp = self.new_temp()
            self.emit(node.op, left, right, result=temp)
            return temp
        
        elif isinstance(node, UnaryOp):
            operand = self.generate(node.operand)
            temp = self.new_temp()
            self.emit(node.op, operand, result=temp)
            return temp
        
        elif isinstance(node, PrintStmt):
            val = self.generate(node.value)
            self.emit("print", val)
        
        elif isinstance(node, IfStmt):
            cond = self.generate(node.condition)
            else_label = self.new_label()
            end_label = self.new_label()
            self.emit("if", f"not {cond}", result=else_label)
            for stmt in node.then_body:
                self.generate(stmt)
            self.emit("goto", end_label)
            self.emit("label", else_label)
            for stmt in node.else_body:
                self.generate(stmt)
            self.emit("label", end_label)
        
        elif isinstance(node, WhileStmt):
            start_label = self.new_label()
            end_label = self.new_label()
            self.emit("label", start_label)
            cond = self.generate(node.condition)
            self.emit("if", f"not {cond}", result=end_label)
            for stmt in node.body:
                self.generate(stmt)
            self.emit("goto", start_label)
            self.emit("label", end_label)

        elif isinstance(node, DoWhileStmt):
            start_label = self.new_label()
            self.emit("label", start_label)
            for stmt in node.body:
                self.generate(stmt)
            cond = self.generate(node.condition)
            self.emit("if", cond, result=start_label)

        elif isinstance(node, FunctionCall):
            args = [self.generate(arg) for arg in node.args]
            temp = self.new_temp()
            self.emit("call", node.name, ", ".join(args), result=temp)
            return temp

        elif isinstance(node, TypeCheck):
            expr = self.generate(node.expression)
            temp = self.new_temp()
            self.emit("type", expr, result=temp)
            return temp
        
        elif isinstance(node, IndexAccess):
            target = self.generate(node.target)
            index = self.generate(node.index)
            temp = self.new_temp()
            self.emit("[]", target, index, result=temp)
            return temp
            
        return None

    def dump(self):
        print(f"\n{'─'*50}")
        print(f"  THREE ADDRESS CODE (TAC)")
        print(f"{'─'*50}")
        for instr in self.instructions:
            print(f"  {instr}")
        print(f"{'─'*50}\n")
