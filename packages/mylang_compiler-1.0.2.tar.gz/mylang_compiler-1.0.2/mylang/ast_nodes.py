"""
MyLang Compiler — AST Node Definitions
"""
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class ASTNode:
    pass

@dataclass
class ProgramNode(ASTNode):
    name: str
    body: List[ASTNode]
    line: int = 0

@dataclass
class NumberLiteral(ASTNode):
    value: int
    line: int = 0

@dataclass
class DecimalLiteral(ASTNode):
    value: float
    line: int = 0

@dataclass
class StringLiteral(ASTNode):
    value: str
    line: int = 0

@dataclass
class BoolLiteral(ASTNode):
    value: bool
    line: int = 0

@dataclass
class Identifier(ASTNode):
    name: str
    line: int = 0

@dataclass
class VarDecl(ASTNode):
    name: str
    var_type: str
    value: ASTNode
    line: int = 0

@dataclass
class Assign(ASTNode):
    name: str
    value: ASTNode
    line: int = 0

@dataclass
class BinaryOp(ASTNode):
    left: ASTNode
    op: str
    right: ASTNode
    line: int = 0

@dataclass
class UnaryOp(ASTNode):
    op: str
    operand: ASTNode
    line: int = 0

@dataclass
class FunctionCall(ASTNode):
    name: str
    args: List[ASTNode]
    line: int = 0

@dataclass
class IndexAccess(ASTNode):
    target: ASTNode
    index: ASTNode
    line: int = 0

@dataclass
class ListLiteral(ASTNode):
    elements: List[ASTNode]
    line: int = 0

@dataclass
class PrintStmt(ASTNode):
    value: ASTNode
    line: int = 0

@dataclass
class InputStmt(ASTNode):
    prompt: ASTNode
    line: int = 0

@dataclass
class PointerAssign(ASTNode):
    """Assignment through a pointer dereference: *ptr = value"""
    target: str
    value: ASTNode
    line: int = 0

@dataclass
class ReturnStmt(ASTNode):
    value: Optional[ASTNode]
    line: int = 0

@dataclass
class IfStmt(ASTNode):
    condition: ASTNode
    then_body: List[ASTNode]
    else_body: List[ASTNode]
    line: int = 0

@dataclass
class RepeatStmt(ASTNode):
    count: ASTNode
    body: List[ASTNode]
    line: int = 0

@dataclass
class WhileStmt(ASTNode):
    condition: ASTNode
    body: List[ASTNode]
    line: int = 0

@dataclass
class ForStmt(ASTNode):
    var: str
    start: ASTNode
    end: ASTNode
    step: ASTNode
    body: List[ASTNode]
    line: int = 0

@dataclass
class DoWhileStmt(ASTNode):
    condition: ASTNode
    body: List[ASTNode]
    line: int = 0

@dataclass
class CaseStmt(ASTNode):
    value: Optional[ASTNode]  # None for default
    body: List[ASTNode]
    line: int = 0

@dataclass
class SwitchStmt(ASTNode):
    expression: ASTNode
    cases: List[CaseStmt]
    line: int = 0

@dataclass
class StructField(ASTNode):
    name: str
    field_type: str
    line: int = 0

@dataclass
class StructDef(ASTNode):
    name: str
    fields: List[StructField]
    line: int = 0

@dataclass
class TypeCheck(ASTNode):
    expression: ASTNode
    line: int = 0

@dataclass
class AddressOf(ASTNode):
    target: str
    line: int = 0

@dataclass
class Dereference(ASTNode):
    target: ASTNode
    line: int = 0

@dataclass
class Param(ASTNode):
    name: str
    param_type: str
    line: int = 0

@dataclass
class FunctionDef(ASTNode):
    name: str
    params: List[Param]
    return_type: Optional[str]
    body: List[ASTNode]
    line: int = 0


def _ast_children(node: ASTNode):
    """Return a list of (label, child_or_children) tuples for tree rendering."""
    if isinstance(node, ProgramNode):
        return [(f"stmt[{i}]", c) for i, c in enumerate(node.body)]
    if isinstance(node, FunctionDef):
        kids = [(f"param[{i}]", p) for i, p in enumerate(node.params)]
        kids += [(f"body[{i}]", c) for i, c in enumerate(node.body)]
        return kids
    if isinstance(node, VarDecl):
        return [("value", node.value)]
    if isinstance(node, Assign):
        return [("value", node.value)]
    if isinstance(node, PointerAssign):
        return [("value", node.value)]
    if isinstance(node, IfStmt):
        kids = [("cond", node.condition)]
        kids += [(f"then[{i}]", c) for i, c in enumerate(node.then_body)]
        kids += [(f"else[{i}]", c) for i, c in enumerate(node.else_body)]
        return kids
    if isinstance(node, RepeatStmt):
        return [("count", node.count)] + [(f"body[{i}]", c) for i, c in enumerate(node.body)]
    if isinstance(node, WhileStmt):
        return [("cond", node.condition)] + [(f"body[{i}]", c) for i, c in enumerate(node.body)]
    if isinstance(node, DoWhileStmt):
        return [(f"body[{i}]", c) for i, c in enumerate(node.body)] + [("cond", node.condition)]
    if isinstance(node, ForStmt):
        return [("start", node.start), ("end", node.end), ("step", node.step)] + \
               [(f"body[{i}]", c) for i, c in enumerate(node.body)]
    if isinstance(node, SwitchStmt):
        return [("expr", node.expression)] + [(f"case[{i}]", c) for i, c in enumerate(node.cases)]
    if isinstance(node, CaseStmt):
        kids = [("val", node.value)] if node.value else []
        kids += [(f"body[{i}]", c) for i, c in enumerate(node.body)]
        return kids
    if isinstance(node, BinaryOp):
        return [("left", node.left), ("right", node.right)]
    if isinstance(node, UnaryOp):
        return [("operand", node.operand)]
    if isinstance(node, FunctionCall):
        return [(f"arg[{i}]", a) for i, a in enumerate(node.args)]
    if isinstance(node, PrintStmt):
        return [("expr", node.value)]
    if isinstance(node, ReturnStmt):
        return [("expr", node.value)] if node.value else []
    if isinstance(node, TypeCheck):
        return [("expr", node.expression)]
    if isinstance(node, Dereference):
        return [("target", node.target)]
    if isinstance(node, IndexAccess):
        return [("target", node.target), ("index", node.index)]
    if isinstance(node, ListLiteral):
        return [(f"elem[{i}]", e) for i, e in enumerate(node.elements)]
    if isinstance(node, InputStmt):
        return [("prompt", node.prompt)]
    if isinstance(node, Param):
        return []
    return []


def _ast_label(node: ASTNode) -> str:
    """Return the display label for a node (no children info)."""
    if isinstance(node, ProgramNode):
        return f"Program  name={node.name!r}"
    if isinstance(node, FunctionDef):
        rt = node.return_type or "void"
        return f"FunctionDef  name={node.name!r}  returns={rt}"
    if isinstance(node, Param):
        return f"Param  {node.name!r}: {node.param_type}"
    if isinstance(node, VarDecl):
        return f"VarDecl  {node.name!r}: {node.var_type}"
    if isinstance(node, Assign):
        return f"Assign  target={node.name!r}"
    if isinstance(node, PointerAssign):
        return f"PointerAssign  target=*{node.target!r}"
    if isinstance(node, IfStmt):
        has_else = "yes" if node.else_body else "no"
        return f"IfStmt  else={has_else}"
    if isinstance(node, RepeatStmt):
        return "RepeatStmt"
    if isinstance(node, WhileStmt):
        return "WhileStmt"
    if isinstance(node, DoWhileStmt):
        return "DoWhileStmt"
    if isinstance(node, ForStmt):
        return f"ForStmt  var={node.var!r}"
    if isinstance(node, SwitchStmt):
        return "SwitchStmt"
    if isinstance(node, CaseStmt):
        return "CaseStmt  default" if node.value is None else "CaseStmt"
    if isinstance(node, StructDef):
        fields = ", ".join(f"{f.name}:{f.field_type}" for f in node.fields)
        return f"StructDef  name={node.name!r}  fields=[{fields}]"
    if isinstance(node, BinaryOp):
        return f"BinaryOp  op={node.op!r}"
    if isinstance(node, UnaryOp):
        return f"UnaryOp  op={node.op!r}"
    if isinstance(node, FunctionCall):
        return f"Call  name={node.name!r}"
    if isinstance(node, PrintStmt):
        return "PrintStmt"
    if isinstance(node, InputStmt):
        return "InputStmt"
    if isinstance(node, ReturnStmt):
        return "ReturnStmt"
    if isinstance(node, TypeCheck):
        return "TypeCheck"
    if isinstance(node, AddressOf):
        return f"AddressOf  &{node.target!r}"
    if isinstance(node, Dereference):
        return "Dereference"
    if isinstance(node, IndexAccess):
        return "IndexAccess"
    if isinstance(node, ListLiteral):
        return f"ListLiteral  len={len(node.elements)}"
    if isinstance(node, Identifier):
        return f"Id  name={node.name!r}"
    if isinstance(node, NumberLiteral):
        return f"Num  value={node.value}"
    if isinstance(node, DecimalLiteral):
        return f"Dec  value={node.value}"
    if isinstance(node, StringLiteral):
        return f"Str  value={node.value!r}"
    if isinstance(node, BoolLiteral):
        return f"Bool  value={node.value}"
    return node.__class__.__name__


def _draw_tree(node: ASTNode, prefix: str = "", is_last: bool = True,
               edge_label: str = "", lines: list = None):
    """Recursively draw the AST as a Unicode tree."""
    if lines is None:
        lines = []

    connector = "└── " if is_last else "├── "
    edge = f"[{edge_label}] " if edge_label else ""
    label = _ast_label(node)
    lines.append(f"{prefix}{connector}{edge}{label}")

    child_prefix = prefix + ("    " if is_last else "│   ")
    children = _ast_children(node)
    for i, (lbl, child) in enumerate(children):
        last_child = (i == len(children) - 1)
        _draw_tree(child, child_prefix, last_child, lbl, lines)

    return lines


def print_ast(node: ASTNode, indent: int = 0):
    """Print the AST as a proper Unicode tree."""
    if indent == 0:
        # Top-level call — print root then its children as a full tree
        print(_ast_label(node))
        children = _ast_children(node)
        for i, (lbl, child) in enumerate(children):
            last = (i == len(children) - 1)
            for line in _draw_tree(child, "", last, lbl):
                print(line)
    else:
        # Called recursively (legacy path) — fall back to tree from this node
        lines = _draw_tree(node, "  " * indent, True, "")
        for line in lines:
            print(line)
