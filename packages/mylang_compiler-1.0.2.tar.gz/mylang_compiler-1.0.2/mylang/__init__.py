"""MyLang — a statically-typed language that compiles to Python."""
__version__ = "1.0.0"
