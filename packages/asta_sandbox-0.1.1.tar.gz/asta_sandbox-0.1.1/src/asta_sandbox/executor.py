"""Core types, Protocol, and abstract base class for sandbox executors."""

from __future__ import annotations

import abc
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol, runtime_checkable


# ── Result types ─────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class RichOutput:
    """A single rich display output (MIME bundle) from code execution."""

    output_type: str
    data: Mapping[str, Any]
    metadata: Mapping[str, Any] = field(default_factory=dict)
    execution_count: int | None = None


@dataclass(frozen=True)
class ExecutionError:
    """Details about an error raised during code execution."""

    etype: str | None
    evalue: str | None
    traceback: tuple[str, ...] = ()


@dataclass(frozen=True)
class ExecutionResult:
    """Complete output of a single code execution call."""

    stdout: str
    stderr: str
    success: bool
    rich_outputs: tuple[RichOutput, ...] = ()
    error: ExecutionError | None = None


# ── File sharing ──────────────────────────────────────────────────────────────────


@dataclass
class MountShare:
    """Bind a local path into the sandbox (read-only on Docker; writable on Modal).

    Before start(): Docker bind-mounts at container start; Modal bakes into the
        image via add_local_file/dir() (Modal caches the layer when source is unchanged).
    After start(): raises ValueError on all backends — mounts are fixed at start time.
    InProcess: raises ValueError.
    """

    source: Path   # path on the host
    dest: str      # absolute path inside the sandbox

    def __post_init__(self) -> None:
        if not self.dest.startswith("/"):
            raise ValueError("MountShare.dest must be an absolute path")


@dataclass
class CopyShare:
    """Copy a local path into the sandbox.

    Before start(): Docker uploads after container start; Modal bakes into image.
    After start(): Docker streams via tar archive; ModalKernel writes via sandbox.open()
        in 512 MiB chunks; ModalEphemeral updates image state for next run_code().
    InProcess: raises ValueError.
    """

    source: Path   # path on the host
    dest: str      # absolute path inside the sandbox

    def __post_init__(self) -> None:
        if not self.dest.startswith("/"):
            raise ValueError("CopyShare.dest must be an absolute path")


@dataclass
class CloudShare:
    """Mount a cloud bucket prefix (S3 / GCS) at construction time.

    Modal only (ModalKernelExecutor and ModalEphemeralExecutor).
    DockerExecutor raises NotImplementedError; InProcess raises ValueError.

    For GCS, set bucket_endpoint_url to the GCS S3-compatible endpoint:
        "https://storage.googleapis.com"
    """

    dest: str               # mount point inside the sandbox
    bucket: str
    key_prefix: str
    read_only: bool = True
    bucket_endpoint_url: str | None = None   # GCS or S3-compatible endpoint
    oidc_auth_role_arn: str | None = None    # IAM role for OIDC auth
    modal_secret: Any | None = None          # modal.Secret for credential-based auth

    def __post_init__(self) -> None:
        if not self.dest.startswith("/"):
            raise ValueError("CloudShare.dest must be an absolute path")


#: Union of all concrete file-share types. Pass to add_shares() on any executor.
FileShare = MountShare | CopyShare | CloudShare


# ── Errors ────────────────────────────────────────────────────────────────────────


class SandboxNotStartedError(RuntimeError):
    """Raised when a sandbox operation is attempted before start()."""


# ── Protocol ──────────────────────────────────────────────────────────────────────


@runtime_checkable
class SandboxExecutor(Protocol):
    """Structural type for all sandbox executor implementations.

    Use this as a type annotation when you want to accept any executor
    without depending on the concrete class or the abstract base.
    """

    async def start(self) -> None: ...
    async def shutdown(self) -> None: ...
    async def run_code(self, code: str, timeout_seconds: float | None = None) -> ExecutionResult: ...
    async def add_shares(self, *shares: FileShare) -> None: ...


# ── Abstract base class ───────────────────────────────────────────────────────────


class SandboxBase(abc.ABC):
    """Convenience base class for sandbox executor implementations.

    Provides async context manager support (start/shutdown), stores all
    file shares (constructor + add_shares), and exposes them via .file_shares.

    Subclasses override add_shares to act on the shares, then call
    super().add_shares(*shares) to record them here.
    """

    def __init__(self) -> None:
        self._file_shares: tuple[FileShare, ...] = ()
        self._started: bool = False

    @property
    def file_shares(self) -> tuple[FileShare, ...]:
        return self._file_shares

    async def __aenter__(self) -> SandboxBase:
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.shutdown()

    @abc.abstractmethod
    async def start(self) -> None:
        """Build or connect to the underlying runtime."""

    @abc.abstractmethod
    async def shutdown(self) -> None:
        """Cleanly tear down the runtime and release resources."""

    @abc.abstractmethod
    async def run_code(self, code: str, timeout_seconds: float | None = None) -> ExecutionResult:
        """Execute code and return structured outputs."""

    async def add_shares(self, *shares: FileShare) -> None:
        """Record additional file shares for inspection via .file_shares.

        Subclasses override this to apply the shares, then call super().
        """
        self._file_shares = self._file_shares + tuple(shares)

    async def _ensure_started(self) -> None:
        if not self._started:
            await self.start()
