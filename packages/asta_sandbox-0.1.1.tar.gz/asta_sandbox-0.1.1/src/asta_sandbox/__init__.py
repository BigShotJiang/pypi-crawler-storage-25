"""asta-sandbox — shared code execution sandbox abstractions for Asta projects.

Quick start::

    from asta_sandbox import InProcessExecutor

    async with InProcessExecutor() as executor:
        result = await executor.run_code("x = 1 + 1")
        result2 = await executor.run_code("print(x)")  # state is preserved
"""

# Core types — always available (no optional deps required)
from .executor import (
    CloudShare,
    CopyShare,
    ExecutionError,
    ExecutionResult,
    FileShare,
    MountShare,
    RichOutput,
    SandboxBase,
    SandboxExecutor,
    SandboxNotStartedError,
)

# In-process backend — always available (only requires ipython)
from .backends.inprocess import InProcessExecutor

# Image builders (lazy modal import inside each function)
from .images import build_modal_ephemeral_image, build_modal_kernel_image

__all__ = [
    # File share types
    "CloudShare",
    "CopyShare",
    "FileShare",
    "MountShare",
    # Result types
    "ExecutionError",
    "ExecutionResult",
    "RichOutput",
    # Executor infrastructure
    "SandboxBase",
    "SandboxExecutor",
    "SandboxNotStartedError",
    # Backends
    "InProcessExecutor",
    # Image builders
    "build_modal_ephemeral_image",
    "build_modal_kernel_image",
]
