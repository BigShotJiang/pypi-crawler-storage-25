"""In-process IPython backend.

Runs code in a persistent IPython shell within the current process.
State (variables, imports) accumulates across run_code() calls.

Best for local development, testing, and multi-turn interactive workflows
where you want low overhead and don't need process-level isolation.
"""

from __future__ import annotations

import asyncio
import logging

from IPython.core.interactiveshell import InteractiveShell

from ..executor import (
    ExecutionError,
    ExecutionResult,
    FileShare,
    RichOutput,
    SandboxBase,
    SandboxNotStartedError,
)
from ..ipython_session import ExecutionConfig, ensure_pip_available, configure_shell, run_cell_with_shell

_log = logging.getLogger(__name__)


def _ipython_dict_to_result(raw: dict) -> ExecutionResult:
    """Convert an IPython session output dict to an ExecutionResult."""
    error: ExecutionError | None = None
    if raw.get("error"):
        err = raw["error"]
        tb = err.get("traceback", "")
        error = ExecutionError(
            etype=err.get("type"),
            evalue=err.get("message"),
            traceback=(tb,) if tb else (),
        )

    rich_outputs = tuple(
        RichOutput(output_type="display_data", data=output, metadata={})
        for output in raw.get("rich_outputs", [])
        if output  # skip empty bundles
    )

    return ExecutionResult(
        stdout=raw.get("stdout", ""),
        stderr=raw.get("stderr", ""),
        success=raw.get("success", False),
        rich_outputs=rich_outputs,
        error=error,
    )


class InProcessExecutor(SandboxBase):
    """Runs code in a persistent in-process IPython shell.

    Stateful: variable and import state accumulates across run_code() calls.

    Note on process-level singleton: IPython's InteractiveShell.instance()
    returns the same shell for all callers in a process. If you run multiple
    InProcessExecutor instances concurrently, they will share shell state.
    This is usually fine in single-executor contexts; for isolation use a
    remote backend.

    File sharing is not supported — there is no isolation boundary to bridge.
    Code runs in the current process and already has full filesystem access.

    Args:
        matplotlib_backend: Matplotlib backend string. Defaults to inline.
    """

    def __init__(
        self,
        *,
        matplotlib_backend: str | None = ExecutionConfig.matplotlib_backend,
    ) -> None:
        super().__init__()
        self._matplotlib_backend = matplotlib_backend
        self._shell: InteractiveShell | None = None

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def start(self) -> None:
        ensure_pip_available()
        self._shell = InteractiveShell.instance()
        configure_shell(self._shell, self._matplotlib_backend)
        _log.debug("InProcessExecutor: IPython shell ready")
        self._started = True

    async def shutdown(self) -> None:
        self._shell = None

    # ── Core API ───────────────────────────────────────────────────────────────

    async def run_code(self, code: str, timeout_seconds: float | None = None) -> ExecutionResult:
        """Execute code in the persistent shell.

        timeout_seconds is a soft limit — asyncio stops waiting but the
        underlying thread may still be running.
        """
        await self._ensure_started()
        shell = self._require_shell()

        def _run_inline() -> dict:
            return run_cell_with_shell(shell, code)

        try:
            if timeout_seconds:
                raw = await asyncio.wait_for(
                    asyncio.to_thread(_run_inline),
                    timeout=timeout_seconds,
                )
            else:
                raw = await asyncio.to_thread(_run_inline)
        except asyncio.TimeoutError:
            raw = {
                "stdout": "",
                "stderr": "",
                "rich_outputs": [],
                "success": False,
                "error": {
                    "type": "TimeoutError",
                    "message": f"Execution timed out after {timeout_seconds}s (soft limit — the thread may still be running)",
                    "traceback": "",
                },
            }

        return _ipython_dict_to_result(raw)

    async def add_shares(self, *shares: FileShare) -> None:
        if shares:
            raise ValueError("InProcessExecutor does not support file shares")

    # ── Helpers ────────────────────────────────────────────────────────────────

    def _require_shell(self) -> InteractiveShell:
        if self._shell is None:
            raise SandboxNotStartedError("InProcessExecutor: call start() first")
        return self._shell
