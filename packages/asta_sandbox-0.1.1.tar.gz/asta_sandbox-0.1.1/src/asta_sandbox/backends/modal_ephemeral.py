"""Modal backend — stateless ephemeral sandboxes.

Creates a fresh Modal sandbox for every run_code() call and terminates
it immediately after. No state (variables, imports) survives between calls.

Suitable for single-shot pipelines and experiment runners where isolation
between executions is desirable.

Requires the `modal-ephemeral` optional dependency group:
    pip install asta-sandbox[modal-ephemeral]
"""

from __future__ import annotations

import json
import logging
from typing import Any, Mapping

import modal

from ..executor import (
    CloudShare,
    CopyShare,
    ExecutionError,
    ExecutionResult,
    FileShare,
    MountShare,
    RichOutput,
    SandboxBase,
)
from ..images import build_modal_ephemeral_image, prepare_modal_shares
from ..mounts import to_modal_cloud_bucket_mount

_log = logging.getLogger(__name__)

_DEFAULT_SANDBOX_TIMEOUT_S = 600

# Inline runner script embedded in the sandbox — avoids needing a deployed function.
# The asta_sandbox package must be available inside the image (via add_local_python_source).
_SANDBOX_RUNNER = """
import json
import sys
import traceback

from asta_sandbox.ipython_session import ExecutionConfig, IPythonSession


def _format_error(exc: BaseException) -> dict:
    return {
        "type": type(exc).__name__,
        "message": str(exc),
        "traceback": "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)),
    }


def main() -> None:
    try:
        payload = json.load(sys.stdin)
        session = IPythonSession(
            matplotlib_backend=payload.get("matplotlib_backend", ExecutionConfig.matplotlib_backend),
        )
        result = session.run_cell(payload["code_str"])
    except BaseException as exc:
        result = {
            "stdout": "",
            "stderr": "",
            "rich_outputs": [],
            "success": False,
            "error": _format_error(exc),
        }
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
"""


def _coerce_stream_output(output: Any) -> str:
    if output is None:
        return ""
    if isinstance(output, bytes):
        return output.decode("utf-8", errors="replace")
    return str(output)


def _ipython_dict_to_result(raw: dict) -> ExecutionResult:
    error: ExecutionError | None = None
    if raw.get("error"):
        err = raw["error"]
        tb = err.get("traceback", "")
        error = ExecutionError(
            etype=err.get("type"),
            evalue=err.get("message"),
            traceback=(tb,) if tb else (),
        )

    rich_outputs = tuple(
        RichOutput(output_type="display_data", data=output, metadata={})
        for output in raw.get("rich_outputs", [])
        if output
    )

    return ExecutionResult(
        stdout=raw.get("stdout", ""),
        stderr=raw.get("stderr", ""),
        success=raw.get("success", False),
        rich_outputs=rich_outputs,
        error=error,
    )


class ModalEphemeralExecutor(SandboxBase):
    """Creates a fresh Modal sandbox for every run_code() call.

    Stateless: no variables, imports, or data persist between calls.
    Each call is fully isolated from every other call.

    The executor instance itself is long-lived and holds configuration
    (image, mounts, env). Construct it once and reuse it across many calls.

    Args:
        app_name: Modal app name. Looked up or created if missing.
        image: Modal image to use. Defaults to build_modal_ephemeral_image(),
            which includes ipython and the asta_sandbox package as a local source.
        environment: Environment variables injected into every sandbox.
        sandbox_timeout_s: Maximum sandbox lifetime per call in seconds.
    """

    def __init__(
        self,
        *,
        app_name: str = "asta-sandbox",
        image: modal.Image | None = None,
        environment: Mapping[str, str] | None = None,
        sandbox_timeout_s: int = _DEFAULT_SANDBOX_TIMEOUT_S,
    ) -> None:
        super().__init__()
        self._image = image or build_modal_ephemeral_image()
        self._app_name = app_name
        self._environment = dict(environment or {})
        self._sandbox_timeout_s = sandbox_timeout_s
        self._app: modal.App | None = None

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def start(self) -> None:
        self._app = await modal.App.lookup.aio(self._app_name, create_if_missing=True)
        self._started = True

    async def shutdown(self) -> None:
        self._app = None

    # ── Core API ───────────────────────────────────────────────────────────────

    async def run_code(self, code: str, timeout_seconds: float | None = None) -> ExecutionResult:
        """Execute code in a fresh Modal sandbox.

        Each call creates a new sandbox, runs the code, terminates the sandbox,
        and returns the result. State does not persist between calls.
        """
        await self._ensure_started()
        volumes = self._build_volumes()
        secret = modal.Secret.from_dict(self._environment) if self._environment else None
        secrets = [secret] if secret is not None else []

        app = self._require_app()
        sandbox = await modal.Sandbox.create.aio(
            app=app,
            image=self._image,
            volumes=volumes,
            secrets=secrets,
            timeout=self._sandbox_timeout_s,
        )

        try:
            payload = {
                "code_str": code,
                "matplotlib_backend": None,  # no matplotlib in ephemeral by default
            }
            process = await sandbox.exec.aio(
                "python",
                "-c",
                _SANDBOX_RUNNER,
                timeout=timeout_seconds,
            )
            process.stdin.write(json.dumps(payload).encode("utf-8"))
            process.stdin.write_eof()
            await process.stdin.drain.aio()
            await process.wait.aio()

            stdout = _coerce_stream_output(await process.stdout.read.aio())
            stderr = _coerce_stream_output(await process.stderr.read.aio())
        finally:
            await sandbox.terminate.aio()

        try:
            raw = json.loads(stdout) if stdout else {}
        except json.JSONDecodeError:
            raw = {
                "stdout": "",
                "stderr": stderr or "",
                "rich_outputs": [],
                "success": False,
                "error": {
                    "type": "RuntimeError",
                    "message": "Sandbox output was not valid JSON",
                    "traceback": stdout or "",
                },
            }

        if stderr:
            raw.setdefault("stderr", "")
            raw["stderr"] = f"{raw['stderr']}{stderr}"

        return _ipython_dict_to_result(raw)

    # ── File share API ─────────────────────────────────────────────────────────

    async def add_shares(self, *shares: FileShare) -> None:
        """Add file shares to this executor.

        All share types are accepted at any time — since each run_code() call
        creates a fresh sandbox, add_shares() simply updates internal state
        and the next run_code() picks it up.

        MountShare / CopyShare: baked into self._image.
        CloudShare: picked up by _build_volumes() via self.file_shares.
        """
        for share in shares:
            if isinstance(share, (MountShare, CopyShare)):
                new_image, _ = prepare_modal_shares(self._image, [share])
                self._image = new_image
            # CloudShare: no extra state needed; _build_volumes reads self.file_shares
        await super().add_shares(*shares)

    # ── Helpers ────────────────────────────────────────────────────────────────

    def _build_volumes(self) -> dict[str, modal.CloudBucketMount]:
        return {
            share.dest: to_modal_cloud_bucket_mount(share)
            for share in self.file_shares
            if isinstance(share, CloudShare)
        }

    def _require_app(self) -> modal.App:
        if self._app is None:
            raise RuntimeError("ModalEphemeralExecutor: call start() first")
        return self._app
