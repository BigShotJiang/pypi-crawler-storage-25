"""Modal backend — stateful persistent kernel.

Runs a Jupyter Kernel Gateway inside a Modal sandbox that stays alive
for the duration of the session. State (variables, imports) accumulates
across run_code() calls, mirroring local interactive notebook behavior.

Requires the `modal-kernel` optional dependency group:
    pip install asta-sandbox[modal-kernel]
"""

from __future__ import annotations

import logging
import secrets
from pathlib import Path
from typing import Mapping, Sequence

import modal
from modal import App, CloudBucketMount, Sandbox, Secret

from ..executor import (
    CloudShare,
    CopyShare,
    FileShare,
    MountShare,
    SandboxNotStartedError,
)
from ..images import build_modal_kernel_image, prepare_modal_shares
from ..mounts import to_modal_cloud_bucket_mount
from ._kernel_gateway import KernelGatewayBase

_log = logging.getLogger(__name__)

_DEFAULT_GATEWAY_PORT = 8888
_DEFAULT_TIMEOUT_S = 86400  # 24 hours


class ModalKernelExecutor(KernelGatewayBase):
    """Runs code in a Modal sandbox with a persistent Jupyter Kernel Gateway.

    Stateful: variable and import state accumulates across run_code() calls.
    The sandbox stays alive between calls until shutdown() is called.

    For stateless (fresh sandbox per call) execution, use ModalEphemeralExecutor.

    Args:
        app_name: Modal app name. The app is looked up or created if missing.
        sandbox_name: Optional stable name for the sandbox (for lookup/reuse).
        image: Modal image to use. Defaults to build_modal_kernel_image().
        workdir: Working directory inside the sandbox.
        environment: Environment variables for the sandbox.
        timeout: Sandbox max lifetime in seconds (default 24h).
        idle_timeout: Sandbox idle timeout in seconds.
        block_network: Whether to block network access inside the sandbox.
        secrets: Modal secrets to inject.
        gateway_port: Port the kernel gateway listens on inside the sandbox.
    """

    _GATEWAY_READY_TIMEOUT_S = 120

    def __init__(
        self,
        *,
        app_name: str = "asta-sandbox",
        sandbox_name: str | None = None,
        image: modal.Image | None = None,
        workdir: str = "/workspace",
        environment: Mapping[str, str] | None = None,
        timeout: int = _DEFAULT_TIMEOUT_S,
        idle_timeout: int | None = _DEFAULT_TIMEOUT_S,
        block_network: bool = False,
        secrets: Sequence[Secret] | None = None,
        gateway_port: int = _DEFAULT_GATEWAY_PORT,
    ) -> None:
        super().__init__()
        self.app_name = app_name
        self.sandbox_name = sandbox_name
        self.image = image or build_modal_kernel_image()
        self.workdir = workdir
        self.environment = dict(environment or {})
        self.timeout = timeout
        self.idle_timeout = idle_timeout
        self.block_network = block_network
        self.secrets = tuple(secrets or ())
        self.volumes: dict[str, CloudBucketMount] = {}
        self.gateway_port = gateway_port

        self._app: App | None = None
        self._sandbox: Sandbox | None = None
        self._gateway_token: str | None = None

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def start(self) -> None:
        if self._sandbox:
            return

        _log.info("Looking up Modal app %s", self.app_name)
        self._app = await modal.App.lookup.aio(self.app_name, create_if_missing=True)

        token = secrets.token_urlsafe(24)
        self._gateway_token = token

        entrypoint = [
            "jupyter",
            "kernelgateway",
            "--KernelGatewayApp.ip=0.0.0.0",
            f"--KernelGatewayApp.port={self.gateway_port}",
            "--KernelGatewayApp.allow_origin=*",
            f"--KernelGatewayApp.auth_token={token}",
        ]

        env: dict[str, str | None] = dict(self.environment)
        env.setdefault("JUPYTER_TOKEN", token)

        self._sandbox = await Sandbox.create.aio(
            *entrypoint,
            app=self._app,
            name=self.sandbox_name,
            image=self.image,
            env=env,
            timeout=self.timeout,
            idle_timeout=self.idle_timeout,
            workdir=self.workdir,
            block_network=self.block_network,
            secrets=self.secrets,
            volumes=self.volumes,
            encrypted_ports=[self.gateway_port],
            memory=4096,
        )
        _log.info("Modal sandbox ID: %s", self._sandbox.object_id)

        await self._exec_raw(["mkdir", "-p", self.workdir], timeout=30)

        tunnel = (await self._sandbox.tunnels.aio())[self.gateway_port]
        base_url = f"https://{tunnel.host}"
        await self._connect_to_gateway(base_url, auth_token=self._gateway_token)

        self._started = True

    async def shutdown(self) -> None:
        await self._shutdown_executor()

        if self._sandbox:
            _log.info("Terminating Modal sandbox %s", self._sandbox.object_id)
            try:
                await self._sandbox.terminate.aio()
            except Exception:
                _log.warning("Failed to terminate sandbox cleanly", exc_info=True)
            finally:
                self._sandbox = None

        self._gateway_token = None

    # ── File share API ─────────────────────────────────────────────────────────

    async def add_shares(self, *shares: FileShare) -> None:
        """Add file shares to this executor.

        Before start(): all share types are accepted and update internal state
        (image for MountShare/CopyShare, volumes for CloudShare) so the next
        start() call picks them up.

        After start(): only CopyShare is supported — copied into the live sandbox.
        MountShare and CloudShare raise ValueError (image and volumes are fixed
        once the sandbox is created).
        """
        # Validate all before applying any
        if self._started:
            for share in shares:
                if not isinstance(share, CopyShare):
                    raise ValueError(
                        f"{type(share).__name__} must be specified before the sandbox starts"
                    )
        # Apply
        for share in shares:
            if self._started:
                await self._copy_to_sandbox(share)  # type: ignore[arg-type]
            else:
                new_image, new_volumes = prepare_modal_shares(self.image, [share])
                self.image = new_image
                self.volumes.update(new_volumes)
        await super().add_shares(*shares)

    # ── Copy helpers ───────────────────────────────────────────────────────────

    async def _copy_to_sandbox(self, share: CopyShare) -> None:
        source = Path(share.source).resolve()
        if not source.exists():
            raise FileNotFoundError(f"Source {source} not found")
        await self._upload_path(source, Path(share.dest))

    async def _upload_path(self, source: Path, remote: Path) -> None:
        sandbox = self._require_sandbox()
        if source.is_dir():
            for item in source.rglob("*"):
                if item.is_dir():
                    continue
                await self._write_remote_file(sandbox, item, remote / item.relative_to(source))
        else:
            await self._write_remote_file(sandbox, source, remote)

    async def _write_remote_file(self, sandbox: Sandbox, source: Path, target: Path) -> None:
        await self._exec_raw(["mkdir", "-p", str(target.parent)], timeout=30)
        chunk_size = 512 * 1024 * 1024  # 512 MiB, safely under Modal's 1 GiB write limit
        async with await sandbox.open.aio(str(target), "wb") as handle:
            with open(source, "rb") as f:
                while chunk := f.read(chunk_size):
                    handle.write(chunk)

    # ── Infrastructure helpers ─────────────────────────────────────────────────

    async def _exec_raw(self, cmd: Sequence[str], *, timeout: int | None = None) -> None:
        sandbox = self._require_sandbox()
        process = await sandbox.exec.aio(
            *cmd,
            env=self.environment,
            timeout=timeout,
            workdir=self.workdir,
            text=True,
        )
        await process.wait.aio()

    def _require_sandbox(self) -> Sandbox:
        if self._sandbox is None:
            raise SandboxNotStartedError("ModalKernelExecutor: call start() first")
        return self._sandbox
