"""Docker-based local execution backend.

Runs code in a Docker container hosting a Jupyter Kernel Gateway.
Stateful: the kernel persists for the lifetime of the container, so
variable and import state accumulates across run_code() calls.

Requires the `docker` optional dependency group:
    pip install asta-sandbox[docker]
"""

from __future__ import annotations

import io
import logging
import secrets
import tarfile
from pathlib import Path
from typing import Mapping, Sequence

import docker
from docker.models.containers import Container
from docker.types import Mount

from ..executor import (
    CloudShare,
    CopyShare,
    FileShare,
    MountShare,
    SandboxNotStartedError,
)
from ..images import DEFAULT_DOCKER_IMAGE
from ._kernel_gateway import KernelGatewayBase

_log = logging.getLogger(__name__)

_DEFAULT_GATEWAY_PORT = 8888


class DockerExecutor(KernelGatewayBase):
    """Runs code in a Docker container with a persistent Jupyter Kernel Gateway.

    Stateful: state accumulates across run_code() calls within a session.

    Args:
        image: Docker image to use. Defaults to DEFAULT_DOCKER_IMAGE.
        name: Optional container name.
        workdir: Working directory inside the container.
        environment: Environment variables for the container.
        pull: Whether to pull the image before starting.
        host_port: Host port to map the gateway's 8888/tcp to.
        file_shares: MountShare and CopyShare only.
            MountShare: bind-mounted when the container starts.
            CopyShare: uploaded into the container right after it starts.
    """

    _GATEWAY_READY_TIMEOUT_S = 60

    def __init__(
        self,
        image: str | None = None,
        *,
        name: str | None = None,
        workdir: str = "/workspace",
        environment: Mapping[str, str] | None = None,
        pull: bool = False,
        host_port: int = _DEFAULT_GATEWAY_PORT,
    ) -> None:
        super().__init__()
        self.image = image or DEFAULT_DOCKER_IMAGE
        self.name = name
        self.workdir = workdir
        self.environment = dict(environment or {})
        self.pull = pull
        self.host_port = host_port

        self._docker: docker.DockerClient | None = None
        self._container: Container | None = None

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def start(self) -> None:
        if self._container:
            return

        self._docker = docker.from_env()

        if self.pull:
            try:
                _log.debug("Pulling Docker image %s", self.image)
                self._docker.images.pull(self.image)
            except docker.errors.APIError as exc:
                _log.warning("Failed to pull %s (%s). Falling back to local build.", self.image, exc)
                self.pull = False

        if not self.pull:
            self._ensure_image_present()

        # Build bind-mounts from MountShares
        mounts = []
        for share in self.file_shares:
            if isinstance(share, MountShare):
                source = Path(share.source).resolve()
                if not source.exists():
                    raise FileNotFoundError(f"Mount source {source} not found")
                mounts.append(Mount(
                    type="bind",
                    target=str(share.dest),
                    source=str(source),
                    read_only=True,
                ))

        env = dict(self.environment)
        if not env.get("JUPYTER_TOKEN"):
            env["JUPYTER_TOKEN"] = secrets.token_urlsafe(32)

        _log.info("Starting Docker container from %s", self.image)
        self._container = self._docker.containers.run(
            self.image,
            detach=True,
            name=self.name,
            environment=env,
            working_dir=self.workdir,
            ports={"8888/tcp": self.host_port},
            mounts=mounts or None,
        )

        base_url = f"http://127.0.0.1:{self.host_port}"
        await self._connect_to_gateway(base_url, auth_token=env["JUPYTER_TOKEN"])

        # Upload CopyShares now that the container is running
        for share in self.file_shares:
            if isinstance(share, CopyShare):
                self._copy_into_container(share)

        self._started = True

    async def shutdown(self) -> None:
        await self._shutdown_executor()

        if self._container:
            _log.info("Stopping container %s", self._container.name)
            try:
                self._container.stop()
                self._container.remove()
            except docker.errors.APIError:
                _log.warning("Failed to stop/remove container", exc_info=True)
            self._container = None

    # ── File share API ─────────────────────────────────────────────────────────

    async def add_shares(self, *shares: FileShare) -> None:
        """Add file shares to this executor.

        Before start(): MountShare and CopyShare are queued and applied
        when the container starts. CloudShare always raises NotImplementedError.

        After start(): CopyShare is copied into the running container.
        MountShare raises ValueError (can't bind-mount to a running container).
        """
        # Validate all before applying any
        for share in shares:
            if isinstance(share, CloudShare):
                raise NotImplementedError(
                    "CloudShare is not supported by DockerExecutor; contact jasond"
                )
            if self._started and isinstance(share, MountShare):
                raise ValueError(
                    "MountShare must be specified before the container starts"
                )
        for share in shares:
            if self._started and isinstance(share, CopyShare):
                self._copy_into_container(share)
        await super().add_shares(*shares)

    # ── Infrastructure helpers ─────────────────────────────────────────────────

    def _copy_into_container(self, share: CopyShare) -> None:
        source = Path(share.source).resolve()
        if not source.exists():
            raise FileNotFoundError(f"Source {source} not found")
        dest = Path(share.dest)
        self._exec_in_container(["mkdir", "-p", str(dest.parent)])
        arc = _build_tar_stream(source, dest.name)
        self._require_container().put_archive(path=str(dest.parent), data=arc.getvalue())

    def _exec_in_container(self, cmd: Sequence[str]) -> None:
        container = self._require_container()
        result = container.exec_run(cmd, workdir=self.workdir)
        if result.exit_code != 0:
            raise RuntimeError(
                f"Command {' '.join(cmd)} failed (exit {result.exit_code}): {result.output}"
            )

    def _ensure_image_present(self) -> None:
        assert self._docker is not None
        try:
            self._docker.images.get(self.image)
            return
        except docker.errors.ImageNotFound:
            pass
        self._build_local_image()

    def _build_local_image(self) -> None:
        assert self._docker is not None
        dockerfile_path = Path(__file__).resolve().parent.parent / "dockerfiles" / "kernel_gateway" / "Dockerfile"
        if not dockerfile_path.exists():
            raise FileNotFoundError(f"Kernel gateway Dockerfile not found at {dockerfile_path}")
        context_path = dockerfile_path.parent
        _log.info("Building kernel gateway image %s from %s", self.image, context_path)
        try:
            image, build_logs = self._docker.images.build(
                path=str(context_path),
                dockerfile=str(dockerfile_path.name),
                tag=self.image,
                rm=True,
            )
            for chunk in build_logs:
                line = chunk.get("stream") or chunk.get("status")
                if line:
                    _log.debug(line.strip())
        except docker.errors.BuildError as exc:
            raise RuntimeError(f"Failed to build gateway image: {exc}") from exc

    def _require_container(self) -> Container:
        if self._container is None:
            raise SandboxNotStartedError("DockerExecutor: call start() first")
        return self._container


def _build_tar_stream(source: Path, remote_name: str) -> io.BytesIO:
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w") as tar:
        tar.add(source, arcname=remote_name)
    buffer.seek(0)
    return buffer
