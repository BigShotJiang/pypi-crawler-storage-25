"""Shared base class for backends that use a Jupyter Kernel Gateway.

Both DockerExecutor and ModalKernelExecutor run a jupyter_kernel_gateway
process and talk to it over HTTP. The core execution API (run_code)
and the gateway-polling helper are identical between the two; this
module factors them out.
"""

from __future__ import annotations

import asyncio
import logging

import requests

from ..executor import (
    ExecutionResult,
    SandboxBase,
    SandboxNotStartedError,
)
from .._jupyter import (
    RemoteJupyterExecutor,
    kernel_response_to_result,
)

_log = logging.getLogger(__name__)


class KernelGatewayBase(SandboxBase):
    """Intermediate base for backends that drive a Jupyter Kernel Gateway.

    Subclasses must implement:
        start()           — spin up the underlying runtime and call
                            self._connect_to_gateway(base_url)
        shutdown()        — tear down the runtime (call _shutdown_executor()
                            first, then stop the sandbox/container)
        _do_upload_file() — write a local path into the sandbox

    Class attributes:
        _GATEWAY_READY_TIMEOUT_S — how long to poll before giving up
    """

    _GATEWAY_READY_TIMEOUT_S: int = 60  # override per subclass

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._executor: RemoteJupyterExecutor | None = None

    # ── Core API ───────────────────────────────────────────────────────────

    async def run_code(self, code: str, timeout_seconds: float | None = None) -> ExecutionResult:
        await self._ensure_started()
        response = await self._require_executor().execute(code, timeout=timeout_seconds)
        return kernel_response_to_result(response)

    # ── Gateway helpers ────────────────────────────────────────────────────

    async def _connect_to_gateway(self, base_url: str, *, auth_token: str | None = None) -> None:
        """Poll until the gateway is ready, then start the RemoteJupyterExecutor."""
        await self._wait_for_gateway(base_url)
        rje = RemoteJupyterExecutor(base_url, auth_token=auth_token)
        await rje.start()
        self._executor = rje

    async def _wait_for_gateway(self, base_url: str) -> None:
        deadline = asyncio.get_event_loop().time() + self._GATEWAY_READY_TIMEOUT_S
        while asyncio.get_event_loop().time() < deadline:
            try:
                resp = await asyncio.to_thread(
                    requests.get, f"{base_url}/api", timeout=2
                )
                # 200 = ready without auth; 401 = ready with auth enforced.
                # Either means the gateway process is up and accepting connections.
                if resp.status_code in (200, 401):
                    return
            except requests.RequestException:
                pass
            await asyncio.sleep(1)
        raise RuntimeError("Jupyter Kernel Gateway did not become ready in time")

    async def _shutdown_executor(self) -> None:
        """Gracefully stop the kernel and clear the executor reference."""
        if self._executor:
            try:
                await self._executor.shutdown()
            except Exception:
                _log.debug("Failed to shut down kernel gracefully", exc_info=True)
            finally:
                self._executor = None

    def _require_executor(self) -> RemoteJupyterExecutor:
        if self._executor is None:
            raise SandboxNotStartedError(f"{self.__class__.__name__}: call start() first")
        return self._executor
