"""IPython-backed execution helpers.

Used by InProcessExecutor (via run_cell_with_shell) and embedded inside
Modal sandboxes for ModalEphemeralExecutor (via IPythonSession).
"""

import base64
import traceback
from dataclasses import dataclass
from typing import Any

from IPython.core.interactiveshell import InteractiveShell
from IPython.utils.capture import capture_output


@dataclass(frozen=True)
class ExecutionConfig:
    """Configuration for an IPython session."""

    matplotlib_backend: str | None = "module://matplotlib_inline.backend_inline"


def _normalize_value(value: Any) -> Any:
    # Ensure outputs are JSON-safe for downstream serialization.
    if isinstance(value, bytes):
        return base64.b64encode(value).decode("ascii")
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, (list, tuple)):
        return [_normalize_value(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _normalize_value(item) for key, item in value.items()}
    return repr(value)


def _format_error(exc: BaseException | None) -> dict[str, str] | None:
    if exc is None:
        return None
    return {
        "type": type(exc).__name__,
        "message": str(exc),
        "traceback": "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)),
    }


def run_cell_with_shell(
    shell: InteractiveShell,
    code_str: str,
) -> dict[str, Any]:
    """Execute code in an existing IPython shell and return captured outputs.

    Public so InProcessExecutor can call it directly on its persistent shell.
    """
    with capture_output() as captured:
        result = shell.run_cell(code_str)

    error = result.error_before_exec or result.error_in_exec
    outputs: dict[str, Any] = {
        "stdout": captured.stdout,
        "stderr": captured.stderr,
        "rich_outputs": [],
        "success": result.success,
        "error": _format_error(error),
    }

    for display_obj in captured.outputs:
        outputs["rich_outputs"].append({k: _normalize_value(v) for k, v in display_obj.data.items()})

    return outputs


def _configure_matplotlib_backend(backend: str | None) -> None:
    if not backend:
        return
    try:
        import matplotlib
        import matplotlib_inline.backend_inline as backend_inline
    except Exception:
        return

    try:
        current = matplotlib.get_backend()
    except Exception:
        current = None

    if current == backend:
        return

    try:
        matplotlib.use(backend, force=True)
        if "matplotlib_inline.backend_inline" in backend:
            backend_inline.set_matplotlib_formats("png", "svg", "jpeg")
    except Exception:
        return


def configure_shell(
    shell: InteractiveShell,
    matplotlib_backend: str | None,
) -> None:
    """Configure matplotlib on an IPython shell.

    Public so InProcessExecutor can call this when starting up.
    """
    _configure_matplotlib_backend(matplotlib_backend)


def ensure_pip_available() -> None:
    # Bootstrap pip so %pip magic can install packages on demand.
    try:
        import pip  # noqa: F401
        return
    except Exception:
        pass
    try:
        import ensurepip
    except Exception:
        return
    try:
        ensurepip.bootstrap()
    except Exception:
        return


class IPythonSession:
    """Run code in an IPython shell.

    A single IPythonSession holds a reference to InteractiveShell.instance(),
    which is a process-level singleton. Multiple IPythonSession objects within
    the same process therefore share kernel state.

    Used by ModalEphemeralExecutor's embedded sandbox runner.
    """

    def __init__(
        self,
        *,
        matplotlib_backend: str | None = ExecutionConfig.matplotlib_backend,
    ) -> None:
        ensure_pip_available()
        self._matplotlib_backend = matplotlib_backend
        self.shell = InteractiveShell.instance()
        configure_shell(self.shell, self._matplotlib_backend)

    def run_cell(self, code_str: str) -> dict[str, Any]:
        """Run a code cell and return captured outputs."""
        return run_cell_with_shell(self.shell, code_str)
