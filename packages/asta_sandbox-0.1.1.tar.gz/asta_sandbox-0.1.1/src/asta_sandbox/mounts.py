"""Cloud bucket mount helpers.

Converts a CloudShare into the appropriate Modal construct, keeping callers
decoupled from modal-specific types.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import modal

from .executor import CloudShare


def to_modal_cloud_bucket_mount(share: CloudShare) -> "modal.CloudBucketMount":
    """Convert a CloudShare to a modal.CloudBucketMount.

    Normalises the key_prefix to always end with a trailing slash, which
    Modal requires for directory-scoped mounts.

    For GCS buckets, set CloudShare.bucket_endpoint_url to the GCS
    S3-compatible endpoint: "https://storage.googleapis.com"
    """
    import modal

    key_prefix = share.key_prefix if share.key_prefix.endswith("/") else f"{share.key_prefix}/"
    kwargs: dict = {
        "bucket_name": share.bucket,
        "key_prefix": key_prefix,
        "read_only": share.read_only,
    }
    if share.bucket_endpoint_url is not None:
        kwargs["bucket_endpoint_url"] = share.bucket_endpoint_url
    if share.modal_secret is not None:
        kwargs["secret"] = share.modal_secret
    if share.oidc_auth_role_arn is not None:
        kwargs["oidc_auth_role_arn"] = share.oidc_auth_role_arn

    return modal.CloudBucketMount(**kwargs)
