"""arc_avs_sdk.runtime — Live state of an initialized SDK.

Holds the schema, adapter, processors, registered keys, and the per-user nonce
sequence. The runtime is the dispatcher for every operation primitive
(create_user, put_record, read, list, process, purge_user, export_user, etc).

Apps acquire a runtime via :func:`init` and then talk to it through async
methods that mirror the TS SDK surface 1:1, in Python idiom (snake_case).

Two key-custody modes:

* ``key_custody="server"`` (default) — runtime generates and holds each user's
  ML-KEM-768 keypair. Backend can decrypt records on demand. Simpler for
  prototyping and for apps where the server is already trusted with plaintext
  (e.g. a managed account model). The keypair is in-memory only; production
  servers will want to wrap a KMS or write durable storage.

* ``key_custody="client"`` — non-custodial. The user's KEM secret key never
  reaches the backend. The frontend (e.g. a browser SDK derived from a wallet
  PRF) seals envelopes locally and ships *envelope bytes* to the backend; the
  backend persists them, commits proofs to the validator network, and serves
  them back as ciphertext on read. Decryption only happens client-side. The
  Python SDK exposes ``register_user`` / ``persist_envelope`` / ``fetch_envelope``
  for this mode and refuses ``read`` / ``process`` / ``export_user`` (which
  would require the secret key the server doesn't have).
"""

from __future__ import annotations

import json
import secrets
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any, Generic, Literal, TypeVar

from eth_hash.auto import keccak

from .adapter.base import AdapterRecord, IndexedQuery, PointQuery, StorageAdapter
from .encryption import (
    CipherEnvelope,
    DsaKeypair,
    KemKeypair,
    bytes_to_hex,
    dsa_keygen,
    ecdsa_public_key,
    hex_to_bytes,
    kem_keygen,
    open_envelope,
    random_bytes,
    seal_envelope,
)
from .processor.base import Processor, ProcessorInput
from .proof import BuildProofInput, PrivacyProof, build_proof
from .router.base import NoopValidatorRouter, ValidatorRouter
from .schema import SchemaDescriptor, canonicalize_schema
from .types import AppId, ReadContext, UserHandle, RecordRef


KeyCustody = Literal["server", "client"]


class ClientCustodyError(RuntimeError):
    """Raised when a server-decrypting method is called in client-custody mode.

    In ``key_custody="client"`` mode the runtime never receives the user's KEM
    secret key, so methods that require decryption (``read``, ``process``,
    ``export_user``) cannot run server-side. Callers should fetch envelope
    bytes via ``fetch_envelope`` and decrypt on the client (TS SDK
    ``openEnvelope`` is the canonical decoder).
    """


T = TypeVar("T")


@dataclass(slots=True)
class HoldOnce(Generic[T]):
    """Plaintext valid for a single ``await use(fn)`` call. Buffer wiped on exit.

    The plaintext cannot be extracted as a raw value; callers pass an async
    callback that the runtime invokes once. After ``use`` returns, the
    underlying ``bytearray`` is overwritten in place.
    """

    context_id: ReadContext
    _plaintext: bytearray | None
    _decoder: Callable[[bytes], T]

    async def use(self, fn: Callable[[T], Awaitable[Any] | Any]) -> Any:
        if self._plaintext is None:
            raise RuntimeError("arc/holdonce: already used or wiped")
        try:
            decoded = self._decoder(bytes(self._plaintext))
            res = fn(decoded)
            if hasattr(res, "__await__"):
                res = await res
            return res
        finally:
            for i in range(len(self._plaintext)):
                self._plaintext[i] = 0
            self._plaintext = None


@dataclass(slots=True)
class _UserKey:
    """Per-user KEM keypair material held by the runtime."""

    handle: UserHandle
    kem: KemKeypair


@dataclass(slots=True)
class _UserPubkey:
    """Just the public side — used in client-custody mode where the runtime
    never sees the user's secret key."""

    handle: UserHandle
    kem_public_key: bytes


@dataclass(slots=True)
class ArcRuntime:
    """The dispatcher every user-data op routes through."""

    app_id: AppId
    schema: SchemaDescriptor
    schema_hash: str
    adapter: StorageAdapter
    router: ValidatorRouter
    processors: dict[str, Processor]
    app_ecdsa_private_key: bytes
    app_ml_dsa_keypair: DsaKeypair
    key_custody: KeyCustody = "server"
    _users: dict[str, _UserKey] = field(default_factory=dict)
    _user_pubkeys: dict[str, _UserPubkey] = field(default_factory=dict)
    _nonce_seqs: dict[str, int] = field(default_factory=dict)

    # ── Custody guards ─────────────────────────────────────────────

    def _require_server_custody(self, op: str) -> None:
        if self.key_custody != "server":
            raise ClientCustodyError(
                f"arc/{op}: not available in client-custody mode. "
                f"In client-custody the user's KEM secret key never reaches "
                f"the backend. Fetch the envelope via fetch_envelope() and "
                f"decrypt client-side (TS SDK openEnvelope)."
            )

    def _require_client_custody(self, op: str) -> None:
        if self.key_custody != "client":
            raise RuntimeError(
                f"arc/{op}: only available in client-custody mode. "
                f"Pass key_custody='client' to init() to use the "
                f"non-custodial flow."
            )

    # ── User lifecycle ──────────────────────────────────────────────

    async def create_user(
        self,
        class_name: str,
        profile: dict[str, Any],
    ) -> tuple[UserHandle, PrivacyProof]:
        """Provision a fresh ML-KEM-768 keypair for a new user. Returns the
        opaque handle + the privacy proof for the create operation.

        Server-custody only — the runtime generates and holds the keypair.
        For non-custodial flows, derive the keypair on the client and call
        :meth:`register_user` instead.
        """
        self._require_server_custody("create_user")
        kp = kem_keygen()
        handle = UserHandle(id="ar_" + secrets.token_hex(8))
        self._users[handle.id] = _UserKey(handle=handle, kem=kp)
        self._nonce_seqs[handle.id] = 0

        # Seal the profile so the create op has a canonical post-state.
        seq = self._next_nonce(handle)
        env = seal_envelope(
            plaintext=_canonical_bytes(profile),
            user_kem_public_key=kp.public_key,
            app_ecdsa_private_key=self.app_ecdsa_private_key,
            app_ml_dsa_private_key=self.app_ml_dsa_keypair.secret_key,
            app_id=self.app_id,
            class_name=class_name,
            nonce_seq=seq,
        )
        rid = "u:" + handle.id
        await self.adapter.put(
            AdapterRecord(
                id=rid,
                user_handle_id=handle.id,
                class_name=class_name,
                index_fields={},
                public_fields={"created_at": int(time.time())},
                envelope=env,
            )
        )
        proof = await self._proof_and_attest(
            "CREATE",
            class_name=class_name,
            nonce_seq=seq,
            pre_state_hash=_zero_hash(),
            post_state_hash=bytes_to_hex(keccak(env.ciphertext)),
            delta=env.aad,
        )
        return handle, proof

    # ── Client-custody surface (non-custodial mode) ────────────────

    def register_user(
        self,
        handle: UserHandle | str,
        user_kem_public_key: bytes,
    ) -> UserHandle:
        """Register a client-derived user identity with the runtime.

        Client-custody only. The handle is whatever opaque ID the client
        chose (typically derived deterministically from a wallet PRF). The
        public key wraps per-record AES keys that only the client's secret
        can unwrap. The runtime uses the public key on subsequent
        ``persist_envelope`` and ``fetch_envelope`` calls but never sees
        the secret.
        """
        self._require_client_custody("register_user")
        h = handle if isinstance(handle, UserHandle) else UserHandle(id=handle)
        self._user_pubkeys[h.id] = _UserPubkey(handle=h, kem_public_key=user_kem_public_key)
        self._nonce_seqs.setdefault(h.id, 0)
        return h

    async def persist_envelope(
        self,
        user: UserHandle,
        class_name: str,
        record_kind: str,
        envelope: CipherEnvelope,
        index_fields: dict[str, bytes] | None = None,
    ) -> tuple[RecordRef, PrivacyProof]:
        """Store a pre-sealed envelope from the client + commit a privacy proof.

        Client-custody only. The frontend produced the envelope (TS SDK
        ``sealEnvelope`` or equivalent) using the user's KEM public key; the
        backend never sees the plaintext. ``index_fields`` are
        deterministic-encrypted bytes the client computed (already in the
        wire format the adapter expects — no re-encoding here).

        The privacy proof is signed by the *app*, not the user — the user's
        signature lives inside the envelope (sigEcdsa + sigMlDsa) and is
        independently checkable.
        """
        self._require_client_custody("persist_envelope")
        if user.id not in self._user_pubkeys:
            raise KeyError(
                f"arc/persist_envelope: user {user.id} not registered. "
                f"Call register_user() with their KEM public key first."
            )

        seq = self._next_nonce(user)
        # The client's envelope already encodes a nonce_seq inside; we use
        # that for proof continuity. If the client is a stateless function
        # (no nonce monotonicity), fall back to the runtime counter.
        proof_seq = envelope.nonce_seq if envelope.nonce_seq > 0 else seq

        rid = "r:" + secrets.token_hex(8)
        await self.adapter.put(
            AdapterRecord(
                id=rid,
                user_handle_id=user.id,
                class_name=class_name,
                index_fields=index_fields or {},
                public_fields={"created_at": int(time.time()), "kind": record_kind},
                envelope=envelope,
            )
        )
        proof = await self._proof_and_attest(
            "CREATE",
            class_name=f"{class_name}.{record_kind}",
            nonce_seq=proof_seq,
            pre_state_hash=_zero_hash(),
            post_state_hash=bytes_to_hex(keccak(envelope.ciphertext)),
            delta=envelope.aad,
        )
        return RecordRef(kind=record_kind, id=rid), proof

    async def fetch_envelope(
        self,
        user: UserHandle,
        ref: RecordRef,
    ) -> CipherEnvelope:
        """Return the raw :class:`CipherEnvelope` for client-side decryption.

        Client-custody only. Pair with the TS SDK's ``openEnvelope`` (or
        the Python ``open_envelope`` if you hold the secret key in a
        trusted-client process). The wire format produced by
        ``encode_envelope`` is byte-identical across language SDKs.
        """
        self._require_client_custody("fetch_envelope")
        record = await self._find(user.id, ref.id)
        if record is None:
            raise KeyError(f"arc/fetch_envelope: no record {ref.id}")
        return record.envelope

    # ── CRUD (server-custody) ──────────────────────────────────────

    async def put_record(
        self,
        user: UserHandle,
        class_name: str,
        record_kind: str,
        value: dict[str, Any],
        index_fields: dict[str, Any] | None = None,
    ) -> tuple[RecordRef, PrivacyProof]:
        """Encrypt + persist a record. Returns the opaque ref + privacy proof.

        Server-custody only — the runtime seals the envelope using its
        in-memory copy of the user's KEM keypair. In non-custodial flows
        use :meth:`persist_envelope` (the client seals locally and sends
        bytes).
        """
        self._require_server_custody("put_record")
        u = self._users[user.id]
        seq = self._next_nonce(user)
        env = seal_envelope(
            plaintext=_canonical_bytes(value),
            user_kem_public_key=u.kem.public_key,
            app_ecdsa_private_key=self.app_ecdsa_private_key,
            app_ml_dsa_private_key=self.app_ml_dsa_keypair.secret_key,
            app_id=self.app_id,
            class_name=f"{class_name}.{record_kind}",
            nonce_seq=seq,
        )
        rid = "r:" + secrets.token_hex(8)
        idx_enc = {k: _det_enc(str(v).encode("utf-8")) for k, v in (index_fields or {}).items()}

        await self.adapter.put(
            AdapterRecord(
                id=rid,
                user_handle_id=user.id,
                class_name=class_name,
                index_fields=idx_enc,
                public_fields={"created_at": int(time.time()), "kind": record_kind},
                envelope=env,
            )
        )
        proof = await self._proof_and_attest(
            "CREATE",
            class_name=f"{class_name}.{record_kind}",
            nonce_seq=seq,
            pre_state_hash=_zero_hash(),
            post_state_hash=bytes_to_hex(keccak(env.ciphertext)),
            delta=env.aad,
        )
        return RecordRef(kind=record_kind, id=rid), proof

    async def read(
        self,
        user: UserHandle,
        ref: RecordRef,
        context_name: str,
    ) -> HoldOnce[dict[str, Any]]:
        """Decrypt one record into a :class:`HoldOnce` closure scoped to ``context_name``.

        Server-custody only — the runtime needs the user's KEM secret key to
        decrypt. In client-custody mode the secret never reaches the backend;
        call :meth:`fetch_envelope` and decrypt with the TS SDK
        ``openEnvelope`` instead.

        The plaintext lives only inside the closure passed to ``HoldOnce.use``.
        After the closure exits, the underlying buffer is overwritten.
        """
        self._require_server_custody("read")
        u = self._users[user.id]
        record = await self._find(user.id, ref.id)
        if record is None:
            raise KeyError(f"arc/read: no record {ref.id} for user {user.id}")
        plaintext = open_envelope(envelope=record.envelope, user_kem_secret_key=u.kem.secret_key)
        buf = bytearray(plaintext)
        return HoldOnce(
            context_id=ReadContext(context_name),
            _plaintext=buf,
            _decoder=lambda b: json.loads(b.decode("utf-8")),
        )

    async def list(
        self,
        user: UserHandle,
        class_name: str,
        where: dict[str, Any] | None = None,
        limit: int | None = None,
    ) -> list[RecordRef]:
        """List records matching ``where``. Returns refs (not plaintext)."""
        idx_enc = {k: _det_enc(str(v).encode("utf-8")) for k, v in (where or {}).items()}
        records = await self.adapter.list(
            class_name,
            user.id,
            IndexedQuery(where=idx_enc, limit=limit) if where else IndexedQuery(limit=limit),
        )
        return [
            RecordRef(kind=str(r.public_fields.get("kind", "")), id=r.id) for r in records
        ]

    async def process(
        self,
        user: UserHandle,
        ref: RecordRef,
        processor_name: str,
    ) -> tuple[Any, PrivacyProof]:
        """Pass a record through a registered processor. Out-of-scope fields
        are stripped before the processor's ``invoke`` is called.

        Server-custody only — the runtime needs to decrypt the record
        before sending the in-scope fields to the processor. In
        non-custodial flows the client decrypts locally and either calls
        the processor itself or sends scoped plaintext to a separate
        relay endpoint.
        """
        self._require_server_custody("process")
        proc = self.processors.get(processor_name)
        if proc is None:
            raise KeyError(f"arc/process: processor '{processor_name}' not registered")

        u = self._users[user.id]
        record = await self._find(user.id, ref.id)
        if record is None:
            raise KeyError(f"arc/process: no record {ref.id}")
        plaintext = open_envelope(envelope=record.envelope, user_kem_secret_key=u.kem.secret_key)
        all_fields = json.loads(plaintext.decode("utf-8"))
        # Filter to declared scope only — defence in depth on top of the
        # compile-time scope guard.
        allowed = set(proc.scope) if proc.scope else set(all_fields.keys())
        scoped = {k: v for k, v in all_fields.items() if k in allowed}

        out = await proc.invoke(ProcessorInput(user_handle_id=user.id, fields=scoped))

        seq = self._next_nonce(user)
        proof = await self._proof_and_attest(
            "PROCESS",
            class_name=ref.kind,
            nonce_seq=seq,
            pre_state_hash=bytes_to_hex(keccak(record.envelope.ciphertext)),
            post_state_hash=bytes_to_hex(keccak(json.dumps(out.result, sort_keys=True).encode("utf-8"))),
            delta=str(out.id).encode("utf-8"),
            processor_id=_processor_id(processor_name),
        )
        return out.result, proof

    # ── Compliance ─────────────────────────────────────────────────

    async def purge_user(self, user: UserHandle) -> tuple[dict[str, int], PrivacyProof]:
        """GDPR Art. 17 — crypto-shred the user's records and revoke their keys.

        Available in both custody modes — purge only needs to overwrite
        the wrapped key on each record (the adapter's ``purge_user`` does
        that; no plaintext access required).
        """
        result = await self.adapter.purge_user(user.id)
        # Drop any in-memory key material we might have for this user.
        self._users.pop(user.id, None)
        self._user_pubkeys.pop(user.id, None)

        seq = self._nonce_seqs.get(user.id, 0) + 1
        self._nonce_seqs[user.id] = seq
        proof = await self._proof_and_attest(
            "PURGE",
            class_name="User",
            nonce_seq=seq,
            pre_state_hash=_zero_hash(),
            post_state_hash=_zero_hash(),
            delta=str(result["records_affected"]).encode("utf-8"),
        )
        return result, proof

    async def export_user(
        self, user: UserHandle, context_name: str
    ) -> tuple[list[dict[str, Any]], PrivacyProof]:
        """GDPR Art. 20 — return all records for the user, decrypted.

        Server-custody only — needs the secret key. In non-custodial flows
        export the *envelopes* (call ``adapter.export_user`` and stream
        their bytes to the client) and let the client decrypt with its
        own secret key.
        """
        self._require_server_custody("export_user")
        u = self._users[user.id]
        records = await self.adapter.export_user(user.id)
        decrypted: list[dict[str, Any]] = []
        for r in records:
            plain = open_envelope(envelope=r.envelope, user_kem_secret_key=u.kem.secret_key)
            decrypted.append(json.loads(plain.decode("utf-8")))

        seq = self._next_nonce(user)
        proof = await self._proof_and_attest(
            "EXPORT",
            class_name=context_name,
            nonce_seq=seq,
            pre_state_hash=_zero_hash(),
            post_state_hash=bytes_to_hex(keccak(json.dumps(decrypted, sort_keys=True).encode("utf-8"))),
            delta=str(len(decrypted)).encode("utf-8"),
        )
        return decrypted, proof

    # ── Internal helpers ───────────────────────────────────────────

    def _next_nonce(self, user: UserHandle) -> int:
        n = self._nonce_seqs.get(user.id, 0) + 1
        self._nonce_seqs[user.id] = n
        return n

    async def _find(self, user_id: str, record_id: str) -> AdapterRecord | None:
        # Without the class name we have to scan exports — only used on the
        # rare branch where the caller didn't include it. In v2 we'll require
        # it explicitly for a fast adapter.get path.
        records = await self.adapter.export_user(user_id)
        for r in records:
            if r.id == record_id:
                return r
        return None

    async def _proof_and_attest(
        self,
        op: str,
        *,
        class_name: str,
        nonce_seq: int,
        pre_state_hash: str,
        post_state_hash: str,
        delta: bytes,
        processor_id: int = 0,
    ) -> PrivacyProof:
        proof = build_proof(
            BuildProofInput(
                app_id=self.app_id,
                op=op,                      # type: ignore[arg-type]
                class_name=class_name,
                processor_id=processor_id,
                nonce_seq=nonce_seq,
                pre_state_hash=pre_state_hash,
                post_state_hash=post_state_hash,
                delta=delta,
                app_ecdsa_private_key=self.app_ecdsa_private_key,
                app_ml_dsa_private_key=self.app_ml_dsa_keypair.secret_key,
            )
        )
        return await self.router.submit(proof)


# ── init() — the canonical entry point ────────────────────────────


async def init(
    schema: SchemaDescriptor,
    *,
    adapter: StorageAdapter,
    router: ValidatorRouter | None = None,
    processors: list[Processor] | None = None,
    app_ecdsa_private_key: bytes | None = None,
    app_ml_dsa_keypair: DsaKeypair | None = None,
    app_id_override: AppId | None = None,
    key_custody: KeyCustody = "server",
) -> ArcRuntime:
    """Construct an :class:`ArcRuntime`. Mirrors the TS ``init(schema, opts)``.

    ``key_custody="server"`` (default) — runtime generates and holds each
    user's KEM keypair; backend can decrypt records on demand. Convenient
    for prototyping.

    ``key_custody="client"`` — non-custodial: the user's KEM secret stays
    on the client (typically derived from a wallet PRF). The backend
    accepts pre-sealed envelopes via ``persist_envelope`` and serves them
    back as ciphertext via ``fetch_envelope``. ``read`` / ``process`` /
    ``export_user`` raise ``ClientCustodyError`` because they need the
    secret the server doesn't have.
    """
    # Hash the schema for on-chain commitment.
    canonical = canonicalize_schema(schema)
    schema_hash = bytes_to_hex(keccak(canonical.encode("utf-8")))

    # Derive appId from the schema's domain field unless overridden.
    if app_id_override is not None:
        app_id: AppId = app_id_override
    elif schema.app_id.startswith("0x") and len(schema.app_id) == 66:
        app_id = AppId(schema.app_id)
    else:
        app_id = AppId(bytes_to_hex(keccak(schema.app_id.lower().encode("utf-8"))))

    # Initialise the adapter for the declared classes.
    await adapter.init(app_id=app_id, classes=list(schema.classes.keys()))

    # Generate app keypairs if none were supplied.
    ecdsa_sk = app_ecdsa_private_key or random_bytes(32)
    _ = ecdsa_public_key(ecdsa_sk)  # validate
    dsa_kp = app_ml_dsa_keypair or dsa_keygen()

    proc_map = {p.name: p for p in (processors or [])}

    return ArcRuntime(
        app_id=app_id,
        schema=schema,
        schema_hash=schema_hash,
        adapter=adapter,
        router=router or NoopValidatorRouter(),
        processors=proc_map,
        app_ecdsa_private_key=ecdsa_sk,
        app_ml_dsa_keypair=dsa_kp,
        key_custody=key_custody,
    )


# ── private helpers ───────────────────────────────────────────────


def _zero_hash() -> str:
    return "0x" + ("00" * 32)


def _canonical_bytes(value: dict[str, Any]) -> bytes:
    """Compact JSON bytes with sorted keys — same canonicalization as the TS SDK
    uses inside ``seal_envelope``."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _det_enc(plaintext: bytes) -> bytes:
    """Deterministic encryption stub for index columns. v1 returns
    ``keccak256(plaintext)`` truncated to 16 bytes — sufficient for equality
    lookups, not collision-free in adversarial inputs. v2 will use AES-SIV with
    a per-app key."""
    return keccak(plaintext)[:16]


def _processor_id(name: str) -> int:
    from .types import PROCESSOR_FLAGS
    return PROCESSOR_FLAGS.get(name, 0)
