"""arc_avs_sdk.schema — Schema DSL + canonicalization.

The schema is the single source of truth for what user data an app touches.
It compiles to:
  1. Pydantic models — runtime validation
  2. A canonical JSON string — hashed on-chain in ArcAppRegistry
  3. Runtime metadata — drives encryption, indexes, retention

The canonicalization MUST match the TS implementation byte-for-byte so the
on-chain hash agrees regardless of which SDK wrote the schema.
"""

from __future__ import annotations

import json
from typing import Any, Literal, TypeAlias

from pydantic import BaseModel, ConfigDict, Field

from .types import AdapterName, ComplianceName, ProcessorName

# ── Field kinds ─────────────────────────────────────────────────────


FieldKind: TypeAlias = Literal[
    # Public scalars
    "string", "number", "boolean", "bytes", "timestamp",
    # Encrypted scalars
    "encrypted-string", "encrypted-email", "encrypted-phone", "encrypted-address",
    "encrypted-ssn", "encrypted-dob", "encrypted-cardnumber", "encrypted-geolocation",
    "encrypted-health", "encrypted-bytes", "encrypted-json", "encrypted-file",
    # Composites
    "struct", "encrypted-struct", "collection", "identity",
]

QueryMode: TypeAlias = Literal["point", "indexed", "range", "aggregate", "vector"]

RetentionLiteral: TypeAlias = Literal["user-controlled", "permanent"]


class _RetentionTtl(BaseModel):
    model_config = ConfigDict(extra="forbid")
    kind: Literal["ttl"] = "ttl"
    seconds: int


class _RetentionUntil(BaseModel):
    model_config = ConfigDict(extra="forbid")
    kind: Literal["until"] = "until"
    iso: str


class _RetentionSession(BaseModel):
    model_config = ConfigDict(extra="forbid")
    kind: Literal["session"] = "session"


RetentionPolicy: TypeAlias = (
    RetentionLiteral | _RetentionTtl | _RetentionUntil | _RetentionSession
)


# ── Field descriptors ───────────────────────────────────────────────


class FieldDescriptor(BaseModel):
    """Base descriptor for a single field. ``index`` makes it queryable; on
    encrypted fields this implies deterministic-encrypted index columns."""

    model_config = ConfigDict(extra="forbid")

    kind: FieldKind
    note: str | None = None
    index: bool | None = None
    compliance: list[ComplianceName] | None = None


class StructDescriptor(FieldDescriptor):
    """Composite of fields. ``kind`` is ``"struct"`` (public) or ``"encrypted-struct"``.

    ``fields`` is typed as ``Any`` so pydantic preserves the actual subclass
    instance (``StructDescriptor`` / ``CollectionDescriptor`` / etc.) when
    serializing — the alternative would require a recursive discriminated
    union that's expensive to declare and doesn't add type safety here.
    """

    kind: Literal["struct", "encrypted-struct"]
    fields: dict[str, Any] = Field(default_factory=dict)


class CollectionDescriptor(FieldDescriptor):
    """Repeating user data — messages, transactions, posts, telemetry."""

    kind: Literal["collection"] = "collection"
    item_kind: str = Field(serialization_alias="itemKind")
    cipher: Literal["ml-kem-768+aes-256-gcm"] | None = None
    query: QueryMode
    index_fields: list[str] | None = Field(default=None, serialization_alias="indexFields")
    retention: RetentionPolicy
    e2ee: bool | None = None
    aggregate_allowed: list[Literal["count", "sum", "avg", "min", "max", "p50", "p95", "p99"]] | None = Field(
        default=None, serialization_alias="aggregateAllowed"
    )
    access_mode: Literal["row-level", "aggregate-only"] | None = Field(
        default=None, serialization_alias="accessMode"
    )
    dim: int | None = None
    similarity: Literal["cosine", "l2", "ip"] | None = None


class IdentityDescriptor(FieldDescriptor):
    """A user identity — owns a PQ keypair, holds a profile + collections.

    See :class:`StructDescriptor` for the rationale behind ``fields: dict[str, Any]``.
    """

    kind: Literal["identity"] = "identity"
    fields: dict[str, Any] = Field(default_factory=dict)


# ── Schema-level descriptor ─────────────────────────────────────────


class SchemaDescriptor(BaseModel):
    """Top-level schema. ``app_id`` may be a hex string or canonical domain."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    app_id: str = Field(serialization_alias="appId")
    compliance: list[ComplianceName]
    classes: dict[str, IdentityDescriptor]
    adapters: list[AdapterName] | None = None
    processors: list[ProcessorName] | None = None
    version: str | None = None


# ── Builder DSL — apps consume this ─────────────────────────────────


class _Encrypted:
    """Namespace bundle exposed as ``arc.encrypted``."""

    @staticmethod
    def string(note: str | None = None) -> FieldDescriptor:
        return FieldDescriptor(kind="encrypted-string", note=note)

    @staticmethod
    def email(note: str | None = None) -> FieldDescriptor:
        return FieldDescriptor(kind="encrypted-email", note=note)

    @staticmethod
    def phone(note: str | None = None) -> FieldDescriptor:
        return FieldDescriptor(kind="encrypted-phone", note=note)

    @staticmethod
    def address(note: str | None = None) -> FieldDescriptor:
        return FieldDescriptor(kind="encrypted-address", note=note)

    @staticmethod
    def ssn(note: str | None = None) -> FieldDescriptor:
        return FieldDescriptor(kind="encrypted-ssn", note=note)

    @staticmethod
    def dob(note: str | None = None) -> FieldDescriptor:
        return FieldDescriptor(kind="encrypted-dob", note=note)

    @staticmethod
    def card_number(note: str | None = None) -> FieldDescriptor:
        return FieldDescriptor(kind="encrypted-cardnumber", note=note)

    @staticmethod
    def geolocation(note: str | None = None) -> FieldDescriptor:
        return FieldDescriptor(kind="encrypted-geolocation", note=note)

    @staticmethod
    def health(note: str | None = None) -> FieldDescriptor:
        return FieldDescriptor(kind="encrypted-health", note=note)

    @staticmethod
    def bytes_(note: str | None = None) -> FieldDescriptor:
        return FieldDescriptor(kind="encrypted-bytes", note=note)

    @staticmethod
    def json_(note: str | None = None) -> FieldDescriptor:
        return FieldDescriptor(kind="encrypted-json", note=note)

    @staticmethod
    def file(note: str | None = None) -> FieldDescriptor:
        return FieldDescriptor(kind="encrypted-file", note=note)

    @staticmethod
    def struct(
        fields: dict[str, FieldDescriptor],
        *,
        compliance: list[ComplianceName] | None = None,
        note: str | None = None,
    ) -> StructDescriptor:
        return StructDescriptor(
            kind="encrypted-struct", fields=fields, note=note, compliance=compliance
        )

    @staticmethod
    def collection(**opts: Any) -> CollectionDescriptor:
        opts.setdefault("cipher", "ml-kem-768+aes-256-gcm")
        return CollectionDescriptor(**opts)


class _Arc:
    """The DSL surface — ``arc.string``, ``arc.collection``, ``arc.schema(...)``, etc."""

    encrypted = _Encrypted

    @staticmethod
    def string(note: str | None = None) -> FieldDescriptor:
        return FieldDescriptor(kind="string", note=note)

    @staticmethod
    def number(note: str | None = None) -> FieldDescriptor:
        return FieldDescriptor(kind="number", note=note)

    @staticmethod
    def boolean(note: str | None = None) -> FieldDescriptor:
        return FieldDescriptor(kind="boolean", note=note)

    @staticmethod
    def bytes_(note: str | None = None) -> FieldDescriptor:
        return FieldDescriptor(kind="bytes", note=note)

    @staticmethod
    def timestamp(note: str | None = None) -> FieldDescriptor:
        return FieldDescriptor(kind="timestamp", note=note)

    @staticmethod
    def struct(
        fields: dict[str, FieldDescriptor], note: str | None = None
    ) -> StructDescriptor:
        return StructDescriptor(kind="struct", fields=fields, note=note)

    @staticmethod
    def collection(**opts: Any) -> CollectionDescriptor:
        opts.setdefault("cipher", "ml-kem-768+aes-256-gcm")
        return CollectionDescriptor(**opts)

    @staticmethod
    def identity(fields: dict[str, FieldDescriptor]) -> IdentityDescriptor:
        return IdentityDescriptor(fields=fields)

    @staticmethod
    def schema(**kwargs: Any) -> SchemaDescriptor:
        return SchemaDescriptor(**kwargs)


arc = _Arc()


# ── Canonicalization ────────────────────────────────────────────────


def canonicalize_schema(s: SchemaDescriptor) -> str:
    """Produce a deterministic JSON string regardless of insertion order.

    Matches the TS ``JSON.stringify(s, replacer)`` byte-for-byte:
      - Object keys are sorted lexicographically at every depth.
      - Arrays preserve their original order.
      - JSON output uses no whitespace (compact separators).
      - Pydantic field aliases are honoured so ``app_id`` → ``"appId"``,
        ``item_kind`` → ``"itemKind"``, etc.
    """
    raw = s.model_dump(by_alias=True, exclude_none=True, mode="json")
    return _canonical_json(raw)


def _canonical_json(value: Any) -> str:
    """Compact JSON with sorted keys at every depth.

    ``json.dumps(..., sort_keys=True)`` already does this for nested dicts —
    but we use ``separators=(",", ":")`` so output matches TS ``JSON.stringify``
    with no spaces.
    """
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


# ── Bitfield helpers ────────────────────────────────────────────────


from .types import ADAPTER_FLAGS, COMPLIANCE, PROCESSOR_FLAGS  # noqa: E402


def compliance_bitfield(names: list[ComplianceName]) -> int:
    v = 0
    for n in names:
        v |= COMPLIANCE[n]
    return v & 0xFFFFFFFF


def adapter_bitfield(names: list[AdapterName]) -> int:
    v = 0
    for n in names:
        v |= ADAPTER_FLAGS[n]
    return v & 0xFFFFFFFF


def processor_bitfield(names: list[ProcessorName]) -> int:
    v = 0
    for n in names:
        v |= PROCESSOR_FLAGS[n]
    return v & 0xFFFFFFFF
