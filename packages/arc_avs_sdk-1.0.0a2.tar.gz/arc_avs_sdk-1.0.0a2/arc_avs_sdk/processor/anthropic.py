"""arc_avs_sdk.processor.anthropic — Claude Messages API."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

import httpx

from .base import ProcessorAttestation, ProcessorInput, ProcessorOutput


@dataclass(slots=True)
class AnthropicProcessor:
    """Anthropic Claude Messages API processor."""

    name: str = "anthropic"
    scope: tuple[str, ...] = ()
    api_key: str = ""
    model: str = "claude-haiku-4-5-20251001"
    privacy_proxy: str | None = None
    attestation: ProcessorAttestation = field(default_factory=ProcessorAttestation)

    @property
    def direction(self) -> str:
        return "redacted" if self.privacy_proxy else "plaintext"

    async def invoke(self, input_: ProcessorInput) -> ProcessorOutput:
        base = self.privacy_proxy or "https://api.anthropic.com"
        messages = input_.fields.get("messages") or [
            {"role": "user", "content": str(input_.fields.get("prompt") or input_.fields.get("content") or "")}
        ]
        body = json.dumps({"model": self.model, "max_tokens": 1024, "messages": messages})

        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.post(
                f"{base}/v1/messages",
                headers={
                    "x-api-key":         self.api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type":      "application/json",
                },
                content=body,
            )
            data: dict[str, Any] = r.json()

        text = "".join(
            c.get("text", "") for c in (data.get("content") or []) if c.get("type") == "text"
        )
        return ProcessorOutput(
            id=str(data.get("id") or f"anthropic-{id(data):x}"),
            result={"content": text, "usage": data.get("usage")},
            bytes_in=len(body),
            bytes_out=len(json.dumps(data)),
        )
