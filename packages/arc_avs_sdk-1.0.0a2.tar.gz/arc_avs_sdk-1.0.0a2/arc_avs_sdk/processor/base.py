"""arc_avs_sdk.processor.base — Processor interface.

Every external service that touches user data is wrapped by a Processor.
The runtime feeds it ``ProcessorInput`` containing only fields declared in
``scope``; everything else is unreachable.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Protocol, TypeAlias, runtime_checkable

ProcessorDirection: TypeAlias = Literal[
    "plaintext", "ciphertext", "token-only", "redacted"
]


@dataclass(frozen=True, slots=True)
class ProcessorAttestation:
    """How the processor attests its own behaviour to validators."""

    kind: Literal["tee", "audit", "self-hosted"] = "self-hosted"
    url: str | None = None
    quote: str | None = None         # TEE quote, hex


@dataclass(frozen=True, slots=True)
class ProcessorInput:
    """Inputs passed to ``invoke()``. ``fields`` only contains keys in ``scope``."""

    user_handle_id: str
    fields: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ProcessorOutput:
    """Result of an ``invoke()`` call."""

    id: str
    result: Any
    bytes_in: int = 0
    bytes_out: int = 0
    external_attestation: str | None = None


@runtime_checkable
class Processor(Protocol):
    """The interface every shipped + custom processor satisfies."""

    name: str
    scope: tuple[str, ...]
    direction: ProcessorDirection
    attestation: ProcessorAttestation

    async def invoke(self, input_: ProcessorInput) -> ProcessorOutput: ...
