"""arc_avs_sdk.processor — external service wrappers.

Each processor declares ``scope`` (allowed fields), ``direction``
(``plaintext`` / ``ciphertext`` / ``token-only`` / ``redacted``), and
``attestation`` (``tee`` / ``audit`` / ``self-hosted``). Out-of-scope fields are
physically unreachable inside ``invoke()``.
"""
