"""arc_avs_sdk.processor.nous — Nous Research / Hermes.

Defaults to the public Hermes inference endpoint; override ``privacy_proxy``
to point at a self-hosted vLLM / Hermes deployment.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

import httpx

from .base import ProcessorAttestation, ProcessorInput, ProcessorOutput


@dataclass(slots=True)
class NousProcessor:
    """Nous Hermes chat-completions processor."""

    name: str = "nous"
    scope: tuple[str, ...] = ()
    api_key: str = ""
    model: str = "Hermes-3-Llama-3.1-70B"
    privacy_proxy: str | None = None
    attestation: ProcessorAttestation = field(default_factory=ProcessorAttestation)

    @property
    def direction(self) -> str:
        return "redacted" if self.privacy_proxy else "plaintext"

    async def invoke(self, input_: ProcessorInput) -> ProcessorOutput:
        base = self.privacy_proxy or "https://inference-api.nousresearch.com"
        messages = input_.fields.get("messages") or [
            {"role": "user", "content": str(input_.fields.get("prompt") or input_.fields.get("content") or "")}
        ]
        body = json.dumps({"model": self.model, "messages": messages})

        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.post(
                f"{base}/v1/chat/completions",
                headers={
                    "authorization": f"Bearer {self.api_key}",
                    "content-type":  "application/json",
                },
                content=body,
            )
            data: dict[str, Any] = r.json()

        choices = data.get("choices") or []
        first = choices[0] if choices else {}
        text = (first.get("message") or {}).get("content") or ""
        return ProcessorOutput(
            id=str(data.get("id") or f"nous-{id(data):x}"),
            result={"content": text, "usage": data.get("usage")},
            bytes_in=len(body),
            bytes_out=len(json.dumps(data)),
        )
