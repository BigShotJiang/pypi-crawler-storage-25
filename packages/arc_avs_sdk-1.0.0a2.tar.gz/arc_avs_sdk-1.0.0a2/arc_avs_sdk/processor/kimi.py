"""arc_avs_sdk.processor.kimi — Kimi K2 / Moonshot AI.

Moonshot's API is OpenAI-compatible at api.moonshot.ai (global) or
api.moonshot.cn. Pick via ``region`` or override with ``privacy_proxy``.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

import httpx

from .base import ProcessorAttestation, ProcessorInput, ProcessorOutput


@dataclass(slots=True)
class KimiProcessor:
    """Kimi K2 (Moonshot) chat-completions processor."""

    name: str = "kimi"
    scope: tuple[str, ...] = ()
    api_key: str = ""
    model: str = "kimi-k2-0711-preview"
    region: Literal["global", "cn"] = "global"
    privacy_proxy: str | None = None
    attestation: ProcessorAttestation = field(default_factory=ProcessorAttestation)

    @property
    def direction(self) -> str:
        return "redacted" if self.privacy_proxy else "plaintext"

    async def invoke(self, input_: ProcessorInput) -> ProcessorOutput:
        base = self.privacy_proxy or (
            "https://api.moonshot.cn" if self.region == "cn" else "https://api.moonshot.ai"
        )
        messages = input_.fields.get("messages") or [
            {"role": "user", "content": str(input_.fields.get("prompt") or input_.fields.get("content") or "")}
        ]
        body = json.dumps({"model": self.model, "messages": messages})

        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.post(
                f"{base}/v1/chat/completions",
                headers={
                    "authorization": f"Bearer {self.api_key}",
                    "content-type":  "application/json",
                },
                content=body,
            )
            data: dict[str, Any] = r.json()

        choices = data.get("choices") or []
        first = choices[0] if choices else {}
        text = (first.get("message") or {}).get("content") or ""
        return ProcessorOutput(
            id=str(data.get("id") or f"kimi-{id(data):x}"),
            result={"content": text, "usage": data.get("usage")},
            bytes_in=len(body),
            bytes_out=len(json.dumps(data)),
        )
