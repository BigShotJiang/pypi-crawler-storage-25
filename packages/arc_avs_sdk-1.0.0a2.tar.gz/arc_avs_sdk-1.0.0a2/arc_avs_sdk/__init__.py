"""arc-avs-sdk — ARC privacy framework for Python.

PQ-encrypted, attested, validator-anchored data layer for any application.
Mirrors the ``@arc-avs/sdk`` TypeScript package; envelopes and proof digests
are byte-compatible across language stacks.

Quick start::

    import asyncio
    from arc_avs_sdk import arc, init
    from arc_avs_sdk.adapter.memory import MemoryAdapter

    schema = arc.schema(
        app_id     = "your-app.com",
        compliance = ["GDPR"],
        classes    = {
            "User": arc.identity({
                "profile": arc.encrypted.struct({
                    "email": arc.encrypted.email(),
                }),
            }),
        },
    )

    async def main() -> None:
        runtime = await init(schema, adapter=MemoryAdapter())
        user, _ = await runtime.create_user("User", {"email": "a@b.c"})

    asyncio.run(main())
"""

from .encryption import (
    CipherEnvelope,
    DsaKeypair,
    KemKeypair,
    aes_decrypt,
    aes_encrypt,
    bind_aad,
    bind_digest,
    bytes_to_hex,
    dsa_keygen,
    dsa_sign,
    dsa_verify,
    ecdsa_public_key,
    ecdsa_sign,
    ecdsa_verify,
    hex_to_bytes,
    kem_decapsulate,
    kem_encapsulate,
    kem_keygen,
    open_envelope,
    random_bytes,
    seal_envelope,
    wipe,
)
from .adapter._shared import (
    decode_envelope,
    encode_envelope,
    index_fields_from_json,
    index_fields_to_json,
)
from .proof import BuildProofInput, PrivacyProof, build_proof, class_id_of, proof_bind_digest
from .runtime import ArcRuntime, ClientCustodyError, HoldOnce, KeyCustody, init
from .schema import (
    CollectionDescriptor,
    FieldDescriptor,
    IdentityDescriptor,
    SchemaDescriptor,
    StructDescriptor,
    adapter_bitfield,
    arc,
    canonicalize_schema,
    compliance_bitfield,
    processor_bitfield,
)
from .types import (
    ADAPTER_FLAGS,
    COMPLIANCE,
    OP,
    PROCESSOR_FLAGS,
    AdapterName,
    AppId,
    ComplianceName,
    OpKind,
    ProcessorName,
    ReadContext,
    RecordRef,
    UserHandle,
    read_context,
)

__version__ = "1.0.0a2"

__all__ = [
    # DSL + runtime
    "arc", "init", "ArcRuntime", "HoldOnce", "KeyCustody", "ClientCustodyError",
    # Schema
    "SchemaDescriptor", "FieldDescriptor", "StructDescriptor",
    "CollectionDescriptor", "IdentityDescriptor",
    "canonicalize_schema",
    "compliance_bitfield", "adapter_bitfield", "processor_bitfield",
    # Crypto
    "CipherEnvelope", "KemKeypair", "DsaKeypair",
    "kem_keygen", "kem_encapsulate", "kem_decapsulate",
    "dsa_keygen", "dsa_sign", "dsa_verify",
    "ecdsa_sign", "ecdsa_verify", "ecdsa_public_key",
    "aes_encrypt", "aes_decrypt",
    "seal_envelope", "open_envelope",
    "bind_aad", "bind_digest",
    "random_bytes", "wipe",
    "hex_to_bytes", "bytes_to_hex",
    # Wire format (cross-language envelope handoff)
    "encode_envelope", "decode_envelope",
    "index_fields_to_json", "index_fields_from_json",
    # Proof
    "PrivacyProof", "BuildProofInput", "build_proof",
    "class_id_of", "proof_bind_digest",
    # Types
    "AppId", "UserHandle", "RecordRef", "ReadContext", "read_context",
    "OP", "OpKind",
    "COMPLIANCE", "ComplianceName",
    "ADAPTER_FLAGS", "AdapterName",
    "PROCESSOR_FLAGS", "ProcessorName",
]
