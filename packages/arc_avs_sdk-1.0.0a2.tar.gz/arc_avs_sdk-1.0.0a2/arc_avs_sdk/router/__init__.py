"""arc_avs_sdk.router — validator routers.

Routers submit privacy proofs to ``PrivacyTaskManager`` on-chain and surface
the resulting attestation. The :class:`NoopValidatorRouter` is the
zero-network default (useful for tests / dry-runs); :class:`Web3ValidatorRouter`
is the production submitter.
"""

from .base import NoopValidatorRouter, ValidatorRouter
from .web3_router import Web3ValidatorRouter

__all__ = ["ValidatorRouter", "NoopValidatorRouter", "Web3ValidatorRouter"]
