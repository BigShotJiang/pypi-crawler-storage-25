"""arc_avs_sdk.router.web3_router — web3.py-backed PrivacyTaskManager submitter.

Calls ``createTaskForApp(AppTaskContext, inputHash, preStateHash, postStateHash,
delta, sigEcdsa, sigMlDsa)`` on the deployed PrivacyTaskManager. Polls for the
``TaskCreated`` and ``TaskAttested`` events; populates the proof's attestation
trail when the K-of-N quorum lands.

``web3`` is a runtime extra (``pip install arc-avs-sdk[chain]``).
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Any

from ..encryption import hex_to_bytes
from ..proof import PrivacyProof
from ..types import OP


# Minimal ABI fragment — only what the router needs.
_TASK_MANAGER_ABI: list[dict[str, Any]] = [
    {
        "name": "createTaskForApp",
        "type": "function",
        "stateMutability": "nonpayable",
        "inputs": [
            {
                "name": "ctx",
                "type": "tuple",
                "components": [
                    {"name": "appId",       "type": "bytes32"},
                    {"name": "op",          "type": "uint32"},
                    {"name": "classId",     "type": "uint32"},
                    {"name": "processorId", "type": "uint32"},
                    {"name": "nonceSeq",    "type": "uint64"},
                ],
            },
            {"name": "inputHash",     "type": "bytes32"},
            {"name": "preStateHash",  "type": "bytes32"},
            {"name": "postStateHash", "type": "bytes32"},
            {"name": "delta",         "type": "bytes"},
            {"name": "sigEcdsa",      "type": "bytes"},
            {"name": "sigMlDsa",      "type": "bytes"},
        ],
        "outputs": [{"name": "taskIndex", "type": "uint32"}],
    },
    {
        "name": "TaskAttested",
        "type": "event",
        "anonymous": False,
        "inputs": [
            {"name": "taskIndex", "type": "uint32",  "indexed": True},
            {"name": "operator",  "type": "address", "indexed": True},
            {
                "name": "attestation",
                "type": "tuple",
                "indexed": False,
                "components": [
                    {"name": "inputHash",     "type": "bytes32"},
                    {"name": "outputHash",    "type": "bytes32"},
                    {"name": "postStateHash", "type": "bytes32"},
                    {"name": "timestamp",     "type": "uint64"},
                    {"name": "dataRetained",  "type": "bool"},
                ],
            },
        ],
    },
]


@dataclass(slots=True)
class Web3ValidatorRouter:
    """Submits proofs via web3.py. The submitter EOA pays gas; the contract
    aggregates K-of-N validator attestations on-chain."""

    rpc_url: str
    private_key: str
    task_manager: str
    poll_interval: float = 4.0
    poll_timeout:  float = 120.0

    async def submit(self, proof: PrivacyProof) -> PrivacyProof:
        try:
            from web3 import Web3            # type: ignore[import-not-found]
            from web3.middleware import construct_sign_and_send_raw_middleware  # type: ignore[import-not-found]
        except ImportError as e:
            raise RuntimeError(
                "arc/router: 'web3' not installed. Run: pip install web3"
            ) from e

        w3 = Web3(Web3.HTTPProvider(self.rpc_url))
        acct = w3.eth.account.from_key(self.private_key)
        w3.middleware_onion.add(construct_sign_and_send_raw_middleware(acct))
        contract = w3.eth.contract(
            address=Web3.to_checksum_address(self.task_manager),
            abi=_TASK_MANAGER_ABI,
        )

        ctx = (
            hex_to_bytes(proof.app_id),
            OP[proof.op],
            proof.class_id,
            proof.processor_id,
            proof.nonce_seq,
        )

        # web3.py is sync; run the blocking calls in a thread.
        loop = asyncio.get_running_loop()

        def _send() -> str:
            tx_hash = contract.functions.createTaskForApp(
                ctx,
                hex_to_bytes(proof.input_hash),
                hex_to_bytes(proof.pre_state_hash),
                hex_to_bytes(proof.post_state_hash),
                b"",                                          # delta carried in inputHash for v1
                hex_to_bytes(proof.sig_ecdsa),
                hex_to_bytes(proof.sig_ml_dsa),
            ).transact({"from": acct.address})
            return tx_hash.hex()

        tx_hash = await loop.run_in_executor(None, _send)
        proof.attestation_tx_hash = "0x" + tx_hash if not tx_hash.startswith("0x") else tx_hash

        # Poll for TaskAttested matching this proof's input_hash.
        deadline = time.time() + self.poll_timeout
        validators: list[str] = []

        def _scan_attestations() -> tuple[list[str], int | None]:
            event = contract.events.TaskAttested
            from_block = max(w3.eth.block_number - 64, 0)
            logs = event().get_logs(fromBlock=from_block)
            ops: list[str] = []
            attested_at: int | None = None
            for log in logs:
                att = log["args"]["attestation"]
                if att[0].hex().lower().lstrip("0x") == proof.input_hash.lower().lstrip("0x"):
                    ops.append(log["args"]["operator"])
                    attested_at = int(att[3])
            return ops, attested_at

        while time.time() < deadline:
            validators, attested_at = await loop.run_in_executor(None, _scan_attestations)
            if validators:
                proof.validators = validators
                proof.attested_at = attested_at
                break
            await asyncio.sleep(self.poll_interval)

        return proof
