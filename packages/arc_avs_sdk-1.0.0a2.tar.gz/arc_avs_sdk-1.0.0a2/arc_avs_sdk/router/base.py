"""arc_avs_sdk.router.base — ValidatorRouter Protocol + Noop default."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from ..proof import PrivacyProof


@runtime_checkable
class ValidatorRouter(Protocol):
    """Submit a :class:`PrivacyProof` for validator attestation."""

    async def submit(self, proof: PrivacyProof) -> PrivacyProof:
        """Return the proof with attestation_tx_hash / validators / attested_at populated."""
        ...


class NoopValidatorRouter:
    """No-op router. Returns the proof unchanged. Default for tests."""

    async def submit(self, proof: PrivacyProof) -> PrivacyProof:
        return proof
