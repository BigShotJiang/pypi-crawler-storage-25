"""arc_avs_sdk.proof — Privacy proof bundles.

Every operation through arc produces a :class:`PrivacyProof`. The bundle is
what the validator network signs and what ``/verify/<appId>`` indexes.

The :func:`proof_bind_digest` byte layout MUST match the TS implementation —
the on-chain ``inputHash`` recorded by ``PrivacyTaskManager`` is computed from
this digest, and validators reject anything whose digest doesn't reproduce.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

from eth_hash.auto import keccak

from .encryption import (
    bytes_to_hex,
    dsa_sign,
    ecdsa_sign,
    hex_to_bytes,
)
from .types import OP, AppId, OpKind


@dataclass(slots=True)
class PrivacyProof:
    """Local proof + on-chain attestation tail.

    Fields up through ``sig_ml_dsa`` are filled by :func:`build_proof`.
    The trailing fields (``attestation_tx_hash``, ``validators``,
    ``attested_at``) are populated when the validator router lands the task.
    """

    # ── App commitment ──────────────────────────────────────
    app_id: AppId
    op: OpKind
    class_name: str
    class_id: int           # truncated keccak256 of class_name → uint32
    processor_id: int       # bit position from PROCESSOR_FLAGS, 0 if none
    nonce_seq: int          # monotonic per (app_id, requester)
    timestamp: int          # unix seconds

    # ── Cryptographic envelope hashes ───────────────────────
    input_hash: str
    pre_state_hash: str
    post_state_hash: str
    delta_hash: str

    # ── App signatures (ECDSA + ML-DSA-65) ─────────────────
    sig_ecdsa: str
    sig_ml_dsa: str

    # ── Validator network attestation (filled later) ───────
    attestation_tx_hash: str | None = None
    validators: list[str] = field(default_factory=list)
    attested_at: int | None = None


@dataclass(frozen=True, slots=True)
class BuildProofInput:
    """Inputs to :func:`build_proof`. Mirrors the TS ``BuildProofInput``."""

    app_id: AppId
    op: OpKind
    class_name: str
    nonce_seq: int
    pre_state_hash: str
    post_state_hash: str
    delta: bytes              # public delta (the only non-hash payload)
    app_ecdsa_private_key: bytes
    app_ml_dsa_private_key: bytes
    processor_id: int = 0


def class_id_of(class_name: str) -> int:
    """Truncate keccak256(class_name) to a uint32. Matches the on-chain id."""
    h = keccak(class_name.encode("utf-8"))
    return int.from_bytes(h[:4], "big") & 0xFFFFFFFF


def proof_bind_digest(
    *,
    app_id: AppId,
    op: OpKind,
    class_name: str,
    processor_id: int,
    nonce_seq: int,
    pre_state_hash: str,
    post_state_hash: str,
    delta_hash: str,
    timestamp: int,
) -> str:
    """32-byte commitment that the validator task uses as ``inputHash``.

    Layout (matches TS byte-for-byte):
        app_id (32) | op (BE u32) | class_name (UTF-8) | processor_id (BE u32)
        | nonce_seq (BE u64) | pre_state_hash (32) | post_state_hash (32)
        | delta_hash (32) | timestamp (BE u64)

    Then keccak256 → ``"0x..."``.
    """
    cls = class_name.encode("utf-8")
    payload = b"".join(
        [
            hex_to_bytes(app_id),
            OP[op].to_bytes(4, "big"),
            cls,
            processor_id.to_bytes(4, "big"),
            nonce_seq.to_bytes(8, "big"),
            hex_to_bytes(pre_state_hash),
            hex_to_bytes(post_state_hash),
            hex_to_bytes(delta_hash),
            timestamp.to_bytes(8, "big"),
        ]
    )
    return bytes_to_hex(keccak(payload))


def build_proof(input_: BuildProofInput) -> PrivacyProof:
    """Sign the bind digest with ECDSA + ML-DSA-65 and return a complete proof."""
    timestamp = int(time.time())
    cls_id = class_id_of(input_.class_name)
    delta_hash = bytes_to_hex(keccak(input_.delta))

    digest_hex = proof_bind_digest(
        app_id=input_.app_id,
        op=input_.op,
        class_name=input_.class_name,
        processor_id=input_.processor_id,
        nonce_seq=input_.nonce_seq,
        pre_state_hash=input_.pre_state_hash,
        post_state_hash=input_.post_state_hash,
        delta_hash=delta_hash,
        timestamp=timestamp,
    )
    digest = hex_to_bytes(digest_hex)

    sig_ecdsa = ecdsa_sign(input_.app_ecdsa_private_key, digest)
    sig_ml_dsa = dsa_sign(input_.app_ml_dsa_private_key, digest)

    return PrivacyProof(
        app_id=input_.app_id,
        op=input_.op,
        class_name=input_.class_name,
        class_id=cls_id,
        processor_id=input_.processor_id,
        nonce_seq=input_.nonce_seq,
        timestamp=timestamp,
        input_hash=digest_hex,
        pre_state_hash=input_.pre_state_hash,
        post_state_hash=input_.post_state_hash,
        delta_hash=delta_hash,
        sig_ecdsa=bytes_to_hex(sig_ecdsa),
        sig_ml_dsa=bytes_to_hex(sig_ml_dsa),
    )
