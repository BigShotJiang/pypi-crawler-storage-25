"""arc_avs_sdk.adapter.base — StorageAdapter interface.

Every adapter implements this Protocol. The runtime is the only caller; user-
facing operations dispatch through the adapter's read/write/query primitives.

Adapters MUST:
  - Persist exactly what the runtime writes (CipherEnvelope bytes,
    deterministic-encrypted index columns where applicable).
  - Refuse single-row reads on `aggregate-only` collections.
  - Surface their canonical name as `kind` so the runtime can match the
    schema's declared adapter set.

Adapters MUST NOT:
  - Decrypt anything. Decryption is the runtime's job.
  - Mutate values mid-flight. The envelope on disk must round-trip bit-for-bit.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Protocol, TypeAlias, runtime_checkable

from ..encryption import CipherEnvelope

AdapterKind: TypeAlias = Literal[
    "indexeddb", "opfs", "sqlite", "sqlcipher",
    "postgres", "mysql", "cloudflareD1",
    "redis", "timescale", "clickhouse",
    "mongo", "dynamodb", "firestore",
    "pgvector", "pinecone", "weaviate",
    "neo4j",
    "s3", "r2", "gcs", "azureblob",
    "bigquery", "snowflake",
    "memory",
    "custom",
]


@dataclass(frozen=True, slots=True)
class AdapterRecord:
    """Row-level encrypted record + its public index columns.

    The runtime serializes a full :class:`CipherEnvelope` and a small
    deterministic-encrypted index map; the adapter just stores them.
    """

    id: str
    user_handle_id: str
    class_name: str
    index_fields: dict[str, bytes] = field(default_factory=dict)   # detEnc(field_value)
    public_fields: dict[str, object] = field(default_factory=dict) # ts, status, etc.
    envelope: CipherEnvelope = field(default_factory=lambda: CipherEnvelope())


@dataclass(frozen=True, slots=True)
class PointQuery:
    id: str


@dataclass(frozen=True, slots=True)
class IndexedQuery:
    where: dict[str, bytes] = field(default_factory=dict)
    limit: int | None = None
    order_by: str | None = None
    desc: bool = False


@dataclass(frozen=True, slots=True)
class RangeQuery:
    field: str
    from_ct: bytes | None = None
    to_ct: bytes | None = None
    limit: int | None = None


@dataclass(frozen=True, slots=True)
class VectorQuery:
    vector_ct: bytes
    top_k: int


@dataclass(frozen=True, slots=True)
class AggregateQuery:
    fn: Literal["count", "sum", "avg", "min", "max", "p50", "p95", "p99"]
    field: str | None = None
    bucket_from: float | None = None
    bucket_to: float | None = None


@dataclass(frozen=True, slots=True)
class AggregateResult:
    value: float
    count: int
    epsilon_spent: float = 0.0   # DP budget consumed


@runtime_checkable
class StorageAdapter(Protocol):
    """Interface every adapter implements. All methods are async."""

    kind: AdapterKind

    async def init(self, *, app_id: str, classes: list[str]) -> None: ...
    async def put(self, record: AdapterRecord) -> None: ...
    async def get(
        self, class_name: str, user_handle_id: str, id: str
    ) -> AdapterRecord | None: ...
    async def list(
        self,
        class_name: str,
        user_handle_id: str,
        q: IndexedQuery | PointQuery,
    ) -> list[AdapterRecord]: ...
    async def delete(
        self, class_name: str, user_handle_id: str, id: str
    ) -> None: ...
    async def purge_user(self, user_handle_id: str) -> dict[str, int]:
        """Crypto-shred all records for a user. Return ``{"records_affected": n}``.

        Adapters do NOT need to actually delete the rows — overwriting the
        ``wrappedKey`` with random bytes makes them undecryptable, which
        satisfies GDPR Article 17 and HIPAA's destruction requirement.
        """
        ...

    async def export_user(self, user_handle_id: str) -> list[AdapterRecord]: ...
    # range / vector / aggregate are optional — adapters that support them
    # define them; the runtime feature-detects via hasattr().
