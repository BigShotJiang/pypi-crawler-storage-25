"""arc_avs_sdk.adapter.postgres — Postgres adapter (asyncpg-backed).

Layout (one table per declared class, prefixed ``arc_``):

  CREATE TABLE arc_<class> (
      id            TEXT  PRIMARY KEY,
      user_handle   TEXT  NOT NULL,
      envelope      BYTEA NOT NULL,
      index_fields  JSONB NOT NULL,         -- { "field": "<hex>" } detEnc
      public_fields JSONB NOT NULL,
      nonce_seq     BIGINT NOT NULL,
      created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
  );
  CREATE INDEX ON arc_<class> (user_handle);
  CREATE INDEX ON arc_<class> USING GIN (index_fields jsonb_path_ops);

Index columns are deterministic-encrypted hex strings; equality lookups use
the GIN containment operator (``@>``) which hits the index.

``asyncpg`` is a runtime extra (``pip install arc-avs-sdk[postgres]``).
"""

from __future__ import annotations

import json
from typing import Any, Literal

from ..encryption import CipherEnvelope, random_bytes
from .base import AdapterRecord, IndexedQuery, PointQuery
from ._shared import (
    decode_envelope,
    encode_envelope,
    index_fields_from_json,
    index_fields_to_json,
)


class PostgresAdapter:
    """asyncpg-backed Postgres adapter. Lazily constructs its connection pool."""

    kind: Literal["postgres"] = "postgres"

    def __init__(
        self,
        *,
        dsn: str | None = None,
        pool: Any | None = None,        # asyncpg.Pool — late-imported
        prefix: str = "arc_",
    ) -> None:
        self._dsn = dsn
        self._pool = pool
        self._prefix = prefix

    async def init(self, *, app_id: str, classes: list[str]) -> None:
        _ = app_id
        if self._pool is None:
            try:
                import asyncpg  # type: ignore[import-not-found]
            except ImportError as e:  # pragma: no cover - exercised in real env
                raise RuntimeError(
                    "arc/postgres: 'asyncpg' not installed. Run: pip install asyncpg"
                ) from e
            if not self._dsn:
                raise ValueError("arc/postgres: dsn or pool is required")
            self._pool = await asyncpg.create_pool(self._dsn)

        async with self._pool.acquire() as conn:                     # type: ignore[union-attr]
            for c in classes:
                t = self._table(c)
                await conn.execute(
                    f"""
                    CREATE TABLE IF NOT EXISTS "{t}" (
                        id            TEXT  PRIMARY KEY,
                        user_handle   TEXT  NOT NULL,
                        envelope      BYTEA NOT NULL,
                        index_fields  JSONB NOT NULL,
                        public_fields JSONB NOT NULL,
                        nonce_seq     BIGINT NOT NULL,
                        created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
                    );
                    """
                )
                await conn.execute(f'CREATE INDEX IF NOT EXISTS "{t}_user_idx" ON "{t}" (user_handle);')
                await conn.execute(
                    f'CREATE INDEX IF NOT EXISTS "{t}_idx_gin" ON "{t}" USING GIN (index_fields jsonb_path_ops);'
                )

    def _table(self, class_name: str) -> str:
        return f"{self._prefix}{class_name.replace('.', '__')}"

    async def put(self, record: AdapterRecord) -> None:
        t = self._table(record.class_name)
        env = encode_envelope(record.envelope)
        idx = index_fields_to_json(record.index_fields)
        async with self._pool.acquire() as conn:                      # type: ignore[union-attr]
            await conn.execute(
                f"""
                INSERT INTO "{t}" (id, user_handle, envelope, index_fields, public_fields, nonce_seq)
                VALUES ($1, $2, $3, $4::jsonb, $5::jsonb, $6)
                ON CONFLICT (id) DO UPDATE SET
                    envelope      = EXCLUDED.envelope,
                    index_fields  = EXCLUDED.index_fields,
                    public_fields = EXCLUDED.public_fields,
                    nonce_seq     = EXCLUDED.nonce_seq;
                """,
                record.id,
                record.user_handle_id,
                env,
                json.dumps(idx),
                json.dumps(record.public_fields),
                record.envelope.nonce_seq,
            )

    async def get(
        self, class_name: str, user_handle_id: str, id: str
    ) -> AdapterRecord | None:
        t = self._table(class_name)
        async with self._pool.acquire() as conn:                      # type: ignore[union-attr]
            row = await conn.fetchrow(
                f'SELECT envelope, index_fields, public_fields FROM "{t}" WHERE id = $1 AND user_handle = $2',
                id, user_handle_id,
            )
        if row is None:
            return None
        return self._materialize(class_name, user_handle_id, id, row)

    async def list(
        self,
        class_name: str,
        user_handle_id: str,
        q: IndexedQuery | PointQuery,
    ) -> list[AdapterRecord]:
        if isinstance(q, PointQuery):
            r = await self.get(class_name, user_handle_id, q.id)
            return [r] if r else []

        t = self._table(class_name)
        contain = json.dumps(index_fields_to_json(q.where))
        sql = (
            f'SELECT id, envelope, index_fields, public_fields FROM "{t}" '
            f'WHERE user_handle = $1 AND index_fields @> $2::jsonb'
        )
        params: list[Any] = [user_handle_id, contain]
        if q.order_by:
            sql += f' ORDER BY public_fields->>{q.order_by!r} {"DESC" if q.desc else "ASC"}'
        if q.limit is not None:
            sql += f' LIMIT {int(q.limit)}'
        async with self._pool.acquire() as conn:                      # type: ignore[union-attr]
            rows = await conn.fetch(sql, *params)
        return [
            self._materialize(class_name, user_handle_id, str(row["id"]), row) for row in rows
        ]

    async def delete(self, class_name: str, user_handle_id: str, id: str) -> None:
        t = self._table(class_name)
        async with self._pool.acquire() as conn:                      # type: ignore[union-attr]
            await conn.execute(
                f'DELETE FROM "{t}" WHERE id = $1 AND user_handle = $2',
                id, user_handle_id,
            )

    async def purge_user(self, user_handle_id: str) -> dict[str, int]:
        # Crypto-shred: overwrite the wrappedKey region of every envelope blob.
        # Cheaper alternative: NULL the envelope and let the row stand as a
        # tombstone. We pick the shred path so the row count + nonce sequence
        # remain auditable.
        n = 0
        # We don't know all class tables ahead of time per-call; iterate
        # information_schema. This is fine for purge-user since it's a rare op.
        async with self._pool.acquire() as conn:                      # type: ignore[union-attr]
            tables = await conn.fetch(
                "SELECT tablename FROM pg_tables WHERE tablename LIKE $1",
                f"{self._prefix}%",
            )
            for t in tables:
                table = str(t["tablename"])
                rows = await conn.fetch(
                    f'SELECT id, envelope FROM "{table}" WHERE user_handle = $1',
                    user_handle_id,
                )
                for r in rows:
                    env = decode_envelope(bytes(r["envelope"]))
                    shredded = encode_envelope(
                        CipherEnvelope(
                            v=env.v,
                            cipher=env.cipher,
                            wrapped_key=random_bytes(len(env.wrapped_key)),
                            nonce=env.nonce,
                            ciphertext=env.ciphertext,
                            aad=env.aad,
                            sig_ecdsa=env.sig_ecdsa,
                            sig_ml_dsa=env.sig_ml_dsa,
                            nonce_seq=env.nonce_seq,
                        )
                    )
                    await conn.execute(
                        f'UPDATE "{table}" SET envelope = $1 WHERE id = $2',
                        shredded, str(r["id"]),
                    )
                    n += 1
        return {"records_affected": n}

    async def export_user(self, user_handle_id: str) -> list[AdapterRecord]:
        out: list[AdapterRecord] = []
        async with self._pool.acquire() as conn:                      # type: ignore[union-attr]
            tables = await conn.fetch(
                "SELECT tablename FROM pg_tables WHERE tablename LIKE $1",
                f"{self._prefix}%",
            )
            for t in tables:
                table = str(t["tablename"])
                cls = table[len(self._prefix):].replace("__", ".")
                rows = await conn.fetch(
                    f'SELECT id, envelope, index_fields, public_fields FROM "{table}" WHERE user_handle = $1',
                    user_handle_id,
                )
                for r in rows:
                    out.append(
                        self._materialize(cls, user_handle_id, str(r["id"]), r)
                    )
        return out

    # ── private helpers ─────────────────────────────────────────────

    def _materialize(
        self, class_name: str, user_handle_id: str, id: str, row: Any
    ) -> AdapterRecord:
        env = decode_envelope(bytes(row["envelope"]))
        idx = index_fields_from_json(json.loads(row["index_fields"]))
        pub = json.loads(row["public_fields"])
        return AdapterRecord(
            id=id,
            user_handle_id=user_handle_id,
            class_name=class_name,
            index_fields=idx,
            public_fields=pub,
            envelope=env,
        )
