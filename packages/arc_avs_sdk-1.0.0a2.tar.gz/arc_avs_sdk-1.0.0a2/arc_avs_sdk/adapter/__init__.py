"""arc_avs_sdk.adapter — storage adapter implementations.

Adapters are imported lazily; only `from arc_avs_sdk.adapter.memory import MemoryAdapter`
forces the cost. This mirrors how the TS SDK uses subpath imports so apps don't
pay the bundle cost of every backend driver.
"""
