"""arc_avs_sdk.adapter._shared — Shared envelope serialization.

Mirrors ``packages/sdk/src/adapter/_shared.ts`` byte-for-byte. The flat-buffer
layout is what every adapter writes (postgres BYTEA, mongo Binary, redis
string, neo4j base64, etc.) so an envelope sealed by the TS SDK can be opened
by the Python SDK and vice-versa.
"""

from __future__ import annotations

from ..encryption import CipherEnvelope


# Wire format (matches TS):
#   [0..1]   v
#   [1..2]   cipher tag (0x01 = ml-kem-768+aes-256-gcm)
#   [2..10]  nonce_seq (BE u64)
#   [10..14] wrapped_key length (BE u32) → wrapped_key bytes
#   [..]      nonce (12 bytes)
#   [..]      ciphertext length (BE u32) → ciphertext bytes
#   [..]      aad length (BE u32) → aad bytes
#   [..]      sig_ecdsa length (BE u32) → sig_ecdsa bytes
#   [..]      sig_ml_dsa length (BE u32) → sig_ml_dsa bytes


_CIPHER_TAG = 0x01


def encode_envelope(env: CipherEnvelope) -> bytes:
    """Serialize a CipherEnvelope to the cross-language flat buffer."""
    parts: list[bytes] = []

    head = bytearray(2 + 8)
    head[0] = env.v
    head[1] = _CIPHER_TAG
    head[2:10] = env.nonce_seq.to_bytes(8, "big")
    parts.append(bytes(head))

    parts.append(len(env.wrapped_key).to_bytes(4, "big"))
    parts.append(env.wrapped_key)
    parts.append(env.nonce)                                # always 12 bytes
    parts.append(len(env.ciphertext).to_bytes(4, "big"))
    parts.append(env.ciphertext)
    parts.append(len(env.aad).to_bytes(4, "big"))
    parts.append(env.aad)
    parts.append(len(env.sig_ecdsa).to_bytes(4, "big"))
    parts.append(env.sig_ecdsa)
    parts.append(len(env.sig_ml_dsa).to_bytes(4, "big"))
    parts.append(env.sig_ml_dsa)
    return b"".join(parts)


def decode_envelope(buf: bytes) -> CipherEnvelope:
    """Inverse of :func:`encode_envelope`. Raises ``ValueError`` on bad input."""
    if len(buf) < 10:
        raise ValueError("arc/envelope: buffer too short")
    v = buf[0]
    cipher_tag = buf[1]
    if cipher_tag != _CIPHER_TAG:
        raise ValueError(f"arc/envelope: unknown cipher tag {cipher_tag:#x}")
    nonce_seq = int.from_bytes(buf[2:10], "big")
    o = 10

    wrapped_len, o = _read_len(buf, o)
    wrapped_key, o = _slice(buf, o, wrapped_len)
    nonce, o = _slice(buf, o, 12)
    ct_len, o = _read_len(buf, o)
    ciphertext, o = _slice(buf, o, ct_len)
    aad_len, o = _read_len(buf, o)
    aad, o = _slice(buf, o, aad_len)
    ecdsa_len, o = _read_len(buf, o)
    sig_ecdsa, o = _slice(buf, o, ecdsa_len)
    dsa_len, o = _read_len(buf, o)
    sig_ml_dsa, o = _slice(buf, o, dsa_len)

    return CipherEnvelope(
        v=v,                              # type: ignore[arg-type]
        cipher="ml-kem-768+aes-256-gcm",
        wrapped_key=wrapped_key,
        nonce=nonce,
        ciphertext=ciphertext,
        aad=aad,
        sig_ecdsa=sig_ecdsa,
        sig_ml_dsa=sig_ml_dsa,
        nonce_seq=nonce_seq,
    )


# ── Index field helpers ──────────────────────────────────────────────


def index_fields_to_json(idx: dict[str, bytes]) -> dict[str, str]:
    """Convert deterministic-encrypted index fields to JSON-safe hex strings."""
    return {k: v.hex() for k, v in idx.items()}


def index_fields_from_json(idx: dict[str, str]) -> dict[str, bytes]:
    """Inverse of :func:`index_fields_to_json`."""
    return {k: bytes.fromhex(v) for k, v in idx.items()}


# ── private helpers ──────────────────────────────────────────────────


def _read_len(buf: bytes, o: int) -> tuple[int, int]:
    if o + 4 > len(buf):
        raise ValueError("arc/envelope: truncated length prefix")
    return int.from_bytes(buf[o : o + 4], "big"), o + 4


def _slice(buf: bytes, o: int, n: int) -> tuple[bytes, int]:
    if o + n > len(buf):
        raise ValueError("arc/envelope: truncated payload")
    return buf[o : o + n], o + n
