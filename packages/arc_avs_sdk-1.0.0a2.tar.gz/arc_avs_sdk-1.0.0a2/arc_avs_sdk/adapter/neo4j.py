"""arc_avs_sdk.adapter.neo4j — Graph-native, agent-memory / RAG aware.

Why a graph adapter at all: agentic RAG stitches user history into model
context every turn. Stock graph drivers store every fragment in plaintext and
let any retrieval cross the model boundary. This adapter writes the same
:class:`CipherEnvelope` bytes that postgres / mongo / redis write — so every
retrieval is encrypted at rest, decryption only happens inside a HoldOnce
closure, and ``purge_user`` crypto-shreds the wrapped keys.

Layout (one node label per declared class, prefixed ``Arc``):

  (:ArcUser   { user_handle })
  (:ArcRecord:Arc<Class> {
      id, class, user_handle, envelope (base64),
      index_fields ({ fieldName: '<hex>' } detEnc),
      public_fields, nonce_seq, created_at
  })
  (u:ArcUser)-[:OWNS]->(r:ArcRecord:Arc<Class>)

``neo4j`` is a runtime extra (``pip install arc-avs-sdk[neo4j]``).
"""

from __future__ import annotations

import base64
import json
from typing import Any, Literal

from ..encryption import CipherEnvelope, random_bytes
from .base import AdapterRecord, IndexedQuery, PointQuery
from ._shared import (
    decode_envelope,
    encode_envelope,
    index_fields_from_json,
    index_fields_to_json,
)


class Neo4jAdapter:
    """neo4j-driver async adapter."""

    kind: Literal["neo4j"] = "neo4j"

    def __init__(
        self,
        *,
        url: str | None = None,
        username: str | None = None,
        password: str | None = None,
        database: str | None = None,
        driver: Any | None = None,    # neo4j.AsyncDriver
        prefix: str = "Arc",
    ) -> None:
        self._url = url
        self._username = username
        self._password = password
        self._database = database
        self._driver = driver
        self._prefix = prefix

    async def init(self, *, app_id: str, classes: list[str]) -> None:
        _ = app_id
        if self._driver is None:
            try:
                from neo4j import AsyncGraphDatabase  # type: ignore[import-not-found]
            except ImportError as e:
                raise RuntimeError(
                    "arc/neo4j: 'neo4j' not installed. Run: pip install neo4j"
                ) from e
            if not self._url:
                raise ValueError("arc/neo4j: url or driver is required")
            auth = (
                (self._username, self._password)
                if self._username and self._password
                else None
            )
            self._driver = AsyncGraphDatabase.driver(self._url, auth=auth)

        async with self._session() as s:
            await s.run(
                f"CREATE CONSTRAINT arc_record_id IF NOT EXISTS "
                f"FOR (r:{self._prefix}Record) REQUIRE r.id IS UNIQUE"
            )
            await s.run(
                f"CREATE INDEX arc_user_handle IF NOT EXISTS "
                f"FOR (u:{self._prefix}User) ON (u.user_handle)"
            )
            await s.run(
                f"CREATE INDEX arc_record_user IF NOT EXISTS "
                f"FOR (r:{self._prefix}Record) ON (r.user_handle)"
            )
            for c in classes:
                lbl = self._class_label(c)
                await s.run(
                    f"CREATE INDEX arc_{lbl}_idx IF NOT EXISTS "
                    f"FOR (r:{lbl}) ON (r.user_handle)"
                )

    def _class_label(self, class_name: str) -> str:
        safe = "".join(ch if ch.isalnum() else "_" for ch in class_name)
        return f"{self._prefix}{safe}"

    def _session(self) -> Any:
        return self._driver.session(database=self._database)         # type: ignore[union-attr]

    async def put(self, record: AdapterRecord) -> None:
        env = base64.b64encode(encode_envelope(record.envelope)).decode("ascii")
        idx = index_fields_to_json(record.index_fields)
        async with self._session() as s:
            await s.run(
                f"""
                MERGE (u:{self._prefix}User {{ user_handle: $u }})
                WITH u
                MERGE (r:{self._prefix}Record:{self._class_label(record.class_name)} {{ id: $id }})
                SET r.user_handle   = $u,
                    r.class         = $cls,
                    r.envelope      = $env,
                    r.index_fields  = $idx,
                    r.public_fields = $pub,
                    r.nonce_seq     = $seq,
                    r.created_at    = coalesce(r.created_at, datetime())
                MERGE (u)-[:OWNS]->(r)
                """,
                u=record.user_handle_id,
                id=record.id,
                cls=record.class_name,
                env=env,
                idx=json.dumps(idx),
                pub=json.dumps(record.public_fields),
                seq=record.envelope.nonce_seq,
            )

    async def get(
        self, class_name: str, user_handle_id: str, id: str
    ) -> AdapterRecord | None:
        async with self._session() as s:
            res = await s.run(
                f"MATCH (r:{self._class_label(class_name)} {{ id: $id, user_handle: $u }}) "
                f"RETURN r LIMIT 1",
                id=id, u=user_handle_id,
            )
            rec = await res.single()
        if rec is None:
            return None
        return self._materialize(class_name, dict(rec["r"]))

    async def list(
        self,
        class_name: str,
        user_handle_id: str,
        q: IndexedQuery | PointQuery,
    ) -> list[AdapterRecord]:
        if isinstance(q, PointQuery):
            r = await self.get(class_name, user_handle_id, q.id)
            return [r] if r else []

        where = ["r.user_handle = $u"]
        params: dict[str, Any] = {"u": user_handle_id}
        for i, (k, v) in enumerate(q.where.items()):
            params[f"idx_{i}"] = f'"{k}":"{v.hex()}"'
            where.append(f"r.index_fields CONTAINS $idx_{i}")
        params["lim"] = q.limit if q.limit is not None else 50

        async with self._session() as s:
            res = await s.run(
                f"MATCH (r:{self._class_label(class_name)}) "
                f"WHERE {' AND '.join(where)} "
                f"RETURN r ORDER BY r.created_at DESC LIMIT $lim",
                **params,
            )
            records = [self._materialize(class_name, dict(rec["r"])) async for rec in res]
        return records

    async def delete(self, class_name: str, user_handle_id: str, id: str) -> None:
        async with self._session() as s:
            await s.run(
                f"MATCH (r:{self._class_label(class_name)} {{ id: $id, user_handle: $u }}) "
                f"DETACH DELETE r",
                id=id, u=user_handle_id,
            )

    async def purge_user(self, user_handle_id: str) -> dict[str, int]:
        n = 0
        async with self._session() as s:
            res = await s.run(
                f"MATCH (r:{self._prefix}Record {{ user_handle: $u }}) RETURN r",
                u=user_handle_id,
            )
            async for rec in res:
                props = dict(rec["r"])
                env = decode_envelope(base64.b64decode(props["envelope"]))
                shredded = base64.b64encode(
                    encode_envelope(
                        CipherEnvelope(
                            v=env.v,
                            cipher=env.cipher,
                            wrapped_key=random_bytes(len(env.wrapped_key)),
                            nonce=env.nonce,
                            ciphertext=env.ciphertext,
                            aad=env.aad,
                            sig_ecdsa=env.sig_ecdsa,
                            sig_ml_dsa=env.sig_ml_dsa,
                            nonce_seq=env.nonce_seq,
                        )
                    )
                ).decode("ascii")
                await s.run(
                    f"MATCH (r:{self._prefix}Record {{ id: $id }}) "
                    f"SET r.envelope = $env, r.purged_at = datetime()",
                    id=props["id"], env=shredded,
                )
                n += 1
        return {"records_affected": n}

    async def export_user(self, user_handle_id: str) -> list[AdapterRecord]:
        out: list[AdapterRecord] = []
        async with self._session() as s:
            res = await s.run(
                f"MATCH (r:{self._prefix}Record {{ user_handle: $u }}) "
                f"RETURN r ORDER BY r.created_at",
                u=user_handle_id,
            )
            async for rec in res:
                props = dict(rec["r"])
                cls = str(props.get("class", ""))
                if not cls:
                    continue
                out.append(self._materialize(cls, props))
        return out

    async def close(self) -> None:
        await self._driver.close()                                    # type: ignore[union-attr]

    def _materialize(self, class_name: str, props: dict[str, Any]) -> AdapterRecord:
        env = decode_envelope(base64.b64decode(str(props["envelope"])))
        idx = index_fields_from_json(json.loads(str(props.get("index_fields") or "{}")))
        pub = json.loads(str(props.get("public_fields") or "{}"))
        return AdapterRecord(
            id=str(props["id"]),
            user_handle_id=str(props["user_handle"]),
            class_name=class_name,
            index_fields=idx,
            public_fields=pub,
            envelope=env,
        )
