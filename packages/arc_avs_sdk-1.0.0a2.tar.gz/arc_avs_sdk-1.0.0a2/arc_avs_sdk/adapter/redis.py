"""arc_avs_sdk.adapter.redis — Redis adapter (redis-py async).

Layout uses one HASH per record + a SET per user for fast user-scoped lookups
+ a SET per (user, indexField, value) for indexed lookups:

  arc:r:<class>:<id>      → HASH { envelope, index_fields, public_fields, nonce_seq, user_handle }
  arc:u:<user>             → SET of "<class>:<id>"
  arc:i:<class>:<key>:<hex> → SET of record ids matching that index field/value

``redis`` is a runtime extra (``pip install arc-avs-sdk[redis]``).
"""

from __future__ import annotations

import json
from typing import Any, Literal

from ..encryption import CipherEnvelope, random_bytes
from .base import AdapterRecord, IndexedQuery, PointQuery
from ._shared import (
    decode_envelope,
    encode_envelope,
    index_fields_from_json,
    index_fields_to_json,
)


class RedisAdapter:
    """redis-py async adapter."""

    kind: Literal["redis"] = "redis"

    def __init__(
        self,
        *,
        url: str | None = None,
        client: Any | None = None,    # redis.asyncio.Redis
        prefix: str = "arc",
    ) -> None:
        self._url = url
        self._client = client
        self._prefix = prefix

    async def init(self, *, app_id: str, classes: list[str]) -> None:
        _ = app_id, classes
        if self._client is None:
            try:
                from redis.asyncio import Redis  # type: ignore[import-not-found]
            except ImportError as e:
                raise RuntimeError(
                    "arc/redis: 'redis' not installed. Run: pip install redis"
                ) from e
            if not self._url:
                raise ValueError("arc/redis: url or client is required")
            self._client = Redis.from_url(self._url)

    def _record_key(self, class_name: str, id: str) -> str:
        return f"{self._prefix}:r:{class_name}:{id}"

    def _user_set(self, user: str) -> str:
        return f"{self._prefix}:u:{user}"

    def _index_set(self, class_name: str, key: str, hex_value: str) -> str:
        return f"{self._prefix}:i:{class_name}:{key}:{hex_value}"

    async def put(self, record: AdapterRecord) -> None:
        env = encode_envelope(record.envelope)
        idx = index_fields_to_json(record.index_fields)
        rkey = self._record_key(record.class_name, record.id)
        pipe = self._client.pipeline()
        pipe.hset(
            rkey,
            mapping={
                "envelope":      env,
                "index_fields":  json.dumps(idx),
                "public_fields": json.dumps(record.public_fields),
                "nonce_seq":     str(record.envelope.nonce_seq),
                "user_handle":   record.user_handle_id,
                "class_name":    record.class_name,
            },
        )
        pipe.sadd(self._user_set(record.user_handle_id), f"{record.class_name}:{record.id}")
        for k, hex_v in idx.items():
            pipe.sadd(self._index_set(record.class_name, k, hex_v), record.id)
        await pipe.execute()

    async def get(
        self, class_name: str, user_handle_id: str, id: str
    ) -> AdapterRecord | None:
        rkey = self._record_key(class_name, id)
        data = await self._client.hgetall(rkey)
        if not data:
            return None
        if data.get(b"user_handle") != user_handle_id.encode("utf-8"):
            return None
        return self._materialize(class_name, id, data)

    async def list(
        self,
        class_name: str,
        user_handle_id: str,
        q: IndexedQuery | PointQuery,
    ) -> list[AdapterRecord]:
        if isinstance(q, PointQuery):
            r = await self.get(class_name, user_handle_id, q.id)
            return [r] if r else []
        sets = [
            self._index_set(class_name, k, v.hex()) for k, v in q.where.items()
        ]
        ids: set[bytes]
        if not sets:
            user_members: set[bytes] = await self._client.smembers(self._user_set(user_handle_id))
            ids = {m.split(b":", 1)[1] for m in user_members if m.startswith(class_name.encode() + b":")}
        else:
            ids = await self._client.sinter(*sets)

        out: list[AdapterRecord] = []
        for raw_id in ids:
            id_str = raw_id.decode("utf-8") if isinstance(raw_id, (bytes, bytearray)) else str(raw_id)
            r = await self.get(class_name, user_handle_id, id_str)
            if r is not None:
                out.append(r)
        if q.limit is not None:
            out = out[: q.limit]
        return out

    async def delete(self, class_name: str, user_handle_id: str, id: str) -> None:
        rkey = self._record_key(class_name, id)
        data = await self._client.hgetall(rkey)
        if not data:
            return
        idx = index_fields_from_json(json.loads(data.get(b"index_fields", b"{}")))
        pipe = self._client.pipeline()
        pipe.delete(rkey)
        pipe.srem(self._user_set(user_handle_id), f"{class_name}:{id}")
        for k, v in idx.items():
            pipe.srem(self._index_set(class_name, k, v.hex()), id)
        await pipe.execute()

    async def purge_user(self, user_handle_id: str) -> dict[str, int]:
        members: set[bytes] = await self._client.smembers(self._user_set(user_handle_id))
        n = 0
        for m in members:
            cls, _, rid = m.decode("utf-8").partition(":")
            rkey = self._record_key(cls, rid)
            data = await self._client.hgetall(rkey)
            if not data:
                continue
            env = decode_envelope(bytes(data[b"envelope"]))
            shredded = encode_envelope(
                CipherEnvelope(
                    v=env.v,
                    cipher=env.cipher,
                    wrapped_key=random_bytes(len(env.wrapped_key)),
                    nonce=env.nonce,
                    ciphertext=env.ciphertext,
                    aad=env.aad,
                    sig_ecdsa=env.sig_ecdsa,
                    sig_ml_dsa=env.sig_ml_dsa,
                    nonce_seq=env.nonce_seq,
                )
            )
            await self._client.hset(rkey, mapping={"envelope": shredded})
            n += 1
        return {"records_affected": n}

    async def export_user(self, user_handle_id: str) -> list[AdapterRecord]:
        members: set[bytes] = await self._client.smembers(self._user_set(user_handle_id))
        out: list[AdapterRecord] = []
        for m in members:
            cls, _, rid = m.decode("utf-8").partition(":")
            r = await self.get(cls, user_handle_id, rid)
            if r is not None:
                out.append(r)
        return out

    def _materialize(self, class_name: str, id: str, data: dict[bytes, bytes]) -> AdapterRecord:
        env = decode_envelope(bytes(data[b"envelope"]))
        idx = index_fields_from_json(json.loads(data.get(b"index_fields", b"{}")))
        pub = json.loads(data.get(b"public_fields", b"{}"))
        return AdapterRecord(
            id=id,
            user_handle_id=data[b"user_handle"].decode("utf-8"),
            class_name=class_name,
            index_fields=idx,
            public_fields=pub,
            envelope=env,
        )
