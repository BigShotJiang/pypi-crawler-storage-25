"""arc_avs_sdk.adapter.memory — in-process adapter for tests / quick starts.

Stores everything in dictionaries. Useful for unit tests, REPL exploration, and
the SDK README's quick-start example. Not durable across processes.
"""

from __future__ import annotations

from typing import Literal

from ..encryption import CipherEnvelope, random_bytes
from .base import AdapterRecord, IndexedQuery, PointQuery


class MemoryAdapter:
    """In-process storage. Records are keyed ``(class_name, user, id)``."""

    kind: Literal["memory"] = "memory"

    def __init__(self) -> None:
        self._rows: dict[tuple[str, str, str], AdapterRecord] = {}

    async def init(self, *, app_id: str, classes: list[str]) -> None:
        # Memory adapter has no schema to provision.
        _ = app_id, classes

    async def put(self, record: AdapterRecord) -> None:
        self._rows[(record.class_name, record.user_handle_id, record.id)] = record

    async def get(
        self, class_name: str, user_handle_id: str, id: str
    ) -> AdapterRecord | None:
        return self._rows.get((class_name, user_handle_id, id))

    async def list(
        self,
        class_name: str,
        user_handle_id: str,
        q: IndexedQuery | PointQuery,
    ) -> list[AdapterRecord]:
        if isinstance(q, PointQuery):
            row = await self.get(class_name, user_handle_id, q.id)
            return [row] if row else []
        out: list[AdapterRecord] = []
        for (cls, user, _id), r in self._rows.items():
            if cls != class_name or user != user_handle_id:
                continue
            if all(r.index_fields.get(k) == v for k, v in q.where.items()):
                out.append(r)
        if q.order_by:
            out.sort(
                key=lambda r: r.public_fields.get(q.order_by, 0),  # type: ignore[arg-type, return-value]
                reverse=q.desc,
            )
        if q.limit is not None:
            out = out[: q.limit]
        return out

    async def delete(
        self, class_name: str, user_handle_id: str, id: str
    ) -> None:
        self._rows.pop((class_name, user_handle_id, id), None)

    async def purge_user(self, user_handle_id: str) -> dict[str, int]:
        n = 0
        for key, r in list(self._rows.items()):
            if r.user_handle_id != user_handle_id:
                continue
            # Crypto-shred: replace the wrappedKey with random bytes so the
            # original AES key is unrecoverable. The row stays so the on-chain
            # commitment trail is preserved.
            shredded = CipherEnvelope(
                v=r.envelope.v,
                cipher=r.envelope.cipher,
                wrapped_key=random_bytes(len(r.envelope.wrapped_key) or 1088),
                nonce=r.envelope.nonce,
                ciphertext=r.envelope.ciphertext,
                aad=r.envelope.aad,
                sig_ecdsa=r.envelope.sig_ecdsa,
                sig_ml_dsa=r.envelope.sig_ml_dsa,
                nonce_seq=r.envelope.nonce_seq,
            )
            self._rows[key] = AdapterRecord(
                id=r.id,
                user_handle_id=r.user_handle_id,
                class_name=r.class_name,
                index_fields=r.index_fields,
                public_fields=r.public_fields,
                envelope=shredded,
            )
            n += 1
        return {"records_affected": n}

    async def export_user(self, user_handle_id: str) -> list[AdapterRecord]:
        return [r for r in self._rows.values() if r.user_handle_id == user_handle_id]
