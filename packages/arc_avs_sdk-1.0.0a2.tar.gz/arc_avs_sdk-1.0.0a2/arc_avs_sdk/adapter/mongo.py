"""arc_avs_sdk.adapter.mongo — MongoDB adapter (motor-backed).

One collection per declared class, prefixed ``arc_``. Documents:

  {
    _id:           <record id>,
    user_handle:   <opaque user handle>,
    envelope:      Binary <encoded CipherEnvelope>,
    index_fields:  { fieldName: "<hex>" },
    public_fields: { ts: ..., status: ... },
    nonce_seq:     <int64>,
    created_at:    ISODate,
  }

Index columns are deterministic-encrypted hex strings; equality lookups use
a compound index on ``(user_handle, index_fields.<key>)``.

``motor`` is a runtime extra (``pip install arc-avs-sdk[mongo]``).
"""

from __future__ import annotations

import datetime
from typing import Any, Literal

from ..encryption import CipherEnvelope, random_bytes
from .base import AdapterRecord, IndexedQuery, PointQuery
from ._shared import (
    decode_envelope,
    encode_envelope,
    index_fields_from_json,
    index_fields_to_json,
)


class MongoAdapter:
    """motor-backed MongoDB adapter."""

    kind: Literal["mongo"] = "mongo"

    def __init__(
        self,
        *,
        url: str | None = None,
        database: str = "arc",
        client: Any | None = None,    # motor.motor_asyncio.AsyncIOMotorClient
        prefix: str = "arc_",
    ) -> None:
        self._url = url
        self._database = database
        self._client = client
        self._db: Any = None
        self._prefix = prefix

    async def init(self, *, app_id: str, classes: list[str]) -> None:
        _ = app_id
        if self._client is None:
            try:
                from motor.motor_asyncio import AsyncIOMotorClient  # type: ignore[import-not-found]
            except ImportError as e:
                raise RuntimeError(
                    "arc/mongo: 'motor' not installed. Run: pip install motor"
                ) from e
            if not self._url:
                raise ValueError("arc/mongo: url or client is required")
            self._client = AsyncIOMotorClient(self._url)
        self._db = self._client[self._database]
        for c in classes:
            coll = self._db[self._collection(c)]
            await coll.create_index("user_handle")

    def _collection(self, class_name: str) -> str:
        return f"{self._prefix}{class_name.replace('.', '__')}"

    async def put(self, record: AdapterRecord) -> None:
        coll = self._db[self._collection(record.class_name)]
        env = encode_envelope(record.envelope)
        await coll.replace_one(
            {"_id": record.id},
            {
                "_id": record.id,
                "user_handle": record.user_handle_id,
                "envelope": env,
                "index_fields": index_fields_to_json(record.index_fields),
                "public_fields": record.public_fields,
                "nonce_seq": record.envelope.nonce_seq,
                "created_at": datetime.datetime.now(datetime.timezone.utc),
            },
            upsert=True,
        )

    async def get(
        self, class_name: str, user_handle_id: str, id: str
    ) -> AdapterRecord | None:
        coll = self._db[self._collection(class_name)]
        doc = await coll.find_one({"_id": id, "user_handle": user_handle_id})
        return self._materialize(class_name, doc) if doc else None

    async def list(
        self,
        class_name: str,
        user_handle_id: str,
        q: IndexedQuery | PointQuery,
    ) -> list[AdapterRecord]:
        if isinstance(q, PointQuery):
            r = await self.get(class_name, user_handle_id, q.id)
            return [r] if r else []
        coll = self._db[self._collection(class_name)]
        filter_: dict[str, Any] = {"user_handle": user_handle_id}
        for k, v in q.where.items():
            filter_[f"index_fields.{k}"] = v.hex()
        cursor = coll.find(filter_)
        if q.order_by:
            cursor = cursor.sort(f"public_fields.{q.order_by}", -1 if q.desc else 1)
        if q.limit is not None:
            cursor = cursor.limit(q.limit)
        return [self._materialize(class_name, d) async for d in cursor]

    async def delete(self, class_name: str, user_handle_id: str, id: str) -> None:
        coll = self._db[self._collection(class_name)]
        await coll.delete_one({"_id": id, "user_handle": user_handle_id})

    async def purge_user(self, user_handle_id: str) -> dict[str, int]:
        n = 0
        # Iterate collections matching the prefix and crypto-shred per row.
        names = await self._db.list_collection_names()
        for name in [n for n in names if n.startswith(self._prefix)]:
            coll = self._db[name]
            cursor = coll.find({"user_handle": user_handle_id})
            async for doc in cursor:
                env = decode_envelope(bytes(doc["envelope"]))
                shredded = encode_envelope(
                    CipherEnvelope(
                        v=env.v,
                        cipher=env.cipher,
                        wrapped_key=random_bytes(len(env.wrapped_key)),
                        nonce=env.nonce,
                        ciphertext=env.ciphertext,
                        aad=env.aad,
                        sig_ecdsa=env.sig_ecdsa,
                        sig_ml_dsa=env.sig_ml_dsa,
                        nonce_seq=env.nonce_seq,
                    )
                )
                await coll.update_one({"_id": doc["_id"]}, {"$set": {"envelope": shredded}})
                n += 1
        return {"records_affected": n}

    async def export_user(self, user_handle_id: str) -> list[AdapterRecord]:
        out: list[AdapterRecord] = []
        names = await self._db.list_collection_names()
        for name in [n for n in names if n.startswith(self._prefix)]:
            cls = name[len(self._prefix):].replace("__", ".")
            cursor = self._db[name].find({"user_handle": user_handle_id})
            async for doc in cursor:
                out.append(self._materialize(cls, doc))
        return out

    def _materialize(self, class_name: str, doc: dict[str, Any]) -> AdapterRecord:
        env = decode_envelope(bytes(doc["envelope"]))
        idx = index_fields_from_json(doc.get("index_fields") or {})
        pub = doc.get("public_fields") or {}
        return AdapterRecord(
            id=str(doc["_id"]),
            user_handle_id=str(doc["user_handle"]),
            class_name=class_name,
            index_fields=idx,
            public_fields=pub,
            envelope=env,
        )
