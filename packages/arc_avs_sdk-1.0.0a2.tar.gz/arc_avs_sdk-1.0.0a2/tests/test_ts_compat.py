"""Pin the TS↔Python byte-level compatibility surface.

These tests build the canonical helpers (bind_aad, bind_digest,
proof_bind_digest, canonicalize_schema) against frozen inputs and assert
the exact bytes / hashes produced. The TS SDK has a parallel test in
``packages/sdk/test/`` that asserts the same fixtures — any drift in
either implementation fails CI.

If you intentionally change the wire format, update fixtures in BOTH
languages in the same commit.
"""

from __future__ import annotations

from eth_hash.auto import keccak

from arc_avs_sdk import (
    arc,
    bind_aad,
    bind_digest,
    bytes_to_hex,
    canonicalize_schema,
    class_id_of,
    proof_bind_digest,
)


def test_bind_aad_known_fixture() -> None:
    """Frozen ``(app_id, class, seq)`` → exact AAD bytes."""
    app_id = "0x" + ("11" * 32)
    aad = bind_aad(app_id, "User", 1)
    expected = (b"\x11" * 32) + b"User" + (1).to_bytes(8, "big")
    assert aad == expected


def test_bind_digest_known_fixture() -> None:
    app_id = "0x" + ("00" * 32)
    aad = bind_aad(app_id, "User", 1)
    digest = bind_digest(app_id, "User", 1, b"WK", b"N" * 12, b"CT", aad)
    expected = keccak(
        bytes(32) + b"User" + (1).to_bytes(8, "big") + b"WK" + b"N" * 12 + b"CT" + aad
    )
    assert digest == expected


def test_proof_bind_digest_known_fixture() -> None:
    """Pin the ``inputHash`` byte layout — what PrivacyTaskManager sees."""
    app_id = "0x" + ("aa" * 32)  # type: ignore[assignment]
    pre = "0x" + ("11" * 32)
    post = "0x" + ("22" * 32)
    delta = "0x" + ("33" * 32)
    h = proof_bind_digest(
        app_id=app_id,                # type: ignore[arg-type]
        op="CREATE",
        class_name="User",
        processor_id=0,
        nonce_seq=1,
        pre_state_hash=pre,
        post_state_hash=post,
        delta_hash=delta,
        timestamp=1700000000,
    )
    payload = (
        bytes.fromhex("aa" * 32)
        + (1).to_bytes(4, "big")          # op CREATE = 1
        + b"User"
        + (0).to_bytes(4, "big")          # processor_id
        + (1).to_bytes(8, "big")          # nonce_seq
        + bytes.fromhex("11" * 32)
        + bytes.fromhex("22" * 32)
        + bytes.fromhex("33" * 32)
        + (1700000000).to_bytes(8, "big")
    )
    assert h == bytes_to_hex(keccak(payload))


def test_class_id_of_known_fixture() -> None:
    """Match the on-chain ``classId`` truncation."""
    h = keccak(b"Patient.record")
    expected = int.from_bytes(h[:4], "big")
    assert class_id_of("Patient.record") == expected


def test_canonical_schema_pinned_string() -> None:
    """Tiny schema → exact canonical JSON. Any change here is a wire change."""
    s = arc.schema(
        app_id="example.com",
        compliance=["GDPR"],
        classes={
            "User": arc.identity({
                "email": arc.encrypted.email(),
            }),
        },
    )
    expected = (
        '{"appId":"example.com",'
        '"classes":{"User":{"fields":{"email":{"kind":"encrypted-email"}},"kind":"identity"}},'
        '"compliance":["GDPR"]}'
    )
    assert canonicalize_schema(s) == expected
