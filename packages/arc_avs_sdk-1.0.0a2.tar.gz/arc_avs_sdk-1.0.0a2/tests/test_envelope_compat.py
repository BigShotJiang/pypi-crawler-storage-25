"""Cross-language envelope compatibility.

These tests pin the byte layout of :func:`encode_envelope` so any drift from
the TS SDK fails CI before it can ship. The TS encoder lives at
``packages/sdk/src/adapter/_shared.ts`` — keep them in lockstep.
"""

from __future__ import annotations

from arc_avs_sdk.adapter._shared import (
    decode_envelope,
    encode_envelope,
    index_fields_from_json,
    index_fields_to_json,
)
from arc_avs_sdk.encryption import CipherEnvelope


def _sample_envelope() -> CipherEnvelope:
    return CipherEnvelope(
        v=1,
        cipher="ml-kem-768+aes-256-gcm",
        wrapped_key=bytes(range(32)),
        nonce=bytes(range(12)),
        ciphertext=b"hello arc",
        aad=b"appid|class|seq",
        sig_ecdsa=bytes(range(65)),
        sig_ml_dsa=bytes(range(80)),
        nonce_seq=42,
    )


def test_encode_decode_round_trip() -> None:
    env = _sample_envelope()
    encoded = encode_envelope(env)
    decoded = decode_envelope(encoded)
    assert decoded.v == env.v
    assert decoded.cipher == env.cipher
    assert decoded.wrapped_key == env.wrapped_key
    assert decoded.nonce == env.nonce
    assert decoded.ciphertext == env.ciphertext
    assert decoded.aad == env.aad
    assert decoded.sig_ecdsa == env.sig_ecdsa
    assert decoded.sig_ml_dsa == env.sig_ml_dsa
    assert decoded.nonce_seq == env.nonce_seq


def test_encoded_layout_matches_ts() -> None:
    """Pin the byte layout — any change here is also a TS-side breakage."""
    env = _sample_envelope()
    buf = encode_envelope(env)

    # head: v(1) | cipher_tag(1) | nonce_seq(BE u64) = 10 bytes
    assert buf[0] == 1
    assert buf[1] == 0x01
    assert int.from_bytes(buf[2:10], "big") == 42

    # wrapped_key length prefix
    assert int.from_bytes(buf[10:14], "big") == 32
    # then 32 bytes wrapped_key, then 12 bytes nonce
    assert buf[14:46] == bytes(range(32))
    assert buf[46:58] == bytes(range(12))


def test_index_fields_json_round_trip() -> None:
    raw = {"kind": b"\x01\x02\x03", "session": b"\xff\xee\xdd"}
    encoded = index_fields_to_json(raw)
    assert encoded == {"kind": "010203", "session": "ffeedd"}
    decoded = index_fields_from_json(encoded)
    assert decoded == raw
