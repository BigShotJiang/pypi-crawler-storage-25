"""Non-custodial (key_custody="client") flow tests.

Models the production split: the runtime never sees the user's KEM secret
key. The "client" half of the test seals envelopes locally; the runtime
persists them and serves them back as ciphertext on read.
"""

from __future__ import annotations

import pytest

from arc_avs_sdk import (
    ClientCustodyError,
    UserHandle,
    arc,
    decode_envelope,
    encode_envelope,
    init,
    kem_keygen,
    open_envelope,
    seal_envelope,
)
from arc_avs_sdk.adapter.memory import MemoryAdapter


@pytest.fixture
def schema():  # noqa: ANN201
    return arc.schema(
        app_id="example.com",
        compliance=["GDPR"],
        classes={
            "User": arc.identity({
                "events": arc.collection(
                    item_kind="event",
                    query="indexed",
                    index_fields=["kind"],
                    retention="permanent",
                ),
            }),
        },
    )


# ── Non-custodial round-trip ──────────────────────────────────────


async def test_client_custody_register_persist_fetch(schema) -> None:  # noqa: ANN001
    runtime = await init(schema, adapter=MemoryAdapter(), key_custody="client")

    # Client owns the keypair end-to-end. The runtime never sees secret_key.
    client_kp = kem_keygen()
    user = runtime.register_user("ar_alice", client_kp.public_key)
    assert isinstance(user, UserHandle)

    # Client seals locally with the app's signing keys (in real life the
    # client would have ECDSA + ML-DSA-65 keys derived from the wallet PRF;
    # for this test we reuse the runtime's app-side keys as a stand-in).
    plaintext = b'{"kind":"login","ts":1700000000}'
    envelope = seal_envelope(
        plaintext=plaintext,
        user_kem_public_key=client_kp.public_key,
        app_ecdsa_private_key=runtime.app_ecdsa_private_key,
        app_ml_dsa_private_key=runtime.app_ml_dsa_keypair.secret_key,
        app_id=runtime.app_id,
        class_name="User.event",
        nonce_seq=1,
    )

    ref, proof = await runtime.persist_envelope(
        user, "User", "event", envelope, index_fields={"kind": b"login"}
    )
    assert proof.op == "CREATE"
    assert ref.kind == "event"

    # Backend returns ciphertext; client decrypts.
    fetched = await runtime.fetch_envelope(user, ref)
    assert fetched.ciphertext == envelope.ciphertext

    decrypted = open_envelope(envelope=fetched, user_kem_secret_key=client_kp.secret_key)
    assert decrypted == plaintext


async def test_envelope_wire_format_round_trips(schema) -> None:  # noqa: ANN001
    """Backend-side encode → wire bytes → client-side decode → open."""
    runtime = await init(schema, adapter=MemoryAdapter(), key_custody="client")
    client_kp = kem_keygen()
    user = runtime.register_user("ar_bob", client_kp.public_key)

    envelope = seal_envelope(
        plaintext=b"hello",
        user_kem_public_key=client_kp.public_key,
        app_ecdsa_private_key=runtime.app_ecdsa_private_key,
        app_ml_dsa_private_key=runtime.app_ml_dsa_keypair.secret_key,
        app_id=runtime.app_id,
        class_name="User.event",
        nonce_seq=1,
    )
    ref, _ = await runtime.persist_envelope(user, "User", "event", envelope)
    fetched = await runtime.fetch_envelope(user, ref)

    # Simulate the over-the-wire trip: backend → bytes → client → open.
    wire = encode_envelope(fetched)
    on_client = decode_envelope(wire)
    assert open_envelope(envelope=on_client, user_kem_secret_key=client_kp.secret_key) == b"hello"


# ── Custody guards ────────────────────────────────────────────────


async def test_client_custody_refuses_create_user(schema) -> None:  # noqa: ANN001
    runtime = await init(schema, adapter=MemoryAdapter(), key_custody="client")
    with pytest.raises(ClientCustodyError):
        await runtime.create_user("User", {"name": "Alice"})


async def test_client_custody_refuses_put_record(schema) -> None:  # noqa: ANN001
    runtime = await init(schema, adapter=MemoryAdapter(), key_custody="client")
    runtime.register_user("ar_x", kem_keygen().public_key)
    with pytest.raises(ClientCustodyError):
        await runtime.put_record(UserHandle("ar_x"), "User", "event", {"k": "v"})


async def test_client_custody_refuses_read_process_export(schema) -> None:  # noqa: ANN001
    runtime = await init(schema, adapter=MemoryAdapter(), key_custody="client")
    client_kp = kem_keygen()
    user = runtime.register_user("ar_y", client_kp.public_key)
    envelope = seal_envelope(
        plaintext=b"x",
        user_kem_public_key=client_kp.public_key,
        app_ecdsa_private_key=runtime.app_ecdsa_private_key,
        app_ml_dsa_private_key=runtime.app_ml_dsa_keypair.secret_key,
        app_id=runtime.app_id,
        class_name="User.event",
        nonce_seq=1,
    )
    ref, _ = await runtime.persist_envelope(user, "User", "event", envelope)

    with pytest.raises(ClientCustodyError):
        await runtime.read(user, ref, "render")
    with pytest.raises(ClientCustodyError):
        await runtime.process(user, ref, "openai")
    with pytest.raises(ClientCustodyError):
        await runtime.export_user(user, "export")


# ── Server-custody mode unchanged ────────────────────────────────


async def test_server_custody_still_allows_create_user(schema) -> None:  # noqa: ANN001
    """Default key_custody="server" preserves the original surface."""
    runtime = await init(schema, adapter=MemoryAdapter())  # server default
    user, proof = await runtime.create_user("User", {"name": "Alice"})
    assert proof.op == "CREATE"
    # And register_user is refused in server mode.
    with pytest.raises(RuntimeError):
        runtime.register_user("ar_unused", kem_keygen().public_key)


# ── Purge works in both modes ────────────────────────────────────


async def test_purge_works_in_client_custody(schema) -> None:  # noqa: ANN001
    runtime = await init(schema, adapter=MemoryAdapter(), key_custody="client")
    client_kp = kem_keygen()
    user = runtime.register_user("ar_z", client_kp.public_key)
    envelope = seal_envelope(
        plaintext=b"x",
        user_kem_public_key=client_kp.public_key,
        app_ecdsa_private_key=runtime.app_ecdsa_private_key,
        app_ml_dsa_private_key=runtime.app_ml_dsa_keypair.secret_key,
        app_id=runtime.app_id,
        class_name="User.event",
        nonce_seq=1,
    )
    await runtime.persist_envelope(user, "User", "event", envelope)
    result, proof = await runtime.purge_user(user)
    assert result["records_affected"] >= 1
    assert proof.op == "PURGE"
