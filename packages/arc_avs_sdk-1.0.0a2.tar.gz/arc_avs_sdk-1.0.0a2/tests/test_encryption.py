"""Crypto-layer tests. Exercise every primitive, plus the bind helpers."""

from __future__ import annotations

import pytest

from arc_avs_sdk.encryption import (
    aes_decrypt,
    aes_encrypt,
    bind_aad,
    bind_digest,
    bytes_to_hex,
    dsa_keygen,
    dsa_sign,
    dsa_verify,
    ecdsa_public_key,
    ecdsa_sign,
    ecdsa_verify,
    hex_to_bytes,
    kem_decapsulate,
    kem_encapsulate,
    kem_keygen,
    open_envelope,
    random_bytes,
    seal_envelope,
)


def test_kem_keygen_and_round_trip() -> None:
    kp = kem_keygen()
    assert len(kp.public_key) == 1184
    assert len(kp.secret_key) == 2400
    ct, ss = kem_encapsulate(kp.public_key)
    assert len(ct) == 1088
    assert len(ss) == 32
    assert kem_decapsulate(kp.secret_key, ct) == ss


def test_aes_round_trip_with_aad() -> None:
    key = random_bytes(32)
    nonce = random_bytes(12)
    aad = b"app=arc"
    ct = aes_encrypt(key, nonce, b"hello world", aad)
    assert aes_decrypt(key, nonce, ct, aad) == b"hello world"


def test_aes_aad_mismatch_fails() -> None:
    from cryptography.exceptions import InvalidTag

    key = random_bytes(32)
    nonce = random_bytes(12)
    ct = aes_encrypt(key, nonce, b"hi", b"aad-A")
    with pytest.raises(InvalidTag):
        aes_decrypt(key, nonce, ct, b"aad-B")


def test_ecdsa_sign_and_verify() -> None:
    sk = random_bytes(32)
    pk = ecdsa_public_key(sk, compressed=False)
    digest = random_bytes(32)
    sig = ecdsa_sign(sk, digest)
    assert len(sig) == 65
    # Verify against the uncompressed pubkey
    assert ecdsa_verify(pk, digest, sig)


def test_dsa_sign_and_verify() -> None:
    kp = dsa_keygen()
    digest = random_bytes(32)
    sig = dsa_sign(kp.secret_key, digest)
    assert dsa_verify(kp.public_key, digest, sig)


def test_bind_aad_layout_matches_spec() -> None:
    app_id = "0x" + ("ab" * 32)
    aad = bind_aad(app_id, "Patient.record", 7)
    assert aad[:32] == hex_to_bytes(app_id)
    assert aad[32 : 32 + len("Patient.record")] == b"Patient.record"
    # last 8 bytes = big-endian uint64 nonce_seq
    seq_bytes = aad[-8:]
    assert int.from_bytes(seq_bytes, "big") == 7


def test_bind_digest_is_keccak256_of_concat() -> None:
    from eth_hash.auto import keccak

    app_id = "0x" + ("00" * 32)
    cls = "User"
    seq = 1
    wk = b"\x01" * 4
    nonce = b"\x02" * 12
    ct = b"\x03" * 16
    aad = bind_aad(app_id, cls, seq)
    digest = bind_digest(app_id, cls, seq, wk, nonce, ct, aad)

    expected = keccak(
        bytes(32) + cls.encode("utf-8") + seq.to_bytes(8, "big") + wk + nonce + ct + aad
    )
    assert digest == expected


def test_seal_open_envelope_round_trip() -> None:
    user_kem = kem_keygen()
    app_dsa = dsa_keygen()
    app_ecdsa_sk = random_bytes(32)
    plaintext = b'{"email":"a@b.c","name":"Alice"}'

    env = seal_envelope(
        plaintext=plaintext,
        user_kem_public_key=user_kem.public_key,
        app_ecdsa_private_key=app_ecdsa_sk,
        app_ml_dsa_private_key=app_dsa.secret_key,
        app_id="0x" + ("aa" * 32),
        class_name="User.profile",
        nonce_seq=1,
    )
    assert env.cipher == "ml-kem-768+aes-256-gcm"
    assert open_envelope(envelope=env, user_kem_secret_key=user_kem.secret_key) == plaintext


def test_hex_helpers() -> None:
    raw = bytes(range(32))
    assert hex_to_bytes(bytes_to_hex(raw)) == raw
    assert hex_to_bytes("0xff") == b"\xff"
