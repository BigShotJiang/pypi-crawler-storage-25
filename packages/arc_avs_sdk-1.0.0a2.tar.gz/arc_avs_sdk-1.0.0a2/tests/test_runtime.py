"""End-to-end runtime tests using the in-memory adapter."""

from __future__ import annotations

import pytest

from arc_avs_sdk import arc, init
from arc_avs_sdk.adapter.memory import MemoryAdapter


@pytest.fixture
def schema():  # noqa: ANN201
    return arc.schema(
        app_id="example.com",
        compliance=["GDPR"],
        classes={
            "User": arc.identity({
                "profile": arc.encrypted.struct({
                    "name":  arc.encrypted.string(),
                    "email": arc.encrypted.email(),
                }),
                "events": arc.collection(
                    item_kind="event",
                    query="indexed",
                    index_fields=["kind"],
                    retention="permanent",
                ),
            }),
        },
    )


async def test_create_user_and_read(schema) -> None:  # noqa: ANN001
    runtime = await init(schema, adapter=MemoryAdapter())
    user, proof = await runtime.create_user("User", {"name": "Alice", "email": "a@b.c"})
    assert user.id.startswith("ar_")
    assert proof.input_hash.startswith("0x")
    assert proof.op == "CREATE"


async def test_put_and_list(schema) -> None:  # noqa: ANN001
    runtime = await init(schema, adapter=MemoryAdapter())
    user, _ = await runtime.create_user("User", {"name": "A"})
    ref, _ = await runtime.put_record(
        user, "User", "event", {"kind": "login", "ts": 1}, index_fields={"kind": "login"}
    )
    refs = await runtime.list(user, "User", where={"kind": "login"})
    assert any(r.id == ref.id for r in refs)


async def test_export_round_trips_plaintext(schema) -> None:  # noqa: ANN001
    runtime = await init(schema, adapter=MemoryAdapter())
    user, _ = await runtime.create_user("User", {"name": "A", "email": "a@b.c"})
    await runtime.put_record(user, "User", "event", {"kind": "login"}, index_fields={"kind": "login"})
    decrypted, proof = await runtime.export_user(user, "export")
    # Profile + event = 2 records
    assert len(decrypted) == 2
    assert proof.op == "EXPORT"


async def test_purge_user_crypto_shreds(schema) -> None:  # noqa: ANN001
    runtime = await init(schema, adapter=MemoryAdapter())
    user, _ = await runtime.create_user("User", {"name": "A"})
    await runtime.put_record(user, "User", "event", {"kind": "login"})
    result, proof = await runtime.purge_user(user)
    assert result["records_affected"] >= 1
    assert proof.op == "PURGE"
