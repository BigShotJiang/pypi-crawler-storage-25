"""Schema canonicalization + bitfield tests."""

from __future__ import annotations

from eth_hash.auto import keccak

from arc_avs_sdk import (
    adapter_bitfield,
    arc,
    bytes_to_hex,
    canonicalize_schema,
    compliance_bitfield,
    processor_bitfield,
)


def _make_schema():  # noqa: ANN202
    return arc.schema(
        app_id="example.com",
        compliance=["GDPR", "CCPA"],
        classes={
            "User": arc.identity({
                "profile": arc.encrypted.struct({
                    "name":  arc.encrypted.string(),
                    "email": arc.encrypted.email(),
                }),
                "events": arc.collection(
                    item_kind="event",
                    query="indexed",
                    index_fields=["kind"],
                    retention="permanent",
                ),
            }),
        },
    )


def test_canonicalize_is_deterministic() -> None:
    s = _make_schema()
    a = canonicalize_schema(s)
    b = canonicalize_schema(s)
    assert a == b
    # Sanity: should be valid JSON with no whitespace
    assert " " not in a or '"' in a   # whitespace only inside strings
    assert "\n" not in a


def test_canonicalize_uses_field_aliases() -> None:
    """``app_id`` must serialize as ``"appId"`` so the on-chain hash agrees with the TS SDK."""
    s = _make_schema()
    raw = canonicalize_schema(s)
    assert '"appId":"example.com"' in raw
    assert '"itemKind":"event"' in raw
    assert '"indexFields":["kind"]' in raw


def test_canonicalize_keys_sorted() -> None:
    s = _make_schema()
    raw = canonicalize_schema(s)
    # appId comes before classes alphabetically; classes before compliance
    assert raw.index('"appId"') < raw.index('"classes"') < raw.index('"compliance"')


def test_schema_hash_round_trips() -> None:
    s = _make_schema()
    h = bytes_to_hex(keccak(canonicalize_schema(s).encode("utf-8")))
    assert h.startswith("0x")
    assert len(h) == 66


def test_bitfields_match_ts() -> None:
    """ADAPTER_FLAGS / PROCESSOR_FLAGS / COMPLIANCE bit positions must match the TS source."""
    assert compliance_bitfield(["GDPR", "CCPA"]) == (1 | 2)
    assert adapter_bitfield(["postgres", "neo4j"]) == ((1 << 4) | (1 << 22))
    assert processor_bitfield(["openai", "kimi"]) == ((1 << 0) | (1 << 17))
