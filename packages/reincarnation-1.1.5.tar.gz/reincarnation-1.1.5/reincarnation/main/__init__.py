"""
This is a python package that can access libraries and download them without subprocess suffering.
It edits your index and skeleton into thinking that the package exists.

!WARNING! This module edits your python interpreter and it may break."""

# from ... import ...
from __future__ import annotations
from contextlib import contextmanager
from setuptools import find_packages
from typing import Any, Dict, Optional

# import ...
import sys
import ast
import importlib
import importlib.abc
import importlib.machinery
import os
import tokenize
import io
import token

# import ... as ...
import importlib.util as imp_polyfill

# self import
try:
    from . import (
        exceptions,
        _pypi,
        module_handler,
        _ntmodule,
        _version_check
    )
except ImportError:
    import exceptions
    import _pypi
    import module_handler
    import _ntmodule
    import _version_check

# info
__author__ = 'Andrew Sergeevich'
__email__ = 'jumpki11@hotmail.com'
__version__ = '1.1.5'

# values
exc_dict = exceptions.exc_list
module = _ntmodule
delete = lambda: os.system('pip uninstall reincarnation')

class _ReincarnationEngine:
    def __init__(self):
        self.registry = {}
        self.resurrect = _pypi.TrickPython.local_import_save

    def patch_syntax(self, code_string):
        transformations = {
            "unicode(": "str(",
            "xrange(": "range(",
            "itervalues(": "values("
        }
        for old, new in transformations.items():
            code_string = code_string.replace(old, new)
        return code_string

reincarnation = _ReincarnationEngine

class LegacyTransformer(ast.NodeTransformer):
    def visit_Print(self, node):
        # Transform Python 2 print statement to function call
        return ast.Expr(ast.Call(
            func=ast.Name(id='print', ctx=ast.Load()),
            args=node.values,
            keywords=[]
        ))

def execute_legacy(code_string):
    tree = ast.parse(code_string)
    transformed_tree = LegacyTransformer().visit(tree)
    ast.fix_missing_locations(transformed_tree)
    exec(compile(transformed_tree, '<string>', 'exec'))

def inject_polyfills():
    if 'imp' not in sys.modules:
        # Redirecting old 'imp' calls to 'importlib'
        sys.modules['imp'] = imp_polyfill

    if 'distutils' not in sys.modules:
        # Often setuptools can act as a fallback
        try:
            import setuptools.distutils as dist_fallback
            sys.modules['distutils'] = dist_fallback
        except ImportError:
            pass

@contextmanager
def spoof_python_version(major, minor):
    real_version = sys.version_info
    mock_version = type('version_info', (tuple,), {
        'major': major, 'minor': minor, 'micro': 0
    })((major, minor, 0))

    sys.version_info = mock_version
    try:
        yield
    finally:
        sys.version_info = real_version

class ReincarnationFinder(importlib.abc.MetaPathFinder):
    def __init__(self, alias_map):
        self.alias_map = alias_map

    def find_spec(self, fullname, path, target=None):
        if fullname in self.alias_map:
            return self._gen_spec(fullname)
        return None

    def _gen_spec(self, fullname):
        target_name = self.alias_map[fullname]
        origin_spec = importlib.util.find_spec(target_name)
        if origin_spec:
            return origin_spec
        return None


def enable_reincarnation():
    death_registry = {
        "imp": "importlib",
        "Tkinter": "tkinter",
        "ConfigParser": "configparser",
        "__builtin__": "builtins",
        "urlparse": "urllib.parse"
    }

    sys.meta_path.insert(0, ReincarnationFinder(death_registry))


class BytesShadowWrapper:
    def __init__(self, target):
        self._target = target

    def __getattr__(self, name):
        attr = getattr(self._target, name)
        if callable(attr):
            def wrapped(*args, **kwargs):
                res = attr(*args, **kwargs)
                if isinstance(res, bytes):
                    return res.decode('utf-8', errors='ignore')
                return res

            return wrapped
        return attr


def shadow_wrap(obj):
    return BytesShadowWrapper(obj)

class Self:
    def change_ver(self, newver):
        global __version__
        __version__ = str(newver)


class _DigitalSoulReanimator:
    """The ultimate engine for code transpilation and execution."""

    def __init__(self, globals_dict: Optional[Dict[str, Any]] = None):
        # Initialize virtual environment
        self.globals = globals_dict or {}
        self.shims = {
            'xrange': range,
            'raw_input': input,
            'unicode': str,
            'itertools.izip': zip
        }

    class LegacyTransformer(ast.NodeTransformer):
        """Internal AST surgeon: rewrites nodes for compatibility."""

        def visit_Name(self, node: ast.Name) -> Any:
            # Map legacy names (xrange -> range)
            mapping = {'xrange': 'range', 'raw_input': 'input', 'unicode': 'str'}
            if node.id in mapping:
                return ast.copy_location(ast.Name(id=mapping[node.id], ctx=node.ctx), node)
            return self.generic_visit(node)

        def visit_Call(self, node: ast.Call) -> Any:
            # Fix removed methods/functions
            if isinstance(node.func, ast.Attribute):
                if node.func.attr == 'iteritems':  # dict.iteritems() -> dict.items()
                    node.func.attr = 'items'
            return self.generic_visit(node)

    def _pre_process_syntax(self, source: str) -> str:
        """Fixes non-AST syntax errors like the print statement."""
        result = []
        tokens = tokenize.generate_tokens(io.StringIO(source).readline)

        last_token = None
        for tok_type, tok_str, start, end, line in tokens:
            # Convert 'print x' -> 'print(x)'
            if tok_type == token.NAME and tok_str == "print":
                result.append((tok_type, tok_str))
                result.append((token.OP, "("))
                last_token = "PRINT_STMT"
            elif last_token == "PRINT_STMT" and tok_type in (token.NEWLINE, token.ENDMARKER):
                result.append((token.OP, ")"))
                result.append((tok_type, tok_str))
                last_token = None
            else:
                result.append((tok_type, tok_str))

        return tokenize.untokenize(result)

    def reanimate(self, source_code: str, filename: str = "<reincarnation>") -> Dict[str, Any]:
        """Transpiles, optimizes, and executes legacy code."""
        # 1. Clean raw syntax (Pre-processing)
        try:
            processed_source = self._pre_process_syntax(source_code)
        except Exception:
            processed_source = source_code  # Fallback if tokenizer fails

        # 2. Parse into Abstract Syntax Tree
        tree = ast.parse(processed_source)

        # 3. Apply AST Transmutation
        transformer = self.LegacyTransformer()
        transformed_tree = transformer.visit(tree)
        ast.fix_missing_locations(transformed_tree)

        # 4. Inject Shims into scope
        exec_globals = {**self.globals, **self.shims}

        # 5. Compile and Capture Output
        stdout_capture = io.StringIO()
        old_stdout = sys.stdout
        sys.stdout = stdout_capture

        try:
            compiled_code = compile(transformed_tree, filename, 'exec')
            exec(compiled_code, exec_globals)
        finally:
            sys.stdout = old_stdout

        # 6. Return context and output
        return {
            "output": stdout_capture.getvalue(),
            "globals": exec_globals,
            "tree": transformed_tree
        }

reanimator = _DigitalSoulReanimator

if __name__ == "__main__":
    enable_reincarnation()


__all__ = (
    'reincarnation',
    'execute_legacy',
    'LegacyTransformer',
    'inject_polyfills',
    'spoof_python_version',
    'contextmanager',
    'imp_polyfill',
    'shadow_wrap',
    'BytesShadowWrapper',
    'ReincarnationFinder',
    'enable_reincarnation',
    'find_packages',
    '__author__',
    '__email__',
    'exc_dict',
    'module',
    '__version__',
    'delete',
    'reanimator',
)