"""Biotailor API client."""

from __future__ import annotations

import json as _json
import logging
import os
import re
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import requests
from tqdm.auto import tqdm

from biotailor.exceptions import BiotailorAPIError, BiotailorValidationError
from biotailor.models import (
    Dataset,
    Job,
    JobStatus,
    ToolConfig,
    parse_dataset,
    parse_job,
    parse_tool_config,
)
from biotailor.pipeline import Pipeline
from biotailor.uploader import upload_files

logger = logging.getLogger("biotailor")

__version__ = "0.1.0"

_API_KEY_PATTERN = re.compile(r"^btk_[a-fA-F0-9]+\.sk_[a-fA-F0-9]+$")

_VALID_FILE_TYPES = {
    "fastq",
    "fasta",
    "bam",
    "sam",
    "html",
    "text",
    "fai",
    "bai",
    "nwk",
    "phylip",
    "catg",
    "nexus",
    "clustalw",
    "diamond_db",
    "kraken2_db",
    "blast_db",
    "bowtie2_db",
    "m8",
    "csv",
    "tsv",
}

_VALID_JOB_SORT_FIELDS = {"startTimestamp", "latestStatusTimestamp"}
_VALID_ORDERS = {"asc", "desc"}


def _format_log_timestamp(timestamp: Any) -> str:
    """Convert API log timestamps to local ISO 8601 strings."""
    if timestamp is None:
        return ""

    try:
        ts = float(timestamp)
    except (TypeError, ValueError):
        return str(timestamp)

    # API timestamps are usually milliseconds since epoch. Accept seconds too.
    if ts > 10_000_000_000:
        ts = ts / 1000

    try:
        return (
            datetime.fromtimestamp(ts, tz=timezone.utc)
            .astimezone()
            .isoformat(timespec="seconds")
        )
    except (OverflowError, OSError, ValueError):
        return str(timestamp)


def _format_display_timestamp(timestamp: Any) -> str:
    """Convert timestamps to a display string, using an em dash when absent."""
    return _format_log_timestamp(timestamp) if timestamp is not None else "—"


def _one_line(value: Any) -> str:
    """Normalize arbitrary text values to one display line."""
    if value is None:
        return ""
    return " ".join(str(value).split())


def _print_table(headers: List[str], rows: List[List[str]]) -> None:
    """Print a simple aligned text table."""
    widths = [len(header) for header in headers]
    for row in rows:
        for i, value in enumerate(row):
            widths[i] = max(widths[i], len(value))

    print("  " + "  ".join(header.ljust(widths[i]) for i, header in enumerate(headers)))
    print("  " + "  ".join("-" * width for width in widths))
    for row in rows:
        print("  " + "  ".join(value.ljust(widths[i]) for i, value in enumerate(row)))


def _extract_log_entries(data: Any) -> Optional[List[Any]]:
    """Extract list-style log entries from common API response shapes."""
    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        if "timestamp" in data and "message" in data:
            return [data]
        for key in ("logs", "log", "events", "messages"):
            value = data.get(key)
            if isinstance(value, list):
                return value

    return None


def _format_log_entries(entries: List[Any]) -> str:
    """Format timestamped log entries as aligned, local-time text."""
    rows: List[tuple[str, str]] = []
    for entry in entries:
        if isinstance(entry, dict):
            timestamp = _format_log_timestamp(
                entry.get("timestamp") or entry.get("time") or entry.get("createdAt")
            )
            message = entry.get("message", entry.get("log", entry.get("logs", "")))
        else:
            timestamp = ""
            message = entry
        rows.append((timestamp, str(message)))

    timestamp_width = max((len(timestamp) for timestamp, _ in rows), default=0)
    formatted: List[str] = []
    for timestamp, message in rows:
        message_lines = message.splitlines() or [""]
        if timestamp:
            prefix = f"{timestamp:<{timestamp_width}}  "
            continuation_prefix = " " * (timestamp_width + 2)
            formatted.append(prefix + message_lines[0])
            formatted.extend(continuation_prefix + line for line in message_lines[1:])
        else:
            formatted.extend(message_lines)

    return "\n".join(formatted)


def _format_job_log_data(data: Any) -> str:
    """Format raw job log API data into human-readable text."""
    entries = _extract_log_entries(data)
    if entries is not None:
        return _format_log_entries(entries)

    if isinstance(data, dict):
        for key in ("logs", "log"):
            if key in data:
                return _format_job_log_data(data[key])

    return str(data)


def _new_job_log_text(data: Any, process_id: str, log_offsets: Dict[str, int]) -> str:
    """Return only log text that has not already been displayed for a process."""
    entries = _extract_log_entries(data)
    if entries is not None:
        start = min(log_offsets.get(process_id, 0), len(entries))
        new_entries = entries[start:]
        log_offsets[process_id] = len(entries)
        return _format_log_entries(new_entries) if new_entries else ""

    text = _format_job_log_data(data)
    start = min(log_offsets.get(process_id, 0), len(text))
    log_offsets[process_id] = len(text)
    return text[start:].strip("\n")


class BiotailorClient:
    """Main client for interacting with the Biotailor API.

    Args:
        api_key: API key in the format ``btk_<id>.sk_<secret>``.
        base_url: Base URL of the Biotailor API.
        timeout: Default request timeout in seconds.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.biotailor.org",
        timeout: int = 30,
        debug: bool = False,
    ):
        if not _API_KEY_PATTERN.match(api_key):
            raise BiotailorValidationError(
                "Invalid API key format. Expected 'btk_<id>.sk_<secret>'."
            )
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._debug = debug

        if debug:
            logging.basicConfig(
                level=logging.DEBUG,
                format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
            )
            logger.setLevel(logging.DEBUG)
        else:
            logger.setLevel(logging.WARNING)

        self._session = requests.Session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": f"biotailor-python/{__version__}",
            }
        )

    # ------------------------------------------------------------------
    # Internal HTTP helpers
    # ------------------------------------------------------------------

    def _url(self, path: str) -> str:
        return f"{self._base_url}/{path.lstrip('/')}"

    def _log_request(self, method: str, url: str, body: Any = None) -> None:
        if not self._debug:
            return
        # Mask the API key in logged headers
        headers = dict(self._session.headers)
        if "Authorization" in headers:
            token = headers["Authorization"]
            # Show first 10 chars + last 4 chars of the key
            if isinstance(token, str) and len(token) > 20:
                headers["Authorization"] = token[:17] + "..." + token[-4:]
        logger.debug(">> %s %s", method, url)
        logger.debug("   Headers: %s", headers)
        if body is not None:
            logger.debug("   Body: %s", _json.dumps(body, indent=2, default=str))

    def _log_response(self, resp: requests.Response) -> None:
        if not self._debug:
            return
        logger.debug("<< %s %s", resp.status_code, resp.reason)
        logger.debug("   Response headers: %s", dict(resp.headers))
        try:
            logger.debug("   Response body: %s", resp.text[:2000])
        except Exception:
            logger.debug("   Response body: <unreadable>")

    def _handle_response(self, resp: requests.Response) -> Any:
        self._log_response(resp)
        if resp.status_code >= 400:
            try:
                body = resp.text
            except Exception:
                body = ""
            raise BiotailorAPIError(
                status_code=resp.status_code,
                message=resp.reason or "Unknown error",
                response_body=body,
            )
        if resp.status_code == 204 or not resp.content:
            return None
        return resp.json()

    def _get(self, path: str, **kwargs: Any) -> Any:
        url = self._url(path)
        self._log_request("GET", url)
        resp = self._session.get(url, timeout=self._timeout, **kwargs)
        return self._handle_response(resp)

    def _post(self, path: str, json: Any = None, **kwargs: Any) -> Any:
        url = self._url(path)
        self._log_request("POST", url, body=json)
        resp = self._session.post(url, json=json, timeout=self._timeout, **kwargs)
        return self._handle_response(resp)

    def _patch(self, path: str, json: Any = None, **kwargs: Any) -> Any:
        url = self._url(path)
        self._log_request("PATCH", url, body=json)
        resp = self._session.patch(url, json=json, timeout=self._timeout, **kwargs)
        return self._handle_response(resp)

    def _delete(self, path: str, **kwargs: Any) -> Any:
        url = self._url(path)
        self._log_request("DELETE", url)
        resp = self._session.delete(url, timeout=self._timeout, **kwargs)
        return self._handle_response(resp)

    # ------------------------------------------------------------------
    # Tools
    # ------------------------------------------------------------------

    def list_tools(self) -> List[ToolConfig]:
        """List all available bioinformatics tools.

        Returns:
            List of ToolConfig objects.
        """
        data = self._get("tools")
        if isinstance(data, list):
            return [parse_tool_config(t) for t in data]
        return []

    def get_tools(self) -> List[ToolConfig]:
        """Get all available bioinformatics tool configs.

        This is an alias for ``list_tools()``.
        """
        return self.list_tools()

    def print_tools(self) -> None:
        """Print all available tools with a short human-readable description."""
        tools = self.list_tools()
        if not tools:
            print("No tools available.")
            return

        print("Available tools:")
        rows = [
            [tool.toolid, tool.display_name, _one_line(tool.description)]
            for tool in tools
        ]
        _print_table(["Tool ID", "Name", "Description"], rows)

    def get_tool(self, tool_id: str) -> ToolConfig:
        """Get a single tool config by ID.

        Args:
            tool_id: The tool identifier (e.g. ``"fastp-single"``).

        Returns:
            ToolConfig for the requested tool.

        Raises:
            BiotailorAPIError: If the tool is not found.
        """
        data = self._get(f"tools/{tool_id}")
        return parse_tool_config(data)

    # ------------------------------------------------------------------
    # Datasets
    # ------------------------------------------------------------------

    def list_datasets(self, type: Optional[str] = None) -> List[Dataset]:
        """List all available datasets.

        Args:
            type: Optional file type to filter by, e.g. ``"fastq"`` or
                ``"bowtie2_db"``.

        Returns:
            List of Dataset objects.
        """
        if type is not None and type not in _VALID_FILE_TYPES:
            raise BiotailorValidationError(
                f"Invalid dataset type {type!r}. Choose from: {sorted(_VALID_FILE_TYPES)}"
            )

        data = self._get("datasets")
        if isinstance(data, list):
            datasets = [parse_dataset(d) for d in data]
            if type is not None:
                datasets = [d for d in datasets if d.dataset_type == type]
            return datasets
        return []

    def print_datasets(self, type: Optional[str] = None) -> None:
        """Print datasets grouped by file type."""
        datasets = self.list_datasets(type=type)
        if not datasets:
            suffix = f" for type {type!r}" if type else ""
            print(f"No datasets available{suffix}.")
            return

        grouped: Dict[str, List[Dataset]] = {}
        for dataset in datasets:
            grouped.setdefault(dataset.dataset_type or "unknown", []).append(dataset)

        print("Datasets:")
        for dataset_type in sorted(grouped):
            print(f"\nDataset type: {dataset_type}")
            rows = []
            sorted_datasets = sorted(
                grouped[dataset_type],
                key=lambda d: d.display_name or d.dataset_id,
            )
            for dataset in sorted_datasets:
                rows.append([
                    dataset.dataset_id,
                    dataset.display_name or "",
                    dataset.compression_method or "—",
                    _one_line(dataset.description),
                ])
            _print_table(["Dataset ID", "Name", "Compression", "Description"], rows)

    # ------------------------------------------------------------------
    # Jobs — CRUD
    # ------------------------------------------------------------------

    def list_jobs(
        self,
        sortBy: Optional[str] = "latestStatusTimestamp",  # noqa: N803
        order: str = "desc",
        jobNameFilter: Optional[str] = None,  # noqa: N803
    ) -> List[Job]:
        """List all jobs for the authenticated user.

        Args:
            sortBy: Field to sort by. Allowed values are ``"startTimestamp"``
                and ``"latestStatusTimestamp"``.
            order: Sort order, either ``"asc"`` or ``"desc"``.
            jobNameFilter: Optional case-insensitive substring filter for job names.

        Returns:
            List of Job objects.
        """
        sort_by = sortBy or "latestStatusTimestamp"
        normalized_order = order.lower()
        if sort_by not in _VALID_JOB_SORT_FIELDS:
            raise BiotailorValidationError(
                f"Invalid sortBy {sort_by!r}. Choose from: {sorted(_VALID_JOB_SORT_FIELDS)}"
            )
        if normalized_order not in _VALID_ORDERS:
            raise BiotailorValidationError(
                f"Invalid order {order!r}. Choose from: {sorted(_VALID_ORDERS)}"
            )

        data = self._get("jobs")
        if not isinstance(data, list):
            return []

        items: List[Dict[str, Any]] = [item for item in data if isinstance(item, dict)]
        if jobNameFilter:
            needle = jobNameFilter.lower()
            items = [
                item
                for item in items
                if needle in str(item.get("jobName", item.get("job_name", ""))).lower()
            ]

        missing_value = float("-inf") if normalized_order == "desc" else float("inf")

        def job_sort_key(item: Dict[str, Any]) -> float:
            value = item.get(sort_by)
            if value is None:
                return missing_value
            try:
                return float(value)
            except (TypeError, ValueError):
                return missing_value

        items.sort(
            key=job_sort_key,
            reverse=normalized_order == "desc",
        )
        return [parse_job(j) for j in items]

    def print_jobs(
        self,
        sortBy: Optional[str] = "latestStatusTimestamp",  # noqa: N803
        order: str = "desc",
        jobNameFilter: Optional[str] = None,  # noqa: N803
    ) -> None:
        """Print jobs in a human-readable table."""
        jobs = self.list_jobs(sortBy=sortBy, order=order, jobNameFilter=jobNameFilter)
        if not jobs:
            print("No jobs found.")
            return

        rows = []
        for job in jobs:
            processes = ", ".join(job.processes_name or [])
            rows.append([
                job.jobid,
                job.job_status.value,
                _format_display_timestamp(job.latest_status_timestamp),
                _format_display_timestamp(job.start_timestamp),
                job.job_name,
                processes,
                job.email or job.userid or "",
            ])

        print("Jobs:")
        _print_table(
            ["Job ID", "Status", "Latest Update", "Start Time", "Job Name", "Tools", "User"],
            rows,
        )

    def get_job(self, job_id: str) -> Job:
        """Get a single job by ID.

        Args:
            job_id: The job identifier.

        Returns:
            Job object with current status and metadata.
        """
        data = self._get(f"jobs/{job_id}")
        if isinstance(data, dict) and "jobid" not in data:
            data["jobid"] = job_id
        return parse_job(data)

    def cancel_job(self, job_id: str) -> None:
        """Cancel a running job.

        Args:
            job_id: The job identifier.
        """
        self._post(f"jobs/{job_id}/cancel")

    # ------------------------------------------------------------------
    # Jobs — Run Pipeline
    # ------------------------------------------------------------------

    def run(self, pipeline: Pipeline, show_progress: bool = True) -> Job:
        """Execute a pipeline: create job, submit workflow, upload files.

        Args:
            pipeline: A configured Pipeline object.
            show_progress: Whether to show upload progress bars.

        Returns:
            Job object with the initial status.
        """
        available_datasets = self.list_datasets() if pipeline.has_dataset_inputs() else None
        workflow_json = pipeline.build_workflow(available_datasets=available_datasets)

        # Step A: Create job
        create_body: Dict[str, Any] = {
            "jobName": pipeline.name,
            "orgid": "null",
            "isprivate": True,
        }
        create_resp = self._post("jobs", json=create_body)
        job_id: str = create_resp["jobid"]

        # Step B: Submit workflow + get upload URLs
        run_body: Dict[str, Any] = {
            "workflow": workflow_json,
            "reactFlowWorkflow": {
                "nodes": [],
                "edges": [],
                "viewport": {"x": 0, "y": 0, "zoom": 1},
            },
        }
        run_resp = self._post(f"jobs/{job_id}/run", json=run_body)
        job_status = run_resp.get("jobStatus", "UPLOADING")

        # Step C: Upload files if needed
        upload_urls = run_resp.get("uploadURLs", [])
        upload_headers = run_resp.get("uploadHeaders", {})

        if upload_urls:
            multipart_results = upload_files(
                upload_urls=upload_urls,
                upload_headers=upload_headers,
                file_map=pipeline.get_file_map(),
                show_progress=show_progress,
            )
            logger.debug("Files uploaded: %s", multipart_results)

            # Step D: Confirm uploads (always called — backend needs this to advance job status)
            confirm_body: Dict[str, Any] = {"multipartFiles": multipart_results}
            self._post(f"jobs/{job_id}/confirm-uploaded", json=confirm_body)

        return Job(
            jobid=job_id,
            job_name=pipeline.name,
            job_status=JobStatus(job_status),
        )

    # ------------------------------------------------------------------
    # Jobs — Monitoring
    # ------------------------------------------------------------------

    def wait_for_completion(
        self,
        job_id: str,
        poll_interval: int = 10,
        timeout: Optional[int] = None,
        verbose: bool = True,
    ) -> Job:
        """Poll until a job reaches a terminal status.

        Args:
            job_id: The job identifier.
            poll_interval: Seconds between polls.
            timeout: Maximum seconds to wait (None = unlimited).
            verbose: Print status updates to stdout.

        Returns:
            Job in a terminal state.

        Raises:
            TimeoutError: If timeout is exceeded.
        """
        start = time.monotonic()
        last_status = None
        log_offsets: Dict[str, int] = {}
        printed_log_headers: set[str] = set()

        while True:
            job = self.get_job(job_id)
            if verbose and job.job_status != last_status:
                print(f"[biotailor] Job {job_id}: {job.job_status.value}")
                last_status = job.job_status

            if verbose and job.job_status == JobStatus.RUNNING:
                self._print_new_running_logs(job, log_offsets, printed_log_headers)

            if job.job_status in JobStatus.terminal_statuses():
                return job

            if timeout is not None and (time.monotonic() - start) >= timeout:
                raise TimeoutError(
                    f"Job {job_id} did not complete within {timeout}s "
                    f"(last status: {job.job_status.value})"
                )

            time.sleep(poll_interval)

    # ------------------------------------------------------------------
    # Jobs — Logs
    # ------------------------------------------------------------------

    def get_job_logs(self, job_id: str, process_id: str) -> str:
        """Fetch logs for a specific process within a job.

        Args:
            job_id: The job identifier.
            process_id: The process identifier.

        Returns:
            Log content as a string.
        """
        return _format_job_log_data(self._get_job_logs_data(job_id, process_id))

    def _get_job_logs_data(self, job_id: str, process_id: str) -> Any:
        """Fetch raw logs for a specific process within a job."""
        return self._get(f"jobs/{job_id}/processes/{process_id}/logs")

    def _get_job_processes(self, job: Job) -> List[Dict[str, Any]]:
        """Extract workflow processes from a job response."""
        workflow = job.workflow or (job.raw or {}).get("workflow") or {}
        if isinstance(workflow, str):
            try:
                workflow = _json.loads(workflow)
            except ValueError:
                return []

        if not isinstance(workflow, dict):
            return []

        processes = workflow.get("processes", [])
        return processes if isinstance(processes, list) else []

    def _print_new_running_logs(
        self,
        job: Job,
        log_offsets: Dict[str, int],
        printed_log_headers: set[str],
    ) -> None:
        """Fetch and print only new logs while a job is running."""
        for proc in self._get_job_processes(job):
            process_id = proc.get("processId") or proc.get("process_id")
            if not process_id:
                continue

            try:
                data = self._get_job_logs_data(job.jobid, process_id)
            except BiotailorAPIError as e:
                logger.debug("Could not fetch logs for process %s: %s", process_id, e)
                continue

            logs = _new_job_log_text(data, process_id, log_offsets)
            if not logs:
                continue

            if process_id not in printed_log_headers:
                label = proc.get("processLabel") or proc.get("type") or process_id
                print(f"\n[biotailor] Logs: {label}  (id: {process_id})")
                printed_log_headers.add(process_id)
            print(logs, flush=True)

    # ------------------------------------------------------------------
    # Jobs — Outputs
    # ------------------------------------------------------------------

    def get_output_file_sizes(self, job_id: str) -> List[Dict[str, Any]]:
        """Get file sizes for all outputs of a job.

        Args:
            job_id: The job identifier.

        Returns:
            Dict mapping output keys to size information.
        """
        data = self._get(f"jobs/{job_id}/outputs/fileSize")
        return data if isinstance(data, list) else []

    def download_outputs(
        self,
        job_id: str,
        output_dir: str,
        process_id: Optional[str] = None,
        show_progress: bool = True,
    ) -> List[str]:
        """Download output files from a completed job.

        Args:
            job_id: The job identifier.
            output_dir: Local directory to save files to.
            process_id: If provided, download only outputs from this process.
            show_progress: Whether to show download progress bars.

        Returns:
            List of downloaded file paths.
        """
        if process_id:
            path = f"jobs/{job_id}/processes/{process_id}/outputs/request-download"
        else:
            path = f"jobs/{job_id}/outputs/request-download"

        data = self._post(path)
        if not isinstance(data, list):
            data = []

        # Flatten into a list of {id, url} items.
        # With process_id: response is [{id, url}, ...]
        # Without process_id: response is [{processId, outputs: [{id, url}, ...]}, ...]
        items: List[Dict[str, Any]] = []
        if process_id:
            items = data
        else:
            for process_entry in data:
                items.extend(process_entry.get("outputs", []))

        os.makedirs(output_dir, exist_ok=True)
        downloaded: List[str] = []

        for item in items:
            url = item.get("url", "")
            name = item.get("id", "")
            if not name:
                name = url.split("?")[0].rsplit("/", 1)[-1]

            dest = os.path.join(output_dir, name)
            _download_file(url, dest, show_progress=show_progress)
            downloaded.append(dest)

        return downloaded

    # ------------------------------------------------------------------
    # Convenience — run_and_wait
    # ------------------------------------------------------------------

    def run_and_wait(
        self,
        pipeline: Pipeline,
        output_dir: Optional[str] = None,
        poll_interval: int = 10,
        timeout: Optional[int] = None,
        show_progress: bool = True,
    ) -> Job:
        """Run a pipeline and wait for it to complete (optionally download outputs).

        Args:
            pipeline: A configured Pipeline object.
            output_dir: If provided, download outputs on success.
            poll_interval: Seconds between status polls.
            timeout: Maximum seconds to wait (None = unlimited).
            show_progress: Whether to show progress bars.

        Returns:
            Job in a terminal state.
        """
        job = self.run(pipeline, show_progress=show_progress)
        job = self.wait_for_completion(job.jobid, poll_interval=poll_interval, timeout=timeout)

        if job.job_status == JobStatus.SUCCEEDED:
            if output_dir:
                self.download_outputs(job.jobid, output_dir, show_progress=show_progress)

        return job

def _download_file(url: str, dest: str, show_progress: bool = True) -> None:
    """Download a file from a URL to a local path."""
    resp = requests.get(url, stream=True, timeout=300)
    resp.raise_for_status()
    total = int(resp.headers.get("content-length", 0))

    if show_progress:
        pbar = tqdm(
            total=total,
            unit="B",
            unit_scale=True,
            desc=os.path.basename(dest),
        )
    else:
        pbar = None

    with open(dest, "wb") as f:
        for chunk in resp.iter_content(chunk_size=8192):
            f.write(chunk)
            if pbar:
                pbar.update(len(chunk))

    if pbar:
        pbar.close()
