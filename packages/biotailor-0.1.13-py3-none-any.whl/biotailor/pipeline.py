"""Pipeline builder for constructing single-tool workflow JSON."""

from __future__ import annotations

import os
import random
import string
from typing import Any, Dict, List, Optional, Union

from biotailor.exceptions import BiotailorValidationError
from biotailor.models import (
    Dataset,
    ToolConfig,
    ToolParameter,
)

_VALID_CPUS = {2, 4, 8, 16, 32, 64, 128, 192}
_VALID_RAM_MULTIPLIERS = {2, 4, 8}


def _random_id(length: int = 6) -> str:
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=length))


def _check_value_type(pid: str, value: Any, param_type: str) -> Optional[str]:
    """Validate that ``value`` matches the declared ``param_type``.

    Returns an error message string on mismatch, or None if valid.
    """
    if param_type == "boolean":
        # bool must be strictly bool (not int)
        if not isinstance(value, bool):
            return (
                f"Parameter '{pid}' expects boolean, got "
                f"{type(value).__name__} ({value!r})."
            )
    elif param_type == "number":
        # Accept int/float but reject bool (bool is subclass of int in Python)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return (
                f"Parameter '{pid}' expects number, got "
                f"{type(value).__name__} ({value!r})."
            )
    elif param_type == "string":
        if not isinstance(value, str):
            return (
                f"Parameter '{pid}' expects string, got "
                f"{type(value).__name__} ({value!r})."
            )
    elif param_type == "number[]":
        if not isinstance(value, (list, tuple)):
            return (
                f"Parameter '{pid}' expects an array of numbers, got "
                f"{type(value).__name__} ({value!r})."
            )
        for i, item in enumerate(value):
            if isinstance(item, bool) or not isinstance(item, (int, float)):
                return (
                    f"Parameter '{pid}' expects an array of numbers, but "
                    f"element at index {i} is {type(item).__name__} ({item!r})."
                )
    elif param_type == "string[]":
        if not isinstance(value, (list, tuple)):
            return (
                f"Parameter '{pid}' expects an array of strings, got "
                f"{type(value).__name__} ({value!r})."
            )
        for i, item in enumerate(value):
            if not isinstance(item, str):
                return (
                    f"Parameter '{pid}' expects an array of strings, but "
                    f"element at index {i} is {type(item).__name__} ({item!r})."
                )
    return None


class Pipeline:
    """Builder for a single-tool Biotailor pipeline.

    Args:
        name: Human-readable pipeline/job name.
        tool: Either a tool ID string or a ``ToolConfig`` object.
    """

    def __init__(self, name: str, tool: Union[str, ToolConfig]):
        self.name = name

        if isinstance(tool, ToolConfig):
            self._tool_config: Optional[ToolConfig] = tool
            self._tool_id: str = tool.toolid
        else:
            self._tool_config = None
            self._tool_id = tool

        self._params: Dict[str, Any] = {}
        self._inputs: Dict[str, str] = {}  # param_id -> local file path
        self._input_batches: Dict[str, List[str]] = {}  # param_id -> list of local file paths
        self._datasets: Dict[str, Dict[str, str]] = {}  # param_id -> {datasetType, datasetId}
        self._hardware: Optional[Dict[str, int]] = None
        self._is_pair_end: Optional[bool] = None

    # ------------------------------------------------------------------
    # Builder methods (chainable)
    # ------------------------------------------------------------------

    def set_param(self, param_id: str, value: Any) -> Pipeline:
        """Set a tool parameter value."""
        self._params[param_id] = value
        return self

    def set_params(self, **kwargs: Any) -> Pipeline:
        """Set multiple tool parameters at once."""
        self._params.update(kwargs)
        return self

    def set_input(self, param_id: str, file_path: str) -> Pipeline:
        """Set a single file input for a parameter.

        Args:
            param_id: The parameter ID that accepts a file.
            file_path: Local path to the file.
        """
        self._inputs[param_id] = file_path
        return self

    def set_input_batch(self, param_id: str, file_paths: List[str]) -> Pipeline:
        """Set multiple file inputs (batch) for a parameter.

        Args:
            param_id: The parameter ID that accepts batch files.
            file_paths: List of local file paths.
        """
        self._input_batches[param_id] = list(file_paths)
        return self

    def set_dataset(self, param_id: str, dataset_type: str, dataset_id: str) -> Pipeline:
        """Set a dataset source for a parameter.

        Args:
            param_id: The parameter ID.
            dataset_type: Dataset type (e.g. ``"bowtie2Indexes"``).
            dataset_id: Specific dataset identifier.
        """
        self._datasets[param_id] = {"datasetType": dataset_type, "datasetId": dataset_id}
        return self

    def set_hardware(self, cpu: int, ram_gb: int) -> Pipeline:
        """Override the default hardware configuration.

        Args:
            cpu: Number of CPUs (must be power of 2, 2-192).
            ram_gb: RAM in GB (must be cpu*2, cpu*4, or cpu*8).
        """
        self._hardware = {"cpu": cpu, "ramInGB": ram_gb}
        return self

    def set_pair_end(self) -> Pipeline:
        """Set this pipeline to paired-end mode."""
        self._is_pair_end = True
        return self

    def set_single_end(self) -> Pipeline:
        """Set this pipeline to single-end mode."""
        self._is_pair_end = False
        return self

    def has_dataset_inputs(self) -> bool:
        """Return True if this pipeline uses any dataset inputs."""
        return bool(self._datasets)

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate(self, available_datasets: Optional[List[Dataset]] = None) -> None:
        """Validate the pipeline configuration.

        Args:
            available_datasets: Optional dataset catalog fetched from the API.
                If provided, every configured dataset source must match an
                available ``dataset_type`` / ``dataset_id`` pair.

        Raises:
            BiotailorValidationError: If validation fails.
        """
        errors: List[str] = []

        # Validate hardware
        hw = self._get_hardware_dict()
        cpu = hw["cpu"]
        ram = hw["ramInGB"]
        if cpu not in _VALID_CPUS:
            errors.append(f"CPU {cpu} is not valid. Choose from {sorted(_VALID_CPUS)}.")
        if cpu in _VALID_CPUS and ram not in {cpu * m for m in _VALID_RAM_MULTIPLIERS}:
            errors.append(
                f"RAM {ram}GB is not valid for {cpu} CPUs. "
                f"Choose from {sorted(cpu * m for m in _VALID_RAM_MULTIPLIERS)}."
            )

        # Validate file inputs exist
        for param_id, file_path in self._inputs.items():
            if not os.path.isfile(file_path):
                errors.append(f"Input file for '{param_id}' not found: {file_path}")

        for param_id, file_paths in self._input_batches.items():
            for fp in file_paths:
                if not os.path.isfile(fp):
                    errors.append(f"Batch input file for '{param_id}' not found: {fp}")

        # Validate against ToolConfig if available
        if self._tool_config:
            self._validate_against_tool_config(errors, available_datasets)

        if errors:
            raise BiotailorValidationError("Pipeline validation failed:\n- " + "\n- ".join(errors))

    def _validate_against_tool_config(
        self,
        errors: List[str],
        available_datasets: Optional[List[Dataset]] = None,
    ) -> None:
        tc = self._tool_config
        assert tc is not None

        param_map: Dict[str, ToolParameter] = {p.id: p for p in tc.parameters}

        # Tools supporting both SE/PE modes require an explicit mode selection
        if tc.has_sepe and self._is_pair_end is None:
            errors.append(
                f"Tool '{tc.toolid}' supports both single-end and paired-end modes. "
                f"Call set_pair_end() for paired-end or set_single_end() for single-end."
            )

        # Check that every set parameter id exists in the tool config
        for pid in self._params:
            if pid not in param_map:
                known = sorted(param_map.keys())
                errors.append(
                    f"Parameter '{pid}' is not a valid parameter for tool "
                    f"'{tc.toolid}'. Known parameters: {known}"
                )

        # Check that every set file/dataset input id exists and is a file param
        input_param_ids = (
            list(self._inputs.keys())
            + list(self._input_batches.keys())
            + list(self._datasets.keys())
        )
        for pid in input_param_ids:
            param = param_map.get(pid)
            if param is None:
                known_files = sorted(p.id for p in tc.parameters if p.type == "file")
                errors.append(
                    f"File input '{pid}' is not a valid parameter for tool "
                    f"'{tc.toolid}'. Known file parameters: {known_files}"
                )
            elif param.type != "file":
                errors.append(
                    f"Parameter '{pid}' is type '{param.type}', not 'file'. "
                    f"Use set_param() instead of set_input()."
                )

        # Check that every set dataset source exists in the API dataset catalog
        if available_datasets is not None:
            self._validate_dataset_sources(errors, available_datasets)

        # Check that mode-specific parameters are only set in matching SE/PE mode
        set_param_ids = list(dict.fromkeys(list(self._params.keys()) + input_param_ids))
        for pid in set_param_ids:
            param = param_map.get(pid)
            if param is None:
                continue
            if param.is_single_end_only and self._is_pair_end is True:
                errors.append(
                    f"Parameter '{pid}' is single-end only and can only be set "
                    f"when set_single_end() is used."
                )
            if param.is_pair_end_only and self._is_pair_end is False:
                errors.append(
                    f"Parameter '{pid}' is paired-end only and can only be set "
                    f"when set_pair_end() is used."
                )

        # Check required params
        for param in tc.parameters:
            if param.validation and param.validation.required:
                if param.is_single_end_only and self._is_pair_end is not False:
                    continue
                if param.is_pair_end_only and self._is_pair_end is not True:
                    continue

                if param.type == "file":
                    has_input = (
                        self._inputs.get(param.id) is not None
                        or self._input_batches.get(param.id) is not None
                        or self._datasets.get(param.id) is not None
                    )
                    if not has_input:
                        errors.append(f"Required file input '{param.id}' is not set.")
                if (
                    param.type != "file"
                    and param.id not in self._params
                    and param.default_value is None
                ):
                    errors.append(f"Required parameter '{param.id}' is not set.")

        # Check parameter value types
        for pid, val in self._params.items():
            param = param_map.get(pid)
            if not param:
                continue
            type_err = _check_value_type(pid, val, param.type)
            if type_err:
                errors.append(type_err)

        # Check number range
        for pid, val in self._params.items():
            param = param_map.get(pid)
            if param and param.type == "number" and param.validation:
                v = param.validation
                if isinstance(val, (int, float)) and not isinstance(val, bool):
                    if v.minimum is not None and val < v.minimum:
                        errors.append(f"Parameter '{pid}' value {val} < minimum {v.minimum}.")
                    if v.maximum is not None and val > v.maximum:
                        errors.append(f"Parameter '{pid}' value {val} > maximum {v.maximum}.")

        # Check options params
        for pid, val in self._params.items():
            param = param_map.get(pid)
            if param and param.validation and param.validation.options:
                valid_vals = {o.value for o in param.validation.options}
                if val not in valid_vals:
                    errors.append(
                        f"Parameter '{pid}' value {val!r} is not a valid option. "
                        f"Choose from: {sorted(str(v) for v in valid_vals)}"
                    )

    def _validate_dataset_sources(
        self,
        errors: List[str],
        available_datasets: List[Dataset],
    ) -> None:
        """Validate configured dataset sources against an API dataset catalog."""
        if not self._datasets:
            return

        datasets_by_type: Dict[str, set[str]] = {}
        for dataset in available_datasets:
            if dataset.dataset_type and dataset.dataset_id:
                datasets_by_type.setdefault(dataset.dataset_type, set()).add(dataset.dataset_id)

        for param_id, dataset_source in self._datasets.items():
            dataset_type = dataset_source["datasetType"]
            dataset_id = dataset_source["datasetId"]
            if dataset_type not in datasets_by_type:
                errors.append(
                    f"Dataset input '{param_id}' has invalid datasetType "
                    f"{dataset_type!r}. Known dataset types: {sorted(datasets_by_type)}"
                )
                continue

            valid_ids = datasets_by_type[dataset_type]
            if dataset_id not in valid_ids:
                errors.append(
                    f"Dataset input '{param_id}' has invalid datasetId {dataset_id!r} "
                    f"for datasetType {dataset_type!r}. Known dataset IDs for this type: "
                    f"{sorted(valid_ids)}"
                )

    # ------------------------------------------------------------------
    # Build workflow JSON
    # ------------------------------------------------------------------

    def _get_hardware_dict(self) -> Dict[str, int]:
        if self._hardware:
            return self._hardware
        if self._tool_config:
            hw = self._tool_config.default_hardware
            return {"cpu": hw.cpu, "ramInGB": hw.ram_in_gb}
        return {"cpu": 2, "ramInGB": 4}

    def build_workflow(self, available_datasets: Optional[List[Dataset]] = None) -> Dict[str, Any]:
        """Build the workflow JSON for the run endpoint.

        Args:
            available_datasets: Optional dataset catalog fetched from the API.
                If provided, dataset sources are validated against it.

        Returns:
            Workflow dict matching the backend ``Workflow`` type.

        Raises:
            BiotailorValidationError: If validation fails.
        """
        self.validate(available_datasets=available_datasets)

        process_id = f"{self._tool_id}{_random_id()}"
        hw = self._get_hardware_dict()

        # Build parameters list
        parameters: List[Dict[str, Any]] = []

        # Non-file parameters
        for pid, val in self._params.items():
            parameters.append({"id": pid, "value": val})

        # Single file inputs
        for pid, file_path in self._inputs.items():
            file_size = os.path.getsize(file_path)
            file_name = os.path.basename(file_path)
            parameters.append({
                "id": pid,
                "source": {
                    "type": "workflowInput",
                    "fileName": file_name,
                    "fileSizeInByte": file_size,
                },
            })

        # Batch file inputs
        for pid, file_paths in self._input_batches.items():
            files = []
            batch_ids = []
            for fp in file_paths:
                fname = os.path.basename(fp)
                files.append({
                    "fileName": fname,
                    "fileSizeInByte": os.path.getsize(fp),
                })
                # batchId = filename without extension
                batch_ids.append(os.path.splitext(fname)[0])

            source_type = "workflowInputBatchPair" if self._is_pair_end else "workflowInputBatch"
            parameters.append({
                "id": pid,
                "source": {
                    "type": source_type,
                    "files": files,
                    "batchIds": batch_ids,
                },
            })

        # Dataset inputs
        for pid, ds_info in self._datasets.items():
            parameters.append({
                "id": pid,
                "source": {
                    "type": "dataset",
                    "datasetType": ds_info["datasetType"],
                    "datasetId": ds_info["datasetId"],
                },
            })

        # Build process outputs
        process_outputs: List[Dict[str, str]] = []
        if self._tool_config:
            for out in self._tool_config.outputs:
                # Filter by pair-end if applicable
                if self._is_pair_end is False and out.is_pair_end_only:
                    continue
                if self._is_pair_end is True and out.is_single_end_only:
                    continue
                process_outputs.append({"outputId": out.id})

        process: Dict[str, Any] = {
            "processId": process_id,
            "processLabel": self._tool_config.display_name if self._tool_config else self._tool_id,
            "type": self._tool_id,
            "hardware": {
                "cpu": hw["cpu"],
                "ramInGB": hw["ramInGB"],
                "moreThan30GBStorage": True,
            },
            "parameters": parameters,
            "maxRetries": 1,
        }

        if process_outputs:
            process["processOutputs"] = process_outputs

        if self._is_pair_end is not None:
            process["isPairEnd"] = self._is_pair_end

        return {
            "name": self.name,
            "processes": [process],
        }

    # ------------------------------------------------------------------
    # File map (for uploader)
    # ------------------------------------------------------------------

    def get_file_map(self) -> Dict[str, str]:
        """Get mapping of fileName -> local path for all files to upload.

        Returns:
            Dict mapping file names to local file paths.
        """
        file_map: Dict[str, str] = {}

        for _pid, file_path in self._inputs.items():
            file_map[os.path.basename(file_path)] = file_path

        for _pid, file_paths in self._input_batches.items():
            for fp in file_paths:
                file_map[os.path.basename(fp)] = fp

        return file_map
