"""Unit tests for the Ardyn Python SDK client."""

from __future__ import annotations

import pytest
import httpx
import respx

from ardyn import ArdynClient, ArdynError, AuthError, NotFoundError, ValidationError
from ardyn.models import (
    Attestation,
    Agent,
    HeartbeatResponse,
    Settlement,
    SubmitProofResponse,
    Tenant,
    TenantConfig,
    UsageStats,
    VerificationResult,
    DashboardData,
)


BASE_URL = "https://api.ardyn.ai"
API_KEY = "test-key-123"


@pytest.fixture
async def client():
    """Create a test client."""
    c = ArdynClient(gateway_url=BASE_URL, api_key=API_KEY)
    yield c
    await c.close()


@respx.mock
@pytest.mark.asyncio
async def test_register_tenant(client: ArdynClient):
    respx.post(f"{BASE_URL}/v1/tenants").mock(
        return_value=httpx.Response(200, json={
            "tenant_id": "t-001",
            "name": "Test Corp",
            "plan": "pro",
            "api_key": "sk-test-abc",
            "created_at": "2025-01-01T00:00:00Z",
        })
    )

    tenant = await client.register_tenant("Test Corp", TenantConfig(plan="pro"))
    assert isinstance(tenant, Tenant)
    assert tenant.tenant_id == "t-001"
    assert tenant.name == "Test Corp"
    assert tenant.plan == "pro"
    assert tenant.api_key == "sk-test-abc"


@respx.mock
@pytest.mark.asyncio
async def test_register_agent(client: ArdynClient):
    respx.post(f"{BASE_URL}/v1/agents/register").mock(
        return_value=httpx.Response(200, json={
            "agent_id": "agent-001",
            "status": "active",
            "heartbeat_interval_secs": 60,
        })
    )

    agent = await client.register_agent("apple_silicon", ["sram_eviction"], "pubkey-hex")
    assert isinstance(agent, Agent)
    assert agent.agent_id == "agent-001"
    assert agent.status == "active"
    assert agent.heartbeat_interval_secs == 60


@respx.mock
@pytest.mark.asyncio
async def test_heartbeat(client: ArdynClient):
    respx.post(f"{BASE_URL}/v1/agents/heartbeat").mock(
        return_value=httpx.Response(200, json={
            "acknowledged": True,
            "pending_attestation_requests": [],
        })
    )

    response = await client.heartbeat("agent-001", "Active", 60, 0)
    assert isinstance(response, HeartbeatResponse)
    assert response.acknowledged is True


@respx.mock
@pytest.mark.asyncio
async def test_attest(client: ArdynClient):
    respx.post(f"{BASE_URL}/v1/attest").mock(
        return_value=httpx.Response(200, json={
            "attestation_id": "att-001",
            "tier": "tier1",
            "ddc_id": "ddc-001",
            "signature": "sig-xyz",
            "timestamp": "2025-01-01T00:00:00Z",
            "scu_charged": 5,
        })
    )

    attestation = await client.attest("calculator", "hash-in", "hash-out")
    assert isinstance(attestation, Attestation)
    assert attestation.attestation_id == "att-001"
    assert attestation.tier == "tier1"
    assert attestation.scu_charged == 5


@respx.mock
@pytest.mark.asyncio
async def test_submit_proof(client: ArdynClient):
    respx.post(f"{BASE_URL}/v1/proofs/submit").mock(
        return_value=httpx.Response(200, json={
            "accepted": True,
            "request_id": "req-001",
            "ddc_id": "ddc-proof-001",
            "verify_url": "https://api.ardyn.ai/v1/verify/ddc-proof-001",
        })
    )

    cert = await client.submit_proof(
        "req-001", "agent-001", "snp", "base64-proof-data", "2025-01-01T00:00:00Z", "sig-proof"
    )
    assert isinstance(cert, SubmitProofResponse)
    assert cert.ddc_id == "ddc-proof-001"
    assert cert.accepted is True


@respx.mock
@pytest.mark.asyncio
async def test_verify(client: ArdynClient):
    respx.get(f"{BASE_URL}/v1/verify/ddc-001").mock(
        return_value=httpx.Response(200, json={
            "valid": True,
            "ddc_id": "ddc-001",
            "sequence": 10,
            "entry_hash": "hash-xyz",
            "ddc_type": "attestation",
            "tenant_id": "t-001",
            "timestamp": "2025-01-01T00:00:00Z",
        })
    )

    result = await client.verify("ddc-001")
    assert isinstance(result, VerificationResult)
    assert result.valid is True
    assert result.ddc_id == "ddc-001"


@respx.mock
@pytest.mark.asyncio
async def test_get_usage(client: ArdynClient):
    respx.get(f"{BASE_URL}/v1/usage").mock(
        return_value=httpx.Response(200, json={
            "tenant_id": "t-001",
            "total_scu": 100,
            "tier1_count": 20,
            "tier_b_count": 80,
            "period_start": "2025-01-01",
        })
    )

    usage = await client.get_usage("t-001")
    assert isinstance(usage, UsageStats)
    assert usage.total_scu == 100


@respx.mock
@pytest.mark.asyncio
async def test_auth_error(client: ArdynClient):
    respx.post(f"{BASE_URL}/v1/attest").mock(
        return_value=httpx.Response(401, text="Unauthorized")
    )

    with pytest.raises(AuthError) as exc_info:
        await client.attest("tool", "in", "out")
    assert exc_info.value.status_code == 401


@respx.mock
@pytest.mark.asyncio
async def test_not_found_error(client: ArdynClient):
    respx.get(f"{BASE_URL}/v1/verify/nonexistent").mock(
        return_value=httpx.Response(404, text="Not found")
    )

    with pytest.raises(NotFoundError) as exc_info:
        await client.verify("nonexistent")
    assert exc_info.value.status_code == 404


@respx.mock
@pytest.mark.asyncio
async def test_validation_error(client: ArdynClient):
    respx.post(f"{BASE_URL}/v1/attest").mock(
        return_value=httpx.Response(422, text="Missing required field: tool_name")
    )

    with pytest.raises(ValidationError) as exc_info:
        await client.attest("", "", "")
    assert exc_info.value.status_code == 400  # ValidationError defaults to 400
