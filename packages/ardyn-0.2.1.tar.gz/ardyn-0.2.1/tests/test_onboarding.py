from __future__ import annotations

import importlib
import json
import sys
import time
from unittest.mock import patch

import pytest
import httpx


def _clear_ardyn_modules() -> None:
    for name in list(sys.modules):
        if name == "ardyn" or name.startswith("ardyn."):
            sys.modules.pop(name, None)


def _import_ardyn():
    _clear_ardyn_modules()
    return importlib.import_module("ardyn")


def test_import_skips_when_env_var_set(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("ARDYN_API_KEY", "env-key")

    with patch("pathlib.Path.home", return_value=tmp_path), patch(
        "builtins.input", side_effect=AssertionError("input should not be called")
    ):
        module = _import_ardyn()

    assert module is not None


def test_import_skips_when_config_exists(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.delenv("ARDYN_API_KEY", raising=False)
    config_dir = tmp_path / ".ardyn"
    config_dir.mkdir()
    (config_dir / "config.json").write_text(json.dumps({"api_key": "cfg-key"}))

    with patch("pathlib.Path.home", return_value=tmp_path), patch(
        "builtins.input", side_effect=AssertionError("input should not be called")
    ):
        module = _import_ardyn()

    assert module is not None


def test_import_skips_when_no_tty(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.delenv("ARDYN_API_KEY", raising=False)
    monkeypatch.setattr(sys.stdin, "isatty", lambda: False)

    with patch("pathlib.Path.home", return_value=tmp_path), patch(
        "builtins.input", side_effect=AssertionError("input should not be called")
    ):
        module = _import_ardyn()

    assert module is not None


def test_client_raises_without_credentials(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.delenv("ARDYN_API_KEY", raising=False)
    monkeypatch.setattr(sys.stdin, "isatty", lambda: False)

    with patch("pathlib.Path.home", return_value=tmp_path):
        module = _import_ardyn()

    with pytest.raises(ValueError, match="No Ardyn credentials found"):
        module.ArdynClient()


def test_onboarding_prints_post_setup_guidance(monkeypatch, tmp_path, capsys):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.delenv("ARDYN_API_KEY", raising=False)

    responses = [
        httpx.Response(
            200,
            json={"tenant_id": "tenant_123", "totp_uri": "otpauth://totp/Ardyn"},
            request=httpx.Request("POST", "https://api.ardyn.ai/onboarding/register"),
        ),
        httpx.Response(
            200,
            json={
                "api_key": "ardyn-key-12345678",
                "tenant_id": "tenant_123",
                "recovery_codes": ["code-1", "code-2"],
            },
            request=httpx.Request("POST", "https://api.ardyn.ai/onboarding/verify-2fa"),
        ),
    ]

    class DummyClient:
        def __init__(self, timeout):
            self.timeout = timeout

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return None

        def post(self, url, json):
            return responses.pop(0)

    with patch("pathlib.Path.home", return_value=tmp_path):
        module = _import_ardyn()

    monkeypatch.setattr(httpx, "Client", DummyClient)
    with patch("builtins.input", side_effect=["Acme", "ops@example.com", "123456"]):
        result = module._run_onboarding_flow(
            require_tty=False,
            show_post_onboarding_guidance=True,
        )

    assert result["api_key"] == "ardyn-key-12345678"
    out = capsys.readouterr().out
    assert "Next steps:" in out
    assert "ardyn init" in out
    assert "enterprise@ardyn.ai" in out


def test_onboarding_skips_post_setup_guidance_for_payment(monkeypatch, tmp_path, capsys):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.delenv("ARDYN_API_KEY", raising=False)

    responses = [
        httpx.Response(
            200,
            json={"tenant_id": "tenant_123", "totp_uri": "otpauth://totp/Ardyn"},
            request=httpx.Request("POST", "https://api.ardyn.ai/onboarding/register"),
        ),
        httpx.Response(
            200,
            json={
                "next_step": "payment",
                "checkout_url": "https://checkout.stripe.test/session",
            },
            request=httpx.Request("POST", "https://api.ardyn.ai/onboarding/verify-2fa"),
        ),
    ]

    class DummyClient:
        def __init__(self, timeout):
            self.timeout = timeout

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return None

        def post(self, url, json):
            return responses.pop(0)

        def get(self, url):
            return httpx.Response(
                200,
                json={"api_key_ready": True, "api_key": "paid-key-12345678"},
                request=httpx.Request("GET", url),
            )

    with patch("pathlib.Path.home", return_value=tmp_path):
        module = _import_ardyn()

    monkeypatch.setattr(httpx, "Client", DummyClient)
    monkeypatch.setattr(time, "sleep", lambda _: None)
    with patch("builtins.input", side_effect=["Acme", "ops@example.com", "123456"]):
        result = module._run_onboarding_flow(
            require_tty=False,
            show_post_onboarding_guidance=True,
        )

    assert result["api_key"] == "paid-key-12345678"
    out = capsys.readouterr().out
    assert "Set up billing to complete your account setup." in out
    assert "Next steps:" not in out
