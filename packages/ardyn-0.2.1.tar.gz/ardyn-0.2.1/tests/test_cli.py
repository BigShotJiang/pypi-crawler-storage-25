from __future__ import annotations

import importlib
import json
import sys
from unittest.mock import patch

import httpx


def _clear_ardyn_modules() -> None:
    for name in list(sys.modules):
        if name == "ardyn" or name.startswith("ardyn."):
            sys.modules.pop(name, None)


def _import_cli():
    _clear_ardyn_modules()
    return importlib.import_module("ardyn.cli")


def test_cli_init_with_existing_account(monkeypatch, tmp_path, capsys):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.delenv("ARDYN_API_KEY", raising=False)
    config_dir = tmp_path / ".ardyn"
    config_dir.mkdir()
    (config_dir / "config.json").write_text(json.dumps({"api_key": "cfg-key"}))

    class DummyClient:
        def __init__(self, timeout, headers=None):
            self.timeout = timeout
            self.headers = headers

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return None

        def post(self, url, json):
            assert url == "https://api.ardyn.ai/v1/agents/register"
            assert json["tenant_api_key"] == "cfg-key"
            assert json["platform"] == "apple_silicon"
            assert json["capabilities"] == ["sram_eviction"]
            assert json["public_key"] == "cli-unmanaged-apple_silicon"
            return httpx.Response(
                200,
                json={"agent_id": "agent_123", "heartbeat_interval_secs": 60},
                request=httpx.Request("POST", url),
            )

    with patch("pathlib.Path.home", return_value=tmp_path):
        cli = _import_cli()

    monkeypatch.setattr("builtins.input", lambda prompt="": "apple_silicon")
    monkeypatch.setattr(cli.httpx, "Client", DummyClient)

    assert cli.main(["init"]) == 0
    out = capsys.readouterr().out
    assert "✓ Account found" in out
    assert "✓ Agent registered: agent_123" in out
    assert "pending approval" in out
    saved = json.loads((config_dir / "config.json").read_text())
    assert saved["agent_id"] == "agent_123"
    assert saved["agent_platform"] == "apple_silicon"


def test_cli_init_runs_onboarding_when_missing_credentials(monkeypatch, tmp_path, capsys):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.delenv("ARDYN_API_KEY", raising=False)

    class DummyClient:
        def __init__(self, timeout, headers=None):
            self.timeout = timeout
            self.headers = headers

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return None

        def post(self, url, json):
            assert url == "https://api.ardyn.ai/v1/agents/register"
            assert json["tenant_api_key"] == "new-key"
            assert json["platform"] == "software_only"
            assert json["capabilities"] == ["sram_eviction"]
            assert json["public_key"] == "cli-unmanaged-software_only"
            return httpx.Response(
                200,
                json={"agent_id": "agent_456", "heartbeat_interval_secs": 60},
                request=httpx.Request("POST", url),
            )

    with patch("pathlib.Path.home", return_value=tmp_path):
        cli = _import_cli()

    monkeypatch.setattr(sys.stdin, "isatty", lambda: True)
    monkeypatch.setattr(
        cli,
        "_run_onboarding_flow",
        lambda **kwargs: {"api_key": "new-key", "tenant_id": "tenant_1"},
    )
    monkeypatch.setattr("builtins.input", lambda prompt="": "")
    monkeypatch.setattr(cli.httpx, "Client", DummyClient)

    assert cli.main(["init"]) == 0
    out = capsys.readouterr().out
    assert "✓ Agent registered: agent_456" in out
    assert "Track status:  https://ardyn.ai/dashboard" in out


def test_cli_heartbeat_rejected_when_pending(monkeypatch, tmp_path, capsys):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.delenv("ARDYN_API_KEY", raising=False)
    config_dir = tmp_path / ".ardyn"
    config_dir.mkdir()
    (config_dir / "config.json").write_text(
        json.dumps({"api_key": "cfg-key", "tenant_id": "tenant_1", "agent_id": "agent_pending"})
    )

    class DummyClient:
        def __init__(self, timeout, headers):
            self.timeout = timeout
            self.headers = headers

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return None

        def get(self, url):
            assert url == "https://api.ardyn.ai/v1/agents/agent_pending/trust"
            assert self.headers == {"Authorization": "Bearer cfg-key"}
            return httpx.Response(
                404,
                json={"error": "Agent trust profile not found"},
                request=httpx.Request("GET", url),
            )

    with patch("pathlib.Path.home", return_value=tmp_path):
        cli = _import_cli()

    monkeypatch.setattr(cli.httpx, "Client", DummyClient)

    assert cli.main(["heartbeat"]) == 1
    err = capsys.readouterr().err
    assert "Agent agent_pending is PendingApproval. Waiting for approval." in err
    assert "enterprise@ardyn.ai" in err
