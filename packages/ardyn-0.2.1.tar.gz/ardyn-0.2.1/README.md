# Ardyn Python SDK

Official Python client for the [Ardyn AI Liability Infrastructure](https://ardyn.ai) API.

## Installation

```bash
pip install ardyn
```

## Quick Start

```python
import asyncio
from ardyn import ArdynClient, TenantConfig

async def main():
    async with ArdynClient(
        gateway_url="https://api.ardyn.ai",
        api_key="your-api-key",
    ) as client:
        # Register a tenant (admin-only route)
        tenant = await client.register_tenant(
            "My Company",
            TenantConfig(plan="pro")
        )
        print(f"Tenant ID: {tenant.tenant_id}")
        print(f"API Key: {tenant.api_key}")

        # Register an agent
        agent = await client.register_agent(
            platform="apple_silicon",
            capabilities=["sram_eviction"],
            public_key="your-ed25519-public-key-hex",
        )
        print(f"Agent ID: {agent.agent_id}")

        # Create an attestation
        attestation = await client.attest(
            tool_name="web_search",
            input_hash="sha256:abc123...",
            output_hash="sha256:def456...",
        )
        print(f"Attestation ID: {attestation.attestation_id}")
        print(f"DDC ID: {attestation.ddc_id}")

        # Verify a DDC
        result = await client.verify(attestation.ddc_id)
        print(f"Valid: {result.valid}")

        # Get usage stats
        usage = await client.get_usage(tenant.tenant_id)
        print(f"Total SCU: {usage.total_scu}")

asyncio.run(main())
```

## Features

- **Async-first**: Built on `httpx` for modern async Python
- **Type-safe**: Full type annotations and dataclass models
- **Auto-retry**: Exponential backoff on transient failures (3 attempts: 1s, 2s, 4s)
- **Connection pooling**: Efficient HTTP/2 connection reuse
- **Comprehensive errors**: Typed exceptions for auth, not-found, validation, and server errors

## API Reference

### `ArdynClient`

```python
ArdynClient(
    gateway_url: str,        # Base URL of the Ardyn gateway
    api_key: str,            # API key for authentication
    timeout: float = 30.0,   # Request timeout in seconds
    max_retries: int = 3,    # Max retry attempts
)
```

### Methods

| Method | Description |
|--------|-------------|
| `register_tenant(name, config?)` | Register a new tenant via the admin-only route |
| `register_agent(platform, capabilities, public_key, manifest_signature?, cert_fingerprint?)` | Register an agent |
| `heartbeat(agent_id, status, uptime_secs, attestations_performed, agent_instance_id?)` | Send agent heartbeat |
| `attest(tool_name, input_hash, output_hash, metadata?)` | Create attestation |
| `submit_proof(request_id, agent_id, proof_type, proof_data, timestamp, signature, input_hash?, output_hash?)` | Submit proof |
| `verify(ddc_id)` | Verify a DDC |
| `get_usage(tenant_id)` | Get usage statistics |
| `get_settlement(tenant_id, period)` | Get settlement details |
| `get_dashboard(tenant_id)` | Get dashboard data |
| `health()` | Check gateway health |

### Error Types

- `ArdynError` - Base exception
- `AuthError` - Authentication failed (401/403)
- `NotFoundError` - Resource not found (404)
- `ValidationError` - Request validation failed (400/422)
- `ServerError` - Server error (5xx)

## Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests
pytest tests/
```

## License

MIT
