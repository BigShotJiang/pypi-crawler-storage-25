"""Ardyn SDK - Official Python client for the Ardyn AI Liability Infrastructure API."""

from . import config
from .client import ArdynClient
from .errors import ArdynError, AuthError, NotFoundError, ServerError, ValidationError
from .models import (
    ActivityEntry,
    Agent,
    Attestation,
    DashboardData,
    DdcCertificate,
    HeartbeatResponse,
    Settlement,
    Tenant,
    TenantConfig,
    UsageStats,
    VerificationResult,
)

__version__ = "0.2.1"


def _has_credentials() -> bool:
    import os

    cfg = config.get_config()
    return bool(cfg.get("api_key") or os.environ.get("ARDYN_API_KEY"))


def _run_onboarding_flow(
    *,
    require_tty: bool = True,
    show_post_onboarding_guidance: bool = False,
):
    import os
    import sys
    import time

    cfg = config.get_config()
    if cfg.get("api_key"):
        return cfg

    if os.environ.get("ARDYN_API_KEY"):
        return {"api_key": os.environ["ARDYN_API_KEY"]}

    if require_tty and not sys.stdin.isatty():
        return None

    print("Let's set up your Ardyn account.\n")

    try:
        name = input("Organization name: ")
        email = input("Email: ")
    except (EOFError, KeyboardInterrupt):
        return None

    try:
        import httpx

        payment_triggered = False
        with httpx.Client(timeout=10) as client:
            register_response = client.post(
                "https://api.ardyn.ai/onboarding/register",
                json={"name": name, "email": email},
            )
            register_response.raise_for_status()
            register_data = register_response.json()

            print("\nScan this QR code with your authenticator app:\n")
            print(f"  {register_data['totp_uri']}\n")

            try:
                code = input("Enter the 6-digit code from your authenticator: ")
            except (EOFError, KeyboardInterrupt):
                return None

            verify_response = client.post(
                "https://api.ardyn.ai/onboarding/verify-2fa",
                json={"tenant_id": register_data["tenant_id"], "code": code},
            )
            verify_response.raise_for_status()
            result = verify_response.json()

            api_key = result.get("api_key")
            if result.get("next_step") == "payment" and result.get("checkout_url"):
                payment_triggered = True
                tenant_id = register_data["tenant_id"]
                print("\nSet up billing to complete your account setup.")
                print(
                    f"Open this link in your browser:\n\n  {result['checkout_url']}\n"
                )
                print("Waiting for payment confirmation", end="", flush=True)

                for _ in range(60):
                    time.sleep(3)
                    print(".", end="", flush=True)
                    try:
                        status_resp = client.get(
                            f"https://api.ardyn.ai/onboarding/status/{tenant_id}"
                        )
                        status_resp.raise_for_status()
                        status_data = status_resp.json()
                        if status_data.get("api_key_ready"):
                            print(" done!")
                            api_key = status_data.get("api_key")
                            break
                    except Exception:
                        continue
                else:
                    print("\nPayment not confirmed after 3 minutes.")
                    print(
                        "Check your email or rerun 'ardyn init' or 'ardyn.onboard()' to resume."
                    )
                    return None

                if not api_key:
                    print(" Could not retrieve API key. Contact support.")
                    return None

                result["api_key"] = api_key
                result["tenant_id"] = tenant_id
    except httpx.HTTPError as exc:
        print(f"Ardyn onboarding failed: {exc}")
        print("You can try again later by running 'ardyn init' or 'ardyn.onboard()' interactively.")
        return None
    except Exception as exc:
        print(f"Ardyn onboarding failed: {exc}")
        print("You can try again later by running 'ardyn init' or 'ardyn.onboard()' interactively.")
        return None

    saved_config = {"api_key": result["api_key"], "tenant_id": result["tenant_id"]}
    config.save_config(saved_config)
    print(f"\nAccount created: {config.mask_key(result['api_key'])}")
    print("API key saved to ~/.ardyn/config.json")
    if result.get("recovery_codes"):
        print(f"Recovery codes: {', '.join(result['recovery_codes'])}")
    if show_post_onboarding_guidance and not payment_triggered:
        print()
        print("Next steps:")
        print("  1. Register your hardware agent:  ardyn init")
        print("  2. Your agent will be reviewed within 24 hours")
        print("  3. Once approved, run:  ardyn heartbeat")
        print("  4. Track attestations at:  https://ardyn.ai/dashboard")
        print()
        print("Questions? enterprise@ardyn.ai")
    return saved_config
def _check_for_updates():
    """Check PyPI for newer versions. Non-blocking daemon thread."""
    import json
    import threading
    import urllib.request

    def _check():
        try:
            url = "https://pypi.org/pypi/ardyn/json"
            req = urllib.request.Request(url, headers={"User-Agent": "ardyn-sdk"})
            resp = urllib.request.urlopen(req, timeout=5)
            data = json.loads(resp.read())
            latest = data["info"]["version"]
            if latest != __version__:
                print(f"\n⚠ Ardyn v{latest} available (you have v{__version__}).")
                print("  Run: pip install --upgrade ardyn\n")
        except Exception:
            pass

    t = threading.Thread(target=_check, daemon=True)
    t.start()


def onboard(
    *,
    require_tty: bool = True,
    show_post_onboarding_guidance: bool = True,
):
    """Run onboarding explicitly.

    Importing ``ardyn`` is side-effect free; callers must opt into onboarding.
    """
    return _run_onboarding_flow(
        require_tty=require_tty,
        show_post_onboarding_guidance=show_post_onboarding_guidance,
    )


def check_for_updates():
    """Check for newer SDK releases explicitly."""
    _check_for_updates()


__all__ = [
    "ArdynClient",
    "config",
    "onboard",
    "check_for_updates",
    "ArdynError",
    "AuthError",
    "NotFoundError",
    "ServerError",
    "ValidationError",
    "ActivityEntry",
    "Agent",
    "Attestation",
    "DashboardData",
    "DdcCertificate",
    "HeartbeatResponse",
    "Settlement",
    "Tenant",
    "TenantConfig",
    "UsageStats",
    "VerificationResult",
]
