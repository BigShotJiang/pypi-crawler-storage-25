"""Data models for the Ardyn SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class TenantConfig:
    """Configuration for creating a new tenant."""

    plan: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class Tenant:
    """A registered tenant."""

    tenant_id: str
    name: str
    plan: str
    api_key: str
    created_at: Optional[str] = None


@dataclass
class Agent:
    """A registered agent."""

    agent_id: str
    status: str
    heartbeat_interval_secs: int


@dataclass
class PendingAttestationRequest:
    """A pending attestation request returned by heartbeat."""

    request_id: str
    call_id: str
    input_hash: str
    output_hash: str
    required_proof_type: str
    expires_at: str


@dataclass
class HeartbeatResponse:
    """Response from an agent heartbeat."""

    acknowledged: bool
    pending_attestation_requests: List[PendingAttestationRequest] = field(default_factory=list)


@dataclass
class Attestation:
    """A created attestation record."""

    attestation_id: str
    tier: str
    signature: str
    timestamp: str
    scu_charged: int
    ddc_id: Optional[str] = None
    fallback_reason: Optional[str] = None


@dataclass
class SubmitProofResponse:
    """Acceptance envelope returned after proof submission."""

    accepted: bool
    request_id: str
    ddc_id: Optional[str] = None
    verify_url: Optional[str] = None
    receipt: Optional[Dict[str, Any]] = None


DdcCertificate = SubmitProofResponse


@dataclass
class VerificationResult:
    """Result of verifying a DDC."""

    valid: bool
    ddc_id: str
    sequence: Optional[int] = None
    entry_hash: Optional[str] = None
    ddc_type: Optional[str] = None
    ddc_payload: Optional[Dict[str, Any]] = None
    tenant_id: Optional[str] = None
    timestamp: Optional[str] = None


@dataclass
class UsageStats:
    """Usage statistics for a tenant."""

    tenant_id: str
    total_scu: int
    tier1_count: int
    tier_b_count: int
    period_start: str


@dataclass
class Settlement:
    """Settlement details for a billing period."""

    tenant_id: str
    period: str
    total_scu: int
    amount_due: str
    currency: str
    status: str
    settled_at: Optional[str] = None


@dataclass
class ActivityEntry:
    """A single activity entry in the dashboard."""

    activity_type: str
    timestamp: str
    description: Optional[str] = None


@dataclass
class DashboardData:
    """Dashboard data for a tenant."""

    tenant_id: str
    total_attestations: int
    period_attestations: int
    total_scu: int
    active_agents: int
    period_start: str
    recent_activity: Optional[List[ActivityEntry]] = field(default=None)


@dataclass
class HealthResponse:
    """Gateway health check response."""

    status: str
    version: str
