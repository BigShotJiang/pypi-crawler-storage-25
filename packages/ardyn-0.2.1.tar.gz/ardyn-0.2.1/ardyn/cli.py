"""Command-line interface for the Ardyn Python SDK."""

from __future__ import annotations

import argparse
import os
import sys

import httpx

from . import _run_onboarding_flow, config

_GATEWAY_URL = "https://api.ardyn.ai"


def _auth_headers(api_key: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {api_key}"}


def _get_api_key() -> str | None:
    if os.environ.get("ARDYN_API_KEY"):
        return os.environ["ARDYN_API_KEY"]

    cfg = config.get_config()
    return cfg.get("api_key")


def _detect_platform() -> str:
    prompt = (
        "Hardware platform "
        "[apple_silicon/nitro_enclave/sev_snp/intel_sgx/software_only]: "
    )
    try:
        raw_platform = input(prompt).strip().lower()
    except (EOFError, KeyboardInterrupt) as exc:
        raise RuntimeError("Platform selection cancelled.") from exc

    if not raw_platform:
        return "software_only"

    aliases = {
        "applesilicon": "apple_silicon",
        "amd_sev": "sev_snp",
        "sevsnp": "sev_snp",
        "intelsgx": "intel_sgx",
        "nitroenclave": "nitro_enclave",
    }
    platform = aliases.get(raw_platform, raw_platform)

    if platform not in (
        "apple_silicon",
        "nitro_enclave",
        "sev_snp",
        "intel_sgx",
        "software_only",
    ):
        raise RuntimeError(f"Unsupported platform: {raw_platform}")
    return platform


def _capabilities_for_platform(platform: str) -> list[str]:
    capabilities = {
        "apple_silicon": ["sram_eviction"],
        "nitro_enclave": ["tpm_quote"],
        "sev_snp": ["enclave_attestation", "confidential_compute"],
        "intel_sgx": ["enclave_attestation"],
        "software_only": ["sram_eviction"],
    }
    return capabilities[platform]


def _register_agent(api_key: str, platform: str) -> tuple[str, int | None]:
    with httpx.Client(timeout=10, headers=_auth_headers(api_key)) as client:
        response = client.post(
            f"{_GATEWAY_URL}/v1/agents/register",
            json={
                "tenant_api_key": api_key,
                "platform": platform,
                "capabilities": _capabilities_for_platform(platform),
                "public_key": f"cli-unmanaged-{platform}",
            },
        )
        response.raise_for_status()
        data = response.json()

    agent_id = data.get("agent_id")
    if not agent_id:
        raise RuntimeError("Agent registration did not return an agent_id.")
    return agent_id, data.get("heartbeat_interval_secs")


def _run_init() -> int:
    api_key = _get_api_key()
    if api_key:
        print("✓ Account found")
    else:
        if not sys.stdin.isatty():
            raise RuntimeError(
                "No Ardyn credentials found and no interactive terminal is available."
            )
        result = _run_onboarding_flow(
            require_tty=False,
            show_post_onboarding_guidance=False,
        )
        if not result or not result.get("api_key"):
            raise RuntimeError("Onboarding did not complete.")
        api_key = result["api_key"]

    platform = _detect_platform()
    agent_id, heartbeat_interval_secs = _register_agent(api_key, platform)

    cfg = config.get_config()
    cfg.update(
        {
            "api_key": api_key,
            "agent_id": agent_id,
            "agent_platform": platform,
        }
    )
    if heartbeat_interval_secs is not None:
        cfg["heartbeat_interval_secs"] = heartbeat_interval_secs
    config.save_config(cfg)

    print(f"✓ Agent registered: {agent_id}")
    print()
    print("Your agent is pending approval. We'll review within 24 hours.")
    print("Once approved, run:  ardyn heartbeat")
    print()
    print("Track status:  https://ardyn.ai/dashboard")
    print("Questions? enterprise@ardyn.ai")
    return 0


def _run_heartbeat() -> int:
    import time

    api_key = _get_api_key()
    if not api_key:
        print("No Ardyn credentials found. Run: ardyn init", file=sys.stderr)
        return 1

    cfg = config.get_config()
    agent_id = cfg.get("agent_id")
    if not agent_id:
        print("No agent is configured. Run: ardyn init", file=sys.stderr)
        return 1

    with httpx.Client(timeout=10, headers=_auth_headers(api_key)) as client:
        resp = client.get(f"{_GATEWAY_URL}/v1/agents/{agent_id}/trust")
        if resp.status_code == 404:
            print(f"Agent {agent_id} is PendingApproval. Waiting for approval.", file=sys.stderr)
            print(
                "Check https://ardyn.ai/dashboard or contact enterprise@ardyn.ai",
                file=sys.stderr,
            )
            return 1
        resp.raise_for_status()
        agent = resp.json()

    status = str(agent.get("status", "Active"))
    normalized_status = status.lower()

    if normalized_status not in ("active", "degraded"):
        print(f"Agent {agent_id} is {status}. Waiting for approval.", file=sys.stderr)
        print(
            "Check https://ardyn.ai/dashboard or contact enterprise@ardyn.ai",
            file=sys.stderr,
        )
        return 1

    heartbeat_interval = int(cfg.get("heartbeat_interval_secs") or 60)

    print(f"Starting heartbeat daemon for agent {agent_id}")
    print(f"Status: {status}")
    print(f"Heartbeating every {heartbeat_interval} seconds. Press Ctrl+C to stop.")

    uptime_start = time.time()
    attestations = 0

    try:
        while True:
            uptime = int(time.time() - uptime_start)
            with httpx.Client(timeout=10, headers=_auth_headers(api_key)) as client:
                resp = client.post(
                    f"{_GATEWAY_URL}/v1/agents/heartbeat",
                    json={
                        "agent_id": agent_id,
                        "status": "Active",
                        "uptime_secs": uptime,
                        "attestations_performed": attestations,
                    },
                )
                resp.raise_for_status()
                result = resp.json()

            if result.get("acknowledged"):
                print(f"✓ Heartbeat acknowledged (uptime: {uptime}s)")
            else:
                print("⚠ Heartbeat sent but not acknowledged")

            pending = result.get("pending_attestation_requests", [])
            if pending:
                print(f"  → {len(pending)} pending attestation(s)")

            time.sleep(heartbeat_interval)
    except KeyboardInterrupt:
        print("\nHeartbeat daemon stopped.")
        return 0
    except httpx.HTTPError as exc:
        print(f"Heartbeat failed: {exc}", file=sys.stderr)
        return 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="ardyn")
    subparsers = parser.add_subparsers(dest="command")
    subparsers.add_parser("init")
    subparsers.add_parser("heartbeat")

    args = parser.parse_args(argv)

    if args.command == "init":
        try:
            return _run_init()
        except Exception as exc:
            print(f"Ardyn init failed: {exc}", file=sys.stderr)
            return 1

    if args.command == "heartbeat":
        try:
            return _run_heartbeat()
        except Exception as exc:
            print(f"Ardyn heartbeat failed: {exc}", file=sys.stderr)
            return 1

    if args.command is None:
        parser.print_help()
        return 1
    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
