"""Async HTTP client for the Ardyn API."""

from __future__ import annotations

import asyncio
import os
from typing import Any, Dict, Optional, Type, TypeVar

import httpx

from . import config
from ardyn.errors import ArdynError, AuthError, NotFoundError, ServerError, ValidationError
from ardyn.models import (
    ActivityEntry,
    Agent,
    Attestation,
    DashboardData,
    HeartbeatResponse,
    HealthResponse,
    PendingAttestationRequest,
    Settlement,
    SubmitProofResponse,
    Tenant,
    TenantConfig,
    UsageStats,
    VerificationResult,
)

T = TypeVar("T")

# Retry constants
_MAX_RETRIES = 3
_INITIAL_BACKOFF = 1.0  # seconds


class ArdynClient:
    """Async client for the Ardyn AI Liability Infrastructure API.

    Example::

        import asyncio
        from ardyn import ArdynClient

        async def main():
            async with ArdynClient(
                gateway_url="https://api.ardyn.ai",
                api_key="your-api-key",
            ) as client:
                tenant = await client.register_tenant("My Company")
                print(f"Tenant ID: {tenant.tenant_id}")

        asyncio.run(main())
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        gateway_url: str = "https://api.ardyn.ai",
        *,
        timeout: float = 30.0,
        max_retries: int = _MAX_RETRIES,
    ):
        """Initialize the Ardyn client.

        Args:
            gateway_url: Base URL of the Ardyn gateway (e.g., "https://api.ardyn.ai").
            api_key: API key for authentication. If omitted, the client checks
                `ARDYN_API_KEY`, then `~/.ardyn/config.json`, then falls back
                to interactive onboarding.
            timeout: Request timeout in seconds (default: 30).
            max_retries: Maximum retry attempts for transient failures (default: 3).
        """
        self.gateway_url = gateway_url.rstrip("/")
        if api_key is not None:
            self.api_key = api_key
        elif os.environ.get("ARDYN_API_KEY"):
            self.api_key = os.environ["ARDYN_API_KEY"]
        else:
            cfg = config.get_config()
            if cfg.get("api_key"):
                self.api_key = cfg["api_key"]
            else:
                raise ValueError(
                    "No Ardyn credentials found. Run 'ardyn init' or call "
                    "'ardyn.onboard()' interactively to create an account, or set "
                    "the ARDYN_API_KEY environment variable."
                )

        self.max_retries = max_retries
        self._client = httpx.AsyncClient(
            base_url=self.gateway_url,
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "User-Agent": "ardyn-python/0.2.1",
            },
        )

    def _interactive_onboarding(self, gateway_url: str) -> str:
        """Guide the user through 2FA onboarding when no credentials exist."""
        print("No Ardyn account found. Let's create one.\n")
        name = input("Organization name: ")
        email = input("Email: ")

        resp = httpx.post(
            f"{gateway_url}/onboarding/register",
            json={"name": name, "email": email},
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json()

        print("\nScan this QR code with your authenticator app:\n")
        print(f"  {data['totp_uri']}\n")

        code = input("Enter the 6-digit code from your authenticator: ")
        resp2 = httpx.post(
            f"{gateway_url}/onboarding/verify-2fa",
            json={"tenant_id": str(data["tenant_id"]), "code": code},
            timeout=10,
        )
        resp2.raise_for_status()
        result = resp2.json()

        cfg = {"api_key": result["api_key"], "tenant_id": str(data["tenant_id"])}
        config.save_config(cfg)

        print(f"\nAccount created: {config.mask_key(result['api_key'])}")
        print("API key saved to ~/.ardyn/config.json")
        if "recovery_codes" in data:
            print(f"Recovery codes: {', '.join(data['recovery_codes'])}")
            print("  Store these somewhere safe.\n")

        return result["api_key"]

    async def __aenter__(self) -> "ArdynClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    # ─── Tenant Management ────────────────────────────────────────────────────

    async def register_tenant(
        self,
        name: str,
        config: Optional[TenantConfig] = None,
    ) -> Tenant:
        """Register a new tenant.

        This route is admin-only on the gateway.

        Args:
            name: Display name for the tenant.
            config: Optional tenant configuration (plan, metadata).

        Returns:
            The registered Tenant object.
        """
        payload: Dict[str, Any] = {"name": name}
        if config:
            if config.plan:
                payload["plan"] = config.plan
            if config.metadata:
                payload["metadata"] = config.metadata

        data = await self._post("/v1/tenants", payload)
        return Tenant(
            tenant_id=data["tenant_id"],
            name=data["name"],
            plan=data["plan"],
            api_key=data["api_key"],
            created_at=data.get("created_at"),
        )

    # ─── Agent Management ─────────────────────────────────────────────────────

    async def register_agent(
        self,
        platform: str,
        capabilities: list[str],
        public_key: str,
        manifest_signature: Optional[str] = None,
        cert_fingerprint: Optional[str] = None,
    ) -> Agent:
        """Register a new agent.

        Args:
            platform: Agent runtime platform identifier.
            capabilities: Agent capability strings accepted by the gateway.
            public_key: The agent's public key (hex or base64 encoded).
            manifest_signature: Optional signed runtime manifest.
            cert_fingerprint: Optional TLS certificate fingerprint.

        Returns:
            The registered Agent object.
        """
        payload: Dict[str, Any] = {
            "tenant_api_key": self.api_key,
            "platform": platform,
            "capabilities": capabilities,
            "public_key": public_key,
        }
        if manifest_signature is not None:
            payload["manifest_signature"] = manifest_signature
        if cert_fingerprint is not None:
            payload["cert_fingerprint"] = cert_fingerprint

        data = await self._post("/v1/agents/register", payload)
        return Agent(
            agent_id=data["agent_id"],
            status=data["status"],
            heartbeat_interval_secs=data["heartbeat_interval_secs"],
        )

    async def heartbeat(
        self,
        agent_id: str,
        status: str,
        uptime_secs: int,
        attestations_performed: int,
        agent_instance_id: Optional[str] = None,
    ) -> HeartbeatResponse:
        """Send a heartbeat for an agent.

        Args:
            agent_id: The agent identifier.
            status: Agent lifecycle status reported to the gateway.
            uptime_secs: Agent uptime in seconds.
            attestations_performed: Number of attestations completed.
            agent_instance_id: Optional cloud/runtime instance identifier.

        Returns:
            HeartbeatResponse indicating acknowledgement.
        """
        payload: Dict[str, Any] = {
            "agent_id": agent_id,
            "status": status,
            "uptime_secs": uptime_secs,
            "attestations_performed": attestations_performed,
        }
        if agent_instance_id is not None:
            payload["agent_instance_id"] = agent_instance_id

        data = await self._post("/v1/agents/heartbeat", payload)
        return HeartbeatResponse(
            acknowledged=data["acknowledged"],
            pending_attestation_requests=[
                PendingAttestationRequest(**request)
                for request in data.get("pending_attestation_requests", [])
            ],
        )

    # ─── Attestation ──────────────────────────────────────────────────────────

    async def attest(
        self,
        tool_name: str,
        input_hash: str,
        output_hash: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Attestation:
        """Create a new attestation for a tool invocation.

        Args:
            tool_name: Name of the tool being attested.
            input_hash: Hash of the tool input.
            output_hash: Hash of the tool output.
            metadata: Optional request metadata forwarded to the gateway.

        Returns:
            The created Attestation object.
        """
        data = await self._post("/v1/attest", {
            "api_key": self.api_key,
            "tool_name": tool_name,
            "input_hash": input_hash,
            "output_hash": output_hash,
            "metadata": metadata,
        })
        return Attestation(
            attestation_id=data["attestation_id"],
            tier=data["tier"],
            signature=data["signature"],
            timestamp=data["timestamp"],
            scu_charged=data["scu_charged"],
            ddc_id=data.get("ddc_id"),
            fallback_reason=data.get("fallback_reason"),
        )

    # ─── Proof Submission ─────────────────────────────────────────────────────

    async def submit_proof(
        self,
        request_id: str,
        agent_id: str,
        proof_type: str,
        proof_data: str,
        timestamp: str,
        signature: str,
        input_hash: Optional[str] = None,
        output_hash: Optional[str] = None,
    ) -> SubmitProofResponse:
        """Submit a cryptographic proof and receive the gateway acceptance envelope.

        Args:
            request_id: Coordinator request identifier.
            agent_id: The agent submitting the proof.
            proof_type: Type of proof (e.g., "snp", "sgx", "software").
            proof_data: The proof payload (base64 or hex encoded).
            timestamp: Proof timestamp in ISO-8601 format.
            signature: Hex-encoded signature for the proof payload.
            input_hash: Optional input hash for direct proof submissions.
            output_hash: Optional output hash for direct proof submissions.

        Returns:
            The gateway acceptance response.
        """
        payload: Dict[str, Any] = {
            "request_id": request_id,
            "agent_id": agent_id,
            "proof_type": proof_type,
            "proof_data": proof_data,
            "timestamp": timestamp,
            "signature": signature,
        }
        if input_hash is not None:
            payload["input_hash"] = input_hash
        if output_hash is not None:
            payload["output_hash"] = output_hash

        data = await self._post("/v1/proofs/submit", payload)
        return SubmitProofResponse(
            accepted=data["accepted"],
            request_id=data["request_id"],
            ddc_id=data.get("ddc_id"),
            verify_url=data.get("verify_url"),
            receipt=data.get("receipt"),
        )

    # ─── Verification ─────────────────────────────────────────────────────────

    async def verify(self, ddc_id: str) -> VerificationResult:
        """Verify a DDC by its identifier.

        Args:
            ddc_id: The DDC identifier to verify.

        Returns:
            VerificationResult with validity and metadata.
        """
        data = await self._get(f"/v1/verify/{ddc_id}")
        return VerificationResult(
            valid=data["valid"],
            ddc_id=data["ddc_id"],
            sequence=data.get("sequence"),
            entry_hash=data.get("entry_hash"),
            ddc_type=data.get("ddc_type"),
            ddc_payload=data.get("ddc_payload"),
            tenant_id=data.get("tenant_id"),
            timestamp=data.get("timestamp"),
        )

    # ─── Usage & Billing ──────────────────────────────────────────────────────

    async def get_usage(self, tenant_id: str) -> UsageStats:
        """Get usage statistics for a tenant.

        Args:
            tenant_id: The tenant identifier.

        Returns:
            UsageStats for the current billing period.
        """
        data = await self._get("/v1/usage")
        return UsageStats(
            tenant_id=data["tenant_id"],
            total_scu=data["total_scu"],
            tier1_count=data["tier1_count"],
            tier_b_count=data["tier_b_count"],
            period_start=data["period_start"],
        )

    async def get_settlement(self, tenant_id: str, period: str) -> Settlement:
        """Get settlement details for a tenant and billing period.

        Args:
            tenant_id: Tenant identifier.
            period: Billing period (e.g., "2025-01").

        Returns:
            Settlement details.
        """
        data = await self._get(f"/v1/settlement?tenant_id={tenant_id}&period={period}")
        return Settlement(
            tenant_id=data["tenant_id"],
            period=data["period"],
            total_scu=data["total_scu"],
            amount_due=data["amount_due"],
            currency=data["currency"],
            status=data["status"],
            settled_at=data.get("settled_at"),
        )

    async def get_dashboard(self, tenant_id: str) -> DashboardData:
        """Get dashboard data for a tenant.

        Args:
            tenant_id: Tenant identifier.

        Returns:
            DashboardData with summary and activity.
        """
        data = await self._get("/v1/dashboard")

        recent_activity = None
        if data.get("recent_activity"):
            recent_activity = [
                ActivityEntry(
                    activity_type=a["activity_type"],
                    timestamp=a["timestamp"],
                    description=a.get("description"),
                )
                for a in data["recent_activity"]
            ]

        return DashboardData(
            tenant_id=data["tenant_id"],
            total_attestations=data["total_attestations"],
            period_attestations=data["period_attestations"],
            total_scu=data["total_scu"],
            active_agents=data["active_agents"],
            period_start=data["period_start"],
            recent_activity=recent_activity,
        )

    # ─── Health ───────────────────────────────────────────────────────────────

    async def health(self) -> HealthResponse:
        """Check gateway health. Does not require authentication."""
        resp = await self._client.get("/v1/health")
        resp.raise_for_status()
        data = resp.json()
        return HealthResponse(status=data["status"], version=data["version"])

    # ─── Internal Helpers ─────────────────────────────────────────────────────

    async def _get(self, path: str) -> Dict[str, Any]:
        """Execute a GET request with retry."""
        return await self._request_with_retry("GET", path)

    async def _post(self, path: str, json: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a POST request with retry."""
        return await self._request_with_retry("POST", path, json=json)

    async def _request_with_retry(
        self,
        method: str,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Execute a request with exponential backoff retry."""
        last_error: Optional[ArdynError] = None
        backoff = _INITIAL_BACKOFF

        for attempt in range(self.max_retries):
            try:
                if method == "GET":
                    resp = await self._client.get(path)
                else:
                    resp = await self._client.post(path, json=json)

                # Don't retry client errors (4xx) except 429
                if 400 <= resp.status_code < 500 and resp.status_code != 429:
                    return self._handle_response(resp)

                # Retry on 429 and 5xx
                if resp.status_code == 429 or resp.status_code >= 500:
                    error_body = resp.text
                    last_error = ServerError(
                        f"HTTP {resp.status_code}: {error_body}",
                        status_code=resp.status_code,
                    )
                    if attempt < self.max_retries - 1:
                        await asyncio.sleep(backoff)
                        backoff *= 2
                        continue
                    raise last_error

                return self._handle_response(resp)

            except httpx.HTTPError as e:
                last_error = ArdynError(f"Network error: {e}")
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(backoff)
                    backoff *= 2
                    continue
                raise last_error from e

        raise last_error or ArdynError("Max retries exceeded")

    def _handle_response(self, resp: httpx.Response) -> Dict[str, Any]:
        """Map HTTP response to data dict or raise appropriate error."""
        if resp.is_success:
            return resp.json()

        body = resp.text
        status = resp.status_code

        if status in (401, 403):
            raise AuthError(f"HTTP {status}: {body}", body=body)
        elif status == 404:
            raise NotFoundError(f"HTTP {status}: {body}", body=body)
        elif status in (400, 422):
            raise ValidationError(f"HTTP {status}: {body}", body=body)
        else:
            raise ServerError(f"HTTP {status}: {body}", status_code=status, body=body)
