"""Error types for the Ardyn SDK."""

from __future__ import annotations

from typing import Any, Optional


class ArdynError(Exception):
    """Base exception for all Ardyn SDK errors."""

    def __init__(self, message: str, status_code: Optional[int] = None, body: Any = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.body = body

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(message={self.message!r}, status_code={self.status_code})"


class AuthError(ArdynError):
    """Raised when authentication fails (HTTP 401/403)."""

    def __init__(self, message: str = "Authentication failed", body: Any = None):
        super().__init__(message, status_code=401, body=body)


class NotFoundError(ArdynError):
    """Raised when a resource is not found (HTTP 404)."""

    def __init__(self, message: str = "Resource not found", body: Any = None):
        super().__init__(message, status_code=404, body=body)


class ValidationError(ArdynError):
    """Raised when request validation fails (HTTP 400/422)."""

    def __init__(self, message: str = "Validation error", body: Any = None):
        super().__init__(message, status_code=400, body=body)


class ServerError(ArdynError):
    """Raised when the server returns an unexpected error (HTTP 5xx)."""

    def __init__(self, message: str = "Server error", status_code: int = 500, body: Any = None):
        super().__init__(message, status_code=status_code, body=body)
