#!/usr/bin/env python3
"""
Basic Attestation Example — Ardyn Python SDK

Demonstrates the complete attestation lifecycle using the ArdynClient:
  1. Health check (no auth required)
  2. Tenant registration (admin endpoint)
  3. Attestation creation
  4. DDC verification
  5. Usage / dashboard retrieval
  6. Sovereign platform classification
  7. Sovereign evidence submission

Requirements:
    pip install ardyn

Set your API key via one of:
    - ARDYN_API_KEY environment variable
    - ~/.ardyn/config.json (or run `ardyn init`)

Usage:
    python basic_attestation.py
"""

import asyncio
import os
from datetime import datetime, timezone
from hashlib import sha256

from ardyn import ArdynClient, ArdynError, AuthError


# ── Configuration ──────────────────────────────────────────────────────────

GATEWAY_URL = os.environ.get("ARDYN_GATEWAY_URL", "https://api.ardyn.ai")
API_KEY = os.environ.get("ARDYN_API_KEY")
TENANT_NAME = "Example Corp"


# ── Helpers ────────────────────────────────────────────────────────────────

def hash_input(text: str) -> str:
    """Return hex-encoded SHA-256 hash of the input string."""
    return sha256(text.encode()).hexdigest()


def timestamp_iso() -> str:
    """Return ISO-8601 timestamp in UTC."""
    return datetime.now(timezone.utc).isoformat()


# ── Main ───────────────────────────────────────────────────────────────────

async def main():
    print("=" * 60)
    print(" Ardyn SDK — Basic Attestation Example")
    print("=" * 60)

    api_key = API_KEY

    #
    # 1. Health check (public route, no key needed)
    #
    print("\n── 1. Health Check ──")
    async with ArdynClient(gateway_url=GATEWAY_URL, api_key="demo-key") as client:
        try:
            health = await client.health()
            print(f"   Gateway status : {health.status}")
            print(f"   Version        : {health.version}")
        except ArdynError as exc:
            print(f"   Health check failed: {exc}")

    if not api_key:
        print("\n⚠  ARDYN_API_KEY not set. "
              "Set it to run the tenant & attestation examples.")
        print("   You can still try the public endpoints below.\\n")
    else:
        async with ArdynClient(gateway_url=GATEWAY_URL, api_key=api_key) as client:
            #
            # 2. Tenant registration (admin-only route)
            #
            print("\n── 2. Tenant Registration ──")
            try:
                tenant = await client.register_tenant(TENANT_NAME)
                print(f"   Tenant ID : {tenant.tenant_id}")
                print(f"   Name      : {tenant.name}")
                print(f"   Plan      : {tenant.plan}")
            except AuthError:
                print("   Skipped — API key does not have admin privileges.")
            except ArdynError as exc:
                print(f"   Skipped — {exc}")

            #
            # 3. Attestation creation
            #
            print("\n── 3. Attestation ──")
            tool_name = "text_analyzer"
            input_data = "What is the capital of France?"
            output_data = "The capital of France is Paris."

            input_hash = hash_input(input_data)
            output_hash = hash_input(output_data)

            print(f"   Tool       : {tool_name}")
            print(f"   Input hash : {input_hash[:16]}...")
            print(f"   Output hash: {output_hash[:16]}...")

            try:
                attestation = await client.attest(
                    tool_name=tool_name,
                    input_hash=input_hash,
                    output_hash=output_hash,
                )
                print(f"   Attestation ID : {attestation.attestation_id}")
                print(f"   Tier           : {attestation.tier}")
                print(f"   SCU charged    : {attestation.scu_charged}")
                if attestation.ddc_id:
                    print(f"   DDC ID         : {attestation.ddc_id}")

                    #
                    # 4. DDC verification
                    #
                    print("\n── 4. Verify DDC ──")
                    verification = await client.verify(attestation.ddc_id)
                    print(f"   Valid      : {verification.valid}")
                    print(f"   DDC ID     : {verification.ddc_id}")
                    if verification.entry_hash:
                        print(f"   Entry hash : {verification.entry_hash}")
                    if verification.sequence is not None:
                        print(f"   Sequence   : {verification.sequence}")
            except ArdynError as exc:
                print(f"   Attestation failed: {exc}")

            #
            # 5. Usage and Dashboard
            #
            print("\n── 5. Usage & Dashboard ──")
            try:
                usage = await client.get_usage(tenant_id="demo")
                print(f"   Total SCU     : {usage.total_scu}")
                print(f"   Tier 1 count  : {usage.tier_1_count}")
                print(f"   Tier B count  : {usage.tier_b_count}")
            except ArdynError as exc:
                print(f"   Usage retrieval failed: {exc}")

            try:
                dashboard = await client.get_dashboard(tenant_id="demo")
                print(f"   Dashboard tenant      : {dashboard.tenant_id}")
                print(f"   Total attestations    : {dashboard.total_attestations}")
                print(f"   Period attestations   : {dashboard.period_attestations}")
                print(f"   Active agents         : {dashboard.active_agents}")
            except ArdynError as exc:
                print(f"   Dashboard failed: {exc}")

    #
    # 6. Sovereign platform classification (public route)
    #
    print("\n── 6. Sovereign Platform Classification ──")
    async with ArdynClient(gateway_url=GATEWAY_URL, api_key="public") as client:
        try:
            # Classify Apple Silicon
            apple_result = await client.classify_sovereign("apple_silicon")
            print(f"   Apple Silicon:")
            print(f"     Verdict              : {apple_result.get('verdict', 'N/A')}")
            print(f"     Confidence           : {apple_result.get('confidence_level', 'N/A')}")
            print(f"     Proof strength       : {apple_result.get('proof_strength', 'N/A')}")
            if apple_result.get('limitations'):
                print(f"     Limitations          : {len(apple_result['limitations'])} noted")
        except ArdynError as exc:
            print(f"   Classification failed: {exc}")

    #
    # 7. Sovereign evidence submission
    #
    print("\n── 7. Sovereign Evidence Submission ──")
    async with ArdynClient(gateway_url=GATEWAY_URL, api_key="public") as client:
        try:
            from ardyn.models import SovereignEvidence

            evidence = SovereignEvidence(
                evidence_tier="hardware_rooted",
                hardware_platform="Apple Silicon",
                proof_strength="verified",
                experimental=False,
                scrubber_executed=True,
                dispatch_count=5,
                scrub_pass_count=5,
                zero_state_pass=True,
                cross_model_clean=True,
                iosurface_observed=True,
                sram_eviction_inferred=True,
                sram_contents_verified=True,
                zero_trace_claimed=False,
                verifier_notes="Example sovereign evidence submission.",
                limitations=[],
                experiment_label="",
                run_id="example-run-001",
                timestamp=timestamp_iso(),
                agent_id="00000000-0000-0000-0000-000000000000",
            )
            result = await client.verify_sovereign(evidence)
            print(f"   Verdict          : {result.get('verdict', 'N/A')}")
            print(f"   Coherence score  : {result.get('coherence_score', 'N/A')}")
            if result.get('dimensions'):
                for key, dim in result['dimensions'].items():
                    print(f"     {key:35s} {dim.get('score', 0):.2f}")
        except ArdynError as exc:
            print(f"   Sovereign verification failed: {exc}")

    print("\n" + "=" * 60)
    print(" Example complete.")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
