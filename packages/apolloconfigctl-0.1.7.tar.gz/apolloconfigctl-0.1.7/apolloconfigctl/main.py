import json
import os
from typing import Annotated, Optional

import httpx
import typer

app = typer.Typer(help="ApolloConfig Gateway CLI 客户端")

_state: dict = {"api_url": ""}


def _get_api_url() -> str:
    url = _state["api_url"]
    if not url:
        url = os.environ.get("APOLLO_API_URL", "")
    if not url:
        typer.echo("错误：请通过 --api-url 或环境变量 APOLLO_API_URL 指定 API 地址", err=True)
        raise typer.Exit(1)
    return url.rstrip("/")


def _get(path: str, params: dict | None = None) -> None:
    url = f"{_get_api_url()}{path}"
    with httpx.Client(timeout=30.0) as client:
        resp = client.get(url, params=params)
        resp.raise_for_status()
        _print(resp)


def _post(path: str, json_body: dict | None = None) -> None:
    url = f"{_get_api_url()}{path}"
    with httpx.Client(timeout=30.0) as client:
        resp = client.post(url, json=json_body)
        resp.raise_for_status()
        _print(resp)


def _print(resp: httpx.Response) -> None:
    try:
        data = resp.json()
        typer.echo(json.dumps(data, ensure_ascii=False, indent=2))
    except (json.JSONDecodeError, ValueError):
        typer.echo(resp.text)


@app.callback()
def main(
    api_url: Annotated[
        Optional[str],
        typer.Option("--api-url", envvar="APOLLO_API_URL", help="ApolloConfig Gateway API 地址，如 http://localhost:8000/api"),
    ] = None,
):
    """ApolloConfig Gateway CLI 客户端"""
    if api_url:
        _state["api_url"] = api_url


@app.command()
def get_app_env_clusters(
    app_id: Annotated[str, typer.Option("--app-id", help="应用的唯一标识，即 AppId")],
):
    """获取指定 App 在各环境下拥有的集群列表"""
    _get("/getAppEnvClusters", {"appId": app_id})


@app.command()
def get_apps(
    app_ids: Annotated[Optional[str], typer.Option("--app-ids", help="需要查询的 appId 列表，以逗号分隔")] = None,
):
    """获取 Apollo 中的应用列表"""
    params = {}
    if app_ids:
        params["appIds"] = app_ids
    _get("/getApps", params or None)


@app.command()
def get_cluster(
    env: Annotated[str, typer.Option("--env", help="环境标识，如 DEV、FAT、UAT、PRO")],
    app_id: Annotated[str, typer.Option("--app-id", help="应用的唯一标识，即 AppId")],
    cluster_name: Annotated[str, typer.Option("--cluster-name", help="集群名称")],
):
    """获取指定集群的详细信息"""
    _get("/getCluster", {"env": env, "appId": app_id, "clusterName": cluster_name})


@app.command()
def get_cluster_namespaces(
    env: Annotated[str, typer.Option("--env", help="环境标识，如 DEV、FAT、UAT、PRO")],
    app_id: Annotated[str, typer.Option("--app-id", help="应用的唯一标识，即 AppId")],
    cluster_name: Annotated[str, typer.Option("--cluster-name", help="集群名称")],
):
    """获取指定集群下所有 Namespace 及其配置项"""
    _get("/getClusterNamespaces", {"env": env, "appId": app_id, "clusterName": cluster_name})


@app.command()
def get_namespace(
    env: Annotated[str, typer.Option("--env", help="环境标识，如 DEV、FAT、UAT、PRO")],
    app_id: Annotated[str, typer.Option("--app-id", help="应用的唯一标识，即 AppId")],
    cluster_name: Annotated[str, typer.Option("--cluster-name", help="集群名称")],
    namespace_name: Annotated[str, typer.Option("--namespace-name", help="Namespace 名称")] = "application",
):
    """获取指定 Namespace 的详细信息"""
    _get("/getNamespace", {"env": env, "appId": app_id, "clusterName": cluster_name, "namespaceName": namespace_name})


@app.command()
def get_namespace_lock(
    env: Annotated[str, typer.Option("--env", help="环境标识，如 DEV、FAT、UAT、PRO")],
    app_id: Annotated[str, typer.Option("--app-id", help="应用的唯一标识，即 AppId")],
    cluster_name: Annotated[str, typer.Option("--cluster-name", help="集群名称")],
    namespace_name: Annotated[str, typer.Option("--namespace-name", help="Namespace 名称")] = "application",
):
    """获取 Namespace 的锁定状态"""
    _get("/getNamespaceLock", {"env": env, "appId": app_id, "clusterName": cluster_name, "namespaceName": namespace_name})


@app.command()
def get_item(
    env: Annotated[str, typer.Option("--env", help="环境标识，如 DEV、FAT、UAT、PRO")],
    app_id: Annotated[str, typer.Option("--app-id", help="应用的唯一标识，即 AppId")],
    cluster_name: Annotated[str, typer.Option("--cluster-name", help="集群名称")],
    namespace_name: Annotated[str, typer.Option("--namespace-name", help="Namespace 名称")] = "application",
    key: Annotated[str, typer.Option("--key", help="配置项的 key")] = "content",
):
    """获取单个配置项的值"""
    _get("/getItem", {"env": env, "appId": app_id, "clusterName": cluster_name, "namespaceName": namespace_name, "key": key})


@app.command()
def get_items(
    env: Annotated[str, typer.Option("--env", help="环境标识，如 DEV、FAT、UAT、PRO")],
    app_id: Annotated[str, typer.Option("--app-id", help="应用的唯一标识，即 AppId")],
    cluster_name: Annotated[str, typer.Option("--cluster-name", help="集群名称")],
    namespace_name: Annotated[str, typer.Option("--namespace-name", help="Namespace 名称")] = "application",
    page: Annotated[int, typer.Option("--page", help="页码，从 0 开始")] = 0,
    size: Annotated[int, typer.Option("--size", help="每页大小")] = 50,
):
    """分页获取指定 Namespace 下的配置项列表"""
    _get("/getItems", {"env": env, "appId": app_id, "clusterName": cluster_name, "namespaceName": namespace_name, "page": page, "size": size})


@app.command()
def get_latest_release(
    env: Annotated[str, typer.Option("--env", help="环境标识，如 DEV、FAT、UAT、PRO")],
    app_id: Annotated[str, typer.Option("--app-id", help="应用的唯一标识，即 AppId")],
    cluster_name: Annotated[str, typer.Option("--cluster-name", help="集群名称")],
    namespace_name: Annotated[str, typer.Option("--namespace-name", help="Namespace 名称")] = "application",
):
    """获取 Namespace 最近一次已发布的配置内容"""
    _get("/getLatestRelease", {"env": env, "appId": app_id, "clusterName": cluster_name, "namespaceName": namespace_name})


@app.command()
def get_authorized_apps():
    """查看当前 Token 已被授权的 AppId 列表"""
    _get("/getAuthorizedApps")


@app.command()
def assign_app_role(
    app_id: Annotated[str, typer.Option("--app-id", help="需要授权的 AppId")],
):
    """为当前 Token 对应的第三方应用授权指定 AppId 的管理权限"""
    _post("/assignAppRole", {"appId": app_id})


@app.command()
def create_cluster(
    env: Annotated[str, typer.Option("--env", help="环境标识，如 DEV、FAT、UAT、PRO")],
    app_id: Annotated[str, typer.Option("--app-id", help="应用的唯一标识，即 AppId")],
    name: Annotated[str, typer.Option("--name", help="集群名称")],
    data_change_created_by: Annotated[str, typer.Option("--data-change-created-by", help="创建人，格式为域账号")],
):
    """在指定环境下为某个 App 创建集群"""
    _post("/createCluster", {"env": env, "appId": app_id, "name": name, "dataChangeCreatedBy": data_change_created_by})


@app.command()
def create_namespace(
    env: Annotated[str, typer.Option("--env", help="环境标识，如 DEV、FAT、UAT、PRO")],
    app_id: Annotated[str, typer.Option("--app-id", help="应用的唯一标识，即 AppId")],
    name: Annotated[str, typer.Option("--name", help="Namespace 名称")],
    format: Annotated[str, typer.Option("--format", help="Namespace 格式：properties/xml/json/yml/yaml")],
    is_public: Annotated[bool, typer.Option("--is-public", help="是否为公共 Namespace")],
    data_change_created_by: Annotated[str, typer.Option("--data-change-created-by", help="创建人，格式为域账号")],
    comment: Annotated[Optional[str], typer.Option("--comment", help="Namespace 说明")] = None,
):
    """为指定 App 创建 Namespace"""
    body: dict = {"env": env, "appId": app_id, "name": name, "format": format, "isPublic": is_public, "dataChangeCreatedBy": data_change_created_by}
    if comment is not None:
        body["comment"] = comment
    _post("/createNamespace", body)


@app.command()
def create_item(
    env: Annotated[str, typer.Option("--env", help="环境标识，如 DEV、FAT、UAT、PRO")],
    app_id: Annotated[str, typer.Option("--app-id", help="应用的唯一标识，即 AppId")],
    cluster_name: Annotated[str, typer.Option("--cluster-name", help="集群名称")],
    namespace_name: Annotated[str, typer.Option("--namespace-name", help="Namespace 名称")],
    key: Annotated[str, typer.Option("--key", help="配置项的 key")],
    value: Annotated[str, typer.Option("--value", help="配置项的 value")],
    data_change_created_by: Annotated[str, typer.Option("--data-change-created-by", help="创建人，格式为域账号")],
    comment: Annotated[Optional[str], typer.Option("--comment", help="配置项备注")] = None,
):
    """在指定 Namespace 下新增配置项"""
    body: dict = {"env": env, "appId": app_id, "clusterName": cluster_name, "namespaceName": namespace_name, "key": key, "value": value, "dataChangeCreatedBy": data_change_created_by}
    if comment is not None:
        body["comment"] = comment
    _post("/createItem", body)


@app.command()
def update_item(
    env: Annotated[str, typer.Option("--env", help="环境标识，如 DEV、FAT、UAT、PRO")],
    app_id: Annotated[str, typer.Option("--app-id", help="应用的唯一标识，即 AppId")],
    cluster_name: Annotated[str, typer.Option("--cluster-name", help="集群名称")],
    namespace_name: Annotated[str, typer.Option("--namespace-name", help="Namespace 名称")],
    key: Annotated[str, typer.Option("--key", help="配置项的 key")],
    value: Annotated[str, typer.Option("--value", help="配置项的新 value")],
    data_change_last_modified_by: Annotated[str, typer.Option("--data-change-last-modified-by", help="修改人，格式为域账号")],
    comment: Annotated[Optional[str], typer.Option("--comment", help="配置项备注")] = None,
    create_if_not_exists: Annotated[bool, typer.Option("--create-if-not-exists", help="当配置项不存在时是否自动创建")] = False,
    data_change_created_by: Annotated[Optional[str], typer.Option("--data-change-created-by", help="createIfNotExists 为 True 时必填，创建人域账号")] = None,
):
    """修改指定 Namespace 下的配置项"""
    body: dict = {"env": env, "appId": app_id, "clusterName": cluster_name, "namespaceName": namespace_name, "key": key, "value": value, "dataChangeLastModifiedBy": data_change_last_modified_by}
    if comment is not None:
        body["comment"] = comment
    body["createIfNotExists"] = create_if_not_exists
    if data_change_created_by is not None:
        body["dataChangeCreatedBy"] = data_change_created_by
    _post("/updateItem", body)


@app.command()
def delete_item(
    env: Annotated[str, typer.Option("--env", help="环境标识，如 DEV、FAT、UAT、PRO")],
    app_id: Annotated[str, typer.Option("--app-id", help="应用的唯一标识，即 AppId")],
    cluster_name: Annotated[str, typer.Option("--cluster-name", help="集群名称")],
    namespace_name: Annotated[str, typer.Option("--namespace-name", help="Namespace 名称")],
    key: Annotated[str, typer.Option("--key", help="配置项的 key")],
    operator: Annotated[str, typer.Option("--operator", help="删除操作人，格式为域账号")],
):
    """删除指定 Namespace 下的配置项"""
    _post("/deleteItem", {"env": env, "appId": app_id, "clusterName": cluster_name, "namespaceName": namespace_name, "key": key, "operator": operator})


@app.command()
def publish_namespace(
    env: Annotated[str, typer.Option("--env", help="环境标识，如 DEV、FAT、UAT、PRO")],
    app_id: Annotated[str, typer.Option("--app-id", help="应用的唯一标识，即 AppId")],
    cluster_name: Annotated[str, typer.Option("--cluster-name", help="集群名称")],
    namespace_name: Annotated[str, typer.Option("--namespace-name", help="Namespace 名称")],
    release_title: Annotated[str, typer.Option("--release-title", help="发布标题")],
    released_by: Annotated[str, typer.Option("--released-by", help="发布人，格式为域账号")],
    release_comment: Annotated[Optional[str], typer.Option("--release-comment", help="发布备注")] = None,
):
    """发布指定 Namespace 的配置"""
    body: dict = {"env": env, "appId": app_id, "clusterName": cluster_name, "namespaceName": namespace_name, "releaseTitle": release_title, "releasedBy": released_by}
    if release_comment is not None:
        body["releaseComment"] = release_comment
    _post("/publishNamespace", body)


@app.command()
def rollback_release(
    env: Annotated[str, typer.Option("--env", help="环境标识，如 DEV、FAT、UAT、PRO")],
    release_id: Annotated[str, typer.Option("--release-id", help="需要回滚的发布版本 ID")],
    operator: Annotated[str, typer.Option("--operator", help="回滚操作人，格式为域账号")],
):
    """回滚已发布的配置到上一个版本"""
    _post("/rollbackRelease", {"env": env, "releaseId": release_id, "operator": operator})


@app.command()
def create_app(
    app_id: Annotated[str, typer.Option("--app-id", help="应用的唯一标识，即 AppId")],
    name: Annotated[str, typer.Option("--name", help="应用名称")],
    org_id: Annotated[str, typer.Option("--org-id", help="部门 ID")],
    org_name: Annotated[str, typer.Option("--org-name", help="部门名称")],
    owner_name: Annotated[str, typer.Option("--owner-name", help="应用负责人姓名")],
    owner_email: Annotated[str, typer.Option("--owner-email", help="应用负责人邮箱")],
    assign_app_role_to_self: Annotated[bool, typer.Option("--assign-app-role-to-self", help="是否授予自己该 App 的管理权限")] = True,
    admins: Annotated[Optional[str], typer.Option("--admins", help="授予管理权限的用户列表，逗号分隔")] = None,
):
    """创建 App 并获取管理员权限"""
    body: dict = {"appId": app_id, "name": name, "orgId": org_id, "orgName": org_name, "ownerName": owner_name, "ownerEmail": owner_email, "assignAppRoleToSelf": assign_app_role_to_self}
    if admins is not None:
        body["admins"] = [a.strip() for a in admins.split(",")]
    _post("/createApp", body)
