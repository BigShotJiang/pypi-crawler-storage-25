from apolloconfigctl.main import app

__all__ = ["app"]
