# apolloconfigctl

ApolloConfig Gateway CLI 客户端，通过 HTTP 连接 ApolloConfig Gateway 的 `/api` 接口。

## 安装

```bash
pip install apolloconfigctl
```

## 使用

```bash
# 通过 --api-url 指定
apolloconfigctl --api-url http://localhost:8000/api get-apps

# 或通过环境变量
export APOLLO_API_URL=http://localhost:8000/api
apolloconfigctl get-apps
```

## 发布到 PyPI

### 前置条件

1. 注册 [PyPI](https://pypi.org/) 账号
2. 配置 API Token：PyPI 账号设置 → API tokens → 创建 token

### 发布步骤

```bash
# 构建
uv build

# 发布（首次会提示输入 PyPI token）
uv publish
```

`uv publish` 首次使用时需提供凭证，可通过以下方式之一：

- **环境变量**：`UV_PUBLISH_TOKEN` 或 `TWINE_PASSWORD`
- **交互式输入**：运行时提示输入 username/password

### 版本更新流程

1. 修改 `pyproject.toml` 中的 `version`
2. 删除旧的 `dist/` 目录：`rm -rf dist/`
3. 构建并发布

### CI/CD 自动发布

可在 GitHub Actions 中配置 Trusted Publisher（OIDC），无需手动管理 token：

```yaml
- name: Publish to PyPI
  uses: pypa/gh-action-pypi-publish@release/v1
```

需在 PyPI 项目设置中配置 GitHub 为 Trusted Publisher。
