"""Access to bundled skill, agent, and plugin assets."""

from __future__ import annotations

import json
import shutil
import stat
import tomllib
from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from typing import Any, cast

from translation_orchestrator import __version__

PACKAGE_ROOT = "translation_orchestrator.plugin_data"
SKILL_NAME = "translation-orchestrator"
PLUGIN_NAME = "translation-orchestrator"


@dataclass(frozen=True)
class ValidationResult:
    """Result of validating bundled package assets."""

    checked_files: tuple[str, ...]


def _resource_root() -> resources.abc.Traversable:
    return resources.files(PACKAGE_ROOT)


def skill_resource() -> resources.abc.Traversable:
    """Return the bundled skill directory resource."""

    return _resource_root() / "skills" / SKILL_NAME


def agents_resource() -> resources.abc.Traversable:
    """Return the bundled translation agents directory resource."""

    return _resource_root() / "agents"


def copy_resource_tree(resource: resources.abc.Traversable, destination: Path) -> None:
    """Copy an importlib resource tree to a filesystem destination."""

    if destination.exists():
        shutil.rmtree(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with resources.as_file(resource) as src:
        shutil.copytree(src, destination)


def install_to_project(project_root: Path) -> tuple[Path, Path]:
    """Install the bundled skill and agents into a repository's .github tree."""

    github_dir = project_root / ".github"
    skill_dir = github_dir / "skills" / SKILL_NAME
    agents_dir = github_dir / "agents"
    copy_resource_tree(skill_resource(), skill_dir)
    agents_dir.mkdir(parents=True, exist_ok=True)
    with resources.as_file(agents_resource()) as src_agents:
        for source in sorted(src_agents.glob("translation-*.agent.md")):
            shutil.copy2(source, agents_dir / source.name)
    return skill_dir, agents_dir


def install_to_directories(skill_dir: Path, agents_dir: Path) -> tuple[Path, Path]:
    """Install the bundled skill and agents into explicit directories."""

    target_skill = skill_dir / SKILL_NAME
    copy_resource_tree(skill_resource(), target_skill)
    agents_dir.mkdir(parents=True, exist_ok=True)
    with resources.as_file(agents_resource()) as src_agents:
        for source in sorted(src_agents.glob("translation-*.agent.md")):
            shutil.copy2(source, agents_dir / source.name)
    return target_skill, agents_dir


def _load_registry() -> dict[str, Any]:
    with resources.as_file(
        skill_resource() / "references" / "domain-plugin-registry.json"
    ) as registry:
        data = json.loads(registry.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("domain-plugin-registry.json must contain an object")
    return cast(dict[str, Any], data)


def list_domains() -> list[str]:
    """List bundled domain plugin names."""

    registry = _load_registry()
    domains = registry.get("domains", {})
    if not isinstance(domains, dict):
        raise ValueError("domain-plugin-registry.json has no object 'domains'")
    return sorted(domains)


def validate_assets() -> ValidationResult:
    """Validate bundled JSON and TOML assets."""

    checked: list[str] = []
    with resources.as_file(skill_resource()) as skill_dir:
        json_paths = [
            *sorted((skill_dir / "schemas").glob("*.json")),
            skill_dir / "references" / "domain-plugin-registry.json",
        ]
        for path in json_paths:
            json.loads(path.read_text(encoding="utf-8"))
            checked.append(str(path.relative_to(skill_dir)))

        toml_paths = [skill_dir / "config.toml"]
        for path in toml_paths:
            tomllib.loads(path.read_text(encoding="utf-8"))
            checked.append(str(path.relative_to(skill_dir)))

        skill_md = skill_dir / "SKILL.md"
        text = skill_md.read_text(encoding="utf-8")
        if not text.startswith("---\n"):
            raise ValueError("SKILL.md must start with YAML frontmatter")
        frontmatter = text.split("---", 2)[1]
        description = ""
        for line in frontmatter.splitlines():
            if line.startswith("description:"):
                description = line.split(":", 1)[1].strip()
                break
        if not description:
            raise ValueError("SKILL.md frontmatter must include description")
        if len(description) > 1024:
            raise ValueError("SKILL.md description exceeds 1024 characters")
        if "<" in frontmatter or ">" in frontmatter:
            raise ValueError("SKILL.md frontmatter must not contain angle brackets")
        checked.append("SKILL.md")

    return ValidationResult(checked_files=tuple(checked))


def render_plugin_json() -> str:
    """Render Copilot-style plugin metadata."""

    payload = {
        "name": PLUGIN_NAME,
        "description": (
            "Copilot CLI plugin for translation-orchestrator "
            "(domain-plugin translation skill + subagents)"
        ),
        "version": __version__,
        "author": {"name": "Grammy Jiang", "email": "grammy.jiang@gmail.com"},
        "skills": "skills/",
        "mcpServers": ".mcp.json",
    }
    return json.dumps(payload, indent=2, ensure_ascii=False) + "\n"


def render_mcp_json() -> str:
    """Render MCP client metadata for the package."""

    payload = {
        "mcpServers": {
            "translation-orchestrator": {
                "command": "./start-mcp.sh",
                "args": [],
                "cwd": ".",
                "description": "Start the translation-orchestrator MCP server.",
            }
        }
    }
    return json.dumps(payload, indent=2, ensure_ascii=False) + "\n"


def render_start_mcp() -> str:
    """Render the plugin start script."""

    return """#!/usr/bin/env bash
set -euo pipefail

if command -v translation-orchestrator >/dev/null 2>&1; then
  exec translation-orchestrator mcp serve "$@"
fi

exec python3 -m translation_orchestrator mcp serve "$@"
"""


def build_plugin_bundle(output: Path) -> Path:
    """Build a Copilot-style direct plugin bundle."""

    if output.exists():
        shutil.rmtree(output)
    output.mkdir(parents=True)

    (output / "plugin.json").write_text(render_plugin_json(), encoding="utf-8")
    (output / ".mcp.json").write_text(render_mcp_json(), encoding="utf-8")
    start_mcp = output / "start-mcp.sh"
    start_mcp.write_text(render_start_mcp(), encoding="utf-8")
    start_mcp.chmod(start_mcp.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    copy_resource_tree(skill_resource(), output / "skills" / SKILL_NAME)
    copy_resource_tree(agents_resource(), output / "agents")
    return output
