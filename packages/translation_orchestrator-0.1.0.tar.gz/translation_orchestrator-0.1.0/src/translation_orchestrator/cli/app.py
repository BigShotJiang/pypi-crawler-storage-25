"""Typer entry point for translation-orchestrator package tooling."""

from __future__ import annotations

import json
from pathlib import Path

import typer

from translation_orchestrator import __version__
from translation_orchestrator.core.assets import (
    build_plugin_bundle,
    install_to_directories,
    install_to_project,
    list_domains,
    render_mcp_json,
    validate_assets,
)
from translation_orchestrator.mcp_server import run_mcp_server

app = typer.Typer(
    add_completion=False,
    no_args_is_help=True,
    help="Package tools for the translation-orchestrator skill and subagents.",
)

mcp_app = typer.Typer(
    add_completion=False,
    no_args_is_help=True,
    help="Run or configure the translation-orchestrator MCP server.",
)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"translation-orchestrator {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False,
        "--version",
        "-V",
        help="Show version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    """Package tools for the translation-orchestrator skill and subagents."""


@app.command()
def domains(json_output: bool = typer.Option(False, "--json", help="Emit JSON.")) -> None:
    """List bundled domain plugins."""

    domains_list = list_domains()
    if json_output:
        typer.echo(json.dumps({"domains": domains_list}, indent=2))
        return
    for domain in domains_list:
        typer.echo(domain)


@app.command()
def validate(json_output: bool = typer.Option(False, "--json", help="Emit JSON.")) -> None:
    """Validate bundled skill, schema, registry, and config assets."""

    result = validate_assets()
    payload = {"ok": True, "checked_files": list(result.checked_files)}
    if json_output:
        typer.echo(json.dumps(payload, indent=2))
        return
    typer.echo(f"Validated {len(result.checked_files)} bundled files.")


@app.command()
def setup(
    project_root: Path | None = typer.Option(
        None,
        "--project-root",
        "-p",
        help="Install into PROJECT_ROOT/.github/skills and PROJECT_ROOT/.github/agents.",
    ),
    skill_dir: Path | None = typer.Option(
        None,
        "--skill-dir",
        help="Explicit parent directory for installing the skill folder.",
    ),
    agents_dir: Path | None = typer.Option(
        None,
        "--agents-dir",
        help="Explicit directory for installing translation-*.agent.md files.",
    ),
) -> None:
    """Install the bundled skill and subagents."""

    if project_root is not None and (skill_dir is not None or agents_dir is not None):
        raise typer.BadParameter("Use either --project-root or --skill-dir/--agents-dir.")
    if project_root is not None:
        installed_skill, installed_agents = install_to_project(project_root)
    else:
        if skill_dir is None or agents_dir is None:
            raise typer.BadParameter(
                "Provide --project-root or both --skill-dir and --agents-dir."
            )
        installed_skill, installed_agents = install_to_directories(skill_dir, agents_dir)
    typer.echo(f"Installed skill: {installed_skill}")
    typer.echo(f"Installed agents: {installed_agents}")


@app.command("build-plugin")
def build_plugin(
    output: Path = typer.Option(
        Path("dist/copilot-plugin-translation-orchestrator"),
        "--output",
        "-o",
        help="Output directory for the Copilot-style plugin bundle.",
    ),
) -> None:
    """Build a Copilot-style direct plugin bundle."""

    bundle = build_plugin_bundle(output)
    typer.echo(f"Built plugin bundle: {bundle}")


@mcp_app.command("config")
def mcp_config() -> None:
    """Print an MCP client configuration snippet."""

    typer.echo(render_mcp_json())


@mcp_app.command("serve")
def mcp_serve() -> None:
    """Run the lightweight MCP server over stdio."""

    run_mcp_server()


app.add_typer(mcp_app, name="mcp")

if __name__ == "__main__":
    app()
