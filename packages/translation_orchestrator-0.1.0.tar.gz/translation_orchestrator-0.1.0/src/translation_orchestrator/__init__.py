"""Package tools for installing and validating the translation-orchestrator skill."""

from __future__ import annotations

__version__ = "0.1.0"
