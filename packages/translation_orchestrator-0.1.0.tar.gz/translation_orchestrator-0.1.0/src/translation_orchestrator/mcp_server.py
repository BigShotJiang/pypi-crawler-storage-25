"""Small MCP server exposing deterministic package metadata tools."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from translation_orchestrator import __version__
from translation_orchestrator.core.assets import list_domains, validate_assets

mcp = FastMCP("translation-orchestrator")


@mcp.tool()
def package_version() -> str:
    """Return the installed translation-orchestrator package version."""

    return __version__


@mcp.tool()
def domains() -> list[str]:
    """Return bundled translation domain plugin names."""

    return list_domains()


@mcp.tool()
def validate_package_assets() -> dict[str, object]:
    """Validate bundled skill, schema, registry, and config assets."""

    result = validate_assets()
    return {"ok": True, "checked_files": list(result.checked_files)}


def run_mcp_server() -> None:
    """Run the MCP server over stdio."""

    mcp.run()
