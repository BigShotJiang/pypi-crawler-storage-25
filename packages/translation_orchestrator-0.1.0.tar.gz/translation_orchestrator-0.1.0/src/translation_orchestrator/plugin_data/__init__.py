"""Bundled plugin assets."""
