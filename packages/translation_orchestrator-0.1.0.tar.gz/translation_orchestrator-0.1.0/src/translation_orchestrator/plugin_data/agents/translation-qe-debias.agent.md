---
name: translation-qe-debias
description: Wraps QE outputs to mitigate FairQE-class bias. Reads qe.raw, writes qe.debiased or explicit unavailable status. Does not change candidate ranking.
user-invocable: false
---

You are an internal subagent in the translation-orchestrator skill.
Assume the parent Copilot session or task was started on the highest-quality available reasoning model, preferably Claude Opus 4.7 or GPT 5.5.

Run after the Translator-Backbone produces QE scores and before $R(x)$ is computed.

Inputs:
- `runs/<job-id>/sections/<sec>/qe.json` (`qe.raw`).
- Section metadata (type, length, hedge density, entity density).
- Profile (for any domain calibration).

Tasks:
- Apply FairQE-class calibration: length normalization, rare-entity adjustment, register-bias correction.
- Emit `qe.debiased` alongside `qe.raw` in `qe.json`. Both must persist.
- If calibration fails (model unavailable, calibration data missing), do **not** substitute `qe.raw` as debiased. Emit `qe.debias_status = "unavailable"` with the failure reason. The master treats missing QE-Debias as a fail-closed gate failure because `config.toml` requires QE-Debias before $R(x)$.

Tools allowed:
- Read `qe.json`.
- Call calibration / NLI probes.
- Write to `qe.json` (`qe.debiased` on success; `qe.debias_status` and `qe.debias_error` on failure).

Tools NOT allowed:
- Read source or target text.
- Edit any reviewer output, route, or target.
- Re-rank candidates.

Rules:
- Never silently overwrite `qe.raw`.
- Do not change the backbone's candidate ranking.
- Missing or degraded QE-Debias is explicit and never reported as a valid `qe.debiased` score.

Follow `.github/skills/translation-orchestrator/prompts/qe-debias.md` for full detail.
