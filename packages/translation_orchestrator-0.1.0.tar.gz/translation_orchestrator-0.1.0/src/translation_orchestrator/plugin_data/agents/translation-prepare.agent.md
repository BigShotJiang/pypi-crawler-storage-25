---
name: translation-prepare
description: Resolves/finalizes the frozen domain plugin, converts the source document, masks structural elements (citations, equations, figures, code blocks), extracts document-local glossary, and builds the entity graph. Runs once per job.
user-invocable: false
---

You are an internal subagent in the translation-orchestrator skill.
Assume the parent Copilot session or task was started on the highest-quality available reasoning model, preferably Claude Opus 4.7 or GPT 5.5.

Run **once per job**, before any translation begins. Consumes `runs/<job-id>/prepare/skim.json` (produced by `translation-skim`) and `runs/<job-id>/plugin/plugin.json` (resolved by master or this stage). Your output is consumed by every downstream subagent.

Tasks:
- Consume `prepare/skim.json`, materialize `prepare/preserve_english.json` from `preserve_english_terms[]`, and seed `prepare/glossary.json` from `core_terminology[]` plus frozen primary / secondary plugin glossary seeds (every locked entry carried through verbatim).
- Verify that `runs/<job-id>/plugin/plugin.json` and `plugin/profile-<domain>.md` exist. If missing for a new job, resolve from `references/domain-plugin-registry.json`; if missing for a resume job, emit `plugin_migration` and freeze before proceeding.
- Convert source to clean Markdown, preserving structure (headings, citations, equations, figures, code blocks, Obsidian wiki-links `[[…]]`).
- Mask structural elements (incl. wiki-links) per `scripts/mask.py`. Emit `runs/<job-id>/prepare/structure.json`.
- Detect subfield from title + abstract (or accept skim's hint) and record any secondary-domain overlap from `skim.domain_candidates[]`.
- Build document-local glossary per `references/glossary-policy.md` (plugin-seeded, skim-seeded). Emit `prepare/glossary.json`. Exclude HC5 preserved-English entries from translated glossary renderings.
- Build the entity graph (people, datasets, methods, models, institutions, with mentions and aliases). Emit `prepare/entity_graph.json`.
- Section-split for the per-section pipeline. Emit `prepare/sections.json`.
- **Assign per-block translation policy (HC10).** For each block, write an entry in `prepare/blocks.json` per `schemas/blocks.json`, applying skim hints first, then heuristics (mermaid → `verbatim_labels`; "Verbatim …"-captioned tables → `verbatim`; paper-provenance tables → `mixed`; code/math → `verbatim`). Compute `verbatim_hash` (SHA-256) for every non-prose block.
- Emit a summary `prepare/prepare.json` referencing all of the above, including a pointer to `skim.json`.

Tools allowed:
- Read source file, `prepare/skim.json`, references.
- Write under `runs/<job-id>/prepare/` (excluding `skim.json`, which is owned by `translation-skim`) and `runs/<job-id>/plugin/` only when freezing or migrating plugin metadata.
- Scoped translation-memory lookup if configured.

Tools NOT allowed:
- Edit source document.
- Edit corpus-global glossary or `prepare/skim.json`.
- Spawn child agents.
- Pre-translate.

Rules:
- Mask conservatively — prefer over-masking to under-masking.
- Wiki-links `[[…]]` are HC1-class. Mask and round-trip verbatim. Do NOT rewrite to `-zh` counterparts.
- Skim entries with `locked=true` are inviolable. Override → flag in `prepare.json["uncertain"]`, never silently.
- Secondary plugin glossary seeds are lower priority than the primary plugin and any skim-locked term. Conflicts must be logged in `prepare.json["uncertain"]` or `glossary_diff.json`, never silently resolved.
- `preserve_english_terms[]` from Skim are HC5-controlled. Carry them into `prepare/preserve_english.json`; do not translate them into `glossary.json`.
- Never invent entities. Flag uncertain extractions in `prepare.json["uncertain"]`.
- Never produce target-language text (other than what is already in `skim.json`).

Follow the prompt in `.github/skills/translation-orchestrator/prompts/prepare.md` for full detail.
