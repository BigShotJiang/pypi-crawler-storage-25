"""structure_check.py — deterministic HC enforcement for the verify-before-accept gate.

Stub / specification. Runs:
- HC1 citation round-trip (citation keys, author-year tokens)
- HC1 wiki-link round-trip: every `[[doc-name]]` (and `[[doc#anchor]]`,
  `[[doc|alias]]`) in source appears byte-identical in target. Translator must
  NOT rewrite to `-zh` counterpart or to a Markdown link.
- HC2 equation / figure / table ref round-trip
- HC5 controlled-non-translation lint, including preserved-English vocabulary
  (no controlled item or preserve-English term translated)
- HC6 polarity lint (negation count parity, contrastive-marker preservation)
- HC10 verbatim-block round-trip: for every block in
  `runs/<job-id>/prepare/blocks.json` with policy in {"verbatim",
  "verbatim_labels", "mixed"}, verify per-policy invariants:
    * `verbatim`: SHA-256(target span) == SHA-256(source span) (byte-identical).
    * `verbatim_labels`: every Mermaid node id and node label preserved
      byte-identical; only edge text / free-form annotations may differ.
    * `mixed`: header rows may differ (translatable); data cells must be
      byte-identical to source data cells (used for paper-provenance tables).
- Numeral integrity (Arabic numerals byte-identical inside masked spans)
- Mask leakage check (no {{MASK_*}} placeholders in unmasked target)

Fail-closed: any check that cannot run because its input is missing returns
status="missing" which the master treats as a reject (HC violation), not a pass.

Run twice in the Finalize stage: once before `scripts/lint_markdown.sh`, once
after. If any pass-state regresses to fail/missing post-lint, master MUST
revert the lint diff (lint may not introduce drift).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

CheckStatus = Literal["pass", "fail", "missing"]


@dataclass
class StructureCheckResult:
    hc1_citation: CheckStatus
    hc1_wikilink: CheckStatus
    hc2_equation_figure: CheckStatus
    hc5_controlled: CheckStatus
    hc6_polarity: CheckStatus
    hc10_verbatim_block: CheckStatus
    numeral_integrity: CheckStatus
    mask_leakage: CheckStatus
    findings: list[dict] = field(default_factory=list)   # span-level failure details


def structure_check(
    source_md: str,
    target_md_unmasked: str,
    structure_map: dict,
    controlled_non_translation: list[str],
    blocks: list[dict] | None = None,  # parsed prepare/blocks.json
) -> StructureCheckResult:
    """Run all deterministic HC checks. Returns per-check status + findings.

    `blocks` carries the policy map (schemas/blocks.json). Each entry with
    policy != "prose" is verified per HC10 rules above. If `blocks` is None
    or any verbatim entry is missing its `verbatim_hash`, hc10_verbatim_block
    is reported as "missing" (fail-closed).
    """
    raise NotImplementedError("Bind to host parser at install time.")


def hc_violations(result: StructureCheckResult) -> list[str]:
    """Convenience: list HC ids that failed (or were missing)."""
    out: list[str] = []
    if result.hc1_citation != "pass": out.append("HC1")
    if result.hc1_wikilink != "pass": out.append("HC1-wikilink")
    if result.hc2_equation_figure != "pass": out.append("HC2")
    if result.hc5_controlled != "pass": out.append("HC5")
    if result.hc6_polarity != "pass": out.append("HC6")
    if result.hc10_verbatim_block != "pass": out.append("HC10")
    if result.numeral_integrity != "pass": out.append("HC2-numeric")
    if result.mask_leakage != "pass": out.append("MASK-LEAK")
    return out
