---
name: profile-news
when_to_use: news articles · analysis pieces · interviews · wire reports · explainers
inputs: [source_file, target_language, source_outlet, publication_time]
outputs: [target_document, audit.md, glossary_diff.json, news_style_notes.md]
hc_set: GROUNDING.md
cp_overrides:
  register: news-zh
  hedge_preservation: strict
  voice: neutral_journalistic
  numerals: arabic
reviewer_set:
  - faithfulness
  - terminology
  - style
  - coherence
  - citation-structure
verify_before_accept:
  - back_translation
  - hedge_aware_nli
  - structure_round_trip
  - glossary_lint
  - qe_debias_R
  - hc_invariant
iteration_cap: 3
N_candidates: 4
N_agents: 5
topology: moderately_sparse
tau_R: 0.28
C_min: 0.70
human_review_sections: [headline, lede, correction_notice]
---

# Profile: News

Profile for journalism, wire copy, explainers, and interview-style articles. News translation is governed by factuality, source attribution, timestamp / numeral integrity, and neutral Chinese journalistic register.

## Reviewer weights

| Reviewer | Weight | Persona |
|---|---:|---|
| faithfulness | 0.40 | troublemaker |
| terminology | 0.15 | peacemaker |
| style | 0.20 | troublemaker |
| coherence | 0.15 | peacemaker |
| citation-structure | 0.10 | strict (HC veto) |

## CP specializations

- Register: concise news Chinese; avoid academic nominalization unless the article itself is scholarly.
- Attribution: preserve "said / claimed / according to" boundaries. Do not turn allegations into facts.
- Time and place: preserve dates, time zones, datelines, monetary amounts, percentages, and named sources exactly unless localization is explicitly requested.
- Headlines and ledes require extra faithfulness review because compression invites overclaim.

## Section-type routing hints

| Section type | Notes |
|---|---|
| headline | Mandatory human review when publication-facing. Tighten $\tau_R = 0.20$. |
| lede | Full review; highest risk of claim compression. |
| quote | Preserve speaker attribution and quotation boundaries. |
| correction_notice | Mandatory human review. |

## Anchors

- [[llm-agent-translation-system-research-report#Theme-9-Domains-are-runtime-plugins-not-hard-coded-forks]]
