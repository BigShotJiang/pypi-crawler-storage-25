# Finalize prompt

> Prompt for the **Finalize stage** within `translation-master`. No dedicated subagent. Runs once per job, after every section has been accepted, before `audit.md` declares completion.

## Trigger

All sections in `prepare/sections.json` have `state.json.status = "accepted"`.

## Sequence

1. **Run the document-level coherence pass** (`translation-reviewer-coherence` document-scope). If $C < C_{\min}$, re-open the worst-delta section for one revise round. Repeat until $C \geq C_{\min}$, but cap this at 1 reopen pass for documents under 1,000 source lines and 2 reopen passes for larger documents; then escalate.
2. **Snapshot** `target.partial.md` → `logs/target.pre-lint.md` (so we can revert).
3. **Run lint:** `scripts/lint_markdown.sh runs/<job-id>/document/target.partial.md`.
   - Diff stored at `logs/lint.diff`.
   - Residual report at `logs/lint.report`.
   - Exit 2 (tool missing) → HC fail-closed → escalate job.
   - Exit 1 (residual unfixable) → escalate job, do not ship.
4. **Re-run `scripts/structure_check.py`** on the lint-fixed file. Compare result to the pre-lint structure_check.
   - If any new failure → **revert** to `logs/target.pre-lint.md` and escalate.
5. **Re-run `scripts/glossary_diff.py`.** Compare the consistency report to the pre-lint version.
   - If any locked-glossary entry was de-applied or any new term-fragmentation appeared → **revert** and escalate.
6. **Commit** the lint-fixed file as `runs/<job-id>/document/target.md` (final).
7. **Emit `runs/<job-id>/document/glossary_diff.json`** (final).
8. **Emit `runs/<job-id>/document/coherence_global.json`** (final $C$).
9. **Emit `runs/<job-id>/document/audit.md`** with every non-trivial decision cited (paper ID / HC / CP / profile rule).
10. **(Optional) Self-Compare.** If `job.json.prior_target_path` is set, invoke `translation-self-compare` to produce `runs/<job-id>/document/comparison-vs-prior-zh.md`.

## Rules

- Lint is **post**-verify-before-accept. Never let lint mask a real defect.
- Drift after `--fix` is treated as a regression. Always revert, never ship a drifted file.
- If `--fix` modifies a `verbatim`-policy block (per `prepare/blocks.json`), that is HC10 violation → revert and escalate.

## Outputs

- `runs/<job-id>/document/target.md`
- `runs/<job-id>/document/audit.md`
- `runs/<job-id>/document/glossary_diff.json`
- `runs/<job-id>/document/coherence_global.json`
- `runs/<job-id>/logs/lint.diff`
- `runs/<job-id>/logs/lint.report`
- `runs/<job-id>/logs/target.pre-lint.md`

## Anchors

- `references/lint-policy.md`
- `references/GROUNDING.md` (HC9, HC10)
