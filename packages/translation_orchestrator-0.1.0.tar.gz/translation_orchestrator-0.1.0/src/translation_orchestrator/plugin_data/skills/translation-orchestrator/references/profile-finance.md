---
name: profile-finance
when_to_use: annual reports · earnings releases · analyst notes · financial news · market commentary
inputs: [source_file, target_language, reporting_period, currency_context]
outputs: [target_document, audit.md, glossary_diff.json, finance_number_check.json]
hc_set: GROUNDING.md
cp_overrides:
  register: finance-zh
  hedge_preservation: strict
  voice: formal_business
  numerals: arabic
reviewer_set:
  - faithfulness
  - terminology
  - style
  - coherence
  - citation-structure
verify_before_accept:
  - back_translation
  - hedge_aware_nli
  - structure_round_trip
  - glossary_lint
  - qe_debias_R
  - hc_invariant
  - numeral_currency_check
iteration_cap: 3
N_candidates: 4
N_agents: 5
topology: moderately_sparse
tau_R: 0.22
C_min: 0.72
human_review_sections: [executive_summary, risk_factors, outlook, financial_tables]
---

# Profile: Finance

Profile for financial reports, analyst commentary, market updates, and earnings materials. Finance translation is high-stakes: numeral, currency, polarity, and hedge drift are blockers.

## Reviewer weights

| Reviewer | Weight | Persona |
|---|---:|---|
| faithfulness | 0.40 | troublemaker |
| terminology | 0.25 | strict |
| style | 0.10 | peacemaker |
| coherence | 0.10 | peacemaker |
| citation-structure | 0.15 | strict (HC veto on tables / numerals) |

## Domain-specific HCs

- Monetary amounts, percentages, units, date ranges, and table cells round-trip exactly unless a user-approved localization rule is present.
- Risk, uncertainty, and forward-looking statement hedges are HC3-critical.
- Do not infer financial performance from partial data. Preserve source polarity and comparison direction.

## CP specializations

- Register: formal financial Chinese; prefer standard terms such as 收入, 净利润, 毛利率, 指引, 同比, 环比 where applicable.
- English tickers, product names, company legal names, and benchmark identifiers remain English if present in `prepare/preserve_english.json`.
- Keep source units and currency symbols visible; do not silently convert currencies.

## Section-type routing hints

| Section type | Notes |
|---|---|
| executive_summary | Full review and tight $\tau_R = 0.20$. |
| financial_tables | Structural + numeral/currency check required; no table-cell paraphrase. |
| outlook | Hedge-aware NLI mandatory; forward-looking disclaimers preserved. |
| risk_factors | Mandatory human review for publication-facing outputs. |

## Anchors

- [[llm-agent-translation-system-research-report#Theme-9-Domains-are-runtime-plugins-not-hard-coded-forks]]
