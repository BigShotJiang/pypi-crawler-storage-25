# Skill Evaluation

Use this checklist after changing `translation-orchestrator` or any `translation-*` agent wrapper. It follows the Claude skill-building guide's trigger, functional, performance, progressive-disclosure, and upload-readiness categories.

## Skill-building guide checks

Before changing behavior, confirm the skill still satisfies the guide's baseline:

| Guide requirement | Translation-orchestrator rule |
|---|---|
| Problem-first use cases | New domain translation, resume run, prior-version comparison. |
| Frontmatter explains what + when | Description names full-document EN→ZH translation, supported domains, trigger phrases, and negative scope. |
| Progressive disclosure | `SKILL.md` stays compact; details live in `prompts/`, `references/`, `schemas/`, and `scripts/`. |
| Actionable instructions | Each phase names owner artifacts and fail-closed validation gates. |
| Error handling | Runtime recovery lives in `references/troubleshooting.md`; HC bypass is never a recovery. |
| Testing | Trigger, functional, regression, and performance checks below must pass before release. |

## Trigger tests

Should trigger:

- "Translate this paper to Chinese using the academic translation harness."
- "Translate this earnings report to Chinese using the finance profile."
- "Translate this engineering design doc with the translation harness."
- "Translate this news article to Chinese and preserve attribution."
- "Run the translation pipeline on `paper.md` and produce a Chinese version."
- "Resume the translation run in `translation/runs/example-job/`."
- "Translate this report again and compare against the prior Chinese version."
- "Process this `.tex` source through the English-to-Chinese translation workflow."

Should not trigger:

- "Translate this sentence into Chinese."
- "Proofread this Chinese paragraph."
- "OCR this scanned PDF."
- "Repair the layout of this PDF."
- "Summarize this paper in Chinese without translating it."
- "Find recent translation papers." (Use `research-pipeline` instead.)
- "Review this design document." (Use `design-doc-review` instead.)

## Functional checks

For a minimal fixture job, verify:

1. `translation-skim` runs before `translation-prepare` and emits `prepare/skim.json`.
2. `translation-skim` emits `domain_candidates[]` with provenance × topic × genre evidence.
3. `translation-master` / `translation-prepare` freezes the resolved plugin under `runs/<job-id>/plugin/`.
4. `translation-skim` proposes `preserve_english_terms[]` for common professional English terms with clear rationale.
5. `translation-prepare` consumes `skim.json`, emits `prepare/preserve_english.json`, masks wiki-links and structural spans, and emits `prepare/blocks.json`.
6. Router rejects any Red-classified route that names a cloud endpoint and never lets secondary plugins weaken the primary plugin.
7. Translator-Backbone preserves masked placeholders, preserved-English terms, locked terms, and plugin-specific interface / numeral / attribution constraints.
8. QE-Debias emits a real `qe.debiased` value or an explicit unavailable status that blocks acceptance.
9. Reviewers write only `review.json`; none edit target files.
10. `translation-master` writes `target.partial.md`, then Finalize snapshots and lint-checks before committing `target.md`.
11. Resume mode uses the frozen plugin copy, skips accepted sections, and never writes outside the selected run directory.

## Regression checks

- Frontmatter `description` includes both what the skill does and when to use it.
- Frontmatter `description` is under 1024 characters.
- Frontmatter contains no angle-bracket placeholders.
- `SKILL.md` entrypoint avoids angle-bracket placeholders for run paths; use `{job_id}` / `{section_id}` examples there.
- `SKILL.md` links to detailed references instead of duplicating long runbooks.
- `SKILL.md` stays comfortably under the guide's 5,000-word recommendation.
- Every referenced file in `SKILL.md` exists.
- The subagent roster in `SKILL.md` matches `.github/agents/translation-*.agent.md`.
- Any fail-closed rule in `SKILL.md`, prompts, agents, and `config.toml` is consistent.
- English-preservation behavior is consistent across Skim, Prepare, Translator-Backbone, Terminology Reviewer, schemas, and glossary policy.
- Domain-plugin behavior is consistent across `schemas/job.json`, `schemas/skim.json`, `references/domain-plugin-registry.json`, routing rules, storage layout, prompts, and agent wrappers.

## Performance / usability checks

Use these as rough guide-aligned targets, not hard product metrics:

| Check | Target |
|---|---|
| Trigger coverage | At least 9/10 obvious full-document translation prompts load the skill. |
| Over-trigger resistance | 0/10 single-sentence, OCR/layout, proofreading-only, or research-only prompts load the skill. |
| User prompting burden | A new job should need at most source path, target language, data classification, and optional domain override before execution. |
| Workflow consistency | Three repeated fixture runs produce the same required artifact tree and same owner boundaries. |
| Token discipline | Routine runs should load only the relevant prompt/reference files for the active phase. |

## Upload readiness

Before packaging this skill for Claude surfaces:

1. Confirm the folder name is `translation-orchestrator` and the entrypoint is exactly `SKILL.md`.
2. Confirm there is no `README.md` inside the skill folder; human documentation belongs outside the skill folder or under `references/`.
3. Run `pre-commit run --files` on all changed skill files.
4. Check frontmatter with a YAML parser if packaging outside this repo.
5. Zip or deploy the skill folder only; do not include `runs/` artifacts.
