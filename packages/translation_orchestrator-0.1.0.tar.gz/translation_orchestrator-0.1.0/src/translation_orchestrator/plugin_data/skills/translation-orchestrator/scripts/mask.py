"""mask.py — citation, equation, figure, code-block masking for the translation harness.

Stub / specification. Implementations bind to host tokenizers and citation parsers.

Used by: translation-prepare (mask) and the master agent / structure_check.py (unmask).

Contract:
- mask_document(src_md: str) -> tuple[str, dict]
    Returns (masked_md, mapping) where mapping is JSON-serializable and round-trips
    perfectly with unmask_document.
- unmask_document(target_md: str, mapping: dict) -> str
    Replaces placeholders with their original tokens, byte-identical.
- placeholders are of the form {{MASK_<KIND>_<id>}} and never overlap with valid
    Markdown / LaTeX / Chinese punctuation.

Hard rules (HC1, HC2):
- Citations: Pandoc-style @key, [Author, Year], [1], [1, 2], (Author, Year).
- Equations: $...$, $$...$$, \\(...\\), \\[...\\], \\begin{equation}...\\end{equation},
    \\begin{align}...\\end{align}, equation labels (\\label{eq:*}), \\eqref{*}, \\ref{*}.
- Figure / table refs: Fig. 1, Figure 1, 图 1, Table 2, 表 2 — only when they refer
    to a numbered structure in the source (cross-checked against entity graph).
- Code blocks: fenced ```lang ... ``` and inline `...`.

Mapping schema:
{
  "version": 1,
  "entries": [
    {"id": "c001", "kind": "citation", "placeholder": "{{MASK_CITE_c001}}",
     "original": "[Smith, 2020]", "src_offset": [120, 134]},
    ...
  ]
}
"""

from __future__ import annotations


def mask_document(src_md: str) -> tuple[str, dict]:
    """Mask structural elements in source markdown. Returns (masked_md, mapping)."""
    raise NotImplementedError("Bind to host parser at install time.")


def unmask_document(target_md: str, mapping: dict) -> str:
    """Restore placeholders in target. Must be byte-identical for HC1/HC2 entries."""
    raise NotImplementedError("Bind to host parser at install time.")


def verify_mapping_round_trip(src_md: str) -> bool:
    """Sanity check used in tests: mask then unmask returns the original document."""
    masked, mapping = mask_document(src_md)
    return unmask_document(masked, mapping) == src_md
