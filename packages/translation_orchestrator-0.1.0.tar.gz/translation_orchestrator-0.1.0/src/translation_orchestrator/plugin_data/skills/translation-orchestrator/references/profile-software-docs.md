---
name: profile-software-docs
when_to_use: API references · tutorials · README files · developer docs
inputs: [source_file, target_language, code_block_policy]
outputs: [target_document, audit.md, glossary_diff.json, code_block_manifest.json]
hc_set: GROUNDING.md
cp_overrides:
  register: tech-doc-zh
  hedge_preservation: strict
  voice: instructional
  numerals: arabic
reviewer_set:
  - faithfulness
  - terminology
  - style
  - coherence
  - citation-structure
verify_before_accept:
  - back_translation
  - structure_round_trip
  - code_block_round_trip
  - glossary_lint
  - qe_debias_R
  - hc_invariant
iteration_cap: 3
N_candidates: 4
N_agents: 5
topology: moderately_sparse
tau_R: 0.30
C_min: 0.65
human_review_sections: [getting_started, api_reference]
---

# Profile: Software Docs

Profile for developer-facing technical documentation.

## Domain-specific HCs (lifted + extended)

- **Code blocks are inviolable.** Fenced code blocks (```), inline code (`...`), and file-path-like tokens round-trip byte-identical. Treated under HC1 / HC2 (the citation-structure reviewer enforces).
- **API names, command names, flag names, environment variables, framework names, package names, protocol names** — never translated. Add to the project's controlled-non-translation list or job-level `prepare/preserve_english.json`.

## Reviewer weights

| Reviewer | Weight | Persona |
|---|---:|---|
| faithfulness | 0.30 | troublemaker |
| terminology | 0.25 | strict |
| style | 0.20 | troublemaker (instructional clarity) |
| coherence | 0.10 | peacemaker |
| citation-structure | 0.15 | strict (HC veto on code blocks) |

## CP specializations

- Imperative voice OK in instructional sections (e.g., "运行以下命令"); not academic-impersonal.
- Inline code uses half-width punctuation and ASCII; surrounding prose uses full-width.

## Anchors

- [[academic-paper-translation-guide#Citation Handling]] (extended to code blocks)
