# AGENTS.md (translation)

> Project-scoped, persistent. 5-principle completeness audit for the translation skill. Score each principle 0–5; jobs are gated at GCS ≥ 4.0.
>
> Anchor: [[ai-agent-translation-system-plan#Tier 2 — `AGENTS.md` for translation]] and the original [coding-agent 5-principle framework](harness-engineering-for-local-coding-agents-engineering-guide.md#43-agentsmd--the-5-principle-completeness-framework).

## 1. Success definition

A translation job is successful when **all** of the following hold:

- All Hard Constraints in `GROUNDING.md` pass for every section.
- Verify-before-accept is clean for every section that lands in `document/target.md`.
- Document-level coherence $C \geq C_{\min}$ from `config.toml` (default 0.70).
- `glossary_diff.json` shows no unjustified diffs (every diff has either an evidence pointer or a profile-level CP override).
- `runs/<job-id>/plugin/` contains the frozen primary domain plugin and any secondary glossary metadata used for the job.
- The PR / handoff description references `runs/<job-id>/job.json` and a non-empty `audit.md`.

A job that ships without `audit.md` or with an unfinished verify-before-accept gate is **not** successful, regardless of human readability of the output.

## 2. Assessment rubric

The rubric is the union of:

- Hedge-aware NLI (HC3, HC4).
- FaithLens score on accepted sections.
- OVERMISS rate on accepted sections.
- DCoEM 4-manner $C$ at the document level.
- `glossary_diff` lint.
- ATSR (Agent Translation Survival Rate) post-human-review (production signal).

Reviewer weights are loaded from the frozen primary plugin at `runs/<job-id>/plugin/profile-<domain>.md`. One human reviewer is mandatory for the configured `human_review_sections` of the primary plugin before publication.

## 3. Scope boundary

The skill writes **only** under `runs/<job-id>/`. It must never:

- Edit the source paper (the original PDF or markdown).
- Edit the global glossary store (only emit `glossary_diff.json` proposals).
- Write into another job's `runs/<other-job-id>/` directory.
- Modify `references/` or `prompts/` at runtime.
- Re-resolve a live domain profile over an in-progress job unless explicitly performing a logged plugin migration.

The Translator-Backbone may only edit its own draft under `runs/<job-id>/sections/<sec>/candidates/`. Reviewers cannot edit anything; they emit `review.json` only.

## 4. Data classification

Per `GROUNDING.md` Data Classification table:

- **Red** routes are local-only. Cloud fallback is denied at the router. The verify-before-accept gate must run with local models when classification is Red — if a local back-translator is not available, the job is rejected at startup.
- **Amber** routes use the approved-endpoint allowlist in `config.toml` (`router.amber_endpoint_allowlist`).
- **Green** routes are unrestricted modulo cost/latency budgets.

Misclassification is treated as a security incident; runbook R4 applies.

## 5. Quality gate

- Verify-before-accept must pass — fail-closed on missing signals.
- Reviewer chain must converge within the iteration cap (default 3 rounds); non-convergence escalates to the human queue.
- `audit.md` must cite paper IDs (or HC / CP / plugin profile IDs) for every non-trivial decision: primary / secondary plugin selection, routing choice, reviewer overrides, candidate selection, and any deviation from a plugin default.
- Session JSONL must be complete (no torn writes); ATSR and Δ_faith must be computable offline from `logs/pipeline.jsonl`.

## Governance Completeness Score (GCS)

Score each principle 0–5; average is the GCS.

| Principle | Score | Notes |
|---|---:|---|
| 1. Success definition | 4.5 | Completion criteria enumerate HC pass state, verify-before-accept, frozen plugin evidence, document-level coherence, glossary diff cleanliness, and handoff evidence. Minor residual risk: human-review completion is referenced but not machine-enforced in this file. |
| 2. Assessment rubric | 4.5 | Rubric combines plugin-specific reviewer weights, NLI, FaithLens, OVERMISS, DCoEM, glossary lint, and ATSR. Minor residual risk: exact scorer implementations are distributed across scripts/prompts rather than embedded here. |
| 3. Scope boundary | 5.0 | Write boundaries, ownership, and no-touch areas are explicit for source, global glossary, sibling runs, references, prompts, final document, candidates, and reviewer outputs. |
| 4. Data classification | 4.5 | Red/Amber/Green routing and misclassification handling are explicit and aligned with `GROUNDING.md` HC7. Minor residual risk: endpoint allowlist is delegated to `config.toml`. |
| 5. Quality gate | 4.5 | Verify-before-accept, reviewer convergence, audit evidence, and telemetry requirements are explicit with fail-closed semantics. Minor residual risk: human queue plumbing is job-specific. |
| **GCS** | **4.6** | Gate passed at ≥ 4.0. Re-audited for the 2026-05-05 domain-plugin translation update. |

A job whose GCS dropped below 4.0 since the last audit is blocked from running until re-audit.
