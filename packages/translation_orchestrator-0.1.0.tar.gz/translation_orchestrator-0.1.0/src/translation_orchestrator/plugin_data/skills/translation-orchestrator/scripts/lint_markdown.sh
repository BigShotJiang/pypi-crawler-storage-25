#!/usr/bin/env bash
# lint_markdown.sh — Finalize-stage Markdown formatter for translation-orchestrator.
#
# Usage: scripts/lint_markdown.sh <target_md> [config_path]
#
# Behaviour (matches references/lint-policy.md):
#   1. Run markdownlint-cli2 with auto-fix (--fix) using the supplied config
#      (defaults to assets/.markdownlint-cli2.jsonc shipped with the skill).
#   2. Save the diff against the pre-fix file to <runs>/logs/lint.diff.
#   3. Exit 0 if no residual issues; exit 1 if issues remain after fix.
#   4. Master MUST re-run scripts/structure_check.py + scripts/glossary_diff.py
#      against the fixed file. If either drifts, master reverts the fix.
#
# Fail-closed: if markdownlint-cli2 is not on PATH, exit 2 (treated as HC fail).

set -euo pipefail

TARGET="${1:?usage: lint_markdown.sh <target_md> [config_path]}"
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG="${2:-${SKILL_DIR}/assets/.markdownlint-cli2.jsonc}"

if ! command -v markdownlint-cli2 >/dev/null 2>&1; then
  echo "FAIL: markdownlint-cli2 not on PATH (HC fail-closed)" >&2
  exit 2
fi

[[ -f "$TARGET" ]] || { echo "FAIL: target not found: $TARGET" >&2; exit 2; }
[[ -f "$CONFIG" ]] || { echo "FAIL: config not found: $CONFIG" >&2; exit 2; }

JOB_ROOT="$(dirname "$(dirname "$TARGET")")"
LOG_DIR="${JOB_ROOT}/logs"
mkdir -p "$LOG_DIR"

PRE="$(mktemp)"
cp "$TARGET" "$PRE"

set +e
markdownlint-cli2 --config "$CONFIG" --fix "$TARGET"
FIX_RC=$?
set -e

diff -u "$PRE" "$TARGET" > "${LOG_DIR}/lint.diff" || true
rm -f "$PRE"

# Re-run without --fix to detect residual unfixable issues.
set +e
markdownlint-cli2 --config "$CONFIG" "$TARGET" > "${LOG_DIR}/lint.report" 2>&1
RESIDUAL_RC=$?
set -e

if [[ $RESIDUAL_RC -ne 0 ]]; then
  echo "FAIL: residual lint issues; see ${LOG_DIR}/lint.report" >&2
  exit 1
fi

echo "OK: lint clean (initial-fix-rc=${FIX_RC}); diff at ${LOG_DIR}/lint.diff"
exit 0
