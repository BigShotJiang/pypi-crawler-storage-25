# Markdown Lint Policy

> Anchor: [[ai-agent-translation-system-plan#Verify-Before-Accept]]; consumers: `translation-master` (Finalize stage), `scripts/lint_markdown.sh`.

## Goal

Catch deterministic Markdown defects (trailing whitespace, missing blank lines around headings/fences/lists, broken table pipes) **without** rewriting CN prose, line-length, or citation tokens.

## Tooling

- Engine: `markdownlint-cli2` (must be on PATH; missing → fail-closed).
- Config (shipped): `assets/.markdownlint-cli2.jsonc`.
- Wrapper: `scripts/lint_markdown.sh`.

## Rule decisions

| Rule | State | Why |
|---|---|---|
| MD009 trailing whitespace | **strict** | CN-prose cleanliness; `br_spaces=0`. |
| MD022 blanks around headings | **on** | Pandoc/Obsidian rendering correctness. |
| MD031 blanks around fences | **on** | Mermaid + code block separation. |
| MD032 blanks around lists | **on** | Same. |
| MD024 duplicate headings | siblings only | Appendix-B iteration headings repeat by design. |
| MD013 line-length | **off** | CN sentences are long; reflowing risks token drift. |
| MD033 inline HTML | **off** | `<sup>`, `<a id="…">` used for refs. |
| MD034 bare URLs | **off** | Citation arrays inside Mermaid blocks. |
| MD036 emphasis-as-heading | **off** | Definition leads use bold openings. |
| MD040 fenced-code-language | **off** | Mermaid blocks may omit language tag. |
| MD041 first-line-H1 | **off** | Front-matter blockquote precedes H1. |
| MD051 link-fragments | **off** | Cross-vault anchors not always resolvable locally. |
| MD025 single-H1 | **off** | Appendices may use H1. |
| MD007 ul-indent | **off** | 4-space lists allowed. |
| MD012 multiple-blank-lines | **off** | Visual section breaks. |

## Workflow (`Finalize` stage)

`translation-master` runs this sequence after all sections are accepted:

1. `scripts/lint_markdown.sh runs/<job-id>/document/target.md` (auto-fix).
2. Diff vs. pre-fix saved to `logs/lint.diff`. Residual report at `logs/lint.report`.
3. Re-run `scripts/structure_check.py` against the fixed `target.md`.
4. Re-run `scripts/glossary_diff.py` against the fixed `target.md`.
5. If (3) or (4) reports any new failure compared to its pre-Finalize result: **revert** the fix (`git checkout` style or reapply pre-Finalize copy from `logs/`), and escalate. Do **not** ship a target that drifted in fix.
6. Otherwise, commit the fixed `target.md` and proceed to Self-Compare (if configured) or job completion.

## Per-job override

`job.json` may provide `lint_overrides` to disable specific rules for a job (e.g., `{"MD009": false}` for sources with intentional trailing-space hard breaks). Master logs every override into `audit.md`.

## Fail-closed semantics

- `markdownlint-cli2` missing → exit 2 → HC fail-closed → master escalates job.
- Residual issues after `--fix` → exit 1 → master escalates section/job (do not ship).
- Drift detected by structure or glossary check after `--fix` → revert + escalate.

## Anti-patterns

- Running lint **before** verify-before-accept (lint may mask real defects).
- Disabling MD009 globally to "save time" (defeats CN-cleanliness intent).
- Letting lint `--fix` re-flow CN sentences across line breaks (would alter `[[…]]` and citation token spans). MD013 stays off.
