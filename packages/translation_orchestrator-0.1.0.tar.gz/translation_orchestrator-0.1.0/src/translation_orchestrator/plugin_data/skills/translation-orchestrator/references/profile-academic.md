---
name: profile-academic
when_to_use: papers · research reports · technical articles · preprints
inputs: [source_file, target_language]
outputs: [target_document, audit.md, glossary_diff.json, coherence_global.json]
hc_set: GROUNDING.md
plugin_contract:
  primary_domain: academic
  selection_basis: provenance_topic_genre
  frozen_copy: runs/<job-id>/plugin/profile-academic.md
  fixture_requirement: ">=20 academic segments, including >=5 hedge/citation/polarity adversarial cases"
  secondary_glossaries_allowed: [finance, engineering, legal, news]
cp_overrides:
  register: academic-zh
  hedge_preservation: strict
  numerals: arabic
  voice: impersonal
reviewer_set:
  - faithfulness
  - terminology
  - style
  - coherence
  - citation-structure
verify_before_accept:
  - back_translation
  - hedge_aware_nli
  - structure_round_trip
  - glossary_lint
  - qe_debias_R
  - hc_invariant
iteration_cap: 3
N_candidates: 4
N_agents: 5
topology: moderately_sparse
tau_R: 0.30
C_min: 0.70
human_review_sections: [abstract, introduction, conclusion]
---

# Profile: Academic

Default profile. Optimized for English → Chinese translation of research papers and technical articles. This profile is also the built-in `academic` domain plugin described in [[academic-paper-translation-guide#Academic-Domain-Plugin-Contract]].

## Domain plugin contract

- **Selection basis:** provenance × topic × genre. Select `academic` when the source has scholarly provenance, paper-like structure, research-claim language, citations, equations, or abstract / introduction / conclusion sections.
- **Primary vs secondary:** keep `academic` as the governing plugin for papers. If the paper is also financial, legal, biomedical, or engineering-heavy, import that domain's glossary seed as a secondary glossary without weakening academic HCs.
- **Frozen copy:** before Prepare, copy the resolved profile and registry metadata into `runs/<job-id>/plugin/`.
- **Fixture baseline:** before changing default route weights, evaluate at least one open-local route and one frontier route on academic fixtures covering abstracts, methods, results, limitations, equations, tables, citation-dense paragraphs, and conclusions.

## Reviewer weights (for $R(x)$ aggregation)

| Reviewer | Weight | Persona |
|---|---:|---|
| faithfulness | 0.35 | troublemaker |
| terminology | 0.20 | peacemaker |
| style | 0.15 | troublemaker |
| coherence | 0.20 | peacemaker |
| citation-structure | 0.10 | strict (HC veto) |

`citation-structure` does not contribute fluency mass; instead it has **veto** power on HC1 / HC2 violations.

## CP specializations

- **CP1 register** — academic-zh: definitions before claims; nominalization preferred over verb-heavy sentences for definitional content.
- **CP4 first-mention** — every translated domain-specific English term gets its Chinese rendering once per section, then English in parens on first mention; subsequent mentions use the Chinese term only. Terms in `prepare/preserve_english.json` remain English-only; if an explanation is allowed, use English-first once, e.g. `RAG（检索增强生成）`.
- **CP5 voice** — Anglo "we" → "本文" / "本研究" / null subject. Never "我们" in academic register unless it appears in a quoted source.

## Section-type routing hints

| Section type | Notes |
|---|---|
| abstract | Mandatory human review. Tighter $\tau_R = 0.20$. |
| introduction | Mandatory human review. Hedge density expected high; faithfulness reviewer weight bumped to 0.45. |
| methods | Glossary enforcement strict; terminology weight bumped to 0.30. |
| results | Numerals lint strict; polarity (HC6) is the highest-leverage failure mode here. |
| discussion | Hedge density expected highest; HC3 is the highest-leverage failure mode. |
| conclusion | Mandatory human review. |
| references | No translation; structure round-trip only. |

## Backbone choice

Default: large-tier model with 4-candidate QE shortlist + MBR. Reduce to 2 candidates if cost cap is hit.

## Anchors

- [[llm-agent-translation-system-research-report#Recommended Architecture]]
- [[academic-paper-translation-guide#Worked Pipeline]]
