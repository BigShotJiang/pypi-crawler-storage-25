# Glossary Policy

> Anchor: [[llm-agent-translation-system-research-report#refs-anchors]] (TransLaw, CHORUS)

## Four-tier scoping

1. **Controlled English-preservation vocabulary (HC5)** — built by `translation-skim` as `preserve_english_terms[]` and materialized by `translation-prepare` as `runs/<job-id>/prepare/preserve_english.json`. It contains common professional English terms that should remain English in a Chinese translation. Entries are enforced as controlled non-translation: translating them is a `blocker`.
2. **Plugin glossary seeds** — domain-level term seeds from the frozen primary plugin and any secondary plugins. Primary-plugin seeds outrank secondary-plugin seeds. Secondary seeds fill gaps but never weaken primary HCs.
3. **Skim-locked glossary (HC9)** — produced by `translation-skim` once per job, before any per-section work. Lives at `runs/<job-id>/prepare/skim.json` under `core_terminology[]`. Every entry with `locked = true` is HC9-enforced: the same English head must render to the **same** `zh_chosen` at every prose-block occurrence. Locked entries are inviolable for the duration of the job; escalate rather than fragment.
4. **Paper-local / document-local glossary** — built by `translation-prepare` from the source document, seeded by skim and the resolved plugin. Lives at `runs/<job-id>/prepare/glossary.json`. Holds section-scoped or non-locked terms. Consistency within the document is mandatory but not HC9-enforced; reviewer-driven.
5. **Corpus-global glossary** — institutional / project-level controlled term list. Read-only from the skill's perspective. Lives outside `runs/`. Drift requires explicit `glossary_diff.json` proposal.

The Translator-Backbone receives **all three** at translate time, in this precedence (highest first):

- **HC1/HC5 controlled-non-translation list** — author / institution / dataset names and citation keys. Always wins.
- **HC5 professional English-preservation vocabulary** — common professional terms in `prepare/preserve_english.json`; preserve English surface form and allowed variants exactly as configured.
- **HC9 skim-locked entries** — single canonical CN rendering for every cross-section term. Wins over corpus-global only when the skim explicitly cited a higher-precedence rule (e.g., standard-CN-academic mismatch with corpus); the rationale must be in `skim.json`.
- **Primary plugin glossary seed** — domain defaults selected by provenance × topic × genre.
- **Secondary plugin glossary seeds** — imported only for overlapping subdomains such as finance-heavy academic papers or engineering-heavy news.
- **Corpus-global rendering** — wins over paper-local for terms that are not skim-locked.
- **Paper-local rendering** — wins for newly coined or paper-specific terminology, only when no higher tier applies.

Every conflict resolution is logged in `glossary_diff.json`.

## Professional English-preservation vocabulary (HC5)

The Skim stage proposes common professional English terms that Chinese-domain readers are expected to know in English. This follows the research report's terminology-memory recommendation: terminology is a separate quality dimension $T$, not an afterthought, and the Domain + Terminology Retriever / Terminology Reviewer are responsible for applying it consistently.

Use **English preservation** when a term meets one or more of these criteria:

- It is a standard acronym or model / method / benchmark name normally cited in English: `LLM`, `RAG`, `Transformer`, `BERT`, `GPT`, `BLEU`, `COMET`, `MQM`, `NLI`, `QE`, `MBR`, `MoE`, `API`, `SDK`, `MCP`.
- It is a paper-local system, agent, dataset, metric, or protocol name that functions as an identifier: `TACTIC`, `CHORUS`, `TransLaw`, `FaithLens`, `OVERMISS`, `DCoEM`.
- Translating it would reduce recognizability for the target technical audience or create multiple unstable Chinese paraphrases.
- The user or job explicitly asks to keep the term in English.

Do **not** preserve English when:

- The term has a stable, standard Chinese academic rendering and is not normally used as an English identifier in Chinese prose, e.g. `embedding` → `嵌入`, `attention` → `注意力` unless the profile or user says otherwise.
- The source term is ordinary prose rather than terminology, e.g. `system`, `method`, `paper`, `result`.
- A Chinese rendering is needed to preserve a definition or claim.

Each preserved entry must include: `en`, `variants`, `category`, `frequency`, `sections_seen`, `preserve = true`, `rationale`, and `source = skim | job_seed | corpus_global | human_override`. Prepare writes the final list to `prepare/preserve_english.json`; the Terminology Reviewer treats it as HC5.

## Application order

1. Pre-prompt injection of the glossary as a constrained-decoding hint or system prompt prefix.
2. Constrained decoding for HC entries where the host supports it, including HC5 English-preservation entries.
3. Post-edit lint via the Terminology-Reviewer — but **never** as the only enforcement. Post-edit-only glossary application is the anti-pattern called out in the plan ([[ai-agent-translation-system-plan#Anti-Patterns to Avoid]]).

## First-mention (CP4) — state machine

CP4 is a **state machine** carried on each glossary entry, not a per-section rerun. Profiles configure scope; Translator-Backbone updates state as it walks sections in order.

States (per entry):

- `unseen` — entry has never appeared in the target.
- `applied(section_id)` — `(English)` parens have been emitted; record which section first applied them.
- `suppressed` — within the same scope window, do not re-emit parens.

Profile-configured scope:

- **Academic** profile: scope = section. Transition `unseen → applied(s)` on first prose occurrence in section `s`; transition back to `unseen` at next section boundary.
- **Software-docs** profile: scope = section, same as academic.
- **Legal** profile: scope = document. Transition `unseen → applied(s)` once; then `suppressed` for the rest of the document; never re-emitted.
- **Marketing** profile: brand-voice doc decides; default `suppressed` from the start (Chinese-only).

Reviewer-Terminology surfaces redundant first-mention parens (state `applied`/`suppressed` but parens re-emitted) as a `first_mention_redundant` finding (severity `minor`, not blocker), so they get cleaned up without thrashing the round count.

The state lives on `core_terminology[].first_mention_state` and `first_mention_section` (per `schemas/skim.json`); paper-local non-skim entries carry the same fields in `prepare/glossary.json`.

## Glossary-diff output

`runs/<job-id>/document/glossary_diff.json`:

```json
{
  "applied": [
    {"src": "transformer", "tgt": "Transformer 模型", "scope": "paper-local"}
  ],
  "skipped": [
    {"src": "we", "reason": "CP5 voice override: null subject"}
  ],
  "conflicts_resolved": [
    {"src": "embedding", "paper_local": "嵌入向量", "corpus_global": "嵌入", "winner": "corpus_global", "rationale": "CP-tier conflict; corpus wins"}
  ]
}
```

Every entry must have a `src`, a `rationale` if non-trivial, and (for conflicts) a `winner` and the rule that selected it.

## Anti-patterns

- Glossary applied **only** as post-edit (causes reviewer thrash and cost explosion).
- Paper-local glossary overriding HC entries (e.g., translating an author name because the source uses an unusual spelling).
- Silent conflict resolution (no entry in `glossary_diff.json`).
- Applying a secondary plugin as if it were primary. Example: a finance-heavy academic paper may import finance terms, but academic citation / hedge / equation HCs still govern.
- **Multiple CN renderings of one locked English term across the document.** This is the failure mode that HC9 + the skim pass exist to prevent. Example from real comparison: `deterministic-wrapper` rendering as `确定性封装层` / `确定性封装` / `确定性外壳` across three sections is a `blocker`, not a stylistic variation.
- **Translating a preserved English term.** If `prepare/preserve_english.json` says `Transformer` or `RAG` is preserved, `变换器` or `检索增强生成` in running prose is an HC5 violation unless the entry explicitly lists that Chinese expansion as allowed explanatory text.
- **Translating Obsidian wiki-link targets.** `[[harness-engineering-design]]` must NOT become `[[harness-engineering-design-zh]]` even if a `-zh` counterpart exists. Wiki-link redirection is parent-caller responsibility (HC1).
- **Re-emitting `(English)` parens after CP4 state is `applied` or `suppressed`.** This is a `first_mention_redundant` finding, surfaced by Reviewer-Terminology.
- **Backbone-proposal-only `selection_rule` in skim.json.** A `core_terminology` entry whose `rationale` is "backbone proposed it" without first checking corpus-global and standard-CN-academic is a quality defect; re-run skim before locking.
