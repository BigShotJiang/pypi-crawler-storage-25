# Translation Orchestrator Troubleshooting

Use this runbook when the skill loads but a job cannot proceed. Recovery actions must preserve HC1-HC10 and the subagent ownership rules.

## Skill packaging and triggering

**Symptom: skill does not upload or load as a Claude skill.**
Cause: The skill folder is mispackaged, the entrypoint is not exactly `SKILL.md`, or frontmatter is invalid.
Solution: Package the `translation-orchestrator/` folder itself, verify `SKILL.md` is present with `---` frontmatter delimiters, and run the upload-readiness checks in `references/skill-evaluation.md`.

**Symptom: skill does not trigger on a full-document translation request.**
Cause: The user phrased the task as a generic document task or omitted translation intent.
Solution: The host should still invoke this skill when the request includes full-document translation to Chinese, EN→ZH, "translation harness", `.pdf` / `.md` / `.tex` / `.docx` source translation, resume of `runs/...`, or prior-version comparison.

**Symptom: skill triggers for single-sentence translation or proofreading.**
Cause: The description or host routing is over-broad.
Solution: Do not run the harness. Refuse early and suggest a plain LLM translation / proofreading workflow. Keep negative trigger examples in `SKILL.md` and `references/skill-evaluation.md` current.

**Symptom: skill loads but consumes too much context before acting.**
Cause: Detailed prompt/reference files were loaded eagerly instead of progressively.
Solution: Start from `SKILL.md`; load only the phase-specific files in the progressive disclosure map. Do not load every profile, prompt, and schema for a routine job.

## Startup and routing

**Error: "GCS audit below 4.0; refusing to start."**
Cause: `references/AGENTS.md` audit failed or is incomplete.
Solution: Re-run the design audit on the source/profile pair before invoking the skill.

**Error: "HC7 violation: red classification routed to cloud endpoint."**
Cause: Router selected a cloud model for Red-classified content.
Solution: Override the router with a local-only profile, or reclassify only if the data sensitivity assessment genuinely changes.

**Error: "No compliant route under budget."**
Cause: HC7, cost, latency, or model separation constraints eliminate every route.
Solution: Relax cost/latency budgets in `job.json` or provide a compliant local/approved endpoint. Do not use the same model for backbone and back-translation.

## Verify-before-accept

**Error: "Verify-before-accept rejected: signal missing."**
Cause: NLI, back-translation, structure check, glossary lint, or QE-Debias is unavailable.
Solution: Restore the missing backend or switch to a profile with compliant local tools. Do not bypass the gate.

**Error: "HC9 violation: locked term rendered as multiple CN forms."**
Cause: Translator-Backbone fragmented a locked glossary entry across sections.
Solution: Reject the section. The master returns it for revise round 2 or 3 with `next_action.suggested_term = skim.zh_chosen`. If the locked rendering is genuinely unsuitable, the backbone must escalate rather than substitute.

**Error: "HC10 violation: verbatim-block SHA mismatch."**
Cause: Translator-Backbone translated or altered a block whose `prepare/blocks.json` policy was `verbatim`, `verbatim_labels`, or `mixed`.
Solution: Reject the section. Backbone must re-emit protected spans byte-identical to source. If the policy is wrong, correct it through a job override and cite the override in `audit.md`.

## Finalize

**Error: "Finalize: markdownlint-cli2 not on PATH."**
Cause: Required lint tool is missing.
Solution: Install `markdownlint-cli2` and re-run Finalize. Do not skip Finalize.

**Error: "Finalize: structure_check regressed after lint fix; reverted."**
Cause: `markdownlint-cli2 --fix` modified a protected span, wiki-link, or verbatim block.
Solution: Inspect `logs/lint.diff`, tune `assets/.markdownlint-cli2.jsonc` or `job.json.lint_overrides`, and re-run Finalize after confirming protected spans remain byte-identical.

## Agent behavior

**Symptom: skill loads but does not orchestrate subagents.**
Cause: Host CLI does not support subagent invocation.
Solution: Simulate sequential specialist passes under the master agent, but never collapse roles in a single prompt.

**Symptom: doom-loop at iteration cap on most sections.**
Cause: Reviewer disagreement, persona miscalibration, or repeated HC9/HC10 errors from upstream artifacts.
Solution: Inspect `logs/pipeline.jsonl` for reviewer score deltas and repeated blocker IDs. Fix the upstream artifact or adjust persona assignment in `config.toml`; do not raise the iteration cap.

**Symptom: Skim selects `backbone_proposal` for most locked terms.**
Cause: Skim ignored corpus-global or standard-CN-academic precedence.
Solution: Re-run Skim with explicit precedence: corpus_global > standard_cn_academic > human_reference > highest_frequency > backbone_proposal.
