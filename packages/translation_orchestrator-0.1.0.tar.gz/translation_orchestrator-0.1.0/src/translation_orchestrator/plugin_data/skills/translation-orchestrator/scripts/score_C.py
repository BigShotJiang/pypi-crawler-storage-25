"""score_C.py — DCoEM 4-manner document-level coherence score.

Stub / specification. Used by the coherence reviewer.

DCoEM 4-manner dimensions:
    relevance      — content stays on-topic across sections
    organization   — section order and internal structure mirror source
    transition     — discourse connectives appear / vanish where source structure implies
    focus          — entity / coreference chains are coherent across the document

C = weighted geometric mean of the four sub-scores in [0, 1].
A document with C < profile.C_min triggers a `revise` from the coherence reviewer
on the section that introduced the largest negative delta.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class CInputs:
    target_partial_md: str       # accepted sections, concatenated
    current_section_md: str
    entity_graph: dict
    weights: dict                # default {relevance: 0.30, organization: 0.25, transition: 0.20, focus: 0.25}


def score_C(inputs: CInputs) -> dict:
    """Returns {'C': float, 'sub': {...}, 'span_findings': [...]}."""
    raise NotImplementedError("Bind to DCoEM probe at install time.")
