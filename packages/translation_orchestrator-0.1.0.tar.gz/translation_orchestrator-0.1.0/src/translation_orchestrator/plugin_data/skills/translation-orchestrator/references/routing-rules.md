# Routing Rules

> Anchor: [[llm-agent-translation-system-research-report#Knowledge Management and Routing]]

The Coordinator-Router subagent picks **model × strategy × review-depth** per section, on a Pareto utility $U$, subject to HC7 (data classification) and the frozen domain plugin.

## Inputs to the router

- `section.features` — type (abstract / methods / results / …), length, hedge density, citation density, code-block presence, inline-equation presence.
- `runs/<job-id>/plugin/plugin.json` — resolved primary plugin, secondary glossary plugins, fixture / route-override pointers.
- `profile.*` — reviewer set, weights, tau_R, iteration cap, N_candidates. For new jobs this is the profile copied under `runs/<job-id>/plugin/`.
- `job.classification` — Red / Amber / Green per `GROUNDING.md`.
- `cost_budget`, `latency_budget` — per-job caps from `job.json`.

## Outputs

A `route.json` per section:

```json
{
  "section_id": "sec-3.1",
  "model": "<backbone model id>",
  "back_translation_model": "<distinct from backbone>",
  "strategy": "qe_shortlist_mbr",
  "N_candidates": 4,
  "review_depth": "full",   // "full" | "fast" | "structural_only"
  "reviewers": ["faithfulness", "terminology", "style", "coherence", "citation-structure"],
  "primary_domain": "academic",
  "secondary_domains": ["engineering"],
  "plugin_overrides_applied": ["academic:section-type-routing-hints"],
  "classification": "green",
  "rationale": "abstract: tau_R=0.20, full reviewer chain, large-tier backbone"
}
```

## Pareto utility $U$

```text
U = w_quality * Q_hat
  - w_cost * cost_estimate
  - w_latency * latency_estimate
  + w_classification * classification_match
```

Where:

- `Q_hat` is the predicted accept probability under the chosen route, learned offline from session JSONL.
- `classification_match` is 1 if the route is allowed under HC7, else **the route is rejected** — this is not a soft penalty.

Weights live in `config.toml` (`[router]`).

## Domain-plugin routing

Domains are selected by provenance × topic × genre. The primary plugin governs reviewer weights, thresholds, mandatory reviewers, human-review sections, and HC extensions. Secondary plugins may contribute glossary seeds or route overrides, but **must not** weaken the primary plugin's HCs, reviewer set, or classification restrictions.

Starter plugin defaults:

| Primary plugin | Default review depth | Tighten route when |
|---|---|---|
| `academic` | `full` | abstract, introduction, conclusion, hedge-dense discussion, citation/equation-heavy prose |
| `news` | `full` | headline, lede, quote attribution, correction notice, allegation / claim-heavy passage |
| `finance` | `full` | financial tables, risk factors, outlook, currency / percentage / date-dense spans |
| `engineering` | `full` | requirements, incident timeline, architecture diagrams, code/interface-token-heavy spans |
| `legal` | `full` + human review | any legal clause, date, amount, defined term, citation, obligation, or exception |
| `marketing` | `fast` or `full` | regulated claim, disclaimer, pricing, campaign headline, brand term |
| `software-docs` | `fast` or `full` | commands, APIs, config keys, code blocks, tutorials, getting-started sections |

Before changing a plugin's default route weights, compare at least one open-local route and one frontier route on that plugin's fixture set when fixtures are available. Log ATSR and $\Delta_{faith}$ in `logs/pipeline.jsonl`.

## Hard rules (HC7 enforcement)

- Red classification → router selects local-only backbone, local-only back-translator. No cloud model id may appear in `route.json`. If unavailable, the router emits a `route_rejection` and the master escalates.
- Amber classification → router restricts to `[router.amber_endpoint_allowlist]` (configured per project; not in the skill itself).
- Green classification → unrestricted modulo cost/latency budgets.

## Review-depth tiers

- **full** — full reviewer chain, used by default for high-stakes primary plugins such as academic, news, finance, engineering, and legal.
- **fast** — drop coherence and style; use for low-stakes section types (e.g., references list).
- **structural_only** — only `citation-structure`; used for reference lists, code blocks-only sections, or tables of contents.

The router never picks a `review_depth` that drops `faithfulness` or `citation-structure`. Those are mandatory for any section containing prose or structural elements.

## Anti-patterns the router must refuse

- Picking the same model for backbone *and* back-translation (defeats the no-oracle property of DryRUN).
- Picking a cloud model for a Red-classified section.
- Picking `structural_only` review depth when the section contains hedges (would silently bypass HC3).
- Picking $N_{\text{candidates}} = 1$ — at minimum 2 for QE shortlist + MBR to be meaningful.
- Letting a secondary plugin weaken the primary plugin's HCs, reviewers, or human-review requirements.
- Changing route defaults without fixture evidence when the plugin provides `eval_fixtures`.
