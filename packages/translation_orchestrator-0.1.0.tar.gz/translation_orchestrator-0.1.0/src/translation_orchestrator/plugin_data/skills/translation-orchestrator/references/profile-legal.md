---
name: profile-legal
when_to_use: contracts · statutes · regulations · legal opinions · case law
inputs: [source_file, target_language, jurisdiction]
outputs: [target_document, audit.md, glossary_diff.json, term_anchor_map.json]
hc_set: GROUNDING.md
cp_overrides:
  register: legal-zh
  hedge_preservation: strict
  voice: impersonal
  numerals: arabic
reviewer_set:
  - faithfulness
  - terminology
  - style
  - coherence
  - citation-structure
verify_before_accept:
  - back_translation
  - hedge_aware_nli
  - structure_round_trip
  - glossary_lint
  - qe_debias_R
  - hc_invariant
  - term_anchor_check
iteration_cap: 3
N_candidates: 4
N_agents: 5
topology: moderately_sparse
tau_R: 0.20
C_min: 0.75
human_review_sections: [all]
---

# Profile: Legal

Profile for legal-domain translation. **All sections require human review** before publication; the agent harness produces a high-quality first draft and an exhaustive audit, not a final.

## Reviewer weights

| Reviewer | Weight | Persona |
|---|---:|---|
| faithfulness | 0.40 | troublemaker |
| terminology | 0.30 | strict (HC veto on controlled-term list) |
| style | 0.05 | peacemaker |
| coherence | 0.10 | peacemaker |
| citation-structure | 0.15 | strict (HC veto) |

## Domain-specific HCs (lifted from GROUNDING + extended)

- **Term anchors** — every controlled legal term resolves to exactly one Chinese rendering for the duration of the document. Drift across sections is a `blocker`.
- **English identifiers** — contract product names, software platform names, API names, and case/dataset identifiers that are controlled as English-only are preserved through `prepare/preserve_english.json` under HC5.
- **Numeral / date integrity** — numerals, dates, and monetary amounts round-trip byte-identical including currency symbols. Treated under HC1.
- **Polarity (HC6) is the highest-leverage failure mode.** Negation drift in legal text changes meaning catastrophically.

## CP specializations

- Legal-zh register: 当事人 / 应当 / 不得 / 视为 / 推定 vocabulary preferred; avoid colloquial particles.
- Sentence boundaries follow source punctuation strictly; do not merge or split across legal clauses.

## Anchors

- [[llm-agent-translation-system-research-report#refs-anchors]] (TransLaw, CHORUS)
