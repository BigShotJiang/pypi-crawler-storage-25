---
name: profile-marketing
when_to_use: marketing copy · brand pages · campaign assets · transcreation
inputs: [source_file, target_language, brand_voice_doc]
outputs: [target_document, audit.md, glossary_diff.json, transcreation_notes.md]
hc_set: GROUNDING.md
cp_overrides:
  register: marketing-zh
  hedge_preservation: relaxed   # marketing copy intentionally drops hedges
  voice: brand_voice
  numerals: arabic
reviewer_set:
  - faithfulness
  - terminology
  - style
  - coherence
verify_before_accept:
  - back_translation
  - structure_round_trip
  - glossary_lint
  - qe_debias_R
  - hc_invariant
iteration_cap: 2
N_candidates: 6
N_agents: 4
topology: moderately_sparse
tau_R: 0.40
C_min: 0.60
human_review_sections: [hero_copy, cta, headlines]
---

# Profile: Marketing

Profile for marketing copy and transcreation. Faithfulness is **claim-level**, not surface-level — the harness must preserve product claims, regulatory disclaimers, and quantitative facts (HC4), but is permitted to restructure sentences for resonance in target locale.

## Reviewer weights

| Reviewer | Weight | Persona |
|---|---:|---|
| faithfulness | 0.25 | troublemaker (claim-level) |
| terminology | 0.30 | strict (brand & product names) |
| style | 0.35 | troublemaker (brand voice) |
| coherence | 0.10 | peacemaker |

`citation-structure` is omitted — marketing copy rarely has formal citations. If the input has citations, fall back to `profile-academic` instead.

## CP specializations

- Hedge preservation is **relaxed**: marketing copy intentionally asserts. HC3 does not apply, but HC4 (no claim invention) still does — the harness must not invent product capabilities.
- Brand, product, platform, API, and campaign identifiers marked in `prepare/preserve_english.json` remain English under HC5 unless the brand-voice document explicitly supplies a localized name.
- Style reviewer is bumped to 0.35; brand voice document is the single source of truth for register.

## Backbone choice

6 candidates with QE shortlist + MBR; pick on a Pareto frontier weighted toward style match.

## Anchors

- [[llm-agent-translation-system-research-report#refs-anchors]]
