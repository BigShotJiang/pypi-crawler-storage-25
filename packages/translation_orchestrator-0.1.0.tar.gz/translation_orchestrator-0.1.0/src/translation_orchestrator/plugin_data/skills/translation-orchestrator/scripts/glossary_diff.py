"""glossary_diff.py — compute applied vs skipped vs conflict-resolved glossary entries.

Stub / specification. Used after document assembly to emit
runs/<job-id>/document/glossary_diff.json per references/glossary-policy.md.

Output schema:
{
  "applied":    [{"src": "transformer", "tgt": "Transformer 模型", "scope": "paper-local"}, ...],
  "skipped":    [{"src": "we", "reason": "CP5 voice override: null subject"}, ...],
  "preserved_english": [
    {"src": "RAG", "section": "intro", "count": 3, "explanation_used": true}
  ],
  "conflicts_resolved": [
    {"src": "embedding", "paper_local": "嵌入向量", "corpus_global": "嵌入",
     "winner": "corpus_global", "rationale": "CP-tier conflict; corpus wins"}
  ],
  "hc_violations": [
     # HC5 violations (controlled item or preserved-English term appeared translated)
     {"hc": "HC5", "src": "Anthropic", "tgt": "人类学", "section": "intro"},
     {"hc": "HC5", "src": "RAG", "tgt": "检索增强生成", "section": "methods"},
    # HC9 violations (locked term rendered with multiple CN forms)
    {"hc": "HC9", "src": "deterministic-wrapper",
     "locked_zh": "确定性封装层",
     "found_forms": [
       {"form": "确定性封装", "section": "5.2", "count": 3},
       {"form": "确定性外壳", "section": "App-B", "count": 1}
     ]}
  ],
  "first_mention_redundant": [
    {"src": "TACTIC", "section": "4.3", "reason": "applied in 4.1; scope=document"}
  ]
}

Hard rules:
- HC5: controlled-non-translation list always wins. Any item translated in
  target -> hc_violations entry + HC5 raise via structure check.
- HC5: professional English-preservation vocabulary always wins. Any item in
  prepare/preserve_english.json translated or Chinese-paraphrased in target ->
  hc_violations entry. If allow_chinese_explanation_once=true, only an
  English-first explanatory apposition is allowed once.
- HC9 (locked-glossary respect): every skim_locked entry (skim.json
  core_terminology[].locked = true, scope = "document") must render with the
  same `zh_chosen` at every prose-block occurrence. Multiple distinct CN
  forms detected for one locked English head -> blocker-severity hc_violations
  entry, master rejects the section (or the whole job at finalize).
- CP4 first-mention state machine: walk sections in order, track per-entry
  state (unseen | applied(section) | suppressed) per profile scope. Re-emitted
  parens after applied/suppressed -> first_mention_redundant entry (minor).

Detection of multi-form fragmentation (HC9):
- For each locked entry, scan target for any CN form that maps back to the
  same English head (via reverse-glossary index built from corpus + paper +
  skim). If > 1 distinct CN form observed across the document, flag.
- Tolerance: forms that differ only by a trailing 模型/方法/系统 suffix when the
  locked form lacks the suffix are still flagged (semantic drift).
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class GlossaryDiffInputs:
    target_md: str
    paper_local_glossary: dict
    corpus_global_glossary: dict
    controlled_non_translation: list[str]
    preserve_english_terms: list[dict] | None = None
    skim_glossary: dict | None = None  # parsed skim.json; required for HC9
    profile_first_mention_scope: str = "section"  # section | document | none


def glossary_diff(inputs: GlossaryDiffInputs) -> dict:
    raise NotImplementedError("Bind to tokenizer/aligner at install time.")
