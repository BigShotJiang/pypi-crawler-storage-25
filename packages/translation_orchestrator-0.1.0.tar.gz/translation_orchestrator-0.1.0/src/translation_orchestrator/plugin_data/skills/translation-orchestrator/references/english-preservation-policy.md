# English Preservation Policy

> Job-level policy for common professional English terms that should remain English in Chinese translations. Evidence anchor: [[llm-agent-translation-system-research-report#Recommended Architecture]] and [[llm-agent-translation-system-research-report#Agent Roles]], especially the Domain + Terminology Retriever and Terminology Reviewer roles.

## Purpose

Chinese technical readers often expect common professional terms, acronyms, model names, benchmark names, and protocol names in English. Translating these terms can reduce recognizability and cause terminology drift. The translation pipeline therefore builds a controlled English-preservation vocabulary before per-section translation.

## Artifact

Prepare writes the final vocabulary to:

```text
runs/<job-id>/prepare/preserve_english.json
```

This artifact is HC5-controlled. Translator-Backbone must preserve listed terms; Terminology Reviewer must flag translated or paraphrased forms as blockers.

## Selection criteria

Preserve English when at least one criterion holds:

1. The term is a standard acronym in technical Chinese prose: `LLM`, `RAG`, `NLI`, `QE`, `MBR`, `MoE`, `API`, `SDK`, `MCP`.
2. The term is a model, benchmark, method, dataset, metric, paper-system, or framework name: `Transformer`, `BERT`, `GPT`, `BLEU`, `COMET`, `MQM`, `TACTIC`, `CHORUS`, `TransLaw`, `FaithLens`, `OVERMISS`, `DCoEM`.
3. The source uses the term as an identifier, label, or citation handle rather than ordinary prose.
4. The user supplied the term in `job.json.preserve_english_seed_terms`.
5. A corpus-global controlled non-translation list marks the term as English-only.

Do not preserve English when:

1. The term is ordinary prose: `paper`, `system`, `method`, `result`, `approach`.
2. A stable Chinese rendering is expected and improves readability: `embedding` → `嵌入`, `attention` → `注意力`, `back-translation` → `回译`.
3. Preserving the English term would obscure a claim, definition, hedge, or contrast.

## Output fields

Each entry contains:

```json
{
  "en": "RAG",
  "variants": ["retrieval-augmented generation", "Retrieval-Augmented Generation"],
  "category": "method",
  "frequency": 6,
  "sections_seen": ["intro", "methods"],
  "preserve": true,
  "allow_chinese_explanation_once": true,
  "rationale": "Standard acronym used directly in Chinese technical prose; translating would reduce recognizability.",
  "source": "skim"
}
```

`allow_chinese_explanation_once` permits an explanatory apposition such as `RAG（检索增强生成）` at first mention when the profile wants it. The head term remains English; subsequent mentions are English-only.

## Enforcement

- Translator-Backbone treats entries as constrained decoding requirements.
- CP4 first-mention does not generate Chinese-term-first output for preserved entries. If an explanation is allowed, use English first: `RAG（检索增强生成）`, not `检索增强生成（RAG）`.
- Terminology Reviewer is source-blind but target-side strict: known Chinese paraphrases of preserved entries are `controlled_translated` blockers.
- `glossary_diff.json` records preserved terms under `preserved_english` and violations under `hc_violations` with `hc = "HC5"`.
