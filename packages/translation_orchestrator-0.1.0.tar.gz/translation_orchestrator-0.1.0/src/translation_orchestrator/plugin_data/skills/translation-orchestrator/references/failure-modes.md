# Failure Modes

> Catalog of academic-translation pitfalls and the reviewer / gate that catches each. Used by the master agent to diagnose verify-before-accept rejections and by the runbook to map signals to causes.

## F1 — Hedge dropped

**Symptom.** "We hypothesize that …" → "本文表明……" (loss of `hypothesize`).
**Catcher.** Faithfulness reviewer (HC3) + hedge-aware NLI in verify-before-accept.
**Common cause.** Backbone trained on news / web corpora that prefer assertive Chinese register.
**Mitigation.** Hedge-lock prompt in `prompts/translator-backbone.md`; faithfulness reviewer persona-bias = troublemaker.

## F2 — Claim invented

**Symptom.** Target adds a result, mechanism, or effect size not in source.
**Catcher.** Faithfulness reviewer (HC4) + back-translation diff.
**Common cause.** Over-helpful expansion in the backbone, or aggregation from prior reviewer rounds without monotonic-history ordering.
**Mitigation.** ECP projection in coordination protocol; reviewer outputs structurally separated from raw text.

## F3 — Polarity flipped

**Symptom.** "X did not improve Y" → "X improved Y" (catastrophic in legal & results sections).
**Catcher.** Faithfulness reviewer (HC6) + polarity lint in `scripts/structure_check.py`.
**Common cause.** Negation drop during paraphrasing, especially with double-negation or contrastive markers.
**Mitigation.** Deterministic polarity lint runs in verify-before-accept; alerts on negation count mismatch.

## F4 — Citation key corrupted

**Symptom.** `[Smith2020]` → `[Smith,2020]` or `[史密斯2020]` or `(Smith, 2020)`.
**Catcher.** Citation-Structure reviewer (HC1) + structure round-trip in verify-before-accept.
**Common cause.** Reviewer round wrongly allowed to edit text; or backbone reformatted citation under fluency pressure.
**Mitigation.** Mask citations before translate (`scripts/mask.py`); per-subagent tool scoping forbids reviewers from editing.

## F5 — Equation / figure reference broken

**Symptom.** `Eq. (3)` → `公式 3` (number drift) or `Fig. 2` → `图二` (numeral CP override applied where HC2 forbids).
**Catcher.** Citation-Structure reviewer (HC2) + structure round-trip.
**Common cause.** CP2 (Chinese characters in fixed expressions) accidentally applied to equation labels.
**Mitigation.** Mask equation labels and figure refs before translate; HC2 supersedes CP2 inside masked spans.

## F6 — Controlled English term translated

**Symptom.** "Stanford University" → "斯坦福大学" when the controlled list says no; `RAG` → `检索增强生成` when `prepare/preserve_english.json` says to keep `RAG`; or an author's surname Romanized differently across sections.
**Catcher.** Terminology reviewer (HC5) + glossary lint.
**Common cause.** Paper-local glossary overriding HC5; no controlled list configured; or Skim failed to build the professional English-preservation vocabulary.
**Mitigation.** HC5 always wins over paper-local; require a controlled list for any name-bearing job; require `prepare/preserve_english.json` for professional English terms that should remain English.

## F7 — Reviewer sycophancy / persona collapse

**Symptom.** All reviewers converge to `accept` in round 1 with identical phrasing.
**Catcher.** Master agent's diversity check on `verdict` and `issue.type` distribution across reviewers.
**Common cause.** ECP projection violated (reviewers seeing each other's raw text); or persona pool too narrow.
**Mitigation.** Persona pool from the profile (troublemaker / peacemaker); ECP-projected `review.json` only.

## F8 — Reviewer doom-loop

**Symptom.** Same `(reviewer, issue_type, span)` triple repeats across rounds without convergence.
**Catcher.** Master agent's loop detector + iteration cap.
**Common cause.** Source ambiguity, conflicting reviewer rubrics, or backbone unable to satisfy mutually contradictory CP overrides.
**Mitigation.** Iteration cap = 3; escalate to human queue; log fingerprint for `failure-modes.md` regression case.

## F9 — Glossary drift across sections

**Symptom.** "embedding" rendered as "嵌入" in §2 and "嵌入向量" in §4.
**Catcher.** Document-level glossary-diff lint after section pass.
**Common cause.** Paper-local glossary built per-section instead of per-document.
**Mitigation.** Build glossary in `translation-prepare` once per document; pass to every section.

## F10 — Coherence drift over long doc

**Symptom.** Entity reference chains break; coreference drifts; document-level $C$ drops below `C_min`.
**Catcher.** Coherence reviewer (DCoEM 4-manner) at document scope.
**Common cause.** Per-section translation without entity graph; backbone has no document-level state.
**Mitigation.** Entity / coreference graph carried as global context in `prepare/entity_graph.json`.

## F11 — QE bias amplified

**Symptom.** $R(x)$ systematically lower for sections with rare entities or non-standard register.
**Catcher.** QE-Debias subagent.
**Common cause.** QE model trained on dominant-style data.
**Mitigation.** QE-Debias wrapper on every QE flow; FairQE-class calibration.

## F12 — Verify-before-accept silently bypassed

**Symptom.** Section accepted with `R(x)` not logged or back-translation evidence missing.
**Catcher.** Master agent's gate-completeness check before writing `target.md`.
**Common cause.** Signal failure (NLI service down) treated as pass instead of reject.
**Mitigation.** Fail-closed semantics in `scripts/score_R.py`; missing signal = HC violation.

## F13 — Red classification breach

**Symptom.** Routing log shows cloud endpoint for a Red-classified job.
**Catcher.** Router pre-flight + audit at job completion.
**Common cause.** Misclassification at intake or HC7 treated as soft preference.
**Mitigation.** Runbook R4; classification gate is HC, not CP; unit test on red-fixture.
