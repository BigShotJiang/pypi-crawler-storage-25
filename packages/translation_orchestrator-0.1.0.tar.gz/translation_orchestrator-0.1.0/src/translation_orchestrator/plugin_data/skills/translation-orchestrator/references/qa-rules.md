# QA Rules

> Anchor: [[llm-agent-translation-system-research-report#Quality Assurance and Evaluation]]

The QA layer is the deterministic backstop that the reviewer chain feeds into. Reviewers are evidence; QA rules are gates.

## Gate order (verify-before-accept)

1. **Back-translation** with a *separate* model from the translator backbone. Compare claim, hedge, and entity sets.
2. **Hedge-aware NLI** between source and target (HC3, HC4).
3. **Structure round-trip** for citations, equations, figure refs, code blocks (HC1, HC2).
4. **Glossary lint** — hard violations (controlled-non-translation list, professional English-preservation vocabulary, controlled-Chinese-rendering list) reject; soft violations flag.
5. **Polarity / numeral lint** (HC6, HC2 numeric integrity).
6. **QE-Debias** scored $R(x)$ — must be ≤ the frozen primary plugin's `tau_R`.
7. **Plugin fixture regression** — when route weights, glossary policy, reviewer prompts, or profile rules changed since the last accepted baseline, run the plugin fixture subset and fail closed on new HC drift.
8. **HC invariant check** — final whole-section pass over the GROUNDING HC list.

A `Reject` from any stage stops the gate. The section returns to the master agent with the failure reason, and the relevant reviewer is invoked for the next round.

## Aggregating $R(x)$

```text
R(x) = 1
     - (sum_i w_i * accept_score_i)
     + lambda_hc * I[any_HC_violation]
     + lambda_qe * (1 - QE_debiased)
```

- `w_i` from the frozen primary plugin's reviewer-weights table.
- `lambda_hc` is large enough that any HC violation makes $R$ exceed any reasonable `tau_R`.
- `lambda_qe` from `config.toml` (default 0.20).

`accept_score_i` for a reviewer is 1 if `verdict == accept`, 0.5 if `verdict == revise` with no HC issues, 0 if `verdict == revise` with HC issues, and we never aggregate if `verdict == escalate` (the master goes straight to the human queue).

## What QA rules are NOT

- They are not a substitute for ATSR. ATSR measures the harness; QA gates measure individual sections.
- They are not adjustable per-section. Primary-plugin overrides apply to the whole job; secondary plugins can add glossary context but cannot lower QA gates.
- They are not BLEU/chrF/COMET. Surface metrics may be logged for diagnostics but never gate a section.

## What QA rules require from the host

- A back-translation model distinct from the backbone. If the host cannot provide one, the job is rejected at startup with a clear error message.
- Persistent storage of every gate's input and output under `runs/<job-id>/sections/<sec>/`.
- A frozen `runs/<job-id>/plugin/` copy for the selected primary plugin and any secondary glossary imports.
