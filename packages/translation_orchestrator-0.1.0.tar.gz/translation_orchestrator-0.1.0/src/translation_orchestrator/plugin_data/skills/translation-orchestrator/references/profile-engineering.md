---
name: profile-engineering
when_to_use: engineering specifications · architecture docs · incident reports · technical reports · design docs
inputs: [source_file, target_language, system_context]
outputs: [target_document, audit.md, glossary_diff.json, interface_integrity.json]
hc_set: GROUNDING.md
cp_overrides:
  register: engineering-zh
  hedge_preservation: strict
  voice: technical_expository
  numerals: arabic
reviewer_set:
  - faithfulness
  - terminology
  - style
  - coherence
  - citation-structure
verify_before_accept:
  - back_translation
  - hedge_aware_nli
  - structure_round_trip
  - glossary_lint
  - qe_debias_R
  - hc_invariant
  - interface_token_check
iteration_cap: 3
N_candidates: 4
N_agents: 5
topology: moderately_sparse
tau_R: 0.28
C_min: 0.68
human_review_sections: [requirements, safety, rollout, incident_timeline]
---

# Profile: Engineering

Profile for engineering design documents, specifications, incident reports, and technical implementation reports. It prioritizes interface-token integrity, causal-chain faithfulness, and consistent technical terminology.

## Reviewer weights

| Reviewer | Weight | Persona |
|---|---:|---|
| faithfulness | 0.35 | troublemaker |
| terminology | 0.25 | strict |
| style | 0.15 | peacemaker |
| coherence | 0.10 | peacemaker |
| citation-structure | 0.15 | strict (HC veto on code / diagrams / interfaces) |

## Domain-specific HCs

- Code, commands, API names, config keys, environment variables, metric names, and file paths round-trip byte-identical unless explicitly localized by a controlled glossary.
- Causal incident sequences must preserve order, actor, trigger, and mitigation. Do not compress away "possibly / likely / suspected" hedges.
- Requirement keywords such as MUST, SHOULD, MAY, required, optional, deprecated, and experimental preserve normative force.

## CP specializations

- Register: precise engineering Chinese; avoid marketing embellishment and academic over-nominalization.
- Keep interface tokens and protocol names in English when recognizability would otherwise drop.
- Prefer short sentences for procedures and incident timelines.

## Section-type routing hints

| Section type | Notes |
|---|---|
| requirements | Full review; normative keyword preservation is critical. |
| architecture | Full review; diagrams and identifiers are HC10-sensitive. |
| incident_timeline | Coherence reviewer checks temporal ordering. |
| code_block | Structural-only if all content is verbatim. |

## Anchors

- [[llm-agent-translation-system-research-report#Theme-9-Domains-are-runtime-plugins-not-hard-coded-forks]]
