"""score_R.py — compute the per-section R(x) score used by the verify-before-accept gate.

Stub / specification. Reads NLI / QE / alignment outputs from runs/<job-id>/sections/<sec>/
and the reviewer review.json files; emits R.json.

Aggregation (see references/qa-rules.md):
    R(x) = 1
         - sum_i w_i * accept_score_i
         + lambda_hc * I[any_HC_violation]
         + lambda_qe * (1 - QE_debiased)

accept_score_i:
    1.0   if reviewer_i.verdict == "accept"
    0.5   if reviewer_i.verdict == "revise" and no HC issues raised
    0.0   if reviewer_i.verdict == "revise" and any HC issue raised
    None  if reviewer_i.verdict == "escalate"   # caller routes to human queue

Fail-closed:
- Any reviewer's review.json missing → R = +inf (forces reject).
- Any verify-before-accept stage with status "missing" → R = +inf.
- QE_debiased missing → use QE_raw and add a 0.05 degradation penalty.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class RInputs:
    section_id: str
    reviews: dict          # reviewer_name -> review.json dict
    qe_debiased: float | None
    qe_raw: float
    hc_violations: list[str]
    weights: dict          # reviewer_name -> weight from profile
    lambda_hc: float
    lambda_qe: float


def score_R(inputs: RInputs) -> dict:
    """Compute R(x). Returns {'R': float, 'breakdown': {...}, 'fail_closed': bool}.

    Implementation must be deterministic and side-effect-free apart from logging.
    """
    raise NotImplementedError("Bind to numeric backend at install time.")


def is_accept(R: float, tau_R: float, hc_violations: list[str]) -> bool:
    """Final accept predicate: R <= tau_R AND no HC violations."""
    return R <= tau_R and len(hc_violations) == 0
