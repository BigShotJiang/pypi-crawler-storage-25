# translation-orchestrator

Installable package for the `translation-orchestrator` skill and its specialist
translation subagents.

The package mirrors the local packaging style used by `research-pipeline` and
`local-agent-harness`: a Python CLI owns setup, validation, and plugin bundle
generation, while the skill/subagent assets remain plain Markdown/JSON/TOML.

## What it installs

- `skills/translation-orchestrator/` — the full skill bundle.
- `agents/translation-*.agent.md` — specialist subagents.
- optional Copilot-style plugin bundle with `plugin.json`, `.mcp.json`, and
  `start-mcp.sh`.

## CLI

```bash
translation-orchestrator --help
translation-orchestrator validate
translation-orchestrator domains
translation-orchestrator setup --project-root /path/to/repo
translation-orchestrator build-plugin --output dist/copilot-plugin-translation-orchestrator
translation-orchestrator mcp config
```

## Development

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e '.[dev]'
pytest
ruff check .
mypy
python -m build
twine check dist/*
```

## Release outline

1. Update `CHANGELOG.md`.
2. Run `pytest`, `ruff check .`, `mypy`, `python -m build`, and `twine check dist/*`.
3. Create a GitHub release/tag.
4. Publish to PyPI with trusted publishing or a `PYPI_API_TOKEN`.

