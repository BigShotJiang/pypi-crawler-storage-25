"""Chunking strategy implementations."""

from __future__ import annotations

import re

from chunk_bench.models import Chunk


class FixedChunker:
    """Split text into fixed-size chunks by character count."""

    def __init__(self, chunk_size: int = 512, overlap: int = 50):
        self.chunk_size = chunk_size
        self.overlap = overlap

    def chunk(self, text: str) -> list[Chunk]:
        chunks = []
        step = max(1, self.chunk_size - self.overlap)
        i = 0
        idx = 0
        while i < len(text):
            end = min(i + self.chunk_size, len(text))
            chunks.append(
                Chunk(text=text[i:end], index=idx, strategy="fixed", char_start=i, char_end=end)
            )
            i += step
            idx += 1
        return chunks


class SlidingChunker:
    """Sliding window chunker — overlaps more than FixedChunker by design."""

    def __init__(self, window_size: int = 400, step: int = 200):
        self.window_size = window_size
        self.step = step

    def chunk(self, text: str) -> list[Chunk]:
        chunks = []
        i = 0
        idx = 0
        while i < len(text):
            end = min(i + self.window_size, len(text))
            chunks.append(
                Chunk(text=text[i:end], index=idx, strategy="sliding", char_start=i, char_end=end)
            )
            if end == len(text):
                break
            i += self.step
            idx += 1
        return chunks


class ParagraphChunker:
    """Split on paragraph boundaries (double newlines). Merges tiny paragraphs."""

    def __init__(self, min_chars: int = 100, max_chars: int = 2000):
        self.min_chars = min_chars
        self.max_chars = max_chars

    def chunk(self, text: str) -> list[Chunk]:
        raw = re.split(r"\n\s*\n", text.strip())
        merged: list[str] = []
        buffer = ""
        for para in raw:
            para = para.strip()
            if not para:
                continue
            if len(buffer) + len(para) < self.min_chars:
                buffer = (buffer + " " + para).strip()
            elif len(buffer) > self.max_chars:
                if buffer:
                    merged.append(buffer)
                buffer = para
            else:
                if buffer:
                    merged.append(buffer)
                buffer = para
        if buffer:
            merged.append(buffer)

        return [
            Chunk(text=t, index=i, strategy="paragraph") for i, t in enumerate(merged) if t.strip()
        ]


class RecursiveChunker:
    """Recursively split on paragraph → sentence → word boundaries."""

    SEPARATORS = ["\n\n", "\n", ". ", "? ", "! ", "; ", ", ", " ", ""]

    def __init__(self, chunk_size: int = 512, overlap: int = 50):
        self.chunk_size = chunk_size
        self.overlap = overlap

    def chunk(self, text: str) -> list[Chunk]:
        raw = self._split(text, self.SEPARATORS)
        # Merge small pieces, split oversized ones
        chunks: list[str] = []
        buffer = ""
        for piece in raw:
            if len(buffer) + len(piece) <= self.chunk_size:
                buffer = (buffer + " " + piece).strip() if buffer else piece
            else:
                if buffer:
                    chunks.append(buffer)
                buffer = piece

            # Hard split if a single piece is too large
            while len(buffer) > self.chunk_size:
                chunks.append(buffer[: self.chunk_size])
                buffer = buffer[max(0, self.chunk_size - self.overlap) :]

        if buffer:
            chunks.append(buffer)

        return [
            Chunk(text=t, index=i, strategy="recursive") for i, t in enumerate(chunks) if t.strip()
        ]

    def _split(self, text: str, seps: list[str]) -> list[str]:
        if not seps:
            return [text]
        sep = seps[0]
        if sep == "":
            return list(text)
        parts = text.split(sep)
        result = []
        for part in parts:
            if len(part) <= self.chunk_size:
                result.append(part)
            else:
                result.extend(self._split(part, seps[1:]))
        return [p for p in result if p.strip()]


# ── Strategy registry ──────────────────────────────────────────

_CHUNKERS = {
    "fixed": FixedChunker,
    "sliding": SlidingChunker,
    "paragraph": ParagraphChunker,
    "recursive": RecursiveChunker,
}

ALL_STRATEGIES = list(_CHUNKERS.keys())


def chunk(text: str, strategy: str = "recursive", **kwargs) -> list[Chunk]:
    """
    Chunk text with the named strategy.

    Args:
        text:     Text to chunk
        strategy: 'fixed' | 'sliding' | 'paragraph' | 'recursive'
        **kwargs: Passed to the chunker constructor

    Returns:
        List of Chunk objects
    """
    if strategy not in _CHUNKERS:
        raise ValueError(f"Unknown strategy {strategy!r}. Choose: {ALL_STRATEGIES}")
    return _CHUNKERS[strategy](**kwargs).chunk(text)
