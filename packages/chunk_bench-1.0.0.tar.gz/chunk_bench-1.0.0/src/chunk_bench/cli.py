"""chunk-bench CLI."""

import argparse
import json
from pathlib import Path


def main() -> None:
    p = argparse.ArgumentParser(prog="chunk-bench", description="Benchmark RAG chunking strategies")
    p.add_argument("file", help="Text file to benchmark")
    p.add_argument("--queries", "-q", nargs="+", required=True, help="Test queries")
    p.add_argument("--strategies", "-s", nargs="+", default=None, help="Strategies to test")
    p.add_argument("--top-k", type=int, default=5)
    p.add_argument("--chunk-size", type=int, default=512)
    p.add_argument("--overlap", type=int, default=50)
    p.add_argument("--json", action="store_true", dest="json_out")
    args = p.parse_args()

    from chunk_bench import ChunkBench

    text = Path(args.file).read_text(encoding="utf-8")
    bench = ChunkBench()
    report = bench.run(
        text=text,
        queries=args.queries,
        strategies=args.strategies,
        top_k=args.top_k,
        chunk_size=args.chunk_size,
        overlap=args.overlap,
    )

    if args.json_out:
        print(
            json.dumps(
                {
                    "strategies": [
                        {
                            "strategy": s.strategy,
                            "chunks": s.chunk_count,
                            "avg_tokens": s.avg_chunk_tokens,
                            "recall": s.avg_recall,
                            "precision": s.avg_precision,
                            "mrr": s.avg_mrr,
                            "f1": s.f1,
                        }
                        for s in report.strategies
                    ]
                },
                indent=2,
            )
        )
    else:
        print(report.summary_table())


if __name__ == "__main__":
    main()
