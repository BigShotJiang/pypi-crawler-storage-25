"""Main ChunkBench class — runs all strategies and computes metrics."""

from __future__ import annotations

from chunk_bench.chunkers import _CHUNKERS, ALL_STRATEGIES
from chunk_bench.metrics import mean_reciprocal_rank, precision_at_k, recall_at_k, retrieve
from chunk_bench.models import BenchmarkResult, QueryResult, StrategyResult


class ChunkBench:
    """
    Benchmark multiple chunking strategies on your document.

    Example:
        bench = ChunkBench()
        report = bench.run(
            text=long_document,
            queries=["What is RAG?", "How does chunking affect retrieval?"],
            relevant_terms=[["RAG", "retrieval"], ["chunk", "split", "boundary"]],
        )
        print(report.summary_table())
        print("Best recall:", report.best_recall.strategy)
    """

    def run(
        self,
        text: str,
        queries: list[str],
        strategies: list[str] | None = None,
        relevant_terms: list[list[str]] | None = None,
        top_k: int = 5,
        chunk_size: int = 512,
        overlap: int = 50,
    ) -> BenchmarkResult:
        """
        Run benchmark across all specified strategies.

        Args:
            text:           Document text to chunk and retrieve from
            queries:        List of test queries
            strategies:     Strategies to test (default: all)
            relevant_terms: For each query, list of terms a good result should contain.
                            If None, derived automatically from the query words.
            top_k:          Number of chunks to retrieve per query
            chunk_size:     Target chunk size in characters (for size-based strategies)
            overlap:        Overlap between chunks in characters

        Returns:
            BenchmarkResult with per-strategy metrics
        """
        strategies = strategies or ALL_STRATEGIES

        # Auto-derive relevant terms from queries if not provided
        if relevant_terms is None:
            relevant_terms = [q.lower().split() for q in queries]

        assert len(relevant_terms) == len(
            queries
        ), "relevant_terms must have same length as queries"

        results: list[StrategyResult] = []

        for strategy in strategies:
            chunker_cls = _CHUNKERS[strategy]
            # Pass relevant kwargs based on strategy
            if strategy in ("fixed", "recursive"):
                chunker = chunker_cls(chunk_size=chunk_size, overlap=overlap)
            elif strategy == "sliding":
                chunker = chunker_cls(window_size=chunk_size, step=max(1, chunk_size - overlap))
            else:
                chunker = chunker_cls()

            chunks = chunker.chunk(text)
            if not chunks:
                continue

            token_counts = [c.token_count for c in chunks]
            query_results: list[QueryResult] = []

            for query, terms in zip(queries, relevant_terms):
                retrieved, scores = retrieve(query, chunks, top_k=top_k)
                rec = recall_at_k(query, retrieved, terms, k=top_k)
                prec = precision_at_k(query, retrieved, terms, k=top_k)
                mrr = mean_reciprocal_rank(query, retrieved, terms)
                query_results.append(
                    QueryResult(
                        query=query,
                        strategy=strategy,
                        top_k_chunks=retrieved,
                        scores=scores,
                        recall=rec,
                        precision=prec,
                        mrr=mrr,
                    )
                )

            results.append(
                StrategyResult(
                    strategy=strategy,
                    chunk_count=len(chunks),
                    avg_chunk_tokens=round(sum(token_counts) / len(token_counts), 1),
                    min_chunk_tokens=min(token_counts),
                    max_chunk_tokens=max(token_counts),
                    avg_recall=round(sum(r.recall for r in query_results) / len(query_results), 4),
                    avg_precision=round(
                        sum(r.precision for r in query_results) / len(query_results), 4
                    ),
                    avg_mrr=round(sum(r.mrr for r in query_results) / len(query_results), 4),
                    query_results=query_results,
                )
            )

        return BenchmarkResult(
            strategies=results,
            text_length=len(text),
            query_count=len(queries),
            top_k=top_k,
        )
