"""Retrieval metrics for chunk evaluation."""

from __future__ import annotations

import re


def _tokens(text: str) -> set[str]:
    return set(re.findall(r"\b\w+\b", text.lower()))


def _score(query: str, chunk_text: str) -> float:
    """BM25-inspired token overlap score."""
    qt = _tokens(query)
    ct = _tokens(chunk_text)
    if not qt or not ct:
        return 0.0
    overlap = len(qt & ct)
    # Penalise very long chunks (length normalisation)
    length_norm = 1.0 / (1.0 + len(ct) / 200.0)
    return overlap / len(qt) * length_norm


def retrieve(query: str, chunks, top_k: int = 5):
    """Retrieve top-k chunks by token overlap score."""
    scored = [(c, _score(query, c.text)) for c in chunks]
    scored.sort(key=lambda x: x[1], reverse=True)
    top = scored[:top_k]
    return [c for c, _ in top], [s for _, s in top]


def recall_at_k(query: str, retrieved_chunks, relevant_terms: list[str], k: int = 5) -> float:
    """
    Fraction of relevant terms found in top-k retrieved chunks.

    Args:
        query:           The search query
        retrieved_chunks: Chunks returned by retriever
        relevant_terms:  Terms that a good retrieval result should contain
        k:               Number of top chunks to consider
    """
    if not relevant_terms:
        return 1.0
    joined = " ".join(c.text for c in retrieved_chunks[:k]).lower()
    found = sum(1 for term in relevant_terms if term.lower() in joined)
    return round(found / len(relevant_terms), 4)


def precision_at_k(query: str, retrieved_chunks, relevant_terms: list[str], k: int = 5) -> float:
    """
    Fraction of top-k chunks that contain at least one relevant term.
    """
    if not relevant_terms or not retrieved_chunks:
        return 0.0
    relevant_set = {t.lower() for t in relevant_terms}
    hits = sum(
        1 for c in retrieved_chunks[:k] if any(term in c.text.lower() for term in relevant_set)
    )
    return round(hits / min(k, len(retrieved_chunks)), 4)


def mean_reciprocal_rank(query: str, retrieved_chunks, relevant_terms: list[str]) -> float:
    """
    MRR: 1/rank of first chunk containing any relevant term.
    """
    if not relevant_terms:
        return 1.0
    relevant_set = {t.lower() for t in relevant_terms}
    for i, c in enumerate(retrieved_chunks, 1):
        if any(term in c.text.lower() for term in relevant_set):
            return round(1.0 / i, 4)
    return 0.0
