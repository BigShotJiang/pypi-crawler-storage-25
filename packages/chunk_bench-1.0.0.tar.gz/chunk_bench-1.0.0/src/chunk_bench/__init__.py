"""
chunk_bench — benchmark RAG chunking strategies.

Quick start:
    from chunk_bench import ChunkBench

    bench = ChunkBench()
    report = bench.run(
        text="Your long document text here...",
        queries=["What is X?", "How does Y work?"],
        strategies=["fixed", "sliding", "paragraph", "recursive"],
    )
    print(report)
"""

from chunk_bench.benchmarker import ChunkBench
from chunk_bench.chunkers import (
    FixedChunker,
    ParagraphChunker,
    RecursiveChunker,
    SlidingChunker,
    chunk,
)
from chunk_bench.metrics import mean_reciprocal_rank, precision_at_k, recall_at_k
from chunk_bench.models import BenchmarkResult, Chunk, StrategyResult

__version__ = "1.0.0"
__author__ = "Linda Oraegbunam"
__all__ = [
    "ChunkBench",
    "FixedChunker",
    "SlidingChunker",
    "ParagraphChunker",
    "RecursiveChunker",
    "chunk",
    "Chunk",
    "BenchmarkResult",
    "StrategyResult",
    "recall_at_k",
    "precision_at_k",
    "mean_reciprocal_rank",
]
