"""Data models for chunk-bench."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Chunk:
    text: str
    index: int
    strategy: str
    char_start: int = 0
    char_end: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def token_count(self) -> int:
        return max(1, len(self.text) // 4)

    def __len__(self) -> int:
        return len(self.text)

    def __repr__(self) -> str:
        return f"Chunk({self.strategy}, idx={self.index}, ~{self.token_count}t, {self.text[:40]!r})"


@dataclass
class QueryResult:
    query: str
    strategy: str
    top_k_chunks: list[Chunk]
    scores: list[float]
    recall: float
    precision: float
    mrr: float


@dataclass
class StrategyResult:
    strategy: str
    chunk_count: int
    avg_chunk_tokens: float
    min_chunk_tokens: int
    max_chunk_tokens: int
    avg_recall: float
    avg_precision: float
    avg_mrr: float
    query_results: list[QueryResult] = field(default_factory=list)

    @property
    def f1(self) -> float:
        if self.avg_precision + self.avg_recall == 0:
            return 0.0
        return round(
            2 * self.avg_precision * self.avg_recall / (self.avg_precision + self.avg_recall), 4
        )

    def __repr__(self) -> str:
        return (
            f"StrategyResult({self.strategy}, chunks={self.chunk_count}, "
            f"recall={self.avg_recall:.2f}, precision={self.avg_precision:.2f}, "
            f"mrr={self.avg_mrr:.2f})"
        )


@dataclass
class BenchmarkResult:
    strategies: list[StrategyResult]
    text_length: int
    query_count: int
    top_k: int

    @property
    def best_recall(self) -> StrategyResult:
        return max(self.strategies, key=lambda s: s.avg_recall)

    @property
    def best_precision(self) -> StrategyResult:
        return max(self.strategies, key=lambda s: s.avg_precision)

    @property
    def best_mrr(self) -> StrategyResult:
        return max(self.strategies, key=lambda s: s.avg_mrr)

    @property
    def best_f1(self) -> StrategyResult:
        return max(self.strategies, key=lambda s: s.f1)

    def summary_table(self) -> str:
        header = f"\n{'Strategy':<18} {'Chunks':>7} {'Avg Tokens':>11} {'Recall':>8} {'Precision':>10} {'MRR':>7} {'F1':>7}"
        sep = "─" * 72
        rows = [header, sep]
        for s in sorted(self.strategies, key=lambda x: x.avg_recall, reverse=True):
            rows.append(
                f"{s.strategy:<18} {s.chunk_count:>7} {s.avg_chunk_tokens:>11.0f} "
                f"{s.avg_recall:>8.3f} {s.avg_precision:>10.3f} {s.avg_mrr:>7.3f} {s.f1:>7.3f}"
            )
        rows.append(sep)
        best = self.best_recall
        rows.append(f"\n  Best recall:    {best.strategy} ({best.avg_recall:.3f})")
        rows.append(f"  Best F1:        {self.best_f1.strategy} ({self.best_f1.f1:.3f})")
        rows.append(f"  Best MRR:       {self.best_mrr.strategy} ({self.best_mrr.avg_mrr:.3f})\n")
        return "\n".join(rows)

    def __repr__(self) -> str:
        return f"BenchmarkResult({len(self.strategies)} strategies, {self.query_count} queries)"
