"""Tests for chunk-bench. Run: pytest tests/ -v"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

import pytest

from chunk_bench import (
    BenchmarkResult,
    Chunk,
    ChunkBench,
    FixedChunker,
    ParagraphChunker,
    RecursiveChunker,
    SlidingChunker,
    StrategyResult,
    chunk,
    mean_reciprocal_rank,
    precision_at_k,
    recall_at_k,
)

# ── Shared fixture ─────────────────────────────────────────────
LONG_TEXT = """
Retrieval Augmented Generation (RAG) is a technique that combines retrieval systems with language models.

RAG systems first retrieve relevant documents from a knowledge base, then use those documents as context
for the language model to generate an answer. This grounding in retrieved text reduces hallucination.

Chunking is the process of splitting documents into smaller pieces before embedding them.
The chunking strategy significantly affects retrieval quality in RAG pipelines.

Fixed-size chunking splits text at regular character or token intervals with optional overlap.
It is simple to implement but may split sentences or ideas across chunk boundaries.

Sliding window chunking uses overlapping windows to ensure context is preserved across boundaries.
The window slides forward by a step size smaller than the window size, creating overlap.

Paragraph chunking splits on natural paragraph boundaries, preserving semantic coherence.
It works well for structured documents but can produce very variable chunk sizes.

Recursive chunking tries to split on the best available boundary — paragraph first, then
sentence, then word — keeping chunk sizes within a target range.

Semantic chunking uses embedding similarity to detect topic shifts. It is computationally
expensive but produces the most semantically coherent chunks.

The choice of chunking strategy depends on document type, query patterns, and latency budget.
There is no universally best strategy — benchmark on your own corpus.
""".strip() * 3  # triple for length


QUERIES = [
    "What is RAG?",
    "How does chunking affect retrieval?",
    "What is sliding window chunking?",
]
TERMS = [
    ["RAG", "retrieval", "generation"],
    ["chunk", "retrieval", "strategy"],
    ["sliding", "window", "overlap"],
]


# ── Chunk model ────────────────────────────────────────────────


class TestChunkModel:
    def test_token_count_positive(self):
        c = Chunk(text="hello world this is a test", index=0, strategy="fixed")
        assert c.token_count > 0

    def test_len_is_char_length(self):
        c = Chunk(text="hello", index=0, strategy="fixed")
        assert len(c) == 5

    def test_repr(self):
        c = Chunk(text="test text", index=0, strategy="fixed")
        assert "fixed" in repr(c)


# ── FixedChunker ───────────────────────────────────────────────


class TestFixedChunker:
    def test_returns_chunks(self):
        chunks = FixedChunker(chunk_size=200).chunk(LONG_TEXT)
        assert len(chunks) > 0

    def test_all_chunks_are_chunk_instances(self):
        chunks = FixedChunker(chunk_size=200).chunk(LONG_TEXT)
        assert all(isinstance(c, Chunk) for c in chunks)

    def test_chunk_size_respected(self):
        chunks = FixedChunker(chunk_size=100, overlap=0).chunk(LONG_TEXT)
        assert all(len(c.text) <= 100 for c in chunks)

    def test_overlap_produces_more_chunks(self):
        no_overlap = FixedChunker(chunk_size=200, overlap=0).chunk(LONG_TEXT)
        with_overlap = FixedChunker(chunk_size=200, overlap=50).chunk(LONG_TEXT)
        assert len(with_overlap) >= len(no_overlap)

    def test_strategy_label(self):
        chunks = FixedChunker().chunk(LONG_TEXT)
        assert all(c.strategy == "fixed" for c in chunks)

    def test_indices_sequential(self):
        chunks = FixedChunker(chunk_size=200).chunk(LONG_TEXT)
        assert [c.index for c in chunks] == list(range(len(chunks)))

    def test_empty_text(self):
        assert FixedChunker().chunk("") == []


# ── SlidingChunker ─────────────────────────────────────────────


class TestSlidingChunker:
    def test_returns_chunks(self):
        assert len(SlidingChunker().chunk(LONG_TEXT)) > 0

    def test_strategy_label(self):
        chunks = SlidingChunker().chunk(LONG_TEXT)
        assert all(c.strategy == "sliding" for c in chunks)

    def test_window_size_respected(self):
        chunks = SlidingChunker(window_size=300).chunk(LONG_TEXT)
        assert all(len(c.text) <= 300 for c in chunks)

    def test_smaller_step_more_chunks(self):
        big_step = SlidingChunker(window_size=200, step=150).chunk(LONG_TEXT)
        small_step = SlidingChunker(window_size=200, step=50).chunk(LONG_TEXT)
        assert len(small_step) >= len(big_step)


# ── ParagraphChunker ───────────────────────────────────────────


class TestParagraphChunker:
    def test_returns_chunks(self):
        assert len(ParagraphChunker().chunk(LONG_TEXT)) > 0

    def test_strategy_label(self):
        chunks = ParagraphChunker().chunk(LONG_TEXT)
        assert all(c.strategy == "paragraph" for c in chunks)

    def test_respects_min_chars(self):
        chunks = ParagraphChunker(min_chars=50).chunk(LONG_TEXT)
        assert all(len(c.text) >= 50 for c in chunks)

    def test_handles_no_paragraphs(self):
        # Single paragraph — should still produce a chunk
        text = "This is a single paragraph with no double newlines at all."
        chunks = ParagraphChunker(min_chars=10).chunk(text)
        assert len(chunks) >= 1


# ── RecursiveChunker ───────────────────────────────────────────


class TestRecursiveChunker:
    def test_returns_chunks(self):
        assert len(RecursiveChunker().chunk(LONG_TEXT)) > 0

    def test_strategy_label(self):
        chunks = RecursiveChunker().chunk(LONG_TEXT)
        assert all(c.strategy == "recursive" for c in chunks)

    def test_chunk_size_roughly_respected(self):
        chunks = RecursiveChunker(chunk_size=300, overlap=0).chunk(LONG_TEXT)
        # Allow a small tolerance for boundary words
        assert all(len(c.text) <= 350 for c in chunks)

    def test_covers_full_text(self):
        text = "Hello world. This is a test. Final sentence."
        chunks = RecursiveChunker(chunk_size=100).chunk(text)
        joined = " ".join(c.text for c in chunks)
        for word in ["Hello", "test", "Final"]:
            assert word in joined


# ── chunk() convenience function ──────────────────────────────


class TestChunkFunction:
    def test_fixed_strategy(self):
        chunks = chunk(LONG_TEXT, strategy="fixed")
        assert len(chunks) > 0

    def test_sliding_strategy(self):
        assert len(chunk(LONG_TEXT, strategy="sliding")) > 0

    def test_paragraph_strategy(self):
        assert len(chunk(LONG_TEXT, strategy="paragraph")) > 0

    def test_recursive_strategy(self):
        assert len(chunk(LONG_TEXT, strategy="recursive")) > 0

    def test_invalid_strategy_raises(self):
        with pytest.raises(ValueError, match="Unknown strategy"):
            chunk(LONG_TEXT, strategy="nonexistent")


# ── Metrics ────────────────────────────────────────────────────


class TestMetrics:
    @pytest.fixture
    def chunks(self):
        return FixedChunker(chunk_size=200).chunk(LONG_TEXT)

    def test_recall_returns_float(self, chunks):
        r = recall_at_k("What is RAG", chunks, ["RAG", "retrieval"])
        assert 0.0 <= r <= 1.0

    def test_recall_full_terms_present(self, chunks):
        r = recall_at_k("What is RAG", chunks, ["RAG"])
        assert r == 1.0  # "RAG" is definitely in the corpus

    def test_recall_empty_terms(self, chunks):
        assert recall_at_k("query", chunks, []) == 1.0

    def test_precision_returns_float(self, chunks):
        p = precision_at_k("chunking strategy", chunks, ["chunk"])
        assert 0.0 <= p <= 1.0

    def test_mrr_returns_float(self, chunks):
        m = mean_reciprocal_rank("RAG retrieval", chunks, ["RAG"])
        assert 0.0 <= m <= 1.0

    def test_mrr_first_rank_is_one(self):
        # If the first chunk contains the term, MRR = 1.0
        chunks = [
            Chunk(text="RAG stands for Retrieval Augmented Generation", index=0, strategy="test")
        ]
        assert mean_reciprocal_rank("RAG", chunks, ["RAG"]) == 1.0

    def test_mrr_zero_if_not_found(self, chunks):
        m = mean_reciprocal_rank("xyzzy_notaword", chunks, ["xyzzy_notaword_unique"])
        assert m == 0.0


# ── ChunkBench ─────────────────────────────────────────────────


class TestChunkBench:
    @pytest.fixture
    def bench(self):
        return ChunkBench()

    def test_run_returns_benchmark_result(self, bench):
        r = bench.run(LONG_TEXT, QUERIES)
        assert isinstance(r, BenchmarkResult)

    def test_all_strategies_included(self, bench):
        r = bench.run(LONG_TEXT, QUERIES)
        names = {s.strategy for s in r.strategies}
        assert "fixed" in names
        assert "sliding" in names
        assert "paragraph" in names
        assert "recursive" in names

    def test_custom_strategies(self, bench):
        r = bench.run(LONG_TEXT, QUERIES, strategies=["fixed", "recursive"])
        assert len(r.strategies) == 2

    def test_metrics_in_range(self, bench):
        r = bench.run(LONG_TEXT, QUERIES, strategies=["fixed"])
        s = r.strategies[0]
        assert 0.0 <= s.avg_recall <= 1.0
        assert 0.0 <= s.avg_precision <= 1.0
        assert 0.0 <= s.avg_mrr <= 1.0

    def test_f1_in_range(self, bench):
        r = bench.run(LONG_TEXT, QUERIES, strategies=["recursive"])
        assert 0.0 <= r.strategies[0].f1 <= 1.0

    def test_best_recall_is_strategy_result(self, bench):
        r = bench.run(LONG_TEXT, QUERIES)
        assert isinstance(r.best_recall, StrategyResult)

    def test_summary_table_is_string(self, bench):
        r = bench.run(LONG_TEXT, QUERIES)
        table = r.summary_table()
        assert isinstance(table, str)
        assert "Strategy" in table
        assert "Recall" in table

    def test_relevant_terms_provided(self, bench):
        r = bench.run(LONG_TEXT, QUERIES, relevant_terms=TERMS)
        assert len(r.strategies) > 0

    def test_chunk_count_positive(self, bench):
        r = bench.run(LONG_TEXT, QUERIES)
        for s in r.strategies:
            assert s.chunk_count > 0

    def test_avg_tokens_positive(self, bench):
        r = bench.run(LONG_TEXT, QUERIES)
        for s in r.strategies:
            assert s.avg_chunk_tokens > 0

    def test_query_count_recorded(self, bench):
        r = bench.run(LONG_TEXT, QUERIES)
        assert r.query_count == len(QUERIES)

    def test_strategy_result_repr(self, bench):
        r = bench.run(LONG_TEXT, QUERIES, strategies=["fixed"])
        assert "StrategyResult" in repr(r.strategies[0])

    def test_benchmark_result_repr(self, bench):
        r = bench.run(LONG_TEXT, QUERIES)
        assert "BenchmarkResult" in repr(r)

    def test_relevant_terms_length_mismatch_raises(self, bench):
        with pytest.raises(AssertionError):
            bench.run(LONG_TEXT, QUERIES, relevant_terms=[["term"]])
