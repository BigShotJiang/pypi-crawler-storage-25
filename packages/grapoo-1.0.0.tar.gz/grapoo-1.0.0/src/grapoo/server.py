from dotenv import load_dotenv

load_dotenv()

from closepoo import grachat

def main ():
  grachat.run_chat()

if __name__ == '__main__':
  main()
