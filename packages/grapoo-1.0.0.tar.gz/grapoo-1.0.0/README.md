# CLOSEPOO WEB DAEMON USING GRADIO

Detailed tips, tricks, and examples, can be found at project's repository
https://github.com/asinerum/grapoo

"We don't use OpenClaw, because we have ClosePoo, a simple-as-poo AI Agent that makes your time easy and controllable"

## Installation
```bash
pip install grapoo
```

## Start Daemon
```bash
export GEMINI_API_KEY="YOUR_GEMINI_API_KEY"
grapoo
```

## Daemon Web Access
```
http://127.0.0.1:7860
```

(C) 2026 Asinerum Conlang Project