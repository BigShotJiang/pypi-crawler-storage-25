"""Precipitation module: precipitation depth rasters from any source.

For now, only `uniform_precip` (synthetic spatially-flat depth) is exposed —
the consumer (`floodpath.runoff.apply_scs_cn`) doesn't care whether the
precip came from synthetic input, ERA5, IMERG, CHIRPS, or anywhere else.
Future fetchers slot in here.
"""

from .models import PrecipGrid
from .uniform import uniform_precip, uniform_precip_like

__all__ = [
    "PrecipGrid",
    "uniform_precip",
    "uniform_precip_like",
]
