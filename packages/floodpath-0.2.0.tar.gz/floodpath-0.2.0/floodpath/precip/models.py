"""Dataclasses for the precip module."""

from dataclasses import dataclass

import numpy as np
from rasterio.transform import Affine

from floodpath.dem.models import BoundingBox

PRECIP_UNITS: str = "mm (precipitation depth)"


@dataclass
class PrecipGrid:
    """Per-cell precipitation depth (mm) over an event window.

    `values` is `mm` of liquid-equivalent precipitation accumulated over
    the period described by `(start, end)`. Synthetic uniform inputs
    leave the period as `None` (event-agnostic). Real fetchers
    (ERA5/IMERG/CHIRPS) record the actual UTC window.

    `source` is a free-form string identifying where the data came from
    so downstream consumers can attribute / cite — e.g. `"uniform"`,
    `"ERA5"`, `"IMERG-Final"`.
    """

    values: np.ndarray
    transform: Affine
    crs: str
    bbox: BoundingBox
    source: str
    start: str | None = None
    end: str | None = None
    units: str = PRECIP_UNITS

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying raster."""
        return self.values.shape  # type: ignore[return-value]

    def total_volume_m3(self, cell_area_m2: float) -> float:
        """Bulk volume of liquid water over the patch, in m^3.

        Args:
            cell_area_m2: Area of one cell in m^2 (the caller knows their
                grid's cell area; we don't infer it from the WGS84
                transform because that would require a per-cell cosine
                latitude correction).

        Returns:
            Total water volume in cubic metres.
        """
        # mm * m^2 = L, divide by 1000 -> m^3.
        return float(np.nansum(self.values) * cell_area_m2 / 1000.0)
