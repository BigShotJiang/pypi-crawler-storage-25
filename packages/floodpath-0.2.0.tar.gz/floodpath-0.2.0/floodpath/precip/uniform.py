"""Synthetic uniform-depth precipitation grids."""

from typing import Protocol

import numpy as np
from rasterio.transform import Affine

from floodpath.dem.models import BoundingBox

from .models import PrecipGrid


class _Griddable(Protocol):
    """Anything with a `shape`, `transform`, `crs`, `bbox` quartet — every
    floodpath grid dataclass satisfies this."""

    shape: tuple[int, int]
    transform: Affine
    crs: str
    bbox: BoundingBox


def uniform_precip(
    bbox: BoundingBox,
    transform: Affine,
    shape: tuple[int, int],
    depth_mm: float,
    crs: str = "EPSG:4326",
) -> PrecipGrid:
    """Build a spatially-uniform precipitation grid of given depth.

    Useful as the simplest possible input to test the rainfall-runoff
    pipeline before plugging in a real fetcher (ERA5 / IMERG / CHIRPS).

    Args:
        bbox: Geographic bounding box matching the target grid.
        transform: Rasterio Affine transform of the target grid.
        shape: (rows, cols) of the target grid.
        depth_mm: Constant precipitation depth applied to every cell, in mm.
        crs: CRS of the grid; defaults to WGS84.

    Returns:
        PrecipGrid filled with `depth_mm` everywhere.

    Raises:
        ValueError: `depth_mm` is negative.
    """
    if depth_mm < 0:
        raise ValueError(f"depth_mm must be >= 0, got {depth_mm}")
    values = np.full(shape, float(depth_mm), dtype=np.float32)
    return PrecipGrid(
        values=values,
        transform=transform,
        crs=crs,
        bbox=bbox,
        source="uniform",
    )


def uniform_precip_like(
    grid: _Griddable,
    depth_mm: float,
) -> PrecipGrid:
    """Build a uniform PrecipGrid that overlays another grid exactly.

    Convenience wrapper — when you already have a CN/HSG/landuse grid and
    want a precip grid that aligns one-to-one, this avoids passing the
    georef arguments by hand.

    Args:
        grid: Any grid dataclass exposing `shape`, `transform`, `crs`,
            `bbox` (CurveNumberGrid, LanduseGrid, HSGGrid, ...).
        depth_mm: Constant precipitation depth applied everywhere, in mm.

    Returns:
        PrecipGrid sharing the input grid's georef.
    """
    return uniform_precip(
        bbox=grid.bbox,
        transform=grid.transform,
        shape=grid.shape,
        depth_mm=depth_mm,
        crs=grid.crs,
    )
