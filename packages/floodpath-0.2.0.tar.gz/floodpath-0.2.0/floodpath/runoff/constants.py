"""Constants for the runoff module: NEH 630 Ch9 Curve Number tables."""

from types import MappingProxyType

# --- NEH 630 Chapter 9 Table 9-1 -------------------------------------------
#
# Per-cell Curve Numbers depend on (cover_type, hydrologic_condition,
# treatment) AND (Hydrologic Soil Group A/B/C/D). Values below come from
# NEH 630 Ch9 Table 9-1 (Jan 2009 release) for "AMC II" — average
# antecedent moisture condition. AMC I/III are documented adjustments
# that the user can apply on top.
#
# References:
#   USDA NRCS National Engineering Handbook Part 630 Chapter 9
#   "Hydrologic Soil-Cover Complexes" (Jan 2009).
#
# Picked NEH cover types per ESA WorldCover class follow the consensus
# mapping used in SWAT, HEC-HMS, and the global SCS-CN literature:
#
#   WC 10 (tree_cover)          -> Woods, hydrologic condition GOOD
#   WC 20 (shrubland)           -> Brush-grass, condition FAIR
#   WC 30 (grassland)           -> Pasture/grassland, condition GOOD
#   WC 40 (cropland)            -> Row crops, straight row, condition GOOD
#   WC 50 (built_up)            -> Residential 1/4 acre lots
#                                   (suburban average; users with dense
#                                   urban patches should override with
#                                   Commercial: A=89/B=92/C=94/D=95)
#   WC 60 (bare_or_sparse)      -> Fallow, bare soil
#   WC 70 (snow_and_ice)        -> Practical impervious (CN=98)
#   WC 80 (permanent_water)     -> Open water (CN=100; no infiltration)
#   WC 90 (herbaceous_wetland)  -> Wetlands; common practice values
#   WC 95 (mangroves)           -> Wetlands; same as 90
#   WC 100 (moss_and_lichen)    -> Brush, condition FAIR

WORLDCOVER_NEH_CN: MappingProxyType = MappingProxyType({
    10:  MappingProxyType({"A": 30,  "B": 55,  "C": 70,  "D": 77}),
    20:  MappingProxyType({"A": 35,  "B": 56,  "C": 70,  "D": 77}),
    30:  MappingProxyType({"A": 39,  "B": 61,  "C": 74,  "D": 80}),
    40:  MappingProxyType({"A": 67,  "B": 78,  "C": 85,  "D": 89}),
    50:  MappingProxyType({"A": 61,  "B": 75,  "C": 83,  "D": 87}),
    60:  MappingProxyType({"A": 77,  "B": 86,  "C": 91,  "D": 94}),
    70:  MappingProxyType({"A": 98,  "B": 98,  "C": 98,  "D": 98}),
    80:  MappingProxyType({"A": 100, "B": 100, "C": 100, "D": 100}),
    90:  MappingProxyType({"A": 78,  "B": 84,  "C": 88,  "D": 90}),
    95:  MappingProxyType({"A": 78,  "B": 84,  "C": 88,  "D": 90}),
    100: MappingProxyType({"A": 35,  "B": 56,  "C": 70,  "D": 77}),
})

# Per-cell CN range. NEH and most practitioners cap the lower end at ~30
# (Woods, HSG A — anything more permeable than that is artificial).
# CN=100 is the upper cap (open water / fully impervious).
CN_MIN: int = 30
CN_MAX: int = 100

# Default value for cells where either landuse or HSG is nodata, or
# the (landuse, HSG) pair is missing from the mapping. 70 is a typical
# pasture/grassland B middle-of-the-table value — neutral and easy to
# notice when it shows up unexpectedly in a CN map.
CN_DEFAULT_FALLBACK: int = 70

CN_NODATA: int = 0
CN_UNITS: str = "Curve Number (NEH 630 Ch9, AMC II)"
