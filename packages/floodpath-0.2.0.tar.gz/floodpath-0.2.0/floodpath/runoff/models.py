"""Dataclasses for the runoff module."""

from dataclasses import dataclass

import numpy as np
from rasterio.transform import Affine

from floodpath.dem.models import BoundingBox

from .constants import CN_NODATA, CN_UNITS

RUNOFF_UNITS: str = "mm (runoff depth, SCS-CN)"


@dataclass
class CurveNumberGrid:
    """Per-cell SCS Curve Number raster.

    Each cell carries an integer CN in [CN_MIN, CN_MAX]; CN_NODATA (0)
    marks cells where either the landuse or hydrologic-soil-group input
    was missing.

    The Curve Number couples directly to the SCS-CN runoff equation:
        S = 25400/CN - 254          (mm, potential maximum retention)
        Q = (P - 0.2*S)^2 / (P + 0.8*S)  if P > 0.2*S, else 0
    where P is precipitation depth (mm) and Q is runoff depth (mm).
    """

    values: np.ndarray
    transform: Affine
    crs: str
    bbox: BoundingBox
    units: str = CN_UNITS

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying raster."""
        return self.values.shape  # type: ignore[return-value]

    def stats(self) -> dict[str, float]:
        """Return summary statistics over classified cells (CN > 0).

        Cells with CN=0 (nodata) are excluded so a few unmapped pixels
        don't drag the mean down.
        """
        valid = self.values[self.values > 0]
        if valid.size == 0:
            return {"min": 0.0, "max": 0.0, "mean": 0.0, "median": 0.0}
        return {
            "min": float(valid.min()),
            "max": float(valid.max()),
            "mean": float(valid.mean()),
            "median": float(np.median(valid)),
        }

    def potential_retention_mm(self) -> np.ndarray:
        """Return S = 25400/CN - 254 (mm) at every cell.

        S is the potential maximum retention used by the SCS-CN runoff
        equation. Cells with CN=0 (nodata) get NaN. CN=100 (open water,
        fully impervious) gives S=0 — runoff equals precipitation.
        """
        out = np.full(self.values.shape, np.nan, dtype=np.float32)
        mask = self.values > 0
        cn = self.values[mask].astype(np.float32)
        # Clip to avoid division-by-zero blow-up at CN exactly 0; CN_NODATA
        # is already excluded by the mask but be defensive about float math.
        out[mask] = 25400.0 / cn - 254.0
        return out


@dataclass
class RunoffGrid:
    """Per-cell runoff depth Q (mm) from the SCS-CN equation.

    Pair-companion to PrecipGrid. The same grid that carried `mm` of
    rainfall now carries `mm` of effective runoff depth — the share of
    precipitation that doesn't infiltrate. Cells where CN was nodata
    inherit NaN.

    `precip_source` records where the input precipitation came from
    (`"uniform"`, `"ERA5"`, ...) so consumers can attribute results.
    """

    values: np.ndarray
    transform: Affine
    crs: str
    bbox: BoundingBox
    precip_source: str
    units: str = RUNOFF_UNITS

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying raster."""
        return self.values.shape  # type: ignore[return-value]

    def stats(self) -> dict[str, float]:
        """Summary statistics over cells with a finite Q."""
        valid = self.values[~np.isnan(self.values)]
        if valid.size == 0:
            return {"min": 0.0, "max": 0.0, "mean": 0.0, "median": 0.0}
        return {
            "min": float(valid.min()),
            "max": float(valid.max()),
            "mean": float(valid.mean()),
            "median": float(np.median(valid)),
        }
