"""Combine landuse + hydrologic soil group into an SCS Curve Number raster."""

import numpy as np
import rasterio.warp
from rasterio.enums import Resampling

from floodpath.dem.models import BoundingBox
from floodpath.landuse.models import LanduseGrid
from floodpath.soil.constants import HSG_TO_INT
from floodpath.soil.models import HSGGrid

from .constants import (
    CN_DEFAULT_FALLBACK,
    CN_NODATA,
    WORLDCOVER_NEH_CN,
)
from .models import CurveNumberGrid


def _upsample_hsg_to_landuse_grid(
    hsg: HSGGrid,
    landuse: LanduseGrid,
) -> np.ndarray:
    """Project an HSG raster onto the landuse grid via nearest-neighbour.

    HSG is categorical (1=A, 2=B, 3=C, 4=D, 0=nodata) so any resampling
    other than nearest-neighbour would produce meaningless intermediate
    codes. WorldCover (10 m) is much finer than SoilGrids (~250 m), so
    every fine cell inherits its parent coarse cell's HSG.

    Used by `compute_curve_number`. Both grids are assumed to be in the
    same CRS and to overlap geographically (the caller is responsible
    for using the same `lat, lon, buffer_deg` when fetching).
    """
    out = np.zeros(landuse.values.shape, dtype=np.uint8)
    rasterio.warp.reproject(
        source=hsg.values,
        destination=out,
        src_transform=hsg.transform,
        src_crs=hsg.crs,
        dst_transform=landuse.transform,
        dst_crs=landuse.crs,
        resampling=Resampling.nearest,
    )
    return out


def compute_curve_number(
    landuse: LanduseGrid,
    hsg: HSGGrid,
    mapping: dict[int, dict[str, int]] | None = None,
    fallback: int = CN_DEFAULT_FALLBACK,
) -> CurveNumberGrid:
    """Derive a per-cell Curve Number raster from landuse + HSG.

    Each cell's CN is read from `mapping[landuse_code][hsg_letter]`,
    with NEH 630 Ch9 Table 9-1 typical values as the default. Cells
    where either landuse or HSG is nodata, or where the (landuse, HSG)
    pair is missing from the mapping, get `fallback`.

    The output raster shares the landuse grid's resolution and georef.
    HSG (typically ~250 m from SoilGrids) is upsampled to the landuse
    grid (typically 10 m for WorldCover) via nearest-neighbour — every
    landuse cell inherits its parent HSG cell's group.

    Args:
        landuse: Categorical land-cover grid (e.g. `floodpath.landuse`).
        hsg: NEH 630 Ch7 hydrologic-soil-group grid (e.g. `floodpath.soil`).
        mapping: Two-level dict landuse_code -> HSG_letter -> CN. Defaults
            to `WORLDCOVER_NEH_CN` (NEH 630 Ch9 + ESA WorldCover).
        fallback: CN value to use for cells the mapping doesn't cover.
            Defaults to 70 (NEH-typical pasture/grassland B).

    Returns:
        CurveNumberGrid sharing the landuse grid's georef.
    """
    table = WORLDCOVER_NEH_CN if mapping is None else mapping

    hsg_at_lu = _upsample_hsg_to_landuse_grid(hsg, landuse)

    cn = np.full(landuse.values.shape, fallback, dtype=np.uint8)
    # Walk every (landuse_code, HSG_letter) pair in the mapping and
    # apply its CN to the matching cells.
    for lu_code, hsg_to_cn in table.items():
        lu_mask = landuse.values == lu_code
        if not lu_mask.any():
            continue
        for letter, cn_value in hsg_to_cn.items():
            hsg_int = HSG_TO_INT.get(letter)
            if hsg_int is None:
                raise ValueError(
                    f"mapping refers to HSG letter {letter!r} which is not "
                    f"one of A/B/C/D"
                )
            cell_mask = lu_mask & (hsg_at_lu == hsg_int)
            cn[cell_mask] = int(cn_value)

    # Cells where either source is nodata: tag CN as nodata (0). Landuse
    # nodata is implicit (no class code matches). HSG nodata = 0 in the
    # upsampled raster.
    nodata_mask = (hsg_at_lu == 0)
    cn[nodata_mask] = CN_NODATA

    return CurveNumberGrid(
        values=cn,
        transform=landuse.transform,
        crs=landuse.crs,
        bbox=BoundingBox(
            min_lon=landuse.bbox.min_lon,
            min_lat=landuse.bbox.min_lat,
            max_lon=landuse.bbox.max_lon,
            max_lat=landuse.bbox.max_lat,
        ),
    )
