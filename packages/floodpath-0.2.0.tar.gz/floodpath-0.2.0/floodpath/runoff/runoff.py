"""Apply the SCS Curve Number runoff equation to a precip + CN pair."""

import numpy as np

from floodpath.precip.models import PrecipGrid

from .models import CurveNumberGrid, RunoffGrid


def apply_scs_cn(
    cn: CurveNumberGrid,
    precip: PrecipGrid,
    initial_abstraction_ratio: float = 0.2,
) -> RunoffGrid:
    """Compute per-cell runoff depth Q (mm) via the SCS-CN equation.

    For each cell:

        S  = 25400 / CN - 254          (mm, potential maximum retention)
        Ia = lambda * S                (mm, initial abstraction)
        Q  = (P - Ia)^2 / (P - Ia + S) if P > Ia, else 0

    where `lambda` is the initial-abstraction ratio (NEH 630 Ch10 standard
    value: 0.2). Cells with CN nodata propagate NaN.

    Args:
        cn: Curve Number raster (any source).
        precip: Precipitation depth raster, in mm. Must share the CN grid's
            shape (call uniform_precip_like(cn, depth_mm) for the
            simplest case).
        initial_abstraction_ratio: lambda in Ia = lambda * S. Defaults to
            0.2 per NEH 630 Ch10. Some authors recommend 0.05 for newer
            calibrations — pass it explicitly if you want that.

    Returns:
        RunoffGrid with per-cell Q in mm. Same georef as the CN raster.

    Raises:
        ValueError: precip and CN have mismatched shapes.
    """
    if precip.shape != cn.shape:
        raise ValueError(
            f"precip shape {precip.shape} does not match CN shape {cn.shape}; "
            "use uniform_precip_like(cn, depth_mm) or reproject the precip grid."
        )

    S = cn.potential_retention_mm()  # mm; NaN where CN is nodata
    P = precip.values.astype(np.float32)
    Ia = float(initial_abstraction_ratio) * S

    with np.errstate(invalid="ignore", divide="ignore"):
        runoff = np.where(
            P > Ia,
            (P - Ia) ** 2 / (P - Ia + S),
            0.0,
        )

    # Anywhere S is NaN (CN nodata), preserve NaN in Q so downstream
    # consumers can tell unmodelled cells apart from "no runoff".
    runoff = np.where(np.isnan(S), np.nan, runoff)

    return RunoffGrid(
        values=runoff.astype(np.float32),
        transform=cn.transform,
        crs=cn.crs,
        bbox=cn.bbox,
        precip_source=precip.source,
    )
