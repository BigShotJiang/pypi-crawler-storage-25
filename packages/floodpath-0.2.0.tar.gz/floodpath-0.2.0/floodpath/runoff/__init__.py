"""Runoff module: rainfall-runoff parameterisations and (future) routing.

Provides:
  * compute_curve_number(landuse, hsg) -> CurveNumberGrid (NEH 630 Ch9)
  * apply_scs_cn(cn, precip) -> RunoffGrid (the SCS-CN equation itself)

These together turn a precipitation depth raster (any source — synthetic
uniform, ERA5, IMERG, ...) into per-cell runoff depth, ready for routing.
"""

from .constants import (
    CN_DEFAULT_FALLBACK,
    CN_MAX,
    CN_MIN,
    WORLDCOVER_NEH_CN,
)
from .curve_number import compute_curve_number
from .models import CurveNumberGrid, RunoffGrid
from .runoff import apply_scs_cn

__all__ = [
    "CN_DEFAULT_FALLBACK",
    "CN_MAX",
    "CN_MIN",
    "CurveNumberGrid",
    "RunoffGrid",
    "WORLDCOVER_NEH_CN",
    "apply_scs_cn",
    "compute_curve_number",
]
