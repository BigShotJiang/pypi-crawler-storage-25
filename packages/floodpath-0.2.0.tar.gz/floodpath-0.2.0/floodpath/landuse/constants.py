"""Constants for the landuse module."""

from types import MappingProxyType

# --- ESA WorldCover (10 m global land cover, AWS Open Data) ----------------
#
# ESA publishes two annual maps as Cloud-Optimized GeoTIFFs on a public S3
# bucket. Each year ships under its own product version directory.
#
#   v100 -> 2020 release
#   v200 -> 2021 release
#
# Globe is tiled at 3 deg x 3 deg; tile names encode the SW corner.

WORLDCOVER_BASE_URL: str = (
    "https://esa-worldcover.s3.eu-central-1.amazonaws.com"
)
WORLDCOVER_VERSIONS: MappingProxyType = MappingProxyType({
    2020: "v100",
    2021: "v200",
})
WORLDCOVER_AVAILABLE_YEARS: tuple[int, ...] = tuple(WORLDCOVER_VERSIONS.keys())
WORLDCOVER_DEFAULT_YEAR: int = 2021

WORLDCOVER_TILE_DEG: int = 3
WORLDCOVER_BUFFER_DEG: float = 0.1
WORLDCOVER_CRS: str = "EPSG:4326"
WORLDCOVER_NODATA: int = 0
WORLDCOVER_UNITS: str = "ESA WorldCover class code"

# Classes from the ESA WorldCover 2021 v200 product user manual.
# 2020 v100 uses the same set minus class 95 (Mangroves) at the original
# release; the per-cell codes themselves are stable.
WORLDCOVER_CLASSES: MappingProxyType = MappingProxyType({
    10: "tree_cover",
    20: "shrubland",
    30: "grassland",
    40: "cropland",
    50: "built_up",
    60: "bare_or_sparse_vegetation",
    70: "snow_and_ice",
    80: "permanent_water_bodies",
    90: "herbaceous_wetland",
    95: "mangroves",
    100: "moss_and_lichen",
})
