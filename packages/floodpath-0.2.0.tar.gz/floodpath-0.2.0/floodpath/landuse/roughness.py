"""Map ESA WorldCover land-cover classes to Manning's roughness coefficient n.

This is a pure transformation of a categorical landuse raster into a
continuous roughness raster. Default values come from Chow 1959 Table 5-6
('Open-channel hydraulics', floodplain values) cross-checked against
USACE EM 1110-2-1417 and FEMA flood-mapping guidance — i.e. n suitable
for floodplain/channel routing, not overland-flow runoff (the latter
takes much higher n; see Kalyanapu et al. 2009).

Users with site-calibrated values should pass a custom mapping to
`landuse_to_roughness`.
"""

from dataclasses import dataclass
from types import MappingProxyType

import numpy as np
from rasterio.transform import Affine

from floodpath.dem.models import BoundingBox

from .models import LanduseGrid

# Manning's n by ESA WorldCover class code (s/m^(1/3)).
# Channel/floodplain values from Chow 1959 Table 5-6, USACE EM 1110-2-1417.
WORLDCOVER_MANNING_N: MappingProxyType = MappingProxyType({
    10: 0.150,    # tree_cover                — dense forest with undergrowth
    20: 0.080,    # shrubland                 — scattered brush, heavy weeds
    30: 0.035,    # grassland                 — short grass / pasture
    40: 0.040,    # cropland                  — cultivated, mature row crops
    50: 0.060,    # built_up                  — mixed urban
    60: 0.025,    # bare_or_sparse_vegetation — bare earth
    70: 0.030,    # snow_and_ice              — smooth surface
    80: 0.025,    # permanent_water_bodies    — open water
    90: 0.080,    # herbaceous_wetland        — emergent wetland
    95: 0.100,    # mangroves                 — woody wetland with roots
    100: 0.030,   # moss_and_lichen
})

ROUGHNESS_UNITS: str = "Manning's n (s/m^(1/3))"


@dataclass
class RoughnessGrid:
    """Per-cell Manning's roughness coefficient n.

    `values` carries the dimensionless n at each cell; `mapping` records
    which class-to-n table was used so downstream consumers (e.g. a
    Manning normal-depth solver) can introspect the assumptions. `fallback`
    is the n value applied to landuse codes absent from `mapping`,
    including the WorldCover nodata value (0).
    """

    values: np.ndarray
    transform: Affine
    crs: str
    bbox: BoundingBox
    mapping: dict[int, float]
    fallback: float
    units: str = ROUGHNESS_UNITS

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying raster."""
        return self.values.shape  # type: ignore[return-value]

    def stats(self) -> dict[str, float]:
        """Return summary statistics (min, max, mean, median) of n."""
        return {
            "min": float(self.values.min()),
            "max": float(self.values.max()),
            "mean": float(self.values.mean()),
            "median": float(np.median(self.values)),
        }


def landuse_to_roughness(
    landuse: LanduseGrid,
    mapping: dict[int, float] | None = None,
    fallback: float = 0.035,
) -> RoughnessGrid:
    """Convert a categorical landuse raster to a Manning's roughness raster.

    Each cell's class code is looked up in `mapping`; codes absent from
    the mapping (including WorldCover nodata=0) get `fallback`.

    Args:
        landuse: Categorical land-cover grid (e.g. ESA WorldCover).
        mapping: Class-code -> Manning's n. Defaults to WORLDCOVER_MANNING_N
            (Chow 1959 / USACE-aligned floodplain values).
        fallback: n applied to codes not present in `mapping`. Defaults to
            0.035 (cropland-like, a reasonable middle of the floodplain
            range when nothing else is known).

    Returns:
        RoughnessGrid sharing georef with the input landuse grid.
    """
    table: dict[int, float] = (
        dict(WORLDCOVER_MANNING_N) if mapping is None else dict(mapping)
    )
    n_values = np.full(landuse.values.shape, float(fallback), dtype=np.float32)
    for code, n in table.items():
        n_values[landuse.values == code] = float(n)

    return RoughnessGrid(
        values=n_values,
        transform=landuse.transform,
        crs=landuse.crs,
        bbox=landuse.bbox,
        mapping=table,
        fallback=float(fallback),
    )
