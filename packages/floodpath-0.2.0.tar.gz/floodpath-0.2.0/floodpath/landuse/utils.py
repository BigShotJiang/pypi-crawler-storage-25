"""Pure helper functions for ESA WorldCover tile addressing."""

import math

from floodpath.dem.models import BoundingBox

from .constants import (
    WORLDCOVER_BASE_URL,
    WORLDCOVER_TILE_DEG,
    WORLDCOVER_VERSIONS,
)


def worldcover_tile_id(
    lat: float,
    lon: float,
) -> tuple[int, int]:
    """Return the SW-corner (lat, lon) of the 3x3 deg WorldCover tile containing the point.

    ESA WorldCover tiles align to multiples of 3 degrees and are named by
    their southwest corner. For example, (lat=11.8, lon=37.5) lies in the
    tile rooted at (9, 36) -> "N09E036", covering [9, 12)N x [36, 39)E.

    Args:
        lat: Latitude in decimal degrees.
        lon: Longitude in decimal degrees.

    Returns:
        Tuple `(lat_sw, lon_sw)` snapped down to the nearest 3-degree multiple.
    """
    lat_sw = int(math.floor(lat / WORLDCOVER_TILE_DEG) * WORLDCOVER_TILE_DEG)
    lon_sw = int(math.floor(lon / WORLDCOVER_TILE_DEG) * WORLDCOVER_TILE_DEG)
    return lat_sw, lon_sw


def tiles_for_bbox(bbox: BoundingBox) -> list[tuple[int, int]]:
    """Enumerate the WorldCover 3x3 deg tile SW-corners covering a bbox.

    Walks every interior tile between the bbox corners — a bbox spanning
    more than two tiles in either dimension must include the interior
    tiles too.

    Args:
        bbox: Geographic bounding box in WGS84.

    Returns:
        List of `(lat_sw, lon_sw)` tile corners snapped to 3-degree multiples.
    """
    lat_sw_min, lon_sw_min = worldcover_tile_id(bbox.min_lat, bbox.min_lon)
    lat_sw_max, lon_sw_max = worldcover_tile_id(bbox.max_lat, bbox.max_lon)

    # When a bbox edge sits exactly on a tile boundary, the max corner is the
    # next tile up — exclude it.
    if bbox.max_lat == lat_sw_max and lat_sw_max > lat_sw_min:
        lat_sw_max -= WORLDCOVER_TILE_DEG
    if bbox.max_lon == lon_sw_max and lon_sw_max > lon_sw_min:
        lon_sw_max -= WORLDCOVER_TILE_DEG

    return [
        (lat, lon)
        for lat in range(lat_sw_min, lat_sw_max + 1, WORLDCOVER_TILE_DEG)
        for lon in range(lon_sw_min, lon_sw_max + 1, WORLDCOVER_TILE_DEG)
    ]


def worldcover_tile_name(
    lat_sw: int,
    lon_sw: int,
) -> str:
    """Build the ESA WorldCover tile name from a SW-corner.

    Tiles are named like 'N09E036' or 'S12W045': two-digit zero-padded
    latitude, three-digit zero-padded longitude, with hemispheric letters.
    """
    ns = "N" if lat_sw >= 0 else "S"
    ew = "E" if lon_sw >= 0 else "W"
    return f"{ns}{abs(lat_sw):02d}{ew}{abs(lon_sw):03d}"


def worldcover_tile_url(
    lat_sw: int,
    lon_sw: int,
    year: int,
) -> str:
    """Build the public HTTPS URL for an ESA WorldCover tile COG."""
    if year not in WORLDCOVER_VERSIONS:
        raise ValueError(
            f"year must be one of {tuple(WORLDCOVER_VERSIONS.keys())}, got {year}"
        )
    version = WORLDCOVER_VERSIONS[year]
    tile = worldcover_tile_name(lat_sw, lon_sw)
    return (
        f"{WORLDCOVER_BASE_URL}/{version}/{year}/map/"
        f"ESA_WorldCover_10m_{year}_{version}_{tile}_Map.tif"
    )
