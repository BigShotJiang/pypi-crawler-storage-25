"""Fetch ESA WorldCover 10 m land-cover patches by streaming COGs over HTTPS."""

import rasterio
from rasterio.env import Env
from rasterio.errors import RasterioIOError
from rasterio.merge import merge

from floodpath.dem.constants import GDAL_VSICURL_ENV
from floodpath.dem.models import BoundingBox
from floodpath.dem.utils import bbox_from_point

from .constants import (
    WORLDCOVER_AVAILABLE_YEARS,
    WORLDCOVER_BUFFER_DEG,
    WORLDCOVER_CLASSES,
    WORLDCOVER_CRS,
    WORLDCOVER_DEFAULT_YEAR,
    WORLDCOVER_UNITS,
)
from .models import LanduseGrid
from .utils import tiles_for_bbox, worldcover_tile_url


def get_worldcover_landuse(
    lat: float,
    lon: float,
    buffer_deg: float = WORLDCOVER_BUFFER_DEG,
    year: int = WORLDCOVER_DEFAULT_YEAR,
) -> LanduseGrid:
    """Return ESA WorldCover land-cover classes for the bbox around a point.

    ESA WorldCover ships as Cloud-Optimized GeoTIFFs on AWS Open Data
    (eu-central-1). The bucket honours HTTP range requests, so this reads
    only the bbox window via GDAL's /vsicurl/ driver — no full tile
    download. Each tile is 3 deg x 3 deg at 10 m (~36k x 36k cells), so
    streaming is meaningfully cheaper than caching.

    Args:
        lat: Latitude of the region center, decimal degrees.
        lon: Longitude of the region center, decimal degrees.
        buffer_deg: Half-width of the square bbox around the point, degrees.
        year: 2020 (v100) or 2021 (v200). Defaults to 2021.

    Returns:
        LanduseGrid with per-cell class codes, georef, and the active
        class-name mapping.

    Raises:
        ValueError: `year` is not one of the available WorldCover releases.
        FileNotFoundError: No WorldCover tile covers the requested bbox
            (e.g. fully oceanic bboxes outside ESA's land mask).
    """
    if year not in WORLDCOVER_AVAILABLE_YEARS:
        raise ValueError(
            f"year must be one of {WORLDCOVER_AVAILABLE_YEARS}, got {year}"
        )

    bbox = bbox_from_point(lat, lon, buffer_deg)
    tile_corners = tiles_for_bbox(bbox)
    urls = [worldcover_tile_url(lat_sw, lon_sw, year=year) for lat_sw, lon_sw in tile_corners]

    with Env(**GDAL_VSICURL_ENV):
        datasets = []
        try:
            for url in urls:
                try:
                    datasets.append(rasterio.open(f"/vsicurl/{url}"))
                except RasterioIOError:
                    # Fully oceanic tiles are absent from the bucket.
                    continue

            if not datasets:
                raise FileNotFoundError(
                    f"No WorldCover {year} tiles found for bbox {bbox.bounds}. "
                    "The region may be ocean or outside ESA's land mask."
                )

            values, transform = merge(datasets, bounds=bbox.bounds)
        finally:
            for ds in datasets:
                ds.close()

    return LanduseGrid(
        values=values[0],
        transform=transform,
        crs=WORLDCOVER_CRS,
        bbox=BoundingBox(*bbox.bounds),
        epoch=year,
        classes=dict(WORLDCOVER_CLASSES),
        units=WORLDCOVER_UNITS,
    )
