"""Dataclasses for the landuse module."""

from dataclasses import dataclass

import numpy as np
from rasterio.transform import Affine

from floodpath.dem.models import BoundingBox

from .constants import WORLDCOVER_CLASSES


@dataclass
class LanduseGrid:
    """A categorical land-cover raster clipped to a bbox.

    `values` carries per-cell class codes (uint8) drawn from a discrete
    code-to-name mapping (e.g. WORLDCOVER_CLASSES). `epoch` is the year of
    the source product. Use `class_counts()` to summarise composition; use
    the `classes` mapping to translate codes to human-readable names.
    """

    values: np.ndarray
    transform: Affine
    crs: str
    bbox: BoundingBox
    epoch: int
    classes: dict[int, str]
    units: str

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying raster."""
        return self.values.shape  # type: ignore[return-value]

    def class_counts(self) -> dict[int, int]:
        """Count cells per class code present in the grid.

        Returns:
            Mapping from class code to cell count. Codes absent from the
            grid are omitted.
        """
        codes, counts = np.unique(self.values, return_counts=True)
        return {int(c): int(n) for c, n in zip(codes, counts)}

    def class_name(self, code: int) -> str:
        """Return the human-readable name for a class code, or 'unknown'."""
        return self.classes.get(code, "unknown")

    def fraction(self, code: int) -> float:
        """Return the fraction of cells with the given class code."""
        if self.values.size == 0:
            return 0.0
        return float(np.count_nonzero(self.values == code) / self.values.size)


# Re-export so callers can do `from floodpath.landuse import WORLDCOVER_CLASSES`
# while also seeing it through the dataclass `classes` field.
__all__ = ["LanduseGrid", "WORLDCOVER_CLASSES"]
