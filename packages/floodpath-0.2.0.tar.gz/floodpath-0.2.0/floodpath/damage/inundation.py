"""Convert HAND + a static water level into a per-cell water-depth raster."""

import numpy as np

from floodpath.hydrology.models import Hand

from .models import InundationDepth


def compute_inundation_depth(
    hand: Hand,
    water_level: float,
) -> InundationDepth:
    """Return per-cell water depth (m) at a static water level.

    For each cell, depth = max(0, water_level - HAND). Cells with
    nodata HAND (negative sentinel from pyflwdir if present) are treated
    as dry — they have no defined relationship to drainage.

    Args:
        hand: HAND raster from `hydrology.compute_hand`.
        water_level: Water surface elevation above the drainage network,
            in metres. Must be >= 0.

    Returns:
        InundationDepth carrying the per-cell depth array and the scenario
        water level.

    Raises:
        ValueError: water_level is negative.
    """
    if water_level < 0:
        raise ValueError(f"water_level must be >= 0, got {water_level}")
    valid = hand.values >= 0
    depth = np.where(valid, water_level - hand.values, 0.0)
    depth = np.maximum(depth, 0.0)
    return InundationDepth(
        values=depth,
        transform=hand.transform,
        crs=hand.crs,
        bbox=hand.bbox,
        water_level=water_level,
    )
