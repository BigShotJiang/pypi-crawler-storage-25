"""Dataclasses for the damage module."""

from dataclasses import dataclass

import numpy as np
from rasterio.transform import Affine

from floodpath.dem.models import BoundingBox


@dataclass
class InundationDepth:
    """Per-cell water depth for a static flood scenario, in metres.

    Cells with depth <= 0 are dry. The water_level field records the
    scenario height above the drainage network (the value that was
    subtracted from HAND).
    """

    values: np.ndarray
    transform: Affine
    crs: str
    bbox: BoundingBox
    water_level: float

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying raster."""
        return self.values.shape  # type: ignore[return-value]


@dataclass
class DamageMap:
    """Per-cell flood damage raster with metadata about how it was produced.

    `values` carries the per-cell damage in the unit reported by `units`
    (typically m^2 of damaged built-up surface). `water_level`, `scenario`,
    and `curve_name` document the input assumptions so two DamageMaps can
    be compared without ambiguity.

    For static-flood scenarios `water_level` is the scalar input that drove
    the inundation; for rainfall-driven scenarios it's the maximum
    per-cell depth observed (a useful one-number summary even when the
    field varies spatially), and `scenario` records the precip source,
    event duration, and hydraulic method.
    """

    values: np.ndarray
    transform: Affine
    crs: str
    bbox: BoundingBox
    water_level: float
    curve_name: str
    units: str
    scenario: str = "static"

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying raster."""
        return self.values.shape  # type: ignore[return-value]
