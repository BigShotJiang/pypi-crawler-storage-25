"""Combine inundation depth + exposure + depth-damage curve -> DamageMap."""

from typing import Union

import numpy as np

from floodpath.exposure.models import ExposureGrid
from floodpath.routing.flood import RainfallInundationDepth

from .constants import RATIO_TOLERANCE
from .curves import DepthDamageCurve
from .models import DamageMap, InundationDepth

InundationLike = Union[InundationDepth, RainfallInundationDepth]


def _upsample_preserving_total(
    values: np.ndarray,
    factor: int,
) -> np.ndarray:
    """Upsample by an integer factor while preserving the total sum.

    Each input cell is replicated into a `factor x factor` block of output
    cells, with each replicated value divided by `factor**2` so the sum
    over the block equals the original cell value. Nearest-neighbour
    upsampling without this division would multiply totals by `factor**2`,
    which is wrong for absolute-quantity rasters like GHSL m^2/cell.
    """
    expanded = np.repeat(np.repeat(values, factor, axis=0), factor, axis=1)
    return expanded / float(factor * factor)


def compute_damage(
    depth: InundationLike,
    exposure: ExposureGrid,
    curve: DepthDamageCurve,
) -> DamageMap:
    """Compute per-cell flood damage on the depth raster's grid.

    The depth grid (typically DEM/HAND at ~30 m) is finer than the GHSL
    exposure grid (~90 m). We upsample exposure into the depth grid by
    replicating each cell into a 3 x 3 block and dividing by 9 so total
    built-up area is preserved. Per-cell damage =
    depth_damage_fraction(depth) * upsampled_built_up_area.

    Accepts either:
      * `InundationDepth` from `compute_inundation_depth(hand, water_level=L)`
        (static scenario, single user-supplied L); produces
        `scenario = "static water level L m"`.
      * `RainfallInundationDepth` from `compute_rainfall_inundation(...)`
        (rainfall-driven, per-cell water depth varies with the upstream
        Manning solution); produces a scenario string capturing the
        precip source, event duration, and hydraulic method, with
        `water_level` set to the per-cell maximum depth as a scalar
        summary.

    Args:
        depth: Either kind of inundation depth grid.
        exposure: ExposureGrid carrying the per-cell built-up surface (m^2).
        curve: Depth-damage curve to apply (e.g. JRC_AFRICA_RESIDENTIAL).

    Returns:
        DamageMap on the depth grid; values in the same unit as exposure
        (m^2 of damaged built-up surface per depth cell).

    Raises:
        ValueError: The depth and exposure grids cannot be aligned by an
            integer upsampling factor.
    """
    if any(
        abs(d - e) > RATIO_TOLERANCE
        for d, e in zip(depth.bbox.bounds, exposure.bbox.bounds)
    ):
        raise ValueError(
            f"depth and exposure cover different geographic regions: "
            f"depth.bbox={depth.bbox.bounds} vs exposure.bbox={exposure.bbox.bounds}. "
            "Both rasters must be fetched for the same lat/lon/buffer."
        )

    rows_depth, cols_depth = depth.shape
    rows_exp, cols_exp = exposure.shape

    ratio_y = rows_depth / rows_exp
    ratio_x = cols_depth / cols_exp
    if abs(ratio_y - ratio_x) > RATIO_TOLERANCE:
        raise ValueError(
            f"depth and exposure grids have different aspect ratios "
            f"({ratio_y} vs {ratio_x}); both must scale by the same integer."
        )
    factor = int(round(ratio_y))
    if abs(ratio_y - factor) > RATIO_TOLERANCE or factor < 1:
        raise ValueError(
            f"depth/exposure shape ratio must be a positive integer; got {ratio_y}"
        )

    if factor == 1:
        upsampled_exposure = exposure.values.astype(np.float64)
    else:
        upsampled_exposure = _upsample_preserving_total(
            exposure.values.astype(np.float64),
            factor=factor,
        )

    damage_fraction = curve(depth.values)
    damage_values = damage_fraction * upsampled_exposure

    # Scenario metadata: differs between static and rainfall-driven inputs.
    if isinstance(depth, RainfallInundationDepth):
        # Use the per-cell max depth as a one-number summary so DamageMaps
        # remain comparable via `water_level`.
        scenario_water_level = float(depth.values.max())
        scenario = (
            f"rainfall-driven ({depth.discharge_source}, "
            f"T={depth.duration_s / 3600:.1f} hr, {depth.method})"
        )
    else:
        scenario_water_level = depth.water_level
        scenario = f"static water level {depth.water_level:.2f} m"

    return DamageMap(
        values=damage_values,
        transform=depth.transform,
        crs=depth.crs,
        bbox=depth.bbox,
        water_level=scenario_water_level,
        curve_name=curve.name,
        units=f"damaged {exposure.units}",
        scenario=scenario,
    )
