"""JRC Huizinga 2017 depth-damage curves: 26 curves across 6 asset classes.

Source: Huizinga, J., de Moel, H. and Szewczyk, W. (2017).
'Global flood depth-damage functions: Methodology and the database with
guidelines.' EUR 28552 EN, Luxembourg: Publications Office of the
European Union. doi: 10.2760/16510. Curve values come from the
accompanying database file (XLSX, "Damage functions" sheet) — the
underlying source of the rounded values shown in the PDF tables.

Curves are sampled at nine reference depths from 0 to 6 m. Depths in
between are linearly interpolated by `DepthDamageCurve.__call__`; depths
above 6 m are clamped to the final value (typically 1.0).

Coverage is sparse for some (class, continent) pairs because the JRC
authors did not have source data for all combinations. `jrc_curve` raises
KeyError for missing combinations.
"""

from dataclasses import dataclass

import numpy as np

JRC_DEPTHS_M: tuple[float, ...] = (0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 5.0, 6.0)

JRC_ASSET_CLASSES: tuple[str, ...] = (
    "residential",
    "commerce",
    "industry",
    "transport",
    "infrastructure",
    "agriculture",
)

JRC_CONTINENTS: tuple[str, ...] = (
    "africa",
    "asia",
    "europe",
    "north_america",
    "oceania",
    "south_america",
)


@dataclass(frozen=True)
class DepthDamageCurve:
    """A monotone non-decreasing depth-damage lookup.

    The curve is sampled at `depths_m`; in between, `__call__` returns a
    linearly interpolated damage fraction. Depths below the first sample
    are clamped to its damage value (typically 0); depths above the last
    sample are clamped to its damage value (typically 1).
    """

    name: str
    asset_class: str
    depths_m: tuple[float, ...]
    damage_fractions: tuple[float, ...]

    def __post_init__(self) -> None:
        if len(self.depths_m) != len(self.damage_fractions):
            raise ValueError(
                "depths_m and damage_fractions must have the same length"
            )
        if any(
            self.depths_m[i] >= self.depths_m[i + 1]
            for i in range(len(self.depths_m) - 1)
        ):
            raise ValueError("depths_m must be strictly increasing")
        if any(
            self.damage_fractions[i] > self.damage_fractions[i + 1]
            for i in range(len(self.damage_fractions) - 1)
        ):
            raise ValueError("damage_fractions must be non-decreasing")

    def __call__(
        self,
        depth: np.ndarray,
    ) -> np.ndarray:
        """Linearly interpolate the damage fraction for each depth."""
        return np.interp(
            depth,
            self.depths_m,
            self.damage_fractions,
            left=self.damage_fractions[0],
            right=self.damage_fractions[-1],
        )


# Continental average damage fractions for the nine JRC reference depths,
# rounded to two decimals from the JRC R2017 database. Empty entries (None)
# mark (class, continent) combinations the JRC authors did not have data for.
_JRC_FRACTIONS: dict[tuple[str, str], tuple[float, ...]] = {
    # Residential — full coverage (all 6 continents).
    ("residential", "europe"):        (0.00, 0.25, 0.40, 0.50, 0.60, 0.75, 0.85, 0.95, 1.00),
    ("residential", "north_america"): (0.20, 0.44, 0.58, 0.68, 0.78, 0.85, 0.92, 0.96, 1.00),
    ("residential", "south_america"): (0.00, 0.49, 0.71, 0.84, 0.95, 0.98, 1.00, 1.00, 1.00),
    ("residential", "asia"):          (0.00, 0.33, 0.49, 0.62, 0.72, 0.87, 0.93, 0.98, 1.00),
    ("residential", "africa"):        (0.00, 0.22, 0.38, 0.53, 0.64, 0.82, 0.90, 0.96, 1.00),
    ("residential", "oceania"):       (0.00, 0.48, 0.64, 0.71, 0.79, 0.93, 0.97, 0.98, 1.00),

    # Commerce — Africa missing.
    ("commerce", "europe"):           (0.00, 0.15, 0.30, 0.45, 0.55, 0.75, 0.90, 1.00, 1.00),
    ("commerce", "north_america"):    (0.02, 0.24, 0.37, 0.47, 0.55, 0.69, 0.82, 0.91, 1.00),
    ("commerce", "south_america"):    (0.00, 0.61, 0.84, 0.92, 0.99, 1.00, 1.00, 1.00, 1.00),
    ("commerce", "asia"):             (0.00, 0.38, 0.54, 0.66, 0.76, 0.88, 0.94, 0.98, 1.00),
    ("commerce", "oceania"):          (0.00, 0.24, 0.48, 0.67, 0.86, 1.00, 1.00, 1.00, 1.00),

    # Industry — Oceania missing.
    ("industry", "europe"):           (0.00, 0.15, 0.27, 0.40, 0.52, 0.70, 0.85, 1.00, 1.00),
    ("industry", "north_america"):    (0.03, 0.32, 0.51, 0.64, 0.74, 0.86, 0.94, 0.98, 1.00),
    ("industry", "south_america"):    (0.00, 0.67, 0.89, 0.95, 1.00, 1.00, 1.00, 1.00, 1.00),
    ("industry", "asia"):             (0.00, 0.28, 0.48, 0.63, 0.72, 0.86, 0.91, 0.96, 1.00),
    ("industry", "africa"):           (0.00, 0.06, 0.25, 0.40, 0.49, 0.68, 0.92, 1.00, 1.00),

    # Transport — only Europe, Asia, South America have data.
    ("transport", "europe"):          (0.00, 0.32, 0.54, 0.70, 0.83, 1.00, 1.00, 1.00, 1.00),
    ("transport", "south_america"):   (0.00, 0.09, 0.18, 0.60, 0.84, 1.00, 1.00, 1.00, 1.00),
    ("transport", "asia"):            (0.00, 0.36, 0.57, 0.73, 0.85, 1.00, 1.00, 1.00, 1.00),

    # Infrastructure (roads) — only Europe, Asia. Note units are damage per
    # *metre* of road for these two; downstream consumers must respect that
    # when multiplying against an exposure raster.
    ("infrastructure", "europe"):     (0.00, 0.25, 0.42, 0.55, 0.65, 0.80, 0.90, 1.00, 1.00),
    ("infrastructure", "asia"):       (0.00, 0.21, 0.37, 0.60, 0.71, 0.81, 0.89, 0.97, 1.00),

    # Agriculture — South America and Oceania missing.
    ("agriculture", "europe"):        (0.00, 0.30, 0.55, 0.65, 0.75, 0.85, 0.95, 1.00, 1.00),
    ("agriculture", "north_america"): (0.02, 0.27, 0.47, 0.55, 0.60, 0.76, 0.87, 0.95, 1.00),
    ("agriculture", "asia"):          (0.00, 0.14, 0.37, 0.52, 0.56, 0.66, 0.83, 0.99, 1.00),
    ("agriculture", "africa"):        (0.00, 0.24, 0.47, 0.74, 0.92, 1.00, 1.00, 1.00, 1.00),
}


def _make_curve(
    asset_class: str,
    continent: str,
    fractions: tuple[float, ...],
) -> DepthDamageCurve:
    pretty_continent = continent.replace("_", " ").title()
    return DepthDamageCurve(
        name=f"JRC Huizinga 2017 - {pretty_continent} {asset_class}",
        asset_class=asset_class,
        depths_m=JRC_DEPTHS_M,
        damage_fractions=fractions,
    )


JRC_CURVES: dict[tuple[str, str], DepthDamageCurve] = {
    key: _make_curve(asset_class=key[0], continent=key[1], fractions=fractions)
    for key, fractions in _JRC_FRACTIONS.items()
}


def jrc_curve(
    asset_class: str,
    continent: str,
) -> DepthDamageCurve:
    """Return the JRC R2017 curve for a given asset class and continent.

    Args:
        asset_class: One of `JRC_ASSET_CLASSES` (lowercased on lookup).
        continent: One of `JRC_CONTINENTS` (lowercased on lookup; use
            `north_america` / `south_america` for the Americas).

    Returns:
        The matching DepthDamageCurve.

    Raises:
        KeyError: The (asset_class, continent) combination has no published
            JRC curve.
    """
    key = (asset_class.lower(), continent.lower())
    if key not in JRC_CURVES:
        available = sorted(c for (a, c) in JRC_CURVES if a == key[0])
        raise KeyError(
            f"No JRC curve for asset_class={asset_class!r}, continent={continent!r}. "
            f"Continents with data for {asset_class!r}: {available}."
        )
    return JRC_CURVES[key]


# Convenience constants for the residential curves (the most common entry
# point) and the three already exported by earlier versions of this module.
JRC_AFRICA_RESIDENTIAL = JRC_CURVES[("residential", "africa")]
JRC_ASIA_RESIDENTIAL = JRC_CURVES[("residential", "asia")]
JRC_OCEANIA_RESIDENTIAL = JRC_CURVES[("residential", "oceania")]
JRC_EUROPE_RESIDENTIAL = JRC_CURVES[("residential", "europe")]
JRC_NORTH_AMERICA_RESIDENTIAL = JRC_CURVES[("residential", "north_america")]
JRC_SOUTH_AMERICA_RESIDENTIAL = JRC_CURVES[("residential", "south_america")]
