"""Constants for the damage module."""

# When aligning the depth grid (typically the DEM/HAND grid at 1 arc-second)
# with the exposure grid (typically GHSL at 3 arc-seconds), the cell-size
# ratio must be a whole integer. Tolerance for non-integer ratios that arise
# from floating-point imprecision in shape arithmetic.
RATIO_TOLERANCE: float = 1e-6
