"""Damage module: combine inundation depth + exposure + depth-damage curves."""

from .compute import compute_damage
from .curves import (
    JRC_AFRICA_RESIDENTIAL,
    JRC_ASIA_RESIDENTIAL,
    JRC_ASSET_CLASSES,
    JRC_CONTINENTS,
    JRC_CURVES,
    JRC_DEPTHS_M,
    JRC_EUROPE_RESIDENTIAL,
    JRC_NORTH_AMERICA_RESIDENTIAL,
    JRC_OCEANIA_RESIDENTIAL,
    JRC_SOUTH_AMERICA_RESIDENTIAL,
    DepthDamageCurve,
    jrc_curve,
)
from .inundation import compute_inundation_depth
from .models import DamageMap, InundationDepth

__all__ = [
    "DamageMap",
    "DepthDamageCurve",
    "InundationDepth",
    "JRC_AFRICA_RESIDENTIAL",
    "JRC_ASIA_RESIDENTIAL",
    "JRC_ASSET_CLASSES",
    "JRC_CONTINENTS",
    "JRC_CURVES",
    "JRC_DEPTHS_M",
    "JRC_EUROPE_RESIDENTIAL",
    "JRC_NORTH_AMERICA_RESIDENTIAL",
    "JRC_OCEANIA_RESIDENTIAL",
    "JRC_SOUTH_AMERICA_RESIDENTIAL",
    "compute_damage",
    "compute_inundation_depth",
    "jrc_curve",
]
