"""Constants for the routing module."""

# Approximate radius of the Earth (m). Used to convert WGS84 pixel sizes
# in degrees to areas in square metres. Mean of equatorial and polar
# radii is ~6,371,000 m; for the small-bbox use cases we care about the
# residual error is well below one percent.
EARTH_RADIUS_M: float = 6_371_000.0

# Length of one degree of latitude at the surface, in metres. Constant
# across the globe to first order (latitude lines are circles around the
# polar axis only at the equator; everywhere else they shorten by cos(lat)).
DEG_LAT_M: float = 111_319.5  # = 2 * pi * EARTH_RADIUS_M / 360 * (something close)

# Default event duration for the steady-state peak-discharge conversion.
# 6 hours is the standard NRCS / FEMA "design storm" duration for small
# rural watersheds; users with their own event windows pass `duration_s`
# explicitly.
DEFAULT_EVENT_DURATION_S: float = 6 * 3600.0  # 21,600 s

# Source-attribution string for the AccumulatedRunoffGrid / DischargeGrid
# when produced by these helpers. Future routing schemes
# (unit hydrograph, kinematic wave) will use distinct strings.
ROUTING_METHOD: str = "steady-state-flow-accumulation"


# --- Channel hydraulics (Manning normal-depth + Leopold-Maddock width) -----
#
# Leopold & Maddock (1953) "The hydraulic geometry of stream channels and
# some physiographic implications" — empirical relation between bankfull
# discharge and channel width:
#
#     w = a * Q^b
#
# where a, b are calibrated regional coefficients. The values below are the
# global natural-channel averages cited in Leopold & Maddock and refined by
# Andreadis et al. (2013) "A simple global river bankfull width and depth
# database" — appropriate when no local data are available. Override per
# basin / climate when calibration data exist.
LEOPOLD_MADDOCK_A: float = 2.5  # m * (m^3/s)^(-b)
LEOPOLD_MADDOCK_B: float = 0.5  # dimensionless

# Numerical floors. Manning's equation has a sqrt(slope) and divisions by
# width and slope, so zero values would blow up. These caps are
# conservatively tight — the right answer is "no flow" when slopes are
# this small, but flagging the cell at all gives smoother boundary output
# than a hard NaN.
MANNING_MIN_SLOPE: float = 1e-5    # m/m — flat-as-a-pond
MANNING_MIN_DEPTH: float = 0.05    # m — 5 cm channel-bottom default
