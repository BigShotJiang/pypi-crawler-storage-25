"""Routing module: hydrologic + hydraulic routing of runoff.

Provides:
  * accumulate_runoff(...) — flow-accumulation of SCS-CN runoff into
    upstream-volume and peak-discharge fields (PR1: hydrologic side).
  * compute_water_level(...) — Manning normal-depth at every stream
    cell, given discharge + roughness + slope + Leopold-Maddock width
    (PR2: hydraulic closure).
  * compute_rainfall_inundation(...) — final step: broadcast per-stream
    water levels upstream via flow direction and apply the existing HAND
    machinery to produce a rainfall-driven flood-depth raster.
"""

from .accumulate import accumulate_runoff
from .constants import (
    DEFAULT_EVENT_DURATION_S,
    EARTH_RADIUS_M,
    LEOPOLD_MADDOCK_A,
    LEOPOLD_MADDOCK_B,
    MANNING_MIN_DEPTH,
    MANNING_MIN_SLOPE,
)
from .discharge import peak_discharge
from .flood import RainfallInundationDepth, compute_rainfall_inundation
from .manning import (
    WaterLevelGrid,
    compute_water_level,
    leopold_maddock_width,
    manning_normal_depth,
)
from .models import (
    AccumulatedRunoffGrid,
    DischargeGrid,
)
from .utils import cell_areas_m2, pixel_sizes_m, slope_along_flow

__all__ = [
    "AccumulatedRunoffGrid",
    "DEFAULT_EVENT_DURATION_S",
    "DischargeGrid",
    "EARTH_RADIUS_M",
    "LEOPOLD_MADDOCK_A",
    "LEOPOLD_MADDOCK_B",
    "MANNING_MIN_DEPTH",
    "MANNING_MIN_SLOPE",
    "RainfallInundationDepth",
    "WaterLevelGrid",
    "accumulate_runoff",
    "cell_areas_m2",
    "compute_rainfall_inundation",
    "compute_water_level",
    "leopold_maddock_width",
    "manning_normal_depth",
    "peak_discharge",
    "pixel_sizes_m",
    "slope_along_flow",
]
