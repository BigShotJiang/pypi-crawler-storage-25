"""Dataclasses for the routing module."""

from dataclasses import dataclass

import numpy as np
from rasterio.transform import Affine

from floodpath.dem.models import BoundingBox


@dataclass
class AccumulatedRunoffGrid:
    """Accumulated upstream runoff volume (m^3) at each cell.

    `values[i, j]` is the total volume of water that has flowed into cell
    (i, j) from itself and all upstream cells in the DEM-derived flow
    direction grid, given the per-cell runoff depth from a RunoffGrid.
    Stream cells thus have the largest values; ridge cells have the
    smallest (just their own per-cell volume).

    Output of `accumulate_runoff(runoff, flow_grid)`.
    """

    values: np.ndarray
    transform: Affine
    crs: str
    bbox: BoundingBox
    precip_source: str
    method: str
    units: str = "m^3 (accumulated runoff volume)"

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying raster."""
        return self.values.shape  # type: ignore[return-value]

    def total_volume_m3(self) -> float:
        """Bulk volume integrated over the patch — *not* the sum of
        accumulated values (which double-counts each cell along its
        downstream path). Use this when reporting water-balance totals.
        """
        return float(self.values.max())

    def stats(self) -> dict[str, float]:
        """Summary statistics over finite cells."""
        valid = self.values[~np.isnan(self.values)]
        if valid.size == 0:
            return {"min": 0.0, "max": 0.0, "mean": 0.0, "median": 0.0}
        return {
            "min": float(valid.min()),
            "max": float(valid.max()),
            "mean": float(valid.mean()),
            "median": float(np.median(valid)),
        }


@dataclass
class DischargeGrid:
    """Per-cell peak discharge Q_peak (m^3/s) under steady-state routing.

    Computed as accumulated upstream runoff volume divided by event
    duration: Q_peak = V_acc / T. This is the simplest possible discharge
    estimate and assumes the entire upstream runoff arrives at each cell
    over the same window T — true only for events much shorter than the
    basin time-of-concentration (small basins, intense storms). Larger
    basins will see peak attenuation that this estimator does NOT model.
    """

    values: np.ndarray
    transform: Affine
    crs: str
    bbox: BoundingBox
    duration_s: float
    precip_source: str
    method: str
    units: str = "m^3/s (peak discharge)"

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying raster."""
        return self.values.shape  # type: ignore[return-value]

    def stats(self) -> dict[str, float]:
        """Summary statistics over finite cells."""
        valid = self.values[~np.isnan(self.values)]
        if valid.size == 0:
            return {"min": 0.0, "max": 0.0, "mean": 0.0, "median": 0.0}
        return {
            "min": float(valid.min()),
            "max": float(valid.max()),
            "mean": float(valid.mean()),
            "median": float(np.median(valid)),
        }

    def outlet_peak(self) -> float:
        """Peak discharge at the outlet (the cell with the largest accumulated
        volume — typically the basin outlet)."""
        return float(np.nanmax(self.values))
