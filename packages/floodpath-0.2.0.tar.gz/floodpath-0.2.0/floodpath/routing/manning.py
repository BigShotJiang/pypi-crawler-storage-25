"""Channel hydraulics: Manning normal-depth solver at stream cells.

Closes the hydraulic side of the rainfall->flood chain. Inputs are
discharge (from `peak_discharge`) and Manning's roughness (from
`floodpath.landuse.landuse_to_roughness`); outputs are per-stream-cell
water levels h that feed the rainfall-driven HAND inundation in
`floodpath.routing.flood`.

Manning's equation (in SI units):

    Q = (1/n) * A * R^(2/3) * S^(1/2)

For a wide rectangular channel (h << w) we approximate:
    A = w * h
    R ~ h
which yields a closed-form normal-depth solution:

    h = ((Q * n) / (w * sqrt(S)))^(3/5)

Channel width w comes from the Leopold-Maddock 1953 hydraulic-geometry
relation `w = a * Q^b` with global natural-channel defaults; users with
local calibration override `width_a, width_b`.
"""

from dataclasses import dataclass

import numpy as np
import rasterio.warp
from rasterio.enums import Resampling
from rasterio.transform import Affine

from floodpath.dem.models import DEM, BoundingBox
from floodpath.hydrology.models import FlowGrid, StreamNetwork
from floodpath.landuse.roughness import RoughnessGrid

from .constants import (
    LEOPOLD_MADDOCK_A,
    LEOPOLD_MADDOCK_B,
    MANNING_MIN_DEPTH,
    MANNING_MIN_SLOPE,
)
from .models import DischargeGrid
from .utils import slope_along_flow


@dataclass
class WaterLevelGrid:
    """Per-cell channel water depth (m), populated only at stream cells.

    `values[i, j]` is the Manning normal-depth water level above the
    channel bed at stream cell (i, j). Non-stream cells carry NaN to
    keep the field semantically clean for the upstream broadcast in
    `compute_rainfall_inundation`.

    `discharge_source` records where the input discharge came from
    (e.g. the precip-source string carried through accumulate->discharge),
    plus method tags for the hydraulic solver.
    """

    values: np.ndarray
    transform: Affine
    crs: str
    bbox: BoundingBox
    duration_s: float
    discharge_source: str
    method: str = "manning-normal-depth"
    units: str = "m (channel water depth)"

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying raster."""
        return self.values.shape  # type: ignore[return-value]

    def stats_at_streams(self) -> dict[str, float]:
        """Summary statistics over stream cells (NaN-skipping)."""
        valid = self.values[~np.isnan(self.values)]
        if valid.size == 0:
            return {"min": 0.0, "max": 0.0, "mean": 0.0, "median": 0.0}
        return {
            "min": float(valid.min()),
            "max": float(valid.max()),
            "mean": float(valid.mean()),
            "median": float(np.median(valid)),
        }


def leopold_maddock_width(
    discharge_q: np.ndarray,
    a: float = LEOPOLD_MADDOCK_A,
    b: float = LEOPOLD_MADDOCK_B,
) -> np.ndarray:
    """Estimate channel width (m) from discharge via Leopold-Maddock.

        w = a * Q^b

    Args:
        discharge_q: Discharge in m^3/s. Scalar or array.
        a, b: Hydraulic-geometry coefficients. Global natural-channel
            defaults are 2.5 and 0.5 (Andreadis et al. 2013).

    Returns:
        Channel width in m, same shape as input.
    """
    q = np.maximum(discharge_q, 0.0)
    return float(a) * np.power(q, float(b))


def manning_normal_depth(
    discharge_q: np.ndarray,
    width_w: np.ndarray,
    slope_s: np.ndarray,
    manning_n: np.ndarray | float,
    min_depth: float = MANNING_MIN_DEPTH,
    min_slope: float = MANNING_MIN_SLOPE,
) -> np.ndarray:
    """Solve Manning's wide-channel approximation for normal depth h.

        h = ((Q * n) / (w * sqrt(S)))^(3/5)

    All inputs are array-broadcast compatible. Floors are applied to
    slope (`min_slope`) to avoid sqrt(0) and to the output (`min_depth`)
    to keep a tiny minimum channel depth where flow exists.

    Args:
        discharge_q: Discharge in m^3/s.
        width_w: Channel width in m.
        slope_s: Channel slope in m/m. Clamped to `min_slope`.
        manning_n: Manning's n in s/m^(1/3). Scalar or array.
        min_depth: Minimum returned depth in m. Default 0.05 m
            (ankle-deep cap to avoid zero-thin channels).
        min_slope: Slope floor in m/m.

    Returns:
        Water depth (m) at each cell, broadcast shape of inputs.
    """
    s = np.maximum(slope_s, float(min_slope))
    sqrt_s = np.sqrt(s)
    # Avoid divide-by-zero at width=0 (no channel) — caller usually masks
    # to stream cells, but defend here too.
    safe_w = np.where(width_w > 0, width_w, 1.0)
    h = ((discharge_q * manning_n) / (safe_w * sqrt_s)) ** (3.0 / 5.0)
    h = np.where(width_w > 0, h, 0.0)
    h = np.maximum(h, float(min_depth))
    return h.astype(np.float32)


def _roughness_at_flow_grid(
    roughness: RoughnessGrid,
    flow_grid: FlowGrid,
) -> np.ndarray:
    """Reproject a (typically 10 m) RoughnessGrid onto the flow grid.

    Roughness is a continuous physical property; an area-weighted average
    is the right downsampling for it (same logic as the runoff reproject
    in `accumulate_runoff`).
    """
    out = np.zeros(flow_grid.shape, dtype=np.float32)
    rasterio.warp.reproject(
        source=roughness.values,
        destination=out,
        src_transform=roughness.transform,
        src_crs=roughness.crs,
        dst_transform=flow_grid.transform,
        dst_crs=flow_grid.crs,
        resampling=Resampling.average,
    )
    return out


def compute_water_level(
    discharge: DischargeGrid,
    roughness: RoughnessGrid,
    flow_grid: FlowGrid,
    streams: StreamNetwork,
    dem: DEM,
    width_a: float = LEOPOLD_MADDOCK_A,
    width_b: float = LEOPOLD_MADDOCK_B,
    min_depth: float = MANNING_MIN_DEPTH,
    min_slope: float = MANNING_MIN_SLOPE,
) -> WaterLevelGrid:
    """Compute water level h at every stream cell via Manning's equation.

    Pipeline:
      1. Reproject the (typically 10 m) RoughnessGrid onto the flow grid.
      2. Compute slope along the flow direction at every cell from the DEM.
      3. Width at every cell = `leopold_maddock_width(Q)`.
      4. h at every cell = `manning_normal_depth(Q, w, S, n)`.
      5. Mask non-stream cells to NaN so the field cleanly says "water
         level only at the channel."

    Args:
        discharge: Per-cell peak discharge (m^3/s) from `peak_discharge`.
        roughness: Manning's n raster from `landuse_to_roughness`. May
            differ in resolution from the flow grid; gets reprojected.
        flow_grid: FlowGrid (carries pyflwdir + transform + CRS).
        streams: StreamNetwork mask defining channel cells.
        dem: DEM whose elevations are used to compute slope.
        width_a, width_b: Leopold-Maddock coefficients.
        min_depth: Minimum channel depth floor (m).
        min_slope: Slope floor (m/m).

    Returns:
        WaterLevelGrid with h (m) at stream cells, NaN elsewhere.
    """
    if discharge.shape != flow_grid.shape:
        raise ValueError(
            f"discharge shape {discharge.shape} does not match flow_grid shape "
            f"{flow_grid.shape}"
        )
    if streams.shape != flow_grid.shape:
        raise ValueError(
            f"streams shape {streams.shape} does not match flow_grid shape "
            f"{flow_grid.shape}"
        )

    n_at_flow = _roughness_at_flow_grid(roughness, flow_grid)
    slope = slope_along_flow(flow_grid, dem, min_slope=min_slope)
    width = leopold_maddock_width(discharge.values, a=width_a, b=width_b)
    h_full = manning_normal_depth(
        discharge_q=discharge.values,
        width_w=width,
        slope_s=slope,
        manning_n=n_at_flow,
        min_depth=min_depth,
        min_slope=min_slope,
    )

    # Mask non-stream cells. Keep stream cells' depths; NaN everywhere else.
    h = np.where(streams.mask, h_full, np.nan).astype(np.float32)

    return WaterLevelGrid(
        values=h,
        transform=flow_grid.transform,
        crs=flow_grid.crs,
        bbox=BoundingBox(
            min_lon=flow_grid.bbox.min_lon,
            min_lat=flow_grid.bbox.min_lat,
            max_lon=flow_grid.bbox.max_lon,
            max_lat=flow_grid.bbox.max_lat,
        ),
        duration_s=discharge.duration_s,
        discharge_source=discharge.precip_source,
    )
