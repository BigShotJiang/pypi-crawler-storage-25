"""Rainfall-driven HAND inundation: combine per-stream water levels with HAND."""

from dataclasses import dataclass

import numpy as np
from rasterio.transform import Affine

from floodpath.dem.models import BoundingBox
from floodpath.hydrology.models import FlowGrid, Hand, StreamNetwork

from .manning import WaterLevelGrid


@dataclass
class RainfallInundationDepth:
    """Per-cell flood depth driven by per-stream-cell channel water levels.

    Replaces the flat-water-level inundation used by `damage`'s static
    `compute_inundation_depth(hand, water_level=5.0)`. The water level
    here varies across the basin: each off-stream cell's depth is

        depth = max(h_at_drainage_stream - HAND, 0)

    where `h_at_drainage_stream` is the Manning normal-depth at the
    stream cell that the off-stream cell drains to (via the flow
    direction grid).
    """

    values: np.ndarray
    transform: Affine
    crs: str
    bbox: BoundingBox
    duration_s: float
    discharge_source: str
    method: str = "hand-driven-by-manning-water-levels"
    units: str = "m (flood depth, rainfall-driven)"

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying raster."""
        return self.values.shape  # type: ignore[return-value]

    def stats(self) -> dict[str, float]:
        """Summary statistics over wet cells (depth > 0)."""
        wet = self.values[self.values > 0]
        if wet.size == 0:
            return {
                "min": 0.0, "max": 0.0, "mean": 0.0, "median": 0.0,
                "wet_cells": 0,
            }
        return {
            "min": float(wet.min()),
            "max": float(wet.max()),
            "mean": float(wet.mean()),
            "median": float(np.median(wet)),
            "wet_cells": int(wet.size),
        }

    def flooded_fraction(self) -> float:
        """Fraction of the patch with depth > 0."""
        if self.values.size == 0:
            return 0.0
        return float((self.values > 0).sum() / self.values.size)


def _broadcast_stream_levels(
    flow_grid: FlowGrid,
    streams: StreamNetwork,
    water_level: WaterLevelGrid,
) -> np.ndarray:
    """Project per-stream-cell water levels onto every cell that drains to them.

    Uses `pyflwdir.FlwdirRaster.basins(idxs=stream_indices)` to label
    every cell with the 1-based index of its drainage stream cell;
    cells outside any stream's catchment (e.g. ridge cells that flow
    off the bbox edge before hitting a stream) get basin_id=0 and water
    level NaN.
    """
    flwdir = flow_grid.flwdir_raster
    stream_flat_idxs = np.flatnonzero(streams.mask.flatten())

    basins = flwdir.basins(idxs=stream_flat_idxs)  # 0 = background, else 1..N

    # Build a lookup table: water level for each basin id (1-based).
    # Position 0 is reserved for "out of basin" -> NaN.
    h_at_streams = water_level.values.flatten()
    h_lookup = np.full(stream_flat_idxs.size + 1, np.nan, dtype=np.float32)
    h_lookup[1:] = h_at_streams[stream_flat_idxs]

    return h_lookup[basins]


def compute_rainfall_inundation(
    water_level: WaterLevelGrid,
    hand: Hand,
    flow_grid: FlowGrid,
    streams: StreamNetwork,
) -> RainfallInundationDepth:
    """Produce a rainfall-driven flood depth raster from the full chain.

    For every cell:

        depth = max(h_at_drainage - HAND, 0)

    where `h_at_drainage` is the Manning normal-depth at the cell's
    associated stream cell (the first downstream stream cell along the
    flow direction). Cells outside any stream's catchment, or with HAND
    nodata, stay dry (depth = 0).

    Args:
        water_level: WaterLevelGrid from `compute_water_level`.
        hand: HAND raster from `compute_hand`.
        flow_grid: Same flow grid used for HAND and routing.
        streams: Same StreamNetwork used for HAND and water-level computation.

    Returns:
        RainfallInundationDepth carrying per-cell flood depth in m.

    Raises:
        ValueError: any of the inputs has a mismatched shape.
    """
    if water_level.shape != flow_grid.shape:
        raise ValueError(
            f"water_level shape {water_level.shape} does not match flow_grid "
            f"shape {flow_grid.shape}"
        )
    if hand.shape != flow_grid.shape:
        raise ValueError(
            f"hand shape {hand.shape} does not match flow_grid shape "
            f"{flow_grid.shape}"
        )

    h_field = _broadcast_stream_levels(flow_grid, streams, water_level)

    # depth = max(h - HAND, 0). HAND nodata is a large negative value
    # from pyflwdir; treat anything < 0 as nodata -> dry.
    valid_hand = hand.values >= 0
    valid_h = ~np.isnan(h_field)
    diff = np.where(valid_hand & valid_h, h_field - hand.values, 0.0)
    depth = np.maximum(diff, 0.0).astype(np.float32)

    return RainfallInundationDepth(
        values=depth,
        transform=flow_grid.transform,
        crs=flow_grid.crs,
        bbox=BoundingBox(
            min_lon=flow_grid.bbox.min_lon,
            min_lat=flow_grid.bbox.min_lat,
            max_lon=flow_grid.bbox.max_lon,
            max_lat=flow_grid.bbox.max_lat,
        ),
        duration_s=water_level.duration_s,
        discharge_source=water_level.discharge_source,
    )
