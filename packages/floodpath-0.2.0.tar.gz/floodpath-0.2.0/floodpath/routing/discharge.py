"""Convert accumulated runoff volume to peak discharge."""

import numpy as np

from .models import AccumulatedRunoffGrid, DischargeGrid


def peak_discharge(
    accumulated: AccumulatedRunoffGrid,
    duration_s: float,
) -> DischargeGrid:
    """Convert accumulated upstream runoff volume to peak discharge.

    Steady-state estimate: per-cell peak discharge equals the total
    upstream runoff volume divided by the event duration.

        Q_peak (m^3/s) = V_acc (m^3) / T (s)

    This treats the entire upstream runoff as arriving over the same
    event window — accurate for storms much shorter than the basin
    time-of-concentration (small mountain basins, intense convective
    storms), increasingly biased high for larger basins where peak
    attenuation along the channel matters. A future kinematic-wave or
    unit-hydrograph router will replace this for those cases.

    Args:
        accumulated: Output of `accumulate_runoff`.
        duration_s: Event duration in seconds. Use 6*3600 for the
            standard NRCS 6-hour design storm; pass `DEFAULT_EVENT_DURATION_S`
            from constants for a typed default.

    Returns:
        DischargeGrid with per-cell peak discharge in m^3/s.

    Raises:
        ValueError: `duration_s` is not strictly positive.
    """
    if duration_s <= 0:
        raise ValueError(f"duration_s must be > 0, got {duration_s}")

    q_peak = (accumulated.values / float(duration_s)).astype(np.float32)

    return DischargeGrid(
        values=q_peak,
        transform=accumulated.transform,
        crs=accumulated.crs,
        bbox=accumulated.bbox,
        duration_s=float(duration_s),
        precip_source=accumulated.precip_source,
        method=accumulated.method,
    )
