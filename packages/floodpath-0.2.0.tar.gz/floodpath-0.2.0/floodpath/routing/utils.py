"""Geometric helpers for the routing module."""

import math

import numpy as np
from rasterio.transform import Affine

from floodpath.dem.models import DEM
from floodpath.hydrology.models import FlowGrid

from .constants import DEG_LAT_M, MANNING_MIN_SLOPE


def cell_areas_m2(
    transform: Affine,
    shape: tuple[int, int],
    crs: str,
) -> np.ndarray:
    """Return per-cell areas in square metres for a raster grid.

    Supports two cases:

    * Geographic CRS in degrees (EPSG:4326 etc.): each row uses a
      latitude-dependent cosine factor — pixels shrink at higher
      latitudes. Pixel size on the X axis is multiplied by
      `cos(latitude)` because longitude lines converge toward the poles.
    * Projected CRS in metres: pixel area is just the absolute product
      of the transform's scale components.

    Args:
        transform: Rasterio Affine transform of the grid.
        shape: (rows, cols) of the raster.
        crs: CRS of the grid as a string (e.g. ``"EPSG:4326"``).

    Returns:
        Float64 array of shape `shape` with each cell's area in m^2.
    """
    pixel_x = abs(transform.a)
    pixel_y = abs(transform.e)
    rows, _ = shape

    is_geographic = ("4326" in crs) or ("WGS 84" in crs) or ("WGS84" in crs)
    if not is_geographic:
        # Projected CRS: pixel size is already in metres.
        return np.full(shape, pixel_x * pixel_y, dtype=np.float64)

    # Geographic CRS in degrees. Compute the latitude at every row centre
    # using the affine transform and apply the cos(lat) longitude
    # convergence factor.
    row_indices = np.arange(rows)
    # transform.f = top-edge latitude; transform.e = -pixel_y for north-up
    # rasters. Centre latitude of row r is f + (r + 0.5) * e.
    lat_centres = transform.f + (row_indices + 0.5) * transform.e
    cos_lat = np.cos(np.radians(lat_centres))

    cell_x_m = pixel_x * DEG_LAT_M * cos_lat  # m, per row
    cell_y_m = pixel_y * DEG_LAT_M             # m, constant
    areas_per_row = cell_x_m * cell_y_m        # m^2, per row

    return np.broadcast_to(
        areas_per_row[:, None],
        shape,
    ).astype(np.float64).copy()


def pixel_sizes_m(
    transform: Affine,
    shape: tuple[int, int],
    crs: str,
) -> tuple[np.ndarray, float]:
    """Return per-row pixel x-size (m) and constant pixel y-size (m).

    Helper used by `slope_along_flow` to convert flow-direction step
    distances from pixel-units to metres on the WGS84 graticule.

    Args:
        transform: Rasterio Affine transform.
        shape: (rows, cols) of the raster.
        crs: CRS string.

    Returns:
        Tuple `(pixel_x_per_row, pixel_y)` where:
          * `pixel_x_per_row` is a (rows,) float array — x-size in metres
            for each row's centre latitude.
          * `pixel_y` is a scalar — y-size in metres (constant for WGS84
            and projected CRSes).
    """
    pixel_x = abs(transform.a)
    pixel_y = abs(transform.e)
    rows, _ = shape

    is_geographic = ("4326" in crs) or ("WGS 84" in crs) or ("WGS84" in crs)
    if not is_geographic:
        return np.full(rows, pixel_x, dtype=np.float64), float(pixel_y)

    row_indices = np.arange(rows)
    lat_centres = transform.f + (row_indices + 0.5) * transform.e
    cos_lat = np.cos(np.radians(lat_centres))
    pixel_x_per_row = pixel_x * DEG_LAT_M * cos_lat
    pixel_y_m = pixel_y * DEG_LAT_M
    return pixel_x_per_row.astype(np.float64), float(pixel_y_m)


def slope_along_flow(
    flow_grid: FlowGrid,
    dem: DEM,
    min_slope: float = MANNING_MIN_SLOPE,
) -> np.ndarray:
    """Per-cell slope (m/m) measured along the downstream flow direction.

    For each cell c with downstream cell c' (= idxs_ds[c]):

        slope = (elev[c] - elev[c']) / distance(c, c')

    where distance accounts for diagonal vs orthogonal D8 steps and uses
    metric pixel sizes (lat-aware in WGS84).

    Pits (cells where idxs_ds points to self) and cells where the
    computed slope would be non-positive are clamped to `min_slope` so
    Manning's `1/sqrt(S)` term doesn't blow up. The convention follows
    pyflwdir's own `subgrid_rivslp` defaults.

    Args:
        flow_grid: FlowGrid with attached pyflwdir FlwdirRaster.
        dem: DEM whose elevations the slope is measured against.
        min_slope: Floor applied to all slope values (m/m). Default 1e-5
            corresponds to ~1 cm drop per kilometre.

    Returns:
        2D float64 array of shape `dem.shape` with per-cell slope in m/m,
        guaranteed >= `min_slope` everywhere.
    """
    flwdir = flow_grid.flwdir_raster
    nrows, ncols = dem.elevation.shape
    n = nrows * ncols

    elev = dem.elevation.astype(np.float64).flatten()
    idxs_ds = np.asarray(flwdir.idxs_ds)

    # Identify pits (downstream is self or out of bounds — idxs_ds = -1).
    self_idx = np.arange(n, dtype=idxs_ds.dtype)
    pit_mask = (idxs_ds == self_idx) | (idxs_ds < 0)
    safe_ds = np.where(pit_mask, self_idx, idxs_ds)

    # Row/col of each cell and its downstream neighbour.
    rows = self_idx // ncols
    cols = self_idx % ncols
    rows_ds = safe_ds // ncols
    cols_ds = safe_ds % ncols
    drow = (rows - rows_ds).astype(np.int64)  # +1 = downstream is north
    dcol = (cols - cols_ds).astype(np.int64)

    pixel_x_per_row, pixel_y = pixel_sizes_m(
        flow_grid.transform, dem.elevation.shape, dem.crs
    )
    pixel_x_flat = pixel_x_per_row[rows]
    distance = np.sqrt((drow * pixel_y) ** 2 + (dcol * pixel_x_flat) ** 2)

    delta_elev = elev - elev[safe_ds]
    with np.errstate(divide="ignore", invalid="ignore"):
        slope = np.where(distance > 0, delta_elev / distance, 0.0)

    # Pits get min_slope; non-positive slopes (sinks, flat valleys) get min_slope.
    slope = np.where(pit_mask, min_slope, slope)
    slope = np.maximum(slope, float(min_slope))

    return slope.reshape(dem.elevation.shape)
