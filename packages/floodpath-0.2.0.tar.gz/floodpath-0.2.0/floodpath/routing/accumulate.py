"""Accumulate runoff (mm depth) along a flow direction grid into volume (m^3)."""

import numpy as np
import rasterio.warp
from rasterio.enums import Resampling

from floodpath.dem.models import BoundingBox
from floodpath.hydrology.models import FlowGrid
from floodpath.runoff.models import RunoffGrid

from .constants import ROUTING_METHOD
from .models import AccumulatedRunoffGrid
from .utils import cell_areas_m2


def _runoff_at_flow_grid(
    runoff: RunoffGrid,
    flow_grid: FlowGrid,
) -> np.ndarray:
    """Reproject runoff depth (mm) onto the flow grid via area-weighted average.

    Runoff is a depth (mm) — averaging fine cells into a coarse cell is
    correct (the coarse cell's depth is the area-weighted mean of its
    fine cells'). Volume aggregation comes later, after multiplying by
    the coarse-grid cell area.
    """
    out = np.zeros(flow_grid.shape, dtype=np.float32)
    rasterio.warp.reproject(
        source=runoff.values,
        destination=out,
        src_transform=runoff.transform,
        src_crs=runoff.crs,
        dst_transform=flow_grid.transform,
        dst_crs=flow_grid.crs,
        resampling=Resampling.average,
    )
    return out


def accumulate_runoff(
    runoff: RunoffGrid,
    flow_grid: FlowGrid,
) -> AccumulatedRunoffGrid:
    """Accumulate runoff downstream along the flow direction grid.

    Three steps:

    1. **Reproject** runoff depth (mm) from its native grid (typically
       WorldCover 10 m) to the flow grid (typically DEM 30 m) via
       area-weighted average. Each coarse cell now carries the
       area-weighted mean depth of its fine cells.
    2. **Convert** depth (mm) at each cell to volume (m^3) by multiplying
       by the cell's area in m^2 (computed from the transform via
       `cell_areas_m2`, which handles WGS84 cos(lat) convergence).
    3. **Accumulate** the per-cell volume downstream using
       `pyflwdir.FlwdirRaster.accuflux`. Each cell's value becomes its
       own volume plus the sum of all upstream cells'.

    NaN cells in the input runoff grid (typically CN nodata at the HSG
    reprojection edge) are zero-filled before accumulation — they
    contribute no runoff downstream rather than poisoning the entire
    accumulation.

    Args:
        runoff: Per-cell runoff depth (mm) from `apply_scs_cn`.
        flow_grid: Flow direction + accumulation grid from `build_flow_grid`.

    Returns:
        AccumulatedRunoffGrid with per-cell upstream runoff volume (m^3),
        sharing the flow grid's georef.
    """
    # 1. Reproject runoff depth (mm) onto the flow grid.
    q_at_flow = _runoff_at_flow_grid(runoff, flow_grid)
    # NaN -> 0 (unknown -> contributes nothing). Without this, accuflux
    # would propagate NaN through the entire downstream network.
    q_at_flow = np.where(np.isnan(q_at_flow), 0.0, q_at_flow)

    # 2. Volume per cell: depth (mm) * area (m^2) / 1000 mm/m -> m^3.
    areas = cell_areas_m2(
        transform=flow_grid.transform,
        shape=flow_grid.shape,
        crs=flow_grid.crs,
    )
    volume_per_cell = (q_at_flow * areas / 1000.0).astype(np.float32)

    # 3. Accumulate downstream via pyflwdir.
    accumulated = flow_grid.flwdir_raster.accuflux(volume_per_cell)

    return AccumulatedRunoffGrid(
        values=accumulated.astype(np.float32),
        transform=flow_grid.transform,
        crs=flow_grid.crs,
        bbox=BoundingBox(
            min_lon=flow_grid.bbox.min_lon,
            min_lat=flow_grid.bbox.min_lat,
            max_lon=flow_grid.bbox.max_lon,
            max_lat=flow_grid.bbox.max_lat,
        ),
        precip_source=runoff.precip_source,
        method=ROUTING_METHOD,
    )
