"""DEM module: fetch elevation patches around a point."""

from .fetcher import get_dem
from .models import DEM, BoundingBox

__all__ = ["DEM", "BoundingBox", "get_dem"]
