"""Pure helper functions for geometry and Copernicus tile addressing."""

import math

from .constants import COPERNICUS_DEM_BASE_URL, COPERNICUS_TILE_RES_CODE
from .models import BoundingBox


def bbox_from_point(
    lat: float,
    lon: float,
    buffer_deg: float,
) -> BoundingBox:
    """Build a square WGS84 bbox around a point.

    Args:
        lat: Latitude in decimal degrees.
        lon: Longitude in decimal degrees.
        buffer_deg: Half-width applied to each side, in degrees.

    Returns:
        BoundingBox spanning [lon-buffer, lon+buffer] x [lat-buffer, lat+buffer].
    """
    return BoundingBox(
        min_lon=lon - buffer_deg,
        min_lat=lat - buffer_deg,
        max_lon=lon + buffer_deg,
        max_lat=lat + buffer_deg,
    )


def tiles_for_bbox(bbox: BoundingBox) -> list[tuple[int, int]]:
    """Enumerate the 1x1 degree tile SW-corners covering a bbox.

    Args:
        bbox: Geographic bounding box.

    Returns:
        List of (lat_sw, lon_sw) integer corners. Each tile spans
        [lat_sw, lat_sw+1) x [lon_sw, lon_sw+1).
    """
    lat_start = math.floor(bbox.min_lat)
    lat_stop = math.floor(bbox.max_lat)
    lon_start = math.floor(bbox.min_lon)
    lon_stop = math.floor(bbox.max_lon)

    # When the bbox edge sits exactly on an integer boundary, math.floor of the
    # max value yields the next tile up — exclude it.
    if bbox.max_lat == lat_stop and lat_stop > lat_start:
        lat_stop -= 1
    if bbox.max_lon == lon_stop and lon_stop > lon_start:
        lon_stop -= 1

    return [(lat, lon) for lat in range(lat_start, lat_stop + 1) for lon in range(lon_start, lon_stop + 1)]


def copernicus_tile_id(
    lat_sw: int,
    lon_sw: int,
) -> str:
    """Build the Copernicus DEM tile identifier for a 1x1 degree cell."""
    ns = "N" if lat_sw >= 0 else "S"
    ew = "E" if lon_sw >= 0 else "W"
    return f"Copernicus_DSM_COG_{COPERNICUS_TILE_RES_CODE}_" f"{ns}{abs(lat_sw):02d}_00_{ew}{abs(lon_sw):03d}_00_DEM"


def copernicus_tile_url(
    lat_sw: int,
    lon_sw: int,
) -> str:
    """Build the public HTTPS URL for a Copernicus GLO-30 tile COG."""
    tile_id = copernicus_tile_id(lat_sw, lon_sw)
    return f"{COPERNICUS_DEM_BASE_URL}/{tile_id}/{tile_id}.tif"
