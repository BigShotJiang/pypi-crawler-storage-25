"""Fetch DEM patches by streaming Copernicus GLO-30 COGs over HTTPS."""

import rasterio
from rasterio.env import Env
from rasterio.errors import RasterioIOError
from rasterio.merge import merge

from .constants import DEM_BUFFER_DEG, DEM_CRS, GDAL_VSICURL_ENV
from .models import DEM
from .utils import bbox_from_point, copernicus_tile_url, tiles_for_bbox


def get_dem(
    lat: float,
    lon: float,
    buffer_deg: float = DEM_BUFFER_DEG,
) -> DEM:
    """Return a DEM patch around (lat, lon) without downloading whole tiles.

    Reads only the bbox window from Copernicus GLO-30 COGs hosted on the
    public AWS Open Data bucket via GDAL's /vsicurl/ driver. Tiles that
    cover only ocean are absent from the bucket; if no tile in the bbox
    exists the call raises FileNotFoundError.

    Args:
        lat: Latitude of the region center, decimal degrees.
        lon: Longitude of the region center, decimal degrees.
        buffer_deg: Half-width of the square bbox around the point, degrees.

    Returns:
        DEM dataclass holding the elevation array, transform, CRS, and bbox.

    Raises:
        FileNotFoundError: No Copernicus tile covers the requested bbox.
    """
    bbox = bbox_from_point(lat, lon, buffer_deg)
    tile_corners = tiles_for_bbox(bbox)
    urls = [copernicus_tile_url(lat_sw, lon_sw) for lat_sw, lon_sw in tile_corners]

    with Env(**GDAL_VSICURL_ENV):
        datasets = []
        try:
            for url in urls:
                try:
                    datasets.append(rasterio.open(f"/vsicurl/{url}"))
                except RasterioIOError:
                    # Ocean tiles and other gaps are missing from the bucket.
                    continue

            if not datasets:
                raise FileNotFoundError(
                    f"No Copernicus DEM tiles found for bbox {bbox.bounds}. "
                    "The region may be ocean or outside global coverage."
                )

            elevation, transform = merge(datasets, bounds=bbox.bounds)
        finally:
            for ds in datasets:
                ds.close()

    return DEM(
        elevation=elevation[0],
        transform=transform,
        crs=DEM_CRS,
        bbox=bbox,
    )
