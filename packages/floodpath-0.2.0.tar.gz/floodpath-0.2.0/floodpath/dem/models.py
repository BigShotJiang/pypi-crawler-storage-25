"""Dataclasses for the DEM module."""

from dataclasses import dataclass

import numpy as np
from rasterio.transform import Affine


@dataclass(frozen=True)
class BoundingBox:
    """Geographic bounding box in degrees (WGS84)."""

    min_lon: float
    min_lat: float
    max_lon: float
    max_lat: float

    @property
    def bounds(self) -> tuple[float, float, float, float]:
        """Return (left, bottom, right, top) as expected by rasterio."""
        return (self.min_lon, self.min_lat, self.max_lon, self.max_lat)


@dataclass
class DEM:
    """A clipped DEM patch held in memory."""

    elevation: np.ndarray
    transform: Affine
    crs: str
    bbox: BoundingBox

    @property
    def shape(self) -> tuple[int, int]:
        """Return the shape of the elevation array."""
        return self.elevation.shape  # type: ignore[return-value]
