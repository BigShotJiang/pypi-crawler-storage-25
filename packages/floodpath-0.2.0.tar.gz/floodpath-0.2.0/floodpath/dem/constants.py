"""Constants for the DEM module."""

DEM_BUFFER_DEG: float = 0.1

COPERNICUS_DEM_BASE_URL: str = "https://copernicus-dem-30m.s3.amazonaws.com"
COPERNICUS_TILE_RES_CODE: str = "10"

DEM_CRS: str = "EPSG:4326"

GDAL_VSICURL_ENV: dict[str, str] = {
    "GDAL_DISABLE_READDIR_ON_OPEN": "EMPTY_DIR",
    "CPL_VSIL_CURL_USE_HEAD": "NO",
    "GDAL_HTTP_MULTIPLEX": "YES",
    "GDAL_HTTP_VERSION": "2",
}
