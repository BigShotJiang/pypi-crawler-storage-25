"""floodpath — modular Python pipeline for HAND-based flood inundation and damage estimation."""

__version__ = "0.2.0"
