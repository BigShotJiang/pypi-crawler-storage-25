"""Dataclasses for the hydrology module."""

from dataclasses import dataclass

import numpy as np
from pyflwdir import FlwdirRaster
from rasterio.transform import Affine

from floodpath.dem.models import BoundingBox


@dataclass
class FlowGrid:
    """Flow direction + accumulation derived from a DEM.

    Wraps a pyflwdir FlwdirRaster (which encodes filled DEM + D8 directions)
    alongside the precomputed flow accumulation array. Downstream operations
    (stream extraction, basin delineation) read both fields.
    """

    flwdir_raster: FlwdirRaster
    accumulation: np.ndarray
    transform: Affine
    crs: str
    bbox: BoundingBox

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying raster."""
        return self.accumulation.shape  # type: ignore[return-value]


@dataclass
class StreamNetwork:
    """Binary stream mask + Strahler order, with the threshold used to derive it."""

    mask: np.ndarray
    order: np.ndarray
    threshold: int
    transform: Affine
    crs: str

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying raster."""
        return self.mask.shape  # type: ignore[return-value]


@dataclass
class Basin:
    """Watershed mask draining to a single pour point."""

    mask: np.ndarray
    pour_point: tuple[float, float]
    pour_pixel: tuple[int, int]
    transform: Affine
    crs: str

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying raster."""
        return self.mask.shape  # type: ignore[return-value]

    @property
    def cell_count(self) -> int:
        """Number of cells inside the basin."""
        return int(self.mask.sum())


@dataclass
class Hand:
    """Height Above Nearest Drainage (HAND) raster, in metres.

    For each cell, `values` holds the vertical distance to the nearest
    drainage (stream) cell traced along the flow direction grid. Cells
    that ARE stream cells have HAND = 0 by construction.
    """

    values: np.ndarray
    transform: Affine
    crs: str
    bbox: BoundingBox
    stream_threshold: int

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying raster."""
        return self.values.shape  # type: ignore[return-value]
