"""Constants for the hydrology module."""

# Cells with this many or more upstream cells are classified as streams.
# 1000 cells at Copernicus GLO-30 (~30 m) ~ 0.9 km^2 contributing area —
# a reasonable default for headwater streams in temperate climates. Override
# per region as needed.
STREAM_ACCUMULATION_THRESHOLD: int = 1000

# Sentinel substituted for NaN in DEMs before passing to pyflwdir, which
# treats nodata as a finite comparison value (NaN comparisons always evaluate
# False, so NaN cells would incorrectly be treated as valid elevations).
DEM_NODATA_SENTINEL: float = -9999.0
