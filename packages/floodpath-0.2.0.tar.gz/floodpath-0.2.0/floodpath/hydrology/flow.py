"""Build a FlowGrid (filled DEM + D8 flow direction + flow accumulation)."""

import pyflwdir

from floodpath.dem.models import DEM

from .constants import DEM_NODATA_SENTINEL
from .models import FlowGrid
from .utils import replace_nan_with_sentinel


def build_flow_grid(dem: DEM) -> FlowGrid:
    """Derive D8 flow direction + flow accumulation from a DEM.

    Wraps pyflwdir.from_dem, which fills depressions (priority-flood) and
    encodes D8 flow direction in a single pass. Flow accumulation is then
    computed in cell counts via FlwdirRaster.upstream_area.

    Args:
        dem: DEM patch produced by `dem.get_dem`. Must be in EPSG:4326.

    Returns:
        FlowGrid bundling the FlwdirRaster, accumulation array, and the
        DEM's georeferencing.
    """
    elevation = replace_nan_with_sentinel(dem.elevation)
    flw = pyflwdir.from_dem(
        data=elevation,
        nodata=DEM_NODATA_SENTINEL,
        transform=dem.transform,
        latlon=True,
    )
    accumulation = flw.upstream_area(unit="cell")

    return FlowGrid(
        flwdir_raster=flw,
        accumulation=accumulation,
        transform=dem.transform,
        crs=dem.crs,
        bbox=dem.bbox,
    )
