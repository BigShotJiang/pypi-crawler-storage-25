"""Extract a stream network from a FlowGrid by thresholding accumulation."""

from .constants import STREAM_ACCUMULATION_THRESHOLD
from .models import FlowGrid, StreamNetwork


def extract_streams(
    grid: FlowGrid,
    threshold: int = STREAM_ACCUMULATION_THRESHOLD,
) -> StreamNetwork:
    """Threshold flow accumulation to define a stream mask + Strahler order.

    Args:
        grid: FlowGrid produced by `build_flow_grid`.
        threshold: Minimum upstream cell count for a cell to be a stream.
            Lower values produce denser networks.

    Returns:
        StreamNetwork with the binary mask, Strahler order array, and the
        threshold actually applied.
    """
    mask = grid.accumulation >= threshold
    # pyflwdir caches stream_order results keyed only on order type — not on
    # the mask. Clear the cache entry so each call recomputes against the
    # current threshold's mask, not the first one seen this session.
    grid.flwdir_raster._cached.pop("strord", None)
    order = grid.flwdir_raster.stream_order(mask=mask)

    return StreamNetwork(
        mask=mask,
        order=order,
        threshold=threshold,
        transform=grid.transform,
        crs=grid.crs,
    )
