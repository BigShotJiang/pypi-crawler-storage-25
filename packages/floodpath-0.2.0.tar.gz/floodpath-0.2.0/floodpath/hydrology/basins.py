"""Delineate watersheds draining to a pour point."""

import numpy as np

from .models import Basin, FlowGrid
from .utils import lonlat_to_rowcol


def delineate_basin(
    grid: FlowGrid,
    pour_point: tuple[float, float],
) -> Basin:
    """Trace upstream from a pour point to find the contributing watershed.

    Args:
        grid: FlowGrid produced by `build_flow_grid`.
        pour_point: `(lat, lon)` of the basin outlet, in decimal degrees.

    Returns:
        Basin with a boolean mask, the requested pour point, and the
        (row, col) pixel coordinates that point resolves to in the grid.
    """
    lat, lon = pour_point
    row, col = lonlat_to_rowcol(lon, lat, grid.transform)
    label_grid = grid.flwdir_raster.basins(xy=(np.array([lon]), np.array([lat])))

    return Basin(
        mask=label_grid > 0,
        pour_point=pour_point,
        pour_pixel=(row, col),
        transform=grid.transform,
        crs=grid.crs,
    )
