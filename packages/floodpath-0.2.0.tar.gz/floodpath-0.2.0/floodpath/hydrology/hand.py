"""Compute Height Above Nearest Drainage (HAND) per cell."""

from floodpath.dem.models import DEM

from .models import FlowGrid, Hand, StreamNetwork


def compute_hand(
    grid: FlowGrid,
    streams: StreamNetwork,
    dem: DEM,
) -> Hand:
    """Compute HAND: vertical distance from each cell to the nearest drainage.

    Internally, the flow direction grid was built on a *filled* DEM
    (priority-flood removes pits), but pyflwdir.hand uses the elevation
    array passed in. Without reconciliation, a handful of cells end up
    with negative HAND because the filled stream sits slightly above the
    raw cell. We pre-process via `dem_adjust`, which enforces monotonically
    decreasing elevation along flow paths, so HAND is non-negative for
    valid cells and stream cells have exactly 0. Cells whose source DEM
    was NaN return the pyflwdir nodata sentinel (a negative value);
    consumers should treat those as 'not part of the drainage' (see
    `damage.compute_inundation_depth`, which masks them out).

    Args:
        grid: FlowGrid produced by build_flow_grid.
        streams: StreamNetwork defining the drainage cells.
        dem: DEM whose elevation values HAND is measured against.

    Returns:
        Hand with per-cell height above nearest drainage in metres.
    """
    adjusted_elev = grid.flwdir_raster.dem_adjust(dem.elevation)
    values = grid.flwdir_raster.hand(
        drain=streams.mask,
        elevtn=adjusted_elev,
    )
    return Hand(
        values=values,
        transform=grid.transform,
        crs=grid.crs,
        bbox=grid.bbox,
        stream_threshold=streams.threshold,
    )
