"""Pure helper functions for the hydrology module."""

import numpy as np
from rasterio.transform import Affine, rowcol

from .constants import DEM_NODATA_SENTINEL


def replace_nan_with_sentinel(
    elevation: np.ndarray,
    sentinel: float = DEM_NODATA_SENTINEL,
) -> np.ndarray:
    """Return a float32 copy of `elevation` with NaN replaced by `sentinel`.

    pyflwdir.from_dem treats nodata as a finite comparison value; NaN
    comparisons always evaluate False, so NaN cells would slip through as
    valid elevations. Swap them out up front.

    Args:
        elevation: 2D elevation array, may contain NaN.
        sentinel: Value substituted for NaN cells.

    Returns:
        New float32 array with NaN replaced.
    """
    return np.where(
        np.isnan(elevation),
        np.float32(sentinel),
        elevation.astype(np.float32),
    )


def lonlat_to_rowcol(
    lon: float,
    lat: float,
    transform: Affine,
) -> tuple[int, int]:
    """Convert geographic (lon, lat) coordinates to integer pixel (row, col).

    Args:
        lon: Longitude in decimal degrees.
        lat: Latitude in decimal degrees.
        transform: Rasterio affine transform of the target raster.

    Returns:
        Tuple `(row, col)` indexed from the top-left of the raster.
    """
    row, col = rowcol(transform, lon, lat)
    return int(row), int(col)
