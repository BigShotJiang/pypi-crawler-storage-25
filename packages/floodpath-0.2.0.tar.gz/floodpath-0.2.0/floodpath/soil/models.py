"""Dataclasses for the soil module."""

from dataclasses import dataclass

import numpy as np
from rasterio.transform import Affine

from floodpath.dem.models import BoundingBox

from .constants import (
    HSG_CLASSES,
    HSG_TO_INT,
    INT_TO_HSG,
    SOILGRIDS_TEXTURE_UNITS,
)


@dataclass
class TextureGrid:
    """Per-cell soil texture composition (sand / silt / clay) as percentages.

    Each of `sand`, `silt`, `clay` is a float32 array in `% by mass`. They
    should sum to ~100 at every cell (SoilGrids predictions can be off by
    1-2 due to independent regression — the texture-triangle classifier is
    robust to that).

    `depths` records which SoilGrids depth slice(s) the values represent;
    when more than one was averaged, the list reflects the depth-weighted
    composition.
    """

    sand: np.ndarray
    silt: np.ndarray
    clay: np.ndarray
    transform: Affine
    crs: str
    bbox: BoundingBox
    depths: tuple[str, ...]
    units: str = SOILGRIDS_TEXTURE_UNITS

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying rasters."""
        return self.sand.shape  # type: ignore[return-value]

    def closure_residual(self) -> np.ndarray:
        """Return per-cell |sand+silt+clay - 100|, useful for diagnostics."""
        return np.abs(self.sand + self.silt + self.clay - 100.0)


@dataclass
class HSGGrid:
    """Per-cell NEH 630 Ch7 hydrologic soil group (A/B/C/D).

    Stored as an integer raster with the encoding in HSG_TO_INT (1=A, 2=B,
    3=C, 4=D, 0=nodata). The `epoch`-equivalent for soil is depth — recorded
    in `depths` so consumers can introspect the assumption.
    """

    values: np.ndarray
    transform: Affine
    crs: str
    bbox: BoundingBox
    depths: tuple[str, ...]
    units: str = "NEH 630 Ch7 HSG (1=A, 2=B, 3=C, 4=D)"

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying raster."""
        return self.values.shape  # type: ignore[return-value]

    def class_counts(self) -> dict[str, int]:
        """Count cells per HSG letter present in the grid (excludes nodata)."""
        out: dict[str, int] = {}
        for letter in HSG_CLASSES:
            n = int(np.count_nonzero(self.values == HSG_TO_INT[letter]))
            if n > 0:
                out[letter] = n
        return out

    def fraction(self, letter: str) -> float:
        """Return the fraction of cells in the given HSG letter."""
        if self.values.size == 0:
            return 0.0
        n = int(np.count_nonzero(self.values == HSG_TO_INT[letter]))
        return float(n / self.values.size)

    def dominant_class(self) -> str:
        """Return the HSG letter with the most cells; raises if grid is empty."""
        counts = self.class_counts()
        if not counts:
            raise ValueError("HSGGrid contains no classified cells")
        return max(counts, key=counts.get)  # type: ignore[arg-type]

    def as_letter_grid(self) -> np.ndarray:
        """Return a US1-string array with HSG letters; nodata becomes empty string."""
        out = np.empty(self.values.shape, dtype="U1")
        for code, letter in INT_TO_HSG.items():
            out[self.values == code] = letter
        return out
