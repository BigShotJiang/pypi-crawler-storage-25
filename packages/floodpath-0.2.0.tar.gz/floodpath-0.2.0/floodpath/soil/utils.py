"""USDA Soil Texture Triangle classification (12 classes).

The boundaries follow the USDA Soil Survey Manual (1993) and Soil Taxonomy
(1999). Each cell of input (sand%, silt%, clay%) maps to exactly one of
the 12 classes in `USDA_TEXTURE_CLASSES`. Inputs need not sum to exactly
100 — silt is computed implicitly so small (~1%) closure errors from
SoilGrids regressions don't affect the classification.

Implementation note: the order of clauses matters because the prose
boundaries overlap at endpoints; the resolution below matches the
canonical online USDA Texture Calculator
(https://www.nrcs.usda.gov/resources/education-and-teaching-materials/soil-texture-calculator).
"""

from __future__ import annotations

import numpy as np


def _ensure_array(x: float | np.ndarray) -> np.ndarray:
    """Convert scalar or array input to a float64 numpy array."""
    return np.asarray(x, dtype=np.float64)


def usda_texture_class(
    sand: float | np.ndarray,
    silt: float | np.ndarray,
    clay: float | np.ndarray,
) -> str | np.ndarray:
    """Classify (sand, silt, clay) percentages into a USDA texture class.

    Args:
        sand: Sand fraction, % by mass. Scalar or array.
        silt: Silt fraction, % by mass. Same shape as `sand`.
        clay: Clay fraction, % by mass. Same shape as `sand`.

    Returns:
        If scalar inputs: a string from USDA_TEXTURE_CLASSES.
        If array inputs: an object array of strings of the same shape.
    """
    s = _ensure_array(sand)
    si = _ensure_array(silt)
    c = _ensure_array(clay)
    scalar = s.ndim == 0

    # Promote scalars to 1-element arrays so the vectorised logic is uniform.
    if scalar:
        s = s.reshape(1)
        si = si.reshape(1)
        c = c.reshape(1)

    out = np.empty(s.shape, dtype=object)
    out[:] = "loam"  # default; should be overwritten by the rules below

    # Order of evaluation: most specific / clay-heavy first, sand-heavy last.
    # Using cumulative `done` mask so later rules don't overwrite earlier
    # assignments — mirrors the USDA Texture Calculator decision tree.
    done = np.zeros(s.shape, dtype=bool)

    def _assign(name: str, mask: np.ndarray) -> None:
        m = mask & ~done
        out[m] = name
        done[m] = True

    # 1. Clay (clay >= 40, sand <= 45, silt < 40).
    _assign("clay", (c >= 40) & (s <= 45) & (si < 40))

    # 2. Silty clay (silt >= 40, clay >= 40).
    _assign("silty_clay", (si >= 40) & (c >= 40))

    # 3. Sandy clay (sand >= 45, clay >= 35).
    _assign("sandy_clay", (s >= 45) & (c >= 35))

    # 4. Clay loam (clay 27-40, sand 20-45).
    _assign("clay_loam", (c >= 27) & (c < 40) & (s > 20) & (s <= 45))

    # 5. Silty clay loam (silt >= 40, clay 27-40).
    _assign("silty_clay_loam", (si >= 40) & (c >= 27) & (c < 40))

    # 6. Sandy clay loam (sand 45-80, clay 20-35, silt < 28).
    _assign(
        "sandy_clay_loam",
        (s > 45) & (c >= 20) & (c < 35) & (si < 28),
    )

    # 7. Loam (clay 7-27, silt 28-50, sand 23-52).
    _assign(
        "loam",
        (c >= 7) & (c < 27) & (si >= 28) & (si < 50) & (s <= 52),
    )

    # 8. Silt (silt >= 80, clay < 12).
    _assign("silt", (si >= 80) & (c < 12))

    # 9. Silt loam (silt >= 50 AND clay 12-27) OR (silt 50-80 AND clay < 12).
    _assign(
        "silt_loam",
        (((si >= 50) & (c >= 12) & (c < 27))
         | ((si >= 50) & (si < 80) & (c < 12))),
    )

    # 10. Sandy loam — three USDA sub-rules combined:
    #     a) sand 43-52 AND silt < 50 AND clay 7-20
    #     b) sand 52-70 AND clay <= 20 AND silt + 2*clay >= 30
    #     c) sand 70-85 AND silt + 2*clay >= 30
    sandy_loam_a = (s >= 43) & (s < 52) & (si < 50) & (c >= 7) & (c < 20)
    sandy_loam_b = (s >= 52) & (s < 70) & (c <= 20) & (si + 2 * c >= 30)
    sandy_loam_c = (s >= 70) & (s < 85) & (si + 2 * c >= 30)
    _assign("sandy_loam", sandy_loam_a | sandy_loam_b | sandy_loam_c)

    # 11. Loamy sand (sand 70-90, clay <= 15, silt + 2*clay < 30
    #                  AND silt + 1.5*clay >= 15).
    _assign(
        "loamy_sand",
        (s >= 70) & (s < 90) & (c <= 15)
        & (si + 2 * c < 30) & (si + 1.5 * c >= 15),
    )

    # 12. Sand (sand >= 85, silt + 1.5*clay < 15).
    _assign("sand", (s >= 85) & (si + 1.5 * c < 15))

    # Anything still unclassified is forced to loam (a textural fallback for
    # combinations slightly outside any class boundary due to closure errors).
    out[~done] = "loam"

    if scalar:
        return str(out[0])
    return out
