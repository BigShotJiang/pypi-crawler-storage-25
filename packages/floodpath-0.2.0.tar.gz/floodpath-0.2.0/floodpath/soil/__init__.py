"""Soil module: hydrologic soil properties from SoilGrids 2.0.

Provides the SOIL half of the SCS-CN runoff parameterisation. Pair with
`floodpath.landuse` to derive a Curve Number raster.
"""

from .constants import (
    HSG_CLASSES,
    HSG_TO_INT,
    INT_TO_HSG,
    SOILGRIDS_DEFAULT_DEPTHS,
    USDA_TEXTURE_CLASSES,
    USDA_TEXTURE_TO_HSG,
)
from .hsg import texture_to_hsg
from .models import HSGGrid, TextureGrid
from .soilgrids import get_soilgrids_texture
from .utils import usda_texture_class

__all__ = [
    "HSGGrid",
    "HSG_CLASSES",
    "HSG_TO_INT",
    "INT_TO_HSG",
    "SOILGRIDS_DEFAULT_DEPTHS",
    "TextureGrid",
    "USDA_TEXTURE_CLASSES",
    "USDA_TEXTURE_TO_HSG",
    "get_soilgrids_texture",
    "texture_to_hsg",
    "usda_texture_class",
]
