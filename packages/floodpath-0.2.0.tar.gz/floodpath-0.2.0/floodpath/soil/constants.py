"""Constants for the soil module."""

from types import MappingProxyType

# --- ISRIC SoilGrids 2.0 (250 m global, COG via WebDAV) --------------------
#
# VRT files reference the underlying COG tiles in Goode Homolosine; GDAL's
# /vsicurl/ + a WarpedVRT projects them to WGS84 on the fly. The bucket
# honours HTTP range requests, so a window read is cheap.

SOILGRIDS_BASE_URL: str = "https://files.isric.org/soilgrids/latest/data"
SOILGRIDS_NATIVE_CRS: str = (
    'PROJCRS["unknown",BASEGEOGCRS["unknown",DATUM["unknown",'
    'ELLIPSOID["WGS 84",6378137,298.257223563,LENGTHUNIT["metre",1]]],'
    'PRIMEM["Greenwich",0,ANGLEUNIT["degree",0.0174532925199433]]],'
    'CONVERSION["unknown",METHOD["Interrupted Goode Homolosine"],'
    'PARAMETER["Longitude of natural origin",0,ANGLEUNIT["degree",0.0174532925199433]],'
    'PARAMETER["False easting",0,LENGTHUNIT["metre",1]],'
    'PARAMETER["False northing",0,LENGTHUNIT["metre",1]]],'
    'CS[Cartesian,2],AXIS["(E)",east,ORDER[1],LENGTHUNIT["metre",1]],'
    'AXIS["(N)",north,ORDER[2],LENGTHUNIT["metre",1]]]'
)
SOILGRIDS_TARGET_CRS: str = "EPSG:4326"

# SoilGrids stores sand/silt/clay as integer g/kg (0-1000). Multiply by 0.1
# to get percent by mass (0-100).
SOILGRIDS_TEXTURE_SCALE: float = 0.1

# SoilGrids nodata sentinel (int16). Cells with this value have no
# prediction (oceans, ice, glaciers, no-cover land). Must be masked
# *before* applying the scale factor or it pollutes downstream stats.
SOILGRIDS_NODATA: int = -32768

# Standard depth slices (in cm) published by SoilGrids 2.0.
SOILGRIDS_DEPTHS: tuple[str, ...] = (
    "0-5cm",
    "5-15cm",
    "15-30cm",
    "30-60cm",
    "60-100cm",
    "100-200cm",
)
# Default depth-weighted topsoil window (0-30 cm). Closest available proxy
# for the 0-50 cm reference depth used in NEH 630 Ch7 Table 7-1.
SOILGRIDS_DEFAULT_DEPTHS: tuple[str, ...] = ("0-5cm", "5-15cm", "15-30cm")
# Width in cm of each depth slice — used as weights when averaging.
SOILGRIDS_DEPTH_WIDTHS_CM: MappingProxyType = MappingProxyType({
    "0-5cm": 5,
    "5-15cm": 10,
    "15-30cm": 15,
    "30-60cm": 30,
    "60-100cm": 40,
    "100-200cm": 100,
})

SOILGRIDS_BUFFER_DEG: float = 0.1
SOILGRIDS_TEXTURE_UNITS: str = "% by mass"


# --- USDA Soil Texture Triangle (12 classes) -------------------------------
#
# Sand / silt / clay in % by mass. Boundaries follow the Soil Survey
# Manual (1993) and Soil Taxonomy 2nd ed. (1999).

USDA_TEXTURE_CLASSES: tuple[str, ...] = (
    "sand",
    "loamy_sand",
    "sandy_loam",
    "loam",
    "silt_loam",
    "silt",
    "sandy_clay_loam",
    "clay_loam",
    "silty_clay_loam",
    "sandy_clay",
    "silty_clay",
    "clay",
)


# --- USDA Texture class -> NEH 630 Ch7 Hydrologic Soil Group ---------------
#
# Source: NRCS National Engineering Handbook Part 630 Chapter 7
# (Hydrologic Soil Groups, January 2009), §630.0701 textural criteria
# in conjunction with §630.0701 prose ("typical" assignment for soils
# with no shallow impermeable layer or high water table).
#
# §630.0701 group definitions:
#   A  <10% clay AND >90% sand or gravel; gravel/sand textures.
#   B  10-20% clay AND 50-90% sand; loamy sand or sandy loam textures.
#   C  20-40% clay AND <50% sand; loam, silt loam, sandy clay loam,
#      clay loam, silty clay loam.
#   D  >40% clay AND <50% sand; clayey textures (clay, silty clay,
#      sandy clay).
#
# A handful of texture classes straddle the prose ranges; we follow the
# most-cited consensus mapping used in SWAT, HEC-HMS, and the Kalyanapu /
# Yu / et-al. global SCS-CN literature.

USDA_TEXTURE_TO_HSG: MappingProxyType = MappingProxyType({
    "sand": "A",
    "loamy_sand": "A",
    "sandy_loam": "B",
    "loam": "B",
    "silt_loam": "B",
    "silt": "B",
    "sandy_clay_loam": "C",
    "clay_loam": "C",
    "silty_clay_loam": "C",
    "sandy_clay": "D",
    "silty_clay": "D",
    "clay": "D",
})

HSG_CLASSES: tuple[str, ...] = ("A", "B", "C", "D")

# Categorical encoding for raster storage. 0 = nodata.
HSG_TO_INT: MappingProxyType = MappingProxyType({"A": 1, "B": 2, "C": 3, "D": 4})
INT_TO_HSG: MappingProxyType = MappingProxyType({v: k for k, v in HSG_TO_INT.items()})

HSG_NODATA: int = 0
HSG_UNITS: str = "NEH 630 Ch7 hydrologic soil group (1=A, 2=B, 3=C, 4=D)"
