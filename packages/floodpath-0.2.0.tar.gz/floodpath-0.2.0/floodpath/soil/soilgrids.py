"""Fetch ISRIC SoilGrids 2.0 soil-property patches via /vsicurl/."""

from concurrent.futures import ThreadPoolExecutor

import numpy as np
import rasterio
from rasterio.enums import Resampling
from rasterio.env import Env
from rasterio.vrt import WarpedVRT
from rasterio.windows import from_bounds
from rasterio.windows import transform as window_transform

from floodpath.dem.constants import GDAL_VSICURL_ENV
from floodpath.dem.models import BoundingBox
from floodpath.dem.utils import bbox_from_point

from .constants import (
    SOILGRIDS_BASE_URL,
    SOILGRIDS_BUFFER_DEG,
    SOILGRIDS_DEFAULT_DEPTHS,
    SOILGRIDS_DEPTH_WIDTHS_CM,
    SOILGRIDS_DEPTHS,
    SOILGRIDS_NODATA,
    SOILGRIDS_TARGET_CRS,
    SOILGRIDS_TEXTURE_SCALE,
)
from .models import TextureGrid


def soilgrids_vrt_url(
    variable: str,
    depth: str,
    statistic: str = "mean",
) -> str:
    """Build the public SoilGrids 2.0 VRT URL.

    Args:
        variable: One of `sand`, `silt`, `clay`, `bdod`, `cec`, ...
        depth: One of SOILGRIDS_DEPTHS, e.g. `5-15cm`.
        statistic: Defaults to `mean`; also `Q0.05`, `Q0.5`, `Q0.95`,
            `uncertainty`.

    Raises:
        ValueError: `depth` is not one of the published slices.
    """
    if depth not in SOILGRIDS_DEPTHS:
        raise ValueError(
            f"depth must be one of {SOILGRIDS_DEPTHS}, got {depth!r}"
        )
    return (
        f"{SOILGRIDS_BASE_URL}/{variable}/"
        f"{variable}_{depth}_{statistic}.vrt"
    )


def _read_warped_window(
    url: str,
    bbox: BoundingBox,
) -> tuple[np.ndarray, "rasterio.transform.Affine"]:
    """Open a SoilGrids VRT, warp to WGS84, return the bbox window + transform.

    SoilGrids native CRS is Interrupted Goode Homolosine. We let GDAL
    decide the destination resolution from the source pixel size projected
    to WGS84 — the ~250 m native pixels become roughly 0.0022° at the
    equator, so a 0.075° patch resolves to ~33 cells.

    Returned data is the raw int16 raster including the SoilGrids nodata
    sentinel (-32768); callers are responsible for masking it.
    """
    with rasterio.open(f"/vsicurl/{url}") as src:
        with WarpedVRT(
            src,
            crs=SOILGRIDS_TARGET_CRS,
            resampling=Resampling.nearest,
        ) as vrt:
            win = from_bounds(*bbox.bounds, transform=vrt.transform)
            # WarpedVRT does not allow boundless reads; SoilGrids is global
            # so any sane bbox is fully inside the source extent.
            data = vrt.read(1, window=win)
            clipped_transform = window_transform(win, vrt.transform)
    return data, clipped_transform


def _scale_texture(raw: np.ndarray) -> np.ndarray:
    """Apply the SoilGrids texture scale, masking nodata to NaN."""
    out = raw.astype(np.float32) * SOILGRIDS_TEXTURE_SCALE
    out[raw == SOILGRIDS_NODATA] = np.nan
    return out


def _fetch_var_at_depth(
    bbox: BoundingBox,
    variable: str,
    depth: str,
) -> tuple[str, str, np.ndarray, "rasterio.transform.Affine"]:
    """Fetch a single (variable, depth) combination. Returns scaled %."""
    url = soilgrids_vrt_url(variable, depth)
    raw, transform = _read_warped_window(url, bbox)
    return variable, depth, _scale_texture(raw), transform


def get_soilgrids_texture(
    lat: float,
    lon: float,
    buffer_deg: float = SOILGRIDS_BUFFER_DEG,
    depths: tuple[str, ...] = SOILGRIDS_DEFAULT_DEPTHS,
) -> TextureGrid:
    """Return depth-weighted soil texture (sand/silt/clay %) around a point.

    The fetcher uses GDAL's `/vsicurl/` driver against the public ISRIC
    bucket (`files.isric.org/soilgrids/latest/data/`) and a `WarpedVRT`
    to reproject from SoilGrids' native Goode Homolosine to WGS84.
    Range-read so payload is on the order of a few hundred KB per call.

    For each depth slice in `depths`, three rasters are fetched
    (sand / silt / clay) — all in parallel via a thread pool, since these
    are I/O-bound. They are then averaged with weights equal to each depth's
    thickness in centimetres so the result represents the bulk topsoil
    composition over the chosen interval. Nodata cells (oceans, glaciers)
    are masked to NaN.

    Args:
        lat: Latitude of the region center, decimal degrees.
        lon: Longitude of the region center, decimal degrees.
        buffer_deg: Half-width of the square bbox around the point, degrees.
        depths: Subset of SOILGRIDS_DEPTHS to average. Default is
            (`0-5cm`, `5-15cm`, `15-30cm`) — the 0-30 cm topsoil window,
            the closest available proxy for the 0-50 cm reference depth
            used in NEH 630 Ch7 Table 7-1.

    Returns:
        TextureGrid with sand/silt/clay arrays in % by mass, NaN where
        SoilGrids has no prediction.

    Raises:
        ValueError: `depths` is empty, or any element is not a published
            SoilGrids slice.
    """
    if not depths:
        raise ValueError("depths must contain at least one slice")
    for d in depths:
        if d not in SOILGRIDS_DEPTHS:
            raise ValueError(
                f"depth {d!r} not in published SoilGrids depths "
                f"{SOILGRIDS_DEPTHS}"
            )

    bbox = bbox_from_point(lat, lon, buffer_deg)

    # Fan out all (variable, depth) pairs to a thread pool. ISRIC tolerates
    # ~10 concurrent connections per client; with 3-9 fetches per call we
    # stay well below that.
    jobs = [(var, depth) for depth in depths for var in ("sand", "silt", "clay")]

    with Env(**GDAL_VSICURL_ENV):
        with ThreadPoolExecutor(max_workers=min(len(jobs), 9)) as pool:
            futures = [
                pool.submit(_fetch_var_at_depth, bbox, var, depth)
                for var, depth in jobs
            ]
            results = [f.result() for f in futures]

    # results is a list of (variable, depth, scaled, transform).
    # Group by variable, depth-weighted average.
    transform = results[0][3]
    by_var: dict[str, dict[str, np.ndarray]] = {"sand": {}, "silt": {}, "clay": {}}
    for var, depth, scaled, _ in results:
        by_var[var][depth] = scaled

    weight_total = float(sum(SOILGRIDS_DEPTH_WIDTHS_CM[d] for d in depths))
    avg: dict[str, np.ndarray] = {}
    for var, depth_to_arr in by_var.items():
        # Use np.nansum so masked nodata cells stay NaN only where every
        # depth was nodata; partially-defined columns get a partial average.
        weighted = np.zeros_like(next(iter(depth_to_arr.values())))
        weight_seen = np.zeros_like(weighted)
        for d in depths:
            arr = depth_to_arr[d]
            w = float(SOILGRIDS_DEPTH_WIDTHS_CM[d])
            valid = ~np.isnan(arr)
            weighted[valid] += w * arr[valid]
            weight_seen[valid] += w
        with np.errstate(invalid="ignore", divide="ignore"):
            avg[var] = np.where(
                weight_seen > 0,
                weighted / weight_seen,
                np.nan,
            )

    return TextureGrid(
        sand=avg["sand"].astype(np.float32),
        silt=avg["silt"].astype(np.float32),
        clay=avg["clay"].astype(np.float32),
        transform=transform,
        crs=SOILGRIDS_TARGET_CRS,
        bbox=BoundingBox(*bbox.bounds),
        depths=tuple(depths),
    )
