"""Map a TextureGrid to a Hydrologic Soil Group (HSG) raster.

Per USDA NRCS NEH Part 630 Chapter 7 §630.0701 (January 2009): each cell's
USDA texture class is looked up in `USDA_TEXTURE_TO_HSG` to assign A/B/C/D.
This is the textural shortcut for the full Table 7-1 criteria (which would
require Ksat, depth-to-impermeable-layer, and water-table data we do not
have globally).

The shortcut assumes "deep" soils with no shallow restrictive layer and
no high water table — appropriate for global SCS-CN runoff modelling at
~250 m. Users with site-calibrated Ksat data should compute HSG directly
from Table 7-1.
"""

import numpy as np

from .constants import (
    HSG_NODATA,
    HSG_TO_INT,
    USDA_TEXTURE_TO_HSG,
)
from .models import HSGGrid, TextureGrid
from .utils import usda_texture_class


def texture_to_hsg(
    texture: TextureGrid,
    mapping: dict[str, str] | None = None,
) -> HSGGrid:
    """Convert a soil texture grid to a hydrologic soil group raster.

    Args:
        texture: Per-cell sand/silt/clay percentages (TextureGrid).
        mapping: Optional override of the USDA-class -> HSG-letter table.
            Defaults to USDA_TEXTURE_TO_HSG (NEH 630 Ch7 §630.0701).

    Returns:
        HSGGrid with int-encoded HSG classes (1=A, 2=B, 3=C, 4=D, 0=nodata).
    """
    table = dict(USDA_TEXTURE_TO_HSG) if mapping is None else dict(mapping)

    # Cells with NaN in any texture component (SoilGrids nodata) cannot be
    # classified — keep them at HSG_NODATA. Pass safe placeholders to the
    # classifier and mask the output afterwards.
    sand = np.where(np.isnan(texture.sand), 0.0, texture.sand)
    silt = np.where(np.isnan(texture.silt), 0.0, texture.silt)
    clay = np.where(np.isnan(texture.clay), 0.0, texture.clay)
    nodata_mask = (
        np.isnan(texture.sand)
        | np.isnan(texture.silt)
        | np.isnan(texture.clay)
    )

    classes = usda_texture_class(sand, silt, clay)
    # `classes` is an object array of texture-class names; map each unique
    # class to its HSG int and apply via fancy indexing.
    hsg_int = np.full(classes.shape, HSG_NODATA, dtype=np.uint8)
    for cls_name, letter in table.items():
        if letter not in HSG_TO_INT:
            raise ValueError(
                f"mapping value {letter!r} is not a valid HSG letter"
            )
        hsg_int[classes == cls_name] = HSG_TO_INT[letter]
    hsg_int[nodata_mask] = HSG_NODATA

    return HSGGrid(
        values=hsg_int,
        transform=texture.transform,
        crs=texture.crs,
        bbox=texture.bbox,
        depths=texture.depths,
    )
