"""Fetch WorldPop constrained 100 m population rasters with local caching."""

import shutil
import urllib.error
import urllib.request
from pathlib import Path

import numpy as np
import rasterio
from rasterio.windows import from_bounds, transform as window_transform

from floodpath.dem.models import BoundingBox
from floodpath.dem.utils import bbox_from_point

from .constants import (
    WORLDPOP_AVAILABLE_YEARS,
    WORLDPOP_BASE_URL,
    WORLDPOP_BUFFER_DEG,
    WORLDPOP_CACHE_DIR,
    WORLDPOP_CRS,
    WORLDPOP_DEFAULT_YEAR,
    WORLDPOP_PRODUCT_VERSION,
    WORLDPOP_UNITS,
)
from .models import ExposureGrid


def worldpop_country_filename(
    country_iso3: str,
    year: int,
) -> str:
    """Filename of the WorldPop GeoTIFF on disk and on the server."""
    return f"{country_iso3.lower()}_ppp_{year}_constrained.tif"


def worldpop_country_url(
    country_iso3: str,
    year: int,
) -> str:
    """Public HTTPS URL for a WorldPop country file."""
    iso3_upper = country_iso3.upper()
    filename = worldpop_country_filename(country_iso3, year)
    return (
        f"{WORLDPOP_BASE_URL}/{year}/{WORLDPOP_PRODUCT_VERSION}/"
        f"{iso3_upper}/{filename}"
    )


def _ensure_country_cached(
    country_iso3: str,
    year: int,
    cache_dir: Path,
) -> Path | None:
    """Return the local GeoTIFF path for a country/year, downloading if absent.

    Returns None if the WorldPop server has no file for that country at that
    year (404).
    """
    filename = worldpop_country_filename(country_iso3, year)
    cached = cache_dir / filename
    if cached.exists():
        return cached

    url = worldpop_country_url(country_iso3, year)
    cache_dir.mkdir(parents=True, exist_ok=True)
    tmp = cache_dir / f"{filename}.partial"

    try:
        with urllib.request.urlopen(url) as resp, open(tmp, "wb") as dst:
            shutil.copyfileobj(resp, dst)
    except urllib.error.HTTPError as exc:
        tmp.unlink(missing_ok=True)
        if exc.code == 404:
            return None
        raise

    tmp.rename(cached)
    return cached


def get_worldpop_population(
    lat: float,
    lon: float,
    country_iso3: str,
    buffer_deg: float = WORLDPOP_BUFFER_DEG,
    year: int = WORLDPOP_DEFAULT_YEAR,
    cache_dir: Path | None = None,
) -> ExposureGrid:
    """Return WorldPop constrained 100 m population for the bbox around a point.

    WorldPop publishes per-country GeoTIFFs at 3 arc-second (~100 m)
    resolution for 2000-2020. Each country file is roughly tens of MB; the
    first call per (country, year) downloads it from data.worldpop.org and
    caches it locally. Subsequent calls read directly from the cache.

    The "constrained" product allocates population only to cells where
    settlement-detection algorithms found buildings — appropriate for
    flood-damage estimation paired with built-up exposure layers.

    Args:
        lat: Latitude of the region center, decimal degrees.
        lon: Longitude of the region center, decimal degrees.
        country_iso3: ISO 3166-1 alpha-3 country code (e.g. "ETH", "USA").
            Required because WorldPop is country-bounded; the bbox must lie
            entirely within this country's footprint.
        buffer_deg: Half-width of the square bbox around the point, degrees.
        year: One of WORLDPOP_AVAILABLE_YEARS (2000-2020 inclusive).
        cache_dir: Where to store country files. Defaults to
            ~/.cache/floodpath/worldpop/.

    Returns:
        ExposureGrid with population per cell.

    Raises:
        ValueError: `year` is outside the available range.
        FileNotFoundError: WorldPop has no file for the requested country/year,
            or the requested bbox falls entirely outside the country's
            published extent (all cells nodata).
    """
    if year not in WORLDPOP_AVAILABLE_YEARS:
        raise ValueError(
            f"year must be one of {WORLDPOP_AVAILABLE_YEARS[0]} to "
            f"{WORLDPOP_AVAILABLE_YEARS[-1]}, got {year}"
        )

    bbox = bbox_from_point(lat, lon, buffer_deg)
    cache = Path(cache_dir) if cache_dir is not None else WORLDPOP_CACHE_DIR

    path = _ensure_country_cached(
        country_iso3=country_iso3,
        year=year,
        cache_dir=cache,
    )
    if path is None:
        raise FileNotFoundError(
            f"No WorldPop file for country={country_iso3!r}, year={year}. "
            "Check the ISO3 code and that WorldPop publishes that year."
        )

    with rasterio.open(path) as src:
        win = from_bounds(*bbox.bounds, transform=src.transform)
        data = src.read(1, window=win, boundless=True, fill_value=src.nodata or 0)
        clipped_transform = window_transform(win, src.transform)
        nodata = src.nodata

    if nodata is not None:
        # Replace WorldPop's nodata sentinel with 0 so callers can sum/etc
        # without special-casing it. The original sentinel is typically a
        # large negative float; clip to >= 0 to be safe.
        data = np.where(data == nodata, 0.0, data)
    data = np.maximum(data, 0.0)

    if not np.any(data > 0):
        raise FileNotFoundError(
            f"WorldPop returned only nodata for bbox {bbox.bounds} in "
            f"{country_iso3.upper()} {year}. Verify the bbox lies inside "
            "the country's published extent."
        )

    return ExposureGrid(
        values=data.astype(np.float32),
        transform=clipped_transform,
        crs=WORLDPOP_CRS,
        bbox=BoundingBox(*bbox.bounds),
        epoch=year,
        units=WORLDPOP_UNITS,
    )
