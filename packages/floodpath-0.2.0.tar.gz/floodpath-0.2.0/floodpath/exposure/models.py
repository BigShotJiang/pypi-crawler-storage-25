"""Dataclasses for the exposure module."""

from dataclasses import dataclass, field
from types import MappingProxyType

import numpy as np
from rasterio.transform import Affine

from floodpath.dem.models import BoundingBox


@dataclass
class ExposureGrid:
    """A raster of exposure values clipped to a bbox.

    `values` carries the per-cell exposure quantity in the unit reported by
    `units` (e.g. m^2 of built-up surface). For temporal sources the
    `epoch` field records which year the data represents; non-temporal
    sources may pass `None`.
    """

    values: np.ndarray
    transform: Affine
    crs: str
    bbox: BoundingBox
    epoch: int | None
    units: str

    @property
    def shape(self) -> tuple[int, int]:
        """Return the (rows, cols) shape of the underlying raster."""
        return self.values.shape  # type: ignore[return-value]


@dataclass(frozen=True)
class BuildingFootprint:
    """One OSM building polygon with metadata.

    `polygon` is an immutable tuple of (lat, lon) vertices in input order
    (the closing duplicate may or may not be present). `area_m2` is the
    polygon's planar area projected with a cos(lat) factor at the centroid
    latitude — accurate to within a fraction of a percent for typical
    building-sized polygons. `tags` is a read-only view of the OSM tag dict
    so the dataclass stays hashable.
    """

    osm_id: int
    polygon: tuple[tuple[float, float], ...]
    area_m2: float
    tags: MappingProxyType  # type: ignore[type-arg]


@dataclass
class BuildingCollection:
    """A bbox-bounded collection of OSM buildings."""

    buildings: tuple[BuildingFootprint, ...] = field(default_factory=tuple)
    bbox: BoundingBox | None = None

    def __len__(self) -> int:
        return len(self.buildings)

    def total_area_m2(self) -> float:
        """Sum of footprint area across all buildings."""
        return float(sum(b.area_m2 for b in self.buildings))
