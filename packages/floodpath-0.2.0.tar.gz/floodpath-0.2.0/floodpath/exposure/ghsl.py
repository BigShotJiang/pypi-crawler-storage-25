"""Fetch GHS-BUILT-S built-up surface rasters with local caching."""

import shutil
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

import rasterio
from rasterio.merge import merge

from floodpath.dem.models import BoundingBox
from floodpath.dem.utils import bbox_from_point

from .constants import (
    DEFAULT_CACHE_DIR,
    GHSL_AVAILABLE_EPOCHS,
    GHSL_BUFFER_DEG,
    GHSL_CRS,
    GHSL_DEFAULT_EPOCH,
    GHSL_UNITS,
)
from .models import ExposureGrid
from .utils import ghsl_tile_filename, ghsl_tile_url, tiles_for_bbox


def _ensure_tile_cached(
    epoch: int,
    row: int,
    col: int,
    cache_dir: Path,
) -> Path | None:
    """Return the local GeoTIFF path for a GHSL tile, downloading if absent.

    The JRC tile zip bundles the GeoTIFF and a documentation PDF; we extract
    only the .tif. Returns None if the tile does not exist on the JRC server
    (404 — typical for ocean tiles).
    """
    filename = ghsl_tile_filename(epoch, row, col)
    cached_tif = cache_dir / filename
    if cached_tif.exists():
        return cached_tif

    url = ghsl_tile_url(epoch, row, col)
    cache_dir.mkdir(parents=True, exist_ok=True)
    tmp_zip = cache_dir / f"{filename}.zip.partial"

    try:
        with urllib.request.urlopen(url) as resp, open(tmp_zip, "wb") as dst:
            shutil.copyfileobj(resp, dst)
    except urllib.error.HTTPError as exc:
        tmp_zip.unlink(missing_ok=True)
        if exc.code == 404:
            return None
        raise

    try:
        with zipfile.ZipFile(tmp_zip) as zf:
            with zf.open(filename) as src, open(cached_tif, "wb") as dst:
                shutil.copyfileobj(src, dst)
    finally:
        tmp_zip.unlink(missing_ok=True)

    return cached_tif


def get_ghsl_built(
    lat: float,
    lon: float,
    buffer_deg: float = GHSL_BUFFER_DEG,
    epoch: int = GHSL_DEFAULT_EPOCH,
    cache_dir: Path | None = None,
) -> ExposureGrid:
    """Return GHS-BUILT-S built-up surface (m^2/cell) for the bbox around a point.

    GHSL R2023A is at ~3 arc-second resolution (~90 m at the equator) and
    is published every 5 years from 1975 to 2030. The first call per
    (epoch, tile) downloads ~22 MB from the JRC server and extracts the
    GeoTIFF to a local cache; subsequent calls read from cache.

    Args:
        lat: Latitude of the region center, decimal degrees.
        lon: Longitude of the region center, decimal degrees.
        buffer_deg: Half-width of the square bbox around the point, degrees.
        epoch: Year of the GHSL product (one of GHSL_AVAILABLE_EPOCHS).
        cache_dir: Where to store extracted tiles. Defaults to
            ~/.cache/floodpath/ghsl/.

    Returns:
        ExposureGrid carrying the m^2 built-up array, georef, and metadata.

    Raises:
        ValueError: `epoch` is not one of the available GHSL epochs.
        FileNotFoundError: No GHSL tile covers the requested bbox.
    """
    if epoch not in GHSL_AVAILABLE_EPOCHS:
        raise ValueError(
            f"epoch must be one of {GHSL_AVAILABLE_EPOCHS}, got {epoch}"
        )

    bbox = bbox_from_point(lat, lon, buffer_deg)
    tiles = tiles_for_bbox(bbox)
    cache = Path(cache_dir) if cache_dir is not None else DEFAULT_CACHE_DIR

    paths: list[Path] = []
    for row, col in tiles:
        path = _ensure_tile_cached(epoch=epoch, row=row, col=col, cache_dir=cache)
        if path is not None:
            paths.append(path)

    if not paths:
        raise FileNotFoundError(
            f"No GHSL R2023A tiles found for bbox {bbox.bounds} at epoch {epoch}. "
            "The region may be ocean or outside global coverage."
        )

    datasets = []
    try:
        for p in paths:
            datasets.append(rasterio.open(p))
        values, transform = merge(datasets, bounds=bbox.bounds)
    finally:
        for ds in datasets:
            ds.close()

    return ExposureGrid(
        values=values[0],
        transform=transform,
        crs=GHSL_CRS,
        bbox=BoundingBox(*bbox.bounds),
        epoch=epoch,
        units=GHSL_UNITS,
    )
