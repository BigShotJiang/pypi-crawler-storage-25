"""Pure helper functions for GHSL tile addressing."""

import math

from floodpath.dem.models import BoundingBox

from .constants import (
    GHSL_BASE_URL,
    GHSL_DIR_TEMPLATE,
    GHSL_PRODUCT_TEMPLATE,
    GHSL_TILE_DEG,
)


def ghsl_tile_id(
    lat: float,
    lon: float,
) -> tuple[int, int]:
    """Return the (row, col) of the 10°x10° GHSL R2023A tile containing the point.

    GHSL R2023A divides the globe into 18 rows (north-to-south) and 36
    columns (west-to-east), 10° each. R1 covers 80–90°N; R18 covers
    -80 to -90°S. C1 covers -180 to -170°E; C36 covers 170–180°E.

    Args:
        lat: Latitude in decimal degrees.
        lon: Longitude in decimal degrees.

    Returns:
        Tuple `(row, col)` with both indices 1-based.
    """
    row = int(math.floor((90.0 - lat) / GHSL_TILE_DEG)) + 1
    col = int(math.floor((lon + 180.0) / GHSL_TILE_DEG)) + 1
    return row, col


def tiles_for_bbox(bbox: BoundingBox) -> list[tuple[int, int]]:
    """Enumerate the GHSL R2023A tiles covering a bbox.

    Walks every interior row/column between the bbox corners, not just the
    four corners — a bbox spanning more than two tiles in either dimension
    must include the interior tiles too.

    Args:
        bbox: Geographic bounding box in WGS84.

    Returns:
        List of `(row, col)` tile IDs (1-based).
    """
    # Tile rows are numbered north-to-south, so the *minimum* row index in
    # a bbox corresponds to the *maximum* latitude.
    row_min = ghsl_tile_id(bbox.max_lat, bbox.min_lon)[0]
    row_max = ghsl_tile_id(bbox.min_lat, bbox.min_lon)[0]
    col_min = ghsl_tile_id(bbox.min_lat, bbox.min_lon)[1]
    col_max = ghsl_tile_id(bbox.min_lat, bbox.max_lon)[1]
    return [
        (r, c)
        for r in range(row_min, row_max + 1)
        for c in range(col_min, col_max + 1)
    ]


def ghsl_tile_filename(
    epoch: int,
    row: int,
    col: int,
) -> str:
    """Filename of the GeoTIFF inside a GHSL tile zip."""
    product = GHSL_PRODUCT_TEMPLATE.format(epoch=epoch)
    return f"{product}_R{row}_C{col}.tif"


def ghsl_tile_url(
    epoch: int,
    row: int,
    col: int,
) -> str:
    """Public HTTPS URL of the per-tile zip on JRC."""
    directory = GHSL_DIR_TEMPLATE.format(epoch=epoch)
    product = GHSL_PRODUCT_TEMPLATE.format(epoch=epoch)
    return f"{GHSL_BASE_URL}/{directory}/V1-0/tiles/{product}_R{row}_C{col}.zip"
