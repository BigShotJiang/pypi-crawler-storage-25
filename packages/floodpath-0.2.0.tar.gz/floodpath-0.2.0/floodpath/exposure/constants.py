"""Constants for the exposure module."""

from pathlib import Path

# JRC GHSL FTP path. Per-tile zips are at:
#   {GHSL_BASE_URL}/{product_dir}/V1-0/tiles/{product_dir}_R{row}_C{col}.zip
GHSL_BASE_URL: str = (
    "https://jeodpp.jrc.ec.europa.eu/ftp/jrc-opendata/GHSL/"
    "GHS_BUILT_S_GLOBE_R2023A"
)

# JRC nests the per-tile zip under a directory whose name lacks the version
# suffix; the file basename includes the version. Use two templates.
GHSL_DIR_TEMPLATE: str = "GHS_BUILT_S_E{epoch}_GLOBE_R2023A_4326_3ss"
GHSL_PRODUCT_TEMPLATE: str = "GHS_BUILT_S_E{epoch}_GLOBE_R2023A_4326_3ss_V1_0"

# JRC publishes GHS-BUILT-S R2023A at five-year intervals from 1975 to 2030.
GHSL_AVAILABLE_EPOCHS: tuple[int, ...] = (
    1975, 1980, 1985, 1990, 1995, 2000,
    2005, 2010, 2015, 2020, 2025, 2030,
)
GHSL_DEFAULT_EPOCH: int = 2020

# GHSL R2023A tiles are 10 deg x 10 deg in WGS84.
GHSL_TILE_DEG: float = 10.0

GHSL_BUFFER_DEG: float = 0.1

GHSL_CRS: str = "EPSG:4326"
GHSL_UNITS: str = "m^2 of built-up surface per cell"

# Per-user cache directory; siblings to other potential exposure sources later.
DEFAULT_CACHE_DIR: Path = Path.home() / ".cache" / "floodpath" / "ghsl"


# --- WorldPop (constrained 100 m population, R2020 maxar_v1) ---------------

WORLDPOP_BASE_URL: str = (
    "https://data.worldpop.org/GIS/Population/Global_2000_2020_Constrained"
)
WORLDPOP_PRODUCT_VERSION: str = "maxar_v1"
WORLDPOP_AVAILABLE_YEARS: tuple[int, ...] = tuple(range(2000, 2021))
WORLDPOP_DEFAULT_YEAR: int = 2020
WORLDPOP_BUFFER_DEG: float = 0.1
WORLDPOP_CRS: str = "EPSG:4326"
WORLDPOP_UNITS: str = "people per cell"

# WorldPop's server does not honour HTTP range requests, so /vsicurl/
# windowed reads are not viable. Download whole country files (~tens of MB)
# on first hit and read windows from the local cache.
WORLDPOP_CACHE_DIR: Path = (
    Path.home() / ".cache" / "floodpath" / "worldpop"
)


# --- OpenStreetMap building footprints via Overpass API --------------------

OVERPASS_URL: str = "https://overpass-api.de/api/interpreter"
OSM_BUFFER_DEG: float = 0.1
OSM_DEFAULT_TIMEOUT_S: int = 60
OSM_USER_AGENT: str = "floodpath/0.1 (research; geospatial pipeline)"
