"""Fetch OSM building footprints via the Overpass API."""

import json
import math
import urllib.error
import urllib.request
from collections.abc import Iterable
from types import MappingProxyType

from floodpath.dem.models import BoundingBox
from floodpath.dem.utils import bbox_from_point

from .constants import (
    OSM_BUFFER_DEG,
    OSM_DEFAULT_TIMEOUT_S,
    OSM_USER_AGENT,
    OVERPASS_URL,
)
from .models import BuildingCollection, BuildingFootprint

# 1 degree of latitude is ~111,320 m at the WGS84 surface; longitude
# converges with cos(lat). Both are exact enough for building-scale
# polygons (the geodesic correction is well below 0.1% at these sizes).
_METRES_PER_DEGREE_LAT: float = 111_320.0


def _build_overpass_query(
    bbox: BoundingBox,
    timeout_seconds: int,
) -> str:
    """Build an Overpass QL query for building ways inside a bbox.

    Returns the geometry of each way so we don't need a second roundtrip
    to fetch node coordinates.
    """
    south = bbox.min_lat
    west = bbox.min_lon
    north = bbox.max_lat
    east = bbox.max_lon
    return (
        f"[out:json][timeout:{timeout_seconds}];"
        f'(way["building"]({south},{west},{north},{east}););'
        f"out body geom;"
    )


def _polygon_area_m2(polygon: Iterable[tuple[float, float]]) -> float:
    """Approximate polygon area in m^2 from (lat, lon) vertices.

    Uses the shoelace formula in a local equirectangular projection
    centred on the polygon's mean latitude. Building-sized polygons see
    sub-0.1% error from this approximation — far below the noise floor of
    the OSM source data itself.
    """
    pts = list(polygon)
    if len(pts) < 3:
        return 0.0
    avg_lat = sum(p[0] for p in pts) / len(pts)
    metres_per_deg_lon = _METRES_PER_DEGREE_LAT * math.cos(math.radians(avg_lat))

    area = 0.0
    n = len(pts)
    for i in range(n):
        lat_i, lon_i = pts[i]
        lat_j, lon_j = pts[(i + 1) % n]
        x_i = lon_i * metres_per_deg_lon
        y_i = lat_i * _METRES_PER_DEGREE_LAT
        x_j = lon_j * metres_per_deg_lon
        y_j = lat_j * _METRES_PER_DEGREE_LAT
        area += x_i * y_j - x_j * y_i
    return abs(area) / 2.0


def _element_to_building(element: dict) -> BuildingFootprint | None:
    """Convert one Overpass element to a BuildingFootprint, or None if invalid."""
    geometry = element.get("geometry")
    if not geometry or len(geometry) < 3:
        return None
    polygon = tuple((float(g["lat"]), float(g["lon"])) for g in geometry)
    return BuildingFootprint(
        osm_id=int(element["id"]),
        polygon=polygon,
        area_m2=_polygon_area_m2(polygon),
        tags=MappingProxyType(dict(element.get("tags", {}))),
    )


def parse_overpass_response(response_json: dict) -> BuildingCollection:
    """Parse a raw Overpass JSON response into a BuildingCollection.

    Exposed as a public helper so test fixtures (saved Overpass responses)
    can be loaded without touching the network.
    """
    buildings: list[BuildingFootprint] = []
    for element in response_json.get("elements", []):
        if element.get("type") != "way":
            continue
        building = _element_to_building(element)
        if building is not None:
            buildings.append(building)
    return BuildingCollection(buildings=tuple(buildings))


def get_osm_buildings(
    lat: float,
    lon: float,
    buffer_deg: float = OSM_BUFFER_DEG,
    timeout_seconds: int = OSM_DEFAULT_TIMEOUT_S,
    overpass_url: str = OVERPASS_URL,
) -> BuildingCollection:
    """Query Overpass for OSM building polygons in the bbox around a point.

    Note: Overpass-API.de has rate limits; do not call this in tight loops.
    For repeated runs over the same area, save the JSON response once and
    reload via `parse_overpass_response`.

    Args:
        lat: Latitude of the region center, decimal degrees.
        lon: Longitude of the region center, decimal degrees.
        buffer_deg: Half-width of the square bbox around the point, degrees.
        timeout_seconds: Overpass query timeout (server-side).
        overpass_url: Override the Overpass endpoint (e.g. for a private
            instance).

    Returns:
        A BuildingCollection holding every building way the server returned
        plus the requested bbox.

    Raises:
        urllib.error.HTTPError: Overpass server returned a non-2xx response
            (e.g. rate limited, malformed query).
    """
    bbox = bbox_from_point(lat, lon, buffer_deg)
    query = _build_overpass_query(bbox=bbox, timeout_seconds=timeout_seconds)

    request = urllib.request.Request(
        overpass_url,
        data=query.encode("utf-8"),
        method="POST",
        headers={
            "Content-Type": "text/plain; charset=utf-8",
            "User-Agent": OSM_USER_AGENT,
        },
    )
    with urllib.request.urlopen(request, timeout=timeout_seconds + 10) as response:
        payload = json.loads(response.read())

    collection = parse_overpass_response(payload)
    return BuildingCollection(buildings=collection.buildings, bbox=bbox)
