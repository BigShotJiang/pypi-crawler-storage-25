# echo-memory

Python SDK for [Echo Memory](https://echo-memory.com) — AI memory infrastructure.

## Install

```bash
pip install echo-memory
```

## Quickstart

```python
from echo_memory import EchoClient

client = EchoClient(api_key="echo_sk_...")

# Store a memory
mem = client.store(
    "Meeting notes: discussed Q2 roadmap with Sarah",
    tags=["meetings", "q2"]
)
print(f"Stored: {mem['id']}")

# Search (hybrid = FTS + vector)
results = client.search("roadmap")
for r in results:
    print(f"  [{r['relevance_score']:.3f}] {r['memory']['content'][:80]}")

# List recent
recent = client.list(limit=5)

# Delete
client.delete(mem["id"])
```

## Search modes

```python
# Full-text search (FTS5, fastest)
client.search("roadmap", mode="fts")

# Semantic search (vector similarity, most relevant)
client.search("roadmap", mode="semantic")

# Hybrid search (combines both, best of both worlds)
client.search("roadmap", mode="hybrid")  # default
```

## Error handling

```python
from echo_memory import EchoClient, AuthenticationError, RateLimitError

try:
    client.store("test")
except AuthenticationError:
    print("Bad API key")
except RateLimitError as e:
    print(f"Rate limited. Retry after {e.retry_after}s")
```
