"""Typed exceptions for the Echo Memory SDK."""


class EchoError(Exception):
    """Base exception for all Echo SDK errors."""

    def __init__(self, message: str, status_code: int = None):
        self.message = message
        self.status_code = status_code
        super().__init__(message)


class AuthenticationError(EchoError):
    """Raised when the API key is invalid or missing."""
    pass


class RateLimitError(EchoError):
    """Raised when rate limit is exceeded. Check retry_after."""

    def __init__(self, message: str, retry_after: int = 5):
        super().__init__(message, status_code=429)
        self.retry_after = retry_after


class NotFoundError(EchoError):
    """Raised when the requested resource doesn't exist."""
    pass


class ValidationError(EchoError):
    """Raised when the request is invalid (bad JSON, missing fields)."""
    pass


class ServerError(EchoError):
    """Raised when the server returns a 5xx error."""
    pass
