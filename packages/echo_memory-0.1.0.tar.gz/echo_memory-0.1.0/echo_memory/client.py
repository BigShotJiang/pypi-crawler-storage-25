"""Echo Memory SDK client."""

import time
from typing import Any, Dict, List, Optional

import httpx

from echo_memory.errors import (
    AuthenticationError,
    EchoError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)


class EchoClient:
    """Client for the Echo Memory API.

    Usage:
        from echo_memory import EchoClient

        client = EchoClient(api_key="echo_sk_...")
        mem = client.store("Meeting notes: discussed Q2 roadmap", tags=["meetings"])
        results = client.search("roadmap")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://echo-memory.fly.dev",
        timeout: float = 30.0,
        max_retries: int = 3,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.max_retries = max_retries
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            headers={
                "X-API-Key": api_key,
                "Content-Type": "application/json",
                "User-Agent": "echo-memory-python/0.1.0",
            },
        )

    def close(self):
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    # --- Core Operations ---

    def store(
        self,
        content: str,
        tags: Optional[List[str]] = None,
        domain: Optional[str] = None,
        session: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Store a new memory.

        Args:
            content: The text content to store.
            tags: Optional list of tags for categorization.
            domain: Optional domain/namespace.
            session: Optional session identifier.

        Returns:
            The created memory dict with id, content, tags, created_at.
        """
        body = {"content": content}
        if tags:
            body["tags"] = tags
        if domain:
            body["domain"] = domain
        if session:
            body["session"] = session

        resp = self._request("POST", "/api/v1/memories", json=body)
        return resp["data"]

    def search(
        self,
        query: str,
        limit: int = 10,
        mode: str = "hybrid",
    ) -> List[Dict[str, Any]]:
        """Search memories.

        Args:
            query: Search query string.
            limit: Maximum results to return (1-100).
            mode: Search mode — "fts" (full-text), "semantic", or "hybrid" (default).

        Returns:
            List of memory results with relevance scores.
        """
        endpoint = {
            "fts": "/api/v1/memories/search",
            "semantic": "/api/v1/memories/semantic-search",
            "hybrid": "/api/v1/memories/hybrid-search",
        }.get(mode, "/api/v1/memories/hybrid-search")

        resp = self._request("GET", endpoint, params={"query": query, "limit": limit})
        return resp["data"]

    def get(self, memory_id: str) -> Dict[str, Any]:
        """Get a single memory by ID.

        Args:
            memory_id: The memory's UUID.

        Returns:
            The memory dict.
        """
        resp = self._request("GET", f"/api/v1/memories/{memory_id}")
        return resp["data"]

    def delete(self, memory_id: str) -> None:
        """Delete a memory by ID.

        Args:
            memory_id: The memory's UUID.
        """
        self._request("DELETE", f"/api/v1/memories/{memory_id}")

    def list(self, limit: int = 20) -> List[Dict[str, Any]]:
        """List recent memories.

        Args:
            limit: Maximum results to return (1-100).

        Returns:
            List of memories sorted by creation time (newest first).
        """
        resp = self._request("GET", "/api/v1/memories", params={"limit": limit})
        return resp["data"]

    def health(self) -> Dict[str, Any]:
        """Check server health."""
        return self._request("GET", "/api/v1/health")

    # --- Internal ---

    def _request(
        self,
        method: str,
        path: str,
        json: Optional[Dict] = None,
        params: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """Make an HTTP request with retry logic."""
        last_error = None

        for attempt in range(self.max_retries + 1):
            try:
                resp = self._client.request(method, path, json=json, params=params)

                if resp.status_code == 429:
                    retry_after = int(resp.headers.get("Retry-After", "5"))
                    if attempt < self.max_retries:
                        time.sleep(retry_after)
                        continue
                    raise RateLimitError("Rate limit exceeded", retry_after=retry_after)

                if resp.status_code == 401:
                    raise AuthenticationError("Invalid or missing API key", status_code=401)

                if resp.status_code == 404:
                    raise NotFoundError("Resource not found", status_code=404)

                if resp.status_code == 400:
                    data = resp.json()
                    raise ValidationError(
                        data.get("error", "Bad request"), status_code=400
                    )

                if resp.status_code >= 500:
                    if attempt < self.max_retries:
                        time.sleep(2 ** attempt)
                        continue
                    raise ServerError(
                        f"Server error ({resp.status_code})",
                        status_code=resp.status_code,
                    )

                return resp.json()

            except httpx.TimeoutException:
                last_error = EchoError("Request timed out")
                if attempt < self.max_retries:
                    time.sleep(2 ** attempt)
                    continue

            except httpx.ConnectError:
                last_error = EchoError("Connection failed")
                if attempt < self.max_retries:
                    time.sleep(2 ** attempt)
                    continue

        raise last_error or EchoError("Request failed after retries")
