"""Echo Memory SDK — Store, search, and retrieve knowledge via API."""

from echo_memory.client import EchoClient
from echo_memory.errors import (
    EchoError,
    AuthenticationError,
    RateLimitError,
    NotFoundError,
    ValidationError,
    ServerError,
)

__version__ = "0.1.0"
__all__ = [
    "EchoClient",
    "EchoError",
    "AuthenticationError",
    "RateLimitError",
    "NotFoundError",
    "ValidationError",
    "ServerError",
]
