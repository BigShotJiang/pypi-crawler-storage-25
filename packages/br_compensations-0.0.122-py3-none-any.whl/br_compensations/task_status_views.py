from allianceauth.services.hooks import get_extension_logger
from django.views.generic import View
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.http import JsonResponse
from .permissions import PERMISSION_CAN_MANAGE

logger = get_extension_logger(__name__)

class TaskStatusView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    View для проверки статуса Celery задачи
    """
    permission_required = f'br_compensations.{PERMISSION_CAN_MANAGE}'
    
    def get(self, request, *args, **kwargs):
        """
        Получение статуса задачи по её ID
        """
        from celery.result import AsyncResult
        
        # Получаем task_id из URL параметров
        task_id = kwargs.get('task_id')
        
        try:
            # Проверяем статус задачи через Celery AsyncResult
            task = AsyncResult(task_id)
            
            # Проверяем, поддерживает ли backend получение статуса
            try:
                status = task.status
            except AttributeError:
                # Backend не поддерживает получение статуса (например, DisabledBackend)
                return JsonResponse({
                    'status': 'UNKNOWN',
                    'result': {'message': 'Backend для хранения результатов не настроен'}
                })
            
            result = None
            
            if status == 'SUCCESS':
                try:
                    result = task.result
                    if isinstance(result, str):
                        import json
                        try:
                            result = json.loads(result)
                        except (json.JSONDecodeError, TypeError):
                            result = {'data': result}
                except Exception as e:
                    result = {'error': f'Ошибка получения результата: {str(e)}'}
            elif status == 'FAILURE':
                result = {'error': str(task.info)}
            elif status == 'PROGRESS':
                try:
                    result = task.info
                    if isinstance(result, str):
                        import json
                        try:
                            result = json.loads(result)
                        except (json.JSONDecodeError, TypeError):
                            result = {'data': result}
                except Exception as e:
                    result = {'error': f'Ошибка получения прогресса: {str(e)}'}
            elif status == 'PENDING':
                result = {'message': 'Задача в очереди на выполнение'}
            elif status == 'RETRY':
                result = {'message': 'Задача повторно выполняется'}
            elif status == 'UNKNOWN':
                result = {'message': 'Статус задачи неизвестен'}
            
            return JsonResponse({
                'status': status,
                'result': result
            })
        except Exception as e:
            logger.error(f'Error getting task status: {e}')
            return JsonResponse({
                'status': 'FAILURE',
                'result': {'error': str(e)}
            }, status=500)