from allianceauth.services.hooks import get_extension_logger
from django.shortcuts import render, redirect
from django.views.generic import TemplateView, View
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.http import JsonResponse
from django.utils.decorators import method_decorator
from .permissions import PERMISSION_CAN_MANAGE
from .forms import AddBrForm
from .models.filterentities import FilterEntity
from .models.battlereport import BattleReport
from .models.killmails import KillCompensation
from .models.charmail import CharMailParse
from eveuniverse.models import EveEntity
from allianceauth.framework.api.user import get_main_character_from_user
from django.conf import settings
from esi.models import Token
from esi.decorators import tokens_required
from django.utils.translation import gettext as _
from django.db.models import Q
from django.db.models import Sum
from esi.views import sso_redirect

logger = get_extension_logger(__name__)
required_scopes = "esi-mail.read_mail.v1 esi-mail.send_mail.v1 esi-ui.open_window.v1"

def request_scopes(request, *args, **kwargs):
    redir = sso_redirect(request, required_scopes.split(' '), 'br_compensations:dashboard')
    return redir

from .dashboard_views import DashboardView
from .reports_views import BattleReportsView
from .mass_action_views import MassActionView
from .task_status_views import TaskStatusView

dashboard = DashboardView.as_view()
reports = BattleReportsView.as_view()
mass_actions = MassActionView.as_view()
tast_status = TaskStatusView.as_view()