from allianceauth.services.hooks import get_extension_logger
from django.views.generic import View
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.http import JsonResponse
from .models.killmails import KillCompensation
from .utils.mailtools import IngameMail
from allianceauth.eveonline.models import EveCharacter
from django.conf import settings
from allianceauth.framework.api.user import get_main_character_from_user
from .permissions import PERMISSION_CAN_MANAGE

logger = get_extension_logger(__name__)

class MassActionView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    View для обработки массовых операций с киллмэйлами
    """
    permission_required = f'br_compensations.{PERMISSION_CAN_MANAGE}'
    
    def post(self, request, *args, **kwargs):
        """
        Обработка массовых операций (синхронная обработка без Celery)
        action: 'approve', 'reject', 'delete', 'restore'
        """
        from .models.killmails import KillCompensation
        from .utils.mailtools import IngameMail
        from allianceauth.eveonline.models import EveCharacter
        from django.conf import settings
        from allianceauth.framework.api.user import get_main_character_from_user
        
        # Получаем список ID киллмэйлов
        if request.content_type == 'application/json':
            import json
            data = json.loads(request.body)
            killmail_ids = data.get('killmail_ids', [])
        else:
            killmail_ids = request.POST.getlist('killmail_ids', [])
        
        if not killmail_ids:
            return JsonResponse({
                'success': False,
                'message': 'Не выбраны киллмэйлы для обработки'
            }, status=400)
        
        # Валидация действия
        allowed_actions = ['approve', 'reject', 'delete', 'restore']
        action = kwargs.get('action')
        if action not in allowed_actions:
            return JsonResponse({
                'success': False,
                'message': f'Недопустимое действие: {action}'
            }, status=400)
        
        try:
            # Получаем текущего персонажа пользователя
            current_character = None
            try:
                current_character = get_main_character_from_user(request.user)
            except Exception as e:
                logger.warning(f'Could not get main character for user {request.user.pk}: {e}')
            
            # Получаем киллмэйлы
            kills = KillCompensation.objects.filter(killmail_id__in=killmail_ids)
            total_count = kills.count()
            updated_count = 0
            deleted_count = 0
            failed_count = 0
            errors = []
            
            logger.info(f'Starting mass action: {action} for {total_count} items by user {request.user}')
            
            # Обрабатываем каждый киллмэйл синхронно
            for kill in kills:
                try:
                    if action == 'approve':
                        # Одобрить компенсацию
                        if kill.status == KillCompensation.STATUS_NEW:
                            kill.status = KillCompensation.STATUS_COMPLETE
                            kill.comment = 'Массовое одобрение администратором'
                            
                            # Отправляем письмо, если есть текущий персонаж
                            if current_character and (request.content_type == 'application/json' and data.get('openMail') == 'true' or request.POST.get('openMail') == 'true'):
                                try:
                                    IngameMail.create_mail(
                                        sender=current_character,
                                        to=[kill.character_id],
                                        subject=('[TEST] ' if settings.DEBUG else '') + "КОМПЕНСАЦИЯ БОЕВЫХ ВЫЛЕТОВ",
                                        body=f"""Уважаемый, <a href=\"showinfo:1377//{kill.character_id}\">{kill.character_name}</a>.

Вам будет выплачена компенсация <a href=\"killReport:{kill.killmail_id}:{kill.hash}\">потери корабля</a> от {kill.timestamp.strftime('%d.%m.%Y, %H:%M')}!
Компенсация будет выслана в виде ISK по оценке ZKB за вычетом страховки и некоторых предметов в карго по типу бустеров.
Если вам не нужна выданная компенсация, либо же она пришла повторно, вы всегда можете отослать иски на <a href=\"showinfo:2//98698983\">Scan Stakan</a>!

С уважением,
<a href=\"showinfo:1377//{current_character.character_id}\">{current_character.character_name}</a>"""
                                    )
                                except Exception as mail_error:
                                    logger.error(f'Failed to send mail for kill {kill.killmail_id}: {mail_error}')
                                
                            kill.save()
                            updated_count += 1
                            logger.debug(f'Approved killmail {kill.killmail_id}')
                    
                    elif action == 'reject':
                        # Отклонить компенсацию
                        if kill.status == KillCompensation.STATUS_NEW:
                            kill.status = KillCompensation.STATUS_REJECT
                            kill.comment = 'Массовое отклонение администратором'
                            
                            # Отправляем письмо, если есть текущий персонаж
                            if current_character and (request.content_type == 'application/json' and data.get('openMail') == 'true' or request.POST.get('openMail') == 'true'):
                                try:
                                    IngameMail.create_mail(
                                        sender=current_character,
                                        to=[kill.character_id],
                                        subject=('[TEST] ' if settings.DEBUG else '') + "ОТКАЗ В КОМПЕНСАЦИИ",
                                        body=f"""Уважаемый, <a href=\"showinfo:1377//{kill.character_id}\">{kill.character_name}</a>.

<a href=\"killReport:{kill.killmail_id}:{kill.hash}\">Потерянный вами корабль</a> от {kill.timestamp.strftime('%d.%m.%Y, %H:%M')} не подпадает под программу компенсации!
В соответствии с правилами компенсации боевых потерь ваш корабль не будет компенсирован.
Если вы не согласны с данным решением, обратитесь к ответственному за компенсации или офицеру альянса.

С уважением,
<a href=\"showinfo:1377//{current_character.character_id}\">{current_character.character_name}</a>"""
                                    )
                                except Exception as mail_error:
                                    logger.error(f'Failed to send mail for kill {kill.killmail_id}: {mail_error}')
                                
                            kill.save()
                            updated_count += 1
                            logger.debug(f'Rejected killmail {kill.killmail_id}')
                    
                    elif action == 'delete':
                        # Удалить киллмэйл
                        kill_id = kill.killmail_id
                        kill.delete()
                        deleted_count += 1
                        logger.debug(f'Deleted killmail {kill_id}')
                    
                    elif action == 'restore':
                        # Восстановить киллмэйл
                        if kill.status in [KillCompensation.STATUS_COMPLETE, KillCompensation.STATUS_REJECT]:
                            kill.status = KillCompensation.STATUS_NEW
                            kill.comment = 'Восстановлено администратором'
                            kill.save()
                            updated_count += 1
                            logger.debug(f'Restored killmail {kill.killmail_id}')
                    
                    else:
                        logger.warning(f'Unknown action: {action}')
                        failed_count += 1
                        
                except Exception as e:
                    logger.error(f'Error processing killmail {kill.killmail_id}: {e}')
                    failed_count += 1
                    errors.append(f'{kill.killmail_id}: {str(e)}')
            
            logger.info(f'Mass action completed: {action}. Updated: {updated_count}, Deleted: {deleted_count}, Failed: {failed_count}')
            
            return JsonResponse({
                'success': True,
                'updated': updated_count,
                'deleted': deleted_count,
                'failed': failed_count,
                'total': total_count,
                'errors': errors[:10],  # Максимум 10 ошибок в ответе
                'message': f'Операция завершена: {updated_count} обновлено, {deleted_count} удалено, {failed_count} ошибок'
            })
        except Exception as e:
            logger.error(f'Error in mass action: {e}')
            return JsonResponse({
                'success': False,
                'message': f'Ошибка при выполнении операции: {str(e)}'
            }, status=500)