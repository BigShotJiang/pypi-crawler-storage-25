from allianceauth.services.hooks import get_extension_logger
from django.shortcuts import redirect
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.views.generic import TemplateView
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from .permissions import PERMISSION_CAN_MANAGE
from .models.filterentities import FilterEntity
from .models.battlereport import BattleReport
from .models.killmails import KillCompensation
from .models.charmail import CharMailParse
from eveuniverse.models import EveEntity
from allianceauth.framework.api.user import get_main_character_from_user
from django.conf import settings
from esi.models import Token
from django.utils.translation import gettext as _
from django.db.models import Sum

logger = get_extension_logger(__name__)

class DashboardView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    template_name = 'br_compensations/dashboard.html'
    permission_required = f'br_compensations.{PERMISSION_CAN_MANAGE}'
    
    def get_context_data(self, filter=None, **kwargs):
        context = super().get_context_data(**kwargs)

        character = get_main_character_from_user(self.request.user)
        charToken = Token.get_token(character.character_id,"esi-mail.read_mail.v1 esi-mail.send_mail.v1 esi-ui.open_window.v1")
        
        if charToken:
            context['scopes_valid'] = True
        else:
            context['scopes_valid'] = False
        
        # Получаем параметр сортировки из GET запроса
        sort_by = self.request.GET.get('sort', '-created_at')
        context['current_sort'] = sort_by
        
        data = []
        dbFilters = FilterEntity.objects.all()
            
        for f in dbFilters:
            entry_icon = ""
            match f.entity_type:
                case FilterEntity.ALLIANCE:
                    entry_icon = f"https://images.evetech.net/alliances/{f.entity_id}/logo?size=32"
                case FilterEntity.CORPORATION:
                    entry_icon = f"https://images.evetech.net/corporations/{f.entity_id}/logo?size=32"
                case FilterEntity.CHARACTER:
                    entry_icon = f"https://images.evetech.net/characters/{f.entity_id}/portrait?size=32"
                case _:
                    entry_icon = ''
                
            try:
                data.append({
                    'filter': {
                        'id': f.entity_id,
                        'type': f.entity_type,
                        },
                    'display_name': str(f),
                    "icon": entry_icon
                })
            except Exception as e:
                logger.error(f"Ошибка при поиске в ESI: {e}")
                try:
                    EveEntity.objects.resolve_name(id=f.entity_id)
                    entry = EveEntity.objects.get(id=f.entity_id)
                
                    data.append({
                        'filter': {
                            'id': f.entity_id,
                            'type': f.entity_type,
                            },
                        'display_name': str(entry),
                        "icon": entry_icon
                    })
                except Exception as e:
                    logger.error(f"Ошибка при поиске в eve universe: {e}")
            
        match filter:
            case 'rejected':
                kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_REJECT).all()
                context['listTitle'] = _('Отмененные компенсации')
            case 'accepted':
                kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_COMPLETE).all()
                context['listTitle'] = _('Выполненные компенсации')
            case 'all':
                kills = KillCompensation.objects.all()
                context['listTitle'] = _('Все компенсации')
            case BattleReport.BATTLEREPORT:
                kills = KillCompensation.objects.filter(source__report_type = BattleReport.BATTLEREPORT, status = KillCompensation.STATUS_NEW).all()
                context['listTitle'] = _('Баттл репорты')
            case BattleReport.KILLMAIL:
                kills = KillCompensation.objects.filter(source__report_type = BattleReport.KILLMAIL, status = KillCompensation.STATUS_NEW).all()
                context['listTitle'] = _('Киллмэйл')
            case _:
                kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_NEW).all()
                context['listTitle'] = _('Текущие компенсации')
        
        context["data"] = sorted(data, key=lambda filter: filter['display_name'])
        context["total_loss"] = kills.aggregate(Sum('loss_value'))['loss_value__sum']
        
        # Применяем сортировку к полному набору данных
        valid_sort_fields = {
            'character_name': 'character_name',
            '-character_name': '-character_name',
            'status': 'status',
            '-status': '-status',
            'loss_value': 'loss_value',
            '-loss_value': '-loss_value',
            'timestamp': 'timestamp',
            '-timestamp': '-timestamp',
            'created_at': 'created_at',
            '-created_at': '-created_at',
        }
        
        if sort_by in valid_sort_fields:
            kills_queryset = kills.order_by(valid_sort_fields[sort_by])
        else:
            kills_queryset = kills.order_by('-created_at', 'status', 'timestamp', '-loss_value')
        
        # Пагинация для killmails
        page_size = 20
        page = self.request.GET.get('page', 1)
        paginator = Paginator(kills_queryset, page_size)
        
        try:
            killmails_page = paginator.page(page)
        except PageNotAnInteger:
            killmails_page = paginator.page(1)
        except EmptyPage:
            killmails_page = paginator.page(paginator.num_pages)
        
        context["killmails"] = killmails_page
        context["is_paginated"] = paginator.num_pages > 1
        context["page_obj"] = killmails_page
        context["paginator"] = paginator
        
        context["mailparser"] = CharMailParse.objects.get(character_id=character.character_id) if character and CharMailParse.objects.filter(character_id = character.character_id).exists() else None
        context["parse_check"] = 'checked' if context['mailparser'] is not None else ''
        context["character_id"] = character.character_id
        context["show_api"] = settings.DEBUG
        
        return context
    
    def post(self, request, *args, **kwargs):
        """
        Обрабатывает POST запросы (например, после выбора персонажа).
        Перенаправляем на GET запрос той же страницы.
        """
        filter_param = kwargs.get('filter', None)
        if filter_param:
            return redirect(f"/br_compensations/dashboard/{filter_param}/")
        return redirect('/br_compensations/dashboard/')