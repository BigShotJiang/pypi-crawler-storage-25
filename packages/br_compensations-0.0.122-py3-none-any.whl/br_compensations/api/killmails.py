from datetime import date
from rest_framework import viewsets
from ..models.killmails import KillCompensation
from .serializers import KillCompensationSrializer
from rest_framework.response import Response
from ..permissions import HasCompensationsPluginAccess
from allianceauth.services.hooks import get_extension_logger
from ..utils.mailtools import IngameMail
from allianceauth.framework.api.user import get_main_character_from_user
from django.conf import settings


logger = get_extension_logger(__name__)

class KillCompensationsViewSet(viewsets.ModelViewSet):
    '''
        API для работы с киллмэйлами
    '''
    queryset = KillCompensation.objects.all()
    serializer_class = KillCompensationSrializer
    permission_classes = [HasCompensationsPluginAccess]
    
    def get_queryset(self):
        """Оптимизация запросов"""
        return super().get_queryset()
    
    def destroy(self,request,pk=None, *args, **kwargs):
        if(pk):
            killmail = KillCompensation.objects.get(killmail_id = pk)
            killmail.delete()
            logger.info(f'Киллмэйл {pk} удален.')
            return Response(status=200)
        return Response(status=404)
    
    def partial_update(self, request, pk=None, *args, **kwargs):
        if pk:
            compense = KillCompensation.objects.get(killmail_id = pk)
            data = request.data
            current_character = get_main_character_from_user(request.user)
            
            if data['status'] == 'C':
                compense.status = KillCompensation.STATUS_COMPLETE
                if (request.content_type == 'application/json' and data.get('openMail') == 'true' or request.POST.get('openMail') == 'true'):
                    IngameMail.create_mail(sender = current_character,
                                        to = [compense.character_id],
                                        subject = ("[TEST] " if settings.DEBUG else "") + "КОМПЕНСАЦИЯ БОЕВЫХ ВЫЛЕТОВ",
                                        body = f"""Уважаемый, <a href="showinfo:1377//{compense.character_id}">{compense.character_name}</a>. 

    Вам будет выплачена компенсация <a href="killReport:{compense.killmail_id}:{compense.hash}">потери корабля</a> от {compense.timestamp.strftime("%d.%m.%Y, %H:%M")}!
    Компенсация будет выслана в виде ISK по оценке ZKB за вычетом страховки и некоторых предметов в карго по типу бустеров.
    Если вам не нужна выданная компенсация, либо же она пришла повторно, вы всегда можете отослать иски на <a href="showinfo:2//98698983">Scan Stakan</a>!

    С уважением,
    <a href="showinfo:1377//{current_character.character_id}">{current_character.character_name}</a>""")
            elif data['status'] == 'R':
                compense.status = KillCompensation.STATUS_REJECT
                if (request.content_type == 'application/json' and data.get('openMail') == 'true' or request.POST.get('openMail') == 'true'):                
                    IngameMail.create_mail(sender = current_character,
                                        to = [compense.character_id],
                                        subject = ('[TEST] ' if settings.DEBUG else '') + 'ОТКАЗ В КОМПЕНСАЦИИ',  
                                        body = f"""Уважаемый, <a href="showinfo:1377//{compense.character_id}">{compense.character_name}</a>. 

    <a href="killReport:{compense.killmail_id}:{compense.hash}">Потерянный вами корабль</a> от {compense.timestamp.strftime("%d.%m.%Y, %H:%M")} не подпадает под программу компенсации!
    В соответствии с правилами компенсации боевых потерь ваш корабль не будет компенсирован.
    Если вы не согласны с данным решением, обратитесь к ответственному за компенсации или офицеру альянса.

    С уважением,
    <a href="showinfo:1377//{current_character.character_id}">{current_character.character_name}</a>""")
            elif data['status'] == 'N':
                compense.status = KillCompensation.STATUS_NEW
            compense.comment = data['comment']
            compense.save()
            return Response(status=200,data=pk)
        return Response(status=404)