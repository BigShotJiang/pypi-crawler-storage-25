from allianceauth.services.hooks import get_extension_logger
from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from .permissions import PERMISSION_CAN_MANAGE
from .forms import AddBrForm
from .models.battlereport import BattleReport
from django.utils.translation import gettext as _
from django.db.models import Q
from django.shortcuts import redirect, render

logger = get_extension_logger(__name__)

class BattleReportsView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    template_name="br_compensations/reports.html"
    permission_required = f'br_compensations.{PERMISSION_CAN_MANAGE}'
    
    def get_context_data(self, filter:str = None, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Получаем параметр сортировки из GET запроса
        sort_by = self.request.GET.get('sort', '-added_at')
        context['current_sort'] = sort_by
        
        match filter:
            case 'complete':
                reports_queryset = BattleReport.objects.filter(status = BattleReport.PROCESS_COMPLETE)
            case 'failed':
                reports_queryset = BattleReport.objects.filter(status = BattleReport.PROCESS_FAILED)
            case 'all':
                reports_queryset = BattleReport.objects.all()
            case _:
                reports_queryset = BattleReport.objects.filter(Q(status = BattleReport.PROCESS_NEW)|Q(status = BattleReport.PROCESS_PROCESSING)|Q(status = BattleReport.PROCESS_REINITIALIZE))
        
        # Применяем сортировку к полному набору данных
        valid_sort_fields = {
            'report_type': 'report_type',
            '-report_type': '-report_type',
            'uid': 'uid',
            '-uid': '-uid',
            'updatedAt': 'updatedAt',
            '-updatedAt': '-updatedAt',
            'comment': 'comment',
            '-comment': '-comment',
            'status': 'status',
            '-status': '-status',
            'added_at': 'added_at',
            '-added_at': '-added_at',
        }
        
        if sort_by in valid_sort_fields:
            reports_queryset = reports_queryset.order_by(valid_sort_fields[sort_by])
        else:
            reports_queryset = reports_queryset.order_by('-added_at', '-updatedAt')
        
        # Пагинация для reports
        page_size = 20
        page = self.request.GET.get('page', 1)
        paginator = Paginator(reports_queryset, page_size)
        
        try:
            reports_page = paginator.page(page)
        except PageNotAnInteger:
            reports_page = paginator.page(1)
        except EmptyPage:
            reports_page = paginator.page(paginator.num_pages)
        
        context["reports"] = reports_page
        context["is_paginated"] = paginator.num_pages > 1
        context["page_obj"] = reports_page
        context["paginator"] = paginator
        context["form"] = AddBrForm()
        context["show_api"] = False
        return context
    
    def post(self,request):
        brForm = AddBrForm(request.POST)
        if brForm.is_valid():
            report = BattleReport(link = brForm.cleaned_data['link'], comment = brForm.cleaned_data['comment'])
            report.save()
            return redirect('/br_compensations/reports/')
        return render(request,'/br_compensations/reports.html',{"form":brForm, "reports": BattleReport.objects.all()})