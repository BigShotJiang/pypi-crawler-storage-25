

class EveKillmail:
    
    def __init__(self, id: int, hash: str, lossValue: float):
        self.id = id
        self.hash = hash
        self.lossValue = lossValue