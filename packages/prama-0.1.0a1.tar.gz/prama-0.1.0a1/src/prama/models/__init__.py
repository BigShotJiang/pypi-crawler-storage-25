from __future__ import annotations

from prama.models.evaluation import WerResult, WerToken, WerUtterance


__all__ = ["WerResult", "WerToken", "WerUtterance"]
