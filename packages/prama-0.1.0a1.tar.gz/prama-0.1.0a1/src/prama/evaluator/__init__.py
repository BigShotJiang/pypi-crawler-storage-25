from __future__ import annotations

from prama.evaluator.evaluator import Evaluator, get_cer, get_wer


__all__ = ["Evaluator", "get_cer", "get_wer"]
