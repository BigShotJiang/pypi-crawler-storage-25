pub mod gltf_io;
pub mod obj;
pub mod usd;

use std::path::Path;

use anvil_reduce_core::half_edge::HalfEdgeMesh;
use anvil_reduce_core::types::Vec3;
use anvil_reduce_core::MeshError;
use thiserror::Error;

/// Hard caps to keep malformed or hostile files from allocating gigabytes
/// before the algorithm pipeline runs.
pub const MAX_VERTICES: usize = 200_000_000;
pub const MAX_TRIANGLES: usize = 400_000_000;

#[derive(Error, Debug)]
pub enum IoError {
    #[error("unsupported format: {0}")]
    UnsupportedFormat(String),
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),
    #[error("mesh construction failed: {0}")]
    Mesh(#[from] MeshError),
    #[error("OBJ parse error: {0}")]
    ObjParse(String),
    #[error("mesh too large: {kind} count {count} exceeds limit {limit}")]
    TooLarge {
        kind: &'static str,
        count: usize,
        limit: usize,
    },
}

/// Validate that a loaded mesh is within hard caps.
pub(crate) fn check_size(positions: usize, indices: usize) -> Result<(), IoError> {
    if positions > MAX_VERTICES {
        return Err(IoError::TooLarge {
            kind: "vertex",
            count: positions,
            limit: MAX_VERTICES,
        });
    }
    if indices > MAX_TRIANGLES {
        return Err(IoError::TooLarge {
            kind: "triangle",
            count: indices,
            limit: MAX_TRIANGLES,
        });
    }
    Ok(())
}

/// Intermediate mesh data returned by format loaders.
pub struct LoadedMesh {
    pub positions: Vec<[f64; 3]>,
    pub indices: Vec<[u32; 3]>,
    /// Per-face-corner UVs (3 per triangle, in face order). None if absent.
    pub corner_uvs: Option<Vec<[f32; 2]>>,
    /// Per-face-corner normals (3 per triangle, in face order). None if absent.
    pub corner_normals: Option<Vec<Vec3>>,
}

/// Data exported from a HalfEdgeMesh for writing.
pub struct ExportMesh {
    pub positions: Vec<[f64; 3]>,
    pub indices: Vec<[u32; 3]>,
    pub corner_uvs: Option<Vec<[f32; 2]>>,
    pub corner_normals: Option<Vec<Vec3>>,
}

pub enum MeshFormat {
    Obj,
    Gltf,
    /// USD ASCII (`.usda`). Round-trip-grade; for full USD support use a
    /// real OpenUSD library and `usdcat` for `.usdc` / `.usdz` conversion.
    Usda,
}

impl MeshFormat {
    pub fn from_extension(path: &Path) -> Option<Self> {
        match path.extension()?.to_str()? {
            "obj" => Some(Self::Obj),
            "gltf" | "glb" => Some(Self::Gltf),
            "usda" => Some(Self::Usda),
            _ => None,
        }
    }
}

/// Load any supported format into raw position/index buffers (no half-edge conversion).
///
/// Use this for meshes that may be non-manifold.
pub fn load_raw(path: &Path) -> Result<LoadedMesh, IoError> {
    let ext = path
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_string();
    let format =
        MeshFormat::from_extension(path).ok_or_else(|| IoError::UnsupportedFormat(ext))?;

    match format {
        MeshFormat::Obj => obj::load(path),
        MeshFormat::Gltf => gltf_io::load(path),
        MeshFormat::Usda => usd::load(path),
    }
}

/// Load any supported format into a HalfEdgeMesh.
pub fn load_mesh(path: &Path) -> Result<HalfEdgeMesh, IoError> {
    let ext = path
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_string();
    let format =
        MeshFormat::from_extension(path).ok_or_else(|| IoError::UnsupportedFormat(ext))?;

    let loaded = match format {
        MeshFormat::Obj => obj::load(path)?,
        MeshFormat::Gltf => gltf_io::load(path)?,
        MeshFormat::Usda => usd::load(path)?,
    };

    let mut mesh =
        HalfEdgeMesh::from_indexed_triangles(&loaded.positions, &loaded.indices)?;
    mesh.set_corner_uvs(loaded.corner_uvs);
    mesh.set_corner_normals(loaded.corner_normals);
    Ok(mesh)
}

/// Write raw positions + indices to a supported format.
pub fn save_raw_mesh(
    positions: &[[f64; 3]],
    indices: &[[u32; 3]],
    path: &Path,
) -> Result<(), IoError> {
    save_raw_mesh_with_attrs(positions, indices, None, None, path)
}

/// Write raw positions + indices, optionally with per-corner UVs and normals.
///
/// Both attribute arrays are laid out per-corner (3 entries per face, in face
/// order). Pass `None` for any attribute that isn't available.
pub fn save_raw_mesh_with_attrs(
    positions: &[[f64; 3]],
    indices: &[[u32; 3]],
    corner_uvs: Option<Vec<[f32; 2]>>,
    corner_normals: Option<Vec<Vec3>>,
    path: &Path,
) -> Result<(), IoError> {
    let ext = path
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_string();
    let format =
        MeshFormat::from_extension(path).ok_or_else(|| IoError::UnsupportedFormat(ext))?;

    let export = ExportMesh {
        positions: positions.to_vec(),
        indices: indices.to_vec(),
        corner_uvs,
        corner_normals,
    };

    match format {
        MeshFormat::Obj => obj::save(path, &export)?,
        MeshFormat::Gltf => gltf_io::save(path, &export)?,
        MeshFormat::Usda => usd::save(path, &export)?,
    }
    Ok(())
}

/// Write a HalfEdgeMesh to any supported format.
pub fn save_mesh(mesh: &HalfEdgeMesh, path: &Path) -> Result<(), IoError> {
    let ext = path
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_string();
    let format =
        MeshFormat::from_extension(path).ok_or_else(|| IoError::UnsupportedFormat(ext))?;

    let (positions, indices) = mesh.to_indexed_triangles();

    // TODO: extract per-corner UVs/normals from half-edges for export
    let export = ExportMesh {
        positions,
        indices,
        corner_uvs: None,
        corner_normals: None,
    };

    match format {
        MeshFormat::Obj => obj::save(path, &export)?,
        MeshFormat::Gltf => gltf_io::save(path, &export)?,
        MeshFormat::Usda => usd::save(path, &export)?,
    }
    Ok(())
}
