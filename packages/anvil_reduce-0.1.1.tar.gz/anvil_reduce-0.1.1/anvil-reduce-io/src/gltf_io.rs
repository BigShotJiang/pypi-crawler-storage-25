//! glTF/GLB read/write support.

use std::path::Path;

use anvil_reduce_core::types::Vec3;

use crate::{check_size, ExportMesh, IoError, LoadedMesh, MAX_TRIANGLES, MAX_VERTICES};

/// Load a glTF or GLB file into intermediate mesh data.
///
/// Merges all meshes/primitives into a single triangle mesh.
pub fn load(path: &Path) -> Result<LoadedMesh, IoError> {
    let (document, buffers, _images) =
        gltf::import(path).map_err(|e| IoError::ObjParse(format!("glTF: {}", e)))?;

    let mut positions: Vec<[f64; 3]> = Vec::new();
    let mut indices: Vec<[u32; 3]> = Vec::new();
    let mut corner_uvs: Vec<[f32; 2]> = Vec::new();
    let mut corner_normals: Vec<Vec3> = Vec::new();
    let mut has_uvs = false;
    let mut has_normals = false;

    for mesh in document.meshes() {
        for primitive in mesh.primitives() {
            if primitive.mode() != gltf::mesh::Mode::Triangles {
                continue;
            }

            let reader = primitive.reader(|buffer| Some(&buffers[buffer.index()]));
            let vert_offset = positions.len() as u32;

            // Positions (required)
            if let Some(pos_iter) = reader.read_positions() {
                for p in pos_iter {
                    if positions.len() >= MAX_VERTICES {
                        return Err(IoError::TooLarge {
                            kind: "vertex",
                            count: positions.len() + 1,
                            limit: MAX_VERTICES,
                        });
                    }
                    positions.push([p[0] as f64, p[1] as f64, p[2] as f64]);
                }
            } else {
                continue;
            }

            // Indices
            let prim_indices: Vec<u32> = if let Some(idx_iter) = reader.read_indices() {
                idx_iter.into_u32().collect()
            } else {
                // Non-indexed: generate sequential indices
                let count = positions.len() as u32 - vert_offset;
                (0..count).collect()
            };

            let n_tris = prim_indices.len() / 3;

            // UVs
            let uvs: Option<Vec<[f32; 2]>> = reader
                .read_tex_coords(0)
                .map(|tc| tc.into_f32().collect());

            // Normals
            let normals: Option<Vec<[f32; 3]>> = reader
                .read_normals()
                .map(|n| n.collect());

            if uvs.is_some() {
                has_uvs = true;
            }
            if normals.is_some() {
                has_normals = true;
            }

            if indices.len().saturating_add(n_tris) > MAX_TRIANGLES {
                return Err(IoError::TooLarge {
                    kind: "triangle",
                    count: indices.len() + n_tris,
                    limit: MAX_TRIANGLES,
                });
            }

            for tri in 0..n_tris {
                let i0 = prim_indices[tri * 3] + vert_offset;
                let i1 = prim_indices[tri * 3 + 1] + vert_offset;
                let i2 = prim_indices[tri * 3 + 2] + vert_offset;
                indices.push([i0, i1, i2]);

                // Per-corner UVs
                if let Some(ref uv_data) = uvs {
                    for k in 0..3 {
                        let vi = prim_indices[tri * 3 + k] as usize;
                        if vi < uv_data.len() {
                            corner_uvs.push(uv_data[vi]);
                        } else {
                            corner_uvs.push([0.0, 0.0]);
                        }
                    }
                } else if has_uvs {
                    for _ in 0..3 {
                        corner_uvs.push([0.0, 0.0]);
                    }
                }

                // Per-corner normals
                if let Some(ref n_data) = normals {
                    for k in 0..3 {
                        let vi = prim_indices[tri * 3 + k] as usize;
                        if vi < n_data.len() {
                            let n = n_data[vi];
                            corner_normals.push(Vec3::new(
                                n[0] as f64,
                                n[1] as f64,
                                n[2] as f64,
                            ));
                        } else {
                            corner_normals.push(Vec3::zeros());
                        }
                    }
                } else if has_normals {
                    for _ in 0..3 {
                        corner_normals.push(Vec3::zeros());
                    }
                }
            }
        }
    }

    if positions.is_empty() {
        return Err(IoError::ObjParse("no triangle meshes found in glTF".into()));
    }

    check_size(positions.len(), indices.len())?;

    Ok(LoadedMesh {
        positions,
        indices,
        corner_uvs: if has_uvs { Some(corner_uvs) } else { None },
        corner_normals: if has_normals {
            Some(corner_normals)
        } else {
            None
        },
    })
}

/// Save mesh data to a GLB (binary glTF) file.
pub fn save(path: &Path, mesh: &ExportMesh) -> Result<(), IoError> {
    use std::io::Write;

    let n_verts = mesh.positions.len();
    let n_tris = mesh.indices.len();

    // Build binary buffer: positions + indices
    let mut bin = Vec::new();

    // Positions (f32 x 3)
    let pos_offset = 0;
    let mut pos_min = [f32::MAX; 3];
    let mut pos_max = [f32::MIN; 3];
    for p in &mesh.positions {
        for k in 0..3 {
            let v = p[k] as f32;
            pos_min[k] = pos_min[k].min(v);
            pos_max[k] = pos_max[k].max(v);
            bin.extend_from_slice(&v.to_le_bytes());
        }
    }
    let pos_len = bin.len() - pos_offset;

    // Pad to 4 bytes
    while bin.len() % 4 != 0 {
        bin.push(0);
    }

    // Indices (u32 x 3)
    let idx_offset = bin.len();
    for tri in &mesh.indices {
        for &i in tri {
            bin.extend_from_slice(&i.to_le_bytes());
        }
    }
    let idx_len = bin.len() - idx_offset;

    // Pad
    while bin.len() % 4 != 0 {
        bin.push(0);
    }

    let total_bin_len = bin.len();

    // Build JSON manually to avoid format! escaping issues
    let json = format!(
        "{{\"asset\":{{\"version\":\"2.0\",\"generator\":\"anvil-reduce\"}},\
         \"buffers\":[{{\"byteLength\":{}}}],\
         \"bufferViews\":[\
           {{\"buffer\":0,\"byteOffset\":{},\"byteLength\":{},\"target\":34962}},\
           {{\"buffer\":0,\"byteOffset\":{},\"byteLength\":{},\"target\":34963}}\
         ],\
         \"accessors\":[\
           {{\"bufferView\":0,\"componentType\":5126,\"count\":{},\"type\":\"VEC3\",\
             \"max\":[{},{},{}],\"min\":[{},{},{}]}},\
           {{\"bufferView\":1,\"componentType\":5125,\"count\":{},\"type\":\"SCALAR\"}}\
         ],\
         \"materials\":[{{\"doubleSided\":true,\"pbrMetallicRoughness\":{{\"baseColorFactor\":[0.8,0.8,0.8,1.0]}}}}],\
         \"meshes\":[{{\"primitives\":[{{\"attributes\":{{\"POSITION\":0}},\"indices\":1,\"material\":0}}]}}],\
         \"nodes\":[{{\"mesh\":0}}],\
         \"scenes\":[{{\"nodes\":[0]}}],\
         \"scene\":0}}",
        total_bin_len,
        pos_offset, pos_len,
        idx_offset, idx_len,
        n_verts,
        pos_max[0], pos_max[1], pos_max[2],
        pos_min[0], pos_min[1], pos_min[2],
        n_tris * 3,
    );

    // GLB structure: header (12) + JSON chunk + BIN chunk
    let json_bytes = json.as_bytes();
    let json_padded_len = (json_bytes.len() + 3) & !3; // pad to 4
    let bin_padded_len = (bin.len() + 3) & !3;
    let total_len = 12 + 8 + json_padded_len + 8 + bin_padded_len;

    let file = std::fs::File::create(path)?;
    let mut w = std::io::BufWriter::new(file);

    // GLB header
    w.write_all(b"glTF")?; // magic
    w.write_all(&2u32.to_le_bytes())?; // version
    w.write_all(&(total_len as u32).to_le_bytes())?; // total length

    // JSON chunk
    w.write_all(&(json_padded_len as u32).to_le_bytes())?;
    w.write_all(&0x4E4F534Au32.to_le_bytes())?; // "JSON"
    w.write_all(json_bytes)?;
    for _ in 0..(json_padded_len - json_bytes.len()) {
        w.write_all(b" ")?;
    }

    // BIN chunk
    w.write_all(&(bin_padded_len as u32).to_le_bytes())?;
    w.write_all(&0x004E4942u32.to_le_bytes())?; // "BIN\0"
    w.write_all(&bin)?;
    for _ in 0..(bin_padded_len - bin.len()) {
        w.write_all(&[0u8])?;
    }

    Ok(())
}
