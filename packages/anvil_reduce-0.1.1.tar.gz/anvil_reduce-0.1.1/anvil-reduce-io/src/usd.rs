//! Minimal USD ASCII (`.usda`) read/write for proxy-mesh use cases.
//!
//! Scope: write a single `Mesh` primitive at the root of a USD layer with
//! `purpose = "proxy"`, so DCCs (Houdini, Maya, Blender) loading the file
//! see the mesh as a proxy automatically. Read support is round-trip-grade
//! — it parses what this module writes — and is deliberately minimal:
//! only `points`, `faceVertexIndices`, and `faceVertexCounts` are extracted
//! from the first `def Mesh` block found.
//!
//! For full USD support (variants, references, payloads, instancing, USDC
//! binary, USDZ packages) use a real USD library. This file is a pragmatic
//! shim for "anvil-reduce → USD layer" workflows.

use std::fs::File;
use std::io::{BufRead, BufReader, BufWriter, Write};
use std::path::Path;

use crate::{ExportMesh, IoError, LoadedMesh};

/// Write a mesh as a USD ASCII layer with a `Mesh` primitive named "proxy"
/// and `purpose = "proxy"`.
pub fn save(path: &Path, mesh: &ExportMesh) -> Result<(), IoError> {
    let file = File::create(path)?;
    let mut w = BufWriter::new(file);

    // Layer header. Keep up-axis Y and meters-per-unit 1 — the most common
    // setup. Real pipelines may want to thread these through CLI flags.
    writeln!(w, "#usda 1.0")?;
    writeln!(w, "(")?;
    writeln!(w, "    defaultPrim = \"proxy\"")?;
    writeln!(w, "    metersPerUnit = 1")?;
    writeln!(w, "    upAxis = \"Y\"")?;
    writeln!(w, ")")?;
    writeln!(w)?;

    writeln!(w, "def Mesh \"proxy\" (")?;
    writeln!(w, "    purpose = \"proxy\"")?;
    writeln!(w, ")")?;
    writeln!(w, "{{")?;
    writeln!(w, "    uniform token subdivisionScheme = \"none\"")?;

    // faceVertexCounts: USD allows ngons, but anvil-reduce always emits
    // triangles, so this is just a Vec of 3s.
    write!(w, "    int[] faceVertexCounts = [")?;
    for i in 0..mesh.indices.len() {
        if i > 0 {
            write!(w, ", ")?;
        }
        write!(w, "3")?;
    }
    writeln!(w, "]")?;

    // faceVertexIndices: flatten the per-triangle [u32; 3] arrays.
    write!(w, "    int[] faceVertexIndices = [")?;
    for (ti, tri) in mesh.indices.iter().enumerate() {
        if ti > 0 {
            write!(w, ", ")?;
        }
        write!(w, "{}, {}, {}", tri[0], tri[1], tri[2])?;
    }
    writeln!(w, "]")?;

    // point3f[]: USD's standard float-precision points attribute.
    write!(w, "    point3f[] points = [")?;
    for (vi, p) in mesh.positions.iter().enumerate() {
        if vi > 0 {
            write!(w, ", ")?;
        }
        write!(w, "({:.6}, {:.6}, {:.6})", p[0], p[1], p[2])?;
    }
    writeln!(w, "]")?;

    // Per-corner normals as a faceVarying-interpolated `normals` attribute.
    // Matches OBJ's `vn` indexed per-face; renderers interpret per-corner
    // automatically.
    if let Some(ref normals) = mesh.corner_normals {
        write!(w, "    normal3f[] normals = [")?;
        for (i, n) in normals.iter().enumerate() {
            if i > 0 {
                write!(w, ", ")?;
            }
            write!(w, "({:.6}, {:.6}, {:.6})", n.x, n.y, n.z)?;
        }
        writeln!(w, "] (")?;
        writeln!(w, "        interpolation = \"faceVarying\"")?;
        writeln!(w, "    )")?;
    }

    // Per-corner UVs as `primvars:st` — the de-facto USD UV-set name for
    // texture coordinates that DCCs (Houdini, Maya, Blender USD plugin)
    // pick up automatically.
    if let Some(ref uvs) = mesh.corner_uvs {
        write!(w, "    texCoord2f[] primvars:st = [")?;
        for (i, uv) in uvs.iter().enumerate() {
            if i > 0 {
                write!(w, ", ")?;
            }
            write!(w, "({:.6}, {:.6})", uv[0], uv[1])?;
        }
        writeln!(w, "] (")?;
        writeln!(w, "        interpolation = \"faceVarying\"")?;
        writeln!(w, "    )")?;
    }

    writeln!(w, "}}")?;
    Ok(())
}

/// Load a USD ASCII layer's first `Mesh` prim into a `LoadedMesh`.
///
/// Round-trip-grade only: handles the format that this module writes.
/// Doesn't follow references, payloads, sublayers, or variants.
pub fn load(path: &Path) -> Result<LoadedMesh, IoError> {
    let file = File::open(path)?;
    let reader = BufReader::new(file);

    // Slurp the file — USD attribute arrays don't always fit on one line,
    // so streaming line-by-line parsing isn't enough; concatenate first.
    let mut text = String::new();
    for line in reader.lines() {
        text.push_str(&line?);
        text.push('\n');
    }

    // Find the first `def Mesh "..."` block. Locate the brace and find
    // its matching close.
    let mesh_start = text
        .find("def Mesh")
        .ok_or_else(|| IoError::ObjParse("USD: no `def Mesh` found".into()))?;
    let body_open = text[mesh_start..]
        .find('{')
        .ok_or_else(|| IoError::ObjParse("USD: malformed Mesh block".into()))?
        + mesh_start;
    let body_close = match_brace(&text, body_open)
        .ok_or_else(|| IoError::ObjParse("USD: unclosed Mesh block".into()))?;
    let body = &text[body_open + 1..body_close];

    let counts = parse_int_array(body, "faceVertexCounts").ok_or_else(|| {
        IoError::ObjParse("USD: faceVertexCounts missing".into())
    })?;
    let face_indices = parse_int_array(body, "faceVertexIndices").ok_or_else(|| {
        IoError::ObjParse("USD: faceVertexIndices missing".into())
    })?;
    let points = parse_point_array(body, "points")
        .ok_or_else(|| IoError::ObjParse("USD: points missing".into()))?;

    // Triangulate ngons by simple fan if any face has > 3 verts.
    let mut indices: Vec<[u32; 3]> = Vec::new();
    let mut cursor = 0usize;
    for &n in &counts {
        let n = n as usize;
        if n < 3 || cursor + n > face_indices.len() {
            return Err(IoError::ObjParse(
                "USD: faceVertexIndices truncated".into(),
            ));
        }
        for k in 1..(n - 1) {
            indices.push([
                face_indices[cursor] as u32,
                face_indices[cursor + k] as u32,
                face_indices[cursor + k + 1] as u32,
            ]);
        }
        cursor += n;
    }

    Ok(LoadedMesh {
        positions: points,
        indices,
        corner_uvs: None,
        corner_normals: None,
    })
}

/// Find the index of the matching `}` for an opening `{` at `open_idx`.
fn match_brace(text: &str, open_idx: usize) -> Option<usize> {
    let bytes = text.as_bytes();
    if bytes[open_idx] != b'{' {
        return None;
    }
    let mut depth = 1i32;
    for (i, &b) in bytes.iter().enumerate().skip(open_idx + 1) {
        match b {
            b'{' => depth += 1,
            b'}' => {
                depth -= 1;
                if depth == 0 {
                    return Some(i);
                }
            }
            _ => {}
        }
    }
    None
}

/// Find `<name> = [...]` and parse the contents as a `Vec<i64>`.
fn parse_int_array(body: &str, name: &str) -> Option<Vec<i64>> {
    let arr = extract_bracket_list(body, name)?;
    let mut out = Vec::new();
    for tok in arr.split(',') {
        let s = tok.trim();
        if s.is_empty() {
            continue;
        }
        out.push(s.parse::<i64>().ok()?);
    }
    Some(out)
}

/// Find `<name> = [(x, y, z), ...]` and parse the tuples as `[f64; 3]`.
fn parse_point_array(body: &str, name: &str) -> Option<Vec<[f64; 3]>> {
    let arr = extract_bracket_list(body, name)?;
    let mut out = Vec::new();
    let mut cursor = 0;
    while let Some(open) = arr[cursor..].find('(') {
        let abs_open = cursor + open;
        let close = arr[abs_open..].find(')')?;
        let inner = &arr[abs_open + 1..abs_open + close];
        let comps: Vec<&str> = inner.split(',').map(|s| s.trim()).collect();
        if comps.len() != 3 {
            return None;
        }
        out.push([
            comps[0].parse::<f64>().ok()?,
            comps[1].parse::<f64>().ok()?,
            comps[2].parse::<f64>().ok()?,
        ]);
        cursor = abs_open + close + 1;
    }
    Some(out)
}

/// Find `<name> = [...]` and return the string between the brackets.
fn extract_bracket_list<'a>(body: &'a str, name: &str) -> Option<&'a str> {
    let key_idx = body.find(name)?;
    let eq = body[key_idx..].find('=')?;
    let open = body[key_idx + eq..].find('[')?;
    let abs_open = key_idx + eq + open;
    let close = body[abs_open..].find(']')?;
    Some(&body[abs_open + 1..abs_open + close])
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_triangle() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("tri.usda");

        let export = ExportMesh {
            positions: vec![[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 1.0, 0.0]],
            indices: vec![[0, 1, 2]],
            corner_uvs: None,
            corner_normals: None,
        };
        save(&path, &export).unwrap();

        let loaded = load(&path).unwrap();
        assert_eq!(loaded.positions.len(), 3);
        assert_eq!(loaded.indices.len(), 1);
        assert_eq!(loaded.indices[0], [0, 1, 2]);
        // Float roundtrip: %.6f precision is plenty for unit cube
        assert!((loaded.positions[0][0] - 0.0).abs() < 1e-5);
        assert!((loaded.positions[1][0] - 1.0).abs() < 1e-5);
        assert!((loaded.positions[2][1] - 1.0).abs() < 1e-5);
    }

    #[test]
    fn roundtrip_quad_split_into_triangles() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("quad.usda");

        let export = ExportMesh {
            positions: vec![
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [1.0, 1.0, 0.0],
                [0.0, 1.0, 0.0],
            ],
            indices: vec![[0, 1, 2], [0, 2, 3]],
            corner_uvs: None,
            corner_normals: None,
        };
        save(&path, &export).unwrap();

        let loaded = load(&path).unwrap();
        assert_eq!(loaded.positions.len(), 4);
        assert_eq!(loaded.indices.len(), 2);
    }

    #[test]
    fn output_contains_proxy_purpose() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("p.usda");

        let export = ExportMesh {
            positions: vec![[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 1.0, 0.0]],
            indices: vec![[0, 1, 2]],
            corner_uvs: None,
            corner_normals: None,
        };
        save(&path, &export).unwrap();

        let content = std::fs::read_to_string(&path).unwrap();
        assert!(content.contains("def Mesh \"proxy\""));
        assert!(content.contains("purpose = \"proxy\""));
        assert!(content.contains("#usda 1.0"));
    }
}
