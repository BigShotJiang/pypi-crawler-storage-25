# anvil-reduce

Volume-based mesh proxy generator: voxelize, marching cubes, smooth, remesh.
Fast, watertight, hands-off. Native Rust core, Python bindings via PyO3.

## Install

```bash
pip install anvil-reduce
```

Inside DCCs:

```bash
mayapy -m pip install anvil-reduce          # Maya
hython -m pip install anvil-reduce          # Houdini
# Blender: install into the addon's bundled Python or vendor the wheel
```

## Quick start

One-shot file pipeline (the path most pipeline TDs want):

```python
from anvil_reduce import proxy_from_path

result = proxy_from_path(
    "hero.obj",
    "hero_proxy.obj",
    quality="balanced",          # "fast" | "balanced" | "high"
    transfer_normals=True,
)
print(f"{result['input_faces']} -> {result['output_faces']} in "
      f"{result['wall_seconds']:.2f}s")
```

NumPy-driven workflow:

```python
import numpy as np
from anvil_reduce import Mesh, generate_proxy

mesh = Mesh.from_numpy(positions, indices)   # (N,3) f64, (M,3) u32
proxy = generate_proxy(mesh, quality="balanced", target_faces=20_000)
positions, indices = proxy.positions(), proxy.indices()
```

## Quality presets

| Preset    | voxel_res | smooth | remesh | sdf  |
|-----------|-----------|--------|--------|------|
| fast      | 64        | 10     | 0      | off  |
| balanced  | 128       | 10     | 3      | off  |
| high      | 256       | 15     | 5      | on   |

Override individual knobs by passing them explicitly. `target_faces` auto-picks
`voxel_res`. `dilation` controls hull tightness (0 = tight, 1-3 = looser).

See <https://github.com/voidreamer/anvil-reduce> for the full project.
