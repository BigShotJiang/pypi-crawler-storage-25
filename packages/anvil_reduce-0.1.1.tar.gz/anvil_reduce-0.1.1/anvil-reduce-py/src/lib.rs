//! Python bindings for anvil-reduce.
//!
//! Two layers of API:
//!   - `Mesh` + numpy-driven functions for users who already have geometry in
//!     memory.
//!   - `proxy_from_path()` one-shot file-to-file pipeline for pipeline TDs who
//!     just want "in.obj -> out.obj" without round-tripping through numpy.

use std::path::PathBuf;
use std::time::Instant;

use numpy::ndarray::Array2;
use numpy::{IntoPyArray, PyArray2, PyReadonlyArray2};
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::PyDict;

use anvil_reduce_core::attribute_transfer::{transfer_attributes, TransferOpts};
use anvil_reduce_core::proxy::ProxySettings;

/// Bundled quality preset matching the CLI: returns
/// (voxel_res, smooth, remesh, use_sdf).
fn apply_quality(name: &str) -> PyResult<(usize, usize, usize, bool)> {
    match name.to_ascii_lowercase().as_str() {
        "fast" => Ok((64, 10, 0, false)),
        "balanced" => Ok((128, 10, 3, false)),
        "high" => Ok((256, 15, 5, true)),
        other => Err(PyValueError::new_err(format!(
            "unknown quality preset {other:?}; expected fast/balanced/high"
        ))),
    }
}

/// Compute voxel_res from a target face count, mirroring the CLI heuristic.
fn voxel_res_for_target(target: usize) -> usize {
    ((target as f64 / 8.5).sqrt() as usize).clamp(8, 1024)
}

/// Resolve the precedence: quality preset wins outright; else target_faces
/// auto-computes voxel_res; else use the explicit knobs.
#[allow(clippy::too_many_arguments)]
fn build_settings(
    quality: Option<&str>,
    target_faces: Option<usize>,
    voxel_res: usize,
    dilation: usize,
    smooth: usize,
    smooth_lambda: f64,
    remesh: usize,
    use_sdf: bool,
    adaptive_remesh: bool,
    bilateral: bool,
    bilateral_sigma_n: f64,
    shrink_fit: f64,
) -> PyResult<ProxySettings> {
    let (vr, sm, rm, sdf) = if let Some(q) = quality {
        apply_quality(q)?
    } else if let Some(t) = target_faces {
        (voxel_res_for_target(t), smooth, remesh, use_sdf)
    } else {
        (voxel_res, smooth, remesh, use_sdf)
    };

    Ok(ProxySettings {
        voxel_resolution: vr,
        dilation,
        smooth_iterations: sm,
        smooth_lambda,
        remesh_iterations: rm,
        use_sdf: sdf,
        adaptive_remesh,
        bilateral,
        bilateral_sigma_n,
        shrink_fit_voxels: shrink_fit,
    })
}

/// A mesh: positions and triangle indices.
///
/// Construct one from numpy arrays via `Mesh.from_numpy(positions, indices)`,
/// from a file via `load(path)`, or get one back from `generate_proxy()`.
#[pyclass]
#[derive(Clone)]
struct Mesh {
    positions: Vec<[f64; 3]>,
    indices: Vec<[u32; 3]>,
}

#[pymethods]
impl Mesh {
    #[getter]
    fn vertex_count(&self) -> usize {
        self.positions.len()
    }

    #[getter]
    fn face_count(&self) -> usize {
        self.indices.len()
    }

    /// Positions as a numpy array of shape (N, 3), float64.
    fn positions<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray2<f64>> {
        let n = self.positions.len();
        let mut arr = Array2::<f64>::zeros((n, 3));
        for (i, p) in self.positions.iter().enumerate() {
            arr[[i, 0]] = p[0];
            arr[[i, 1]] = p[1];
            arr[[i, 2]] = p[2];
        }
        arr.into_pyarray(py)
    }

    /// Triangle indices as a numpy array of shape (M, 3), uint32.
    fn indices<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray2<u32>> {
        let n = self.indices.len();
        let mut arr = Array2::<u32>::zeros((n, 3));
        for (i, tri) in self.indices.iter().enumerate() {
            arr[[i, 0]] = tri[0];
            arr[[i, 1]] = tri[1];
            arr[[i, 2]] = tri[2];
        }
        arr.into_pyarray(py)
    }

    /// Build a Mesh from numpy arrays.
    ///
    /// `positions` must be (N, 3) float64; `indices` must be (M, 3) uint32.
    /// Use `arr.astype(np.float64)` / `arr.astype(np.uint32)` upstream if
    /// your data is in another dtype.
    #[staticmethod]
    fn from_numpy(
        positions: PyReadonlyArray2<f64>,
        indices: PyReadonlyArray2<u32>,
    ) -> PyResult<Self> {
        let pos = positions.as_array();
        let idx = indices.as_array();

        if pos.ncols() != 3 {
            return Err(PyValueError::new_err("positions must have 3 columns"));
        }
        if idx.ncols() != 3 {
            return Err(PyValueError::new_err("indices must have 3 columns"));
        }

        let positions: Vec<[f64; 3]> = (0..pos.nrows())
            .map(|i| [pos[[i, 0]], pos[[i, 1]], pos[[i, 2]]])
            .collect();
        let indices: Vec<[u32; 3]> = (0..idx.nrows())
            .map(|i| [idx[[i, 0]], idx[[i, 1]], idx[[i, 2]]])
            .collect();

        Ok(Mesh { positions, indices })
    }

    fn __repr__(&self) -> String {
        format!(
            "Mesh(vertices={}, faces={})",
            self.positions.len(),
            self.indices.len()
        )
    }
}

/// Load a mesh from a supported format (.obj, .glb, .gltf, .usda).
#[pyfunction]
fn load(path: &str) -> PyResult<Mesh> {
    let p = PathBuf::from(path);
    let loaded = anvil_reduce_io::load_raw(&p)
        .map_err(|e| PyValueError::new_err(format!("{e}")))?;
    Ok(Mesh {
        positions: loaded.positions,
        indices: loaded.indices,
    })
}

/// Save a mesh to a supported format (.obj, .glb, .gltf, .usda).
#[pyfunction]
fn save(mesh: &Mesh, path: &str) -> PyResult<()> {
    let p = PathBuf::from(path);
    anvil_reduce_io::save_raw_mesh(&mesh.positions, &mesh.indices, &p)
        .map_err(|e| PyValueError::new_err(format!("{e}")))?;
    Ok(())
}

/// Generate a volume proxy mesh.
///
/// Args:
///     mesh: Input mesh.
///     quality: "fast", "balanced", or "high". Overrides voxel_res, smooth,
///         remesh, and use_sdf when set.
///     target_faces: Auto-pick voxel_res to hit a target face count. Ignored
///         when `quality` is set.
///     voxel_res: Voxel grid resolution along the longest axis. Default 64.
///     dilation: Volume dilation iterations. 0 = tight wrap, 1-3 = looser
///         hull. Default 1.
///     smooth: Taubin smoothing iterations. Default 10.
///     smooth_lambda: Smoothing strength per iteration. Default 0.5.
///     remesh: Isotropic remeshing iterations. 0 = skip. Default 0.
///     use_sdf: Use signed-distance-field voxelization (smoother output).
///     adaptive_remesh: Curvature-adaptive edge length during remesh.
///     bilateral: Use feature-preserving bilateral smoothing instead of Taubin.
///     bilateral_sigma_n: Bilateral normal weight. Lower = sharper features.
///     shrink_fit: Shrink-fit max displacement in voxel cells. Snaps each
///         proxy vertex inward toward the nearest input vertex to undo
///         voxelization inflation. 0.0 disables. Default 1.5.
///
/// Returns:
///     A new Mesh with the proxy geometry.
#[pyfunction]
#[pyo3(signature = (
    mesh,
    *,
    quality=None,
    target_faces=None,
    voxel_res=64,
    dilation=1,
    smooth=10,
    smooth_lambda=0.5,
    remesh=0,
    use_sdf=false,
    adaptive_remesh=false,
    bilateral=false,
    bilateral_sigma_n=0.3,
    shrink_fit=1.5,
))]
#[allow(clippy::too_many_arguments)]
fn generate_proxy(
    py: Python<'_>,
    mesh: &Mesh,
    quality: Option<&str>,
    target_faces: Option<usize>,
    voxel_res: usize,
    dilation: usize,
    smooth: usize,
    smooth_lambda: f64,
    remesh: usize,
    use_sdf: bool,
    adaptive_remesh: bool,
    bilateral: bool,
    bilateral_sigma_n: f64,
    shrink_fit: f64,
) -> PyResult<Mesh> {
    let settings = build_settings(
        quality,
        target_faces,
        voxel_res,
        dilation,
        smooth,
        smooth_lambda,
        remesh,
        use_sdf,
        adaptive_remesh,
        bilateral,
        bilateral_sigma_n,
        shrink_fit,
    )?;

    // Release the GIL while the Rust pipeline runs so DCC host threads
    // (Maya/Houdini UI) can keep ticking.
    let positions = mesh.positions.clone();
    let indices = mesh.indices.clone();
    let (out_positions, out_indices) = py.allow_threads(|| {
        anvil_reduce_core::generate_proxy_raw(&positions, &indices, &settings)
    });

    Ok(Mesh {
        positions: out_positions,
        indices: out_indices,
    })
}

/// Generate a full LOD chain.
///
/// LOD0 is the original mesh; LOD1..N are progressively coarser proxies.
#[pyfunction]
#[pyo3(signature = (
    mesh,
    *,
    levels=4,
    base_res=128,
    smooth=10,
    remesh=3,
    dilation=1,
    shrink_fit=1.5,
))]
#[allow(clippy::too_many_arguments)]
fn generate_lod_chain(
    py: Python<'_>,
    mesh: &Mesh,
    levels: usize,
    base_res: usize,
    smooth: usize,
    remesh: usize,
    dilation: usize,
    shrink_fit: f64,
) -> PyResult<Vec<Mesh>> {
    if levels == 0 {
        return Ok(vec![]);
    }

    let mut chain = Vec::with_capacity(levels);
    chain.push(mesh.clone());

    let positions = mesh.positions.clone();
    let indices = mesh.indices.clone();

    for level in 1..levels {
        let res = (base_res >> (level - 1)).max(8);
        let settings = ProxySettings {
            voxel_resolution: res,
            dilation,
            smooth_iterations: smooth,
            smooth_lambda: 0.5,
            remesh_iterations: remesh,
            use_sdf: false,
            adaptive_remesh: false,
            bilateral: false,
            bilateral_sigma_n: 0.3,
            shrink_fit_voxels: shrink_fit,
        };

        let (out_positions, out_indices) = py.allow_threads(|| {
            anvil_reduce_core::generate_proxy_raw(&positions, &indices, &settings)
        });

        chain.push(Mesh {
            positions: out_positions,
            indices: out_indices,
        });
    }

    Ok(chain)
}

/// One-shot file-to-file proxy generation.
///
/// Reads the input mesh, runs the proxy pipeline, writes the output, and
/// returns a result dict. The dict mirrors the CLI's audit JSON loosely:
///
///     {
///         "input_path": str,
///         "output_path": str,
///         "input_vertices": int,
///         "input_faces": int,
///         "output_vertices": int,
///         "output_faces": int,
///         "wall_seconds": float,
///     }
///
/// This is the path the average pipeline TD wants: no numpy round-trip.
#[pyfunction]
#[pyo3(signature = (
    input_path,
    output_path,
    *,
    quality=None,
    target_faces=None,
    voxel_res=64,
    dilation=1,
    smooth=10,
    smooth_lambda=0.5,
    remesh=0,
    use_sdf=false,
    adaptive_remesh=false,
    bilateral=false,
    bilateral_sigma_n=0.3,
    shrink_fit=1.5,
    transfer_normals=true,
    transfer_uvs=false,
))]
#[allow(clippy::too_many_arguments)]
fn proxy_from_path<'py>(
    py: Python<'py>,
    input_path: &str,
    output_path: &str,
    quality: Option<&str>,
    target_faces: Option<usize>,
    voxel_res: usize,
    dilation: usize,
    smooth: usize,
    smooth_lambda: f64,
    remesh: usize,
    use_sdf: bool,
    adaptive_remesh: bool,
    bilateral: bool,
    bilateral_sigma_n: f64,
    shrink_fit: f64,
    transfer_normals: bool,
    transfer_uvs: bool,
) -> PyResult<Bound<'py, PyDict>> {
    let settings = build_settings(
        quality,
        target_faces,
        voxel_res,
        dilation,
        smooth,
        smooth_lambda,
        remesh,
        use_sdf,
        adaptive_remesh,
        bilateral,
        bilateral_sigma_n,
        shrink_fit,
    )?;

    let in_path = PathBuf::from(input_path);
    let out_path = PathBuf::from(output_path);
    let start = Instant::now();

    let (input_vertices, input_faces, output_vertices, output_faces) = py
        .allow_threads(|| -> Result<(usize, usize, usize, usize), String> {
            let loaded = anvil_reduce_io::load_raw(&in_path)
                .map_err(|e| format!("load {input_path}: {e}"))?;
            let in_v = loaded.positions.len();
            let in_f = loaded.indices.len();

            let (positions, indices) = anvil_reduce_core::generate_proxy_raw(
                &loaded.positions,
                &loaded.indices,
                &settings,
            );

            let opts = TransferOpts {
                transfer_normals,
                transfer_uvs,
            };
            let transfer = transfer_attributes(
                &loaded.positions,
                &loaded.indices,
                loaded.corner_normals.as_deref(),
                loaded.corner_uvs.as_deref(),
                &positions,
                &indices,
                &opts,
            );

            anvil_reduce_io::save_raw_mesh_with_attrs(
                &positions,
                &indices,
                transfer.corner_uvs,
                transfer.corner_normals,
                &out_path,
            )
            .map_err(|e| format!("save {output_path}: {e}"))?;

            Ok((in_v, in_f, positions.len(), indices.len()))
        })
        .map_err(PyValueError::new_err)?;

    let elapsed = start.elapsed().as_secs_f64();

    let dict = PyDict::new(py);
    dict.set_item("input_path", input_path)?;
    dict.set_item("output_path", output_path)?;
    dict.set_item("input_vertices", input_vertices)?;
    dict.set_item("input_faces", input_faces)?;
    dict.set_item("output_vertices", output_vertices)?;
    dict.set_item("output_faces", output_faces)?;
    dict.set_item("wall_seconds", elapsed)?;
    Ok(dict)
}

/// anvil_reduce: high-performance volume mesh proxy generator.
#[pymodule]
fn anvil_reduce(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add("__version__", env!("CARGO_PKG_VERSION"))?;
    m.add_class::<Mesh>()?;
    m.add_function(wrap_pyfunction!(load, m)?)?;
    m.add_function(wrap_pyfunction!(save, m)?)?;
    m.add_function(wrap_pyfunction!(generate_proxy, m)?)?;
    m.add_function(wrap_pyfunction!(generate_lod_chain, m)?)?;
    m.add_function(wrap_pyfunction!(proxy_from_path, m)?)?;
    Ok(())
}
