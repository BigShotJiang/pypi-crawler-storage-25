//! Attribute transfer from a high-resolution input mesh to a low-resolution
//! proxy mesh.
//!
//! For each output proxy face corner, the nearest input vertex is found via
//! a uniform 3D grid spatial index, and that vertex's normal (and optionally
//! UV) is copied. Turns the proxy from a collision-only mesh into something
//! you can shade — preserves the input's smoothing groups + texture mapping
//! "smear" through the proxy.
//!
//! v1 limitations:
//! - **Nearest-vertex** lookup, not nearest-point-on-triangle. For dense
//!   input meshes this is accurate enough; upgrade later if needed.
//! - **One representative UV per input vertex.** Vertices that appear in
//!   multiple face-corners with different UVs (i.e., on UV seams) keep one
//!   arbitrary corner's UV. Documented as approximate-on-seams.

use rayon::prelude::*;

use crate::types::Vec3;

/// Options for `transfer_attributes`.
#[derive(Clone, Debug, Default)]
pub struct TransferOpts {
    /// Sample input normals at the nearest input vertex.
    pub transfer_normals: bool,
    /// Sample input UVs at the nearest input vertex (approximate on seams).
    pub transfer_uvs: bool,
}

/// Result of an attribute-transfer pass — corner-laid-out arrays matching the
/// proxy's `indices.len() * 3` corners.
pub struct TransferResult {
    pub corner_normals: Option<Vec<Vec3>>,
    pub corner_uvs: Option<Vec<[f32; 2]>>,
}

/// 3D uniform-grid spatial index over a set of points.
///
/// Bucketed for O(1)-amortized nearest-point queries assuming roughly uniform
/// point density. Grid cell size is auto-chosen to put ~16-32 points per cell
/// on average — small enough that the per-cell brute-force search stays fast,
/// large enough that the cell array doesn't dominate memory.
pub struct UniformGrid {
    cell_size: f64,
    inv_cell_size: f64,
    origin: Vec3,
    res: [usize; 3],
    /// Flat array of cells, each holding indices into `points`.
    cells: Vec<Vec<u32>>,
    /// The original points; queries return indices into this.
    points: Vec<Vec3>,
}

impl UniformGrid {
    /// Build a uniform grid over `points`.
    pub fn build(points: &[[f64; 3]]) -> Self {
        if points.is_empty() {
            return Self {
                cell_size: 1.0,
                inv_cell_size: 1.0,
                origin: Vec3::zeros(),
                res: [1, 1, 1],
                cells: vec![Vec::new()],
                points: Vec::new(),
            };
        }

        let mut bmin = Vec3::new(f64::MAX, f64::MAX, f64::MAX);
        let mut bmax = Vec3::new(f64::MIN, f64::MIN, f64::MIN);
        for p in points {
            let v = Vec3::new(p[0], p[1], p[2]);
            bmin = bmin.inf(&v);
            bmax = bmax.sup(&v);
        }
        let extent = bmax - bmin;
        let longest = extent.x.max(extent.y).max(extent.z).max(1e-12);

        // Aim for ~25 points/cell on average. With N points in volume V,
        // cell volume = V / (N/25), so cell side = (longest^3 / (N/25))^(1/3)
        // for roughly cubic cells.
        let target_per_cell = 25.0;
        let n_cells = (points.len() as f64 / target_per_cell).max(1.0);
        let cell_side = (longest.powi(3) / n_cells).cbrt();
        let cell_size = cell_side.max(longest / 1024.0);

        let inv_cell_size = 1.0 / cell_size;
        let rx = ((extent.x * inv_cell_size).ceil() as usize).max(1);
        let ry = ((extent.y * inv_cell_size).ceil() as usize).max(1);
        let rz = ((extent.z * inv_cell_size).ceil() as usize).max(1);
        let n = rx * ry * rz;

        let mut cells: Vec<Vec<u32>> = vec![Vec::new(); n];
        let stored: Vec<Vec3> = points
            .iter()
            .map(|p| Vec3::new(p[0], p[1], p[2]))
            .collect();
        for (i, p) in stored.iter().enumerate() {
            let (cx, cy, cz) = bucket_for(*p, bmin, inv_cell_size, [rx, ry, rz]);
            let idx = cx + cy * rx + cz * rx * ry;
            cells[idx].push(i as u32);
        }

        Self {
            cell_size,
            inv_cell_size,
            origin: bmin,
            res: [rx, ry, rz],
            cells,
            points: stored,
        }
    }

    /// Find the index of the point nearest to `query`. Returns `None` if the
    /// grid is empty.
    pub fn query_nearest(&self, query: Vec3) -> Option<u32> {
        if self.points.is_empty() {
            return None;
        }
        let [rx, ry, rz] = self.res;
        let (qx, qy, qz) = bucket_for(query, self.origin, self.inv_cell_size, self.res);

        // Walk outward in expanding shells until at least one candidate is
        // found, then keep walking one more shell to guarantee the nearest
        // wasn't just outside the current radius.
        let mut best_dist_sq = f64::INFINITY;
        let mut best_idx: Option<u32> = None;
        let mut radius = 0i32;
        let max_radius = rx.max(ry).max(rz) as i32 + 1;

        loop {
            let lo_x = (qx as i32 - radius).max(0) as usize;
            let hi_x = (qx as i32 + radius + 1).min(rx as i32) as usize;
            let lo_y = (qy as i32 - radius).max(0) as usize;
            let hi_y = (qy as i32 + radius + 1).min(ry as i32) as usize;
            let lo_z = (qz as i32 - radius).max(0) as usize;
            let hi_z = (qz as i32 + radius + 1).min(rz as i32) as usize;

            for cz in lo_z..hi_z {
                for cy in lo_y..hi_y {
                    for cx in lo_x..hi_x {
                        // Skip cells we already scanned at smaller radii.
                        if radius > 0 {
                            let dx = (cx as i32 - qx as i32).abs();
                            let dy = (cy as i32 - qy as i32).abs();
                            let dz = (cz as i32 - qz as i32).abs();
                            if dx < radius && dy < radius && dz < radius {
                                continue;
                            }
                        }
                        let idx = cx + cy * rx + cz * rx * ry;
                        for &pi in &self.cells[idx] {
                            let p = self.points[pi as usize];
                            let d = (query - p).norm_squared();
                            if d < best_dist_sq {
                                best_dist_sq = d;
                                best_idx = Some(pi);
                            }
                        }
                    }
                }
            }

            // Exit condition: we have a candidate AND we've walked one shell
            // past it (to ensure it's actually the global minimum).
            if best_idx.is_some() {
                let best_dist = best_dist_sq.sqrt();
                let radius_world = (radius as f64) * self.cell_size;
                if best_dist <= radius_world {
                    break;
                }
            }
            if radius >= max_radius {
                break;
            }
            radius += 1;
        }

        best_idx
    }
}

fn bucket_for(p: Vec3, origin: Vec3, inv_cell_size: f64, res: [usize; 3]) -> (usize, usize, usize) {
    let local = p - origin;
    let cx = ((local.x * inv_cell_size).floor() as i64)
        .clamp(0, res[0] as i64 - 1) as usize;
    let cy = ((local.y * inv_cell_size).floor() as i64)
        .clamp(0, res[1] as i64 - 1) as usize;
    let cz = ((local.z * inv_cell_size).floor() as i64)
        .clamp(0, res[2] as i64 - 1) as usize;
    (cx, cy, cz)
}

/// Aggregate per-corner attributes to per-vertex. Each input vertex gets the
/// area-weighted average normal and the first encountered UV.
fn aggregate_per_vertex(
    n_vertices: usize,
    indices: &[[u32; 3]],
    corner_normals: Option<&[Vec3]>,
    corner_uvs: Option<&[[f32; 2]]>,
    positions: &[[f64; 3]],
) -> (Option<Vec<Vec3>>, Option<Vec<[f32; 2]>>) {
    // Per-vertex normals: aggregate from corner normals (if present) or
    // synthesize from face geometry.
    let normals_out: Option<Vec<Vec3>> = {
        let mut v_normals: Vec<Vec3> = vec![Vec3::zeros(); n_vertices];
        if let Some(cn) = corner_normals {
            for (fi, tri) in indices.iter().enumerate() {
                for k in 0..3 {
                    let v = tri[k] as usize;
                    if fi * 3 + k < cn.len() && v < n_vertices {
                        v_normals[v] += cn[fi * 3 + k];
                    }
                }
            }
        } else {
            // Area-weighted face normals.
            for tri in indices {
                let v0 = tri[0] as usize;
                let v1 = tri[1] as usize;
                let v2 = tri[2] as usize;
                if v0 >= n_vertices || v1 >= n_vertices || v2 >= n_vertices {
                    continue;
                }
                let p0 = Vec3::new(
                    positions[v0][0],
                    positions[v0][1],
                    positions[v0][2],
                );
                let p1 = Vec3::new(
                    positions[v1][0],
                    positions[v1][1],
                    positions[v1][2],
                );
                let p2 = Vec3::new(
                    positions[v2][0],
                    positions[v2][1],
                    positions[v2][2],
                );
                let n = (p1 - p0).cross(&(p2 - p0));
                v_normals[v0] += n;
                v_normals[v1] += n;
                v_normals[v2] += n;
            }
        }
        for n in &mut v_normals {
            let len = n.norm();
            if len > 1e-12 {
                *n /= len;
            } else {
                *n = Vec3::new(0.0, 1.0, 0.0);
            }
        }
        Some(v_normals)
    };

    let uvs_out: Option<Vec<[f32; 2]>> = corner_uvs.map(|cu| {
        let mut v_uvs: Vec<[f32; 2]> = vec![[0.0, 0.0]; n_vertices];
        let mut have = vec![false; n_vertices];
        for (fi, tri) in indices.iter().enumerate() {
            for k in 0..3 {
                let v = tri[k] as usize;
                if v < n_vertices && fi * 3 + k < cu.len() && !have[v] {
                    v_uvs[v] = cu[fi * 3 + k];
                    have[v] = true;
                }
            }
        }
        v_uvs
    });

    (normals_out, uvs_out)
}

/// Compute proxy-own per-corner normals from geometry (area-weighted face
/// normals aggregated to vertices, then re-emitted per corner).
fn proxy_own_corner_normals(
    proxy_positions: &[[f64; 3]],
    proxy_indices: &[[u32; 3]],
) -> Vec<Vec3> {
    let n_v = proxy_positions.len();
    let mut v_normals: Vec<Vec3> = vec![Vec3::zeros(); n_v];
    for tri in proxy_indices {
        let v0 = tri[0] as usize;
        let v1 = tri[1] as usize;
        let v2 = tri[2] as usize;
        let p0 = Vec3::new(
            proxy_positions[v0][0],
            proxy_positions[v0][1],
            proxy_positions[v0][2],
        );
        let p1 = Vec3::new(
            proxy_positions[v1][0],
            proxy_positions[v1][1],
            proxy_positions[v1][2],
        );
        let p2 = Vec3::new(
            proxy_positions[v2][0],
            proxy_positions[v2][1],
            proxy_positions[v2][2],
        );
        let n = (p1 - p0).cross(&(p2 - p0));
        v_normals[v0] += n;
        v_normals[v1] += n;
        v_normals[v2] += n;
    }
    for n in &mut v_normals {
        let len = n.norm();
        if len > 1e-12 {
            *n /= len;
        } else {
            *n = Vec3::new(0.0, 1.0, 0.0);
        }
    }
    let mut out: Vec<Vec3> = Vec::with_capacity(proxy_indices.len() * 3);
    for tri in proxy_indices {
        for k in 0..3 {
            out.push(v_normals[tri[k] as usize]);
        }
    }
    out
}

/// Sample input attributes onto the proxy via nearest-input-vertex lookup.
///
/// - `transfer_normals` enabled: returns per-corner normals sampled from the
///   nearest input vertex. If the input has no normals, computes them from
///   input geometry first.
/// - `transfer_normals` disabled: returns per-corner normals computed from
///   the proxy's own geometry (so the output is shadable regardless).
/// - `transfer_uvs` enabled: returns per-corner UVs from the nearest input
///   vertex. Approximate near UV seams.
pub fn transfer_attributes(
    input_positions: &[[f64; 3]],
    input_indices: &[[u32; 3]],
    input_corner_normals: Option<&[Vec3]>,
    input_corner_uvs: Option<&[[f32; 2]]>,
    proxy_positions: &[[f64; 3]],
    proxy_indices: &[[u32; 3]],
    opts: &TransferOpts,
) -> TransferResult {
    if !opts.transfer_normals && !opts.transfer_uvs {
        return TransferResult {
            corner_normals: Some(proxy_own_corner_normals(proxy_positions, proxy_indices)),
            corner_uvs: None,
        };
    }

    let need_uv = opts.transfer_uvs && input_corner_uvs.is_some();
    let need_input_lookup = opts.transfer_normals || need_uv;

    if !need_input_lookup {
        return TransferResult {
            corner_normals: Some(proxy_own_corner_normals(proxy_positions, proxy_indices)),
            corner_uvs: None,
        };
    }

    let (vertex_normals, vertex_uvs) = aggregate_per_vertex(
        input_positions.len(),
        input_indices,
        input_corner_normals,
        if need_uv { input_corner_uvs } else { None },
        input_positions,
    );

    let grid = UniformGrid::build(input_positions);

    let n_corners = proxy_indices.len() * 3;
    let mut corner_normals: Option<Vec<Vec3>> = if opts.transfer_normals {
        Some(vec![Vec3::zeros(); n_corners])
    } else {
        None
    };
    let mut corner_uvs: Option<Vec<[f32; 2]>> = if need_uv {
        Some(vec![[0.0, 0.0]; n_corners])
    } else {
        None
    };

    // Parallel over proxy faces: each face writes 3 contiguous corner slots.
    if let Some(ref mut cn) = corner_normals {
        cn.par_chunks_exact_mut(3)
            .zip(proxy_indices.par_iter())
            .for_each(|(slot, tri)| {
                for k in 0..3 {
                    let v = tri[k] as usize;
                    let pos = Vec3::new(
                        proxy_positions[v][0],
                        proxy_positions[v][1],
                        proxy_positions[v][2],
                    );
                    let nearest = grid.query_nearest(pos);
                    if let Some(idx) = nearest {
                        slot[k] = vertex_normals
                            .as_ref()
                            .map(|vn| vn[idx as usize])
                            .unwrap_or_else(|| Vec3::new(0.0, 1.0, 0.0));
                    }
                }
            });
    }

    if let Some(ref mut cu) = corner_uvs {
        let vuv = vertex_uvs.as_ref().expect("uv aggregation succeeded");
        cu.par_chunks_exact_mut(3)
            .zip(proxy_indices.par_iter())
            .for_each(|(slot, tri)| {
                for k in 0..3 {
                    let v = tri[k] as usize;
                    let pos = Vec3::new(
                        proxy_positions[v][0],
                        proxy_positions[v][1],
                        proxy_positions[v][2],
                    );
                    if let Some(idx) = grid.query_nearest(pos) {
                        slot[k] = vuv[idx as usize];
                    }
                }
            });
    }

    TransferResult {
        corner_normals,
        corner_uvs,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn uniform_grid_finds_nearest() {
        let pts: Vec<[f64; 3]> = vec![
            [0.0, 0.0, 0.0],
            [10.0, 0.0, 0.0],
            [5.0, 5.0, 5.0],
            [-3.0, -2.0, 1.0],
        ];
        let grid = UniformGrid::build(&pts);

        // Query at (4.5, 4.5, 4.5) — closest is (5, 5, 5)
        let q = Vec3::new(4.5, 4.5, 4.5);
        assert_eq!(grid.query_nearest(q), Some(2));

        // Query at (0.1, 0.1, 0.1) — closest is (0, 0, 0)
        let q = Vec3::new(0.1, 0.1, 0.1);
        assert_eq!(grid.query_nearest(q), Some(0));

        // Query far outside bbox — still finds the nearest
        let q = Vec3::new(100.0, 0.0, 0.0);
        assert_eq!(grid.query_nearest(q), Some(1));
    }

    #[test]
    fn uniform_grid_handles_dense_points() {
        // 1000 points on a unit cube — every query should land within ~0.1
        let mut pts: Vec<[f64; 3]> = Vec::new();
        for i in 0..10 {
            for j in 0..10 {
                for k in 0..10 {
                    pts.push([i as f64 * 0.1, j as f64 * 0.1, k as f64 * 0.1]);
                }
            }
        }
        let grid = UniformGrid::build(&pts);

        // Query at a known grid point
        let q = Vec3::new(0.3, 0.4, 0.5);
        let nearest = grid.query_nearest(q).expect("non-empty grid");
        let p = pts[nearest as usize];
        let d = ((p[0] - 0.3).powi(2) + (p[1] - 0.4).powi(2) + (p[2] - 0.5).powi(2)).sqrt();
        assert!(d < 0.05, "expected exact match, got dist {d}");
    }

    #[test]
    fn transfer_with_no_input_attrs_emits_proxy_own_normals() {
        // Input cube
        let input_positions: Vec<[f64; 3]> = vec![
            [0.0, 0.0, 0.0],
            [1.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
        ];
        let input_indices: Vec<[u32; 3]> = vec![[0, 1, 2]];

        // Proxy = same triangle
        let proxy_positions = input_positions.clone();
        let proxy_indices = input_indices.clone();

        let result = transfer_attributes(
            &input_positions,
            &input_indices,
            None,
            None,
            &proxy_positions,
            &proxy_indices,
            &TransferOpts {
                transfer_normals: false,
                transfer_uvs: false,
            },
        );

        let normals = result.corner_normals.expect("normals always emitted");
        assert_eq!(normals.len(), 3);
        // Triangle is in z=0 plane → normal should be ±Z
        for n in &normals {
            assert!((n.z.abs() - 1.0).abs() < 1e-9, "got {:?}", n);
            assert!(n.x.abs() < 1e-9 && n.y.abs() < 1e-9);
        }
        assert!(result.corner_uvs.is_none());
    }

    #[test]
    fn transfer_normals_from_input_via_nearest_lookup() {
        // Two-triangle input, with one corner normal per corner.
        let input_positions: Vec<[f64; 3]> = vec![
            [0.0, 0.0, 0.0],
            [1.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
            [1.0, 1.0, 0.0],
        ];
        let input_indices: Vec<[u32; 3]> = vec![[0, 1, 2], [1, 3, 2]];
        // Up normal everywhere.
        let input_corner_normals: Vec<Vec3> = vec![Vec3::new(0.0, 0.0, 1.0); 6];

        // Proxy with vertices near input vertices.
        let proxy_positions: Vec<[f64; 3]> = vec![
            [0.01, 0.01, 0.0],
            [0.99, 0.01, 0.0],
            [0.5, 0.99, 0.0],
        ];
        let proxy_indices: Vec<[u32; 3]> = vec![[0, 1, 2]];

        let result = transfer_attributes(
            &input_positions,
            &input_indices,
            Some(&input_corner_normals),
            None,
            &proxy_positions,
            &proxy_indices,
            &TransferOpts {
                transfer_normals: true,
                transfer_uvs: false,
            },
        );

        let normals = result.corner_normals.unwrap();
        for n in &normals {
            assert!((n.z - 1.0).abs() < 1e-6);
        }
    }
}
