//! Sparse linear algebra for mesh processing.
//!
//! Provides a compressed sparse row (CSR) matrix and conjugate gradient solver
//! for the symmetric positive-definite systems arising in cross-field computation
//! and surface parametrization.

/// Compressed Sparse Row (CSR) matrix.
///
/// Stores a sparse matrix in row-major order. Efficient for matrix-vector products
/// and row access, which is what the CG solver needs.
#[derive(Clone, Debug)]
pub struct CsrMatrix {
    /// Number of rows.
    pub nrows: usize,
    /// Number of columns.
    pub ncols: usize,
    /// Row pointers: row i has entries in values[row_ptr[i]..row_ptr[i+1]].
    pub row_ptr: Vec<usize>,
    /// Column indices for each non-zero entry.
    pub col_idx: Vec<usize>,
    /// Non-zero values.
    pub values: Vec<f64>,
}

impl CsrMatrix {
    /// Create a new CSR matrix from triplets (row, col, value).
    ///
    /// Duplicate entries are summed (standard FEM assembly pattern).
    pub fn from_triplets(nrows: usize, ncols: usize, triplets: &[(usize, usize, f64)]) -> Self {
        // Count entries per row
        let mut row_counts = vec![0usize; nrows];
        for &(r, _, _) in triplets {
            row_counts[r] += 1;
        }

        // Build row pointers
        let mut row_ptr = vec![0usize; nrows + 1];
        for i in 0..nrows {
            row_ptr[i + 1] = row_ptr[i] + row_counts[i];
        }

        let nnz = row_ptr[nrows];
        let mut col_idx = vec![0usize; nnz];
        let mut values = vec![0.0f64; nnz];
        let mut row_pos = vec![0usize; nrows]; // current insert position per row

        for &(r, c, v) in triplets {
            let pos = row_ptr[r] + row_pos[r];
            col_idx[pos] = c;
            values[pos] = v;
            row_pos[r] += 1;
        }

        // Sort each row by column index and merge duplicates
        let mut result = CsrMatrix {
            nrows,
            ncols,
            row_ptr,
            col_idx,
            values,
        };
        result.sort_and_merge();
        result
    }

    fn sort_and_merge(&mut self) {
        for i in 0..self.nrows {
            let start = self.row_ptr[i];
            let end = self.row_ptr[i + 1];
            if start == end {
                continue;
            }

            // Sort by column index
            let mut entries: Vec<(usize, f64)> = (start..end)
                .map(|k| (self.col_idx[k], self.values[k]))
                .collect();
            entries.sort_by_key(|&(c, _)| c);

            // Merge duplicates
            let mut merged = Vec::with_capacity(entries.len());
            merged.push(entries[0]);
            for &(c, v) in &entries[1..] {
                if c == merged.last().unwrap().0 {
                    merged.last_mut().unwrap().1 += v;
                } else {
                    merged.push((c, v));
                }
            }

            // Write back (may be shorter due to merges, pad with zeros)
            for (k, &(c, v)) in merged.iter().enumerate() {
                self.col_idx[start + k] = c;
                self.values[start + k] = v;
            }
            for k in merged.len()..(end - start) {
                self.values[start + k] = 0.0;
            }
        }
    }

    /// Matrix-vector product: y = A * x.
    pub fn mul_vec(&self, x: &[f64], y: &mut [f64]) {
        assert_eq!(x.len(), self.ncols);
        assert_eq!(y.len(), self.nrows);

        for i in 0..self.nrows {
            let mut sum = 0.0;
            for k in self.row_ptr[i]..self.row_ptr[i + 1] {
                if self.values[k] != 0.0 {
                    sum += self.values[k] * x[self.col_idx[k]];
                }
            }
            y[i] = sum;
        }
    }
}

/// Solve Ax = b using the conjugate gradient method.
///
/// Requires A to be symmetric positive definite. Returns the solution x.
///
/// Parameters:
/// - `a`: The sparse SPD matrix.
/// - `b`: Right-hand side vector.
/// - `x0`: Initial guess (if None, starts from zero).
/// - `tol`: Convergence tolerance (relative residual). Default 1e-6.
/// - `max_iter`: Maximum iterations. Default 2 * n.
///
/// Returns (solution, iterations, final_residual).
pub fn conjugate_gradient(
    a: &CsrMatrix,
    b: &[f64],
    x0: Option<&[f64]>,
    tol: f64,
    max_iter: usize,
) -> (Vec<f64>, usize, f64) {
    let n = a.nrows;
    assert_eq!(a.ncols, n, "CG requires square matrix");
    assert_eq!(b.len(), n);

    let mut x = if let Some(x0) = x0 {
        x0.to_vec()
    } else {
        vec![0.0; n]
    };

    // r = b - A*x
    let mut ax = vec![0.0; n];
    a.mul_vec(&x, &mut ax);
    let mut r: Vec<f64> = b.iter().zip(ax.iter()).map(|(&bi, &ai)| bi - ai).collect();

    let b_norm = b.iter().map(|&bi| bi * bi).sum::<f64>().sqrt();
    if b_norm < 1e-15 {
        return (x, 0, 0.0);
    }

    let mut r_norm_sq: f64 = r.iter().map(|&ri| ri * ri).sum();

    if r_norm_sq.sqrt() / b_norm < tol {
        return (x, 0, r_norm_sq.sqrt() / b_norm);
    }

    let mut p = r.clone();
    let mut ap = vec![0.0; n];

    for iter in 0..max_iter {
        // ap = A * p
        a.mul_vec(&p, &mut ap);

        // alpha = r'r / p'Ap
        let p_ap: f64 = p.iter().zip(ap.iter()).map(|(&pi, &ai)| pi * ai).sum();
        if p_ap.abs() < 1e-30 {
            break;
        }
        let alpha = r_norm_sq / p_ap;

        // x = x + alpha * p
        for i in 0..n {
            x[i] += alpha * p[i];
        }

        // r = r - alpha * Ap
        for i in 0..n {
            r[i] -= alpha * ap[i];
        }

        let new_r_norm_sq: f64 = r.iter().map(|&ri| ri * ri).sum();
        let rel_residual = new_r_norm_sq.sqrt() / b_norm;

        if rel_residual < tol {
            return (x, iter + 1, rel_residual);
        }

        // beta = r_new'r_new / r_old'r_old
        let beta = new_r_norm_sq / r_norm_sq;
        r_norm_sq = new_r_norm_sq;

        // p = r + beta * p
        for i in 0..n {
            p[i] = r[i] + beta * p[i];
        }
    }

    let final_residual = r_norm_sq.sqrt() / b_norm;
    (x, max_iter, final_residual)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn csr_from_triplets_basic() {
        // 2x2 identity
        let m = CsrMatrix::from_triplets(2, 2, &[(0, 0, 1.0), (1, 1, 1.0)]);
        assert_eq!(m.nrows, 2);
        assert_eq!(m.ncols, 2);

        let mut y = vec![0.0; 2];
        m.mul_vec(&[3.0, 5.0], &mut y);
        assert!((y[0] - 3.0).abs() < 1e-10);
        assert!((y[1] - 5.0).abs() < 1e-10);
    }

    #[test]
    fn csr_duplicate_entries_summed() {
        let m = CsrMatrix::from_triplets(2, 2, &[
            (0, 0, 1.0), (0, 0, 2.0), (1, 1, 3.0),
        ]);
        let mut y = vec![0.0; 2];
        m.mul_vec(&[1.0, 1.0], &mut y);
        assert!((y[0] - 3.0).abs() < 1e-10); // 1.0 + 2.0
        assert!((y[1] - 3.0).abs() < 1e-10);
    }

    #[test]
    fn cg_solves_identity() {
        let m = CsrMatrix::from_triplets(3, 3, &[
            (0, 0, 1.0), (1, 1, 1.0), (2, 2, 1.0),
        ]);
        let b = vec![1.0, 2.0, 3.0];
        let (x, iters, residual) = conjugate_gradient(&m, &b, None, 1e-10, 100);
        assert!((x[0] - 1.0).abs() < 1e-8);
        assert!((x[1] - 2.0).abs() < 1e-8);
        assert!((x[2] - 3.0).abs() < 1e-8);
        assert!(iters <= 3);
    }

    #[test]
    fn cg_solves_spd_system() {
        // A = [[4, 1], [1, 3]] -- SPD
        let m = CsrMatrix::from_triplets(2, 2, &[
            (0, 0, 4.0), (0, 1, 1.0),
            (1, 0, 1.0), (1, 1, 3.0),
        ]);
        // b = [1, 2] -> x = [1/11, 7/11]
        let b = vec![1.0, 2.0];
        let (x, _, residual) = conjugate_gradient(&m, &b, None, 1e-10, 100);
        assert!((x[0] - 1.0 / 11.0).abs() < 1e-8);
        assert!((x[1] - 7.0 / 11.0).abs() < 1e-8);
        assert!(residual < 1e-10);
    }

    #[test]
    fn cg_solves_laplacian_like() {
        // 5x5 tridiagonal: 2 on diagonal, -1 on off-diagonal (1D Laplacian)
        let n = 5;
        let mut triplets = Vec::new();
        for i in 0..n {
            triplets.push((i, i, 2.0));
            if i > 0 {
                triplets.push((i, i - 1, -1.0));
            }
            if i + 1 < n {
                triplets.push((i, i + 1, -1.0));
            }
        }
        let m = CsrMatrix::from_triplets(n, n, &triplets);
        let b = vec![1.0; n];
        let (x, iters, residual) = conjugate_gradient(&m, &b, None, 1e-10, 100);

        // Verify Ax = b
        let mut ax = vec![0.0; n];
        m.mul_vec(&x, &mut ax);
        for i in 0..n {
            assert!(
                (ax[i] - b[i]).abs() < 1e-8,
                "row {}: Ax={}, b={}",
                i,
                ax[i],
                b[i]
            );
        }
        assert!(residual < 1e-10);
    }
}
