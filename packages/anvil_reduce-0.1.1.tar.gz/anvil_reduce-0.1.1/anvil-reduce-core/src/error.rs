use thiserror::Error;

#[derive(Error, Debug)]
pub enum MeshError {
    #[error("non-manifold edge between vertices {0} and {1} (shared by >2 faces)")]
    NonManifoldEdge(u32, u32),

    #[error("non-manifold vertex {0} (bowtie topology)")]
    NonManifoldVertex(u32),

    #[error("empty mesh: no vertices or faces provided")]
    EmptyMesh,

    #[error("invalid index {index} in face {face} (vertex count: {vertex_count})")]
    InvalidIndex {
        face: usize,
        index: u32,
        vertex_count: usize,
    },
}
