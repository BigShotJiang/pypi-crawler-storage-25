//! Marching cubes isosurface extraction from a binary voxel grid.

use rayon::prelude::*;
use rustc_hash::FxHashMap;

use crate::mc_tables::{CORNER_OFFSETS, EDGE_TABLE, EDGE_VERTICES, TRI_TABLE};
use crate::progress::Reporter;
use crate::voxelize::VoxelGrid;

/// Maps each of the 12 cube edges to a canonical (dx, dy, dz, axis) offset
/// relative to the cube's grid position. This allows vertex deduplication
/// across neighbouring cubes that share an edge.
///
/// axis: 0 = X, 1 = Y, 2 = Z
const EDGE_CANONICAL: [[i32; 4]; 12] = [
    [0, 0, 0, 0], // edge 0:  X at (x,   y,   z  )
    [1, 0, 0, 1], // edge 1:  Y at (x+1, y,   z  )
    [0, 1, 0, 0], // edge 2:  X at (x,   y+1, z  )
    [0, 0, 0, 1], // edge 3:  Y at (x,   y,   z  )
    [0, 0, 1, 0], // edge 4:  X at (x,   y,   z+1)
    [1, 0, 1, 1], // edge 5:  Y at (x+1, y,   z+1)
    [0, 1, 1, 0], // edge 6:  X at (x,   y+1, z+1)
    [0, 0, 1, 1], // edge 7:  Y at (x,   y,   z+1)
    [0, 0, 0, 2], // edge 8:  Z at (x,   y,   z  )
    [1, 0, 0, 2], // edge 9:  Z at (x+1, y,   z  )
    [1, 1, 0, 2], // edge 10: Z at (x+1, y+1, z  )
    [0, 1, 0, 2], // edge 11: Z at (x,   y+1, z  )
];

/// Per-slab output produced by parallel marching cubes.
struct SlabOutput {
    /// Vertex positions, indexed by `local_indices` entries.
    positions: Vec<[f64; 3]>,
    /// Global canonical edge key for each local position; used for cross-slab dedup.
    keys: Vec<(u32, u32, u32, u8)>,
    /// Triangles using local indices (must be remapped at merge).
    indices: Vec<[u32; 3]>,
}

/// Extract an isosurface from a binary voxel grid using marching cubes.
///
/// Returns `(positions, triangle_indices)` suitable for writing to OBJ.
/// Vertices on shared edges are deduplicated via a canonical-edge HashMap.
///
/// Parallel over Z-slabs of cubes with thread-local dedup. Cross-slab edges
/// (those at the shared boundary between two slabs) are deduped sequentially
/// at the merge step using the same global (gx, gy, gz, axis) keys, so the
/// output is bit-identical to a sequential implementation.
pub fn extract_isosurface(grid: &VoxelGrid) -> (Vec<[f64; 3]>, Vec<[u32; 3]>) {
    let [rx, ry, rz] = grid.res;
    let cs = grid.cell_size;
    let o = grid.origin;

    if rx < 2 || ry < 2 || rz < 2 {
        return (Vec::new(), Vec::new());
    }

    // Per-stage Reporter: the work itself is parallel across Z-slabs and
    // there's no natural per-iteration tick, so we just bracket the stage
    // for visibility / timing.
    let reporter = Reporter::untimed("marching cubes");

    // Each Z slab processes one cube layer (cubes spanning grid Z..Z+1).
    let slabs: Vec<SlabOutput> = (0..rz - 1)
        .into_par_iter()
        .map(|z| process_slab(grid, z, rx, ry, cs, o))
        .collect();

    // Sequential merge: dedup vertices across slabs by global edge key.
    let total_verts: usize = slabs.iter().map(|s| s.positions.len()).sum();
    let total_tris: usize = slabs.iter().map(|s| s.indices.len()).sum();

    let mut global_map: FxHashMap<(u32, u32, u32, u8), u32> =
        FxHashMap::with_capacity_and_hasher(total_verts, Default::default());
    let mut positions: Vec<[f64; 3]> = Vec::with_capacity(total_verts);
    let mut indices: Vec<[u32; 3]> = Vec::with_capacity(total_tris);

    for slab in slabs {
        let mut local_to_global = vec![u32::MAX; slab.positions.len()];
        for (li, key) in slab.keys.iter().enumerate() {
            let global_idx = *global_map.entry(*key).or_insert_with(|| {
                let idx = positions.len() as u32;
                positions.push(slab.positions[li]);
                idx
            });
            local_to_global[li] = global_idx;
        }
        for tri in slab.indices {
            indices.push([
                local_to_global[tri[0] as usize],
                local_to_global[tri[1] as usize],
                local_to_global[tri[2] as usize],
            ]);
        }
    }
    reporter.finish();

    (positions, indices)
}

/// Process one Z layer of cubes (cubes at z, spanning grid cells z..z+1).
fn process_slab(
    grid: &VoxelGrid,
    z: usize,
    rx: usize,
    ry: usize,
    cs: f64,
    o: crate::types::Vec3,
) -> SlabOutput {
    let mut positions: Vec<[f64; 3]> = Vec::new();
    let mut keys: Vec<(u32, u32, u32, u8)> = Vec::new();
    let mut indices: Vec<[u32; 3]> = Vec::new();
    let mut local_map: FxHashMap<(u32, u32, u32, u8), u32> = FxHashMap::default();

    for y in 0..ry - 1 {
        for x in 0..rx - 1 {
            let mut cube_index: u8 = 0;
            for (i, co) in CORNER_OFFSETS.iter().enumerate() {
                if grid.is_solid(x + co[0], y + co[1], z + co[2]) {
                    cube_index |= 1 << i;
                }
            }

            let edges = EDGE_TABLE[cube_index as usize];
            if edges == 0 {
                continue;
            }

            let mut edge_verts = [u32::MAX; 12];
            for e in 0..12u8 {
                if edges & (1 << e) == 0 {
                    continue;
                }

                let canon = &EDGE_CANONICAL[e as usize];
                let gx = (x as i32 + canon[0]) as u32;
                let gy = (y as i32 + canon[1]) as u32;
                let gz = (z as i32 + canon[2]) as u32;
                let axis = canon[3] as u8;
                let key = (gx, gy, gz, axis);

                let vi = *local_map.entry(key).or_insert_with(|| {
                    let pos = match axis {
                        0 => [
                            o.x + (gx as f64 + 0.5) * cs,
                            o.y + gy as f64 * cs,
                            o.z + gz as f64 * cs,
                        ],
                        1 => [
                            o.x + gx as f64 * cs,
                            o.y + (gy as f64 + 0.5) * cs,
                            o.z + gz as f64 * cs,
                        ],
                        _ => [
                            o.x + gx as f64 * cs,
                            o.y + gy as f64 * cs,
                            o.z + (gz as f64 + 0.5) * cs,
                        ],
                    };
                    let idx = positions.len() as u32;
                    positions.push(pos);
                    keys.push(key);
                    idx
                });
                edge_verts[e as usize] = vi;
            }

            let tri_row = &TRI_TABLE[cube_index as usize];
            let mut t = 0;
            while t + 2 < 16 {
                if tri_row[t] < 0 {
                    break;
                }
                let a = edge_verts[tri_row[t] as usize];
                let b = edge_verts[tri_row[t + 1] as usize];
                let c = edge_verts[tri_row[t + 2] as usize];
                indices.push([a, b, c]);
                t += 3;
            }
        }
    }

    SlabOutput { positions, keys, indices }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::half_edge::HalfEdgeMesh;

    /// A simple closed box mesh for testing.
    fn box_mesh() -> HalfEdgeMesh {
        #[rustfmt::skip]
        let positions: Vec<[f64; 3]> = vec![
            [0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [1.0, 1.0, 0.0], [0.0, 1.0, 0.0],
            [0.0, 0.0, 1.0], [1.0, 0.0, 1.0], [1.0, 1.0, 1.0], [0.0, 1.0, 1.0],
        ];
        #[rustfmt::skip]
        let indices: Vec<[u32; 3]> = vec![
            [0, 2, 1], [0, 3, 2],
            [4, 5, 6], [4, 6, 7],
            [0, 1, 5], [0, 5, 4],
            [3, 6, 2], [3, 7, 6],
            [0, 4, 7], [0, 7, 3],
            [1, 2, 6], [1, 6, 5],
        ];
        HalfEdgeMesh::from_indexed_triangles(&positions, &indices).unwrap()
    }

    #[test]
    fn marching_cubes_produces_mesh() {
        let mesh = box_mesh();
        let grid = crate::voxelize::VoxelGrid::from_mesh(&mesh, 16);
        let (positions, indices) = extract_isosurface(&grid);

        assert!(!positions.is_empty(), "should produce vertices");
        assert!(!indices.is_empty(), "should produce triangles");

        // All indices should be valid
        for tri in &indices {
            for &i in tri {
                assert!(
                    (i as usize) < positions.len(),
                    "index {} out of range ({})",
                    i,
                    positions.len()
                );
            }
        }
    }

    #[test]
    fn marching_cubes_closed_manifold() {
        // For a closed solid, every edge should be shared by exactly 2 triangles
        let mesh = box_mesh();
        let grid = crate::voxelize::VoxelGrid::from_mesh(&mesh, 16);
        let (_, indices) = extract_isosurface(&grid);

        let mut edge_count: std::collections::HashMap<(u32, u32), u32> = std::collections::HashMap::new();
        for tri in &indices {
            for i in 0..3 {
                let a = tri[i];
                let b = tri[(i + 1) % 3];
                let key = if a < b { (a, b) } else { (b, a) };
                *edge_count.entry(key).or_insert(0) += 1;
            }
        }

        // Every edge should appear exactly 2 times (manifold)
        for (&edge, &count) in &edge_count {
            assert_eq!(
                count, 2,
                "edge ({}, {}) has {} uses, expected 2",
                edge.0, edge.1, count
            );
        }
    }
}
