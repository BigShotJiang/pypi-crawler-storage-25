//! Lightweight progress reporting utilities.
//!
//! `Reporter` is constructed at the start of a stage with a label and a
//! total-item count. `tick(current)` is called inside a hot loop; output is
//! throttled to ~5 Hz so progress prints don't dominate wall time. Reports
//! to stderr with `\r`-style overwriting.
//!
//! Output is globally suppressible via [`set_quiet`] — the CLI's `--quiet`
//! flag, batch mode for farm jobs, or Python bindings setting it per-call.

use std::sync::atomic::{AtomicBool, Ordering};
use std::time::{Duration, Instant};

static QUIET: AtomicBool = AtomicBool::new(false);

/// Globally suppress all progress output. Idempotent.
pub fn set_quiet(quiet: bool) {
    QUIET.store(quiet, Ordering::Relaxed);
}

/// Whether progress output is currently suppressed.
pub fn is_quiet() -> bool {
    QUIET.load(Ordering::Relaxed)
}

/// Stage-level progress reporter with a per-stage banner and throttled ticks.
pub struct Reporter {
    label: String,
    total: usize,
    start: Instant,
    last_print: Instant,
    finished: bool,
}

impl Reporter {
    /// Begin a stage with `total` items of expected work. Prints a banner.
    pub fn new(label: impl Into<String>, total: usize) -> Self {
        let now = Instant::now();
        let r = Self {
            label: label.into(),
            total,
            start: now,
            last_print: now - Duration::from_secs(1),
            finished: false,
        };
        if !is_quiet() {
            eprintln!("  {}: starting ({} items)", r.label, r.total);
        }
        r
    }

    /// Stage with no item count — just timing. Useful for stages whose work
    /// isn't naturally indexable.
    pub fn untimed(label: impl Into<String>) -> Self {
        Self::new(label, 0)
    }

    /// Update progress. Throttled internally to ~5 Hz; cheap to call from
    /// hot loops every iteration.
    pub fn tick(&mut self, current: usize) {
        if is_quiet() {
            return;
        }
        let now = Instant::now();
        if now.duration_since(self.last_print) < Duration::from_millis(200) {
            return;
        }
        self.last_print = now;
        let elapsed = now.duration_since(self.start).as_secs_f64();
        let rate = current as f64 / elapsed.max(1e-3);
        if self.total > 0 {
            let pct = (current as f64 / self.total as f64) * 100.0;
            eprint!(
                "\r  {}: {:>5.1}%  {} / {}  ({})        ",
                self.label,
                pct,
                current,
                self.total,
                fmt_rate(rate),
            );
        } else {
            eprint!(
                "\r  {}: {} items  ({})        ",
                self.label,
                current,
                fmt_rate(rate),
            );
        }
    }

    /// Mark the stage as complete. Prints the summary line.
    pub fn finish(mut self) {
        self.finish_inline();
    }

    fn finish_inline(&mut self) {
        if self.finished || is_quiet() {
            self.finished = true;
            return;
        }
        let elapsed = self.start.elapsed().as_secs_f64();
        let rate = self.total as f64 / elapsed.max(1e-3);
        if self.total > 0 {
            eprintln!(
                "\r  {}: done {} items in {:.2}s ({})        ",
                self.label,
                self.total,
                elapsed,
                fmt_rate(rate),
            );
        } else {
            eprintln!(
                "\r  {}: done in {:.2}s        ",
                self.label, elapsed,
            );
        }
        self.finished = true;
    }
}

impl Drop for Reporter {
    fn drop(&mut self) {
        // If the user forgot to call finish(), still close out the line.
        self.finish_inline();
    }
}

fn fmt_rate(rate: f64) -> String {
    if rate >= 1e6 {
        format!("{:.1}M/s", rate / 1e6)
    } else if rate >= 1e3 {
        format!("{:.1}k/s", rate / 1e3)
    } else {
        format!("{:.0}/s", rate)
    }
}
