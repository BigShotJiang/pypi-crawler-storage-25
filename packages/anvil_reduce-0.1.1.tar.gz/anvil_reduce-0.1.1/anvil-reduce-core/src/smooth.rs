//! Mesh smoothing operations.
//!
//! Laplacian smoothing moves each vertex toward the average of its neighbors,
//! producing organic-looking meshes from voxelized MC output.

use crate::progress::Reporter;

/// Apply Laplacian smoothing to a triangle mesh.
///
/// Each iteration moves every vertex toward the centroid of its edge-connected
/// neighbors by `lambda` (0.0 = no movement, 1.0 = full snap to centroid).
///
/// To prevent shrinkage, we use Taubin smoothing: alternate a positive step
/// (lambda) with a slightly larger negative step (mu), which inflates back.
pub fn taubin_smooth(
    positions: &mut [[f64; 3]],
    indices: &[[u32; 3]],
    iterations: usize,
    lambda: f64,
) {
    let n = positions.len();
    if n == 0 || iterations == 0 {
        return;
    }

    // Taubin's mu parameter: slightly larger than lambda to counteract shrinkage
    let mu = -lambda / (1.0 - 0.1 * lambda);

    // Build adjacency: for each vertex, collect unique neighbor indices
    let mut neighbors: Vec<Vec<u32>> = vec![Vec::new(); n];
    for tri in indices {
        for i in 0..3 {
            let a = tri[i] as usize;
            let b = tri[(i + 1) % 3] as usize;
            if !neighbors[a].contains(&(b as u32)) {
                neighbors[a].push(b as u32);
            }
            if !neighbors[b].contains(&(a as u32)) {
                neighbors[b].push(a as u32);
            }
        }
    }

    let mut temp = vec![[0.0f64; 3]; n];

    let mut reporter = Reporter::new("Taubin smooth", iterations);
    for it in 0..iterations {
        reporter.tick(it);
        // Positive step (shrink)
        laplacian_step(positions, &neighbors, &mut temp, lambda);
        // Negative step (inflate back)
        laplacian_step(positions, &neighbors, &mut temp, mu);
    }
    reporter.finish();
}

fn laplacian_step(
    positions: &mut [[f64; 3]],
    neighbors: &[Vec<u32>],
    temp: &mut [[f64; 3]],
    factor: f64,
) {
    let n = positions.len();

    // Compute smoothed positions
    for i in 0..n {
        if neighbors[i].is_empty() {
            temp[i] = positions[i];
            continue;
        }

        let mut avg = [0.0f64; 3];
        for &ni in &neighbors[i] {
            let p = &positions[ni as usize];
            avg[0] += p[0];
            avg[1] += p[1];
            avg[2] += p[2];
        }
        let count = neighbors[i].len() as f64;
        avg[0] /= count;
        avg[1] /= count;
        avg[2] /= count;

        // Move toward centroid by factor
        temp[i] = [
            positions[i][0] + factor * (avg[0] - positions[i][0]),
            positions[i][1] + factor * (avg[1] - positions[i][1]),
            positions[i][2] + factor * (avg[2] - positions[i][2]),
        ];
    }

    // Copy back
    positions.copy_from_slice(&temp[..n]);
}

/// Apply bilateral mesh smoothing that preserves sharp features.
///
/// Unlike Laplacian/Taubin smoothing which blurs everything uniformly,
/// bilateral smoothing weights neighbor contributions by normal similarity.
/// Vertices along sharp edges (where neighbor normals differ) are smoothed
/// less, preserving creases and hard edges while still smoothing noise.
///
/// Parameters:
/// - `sigma_s`: Spatial weight falloff. Controls the spatial neighborhood influence.
///   Relative to average edge length (default ~1.0).
/// - `sigma_n`: Normal weight falloff. Lower values preserve sharper features.
///   Range 0.1 (very sharp) to 1.0 (smooth like Laplacian). Default 0.3.
pub fn bilateral_smooth(
    positions: &mut [[f64; 3]],
    indices: &[[u32; 3]],
    iterations: usize,
    sigma_n: f64,
) {
    let n = positions.len();
    if n == 0 || iterations == 0 {
        return;
    }

    // Build adjacency
    let mut neighbors: Vec<Vec<u32>> = vec![Vec::new(); n];
    for tri in indices {
        for i in 0..3 {
            let a = tri[i] as usize;
            let b = tri[(i + 1) % 3] as usize;
            if !neighbors[a].contains(&(b as u32)) {
                neighbors[a].push(b as u32);
            }
            if !neighbors[b].contains(&(a as u32)) {
                neighbors[b].push(a as u32);
            }
        }
    }

    // Build vertex -> face adjacency for normal computation
    let mut vert_faces: Vec<Vec<usize>> = vec![Vec::new(); n];
    for (fi, tri) in indices.iter().enumerate() {
        for &vi in tri {
            vert_faces[vi as usize].push(fi);
        }
    }

    let sigma_n_sq_2 = 2.0 * sigma_n * sigma_n;
    let mut temp = vec![[0.0f64; 3]; n];

    let mut reporter = Reporter::new("bilateral smooth", iterations);
    for it in 0..iterations {
        reporter.tick(it);
        // Compute per-vertex normals (area-weighted face normals)
        let mut normals = vec![[0.0f64; 3]; n];
        for tri in indices {
            let p0 = &positions[tri[0] as usize];
            let p1 = &positions[tri[1] as usize];
            let p2 = &positions[tri[2] as usize];
            let e1 = [p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]];
            let e2 = [p2[0] - p0[0], p2[1] - p0[1], p2[2] - p0[2]];
            let fn_ = [
                e1[1] * e2[2] - e1[2] * e2[1],
                e1[2] * e2[0] - e1[0] * e2[2],
                e1[0] * e2[1] - e1[1] * e2[0],
            ];
            for &vi in tri {
                normals[vi as usize][0] += fn_[0];
                normals[vi as usize][1] += fn_[1];
                normals[vi as usize][2] += fn_[2];
            }
        }
        // Normalize
        for nrm in &mut normals {
            let len = (nrm[0] * nrm[0] + nrm[1] * nrm[1] + nrm[2] * nrm[2]).sqrt();
            if len > 1e-12 {
                nrm[0] /= len;
                nrm[1] /= len;
                nrm[2] /= len;
            }
        }

        // Compute average edge length for spatial sigma
        let mut total_edge = 0.0f64;
        let mut edge_count = 0usize;
        for (i, nbrs) in neighbors.iter().enumerate() {
            for &ni in nbrs {
                if (ni as usize) > i {
                    let dx = positions[i][0] - positions[ni as usize][0];
                    let dy = positions[i][1] - positions[ni as usize][1];
                    let dz = positions[i][2] - positions[ni as usize][2];
                    total_edge += (dx * dx + dy * dy + dz * dz).sqrt();
                    edge_count += 1;
                }
            }
        }
        let avg_edge = if edge_count > 0 { total_edge / edge_count as f64 } else { 1.0 };
        let sigma_s_sq_2 = 2.0 * avg_edge * avg_edge;

        // Bilateral filter: for each vertex, compute weighted displacement
        for i in 0..n {
            if neighbors[i].is_empty() {
                temp[i] = positions[i];
                continue;
            }

            let ni = &normals[i];
            let pi = &positions[i];
            let mut disp = [0.0f64; 3];
            let mut weight_sum = 0.0f64;

            for &nj in &neighbors[i] {
                let j = nj as usize;
                let pj = &positions[j];
                let nj_normal = &normals[j];

                // Spatial distance squared
                let dx = pj[0] - pi[0];
                let dy = pj[1] - pi[1];
                let dz = pj[2] - pi[2];
                let dist_sq = dx * dx + dy * dy + dz * dz;

                // Normal difference: 1 - dot(ni, nj), range [0, 2]
                let ndot = ni[0] * nj_normal[0] + ni[1] * nj_normal[1] + ni[2] * nj_normal[2];
                let normal_diff_sq = (1.0 - ndot).max(0.0);

                // Bilateral weight: spatial * normal similarity
                let ws = (-dist_sq / sigma_s_sq_2).exp();
                let wn = (-normal_diff_sq / sigma_n_sq_2).exp();
                let w = ws * wn;

                disp[0] += w * dx;
                disp[1] += w * dy;
                disp[2] += w * dz;
                weight_sum += w;
            }

            if weight_sum > 1e-12 {
                temp[i] = [
                    pi[0] + disp[0] / weight_sum,
                    pi[1] + disp[1] / weight_sum,
                    pi[2] + disp[2] / weight_sum,
                ];
            } else {
                temp[i] = *pi;
            }
        }

        positions.copy_from_slice(&temp[..n]);
    }
    reporter.finish();
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn smoothing_does_not_explode() {
        // Simple quad (2 triangles)
        let mut positions = vec![
            [0.0, 0.0, 0.0],
            [1.0, 0.0, 0.0],
            [1.0, 1.0, 0.0],
            [0.0, 1.0, 0.0],
        ];
        let indices = vec![[0u32, 1, 2], [0, 2, 3]];

        let original = positions.clone();
        taubin_smooth(&mut positions, &indices, 5, 0.5);

        // Positions should have changed but not diverged
        for (i, pos) in positions.iter().enumerate() {
            for k in 0..3 {
                assert!(
                    pos[k].is_finite(),
                    "vertex {} component {} is not finite",
                    i,
                    k
                );
                assert!(
                    (pos[k] - original[i][k]).abs() < 10.0,
                    "vertex {} drifted too far",
                    i
                );
            }
        }
    }
}
