//! Signed Distance Field computation and SDF-based marching cubes.
//!
//! Replaces binary voxelization with continuous distance values,
//! enabling smooth interpolated vertex placement in marching cubes.
//!
//! The unsigned distance transform is **Saito-Toriwaki separable EDT**
//! (Saito & Toriwaki 1994 / Felzenszwalb & Huttenlocher 2004): three
//! independent 1D passes along each axis, each O(n) using the parabola-
//! envelope sweep. Produces exact squared Euclidean distances in cell
//! units, deterministic across runs, and ~5-10× faster than the previous
//! BFS-based approximation (which only computed Manhattan distance).

use rayon::prelude::*;
use rustc_hash::FxHashMap;

use crate::mc_tables::{EDGE_TABLE, TRI_TABLE};
use crate::types::Vec3;

/// A grid storing signed distance values.
///
/// Negative = inside the surface, positive = outside.
pub struct SdfGrid {
    pub data: Vec<f32>,
    pub res: [usize; 3],
    pub origin: Vec3,
    pub cell_size: f64,
}

/// 6-connected neighbour offsets, used only for surface-cell detection.
const NEIGHBOURS_6: [(i32, i32, i32); 6] = [
    (-1, 0, 0),
    (1, 0, 0),
    (0, -1, 0),
    (0, 1, 0),
    (0, 0, -1),
    (0, 0, 1),
];

impl SdfGrid {
    /// Build an SDF grid from raw triangle soup.
    ///
    /// Pipeline:
    /// 1. Binary voxelization (`VoxelGrid::from_raw_triangles`).
    /// 2. Identify surface cells (solid cells adjacent to non-solid).
    /// 3. Saito-Toriwaki separable Euclidean distance transform.
    /// 4. Negate distances for interior cells (sign).
    ///
    /// O(grid_cells) total. Exact squared-Euclidean distances, deterministic.
    pub fn from_raw_triangles(
        positions: &[[f64; 3]],
        indices: &[[u32; 3]],
        resolution: usize,
    ) -> Self {
        use crate::voxelize::VoxelGrid;

        let binary = VoxelGrid::from_raw_triangles(positions, indices, resolution);
        let [rx, ry, rz] = binary.res;
        let cell_size = binary.cell_size;
        let origin = binary.origin;
        let total = rx * ry * rz;

        // Mark surface cells: solid cells that touch a non-solid cell or
        // are on the grid boundary.
        let mut is_surface_cell = vec![false; total];
        let idx = |x: usize, y: usize, z: usize| x + y * rx + z * rx * ry;
        for z in 0..rz {
            for y in 0..ry {
                for x in 0..rx {
                    if !binary.is_solid(x, y, z) {
                        continue;
                    }
                    let mut is_surface = false;
                    for &(dx, dy, dz) in &NEIGHBOURS_6 {
                        let nx = x as i32 + dx;
                        let ny = y as i32 + dy;
                        let nz = z as i32 + dz;
                        if nx < 0
                            || ny < 0
                            || nz < 0
                            || nx as usize >= rx
                            || ny as usize >= ry
                            || nz as usize >= rz
                        {
                            is_surface = true;
                            break;
                        }
                        if !binary.is_solid(nx as usize, ny as usize, nz as usize) {
                            is_surface = true;
                            break;
                        }
                    }
                    if is_surface {
                        is_surface_cell[idx(x, y, z)] = true;
                    }
                }
            }
        }

        // Saito-Toriwaki: produce squared distances in cell-units.
        let mut sq = saito_toriwaki_3d([rx, ry, rz], &is_surface_cell);

        // Convert squared cell-distances to signed world-distances.
        let cs = cell_size as f32;
        let mut data = Vec::with_capacity(total);
        for z in 0..rz {
            for y in 0..ry {
                for x in 0..rx {
                    let i = idx(x, y, z);
                    let d = (sq[i].max(0.0)).sqrt() as f32 * cs;
                    let signed = if binary.is_solid(x, y, z) { -d } else { d };
                    data.push(signed);
                    sq[i] = 0.0; // hint: dropped soon
                }
            }
        }

        SdfGrid {
            data,
            res: [rx, ry, rz],
            origin,
            cell_size,
        }
    }

    fn idx(&self, x: usize, y: usize, z: usize) -> usize {
        x + y * self.res[0] + z * self.res[0] * self.res[1]
    }

    /// Get the SDF value at a grid cell. Negative = inside.
    pub fn get(&self, x: usize, y: usize, z: usize) -> f32 {
        self.data[self.idx(x, y, z)]
    }

    /// Dilate the volume by shifting the isosurface outward.
    pub fn dilate(&mut self, amount: f64) {
        let shift = amount as f32;
        for d in &mut self.data {
            *d -= shift;
        }
    }
}

// ---- Saito-Toriwaki separable 3D EDT ----
//
// Three independent 1D passes along each axis. The 1D pass is the
// Felzenszwalb-Huttenlocher parabola-envelope sweep, which computes the
// lower envelope of N parabolas y = (q - i)^2 + f(i) in O(N) total time.
//
// Input: boolean mask of "seed" cells (here: surface cells).
// Output: squared distance (in cell-units) from each cell to the nearest
// seed, accurate to floating-point precision.

/// 1D EDT lower-envelope sweep.
///
/// Reads `f[i]` (seed cells = 0, others = +inf), writes `d[q]` =
/// min over i of (q - i)^2 + f[i].
fn edt_1d(f: &[f64], d: &mut [f64]) {
    let n = f.len();
    if n == 0 {
        return;
    }
    if n == 1 {
        d[0] = f[0];
        return;
    }

    // v[k] = index of k-th parabola in the lower envelope.
    // z[k] = left boundary (in q-space) where parabola k takes over.
    let mut v = vec![0usize; n];
    let mut z = vec![0.0f64; n + 1];
    let mut k = 0usize;
    z[0] = f64::NEG_INFINITY;
    z[1] = f64::INFINITY;

    for q in 1..n {
        if !f[q].is_finite() {
            continue; // parabola at +inf never wins
        }
        let qf = q as f64;
        loop {
            let vf = v[k] as f64;
            let denom = 2.0 * (qf - vf);
            if denom == 0.0 {
                break;
            }
            let s = ((f[q] + qf * qf) - (f[v[k]] + vf * vf)) / denom;
            if s > z[k] {
                k += 1;
                v[k] = q;
                z[k] = s;
                z[k + 1] = f64::INFINITY;
                break;
            }
            if k == 0 {
                v[k] = q;
                break;
            }
            k -= 1;
        }
    }

    let mut k = 0usize;
    for q in 0..n {
        let qf = q as f64;
        while z[k + 1] < qf {
            k += 1;
        }
        let dq = qf - v[k] as f64;
        d[q] = dq * dq + f[v[k]];
    }
}

/// Run Saito-Toriwaki EDT on a 3D grid of seed flags.
/// Returns `Vec<f64>` of squared distances in cell-units.
fn saito_toriwaki_3d(res: [usize; 3], seeds: &[bool]) -> Vec<f64> {
    let [rx, ry, rz] = res;
    let total = rx * ry * rz;
    debug_assert_eq!(seeds.len(), total);

    // Initialize: seed cells = 0, others = +inf.
    let mut data: Vec<f64> = seeds
        .iter()
        .map(|&s| if s { 0.0 } else { f64::INFINITY })
        .collect();

    // Pass 1: X axis (rows are contiguous, stride 1). Parallel via
    // par_chunks_exact_mut over y-z lines of length rx.
    data.par_chunks_exact_mut(rx).for_each(|line| {
        let f: Vec<f64> = line.to_vec();
        let mut out = vec![0.0; rx];
        edt_1d(&f, &mut out);
        line.copy_from_slice(&out);
    });

    // Pass 2: Y axis (stride rx within an xz-slice). Each z-slice is a
    // contiguous block of rx * ry; parallelise over z-slices.
    let xy = rx * ry;
    data.par_chunks_exact_mut(xy).for_each(|slice| {
        let mut tmp = vec![0.0; ry];
        let mut out = vec![0.0; ry];
        for x in 0..rx {
            for y in 0..ry {
                tmp[y] = slice[x + y * rx];
            }
            edt_1d(&tmp, &mut out);
            for y in 0..ry {
                slice[x + y * rx] = out[y];
            }
        }
    });

    // Pass 3: Z axis (stride rx*ry across the full grid). Sequential over
    // (x, y); each line of length rz is independent. The outer loop is
    // parallelised over y (stride rx), so each thread takes a y-row and
    // sweeps each x-column inside it.
    //
    // We need exclusive access to disjoint columns; the easiest safe
    // pattern is a sequential outer loop here. rz lines × (rx * ry) =
    // total grid cells touched, same work as the parallel passes — only
    // ~1/3 of the wall time, so single-threaded is fine.
    let mut tmp = vec![0.0; rz];
    let mut out = vec![0.0; rz];
    for y in 0..ry {
        for x in 0..rx {
            for z in 0..rz {
                tmp[z] = data[x + y * rx + z * xy];
            }
            edt_1d(&tmp, &mut out);
            for z in 0..rz {
                data[x + y * rx + z * xy] = out[z];
            }
        }
    }

    data
}

/// Canonical edge mapping for vertex deduplication (same as marching_cubes.rs).
const EDGE_CANONICAL: [[i32; 4]; 12] = [
    [0, 0, 0, 0],
    [1, 0, 0, 1],
    [0, 1, 0, 0],
    [0, 0, 0, 1],
    [0, 0, 1, 0],
    [1, 0, 1, 1],
    [0, 1, 1, 0],
    [0, 0, 1, 1],
    [0, 0, 0, 2],
    [1, 0, 0, 2],
    [1, 1, 0, 2],
    [0, 1, 0, 2],
];

/// Corner offsets for the marching cubes cube (same convention as mc_tables).
const CORNER_POS: [[usize; 3]; 8] = [
    [0, 0, 0],
    [1, 0, 0],
    [1, 1, 0],
    [0, 1, 0],
    [0, 0, 1],
    [1, 0, 1],
    [1, 1, 1],
    [0, 1, 1],
];

/// The two corner indices for each of the 12 edges.
const EDGE_CORNERS: [[usize; 2]; 12] = [
    [0, 1], [1, 2], [2, 3], [3, 0],
    [4, 5], [5, 6], [6, 7], [7, 4],
    [0, 4], [1, 5], [2, 6], [3, 7],
];

/// Per-slab output produced by parallel SDF marching cubes.
struct SdfSlabOutput {
    positions: Vec<[f64; 3]>,
    keys: Vec<(u32, u32, u32, u8)>,
    indices: Vec<[u32; 3]>,
}

/// Extract an isosurface from an SDF grid using marching cubes with
/// linear interpolation along edges.
///
/// The isosurface is at SDF = 0.
///
/// Parallel over Z-slabs with sequential merge (see `marching_cubes` module
/// for the same pattern). Output is bit-identical to a sequential version
/// because edge positions depend only on the SDF values at the edge endpoints,
/// which are the same regardless of which slab visits the edge.
pub fn extract_sdf_isosurface(grid: &SdfGrid) -> (Vec<[f64; 3]>, Vec<[u32; 3]>) {
    let [rx, ry, rz] = grid.res;
    let cs = grid.cell_size;
    let o = grid.origin;

    if rx < 2 || ry < 2 || rz < 2 {
        return (Vec::new(), Vec::new());
    }

    let slabs: Vec<SdfSlabOutput> = (0..rz - 1)
        .into_par_iter()
        .map(|z| process_sdf_slab(grid, z, rx, ry, cs, o))
        .collect();

    let total_verts: usize = slabs.iter().map(|s| s.positions.len()).sum();
    let total_tris: usize = slabs.iter().map(|s| s.indices.len()).sum();

    let mut global_map: FxHashMap<(u32, u32, u32, u8), u32> =
        FxHashMap::with_capacity_and_hasher(total_verts, Default::default());
    let mut positions: Vec<[f64; 3]> = Vec::with_capacity(total_verts);
    let mut indices: Vec<[u32; 3]> = Vec::with_capacity(total_tris);

    for slab in slabs {
        let mut local_to_global = vec![u32::MAX; slab.positions.len()];
        for (li, key) in slab.keys.iter().enumerate() {
            let global_idx = *global_map.entry(*key).or_insert_with(|| {
                let idx = positions.len() as u32;
                positions.push(slab.positions[li]);
                idx
            });
            local_to_global[li] = global_idx;
        }
        for tri in slab.indices {
            indices.push([
                local_to_global[tri[0] as usize],
                local_to_global[tri[1] as usize],
                local_to_global[tri[2] as usize],
            ]);
        }
    }

    (positions, indices)
}

fn process_sdf_slab(
    grid: &SdfGrid,
    z: usize,
    rx: usize,
    ry: usize,
    cs: f64,
    o: Vec3,
) -> SdfSlabOutput {
    let mut positions: Vec<[f64; 3]> = Vec::new();
    let mut keys: Vec<(u32, u32, u32, u8)> = Vec::new();
    let mut indices: Vec<[u32; 3]> = Vec::new();
    let mut local_map: FxHashMap<(u32, u32, u32, u8), u32> = FxHashMap::default();

    for y in 0..ry - 1 {
        for x in 0..rx - 1 {
            let mut corner_vals = [0.0f32; 8];
            for (i, co) in CORNER_POS.iter().enumerate() {
                corner_vals[i] = grid.get(x + co[0], y + co[1], z + co[2]);
            }

            let mut cube_index: u8 = 0;
            for (i, &v) in corner_vals.iter().enumerate() {
                if v < 0.0 {
                    cube_index |= 1 << i;
                }
            }

            let edges = EDGE_TABLE[cube_index as usize];
            if edges == 0 {
                continue;
            }

            let mut edge_verts = [u32::MAX; 12];
            for e in 0..12u8 {
                if edges & (1 << e) == 0 {
                    continue;
                }

                let canon = &EDGE_CANONICAL[e as usize];
                let gx = (x as i32 + canon[0]) as u32;
                let gy = (y as i32 + canon[1]) as u32;
                let gz = (z as i32 + canon[2]) as u32;
                let axis = canon[3] as u8;
                let key = (gx, gy, gz, axis);

                let vi = *local_map.entry(key).or_insert_with(|| {
                    let [c0, c1] = EDGE_CORNERS[e as usize];
                    let v0 = corner_vals[c0];
                    let v1 = corner_vals[c1];

                    let t = if (v1 - v0).abs() > 1e-10 {
                        (-v0 / (v1 - v0)) as f64
                    } else {
                        0.5
                    };
                    let t = t.clamp(0.01, 0.99);

                    let p0 = CORNER_POS[c0];
                    let p1 = CORNER_POS[c1];
                    let pos = [
                        o.x + (x as f64 + p0[0] as f64 + (p1[0] as f64 - p0[0] as f64) * t) * cs,
                        o.y + (y as f64 + p0[1] as f64 + (p1[1] as f64 - p0[1] as f64) * t) * cs,
                        o.z + (z as f64 + p0[2] as f64 + (p1[2] as f64 - p0[2] as f64) * t) * cs,
                    ];

                    let idx = positions.len() as u32;
                    positions.push(pos);
                    keys.push(key);
                    idx
                });
                edge_verts[e as usize] = vi;
            }

            let tri_row = &TRI_TABLE[cube_index as usize];
            let mut t = 0;
            while t + 2 < 16 {
                if tri_row[t] < 0 {
                    break;
                }
                let a = edge_verts[tri_row[t] as usize];
                let b = edge_verts[tri_row[t + 1] as usize];
                let c = edge_verts[tri_row[t + 2] as usize];
                indices.push([a, b, c]);
                t += 3;
            }
        }
    }

    SdfSlabOutput { positions, keys, indices }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Single seed at index 0 → distances along the line should be 0², 1², 2², ...
    #[test]
    fn edt_1d_single_seed_at_start() {
        let f = vec![0.0, f64::INFINITY, f64::INFINITY, f64::INFINITY, f64::INFINITY];
        let mut d = vec![0.0; 5];
        edt_1d(&f, &mut d);
        for (i, &v) in d.iter().enumerate() {
            assert!(
                (v - (i as f64).powi(2)).abs() < 1e-9,
                "d[{}] = {}, expected {}",
                i,
                v,
                (i as f64).powi(2)
            );
        }
    }

    /// Two seeds → each cell takes the distance to the nearer seed.
    #[test]
    fn edt_1d_two_seeds() {
        // seeds at 0 and 6 in a 7-element line. Expected squared distances:
        //  i: 0  1  2  3  4  5  6
        //  d: 0  1  4  9  4  1  0   ← min((i-0)^2, (i-6)^2)
        let mut f = vec![f64::INFINITY; 7];
        f[0] = 0.0;
        f[6] = 0.0;
        let mut d = vec![0.0; 7];
        edt_1d(&f, &mut d);
        let expected = [0.0, 1.0, 4.0, 9.0, 4.0, 1.0, 0.0];
        for (i, &e) in expected.iter().enumerate() {
            assert!((d[i] - e).abs() < 1e-9, "i={}: got {}, want {}", i, d[i], e);
        }
    }

    /// 3D EDT with a single seed at the origin should give exact squared
    /// Euclidean distance at every cell.
    #[test]
    fn saito_toriwaki_3d_single_seed_is_exact_euclidean() {
        let res = [5usize, 5, 5];
        let mut seeds = vec![false; 5 * 5 * 5];
        seeds[0] = true; // (0,0,0) is the seed

        let sq = saito_toriwaki_3d(res, &seeds);
        for z in 0..5 {
            for y in 0..5 {
                for x in 0..5 {
                    let i = x + y * 5 + z * 25;
                    let expected = (x * x + y * y + z * z) as f64;
                    assert!(
                        (sq[i] - expected).abs() < 1e-9,
                        "({},{},{}): got {}, want {}",
                        x, y, z, sq[i], expected
                    );
                }
            }
        }
    }

    #[test]
    fn sdf_box_produces_mesh() {
        // Simple box
        #[rustfmt::skip]
        let positions: Vec<[f64; 3]> = vec![
            [0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [1.0, 1.0, 0.0], [0.0, 1.0, 0.0],
            [0.0, 0.0, 1.0], [1.0, 0.0, 1.0], [1.0, 1.0, 1.0], [0.0, 1.0, 1.0],
        ];
        #[rustfmt::skip]
        let indices: Vec<[u32; 3]> = vec![
            [0, 2, 1], [0, 3, 2],
            [4, 5, 6], [4, 6, 7],
            [0, 1, 5], [0, 5, 4],
            [3, 6, 2], [3, 7, 6],
            [0, 4, 7], [0, 7, 3],
            [1, 2, 6], [1, 6, 5],
        ];

        let grid = SdfGrid::from_raw_triangles(&positions, &indices, 16);
        let (pos, idx) = extract_sdf_isosurface(&grid);

        assert!(!pos.is_empty(), "should produce vertices");
        assert!(!idx.is_empty(), "should produce triangles");

        // Verify closed manifold
        let mut edge_count: std::collections::HashMap<(u32, u32), u32> = std::collections::HashMap::new();
        for tri in &idx {
            for i in 0..3 {
                let a = tri[i];
                let b = tri[(i + 1) % 3];
                let key = if a < b { (a, b) } else { (b, a) };
                *edge_count.entry(key).or_insert(0) += 1;
            }
        }
        let boundary = edge_count.values().filter(|&&c| c != 2).count();
        assert_eq!(boundary, 0, "mesh should be closed manifold");
    }
}
