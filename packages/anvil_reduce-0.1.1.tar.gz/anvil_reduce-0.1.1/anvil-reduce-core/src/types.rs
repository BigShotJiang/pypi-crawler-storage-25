use nalgebra as na;

pub type Vec3 = na::Vector3<f64>;
pub type Mat3 = na::Matrix3<f64>;

pub type Idx = u32;
pub const INVALID: Idx = u32::MAX;

/// Axis-aligned bounding box.
#[derive(Clone, Copy, Debug)]
pub struct BBox {
    pub min: Vec3,
    pub max: Vec3,
}

impl BBox {
    pub fn empty() -> Self {
        Self {
            min: Vec3::new(f64::MAX, f64::MAX, f64::MAX),
            max: Vec3::new(f64::MIN, f64::MIN, f64::MIN),
        }
    }

    pub fn expand(&mut self, p: Vec3) {
        self.min = self.min.inf(&p);
        self.max = self.max.sup(&p);
    }

    pub fn diagonal(&self) -> f64 {
        (self.max - self.min).norm()
    }
}
