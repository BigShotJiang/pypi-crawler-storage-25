//! Volume proxy pipeline: voxelize → dilate → marching cubes → mesh.
//!
//! Produces a clean manifold mesh that approximates the volume of the input,
//! bypassing the topology issues inherent in edge-collapse decimation.

use crate::half_edge::HalfEdgeMesh;
use crate::marching_cubes;
use crate::progress::{is_quiet, Reporter};
use crate::voxelize::VoxelGrid;

/// Settings for proxy mesh generation.
#[derive(Clone, Debug)]
pub struct ProxySettings {
    /// Voxel grid resolution along the longest axis.
    pub voxel_resolution: usize,
    /// Number of dilation iterations (expands the volume outward).
    /// 0 = tight wrap, 1-3 = progressively looser hull.
    pub dilation: usize,
    /// Number of Taubin smoothing iterations (0 = no smoothing).
    pub smooth_iterations: usize,
    /// Smoothing lambda (0.0-1.0). Higher = more aggressive per iteration.
    pub smooth_lambda: f64,
    /// Number of isotropic remeshing iterations (0 = skip).
    pub remesh_iterations: usize,
    /// Use signed distance field instead of binary voxelization.
    /// Produces smoother output with fewer smoothing iterations needed.
    pub use_sdf: bool,
    /// Use curvature-adaptive remeshing (denser near features, coarser on flat areas).
    pub adaptive_remesh: bool,
    /// Use bilateral smoothing instead of Taubin. Preserves sharp edges/creases.
    /// sigma_n controls feature sensitivity: 0.1 = very sharp, 1.0 = like Laplacian.
    pub bilateral: bool,
    /// Bilateral normal weight sigma. Lower = sharper feature preservation.
    pub bilateral_sigma_n: f64,
    /// Shrink-fit max displacement, in voxel cells. After marching cubes (and
    /// any smoothing/remeshing), each proxy vertex is snapped inward toward
    /// the nearest input vertex by up to this many voxel cells. Counters the
    /// outward bias from voxelization (~½ cell) plus dilation. 0.0 disables.
    pub shrink_fit_voxels: f64,
}

impl Default for ProxySettings {
    fn default() -> Self {
        Self {
            voxel_resolution: 64,
            dilation: 1,
            smooth_iterations: 10,
            smooth_lambda: 0.5,
            remesh_iterations: 0,
            use_sdf: false,
            adaptive_remesh: false,
            bilateral: false,
            bilateral_sigma_n: 0.3,
            shrink_fit_voxels: 1.5,
        }
    }
}

/// Generate a proxy mesh from the input via voxelization + marching cubes.
///
/// Returns raw (positions, triangle_indices) — no HalfEdgeMesh needed.
pub fn generate_proxy(
    mesh: &HalfEdgeMesh,
    settings: &ProxySettings,
) -> (Vec<[f64; 3]>, Vec<[u32; 3]>) {
    let mut grid = VoxelGrid::from_mesh(mesh, settings.voxel_resolution);

    if settings.dilation > 0 {
        let r = Reporter::untimed(format!("dilate (×{})", settings.dilation));
        grid.dilate(settings.dilation);
        r.finish();
    }

    let (positions, indices) = marching_cubes::extract_isosurface(&grid);

    if !is_quiet() {
        eprintln!(
            "  proxy: {} vertices, {} faces",
            positions.len(),
            indices.len()
        );
    }

    (positions, indices)
}

/// Generate a proxy mesh from raw triangle soup (no half-edge mesh needed).
///
/// This handles non-manifold meshes that cannot be loaded into a HalfEdgeMesh.
/// Applies Taubin smoothing to produce organic-looking output.
pub fn generate_proxy_raw(
    positions: &[[f64; 3]],
    indices: &[[u32; 3]],
    settings: &ProxySettings,
) -> (Vec<[f64; 3]>, Vec<[u32; 3]>) {
    let (cell_size, (mut out_positions, mut out_indices)) = if settings.use_sdf {
        let mut sdf = crate::sdf::SdfGrid::from_raw_triangles(
            positions,
            indices,
            settings.voxel_resolution,
        );

        if settings.dilation > 0 {
            let amount = sdf.cell_size * settings.dilation as f64;
            let r = Reporter::untimed(format!("dilate SDF by {amount:.4}"));
            sdf.dilate(amount);
            r.finish();
        }

        let cs = sdf.cell_size;
        (cs, crate::sdf::extract_sdf_isosurface(&sdf))
    } else {
        let mut grid =
            VoxelGrid::from_raw_triangles(positions, indices, settings.voxel_resolution);

        if settings.dilation > 0 {
            let r = Reporter::untimed(format!("dilate (×{})", settings.dilation));
            grid.dilate(settings.dilation);
            r.finish();
        }

        let cs = grid.cell_size;
        (cs, marching_cubes::extract_isosurface(&grid))
    };

    if settings.smooth_iterations > 0 {
        if settings.bilateral {
            crate::smooth::bilateral_smooth(
                &mut out_positions,
                &out_indices,
                settings.smooth_iterations,
                settings.bilateral_sigma_n,
            );
        } else {
            crate::smooth::taubin_smooth(
                &mut out_positions,
                &out_indices,
                settings.smooth_iterations,
                settings.smooth_lambda,
            );
        }
    }

    if settings.remesh_iterations > 0 {
        let remesh_settings = crate::remesh::RemeshSettings {
            target_edge_length: None,
            iterations: settings.remesh_iterations,
            smooth_lambda: 0.3,
            adaptive: settings.adaptive_remesh,
            ..Default::default()
        };
        let (r_pos, r_idx) = crate::remesh::isotropic_remesh(&out_positions, &out_indices, &remesh_settings);
        out_positions = r_pos;
        out_indices = r_idx;
    }

    if settings.shrink_fit_voxels > 0.0 {
        let max_disp = settings.shrink_fit_voxels * cell_size;
        let r = Reporter::untimed(format!(
            "shrink-fit ({:.2} voxels = {max_disp:.4} world)",
            settings.shrink_fit_voxels
        ));
        crate::shrink_fit::shrink_fit(&mut out_positions, positions, max_disp);
        r.finish();
    }

    if !is_quiet() {
        eprintln!(
            "  proxy: {} vertices, {} faces",
            out_positions.len(),
            out_indices.len()
        );
    }

    (out_positions, out_indices)
}
