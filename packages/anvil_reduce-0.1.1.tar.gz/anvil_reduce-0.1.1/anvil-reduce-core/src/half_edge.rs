//! Arena-based half-edge mesh data structure.
//!
//! All elements (vertices, half-edges, faces) live in contiguous `Vec`s and
//! reference each other by index. This is cache-friendly and avoids the
//! borrow-checker issues that pointer-based half-edge meshes have in Rust.

use std::collections::HashMap;

use crate::error::MeshError;
use crate::types::*;

bitflags::bitflags! {
    #[derive(Clone, Copy, Debug, PartialEq, Eq)]
    pub struct VertexFlags: u8 {
        const BOUNDARY = 0b0001;
        const UV_SEAM  = 0b0010;
        const LOCKED   = 0b0100;
        const DELETED  = 0b1000;
    }
}

#[derive(Clone, Debug)]
pub(crate) struct Vertex {
    pub(crate) position: Vec3,
    pub(crate) halfedge: Idx,
    pub(crate) flags: VertexFlags,
}

#[derive(Clone, Debug)]
pub(crate) struct HalfEdge {
    pub(crate) vertex: Idx,     // target vertex
    pub(crate) face: Idx,       // left face (INVALID if boundary)
    pub(crate) next: Idx,       // next half-edge in face loop
    pub(crate) prev: Idx,       // prev half-edge in face loop
    pub(crate) opposite: Idx,   // twin half-edge

    // Per-face-corner attributes
    pub(crate) uv: Option<[f32; 2]>,
    pub(crate) normal: Option<Vec3>,
}

#[derive(Clone, Debug)]
pub(crate) struct Face {
    pub(crate) halfedge: Idx,
    pub(crate) deleted: bool,
}

pub struct HalfEdgeMesh {
    pub(crate) vertices: Vec<Vertex>,
    pub(crate) halfedges: Vec<HalfEdge>,
    pub(crate) faces: Vec<Face>,

    pub(crate) colors: Option<Vec<[f32; 4]>>,

    // Packed skinning weights
    pub(crate) weight_offsets: Option<Vec<(u32, u16)>>,
    pub(crate) weight_data: Option<Vec<(Idx, f32)>>,
}

/// Canonical edge key: (min_vertex, max_vertex).
fn edge_key(a: Idx, b: Idx) -> (Idx, Idx) {
    if a < b { (a, b) } else { (b, a) }
}

impl HalfEdgeMesh {
    /// Build a half-edge mesh from flat index/vertex buffers.
    ///
    /// Handles:
    /// - Boundary edges (unpaired) — creates boundary half-edges with face=INVALID
    /// - Degenerate triangles (zero area) — skipped
    /// - Non-manifold edges (>2 faces sharing an edge) — returns error
    /// - Out-of-range indices — returns error
    pub fn from_indexed_triangles(
        positions: &[[f64; 3]],
        indices: &[[u32; 3]],
    ) -> Result<Self, MeshError> {
        if positions.is_empty() || indices.is_empty() {
            return Err(MeshError::EmptyMesh);
        }

        let n_verts = positions.len();
        let n_faces = indices.len();

        // Validate indices
        for (fi, tri) in indices.iter().enumerate() {
            for &idx in tri {
                if idx as usize >= n_verts {
                    return Err(MeshError::InvalidIndex {
                        face: fi,
                        index: idx,
                        vertex_count: n_verts,
                    });
                }
            }
        }

        // 1. Create vertices
        let vertices: Vec<Vertex> = positions
            .iter()
            .map(|p| Vertex {
                position: Vec3::new(p[0], p[1], p[2]),
                halfedge: INVALID,
                flags: VertexFlags::empty(),
            })
            .collect();

        // 2. Allocate half-edges: 3 per face (we'll add boundary half-edges later)
        let mut halfedges: Vec<HalfEdge> = Vec::with_capacity(n_faces * 3 + n_faces);
        let mut faces: Vec<Face> = Vec::with_capacity(n_faces);

        // Map: edge_key(v0,v1) -> Vec of half-edge indices that go from v0->v1 or v1->v0
        // We need to pair opposites.
        let mut edge_map: HashMap<(Idx, Idx), Vec<Idx>> = HashMap::new();

        // Track which faces are degenerate (skipped)
        let mut skipped = 0usize;

        for tri in indices {
            let v0 = tri[0];
            let v1 = tri[1];
            let v2 = tri[2];

            // Skip degenerate triangles
            let p0 = Vec3::new(
                positions[v0 as usize][0],
                positions[v0 as usize][1],
                positions[v0 as usize][2],
            );
            let p1 = Vec3::new(
                positions[v1 as usize][0],
                positions[v1 as usize][1],
                positions[v1 as usize][2],
            );
            let p2 = Vec3::new(
                positions[v2 as usize][0],
                positions[v2 as usize][1],
                positions[v2 as usize][2],
            );
            let cross = (p1 - p0).cross(&(p2 - p0));
            if cross.norm() < f64::EPSILON * 100.0 {
                skipped += 1;
                continue;
            }

            let fi = faces.len() as Idx;
            let he_base = halfedges.len() as Idx;

            // Create 3 half-edges for this face
            let verts = [v0, v1, v2];
            for i in 0..3 {
                let target = verts[(i + 1) % 3];
                halfedges.push(HalfEdge {
                    vertex: target,
                    face: fi,
                    next: he_base + ((i as Idx + 1) % 3),
                    prev: he_base + ((i as Idx + 2) % 3),
                    opposite: INVALID,
                    uv: None,
                    normal: None,
                });
            }

            faces.push(Face {
                halfedge: he_base,
                deleted: false,
            });

            // Register edges for opposite pairing
            // half-edge i goes from verts[i] -> verts[(i+1)%3]
            for i in 0..3u32 {
                let src = verts[i as usize];
                let dst = verts[((i + 1) % 3) as usize];
                let key = edge_key(src, dst);
                edge_map.entry(key).or_default().push(he_base + i);
            }
        }

        let _ = skipped; // could log this

        // 3. Pair opposite half-edges
        let mut boundary_edges: Vec<(Idx, Idx)> = Vec::new(); // (he_idx, src_vertex)

        for (key, hes) in &edge_map {
            if hes.len() == 2 {
                // Manifold edge: pair the two half-edges
                let he_a = hes[0];
                let he_b = hes[1];
                halfedges[he_a as usize].opposite = he_b;
                halfedges[he_b as usize].opposite = he_a;
            } else if hes.len() == 1 {
                // Boundary edge: will create boundary half-edge later
                let he = hes[0];
                // Figure out the source vertex of this half-edge
                let src = halfedges[halfedges[he as usize].prev as usize].vertex;
                boundary_edges.push((he, src));
            } else {
                // Non-manifold: >2 faces share this edge
                return Err(MeshError::NonManifoldEdge(key.0, key.1));
            }
        }

        // 4. Create boundary half-edges for unpaired edges
        // A boundary half-edge goes in the opposite direction with face=INVALID
        for (interior_he, _src_vertex) in &boundary_edges {
            let bnd_idx = halfedges.len() as Idx;
            let interior = &halfedges[*interior_he as usize];
            // Boundary half-edge target is the source of the interior half-edge
            let bnd_target = halfedges[interior.prev as usize].vertex;

            halfedges.push(HalfEdge {
                vertex: bnd_target,
                face: INVALID,
                next: INVALID, // linked below
                prev: INVALID,
                opposite: *interior_he,
                uv: None,
                normal: None,
            });
            halfedges[*interior_he as usize].opposite = bnd_idx;
        }

        // 5. Link boundary half-edges into chains (next/prev)
        // For each boundary vertex, find outgoing boundary half-edges and link them.
        // This requires walking around boundary vertices.
        Self::link_boundary_halfedges(&mut halfedges);

        // 6. Assign one outgoing half-edge per vertex
        let mut mesh = HalfEdgeMesh {
            vertices,
            halfedges,
            faces,
            colors: None,
            weight_offsets: None,
            weight_data: None,
        };
        mesh.assign_vertex_halfedges();
        mesh.mark_boundary_vertices();

        Ok(mesh)
    }

    /// Link boundary half-edges into next/prev chains.
    fn link_boundary_halfedges(halfedges: &mut [HalfEdge]) {
        // Collect all boundary half-edges (face == INVALID)
        // Group by their target vertex: at each boundary vertex, the incoming boundary
        // half-edge's next should be the outgoing boundary half-edge.

        // Map: vertex -> incoming boundary half-edge index
        let mut incoming_at: HashMap<Idx, Idx> = HashMap::new();
        // Map: vertex -> outgoing boundary half-edge index
        let mut outgoing_at: HashMap<Idx, Idx> = HashMap::new();

        for (i, he) in halfedges.iter().enumerate() {
            if he.face == INVALID {
                let he_idx = i as Idx;
                // This boundary he goes from some vertex to he.vertex
                let target = he.vertex;
                incoming_at.insert(target, he_idx);

                // Source vertex: the target of the opposite (interior) half-edge's prev
                let opp = he.opposite;
                if opp != INVALID {
                    let src = halfedges[opp as usize].vertex;
                    outgoing_at.insert(src, he_idx);
                }
            }
        }

        // Link: for each boundary vertex v, incoming_at[v].next = outgoing_at[v]
        for (v, incoming_he) in &incoming_at {
            if let Some(&outgoing_he) = outgoing_at.get(v) {
                halfedges[*incoming_he as usize].next = outgoing_he;
                halfedges[outgoing_he as usize].prev = *incoming_he;
            }
        }
    }

    /// Assign each vertex one outgoing half-edge.
    fn assign_vertex_halfedges(&mut self) {
        for he_idx in 0..self.halfedges.len() {
            let he = &self.halfedges[he_idx];
            if he.face == INVALID {
                continue;
            }
            // This half-edge goes from prev.vertex -> he.vertex
            // So it's "outgoing" from prev.vertex
            let src = self.halfedges[he.prev as usize].vertex;
            // Prefer assigning interior half-edges
            if self.vertices[src as usize].halfedge == INVALID {
                self.vertices[src as usize].halfedge = he_idx as Idx;
            }
        }
    }

    /// Mark boundary vertices.
    fn mark_boundary_vertices(&mut self) {
        for he in &self.halfedges {
            if he.face == INVALID {
                // The target of a boundary half-edge is a boundary vertex
                self.vertices[he.vertex as usize]
                    .flags
                    .insert(VertexFlags::BOUNDARY);
                // The source is also on the boundary
                let opp = he.opposite;
                if opp != INVALID {
                    let src = self.halfedges[opp as usize].vertex;
                    self.vertices[src as usize]
                        .flags
                        .insert(VertexFlags::BOUNDARY);
                }
            }
        }
    }

    /// Export back to flat index/vertex buffers.
    /// Only includes non-deleted faces and their referenced vertices.
    /// Skips faces with invalid topology (e.g., from incomplete collapse cleanup).
    pub fn to_indexed_triangles(&self) -> (Vec<[f64; 3]>, Vec<[u32; 3]>) {
        // Build vertex remap table
        let mut used = vec![false; self.vertices.len()];
        let mut face_data: Vec<[Idx; 3]> = Vec::new();

        for face in &self.faces {
            if face.deleted {
                continue;
            }
            let he0 = face.halfedge;
            if he0 == INVALID || he0 as usize >= self.halfedges.len() {
                continue;
            }
            let he1 = self.halfedges[he0 as usize].next;
            if he1 == INVALID || he1 as usize >= self.halfedges.len() {
                continue;
            }
            let prev0 = self.halfedges[he0 as usize].prev;
            if prev0 == INVALID || prev0 as usize >= self.halfedges.len() {
                continue;
            }

            // Get source vertex of each half-edge
            let v0 = self.halfedges[prev0 as usize].vertex;
            let v1 = self.halfedges[he0 as usize].vertex;
            let v2 = self.halfedges[he1 as usize].vertex;

            // Skip faces with deleted or invalid vertices
            if v0 == INVALID || v1 == INVALID || v2 == INVALID {
                continue;
            }
            if v0 as usize >= self.vertices.len()
                || v1 as usize >= self.vertices.len()
                || v2 as usize >= self.vertices.len()
            {
                continue;
            }
            if self.vertices[v0 as usize].flags.contains(VertexFlags::DELETED)
                || self.vertices[v1 as usize].flags.contains(VertexFlags::DELETED)
                || self.vertices[v2 as usize].flags.contains(VertexFlags::DELETED)
            {
                continue;
            }

            used[v0 as usize] = true;
            used[v1 as usize] = true;
            used[v2 as usize] = true;
            face_data.push([v0, v1, v2]);
        }

        // Build compacted vertex array with remap
        let mut remap = vec![INVALID; self.vertices.len()];
        let mut positions: Vec<[f64; 3]> = Vec::new();

        for (i, &is_used) in used.iter().enumerate() {
            if is_used {
                remap[i] = positions.len() as Idx;
                let p = self.vertices[i].position;
                positions.push([p.x, p.y, p.z]);
            }
        }

        // Remap face indices
        let indices: Vec<[u32; 3]> = face_data
            .iter()
            .map(|f| [remap[f[0] as usize], remap[f[1] as usize], remap[f[2] as usize]])
            .collect();

        (positions, indices)
    }

    // ---- Accessors ----

    pub fn vertex_count(&self) -> usize {
        self.vertices
            .iter()
            .filter(|v| !v.flags.contains(VertexFlags::DELETED))
            .count()
    }

    pub fn active_face_count(&self) -> u32 {
        self.faces.iter().filter(|f| !f.deleted).count() as u32
    }

    pub fn bounding_box(&self) -> BBox {
        let mut bbox = BBox::empty();
        for v in &self.vertices {
            if !v.flags.contains(VertexFlags::DELETED) {
                bbox.expand(v.position);
            }
        }
        bbox
    }

    /// Get the three vertex indices of a face.
    pub fn face_vertex_indices(&self, fi: Idx) -> [Idx; 3] {
        let he0 = self.faces[fi as usize].halfedge;
        let he1 = self.halfedges[he0 as usize].next;

        // half-edge target vertices give us two, prev of first gives third
        let v0 = self.halfedges[self.halfedges[he0 as usize].prev as usize].vertex;
        let v1 = self.halfedges[he0 as usize].vertex;
        let v2 = self.halfedges[he1 as usize].vertex;

        [v0, v1, v2]
    }

    /// Check if a half-edge is on the mesh boundary.
    pub fn is_boundary_edge(&self, he: Idx) -> bool {
        let opp = self.halfedges[he as usize].opposite;
        opp == INVALID || self.halfedges[opp as usize].face == INVALID
    }

    /// Check if a half-edge is on a UV seam (different UVs on each side).
    pub fn is_uv_seam_edge(&self, he: Idx) -> bool {
        let opp = self.halfedges[he as usize].opposite;
        if opp == INVALID {
            return false;
        }

        match (&self.halfedges[he as usize].uv, &self.halfedges[opp as usize].uv) {
            (Some(uv_a), Some(uv_b)) => {
                let du = (uv_a[0] - uv_b[0]).abs();
                let dv = (uv_a[1] - uv_b[1]).abs();
                du > 1e-6 || dv > 1e-6
            }
            _ => false,
        }
    }

    /// Set per-corner UV coordinates from a flat array (3 UVs per face, in face order).
    pub fn set_corner_uvs(&mut self, uvs: Option<Vec<[f32; 2]>>) {
        let Some(uvs) = uvs else { return };
        let mut uv_idx = 0;
        for face in &self.faces {
            if face.deleted {
                continue;
            }
            let he0 = face.halfedge as usize;
            let he1 = self.halfedges[he0].next as usize;
            let he2 = self.halfedges[he1].next as usize;

            if uv_idx + 2 < uvs.len() {
                self.halfedges[he0].uv = Some(uvs[uv_idx]);
                self.halfedges[he1].uv = Some(uvs[uv_idx + 1]);
                self.halfedges[he2].uv = Some(uvs[uv_idx + 2]);
            }
            uv_idx += 3;
        }
    }

    /// Set per-corner normals from a flat array (3 normals per face, in face order).
    pub fn set_corner_normals(&mut self, normals: Option<Vec<Vec3>>) {
        let Some(normals) = normals else { return };
        let mut n_idx = 0;
        for face in &self.faces {
            if face.deleted {
                continue;
            }
            let he0 = face.halfedge as usize;
            let he1 = self.halfedges[he0].next as usize;
            let he2 = self.halfedges[he1].next as usize;

            if n_idx + 2 < normals.len() {
                self.halfedges[he0].normal = Some(normals[n_idx]);
                self.halfedges[he1].normal = Some(normals[n_idx + 1]);
                self.halfedges[he2].normal = Some(normals[n_idx + 2]);
            }
            n_idx += 3;
        }
    }

    /// Iterate half-edges around a vertex (one-ring).
    /// Returns the half-edge indices of all outgoing half-edges from vertex `v`.
    ///
    /// Walks CCW via opposite→next. For boundary vertices, also walks CW via
    /// prev→opposite to collect the other side. Includes a max-iteration guard
    /// to prevent infinite loops on corrupted topology.
    pub fn vertex_outgoing_halfedges(&self, v: Idx) -> Vec<Idx> {
        let start = self.vertices[v as usize].halfedge;
        if start == INVALID {
            return Vec::new();
        }

        let max_iter = self.halfedges.len();
        let mut result = Vec::new();
        let mut current = start;
        let mut hit_boundary = false;

        // Walk CCW: current → opposite → next
        loop {
            result.push(current);
            if result.len() >= max_iter {
                break; // corrupted topology guard
            }

            let opp = self.halfedges[current as usize].opposite;
            if opp == INVALID || self.halfedges[opp as usize].face == INVALID {
                hit_boundary = true;
                break;
            }
            let next = self.halfedges[opp as usize].next;
            if next == INVALID || next == start {
                break;
            }
            current = next;
        }

        // For boundary vertices the CCW walk stops at one edge of the fan.
        // Walk CW from start to pick up the other side: prev → opposite
        if hit_boundary {
            current = start;
            loop {
                let prev_he = self.halfedges[current as usize].prev;
                if prev_he == INVALID {
                    break;
                }
                let prev_opp = self.halfedges[prev_he as usize].opposite;
                if prev_opp == INVALID || self.halfedges[prev_opp as usize].face == INVALID {
                    break;
                }
                current = prev_opp;
                result.push(current);
                if result.len() >= max_iter {
                    break;
                }
            }
        }

        result
    }

    /// Remove deleted elements and remap all indices.
    pub(crate) fn compact(&mut self) {
        // Build vertex remap
        let mut v_remap = vec![INVALID; self.vertices.len()];
        let mut new_verts = Vec::new();
        for (i, v) in self.vertices.iter().enumerate() {
            if !v.flags.contains(VertexFlags::DELETED) {
                v_remap[i] = new_verts.len() as Idx;
                new_verts.push(v.clone());
            }
        }

        // Build face remap
        let mut f_remap = vec![INVALID; self.faces.len()];
        let mut new_faces = Vec::new();
        for (i, f) in self.faces.iter().enumerate() {
            if !f.deleted {
                f_remap[i] = new_faces.len() as Idx;
                new_faces.push(f.clone());
            }
        }

        // Build half-edge remap: keep half-edges whose face is kept OR
        // boundary half-edges whose opposite's face is kept
        let mut he_remap = vec![INVALID; self.halfedges.len()];
        let mut new_hes = Vec::new();
        for (i, he) in self.halfedges.iter().enumerate() {
            let keep = if he.face != INVALID {
                !self.faces[he.face as usize].deleted
            } else {
                // Boundary half-edge: keep if opposite is kept
                he.opposite != INVALID
                    && self.halfedges[he.opposite as usize].face != INVALID
                    && !self.faces[self.halfedges[he.opposite as usize].face as usize].deleted
            };
            if keep {
                he_remap[i] = new_hes.len() as Idx;
                new_hes.push(he.clone());
            }
        }

        // Remap all indices in new half-edges
        for he in &mut new_hes {
            he.vertex = v_remap[he.vertex as usize];
            if he.face != INVALID {
                he.face = f_remap[he.face as usize];
            }
            if he.next != INVALID {
                he.next = he_remap[he.next as usize];
            }
            if he.prev != INVALID {
                he.prev = he_remap[he.prev as usize];
            }
            if he.opposite != INVALID {
                he.opposite = he_remap[he.opposite as usize];
            }
        }

        // Remap vertex halfedge references
        for v in &mut new_verts {
            if v.halfedge != INVALID {
                v.halfedge = he_remap[v.halfedge as usize];
            }
        }

        // Remap face halfedge references
        for f in &mut new_faces {
            if f.halfedge != INVALID {
                f.halfedge = he_remap[f.halfedge as usize];
            }
        }

        // Remap colors if present
        if let Some(ref colors) = self.colors {
            let mut new_colors = Vec::with_capacity(new_verts.len());
            for (i, &remap) in v_remap.iter().enumerate() {
                if remap != INVALID && i < colors.len() {
                    new_colors.push(colors[i]);
                }
            }
            self.colors = Some(new_colors);
        }

        self.vertices = new_verts;
        self.halfedges = new_hes;
        self.faces = new_faces;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn single_triangle() -> HalfEdgeMesh {
        let positions = [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 1.0, 0.0]];
        let indices = [[0, 1, 2]];
        HalfEdgeMesh::from_indexed_triangles(&positions, &indices).unwrap()
    }

    fn two_triangles() -> HalfEdgeMesh {
        // Two triangles sharing edge 1-2
        let positions = [
            [0.0, 0.0, 0.0],
            [1.0, 0.0, 0.0],
            [0.5, 1.0, 0.0],
            [1.5, 1.0, 0.0],
        ];
        let indices = [[0, 1, 2], [1, 3, 2]];
        HalfEdgeMesh::from_indexed_triangles(&positions, &indices).unwrap()
    }

    #[test]
    fn single_triangle_structure() {
        let mesh = single_triangle();
        assert_eq!(mesh.vertices.len(), 3);
        assert_eq!(mesh.active_face_count(), 1);
        // 3 interior + 3 boundary half-edges
        assert_eq!(mesh.halfedges.len(), 6);
    }

    #[test]
    fn two_triangle_shared_edge() {
        let mesh = two_triangles();
        assert_eq!(mesh.vertices.len(), 4);
        assert_eq!(mesh.active_face_count(), 2);
        // 6 interior half-edges + 4 boundary (4 boundary edges)
        assert_eq!(mesh.halfedges.len(), 10);
    }

    #[test]
    fn boundary_vertices_marked() {
        let mesh = single_triangle();
        for v in &mesh.vertices {
            assert!(v.flags.contains(VertexFlags::BOUNDARY));
        }
    }

    #[test]
    fn all_vertices_have_halfedge() {
        let mesh = two_triangles();
        for v in &mesh.vertices {
            assert_ne!(v.halfedge, INVALID);
        }
    }

    #[test]
    fn opposite_pairing() {
        let mesh = two_triangles();
        for (i, he) in mesh.halfedges.iter().enumerate() {
            if he.opposite != INVALID {
                let opp = &mesh.halfedges[he.opposite as usize];
                assert_eq!(opp.opposite, i as Idx, "opposite should be symmetric");
            }
        }
    }

    #[test]
    fn next_prev_consistency() {
        let mesh = two_triangles();
        for (i, he) in mesh.halfedges.iter().enumerate() {
            if he.next != INVALID {
                let next = &mesh.halfedges[he.next as usize];
                assert_eq!(next.prev, i as Idx, "next.prev should point back");
            }
        }
    }

    #[test]
    fn roundtrip_export() {
        let positions = [
            [0.0, 0.0, 0.0],
            [1.0, 0.0, 0.0],
            [0.5, 1.0, 0.0],
            [1.5, 1.0, 0.0],
        ];
        let indices = [[0u32, 1, 2], [1, 3, 2]];
        let mesh = HalfEdgeMesh::from_indexed_triangles(&positions, &indices).unwrap();
        let (out_pos, out_idx) = mesh.to_indexed_triangles();
        assert_eq!(out_pos.len(), 4);
        assert_eq!(out_idx.len(), 2);
    }

    #[test]
    fn rejects_empty_mesh() {
        let result = HalfEdgeMesh::from_indexed_triangles(&[], &[]);
        assert!(result.is_err());
    }

    #[test]
    fn rejects_invalid_index() {
        let positions = [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]];
        let indices = [[0, 1, 5]]; // 5 is out of range
        let result = HalfEdgeMesh::from_indexed_triangles(&positions, &indices);
        assert!(result.is_err());
    }

    #[test]
    fn skips_degenerate_triangles() {
        // Collinear points
        let positions = [
            [0.0, 0.0, 0.0],
            [1.0, 0.0, 0.0],
            [2.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
        ];
        // First triangle is degenerate, second is valid
        let indices = [[0, 1, 2], [0, 1, 3]];
        let mesh = HalfEdgeMesh::from_indexed_triangles(&positions, &indices).unwrap();
        assert_eq!(mesh.active_face_count(), 1);
    }

    #[test]
    fn face_vertex_indices_correct() {
        let mesh = single_triangle();
        let verts = mesh.face_vertex_indices(0);
        // Should contain {0, 1, 2} in some order
        let mut sorted = verts;
        sorted.sort();
        assert_eq!(sorted, [0, 1, 2]);
    }

    #[test]
    fn compact_preserves_structure() {
        let mut mesh = two_triangles();
        // Mark first face as deleted
        mesh.faces[0].deleted = true;
        // Mark its vertices that aren't shared
        // vertex 0 is only in face 0
        mesh.vertices[0].flags.insert(VertexFlags::DELETED);

        mesh.compact();

        assert_eq!(mesh.active_face_count(), 1);
        // All remaining indices should be valid
        for he in &mesh.halfedges {
            if he.face != INVALID {
                assert!((he.face as usize) < mesh.faces.len());
            }
            assert!((he.vertex as usize) < mesh.vertices.len());
        }
    }
}
