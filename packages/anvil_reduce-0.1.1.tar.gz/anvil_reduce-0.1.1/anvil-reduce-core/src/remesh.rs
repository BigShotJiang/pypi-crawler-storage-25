//! Isotropic remeshing: produces organic, curvature-adaptive triangulation.
//!
//! Takes a triangle mesh and iteratively:
//! 1. Splits edges longer than 4/3 * target_length
//! 2. Collapses edges shorter than 4/5 * target_length
//! 3. Flips edges to improve vertex valence toward 6
//! 4. Applies tangential Laplacian smoothing
//!
//! The result has uniform-ish edge lengths with smooth, organic triangulation.

use rustc_hash::{FxHashMap as HashMap, FxHashSet as HashSet};

/// A lightweight triangle mesh for remeshing operations.
///
/// Uses indexed triangles with a lazily-rebuilt edge adjacency map.
pub struct RemeshMesh {
    pub positions: Vec<[f64; 3]>,
    pub triangles: Vec<[u32; 3]>,
    /// Marks deleted triangles (lazy deletion).
    deleted: Vec<bool>,
}

impl RemeshMesh {
    pub fn new(positions: Vec<[f64; 3]>, triangles: Vec<[u32; 3]>) -> Self {
        let n = triangles.len();
        Self {
            positions,
            triangles,
            deleted: vec![false; n],
        }
    }

    /// Number of active (non-deleted) triangles.
    pub fn active_tri_count(&self) -> usize {
        self.deleted.iter().filter(|&&d| !d).count()
    }

    /// Compact the mesh, removing deleted triangles and unreferenced vertices.
    pub fn compact(&mut self) {
        // Remove deleted triangles
        let mut new_tris = Vec::new();
        for (i, tri) in self.triangles.iter().enumerate() {
            if !self.deleted[i] {
                new_tris.push(*tri);
            }
        }

        // Find referenced vertices
        let mut used = vec![false; self.positions.len()];
        for tri in &new_tris {
            for &vi in tri {
                used[vi as usize] = true;
            }
        }

        // Build remap
        let mut remap = vec![u32::MAX; self.positions.len()];
        let mut new_positions = Vec::new();
        for (i, &u) in used.iter().enumerate() {
            if u {
                remap[i] = new_positions.len() as u32;
                new_positions.push(self.positions[i]);
            }
        }

        // Remap triangle indices
        for tri in &mut new_tris {
            for vi in tri.iter_mut() {
                *vi = remap[*vi as usize];
            }
        }

        self.positions = new_positions;
        self.triangles = new_tris;
        self.deleted = vec![false; self.triangles.len()];
    }

    /// Remove degenerate and flipped triangles.
    ///
    /// 1. Removes triangles with near-zero area (degenerate).
    /// 2. Computes per-vertex normals (area-weighted), then removes any triangle
    ///    whose face normal disagrees with its vertex-averaged normal. These are
    ///    the "flipped" faces that appear as holes in the rendered mesh.
    /// 3. Removes non-manifold edges (shared by >2 active triangles).
    fn cleanup(&mut self) {
        let min_area_sq = 1e-20;

        // Pass 1: remove degenerate triangles
        for ti in 0..self.triangles.len() {
            if self.deleted[ti] {
                continue;
            }
            let tri = self.triangles[ti];
            if tri[0] == tri[1] || tri[1] == tri[2] || tri[0] == tri[2] {
                self.deleted[ti] = true;
                continue;
            }
            let n = tri_normal(
                &self.positions[tri[0] as usize],
                &self.positions[tri[1] as usize],
                &self.positions[tri[2] as usize],
            );
            let area_sq = n[0] * n[0] + n[1] * n[1] + n[2] * n[2];
            if area_sq < min_area_sq {
                self.deleted[ti] = true;
            }
        }

        // Pass 2: compute area-weighted vertex normals
        let n_verts = self.positions.len();
        let mut vertex_normals = vec![[0.0f64; 3]; n_verts];
        for (ti, tri) in self.triangles.iter().enumerate() {
            if self.deleted[ti] {
                continue;
            }
            let fn_ = tri_normal(
                &self.positions[tri[0] as usize],
                &self.positions[tri[1] as usize],
                &self.positions[tri[2] as usize],
            );
            for &vi in tri {
                vertex_normals[vi as usize][0] += fn_[0];
                vertex_normals[vi as usize][1] += fn_[1];
                vertex_normals[vi as usize][2] += fn_[2];
            }
        }

        // Pass 3: remove triangles whose normal disagrees with vertex average
        let mut removed = 0usize;
        for (ti, tri) in self.triangles.iter().enumerate() {
            if self.deleted[ti] {
                continue;
            }
            let fn_ = tri_normal(
                &self.positions[tri[0] as usize],
                &self.positions[tri[1] as usize],
                &self.positions[tri[2] as usize],
            );
            // Average the vertex normals at the three corners
            let mut avg = [0.0f64; 3];
            for &vi in tri {
                avg[0] += vertex_normals[vi as usize][0];
                avg[1] += vertex_normals[vi as usize][1];
                avg[2] += vertex_normals[vi as usize][2];
            }
            // If face normal points opposite to vertex-averaged normal, it's flipped
            let d = fn_[0] * avg[0] + fn_[1] * avg[1] + fn_[2] * avg[2];
            if d < 0.0 {
                self.deleted[ti] = true;
                removed += 1;
            }
        }

        // Pass 4: remove non-manifold edges (shared by >2 triangles)
        let edge_map = self.build_edge_map();
        for (_edge, tris) in &edge_map {
            let active: Vec<usize> = tris.iter().copied().filter(|&ti| !self.deleted[ti]).collect();
            if active.len() > 2 {
                // Keep the 2 triangles with most consistent normals, remove the rest
                for &ti in &active[2..] {
                    self.deleted[ti] = true;
                    removed += 1;
                }
            }
        }

        if removed > 0 {
            eprintln!("    Cleanup: removed {} bad triangles", removed);
        }
    }

    /// Export as (positions, indices).
    pub fn into_buffers(mut self) -> (Vec<[f64; 3]>, Vec<[u32; 3]>) {
        self.cleanup();
        self.compact();
        (self.positions, self.triangles)
    }

    // ---- Edge helpers ----

    fn edge_key(a: u32, b: u32) -> (u32, u32) {
        if a < b { (a, b) } else { (b, a) }
    }

    fn edge_length(&self, a: u32, b: u32) -> f64 {
        let pa = &self.positions[a as usize];
        let pb = &self.positions[b as usize];
        let dx = pa[0] - pb[0];
        let dy = pa[1] - pb[1];
        let dz = pa[2] - pb[2];
        (dx * dx + dy * dy + dz * dz).sqrt()
    }

    /// Build edge -> [triangle indices] map for active triangles.
    fn build_edge_map(&self) -> HashMap<(u32, u32), Vec<usize>> {
        let mut map: HashMap<(u32, u32), Vec<usize>> = HashMap::default();
        for (ti, tri) in self.triangles.iter().enumerate() {
            if self.deleted[ti] {
                continue;
            }
            for k in 0..3 {
                let e = Self::edge_key(tri[k], tri[(k + 1) % 3]);
                map.entry(e).or_default().push(ti);
            }
        }
        map
    }

    /// Build vertex -> [triangle indices] map for active triangles.
    fn build_vertex_tris(&self) -> HashMap<u32, Vec<usize>> {
        let mut map: HashMap<u32, Vec<usize>> = HashMap::default();
        for (ti, tri) in self.triangles.iter().enumerate() {
            if self.deleted[ti] {
                continue;
            }
            for &vi in tri {
                map.entry(vi).or_default().push(ti);
            }
        }
        map
    }

    /// Get unique neighbor vertices of a vertex.
    fn vertex_neighbors(&self, vi: u32, vtris: &HashMap<u32, Vec<usize>>) -> Vec<u32> {
        let mut neighbors = HashSet::default();
        if let Some(tris) = vtris.get(&vi) {
            for &ti in tris {
                if self.deleted[ti] {
                    continue;
                }
                for &v in &self.triangles[ti] {
                    if v != vi {
                        neighbors.insert(v);
                    }
                }
            }
        }
        neighbors.into_iter().collect()
    }

    /// Check if an edge is on the mesh boundary (shared by only 1 triangle).
    fn is_boundary_edge(&self, a: u32, b: u32, edge_map: &HashMap<(u32, u32), Vec<usize>>) -> bool {
        let key = Self::edge_key(a, b);
        match edge_map.get(&key) {
            Some(tris) => {
                let active = tris.iter().filter(|&&ti| !self.deleted[ti]).count();
                active < 2
            }
            None => true,
        }
    }

    /// Check if a vertex is on the boundary.
    fn is_boundary_vertex(&self, vi: u32, vtris: &HashMap<u32, Vec<usize>>, edge_map: &HashMap<(u32, u32), Vec<usize>>) -> bool {
        let neighbors = self.vertex_neighbors(vi, vtris);
        for &ni in &neighbors {
            if self.is_boundary_edge(vi, ni, edge_map) {
                return true;
            }
        }
        false
    }

    /// Vertex valence (number of connected edges).
    fn valence(&self, vi: u32, vtris: &HashMap<u32, Vec<usize>>) -> usize {
        self.vertex_neighbors(vi, vtris).len()
    }

    // ---- Remeshing operations ----

    /// Split an edge at its midpoint. Returns the new vertex index.
    fn split_edge(
        &mut self,
        a: u32,
        b: u32,
        edge_map: &HashMap<(u32, u32), Vec<usize>>,
    ) -> u32 {
        let mid = [
            (self.positions[a as usize][0] + self.positions[b as usize][0]) * 0.5,
            (self.positions[a as usize][1] + self.positions[b as usize][1]) * 0.5,
            (self.positions[a as usize][2] + self.positions[b as usize][2]) * 0.5,
        ];
        let new_vi = self.positions.len() as u32;
        self.positions.push(mid);

        let key = Self::edge_key(a, b);
        let tris = match edge_map.get(&key) {
            Some(t) => t.clone(),
            None => return new_vi,
        };

        for &ti in &tris {
            if self.deleted[ti] {
                continue;
            }
            let tri = self.triangles[ti];
            // Find the third vertex (not a or b)
            let c = if tri[0] != a && tri[0] != b {
                tri[0]
            } else if tri[1] != a && tri[1] != b {
                tri[1]
            } else {
                tri[2]
            };

            // Delete original triangle
            self.deleted[ti] = true;

            // Create 2 new triangles: (a, new_vi, c) and (new_vi, b, c)
            // Preserve winding order from original
            let (va, vb) = self.edge_order_in_tri(&tri, a, b);
            self.triangles.push([va, new_vi, c]);
            self.deleted.push(false);
            self.triangles.push([new_vi, vb, c]);
            self.deleted.push(false);
        }

        new_vi
    }

    /// Get the order of vertices a,b as they appear in the triangle winding.
    fn edge_order_in_tri(&self, tri: &[u32; 3], a: u32, b: u32) -> (u32, u32) {
        for k in 0..3 {
            if tri[k] == a && tri[(k + 1) % 3] == b {
                return (a, b);
            }
        }
        (b, a)
    }

    /// Collapse edge (a,b) by moving a to the midpoint and removing b.
    /// Returns true if successful.
    fn collapse_edge(
        &mut self,
        a: u32,
        b: u32,
        edge_map: &HashMap<(u32, u32), Vec<usize>>,
        vtris: &HashMap<u32, Vec<usize>>,
    ) -> bool {
        // Don't collapse boundary edges
        if self.is_boundary_edge(a, b, edge_map) {
            return false;
        }

        // Link condition: check that collapsing won't create non-manifold topology.
        // The shared neighbors of a and b should be exactly 2 (the triangle tips).
        let a_neighbors: HashSet<u32> = self.vertex_neighbors(a, vtris).into_iter().collect();
        let b_neighbors: HashSet<u32> = self.vertex_neighbors(b, vtris).into_iter().collect();
        let shared: Vec<u32> = a_neighbors.intersection(&b_neighbors).copied().collect();
        if shared.len() != 2 {
            return false;
        }

        // Check that collapse won't invert any triangles
        let mid = [
            (self.positions[a as usize][0] + self.positions[b as usize][0]) * 0.5,
            (self.positions[a as usize][1] + self.positions[b as usize][1]) * 0.5,
            (self.positions[a as usize][2] + self.positions[b as usize][2]) * 0.5,
        ];

        // Check all triangles around a and b (except the ones being deleted)
        let edge_key = Self::edge_key(a, b);
        let deleted_tris: HashSet<usize> = edge_map
            .get(&edge_key)
            .map(|t| t.iter().copied().collect())
            .unwrap_or_default();

        for &vi in &[a, b] {
            if let Some(tris) = vtris.get(&vi) {
                for &ti in tris {
                    if self.deleted[ti] || deleted_tris.contains(&ti) {
                        continue;
                    }
                    let tri = self.triangles[ti];
                    // Replace vi with mid, check normal doesn't flip
                    let mut new_tri = [[0.0f64; 3]; 3];
                    for (k, &v) in tri.iter().enumerate() {
                        if v == a || v == b {
                            new_tri[k] = mid;
                        } else {
                            new_tri[k] = self.positions[v as usize];
                        }
                    }
                    let old_normal = tri_normal(
                        &self.positions[tri[0] as usize],
                        &self.positions[tri[1] as usize],
                        &self.positions[tri[2] as usize],
                    );
                    let new_normal = tri_normal(&new_tri[0], &new_tri[1], &new_tri[2]);
                    if dot3(&old_normal, &new_normal) < 0.0 {
                        return false; // would invert triangle
                    }
                }
            }
        }

        // Move a to midpoint
        self.positions[a as usize] = mid;

        // Delete triangles containing the edge
        if let Some(tris) = edge_map.get(&edge_key) {
            for &ti in tris {
                self.deleted[ti] = true;
            }
        }

        // Replace all occurrences of b with a in remaining triangles
        if let Some(tris) = vtris.get(&b) {
            for &ti in tris {
                if self.deleted[ti] {
                    continue;
                }
                for vi in self.triangles[ti].iter_mut() {
                    if *vi == b {
                        *vi = a;
                    }
                }
                // Check for degenerate triangles (two identical vertices)
                let t = self.triangles[ti];
                if t[0] == t[1] || t[1] == t[2] || t[0] == t[2] {
                    self.deleted[ti] = true;
                }
            }
        }

        true
    }

    /// Flip an edge shared by two triangles. Returns true if flipped.
    fn flip_edge(
        &mut self,
        a: u32,
        b: u32,
        edge_map: &HashMap<(u32, u32), Vec<usize>>,
        vtris: &HashMap<u32, Vec<usize>>,
    ) -> bool {
        let key = Self::edge_key(a, b);
        let tris = match edge_map.get(&key) {
            Some(t) => t,
            None => return false,
        };

        // Need exactly 2 active triangles
        let active: Vec<usize> = tris.iter().copied().filter(|&ti| !self.deleted[ti]).collect();
        if active.len() != 2 {
            return false;
        }

        let t0 = self.triangles[active[0]];
        let t1 = self.triangles[active[1]];

        // Find the two opposite vertices (c and d)
        let c = match t0.iter().find(|&&v| v != a && v != b).copied() {
            Some(v) => v,
            None => return false,
        };
        let d = match t1.iter().find(|&&v| v != a && v != b).copied() {
            Some(v) => v,
            None => return false,
        };

        // Don't flip if it would create a duplicate edge
        let new_edge = Self::edge_key(c, d);
        if edge_map.contains_key(&new_edge) {
            // Check if it's an active edge
            if let Some(existing) = edge_map.get(&new_edge) {
                if existing.iter().any(|&ti| !self.deleted[ti]) {
                    return false;
                }
            }
        }

        // Check valence improvement
        let val_a = self.valence(a, vtris);
        let val_b = self.valence(b, vtris);
        let val_c = self.valence(c, vtris);
        let val_d = self.valence(d, vtris);

        let target = 6;
        let before = (val_a as i32 - target).abs()
            + (val_b as i32 - target).abs()
            + (val_c as i32 - target).abs()
            + (val_d as i32 - target).abs();
        let after = (val_a as i32 - 1 - target).abs()
            + (val_b as i32 - 1 - target).abs()
            + (val_c as i32 + 1 - target).abs()
            + (val_d as i32 + 1 - target).abs();

        if after >= before {
            return false; // no improvement
        }

        // Check that flip doesn't invert normals
        let new_n0 = tri_normal(
            &self.positions[c as usize],
            &self.positions[d as usize],
            &self.positions[a as usize],
        );
        let new_n1 = tri_normal(
            &self.positions[d as usize],
            &self.positions[c as usize],
            &self.positions[b as usize],
        );
        let old_n0 = tri_normal(
            &self.positions[t0[0] as usize],
            &self.positions[t0[1] as usize],
            &self.positions[t0[2] as usize],
        );
        if dot3(&new_n0, &old_n0) < 0.0 || dot3(&new_n1, &old_n0) < 0.0 {
            return false;
        }

        // Perform the flip
        self.deleted[active[0]] = true;
        self.deleted[active[1]] = true;

        // New triangles: (c, d, a) and (d, c, b)
        self.triangles.push([c, d, a]);
        self.deleted.push(false);
        self.triangles.push([d, c, b]);
        self.deleted.push(false);

        true
    }

    /// Tangential Laplacian smoothing: move vertices toward neighbor average,
    /// then project back onto the tangent plane to preserve shape.
    fn tangential_smooth(&mut self, lambda: f64) {
        let vtris = self.build_vertex_tris();
        let edge_map = self.build_edge_map();
        let n = self.positions.len();

        // Compute vertex normals (area-weighted face normals)
        let mut normals = vec![[0.0f64; 3]; n];
        for (ti, tri) in self.triangles.iter().enumerate() {
            if self.deleted[ti] {
                continue;
            }
            let fn_ = tri_normal(
                &self.positions[tri[0] as usize],
                &self.positions[tri[1] as usize],
                &self.positions[tri[2] as usize],
            );
            for &vi in tri {
                normals[vi as usize][0] += fn_[0];
                normals[vi as usize][1] += fn_[1];
                normals[vi as usize][2] += fn_[2];
            }
        }
        for n in &mut normals {
            let len = (n[0] * n[0] + n[1] * n[1] + n[2] * n[2]).sqrt();
            if len > 1e-12 {
                n[0] /= len;
                n[1] /= len;
                n[2] /= len;
            }
        }

        // Compute target positions
        let mut new_positions = self.positions.clone();
        for (vi, pos) in self.positions.iter().enumerate() {
            // Skip boundary vertices
            if self.is_boundary_vertex(vi as u32, &vtris, &edge_map) {
                continue;
            }

            let neighbors = self.vertex_neighbors(vi as u32, &vtris);
            if neighbors.is_empty() {
                continue;
            }

            // Compute centroid of neighbors
            let mut centroid = [0.0f64; 3];
            for &ni in &neighbors {
                centroid[0] += self.positions[ni as usize][0];
                centroid[1] += self.positions[ni as usize][1];
                centroid[2] += self.positions[ni as usize][2];
            }
            let count = neighbors.len() as f64;
            centroid[0] /= count;
            centroid[1] /= count;
            centroid[2] /= count;

            // Displacement toward centroid
            let disp = [
                lambda * (centroid[0] - pos[0]),
                lambda * (centroid[1] - pos[1]),
                lambda * (centroid[2] - pos[2]),
            ];

            // Project displacement onto tangent plane (remove normal component)
            let n = &normals[vi];
            let dot = disp[0] * n[0] + disp[1] * n[1] + disp[2] * n[2];
            new_positions[vi] = [
                pos[0] + disp[0] - dot * n[0],
                pos[1] + disp[1] - dot * n[1],
                pos[2] + disp[2] - dot * n[2],
            ];
        }

        self.positions = new_positions;
    }
}

// ---- Geometry helpers ----

fn tri_normal(a: &[f64; 3], b: &[f64; 3], c: &[f64; 3]) -> [f64; 3] {
    let e1 = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
    let e2 = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
    [
        e1[1] * e2[2] - e1[2] * e2[1],
        e1[2] * e2[0] - e1[0] * e2[2],
        e1[0] * e2[1] - e1[1] * e2[0],
    ]
}

fn dot3(a: &[f64; 3], b: &[f64; 3]) -> f64 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}

// ---- Public API ----

/// Settings for isotropic remeshing.
pub struct RemeshSettings {
    /// Target edge length. If None, computed from average edge length.
    pub target_edge_length: Option<f64>,
    /// Number of remeshing iterations.
    pub iterations: usize,
    /// Smoothing lambda per iteration.
    pub smooth_lambda: f64,
    /// Enable curvature-adaptive edge lengths.
    /// When true, edges in high-curvature areas are kept shorter,
    /// and edges in flat areas are allowed to be longer.
    pub adaptive: bool,
    /// Minimum edge length factor relative to target (for high-curvature areas).
    /// Default: 0.25 (edges can be 1/4 of base target in high-curvature areas).
    pub min_edge_factor: f64,
    /// Maximum edge length factor relative to target (for flat areas).
    /// Default: 3.0 (edges can be 3x base target in flat areas).
    pub max_edge_factor: f64,
}

impl Default for RemeshSettings {
    fn default() -> Self {
        Self {
            target_edge_length: None,
            iterations: 5,
            smooth_lambda: 0.5,
            adaptive: false,
            min_edge_factor: 0.25,
            max_edge_factor: 3.0,
        }
    }
}

/// Compute per-vertex curvature as the mean angle deficit.
///
/// Uses the discrete Gaussian curvature: K = 2π - sum(angles at vertex).
/// Returns absolute curvature normalized to [0, 1] range.
fn compute_vertex_curvature(mesh: &RemeshMesh) -> Vec<f64> {
    let n = mesh.positions.len();
    let mut angle_sum = vec![0.0f64; n];

    for (ti, tri) in mesh.triangles.iter().enumerate() {
        if mesh.deleted[ti] {
            continue;
        }
        // Angle at each vertex
        for k in 0..3 {
            let vi = tri[k] as usize;
            let a = &mesh.positions[tri[k] as usize];
            let b = &mesh.positions[tri[(k + 1) % 3] as usize];
            let c = &mesh.positions[tri[(k + 2) % 3] as usize];

            let ab = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
            let ac = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];

            let lab = (ab[0] * ab[0] + ab[1] * ab[1] + ab[2] * ab[2]).sqrt();
            let lac = (ac[0] * ac[0] + ac[1] * ac[1] + ac[2] * ac[2]).sqrt();

            if lab > 1e-12 && lac > 1e-12 {
                let cos_angle = (ab[0] * ac[0] + ab[1] * ac[1] + ab[2] * ac[2]) / (lab * lac);
                angle_sum[vi] += cos_angle.clamp(-1.0, 1.0).acos();
            }
        }
    }

    // Curvature = |2π - angle_sum|
    let two_pi = 2.0 * std::f64::consts::PI;
    let mut curvature: Vec<f64> = angle_sum
        .iter()
        .map(|&a| (two_pi - a).abs())
        .collect();

    // Normalize to [0, 1] using percentile-based normalization
    // to be robust against outliers
    let mut sorted: Vec<f64> = curvature.iter().copied().filter(|&c| c > 0.0).collect();
    sorted.sort_by(|a, b| a.total_cmp(b));

    if sorted.is_empty() {
        return curvature;
    }

    // Use 95th percentile as max for normalization
    let p95_idx = (sorted.len() as f64 * 0.95) as usize;
    let p95_idx = p95_idx.min(sorted.len() - 1);
    let max_curv = sorted[p95_idx].max(1e-10);

    for c in &mut curvature {
        *c = (*c / max_curv).clamp(0.0, 1.0);
    }

    curvature
}

/// Compute per-edge target length based on endpoint curvature.
fn adaptive_edge_target(
    _mesh: &RemeshMesh,
    a: u32,
    b: u32,
    curvature: &[f64],
    base_target: f64,
    min_factor: f64,
    max_factor: f64,
) -> f64 {
    let ca = curvature[a as usize];
    let cb = curvature[b as usize];
    let c = (ca + cb) * 0.5; // average curvature at edge

    // High curvature (c=1) -> short edges (min_factor * base)
    // Low curvature (c=0) -> long edges (max_factor * base)
    let factor = max_factor + (min_factor - max_factor) * c;
    base_target * factor
}

/// Isotropic remeshing: produces organic triangulation.
///
/// When `settings.adaptive` is true, uses curvature-adaptive edge lengths:
/// shorter edges in high-curvature areas, longer in flat areas.
///
/// Takes raw mesh buffers and returns remeshed buffers.
pub fn isotropic_remesh(
    positions: &[[f64; 3]],
    indices: &[[u32; 3]],
    settings: &RemeshSettings,
) -> (Vec<[f64; 3]>, Vec<[u32; 3]>) {
    let mut mesh = RemeshMesh::new(positions.to_vec(), indices.to_vec());

    // Compute base target edge length
    let target = settings.target_edge_length.unwrap_or_else(|| {
        compute_average_edge_length(&mesh)
    });

    if settings.adaptive {
        eprintln!(
            "    Adaptive remeshing: base_target={:.4}, min_factor={:.2}, max_factor={:.2}, {} iterations",
            target, settings.min_edge_factor, settings.max_edge_factor, settings.iterations
        );

        for iter in 0..settings.iterations {
            let before = mesh.active_tri_count();

            // Recompute curvature each iteration as mesh changes
            let curvature = compute_vertex_curvature(&mesh);

            // 1. Split long edges (adaptive threshold)
            let splits = split_long_edges_adaptive(
                &mut mesh, target, &curvature,
                settings.min_edge_factor, settings.max_edge_factor,
            );

            // Recompute curvature after splits added new vertices
            let curvature = compute_vertex_curvature(&mesh);

            // 2. Collapse short edges (adaptive threshold)
            let collapses = collapse_short_edges_adaptive(
                &mut mesh, target, &curvature,
                settings.min_edge_factor, settings.max_edge_factor,
            );

            // 3. Flip edges to improve valence
            let flips = flip_edges_for_valence(&mut mesh);

            // 4. Tangential smoothing
            mesh.tangential_smooth(settings.smooth_lambda);

            // Compact periodically
            if (iter + 1) % 2 == 0 {
                mesh.compact();
            }

            let after = mesh.active_tri_count();
            eprintln!(
                "    Iter {}: {} splits, {} collapses, {} flips, {} -> {} tris",
                iter + 1, splits, collapses, flips, before, after
            );
        }
    } else {
        let high = target * 4.0 / 3.0;
        let low = target * 4.0 / 5.0;

        eprintln!(
            "    Remeshing: target_edge={:.4}, high={:.4}, low={:.4}, {} iterations",
            target, high, low, settings.iterations
        );

        for iter in 0..settings.iterations {
            let before = mesh.active_tri_count();

            // 1. Split long edges
            let splits = split_long_edges(&mut mesh, high);

            // 2. Collapse short edges
            let collapses = collapse_short_edges(&mut mesh, low);

            // 3. Flip edges to improve valence
            let flips = flip_edges_for_valence(&mut mesh);

            // 4. Tangential smoothing
            mesh.tangential_smooth(settings.smooth_lambda);

            let after = mesh.active_tri_count();
            eprintln!(
                "    Iter {}: {} splits, {} collapses, {} flips, {} -> {} tris",
                iter + 1, splits, collapses, flips, before, after
            );
        }
    }

    mesh.into_buffers()
}

fn compute_average_edge_length(mesh: &RemeshMesh) -> f64 {
    let mut total = 0.0;
    let mut count = 0usize;
    let mut seen = HashSet::default();

    for (ti, tri) in mesh.triangles.iter().enumerate() {
        if mesh.deleted[ti] {
            continue;
        }
        for k in 0..3 {
            let e = RemeshMesh::edge_key(tri[k], tri[(k + 1) % 3]);
            if seen.insert(e) {
                total += mesh.edge_length(e.0, e.1);
                count += 1;
            }
        }
    }

    if count > 0 { total / count as f64 } else { 1.0 }
}

fn split_long_edges_adaptive(
    mesh: &mut RemeshMesh,
    base_target: f64,
    curvature: &[f64],
    min_factor: f64,
    max_factor: f64,
) -> usize {
    let mut count = 0;
    // Same dirty-tracked outer-loop pattern as split_long_edges. Splits
    // invalidate edge_map for neighbouring edges; without per-pass dirty
    // tracking, two splits sharing a triangle each see only one of the
    // edge's adjacent triangles and we leak boundary edges (holes).
    loop {
        let edge_map = mesh.build_edge_map();
        let mut to_split: Vec<(u32, u32, f64)> = Vec::new();

        for (&(a, b), tris) in &edge_map {
            if tris.iter().any(|&ti| !mesh.deleted[ti]) {
                let local_target = adaptive_edge_target(
                    mesh, a, b, curvature, base_target, min_factor, max_factor,
                );
                let high = local_target * 4.0 / 3.0;
                let len = mesh.edge_length(a, b);
                if len > high {
                    to_split.push((a, b, len));
                }
            }
        }

        if to_split.is_empty() {
            break;
        }

        to_split.sort_by(|a, b| b.2.total_cmp(&a.2));

        let mut dirty: HashSet<u32> = HashSet::default();
        let mut split_this_pass = 0;
        for (a, b, _len) in to_split {
            if dirty.contains(&a) || dirty.contains(&b) {
                continue;
            }
            let key = RemeshMesh::edge_key(a, b);
            let Some(tris) = edge_map.get(&key) else {
                continue;
            };
            if !tris.iter().any(|&ti| !mesh.deleted[ti]) {
                continue;
            }
            let local_target = adaptive_edge_target(
                mesh, a, b, curvature, base_target, min_factor, max_factor,
            );
            let high = local_target * 4.0 / 3.0;
            if mesh.edge_length(a, b) <= high {
                continue;
            }

            let mut apexes: Vec<u32> = Vec::with_capacity(2);
            for &ti in tris {
                if mesh.deleted[ti] {
                    continue;
                }
                for &v in &mesh.triangles[ti] {
                    if v != a && v != b {
                        apexes.push(v);
                    }
                }
            }

            mesh.split_edge(a, b, &edge_map);
            count += 1;
            split_this_pass += 1;
            dirty.insert(a);
            dirty.insert(b);
            for v in apexes {
                dirty.insert(v);
            }
        }

        if split_this_pass == 0 {
            break;
        }
    }
    count
}

fn collapse_short_edges_adaptive(
    mesh: &mut RemeshMesh,
    base_target: f64,
    curvature: &[f64],
    min_factor: f64,
    max_factor: f64,
) -> usize {
    let mut count = 0;
    let edge_map = mesh.build_edge_map();
    let vtris = mesh.build_vertex_tris();

    let mut to_collapse: Vec<(u32, u32, f64)> = Vec::new();
    for (&(a, b), tris) in &edge_map {
        if tris.iter().any(|&ti| !mesh.deleted[ti]) {
            let local_target = adaptive_edge_target(mesh, a, b, curvature, base_target, min_factor, max_factor);
            let low = local_target * 4.0 / 5.0;
            let len = mesh.edge_length(a, b);
            if len < low {
                to_collapse.push((a, b, len));
            }
        }
    }

    // Sort by length ascending
    to_collapse.sort_by(|a, b| a.2.total_cmp(&b.2));

    // Track vertices modified by collapses -- skip edges touching dirty vertices
    let mut dirty = HashSet::default();
    for (a, b, _) in to_collapse {
        if dirty.contains(&a) || dirty.contains(&b) {
            continue;
        }
        if mesh.collapse_edge(a, b, &edge_map, &vtris) {
            dirty.insert(a);
            dirty.insert(b);
            if let Some(tris) = vtris.get(&a) {
                for &ti in tris {
                    if !mesh.deleted[ti] {
                        for &v in &mesh.triangles[ti] {
                            dirty.insert(v);
                        }
                    }
                }
            }
            if let Some(tris) = vtris.get(&b) {
                for &ti in tris {
                    if !mesh.deleted[ti] {
                        for &v in &mesh.triangles[ti] {
                            dirty.insert(v);
                        }
                    }
                }
            }
            count += 1;
        }
    }
    count
}

fn split_long_edges(mesh: &mut RemeshMesh, high: f64) -> usize {
    let mut count = 0;
    // Outer loop: rebuild edge_map and re-collect long edges. Splitting an
    // edge invalidates edge_map for all neighbouring edges (the newly-created
    // triangles aren't in the snapshot), so we must use dirty tracking
    // within a pass and re-loop for the next batch.
    loop {
        let edge_map = mesh.build_edge_map();
        let mut to_split: Vec<(u32, u32, f64)> = Vec::new();

        for (&(a, b), tris) in &edge_map {
            if tris.iter().any(|&ti| !mesh.deleted[ti]) {
                let len = mesh.edge_length(a, b);
                if len > high {
                    to_split.push((a, b, len));
                }
            }
        }

        if to_split.is_empty() {
            break;
        }

        // Sort by length descending (split longest first)
        to_split.sort_by(|&(_, _, l1), &(_, _, l2)| l2.total_cmp(&l1));

        // Dirty tracking: when we split edge (a, b) sharing triangle T with
        // apex c, T is replaced by two new triangles touching a, b, c, and
        // a freshly minted vertex. Any subsequent split in this pass that
        // touches a, b, or c would read stale edge_map entries (the new
        // triangles aren't in there), miss one side of an edge, and produce
        // a boundary edge. Marking the four affected vertices dirty prevents
        // that; we pick up missed edges in the next outer-loop iteration.
        let mut dirty: HashSet<u32> = HashSet::default();
        let mut split_this_pass = 0;
        for (a, b, _len) in to_split {
            if dirty.contains(&a) || dirty.contains(&b) {
                continue;
            }
            let key = RemeshMesh::edge_key(a, b);
            let Some(tris) = edge_map.get(&key) else {
                continue;
            };
            if !tris.iter().any(|&ti| !mesh.deleted[ti]) {
                continue;
            }
            if mesh.edge_length(a, b) <= high {
                continue;
            }

            // Collect apex vertices BEFORE splitting (split deletes the
            // adjacent triangles). For a manifold edge, two apex vertices.
            let mut apexes: Vec<u32> = Vec::with_capacity(2);
            for &ti in tris {
                if mesh.deleted[ti] {
                    continue;
                }
                for &v in &mesh.triangles[ti] {
                    if v != a && v != b {
                        apexes.push(v);
                    }
                }
            }

            mesh.split_edge(a, b, &edge_map);
            count += 1;
            split_this_pass += 1;
            dirty.insert(a);
            dirty.insert(b);
            for v in apexes {
                dirty.insert(v);
            }
        }

        if split_this_pass == 0 {
            // Nothing more we can do without rebuilding maps; bail.
            break;
        }
        // Continue outer loop: rebuild edge_map, find any still-long edges
        // (including ones we skipped due to dirty), split them next pass.
        continue;
    }
    count
}

fn collapse_short_edges(mesh: &mut RemeshMesh, low: f64) -> usize {
    let mut count = 0;
    let edge_map = mesh.build_edge_map();
    let vtris = mesh.build_vertex_tris();

    let mut to_collapse: Vec<(u32, u32)> = Vec::new();
    for (&(a, b), tris) in &edge_map {
        if tris.iter().any(|&ti| !mesh.deleted[ti]) {
            if mesh.edge_length(a, b) < low {
                to_collapse.push((a, b));
            }
        }
    }

    // Sort by length ascending (collapse shortest first)
    to_collapse.sort_by(|&(a1, b1), &(a2, b2)| {
        mesh.edge_length(a1, b1)
            .total_cmp(&mesh.edge_length(a2, b2))
    });

    // Track vertices modified by collapses -- skip edges touching dirty vertices
    // to prevent cascading topology errors from stale adjacency data.
    let mut dirty = HashSet::default();
    for (a, b) in to_collapse {
        if dirty.contains(&a) || dirty.contains(&b) {
            continue;
        }
        if mesh.collapse_edge(a, b, &edge_map, &vtris) {
            // Mark both vertices and their neighbors as dirty
            dirty.insert(a);
            dirty.insert(b);
            if let Some(tris) = vtris.get(&a) {
                for &ti in tris {
                    if !mesh.deleted[ti] {
                        for &v in &mesh.triangles[ti] {
                            dirty.insert(v);
                        }
                    }
                }
            }
            if let Some(tris) = vtris.get(&b) {
                for &ti in tris {
                    if !mesh.deleted[ti] {
                        for &v in &mesh.triangles[ti] {
                            dirty.insert(v);
                        }
                    }
                }
            }
            count += 1;
        }
    }
    count
}

fn flip_edges_for_valence(mesh: &mut RemeshMesh) -> usize {
    let edge_map = mesh.build_edge_map();
    let vtris = mesh.build_vertex_tris();
    let mut count = 0;

    let edges: Vec<(u32, u32)> = edge_map.keys().copied().collect();
    for (a, b) in edges {
        if mesh.flip_edge(a, b, &edge_map, &vtris) {
            count += 1;
        }
    }
    count
}

#[cfg(test)]
mod tests {
    use super::*;

    fn box_mesh() -> (Vec<[f64; 3]>, Vec<[u32; 3]>) {
        let positions = vec![
            [0.0, 0.0, 0.0],
            [1.0, 0.0, 0.0],
            [1.0, 1.0, 0.0],
            [0.0, 1.0, 0.0],
            [0.0, 0.0, 1.0],
            [1.0, 0.0, 1.0],
            [1.0, 1.0, 1.0],
            [0.0, 1.0, 1.0],
        ];
        let indices = vec![
            [0, 2, 1], [0, 3, 2],
            [4, 5, 6], [4, 6, 7],
            [0, 1, 5], [0, 5, 4],
            [3, 6, 2], [3, 7, 6],
            [0, 4, 7], [0, 7, 3],
            [1, 2, 6], [1, 6, 5],
        ];
        (positions, indices)
    }

    #[test]
    fn remesh_produces_output() {
        let (pos, idx) = box_mesh();
        let settings = RemeshSettings {
            iterations: 3,
            ..Default::default()
        };
        let (new_pos, new_idx) = isotropic_remesh(&pos, &idx, &settings);
        assert!(!new_pos.is_empty());
        assert!(!new_idx.is_empty());
        // All indices valid
        for tri in &new_idx {
            for &vi in tri {
                assert!((vi as usize) < new_pos.len());
            }
        }
    }

    #[test]
    fn remesh_with_target_length() {
        let (pos, idx) = box_mesh();
        let settings = RemeshSettings {
            target_edge_length: Some(0.3),
            iterations: 3,
            smooth_lambda: 0.3,
            ..Default::default()
        };
        let (new_pos, new_idx) = isotropic_remesh(&pos, &idx, &settings);
        // Should have more triangles than input (edges were split)
        assert!(new_idx.len() > idx.len());
        assert!(!new_pos.is_empty());
    }
}
