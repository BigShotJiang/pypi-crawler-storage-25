//! Discrete differential geometry utilities for triangle meshes.
//!
//! Provides per-vertex curvature estimation, tangent frames, and parallel
//! transport -- the foundation for cross-field computation and quad retopology.

use std::collections::HashMap;
use std::f64::consts::PI;

/// Per-face tangent frame: two orthonormal tangent vectors + normal.
#[derive(Clone, Debug)]
pub struct TangentFrame {
    pub u: [f64; 3],
    pub v: [f64; 3],
    pub n: [f64; 3],
}

/// Per-vertex curvature data.
#[derive(Clone, Debug)]
pub struct VertexCurvature {
    /// Maximum principal curvature.
    pub k1: f64,
    /// Minimum principal curvature.
    pub k2: f64,
    /// Direction of maximum principal curvature (in 3D).
    pub t1: [f64; 3],
    /// Direction of minimum principal curvature (in 3D).
    pub t2: [f64; 3],
}

/// Compute per-face tangent frames.
///
/// For each triangle, constructs an orthonormal basis where:
/// - `u` is along the first edge (normalized)
/// - `n` is the face normal
/// - `v` = n x u
pub fn compute_face_frames(
    positions: &[[f64; 3]],
    indices: &[[u32; 3]],
) -> Vec<TangentFrame> {
    indices
        .iter()
        .map(|tri| {
            let p0 = positions[tri[0] as usize];
            let p1 = positions[tri[1] as usize];
            let p2 = positions[tri[2] as usize];

            let e0 = sub(p1, p0);
            let e1 = sub(p2, p0);
            let n = normalize(cross(e0, e1));
            let u = normalize(e0);
            let v = cross(n, u);

            TangentFrame { u, v, n }
        })
        .collect()
}

/// Compute area-weighted per-vertex normals.
pub fn compute_vertex_normals(
    positions: &[[f64; 3]],
    indices: &[[u32; 3]],
) -> Vec<[f64; 3]> {
    let n = positions.len();
    let mut normals = vec![[0.0f64; 3]; n];

    for tri in indices {
        let p0 = positions[tri[0] as usize];
        let p1 = positions[tri[1] as usize];
        let p2 = positions[tri[2] as usize];

        let fn_ = cross(sub(p1, p0), sub(p2, p0));
        for &vi in tri {
            let nrm = &mut normals[vi as usize];
            nrm[0] += fn_[0];
            nrm[1] += fn_[1];
            nrm[2] += fn_[2];
        }
    }

    for nrm in &mut normals {
        let len = (nrm[0] * nrm[0] + nrm[1] * nrm[1] + nrm[2] * nrm[2]).sqrt();
        if len > 1e-12 {
            nrm[0] /= len;
            nrm[1] /= len;
            nrm[2] /= len;
        }
    }

    normals
}

/// Compute per-vertex principal curvatures and directions.
///
/// Uses the method of Rusinkiewicz (2004): estimates the curvature tensor
/// per vertex by accumulating edge-based curvature estimates across the
/// one-ring neighborhood, then finds principal curvatures via 2x2 eigendecomposition.
pub fn compute_principal_curvatures(
    positions: &[[f64; 3]],
    indices: &[[u32; 3]],
) -> Vec<VertexCurvature> {
    let n = positions.len();
    let vertex_normals = compute_vertex_normals(positions, indices);

    // Build per-vertex tangent frames from the vertex normal
    let vertex_frames: Vec<TangentFrame> = vertex_normals
        .iter()
        .map(|n| tangent_frame_from_normal(*n))
        .collect();

    // Accumulate curvature tensor per vertex in local (u,v) coordinates.
    // The tensor is symmetric 2x2: [[a, b], [b, c]]
    let mut tensor_a = vec![0.0f64; n];
    let mut tensor_b = vec![0.0f64; n];
    let mut tensor_c = vec![0.0f64; n];
    let mut weight_sum = vec![0.0f64; n];

    for tri in indices {
        let i0 = tri[0] as usize;
        let i1 = tri[1] as usize;
        let i2 = tri[2] as usize;

        let p0 = positions[i0];
        let p1 = positions[i1];
        let p2 = positions[i2];

        // Face normal for weighting
        let fn_ = cross(sub(p1, p0), sub(p2, p0));
        let face_area = 0.5 * length(fn_);
        if face_area < 1e-12 {
            continue;
        }

        // Process each edge of the triangle
        let edges = [(i0, i1, i2), (i1, i2, i0), (i2, i0, i1)];
        for &(vi, vj, _vk) in &edges {
            let edge = sub(positions[vj], positions[vi]);
            let edge_len = length(edge);
            if edge_len < 1e-12 {
                continue;
            }

            // Normal difference along edge
            let dn = sub(vertex_normals[vj], vertex_normals[vi]);

            // Project edge and dn into vertex vi's tangent frame
            let frame = &vertex_frames[vi];
            let eu = dot(edge, frame.u);
            let ev = dot(edge, frame.v);
            let dnu = dot(dn, frame.u);
            let dnv = dot(dn, frame.v);

            // Weight by edge length
            let w = edge_len;

            // Accumulate: shape operator S such that dn = -S * de
            // In tangent frame: [dnu, dnv] = -[[a,b],[b,c]] * [eu, ev]
            // We solve for a, b, c via least squares accumulation
            tensor_a[vi] += w * eu * dnu;
            tensor_b[vi] += w * 0.5 * (eu * dnv + ev * dnu);
            tensor_c[vi] += w * ev * dnv;
            weight_sum[vi] += w * (eu * eu + ev * ev);
        }
    }

    // Extract principal curvatures from each vertex's tensor
    (0..n)
        .map(|vi| {
            if weight_sum[vi] < 1e-12 {
                return VertexCurvature {
                    k1: 0.0,
                    k2: 0.0,
                    t1: vertex_frames[vi].u,
                    t2: vertex_frames[vi].v,
                };
            }

            // Normalize tensor
            let inv_w = 1.0 / weight_sum[vi];
            let a = -tensor_a[vi] * inv_w;
            let b = -tensor_b[vi] * inv_w;
            let c = -tensor_c[vi] * inv_w;

            // 2x2 eigendecomposition of [[a, b], [b, c]]
            let (k1, k2, theta) = eigen_2x2_symmetric(a, b, c);

            let frame = &vertex_frames[vi];
            let cos_t = theta.cos();
            let sin_t = theta.sin();

            // t1 = cos(theta)*u + sin(theta)*v
            let t1 = [
                cos_t * frame.u[0] + sin_t * frame.v[0],
                cos_t * frame.u[1] + sin_t * frame.v[1],
                cos_t * frame.u[2] + sin_t * frame.v[2],
            ];
            // t2 = -sin(theta)*u + cos(theta)*v
            let t2 = [
                -sin_t * frame.u[0] + cos_t * frame.v[0],
                -sin_t * frame.u[1] + cos_t * frame.v[1],
                -sin_t * frame.u[2] + cos_t * frame.v[2],
            ];

            VertexCurvature { k1, k2, t1, t2 }
        })
        .collect()
}

/// Compute per-edge dihedral angles.
///
/// Returns a map from (min_vertex, max_vertex) -> angle in radians.
/// Sharp edges have angles far from PI (flat).
pub fn compute_dihedral_angles(
    positions: &[[f64; 3]],
    indices: &[[u32; 3]],
) -> HashMap<(u32, u32), f64> {
    // Build edge -> face adjacency
    let mut edge_faces: HashMap<(u32, u32), Vec<usize>> = HashMap::new();
    for (fi, tri) in indices.iter().enumerate() {
        for k in 0..3 {
            let a = tri[k];
            let b = tri[(k + 1) % 3];
            let key = if a < b { (a, b) } else { (b, a) };
            edge_faces.entry(key).or_default().push(fi);
        }
    }

    let mut angles = HashMap::new();

    for (&edge, faces) in &edge_faces {
        if faces.len() != 2 {
            continue; // boundary or non-manifold
        }

        let n0 = face_normal(positions, &indices[faces[0]]);
        let n1 = face_normal(positions, &indices[faces[1]]);

        let cos_angle = dot(n0, n1).clamp(-1.0, 1.0);
        angles.insert(edge, cos_angle.acos());
    }

    angles
}

/// Detect feature edges (sharp creases) based on dihedral angle threshold.
///
/// Returns set of edge keys where the angle between face normals exceeds
/// the threshold. An angle of 0 means flat (coplanar), PI/2 means 90-degree
/// edge, PI means a knife-edge fold.
pub fn detect_feature_edges(
    positions: &[[f64; 3]],
    indices: &[[u32; 3]],
    angle_threshold_degrees: f64,
) -> Vec<(u32, u32)> {
    let threshold = angle_threshold_degrees * PI / 180.0;
    let angles = compute_dihedral_angles(positions, indices);

    angles
        .into_iter()
        .filter(|&(_, angle)| angle > threshold)
        .map(|(edge, _)| edge)
        .collect()
}

/// Parallel transport a tangent vector from face `fi` to face `fj` across their shared edge.
///
/// The vector is rotated in the tangent plane to account for the change in
/// coordinate frame between the two faces.
pub fn parallel_transport(
    vec_in: [f64; 3],
    frame_from: &TangentFrame,
    frame_to: &TangentFrame,
    edge_dir: [f64; 3],
) -> [f64; 3] {
    let edge = normalize(edge_dir);

    // Project input vector into source frame's tangent plane
    let v_u = dot(vec_in, frame_from.u);
    let v_v = dot(vec_in, frame_from.v);

    // Express the shared edge in both frames
    let e_from_u = dot(edge, frame_from.u);
    let e_from_v = dot(edge, frame_from.v);
    let e_to_u = dot(edge, frame_to.u);
    let e_to_v = dot(edge, frame_to.v);

    // Angle of edge in source frame
    let angle_from = e_from_v.atan2(e_from_u);
    // Angle of edge in target frame
    let angle_to = e_to_v.atan2(e_to_u);

    // Rotation needed: rotate by (angle_to - angle_from) in tangent plane
    let delta = angle_to - angle_from;
    let cos_d = delta.cos();
    let sin_d = delta.sin();

    // Rotate the 2D vector
    let r_u = cos_d * v_u - sin_d * v_v;
    let r_v = sin_d * v_u + cos_d * v_v;

    // Reconstruct in target frame
    [
        r_u * frame_to.u[0] + r_v * frame_to.v[0],
        r_u * frame_to.u[1] + r_v * frame_to.v[1],
        r_u * frame_to.u[2] + r_v * frame_to.v[2],
    ]
}

/// Compute the angle of a tangent vector in a face's local frame.
///
/// Returns the angle in radians, measured from the frame's u-axis.
pub fn vector_angle_in_frame(vec: [f64; 3], frame: &TangentFrame) -> f64 {
    let u = dot(vec, frame.u);
    let v = dot(vec, frame.v);
    v.atan2(u)
}

/// Build face adjacency: for each face, the neighboring face across each edge.
///
/// Returns `Vec<[Option<usize>; 3]>` where entry `[fi][k]` is the face
/// across edge (tri[k], tri[(k+1)%3]).
pub fn build_face_adjacency(indices: &[[u32; 3]]) -> Vec<[Option<usize>; 3]> {
    let mut edge_face: HashMap<(u32, u32), Vec<(usize, usize)>> = HashMap::new();
    for (fi, tri) in indices.iter().enumerate() {
        for k in 0..3 {
            let a = tri[k];
            let b = tri[(k + 1) % 3];
            let key = if a < b { (a, b) } else { (b, a) };
            edge_face.entry(key).or_default().push((fi, k));
        }
    }

    let mut adjacency = vec![[None; 3]; indices.len()];

    for (_, faces) in &edge_face {
        if faces.len() == 2 {
            let (f0, k0) = faces[0];
            let (f1, k1) = faces[1];
            adjacency[f0][k0] = Some(f1);
            adjacency[f1][k1] = Some(f0);
        }
    }

    adjacency
}

// ---- Internal helpers ----

fn face_normal(positions: &[[f64; 3]], tri: &[u32; 3]) -> [f64; 3] {
    let p0 = positions[tri[0] as usize];
    let p1 = positions[tri[1] as usize];
    let p2 = positions[tri[2] as usize];
    normalize(cross(sub(p1, p0), sub(p2, p0)))
}

fn tangent_frame_from_normal(n: [f64; 3]) -> TangentFrame {
    // Find a vector not parallel to n
    let up = if n[0].abs() < 0.9 {
        [1.0, 0.0, 0.0]
    } else {
        [0.0, 1.0, 0.0]
    };
    let u = normalize(cross(n, up));
    let v = cross(n, u);
    TangentFrame { u, v, n }
}

/// Eigendecomposition of 2x2 symmetric matrix [[a, b], [b, c]].
///
/// Returns (eigenvalue1, eigenvalue2, angle) where angle is the rotation
/// from the original basis to the eigenvector basis.
/// eigenvalue1 >= eigenvalue2.
fn eigen_2x2_symmetric(a: f64, b: f64, c: f64) -> (f64, f64, f64) {
    let trace = a + c;
    let det = a * c - b * b;
    let disc = (trace * trace * 0.25 - det).max(0.0).sqrt();

    let e1 = trace * 0.5 + disc;
    let e2 = trace * 0.5 - disc;

    let theta = if b.abs() < 1e-12 {
        if a >= c { 0.0 } else { PI * 0.5 }
    } else {
        0.5 * (2.0 * b).atan2(a - c)
    };

    if e1.abs() >= e2.abs() {
        (e1, e2, theta)
    } else {
        (e2, e1, theta + PI * 0.5)
    }
}

fn sub(a: [f64; 3], b: [f64; 3]) -> [f64; 3] {
    [a[0] - b[0], a[1] - b[1], a[2] - b[2]]
}

fn cross(a: [f64; 3], b: [f64; 3]) -> [f64; 3] {
    [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]
}

fn dot(a: [f64; 3], b: [f64; 3]) -> f64 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}

fn length(a: [f64; 3]) -> f64 {
    (a[0] * a[0] + a[1] * a[1] + a[2] * a[2]).sqrt()
}

fn normalize(a: [f64; 3]) -> [f64; 3] {
    let len = length(a);
    if len < 1e-12 {
        [0.0, 0.0, 0.0]
    } else {
        [a[0] / len, a[1] / len, a[2] / len]
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn cube_mesh() -> (Vec<[f64; 3]>, Vec<[u32; 3]>) {
        let positions = vec![
            [0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [1.0, 1.0, 0.0], [0.0, 1.0, 0.0],
            [0.0, 0.0, 1.0], [1.0, 0.0, 1.0], [1.0, 1.0, 1.0], [0.0, 1.0, 1.0],
        ];
        let indices = vec![
            [0, 2, 1], [0, 3, 2], // -Z
            [4, 5, 6], [4, 6, 7], // +Z
            [0, 1, 5], [0, 5, 4], // -Y
            [3, 6, 2], [3, 7, 6], // +Y
            [0, 4, 7], [0, 7, 3], // -X
            [1, 2, 6], [1, 6, 5], // +X
        ];
        (positions, indices)
    }

    fn sphere_mesh() -> (Vec<[f64; 3]>, Vec<[u32; 3]>) {
        // Simple icosphere-like mesh (UV sphere with 6 lat x 12 lon)
        let mut positions = Vec::new();
        let mut indices = Vec::new();

        let n_lat = 8;
        let n_lon = 16;

        // Top pole
        positions.push([0.0, 1.0, 0.0]);

        // Middle rings
        for i in 1..n_lat {
            let phi = PI * i as f64 / n_lat as f64;
            let y = phi.cos();
            let r = phi.sin();
            for j in 0..n_lon {
                let theta = 2.0 * PI * j as f64 / n_lon as f64;
                positions.push([r * theta.cos(), y, r * theta.sin()]);
            }
        }

        // Bottom pole
        let bottom = positions.len() as u32;
        positions.push([0.0, -1.0, 0.0]);

        // Top cap triangles
        for j in 0..n_lon {
            let j_next = (j + 1) % n_lon;
            indices.push([0, (1 + j) as u32, (1 + j_next) as u32]);
        }

        // Middle quads (as 2 triangles)
        for i in 0..(n_lat - 2) {
            for j in 0..n_lon {
                let j_next = (j + 1) % n_lon;
                let a = (1 + i * n_lon + j) as u32;
                let b = (1 + i * n_lon + j_next) as u32;
                let c = (1 + (i + 1) * n_lon + j_next) as u32;
                let d = (1 + (i + 1) * n_lon + j) as u32;
                indices.push([a, b, c]);
                indices.push([a, c, d]);
            }
        }

        // Bottom cap
        let last_ring_start = 1 + (n_lat - 2) * n_lon;
        for j in 0..n_lon {
            let j_next = (j + 1) % n_lon;
            indices.push([
                (last_ring_start + j) as u32,
                (last_ring_start + j_next) as u32,
                bottom,
            ]);
        }

        (positions, indices)
    }

    #[test]
    fn face_frames_orthonormal() {
        let (pos, idx) = cube_mesh();
        let frames = compute_face_frames(&pos, &idx);
        assert_eq!(frames.len(), idx.len());

        for frame in &frames {
            // u, v, n should be orthonormal
            let uu = dot(frame.u, frame.u);
            let vv = dot(frame.v, frame.v);
            let nn = dot(frame.n, frame.n);
            assert!((uu - 1.0).abs() < 1e-10);
            assert!((vv - 1.0).abs() < 1e-10);
            assert!((nn - 1.0).abs() < 1e-10);

            let uv = dot(frame.u, frame.v);
            let un = dot(frame.u, frame.n);
            let vn = dot(frame.v, frame.n);
            assert!(uv.abs() < 1e-10);
            assert!(un.abs() < 1e-10);
            assert!(vn.abs() < 1e-10);
        }
    }

    #[test]
    fn vertex_normals_unit_length() {
        let (pos, idx) = cube_mesh();
        let normals = compute_vertex_normals(&pos, &idx);
        assert_eq!(normals.len(), pos.len());

        for n in &normals {
            let len = length(*n);
            assert!((len - 1.0).abs() < 1e-10, "normal length: {}", len);
        }
    }

    #[test]
    fn cube_dihedral_angles() {
        let (pos, idx) = cube_mesh();
        let angles = compute_dihedral_angles(&pos, &idx);

        // Cube triangulated mesh has two types of edges:
        // - 6 diagonal edges within cube faces: angle between normals = 0 (coplanar)
        // - 12 cube edges: angle between normals = PI/2 (90 degrees)
        let mut coplanar = 0;
        let mut right_angle = 0;
        for (_, angle) in &angles {
            if *angle < 0.1 {
                coplanar += 1;
            } else if (angle - PI / 2.0).abs() < 0.1 {
                right_angle += 1;
            }
        }
        assert_eq!(coplanar, 6, "expected 6 coplanar (diagonal) edges");
        assert_eq!(right_angle, 12, "expected 12 right-angle (cube) edges");
    }

    #[test]
    fn cube_feature_edges_detected() {
        let (pos, idx) = cube_mesh();
        // Threshold 30 degrees: only the 12 cube edges (90 degrees) are features,
        // not the 6 coplanar diagonals (0 degrees)
        let features = detect_feature_edges(&pos, &idx, 30.0);
        assert_eq!(features.len(), 12, "cube should have 12 feature edges");
    }

    #[test]
    fn principal_curvatures_on_sphere() {
        let (pos, idx) = sphere_mesh();
        let curvatures = compute_principal_curvatures(&pos, &idx);
        assert_eq!(curvatures.len(), pos.len());

        // On a unit sphere, both principal curvatures should be ~1.0
        // (Skip poles which have degenerate neighborhoods)
        for (i, curv) in curvatures.iter().enumerate() {
            if i == 0 || i == pos.len() - 1 {
                continue; // skip poles
            }
            // Be lenient -- discrete curvature estimation on coarse meshes isn't exact
            assert!(
                curv.k1.abs() > 0.3 && curv.k1.abs() < 3.0,
                "vertex {}: k1={} (expected ~1.0)",
                i,
                curv.k1
            );
        }
    }

    #[test]
    fn face_adjacency_correct() {
        let (_, idx) = cube_mesh();
        let adj = build_face_adjacency(&idx);
        assert_eq!(adj.len(), idx.len());

        // Every face should have 3 neighbors (cube is closed manifold)
        for (fi, neighbors) in adj.iter().enumerate() {
            for k in 0..3 {
                assert!(
                    neighbors[k].is_some(),
                    "face {} edge {} has no neighbor",
                    fi,
                    k
                );
            }
        }
    }

    #[test]
    fn parallel_transport_preserves_length() {
        let (pos, idx) = cube_mesh();
        let frames = compute_face_frames(&pos, &idx);

        // Transport a vector from face 0 to face 1 (share an edge)
        let vec_in = frames[0].u; // unit vector
        let edge_dir = sub(pos[idx[0][1] as usize], pos[idx[0][0] as usize]);
        let vec_out = parallel_transport(vec_in, &frames[0], &frames[1], edge_dir);

        let len_in = length(vec_in);
        let len_out = length(vec_out);
        assert!(
            (len_in - len_out).abs() < 1e-10,
            "transport changed length: {} -> {}",
            len_in,
            len_out
        );
    }

    #[test]
    fn eigen_2x2_identity() {
        let (e1, e2, theta) = eigen_2x2_symmetric(1.0, 0.0, 1.0);
        assert!((e1 - 1.0).abs() < 1e-10);
        assert!((e2 - 1.0).abs() < 1e-10);
    }

    #[test]
    fn eigen_2x2_diagonal() {
        let (e1, e2, theta) = eigen_2x2_symmetric(3.0, 0.0, 1.0);
        assert!((e1 - 3.0).abs() < 1e-10);
        assert!((e2 - 1.0).abs() < 1e-10);
        assert!(theta.abs() < 1e-10); // eigenvectors aligned with axes
    }
}
