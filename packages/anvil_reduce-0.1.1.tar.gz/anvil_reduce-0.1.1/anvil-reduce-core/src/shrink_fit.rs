//! Shrink-fit pass: pull proxy vertices toward the input surface.
//!
//! Counters the outward bias inherent to voxelization. Binary marching cubes
//! marks any cell touched by a triangle as solid, inflating the surface by up
//! to ~½ a voxel; explicit dilation adds another N voxels on top. This pass
//! reverses that bias by snapping each proxy vertex toward the nearest input
//! vertex, with the displacement clamped to `max_displacement` so we don't
//! tunnel through thin features or get pulled across the mesh.
//!
//! Reuses the `UniformGrid` index from `attribute_transfer`, so the cost is
//! roughly one extra nearest-vertex lookup per proxy vertex — small relative
//! to voxelization and MC.
//!
//! Limitations:
//! - Nearest-input-*vertex* (not nearest-point-on-triangle); on sparse
//!   inputs the snap target can be slightly off the true surface. Adequate
//!   while the input is denser than the proxy at the surface, which is the
//!   normal case for the proxy pipeline.
//! - The `max_displacement` cap is the only safeguard against lateral drift
//!   on thin features. Keep it ≲ ~2 voxel cells.

use rayon::prelude::*;

use crate::attribute_transfer::UniformGrid;
use crate::types::Vec3;

/// Snap proxy vertices toward the nearest input vertex.
///
/// `max_displacement` is in world units; suggested ≈ 1-2 voxel cells.
/// Setting it ≤ 0 is a no-op.
///
/// The displacement is along `(nearest_input - proxy_vertex)`, capped at
/// `max_displacement`. This is intentionally agnostic to triangle winding
/// (which differs between marching-cubes outputs and downstream pipelines)
/// and works whether the proxy is inflated or slightly deflated relative
/// to the input.
pub fn shrink_fit(
    proxy_positions: &mut [[f64; 3]],
    input_positions: &[[f64; 3]],
    max_displacement: f64,
) {
    if !(max_displacement > 0.0)
        || proxy_positions.is_empty()
        || input_positions.is_empty()
    {
        return;
    }

    let grid = UniformGrid::build(input_positions);
    let max_sq = max_displacement * max_displacement;

    // Two passes (compute, apply) so a vertex's snap target isn't affected
    // by another vertex's earlier in-place mutation.
    let displacements: Vec<Vec3> = proxy_positions
        .par_iter()
        .map(|p| {
            let pos = Vec3::new(p[0], p[1], p[2]);
            let Some(idx) = grid.query_nearest(pos) else {
                return Vec3::zeros();
            };
            let np = input_positions[idx as usize];
            let target = Vec3::new(np[0], np[1], np[2]);
            let diff = target - pos;
            let dsq = diff.norm_squared();
            if dsq <= max_sq {
                diff
            } else {
                diff * (max_displacement / dsq.sqrt())
            }
        })
        .collect();

    proxy_positions
        .par_iter_mut()
        .zip(displacements.par_iter())
        .for_each(|(p, d)| {
            p[0] += d.x;
            p[1] += d.y;
            p[2] += d.z;
        });
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Inflated cube proxy snaps back onto the input cube within max_displacement.
    #[test]
    fn shrink_fit_pulls_inflated_proxy_toward_input() {
        // Input: 8-vertex unit cube corners (just the corners, sufficient for
        // nearest-vertex snapping in this synthetic test).
        let input_positions: Vec<[f64; 3]> = vec![
            [0.0, 0.0, 0.0],
            [1.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
            [1.0, 1.0, 0.0],
            [0.0, 0.0, 1.0],
            [1.0, 0.0, 1.0],
            [0.0, 1.0, 1.0],
            [1.0, 1.0, 1.0],
        ];

        // Proxy: a slightly larger cube — same vertex layout, scaled out by
        // 0.1 from the cube center (0.5, 0.5, 0.5).
        let inflate = 0.1;
        let center = [0.5, 0.5, 0.5];
        let mut proxy_positions: Vec<[f64; 3]> = input_positions
            .iter()
            .map(|p| {
                [
                    center[0] + (p[0] - center[0]) * (1.0 + inflate),
                    center[1] + (p[1] - center[1]) * (1.0 + inflate),
                    center[2] + (p[2] - center[2]) * (1.0 + inflate),
                ]
            })
            .collect();

        let before: Vec<f64> = proxy_positions
            .iter()
            .zip(input_positions.iter())
            .map(|(a, b)| {
                ((a[0] - b[0]).powi(2) + (a[1] - b[1]).powi(2) + (a[2] - b[2]).powi(2)).sqrt()
            })
            .collect();

        shrink_fit(&mut proxy_positions, &input_positions, 0.5);

        let after: Vec<f64> = proxy_positions
            .iter()
            .zip(input_positions.iter())
            .map(|(a, b)| {
                ((a[0] - b[0]).powi(2) + (a[1] - b[1]).powi(2) + (a[2] - b[2]).powi(2)).sqrt()
            })
            .collect();

        // With max_disp > sqrt(3)*0.05 ≈ 0.0866, every inflated corner
        // snaps directly onto its matching input corner.
        for (b, a) in before.iter().zip(after.iter()) {
            assert!(*b > 1e-6, "test setup: vertex was already on input");
            assert!(
                *a < 1e-9,
                "vertex did not snap onto input corner: before={b}, after={a}",
            );
        }
    }

    /// max_displacement clamps how far any one vertex moves.
    #[test]
    fn shrink_fit_respects_clamp() {
        let input_positions: Vec<[f64; 3]> = vec![[0.0, 0.0, 0.0]];
        // Three "proxy" vertices floating well away from the input.
        let mut proxy_positions: Vec<[f64; 3]> =
            vec![[10.0, 0.0, 0.0], [10.0, 1.0, 0.0], [10.0, 0.0, 1.0]];

        let max_disp = 0.5;
        let snapshot = proxy_positions.clone();
        shrink_fit(&mut proxy_positions, &input_positions, max_disp);

        for (a, b) in proxy_positions.iter().zip(snapshot.iter()) {
            let d = ((a[0] - b[0]).powi(2) + (a[1] - b[1]).powi(2) + (a[2] - b[2]).powi(2)).sqrt();
            assert!(
                d <= max_disp + 1e-9,
                "vertex moved {d}, exceeds clamp {max_disp}",
            );
        }
    }

    #[test]
    fn shrink_fit_zero_max_is_noop() {
        let input_positions: Vec<[f64; 3]> = vec![[0.0, 0.0, 0.0]];
        let mut proxy_positions: Vec<[f64; 3]> =
            vec![[10.0, 0.0, 0.0], [10.0, 1.0, 0.0], [10.0, 0.0, 1.0]];
        let snapshot = proxy_positions.clone();

        shrink_fit(&mut proxy_positions, &input_positions, 0.0);

        assert_eq!(proxy_positions, snapshot);
    }
}
