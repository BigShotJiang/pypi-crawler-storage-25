//! Surface voxelization, flood fill, and morphological operations.

use std::collections::VecDeque;
use std::sync::atomic::{AtomicU8, Ordering};

use rayon::prelude::*;

use crate::half_edge::HalfEdgeMesh;
use crate::progress::Reporter;
use crate::types::*;

/// Cell states in the voxel grid.
const EMPTY: u8 = 0;
const SURFACE: u8 = 1;
const INTERIOR: u8 = 2;
const EXTERIOR: u8 = 3;

/// Hard cap on total grid cells. At 1 byte per cell this is ~1 GiB.
/// Prevents pathological inputs (huge bounding box + high resolution) from
/// allocating gigabytes or overflowing usize on `rx * ry * rz`.
const MAX_VOXEL_CELLS: usize = 1 << 30;

/// 6-connected neighbour offsets for flood fill and dilation.
const NEIGHBOURS_6: [(i32, i32, i32); 6] = [
    (-1, 0, 0),
    (1, 0, 0),
    (0, -1, 0),
    (0, 1, 0),
    (0, 0, -1),
    (0, 0, 1),
];

pub struct VoxelGrid {
    data: Vec<u8>,
    pub res: [usize; 3],
    pub origin: Vec3,
    pub cell_size: f64,
}

impl VoxelGrid {
    /// Build a voxel grid from a triangle mesh.
    ///
    /// 1. Compute bounding box with 2-cell padding.
    /// 2. Rasterize all mesh triangles onto the grid surface.
    /// 3. Flood-fill the exterior starting from corner (0,0,0).
    /// 4. Mark remaining empty cells as interior.
    pub fn from_mesh(mesh: &HalfEdgeMesh, resolution: usize) -> Self {
        let bbox = mesh.bounding_box();
        let extent = bbox.max - bbox.min;

        let ([rx, ry, rz], cell_size) = compute_grid_dims(extent, resolution);
        let origin = bbox.min - Vec3::new(2.0 * cell_size, 2.0 * cell_size, 2.0 * cell_size);

        let mut grid = Self {
            data: vec![EMPTY; rx * ry * rz],
            res: [rx, ry, rz],
            origin,
            cell_size,
        };

        grid.rasterize_mesh(mesh);
        let r = Reporter::untimed("flood-fill exterior");
        grid.flood_fill_exterior();
        r.finish();
        grid.mark_interior();

        grid
    }

    /// Build a voxel grid from raw position/index buffers.
    ///
    /// Works on any triangle soup — no manifold requirement.
    pub fn from_raw_triangles(
        positions: &[[f64; 3]],
        indices: &[[u32; 3]],
        resolution: usize,
    ) -> Self {
        // Compute bounding box
        let mut bmin = Vec3::new(f64::MAX, f64::MAX, f64::MAX);
        let mut bmax = Vec3::new(f64::MIN, f64::MIN, f64::MIN);
        for p in positions {
            let v = Vec3::new(p[0], p[1], p[2]);
            bmin = bmin.inf(&v);
            bmax = bmax.sup(&v);
        }

        let extent = bmax - bmin;
        let ([rx, ry, rz], cell_size) = compute_grid_dims(extent, resolution);
        let origin = bmin - Vec3::new(2.0 * cell_size, 2.0 * cell_size, 2.0 * cell_size);

        let mut grid = Self {
            data: vec![EMPTY; rx * ry * rz],
            res: [rx, ry, rz],
            origin,
            cell_size,
        };

        let step = grid.cell_size * 0.4;
        let stride_y = grid.res[0];
        let stride_z = grid.res[0] * grid.res[1];
        let res = grid.res;
        let origin = grid.origin;
        let cell_size = grid.cell_size;
        let atomic = as_atomic_slice(&mut grid.data);

        // Per-stage Reporter only — par_iter doesn't have a natural sequential
        // tick point, and rasterization is fast enough that tick granularity
        // wouldn't add much.
        let reporter = Reporter::untimed("voxelize");
        indices.par_iter().for_each(|tri| {
            let p0 = Vec3::new(
                positions[tri[0] as usize][0],
                positions[tri[0] as usize][1],
                positions[tri[0] as usize][2],
            );
            let p1 = Vec3::new(
                positions[tri[1] as usize][0],
                positions[tri[1] as usize][1],
                positions[tri[1] as usize][2],
            );
            let p2 = Vec3::new(
                positions[tri[2] as usize][0],
                positions[tri[2] as usize][1],
                positions[tri[2] as usize][2],
            );

            rasterize_tri_atomic(p0, p1, p2, origin, cell_size, step, res, stride_y, stride_z, atomic);
        });
        reporter.finish();

        let r = Reporter::untimed("flood-fill exterior");
        grid.flood_fill_exterior();
        r.finish();
        grid.mark_interior();
        grid
    }

    // ---- Indexing helpers ----

    fn idx(&self, x: usize, y: usize, z: usize) -> usize {
        x + y * self.res[0] + z * self.res[0] * self.res[1]
    }

    pub fn get(&self, x: usize, y: usize, z: usize) -> u8 {
        self.data[self.idx(x, y, z)]
    }

    fn set(&mut self, x: usize, y: usize, z: usize, val: u8) {
        let i = self.idx(x, y, z);
        self.data[i] = val;
    }

    fn in_bounds(&self, x: i32, y: i32, z: i32) -> bool {
        x >= 0
            && y >= 0
            && z >= 0
            && (x as usize) < self.res[0]
            && (y as usize) < self.res[1]
            && (z as usize) < self.res[2]
    }

    // ---- Rasterization ----

    /// Rasterize every active triangle into the grid by dense barycentric sampling.
    ///
    /// Parallel over triangles. Cell writes are idempotent (every triangle
    /// stores `SURFACE`, never reads the prior value), so relaxed atomic stores
    /// are sufficient.
    fn rasterize_mesh(&mut self, mesh: &HalfEdgeMesh) {
        let res = self.res;
        let cell_size = self.cell_size;
        let origin = self.origin;
        let stride_y = res[0];
        let stride_z = res[0] * res[1];
        let step = cell_size * 0.4;

        let atomic = as_atomic_slice(&mut self.data);

        let reporter = Reporter::untimed("voxelize");
        (0..mesh.faces.len()).into_par_iter().for_each(|fi| {
            if mesh.faces[fi].deleted {
                return;
            }

            let [vi0, vi1, vi2] = mesh.face_vertex_indices(fi as Idx);
            let p0 = mesh.vertices[vi0 as usize].position;
            let p1 = mesh.vertices[vi1 as usize].position;
            let p2 = mesh.vertices[vi2 as usize].position;

            rasterize_tri_atomic(p0, p1, p2, origin, cell_size, step, res, stride_y, stride_z, atomic);
        });
        reporter.finish();
    }

    // ---- Flood fill ----

    /// BFS flood-fill from (0,0,0) through EMPTY cells, marking them EXTERIOR.
    fn flood_fill_exterior(&mut self) {
        let mut queue = VecDeque::new();

        if self.get(0, 0, 0) == EMPTY {
            self.set(0, 0, 0, EXTERIOR);
            queue.push_back((0i32, 0i32, 0i32));
        }

        while let Some((x, y, z)) = queue.pop_front() {
            for &(dx, dy, dz) in &NEIGHBOURS_6 {
                let nx = x + dx;
                let ny = y + dy;
                let nz = z + dz;

                if !self.in_bounds(nx, ny, nz) {
                    continue;
                }

                let ux = nx as usize;
                let uy = ny as usize;
                let uz = nz as usize;

                if self.get(ux, uy, uz) == EMPTY {
                    self.set(ux, uy, uz, EXTERIOR);
                    queue.push_back((nx, ny, nz));
                }
            }
        }
    }

    /// Any cell still marked EMPTY after flood fill must be interior.
    fn mark_interior(&mut self) {
        for cell in &mut self.data {
            if *cell == EMPTY {
                *cell = INTERIOR;
            }
        }
    }

    // ---- Morphological operations ----

    /// Dilate the solid region (SURFACE | INTERIOR) by the given number of
    /// iterations. Each iteration expands solid cells into all 6-connected
    /// non-solid neighbours.
    ///
    /// Pull-style implementation: each output cell reads its 6 neighbours from
    /// the previous buffer. Embarrassingly parallel via rayon. Equivalent to the
    /// push-style original (write to a non-solid neighbour from a solid cell)
    /// because both compute the same 6-connected dilation kernel.
    pub fn dilate(&mut self, iterations: usize) {
        let [rx, ry, rz] = self.res;
        let stride_y = rx;
        let stride_z = rx * ry;
        let mut next: Vec<u8> = vec![EMPTY; self.data.len()];

        for _ in 0..iterations {
            let prev = &self.data;
            next.par_iter_mut().enumerate().for_each(|(i, out)| {
                let cur = prev[i];
                // Solid cells stay solid (preserves SURFACE vs INTERIOR distinction).
                if cur == SURFACE || cur == INTERIOR {
                    *out = cur;
                    return;
                }

                let z = i / stride_z;
                let rem = i % stride_z;
                let y = rem / stride_y;
                let x = rem % stride_y;

                for &(dx, dy, dz) in &NEIGHBOURS_6 {
                    let nx = x as i32 + dx;
                    let ny = y as i32 + dy;
                    let nz = z as i32 + dz;
                    if nx < 0 || ny < 0 || nz < 0 {
                        continue;
                    }
                    let (ux, uy, uz) = (nx as usize, ny as usize, nz as usize);
                    if ux >= rx || uy >= ry || uz >= rz {
                        continue;
                    }
                    let ni = ux + uy * stride_y + uz * stride_z;
                    let nv = prev[ni];
                    if nv == SURFACE || nv == INTERIOR {
                        *out = INTERIOR;
                        return;
                    }
                }
                *out = cur;
            });
            std::mem::swap(&mut self.data, &mut next);
        }
    }

    // ---- Queries ----

    /// Returns `true` if the cell is part of the solid region (surface or interior).
    pub fn is_solid(&self, x: usize, y: usize, z: usize) -> bool {
        let v = self.get(x, y, z);
        v == SURFACE || v == INTERIOR
    }
}

/// Compute padded per-axis grid dimensions and cell size from a bounding-box extent.
///
/// Guarantees:
/// - `resolution` is clamped to `>= 1`.
/// - Degenerate or non-finite extents fall back to a tiny placeholder grid.
/// - `rx * ry * rz` never overflows `usize` and is capped at `MAX_VOXEL_CELLS`.
///   When the budget would be exceeded, the resolution is halved until it fits
///   and a warning is printed.
fn compute_grid_dims(extent: Vec3, resolution: usize) -> ([usize; 3], f64) {
    let resolution = resolution.max(1);

    let ex = extent.x.max(0.0);
    let ey = extent.y.max(0.0);
    let ez = extent.z.max(0.0);
    let longest = ex.max(ey).max(ez);

    if !longest.is_finite() || longest <= 0.0 {
        // Degenerate input (single point, NaN bbox, etc.). Return a 5x5x5 grid
        // so flood fill and indexing helpers remain valid.
        return ([5, 5, 5], 1.0);
    }

    let mut res = resolution;
    let mut cell_size = longest / res as f64;
    let mut dims = axis_dims(ex, ey, ez, cell_size);
    let original = dims;

    while dims.0.checked_mul(dims.1)
        .and_then(|n| n.checked_mul(dims.2))
        .map(|n| n > MAX_VOXEL_CELLS)
        .unwrap_or(true)
        && res > 1
    {
        res /= 2;
        cell_size = longest / res as f64;
        dims = axis_dims(ex, ey, ez, cell_size);
    }

    if dims != original {
        eprintln!(
            "  warning: voxel grid {}x{}x{} would exceed {} cell budget; \
             reduced resolution to {}x{}x{}",
            original.0, original.1, original.2,
            MAX_VOXEL_CELLS,
            dims.0, dims.1, dims.2,
        );
    }

    ([dims.0, dims.1, dims.2], cell_size)
}

/// View `&mut [u8]` as `&[AtomicU8]` for parallel idempotent stores.
///
/// SAFETY: `AtomicU8` is guaranteed to have the same in-memory representation
/// as `u8` (std docs). The exclusive `&mut [u8]` is downgraded to a shared
/// `&[AtomicU8]`, ruling out non-atomic access for the borrow's lifetime.
fn as_atomic_slice(s: &mut [u8]) -> &[AtomicU8] {
    let len = s.len();
    unsafe { std::slice::from_raw_parts(s.as_mut_ptr() as *const AtomicU8, len) }
}

/// Rasterize one triangle into the atomic grid via dense barycentric sampling.
/// Cell stores are idempotent (always SURFACE) so Relaxed ordering is sound.
#[allow(clippy::too_many_arguments)]
fn rasterize_tri_atomic(
    p0: Vec3,
    p1: Vec3,
    p2: Vec3,
    origin: Vec3,
    cell_size: f64,
    step: f64,
    res: [usize; 3],
    stride_y: usize,
    stride_z: usize,
    grid: &[AtomicU8],
) {
    let e1 = p1 - p0;
    let e2 = p2 - p0;
    let n1 = ((e1.norm() / step).ceil() as usize).max(1);
    let n2 = ((e2.norm() / step).ceil() as usize).max(1);

    for i in 0..=n1 {
        let u = i as f64 / n1 as f64;
        for j in 0..=n2 {
            let v = j as f64 / n2 as f64;
            if u + v > 1.0 {
                continue;
            }
            let pt = p0 + e1 * u + e2 * v;
            let gx = ((pt.x - origin.x) / cell_size) as i32;
            let gy = ((pt.y - origin.y) / cell_size) as i32;
            let gz = ((pt.z - origin.z) / cell_size) as i32;
            if gx < 0 || gy < 0 || gz < 0 {
                continue;
            }
            let (ux, uy, uz) = (gx as usize, gy as usize, gz as usize);
            if ux >= res[0] || uy >= res[1] || uz >= res[2] {
                continue;
            }
            let idx = ux + uy * stride_y + uz * stride_z;
            grid[idx].store(SURFACE, Ordering::Relaxed);
        }
    }
}

/// Per-axis grid resolution (>=1, +4 cells padding).
/// Saturates non-finite divisions to 1.
fn axis_dims(ex: f64, ey: f64, ez: f64, cell_size: f64) -> (usize, usize, usize) {
    let to_dim = |e: f64| -> usize {
        let cells = (e / cell_size).ceil();
        let n = if cells.is_finite() && cells >= 0.0 {
            // f64 -> usize with explicit clamp; saturation on overflow.
            (cells as usize).max(1)
        } else {
            1
        };
        n.saturating_add(4)
    };
    (to_dim(ex), to_dim(ey), to_dim(ez))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::half_edge::HalfEdgeMesh;

    /// Build a simple closed box mesh (12 triangles) for testing.
    fn box_mesh() -> HalfEdgeMesh {
        #[rustfmt::skip]
        let positions: Vec<[f64; 3]> = vec![
            [0.0, 0.0, 0.0], // 0
            [1.0, 0.0, 0.0], // 1
            [1.0, 1.0, 0.0], // 2
            [0.0, 1.0, 0.0], // 3
            [0.0, 0.0, 1.0], // 4
            [1.0, 0.0, 1.0], // 5
            [1.0, 1.0, 1.0], // 6
            [0.0, 1.0, 1.0], // 7
        ];
        #[rustfmt::skip]
        let indices: Vec<[u32; 3]> = vec![
            // -Z face
            [0, 2, 1], [0, 3, 2],
            // +Z face
            [4, 5, 6], [4, 6, 7],
            // -Y face
            [0, 1, 5], [0, 5, 4],
            // +Y face
            [3, 6, 2], [3, 7, 6],
            // -X face
            [0, 4, 7], [0, 7, 3],
            // +X face
            [1, 2, 6], [1, 6, 5],
        ];
        HalfEdgeMesh::from_indexed_triangles(&positions, &indices).unwrap()
    }

    #[test]
    fn voxel_grid_has_solid_interior() {
        let mesh = box_mesh();
        let grid = VoxelGrid::from_mesh(&mesh, 20);

        // The centre of the box should be solid.
        let cx = ((0.5 - grid.origin.x) / grid.cell_size) as usize;
        let cy = ((0.5 - grid.origin.y) / grid.cell_size) as usize;
        let cz = ((0.5 - grid.origin.z) / grid.cell_size) as usize;
        assert!(grid.is_solid(cx, cy, cz));
    }

    #[test]
    fn corner_is_exterior() {
        let mesh = box_mesh();
        let grid = VoxelGrid::from_mesh(&mesh, 20);

        // (0,0,0) is in the padded exterior.
        assert!(!grid.is_solid(0, 0, 0));
    }

    #[test]
    fn dilate_expands_solid() {
        let mesh = box_mesh();
        let mut grid = VoxelGrid::from_mesh(&mesh, 20);

        // Count solid cells before dilation.
        let before: usize = grid
            .data
            .iter()
            .filter(|&&v| v == SURFACE || v == INTERIOR)
            .count();

        grid.dilate(1);

        let after: usize = grid
            .data
            .iter()
            .filter(|&&v| v == SURFACE || v == INTERIOR)
            .count();

        assert!(after > before);
    }
}
