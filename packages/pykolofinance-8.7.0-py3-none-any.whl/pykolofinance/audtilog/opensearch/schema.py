# logging/tasks.py

import logging
import socket
from datetime import datetime

from django.conf import settings
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

_client = None
_index_checked = False


def get_opensearch_config():
    required_settings = {
        "host": getattr(settings, "PYKOLOFINANCE_OPENSEARCH_HOST", None),
        "port": getattr(settings, "PYKOLOFINANCE_OPENSEARCH_PORT", None),
        "username": getattr(settings, "PYKOLOFINANCE_OPENSEARCH_USERNAME", None),
        "password": getattr(settings, "PYKOLOFINANCE_OPENSEARCH_PASSWORD", None),
        "index_name": getattr(
            settings,
            "PYKOLOFINANCE_OPENSEARCH_INDEX_NAME",
            None,
        ),
    }

    missing = [
        key for key, value in required_settings.items()
        if not value
    ]

    if missing:
        logger.warning(
            "OpenSearch logging disabled. Missing settings: %s",
            ", ".join(missing),
        )
        return None

    return required_settings


def get_opensearch_index_name():
    return getattr(
        settings,
        "PYKOLOFINANCE_OPENSEARCH_INDEX_NAME",
        None,
    )


def get_opensearch_client():
    global _client

    if _client is not None:
        return _client

    config = get_opensearch_config()
    if not config:
        return None

    try:
        _client = OpenSearch(
            hosts=[
                {
                    "host": config["host"],
                    "port": config["port"],
                }
            ],
            http_auth=(
                config["username"],
                config["password"],
            ),
            use_ssl=True,
            verify_certs=False,
            ssl_show_warn=False,
            http_compress=True,
            timeout=3,
            max_retries=1,
            retry_on_timeout=False,
            pool_maxsize=20,
        )

        return _client

    except Exception:
        logger.exception(
            "OpenSearch logging disabled. Failed to initialize client."
        )
        _client = None
        return None


def get_index_mapping():
    return {
        "settings": {
            "number_of_shards": 1,
            "number_of_replicas": 0,
        },
        "mappings": {
            "dynamic": True,
            "properties": {
                "@timestamp": {
                    "type": "date"
                },

                "level": {
                    "type": "keyword"
                },

                "app_name": {
                    "type": "keyword"
                },

                "environment": {
                    "type": "keyword"
                },

                "method": {
                    "type": "keyword"
                },

                "status_code": {
                    "type": "integer"
                },

                "execution_time": {
                    "type": "float"
                },

                "client_ip_address": {
                    "type": "text"
                },

                "added_on": {
                    "type": "text"
                },

                "email": {
                    "type": "keyword",
                    "null_value": "NULL"
                },

                "user_id": {
                    "type": "keyword",
                    "null_value": "NULL"
                },

                "fullname": {
                    "type": "text"
                },

                "action_description": {
                    "type": "text"
                },

                "action_function_call": {
                    "type": "keyword",
                    "null_value": "NULL"
                },

                "api": {
                    "type": "text"
                },

                "headers": {"type": "object", "enabled": False},

                "body": {"type": "object", "enabled": True},

                "response": {"type": "object", "enabled": False},

                "extra": {"type": "object", "enabled": False},

                "error": {
                    "type": "text"
                },

                "traceback": {
                    "type": "text"
                },

                "hostname": {
                    "type": "keyword"
                },
            },
        },
    }


def ensure_index_exists():
    global _index_checked

    if _index_checked:
        return True

    client = get_opensearch_client()
    if client is None:
        return False

    index_name = get_opensearch_index_name()

    if not index_name:
        logger.warning(
            "OpenSearch logging disabled. Missing index name."
        )
        return False

    try:
        exists = client.indices.exists(index=index_name)

        if not exists:
            client.indices.create(
                index=index_name,
                body=get_index_mapping(),
            )

        _index_checked = True
        return True

    except Exception:
        logger.exception(
            "Failed to ensure OpenSearch index exists."
        )
        return False


def log_to_opensearch(log_data):
    client = get_opensearch_client()

    if client is None:
        return None

    index_name = get_opensearch_index_name()

    if not index_name:
        logger.warning(
            "OpenSearch logging disabled. Missing index name."
        )
        return "missing index name"

    if not ensure_index_exists():
        return "Index does not exists."

    try:
        log_data["@timestamp"] = datetime.utcnow().isoformat()
        log_data["hostname"] = socket.gethostname()

        response = client.index(
            index=index_name,
            body=log_data,
        )

        return response.get("_id")

    except Exception as e:
        logger.exception(
            "Failed to send log to OpenSearch."
        )
        return str(e)
