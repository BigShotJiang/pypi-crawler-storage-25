from simple_rest_client.api import API
from simple_rest_client.resource import Resource

from vgscli._version import __version__

CERT_MANAGER_URLS = {
    "dev": "https://cert-manager-api.verygoodsecurity.io",
    "prod": "https://cert-manager-api.live.apps.verygoodvault.com",
}


class CertificatesResource(Resource):
    actions = {
        "list": {"method": "GET", "url": "api/certificates"},
        "create": {"method": "POST", "url": "api/certificates"},
        "delete_by_domain": {"method": "DELETE", "url": "api/certificates/{}"},
        "renew": {"method": "PUT", "url": "api/certificates/{}"},
        "fetch_certificate": {
            "method": "GET",
            "url": "api/certificates/{}/certificate",
        },
        "create_csr": {"method": "POST", "url": "api/certificates/csr"},
    }


def _ensure_api_root(url: str) -> str:
    return (url or "").rstrip("/")


def create_cert_manager_api(vault_id, environment, token):
    env = (environment or "prod").lower()
    base = CERT_MANAGER_URLS.get(env, CERT_MANAGER_URLS["prod"])
    api_root_url = _ensure_api_root(base)

    headers = {
        "Content-Type": "application/vnd.api+json",
        "Accept": "application/json",
        "User-Agent": f"VGS CLI {__version__}",
        "Authorization": f"Bearer {token}",
    }
    if vault_id:
        headers["VGS-Tenant"] = vault_id

    api = API(
        api_root_url=api_root_url,
        params={},
        headers=headers,
        timeout=30,
        append_slash=False,
        json_encode_body=True,
    )
    api.add_resource(resource_name="certificates", resource_class=CertificatesResource)
    return api
