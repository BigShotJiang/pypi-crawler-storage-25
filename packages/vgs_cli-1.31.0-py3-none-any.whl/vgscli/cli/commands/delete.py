import click
from click_plugins import with_plugins

from vgscli.cli_utils import iter_entry_points
from vgscli.errors import handle_errors


@with_plugins(iter_entry_points("vgs.delete.plugins"))
@click.group("delete")
def delete():
    """
    Delete VGS resource.
    """
    pass


@delete.command("service-account")
@click.option("--organization", "-O", help="Organization ID", required=True)
@click.argument("client_id", type=click.STRING)
@click.pass_context
@handle_errors()
def delete_service_account(ctx, organization, client_id):
    """
    Delete a service account in the specified organization.
    """
    from vgscli.cli import create_account_mgmt_api

    account_mgmt = create_account_mgmt_api(ctx)
    account_mgmt.service_accounts.delete(organization, client_id)
