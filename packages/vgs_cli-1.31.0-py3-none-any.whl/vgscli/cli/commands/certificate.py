from __future__ import annotations

import base64
import logging
import re
import textwrap
from pathlib import Path
from typing import Any

import click

from vgscli.auth import token_util
from vgscli.cert_manager_api import create_cert_manager_api
from vgscli.cli_utils import dump_camelized_yaml
from vgscli.errors import handle_errors

logger = logging.getLogger(__name__)

APPLE_PAY_TYPE_MAP = {
    "apple-pay-merchant-identity": "APPLEPAY_MERCHANT",
    "apple-pay-payment-processing": "APPLEPAY_PAYMENT",
}

DEFAULT_ENV = "prod"

_CERT_ID_RE = re.compile(r"^CRT[0-9A-Z]+$", re.IGNORECASE)

# Allowlist: only these authorities are known to expose a downloadable public certificate payload
# via `/certificates/{domain}/certificate`. If backend adds new downloadable authorities,
# update this set accordingly.
DOWNLOADABLE_AUTHORITIES = {"LETS_ENCRYPT", "DIGICERT"}


def _debug_enabled() -> bool:
    ctx = click.get_current_context(silent=True)
    if not ctx:
        return False
    root = ctx.find_root()
    if getattr(root, "debug", False):
        return True
    obj = getattr(root, "obj", None)
    return bool(getattr(obj, "debug", False))


def _is_cert_id(value: str) -> bool:
    return bool(_CERT_ID_RE.fullmatch((value or "").strip()))


def _normalize_authority(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    norm = value.strip().upper().replace("-", "_")
    return norm or None


def _iter_cert_list_items(list_body: Any) -> list[dict[str, Any]]:
    if not isinstance(list_body, dict):
        return []
    data = list_body.get("data")
    if isinstance(data, list):
        return [d for d in data if isinstance(d, dict)]
    if isinstance(data, dict):
        return [data]
    return []


def _resolve_certificate_metadata(
    api: Any, *, vault: str, domain_or_id: str
) -> dict[str, Any]:
    """
    Resolve one certificate/CSR metadata object via certificates.list + client-side filtering.

    Note: the API spec does not provide a GET-by-id/domain metadata endpoint, so list is required.
    """
    resp = api.certificates.list(params={"vault_identifier": vault})
    items = _iter_cert_list_items(getattr(resp, "body", None) or {})

    needle = (domain_or_id or "").strip()
    needle_cf = needle.casefold()

    matches: list[dict[str, Any]] = []

    if _is_cert_id(needle):
        for item in items:
            item_id = item.get("id")
            if isinstance(item_id, str) and item_id.strip().casefold() == needle_cf:
                matches.append(item)
    else:
        for item in items:
            attrs = (
                item.get("attributes")
                if isinstance(item.get("attributes"), dict)
                else {}
            )
            item_domain = attrs.get("domain")
            if (
                isinstance(item_domain, str)
                and item_domain.strip().casefold() == needle_cf
            ):
                matches.append(item)

    if not matches:
        raise click.ClickException(
            f"No certificate found for '{domain_or_id}' in vault '{vault}'"
        )

    if len(matches) > 1 and not _is_cert_id(needle):
        lines = [
            f"Ambiguous domain '{domain_or_id}': {len(matches)} certificates found:"
        ]
        for m in matches:
            mid = m.get("id") or "UNKNOWN_ID"
            mtype = m.get("type") or "unknown-type"
            lines.append(f"- {mid} ({mtype})")
        lines.append("Re-run with --domain CRTxxxx to target a specific certificate.")
        raise click.ClickException("\n".join(lines))

    return matches[0]


def _is_csr_resource(cert_item: dict[str, Any]) -> bool:
    item_type = cert_item.get("type")
    return isinstance(item_type, str) and item_type.strip().casefold() == "csr"


def _assert_certificate_is_downloadable(
    api: Any, *, vault: str, domain_or_id: str
) -> None:
    """
    CSRs are not downloadable via fetch_certificate (no public cert payload).
    Only Let's Encrypt / DigiCert issued certificates should be allowed.
    """
    cert_item = _resolve_certificate_metadata(
        api, vault=vault, domain_or_id=domain_or_id
    )

    if _is_csr_resource(cert_item):
        cert_id = cert_item.get("id") or domain_or_id
        raise click.ClickException(
            "Cannot fetch/download a public certificate for a CSR. "
            f"Target '{cert_id}' is a CSR and has no public certificate payload. "
            "If you need the CSR, use `vgs certificate generate-csr` output (.csr). "
            "If you need a public certificate, issue a certificate via Let's Encrypt or DigiCert."
        )

    attrs = (
        cert_item.get("attributes")
        if isinstance(cert_item.get("attributes"), dict)
        else {}
    )
    authority = _normalize_authority(attrs.get("authority"))

    if authority not in DOWNLOADABLE_AUTHORITIES:
        cert_id = cert_item.get("id") or domain_or_id
        raise click.ClickException(
            f"Certificate '{cert_id}' is not downloadable via this command. "
            "Only Let's Encrypt and DigiCert certificates expose a public certificate payload."
        )


def _looks_like_backend_500(exc: BaseException) -> bool:
    status = getattr(exc, "status", None) or getattr(exc, "status_code", None)
    if status == 500:
        return True
    resp = getattr(exc, "response", None)
    if resp is not None and getattr(resp, "status_code", None) == 500:
        return True
    return False


def _fetch_public_certificate_payload(
    api: Any,
    *,
    vault: str,
    domain_or_id: str,
    params: dict[str, Any],
    action: str,
):
    """
    Shared flow for get-public + download:
      1) pre-flight: refuse CSR / unsupported authority
      2) call fetch_certificate
      3) fallback: make backend 500 user-friendly
    """
    _assert_certificate_is_downloadable(api, vault=vault, domain_or_id=domain_or_id)

    try:
        return api.certificates.fetch_certificate(domain_or_id, params=params)
    except Exception as exc:
        if _looks_like_backend_500(exc):
            if _debug_enabled():
                logger.debug(
                    "Backend 500 during %s for %s: %r",
                    action,
                    domain_or_id,
                    exc,
                    exc_info=True,
                )
            raise click.ClickException(
                f"Failed to {action} (server error). "
                "Verify the target is an issued Let's Encrypt/DigiCert certificate (not a CSR) and try again."
            ) from None
        raise


def _get_api(ctx: click.Context, vault: str):
    """
    Env resolution order:
      1) ctx.obj.env (normal CLI flow)
      2) root click params (if ctx.obj isn't initialized)
      3) DEFAULT_ENV ("prod")
    """
    token = token_util.get_access_token()

    env = getattr(getattr(ctx, "obj", None), "env", None)
    if not env:
        env = (ctx.find_root().params or {}).get("environment")
    if not env:
        env = DEFAULT_ENV

    return create_cert_manager_api(vault, env, token)


def _der_to_pem_certificate(der_bytes: bytes) -> str:
    b64 = base64.b64encode(der_bytes).decode("ascii")
    wrapped = "\n".join(textwrap.wrap(b64, width=64))
    return f"-----BEGIN CERTIFICATE-----\n{wrapped}\n-----END CERTIFICATE-----\n"


def _read_certificate_as_pem(cert_file: str) -> str:
    data = Path(cert_file).read_bytes()

    if b"-----BEGIN CERTIFICATE-----" in data:
        try:
            text = data.decode("ascii")
        except UnicodeDecodeError as e:
            raise click.ClickException(
                f"Certificate file '{cert_file}' looks like PEM but is not valid ASCII: {e}"
            )
        return text.rstrip("\n") + "\n"

    return _der_to_pem_certificate(data)


@click.group("certificate")
def certificate() -> None:
    """Manage certificates."""


@certificate.command("list")
@click.option("--vault", "-V", help="Vault ID.", required=True)
@click.pass_context
@handle_errors()
def certificate_list(ctx: click.Context, vault: str) -> None:
    params: dict[str, Any] = {"vault_identifier": vault}

    api = _get_api(ctx, vault)
    response = api.certificates.list(params=params)

    click.echo(
        dump_camelized_yaml(
            {
                "apiVersion": "1.0.0",
                "kind": "Certificates",
                "data": response.body,
            }
        )
    )


@certificate.command("create")
@click.option("--vault", "-V", help="Vault ID", required=True)
@click.option("--domain", "-d", required=True)
@click.option(
    "--authority",
    "-a",
    type=click.Choice(["lets-encrypt", "digicert"], case_sensitive=False),
    required=True,
)
@click.pass_context
@handle_errors()
def certificate_create(
    ctx: click.Context, vault: str, domain: str, authority: str
) -> None:
    payload = {
        "data": {
            "type": "certificate",
            "attributes": {
                "vault_identifier": vault,
                "domain": domain,
                "authority": authority.upper().replace("-", "_"),
            },
        }
    }

    api = _get_api(ctx, vault)
    response = api.certificates.create(body=payload)

    click.secho(f"Certificate for {domain} created successfully.", fg="green", err=True)

    click.echo(
        dump_camelized_yaml(
            {
                "apiVersion": "1.0.0",
                "kind": "Certificate",
                "data": response.body,
            }
        )
    )


@certificate.command("delete")
@click.option("--vault", "-V", help="Vault ID", required=True)
@click.option(
    "--domain", "-d", help="Certificate ID (CRTxxxx) or domain name", required=True
)
@click.option("--confirm", "-y", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
@handle_errors()
def certificate_delete(
    ctx: click.Context, vault: str, domain: str, confirm: bool
) -> None:
    # Unambiguous deletion: CRT id passed directly.
    if _is_cert_id(domain):
        if not confirm:
            click.confirm(
                f"Are you sure you want to delete certificate {domain}?",
                abort=True,
            )
        api = _get_api(ctx, vault)
        api.certificates.delete_by_domain(domain)
        click.secho(f"Certificate {domain} deleted successfully", fg="green")
        return

    # Domain name deletion: resolve first to avoid ambiguous deletion.
    api = _get_api(ctx, vault)
    resp = api.certificates.list(params={"vault_identifier": vault, "domain": domain})
    body = resp.body or {}
    data = body.get("data") if isinstance(body, dict) else None

    if isinstance(data, list):
        data_list = [d for d in data if isinstance(d, dict)]
    elif isinstance(data, dict):
        data_list = [data]
    else:
        data_list = []

    normalized_input_domain = (domain or "").strip().casefold()

    matches: list[tuple[str, str]] = []
    for item in data_list:
        cert_id = item.get("id")
        attrs = (
            item.get("attributes") if isinstance(item.get("attributes"), dict) else {}
        )
        cert_domain = attrs.get("domain")

        if (
            isinstance(cert_id, str)
            and cert_id
            and isinstance(cert_domain, str)
            and cert_domain
        ):
            # Defensive: also filter client-side in case backend ignores the query param.
            if cert_domain.strip().casefold() == normalized_input_domain:
                matches.append((cert_id, cert_domain))

    if len(matches) == 0:
        raise click.ClickException(f"No certificate found for domain '{domain}'")

    if len(matches) > 1:
        lines = [f"Ambiguous domain '{domain}': {len(matches)} certificates found:"]
        for cert_id, cert_domain in matches:
            lines.append(f"- {cert_id} ({cert_domain})")
        lines.append("Re-run with --domain CRTxxxx to delete a specific certificate.")
        raise click.ClickException("\n".join(lines))

    cert_id, cert_domain = matches[0]

    if not confirm:
        click.confirm(
            f"Are you sure you want to delete certificate {cert_id} for domain {cert_domain}?",
            abort=True,
        )

    api.certificates.delete_by_domain(cert_id)
    click.secho(f"Certificate for {cert_domain} deleted successfully", fg="green")


@certificate.command("renew")
@click.option("--vault", "-V", required=True, help="Vault ID")
@click.option(
    "--domain", "-d", required=True, help="Certificate ID (CRTxxxx) or domain to renew"
)
@click.pass_context
@handle_errors()
def certificate_renew(ctx: click.Context, vault: str, domain: str) -> None:
    api = _get_api(ctx, vault)
    api.certificates.renew(domain)
    click.secho(f"Certificate for {domain} renewed successfully", fg="green")


@certificate.command("get-public")
@click.option("--vault", "-V", help="Vault ID", required=True)
@click.option(
    "--domain", "-d", help="Certificate ID (CRTxxxx) or domain", required=True
)
@click.pass_context
@handle_errors()
def certificate_get_public(ctx: click.Context, vault: str, domain: str) -> None:
    api = _get_api(ctx, vault)
    response = _fetch_public_certificate_payload(
        api,
        vault=vault,
        domain_or_id=domain,
        params={"vault_identifier": vault},
        action="fetch public certificate payload",
    )

    click.echo(
        dump_camelized_yaml(
            {
                "apiVersion": "1.0.0",
                "kind": "CertificatePublicPayload",
                "data": response.body,
            }
        )
    )


@certificate.command("download")
@click.option("--vault", "-V", required=True, help="Vault ID")
@click.option(
    "--domain", "-d", required=True, help="Certificate ID (CRTxxxx) or domain"
)
@click.option(
    "--output",
    "-o",
    "-f",
    type=click.Path(dir_okay=False, writable=True),
    required=True,
    help="Output file to save the PEM certificate",
)
@click.pass_context
@handle_errors()
def certificate_download(
    ctx: click.Context, vault: str, domain: str, output: str
) -> None:
    api = _get_api(ctx, vault)
    response = _fetch_public_certificate_payload(
        api,
        vault=vault,
        domain_or_id=domain,
        params={"vault_identifier": vault},
        action="download public certificate payload",
    )

    cert_data = response.body.get("data") or []
    if not cert_data:
        raise click.ClickException(
            f"No certificate found for '{domain}' in vault '{vault}'"
        )

    cert_obj = cert_data[0] if isinstance(cert_data, list) else cert_data
    pem = (cert_obj.get("attributes") or {}).get("certificate")
    if not pem:
        raise click.ClickException(
            f"Certificate payload missing for '{domain}' in vault '{vault}'"
        )

    with open(output, "w", encoding="utf-8") as f:
        f.write(pem)

    click.echo(output)


@certificate.command("generate-csr")
@click.option("--vault", "-V", required=True, help="Vault ID")
@click.option(
    "--type",
    "cert_type",
    required=True,
    type=click.Choice(list(APPLE_PAY_TYPE_MAP.keys())),
)
@click.option(
    "--name",
    "-n",
    "--domain",
    "-d",
    "name",
    required=True,
    help="Domain for CSR (Apple Pay merchant domain). Use --name/-n or --domain/-d.",
)
@click.option(
    "--output",
    "-o",
    "-f",
    required=False,
    type=click.Path(dir_okay=False, writable=True),
    help="Save CSR PEM to file (recommended extension: .csr). If no extension is provided, .csr is added.",
)
@click.pass_context
@handle_errors()
def certificate_generate_csr(
    ctx: click.Context, vault: str, cert_type: str, name: str, output: str | None
) -> None:
    attrs: dict[str, Any] = {
        "vault_identifier": vault,
        "type": APPLE_PAY_TYPE_MAP[cert_type],
        "domain": name,
    }
    payload = {"data": {"type": "csr", "attributes": attrs}}

    api = _get_api(ctx, vault)
    response = api.certificates.create_csr(body=payload)

    body = response.body or {}
    if not isinstance(body, dict):
        raise click.ClickException("Invalid CSR response: expected JSON object")

    data_obj = body.get("data")
    if not isinstance(data_obj, dict):
        raise click.ClickException("Invalid CSR response: missing 'data'")

    attrs_obj = data_obj.get("attributes")
    if not isinstance(attrs_obj, dict):
        raise click.ClickException("Invalid CSR response: missing 'data.attributes'")

    csr_pem = attrs_obj.get("csr_payload") or attrs_obj.get("csrPayload")
    if not isinstance(csr_pem, str) or not csr_pem.strip():
        available = ", ".join(sorted(attrs_obj.keys()))
        raise click.ClickException(
            "CSR payload missing in response (expected data.attributes.csr_payload or data.attributes.csrPayload). "
            f"Available keys: {available}"
        )

    cert_id = data_obj.get("id") or attrs_obj.get("id")
    if not isinstance(cert_id, str) or not cert_id.strip():
        cert_id = None

    success_msg = f"CSR created for {name}"
    if cert_id:
        success_msg += f" (cert id: {cert_id})"

    if output:
        out_path = Path(output)
        if out_path.suffix == "":
            out_path = out_path.with_suffix(".csr")

        out_path.write_text(csr_pem.rstrip("\n") + "\n", encoding="utf-8")

        click.secho(success_msg, fg="green", err=True)
        click.echo(str(out_path))
        return

    click.secho(success_msg, fg="green", err=True)
    click.echo(
        dump_camelized_yaml(
            {
                "apiVersion": "1.0.0",
                "kind": "CertificateSigningRequest",
                "data": body,
            }
        )
    )


@certificate.command("upload")
@click.option("--vault", "-V", required=True, help="Vault ID")
@click.option(
    "--name",
    "-n",
    "--domain",
    "-d",
    "--cert-id",
    "name",
    required=True,
    help="Certificate domain or certificate ID (CRTxxxx) to associate this upload with.",
)
@click.option(
    "--file",
    "-f",
    "cert_file",
    required=True,
    type=click.Path(exists=True, dir_okay=False),
)
@click.pass_context
@handle_errors()
def certificate_upload(
    ctx: click.Context, vault: str, name: str, cert_file: str
) -> None:
    public_certificate = _read_certificate_as_pem(cert_file)

    payload = {
        "data": {
            "type": "certificate",
            "attributes": {
                "vault_identifier": vault,
                "domain": name,
                "public_certificate": public_certificate,
            },
        }
    }

    api = _get_api(ctx, vault)
    response = api.certificates.create(body=payload)

    click.secho(f"Certificate for {name} uploaded successfully.", fg="green", err=True)

    click.echo(
        dump_camelized_yaml(
            {
                "apiVersion": "1.0.0",
                "kind": "Certificate",
                "data": response.body,
            }
        )
    )
