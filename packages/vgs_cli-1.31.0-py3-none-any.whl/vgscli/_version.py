from typing import Optional

import click
import requests
from packaging.version import InvalidVersion, Version

from vgscli.text import bold, green

__version__ = "1.31.0"


# noinspection PyBroadException
def get_latest_stable_version(**kwargs) -> Optional[Version]:
    """
    Return the latest *stable* (non-prerelease) version available on PyPI.

    This intentionally ignores prereleases (e.g. .devN, rcN) so users only get
    prompted to update to stable versions unless they explicitly install a prerelease.
    """
    try:
        response_json = requests.get(
            "https://pypi.org/pypi/vgs-cli/json", **kwargs
        ).json()

        versions: list[Version] = []
        for s in response_json.get("releases", {}).keys():
            try:
                v = Version(s)
            except InvalidVersion:
                continue
            if not v.is_prerelease:
                versions.append(v)

        return max(versions) if versions else None
    except Exception:
        return None


def get_current_version() -> Optional[Version]:
    try:
        return Version(__version__)
    except InvalidVersion:
        return None


def check_for_updates() -> None:
    latest_stable = get_latest_stable_version(timeout=2)
    current = get_current_version()

    if not latest_stable or not current:
        return

    # Only notify for stable updates (never notify about dev/rc).
    if latest_stable > current:
        message = (
            f"CLI update available from {bold(green(__version__))} "
            f"to {bold(green(str(latest_stable)))}."
        )
        click.echo(message, err=True)


def version():
    return __version__
