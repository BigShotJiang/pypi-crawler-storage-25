default_app_config = "django_resaas.apps.DjangoResaasConfig"
