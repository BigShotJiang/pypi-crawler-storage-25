"""Configuration module for food web bifurcation explorer."""

from food_web_bifurcation_explorer.common.drawing.drawing_options import DrawingOptions
from food_web_bifurcation_explorer.common.exceptions import ParameterTypeError
from food_web_bifurcation_explorer.enums.network_data import NetworkData
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers
from food_web_bifurcation_explorer.enums.resolutions.layout_resolutions import LayoutResolutions
from food_web_bifurcation_explorer.enums.static_options import StaticOptions
from food_web_bifurcation_explorer.enums.types.bifurcation_diagram_types import BifurcationDiagramTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes


class Config:
    def __init__(self) -> None:
        # fixed parameters in float format
        self.fixed_parameter_values = [
            fixed_parameter / (IntegerNumbers.MAX_FIXED_PARAMETERS - 1) for fixed_parameter in range(0, IntegerNumbers.MAX_FIXED_PARAMETERS)
        ]
        # fixed parameters in string format
        self.fixed_parameter_values_str = [
            f"{fixed_parameter / (IntegerNumbers.MAX_FIXED_PARAMETERS - 1):.5f}" for fixed_parameter in range(0, IntegerNumbers.MAX_FIXED_PARAMETERS)
        ]
        # general options
        self.network: str = StaticOptions.DEFAULT_NETWORK
        self.resolution: int = LayoutResolutions.DEFAULT.value
        self.fixed_parameter_type: ParameterTypes = ParameterTypes.LOTKAVOLTERRA
        self.dynamic_paramameter_type: ParameterTypes = ParameterTypes.RECIPIENT
        self.fixed_parameter_value: float = StaticOptions.DEFAULT_PARAMETER_VALUE
        self.fixed_parameter_value_str: str = f"{self.fixed_parameter_value:.5f}"
        # bifurcation diagram values
        self.compartment_index: dict[BifurcationDiagramTypes, int] = {}
        self.compartment_value: dict[BifurcationDiagramTypes, str] = {}
        # set initial values for bifurcation diagram compartments
        self.compartment_index[BifurcationDiagramTypes.FIRST] = StaticOptions.DEFAULT_COMPARTMENT_FIRST
        self.compartment_index[BifurcationDiagramTypes.SECOND] = StaticOptions.DEFAULT_COMPARTMENT_SECOND
        self.compartment_value[BifurcationDiagramTypes.FIRST] = StaticOptions.DEFAULT_COMPARTMENT_FIRST_STR
        self.compartment_value[BifurcationDiagramTypes.SECOND] = StaticOptions.DEFAULT_COMPARTMENT_SECOND_STR
        # eigenValues spectrum options
        self.eigenvalue_spectrum_index: dict[BranchTypes, int] = {}
        for branch_type in BranchTypes:
            self.eigenvalue_spectrum_index[branch_type] = 0
        # drawing options
        self.drawing_options: DrawingOptions = DrawingOptions()
        # heatmap options
        self.heatmap_ternary_min_value: int = IntegerNumbers.HEATMAP_MIN_VALUE
        # bifurcation distribution options
        self.bifurcation_distribution_num_bins: int = IntegerNumbers.BIFURCATION_DISTRIBUTIONS_BINS_DEFAULT
        self.bifurcation_distribution_num_contours: int = IntegerNumbers.BIFURCATION_DISTRIBUTIONS_CONTOURS_DEFAULT
        self.bifurcation_distribution_use_contours: bool = False
        # logarithmic options
        self.heatmap_ternary_logarithmic: bool = False
        self.bifurcation_distribution_logarithmic: bool = False

    def get_current_compartments(self) -> list[str]:
        """Return the list of current compartments for the selected network."""
        if self.network is not None:
            return NetworkData.VALUES[self.network]
        # return empty list
        return []

    def update_network(self, network: str) -> None:
        """Update the current network and adjust compartment indices if necessary."""
        self.network = network
        # adjust compartments
        num_compartments: int = len(self.get_current_compartments())
        if self.compartment_index[BifurcationDiagramTypes.FIRST] >= num_compartments:
            self.compartment_index[BifurcationDiagramTypes.FIRST] = StaticOptions.DEFAULT_COMPARTMENT_FIRST
            self.compartment_value[BifurcationDiagramTypes.FIRST] = StaticOptions.DEFAULT_COMPARTMENT_FIRST_STR
        if self.compartment_index[BifurcationDiagramTypes.SECOND] >= num_compartments:
            self.compartment_index[BifurcationDiagramTypes.SECOND] = StaticOptions.DEFAULT_COMPARTMENT_SECOND
            self.compartment_value[BifurcationDiagramTypes.SECOND] = StaticOptions.DEFAULT_COMPARTMENT_SECOND_STR

    def update_fixed_parameter_type(self, fixed_parameter_type: ParameterTypes) -> None:
        """Update the type of the fixed parameter."""
        self.fixed_parameter_type = fixed_parameter_type
        # set dynamic parameter
        if self.fixed_parameter_type == ParameterTypes.DONOR:
            self.dynamic_paramameter_type = ParameterTypes.LOTKAVOLTERRA
        elif self.fixed_parameter_type == ParameterTypes.RECIPIENT:
            self.dynamic_paramameter_type = ParameterTypes.DONOR
        elif self.fixed_parameter_type == ParameterTypes.LOTKAVOLTERRA:
            self.dynamic_paramameter_type = ParameterTypes.RECIPIENT
        else:
            raise ParameterTypeError("invalid parameter")

    def update_fixed_parameter_value(self, fixed_parameter_value: float) -> float:
        """Update the value of the fixed parameter and its string representation."""
        self.fixed_parameter_value = fixed_parameter_value
        self.fixed_parameter_value_str = f"{fixed_parameter_value:.5f}"
        # return new value
        return self.fixed_parameter_value

    def update_eigenvalue_spectrum_index(self, branch_type: BranchTypes, eigenvalue_spectrum_index: int) -> None:
        """Update the eigenvalue spectrum index for a given branch type."""
        self.eigenvalue_spectrum_index[branch_type] = eigenvalue_spectrum_index

    def update_compartment(self, bifurcation_diagram_type: BifurcationDiagramTypes, compartment_index: int) -> None:
        """Update compartment to the specified value if it exists, otherwise set to the default compartment."""
        compartments: list[str] = self.get_current_compartments()
        # continue depending if value exist in the current compartments
        if compartment_index[bifurcation_diagram_type] < len(compartments):
            self.compartment_index[bifurcation_diagram_type] = compartment_index
            self.compartment_value[bifurcation_diagram_type] = compartments[compartment_index]
        elif bifurcation_diagram_type == BifurcationDiagramTypes.FIRST:
            self.compartment_index[bifurcation_diagram_type] = StaticOptions.DEFAULT_COMPARTMENT_FIRST
            self.compartment_value[bifurcation_diagram_type] = compartments[StaticOptions.DEFAULT_COMPARTMENT_FIRST]
        else:
            self.compartment_index[bifurcation_diagram_type] = StaticOptions.DEFAULT_COMPARTMENT_FIRST
            self.compartment_value[bifurcation_diagram_type] = compartments[StaticOptions.DEFAULT_COMPARTMENT_FIRST]
