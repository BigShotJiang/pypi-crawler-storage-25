from food_web_bifurcation_explorer.enums.types.bifurcation_types import BifurcationTypes


class DrawingBifurcationOptions:
    def __init__(self, empirical_enabled: bool, alternative_enabled: bool) -> None:
        # flags to indicate if drawing of specific bifurcation types is enabled for empirical and alternative branches
        self.saddlenode_empirical: bool = empirical_enabled
        self.saddlenode_alternative: bool = empirical_enabled
        self.transcritical_empirical: bool = empirical_enabled
        self.transcritical_alternative: bool = empirical_enabled
        self.hopf_subcritical_empirical: bool = empirical_enabled
        self.hopf_subcritical_alternative: bool = empirical_enabled
        self.hopf_supercritical_empirical: bool = empirical_enabled
        self.hopf_supercritical_alternative: bool = empirical_enabled
        self.hopf_bautin_empirical: bool = empirical_enabled
        self.hopf_bautin_alternative: bool = empirical_enabled
        self.hopf_envelope_empirical: bool = empirical_enabled
        self.hopf_envelope_alternative: bool = empirical_enabled
        # flags to indicate if redraw is required for specific bifurcation types in ternary and bifurcation diagrams
        self.redraw_saddlenode_empirical: bool = alternative_enabled
        self.redraw_saddlenode_alternative: bool = alternative_enabled
        self.redraw_transcritical_empirical: bool = alternative_enabled
        self.redraw_transcritical_alternative: bool = alternative_enabled
        self.redraw_hopf_subcritical_empirical: bool = alternative_enabled
        self.redraw_hopf_subcritical_alternative: bool = alternative_enabled
        self.redraw_hopf_supercritical_empirical: bool = alternative_enabled
        self.redraw_hopf_supercritical_alternative: bool = alternative_enabled
        self.redraw_hopf_bautin_empirical: bool = alternative_enabled
        self.redraw_hopf_bautin_alternative: bool = alternative_enabled
        self.redraw_hopf_envelope_empirical: bool = alternative_enabled
        self.redraw_hopf_envelope_alternative: bool = alternative_enabled

    def update_bifurcation_options_flags(
        self,
        saddlenode_empirical: bool,
        saddlenode_alternative: bool,
        transcritical_empirical: bool,
        transcritical_alternative: bool,
        hopf_subcritical_empirical: bool,
        hopf_subcritical_alternative: bool,
        hopf_supercritical_empirical: bool,
        hopf_supercritical_alternative: bool,
        hopf_bautin_empirical: bool,
        hopf_bautin_alternative: bool,
    ) -> None:
        """Update bifurcation flags"""
        # update values
        self.redraw_saddlenode_empirical = self.redraw_saddlenode_empirical or (self.saddlenode_empirical != saddlenode_empirical)
        self.redraw_saddlenode_alternative = self.redraw_saddlenode_alternative or (self.saddlenode_alternative != saddlenode_alternative)
        self.redraw_transcritical_empirical = self.redraw_transcritical_empirical or (self.transcritical_empirical != transcritical_empirical)
        self.redraw_transcritical_alternative = self.redraw_transcritical_alternative or (self.transcritical_alternative != transcritical_alternative)
        self.redraw_hopf_subcritical_empirical = self.redraw_hopf_subcritical_empirical or (
            self.hopf_subcritical_empirical != hopf_subcritical_empirical
        )
        self.redraw_hopf_subcritical_alternative = self.redraw_hopf_subcritical_alternative or (
            self.hopf_subcritical_alternative != hopf_subcritical_alternative
        )
        self.redraw_hopf_supercritical_empirical = self.redraw_hopf_supercritical_empirical or (
            self.hopf_supercritical_empirical != hopf_supercritical_empirical
        )
        self.redraw_hopf_supercritical_alternative = self.redraw_hopf_supercritical_alternative or (
            self.hopf_supercritical_alternative != hopf_supercritical_alternative
        )
        self.redraw_hopf_bautin_empirical = self.redraw_hopf_bautin_empirical or (self.hopf_bautin_empirical != hopf_bautin_empirical)
        self.redraw_hopf_bautin_alternative = self.redraw_hopf_bautin_alternative or (self.hopf_bautin_alternative != hopf_bautin_alternative)
        # update values
        self.saddlenode_empirical = saddlenode_empirical
        self.saddlenode_alternative = saddlenode_alternative
        self.transcritical_empirical = transcritical_empirical
        self.transcritical_alternative = transcritical_alternative
        self.hopf_subcritical_empirical = hopf_subcritical_empirical
        self.hopf_subcritical_alternative = hopf_subcritical_alternative
        self.hopf_supercritical_empirical = hopf_supercritical_empirical
        self.hopf_supercritical_alternative = hopf_supercritical_alternative
        self.hopf_bautin_empirical = hopf_bautin_empirical
        self.hopf_bautin_alternative = hopf_bautin_alternative

    def redraw_all(self) -> None:
        """Set all redraw flags to True."""
        self.redraw_saddlenode_empirical = True
        self.redraw_saddlenode_alternative = True
        self.redraw_transcritical_empirical = True
        self.redraw_transcritical_alternative = True
        self.redraw_hopf_subcritical_empirical = True
        self.redraw_hopf_subcritical_alternative = True
        self.redraw_hopf_supercritical_empirical = True
        self.redraw_hopf_supercritical_alternative = True
        self.redraw_hopf_bautin_empirical = True
        self.redraw_hopf_bautin_alternative = True
        self.redraw_hopf_envelope_empirical = True
        self.redraw_hopf_envelope_alternative = True

    def get_enabled_bifurcations(self) -> tuple[list[BifurcationTypes], list[BifurcationTypes]]:
        """Get the enabled bifurcation types for empirical and alternative branches."""
        # empirical bifurcations
        empirical_bifurcations: list[BifurcationTypes] = []
        if self.saddlenode_empirical:
            empirical_bifurcations.append(BifurcationTypes.SADDLENODE)
        if self.transcritical_empirical:
            empirical_bifurcations.append(BifurcationTypes.TRANSCRITICAL)
        if self.hopf_subcritical_empirical:
            empirical_bifurcations.append(BifurcationTypes.HOPF_SUBCRITICAL)
        if self.hopf_supercritical_empirical:
            empirical_bifurcations.append(BifurcationTypes.HOPF_SUPERCRITICAL)
        if self.hopf_bautin_empirical:
            empirical_bifurcations.append(BifurcationTypes.HOPF_BAUTIN)
        # alternative bifurcations
        alternative_bifurcations = []
        if self.saddlenode_alternative:
            alternative_bifurcations.append(BifurcationTypes.SADDLENODE)
        if self.transcritical_alternative:
            alternative_bifurcations.append(BifurcationTypes.TRANSCRITICAL)
        if self.hopf_subcritical_alternative:
            alternative_bifurcations.append(BifurcationTypes.HOPF_SUBCRITICAL)
        if self.hopf_supercritical_alternative:
            alternative_bifurcations.append(BifurcationTypes.HOPF_SUPERCRITICAL)
        if self.hopf_bautin_alternative:
            alternative_bifurcations.append(BifurcationTypes.HOPF_BAUTIN)
        return [empirical_bifurcations, alternative_bifurcations]
