class DrawingEigenvalueSpectrumOptions:
    def __init__(self) -> None:
        # flags to indicate if drawing an specific element of eigen values spectrum diagrams
        self.eigenvalue_spectrum_centered: bool = False
        # flags to indicate if redraw is required for eigen value spectrum diagrams
        self.redraw_eigenvalue_spectrum: bool = False

    def update_eigenvalue_spectrum_options_flags(
        self,
        eigenvalue_spectrum_centered: bool,
    ) -> None:
        """Update eigenvalue spectrum flags"""
        # update values
        self.redraw_eigenvalue_spectrum = self.redraw_eigenvalue_spectrum or (self.eigenvalue_spectrum_centered != eigenvalue_spectrum_centered)
        # update values
        self.eigenvalue_spectrum_centered = eigenvalue_spectrum_centered

    def redraw_all(self) -> None:
        """Set all redraw flags to True."""
        self.redraw_eigenvalue_spectrum = True
