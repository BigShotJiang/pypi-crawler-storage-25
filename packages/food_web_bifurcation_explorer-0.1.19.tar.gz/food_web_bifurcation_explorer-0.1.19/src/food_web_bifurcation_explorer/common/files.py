import os

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.data.bifurcation_data import ParameterTypes
from food_web_bifurcation_explorer.data.branch_data import BranchTypes
from food_web_bifurcation_explorer.enums.types.area_types import AreaTypes
from food_web_bifurcation_explorer.enums.types.bifurcation_types import BifurcationTypes
from food_web_bifurcation_explorer.enums.types.bifurcation_types_extended import BifurcationTypesExtended


class Files:
    def __init__(self) -> None:
        # main folder
        self.main_folder = os.path.join("D:\\", "OIST", "foodweb-dynamics-results")
        self.data_folder = os.path.join("D:\\", "OIST", "food-web-bifurcation-explorer-data")

    # ========================================
    # Continuation
    # ========================================

    def get_continuation_folder(self) -> str:
        """Return the path to the result pseudo-arc data folder."""
        return os.path.join(self.main_folder, "continuation")

    def get_continuation_subfolders(self) -> list:
        """Return a list of all folder paths inside the continuation folder."""
        return [entry.name for entry in os.scandir(self.get_continuation_folder()) if entry.is_dir()]

    def get_continuation_zip_file(self, fixed_parameter_value_str: str) -> str:
        """Return the path to the continuation zip file."""
        return os.path.join(self.get_continuation_folder(), glob.config.network, fixed_parameter_value_str + ".zip")

    # ========================================
    # Envelope
    # ========================================

    def get_envelope_folder(self) -> str:
        """Return the path to the result envelope data folder."""
        return os.path.join(self.main_folder, "envelope")

    def get_envelope_zip_file(self, fixed_parameter_value_str: str) -> str:
        """Return the path to the envelope zip file."""
        return os.path.join(self.get_envelope_folder(), glob.config.network, fixed_parameter_value_str + ".zip")

    # ========================================
    # Data
    # ========================================

    def get_data_folder(self) -> str:
        """Return the path to the data cache folder."""
        return self.data_folder

    def get_data_network_folder(self) -> str:
        """Return the path to the network placed in data cache folder folder."""
        return os.path.join(self.data_folder, glob.config.network)

    def get_data_ternary_zip_file(self) -> str:
        """Return the path to the data ternary zip file."""
        return os.path.join(self.get_data_network_folder(), "ternary_data.zip")

    def get_data_branch_zip_file(self, fixed_parameter_value_str: str) -> str:
        """Return the path to the data branch zip file."""
        return os.path.join(self.get_data_network_folder(), f"{fixed_parameter_value_str}.zip")

    def get_general_bifurcation_data_zip_file(self) -> str:
        """Return the path to the general bifurcation data zip file."""
        return os.path.join(self.data_folder, "general_bifurcation_data.zip")

    # ========================================
    # parquet files (from data zip files)
    # ========================================

    def get_branch_parquet_file(self, parameter_type: ParameterTypes, branch_type: BranchTypes, fixed_parameter_value: str) -> str:
        """Return the branch parquet file name."""
        return f"branch_{fixed_parameter_value}_{parameter_type.value}_{branch_type.value}.parquet"

    def get_bifurcation_parquet_file(self, parameter_type: ParameterTypes, branch_type: BranchTypes, fixed_parameter_value: str) -> str:
        """Return the bifuraction parquet file name."""
        return f"bifurcation_{fixed_parameter_value}_{parameter_type.value}_{branch_type.value}.parquet"

    def get_ternary_parquet_file(
        self, branch_type: BranchTypes, parameter_type: ParameterTypes, bifurcation_type: BifurcationTypesExtended, index: int
    ) -> str:
        """Return the ternary parquet file name."""
        return f"ternary_{branch_type.value}_{parameter_type.value}_{bifurcation_type.value}_{index}.parquet"

    def get_general_bifurcation_data_parquet_file(self, branch_type: BranchTypes, bifurcation_type: BifurcationTypes) -> str:
        """Return the general bifurcation data file name."""
        return f"general_bifurcation_data_{branch_type.value}_{bifurcation_type.value}.parquet"

    def get_ternary_grid_counts_file(self, branch_type: BranchTypes) -> str:
        """Return the ternary grid countsfile name."""
        return f"ternary_grid_counts_{branch_type.value}.parquet"

    def get_ternary_shape_file(self, area_types: AreaTypes) -> str:
        return f"ternary_shape_{area_types.value}.parquet"
