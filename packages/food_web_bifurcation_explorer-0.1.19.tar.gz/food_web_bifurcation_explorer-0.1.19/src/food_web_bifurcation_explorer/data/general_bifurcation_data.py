import os
import shutil
import zipfile

import numpy as np
import pandas as pd

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.resolutions.ternary_heatmap_resolutions import TernaryHeatmapResolutions
from food_web_bifurcation_explorer.enums.static_options import StaticOptions
from food_web_bifurcation_explorer.enums.types.bifurcation_types import BifurcationTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes


class GeneralBifurcationData:

    def __init__(self) -> None:

        # dictionary used for keeping general bifurcation data with different resolutions
        self.data: dict[TernaryHeatmapResolutions, pd.DataFrame] = {}
        
        # Check if generate or load general bifurcation data
        if StaticOptions.GENERATE_GENERAL_BIFURCATION_DATA:
            self.generate_data()
        else:
            self.load_data()

    def generate_data(self) -> None:

        # show info
        print("generating general bifurcation data")

        # get all the networks in the continuation folder
        networks = glob.files.get_continuation_subfolders()

        # declare a list to store all the dataframes that we will concatenate later
        dataframes = []

        # iterate over all networks
        for network in networks:

            # show info
            print(f"Processing {network}")

            # iterate over all fixed parameter values
            for fixed_parameter_value in glob.config.fixed_parameter_values_str:

                # get the path of the continuation zip file for this network and fixed parameter value
                continuation_zip_file_path = os.path.join(glob.files.get_continuation_folder(), network, fixed_parameter_value + ".zip")
                # ensure the zip file exists before trying to open it
                if os.path.exists(continuation_zip_file_path):
                    try:
                        # open zip file
                        with zipfile.ZipFile(continuation_zip_file_path, "r") as continuation_zip_file:
                            # iterate over all branch types
                            for branch_type in BranchTypes:
                                file_name = f"bifurcations_{branch_type.value}_{ParameterTypes.LOTKAVOLTERRA.value}_{fixed_parameter_value}.csv"
                                
                                # Comprobar que el archivo existe en el zip para evitar excepciones
                                if file_name not in continuation_zip_file.namelist():
                                    continue
                                
                                # open CSV file
                                with continuation_zip_file.open(file_name) as file:
                                    
                                    # read the CSV file into a dataframe, selecting only the relevant columns
                                    bifurcations_dataframe = pd.read_csv(file, usecols=["type", "sd", "sr", "sl", "index"])

                                    # rename the "index" column to "branch_index" to avoid problems with the parameter Index of Pandas
                                    bifurcations_dataframe = bifurcations_dataframe.rename(columns={"index": "branch_index"})
                                
                                    # filter max number of bifurcations per branch type (empirical: 3, alternative: 5)
                                    if branch_type == BranchTypes.EMPIRICAL:
                                        bifurcations_dataframe = bifurcations_dataframe[bifurcations_dataframe["branch_index"] <= 3]
                                    else:
                                        bifurcations_dataframe = bifurcations_dataframe[bifurcations_dataframe["branch_index"] <= 5]
                                    
                                    # group by type
                                    bifurcations_dataframe_grouped = bifurcations_dataframe.groupby("type")
                                
                                    # iterate over bifurcation types
                                    for bifurcation_type in BifurcationTypes:
                                        if bifurcation_type.value in bifurcations_dataframe_grouped.groups:

                                            # create a copy of the dataframe with only the relevant columns for this bifurcation type
                                            dataframe_filtered = bifurcations_dataframe_grouped.get_group(bifurcation_type.value)[["sd", "sr", "sl"]].copy()
                                        
                                            # create column for this branch type and bifurcation type with value 1
                                            dataframe_filtered[f"{branch_type.value}_{bifurcation_type.value}"] = 1

                                            # save network name
                                            dataframe_filtered["networks"] = network

                                            # append to the list of dataframes
                                            dataframes.append(dataframe_filtered)
                    except Exception as e:
                        print(f"Error processing {continuation_zip_file_path}: {e}")

        # declare temporal dir
        os.makedirs(glob.files.get_data_folder(), exist_ok=True)
        temporal_dir = os.path.join(glob.files.get_data_folder(), "temp_parquet_general_bifurcation_data")
        os.makedirs(temporal_dir, exist_ok=True)
        temporal_files = []

        # only continue if we have dataframes to save
        if dataframes:
            # concatenate all dataframes
            combined_raw_dataframe = pd.concat(dataframes, ignore_index=True)
            
            # extract all column names
            bifurcation_columns = [column for column in combined_raw_dataframe.columns if column not in ["sd", "sr", "sl", "networks"]]

            # fill all NAN values with zeros
            combined_raw_dataframe[bifurcation_columns] = combined_raw_dataframe[bifurcation_columns].fillna(0).astype(int)
            
            # create aggregation rules for sum and networks
            aggregation_rules = {col: 'sum' for col in bifurcation_columns}
            aggregation_rules["networks"] = lambda x: ",".join(sorted(set(x.dropna())))
        else:
            # create empty values
            combined_raw_dataframe = pd.DataFrame(columns=["sd", "sr", "sl", "networks"])
            aggregation_rules = {}

        # process for every resolution
        for ternary_heatmap_resolution in TernaryHeatmapResolutions:
            # show info                
            print(f"Processing resolution {ternary_heatmap_resolution}")

            # make a copy of the raw dataframe
            dataframe_resolution = combined_raw_dataframe.copy()
            
            if not dataframe_resolution.empty:
                # truncate the sd-sr-sl values to the ternary_heatmap_resolution value
                factor = 10 ** ternary_heatmap_resolution.value
                dataframe_resolution[["sd", "sr", "sl"]] = np.trunc(dataframe_resolution[["sd", "sr", "sl"]] * factor) / factor
                
                # group dataframe using sd-sr-sl 
                grouped_dataframe = dataframe_resolution.groupby(["sd", "sr", "sl"]).agg(aggregation_rules).reset_index()
            else:
                grouped_dataframe = dataframe_resolution
            
            # ensure that all columns exist (incluso si estaba vacío)
            for branch_type in BranchTypes:
                for bifurcation_type in BifurcationTypes:
                    col_name = f"{branch_type.value}_{bifurcation_type.value}"
                    if col_name not in grouped_dataframe.columns:
                        grouped_dataframe[col_name] = 0

            # save grouped dataframe in data
            self.data[ternary_heatmap_resolution] = grouped_dataframe

            # save parquet file
            parquet_filename = f"bifurcation_data_{ternary_heatmap_resolution.value}.parquet"
            temp_path = os.path.join(temporal_dir, parquet_filename)
            grouped_dataframe.to_parquet(temp_path, compression="snappy")
            temporal_files.append((temp_path, parquet_filename))

        # save all in zip file (Ahora siempre creará el zip, aunque contenga parquets vacíos)
        if temporal_files:
            with zipfile.ZipFile(glob.files.get_general_bifurcation_data_zip_file(), "w", compression=zipfile.ZIP_DEFLATED) as data_zip_file:
                for temp_path, arcname in temporal_files:
                    data_zip_file.write(temp_path, arcname)

        # clean temporal directory
        shutil.rmtree(temporal_dir)


    def load_data(self) -> None:
        # show info
        print("loading general bifurcation data")

        # open zip file
        with zipfile.ZipFile(glob.files.get_general_bifurcation_data_zip_file(), "r", compression=zipfile.ZIP_DEFLATED) as data_zip_file:

            # iterate over all resolutions
            for ternary_heatmap_resolution in TernaryHeatmapResolutions:
                
                # open data zip file
                with data_zip_file.open(f"bifurcation_data_{ternary_heatmap_resolution.value}.parquet") as f:
                    # read parquet file and keep y data
                    self.data[ternary_heatmap_resolution] = pd.read_parquet(f)