import os
import zipfile

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.bifurcation_types_extended import BifurcationTypesExtended
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes
from food_web_bifurcation_explorer.enums.types.parameter_types_extended import ParameterTypesExtended


# bifurcation data
class BifurcationData:
    """Class to manage and store bifurcation data for different types and parameters."""

    def __init__(self) -> None:
        """Initialize the BifurcationData object, setting up data structures for bifurcation types and plot data."""
        self.fixed_parameter_type: ParameterTypes | None = None
        self.fixed_parameter_value: str | None = None
        self.data: dict[BifurcationTypesExtended, dict[int, dict[ParameterTypesExtended, dict[float, float | list[int] | list[float]]]]] = {}
        # create dictionary with bifurcation types
        for bifurcation_type in BifurcationTypesExtended:
            self.data[bifurcation_type] = {}

    def clear_data(self) -> None:
        self.fixed_parameter_type = None
        self.fixed_parameter_value = None
        # clar bifurcation types
        for bifurcation_type in BifurcationTypesExtended:
            self.data[bifurcation_type] = {}

    def add_bifurcation_index(self, bifurcation_type: BifurcationTypesExtended, bifurcation_index: int) -> None:
        """Add a new bifurcation index for a given bifurcation type.

        Args:
            bifurcation_type (str): The type of bifurcation.
            bifurcation_index (int): The index to add.

        """
        # declare dictionary
        self.data[bifurcation_type][bifurcation_index] = {}
        # create dicctionar for every parameter type
        for parameter_type_extended in ParameterTypesExtended:
            # set plot data values
            self.data[bifurcation_type][bifurcation_index][parameter_type_extended] = {}

    # set data
    def set_data(self, line_parts: list[str], fixed_parameter_value_str: str) -> None:
        """Set the bifurcation data from food_web_bifurcation_explorer.a line of input and a fixed parameter value.

        Args:
            line_parts (list[str]): The parts of the input line.
            fixed_parameter_value_str (str): The fixed parameter value as a string.

        """
        fixed_parameter_value = float(fixed_parameter_value_str)
        # get parts type
        bifurcation_type: BifurcationTypesExtended = BifurcationTypesExtended(line_parts[0])
        bifurcation_index: int = int(line_parts[1])
        sd: float = float(line_parts[2])
        sr: float = float(line_parts[3])
        sl: float = float(line_parts[4])
        biomass_values: list[float] = [float(x) for x in line_parts[5].split("_")]
        # check if add a new bifurcation index
        if bifurcation_index not in self.data[bifurcation_type]:
            self.add_bifurcation_index(bifurcation_type, bifurcation_index)
        self.data[bifurcation_type][bifurcation_index][ParameterTypesExtended.DONOR][fixed_parameter_value] = sd
        self.data[bifurcation_type][bifurcation_index][ParameterTypesExtended.RECIPIENT][fixed_parameter_value] = sr
        self.data[bifurcation_type][bifurcation_index][ParameterTypesExtended.LOTKAVOLTERRA][fixed_parameter_value] = sl
        self.data[bifurcation_type][bifurcation_index][ParameterTypesExtended.BIOMASS][fixed_parameter_value] = biomass_values
        if bifurcation_type == BifurcationTypesExtended.EXTINCT:
            # search all compartments with zero biomass
            extinct_compartments: list[int] = []
            for i, value in enumerate(biomass_values):
                if value < 0:
                    extinct_compartments.append(i)
            # set label
            self.data[bifurcation_type][bifurcation_index][ParameterTypesExtended.LABELS][fixed_parameter_value] = extinct_compartments

    # check if exist data
    def exist(self, bifurcation_type: BifurcationTypesExtended) -> bool:
        """Check if data exists for a given bifurcation type.

        Args:
            bifurcation_type (str): The type of bifurcation.

        Returns:
            bool: True if data exists, False otherwise.

        """
        return len(self.data[bifurcation_type]) > 0

    # get indexes
    def get_indexes(self, bifurcation_type: BifurcationTypesExtended) -> list[int]:
        """Get the list of indexes for a given bifurcation type.

        Args:
            bifurcation_type (str): The type of bifurcation.

        Returns:
            list: List of indexes.

        """
        return list(self.data[bifurcation_type])

    # get X data
    def get_bifurcation_diagram_x(self, bifurcation_type: BifurcationTypesExtended, index: int) -> list[float]:
        """Get the X values for the bifurcation diagram.

        Args:
            bifurcation_type (str): The type of bifurcation.
            index (int): The index to retrieve.

        Returns:
            list: List of X values.

        """
        # get x values
        if glob.config.fixed_parameter_value in self.data[bifurcation_type][index][glob.config.dynamic_paramameter_type]:
            return [self.data[bifurcation_type][index][glob.config.dynamic_paramameter_type][glob.config.fixed_parameter_value]]
        return []

    # get Y data
    def get_bifurcation_diagram_y(self, bifurcation_type: BifurcationTypesExtended, index: int, biomass_compartment: int) -> list[float]:
        """Get the Y values for the bifurcation diagram.

        Args:
            bifurcation_type (str): The type of bifurcation.
            index (int): The index to retrieve.
            biomass_compartment (int): The biomass compartment index.

        Returns:
            list: List of Y values.

        """
        if glob.config.fixed_parameter_value in self.data[bifurcation_type][index][ParameterTypesExtended.BIOMASS]:
            return [self.data[bifurcation_type][index][ParameterTypesExtended.BIOMASS][glob.config.fixed_parameter_value][biomass_compartment]]
        return []

    # get labels
    def get_bifurcation_diagram_labels(self, bifurcation_type: BifurcationTypesExtended, index: int) -> list[str]:
        """Get the labels for the bifurcation diagram.

        Args:
            bifurcation_type (str): The type of bifurcation.
            index (int): The index to retrieve.

        Returns:
            list: List of label strings.

        """
        if glob.config.fixed_parameter_value in self.data[bifurcation_type][index][ParameterTypesExtended.LABELS]:
            # get compartment names instead of index
            label_indexes: list[int] = self.data[bifurcation_type][index][ParameterTypesExtended.LABELS][glob.config.fixed_parameter_value]
            compartments_str = glob.config.get_current_compartments()
            # format: "label (index)"
            return [f"<b>{index + 1} ({compartments_str[index]})</b>" for index in label_indexes]
        return []

    # read bifurcation data file
    def read_bifurcation_data_file(self, fixed_parameter_type: ParameterTypes, fixed_parameter_value: str) -> None:
        """Read a bifurcation data file from food_web_bifurcation_explorer.a zip archive

        Args:
            fixed_parameter_type (ParameterTypes): The type of the fixed parameter.
            fixed_parameter_value (str): The value of the fixed parameter.

        """
        # set common parameters
        self.fixed_parameter_type = fixed_parameter_type
        self.fixed_parameter_value = fixed_parameter_value
        # check that zip exist
        if os.path.exists(glob.files.get_continuation_zip_file(self.fixed_parameter_value)):
            # open zip
            with zipfile.ZipFile(glob.files.get_continuation_zip_file(self.fixed_parameter_value), "r") as zip_file:
                # open bifurcation file
                with zip_file.open("bifurcations_" + fixed_parameter_type + "_" + fixed_parameter_value + ".txt") as file:
                    # iterate over every line
                    for line_bits in file:
                        # strip line
                        line = line_bits.decode("utf-8").strip()
                        # check that line exist
                        if not line:
                            continue
                        # set data
                        self.set_data(line.split(";"), fixed_parameter_value)
