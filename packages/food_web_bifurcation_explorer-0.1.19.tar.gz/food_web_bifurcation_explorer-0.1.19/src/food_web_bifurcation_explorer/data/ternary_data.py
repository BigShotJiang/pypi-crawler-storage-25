"""Module for managing ternary plot data from bifurcation analysis.

This module contains the TernaryData class which handles loading, storing, and processing
bifurcation analysis data for ternary plots across different branch types, parameter types,
and bifurcation types.
"""

import os
import zipfile

import pandas as pd

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.data.shape_data import ShapeData
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers
from food_web_bifurcation_explorer.enums.types.area_types import AreaTypes
from food_web_bifurcation_explorer.enums.types.bifurcation_types import BifurcationTypes
from food_web_bifurcation_explorer.enums.types.bifurcation_types_extended import BifurcationTypesExtended
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.hopf_parameter_types import HopfParameterTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes


class TernaryData:
    """Branch data container for storing and processing bifurcation analysis data."""

    def __init__(self) -> None:
        # declare dataframe
        self.ternary_dataframe: dict[
            BranchTypes, dict[ParameterTypes, dict[BifurcationTypes | BifurcationTypesExtended, dict[int, pd.DataFrame]]]
        ] = {}

        # iterate over parameter types, branch types and bifurcation types to initialize nested dictionaries
        for branch_type in BranchTypes:
            self.ternary_dataframe[branch_type] = {}
            for parameter_type in ParameterTypes:
                self.ternary_dataframe[branch_type][parameter_type] = {}
                for bifurcation_type in BifurcationTypesExtended:
                    self.ternary_dataframe[branch_type][parameter_type][bifurcation_type] = {}
                    # get num of traces
                    numTraces = IntegerNumbers.TRACES_NUM_MAX
                    if bifurcation_type == BifurcationTypesExtended.EXTINCT:
                        numTraces = IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS
                    for index in range(numTraces):
                        self.ternary_dataframe[branch_type][parameter_type][bifurcation_type][index] = pd.DataFrame()
        # declare shape data
        self.shape_data: ShapeData = ShapeData()
        # declare auxiliar dictionaries using for loading data (used to calculate bauting points)
        self.hopf_bifurcations = {}
        self.temporal_frame = {}

    def clear_data(self) -> None:
        """Reset all dataframes"""
        # simply reset all dataframes to empty
        for branch_type in BranchTypes:
            for parameter_type in ParameterTypes:
                for bifurcation_type in BifurcationTypesExtended:
                    # get num of traces
                    numTraces = IntegerNumbers.TRACES_NUM_MAX
                    if bifurcation_type == BifurcationTypesExtended.EXTINCT:
                        numTraces = IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS
                    for index in range(numTraces):
                        self.ternary_dataframe[branch_type][parameter_type][bifurcation_type][index] = pd.DataFrame()

    def get_ternary_values(
        self, branch_type: BranchTypes, bifurcation_type: BifurcationTypesExtended, index: int
    ) -> tuple[list[int | None], list[int | None], list[int | None]]:
        """Get the list of values for a given branch, parameter, bifurcation type and index."""
        # get dataframe for current branch, parameter, bifurcation type and index
        dataframe = self.ternary_dataframe[branch_type][glob.config.fixed_parameter_type][bifurcation_type][index]
        # declare values arrays filled with None
        sd_values: list[int | None] = [None] * IntegerNumbers.MAX_FIXED_PARAMETERS
        sr_values: list[int | None] = [None] * IntegerNumbers.MAX_FIXED_PARAMETERS
        sl_values: list[int | None] = [None] * IntegerNumbers.MAX_FIXED_PARAMETERS
        # check that dataframe isn't empty
        if not dataframe.empty:
            # Populate the arrays using the fixed_value directly as the array index
            for (
                sd_val,
                sr_val,
                sl_val,
                fixed_pos,
            ) in zip(
                # parameters
                dataframe[ParameterTypes.DONOR.value],
                dataframe[ParameterTypes.RECIPIENT.value],
                dataframe[ParameterTypes.LOTKAVOLTERRA.value],
                # index
                dataframe["fixed_value"],
            ):
                # position in the array
                pos = int(fixed_pos)
                # parameters
                sd_values[pos] = sd_val
                sr_values[pos] = sr_val
                sl_values[pos] = sl_val
        # return values
        return [sd_values, sr_values, sl_values]

    def get_hopf_parameter_values(self, hopf_parameter_type: HopfParameterTypes, hopf_bifurcation_type: BifurcationTypes) -> list[int | None]:
        """Get the hopf parameterlist of values for a given branch, parameter, bifurcation type and index."""
        # get dataframe for current branch, parameter, bifurcation type and index
        dataframe = self.ternary_dataframe[BranchTypes.EMPIRICAL][glob.config.fixed_parameter_type][hopf_bifurcation_type][1]
        # declare values arrays filled with None
        values: list[int | None] = [None] * IntegerNumbers.MAX_FIXED_PARAMETERS
        # check that dataframe isn't empty
        if not dataframe.empty:
            # Populate the arrays using the fixed_value directly as the array index
            for fixed_pos, value in zip(dataframe["fixed_value"], dataframe[hopf_parameter_type]):
                if value is not None:
                    # position in the array
                    pos = int(fixed_pos)
                    # specific of hopf bifurcations
                    values[pos] = value
        # return values
        return values

    def get_ternary_indexes(self, branch_type: BranchTypes, bifurcation_type: BifurcationTypesExtended) -> list[int]:
        """Get the list of index columns for a given branch, parameter and bifurcation type."""
        # declare empty index list
        indexes: list[int] = []
        # check for every index if the dataframe is not empty, then add to the list of indexes
        numTraces = IntegerNumbers.TRACES_NUM_MAX
        if bifurcation_type == BifurcationTypesExtended.EXTINCT:
            numTraces = IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS
        for index in range(numTraces):
            if not self.ternary_dataframe[branch_type][glob.config.fixed_parameter_type][bifurcation_type][index].empty:
                indexes.append(index)
        return indexes

    def load_parquet_data(self, ternary_zip_file: zipfile.ZipFile) -> None:
        """Load parquet data from a parquet file stream and set fixed parameter information."""
        # first clear data
        self.clear_data()
        # try to load branch parquet file from zip
        for branch_type in BranchTypes:
            for parameter_type in ParameterTypes:
                for bifurcation_type in BifurcationTypesExtended:
                    # get num of traces
                    numTraces = IntegerNumbers.TRACES_NUM_MAX
                    if bifurcation_type == BifurcationTypesExtended.EXTINCT:
                        numTraces = IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS
                    for index in range(numTraces):
                        try:
                            parquet_file = glob.files.get_ternary_parquet_file(branch_type, parameter_type, bifurcation_type, index)
                            with ternary_zip_file.open(parquet_file) as f:
                                self.ternary_dataframe[branch_type][parameter_type][bifurcation_type][index] = pd.read_parquet(f)
                        except:
                            pass
        # load ternary shape file
        for area_type in AreaTypes:
            parquet_file = glob.files.get_ternary_shape_file(area_type)
            with ternary_zip_file.open(parquet_file) as f:
                self.shape_data.perimeters[area_type] = pd.read_parquet(f)

    def read_continuation_files(self) -> None:
        """Read ternary data from continuation files."""
        # first clear data
        self.clear_data()
        # init auxiliar containers (hopf and temporal_frame)
        self._init_auxiliar_containers()
        # now read data for every zip file
        for index, fixed_parameter_value in enumerate(glob.config.fixed_parameter_values_str):
            # show current processed value
            print(fixed_parameter_value)
            # get continuation zip file path
            continuation_zip_file_path = glob.files.get_continuation_zip_file(fixed_parameter_value)
            # check if file exists
            if os.path.exists(continuation_zip_file_path):
                # open continuation zip file
                with zipfile.ZipFile(continuation_zip_file_path, "r") as continuation_zip_file:
                    # open CSV for every parameter and branch type
                    for branch_type in BranchTypes:
                        for parameter_type in ParameterTypes:
                            # parse CSV in temporal dataframe
                            file_name = f"bifurcations_{branch_type.value}_{parameter_type.value}_{fixed_parameter_value}.csv"
                            with continuation_zip_file.open(file_name) as file:
                                tmp_dataframe = pd.read_csv(file)
                            # iterate over bifurcation types
                            for bifurcation_type in BifurcationTypesExtended:
                                # filter rows for current bifurcation type
                                bifurcation_type_rows = tmp_dataframe[tmp_dataframe["type"] == bifurcation_type.value]
                                # get max num of traces
                                maxNumTraces = IntegerNumbers.TRACES_NUM_MAX
                                if bifurcation_type == BifurcationTypesExtended.EXTINCT:
                                    maxNumTraces = IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS
                                # iterate using zip
                                for (
                                    sd_val,
                                    sr_val,
                                    sl_val,
                                    index_val,
                                    l1,
                                    oscillation_frequency,
                                    transversal_crossing_speed,
                                    normalization_error,
                                ) in zip(
                                    # parameters
                                    bifurcation_type_rows[ParameterTypes.DONOR.value],
                                    bifurcation_type_rows[ParameterTypes.RECIPIENT.value],
                                    bifurcation_type_rows[ParameterTypes.LOTKAVOLTERRA.value],
                                    # index
                                    bifurcation_type_rows["index"],
                                    # hopf bifurcation specific parameters
                                    bifurcation_type_rows[HopfParameterTypes.L1.value],
                                    bifurcation_type_rows[HopfParameterTypes.OSCILLATION_FREQUENCY.value],
                                    bifurcation_type_rows[HopfParameterTypes.TRANSVERSAL_CROSSING_SPEED.value],
                                    bifurcation_type_rows[HopfParameterTypes.NORMALIZATION_ERROR.value],
                                ):
                                    # get index value as integer
                                    index_value = int(index_val)
                                    # ensure that index value is less than max num of traces, otherwise skip (to avoid out of range errors)
                                    if index_value < maxNumTraces:
                                        # declare row to save in temporal frame
                                        row = {
                                            # parameters
                                            ParameterTypes.DONOR.value: sd_val,
                                            ParameterTypes.RECIPIENT.value: sr_val,
                                            ParameterTypes.LOTKAVOLTERRA.value: sl_val,
                                            # index
                                            "fixed_value": index,
                                            # hopf bifurcation specific parameters
                                            HopfParameterTypes.L1.value: l1,
                                            HopfParameterTypes.OSCILLATION_FREQUENCY.value: oscillation_frequency,
                                            HopfParameterTypes.TRANSVERSAL_CROSSING_SPEED.value: transversal_crossing_speed,
                                            HopfParameterTypes.NORMALIZATION_ERROR.value: normalization_error,
                                        }
                                        self.temporal_frame[branch_type][parameter_type][bifurcation_type][index_value].append(row)
                                        # save hopf bifurcation in special structure to process later the bauting points
                                        if bifurcation_type in (
                                            BifurcationTypesExtended.HOPF_SUBCRITICAL,
                                            BifurcationTypesExtended.HOPF_SUPERCRITICAL,
                                        ):
                                            self.hopf_bifurcations[branch_type][parameter_type][index_value][bifurcation_type][index] = row
            # load shape data for current fixed parameter value
            self.shape_data.load_shape_data(index, fixed_parameter_value)
        # calculate bauting points
        self._calculate_bauting_points()
        # now that all files are processed, update the ternary_dataframe with the complete data from self.temporal_frame
        for branch_type in BranchTypes:
            for parameter_type in ParameterTypes:
                for bifurcation_type in BifurcationTypesExtended:
                    # get num of traces
                    numTraces = IntegerNumbers.TRACES_NUM_MAX
                    if bifurcation_type == BifurcationTypesExtended.EXTINCT:
                        numTraces = IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS
                    for index_value in range(numTraces):
                        data_list = self.temporal_frame[branch_type][parameter_type][bifurcation_type][index_value]
                        if data_list:
                            # Create the dataframe for this specific index
                            dataframe = pd.DataFrame(data_list)
                            # Ensure columns are ordered correctly just in case
                            dataframe = dataframe.reindex(
                                columns=[
                                    ParameterTypes.DONOR.value,
                                    ParameterTypes.RECIPIENT.value,
                                    ParameterTypes.LOTKAVOLTERRA.value,
                                    "fixed_value",
                                    HopfParameterTypes.L1.value,
                                    HopfParameterTypes.OSCILLATION_FREQUENCY.value,
                                    HopfParameterTypes.TRANSVERSAL_CROSSING_SPEED.value,
                                    HopfParameterTypes.NORMALIZATION_ERROR.value,
                                ]
                            )
                            # Assign the fully built dataframe to the class attribute
                            self.ternary_dataframe[branch_type][parameter_type][bifurcation_type][index_value] = dataframe
                        else:
                            pass
        # reset bot auxiliar structures to free memory
        self.hopf_bifurcations = {}
        self.temporal_frame = {}
        # process shape data
        self.shape_data.process_shape_data()

    def _init_auxiliar_containers(self) -> None:

        # create a temporary nested dictionary to hold rows as native Python lists
        for branch_type in BranchTypes:
            self.temporal_frame[branch_type] = {}
            for parameter_type in ParameterTypes:
                self.temporal_frame[branch_type][parameter_type] = {}
                for bifurcation_type in BifurcationTypesExtended:
                    self.temporal_frame[branch_type][parameter_type][bifurcation_type] = {}
                    # get num of traces
                    numTraces = IntegerNumbers.TRACES_NUM_MAX
                    if bifurcation_type == BifurcationTypesExtended.EXTINCT:
                        numTraces = IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS
                    for index in range(numTraces):
                        self.temporal_frame[branch_type][parameter_type][bifurcation_type][index] = []
        # init hopf bifurcations
        for branch_type in BranchTypes:
            self.hopf_bifurcations[branch_type] = {}
            for parameter_type in ParameterTypes:
                self.hopf_bifurcations[branch_type][parameter_type] = {}
                for trace in range(IntegerNumbers.TRACES_NUM_MAX):
                    self.hopf_bifurcations[branch_type][parameter_type][trace] = {
                        BifurcationTypesExtended.HOPF_SUBCRITICAL: [None] * IntegerNumbers.MAX_FIXED_PARAMETERS,
                        BifurcationTypesExtended.HOPF_SUPERCRITICAL: [None] * IntegerNumbers.MAX_FIXED_PARAMETERS,
                    }

    def _calculate_bauting_points(self) -> None:

        for branch_type in BranchTypes:
            for parameter_type in ParameterTypes:
                for trace, trace_data in self.hopf_bifurcations[branch_type][parameter_type].items():
                    # declare variables to save last seen bifurcation type and point (to detect transitions)
                    last_seen_type = None
                    # iterate over all fixed parameters
                    for i in range(IntegerNumbers.MAX_FIXED_PARAMETERS):
                        # get both hopf traces
                        subcritical_trace = trace_data[BifurcationTypesExtended.HOPF_SUBCRITICAL][i]
                        supercritical_trace = trace_data[BifurcationTypesExtended.HOPF_SUPERCRITICAL][i]
                        # check if we found a point subcritical in this step
                        if subcritical_trace is not None:
                            # check if we come from a supercritical
                            if last_seen_type == BifurcationTypesExtended.HOPF_SUPERCRITICAL:
                                # bauting point found.
                                bautin_pt = {
                                    # parameters
                                    ParameterTypes.DONOR.value: subcritical_trace[ParameterTypes.DONOR.value],
                                    ParameterTypes.RECIPIENT.value: subcritical_trace[ParameterTypes.RECIPIENT.value],
                                    ParameterTypes.LOTKAVOLTERRA.value: subcritical_trace[ParameterTypes.LOTKAVOLTERRA.value],
                                    # index
                                    "fixed_value": subcritical_trace["fixed_value"],
                                    # hopf bifurcation specific parameters
                                    HopfParameterTypes.L1.value: subcritical_trace[HopfParameterTypes.L1.value],
                                    HopfParameterTypes.OSCILLATION_FREQUENCY.value: subcritical_trace[HopfParameterTypes.OSCILLATION_FREQUENCY.value],
                                    HopfParameterTypes.TRANSVERSAL_CROSSING_SPEED.value: subcritical_trace[
                                        HopfParameterTypes.TRANSVERSAL_CROSSING_SPEED.value
                                    ],
                                    HopfParameterTypes.NORMALIZATION_ERROR.value: subcritical_trace[HopfParameterTypes.NORMALIZATION_ERROR.value],
                                }
                                # save in temporal frame
                                self.temporal_frame[branch_type][parameter_type][BifurcationTypesExtended.HOPF_BAUTIN][trace].append(bautin_pt)
                                # update last seen type and point
                            last_seen_type = BifurcationTypesExtended.HOPF_SUBCRITICAL
                        # check if we found a point supercritical in this step
                        if supercritical_trace is not None:
                            # check if we come from a subcritical
                            if last_seen_type == BifurcationTypesExtended.HOPF_SUBCRITICAL:
                                # bauting point found.
                                bautin_pt = {
                                    # parameters
                                    ParameterTypes.DONOR.value: supercritical_trace[ParameterTypes.DONOR.value],
                                    ParameterTypes.RECIPIENT.value: supercritical_trace[ParameterTypes.RECIPIENT.value],
                                    ParameterTypes.LOTKAVOLTERRA.value: supercritical_trace[ParameterTypes.LOTKAVOLTERRA.value],
                                    # index
                                    "fixed_value": supercritical_trace["fixed_value"],
                                    # hopf bifurcation specific parameters
                                    HopfParameterTypes.L1.value: supercritical_trace[HopfParameterTypes.L1.value],
                                    HopfParameterTypes.OSCILLATION_FREQUENCY.value: supercritical_trace[
                                        HopfParameterTypes.OSCILLATION_FREQUENCY.value
                                    ],
                                    HopfParameterTypes.TRANSVERSAL_CROSSING_SPEED.value: supercritical_trace[
                                        HopfParameterTypes.TRANSVERSAL_CROSSING_SPEED.value
                                    ],
                                    HopfParameterTypes.NORMALIZATION_ERROR.value: supercritical_trace[HopfParameterTypes.NORMALIZATION_ERROR.value],
                                }
                                # save in temporal frame
                                self.temporal_frame[branch_type][parameter_type][BifurcationTypesExtended.HOPF_BAUTIN][trace].append(bautin_pt)
                            # update last seen type and point
                            last_seen_type = BifurcationTypesExtended.HOPF_SUPERCRITICAL
