import os
import shutil
import threading
import zipfile

import pandas as pd

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.data.branch_data import BranchData
from food_web_bifurcation_explorer.data.ternary_data import TernaryData
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers
from food_web_bifurcation_explorer.enums.types.area_types import AreaTypes
from food_web_bifurcation_explorer.enums.types.bifurcation_types_extended import BifurcationTypesExtended
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes


class PlotData:
    """Class to manage and store plot data for bifurcation and branch analysis."""

    def __init__(self) -> None:
        """Initialize PlotData with default values for all data structures."""
        # loading lock
        self.data_load_lock = threading.RLock()
        # ternary data
        self.ternary_data: TernaryData = TernaryData()
        # branch datas
        self.branch_datas: dict[ParameterTypes, dict[BranchTypes, BranchData]] = {}
        # create elements for every branch data
        for parameter_type in ParameterTypes:
            self.branch_datas[parameter_type] = {}
            for branch_type in BranchTypes:
                self.branch_datas[parameter_type][branch_type] = BranchData(branch_type, parameter_type)
        # load data
        self.load_ternary_data()
        self.load_branch_datas()

    def get_num_compartments(self) -> int:
        """Get the number of compartments from food_web_bifurcation_explorer.empirical donor branch data."""
        return self.branch_datas[ParameterTypes.DONOR][BranchTypes.EMPIRICAL].n

    def load_ternary_data(self) -> None:
        """Load ternary data from food_web_bifurcation_explorer.cached files or generate from food_web_bifurcation_explorer.bifurcation data."""
        # lock load branch datas to avoid problems creating branch files
        with self.data_load_lock:
            # declare zip file path for ternary data
            data_ternary_zip_file = glob.files.get_data_ternary_zip_file()
            # check if we have cached files
            if os.path.exists(data_ternary_zip_file):
                # open zip file
                with zipfile.ZipFile(data_ternary_zip_file, "r") as ternary_zip_file:
                    # load ternary data from cache
                    self.ternary_data.load_parquet_data(ternary_zip_file)
            else:
                # read continuation files
                self.ternary_data.read_continuation_files()
                # check if create cache file
                if not os.path.exists(glob.files.get_data_folder()):
                    os.makedirs(glob.files.get_data_folder())
                # check if create network folder
                if not os.path.exists(glob.files.get_data_network_folder()):
                    os.makedirs(glob.files.get_data_network_folder())
                # create temporary directory for parquet files
                temporal_dir = os.path.join(glob.files.get_data_folder(), "temp_parquet_ternary")
                os.makedirs(temporal_dir, exist_ok=True)
                # list to store temporary file paths
                temporal_files = []
                # iterate over parameter types and branch types to read all branch data combinations
                for branch_type in BranchTypes:
                    for parameter_type in ParameterTypes:
                        for bifurcation_type in BifurcationTypesExtended:
                            # get num of traces
                            numTraces = IntegerNumbers.TRACES_NUM_MAX
                            if bifurcation_type == BifurcationTypesExtended.EXTINCT:
                                numTraces = IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS
                            for index in range(numTraces):
                                # first ensure that we have a dataframe
                                if self.ternary_data.ternary_dataframe[branch_type][parameter_type][bifurcation_type][index] is not None:
                                    # get parquet file
                                    ternary_parquet_file = glob.files.get_ternary_parquet_file(branch_type, parameter_type, bifurcation_type, index)
                                    # create temporary file paths
                                    ternary_temporal_path = os.path.join(temporal_dir, ternary_parquet_file)
                                    # save branch dataframe to temporary file
                                    self.ternary_data.ternary_dataframe[branch_type][parameter_type][bifurcation_type][index].to_parquet(
                                        ternary_temporal_path
                                    )
                                    # add to temporal files
                                    temporal_files.append((ternary_temporal_path, ternary_parquet_file))
                # also save shape file
                for area_type in AreaTypes:
                    # get perimeter parquet file
                    perimeter_parquet_file = glob.files.get_ternary_shape_file(area_type)
                    # create temporary file paths
                    ternary_temporal_path = os.path.join(temporal_dir, perimeter_parquet_file)
                    # save parquet file
                    self.ternary_data.shape_data.perimeters[area_type].to_parquet(os.path.join(temporal_dir, perimeter_parquet_file))
                    # add to temporal files
                    temporal_files.append((os.path.join(temporal_dir, perimeter_parquet_file), perimeter_parquet_file))
                # create zip file with all parquet files
                with zipfile.ZipFile(data_ternary_zip_file, "w", compression=zipfile.ZIP_DEFLATED) as data_zip_file:
                    for temporal_path, archive_name in temporal_files:
                        data_zip_file.write(temporal_path, archive_name)
                # remove temporary directory
                shutil.rmtree(temporal_dir)

    def load_branch_datas(self, precache: bool = True) -> None:
        """Load branch data from cached files or read from zip files."""
        # lock load branch datas to avoid problems creating branch files
        with self.data_load_lock:
            # first reset all branch datas
            for parameter_type in ParameterTypes:
                for branch_type in BranchTypes:
                    self.branch_datas[parameter_type][branch_type].clear_data()
                    # set global fixed parameter value
                    self.branch_datas[parameter_type][branch_type].fixed_parameter_value = glob.config.fixed_parameter_value_str
            # get zip file in wich have to be stored the branch data for the current fixed parameter value
            branch_zip_file_path = glob.files.get_data_branch_zip_file(glob.config.fixed_parameter_value_str)
            # check if zip file exists
            if os.path.exists(branch_zip_file_path):
                # open zip file
                with zipfile.ZipFile(branch_zip_file_path, "r") as branch_zip_file:
                    for parameter_type in ParameterTypes:
                        for branch_type in BranchTypes:
                            # load branch parquet file from zip
                            parquet_file = glob.files.get_branch_parquet_file(parameter_type, branch_type, glob.config.fixed_parameter_value_str)
                            with branch_zip_file.open(parquet_file) as f:
                                self.branch_datas[parameter_type][branch_type].branch_dataframe = pd.read_parquet(f)
                            # load bifurcation parquet file from zip
                            parquet_file = glob.files.get_bifurcation_parquet_file(parameter_type, branch_type, glob.config.fixed_parameter_value_str)
                            with branch_zip_file.open(parquet_file) as f:
                                self.branch_datas[parameter_type][branch_type].bifurcations_dataframe = pd.read_parquet(f)
                            # process data
                            self.branch_datas[parameter_type][branch_type].process_data()
            elif precache:
                # precache all branch data
                print("Precaching branch data...")
                # check if create cache folders
                if not os.path.exists(glob.files.get_data_folder()):
                    os.makedirs(glob.files.get_data_folder())
                if not os.path.exists(glob.files.get_data_network_folder()):
                    os.makedirs(glob.files.get_data_network_folder())
                # continue depending if we want to precache all traces
                if glob.static_options.PRECACHE_ALL_TRACES:
                    fixed_parameter_values = glob.config.fixed_parameter_values_str
                else:
                    fixed_parameter_values = [glob.config.fixed_parameter_value_str]
                # iterate over every fixed parameter value
                for fixed_parameter_value in fixed_parameter_values:
                    # show info
                    print(fixed_parameter_value)
                    # get both zip file
                    continuation_zip_file_path = glob.files.get_continuation_zip_file(fixed_parameter_value)
                    data_zip_file_path = glob.files.get_data_branch_zip_file(fixed_parameter_value)
                    # check if file exist
                    if os.path.exists(continuation_zip_file_path):
                        # open zip file
                        with zipfile.ZipFile(continuation_zip_file_path, "r") as continuation_zip_file:
                            # create temporary directory for parquet files
                            temporal_dir = os.path.join(glob.files.get_data_folder(), "temp_parquet_branch")
                            os.makedirs(temporal_dir, exist_ok=True)
                            # list to store temporary file paths
                            temporal_files = []
                            # iterate over parameter types and branch types to read all branch data combinations
                            for parameter_type in ParameterTypes:
                                for branch_type in BranchTypes:
                                    # read branch data
                                    self.branch_datas[parameter_type][branch_type].read_branch_data(
                                        continuation_zip_file, parameter_type, fixed_parameter_value
                                    )
                                    # get file names
                                    branch_parquet_file = glob.files.get_branch_parquet_file(parameter_type, branch_type, fixed_parameter_value)
                                    bifurcation_parquet_file = glob.files.get_bifurcation_parquet_file(
                                        parameter_type, branch_type, fixed_parameter_value
                                    )
                                    # create temporary file paths
                                    branch_temporal_path = os.path.join(temporal_dir, branch_parquet_file)
                                    bifurcation_temporal_path = os.path.join(temporal_dir, bifurcation_parquet_file)
                                    # save branch dataframe to temporary file
                                    self.branch_datas[parameter_type][branch_type].branch_dataframe.to_parquet(branch_temporal_path)
                                    temporal_files.append((branch_temporal_path, branch_parquet_file))
                                    # save bifurcation dataframe to temporary file
                                    self.branch_datas[parameter_type][branch_type].bifurcations_dataframe.to_parquet(bifurcation_temporal_path)
                                    temporal_files.append((bifurcation_temporal_path, bifurcation_parquet_file))
                            # create zip file with all parquet files
                            with zipfile.ZipFile(data_zip_file_path, "w", compression=zipfile.ZIP_DEFLATED) as data_zip_file:
                                for temporal_path, archive_name in temporal_files:
                                    data_zip_file.write(temporal_path, archive_name)
                            # remove temporary directory
                            shutil.rmtree(temporal_dir)
                # finally call again this function to load the desired fixed parameter value
                self.load_branch_datas(False)
