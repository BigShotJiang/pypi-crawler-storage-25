from enum import Enum, unique

from food_web_bifurcation_explorer.enums.types.bifurcation_types import BifurcationTypes


@unique
class BifurcationTypesExtended(str, Enum):
    """Enumeration for bifurcation types."""

    # bifurcations
    SADDLENODE = BifurcationTypes.SADDLENODE.value
    TRANSCRITICAL = BifurcationTypes.TRANSCRITICAL.value
    HOPF_SUBCRITICAL = BifurcationTypes.HOPF_SUBCRITICAL.value
    HOPF_SUPERCRITICAL = BifurcationTypes.HOPF_SUPERCRITICAL.value
    HOPF_BAUTIN = BifurcationTypes.HOPF_BAUTIN.value
    # other
    FRONTIER = "frontier"
    INTERNAL_ERROR = "outOfParameters"
    EXTINCT = "extinction"
