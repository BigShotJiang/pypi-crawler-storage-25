from enum import Enum, unique


@unique
class Labels(str, Enum):
    """Enumeration for frontend element labels."""

    # parameters
    DONOR_CONTROL = "Donor control"
    RECIPIENT_CONTROL = "Recipient control"
    LOTKAVOLTERRA_CONTROL = "Lotka-Volterra control"
    # alias
    DONOR_ALIAS = "<i>s</i><sub>d</sub>"
    RECIPIENT_ALIAS = "<i>s</i><sub>r</sub>"
    LOTKAVOLTERRA_ALIAS = "<i>s</i><sub>l</sub>"
    # strength
    DONOR_CONTROL_STRENGTH = DONOR_CONTROL + " strength " + DONOR_ALIAS
    RECIPIENT_CONTROL_STRENGTH = RECIPIENT_CONTROL + " strength " + RECIPIENT_ALIAS
    LOTKAVOLTERRA_CONTROL_STRENGTH = LOTKAVOLTERRA_CONTROL + " strength " + LOTKAVOLTERRA_ALIAS
    # equilibria
    ALTERNATIVE_EQUILIBRIA = "Alternative equilibria"
    ALTERNATIVE_BRANCH = "Alternative branch"
    UNSTABLE_EQUILIBRIA = "Unstable equilibria"
    # biomass
    BIOMASS_COMPARTMENT_FIRST = "First biomass compartment"
    BIOMASS_COMPARTMENT_SECOND = "Second biomass compartment"
    BIOMASS_UNIT = "mg/m<sup>2</sup>"
    # hopf parameters
    PARAMETERS_RANGE = "Lotka-Volterra parameters"
    L1 = "first Lyapunov coefficient <i>l</i><sub>1</sub>"
    L1_UNIT = "s<sup>-1</sup>"
    OSCILLATION_FREQUENCY = "oscillation frequency <i>ω</i>"
    OSCILLATION_FREQUENCY_UNIT = "rad/s"
    TRANSVERSAL_CROSSING_SPEED = "transversal crossing speed <i>λ</i>'"
    TRANSVERSAL_CROSSING_SPEED_UNIT = "s<sup>-1</sup> · μ<sup>-1</sup>"
    NORMALIZATION_ERROR = "normalization error <i>n</i>"
    NORMALIZATION_ERROR_UNIT = "adimensional"
    # others
    BIFURCATION_DISTRIBUTION = "Bifurcation distribution"
    BIFURCATION_DISTRIBUTION_NUM_BINS = "Distribution bins"
    BIFURCATION_DISTRIBUTIONS_NUM_CONTOURS = "Distribution contours"
    BIFURCATION_DISTRIBUTIONS_USE_CONTOURS = "Show contours"
    BIFURCATION_DISTRIBUTIONS_DESIGN = "Bifurcation distribution design"
    DRAW_LINES = "Draw lines"
    DRAW_POINTS = "Draw points"
    DRAWING_OPTIONS = "Drawing options"
    EIGENVALUE_SPECTRUM = "Eigenvalue Spectrum"
    EIGENVALUE_SPECTRUM_CENTERED = "Draw centered around 0"
    EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE = "Eigenvalue spectrum for alternative branch"
    EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL = "Eigenvalue spectrum for empirical branch"
    EMPIRICAL_BRANCH = "Empirical branch"
    EMPIRICAL_EQUILIBRIA = "Empirical equilibria"
    EQUILIBRIA = "Equilibria"
    EXTINCT = "Extinct"
    FIXED_PARAMETER_TYPE = "Fixed parameter"
    FIXED_PARAMETER_VALUE = "Fixed parameter value [0,1]"
    HEATMAP_TERNARY = "Heatmap ternary"
    HOPF_BAUTIN_BIFURCATIONS = "Bautin bifurcations"
    HOPF_ENVELOPES = "Hopf envelopes"
    HOPF_SUBCRITICAL_BIFURCATIONS = "Hopf subcritical bifurcations"
    HOPF_SUPERCRITICAL_BIFURCATIONS = "Hopf supercritical bifurcations"
    INTERNAL_ERROR = "Internal error"
    LOGARITHMIC_SCALE = "Logarithmic scale"
    MAIN_TITLE = "Food-web Bifurcation Explorer"
    MIN_COUNT_CONSIDERED = "Minimum count considered"
    NETWORK_SELECTOR = "Network"
    OTHERS = "Others"
    OVER_INFORMATION = "Show over information"
    SADDLENODE_BIFURCATIONS = "Saddle-node bifurcations"
    STABILITY_AREA = "Stability area"
    STABLE_EQUILIBRIA = "Stable equilibria"
    TRANSCRITICAL_BIFURCATIONS = "Transcritical bifurcations"
    ZOOM_LEVEL = "Zoom level"
