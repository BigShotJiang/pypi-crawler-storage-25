from food_web_bifurcation_explorer.enums.colors.diverse_colors import DiverseColors
from food_web_bifurcation_explorer.enums.font import Font
from food_web_bifurcation_explorer.enums.resolutions.layout_resolutions import LayoutResolutions


class Styles:
    """class for group for frontend style configurations."""

    # Style for the main header (H1)
    MAIN_TITLE = {
        "width": f"{LayoutResolutions.DEFAULT.value * 10}px",
        "textAlign": "center",
        "WebkitTextSizeAdjust": "none",
        "textSizeAdjust": "none",
        "fontFamily": Font.FONT.value,
        "fontSize": Font.SIZE_TITLE,
    }
    # Style for containers with large Dropdowns (Network, Parameters)
    GROUP_DROPDOWN = {
        "display": "flex",
        "flexDirection": "column",  # arrange items vertically one below the other (typical for side menus)
        "flexShrink": 0,  # prevent container from food_web_bifurcation_explorer.shrinking (forces scroll)
        "gap": "0px",  # controls EXACT space between elements (vertical or horizontal)
        "justifyContent": "flex-start",  # align items to the start
        "margin": "0 0 0 5px",  # margin around the container
        "maxWidth": "210px",  # max width to prevent excessive stretching
        "minWidth": "210px",  # min width to prevent squeezing
        "fontFamily": Font.FONT.value,
        "fontSize": Font.SIZE.value,
    }
    # Style for containers with eigenvaluesSpectrum
    GROUP_EIGENVALUES = {
        "display": "flex",
        "flexDirection": "column",  # arrange items vertically one below the other (typical for side menus)
        "flexShrink": 0,  # prevent container from food_web_bifurcation_explorer.shrinking (forces scroll)
        "gap": "0px",  # controls EXACT space between elements (vertical or horizontal)
        "justifyContent": "flex-start",  # align items to the start
        "margin": "0 0 0 5px",  # margin around the container
        "maxWidth": "350px",  # max width to prevent excessive stretching
        "minWidth": "350px",  # min width to prevent squeezing
        "fontFamily": Font.FONT.value,
        "fontSize": Font.SIZE.value,
    }
    # Style for containers with eigenvaluesSpectrum
    SUBGROUP_EIGENVALUES = {
        "display": "flex",
        "flexDirection": "row",  # arrange items horizontally side by side
        "flexShrink": 0,  # prevent container from food_web_bifurcation_explorer.shrinking (forces scroll)
        "gap": "0px",  # controls EXACT space between elements (vertical or horizontal)
        "justifyContent": "flex-start",  # align items to the start
        "margin": "0 0 0 0",  # margin around the container
        "maxWidth": "350px",  # max width to prevent excessive stretching
        "minWidth": "350px",  # min width to prevent squeezing
        "fontFamily": Font.FONT.value,
        "fontSize": Font.SIZE.value,
    }
    # Style for containers with Checkboxes (Branches, Bifurcations, etc.)
    GROUP_CHECKBOX = {
        "margin": "0 0 0 10px",  # margin around the container
        "display": "flex",
        "flexDirection": "column",  # arrange items vertically one below the other (typical for side menus)
        "flexShrink": 0,  # prevent container from food_web_bifurcation_explorer.shrinking (forces scroll)
        "gap": "0px",  # controls EXACT space between elements (vertical or horizontal)
        "justifyContent": "flex-start",  # align items to the start
        "maxWidth": "210px",  # max width to prevent excessive stretching
        "minWidth": "50px",  # min width to prevent squeezing
        "fontFamily": Font.FONT.value,
        "fontSize": Font.SIZE.value,
    }
    # style for control wrapper
    DIV_CONTROL = {
        "width": f"{LayoutResolutions.DEFAULT.value * 10}px",
        "alignItems": "flex-start",  # aligns items to the top edge
        "backgroundColor": DiverseColors.DIV_CONTROL.value,  # light gray background color
        "borderBottom": "2px solid #ddd",  # bottom border separator line
        "borderTop": "2px solid #ddd",  # top border separator line
        "boxSizing": "border-box",  # ensures padding is included in total width
        "display": "flex",  # enables flexbox layout
        "flexDirection": "row",  # arranges items horizontally
        "flexWrap": "nowrap",  # prevents items from food_web_bifurcation_explorer.wrapping (critical for scroll)
        "justifyContent": "left",  # aligns items to the left start
        "padding": "0",  # force zero padding
        "fontFamily": Font.FONT.value,
        "fontSize": Font.SIZE.value,
    }
    # style for ternary
    TERNARY = {
        "width": "100%",
        "height": "100%",
        "marginTop": "-10%",
        "transform": "scale(1.2)",
        "transformOrigin": "center center",
    }
    # style for plots
    PLOT = {
        "width": "100%",
        "height": "100%",
    }
    # style for ternary graph divisor
    DIV_GRAPH_SCATTER_TERNARY = {
        "width": f"{LayoutResolutions.DEFAULT.value * 2}px",
        "height": f"{LayoutResolutions.DEFAULT.value * 2}px",
        "backgroundColor": "white",  # neutral background for visibility
        "flexShrink": 0,  # prevent the graph from food_web_bifurcation_explorer.shrinking in flex containers
        "margin": "0",  # force zero margin
        "overflow": "hidden",  # clip any content that exceeds the fixed dimensions
        "padding": "0",  # force zero padding
        "fontFamily": Font.FONT.value,
        "fontSize": Font.SIZE.value,
    }
    # style for ternary graph divisor
    DIV_GRAPH_HEATMAP_TERNARY = {
        "width": f"{(LayoutResolutions.DEFAULT.value * 2) + (LayoutResolutions.DEFAULT.value * 0.2)}px",
        "height": f"{LayoutResolutions.DEFAULT.value * 2}px",
        "backgroundColor": "white",  # neutral background for visibility
        "flexShrink": 0,  # prevent the graph from food_web_bifurcation_explorer.shrinking in flex containers
        "margin": "0",  # force zero margin
        "overflow": "hidden",  # clip any content that exceeds the fixed dimensions
        "padding": "0",  # force zero padding
        "fontFamily": Font.FONT.value,
        "fontSize": Font.SIZE.value,
    }
    # style for ternary graph divisor
    DIV_GRAPH_SCATTER_PLOT = {
        "width": f"{LayoutResolutions.DEFAULT.value * 2}px",
        "height": f"{LayoutResolutions.DEFAULT.value}px",
        "backgroundColor": "white",  # neutral background for visibility
        "flexShrink": 0,  # prevent the graph from food_web_bifurcation_explorer.shrinking in flex containers
        "margin": "0",  # force zero margin
        "overflow": "hidden",  # clip any content that exceeds the fixed dimensions
        "padding": "0",  # force zero padding
        "fontFamily": Font.FONT.value,
        "fontSize": Font.SIZE.value,
    }
    # style for ternary graph divisor
    DIV_GRAPH_DISTRIBUTION_PLOT = {
        "width": f"{LayoutResolutions.DEFAULT.value * 1.5}px",
        "height": f"{LayoutResolutions.DEFAULT.value * 1.5}px",
        "backgroundColor": "white",  # neutral background for visibility
        "flexShrink": 0,  # prevent the graph from food_web_bifurcation_explorer.shrinking in flex containers
        "margin": "0",  # force zero margin
        "overflow": "hidden",  # clip any content that exceeds the fixed dimensions
        "padding": "0",  # force zero padding
        "fontFamily": Font.FONT.value,
        "fontSize": Font.SIZE.value,
    }
    # style for main graph divisor container
    DIV_GRAPHS = {
        "width": f"{LayoutResolutions.DEFAULT.value * 4}px",
        "height": f"{LayoutResolutions.DEFAULT.value * 2}px",
        "alignItems": "flex-start",
        "backgroundColor": "white",
        "display": "flex",
        "flexDirection": "row",
        "flexWrap": "nowrap",
        "gap": "0",
        "justifyContent": "flex-start",
        "margin": "0",
        "padding": "0",
    }
    # four panels divisor
    DIV_FOUR_PLOTS = {
        "width": f"{LayoutResolutions.DEFAULT.value * 2}px",
        "height": f"{LayoutResolutions.DEFAULT.value * 4}px",
        "alignItems": "flex-start",
        "display": "flex",
        "flexDirection": "column",
        "gap": "0",
        "justifyContent": "flex-start",
        "margin": "0",
        "padding": "0",
    }
    # row divisor
    DIV_SMALL_ROW = {
        "width": f"{LayoutResolutions.DEFAULT.value * 4}px",
        "height": f"{LayoutResolutions.DEFAULT.value}px",
        "alignItems": "flex-start",
        "display": "flex",
        "flexDirection": "row",
        "gap": "0",
        "justifyContent": "flex-start",
        "margin": "0",
        "padding": "0",
    }
    # style for checkbox label
    CHECKBOXLABEL = {
        "alignItems": "center",  # vertically center align items
        "display": "inline-flex",  # inline flex display
        "height": "2px",  # minimal height
        "fontFamily": Font.FONT.value,
        "fontSize": Font.SIZE.value,
    }
    # style for standard label
    LABEL = {
        "alignItems": "center",  # vertically center align items
        "display": "flex",  # flex display
        "height": "32px",  # standard height for labels
        "fontFamily": Font.FONT.value,
        "fontSize": Font.SIZE.value,
    }
