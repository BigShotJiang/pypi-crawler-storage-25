from enum import Enum


class IntegerNumbers(int, Enum):
    """Enumeration for integer number parameters used in the application."""

    MAX_FIXED_PARAMETERS = 1001
    # traces
    TRACES_NUM_MAX = 20
    TRACES_NUM_MAX_EXTINCTIONS = 130  # correspond to the network with the maximum number of compartments
    # eigenvalue spectrum
    EIGENVALUE_SPECTRUM_MIN = 0
    EIGENVALUE_SPECTRUM_MAX = 2000
    EIGENVALUE_SPECTRUM_STEP = 1
    # heatmap
    HEATMAP_MAX_VALUE = 20
    HEATMAP_MIN_VALUE = 1
    HEATMAP_MIN_VALUE_STEP = 1
    # bifurcation distributions
    BIFURCATION_DISTRIBUTIONS_BINS_DEFAULT = 51
    BIFURCATION_DISTRIBUTIONS_BINS_MIN = 11
    BIFURCATION_DISTRIBUTIONS_BINS_STEPS = 10
    BIFURCATION_DISTRIBUTIONS_CONTOURS_DEFAULT = 10
    BIFURCATION_DISTRIBUTIONS_CONTOURS_MIN = 1
    BIFURCATION_DISTRIBUTIONS_CONTOURS_STEPS = 1
