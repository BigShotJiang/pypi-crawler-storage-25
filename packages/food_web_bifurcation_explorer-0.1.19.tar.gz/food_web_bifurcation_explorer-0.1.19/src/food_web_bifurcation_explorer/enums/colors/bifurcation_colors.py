from enum import Enum, unique


@unique
class BifurcationColors(str, Enum):
    """Enumeration for bifurcation colors used in graphs."""

    # bifurcations
    SADDLENODE_EMPIRICAL = "yellow"
    SADDLENODE_ALTERNATIVE = "gold"
    TRANSCRITICAL_EMPIRICAL = "orange"
    TRANSCRITICAL_ALTERNATIVE = "darkorange"
    HOPF_SUBCRITICAL_EMPIRICAL = "lightgreen"
    HOPF_SUBCRITICAL_ALTERNATIVE = "mediumseagreen"
    HOPF_SUPERCRITICAL_EMPIRICAL = "limegreen"
    HOPF_SUPERCRITICAL_ALTERNATIVE = "forestgreen"
    HOPF_BAUTIN_EMPIRICAL = "springgreen"
    HOPF_BAUTIN_ALTERNATIVE = "seagreen"
    HOPF_ENVELOPE_EMPIRICAL = "greenyellow"
    HOPF_ENVELOPE_ALTERNATIVE = "olivedrab"
    # other
    EXTINCT = "black"
    INTERNAL_ERROR = "magenta"
    EIGENVALUE_SPECTRUM_INDEX = "green"
