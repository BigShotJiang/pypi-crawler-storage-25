from enum import Enum, unique

from food_web_bifurcation_explorer.common.decorators import exact_values
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers


@unique
@exact_values(IntegerNumbers.HEATMAP_MAX_VALUE)
class HeatmapWhiteRedColors(str, Enum):
    """Enumeration for heatmap colors"""

    color_00 = "#FFF5F5"
    color_01 = "#FFEBEB"
    color_02 = "#FFE0E0"
    color_03 = "#FFD6D6"
    color_04 = "#FFCCCC"
    color_05 = "#FFC2C2"
    color_06 = "#FFB8B8"
    color_07 = "#FFADAD"
    color_08 = "#FF9E9E"
    color_09 = "#FF8F8F"
    color_10 = "#FF8080"
    color_11 = "#FF7070"
    color_12 = "#FF6060"
    color_13 = "#FF5050"
    color_14 = "#FF4040"
    color_15 = "#FF3030"
    color_16 = "#FF2020"
    color_17 = "#FF1010"
    color_18 = "#FF0000"
    color_19 = "#CC0000"
