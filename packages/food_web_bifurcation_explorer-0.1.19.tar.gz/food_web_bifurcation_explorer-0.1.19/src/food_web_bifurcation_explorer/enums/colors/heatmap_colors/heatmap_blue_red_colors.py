from enum import Enum, unique

from food_web_bifurcation_explorer.common.decorators import exact_values
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers


@unique
@exact_values(IntegerNumbers.HEATMAP_MAX_VALUE)
class HeatmapBlueRedColors(str, Enum):
    """Enumeration for divergent heatmap colors (blue to red via purple/magenta)"""

    color_00 = "#0000CC"
    color_01 = "#1A00DD"
    color_02 = "#3300EE"
    color_03 = "#5500EE"
    color_04 = "#7700DD"
    color_05 = "#9900CC"
    color_06 = "#BB00BB"
    color_07 = "#CC00AA"
    color_08 = "#DD0088"
    color_09 = "#EE0066"
    color_10 = "#EE0044"
    color_11 = "#EE0033"
    color_12 = "#EE1122"
    color_13 = "#EE2211"
    color_14 = "#EE3300"
    color_15 = "#EE4400"
    color_16 = "#DD3300"
    color_17 = "#CC2200"
    color_18 = "#BB1100"
    color_19 = "#AA0000"
