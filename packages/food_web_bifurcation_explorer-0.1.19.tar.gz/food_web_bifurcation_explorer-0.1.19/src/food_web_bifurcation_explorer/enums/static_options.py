class StaticOptions:
    DEBUG: bool = False
    PRECACHE_ALL_TRACES: bool = False
    GENERATE_GENERAL_BIFURCATION_DATA: bool = True
    # default values
    DEFAULT_NETWORK: str = "Baja_California_417"
    DEFAULT_COMPARTMENT_FIRST: int = 0
    DEFAULT_COMPARTMENT_FIRST_STR: str = "0"
    DEFAULT_COMPARTMENT_SECOND: int = 1
    DEFAULT_COMPARTMENT_SECOND_STR: str = "1"
    DEFAULT_PARAMETER_VALUE: float = 0.4
