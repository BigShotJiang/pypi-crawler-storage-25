import webbrowser
from threading import Timer

from food_web_bifurcation_explorer.callbacks import *
from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.static_options import StaticOptions
from food_web_bifurcation_explorer.frontend.layout import html_layout


class FoodWebBifurcationExplorer:
    """Main class for running the Bifurcation Explorer application."""

    def __init__(self, host: str = "127.0.0.1", port: int = 8050, open_browser: bool = True):
        glob.app.layout = html_layout
        # check if open browser before running the app
        if open_browser:
            url = f"http://{host}:{port}/"
            Timer(1, lambda: webbrowser.open_new(url)).start()
        # run the app
        glob.app.run(host=host, port=port, debug=StaticOptions.DEBUG)
