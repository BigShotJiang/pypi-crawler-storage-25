from dash import dcc, html

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.enums.types.bifurcation_distribution_types import BifurcationDistributionTypes
from food_web_bifurcation_explorer.enums.types.hopf_parameter_types import HopfParameterTypes
from food_web_bifurcation_explorer.frontend.distribution_module import bifurcation_distribution_logarithmic
from food_web_bifurcation_explorer.frontend.distribution_module.bifurcation_distribution import (
    bifurcation_distribution_num_bins,
    bifurcation_distribution_num_contours,
    bifurcation_distribution_use_contours,
)
from food_web_bifurcation_explorer.frontend.distribution_module.bifurcations.hopf.bautin import (
    bautin_alternative_distribution,
    bautin_empirical_distribution,
)
from food_web_bifurcation_explorer.frontend.distribution_module.bifurcations.hopf.subcritical import (
    subcritical_alternative_distribution,
    subcritical_empirical_distribution,
)
from food_web_bifurcation_explorer.frontend.distribution_module.bifurcations.hopf.supercritical import (
    supercritical_alternative_distribution,
    supercritical_empirical_distribution,
)
from food_web_bifurcation_explorer.frontend.distribution_module.bifurcations.saddlenode import (
    saddlenode_alternative_distribution,
    saddlenode_empirical_distribution,
)
from food_web_bifurcation_explorer.frontend.distribution_module.bifurcations.transcritical import (
    transcritical_alternative_distribution,
    transcritical_empirical_distribution,
)
from food_web_bifurcation_explorer.frontend.heatmap_module import heatmap_logarithmic, min_heatmap_value
from food_web_bifurcation_explorer.frontend.heatmap_module.bifurcations.hopf.bautin import bautin_alternative_heatmap, bautin_empirical_heatmap
from food_web_bifurcation_explorer.frontend.heatmap_module.bifurcations.hopf.subcritical import (
    subcritical_alternative_heatmap,
    subcritical_empirical_heatmap,
)
from food_web_bifurcation_explorer.frontend.heatmap_module.bifurcations.hopf.supercritical import (
    supercritical_alternative_heatmap,
    supercritical_empirical_heatmap,
)
from food_web_bifurcation_explorer.frontend.heatmap_module.bifurcations.saddlenode import saddlenode_alternative_heatmap, saddlenode_empirical_heatmap
from food_web_bifurcation_explorer.frontend.heatmap_module.bifurcations.transcritical import (
    transcritical_alternative_heatmap,
    transcritical_empirical_heatmap,
)
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.frontend.scatter_module.bifurcations.hopf.bautin import bautin_alternative_single, bautin_empirical_single
from food_web_bifurcation_explorer.frontend.scatter_module.bifurcations.hopf.envelope import envelope_alternative_single, envelope_empirical_single
from food_web_bifurcation_explorer.frontend.scatter_module.bifurcations.hopf.subcritical import (
    subcritical_alternative_single,
    subcritical_empirical_single,
)
from food_web_bifurcation_explorer.frontend.scatter_module.bifurcations.hopf.supercritical import (
    supercritical_alternative_single,
    supercritical_empirical_single,
)
from food_web_bifurcation_explorer.frontend.scatter_module.bifurcations.saddlenode import saddlenode_alternative_single, saddlenode_empirical_single
from food_web_bifurcation_explorer.frontend.scatter_module.bifurcations.transcritical import (
    transcritical_alternative_single,
    transcritical_empirical_single,
)
from food_web_bifurcation_explorer.frontend.scatter_module.biomass_compartment import biomass_compartment_first, biomass_compartment_second
from food_web_bifurcation_explorer.frontend.scatter_module.draw import branch_alternative, branch_empirical, lines, points
from food_web_bifurcation_explorer.frontend.scatter_module.eigenvalue_spectrum import (
    eigenvalue_spectrum_centered_alternative,
    eigenvalue_spectrum_centered_empirical,
    eigenvalue_spectrum_index_alternative,
    eigenvalue_spectrum_index_empirical,
)
from food_web_bifurcation_explorer.frontend.scatter_module.equilibria import area, over_information, stable, unstable
from food_web_bifurcation_explorer.frontend.scatter_module.general import network_selector, resolution_selector
from food_web_bifurcation_explorer.frontend.scatter_module.others import eigenvalue_spectrum_index, extinct, internal_error
from food_web_bifurcation_explorer.frontend.scatter_module.parameters import fixed_parameter_type, fixed_parameter_value

# html layout
html_layout = html.Div(
    [
        # title
        html.H1(Labels.MAIN_TITLE, style=Styles.MAIN_TITLE),
        # DIV_CONTROL scatter
        html.Div(
            [
                # Group 1
                html.Div(
                    [
                        html.Label(Labels.NETWORK_SELECTOR, style=Styles.LABEL),
                        network_selector.build(),
                        html.Label(Labels.ZOOM_LEVEL, style=Styles.LABEL),
                        resolution_selector.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 2
                html.Div(
                    [
                        html.Label(Labels.BIOMASS_COMPARTMENT_FIRST, style=Styles.LABEL),
                        biomass_compartment_first.build(),
                        html.Label(Labels.BIOMASS_COMPARTMENT_SECOND, style=Styles.LABEL),
                        biomass_compartment_second.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 3
                html.Div(
                    [
                        html.Label(Labels.FIXED_PARAMETER_TYPE, style=Styles.LABEL),
                        fixed_parameter_type.build(),
                        html.Label(Labels.FIXED_PARAMETER_VALUE, style=Styles.LABEL),
                        fixed_parameter_value.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 4: Equilibria
                html.Div(
                    [
                        html.Label(Labels.EQUILIBRIA, style=Styles.LABEL),
                        area.build(),
                        stable.build(),
                        unstable.build(),
                        over_information.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 5: saddlenode & transcritical bifurcations
                html.Div(
                    [
                        # saddle node bifurcations
                        html.Label(Labels.SADDLENODE_BIFURCATIONS, style=Styles.LABEL),
                        saddlenode_empirical_single.build(),
                        saddlenode_alternative_single.build(),
                        # transcritical bifurcations
                        html.Label(
                            Labels.TRANSCRITICAL_BIFURCATIONS,
                            style=Styles.LABEL,
                        ),
                        transcritical_empirical_single.build(),
                        transcritical_alternative_single.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 6: hopf bifurcations
                html.Div(
                    [
                        # hopf subcritical bifurcations
                        html.Label(Labels.HOPF_SUBCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        subcritical_empirical_single.build(),
                        subcritical_alternative_single.build(),
                        # hopf supercritical bifurcations
                        html.Label(Labels.HOPF_SUPERCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        supercritical_empirical_single.build(),
                        supercritical_alternative_single.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 7: bautin & envelope
                html.Div(
                    [
                        html.Label(Labels.HOPF_BAUTIN_BIFURCATIONS, style=Styles.LABEL),
                        bautin_empirical_single.build(),
                        bautin_alternative_single.build(),
                        html.Label(Labels.HOPF_ENVELOPES, style=Styles.LABEL),
                        envelope_empirical_single.build(),
                        envelope_alternative_single.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 8 : others
                html.Div(
                    [
                        html.Label(Labels.OTHERS, style=Styles.LABEL),
                        extinct.build(),
                        internal_error.build(),
                        eigenvalue_spectrum_index.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 9: Drawing Options
                html.Div(
                    [
                        html.Label(Labels.DRAWING_OPTIONS, style=Styles.LABEL),
                        branch_empirical.build(),
                        branch_alternative.build(),
                        lines.build(),
                        points.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 10: eigen value spectrum indices
                html.Div(
                    [
                        eigenvalue_spectrum_index_empirical.title(),
                        # subgroup 10: empirical
                        html.Div(
                            [
                                eigenvalue_spectrum_index_empirical.build(),
                                eigenvalue_spectrum_centered_empirical.build(),
                            ],
                            style=Styles.SUBGROUP_EIGENVALUES,
                        ),
                        eigenvalue_spectrum_index_alternative.title(),
                        # subgroup 10: alternative
                        html.Div(
                            [
                                eigenvalue_spectrum_index_alternative.build(),
                                eigenvalue_spectrum_centered_alternative.build(),
                            ],
                            style=Styles.SUBGROUP_EIGENVALUES,
                        ),
                    ],
                    style=Styles.GROUP_EIGENVALUES,
                ),
            ],
            style=Styles.DIV_CONTROL,
        ),
        # DIV_GRAPHS
        html.Div(
            [
                # ternary graph
                html.Div(
                    [
                        dcc.Graph(
                            id=IDs.FIGURE_SCATTER_TERNARY,
                            figure=glob.figures.ternary_scatter,
                            style=Styles.TERNARY,
                            config={"doubleClick": False, "scrollZoom": False, "responsive": True, "displayModeBar": False},
                        )
                    ],
                    id=IDs.DIV_SCATTER_TERNARY,
                    style=Styles.DIV_GRAPH_SCATTER_TERNARY,
                ),
                # DIV_RIGHT_PANEL
                html.Div(
                    [
                        # DIV_SMALL_ROW
                        html.Div(
                            [
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # bifurcation diagram A
                                        dcc.Graph(
                                            id=IDs.FIGURE_SCATTER_BIFURCATION_DIAGRAM_FIRST,
                                            figure=glob.figures.bifurcation_diagram_first,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_SCATTER_BIFURCATION_DIAGRAM_FIRST,
                                    style=Styles.DIV_GRAPH_SCATTER_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # eigenvalue_spectrum empirical
                                        dcc.Graph(
                                            id=IDs.FIGURE_SCATTER_EIGENVALUE_SPECTRUM_EMPIRICAL,
                                            figure=glob.figures.eigenvalue_spectrum_empirical,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_SCATTER_EIGENVALUE_SPECTRUM_EMPIRICAL,
                                    style=Styles.DIV_GRAPH_SCATTER_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # hopf parameter L1
                                        dcc.Graph(
                                            id=IDs.FIGURE_SCATTER_HOPF_PARAMETER_PLOT_L1,
                                            figure=glob.figures.hopf_parameters[HopfParameterTypes.L1],
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_SCATTER_HOPF_PARAMETER_PLOT_L1,
                                    style=Styles.DIV_GRAPH_SCATTER_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # hopf parameter transversal crossing speed
                                        dcc.Graph(
                                            id=IDs.FIGURE_SCATTER_HOPF_PARAMETER_PLOT_TRANSVERSAL_CROSSING_SPEED,
                                            figure=glob.figures.hopf_parameters[HopfParameterTypes.TRANSVERSAL_CROSSING_SPEED],
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_SCATTER_HOPF_PARAMETER_PLOT_TRANSVERSAL_CROSSING_SPEED,
                                    style=Styles.DIV_GRAPH_SCATTER_PLOT,
                                ),
                            ],
                            id=IDs.DIV_SCATTER_ROW_PLOTS_A,
                            style=Styles.DIV_SMALL_ROW,
                        ),
                        # DIV_SMALL_ROW
                        html.Div(
                            [
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # bifurcation diagram B
                                        dcc.Graph(
                                            id=IDs.FIGURE_SCATTER_BIFURCATION_DIAGRAM_SECOND,
                                            figure=glob.figures.bifurcation_diagram_second,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_SCATTER_BIFURCATION_DIAGRAM_SECOND,
                                    style=Styles.DIV_GRAPH_SCATTER_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # eigenvalue_spectrum alternative
                                        dcc.Graph(
                                            id=IDs.FIGURE_SCATTER_EIGENVALUE_SPECTRUM_ALTERNATIVE,
                                            figure=glob.figures.eigenvalue_spectrum_alternative,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_SCATTER_EIGENVALUE_SPECTRUM_ALTERNATIVE,
                                    style=Styles.DIV_GRAPH_SCATTER_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # hopf parameter frequency
                                        dcc.Graph(
                                            id=IDs.FIGURE_SCATTER_HOPF_PARAMETER_PLOT_OSCILLATION_FREQUENCY,
                                            figure=glob.figures.hopf_parameters[HopfParameterTypes.OSCILLATION_FREQUENCY],
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_SCATTER_HOPF_PARAMETER_PLOT_FREQUENCY,
                                    style=Styles.DIV_GRAPH_SCATTER_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # hopf parameter normalization error
                                        dcc.Graph(
                                            id=IDs.FIGURE_SCATTER_HOPF_PARAMETER_PLOT_NORMALIZATION_ERROR,
                                            figure=glob.figures.hopf_parameters[HopfParameterTypes.NORMALIZATION_ERROR],
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_SCATTER_HOPF_PARAMETER_PLOT_NORMALIZATION_ERROR,
                                    style=Styles.DIV_GRAPH_SCATTER_PLOT,
                                ),
                            ],
                            id=IDs.DIV_SCATTER_ROW_PLOTS_B,
                            style=Styles.DIV_SMALL_ROW,
                        ),
                    ],
                    id=IDs.DIV_SCATTER_FOUR_PLOTS_ROW,
                    style=Styles.DIV_FOUR_PLOTS,
                ),
            ],
            id=IDs.DIV_MATRIX_01,
            style=Styles.DIV_GRAPHS,
        ),
        # DIV_CONTROL heatmap
        html.Div(
            [
                # Group 1: heatmap ternary options
                html.Div(
                    [
                        html.Label(Labels.MIN_COUNT_CONSIDERED, style=Styles.LABEL),
                        min_heatmap_value.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 2: bifurcation distribution options
                html.Div(
                    [
                        html.Label(Labels.LOGARITHMIC_SCALE, style=Styles.LABEL),
                        heatmap_logarithmic.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 3: saddlenode  bifurcations
                html.Div(
                    [
                        html.Label(Labels.SADDLENODE_BIFURCATIONS, style=Styles.LABEL),
                        saddlenode_empirical_heatmap.build(),
                        saddlenode_alternative_heatmap.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 4: transcritical bifurcations
                html.Div(
                    [
                        html.Label(Labels.TRANSCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        transcritical_empirical_heatmap.build(),
                        transcritical_alternative_heatmap.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 5: hopf subcritical bifurcations
                html.Div(
                    [
                        html.Label(Labels.HOPF_SUBCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        subcritical_empirical_heatmap.build(),
                        subcritical_alternative_heatmap.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 6: hopf supercritical bifurcations
                html.Div(
                    [
                        html.Label(Labels.HOPF_SUPERCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        supercritical_empirical_heatmap.build(),
                        supercritical_alternative_heatmap.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 7: bautin
                html.Div(
                    [
                        html.Label(Labels.HOPF_BAUTIN_BIFURCATIONS, style=Styles.LABEL),
                        bautin_empirical_heatmap.build(),
                        bautin_alternative_heatmap.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
            ],
            style=Styles.DIV_CONTROL,
        ),
        # DIV_GRAPHS
        html.Div(
            [
                # ternary graph
                html.Div(
                    [
                        dcc.Graph(
                            id=IDs.FIGURE_HEATMAP_TERNARY,
                            figure=glob.figures.ternary_heatmap,
                            style=Styles.TERNARY,
                            config={"doubleClick": False, "scrollZoom": False, "responsive": True, "displayModeBar": False},
                        )
                    ],
                    id=IDs.DIV_HEATMAP_TERNARY,
                    style=Styles.DIV_GRAPH_HEATMAP_TERNARY,
                ),
            ],
            id=IDs.DIV_MATRIX_02,
            style=Styles.DIV_GRAPHS,
        ),
        # DIV_CONTROL distribution
        html.Div(
            [
                # Group 1: distribution options
                html.Div(
                    [
                        html.Label(Labels.BIFURCATION_DISTRIBUTION_NUM_BINS, style=Styles.LABEL),
                        bifurcation_distribution_num_bins.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 2: distribution configuration
                html.Div(
                    [
                        html.Label(Labels.BIFURCATION_DISTRIBUTIONS_NUM_CONTOURS, style=Styles.LABEL),
                        bifurcation_distribution_num_contours.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 3: distribution design
                html.Div(
                    [
                        html.Label(Labels.BIFURCATION_DISTRIBUTIONS_DESIGN, style=Styles.LABEL),
                        bifurcation_distribution_use_contours.build(),
                        bifurcation_distribution_logarithmic.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 4: saddlenode  bifurcations
                html.Div(
                    [
                        html.Label(Labels.SADDLENODE_BIFURCATIONS, style=Styles.LABEL),
                        saddlenode_empirical_distribution.build(),
                        saddlenode_alternative_distribution.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 5: transcritical bifurcations
                html.Div(
                    [
                        html.Label(Labels.TRANSCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        transcritical_empirical_distribution.build(),
                        transcritical_alternative_distribution.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 6: hopf subcritical bifurcations
                html.Div(
                    [
                        html.Label(Labels.HOPF_SUBCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        subcritical_empirical_distribution.build(),
                        subcritical_alternative_distribution.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 7: hopf supercritical bifurcations
                html.Div(
                    [
                        html.Label(Labels.HOPF_SUPERCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        supercritical_empirical_distribution.build(),
                        supercritical_alternative_distribution.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 8: bautin
                html.Div(
                    [
                        html.Label(Labels.HOPF_BAUTIN_BIFURCATIONS, style=Styles.LABEL),
                        bautin_empirical_distribution.build(),
                        bautin_alternative_distribution.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
            ],
            style=Styles.DIV_CONTROL,
        ),
        # DIV_GRAPHS
        html.Div(
            [
                # DIV_GRAPH_DISTRIBUTION
                html.Div(
                    [
                        # bifuraction distribution sdsr
                        dcc.Graph(
                            id=IDs.FIGURE_DISTRIBUTION_SD_SR,
                            figure=glob.figures.bifurcation_distribution[BifurcationDistributionTypes.SD_SR],
                            style=Styles.PLOT,
                            config={"displayModeBar": False},
                        ),
                    ],
                    id=IDs.DIV_DISTRIBUTION_SD_SR,
                    style=Styles.DIV_GRAPH_DISTRIBUTION_PLOT,
                ),
                # DIV_GRAPH_DISTRIBUTION
                html.Div(
                    [
                        # bifuraction distribution sdsr
                        dcc.Graph(
                            id=IDs.FIGURE_DISTRIBUTION_SR_SL,
                            figure=glob.figures.bifurcation_distribution[BifurcationDistributionTypes.SR_SL],
                            style=Styles.PLOT,
                            config={"displayModeBar": False},
                        ),
                    ],
                    id=IDs.DIV_DISTRIBUTION_SR_SL,
                    style=Styles.DIV_GRAPH_DISTRIBUTION_PLOT,
                ),
                # DIV_GRAPH_DISTRIBUTION
                html.Div(
                    [
                        # bifuraction distribution sdsr
                        dcc.Graph(
                            id=IDs.FIGURE_DISTRIBUTION_SL_SD,
                            figure=glob.figures.bifurcation_distribution[BifurcationDistributionTypes.SL_SD],
                            style=Styles.PLOT,
                            config={"displayModeBar": False},
                        ),
                    ],
                    id=IDs.DIV_DISTRIBUTION_SL_SD,
                    style=Styles.DIV_GRAPH_DISTRIBUTION_PLOT,
                ),
            ],
            id=IDs.DIV_MATRIX_03,
            style=Styles.DIV_GRAPHS,
        ),
        # error messages
        html.Div(
            id=IDs.ERROR_MESSAGE,
            style={"color": "red", "fontWeight": "bold", "textAlign": "center", "padding": "10px"},
        ),
    ]
)
