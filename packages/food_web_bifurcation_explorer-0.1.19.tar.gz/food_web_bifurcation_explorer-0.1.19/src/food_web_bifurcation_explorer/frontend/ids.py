from enum import Enum, unique

from food_web_bifurcation_explorer.common.decorators import consistent_ids


@unique
@consistent_ids
class IDs(str, Enum):
    """Enumeration for frontend IDs."""

    # control for scatter ternary
    DROPDOWN_SCATTER_COMPARTMENT_FIRST = "dropdown-scatter-compartment-first"
    DROPDOWN_SCATTER_COMPARTMENT_SECOND = "dropdown-scatter-compartment-second"
    DROPDOWN_SCATTER_NETWORK = "dropdown-scatter-network"
    DROPDOWN_SCATTER_PARAMETER_TYPE = "dropdown-scatter-parameter-type"
    DROPDOWN_SCATTER_SIZE = "dropdown-scatter-size"
    TEXTFIELD_SCATTER_FIXED_PARAMETER_VALUE = "textfield-scatter-fixed-parameter-value"
    # eigen values spectrum for scatter ternary
    TEXTFIELD_SCATTER_EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE = "textfield-scatter-eigenvalue-spectrum-index-alternative"
    TEXTFIELD_SCATTER_EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL = "textfield-scatter-eigenvalue-spectrum-index-empirical"
    # checkbox branches for scatter ternary
    CHECKBOX_SCATTER_EQUILIBRIA_AREA = "checkbox-scatter-equilibria-area"
    CHECKBOX_SCATTER_EQUILIBRIA_OVERINFORMATION = "checkbox-scatter-equilibria-overinformation"
    CHECKBOX_SCATTER_EQUILIBRIA_STABLE = "checkbox-scatter-equilibria-stable"
    CHECKBOX_SCATTER_EQUILIBRIA_UNSTABLE = "checkbox-scatter-equilibria-unstable"
    # checkbox bifurcations for scatter ternary
    CHECKBOX_SCATTER_BIFURCATIONS_HOPF_BAUTIN_ALTERNATIVE = "checkbox-scatter-bifurcations-hopf-bautin-alternative"
    CHECKBOX_SCATTER_BIFURCATIONS_HOPF_BAUTIN_EMPIRICAL = "checkbox-scatter-bifurcations-hopf-bautin-empirical"
    CHECKBOX_SCATTER_BIFURCATIONS_HOPF_ENVELOPE_ALTERNATIVE = "checkbox-scatter-bifurcations-hopf-envelope-alternative"
    CHECKBOX_SCATTER_BIFURCATIONS_HOPF_ENVELOPE_EMPIRICAL = "checkbox-scatter-bifurcations-hopf-envelope-empirical"
    CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE = "checkbox-scatter-bifurcations-hopf-subcritical-alternative"
    CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL = "checkbox-scatter-bifurcations-hopf-subcritical-empirical"
    CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE = "checkbox-scatter-bifurcations-hopf-supercritical-alternative"
    CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL = "checkbox-scatter-bifurcations-hopf-supercritical-empirical"
    CHECKBOX_SCATTER_BIFURCATIONS_SADDLENODE_ALTERNATIVE = "checkbox-scatter-bifurcations-saddlenode-alternative"
    CHECKBOX_SCATTER_BIFURCATIONS_SADDLENODE_EMPIRICAL = "checkbox-scatter-bifurcations-saddlenode-empirical"
    CHECKBOX_SCATTER_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE = "checkbox-scatter-bifurcations-transcritical-alternative"
    CHECKBOX_SCATTER_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL = "checkbox-scatter-bifurcations-transcritical-empirical"
    # others
    CHECKBOX_SCATTER_OTHERS_EIGENVALUE_SPECTRUM_INDEX = "checkbox-scatter-others-eigenvalue-spectrum-index"
    CHECKBOX_SCATTER_OTHERS_EXTINCT = "checkbox-scatter-others-extinct"
    CHECKBOX_SCATTER_OTHERS_INTERNALERROR = "checkbox-scatter-others-internalerror"
    # draw options
    CHECKBOX_SCATTER_DRAW_BRANCH_ALTERNATIVE = "checkbox-scatter-draw-branch-alternative"
    CHECKBOX_SCATTER_DRAW_BRANCH_EMPIRICAL = "checkbox-scatter-draw-branch-empirical"
    CHECKBOX_SCATTER_DRAW_LINES = "checkbox-scatter-draw-lines"
    CHECKBOX_SCATTER_DRAW_POINTS = "checkbox-scatter-draw-points"
    # eigen values centering
    CHECKBOX_SCATTER_EIGENVALUE_SPECTRUM_CENTERED_ALTERNATIVE = "checkbox-scatter-eigenvalue-spectrum-centered-alternative"
    CHECKBOX_SCATTER_EIGENVALUE_SPECTRUM_CENTERED_EMPIRICAL = "checkbox-scatter-eigenvalue-spectrum-centered-empirical"
    # heatmap
    TEXTFIELD_HEATMAP_MIN_VALUE = "textfield-heatmap-min-value"
    CHECKBOX_HEATMAP_LOGARITHMIC = "checkbox-heatmap-logarithmic"
    # checkbox bifurcations for heatmap ternary
    CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_BAUTIN_ALTERNATIVE = "checkbox-heatmap-bifurcations-hopf-bautin-alternative"
    CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_BAUTIN_EMPIRICAL = "checkbox-heatmap-bifurcations-hopf-bautin-empirical"
    CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE = "checkbox-heatmap-bifurcations-hopf-subcritical-alternative"
    CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL = "checkbox-heatmap-bifurcations-hopf-subcritical-empirical"
    CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE = "checkbox-heatmap-bifurcations-hopf-supercritical-alternative"
    CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL = "checkbox-heatmap-bifurcations-hopf-supercritical-empirical"
    CHECKBOX_HEATMAP_BIFURCATIONS_SADDLENODE_ALTERNATIVE = "checkbox-heatmap-bifurcations-saddlenode-alternative"
    CHECKBOX_HEATMAP_BIFURCATIONS_SADDLENODE_EMPIRICAL = "checkbox-heatmap-bifurcations-saddlenode-empirical"
    CHECKBOX_HEATMAP_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE = "checkbox-heatmap-bifurcations-transcritical-alternative"
    CHECKBOX_HEATMAP_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL = "checkbox-heatmap-bifurcations-transcritical-empirical"
    # bifurcation distributions
    TEXTFIELD_DISTRIBUTION_USE_CONTOURS = "textfield-distribution-use-contours"
    TEXTFIELD_DISTRIBUTION_NUM_CONTOURS = "textfield-distribution-num-contours"
    TEXTFIELD_DISTRIBUTION_NUM_BINS = "textfield-distribution-num-bins"
    CHECKBOX_DISTRIBUTION_LOGARITHMIC = "checkbox-distribution-logarithmic"
    # checkbox bifurcations for bifurcation distribution ternary
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_BAUTIN_ALTERNATIVE = "checkbox-distribution-bifurcations-hopf-bautin-alternative"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_BAUTIN_EMPIRICAL = "checkbox-distribution-bifurcations-hopf-bautin-empirical"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE = "checkbox-distribution-bifurcations-hopf-subcritical-alternative"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL = "checkbox-distribution-bifurcations-hopf-subcritical-empirical"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE = "checkbox-distribution-bifurcations-hopf-supercritical-alternative"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL = "checkbox-distribution-bifurcations-hopf-supercritical-empirical"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_SADDLENODE_ALTERNATIVE = "checkbox-distribution-bifurcations-saddlenode-alternative"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_SADDLENODE_EMPIRICAL = "checkbox-distribution-bifurcations-saddlenode-empirical"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE = "checkbox-distribution-bifurcations-transcritical-alternative"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL = "checkbox-distribution-bifurcations-transcritical-empirical"
    # scatter graphs
    FIGURE_SCATTER_BIFURCATION_DIAGRAM_FIRST = "figure-scatter-bifurcation-diagram-first"
    FIGURE_SCATTER_BIFURCATION_DIAGRAM_SECOND = "figure-scatter-bifurcation-diagram-second"
    FIGURE_SCATTER_EIGENVALUE_SPECTRUM_ALTERNATIVE = "figure-scatter-eigenvalue-spectrum-alternative"
    FIGURE_SCATTER_EIGENVALUE_SPECTRUM_EMPIRICAL = "figure-scatter-eigenvalue-spectrum-empirical"
    FIGURE_SCATTER_HOPF_PARAMETER_PLOT_L1 = "figure-scatter-hopf-parameter-plot-l1"
    FIGURE_SCATTER_HOPF_PARAMETER_PLOT_NORMALIZATION_ERROR = "figure-scatter-hopf-parameter-plot-normalization-error"
    FIGURE_SCATTER_HOPF_PARAMETER_PLOT_OSCILLATION_FREQUENCY = "figure-scatter-hopf-parameter-plot-oscillation-frequency"
    FIGURE_SCATTER_HOPF_PARAMETER_PLOT_TRANSVERSAL_CROSSING_SPEED = "figure-scatter-hopf-parameter-plot-transversal-crossing-speed"
    FIGURE_SCATTER_TERNARY = "figure-scatter-ternary"
    # heatmap graphs
    FIGURE_HEATMAP_TERNARY = "figure-heatmap-ternary"
    # distribution graphs
    FIGURE_DISTRIBUTION_SD_SR = "figure-distribution-sd-sr"
    FIGURE_DISTRIBUTION_SL_SD = "figure-distribution-sl-sd"
    FIGURE_DISTRIBUTION_SR_SL = "figure-distribution-sr-sl"
    # scatter divs
    DIV_SCATTER_ROW_PLOTS_A = "div-scatter-row-plots-a"
    DIV_SCATTER_ROW_PLOTS_B = "div-scatter-row-plots-b"
    DIV_SCATTER_BIFURCATION_DIAGRAM_FIRST = "div-scatter-bifurcation-diagram-first"
    DIV_SCATTER_BIFURCATION_DIAGRAM_SECOND = "div-scatter-bifurcation-diagram-second"
    DIV_SCATTER_EIGENVALUE_SPECTRUM_ALTERNATIVE = "div-scatter-eigenvalue-spectrum-alternative"
    DIV_SCATTER_EIGENVALUE_SPECTRUM_EMPIRICAL = "div-scatter-eigenvalue-spectrum-empirical"
    DIV_SCATTER_FOUR_PLOTS_ROW = "div-scatter-four-plots-row"
    DIV_SCATTER_HOPF_PARAMETER_PLOT_FREQUENCY = "div-scatter-hopf-parameter-plot-frequency"
    DIV_SCATTER_HOPF_PARAMETER_PLOT_L1 = "div-scatter-hopf-parameter-plot-l1"
    DIV_SCATTER_HOPF_PARAMETER_PLOT_NORMALIZATION_ERROR = "div-scatter-hopf-parameter-plot-normalization-error"
    DIV_SCATTER_HOPF_PARAMETER_PLOT_TRANSVERSAL_CROSSING_SPEED = "div-scatter-hopf-parameter-plot-transversal-crossing-speed"
    DIV_SCATTER_TERNARY = "div-scatter-ternary"
    # heatmap div
    DIV_HEATMAP_TERNARY = "div-heatmap-ternary"
    # distribution div
    DIV_DISTRIBUTION_SD_SR = "div-distribution-sd-sr"
    DIV_DISTRIBUTION_SL_SD = "div-distribution-sl-sd"
    DIV_DISTRIBUTION_SR_SL = "div-distribution-sr-sl"
    # other divs
    DIV_MATRIX_01 = "div-matrix-01"
    DIV_MATRIX_02 = "div-matrix-02"
    DIV_MATRIX_03 = "div-matrix-03"
    # other
    ERROR_MESSAGE = "error-message"
