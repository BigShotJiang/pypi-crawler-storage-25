from dash import dcc, html

from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers
from food_web_bifurcation_explorer.frontend.ids import IDs


def build() -> html.Div:
    # input number box
    return html.Div(
        dcc.Input(
            id=IDs.TEXTFIELD_HEATMAP_MIN_VALUE,
            type="number",
            min=IntegerNumbers.HEATMAP_MIN_VALUE,
            max=IntegerNumbers.HEATMAP_MAX_VALUE,
            step=IntegerNumbers.HEATMAP_MIN_VALUE_STEP,
            style={
                "width": "100%",
                "boxSizing": "border-box",
                "height": "36px",
                "borderRadius": "5px",
                "border": "1px solid #ccc",
                "padding": "0 10px",
            },
            value=IntegerNumbers.HEATMAP_MIN_VALUE,
            debounce=True,
        ),
        style={"flex": "1", "marginRight": "10px"},
    )
