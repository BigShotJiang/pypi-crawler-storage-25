from dash import dcc, html

from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.frontend.ids import IDs


# build
def build() -> dcc.Checklist:
    return dcc.Checklist(
        id=IDs.CHECKBOX_HEATMAP_LOGARITHMIC,
        options=[
            {
                "label": html.Span(
                    [
                        Labels.HEATMAP_TERNARY,
                    ]
                ),
                "value": True,
            }
        ],
        value=[],
        inline=True,
        labelStyle=Styles.CHECKBOXLABEL,
    )
