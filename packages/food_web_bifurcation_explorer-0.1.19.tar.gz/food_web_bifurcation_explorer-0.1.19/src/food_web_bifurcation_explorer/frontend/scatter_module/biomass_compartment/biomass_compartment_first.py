from dash import dcc

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.static_options import StaticOptions
from food_web_bifurcation_explorer.frontend.ids import IDs


def build() -> dcc.Dropdown:
    """Builds and returns a Dash Dropdown component for selecting the first compartment."""
    # get compartments
    compartments: list[str] = glob.config.get_current_compartments()
    return dcc.Dropdown(
        id=IDs.DROPDOWN_SCATTER_COMPARTMENT_FIRST,
        options=[{"label": compartments[index] + " (" + str(index) + ")", "value": index} for index in range(0, len(compartments))],
        value=StaticOptions.DEFAULT_COMPARTMENT_FIRST,
        clearable=False,  # prevents the user from food_web_bifurcation_explorer.clearing the selection (removes the X)
    )


def update() -> list[dict[str, object]]:
    """Updates and returns the options for the compartment first dropdown."""
    # get compartments
    compartments: list[str] = glob.config.get_current_compartments()
    # set new options
    options = [{"label": compartments[index] + " (" + str(index) + ")", "value": index} for index in range(0, len(compartments))]
    return options
