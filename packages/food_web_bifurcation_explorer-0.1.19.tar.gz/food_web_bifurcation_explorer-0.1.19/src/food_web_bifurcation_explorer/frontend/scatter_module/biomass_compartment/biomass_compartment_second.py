from dash import dcc

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.static_options import StaticOptions
from food_web_bifurcation_explorer.frontend.ids import IDs


def build() -> dcc.Dropdown:
    # get compartments
    compartments: list[str] = glob.config.get_current_compartments()
    return dcc.Dropdown(
        id=IDs.DROPDOWN_SCATTER_COMPARTMENT_SECOND,
        options=[{"label": compartments[index] + " (" + str(index) + ")", "value": index} for index in range(0, len(compartments))],
        value=StaticOptions.DEFAULT_COMPARTMENT_SECOND,
        clearable=False,  # prevents the user from food_web_bifurcation_explorer.clearing the selection (removes the X)
    )


def update() -> list[dict[str, object]]:
    # get compartments
    compartments: list[str] = glob.config.get_current_compartments()
    # set new options
    options = [{"label": compartments[index] + " (" + str(index) + ")", "value": index} for index in range(0, len(compartments))]
    return options
