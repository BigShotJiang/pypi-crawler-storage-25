from dash import dcc

from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.frontend.ids import IDs


def build() -> dcc.Checklist:
    return dcc.Checklist(
        id=IDs.CHECKBOX_SCATTER_EIGENVALUE_SPECTRUM_CENTERED_EMPIRICAL,
        options=[{"label": Labels.EIGENVALUE_SPECTRUM_CENTERED, "value": True}],
        value=[],
        inline=True,
        labelStyle=Styles.CHECKBOXLABEL,
    )
