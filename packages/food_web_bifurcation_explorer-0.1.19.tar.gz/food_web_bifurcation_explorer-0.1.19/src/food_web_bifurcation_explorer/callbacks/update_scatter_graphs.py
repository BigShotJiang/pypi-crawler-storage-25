import plotly.graph_objects as go
from dash import Input, Output, Patch, callback, no_update

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.types.bifurcation_diagram_types import BifurcationDiagramTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.hopf_parameter_types import HopfParameterTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.frontend.scatter_module.biomass_compartment import biomass_compartment_first, biomass_compartment_second
from food_web_bifurcation_explorer.graph.bifurcation_diagram.build import build_bifurcation_diagram
from food_web_bifurcation_explorer.graph.bifurcation_diagram.update import update_bifurcation_diagram
from food_web_bifurcation_explorer.graph.eigenvalue_spectrum.build import build_eigenvalue_spectrum
from food_web_bifurcation_explorer.graph.eigenvalue_spectrum.update import update_eigenvalue_spectrum
from food_web_bifurcation_explorer.graph.hopf_parameter_plot.update import update_hopf_parameter_plot
from food_web_bifurcation_explorer.graph.ternary_scatter.build import build_ternary_scatter
from food_web_bifurcation_explorer.graph.ternary_scatter.update import update_ternary_scatter


# callback to update graphs
@callback(
    # outputs
    [
        Output(IDs.DROPDOWN_SCATTER_PARAMETER_TYPE, "value"),
        Output(IDs.TEXTFIELD_SCATTER_FIXED_PARAMETER_VALUE, "value"),
        Output(IDs.DROPDOWN_SCATTER_COMPARTMENT_FIRST, "options"),
        Output(IDs.DROPDOWN_SCATTER_COMPARTMENT_SECOND, "options"),
        Output(IDs.TEXTFIELD_SCATTER_EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL, "value"),
        Output(IDs.TEXTFIELD_SCATTER_EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE, "value"),
        Output(IDs.FIGURE_SCATTER_TERNARY, "figure"),
        Output(IDs.FIGURE_SCATTER_BIFURCATION_DIAGRAM_FIRST, "figure"),
        Output(IDs.FIGURE_SCATTER_BIFURCATION_DIAGRAM_SECOND, "figure"),
        Output(IDs.FIGURE_SCATTER_EIGENVALUE_SPECTRUM_EMPIRICAL, "figure"),
        Output(IDs.FIGURE_SCATTER_EIGENVALUE_SPECTRUM_ALTERNATIVE, "figure"),
        Output(IDs.FIGURE_SCATTER_HOPF_PARAMETER_PLOT_L1, "figure"),
        Output(IDs.FIGURE_SCATTER_HOPF_PARAMETER_PLOT_OSCILLATION_FREQUENCY, "figure"),
        Output(IDs.FIGURE_SCATTER_HOPF_PARAMETER_PLOT_TRANSVERSAL_CROSSING_SPEED, "figure"),
        Output(IDs.FIGURE_SCATTER_HOPF_PARAMETER_PLOT_NORMALIZATION_ERROR, "figure"),
        Output(IDs.ERROR_MESSAGE, "children"),
    ],
    # inputs
    [
        # scatter general options
        Input(IDs.DROPDOWN_SCATTER_NETWORK, "value"),
        Input(IDs.DROPDOWN_SCATTER_COMPARTMENT_FIRST, "value"),
        Input(IDs.DROPDOWN_SCATTER_COMPARTMENT_SECOND, "value"),
        Input(IDs.DROPDOWN_SCATTER_PARAMETER_TYPE, "value"),
        Input(IDs.TEXTFIELD_SCATTER_FIXED_PARAMETER_VALUE, "value"),
        # branches
        Input(IDs.CHECKBOX_SCATTER_EQUILIBRIA_AREA, "value"),
        Input(IDs.CHECKBOX_SCATTER_EQUILIBRIA_STABLE, "value"),
        Input(IDs.CHECKBOX_SCATTER_EQUILIBRIA_UNSTABLE, "value"),
        Input(IDs.CHECKBOX_SCATTER_EQUILIBRIA_OVERINFORMATION, "value"),
        # scatter bifurcations
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_SADDLENODE_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_SADDLENODE_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_BAUTIN_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_BAUTIN_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_ENVELOPE_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_ENVELOPE_ALTERNATIVE, "value"),
        # others
        Input(IDs.CHECKBOX_SCATTER_OTHERS_EXTINCT, "value"),
        Input(IDs.CHECKBOX_SCATTER_OTHERS_INTERNALERROR, "value"),
        Input(IDs.CHECKBOX_SCATTER_OTHERS_EIGENVALUE_SPECTRUM_INDEX, "value"),
        # draw options
        Input(IDs.CHECKBOX_SCATTER_DRAW_BRANCH_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SCATTER_DRAW_BRANCH_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_SCATTER_DRAW_LINES, "value"),
        Input(IDs.CHECKBOX_SCATTER_DRAW_POINTS, "value"),
        # eigen values spectrum
        Input(IDs.TEXTFIELD_SCATTER_EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL, "value"),
        Input(IDs.TEXTFIELD_SCATTER_EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE, "value"),
        # eigen values centering
        Input(IDs.CHECKBOX_SCATTER_EIGENVALUE_SPECTRUM_CENTERED_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SCATTER_EIGENVALUE_SPECTRUM_CENTERED_ALTERNATIVE, "value"),
    ],
)
# update scatter graph
def update_scatter_graphs(
    network: str,
    compartment_first_index: int,
    compartment_second_index: int,
    parameter_type_str: str,
    fixed_parameter_value: float,
    # equilibria
    equilibria_area: bool,
    equilibria_stable: bool,
    equilibria_unstable: bool,
    equilibria_over_information: bool,
    # bifurcations
    saddlenode_empirical: bool,
    saddlenode_alternative: bool,
    transcritical_empirical: bool,
    transcritical_alternative: bool,
    hopf_subcritical_empirical: bool,
    hopf_subcritical_alternative: bool,
    hopf_supercritical_empirical: bool,
    hopf_supercritical_alternative: bool,
    hopf_bautin_empirical: bool,
    hopf_bautin_alternative: bool,
    hopf_envelope_empirical: bool,
    hopf_envelope_alternative: bool,
    # others
    extinct: bool,
    internal_error: bool,
    eigenvalue_spectrum_symbols: bool,
    # drawing options
    draw_branch_empirical: bool,
    draw_branch_alternative: bool,
    draw_lines: bool,
    draw_points: bool,
    # eigenvalue spectrum
    eigenvalue_spectrum_index_empirical: int,
    eigenvalue_spectrum_index_alternative: int,
    # eigenvalue spectrum (centering)
    eigenvalue_spectrum_centered_empirical: bool,
    eigenvalue_spectrum_centered_alternative: bool,
) -> tuple[Patch, go.Figure, go.Figure, go.Figure, go.Figure, str]:
    # update drawing config
    glob.config.drawing_options.update_scatter_flags(
        # bifurcations
        saddlenode_empirical,
        saddlenode_alternative,
        transcritical_empirical,
        transcritical_alternative,
        hopf_subcritical_empirical,
        hopf_subcritical_alternative,
        hopf_supercritical_empirical,
        hopf_supercritical_alternative,
        hopf_bautin_empirical,
        hopf_bautin_alternative,
        # scatter options
        equilibria_area,
        equilibria_stable,
        equilibria_unstable,
        equilibria_over_information,
        hopf_envelope_empirical,
        hopf_envelope_alternative,
        extinct,
        internal_error,
        eigenvalue_spectrum_symbols,
        draw_branch_empirical,
        draw_branch_alternative,
        draw_lines,
        draw_points,
        # eigenvalues
        eigenvalue_spectrum_centered_empirical,
        eigenvalue_spectrum_centered_alternative,
    )

    # check if update network
    if glob.config.network != network:
        # update network
        glob.config.update_network(network)

        # load ternary data
        glob.plot_data.load_ternary_data()

        # rebuild figures
        glob.figures.ternary_scatter = build_ternary_scatter()
        glob.figures.bifurcation_diagram_first = build_bifurcation_diagram(BifurcationDiagramTypes.FIRST)
        glob.figures.bifurcation_diagram_second = build_bifurcation_diagram(BifurcationDiagramTypes.SECOND)
        glob.figures.eigenvalue_spectrum_empirical = build_eigenvalue_spectrum(BranchTypes.EMPIRICAL)
        glob.figures.eigenvalue_spectrum_alternative = build_eigenvalue_spectrum(BranchTypes.ALTERNATIVE)

        # redraw all scatter plots
        glob.config.drawing_options.redraw_all_scatter_graphs()

    # check if update parameter type
    try:
        parameter_type = ParameterTypes(parameter_type_str)
        if glob.config.fixed_parameter_type != parameter_type:
            # set new fixed parameter type
            glob.config.update_fixed_parameter_type(parameter_type)

            # rebuild figures
            glob.figures.ternary_scatter = build_ternary_scatter()
            glob.figures.bifurcation_diagram_first = build_bifurcation_diagram(BifurcationDiagramTypes.FIRST)
            glob.figures.bifurcation_diagram_second = build_bifurcation_diagram(BifurcationDiagramTypes.SECOND)
            glob.figures.eigenvalue_spectrum_empirical = build_eigenvalue_spectrum(BranchTypes.EMPIRICAL)
            glob.figures.eigenvalue_spectrum_alternative = build_eigenvalue_spectrum(BranchTypes.ALTERNATIVE)

            # redraw all scatter plots
            glob.config.drawing_options.redraw_all_scatter_graphs()
    except ValueError:
        pass

    # check if update fixed parameter value
    if glob.config.fixed_parameter_value != fixed_parameter_value:
        # set new value
        fixed_parameter_value = glob.config.update_fixed_parameter_value(fixed_parameter_value)

        # read branch datas
        glob.plot_data.load_branch_datas()

        # update only branches in ternary
        glob.config.drawing_options.scatter_ternary_options.redraw_ternary_branches = True

        # rebuild figures
        glob.figures.bifurcation_diagram_first = build_bifurcation_diagram(BifurcationDiagramTypes.FIRST)
        glob.figures.bifurcation_diagram_second = build_bifurcation_diagram(BifurcationDiagramTypes.SECOND)
        glob.figures.eigenvalue_spectrum_empirical = build_eigenvalue_spectrum(BranchTypes.EMPIRICAL)
        glob.figures.eigenvalue_spectrum_alternative = build_eigenvalue_spectrum(BranchTypes.ALTERNATIVE)

        # redraw bifurcation diagrams
        for bifurcation_diagram in BifurcationDiagramTypes:
            glob.config.drawing_options.redraw_bifurcation_diagram_graphs(bifurcation_diagram)

    # check if update first compartment
    if glob.config.compartment_index[BifurcationDiagramTypes.FIRST] != compartment_first_index:
        # update first compartment
        glob.config.update_compartment(BifurcationDiagramTypes.FIRST, compartment_first_index)

        # rebuild figures
        glob.figures.bifurcation_diagram_first = build_bifurcation_diagram(BifurcationDiagramTypes.FIRST)
        glob.figures.eigenvalue_spectrum_empirical = build_eigenvalue_spectrum(BranchTypes.EMPIRICAL)
        glob.figures.eigenvalue_spectrum_alternative = build_eigenvalue_spectrum(BranchTypes.ALTERNATIVE)

        # redraw bifurcation diagram
        glob.config.drawing_options.redraw_bifurcation_diagram_graphs(BifurcationDiagramTypes.FIRST)

    # check if update second compartment
    if glob.config.compartment_index[BifurcationDiagramTypes.SECOND] != compartment_second_index:
        # update second compartment
        glob.config.update_compartment(BifurcationDiagramTypes.SECOND, compartment_first_index)

        # rebuild figures
        glob.figures.bifurcation_diagram_second = build_bifurcation_diagram(BifurcationDiagramTypes.SECOND)

        # redraw bifurcation diagram
        glob.config.drawing_options.redraw_bifurcation_diagram_graphs(BifurcationDiagramTypes.SECOND)

    # check if update eigenvalue spectrum empirical index
    if glob.config.eigenvalue_spectrum_index[BranchTypes.EMPIRICAL] != eigenvalue_spectrum_index_empirical:
        # update eigen value spectrum empirical index
        glob.config.update_eigenvalue_spectrum_index(BranchTypes.EMPIRICAL, eigenvalue_spectrum_index_empirical)

        # rebuild figure
        glob.figures.eigenvalue_spectrum_empirical = build_eigenvalue_spectrum(BranchTypes.EMPIRICAL)

        # redraw bifurcation diagrams
        glob.config.drawing_options.eigenvalue_spectrum[BranchTypes.EMPIRICAL].redraw_all()

        # mark the empirical index for redrawing
        glob.config.drawing_options.bifurcation_diagrams_options[BifurcationDiagramTypes.FIRST].redraw_eigenvalue_spectrum_symbol_empirical = True

    # check if update eigenvalue spectrum empirical index
    if glob.config.eigenvalue_spectrum_index[BranchTypes.ALTERNATIVE] != eigenvalue_spectrum_index_alternative:
        # update eigen value spectrum alternative index
        glob.config.update_eigenvalue_spectrum_index(BranchTypes.ALTERNATIVE, eigenvalue_spectrum_index_alternative)

        # rebuild figure
        glob.figures.eigenvalue_spectrum_alternative = build_eigenvalue_spectrum(BranchTypes.ALTERNATIVE)

        # redraw bifurcation diagrams
        glob.config.drawing_options.eigenvalue_spectrum[BranchTypes.ALTERNATIVE].redraw_all()

        # mark the alternative index for redrawing
        glob.config.drawing_options.bifurcation_diagrams_options[BifurcationDiagramTypes.FIRST].redraw_eigenvalue_spectrum_symbol_alternative = True

    # update ternary scatter
    glob.figures.ternary_scatter = update_ternary_scatter()

    # update both bifurcation diagrams
    glob.figures.bifurcation_diagram_first = update_bifurcation_diagram(glob.figures.bifurcation_diagram_first, BifurcationDiagramTypes.FIRST)
    glob.figures.bifurcation_diagram_second = update_bifurcation_diagram(glob.figures.bifurcation_diagram_second, BifurcationDiagramTypes.SECOND)

    # update eigen values
    glob.figures.eigenvalue_spectrum_empirical = update_eigenvalue_spectrum(glob.figures.eigenvalue_spectrum_empirical, BranchTypes.EMPIRICAL)
    glob.figures.eigenvalue_spectrum_alternative = update_eigenvalue_spectrum(glob.figures.eigenvalue_spectrum_alternative, BranchTypes.ALTERNATIVE)

    # declare hopf parameter updates as no_update by default
    hopf_parameter_updates = [no_update] * len(HopfParameterTypes)

    # only update if at least one of the hopf parameter plots needs to be updated. In other case, send no_update to avoid unnecessary updates
    if any(glob.config.drawing_options.redraw_hopf_bifurcation.values()):
        # update figures
        glob.figures.hopf_parameters[HopfParameterTypes.L1] = update_hopf_parameter_plot(HopfParameterTypes.L1, Labels.L1, Labels.L1_UNIT)
        glob.figures.hopf_parameters[HopfParameterTypes.OSCILLATION_FREQUENCY] = update_hopf_parameter_plot(
            HopfParameterTypes.OSCILLATION_FREQUENCY, Labels.OSCILLATION_FREQUENCY, Labels.OSCILLATION_FREQUENCY_UNIT
        )
        glob.figures.hopf_parameters[HopfParameterTypes.TRANSVERSAL_CROSSING_SPEED] = update_hopf_parameter_plot(
            HopfParameterTypes.TRANSVERSAL_CROSSING_SPEED, Labels.TRANSVERSAL_CROSSING_SPEED, Labels.TRANSVERSAL_CROSSING_SPEED_UNIT
        )
        glob.figures.hopf_parameters[HopfParameterTypes.NORMALIZATION_ERROR] = update_hopf_parameter_plot(
            HopfParameterTypes.NORMALIZATION_ERROR, Labels.NORMALIZATION_ERROR, Labels.NORMALIZATION_ERROR_UNIT
        )

        # send figures as update
        hopf_parameter_updates = list(glob.figures.hopf_parameters.values())

    # return both figure and the empty error message
    return (
        # dropdown and text fields
        parameter_type_str,
        fixed_parameter_value,
        biomass_compartment_first.update(),
        biomass_compartment_second.update(),
        eigenvalue_spectrum_index_empirical,
        eigenvalue_spectrum_index_alternative,
        # ternary
        glob.figures.ternary_scatter,
        # bifurcation diagrams
        glob.figures.bifurcation_diagram_first,
        glob.figures.bifurcation_diagram_second,
        # eigen values
        glob.figures.eigenvalue_spectrum_empirical,
        glob.figures.eigenvalue_spectrum_alternative,
        # hopf parameter plots
        hopf_parameter_updates[0],
        hopf_parameter_updates[1],
        hopf_parameter_updates[2],
        hopf_parameter_updates[3],
        # error message
        "",
    )
