import plotly.graph_objects as go
from dash import Input, Output, callback

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.bifurcation_distribution_types import BifurcationDistributionTypes
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.graph.bifurcation_distribution.update import update_bifurcation_distribution


# callback to update graphs
@callback(
    # outputs
    [
        Output(IDs.FIGURE_DISTRIBUTION_SD_SR, "figure"),
        Output(IDs.FIGURE_DISTRIBUTION_SR_SL, "figure"),
        Output(IDs.FIGURE_DISTRIBUTION_SL_SD, "figure"),
    ],
    # inputs
    [
        # heatmap options
        Input(IDs.TEXTFIELD_DISTRIBUTION_NUM_BINS, "value"),
        Input(IDs.TEXTFIELD_DISTRIBUTION_NUM_CONTOURS, "value"),
        Input(IDs.TEXTFIELD_DISTRIBUTION_USE_CONTOURS, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_LOGARITHMIC, "value"),
        # heatmap bifurcations
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_SADDLENODE_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_SADDLENODE_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_BAUTIN_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_BAUTIN_ALTERNATIVE, "value"),
    ],
)
# update heatmap graph
def update_distribution_graphs(
    bifurcation_distribution_num_bins: int,
    bifurcation_distribution_num_contours: int,
    bifurcation_distribution_use_contours: bool,
    bifurcation_distribution_logarithmic: bool,
    bifurcations_saddlenode_empirical: bool,
    bifurcations_saddlenode_alternative: bool,
    bifurcations_transcritical_empirical: bool,
    bifurcations_transcritical_alternative: bool,
    bifurcations_hopf_subcritical_empirical: bool,
    bifurcations_hopf_subcritical_alternative: bool,
    bifurcations_hopf_supercritical_empirical: bool,
    bifurcations_hopf_supercritical_alternative: bool,
    bifurcations_hopf_bautin_empirical: bool,
    bifurcations_hopf_bautin_alternative: bool,
) -> tuple[go.Figure, go.Figure, go.Figure]:
    # update hetmap options
    glob.config.bifurcation_distribution_num_bins = bifurcation_distribution_num_bins
    glob.config.bifurcation_distribution_num_contours = bifurcation_distribution_num_contours
    glob.config.bifurcation_distribution_use_contours = bifurcation_distribution_use_contours
    glob.config.bifurcation_distribution_logarithmic = bifurcation_distribution_logarithmic
    # update only bifurcation flags
    glob.config.drawing_options.update_distribution_flags(
        bifurcations_saddlenode_empirical,
        bifurcations_saddlenode_alternative,
        bifurcations_transcritical_empirical,
        bifurcations_transcritical_alternative,
        bifurcations_hopf_subcritical_empirical,
        bifurcations_hopf_subcritical_alternative,
        bifurcations_hopf_supercritical_empirical,
        bifurcations_hopf_supercritical_alternative,
        bifurcations_hopf_bautin_empirical,
        bifurcations_hopf_bautin_alternative,
    )
    # update bifurcation distributions
    for bifurcation_distribution_type in BifurcationDistributionTypes:
        glob.figures.bifurcation_distribution[bifurcation_distribution_type] = update_bifurcation_distribution(bifurcation_distribution_type)
    # return all figures
    return (
        # bifurcation distributions
        glob.figures.bifurcation_distribution[BifurcationDistributionTypes.SD_SR],
        glob.figures.bifurcation_distribution[BifurcationDistributionTypes.SR_SL],
        glob.figures.bifurcation_distribution[BifurcationDistributionTypes.SL_SD],
    )
