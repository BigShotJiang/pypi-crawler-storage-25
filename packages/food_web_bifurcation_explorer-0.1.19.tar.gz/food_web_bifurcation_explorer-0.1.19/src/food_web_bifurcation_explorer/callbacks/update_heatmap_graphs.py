import plotly.graph_objects as go
from dash import Input, Output, callback

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.graph.ternary_heatmap.update import update_ternary_heatmap


# callback to update graphs
@callback(
    # outputs
    [
        Output(IDs.FIGURE_HEATMAP_TERNARY, "figure"),
    ],
    # inputs
    [
        # heatmap options
        Input(IDs.TEXTFIELD_HEATMAP_MIN_VALUE, "value"),
        Input(IDs.CHECKBOX_HEATMAP_LOGARITHMIC, "value"),
        # heatmap bifurcations
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_SADDLENODE_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_SADDLENODE_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_BAUTIN_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_BAUTIN_ALTERNATIVE, "value"),
    ],
)
# update heatmap graph
def update_heatmap_graphs(
    heatmap_ternary_min_value: int,
    heatmap_ternary_logarithmic: bool,
    bifurcations_saddlenode_empirical: bool,
    bifurcations_saddlenode_alternative: bool,
    bifurcations_transcritical_empirical: bool,
    bifurcations_transcritical_alternative: bool,
    bifurcations_hopf_subcritical_empirical: bool,
    bifurcations_hopf_subcritical_alternative: bool,
    bifurcations_hopf_supercritical_empirical: bool,
    bifurcations_hopf_supercritical_alternative: bool,
    bifurcations_hopf_bautin_empirical: bool,
    bifurcations_hopf_bautin_alternative: bool,
) -> tuple[go.Figure]:
    # update hetmap options
    glob.config.heatmap_ternary_min_value = heatmap_ternary_min_value
    glob.config.heatmap_ternary_logarithmic = heatmap_ternary_logarithmic
    # update only bifurcation flags
    glob.config.drawing_options.update_heatmap_flags(
        bifurcations_saddlenode_empirical,
        bifurcations_saddlenode_alternative,
        bifurcations_transcritical_empirical,
        bifurcations_transcritical_alternative,
        bifurcations_hopf_subcritical_empirical,
        bifurcations_hopf_subcritical_alternative,
        bifurcations_hopf_supercritical_empirical,
        bifurcations_hopf_supercritical_alternative,
        bifurcations_hopf_bautin_empirical,
        bifurcations_hopf_bautin_alternative,
    )
    # update ternary heatmap
    glob.figures.ternary_heatmap = update_ternary_heatmap()
    # return all figures
    return (
        # scatter ternary
        glob.figures.ternary_heatmap,
    )
