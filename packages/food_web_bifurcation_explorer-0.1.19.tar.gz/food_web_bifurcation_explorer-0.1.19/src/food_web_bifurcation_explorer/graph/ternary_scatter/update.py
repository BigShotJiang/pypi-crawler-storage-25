import plotly.graph_objects as go

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.data.ternary_data import TernaryData
from food_web_bifurcation_explorer.data.ternary_line import TernaryLine
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.traces.ternary_traces import TernaryTraces
from food_web_bifurcation_explorer.enums.types.area_types import AreaTypes
from food_web_bifurcation_explorer.enums.types.bifurcation_types_extended import BifurcationTypesExtended
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes


def build_ternary_hover_template(title: str, show: bool) -> str | None:
    if show:
        return (
            f"{title}<br>"
            + f"{Labels.DONOR_CONTROL.value}: %{{b:.6f}}<br>"
            + f"{Labels.RECIPIENT_CONTROL.value}: %{{c:.6f}}<br>"
            + f"{Labels.LOTKAVOLTERRA_CONTROL.value}: %{{a:.6f}}<br>"
            + "<extra></extra>"
        )
    return None


def update_bifurcation_trace(
    ternary: go.Figure,
    ternary_trace: TernaryTraces,
    branch_type: BranchTypes,
    bifurcation_type: BifurcationTypesExtended,
    drawing_mode: str,
    is_active: bool,
) -> go.Figure:
    # declare combined lists for a, b, c
    a_combined, b_combined, c_combined = [], [], []

    # only populate if active, otherwise leave empty to clear the trace
    if is_active:
        # get ternary data
        ternary_data: TernaryData = glob.plot_data.ternary_data

        # obtain relevant indexes for the given branch and bifurcation type
        indexes = ternary_data.get_ternary_indexes(branch_type, bifurcation_type)

        # iterate over all indexes
        for idx in indexes:
            # retrieve a, b, c values for the current index
            b_list, c_list, a_list = ternary_data.get_ternary_values(branch_type, bifurcation_type, idx)

            # only add to combined lists if there are valid points (a_list is not empty)
            if a_list and len(a_list) > 0:
                # append to combined lists
                a_combined.extend(a_list)
                b_combined.extend(b_list)
                c_combined.extend(c_list)

                # insert None to break lines between segments
                if "lines" in drawing_mode:
                    a_combined.append(None)
                    b_combined.append(None)
                    c_combined.append(None)
    # set over info
    hover_info = "all" if glob.config.drawing_options.scatter_ternary_options.equilibria_over_information and a_combined else "skip"

    # update traces
    ternary.update_traces(
        selector={"name": str(ternary_trace.value)},
        a=a_combined,
        b=b_combined,
        c=c_combined,
        mode=drawing_mode if a_combined else "markers",
        hoverinfo=hover_info,
        hovertemplate=(
            build_ternary_hover_template(ternary_trace.value, glob.config.drawing_options.scatter_ternary_options.equilibria_over_information)
            if a_combined
            else None
        ),
    )


def update_ternary_scatter() -> go.Figure:

    # get ternary
    ternary: go.Figure = glob.figures.ternary_scatter

    # adjust layout size based on resolution
    ternary.update_layout(width=glob.config.resolution * 2, height=glob.config.resolution * 2)

    # Determine drawing mode
    if glob.config.drawing_options.scatter_ternary_options.lines and glob.config.drawing_options.scatter_ternary_options.points:
        drawing_mode = "lines+markers"
    elif glob.config.drawing_options.scatter_ternary_options.lines:
        drawing_mode = "lines"
    elif glob.config.drawing_options.scatter_ternary_options.points:
        drawing_mode = "markers"
    else:
        drawing_mode = "none"

    # Stable area
    if glob.config.drawing_options.scatter_ternary_options.equilibria_area:
        sd, sr, sl = glob.plot_data.ternary_data.shape_data.get_perimeter_coordinates(AreaTypes.STABLE)
        ternary.update_traces(selector={"name": str(TernaryTraces.STABLE_EQUILIBRIA_AREA.value)}, a=sl, b=sd, c=sr)
    else:
        ternary.update_traces(selector={"name": str(TernaryTraces.STABLE_EQUILIBRIA_AREA.value)}, a=[], b=[], c=[])

    # Unstable area
    if glob.config.drawing_options.scatter_ternary_options.equilibria_area:
        sd, sr, sl = glob.plot_data.ternary_data.shape_data.get_perimeter_coordinates(AreaTypes.UNSTABLE)
        ternary.update_traces(selector={"name": str(TernaryTraces.UNSTABLE_EQUILIBRIA_AREA.value)}, a=sl, b=sd, c=sr)
    else:
        ternary.update_traces(selector={"name": str(TernaryTraces.UNSTABLE_EQUILIBRIA_AREA.value)}, a=[], b=[], c=[])

    # ternary line
    if glob.config.drawing_options.scatter_ternary_options.redraw_ternary_branches:
        # create line
        ternary_line = TernaryLine()

        # Stable
        a, b, c = (ternary_line.stable_sl, ternary_line.stable_sd, ternary_line.stable_sr) if ternary_line.stable_sl else ([], [], [])
        ternary.update_traces(
            selector={"name": str(TernaryTraces.STABLE_EQUILIBRIA.value)},
            a=a,
            b=b,
            c=c,
            mode="lines",
            hovertemplate=build_ternary_hover_template(
                "Empirical stable equilibrium", glob.config.drawing_options.scatter_ternary_options.equilibria_over_information
            ),
        )

        # Unstable
        a, b, c = (ternary_line.unstable_sl, ternary_line.unstable_sd, ternary_line.unstable_sr) if ternary_line.unstable_sl else ([], [], [])
        ternary.update_traces(
            selector={"name": str(TernaryTraces.UNSTABLE_EQUILIBRIA.value)},
            a=a,
            b=b,
            c=c,
            mode="lines",
            hovertemplate=build_ternary_hover_template(
                "Empirical unstable equilibrium", glob.config.drawing_options.scatter_ternary_options.equilibria_over_information
            ),
        )
        glob.config.drawing_options.scatter_ternary_options.redraw_ternary_branches = False

    # extinctions
    if glob.config.drawing_options.scatter_ternary_options.redraw_extinct:
        update_bifurcation_trace(
            ternary,
            TernaryTraces.EXTINCT,
            BranchTypes.ALTERNATIVE,
            BifurcationTypesExtended.EXTINCT,
            drawing_mode,
            glob.config.drawing_options.scatter_ternary_options.extinct,
        )
        glob.config.drawing_options.scatter_ternary_options.redraw_extinct = False

    # saddle node empirical
    if glob.config.drawing_options.scatter_ternary_bifurcation.redraw_saddlenode_empirical:
        update_bifurcation_trace(
            ternary,
            TernaryTraces.SADDLENODE_EMPIRICAL,
            BranchTypes.EMPIRICAL,
            BifurcationTypesExtended.SADDLENODE,
            drawing_mode,
            glob.config.drawing_options.scatter_ternary_bifurcation.saddlenode_empirical,
        )
        glob.config.drawing_options.scatter_ternary_bifurcation.redraw_saddlenode_empirical = False

    # saddle node alternative
    if glob.config.drawing_options.scatter_ternary_bifurcation.redraw_saddlenode_alternative:
        update_bifurcation_trace(
            ternary,
            TernaryTraces.SADDLENODE_ALTERNATIVE,
            BranchTypes.ALTERNATIVE,
            BifurcationTypesExtended.SADDLENODE,
            drawing_mode,
            glob.config.drawing_options.scatter_ternary_bifurcation.saddlenode_alternative,
        )
        glob.config.drawing_options.scatter_ternary_bifurcation.redraw_saddlenode_alternative = False

    # transcritical empirical
    if glob.config.drawing_options.scatter_ternary_bifurcation.redraw_transcritical_empirical:
        update_bifurcation_trace(
            ternary,
            TernaryTraces.TRANSCRITICAL_EMPIRICAL,
            BranchTypes.EMPIRICAL,
            BifurcationTypesExtended.TRANSCRITICAL,
            drawing_mode,
            glob.config.drawing_options.scatter_ternary_bifurcation.transcritical_empirical,
        )
        glob.config.drawing_options.scatter_ternary_bifurcation.redraw_transcritical_empirical = False

    # transcritical alternative
    if glob.config.drawing_options.scatter_ternary_bifurcation.redraw_transcritical_alternative:
        update_bifurcation_trace(
            ternary,
            TernaryTraces.TRANSCRITICAL_ALTERNATIVE,
            BranchTypes.ALTERNATIVE,
            BifurcationTypesExtended.TRANSCRITICAL,
            drawing_mode,
            glob.config.drawing_options.scatter_ternary_bifurcation.transcritical_alternative,
        )
        glob.config.drawing_options.scatter_ternary_bifurcation.redraw_transcritical_alternative = False

    # hopf subcritical empirical
    if glob.config.drawing_options.scatter_ternary_bifurcation.redraw_hopf_subcritical_empirical:
        update_bifurcation_trace(
            ternary,
            TernaryTraces.HOPF_SUBCRITICAL_EMPIRICAL,
            BranchTypes.EMPIRICAL,
            BifurcationTypesExtended.HOPF_SUBCRITICAL,
            drawing_mode,
            glob.config.drawing_options.scatter_ternary_bifurcation.hopf_subcritical_empirical,
        )
        glob.config.drawing_options.scatter_ternary_bifurcation.redraw_hopf_subcritical_empirical = False

    # hopf subcritical alternative
    if glob.config.drawing_options.scatter_ternary_bifurcation.redraw_hopf_subcritical_alternative:
        update_bifurcation_trace(
            ternary,
            TernaryTraces.HOPF_SUBCRITICAL_ALTERNATIVE,
            BranchTypes.ALTERNATIVE,
            BifurcationTypesExtended.HOPF_SUBCRITICAL,
            drawing_mode,
            glob.config.drawing_options.scatter_ternary_bifurcation.hopf_subcritical_alternative,
        )
        glob.config.drawing_options.scatter_ternary_bifurcation.redraw_hopf_subcritical_alternative = False

    # hopf supercritical empirical
    if glob.config.drawing_options.scatter_ternary_bifurcation.redraw_hopf_supercritical_empirical:
        update_bifurcation_trace(
            ternary,
            TernaryTraces.HOPF_SUPERCRITICAL_EMPIRICAL,
            BranchTypes.EMPIRICAL,
            BifurcationTypesExtended.HOPF_SUPERCRITICAL,
            drawing_mode,
            glob.config.drawing_options.scatter_ternary_bifurcation.hopf_supercritical_empirical,
        )
        glob.config.drawing_options.scatter_ternary_bifurcation.redraw_hopf_supercritical_empirical = False

    # hopf supercritical alternative
    if glob.config.drawing_options.scatter_ternary_bifurcation.redraw_hopf_supercritical_alternative:
        update_bifurcation_trace(
            ternary,
            TernaryTraces.HOPF_SUPERCRITICAL_ALTERNATIVE,
            BranchTypes.ALTERNATIVE,
            BifurcationTypesExtended.HOPF_SUPERCRITICAL,
            drawing_mode,
            glob.config.drawing_options.scatter_ternary_bifurcation.hopf_supercritical_alternative,
        )
        glob.config.drawing_options.scatter_ternary_bifurcation.redraw_hopf_supercritical_alternative = False

    # hopf bautin empirical
    if glob.config.drawing_options.scatter_ternary_bifurcation.redraw_hopf_bautin_empirical:
        update_bifurcation_trace(
            ternary,
            TernaryTraces.HOPF_BAUTIN_EMPIRICAL,
            BranchTypes.EMPIRICAL,
            BifurcationTypesExtended.HOPF_BAUTIN,
            drawing_mode,
            glob.config.drawing_options.scatter_ternary_bifurcation.hopf_bautin_empirical,
        )
        glob.config.drawing_options.scatter_ternary_bifurcation.redraw_hopf_bautin_empirical = False

    # hopf bautin alternative
    if glob.config.drawing_options.scatter_ternary_bifurcation.redraw_hopf_bautin_alternative:
        update_bifurcation_trace(
            ternary,
            TernaryTraces.HOPF_BAUTIN_ALTERNATIVE,
            BranchTypes.ALTERNATIVE,
            BifurcationTypesExtended.HOPF_BAUTIN,
            drawing_mode,
            glob.config.drawing_options.scatter_ternary_bifurcation.hopf_bautin_alternative,
        )
        glob.config.drawing_options.scatter_ternary_bifurcation.redraw_hopf_bautin_alternative = False

    # internal error
    if glob.config.drawing_options.scatter_ternary_options.redraw_internal_error:
        update_bifurcation_trace(
            ternary,
            TernaryTraces.INTERNAL_ERROR,
            BranchTypes.ALTERNATIVE,
            BifurcationTypesExtended.INTERNAL_ERROR,
            drawing_mode,
            glob.config.drawing_options.scatter_ternary_options.internal_error,
        )
        glob.config.drawing_options.scatter_ternary_options.redraw_internal_error = False

    return ternary
