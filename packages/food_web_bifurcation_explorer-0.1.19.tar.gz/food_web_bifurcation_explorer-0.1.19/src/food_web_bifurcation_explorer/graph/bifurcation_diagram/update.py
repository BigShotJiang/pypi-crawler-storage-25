import plotly.graph_objects as go

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.data.branch_data import EnvelopeData
from food_web_bifurcation_explorer.data.plot_data import BranchData
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers
from food_web_bifurcation_explorer.enums.traces.bifurcation_diagram_traces import BifurcationDiagramTraces
from food_web_bifurcation_explorer.enums.types.bifurcation_diagram_types import BifurcationDiagramTypes
from food_web_bifurcation_explorer.enums.types.bifurcation_types_extended import BifurcationTypesExtended
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes


def build_over_template(trace: str, show: bool) -> str | None:
    # check if show over template
    if show:
        # return formatted over template
        return (
            trace
            + "<br>"
            + "Parameter "
            + glob.config.dynamic_paramameter_type
            + ": %{x}<br>"
            + "Biomass: %{y} "
            + Labels.BIOMASS_UNIT
            + " <extra></extra>"
        )
    # skip template
    return None


def clear_branch(fig: go.Figure, name: str) -> None:
    """Clears the branch trace with the specified name in the given figure.

    Args:
        fig (go.Figure): The Plotly figure object.
        name (str): The name of the branch trace to clear.

    """
    fig.update_traces(selector={"name": name}, x=[], y=[])


def clear_branch_traces(fig: go.Figure, branch_data: BranchData) -> None:
    # stable
    clear_branch(fig, BifurcationDiagramTraces.STABLE_EQUILIBRIA.value + "_" + branch_data.branch_type.value)
    # unstable
    clear_branch(fig, BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value + "_" + branch_data.branch_type.value)
    # stable (transition)
    clear_branch(fig, BifurcationDiagramTraces.STABLE_EQUILIBRIA.value + "_transition_" + branch_data.branch_type.value)
    # unstable (transition)
    clear_branch(fig, BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value + "_transition_" + branch_data.branch_type.value)


def draw_branch_data(bifurcation_diagram_type: BifurcationDiagramTypes, branch_data: BranchData, fig: go.Figure) -> None:
    """Draws branch data for the specified compartment index in the figure.

    Args:
        branch_data: The branch data object containing equilibrium nodes and x values.
        fig (go.Figure): The Plotly figure object.

    """
    # check if show hoverinfo
    show_hoverinfo = "skip"
    if glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].equilibria_over_information:
        show_hoverinfo = "all"

    # get biomass column name
    biomass_column = f"b_{glob.config.compartment_index[bifurcation_diagram_type] + 1}"

    # check if there is data to draw
    if not branch_data.branch_dataframe.empty:
        # get parameter values
        parameter_values = branch_data.branch_dataframe["parameter_values"].tolist()

        # stable
        if glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].equilibria_stable:
            fig.update_traces(
                selector={"name": BifurcationDiagramTraces.STABLE_EQUILIBRIA.value + "_" + branch_data.branch_type.value},
                x=parameter_values,
                y=branch_data.stablenodes_dataframe[biomass_column].tolist(),
                hoverinfo=show_hoverinfo,
                hovertemplate=build_over_template(
                    BifurcationDiagramTraces.STABLE_EQUILIBRIA.value,
                    glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].equilibria_over_information,
                ),
            )
        else:
            clear_branch(fig, BifurcationDiagramTraces.STABLE_EQUILIBRIA.value + "_" + branch_data.branch_type)

        # unstable
        if glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].equilibria_unstable:
            fig.update_traces(
                selector={"name": BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value + "_" + branch_data.branch_type},
                x=parameter_values,
                y=branch_data.unstablenodes_dataframe[biomass_column].tolist(),
                hoverinfo=show_hoverinfo,
                hovertemplate=build_over_template(
                    BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value,
                    glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].equilibria_over_information,
                ),
            )
        else:
            clear_branch(fig, BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value + "_" + branch_data.branch_type)

        # stable (transition)
        if glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].equilibria_stable:
            fig.update_traces(
                selector={"name": BifurcationDiagramTraces.STABLE_EQUILIBRIA.value + "_transition_" + branch_data.branch_type},
                x=parameter_values,
                y=branch_data.transition_stabletounstablenodes_dataframe[biomass_column].tolist(),
                hoverinfo=show_hoverinfo,
                hovertemplate=build_over_template(
                    BifurcationDiagramTraces.STABLE_EQUILIBRIA.value,
                    glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].equilibria_over_information,
                ),
            )
        else:
            clear_branch(fig, BifurcationDiagramTraces.STABLE_EQUILIBRIA.value + "_transition_" + branch_data.branch_type)

        # unstable (transition)
        if glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].equilibria_unstable:
            fig.update_traces(
                selector={"name": BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value + "_transition_" + branch_data.branch_type},
                x=parameter_values,
                y=branch_data.transition_unstabletostablenodes_dataframe[biomass_column].tolist(),
                hoverinfo=show_hoverinfo,
                hovertemplate=build_over_template(
                    BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value,
                    glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].equilibria_over_information,
                ),
            )
        else:
            clear_branch(fig, BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value + "_transition_" + branch_data.branch_type)

    else:
        clear_branch_traces(fig, branch_data)


def update_bifurcation_diagram(fig: go.Figure, bifurcation_diagram_type: BifurcationDiagramTypes) -> go.Figure:
    """Updates the bifurcation diagram in the given figure based on the diagram type.

    Args:
        fig (go.Figure): The Plotly figure object.
        plot_type (PlotTypes): The type of bifurcation diagram to update.

    Returns:
        go.Figure: The updated Plotly figure object.

    """
    # get branches
    empirical_branch = glob.plot_data.branch_datas[glob.config.fixed_parameter_type][BranchTypes.EMPIRICAL]
    alternative_branch = glob.plot_data.branch_datas[glob.config.fixed_parameter_type][BranchTypes.ALTERNATIVE]

    # get bifurcation diagrams bifurcations
    bifurcation_diagrams_bifurcations = glob.config.drawing_options.bifurcation_diagrams_bifurcations[bifurcation_diagram_type]

    # empirical branch
    if glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].redraw_ternary_branches:
        # first clear branches
        clear_branch_traces(fig, empirical_branch)
        clear_branch_traces(fig, alternative_branch)

        # draw empirical branch
        if glob.config.drawing_options.scatter_ternary_options.branch_empirical:
            # draw branch data
            draw_branch_data(bifurcation_diagram_type, empirical_branch, fig)

            # draw alternative branch
        if glob.config.drawing_options.scatter_ternary_options.branch_alternative:
            # draw branch data
            draw_branch_data(bifurcation_diagram_type, alternative_branch, fig)

            # reset flag
        glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].redraw_ternary_branches = False

    # envelope empirical
    if glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].redraw_hopf_envelope_empirical:
        # clear branches
        clear_branch(fig, BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL.value)
        clear_branch(fig, BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL_TOP.value)
        clear_branch(fig, BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL_BOT.value)

        # check if draw
        if glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].hopf_envelope_empirical:
            # get evelope empirical data
            envelope_empirical: EnvelopeData = empirical_branch.envelope_data

            # draw traces
            if False and glob.config.compartment_index[bifurcation_diagram_type] < len(envelope_empirical.envelope_line_y):
                fig.update_traces(
                    selector={"name": BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL.value},
                    x=envelope_empirical.envelope_line_x,
                    y=envelope_empirical.envelope_line_y[glob.config.compartment_index[bifurcation_diagram_type]],
                    hovertemplate=build_over_template(
                        BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL.value,
                        glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].equilibria_over_information,
                    ),
                )

            # draw traces
            if glob.config.compartment_index[bifurcation_diagram_type] < len(envelope_empirical.envelope_top):
                fig.update_traces(
                    selector={"name": BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL_TOP.value},
                    x=envelope_empirical.x_values,
                    y=envelope_empirical.envelope_top[glob.config.compartment_index[bifurcation_diagram_type]],
                    hovertemplate=build_over_template(
                        BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL_TOP.value,
                        glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].equilibria_over_information,
                    ),
                )

            # draw traces
            if glob.config.compartment_index[bifurcation_diagram_type] < len(envelope_empirical.envelope_bot):
                fig.update_traces(
                    selector={"name": BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL_BOT.value},
                    x=envelope_empirical.x_values,
                    y=envelope_empirical.envelope_bot[glob.config.compartment_index[bifurcation_diagram_type]],
                    hovertemplate=build_over_template(
                        BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL_BOT.value,
                        glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].equilibria_over_information,
                    ),
                )

                # reset flag
        glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].redraw_hopf_envelope_empirical = False

    # bifurcation dataframes
    empirical_bifurcations = empirical_branch.bifurcations_dataframe
    alternative_bifurcations = alternative_branch.bifurcations_dataframe

    # get biomass column name
    biomass_column = f"b_{glob.config.compartment_index[bifurcation_diagram_type] + 1}"

    # saddle node empirical
    if bifurcation_diagrams_bifurcations.redraw_saddlenode_empirical:
        x_combined, y_combined = [], []
        if bifurcation_diagrams_bifurcations.saddlenode_empirical and not empirical_bifurcations.empty:
            filtered_data = empirical_bifurcations[empirical_bifurcations["type"] == BifurcationTypesExtended.SADDLENODE]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_combined.extend(branch_rows["parameter_values"].tolist())
                    y_combined.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.SADDLENODE_EMPIRICAL.value},
            x=x_combined,
            y=y_combined,
            hovertemplate=build_over_template(BifurcationDiagramTraces.SADDLENODE_EMPIRICAL.value, True),
        )

        # reset flag
        bifurcation_diagrams_bifurcations.redraw_saddlenode_empirical = False

    # saddle node alternative
    if bifurcation_diagrams_bifurcations.redraw_saddlenode_alternative:
        x_combined, y_combined = [], []
        if bifurcation_diagrams_bifurcations.saddlenode_alternative and not alternative_bifurcations.empty:
            filtered_data = alternative_bifurcations[alternative_bifurcations["type"] == BifurcationTypesExtended.SADDLENODE]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_combined.extend(branch_rows["parameter_values"].tolist())
                    y_combined.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.SADDLENODE_ALTERNATIVE.value},
            x=x_combined,
            y=y_combined,
            hovertemplate=build_over_template(BifurcationDiagramTraces.SADDLENODE_ALTERNATIVE.value, True),
        )

        # reset flag
        bifurcation_diagrams_bifurcations.redraw_saddlenode_alternative = False

    # transcritical empirical
    if bifurcation_diagrams_bifurcations.redraw_transcritical_empirical:
        x_combined, y_combined = [], []
        if bifurcation_diagrams_bifurcations.transcritical_empirical and not empirical_bifurcations.empty:
            filtered_data = empirical_bifurcations[empirical_bifurcations["type"] == BifurcationTypesExtended.TRANSCRITICAL]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_combined.extend(branch_rows["parameter_values"].tolist())
                    y_combined.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.TRANSCRITICAL_EMPIRICAL.value},
            x=x_combined,
            y=y_combined,
            hovertemplate=build_over_template(BifurcationDiagramTraces.TRANSCRITICAL_EMPIRICAL.value, True),
        )

        # reset flag
        bifurcation_diagrams_bifurcations.redraw_transcritical_empirical = False

    # transcritical alternative
    if bifurcation_diagrams_bifurcations.redraw_transcritical_alternative:
        x_combined, y_combined = [], []
        if bifurcation_diagrams_bifurcations.transcritical_alternative and not alternative_bifurcations.empty:
            filtered_data = alternative_bifurcations[alternative_bifurcations["type"] == BifurcationTypesExtended.TRANSCRITICAL]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_combined.extend(branch_rows["parameter_values"].tolist())
                    y_combined.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.TRANSCRITICAL_ALTERNATIVE.value},
            x=x_combined,
            y=y_combined,
            hovertemplate=build_over_template(BifurcationDiagramTraces.TRANSCRITICAL_ALTERNATIVE.value, True),
        )

        # reset flag
        bifurcation_diagrams_bifurcations.redraw_transcritical_alternative = False

    # hopf subcritical empirical
    if bifurcation_diagrams_bifurcations.redraw_hopf_subcritical_empirical:
        x_combined, y_combined = [], []
        if bifurcation_diagrams_bifurcations.hopf_subcritical_empirical and not empirical_bifurcations.empty:
            filtered_data = empirical_bifurcations[empirical_bifurcations["type"] == BifurcationTypesExtended.HOPF_SUBCRITICAL]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_combined.extend(branch_rows["parameter_values"].tolist())
                    y_combined.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.HOPF_SUBCRITICAL_EMPIRICAL.value},
            x=x_combined,
            y=y_combined,
            hovertemplate=build_over_template(BifurcationDiagramTraces.HOPF_SUBCRITICAL_EMPIRICAL.value, True),
        )

        # reset flag
        bifurcation_diagrams_bifurcations.redraw_hopf_subcritical_empirical = False

    # hopf subcritical alternative
    if bifurcation_diagrams_bifurcations.redraw_hopf_subcritical_alternative:
        x_combined, y_combined = [], []
        if bifurcation_diagrams_bifurcations.hopf_subcritical_alternative and not alternative_bifurcations.empty:
            filtered_data = alternative_bifurcations[alternative_bifurcations["type"] == BifurcationTypesExtended.HOPF_SUBCRITICAL]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_combined.extend(branch_rows["parameter_values"].tolist())
                    y_combined.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.HOPF_SUBCRITICAL_ALTERNATIVE.value},
            x=x_combined,
            y=y_combined,
            hovertemplate=build_over_template(BifurcationDiagramTraces.HOPF_SUBCRITICAL_ALTERNATIVE.value, True),
        )

        # reset flag
        bifurcation_diagrams_bifurcations.redraw_hopf_subcritical_alternative = False

    # hopf supercritical empirical
    if bifurcation_diagrams_bifurcations.redraw_hopf_supercritical_empirical:
        x_combined, y_combined = [], []
        if bifurcation_diagrams_bifurcations.hopf_supercritical_empirical and not empirical_bifurcations.empty:
            filtered_data = empirical_bifurcations[empirical_bifurcations["type"] == BifurcationTypesExtended.HOPF_SUPERCRITICAL]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_combined.extend(branch_rows["parameter_values"].tolist())
                    y_combined.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.HOPF_SUPERCRITICAL_EMPIRICAL.value},
            x=x_combined,
            y=y_combined,
            hovertemplate=build_over_template(BifurcationDiagramTraces.HOPF_SUPERCRITICAL_EMPIRICAL.value, True),
        )

        # reset flag
        bifurcation_diagrams_bifurcations.redraw_hopf_supercritical_empirical = False

    # hopf supercritical alternative
    if bifurcation_diagrams_bifurcations.redraw_hopf_supercritical_alternative:
        x_combined, y_combined = [], []
        if bifurcation_diagrams_bifurcations.hopf_supercritical_alternative and not alternative_bifurcations.empty:
            filtered_data = alternative_bifurcations[alternative_bifurcations["type"] == BifurcationTypesExtended.HOPF_SUPERCRITICAL]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_combined.extend(branch_rows["parameter_values"].tolist())
                    y_combined.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.HOPF_SUPERCRITICAL_ALTERNATIVE.value},
            x=x_combined,
            y=y_combined,
            hovertemplate=build_over_template(BifurcationDiagramTraces.HOPF_SUPERCRITICAL_ALTERNATIVE.value, True),
        )

        # reset flag
        bifurcation_diagrams_bifurcations.redraw_hopf_supercritical_alternative = False

    # extinct
    if glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].redraw_extinct:
        x_combined, y_combined = [], []
        if glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].extinct and not alternative_bifurcations.empty:
            filtered_data = alternative_bifurcations[alternative_bifurcations["type"] == BifurcationTypesExtended.EXTINCT]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_combined.extend(branch_rows["parameter_values"].tolist())
                    y_combined.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.EXTINCT.value},
            x=x_combined,
            y=y_combined,
            hovertemplate=build_over_template(BifurcationDiagramTraces.EXTINCT.value, True),
        )

        # reset flag
        glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].redraw_extinct = False

    # internal_error
    if glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].redraw_internal_error:
        x_combined, y_combined = [], []
        if glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].internal_error and not alternative_bifurcations.empty:
            filtered_data = alternative_bifurcations[alternative_bifurcations["type"] == BifurcationTypesExtended.INTERNAL_ERROR]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_combined.extend(branch_rows["parameter_values"].tolist())
                    y_combined.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.INTERNAL_ERROR.value},
            x=x_combined,
            y=y_combined,
            hovertemplate=build_over_template(BifurcationDiagramTraces.INTERNAL_ERROR.value, True),
        )

        # reset flag
        glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].redraw_internal_error = False

    # draw eingenvalue spectrum only if this is the first bifurcation diagram
    if bifurcation_diagram_type == BifurcationDiagramTypes.FIRST:
        # eigenvalue spectrum index empirical
        if glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].redraw_eigenvalue_spectrum_symbol_empirical:
            # clear traces
            clear_branch(fig, BifurcationDiagramTraces.EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL.value)

            # check eigenvalue spectrum flag
            if glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].eigenvalue_spectrum_symbols:
                # get empirical branch
                fig.update_traces(
                    selector={"name": BifurcationDiagramTraces.EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL.value},
                    x=empirical_branch.get_eigenvalue_spectrum_x(),
                    y=empirical_branch.get_eigenvalue_spectrum_y(),
                    hovertemplate=build_over_template(BifurcationDiagramTraces.EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL.value, True),
                )

            # reset flag
            glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].redraw_eigenvalue_spectrum_symbol_empirical = False

        # eigenvalue spectrum index alternative
        if glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].redraw_eigenvalue_spectrum_symbol_alternative:
            # clear traces
            clear_branch(fig, BifurcationDiagramTraces.EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE.value)

            # check eigenvalue spectrum flag
            if glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].eigenvalue_spectrum_symbols:
                # alternative
                fig.update_traces(
                    selector={"name": BifurcationDiagramTraces.EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE.value},
                    x=alternative_branch.get_eigenvalue_spectrum_x(),
                    y=alternative_branch.get_eigenvalue_spectrum_y(),
                    hovertemplate=build_over_template(BifurcationDiagramTraces.EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE.value, True),
                )

            # reset flag
            glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type].redraw_eigenvalue_spectrum_symbol_alternative = False

    # get x axis title
    if glob.config.dynamic_paramameter_type == ParameterTypes.DONOR:
        xaxis_title = Labels.DONOR_CONTROL_STRENGTH
    elif glob.config.dynamic_paramameter_type == ParameterTypes.RECIPIENT:
        xaxis_title = Labels.RECIPIENT_CONTROL_STRENGTH
    elif glob.config.dynamic_paramameter_type == ParameterTypes.LOTKAVOLTERRA:
        xaxis_title = Labels.LOTKAVOLTERRA_CONTROL_STRENGTH
    else:
        raise ValueError("Unknown fixed parameter type: " + glob.config.dynamic_paramameter_type)

    # update layout
    fig.update_layout(
        title="Evolution of biomass compartment '"
        + str(glob.config.compartment_index[bifurcation_diagram_type] + 1)
        + "' ("
        + glob.config.compartment_value[bifurcation_diagram_type]
        + ") for fixed "
        + glob.config.fixed_parameter_type
        + "="
        + glob.config.fixed_parameter_value_str,
        xaxis_title=xaxis_title,
        yaxis_title=glob.config.compartment_value[bifurcation_diagram_type] + " biomass (" + Labels.BIOMASS_UNIT + ")",
    )
    return fig
