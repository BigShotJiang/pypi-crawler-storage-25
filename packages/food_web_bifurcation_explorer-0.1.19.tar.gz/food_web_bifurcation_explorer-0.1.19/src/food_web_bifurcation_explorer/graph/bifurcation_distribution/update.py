import pandas as pd
import plotly.graph_objects as go

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.common.exceptions import BifurcationDistributionTypeError
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers
from food_web_bifurcation_explorer.enums.types.bifurcation_distribution_types import BifurcationDistributionTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes


def update_bifurcation_distribution(bifurcation_distribution_type: BifurcationDistributionTypes) -> go.Figure:
    # extract parameters depending of the plot type
    if bifurcation_distribution_type == BifurcationDistributionTypes.SD_SR:
        paramA = ParameterTypes.DONOR
        paramB = ParameterTypes.RECIPIENT
        center_label = ParameterTypes.LOTKAVOLTERRA.value
    elif bifurcation_distribution_type == BifurcationDistributionTypes.SR_SL:
        paramA = ParameterTypes.RECIPIENT
        paramB = ParameterTypes.LOTKAVOLTERRA
        center_label = ParameterTypes.DONOR.value
    elif bifurcation_distribution_type == BifurcationDistributionTypes.SL_SD:
        paramA = ParameterTypes.LOTKAVOLTERRA
        paramB = ParameterTypes.DONOR
        center_label = ParameterTypes.RECIPIENT.value
    else:
        raise BifurcationDistributionTypeError(f"Invalid bifurcation distribution type: {bifurcation_distribution_type}")
    # get figure
    fig = glob.figures.bifurcation_distribution[bifurcation_distribution_type]
    # clear previous data
    fig.data = []
    # get enabled bifurcations
    enabled_bifurcations = glob.config.drawing_options.bifurcation_distribution.get_enabled_bifurcations()
    # merge frames
    dataframes = [glob.general_bifurcation_data.data[BranchTypes.EMPIRICAL][b] for b in enabled_bifurcations[0]] + [
        glob.general_bifurcation_data.data[BranchTypes.ALTERNATIVE][b] for b in enabled_bifurcations[1]
    ]
    # concatenate frames
    if dataframes:
        # merge both dataframes
        merged = pd.concat(dataframes, ignore_index=True)
        # save merged debug
        with pd.option_context("display.max_rows", None, "display.max_columns", None):
            merged.to_csv("merged_debug.csv", index=False)
        # diagonal line from (1,0) to (0,1)
        fig.add_trace(
            go.Scatter(
                x=[1 - fixed_parameter_value for fixed_parameter_value in glob.config.fixed_parameter_values],
                y=[fixed_parameter_value for fixed_parameter_value in glob.config.fixed_parameter_values],
                mode="lines",
                line=dict(color="red", width=2),
                showlegend=False,
                hoverinfo="skip",
            )
        )
        # line from (0,0) to (1,0)
        fig.add_trace(
            go.Scatter(
                x=[fixed_parameter_value for fixed_parameter_value in glob.config.fixed_parameter_values],
                y=[0] * IntegerNumbers.MAX_FIXED_PARAMETERS,
                mode="lines",
                line=dict(color="red", width=2),
                showlegend=False,
                hoverinfo="skip",
            )
        )
        # line from (0,0) to (0,1)
        fig.add_trace(
            go.Scatter(
                x=[0] * IntegerNumbers.MAX_FIXED_PARAMETERS,
                y=[fixed_parameter_value for fixed_parameter_value in glob.config.fixed_parameter_values],
                mode="lines",
                line=dict(color="red", width=2),
                showlegend=False,
                hoverinfo="skip",
            )
        )
        # label at center (0.5, 0.5)
        fig.add_trace(
            go.Scatter(
                x=[0.58],
                y=[0.5],
                mode="text",
                text=f"Parameter {center_label}",
                textposition="middle center",
                textfont=dict(color="red", size=14, family="Arial"),
                showlegend=False,
                hoverinfo="skip",
            )
        )
        # check if use contours
        if glob.config.bifurcation_distribution_use_contours:
            # histogram 2D with contours
            fig.add_trace(
                go.Histogram2dContour(
                    x=merged[paramA.value],
                    y=merged[paramB.value],
                    colorscale="Blues",
                    contours_coloring="heatmap",
                    nbinsx=glob.config.bifurcation_distribution_num_bins,
                    nbinsy=glob.config.bifurcation_distribution_num_bins,
                    ncontours=glob.config.bifurcation_distribution_num_contours,
                    showscale=True,
                    zmin=1,
                    hovertemplate=(f"<b>{paramA.value}</b>: %{{x:.3f}}<br><b>{paramB.value}</b>: %{{y:.3f}}<br><b>Count</b>: %{{z}}<extra></extra>"),
                )
            )
        else:
            # classic histogram 2D
            fig.add_trace(
                go.Histogram2d(
                    x=merged[paramA.value],
                    y=merged[paramB.value],
                    colorscale=[
                        [0, "rgba(0,0,0,0)"],
                        [0.0001, "#d0e9ff"],
                        [1, "#003d7a"],
                    ],
                    nbinsx=glob.config.bifurcation_distribution_num_bins,
                    nbinsy=glob.config.bifurcation_distribution_num_bins,
                    showscale=True,
                    zmin=1,
                    hovertemplate=(f"<b>{paramA.value}</b>: %{{x:.3f}}<br><b>{paramB.value}</b>: %{{y:.3f}}<br><b>Count</b>: %{{z}}<extra></extra>"),
                )
            )
    # declare axis ticks
    axis_ticks = [round(i * 0.1, 1) for i in range(11)]
    # declare bin ticks (grid lines aligned with bins)
    bin_ticks = [round(i / glob.config.bifurcation_distribution_num_bins, 4) for i in range(glob.config.bifurcation_distribution_num_bins + 1)]
    # range X
    range_x = [0, 1]
    range_y = [0, 1]
    # set x axes
    fig.update_xaxes(
        title_text=f"Parameter {paramA.value}",
        tickvals=axis_ticks,
        range=range_x,
        constrain="domain",
        minor=dict(
            tickvals=bin_ticks,
            showgrid=True,
            gridcolor="lightgrey",
            gridwidth=0.5,
        ),
    )
    # set y axes
    fig.update_yaxes(
        title_text=f"Parameter {paramB.value}",
        tickvals=axis_ticks,
        range=range_y,
        scaleanchor="x",
        scaleratio=1,
        minor=dict(
            tickvals=bin_ticks,
            showgrid=True,
            gridcolor="lightgrey",
            gridwidth=0.5,
        ),
    )
    # final layout
    fig.update_layout(
        title_text=f"Bifurcation density ({paramA.value} vs {paramB.value})",
        showlegend=False,
        template="plotly_white",
    )
    return fig
