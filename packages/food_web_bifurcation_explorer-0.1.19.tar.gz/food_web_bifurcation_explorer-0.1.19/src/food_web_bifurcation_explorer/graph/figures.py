"""Module for managing graph figures used in the food web bifurcation explorer."""

import plotly.graph_objects as go

from food_web_bifurcation_explorer.enums.types.bifurcation_diagram_types import BifurcationDiagramTypes
from food_web_bifurcation_explorer.enums.types.bifurcation_distribution_types import BifurcationDistributionTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.hopf_parameter_types import HopfParameterTypes
from food_web_bifurcation_explorer.graph.bifurcation_diagram.build import build_bifurcation_diagram
from food_web_bifurcation_explorer.graph.bifurcation_distribution.build import build_bifurcation_distribution
from food_web_bifurcation_explorer.graph.eigenvalue_spectrum.build import build_eigenvalue_spectrum
from food_web_bifurcation_explorer.graph.hopf_parameter_plot.build import build_hopf_parameter_plot
from food_web_bifurcation_explorer.graph.ternary_heatmap.build import build_ternary_heatmap
from food_web_bifurcation_explorer.graph.ternary_scatter.build import build_ternary_scatter


class Figures:
    def __init__(self) -> None:
        # empty figure used if case of errors
        self.empty_figure: go.Figure = go.Figure()

        # ternary scatter
        self.ternary_scatter: go.Figure = build_ternary_scatter()

        # ternary heatmap
        self.ternary_heatmap: go.Figure = build_ternary_heatmap()

        # ternary index to know which trace corresponds to which index in the data
        self.ternary_traces_index: dict[str, str] = {}

        # ternary index to know which trace to remove when updating the ternary diagram
        self.ternary_traces_remove: dict[str, str] = {}

        # first bifurcation diagram
        self.bifurcation_diagram_first: go.Figure = build_bifurcation_diagram(BifurcationDiagramTypes.FIRST)

        # second bifurcation diagram
        self.bifurcation_diagram_second: go.Figure = build_bifurcation_diagram(BifurcationDiagramTypes.SECOND)

        # eigenvalue spectrum for empirical branch
        self.eigenvalue_spectrum_empirical: go.Figure = build_eigenvalue_spectrum(BranchTypes.EMPIRICAL)

        # eigenvalue spectrum for alternative branch
        self.eigenvalue_spectrum_alternative: go.Figure = build_eigenvalue_spectrum(BranchTypes.ALTERNATIVE)

        # hopf parameters
        self.hopf_parameters: dict[HopfParameterTypes, go.Figure] = {}
        for hopf_parameter_type in HopfParameterTypes:
            self.hopf_parameters[hopf_parameter_type] = build_hopf_parameter_plot(hopf_parameter_type)

        # bifurcation distributions
        self.bifurcation_distribution: dict[BifurcationDistributionTypes, go.Figure] = {}
        for bifurcation_distribution_type in BifurcationDistributionTypes:
            self.bifurcation_distribution[bifurcation_distribution_type] = build_bifurcation_distribution(bifurcation_distribution_type)
