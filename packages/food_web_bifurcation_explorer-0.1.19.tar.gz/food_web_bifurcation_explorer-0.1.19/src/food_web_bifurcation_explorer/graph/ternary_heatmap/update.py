import plotly.graph_objects as go

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.colors.heatmap_colors.heatmap_blue_red_colors import HeatmapBlueRedColors
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers
from food_web_bifurcation_explorer.enums.types.bifurcation_types import BifurcationTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes


def add_heatmap_legend(fig: go.Figure, block_counts: dict[int, int]) -> go.Figure:
    """add color legend"""

    # position
    legend_x0 = 1.00
    legend_x1 = 1.04
    legend_y0 = 0.05
    legend_y1 = 0.9
    block_height = (legend_y1 - legend_y0) / IntegerNumbers.HEATMAP_MAX_VALUE

    shapes_legend = []
    annotations_legend = []

    for index in range(IntegerNumbers.HEATMAP_MAX_VALUE):
        color_index = IntegerNumbers.HEATMAP_MAX_VALUE - 1 - index
        color = HeatmapBlueRedColors[f"color_{color_index:02d}"].value
        y_top = legend_y1 - index * block_height
        y_bottom = y_top - block_height
        y_mid = (y_top + y_bottom) / 2

        # rectangle color
        shapes_legend.append(dict(
            type="rect",
            xref="paper", yref="paper",
            x0=legend_x0, x1=legend_x1,
            y0=y_bottom, y1=y_top,
            fillcolor=color,
            line={"width": 0},
        ))

        # add annotations
        count = block_counts.get(color_index, 0)
        annotations_legend.append(dict(
            xref="paper", yref="paper",
            x=legend_x1 + 0.01,
            y=y_mid,
            text=f"{color_index + 1} ({count:,})",
            showarrow=False,
            font={"size": 9, "color": "black"},
            xanchor="left",
            yanchor="middle",
            textangle=0,
        ))

    # legend title
    annotations_legend.append(dict(
        xref="paper", yref="paper",
        x=(legend_x0 + legend_x1) / 2,
        y=legend_y1 + 0.03,
        text="<b>N</b>",
        showarrow=False,
        font={"size": 11, "color": "black"},
        xanchor="center",
        yanchor="bottom",
        textangle=0,
    ))

    # update layout
    fig.update_layout(
        shapes=shapes_legend,
        annotations=annotations_legend,
        margin={
            "r": (glob.config.resolution * 0.4),
        },
    )
    return fig


def update_ternary_heatmap() -> go.Figure:
    # get ternary
    ternary: go.Figure = glob.figures.ternary_heatmap


    df_grid = glob.general_bifurcation_data.data_ternary_grid_counts.get(BranchTypes.EMPIRICAL)
    bifurcation_columns = [b.value for b in BifurcationTypes if b.value in df_grid.columns]
    df_combined = df_grid.copy()
    df_combined["total_counts"] = df_combined[bifurcation_columns].sum(axis=1)

    # conteo de puntos por bloque de color
    block_counts: dict[int, int] = {}

    for index in range(IntegerNumbers.HEATMAP_MAX_VALUE):
        if (index + 1) < glob.config.heatmap_ternary_min_value:
            ternary.update_traces(a=[], b=[], c=[], selector={"name": f"color_{index:02d}"})
            block_counts[index] = 0
        else:
            df_filtered = df_combined[df_combined["total_counts"] >= (index + 1)].copy()
            if df_filtered.empty:
                ternary.update_traces(a=[], b=[], c=[], selector={"name": f"color_{index:02d}"})
                block_counts[index] = 0
            else:
                ternary.update_traces(
                    a=df_filtered["sl"],
                    b=df_filtered["sd"],
                    c=df_filtered["sr"],
                    marker={
                        "symbol": "hexagon",
                        "color": HeatmapBlueRedColors[f"color_{index:02d}"].value,
                        "size": 4,
                        "line": {"width": 0},
                    },
                    hovertemplate=(
                        f"<b>Total Bifurcaciones ({BranchTypes.EMPIRICAL.name})</b><br>"
                        f"{ParameterTypes.LOTKAVOLTERRA.value}: %{{a:.3f}}<br>"
                        f"{ParameterTypes.DONOR.value}: %{{b:.3f}}<br>"
                        f"{ParameterTypes.RECIPIENT.value}: %{{c:.3f}}<br>"
                        "Total: %{marker.color}<extra></extra>"
                    ),
                    selector={"name": f"color_{index:02d}"},
                )
                block_counts[index] = len(df_filtered)

    # update size
    ternary.update_layout(width=(glob.config.resolution * 2) + (glob.config.resolution * 0.2), height=glob.config.resolution * 2)

    # add heatmap legend
    ternary = add_heatmap_legend(ternary, block_counts)

    # return new ternary
    return ternary

