import plotly.graph_objects as go

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.types.bifurcation_types import BifurcationTypes
from food_web_bifurcation_explorer.enums.types.hopf_parameter_types import HopfParameterTypes


def update_hopf_parameter_plot(hopf_parameter_type: HopfParameterTypes, hopf_parameter_name: Labels, hopf_parameter_unit: Labels) -> go.Figure:
    # get figure
    fig: go.Figure = glob.figures.hopf_parameters[hopf_parameter_type]
    # check if redraw is needed
    if glob.config.drawing_options.redraw_hopf_bifurcation[hopf_parameter_type]:
        # update both traces
        for hopf_bifurcation in [BifurcationTypes.HOPF_SUBCRITICAL, BifurcationTypes.HOPF_SUPERCRITICAL]:
            fig.update_traces(
                selector={"name": hopf_bifurcation.value},
                x=glob.config.fixed_parameter_values,
                y=glob.plot_data.ternary_data.get_hopf_parameter_values(hopf_parameter_type, hopf_bifurcation),
                hovertemplate=(
                    hopf_parameter_type.value
                    + " ("
                    + hopf_bifurcation.value
                    + ")"
                    + "<br>"
                    + "Parameter: %{x}<br>"
                    + "Value: %{y:.10f} "
                    + hopf_parameter_unit.value
                    + " <extra></extra>"
                ),
            )
        glob.config.drawing_options.redraw_hopf_bifurcation[hopf_parameter_type] = False
    # update layout
    fig.update_layout(
        title="Evolution of " + hopf_parameter_name + " (" + hopf_parameter_unit + ")",
        xaxis_title=Labels.PARAMETERS_RANGE,
        yaxis_title=hopf_parameter_unit,
    )
    return fig
