import plotly.graph_objects as go

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.colors.bifurcation_colors import BifurcationColors
from food_web_bifurcation_explorer.enums.types.bifurcation_types import BifurcationTypes
from food_web_bifurcation_explorer.enums.types.hopf_parameter_types import HopfParameterTypes


def build_hopf_parameter_plot(hopf_parameter_type: HopfParameterTypes) -> go.Figure:
    # declare line width
    line_width = 4
    marker_width = 7
    # declare general figure
    fig = go.Figure()
    # subcritical trace
    fig.add_trace(
        go.Scattergl(
            name=BifurcationTypes.HOPF_SUBCRITICAL.value,
            x=[],
            y=[],
            mode="lines+markers",
            line={"color": BifurcationColors.HOPF_SUBCRITICAL_EMPIRICAL, "width": line_width},
            marker={"size": marker_width},
            showlegend=True,
        )
    )
    # supercritical trace
    fig.add_trace(
        go.Scattergl(
            name=BifurcationTypes.HOPF_SUPERCRITICAL.value,
            x=[],
            y=[],
            mode="lines+markers",
            line={"color": BifurcationColors.HOPF_SUPERCRITICAL_EMPIRICAL, "width": line_width},
            marker={"size": marker_width},
            showlegend=True,
        )
    )
    # draw special lines
    if hopf_parameter_type == HopfParameterTypes.L1:
        fig.add_hline(
            y=0,
            line_dash="dot",
            line_color="black",
            annotation_text="Bautin point frontier",
            annotation_position="bottom left",
        )
    elif hopf_parameter_type == HopfParameterTypes.OSCILLATION_FREQUENCY:
        fig.add_hline(
            y=0,
            line_dash="dot",
            line_color="black",
            annotation_text="Oscillation limit",
            annotation_position="bottom left",
        )
    elif hopf_parameter_type == HopfParameterTypes.TRANSVERSAL_CROSSING_SPEED:
        fig.add_hline(
            y=0,
            line_dash="dot",
            line_color="black",
            annotation_text="Change of direction",
            annotation_position="bottom left",
        )
    # update layout
    fig.update_layout(
        margin={"l": 0, "r": 0, "t": 50, "b": 0},
        showlegend=True,
        uirevision="hopf_parameter_plot_" + hopf_parameter_type.value,
        # set x values
        xaxis=dict(
            tickmode="linear",
            tick0=0,
            dtick=0.1,
        ),
        # set legend
        legend=dict(
            x=0.98,
            y=0.98,
            xanchor="right",
            yanchor="top",
            bgcolor="rgba(255,255,255,0.8)",
            bordercolor="black",
            borderwidth=1,
        ),
        # set sizes
        width=glob.config.resolution * 2,
        height=glob.config.resolution,
    )
    return fig
