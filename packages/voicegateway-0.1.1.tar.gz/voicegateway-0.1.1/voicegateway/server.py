"""VoiceGateway HTTP API server.

A thin FastAPI layer over the Gateway, exposing /health, /v1/status,
/v1/models, /v1/costs, /v1/projects, /v1/logs, and /v1/metrics.

This is what the dashboard consumes and what external monitoring tools
(Prometheus, load balancers) scrape.
"""

from __future__ import annotations

import logging
import time
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any

from fastapi import Depends, FastAPI, HTTPException, Query, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse

from voicegateway.core.auth import (
    AuthError,
    check_request,
    load_api_keys,
    resolve_cors_origins,
)
from voicegateway.pricing import catalog
from voicegateway.storage._percentiles import quantile_label

if TYPE_CHECKING:
    from voicegateway.core.gateway import Gateway

logger = logging.getLogger(__name__)


def _parse_iso_date(value: str, *, end_of_day: bool) -> float:
    """Parse a YYYY-MM-DD string into a UTC POSIX timestamp.

    With `end_of_day=True`, advance one day so the timestamp is the
    exclusive upper bound for "include all of YYYY-MM-DD."
    """
    try:
        d = datetime.strptime(value, "%Y-%m-%d").replace(tzinfo=UTC)
    except ValueError as e:
        raise HTTPException(
            status_code=400,
            detail=f"invalid date {value!r}: expected YYYY-MM-DD",
        ) from e
    if end_of_day:
        d += timedelta(days=1)
    return d.timestamp()


def build_app(gateway: Gateway) -> FastAPI:
    """Build a FastAPI app bound to the given Gateway instance."""
    app = FastAPI(
        title="VoiceGateway API",
        version="0.1.1",
        description="HTTP API for VoiceGateway: cost tracking and reconciliation for LiveKit voice agents.",
    )

    # Auth is opt-in. When no keys are configured, check_request passes
    # every request and require_scope becomes a no-op dependency.
    api_keys = load_api_keys(gateway.config.auth)
    cors_origins = resolve_cors_origins(gateway.config.auth)
    if cors_origins == ["*"]:
        logger.warning(
            "CORS: allow_origins=['*']. Set auth.cors_origins in "
            "voicegw.yaml to restrict."
        )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_methods=["*"],
        allow_headers=["*"],
        # Custom response headers are not visible to JavaScript on
        # cross-origin calls unless they are listed here. The dashboard
        # detects /v1/costs?period=...&start=... mixed-call deprecation
        # via the Deprecation response header, so it must be exposed.
        expose_headers=["Deprecation"],
    )

    def require_scope(scope: str):
        """Return a FastAPI dependency enforcing ``scope`` on a request."""

        async def _dep(request: Request) -> None:
            try:
                check_request(
                    request.headers.get("Authorization"),
                    scope,
                    api_keys,
                )
            except AuthError as exc:
                raise HTTPException(
                    status_code=exc.status_code, detail=exc.message
                ) from None

        return _dep

    write_dep = Depends(require_scope("write"))

    started_at = time.time()

    @app.get("/health")
    async def health() -> dict:
        return {
            "status": "ok",
            "uptime_seconds": round(time.time() - started_at, 1),
            "version": "0.1.1",
        }

    @app.get("/v1/status")
    async def v1_status() -> dict:
        cfg = gateway.config
        providers = {}
        for name, provider_cfg in cfg.providers.items():
            has_key = bool(provider_cfg.get("api_key")) or name in (
                "ollama",
                "whisper",
                "kokoro",
                "piper",
            )
            providers[name] = {
                "configured": has_key,
                "type": "local"
                if name in ("ollama", "whisper", "kokoro", "piper")
                else "cloud",
            }
        # Surface catalog freshness so the dashboard can render
        # "estimates last verified ..." copy without joining the
        # pricing tables itself. ``stt`` and ``tts`` carry both the
        # source string (logged on each request as ``pricing_source``)
        # and the oldest per-entry verification date so the UI can
        # show a yellow banner when any rate crossed a staleness
        # threshold. ``llm`` derives its source from the
        # ``genai-prices`` library version; the upstream catalog is
        # versioned, not date-stamped.
        from voicegateway.pricing import llm as _llm_pricing
        from voicegateway.pricing import stt as _stt_pricing
        from voicegateway.pricing import tts as _tts_pricing

        pricing = {
            "llm": {"source": _llm_pricing.PRICING_SOURCE},
            "stt": {
                "source": _stt_pricing.PRICING_SOURCE,
                "oldest_entry_date": _stt_pricing._oldest_pricing_date().isoformat(),
            },
            "tts": {
                "source": _tts_pricing.PRICING_SOURCE,
                "oldest_entry_date": _tts_pricing._oldest_pricing_date().isoformat(),
            },
        }
        return {
            "providers": providers,
            "model_count": sum(
                len(v) for v in cfg.models.values() if isinstance(v, dict)
            ),
            "project_count": len(cfg.projects),
            "pricing": pricing,
        }

    @app.get("/v1/models")
    async def v1_models(
        project: str | None = Query(None),
    ) -> dict:
        cfg = gateway.config
        models: dict[str, dict[str, Any]] = {}
        for modality, modality_models in cfg.models.items():
            if not isinstance(modality_models, dict):
                continue
            for model_id, model_cfg in modality_models.items():
                if not isinstance(model_cfg, dict):
                    continue
                models[model_id] = {
                    "modality": modality,
                    "provider": model_cfg.get("provider", ""),
                    "model": model_cfg.get("model", ""),
                }

        # Optionally filter to models used by a project's default stack
        if project:
            pcfg = cfg.get_project(project)
            if pcfg and pcfg.default_stack and pcfg.default_stack in cfg.stacks:
                wanted = set(cfg.stacks[pcfg.default_stack].values())
                models = {k: v for k, v in models.items() if k in wanted}

        return {"models": models, "project": project}

    @app.get("/v1/costs")
    async def v1_costs(
        response: Response,
        period: str | None = Query(None),
        project: str | None = Query(None),
        per_modality: bool = Query(False),
        include_pricing_source: bool = Query(True),
        start: str | None = Query(None),
        end: str | None = Query(None),
    ) -> dict:
        # Top-level `pricing_sources` records the catalog the running
        # instance is currently using (per modality). With
        # `include_pricing_source=true` (the default since v0.0.5),
        # each `by_model` entry also carries the source(s) that priced
        # its historical records, which is what the dashboard's
        # cost-staleness banner and `voicegw reconcile` against an
        # invoice both need. Pass `?include_pricing_source=false` to
        # opt out of the per-row attribution.
        pricing_sources = {
            modality: catalog.pricing_source(modality)
            for modality in ("llm", "stt", "tts")
        }
        # Backward-compat: when neither period nor a window is given,
        # fall back to "today" (the legacy default). Existing dashboard
        # callers that omit all three see no behavior change.
        period_explicit = period is not None
        effective_period = period if period is not None else "today"
        # Deprecation header: when the caller mixes the legacy `period`
        # with new-API `start`/`end`, the new params win at the
        # storage layer. Surface a Deprecation header so dashboards
        # mid-migration discover the redundancy.
        if period_explicit and (start or end):
            response.headers["Deprecation"] = (
                "period parameter is ignored when start/end are "
                "provided. Drop period from new-API calls."
            )
        # Explicit start/end ISO dates (YYYY-MM-DD) override `period`.
        # Both bounds are interpreted at UTC midnight; `end` is the
        # inclusive day, so internally we advance one day for the
        # exclusive upper bound. Either bound is independently optional.
        start_ts = _parse_iso_date(start, end_of_day=False) if start else None
        end_ts = _parse_iso_date(end, end_of_day=True) if end else None
        if gateway.storage is None:
            empty: dict[str, Any] = {
                "period": effective_period,
                "project": project,
                "total": 0.0,
                "by_provider": {},
                "by_model": {},
                "by_project": {},
                "pricing_sources": pricing_sources,
            }
            if per_modality:
                empty["by_modality"] = {}
            return empty
        summary = await gateway.storage.get_cost_summary(
            effective_period,
            project=project,
            include_pricing_source=include_pricing_source,
            start_ts=start_ts,
            end_ts=end_ts,
        )
        # Always include a by_project breakdown for the "All Projects" view
        if project is None:
            summary["by_project"] = await gateway.storage.get_cost_by_project(
                effective_period, start_ts=start_ts, end_ts=end_ts
            )
        else:
            summary["by_project"] = {}
        if per_modality:
            summary["by_modality"] = await gateway.storage.get_cost_by_modality(
                effective_period,
                project=project,
                start_ts=start_ts,
                end_ts=end_ts,
            )
        summary["pricing_sources"] = pricing_sources
        return summary

    @app.get("/v1/latency")
    async def v1_latency(
        period: str = Query("today"),
        project: str | None = Query(None),
    ) -> dict:
        if gateway.storage is None:
            return {}
        pcts = gateway.config.latency.get("percentiles") or [50.0, 95.0, 99.0]
        return await gateway.storage.get_latency_stats(
            period, project=project, percentiles=pcts
        )

    @app.get("/v1/projects")
    async def v1_projects() -> dict:
        """List configured projects with today's stats."""
        projects = gateway.list_projects()
        stats: dict[str, Any] = {}
        if gateway.storage is not None:
            for p in projects:
                pid = p["id"]
                stats[pid] = await gateway.storage.get_project_stats(pid)
        return {"projects": projects, "stats": stats}

    @app.get("/v1/projects/{project_id}")
    async def v1_project_detail(project_id: str) -> dict:
        pcfg = gateway.config.get_project(project_id)
        if pcfg is None:
            return {"error": f"project not found: {project_id}"}
        data: dict[str, Any] = {
            "id": pcfg.id,
            "name": pcfg.name,
            "description": pcfg.description,
            "daily_budget": pcfg.daily_budget,
            "budget_action": pcfg.budget_action,
            "default_stack": pcfg.default_stack,
            "tags": list(pcfg.tags),
            "accent": pcfg.accent,
            "today_spend": 0.0,
            "budget_status": "ok",
        }
        if gateway.storage is not None:
            data["today"] = await gateway.storage.get_project_stats(project_id)
            costs_today = await gateway.storage.get_cost_summary(
                "today", project=project_id
            )
            data["costs_today"] = costs_today
            today_spend = costs_today.get("total", 0.0)
            data["today_spend"] = today_spend
            enforcer = gateway._budget_enforcer
            data["budget_status"] = enforcer.get_budget_status(project_id, today_spend)
        return data

    @app.get("/v1/logs")
    async def v1_logs(
        limit: int = Query(100, ge=1, le=1000),
        modality: str | None = Query(None),
        project: str | None = Query(None),
    ) -> list[dict]:
        if gateway.storage is None:
            return []
        return await gateway.storage.get_recent_requests(
            limit=limit, modality=modality, project=project
        )

    @app.get("/v1/sessions")
    async def v1_sessions(
        limit: int = Query(100, ge=1, le=1000),
        project: str | None = Query(None),
        order_by: str = Query(
            "started_at_desc",
            pattern="^(started_at_desc|started_at_asc|cost_desc|cost_asc)$",
        ),
    ) -> list[dict]:
        """Return recent voice sessions, ordered per ``order_by``.

        Sessions are populated by the v0.0.5 inference module via
        ContextVar correlation; rows accumulate cost and request count
        over the life of one logical voice session. ``ended_at``
        tracks last activity (the timestamp of the most recent
        request) so duration is queryable without a session-close
        hook. ``order_by`` defaults to newest first; pass
        ``cost_desc`` to find the most expensive sessions.
        """
        if gateway.storage is None:
            return []
        return await gateway.storage.list_sessions(
            limit=limit, project=project, order_by=order_by
        )

    @app.get("/v1/sessions/{session_id}")
    async def v1_session_detail(session_id: str) -> dict:
        """Return one session by id with a per-modality cost breakdown.

        The response includes ``by_modality`` (a dict keyed by
        ``"stt"`` / ``"llm"`` / ``"tts"`` with ``cost`` and
        ``request_count``) and ``providers`` (deduplicated list of
        provider names seen in this session). Both are computed by
        joining the ``requests`` table on ``session_id`` at read
        time. 404 when no session matches.
        """
        if gateway.storage is None:
            raise HTTPException(
                status_code=404, detail=f"Session '{session_id}' not found"
            )
        row = await gateway.storage.get_session(session_id)
        if row is None:
            raise HTTPException(
                status_code=404, detail=f"Session '{session_id}' not found"
            )
        return row

    @app.get("/v1/metrics", response_class=PlainTextResponse)
    async def v1_metrics() -> str:
        """Prometheus-format metrics."""
        lines = [
            "# HELP voicegw_uptime_seconds Process uptime",
            "# TYPE voicegw_uptime_seconds gauge",
            f"voicegw_uptime_seconds {time.time() - started_at:.1f}",
            "# HELP voicegw_providers_configured Configured providers",
            "# TYPE voicegw_providers_configured gauge",
            f"voicegw_providers_configured {len(gateway.config.providers)}",
            "# HELP voicegw_projects_configured Configured projects",
            "# TYPE voicegw_projects_configured gauge",
            f"voicegw_projects_configured {len(gateway.config.projects)}",
        ]

        if gateway.storage is not None:
            today = await gateway.storage.get_cost_summary("today")
            lines += [
                "# HELP voicegw_cost_usd_total Total cost in USD (today)",
                "# TYPE voicegw_cost_usd_total counter",
                f'voicegw_cost_usd_total{{period="today"}} {today["total"]:.6f}',
                "# HELP voicegw_requests_total Total requests (today)",
                "# TYPE voicegw_requests_total counter",
            ]
            for provider, data in today.get("by_provider", {}).items():
                lines.append(
                    f'voicegw_requests_total{{provider="{provider}"}} {data["requests"]}'
                )
                lines.append(
                    f'voicegw_cost_usd_total{{provider="{provider}"}} {data["cost"]:.6f}'
                )

            by_project = await gateway.storage.get_cost_by_project("today")
            for pid, data in by_project.items():
                lines.append(
                    f'voicegw_cost_usd_total{{project="{pid}"}} {data["cost"]:.6f}'
                )

            # Per-model latency summaries. Prometheus ``summary`` convention:
            # one series per quantile label, values in seconds.
            pcts = gateway.config.latency.get("percentiles") or [50.0, 95.0, 99.0]
            latency = await gateway.storage.get_latency_stats("today", percentiles=pcts)
            if latency:
                lines += [
                    "# HELP voicegw_request_ttfb_seconds "
                    "Per-model time to first byte (seconds, summary)",
                    "# TYPE voicegw_request_ttfb_seconds summary",
                    "# HELP voicegw_request_total_latency_seconds "
                    "Per-model total latency (seconds, summary)",
                    "# TYPE voicegw_request_total_latency_seconds summary",
                ]
                for model, s in latency.items():
                    for p in pcts:
                        key = f"p{int(p)}"
                        q = quantile_label(p)
                        ttfb_v = s.get("ttfb_percentiles", {}).get(key)
                        if ttfb_v is not None:
                            lines.append(
                                f"voicegw_request_ttfb_seconds"
                                f'{{model="{model}",quantile="{q}"}} '
                                f"{ttfb_v / 1000:.6f}"
                            )
                        lat_v = s.get("latency_percentiles", {}).get(key)
                        if lat_v is not None:
                            lines.append(
                                f"voicegw_request_total_latency_seconds"
                                f'{{model="{model}",quantile="{q}"}} '
                                f"{lat_v / 1000:.6f}"
                            )

        return "\n".join(lines) + "\n"

    # ------------------------------------------------------------------
    # CRUD — Providers
    # ------------------------------------------------------------------

    @app.get("/v1/providers")
    async def v1_list_providers() -> dict:
        from voicegateway.core.crypto import mask

        result = []
        for name, pcfg in gateway.config.providers.items():
            api_key = pcfg.get("api_key", "") if isinstance(pcfg, dict) else ""
            source = pcfg.get("_source", "yaml") if isinstance(pcfg, dict) else "yaml"
            result.append(
                {
                    "provider_id": name,
                    "source": source,
                    "api_key_masked": mask(api_key)
                    if source != "db"
                    else mask(api_key),
                    "base_url": pcfg.get("base_url")
                    if isinstance(pcfg, dict)
                    else None,
                }
            )
        return {"providers": result}

    @app.post("/v1/providers", dependencies=[write_dep])
    async def v1_create_provider(body: dict[str, Any]) -> dict:
        from voicegateway.core.crypto import mask
        from voicegateway.core.registry import _PROVIDER_REGISTRY

        pid = body.get("provider_id", "")
        ptype = body.get("provider_type", pid)
        api_key = body.get("api_key", "")
        base_url = body.get("base_url")
        # v0.0.5: optional per-project scope. When set, the row's
        # project column is populated so the dashboard's
        # /api/providers/by-project endpoint surfaces it under that
        # project. Pre-v0.0.5 callers omit this field; the column
        # stays NULL (legacy global semantics).
        project = body.get("project")

        if not pid or not isinstance(pid, str):
            raise HTTPException(400, "provider_id is required and must be a string")
        if ptype not in _PROVIDER_REGISTRY:
            raise HTTPException(400, f"Unknown provider_type '{ptype}'")
        if pid in gateway.config.providers:
            is_managed = (
                isinstance(gateway.config.providers[pid], dict)
                and gateway.config.providers[pid].get("_source") == "db"
            )
            if not is_managed:
                raise HTTPException(409, f"Provider '{pid}' already exists in YAML")
        # When the caller scopes the row to a project, also reject if the
        # YAML already pins that project's slot for this provider type.
        # Without this check the DB row writes successfully but
        # ConfigManager.load_merged keeps the YAML entry, so the rotated
        # credential silently never gets used.
        if project:
            existing_project = gateway.config.projects.get(project)
            if existing_project is not None and ptype in existing_project.providers:
                yaml_entry = existing_project.providers[ptype]
                yaml_pinned = (
                    not isinstance(yaml_entry, dict)
                    or yaml_entry.get("_source") != "db"
                )
                if yaml_pinned:
                    raise HTTPException(
                        409,
                        f"Provider '{ptype}' is already pinned in YAML at "
                        f"projects.{project}.providers.{ptype}; "
                        "remove it from voicegw.yaml before creating a "
                        "managed override.",
                    )
        if gateway.storage is None:
            raise HTTPException(400, "Storage not enabled")

        await gateway.storage.upsert_managed_provider(
            pid, ptype, api_key, base_url, project=project
        )
        audit_body = {**body, "api_key": "<redacted>"} if "api_key" in body else body
        await gateway.storage.log_audit_event(
            "provider", pid, "create", audit_body, "api"
        )
        await gateway.refresh_config()

        return {
            "provider_id": pid,
            "source": "db",
            "api_key_masked": mask(api_key),
            "project": project,
        }

    @app.patch("/v1/providers/{provider_id}", dependencies=[write_dep])
    async def v1_update_provider(provider_id: str, body: dict[str, Any]) -> dict:
        from voicegateway.core.registry import _PROVIDER_REGISTRY

        if gateway.storage is None:
            raise HTTPException(400, "Storage not enabled")
        existing = await gateway.storage.get_managed_provider(provider_id)
        if existing is None:
            raise HTTPException(404, f"No managed provider '{provider_id}'")

        from voicegateway.core.crypto import decrypt

        current_key = decrypt(existing.get("api_key_encrypted", ""))
        api_key = body.get("api_key", current_key)
        base_url = body.get("base_url", existing.get("base_url"))
        ptype = body.get("provider_type", existing["provider_type"])
        if ptype not in _PROVIDER_REGISTRY:
            raise HTTPException(400, f"Unknown provider_type '{ptype}'")

        # Preserve the row's existing project scope on PATCH unless the
        # caller explicitly overrides it. Rotating a per-project key
        # MUST NOT silently demote it to global scope.
        project = body.get("project", existing.get("project"))

        await gateway.storage.upsert_managed_provider(
            provider_id, ptype, api_key, base_url, project=project
        )
        audit_body = {**body, "api_key": "<redacted>"} if "api_key" in body else body
        await gateway.storage.log_audit_event(
            "provider", provider_id, "update", audit_body, "api"
        )
        await gateway.refresh_config()
        return {"provider_id": provider_id, "updated": True}

    @app.delete("/v1/providers/{provider_id}", dependencies=[write_dep])
    async def v1_delete_provider(
        provider_id: str,
        confirm: bool = Query(False),
    ) -> dict:
        if gateway.storage is None:
            raise HTTPException(400, "Storage not enabled")
        managed = await gateway.storage.get_managed_provider(provider_id)
        if managed is None:
            if provider_id in gateway.config.providers:
                raise HTTPException(
                    403,
                    f"Provider '{provider_id}' is YAML-defined and cannot be deleted",
                )
            raise HTTPException(404, f"No provider '{provider_id}'")

        if not confirm:
            return {"would_delete": {"provider_id": provider_id}}
        await gateway.storage.delete_managed_provider(provider_id)
        await gateway.storage.log_audit_event(
            "provider", provider_id, "delete", None, "api"
        )
        await gateway.refresh_config()
        return {"deleted": provider_id}

    async def _resolve_test_target(
        provider_id: str,
    ) -> tuple[str | None, dict[str, Any] | None]:
        """Return ``(provider_type, provider_config)`` for the test path.

        Resolution order matches the v0.0.5 wedge:

        1. Top-level ``providers.<id>`` (legacy global config).
        2. DB-managed ``managed_providers`` row keyed by id (covers
           the composite ``"<project>:<provider>"`` rows written by
           ``vg_add_provider``). Returns the row's actual
           ``provider_type`` and decrypted api_key.
        3. YAML per-project ``projects.<project>.providers.<provider>``
           when the id is in composite form. Returns the YAML entry
           verbatim with ``provider_type`` derived from the suffix.

        Returns ``(None, None)`` if no matching entry exists.
        """
        cfg = gateway.config

        # 1. Top-level providers (also catches DB rows merged in via
        # ConfigManager.load_merged when they have no project scope).
        if provider_id in cfg.providers:
            pcfg = cfg.providers[provider_id]
            if isinstance(pcfg, dict):
                # If the merged dict came from the DB, ConfigManager
                # tagged it with `_source: "db"` but did not populate
                # provider_type — fall through to the storage lookup.
                if pcfg.get("_source") != "db":
                    return provider_id, dict(pcfg)

        # 2. Storage-side managed_providers row (the canonical place
        # where provider_type lives for DB-managed rows, including
        # the per-project composite ids written by vg_add_provider).
        if gateway.storage is not None:
            row = await gateway.storage.get_managed_provider(provider_id)
            if row is not None:
                from voicegateway.core.crypto import decrypt

                return row["provider_type"], {
                    "api_key": decrypt(row.get("api_key_encrypted", "")),
                    "base_url": row.get("base_url"),
                    **(row.get("extra_config") or {}),
                }

        # 3. YAML per-project entry: id has the form "<project>:<provider>".
        if ":" in provider_id:
            project, _, provider_type = provider_id.partition(":")
            project_cfg = cfg.projects.get(project)
            if project_cfg is not None and provider_type in project_cfg.providers:
                return provider_type, dict(project_cfg.providers[provider_type])

        return None, None

    @app.post("/v1/providers/{provider_id}/test", dependencies=[write_dep])
    async def v1_test_provider(provider_id: str) -> dict:
        import asyncio as _asyncio
        import logging as _logging

        from voicegateway.core.registry import _PROVIDER_REGISTRY, create_provider

        _test_log = _logging.getLogger(__name__)
        ptype, pcfg = await _resolve_test_target(provider_id)
        if pcfg is None:
            raise HTTPException(404, f"No provider '{provider_id}'")
        if ptype not in _PROVIDER_REGISTRY:
            return {
                "status": "failed",
                "message": f"Unknown type '{ptype}'",
                "latency_ms": 0,
            }
        try:
            inst = create_provider(ptype, pcfg)
            start = time.time()
            ok = await _asyncio.wait_for(inst.health_check(), timeout=10.0)
            latency_ms = int((time.time() - start) * 1000)
        except TimeoutError:
            return {
                "status": "failed",
                "message": "Provider health check timed out",
                "latency_ms": 10000,
            }
        except Exception as exc:  # noqa: BLE001
            _test_log.warning("Provider test for '%s' failed: %s", provider_id, exc)
            return {
                "status": "failed",
                "message": "Provider health check failed",
                "latency_ms": 0,
            }
        return {"status": "ok" if ok else "failed", "latency_ms": latency_ms}

    @app.post("/v1/providers/test", dependencies=[write_dep])
    async def v1_test_provider_stateless(body: dict[str, Any]) -> dict:
        """Stateless health check: takes provider_type + api_key + base_url,
        runs the provider's health_check, returns the same shape as the
        id-based variant. Persists nothing.

        Used by the dashboard's "Test Connection" button on the Add
        Provider modal so the test does not have to round-trip a
        sentinel managed_providers row.
        """
        import asyncio as _asyncio
        import logging as _logging

        from voicegateway.core.registry import _PROVIDER_REGISTRY, create_provider

        _stateless_log = _logging.getLogger(__name__)
        ptype = body.get("provider_type", "")
        if ptype not in _PROVIDER_REGISTRY:
            return {
                "status": "failed",
                "message": f"Unknown provider_type '{ptype}'",
                "latency_ms": 0,
            }
        cfg: dict[str, Any] = {
            "api_key": body.get("api_key", ""),
            "base_url": body.get("base_url"),
        }
        try:
            inst = create_provider(ptype, cfg)
            start = time.time()
            ok = await _asyncio.wait_for(inst.health_check(), timeout=10.0)
            latency_ms = int((time.time() - start) * 1000)
        except TimeoutError:
            return {
                "status": "failed",
                "message": "Provider health check timed out",
                "latency_ms": 10000,
            }
        except Exception as exc:  # noqa: BLE001
            _stateless_log.warning(
                "Stateless provider test for '%s' failed: %s", ptype, exc
            )
            return {
                "status": "failed",
                "message": "Provider health check failed",
                "latency_ms": 0,
            }
        return {"status": "ok" if ok else "failed", "latency_ms": latency_ms}

    # ------------------------------------------------------------------
    # CRUD — Models
    # ------------------------------------------------------------------

    @app.post("/v1/models", dependencies=[write_dep])
    async def v1_create_model(body: dict[str, Any]) -> dict:
        if gateway.storage is None:
            raise HTTPException(400, "Storage not enabled")
        modality = body.get("modality", "")
        provider_id = body.get("provider_id", "")
        model_name = body.get("model_name", "")
        model_id = f"{provider_id}/{model_name}"

        if provider_id not in gateway.config.providers:
            raise HTTPException(400, f"Provider '{provider_id}' not configured")
        yaml_bucket = gateway.config.models.get(modality, {})
        if model_id in yaml_bucket:
            raise HTTPException(409, f"Model '{model_id}' already exists")

        await gateway.storage.upsert_managed_model(
            model_id=model_id,
            modality=modality,
            provider_id=provider_id,
            model_name=model_name,
            display_name=body.get("display_name"),
            default_language=body.get("default_language"),
            default_voice=body.get("default_voice"),
            extra_config=body.get("config"),
        )
        await gateway.storage.log_audit_event("model", model_id, "create", body, "api")
        await gateway.refresh_config()
        return {"model_id": model_id, "source": "db", "created": True}

    @app.delete("/v1/models/{model_id:path}", dependencies=[write_dep])
    async def v1_delete_model(model_id: str, confirm: bool = Query(False)) -> dict:
        if gateway.storage is None:
            raise HTTPException(400, "Storage not enabled")
        managed = await gateway.storage.get_managed_model(model_id)
        if managed is None:
            for mm in gateway.config.models.values():
                if isinstance(mm, dict) and model_id in mm:
                    raise HTTPException(403, f"Model '{model_id}' is YAML-defined")
            raise HTTPException(404, f"No model '{model_id}'")
        if not confirm:
            return {"would_delete": {"model_id": model_id}}
        await gateway.storage.delete_managed_model(model_id)
        await gateway.storage.log_audit_event("model", model_id, "delete", None, "api")
        await gateway.refresh_config()
        return {"deleted": model_id}

    # ------------------------------------------------------------------
    # CRUD — Projects
    # ------------------------------------------------------------------

    @app.post("/v1/projects", dependencies=[write_dep])
    async def v1_create_project(body: dict[str, Any]) -> dict:
        if gateway.storage is None:
            raise HTTPException(400, "Storage not enabled")
        pid = body.get("project_id", "")
        if pid in gateway.config.projects:
            raise HTTPException(409, f"Project '{pid}' already exists")
        await gateway.storage.upsert_managed_project(
            project_id=pid,
            name=body.get("name", pid),
            description=body.get("description", ""),
            daily_budget=float(body.get("daily_budget", 0.0)),
            budget_action=body.get("budget_action", "warn"),
            default_stack=body.get("default_stack"),
            stt_model=body.get("stt_model"),
            llm_model=body.get("llm_model"),
            tts_model=body.get("tts_model"),
            tags=body.get("tags"),
        )
        await gateway.storage.log_audit_event("project", pid, "create", body, "api")
        await gateway.refresh_config()
        return {"project_id": pid, "source": "db", "created": True}

    @app.patch("/v1/projects/{project_id}", dependencies=[write_dep])
    async def v1_update_project(project_id: str, body: dict[str, Any]) -> dict:
        if gateway.storage is None:
            raise HTTPException(400, "Storage not enabled")
        managed = await gateway.storage.get_managed_project(project_id)
        if managed is None:
            raise HTTPException(404, f"No managed project '{project_id}'")
        await gateway.storage.upsert_managed_project(
            project_id=project_id,
            name=body.get("name", managed["name"]),
            description=body.get("description", managed.get("description", "")),
            daily_budget=float(
                body.get("daily_budget", managed.get("daily_budget", 0.0))
            ),
            budget_action=body.get(
                "budget_action", managed.get("budget_action", "warn")
            ),
            default_stack=body.get("default_stack", managed.get("default_stack")),
            stt_model=body.get("stt_model", managed.get("stt_model")),
            llm_model=body.get("llm_model", managed.get("llm_model")),
            tts_model=body.get("tts_model", managed.get("tts_model")),
            tags=body.get("tags", managed.get("tags")),
        )
        await gateway.storage.log_audit_event(
            "project", project_id, "update", body, "api"
        )
        await gateway.refresh_config()
        return {"project_id": project_id, "updated": True}

    @app.delete("/v1/projects/{project_id}", dependencies=[write_dep])
    async def v1_delete_project(project_id: str, confirm: bool = Query(False)) -> dict:
        if gateway.storage is None:
            raise HTTPException(400, "Storage not enabled")
        managed = await gateway.storage.get_managed_project(project_id)
        if managed is None:
            if project_id in gateway.config.projects:
                raise HTTPException(403, f"Project '{project_id}' is YAML-defined")
            raise HTTPException(404, f"No project '{project_id}'")
        if not confirm:
            return {"would_delete": {"project_id": project_id}}
        await gateway.storage.delete_managed_project(project_id)
        await gateway.storage.log_audit_event(
            "project", project_id, "delete", None, "api"
        )
        await gateway.refresh_config()
        return {"deleted": project_id}

    # ------------------------------------------------------------------
    # Audit log
    # ------------------------------------------------------------------

    @app.get("/v1/audit-log")
    async def v1_audit_log(
        limit: int = Query(50, ge=1, le=500),
        entity_type: str | None = Query(None),
        entity_id: str | None = Query(None),
        action: str | None = Query(None),
    ) -> list[dict]:
        if gateway.storage is None:
            return []
        return await gateway.storage.get_audit_log(
            limit=limit,
            entity_type=entity_type,
            entity_id=entity_id,
            action=action,
        )

    return app
