"""Per-agent runtime tunnel to a Butt-Dial MCP server.

The :class:`Agent` is a thin client that holds three things:

- ``base_url``    — BD server root (the SSE endpoint is ``<base>/sse``)
- ``agent_id``    — host-supplied UUID for this agent. BD echoes it on
  registration but does not generate it; the host owns identity.
- ``agent_token`` — per-agent runtime bearer token

The Agent is intentionally narrow: it sends and receives. Org-level
admin work (registering this agent, rotating tokens, billing) lives on
:class:`buttdial.AccountsClient` with its own ``team_token``.

Token resolution
----------------

Per-call ``agent_token`` overrides the instance default — useful for
multi-tenant hosts that hold one ``Agent`` for transport but multiplex
different agent tokens onto it. If neither is set, ``send_message``
returns ``SendResult(failed=True, stage_failed="config")``.

Retries + auth contract
-----------------------

3 attempts with exponential backoff (2s, 4s, 8s, capped at 10s). On
exhaustion, returns ``SendResult(failed=True)`` — does not raise.

Auth errors (``AuthInvalidTokenError``, ``RevokedToken`` /
``AuthTokenRevokedError``, ``AuthMissingHeaderError``) propagate
immediately as typed exceptions — they are ``retryable=false`` per BD's
contract, and naive retry walks straight into the per-IP brute-force
lockout.

WhatsApp actions
----------------

Beyond ``send_message`` the Agent exposes :meth:`whatsapp_action` and
13 typed helpers (``typing``, ``mark_read``, ``react``, ``edit``,
``forward``, ``delete``, ``send_poll``, ``send_buttons``,
``send_location``, ``send_contact``, ``post_status``, ``set_chat_ttl``,
``send_view_once``) that wrap BD's ``comms_whatsapp_action`` MCP tool.
Provider mismatches (e.g. greenapi cannot ``post_status``) raise
:class:`ProviderCapabilityError`.
"""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from typing import Any

from buttdial._http import check_deprecation_headers, user_agent
from buttdial.errors import (
    AuthInvalidTokenError,
    AuthMissingHeaderError,
    AuthTokenRevokedError,
    ConfigError,
    ProviderCapabilityError,
)
from buttdial.models import Channel, SendResult
from buttdial.settings import load as load_settings

logger = logging.getLogger(__name__)

SEND_TOOL = "comms_send_message"
WA_ACTION_TOOL = "comms_whatsapp_action"


# Server-error substring → remediation text. Used when BD returns a
# business-level ``{"error": "..."}`` so callers see actionable next
# steps, not just the raw server string.
_SERVER_ERROR_REMEDIATIONS: list[tuple[str, str]] = [
    (
        "agentid is required",
        "This tool needs agent context. Either pass `agent_token=<per-agent token>` "
        "to send_message(), or construct Agent(..., agent_token=<per-agent token>).",
    ),
    (
        "agent id is required",
        "Pass `agent_token=<per-agent token>` or set agent_token on the Agent constructor.",
    ),
    (
        "invalid recipient",
        "Recipient must be E.164 format (+country code). Example: +14155550123.",
    ),
    (
        "invalid_recipient",
        "Recipient must be E.164 format (+country code). Example: +14155550123.",
    ),
    (
        "consent",
        "Recipient has not consented / is opted out. Check the opt-in status "
        "before sending, or configure consent-on-first-message in the Butt-Dial admin console.",
    ),
    (
        "rate limit",
        "Rate limit hit. Back off and retry with exponential delay, or request a higher quota.",
    ),
    (
        "not provisioned",
        "The sending channel is not provisioned for this team. Provision the channel "
        "in the Butt-Dial admin console before sending.",
    ),
]


def _server_error_remediation(error_text: str) -> str | None:
    """Map a server-returned error string to an actionable remediation. None if unknown."""
    lower = (error_text or "").lower()
    for trigger, remedy in _SERVER_ERROR_REMEDIATIONS:
        if trigger in lower:
            return remedy
    return None


# WhatsApp actions the SDK knows about. Used to short-circuit unknown
# actions before hitting the wire. The server is the authority on what
# each provider supports — we surface mismatches via
# :class:`ProviderCapabilityError` from the response.
_WA_ACTIONS = frozenset(
    {
        "typing",
        "mark_read",
        "react",
        "edit",
        "forward",
        "delete",
        "send_poll",
        "send_buttons",
        "send_location",
        "send_contact",
        "post_status",
        "set_chat_ttl",
        "send_view_once",
    }
)


class Agent:
    """Per-agent runtime tunnel to a Butt-Dial MCP server.

    Parameters
    ----------
    base_url:
        BD server root (without ``/sse`` and without ``/api/...``).
        Example: ``"https://call.95percent.ai"``. The Agent appends
        ``/sse`` for MCP and ``/api/v1/...`` for REST internally.
    agent_id:
        Host-chosen UUID for this agent. Optional — required only by
        actions that resolve agent context server-side.
    agent_token:
        Per-agent runtime bearer token. Required for all transport.
        Per-call ``agent_token`` overrides this (multi-tenant pattern).
    send_tool:
        MCP tool name for sending. Defaults to ``"comms_send_message"``.
    max_send_attempts:
        Retries for transient transport failures. Default 3.
    sse_timeout:
        SSE connect timeout in seconds. Default 30.
    """

    def __init__(
        self,
        base_url: str | None = None,
        *,
        agent_id: str | None = None,
        agent_token: str | None = None,
        send_tool: str = SEND_TOOL,
        max_send_attempts: int = 3,
        sse_timeout: float = 30.0,
    ) -> None:
        if not base_url:
            raise ValueError("Agent requires `base_url` (Butt-Dial server root).")
        cleaned = base_url.rstrip("/")
        # Tolerate base_url given with /sse already (legacy callers).
        if cleaned.endswith("/sse"):
            self.base_url = cleaned[:-4]
            self.sse_url = cleaned
        else:
            self.base_url = cleaned
            self.sse_url = f"{cleaned}/sse"
        self.agent_id = agent_id or ""
        self.agent_token = agent_token or ""
        self.send_tool = send_tool
        self.max_send_attempts = max_send_attempts
        self.sse_timeout = sse_timeout

    @classmethod
    def from_env(cls, **overrides: Any) -> Agent:
        """Build an Agent from ``BUTT_DIAL_*`` env vars."""
        s = load_settings()
        # Prefer BUTT_DIAL_BASE_URL; fall back to BUTT_DIAL_URL (legacy).
        base = overrides.pop("base_url", s.base_url or s.url)
        return cls(
            base_url=base,
            agent_id=overrides.pop("agent_id", s.agent_id),
            agent_token=overrides.pop("agent_token", s.agent_token),
            **overrides,
        )

    def _resolve_token(self, agent_token: str | None) -> str:
        return agent_token or self.agent_token

    # ----- send_message ---------------------------------------------------

    async def send_message(
        self,
        to: str,
        body: str | None = None,
        channel: Channel = "whatsapp",
        *,
        agent_token: str | None = None,
        media_url: str | None = None,
        sender_sid: str | None = None,
        sender_name: str | None = None,
        language: str | None = None,
        fallback_channels: list[str] | None = None,
        scheduled_at: str | None = None,
        thread_id: str | None = None,
        entity_id: str | None = None,
        reply_msg_id: str | None = None,
        idempotency_key: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> SendResult:
        """Send a single message via Butt-Dial.

        Either ``body`` or ``media_url`` must be set. ``sender_sid``
        explicitly routes through a specific provisioned number, which
        is how callers control provider failover (greenapi vs twilio
        vs waha) when the org has multiple senders.

        Returns a ``SendResult``; does not raise on transient failures
        (retried internally). On exhaustion returns
        ``SendResult(failed=True)`` with ``stage_failed`` +
        ``remediation`` set. Auth errors propagate as typed exceptions
        (``RevokedToken`` / ``AuthInvalidTokenError`` /
        ``AuthMissingHeaderError``) so the host can prompt re-auth
        instead of retrying into a lockout.
        """
        if not body and not media_url:
            return SendResult(
                failed=True,
                error="send_message requires either `body` or `media_url`",
                stage_failed="config",
                remediation="Pass body=... for text or media_url=... for media.",
            )

        token = self._resolve_token(agent_token)
        if not token:
            logger.error("send_message: no agent_token configured")
            return SendResult(
                failed=True,
                error="No Butt-Dial agent_token configured",
                stage_failed="config",
                remediation=(
                    "Set BUTT_DIAL_AGENT_TOKEN, or pass agent_token=... to "
                    "Agent(), or agent_token=... to send_message()."
                ),
            )

        args: dict[str, Any] = {
            "to": to,
            "channel": channel,
            "idempotencyKey": idempotency_key or str(uuid.uuid4()),
        }
        if body:
            args["body"] = body
        if media_url:
            # Server expects `media: [url, ...]` (array). The legacy
            # `mediaUrl` (singular) was silently dropped by the server's
            # Zod validator — see 0.5.1 release notes / docs/BD_SERVER_FEEDBACK.md.
            args["media"] = [media_url]
        if sender_sid:
            args["senderSid"] = sender_sid
        if sender_name:
            args["senderName"] = sender_name
        if language:
            args["language"] = language
        if fallback_channels:
            args["fallbackChannels"] = fallback_channels
        if scheduled_at:
            args["scheduledAt"] = scheduled_at
        # `threadId`/`entityId`/`replyMsgId` are accepted by BD's
        # `comms_send_message` schema (sprint-21+, confirmed 2026-05-08
        # in send-message.ts:132-134). The server records them for
        # observability and echoes them back in the response. `replyMsgId`
        # is documented to eventually drive WhatsApp `quotedMessageId` /
        # email `In-Reply-To` headers — not yet routed to providers.
        if thread_id:
            args["threadId"] = thread_id
        if entity_id:
            args["entityId"] = entity_id
        if reply_msg_id:
            args["replyMsgId"] = reply_msg_id
        if extra:
            args.update(extra)

        last_exc: BaseException | None = None
        parsed: Any = None
        raw: Any = None

        for attempt_num in range(self.max_send_attempts):
            try:
                parsed, raw = await self._call_tool(token, self.send_tool, args)
                last_exc = None
                break
            except (AuthInvalidTokenError, AuthTokenRevokedError, AuthMissingHeaderError):
                # `retryable=False` per BD's auth contract. Re-trying the
                # same bad credentials walks straight into the per-IP
                # brute-force lockout (10 fails → 15 min). Surface
                # immediately so the integrator can prompt for a fresh
                # token instead of looping.
                raise
            except Exception as exc:
                last_exc = exc
                logger.warning(
                    "send_message attempt %d/%d failed: %s",
                    attempt_num + 1,
                    self.max_send_attempts,
                    exc,
                )
                if attempt_num < self.max_send_attempts - 1:
                    delay = min(10.0, 2.0 ** (attempt_num + 1))
                    await asyncio.sleep(delay)

        if last_exc is not None:
            return SendResult(
                failed=True,
                error=str(last_exc),
                stage_failed="transport",
                remediation=(
                    "Check Butt-Dial server reachability and token validity — "
                    "run `buttdial doctor` for a staged diagnostic."
                ),
            )

        message_sid = self._extract_sid(parsed)
        if message_sid:
            logger.info("send_message: to=%s channel=%s sid=%s", to, channel, message_sid)
            return SendResult(message_sid=message_sid, raw=raw)

        # No SID — did the server tell us why?
        server_error = self._extract_server_error(parsed)
        if server_error:
            logger.warning("send_message: server returned error: %s", server_error)
            code, channel, server_remediation = self._extract_error_envelope(parsed)
            return SendResult(
                failed=True,
                error=server_error,
                error_code=code,
                error_channel=channel,
                stage_failed="server",
                # Prefer the server-supplied remediation when present (BD F90+).
                # Fall back to the SDK's curated remediation map.
                remediation=server_remediation or _server_error_remediation(server_error),
                raw=raw,
            )

        logger.warning("send_message: no message_sid and no error in response: %r", parsed)
        return SendResult(
            failed=True,
            error="server response contained no message_sid and no error",
            stage_failed="parse",
            remediation=(
                "Butt-Dial server returned an unrecognized response shape. "
                "Check the server version and the SDK's Agent.send_tool name."
            ),
            raw=raw,
        )

    # ----- WhatsApp actions ----------------------------------------------

    async def whatsapp_action(
        self,
        action: str,
        *,
        agent_token: str | None = None,
        sender_sid: str | None = None,
        **params: Any,
    ) -> dict[str, Any]:
        """Generic dispatch into ``comms_whatsapp_action``.

        Prefer the typed helpers (:meth:`typing`, :meth:`react`, etc.) —
        they pin the right argument names. This method is the escape
        hatch for forward-compat or actions added server-side that the
        SDK does not yet have a typed wrapper for.

        Raises :class:`ProviderCapabilityError` if BD rejects the
        provider/action combination (e.g. greenapi + post_status).
        Returns the parsed response dict (``{ok: bool, ...}`` or
        ``{messageId: ...}`` depending on action).
        """
        if action not in _WA_ACTIONS:
            raise ValueError(f"Unknown WhatsApp action {action!r}. Known: {sorted(_WA_ACTIONS)}")
        token = self._resolve_token(agent_token)
        if not token:
            raise ValueError("whatsapp_action requires agent_token (per-call or on the Agent).")
        args: dict[str, Any] = {"action": action, **params}
        if sender_sid:
            args["senderSid"] = sender_sid
        parsed, _raw = await self._call_tool(token, WA_ACTION_TOOL, args)
        # Translate BD's provider-capability error into a typed exception.
        if isinstance(parsed, dict):
            err_code = parsed.get("code")
            if err_code in ("PROVIDER_UNSUPPORTED", "CHANNEL_UNSUPPORTED"):
                raise ProviderCapabilityError(
                    str(parsed.get("error") or f"Provider does not support {action}"),
                    code=str(err_code),
                    action=action,
                    channel=parsed.get("channel"),
                    provider=parsed.get("provider"),
                    body=parsed,
                )
        return parsed if isinstance(parsed, dict) else {"raw": parsed}

    # Typed helpers — one per documented action. Argument names match
    # BD's MCP tool schema (camelCase preserved on the wire).

    async def typing(self, *, to: str, **kw: Any) -> dict[str, Any]:
        """Send a 'typing…' indicator."""
        return await self.whatsapp_action("typing", to=to, **kw)

    async def mark_read(self, *, messageId: str, **kw: Any) -> dict[str, Any]:
        """Mark a received message as read."""
        return await self.whatsapp_action("mark_read", messageId=messageId, **kw)

    async def react(self, *, messageId: str, emoji: str, **kw: Any) -> dict[str, Any]:
        """React to a message with an emoji."""
        return await self.whatsapp_action("react", messageId=messageId, emoji=emoji, **kw)

    async def edit(self, *, messageId: str, body: str, **kw: Any) -> dict[str, Any]:
        """Edit a previously-sent message's body."""
        return await self.whatsapp_action("edit", messageId=messageId, body=body, **kw)

    async def forward(self, *, messageId: str, to: str, **kw: Any) -> dict[str, Any]:
        """Forward a message to a new recipient."""
        return await self.whatsapp_action("forward", messageId=messageId, to=to, **kw)

    async def delete(self, *, messageId: str, **kw: Any) -> dict[str, Any]:
        """Delete (revoke) a previously-sent message."""
        return await self.whatsapp_action("delete", messageId=messageId, **kw)

    async def send_poll(
        self, *, to: str, title: str, options: list[str], **kw: Any
    ) -> dict[str, Any]:
        """Send a poll. Returns ``{messageId}``."""
        return await self.whatsapp_action("send_poll", to=to, title=title, options=options, **kw)

    async def send_buttons(
        self,
        *,
        to: str,
        body: str,
        buttons: list[dict[str, Any]],
        **kw: Any,
    ) -> dict[str, Any]:
        """Send an interactive-buttons message. Returns ``{messageId}``."""
        return await self.whatsapp_action("send_buttons", to=to, body=body, buttons=buttons, **kw)

    async def send_location(
        self,
        *,
        to: str,
        lat: float,
        lng: float,
        name: str | None = None,
        **kw: Any,
    ) -> dict[str, Any]:
        """Send a location pin. Returns ``{messageId}``."""
        if name is not None:
            kw["name"] = name
        return await self.whatsapp_action("send_location", to=to, lat=lat, lng=lng, **kw)

    async def send_contact(self, *, to: str, vcard: str, **kw: Any) -> dict[str, Any]:
        """Send a contact card (vCard). Returns ``{messageId}``."""
        return await self.whatsapp_action("send_contact", to=to, vcard=vcard, **kw)

    async def post_status(
        self, *, body: str, mediaUrl: str | None = None, **kw: Any
    ) -> dict[str, Any]:
        """Post a status / story.

        Provider-only: greenapi rejects this; only twilio supports it.
        Raises :class:`ProviderCapabilityError` on rejection.
        """
        if mediaUrl is not None:
            kw["mediaUrl"] = mediaUrl
        return await self.whatsapp_action("post_status", body=body, **kw)

    async def set_chat_ttl(self, *, chatId: str, ttlSeconds: int, **kw: Any) -> dict[str, Any]:
        """Set disappearing-message TTL on a chat."""
        return await self.whatsapp_action(
            "set_chat_ttl", chatId=chatId, ttlSeconds=ttlSeconds, **kw
        )

    async def send_view_once(
        self,
        *,
        to: str,
        mediaUrl: str,
        body: str | None = None,
        **kw: Any,
    ) -> dict[str, Any]:
        """Send a view-once media message. Returns ``{messageId}``."""
        if body is not None:
            kw["body"] = body
        return await self.whatsapp_action("send_view_once", to=to, mediaUrl=mediaUrl, **kw)

    # ----- internals -----------------------------------------------------

    async def _call_tool(
        self,
        token: str,
        tool_name: str,
        args: dict[str, Any],
    ) -> tuple[Any, Any]:
        """Open SSE, initialize session, invoke an MCP tool. Returns (parsed, raw_result)."""
        import httpx
        from mcp import ClientSession
        from mcp.client.sse import sse_client

        from buttdial.errors import AuthError as _AuthError

        headers = {
            "Authorization": f"Bearer {token}",
            "User-Agent": user_agent(),
        }
        try:
            async with sse_client(  # noqa: SIM117  (read,write tuple-unpack feeds the inner CM)
                self.sse_url, headers=headers, timeout=self.sse_timeout
            ) as (read, write):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    result = await session.call_tool(tool_name, arguments=args)
                    text = result.content[0].text if result.content else None
                    try:
                        parsed = json.loads(text) if text else None
                    except (json.JSONDecodeError, TypeError):
                        parsed = text
                    return parsed, result
        except httpx.HTTPStatusError as exc:
            self._raise_typed_error_for_response(exc.response)
            raise  # pragma: no cover - parse_error_response handles 401/429
        except _AuthError:
            raise

    @staticmethod
    def _raise_typed_error_for_response(response: Any) -> None:
        """Inspect an HTTP error response; raise typed BD error if recognized."""
        from buttdial.errors import parse_error_response

        status = getattr(response, "status_code", 0)
        if status not in (401, 429):
            return
        try:
            body = response.json()
        except Exception:
            body = None
        try:
            response_headers = dict(response.headers)
        except Exception:  # pragma: no cover - defensive
            response_headers = {}
        raise parse_error_response(
            status_code=status,
            body=body,
            headers=response_headers,
        )

    @staticmethod
    def _extract_sid(parsed: Any) -> str | None:
        if isinstance(parsed, dict):
            return parsed.get("messageId") or parsed.get("sid") or parsed.get("message_sid")
        return None

    @staticmethod
    def _extract_server_error(parsed: Any) -> str | None:
        """Pull a human-readable error text from a business-level failure response."""
        if not isinstance(parsed, dict):
            return None
        err = parsed.get("error")
        if isinstance(err, str) and err:
            return err
        errors = parsed.get("errors")
        if isinstance(errors, list) and errors:
            return "; ".join(str(e) for e in errors)
        return None

    @staticmethod
    def _extract_error_envelope(parsed: Any) -> tuple[str | None, str | None, str | None]:
        """Pull (code, channel, remediation) from BD's structured error envelope.

        BD's `/api/v1/*` envelopes ship as
            ``{"error": "...", "code": "NO_CHANNEL_ASSIGNED", "channel": "whatsapp",
               "remediation": "Call /provision first"}``
        Returns ``(None, None, None)`` for shapes the SDK doesn't recognize so
        existing string-based ``SendResult.error`` handling continues to work.
        """
        if not isinstance(parsed, dict):
            return (None, None, None)
        # Top-level shape (`{error, code, channel, remediation}`)
        code = parsed.get("code")
        channel = parsed.get("channel")
        remediation = parsed.get("remediation")
        # Some endpoints nest under `error: {...}` instead of flat top-level.
        nested = parsed.get("error")
        if isinstance(nested, dict):
            code = code or nested.get("code")
            channel = channel or nested.get("channel")
            remediation = remediation or nested.get("remediation")
        return (
            code if isinstance(code, str) else None,
            channel if isinstance(channel, str) else None,
            remediation if isinstance(remediation, str) else None,
        )

    # ====================================================================
    # FULL BD COVERAGE — typed MCP wrappers (sprint-21+ expansion, 0.5.0)
    # ====================================================================
    #
    # Every agent-scope MCP tool BD exposes has a typed method below. Each
    # delegates to ``self.call_tool(name, args)``; the bodies are
    # intentionally thin so the wire shape stays obvious. Use these
    # wrappers — they survive server schema migrations because the BD
    # server itself owns the tool name + arg shape. Reach for
    # :meth:`call_tool` only for tools added after this SDK release.

    # --- voice --------------------------------------------------------

    async def make_call(
        self,
        to: str,
        *,
        system_prompt: str | None = None,
        greeting: str | None = None,
        voice: str | None = None,
        language: str | None = None,
        recipient_timezone: str | None = None,
        target_gender: str | None = None,
        orchestrator: str | None = None,
    ) -> dict[str, Any]:
        """Initiate an outbound AI voice call. Returns ``{callSid, sessionId, status}``."""
        args: dict[str, Any] = {"to": to}
        if system_prompt is not None: args["systemPrompt"] = system_prompt
        if greeting is not None: args["greeting"] = greeting
        if voice is not None: args["voice"] = voice
        if language is not None: args["language"] = language
        if recipient_timezone is not None: args["recipientTimezone"] = recipient_timezone
        if target_gender is not None: args["targetGender"] = target_gender
        if orchestrator is not None: args["orchestrator"] = orchestrator
        return await self.call_tool("comms_make_call", args)

    async def transfer_call(
        self,
        call_sid: str,
        to: str,
        *,
        announcement_text: str | None = None,
    ) -> dict[str, Any]:
        """Transfer a live call to another number / agent. Returns confirmation."""
        args: dict[str, Any] = {"callSid": call_sid, "to": to}
        if announcement_text is not None: args["announcementText"] = announcement_text
        return await self.call_tool("comms_transfer_call", args)

    async def call_on_behalf(
        self,
        target: str,
        requester_phone: str,
        *,
        target_name: str | None = None,
        requester_name: str | None = None,
        message: str | None = None,
        recipient_timezone: str | None = None,
        target_gender: str | None = None,
    ) -> dict[str, Any]:
        """Secretary call — call ``target`` on requester's behalf, bridge if available."""
        args: dict[str, Any] = {"target": target, "requesterPhone": requester_phone}
        if target_name is not None: args["targetName"] = target_name
        if requester_name is not None: args["requesterName"] = requester_name
        if message is not None: args["message"] = message
        if recipient_timezone is not None: args["recipientTimezone"] = recipient_timezone
        if target_gender is not None: args["targetGender"] = target_gender
        return await self.call_tool("comms_call_on_behalf", args)

    async def send_voice_message(
        self,
        to: str,
        text: str,
        *,
        voice: str | None = None,
        target_gender: str | None = None,
    ) -> dict[str, Any]:
        """Place a call that plays a TTS message and hangs up."""
        args: dict[str, Any] = {"to": to, "text": text}
        if voice is not None: args["voice"] = voice
        if target_gender is not None: args["targetGender"] = target_gender
        return await self.call_tool("comms_send_voice_message", args)

    async def generate_tts(
        self,
        text: str,
        *,
        voice: str | None = None,
        format: str = "ogg",
    ) -> dict[str, Any]:
        """Generate TTS audio without placing a call. Returns ``{url, format}``.

        ``format`` ∈ {"mp3","ogg"}.
        """
        args: dict[str, Any] = {"text": text, "format": format}
        if voice is not None: args["voice"] = voice
        return await self.call_tool("comms_generate_tts", args)

    async def set_voice_callback(self, voice_callback_url: str) -> dict[str, Any]:
        """Set the webhook BD posts voice transcripts to."""
        return await self.call_tool(
            "comms_set_voice_callback",
            {"voiceCallbackUrl": voice_callback_url},
        )

    # --- sessions -----------------------------------------------------

    async def create_session(
        self,
        participants: list[dict[str, Any]],
        *,
        channel: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a multi-party session. ``participants`` is a list of
        ``{id, type: 'agent'|'human', name?}`` entries.
        """
        args: dict[str, Any] = {"participants": participants}
        if channel is not None: args["channel"] = channel
        if context is not None: args["context"] = context
        return await self.call_tool("comms_create_session", args)

    async def get_session(self, session_id: str, *, history_limit: int = 20) -> dict[str, Any]:
        """Fetch a session by id with the last ``history_limit`` messages."""
        return await self.call_tool(
            "comms_get_session",
            {"sessionId": session_id, "historyLimit": history_limit},
        )

    async def list_sessions(
        self,
        *,
        status: str = "active",
        limit: int = 50,
    ) -> dict[str, Any]:
        """List sessions. ``status`` ∈ {"active","paused","closed"}."""
        return await self.call_tool(
            "comms_list_sessions",
            {"status": status, "limit": limit},
        )

    async def close_session(self, session_id: str, *, confirm: bool = False) -> dict[str, Any]:
        """Close a session. Pass ``confirm=True`` to actually close (without
        it the server returns a preview).
        """
        return await self.call_tool(
            "comms_close_session",
            {"sessionId": session_id, "confirm": confirm},
        )

    # --- consent / trust ---------------------------------------------

    async def check_consent(self, contact: str, channel: str) -> dict[str, Any]:
        """Check whether ``contact`` has consented to ``channel``."""
        return await self.call_tool(
            "comms_check_consent",
            {"contact": contact, "channel": channel},
        )

    async def record_consent(
        self,
        contact: str,
        channel: str,
        *,
        consent_type: str = "express",
        source: str | None = None,
        notes: str | None = None,
    ) -> dict[str, Any]:
        """Record consent for ``contact`` on ``channel``.

        ``consent_type`` ∈ {"express","implied","transactional"}.
        """
        args: dict[str, Any] = {
            "contactAddress": contact,
            "channel": channel,
            "consentType": consent_type,
        }
        if source is not None: args["source"] = source
        if notes is not None: args["notes"] = notes
        return await self.call_tool("comms_record_consent", args)

    async def revoke_consent(self, contact: str, channel: str, *, confirm: bool = False) -> dict[str, Any]:
        """Revoke consent. Pass ``confirm=True`` to actually revoke."""
        return await self.call_tool(
            "comms_revoke_consent",
            {"contactAddress": contact, "channel": channel, "confirm": confirm},
        )

    async def check_trust(self, contact: str) -> dict[str, Any]:
        """Check trust state for ``contact``. Returns ``{trusted, status, expiresAt, message}``."""
        return await self.call_tool("comms_check_trust", {"contact": contact})

    async def grant_trust(
        self,
        contact: str,
        *,
        channel: str = "manual",
        duration_minutes: int | None = None,
    ) -> dict[str, Any]:
        """Grant trust to ``contact``. Default ``channel='manual'``."""
        args: dict[str, Any] = {"contactAddress": contact, "channel": channel}
        if duration_minutes is not None: args["durationMinutes"] = duration_minutes
        return await self.call_tool("comms_grant_trust", args)

    async def revoke_trust(self, contact: str, *, confirm: bool = False) -> dict[str, Any]:
        """Revoke trust. Pass ``confirm=True`` to actually revoke."""
        return await self.call_tool(
            "comms_revoke_trust",
            {"contactAddress": contact, "confirm": confirm},
        )

    # --- OTP ----------------------------------------------------------

    async def send_otp(
        self,
        to: str,
        channel: str,
        *,
        purpose: str | None = None,
        failover: bool | None = None,
        channels: list[str] | None = None,
    ) -> dict[str, Any]:
        """Send a one-time passcode. ``channel`` ∈ {"sms","email","whatsapp","voice"}."""
        args: dict[str, Any] = {"to": to, "channel": channel}
        if purpose is not None: args["purpose"] = purpose
        if failover is not None: args["failover"] = failover
        if channels is not None: args["channels"] = channels
        return await self.call_tool("comms_send_otp", args)

    async def verify_otp(
        self,
        code: str,
        *,
        to: str | None = None,
        channel: str | None = None,
    ) -> dict[str, Any]:
        """Verify an OTP code. On success creates an automatic trust session."""
        args: dict[str, Any] = {"code": code}
        if to is not None: args["to"] = to
        if channel is not None: args["channel"] = channel
        return await self.call_tool("comms_verify_otp", args)

    # --- discovery ----------------------------------------------------

    async def validate_number(self, phone_number: str) -> dict[str, Any]:
        """Look up carrier / line type / country for a phone number."""
        return await self.call_tool("comms_validate_number", {"phoneNumber": phone_number})

    async def find_agent(
        self,
        *,
        query: str | None = None,
        include_self: bool = True,
        include_draft: bool = True,
    ) -> dict[str, Any]:
        """List agents in this org (optionally filtered by ``query``)."""
        args: dict[str, Any] = {"includeSelf": include_self, "includeDraft": include_draft}
        if query is not None: args["query"] = query
        return await self.call_tool("comms_find_agent", args)

    async def get_contact_profile(self, contact: str) -> dict[str, Any]:
        """Return BD's profile cache for ``contact`` (E.164 or group@g.us)."""
        return await self.call_tool("comms_get_contact_profile", {"contact": contact})

    async def get_group_members(self, group_id: str) -> dict[str, Any]:
        """List members of a WhatsApp group (``120363...@g.us``)."""
        return await self.call_tool("comms_get_group_members", {"groupId": group_id})

    # --- inbound queue (MCP variants) ---------------------------------

    async def get_message_status(self, external_id: str) -> dict[str, Any]:
        """Look up the delivery state of a previously-sent message by SID."""
        return await self.call_tool("comms_get_message_status", {"externalId": external_id})

    async def subscribe_inbound(
        self,
        operation: str,
        *,
        channels: list[str] | None = None,
        contacts: list[str] | None = None,
    ) -> dict[str, Any]:
        """Manage push subscriptions for inbound events.

        ``operation`` ∈ {"subscribe","unsubscribe","status"}. Note: this
        complements (does not replace) the SSE/webhook delivery path.
        """
        args: dict[str, Any] = {"operation": operation}
        if channels is not None: args["channels"] = channels
        if contacts is not None: args["contacts"] = contacts
        return await self.call_tool("comms_subscribe_inbound", args)

    # --- channel-mgmt (agent-scope) -----------------------------------

    async def manage_inbound_filter(
        self,
        operation: str,
        *,
        filter_type: str | None = None,
        pattern: str | None = None,
        action: str | None = None,
        tag: str | None = None,
        filter_id: str | None = None,
    ) -> dict[str, Any]:
        """Manage inbound message filters (keyword/contact rules).

        ``operation`` ∈ {"add","list","delete"}. For "add",
        ``filter_type`` / ``pattern`` / ``action`` are required.
        """
        args: dict[str, Any] = {"operation": operation}
        if filter_type is not None: args["filterType"] = filter_type
        if pattern is not None: args["pattern"] = pattern
        if action is not None: args["action"] = action
        if tag is not None: args["tag"] = tag
        if filter_id is not None: args["filterId"] = filter_id
        return await self.call_tool("comms_manage_inbound_filter", args)

    # --- billing (agent-scope) ----------------------------------------

    async def get_income(self, *, period: str = "month") -> dict[str, Any]:
        """Get income breakdown for the agent.

        ``period`` ∈ {"today","week","month","all"}.
        """
        return await self.call_tool("comms_get_income", {"period": period})

    async def get_usage_dashboard(self, *, period: str = "today") -> dict[str, Any]:
        """Get the BD-side usage dashboard for the agent.

        ``period`` ∈ {"today","week","month","all"}.
        """
        return await self.call_tool("comms_get_usage_dashboard", {"period": period})

    # --- profile / token / inter-agent --------------------------------

    async def update_profile(self, **fields: Any) -> dict[str, Any]:
        """Update the agent's profile. All fields optional, camelCase keys.

        Recognised fields: ``agentName``, ``greeting``, ``systemPrompt``,
        ``voiceId``, ``language``, ``gender`` ∈ {"male","female","neutral"},
        ``voiceGender``, ``status`` ∈ {"active","inactive"}.
        """
        return await self.call_tool("comms_update_profile", fields)

    async def message_agent(self, to_agent: str, body: str) -> dict[str, Any]:
        """Send a message to another agent in the same org by id or name."""
        return await self.call_tool("comms_message_agent", {"toAgent": to_agent, "body": body})

    async def rotate_agent_token(self, *, confirm: bool = False) -> dict[str, Any]:
        """Rotate the agent_token via MCP. Old token revoked 30s after new
        one is issued. Pass ``confirm=True`` to actually rotate.
        """
        return await self.call_tool("comms_rotate_token", {"confirm": confirm})

    # --- admin-scope MCP (require an admin agent's agent_token) -----
    #
    # BD's /sse transport rejects team_token (401), so these tools cannot
    # live on AccountsClient. To use them: construct an Agent with the
    # token of an agent that holds `org-admin` (or higher) scope.

    async def register_provider(
        self,
        provider: str,
        credentials: dict[str, str],
        *,
        auto_verify: bool = True,
    ) -> dict[str, Any]:
        """Register/update a provider's credentials. Org-admin scope.

        ``provider`` ∈ {"twilio","vonage","resend","elevenlabs","openai",
        "deepgram","greenapi","s3","r2","turso","convex"}. Credentials are
        encrypted at rest server-side.
        """
        return await self.call_tool(
            "comms_register_provider",
            {"provider": provider, "credentials": credentials, "autoVerify": auto_verify},
        )

    async def expand_client_pool(
        self,
        max_agents: int,
        *,
        confirm: bool = False,
    ) -> dict[str, Any]:
        """Resize the org's agent pool. ``max_agents`` ∈ [1, 10000].

        Pass ``confirm=True`` to actually resize; otherwise returns a preview.
        Org-admin scope required.
        """
        return await self.call_tool(
            "comms_expand_client_pool",
            {"maxAgents": max_agents, "confirm": confirm},
        )

    async def list_available_numbers(self) -> dict[str, Any]:
        """List numbers available in the org's pool for provisioning. Org-admin scope."""
        return await self.call_tool("comms_list_available_numbers", {})

    async def bridge_call(self, action: str, **kwargs: Any) -> dict[str, Any]:
        """Manage call-bridge wiring. Org-admin scope.

        ``action`` ∈ {"setup","remove","list","call"}. Other kwargs vary by
        action: ``fromNumber``, ``localNumber``, ``destinationNumber``,
        ``label``, ``bridgeId``, ``callerNumber``.
        """
        return await self.call_tool("comms_bridge_call", {"action": action, **kwargs})

    async def manage_channel(
        self,
        action: str,
        channel: str,
        *,
        country: str | None = None,
        email_domain: str | None = None,
    ) -> dict[str, Any]:
        """Add/remove channels via MCP (org-admin scope, MCP variant of the REST
        ``/agents/{id}/channels``).

        ``action`` ∈ {"add","remove"}; ``channel`` ∈ {"phone","email","whatsapp","line"}.
        """
        args: dict[str, Any] = {"action": action, "channel": channel}
        if country is not None: args["country"] = country
        if email_domain is not None: args["emailDomain"] = email_domain
        return await self.call_tool("comms_manage_channel", args)

    async def deprovision_channels(self, *, confirm: bool = False) -> dict[str, Any]:
        """Tear down this agent's channels via MCP. Pass ``confirm=True`` to actually deprovision."""
        return await self.call_tool("comms_deprovision_channels", {"confirm": confirm})

    async def set_client_limits_safe(
        self,
        limits: dict[str, Any],
        *,
        confirm: bool = False,
    ) -> dict[str, Any]:
        """Set rate-limits via the MCP variant (with confirm-gating). Org-admin scope.

        REST equivalent on AccountsClient (:meth:`AccountsClient.set_client_limits`)
        does not have the confirm gate.
        """
        return await self.call_tool(
            "comms_set_client_limits",
            {"limits": limits, "confirm": confirm},
        )

    # --- 0.5.1 audit fixes — REST: list_voices, set_client_status -----

    async def list_voices(self) -> dict[str, Any]:
        """List TTS voices available to this org. Returns ``{voices, count}``."""
        return await self._rest("GET", "/api/v1/voices")

    async def set_client_status(
        self,
        status: str,
        *,
        reason: str | None = None,
    ) -> dict[str, Any]:
        """Activate/deactivate/suspend the agent.

        ``status`` ∈ {"active","inactive","suspended"}. Transition into
        ``"suspended"`` fires the BD ``agent.suspended`` event.
        """
        body: dict[str, Any] = {"status": status}
        if reason is not None: body["reason"] = reason
        return await self._rest("PUT", "/api/v1/client-status", body=body)

    # --- 0.5.1 audit fixes — admin-MCP wrappers -----------------------

    async def onboard_customer(
        self,
        agent_name: str,
        capabilities: dict[str, bool],
        *,
        agent_id: str | None = None,
        callback_url: str | None = None,
        email_domain: str | None = None,
    ) -> dict[str, Any]:
        """Full enterprise onboarding via MCP. Org-admin scope.

        Provisions all channels in a single MCP call and returns a complete
        setup package: token, channels, DNS records, webhook URLs, SSE
        instructions. Equivalent to the REST ``/api/v1/onboard`` but
        returns more orchestration metadata.
        """
        args: dict[str, Any] = {
            "agentName": agent_name,
            "capabilities": capabilities,
        }
        if agent_id is not None: args["agentId"] = agent_id
        if callback_url is not None: args["callbackUrl"] = callback_url
        if email_domain is not None: args["emailDomain"] = email_domain
        return await self.call_tool("comms_onboard_customer", args)

    async def create_team(
        self,
        name: str,
        slug: str,
        *,
        settings: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new team (organization). Super-admin scope only.

        ``slug`` must match ``^[a-z0-9-]+$``. Returns a team admin token.
        """
        args: dict[str, Any] = {"name": name, "slug": slug}
        if settings is not None: args["settings"] = settings
        return await self.call_tool("comms_create_team", args)

    async def list_teams(self) -> dict[str, Any]:
        """List all teams with agent counts. Super-admin scope only."""
        return await self.call_tool("comms_list_teams", {})

    async def get_billing_summary(
        self,
        *,
        agent_id: str | None = None,
        period: str = "month",
    ) -> dict[str, Any]:
        """Get billing summary with provider costs vs billed costs.

        Agents see their own data; admins can pass ``agent_id`` to see a
        specific agent or omit it to see all.
        """
        args: dict[str, Any] = {"period": period}
        if agent_id is not None: args["agentId"] = agent_id
        return await self.call_tool("comms_get_billing_summary", args)

    # ----- generic MCP escape hatch --------------------------------------

    async def call_tool(
        self,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
        *,
        agent_token: str | None = None,
    ) -> Any:
        """Call any MCP tool by name. Untyped escape hatch for tools the SDK
        doesn't yet wrap.

        Returns the parsed JSON body of the tool result (or the raw text if
        the body wasn't valid JSON, or ``None`` if the tool returned no
        content). Raises the typed auth errors (``AuthInvalidTokenError``,
        ``AuthLockedOutError``, ``AuthTokenRevokedError``) on 401/429.

        Use the typed methods (``send_message``, ``react``, ``list_tools``,
        etc.) when one exists — they shape the result, map errors to
        ``SendResult`` / typed exceptions, and survive server schema
        evolution. Reach for ``call_tool`` for the long-tail (voice
        sessions, consent/trust, OTP, channel introspection, etc.) until a
        typed wrapper is added.

        Example:
            >>> result = await agent.call_tool("comms_validate_number", {"number": "+14155550123"})
            >>> result["valid"]
            True
        """
        token = self._resolve_token(agent_token)
        if not token:
            raise ConfigError("agent_token is required to call MCP tools")
        parsed, _raw = await self._call_tool(token, tool_name, arguments or {})
        return parsed

    # ----- admin / introspection -----------------------------------------

    async def list_tools(self) -> list[str]:
        """Return the names of MCP tools the BD server exposes.

        Returns an empty list on any error (disconnected, auth failure, etc.).
        """
        token = self._resolve_token(None)
        if not token:
            return []
        try:
            from mcp import ClientSession
            from mcp.client.sse import sse_client

            headers = {
                "Authorization": f"Bearer {token}",
                "User-Agent": user_agent(),
            }
            async with sse_client(  # noqa: SIM117  (read,write tuple-unpack feeds the inner CM)
                self.sse_url, headers=headers, timeout=self.sse_timeout
            ) as (read, write):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    result = await session.list_tools()
                    return [t.name for t in result.tools]
        except Exception as exc:
            logger.warning("list_tools failed: %s", exc)
            return []

    async def ping(self, tool_name: str = "comms_ping") -> bool:
        """Call the server's ping tool. True if it returned anything; False on error."""
        token = self._resolve_token(None)
        if not token:
            return False
        try:
            from mcp import ClientSession
            from mcp.client.sse import sse_client

            headers = {
                "Authorization": f"Bearer {token}",
                "User-Agent": user_agent(),
            }
            async with sse_client(  # noqa: SIM117  (read,write tuple-unpack feeds the inner CM)
                self.sse_url, headers=headers, timeout=self.sse_timeout
            ) as (read, write):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    result = await session.call_tool(tool_name, arguments={})
                    return bool(result and result.content)
        except Exception as exc:
            logger.debug("ping failed: %s", exc)
            return False

    async def fetch_usage_summary(self, path: str = "/api/v1/usage") -> dict[str, Any] | None:
        """Fetch the BD usage summary via REST.

        Returns the parsed JSON body on 200; None on any error.
        """
        return await self._rest("GET", path, swallow_errors=True)

    # ----- agent-scope REST endpoints (sprint-21+ coverage) -----------

    async def get_self(self) -> dict[str, Any]:
        """Return the agent record this token belongs to (REST
        ``GET /api/v1/agents/me``).

        Response shape: ``{agentId, displayName, status, lifecycleState,
        channels: {phone?, whatsapp?, email?}, callbackUrl?, createdAt,
        provisionedAt?}``. Prefer ``lifecycleState`` over raw ``status``
        (per F27/F42).

        Use this when the agent only knows its own token — admin lookup
        via :meth:`AccountsClient.get_agent` requires team_token.

        See also :meth:`get_me` for the MCP-tool variant — same data,
        same auth, just over the MCP/SSE transport.
        """
        return await self._rest("GET", "/api/v1/agents/me")

    async def get_me(self) -> dict[str, Any]:
        """Return the agent record via MCP (``comms_get_me``).

        MCP variant of :meth:`get_self` — same payload, same auth, just
        routed over MCP/SSE instead of REST. BD recommends this in its
        public MCP instructions (any LLM connecting via SSE should call
        ``comms_get_me`` first to introspect its identity + channels).
        """
        return await self.call_tool("comms_get_me", {})

    async def get_waiting_messages(
        self,
        *,
        limit: int = 50,
        channel: str | None = None,
    ) -> dict[str, Any]:
        """Fetch (and auto-ack) waiting inbound messages.

        **Destructive read** — fetched messages are removed from the queue.
        Use only if you've missed webhooks; the canonical inbound path is
        the webhook receiver.

        ``channel`` ∈ {"sms","email","whatsapp","voice","line"}. Omitted
        means all channels. Returns ``{messages: [...], count}``.
        """
        params = f"?limit={limit}" + (f"&channel={channel}" if channel else "")
        return await self._rest("GET", f"/api/v1/waiting-messages{params}")

    async def get_channel_status(self) -> dict[str, Any]:
        """Get this agent's channel state. Returns the BD-side mirror.

        Response shape: ``{phone?, whatsapp?, email?, voiceAi?}`` where each
        value is ``{status, ...channel-specific}``.
        """
        return await self._rest("GET", "/api/v1/channel-status")

    async def get_billing(self, *, period: str = "month") -> dict[str, Any]:
        """Get billing summary for the agent.

        ``period`` ∈ {"today","week","month","all"}. Default ``"month"``.
        """
        return await self._rest("GET", f"/api/v1/billing?period={period}")

    async def set_callback_url(self, callback_url: str) -> dict[str, Any]:
        """Update the inbound-webhook URL for this agent (`PUT /callback-url`).

        BD posts inbound messages and delivery receipts here. Must be
        HTTPS and reachable from BD's network.
        """
        return await self._rest(
            "PUT",
            "/api/v1/callback-url",
            body={"callbackUrl": callback_url},
        )

    # ----- internal REST helper ---------------------------------------

    async def _rest(
        self,
        method: str,
        path: str,
        *,
        body: dict[str, Any] | None = None,
        swallow_errors: bool = False,
    ) -> Any:
        """Generic REST request using the agent token. Returns parsed JSON.

        ``swallow_errors=True`` returns None on any failure (used by
        legacy ``fetch_usage_summary`` for back-compat). Otherwise raises
        a TransportError on network failure or returns the server's
        error body on 4xx/5xx.
        """
        import httpx

        token = self._resolve_token(None)
        if not token:
            if swallow_errors:
                return None
            raise ConfigError("agent_token is required for REST calls")
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.request(
                    method,
                    f"{self.base_url}{path}",
                    headers={
                        "Authorization": f"Bearer {token}",
                        "User-Agent": user_agent(),
                    },
                    json=body if body is not None else None,
                )
                check_deprecation_headers(method, path, dict(resp.headers))
                if resp.status_code == 200 or (200 <= resp.status_code < 300):
                    if not resp.content:
                        return {}
                    try:
                        return resp.json()
                    except ValueError:
                        return {}
                # Error path. Return the body if we have one (auth
                # callers branch on `code`); otherwise bubble a basic
                # dict so callers can still see status+message.
                try:
                    err_body = resp.json()
                except ValueError:
                    err_body = {}
                if swallow_errors:
                    return None
                if isinstance(err_body, dict):
                    err_body.setdefault("status", resp.status_code)
                    return err_body
                return {"status": resp.status_code, "body": err_body}
        except Exception as exc:
            if swallow_errors:
                logger.debug("REST %s %s failed: %s", method, path, exc)
                return None
            raise
