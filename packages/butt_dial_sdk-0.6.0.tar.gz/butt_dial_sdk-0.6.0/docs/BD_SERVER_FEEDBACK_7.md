# BD Server Feedback — Round 7 (post-0.5.1 audit)

<!-- version: 1.0 | updated: 2026-05-08 -->

**SDK:** `butt-dial-sdk==0.5.1` (Python) / `butt-dial-sdk@0.2.1` (Node)
**Audited against:** `https://call.95percent.ai`, server commit at `~/Documents/work/butt-dial` (sprint 21 era)

This round focuses on issues that will affect every SDK consumer (not just iv-bknd). The SDK is now public on PyPI + npm; what BD does or doesn't ship has external impact beyond our internal hosts.

---

## 🚨 BLOCKING — Sunset endpoints with no published successor

Three core endpoints are emitting `Sunset` headers with **no successor-version pointer**. The `Link: </docs#deprecations>; rel="deprecation"` header points to a docs anchor that doesn't exist (the page redirects to home — verified 2026-05-08).

| Endpoint | Sunset | What the SDK uses it for |
|---|---|---|
| `POST /api/orgs/register` | `Tue, 28 Jul 2026` (sometimes `Wed, 05 Aug`) | Every signup goes through this — `accounts.register()` |
| `GET /api/v1/agents/{agentId}` | `Thu, 06 Aug 2026 15:32:24 GMT` | `accounts.get_agent()` admin lookup |
| `GET /api/v1/agents/me` | `Thu, 06 Aug 2026 15:32:24 GMT` | `agent.get_self()` self-introspection |

Sunset date has been moving back (`07-28` → `08-05` → `08-06` over the past week), suggesting BD doesn't have replacements ready.

**Asks:**
1. Publish replacement endpoint paths and let the SDK ship a 0.6.0 with both old (deprecated) and new wrappers, plus a transitional dual-call shim.
2. If replacements aren't planned before sunset, please remove the `Sunset` headers — they're firing the SDK's deprecation logger on every probe and creating noise without action.
3. If replacements ARE planned, populate `Link: <...>; rel="successor-version"` on the deprecated responses so the SDK can auto-discover them. The current `rel="deprecation"` link to a 404 anchor is actively misleading.

---

## ❌ ACTIVE BUG (server-side) — `comms_get_me` referenced but never registered

The MCP server's instructions string (`packages/server/src/server.ts:61` and `:74`, mirrored at `rest-router.ts:158` and `llms-txt.ts:191`) advises clients:

> "Run `comms_get_me` to see your agent profile."

But `comms_get_me` is **not registered as a tool**. Calling it returns "tool not found." Every LLM following the official instructions hits this dead end.

**Ask:** either register the tool (it could just be an alias for the existing `GET /api/v1/agents/me` REST endpoint), or update the instructions string to recommend the actual working path. We've confirmed this is a server-side issue, not an SDK gap.

---

## ⚠️ Schema gap — `comms_send_message` rejects `threadId`/`entityId`/`replyMsgId`

Both SDKs (`butt-dial-sdk@0.5.1` Python, `0.2.1` Node) send these three fields when callers supply them:

```python
agent.send_message(
    to="+1...",
    body="reply text",
    thread_id="msg-conversation-id",   # silently dropped server-side
    entity_id="customer-42",            # silently dropped server-side
    reply_msg_id="prev-msg-sid",        # silently dropped server-side
)
```

Server's Zod schema at `packages/server/src/tools/send-message.ts:96-115` doesn't declare them. Zod strips unknown keys, so the fields disappear before the handler runs. SDK callers think they're attaching reply context; nothing reaches BD.

**Ask:** add these three keys to the `comms_send_message` schema (and the matching `POST /api/v1/send-message` REST handler at `rest-router.ts:428`). Once declared, the SDKs become usable for thread-aware messaging without a release. Until then, callers passing these are confused into a silent no-op.

---

## ✅ Credit where due — what BD shipped this round

(For the status doc, not asks — this is what's working.)

- 0.5.0/0.5.1 SDKs ship typed wrappers for **all 85+** public endpoints + tools — confirmed against the captured OpenAPI + MCP tool list.
- `OnboardingRequired` (sprint-20) flow works end-to-end: `verify()` → `accept_onboarding(sessionId, version)`.
- `media: [url]` (array) accepted on `comms_send_message` — fix shipped in 0.5.1 / 0.2.1 once the schema mismatch was caught.
- `bypass-2fa` granular-access tokens work for npm-style CI publishing — useful pattern reference for how BD's own admin tokens could relax for trusted automation.

---

## SDK-side decisions deferred to BD answers

**Don't ship a 0.6.0 with replacement-endpoint wrappers** until BD publishes the successor paths for the 3 sunset items. Best-case the SDK ships the new wrappers same-day; worst-case (BD removes the sunsets) we save the churn entirely. Current SDK works against the deprecated endpoints; the deprecation logger continues to alert integrators.

**The schema-gap items** (`comms_get_me`, `threadId`/`entityId`/`replyMsgId`) don't gate the SDK release — but every day they're unfixed, integrators hit the same papercuts.
