# BD Server — Consolidated Status (post-round-9)

<!-- version: 1.0 | updated: 2026-05-08 -->

**As of:** 2026-05-08, after shipping SDK 0.5.0 + 0.2.0 (Node).
**Server:** `https://call.95percent.ai`
**SDK:** `butt-dial-sdk==0.5.0` (PyPI), `butt-dial-sdk@0.2.0` (npm — pending publish auth)

This round was a **coverage sprint**. The audit at the start of the session showed the SDK was wrapping ~30 of BD's ~85 public surface elements (~35%). 0.5.0 / 0.2.0 close that gap to 100%: every public REST endpoint and every MCP tool now has a typed wrapper, plus a public `call_tool()` escape hatch for tools BD ships after this release.

---

## Headline

- **Full surface coverage shipped.** ~55 new typed methods per SDK. AccountsClient: 13 → 28 (Python) / 14 → 30 (Node). Agent: ~22 → 55 (Python) / ~22 → 59 (Node).
- **One BD-server architectural fact confirmed live:** BD's `/sse` rejects `team_token` at the auth layer (401). The entire MCP surface is agent-scoped end-to-end. This shaped the SDK's class design — see § Architecture findings.
- **🚨 Third sunset endpoint surfaced:** `GET /api/v1/agents/me` carries `Sunset: Wed, 05 Aug 2026 23:11:22 GMT`. Joins `/api/orgs/register` (2026-07-28) and `/api/v1/agents/{id}` (2026-07-28) on the deprecation list.

---

## What's now covered

### REST (29 OpenAPI endpoints + 7 lifecycle endpoints = 36 total)

All wrapped. New in 0.5.0:

**Admin REST on AccountsClient:**
- `POST /api/v1/onboard` → `onboard()`
- `POST /api/v1/deprovision` → `deprovision()`
- `GET /api/v1/agents/{id}/tokens` → `list_agent_tokens()`
- `POST /api/v1/agents/{id}/regenerate-token` → `regenerate_agent_token()`
- `POST /api/v1/billing/config` → `set_billing_config()`
- `POST /api/v1/client-limits` → `set_client_limits()`
- `GET /api/v1/agents/{id}/comm-channels` → `list_agent_comm_channels()`
- `POST /api/v1/agents/{id}/comm-channels` → `add_agent_comm_channel()`
- `POST /api/v1/agents/{id}/channels` → `manage_agent_channel()`
- `PATCH /api/v1/comm-channels/{id}` → `update_comm_channel()`
- `DELETE /api/v1/comm-channels/{id}` → `delete_comm_channel()`

**Agent-scope REST on Agent:**
- `GET /api/v1/agents/me` → `get_self()`
- `GET /api/v1/waiting-messages` → `get_waiting_messages()`
- `GET /api/v1/channel-status` → `get_channel_status()`
- `GET /api/v1/billing` → `get_billing()`
- `PUT /api/v1/callback-url` → `set_callback_url()`

### MCP (57 tools)

All wrapped. The 41 previously-uncovered tools, by domain:

| Domain | Tools | Lives on |
|---|---|---|
| Voice | `make_call`, `transfer_call`, `call_on_behalf`, `send_voice_message`, `generate_tts`, `set_voice_callback` | Agent |
| Sessions | `create_session`, `get_session`, `list_sessions`, `close_session` | Agent |
| Consent + trust | `check_consent`, `record_consent`, `revoke_consent`, `check_trust`, `grant_trust`, `revoke_trust` | Agent |
| OTP | `send_otp`, `verify_otp` | Agent |
| Discovery | `validate_number`, `find_agent`, `get_contact_profile`, `get_group_members` | Agent |
| Inbound queue | `get_message_status`, `subscribe_inbound` | Agent |
| Channel mgmt (agent) | `manage_inbound_filter` | Agent |
| Billing (agent) | `get_income`, `get_usage_dashboard` | Agent |
| Profile / inter-agent / token | `update_profile`, `message_agent`, `rotate_token` | Agent |
| **Admin-MCP (org-admin scope)** | `register_provider`, `expand_client_pool`, `list_available_numbers`, `bridge_call`, `manage_channel`, `deprovision_channels`, `set_client_limits` | Agent (see below) |

### Escape hatch

`Agent.call_tool(name, args)` (Python) / `agent.callTool(name, args)` (Node) — public, untyped, returns parsed JSON body. For any tool BD adds after 0.5.0 / 0.2.0, hosts can call it without waiting for an SDK release.

---

## Architecture findings

### Admin-MCP tools live on `Agent`, not `AccountsClient`

The categorization plan initially placed admin-MCP wrappers (`register_provider`, `bridge_call`, etc.) on `AccountsClient` because they're admin operations and `AccountsClient` already holds `team_token`. **This was wrong, and live testing surfaced it before release.**

When the SDK opened an MCP/SSE session with `Authorization: Bearer <team_token>`, BD's `/sse` returned `401 Unauthorized` at the transport handshake — before any tool was invoked. The MCP surface is agent-scoped end-to-end. To call admin MCP tools, you need an `agent_token` from an agent that holds `org-admin` (or higher) scope.

The SDK now reflects this:
- `AccountsClient` has only the **REST** admin surface. team_token works there.
- `Agent` carries the admin-MCP wrappers. Hosts construct an `Agent(agent_token=<admin_agent's_token>)` to use them.

**For BD:** if this scope split was intentional, no action needed. If team_token *should* be able to open `/sse` for admin tools (i.e. the 401 is a bug), please confirm — we'd un-relocate. The SDK works either way after this fact is settled.

### Live verification of admin-MCP

A test agent without org-admin scope hit `register_provider` etc. through Agent. BD returned a clean structured error: `{error: "Admin access required. Client tokens cannot perform this action."}`. So the wire shape is correct end-to-end; the only thing standing between the SDK and a successful admin-MCP call is whether the caller's agent has `org-admin` scope.

---

## 🚨 New BD questions / observations

### Q1 — A third endpoint is on the sunset list

Adding to the round-8 list. Current sunset state visible to the SDK:

| Endpoint | Sunset | Surfaced when |
|---|---|---|
| `POST /api/orgs/register` | Tue, 28 Jul 2026 19:53:11 GMT | round-8, register probe |
| `GET /api/v1/agents/{agentId}` | Tue, 28 Jul 2026 19:41:40 GMT | round-8, getAgent probe |
| `GET /api/v1/agents/me` | **Wed, 05 Aug 2026 23:11:22 GMT** | round-9, get_self probe |

Three core SDK surfaces now have sunset dates < 100 days out. Need replacement paths. Question repeated from round-8: what's the plan-of-record? If they're still in design, an ETA so we can ship a transitional 0.5.x or 0.6.0 that targets the new paths before sunset.

### Q2 — `/sse` rejecting team_token: bug or by-design?

See § Architecture findings. The SDK assumes by-design and split admin-MCP onto `Agent`. Confirm if that's correct.

### Q3 — Carryover from round-8 (still open)

- Sprint-20 `onboardingUrl` contract — confirm `verify()` always includes it on the TOS-gate branch, or specify the canonical fallback path.
- `sender_name` / `language` on `send_message` — server-side confirmation that they're applied.
- `User-Agent` aggregation telemetry — share what BD sees post-0.4.5 / 0.1.1 / 0.5.0 / 0.2.0.

---

## Item movement R8 → R9

| | R8 | R9 | Δ |
|---|---|---|---|
| ✅ FIXED | 60 / 92 (65%) | 60 / 92 (65%) | 0 (this round was SDK coverage, not server fixes) |
| ⚠️ PARTIAL | 9 | 9 | 0 |
| ❌ OPEN | 19 | 19 | 0 |
| 🚫 WONTFIX | 2 | 2 | 0 |
| ℹ️ INFO | 2 | 2 | 0 |

**SDK release queue:** **empty.** Every BD endpoint and tool ships with a typed wrapper. The remaining open BD-side items are all server-side concerns (sunset replacements, F06 squatting, F86 surface unification).

---

## Live verification — sample (Python 0.5.0 against call.95percent.ai)

```
agent.validate_number('+14155550123')  → {valid=True, countryCode='US'}
agent.get_self()                        → {agentId, displayName, status, ...}
agent.find_agent()                      → {agents, count}
agent.get_income()                      → {period, currency, providerCost, billedCost, income}
agent.list_available_numbers()          → {error: "Admin access required."}     [✓ wire shape]
agent.bridge_call('list')               → {error: "Admin access required."}     [✓ wire shape]

[buttdial] Endpoint GET /api/v1/agents/me is deprecated (Sunset: Wed, 05 Aug 2026 23:11:22 GMT).
```

---

## References

- This release: PyPI [`butt-dial-sdk==0.5.0`](https://pypi.org/project/butt-dial-sdk/0.5.0/) — npm `butt-dial-sdk@0.2.0` (publish pending Automation token)
- Python repo: <https://github.com/elradts/butt-dial-sdk> — commit `7888c5f`
- Node repo: <https://github.com/elradts/butt-dial-node-sdk> — commit `63ec4b5`
- Round-8: `docs/BD_SERVER_STATUS_AS_OF_R8.md` (v1.0)
- Round-7 baseline: `docs/BD_SERVER_STATUS_AS_OF_R6.md` (v1.1)
- Open items: `docs/BD_SERVER_OPEN_ITEMS.md`
- Coverage source-of-truth: `c:/temp/bd_coverage/openapi.json`, `c:/temp/bd_coverage/mcp_tools.json`
