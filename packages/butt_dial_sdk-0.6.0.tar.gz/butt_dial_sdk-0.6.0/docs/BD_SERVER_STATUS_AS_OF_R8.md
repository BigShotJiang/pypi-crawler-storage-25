# BD Server — Consolidated Status (post-round-8)

<!-- version: 1.0 | updated: 2026-04-30 -->

**As of:** 2026-04-30, after shipping SDK 0.4.5 + 0.1.1 (Node port).
**Server:** `https://call.95percent.ai`
**SDK:** `butt-dial-sdk==0.4.5` (PyPI), `butt-dial-sdk@0.1.1` (npm — pending publish auth)

This round was an action-list sprint: BD asked for five SDK-side behaviors (C1–C5), and we folded in two long-pending SDK-only cleanups (F13, F57) at the same time. Live smoke against `call.95percent.ai` confirms all five are working end-to-end and surfaced **two BD-side endpoints already on a sunset path** that the SDK couldn't see before — see § New questions for BD.

---

## Headline

- **C1–C5: all five BD-asked SDK actions shipped in 0.4.5/0.1.1.** Test counts: Python 248/248, Node 76/76. Live smoke: Python 5/5, Node 6/6.
- **F13 closed:** `verify()` docstring/types corrected — server returns `scopes`, not `mode`.
- **F57 closed:** `provision_channels.capabilities` tightened to `dict[str, bool]`; the SDK-invented `list[str]` overload (server-rejected) removed.
- **🚨 New BD-side discovery:** `POST /api/orgs/register` and `GET /api/v1/agents/{agentId}` are both serving `Sunset: Tue, 28 Jul 2026 19:xx:xx GMT` headers. The SDK's new C5 logger surfaced this on the very first probe run after release. Need BD to confirm replacement paths before that date.

---

## C1–C5 — what shipped (matching BD's exact ask)

### C1 — `requiresOnboarding` → typed exception

**BD ask:** "Sprint-20+ servers can return `{teamToken: null, requiresOnboarding: true, orgId, onboardingSessionId, onboardingExpiresAt}` from `/verify`. SDK should raise a typed exception with `org_id` / `onboarding_url` / `expires_at`."

**Shipped:**
- `buttdial.OnboardingRequired` (Python) / `OnboardingRequired` (Node) — extends `AccountsError`.
- `verify()` detects `requiresOnboarding` (or snake-case `requires_onboarding` per F84 sunset window) and raises with all four fields populated.
- If BD supplies `onboardingUrl` in the response, the SDK uses it verbatim. Otherwise it constructs `${baseUrl}/onboarding?s=${sessionId}` as a fallback. **→ BD: confirm the canonical onboarding URL pattern so the fallback either matches or gets removed.**

**Live verified:** SDK round-7 probe path; legacy `{team_token, ...}` response still works (back-compat preserved).

### C2 — auto Idempotency-Key on `register`

**BD ask:** "Generate UUIDv4 per call, send as `Idempotency-Key`. Override-able."

**Shipped:**
- Python: `register(..., idempotency_key=...)` kwarg with UUIDv4 default.
- Node: `register({ ..., idempotencyKey })` field with `randomUUID()` default.
- iv-bknd's manual `httpx.AsyncClient` register-bypass (added because the SDK didn't expose the kwarg) is now obsolete — tracked in iv-bknd's `docs/TODO.md` "BD SDK 0.4.5 adoption".

**Live verified:** the round-7 probe sent two registers with auto-generated keys; both round-tripped clean orgIds + webhookSecrets + pollTokens.

### C3 — `sender_name` / `language` on `send_message`

**BD ask:** "Re-enable the kwargs on `send_message` (they were dropped at some point)."

**Shipped:** The fields were already wired in `agent.py` (`accounts.py:215-216`, forwarded to MCP args as camelCase `senderName` / `language` at `agent.py:273-275`). Verified intact, no change needed. **→ BD: confirm you actually see these on the wire when the SDK sends them, since the round-trip wasn't the focus of this sprint.**

### C4 — `User-Agent` header

**BD ask:** "Send `User-Agent: buttdial-python/<version>` (and `buttdial-node/<version>` for the Node port)."

**Shipped:**
- New `buttdial._http.user_agent()` (Python) / `_http.userAgent()` (Node) helper.
- Applied to **every** outbound request: REST surface (`accounts.py`), SSE handshake (`agent.py` — both `requestInit` and the EventSource fetch), REST usage endpoint.
- Resolved at call time from package `__version__`/`VERSION`, so updates follow the wheel.

**Live verified:** `User-Agent: buttdial-python/0.4.5` / `buttdial-node/0.1.1` appearing in every probe.

### C5 — Deprecation/Sunset header awareness

**BD ask:** "Log a warning when responses include `Deprecation: true` and/or `Sunset: <date>` headers."

**Shipped:**
- New `buttdial._http.check_deprecation_headers()` (Python) / `checkDeprecationHeaders()` (Node).
- Wired into every response path on both surfaces (REST + SSE).
- Honors RFC 8594 (Sunset) + draft-ietf-httpapi-deprecation-header. Case-insensitive header lookup.
- Deduplicates per `(method, path, sunset)` per process — safe to leave on in production without log spam.
- Python: `WARNING` on `logger("buttdial")`. Node: `console.warn` with `[buttdial]` prefix.

**Live verified — and immediately useful:** on the very first round-7 probe run, the new logger fired twice. See § New questions for BD.

---

## SDK-side cleanups folded in

### F13 — `verify()` docstring drift

Was: docstring claimed `verify()` returned `{team_token, org_id, mode}`. Server returns `{..., scopes: "org-admin"}`. The `mode` field (`"sandbox"` / `"live"`) lives on `GET /api/orgs/me`, not `verify`.

Fixed: docstring corrected, `VerifyResponse` typing updated (Node), back-compat preserved (extra keys still accepted).

### F57 — `provision_channels` list-shape removed

Was: `capabilities: dict[str, bool] | list[str]`. The `list[str]` branch was an SDK-invented convenience the server never accepted.

Fixed: tightened to `dict[str, bool]` only. Docstring + JSDoc explain the change. Existing iv-bknd callers already use the dict form, so no caller-side breakage.

Both items now move to ✅ FIXED. Updated counts: **60 / 92 fixed** (was 58).

---

## 🚨 New questions for BD

### Q1 — Sunset path on `/api/orgs/register` + `/api/v1/agents/{agentId}`

C5 surfaced these in production traffic immediately after 0.4.5 went live:

```
POST /api/orgs/register           Sunset: Tue, 28 Jul 2026 19:53:11 GMT
GET  /api/v1/agents/{agentId}     Sunset: Tue, 28 Jul 2026 19:41:40 GMT
```

These are **the** core SDK surfaces — every signup goes through register, every agent lookup uses the second. **What are the replacement paths?** We need to ship a 0.4.6/0.1.2 that targets the new URLs before that date or every host built on the SDK breaks at sunset.

If the replacements are already shipped, please point at them in the next BD doc and we'll cut a migration release. If they're still in design, we need a plan-of-record and an ETA so the SDK can ship a transitional dual-call shim.

### Q2 — Sprint-20 onboarding URL contract

The SDK's `OnboardingRequired.onboarding_url` resolves in this order:
1. Server-supplied `onboardingUrl` (or snake `onboarding_url`) if present.
2. Else `${baseUrl}/onboarding?s=${sessionId}` if a session id is present.
3. Else `${baseUrl}/onboarding`.

**Please confirm:**
- Will `/api/orgs/verify` always include `onboardingUrl` when `requiresOnboarding: true`? (If so, fallback can be removed.)
- If not — is the fallback path correct (`/onboarding?s=<sessionId>` vs e.g. `/onboarding/<sessionId>` or a fully-qualified host)?
- Once a user accepts TOS, does BD post `account.verified` to the same `webhookUrl` registered at signup time, with the now-minted `teamToken`? (My SDK doc + iv-bknd note assume yes.)

### Q3 — `sender_name` / `language` reception confirmation

The SDK forwards both as camelCase MCP args. We've never had a probe confirm BD actually applies them on the outbound message. Could you grep the server log for an outbound where `senderName` / `language` were set, and confirm the resolved sender / template language matches?

### Q4 — `User-Agent` adoption tracking

If you start aggregating `User-Agent` strings server-side, please share what you see on the next round. We'd like to verify no traffic is still hitting the old (no-UA) code paths once iv-bknd, the doctor CLI, and external integrators all upgrade.

---

## Live smoke (post-0.4.5) — both SDKs

### Python (`scripts/probe_round7.py`)

```
=== Probes (BD round-6 follow-up claims) ===
  [ok] F21      MCP serverInfo.version                           version='1.0.0'
  [ok] F84      OpenAPI info.title                               title='Butt-Dial — REST API'
  [ok] F89      register response shape symmetry                 webhookSecret present: pending=True verified=True
  [ok] F90      comms_send_message error envelope                code='NO_CHANNEL_ASSIGNED'
  [ok] F92      /docs/mcp-tools scope vocabulary                 4-tier set present

⚠  Butt-Dial endpoint POST /api/orgs/register is deprecated (Sunset: Tue, 28 Jul 2026 19:53:11 GMT)

=== Summary ===
  PASS=5  FAIL=0  SKIP=0  INFO=0
```

### Node (`scripts/smoke-live.mjs`)

```
=== REST surface (AccountsClient) ===
  [ok] AccountsClient.getAccount         orgId="28bf35dd-995f-46ac-96da-1f99ac9d9b52"
[buttdial] Endpoint GET /api/v1/agents/d51b0eb9-… is deprecated (Sunset: Tue, 28 Jul 2026 19:41:40 GMT).
  [ok] AccountsClient.getAgent           keys=["agentId","agent_id","displayName","display_name","status"]

=== Onboarding handshake ===
[buttdial] Endpoint POST /api/orgs/register is deprecated (Sunset: Tue, 28 Jul 2026 19:53:11 GMT).
  [ok] register(branded)                 orgId=true webhookSecret=true pollToken=true

=== MCP surface (Agent) ===
  [ok] Agent.listTools                   57 tools
  [ok] Agent.ping                        ok=true
  [ok] Agent.sendMessage                 failed-as-expected stage=server errorCode=CHANNEL_UNAVAILABLE

=== Summary ===
  PASS=6  FAIL=0  SKIP=0  INFO=0
```

> **Side note from the Node smoke:** `Agent.sendMessage` failure code is `CHANNEL_UNAVAILABLE` against this agent today; previous Python probes saw `NO_CHANNEL_ASSIGNED` (F90). Either the server now distinguishes the two or the agent's state shifted between probes. Worth a quick look — both codes are valid F90-shape envelopes, just want to be sure the SDK's typed-error mapping covers both.

---

## Item movement vs. R6 → R8

| | R6 (post-r7 verify) | R8 (this doc) | Δ |
|---|---|---|---|
| ✅ FIXED | 58 / 92 (63%) | **60 / 92 (65%)** | +2 (F13, F57) |
| ⚠️ PARTIAL | 9 | 9 | 0 |
| ❌ OPEN | 21 | 19 | −2 (F13, F57) |
| 🚫 WONTFIX | 2 | 2 | 0 |
| ℹ️ INFO | 2 | 2 | 0 |

**Still open SDK-side:** none after F13/F57 close. The SDK release queue is empty; everything remaining is BD-server work or strategic items (F06 squatting, F86 surface unification).

**Still open BD-side:** the 19 in `BD_SERVER_OPEN_ITEMS.md` plus the new Q1 sunset replacement question.

---

## References

- This release: PyPI [`butt-dial-sdk==0.4.5`](https://pypi.org/project/butt-dial-sdk/0.4.5/) — npm `butt-dial-sdk@0.1.1` (publish pending auth)
- Python repo: <https://github.com/elradts/butt-dial-sdk> — commit `80b3b16`
- Node repo: <https://github.com/elradts/butt-dial-node-sdk> — commit `2d38ca3`
- Round-7 baseline: `docs/BD_SERVER_STATUS_AS_OF_R6.md` (v1.1)
- Open items list: `docs/BD_SERVER_OPEN_ITEMS.md`
- Earlier rounds: `docs/BD_SERVER_FEEDBACK*.md`
