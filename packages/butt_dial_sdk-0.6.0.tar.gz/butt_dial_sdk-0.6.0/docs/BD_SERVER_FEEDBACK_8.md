# BD Server — Round 8 ask (Item A is the only one left)

<!-- version: 1.0 | updated: 2026-05-08 -->

**SDK:** `butt-dial-sdk==0.5.2` (Python) / `butt-dial-sdk@0.2.2` (Node)
**Verified live against:** `https://call.95percent.ai`

---

## ✅ Thank-you note (Items B + C resolved)

You shipped 2 of the 3 asks from `BD_SERVER_FEEDBACK_7.md`:

- **Item B — `comms_get_me` registered.** Live MCP list now shows 58 tools (was 57). Server file: `packages/server/src/tools/get-me-profile.ts` with the comment *"after an integrator flagged the gap"* — appreciated.
  - SDK 0.5.2 / 0.2.2 ships matching `Agent.get_me()` / `agent.getMe()` wrappers using your tool. Live verified.

- **Item C — `comms_send_message` schema declares `threadId`/`entityId`/`replyMsgId`.** Confirmed at `packages/server/src/tools/send-message.ts:132-134`. The fields are now recorded and echoed back in the response per the descriptions you wrote. SDK callers will see correlation values in the response immediately.
  - SDK 0.5.2 / 0.2.2 updated the inline comments that previously claimed "BD silently strips them." They no longer say that.

---

## ❌ Item A — still open. Three endpoints emit `Sunset` headers with no successor pointer.

### Live evidence (re-checked 2026-05-08, 18:30 UTC)

```
$ curl -sI https://call.95percent.ai/api/v1/agents/me
Deprecation: true
Link: </docs#deprecations>; rel="deprecation"
Sunset: Thu, 06 Aug 2026 15:32:24 GMT

$ curl -sI https://call.95percent.ai/api/v1/agents/<id>
Deprecation: true
Link: </docs#deprecations>; rel="deprecation"
Sunset: Thu, 06 Aug 2026 15:32:24 GMT

$ curl -sI -X POST https://call.95percent.ai/api/orgs/register
(headers exist but no Link rel — Sunset varies between 07-28 / 08-05 / 08-06 across runs)
```

### Two problems with the current state

1. **`/docs#deprecations` doesn't exist.** Following the `Link` lands on `/docs/home`. The fragment isn't rendered. Anyone (LLM or human) following npm-style sunset semantics will hit a dead link.
2. **No `rel="successor-version"` link.** RFC 8594 + draft-ietf-httpapi-deprecation-header advise pairing `Sunset` with `Link rel="successor-version"` so clients can auto-discover the replacement. SDK clients can't programmatically migrate.

The Sunset date has also been moving (`07-28` → `08-05` → `08-06`), suggesting replacement endpoints aren't ready. **89 days remain** until the current `08-06` date.

### What we need from BD — one of three paths

**Path 1 — Replacements ready: ship them + populate Link.**
- Add `Link: </api/v1/{new-path}>; rel="successor-version"` on each deprecated response
- Document the replacements at `/docs/api-reference` (or wherever) and make `/docs#deprecations` a real anchor
- Once shipped: SDK ships 0.6.0 with both old (deprecated) wrappers and new ones, plus a transitional auto-migrate shim. Same-day turnaround possible.

**Path 2 — Replacements not coming this quarter: extend the Sunset.**
- Bump the Sunset date to a date BD can hit (e.g. `2027-01-01`) so the deprecation-header logger stops alerting integrators on every probe
- Avoids forcing SDK consumers into a panicked migration without a target

**Path 3 — Deprecation was provisional / not actually planned: remove the headers.**
- If `/api/orgs/register`, `/api/v1/agents/me`, and `/api/v1/agents/{id}` are not actually being sunset, drop the `Sunset` + `Deprecation` + `Link` headers
- These are core SDK surfaces; surfacing them as deprecated is high-cost noise

Any of the three is a clean answer. The current "mid-state" — sunset declared, no successor, date drifting — is the worst spot because it tells integrators *something is changing* without telling them *what or when*.

### Concrete code changes if Path 1

Replacement Link headers per endpoint (BD knows the right paths; these are illustrative):

```ts
// packages/server/src/api/register-router.ts (around the /api/orgs/register handler)
res.setHeader("Link", '</api/orgs/v2/register>; rel="successor-version", </docs/api-reference#orgs-register-v2>; rel="deprecation"');
res.setHeader("Sunset", "Thu, 06 Aug 2026 15:32:24 GMT");
res.setHeader("Deprecation", "true");

// rest-router.ts agents/me + agents/{id} similarly
```

Plus: render `/docs/api-reference` (or `/docs/deprecations`) with a section per deprecated endpoint listing successor + migration notes. Even a stub page that says *"successor TBD; please track this issue"* is better than the current 404 anchor.

### What we do NOT need from BD

- We don't need a 0.6.0 SDK release coordinated with a BD deploy — happy to pull the trigger on the SDK once endpoints exist
- We don't need backwards-compat at the BD level beyond the published Sunset date — the SDK handles the dual-version transition

---

## SDK readiness for Path 1 (when BD is ready)

When BD publishes successor endpoints, the SDK will:

1. Add new wrapper methods alongside existing ones (e.g. `accounts.register_v2()` / `accounts.registerV2()`)
2. Mark old ones with a runtime warning when called past the Sunset date − N days
3. Add a `_migrate=auto` opt-in flag on existing methods that auto-route to the v2 path, so consumers don't need code changes
4. Live-smoke both old and new in CI until the Sunset date
5. Cut SDK 0.6.0 / 0.3.0 with the migration

ETA from "BD publishes spec" to "SDK on PyPI + npm": **≤ 24 hours**.

---

## Summary line for BD's tracker

> "SDK 0.5.2 / 0.2.2 thanks BD for resolving the `comms_get_me` ghost reference and the `comms_send_message` correlation-fields schema gap. The 3 deprecated endpoints (`/api/orgs/register`, `/api/v1/agents/me`, `/api/v1/agents/{id}`) still need either a successor-path declaration, a Sunset extension, or removal of the deprecation headers — pick one. Current state (sunset declared, no successor, date drifting) is the worst option for SDK consumers."
