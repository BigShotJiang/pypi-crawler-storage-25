# LLM Woodpecker

LLM Woodpecker is an AI model debugging tool that supports both Chat mode and Raw JSON mode.

## Features

- **Chat Mode**: Interactive chat interface for testing LLM responses
- **Raw JSON Mode**: Direct JSON request/response testing with structured view
- **Multiple Model Support**: Configure and switch between different LLM providers
- **Streaming Support**: Real-time streaming responses
- **Modern UI**: Clean, responsive interface with collapsible content

## Installation

```bash
pip install llm-woodpecker
```

## Usage

### Web UI

```bash
llm-woodpecker
```

Then open http://127.0.0.1:7660 in your browser.

### Configuration

Initialize config file:
```bash
llm-woodpecker --init-config
```

List configured models:
```bash
llm-woodpecker --list-models
```

Set active model:
```bash
llm-woodpecker --set-model qwen
```

### Chat Mode (Terminal)

```bash
llm-woodpecker --chat
```

Or with a message:
```bash
llm-woodpecker --chat --messages '[{"role":"user","content":"Hello!"}]'
```

## Configuration File

The default config file is located at `~/.llm_woodpecker/config.yaml`.

## License

MIT License
