"""Configuration module for LLM Woodpecker"""

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Optional

import yaml


DEFAULT_CONFIG_DIR = Path.home() / ".llm_woodpecker"
DEFAULT_CONFIG_FILE = DEFAULT_CONFIG_DIR / "config.yaml"


class ModelConfig:
    """Model provider configuration"""

    def __init__(
        self,
        name: str,
        base_url: str,
        api_key: str = "",
        model_name: str = "",
        description: str = "",
    ):
        self.name = name
        self.base_url = base_url
        self.api_key = api_key
        self.model_name = model_name
        self.description = description

    def to_dict(self) -> dict:
        return {
            "base_url": self.base_url,
            "api_key": self.api_key,
            "model_name": self.model_name,
            "description": self.description,
        }

    @classmethod
    def from_dict(cls, name: str, data: dict) -> "ModelConfig":
        return cls(
            name=name,
            base_url=data.get("base_url", ""),
            api_key=data.get("api_key", ""),
            model_name=data.get("model_name", ""),
            description=data.get("description", ""),
        )


class LocalConfig:
    """Local configuration manager for LLM Woodpecker"""

    def __init__(self):
        self.models: dict[str, ModelConfig] = {}
        self.active_model: str = ""
        self.host: str = "127.0.0.1"
        self.port: int = 7660

    @classmethod
    def get_default_config_path(cls) -> Path:
        return DEFAULT_CONFIG_FILE

    @classmethod
    def ensure_config_dir(cls) -> None:
        DEFAULT_CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    def to_dict(self) -> dict:
        return {
            "models": {name: model.to_dict() for name, model in self.models.items()},
            "active_model": self.active_model,
            "host": self.host,
            "port": self.port,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "LocalConfig":
        config = cls()
        config.models = {
            name: ModelConfig.from_dict(name, model_data)
            for name, model_data in data.get("models", {}).items()
        }
        config.active_model = data.get("active_model", "")
        config.host = data.get("host", "127.0.0.1")
        config.port = data.get("port", 7660)
        return config

    def load(self, path: Optional[Path] = None) -> bool:
        config_path = path or self.get_default_config_path()
        if not config_path.exists():
            return False

        try:
            with open(config_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}

            config_data = self.from_dict(data)
            self.models = config_data.models
            self.active_model = config_data.active_model
            self.host = config_data.host
            self.port = config_data.port
            return True
        except Exception as e:
            print(f"[warn] Failed to load config from {config_path}: {e}")
            return False

    def save(self, path: Optional[Path] = None) -> bool:
        config_path = path or self.get_default_config_path()
        try:
            self.ensure_config_dir()
            with open(config_path, "w", encoding="utf-8") as f:
                yaml.dump(
                    self.to_dict(),
                    f,
                    default_flow_style=False,
                    allow_unicode=True,
                    sort_keys=False,
                )
            return True
        except Exception as e:
            print(f"[error] Failed to save config to {config_path}: {e}")
            return False

    @classmethod
    def create_default_config(cls, path: Optional[Path] = None) -> "LocalConfig":
        config = cls()
        config.models = {
            "qwen": ModelConfig(
                name="qwen",
                base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
                api_key="",
                model_name="qwen-plus",
                description="Qwen (阿里云百炼)",
            ),
            "kimi": ModelConfig(
                name="kimi",
                base_url="https://api.moonshot.cn/v1",
                api_key="",
                model_name="moonshot-v1-8k",
                description="Kimi (月之暗面)",
            ),
            "openai": ModelConfig(
                name="openai",
                base_url="https://api.openai.com/v1",
                api_key="",
                model_name="gpt-4o-mini",
                description="OpenAI",
            ),
            "local": ModelConfig(
                name="local",
                base_url="http://localhost:8000/v1",
                api_key="",
                model_name="",
                description="Local LLM Server",
            ),
        }
        config.active_model = "qwen"
        config.save(path)
        return config

    def get_active_model(self) -> Optional[ModelConfig]:
        if not self.active_model:
            return None
        return self.models.get(self.active_model)

    def set_active_model(self, name: str, path: Optional[Path] = None) -> bool:
        if name not in self.models:
            print(f"[error] Model '{name}' not found")
            return False
        self.active_model = name
        return self.save(path)

    def add_model(
        self,
        name: str,
        base_url: str,
        api_key: str = "",
        model_name: str = "",
        description: str = "",
        path: Optional[Path] = None,
    ) -> bool:
        self.models[name] = ModelConfig(
            name=name,
            base_url=base_url,
            api_key=api_key,
            model_name=model_name,
            description=description,
        )
        return self.save(path)

    def remove_model(self, name: str, path: Optional[Path] = None) -> bool:
        if name not in self.models:
            print(f"[error] Model '{name}' not found")
            return False
        if name == self.active_model:
            print(f"[error] Cannot remove active model '{name}'")
            return False
        del self.models[name]
        return self.save(path)

    def list_models(self) -> list[tuple[str, ModelConfig]]:
        return [(name, model) for name, model in self.models.items()]


class Config:
    """Configuration class for LLM Debugger"""

    def __init__(self):
        self.base_url: str = ""
        self.api_key: str = ""
        self.model_name: str = ""
        self.host: str = "127.0.0.1"
        self.port: int = 7660
        self.local_config: Optional[LocalConfig] = None

    @classmethod
    def from_args(cls) -> "Config":
        config = cls()

        help_text = """
LLM Woodpecker - AI Model Debugging Tool

Commands:
  llm-woodpecker                      Start web UI server
  llm-woodpecker --chat               Run chat mode in terminal
  llm-woodpecker --chat --messages '[{"role":"user","content":"Hello"}]'
  llm-woodpecker --print-config-path  Print config file path
  llm-woodpecker --init-config        Create default config file
  llm-woodpecker --list-models        List all configured models
  llm-woodpecker --set-model NAME     Switch active model

Config file: ~/.llm_woodpecker/config.yaml
"""

        parser = argparse.ArgumentParser(
            description="LLM Woodpecker",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog=help_text,
        )
        parser.add_argument("--config", type=str, help="Config file path")
        parser.add_argument(
            "--print-config-path", action="store_true", help="Print config file path"
        )
        parser.add_argument(
            "--init-config", action="store_true", help="Initialize default config file"
        )
        parser.add_argument(
            "--list-models", action="store_true", help="List all configured models"
        )
        parser.add_argument(
            "--set-model", type=str, metavar="NAME", help="Set active model"
        )
        parser.add_argument(
            "--add-model",
            type=str,
            metavar="NAME",
            help="Add new model (requires --base-url)",
        )
        parser.add_argument("--base-url", type=str, help="Base URL (used with --add-model)")
        parser.add_argument(
            "--api-key", type=str, help="API key (used with --add-model)"
        )
        parser.add_argument(
            "--model-name", type=str, default="", help="Model name (used with --add-model)"
        )
        parser.add_argument(
            "--description",
            type=str,
            default="",
            help="Description (used with --add-model)",
        )
        parser.add_argument(
            "--chat", action="store_true", help="Run chat mode in terminal"
        )
        parser.add_argument(
            "--messages", type=str, help="JSON messages for chat mode"
        )
        parser.add_argument(
            "--system", type=str, default="", help="System prompt for chat"
        )
        parser.add_argument(
            "--stream",
            action="store_true",
            default=False,
            help="Enable streaming for chat",
        )

        args = parser.parse_args()

        # Load local config
        config_path = Path(args.config) if args.config else None
        config.local_config = LocalConfig()

        if config_path and config_path.exists():
            config.local_config.load(config_path)
        else:
            config.local_config.load()

        # Handle print-config-path
        if args.print_config_path:
            print(str(config.local_config.get_default_config_path().resolve()))
            sys.exit(0)

        # Handle init-config
        if args.init_config:
            LocalConfig.ensure_config_dir()
            cfg_path = config_path or cls.get_default_config_path()
            cfg = LocalConfig.create_default_config(cfg_path)
            print(f"Config path: {cfg.get_default_config_path().resolve()}")
            print("Default config created.")
            sys.exit(0)

        # Handle list-models
        if args.list_models:
            config._print_models()
            sys.exit(0)

        # Handle set-model
        if args.set_model:
            print(
                f"Config path: {str(config.local_config.get_default_config_path().resolve())}"
            )
            if config.local_config.set_active_model(args.set_model, config_path):
                print(f"Active model set to: {args.set_model}")
            sys.exit(0)

        # Handle add-model
        if args.add_model:
            print(
                f"Config path: {str(config.local_config.get_default_config_path().resolve())}"
            )
            if not args.base_url:
                print("[error] --add-model requires --base-url")
                sys.exit(1)
            if config.local_config.add_model(
                args.add_model,
                args.base_url,
                args.api_key or "",
                args.model_name,
                args.description,
                config_path,
            ):
                print(f"Added model: {args.add_model}")
            sys.exit(0)

        # Get active model config
        active = config.local_config.get_active_model()
        if active:
            config.base_url = active.base_url.rstrip("/")
            config.api_key = active.api_key
            config.model_name = active.model_name

        config.host = config.local_config.host
        config.port = config.local_config.port

        return config

    @classmethod
    def get_default_config_path(cls) -> Path:
        return DEFAULT_CONFIG_FILE

    def _print_models(self) -> None:
        """Print all available models"""
        models = self.local_config.list_models()
        print(f"Config path: {str(self.local_config.get_default_config_path().resolve())}")

        if not models:
            print("No models configured.")
            print("Run with --init-config to create a default config.")
            return

        print("\nAvailable models:")
        print("-" * 50)
        active = self.local_config.active_model

        for name, model in models:
            marker = " *" if name == active else ""
            print(f"  {name}{marker}")
            print(f"    Base URL: {model.base_url}")
            print(f"    Model: {model.model_name}")
            if model.description:
                print(f"    Description: {model.description}")
            if model.api_key:
                print(f"    API Key: {model.api_key[:8]}...")
            print()
