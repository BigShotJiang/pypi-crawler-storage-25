"""Web UI module for LLM Woodpecker"""

import json
import logging
from typing import Optional

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from .chat import ChatClient
from .config import Config
import pkgutil

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("llm_woodpecker.ui")


class ChatRequest(BaseModel):
    messages: list[dict]
    model: Optional[str] = None
    stream: bool = False
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    frequency_penalty: Optional[float] = None
    presence_penalty: Optional[float] = None
    stop: Optional[list[str]] = None


class EmbeddingsRequest(BaseModel):
    input_text: str
    model: Optional[str] = None


class AddModelRequest(BaseModel):
    name: str
    base_url: str
    api_key: Optional[str] = ""
    model_name: Optional[str] = ""
    description: Optional[str] = ""


class SetActiveModelRequest(BaseModel):
    name: str


def create_app(config: Config) -> FastAPI:
    """Create FastAPI app for LLM Woodpecker"""
    app = FastAPI(title="LLM Woodpecker", description="AI Model Debugging Tool")

    client = ChatClient(
        base_url=config.base_url, api_key=config.api_key, model_name=config.model_name
    )

    @app.get("/")
    def index():
        """Serve index page"""
        data = pkgutil.get_data(__name__, "static/debugger.html")
        if data is None:
            return Response(content="Index file not found", status_code=404)
        return Response(content=data, media_type="text/html")

    @app.get("/api/config")
    def get_config():
        """Get current configuration"""
        return JSONResponse(
            {
                "base_url": config.base_url,
                "model_name": config.model_name,
                "host": config.host,
                "port": config.port,
            }
        )

    @app.get("/api/models")
    def list_models():
        """List all configured models"""
        models = config.local_config.list_models()
        return JSONResponse(
            {
                "active": config.local_config.active_model,
                "models": [
                    {
                        "name": name,
                        "base_url": m.base_url,
                        "model_name": m.model_name,
                        "description": m.description,
                        "has_api_key": bool(m.api_key),
                    }
                    for name, m in models
                ],
            }
        )

    @app.post("/api/models")
    def add_model(request: AddModelRequest):
        """Add a new model"""
        try:
            if request.name in config.local_config.models:
                return JSONResponse(
                    {"error": f"Model '{request.name}' already exists"},
                    status_code=400,
                )
            config.local_config.add_model(
                name=request.name,
                base_url=request.base_url,
                api_key=request.api_key or "",
                model_name=request.model_name or "",
                description=request.description or "",
            )
            return JSONResponse({"success": True, "name": request.name})
        except Exception as e:
            return JSONResponse({"error": str(e)}, status_code=500)

    @app.delete("/api/models/{name}")
    def delete_model(name: str):
        """Delete a model"""
        try:
            if name == config.local_config.active_model:
                config.local_config.active_model = ""
                config.local_config.save()
            if config.local_config.remove_model(name):
                return JSONResponse({"success": True, "name": name})
            return JSONResponse(
                {"error": f"Model '{name}' not found"},
                status_code=404,
            )
        except Exception as e:
            return JSONResponse({"error": str(e)}, status_code=500)

    @app.put("/api/models/{name}/active")
    def set_active_model(name: str):
        """Set active model"""
        try:
            if name not in config.local_config.models:
                return JSONResponse(
                    {"error": f"Model '{name}' not found"},
                    status_code=404,
                )
            if config.local_config.set_active_model(name):
                active = config.local_config.get_active_model()
                if active:
                    client.base_url = active.base_url.rstrip("/")
                    client.api_key = active.api_key
                    client.model_name = active.model_name
                return JSONResponse({"success": True, "name": name})
            return JSONResponse({"error": "Failed to set active model"}, status_code=500)
        except Exception as e:
            return JSONResponse({"error": str(e)}, status_code=500)

    @app.post("/api/chat")
    async def chat(request: ChatRequest):
        """Handle chat request"""
        logger.info("Chat request: model=%s, stream=%s, messages=%d", 
                   request.model or client.model_name, request.stream, len(request.messages))
        try:
            kwargs = {}
            if request.temperature is not None:
                kwargs["temperature"] = request.temperature
            if request.max_tokens is not None:
                kwargs["max_tokens"] = request.max_tokens
            if request.top_p is not None:
                kwargs["top_p"] = request.top_p
            if request.frequency_penalty is not None:
                kwargs["frequency_penalty"] = request.frequency_penalty
            if request.presence_penalty is not None:
                kwargs["presence_penalty"] = request.presence_penalty
            if request.stop is not None:
                kwargs["stop"] = request.stop

            # Get actual model name from config if request.model is a model index name
            actual_model_name = request.model
            if request.model:
                model_config = config.local_config.models.get(request.model)
                if model_config and model_config.model_name:
                    actual_model_name = model_config.model_name

            result = client.chat(
                messages=request.messages,
                model=actual_model_name,
                stream=request.stream,
                **kwargs,
            )
            logger.info("Chat response received successfully")
            return JSONResponse(result)
        except httpx.HTTPStatusError as e:
            logger.error("Chat HTTP error: %d - %s", e.response.status_code, e.response.text[:500])
            return JSONResponse(
                {"error": f"HTTP {e.response.status_code}: {e.response.text}"},
                status_code=e.response.status_code,
            )
        except Exception as e:
            logger.error("Chat error: %s", str(e), exc_info=True)
            return JSONResponse({"error": str(e)}, status_code=500)

    @app.post("/api/embeddings")
    async def embeddings(request: EmbeddingsRequest):
        """Handle embeddings request"""
        try:
            result = client.embeddings(
                input_text=request.input_text, model=request.model
            )
            return JSONResponse(result)
        except httpx.HTTPStatusError as e:
            return JSONResponse(
                {"error": f"HTTP {e.response.status_code}: {e.response.text}"},
                status_code=e.response.status_code,
            )
        except Exception as e:
            return JSONResponse({"error": str(e)}, status_code=500)

    @app.post("/api/chat-stream")
    async def chat_stream(request: ChatRequest):
        """Handle streaming chat request"""
        from starlette.background import BackgroundTask
        from starlette.datastructures import Headers
        from starlette.responses import StreamingResponse as StarletteStreamingResponse

        async def generate():
            try:
                kwargs = {}
                if request.temperature is not None:
                    kwargs["temperature"] = request.temperature
                if request.max_tokens is not None:
                    kwargs["max_tokens"] = request.max_tokens

                result = client.chat(
                    messages=request.messages,
                    model=request.model,
                    stream=True,
                    **kwargs,
                )

                for content in result:
                    if content:
                        yield f"data: {json.dumps({'content': content})}\n\n"
                yield "data: [DONE]\n\n"
            except Exception as e:
                yield f"data: {json.dumps({'error': str(e)})}\n\n"

        return StarletteStreamingResponse(
            generate(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache"},
        )

    return app


async def run_ui(config: Config) -> None:
    """Run the web UI server"""
    import uvicorn

    app = create_app(config)
    print(f"LLM Woodpecker Web UI → http://{config.host}:{config.port}")
    print(f"API Endpoint: {config.base_url}")
    print(f"Model: {config.model_name}")
    print()

    config_uvicorn = uvicorn.Config(
        app, host=config.host, port=config.port, log_level="info"
    )
    await uvicorn.Server(config_uvicorn).serve()
