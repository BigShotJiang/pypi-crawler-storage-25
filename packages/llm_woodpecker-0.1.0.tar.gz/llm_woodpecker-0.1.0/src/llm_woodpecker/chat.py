"""Chat/Request module for LLM Debugger"""

import json
from typing import Any, AsyncIterator, Optional

import httpx


class ChatClient:
    """Client for chatting with LLM models"""

    def __init__(self, base_url: str, api_key: str, model_name: str = ""):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model_name = model_name
        self.timeout = 120.0

    def _get_headers(self) -> dict:
        headers = {
            "Content-Type": "application/json",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def chat(
        self,
        messages: list[dict],
        model: Optional[str] = None,
        stream: bool = False,
        **kwargs,
    ) -> dict | AsyncIterator[str]:
        """Send chat completion request"""
        url = f"{self.base_url}/chat/completions"

        payload: dict[str, Any] = {
            "messages": messages,
            "stream": stream,
        }

        model_to_use = model or self.model_name
        if model_to_use:
            payload["model"] = model_to_use

        # Add extra parameters
        for key, value in kwargs.items():
            if value is not None:
                payload[key] = value

        if stream:
            return self._stream_chat(url, payload)
        else:
            return self._sync_chat(url, payload)

    def _sync_chat(self, url: str, payload: dict) -> dict:
        """Synchronous chat request"""
        with httpx.Client(timeout=self.timeout) as client:
            response = client.post(
                url, headers=self._get_headers(), json=payload, timeout=self.timeout
            )
            response.raise_for_status()
            return response.json()

    def _stream_chat(self, url: str, payload: dict) -> AsyncIterator[str]:
        """Streaming chat request"""

        def generator():
            with httpx.Client(timeout=self.timeout) as client:
                with client.stream(
                    "POST", url, headers=self._get_headers(), json=payload
                ) as response:
                    response.raise_for_status()
                    for line in response.iter_lines():
                        if line.startswith("data:"):
                            data = line[5:].strip()
                            if data == "[DONE]":
                                break
                            try:
                                chunk = json.loads(data)
                                if chunk.get("choices"):
                                    delta = chunk["choices"][0].get("delta", {})
                                    content = delta.get("content", "")
                                    if content:
                                        yield content
                            except json.JSONDecodeError:
                                pass

        return generator()

    def embeddings(self, input_text: str, model: Optional[str] = None) -> dict:
        """Get embeddings"""
        url = f"{self.base_url}/embeddings"

        payload: dict[str, Any] = {
            "input": input_text,
        }

        model_to_use = model or self.model_name
        if model_to_use:
            payload["model"] = model_to_use

        with httpx.Client(timeout=self.timeout) as client:
            response = client.post(
                url, headers=self._get_headers(), json=payload, timeout=self.timeout
            )
            response.raise_for_status()
            return response.json()


def format_json(data: Any, indent: int = 2) -> str:
    """Format data as pretty JSON"""
    return json.dumps(data, indent=indent, ensure_ascii=False)


def format_markdown(data: dict) -> str:
    """Format chat response as markdown"""
    lines = []

    if "model" in data:
        lines.append(f"**Model:** {data['model']}")

    if "created" in data:
        lines.append(f"**Created:** {data['created']}")

    if "usage" in data and data["usage"]:
        usage = data["usage"]
        lines.append("\n**Usage:**")
        if "prompt_tokens" in usage:
            lines.append(f"- Prompt tokens: {usage['prompt_tokens']}")
        if "completion_tokens" in usage:
            lines.append(f"- Completion tokens: {usage['completion_tokens']}")
        if "total_tokens" in usage:
            lines.append(f"- Total tokens: {usage['total_tokens']}")

    if "choices" in data:
        lines.append("\n**Choices:**")
        for i, choice in enumerate(data["choices"]):
            lines.append(f"\n### Choice {i + 1}")
            if "finish_reason" in choice:
                lines.append(f"**Finish Reason:** {choice['finish_reason']}")

            message = choice.get("message", {})
            if message:
                role = message.get("role", "assistant")
                content = message.get("content", "")
                lines.append(f"\n**{role.capitalize()}:**\n{content}")

            delta = choice.get("delta", {})
            if delta:
                content = delta.get("content", "")
                if content:
                    lines.append(f"\n**Delta:**\n{content}")

    return "\n".join(lines) if lines else format_json(data)
