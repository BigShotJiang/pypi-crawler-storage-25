"""Main entry point for LLM Woodpecker"""

import argparse
import asyncio
import json
import sys
from typing import Optional

from .chat import ChatClient, format_json, format_markdown
from .config import Config, LocalConfig
from .ui import run_ui


async def run_chat_mode(
    config: Config,
    messages: Optional[str] = None,
    system: str = "",
    stream: bool = False,
) -> None:
    """Run chat mode in terminal"""
    client = ChatClient(
        base_url=config.base_url,
        api_key=config.api_key,
        model_name=config.model_name,
    )

    if not config.api_key:
        print("[warning] No API key configured, requests may fail.")

    print(f"Model: {config.model_name}")
    print(f"Base URL: {config.base_url}")
    print("-" * 50)

    # Build messages
    if messages:
        try:
            chat_messages = json.loads(messages)
            if not isinstance(chat_messages, list):
                print("[error] Messages must be a JSON array")
                return
        except json.JSONDecodeError as e:
            print(f"[error] Invalid JSON: {e}")
            return
    else:
        chat_messages = []

    if system:
        chat_messages.insert(0, {"role": "system", "content": system})

    if not chat_messages:
        print("Interactive chat mode (type 'exit' to quit)")
        print("-" * 50)
        while True:
            try:
                user_input = input("\nYou: ")
                if user_input.lower() in ("exit", "quit", "q"):
                    break
                if not user_input.strip():
                    continue

                chat_messages.append({"role": "user", "content": user_input})

                print("\nAssistant: ", end="", flush=True)
                if stream:
                    response = client.chat(messages=chat_messages, stream=True)
                    full_response = ""
                    for chunk in response:
                        print(chunk, end="", flush=True)
                        full_response += chunk
                    chat_messages.append({"role": "assistant", "content": full_response})
                else:
                    result = client.chat(messages=chat_messages)
                    content = ""
                    if "choices" in result and result["choices"]:
                        content = result["choices"][0]["message"].get("content", "")
                        print(content)
                        chat_messages.append({"role": "assistant", "content": content})

                    # Print usage
                    if "usage" in result and result["usage"]:
                        usage = result["usage"]
                        print(f"\n[Usage: {usage.get('total_tokens', 0)} tokens]")
            except KeyboardInterrupt:
                print("\n\nExiting...")
                break
            except Exception as e:
                print(f"\n[error] {e}")
    else:
        # Non-interactive mode
        print("Sending messages...")
        print(f"Messages: {format_json(chat_messages)}")
        print("-" * 50)

        try:
            if stream:
                print("\nAssistant (streaming):")
                print("-" * 50)
                response = client.chat(messages=chat_messages, stream=True)
                full_response = ""
                for chunk in response:
                    print(chunk, end="", flush=True)
                    full_response += chunk
                print("\n" + "-" * 50)
                print(f"[Total tokens: {len(full_response)} chars]")
            else:
                result = client.chat(messages=chat_messages)
                print("\nResponse:")
                print("-" * 50)
                print(format_markdown(result))
        except Exception as e:
            print(f"[error] {e}")
            sys.exit(1)


async def run_woodpecker(config: Config) -> None:
    """Run the woodpecker web UI"""
    await run_ui(config)


def main() -> None:
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="LLM Woodpecker",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--chat", action="store_true", help="Run chat mode in terminal")
    parser.add_argument("--messages", type=str, help="JSON messages for chat mode")
    parser.add_argument("--system", type=str, default="", help="System prompt for chat")
    parser.add_argument(
        "--stream", action="store_true", default=False, help="Enable streaming for chat"
    )
    parser.add_argument(
        "--print-config-path",
        action="store_true",
        help="Print config file path",
    )
    parser.add_argument(
        "--init-config", action="store_true", help="Initialize default config file"
    )
    parser.add_argument(
        "--list-models", action="store_true", help="List all configured models"
    )
    parser.add_argument(
        "--set-model", type=str, metavar="NAME", help="Set active model"
    )
    parser.add_argument(
        "--add-model",
        type=str,
        metavar="NAME",
        help="Add new model (requires --base-url)",
    )
    parser.add_argument(
        "--base-url", type=str, help="Base URL (used with --add-model)"
    )
    parser.add_argument(
        "--api-key", type=str, help="API key (used with --add-model)"
    )
    parser.add_argument(
        "--model-name", type=str, default="", help="Model name (used with --add-model)"
    )
    parser.add_argument(
        "--description",
        type=str,
        default="",
        help="Description (used with --add-model)",
    )

    args = parser.parse_args()

    # Build help text
    help_text = """
LLM Woodpecker - AI Model Debugging Tool

Commands:
  llm-woodpecker                      Start web UI server
  llm-woodpecker --chat               Run chat mode in terminal
  llm-woodpecker --chat --messages '[{"role":"user","content":"Hello"}]'
  llm-woodpecker --print-config-path  Print config file path
  llm-woodpecker --init-config        Create default config file
  llm-woodpecker --list-models        List all configured models
  llm-woodpecker --set-model NAME     Switch active model

Config file: ~/.llm_woodpecker/config.yaml
"""

    if len(sys.argv) == 1:
        print(help_text)

    # Load config
    config = Config()

    config.local_config = LocalConfig()
    if not config.local_config.load():
        config.local_config = LocalConfig()

    # Handle print-config-path
    if args.print_config_path:
        print(str(config.local_config.get_default_config_path().resolve()))
        sys.exit(0)

    # Handle init-config
    if args.init_config:
        LocalConfig.ensure_config_dir()
        cfg = LocalConfig.create_default_config()
        print(f"Config path: {cfg.get_default_config_path().resolve()}")
        print("Default config created.")
        sys.exit(0)

    # Handle list-models
    if args.list_models:
        print(
            f"Config path: {str(config.local_config.get_default_config_path().resolve())}"
        )
        models = config.local_config.list_models()
        if not models:
            print("No models configured.")
            print("Run with --init-config to create a default config.")
        else:
            print("\nAvailable models:")
            print("-" * 50)
            active = config.local_config.active_model
            for name, model in models:
                marker = " *" if name == active else ""
                print(f"  {name}{marker}")
                print(f"    Base URL: {model.base_url}")
                print(f"    Model: {model.model_name}")
                if model.description:
                    print(f"    Description: {model.description}")
                if model.api_key:
                    print(f"    API Key: {model.api_key[:8]}...")
                print()
        sys.exit(0)

    # Handle set-model
    if args.set_model:
        print(
            f"Config path: {str(config.local_config.get_default_config_path().resolve())}"
        )
        if config.local_config.set_active_model(args.set_model):
            print(f"Active model set to: {args.set_model}")
        sys.exit(0)

    # Handle add-model
    if args.add_model:
        print(
            f"Config path: {str(config.local_config.get_default_config_path().resolve())}"
        )
        if not args.base_url:
            print("[error] --add-model requires --base-url")
            sys.exit(1)
        if config.local_config.add_model(
            args.add_model,
            args.base_url,
            args.api_key or "",
            args.model_name,
            args.description,
        ):
            print(f"Added model: {args.add_model}")
        sys.exit(0)

    # Get active model config
    active = config.local_config.get_active_model()
    if active:
        config.base_url = active.base_url.rstrip("/")
        config.api_key = active.api_key
        config.model_name = active.model_name

    config.host = config.local_config.host
    config.port = config.local_config.port

    # Handle chat mode
    if args.chat:
        asyncio.run(run_chat_mode(config, args.messages, args.system, args.stream))
    else:
        # Run web UI
        asyncio.run(run_woodpecker(config))


if __name__ == "__main__":
    main()
