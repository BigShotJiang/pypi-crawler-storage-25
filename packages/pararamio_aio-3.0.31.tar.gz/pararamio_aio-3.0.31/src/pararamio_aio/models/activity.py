"""Async Activity model with async-specific methods."""

from __future__ import annotations

from collections.abc import Callable, Coroutine
from datetime import datetime
from typing import Any

from pararamio_aio._core.api_schemas.responses import UserActivityResponse
from pararamio_aio._core.models import Activity as CoreActivity
from pararamio_aio._core.models import ActivityAction
from pararamio_aio._core.models.activity import iter_activity_windows

__all__ = ('Activity', 'ActivityAction')


class Activity(CoreActivity):
    """Async Activity model with async get_activity method."""

    @classmethod
    async def get_activity(
        cls,
        page_loader: Callable[..., Coroutine[Any, Any, UserActivityResponse]],
        start: datetime,
        end: datetime,
        actions: list[ActivityAction] | None = None,
    ) -> list[Activity]:
        """Get user activity within date range (async version).

        The server filters by ``start``/``end`` directly and rejects periods longer
        than 14 days, so the range is split into 14-day windows here. With the
        time filter active the server returns the full window in one response —
        no pagination is needed.

        Args:
            page_loader: Async function taking ``(start, end, actions)`` and
                returning a ``UserActivityResponse`` for that window.
            start: Range start (inclusive).
            end: Range end (inclusive).
            actions: Optional list of actions to filter.

        Returns:
            List of Activity objects sorted by time.
        """
        results: list[Activity] = []
        for window_start, window_end in iter_activity_windows(start, end):
            response = await page_loader(window_start, window_end, actions)
            results.extend(
                cls.from_api_data(item)
                for item in response.get('data', response.get('activities', []))
            )
        return sorted(results, key=lambda x: x.time)
