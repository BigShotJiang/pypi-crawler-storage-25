"""AES-GCM session-key encrypt/decrypt for Pararam e2e post bodies.

Wire format for the body portion of an e2e post:

    CT_B64$IV_B64

where `CT_B64` = standard-base64 of (ciphertext || 128-bit GCM tag)
and `IV_B64` = standard-base64 of a 12-byte random IV.
"""

from __future__ import annotations

import secrets

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .keys import b64_decode, b64_encode

__all__ = ['decrypt_text', 'encrypt_text']


_GCM_IV_LEN = 12
_GCM_TAG_LEN_BITS = 128  # default for WebCrypto AES-GCM; cryptography.hazmat uses 128-bit too


def encrypt_text(session_key: bytes, plaintext: str) -> str:
    """Encrypt UTF-8 text with a session key, return `CT_B64$IV_B64`.

    Uses a freshly-generated 12-byte random IV; never reuse IVs under the
    same key — this helper makes that impossible by generating per-call.
    """
    if len(session_key) != 32:
        raise ValueError('session_key must be 32 bytes (AES-256)')
    iv = secrets.token_bytes(_GCM_IV_LEN)
    ct = AESGCM(session_key).encrypt(iv, plaintext.encode('utf-8'), None)
    return f'{b64_encode(ct)}${b64_encode(iv)}'


def decrypt_text(session_key: bytes, body: str) -> str:
    """Decrypt a `CT_B64$IV_B64` body back to UTF-8 plaintext.

    Raises `cryptography.exceptions.InvalidTag` on auth-tag mismatch —
    never returns garbled text on tamper.
    """
    if len(session_key) != 32:
        raise ValueError('session_key must be 32 bytes (AES-256)')
    ct_b64, _, iv_b64 = body.partition('$')
    if not iv_b64:
        raise ValueError("e2e body missing '$' separator between ciphertext and IV")
    iv = b64_decode(iv_b64)
    if len(iv) != _GCM_IV_LEN:
        raise ValueError(f'IV must be {_GCM_IV_LEN} bytes, got {len(iv)}')
    ct = b64_decode(ct_b64)
    return AESGCM(session_key).decrypt(iv, ct, None).decode('utf-8')
