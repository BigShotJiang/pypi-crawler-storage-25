"""End-to-end encryption primitives for Pararam chat.

Pararam wraps each e2e post as:

    <e2e>CT_B64$IV_B64<keys>USER_ID_1&WRAPPED_KEY_1$USER_ID_2&WRAPPED_KEY_2$...

Where:
* The post's symmetric session key (AES-256-GCM) is fresh per post.
* `CT_B64$IV_B64` — base64(ciphertext with 128-bit GCM tag appended) +
  base64(12-byte IV).
* Each `WRAPPED_KEY` is base64(RSA-OAEP-SHA256(recipient_pubkey,
  session_key_serialized)). `session_key_serialized` uses JWK "oct"
  form flattened as `kty$alg$ext$k_base64url`.

RSA keys are 2048-bit, OAEP-SHA256 (`RSA-OAEP-256`). Public keys are
serialized as `kty$e$alg$ext$n`; private keys as
`kty$e$alg$ext$n$p$q$qi$d$dp$dq[:::timestamp]` where the optional
`:::timestamp` is an ISO 8601 tag the client appends for key-rotation
bookkeeping (ignored on import).

Importing this module requires the optional `cryptography` dependency.
Install the lib with `pararamio-core[e2e]` (or the parent package's e2e
extra) to pull it in.
"""

from __future__ import annotations

try:
    from .keys import (
        E2EKey,
        parse_aes_session_key,
        parse_rsa_private_key_str,
        parse_rsa_public_key_str,
        serialize_aes_session_key,
        serialize_rsa_public_key,
    )
    from .post_format import (
        E2E_MARKER,
        KEYS_MARKER,
        WrappedKey,
        build_e2e_post_text,
        encrypt_e2e_message,
        is_e2e_post_text,
        parse_e2e_post_text,
    )
    from .session import decrypt_text, encrypt_text
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        'pararamio e2e requires the `cryptography` package. '
        'Install with: pip install pararamio-core[e2e] '
        '(or add cryptography>=42.0 to your environment).'
    ) from exc

__all__ = [
    'E2E_MARKER',
    'KEYS_MARKER',
    'E2EKey',
    'WrappedKey',
    'build_e2e_post_text',
    'decrypt_text',
    'encrypt_e2e_message',
    'encrypt_text',
    'is_e2e_post_text',
    'parse_aes_session_key',
    'parse_e2e_post_text',
    'parse_rsa_private_key_str',
    'parse_rsa_public_key_str',
    'serialize_aes_session_key',
    'serialize_rsa_public_key',
]
