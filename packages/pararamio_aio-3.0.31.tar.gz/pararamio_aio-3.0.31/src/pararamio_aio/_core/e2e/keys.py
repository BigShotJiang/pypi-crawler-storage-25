"""RSA + AES key parsing / serialization for Pararam e2e.

All base64 operations mirror the web client's conventions:
* JWK fields (RSA/AES parameters) use base64url (no padding).
* Wire-level byte blobs (wrapped session keys, ciphertexts, IVs) use
  standard base64 (with padding) — as produced by `btoa()`.
"""

from __future__ import annotations

import base64
import secrets
from dataclasses import dataclass

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa

__all__ = [
    'AES_JWK_ALG',
    'RSA_JWK_ALG',
    'E2EKey',
    'b64_decode',
    'b64_encode',
    'b64url_decode',
    'b64url_encode',
    'parse_aes_session_key',
    'parse_rsa_private_key_str',
    'parse_rsa_public_key_str',
    'serialize_aes_session_key',
    'serialize_rsa_public_key',
]


RSA_JWK_ALG = 'RSA-OAEP-256'
AES_JWK_ALG = 'A256GCM'


# ---------------------------------------------------------------------------
# base64 helpers
# ---------------------------------------------------------------------------


def b64url_encode(raw: bytes) -> str:
    """base64url without padding — matches WebCrypto JWK encoding."""
    return base64.urlsafe_b64encode(raw).rstrip(b'=').decode('ascii')


def b64url_decode(s: str) -> bytes:
    """Inverse of b64url_encode — add padding back, then decode."""
    pad = (-len(s)) % 4
    return base64.urlsafe_b64decode(s + '=' * pad)


def b64_encode(raw: bytes) -> str:
    """Standard base64 (with padding) — matches browser btoa()."""
    return base64.b64encode(raw).decode('ascii')


def b64_decode(s: str) -> bytes:
    """Standard base64 (with padding)."""
    return base64.b64decode(s)


# ---------------------------------------------------------------------------
# RSA parsing / serialization
# ---------------------------------------------------------------------------


def _int_to_b64url(value: int, byte_length: int | None = None) -> str:
    """Big-endian integer → base64url string. If `byte_length` is None the
    minimum number of bytes is used.
    """
    if byte_length is None:
        byte_length = (value.bit_length() + 7) // 8 or 1
    return b64url_encode(value.to_bytes(byte_length, 'big'))


def parse_rsa_private_key_str(s: str) -> rsa.RSAPrivateKey:
    """Parse Pararam's flattened JWK RSA private key string into a key object.

    Format: `kty$e$alg$ext$n$p$q$qi$d$dp$dq[:::timestamp]`. The trailing
    `:::timestamp` suffix (if present) is tolerated and ignored — it's a
    client-side creation/rotation marker, not part of the key material.
    """
    parts = s.split('$')
    if len(parts) < 11:
        raise ValueError(f'expected at least 11 $-separated parts, got {len(parts)}')
    # Strip optional ":::timestamp" suffix from the last part (dq).
    dq_raw = parts[10].split(':::', 1)[0]

    n = int.from_bytes(b64url_decode(parts[4]), 'big')
    e = int.from_bytes(b64url_decode(parts[1]), 'big')
    p = int.from_bytes(b64url_decode(parts[5]), 'big')
    q = int.from_bytes(b64url_decode(parts[6]), 'big')
    qi = int.from_bytes(b64url_decode(parts[7]), 'big')
    d = int.from_bytes(b64url_decode(parts[8]), 'big')
    dp = int.from_bytes(b64url_decode(parts[9]), 'big')
    dq = int.from_bytes(b64url_decode(dq_raw), 'big')

    pub = rsa.RSAPublicNumbers(e=e, n=n)
    priv = rsa.RSAPrivateNumbers(p=p, q=q, d=d, dmp1=dp, dmq1=dq, iqmp=qi, public_numbers=pub)
    return priv.private_key()


def parse_rsa_public_key_str(s: str) -> rsa.RSAPublicKey:
    """Parse Pararam's flattened JWK RSA public key string.

    Format: `kty$e$alg$ext$n` — 5 parts.
    """
    parts = s.split('$')
    if len(parts) < 5:
        raise ValueError(f'expected at least 5 $-separated parts, got {len(parts)}')
    n = int.from_bytes(b64url_decode(parts[4]), 'big')
    e = int.from_bytes(b64url_decode(parts[1]), 'big')
    return rsa.RSAPublicNumbers(e=e, n=n).public_key()


def serialize_rsa_public_key(key: rsa.RSAPublicKey) -> str:
    """Serialize an RSA public key to Pararam's `kty$e$alg$ext$n` form."""
    numbers = key.public_numbers()
    n_bytes = (key.key_size + 7) // 8
    e_bytes = max(1, (numbers.e.bit_length() + 7) // 8)
    return '$'.join([
        'RSA',
        _int_to_b64url(numbers.e, e_bytes),
        RSA_JWK_ALG,
        'true',
        _int_to_b64url(numbers.n, n_bytes),
    ])


# ---------------------------------------------------------------------------
# AES session key parsing / serialization
# ---------------------------------------------------------------------------


def parse_aes_session_key(s: str) -> bytes:
    """Parse a session key string `kty$alg$ext$k` into raw 32 AES-256 bytes."""
    parts = s.split('$')
    if len(parts) < 4:
        raise ValueError(f'expected 4 $-separated parts, got {len(parts)}')
    if parts[0] != 'oct':
        raise ValueError(f"expected kty 'oct', got {parts[0]!r}")
    if parts[1] != AES_JWK_ALG:
        raise ValueError(f'expected alg {AES_JWK_ALG}, got {parts[1]!r}')
    key_bytes = b64url_decode(parts[3])
    if len(key_bytes) != 32:
        raise ValueError(f'expected 32-byte AES-256 key, got {len(key_bytes)} bytes')
    return key_bytes


def serialize_aes_session_key(key_bytes: bytes) -> str:
    """Serialize raw AES-256 key bytes to Pararam's `oct$A256GCM$true$k` form."""
    if len(key_bytes) != 32:
        raise ValueError(f'expected 32-byte AES-256 key, got {len(key_bytes)} bytes')
    return f'oct${AES_JWK_ALG}$true${b64url_encode(key_bytes)}'


# ---------------------------------------------------------------------------
# High-level key holder
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class E2EKey:
    """Holder for a user's RSA keypair used in Pararam e2e.

    Use `E2EKey.from_jwk_string(s)` to load a private key exported by the
    web client, or `E2EKey.generate()` to mint a fresh keypair. Public-key
    serialization (for sharing with peers) is via `.public_key_str`.
    """

    private_key: rsa.RSAPrivateKey

    @classmethod
    def from_jwk_string(cls, s: str) -> E2EKey:
        """Load a private key from Pararam's `$`-delimited JWK string."""
        return cls(private_key=parse_rsa_private_key_str(s))

    @classmethod
    def generate(cls) -> E2EKey:
        """Generate a fresh RSA-2048 keypair (matches the web client)."""
        return cls(private_key=rsa.generate_private_key(public_exponent=65537, key_size=2048))

    @property
    def public_key(self) -> rsa.RSAPublicKey:
        return self.private_key.public_key()

    @property
    def public_key_str(self) -> str:
        """Public key in Pararam's `kty$e$alg$ext$n` form (for upload/share)."""
        return serialize_rsa_public_key(self.public_key)

    def unwrap_session_key(self, wrapped_b64: str) -> bytes:
        """RSA-OAEP-SHA256 decrypt a wrapped session key → raw AES bytes.

        Accepts the standard-base64 form (as produced by the web client's
        `btoa()` in the `<keys>` tail of an e2e post).
        """
        oaep = padding.OAEP(
            mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None
        )
        serialized = self.private_key.decrypt(b64_decode(wrapped_b64), oaep)
        return parse_aes_session_key(serialized.decode('utf-8'))

    @staticmethod
    def wrap_session_key(recipient_public_key: rsa.RSAPublicKey, session_key_bytes: bytes) -> str:
        """RSA-OAEP-SHA256 encrypt raw AES bytes under a recipient's public key.

        Returns standard-base64, matching the web client's wire format.
        """
        serialized = serialize_aes_session_key(session_key_bytes).encode('utf-8')
        oaep = padding.OAEP(
            mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None
        )
        wrapped = recipient_public_key.encrypt(serialized, oaep)
        return b64_encode(wrapped)

    @staticmethod
    def fresh_session_key() -> bytes:
        """Generate a cryptographically random 32-byte AES-256 key."""
        return secrets.token_bytes(32)

    def public_key_der(self) -> bytes:
        """Raw DER of the public key — utility for custom transport layers."""
        return self.public_key.public_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
