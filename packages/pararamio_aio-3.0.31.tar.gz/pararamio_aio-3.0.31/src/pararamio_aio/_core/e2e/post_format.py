"""Parse / build the `<e2e>...<keys>...` post-text frame.

Full format:

    <e2e>CT_B64$IV_B64<keys>USER_ID_1&WRAPPED_KEY_1$USER_ID_2&WRAPPED_KEY_2$...

The body (`CT_B64$IV_B64`) is passed to the AES-GCM session-key helpers
in `session.py`. The keys tail is a mapping from recipient user_id to the
RSA-OAEP-wrapped session key, one entry per recipient including the
author (so the author can decrypt their own posts later).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from .keys import E2EKey, parse_rsa_public_key_str
from .session import encrypt_text

if TYPE_CHECKING:
    from cryptography.hazmat.primitives.asymmetric import rsa

    RecipientPublicKey = rsa.RSAPublicKey | str

__all__ = [
    'E2E_MARKER',
    'KEYS_MARKER',
    'WrappedKey',
    'build_e2e_post_text',
    'encrypt_e2e_message',
    'is_e2e_post_text',
    'parse_e2e_post_text',
]


E2E_MARKER = '<e2e>'
KEYS_MARKER = '<keys>'


@dataclass(frozen=True, slots=True)
class WrappedKey:
    """A session key wrapped for a single recipient."""

    user_id: int
    wrapped_b64: str


def is_e2e_post_text(text: str) -> bool:
    """True if `text` begins with the `<e2e>` marker."""
    return text.startswith(E2E_MARKER)


def parse_e2e_post_text(text: str) -> tuple[str, list[WrappedKey]]:
    """Split the e2e post text into (body, [wrapped_keys]).

    Returns:
        `body` is the `CT_B64$IV_B64` portion — feed to `decrypt_text`
        with the unwrapped session key.
        `wrapped_keys` is the per-recipient list.

    Raises:
        ValueError: if the markers are missing or the keys block is malformed.
    """
    if not text.startswith(E2E_MARKER):
        raise ValueError(f'text does not start with {E2E_MARKER!r}')
    rest = text[len(E2E_MARKER) :]
    body, marker, keys_str = rest.partition(KEYS_MARKER)
    if not marker:
        raise ValueError(f'{KEYS_MARKER!r} not found in e2e post')
    keys: list[WrappedKey] = []
    # Empty keys_str is unusual but tolerated — means the post was encrypted
    # for nobody, which the client should never produce.
    for entry in filter(None, keys_str.split('$')):
        user_str, sep, wrapped = entry.partition('&')
        if not sep:
            raise ValueError(f'malformed key entry (missing &): {entry!r}')
        try:
            user_id = int(user_str)
        except ValueError as exc:
            raise ValueError(f'non-integer user_id in key entry: {user_str!r}') from exc
        keys.append(WrappedKey(user_id=user_id, wrapped_b64=wrapped))
    return body, keys


def build_e2e_post_text(body: str, wrapped_keys: list[WrappedKey]) -> str:
    """Assemble the full `<e2e>BODY<keys>USER&KEY$...` string."""
    if not wrapped_keys:
        raise ValueError('e2e post requires at least one wrapped recipient key')
    keys_tail = '$'.join(f'{k.user_id}&{k.wrapped_b64}' for k in wrapped_keys)
    return f'{E2E_MARKER}{body}{KEYS_MARKER}{keys_tail}'


def encrypt_e2e_message(
    plaintext: str,
    recipient_public_keys: dict[int, RecipientPublicKey],
) -> str:
    """Build the full `<e2e>...<keys>...` post text for a plaintext message.

    Generates a fresh AES-256-GCM session key, encrypts the plaintext, and
    wraps the session key once per recipient. The resulting string is the
    ready-to-post `text` value for a POST to `/msg/post/{chat_id}`.

    Args:
        plaintext: UTF-8 text to encrypt.
        recipient_public_keys: mapping of user_id → public key. The value
            may be a parsed `cryptography.hazmat.primitives.asymmetric.rsa.RSAPublicKey`
            object OR the flattened `kty$e$alg$ext$n` string form that the
            Pararam API returns for peer keys.

    Returns:
        The full `<e2e>CT$IV<keys>USER&KEY$...` post text.

    Raises:
        ValueError: if `recipient_public_keys` is empty.
    """
    if not recipient_public_keys:
        raise ValueError('encrypt_e2e_message requires at least one recipient')

    session_key = E2EKey.fresh_session_key()
    body = encrypt_text(session_key, plaintext)

    wrapped_list: list[WrappedKey] = []
    for user_id, key in recipient_public_keys.items():
        pub = parse_rsa_public_key_str(key) if isinstance(key, str) else key
        wrapped_list.append(
            WrappedKey(
                user_id=user_id,
                wrapped_b64=E2EKey.wrap_session_key(pub, session_key),
            )
        )
    return build_e2e_post_text(body, wrapped_list)
