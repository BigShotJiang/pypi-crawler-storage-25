"""Text formatters for "app message" posts (events, checklists).

The Pararam client renders these from structured markers embedded in a
post's `text`. We build the same markers on the library side so callers
don't have to know the wire format.

Observed formats (see packages/docs or reverse-engineering notes):

Event:
    #event
    [#l10nb](event.event): <NAME>
    [#l10nb](event.date): <ISO 8601 UTC, millisecond precision>
    [#l10nb](event.place): [#address](<PLACE>)        # optional
    [#l10nb](event.invited): @u1 @u2 @u3              # optional
    [#l10nb](event.description): <DESCRIPTION>        # optional

Checklist:
    #checklist  <-- NOTE: two spaces after the marker
    **<TITLE>**
    [ ](item 1)
    [ ](item 2)
    ...
"""

from __future__ import annotations

from collections.abc import Iterable
from datetime import UTC, datetime

__all__ = ['format_checklist_text', 'format_event_text', 'format_iso_millis_utc']


def format_iso_millis_utc(dt: datetime) -> str:
    """Format a tz-aware datetime as ISO 8601 UTC with millisecond precision.

    The client sends `2026-04-21T13:10:00.000Z` — millis, trailing Z.
    Naive datetimes are rejected — event time must be unambiguous.
    """
    if dt.tzinfo is None:
        raise ValueError(
            'event datetime must be timezone-aware; pass e.g. datetime(..., tzinfo=UTC)'
        )
    u = dt.astimezone(UTC)
    millis = u.microsecond // 1000
    base = u.strftime('%Y-%m-%dT%H:%M:%S')
    return f'{base}.{millis:03d}Z'


def format_event_text(
    name: str,
    date_time: datetime,
    *,
    description: str = '',
    place: str | None = None,
    invited_unique_names: Iterable[str] | None = None,
) -> str:
    """Build the `text` body for an event app-message.

    Args:
        name: Event name (rendered after "Event:" in the client).
        date_time: When the event starts (must be timezone-aware).
        description: Optional description body.
        place: Optional place/location (wrapped as `[#address](...)`).
        invited_unique_names: Optional iterable of user `unique_name`
            (without `@`). Each becomes `@<name>` in the rendered list.

    Returns:
        Multi-line string suitable for `POST /amsg/post/{chat_id}`.
    """
    lines = [
        '#event',
        f'[#l10nb](event.event): {name}',
        f'[#l10nb](event.date): {format_iso_millis_utc(date_time)}',
    ]
    if place:
        lines.append(f'[#l10nb](event.place): [#address]({place})')
    if invited_unique_names:
        mentions = ' '.join(f'@{name}' for name in invited_unique_names)
        lines.append(f'[#l10nb](event.invited): {mentions}')
    if description:
        lines.append(f'[#l10nb](event.description): {description}')
    return '\n'.join(lines)


def format_checklist_text(title: str, items: Iterable[str]) -> str:
    """Build the `text` body for a checklist app-message.

    Args:
        title: Checklist title (rendered bold).
        items: Iterable of item strings. Each becomes an unchecked entry.

    Returns:
        Multi-line string. Exact format: `#checklist  \\n**title**\\n[ ](item)\\n...`.
        The double-space after `#checklist` and the trailing newline are
        load-bearing — the client parser expects them.
    """
    item_list = list(items)
    parts = [f'#checklist  \n**{title}**']
    parts.extend(f'[ ]({item})' for item in item_list)
    return '\n'.join(parts) + '\n'
