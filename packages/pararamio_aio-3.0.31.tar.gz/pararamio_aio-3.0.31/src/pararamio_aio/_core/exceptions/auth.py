"""Authentication-specific exceptions."""

from __future__ import annotations

from .base import PararamioAuthenticationError

__all__ = (
    'CaptchaRequiredError',
    'InvalidCredentialsError',
    'RateLimitError',
    'SessionExpiredError',
    'StepUpFailedError',
    'StepUpRequiredError',
    'TwoFactorFailedError',
    'TwoFactorRequiredError',
    'XSRFTokenError',
)


class InvalidCredentialsError(PararamioAuthenticationError):
    """Invalid login credentials."""

    def __init__(self, message: str = 'Invalid email or password'):
        super().__init__(message, error_code='invalid_credentials')


class XSRFTokenError(PararamioAuthenticationError):
    """XSRF token related errors."""

    def __init__(self, message: str = 'XSRF token validation failed'):
        super().__init__(message, error_code='xsrf_token_error')


class TwoFactorRequiredError(PararamioAuthenticationError):
    """Two-factor authentication is required."""

    def __init__(self, message: str = 'Two-factor authentication required'):
        super().__init__(message, error_code='2fa_required')


class TwoFactorFailedError(PararamioAuthenticationError):
    """Two-factor authentication failed."""

    def __init__(self, message: str = 'Invalid two-factor authentication code'):
        super().__init__(message, error_code='2fa_failed')


class CaptchaRequiredError(PararamioAuthenticationError):
    """Captcha verification required."""

    def __init__(
        self,
        message: str = 'Captcha verification required',
        captcha_url: str | None = None,
    ):
        super().__init__(message, error_code='captcha_required')
        self.captcha_url = captcha_url


class RateLimitError(PararamioAuthenticationError):
    """Rate limit exceeded (429 Too Many Requests)."""

    def __init__(
        self,
        message: str = 'Rate limit exceeded',
        retry_after: int | None = None,
    ):
        super().__init__(message, error_code='rate_limit', retry_after=retry_after)


class SessionExpiredError(PararamioAuthenticationError):
    """Session has expired."""

    def __init__(self, message: str = 'Session has expired, please authenticate again'):
        super().__init__(message, error_code='session_expired')


class StepUpRequiredError(PararamioAuthenticationError):
    """Server requested two-step verification mid-session, but no TOTP key configured on client."""

    def __init__(
        self,
        message: str = (
            'Server requested two-step verification but no TOTP key is configured on the client'
        ),
    ):
        super().__init__(message, error_code='step_up_required')


class StepUpFailedError(PararamioAuthenticationError):
    """TOTP step-up POST /auth/totp returned a non-OK status."""

    def __init__(self, message: str = 'TOTP step-up verification failed'):
        super().__init__(message, error_code='step_up_failed')
