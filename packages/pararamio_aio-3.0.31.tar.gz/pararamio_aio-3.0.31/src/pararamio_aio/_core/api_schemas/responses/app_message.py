"""App-message + reminder API response schemas."""

from typing import TypedDict


class AppMessageCreateResponse(TypedDict):
    """Response from POST /amsg/post/{chat_id}."""

    uuid: str
    chat_id: int
    post_no: int


class RemindCreateResponse(TypedDict):
    """Response from POST /msg/remind."""

    remind_id: int


__all__ = ['AppMessageCreateResponse', 'RemindCreateResponse']
