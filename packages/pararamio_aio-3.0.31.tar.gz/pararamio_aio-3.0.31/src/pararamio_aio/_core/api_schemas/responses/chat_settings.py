"""Chat features + reaction API response schemas.

ChatFeatures — response of GET /core/chat/{chat_id}/settings. Writable toggles
(bot permissions, branches, deny flags) plus read-only structural fields
(branches list, parent_id, auto_delete_branch_without_post).

ReactionResponse — response of POST/GET /msg/post/{chat_id}/{post_no}/reaction.
"""

from typing import NotRequired, TypedDict


class ChatFeatures(TypedDict, total=False):
    """Chat feature toggles + branch structure.

    Writable: deny_all, allow_bot, allow_bot_read, allow_bot_manage_members,
    deny_groups, allow_branch.

    Read-only: branches, parent_id, auto_delete_branch_without_post.
    """

    # writable
    deny_all: bool
    allow_bot: bool
    allow_bot_read: bool
    allow_bot_manage_members: bool
    deny_groups: bool
    allow_branch: bool
    # read-only
    branches: list[int]
    parent_id: int | None
    auto_delete_branch_without_post: NotRequired[bool]


class ChatFeaturesResponse(TypedDict):
    """Wrapper the server returns around ChatFeatures."""

    settings: ChatFeatures


class ReactionTimeEntry(TypedDict):
    """Per-user reaction record returned by GET reactions."""

    user_id: int
    reaction: str
    time: str  # ISO timestamp


class ReactionResponse(TypedDict, total=False):
    """Response from POST /msg/post/{chat_id}/{post_no}/reaction (and GET)."""

    total: int
    count_reaction: dict[str, int]
    my_reaction: str | None
    time_reaction: list[ReactionTimeEntry]  # only present on GET


__all__ = [
    'ChatFeatures',
    'ChatFeaturesResponse',
    'ReactionResponse',
    'ReactionTimeEntry',
]
