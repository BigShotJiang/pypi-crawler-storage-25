"""API request schemas."""

from .app_message import AppMessageCreateRequest, RemindCreateRequest
from .chat import (
    ChatCreateBranchRequest,
    ChatCreateRequest,
    ChatUpdateFeaturesRequest,
    ChatUpdateSettingsRequest,
)
from .deferred_post import DeferredPostCreateRequest
from .group import GroupEditRequest
from .post import MarkReadRequest, PostCreateRequest, PostSendMessageRequest

__all__ = [
    'AppMessageCreateRequest',
    'ChatCreateBranchRequest',
    'ChatCreateRequest',
    'ChatUpdateFeaturesRequest',
    'ChatUpdateSettingsRequest',
    'DeferredPostCreateRequest',
    'GroupEditRequest',
    'MarkReadRequest',
    'PostCreateRequest',
    'PostSendMessageRequest',
    'RemindCreateRequest',
]
