"""App-message + reminder API request schemas."""

from typing import NotRequired, TypedDict


class AppMessageCreateRequest(TypedDict):
    """Body for POST /amsg/post/{chat_id}.

    The `text` is a structured payload the client renders into a card
    (event, checklist, or other "app message"). The server stores it as a
    regular Post but clients recognise the leading marker (`#event`,
    `#checklist`, etc.) and render accordingly.
    """

    text: str
    uuid: NotRequired[str]


class RemindCreateRequest(TypedDict):
    """Body for POST /msg/remind.

    Attaches a reminder to an existing post. The reminder fires at
    `remind_time` (ISO 8601 with timezone) and — per observed UI — may
    surface as a system message in the chat.
    """

    author_id: int  # 0 for the current user, non-zero to attribute to someone else
    text: str  # can be empty string
    post_no: int
    chat_id: int
    remind_time: str  # ISO 8601 with timezone


__all__ = ['AppMessageCreateRequest', 'RemindCreateRequest']
