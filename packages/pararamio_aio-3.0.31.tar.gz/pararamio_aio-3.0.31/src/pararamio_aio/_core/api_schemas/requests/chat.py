"""Chat API request schemas."""

from typing import NotRequired, TypedDict


class ChatCreateRequest(TypedDict):
    """Schema for chat creation request.

    Note: the UI "Channel" checkbox maps to `read_only` — when true, only
    admins can post. There is no separate `channel` field in the API.
    """

    title: str
    description: NotRequired[str]
    organization_id: NotRequired[int | None]
    posts_live_time: NotRequired[int | None]  # seconds
    two_step_required: NotRequired[bool]
    history_mode: NotRequired[str]  # 'all' | 'since_join'
    org_visible: NotRequired[bool]
    allow_api: NotRequired[bool]  # deprecated
    read_only: NotRequired[bool]  # UI "Channel" flag maps here
    mode_read_only: NotRequired[bool]
    users: NotRequired[list[int]]  # For bots only
    groups: NotRequired[list[int]]  # For bots only


class ChatUpdateSettingsRequest(TypedDict):
    """Request body for PUT /core/chat/{chat_id}.

    Basic chat-level fields: title, description, history settings,
    2-step requirement, team visibility, read-only mode ("Channel" in the UI).

    For feature toggles (bots, branches, role restrictions) use
    ChatUpdateFeaturesRequest + Chat.update_features() instead.
    """

    title: NotRequired[str]
    description: NotRequired[str]
    posts_live_time: NotRequired[int | None]  # seconds
    two_step_required: NotRequired[bool]
    history_mode: NotRequired[str]  # 'all' | 'since_join', default='all'
    org_visible: NotRequired[bool]
    allow_api: NotRequired[bool]  # default=True
    read_only: NotRequired[bool]  # UI "Channel" flag maps here


class ChatUpdateFeaturesRequest(TypedDict):
    """Request body for POST /core/chat/{chat_id}/settings.

    Feature toggles for a chat — bot permissions, branch creation, and
    role/mention restrictions. All fields are admin-only.
    """

    deny_all: NotRequired[bool]
    allow_bot: NotRequired[bool]
    allow_bot_read: NotRequired[bool]
    allow_bot_manage_members: NotRequired[bool]
    deny_groups: NotRequired[bool]
    allow_branch: NotRequired[bool]


class ChatCreateBranchRequest(TypedDict):
    """Request body for POST /core/chat/branch/{parent_chat_id}."""

    post_no: int
    title: NotRequired[str]


__all__ = [
    'ChatCreateBranchRequest',
    'ChatCreateRequest',
    'ChatUpdateFeaturesRequest',
    'ChatUpdateSettingsRequest',
]
