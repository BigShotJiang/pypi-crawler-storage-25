"""Core Activity model without lazy loading."""

from __future__ import annotations

import datetime as dt
from enum import Enum
from typing import TYPE_CHECKING, Any, ClassVar, Self, Unpack
from urllib.parse import urlencode

from pararamio_aio._core.api_schemas.responses import ActivityResponse
from pararamio_aio._core.utils.helpers import parse_iso_datetime

from .base import CoreBaseModel

if TYPE_CHECKING:
    from collections.abc import Iterator

    from pararamio_aio._core._types import FormatterT

__all__ = (
    'ACTIVITY_MAX_PERIOD',
    'Activity',
    'ActivityAction',
    'CoreActivity',
    'build_activity_url',
    'iter_activity_windows',
)


# Server-side limit on the period covered by a single /activity request.
ACTIVITY_MAX_PERIOD = dt.timedelta(days=14)


# Attribute formatters for Activity
ACTIVITY_ATTR_FORMATTERS: FormatterT = {
    'datetime': parse_iso_datetime,
}


class ActivityAction(Enum):
    """Activity action types."""

    ONLINE = 'online'
    OFFLINE = 'offline'
    AWAY = 'away'
    READ = 'thread-read'
    POST = 'thread-post'
    CALL = 'calling'
    CALL_END = 'endcall'


class Activity:
    """User activity record."""

    action: ActivityAction
    time: dt.datetime

    def __init__(self, action: ActivityAction, time: dt.datetime) -> None:
        """Initialize activity.

        Args:
            action: Activity action type
            time: Activity timestamp
        """
        self.action = action
        self.time = time

    def __str__(self) -> str:
        """String representation."""
        return f'Activity({self.time}, {self.action.value})'

    def __repr__(self) -> str:
        """Detailed representation."""
        return f'<Activity(action={self.action}, time={self.time})>'

    def __eq__(self, other: object) -> bool:
        """Check equality."""
        if not isinstance(other, Activity):
            return False
        return self.action == other.action and self.time == other.time

    @classmethod
    def from_api_data(cls, data: dict[str, str]) -> Self:
        """Create Activity from API response data.

        Args:
            data: API response data

        Returns:
            Activity instance

        Raises:
            ValueError: If the time format is invalid
        """
        time = parse_iso_datetime(data, 'datetime')
        if time is None:
            raise ValueError('Invalid time format')

        return cls(
            action=ActivityAction(data['action']),
            time=time,
        )


class CoreActivity(CoreBaseModel[ActivityResponse]):
    """Core Activity model with common functionality."""

    _data: ActivityResponse
    # Activity attributes
    action: str
    datetime: dt.datetime

    _attr_formatters: ClassVar[FormatterT] = ACTIVITY_ATTR_FORMATTERS

    def __init__(self, client: Any, **kwargs: Unpack[ActivityResponse]) -> None:  # noqa: ARG002
        """Initialize the activity model with data.

        Args:
            client: Client instance (Pararamio or AsyncPararamio)
            **kwargs: Activity data
        """
        self._data = kwargs

    def __str__(self) -> str:
        return self.action

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, CoreActivity):
            return id(other) == id(self)
        return self.action == other.action and self.datetime == other.datetime


def build_activity_url(
    user_id: int,
    start: dt.datetime,
    end: dt.datetime,
    actions: list[ActivityAction] | None = None,
) -> str:
    """Build a /activity URL for the given user and time window.

    The server expects ISO-8601 ``start``/``end`` (date or datetime, optionally
    with seconds) and a comma-separated ``action`` list. Both bounds are required.
    """
    params: list[tuple[str, str]] = [
        ('user_id', str(user_id)),
        ('start', start.isoformat()),
        ('end', end.isoformat()),
    ]
    if actions:
        params.append(('action', ','.join(a.value for a in actions)))
    return f'/activity?{urlencode(params)}'


def iter_activity_windows(
    start: dt.datetime, end: dt.datetime
) -> Iterator[tuple[dt.datetime, dt.datetime]]:
    """Yield (window_start, window_end) pairs covering [start, end].

    Each window is at most ``ACTIVITY_MAX_PERIOD`` long, matching the server-side
    limit on a single /activity request.
    """
    if end < start:
        return
    current = start
    while current < end:
        window_end = min(current + ACTIVITY_MAX_PERIOD, end)
        yield current, window_end
        if window_end == end:
            return
        current = window_end
