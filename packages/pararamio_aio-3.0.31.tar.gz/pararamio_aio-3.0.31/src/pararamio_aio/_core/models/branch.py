"""Branch model: a parent-chat → child-chat forking relationship.

A Branch wraps the child Chat (use `branch.chat` for messaging and all Chat
operations) and carries the forking metadata (parent chat id and, when
known, the parent post number the branch was forked from).

The server does not preserve the parent post id: it's set when the Branch
comes back from `Chat.create_branch()`, and is None when the Branch is
reconstructed via `Chat.get_branches()` (which only has the child chat IDs
from `ChatFeatures.branches`).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Generic, TypeVar

if TYPE_CHECKING:
    from .chat import CoreChat

ChatT_co = TypeVar('ChatT_co', bound='CoreChat', covariant=True)  # type: ignore[type-arg]


@dataclass(frozen=True)
class CoreBranch(Generic[ChatT_co]):
    """A forking relationship between a parent chat and a child chat.

    Attributes:
        chat: The child Chat. Use this for messaging, editing, member mgmt,
            and anything else that operates on a chat.
        parent_chat_id: ID of the chat this branch was forked from.
        parent_post_no: Post number the branch was forked from in the parent
            chat. Only populated when the Branch was just created via
            `create_branch()`; None when loaded via `get_branches()`.
    """

    chat: ChatT_co
    parent_chat_id: int
    parent_post_no: int | None = None


__all__ = ['CoreBranch']
