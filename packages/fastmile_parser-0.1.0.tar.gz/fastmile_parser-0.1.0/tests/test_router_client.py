import requests

from fastmile_parser.router_client import RouterClient


def test_fetch_status_html_uses_https_and_verify_false(monkeypatch):
    calls = {}

    class Response:
        status_code = 200
        text = "<html>ok</html>"

        def raise_for_status(self):
            return None

    def fake_get(url, timeout, verify):
        calls["url"] = url
        calls["timeout"] = timeout
        calls["verify"] = verify
        return Response()

    monkeypatch.setattr(requests, "get", fake_get)

    client = RouterClient("192.168.0.1", timeout=30)
    assert client.fetch_status_html() == "<html>ok</html>"
    assert calls == {"url": "https://192.168.0.1/status.php", "timeout": 30, "verify": False}
