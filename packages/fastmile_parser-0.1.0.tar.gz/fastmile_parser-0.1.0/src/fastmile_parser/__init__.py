"""FastMile parser package."""
