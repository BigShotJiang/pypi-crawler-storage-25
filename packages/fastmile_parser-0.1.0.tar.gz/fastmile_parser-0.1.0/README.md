# fastmile-parser

Shared Nokia FastMile parser package.

## What it does

- fetches `https://<router>/status.php`
- parses the status page into typed snapshot models
- preserves the exact field set used by `fastmile-api`

## Usage

```python
from fastmile_parser.router_client import RouterClient
from fastmile_parser.scraper import parse_snapshot

html = RouterClient("192.168.0.1").fetch_status_html()
snapshot = parse_snapshot(html)
```
