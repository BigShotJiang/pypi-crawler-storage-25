# vaultd CLI entry points
