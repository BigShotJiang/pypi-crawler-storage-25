"""Public KyronthaLogger — direct, framework-free usage."""

from __future__ import annotations

import os
import time
import uuid
from typing import Any, Callable, Dict, Literal, Optional

from ._batcher import Batcher

LogLevel = Literal["fatal", "error", "warn", "info", "debug"]
_DEFAULT_ENDPOINT = "https://lens.kyrontha.io/api/ingest"


def _default_on_error(err: Exception) -> None:
    # Print to stderr via standard channels — match Python convention without
    # forcing a stdlib `logging` dependency on the user's app.
    import sys
    print(f"[kyrontha-lens] {err}", file=sys.stderr)


class KyronthaLogger:
    """Buffered, async log shipper for Kyrontha Lens.

    Example::

        from kyrontha_lens import KyronthaLogger

        log = KyronthaLogger(api_key=os.environ["KYRONTHA_KEY"], source="checkout-api")
        log.info("order placed", order_id=42, user_id="u-123")
        log.error("payment failed", order_id=42, reason="declined")

    On graceful shutdown the SDK drains the buffer once via atexit + SIGTERM
    handlers. For short-lived scripts call ``log.flush()`` (or ``log.close()``)
    explicitly so the in-flight POST has time to complete.
    """

    def __init__(
        self,
        api_key: str,
        *,
        endpoint: Optional[str] = None,
        source: Optional[str] = None,
        flush_interval_s: float = 5.0,
        flush_batch_size: int = 50,
        max_retries: int = 3,
        on_error: Optional[Callable[[Exception], None]] = None,
    ) -> None:
        if not api_key:
            raise ValueError("KyronthaLogger: api_key is required")
        self._source = source or os.environ.get("KYRONTHA_SOURCE") or "app"
        self._batcher = Batcher(
            endpoint=endpoint or _DEFAULT_ENDPOINT,
            api_key=api_key,
            flush_interval_s=flush_interval_s,
            flush_batch_size=flush_batch_size,
            max_retries=max_retries,
            on_error=on_error or _default_on_error,
        )

    # ── Public log methods ────────────────────────────────────────────────────
    def log(self, level: str, message: str, **meta: Any) -> None:
        # Use kwargs for structured fields (Pythonic). Internal source
        # override is supported via a `source=` kwarg.
        src = meta.pop("source", None) or self._source
        event: Dict[str, Any] = {
            "id":        str(uuid.uuid4()),
            "timestamp": int(time.time() * 1000),
            "level":     str(level).lower(),
            "source":    src,
            "message":   message,
        }
        if meta:
            # Send as raw JSON so the server-side attribute extractor can
            # pull allowlisted keys (request_id, status_code, ...) into
            # the queryable `attributes.*` fields.
            import json
            event["raw"] = json.dumps(meta, default=str)
        self._batcher.enqueue(event)

    def fatal(self, message: str, **meta: Any) -> None: self.log("fatal", message, **meta)
    def error(self, message: str, **meta: Any) -> None: self.log("error", message, **meta)
    def warn (self, message: str, **meta: Any) -> None: self.log("warn",  message, **meta)
    def info (self, message: str, **meta: Any) -> None: self.log("info",  message, **meta)
    def debug(self, message: str, **meta: Any) -> None: self.log("debug", message, **meta)

    # ── Drain hooks ───────────────────────────────────────────────────────────
    def flush(self, timeout: float = 10.0) -> None:
        """Force-flush. Useful before short-lived scripts exit."""
        self._batcher.flush(timeout=timeout)

    def close(self, timeout: float = 10.0) -> None:
        """Stop the background worker and drain. Idempotent."""
        self._batcher.close(timeout=timeout)
