"""Stdlib ``logging.Handler`` adapter — also unlocks structlog (via
``wrap_for_formatter`` / standard-library bridge) and Loguru (via
``logger.add(handler)``)."""

from __future__ import annotations

import logging
from typing import Any, Callable, Optional

from .logger import KyronthaLogger

# Stdlib log level (int) -> our level name
_LEVEL_NAME = {
    logging.DEBUG:    "debug",
    logging.INFO:     "info",
    logging.WARNING:  "warn",
    logging.ERROR:    "error",
    logging.CRITICAL: "fatal",
}

# Standard LogRecord attributes that we DON'T want to ship as user `meta`.
_STDLIB_RESERVED = frozenset({
    "name", "msg", "args", "levelname", "levelno", "pathname", "filename",
    "module", "exc_info", "exc_text", "stack_info", "lineno", "funcName",
    "created", "msecs", "relativeCreated", "thread", "threadName",
    "processName", "process", "getMessage", "message",
    # Bridge / framework noise
    "taskName", "asctime",
})


class KyronthaHandler(logging.Handler):
    """Drop-in ``logging.Handler`` that ships records to Kyrontha Lens.

    Works with:
      * stdlib ``logging`` directly
      * ``structlog`` configured to render via stdlib (the standard pattern)
      * ``loguru`` via ``logger.add(KyronthaHandler(api_key=...))``

    Example::

        import logging
        from kyrontha_lens import KyronthaHandler

        logging.basicConfig(level=logging.INFO, handlers=[
            logging.StreamHandler(),
            KyronthaHandler(api_key=os.environ["KYRONTHA_KEY"], source="checkout-api"),
        ])
        log = logging.getLogger(__name__)
        log.info("order placed", extra={"order_id": 42})
    """

    def __init__(
        self,
        api_key: str,
        *,
        endpoint: Optional[str] = None,
        source: Optional[str] = None,
        flush_interval_s: float = 5.0,
        flush_batch_size: int = 50,
        max_retries: int = 3,
        on_error: Optional[Callable[[Exception], None]] = None,
        level: int = logging.NOTSET,
    ) -> None:
        super().__init__(level=level)
        self._logger = KyronthaLogger(
            api_key=api_key,
            endpoint=endpoint,
            source=source,
            flush_interval_s=flush_interval_s,
            flush_batch_size=flush_batch_size,
            max_retries=max_retries,
            on_error=on_error,
        )

    def emit(self, record: logging.LogRecord) -> None:
        # `extra={...}` fields end up as attributes on the record. Pull
        # everything that isn't a stdlib-reserved attribute so we forward
        # the user's structured fields as meta.
        try:
            meta = {
                k: v for k, v in record.__dict__.items()
                if k not in _STDLIB_RESERVED and not k.startswith("_")
            }
            level_name = _LEVEL_NAME.get(record.levelno, "info")
            self._logger.log(level_name, record.getMessage(), **meta)
        except Exception:                                  # noqa: BLE001
            self.handleError(record)

    # Allow callers to drain the buffer when the host logging system is
    # shutting down (e.g. ``logging.shutdown()`` calls ``handler.close()``).
    def flush(self) -> None:
        self._logger.flush()

    def close(self) -> None:
        try:
            self._logger.close()
        finally:
            super().close()
