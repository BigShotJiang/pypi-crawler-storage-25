"""Buffered async sender used by KyronthaLogger.

Design goals (mirrors the Node SDK):
  * Never block the calling code. Logging is fire-and-forget.
  * Never crash the host app. A Lens outage drops events after retry.
  * Drain on graceful shutdown so the last few seconds of logs aren't
    lost on container restart / SIGTERM.

A daemon thread owns the buffer + flush loop. Calls to ``enqueue`` are
synchronous and only acquire a brief lock on the buffer.
"""

from __future__ import annotations

import atexit
import json
import logging
import signal
import threading
import time
from typing import Any, Callable, Dict, List
from urllib import error as urlerror, request as urlrequest

_log = logging.getLogger("kyrontha_lens")


class Batcher:
    def __init__(
        self,
        endpoint: str,
        api_key: str,
        flush_interval_s: float,
        flush_batch_size: int,
        max_retries: int,
        on_error: Callable[[Exception], None],
    ) -> None:
        self._endpoint = endpoint
        self._api_key = api_key
        self._flush_interval_s = flush_interval_s
        self._flush_batch_size = flush_batch_size
        self._max_retries = max_retries
        self._on_error = on_error

        self._buffer: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
        # Set whenever a manual flush is requested OR shutdown is in progress —
        # wakes the worker out of its interval sleep so it drains immediately.
        self._wake = threading.Event()
        self._closed = False

        self._worker = threading.Thread(
            target=self._run, name="kyrontha-lens-batcher", daemon=True
        )
        self._worker.start()
        self._install_shutdown_handlers()

    # ── Public ────────────────────────────────────────────────────────────────
    def enqueue(self, event: Dict[str, Any]) -> None:
        if self._closed:
            return
        with self._lock:
            self._buffer.append(event)
            if len(self._buffer) >= self._flush_batch_size:
                self._wake.set()

    def flush(self, timeout: float = 10.0) -> None:
        """Force a flush and block until it completes (or `timeout` seconds)."""
        # Snapshot the current pending count so we know when "done" means done.
        with self._lock:
            had = len(self._buffer)
        if had == 0 and not self._wake.is_set():
            return
        # Wake the worker, then wait for the buffer to drain.
        self._wake.set()
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            with self._lock:
                if not self._buffer:
                    return
            time.sleep(0.05)

    def close(self, timeout: float = 10.0) -> None:
        """Stop the worker and drain. Safe to call multiple times."""
        if self._closed:
            return
        self._closed = True
        self._wake.set()
        self._worker.join(timeout=timeout)

    # ── Worker loop ───────────────────────────────────────────────────────────
    def _run(self) -> None:
        while True:
            # Sleep up to flush_interval_s, woken early on close/manual flush.
            self._wake.wait(timeout=self._flush_interval_s)
            self._wake.clear()
            self._drain_once()
            if self._closed:
                # One final pass after the close signal in case anything was
                # enqueued between the wait() and now.
                self._drain_once()
                return

    def _drain_once(self) -> None:
        with self._lock:
            if not self._buffer:
                return
            batch = self._buffer
            self._buffer = []
        self._send(batch)

    def _send(self, batch: List[Dict[str, Any]]) -> None:
        body = json.dumps(batch).encode("utf-8")
        attempt = 0
        while attempt <= self._max_retries:
            try:
                req = urlrequest.Request(
                    self._endpoint,
                    data=body,
                    method="POST",
                    headers={
                        "Content-Type": "application/json",
                        "x-api-key":    self._api_key,
                    },
                )
                with urlrequest.urlopen(req, timeout=10) as resp:
                    if 200 <= resp.status < 300:
                        return
                    # 4xx: permanent. Drop and surface via on_error.
                    if 400 <= resp.status < 500:
                        body_text = resp.read().decode("utf-8", "replace")[:200]
                        self._on_error(RuntimeError(
                            f"Kyrontha Lens rejected {len(batch)} events: "
                            f"HTTP {resp.status} {body_text}"
                        ))
                        return
                    raise RuntimeError(f"HTTP {resp.status}")
            except urlerror.HTTPError as e:
                # urllib raises HTTPError for non-2xx — surface 4xx as permanent.
                if 400 <= e.code < 500:
                    self._on_error(RuntimeError(
                        f"Kyrontha Lens rejected {len(batch)} events: HTTP {e.code}"
                    ))
                    return
                attempt += 1
                if attempt > self._max_retries:
                    self._on_error(RuntimeError(
                        f"Kyrontha Lens dropped {len(batch)} events after "
                        f"{self._max_retries} retries: {e}"
                    ))
                    return
                time.sleep(0.25 * (2 ** (attempt - 1)))
            except Exception as e:  # noqa: BLE001
                attempt += 1
                if attempt > self._max_retries:
                    self._on_error(RuntimeError(
                        f"Kyrontha Lens dropped {len(batch)} events after "
                        f"{self._max_retries} retries: {e}"
                    ))
                    return
                time.sleep(0.25 * (2 ** (attempt - 1)))

    # ── Shutdown hooks ────────────────────────────────────────────────────────
    def _install_shutdown_handlers(self) -> None:
        atexit.register(lambda: self.close(timeout=5))
        # signal handlers can only be installed in the main thread; ignore
        # silently if we're not (e.g., inside a worker process).
        try:
            for sig in (signal.SIGTERM, signal.SIGINT):
                prev = signal.getsignal(sig)
                def _handler(signum, frame, _prev=prev):  # noqa: ANN001
                    self.close(timeout=5)
                    if callable(_prev):
                        _prev(signum, frame)
                signal.signal(sig, _handler)
        except (ValueError, OSError):
            pass
