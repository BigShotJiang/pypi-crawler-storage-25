#!/usr/bin/env bash
# Publish kyrontha-lens to PyPI.
#
# Local use:
#   cd sdk/python
#   TWINE_USERNAME=__token__ TWINE_PASSWORD=pypi-... bash publish.sh
#
# CI use:
#   The same env vars are set as secret pipeline variables in
#   deploy/sdk-publish-pipeline.yml (TWINE_USERNAME is hardcoded to
#   "__token__"; TWINE_PASSWORD is the secret API token).
#
# Prerequisites (one-time):
#   python3 -m pip install --user --upgrade build twine
#   Reserve the `kyrontha-lens` name on https://pypi.org/manage/projects/
#   Generate an API token scoped to the project from your account settings.
#
# We invoke build + twine via `python3 -m` rather than the bare `build` /
# `twine` commands so they work whether or not user-pip's bin directory
# (~/.local/bin) is on PATH. Pipeline steps in Azure DevOps each run in a
# fresh shell so PATH adjustments don't carry over.
set -euo pipefail

cd "$(dirname "$0")"

# Pick whichever python3 is on PATH. `python` is python2 on many distros;
# don't trust it.
PY=python3
if ! command -v "$PY" >/dev/null 2>&1; then
  echo "ERROR: python3 not found. Install via your package manager (apt/yum/brew)."
  exit 1
fi

# Clean prior builds so we don't accidentally upload a stale wheel.
rm -rf dist/ build/ *.egg-info

echo "── Building sdist + wheel ──"
"$PY" -m build

echo "── Uploading to PyPI ──"
# --skip-existing means re-running for a version that's already on PyPI
# is a no-op rather than a hard error. Helpful for CI retries.
"$PY" -m twine upload --skip-existing --non-interactive dist/*

echo "── Done. Verify at https://pypi.org/project/kyrontha-lens/ ──"
