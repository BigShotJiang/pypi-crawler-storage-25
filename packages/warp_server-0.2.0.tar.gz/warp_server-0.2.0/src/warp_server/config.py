from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    database_url: str = "sqlite+aiosqlite:///./warp.db"
    secret_key: str = "change-me-in-production"
    host: str = "127.0.0.1"
    port: int = 8000
    log_level: str = "info"
    cors_origins: list[str] = []
    max_login_attempts: int = 5
    reload: bool = False

    model_config = {"env_prefix": "WARP_"}


settings = Settings()
