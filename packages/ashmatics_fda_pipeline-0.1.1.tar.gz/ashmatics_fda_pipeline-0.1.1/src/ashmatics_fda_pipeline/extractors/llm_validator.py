# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
LLM-based validation for FDA 510(k) metadata extraction.

Uses LLM as a "judge" to validate and correct regex extraction results.
More token-efficient than pure LLM extraction while handling edge cases.
"""

import json
from typing import Dict, Optional, Tuple

from ashmatics_tools import BaseLLMClient, LLMMessage, create_llm_client


class LLMMetadataValidator:
    """
    LLM-based validator for extracted metadata.

    Uses "LLM as judge" pattern: validates regex results rather than
    extracting from scratch, saving tokens and improving consistency.
    """

    def __init__(
        self,
        llm_client: Optional[BaseLLMClient] = None,
        provider: str = "azure-openai"
    ):
        """
        Initialize validator.

        Args:
            llm_client: Optional pre-configured LLM client
            provider: LLM provider if creating new client
        """
        self.llm_client = llm_client or create_llm_client(provider)

    async def validate_metadata(
        self, header_text: str, regex_results: Dict
    ) -> Tuple[Dict, Dict]:
        """
        Validate and correct extracted metadata using LLM.

        Args:
            header_text: Raw header section text
            regex_results: Results from regex extraction

        Returns:
            Tuple of (validated_metadata, audit_dict)
        """
        # Construct validation prompt
        prompt = self._build_validation_prompt(header_text, regex_results)

        messages = [
            LLMMessage(role="system", content=self._get_validation_system_prompt()),
            LLMMessage(role="user", content=prompt),
        ]

        # Call LLM with structured output inside async context manager
        try:
            async with self.llm_client as client:
                response = await client.complete_with_messages(
                    messages=messages,
                    temperature=0.0,  # Deterministic
                    response_format={"type": "json_object"},  # Structured JSON output
                )

                # Parse LLM response
                llm_output = json.loads(response.text)

                # Build audit trail
                audit = {
                    'corrections': llm_output.get('corrections', {}),
                    'confidence': llm_output.get('confidence_score'),
                    'issues_found': llm_output.get('issues', []),
                    'llm_notes': llm_output.get('notes'),
                    'tokens_used': {
                        'prompt': response.tokens.prompt_tokens,
                        'completion': response.tokens.completion_tokens,
                        'total': response.tokens.total_tokens,
                    },
                    'model': response.model,
                }

        except json.JSONDecodeError:
            # Fallback if JSON parsing fails
            llm_output = {
                'corrections': {},
                'issues': ['Failed to parse LLM JSON response'],
                'confidence_score': 50,
                'notes': 'JSON parse error, using regex results as-is'
            }
            audit = {
                'corrections': {},
                'confidence': 50,
                'issues_found': ['JSON parse error'],
                'llm_notes': 'Failed to parse LLM response',
                'tokens_used': {'prompt': 0, 'completion': 0, 'total': 0},
                'model': 'unknown',
            }
        except Exception as e:
            # Fallback for any other errors
            llm_output = {
                'corrections': {},
                'issues': [f'LLM validation error: {str(e)}'],
                'confidence_score': 50,
                'notes': f'Error during validation: {str(e)}'
            }
            audit = {
                'corrections': {},
                'confidence': 50,
                'issues_found': [str(e)],
                'llm_notes': f'Validation error: {str(e)}',
                'tokens_used': {'prompt': 0, 'completion': 0, 'total': 0},
                'model': 'unknown',
            }

        # Apply corrections to regex results
        validated = self._apply_corrections(regex_results, llm_output.get('corrections', {}))

        return validated, audit

    def _get_validation_system_prompt(self) -> str:
        """System prompt for LLM validator."""
        return """You are a metadata validation assistant for FDA 510(k) regulatory documents.

Your task: Validate and correct extracted metadata fields from the document header.

Instructions:
1. Compare the extracted values against the source text
2. Identify any extraction errors (wrong values, missing data, formatting issues)
3. Correct errors with accurate values from the source text
4. For manufacturer names: extract the COMPANY NAME ONLY (before '℅', excluding contact person)
5. Preserve correct extractions (don't change if already accurate)
6. Return confidence score (0-100) for overall extraction quality

Critical fields to validate:
- k_number: Must match format K######
- manufacturer: Company name only, no contact person
- trade_name: Full device/trade name
- regulation_number: Format "21 CFR X.Y"
- regulatory_class: Format "Class I", "Class II", or "Class III"
- product_codes: May be comma-separated list
- dates: In ISO format YYYY-MM-DD

Return JSON format:
{
  "corrections": {
    "field_name": "corrected_value",  // Only include fields that need correction
    // Use null value to mark field as missing/should be removed
  },
  "issues": [
    "Description of issue 1",
    "Description of issue 2"
  ],
  "confidence_score": 85,  // 0-100
  "notes": "Any additional observations"
}

Be conservative: Only suggest corrections when clearly needed based on source text."""

    def _build_validation_prompt(self, header_text: str, regex_results: Dict) -> str:
        """Build validation prompt for LLM."""

        # Create clean copy without internal fields
        display_results = {
            k: v
            for k, v in regex_results.items()
            if not k.startswith('_') and k not in ['parsed_doc_info']
        }

        # Format for display
        extracted_fields = json.dumps(display_results, indent=2)

        prompt = f"""Please validate the following metadata extraction from this FDA 510(k) document header.

SOURCE TEXT:
```
{header_text}
```

EXTRACTED METADATA (by regex):
```json
{extracted_fields}
```

Review each field and identify any extraction errors. Pay special attention to:
- manufacturer: Should be company name only (before ℅ symbol, excluding contact person name)
- k_number: Must match pattern K######
- product_codes: May be comma-separated list
- dates: Should be in ISO format YYYY-MM-DD

Return corrections only for fields with errors."""

        return prompt

    def _apply_corrections(self, original: Dict, corrections: Dict) -> Dict:
        """
        Apply LLM corrections to original metadata.

        Args:
            original: Original regex results
            corrections: LLM-suggested corrections

        Returns:
            Corrected metadata dictionary
        """
        validated = original.copy()

        for field, corrected_value in corrections.items():
            if corrected_value is None:
                # LLM suggests removing field
                validated.pop(field, None)
            else:
                # Apply correction
                validated[field] = corrected_value

        return validated
