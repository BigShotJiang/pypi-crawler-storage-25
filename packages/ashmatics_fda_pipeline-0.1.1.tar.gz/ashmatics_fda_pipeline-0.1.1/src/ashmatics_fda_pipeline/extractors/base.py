# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Base classes for extensible document metadata extraction.

Provides abstract base class pattern for document-type-specific extractors
while sharing common utilities for section normalization, content extraction,
and multi-source metadata assembly.
"""

import re
from abc import ABC, abstractmethod
from typing import Dict, List, Optional

from ashmatics_tools import ParsedDocument


class DocumentExtractor(ABC):
    """
    Abstract base class for document-type-specific metadata extraction.

    Subclasses implement document-specific extraction logic while
    inheriting common utilities for section normalization, table
    classification, and multi-source extraction.

    This pattern enables extension to multiple document types:
    - FDA 510(k) regulatory documents
    - Peer-reviewed research papers
    - Clinical guidelines
    - AI/ML model cards

    Each document type has different section schemas but shares
    the same extraction patterns.
    """

    def __init__(self, section_config: Dict[str, List[str]]):
        """
        Initialize extractor with section normalization configuration.

        Args:
            section_config: Section normalization mapping.
                Key = canonical section name (e.g., 'abstract', 'methods')
                Value = list of variant titles to match against

                Example for FDA 510(k):
                {
                    'indications_for_use': [
                        'indications for use',
                        'indications',
                        'intended use'
                    ],
                    'device_description': [
                        'device description',
                        'description of device'
                    ]
                }

                Example for research papers:
                {
                    'abstract': ['abstract', 'summary'],
                    'methods': ['methods', 'methodology', 'materials and methods']
                }
        """
        self.section_config = section_config

    @abstractmethod
    def extract_metadata(self, parsed_doc: ParsedDocument) -> Dict:
        """
        Extract document-type-specific metadata.

        Subclasses implement custom extraction logic for their document type.
        For example:
        - FDA510kExtractor: Extracts K-number, device name, manufacturer, etc.
        - ResearchPaperExtractor: Extracts authors, journal, DOI, etc.

        Args:
            parsed_doc: Parsed document from DocLing/GROBID parser

        Returns:
            Dictionary with extracted metadata fields
        """
        pass

    @abstractmethod
    def get_required_sections(self) -> List[str]:
        """
        Return list of required section IDs for this document type.

        Used for validation - documents missing required sections
        should trigger warnings.

        Example for FDA 510(k):
            ['indications_for_use', 'device_description', 'predicate_devices']

        Example for research papers:
            ['abstract', 'methods', 'results']

        Returns:
            List of canonical section names that must be present
        """
        pass

    # =========================================================================
    # Shared Utility Methods (inherited by all subclasses)
    # =========================================================================

    def normalize_section_title(self, title: str) -> Optional[str]:
        """
        Normalize section title to canonical name using configuration.

        Performs fuzzy matching to handle title variations:
        - Case-insensitive matching
        - Substring matching (e.g., "Methods" matches "Materials and Methods")

        Args:
            title: Raw section title from parsed document

        Returns:
            Canonical section name if matched, None otherwise

        Example:
            >>> extractor.normalize_section_title("Indications")
            'indications_for_use'
            >>> extractor.normalize_section_title("Performance Data")
            'performance_testing'
        """
        title_lower = title.lower().strip()

        for canonical, variants in self.section_config.items():
            # Exact match
            if title_lower in [v.lower() for v in variants]:
                return canonical

            # Fuzzy matching - check if variant appears in title or vice versa
            for variant in variants:
                variant_lower = variant.lower()
                if variant_lower in title_lower or title_lower in variant_lower:
                    return canonical

        return None

    def extract_section_content(
        self, parsed_doc: ParsedDocument, section_names: List[str]
    ) -> Optional[str]:
        """
        Extract content from first matching section.

        Searches parsed document sections for any of the provided canonical
        section names and returns the first match.

        Args:
            parsed_doc: Parsed document
            section_names: List of canonical section names to search for
                Example: ['abstract', 'summary']

        Returns:
            Section content text or None if not found

        Example:
            >>> content = extractor.extract_section_content(
            ...     parsed_doc,
            ...     ['indications_for_use']
            ... )
            >>> # Returns "The device is intended for use in..."
        """
        for section in parsed_doc.sections:
            normalized = self.normalize_section_title(section.title)
            if normalized in section_names:
                # Extract content from markdown
                pattern = f"## {re.escape(section.title)}"
                match = re.search(
                    f"{pattern}(.+?)(?:^## |\\Z)",
                    parsed_doc.markdown,
                    re.MULTILINE | re.DOTALL,
                )
                if match:
                    return match.group(1).strip()

        return None

    def find_section_by_canonical_name(
        self, parsed_doc: ParsedDocument, canonical_name: str
    ) -> Optional[str]:
        """
        Helper to extract single section by canonical name.

        Convenience wrapper around extract_section_content for single section.

        Args:
            parsed_doc: Parsed document
            canonical_name: Canonical section name (e.g., 'abstract')

        Returns:
            Section content or None
        """
        return self.extract_section_content(parsed_doc, [canonical_name])

    def validate_required_sections(
        self, parsed_doc: ParsedDocument
    ) -> Dict[str, bool]:
        """
        Check if all required sections are present in document.

        Args:
            parsed_doc: Parsed document

        Returns:
            Dictionary mapping canonical section name to presence (True/False)

        Example:
            >>> status = extractor.validate_required_sections(parsed_doc)
            >>> # {'indications_for_use': True, 'device_description': False, ...}
        """
        required = self.get_required_sections()
        status = {}

        for canonical_name in required:
            content = self.find_section_by_canonical_name(parsed_doc, canonical_name)
            status[canonical_name] = content is not None and len(content) > 0

        return status
