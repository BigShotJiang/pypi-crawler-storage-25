# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Extractors module for FDA document metadata extraction.

This module provides extractors for extracting metadata from FDA regulatory
documents (510(k) summaries, De Novo decision summaries).

Classes:
    - BaseExtractor (DocumentExtractor): Abstract base class for document extractors
    - MetadataExtractor (FDA510kExtractor): FDA 510(k) metadata extraction
    - LLMValidator (LLMMetadataValidator): LLM-based validation for extracted metadata
    - SectionTitleNormalizer: Normalizes FDA document section titles
    - detect_document_type: Helper function to detect 510(k) vs De Novo documents
"""

from .base import DocumentExtractor
from .metadata_extractor import (
    FDA510kExtractor,
    SectionTitleNormalizer,
    detect_document_type,
)
from .llm_validator import LLMMetadataValidator

# Aliases for public API
BaseExtractor = DocumentExtractor
MetadataExtractor = FDA510kExtractor
LLMValidator = LLMMetadataValidator

__all__ = [
    # Base classes
    "DocumentExtractor",
    "BaseExtractor",
    # Metadata extraction
    "FDA510kExtractor",
    "MetadataExtractor",
    "SectionTitleNormalizer",
    "detect_document_type",
    # LLM validation
    "LLMMetadataValidator",
    "LLMValidator",
]
