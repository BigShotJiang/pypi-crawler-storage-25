# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
FDA 510(k) metadata extractor using regex-based extraction.

Extends DocumentExtractor base class with 510(k)-specific extraction logic.

Extracts key metadata fields from FDA 510(k) summary documents:
- K-number (UID)
- Device/Trade name
- Manufacturer/Applicant
- Regulation number and name
- Regulatory class
- Product codes
- Dates (submitted, received)
- Indications for use

Uses structured header section and fallback to 510(k) Summary section.

Phase 2F Enhancement (2025-11-28):
- Added document type detection (510k vs De Novo)
- Added SectionTitleNormalizer using YAML patterns
- Integration with DocumentPatternLoader for pattern-based extraction
"""

import logging
import re
from datetime import datetime
from typing import Dict, List, Optional, Tuple

from ashmatics_tools import ParsedDocument, ParsedSection

from .base import DocumentExtractor
from ..domain_knowledge import DocumentPatternLoader, get_document_patterns

logger = logging.getLogger(__name__)


class SectionTitleNormalizer:
    """
    Normalizes FDA document section titles for robust matching.

    Uses patterns from DocumentPatternLoader to handle variations in:
    - Section numbering (e.g., "5.6.1 Device Description" -> "Device Description")
    - Case variations (e.g., "INDICATIONS FOR USE" vs "Indications for Use")
    - Abbreviations and alternative phrasings

    Phase 2F Enhancement (2025-11-28):
    - Created as part of ASHKBAPP-43 parser optimization
    - Uses YAML patterns from 510k_summary_document_patterns.yaml and de_novo_document_patterns.yaml
    """

    # Common numbered section patterns to strip
    NUMBERING_PATTERNS = [
        r"^\d+\.\d+\.\d+\s+",  # 5.6.1 Title
        r"^\d+\.\d+\s+",  # 5.6 Title
        r"^\d+\.\s+",  # 5. Title
        r"^[A-Z]\.\s+",  # A. Title
        r"^[IVX]+\.\s+",  # IV. Title
        r"^\(\d+\)\s+",  # (1) Title
        r"^[a-z]\)\s+",  # a) Title
        r"^\([a-z]\)\s+",  # (a) Title
        r"^Section\s+\d+[:\.\s]+",  # Section 5: Title
        r"^Part\s+\d+[:\.\s]+",  # Part 5: Title
    ]

    def __init__(self, doc_type: str = "510k"):
        """
        Initialize normalizer for a specific document type.

        Args:
            doc_type: "510k" or "de_novo"
        """
        self.doc_type = doc_type
        self.patterns = get_document_patterns()
        self._numbering_regex = re.compile(
            "|".join(self.NUMBERING_PATTERNS), re.IGNORECASE
        )

    def normalize(self, title: str) -> str:
        """
        Normalize a section title by removing numbering and standardizing case.

        Args:
            title: Raw section title from parsed document

        Returns:
            Normalized title string
        """
        if not title:
            return ""

        # Strip leading/trailing whitespace
        normalized = title.strip()

        # Remove numbering prefixes
        normalized = self._numbering_regex.sub("", normalized)

        # Strip again after removing prefix
        normalized = normalized.strip()

        # Normalize whitespace
        normalized = re.sub(r"\s+", " ", normalized)

        return normalized

    def matches(self, title: str, target_section: str) -> bool:
        """
        Check if a title matches a target section name.

        Uses YAML patterns for the target section if available.

        Args:
            title: Section title to check
            target_section: Canonical section name (e.g., "indications_for_use")

        Returns:
            True if the title matches the target section
        """
        normalized_title = self.normalize(title).lower()

        # Get patterns from YAML
        header_patterns = self.patterns.get_section_header_patterns(
            self.doc_type, target_section
        )

        # Check against YAML patterns
        for pattern in header_patterns:
            try:
                if re.search(pattern, title, re.IGNORECASE):
                    return True
            except re.error:
                # Invalid regex, try as literal match
                if pattern.lower() in normalized_title:
                    return True

        # Fallback: simple containment check
        target_normalized = target_section.replace("_", " ").lower()
        if target_normalized in normalized_title:
            return True

        return False

    def find_section(
        self, sections: List[ParsedSection], target: str
    ) -> Optional[ParsedSection]:
        """
        Find a section matching the target name.

        Args:
            sections: List of parsed sections
            target: Canonical section name (e.g., "indications_for_use")

        Returns:
            Matching ParsedSection or None
        """
        for section in sections:
            if self.matches(section.title, target):
                return section
        return None

    def find_all_matching_sections(
        self, sections: List[ParsedSection], target: str
    ) -> List[ParsedSection]:
        """
        Find all sections matching the target name.

        Args:
            sections: List of parsed sections
            target: Canonical section name

        Returns:
            List of matching ParsedSections
        """
        return [s for s in sections if self.matches(s.title, target)]


def detect_document_type(content: str) -> Tuple[str, float]:
    """
    Detect whether content is from a 510(k) or De Novo document.

    Uses patterns from DocumentPatternLoader to classify the document.

    Args:
        content: Document text content (markdown or plain text)

    Returns:
        Tuple of (document_type, confidence) where document_type is
        "510k", "de_novo", or "unknown"
    """
    patterns = get_document_patterns()
    return patterns.detect_document_type(content)


class FDA510kExtractor(DocumentExtractor):
    """
    Extract metadata from FDA 510(k) regulatory documents.

    Extends DocumentExtractor with FDA 510(k)-specific extraction logic
    for regulatory submission metadata.

    Phase 2F Enhancement (2025-11-28):
    - Added SectionTitleNormalizer integration for robust section matching
    - Added document type detection
    - Uses YAML patterns from DocumentPatternLoader
    """

    def __init__(self):
        # FDA 510(k)-specific section normalization configuration
        section_config = {
            'indications_for_use': [
                'indications for use',
                'indications',
                'intended use',
                'clinical indications',
            ],
            'device_description': [
                'device description',
                'description of device',
                'product description',
                'device overview',
            ],
            'predicate_devices': [
                'predicate devices',
                'substantial equivalence',
                'comparison to predicate',
                'predicate information',
                'device comparison',
            ],
            'performance_testing': [
                'performance testing',
                'performance data',
                'validation',
                'clinical performance',
                'bench testing',
            ],
            'substantial_equivalence': [
                'substantial equivalence',
                'se discussion',
                'conclusion',
                'summary',
            ],
        }

        # Initialize base class with section config
        super().__init__(section_config)

        # 510(k)-specific regex patterns
        self.date_pattern = re.compile(r'([A-Za-z]+ \d{1,2}, \d{4})')

        # Initialize section normalizer (will be set to correct doc type during extraction)
        self._section_normalizer: Optional[SectionTitleNormalizer] = None
        self._document_patterns = get_document_patterns()

    def extract_metadata(self, parsed_doc: ParsedDocument) -> Dict:
        """
        Extract all 510(k) metadata from a parsed document.

        Args:
            parsed_doc: ParsedDocument from DocLing parser

        Returns:
            Dictionary with extracted metadata
        """
        metadata = {
            'source_file': parsed_doc.metadata.get('filename'),
            'extraction_timestamp': datetime.now().isoformat(),
            'num_pages': parsed_doc.num_pages,
        }

        # 0. Detect document type and initialize appropriate normalizer
        doc_type, doc_type_confidence = detect_document_type(parsed_doc.markdown)
        metadata['_detected_document_type'] = doc_type
        metadata['_document_type_confidence'] = doc_type_confidence

        # Initialize section normalizer for detected document type
        self._section_normalizer = SectionTitleNormalizer(doc_type if doc_type != "unknown" else "510k")

        if doc_type == "de_novo":
            logger.info(f"Detected De Novo document (confidence: {doc_type_confidence:.2f})")
        elif doc_type == "510k":
            logger.debug(f"Detected 510(k) document (confidence: {doc_type_confidence:.2f})")

        # 1. Extract from header (first ~30 lines of markdown)
        header_data = self._extract_from_header(parsed_doc.markdown)
        metadata.update(header_data)

        # 1a. K-number extraction priority hierarchy (filename is source of truth)
        metadata['k_number'] = self._extract_k_number_with_fallback(
            filename=parsed_doc.metadata.get('filename'),
            header_k_number=metadata.get('k_number')
        )

        # 2. Extract from "510(k) Summary" section (fallback/validation)
        summary_section = self._find_section(
            parsed_doc.sections, ["510(k) Summary", "510 (k) SUMMARY"]
        )
        if summary_section:
            summary_data = self._extract_from_summary_section(
                parsed_doc, summary_section
            )
            # Merge with priority to header data
            metadata = self._merge_metadata(metadata, summary_data)

        # 3. Extract Indications for Use
        metadata['indications_for_use'] = self._extract_indications(parsed_doc)

        # 4. Validate document completeness
        metadata['_completeness'] = self._validate_document_completeness(
            parsed_doc.markdown, metadata
        )

        # 5. Validate and clean
        metadata = self._validate_and_clean(metadata)

        return metadata

    def _extract_from_header(self, markdown: str) -> Dict:
        """
        Extract metadata from document header (first ~30 lines).

        This is the most reliable source as it's standardized FDA format.
        """
        # Get first 30 lines
        lines = markdown.split('\n')[:30]
        header_text = '\n'.join(lines)

        metadata = {}

        # K-number (critical - primary key)
        k_match = re.search(r'Re:\s+(K\d{6})', header_text)
        if k_match:
            metadata['k_number'] = k_match.group(1)

        # Trade/Device Name
        trade_match = re.search(r'Trade/Device Name:\s+(.+?)(?:\n|$)', header_text)
        if trade_match:
            metadata['trade_name'] = trade_match.group(1).strip()

        # Regulation Number
        reg_num_match = re.search(r'Regulation Number:\s+(21 CFR [\d.]+)', header_text)
        if reg_num_match:
            metadata['regulation_number'] = reg_num_match.group(1)

        # Regulation Name
        reg_name_match = re.search(r'Regulation Name:\s+(.+?)(?:\n|$)', header_text)
        if reg_name_match:
            metadata['regulation_name'] = reg_name_match.group(1).strip()

        # Regulatory Class
        class_match = re.search(r'Regulatory Class:\s+(?:Class\s+)?([IVX]+)', header_text)
        if class_match:
            # Normalize to always include "Class" prefix
            class_value = class_match.group(1)
            metadata['regulatory_class'] = (
                f"Class {class_value}"
                if not class_value.startswith("Class")
                else class_value
            )

        # Product Code(s)
        code_match = re.search(r'Product Code:\s+(.+?)(?:\n|$)', header_text)
        if code_match:
            codes_str = code_match.group(1).strip()
            # Split by comma if multiple codes
            metadata['product_codes'] = [c.strip() for c in codes_str.split(',')]

        # Dates
        dated_match = re.search(r'Dated:\s+(.+?)(?:\n|$)', header_text)
        if dated_match:
            date_str = dated_match.group(1).strip()
            metadata['date_submitted'] = self._parse_date(date_str)

        received_match = re.search(r'Received:\s+(.+?)(?:\n|$)', header_text)
        if received_match:
            date_str = received_match.group(1).strip()
            metadata['date_received'] = self._parse_date(date_str)

        # Predicate devices (from header if present)
        predicate_match = re.search(r'Predicate Devices?:\s+(.+?)(?:\n|$)', header_text, re.IGNORECASE)
        if predicate_match:
            predicates_str = predicate_match.group(1).strip()
            # Split by common separators (comma, semicolon) and extract K-numbers
            predicate_k_numbers = []
            # Find all K-numbers in the predicates string
            k_num_matches = re.findall(r'\bK\d{6}\b', predicates_str)
            if k_num_matches:
                metadata['predicate_devices_header'] = k_num_matches

        # Manufacturer (from first few lines before "Re:")
        manufacturer = self._extract_manufacturer(header_text)
        if manufacturer:
            metadata['manufacturer'] = manufacturer

        # Store raw header text for LLM validation
        metadata['_raw_header_text'] = header_text

        return metadata

    def _extract_manufacturer(self, header_text: str) -> Optional[str]:
        """
        Extract manufacturer from header text.

        Appears in first 3 lines before "Re: K######"
        """
        # Get text before "Re:"
        before_re = header_text.split('Re:')[0] if 'Re:' in header_text else header_text

        # Split into lines and filter out empty/image markers
        lines = [
            line.strip()
            for line in before_re.split('\n')
            if line.strip() and not line.strip().startswith('<!--')
        ]

        if not lines:
            return None

        # Manufacturer is typically in first 2-3 lines
        # Look for company name before ℅ or with company suffix
        manufacturer_text = ' '.join(lines[:3])

        # Try splitting on ℅ (care of symbol)
        if '℅' in manufacturer_text:
            manufacturer = manufacturer_text.split('℅')[0].strip()
        elif 'c/o' in manufacturer_text:
            manufacturer = manufacturer_text.split('c/o')[0].strip()
        else:
            # Look for company suffix patterns
            company_patterns = [
                r'(.+?(?:Inc\.|LLC|Ltd\.|GmbH|AB|PBC|Co\.))',
                r'(.+?(?:Incorporated|Limited|Corporation))',
            ]
            for pattern in company_patterns:
                match = re.search(pattern, manufacturer_text, re.IGNORECASE)
                if match:
                    manufacturer = match.group(1).strip()
                    break
            else:
                # Fallback: use first line
                manufacturer = lines[0].strip()

        # Clean up
        manufacturer = re.sub(r'\s+', ' ', manufacturer)  # Normalize whitespace

        return manufacturer if len(manufacturer) > 3 else None

    def _extract_k_number_with_fallback(
        self, filename: Optional[str], header_k_number: Optional[str]
    ) -> Optional[str]:
        """
        Extract K-number using priority hierarchy (filename is source of truth).

        Priority order:
        1. Filename pattern (e.g., K230337.pdf or K230337.pdf.md)
        2. Header "Re:" line extraction
        3. None if neither found

        Args:
            filename: Source filename from parsed_doc.metadata
            header_k_number: K-number extracted from "Re:" line

        Returns:
            K-number string or None
        """
        # Priority 1: Extract from filename (most reliable)
        if filename:
            # Match K###### in filename (handles .pdf, .pdf.md, etc.)
            filename_match = re.search(r'(K\d{6})', filename, re.IGNORECASE)
            if filename_match:
                k_from_filename = filename_match.group(1).upper()  # Normalize to uppercase

                # Validate against header if both exist (sanity check)
                if header_k_number and header_k_number != k_from_filename:
                    logger.warning(f"K-number mismatch - filename: {k_from_filename}, header: {header_k_number}")
                    logger.warning(f"Using filename as source of truth: {k_from_filename}")

                return k_from_filename

        # Priority 2: Fallback to header extraction
        if header_k_number:
            return header_k_number

        # Priority 3: No K-number found
        return None

    def _validate_document_completeness(
        self, markdown: str, metadata: Dict
    ) -> Dict:
        """
        Validate PDF completeness to detect incomplete/partial documents.

        Checks for key section markers and content length to estimate
        whether the parsed document is a full 510(k) submission or just
        a clearance letter.

        Args:
            markdown: Full markdown content
            metadata: Extracted metadata (for additional context)

        Returns:
            Dictionary with completeness assessment:
            - has_510k_summary: bool
            - has_predicate_section: bool
            - has_substantial_equivalence: bool
            - word_count: int
            - estimated_completeness: str (letter_only, possibly_incomplete, likely_complete, full_submission)
            - warnings: List[str]
        """
        completeness = {
            'has_510k_summary': False,
            'has_predicate_section': False,
            'has_substantial_equivalence': False,
            'has_indications_section': False,
            'word_count': 0,
            'estimated_completeness': 'unknown',
            'warnings': [],
        }

        # Check for key section markers
        completeness['has_510k_summary'] = bool(
            re.search(r'510\(k\)\s+SUMMARY', markdown, re.IGNORECASE)
        )
        completeness['has_predicate_section'] = bool(
            re.search(r'##\s*\d*\.?\s*(?:Identification of )?Predicate Device', markdown, re.IGNORECASE)
        )
        completeness['has_substantial_equivalence'] = bool(
            re.search(r'##\s*\d*\.?\s*Substantial Equivalence', markdown, re.IGNORECASE)
        )
        completeness['has_indications_section'] = bool(
            re.search(r'Indications for Use', markdown, re.IGNORECASE)
        )

        # Count words (rough estimate of content)
        completeness['word_count'] = len(markdown.split())

        # Estimate completeness based on content
        word_count = completeness['word_count']

        if word_count < 500:
            # Very short - likely just clearance letter
            completeness['estimated_completeness'] = 'letter_only'
            completeness['warnings'].append(
                'Document appears to be clearance letter only (< 500 words). '
                'May not contain predicate information or full submission content.'
            )
        elif (
            completeness['has_510k_summary']
            and completeness['has_predicate_section']
            and word_count > 2000
        ):
            # Has key sections and substantial content
            completeness['estimated_completeness'] = 'full_submission'
        elif word_count > 3000:
            # Long document, even if missing some section markers
            completeness['estimated_completeness'] = 'likely_complete'
        elif word_count > 1000:
            # Medium length - possibly incomplete or partial
            completeness['estimated_completeness'] = 'possibly_incomplete'
            if not completeness['has_510k_summary']:
                completeness['warnings'].append(
                    'Document missing "510(k) SUMMARY" section - may be incomplete.'
                )
        else:
            # Short but not letter-only
            completeness['estimated_completeness'] = 'possibly_incomplete'
            completeness['warnings'].append(
                'Document appears short (< 1000 words) and may be incomplete.'
            )

        # Additional validation checks
        if not completeness['has_indications_section'] and word_count > 500:
            completeness['warnings'].append(
                'No "Indications for Use" section found - may affect metadata extraction.'
            )

        if not completeness['has_predicate_section'] and word_count > 1000:
            completeness['warnings'].append(
                'No predicate device section found - predicate extraction may fail.'
            )

        return completeness

    def _find_section(
        self, sections: List[ParsedSection], titles: List[str]
    ) -> Optional[ParsedSection]:
        """
        Find a section by title (case-insensitive partial match).

        Phase 2F Enhancement: Uses SectionTitleNormalizer for more robust matching
        when available.
        """
        # Try using SectionTitleNormalizer first if available
        if self._section_normalizer:
            for search_title in titles:
                # Convert title to canonical section name
                canonical = search_title.lower().replace(" ", "_").replace("-", "_")
                found = self._section_normalizer.find_section(sections, canonical)
                if found:
                    return found

        # Fallback to simple matching
        for section in sections:
            section_title_lower = section.title.lower()
            # Also try with numbering stripped
            normalized_title = re.sub(r"^\d+\.\d+\.\d+\s+|^\d+\.\d+\s+|^\d+\.\s+", "", section_title_lower)
            for search_title in titles:
                search_lower = search_title.lower()
                if search_lower in section_title_lower or search_lower in normalized_title:
                    return section
        return None

    def _extract_from_summary_section(
        self, parsed_doc: ParsedDocument, summary_section: ParsedSection
    ) -> Dict:
        """
        Extract metadata from 510(k) Summary section.

        This section has consistent subsections and can serve as:
        - Fallback for missing header data
        - Validation/cross-check
        - Additional details (contact info, predicate devices, etc.)
        """
        metadata = {}

        # Get the section content from markdown
        # Find section in markdown by title
        section_start_pattern = f"## {re.escape(summary_section.title)}"
        section_match = re.search(
            f"{section_start_pattern}(.+?)(?:^## |\\Z)",
            parsed_doc.markdown,
            re.MULTILINE | re.DOTALL,
        )

        if not section_match:
            return metadata

        section_text = section_match.group(1)

        # Extract submitter/manufacturer (often has subsection or table)
        submitter_match = re.search(
            r'(?:Submitter|Sponsor|Contact Person)[\s\S]{,10}?:[\s\S]{,200}?([A-Z][^\n]+(?:Inc\.|LLC|Ltd\.|GmbH|AB|PBC))',
            section_text,
            re.MULTILINE,
        )
        if submitter_match:
            metadata['manufacturer'] = submitter_match.group(1).strip()

        # Extract trade name if not found in header
        trade_match = re.search(
            r'(?:Trade Name|Device Name)[\s\S]{,10}?:[\s\S]{,5}?([^\n]+)', section_text
        )
        if trade_match:
            metadata['trade_name'] = trade_match.group(1).strip()

        # Extract regulation info
        reg_match = re.search(
            r'Regulation Number[\s\S]{,10}?:[\s\S]{,5}?(21 CFR [\d.]+)', section_text
        )
        if reg_match:
            metadata['regulation_number'] = reg_match.group(1)

        class_match = re.search(
            r'(?:Classification|Class)[\s\S]{,10}?:[\s\S]{,5}?(Class [IVX]+|[IVX]+)',
            section_text,
        )
        if class_match:
            metadata['regulatory_class'] = class_match.group(1)

        code_match = re.search(
            r'Product Code[\s\S]{,10}?:[\s\S]{,5}?([A-Z]{2,4}(?:,\s*[A-Z]{2,4})*)',
            section_text,
        )
        if code_match:
            metadata['product_codes'] = [c.strip() for c in code_match.group(1).split(',')]

        return metadata

    def _extract_indications(self, parsed_doc: ParsedDocument) -> Optional[str]:
        """
        Extract Indications for Use text.

        Priority (updated 2025-11-27 to handle variant section titles):
        1. "Indications for Use statement" section (explicit IFU statement, e.g., "5.6.1 Indications for Use statement")
        2. "Indications for Use (Describe)" subsection within FDA form
        3. "Intended use" section with IFU content
        4. Within "510(k) Summary" section
        5. Combine content from multiple IFU-related sections if needed
        """
        # Strategy 1: Find the most specific "Indications for Use statement" section first
        # This handles documents like Optellum K202300 with numbered sections
        ifu_statement_section = self._find_section(
            parsed_doc.sections, ["Indications for Use statement", "Indications For Use Statement"]
        )

        if ifu_statement_section:
            section_text = self._extract_section_text(parsed_doc, ifu_statement_section)
            if section_text and len(section_text) > 50:  # Ensure meaningful content
                return self._clean_indications_text(section_text)

        # Strategy 2: Find dedicated "Indications for Use" section (FDA form)
        indications_section = self._find_section(
            parsed_doc.sections, ["Indications for Use", "Indications For Use"]
        )

        if indications_section:
            # Extract full section text from markdown
            section_pattern = f"## {re.escape(indications_section.title)}"
            match = re.search(
                f"{section_pattern}(.+?)(?:^## |\\Z)",
                parsed_doc.markdown,
                re.MULTILINE | re.DOTALL,
            )
            if match:
                section_text = match.group(1).strip()

                # Look for "Indications for Use (Describe)" subsection (FDA form format)
                describe_match = re.search(
                    r'Indications for Use \(Describe\)(.+?)(?:Type of Use|CONTINUE ON|^##)',
                    section_text,
                    re.DOTALL | re.MULTILINE,
                )

                if describe_match:
                    indications_text = describe_match.group(1).strip()
                    indications_text = self._clean_indications_text(indications_text)
                    if len(indications_text) > 50:  # Ensure meaningful content
                        return indications_text

        # Strategy 3: Find "Intended use" section (may contain IFU subsections)
        intended_use_section = self._find_section(
            parsed_doc.sections, ["Intended use", "Intended Use"]
        )

        if intended_use_section:
            # Check if there's a child "Indications for Use statement" section
            # by looking at all sections that come after this one with IFU content
            ifu_texts = []
            found_intended_use = False

            for section in parsed_doc.sections:
                if section.title == intended_use_section.title:
                    found_intended_use = True
                    continue

                if found_intended_use:
                    title_lower = section.title.lower()
                    # Stop if we hit a new major section (not a subsection of intended use)
                    if not any(x in title_lower for x in ['indications', 'contraindication', 'patient population', 'intended']):
                        # Check if this looks like a sibling section (same or higher level)
                        if not title_lower.startswith(intended_use_section.title.split()[0].lower()):
                            break

                    # Collect text from IFU-related subsections
                    if 'indications for use' in title_lower and 'contraindication' not in title_lower:
                        section_text = self._extract_section_text(parsed_doc, section)
                        if section_text and len(section_text) > 50:
                            ifu_texts.append(section_text)

            if ifu_texts:
                combined_text = '\n\n'.join(ifu_texts)
                return self._clean_indications_text(combined_text)

        # Strategy 4: Extract from 510(k) Summary
        summary_section = self._find_section(
            parsed_doc.sections, ["510(k) Summary", "510 (k) SUMMARY"]
        )

        if summary_section:
            section_match = re.search(
                f"## {re.escape(summary_section.title)}(.+?)(?:^## |\\Z)",
                parsed_doc.markdown,
                re.MULTILINE | re.DOTALL,
            )
            if section_match:
                section_text = section_match.group(1)

                # Look for Indications subsection
                indications_match = re.search(
                    r'(?:Indications for Use|Intended Use)[\s\S]{,500}?:[\s\S]{,20}?(.+?)(?:\n\n##|\Z)',
                    section_text,
                    re.DOTALL,
                )

                if indications_match:
                    indications_text = indications_match.group(1).strip()
                    if len(indications_text) > 50:
                        return self._clean_indications_text(indications_text)

        return None

    def _extract_section_text(self, parsed_doc: ParsedDocument, section: 'ParsedSection') -> Optional[str]:
        """
        Extract text content from a section by finding it in the markdown.

        Args:
            parsed_doc: Parsed document
            section: Section to extract text from

        Returns:
            Section text content or None
        """
        # Escape special regex characters in title
        escaped_title = re.escape(section.title)

        # Match section header and content until next section or end
        pattern = f"##+ {escaped_title}(.+?)(?:^##+ |\\Z)"
        match = re.search(pattern, parsed_doc.markdown, re.MULTILINE | re.DOTALL)

        if match:
            content = match.group(1).strip()
            # Remove image placeholders
            content = re.sub(r'<!-- image -->', '', content)
            return content.strip()

        return None

    def _clean_indications_text(self, text: str) -> str:
        """Clean up indications text from markdown artifacts."""
        # Remove checkbox markers
        text = re.sub(r'- \[[ x]\]\s*', '', text)
        # Remove extra whitespace
        text = re.sub(r'\n{3,}', '\n\n', text)
        # Remove leading/trailing whitespace
        text = text.strip()
        return text

    def _parse_date(self, date_str: str) -> str:
        """
        Parse FDA date format to ISO format.

        Args:
            date_str: Date in format "Month DD, YYYY"

        Returns:
            ISO date string "YYYY-MM-DD"
        """
        try:
            parsed = datetime.strptime(date_str, "%B %d, %Y")
            return parsed.date().isoformat()
        except Exception:
            # Return original if parsing fails
            return date_str

    def _merge_metadata(self, primary: Dict, secondary: Dict) -> Dict:
        """
        Merge two metadata dicts, prioritizing primary (header data).

        Use secondary to fill gaps.
        """
        merged = primary.copy()

        for key, value in secondary.items():
            if key not in merged or not merged[key]:
                merged[key] = value

        return merged

    def _validate_and_clean(self, metadata: Dict) -> Dict:
        """Validate extracted metadata and add validation flags."""
        validation = {
            'is_valid': True,
            'missing_critical_fields': [],
            'warnings': [],
        }

        # Critical fields
        critical = ['k_number', 'trade_name', 'regulation_number', 'regulatory_class']

        for field in critical:
            if field not in metadata or not metadata[field]:
                validation['missing_critical_fields'].append(field)
                validation['is_valid'] = False

        # Validate formats
        if 'k_number' in metadata and metadata['k_number']:
            if not re.match(r'K\d{6}', metadata['k_number']):
                validation['warnings'].append('K-number format unexpected')

        if 'regulation_number' in metadata and metadata['regulation_number']:
            if not metadata['regulation_number'].startswith('21 CFR'):
                validation['warnings'].append('Regulation number format unexpected')

        if 'regulatory_class' in metadata and metadata['regulatory_class']:
            if not re.match(r'Class [IVX]+', metadata['regulatory_class']):
                validation['warnings'].append('Regulatory class format unexpected')

        metadata['_validation'] = validation

        return metadata

    def get_required_sections(self) -> List[str]:
        """
        Return list of required section IDs for FDA 510(k) documents.

        Returns:
            List of canonical section names that must be present
        """
        return [
            'indications_for_use',
            'device_description',
            'predicate_devices',
            'performance_testing',
        ]
