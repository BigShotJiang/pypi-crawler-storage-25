# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Main FDA 510(k) processing pipeline.

Complete pipeline for processing FDA 510(k) PDF documents:
1. Parse PDF with DocLing
2. Extract metadata with regex
3. Validate with LLM
4. Map to MongoDB schema
5. Save outputs
"""

import asyncio
import json
from pathlib import Path
from typing import List, Optional, Dict, Any

import pandas as pd

from ashmatics_tools import ParsedDocument, create_llm_client, create_parser, get_config_class

from .config import PipelineConfig, ProcessingResult
from .enrichers import PredicateExtractor, TableClassifier, TableConsolidator, TrainingDataExtractor, PerformanceDataExtractor
from .extractors import FDA510kExtractor, LLMMetadataValidator
from .mappers import RegulatoryDocumentMapper
from .storage import BatchOutputManager, BatchOutput, DocumentOutput


class FDA510kPipeline:
    """
    Complete pipeline for processing FDA 510(k) documents.

    Features:
    - PDF parsing with DocLing
    - Regex-based metadata extraction
    - LLM validation (optional)
    - MongoDB schema mapping
    - Batch processing with concurrency control
    """

    def __init__(self, config: Optional[PipelineConfig] = None):
        """
        Initialize pipeline.

        Args:
            config: Pipeline configuration. If None, uses defaults.
        """
        self.config = config or PipelineConfig()

        # Initialize non-LLM components (no shared state)
        self.parser = create_parser("docling", config=self.config.parser_config)
        self.extractor = FDA510kExtractor()
        self.mapper = RegulatoryDocumentMapper()

        # Create output directories
        self.config.output_markdown_dir.mkdir(parents=True, exist_ok=True)
        self.config.output_metadata_dir.mkdir(parents=True, exist_ok=True)

        # Initialize batch output manager (ASHKBAPP-44)
        self.batch_manager: Optional[BatchOutputManager] = None
        if self.config.enable_batch_output:
            self.batch_manager = BatchOutputManager(
                base_output_dir=self.config.batch_output_dir,
                figure_min_size=self.config.figure_min_size,
                storage_mode=self.config.storage_mode,
            )

    def _create_llm_components(self):
        """
        Create fresh LLM client and components for a single document.

        This method is called once per document to avoid shared state issues
        when processing multiple documents concurrently. Each document gets
        its own LLM client instance with its own connection pool.

        Returns:
            Tuple of (validator, table_consolidator, table_classifier, predicate_extractor, training_data_extractor, performance_data_extractor)
        """
        if not self.config.enable_llm_validation:
            return None, None, None, None, None, None

        # Get the appropriate config class for the LLM provider
        config_class = get_config_class(self.config.llm_provider)

        # Create LLM config (loads from environment variables automatically)
        llm_config = config_class(**self.config.llm_config_overrides)

        # Create LLM client with provider-specific config
        llm_client = create_llm_client(self.config.llm_provider, llm_config)

        # Create all LLM-dependent components with shared client
        # (They'll all share the same client instance for this document)
        validator = LLMMetadataValidator(llm_client=llm_client)

        table_consolidator = TableConsolidator(
            llm_client=llm_client,
            provider=self.config.llm_provider,
            llm_config_overrides=self.config.llm_config_overrides,
            use_llm_validation=True,
        )

        table_classifier = TableClassifier(
            llm_client=llm_client,
            provider=self.config.llm_provider,
            llm_config_overrides=self.config.llm_config_overrides
        )

        predicate_extractor = PredicateExtractor(
            llm_client=llm_client,
            provider=self.config.llm_provider,
            llm_config_overrides=self.config.llm_config_overrides
        )

        training_data_extractor = TrainingDataExtractor(
            llm_client=llm_client,
            provider=self.config.llm_provider,
            llm_config_overrides=self.config.llm_config_overrides
        )

        # Phase 2E: Performance data extractor
        performance_data_extractor = PerformanceDataExtractor(
            llm_client=llm_client,
            provider=self.config.llm_provider,
            llm_config_overrides=self.config.llm_config_overrides
        )

        return validator, table_consolidator, table_classifier, predicate_extractor, training_data_extractor, performance_data_extractor

    async def process_single(
        self,
        pdf_path: Path,
        doc_output: Optional[DocumentOutput] = None,
    ) -> ProcessingResult:
        """
        Process a single 510(k) PDF document.

        Args:
            pdf_path: Path to PDF file
            doc_output: Optional DocumentOutput for batch mode (ASHKBAPP-44)

        Returns:
            ProcessingResult with metadata, audit info, and token usage
        """
        # Token tracking
        tokens_by_operation = {}
        total_tokens = 0
        total_cost = 0.0

        try:
            # Create fresh LLM components for this document (avoids shared state issues)
            validator, table_consolidator, table_classifier, predicate_extractor, training_data_extractor, performance_data_extractor = (
                self._create_llm_components()
            )

            # 1. Parse PDF
            parsed_doc: ParsedDocument = await self.parser.parse_file(str(pdf_path))

            # 2. Extract metadata with regex
            extracted_metadata = self.extractor.extract_metadata(parsed_doc)

            # 3. Validate with LLM (if enabled)
            validation_audit = None
            if validator and extracted_metadata.get('_raw_header_text'):
                header_text = extracted_metadata['_raw_header_text']
                extracted_metadata, validation_audit = await validator.validate_metadata(
                    header_text, extracted_metadata
                )

                # Track validation tokens
                if validation_audit and 'tokens_used' in validation_audit:
                    val_tokens = validation_audit['tokens_used']['total']
                    tokens_by_operation['validation'] = val_tokens
                    total_tokens += val_tokens

                # Check confidence threshold
                confidence = validation_audit.get('confidence', 100)
                if confidence < self.config.llm_validation_confidence_threshold:
                    extracted_metadata['_needs_review'] = True
                    extracted_metadata['_review_reason'] = (
                        f"Low validation confidence: {confidence}"
                    )

            # 3.4. Consolidate multi-page tables (Phase 2C - if enabled)
            consolidated_tables = None
            if table_consolidator and parsed_doc.tables:
                # Consolidate split tables (pass markdown for caption extraction)
                consolidated_tables = await table_consolidator.consolidate_tables(
                    parsed_doc.tables,
                    parsed_doc.markdown  # For caption extraction (DocLing limitation)
                )

                # Store consolidation metadata
                consolidation_metadata = {
                    'total_tables_before': len(parsed_doc.tables),
                    'total_tables_after': len(consolidated_tables),
                    'merged_groups': [
                        {
                            'table_id': table.table_id,
                            'merged_from': table.merged_from,
                            'merge_method': table.merge_method,
                            'merge_confidence': table.merge_confidence,
                        }
                        for table in consolidated_tables
                        if table.merged_from
                    ],
                }
                extracted_metadata['_table_consolidation'] = consolidation_metadata

            # 3.5. Classify tables (if enabled and tables exist)
            # Use consolidated tables if available, otherwise use original
            tables_to_classify = consolidated_tables if consolidated_tables else None
            table_classifications = {}

            if table_classifier and tables_to_classify:
                # Build table list for classifier from consolidated tables
                tables_for_classification = []
                for table in tables_to_classify:
                    table_dict = {
                        'table_id': table.table_id,
                        'caption': table.caption,
                        'markdown': table.markdown,
                    }
                    tables_for_classification.append(table_dict)

                # Classify all tables (now returns tokens too)
                classifications, classification_tokens = await table_classifier.classify_tables(
                    tables_for_classification
                )

                # Track classification tokens
                tokens_by_operation['table_classification'] = classification_tokens
                total_tokens += classification_tokens

                # Store classifications by table_id
                for table, category in zip(tables_for_classification, classifications):
                    table_classifications[table['table_id']] = category.value

                # Store in metadata for reference
                extracted_metadata['_table_classifications'] = table_classifications
            elif table_classifier and parsed_doc.tables:
                # Fallback: no consolidation, classify original tables
                tables_for_classification = []
                for idx, table_data in enumerate(parsed_doc.tables):
                    table_dict = {
                        'table_id': f"table_{idx + 1}",
                        'caption': getattr(table_data, 'caption', None),
                        'markdown': getattr(table_data, 'markdown', None),
                    }
                    tables_for_classification.append(table_dict)

                # Classify all tables (now returns tokens too)
                classifications, classification_tokens = await table_classifier.classify_tables(
                    tables_for_classification
                )

                # Track classification tokens
                tokens_by_operation['table_classification'] = classification_tokens
                total_tokens += classification_tokens

                # Store classifications by table_id
                for table, category in zip(tables_for_classification, classifications):
                    table_classifications[table['table_id']] = category.value

                # Store in metadata for reference
                extracted_metadata['_table_classifications'] = table_classifications

            # 3.6. Extract predicates (if enabled)
            if predicate_extractor:
                predicates, predicate_tokens = await predicate_extractor.extract_predicates(
                    metadata=extracted_metadata,
                    parsed_doc=parsed_doc,
                    table_classifications=table_classifications,
                )

                # Track predicate extraction tokens
                tokens_by_operation['predicate_extraction'] = predicate_tokens
                total_tokens += predicate_tokens

                # Store extracted predicates for mapper (keep as Pydantic objects, not dicts)
                # The mapper will use them directly when building the PredicatesSection
                extracted_metadata['_extracted_predicates'] = predicates

            # 3.7. Extract training data for AI/ML devices (Phase 2D, if enabled)
            if training_data_extractor and table_classifications:
                # Filter tables classified as 'study_design'
                study_design_tables = []

                if tables_to_classify:
                    # Use consolidated tables if available
                    for table in tables_to_classify:
                        table_id = table.table_id
                        if table_classifications.get(table_id) == 'study_design':
                            study_design_tables.append({
                                'table_id': table_id,
                                'caption': table.caption,
                                'markdown': table.markdown,
                            })
                elif parsed_doc.tables:
                    # Fallback: use original tables
                    for idx, table_data in enumerate(parsed_doc.tables):
                        table_id = f"table_{idx + 1}"
                        if table_classifications.get(table_id) == 'study_design':
                            study_design_tables.append({
                                'table_id': table_id,
                                'caption': getattr(table_data, 'caption', None),
                                'markdown': getattr(table_data, 'markdown', None),
                            })

                # Extract training data from study_design tables + document context
                if study_design_tables or parsed_doc.markdown:
                    training_data = await training_data_extractor.extract_training_data(
                        study_design_tables=study_design_tables,
                        document_text=parsed_doc.markdown,  # Full document for context
                    )

                    # Store extracted training data for mapper (Pydantic object)
                    if training_data:
                        extracted_metadata['_extracted_training_data'] = training_data

                        # Track in metadata for logging
                        extracted_metadata['_has_training_data'] = True
                        extracted_metadata['_training_data_confidence'] = training_data.extraction_confidence

                    # Note: Training data extraction uses same LLM client as other operations,
                    # so tokens are already tracked by the client. We don't separately track here
                    # unless the extractor returns token counts (future enhancement).

            # 3.8. Extract performance data (Phase 2E, if enabled)
            if performance_data_extractor and self.config.enable_performance_extraction:
                # Filter tables classified as 'performance_metrics' or 'study_design'
                performance_tables = []

                if tables_to_classify:
                    # Use consolidated tables if available
                    for table in tables_to_classify:
                        table_id = table.table_id
                        classification = table_classifications.get(table_id)
                        if classification in ['performance_metrics', 'study_design']:
                            performance_tables.append({
                                'table_id': table_id,
                                'caption': table.caption,
                                'markdown': table.markdown,
                            })
                elif parsed_doc.tables:
                    # Fallback: use original tables
                    for idx, table_data in enumerate(parsed_doc.tables):
                        table_id = f"table_{idx + 1}"
                        classification = table_classifications.get(table_id)
                        if classification in ['performance_metrics', 'study_design']:
                            performance_tables.append({
                                'table_id': table_id,
                                'caption': getattr(table_data, 'caption', None),
                                'markdown': getattr(table_data, 'markdown', None),
                            })

                # Get product code for domain knowledge context
                product_codes = extracted_metadata.get('product_codes', [])
                product_code = product_codes[0] if product_codes else None

                # Extract performance data
                if performance_tables or parsed_doc.markdown:
                    performance_data = await performance_data_extractor.extract_performance_data(
                        performance_tables=performance_tables,
                        document_text=parsed_doc.markdown,
                        product_code=product_code,
                        submission_type='510k',
                    )

                    # Store extracted performance data for mapper (Pydantic object)
                    if performance_data:
                        extracted_metadata['_extracted_performance_data'] = performance_data
                        extracted_metadata['_has_performance_data'] = True
                        extracted_metadata['_performance_data_confidence'] = performance_data.extraction_confidence

                    # Note: Performance data extraction uses same LLM client as other operations,
                    # so tokens are already tracked by the client.

            # 4. Get k_number early (needed for batch output)
            k_number = extracted_metadata.get('k_number', pdf_path.stem)

            # 4.5. Batch output: save figures and tables (ASHKBAPP-44)
            if doc_output and self.batch_manager:
                # Save parsed markdown
                self.batch_manager.save_parsed_markdown(doc_output, parsed_doc.markdown)

                # Process and save figures (if enabled)
                if self.config.save_figures and parsed_doc.figures:
                    self.batch_manager.process_and_save_figures(
                        doc_output,
                        parsed_doc.figures,
                        parsed_doc.markdown,
                    )
                    # Store figure URLs and captions in metadata for mapper
                    figure_urls = self.batch_manager.figure_manager.get_figure_urls(doc_output.figures)
                    extracted_metadata['_figure_urls'] = figure_urls

                    # Also store captions extracted from markdown (ASHKBAPP-44)
                    figure_captions = {
                        fig.figure_id: fig.caption
                        for fig in doc_output.figures
                        if fig.caption
                    }
                    extracted_metadata['_figure_captions'] = figure_captions

                # Process and save tables (if enabled)
                # Use consolidated tables if available, otherwise fall back to raw tables
                tables_to_save = consolidated_tables
                if not tables_to_save and parsed_doc.tables:
                    # Convert raw tables to format compatible with storage manager
                    from .enrichers.table_consolidator import ConsolidatedTable
                    tables_to_save = [
                        ConsolidatedTable(
                            table_id=f"table_{idx + 1}",
                            caption=getattr(t, 'caption', None),
                            markdown=getattr(t, 'markdown', ''),
                            merged_from=[],
                            merge_confidence=100.0,
                            merge_method="none",
                            original_indices=[idx],
                        )
                        for idx, t in enumerate(parsed_doc.tables)
                    ]
                if self.config.save_tables and tables_to_save:
                    self.batch_manager.process_and_save_tables(
                        doc_output,
                        tables_to_save,
                        table_classifications,
                    )

            # 5. Map to MongoDB schema
            # Pass consolidated tables to mapper if available
            regulatory_doc = self.mapper.map_to_document(
                extracted_metadata, parsed_doc, validation_audit, consolidated_tables
            )

            # 6. Save outputs
            # 6.1. Batch output: save exports (ASHKBAPP-44)
            if doc_output and self.batch_manager:
                self.batch_manager.save_exports(doc_output, regulatory_doc, extracted_metadata)
                self.batch_manager.update_processing_result(
                    doc_output,
                    success=True,
                    tokens_used=total_tokens,
                )

            # 6.2. Legacy output paths (for backward compatibility)
            # Save markdown (if enabled)
            if self.config.write_markdown:
                markdown_path = self.config.output_markdown_dir / f"{k_number}.md"
                with open(markdown_path, 'w', encoding='utf-8') as f:
                    f.write(parsed_doc.markdown)

            # Save metadata JSON (if enabled)
            if self.config.write_metadata_json:
                metadata_path = self.config.output_metadata_dir / f"{k_number}_metadata.json"

                # Prepare metadata for JSON serialization
                json_metadata = self._prepare_for_json(extracted_metadata)

                with open(metadata_path, 'w', encoding='utf-8') as f:
                    json.dump(json_metadata, f, indent=2)

            # Save MongoDB document JSON
            doc_path = self.config.output_metadata_dir / f"{k_number}_mongo_doc.json"
            with open(doc_path, 'w', encoding='utf-8') as f:
                # Use Pydantic's model_dump with mode='json' for proper serialization
                json.dump(regulatory_doc.model_dump(mode='json'), f, indent=2)

            print(f"✓ Processed {k_number} (tokens: {total_tokens}, cost: ${total_cost:.4f})")

            return ProcessingResult(
                success=True,
                k_number=k_number,
                file_name=pdf_path.name,
                metadata=extracted_metadata,
                validation_audit=validation_audit,
                total_tokens=total_tokens,
                total_cost=total_cost,
                tokens_by_operation=tokens_by_operation,
            )

        except Exception as e:
            print(f"✗ Failed to process {pdf_path.name}: {e}")
            return ProcessingResult(
                success=False,
                k_number=None,
                file_name=pdf_path.name,
                error=str(e),
            )

    async def process_batch(self, pdf_files: List[Path]) -> List[ProcessingResult]:
        """
        Process multiple PDF files with concurrency control.

        Args:
            pdf_files: List of PDF file paths

        Returns:
            List of ProcessingResult objects
        """
        # Create batch for structured output (ASHKBAPP-44)
        batch: Optional[BatchOutput] = None
        if self.batch_manager:
            batch = self.batch_manager.create_batch()
            print(f"Created batch: {batch.batch_id}")

        semaphore = asyncio.Semaphore(self.config.max_concurrent)

        async def process_with_limit(pdf_path: Path) -> ProcessingResult:
            async with semaphore:
                # Create document output structure for this file
                doc_output: Optional[DocumentOutput] = None
                if batch and self.batch_manager:
                    # Extract k_number from filename for folder creation
                    # Actual k_number will be updated during processing
                    k_number_guess = pdf_path.stem
                    doc_output = self.batch_manager.create_document_output(batch, k_number_guess)

                return await self.process_single(pdf_path, doc_output)

        print(f"Processing {len(pdf_files)} documents...")

        # Process all files concurrently (with limit)
        results = await asyncio.gather(*[process_with_limit(fp) for fp in pdf_files])

        # Generate summary
        successful = sum(1 for r in results if r.success)
        print(f"\n✓ Processed {successful}/{len(pdf_files)} successfully")

        # Finalize batch with manifest (ASHKBAPP-44)
        if batch and self.batch_manager:
            processing_summary = {
                'successful': successful,
                'failed': len(pdf_files) - successful,
                'total_files': len(pdf_files),
            }
            self.batch_manager.finalize_batch(batch, processing_summary)
            print(f"Batch manifest saved: {batch.manifest_path}")

        # Write summary CSV (if enabled)
        if self.config.write_summary_csv:
            self._write_summary_csv(results)

        return results

    def _write_summary_csv(self, results: List[ProcessingResult]):
        """Write summary CSV of processed documents."""
        df_data = []

        for result in results:
            if result.success and result.metadata:
                df_data.append(
                    {
                        'k_number': result.k_number,
                        'manufacturer': result.metadata.get('manufacturer'),
                        'trade_name': result.metadata.get('trade_name'),
                        'regulation_number': result.metadata.get('regulation_number'),
                        'regulatory_class': result.metadata.get('regulatory_class'),
                        'product_codes': ','.join(result.metadata.get('product_codes', [])),
                        'date_submitted': result.metadata.get('date_submitted'),
                        'date_received': result.metadata.get('date_received'),
                        'is_valid': result.metadata.get('_validation', {}).get(
                            'is_valid'
                        ),
                        'needs_review': result.metadata.get('_needs_review', False),
                        'llm_confidence': (
                            result.validation_audit.get('confidence')
                            if result.validation_audit
                            else None
                        ),
                    }
                )

        if df_data:
            df = pd.DataFrame(df_data)
            csv_path = self.config.output_metadata_dir / "510k_processing_summary.csv"
            df.to_csv(csv_path, index=False)
            print(f"Summary CSV saved to {csv_path}")

    def _prepare_for_json(self, metadata: Dict) -> Dict:
        """Prepare metadata dict for JSON serialization."""
        json_safe = {}
        for key, value in metadata.items():
            # Skip internal fields (prefixed with _) - they're for pipeline use only
            if key.startswith('_'):
                continue

            if isinstance(value, (str, int, float, bool, type(None))):
                json_safe[key] = value
            elif isinstance(value, list):
                json_safe[key] = value
            elif isinstance(value, dict):
                json_safe[key] = self._prepare_for_json(value)
            else:
                json_safe[key] = str(value)
        return json_safe
