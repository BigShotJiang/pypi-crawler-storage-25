# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
CLI for FDA 510(k) Pipeline.

Provides command-line interface for processing FDA 510(k) and De Novo
documents.

Usage:
    fda-pipeline process /path/to/pdfs --output /path/to/output
    fda-pipeline process-single /path/to/document.pdf
"""

import asyncio
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from .config import PipelineConfig
from .pipeline import FDA510kPipeline

app = typer.Typer(
    name="fda-pipeline",
    help="FDA 510(k) and De Novo document extraction pipeline",
    add_completion=False,
)
console = Console()


@app.command("process")
def process_batch(
    input_dir: Path = typer.Argument(
        ...,
        help="Directory containing PDF documents to process",
        exists=True,
        file_okay=False,
        dir_okay=True,
    ),
    output_dir: Optional[Path] = typer.Option(
        None,
        "--output", "-o",
        help="Output directory for results (default: input_dir/../batch-output)",
    ),
    max_concurrent: int = typer.Option(
        3,
        "--concurrent", "-c",
        help="Maximum concurrent document processing",
    ),
    max_files: Optional[int] = typer.Option(
        None,
        "--max-files", "-n",
        help="Limit number of files to process (for testing)",
    ),
    enable_llm: bool = typer.Option(
        True,
        "--llm/--no-llm",
        help="Enable/disable LLM validation and enrichment",
    ),
    enable_performance: bool = typer.Option(
        True,
        "--performance/--no-performance",
        help="Enable/disable performance data extraction",
    ),
    llm_provider: str = typer.Option(
        "azure_openai",
        "--llm-provider",
        help="LLM provider (azure_openai, openai, anthropic)",
    ),
    save_markdown: bool = typer.Option(
        False,
        "--markdown",
        help="Save intermediate markdown files",
    ),
):
    """
    Process a batch of FDA 510(k) PDF documents.

    Extracts metadata, validates with LLM, and generates structured output.
    """
    # Find PDF files
    pdf_files = sorted(input_dir.glob("*.pdf"))
    if not pdf_files:
        console.print(f"[red]No PDF files found in {input_dir}[/red]")
        raise typer.Exit(1)

    if max_files:
        pdf_files = pdf_files[:max_files]

    console.print(f"[bold]Found {len(pdf_files)} PDF files to process[/bold]")

    # Configure pipeline
    config = PipelineConfig(
        input_dir=input_dir,
        batch_output_dir=output_dir or input_dir.parent,
        max_concurrent=max_concurrent,
        max_files=max_files,
        enable_llm_validation=enable_llm,
        enable_performance_extraction=enable_performance,
        llm_provider=llm_provider,
        write_markdown=save_markdown,
        enable_batch_output=True,
    )

    # Create and run pipeline
    pipeline = FDA510kPipeline(config)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Processing documents...", total=len(pdf_files))

        # Run async pipeline
        results = asyncio.run(pipeline.process_batch(pdf_files))

        progress.update(task, advance=len(pdf_files))

    # Display results summary
    successful = sum(1 for r in results if r.success)
    failed = len(results) - successful

    # Create results table
    table = Table(title="Processing Results")
    table.add_column("Status", style="cyan")
    table.add_column("Count", style="magenta")

    table.add_row("Successful", f"[green]{successful}[/green]")
    table.add_row("Failed", f"[red]{failed}[/red]" if failed else "0")
    table.add_row("Total", str(len(results)))

    console.print(table)

    # Show failed files
    if failed:
        console.print("\n[bold red]Failed documents:[/bold red]")
        for result in results:
            if not result.success:
                console.print(f"  - {result.file_name}: {result.error}")


@app.command("process-single")
def process_single(
    pdf_path: Path = typer.Argument(
        ...,
        help="Path to PDF document to process",
        exists=True,
        file_okay=True,
        dir_okay=False,
    ),
    output_dir: Optional[Path] = typer.Option(
        None,
        "--output", "-o",
        help="Output directory for results",
    ),
    enable_llm: bool = typer.Option(
        True,
        "--llm/--no-llm",
        help="Enable/disable LLM validation",
    ),
    llm_provider: str = typer.Option(
        "azure_openai",
        "--llm-provider",
        help="LLM provider (azure_openai, openai, anthropic)",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose", "-v",
        help="Show detailed output",
    ),
):
    """
    Process a single FDA 510(k) PDF document.
    """
    console.print(f"[bold]Processing: {pdf_path.name}[/bold]")

    # Configure pipeline
    config = PipelineConfig(
        input_dir=pdf_path.parent,
        batch_output_dir=output_dir or pdf_path.parent,
        enable_llm_validation=enable_llm,
        llm_provider=llm_provider,
        enable_batch_output=output_dir is not None,
    )

    # Create and run pipeline
    pipeline = FDA510kPipeline(config)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Processing...", total=1)

        result = asyncio.run(pipeline.process_single(pdf_path))

        progress.update(task, advance=1)

    # Display results
    if result.success:
        console.print(f"\n[bold green]Success![/bold green]")
        console.print(f"K-Number: {result.k_number}")

        if verbose and result.metadata:
            console.print("\n[bold]Extracted Metadata:[/bold]")
            for key, value in result.metadata.items():
                if not key.startswith("_"):
                    console.print(f"  {key}: {value}")

        if result.total_tokens:
            console.print(f"\nTokens used: {result.total_tokens}")

    else:
        console.print(f"\n[bold red]Failed:[/bold red] {result.error}")
        raise typer.Exit(1)


@app.command("version")
def version():
    """Show package version."""
    from . import __version__
    console.print(f"ashmatics-fda-pipeline v{__version__}")


if __name__ == "__main__":
    app()
