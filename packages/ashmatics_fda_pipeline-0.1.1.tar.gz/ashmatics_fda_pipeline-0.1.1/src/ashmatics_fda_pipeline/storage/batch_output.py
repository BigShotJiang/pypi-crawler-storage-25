# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""Batch output manager for FDA 510(k) pipeline.

Orchestrates:
- Batch folder structure creation
- Document-level folder organization
- Batch manifest generation
- Coordination between storage managers

Folder Structure:
    batch-YYYYMMDD-HHMMSS/
    ├── batch_manifest.json
    ├── K300204/
    │   ├── parsed/
    │   │   └── K300204.md
    │   ├── figures/
    │   │   ├── figure_1_abc123.png
    │   │   └── figures_manifest.json
    │   ├── tables/
    │   │   ├── table_1.md
    │   │   ├── table_1.json
    │   │   └── tables_manifest.json
    │   └── export/
    │       ├── K300204_mongo_doc.json
    │       └── K300204_metadata.json
    └── K300205/
        └── ...
"""

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from ashmatics_tools.document_storage import (
    FigureStorageManager,
    ProcessedFigure,
    StoredTable,
    TableStorageManager,
)

logger = logging.getLogger(__name__)


@dataclass
class DocumentOutput:
    """Complete output for a single processed document.

    Attributes:
        k_number: Document identifier (e.g., 'K300204')
        doc_dir: Root directory for this document
        parsed_markdown_path: Path to saved markdown
        figures: Processed and saved figures
        tables: Processed and saved tables
        mongo_doc_path: Path to MongoDB document JSON
        metadata_path: Path to extracted metadata JSON
        processing_result: Success/failure info and stats
    """

    k_number: str
    doc_dir: Path
    parsed_markdown_path: Optional[Path] = None
    figures: List[ProcessedFigure] = field(default_factory=list)
    tables: List[StoredTable] = field(default_factory=list)
    mongo_doc_path: Optional[Path] = None
    metadata_path: Optional[Path] = None
    processing_result: Dict[str, Any] = field(default_factory=dict)


@dataclass
class BatchOutput:
    """Complete batch processing output.

    Attributes:
        batch_id: Unique batch identifier (batch-YYYYMMDD-HHMMSS)
        batch_dir: Root directory for batch
        documents: List of DocumentOutput for each processed document
        manifest_path: Path to batch_manifest.json
        started_at: Batch start timestamp (UTC)
        completed_at: Batch completion timestamp (UTC)
    """

    batch_id: str
    batch_dir: Path
    documents: List[DocumentOutput] = field(default_factory=list)
    manifest_path: Optional[Path] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


class BatchOutputManager:
    """Orchestrates batch output folder structure and manifest generation.

    Creates document-centric folder structure:
        batch-YYYYMMDD-HHMMSS/
        ├── batch_manifest.json
        ├── K300204/
        │   ├── parsed/K300204.md
        │   ├── figures/{figure files + manifest}
        │   ├── tables/{table files + manifest}
        │   └── export/{mongo_doc + metadata}
        └── ...

    Usage:
        >>> manager = BatchOutputManager(base_output_dir)
        >>> batch = manager.create_batch()
        >>> doc_output = manager.create_document_output(batch, 'K300204')
        >>> manager.save_parsed_markdown(doc_output, markdown_content)
        >>> manager.process_and_save_figures(doc_output, raw_figures, markdown)
        >>> manager.process_and_save_tables(doc_output, consolidated_tables, classifications)
        >>> manager.save_exports(doc_output, mongo_doc, metadata)
        >>> manager.finalize_batch(batch)
    """

    def __init__(
        self,
        base_output_dir: Path,
        figure_min_size: int = 200,
        storage_mode: str = "local",
    ):
        """Initialize batch output manager.

        Args:
            base_output_dir: Base directory for batch outputs
                             (e.g., ../knowledge-base-documents)
            figure_min_size: Minimum figure size (pixels) to save
            storage_mode: 'local' or 'azure' (azure is Phase 2, not yet implemented)
        """
        self.base_output_dir = Path(base_output_dir)
        self.figure_manager = FigureStorageManager(
            min_size=figure_min_size,
            storage_mode=storage_mode,
        )
        self.table_manager = TableStorageManager()

    def create_batch(self) -> BatchOutput:
        """Create a new batch with timestamped directory.

        Returns:
            BatchOutput with initialized batch directory
        """
        # Generate batch ID with compact timestamp format
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
        batch_id = f"batch-{timestamp}"

        # Create batch directory
        batch_dir = self.base_output_dir / batch_id
        batch_dir.mkdir(parents=True, exist_ok=True)

        batch = BatchOutput(
            batch_id=batch_id,
            batch_dir=batch_dir,
            started_at=datetime.now(timezone.utc),
        )

        logger.info(f"Created batch: {batch_id} at {batch_dir}")
        return batch

    def create_document_output(
        self,
        batch: BatchOutput,
        k_number: str,
    ) -> DocumentOutput:
        """Create document output structure within batch.

        Creates subdirectories:
        - parsed/
        - figures/
        - tables/
        - export/

        Args:
            batch: Parent batch
            k_number: Document identifier (e.g., 'K300204')

        Returns:
            DocumentOutput with initialized directories
        """
        doc_dir = batch.batch_dir / k_number

        # Create subdirectories
        (doc_dir / "parsed").mkdir(parents=True, exist_ok=True)
        (doc_dir / "figures").mkdir(parents=True, exist_ok=True)
        (doc_dir / "tables").mkdir(parents=True, exist_ok=True)
        (doc_dir / "export").mkdir(parents=True, exist_ok=True)

        doc_output = DocumentOutput(
            k_number=k_number,
            doc_dir=doc_dir,
        )

        batch.documents.append(doc_output)

        logger.debug(f"Created document output structure for {k_number}")
        return doc_output

    def save_parsed_markdown(
        self,
        doc_output: DocumentOutput,
        markdown_content: str,
    ) -> None:
        """Save parsed markdown to parsed/ directory.

        Args:
            doc_output: Document output structure
            markdown_content: Full parsed markdown content
        """
        md_path = doc_output.doc_dir / "parsed" / f"{doc_output.k_number}.md"

        with open(md_path, "w", encoding="utf-8") as f:
            f.write(markdown_content)

        doc_output.parsed_markdown_path = md_path
        logger.debug(f"Saved parsed markdown to {md_path}")

    def process_and_save_figures(
        self,
        doc_output: DocumentOutput,
        raw_figures: List[Any],
        document_markdown: Optional[str] = None,
    ) -> List[ProcessedFigure]:
        """Process raw figures and save to figures/ directory.

        Args:
            doc_output: Document output structure
            raw_figures: Figures from ParsedDocument.figures
            document_markdown: Full document markdown for caption extraction

        Returns:
            List of processed and saved figures
        """
        # Process figures (filter, extract metadata)
        processed = self.figure_manager.process_figures(raw_figures, document_markdown)

        # Save to figures/ directory
        if processed:
            figures_dir = doc_output.doc_dir / "figures"
            saved = self.figure_manager.save_figures(processed, figures_dir, doc_output.k_number)
            doc_output.figures = saved

        return doc_output.figures

    def process_and_save_tables(
        self,
        doc_output: DocumentOutput,
        consolidated_tables: List[Any],
        table_classifications: Optional[Dict[str, str]] = None,
    ) -> List[StoredTable]:
        """Process consolidated tables and save to tables/ directory.

        Args:
            doc_output: Document output structure
            consolidated_tables: ConsolidatedTable objects from TableConsolidator
            table_classifications: Dict mapping table_id to classification

        Returns:
            List of stored tables
        """
        # Process tables
        processed = self.table_manager.process_tables(consolidated_tables, table_classifications)

        # Save to tables/ directory
        if processed:
            tables_dir = doc_output.doc_dir / "tables"
            saved = self.table_manager.save_tables(processed, tables_dir, doc_output.k_number)
            doc_output.tables = saved

        return doc_output.tables

    def save_exports(
        self,
        doc_output: DocumentOutput,
        mongo_doc: Any,
        metadata: Dict[str, Any],
    ) -> None:
        """Save MongoDB document and metadata to export/ directory.

        Args:
            doc_output: Document output structure
            mongo_doc: Pydantic model or dict for MongoDB document
            metadata: Extracted metadata dictionary
        """
        export_dir = doc_output.doc_dir / "export"

        # Save MongoDB document
        mongo_path = export_dir / f"{doc_output.k_number}_mongo_doc.json"
        with open(mongo_path, "w", encoding="utf-8") as f:
            if hasattr(mongo_doc, "model_dump"):
                # Pydantic v2
                json.dump(mongo_doc.model_dump(mode="json"), f, indent=2, default=str)
            elif hasattr(mongo_doc, "dict"):
                # Pydantic v1
                json.dump(mongo_doc.dict(), f, indent=2, default=str)
            else:
                # Plain dict
                json.dump(mongo_doc, f, indent=2, default=str)
        doc_output.mongo_doc_path = mongo_path

        # Save metadata (filter out internal fields starting with _)
        metadata_path = export_dir / f"{doc_output.k_number}_metadata.json"
        clean_metadata = {k: v for k, v in metadata.items() if not k.startswith("_")}
        with open(metadata_path, "w", encoding="utf-8") as f:
            json.dump(clean_metadata, f, indent=2, default=str)
        doc_output.metadata_path = metadata_path

        logger.debug(f"Saved exports for {doc_output.k_number}")

    def update_processing_result(
        self,
        doc_output: DocumentOutput,
        success: bool,
        error: Optional[str] = None,
        tokens_used: int = 0,
        processing_time_seconds: Optional[float] = None,
        **kwargs: Any,
    ) -> None:
        """Update document processing result.

        Args:
            doc_output: Document output structure
            success: Whether processing succeeded
            error: Error message if failed
            tokens_used: Total tokens used for LLM operations
            processing_time_seconds: Processing duration
            **kwargs: Additional result fields
        """
        doc_output.processing_result = {
            "success": success,
            "error": error,
            "tokens_used": tokens_used,
            "processing_time_seconds": processing_time_seconds,
            **kwargs,
        }

    def finalize_batch(
        self,
        batch: BatchOutput,
        processing_summary: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Finalize batch with manifest generation.

        Args:
            batch: Batch to finalize
            processing_summary: Optional summary statistics
        """
        batch.completed_at = datetime.now(timezone.utc)

        # Build manifest
        manifest = self._build_batch_manifest(batch, processing_summary)

        # Save manifest
        manifest_path = batch.batch_dir / "batch_manifest.json"
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2, default=str)

        batch.manifest_path = manifest_path

        logger.info(f"Finalized batch {batch.batch_id} with {len(batch.documents)} documents")

    def _build_batch_manifest(
        self,
        batch: BatchOutput,
        processing_summary: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Build batch manifest JSON.

        Args:
            batch: Batch to build manifest for
            processing_summary: Optional processing summary

        Returns:
            Manifest dict ready for JSON serialization
        """
        # Calculate duration
        duration_seconds = None
        if batch.started_at and batch.completed_at:
            duration_seconds = (batch.completed_at - batch.started_at).total_seconds()

        manifest: Dict[str, Any] = {
            "batch_id": batch.batch_id,
            "batch_dir": str(batch.batch_dir),
            "started_at": batch.started_at.isoformat() if batch.started_at else None,
            "completed_at": batch.completed_at.isoformat() if batch.completed_at else None,
            "duration_seconds": duration_seconds,
            "document_count": len(batch.documents),
            "documents": [],
        }

        # Aggregate statistics
        total_figures = 0
        total_tables = 0
        successful_count = 0
        failed_count = 0
        total_tokens = 0

        for doc in batch.documents:
            # Build relative paths for portability
            relative_dir = doc.doc_dir.name

            doc_entry: Dict[str, Any] = {
                "k_number": doc.k_number,
                "directory": relative_dir,
                "outputs": {
                    "parsed_markdown": doc.parsed_markdown_path.name if doc.parsed_markdown_path else None,
                    "figure_count": len(doc.figures),
                    "table_count": len(doc.tables),
                    "mongo_doc": doc.mongo_doc_path.name if doc.mongo_doc_path else None,
                    "metadata": doc.metadata_path.name if doc.metadata_path else None,
                },
                "processing": doc.processing_result,
            }
            manifest["documents"].append(doc_entry)

            # Aggregate stats
            total_figures += len(doc.figures)
            total_tables += len(doc.tables)

            if doc.processing_result.get("success"):
                successful_count += 1
            else:
                failed_count += 1

            total_tokens += doc.processing_result.get("tokens_used", 0)

        # Add aggregates
        manifest["totals"] = {
            "documents": len(batch.documents),
            "figures": total_figures,
            "tables": total_tables,
        }

        # Add summary (merge with provided summary if any)
        manifest["summary"] = {
            "successful": successful_count,
            "failed": failed_count,
            "total_tokens": total_tokens,
            **(processing_summary or {}),
        }

        return manifest
