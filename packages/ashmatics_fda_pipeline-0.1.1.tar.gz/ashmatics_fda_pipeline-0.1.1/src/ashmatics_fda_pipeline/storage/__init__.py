# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Storage module for FDA pipeline batch output management.

This module provides components for managing batch output structure,
document-level folder organization, and manifest generation.

Classes:
    - BatchOutputManager: Orchestrates batch folder structure and manifests
    - BatchOutput: Complete batch processing output data class
    - DocumentOutput: Complete output for a single processed document
"""

from .batch_output import BatchOutputManager, BatchOutput, DocumentOutput

__all__ = [
    "BatchOutputManager",
    "BatchOutput",
    "DocumentOutput",
]
