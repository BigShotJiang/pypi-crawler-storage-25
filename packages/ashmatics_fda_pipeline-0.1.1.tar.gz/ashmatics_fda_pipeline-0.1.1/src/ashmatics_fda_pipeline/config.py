# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""Configuration for FDA 510(k) processing pipeline."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from ashmatics_tools import ParserConfig, ParserType


@dataclass
class PipelineConfig:
    """Configuration for the 510(k) processing pipeline."""

    # Parser configuration
    parser_config: ParserConfig = field(
        default_factory=lambda: ParserConfig(
            parser_type=ParserType.DOCLING,
            extract_figures=True,
            extract_tables=True,
            extract_sections=True,
            enable_ocr=True,
            ocr_language="eng",
            max_concurrent=4,
            timeout_seconds=300,
            markdown_format="github",
            preserve_formatting=True,
        )
    )

    # LLM configuration
    enable_llm_validation: bool = True
    llm_provider: str = "azure_openai"  # Use underscore format: azure_openai, openai, etc.
    llm_validation_confidence_threshold: float = 70.0
    llm_config_overrides: dict = field(default_factory=dict)  # Optional overrides for LLM config
    enable_performance_extraction: bool = True  # Phase 2E: Performance data extraction

    # Processing configuration
    max_concurrent: int = 3
    batch_size: int = 5
    write_markdown: bool = False  # Whether to write intermediate markdown files
    write_metadata_json: bool = True  # Whether to write extracted metadata JSON
    write_summary_csv: bool = True  # Whether to write summary CSV

    # Batch output configuration (ASHKBAPP-44)
    enable_batch_output: bool = True  # Use new batch folder structure
    batch_output_dir: Optional[Path] = None  # Base dir for batch-YYYYMMDD-HHMMSS folders

    # Figure handling (ASHKBAPP-44)
    save_figures: bool = True  # Save figures as PNG files
    figure_min_size: int = 200  # Min width/height for significant figures (filters logos)

    # Table handling (ASHKBAPP-44)
    save_tables: bool = True  # Save tables as MD + JSON files

    # Storage mode (ASHKBAPP-44)
    storage_mode: str = "local"  # 'local' or 'azure' (azure is Phase 2)
    azure_figure_container: Optional[str] = None  # Phase 2: Azure container for figures

    # Paths
    input_dir: Optional[Path] = None
    output_markdown_dir: Optional[Path] = None
    output_metadata_dir: Optional[Path] = None

    # Limits (for testing)
    max_files: Optional[int] = None  # Limit number of files to process

    def __post_init__(self):
        """Set default paths if not provided."""
        if self.input_dir is None:
            # Default to knowledge-base-documents/reg-510k-src-batch
            repo_root = Path(__file__).parent.parent.parent.parent
            self.input_dir = (
                repo_root / "knowledge-base-documents" / "reg-510k-src-batch"
            )

        if self.output_markdown_dir is None:
            self.output_markdown_dir = self.input_dir.parent / "parsed-docs"

        if self.output_metadata_dir is None:
            self.output_metadata_dir = self.input_dir.parent / "510k-metadata"

        # Default batch output dir to parent of input (knowledge-base-documents/)
        if self.batch_output_dir is None:
            self.batch_output_dir = self.input_dir.parent

        # Ensure paths are Path objects
        self.input_dir = Path(self.input_dir)
        self.output_markdown_dir = Path(self.output_markdown_dir)
        self.output_metadata_dir = Path(self.output_metadata_dir)
        self.batch_output_dir = Path(self.batch_output_dir)


@dataclass
class ProcessingResult:
    """Result of processing a single 510(k) document."""

    success: bool
    k_number: Optional[str]
    file_name: str
    metadata: Optional[dict] = None
    validation_audit: Optional[dict] = None
    error: Optional[str] = None

    # Token usage tracking
    total_tokens: int = 0
    total_cost: float = 0.0
    tokens_by_operation: dict = field(default_factory=dict)  # {'validation': 1234, 'classification': 5678, ...}
