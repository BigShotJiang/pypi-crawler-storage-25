# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Pipeline registry for extensible document processing.

Provides factory pattern for creating appropriate pipeline based on
document type. Supports runtime registration of new document processors.

This enables:
- Clean separation of pipeline types
- Easy extension to new document types (research papers, guidelines, etc.)
- Consistent interface across all pipelines
- Testability (can mock pipelines by type)
"""

from typing import Dict, Optional, Type

from ashmatics_datamodels.documents.base import DocumentType


class PipelineRegistry:
    """
    Central registry for document type → pipeline class mapping.

    Implements factory pattern for creating appropriate document processing
    pipeline based on document type.

    Usage:
        >>> from fda_510k_pipeline import PipelineRegistry, PipelineConfig
        >>> from ashmatics_datamodels.documents.base import DocumentType
        >>>
        >>> # Create FDA 510(k) pipeline
        >>> config = PipelineConfig(...)
        >>> pipeline = PipelineRegistry.create_pipeline(
        ...     DocumentType.REGULATORY_DOC,
        ...     config
        ... )
        >>>
        >>> # Future: Create research paper pipeline
        >>> pipeline = PipelineRegistry.create_pipeline(
        ...     DocumentType.EVIDENCE_DOC,
        ...     config
        ... )

    Future document types:
    - DocumentType.EVIDENCE_DOC → ResearchPaperPipeline
    - DocumentType.USE_CASE → GuidelinePipeline
    - DocumentType.AIMODEL_CARD → ModelCardPipeline
    """

    # Internal registry mapping document types to pipeline classes
    # Will be populated as new pipelines are implemented
    _pipelines: Dict[DocumentType, Type] = {}

    @classmethod
    def register_pipeline(
        cls,
        document_type: DocumentType,
        pipeline_class: Type,
    ) -> None:
        """
        Register a new pipeline type.

        Allows runtime registration of new document processing pipelines
        without modifying the registry class.

        Args:
            document_type: Document type enum value
            pipeline_class: Pipeline class to instantiate for this type

        Example:
            >>> from .research_paper_pipeline import ResearchPaperPipeline
            >>> PipelineRegistry.register_pipeline(
            ...     DocumentType.EVIDENCE_DOC,
            ...     ResearchPaperPipeline
            ... )
        """
        cls._pipelines[document_type] = pipeline_class

    @classmethod
    def create_pipeline(
        cls,
        document_type: DocumentType,
        config: Optional[object] = None,
    ):
        """
        Factory method to create appropriate pipeline based on document type.

        Args:
            document_type: Type of document to process
            config: Optional configuration object (e.g., PipelineConfig)

        Returns:
            Initialized pipeline instance

        Raises:
            ValueError: If no pipeline registered for document type

        Example:
            >>> pipeline = PipelineRegistry.create_pipeline(
            ...     DocumentType.REGULATORY_DOC,
            ...     config=PipelineConfig(enable_llm_validation=True)
            ... )
            >>> result = await pipeline.process_single(pdf_path)
        """
        pipeline_class = cls._pipelines.get(document_type)

        if not pipeline_class:
            raise ValueError(
                f"No pipeline registered for document type: {document_type}. "
                f"Available types: {list(cls._pipelines.keys())}"
            )

        # Instantiate pipeline with config
        return pipeline_class(config)

    @classmethod
    def get_registered_types(cls) -> list[DocumentType]:
        """
        Get list of registered document types.

        Returns:
            List of DocumentType enum values with registered pipelines

        Example:
            >>> types = PipelineRegistry.get_registered_types()
            >>> # [DocumentType.REGULATORY_DOC, DocumentType.EVIDENCE_DOC, ...]
        """
        return list(cls._pipelines.keys())

    @classmethod
    def is_registered(cls, document_type: DocumentType) -> bool:
        """
        Check if a pipeline is registered for a document type.

        Args:
            document_type: Document type to check

        Returns:
            True if pipeline registered, False otherwise

        Example:
            >>> if PipelineRegistry.is_registered(DocumentType.REGULATORY_DOC):
            ...     pipeline = PipelineRegistry.create_pipeline(...)
        """
        return document_type in cls._pipelines


# Auto-register FDA 510(k) pipeline
# This happens when the module is imported
try:
    from .pipeline import FDA510kPipeline

    PipelineRegistry.register_pipeline(
        DocumentType.REGULATORY_DOC,
        FDA510kPipeline,
    )
except ImportError:
    # If FDA510kPipeline not available yet, skip registration
    pass
