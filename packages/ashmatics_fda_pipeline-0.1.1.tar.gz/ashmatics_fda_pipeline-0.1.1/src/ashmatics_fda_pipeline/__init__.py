# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Ashmatics FDA Pipeline - FDA 510(k) and De Novo document processing pipeline.

This package provides a complete pipeline for extracting, enriching, and structuring
FDA regulatory documents (510(k) summaries and De Novo decision summaries) into
MongoDB-ready structured documents.

Quick Start:
    >>> from ashmatics_fda_pipeline import FDA510kPipeline, PipelineConfig
    >>>
    >>> # Configure pipeline
    >>> config = PipelineConfig(
    ...     enable_llm_validation=True,
    ...     enable_table_classification=True,
    ... )
    >>>
    >>> # Create and run pipeline
    >>> pipeline = FDA510kPipeline(config)
    >>> result = pipeline.process_document("path/to/K123456.pdf")

Components:
    - **Pipeline**: FDA510kPipeline, PipelineConfig, PipelineResult
    - **Extractors**: MetadataExtractor, LLMValidator, BaseExtractor
    - **Enrichers**: TableClassifier, PredicateExtractor, TrainingDataExtractor, PerformanceDataExtractor
    - **Mappers**: RegulatoryDocumentMapper, DocumentMapper
    - **Storage**: BatchOutputManager, DocumentOutput, BatchOutput
    - **Domain Knowledge**: DomainKnowledge, DocumentPatternLoader

Version: 0.1.0
"""

__version__ = "0.1.1"
__author__ = "Asher Informatics PBC"
__license__ = "Proprietary"

# Core pipeline
from ashmatics_fda_pipeline.pipeline import FDA510kPipeline
from ashmatics_fda_pipeline.config import PipelineConfig, ProcessingResult

# Alias for backward compatibility and cleaner public API
PipelineResult = ProcessingResult

# Extractors
from ashmatics_fda_pipeline.extractors import (
    BaseExtractor,
    MetadataExtractor,
    LLMValidator,
)

# Enrichers
from ashmatics_fda_pipeline.enrichers import (
    TableClassifier,
    TableCategory,
    TableConsolidator,
    ConsolidatedTable,
    PredicateExtractor,
    TrainingDataExtractor,
    PerformanceDataExtractor,
)

# Mappers
from ashmatics_fda_pipeline.mappers import (
    DocumentMapper,
    RegulatoryDocumentMapper,
)

# Storage
from ashmatics_fda_pipeline.storage import (
    BatchOutputManager,
    DocumentOutput,
    BatchOutput,
)

# Domain Knowledge
from ashmatics_fda_pipeline.domain_knowledge import (
    DomainKnowledge,
    DocumentPatternLoader,
    get_domain_knowledge,
    get_document_patterns,
)

# Pipeline Registry (for extensibility)
from ashmatics_fda_pipeline.pipeline_registry import PipelineRegistry

__all__ = [
    # Version info
    "__version__",
    "__author__",
    "__license__",
    # Core pipeline
    "FDA510kPipeline",
    "PipelineConfig",
    "PipelineResult",
    "PipelineRegistry",
    # Extractors
    "BaseExtractor",
    "MetadataExtractor",
    "LLMValidator",
    # Enrichers
    "TableClassifier",
    "TableCategory",
    "TableConsolidator",
    "ConsolidatedTable",
    "PredicateExtractor",
    "TrainingDataExtractor",
    "PerformanceDataExtractor",
    # Mappers
    "DocumentMapper",
    "RegulatoryDocumentMapper",
    # Storage
    "BatchOutputManager",
    "DocumentOutput",
    "BatchOutput",
    # Domain Knowledge
    "DomainKnowledge",
    "DocumentPatternLoader",
    "get_domain_knowledge",
    "get_document_patterns",
]
