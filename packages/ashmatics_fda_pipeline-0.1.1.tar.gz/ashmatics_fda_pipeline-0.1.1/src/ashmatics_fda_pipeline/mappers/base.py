# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Base classes for extensible document-to-MongoDB schema mapping.

Provides abstract base class pattern for mapping extracted metadata
to MongoDB document schemas while sharing common three-tier structure
logic across all document types.
"""

from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Dict, Optional

from ashmatics_tools import ParsedDocument
from ashmatics_datamodels.documents.base import MongoDocumentBase


class DocumentMapper(ABC):
    """
    Abstract base class for mapping extracted metadata to MongoDB schemas.

    Handles common three-tier structure mapping while allowing
    document-specific customization:

    Three-tier MongoDB structure (all document types):
    - Tier 1: metadata_object - Artifact/file metadata (SHARED)
    - Tier 2: metadata_content - Content classification (DOCUMENT-SPECIFIC)
    - Tier 3: content - Document body with sections (DOCUMENT-SPECIFIC)

    Subclasses implement document-type-specific mapping:
    - RegulatoryDocumentMapper: Maps to RegulatoryDocument schema
    - EvidenceDocumentMapper: Maps to EvidenceDocument schema
    - UseCaseDocumentMapper: Maps to UseCaseDocument schema
    """

    @abstractmethod
    def map_to_document(
        self,
        extracted_metadata: Dict,
        parsed_doc: ParsedDocument,
        validation_audit: Optional[Dict] = None,
    ) -> MongoDocumentBase:
        """
        Map extracted metadata to MongoDB document schema.

        Subclasses implement document-type-specific schema mapping.

        Args:
            extracted_metadata: Metadata extracted by DocumentExtractor
            parsed_doc: Original parsed document (for sections, tables, figures)
            validation_audit: Optional LLM validation audit trail

        Returns:
            Document ready for MongoDB insertion (subclass of MongoDocumentBase)

        Example (FDA 510k):
            >>> mapper = RegulatoryDocumentMapper()
            >>> doc = mapper.map_to_document(
            ...     extracted_metadata={'k_number': 'K240411', ...},
            ...     parsed_doc=parsed_doc,
            ...     validation_audit=audit
            ... )
            >>> # Returns RegulatoryDocument instance

        Example (Research Paper):
            >>> mapper = EvidenceDocumentMapper()
            >>> doc = mapper.map_to_document(
            ...     extracted_metadata={'authors': [...], 'doi': '...'},
            ...     parsed_doc=parsed_doc
            ... )
            >>> # Returns EvidenceDocument instance
        """
        pass

    # =========================================================================
    # Shared Utility Methods (inherited by all subclasses)
    # =========================================================================

    def build_metadata_object(
        self,
        extracted_metadata: Dict,
        pipeline_version: str,
        validation_audit: Optional[Dict] = None,
    ) -> Dict:
        """
        Build common metadata_object tier (Tier 1).

        This tier is SHARED across all document types - contains artifact
        metadata about the file itself, not the content.

        Args:
            extracted_metadata: Extracted metadata dictionary
            pipeline_version: Processing pipeline identifier
                Example: 'fda_510k_pipeline_v1.0', 'research_paper_pipeline_v1.0'
            validation_audit: Optional LLM validation audit trail with:
                - issues_found: List of validation issues
                - confidence: Confidence score (0-100)
                - corrections: Dictionary of corrections made
                - tokens_used: Token usage stats

        Returns:
            Dictionary with metadata_object fields to set on document

        Example usage in subclass:
            >>> metadata_object_data = self.build_metadata_object(
            ...     extracted_metadata,
            ...     pipeline_version='fda_510k_pipeline_v1.0',
            ...     validation_audit=audit
            ... )
            >>> document = RegulatoryDocument(...)
            >>> for key, value in metadata_object_data.items():
            ...     setattr(document.metadata_object, key, value)
        """
        metadata_object_data = {
            'original_filename': extracted_metadata.get('source_file'),
            'processing_pipeline': pipeline_version,
            'processing_completed_at': datetime.now(timezone.utc),
        }

        # Store validation audit issues in processing_errors field
        if validation_audit and validation_audit.get('issues_found'):
            confidence = validation_audit.get('confidence', 0)
            issues = validation_audit.get('issues_found', [])

            error_message = (
                f"LLM validation (confidence: {confidence}): " + "; ".join(issues)
            )
            metadata_object_data['processing_errors'] = [error_message]

        return metadata_object_data

    def extract_tables_from_parsed_doc(
        self, parsed_doc: ParsedDocument
    ) -> list:
        """
        Extract tables from parsed document to list of dictionaries.

        Converts ParsedDocument.tables to format suitable for TableReference
        schema mapping. This is a common operation across all document types.

        Args:
            parsed_doc: Parsed document with tables

        Returns:
            List of table dictionaries with:
                - table_id: Generated ID (e.g., 'table_1')
                - caption: Table caption (if present)
                - markdown: Table in markdown format
                - data: None (populated later by structured extractors)

        Example:
            >>> tables = self.extract_tables_from_parsed_doc(parsed_doc)
            >>> # [{'table_id': 'table_1', 'caption': '...', 'markdown': '...'}, ...]
        """
        tables = []

        for idx, table_data in enumerate(parsed_doc.tables):
            table_dict = {
                'table_id': f"table_{idx + 1}",
                'caption': getattr(table_data, 'caption', None),
                'markdown': getattr(table_data, 'markdown', None),
                'data': None,  # Populated by specialized extractors
            }
            tables.append(table_dict)

        return tables

    def extract_figures_from_parsed_doc(
        self, parsed_doc: ParsedDocument, min_figure_size: int = 200
    ) -> list:
        """
        Extract figures from parsed document to list of dictionaries.

        Converts ParsedDocument.figures to format suitable for FigureReference
        schema mapping. Filters out small images (logos, headers) based on size.

        Args:
            parsed_doc: Parsed document with figures
            min_figure_size: Minimum width/height (pixels) for significant figures.
                            Images smaller than this are excluded (logos/headers).
                            Default: 200 pixels.

        Returns:
            List of figure dictionaries with:
                - figure_id: Generated ID (e.g., 'figure_1')
                - caption: Figure caption (if present)
                - image_url: None (populated when images stored to blob storage)
                - metadata: Image dimensions, format, significance flag

        Example:
            >>> figures = self.extract_figures_from_parsed_doc(parsed_doc)
            >>> # [{'figure_id': 'figure_1', 'caption': '...', 'metadata': {...}}, ...]
        """
        figures = []
        figure_num = 1  # Sequential numbering for significant figures only

        for idx, figure_data in enumerate(parsed_doc.figures):
            image_data = getattr(figure_data, 'image_data', None)

            # Extract image metadata if available
            dimensions = None
            format_type = None
            is_significant = True

            if image_data and hasattr(image_data, 'size'):
                width, height = image_data.size
                dimensions = {'width': width, 'height': height}
                format_type = getattr(image_data, 'format', 'unknown')

                # Filter small images (logos, headers, page decorations)
                # Exclude if EITHER dimension is too small (catches wide logos, tall banners)
                # AND if both dimensions are below threshold (very small images)
                if width < min_figure_size or height < min_figure_size:
                    is_significant = False
                    # Skip small images entirely
                    continue

            # Only include significant figures
            if is_significant:
                figure_dict = {
                    'figure_id': f"figure_{figure_num}",
                    'caption': getattr(figure_data, 'caption', None),
                    'image_url': None,  # TODO Phase 2: Upload to Azure Blob Storage
                    'metadata': {
                        'dimensions': dimensions,
                        'format': format_type,
                        'is_significant': is_significant,
                        'original_index': idx,  # Original position in parsed_doc.figures
                    }
                }
                figures.append(figure_dict)
                figure_num += 1

        return figures
