# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Mappers module for FDA document schema mapping.

This module provides mappers for converting extracted FDA document metadata
to MongoDB-ready document schemas.

Classes:
    - DocumentMapper: Abstract base class for document-to-schema mapping
    - RegulatoryDocumentMapper: FDA 510(k) to RegulatoryDocument schema mapping
"""

from .base import DocumentMapper
from .document_mapper import RegulatoryDocumentMapper

__all__ = [
    "DocumentMapper",
    "RegulatoryDocumentMapper",
]
