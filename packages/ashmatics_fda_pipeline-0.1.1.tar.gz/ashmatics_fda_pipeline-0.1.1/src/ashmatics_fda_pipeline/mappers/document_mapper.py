# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Map extracted 510(k) metadata to MongoDB RegulatoryDocument schema.

Extends DocumentMapper base class with FDA 510(k)-specific schema mapping.

Converts flat extracted metadata dictionary to structured three-tier
MongoDB document schema from ashmatics-core-datamodels.
"""

from datetime import date, datetime
from typing import Dict, Optional

from ashmatics_datamodels.documents.base import (
    ContentType,
    FigureReference,
    SectionBase,
    TableReference,
)
from ashmatics_datamodels.documents.regulatory import (
    DeviceDescriptionSection,
    IndicationsSection,
    PerformanceTestingSection,
    PredicatesSection,
    RawSection,
    RegulatoryContent,
    RegulatoryDocument,
    RegulatoryMetadataContent,
    SponsorSection,
    SubstantialEquivalenceSection,
)

from ashmatics_tools import ParsedDocument

from .base import DocumentMapper
from typing import List


class RegulatoryDocumentMapper(DocumentMapper):
    """
    Maps extracted 510(k) metadata to RegulatoryDocument schema.

    Extends DocumentMapper with FDA 510(k)-specific schema mapping for
    regulatory submissions.

    Converts flat extraction results to three-tier structure:
    - metadata_object: Artifact/file metadata (uses base class builder)
    - metadata_content: FDA-specific metadata (510(k) fields)
    - content: Structured sections (regulatory sections)
    """

    def map_to_document(
        self,
        extracted_metadata: Dict,
        parsed_doc: ParsedDocument,
        validation_audit: Optional[Dict] = None,
        consolidated_tables: Optional[List] = None,
    ) -> RegulatoryDocument:
        """
        Map extracted metadata to RegulatoryDocument schema.

        Args:
            extracted_metadata: Metadata extracted from document
            parsed_doc: Original ParsedDocument from parser
            validation_audit: Optional LLM validation audit trail
            consolidated_tables: Optional list of ConsolidatedTable objects (Phase 2C)

        Returns:
            RegulatoryDocument ready for MongoDB insertion
        """
        # Build metadata_content (FDA-specific)
        metadata_content = self._build_metadata_content(extracted_metadata)

        # Build content sections
        # Use consolidated tables if available (Phase 2C)
        content = self._build_content(extracted_metadata, parsed_doc, consolidated_tables)

        # Create document
        document = RegulatoryDocument(
            metadata_content=metadata_content,
            content=content,
        )

        # Use base class method to build metadata_object
        metadata_object_data = self.build_metadata_object(
            extracted_metadata,
            pipeline_version='fda_510k_pipeline_v1.0',
            validation_audit=validation_audit,
        )

        # Update metadata_object fields
        for key, value in metadata_object_data.items():
            setattr(document.metadata_object, key, value)

        return document

    def _build_metadata_content(self, metadata: Dict) -> RegulatoryMetadataContent:
        """Build metadata_content tier from extracted data."""

        # Parse dates
        clearance_date = self._parse_date_field(metadata.get('date_received'))

        # Determine device class (normalize format)
        device_class = self._normalize_device_class(metadata.get('regulatory_class'))

        # Get product code(s) - join if multiple
        product_code = None
        if 'product_codes' in metadata and metadata['product_codes']:
            if isinstance(metadata['product_codes'], list):
                product_code = ','.join(metadata['product_codes'])  # Join multiple codes
            else:
                product_code = metadata['product_codes']

        # Extract top-level predicate_devices array for easy querying
        predicate_devices = self._extract_predicate_k_numbers(metadata)

        return RegulatoryMetadataContent(
            content_type=ContentType.SUMMARY_510K,
            title=metadata.get('trade_name', 'Untitled 510(k)'),
            k_number=metadata.get('k_number'),
            clearance_date=clearance_date,
            applicant=metadata.get('manufacturer'),
            device_name=metadata.get('trade_name'),
            device_class=device_class,
            product_code=product_code,
            predicate_devices=predicate_devices,  # Top-level array for queries
        )

    def _build_content(
        self, metadata: Dict, parsed_doc: ParsedDocument, consolidated_tables: Optional[List] = None
    ) -> RegulatoryContent:
        """
        Build content tier with sections, tables, and figures.

        Args:
            metadata: Extracted metadata
            parsed_doc: Parsed document
            consolidated_tables: Optional list of ConsolidatedTable objects (Phase 2C)
        """

        # Map parsed sections to structured sections
        sections = {}

        # 0. Sponsor Information
        sponsor_text = self._extract_section_content(
            parsed_doc, ["Sponsor", "Applicant", "Submitter", "Manufacturer Information", "Company Information"]
        )
        sections["0_sponsor"] = SponsorSection(
            title="Sponsor Information",
            order=0,
            text=sponsor_text or "",
        )

        # 1. Device Description
        device_desc_text = self._extract_section_content(
            parsed_doc, ["Device Description", "Description of Device"]
        )
        sections["1_device_description"] = DeviceDescriptionSection(
            title="Device Description",
            order=1,
            text=device_desc_text or "",
        )

        # 2. Indications for Use
        indications_text = metadata.get('indications_for_use', '')
        sections["2_indications_for_use"] = IndicationsSection(
            title="Indications for Use",
            order=2,
            text=indications_text or "",
        )

        # 3. Predicate Devices
        predicates_text = self._extract_section_content(
            parsed_doc, ["Predicate Devices", "Substantial Equivalent"]
        )
        # Get extracted predicates from metadata (populated by PredicateExtractor enricher)
        extracted_predicates = metadata.get('_extracted_predicates', [])
        sections["3_predicate_devices"] = PredicatesSection(
            title="Predicate Devices",
            order=3,
            text=predicates_text or "",
            predicates=extracted_predicates,
        )

        # 4. Performance Testing (with AI/ML training data and performance results if available)
        testing_text = self._extract_section_content(
            parsed_doc, ["Performance Testing", "Performance Data", "Testing"]
        )

        # Get extracted training data (Phase 2D) if available
        extracted_training_data = metadata.get('_extracted_training_data')

        # Get extracted performance data (Phase 2E) if available
        extracted_performance_data = metadata.get('_extracted_performance_data')

        sections["4_performance_testing"] = PerformanceTestingSection(
            title="Performance Testing",
            order=4,
            text=testing_text or "",
            training_data=extracted_training_data,  # Phase 2D: AI/ML training data
            test_results=extracted_performance_data,  # Phase 2E: Performance test results
        )

        # 5. Substantial Equivalence
        se_text = self._extract_section_content(
            parsed_doc, ["Substantial Equivalence", "Conclusion"]
        )
        sections["5_substantial_equivalence"] = SubstantialEquivalenceSection(
            title="Substantial Equivalence",
            order=5,
            text=se_text or "",
        )

        # Extract tables - use consolidated tables if available (Phase 2C)
        tables = []

        # Get table classifications if available
        table_classifications = metadata.get('_table_classifications', {})

        if consolidated_tables:
            # Use consolidated tables (Phase 2C)
            for cons_table in consolidated_tables:
                # Build metadata dict with markdown, source format, and consolidation info
                table_metadata = {
                    'markdown': cons_table.markdown,
                    'source_format': 'docling',
                }

                # Add consolidation metadata (REQ-4.3)
                if cons_table.merged_from:
                    table_metadata['merged_from'] = cons_table.merged_from
                    table_metadata['merge_method'] = cons_table.merge_method
                    table_metadata['merge_confidence'] = cons_table.merge_confidence

                # Add classification if available
                classification = table_classifications.get(cons_table.table_id)
                if classification:
                    table_metadata['classification'] = classification

                table_ref = TableReference(
                    table_id=cons_table.table_id,
                    caption=cons_table.caption,
                    data=None,  # ConsolidatedTable doesn't have data field
                    referenced_in_sections=[],
                    metadata=table_metadata,
                )
                tables.append(table_ref)
        else:
            # Fallback: use original parsed tables
            table_dicts = self.extract_tables_from_parsed_doc(parsed_doc)

            for table_dict in table_dicts:
                # Build metadata dict with markdown and source format
                table_metadata = {
                    'markdown': table_dict['markdown'],
                    'source_format': 'docling',
                }

                # Add classification if available
                classification = table_classifications.get(table_dict['table_id'])
                if classification:
                    table_metadata['classification'] = classification

                table_ref = TableReference(
                    table_id=table_dict['table_id'],
                    caption=table_dict['caption'],
                    data=table_dict['data'],
                    referenced_in_sections=[],
                    metadata=table_metadata,
                )
                tables.append(table_ref)

        # Extract figures from parsed document (use base class method)
        # Filters out small images (logos/headers) automatically
        figure_dicts = self.extract_figures_from_parsed_doc(parsed_doc)
        figures = []

        # Get figure URLs and captions from batch output manager (ASHKBAPP-44)
        figure_urls = metadata.get('_figure_urls', {})
        figure_captions = metadata.get('_figure_captions', {})

        # Store figure metadata separately (FigureReference doesn't have metadata field yet)
        figure_metadata_list = []

        for figure_dict in figure_dicts:
            # Use URL from storage manager if available (ASHKBAPP-44)
            image_url = figure_urls.get(figure_dict['figure_id'], figure_dict['image_url'])

            # Use caption from storage manager if available (extracted from markdown)
            caption = figure_captions.get(figure_dict['figure_id'], figure_dict['caption'])

            figure_ref = FigureReference(
                figure_id=figure_dict['figure_id'],
                caption=caption,
                image_url=image_url,
                referenced_in_sections=[],
            )
            figures.append(figure_ref)

            # Store metadata for debugging/future use
            if 'metadata' in figure_dict:
                figure_metadata_list.append({
                    'figure_id': figure_dict['figure_id'],
                    **figure_dict['metadata']
                })

        # Store figure metadata in extracted_metadata for logging
        if figure_metadata_list:
            metadata['_figure_metadata'] = figure_metadata_list

        # Build raw_sections from all parsed sections (complete document preservation)
        raw_sections = []
        for idx, section in enumerate(parsed_doc.sections):
            section_id = f"section_{idx + 1}"

            # Determine if this raw section was normalized to an enriched section
            normalized_to = self._find_normalized_section(section.title)

            # Extract actual content from markdown (sections don't contain text, markdown does)
            section_text = self._extract_section_text_from_markdown(
                parsed_doc.markdown, section.title, idx, parsed_doc.sections
            )

            raw_section = RawSection(
                section_id=section_id,
                title=section.title,
                order=idx + 1,
                text=section_text or "",
                normalized_to=normalized_to,
            )
            raw_sections.append(raw_section)

        return RegulatoryContent(sections=sections, tables=tables, figures=figures, raw_sections=raw_sections)

    def _extract_predicate_k_numbers(self, metadata: Dict) -> List[str]:
        """
        Extract predicate K-numbers from enriched metadata for top-level array.

        This creates a simple array of predicate K-numbers for easy querying,
        extracted from the detailed predicate information in the content sections.

        Args:
            metadata: Extracted metadata with enriched predicate information

        Returns:
            List of predicate K-numbers (deduplicated, sorted)
        """
        k_numbers = []

        # Source 1: Extracted predicates from PredicateExtractor enricher
        extracted_predicates = metadata.get('_extracted_predicates', [])
        for pred in extracted_predicates:
            if hasattr(pred, 'k_number') and pred.k_number:
                k_numbers.append(pred.k_number)

        # Source 2: Header predicates (fallback if enricher didn't run)
        header_predicates = metadata.get('predicate_devices_header', [])
        k_numbers.extend(header_predicates)

        # Deduplicate and sort
        unique_k_numbers = sorted(list(set(k_numbers)))

        return unique_k_numbers

    def _extract_section_content(
        self, parsed_doc: ParsedDocument, section_titles: list[str]
    ) -> Optional[str]:
        """
        Extract content for a section by searching for matching titles.

        Implements look-ahead logic: if matched section is empty, grab next section's text.
        This handles cases where numbered headers (e.g., "2. Sponsor Identification") are
        followed by content in an unnumbered section.

        Args:
            parsed_doc: Parsed document
            section_titles: List of possible section title variations

        Returns:
            Section content text or None
        """
        import re

        for idx, section in enumerate(parsed_doc.sections):
            section_title_lower = section.title.lower()
            for search_title in section_titles:
                if search_title.lower() in section_title_lower:
                    # Extract from markdown
                    pattern = f"## {re.escape(section.title)}"
                    match = re.search(
                        f"{pattern}(.+?)(?:^## |\\Z)",
                        parsed_doc.markdown,
                        re.MULTILINE | re.DOTALL,
                    )
                    if match:
                        text = match.group(1).strip()

                        # Look-ahead logic: if section is empty, try next section
                        if not text and idx + 1 < len(parsed_doc.sections):
                            next_section = parsed_doc.sections[idx + 1]
                            next_pattern = f"## {re.escape(next_section.title)}"
                            next_match = re.search(
                                f"{next_pattern}(.+?)(?:^## |\\Z)",
                                parsed_doc.markdown,
                                re.MULTILINE | re.DOTALL,
                            )
                            if next_match:
                                text = next_match.group(1).strip()

                        return text if text else None

        return None

    def _parse_date_field(self, date_value: Optional[str]) -> Optional[date]:
        """Parse date string to date object."""
        if not date_value:
            return None

        # If already ISO format
        if isinstance(date_value, str):
            try:
                return datetime.fromisoformat(date_value).date()
            except (ValueError, AttributeError):
                pass

        return None

    def _normalize_device_class(self, class_value: Optional[str]) -> Optional[str]:
        """
        Normalize device class to single character format.

        Args:
            class_value: "Class I", "Class II", "II", etc.

        Returns:
            "I", "II", or "III"
        """
        if not class_value:
            return None

        # Extract roman numerals
        import re

        match = re.search(r'\b([IVX]+)\b', class_value.upper())
        if match:
            return match.group(1)

        return None

    def _find_normalized_section(self, section_title: str) -> Optional[str]:
        """
        Determine which enriched section this raw section maps to.

        Args:
            section_title: Title of the raw section from parser

        Returns:
            Enriched section key (e.g., "2_indications_for_use") or None
        """
        title_lower = section_title.lower()

        # Define mappings from section title patterns to enriched keys
        mappings = {
            '0_sponsor': ['sponsor', 'applicant', 'submitter', 'manufacturer information', 'company information', 'contact information'],
            '1_device_description': ['device description', 'description of device', 'product description', 'device overview'],
            '2_indications_for_use': ['indications for use', 'indications', 'intended use', 'clinical indications'],
            '3_predicate_devices': ['predicate devices', 'substantial equivalent', 'comparison to predicate', 'predicate information', 'device comparison'],
            '4_performance_testing': ['performance testing', 'performance data', 'validation', 'clinical performance', 'bench testing'],
            '5_substantial_equivalence': ['substantial equivalence', 'se discussion', 'conclusion', 'summary'],
        }

        # Check for fuzzy matches
        for enriched_key, patterns in mappings.items():
            for pattern in patterns:
                if pattern in title_lower or title_lower in pattern:
                    return enriched_key

        return None  # Not mapped to any enriched section

    def _extract_section_text_from_markdown(
        self, markdown: str, section_title: str, section_idx: int, all_sections: list
    ) -> Optional[str]:
        """
        Extract section text from markdown by finding content between this section and the next.

        Args:
            markdown: Full document markdown
            section_title: Title of current section
            section_idx: Index of current section in sections list
            all_sections: All parsed sections

        Returns:
            Section text content or None
        """
        import re

        # Escape special regex characters in title
        escaped_title = re.escape(section_title)

        # Determine next section title (or end of document)
        if section_idx < len(all_sections) - 1:
            next_section_title = all_sections[section_idx + 1].title
            escaped_next = re.escape(next_section_title)
            # Match from current section to next section (or end)
            pattern = f"##+ {escaped_title}(.+?)(?:##+ {escaped_next}|\\Z)"
        else:
            # Last section - match to end of document
            pattern = f"##+ {escaped_title}(.+?)\\Z"

        match = re.search(pattern, markdown, re.MULTILINE | re.DOTALL)
        if match:
            content = match.group(1).strip()
            # Remove table/figure markers that might be embedded
            content = re.sub(r'\n\n---\n\n', '\n\n', content)  # Remove markdown separators
            return content

        return None
