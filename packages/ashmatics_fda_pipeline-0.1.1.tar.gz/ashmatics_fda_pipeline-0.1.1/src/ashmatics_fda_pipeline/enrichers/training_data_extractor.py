# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Training data extractor for AI/ML devices (Phase 2D, REQ-2).

Extracts structured training data characteristics from FDA 510(k) documents
for devices using data-driven models (AI/ML). Critical for assessing model
generalizability, potential bias, and applicability to specific patient populations.

Now includes domain knowledge integration to set appropriate expectations
based on product codes and submission types.

Requirements Addressed:
- REQ-2.1: Training dataset size (number of patients, images, samples)
- REQ-2.2: Patient demographics (age, gender, race/ethnicity stratification)
- REQ-2.3: Disease/condition characteristics (severity, stage, comorbidities)
- REQ-2.4: Data sources (institutions, public datasets, multi-site vs single-site)
- REQ-2.5: Inclusion/exclusion criteria for training data
- REQ-2.6: Device types/imaging modalities used for data acquisition
- REQ-2.7: Ground truth/reference standard methodology

Example:
    >>> from fda_510k_pipeline.enrichers import TrainingDataExtractor
    >>> extractor = TrainingDataExtractor()
    >>>
    >>> # With domain knowledge context
    >>> training_data = await extractor.extract_from_text(
    ...     document_text,
    ...     product_code="QAS",
    ...     submission_type="510k"
    ... )
"""

import json
import re
from typing import Dict, List, Optional

from ashmatics_datamodels.documents.regulatory import (
    DatasetCharacteristics,
    PatientDemographics,
    TrainingDataCharacteristics,
)
from ashmatics_tools import BaseLLMClient, LLMMessage, create_llm_client, get_config_class

# Import domain knowledge for context-aware extraction
try:
    from ashmatics_fda_pipeline.domain_knowledge import get_domain_knowledge
    DOMAIN_KNOWLEDGE_AVAILABLE = True
except ImportError:
    DOMAIN_KNOWLEDGE_AVAILABLE = False


class TrainingDataExtractor:
    """
    LLM-based extractor for AI/ML training data characteristics.

    Extracts structured training data information from study design tables
    and performance/validation sections in FDA 510(k) documents.

    Addresses REQ-2 (AI/ML Model Training Data Extraction) from Phase 2D design plan.

    Usage:
        >>> extractor = TrainingDataExtractor(provider="azure_openai")
        >>> training_data = await extractor.extract_training_data(
        ...     study_design_tables=tables,
        ...     document_text=performance_section_text
        ... )
        >>>
        >>> # Access extracted characteristics
        >>> if training_data.dataset_characteristics:
        ...     print(f"Dataset size: {training_data.dataset_characteristics.dataset_size}")
        >>> if training_data.patient_demographics:
        ...     print(f"Age range: {training_data.patient_demographics.age_range}")

    Attributes:
        llm_client: LLM client for training data extraction
    """

    def __init__(
        self,
        llm_client: Optional[BaseLLMClient] = None,
        provider: str = "azure_openai",
        llm_config_overrides: Optional[Dict] = None,
    ):
        """
        Initialize training data extractor.

        Args:
            llm_client: Optional pre-configured LLM client
            provider: LLM provider if creating new client (default: azure_openai)
            llm_config_overrides: Optional config overrides (e.g., {'deployment_name': 'chat'})
        """
        if llm_client:
            self.llm_client = llm_client
        else:
            # Create LLM client with provider-specific config
            config_class = get_config_class(provider)
            overrides = llm_config_overrides or {}
            llm_config = config_class(**overrides)  # Loads from environment variables
            self.llm_client = create_llm_client(provider, llm_config)

    async def extract_training_data(
        self,
        study_design_tables: List[Dict],
        document_text: Optional[str] = None,
    ) -> Optional[TrainingDataCharacteristics]:
        """
        Extract training data characteristics from study design tables and document text.

        Args:
            study_design_tables: List of tables classified as 'study_design'
                Each dict should have keys: table_id, caption, markdown
            document_text: Optional full document or section text for additional context

        Returns:
            TrainingDataCharacteristics if training data found, None otherwise

        Example:
            >>> tables = [
            ...     {'table_id': 'table_5', 'caption': 'Training Dataset Demographics', 'markdown': '...'},
            ...     {'table_id': 'table_8', 'caption': 'Inclusion/Exclusion Criteria', 'markdown': '...'}
            ... ]
            >>> training_data = await extractor.extract_training_data(tables)
        """
        if not study_design_tables:
            return None

        # Combine table content for LLM extraction
        combined_content = self._combine_table_content(study_design_tables)

        # Add document text context if provided
        if document_text:
            # Extract relevant sections (limit to ~2000 chars)
            relevant_text = self._extract_relevant_context(document_text)
            combined_content = f"{combined_content}\n\n## Additional Context:\n{relevant_text}"

        # Call LLM to extract structured training data
        async with self.llm_client as client:
            extracted_data = await self._llm_extract_training_data(
                combined_content, client
            )

        if not extracted_data:
            return None

        # Build TrainingDataCharacteristics object
        training_data = self._build_training_data_object(
            extracted_data, study_design_tables
        )

        return training_data

    def _combine_table_content(self, tables: List[Dict]) -> str:
        """Combine table captions and markdown content into single text."""
        combined = []
        for table in tables:
            table_id = table.get('table_id', 'unknown')
            caption = table.get('caption', 'No caption')
            markdown = table.get('markdown', '')

            # Truncate very long tables
            if len(markdown) > 2000:
                markdown = markdown[:2000] + "\n... (truncated)"

            combined.append(f"## {table_id}: {caption}\n{markdown}")

        return "\n\n".join(combined)

    def _extract_relevant_context(self, document_text: str, expanded: bool = False) -> str:
        """Extract relevant context from document text - focused on ML training content.

        Args:
            document_text: Full document text
            expanded: If True, use broader keywords for retry when initial extraction fails

        Simplified approach: only extract lines that mention ML training concepts,
        plus minimal context. Avoids bloating with validation data descriptions.
        """
        # ML-specific training phrases - ONLY these get extracted
        ml_training_phrases = [
            "training dataset",
            "training data",
            "trained on",
            "trained using",
            "algorithm trained",
            "model training",
            "training set",
            "labeled images",
            "tagged images",
            "algorithm development",
        ]

        # Expanded phrases for retry - broader search when initial extraction fails
        expanded_phrases = [
            # Alternative section headers
            "model development",
            "data used for",
            "development dataset",
            "learning dataset",
            "data collection",
            "image dataset",
            "dataset description",
            "data characteristics",
            # ML/DL terms that might indicate training context
            "deep learning",
            "machine learning",
            "neural network",
            "convolutional",
            "cnn",
            "model was developed",
            "algorithm was developed",
            # Ground truth / labeling
            "ground truth",
            "reference standard",
            "labeled by",
            "annotated by",
            "expert annotation",
            # Dataset properties
            "multi-site",
            "multicenter",
            "retrospective data",  # Sometimes training uses retrospective data
            "curated dataset",
        ]

        # Lines to exclude (FDA boilerplate, human references)
        exclude_patterns = [
            "cdrh",
            "fda.gov",
            "http",
            "www.",
            "trained radiologist",
            "trained specialist",
            "trained clinician",
            "trained medical",
            "trained physician",
            "trained user",
        ]

        # Use expanded phrases if retry mode
        search_phrases = ml_training_phrases + expanded_phrases if expanded else ml_training_phrases

        lines = document_text.split('\n')
        matched_indices = set()

        for i, line in enumerate(lines):
            line_lower = line.lower()

            # Skip excluded lines
            if any(pattern in line_lower for pattern in exclude_patterns):
                continue

            # Only include lines with search phrases
            if any(phrase in line_lower for phrase in search_phrases):
                # Add this line plus context (more context for expanded search)
                context_lines = 3 if expanded else 2
                start = max(0, i - context_lines)
                end = min(len(lines), i + context_lines + 1)
                for j in range(start, end):
                    matched_indices.add(j)

        # Build text from matched lines, in order
        relevant_lines = []
        for i in sorted(matched_indices):
            if i < len(lines):
                line = lines[i].strip()
                if line:  # Skip empty lines
                    relevant_lines.append(line)

        relevant_text = '\n'.join(relevant_lines)

        # Truncate if still too long (allow more for expanded search)
        max_length = 6000 if expanded else 4000
        if len(relevant_text) > max_length:
            relevant_text = relevant_text[:max_length] + "\n... (truncated)"

        return relevant_text

    async def _llm_extract_training_data(
        self, content: str, client
    ) -> Optional[Dict]:
        """
        Call LLM to extract structured training data from content.

        Args:
            content: Combined table and context content
            client: Open LLM client instance

        Returns:
            Dictionary with extracted training data fields
        """
        prompt = self._build_extraction_prompt(content)

        messages = [
            LLMMessage(
                role="system",
                content=(
                    "You are an expert at extracting AI/ML training data characteristics "
                    "from FDA regulatory documents. Extract structured information about "
                    "training datasets, patient demographics, and study design. "
                    "Be precise and only extract information explicitly present in the content."
                ),
            ),
            LLMMessage(role="user", content=prompt),
        ]

        try:
            response = await client.complete_with_messages(
                messages=messages,
                temperature=0.0,  # Deterministic extraction
                response_format={"type": "json_object"},
            )

            # Parse JSON response
            result = json.loads(response.text)
            return result

        except Exception as e:
            # Log error and return None (graceful degradation)
            print(f"Error extracting training data: {e}")
            return None

    def _build_extraction_prompt(self, content: str) -> str:
        """Build LLM prompt for training data extraction."""
        return f"""Extract ONLY AI/ML TRAINING data characteristics from the following FDA 510(k) content.

Content (tables and text):
{content}

**CRITICAL INSTRUCTIONS - READ VERY CAREFULLY:**

## STEP 1: IDENTIFY THE DATA TYPE

FDA 510(k) documents describe TWO types of datasets - you MUST distinguish them:

**TRAINING DATA** (what we want):
- Used to BUILD/DEVELOP the algorithm BEFORE it was tested
- Keywords: "training dataset", "algorithm development", "trained on", "labeled images", "tagged images"
- Often MINIMALLY described with few details

**VALIDATION/TEST DATA** (DO NOT EXTRACT):
- Used to EVALUATE/TEST the algorithm AFTER it was built
- Keywords: "pivotal study", "retrospective study", "validation", "performance evaluation", "clinical study"
- Usually RICHLY described with demographics, sample sizes, sites

## STEP 2: COMMON TRAPS TO AVOID

**TRAP 1: Retrospective studies are VALIDATION, not training**
- "conducted a retrospective study with 198 cases from 3 sites" → VALIDATION (NOT training)
- "evaluated 2,803 CTPA exams from a single center" → VALIDATION (NOT training)
- "509 cases from 5 US-based clinical sites" → VALIDATION (NOT training)

**TRAP 2: Demographics tables are usually for VALIDATION**
- If you see "Mean age", "Gender distribution", "Age (Years)" tables → likely VALIDATION
- Training data rarely has detailed demographic breakdowns

**TRAP 3: "distinct from training" confirms data is VALIDATION**
- "cases collected for the pivotal dataset were all distinct in time or center from the cases used to train the algorithm"
- This sentence CONFIRMS the described data is VALIDATION, not training

**TRAP 4: Performance metrics are always for VALIDATION**
- Sensitivity, specificity, PPV, NPV, AUC, DICE scores → always from VALIDATION dataset

## STEP 3: WHAT TO EXTRACT

Only extract if you find EXPLICIT training data descriptions like:
- "The algorithm was trained on [X] labeled images"
- "Training dataset consisted of [X] tagged CT scans"
- "For training, [X] images from [source] were used"

If training data is only mentioned generically (e.g., "trained on labeled images" with no numbers),
return has_training_data=true but with null values and extraction_confidence < 30.

**Dataset Characteristics (TRAINING ONLY):**
- dataset_size: ONLY if explicitly stated for TRAINING (not validation)
- data_source: ONLY if explicitly stated for TRAINING
- multi_site: ONLY if explicitly stated for TRAINING
- imaging_modality: Can infer from context if same modality used throughout
- ground_truth_method: How TRAINING images were labeled

**Patient Demographics (TRAINING ONLY):**
- Set ALL to null unless demographics are EXPLICITLY for the TRAINING dataset

**Inclusion/Exclusion (TRAINING ONLY):**
- Set ALL to null unless criteria are EXPLICITLY for TRAINING data selection

Return JSON:
{{
  "has_training_data": true/false,
  "training_data_description": "<brief quote of training data description if found, or null>",
  "dataset_characteristics": {{
    "dataset_size": <integer or null>,
    "data_source": "<string or null>",
    "multi_site": <boolean or null>,
    "imaging_modality": "<string or null>",
    "ground_truth_method": "<string or null>"
  }},
  "patient_demographics": {{
    "age_range": "<string or null>",
    "gender_distribution": {{...}} or null,
    "race_ethnicity_distribution": {{...}} or null
  }},
  "inclusion_criteria": "<string or null>",
  "exclusion_criteria": "<string or null>",
  "disease_characteristics": "<string or null>",
  "data_collection_period": "<string or null>",
  "extraction_confidence": <float 0-100>,
  "reasoning": "<explain why you believe this is training vs validation data>"
}}

**Decision Rules:**
- Set has_training_data to FALSE if no training data information is found
- Set has_training_data to FALSE if only validation/test data is described
- Use null for ALL fields where training data information is not EXPLICITLY present
- extraction_confidence < 30 if training data only mentioned generically ("trained on images")
- extraction_confidence 30-60 if some specifics but missing key details
- extraction_confidence > 70 ONLY if explicit training dataset size AND source provided

**CORRECT Example:**
Text: "The algorithm was trained on 5000 labeled chest X-rays from 3 medical centers"
→ dataset_size: 5000, multi_site: true, data_source: "3 medical centers", confidence: 75

**CORRECT Example (minimal training data):**
Text: "As is customary in machine learning, algorithm development consisted of training on labeled images"
→ has_training_data: true, all characteristics: null, confidence: 20
→ reasoning: "Training mentioned but no specific dataset details provided"

**INCORRECT - DO NOT DO THIS:**
Text: "Aidoc conducted a retrospective study with 198 cases from 3 clinical sites"
→ This is VALIDATION data. Return has_training_data: false, all null, confidence: 0
"""

    def _build_training_data_object(
        self, extracted_data: Dict, source_tables: List[Dict]
    ) -> Optional[TrainingDataCharacteristics]:
        """Build TrainingDataCharacteristics object from extracted data."""
        if not extracted_data.get('has_training_data', False):
            return None

        # Extract dataset characteristics
        dataset_char_data = extracted_data.get('dataset_characteristics', {})
        dataset_characteristics = None
        if any(dataset_char_data.values()):
            dataset_characteristics = DatasetCharacteristics(
                dataset_size=dataset_char_data.get('dataset_size'),
                data_source=dataset_char_data.get('data_source'),
                multi_site=dataset_char_data.get('multi_site'),
                imaging_modality=dataset_char_data.get('imaging_modality'),
                ground_truth_method=dataset_char_data.get('ground_truth_method'),
            )

        # Extract patient demographics
        demo_data = extracted_data.get('patient_demographics', {})
        patient_demographics = None
        if any(demo_data.values()):
            # Convert gender and race/ethnicity distributions to proper format
            gender_dist = demo_data.get('gender_distribution')
            if gender_dist and isinstance(gender_dist, dict):
                # Convert percentages to proportions (0-1), handling string values from LLM
                try:
                    gender_dist = {k: float(v) / 100.0 for k, v in gender_dist.items() if v is not None}
                except (ValueError, TypeError):
                    gender_dist = None

            race_dist = demo_data.get('race_ethnicity_distribution')
            if race_dist and isinstance(race_dist, dict):
                # Convert percentages to proportions (0-1), handling string values from LLM
                try:
                    race_dist = {k: float(v) / 100.0 for k, v in race_dist.items() if v is not None}
                except (ValueError, TypeError):
                    race_dist = None

            patient_demographics = PatientDemographics(
                age_range=demo_data.get('age_range'),
                gender_distribution=gender_dist,
                race_ethnicity_distribution=race_dist,
            )

        # Build TrainingDataCharacteristics
        training_data = TrainingDataCharacteristics(
            dataset_characteristics=dataset_characteristics,
            patient_demographics=patient_demographics,
            inclusion_criteria=extracted_data.get('inclusion_criteria'),
            exclusion_criteria=extracted_data.get('exclusion_criteria'),
            disease_characteristics=extracted_data.get('disease_characteristics'),
            data_collection_period=extracted_data.get('data_collection_period'),
            extraction_confidence=extracted_data.get('extraction_confidence', 0.0),
            source_tables=[t.get('table_id', 'unknown') for t in source_tables],
        )

        return training_data

    async def extract_from_text(
        self,
        text: str,
        client=None,
        debug: bool = False,
        product_code: Optional[str] = None,
        submission_type: Optional[str] = None,
    ) -> Optional[TrainingDataCharacteristics]:
        """
        Extract training data from free text (section content).

        Convenience method for extracting from section text without tables.
        Optionally uses domain knowledge to set appropriate expectations.

        For high-expectation product codes (CADe/CADx), if initial extraction
        fails to find training data, will retry with expanded context search.

        Args:
            text: Free text content (e.g., Performance Verification section)
            client: Optional already-open LLM client. If not provided, opens a new session.
                    For batch processing, pass an open client to avoid rate limiting.
            debug: If True, print debug info about extracted context
            product_code: FDA product code (e.g., "QAS", "MYN") for domain-specific hints
            submission_type: Submission type ("510k", "de_novo", "pma") for expectations

        Returns:
            TrainingDataCharacteristics if training data found, None otherwise.
            If product code expects detailed training data but none found,
            the result will have `notable_missing=True` flag.

        Example (single call):
            >>> training_data = await extractor.extract_from_text(document_text)

        Example (with domain knowledge):
            >>> training_data = await extractor.extract_from_text(
            ...     document_text,
            ...     product_code="QAS",
            ...     submission_type="510k"
            ... )

        Example (batch processing - recommended):
            >>> async with extractor.llm_client as client:
            ...     for doc in documents:
            ...         training_data = await extractor.extract_from_text(doc.text, client=client)
        """
        # Get domain knowledge context if available
        domain_context = ""
        confidence_adjustment = 0
        is_high_expectation = False
        missing_is_notable = False

        if DOMAIN_KNOWLEDGE_AVAILABLE and (product_code or submission_type):
            dk = get_domain_knowledge()
            domain_context = dk.format_context_for_llm(
                product_code, submission_type, "training_data"
            )
            confidence_adjustment = dk.get_confidence_adjustment(
                product_code, submission_type, "training_data"
            )
            expected_level = dk.get_expected_level(
                product_code, submission_type, "training_data"
            )
            missing_is_notable = dk.is_missing_notable(
                product_code, submission_type, "training_data"
            )

            # High expectation = confidence adjustment >= 15 (CADe/CADx, triage, etc.)
            is_high_expectation = confidence_adjustment >= 15

            if debug:
                print(f"[DEBUG] Domain context: product={product_code}, submission={submission_type}")
                print(f"[DEBUG] Expected training data level: {expected_level}")
                print(f"[DEBUG] Confidence adjustment: {confidence_adjustment:+d}")
                print(f"[DEBUG] High expectation (will retry if not found): {is_high_expectation}")
                print(f"[DEBUG] Missing is notable: {missing_is_notable}")

        # First attempt: standard context extraction
        relevant_text = self._extract_relevant_context(text, expanded=False)

        if debug:
            print(f"\n[DEBUG] Initial relevant text length: {len(relevant_text)} chars")
            if "training dataset" in relevant_text.lower():
                print(f"[DEBUG] 'training dataset' FOUND in relevant text")
            else:
                print(f"[DEBUG] 'training dataset' NOT in relevant text")

        # Prepend domain context to content if available
        content_for_llm = relevant_text
        if domain_context:
            content_for_llm = f"{domain_context}\n\n{relevant_text}"

        # Run extraction
        async def run_extraction(content: str, llm_client) -> Optional[Dict]:
            if llm_client:
                return await self._llm_extract_training_data(content, llm_client)
            else:
                async with self.llm_client as new_client:
                    return await self._llm_extract_training_data(content, new_client)

        extracted_data = await run_extraction(content_for_llm, client)

        # Check if we need to retry with expanded context
        found_training_data = extracted_data and extracted_data.get('has_training_data', False)

        if not found_training_data and is_high_expectation:
            if debug:
                print(f"\n[DEBUG] No training data found for high-expectation device - retrying with expanded context")

            # Retry with expanded context
            expanded_text = self._extract_relevant_context(text, expanded=True)

            if debug:
                print(f"[DEBUG] Expanded relevant text length: {len(expanded_text)} chars")
                print(f"[DEBUG] Expanded text added {len(expanded_text) - len(relevant_text)} more chars")

            # Only retry if expanded search found more content
            if len(expanded_text) > len(relevant_text) + 100:
                expanded_content = expanded_text
                if domain_context:
                    # Add hint that this is a retry with expanded search
                    retry_hint = "\n\n**NOTE: This is an expanded search. The device type expects detailed training data. Look carefully for any training/development data descriptions, even if using non-standard terminology.**\n"
                    expanded_content = f"{domain_context}{retry_hint}\n{expanded_text}"

                extracted_data = await run_extraction(expanded_content, client)
                found_training_data = extracted_data and extracted_data.get('has_training_data', False)

                if debug:
                    if found_training_data:
                        print(f"[DEBUG] Expanded search FOUND training data!")
                    else:
                        print(f"[DEBUG] Expanded search still found no training data")

        # Handle case where high-expectation device has no training data
        if not found_training_data:
            if missing_is_notable:
                # Return a minimal result indicating notable absence
                # We use extraction_confidence=0 and empty characteristics to signal this
                if debug:
                    print(f"[DEBUG] Returning result for high-expectation device with NO training data found")
                    print(f"[DEBUG] This is NOTABLE - expected training data for this device type")
                # Create minimal result - the 0% confidence + empty data signals "expected but not found"
                result = TrainingDataCharacteristics(
                    dataset_characteristics=None,
                    patient_demographics=None,
                    extraction_confidence=0.0,
                    source_tables=[],
                )
                # Store as private attribute for downstream consumers
                result._notable_missing = True
                result._product_code = product_code
                return result
            return None

        # Apply confidence adjustment from domain knowledge
        if confidence_adjustment and 'extraction_confidence' in extracted_data:
            original_conf = extracted_data['extraction_confidence']
            extracted_data['extraction_confidence'] = min(100, max(0, original_conf + confidence_adjustment))
            if debug:
                print(f"[DEBUG] Confidence adjusted: {original_conf} -> {extracted_data['extraction_confidence']}")

        return self._build_training_data_object(extracted_data, source_tables=[])