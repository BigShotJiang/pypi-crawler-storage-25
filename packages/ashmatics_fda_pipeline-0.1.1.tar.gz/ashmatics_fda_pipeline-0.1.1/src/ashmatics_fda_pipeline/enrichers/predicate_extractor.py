# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Predicate device extraction enricher for FDA 510(k) documents.

Multi-source extraction strategy:
1. Header regex (K-numbers from document header)
2. Section text (fuzzy title matching + LLM extraction)
3. Classified tables (predicate_comparison tables)

Deduplicates by K-number and merges comparison summaries from all sources.

Example:
    >>> from fda_510k_pipeline.enrichers import PredicateExtractor
    >>> extractor = PredicateExtractor()
    >>> predicates = await extractor.extract_predicates(
    ...     metadata=extracted_metadata,
    ...     parsed_doc=parsed_doc,
    ...     table_classifications={"table_1": "predicate_comparison"}
    ... )
    >>> # [PredicateDeviceInfo(k_number="K123456", ...)]
"""

import asyncio
import json
import re
from typing import Dict, List, Optional

from ashmatics_datamodels.documents.regulatory import PredicateDeviceInfo
from ashmatics_tools import BaseLLMClient, LLMMessage, ParsedDocument, create_llm_client, get_config_class

from .table_classifier import TableCategory


class PredicateExtractor:
    """
    Multi-source predicate device extractor for FDA 510(k) documents.

    Extracts predicate device information from:
    - Document headers (regex-based from metadata)
    - Section text (fuzzy section matching + LLM)
    - Classified tables (predicate_comparison category)

    Deduplicates and merges predicate information by K-number.

    Usage:
        >>> extractor = PredicateExtractor(provider="azure_openai")
        >>> predicates = await extractor.extract_predicates(
        ...     metadata=extracted_metadata,
        ...     parsed_doc=parsed_doc,
        ...     table_classifications=table_classifications
        ... )
        >>> # Returns list of PredicateDeviceInfo objects

    Attributes:
        llm_client: LLM client for section/table extraction
        batch_size: Number of tables to process in parallel
    """

    def __init__(
        self,
        llm_client: Optional[BaseLLMClient] = None,
        provider: str = "azure_openai",
        llm_config_overrides: Optional[Dict] = None,
        batch_size: int = 5,
    ):
        """
        Initialize predicate extractor.

        Args:
            llm_client: Optional pre-configured LLM client
            provider: LLM provider if creating new client (default: azure_openai)
            llm_config_overrides: Optional config overrides (e.g., {'deployment_name': 'chat'})
            batch_size: Number of tables to process concurrently (default: 5)
        """
        if llm_client:
            self.llm_client = llm_client
        else:
            # Create LLM client with provider-specific config
            config_class = get_config_class(provider)
            overrides = llm_config_overrides or {}
            llm_config = config_class(**overrides)  # Loads from environment variables
            self.llm_client = create_llm_client(provider, llm_config)

        self.batch_size = batch_size

    async def extract_predicates(
        self,
        metadata: Dict,
        parsed_doc: ParsedDocument,
        table_classifications: Optional[Dict[str, str]] = None,
    ) -> List[PredicateDeviceInfo]:
        """
        Extract predicates from all sources and deduplicate.

        Multi-tiered extraction strategy:
        1. Header regex (already in metadata)
        2. High-probability sections from markdown (predicate sections, substantial equivalence)
        3. Classified predicate_comparison tables

        Args:
            metadata: Extracted metadata dictionary (may contain header predicates)
            parsed_doc: ParsedDocument from DocLing
            table_classifications: Dict mapping table_id to TableCategory value

        Returns:
            List of unique PredicateDeviceInfo objects, deduplicated by K-number

        Example:
            >>> predicates = await extractor.extract_predicates(
            ...     metadata={'predicate_devices_header': ['K123456']},
            ...     parsed_doc=parsed_doc,
            ...     table_classifications={'table_1': 'predicate_comparison'}
            ... )
        """
        all_predicates = []

        # Source 1: Header predicates (from metadata extraction regex)
        header_predicates = metadata.get('predicate_devices_header', [])
        for k_num in header_predicates:
            all_predicates.append(
                PredicateDeviceInfo(
                    k_number=k_num,
                )
            )

        # Source 2: Section text extraction from markdown (high-probability sections)
        # Search for sections with common predicate-related titles
        section_predicates = await self._extract_from_markdown_sections(parsed_doc)
        all_predicates.extend(section_predicates)

        # Source 3: Classified tables (predicate_comparison tables)
        if table_classifications and parsed_doc.tables:
            table_predicates = await self._extract_from_tables(
                parsed_doc, table_classifications
            )
            all_predicates.extend(table_predicates)

        # Deduplicate and merge by K-number
        # Note: total_tokens will be tracked when we update LLM methods
        return self._deduplicate_predicates(all_predicates), 0  # TODO: Add token tracking

    async def _extract_from_markdown_sections(
        self, parsed_doc: ParsedDocument
    ) -> List[PredicateDeviceInfo]:
        """
        Extract from markdown sections using pattern matching for common section headers.

        Searches markdown directly for sections with predicate-related headers.
        Handles section title variations (predicate devices, substantial equivalence, etc.)

        Args:
            parsed_doc: ParsedDocument from DocLing

        Returns:
            List of PredicateDeviceInfo from high-probability sections
        """
        # Patterns to search for in markdown section headers
        section_patterns = [
            r'##\s*\d*\.?\s*Identification of Predicate',
            r'##\s*\d*\.?\s*Predicate Device',
            r'##\s*\d*\.?\s*Substantial Equivalence',
            r'##\s*\d*\.?\s*Comparison to Predicate',
            r'##\s*\d*\.?\s*Device Comparison',
            r'##\s*\d*\.?\s*Predicate Analysis',
            r'##\s*\d*\.?\s*SE Discussion',
        ]

        all_predicates = []

        for pattern in section_patterns:
            # Search for section in markdown
            match = re.search(pattern, parsed_doc.markdown, re.IGNORECASE)
            if match:
                # Extract full section title
                section_start = match.group(0)
                # Extract section content (everything until next ## or end)
                section_match = re.search(
                    f"{re.escape(section_start)}(.+?)(?:^## |\\Z)",
                    parsed_doc.markdown,
                    re.MULTILINE | re.DOTALL
                )

                if section_match:
                    section_text = section_match.group(1).strip()
                    # Clean text (remove image placeholders, etc.)
                    section_text = self._clean_text(section_text)

                    # Check if section has K-numbers
                    if re.search(r'\bK\d{6}\b', section_text):
                        print(f"Debug: Found predicate section: {section_start[:50]}")
                        print(f"Debug: Section text length: {len(section_text)} chars")

                        # Extract with LLM
                        section_predicates = await self._llm_extract_from_text(section_text)
                        all_predicates.extend(section_predicates)

                        # Stop after first successful extraction
                        if section_predicates:
                            break

        return all_predicates

    def _extract_section_text(
        self, parsed_doc: ParsedDocument, section_title: str
    ) -> Optional[str]:
        """
        Extract section content from markdown.

        Args:
            parsed_doc: ParsedDocument from DocLing
            section_title: Section title to extract

        Returns:
            Section content text or None if not found
        """
        # Escape special regex characters in section title
        pattern = f"## {re.escape(section_title)}"
        match = re.search(
            f"{pattern}(.+?)(?:^## |\\Z)",
            parsed_doc.markdown,
            re.MULTILINE | re.DOTALL,
        )
        if match:
            text = match.group(1).strip()
            # Clean up image placeholders and consolidate whitespace
            text = self._clean_text(text)
            return text
        return None

    def _clean_text(self, text: str) -> str:
        """
        Clean text by removing image placeholders and consolidating whitespace.

        Handles common DocLing parsing artifacts:
        - <!-- image --> placeholders (logos, page boundaries)
        - Excessive whitespace/newlines

        Args:
            text: Raw text from markdown

        Returns:
            Cleaned text with artifacts removed
        """
        # Remove <!-- image --> placeholders (logos, page breaks, etc.)
        text = re.sub(r'<!--\s*image\s*-->', ' ', text)

        # Remove other HTML comments
        text = re.sub(r'<!--.*?-->', ' ', text, flags=re.DOTALL)

        # Consolidate multiple newlines into double newlines (preserve paragraphs)
        text = re.sub(r'\n{3,}', '\n\n', text)

        # Consolidate multiple spaces into single space
        text = re.sub(r' {2,}', ' ', text)

        # Remove leading/trailing whitespace from each line
        lines = [line.strip() for line in text.split('\n')]
        text = '\n'.join(lines)

        return text.strip()

    async def _extract_from_tables(
        self,
        parsed_doc: ParsedDocument,
        table_classifications: Dict[str, str],
    ) -> List[PredicateDeviceInfo]:
        """
        Extract predicates from tables classified as predicate_comparison.

        Args:
            parsed_doc: ParsedDocument from DocLing
            table_classifications: Dict mapping table_id to category value

        Returns:
            List of PredicateDeviceInfo from comparison tables
        """
        predicates = []

        # Open LLM client context once for all tables (more efficient)
        async with self.llm_client as client:
            # Collect predicate_comparison tables
            comparison_tables = []
            for idx, table_data in enumerate(parsed_doc.tables):
                table_id = f"table_{idx + 1}"

                if table_classifications.get(table_id) == TableCategory.PREDICATE_COMPARISON.value:
                    markdown = getattr(table_data, 'markdown', None)
                    caption = getattr(table_data, 'caption', None)
                    if markdown:
                        comparison_tables.append((caption, markdown, table_id))

            # Process in batches to avoid rate limits
            for i in range(0, len(comparison_tables), self.batch_size):
                batch = comparison_tables[i : i + self.batch_size]
                batch_results = await asyncio.gather(
                    *[
                        self._llm_extract_from_table_with_client(caption, markdown, table_id, client)
                        for caption, markdown, table_id in batch
                    ]
                )

                # Flatten results
                for table_predicates in batch_results:
                    predicates.extend(table_predicates)

        return predicates

    async def _llm_extract_from_text(
        self, text: str
    ) -> List[PredicateDeviceInfo]:
        """
        Extract predicates from section text using LLM with regex fallback.

        Args:
            text: Section text content

        Returns:
            List of PredicateDeviceInfo
        """
        # Truncate very long text to stay within token limits
        max_chars = 2000
        if len(text) > max_chars:
            text = text[:max_chars] + "\n... (truncated)"

        prompt = f"""Extract predicate device information from this FDA 510(k) text.

Text:
{text}

For each predicate device mentioned, extract:
- k_number (required, format: K######)
- device_name (if mentioned)
- manufacturer (if mentioned)

Return ONLY valid JSON with array "predicates" containing objects with these fields.
Example: {{"predicates": [{{"k_number": "K123456", "device_name": "DeviceName", "manufacturer": "CompanyName"}}]}}

If no predicate devices are found, return: {{"predicates": []}}"""

        messages = [
            LLMMessage(
                role="system",
                content="You are an expert at extracting structured data from FDA regulatory documents. Be precise with K-numbers.",
            ),
            LLMMessage(role="user", content=prompt),
        ]

        async with self.llm_client as client:
            response = await client.complete_with_messages(
                messages=messages,
                temperature=0.0,  # Deterministic extraction
            )

            try:
                result = json.loads(response.text)
                predicates = []

                for item in result.get('predicates', []):
                    # Validate K-number format
                    k_number = item.get('k_number', '').strip()
                    if not re.match(r'^K\d{6}$', k_number):
                        continue  # Skip invalid K-numbers

                    predicates.append(
                        PredicateDeviceInfo(
                            k_number=k_number,
                            device_name=item.get('device_name'),
                            manufacturer=item.get('manufacturer'),
                        )
                    )

                # Fallback: If LLM found no predicates, try regex extraction
                if not predicates:
                    predicates = self._regex_extract_k_numbers(text)

                return predicates

            except (json.JSONDecodeError, ValueError) as e:
                # LLM failed to return valid JSON - fallback to regex
                print(f"Warning: Failed to parse LLM response for section text: {e}")
                print(f"Response: {response.text[:200]}...")
                # Fallback to regex extraction
                return self._regex_extract_k_numbers(text)

    def _regex_extract_k_numbers(self, text: str) -> List[PredicateDeviceInfo]:
        """
        Fallback regex extraction of K-numbers from text.

        Used when LLM extraction fails or returns no results.

        Args:
            text: Text to search for K-numbers

        Returns:
            List of PredicateDeviceInfo with just K-numbers
        """
        k_numbers = re.findall(r'\bK\d{6}\b', text)

        # Deduplicate while preserving order
        seen = set()
        unique_k_numbers = []
        for k_num in k_numbers:
            if k_num not in seen:
                seen.add(k_num)
                unique_k_numbers.append(k_num)

        return [
            PredicateDeviceInfo(k_number=k_num)
            for k_num in unique_k_numbers
        ]

    async def _llm_extract_from_table_with_client(
        self, caption: Optional[str], markdown: str, table_id: str, client
    ) -> List[PredicateDeviceInfo]:
        """
        Extract from comparison table markdown using already-open LLM client.

        Args:
            caption: Table caption
            markdown: Table markdown content
            table_id: Table identifier (for logging)
            client: Open LLM client instance

        Returns:
            List of PredicateDeviceInfo from this table
        """
        # Clean image placeholders from table markdown
        markdown = self._clean_text(markdown)

        # Truncate very long tables to stay within token limits
        max_chars = 2000
        if len(markdown) > max_chars:
            markdown = markdown[:max_chars] + "\n... (truncated)"

        prompt = f"""Extract predicate device information from this comparison table.

Table Caption: {caption or "No caption"}

Table (markdown):
{markdown}

Extract ALL predicate devices (exclude subject device).
For each predicate:
- k_number (required, format: K######)
- device_name (if present)
- manufacturer (if present)
- comparison_summary (brief summary of how it compares to subject)

Return ONLY valid JSON with "predicates" array.
Example: {{"predicates": [{{"k_number": "K123456", "device_name": "DeviceName", "manufacturer": "CompanyName", "comparison_summary": "Similar AI algorithm"}}]}}

If no predicate devices are found, return: {{"predicates": []}}"""

        messages = [
            LLMMessage(
                role="system",
                content="You are an expert at extracting structured data from FDA regulatory tables. Extract ALL predicate devices mentioned.",
            ),
            LLMMessage(role="user", content=prompt),
        ]

        # Call LLM with already-open client
        response = await client.complete_with_messages(
            messages=messages,
            temperature=0.0,  # Deterministic extraction
        )

        try:
            result = json.loads(response.text)
            predicates = []

            for item in result.get('predicates', []):
                # Validate K-number format
                k_number = item.get('k_number', '').strip()
                if not re.match(r'^K\d{6}$', k_number):
                    continue  # Skip invalid K-numbers

                predicates.append(
                    PredicateDeviceInfo(
                        k_number=k_number,
                        device_name=item.get('device_name'),
                        manufacturer=item.get('manufacturer'),
                        comparison_summary=item.get('comparison_summary'),
                    )
                )

            return predicates

        except (json.JSONDecodeError, ValueError) as e:
            # LLM failed to return valid JSON
            print(f"Warning: Failed to parse LLM response for {table_id}: {e}")
            return []

    def _deduplicate_predicates(
        self, predicates: List[PredicateDeviceInfo]
    ) -> List[PredicateDeviceInfo]:
        """
        Deduplicate predicates by K-number, merging information.

        Strategy:
        - Group by k_number
        - Prefer non-null values for optional fields
        - Concatenate comparison_summary from all sources with "; " separator

        Args:
            predicates: List of PredicateDeviceInfo (may have duplicates)

        Returns:
            Deduplicated list of PredicateDeviceInfo
        """
        merged: Dict[str, PredicateDeviceInfo] = {}

        for pred in predicates:
            k_num = pred.k_number

            if k_num not in merged:
                merged[k_num] = pred
            else:
                # Merge logic: prefer non-null values
                existing = merged[k_num]

                # Update device_name if existing is None
                if pred.device_name and not existing.device_name:
                    existing.device_name = pred.device_name

                # Update manufacturer if existing is None
                if pred.manufacturer and not existing.manufacturer:
                    existing.manufacturer = pred.manufacturer

                # Concatenate comparison_summary
                if pred.comparison_summary:
                    if existing.comparison_summary:
                        # Avoid duplicate summaries
                        if pred.comparison_summary not in existing.comparison_summary:
                            existing.comparison_summary += f"; {pred.comparison_summary}"
                    else:
                        existing.comparison_summary = pred.comparison_summary

        return list(merged.values())
