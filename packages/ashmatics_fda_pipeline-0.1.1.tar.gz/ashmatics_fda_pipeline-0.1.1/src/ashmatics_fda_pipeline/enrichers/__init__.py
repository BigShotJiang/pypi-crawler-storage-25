# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Enrichers module for FDA document content enrichment.

This module provides LLM-based enrichers for extracting structured information
from FDA regulatory documents.

Classes:
    - TableClassifier: LLM-based table classification by content type
    - TableCategory: Enum of table classification categories
    - TableConsolidator: Multi-page table consolidation
    - PredicateExtractor: Multi-source predicate device extraction
    - TrainingDataExtractor: AI/ML training data characteristics extraction
    - PerformanceDataExtractor: Clinical validation and performance data extraction
"""

from .table_classifier import TableClassifier, TableCategory
from .table_consolidator import TableConsolidator, ConsolidatedTable
from .predicate_extractor import PredicateExtractor
from .training_data_extractor import TrainingDataExtractor
from .performance_data_extractor import PerformanceDataExtractor

__all__ = [
    # Table classification
    "TableClassifier",
    "TableCategory",
    # Table consolidation
    "TableConsolidator",
    "ConsolidatedTable",
    # Predicate extraction
    "PredicateExtractor",
    # Training data
    "TrainingDataExtractor",
    # Performance data
    "PerformanceDataExtractor",
]
