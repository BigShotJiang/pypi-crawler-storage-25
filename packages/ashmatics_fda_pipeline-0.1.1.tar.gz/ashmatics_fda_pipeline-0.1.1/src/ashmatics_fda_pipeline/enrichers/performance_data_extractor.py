# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Performance data extractor for FDA 510(k) devices (Phase 2E, REQ-3).

Extracts structured clinical validation and performance testing results from
FDA 510(k) and De Novo submissions. Critical for comparative effectiveness
analysis, meta-analysis, and evidence-based device selection.

Includes domain knowledge integration to set appropriate expectations
based on product codes and submission types.

Requirements Addressed:
- REQ-3.1: Performance metrics (sensitivity, specificity, AUC, DICE, etc.)
- REQ-3.2: Validation dataset characteristics
- REQ-3.3: Statistical measures (CIs, p-values)
- REQ-3.4: Stratified results preservation
- REQ-3.5: Predicate comparison extraction
- REQ-3.6: Acceptance criteria and pass/fail status
- REQ-3.7: Study type classification (standalone, MRMC, pivotal, etc.)

Example:
    >>> from fda_510k_pipeline.enrichers import PerformanceDataExtractor
    >>> extractor = PerformanceDataExtractor()
    >>>
    >>> # With domain knowledge context
    >>> performance_data = await extractor.extract_performance_data(
    ...     performance_tables=tables,
    ...     document_text=performance_section_text,
    ...     product_code="POK",
    ...     submission_type="510k"
    ... )
"""

import json
import re
from typing import Any, Dict, List, Optional

from ashmatics_datamodels.documents.regulatory import (
    MetricType,
    PatientDemographics,
    PerformanceMetric,
    PerformanceTestResults,
    StudyType,
    TestDataset,
    ValidationStudy,
)
from ashmatics_tools import BaseLLMClient, LLMMessage, create_llm_client, get_config_class

# Import domain knowledge for context-aware extraction
try:
    from ashmatics_fda_pipeline.domain_knowledge import get_domain_knowledge

    DOMAIN_KNOWLEDGE_AVAILABLE = True
except ImportError:
    DOMAIN_KNOWLEDGE_AVAILABLE = False


class PerformanceDataExtractor:
    """
    LLM-based extractor for clinical validation and performance data.

    Extracts structured performance information from performance tables
    and validation sections in FDA 510(k) documents.

    Addresses REQ-3 (Validation Results Extraction) from Phase 2E design plan.

    Multi-source extraction strategy:
    1. Classified performance tables (performance_metrics category)
    2. Study design tables (may contain performance metrics)
    3. Performance/validation sections

    Domain knowledge integration:
    - Product code expectations drive retry logic
    - CADx devices (POK, MYN, QDQ, QBS): Expect detailed standalone + reader study
    - Triage devices (QAS): Expect minimal standalone data
    - De Novo: Expect comprehensive pivotal study

    Usage:
        >>> extractor = PerformanceDataExtractor(provider="azure_openai")
        >>> performance_data = await extractor.extract_performance_data(
        ...     performance_tables=performance_tables,
        ...     document_text=performance_section_text,
        ...     product_code="POK",
        ...     submission_type="510k"
        ... )
        >>>
        >>> # Access extracted data
        >>> if performance_data.validation_studies:
        ...     for study in performance_data.validation_studies:
        ...         print(f"Study: {study.study_name}, Type: {study.study_type}")
        >>> for metric in performance_data.performance_metrics:
        ...     print(f"{metric.metric_name}: {metric.value}")

    Attributes:
        llm_client: LLM client for performance data extraction
    """

    def __init__(
        self,
        llm_client: Optional[BaseLLMClient] = None,
        provider: str = "azure_openai",
        llm_config_overrides: Optional[Dict] = None,
    ):
        """
        Initialize performance data extractor.

        Args:
            llm_client: Optional pre-configured LLM client
            provider: LLM provider if creating new client (default: azure_openai)
            llm_config_overrides: Optional config overrides (e.g., {'deployment_name': 'chat'})
        """
        if llm_client:
            self.llm_client = llm_client
        else:
            # Create LLM client with provider-specific config
            config_class = get_config_class(provider)
            overrides = llm_config_overrides or {}
            llm_config = config_class(**overrides)  # Loads from environment variables
            self.llm_client = create_llm_client(provider, llm_config)

    async def extract_performance_data(
        self,
        performance_tables: List[Dict],
        document_text: Optional[str] = None,
        product_code: Optional[str] = None,
        submission_type: Optional[str] = None,
        client=None,
        debug: bool = False,
    ) -> Optional[PerformanceTestResults]:
        """
        Extract performance data from tables and document text.

        Args:
            performance_tables: Tables classified as 'performance_metrics' or 'study_design'
                Each dict should have keys: table_id, caption, markdown
            document_text: Optional performance section text for additional context
            product_code: FDA product code (e.g., "POK", "QAS") for domain knowledge
            submission_type: Submission type ('510k', 'de_novo', 'pma')
            client: Optional open LLM client (for batch processing)
            debug: Print debug information

        Returns:
            PerformanceTestResults if performance data found, None otherwise

        Example:
            >>> tables = [
            ...     {'table_id': 'table_18', 'caption': 'Performance Results', 'markdown': '...'},
            ...     {'table_id': 'table_20', 'caption': 'Pivotal Study Demographics', 'markdown': '...'}
            ... ]
            >>> performance_data = await extractor.extract_performance_data(
            ...     performance_tables=tables,
            ...     product_code="POK",
            ...     submission_type="510k"
            ... )
        """
        # Get domain knowledge context if available
        domain_context = ""
        confidence_adjustment = 0
        is_high_expectation = False
        missing_is_notable = False

        if DOMAIN_KNOWLEDGE_AVAILABLE and (product_code or submission_type):
            dk = get_domain_knowledge()
            domain_context = dk.format_performance_context_for_llm(
                product_code, submission_type
            )
            confidence_adjustment = dk.get_confidence_adjustment(
                product_code, submission_type, "performance_data"
            )
            expected_level = dk.get_expected_level(
                product_code, submission_type, "performance_data"
            )
            missing_is_notable = dk.is_missing_notable(
                product_code, submission_type, "performance_data"
            )

            # High expectation = confidence adjustment >= 15 (CADx, De Novo, etc.)
            is_high_expectation = confidence_adjustment >= 15

            if debug:
                print(
                    f"[DEBUG] Domain context: product={product_code}, submission={submission_type}"
                )
                print(f"[DEBUG] Expected performance data level: {expected_level}")
                print(f"[DEBUG] Confidence adjustment: {confidence_adjustment:+d}")
                print(
                    f"[DEBUG] High expectation (will retry if not found): {is_high_expectation}"
                )
                print(f"[DEBUG] Missing is notable: {missing_is_notable}")

        # Combine table content
        combined_content = self._combine_table_content(performance_tables)

        # Add document text context if provided
        if document_text:
            relevant_text = self._extract_relevant_context(document_text)
            if relevant_text:
                combined_content = (
                    f"{combined_content}\n\n## Additional Context:\n{relevant_text}"
                )

        if debug:
            print(f"[DEBUG] Combined content length: {len(combined_content)} chars")
            print(f"[DEBUG] Number of tables: {len(performance_tables)}")

        # Prepend domain context if available
        content_for_llm = combined_content
        if domain_context:
            content_for_llm = f"{domain_context}\n\n{combined_content}"

        # Run extraction
        async def run_extraction(content: str, llm_client) -> Optional[Dict]:
            if llm_client:
                return await self._llm_extract_performance_data(content, llm_client)
            else:
                async with self.llm_client as new_client:
                    return await self._llm_extract_performance_data(content, new_client)

        extracted_data = await run_extraction(content_for_llm, client)

        # Check if we need to retry with expanded context
        found_performance_data = extracted_data and extracted_data.get(
            "has_performance_data", False
        )

        if not found_performance_data and is_high_expectation and document_text:
            if debug:
                print(
                    "\n[DEBUG] No performance data found for high-expectation device - retrying with expanded context"
                )

            # Retry with expanded context
            expanded_text = self._extract_relevant_context(document_text, expanded=True)

            if debug:
                print(f"[DEBUG] Expanded relevant text length: {len(expanded_text)} chars")

            # Only retry if expanded search found more content
            if len(expanded_text) > len(combined_content) + 100:
                expanded_content = self._combine_table_content(
                    performance_tables
                ) + f"\n\n## Additional Context (Expanded):\n{expanded_text}"
                if domain_context:
                    retry_hint = "\n\n**NOTE: This is an expanded search. The device type expects detailed performance data. Look carefully for any validation/performance descriptions, even if using non-standard terminology.**\n"
                    expanded_content = f"{domain_context}{retry_hint}\n{expanded_content}"

                extracted_data = await run_extraction(expanded_content, client)
                found_performance_data = extracted_data and extracted_data.get(
                    "has_performance_data", False
                )

                if debug:
                    if found_performance_data:
                        print("[DEBUG] Expanded search FOUND performance data!")
                    else:
                        print("[DEBUG] Expanded search still found no performance data")

        # Handle case where high-expectation device has no performance data
        if not found_performance_data:
            if missing_is_notable:
                if debug:
                    print(
                        "[DEBUG] Returning result for high-expectation device with NO performance data found"
                    )
                    print(
                        "[DEBUG] This is NOTABLE - expected performance data for this device type"
                    )
                # Create minimal result - 0% confidence + empty data signals "expected but not found"
                result = PerformanceTestResults(
                    validation_studies=[],
                    performance_metrics=[],
                    extraction_confidence=0.0,
                    source_tables=[],
                )
                # Store as private attribute for downstream consumers
                result._notable_missing = True  # type: ignore
                result._product_code = product_code  # type: ignore
                return result
            return None

        # Apply confidence adjustment from domain knowledge
        if confidence_adjustment and "extraction_confidence" in extracted_data:
            original_conf = extracted_data["extraction_confidence"]
            extracted_data["extraction_confidence"] = min(
                100, max(0, original_conf + confidence_adjustment)
            )
            if debug:
                print(
                    f"[DEBUG] Confidence adjusted: {original_conf} -> {extracted_data['extraction_confidence']}"
                )

        # Build PerformanceTestResults object
        result = self._build_performance_results_object(
            extracted_data, performance_tables, product_code
        )

        # Attach token usage if available (for cost tracking)
        if result and '_token_usage' in extracted_data:
            result._token_usage = extracted_data['_token_usage']  # type: ignore

        return result

    def _combine_table_content(self, tables: List[Dict]) -> str:
        """Combine table captions and markdown content into single text."""
        if not tables:
            return ""

        combined = []
        for table in tables:
            table_id = table.get("table_id", "unknown")
            caption = table.get("caption", "No caption")
            markdown = table.get("markdown", "")

            # Truncate very long tables
            if len(markdown) > 3000:
                markdown = markdown[:3000] + "\n... (truncated)"

            combined.append(f"## {table_id}: {caption}\n{markdown}")

        return "\n\n".join(combined)

    def _extract_relevant_context(
        self, document_text: str, expanded: bool = False
    ) -> str:
        """Extract relevant context from document text - focused on performance/validation content.

        Args:
            document_text: Full document text
            expanded: If True, use broader keywords for retry when initial extraction fails

        Returns:
            Relevant text excerpts for performance data extraction
        """
        # Performance-specific phrases - core metrics and study types
        performance_phrases = [
            # Core metrics
            "performance",
            "validation",
            "sensitivity",
            "specificity",
            "auc",
            "auroc",
            "roc",
            "dice",
            "accuracy",
            "ppv",
            "npv",
            "confidence interval",
            "95% ci",
            # Study types
            "pivotal study",
            "reader study",
            "mrmc",
            "multi-reader",
            "multiple-reader",
            "multiple reader",
            "observer study",
            "standalone testing",
            "standalone performance",
            "clinical study",
            "clinical performance",
            "clinical validation",
            "performance goal",
            "acceptance criteria",
            "p-value",
            "p value",
            "p<",
            "p =",
            "statistical significance",
            # MRMC/Reader study specific
            "reader performance",
            "unaided",
            "aided",
            "with device",
            "without device",
            "with aid",
            "without aid",
            "effect size",
            "delta auc",
            "improvement",
            # CADx/CADe specific
            "cadx",
            "cade",
            "computer-aided",
            "computer aided",
            "diagnostic aid",
            "detection aid",
            "malignancy",
            "benign",
            "discrimination",
            "discriminability",
            "efficacy",
        ]

        # Expanded phrases for retry
        expanded_phrases = [
            "evaluation",
            "test results",
            "study results",
            "clinical evaluation",
            "retrospective study",
            "prospective study",
            "ground truth",
            "reference standard",
            "blinded",
            "unblinded",
            "multi-site",
            "multicenter",
            "single center",
            "cases",
            "patients",
            "subjects",
            "enrolled",
            "performance endpoint",
            "primary endpoint",
            "secondary endpoint",
            "non-inferior",
            "superiority",
            "equivalence",
            # Additional MRMC terms
            "radiologist",
            "pulmonologist",
            "reader",
            "clinician",
            "fully-crossed",
            "fully crossed",
            "per-reader",
            "per reader",
            "mean auc",
            "average auc",
            "area under",
        ]

        # Lines to exclude (FDA boilerplate)
        exclude_patterns = [
            "cdrh",
            "fda.gov",
            "http",
            "www.",
            "page",
            "figure",
            "appendix",
        ]

        # Use expanded phrases if retry mode
        search_phrases = (
            performance_phrases + expanded_phrases if expanded else performance_phrases
        )

        # Priority phrases - these are most likely to contain actual results
        # vs generic device descriptions
        high_priority_phrases = [
            "mrmc", "multi-reader", "multiple-reader", "reader study",
            "unaided", "aided", "delta auc", "effect size",
            "auc points", "auc improvement", "mean auc", "per-reader",
            "sensitivity was", "specificity was", "auc was", "accuracy was",
            "confidence interval", "95% ci", "p-value", "p <", "p=",
            "primary endpoint", "secondary endpoint",
            "pivotal study", "validation study",
        ]

        # Section headers that indicate high-value content
        # These are markdown headers (## or ###) that indicate performance sections
        performance_section_headers = [
            "clinical performance",
            "performance data",
            "performance testing",
            "performance results",
            "validation study",
            "clinical study",
            "pivotal study",
            "pilot study",
            "reader study",
            "mrmc study",
            "standalone testing",
            "standalone performance",
            "clinical validation",
            "efficacy",
            "performance characteristics",
            "acceptance criteria",
        ]

        lines = document_text.split("\n")

        # First, find section header lines and mark all content under them as high priority
        in_performance_section = False
        section_content_indices = set()

        for i, line in enumerate(lines):
            line_lower = line.lower().strip()
            # Check if this is a markdown header
            if line_lower.startswith("#"):
                header_text = line_lower.lstrip("#").strip()
                # Check if it's a performance-related header
                if any(header in header_text for header in performance_section_headers):
                    in_performance_section = True
                elif line_lower.startswith("##"):  # New major section resets
                    in_performance_section = False

            if in_performance_section:
                section_content_indices.add(i)

        # Track matches with priority scores
        matched_with_priority = {}  # index -> priority (higher = better)

        # Content under performance sections gets highest priority (3)
        for i in section_content_indices:
            matched_with_priority[i] = 3

        for i, line in enumerate(lines):
            line_lower = line.lower()

            # Skip excluded lines
            if any(pattern in line_lower for pattern in exclude_patterns):
                continue

            # Check for high priority phrases first
            is_high_priority = any(phrase in line_lower for phrase in high_priority_phrases)

            # Then check for regular search phrases
            if is_high_priority or any(phrase in line_lower for phrase in search_phrases):
                # Add this line plus context
                context_lines = 4 if expanded else 3
                start = max(0, i - context_lines)
                end = min(len(lines), i + context_lines + 1)

                priority = 2 if is_high_priority else 1
                for j in range(start, end):
                    if j not in matched_with_priority or matched_with_priority[j] < priority:
                        matched_with_priority[j] = priority

        # Sort by priority (high priority first), then by line number
        sorted_indices = sorted(matched_with_priority.keys(),
                                key=lambda x: (-matched_with_priority[x], x))

        # Build text from matched lines, prioritizing high-value content
        relevant_lines = []
        seen_indices = set()
        for i in sorted_indices:
            if i < len(lines) and i not in seen_indices:
                line = lines[i].strip()
                if line:  # Skip empty lines
                    relevant_lines.append(line)
                    seen_indices.add(i)

        relevant_text = "\n".join(relevant_lines)

        # Truncate if still too long
        # For MRMC/reader studies, allow more content since they have rich data
        has_mrmc_markers = any(
            phrase in document_text.lower()
            for phrase in ["mrmc", "multi-reader", "multiple-reader", "reader study",
                           "unaided", "aided", "delta auc", "effect size", "per-reader",
                           "clinical performance"]
        )
        max_length = 12000 if has_mrmc_markers else (8000 if expanded else 6000)

        if len(relevant_text) > max_length:
            relevant_text = relevant_text[:max_length] + "\n... (truncated)"

        return relevant_text

    async def _llm_extract_performance_data(
        self, content: str, client
    ) -> Optional[Dict]:
        """
        Call LLM to extract structured performance data from content.

        Args:
            content: Combined table and context content
            client: Open LLM client instance

        Returns:
            Dictionary with extracted performance data fields
        """
        prompt = self._build_extraction_prompt(content)

        messages = [
            LLMMessage(
                role="system",
                content=(
                    "You are an expert at extracting clinical validation and performance testing data "
                    "from FDA regulatory documents. Extract structured information about validation studies, "
                    "performance metrics, statistical measures, and study design. "
                    "Be precise and only extract information explicitly present in the content. "
                    "Convert percentages to proportions (e.g., 90.6% → 0.906)."
                ),
            ),
            LLMMessage(role="user", content=prompt),
        ]

        try:
            response = await client.complete_with_messages(
                messages=messages,
                temperature=0.0,  # Deterministic extraction
                response_format={"type": "json_object"},
                max_tokens=4096,  # Ensure enough room for complete JSON response
            )

            # Track token usage if available
            token_usage = None
            if hasattr(response, 'tokens') and response.tokens:
                token_usage = {
                    'prompt_tokens': response.tokens.prompt_tokens,
                    'completion_tokens': response.tokens.completion_tokens,
                    'total_tokens': response.tokens.total_tokens,
                    'estimated_cost': getattr(response.tokens, 'estimated_cost', None)
                }

            # Parse JSON response with repair attempt
            response_text = response.text
            try:
                result = json.loads(response_text)
            except json.JSONDecodeError as json_err:
                # Try to repair common JSON issues (e.g., truncated responses)
                repaired_text = self._repair_json(response_text)
                if repaired_text != response_text:
                    try:
                        result = json.loads(repaired_text)
                        if token_usage:
                            result['_token_usage'] = token_usage
                        return result
                    except json.JSONDecodeError:
                        raise json_err  # Re-raise original error
                else:
                    raise json_err

            # Attach token usage to result for tracking
            if token_usage:
                result['_token_usage'] = token_usage
            return result

        except Exception as e:
            # Log error and return None (graceful degradation)
            print(f"Error extracting performance data: {e}")
            return None

    def _repair_json(self, text: str) -> str:
        """Attempt to repair common JSON issues from LLM output.

        Handles:
        - Unterminated strings (missing closing quotes)
        - Truncated JSON (missing closing brackets) - common with token limits
        - Invalid escape sequences
        - Partial object/array entries cut off mid-value
        """
        import re as re_module

        repaired = text.rstrip()

        # Check for truncation - if JSON doesn't end properly
        # A valid JSON object ends with } or ]
        if not repaired.endswith('}') and not repaired.endswith(']'):
            # Check for balanced quotes first
            quote_count = len(re_module.findall(r'(?<!\\)"', repaired))
            if quote_count % 2 != 0:
                # Unbalanced quotes - close the string
                repaired = repaired + '"'

            # Find and remove incomplete trailing entries
            lines = repaired.split('\n')

            # Look backwards for the last complete line
            while lines:
                last_line = lines[-1].strip()

                # Skip empty lines
                if not last_line:
                    lines = lines[:-1]
                    continue

                # Check if this line is a complete JSON element
                # Complete patterns:
                # - Ends with } or ] (closing brace/bracket)
                # - Ends with ", (quoted string with comma)
                # - Ends with "} or "] (string at end of object/array)
                # - Ends with null, true, false (optionally with comma)
                # - Ends with a full number followed by comma: 123, or 1.5,
                # - Ends with a full number at end of line: 123 or 1.5 (no trailing partial)
                # Incomplete patterns to reject:
                # - Ends with just digits with decimal point: 64.  (incomplete float)
                # - Ends with colon: "key":
                # - Ends with open quote: "value": "
                if re_module.search(r'(}|]|",|"\]|"\}|null,?|true,?|false,?|\d+(\.\d+)?,?)\s*$', last_line):
                    # Check it's not a partial float like "64." or "3."
                    if re_module.search(r'\d+\.\s*$', last_line):
                        # Incomplete float - remove this line
                        lines = lines[:-1]
                        continue
                    # This looks like a complete line
                    break
                else:
                    # Incomplete line - remove it
                    lines = lines[:-1]

            if lines:
                repaired = '\n'.join(lines)

            # Remove trailing commas before we close brackets
            repaired = repaired.rstrip()
            if repaired.endswith(','):
                repaired = repaired[:-1]

        # Count and close unclosed brackets/braces
        open_braces = repaired.count('{') - repaired.count('}')
        open_brackets = repaired.count('[') - repaired.count(']')

        # Close arrays first, then objects
        for _ in range(max(0, open_brackets)):
            repaired += ']'
        for _ in range(max(0, open_braces)):
            repaired += '}'

        return repaired

    def _build_extraction_prompt(self, content: str) -> str:
        """Build LLM prompt for performance data extraction."""
        return f"""Extract clinical validation and performance testing data from the following FDA 510(k) content.

Content (tables and text):
{content}

**INSTRUCTIONS:**

## STEP 1: IDENTIFY VALIDATION STUDIES

Look for distinct validation studies in the document:
- **Pilot Study**: Preliminary feasibility/performance study
- **Pivotal Study**: Definitive regulatory validation study
- **Reader Study / MRMC**: Multi-reader multi-case study comparing reader performance WITH and WITHOUT device aid
- **Standalone Testing**: Device-only testing with ground truth (algorithm performance assessment)
- **Clinical Validation / Clinical Performance**: Clinical evaluation study
- **Retrospective Study**: Historical data analysis
- **Prospective Study**: Prospective data collection

**IMPORTANT FOR MRMC/READER STUDIES:**
- These studies compare reader performance UNAIDED vs AIDED by the device
- Look for terms like: "without aid", "with aid", "unaided", "aided", "before consulting", "after consulting"
- Extract AUC improvement (delta AUC, effect size) as a metric
- Extract individual reader results if available (per-reader AUC)
- num_readers should be the number of readers/clinicians who participated

For each study, extract:
- study_name: Name/title of the study
- study_type: One of [standalone, clinical_validation, reader_study, pivotal_study, pilot_study, retrospective, prospective, unknown]
- prospective: true/false/null
- blinding: "single_blind", "double_blind", "unblinded", or null
- num_readers: Number of readers (for MRMC studies)
- num_cases: Number of cases/subjects
- num_sites: Number of clinical sites
- data_source: Description of data sources
- acceptance_criteria: Performance goals/thresholds if stated
- acceptance_met: Whether criteria were met (true/false/null)

## STEP 2: EXTRACT PERFORMANCE METRICS

For each metric found (sensitivity, specificity, AUC, DICE, accuracy, PPV, NPV, delta AUC, effect size, etc.):
- metric_name: Exact name from document
- metric_type: Standardized type [sensitivity, specificity, auc, dice, accuracy, ppv, npv, f1_score, precision, recall, hausdorff_distance, time_to_detection, time_to_notification, other]
- value: Numeric value as PROPORTION (0-1), convert percentages (90.6% → 0.906)
- unit: Unit if applicable (e.g., "seconds", "mm")
- ci_lower: Lower bound of 95% CI (as proportion)
- ci_upper: Upper bound of 95% CI (as proportion)
- p_value: p-value if present
- sample_size: N or sample size
- stratification: Dict of stratification dimensions (e.g., {{"study": "pivotal", "gender": "female"}})
- source_table: Table ID if from a table

## STEP 3: EXTRACT PREDICATE COMPARISON (if present)

If the document compares performance to a predicate device:
- comparison_to_predicate: Description of comparison result (e.g., "Non-inferior", "Superior", "Equivalent")
- predicate_metrics: List of predicate device metrics (same format as performance_metrics)

## STEP 4: EXTRACT TEST DATASET CHARACTERISTICS

For validation datasets:
- dataset_name: Name/description
- dataset_size: Total number of cases/images
- multi_site: true/false
- num_sites: Number of sites
- ground_truth_method: How ground truth was established
- collection_period: Data collection timeframe
- patient_demographics: Age range, gender distribution, race/ethnicity distribution
- inclusion_criteria: Inclusion criteria
- exclusion_criteria: Exclusion criteria

Return JSON:
{{
  "has_performance_data": true/false,
  "validation_studies": [
    {{
      "study_name": "<string or null>",
      "study_type": "<study_type>",
      "study_description": "<brief description or null>",
      "prospective": <boolean or null>,
      "blinding": "<string or null>",
      "num_readers": <integer or null>,
      "num_cases": <integer or null>,
      "test_dataset": {{
        "dataset_name": "<string or null>",
        "dataset_size": <integer or null>,
        "data_source": "<string or null>",
        "multi_site": <boolean or null>,
        "num_sites": <integer or null>,
        "collection_period": "<string or null>",
        "ground_truth_method": "<string or null>",
        "patient_demographics": {{
          "age_range": "<string or null>",
          "gender_distribution": {{"male": <float 0-1>, "female": <float 0-1>}} or null,
          "race_ethnicity_distribution": {{...}} or null
        }},
        "inclusion_criteria": "<string or null>",
        "exclusion_criteria": "<string or null>",
        "independent_from_training": <boolean or null>
      }},
      "acceptance_criteria": "<string or null>",
      "acceptance_met": <boolean or null>
    }}
  ],
  "performance_metrics": [
    {{
      "metric_name": "<exact name>",
      "metric_type": "<standardized type>",
      "value": <float 0-1 or raw value>,
      "unit": "<string or null>",
      "ci_lower": <float or null>,
      "ci_upper": <float or null>,
      "p_value": <float or null>,
      "sample_size": <integer or null>,
      "stratification": {{"key": "value"}} or null,
      "source_table": "<table_id or null>"
    }}
  ],
  "comparison_to_predicate": "<string or null>",
  "predicate_metrics": [],
  "extraction_confidence": <float 0-100>,
  "source_tables": ["<table_id>", ...]
}}

**Decision Rules:**
- Set has_performance_data to TRUE if ANY performance metrics or validation studies are found
- Set has_performance_data to FALSE only if NO quantitative performance information present
- Convert ALL percentages to proportions (0-1 range)
- extraction_confidence < 30 if data is minimal or ambiguous
- extraction_confidence 30-70 if moderate detail present
- extraction_confidence > 70 if comprehensive performance data with CIs and study details

**Example Extraction:**
Text: "Sensitivity was 93.0% (95% CI: 90.2%-95.1%) in the pivotal study with 184 cases"
→ metric_name: "sensitivity", value: 0.930, ci_lower: 0.902, ci_upper: 0.951, sample_size: 184
"""

    def _build_performance_results_object(
        self,
        extracted_data: Dict,
        source_tables: List[Dict],
        product_code: Optional[str] = None,
    ) -> Optional[PerformanceTestResults]:
        """Build PerformanceTestResults object from extracted data."""
        if not extracted_data.get("has_performance_data", False):
            return None

        # Build validation studies
        validation_studies = []
        for study_data in extracted_data.get("validation_studies", []):
            study = self._build_validation_study(study_data)
            if study:
                validation_studies.append(study)

        # Build performance metrics
        performance_metrics = []
        for metric_data in extracted_data.get("performance_metrics", []):
            metric = self._build_performance_metric(metric_data, product_code)
            if metric:
                performance_metrics.append(metric)

        # Build predicate metrics
        predicate_metrics = []
        for metric_data in extracted_data.get("predicate_metrics", []):
            metric = self._build_performance_metric(metric_data, product_code)
            if metric:
                predicate_metrics.append(metric)

        # Extract legacy fields for backward compatibility
        legacy_sensitivity = None
        legacy_specificity = None
        legacy_auc = None
        legacy_test_size = None

        for metric in performance_metrics:
            if metric.metric_type == MetricType.SENSITIVITY and legacy_sensitivity is None:
                legacy_sensitivity = metric.value
            elif metric.metric_type == MetricType.SPECIFICITY and legacy_specificity is None:
                legacy_specificity = metric.value
            elif metric.metric_type == MetricType.AUC and legacy_auc is None:
                legacy_auc = metric.value

            # Get test dataset size from first validation study
            if legacy_test_size is None and validation_studies:
                for study in validation_studies:
                    if study.test_dataset and study.test_dataset.dataset_size:
                        legacy_test_size = study.test_dataset.dataset_size
                        break

        # Build PerformanceTestResults
        result = PerformanceTestResults(
            validation_studies=validation_studies,
            performance_metrics=performance_metrics,
            comparison_to_predicate=extracted_data.get("comparison_to_predicate"),
            predicate_metrics=predicate_metrics,
            # Legacy fields
            sensitivity=legacy_sensitivity,
            specificity=legacy_specificity,
            auc_roc=legacy_auc,
            test_dataset_size=legacy_test_size,
            # Extraction metadata
            extraction_confidence=extracted_data.get("extraction_confidence", 0.0),
            source_tables=extracted_data.get(
                "source_tables", [t.get("table_id", "unknown") for t in source_tables]
            ),
        )

        return result

    def _build_validation_study(self, study_data: Dict) -> Optional[ValidationStudy]:
        """Build ValidationStudy object from extracted data."""
        if not study_data:
            return None

        # Parse study type
        study_type_str = study_data.get("study_type", "unknown")
        try:
            study_type = StudyType(study_type_str.lower())
        except ValueError:
            study_type = StudyType.UNKNOWN

        # Build test dataset if present
        test_dataset = None
        dataset_data = study_data.get("test_dataset")
        if dataset_data and any(dataset_data.values()):
            test_dataset = self._build_test_dataset(dataset_data)

        return ValidationStudy(
            study_name=study_data.get("study_name"),
            study_type=study_type,
            study_description=study_data.get("study_description"),
            prospective=study_data.get("prospective"),
            blinding=study_data.get("blinding"),
            num_readers=study_data.get("num_readers"),
            num_cases=study_data.get("num_cases"),
            test_dataset=test_dataset,
            acceptance_criteria=study_data.get("acceptance_criteria"),
            acceptance_met=study_data.get("acceptance_met"),
            source_section=study_data.get("source_section"),
        )

    def _build_test_dataset(self, dataset_data: Dict) -> Optional[TestDataset]:
        """Build TestDataset object from extracted data."""
        if not dataset_data:
            return None

        # Build patient demographics if present
        patient_demographics = None
        demo_data = dataset_data.get("patient_demographics")
        if demo_data and any(v for v in demo_data.values() if v is not None):
            # Convert gender distribution if present
            gender_dist = demo_data.get("gender_distribution")
            if gender_dist and isinstance(gender_dist, dict):
                # Ensure values are floats 0-1
                gender_dist = {
                    k: float(v) if v is not None else None
                    for k, v in gender_dist.items()
                }

            race_dist = demo_data.get("race_ethnicity_distribution")
            if race_dist and isinstance(race_dist, dict):
                race_dist = {
                    k: float(v) if v is not None else None for k, v in race_dist.items()
                }

            patient_demographics = PatientDemographics(
                age_range=demo_data.get("age_range"),
                gender_distribution=gender_dist,
                race_ethnicity_distribution=race_dist,
            )

        return TestDataset(
            dataset_name=dataset_data.get("dataset_name"),
            dataset_size=dataset_data.get("dataset_size"),
            data_source=dataset_data.get("data_source"),
            multi_site=dataset_data.get("multi_site"),
            num_sites=dataset_data.get("num_sites"),
            collection_period=dataset_data.get("collection_period"),
            ground_truth_method=dataset_data.get("ground_truth_method"),
            imaging_modality=dataset_data.get("imaging_modality"),
            patient_demographics=patient_demographics,
            disease_prevalence=dataset_data.get("disease_prevalence"),
            inclusion_criteria=dataset_data.get("inclusion_criteria"),
            exclusion_criteria=dataset_data.get("exclusion_criteria"),
            independent_from_training=dataset_data.get("independent_from_training"),
        )

    def _build_performance_metric(
        self, metric_data: Dict, product_code: Optional[str] = None
    ) -> Optional[PerformanceMetric]:
        """Build PerformanceMetric object from extracted data."""
        if not metric_data or "value" not in metric_data:
            return None

        # Get metric name
        metric_name = metric_data.get("metric_name", "unknown")

        # Normalize metric type using domain knowledge if available
        metric_type = None
        metric_type_str = metric_data.get("metric_type")
        if metric_type_str:
            try:
                metric_type = MetricType(metric_type_str.lower())
            except ValueError:
                # Try domain knowledge normalization
                if DOMAIN_KNOWLEDGE_AVAILABLE:
                    dk = get_domain_knowledge()
                    normalized = dk.normalize_metric_type(metric_name)
                    if normalized:
                        try:
                            metric_type = MetricType(normalized)
                        except ValueError:
                            metric_type = MetricType.OTHER
                    else:
                        metric_type = MetricType.OTHER
                else:
                    metric_type = MetricType.OTHER

        # If no metric_type extracted, try to infer from name
        if metric_type is None:
            if DOMAIN_KNOWLEDGE_AVAILABLE:
                dk = get_domain_knowledge()
                normalized = dk.normalize_metric_type(metric_name)
                if normalized:
                    try:
                        metric_type = MetricType(normalized)
                    except ValueError:
                        metric_type = MetricType.OTHER
                else:
                    metric_type = MetricType.OTHER

        # Handle p-value which may be a string like "<0.0001" or "p<0.05"
        p_value_raw = metric_data.get("p_value")
        p_value = None
        if p_value_raw is not None:
            if isinstance(p_value_raw, (int, float)):
                p_value = float(p_value_raw)
            elif isinstance(p_value_raw, str):
                # Handle strings like "<0.0001", "p<0.05", "< .001", etc.
                cleaned = p_value_raw.lower().strip().replace("p", "").replace("<", "").replace(">", "").strip()
                try:
                    p_value = float(cleaned)
                except ValueError:
                    p_value = None  # Unable to parse, skip

        return PerformanceMetric(
            metric_name=metric_name,
            metric_type=metric_type,
            value=float(metric_data["value"]),
            unit=metric_data.get("unit"),
            ci_lower=metric_data.get("ci_lower"),
            ci_upper=metric_data.get("ci_upper"),
            p_value=p_value,
            sample_size=metric_data.get("sample_size"),
            stratification=metric_data.get("stratification"),
            source_table=metric_data.get("source_table"),
            source_section=metric_data.get("source_section"),
        )

    async def extract_from_text(
        self,
        text: str,
        client=None,
        debug: bool = False,
        product_code: Optional[str] = None,
        submission_type: Optional[str] = None,
    ) -> Optional[PerformanceTestResults]:
        """
        Extract performance data from free text (section content).

        Convenience method for extracting from section text without tables.
        Optionally uses domain knowledge to set appropriate expectations.

        Args:
            text: Free text content (e.g., Performance Verification section)
            client: Optional already-open LLM client. If not provided, opens a new session.
                    For batch processing, pass an open client to avoid rate limiting.
            debug: If True, print debug info about extracted context
            product_code: FDA product code (e.g., "POK", "QAS") for domain-specific hints
            submission_type: Submission type ("510k", "de_novo", "pma") for expectations

        Returns:
            PerformanceTestResults if performance data found, None otherwise.

        Example (single call):
            >>> performance_data = await extractor.extract_from_text(document_text)

        Example (with domain knowledge):
            >>> performance_data = await extractor.extract_from_text(
            ...     document_text,
            ...     product_code="POK",
            ...     submission_type="510k"
            ... )

        Example (batch processing - recommended):
            >>> async with extractor.llm_client as client:
            ...     for doc in documents:
            ...         data = await extractor.extract_from_text(doc.text, client=client)
        """
        # Use extract_performance_data with empty tables list
        return await self.extract_performance_data(
            performance_tables=[],
            document_text=text,
            product_code=product_code,
            submission_type=submission_type,
            client=client,
            debug=debug,
        )

    async def extract_from_tables(
        self,
        tables: List[Dict],
        client=None,
        debug: bool = False,
        product_code: Optional[str] = None,
        submission_type: Optional[str] = None,
    ) -> Optional[PerformanceTestResults]:
        """
        Extract performance data from classified tables.

        Convenience method for extracting from tables without additional text.

        Args:
            tables: List of tables with keys: table_id, caption, markdown
            client: Optional already-open LLM client
            debug: If True, print debug info
            product_code: FDA product code for domain-specific hints
            submission_type: Submission type for expectations

        Returns:
            PerformanceTestResults if performance data found, None otherwise.

        Example:
            >>> tables = [
            ...     {'table_id': 'table_18', 'caption': 'Sensitivity Analysis', 'markdown': '...'}
            ... ]
            >>> performance_data = await extractor.extract_from_tables(tables)
        """
        return await self.extract_performance_data(
            performance_tables=tables,
            document_text=None,
            product_code=product_code,
            submission_type=submission_type,
            client=client,
            debug=debug,
        )
