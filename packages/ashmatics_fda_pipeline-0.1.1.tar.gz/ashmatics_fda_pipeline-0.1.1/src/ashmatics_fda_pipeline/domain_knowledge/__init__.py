# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Domain knowledge module for FDA regulatory document extraction.

This module provides two complementary knowledge systems:

1. DomainKnowledge (ai_device_expectations.yaml)
   - WHAT to expect from device types
   - Product code expectations, metric normalization, confidence adjustments
   - Device archetypes and extraction hints

2. DocumentPatternLoader (510k_summary_document_patterns.yaml, de_novo_document_patterns.yaml)
   - HOW documents are structured
   - Section patterns, table patterns, form detection
   - Document type classification

Phase 2E Enhancement (2025-11-25):
- Added performance data extraction methods
- Added expected metrics by product code
- Added study type detection helpers
- Added metric type normalization

Phase 2F Enhancement (2025-11-28):
- Added DocumentPatternLoader for document structure patterns
- Separated device knowledge from document format knowledge
- Consolidated metric patterns as single source of truth

Usage:
    >>> from ashmatics_fda_pipeline.domain_knowledge import DomainKnowledge, DocumentPatternLoader
    >>>
    >>> # Device knowledge - what to expect from device types
    >>> dk = DomainKnowledge()
    >>> expectations = dk.get_product_expectations("QAS")
    >>> metric_type = dk.normalize_metric_type("PPV")  # Returns 'ppv'
    >>>
    >>> # Document patterns - how documents are structured
    >>> dp = DocumentPatternLoader()
    >>> doc_type, confidence = dp.detect_document_type(content)
    >>> ifu_patterns = dp.get_ifu_extraction_patterns()
    >>> section_patterns = dp.get_section_patterns("510k", "device_description")
"""

import yaml
from pathlib import Path
from typing import Dict, List, Optional, Any


class DomainKnowledge:
    """
    Loader and accessor for AI/ML device domain knowledge.

    Caches YAML on first load for efficiency.
    """

    _instance = None
    _knowledge: Dict = None

    def __new__(cls):
        """Singleton pattern - load YAML once."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._load_knowledge()
        return cls._instance

    def _load_knowledge(self):
        """Load domain knowledge from YAML file."""
        yaml_path = Path(__file__).parent / "ai_device_expectations.yaml"
        if yaml_path.exists():
            with open(yaml_path, 'r') as f:
                self._knowledge = yaml.safe_load(f)
        else:
            self._knowledge = {}

    def get_product_expectations(self, product_code: str) -> Optional[Dict]:
        """
        Get expectations for a specific product code.

        Args:
            product_code: FDA product code (e.g., "QAS", "POK")

        Returns:
            Dict with training_data, performance_data expectations, or None
        """
        if not self._knowledge:
            return None
        return self._knowledge.get('product_codes', {}).get(product_code.upper())

    def get_submission_expectations(self, submission_type: str) -> Optional[Dict]:
        """
        Get expectations for a submission type.

        Args:
            submission_type: "de_novo", "510k", or "pma"

        Returns:
            Dict with training_data, performance_data expectations
        """
        if not self._knowledge:
            return None
        return self._knowledge.get('submission_types', {}).get(submission_type.lower())

    def get_extraction_hints(
        self,
        product_code: Optional[str] = None,
        submission_type: Optional[str] = None,
        extraction_type: str = "training_data"
    ) -> List[str]:
        """
        Get LLM prompt hints for extraction.

        Combines hints from product code, submission type, and general section hints.

        Args:
            product_code: FDA product code (optional)
            submission_type: Submission type (optional)
            extraction_type: "training_data" or "validation_data"

        Returns:
            List of hint strings to inject into LLM prompt
        """
        hints = []

        # Product-specific hints
        if product_code:
            product = self.get_product_expectations(product_code)
            if product and extraction_type in product:
                product_hints = product[extraction_type].get('extraction_hints', [])
                hints.extend(product_hints)

        # Submission-type hints
        if submission_type:
            submission = self.get_submission_expectations(submission_type)
            if submission:
                submission_hints = submission.get('extraction_hints', [])
                hints.extend(submission_hints)

        # General section hints
        if self._knowledge:
            section_hints = self._knowledge.get('section_hints', {}).get(extraction_type, {})
            # Add distinguishing phrases as hints
            not_training = section_hints.get('not_training', [])
            if not_training and extraction_type == 'training_data':
                hints.append(f"IGNORE sections about: {', '.join(not_training[:5])}")

        return hints

    def get_expected_level(
        self,
        product_code: Optional[str] = None,
        submission_type: Optional[str] = None,
        extraction_type: str = "training_data"
    ) -> str:
        """
        Get expected detail level for extraction.

        Args:
            product_code: FDA product code
            submission_type: Submission type
            extraction_type: "training_data" or "performance_data"

        Returns:
            "detailed", "moderate", "minimal", "none", or "varies"
        """
        # Product code takes precedence
        if product_code:
            product = self.get_product_expectations(product_code)
            if product and extraction_type in product:
                return product[extraction_type].get('expected_level', 'varies')

        # Fall back to submission type
        if submission_type:
            submission = self.get_submission_expectations(submission_type)
            if submission and extraction_type in submission:
                return submission[extraction_type].get('expected_level', 'varies')

        return 'varies'

    def get_confidence_adjustment(
        self,
        product_code: Optional[str] = None,
        submission_type: Optional[str] = None,
        extraction_type: str = "training_data"
    ) -> int:
        """
        Get confidence score adjustment based on device context.

        Product code adjustments take precedence over submission type.
        Adjustments are NOT additive - we use the more specific one.

        Confidence adjustments by product code:
        - CADe/CADx codes (POK, MYN, QDQ, QBS): +25
        - Triage with CADe (QAS), General AI (QIH): +20
        - Radiation/CV/GI codes (QKB, QFM, MUJ, DQK, SDJ, QNP): +15
        - Minimal expectation codes (IYN, LNH, JAK): 0

        Confidence adjustments by submission type (if no product code):
        - De Novo: +15
        - PMA: +20
        - 510(k): 0

        Args:
            product_code: FDA product code
            submission_type: Submission type
            extraction_type: "training_data"

        Returns:
            Integer adjustment to add to confidence score
        """
        # Product code takes precedence (more specific)
        if product_code:
            product = self.get_product_expectations(product_code)
            if product and extraction_type in product:
                product_adj = product[extraction_type].get('confidence_adjustment')
                if product_adj is not None:
                    return product_adj

        # Fall back to submission type adjustment
        if submission_type:
            submission = self.get_submission_expectations(submission_type)
            if submission and extraction_type in submission:
                return submission[extraction_type].get('confidence_adjustment', 0)

        return 0

    def is_missing_notable(
        self,
        product_code: Optional[str] = None,
        submission_type: Optional[str] = None,
        extraction_type: str = "training_data"
    ) -> bool:
        """
        Check if missing data should be flagged as notable.

        For De Novo or CADx devices, missing training data is unusual.
        For triage/notification devices, it's expected.

        Returns:
            True if missing data should be flagged
        """
        # Check product code first
        if product_code:
            product = self.get_product_expectations(product_code)
            if product and extraction_type in product:
                return product[extraction_type].get('missing_is_notable', False)

        # Check submission type
        if submission_type:
            submission = self.get_submission_expectations(submission_type)
            if submission and extraction_type in submission:
                return submission[extraction_type].get('missing_is_notable', False)

        return False

    def format_context_for_llm(
        self,
        product_code: Optional[str] = None,
        submission_type: Optional[str] = None,
        extraction_type: str = "training_data"
    ) -> str:
        """
        Format domain knowledge as compact context for LLM prompt.

        Args:
            product_code: FDA product code
            submission_type: Submission type
            extraction_type: Type of extraction

        Returns:
            Formatted string to prepend to LLM prompt
        """
        parts = []

        # Add device context
        if product_code:
            product = self.get_product_expectations(product_code)
            if product:
                parts.append(f"Device Type: {product.get('name', product_code)}")
                parts.append(f"Clinical Domain: {product.get('clinical_domain', 'unknown')}")
                expected = self.get_expected_level(product_code, extraction_type=extraction_type)
                parts.append(f"Expected {extraction_type} detail: {expected}")

        # Add submission context
        if submission_type:
            submission = self.get_submission_expectations(submission_type)
            if submission:
                parts.append(f"Submission: {submission_type.upper()} - {submission.get('description', '')}")

        # Add hints
        hints = self.get_extraction_hints(product_code, submission_type, extraction_type)
        if hints:
            parts.append("Extraction hints:")
            for hint in hints[:3]:  # Limit to top 3 hints
                parts.append(f"  - {hint}")

        if parts:
            return "## Device Context\n" + "\n".join(parts) + "\n"
        return ""

    # =========================================================================
    # Phase 2E: Performance Data Methods
    # =========================================================================

    def get_performance_expectations(
        self,
        product_code: Optional[str] = None,
        submission_type: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get performance data expectations for a device.

        Args:
            product_code: FDA product code (e.g., "QDQ", "POK", "SEZ")
            submission_type: Submission type (e.g., "510k", "de_novo")

        Returns:
            Dict with performance_data expectations including:
            - expected_study_types: List of expected study types
            - expected_metrics: Dict of primary/secondary metrics
            - acceptance_criteria_patterns: Common acceptance criteria
            - predicate_comparison_expected: bool
            - confidence_intervals_expected: bool
            - subgroup_analysis_fields: List of stratification dimensions
        """
        result = {}

        # Product code takes precedence
        if product_code:
            product = self.get_product_expectations(product_code)
            if product and 'performance_data' in product:
                result = product['performance_data'].copy()

        # Merge with submission type expectations if not fully specified
        if submission_type:
            submission = self.get_submission_expectations(submission_type)
            if submission and 'performance_data' in submission:
                for key, value in submission['performance_data'].items():
                    if key not in result:
                        result[key] = value

        return result

    def get_expected_metrics(
        self,
        product_code: Optional[str] = None,
        submission_type: Optional[str] = None,
        metric_category: str = "primary"
    ) -> List[str]:
        """
        Get expected performance metrics for a device.

        Args:
            product_code: FDA product code
            submission_type: Submission type
            metric_category: "primary", "secondary", "all", or specific category

        Returns:
            List of expected metric names
        """
        perf_exp = self.get_performance_expectations(product_code, submission_type)
        expected_metrics = perf_exp.get('expected_metrics', {})

        if metric_category == "all":
            # Flatten all metric categories
            all_metrics = []
            if isinstance(expected_metrics, dict):
                for metrics in expected_metrics.values():
                    if isinstance(metrics, list):
                        all_metrics.extend(metrics)
            elif isinstance(expected_metrics, list):
                all_metrics = expected_metrics
            return list(set(all_metrics))
        elif isinstance(expected_metrics, dict):
            return expected_metrics.get(metric_category, [])
        elif isinstance(expected_metrics, list):
            return expected_metrics
        return []

    def get_expected_study_types(
        self,
        product_code: Optional[str] = None,
        submission_type: Optional[str] = None
    ) -> List[str]:
        """
        Get expected validation study types for a device.

        Args:
            product_code: FDA product code
            submission_type: Submission type

        Returns:
            List of expected study types (e.g., ["standalone", "reader_study", "pivotal_study"])
        """
        perf_exp = self.get_performance_expectations(product_code, submission_type)
        return perf_exp.get('expected_study_types', [])

    def get_subgroup_analysis_fields(
        self,
        product_code: Optional[str] = None,
        submission_type: Optional[str] = None
    ) -> List[str]:
        """
        Get expected stratification/subgroup analysis fields.

        Args:
            product_code: FDA product code
            submission_type: Submission type

        Returns:
            List of stratification fields (e.g., ["breast_density", "age_group", "race_ethnicity"])
        """
        perf_exp = self.get_performance_expectations(product_code, submission_type)
        return perf_exp.get('subgroup_analysis_fields', [])

    def normalize_metric_type(self, metric_name: str) -> Optional[str]:
        """
        Normalize a metric name to a standard MetricType enum value.

        Uses metric_type_mapping from the YAML to map aliases to standard types.

        Args:
            metric_name: Raw metric name from document (e.g., "PPV", "Dice coefficient", "AUC")

        Returns:
            Standard metric type (e.g., "ppv", "dice", "auc") or None if not recognized
        """
        if not self._knowledge:
            return None

        metric_mapping = self._knowledge.get('metric_type_mapping', {})
        metric_lower = metric_name.lower().strip()

        for standard_type, config in metric_mapping.items():
            aliases = config.get('aliases', [])
            for alias in aliases:
                if alias.lower() == metric_lower or alias.lower() in metric_lower:
                    return config.get('standard_type', standard_type)

        # If not found in mapping, return the lowercased name with underscores
        return metric_lower.replace(' ', '_').replace('-', '_')

    def get_performance_extraction_hints(
        self,
        product_code: Optional[str] = None,
        submission_type: Optional[str] = None
    ) -> List[str]:
        """
        Get hints for performance data extraction.

        Combines product-specific, submission-specific, and general hints.

        Args:
            product_code: FDA product code
            submission_type: Submission type

        Returns:
            List of extraction hints for LLM prompt
        """
        hints = []

        # Product-specific performance hints
        if product_code:
            product = self.get_product_expectations(product_code)
            if product and 'performance_data' in product:
                perf_hints = product['performance_data'].get('extraction_hints', [])
                hints.extend(perf_hints)

        # Submission-type performance hints
        if submission_type:
            submission = self.get_submission_expectations(submission_type)
            if submission and 'performance_data' in submission:
                sub_hints = submission['performance_data'].get('extraction_hints', [])
                hints.extend(sub_hints)

        # General performance extraction hints
        if self._knowledge:
            section_hints = self._knowledge.get('section_hints', {}).get('performance_data', {})
            table_hints = section_hints.get('table_extraction_hints', [])
            hints.extend(table_hints)

        return hints

    def get_metric_extraction_patterns(self) -> Dict[str, List[str]]:
        """
        Get regex/text patterns for metric extraction.

        Returns:
            Dict mapping metric types to extraction patterns
        """
        if not self._knowledge:
            return {}
        return self._knowledge.get('section_hints', {}).get('performance_data', {}).get('metric_extraction_patterns', {})

    def get_ci_patterns(self) -> List[str]:
        """
        Get patterns for confidence interval extraction.

        Returns:
            List of CI format patterns
        """
        if not self._knowledge:
            return []
        return self._knowledge.get('section_hints', {}).get('performance_data', {}).get('confidence_interval_patterns', [])

    def get_study_type_indicators(self) -> Dict[str, List[str]]:
        """
        Get text indicators for study type classification.

        Returns:
            Dict mapping study types to indicator phrases
        """
        if not self._knowledge:
            return {}
        return self._knowledge.get('section_hints', {}).get('performance_data', {}).get('study_type_indicators', {})

    def format_performance_context_for_llm(
        self,
        product_code: Optional[str] = None,
        submission_type: Optional[str] = None
    ) -> str:
        """
        Format performance data context for LLM extraction prompt.

        Args:
            product_code: FDA product code
            submission_type: Submission type

        Returns:
            Formatted context string for LLM prompt
        """
        parts = ["## Performance Data Extraction Context"]

        # Device context
        if product_code:
            product = self.get_product_expectations(product_code)
            if product:
                parts.append(f"\nDevice: {product.get('name', product_code)}")
                parts.append(f"Clinical Domain: {product.get('clinical_domain', 'unknown')}")
                parts.append(f"Typical Use: {product.get('typical_use', 'unknown')}")

        # Expected metrics
        expected_metrics = self.get_expected_metrics(product_code, submission_type, "primary")
        if expected_metrics:
            parts.append(f"\nExpected Primary Metrics: {', '.join(expected_metrics)}")

        # Expected study types
        study_types = self.get_expected_study_types(product_code, submission_type)
        if study_types:
            parts.append(f"Expected Study Types: {', '.join(study_types)}")

        # Subgroup analysis fields
        subgroups = self.get_subgroup_analysis_fields(product_code, submission_type)
        if subgroups:
            parts.append(f"Expected Stratification: {', '.join(subgroups[:5])}")

        # Predicate comparison expected?
        perf_exp = self.get_performance_expectations(product_code, submission_type)
        if perf_exp.get('predicate_comparison_expected'):
            parts.append("Predicate Comparison: Expected (this is a 510(k))")

        # Add extraction hints
        hints = self.get_performance_extraction_hints(product_code, submission_type)
        if hints:
            parts.append("\nExtraction Hints:")
            for hint in hints[:4]:  # Limit to top 4
                parts.append(f"  - {hint}")

        return "\n".join(parts) + "\n"


# Convenience function
def get_domain_knowledge() -> DomainKnowledge:
    """Get singleton DomainKnowledge instance."""
    return DomainKnowledge()


# Import DocumentPatternLoader for document structure patterns
from .document_patterns import DocumentPatternLoader, get_document_patterns

__all__ = [
    "DomainKnowledge",
    "get_domain_knowledge",
    "DocumentPatternLoader",
    "get_document_patterns",
]