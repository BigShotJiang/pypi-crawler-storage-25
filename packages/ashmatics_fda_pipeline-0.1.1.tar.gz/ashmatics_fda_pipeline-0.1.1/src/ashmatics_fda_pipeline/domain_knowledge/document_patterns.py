# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Document Pattern Loader for FDA regulatory documents.

Provides document-type-specific parsing patterns for 510(k) and De Novo documents.
This complements the DomainKnowledge class (which provides device expectations)
with document structure knowledge (format patterns).

The separation of concerns:
- DomainKnowledge (ai_device_expectations.yaml) -> WHAT to expect from device types
- DocumentPatternLoader (this module) -> HOW documents are structured

Phase 2F Enhancement (2025-11-28):
- Created as part of ASHKBAPP-43 parser optimization
- Loads 510k_summary_document_patterns.yaml and de_novo_document_patterns.yaml
- Provides section patterns, table patterns, and detection patterns

Usage:
    >>> from fda_510k_pipeline.domain_knowledge import DocumentPatternLoader
    >>> patterns = DocumentPatternLoader()
    >>>
    >>> # Get 510(k) document patterns
    >>> k_patterns = patterns.get_510k_patterns()
    >>>
    >>> # Get section header patterns for a specific section
    >>> ifu_patterns = patterns.get_section_patterns("510k", "indications_for_use")
    >>>
    >>> # Detect document type from content
    >>> doc_type = patterns.detect_document_type(markdown_content)
"""

import re
import yaml
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple

logger = logging.getLogger(__name__)


class DocumentPatternLoader:
    """
    Loader for document-type-specific parsing patterns.

    Complements DomainKnowledge (device expectations) with
    document structure knowledge (format patterns).

    Singleton pattern - loads YAMLs once on first instantiation.
    """

    _instance = None
    _510k_patterns: Optional[Dict] = None
    _denovo_patterns: Optional[Dict] = None

    def __new__(cls):
        """Singleton pattern - load YAMLs once."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._load_patterns()
        return cls._instance

    def _load_patterns(self) -> None:
        """Load document pattern YAML files."""
        base_path = Path(__file__).parent

        # Load 510(k) patterns
        k510_path = base_path / "510k_summary_document_patterns.yaml"
        if k510_path.exists():
            try:
                with open(k510_path, "r") as f:
                    self._510k_patterns = yaml.safe_load(f)
                logger.debug(f"Loaded 510(k) patterns from {k510_path}")
            except Exception as e:
                logger.error(f"Failed to load 510(k) patterns: {e}")
                self._510k_patterns = {}
        else:
            logger.warning(f"510(k) patterns file not found: {k510_path}")
            self._510k_patterns = {}

        # Load De Novo patterns
        denovo_path = base_path / "de_novo_document_patterns.yaml"
        if denovo_path.exists():
            try:
                with open(denovo_path, "r") as f:
                    self._denovo_patterns = yaml.safe_load(f)
                logger.debug(f"Loaded De Novo patterns from {denovo_path}")
            except Exception as e:
                logger.error(f"Failed to load De Novo patterns: {e}")
                self._denovo_patterns = {}
        else:
            logger.warning(f"De Novo patterns file not found: {denovo_path}")
            self._denovo_patterns = {}

    # =========================================================================
    # Pattern Accessors
    # =========================================================================

    def get_510k_patterns(self) -> Dict:
        """
        Get all 510(k) document patterns.

        Returns:
            Dict containing complete 510(k) pattern configuration
        """
        return self._510k_patterns or {}

    def get_denovo_patterns(self) -> Dict:
        """
        Get all De Novo document patterns.

        Returns:
            Dict containing complete De Novo pattern configuration
        """
        return self._denovo_patterns or {}

    def get_patterns_for_type(self, doc_type: str) -> Dict:
        """
        Get patterns for a specific document type.

        Args:
            doc_type: "510k", "de_novo", or "denovo"

        Returns:
            Dict containing pattern configuration for the document type
        """
        doc_type_lower = doc_type.lower().replace("-", "_").replace(" ", "_")
        if doc_type_lower in ("510k", "510_k", "k"):
            return self.get_510k_patterns()
        elif doc_type_lower in ("de_novo", "denovo", "den"):
            return self.get_denovo_patterns()
        else:
            logger.warning(f"Unknown document type: {doc_type}")
            return {}

    # =========================================================================
    # Section Pattern Accessors
    # =========================================================================

    def get_section_patterns(self, doc_type: str, section_name: str) -> Dict:
        """
        Get patterns for a specific section within a document type.

        Args:
            doc_type: "510k" or "de_novo"
            section_name: Section name (e.g., "indications_for_use", "device_description")

        Returns:
            Dict containing section-specific patterns including header_patterns,
            extraction rules, and semantic_fields
        """
        patterns = self.get_patterns_for_type(doc_type)

        # Try different locations for section patterns
        # 510(k) has sections under manufacturer_summary.sections
        # De Novo has sections directly under sections
        if doc_type.lower() in ("510k", "510_k"):
            sections = patterns.get("manufacturer_summary", {}).get("sections", {})
        else:
            sections = patterns.get("sections", {})

        section_key = section_name.lower().replace(" ", "_").replace("-", "_")
        return sections.get(section_key, {})

    def get_section_header_patterns(
        self, doc_type: str, section_name: str
    ) -> List[str]:
        """
        Get header patterns (regexes) for detecting a section.

        Args:
            doc_type: "510k" or "de_novo"
            section_name: Section name

        Returns:
            List of regex pattern strings for matching section headers
        """
        section = self.get_section_patterns(doc_type, section_name)
        patterns = section.get("header_patterns", [])

        # Extract regex values if patterns are dicts
        result = []
        for p in patterns:
            if isinstance(p, dict) and "regex" in p:
                result.append(p["regex"])
            elif isinstance(p, str):
                result.append(p)
        return result

    def get_all_section_names(self, doc_type: str) -> List[str]:
        """
        Get list of all section names defined for a document type.

        Args:
            doc_type: "510k" or "de_novo"

        Returns:
            List of section names in document order
        """
        patterns = self.get_patterns_for_type(doc_type)

        if doc_type.lower() in ("510k", "510_k"):
            sections = patterns.get("manufacturer_summary", {}).get("sections", {})
        else:
            sections = patterns.get("sections", {})

        # Sort by order field if present
        section_list = []
        for name, config in sections.items():
            order = config.get("order", 999)
            section_list.append((order, name))

        section_list.sort(key=lambda x: x[0])
        return [name for _, name in section_list]

    # =========================================================================
    # Table Pattern Accessors
    # =========================================================================

    def get_table_patterns(self, doc_type: str, table_type: str = None) -> Dict:
        """
        Get table extraction patterns for a document type.

        Args:
            doc_type: "510k" or "de_novo"
            table_type: Optional specific table type (e.g., "comparison_table",
                       "performance_results_table", "demographics_table")

        Returns:
            Dict containing table patterns. If table_type specified, returns
            patterns for that specific table type.
        """
        patterns = self.get_patterns_for_type(doc_type)
        table_patterns = patterns.get("table_patterns", {})

        if table_type:
            table_key = table_type.lower().replace(" ", "_").replace("-", "_")
            return table_patterns.get(table_key, {})
        return table_patterns

    # =========================================================================
    # Document Type Detection
    # =========================================================================

    def get_detection_patterns(self, doc_type: str) -> List[str]:
        """
        Get patterns for detecting a document type.

        Args:
            doc_type: "510k" or "de_novo"

        Returns:
            List of regex patterns that indicate this document type
        """
        patterns = self.get_patterns_for_type(doc_type)

        detection_patterns = []

        # 510(k) detection patterns
        if doc_type.lower() in ("510k", "510_k"):
            # FDA clearance letter patterns
            fda_letter = patterns.get("fda_clearance_letter", {}).get("detection", {})
            detection_patterns.extend(
                self._extract_regex_list(fda_letter.get("patterns", []))
            )

            # OMB form patterns
            omb_form = patterns.get("omb_ifu_form", {}).get("detection", {})
            detection_patterns.extend(
                self._extract_regex_list(omb_form.get("patterns", []))
            )

            # Manufacturer summary patterns
            mfr_summary = patterns.get("manufacturer_summary", {}).get("detection", {})
            detection_patterns.extend(
                self._extract_regex_list(mfr_summary.get("patterns", []))
            )

        # De Novo detection patterns
        else:
            doc_structure = patterns.get("document_structure", {})
            for format_key in ("format_a", "format_b"):
                format_config = doc_structure.get("formats", {}).get(format_key, {})
                detection_patterns.extend(format_config.get("detection_patterns", []))

        return detection_patterns

    def detect_document_type(self, content: str) -> Tuple[str, float]:
        """
        Detect the document type from content.

        Args:
            content: Document text content (markdown or plain text)

        Returns:
            Tuple of (document_type, confidence_score) where document_type
            is "510k", "de_novo", or "unknown"
        """
        # Get detection patterns for each type
        k510_patterns = self.get_detection_patterns("510k")
        denovo_patterns = self.get_detection_patterns("de_novo")

        # Count matches
        k510_matches = self._count_pattern_matches(content, k510_patterns)
        denovo_matches = self._count_pattern_matches(content, denovo_patterns)

        # Calculate scores
        k510_score = k510_matches / max(len(k510_patterns), 1)
        denovo_score = denovo_matches / max(len(denovo_patterns), 1)

        # Also check for explicit identifiers
        if re.search(r"K\d{6}", content):
            k510_score += 0.3
        if re.search(r"DEN\d{6}", content):
            denovo_score += 0.3

        # Determine type
        if k510_score > denovo_score and k510_score > 0.1:
            return ("510k", min(k510_score, 1.0))
        elif denovo_score > k510_score and denovo_score > 0.1:
            return ("de_novo", min(denovo_score, 1.0))
        else:
            return ("unknown", 0.0)

    def _count_pattern_matches(self, content: str, patterns: List[str]) -> int:
        """Count how many patterns match in the content."""
        matches = 0
        for pattern in patterns:
            try:
                if re.search(pattern, content, re.IGNORECASE | re.MULTILINE):
                    matches += 1
            except re.error:
                # Invalid regex pattern
                continue
        return matches

    def _extract_regex_list(self, patterns: List) -> List[str]:
        """Extract regex strings from a list of patterns (may be dicts or strings)."""
        result = []
        for p in patterns:
            if isinstance(p, dict) and "regex" in p:
                result.append(p["regex"])
            elif isinstance(p, str):
                result.append(p)
        return result

    # =========================================================================
    # Form 3881 (OMB IFU Form) Patterns - 510(k) specific
    # =========================================================================

    def get_form3881_patterns(self) -> Dict:
        """
        Get patterns for FDA Form 3881 (Indications for Use form).

        Returns:
            Dict containing form detection patterns, field patterns, and
            extraction rules for the standardized OMB form.
        """
        patterns = self.get_510k_patterns()
        return patterns.get("omb_ifu_form", {})

    def get_ifu_extraction_patterns(self) -> Dict:
        """
        Get patterns specifically for extracting Indications for Use.

        NOTE: "Intended Use" is often a parent section or synonym for "Indications for Use".
        In FDA Form 3881, the field is labeled "Indications for Use (Describe)".
        Some sponsors include "Intended Use:" as a sub-heading within the IFU box.

        Returns:
            Dict with patterns from multiple sources (in priority order):
            - form3881: OMB form patterns (AUTHORITATIVE source)
            - section: Section header patterns from manufacturer summary
            - content: Content-based detection patterns (fallback)
            - extraction_priority: Recommended order of extraction strategies
        """
        result = {
            "form3881": {},
            "section": [],
            "content": [],
            "extraction_priority": [
                "form3881",  # FDA Form 3881 is authoritative source
                "section",   # Manufacturer summary sections
                "content",   # Content pattern matching (fallback)
            ],
            "notes": {
                "intended_use_relationship": (
                    "'Intended Use' is often synonymous with or a subset of 'Indications for Use'. "
                    "When extracting, check for 'Intended Use:' as a sub-heading within IFU content."
                ),
                "historical_forms": (
                    "Older FDA forms (pre-2017) may use different field labels. "
                    "Look for 'Intended Use (Describe)' as an alternative."
                ),
            },
            # Definitions for LLM context/validation
            "definitions": {
                "intended_use": (
                    "What you claim on your label that the device does."
                ),
                "indications_for_use": (
                    "The circumstances or conditions under which the device will be used, "
                    "i.e. the reasons you would use the device."
                ),
                "contraindications": (
                    "What the device should NOT be used for. May appear as a separate "
                    "paragraph within IFU or as its own section."
                ),
            },
            # Expected IFU content elements
            "ifu_content_elements": [
                "Patient population (age, disease state, clinical presentation)",
                "Clinical context/setting (hospital, clinic, point-of-care)",
                "Imaging/equipment context (e.g., CT scanner types, MRI field strength)",
                "Intended clinical outcome (detection, diagnosis, triage, treatment planning)",
            ],
        }

        # Form 3881 patterns from OMB IFU form (AUTHORITATIVE)
        form_patterns = self.get_form3881_patterns()
        result["form3881"] = form_patterns.get("form_fields", {}).get(
            "indications_for_use", {}
        )

        # Section header patterns from 510(k)
        # Try intended_use section (which includes IFU patterns)
        section_patterns = self.get_section_header_patterns("510k", "intended_use")
        result["section"].extend(section_patterns)

        # Also try indications_for_use directly
        ifu_patterns = self.get_section_header_patterns("510k", "indications_for_use")
        result["section"].extend(ifu_patterns)

        # Section header patterns from De Novo
        denovo_ifu = self.get_section_header_patterns("de_novo", "indications_for_use")
        result["section"].extend(denovo_ifu)

        # Add fallback patterns if nothing found from YAML
        if not result["section"]:
            result["section"] = [
                r"^(?:V\.?\s*)?Intended Use(?:/Indications? for Use)?:?",
                r"^(?:\d+\.\d+\.?\s*)?Intended Use:?",
                r"^Indications? for Use:?",
                r"^(?:\d+\.\d+\.?\s*)?Indications for Use(?:\s+statement)?:?",
                r"Indications for Use \(Describe\)",
                r"Intended Use \(Describe\)",
            ]

        # Content patterns (phrases that indicate IFU content) - for fallback extraction
        result["content"] = [
            r"(?:is|are)\s+indicated\s+for",
            r"intended\s+to\s+(?:be\s+)?used?\s+for",
            r"intended\s+use",
            r"for\s+use\s+(?:in|by|with)",
            r"The\s+device\s+is\s+intended",
            r"for\s+the\s+(?:detection|diagnosis|treatment|monitoring)\s+of",
        ]

        return result

    # =========================================================================
    # Figure Patterns - primarily De Novo
    # =========================================================================

    def get_figure_patterns(self, doc_type: str = "de_novo") -> Dict:
        """
        Get figure extraction patterns.

        Args:
            doc_type: Document type (De Novo has more comprehensive figure patterns)

        Returns:
            Dict containing figure detection patterns and semantic type definitions
        """
        patterns = self.get_patterns_for_type(doc_type)
        return patterns.get("figure_patterns", {})

    # =========================================================================
    # Validation Rules
    # =========================================================================

    def get_validation_rules(self, doc_type: str) -> Dict:
        """
        Get validation rules for a document type.

        Args:
            doc_type: "510k" or "de_novo"

        Returns:
            Dict containing required_fields, cross_validation rules,
            and completeness_checks
        """
        patterns = self.get_patterns_for_type(doc_type)
        return patterns.get("validation_rules", {})

    def get_required_fields(self, doc_type: str) -> List[str]:
        """
        Get list of required fields for a document type.

        Args:
            doc_type: "510k" or "de_novo"

        Returns:
            List of field names that must be present
        """
        rules = self.get_validation_rules(doc_type)
        return rules.get("required_fields", [])

    # =========================================================================
    # Confidence Scoring
    # =========================================================================

    def get_confidence_scoring(self, doc_type: str) -> Dict:
        """
        Get confidence scoring configuration for a document type.

        Args:
            doc_type: "510k" or "de_novo"

        Returns:
            Dict containing extraction_confidence values and validation_adjustments
        """
        patterns = self.get_patterns_for_type(doc_type)
        return patterns.get("confidence_scoring", {})


# Convenience function
def get_document_patterns() -> DocumentPatternLoader:
    """Get singleton DocumentPatternLoader instance."""
    return DocumentPatternLoader()
