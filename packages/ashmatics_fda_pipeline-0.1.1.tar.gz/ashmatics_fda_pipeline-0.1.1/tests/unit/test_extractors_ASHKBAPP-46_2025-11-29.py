# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Unit tests for extractors module.

JIRA: ASHKBAPP-46
Date: 2025-11-29
"""

import pytest
from unittest.mock import MagicMock, patch

from ashmatics_fda_pipeline.extractors import (
    DocumentExtractor,
    FDA510kExtractor,
    SectionTitleNormalizer,
    detect_document_type,
)


class TestSectionTitleNormalizer:
    """Tests for SectionTitleNormalizer class."""

    def test_normalize_removes_numbering(self):
        """Test that section numbering is removed."""
        normalizer = SectionTitleNormalizer(doc_type="510k")

        # Test various numbering formats
        assert normalizer.normalize("5.6.1 Device Description") == "Device Description"
        assert normalizer.normalize("5.6 Device Description") == "Device Description"
        assert normalizer.normalize("5. Device Description") == "Device Description"
        assert normalizer.normalize("A. Device Description") == "Device Description"
        assert normalizer.normalize("IV. Device Description") == "Device Description"

    def test_normalize_strips_whitespace(self):
        """Test that whitespace is properly handled."""
        normalizer = SectionTitleNormalizer(doc_type="510k")

        assert normalizer.normalize("  Device Description  ") == "Device Description"
        assert normalizer.normalize("Device   Description") == "Device Description"


class TestDetectDocumentType:
    """Tests for document type detection."""

    def test_detect_510k_from_k_number(self):
        """Test detection of 510(k) documents."""
        content = "Re: K123456\nTrade Name: Test Device"
        doc_type, confidence = detect_document_type(content)

        assert doc_type == "510k"
        assert confidence > 0.3

    def test_detect_denovo_from_den_number(self):
        """Test detection of De Novo documents."""
        content = "DEN123456\nDe Novo Classification Request"
        doc_type, confidence = detect_document_type(content)

        assert doc_type == "de_novo"
        assert confidence > 0.3

    def test_unknown_document_type(self):
        """Test handling of unknown document types."""
        content = "This is just some random text"
        doc_type, confidence = detect_document_type(content)

        assert doc_type == "unknown"
        assert confidence == 0.0


class TestFDA510kExtractor:
    """Tests for FDA510kExtractor class."""

    def test_init_creates_section_config(self):
        """Test that extractor initializes with section config."""
        extractor = FDA510kExtractor()

        assert 'indications_for_use' in extractor.section_config
        assert 'device_description' in extractor.section_config
        assert 'predicate_devices' in extractor.section_config

    def test_required_sections(self):
        """Test that required sections are defined."""
        extractor = FDA510kExtractor()
        required = extractor.get_required_sections()

        assert 'indications_for_use' in required
        assert 'device_description' in required
        assert 'predicate_devices' in required

    def test_k_number_extraction_priority(self):
        """Test K-number extraction priority (filename > header)."""
        extractor = FDA510kExtractor()

        # Filename takes priority
        result = extractor._extract_k_number_with_fallback(
            filename="K123456.pdf",
            header_k_number="K999999"
        )
        assert result == "K123456"

        # Header used as fallback
        result = extractor._extract_k_number_with_fallback(
            filename="document.pdf",
            header_k_number="K999999"
        )
        assert result == "K999999"

        # None when both missing
        result = extractor._extract_k_number_with_fallback(
            filename="document.pdf",
            header_k_number=None
        )
        assert result is None
