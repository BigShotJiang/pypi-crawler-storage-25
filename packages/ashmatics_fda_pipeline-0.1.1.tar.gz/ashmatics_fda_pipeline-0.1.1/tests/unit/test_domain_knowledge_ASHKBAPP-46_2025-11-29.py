# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Unit tests for domain_knowledge module.

JIRA: ASHKBAPP-46
Date: 2025-11-29
"""

import pytest

from ashmatics_fda_pipeline.domain_knowledge import (
    DomainKnowledge,
    DocumentPatternLoader,
    get_domain_knowledge,
    get_document_patterns,
)


class TestDomainKnowledge:
    """Tests for DomainKnowledge class."""

    def test_singleton_pattern(self):
        """Test that DomainKnowledge uses singleton pattern."""
        dk1 = DomainKnowledge()
        dk2 = DomainKnowledge()

        assert dk1 is dk2

    def test_get_domain_knowledge_convenience(self):
        """Test get_domain_knowledge convenience function."""
        dk = get_domain_knowledge()

        assert isinstance(dk, DomainKnowledge)

    def test_normalize_metric_type(self):
        """Test metric type normalization."""
        dk = get_domain_knowledge()

        # Test common metrics
        assert dk.normalize_metric_type("sensitivity") == "sensitivity"
        assert dk.normalize_metric_type("Sensitivity") == "sensitivity"
        assert dk.normalize_metric_type("PPV") is not None
        assert dk.normalize_metric_type("AUC") is not None

    def test_get_expected_level(self):
        """Test expected level retrieval."""
        dk = get_domain_knowledge()

        # De Novo submissions typically have detailed requirements
        level = dk.get_expected_level(
            submission_type="de_novo",
            extraction_type="training_data"
        )
        # Should return one of the valid levels
        assert level in ["detailed", "moderate", "minimal", "none", "varies"]


class TestDocumentPatternLoader:
    """Tests for DocumentPatternLoader class."""

    def test_singleton_pattern(self):
        """Test that DocumentPatternLoader uses singleton pattern."""
        dp1 = DocumentPatternLoader()
        dp2 = DocumentPatternLoader()

        assert dp1 is dp2

    def test_get_document_patterns_convenience(self):
        """Test get_document_patterns convenience function."""
        dp = get_document_patterns()

        assert isinstance(dp, DocumentPatternLoader)

    def test_get_510k_patterns(self):
        """Test loading 510(k) patterns."""
        dp = get_document_patterns()
        patterns = dp.get_510k_patterns()

        # Should have loaded patterns from YAML
        assert isinstance(patterns, dict)

    def test_get_denovo_patterns(self):
        """Test loading De Novo patterns."""
        dp = get_document_patterns()
        patterns = dp.get_denovo_patterns()

        # Should have loaded patterns from YAML
        assert isinstance(patterns, dict)

    def test_detect_document_type_510k(self):
        """Test document type detection for 510(k)."""
        dp = get_document_patterns()

        content = "510(k) SUMMARY\nRe: K123456"
        doc_type, confidence = dp.detect_document_type(content)

        assert doc_type == "510k"

    def test_detect_document_type_denovo(self):
        """Test document type detection for De Novo."""
        dp = get_document_patterns()

        content = "De Novo Classification Request\nDEN123456"
        doc_type, confidence = dp.detect_document_type(content)

        assert doc_type == "de_novo"

    def test_get_ifu_extraction_patterns(self):
        """Test IFU extraction pattern retrieval."""
        dp = get_document_patterns()
        patterns = dp.get_ifu_extraction_patterns()

        assert "form3881" in patterns
        assert "section" in patterns
        assert "content" in patterns
        assert "extraction_priority" in patterns
