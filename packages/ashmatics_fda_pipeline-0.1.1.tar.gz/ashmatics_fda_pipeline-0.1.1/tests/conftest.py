# Copyright 2025 Asher Informatics PBC
# Proprietary and Confidential
# Last Created: 2025-11-29

"""
Pytest configuration and shared fixtures.

JIRA: ASHKBAPP-46
Date: 2025-11-29
"""

import pytest
from pathlib import Path


@pytest.fixture
def fixtures_dir():
    """Return path to test fixtures directory."""
    return Path(__file__).parent / "fixtures"


@pytest.fixture
def sample_510k_header():
    """Sample 510(k) document header text for testing."""
    return """
DEPARTMENT OF HEALTH AND HUMAN SERVICES
Food and Drug Administration

Test Manufacturer, Inc.
℅ John Smith
123 Test Street
Test City, CA 90210

Re: K123456

Trade/Device Name: Test AI Device
Regulation Number: 21 CFR 892.2050
Regulation Name: Picture archiving and communications system
Regulatory Class: Class II
Product Code: QAS
Dated: January 15, 2024
Received: January 10, 2024
"""


@pytest.fixture
def sample_denovo_header():
    """Sample De Novo document header text for testing."""
    return """
De Novo Classification Request
DEN240001

Device Name: Novel AI Diagnostic
Requested Classification: Class II
Applicant: Test Medical Corporation
"""


@pytest.fixture
def sample_indications_for_use():
    """Sample Indications for Use text."""
    return """
The Test AI Device is a computer-aided detection (CADe) software device
intended to analyze chest X-ray images and identify findings suggestive
of pulmonary abnormalities. The device is intended for use as an aid to
qualified medical professionals in the detection and prioritization of
potential pulmonary findings. The device is not intended to replace the
full interpretation by a qualified physician.

The device is indicated for use with patients 18 years of age and older.

Contraindications:
- The device should not be used as a standalone diagnostic tool.
- Not intended for use in emergency or critical care settings.
"""


@pytest.fixture
def sample_performance_table_markdown():
    """Sample performance results table in markdown format."""
    return """
| Metric | Value | 95% CI |
|--------|-------|--------|
| Sensitivity | 93.2% | (90.1% - 95.8%) |
| Specificity | 87.5% | (84.2% - 90.3%) |
| AUC | 0.942 | (0.921 - 0.963) |
| PPV | 78.4% | (73.8% - 82.5%) |
| NPV | 96.1% | (94.2% - 97.5%) |
"""
