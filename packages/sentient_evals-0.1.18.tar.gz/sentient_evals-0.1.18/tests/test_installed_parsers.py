import json
from pathlib import Path

from sentient_evals.adapters.installed.parsers.claude_code import parse_claude_code_session
from sentient_evals.adapters.installed.parsers.codex import parse_codex_exec_output, parse_codex_session
from sentient_evals.adapters.installed.parsers.cursor_cli import parse_cursor_cli_stream
from sentient_evals.adapters.installed.parsers.gemini_cli import parse_gemini_trajectory
from sentient_evals.adapters.installed.parsers.mini_swe_agent import parse_mini_swe_agent_trajectory
from sentient_evals.adapters.installed.parsers.openhands import parse_openhands_session
from sentient_evals.adapters.installed.parsers.structured_streams import (
    parse_cline_json_stream,
    parse_gemini_stream,
    parse_goose_stream,
    parse_opencode_json_stream,
    parse_qwen_code_stream,
)
from sentient_evals.adapters.installed.parsers.swe_agent import parse_swe_agent_traj


def test_parse_swe_agent_traj_emits_tool_calls(tmp_path: Path):
    traj = {
        "info": {"input_tokens": 10, "output_tokens": 5, "total_cost": 0.01},
        "trajectory": [
            {"response": "ok", "thought": "think", "action": "echo hi", "observation": "hi"},
        ],
    }
    p = tmp_path / "swe.traj"
    p.write_text(json.dumps(traj), encoding="utf-8")
    parsed = parse_swe_agent_traj(p, instruction="do it", model_name="x")
    assert parsed is not None
    assert any(e.kind == "tool_call" for e in parsed.events)
    assert parsed.metrics.get("prompt_tokens") == 10.0


def test_parse_mini_swe_agent_emits_messages(tmp_path: Path):
    data = {
        "info": {"model_stats": {"instance_cost": 0.02}},
        "messages": [
            {"role": "assistant", "content": "hello", "extra": {"response": {"usage": {"prompt_tokens": 2, "completion_tokens": 3}}}},
        ],
    }
    p = tmp_path / "mini.json"
    p.write_text(json.dumps(data), encoding="utf-8")
    parsed = parse_mini_swe_agent_trajectory(p, instruction="do", model_name="m")
    assert parsed is not None
    assert any(e.kind == "message" and e.role == "assistant" for e in parsed.events)
    assert parsed.metrics.get("completion_tokens") == 3.0


def test_parse_openhands_tool_call_metadata(tmp_path: Path):
    sess = tmp_path / "sessions" / "s1" / "events"
    sess.mkdir(parents=True, exist_ok=True)
    (sess / "0.json").write_text(json.dumps({"source": "agent", "tool_call_metadata": {"tool_call_id": "t1", "function_name": "exec", "model_response": {"choices": [{"message": {"tool_calls": [{"function": {"arguments": "{\"cmd\":\"ls\"}"}}]}}]}}}), encoding="utf-8")
    (sess / "1.json").write_text(json.dumps({"source": "agent", "cause": "x", "observation": True, "content": "ok"}), encoding="utf-8")
    parsed = parse_openhands_session(tmp_path, instruction="do")
    assert parsed is not None
    tool_calls = [e for e in parsed.events if e.kind == "tool_call" and e.tool_call]
    assert tool_calls
    assert tool_calls[0].tool_call.id == "t1"
    assert tool_calls[0].observation == "ok"



def test_parse_cursor_cli_stream_emits_tool_calls_and_metrics(tmp_path: Path):
    output = tmp_path / "cursor-cli.txt"
    output.write_text(
        "\n".join(
            [
                json.dumps(
                    {
                        "type": "system",
                        "subtype": "init",
                        "apiKeySource": "env",
                        "cwd": "/app",
                        "session_id": "sess-1",
                        "model": "Claude 4 Sonnet",
                        "permissionMode": "default",
                    }
                ),
                json.dumps(
                    {
                        "type": "user",
                        "message": {
                            "role": "user",
                            "content": [{"type": "text", "text": "Read the file and summarize it"}],
                        },
                        "session_id": "sess-1",
                    }
                ),
                json.dumps(
                    {
                        "type": "assistant",
                        "message": {
                            "role": "assistant",
                            "content": [{"type": "text", "text": "I'll inspect the file first."}],
                        },
                        "session_id": "sess-1",
                        "model_call_id": "mc-1",
                        "timestamp_ms": 1710000001000,
                    }
                ),
                json.dumps(
                    {
                        "type": "tool_call",
                        "subtype": "started",
                        "call_id": "tool-1",
                        "tool_call": {"readToolCall": {"args": {"path": "README.md"}}},
                        "session_id": "sess-1",
                        "model_call_id": "mc-1",
                        "timestamp_ms": 1710000001500,
                    }
                ),
                json.dumps(
                    {
                        "type": "tool_call",
                        "subtype": "completed",
                        "call_id": "tool-1",
                        "tool_call": {
                            "readToolCall": {
                                "args": {"path": "README.md"},
                                "result": {"success": {"content": "# Title", "totalLines": 1}},
                            }
                        },
                        "session_id": "sess-1",
                        "model_call_id": "mc-1",
                        "timestamp_ms": 1710000002000,
                    }
                ),
                json.dumps(
                    {
                        "type": "assistant",
                        "message": {
                            "role": "assistant",
                            "content": [{"type": "text", "text": "Done. I summarized the file."}],
                        },
                        "session_id": "sess-1",
                        "model_call_id": "mc-2",
                        "timestamp_ms": 1710000003000,
                    }
                ),
                json.dumps(
                    {
                        "type": "result",
                        "subtype": "success",
                        "duration_ms": 5234,
                        "duration_api_ms": 4100,
                        "is_error": False,
                        "result": "Done. I summarized the file.",
                        "usage": {
                            "inputTokens": 100,
                            "outputTokens": 20,
                            "cacheReadTokens": 5,
                            "cacheWriteTokens": 2,
                        },
                        "session_id": "sess-1",
                        "request_id": "req-1",
                    }
                ),
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    parsed = parse_cursor_cli_stream(tmp_path, instruction="Read the file and summarize it")
    assert parsed is not None
    assert parsed.metrics == {
        "prompt_tokens": 107.0,
        "completion_tokens": 20.0,
        "cached_tokens": 5.0,
    }
    assert parsed.extra == {
        "source": "cursor-cli-stream",
        "output_file": "cursor-cli.txt",
        "session_id": "sess-1",
        "model": "Claude 4 Sonnet",
        "permission_mode": "default",
        "api_key_source": "env",
        "duration_ms": 5234,
        "duration_api_ms": 4100,
        "request_id": "req-1",
        "result_subtypes": ["success"],
    }
    tool_calls = [e for e in parsed.events if e.kind == "tool_call" and e.tool_call]
    assert len(tool_calls) == 1
    assert tool_calls[0].tool_call.id == "tool-1"
    assert tool_calls[0].tool_call.name == "readToolCall"
    assert tool_calls[0].tool_call.args == {"path": "README.md"}
    assert tool_calls[0].observation == '{"success": {"content": "# Title", "totalLines": 1}}'
    assert tool_calls[0].tool_call.started_at is not None
    assert tool_calls[0].tool_call.ended_at is not None
    assert any(
        e.kind == "message" and e.role == "assistant" and (e.content or "") == "I'll inspect the file first."
        for e in parsed.events
    )
    assert any(
        e.kind == "message" and e.role == "assistant" and (e.content or "") == "Done. I summarized the file."
        for e in parsed.events
    )


def test_parse_codex_jsonl(tmp_path: Path):
    sessions = tmp_path / "sessions"
    sessions.mkdir(parents=True, exist_ok=True)
    p_old = sessions / "old.jsonl"
    p_old.write_text(
        '\n'.join(
            [
                '{"type":"message","payload":{"role":"assistant","text":"hello"}}',
                '{"type":"tool_call","payload":{"call_id":"c1","tool_name":"exec","arguments":{"cmd":"ls"},"output":"x"}}',
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    p_new = sessions / "new.jsonl"
    p_new.write_text(
        '\n'.join(
            [
                '{"type":"message","payload":{"role":"assistant","text":"new"}}',
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    import os, time
    os.utime(p_old, (time.time() - 10, time.time() - 10))
    os.utime(p_new, (time.time(), time.time()))

    parsed = parse_codex_session(tmp_path, instruction="do")
    assert parsed is not None
    # Must select newest session file (which does NOT contain tool_call).
    assert any(e.kind == "message" and e.role == "assistant" and (e.content or "") == "new" for e in parsed.events)


def test_parse_codex_modern_session_jsonl(tmp_path: Path):
    sessions = tmp_path / "sessions" / "2026" / "03" / "21"
    sessions.mkdir(parents=True, exist_ok=True)
    p = sessions / "rollout.jsonl"
    p.write_text(
        "\n".join(
            [
                json.dumps({"timestamp": "2026-03-21T00:00:00Z", "type": "session_meta", "payload": {"cli_version": "0.116.0"}}),
                json.dumps(
                    {
                        "timestamp": "2026-03-21T00:00:01Z",
                        "type": "response_item",
                        "payload": {"type": "reasoning", "summary": [{"text": "Inspect the environment first."}]},
                    }
                ),
                json.dumps(
                    {
                        "timestamp": "2026-03-21T00:00:02Z",
                        "type": "response_item",
                        "payload": {
                            "type": "message",
                            "role": "assistant",
                            "phase": "commentary",
                            "content": [{"type": "output_text", "text": "Checking Composio setup."}],
                        },
                    }
                ),
                json.dumps(
                    {
                        "timestamp": "2026-03-21T00:00:03Z",
                        "type": "response_item",
                        "payload": {
                            "type": "function_call",
                            "name": "exec_command",
                            "call_id": "call_1",
                            "arguments": json.dumps({"cmd": "which composio"}),
                        },
                    }
                ),
                json.dumps(
                    {
                        "timestamp": "2026-03-21T00:00:04Z",
                        "type": "response_item",
                        "payload": {
                            "type": "function_call_output",
                            "call_id": "call_1",
                            "output": "Command: which composio\nOutput:\n/root/.composio/composio\n",
                        },
                    }
                ),
                json.dumps(
                    {
                        "timestamp": "2026-03-21T00:00:05Z",
                        "type": "response_item",
                        "payload": {
                            "type": "web_search_call",
                            "status": "completed",
                            "action": {"type": "search", "query": "composio gmail send email"},
                        },
                    }
                ),
                json.dumps(
                    {
                        "timestamp": "2026-03-21T00:00:06Z",
                        "type": "event_msg",
                        "payload": {
                            "type": "token_count",
                            "info": {
                                "total_token_usage": {
                                    "input_tokens": 100,
                                    "cached_input_tokens": 40,
                                    "output_tokens": 12,
                                },
                                "last_token_usage": {
                                    "input_tokens": 25,
                                    "cached_input_tokens": 10,
                                    "output_tokens": 4,
                                },
                            },
                        },
                    }
                ),
                json.dumps(
                    {
                        "timestamp": "2026-03-21T00:00:07Z",
                        "type": "response_item",
                        "payload": {
                            "type": "message",
                            "role": "assistant",
                            "phase": "final_answer",
                            "content": [{"type": "output_text", "text": "Email sent."}],
                        },
                    }
                ),
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    parsed = parse_codex_session(tmp_path, instruction="send the email")
    assert parsed is not None
    assert parsed.metrics["prompt_tokens"] == 100.0
    assert parsed.metrics["cached_tokens"] == 40.0
    assert parsed.metrics["completion_tokens"] == 12.0
    assert any(e.kind == "message" and e.role == "assistant" and (e.content or "") == "Checking Composio setup." for e in parsed.events)
    tool_calls = [e for e in parsed.events if e.kind == "tool_call" and e.tool_call]
    assert any(e.tool_call and e.tool_call.id == "call_1" and e.tool_call.name == "exec_command" for e in tool_calls)
    exec_event = next(e for e in tool_calls if e.tool_call and e.tool_call.id == "call_1")
    assert exec_event.observation == "Command: which composio\nOutput:\n/root/.composio/composio\n"
    assert any(e.reasoning_content == "Inspect the environment first." for e in parsed.events)
    assert any(e.tool_call and e.tool_call.name == "search" for e in tool_calls)
    search_event = next(e for e in tool_calls if e.tool_call and e.tool_call.name == "search")
    assert search_event.metrics == {
        "prompt_tokens": 25.0,
        "completion_tokens": 4.0,
        "cached_tokens": 10.0,
    }
    assert any(e.kind == "message" and e.role == "assistant" and (e.content or "") == "Email sent." for e in parsed.events)


def test_parse_codex_exec_output_stream(tmp_path: Path):
    del tmp_path
    stdout = "\n".join(
        [
            json.dumps({"type": "thread.started", "thread_id": "t1"}),
            json.dumps(
                {
                    "type": "item.completed",
                    "item": {"id": "item_0", "type": "agent_message", "text": "Checking Composio setup."},
                }
            ),
            json.dumps(
                {
                    "type": "item.completed",
                    "item": {
                        "id": "item_1",
                        "type": "command_execution",
                        "command": "/bin/bash -lc 'which composio'",
                        "aggregated_output": "/root/.composio/composio\n",
                        "exit_code": 0,
                        "status": "completed",
                    },
                }
            ),
            json.dumps(
                {
                    "type": "item.completed",
                    "item": {"id": "item_2", "type": "agent_message", "text": "Email sent."},
                }
            ),
            json.dumps(
                {
                    "type": "turn.completed",
                    "usage": {"input_tokens": 50, "cached_input_tokens": 10, "output_tokens": 5},
                }
            ),
        ]
    )
    parsed = parse_codex_exec_output(stdout, instruction="send the email")
    assert parsed is not None
    assert parsed.metrics["prompt_tokens"] == 50.0
    assert parsed.metrics["cached_tokens"] == 10.0
    assert parsed.metrics["completion_tokens"] == 5.0
    assert any(e.kind == "message" and e.role == "assistant" and (e.content or "") == "Checking Composio setup." for e in parsed.events)
    tool_calls = [e for e in parsed.events if e.kind == "tool_call" and e.tool_call]
    assert len(tool_calls) == 1
    assert tool_calls[0].tool_call.name == "exec_command"
    assert tool_calls[0].observation == {
        "stdout": "/root/.composio/composio\n",
        "exit_code": 0,
        "status": "completed",
        "command": "/bin/bash -lc 'which composio'",
    }
    final_message = next(e for e in parsed.events if e.kind == "message" and e.role == "assistant" and (e.content or "") == "Email sent.")
    assert final_message.metrics == {
        "prompt_tokens": 50.0,
        "completion_tokens": 5.0,
        "cached_tokens": 10.0,
    }


def test_parse_claude_stream_json_basic(tmp_path: Path):
    sessions = tmp_path / "sessions" / "projects" / "p"
    sessions.mkdir(parents=True, exist_ok=True)
    p = sessions / "s.jsonl"
    p.write_text(
        '\n'.join(
            [
                json.dumps({"type": "assistant", "timestamp": "2026-01-30T00:00:00Z", "message": {"role": "assistant", "content": "hello", "usage": {"input_tokens": 1, "output_tokens": 2}}}),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    parsed = parse_claude_code_session(tmp_path, instruction="do")
    assert parsed is not None
    assert any(e.kind == "message" and e.role == "assistant" for e in parsed.events)


def test_parse_gemini_trajectory(tmp_path: Path):
    p = tmp_path / "gemini-cli.trajectory.json"
    p.write_text(
        json.dumps(
            {
                "sessionId": "s",
                "messages": [
                    {"type": "user", "content": "hi"},
                    {
                        "type": "gemini",
                        "content": "ok",
                        "thoughts": [{"subject": "plan", "description": "do"}],
                        "tokens": {"input": 1, "output": 2, "cached": 0, "thoughts": 1, "tool": 0},
                        "toolCalls": [
                            {
                                "id": "t1",
                                "name": "exec",
                                "args": {"cmd": "ls"},
                                "result": [{"functionResponse": {"response": {"output": "x"}}}],
                            }
                        ],
                    },
                ],
            }
        ),
        encoding="utf-8",
    )
    parsed = parse_gemini_trajectory(tmp_path, instruction="do")
    assert parsed is not None
    assert any(e.kind == "tool_call" and e.tool_call and e.tool_call.id == "t1" for e in parsed.events)


def test_parse_gemini_stream_json(tmp_path: Path):
    (tmp_path / "gemini-cli.txt").write_text(
        "\n".join(
            [
                json.dumps({"type": "message", "message": {"role": "assistant", "content": [{"type": "text", "text": "I will inspect."}]}}),
                json.dumps({"type": "tool_use", "id": "g1", "name": "read_file", "input": {"path": "README.md"}}),
                json.dumps({"type": "tool_result", "tool_use_id": "g1", "content": "contents"}),
                json.dumps({"type": "result", "usage": {"inputTokens": 10, "outputTokens": 3}}),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    parsed = parse_gemini_stream(tmp_path, instruction="do")
    assert parsed is not None
    tool_calls = [e for e in parsed.events if e.tool_call]
    assert len(tool_calls) == 1
    assert tool_calls[0].tool_call.name == "read_file"
    assert tool_calls[0].observation == "contents"
    assert parsed.metrics["prompt_tokens"] == 10.0


def test_parse_qwen_code_stream_json(tmp_path: Path):
    (tmp_path / "qwen-code.txt").write_text(
        "\n".join(
            [
                json.dumps({"type": "system", "subtype": "session_start", "session_id": "s1", "model": "qwen3-coder-plus"}),
                json.dumps(
                    {
                        "type": "assistant",
                        "message": {
                            "role": "assistant",
                            "content": [
                                {"type": "text", "text": "Reading file."},
                                {"type": "tool_use", "id": "q1", "name": "read_file", "input": {"path": "a.txt"}},
                            ],
                            "usage": {"inputTokens": 6, "outputTokens": 2},
                        },
                    }
                ),
                json.dumps({"type": "tool_result", "message": {"parts": [{"functionResponse": {"id": "q1", "response": {"output": "ok"}}}]}}),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    parsed = parse_qwen_code_stream(tmp_path, instruction="do")
    assert parsed is not None
    tool_calls = [e for e in parsed.events if e.tool_call]
    assert len(tool_calls) == 1
    assert tool_calls[0].tool_call.id == "q1"
    assert tool_calls[0].observation == "ok"
    assert parsed.metrics["prompt_tokens"] == 6.0


def test_parse_cline_json_stream(tmp_path: Path):
    (tmp_path / "cline.txt").write_text(
        "\n".join(
            [
                json.dumps({"type": "say", "say": "text", "text": "I will fix it.", "ts": 1760501486669}),
                json.dumps({"type": "say", "say": "tool", "text": "Running npm test", "ts": 1760501487669}),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    parsed = parse_cline_json_stream(tmp_path, instruction="do")
    assert parsed is not None
    assert any(e.kind == "message" and e.role == "assistant" for e in parsed.events)
    assert any(e.tool_call and e.tool_call.name == "npm" for e in parsed.events)


def test_parse_opencode_json_stream(tmp_path: Path):
    (tmp_path / "opencode.txt").write_text(
        "\n".join(
            [
                json.dumps({"type": "text", "timestamp": 1700000001000, "sessionID": "s1", "part": {"type": "text", "messageID": "m1", "text": "Creating file."}}),
                json.dumps({"type": "tool_use", "timestamp": 1700000002000, "sessionID": "s1", "part": {"type": "tool", "messageID": "m1", "callID": "o1", "tool": "write", "state": {"status": "completed", "input": {"filePath": "a.txt"}, "output": "done"}}}),
                json.dumps({"type": "step_finish", "sessionID": "s1", "part": {"type": "step-finish", "cost": 0.01, "tokens": {"input": 4, "output": 5, "cache": {"read": 2}}}}),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    parsed = parse_opencode_json_stream(tmp_path, instruction="do")
    assert parsed is not None
    tool_calls = [e for e in parsed.events if e.tool_call]
    assert tool_calls[0].tool_call.id == "o1"
    assert tool_calls[0].observation == "done"
    assert parsed.metrics["prompt_tokens"] == 6.0
    assert parsed.metrics["cost_usd"] == 0.01


def test_parse_goose_stream_json(tmp_path: Path):
    (tmp_path / "goose.txt").write_text(
        "\n".join(
            [
                json.dumps({"type": "message", "message": {"id": "m1", "role": "assistant", "content": [{"type": "text", "text": "Checking."}, {"type": "toolRequest", "id": "g1", "toolCall": {"value": {"name": "developer__shell", "arguments": {"cmd": "ls"}}}}]}}),
                json.dumps({"type": "message", "message": {"id": "m2", "role": "user", "content": [{"type": "toolResponse", "id": "g1", "toolResult": {"value": {"content": [{"type": "text", "text": "ok"}]}}}]}}),
                json.dumps({"type": "complete", "total_tokens": 12}),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    parsed = parse_goose_stream(tmp_path, instruction="do")
    assert parsed is not None
    tool_calls = [e for e in parsed.events if e.tool_call]
    assert tool_calls[0].tool_call.name == "developer__shell"
    assert "ok" in (tool_calls[0].observation or "")
    assert parsed.metrics["total_tokens"] == 12.0


def test_final_metrics_populated_from_transcript(tmp_path: Path):
    from sentient_evals.atif.converters import transcript_to_trajectory
    from sentient_evals.models import TranscriptEvent

    t = [
        TranscriptEvent(kind="message", role="user", content="x"),
        TranscriptEvent(kind="message", role="assistant", content="y", metrics={"prompt_tokens": 2, "completion_tokens": 3}),
    ]
    traj = transcript_to_trajectory(t, session_id="s", agent_name="a", agent_version="v")
    assert traj.final_metrics is not None
    assert traj.final_metrics.total_prompt_tokens == 2
    assert traj.final_metrics.total_completion_tokens == 3
