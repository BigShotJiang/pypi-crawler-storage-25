# Code of Conduct

This project follows the Contributor Covenant Code of Conduct.

We expect participants to be respectful, constructive, and professional.

Reporting: open an issue or contact `oss@sentient.ai`.

