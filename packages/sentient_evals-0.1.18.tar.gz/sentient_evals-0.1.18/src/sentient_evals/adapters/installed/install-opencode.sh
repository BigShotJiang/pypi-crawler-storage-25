#!/bin/bash

apt-get update
apt-get install -y curl

curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.2/install.sh | bash

source "$HOME/.nvm/nvm.sh"

nvm install 22
npm -v

{% if version %}
npm i -g opencode-ai@{{ version }}
{% else %}
npm i -g opencode-ai@latest
{% endif %}
