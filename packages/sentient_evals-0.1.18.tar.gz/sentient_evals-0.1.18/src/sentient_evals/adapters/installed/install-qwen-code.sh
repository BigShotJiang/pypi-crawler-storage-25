#!/bin/bash

apt-get update
apt-get install -y curl

# Install npm, nvm, and node
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.2/install.sh | bash
source "$HOME/.nvm/nvm.sh"
nvm install 22
npm -v

# Install QWen Code
{% if version %}
npm install -g @qwen-code/qwen-code@{{ version }}
{% else %}
npm install -g @qwen-code/qwen-code@latest
{% endif %}
