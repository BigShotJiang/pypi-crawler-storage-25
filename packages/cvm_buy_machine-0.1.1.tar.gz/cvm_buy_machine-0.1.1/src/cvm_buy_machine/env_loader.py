# -*- coding: utf-8 -*-
import os
from pathlib import Path
from dotenv import dotenv_values


def load_env() -> dict:
    """从环境变量 ENV_FILE_PATH 指定的 .env 文件加载配置"""
    env_path = os.environ.get("ENV_FILE_PATH", "")
    if not env_path:
        raise RuntimeError("未设置环境变量 ENV_FILE_PATH，请在 mcp.json 的 env 字段中配置")
    p = Path(env_path).expanduser().resolve()
    if not p.exists():
        raise FileNotFoundError(f".env 文件不存在: {p}")
    return dotenv_values(str(p))
