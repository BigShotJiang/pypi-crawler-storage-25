# -*- coding: utf-8 -*-
"""
多云厂商 CVM 购买 MCP 工具

支持厂商: 腾讯云 / 阿里云 / 火山引擎 / 华为云 / AWS / Azure / GCP
每个厂商一个独立 tool，通过 .env 文件加载配置和密钥。
.env 文件路径通过环境变量 ENV_FILE_PATH 指定（在 mcp.json 中配置）。
"""
from mcp.server.fastmcp import FastMCP

from .vendors.qcloud import register as register_qcloud
from .vendors.aliyun import register as register_aliyun
from .vendors.volcengine import register as register_volcengine
from .vendors.huaweiyun import register as register_huaweiyun
from .vendors.aws import register as register_aws
from .vendors.azure_vm import register as register_azure
from .vendors.gcp import register as register_gcp

mcp = FastMCP("cvm-buy-machine")

register_qcloud(mcp)
register_aliyun(mcp)
register_volcengine(mcp)
register_huaweiyun(mcp)
register_aws(mcp)
register_azure(mcp)
register_gcp(mcp)


def main():
    mcp.run()


if __name__ == "__main__":
    main()
