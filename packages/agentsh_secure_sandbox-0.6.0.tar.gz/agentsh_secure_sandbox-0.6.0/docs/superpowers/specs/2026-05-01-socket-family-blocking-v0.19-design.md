# Socket Family Blocking + agentsh v0.19.0 (Python)

Expose agentsh v0.19.0's per-AF_* socket family blocking through the
`agentsh_secure_sandbox` Python API, and bump the pinned agentsh version from
`0.18.3` to `0.19.0`. Mirrors the TypeScript port shipped in
`secure-sandbox` v0.5.0 (commit `3e87765`).

## Context

agentsh v0.19.0 adds per-AF_* family blocking on `socket(2)` and
`socketpair(2)`, configured under `sandbox.seccomp.blocked_socket_families`.
Two enforcement engines (seccomp-bpf primary, ptrace fallback) share the
config and emit identical `seccomp_socket_family_blocked` audit events. The
motivating CVE class is `socket(AF_<niche>, ...)` as a kernel attack entry
point.

When the YAML field is unset, agentsh applies a 12-family recommended-default
list at `action: errno` (AF_ALG, AF_VSOCK, AF_RDS, AF_TIPC, AF_KCM, AF_X25,
AF_AX25, AF_NETROM, AF_ROSE, AF_DECnet, AF_APPLETALK, AF_IPX). Setting the
field to `[]` is an explicit opt-out; a non-empty list overrides the defaults.

The Python library currently pins agentsh `0.18.3`, so this feature is
unreachable from Python callers and the version pin is one minor behind
upstream. The TypeScript sibling library shipped the equivalent surface as
`secure-sandbox` v0.5.0 — this design ports the same config knob and version
bump to Python.

## Scope

In:

| Item | Layer | Files |
|---|---|---|
| `BlockedSocketFamily` Pydantic model | Types | `src/agentsh_secure_sandbox/core/types.py` |
| `seccomp_details.blocked_socket_families` field | Types | `src/agentsh_secure_sandbox/core/types.py` |
| Tri-state YAML emission (omitted / `[]` / populated) | Server config | `src/agentsh_secure_sandbox/core/config.py` |
| Version bump 0.18.3 → 0.19.0 | Integrity / install | `src/agentsh_secure_sandbox/core/integrity.py`, `src/agentsh_secure_sandbox/adapters/freestyle/_defaults.py` |
| Tests | Unit | `tests/test_config.py`, `tests/test_integrity.py`, `tests/test_freestyle_defaults.py`, `tests/test_freestyle_client.py` |
| README mention | Docs | `README.md` |

Out of scope (deferred or not applicable to Python):

- Sprites WebSocket retry — TS-only fix for `@fly/sprites` SDK quirk; the
  Python sprites adapter uses a different transport.
- Freestyle e2e `delete` vs `stop` — Python repo has no equivalent
  always-running e2e runner accumulating VMs.
- `scripts/freestyle-cleanup.ts` Python equivalent — one-shot operational
  tooling, not library code.
- `skillcheck` (the other v0.19.0 feature) — separate config surface, not
  yet ported in TS either.
- `serializePolicy`-equivalent changes — this is sandbox config, not policy.
- Per-adapter overrides — adapters keep relying on agentsh defaults.

## API surface (`core/types.py`)

Add a new top-level Pydantic model alongside `FileMonitorConfig`:

```python
class BlockedSocketFamily(BaseModel):
    model_config = ConfigDict(extra="forbid")
    family: str  # 'AF_VSOCK', 'AF_ALG', or numeric string '38'
    action: Literal["errno", "kill", "log", "log_and_kill"] | None = None
```

Extend `SeccompDetailsConfig` with one optional field:

```python
class SeccompDetailsConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    execve: bool | None = None
    file_monitor: FileMonitorConfig | None = None
    blocked_socket_families: list[BlockedSocketFamily] | None = None  # NEW
```

Both classes use `extra="forbid"` to match the rest of `types.py` and reject
typos at the API boundary.

`family` is a plain `str` rather than an enum. The kernel adds families
occasionally and agentsh's table is authoritative; a typo'd family name
surfaces as an agentsh config-load error, which is the right place for it.

`action` is optional per-entry. When `None`, the YAML emission omits the
`action` key for that entry, and agentsh defaults to `errno`. This mirrors
the TS surface.

`BlockedSocketFamily` is importable from `agentsh_secure_sandbox.core.types`
alongside the other nested config models, matching the existing convention
(neither `core/__init__.py` nor the package-level `__all__` re-export the
nested seccomp/ptrace/etc. config types — consumers import them directly):

```python
from agentsh_secure_sandbox.core.types import (
    BlockedSocketFamily,
    SeccompDetailsConfig,
    ServerConfig,
)
```

## YAML emission (`core/config.py`)

Inserted at the end of the existing `if sc.seccomp_details is not None:`
block (after the `file_monitor` handling, around line 278):

```python
if sc.seccomp_details.blocked_socket_families is not None:
    sec["blocked_socket_families"] = [
        {"family": e.family, **({"action": e.action} if e.action is not None else {})}
        for e in sc.seccomp_details.blocked_socket_families
    ]
```

### Tri-state semantics (preserved from agentsh)

| Caller passes | YAML emitted | agentsh behavior |
|---|---|---|
| field omitted (`None`) | `blocked_socket_families` key absent | applies 12-family default list at errno |
| `blocked_socket_families=[]` | `blocked_socket_families: []` | opts out of all family blocking |
| populated list | `blocked_socket_families: [...]` | uses the supplied list, overrides defaults |

Pydantic's `None` vs `[]` distinction makes this fall out naturally; no
sentinel class needed. The check uses `is not None` (not truthiness) so an
empty list emits the explicit opt-out array.

### Implicit enablement

Existing rule in `generateServerConfig` (Python: `config.py:258–259`): when
`seccomp_details` is provided AND `ptrace.enabled` is not true,
`sandbox.seccomp.enabled = True`. This rule is unchanged — passing only
`blocked_socket_families` (without `execve`/`file_monitor`) implicitly enables
seccomp. With ptrace enabled, seccomp stays disabled and agentsh's ptrace
fallback engine handles family blocking from the same emitted field.

## Version bump

Three constants + four test literals + one entry added to `CHECKSUMS`:

- **`src/agentsh_secure_sandbox/core/integrity.py`**:
  - `PINNED_VERSION = "0.19.0"`
  - Add to `CHECKSUMS`:
    ```python
    "0.19.0": {
        "linux_amd64": "04c1b0e958a6e9027fc85d4625bec765e459f191dc16c4c5a04468c867f71d85",
        "linux_arm64": "89cecae90e6511cf96019cca948e3b5142dce329349141eb838979a243dda9cd",
    },
    ```
  - Older versions retained for callers that pin via `agentsh_version`.
- **`src/agentsh_secure_sandbox/adapters/freestyle/_defaults.py`** (line 133):
  `agentsh_version: str = "0.19.0"`. The script template at lines 52–53 uses
  `{version}` interpolation, so it picks up the new default automatically.

Checksums sourced from the v0.19.0 release `checksums.txt` (the same values
shipped in TS `secure-sandbox` v0.5.0).

## Tests

### `tests/test_config.py` (5 new tests)

Mirror the existing `test_file_monitor_new_fields` pattern (around line 291).
Each test instantiates a `SecureConfig` with a `ServerConfig` containing
`SeccompDetailsConfig`, calls the existing config-emission helper, parses
the resulting YAML, and asserts on `sandbox.seccomp.*`:

1. **`test_blocked_socket_families_omitted`** —
   `SeccompDetailsConfig(execve=True)` produces a config where
   `sandbox.seccomp.blocked_socket_families` key is absent (agentsh-default
   path).
2. **`test_blocked_socket_families_empty_optout`** —
   `SeccompDetailsConfig(blocked_socket_families=[])` emits
   `blocked_socket_families: []`. Asserts the key is present, the list is
   empty, and `sandbox.seccomp.enabled` is `True` (implicit enablement).
3. **`test_blocked_socket_families_populated`** — three entries:
   `BlockedSocketFamily(family="AF_VSOCK", action="log_and_kill")`,
   `BlockedSocketFamily(family="AF_ALG")` (no action),
   `BlockedSocketFamily(family="38", action="errno")`. Asserts the emitted
   list matches exactly, including that the second entry has no `action`
   key in its YAML dict.
4. **`test_blocked_socket_families_implicit_seccomp_enable`** — passing only
   `blocked_socket_families` (no `execve`, no `file_monitor`) sets
   `sandbox.seccomp.enabled` to `True`.
5. **`test_blocked_socket_families_ptrace_precedence`** — with
   `PtraceConfig(enabled=True)` plus
   `blocked_socket_families=[BlockedSocketFamily(family="AF_VSOCK", action="log")]`,
   `sandbox.seccomp.enabled` stays `False` and the
   `blocked_socket_families` list is still emitted under
   `sandbox.seccomp` so the ptrace engine can consume it.

### `tests/test_integrity.py` (bump literals)

- Flip `PINNED_VERSION` assertion `0.18.3` → `0.19.0` (lines 12, 54).
- Update `binary_url("0.18.3", ...)` → `binary_url("0.19.0", ...)` and the
  filename substring assertion (lines 22–23).
- Update `get_checksum("0.18.3", ...)` → `get_checksum("0.19.0", ...)` (line 33).
- Update `CHECKSUMS["0.18.3"]` → `CHECKSUMS["0.19.0"]` and the two checksum
  literal assertions (lines 58–62) to the 0.19.0 values.

### `tests/test_freestyle_defaults.py` (bump literals)

- Line 113: `assert opts.agentsh_version == "0.19.0"`.
- Line 145: `assert 'AGENTSH_VERSION="0.19.0"' in content`.

### `tests/test_freestyle_client.py` (bump literals)

- Line 531: `FreestyleConfigureOptions(agentsh_version="0.19.0")`.
- Line 536: `assert 'AGENTSH_VERSION="0.19.0"' in install_script`.

Existing seccomp/ptrace test coverage stays untouched. Those tests don't
reference `blocked_socket_families`, so they verify backward-compat by
being unaffected.

## README

Short note in the security/configuration section: secure-sandbox blocks 12
niche AF_* socket families by default at `EAFNOSUPPORT` via agentsh v0.19.0.
Operators can override the list via:

```python
ServerConfig(
    seccomp_details=SeccompDetailsConfig(
        blocked_socket_families=[
            BlockedSocketFamily(family="AF_VSOCK", action="log_and_kill"),
            ...
        ],
    ),
)
```

…or opt out entirely with `blocked_socket_families=[]`. Reference upstream
agentsh `docs/seccomp.md` for the canonical default list and audit event
shape.

## Verification

1. `uv run pytest tests/test_config.py tests/test_integrity.py tests/test_freestyle_defaults.py tests/test_freestyle_client.py`
   — exercises all new and bumped assertions.
2. `uv run pytest` — full suite, confirms nothing else regresses.
3. `uv run mypy src/` — confirms new types compile cleanly.

Manual integration (optional, requires a Linux host with seccomp): construct
a `SecureConfig` with
`server_config=ServerConfig(seccomp_details=SeccompDetailsConfig(blocked_socket_families=[BlockedSocketFamily(family="AF_VSOCK", action="log")]))`,
provision a sandbox, run a small program inside it that calls
`socket(AF_VSOCK, SOCK_STREAM, 0)`, confirm it returns `EAFNOSUPPORT` and a
`seccomp_socket_family_blocked` audit event lands.

## Critical files

- `src/agentsh_secure_sandbox/core/types.py` (add `BlockedSocketFamily`,
  extend `SeccompDetailsConfig`)
- `src/agentsh_secure_sandbox/core/config.py` (~line 278: emit
  `blocked_socket_families` block)
- `src/agentsh_secure_sandbox/core/integrity.py` (`PINNED_VERSION` +
  `CHECKSUMS` entry)
- `src/agentsh_secure_sandbox/adapters/freestyle/_defaults.py` (line 133:
  default `agentsh_version`)
- `tests/test_config.py` (5 new tests)
- `tests/test_integrity.py` (lines 12, 22–23, 33, 54, 58–62)
- `tests/test_freestyle_defaults.py` (lines 113, 145)
- `tests/test_freestyle_client.py` (lines 531, 536)
- `README.md` (short note)
