# Socket Family Blocking + agentsh v0.19.0 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Expose agentsh v0.19.0's per-AF_* socket family blocking through the Python `agentsh_secure_sandbox` API and bump the pinned agentsh version from `0.18.3` to `0.19.0`. Mirrors the TypeScript port shipped in `secure-sandbox` v0.5.0.

**Architecture:** Adds a new `BlockedSocketFamily` Pydantic model and a `blocked_socket_families` field on `SeccompDetailsConfig` in `core/types.py`. Extends YAML emission in `core/config.py` to write `sandbox.seccomp.blocked_socket_families` with tri-state semantics (omitted / `[]` / populated). Updates pinned version + checksums in `core/integrity.py` and the freestyle adapter default. Adds five unit tests mirroring the upstream TS suite.

**Tech Stack:** Python 3.12+, Pydantic v2, PyYAML, pytest, uv.

---

## File Structure

| File | Responsibility |
|---|---|
| `src/agentsh_secure_sandbox/core/types.py` | Adds `BlockedSocketFamily` model + `blocked_socket_families` field on `SeccompDetailsConfig` |
| `src/agentsh_secure_sandbox/core/config.py` | Adds tri-state YAML emission inside the existing `seccomp_details` branch of `generate_server_config()` |
| `src/agentsh_secure_sandbox/core/integrity.py` | Bumps `PINNED_VERSION` to `0.19.0` and adds checksums entry |
| `src/agentsh_secure_sandbox/adapters/freestyle/_defaults.py` | Bumps `agentsh_version` default constant |
| `tests/test_config.py` | Five new tests for the field + emission behavior |
| `tests/test_integrity.py` | Bumps version literal assertions and checksum literals |
| `tests/test_freestyle_defaults.py` | Bumps version literal assertions |
| `tests/test_freestyle_client.py` | Bumps version literal assertions |
| `README.md` | Short note on default 12-family blocking + override knob |

---

## Task 1: Add `BlockedSocketFamily` model and `blocked_socket_families` field

**Files:**
- Modify: `src/agentsh_secure_sandbox/core/types.py:294-306` (add `BlockedSocketFamily` next to `FileMonitorConfig`; add new field on `SeccompDetailsConfig`)
- Test: `tests/test_config.py` (new test that exercises the model directly via Pydantic validation)

This task only adds the type definitions. YAML emission lands in Task 2.

- [ ] **Step 1: Write the failing test for the model**

Append to `tests/test_config.py` (just below the existing `test_file_monitor_new_fields` at line 305). The test imports `BlockedSocketFamily` (which does not yet exist) and exercises Pydantic validation:

```python
def test_blocked_socket_family_model_basic():
    fam = BlockedSocketFamily(family="AF_VSOCK", action="errno")
    assert fam.family == "AF_VSOCK"
    assert fam.action == "errno"


def test_blocked_socket_family_model_action_optional():
    fam = BlockedSocketFamily(family="AF_ALG")
    assert fam.family == "AF_ALG"
    assert fam.action is None


def test_blocked_socket_family_model_rejects_unknown_action():
    import pytest
    from pydantic import ValidationError
    with pytest.raises(ValidationError):
        BlockedSocketFamily(family="AF_VSOCK", action="bogus")  # type: ignore[arg-type]


def test_blocked_socket_family_model_rejects_extra_fields():
    import pytest
    from pydantic import ValidationError
    with pytest.raises(ValidationError):
        BlockedSocketFamily(family="AF_VSOCK", typo=True)  # type: ignore[call-arg]
```

Also extend the import block at the top of `tests/test_config.py` (currently line 11) to include `BlockedSocketFamily`:

```python
    SeccompDetailsConfig, FileMonitorConfig, BlockedSocketFamily,
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py && uv run pytest tests/test_config.py::test_blocked_socket_family_model_basic tests/test_config.py::test_blocked_socket_family_model_action_optional tests/test_config.py::test_blocked_socket_family_model_rejects_unknown_action tests/test_config.py::test_blocked_socket_family_model_rejects_extra_fields -v`

Expected: ImportError or 4× FAIL with `ImportError: cannot import name 'BlockedSocketFamily'`.

- [ ] **Step 3: Add `BlockedSocketFamily` model to `core/types.py`**

In `src/agentsh_secure_sandbox/core/types.py`, insert the new class immediately above `FileMonitorConfig` (currently at line 294):

```python
class BlockedSocketFamily(BaseModel):
    model_config = ConfigDict(extra="forbid")
    family: str
    action: Literal["errno", "kill", "log", "log_and_kill"] | None = None


```

- [ ] **Step 4: Extend `SeccompDetailsConfig` with the new field**

Modify `SeccompDetailsConfig` (currently at lines 303–306). Add the new optional field below `file_monitor`:

```python
class SeccompDetailsConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    execve: bool | None = None
    file_monitor: FileMonitorConfig | None = None
    blocked_socket_families: list[BlockedSocketFamily] | None = None
```

- [ ] **Step 5: Run model tests to verify they pass**

Run: `cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py && uv run pytest tests/test_config.py::test_blocked_socket_family_model_basic tests/test_config.py::test_blocked_socket_family_model_action_optional tests/test_config.py::test_blocked_socket_family_model_rejects_unknown_action tests/test_config.py::test_blocked_socket_family_model_rejects_extra_fields -v`

Expected: 4× PASS.

- [ ] **Step 6: Run mypy to confirm types compile**

Run: `cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py && uv run mypy src/agentsh_secure_sandbox/core/`

Expected: `Success: no issues found` (or unchanged baseline — no new errors introduced by this change).

- [ ] **Step 7: Commit**

```bash
cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py
git add src/agentsh_secure_sandbox/core/types.py tests/test_config.py
git commit -m "feat(types): add BlockedSocketFamily model + seccomp_details.blocked_socket_families field

Mirrors the TS secure-sandbox v0.5.0 surface. YAML emission lands next.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>"
```

---

## Task 2: YAML emission for `blocked_socket_families`

**Files:**
- Modify: `src/agentsh_secure_sandbox/core/config.py:278` (add emission block at end of existing `seccomp_details` branch)
- Test: `tests/test_config.py` (five new tests immediately after the model tests added in Task 1)

- [ ] **Step 1: Write the five failing emission tests**

Append to `tests/test_config.py` directly below the model tests added in Task 1:

```python
def test_blocked_socket_families_omitted():
    """When blocked_socket_families is None, no `blocked_socket_families` key is emitted."""
    cfg = SecureConfig(server_config=ServerConfig(seccomp_details=SeccompDetailsConfig(
        execve=True,
    )))
    result = yaml.safe_load(generate_server_config(cfg))
    seccomp = result["sandbox"]["seccomp"]
    assert seccomp["enabled"] is True
    assert "blocked_socket_families" not in seccomp


def test_blocked_socket_families_empty_optout():
    """Explicit empty list emits `blocked_socket_families: []` and implicitly enables seccomp."""
    cfg = SecureConfig(server_config=ServerConfig(seccomp_details=SeccompDetailsConfig(
        blocked_socket_families=[],
    )))
    result = yaml.safe_load(generate_server_config(cfg))
    seccomp = result["sandbox"]["seccomp"]
    assert seccomp["enabled"] is True
    assert "blocked_socket_families" in seccomp
    assert seccomp["blocked_socket_families"] == []


def test_blocked_socket_families_populated():
    """Populated list emits matching YAML; entries with action=None omit the action key."""
    cfg = SecureConfig(server_config=ServerConfig(seccomp_details=SeccompDetailsConfig(
        blocked_socket_families=[
            BlockedSocketFamily(family="AF_VSOCK", action="log_and_kill"),
            BlockedSocketFamily(family="AF_ALG"),
            BlockedSocketFamily(family="38", action="errno"),
        ],
    )))
    result = yaml.safe_load(generate_server_config(cfg))
    families = result["sandbox"]["seccomp"]["blocked_socket_families"]
    assert families == [
        {"family": "AF_VSOCK", "action": "log_and_kill"},
        {"family": "AF_ALG"},
        {"family": "38", "action": "errno"},
    ]
    # Explicit shape check — entry index 1 must NOT carry an `action` key.
    assert "action" not in families[1]


def test_blocked_socket_families_implicit_seccomp_enable():
    """Passing only blocked_socket_families (no execve/file_monitor) implicitly enables seccomp."""
    cfg = SecureConfig(server_config=ServerConfig(seccomp_details=SeccompDetailsConfig(
        blocked_socket_families=[BlockedSocketFamily(family="AF_VSOCK")],
    )))
    result = yaml.safe_load(generate_server_config(cfg))
    seccomp = result["sandbox"]["seccomp"]
    assert seccomp["enabled"] is True
    assert seccomp["blocked_socket_families"] == [{"family": "AF_VSOCK"}]


def test_blocked_socket_families_ptrace_precedence():
    """With ptrace enabled, seccomp.enabled stays False but blocked_socket_families is still emitted."""
    cfg = SecureConfig(server_config=ServerConfig(
        ptrace=PtraceConfig(enabled=True),
        seccomp_details=SeccompDetailsConfig(
            blocked_socket_families=[BlockedSocketFamily(family="AF_VSOCK", action="log")],
        ),
    ))
    result = yaml.safe_load(generate_server_config(cfg))
    seccomp = result["sandbox"]["seccomp"]
    assert seccomp["enabled"] is False
    assert seccomp["blocked_socket_families"] == [
        {"family": "AF_VSOCK", "action": "log"},
    ]
```

- [ ] **Step 2: Run the emission tests to verify they fail**

Run: `cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py && uv run pytest tests/test_config.py -k "blocked_socket_families" -v`

Expected: 5× FAIL. The first two and the implicit-enable test will fail with `KeyError: 'blocked_socket_families'` (or `assert "blocked_socket_families" in seccomp` failing). The populated and ptrace-precedence tests will fail similarly because the key is never written.

- [ ] **Step 3: Implement the YAML emission**

In `src/agentsh_secure_sandbox/core/config.py`, find the `seccomp_details` branch (starts at line 256) and the `file_monitor` handling that ends with `sec["file_monitor"] = fm_obj` at line 278. Immediately after that line — still inside `if sc.seccomp_details is not None:` — insert:

```python
            if sc.seccomp_details.blocked_socket_families is not None:
                sec["blocked_socket_families"] = [
                    {
                        "family": entry.family,
                        **({"action": entry.action} if entry.action is not None else {}),
                    }
                    for entry in sc.seccomp_details.blocked_socket_families
                ]
```

Indentation must match the surrounding block (`if sc.seccomp_details.file_monitor is not None:` at line 266 — eight leading spaces inside the `if sc.seccomp_details is not None:` branch).

- [ ] **Step 4: Run the emission tests to verify they pass**

Run: `cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py && uv run pytest tests/test_config.py -k "blocked_socket_families" -v`

Expected: 5× PASS.

- [ ] **Step 5: Run the full config test file to confirm no regressions**

Run: `cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py && uv run pytest tests/test_config.py -v`

Expected: all tests pass (the four model tests from Task 1 + five emission tests from this task + every previously existing test in the file).

- [ ] **Step 6: Commit**

```bash
cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py
git add src/agentsh_secure_sandbox/core/config.py tests/test_config.py
git commit -m "feat(config): emit blocked_socket_families with tri-state semantics

None -> key omitted (agentsh applies 12-family default).
[] -> emitted as empty list (explicit opt-out).
Populated -> emitted verbatim, action key omitted per-entry when None.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>"
```

---

## Task 3: Bump pinned agentsh to v0.19.0 in `integrity.py`

**Files:**
- Modify: `src/agentsh_secure_sandbox/core/integrity.py:3-13` (`PINNED_VERSION` + new `CHECKSUMS` entry)
- Test: `tests/test_integrity.py:11-12, 21-23, 32-33, 53-62` (bump literals)

- [ ] **Step 1: Update the integrity tests first (failing-test step)**

In `tests/test_integrity.py`, apply these edits in place (preserving the test names):

Line 12 (inside `test_pinned_version_exists`): change `"0.18.3"` → `"0.19.0"`.

Lines 22–23 (inside `test_binary_url_default`):
```python
    url = binary_url("0.19.0", "linux_amd64")
    assert "agentsh_0.19.0_linux_amd64.tar.gz" in url
```

Line 33 (inside `test_get_checksum`): change `get_checksum("0.18.3", "linux_amd64")` → `get_checksum("0.19.0", "linux_amd64")`.

Lines 53–62 — replace the existing two `0.18.3`-versioned tests with the same shape on `0.19.0`. Rename the function to make the version explicit:

```python
def test_pinned_version_is_0_19_0():
    assert PINNED_VERSION == "0.19.0"


def test_checksums_include_0_19_0():
    assert "0.19.0" in CHECKSUMS
    assert "linux_amd64" in CHECKSUMS["0.19.0"]
    assert "linux_arm64" in CHECKSUMS["0.19.0"]
    assert CHECKSUMS["0.19.0"]["linux_amd64"] == "04c1b0e958a6e9027fc85d4625bec765e459f191dc16c4c5a04468c867f71d85"
    assert CHECKSUMS["0.19.0"]["linux_arm64"] == "89cecae90e6511cf96019cca948e3b5142dce329349141eb838979a243dda9cd"
```

- [ ] **Step 2: Run integrity tests to verify they fail**

Run: `cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py && uv run pytest tests/test_integrity.py -v`

Expected: at least 5 failures (`test_pinned_version_exists`, `test_binary_url_default`, `test_get_checksum`, `test_pinned_version_is_0_19_0`, `test_checksums_include_0_19_0`). The `0.18.3` checksums are no longer the pinned version, so any assertion that depended on `PINNED_VERSION == "0.18.3"` will fail.

- [ ] **Step 3: Bump `PINNED_VERSION` and add the new checksums entry**

In `src/agentsh_secure_sandbox/core/integrity.py`, change line 3 from:

```python
PINNED_VERSION = "0.18.3"
```

to:

```python
PINNED_VERSION = "0.19.0"
```

And add a new top entry at the start of the `CHECKSUMS` dict (currently begins at line 5 with the `0.18.3` block). Insert immediately after the opening brace of `CHECKSUMS = {`:

```python
    "0.19.0": {
        "linux_amd64": "04c1b0e958a6e9027fc85d4625bec765e459f191dc16c4c5a04468c867f71d85",
        "linux_arm64": "89cecae90e6511cf96019cca948e3b5142dce329349141eb838979a243dda9cd",
    },
```

The existing `0.18.3`, `0.18.2`, `0.17.0`, `0.16.9`, and `0.16.2` entries stay untouched so callers pinning via `agentsh_version` continue to work.

- [ ] **Step 4: Run integrity tests to verify they pass**

Run: `cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py && uv run pytest tests/test_integrity.py -v`

Expected: all tests pass.

- [ ] **Step 5: Commit**

```bash
cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py
git add src/agentsh_secure_sandbox/core/integrity.py tests/test_integrity.py
git commit -m "chore(integrity): bump pinned agentsh to v0.19.0

Adds linux_amd64 + linux_arm64 SHA-256 checksums for the v0.19.0
release. Older entries retained for callers that pin via agentsh_version.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>"
```

---

## Task 4: Bump default `agentsh_version` in the freestyle adapter

**Files:**
- Modify: `src/agentsh_secure_sandbox/adapters/freestyle/_defaults.py:133`
- Test: `tests/test_freestyle_defaults.py:113, 145`
- Test: `tests/test_freestyle_client.py:531, 536`

The freestyle adapter has a hard-coded default for `agentsh_version` and an install-script template that interpolates it into `AGENTSH_VERSION="..."`. Tests assert both surfaces.

- [ ] **Step 1: Update freestyle tests first (failing-test step)**

In `tests/test_freestyle_defaults.py`:

Line 113 — change `assert opts.agentsh_version == "0.18.3"` → `assert opts.agentsh_version == "0.19.0"`.

Line 145 — change `assert 'AGENTSH_VERSION="0.18.3"' in content` → `assert 'AGENTSH_VERSION="0.19.0"' in content`.

In `tests/test_freestyle_client.py`:

Line 531 — change `opts=FreestyleConfigureOptions(agentsh_version="0.18.3")` → `opts=FreestyleConfigureOptions(agentsh_version="0.19.0")`.

Line 536 — change `assert 'AGENTSH_VERSION="0.18.3"' in install_script` → `assert 'AGENTSH_VERSION="0.19.0"' in install_script`.

- [ ] **Step 2: Run the freestyle tests to verify they fail**

Run: `cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py && uv run pytest tests/test_freestyle_defaults.py tests/test_freestyle_client.py -v`

Expected: at least 2 failures referencing `0.18.3` vs `0.19.0` mismatches. (The line-145/536 assertions will fail because `_defaults.py` still produces a script containing `AGENTSH_VERSION="0.18.3"`. Line 113 will fail because the dataclass default is still `0.18.3`. Line 531 sets the version explicitly to `0.19.0`, but the installer script for that path will still substitute `0.19.0` into the template, so the line-536 assertion may already pass — it depends on whether the test passes `0.19.0` through to the script template. Verify by reading the failure output.)

- [ ] **Step 3: Bump the default in `_defaults.py`**

In `src/agentsh_secure_sandbox/adapters/freestyle/_defaults.py`, change line 133 from:

```python
    agentsh_version: str = "0.18.3"
```

to:

```python
    agentsh_version: str = "0.19.0"
```

Lines 52–53 of the same file already use `{version}` interpolation against this field, so the install-script template picks up the new default automatically without further edits.

- [ ] **Step 4: Run the freestyle tests to verify they pass**

Run: `cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py && uv run pytest tests/test_freestyle_defaults.py tests/test_freestyle_client.py -v`

Expected: all tests pass.

- [ ] **Step 5: Commit**

```bash
cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py
git add src/agentsh_secure_sandbox/adapters/freestyle/_defaults.py tests/test_freestyle_defaults.py tests/test_freestyle_client.py
git commit -m "chore(freestyle): default agentsh_version to v0.19.0

Picks up the v0.19.0 install-script default. Tests bumped accordingly.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>"
```

---

## Task 5: README note on default socket family blocking

**Files:**
- Modify: `README.md`

No tests — this is a docs-only change. Read the README first to find the seccomp/security section the note belongs in.

- [ ] **Step 1: Locate the relevant section in `README.md`**

Run: `cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py && grep -n "seccomp\|security\|configuration" README.md | head -20`

Pick the configuration section closest to existing seccomp/security content. If there is a "Security" or "Configuration" subsection that already discusses seccomp, add the note there. Otherwise, add it as a small subsection under the existing security/configuration coverage.

- [ ] **Step 2: Add the note**

Insert (under the most appropriate existing section, e.g. just below where `SeccompDetailsConfig` is referenced or where seccomp policy is described):

````markdown
### Default socket family blocking

Starting with agentsh v0.19.0, `secure_sandbox` blocks 12 niche AF_* socket
families by default at `EAFNOSUPPORT` (AF_ALG, AF_VSOCK, AF_RDS, AF_TIPC,
AF_KCM, AF_X25, AF_AX25, AF_NETROM, AF_ROSE, AF_DECnet, AF_APPLETALK,
AF_IPX). These are kernel attack surfaces that few applications need.

Override the list:

```python
from agentsh_secure_sandbox.core.types import (
    BlockedSocketFamily,
    SeccompDetailsConfig,
    ServerConfig,
)

server_config = ServerConfig(
    seccomp_details=SeccompDetailsConfig(
        blocked_socket_families=[
            BlockedSocketFamily(family="AF_VSOCK", action="log_and_kill"),
            BlockedSocketFamily(family="AF_ALG"),
        ],
    ),
)
```

Opt out entirely with `blocked_socket_families=[]`. See upstream agentsh
`docs/seccomp.md` for the canonical default list and audit event shape.
````

- [ ] **Step 3: Verify the README still renders cleanly**

Run: `cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py && python -c "import pathlib; print(pathlib.Path('README.md').read_text()[:500])"`

Spot-check that the section was inserted at a reasonable location and that surrounding markdown is intact.

- [ ] **Step 4: Commit**

```bash
cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py
git add README.md
git commit -m "docs(readme): note default socket family blocking + override knob

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>"
```

---

## Task 6: Final verification

This task runs no new tests of its own — it confirms the full suite passes after all earlier tasks land, and that nothing else in the repository still references `0.18.3` as the pinned version.

- [ ] **Step 1: Run the full pytest suite**

Run: `cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py && uv run pytest -x`

Expected: every test passes. If anything fails, it likely missed a `0.18.3` literal — find and fix.

- [ ] **Step 2: Confirm no stale `0.18.3` literals remain in source or test code**

Run: `cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py && grep -rn "0\.18\.3" --include="*.py" --include="*.toml" src/ tests/`

Expected: no results. If any results appear, decide case-by-case:
- If the literal is genuinely a "supported older version" reference inside `CHECKSUMS` (the `0.18.3` block we kept), it is allowed — but only inside `integrity.py`.
- Anything else should be bumped to `0.19.0`.

If a fix is needed, edit the file, run `uv run pytest -x` again, and commit:

```bash
git add <file>
git commit -m "chore: scrub stale 0.18.3 literal from <area>"
```

- [ ] **Step 3: Run mypy on the whole `src/` tree**

Run: `cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py && uv run mypy src/`

Expected: clean output (or unchanged baseline — no new errors introduced by this PR).

- [ ] **Step 4: Confirm git history is clean**

Run: `cd /home/eran/work/canyonroad/agentsh-secure-sandbox-py && git log --oneline -10`

Expected: five new commits on top of the design-doc commit (`docs(specs): socket family blocking + agentsh v0.19.0 (Python port)`):
1. `feat(types): add BlockedSocketFamily model + seccomp_details.blocked_socket_families field`
2. `feat(config): emit blocked_socket_families with tri-state semantics`
3. `chore(integrity): bump pinned agentsh to v0.19.0`
4. `chore(freestyle): default agentsh_version to v0.19.0`
5. `docs(readme): note default socket family blocking + override knob`

If a stray fix from Step 2 was required, there will be a sixth `chore: scrub stale 0.18.3 literal …` commit.

---

## Summary

| Task | Outcome | Files touched |
|---|---|---|
| 1 | New `BlockedSocketFamily` model + field on `SeccompDetailsConfig` | `core/types.py`, `tests/test_config.py` |
| 2 | Tri-state YAML emission with five behavioral tests | `core/config.py`, `tests/test_config.py` |
| 3 | `PINNED_VERSION` bump + new checksums | `core/integrity.py`, `tests/test_integrity.py` |
| 4 | Freestyle adapter default version bump | `adapters/freestyle/_defaults.py`, `tests/test_freestyle_defaults.py`, `tests/test_freestyle_client.py` |
| 5 | README note | `README.md` |
| 6 | Full-suite verification + scrub for stale `0.18.3` literals | (verification only) |
