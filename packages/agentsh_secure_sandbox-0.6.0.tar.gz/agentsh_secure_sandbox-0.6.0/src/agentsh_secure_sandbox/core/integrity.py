from __future__ import annotations

PINNED_VERSION = "0.19.0"

CHECKSUMS: dict[str, dict[str, str]] = {
    "0.19.0": {
        "linux_amd64": "04c1b0e958a6e9027fc85d4625bec765e459f191dc16c4c5a04468c867f71d85",
        "linux_arm64": "89cecae90e6511cf96019cca948e3b5142dce329349141eb838979a243dda9cd",
    },
    "0.18.3": {
        "linux_amd64": "07612c7062e843d0375519c08ac0c590cba99c990c0350ee4bade1fca34f0ddd",
        "linux_arm64": "22bc02e32877cb75df45a2a0474cc0afe87709634d6f6ed2561b9bafdbc75e81",
    },
    "0.18.2": {
        "linux_amd64": "5b277f4565b8beecee1011c7683f58b51ac25ae8cc7c7d2e1f3f7433bdd3b825",
        "linux_arm64": "2dcbc30ee9af3b8ac0212d35ec855c3fe038febf503fc3dcf7a519ffc6d0d44d",
    },
    "0.17.0": {
        "linux_amd64": "f8b710e29a45e104b93dd922540bd877762d1c68005a62c871216055b6db82b4",
        "linux_arm64": "4de3338f5d060d289dfbbf77c9172a573f4c06ca6f725fa619e408d75b17bd73",
    },
    "0.16.9": {
        "linux_amd64": "37b7be738291e90957a13653c5bb60b3cbbf9ab5abbc932e00e679a431f9064e",
        "linux_arm64": "4a8e29457241a329bca09d45830542de1c1c98976332234294a14d818c38fd72",
    },
    "0.16.2": {
        "linux_amd64": "7ff357066a61694626d4c19afa92fdf368318bced9be90391cc2f3808976f995",
        "linux_arm64": "a48b3e4a60804cca98326619a68409e8ee83556d69ee2cf5d574e4361e0c19c6",
    },
}


def get_checksum(version: str, arch: str) -> str:
    return CHECKSUMS[version][arch]


def binary_url(version: str, arch: str, override: str | None = None) -> str:
    if override:
        return override
    return (
        f"https://github.com/canyonroad/agentsh/releases/download/"
        f"v{version}/agentsh_{version}_{arch}.tar.gz"
    )


def build_verify_command(file_path: str, expected_checksum: str) -> str:
    """Build a shell command to verify SHA256 checksum of a file.

    Returns multiple commands joined with || to try different checksum tools.
    """
    import shlex

    safe_path = shlex.quote(file_path)
    safe_checksum = shlex.quote(expected_checksum)
    return (
        f'test "$(sha256sum {safe_path} 2>/dev/null | awk \'{{print $1}}\')" = {safe_checksum} || '
        f'test "$(shasum -a 256 {safe_path} 2>/dev/null | awk \'{{print $1}}\')" = {safe_checksum} || '
        f'test "$(openssl dgst -sha256 -r {safe_path} 2>/dev/null | awk \'{{print $1}}\')" = {safe_checksum}'
    )
