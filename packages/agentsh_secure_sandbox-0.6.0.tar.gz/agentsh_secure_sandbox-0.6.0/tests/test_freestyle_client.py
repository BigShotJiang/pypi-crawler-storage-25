"""Unit tests for FreestyleClient."""

from __future__ import annotations

from typing import Any

import httpx
import pytest

from agentsh_secure_sandbox.adapters.freestyle._client import (
    FreestyleClient,
    FreestyleError,
)
from agentsh_secure_sandbox.adapters.freestyle._spec import FreestyleVmSpec
from agentsh_secure_sandbox.adapters.freestyle._vm import FreestyleVm


class TestFreestyleError:
    def test_error_is_runtime_error(self) -> None:
        err = FreestyleError("boom")
        assert isinstance(err, RuntimeError)
        assert str(err) == "boom"

    def test_error_carries_status_and_body(self) -> None:
        err = FreestyleError("bad", status=404, body='{"error": "not found"}')
        assert err.status == 404
        assert err.body == '{"error": "not found"}'

    def test_error_status_and_body_default_none(self) -> None:
        err = FreestyleError("boom")
        assert err.status is None
        assert err.body is None


class TestFreestyleClientConstruction:
    def test_accepts_explicit_api_key(self) -> None:
        client = FreestyleClient(api_key="sk-test")
        assert client.api_key == "sk-test"

    def test_reads_api_key_from_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("FREESTYLE_API_KEY", "sk-env")
        client = FreestyleClient()
        assert client.api_key == "sk-env"

    def test_raises_if_no_api_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("FREESTYLE_API_KEY", raising=False)
        with pytest.raises(FreestyleError, match="api_key"):
            FreestyleClient()

    def test_default_base_url(self) -> None:
        client = FreestyleClient(api_key="sk-test")
        assert client.base_url == "https://api.freestyle.sh"

    def test_custom_base_url(self) -> None:
        client = FreestyleClient(api_key="sk-test", base_url="https://staging.freestyle.sh/")
        # Trailing slash stripped for consistent URL joining
        assert client.base_url == "https://staging.freestyle.sh"


class TestFreestyleClientAuth:
    async def test_sets_bearer_auth_header(self) -> None:
        captured: dict[str, httpx.Request] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["req"] = request
            return httpx.Response(200, json={"ok": True})

        transport = httpx.MockTransport(handler)
        client = FreestyleClient(api_key="sk-test", transport=transport)
        try:
            await client._get("/v1/ping")
        finally:
            await client.aclose()
        assert captured["req"].headers["authorization"] == "Bearer sk-test"

    async def test_aclose_is_idempotent(self) -> None:
        client = FreestyleClient(api_key="sk-test")
        await client.aclose()
        await client.aclose()  # should not raise

    async def test_async_context_manager(self) -> None:
        async with FreestyleClient(api_key="sk-test") as client:
            assert client.api_key == "sk-test"
        # After exit, the underlying httpx client is closed
        assert client._http.is_closed


class TestVmsNamespaceCreate:
    async def test_create_posts_to_v1_vms_with_body(self) -> None:
        captured: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["method"] = request.method
            captured["url"] = str(request.url)
            import json as _json
            captured["body"] = _json.loads(request.content) if request.content else None
            return httpx.Response(
                200, json={"vmId": "vm_123", "status": "running"}
            )

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            spec = FreestyleVmSpec(apt_deps=["curl"])
            vm = await client.vms.create(spec=spec)

        assert captured["method"] == "POST"
        assert captured["url"].endswith("/v1/vms")
        assert captured["body"] == {"aptDeps": ["curl"]}
        assert isinstance(vm, FreestyleVm)
        assert vm.vm_id == "vm_123"

    async def test_create_accepts_dict_spec(self) -> None:
        captured: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            import json as _json
            captured["body"] = _json.loads(request.content) if request.content else None
            return httpx.Response(200, json={"vmId": "vm_abc"})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = await client.vms.create(spec={"aptDeps": ["jq"]})

        # Dict went through FreestyleVmSpec validation and serialization
        assert captured["body"] == {"aptDeps": ["jq"]}
        assert vm.vm_id == "vm_abc"

    async def test_create_with_none_spec_sends_empty_body(self) -> None:
        captured: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            import json as _json
            captured["body"] = _json.loads(request.content) if request.content else None
            return httpx.Response(200, json={"vmId": "vm_x"})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            await client.vms.create(spec=None)

        assert captured["body"] == {}

    async def test_create_raises_freestyle_error_on_non_2xx(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(500, text="internal boom")

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            with pytest.raises(FreestyleError) as exc_info:
                await client.vms.create(spec=FreestyleVmSpec())
        assert exc_info.value.status == 500
        assert exc_info.value.body == "internal boom"

    async def test_create_unwraps_vm_envelope(self) -> None:
        """Some Freestyle endpoints wrap the VM in ``{vm: {...}}``."""
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200, json={"vm": {"vmId": "vm_envelope", "status": "running"}}
            )

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = await client.vms.create()
        assert vm.vm_id == "vm_envelope"
        assert vm.raw == {"vmId": "vm_envelope", "status": "running"}

    async def test_create_handles_null_vm_envelope(self) -> None:
        """Defensive: ``{vm: null, vmId: ...}`` falls through to flat form."""
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"vm": None, "vmId": "vm_flat"})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = await client.vms.create()
        assert vm.vm_id == "vm_flat"


class TestVmsNamespaceGetAndRef:
    async def test_get_fetches_by_id(self) -> None:
        captured: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            captured["method"] = request.method
            return httpx.Response(200, json={"vmId": "vm_get"})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = await client.vms.get("vm_get")

        assert captured["method"] == "GET"
        assert captured["url"].endswith("/v1/vms/vm_get")
        assert vm.vm_id == "vm_get"

    async def test_ref_does_not_call_api(self) -> None:
        calls = 0

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal calls
            calls += 1
            return httpx.Response(200, json={})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_ref")
        assert calls == 0
        assert vm.vm_id == "vm_ref"


class TestFreestyleVmExec:
    async def test_exec_posts_command_to_exec_await(self) -> None:
        captured: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            import json as _json
            captured["body"] = _json.loads(request.content) if request.content else None
            return httpx.Response(
                200,
                json={"stdout": "hello\n", "stderr": "", "statusCode": 0},
            )

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            result = await vm.exec("echo hello")

        assert captured["url"].endswith("/v1/vms/vm_test/exec-await")
        assert captured["body"] == {
            "command": "echo hello",
            "terminal": None,
            "timeoutMs": None,
        }
        assert result["stdout"] == "hello\n"
        assert result["statusCode"] == 0

    async def test_exec_passes_timeout_ms(self) -> None:
        captured: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            import json as _json
            captured["body"] = _json.loads(request.content)
            return httpx.Response(200, json={"statusCode": 0})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            await vm.exec("sleep 1", timeout_ms=5000)

        assert captured["body"]["timeoutMs"] == 5000

    async def test_exec_raises_on_http_error(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(502, text="upstream")

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            with pytest.raises(FreestyleError) as exc_info:
                await vm.exec("echo hi")
        assert exc_info.value.status == 502


class TestFreestyleVmFiles:
    async def test_write_file_base64_encodes_string_content(self) -> None:
        import base64 as _b64
        captured: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["method"] = request.method
            captured["url"] = str(request.url)
            import json as _json
            captured["body"] = _json.loads(request.content)
            return httpx.Response(200, json={})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            await vm.write_file("/tmp/hi.txt", "hello world")

        assert captured["method"] == "PUT"
        assert captured["url"].endswith("/v1/vms/vm_test/files/%2Ftmp%2Fhi.txt")
        assert captured["body"]["encoding"] == "base64"
        assert _b64.b64decode(captured["body"]["content"]) == b"hello world"

    async def test_write_file_accepts_bytes(self) -> None:
        import base64 as _b64
        captured: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            import json as _json
            captured["body"] = _json.loads(request.content)
            return httpx.Response(200, json={})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            await vm.write_file("/tmp/bin", b"\x00\x01\x02")

        assert _b64.b64decode(captured["body"]["content"]) == b"\x00\x01\x02"

    async def test_read_file_decodes_base64_response(self) -> None:
        import base64 as _b64

        def handler(request: httpx.Request) -> httpx.Response:
            encoded = _b64.b64encode(b"file body").decode("ascii")
            return httpx.Response(200, json={"content": encoded, "encoding": "base64"})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            content = await vm.read_file("/tmp/hi.txt")
        assert content == "file body"

    async def test_read_file_passes_through_utf8_encoding(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"content": "hello", "encoding": "utf-8"})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            content = await vm.read_file("/tmp/hi.txt")
        assert content == "hello"

    async def test_read_file_raises_on_404(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(404, text="not found")

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            with pytest.raises(FreestyleError) as exc_info:
                await vm.read_file("/nope")
        assert exc_info.value.status == 404

    async def test_file_exists_returns_true_on_exit_zero(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"statusCode": 0, "stdout": "", "stderr": ""})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            assert await vm.file_exists("/exists") is True

    async def test_file_exists_returns_false_on_nonzero_exit(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"statusCode": 1, "stdout": "", "stderr": ""})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            assert await vm.file_exists("/nope") is False

    async def test_file_exists_returns_false_on_freestyle_error(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(500, text="boom")

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            assert await vm.file_exists("/any") is False

    async def test_write_file_escapes_hash_in_path(self) -> None:
        """Paths containing ``#`` must not be silently truncated as URL fragments."""
        captured: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, json={})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            await vm.write_file("/tmp/file#1.txt", "data")

        # The '#' must be percent-encoded so the server sees the full filename
        assert "file#1.txt" not in captured["url"] or "%23" in captured["url"]
        assert captured["url"].endswith("/v1/vms/vm_test/files/%2Ftmp%2Ffile%231.txt")

    async def test_write_file_escapes_query_chars_in_path(self) -> None:
        """Paths containing ``?`` must not become query strings."""
        captured: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["url"] = str(request.url)
            return httpx.Response(200, json={})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            await vm.write_file("/tmp/log?old=yes", "data")

        assert captured["url"].endswith("/v1/vms/vm_test/files/%2Ftmp%2Flog%3Fold%3Dyes")

    async def test_file_exists_returns_false_on_missing_status_code(self) -> None:
        """If the API omits statusCode, treat as failure (safer default)."""
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"stdout": "", "stderr": ""})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            assert await vm.file_exists("/any") is False


class TestFreestyleVmStop:
    async def test_stop_calls_delete_endpoint(self) -> None:
        captured: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["method"] = request.method
            captured["url"] = str(request.url)
            return httpx.Response(200, json={})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            await vm.stop()
        assert captured["method"] == "POST"
        assert captured["url"].endswith("/v1/vms/vm_test/stop")


class TestFreestyleVmInstall:
    async def test_wait_for_agentsh_install_succeeds_when_marker_present(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200, json={"statusCode": 0, "stdout": "ok", "stderr": ""}
            )

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            await vm.wait_for_agentsh_install(timeout=5.0)

    async def test_wait_for_agentsh_install_times_out_when_never_ready(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200, json={"statusCode": 1, "stdout": "", "stderr": "no such file"}
            )

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            with pytest.raises(FreestyleError, match="install did not complete"):
                await vm.wait_for_agentsh_install(timeout=0.05, poll_interval=0.01)

    async def test_wait_for_agentsh_install_tolerates_transient_freestyle_errors(self) -> None:
        calls = {"n": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            calls["n"] += 1
            if calls["n"] < 3:
                return httpx.Response(503, text="not yet")
            return httpx.Response(
                200, json={"statusCode": 0, "stdout": "ok", "stderr": ""}
            )

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            await vm.wait_for_agentsh_install(timeout=5.0, poll_interval=0.01)
        assert calls["n"] >= 3

    async def test_wait_for_agentsh_install_passes_timeout_ms_to_inner_exec(self) -> None:
        """The inner exec must carry timeout_ms=5000 so a wedged VM can't hang the outer loop."""
        captured: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            import json as _json
            captured["body"] = _json.loads(request.content) if request.content else None
            return httpx.Response(
                200, json={"statusCode": 0, "stdout": "ok", "stderr": ""}
            )

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = client.vms.ref("vm_test")
            await vm.wait_for_agentsh_install(timeout=5.0)

        assert captured["body"] is not None
        assert captured["body"]["timeoutMs"] == 5000


class TestCreateSandboxVm:
    async def test_create_sandbox_vm_bakes_agentsh_and_waits_for_install(self) -> None:
        calls: list[dict[str, Any]] = []

        def handler(request: httpx.Request) -> httpx.Response:
            calls.append({"method": request.method, "path": request.url.path})
            if request.method == "POST" and request.url.path == "/v1/vms":
                import json as _json
                body = _json.loads(request.content) if request.content else {}
                # The create request must contain the baked-in install script
                files = body.get("additionalFiles", {})
                assert "/opt/install-agentsh.sh" in files
                return httpx.Response(200, json={"vmId": "vm_sandbox"})
            if request.method == "POST" and "exec-await" in request.url.path:
                return httpx.Response(
                    200, json={"statusCode": 0, "stdout": "ok", "stderr": ""}
                )
            return httpx.Response(200, json={})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = await client.create_sandbox_vm(install_timeout=5.0)

        assert vm.vm_id == "vm_sandbox"
        # Should have POSTed to /v1/vms, then polled install marker
        paths = [c["path"] for c in calls]
        assert "/v1/vms" in paths
        assert any("exec-await" in p for p in paths)

    async def test_create_sandbox_vm_accepts_custom_options(self) -> None:
        from agentsh_secure_sandbox.adapters.freestyle._defaults import (
            FreestyleConfigureOptions,
        )

        captured: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            if request.method == "POST" and request.url.path == "/v1/vms":
                import json as _json
                captured["body"] = _json.loads(request.content)
                return httpx.Response(200, json={"vmId": "vm_x"})
            return httpx.Response(
                200, json={"statusCode": 0, "stdout": "ok", "stderr": ""}
            )

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            await client.create_sandbox_vm(
                opts=FreestyleConfigureOptions(agentsh_version="0.19.0"),
                install_timeout=5.0,
            )

        install_script = captured["body"]["additionalFiles"]["/opt/install-agentsh.sh"]["content"]
        assert 'AGENTSH_VERSION="0.19.0"' in install_script

    async def test_create_sandbox_vm_accepts_dict_spec(self) -> None:
        """A dict ``spec`` is validated through ``FreestyleVmSpec`` then baked."""
        import json as _json

        captured: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            if request.method == "POST" and request.url.path == "/v1/vms":
                captured["body"] = _json.loads(request.content)
                return httpx.Response(200, json={"vmId": "vm_dict"})
            return httpx.Response(
                200, json={"statusCode": 0, "stdout": "ok", "stderr": ""}
            )

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            vm = await client.create_sandbox_vm(
                spec={"vcpus": 2},
                install_timeout=5.0,
            )

        assert vm.vm_id == "vm_dict"
        body = captured["body"]
        # Dict was validated → spec → .snapshot() → configured.
        # After .snapshot(), the request body uses a top-level ``snapshot``
        # key to hold the snapshot-mode flags including ``vcpus``.
        assert body["snapshot"]["vcpus"] == 2
        assert "/opt/install-agentsh.sh" in body["additionalFiles"]

    async def test_create_sandbox_vm_stops_vm_on_install_failure(self) -> None:
        """If ``wait_for_agentsh_install`` fails the VM is stopped, not leaked."""
        stop_called = False

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal stop_called
            if request.method == "POST" and request.url.path == "/v1/vms":
                return httpx.Response(200, json={"vmId": "vm_leak"})
            if request.method == "POST" and request.url.path.endswith("/exec-await"):
                # Never ready: always return non-zero so the install
                # loop exhausts its timeout budget.
                return httpx.Response(
                    200, json={"statusCode": 1, "stdout": "", "stderr": "not ready"}
                )
            if request.method == "POST" and request.url.path == "/v1/vms/vm_leak/stop":
                stop_called = True
                return httpx.Response(200, json={})
            return httpx.Response(200, json={})

        transport = httpx.MockTransport(handler)
        async with FreestyleClient(api_key="sk-test", transport=transport) as client:
            with pytest.raises(FreestyleError):
                await client.create_sandbox_vm(install_timeout=0.2)

        assert stop_called, "expected vm.stop() to be called after install failure"
