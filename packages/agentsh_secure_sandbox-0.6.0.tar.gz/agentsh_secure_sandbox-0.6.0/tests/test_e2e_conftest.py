from __future__ import annotations

import sys
import types

import pytest

dotenv = types.ModuleType("dotenv")


def _load_dotenv(*args, **kwargs) -> None:
    return None


dotenv.load_dotenv = _load_dotenv
sys.modules.setdefault("dotenv", dotenv)

from tests.e2e import conftest as e2e_conf  # noqa: E402
from agentsh_secure_sandbox.core.types import ExecResult  # noqa: E402


def _env(**overrides: str) -> dict[str, str]:
    env = {
        "E2B_API_KEY": "",
        "DAYTONA_API_KEY": "",
        "DAYTONA_API_URL": "",
        "DAYTONA_TARGET": "",
        "OPENAI_API_KEY": "",
        "VERCEL_TOKEN": "",
        "VERCEL_PROJECT_ID": "",
        "VERCEL_TEAM_ID": "",
        "CLOUDFLARE_WORKER_URL": "",
        "CLOUDFLARE_SANDBOX_WORKER_URL": "",
        "CLOUDFLARE_API_TOKEN": "",
        "BLAXEL_API_KEY": "",
        "BL_API_KEY": "",
        "BL_WORKSPACE": "",
        "SPRITES_TOKEN": "",
        "SPRITES_ORG": "",
        "SPRITES_NAME": "",
        "FLY_API_TOKEN": "",
        "MODAL_TOKEN_ID": "",
        "MODAL_TOKEN_SECRET": "",
        "RUNLOOP_API_KEY": "",
        "EXE_VM_NAME": "",
        "FREESTYLE_API_KEY": "",
    }
    env.update(overrides)
    return env


def _refresh(monkeypatch, env: dict[str, str], sdk_name: str) -> None:
    monkeypatch.setattr(e2e_conf, "_sdk_available", lambda name: name == sdk_name)
    monkeypatch.setattr(e2e_conf, "_build_env", lambda: env)
    e2e_conf._refresh_e2e_state()


def test_daytona_repo_available_accepts_legacy_sdk(monkeypatch) -> None:
    env = _env(DAYTONA_API_KEY="dtn_test")
    _refresh(monkeypatch, env, "daytona_sdk")

    assert e2e_conf._daytona_repo_available(env) is True
    assert e2e_conf.skip_no_daytona is e2e_conf.skip_no_daytona_repo
    assert e2e_conf.skip_no_daytona.args == (False,)
    assert e2e_conf._daytona_openai_available(env) is False
    assert e2e_conf.skip_no_daytona_openai.args == (True,)


def test_daytona_openai_available_requires_new_sdk(monkeypatch) -> None:
    env = _env(DAYTONA_API_KEY="dtn_test")

    _refresh(monkeypatch, env, "daytona")

    assert e2e_conf._daytona_openai_available(env) is True
    assert e2e_conf.skip_no_daytona_openai is not e2e_conf.skip_no_daytona_repo
    assert e2e_conf.skip_no_daytona_openai.args == (False,)
    assert e2e_conf.skip_no_daytona.args == (False,)


def test_cloudflare_exec_available_uses_legacy_url(monkeypatch) -> None:
    env = _env(
        CLOUDFLARE_WORKER_URL="https://exec.example.workers.dev",
        CLOUDFLARE_API_TOKEN="token",
    )
    _refresh(monkeypatch, env, "aiohttp")

    assert e2e_conf._cloudflare_exec_available(env) is True
    assert e2e_conf.skip_no_cloudflare is e2e_conf.skip_no_cloudflare_exec
    assert e2e_conf.skip_no_cloudflare.args == (False,)
    assert e2e_conf._cloudflare_sandbox_available(env) is False
    assert e2e_conf.skip_no_cloudflare_sandbox.args == (True,)


def test_cloudflare_sandbox_available_requires_sandbox_url(monkeypatch) -> None:
    env = _env(
        CLOUDFLARE_WORKER_URL="https://exec.example.workers.dev",
        CLOUDFLARE_SANDBOX_WORKER_URL="https://sandbox.example.workers.dev",
        CLOUDFLARE_API_TOKEN="token",
    )
    _refresh(monkeypatch, env, "aiohttp")

    assert e2e_conf._cloudflare_sandbox_available(env) is True
    assert e2e_conf.skip_no_cloudflare_sandbox.args == (False,)
    assert e2e_conf.skip_no_cloudflare.args == (False,)


def test_cloudflare_exec_marker_stays_tied_to_worker_url(monkeypatch) -> None:
    env = _env(
        CLOUDFLARE_SANDBOX_WORKER_URL="https://sandbox.example.workers.dev",
        CLOUDFLARE_API_TOKEN="token",
    )
    _refresh(monkeypatch, env, "aiohttp")

    assert e2e_conf._cloudflare_exec_available(env) is False
    assert e2e_conf.skip_no_cloudflare is e2e_conf.skip_no_cloudflare_exec
    assert e2e_conf.skip_no_cloudflare_exec.args == (True,)
    assert e2e_conf._cloudflare_sandbox_available(env) is True
    assert e2e_conf.skip_no_cloudflare_sandbox.args == (False,)


def test_sprites_available_uses_credentials_not_name(monkeypatch) -> None:
    env = _env(SPRITES_TOKEN="token")
    _refresh(monkeypatch, env, "sprites")

    assert e2e_conf.sprites_available is True
    assert e2e_conf.skip_no_sprites.args == (False,)


class _FakeSpritesNotFound(Exception):
    pass


class _FakeSpritesClient:
    def __init__(self, *, sprite=None, missing: Exception | None = None) -> None:
        self.sprite = sprite or object()
        self.missing = missing
        self.get_calls: list[str] = []
        self.create_calls: list[str] = []
        self.close_calls = 0

    def get_sprite(self, name: str):
        self.get_calls.append(name)
        if self.missing is not None:
            raise self.missing
        return self.sprite

    def create_sprite(self, name: str):
        self.create_calls.append(name)
        return self.sprite

    def close(self) -> None:
        self.close_calls += 1


def test_resolve_or_create_sprites_target_reuses_existing_target(monkeypatch) -> None:
    sprite = object()
    fake_client = _FakeSpritesClient(sprite=sprite)
    monkeypatch.setattr(e2e_conf, 'ENV', _env(SPRITES_NAME='existing-sprite'))
    monkeypatch.setattr(e2e_conf, 'build_sprites_client', lambda: fake_client)

    client, resolved_sprite, created = e2e_conf.resolve_or_create_sprites_target()

    assert client is fake_client
    assert resolved_sprite is sprite
    assert created is False
    assert fake_client.get_calls == ['existing-sprite']
    assert fake_client.create_calls == []


def test_resolve_or_create_sprites_target_falls_back_when_target_missing(monkeypatch) -> None:
    sprite = object()
    fake_client = _FakeSpritesClient(
        sprite=sprite,
        missing=_FakeSpritesNotFound("Resource not found for get sprite 'stale-sprite'"),
    )
    monkeypatch.setattr(e2e_conf, 'ENV', _env(SPRITES_NAME='stale-sprite'))
    monkeypatch.setattr(e2e_conf, 'build_sprites_client', lambda: fake_client)

    client, resolved_sprite, created = e2e_conf.resolve_or_create_sprites_target()

    assert client is fake_client
    assert resolved_sprite is sprite
    assert created is True
    assert fake_client.get_calls == ['stale-sprite']
    assert len(fake_client.create_calls) == 1
    assert fake_client.create_calls[0].startswith('agentsh-sprites-e2e-')


@pytest.mark.asyncio
async def test_require_sprites_command_endpoint_skips_when_target_missing() -> None:
    class _FakeAdapter:
        def __init__(self) -> None:
            class _FakeSprite:
                name = 'stale-sprite'
                client = _FakeSpritesClient(
                    missing=_FakeSpritesNotFound(
                        "Resource not found for get sprite 'stale-sprite'"
                    )
                )

            self._sprite = _FakeSprite()

        async def exec(self, *_args, **_kwargs):
            raise AssertionError('exec should not be reached when sprite is missing')

    with pytest.raises(pytest.skip.Exception, match='Configured Sprites target is unavailable'):
        await e2e_conf.require_sprites_command_endpoint(_FakeAdapter())


def test_build_http_status_command_uses_policy_safe_curl_target() -> None:
    cmd = e2e_conf.build_http_status_command(
        "https://registry.npmjs.org/-/ping",
        timeout_seconds=7,
    )

    assert cmd.startswith('curl --proto-default https -L -s -o /dev/null -w "%{http_code}"')
    assert "https://" not in cmd
    assert "registry.npmjs.org/-/ping" in cmd
    assert "7" in cmd


def test_build_http_status_command_rejects_non_http_urls() -> None:
    with pytest.raises(ValueError, match="http"):
        e2e_conf.build_http_status_command("registry.npmjs.org")


@pytest.mark.asyncio
async def test_exec_http_status_returns_numeric_status() -> None:
    class _FakeSecured:
        command = ""

        async def exec(self, command: str) -> ExecResult:
            self.command = command
            return ExecResult(stdout="200\n", stderr="", exit_code=0)

    secured = _FakeSecured()

    status = await e2e_conf.exec_http_status(secured, "https://registry.npmjs.org/")

    assert status == "200"
    assert "registry.npmjs.org/" in secured.command


@pytest.mark.asyncio
async def test_exec_http_status_skips_when_no_probe_tool_is_available() -> None:
    class _FakeSecured:
        async def exec(self, _command: str) -> ExecResult:
            return ExecResult(stdout="", stderr="no-http-probe", exit_code=127)

    with pytest.raises(pytest.skip.Exception, match="HTTP probe unavailable"):
        await e2e_conf.exec_http_status(_FakeSecured(), "https://registry.npmjs.org/")



def test_cleanup_sprites_target_ignores_missing_sprite() -> None:
    class _FakeSprite:
        def delete(self) -> None:
            raise _FakeSpritesNotFound("Resource not found for delete sprite 'tmp'")

    client = _FakeSpritesClient()

    e2e_conf.cleanup_sprites_target(client, _FakeSprite(), True)

    assert client.close_calls == 1


def test_exe_available_uses_ssh_not_vm_name(monkeypatch) -> None:
    env = _env()
    monkeypatch.setattr(e2e_conf.shutil, 'which', lambda name: '/usr/bin/ssh' if name == 'ssh' else None)
    _refresh(monkeypatch, env, 'unused-sdk')

    assert e2e_conf.exe_available is True
    assert e2e_conf.skip_no_exe.args == (False,)


def test_resolve_or_create_exe_vm_reuses_existing_target(monkeypatch) -> None:
    calls: list[object] = []
    monkeypatch.setattr(e2e_conf, 'ENV', _env(EXE_VM_NAME='agentsh-test'))
    monkeypatch.setattr(e2e_conf, 'require_exe_gateway_access', lambda: calls.append('gateway'))
    monkeypatch.setattr(e2e_conf, 'exe_vm_exists', lambda name: calls.append(('exists', name)) or True)
    monkeypatch.setattr(e2e_conf, 'create_exe_vm', lambda name: calls.append(('create', name)))
    monkeypatch.setattr(e2e_conf, 'wait_for_exe_vm_ssh', lambda name: calls.append(('wait', name)))
    monkeypatch.setattr(e2e_conf, 'ensure_exe_vm_prereqs', lambda name: calls.append(('prepare', name)))

    name, destroy_on_cleanup = e2e_conf.resolve_or_create_exe_vm()

    assert name == 'agentsh-test'
    assert destroy_on_cleanup is False
    assert calls == ['gateway', ('exists', 'agentsh-test'), ('prepare', 'agentsh-test')]


def test_resolve_or_create_exe_vm_creates_configured_target_when_missing(monkeypatch) -> None:
    calls: list[object] = []
    monkeypatch.setattr(e2e_conf, 'ENV', _env(EXE_VM_NAME='agentsh-test'))
    monkeypatch.setattr(e2e_conf, 'require_exe_gateway_access', lambda: calls.append('gateway'))
    monkeypatch.setattr(e2e_conf, 'exe_vm_exists', lambda name: calls.append(('exists', name)) or False)
    monkeypatch.setattr(e2e_conf, 'create_exe_vm', lambda name: calls.append(('create', name)))
    monkeypatch.setattr(e2e_conf, 'wait_for_exe_vm_ssh', lambda name: calls.append(('wait', name)))
    monkeypatch.setattr(e2e_conf, 'ensure_exe_vm_prereqs', lambda name: calls.append(('prepare', name)))

    name, destroy_on_cleanup = e2e_conf.resolve_or_create_exe_vm()

    assert name == 'agentsh-test'
    assert destroy_on_cleanup is False
    assert calls == [
        'gateway',
        ('exists', 'agentsh-test'),
        ('create', 'agentsh-test'),
        ('wait', 'agentsh-test'),
        ('prepare', 'agentsh-test'),
    ]


def test_resolve_or_create_exe_vm_creates_disposable_when_name_missing(monkeypatch) -> None:
    calls: list[object] = []
    monkeypatch.setattr(e2e_conf, 'ENV', _env())
    monkeypatch.setattr(e2e_conf, 'require_exe_gateway_access', lambda: calls.append('gateway'))
    monkeypatch.setattr(e2e_conf, 'create_exe_vm', lambda name: calls.append(('create', name)))
    monkeypatch.setattr(e2e_conf, 'wait_for_exe_vm_ssh', lambda name: calls.append(('wait', name)))
    monkeypatch.setattr(e2e_conf, 'ensure_exe_vm_prereqs', lambda name: calls.append(('prepare', name)))

    name, destroy_on_cleanup = e2e_conf.resolve_or_create_exe_vm(prefix='agentsh-exe-e2e')

    assert name.startswith('agentsh-exe-e2e-')
    assert destroy_on_cleanup is True
    assert calls == [
        'gateway',
        ('create', name),
        ('wait', name),
        ('prepare', name),
    ]


def test_cleanup_exe_vm_deletes_only_disposable(monkeypatch) -> None:
    deleted: list[str] = []
    monkeypatch.setattr(e2e_conf, 'delete_exe_vm', lambda name: deleted.append(name))

    e2e_conf.cleanup_exe_vm('agentsh-test', False)
    e2e_conf.cleanup_exe_vm('agentsh-temp', True)

    assert deleted == ['agentsh-temp']
