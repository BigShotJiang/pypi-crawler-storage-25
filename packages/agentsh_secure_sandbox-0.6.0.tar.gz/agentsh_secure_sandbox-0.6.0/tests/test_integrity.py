# tests/test_integrity.py
from agentsh_secure_sandbox.core.integrity import (
    PINNED_VERSION,
    CHECKSUMS,
    binary_url,
    get_checksum,
    build_verify_command,
)


def test_pinned_version_exists():
    assert PINNED_VERSION == "0.19.0"


def test_checksums_for_pinned_version():
    assert PINNED_VERSION in CHECKSUMS
    assert "linux_amd64" in CHECKSUMS[PINNED_VERSION]
    assert "linux_arm64" in CHECKSUMS[PINNED_VERSION]


def test_binary_url_default():
    url = binary_url("0.19.0", "linux_amd64")
    assert "agentsh_0.19.0_linux_amd64.tar.gz" in url
    assert url.startswith("https://github.com/canyonroad/agentsh/releases/")


def test_binary_url_override():
    url = binary_url("0.14.0", "linux_amd64", override="https://custom.example.com/bin.tar.gz")
    assert url == "https://custom.example.com/bin.tar.gz"


def test_get_checksum():
    cs = get_checksum("0.19.0", "linux_amd64")
    assert isinstance(cs, str)
    assert len(cs) > 10


def test_get_checksum_unknown():
    import pytest

    with pytest.raises(KeyError):
        get_checksum("99.99.99", "linux_amd64")


def test_build_verify_command():
    cmd = build_verify_command("/usr/local/bin/agentsh", "abcdef123456")
    assert "abcdef123456" in cmd
    assert "/usr/local/bin/agentsh" in cmd
    assert "sha256sum -c --status" not in cmd
    assert "awk" in cmd


def test_pinned_version_is_0_19_0():
    assert PINNED_VERSION == "0.19.0"


def test_checksums_include_0_19_0():
    assert "0.19.0" in CHECKSUMS
    assert "linux_amd64" in CHECKSUMS["0.19.0"]
    assert "linux_arm64" in CHECKSUMS["0.19.0"]
    assert CHECKSUMS["0.19.0"]["linux_amd64"] == "04c1b0e958a6e9027fc85d4625bec765e459f191dc16c4c5a04468c867f71d85"
    assert CHECKSUMS["0.19.0"]["linux_arm64"] == "89cecae90e6511cf96019cca948e3b5142dce329349141eb838979a243dda9cd"
