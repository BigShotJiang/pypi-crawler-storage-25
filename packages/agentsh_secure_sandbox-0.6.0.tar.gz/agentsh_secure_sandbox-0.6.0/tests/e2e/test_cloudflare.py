"""Cloudflare end-to-end tests — mirrors cloudflare.e2e.test.ts.

Uses HTTP proxy pattern: POSTs exec() calls to a deployed Cloudflare Worker.
Skips .env deny, env, printenv tests (Firecracker kernel limitation).
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

import httpx
import pytest
import pytest_asyncio

from tests.e2e.conftest import ENV, exec_http_status, skip_no_cloudflare_exec

from agentsh_secure_sandbox import SecuredSandbox, SecureConfig, secure_sandbox
from agentsh_secure_sandbox.adapters import cloudflare

pytestmark = [
    pytest.mark.e2e,
    pytest.mark.timeout(300),
    skip_no_cloudflare_exec,
    pytest.mark.asyncio(loop_scope="module"),
]

# ─── Module-scoped setup / teardown ────────────────────────


@dataclass
class _ExecResult:
    """Adapter-compatible exec result with stdout/stderr/exit_code attributes."""

    stdout: str
    stderr: str
    exit_code: int


def _coerce_exec_result(data: dict[str, Any]) -> _ExecResult:
    """Convert worker JSON response into the object the adapter expects.

    The deployed worker may emit either snake_case or camelCase keys; accept both.
    """
    exit_code = data.get("exit_code")
    if exit_code is None:
        exit_code = data.get("exitCode", 0)
    return _ExecResult(
        stdout=data.get("stdout") or "",
        stderr=data.get("stderr") or "",
        exit_code=int(exit_code or 0),
    )


class _CloudflareSandboxProxy:
    """HTTP proxy that forwards exec() calls to the deployed Worker."""

    def __init__(self, base_url: str, token: str, sandbox_id: str) -> None:
        self._base_url = base_url
        self._token = token
        self._sandbox_id = sandbox_id
        self._client = httpx.AsyncClient(timeout=120)

    async def exec(
        self, command: str, *, cwd: str | None = None
    ) -> _ExecResult:
        res = await self._client.post(
            f"{self._base_url}/exec",
            params={"id": self._sandbox_id},
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._token}",
            },
            json={"command": command, "cwd": cwd},
        )
        if res.status_code >= 400:
            raise RuntimeError(f"Worker returned {res.status_code}: {res.text}")
        return _coerce_exec_result(res.json())

    async def close(self) -> None:
        await self._client.aclose()


@pytest_asyncio.fixture(scope="module", loop_scope="module")
async def secured() -> SecuredSandbox:  # type: ignore[misc]
    sandbox_id = f"e2e-{int(time.time() * 1000)}"
    proxy = _CloudflareSandboxProxy(
        base_url=ENV["CLOUDFLARE_WORKER_URL"],
        token=ENV["CLOUDFLARE_API_TOKEN"],
        sandbox_id=sandbox_id,
    )
    adapter = cloudflare(proxy)
    # The legacy Cloudflare exec worker already routes commands through
    # ``agentsh exec``. Use ``install_strategy="running"`` here so the
    # secured sandbox runs in passthrough mode instead of nesting a second
    # agentsh session inside that outer facade.
    sec = await secure_sandbox(
        adapter,
        SecureConfig(
            install_strategy="running",
            session_id=sandbox_id,
            security_mode="minimal",
        ),
    )

    yield sec  # type: ignore[misc]

    await sec.stop()
    await proxy.close()


# ─── Smoke tests ──────────────────────────────────────────


class TestCloudflareSmoke:
    async def test_provisions_session_id(self, secured: SecuredSandbox) -> None:
        assert secured.session_id
        assert isinstance(secured.session_id, str)

    async def test_reports_valid_security_mode(self, secured: SecuredSandbox) -> None:
        assert secured.security_mode in ("full", "landlock", "landlock-only", "minimal")

    async def test_exec_simple_command(self, secured: SecuredSandbox) -> None:
        result = await secured.exec("echo hello")
        assert result.exit_code == 0
        assert result.stdout.strip() == "hello"

    async def test_write_read_roundtrip(self, secured: SecuredSandbox) -> None:
        path = "/workspace/e2e-test-file.txt"
        content = f"e2e-roundtrip-{int(time.time() * 1000)}"

        write_result = await secured.write_file(path, content)
        assert write_result.success is True

        read_result = await secured.read_file(path)
        assert read_result.success is True
        if read_result.success:
            assert read_result.content.strip() == content


# ─── Policy enforcement ───────────────────────────────────
# Note: Cloudflare Containers run in Firecracker VMs whose custom kernel
# reports 'full' security mode but may lack actual seccomp_user_notify
# and FUSE support.  Tests for .env file deny, env/printenv blocking are
# skipped here and covered by the Vercel E2E tests instead.


class TestCloudflarePolicy:
    async def test_allows_workspace_write(self, secured: SecuredSandbox) -> None:
        result = await secured.write_file("/workspace/allowed-file.txt", "allowed")
        assert result.success is True

    async def test_blocks_sudo(self, secured: SecuredSandbox) -> None:
        result = await secured.exec("sudo whoami")
        assert result.exit_code != 0

    async def test_allows_npm_registry(self, secured: SecuredSandbox) -> None:
        status = await exec_http_status(secured, "https://registry.npmjs.org/")
        assert status == "200"

    async def test_blocks_unauthorized_network(self, secured: SecuredSandbox) -> None:
        status = await exec_http_status(secured, "https://evil.example.com")
        assert status != "200"

    async def test_filters_sensitive_env_vars(self, secured: SecuredSandbox) -> None:
        result = await secured.exec("printenv SECRET_KEY")
        assert result.stdout.strip() == ""
