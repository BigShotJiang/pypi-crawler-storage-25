"""ux module boundaries."""
