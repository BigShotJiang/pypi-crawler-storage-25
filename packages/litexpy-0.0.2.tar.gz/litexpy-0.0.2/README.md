# litexpy

Python runner for an interactive `litex` terminal session.

## Usage

```python
import litexpy

runner = litexpy.Runner()

runner.run("1 = 1")
runner.clear()
runner.quit()
```

`litexpy.Runner()` starts the `litex` command in an interactive terminal
process. `run(script)` sends one script line to that process, `clear()` is
equivalent to `run("clear")`, and `quit()` closes the running `litex` process.
