# Fred SDK

`fred-sdk` is the authoring SDK for Fred agents. It packages the public
interfaces used by agent authors (ReAct, graph workflows, team agents, HITL)
so you can build workflows without wiring platform internals.

Install
-------
```bash
pip install fred-sdk
```

Quickstart
----------
```python
from fred_sdk import hello_message

print(hello_message("Ada"))
```

Notes
-----
- `fred-sdk` depends on `fred-core` and `fred-portable` and pulls them in
  automatically.
- The SDK surface lives in `fred_sdk/__init__.py` for top-level imports.

Resources
---------
- Homepage: https://fredk8.dev
- Repository: https://github.com/ThalesGroup/fred
