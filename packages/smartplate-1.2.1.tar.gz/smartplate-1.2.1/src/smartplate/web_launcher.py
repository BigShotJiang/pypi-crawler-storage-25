"""SmartPlate Web UI launcher — run `smartplate-web` to start the web app."""

import os
import sys
from pathlib import Path


def main():
    web_app = Path(__file__).parent / "web_app.py"
    args = [sys.executable, "-m", "streamlit", "run", str(web_app), "--server.headless", "true",
            "--browser.gatherUsageStats", "false"] + sys.argv[1:]
    os.execv(sys.executable, args)
