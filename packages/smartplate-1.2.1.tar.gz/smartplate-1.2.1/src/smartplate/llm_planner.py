"""
llm_planner.py - 知识约束型 LLM 配餐引擎

核心思路：将结构化领域知识（营养数据库、DRIs、份量规则、画像约束）
注入 LLM prompt，让 LLM 在领域知识约束下生成个性化食谱。

同时提供纯 LLM 基线模式（最小化 prompt，无知识注入）用于 A/B 实验对比。
"""

import json
import os
import re
from typing import Any

from .advice_engine import GOAL_ADJUSTMENTS, get_user_rda, per_meal_rda
from .logging_config import get_logger
from .meal_planner import GOAL_LABELS, MEAL_TEMPLATES
from .nutrition_db import FOOD_NUTRITION, SYNONYMS, get_nutrition, search_food
from .visual_portion import (
    CATEGORY_GRAM_PER_UNIT,
    CATEGORY_ZH,
    FOOD_CATEGORY_MAP,
    PROFILE_RECOMMENDATIONS,
    VISUAL_UNITS,
    classify_food,
    get_default_unit,
    get_gram_equivalent,
)

log = get_logger("llm_planner")


def call_llm_api(
    messages: list[dict[str, Any]],
    api_url: str | None = None,
    api_key: str | None = None,
    model: str | None = None,
    temperature: float = 0.5,
    max_tokens: int = 2000,
    timeout: int = 60,
    force_json: bool = False,
) -> str | None:
    """调用 OpenAI 兼容 LLM API，返回响应文本。失败返回 None。"""
    url = api_url or os.environ.get("LLM_API_URL", "") or "https://api.openai.com/v1/chat/completions"
    key = api_key or os.environ.get("LLM_API_KEY", "")
    model_name = model or os.environ.get("LLM_MODEL", "gpt-3.5-turbo")

    if not key:
        log.warning("LLM API key not configured")
        return None

    try:
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {key}",
        }
        body: dict[str, Any] = {
            "model": model_name,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        if force_json and any(m in model_name.lower() for m in ["gpt-4", "gpt-3.5-turbo", "gpt-4o"]):
            body["response_format"] = {"type": "json_object"}

        import requests
        resp = requests.post(url, headers=headers, json=body, timeout=timeout)
        resp.raise_for_status()

        data: Any = resp.json()
        return str(data["choices"][0]["message"]["content"])
    except Exception as e:
        log.warning(f"LLM API call failed: {e}")
        return None


# ============================================================
# LLMPlanner 类
# ============================================================
class LLMPlanner:
    """知识约束型 LLM 配餐引擎"""

    def __init__(
        self,
        user_type: str = "general",
        gender: str = "male",
        age: int = 30,
        activity: str = "light",
        api_url: str | None = None,
        api_key: str | None = None,
        model: str | None = None,
        temperature: float = 0.9,
        max_retries: int = 2,
        validate_tolerance: float = 0.30,
    ):
        """
        初始化 LLM 配餐器。

        :param user_type: 用户画像类型（general/diabetes/weight_loss/muscle_gain）
        :param gender: 性别
        :param age: 年龄
        :param activity: 活动水平（sedentary/light/moderate/active）
        :param api_url: LLM API 地址（默认从环境变量读取）
        :param api_key: API 密钥（默认从环境变量读取）
        :param model: 模型名称（默认从环境变量读取）
        :param temperature: 生成温度（随机性）
        :param max_retries: 最大重试次数
        :param validate_tolerance: 营养偏差容忍阈值（暂未使用，预留）
        """
        self.user_type = user_type
        self.gender = gender
        self.age = age
        self.activity = activity
        self.goal_label = GOAL_LABELS.get(user_type, "日常健康")

        # LLM 配置
        self.api_url = api_url or os.environ.get("LLM_API_URL", "")
        self.api_key = api_key or os.environ.get("LLM_API_KEY", "")
        self.model = model or os.environ.get("LLM_MODEL", "gpt-3.5-turbo")
        self.temperature = temperature
        self.max_retries = max_retries
        self.validate_tolerance = validate_tolerance

        # 计算用户每日推荐摄入量（DRIs）和每餐目标
        self.daily_rda: dict[str, Any] = get_user_rda(gender, age, activity, user_type)
        self.per_meal: dict[str, Any] = per_meal_rda(self.daily_rda)
        self.goal_config: dict[str, Any] = GOAL_ADJUSTMENTS.get(user_type, {})

        # 记录最后一次的 prompt 和响应（用于调试）
        self._last_prompt = ""
        self._last_response = ""

    def is_available(self) -> bool:
        """检查 LLM 是否可用（API 密钥已配置）"""
        return bool(self.api_key)

    # ---------- Prompt 构建 ----------

    def _build_structured_prompt(self) -> str:
        """构建完整的知识约束型 prompt（包含所有领域知识）"""
        sections = [
            self._prompt_section_role(),
            self._prompt_section_user_targets(),
            self._prompt_section_meal_structure(),
            self._prompt_section_food_database(),
            self._prompt_section_profile_constraints(),
            self._prompt_section_output_format(),
        ]
        return "\n\n".join(sections)

    def _prompt_section_role(self) -> str:
        """角色设定：注册营养师，并要求使用数据库中的食物，鼓励多样性（使用随机种子）"""
        import random
        seed = random.randint(1, 99999)
        return f"""## Role & Task (Seed: {seed})
You are a registered dietitian designing a one-day meal plan for a specific user.
Generate a complete 4-meal plan (breakfast, lunch, dinner, snack).
CRITICAL: Use ONLY foods from the food database provided below. Do NOT invent foods.
CRITICAL: Follow the portion guidelines and constraints for this user profile.
CRITICAL: Be CREATIVE and DIVERSE — choose different foods for each meal slot. Use the seed {seed} to make different choices each time. Rotate between different grains, proteins, vegetables, and fruits.
Return your plan in the EXACT JSON format specified at the end."""

    def _prompt_section_user_targets(self) -> str:
        """用户画像与每日营养目标（来自 DRIs）"""
        rda = self.daily_rda
        meals_per_day = 3  # 正餐数（早餐、午餐、晚餐）
        return f"""## User Profile & Daily Targets
- Health Goal: {self.goal_label}
- Gender: {self.gender}, Age: {self.age}, Activity Level: {self.activity}
- Daily Energy Target: {rda.get('daily_energy_kcal', '?')} kcal
- Daily Carbs: {rda.get('daily_carbs_g', '?')}g (per-meal target: ~{rda.get('daily_carbs_g', 0) / meals_per_day:.0f}g)
- Daily Protein: {rda.get('daily_protein_g', '?')}g (per-meal target: ~{rda.get('daily_protein_g', 0) / meals_per_day:.0f}g)
- Daily Fat: {rda.get('daily_fat_g', '?')}g (per-meal target: ~{rda.get('daily_fat_g', 0) / meals_per_day:.0f}g)
- Daily Fiber: {rda.get('daily_fiber_g', '?')}g
- Macro energy ratio target: Carbs 50-65%, Protein 10-15%, Fat 20-30%"""

    def _prompt_section_meal_structure(self) -> str:
        """餐食结构与份量指南（手部份量系统 + 每餐模板 + 每类食物每日推荐）"""
        profile = PROFILE_RECOMMENDATIONS.get(self.user_type, PROFILE_RECOMMENDATIONS["general"])

        lines = ["## Meal Structure & Portion Guidelines (Hand-Portion System)"]
        lines.append("Portion unit reference: 1 fist ~150g staples/fruits, 1 fist ~100g vegetables, 1 palm ~85g protein, 1 thumb ~15g fats, 1 bowl ~300ml liquid/porridge\n")

        # 每餐模板（来自 meal_planner.MEAL_TEMPLATES）
        lines.append("### Per-Meal Templates:")
        for meal_name in ["breakfast", "lunch", "dinner", "snack"]:
            slots = MEAL_TEMPLATES.get(meal_name, [])
            parts = []
            for s in slots:
                zh = CATEGORY_ZH.get(s["category"], s["category"])
                v_unit_info: dict[str, str] = VISUAL_UNITS.get(s["target_unit"], {})
                unit_zh = v_unit_info.get("zh", s["target_unit"])
                if s["target_count"] == 0.5:
                    parts.append(f"half {unit_zh} of {zh}")
                elif s["target_count"] == int(s["target_count"]):
                    parts.append(f"{int(s['target_count'])} {unit_zh} of {zh}")
                else:
                    parts.append(f"{s['target_count']} {unit_zh} of {zh}")
            lines.append(f"- {meal_name.capitalize()}: {' + '.join(parts)}")

        # 按类别的每日指南（来自 visual_portion.PROFILE_RECOMMENDATIONS）
        lines.append("\n### Per-Category Daily Guidelines (for this profile):")
        for cat in ["grains", "protein", "vegetables", "fats", "fruits"]:
            if cat in profile:
                rule = profile[cat]
                unit = list(rule.keys())[0]
                unit_zh = VISUAL_UNITS.get(unit, {}).get("zh", unit)
                count = rule.get(unit, 1)
                lines.append(f"- {CATEGORY_ZH.get(cat, cat)}: {count} {unit_zh}/meal, {rule.get('desc', '')}")

        # 克数换算参考
        lines.append("\n### Gram Equivalents (per unit, for common foods):")
        for cat in ["grains", "protein", "vegetables", "fruits", "fats"]:
            defaults = CATEGORY_GRAM_PER_UNIT.get(cat, {})
            for unit, grams in defaults.items():
                unit_zh = VISUAL_UNITS.get(unit, {}).get("zh", unit)
                lines.append(f"- 1 {unit_zh} of {CATEGORY_ZH.get(cat, cat)} ≈ {grams}g")

        return "\n".join(lines)

    def _prompt_section_food_database(self) -> str:
        """提供可用的食物数据库（每 100g 数据），随机打乱以增加多样性"""
        import random
        lines = ["## Available Food Database (per 100g, use ONLY these foods)\n"]
        lines.append("| # | Food Key | Category | kcal | Carbs(g) | Protein(g) | Fat(g) | GI | Fiber(g) |")
        lines.append("|---|----------|----------|------|----------|------------|--------|-----|---------|")

        idx = 0
        # 按类别分组，每类内随机排序
        for cat in ["grains", "protein", "vegetables", "fruits", "fats", "mixed"]:
            cat_foods = [(k, v) for k, v in FOOD_NUTRITION.items()
                         if FOOD_CATEGORY_MAP.get(k, "mixed") == cat]
            if not cat_foods:
                continue
            lines.append(f"| *{CATEGORY_ZH.get(cat, cat)}* | | | | | | | | |")
            shuffled = random.sample(cat_foods, len(cat_foods))
            for food_key, data in shuffled:
                idx += 1
                lines.append(
                    f"| {idx} | {food_key} | {cat} | {data.get('calories', 0)} | "
                    f"{data.get('carbs', 0):.1f} | {data.get('protein', 0):.1f} | "
                    f"{data.get('fat', 0):.1f} | {data.get('gi', 0)} | {data.get('fiber_g', 0):.1f} |"
                )

        return "\n".join(lines)

    def _prompt_section_profile_constraints(self) -> str:
        """针对不同用户画像的关键约束（糖尿病/减脂/增肌/通用）"""
        lines = ["## Critical Constraints for This User Profile"]

        if self.user_type == "diabetes":
            lines.append(f"""- MAX carbs per meal: {self.goal_config.get('carbs_max_per_meal', 60)}g
- MAX GI for any staple or fruit: {self.goal_config.get('gi_limit', 55)} (protein/vegetable foods with GI=0 or low GI are OK)
- MAX glycemic load per meal: {self.goal_config.get('gl_max_per_meal', 40)}
- TARGET fiber per meal: >= {self.goal_config.get('fiber_target_per_meal', 8)}g
- PREFER low-GI staples: 燕麦(GI=40), 糙米饭(GI=55), 红薯(GI=54), 全麦面包(GI=50)
- AVOID high-GI foods: 米饭(GI=73), 白面包(GI=75), 面条(GI=71), 西瓜(GI=72), 粥(GI=70)
- Choose lean proteins with <10g fat per 100g
- Pair carbs with protein and vegetables to slow glucose absorption""")

        elif self.user_type == "weight_loss":
            lines.append(f"""- MIN protein per meal: {self.goal_config.get('protein_min_per_meal', 25)}g (to preserve muscle)
- MAX fat per meal: {self.goal_config.get('fat_max_per_meal', 20)}g
- PREFER foods with low calorie density: vegetables <50kcal/100g, lean proteins <200kcal/100g
- PREFER high-fiber staples: 全麦面包, 燕麦, 糙米饭, 红薯
- AVOID 食用油 (884kcal/100g), fatty meats (猪肉 395kcal, 鸭肉 337kcal, 羊肉 294kcal)
- AVOID fried foods, 甜甜圈s (452kcal), 蛋糕s (347kcal), 薯条 (312kcal)
- Fill half the plate with vegetables for satiety""")

        elif self.user_type == "muscle_gain":
            lines.append(f"""- MIN protein per meal: {self.goal_config.get('protein_min_per_meal', 30)}g
- MIN carbs per meal: {self.goal_config.get('carbs_min_per_meal', 60)}g
- PREFER high-protein foods: 鸡胸肉(31g/100g), 瘦牛肉(28g/100g), 虾仁(24g/100g), 鱼肉(20g/100g), 老豆腐(17g/100g)
- PREFER high-carb staples: 米饭, 面条, 白面包, 燕麦, 土豆
- Include 2 palm portions of protein in lunch and dinner
- Sufficient carbs needed for training energy and glycogen recovery
- Healthy fats support hormone production""")

        else:
            lines.append("- Aim for balanced nutrition across all food categories")
            lines.append("- Follow the general portion guidelines for each meal")
            lines.append("- Include variety: different protein sources, colorful vegetables, whole grains")

        return "\n".join(lines)

    def _prompt_section_output_format(self) -> str:
        """严格的输出格式要求（仅 JSON，无额外文本）"""
        return """## Required Output Format

YOU MUST OUTPUT ONLY A JSON OBJECT. No markdown, no text explanations, no meal descriptions.

The JSON MUST follow this EXACT schema:

{
  "meals": {
    "breakfast": [
      {"food_name": "<choose from database>", "grams": <integer>},
      {"food_name": "<choose from database>", "grams": <integer>}
    ],
    "lunch": [
      {"food_name": "<choose from database>", "grams": <integer>},
      {"food_name": "<choose from database>", "grams": <integer>}
    ],
    "dinner": [
      {"food_name": "<choose from database>", "grams": <integer>},
      {"food_name": "<choose from database>", "grams": <integer>}
    ],
    "snack": [
      {"food_name": "<choose from database>", "grams": <integer>}
    ]
  }
}

CRITICAL RULES:
1. "food_name" MUST be a Chinese food key from the database table above. Choose DIFFERENT foods each time — do NOT copy these placeholder values.
2. "grams" is an integer (NOT a string). Calculate from the portion guidelines.
3. Each meal should have 2-4 food items covering different categories: grains + protein + vegetables/fruits.
4. Output ONLY the JSON object. No markdown fences, no natural language text.
5. Vary your food choices across meals — do not repeat the same food in multiple meals."""

    # ---------- LLM API 调用 ----------

    def _call_llm(self, prompt: str) -> str | None:
        """调用 LLM API，返回原始响应文本。失败返回 None"""
        self._last_prompt = prompt

        messages = [
            {
                "role": "system",
                "content": "You are a registered dietitian. Output ONLY valid JSON, no markdown fences, no explanation outside the JSON object."
            },
            {"role": "user", "content": prompt},
        ]

        result = call_llm_api(
            messages=messages,
            api_url=self.api_url,
            api_key=self.api_key,
            model=self.model,
            temperature=self.temperature,
            max_tokens=2000,
            timeout=60,
            force_json=True,
        )
        if result:
            self._last_response = result
        return result

    # ---------- 响应解析 ----------

    def _parse_response(self, raw_text: str) -> dict | None:
        """从 LLM 原始响应中提取 JSON 对象（去除 markdown 代码块）"""
        if not raw_text:
            return None

        text = raw_text.strip()

        # 去除 markdown 代码块标记
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*\n?", "", text)
            text = re.sub(r"\n?```\s*$", "", text)

        # 直接解析
        try:
            data: dict[str, Any] = json.loads(text)
            if "meals" in data:
                return data
        except json.JSONDecodeError:
            pass

        # 尝试提取第一个完整的 JSON 对象
        m = re.search(r'\{[\s\S]*"meals"[\s\S]*\}', text)
        if m:
            try:
                data2: dict[str, Any] = json.loads(m.group(0))
                if "meals" in data2:
                    return data2
            except json.JSONDecodeError:
                pass

        return None

    # ---------- 校验层 ----------

    def _validate_plan(self, plan: dict[str, Any]) -> tuple[bool, dict[str, Any]]:
        """
        对 LLM 生成的计划进行全面校验：
        1. 食物名称是否存在（通过同义词映射 + 模糊匹配）
        2. 营养偏差计算（每餐和全天与 DRIs 比较，允许 20% 偏差）
        3. 画像特定违规（GI 过高、蛋白质不足、高脂等）

        :return: (is_valid, details)  details 包含校验详情和 resolved_plan
        """
        details: dict[str, Any] = {
            "food_check": {"valid": 0, "invalid": 0, "invalid_foods": [], "substitutions": []},
            "nutrition_check": {},
            "gi_violations": [],
            "profile_violations": [],
        }

        # 正常化 meals 结构：LLM 可能返回列表格式（含 meal 字段）
        meals = plan.get("meals", {})
        if isinstance(meals, list):
            MEAL_KEY_MAP = {
                "breakfast": "breakfast", "lunch": "lunch", "dinner": "dinner",
                "snack": "snack", "snacks": "snack",
                "早餐": "breakfast", "午餐": "lunch", "晚餐": "dinner", "加餐": "snack",
            }
            normalized: dict[str, Any] = {}
            for entry in meals:
                meal_key = entry.get("meal", entry.get("meal_name", entry.get("name", "")))
                meal_key = meal_key.lower().strip()
                meal_key = MEAL_KEY_MAP.get(meal_key, meal_key)
                items = entry.get("items", entry.get("foods", []))
                # 如果 items 是字符串列表，说明 LLM 返回了自然语言，无法使用
                if items and isinstance(items[0], str):
                    normalized[meal_key] = []
                else:
                    normalized[meal_key] = items
            meals = normalized if normalized else {}
        plan["meals"] = meals

        # Phase 1: 食物数据库校验，同时构建解析后的计划（resolved_plan）
        resolved_plan: dict[str, Any] = {"meals": {}}
        for meal_name in ["breakfast", "lunch", "dinner", "snack"]:
            resolved_plan["meals"][meal_name] = []
            for item in plan.get("meals", {}).get(meal_name, []):
                food_name = item.get("food_name", "")
                grams = item.get("grams", 100)

                # 先通过同义词映射解析（支持中英文别称）
                resolved_key = SYNONYMS.get(food_name.lower().strip(), food_name.lower().strip())

                if resolved_key in FOOD_NUTRITION:
                    details["food_check"]["valid"] += 1
                    resolved_plan["meals"][meal_name].append({
                        "food_name": resolved_key,
                        "grams": int(grams),
                    })
                else:
                    # 模糊匹配（目前 search_food 返回列表，需要调整阈值，这里简化）
                    # 注：原 search_food 未返回相似度，此处保持原有逻辑（直接使用 matches）
                    matches = search_food(food_name)
                    if matches:
                        substitute = matches[0]  # 取第一个匹配
                        details["food_check"]["substitutions"].append(
                            f"{food_name} -> {substitute}"
                        )
                        details["food_check"]["valid"] += 1
                        resolved_plan["meals"][meal_name].append({
                            "food_name": substitute,
                            "grams": int(grams),
                        })
                    else:
                        details["food_check"]["invalid"] += 1
                        details["food_check"]["invalid_foods"].append(food_name)

        has_invalid_foods = details["food_check"]["invalid"] > 0

        # Phase 2: 营养校验（每餐和全天，偏差 >20% 视为不通过）
        daily_totals = {"calories": 0.0, "carbs_g": 0.0, "protein_g": 0.0, "fat_g": 0.0, "fiber_g": 0.0}
        all_valid = True

        for meal_name in ["breakfast", "lunch", "dinner", "snack"]:
            meal_cal = 0.0
            meal_carbs = 0.0
            meal_protein = 0.0
            meal_fat = 0.0

            for item in resolved_plan["meals"][meal_name]:
                nut = get_nutrition(item["food_name"], item["grams"])
                if nut:
                    meal_cal += nut.get("calories", 0)
                    meal_carbs += nut.get("carbs_g", 0)
                    meal_protein += nut.get("protein_g", 0)
                    meal_fat += nut.get("fat_g", 0)

            daily_totals["calories"] += meal_cal
            daily_totals["carbs_g"] += meal_carbs
            daily_totals["protein_g"] += meal_protein
            daily_totals["fat_g"] += meal_fat

            # 获取每餐目标（来自 per_meal_rda）
            target_cal = self.per_meal.get("energy_kcal", 600)

            details["nutrition_check"][meal_name] = {
                "calories": round(meal_cal),
                "calorie_target": target_cal,
                "calorie_deviation_pct": round(abs(meal_cal - target_cal) / max(target_cal, 1) * 100, 1),
                "carbs": round(meal_carbs, 1),
                "protein": round(meal_protein, 1),
                "fat": round(meal_fat, 1),
            }

        # 检查全天总量相对 RDA 的偏差（允许 20%）
        rda = self.daily_rda
        daily_deviation = {}
        for key, rda_key in [("calories", "daily_energy_kcal"), ("carbs_g", "daily_carbs_g"),
                              ("protein_g", "daily_protein_g"), ("fat_g", "daily_fat_g")]:
            target = rda.get(rda_key, 1)
            if target <= 0:
                target = 1
            actual = daily_totals.get(key, 0)
            deviation = abs(actual - target) / target * 100
            daily_deviation[key] = round(deviation, 1)
            if deviation > 20:
                all_valid = False

        details["daily_totals"] = {k: round(v, 1) for k, v in daily_totals.items()}
        details["daily_deviation"] = daily_deviation

        # Phase 3: 画像特定违规
        if self.user_type == "diabetes":
            gi_limit = self.goal_config.get("gi_limit", 55)
            for meal_name in ["breakfast", "lunch", "dinner", "snack"]:
                for item in resolved_plan["meals"][meal_name]:
                    food_data = FOOD_NUTRITION.get(item["food_name"], {})
                    gi = food_data.get("gi", 0)
                    cat = FOOD_CATEGORY_MAP.get(item["food_name"], "mixed")
                    if cat in ("grains", "fruits") and 0 < gi > gi_limit:
                        details["gi_violations"].append(
                            f"{meal_name}: {item['food_name']} (GI={gi} > limit {gi_limit})"
                        )
            if details["gi_violations"]:
                all_valid = False

        elif self.user_type == "weight_loss":
            for meal_name in ["breakfast", "lunch", "dinner", "snack"]:
                for item in resolved_plan["meals"][meal_name]:
                    food_data = FOOD_NUTRITION.get(item["food_name"], {})
                    fat = food_data.get("fat", 0)
                    if fat > 50:  # 每 100g 脂肪 > 50g 视为极高脂
                        details["profile_violations"].append(
                            f"{meal_name}: {item['food_name']} is high-fat ({fat}g/100g)"
                        )

        elif self.user_type == "muscle_gain":
            protein_min = self.goal_config.get("protein_min_per_meal", 30)
            for meal_name in ["lunch", "dinner"]:
                meal_protein = sum(
                    get_nutrition(item["food_name"], item["grams"]).get("protein_g", 0)
                    for item in resolved_plan["meals"][meal_name]
                )
                if meal_protein < protein_min:
                    details["profile_violations"].append(
                        f"{meal_name}: protein {meal_protein:.0f}g < minimum {protein_min}g"
                    )
                    all_valid = False

        details["overall_valid"] = (not has_invalid_foods) and all_valid
        details["resolved_plan"] = resolved_plan

        return details["overall_valid"], details

    # ---------- 纠错 ----------

    def _correct_plan(self, plan: dict[str, Any], validation_details: dict[str, Any]) -> dict[str, Any]:
        """
        根据校验详情决定如何纠错。
        返回 dict:
          - "action": "use_resolved" (直接使用已解析的计划，仅做了同义词替换)
                      "retry" (需要重新生成，提供错误反馈)
                      "fail" (无法修复)
          - "plan": 修正后的计划（当 action 为 use_resolved）
          - "prompt": 用于重试的修正 prompt（当 action 为 retry）
        """
        invalid_foods = validation_details["food_check"]["invalid_foods"]
        gi_violations = validation_details.get("gi_violations", [])
        profile_violations = validation_details.get("profile_violations", [])

        errors = []
        if invalid_foods:
            errors.append(f"Invalid foods not in database: {', '.join(invalid_foods)}. "
                          f"Please use ONLY foods from the database table.")
        if gi_violations:
            errors.append(f"GI violations: {'; '.join(gi_violations)}. "
                          f"Replace high-GI foods with low-GI alternatives from the database.")
        if profile_violations:
            errors.append(f"Profile violations: {'; '.join(profile_violations)}")

        if not errors:
            # 只有同义词替换，无需重试
            return {"action": "use_resolved",
                    "plan": validation_details.get("resolved_plan", plan)}

        # 构造纠错提示，要求重新生成
        error_text = "\n".join(f"{i+1}. {e}" for i, e in enumerate(errors))
        correction_prompt = f"""Your previous meal plan had the following issues:

{error_text}

Please regenerate the COMPLETE plan fixing ALL these issues.
Remember: use ONLY foods from the database, follow the meal templates and portion guidelines, and respect all profile constraints.

Return ONLY valid JSON."""

        return {"action": "retry", "prompt": correction_prompt}

    # ---------- 主入口 ----------

    def generate_daily_plan(self) -> dict[str, Any] | None:
        """
        生成知识约束型食谱（核心方法）
        流程：构建 prompt -> 调用 LLM -> 解析 -> 校验 -> 纠错（重试）
        :return: 与 MealPlanner.generate_daily_plan() 兼容的字典，失败返回 None
        """
        if not self.is_available():
            return None

        prompt = self._build_structured_prompt()

        for attempt in range(self.max_retries + 1):
            if attempt > 0:
                log.info(f"Retry attempt {attempt}/{self.max_retries}")

            raw = self._call_llm(prompt)
            if not raw:
                return None

            plan = self._parse_response(raw)
            if not plan:
                prompt = "Your response was not valid JSON. Please return ONLY a valid JSON object with the 'meals' structure. No markdown, no extra text."
                continue

            is_valid, details = self._validate_plan(plan)
            if is_valid:
                return self._build_result(details["resolved_plan"], details)

            # 尝试纠错
            result = self._correct_plan(plan, details)
            if result["action"] == "use_resolved":
                return self._build_result(result["plan"], details)
            elif result["action"] == "retry":
                prompt = result["prompt"]
            else:
                return None

        return None

    def generate_baseline_plan(self) -> dict[str, Any] | None:
        """
        纯 LLM 基线：最小化 prompt，不注入任何领域知识，仅给出用户画像和 JSON 格式要求。
        用于对比实验，评估知识注入的效果。
        """
        if not self.is_available():
            return None

        prompt = f"""Create a one-day meal plan for a person with the following profile:
- Health Goal: {self.goal_label}
- Gender: {self.gender}, Age: {self.age}
- Activity Level: {self.activity}

Provide 4 meals (breakfast, lunch, dinner, snack) with food names and approximate portions in grams.

Return ONLY a valid JSON object with this structure:
{{"meals": {{"breakfast": [{{"food_name": "...", "grams": 100}}], "lunch": [...], "dinner": [...], "snack": [...]}}}}"""

        raw = self._call_llm(prompt)
        if not raw:
            return None

        plan = self._parse_response(raw)
        if not plan:
            return None

        # 基线模式也做基础的食物名称校验（保证输出可用的食谱）
        is_valid, details = self._validate_plan(plan)
        return self._build_result(
            details.get("resolved_plan", plan),
            details,
            generation_method="llm_baseline",
        )

    def _build_result(self, plan: dict, validation_details: dict,
                      generation_method: str = "llm_knowledge") -> dict:
        """
        将内部 resolved_plan 转换为与 MealPlanner.generate_daily_plan() 完全一致的输出格式，
        包括每道菜的显示份量（手部单位）、每餐营养合计、全天目标等。
        """
        meals = {}
        daily_totals = {"calories": 0.0, "carbs_g": 0.0, "protein_g": 0.0,
                       "fat_g": 0.0, "fiber_g": 0.0}

        for meal_name in ["breakfast", "lunch", "dinner", "snack"]:
            meal_items = []
            for item in plan.get("meals", {}).get(meal_name, []):
                food_name = item["food_name"]
                grams = item.get("grams", 100)
                cat = classify_food(food_name)
                nut = get_nutrition(food_name, grams) or {}

                # 根据克数推算视觉份量（手部单位）
                unit = get_default_unit(food_name)
                unit_grams = get_gram_equivalent(food_name, unit)
                count = round(grams / max(unit_grams, 1), 1)
                unit_zh = VISUAL_UNITS.get(unit, {}).get("zh", unit)
                if count == 0.5:
                    portion = f"半{unit_zh}"
                elif count == int(count):
                    portion = f"{int(count)}{unit_zh}"
                else:
                    portion = f"{count}{unit_zh}"

                meal_items.append({
                    "name": food_name,
                    "category": cat,
                    "category_zh": CATEGORY_ZH.get(cat, cat),
                    "portion": portion,
                    "grams": grams,
                    "calories": round(nut.get("calories", 0)),
                    "gi": nut.get("gi", 0),
                    "protein": round(nut.get("protein_g", 0), 1),
                    "carbs": round(nut.get("carbs_g", 0), 1),
                })

                for k in daily_totals:
                    if k in nut:
                        daily_totals[k] += nut[k]

            meals[meal_name] = meal_items

        # 构建 daily_target（与 MealPlanner 保持一致）
        per_meal_dict = per_meal_rda(self.daily_rda)
        goal_config = GOAL_ADJUSTMENTS.get(self.user_type, {})

        target_carbs = per_meal_dict["carbs_g"]
        target_protein = per_meal_dict["protein_g"]
        target_fat = per_meal_dict["fat_g"]
        target_calories = per_meal_dict["energy_kcal"]
        target_fiber = per_meal_dict.get("fiber_g", 8)

        if goal_config.get("carbs_max_per_meal"):
            target_carbs = min(target_carbs, goal_config["carbs_max_per_meal"])
        if goal_config.get("protein_min_per_meal"):
            target_protein = max(target_protein, goal_config["protein_min_per_meal"])
        if goal_config.get("fat_max_per_meal"):
            target_fat = min(target_fat, goal_config["fat_max_per_meal"])
        if goal_config.get("fiber_target_per_meal"):
            target_fiber = goal_config["fiber_target_per_meal"]

        daily_target = {
            "carbs_g": round(target_carbs * 3, 1),
            "protein_g": round(target_protein * 3, 1),
            "fat_g": round(target_fat * 3, 1),
            "calories": round(target_calories * 3),
            "fiber_g": round(target_fiber * 3, 1),
        }

        return {
            "meals": meals,
            "daily_target": daily_target,
            "goal_label": self.goal_label,
            "user_profile": {"gender": self.gender, "age": self.age, "activity": self.activity},
            "daily_rda": self.daily_rda,
            "generation_method": generation_method,
            "validation_passed": validation_details.get("overall_valid", False),
            "validation_details": {
                k: v for k, v in validation_details.items() if k != "resolved_plan"
            },
        }
