"""
SmartPlate Web 界面 - 基于 Streamlit 的智能配餐助手
启动方式：smartplate-web 或 streamlit run smartplate/web_app.py
"""

import streamlit as st

from smartplate.cli import MEAL_ZH
from smartplate.meal_planner import MealPlanner
from smartplate.nutrition_db import FOOD_NUTRITION, SYNONYMS
from smartplate.visual_portion import VISUAL_UNITS

# ---------- 页面配置 ----------
st.set_page_config(
    page_title="SmartPlate 智能配餐助手",
    page_icon="🍽️",
    layout="wide",
)


# ---------- 初始化 session state ----------
def init_session():
    defaults = {
        "user_type": "general",
        "gender": "male",
        "age": 30,
        "activity": "light",
        "use_llm": True,
        "planner": None,
        "daily_plan": None,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v


def get_planner() -> MealPlanner:
    """获取或创建 MealPlanner 实例"""
    key = (st.session_state.user_type, st.session_state.gender,
           st.session_state.age, st.session_state.activity, st.session_state.use_llm)
    if "planner" not in st.session_state or st.session_state.get("_planner_key") != key:
        st.session_state.planner = MealPlanner(
            user_type=st.session_state.user_type,
            gender=st.session_state.gender,
            age=st.session_state.age,
            activity=st.session_state.activity,
            use_llm=st.session_state.use_llm,
        )
        st.session_state._planner_key = key
        st.session_state.daily_plan = None
    return st.session_state.planner


# ---------- 侧边栏 ----------
def render_sidebar():
    st.sidebar.title("🍽️ SmartPlate")
    st.sidebar.caption("智能配餐助手")

    st.sidebar.markdown("---")
    st.sidebar.subheader("👤 用户画像")

    goal_labels_display = {"general": "🍎 日常健康", "diabetes": "🩸 糖尿病/血糖控制",
                           "weight_loss": "🏃 减脂/体重控制", "muscle_gain": "💪 增肌/力量训练"}
    goal = st.sidebar.selectbox(
        "健康目标",
        options=list(goal_labels_display.keys()),
        format_func=lambda x: goal_labels_display[x],
        index=list(goal_labels_display.keys()).index(st.session_state.user_type),
    )

    gender = st.sidebar.radio("性别", ["male", "female"],
                              format_func=lambda x: "男" if x == "male" else "女",
                              index=0 if st.session_state.gender == "male" else 1,
                              horizontal=True)

    age = st.sidebar.slider("年龄", 18, 80, st.session_state.age)

    activity_labels = {"sedentary": "久坐", "light": "轻度活动", "moderate": "中度活动", "active": "活跃"}
    activity = st.sidebar.selectbox(
        "活动水平",
        options=list(activity_labels.keys()),
        format_func=lambda x: activity_labels[x],
        index=list(activity_labels.keys()).index(st.session_state.activity),
    )

    use_llm = st.sidebar.checkbox("启用 LLM", value=st.session_state.use_llm,
                                  help="启用大语言模型生成更智能的配餐方案（需配置 API Key）")

    if st.sidebar.button("🔄 更新画像", use_container_width=True):
        st.session_state.user_type = goal
        st.session_state.gender = gender
        st.session_state.age = age
        st.session_state.activity = activity
        st.session_state.use_llm = use_llm
        st.session_state.pop("_planner_key", None)
        st.rerun()

    # 显示当前每日目标
    planner = get_planner()
    rda = planner.daily_rda
    st.sidebar.markdown("---")
    st.sidebar.subheader("📋 每日推荐摄入")
    st.sidebar.write(f"🔥 热量：{rda.get('daily_energy_kcal', '?')} kcal")
    st.sidebar.write(f"🍚 碳水：{rda.get('daily_carbs_g', '?')} g")
    st.sidebar.write(f"🥩 蛋白：{rda.get('daily_protein_g', '?')} g")
    st.sidebar.write(f"🧈 脂肪：{rda.get('daily_fat_g', '?')} g")
    st.sidebar.write(f"🥬 纤维：{rda.get('daily_fiber_g', '?')} g")

    # 今日进度概览
    planner = get_planner()
    if planner.daily_log:
        st.sidebar.markdown("---")
        st.sidebar.subheader("📊 今日进度")
        t = planner._totals
        for label, key, target_key, _unit in [
            ("🔥 热量", "calories", "daily_energy_kcal", "kcal"),
            ("🍚 碳水", "carbs_g", "daily_carbs_g", "g"),
            ("🥩 蛋白", "protein_g", "daily_protein_g", "g"),
            ("🧈 脂肪", "fat_g", "daily_fat_g", "g"),
        ]:
            val = t.get(key, 0)
            target = rda.get(target_key, 1)
            pct = min(val / max(target, 1) * 100, 100)
            st.sidebar.write(f"{label}：{val:.0f}/{target} ( {pct:.0f}% )")
            st.sidebar.progress(pct / 100)


# ---------- Tab 1: 生成食谱 ----------
def render_meal_plan():
    st.header("🍽️ 生成一日食谱")

    col1, col2, col3 = st.columns(3)
    with col1:
        use_baseline = st.checkbox("LLM 纯基线模式（无知识注入）", value=False,
                                   help="仅用于实验对比，不注入营养学知识约束")
    with col2:
        if st.button("🎲 生成食谱", type="primary", use_container_width=True):
            with st.spinner("正在为你配餐..."):
                planner = get_planner()
                if use_baseline:
                    plan = planner.generate_daily_plan_baseline()
                    if plan is None:
                        st.warning("LLM 不可用，回退到规则引擎")
                        plan = planner.generate_daily_plan_rule()
                else:
                    plan = planner.generate_daily_plan()
                st.session_state.daily_plan = plan
            st.rerun()

    with col3:
        if st.button("🔄 重置食谱", use_container_width=True):
            st.session_state.daily_plan = None
            st.rerun()

    plan = st.session_state.daily_plan
    if not plan:
        st.info("点击「生成食谱」开始智能配餐")
        return

    method = plan.get("generation_method", "rule_engine")
    method_labels = {"llm_knowledge": "LLM + 知识约束", "llm_baseline": "LLM 纯基线", "rule_engine": "规则引擎"}
    st.caption(f"生成方式：{method_labels.get(method, method)}")

    # 四餐卡片布局
    cols = st.columns(4)
    for idx, meal_key in enumerate(["breakfast", "lunch", "dinner", "snack"]):
        items = plan["meals"].get(meal_key, [])
        with cols[idx]:
            zh = MEAL_ZH.get(meal_key, meal_key)
            emoji = {"早餐": "🌅", "午餐": "☀️", "晚餐": "🌙", "加餐": "🍪"}
            st.subheader(f"{emoji.get(zh, '')} {zh}")
            if not items:
                st.caption("无")
                continue
            meal_cals = 0
            for item in items:
                meal_cals += item["calories"]
                gi = item.get("gi", "-")
                gi_color = "🟢" if gi != "-" and gi <= 55 else ("🟡" if gi != "-" and gi <= 70 else "🔴")
                st.markdown(
                    f"""<div style="border:1px solid #ddd;border-radius:8px;padding:10px;margin:5px 0">
                    <b>{item['name']}</b> {gi_color}<br>
                    <small>{item['portion']} · 约{item['grams']}g<br>
                    {item['calories']} kcal | GI:{gi}</small>
                    </div>""",
                    unsafe_allow_html=True,
                )
            st.caption(f"小计：约 {meal_cals} kcal")

    # 全天目标
    st.markdown("---")
    target = plan["daily_target"]
    st.subheader("📊 全天营养目标")
    tc1, tc2, tc3, tc4, tc5 = st.columns(5)
    tc1.metric("热量", f"{target['calories']} kcal")
    tc2.metric("碳水", f"{target['carbs_g']} g")
    tc3.metric("蛋白质", f"{target['protein_g']} g")
    tc4.metric("脂肪", f"{target['fat_g']} g")
    tc5.metric("膳食纤维", f"{target['fiber_g']} g")

    if st.session_state.user_type == "diabetes":
        st.info("🩸 控糖提示：每餐碳水≤60g，优先选择低GI食物，搭配蛋白质和蔬菜")


# ---------- Tab 2: 记录饮食 ----------
def render_food_log():
    st.header("📝 记录饮食")

    planner = get_planner()

    # 食物输入区
    col1, col2 = st.columns([3, 1])
    with col1:
        food_input = st.text_input(
            "输入食物名称（多个用逗号分隔）",
            placeholder="例如：米饭,鸡胸肉,西兰花",
            key="food_input",
        )
    with col2:
        manual_grams_input = st.text_input(
            "指定克数（可选）",
            placeholder="米饭=200",
            key="manual_grams",
        )

    if st.button("📥 记录摄入", type="primary", use_container_width=True):
        if food_input.strip():
            food_names = [f.strip() for f in food_input.replace("，", ",").split(",") if f.strip()]

            # 解析手动克数
            manual = {}
            if manual_grams_input.strip():
                for part in manual_grams_input.split(","):
                    part = part.strip()
                    if "=" in part:
                        n, g = part.split("=", 1)
                        try:
                            manual[n.strip()] = float(g.strip())
                        except ValueError:
                            pass

            # 验证食物名
            valid = []
            unknown = []
            for name in food_names:
                key = SYNONYMS.get(name.lower(), name.lower())
                if key in FOOD_NUTRITION:
                    valid.append(name)
                else:
                    unknown.append(name)

            if unknown:
                st.warning(f"未找到：{', '.join(unknown)}，已跳过")
                all_foods = sorted(set(SYNONYMS.get(k, k) for k in FOOD_NUTRITION))
                for u in unknown:
                    matches = [f for f in all_foods if u.lower() in f.lower()][:5]
                    if matches:
                        st.caption(f"「{u}」是否指：{', '.join(matches)}？")

            if valid:
                result = planner.log_food(valid, manual)
                st.success(f"已记录 {len(valid)} 种食物")

                # 本次摄入详情
                st.subheader("本次摄入")
                for item in result["items"]:
                    st.write(f"• {item['raw_name']} — {item['portion']} ({item['grams']}g)")

                mt = result["meal_totals"]
                rc1, rc2, rc3, rc4 = st.columns(4)
                rc1.metric("碳水", f"{mt['carbs_g']}g")
                rc2.metric("蛋白质", f"{mt['protein_g']}g")
                rc3.metric("脂肪", f"{mt['fat_g']}g")
                rc4.metric("热量", f"{mt['calories']}kcal")

                # 今日进度
                st.subheader("今日进度")
                remaining = result["remaining"]
                bars = remaining.get("progress_bars", {})
                for label, key, target_key in [
                    ("热量", "calories", "daily_energy_kcal"),
                    ("碳水", "carbs_g", "daily_carbs_g"),
                    ("蛋白质", "protein_g", "daily_protein_g"),
                    ("脂肪", "fat_g", "daily_fat_g"),
                ]:
                    rda = planner.daily_rda
                    target = rda.get(target_key, 1)
                    current = planner._totals.get(key, 0)
                    pct = min(current / max(target, 1) * 100, 100)
                    st.write(f"{label}：{bars.get(key, '')}")
                    st.progress(pct / 100)

    # 已记录食物列表
    if planner.daily_log:
        st.markdown("---")
        st.subheader(f"📋 今日已记录（{len(planner.daily_log)} 项）")
        for item in planner.daily_log:
            col_a, _col_b = st.columns([4, 1])
            with col_a:
                st.write(f"• {item['raw_name']} — {item.get('portion', '')} ({item['grams']}g)")
        if st.button("🗑️ 清空记录", type="secondary"):
            planner.reset()
            st.rerun()


# ---------- Tab 3: 今日总结 & 建议 ----------
def render_summary():
    st.header("📊 今日饮食总结 & 下一餐建议")

    planner = get_planner()

    if not planner.daily_log:
        st.info("今日尚未记录任何饮食，请先在「记录饮食」中添加")
        return

    summary = planner.get_summary()

    # 摄入 vs 目标
    st.subheader("摄入 vs 目标")
    rda = summary["daily_rda"]
    today = summary["today_totals"]
    remaining = summary["remaining"]
    bars = remaining.get("progress_bars", {})

    for label, key, target_key, unit, emoji in [
        ("热量", "calories", "daily_energy_kcal", "kcal", "🔥"),
        ("碳水", "carbs_g", "daily_carbs_g", "g", "🍚"),
        ("蛋白质", "protein_g", "daily_protein_g", "g", "🥩"),
        ("脂肪", "fat_g", "daily_fat_g", "g", "🧈"),
        ("纤维", "fiber_g", "daily_fiber_g", "g", "🥬"),
    ]:
        val = today.get(key, 0)
        target = rda.get(target_key, 1)
        pct = min(val / max(target, 1) * 100, 100)
        st.write(f"{emoji} {label}：{val:.1f} / {target} {unit}  {bars.get(key, '')}")
        st.progress(pct / 100)

    # 下一餐建议
    st.markdown("---")
    st.subheader("🍽️ 下一餐推荐")
    suggestion = planner.suggest_next_meal()

    top = suggestion.get("top_deficit")
    if top and top["pct"] < 80:
        st.warning(f"最需补充：{top['label']}（仅完成 {top['pct']:.0f}%）")

    suggestions = suggestion.get("suggestions", [])
    if suggestions:
        meal_type = MEAL_ZH.get(suggestion.get("recommended_meal_type", "dinner"), "下一餐")
        st.write(f"**{meal_type}推荐食物：**")
        cols = st.columns(len(suggestions))
        for i, s in enumerate(suggestions):
            with cols[i]:
                nut = FOOD_NUTRITION.get(s["name"], {})
                st.markdown(f"""<div style="border:1px solid #4CAF50;border-radius:8px;padding:10px;text-align:center">
                <b>{s['name']}</b><br>
                <small>{s['reason']}</small><br>
                <small>每100g：{nut.get('calories', '?')}kcal | GI:{nut.get('gi', '?')}</small>
                </div>""", unsafe_allow_html=True)

    # 搭配建议
    template = suggestion.get("meal_template", [])
    if template:
        st.write("**搭配参考：**")
        parts = []
        for slot in template:
            count = slot["target_count"]
            unit = slot["target_unit"]
            unit_zh = VISUAL_UNITS.get(unit, {}).get("zh", unit)
            if count == 0.5:
                parts.append(f"{slot['label']} 半{unit_zh}")
            else:
                parts.append(f"{slot['label']} {int(count)}{unit_zh}")
        st.info(" + ".join(parts))

    # 用户画像特有提示
    if st.session_state.user_type == "diabetes":
        st.info("🩸 控糖提示：优先低GI食物，每餐搭配蛋白质和蔬菜")
    elif st.session_state.user_type == "weight_loss":
        st.info("🏃 减脂提示：控制总热量，细嚼慢咽增加饱腹感")
    elif st.session_state.user_type == "muscle_gain":
        st.info("💪 增肌提示：训练后30分钟内补充蛋白质+碳水")

    # 营养师点评
    st.markdown("---")
    advice = summary.get("advice", {})
    if advice.get("advice_text"):
        st.subheader("🧑‍⚕️ 营养师点评")
        st.text(advice["advice_text"])

    # 已记录食物
    st.markdown("---")
    st.subheader("📋 已记录食物")
    for item in summary.get("logged_foods", []):
        st.write(f"• {item['name']} — {item['portion']} ({item['grams']}g)")


# ---------- 主入口 ----------
def main():
    init_session()

    # 标题
    st.title("🍽️ SmartPlate 智能配餐助手")
    st.caption("基于《中国居民膳食指南 2022》和营养学知识约束的个性化配餐系统")

    render_sidebar()

    # Tab 切换
    tab1, tab2, tab3 = st.tabs(["🍽️ 生成食谱", "📝 记录饮食", "📊 今日总结"])

    with tab1:
        render_meal_plan()
    with tab2:
        render_food_log()
    with tab3:
        render_summary()


if __name__ == "__main__":
    main()
