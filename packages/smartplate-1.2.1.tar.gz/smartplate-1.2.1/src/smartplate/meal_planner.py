"""
meal_planner.py - 智能配餐引擎

支持三种食谱生成模式：
  1. LLM + Knowledge（知识约束型 LLM，主路径）
  2. LLM Baseline（纯 LLM，无知识注入，实验对比基线）
  3. Rule Engine（规则引擎，兜底方案）

完全复用 nutrition_db、advice_engine、visual_portion 现有模块。
"""

import random
from typing import Any

from .advice_engine import get_user_rda, per_meal_rda
from .nutrition_db import FOOD_NUTRITION, get_nutrition
from .visual_portion import (
    CATEGORY_ZH,
    VISUAL_UNITS,
    get_gram_equivalent,
)

GOAL_LABELS = {
    "general": "日常健康",
    "diabetes": "糖尿病/血糖控制",
    "weight_loss": "减脂/体重控制",
    "muscle_gain": "增肌/力量训练",
}

# ============================================================
# 餐次模板（哪些类别出现在哪一餐）
# ============================================================
MEAL_TEMPLATES: dict[str, list[dict[str, Any]]] = {
    "breakfast": [
        {"category": "grains", "label": "主食", "target_unit": "fist", "target_count": 1.0},
        {"category": "protein", "label": "蛋白质", "target_unit": "palm", "target_count": 1.0},
        {"category": "fruits", "label": "水果", "target_unit": "fist", "target_count": 1.0},
    ],
    "lunch": [
        {"category": "grains", "label": "主食", "target_unit": "fist", "target_count": 1.0},
        {"category": "protein", "label": "蛋白质", "target_unit": "palm", "target_count": 1.0},
        {"category": "vegetables", "label": "蔬菜", "target_unit": "fist", "target_count": 1.0},
    ],
    "dinner": [
        {"category": "vegetables", "label": "蔬菜", "target_unit": "fist", "target_count": 1.0},
        {"category": "protein", "label": "蛋白质", "target_unit": "palm", "target_count": 1.0},
        {"category": "grains", "label": "主食", "target_unit": "fist", "target_count": 0.5},
    ],
    "snack": [
        {"category": "fruits", "label": "水果", "target_unit": "fist", "target_count": 1.0},
    ],
}

# 各餐次适合的食物（只选数据库中的子集，避免推荐不合适的食物）
MEAL_FOOD_POOLS: dict[str, dict[str, list[str]]] = {
    "breakfast": {
        "grains": ["燕麦", "白面包", "全麦面包", "馒头", "粥"],
        "protein": ["鸡蛋", "蛋白", "全脂牛奶", "脱脂牛奶", "酸奶", "豆浆"],
        "fruits": ["苹果", "香蕉", "橙子", "猕猴桃", "草莓", "梨", "蓝莓", "桃子"],
        "vegetables": [],
        "fats": ["花生", "核桃", "杏仁"],
        "mixed": [],
    },
    "lunch": {
        "grains": ["米饭", "糙米饭", "面条", "玉米", "红薯", "白面包", "全麦面包"],
        "protein": ["鸡胸肉", "瘦牛肉", "瘦猪肉", "鱼肉", "三文鱼", "虾仁", "嫩豆腐", "老豆腐", "鸡蛋"],
        "vegetables": ["西兰花", "菠菜", "番茄", "黄瓜", "卷心菜", "胡萝卜", "芹菜", "甜椒", "茄子", "蘑菇", "四季豆"],
        "fruits": [],
        "fats": ["食用油", "橄榄油"],
        "mixed": ["饺子"],
    },
    "dinner": {
        "grains": ["米饭", "糙米饭", "面条", "红薯", "玉米"],
        "protein": ["鸡胸肉", "鱼肉", "三文鱼", "虾仁", "嫩豆腐", "老豆腐", "瘦牛肉", "瘦猪肉"],
        "vegetables": ["西兰花", "菠菜", "番茄", "黄瓜", "卷心菜", "生菜", "芹菜", "蘑菇", "茄子", "甜椒", "莲藕", "竹笋", "海带", "豆芽"],
        "fruits": [],
        "fats": ["食用油", "橄榄油"],
        "mixed": [],
    },
    "snack": {
        "grains": [],
        "protein": ["酸奶", "全脂牛奶", "脱脂牛奶", "豆浆"],
        "vegetables": [],
        "fruits": ["苹果", "香蕉", "橙子", "猕猴桃", "草莓", "梨", "葡萄", "西瓜", "樱桃", "蓝莓", "桃子", "芒果", "荔枝"],
        "fats": ["花生", "核桃", "杏仁"],
        "mixed": [],
    },
}


def _score_food(food_name: str, user_type: str, category: str) -> float:
    """
    根据用户画像给食物打分（越高越推荐）

    diabetes: 低GI > 高纤维 > 低脂肪
    weight_loss: 低热量 > 高蛋白 > 高纤维
    muscle_gain: 高蛋白 > 高热量 > 高碳水
    general: 均衡
    """
    data = FOOD_NUTRITION.get(food_name, {})
    if not data:
        return 0.0

    gi = data.get("gi", 100)
    fiber = data.get("fiber_g", 0)
    protein = data.get("protein", 0)
    fat = data.get("fat", 0)
    calories = data.get("calories", 0)
    carbs = data.get("carbs", 0)

    if user_type == "diabetes":
        score = 50.0
        if gi > 0:
            score += max(0, (100 - gi)) * 0.3  # 低GI加分
        score += fiber * 2.0                      # 高纤维加分
        if category in ("grains", "fruits"):
            if gi > 0 and gi <= 40:
                score += 20  # 低GI主食/水果额外加分
            elif gi > 0 and gi <= 55:
                score += 10
        if category == "protein":
            if fat < 10:
                score += 10  # 低脂蛋白加分
            if protein > 15:
                score += 5
        if category == "fats":
            score -= 10  # 控糖减少脂肪

    elif user_type == "weight_loss":
        score = 50.0
        if calories > 0:
            score += max(0, (500 - calories)) * 0.05  # 低热量加分
        score += protein * 1.0                          # 高蛋白加分
        score += fiber * 3.0                            # 高纤维加分
        if category == "protein":
            if fat < 10:
                score += 15
            if protein > 20:
                score += 10
        if calories < 100 and category in ("vegetables", "fruits"):
            score += 10  # 低热量蔬果
        if category == "grains" and fiber > 3:
            score += 10  # 全谷物

    elif user_type == "muscle_gain":
        score = 50.0
        score += protein * 1.5                           # 高蛋白加分
        score += calories * 0.02                         # 高热量略加分
        if category == "grains":
            score += carbs * 0.1                         # 高碳水主食
        if category == "protein":
            if protein > 25:
                score += 15
            if fat < 15:
                score += 5  # 避免过多脂肪
        if category == "fats":
            score += 5  # 增肌需要脂肪

    else:  # general
        score = 50.0
        score += fiber * 1.0
        score += protein * 0.5
        if calories > 0 and calories < 600:
            score += (600 - calories) * 0.02

    return round(score, 1)


def _pick_foods(pool: list[str], user_type: str, category: str,
                count: int = 1, top_k: int = 3) -> list[str]:
    """从食物池中按分数选取 top-K 中的随机食物"""
    if not pool or count <= 0:
        return []
    scored = [(name, _score_food(name, user_type, category)) for name in pool]
    scored.sort(key=lambda x: x[1], reverse=True)
    # 从 top-K 高分食物中随机选取，增加食谱多样性
    candidates = scored[:min(top_k, len(scored))]
    picked = random.sample(candidates, min(count, len(candidates)))
    return [name for name, _ in picked]


def _portion_to_grams(food_name: str, unit: str, count: float) -> int:
    """视觉份量 → 克重"""
    return round(get_gram_equivalent(food_name, unit) * count)


# ============================================================
# MealPlanner 类
# ============================================================
class MealPlanner:
    """智能配餐引擎"""

    def __init__(self, user_type: str = "general",
                 gender: str = "male",
                 age: int = 30,
                 activity: str = "light",
                 use_llm: bool = True,
                 llm_config: dict[str, Any] | None = None):
        # 用户画像
        self.user_type = user_type
        self.user_profile: dict[str, Any] = {"gender": gender, "age": age, "activity": activity}
        self.goal_label = GOAL_LABELS.get(user_type, "日常健康")

        # 从 advice_engine 获取每日营养目标
        rda: dict[str, Any] = get_user_rda(
            str(self.user_profile["gender"]),
            int(self.user_profile["age"]),
            str(self.user_profile["activity"]),
            user_type
        )
        # 获取每日的营养目标
        self.daily_rda: dict[str, Any] = rda
        # 获取每顿的目标
        self.meal_targets: dict[str, Any] = per_meal_rda(rda)

        # LLM 配置
        self.use_llm = use_llm
        self._llm_config = llm_config or {}
        self._llm_planner: Any = None

        # 当日饮食记录
        self.daily_log: list[dict[str, Any]] = []
        # 已记录的营养累计
        self._totals: dict[str, float] = {"carbs_g": 0.0, "protein_g": 0.0, "fat_g": 0.0,
                        "calories": 0.0, "fiber_g": 0.0}

    # ---------- 一日食谱生成 ----------
    def _init_llm_planner(self):
        """延迟初始化 LLMPlanner"""
        if self._llm_planner is None:
            from .llm_planner import LLMPlanner
            self._llm_planner = LLMPlanner(
                user_type=self.user_type,
                gender=self.user_profile["gender"],
                age=self.user_profile["age"],
                activity=self.user_profile["activity"],
                **self._llm_config,
            )

    def generate_daily_plan(self) -> dict[str, Any]:
        """生成一日食谱（调度器：LLM+Knowledge → rule fallback）"""
        if self.use_llm:
            self._init_llm_planner()
            if self._llm_planner.is_available():
                llm_plan: dict[str, Any] | None = self._llm_planner.generate_daily_plan()
                if llm_plan is not None:
                    return llm_plan
        return self.generate_daily_plan_rule()

    def generate_daily_plan_baseline(self) -> dict[str, Any] | None:
        """纯 LLM 基线食谱（无知识注入，用于实验对比）"""
        if not self.use_llm:
            return self.generate_daily_plan_rule()
        self._init_llm_planner()
        if not self._llm_planner.is_available():
            return None
        plan: dict[str, Any] | None = self._llm_planner.generate_baseline_plan()
        return plan

    def generate_daily_plan_rule(self) -> dict[str, Any]:
        """规则引擎食谱生成（原 generate_daily_plan，保留为兜底方案）"""
        meals = {}
        used_foods: set[str] = set()  # 避免一天内重复推荐

        for meal_name in ["breakfast", "lunch", "dinner", "snack"]:
            template = MEAL_TEMPLATES[meal_name]
            pools = MEAL_FOOD_POOLS[meal_name]
            meal_items = []

            for slot in template:
                cat: str = slot["category"]
                pool: list[str] = pools.get(cat, [])
                if not pool:
                    continue
                # 排除今天已经用过的食物
                available = [f for f in pool if f not in used_foods]
                if not available:
                    available = pool  # 如果都重复了，允许复用

                target: float = slot["target_count"]
                # 按分数选取
                picked = _pick_foods(available, self.user_type, cat, count=1)
                for food_name in picked:
                    target_unit: str = slot["target_unit"]
                    grams = _portion_to_grams(food_name, target_unit, target)
                    unit_info: dict[str, str] = VISUAL_UNITS.get(target_unit, {})
                    unit_zh: str = unit_info.get("zh", "")
                    if target == 0.5:
                        display = f"半{unit_zh}"
                    elif target == int(target):
                        display = f"{int(target)}{unit_zh}"
                    else:
                        display = f"{target}{unit_zh}"

                    nut = get_nutrition(food_name, grams) or {}
                    meal_items.append({
                        "name": food_name,
                        "category": cat,
                        "category_zh": CATEGORY_ZH.get(cat, cat),
                        "portion": display,
                        "grams": grams,
                        "calories": round(nut.get("calories", 0)),
                        "gi": nut.get("gi", 0),
                        "protein": round(nut.get("protein_g", 0), 1),
                        "carbs": round(nut.get("carbs_g", 0), 1),
                    })
                    used_foods.add(food_name)

            meals[meal_name] = meal_items

        # 计算全天营养汇总
        # Apply goal-specific adjustments from advice_engine per-meal
        from .advice_engine import GOAL_ADJUSTMENTS
        goal_config = GOAL_ADJUSTMENTS.get(self.user_type, {})
        per_meal_rda_dict = per_meal_rda(self.daily_rda)

        # Goal-specific per-meal target overrides
        target_carbs = per_meal_rda_dict["carbs_g"]
        target_protein = per_meal_rda_dict["protein_g"]
        target_fat = per_meal_rda_dict["fat_g"]
        target_calories = per_meal_rda_dict["energy_kcal"]
        target_fiber = per_meal_rda_dict.get("fiber_g", 8)

        if goal_config.get("carbs_max_per_meal"):
            target_carbs = min(target_carbs, goal_config["carbs_max_per_meal"])
        if goal_config.get("protein_min_per_meal"):
            target_protein = max(target_protein, goal_config["protein_min_per_meal"])
        if goal_config.get("fat_max_per_meal"):
            target_fat = min(target_fat, goal_config["fat_max_per_meal"])
        if goal_config.get("fiber_target_per_meal"):
            target_fiber = goal_config["fiber_target_per_meal"]

        daily_target = {
            "carbs_g": round(target_carbs * 3, 1),
            "protein_g": round(target_protein * 3, 1),
            "fat_g": round(target_fat * 3, 1),
            "calories": round(target_calories * 3),
            "fiber_g": round(target_fiber * 3, 1),
        }

        return {
            "meals": meals,
            "daily_target": daily_target,
            "goal_label": self.goal_label,
            "user_profile": self.user_profile,
            "daily_rda": self.daily_rda,
        }

    # ---------- 记录饮食 ----------
    def log_food(self, food_names: list[str],
                 manual_grams: dict[str, Any] | None = None) -> dict[str, Any]:
        """
        记录用户吃过的食物

        :param food_names: 食物名称列表（中文或英文）
        :param manual_grams: 手动指定克数 {name: grams}
        :return: 本次记录的详情
        """
        if manual_grams is None:
            manual_grams = {}

        # 解析食物名 → 数据库键名
        from .nutrition_db import SYNONYMS
        from .visual_portion import recommend_all_portions
        resolved: dict[str, str] = {}
        for raw in food_names:
            key = SYNONYMS.get(raw.lower().strip(), raw.lower().strip())
            resolved[raw.strip()] = key

        db_names = list(resolved.values())
        portion_recs, portion_summary = recommend_all_portions(db_names, self.user_type)

        items = []
        meal_totals = {"carbs_g": 0.0, "protein_g": 0.0, "fat_g": 0.0,
                       "calories": 0.0, "fiber_g": 0.0}

        for raw_name, db_name in resolved.items():
            rec = portion_recs.get(db_name, {})
            if db_name in manual_grams:
                grams = manual_grams[db_name]
            else:
                grams = rec.get("grams", 100)

            nut = get_nutrition(db_name, grams)
            if not nut:
                continue

            item = {
                "raw_name": raw_name,
                "db_name": db_name,
                "grams": grams,
                "portion": rec.get("visual_display", f"{grams}g"),
                "nutrition": nut,
            }
            items.append(item)
            for k in meal_totals:
                if k in nut:
                    meal_totals[k] += nut[k]

            # 加入日志
            self.daily_log.append(item)
            for k in self._totals:
                if k in nut:
                    self._totals[k] += nut[k]

        # 计算剩余
        remaining = self._calc_remaining()

        return {
            "items": items,
            "meal_totals": {k: round(v, 1) for k, v in meal_totals.items()},
            "today_totals": {k: round(v, 1) for k, v in self._totals.items()},
            "remaining": remaining,
            "portion_summary": portion_summary,
        }

    # ---------- 剩余计算 ----------
    def _calc_remaining(self) -> dict[str, Any]:
        """计算各营养素距每日目标的剩余量"""
        daily = self.daily_rda
        remaining = {
            "carbs_g": round(daily.get("daily_carbs_g", 0) - self._totals["carbs_g"], 1),
            "protein_g": round(daily.get("daily_protein_g", 0) - self._totals["protein_g"], 1),
            "fat_g": round(daily.get("daily_fat_g", 0) - self._totals["fat_g"], 1),
            "calories": round(daily.get("daily_energy_kcal", 0) - self._totals["calories"]),
            "fiber_g": round(daily.get("daily_fiber_g", 0) - self._totals["fiber_g"], 1),
        }
        # 进度条
        bars = {}
        for k, target_key in [("carbs_g", "daily_carbs_g"), ("protein_g", "daily_protein_g"),
                               ("fat_g", "daily_fat_g"), ("calories", "daily_energy_kcal"),
                               ("fiber_g", "daily_fiber_g")]:
            target = daily.get(target_key, 1)
            if target <= 0:
                target = 1
            pct = min(100, self._totals.get(k, 0) / target * 100)
            filled = int(pct / 5)
            bar = "#" * filled + "-" * (20 - filled)
            bars[k] = f"[{bar}] {pct:.0f}%"
        remaining["progress_bars"] = bars
        remaining["today_totals"] = {k: round(v, 1) for k, v in self._totals.items()}
        return remaining

    def get_remaining(self) -> dict[str, Any]:
        return self._calc_remaining()

    # ---------- 下一餐推荐 ----------
    def suggest_next_meal(self) -> dict[str, Any]:
        """基于剩余营养素缺口，推荐下一餐食物"""
        remaining = self._calc_remaining()

        # 判断缺口最大的营养素
        daily = self.daily_rda
        deficits = []
        for k, label, target_key in [
            ("carbs_g", "碳水化合物", "daily_carbs_g"),
            ("protein_g", "蛋白质", "daily_protein_g"),
            ("fat_g", "脂肪", "daily_fat_g"),
            ("fiber_g", "膳食纤维", "daily_fiber_g"),
            ("calories", "热量", "daily_energy_kcal"),
        ]:
            target = daily.get(target_key, 1)
            current = self._totals.get(k, 0)
            pct = current / target * 100 if target > 0 else 100
            deficits.append({"key": k, "label": label, "pct": pct, "remaining": remaining.get(k, 0)})

        # 找缺口最大的（最低完成率）
        deficits.sort(key=lambda x: x["pct"])
        top_deficit = deficits[0] if deficits else None

        # 根据缺口推荐食物
        suggestions = []
        if top_deficit and top_deficit["pct"] < 80:
            key = top_deficit["key"]
            if key == "calories" or key == "carbs_g":
                pool = MEAL_FOOD_POOLS["lunch"]["grains"] + MEAL_FOOD_POOLS["lunch"]["protein"]
                for name in _pick_foods(pool, self.user_type, "grains", 3):
                    suggestions.append({"name": name, "reason": "补充碳水化合物和能量"})
            elif key == "protein_g":
                pool = MEAL_FOOD_POOLS["lunch"]["protein"]
                for name in _pick_foods(pool, self.user_type, "protein", 3):
                    suggestions.append({"name": name, "reason": "补充蛋白质"})
            elif key == "fiber_g":
                pool = MEAL_FOOD_POOLS["lunch"]["vegetables"]
                for name in _pick_foods(pool, self.user_type, "vegetables", 3):
                    suggestions.append({"name": name, "reason": "补充膳食纤维"})
            else:
                pool = MEAL_FOOD_POOLS["dinner"]["vegetables"] + MEAL_FOOD_POOLS["dinner"]["protein"]
                for name in _pick_foods(pool, self.user_type, "protein", 3):
                    suggestions.append({"name": name, "reason": "均衡补充"})

        # 搭配模板
        best_meal = "dinner" if remaining.get("calories", 0) < 500 else "lunch"
        template = MEAL_TEMPLATES.get(best_meal, MEAL_TEMPLATES["lunch"])

        return {
            "deficits": deficits,
            "top_deficit": top_deficit,
            "suggestions": suggestions[:4],
            "recommended_meal_type": best_meal,
            "meal_template": template,
            "remaining": remaining,
        }

    # ---------- 今日总结 ----------
    def get_summary(self) -> dict[str, Any]:
        """今日饮食全面总结"""
        remaining = self._calc_remaining()
        daily = self.daily_rda

        # 调用 advice_engine 生成分析
        from .advice_engine import generate_advice
        totals_for_advice = {**self._totals,
                             "glycemic_load": 0.0, "avg_gi": 0}
        advice = generate_advice(
            totals_for_advice, self.user_type,
            self.user_profile["gender"],
            self.user_profile["age"],
            self.user_profile["activity"]
        )

        return {
            "goal_label": self.goal_label,
            "user_profile": self.user_profile,
            "daily_rda": daily,
            "today_totals": {k: round(v, 1) for k, v in self._totals.items()},
            "remaining": remaining,
            "log_count": len(self.daily_log),
            "advice": advice,
            "logged_foods": [
                {"name": item.get("raw_name", item.get("db_name", "")),
                 "grams": item["grams"],
                 "portion": item.get("portion", "")}
                for item in self.daily_log
            ],
        }

    # ---------- 重置 ----------
    def reset(self):
        """重置当日饮食记录"""
        self.daily_log.clear()
        self._totals = {"carbs_g": 0.0, "protein_g": 0.0, "fat_g": 0.0,
                        "calories": 0.0, "fiber_g": 0.0}
