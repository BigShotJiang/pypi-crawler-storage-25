"""
营养数据库：宏量营养素 + 微量元素（钙、铁、锌、镁、铬、钾、膳食纤维）
数据来源：中国食物成分表（第6版）+ USDA FoodData Central
每100g可食部的营养数据
"""

# ============================================================
# 主食类 (Staples)
# ============================================================
FOOD_NUTRITION = {
    "米饭": {
        "carbs": 28.0, "protein": 2.5, "fat": 0.3, "calories": 130, "gi": 73,
        "calcium_mg": 3, "iron_mg": 0.2, "zinc_mg": 0.6, "magnesium_mg": 12,
        "chromium_ug": 2, "potassium_mg": 35, "fiber_g": 0.4
    },
    "糙米饭": {
        "carbs": 23.0, "protein": 2.6, "fat": 1.0, "calories": 123, "gi": 55,
        "calcium_mg": 10, "iron_mg": 0.5, "zinc_mg": 0.8, "magnesium_mg": 43,
        "chromium_ug": 3, "potassium_mg": 80, "fiber_g": 1.6
    },
    "面条": {
        "carbs": 25.0, "protein": 4.5, "fat": 1.2, "calories": 138, "gi": 55,
        "calcium_mg": 15, "iron_mg": 0.6, "zinc_mg": 0.5, "magnesium_mg": 18,
        "chromium_ug": 1, "potassium_mg": 30, "fiber_g": 1.0
    },
    "馒头": {
        "carbs": 44.0, "protein": 6.2, "fat": 1.0, "calories": 223, "gi": 67,
        "calcium_mg": 18, "iron_mg": 0.8, "zinc_mg": 0.4, "magnesium_mg": 20,
        "chromium_ug": 2, "potassium_mg": 100, "fiber_g": 1.5
    },
    "燕麦": {
        "carbs": 66.0, "protein": 13.5, "fat": 6.7, "calories": 377, "gi": 40,
        "calcium_mg": 54, "iron_mg": 4.7, "zinc_mg": 2.0, "magnesium_mg": 138,
        "chromium_ug": 5, "potassium_mg": 350, "fiber_g": 10.6
    },
    "玉米": {
        "carbs": 19.0, "protein": 3.3, "fat": 1.2, "calories": 96, "gi": 55,
        "calcium_mg": 2, "iron_mg": 0.5, "zinc_mg": 0.4, "magnesium_mg": 32,
        "chromium_ug": 2, "potassium_mg": 270, "fiber_g": 2.4
    },
    "红薯": {
        "carbs": 20.1, "protein": 1.6, "fat": 0.1, "calories": 86, "gi": 54,
        "calcium_mg": 30, "iron_mg": 0.6, "zinc_mg": 0.3, "magnesium_mg": 25,
        "chromium_ug": 2, "potassium_mg": 337, "fiber_g": 3.0
    },
    "白面包": {
        "carbs": 49.0, "protein": 9.0, "fat": 3.3, "calories": 265, "gi": 75,
        "calcium_mg": 100, "iron_mg": 3.6, "zinc_mg": 0.8, "magnesium_mg": 25,
        "chromium_ug": 2, "potassium_mg": 120, "fiber_g": 2.7
    },
    "全麦面包": {
        "carbs": 41.0, "protein": 10.0, "fat": 3.0, "calories": 247, "gi": 50,
        "calcium_mg": 130, "iron_mg": 3.0, "zinc_mg": 1.2, "magnesium_mg": 54,
        "chromium_ug": 3, "potassium_mg": 200, "fiber_g": 6.0
    },
    "粥": {
        "carbs": 9.0, "protein": 1.1, "fat": 0.1, "calories": 46, "gi": 70,
        "calcium_mg": 5, "iron_mg": 0.1, "zinc_mg": 0.2, "magnesium_mg": 5,
        "chromium_ug": 1, "potassium_mg": 12, "fiber_g": 0.1
    },

    # ============================================================
    # 肉类 (Meat & Poultry)
    # ============================================================
    "鸡胸肉": {
        "carbs": 0.0, "protein": 31.0, "fat": 3.6, "calories": 165, "gi": 0,
        "calcium_mg": 15, "iron_mg": 1.0, "zinc_mg": 1.0, "magnesium_mg": 29,
        "chromium_ug": 8, "potassium_mg": 256, "fiber_g": 0
    },
    "牛肉": {
        "carbs": 0.0, "protein": 26.0, "fat": 15.0, "calories": 250, "gi": 0,
        "calcium_mg": 18, "iron_mg": 2.6, "zinc_mg": 4.8, "magnesium_mg": 21,
        "chromium_ug": 5, "potassium_mg": 318, "fiber_g": 0
    },
    "瘦牛肉": {
        "carbs": 0.0, "protein": 28.0, "fat": 7.0, "calories": 190, "gi": 0,
        "calcium_mg": 12, "iron_mg": 3.0, "zinc_mg": 5.0, "magnesium_mg": 25,
        "chromium_ug": 6, "potassium_mg": 350, "fiber_g": 0
    },
    "猪肉": {
        "carbs": 0.0, "protein": 20.0, "fat": 30.0, "calories": 395, "gi": 0,
        "calcium_mg": 6, "iron_mg": 1.6, "zinc_mg": 2.0, "magnesium_mg": 18,
        "chromium_ug": 3, "potassium_mg": 300, "fiber_g": 0
    },
    "瘦猪肉": {
        "carbs": 0.0, "protein": 22.0, "fat": 10.0, "calories": 190, "gi": 0,
        "calcium_mg": 5, "iron_mg": 1.5, "zinc_mg": 2.5, "magnesium_mg": 22,
        "chromium_ug": 4, "potassium_mg": 320, "fiber_g": 0
    },
    "羊肉": {
        "carbs": 0.0, "protein": 20.5, "fat": 14.0, "calories": 220, "gi": 0,
        "calcium_mg": 9, "iron_mg": 2.3, "zinc_mg": 3.2, "magnesium_mg": 19,
        "chromium_ug": 4, "potassium_mg": 280, "fiber_g": 0
    },
    "鸭肉": {
        "carbs": 0.1, "protein": 18.0, "fat": 28.0, "calories": 337, "gi": 0,
        "calcium_mg": 12, "iron_mg": 2.7, "zinc_mg": 1.4, "magnesium_mg": 20,
        "chromium_ug": 5, "potassium_mg": 210, "fiber_g": 0
    },

    # ============================================================
    # 水产类 (Seafood)
    # ============================================================
    "鱼肉": {
        "carbs": 0.0, "protein": 18.0, "fat": 4.0, "calories": 110, "gi": 0,
        "calcium_mg": 50, "iron_mg": 0.5, "zinc_mg": 0.8, "magnesium_mg": 30,
        "chromium_ug": 2, "potassium_mg": 400, "fiber_g": 0
    },
    "三文鱼": {
        "carbs": 0.0, "protein": 20.0, "fat": 13.0, "calories": 208, "gi": 0,
        "calcium_mg": 12, "iron_mg": 0.8, "zinc_mg": 0.6, "magnesium_mg": 29,
        "chromium_ug": 3, "potassium_mg": 490, "fiber_g": 0
    },
    "虾仁": {
        "carbs": 0.0, "protein": 24.0, "fat": 0.3, "calories": 99, "gi": 0,
        "calcium_mg": 70, "iron_mg": 0.4, "zinc_mg": 1.6, "magnesium_mg": 28,
        "chromium_ug": 3, "potassium_mg": 220, "fiber_g": 0
    },

    # ============================================================
    # 蔬菜类 (Vegetables)
    # ============================================================
    "西兰花": {
        "carbs": 7.0, "protein": 2.8, "fat": 0.4, "calories": 34, "gi": 15,
        "calcium_mg": 47, "iron_mg": 0.7, "zinc_mg": 0.4, "magnesium_mg": 21,
        "chromium_ug": 3, "potassium_mg": 316, "fiber_g": 2.6
    },
    "菠菜": {
        "carbs": 3.6, "protein": 2.9, "fat": 0.4, "calories": 23, "gi": 15,
        "calcium_mg": 99, "iron_mg": 2.7, "zinc_mg": 0.5, "magnesium_mg": 79,
        "chromium_ug": 3, "potassium_mg": 558, "fiber_g": 2.2
    },
    "番茄": {
        "carbs": 4.0, "protein": 0.9, "fat": 0.2, "calories": 18, "gi": 15,
        "calcium_mg": 10, "iron_mg": 0.3, "zinc_mg": 0.2, "magnesium_mg": 11,
        "chromium_ug": 1, "potassium_mg": 237, "fiber_g": 1.2
    },
    "黄瓜": {
        "carbs": 2.9, "protein": 0.7, "fat": 0.1, "calories": 15, "gi": 15,
        "calcium_mg": 14, "iron_mg": 0.2, "zinc_mg": 0.2, "magnesium_mg": 12,
        "chromium_ug": 1, "potassium_mg": 140, "fiber_g": 0.5
    },
    "卷心菜": {
        "carbs": 3.2, "protein": 1.3, "fat": 0.1, "calories": 17, "gi": 15,
        "calcium_mg": 40, "iron_mg": 0.5, "zinc_mg": 0.2, "magnesium_mg": 12,
        "chromium_ug": 2, "potassium_mg": 200, "fiber_g": 1.8
    },
    "胡萝卜": {
        "carbs": 8.8, "protein": 0.8, "fat": 0.2, "calories": 37, "gi": 40,
        "calcium_mg": 33, "iron_mg": 0.3, "zinc_mg": 0.2, "magnesium_mg": 12,
        "chromium_ug": 2, "potassium_mg": 320, "fiber_g": 2.8
    },
    "芹菜": {
        "carbs": 3.3, "protein": 0.7, "fat": 0.2, "calories": 14, "gi": 15,
        "calcium_mg": 40, "iron_mg": 0.2, "zinc_mg": 0.1, "magnesium_mg": 11,
        "chromium_ug": 2, "potassium_mg": 260, "fiber_g": 1.6
    },
    "生菜": {
        "carbs": 2.0, "protein": 1.0, "fat": 0.1, "calories": 13, "gi": 15,
        "calcium_mg": 18, "iron_mg": 0.5, "zinc_mg": 0.2, "magnesium_mg": 8,
        "chromium_ug": 1, "potassium_mg": 140, "fiber_g": 1.3
    },
    "甜椒": {
        "carbs": 5.3, "protein": 0.9, "fat": 0.2, "calories": 22, "gi": 15,
        "calcium_mg": 7, "iron_mg": 0.3, "zinc_mg": 0.1, "magnesium_mg": 10,
        "chromium_ug": 1, "potassium_mg": 210, "fiber_g": 1.7
    },
    "茄子": {
        "carbs": 5.9, "protein": 1.0, "fat": 0.2, "calories": 25, "gi": 15,
        "calcium_mg": 9, "iron_mg": 0.2, "zinc_mg": 0.2, "magnesium_mg": 14,
        "chromium_ug": 1, "potassium_mg": 229, "fiber_g": 3.0
    },
    "蘑菇": {
        "carbs": 5.0, "protein": 3.0, "fat": 0.3, "calories": 27, "gi": 15,
        "calcium_mg": 2, "iron_mg": 0.3, "zinc_mg": 0.9, "magnesium_mg": 9,
        "chromium_ug": 2, "potassium_mg": 320, "fiber_g": 1.5
    },
    "四季豆": {
        "carbs": 7.0, "protein": 1.8, "fat": 0.1, "calories": 31, "gi": 15,
        "calcium_mg": 37, "iron_mg": 1.0, "zinc_mg": 0.3, "magnesium_mg": 25,
        "chromium_ug": 2, "potassium_mg": 209, "fiber_g": 2.7
    },
    "土豆": {
        "carbs": 17.0, "protein": 2.0, "fat": 0.1, "calories": 77, "gi": 62,
        "calcium_mg": 8, "iron_mg": 0.8, "zinc_mg": 0.3, "magnesium_mg": 23,
        "chromium_ug": 2, "potassium_mg": 379, "fiber_g": 1.7
    },

    # ============================================================
    # 水果类 (Fruits)
    # ============================================================
    "苹果": {
        "carbs": 14.0, "protein": 0.3, "fat": 0.2, "calories": 52, "gi": 36,
        "calcium_mg": 6, "iron_mg": 0.1, "zinc_mg": 0.1, "magnesium_mg": 5,
        "chromium_ug": 1, "potassium_mg": 107, "fiber_g": 2.4
    },
    "香蕉": {
        "carbs": 23.0, "protein": 1.1, "fat": 0.3, "calories": 89, "gi": 52,
        "calcium_mg": 5, "iron_mg": 0.3, "zinc_mg": 0.2, "magnesium_mg": 27,
        "chromium_ug": 1, "potassium_mg": 358, "fiber_g": 2.6
    },
    "橙子": {
        "carbs": 11.0, "protein": 0.9, "fat": 0.1, "calories": 47, "gi": 33,
        "calcium_mg": 40, "iron_mg": 0.1, "zinc_mg": 0.1, "magnesium_mg": 10,
        "chromium_ug": 1, "potassium_mg": 181, "fiber_g": 2.4
    },
    "葡萄": {
        "carbs": 18.0, "protein": 0.7, "fat": 0.2, "calories": 69, "gi": 46,
        "calcium_mg": 10, "iron_mg": 0.4, "zinc_mg": 0.1, "magnesium_mg": 7,
        "chromium_ug": 1, "potassium_mg": 191, "fiber_g": 0.9
    },
    "西瓜": {
        "carbs": 7.5, "protein": 0.6, "fat": 0.2, "calories": 30, "gi": 72,
        "calcium_mg": 7, "iron_mg": 0.2, "zinc_mg": 0.1, "magnesium_mg": 10,
        "chromium_ug": 1, "potassium_mg": 112, "fiber_g": 0.4
    },
    "猕猴桃": {
        "carbs": 15.0, "protein": 1.1, "fat": 0.5, "calories": 61, "gi": 39,
        "calcium_mg": 34, "iron_mg": 0.3, "zinc_mg": 0.1, "magnesium_mg": 17,
        "chromium_ug": 1, "potassium_mg": 312, "fiber_g": 3.0
    },
    "草莓": {
        "carbs": 7.7, "protein": 0.7, "fat": 0.3, "calories": 32, "gi": 25,
        "calcium_mg": 16, "iron_mg": 0.4, "zinc_mg": 0.1, "magnesium_mg": 13,
        "chromium_ug": 1, "potassium_mg": 153, "fiber_g": 2.0
    },
    "梨": {
        "carbs": 15.5, "protein": 0.4, "fat": 0.1, "calories": 57, "gi": 33,
        "calcium_mg": 9, "iron_mg": 0.2, "zinc_mg": 0.1, "magnesium_mg": 7,
        "chromium_ug": 1, "potassium_mg": 120, "fiber_g": 3.1
    },

    # ============================================================
    # 豆制品 (Soy & Tofu)
    # ============================================================
    "嫩豆腐": {
        "carbs": 1.9, "protein": 8.1, "fat": 4.8, "calories": 84, "gi": 15,
        "calcium_mg": 105, "iron_mg": 1.3, "zinc_mg": 0.6, "magnesium_mg": 27,
        "chromium_ug": 2, "potassium_mg": 120, "fiber_g": 0.3
    },
    "老豆腐": {
        "carbs": 2.0, "protein": 10.0, "fat": 5.0, "calories": 95, "gi": 15,
        "calcium_mg": 120, "iron_mg": 1.5, "zinc_mg": 0.8, "magnesium_mg": 30,
        "chromium_ug": 2, "potassium_mg": 140, "fiber_g": 0.5
    },
    "豆浆": {
        "carbs": 1.2, "protein": 3.0, "fat": 1.5, "calories": 32, "gi": 30,
        "calcium_mg": 4, "iron_mg": 0.4, "zinc_mg": 0.2, "magnesium_mg": 16,
        "chromium_ug": 1, "potassium_mg": 120, "fiber_g": 0.4
    },
    "毛豆": {
        "carbs": 9.9, "protein": 11.0, "fat": 7.0, "calories": 147, "gi": 15,
        "calcium_mg": 63, "iron_mg": 2.2, "zinc_mg": 1.0, "magnesium_mg": 60,
        "chromium_ug": 4, "potassium_mg": 500, "fiber_g": 5.2
    },

    # ============================================================
    # 蛋奶类 (Eggs & Dairy)
    # ============================================================
    "鸡蛋": {
        "carbs": 1.1, "protein": 13.0, "fat": 9.5, "calories": 144, "gi": 0,
        "calcium_mg": 56, "iron_mg": 1.8, "zinc_mg": 1.1, "magnesium_mg": 12,
        "chromium_ug": 3, "potassium_mg": 140, "fiber_g": 0
    },
    "蛋白": {
        "carbs": 0.7, "protein": 11.0, "fat": 0.2, "calories": 52, "gi": 0,
        "calcium_mg": 10, "iron_mg": 0.1, "zinc_mg": 0.1, "magnesium_mg": 11,
        "chromium_ug": 1, "potassium_mg": 160, "fiber_g": 0
    },
    "全脂牛奶": {
        "carbs": 5.0, "protein": 3.1, "fat": 3.4, "calories": 65, "gi": 27,
        "calcium_mg": 120, "iron_mg": 0.1, "zinc_mg": 0.4, "magnesium_mg": 12,
        "chromium_ug": 1, "potassium_mg": 150, "fiber_g": 0
    },
    "脱脂牛奶": {
        "carbs": 5.0, "protein": 3.4, "fat": 0.1, "calories": 35, "gi": 27,
        "calcium_mg": 125, "iron_mg": 0.1, "zinc_mg": 0.4, "magnesium_mg": 12,
        "chromium_ug": 1, "potassium_mg": 160, "fiber_g": 0
    },
    "酸奶": {
        "carbs": 9.0, "protein": 3.5, "fat": 3.0, "calories": 72, "gi": 35,
        "calcium_mg": 110, "iron_mg": 0.1, "zinc_mg": 0.5, "magnesium_mg": 12,
        "chromium_ug": 1, "potassium_mg": 150, "fiber_g": 0
    },
    "奶酪": {
        "carbs": 1.3, "protein": 25.0, "fat": 33.0, "calories": 400, "gi": 0,
        "calcium_mg": 700, "iron_mg": 0.3, "zinc_mg": 3.0, "magnesium_mg": 25,
        "chromium_ug": 2, "potassium_mg": 80, "fiber_g": 0
    },

    # ============================================================
    # 坚果类 (Nuts & Seeds)
    # ============================================================
    "花生": {
        "carbs": 16.0, "protein": 26.0, "fat": 49.0, "calories": 567, "gi": 14,
        "calcium_mg": 54, "iron_mg": 2.2, "zinc_mg": 3.3, "magnesium_mg": 168,
        "chromium_ug": 6, "potassium_mg": 705, "fiber_g": 8.5
    },
    "核桃": {
        "carbs": 14.0, "protein": 15.0, "fat": 65.0, "calories": 654, "gi": 15,
        "calcium_mg": 98, "iron_mg": 2.9, "zinc_mg": 3.1, "magnesium_mg": 158,
        "chromium_ug": 4, "potassium_mg": 440, "fiber_g": 6.7
    },
    "杏仁": {
        "carbs": 20.0, "protein": 21.0, "fat": 50.0, "calories": 579, "gi": 15,
        "calcium_mg": 270, "iron_mg": 3.7, "zinc_mg": 3.3, "magnesium_mg": 270,
        "chromium_ug": 5, "potassium_mg": 733, "fiber_g": 12.5
    },

    # ============================================================
    # 油脂/调味品 (Oils & Condiments)
    # ============================================================
    "食用油": {
        "carbs": 0.0, "protein": 0.0, "fat": 100.0, "calories": 900, "gi": 0,
        "calcium_mg": 0, "iron_mg": 0, "zinc_mg": 0, "magnesium_mg": 0,
        "chromium_ug": 0, "potassium_mg": 0, "fiber_g": 0
    },
    "橄榄油": {
        "carbs": 0.0, "protein": 0.0, "fat": 100.0, "calories": 884, "gi": 0,
        "calcium_mg": 1, "iron_mg": 0.6, "zinc_mg": 0.1, "magnesium_mg": 0,
        "chromium_ug": 0, "potassium_mg": 1, "fiber_g": 0
    },

    # ============================================================
    # 加工食品 (Processed Foods)
    # ============================================================
    "披萨": {
        "carbs": 33.0, "protein": 11.0, "fat": 10.0, "calories": 266, "gi": 60,
        "calcium_mg": 188, "iron_mg": 2.5, "zinc_mg": 1.4, "magnesium_mg": 24,
        "chromium_ug": 2, "potassium_mg": 180, "fiber_g": 2.0
    },
    "热狗": {
        "carbs": 18.0, "protein": 10.0, "fat": 26.0, "calories": 350, "gi": 55,
        "calcium_mg": 60, "iron_mg": 1.5, "zinc_mg": 1.2, "magnesium_mg": 15,
        "chromium_ug": 2, "potassium_mg": 150, "fiber_g": 0.5
    },
    "三明治": {
        "carbs": 28.0, "protein": 12.0, "fat": 8.0, "calories": 240, "gi": 55,
        "calcium_mg": 100, "iron_mg": 2.0, "zinc_mg": 1.0, "magnesium_mg": 25,
        "chromium_ug": 2, "potassium_mg": 200, "fiber_g": 1.5
    },
    "甜甜圈": {
        "carbs": 47.0, "protein": 4.0, "fat": 19.0, "calories": 388, "gi": 76,
        "calcium_mg": 40, "iron_mg": 1.5, "zinc_mg": 0.3, "magnesium_mg": 10,
        "chromium_ug": 1, "potassium_mg": 100, "fiber_g": 1.0
    },
    "蛋糕": {
        "carbs": 53.0, "protein": 4.0, "fat": 16.0, "calories": 380, "gi": 67,
        "calcium_mg": 50, "iron_mg": 1.0, "zinc_mg": 0.3, "magnesium_mg": 10,
        "chromium_ug": 1, "potassium_mg": 100, "fiber_g": 0.5
    },
    "薯条": {
        "carbs": 35.0, "protein": 3.5, "fat": 17.0, "calories": 312, "gi": 64,
        "calcium_mg": 10, "iron_mg": 0.7, "zinc_mg": 0.4, "magnesium_mg": 23,
        "chromium_ug": 1, "potassium_mg": 450, "fiber_g": 3.2
    },
    "饺子": {
        "carbs": 25.0, "protein": 8.0, "fat": 7.0, "calories": 200, "gi": 55,
        "calcium_mg": 40, "iron_mg": 1.0, "zinc_mg": 0.5, "magnesium_mg": 15,
        "chromium_ug": 2, "potassium_mg": 150, "fiber_g": 1.0
    },

    # ============================================================
    # 扩展水果 (Extended Fruits)
    # ============================================================
    "桃子": {
        "carbs": 10.0, "protein": 0.9, "fat": 0.3, "calories": 42, "gi": 28,
        "calcium_mg": 6, "iron_mg": 0.3, "zinc_mg": 0.1, "magnesium_mg": 8,
        "chromium_ug": 1, "potassium_mg": 190, "fiber_g": 1.5
    },
    "芒果": {
        "carbs": 15.0, "protein": 0.8, "fat": 0.4, "calories": 60, "gi": 41,
        "calcium_mg": 11, "iron_mg": 0.2, "zinc_mg": 0.1, "magnesium_mg": 10,
        "chromium_ug": 1, "potassium_mg": 168, "fiber_g": 1.6
    },
    "菠萝": {
        "carbs": 13.0, "protein": 0.5, "fat": 0.1, "calories": 50, "gi": 59,
        "calcium_mg": 13, "iron_mg": 0.3, "zinc_mg": 0.1, "magnesium_mg": 12,
        "chromium_ug": 1, "potassium_mg": 109, "fiber_g": 1.4
    },
    "樱桃": {
        "carbs": 16.0, "protein": 1.1, "fat": 0.2, "calories": 63, "gi": 20,
        "calcium_mg": 13, "iron_mg": 0.4, "zinc_mg": 0.1, "magnesium_mg": 11,
        "chromium_ug": 1, "potassium_mg": 222, "fiber_g": 2.1
    },
    "蓝莓": {
        "carbs": 14.5, "protein": 0.7, "fat": 0.3, "calories": 57, "gi": 28,
        "calcium_mg": 6, "iron_mg": 0.3, "zinc_mg": 0.2, "magnesium_mg": 6,
        "chromium_ug": 1, "potassium_mg": 77, "fiber_g": 2.4
    },
    "荔枝": {
        "carbs": 16.5, "protein": 0.8, "fat": 0.4, "calories": 66, "gi": 50,
        "calcium_mg": 5, "iron_mg": 0.3, "zinc_mg": 0.1, "magnesium_mg": 10,
        "chromium_ug": 1, "potassium_mg": 171, "fiber_g": 1.3
    },
    "柠檬": {
        "carbs": 9.3, "protein": 1.1, "fat": 0.3, "calories": 29, "gi": 20,
        "calcium_mg": 26, "iron_mg": 0.6, "zinc_mg": 0.1, "magnesium_mg": 8,
        "chromium_ug": 1, "potassium_mg": 138, "fiber_g": 2.8
    },
    "牛油果": {
        "carbs": 8.5, "protein": 2.0, "fat": 14.7, "calories": 160, "gi": 10,
        "calcium_mg": 12, "iron_mg": 0.6, "zinc_mg": 0.6, "magnesium_mg": 29,
        "chromium_ug": 2, "potassium_mg": 485, "fiber_g": 6.7
    },

    # ============================================================
    # 扩展蔬菜 (Extended Vegetables)
    # ============================================================
    "洋葱": {
        "carbs": 9.3, "protein": 1.1, "fat": 0.1, "calories": 40, "gi": 10,
        "calcium_mg": 23, "iron_mg": 0.2, "zinc_mg": 0.2, "magnesium_mg": 10,
        "chromium_ug": 1, "potassium_mg": 146, "fiber_g": 1.7
    },
    "大蒜": {
        "carbs": 33.0, "protein": 6.4, "fat": 0.5, "calories": 149, "gi": 10,
        "calcium_mg": 181, "iron_mg": 1.7, "zinc_mg": 1.2, "magnesium_mg": 25,
        "chromium_ug": 2, "potassium_mg": 401, "fiber_g": 2.1
    },
    "姜": {
        "carbs": 17.8, "protein": 1.8, "fat": 0.8, "calories": 80, "gi": 10,
        "calcium_mg": 16, "iron_mg": 0.6, "zinc_mg": 0.3, "magnesium_mg": 43,
        "chromium_ug": 1, "potassium_mg": 415, "fiber_g": 2.0
    },
    "南瓜": {
        "carbs": 7.0, "protein": 1.0, "fat": 0.1, "calories": 26, "gi": 65,
        "calcium_mg": 21, "iron_mg": 0.8, "zinc_mg": 0.3, "magnesium_mg": 12,
        "chromium_ug": 2, "potassium_mg": 340, "fiber_g": 1.0
    },
    "莲藕": {
        "carbs": 16.4, "protein": 2.6, "fat": 0.1, "calories": 74, "gi": 38,
        "calcium_mg": 39, "iron_mg": 1.4, "zinc_mg": 0.4, "magnesium_mg": 19,
        "chromium_ug": 2, "potassium_mg": 243, "fiber_g": 2.2
    },
    "竹笋": {
        "carbs": 3.0, "protein": 2.6, "fat": 0.3, "calories": 23, "gi": 15,
        "calcium_mg": 9, "iron_mg": 0.5, "zinc_mg": 0.4, "magnesium_mg": 4,
        "chromium_ug": 1, "potassium_mg": 389, "fiber_g": 2.2
    },
    "海带": {
        "carbs": 5.1, "protein": 5.8, "fat": 0.3, "calories": 43, "gi": 15,
        "calcium_mg": 150, "iron_mg": 2.5, "zinc_mg": 0.5, "magnesium_mg": 107,
        "chromium_ug": 5, "potassium_mg": 356, "fiber_g": 0.5
    },
    "豆芽": {
        "carbs": 3.0, "protein": 3.0, "fat": 0.2, "calories": 24, "gi": 15,
        "calcium_mg": 9, "iron_mg": 0.9, "zinc_mg": 0.4, "magnesium_mg": 21,
        "chromium_ug": 2, "potassium_mg": 149, "fiber_g": 1.8
    },
}

# ============================================================
# 同义词映射（支持中英文、别称）
# ============================================================
SYNONYMS = {
    # ===== 主食类 =====
    # 米饭
    "white rice": "米饭", "cooked rice": "米饭", "steamed rice": "米饭", "rice": "米饭",
    "米饭": "米饭", "白米饭": "米饭", "大米饭": "米饭",
    # 糙米饭
    "brown rice": "糙米饭", "糙米": "糙米饭", "糙米饭": "糙米饭",
    # 面条
    "noodles": "面条", "pasta": "面条", "spaghetti": "面条",
    "面条": "面条", "面": "面条", "面食": "面条", "挂面": "面条",
    # 馒头
    "steamed bun": "馒头", "mantou": "馒头", "馒头": "馒头", "馍": "馒头",
    # 燕麦
    "oats": "燕麦", "oat": "燕麦", "oatmeal": "燕麦",
    "燕麦": "燕麦", "燕麦片": "燕麦", "麦片": "燕麦",
    # 玉米
    "corn": "玉米", "maize": "玉米", "玉米": "玉米", "玉米棒": "玉米",
    # 红薯
    "sweet potato": "红薯", "yam": "红薯",
    "红薯": "红薯", "地瓜": "红薯", "番薯": "红薯", "甘薯": "红薯",
    # 白面包
    "bread": "白面包", "toast": "白面包", "white bread": "白面包",
    "面包": "白面包", "吐司": "白面包",
    # 全麦面包
    "whole wheat bread": "全麦面包", "wholemeal bread": "全麦面包",
    "全麦面包": "全麦面包", "全麦": "全麦面包",
    # 粥
    "congee": "粥", "rice porridge": "粥",
    "粥": "粥", "稀饭": "粥", "白粥": "粥", "米粥": "粥",
    # 土豆
    "potato": "土豆", "土豆": "土豆", "马铃薯": "土豆", "洋芋": "土豆",

    # ===== 蛋白质类 =====
    "chicken": "鸡胸肉", "chicken breast": "鸡胸肉",
    "鸡胸肉": "鸡胸肉", "鸡肉": "鸡胸肉", "鸡胸": "鸡胸肉",
    "beef": "牛肉", "牛肉": "牛肉",
    "lean beef": "瘦牛肉", "瘦牛肉": "瘦牛肉", "牛瘦肉": "瘦牛肉",
    "pork": "猪肉", "猪肉": "猪肉",
    "lean pork": "瘦猪肉", "瘦猪肉": "瘦猪肉", "猪瘦肉": "瘦猪肉",
    "lamb": "羊肉", "羊肉": "羊肉", "羊腿肉": "羊肉",
    "duck": "鸭肉", "鸭肉": "鸭肉", "鸭": "鸭肉",
    "fish": "鱼肉", "鱼肉": "鱼肉", "鱼": "鱼肉", "鱼片": "鱼肉", "白鱼": "鱼肉",
    "salmon": "三文鱼", "三文鱼": "三文鱼",
    "shrimp": "虾仁", "虾仁": "虾仁", "虾": "虾仁", "大虾": "虾仁", "虾肉": "虾仁",
    "tofu": "嫩豆腐", "嫩豆腐": "嫩豆腐",
    "firm tofu": "老豆腐", "豆腐干": "老豆腐", "老豆腐": "老豆腐", "硬豆腐": "老豆腐",
    "edamame": "毛豆", "soy beans": "毛豆", "毛豆": "毛豆", "豆子": "毛豆",
    "egg": "鸡蛋", "鸡蛋": "鸡蛋", "全蛋": "鸡蛋",
    "egg white": "蛋白", "蛋白": "蛋白", "蛋清": "蛋白",
    "milk": "全脂牛奶", "whole milk": "全脂牛奶",
    "牛奶": "全脂牛奶", "全脂奶": "全脂牛奶",
    "skim milk": "脱脂牛奶", "low fat milk": "脱脂牛奶",
    "脱脂牛奶": "脱脂牛奶", "脱脂奶": "脱脂牛奶", "低脂奶": "脱脂牛奶",
    "yogurt": "酸奶", "酸奶": "酸奶", "优格": "酸奶",
    "cheese": "奶酪", "奶酪": "奶酪", "芝士": "奶酪", "起司": "奶酪",
    "soy milk": "豆浆", "豆浆": "豆浆", "豆奶": "豆浆", "豆汁": "豆浆",

    # ===== 蔬菜类 =====
    "broccoli": "西兰花", "西兰花": "西兰花", "花椰菜": "西兰花", "青花菜": "西兰花",
    "spinach": "菠菜", "菠菜": "菠菜",
    "tomato": "番茄", "番茄": "番茄", "西红柿": "番茄",
    "cucumber": "黄瓜", "黄瓜": "黄瓜", "青瓜": "黄瓜",
    "cabbage": "卷心菜", "卷心菜": "卷心菜", "包菜": "卷心菜", "圆白菜": "卷心菜", "甘蓝": "卷心菜",
    "carrot": "胡萝卜", "胡萝卜": "胡萝卜",
    "celery": "芹菜", "芹菜": "芹菜",
    "lettuce": "生菜", "生菜": "生菜", "莴苣": "生菜",
    "bell pepper": "甜椒", "甜椒": "甜椒", "彩椒": "甜椒", "柿子椒": "甜椒",
    "eggplant": "茄子", "茄子": "茄子", "矮瓜": "茄子",
    "mushroom": "蘑菇", "蘑菇": "蘑菇", "菌菇": "蘑菇", "香菇": "蘑菇",
    "green beans": "四季豆", "四季豆": "四季豆", "豆角": "四季豆", "刀豆": "四季豆",
    "onion": "洋葱", "洋葱": "洋葱", "圆葱": "洋葱",
    "garlic": "大蒜", "大蒜": "大蒜", "蒜": "大蒜", "蒜瓣": "大蒜",
    "ginger": "姜", "姜": "姜", "生姜": "姜",
    "pumpkin": "南瓜", "南瓜": "南瓜", "倭瓜": "南瓜",
    "lotus root": "莲藕", "莲藕": "莲藕", "藕": "莲藕", "藕片": "莲藕",
    "bamboo shoot": "竹笋", "竹笋": "竹笋", "笋": "竹笋", "春笋": "竹笋",
    "seaweed": "海带", "kelp": "海带", "海带": "海带", "昆布": "海带",
    "bean sprouts": "豆芽", "豆芽": "豆芽", "芽菜": "豆芽",

    # ===== 水果类 =====
    "apple": "苹果", "苹果": "苹果",
    "banana": "香蕉", "香蕉": "香蕉",
    "orange": "橙子", "橙子": "橙子", "橙": "橙子", "橘子": "橙子",
    "grapes": "葡萄", "grape": "葡萄", "葡萄": "葡萄",
    "watermelon": "西瓜", "西瓜": "西瓜",
    "kiwi": "猕猴桃", "kiwifruit": "猕猴桃", "猕猴桃": "猕猴桃", "奇异果": "猕猴桃",
    "strawberry": "草莓", "草莓": "草莓", "士多啤梨": "草莓",
    "pear": "梨", "梨": "梨", "雪梨": "梨",
    "peach": "桃子", "桃子": "桃子", "桃": "桃子",
    "mango": "芒果", "芒果": "芒果",
    "pineapple": "菠萝", "菠萝": "菠萝", "凤梨": "菠萝",
    "cherry": "樱桃", "樱桃": "樱桃", "车厘子": "樱桃",
    "blueberry": "蓝莓", "蓝莓": "蓝莓",
    "lychee": "荔枝", "litchi": "荔枝", "荔枝": "荔枝", "桂味": "荔枝",
    "lemon": "柠檬", "柠檬": "柠檬",

    # ===== 脂肪/坚果类 =====
    "peanut": "花生", "花生": "花生", "花生米": "花生",
    "walnut": "核桃", "核桃": "核桃", "胡桃": "核桃",
    "almond": "杏仁", "杏仁": "杏仁", "扁桃仁": "杏仁",
    "cooking oil": "食用油", "oil": "食用油", "食用油": "食用油", "烹调油": "食用油",
    "olive oil": "橄榄油", "橄榄油": "橄榄油",
    "avocado": "牛油果", "牛油果": "牛油果", "鳄梨": "牛油果",

    # ===== 混合食物类 =====
    "pizza": "披萨", "披萨": "披萨", "比萨": "披萨",
    "hot dog": "热狗", "热狗": "热狗",
    "sandwich": "三明治", "三明治": "三明治",
    "donut": "甜甜圈", "doughnut": "甜甜圈", "甜甜圈": "甜甜圈", "甜圈": "甜甜圈",
    "cake": "蛋糕", "蛋糕": "蛋糕", "糕点": "蛋糕",
    "french fries": "薯条", "fries": "薯条", "薯条": "薯条", "炸薯条": "薯条",
    "dumpling": "饺子", "饺子": "饺子", "水饺": "饺子",
}


# ---------- 获取食物营养数据 ----------
def get_nutrition(food_name: str, grams: float = 100.0):
    """
    查询食物营养数据（每100g 缩放至实际克数）
    :param food_name: 食物名称（中文或英文）
    :param grams: 实际重量（克）
    :return: 营养数据字典，未找到返回 None
    """
    key = SYNONYMS.get(food_name.lower(), food_name.lower())
    if key not in FOOD_NUTRITION:
        return None
    per100 = FOOD_NUTRITION[key]
    factor = grams / 100.0
    return {
        "carbs_g": per100.get("carbs", 0) * factor,
        "protein_g": per100.get("protein", 0) * factor,
        "fat_g": per100.get("fat", 0) * factor,
        "calories": per100.get("calories", 0) * factor,
        "gi": per100.get("gi", 0),
        "calcium_mg": per100.get("calcium_mg", 0) * factor,
        "iron_mg": per100.get("iron_mg", 0) * factor,
        "zinc_mg": per100.get("zinc_mg", 0) * factor,
        "magnesium_mg": per100.get("magnesium_mg", 0) * factor,
        "chromium_ug": per100.get("chromium_ug", 0) * factor,
        "potassium_mg": per100.get("potassium_mg", 0) * factor,
        "fiber_g": per100.get("fiber_g", 0) * factor,
    }


def search_food(keyword: str):
    """
    在本地数据库中搜索匹配的食物名称
    :param keyword: 搜索关键词（支持中英文）
    :return: 匹配的食物键名列表
    """
    keyword_lower = keyword.lower().strip()
    results = []

    # 直接匹配键名
    for key in FOOD_NUTRITION:
        if keyword_lower in key:
            results.append(key)

    # 匹配同义词
    for syn, target in SYNONYMS.items():
        if keyword_lower in syn and target not in results:
            results.append(target)

    return list(set(results))
