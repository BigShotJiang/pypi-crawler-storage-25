"""
共享日志配置
提供统一的日志记录器，避免在多个模块中重复配置日志格式和输出。
"""

import logging
import sys

# 模块级缓存，存储根日志记录器实例
_logger = None


def get_logger(name: str = "smartplate") -> logging.Logger:
    """
    获取指定名称的子日志记录器。
    首次调用时初始化根日志记录器（输出到 stdout，格式为 "[级别] 名称: 消息"），
    后续调用返回基于根记录器的子记录器，方便区分不同模块的日志来源。

    :param name: 子日志记录器名称，默认为 "smartplate"
    :return: logging.Logger 实例
    """
    global _logger
    # 如果根日志记录器已存在，直接返回其子记录器
    if _logger is not None:
        return _logger.getChild(name)

    # 创建根日志记录器（名称为 "smartplate"）
    _logger = logging.getLogger("smartplate")
    _logger.setLevel(logging.INFO)          # 设置日志级别为 INFO

    # 避免重复添加处理器（例如多次调用 get_logger 导致多个 handler）
    if not _logger.handlers:
        # 创建输出到标准输出的处理器
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(logging.INFO)

        # 定义日志格式：[级别] 记录器名称: 消息内容
        formatter = logging.Formatter(
            "[%(levelname)s] %(name)s: %(message)s"
        )
        handler.setFormatter(formatter)
        _logger.addHandler(handler)

    # 返回基于根记录器的子记录器，便于模块化使用
    return _logger.getChild(name)
