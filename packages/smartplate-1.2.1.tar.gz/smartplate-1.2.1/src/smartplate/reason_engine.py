"""
reason_engine.py - 解释引擎
支持两种模式：
  1. 规则模式（默认）：基于营养素阈值的知识库匹配，离线可用
  2. LLM 模式（可选）：调用大模型生成自然语言饮食解释
"""

import base64
import os
from pathlib import Path
from typing import Any

from .llm_planner import call_llm_api

# ---------- 知识库 ----------
KNOWLEDGE = {
    "high_fiber": {
        "name": "膳食纤维",
        "function": "延缓糖分吸收，增加饱腹感，有助于平稳血糖和控制体重",
        "target": ["diabetes", "fitness"]
    },
    "high_protein": {
        "name": "蛋白质",
        "function": "促进肌肉合成，增加饱腹感，帮助控制体重，维持肌肉量",
        "target": ["fitness"]
    },
    "low_gi": {
        "name": "低升糖指数",
        "function": "碳水化合物释放缓慢，避免餐后血糖急剧波动，适合控糖人群",
        "target": ["diabetes"]
    },
    "chromium": {
        "name": "铬",
        "function": "参与葡萄糖耐量因子合成，辅助增强胰岛素作用，改善糖代谢",
        "target": ["diabetes"]
    },
    "magnesium": {
        "name": "镁",
        "function": "改善胰岛素抵抗，辅助降血压，有助于心血管健康",
        "target": ["both"]
    },
    "zinc": {
        "name": "锌",
        "function": "保护胰岛细胞功能，稳定胰岛素结构，促进伤口愈合",
        "target": ["diabetes"]
    },
    "calcium": {
        "name": "钙",
        "function": "有助于骨骼健康，维持神经肌肉功能",
        "target": ["fitness"]
    },
    "potassium": {
        "name": "钾",
        "function": "帮助维持正常血压，减少肌肉痉挛",
        "target": ["fitness"]
    },
    "low_fat": {
        "name": "低脂肪",
        "function": "减少热量摄入，有利于体重管理",
        "target": ["fitness"]
    }
}


# ---------- 规则引擎（保留）----------
def evaluate_food(food_name: str, nutrition_data: dict[str, Any]) -> dict[str, list[str]]:
    """评估单个食物对控糖和健身人群的益处"""
    reasons: dict[str, list[str]] = {"diabetes": [], "fitness": [], "both": []}

    fiber = nutrition_data.get("fiber_g", 0)
    protein = nutrition_data.get("protein_g", 0)
    gi = nutrition_data.get("gi", 100)
    chromium = nutrition_data.get("chromium_ug", 0)
    magnesium = nutrition_data.get("magnesium_mg", 0)
    zinc = nutrition_data.get("zinc_mg", 0)
    calcium = nutrition_data.get("calcium_mg", 0)
    potassium = nutrition_data.get("potassium_mg", 0)
    fat = nutrition_data.get("fat_g", 0)

    if fiber > 3:
        reasons["diabetes"].append("high_fiber")
        reasons["fitness"].append("high_fiber")
    if protein > 15:
        reasons["fitness"].append("high_protein")
    if gi < 55 and gi > 0:
        reasons["diabetes"].append("low_gi")
    if chromium > 5:
        reasons["diabetes"].append("chromium")
    if magnesium > 50:
        reasons["both"].append("magnesium")
    if zinc > 2:
        reasons["diabetes"].append("zinc")
    if calcium > 100:
        reasons["fitness"].append("calcium")
    if potassium > 300:
        reasons["fitness"].append("potassium")
    if fat < 5:
        reasons["fitness"].append("low_fat")

    for target in ["diabetes", "fitness"]:
        reasons[target].extend(reasons["both"])
        reasons[target] = list(set(reasons[target]))

    return reasons


def generate_explanation(food_name: str, nutrition_data: dict[str, Any], user_type: str) -> str:
    """生成规则模式的自然语言解释"""
    reasons = evaluate_food(food_name, nutrition_data)
    target_reasons = reasons.get(user_type, [])

    user_label = "控糖人群" if user_type == "diabetes" else "健身人群"
    if not target_reasons:
        return f"{food_name} 对{user_label}没有特别益处，建议适量食用。"

    lines = [f"✓ {food_name} 适合{user_label}，原因如下："]
    for reason_key in target_reasons:
        info = KNOWLEDGE.get(reason_key)
        if info:
            lines.append(f"  - 富含 **{info['name']}**：{info['function']}")
    return "\n".join(lines)


def generate_full_explanation(food_name: str, nutrition_data: dict[str, Any]) -> str:
    """生成完整的规则模式解释"""
    lines = [f"【{food_name} 营养解析】"]

    micro = []
    if nutrition_data.get("calcium_mg", 0) > 20:
        micro.append(f"钙 {nutrition_data['calcium_mg']:.1f}mg")
    if nutrition_data.get("iron_mg", 0) > 0.5:
        micro.append(f"铁 {nutrition_data['iron_mg']:.1f}mg")
    if nutrition_data.get("zinc_mg", 0) > 0.5:
        micro.append(f"锌 {nutrition_data['zinc_mg']:.1f}mg")
    if nutrition_data.get("magnesium_mg", 0) > 15:
        micro.append(f"镁 {nutrition_data['magnesium_mg']:.1f}mg")
    if nutrition_data.get("chromium_ug", 0) > 1:
        micro.append(f"铬 {nutrition_data['chromium_ug']:.1f}μg")
    if nutrition_data.get("potassium_mg", 0) > 100:
        micro.append(f"钾 {nutrition_data['potassium_mg']:.1f}mg")
    if micro:
        lines.append(f"  微量元素: {', '.join(micro)}")

    dia = generate_explanation(food_name, nutrition_data, "diabetes")
    fit = generate_explanation(food_name, nutrition_data, "fitness")
    lines.append(f"\n{dia}\n")
    lines.append(f"{fit}")
    return "\n".join(lines)


# ---------- LLM 模式 ----------
def _llm_enabled() -> bool:
    """检查 LLM 是否可用"""
    return bool(os.environ.get("LLM_API_KEY", ""))


def _llm_config_kwargs() -> dict[str, Any]:
    """获取 LLM 配置参数"""
    return {
        "api_url": os.environ.get("LLM_API_URL", ""),
        "api_key": os.environ.get("LLM_API_KEY", ""),
        "model": os.environ.get("LLM_MODEL", "gpt-3.5-turbo"),
    }


def _build_explanation_prompt(food_name: str, nutrition_data: dict[str, Any], user_type: str,
                              user_profile: dict[str, Any], portion_info: dict[str, Any] | None = None) -> str:
    """构建 LLM 解释 prompt"""
    goal_labels = {
        "diabetes": "血糖控制（糖尿病）",
        "weight_loss": "减脂控制体重",
        "muscle_gain": "增肌塑形",
        "general": "日常健康饮食",
    }
    goal_label = goal_labels.get(user_type, "日常健康饮食")

    profile_str = f"性别：{user_profile.get('gender', '未知')}，年龄：{user_profile.get('age', '未知')}岁"

    portion_str = ""
    if portion_info:
        portion_str = f"\n推荐份量：{portion_info.get('visual_display', '')}（约{portion_info.get('grams', 0)}g）"

    prompt = f"""你是一位注册营养师。请为以下食物生成简洁的营养解释。

【用户信息】
目标：{goal_label}
{profile_str}{portion_str}

【食物信息】
名称：{food_name}
营养数据（本餐实际摄入量）：
- 碳水化合物：{nutrition_data.get('carbs_g', 0):.1f}g
- 蛋白质：{nutrition_data.get('protein_g', 0):.1f}g
- 脂肪：{nutrition_data.get('fat_g', 0):.1f}g
- 热量：{nutrition_data.get('calories', 0):.0f}kcal
- GI值：{nutrition_data.get('gi', 0)}
- 膳食纤维：{nutrition_data.get('fiber_g', 0):.1f}g
- 钙：{nutrition_data.get('calcium_mg', 0):.1f}mg
- 铁：{nutrition_data.get('iron_mg', 0):.1f}mg
- 锌：{nutrition_data.get('zinc_mg', 0):.1f}mg
- 镁：{nutrition_data.get('magnesium_mg', 0):.1f}mg
- 钾：{nutrition_data.get('potassium_mg', 0):.1f}mg

请用2-3句话回答：
1. 这个食物对{goal_label}人群是否合适？为什么？
2. 有什么需要注意的？

请用中文回答，简洁专业。"""
    return prompt


def generate_llm_explanation(food_name: str, nutrition_data: dict[str, Any],
                             user_type: str = "general",
                             user_profile: dict[str, Any] | None = None,
                             portion_info: dict[str, Any] | None = None) -> str | None:
    """调用 LLM 生成营养解释"""
    if not _llm_enabled():
        return None

    if user_profile is None:
        user_profile = {}

    prompt = _build_explanation_prompt(food_name, nutrition_data, user_type,
                                        user_profile, portion_info)

    messages = [
        {"role": "system", "content": "你是一位专业的注册营养师，擅长用简洁的语言解释食物的营养价值。"},
        {"role": "user", "content": prompt},
    ]

    result = call_llm_api(messages=messages, max_tokens=300, temperature=0.5, **_llm_config_kwargs())
    if result:
        return f"【{food_name} AI营养解析】\n{result.strip()}"
    return None


# ---------- 统一入口 ----------
def explain_food(food_name: str, nutrition_data: dict[str, Any],
                 user_type: str = "general",
                 user_profile: dict[str, Any] | None = None,
                 use_llm: bool = True,
                 portion_info: dict[str, Any] | None = None) -> str:
    """
    生成食物营养解释（统一入口）
    :param food_name: 食物名称
    :param nutrition_data: 营养数据
    :param user_type: 用户类型
    :param user_profile: 用户画像
    :param use_llm: 是否尝试使用 LLM
    :param portion_info: 视觉份量推荐信息（可选）
    :return: 解释文本
    """
    # 构建份量提示行
    portion_prefix = ""
    if portion_info:
        visual = portion_info.get("visual_display", "")
        grams = portion_info.get("grams", 0)
        note = portion_info.get("note", "")
        goal_labels = {
            "diabetes": "控糖", "weight_loss": "减脂",
            "muscle_gain": "增肌", "general": "日常健康",
        }
        goal = goal_labels.get(user_type, "日常健康")
        portion_prefix = f"推荐份量：{visual}（约{grams}g）——基于您的{goal}目标"
        if note:
            portion_prefix += f"（{note}）"
        portion_prefix += "\n\n"

    if use_llm and _llm_enabled():
        llm_result = generate_llm_explanation(food_name, nutrition_data, user_type,
                                               user_profile, portion_info)
        if llm_result:
            return portion_prefix + llm_result

    # 回退到规则引擎
    return portion_prefix + generate_full_explanation(food_name, nutrition_data)


# ============================================================
# 多模态 LLM 模式（图片 + 数据 → 饮食建议）
# ============================================================

def _encode_image_base64(image_path: str) -> str | None:
    """将图片编码为 base64 data URL"""
    try:
        with open(image_path, "rb") as f:
            img_data = f.read()
        b64 = base64.b64encode(img_data).decode("utf-8")
        ext = Path(image_path).suffix.lower()
        mime_map = {".jpg": "jpeg", ".jpeg": "jpeg", ".png": "png", ".webp": "webp"}
        mime = mime_map.get(ext, "jpeg")
        return f"data:image/{mime};base64,{b64}"
    except Exception:
        return None


def _build_multimodal_prompt(image_path: str,
                              nutrition_summary: dict[str, Any],
                              user_type: str,
                              user_profile: dict[str, Any]) -> list[dict[str, Any]] | None:
    """构建多模态 prompt（含图片 + 结构化数据）"""
    goal_labels = {
        "diabetes": "血糖控制（糖尿病）",
        "weight_loss": "减脂控制体重",
        "muscle_gain": "增肌塑形",
        "general": "日常健康饮食",
    }
    goal_label = goal_labels.get(user_type, "日常健康饮食")

    # 总营养数据
    total = nutrition_summary.get("total_nutrition", {})
    foods = nutrition_summary.get("detected_foods", [])
    analysis = nutrition_summary.get("analysis", [])

    food_list = "\n".join([
        f"  - {f['name']}：{f.get('grams', '?')}g"
        f"（估算方式：{f.get('weight_method', '默认')}）"
        for f in foods
    ])

    analysis_text = ""
    for a in analysis:
        analysis_text += (
            f"  - {a.get('label', '')}：{a.get('value', 0)}{a.get('unit', '')} / "
            f"目标 {a.get('target', 0)}{a.get('unit', '')}（{a.get('status', '?')}）\n"
        )

    text_prompt = f"""你是一位专业的注册营养师。请根据这张食物图片和营养分析数据，给出饮食评估和建议。

【用户信息】
目标：{goal_label}
性别：{user_profile.get('gender', '未知')}
年龄：{user_profile.get('age', '未知')}岁
活动水平：{user_profile.get('activity', 'light')}

【检测到的食物】
{food_list}

【本餐总营养】
- 碳水化合物：{total.get('carbs_g', 0):.1f}g
- 蛋白质：{total.get('protein_g', 0):.1f}g
- 脂肪：{total.get('fat_g', 0):.1f}g
- 热量：{total.get('calories', 0):.0f}kcal
- 膳食纤维：{total.get('fiber_g', 0):.1f}g

【每项分析】
{analysis_text}

请按以下格式回答（用中文）：
1. 📋 总体评价：一句话评价这一餐
2. ✅ 优点：列出1-2个
3. ⚠️ 注意事项：列出1-2个
4. 💡 改进建议：1-2条具体可操作的建议"""

    b64_img = _encode_image_base64(image_path)
    if not b64_img:
        return None

    return [
        {
            "role": "system",
            "content": "你是一位经验丰富的注册营养师，擅长看图分析食物并给出专业的饮食建议。"
        },
        {
            "role": "user",
            "content": [
                {"type": "image_url", "image_url": {"url": b64_img}},
                {"type": "text", "text": text_prompt},
            ]
        }
    ]


def generate_multimodal_advice(image_path: str,
                                nutrition_summary: dict[str, Any],
                                user_type: str = "general",
                                user_profile: dict[str, Any] | None = None) -> str | None:
    """
    使用多模态 LLM（看图 + 数据）生成整餐饮食建议

    :param image_path: 食物图片路径
    :param nutrition_summary: analyze_meal 返回的结果字典
    :param user_type: 用户类型
    :param user_profile: 用户画像
    :return: 建议文本，失败返回 None
    """
    if not _llm_enabled():
        return None

    if user_profile is None:
        user_profile = {}

    messages = _build_multimodal_prompt(image_path, nutrition_summary, user_type, user_profile)
    if messages is None:
        return None

    result = call_llm_api(messages=messages, max_tokens=600, temperature=0.5, timeout=30, **_llm_config_kwargs())
    if result:
        return result.strip()
    return None


def generate_full_meal_advice(image_path: str,
                               nutrition_summary: dict[str, Any],
                               user_type: str = "general",
                               user_profile: dict[str, Any] | None = None) -> str:
    """
    生成整餐建议的统一入口

    优先级：多模态 LLM > 文本 LLM > 规则引擎建议文本

    :return: 建议文本
    """
    # 1. 尝试多模态 LLM（图片 + 数据）
    if _llm_enabled():
        mm_result = generate_multimodal_advice(
            image_path, nutrition_summary, user_type, user_profile
        )
        if mm_result:
            return mm_result

    # 2. 尝试纯文本 LLM（仅数据）
    if _llm_enabled():
        total: dict[str, Any] = nutrition_summary.get("total_nutrition", {})
        foods = nutrition_summary.get("detected_foods", [])
        profile = user_profile or {}
        food_list = ", ".join([f"{f['name']}({f.get('grams', '?')}g)" for f in foods])
        prompt = f"""你是注册营养师。请为以下一餐生成饮食建议。
用户目标：{user_type}，{profile.get('gender', '')}，{profile.get('age', '')}岁
食物：{food_list}
总营养：碳水 {total.get('carbs_g', 0):.1f}g，蛋白 {total.get('protein_g', 0):.1f}g，
脂肪 {total.get('fat_g', 0):.1f}g，热量 {total.get('calories', 0):.0f}kcal
请用3-4句话给出总体评价和改进建议（中文）。"""

        messages = [
            {"role": "system", "content": "你是注册营养师。"},
            {"role": "user", "content": prompt},
        ]
        result = call_llm_api(messages=messages, max_tokens=300, temperature=0.5, **_llm_config_kwargs())
        if result:
            return result.strip()

    # 3. 回退到规则引擎建议文本
    return str(nutrition_summary.get("advice", "请参考分析结果调整饮食。"))
