"""
visual_portion.py - 视觉份量推荐系统

基于 Precision Nutrition 手掌分量法的简化思路，用"拳头/掌心/拇指"等
视觉类比推荐每餐各类食物的食用份量，替代不可靠的图像重量估算。

核心概念：
  - 拳头 (fist) ≈ 200ml → 主食/蔬菜/水果
  - 掌心 (palm) ≈ 85g → 蛋白质
  - 拇指 (thumb) ≈ 15g → 脂肪/坚果
  - 碗 (bowl) ≈ 300ml → 粥/汤/奶制品

用户画像 → 每餐各类别推荐单位数 → 均分到具体食物 → 克重 → 营养计算
"""

from typing import Any

# ============================================================
# 食物分类映射（nutrition_db 中的每种食物 → 五大类之一）
# ============================================================
FOOD_CATEGORY_MAP = {
    # --- 主食类 (Grains/Staples) ---
    "米饭": "grains", "糙米饭": "grains", "面条": "grains",
    "馒头": "grains", "燕麦": "grains", "玉米": "grains",
    "红薯": "grains", "白面包": "grains", "全麦面包": "grains",
    "粥": "grains", "土豆": "grains",

    # --- 蛋白质类 (Protein: meat, seafood, soy, 鸡蛋s, dairy) ---
    "鸡胸肉": "protein", "牛肉": "protein", "瘦牛肉": "protein",
    "猪肉": "protein", "瘦猪肉": "protein", "羊肉": "protein",
    "鸭肉": "protein", "鱼肉": "protein", "三文鱼": "protein",
    "虾仁": "protein", "嫩豆腐": "protein", "老豆腐": "protein",
    "毛豆": "protein", "鸡蛋": "protein", "蛋白": "protein",
    "全脂牛奶": "protein", "脱脂牛奶": "protein", "酸奶": "protein",
    "奶酪": "protein",

    # --- 蔬菜类 (Vegetables) ---
    "西兰花": "vegetables", "菠菜": "vegetables", "番茄": "vegetables",
    "黄瓜": "vegetables", "卷心菜": "vegetables", "胡萝卜": "vegetables",
    "芹菜": "vegetables", "生菜": "vegetables", "甜椒": "vegetables",
    "茄子": "vegetables", "蘑菇": "vegetables", "四季豆": "vegetables",
    "洋葱": "vegetables", "大蒜": "vegetables", "姜": "vegetables",
    "南瓜": "vegetables", "莲藕": "vegetables",
    "竹笋": "vegetables", "海带": "vegetables",
    "豆芽": "vegetables",

    # --- 水果类 (Fruits) ---
    "苹果": "fruits", "香蕉": "fruits", "橙子": "fruits",
    "葡萄": "fruits", "西瓜": "fruits", "猕猴桃": "fruits",
    "草莓": "fruits", "梨": "fruits",
    "桃子": "fruits", "芒果": "fruits", "菠萝": "fruits",
    "樱桃": "fruits", "蓝莓": "fruits", "荔枝": "fruits",
    "柠檬": "fruits",

    # --- 脂肪/坚果类 (Fats/Nuts) ---
    "花生": "fats", "核桃": "fats", "杏仁": "fats",
    "食用油": "fats", "橄榄油": "fats",
    "牛油果": "fats",

    # --- 混合食物 (Mixed/Processed) ---
    "披萨": "mixed", "热狗": "mixed", "三明治": "mixed",
    "甜甜圈": "mixed", "蛋糕": "mixed", "薯条": "mixed",
    "饺子": "mixed", "豆浆": "protein",
}

# ============================================================
# 视觉单位定义
# ============================================================
VISUAL_UNITS = {
    "fist":   {"zh": "拳头", "desc": "一个拳头大小，约200ml体积"},
    "palm":   {"zh": "掌心", "desc": "一个手掌心（不含手指），厚约1cm"},
    "thumb":  {"zh": "拇指", "desc": "一个拇指大小"},
    "cupped": {"zh": "一捧", "desc": "双手捧起的量"},
    "bowl":   {"zh": "一碗", "desc": "标准中式饭碗（直径约11cm），约300ml"},
}

# ============================================================
# 每类食物每单位的克重（类别默认值）
# ============================================================
CATEGORY_GRAM_PER_UNIT: dict[str, dict[str, int]] = {
    "grains":     {"fist": 150, "bowl": 300},
    "protein":    {"palm": 85},
    "vegetables": {"fist": 100},
    "fruits":     {"fist": 150},
    "fats":       {"thumb": 15, "cupped": 30},
    "mixed":      {"palm": 100},
}

# 特殊食物覆盖（类别默认值偏差较大时使用）
FOOD_GRAM_OVERRIDE = {
    # 蓬松蔬菜每拳更轻
    "西兰花":       {"fist": 80},
    "菠菜":        {"fist": 80},
    "生菜":        {"fist": 50},
    "卷心菜":        {"fist": 80},
    "蘑菇":       {"fist": 60},
    "豆芽":   {"fist": 70},
    "海带":        {"fist": 30},
    # 淀粉类蔬菜每拳更重
    "土豆":         {"fist": 150},
    "红薯":   {"fist": 150},
    "莲藕":     {"fist": 130},
    # 面包比米饭轻
    "白面包":          {"fist": 80},
    "全麦面包": {"fist": 80},
    "馒头":    {"fist": 100},
    "燕麦":        {"fist": 80},
    # 蛋白质
    "鸡蛋":            {"palm": 50},
    "奶酪":         {"palm": 30},
    "嫩豆腐":           {"palm": 120},
    "老豆腐":      {"palm": 120},
    "鱼肉":           {"palm": 100},
    # 液体用碗
    "全脂牛奶":           {"bowl": 250},
    "脱脂牛奶":      {"bowl": 250},
    "豆浆":       {"bowl": 250},
    "酸奶":         {"bowl": 200},
    "粥":         {"bowl": 300},
    # 水果
    "香蕉":         {"fist": 120},
    "西瓜":     {"fist": 300},
    "葡萄":          {"fist": 150},
    "樱桃":         {"fist": 150},
    "蓝莓":      {"fist": 150},
    "草莓":     {"fist": 150},
    # 坚果
    "花生":         {"thumb": 15},
    "核桃":         {"thumb": 15},
    "杏仁":         {"thumb": 15},
    "牛油果":        {"thumb": 30},
}

# 类别中文名
CATEGORY_ZH = {
    "grains":     "主食",
    "protein":    "蛋白质",
    "vegetables": "蔬菜",
    "fruits":     "水果",
    "fats":       "脂肪",
    "mixed":      "混合食物",
}

# ============================================================
# 每用户画像的每餐份量推荐（单位数）
# ============================================================
PROFILE_RECOMMENDATIONS: dict[str, dict[str, Any]] = {
    "general": {
        "vegetables": {"fist": 2,   "desc": "两份蔬菜，提供纤维和微量营养素"},
        "protein":    {"palm": 1,   "desc": "一份蛋白质，维持肌肉和饱腹感"},
        "grains":     {"fist": 2,   "desc": "两份主食，提供能量"},
        "fats":       {"thumb": 1,  "desc": "一份健康脂肪"},
        "fruits":     {"fist": 1,   "desc": "一份水果"},
        "mixed":      {"palm": 1,   "desc": "适量食用"},
    },
    "diabetes": {
        "vegetables": {"fist": 2,   "desc": "两份蔬菜（优先绿叶蔬菜），纤维延缓糖分吸收"},
        "protein":    {"palm": 1,   "desc": "一份蛋白质，延缓胃排空，平稳血糖"},
        "grains":     {"fist": 1,   "desc": "一份主食（优先低GI主食）"},
        "fats":       {"thumb": 0.5,"desc": "半份脂肪，避免高脂影响胰岛素敏感性"},
        "fruits":     {"fist": 1,   "desc": "一份低GI水果（苹果/橙子/草莓等）"},
        "mixed":      {"palm": 0.5, "desc": "控糖期间建议减少加工食品"},
    },
    "weight_loss": {
        "vegetables": {"fist": 2,   "desc": "两份蔬菜，高纤维低热量增加饱腹感"},
        "protein":    {"palm": 2,   "desc": "两份蛋白质（优先瘦肉/鱼虾/鸡胸肉），防止肌肉流失"},
        "grains":     {"fist": 1,   "desc": "一份主食，控制碳水总摄入"},
        "fats":       {"thumb": 0.5,"desc": "半份脂肪，控制热量"},
        "fruits":     {"fist": 1,   "desc": "一份水果（优选低糖水果）"},
        "mixed":      {"palm": 0.5, "desc": "减脂期间建议减少加工食品"},
    },
    "muscle_gain": {
        "vegetables": {"fist": 2,   "desc": "两份蔬菜，保证微量营养素"},
        "protein":    {"palm": 2,   "desc": "两份蛋白质，支持肌肉合成"},
        "grains":     {"fist": 3,   "desc": "三份主食，提供训练能量和肌糖原恢复"},
        "fats":       {"thumb": 2,  "desc": "两份健康脂肪，支持激素合成"},
        "fruits":     {"fist": 1.5, "desc": "1-2份水果，补充维生素和碳水"},
        "mixed":      {"palm": 1,   "desc": "适量食用"},
    },
}

# ============================================================
# 核心函数
# ============================================================

def classify_food(food_name: str) -> str:
    """食物名 → 分类，未找到返回 'mixed'"""
    return FOOD_CATEGORY_MAP.get(food_name, "mixed")


def get_gram_equivalent(food_name: str, unit: str) -> float:
    """食物 + 视觉单位 → 一份的克重"""
    cat = classify_food(food_name)
    if food_name in FOOD_GRAM_OVERRIDE and unit in FOOD_GRAM_OVERRIDE[food_name]:
        return FOOD_GRAM_OVERRIDE[food_name][unit]
    cat_defaults = CATEGORY_GRAM_PER_UNIT.get(cat, {})
    return cat_defaults.get(unit, 100)


def get_default_unit(food_name: str) -> str:
    """获取该食物分类对应的默认视觉单位"""
    cat = classify_food(food_name)
    cat_units = CATEGORY_GRAM_PER_UNIT.get(cat, {})
    if cat_units:
        return list(cat_units.keys())[0]
    return "fist"


def recommend_portion(food_name: str, user_type: str = "general",
                      unit_count: float | None = None) -> dict[str, Any]:
    """
    单食物份量推荐

    :param food_name: 食物名称（数据库键名）
    :param user_type: general / diabetes / weight_loss / muscle_gain
    :param unit_count: 手动指定单位数（None=使用画像默认值）
    :return: 推荐结果字典
    """
    cat = classify_food(food_name)
    profile: dict[str, Any] = PROFILE_RECOMMENDATIONS.get(user_type, PROFILE_RECOMMENDATIONS["general"])
    cat_rule: dict[str, Any] = profile.get(cat, {"palm": 1, "desc": "适量食用"})

    unit = get_default_unit(food_name)
    for u in cat_rule:
        if u in ("desc", "_meta"):
            continue
        unit = u
        break

    if unit_count is None:
        unit_count = float(cat_rule.get(unit, 1.0))

    grams = round(get_gram_equivalent(food_name, unit) * unit_count)

    unit_info: dict[str, str] = VISUAL_UNITS.get(unit, {})
    unit_zh: str = unit_info.get("zh", unit)
    if unit_count == 0.5:
        display = f"半{unit_zh}"
    elif unit_count == int(unit_count):
        display = f"{int(unit_count)}{unit_zh}"
    else:
        display = f"{unit_count}{unit_zh}"

    return {
        "name": food_name,
        "category": cat,
        "category_zh": CATEGORY_ZH.get(cat, cat),
        "visual_quantity": unit_count,
        "visual_unit": unit,
        "visual_unit_zh": unit_zh,
        "visual_display": display,
        "grams": grams,
        "grams_display": f"约{grams}g",
        "note": cat_rule.get("desc", ""),
    }


def recommend_all_portions(food_names: list[str],
                            user_type: str = "general") -> tuple[dict[str, Any], dict[str, Any]]:
    """
    批量份量推荐（主入口）

    逻辑：
      1. 将检测到的食物按类别分组
      2. 每类按照用户画像规则确定该类别总推荐单位数
      3. 同类别有多样食物时均分

    :param food_names: 食物名称列表
    :param user_type: 用户类型
    :return: (food_recs, summary)
             food_recs = {food_name: portion_dict, ...}
             summary   = 分类汇总信息
    """
    profile: dict[str, Any] = PROFILE_RECOMMENDATIONS.get(user_type, PROFILE_RECOMMENDATIONS["general"])

    # 按类别分组
    by_category: dict[str, list[str]] = {}
    for name in food_names:
        cat = classify_food(name)
        by_category.setdefault(cat, []).append(name)

    # 为每个食物计算推荐份量
    food_recs: dict[str, Any] = {}
    per_category_summary: dict[str, Any] = {}

    for cat, foods in by_category.items():
        cat_rule: dict[str, Any] = profile.get(cat, {"palm": 1, "desc": "适量食用"})
        unit = get_default_unit(foods[0])
        for u in cat_rule:
            if u in ("desc", "_meta"):
                continue
            unit = u
            break
        total_units: float = cat_rule.get(unit, 1.0)
        per_food_units = round(total_units / len(foods), 2)

        total_grams = 0
        cat_foods = []
        for food_name in foods:
            rec = recommend_portion(food_name, user_type, unit_count=per_food_units)
            food_recs[food_name] = rec
            total_grams += rec["grams"]
            cat_foods.append({
                "name": food_name,
                "portion": rec["visual_display"],
                "grams": rec["grams"],
            })

        unit_info: dict[str, str] = VISUAL_UNITS.get(unit, {})
        unit_zh: str = unit_info.get("zh", unit)
        if total_units == int(total_units):
            total_display = f"{int(total_units)}{unit_zh}"
        else:
            total_display = f"{total_units}{unit_zh}"

        per_category_summary[cat] = {
            "category_zh": CATEGORY_ZH.get(cat, cat),
            "total_unit_display": total_display,
            "unit_zh": unit_zh,
            "total_grams": total_grams,
            "foods": cat_foods,
            "note": cat_rule.get("desc", ""),
        }

    total_grams = sum(s["total_grams"] for s in per_category_summary.values())

    # 生成总体文本
    parts = []
    for cat in ["grains", "protein", "vegetables", "fats", "fruits", "mixed"]:
        if cat in per_category_summary:
            s = per_category_summary[cat]
            parts.append(f"{s['category_zh']} {s['total_unit_display']}")

    summary = {
        "method": "visual_portion",
        "total_recommended_grams": total_grams,
        "per_category": per_category_summary,
        "overview_text": " | ".join(parts),
        "note": f"基于「{PROFILE_RECOMMENDATIONS.get(user_type, {}).get('_label', user_type)}」目标的每餐推荐份量",
    }

    return food_recs, summary


def build_portion_advice(food_name: str, rec: dict[str, Any], nutrition: dict[str, Any], user_type: str) -> str:
    """
    生成单食物的份量建议文本（用于 explain_food 前追加）

    :param food_name: 食物名
    :param rec: recommend_portion 的返回
    :param nutrition: 营养数据
    :param user_type: 用户类型
    :return: 建议文本
    """
    lines = [f"【推荐份量】{rec['visual_display']}（{rec['grams_display']}）"]

    # 简要营养
    carbs = nutrition.get("carbs_g", 0)
    protein = nutrition.get("protein_g", 0)
    calories = nutrition.get("calories", 0)
    gi = nutrition.get("gi", 0)
    lines.append(f"  碳水 {carbs:.1f}g | 蛋白 {protein:.1f}g | 热量 {calories:.0f}kcal")

    # 针对性提示
    if user_type == "diabetes" and gi > 0:
        if gi <= 40:
            lines.append(f"  [控糖] GI={gi}，属于低GI食物，此份量对血糖影响较小")
        elif gi <= 55:
            lines.append(f"  [控糖] GI={gi}，属于中GI食物，控制在{rec['visual_display']}以内有助于平稳血糖")
        else:
            lines.append(f"  [控糖提醒] GI={gi}偏高，建议严格控制份量，搭配蛋白质和蔬菜食用")
    elif user_type == "weight_loss" and calories > 0:
        if calories / (rec["grams"] or 1) * 100 < 50:
            lines.append("  [减脂] 此食物热量密度较低，适合减脂期食用")
    elif user_type == "muscle_gain" and protein > 0:
        lines.append(f"  [增肌] 此份量提供 {protein:.1f}g 蛋白质")

    return "\n".join(lines)
