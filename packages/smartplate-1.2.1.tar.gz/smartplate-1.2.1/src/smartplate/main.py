"""
主程序：SmartPlate 智能配餐助手入口
功能：
- 解析命令行参数，支持多种用户类型（日常、控糖、减脂、增肌）和个性化信息（性别、年龄、活动量）
- 提供四种运行模式：cli（交互式菜单）、recipe（快速生成食谱）、log（记录摄入食物）、experiment（实验对比）
- 支持规则引擎与大模型（LLM）双模式，可分别使用或组合
- 支持纯 LLM 基线模式（无知识注入），用于课程对比实验
"""

import argparse
from pathlib import Path

from dotenv import load_dotenv

from .cli import MEAL_ZH, print_header
from .cli import main as cli_main
from .meal_planner import MealPlanner

# 自动加载项目根目录 .env 文件（通常存放 API_KEY 等敏感配置）
_env_path = Path(__file__).resolve().parent.parent.parent / ".env"
if _env_path.exists():
    load_dotenv(_env_path)


def main():
    """主入口函数，解析命令行参数并根据模式分发到不同处理流程。"""

    # ---------- 1. 定义命令行参数 ----------
    parser = argparse.ArgumentParser(description="SmartPlate 智能配餐助手")

    # 用户类型：日常/控糖/减脂/增肌（fitness 作为 muscle_gain 别名）
    parser.add_argument(
        "--user", choices=["general", "diabetes", "weight_loss", "muscle_gain", "fitness"],
        default="general",
        help="用户类型：general=日常, diabetes=控糖, weight_loss=减脂, muscle_gain/fitness=增肌")

    # 个体基础信息
    parser.add_argument("--gender", choices=["male", "female"], default="male", help="性别")
    parser.add_argument("--age", type=int, default=30, help="年龄")
    parser.add_argument("--activity", choices=["sedentary", "light", "moderate", "active"],
                        default="light", help="活动水平")

    # 运行模式选择
    parser.add_argument("--mode", choices=["cli", "recipe", "log", "experiment"], default="cli",
                        help="配餐模式：cli=交互式菜单, recipe=快速生成食谱, log=记录食物, experiment=对比实验")

    # log 模式专用参数：食物列表（逗号分隔）
    parser.add_argument("--foods", type=str, default=None,
                        help="食物列表（--mode log 时使用，逗号分隔）")

    # LLM 开关：--use-llm 启用，--no-llm 禁用；默认未指定时由内部决定
    parser.add_argument("--use-llm", dest="use_llm", action="store_true", default=None,
                        help="启用 LLM 模式")
    parser.add_argument("--no-llm", dest="use_llm", action="store_false", default=None,
                        help="禁用 LLM 模式，仅使用规则引擎")

    # 实验对比模式：纯 LLM 基线（无知识注入）
    parser.add_argument("--llm-baseline", action="store_true", default=False,
                        help="使用纯 LLM 基线（无知识注入），用于实验对比")

    args = parser.parse_args()

    # ---------- 2. 参数后处理 ----------
    # 兼容 fitness 参数，将其映射为 muscle_gain
    if args.user == "fitness":
        args.user = "muscle_gain"

    # 决定是否使用 LLM：如果用户未显式指定，则默认启用 LLM
    use_llm = args.use_llm if args.use_llm is not None else True  # 默认 True
    if args.llm_baseline:
        use_llm = True  # 基线模式会强制使用 LLM 但内部调用 generate_daily_plan_baseline 方法，无知识注入

    # ---------- 3. 初始化 MealPlanner（核心配餐器） ----------
    planner = MealPlanner(
        user_type=args.user,
        gender=args.gender,
        age=args.age,
        activity=args.activity,
        use_llm=use_llm,
        # llm_config 可在此传入，目前使用默认配置
    )

    # ---------- 4. 根据运行模式执行不同逻辑 ----------
    if args.mode == "experiment":
        # 实验模式：调用对比实验框架，对四种画像进行多次试验，输出 CSV 及统计摘要
        from .experiment import run_all_profiles
        num_trials = 5  # 每种方法在每个画像上运行 5 次，可调整
        print(f"Running experiment: 4 profiles x 3 methods x {num_trials} trials...")
        run_all_profiles(num_trials=num_trials)

    elif args.mode == "recipe":
        # 快速生成食谱模式：直接输出当日三餐+加餐计划
        print_header(planner)  # 打印用户画像摘要

        if args.llm_baseline:
            # 基线模式：纯 LLM（无知识注入）
            plan = planner.generate_daily_plan_baseline()
            if plan is None:
                print("LLM not available, falling back to rule engine.")
                plan = planner.generate_daily_plan_rule()
        else:
            # 正常模式：优先使用 LLM+知识注入，若不可用则回退规则引擎
            plan = planner.generate_daily_plan()

        method = plan.get("generation_method", "rule_engine")
        print(f"  [生成方式: {method}]")

        # 按餐次输出食谱详情
        for meal_key in ["breakfast", "lunch", "dinner", "snack"]:
            items = plan["meals"].get(meal_key, [])
            if not items:
                continue
            zh = MEAL_ZH.get(meal_key, meal_key)
            print(f"\n【{zh}】")
            for item in items:
                print(f"  {item['name']:<12s} {item['portion']:<8s} "
                      f"约{item['grams']}g | {item['calories']}kcal")

        # 输出全天营养目标
        target = plan["daily_target"]
        print(f"\n全天目标：{target['calories']}kcal | "
              f"碳水{target['carbs_g']}g | 蛋白{target['protein_g']}g")

    elif args.mode == "log":
        # 食物记录模式：分析用户输入的食物，计算其营养合计
        foods = []
        if args.foods:
            # 支持中英文逗号分隔
            foods = [f.strip() for f in args.foods.replace("，", ",").split(",") if f.strip()]
        if not foods:
            # 未通过命令行提供则交互输入
            foods_input = input("请输入食物名称（逗号分隔）：")
            foods = [f.strip() for f in foods_input.replace("，", ",").split(",") if f.strip()]

        if foods:
            print_header(planner)
            result = planner.log_food(foods)  # 返回识别后的食物条目及营养总计
            for item in result["items"]:
                print(f"  {item['raw_name']:<12s} {item['portion']:<8s} {item['grams']}g")
            mt = result["meal_totals"]
            print(f"\n本次摄入：碳水{mt['carbs_g']}g | 蛋白{mt['protein_g']}g | "
                  f"脂肪{mt['fat_g']}g | 热量{mt['calories']}kcal")
    else:
        # 默认模式：启动交互式命令行菜单（cli）
        cli_main()


if __name__ == "__main__":
    # 程序入口，捕获中断和异常，优雅退出
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n感谢使用 SmartPlate 智能配餐助手，祝您健康！")
    except Exception as e:
        print(f"\n发生错误：{e}")
        import traceback
        traceback.print_exc()
