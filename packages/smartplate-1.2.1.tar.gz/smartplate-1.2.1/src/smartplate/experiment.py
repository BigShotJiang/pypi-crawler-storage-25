"""
experiment.py - 对比实验框架

论文第 4 章 "实验评估" 的核心模块：对比三种方法的性能差异。
  1. Rule Engine    — 现有规则引擎（兜底方案）
  2. LLM Baseline   — 纯 LLM，最小化 prompt，无知识注入（对照）
  3. LLM + Knowledge — 本文方法：结构化知识注入 + 校验层（实验组）

输出可直接用于论文的对比表格和 CSV 数据。
"""

import csv
import time
from dataclasses import asdict, dataclass
from typing import Any

from .advice_engine import GOAL_ADJUSTMENTS
from .meal_planner import GOAL_LABELS, MealPlanner
from .nutrition_db import FOOD_NUTRITION
from .visual_portion import FOOD_CATEGORY_MAP


@dataclass
class TrialResult:
    """单次实验结果的完整数据结构，用于后续统计分析。"""
    trial_id: int = 0                 # 试验序号
    user_type: str = ""               # 用户画像：general/diabetes/weight_loss/muscle_gain
    method: str = ""                  # 方法标识：rule_engine / llm_baseline / llm_knowledge
    success: bool = False             # 是否成功生成有效计划
    generation_time_ms: float = 0.0   # 生成耗时（毫秒）

    # 营养偏离指标（相对每日推荐摄入量 RDA 的偏差百分比）
    calorie_deviation_pct: float = 0.0
    carb_deviation_pct: float = 0.0
    protein_deviation_pct: float = 0.0
    fat_deviation_pct: float = 0.0
    fiber_deviation_pct: float = 0.0

    # 安全指标
    food_hallucination_count: int = 0     # 幻觉食物数量（数据库中不存在的食物）
    food_hallucination_rate: float = 0.0  # 幻觉食物比例
    gi_violation_count: int = 0           # 升糖指数违规次数（仅糖尿病）
    profile_violation_count: int = 0      # 画像违规次数（如正餐蛋白质不足）

    # 质量指标
    total_calories: float = 0.0           # 总热量（千卡）
    food_variety_count: int = 0           # 涉及的不同食物种类数

    # LLM 专有指标
    retry_count: int = 0                  # 重试次数（LLM 请求失败后重试）
    validation_passed: bool = False       # 是否通过后校验层


def _count_food_hallucinations(plan: dict[str, Any]) -> tuple[int, float, list[str]]:
    """统计计划中不存在的食物（不在 FOOD_NUTRITION 中）"""
    from .nutrition_db import SYNONYMS

    total = 0
    hallucinations = 0
    hallucinated = []

    for meal_name in ["breakfast", "lunch", "dinner", "snack"]:
        for item in plan.get("meals", {}).get(meal_name, []):
            total += 1
            food_name = item.get("name", item.get("food_name", ""))
            if food_name not in FOOD_NUTRITION:
                # 尝试用同义词映射解析
                resolved = SYNONYMS.get(food_name.lower().strip(), "")
                if resolved not in FOOD_NUTRITION:
                    hallucinations += 1
                    hallucinated.append(food_name)

    rate = hallucinations / max(total, 1)
    return hallucinations, rate, hallucinated


def _count_gi_violations(plan: dict[str, Any], user_type: str) -> int:
    """统计 GI 违规数（仅对糖尿病用户）"""
    if user_type != "diabetes":
        return 0

    gi_limit = GOAL_ADJUSTMENTS.get("diabetes", {}).get("gi_limit", 55)
    violations = 0

    for meal_name in ["breakfast", "lunch", "dinner", "snack"]:
        for item in plan.get("meals", {}).get(meal_name, []):
            food_name = item.get("name", item.get("food_name", ""))
            food_data = FOOD_NUTRITION.get(food_name, {})
            gi = food_data.get("gi", 0)
            cat = FOOD_CATEGORY_MAP.get(food_name, "mixed")
            if cat in ("grains", "fruits") and 0 < gi > gi_limit:
                violations += 1

    return violations


def _count_profile_violations(plan: dict[str, Any], daily_rda: dict[str, Any], user_type: str) -> int:
    """
    统计画像违规数（例如：午餐/晚餐蛋白质是否达到目标下限）
    """
    from .nutrition_db import get_nutrition
    goal_config = GOAL_ADJUSTMENTS.get(user_type, {})
    violations = 0

    for meal_name in ["lunch", "dinner"]:
        meal_protein = 0.0
        for item in plan.get("meals", {}).get(meal_name, []):
            food_name = item.get("name", item.get("food_name", ""))
            grams = item.get("grams", 100)
            nut = get_nutrition(food_name, grams)
            if nut:
                meal_protein += nut.get("protein_g", 0)

        protein_min = goal_config.get("protein_min_per_meal", 0)
        if protein_min > 0 and meal_protein < protein_min:
            violations += 1

    return violations


def _evaluate_plan(plan: dict[str, Any] | None, daily_rda: dict[str, Any], user_type: str,
                   method: str, trial_id: int, elapsed_ms: float) -> TrialResult:
    """
    对生成的食谱计划进行全面评估，填充 TrialResult 的各项指标。
    """
    from .nutrition_db import get_nutrition

    result = TrialResult(
        trial_id=trial_id,
        user_type=user_type,
        method=method,
        success=plan is not None,
        generation_time_ms=round(elapsed_ms),
    )

    if plan is None:
        return result

    # 计算每日营养素合计
    totals = {"calories": 0.0, "carbs_g": 0.0, "protein_g": 0.0, "fat_g": 0.0, "fiber_g": 0.0}
    food_names = set()

    for meal_name in ["breakfast", "lunch", "dinner", "snack"]:
        for item in plan.get("meals", {}).get(meal_name, []):
            food_name = item.get("name", item.get("food_name", ""))
            grams = item.get("grams", 100)
            nut = get_nutrition(food_name, grams)
            if nut:
                for k in totals:
                    if k in nut:
                        totals[k] += nut[k]
                food_names.add(food_name)

    result.total_calories = round(totals["calories"])
    result.food_variety_count = len(food_names)

    # 计算营养偏差（相对于每日推荐摄入量 RDA）
    rda_map = {
        "calories": "daily_energy_kcal",
        "carbs_g": "daily_carbs_g",
        "protein_g": "daily_protein_g",
        "fat_g": "daily_fat_g",
        "fiber_g": "daily_fiber_g",
    }
    attr_map = {
        "calories": "calorie_deviation_pct",
        "carbs_g": "carb_deviation_pct",
        "protein_g": "protein_deviation_pct",
        "fat_g": "fat_deviation_pct",
        "fiber_g": "fiber_deviation_pct",
    }
    for key, rda_key in rda_map.items():
        target = daily_rda.get(rda_key, 1)
        if target <= 0:
            target = 1
        deviation = abs(totals.get(key, 0) - target) / target * 100
        setattr(result, attr_map[key], round(deviation, 1))

    # 安全指标
    result.food_hallucination_count, result.food_hallucination_rate, _ = \
        _count_food_hallucinations(plan)
    result.gi_violation_count = _count_gi_violations(plan, user_type)
    result.profile_violation_count = _count_profile_violations(plan, daily_rda, user_type)

    # LLM 专有信息
    result.validation_passed = plan.get("validation_passed", True)
    result.retry_count = plan.get("validation_details", {}).get("retry_count", 0)

    return result


def run_comparison(
    user_type: str = "general",
    num_trials: int = 10,
    llm_config: dict | None = None,
    output_csv: str | None = None,
) -> list[TrialResult]:
    """
    对指定画像运行三种方法的对比实验。

    :param user_type: 用户画像（general/diabetes/weight_loss/muscle_gain）
    :param num_trials: 每种方法的试验次数（例如 10 次）
    :param llm_config: LLM 配置字典，可包含 api_url, api_key, model, temperature
    :param output_csv: 可选 CSV 输出路径
    :return: 包含所有试验结果的 TrialResult 列表
    """
    if llm_config is None:
        llm_config = {}

    base_config: dict[str, Any] = {"user_type": user_type, "gender": "male", "age": 30, "activity": "light"}
    results = []
    trial_start = 0

    # 定义三种方法的参数组合：(方法名, use_llm, use_baseline)
    method_configs = [
        ("rule_engine", False, False),
        ("llm_baseline", True, True),
        ("llm_knowledge", True, False),
    ]

    for trial_id in range(num_trials):
        for method, use_llm, _use_baseline in method_configs:
            planner = MealPlanner(**base_config, use_llm=use_llm, llm_config=llm_config)

            t0 = time.time()
            plan: dict[str, Any] | None
            if method == "rule_engine":
                plan = planner.generate_daily_plan_rule()
            elif method == "llm_baseline":
                plan = planner.generate_daily_plan_baseline()
            else:  # llm_knowledge
                plan = planner.generate_daily_plan()
            elapsed = (time.time() - t0) * 1000

            result = _evaluate_plan(
                plan, planner.daily_rda, user_type, method,
                trial_start + trial_id, elapsed,
            )
            results.append(result)

    if output_csv:
        _write_csv(results, output_csv)

    return results


def run_all_profiles(
    num_trials: int = 10,
    llm_config: dict | None = None,
    output_dir: str = "results",
) -> list[TrialResult]:
    """
    对四种用户画像分别运行对比实验，并保存 CSV 结果及打印摘要。

    :param num_trials: 每种方法在每个画像上的试验次数
    :param llm_config: LLM 配置
    :param output_dir: 结果输出目录
    :return: 所有试验结果的列表
    """
    import os
    os.makedirs(output_dir, exist_ok=True)

    all_results = []
    profiles = ["general", "diabetes", "weight_loss", "muscle_gain"]

    for profile in profiles:
        print(f"\n{'=' * 60}")
        print(f"  Profile: {GOAL_LABELS.get(profile, profile)} ({profile})")
        print(f"{'=' * 60}")
        csv_path = f"{output_dir}/comparison_{profile}.csv"
        results = run_comparison(
            user_type=profile,
            num_trials=num_trials,
            llm_config=llm_config,
            output_csv=csv_path,
        )
        all_results.extend(results)

        # 打印当前画像的统计摘要
        _print_profile_summary(results, profile)

    # 打印全局聚合摘要
    _print_aggregate_summary(all_results)

    # 保存全部结果到单个 CSV
    all_csv = f"{output_dir}/comparison_all.csv"
    _write_csv(all_results, all_csv)
    print(f"\nAll results saved to: {all_csv}")

    return all_results


def _print_profile_summary(results: list[TrialResult], profile: str):
    """按方法聚合打印单个画像的摘要（表格形式）。"""
    print("\n  Method           | N  | Succ% | CalDev%  | ProtDev% | Halluc% | GI-Viol | Var | Time(ms)")
    print(f"  {'-' * 85}")

    methods = ["rule_engine", "llm_baseline", "llm_knowledge"]
    for method in methods:
        subset = [r for r in results if r.method == method]
        if not subset:
            continue
        n = len(subset)
        succ = sum(1 for r in subset if r.success) / n * 100
        cal_dev = _mean_std([r.calorie_deviation_pct for r in subset])
        prot_dev = _mean_std([r.protein_deviation_pct for r in subset])
        hall = _mean_std([r.food_hallucination_rate * 100 for r in subset])
        gi_viol = _mean([r.gi_violation_count for r in subset])
        variety = _mean([r.food_variety_count for r in subset])
        time_ms = _mean_std([r.generation_time_ms for r in subset])

        print(f"  {method:<16s}  | {n:>2} | {succ:>5.0f}% | {cal_dev:>8s} | {prot_dev:>8s} | {hall:>7s} | {gi_viol:>6.1f} | {variety:>3.0f} | {time_ms:>8s}")


def _print_aggregate_summary(all_results: list[TrialResult]):
    """打印跨画像的聚合摘要（平均值 ± 标准差）。"""
    print(f"\n{'=' * 60}")
    print("  AGGREGATE SUMMARY (All Profiles)")
    print(f"{'=' * 60}")

    methods = ["rule_engine", "llm_baseline", "llm_knowledge"]
    for method in methods:
        subset = [r for r in all_results if r.method == method and r.success]
        if not subset:
            print(f"\n  {method}: No successful runs")
            continue
        n = len(subset)
        print(f"\n  [{method}] n={n}")
        print(f"    Calorie Deviation:  {_mean_std([r.calorie_deviation_pct for r in subset])}%")
        print(f"    Protein Deviation:  {_mean_std([r.protein_deviation_pct for r in subset])}%")
        print(f"    Carb Deviation:     {_mean_std([r.carb_deviation_pct for r in subset])}%")
        print(f"    Fat Deviation:      {_mean_std([r.fat_deviation_pct for r in subset])}%")
        print(f"    Hallucination Rate: {_mean([r.food_hallucination_rate * 100 for r in subset]):.1f}%")
        print(f"    GI Violations/meal: {_mean([r.gi_violation_count for r in subset]):.1f}")
        print(f"    Food Variety:       {_mean([r.food_variety_count for r in subset]):.1f}")
        print(f"    Time (ms):          {_mean([r.generation_time_ms for r in subset]):.0f}")


def _mean(values: list[float]) -> float:
    """简单均值计算"""
    return sum(values) / max(len(values), 1)


def _mean_std(values: list[float]) -> str:
    """返回 "均值±标准差" 格式化字符串，样本数≤1时仅返回均值"""
    if len(values) <= 1:
        return f"{_mean(values):.1f}"
    mean = _mean(values)
    var = sum((v - mean) ** 2 for v in values) / (len(values) - 1)
    std = var ** 0.5
    return f"{mean:.1f}±{std:.1f}"


def _write_csv(results: list[TrialResult], path: str):
    """将 TrialResult 列表写入 CSV 文件"""
    if not results:
        return
    fieldnames = list(asdict(results[0]).keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in results:
            writer.writerow(asdict(r))
    print(f"  CSV saved: {path}")
