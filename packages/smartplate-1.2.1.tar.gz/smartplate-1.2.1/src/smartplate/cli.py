"""
cli.py - SmartPlate 智能配餐助手交互式命令行界面
"""

import os

from .meal_planner import GOAL_LABELS, MealPlanner
from .nutrition_db import FOOD_NUTRITION, SYNONYMS

MEAL_ZH = {"breakfast": "早餐", "lunch": "午餐", "dinner": "晚餐", "snack": "加餐"}


def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")


def print_header(planner: MealPlanner):
    print("=" * 50)
    print("  SmartPlate 智能配餐助手")
    print("=" * 50)
    profile = planner.user_profile
    print(f"  画像：{planner.goal_label} | {profile['gender']} | "
          f"{profile['age']}岁 | {profile['activity']}")
    rda = planner.daily_rda
    print(f"  每日推荐：{rda.get('daily_energy_kcal', '?')} kcal | "
          f"碳水 {rda.get('daily_carbs_g', '?')}g | "
          f"蛋白 {rda.get('daily_protein_g', '?')}g")
    if planner.daily_log:
        t = planner._totals
        print(f"  今日已摄入：{t['calories']:.0f} kcal | "
              f"碳水 {t['carbs_g']:.1f}g | 蛋白 {t['protein_g']:.1f}g")
    print("=" * 50)


def menu_setup(planner: MealPlanner):
    """设置健康目标"""
    print("\n--- 设置健康目标 ---")
    print("目标选择：")
    print("  1. 日常健康饮食")
    print("  2. 糖尿病/血糖控制")
    print("  3. 减脂/体重控制")
    print("  4. 增肌/力量训练")

    goal_map = {"1": "general", "2": "diabetes", "3": "weight_loss", "4": "muscle_gain"}
    goal_choice = input("请选择 [1-4]（回车保持当前）：").strip()
    if goal_choice in goal_map:
        planner.user_type = goal_map[goal_choice]
        planner.goal_label = GOAL_LABELS.get(planner.user_type, "日常健康")

    gender = input(f"性别 [male/female]（回车={planner.user_profile['gender']}）：").strip().lower()
    if gender in ("male", "female"):
        planner.user_profile["gender"] = gender

    age_str = input(f"年龄（回车={planner.user_profile['age']}）：").strip()
    if age_str.isdigit():
        planner.user_profile["age"] = int(age_str)

    print("活动水平：1=久坐  2=轻度  3=中度  4=活跃")
    act_map = {"1": "sedentary", "2": "light", "3": "moderate", "4": "active"}
    act_choice = input("请选择 [1-4]（回车保持当前）：").strip()
    if act_choice in act_map:
        planner.user_profile["activity"] = act_map[act_choice]

    # 重新计算每日目标
    from .advice_engine import get_user_rda
    planner.daily_rda = get_user_rda(
        str(planner.user_profile["gender"]),
        int(planner.user_profile["age"]),
        str(planner.user_profile["activity"]),
        planner.user_type,
    )
    planner.reset()
    print(f"\n✓ 设置完成，每日推荐 {planner.daily_rda.get('daily_energy_kcal', '?')} kcal")
    input("按回车继续...")


def menu_plan(planner: MealPlanner):
    """生成一日食谱"""
    print("\n⏳ 正在生成一日食谱...")
    plan = planner.generate_daily_plan()

    method = plan.get("generation_method", "rule_engine")
    method_labels = {
        "llm_knowledge": "LLM + 知识约束",
        "llm_baseline": "LLM 纯基线",
        "rule_engine": "规则引擎",
    }
    method_label = method_labels.get(method, method)
    print(f"\n{'=' * 50}")
    print(f"  {planner.goal_label} · 一日食谱推荐 [{method_label}]")
    print(f"{'=' * 50}")

    for meal_key in ["breakfast", "lunch", "dinner", "snack"]:
        items = plan["meals"].get(meal_key, [])
        if not items:
            continue
        zh = MEAL_ZH.get(meal_key, meal_key)
        print(f"\n【{zh}】")
        meal_cals = 0
        for item in items:
            print(f"  {item['name']:<12s} {item['portion']:<8s} "
                  f"约{item['grams']}g | {item['calories']}kcal "
                  f"| GI:{item.get('gi','-')}")
            meal_cals += item["calories"]
        print(f"  {'─' * 30}")
        print(f"  小计：约 {meal_cals} kcal")

    target = plan["daily_target"]
    print(f"\n{'=' * 50}")
    print(f"全天汇总（目标 {target['calories']} kcal）")
    print(f"  碳水 {target['carbs_g']}g | 蛋白 {target['protein_g']}g | "
          f"脂肪 {target['fat_g']}g | 纤维 {target['fiber_g']}g")
    if planner.user_type == "diabetes":
        print("  🩸 控糖提示：优先低GI主食和水果，每餐搭配蛋白质和蔬菜")

    input("\n按回车继续...")


def menu_log(planner: MealPlanner):
    """记录饮食"""
    print("\n--- 记录我已吃的食物 ---")
    print("（输入食物名称，多个用逗号分隔，如：米饭,鸡胸肉,西兰花）")
    print("（支持中文或英文名称）")
    print("（输入 0 返回主菜单）")

    raw = input("\n食物名称：").strip()
    if raw == "0" or not raw:
        return

    food_names = [f.strip() for f in raw.replace("，", ",").split(",") if f.strip()]

    # 验证并提示可用的食物名
    print()
    valid = []
    unknown = []
    for name in food_names:
        key = SYNONYMS.get(name.lower(), name.lower())
        if key in FOOD_NUTRITION:
            valid.append(name)
        else:
            unknown.append(name)

    if unknown:
        print(f"⚠ 未找到食物数据：{', '.join(unknown)}，已跳过")
        # 尝试模糊匹配
        print("  数据库中的食物：")
        all_foods = sorted(set(SYNONYMS.get(k, k) for k in FOOD_NUTRITION))
        for u in unknown:
            matches = [f for f in all_foods if u.lower() in f.lower()][:5]
            if matches:
                print(f"  「{u}」是否指：{', '.join(matches)}？")

    if not valid:
        input("\n没有有效食物，按回车返回...")
        return

    # 可选手动克数
    manual = {}
    print(f"\n检测到食物：{', '.join(valid)}")
    gram_input = input("如需指定克数（格式：食物=克数），直接回车使用推荐份量：").strip()
    if gram_input:
        for part in gram_input.split(","):
            part = part.strip()
            if "=" in part:
                n, g = part.split("=", 1)
                try:
                    manual[n.strip()] = float(g.strip())
                except ValueError:
                    pass

    result = planner.log_food(valid, manual)

    print(f"\n{'─' * 40}")
    print("【本次摄入】")
    for item in result["items"]:
        print(f"  {item['raw_name']:<12s} {item['portion']:<8s} {item['grams']}g")

    mt = result["meal_totals"]
    print(f"\n  碳水 {mt['carbs_g']}g | 蛋白 {mt['protein_g']}g | "
          f"脂肪 {mt['fat_g']}g | 热量 {mt['calories']}kcal")

    remaining = result["remaining"]
    bars = remaining.get("progress_bars", {})
    print("\n【今日进度】")
    if bars:
        print(f"  热量    {bars.get('calories', '')}")
        print(f"  碳水    {bars.get('carbs_g', '')}")
        print(f"  蛋白质  {bars.get('protein_g', '')}")
        print(f"  脂肪    {bars.get('fat_g', '')}")
        print(f"  纤维    {bars.get('fiber_g', '')}")

    input("\n按回车继续...")


def menu_remaining(planner: MealPlanner):
    """查看剩余建议"""
    if not planner.daily_log:
        print("\n今日尚未记录任何饮食。请先选择功能3记录食物。")
        input("按回车继续...")
        return

    suggestion = planner.suggest_next_meal()
    remaining = suggestion["remaining"]
    bars = remaining.get("progress_bars", {})

    print(f"\n{'=' * 50}")
    print("  今日剩余饮食建议")
    print(f"{'=' * 50}")

    print("\n【营养素完成度】")
    print(f"  热量    {bars.get('calories', '')}")
    print(f"  碳水    {bars.get('carbs_g', '')}")
    print(f"  蛋白质  {bars.get('protein_g', '')}")
    print(f"  脂肪    {bars.get('fat_g', '')}")
    print(f"  纤维    {bars.get('fiber_g', '')}")

    # 缺口最大
    top = suggestion.get("top_deficit")
    if top and top["pct"] < 80:
        print(f"\n⚠ 最需补充：{top['label']}（仅完成 {top['pct']:.0f}%）")

    # 推荐食物
    suggestions = suggestion.get("suggestions", [])
    if suggestions:
        meal_type = MEAL_ZH.get(suggestion.get("recommended_meal_type", "dinner"), "下一餐")
        print(f"\n【{meal_type}推荐食物】")
        for s in suggestions:
            name = s["name"]
            nut = FOOD_NUTRITION.get(name, {})
            print(f"  ● {name}（{s['reason']}）")
            if nut:
                print(f"    每100g: 碳水{nut.get('carbs', 0)}g | "
                      f"蛋白{nut.get('protein', 0)}g | "
                      f"热量{nut.get('calories', 0)}kcal | "
                      f"GI:{nut.get('gi', '-')}")

    # 搭配建议
    template = suggestion.get("meal_template", [])
    if template:
        print("\n【搭配参考】")
        parts = []
        for slot in template:
            count = slot["target_count"]
            unit = slot["target_unit"]
            from .visual_portion import VISUAL_UNITS
            unit_zh = VISUAL_UNITS.get(unit, {}).get("zh", unit)
            if count == 0.5:
                parts.append(f"{slot['label']} 半{unit_zh}")
            else:
                parts.append(f"{slot['label']} {int(count)}{unit_zh}")
        print(f"  {' + '.join(parts)}")

    # 用户目标特有的提示
    if planner.user_type == "diabetes":
        print("\n  🩸 控糖提示：优先低GI食物，每餐搭配蛋白质和蔬菜")
    elif planner.user_type == "weight_loss":
        print("\n  🏃 减脂提示：控制总热量，细嚼慢咽增加饱腹感")
    elif planner.user_type == "muscle_gain":
        print("\n  💪 增肌提示：训练后30分钟内补充蛋白质+碳水")

    input("\n按回车继续...")


def menu_summary(planner: MealPlanner):
    """今日饮食总结"""
    if not planner.daily_log:
        print("\n今日尚未记录任何饮食。")
        input("按回车继续...")
        return

    summary = planner.get_summary()
    r = summary["remaining"]
    bars = r.get("progress_bars", {})

    print(f"\n{'=' * 50}")
    print(f"  今日饮食总结 · {summary['goal_label']}")
    print(f"{'=' * 50}")

    print("\n【已记录食物】")
    for item in summary["logged_foods"]:
        print(f"  ● {item['name']:<12s} {item['portion']:<8s} {item['grams']}g")

    print("\n【摄入 vs 目标】")
    target = summary.get("daily_rda", {})
    today = summary["today_totals"]
    print(f"  热量    {today['calories']:.0f} / {target.get('daily_energy_kcal', '?')} kcal  {bars.get('calories', '')}")
    print(f"  碳水    {today['carbs_g']:.1f} / {target.get('daily_carbs_g', '?')}g  {bars.get('carbs_g', '')}")
    print(f"  蛋白质  {today['protein_g']:.1f} / {target.get('daily_protein_g', '?')}g  {bars.get('protein_g', '')}")
    print(f"  脂肪    {today['fat_g']:.1f} / {target.get('daily_fat_g', '?')}g  {bars.get('fat_g', '')}")
    print(f"  纤维    {today['fiber_g']:.1f} / {target.get('daily_fiber_g', '?')}g  {bars.get('fiber_g', '')}")

    # 汇总建议
    advice = summary.get("advice", {})
    if advice and advice.get("advice_text"):
        print("\n【营养师点评】")
        # 提取关键建议行
        lines = advice["advice_text"].split("\n")
        for line in lines:
            if "💡" in line or "✓" in line or "↓" in line or "⚠" in line:
                print(f"  {line.strip()}")

    input("\n按回车继续...")


def main():
    """主入口：交互式菜单循环"""
    planner = MealPlanner()
    menu_choice = "0"  # 首次进入显示菜单

    while True:
        if menu_choice != "0":
            clear_screen()
        print_header(planner)

        print("\n请选择功能：")
        print("  1. 设置健康目标")
        print("  2. 生成一日食谱推荐")
        print("  3. 记录我已吃的食物")
        print("  4. 查看今日剩余饮食建议")
        print("  5. 查看今日饮食总结")
        print("  0. 退出")
        print("=" * 50)

        menu_choice = input("请输入选项 [0-5]：").strip()

        if menu_choice == "0":
            print("\n感谢使用 SmartPlate 智能配餐助手，祝您健康！")
            break
        elif menu_choice == "1":
            menu_setup(planner)
        elif menu_choice == "2":
            menu_plan(planner)
        elif menu_choice == "3":
            menu_log(planner)
        elif menu_choice == "4":
            menu_remaining(planner)
        elif menu_choice == "5":
            menu_summary(planner)
        else:
            print("无效选项，请重新选择")
            input("按回车继续...")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n感谢使用 SmartPlate 智能配餐助手，祝您健康！")
    except Exception as e:
        print(f"\n发生错误：{e}")
        import traceback
        traceback.print_exc()
