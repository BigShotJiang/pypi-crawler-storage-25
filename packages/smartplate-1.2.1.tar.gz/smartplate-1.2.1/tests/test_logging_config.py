"""
测试 logging_config 模块
"""
import logging

from smartplate.logging_config import get_logger


class TestGetLogger:
    def test_returns_logger_instance(self):
        logger = get_logger("test_module")
        assert isinstance(logger, logging.Logger)

    def test_logger_naming(self):
        logger = get_logger("my_module")
        assert "my_module" in logger.name

    def test_logger_reuses_root(self):
        logger1 = get_logger("mod_a")
        logger2 = get_logger("mod_b")
        # Both are children of the same root "smartplate"
        assert logger1.parent is logger2.parent
        assert logger1.parent.name == "smartplate"

    def test_logger_level_is_info(self):
        logger = get_logger("test")
        # Root logger should be at INFO level
        assert logger.parent.level == logging.INFO
