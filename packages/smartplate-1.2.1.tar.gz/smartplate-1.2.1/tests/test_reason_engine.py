"""
测试 reason_engine 模块：规则引擎的食物评估和解释生成
"""
from smartplate.reason_engine import (
    KNOWLEDGE,
    evaluate_food,
    generate_explanation,
    generate_full_explanation,
)


class TestEvaluateFood:
    def test_high_fiber_food(self):
        """高纤维食物应对糖尿病和健身都有益"""
        data = {"fiber_g": 5.0, "protein_g": 2, "gi": 100, "chromium_ug": 1,
                "magnesium_mg": 10, "zinc_mg": 1, "calcium_mg": 10,
                "potassium_mg": 50, "fat_g": 10}
        reasons = evaluate_food("测试食物", data)
        assert "high_fiber" in reasons["diabetes"]
        assert "high_fiber" in reasons["fitness"]

    def test_high_protein_food(self):
        """高蛋白食物对健身人群有益"""
        data = {"fiber_g": 1, "protein_g": 25, "gi": 100, "chromium_ug": 0,
                "magnesium_mg": 10, "zinc_mg": 1, "calcium_mg": 10,
                "potassium_mg": 50, "fat_g": 10}
        reasons = evaluate_food("鸡胸肉", data)
        assert "high_protein" in reasons["fitness"]

    def test_low_gi_food(self):
        """低GI食物对控糖人群有益"""
        data = {"fiber_g": 2, "protein_g": 5, "gi": 30, "chromium_ug": 0,
                "magnesium_mg": 10, "zinc_mg": 1, "calcium_mg": 10,
                "potassium_mg": 50, "fat_g": 10}
        reasons = evaluate_food("燕麦", data)
        assert "low_gi" in reasons["diabetes"]

    def test_high_gi_food_no_benefit(self):
        """GI=0（纯蛋白质/脂肪）不应触发 low_gi"""
        data = {"fiber_g": 0, "protein_g": 31, "gi": 0, "chromium_ug": 0,
                "magnesium_mg": 10, "zinc_mg": 1, "calcium_mg": 10,
                "potassium_mg": 50, "fat_g": 3.6}
        reasons = evaluate_food("鸡胸肉", data)
        assert "low_gi" not in reasons["diabetes"]  # GI=0 means no carbs

    def test_low_fat_food(self):
        """低脂肪食物对健身人群有益"""
        data = {"fiber_g": 1, "protein_g": 20, "gi": 100, "chromium_ug": 0,
                "magnesium_mg": 10, "zinc_mg": 1, "calcium_mg": 10,
                "potassium_mg": 50, "fat_g": 2}
        reasons = evaluate_food("脱脂牛奶", data)
        assert "low_fat" in reasons["fitness"]

    def test_both_magnesium(self):
        """镁对both人群有益"""
        data = {"fiber_g": 2, "protein_g": 10, "gi": 50, "chromium_ug": 0,
                "magnesium_mg": 80, "zinc_mg": 1, "calcium_mg": 10,
                "potassium_mg": 50, "fat_g": 10}
        reasons = evaluate_food("菠菜", data)
        assert "magnesium" in reasons["diabetes"]
        assert "magnesium" in reasons["fitness"]


class TestGenerateExplanation:
    def test_diabetes_explanation(self):
        data = {"fiber_g": 5.0, "protein_g": 8, "gi": 30, "chromium_ug": 0,
                "magnesium_mg": 10, "zinc_mg": 1, "calcium_mg": 10,
                "potassium_mg": 50, "fat_g": 1}
        text = generate_explanation("西兰花", data, "diabetes")
        assert "西兰花" in text
        assert "控糖人群" in text

    def test_fitness_explanation(self):
        data = {"fiber_g": 1, "protein_g": 25, "gi": 0, "chromium_ug": 0,
                "magnesium_mg": 10, "zinc_mg": 1, "calcium_mg": 10,
                "potassium_mg": 50, "fat_g": 3}
        text = generate_explanation("鸡胸肉", data, "fitness")
        assert "鸡胸肉" in text
        assert "健身人群" in text

    def test_no_benefit_food(self):
        """没有特别益处的食物给出适量食用建议"""
        data = {"fiber_g": 0, "protein_g": 2, "gi": 100, "chromium_ug": 0,
                "magnesium_mg": 0, "zinc_mg": 0, "calcium_mg": 0,
                "potassium_mg": 0, "fat_g": 30}
        text = generate_explanation("黄油", data, "diabetes")
        assert "适量食用" in text


class TestGenerateFullExplanation:
    def test_full_explanation_structure(self):
        data = {"fiber_g": 5.0, "protein_g": 8, "gi": 30, "chromium_ug": 0,
                "magnesium_mg": 30, "zinc_mg": 2, "calcium_mg": 50,
                "potassium_mg": 200, "fat_g": 1, "iron_mg": 1.0}
        text = generate_full_explanation("西兰花", data)
        assert "西兰花 营养解析" in text
        assert "控糖人群" in text
        assert "健身人群" in text


class TestKnowledgeBase:
    def test_knowledge_has_required_keys(self):
        """知识库条目必须包含 name 和 function"""
        for key, info in KNOWLEDGE.items():
            assert "name" in info, f"{key} missing 'name'"
            assert "function" in info, f"{key} missing 'function'"
            assert "target" in info, f"{key} missing 'target'"
