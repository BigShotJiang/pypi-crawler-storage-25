"""
测试 nutrition_db 模块（含新增食物和同义词）
"""
from smartplate.nutrition_db import FOOD_NUTRITION, get_nutrition, search_food


def test_get_nutrition_rice():
    nut = get_nutrition("rice", 100)
    assert nut["carbs_g"] == 28.0
    assert nut["calories"] == 130


def test_get_nutrition_unknown():
    nut = get_nutrition("unknown_food", 100)
    assert nut is None


def test_get_nutrition_synonym():
    nut = get_nutrition("white rice", 150)
    assert abs(nut["carbs_g"] - 42.0) < 0.1  # 28*1.5=42


def test_get_nutrition_chinese_synonym():
    """中文同义词查询"""
    nut = get_nutrition("米饭", 200)
    assert nut is not None
    assert abs(nut["carbs_g"] - 56.0) < 0.1  # 28*2=56


def test_get_nutrition_scaled():
    """重量缩放"""
    nut = get_nutrition("banana", 200)
    assert abs(nut["carbs_g"] - 46.0) < 0.1  # 23*2=46
    assert abs(nut["calories"] - 178.0) < 0.1  # 89*2=178


def test_new_food_grape():
    """新增食物：葡萄"""
    nut = get_nutrition("grape", 100)
    assert nut is not None
    assert nut["carbs_g"] == 18.0
    assert nut["gi"] == 46


def test_new_food_chinese_grape():
    """中文葡萄"""
    nut = get_nutrition("葡萄", 100)
    assert nut is not None
    assert nut["carbs_g"] == 18.0


def test_new_food_avocado():
    """新增食物：牛油果"""
    nut = get_nutrition("avocado", 100)
    assert nut is not None
    assert nut["fat_g"] == 14.7  # 高脂肪水果
    assert nut["fiber_g"] == 6.7


def test_new_food_mango():
    """新增食物：芒果"""
    nut = get_nutrition("芒果", 100)
    assert nut is not None
    assert nut["carbs_g"] == 15.0


def test_search_food():
    """模糊搜索：英文同义词搜索返回中文规范名称"""
    results = search_food("rice")
    assert "米饭" in results


def test_search_food_chinese():
    """中文搜索"""
    results = search_food("鸡")
    assert len(results) > 0


def test_all_foods_have_required_keys():
    """所有食物必须有完整的营养字段"""
    required = ["carbs", "protein", "fat", "calories", "gi",
                "calcium_mg", "iron_mg", "zinc_mg", "magnesium_mg",
                "chromium_ug", "potassium_mg", "fiber_g"]
    for name, data in FOOD_NUTRITION.items():
        for key in required:
            assert key in data, f"{name} 缺少字段 {key}"


def test_food_count():
    """验证食物数量（应 >= 50）"""
    assert len(FOOD_NUTRITION) >= 50, f"当前只有 {len(FOOD_NUTRITION)} 种食物"
