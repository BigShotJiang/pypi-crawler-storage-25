"""
测试 advice_engine 模块
"""
from smartplate.advice_engine import (
    _generate_pairing_advice,
    analyze_nutrition,
    generate_advice,
    get_user_rda,
    per_meal_rda,
)


def test_advice_diabetes_high_carbs():
    """控糖用户：碳水化合物超过每餐上限应触发偏高"""
    totals = {"carbs_g": 90, "protein_g": 20, "fat_g": 10, "calories": 500, "fiber_g": 2}
    result = generate_advice(totals, "diabetes")
    assert isinstance(result, dict)
    assert "advice_text" in result
    assert "analysis" in result
    carbs_analysis = next(a for a in result["analysis"] if a["nutrient"] == "carbohydrate")
    assert carbs_analysis["status"] == "high"


def test_advice_fitness_low_protein():
    """健身用户：蛋白质偏低应触发提示"""
    totals = {"carbs_g": 40, "protein_g": 15, "fat_g": 10, "calories": 400, "fiber_g": 2}
    result = generate_advice(totals, "muscle_gain")
    assert isinstance(result, dict)
    protein_analysis = next(a for a in result["analysis"] if a["nutrient"] == "protein")
    assert protein_analysis["status"] == "low"


def test_advice_backward_compat_fitness():
    """向后兼容：fitness 输入映射到 muscle_gain"""
    result = generate_advice({"carbs_g": 40, "protein_g": 15, "fat_g": 10,
                               "calories": 400, "fiber_g": 2}, "fitness")
    assert "advice_text" in result


def test_generate_advice_returns_user_profile():
    """验证返回的用户画像信息"""
    result = generate_advice(
        {"carbs_g": 50, "protein_g": 25, "fat_g": 15, "calories": 500, "fiber_g": 5},
        "diabetes", gender="female", age=40, activity="moderate"
    )
    assert result["user_profile"]["gender"] == "female"
    assert result["user_profile"]["age"] == 40
    assert result["user_profile"]["activity"] == "moderate"
    assert result["user_profile"]["goal"] == "diabetes"


def test_get_user_rda():
    """验证 RDA 计算"""
    rda = get_user_rda("male", 30, "light", "general")
    assert rda["daily_energy_kcal"] == 2250
    assert 300 < rda["daily_carbs_g"] < 400
    assert 60 < rda["daily_protein_g"] < 90

    meal = per_meal_rda(rda)
    assert 700 < meal["energy_kcal"] < 800


def test_diabetes_gl_analysis():
    """控糖模式：应包含血糖负荷分析"""
    totals = {"carbs_g": 60, "protein_g": 20, "fat_g": 10, "calories": 450,
              "fiber_g": 3, "glycemic_load": 55, "avg_gi": 70}
    rda = get_user_rda("male", 30, "light", "diabetes")
    meal_targets = per_meal_rda(rda)
    analysis = analyze_nutrition(totals, meal_targets, rda["goal_config"])

    gl_items = [a for a in analysis if a["nutrient"] == "glycemic_load"]
    assert len(gl_items) == 1
    assert gl_items[0]["value"] == 55
    assert gl_items[0]["status"] == "high"  # 55/40=137.5% > 130%


def test_gl_not_shown_for_general():
    """非控糖模式：不应显示 GL 分析"""
    totals = {"carbs_g": 60, "protein_g": 20, "fat_g": 10, "calories": 450,
              "fiber_g": 3, "glycemic_load": 45}
    rda = get_user_rda("male", 30, "light", "general")
    meal_targets = per_meal_rda(rda)
    analysis = analyze_nutrition(totals, meal_targets, rda["goal_config"])

    gl_items = [a for a in analysis if a["nutrient"] == "glycemic_load"]
    assert len(gl_items) == 0  # GL 仅在控糖模式显示


def test_pairing_advice_high_gl():
    """高 GL + 低蛋白/纤维：应触发搭配建议"""
    totals = {"carbs_g": 70, "protein_g": 8, "fat_g": 10, "calories": 450,
              "fiber_g": 2, "glycemic_load": 50, "avg_gi": 70}
    config = {"gl_max_per_meal": 40, "gi_limit": 55}
    tips = _generate_pairing_advice(totals, "diabetes", config)
    assert len(tips) >= 2  # 应该至少建议增加蛋白质和纤维


def test_pairing_advice_low_gl():
    """低 GL + 充足蛋白/纤维：应给出正面评价"""
    totals = {"carbs_g": 30, "protein_g": 25, "fat_g": 8, "calories": 350,
              "fiber_g": 6, "glycemic_load": 20, "avg_gi": 45}
    config = {"gl_max_per_meal": 40, "gi_limit": 55}
    tips = _generate_pairing_advice(totals, "diabetes", config)
    # 应有正面评价
    positive = [t for t in tips if "搭配合理" in t]
    assert len(positive) >= 1


def test_rda_different_ages():
    """不同年龄段的能量需求应不同"""
    rda_young = get_user_rda("male", 25, "light", "general")
    rda_senior = get_user_rda("male", 60, "light", "general")
    assert rda_senior["daily_energy_kcal"] < rda_young["daily_energy_kcal"]


def test_rda_diabetes_goal():
    """控糖目标的配置应包含必要参数"""
    rda = get_user_rda("female", 45, "moderate", "diabetes")
    config = rda["goal_config"]
    assert "carbs_max_per_meal" in config
    assert "gl_max_per_meal" in config
    assert config["carbs_max_per_meal"] == 60
    assert rda["goal_description"] == "糖尿病/血糖控制"
