"""
测试 meal_planner 模块：食物评分、选取、份量转换（纯规则引擎路径）
"""
import random

from smartplate.meal_planner import MealPlanner, _pick_foods, _portion_to_grams, _score_food


class TestScoreFood:
    def test_diabetes_prefers_low_gi(self):
        """控糖模式：低GI食物得分应高于高GI食物"""
        # 燕麦 GI=40 vs 白米饭 GI=73 (both grains, similar category)
        score_oats = _score_food("燕麦", "diabetes", "grains")
        score_rice = _score_food("米饭", "diabetes", "grains")
        assert score_oats > score_rice, f"oats={score_oats} should beat rice={score_rice}"

    def test_weight_loss_prefers_low_calorie(self):
        """减脂模式：低热量蔬菜得分应高于高热量主食"""
        score_broccoli = _score_food("西兰花", "weight_loss", "vegetables")
        score_rice = _score_food("米饭", "weight_loss", "grains")
        assert score_broccoli > score_rice

    def test_muscle_gain_prefers_high_protein(self):
        """增肌模式：高蛋白食物得分应高于低蛋白食物"""
        score_chicken = _score_food("鸡胸肉", "muscle_gain", "protein")
        score_tofu = _score_food("豆腐", "muscle_gain", "protein")
        assert score_chicken > score_tofu

    def test_unknown_food_scores_zero(self):
        assert _score_food("不存在的食物", "general", "mixed") == 0.0

    def test_general_mode_balanced(self):
        """日常模式应有正向得分"""
        score = _score_food("西兰花", "general", "vegetables")
        assert score > 0


class TestPickFoods:
    def test_pick_single(self):
        random.seed(42)
        pool = ["西兰花", "菠菜", "番茄"]
        picked = _pick_foods(pool, "general", "vegetables", count=1)
        assert len(picked) == 1
        assert picked[0] in pool

    def test_pick_multiple(self):
        random.seed(42)
        pool = ["鸡胸肉", "牛肉", "三文鱼", "虾仁", "鸡蛋"]
        picked = _pick_foods(pool, "muscle_gain", "protein", count=2)
        assert len(picked) == 2
        # all picked should be from the pool
        for item in picked:
            assert item in pool

    def test_pick_all_from_small_pool(self):
        random.seed(42)
        pool = ["苹果", "香蕉"]
        picked = _pick_foods(pool, "general", "fruits", count=5)
        assert len(picked) == 2  # only 2 available

    def test_pick_empty_pool(self):
        assert _pick_foods([], "general", "grains", count=1) == []

    def test_pick_zero_count(self):
        assert _pick_foods(["米饭", "馒头"], "general", "grains", count=0) == []

    def test_pick_deterministic_with_seed(self):
        """固定种子应产生相同结果"""
        pool = ["鸡胸肉", "牛肉", "三文鱼", "虾仁", "鸡蛋"]
        random.seed(42)
        pick1 = _pick_foods(pool, "muscle_gain", "protein", count=2)
        random.seed(42)
        pick2 = _pick_foods(pool, "muscle_gain", "protein", count=2)
        assert pick1 == pick2


class TestPortionToGrams:
    def test_rice_fist(self):
        grams = _portion_to_grams("米饭", "fist", 1)
        assert grams == 150

    def test_chicken_double_palm(self):
        grams = _portion_to_grams("鸡胸肉", "palm", 2)
        assert grams == 170  # 85 * 2

    def test_unknown_food_fallback(self):
        grams = _portion_to_grams("unknown", "fist", 1)
        assert grams > 0  # fallback to 100


class TestMealPlannerInit:
    def test_create_general_planner(self):
        planner = MealPlanner("general", "male", 30, "moderate")
        assert planner.user_type == "general"
        assert planner.user_profile["gender"] == "male"
        assert planner.user_profile["age"] == 30
        assert planner.user_profile["activity"] == "moderate"

    def test_create_diabetes_planner(self):
        planner = MealPlanner("diabetes", "female", 55, "light")
        assert planner.user_type == "diabetes"
        assert "daily_energy_kcal" in planner.daily_rda

    def test_dri_targets_are_set(self):
        planner = MealPlanner("general", "male", 30, "moderate")
        assert "daily_energy_kcal" in planner.daily_rda
        assert "daily_carbs_g" in planner.daily_rda
        assert "daily_protein_g" in planner.daily_rda
        assert "daily_fat_g" in planner.daily_rda

    def test_different_ages_different_dri(self):
        young = MealPlanner("general", "male", 25, "light")
        senior = MealPlanner("general", "male", 65, "light")
        # younger person needs more calories
        assert young.daily_rda["daily_energy_kcal"] > senior.daily_rda["daily_energy_kcal"]
