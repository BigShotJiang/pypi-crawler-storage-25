"""
测试 visual_portion 模块：食物分类、份量推荐
"""
from smartplate.visual_portion import (
    classify_food,
    get_default_unit,
    get_gram_equivalent,
    recommend_all_portions,
    recommend_portion,
)


class TestClassifyFood:
    def test_classify_known_food(self):
        assert classify_food("鸡胸肉") == "protein"
        assert classify_food("米饭") == "grains"
        assert classify_food("西兰花") == "vegetables"

    def test_classify_unknown_food(self):
        assert classify_food("火星岩石") == "mixed"


class TestGramEquivalent:
    def test_get_gram_rice_fist(self):
        grams = get_gram_equivalent("米饭", "fist")
        assert grams == 150  # 1 fist grains ≈ 150g

    def test_get_gram_chicken_palm(self):
        grams = get_gram_equivalent("鸡胸肉", "palm")
        assert grams == 85  # 1 palm protein ≈ 85g

    def test_get_gram_unknown_unit(self):
        grams = get_gram_equivalent("米饭", "nonexistent_unit")
        assert grams == 100  # fallback default


class TestDefaultUnit:
    def test_default_unit_grains(self):
        assert get_default_unit("米饭") == "fist"

    def test_default_unit_protein(self):
        assert get_default_unit("鸡胸肉") == "palm"

    def test_default_unit_unknown(self):
        assert get_default_unit("unknown_food") == "palm"  # unknown→mixed→palm


class TestRecommendPortion:
    def test_recommend_general(self):
        rec = recommend_portion("米饭", "general")
        assert rec["name"] == "米饭"
        assert rec["category"] == "grains"
        assert "grams" in rec
        assert "visual_display" in rec
        assert rec["grams"] > 0

    def test_recommend_diabetes(self):
        rec = recommend_portion("米饭", "diabetes")
        assert rec["name"] == "米饭"

    def test_recommend_muscle_gain(self):
        rec = recommend_portion("鸡胸肉", "muscle_gain")
        assert rec["category"] == "protein"
        assert rec["grams"] > 0

    def test_recommend_custom_count(self):
        rec = recommend_portion("米饭", "general", unit_count=2)
        assert rec["visual_quantity"] == 2
        assert rec["grams"] >= 280  # ~2 * 150

    def test_recommend_half_portion(self):
        rec = recommend_portion("米饭", "general", unit_count=0.5)
        assert "半" in rec["visual_display"]


class TestRecommendAllPortions:
    def test_single_category(self):
        result, summary = recommend_all_portions(["鸡胸肉", "牛肉"], "general")
        assert "鸡胸肉" in result
        assert "牛肉" in result
        assert "protein" in summary["per_category"]

    def test_multi_category(self):
        foods = ["米饭", "鸡胸肉", "西兰花", "苹果"]
        result, summary = recommend_all_portions(foods, "general")
        assert len(result) == 4
        # summary per_category should cover grains, protein, vegetables, fruits
        assert len(summary["per_category"]) >= 3

    def test_empty_foods(self):
        result, summary = recommend_all_portions([], "general")
        assert result == {}
        assert summary["per_category"] == {}
        assert summary["total_recommended_grams"] == 0
