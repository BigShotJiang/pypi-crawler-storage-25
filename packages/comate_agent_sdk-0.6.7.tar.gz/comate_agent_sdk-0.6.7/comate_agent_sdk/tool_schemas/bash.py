from __future__ import annotations

from typing import Any

from comate_agent_sdk.tool_schemas._base import ToolOutput


class BashOutput(ToolOutput):
    stdout: str
    stderr: str
    exit_code: int
    timed_out: bool
    interrupted: bool
    killed: bool
    duration_ms: int
    truncated: bool
    truncated_reason: str | None = None
    artifact: dict[str, Any] | None = None
    stdout_truncated: bool = False
    stdout_total_bytes: int = 0
    stdout_dropped_lines: int = 0
    stderr_truncated: bool = False
    stderr_total_bytes: int = 0
    stderr_dropped_lines: int = 0
