from __future__ import annotations

from typing import Literal

from pydantic import Field

from comate_agent_sdk.tool_schemas._base import ToolOutput
from comate_agent_sdk.tool_schemas._diff import PatchHunk


class WriteOutput(ToolOutput):
    bytes_written: int
    lines_written: int
    file_bytes: int
    created: bool
    sha256: str
    relpath: str
    type: Literal["create", "update", "append"] | None = None
    structured_patch: list[PatchHunk] = Field(default_factory=list)
    original_file: str | None = None
