from __future__ import annotations

from typing import Literal

from pydantic import Field

from comate_agent_sdk.tool_schemas._base import ToolOutput
from comate_agent_sdk.tool_schemas._diff import PatchHunk


class EditOutput(ToolOutput):
    replacements: int
    created: bool | None = None
    before_sha256: str | None
    after_sha256: str
    relpath: str
    diff: list[str]
    start_line: int
    end_line: int
    type: Literal["create", "update"] | None = None
    structured_patch: list[PatchHunk] = Field(default_factory=list)
    original_file: str | None = None
