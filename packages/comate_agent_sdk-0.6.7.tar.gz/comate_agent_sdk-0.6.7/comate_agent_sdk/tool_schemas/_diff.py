from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class PatchHunk(BaseModel):
    model_config = ConfigDict(extra="ignore", frozen=True)

    old_start: int
    old_lines: int
    new_start: int
    new_lines: int
    lines: list[str]
