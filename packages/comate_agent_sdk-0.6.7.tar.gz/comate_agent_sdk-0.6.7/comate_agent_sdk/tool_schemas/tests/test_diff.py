from __future__ import annotations

import pytest
from pydantic import ValidationError

from comate_agent_sdk.tool_schemas._diff import PatchHunk


def test_patch_hunk_accepts_python_field_names() -> None:
    hunk = PatchHunk(
        old_start=1,
        old_lines=2,
        new_start=1,
        new_lines=3,
        lines=[" line", "-old", "+new"],
    )

    assert hunk.old_start == 1
    assert hunk.old_lines == 2
    assert hunk.new_start == 1
    assert hunk.new_lines == 3
    assert hunk.lines == [" line", "-old", "+new"]


def test_patch_hunk_is_frozen() -> None:
    hunk = PatchHunk(old_start=1, old_lines=1, new_start=1, new_lines=1, lines=[])

    with pytest.raises(ValidationError):
        hunk.old_start = 2


def test_patch_hunk_ignores_future_fields() -> None:
    hunk = PatchHunk.model_validate(
        {
            "old_start": 1,
            "old_lines": 1,
            "new_start": 1,
            "new_lines": 1,
            "lines": [],
            "future_field": "ignored",
        }
    )

    assert not hasattr(hunk, "future_field")
