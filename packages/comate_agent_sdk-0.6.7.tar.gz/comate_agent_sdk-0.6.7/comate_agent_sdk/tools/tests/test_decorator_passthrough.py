import unittest

from pydantic import BaseModel
from mcp.types import CallToolResult, TextContent

from comate_agent_sdk.tools.decorator import tool


@tool("test tool")
async def passthrough_tool(x: int) -> CallToolResult:
    return CallToolResult(
        content=[TextContent(type="text", text=str(x))],
    )


@tool("error tool")
async def error_tool() -> CallToolResult:
    return CallToolResult(
        content=[TextContent(type="text", text="bad")],
        isError=True,
    )


@tool("legacy tool")
async def legacy_tool(x: int) -> str:
    return f"result: {x}"


@tool("observable defaults")
async def observable_defaults_tool(path: str, recursive: bool = False, limit: int = 10) -> str:
    return path


class ObservableParams(BaseModel):
    query: str
    limit: int = 20
    format: str = "text"


@tool("observable model defaults")
async def observable_model_tool(params: ObservableParams) -> str:
    return params.query


def _backfill_abs_path(args: dict[str, object]) -> None:
    path = args.get("path")
    if isinstance(path, str) and not path.startswith("/"):
        args["abs_path"] = f"/workspace/{path}"


@tool("observable backfill", observable_input_backfill=_backfill_abs_path)
async def observable_backfill_tool(path: str) -> str:
    return path


class TestCallToolResultPassthrough(unittest.IsolatedAsyncioTestCase):
    async def test_call_tool_result_passes_through(self):
        """CallToolResult returned by handler is NOT serialized."""
        result = await passthrough_tool.execute(x=42)
        self.assertIsInstance(result, CallToolResult)
        self.assertEqual(result.content[0].text, "42")
        self.assertFalse(result.isError)

    async def test_call_tool_result_preserves_is_error(self):
        """isError=True passes through unchanged."""
        result = await error_tool.execute()
        self.assertIsInstance(result, CallToolResult)
        self.assertTrue(result.isError)

    async def test_legacy_return_still_serialized(self):
        """Non-CallToolResult returns still go through _serialize_result."""
        result = await legacy_tool.execute(x=1)
        self.assertIsInstance(result, str)
        self.assertEqual(result, "result: 1")


class TestObservableInput(unittest.TestCase):
    def test_build_observable_input_backfills_signature_defaults(self):
        observable = observable_defaults_tool.build_observable_input({"path": "src/app.py"})
        self.assertEqual(
            observable,
            {
                "path": "src/app.py",
                "recursive": False,
                "limit": 10,
            },
        )

    def test_build_observable_input_backfills_model_defaults(self):
        observable = observable_model_tool.build_observable_input({"query": "hello"})
        self.assertEqual(
            observable,
            {
                "query": "hello",
                "limit": 20,
                "format": "text",
            },
        )

    def test_build_observable_input_applies_tool_backfill(self):
        observable = observable_backfill_tool.build_observable_input({"path": "docs/spec.md"})
        self.assertEqual(
            observable,
            {
                "path": "docs/spec.md",
                "abs_path": "/workspace/docs/spec.md",
            },
        )
