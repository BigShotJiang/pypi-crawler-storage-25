# comate_agent_sdk/facade/core/events.py
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, TypeAlias

# 重新导出现有事件（来自 agent.events）
from comate_agent_sdk.agent.events import (
    SessionInitEvent,
    StepCompleteEvent,
    StepStartEvent,
    TeamMessageEvent,
    TextDeltaEvent,
    TextEvent,
    ThinkingDeltaEvent,
    ThinkingEvent,
    ToolCallStartEvent,
    ToolResultEvent,
    UserQuestionEvent,
)


# 新增：YieldEvent（Team Mode 中的让出）
@dataclass(slots=True)
class YieldEvent:
    """Agent 在 team mode 中让出控制权，SDK 继续轮询"""
    reason: Literal[
        "waiting_for_inbox",      # 等待 inbox 消息
        "waiting_for_task",       # 等待任务分配
        "waiting_for_teammate",   # 等待 teammate 回复
    ]
    metadata: dict[str, object] = field(default_factory=dict)

    def __str__(self) -> str:
        return f"⏸️  让出: {self.reason}"


# 新增：StopEvent（取代 DoneEvent）
@dataclass(slots=True)
class StopEvent:
    """Agent 真的停止了（无论是否 team mode）"""
    reason: Literal[
        "completed",              # 正常完成
        "interrupted",            # 被中断
        "max_iterations",         # 达到最大迭代
    ]

    def __str__(self) -> str:
        return f"🛑 停止: {self.reason}"


# 新增：ToolUseEvent（迁移自 facade.events）
@dataclass(slots=True)
class ToolUseEvent:
    """Agent 调用工具"""
    tool: str
    args: dict[str, object]
    tool_call_id: str
    display_name: str = ""

    def __str__(self) -> str:
        import json
        if self.display_name:
            return f"🔧 {self.display_name}"
        args_str = json.dumps(self.args, default=str)
        if len(args_str) > 80:
            args_str = f"{args_str[:77]}..."
        return f"🔧 {self.tool}({args_str})"


# TypeAlias：事件联合类型
Event: TypeAlias = (
    SessionInitEvent
    | TextEvent
    | TextDeltaEvent
    | ThinkingEvent
    | ThinkingDeltaEvent
    | ToolUseEvent
    | ToolCallStartEvent
    | ToolResultEvent
    | StepStartEvent
    | StepCompleteEvent
    | UserQuestionEvent
    | TeamMessageEvent
    | YieldEvent
    | StopEvent
)

__all__ = [
    "Event",
    "SessionInitEvent",
    "TextEvent",
    "TextDeltaEvent",
    "ThinkingEvent",
    "ThinkingDeltaEvent",
    "ToolUseEvent",
    "ToolCallStartEvent",
    "ToolResultEvent",
    "StepStartEvent",
    "StepCompleteEvent",
    "TeamMessageEvent",
    "UserQuestionEvent",
    "YieldEvent",
    "StopEvent",
]
