import tempfile
import unittest
from collections.abc import Mapping
from pathlib import Path
from types import MappingProxyType
from comate_agent_sdk.agent.compaction.models import CompactionConfig
from comate_agent_sdk.facade.config.options import AgentOptions, SubagentConfig
from comate_agent_sdk.facade._internals.adapters import _map_options
from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.llm.schema import build_response_format_from_model
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.tools.decorator import tool


class TestFacadeCapabilityGating(unittest.TestCase):
    def test_facade_tools_comate_allows_agent_capability_when_agents_present(self) -> None:
        config = _map_options(AgentOptions(
            tools="comate",
            agents={"researcher": SubagentConfig(description="r", prompt="p")},
        ))
        self.assertIsNone(config.tools)
        self.assertIsNotNone(config.agents)

    def test_facade_tools_comate_allows_skill_capability_when_skills_present(self) -> None:
        config = _map_options(AgentOptions(
            tools="comate",
            skills=["demo-skill"],
        ))
        self.assertIsNone(config.tools)
        self.assertIsNotNone(config.skills)

    def test_facade_missing_agent_capability_fails_fast(self) -> None:
        with self.assertRaisesRegex(ValueError, "Agent capability"):
            _map_options(AgentOptions(
                tools=["Read", "Write"],
                agents={"researcher": SubagentConfig(description="r", prompt="p")},
            ))

    def test_facade_missing_skill_capability_fails_fast(self) -> None:
        with self.assertRaisesRegex(ValueError, "Skill capability"):
            _map_options(AgentOptions(
                tools=["Read", "Write"],
                skills=["demo-skill"],
            ))

    def test_facade_agent_sentinel_without_explicit_agents_defers_to_runtime(self) -> None:
        config = _map_options(AgentOptions(tools=["Agent"]))
        self.assertEqual(config.tools, ("Agent",))

    def test_facade_skill_sentinel_without_explicit_skills_defers_to_runtime(self) -> None:
        config = _map_options(AgentOptions(tools=["Skill"]))
        self.assertEqual(config.tools, ("Skill",))

    def test_facade_disallowed_agent_conflict_fails_fast(self) -> None:
        with self.assertRaisesRegex(ValueError, "disallowed_tools"):
            _map_options(AgentOptions(
                tools="comate",
                agents={"researcher": SubagentConfig(description="r", prompt="p")},
                disallowed_tools=["Agent"],
            ))

    def test_facade_plugin_skill_requires_skill_capability(self) -> None:
        from types import SimpleNamespace

        from comate_agent_sdk.skill.models import SkillDefinition

        plugin = SimpleNamespace(
            agents=[],
            skills=[SkillDefinition(name="plugin:demo", description="demo", prompt="demo")],
            mcp_servers={},
        )

        with self.assertRaisesRegex(ValueError, "Skill capability"):
            _map_options(AgentOptions(tools=["Read"]), loaded_plugins=[plugin])


class TestEnvFieldMapping(unittest.TestCase):
    def test_env_none_by_default(self) -> None:
        config = _map_options(AgentOptions())
        self.assertIsNone(config.env)

    def test_env_maps_to_frozen_mapping(self) -> None:
        config = _map_options(AgentOptions(env={"FOO": "bar", "BAZ": "1"}))
        self.assertIsNotNone(config.env)
        self.assertEqual(config.env["FOO"], "bar")
        self.assertEqual(config.env["BAZ"], "1")
        self.assertIsInstance(config.env, MappingProxyType)

    def test_env_empty_dict_maps_to_none(self) -> None:
        config = _map_options(AgentOptions(env={}))
        self.assertIsNone(config.env)

    def test_memory_background_enabled_none_by_default(self) -> None:
        config = _map_options(AgentOptions())
        self.assertIsNone(config.memory_background_enabled)

    def test_memory_background_enabled_maps_to_config(self) -> None:
        config = _map_options(AgentOptions(memory_background_enabled=False))
        self.assertFalse(config.memory_background_enabled)

    def test_compaction_threshold_ratio_none_by_default(self) -> None:
        config = _map_options(AgentOptions())
        self.assertIsNone(config.compaction)

    def test_compaction_threshold_ratio_maps_to_compaction_config(self) -> None:
        config = _map_options(AgentOptions(compaction_threshold_ratio=0.72))
        self.assertEqual(config.compaction, CompactionConfig(threshold_ratio=0.72))


from comate_agent_sdk.tools.system_context import (
    SystemToolContext,
    bind_system_tool_context,
    get_system_tool_context,
)


class TestEnvSystemToolContext(unittest.TestCase):
    def test_config_env_field_exists(self) -> None:
        ctx = SystemToolContext(
            project_root=Path("/tmp"),
            config_env={"MY_VAR": "hello"},
        )
        self.assertEqual(ctx.config_env["MY_VAR"], "hello")

    def test_config_env_default_none(self) -> None:
        ctx = SystemToolContext(project_root=Path("/tmp"))
        self.assertIsNone(ctx.config_env)

    def test_bind_passes_config_env(self) -> None:
        with bind_system_tool_context(
            project_root="/tmp",
            config_env={"X": "1"},
        ):
            ctx = get_system_tool_context()
            self.assertIsNotNone(ctx.config_env)
            self.assertEqual(ctx.config_env["X"], "1")


class TestAddDirsFieldMapping(unittest.TestCase):
    def test_add_dirs_none_by_default(self) -> None:
        config = _map_options(AgentOptions())
        self.assertIsNone(config.add_dirs)

    def test_add_dirs_maps_to_resolved_paths(self) -> None:
        config = _map_options(AgentOptions(add_dirs=["/tmp", "/var"]))
        self.assertIsNotNone(config.add_dirs)
        self.assertIsInstance(config.add_dirs, tuple)
        self.assertEqual(len(config.add_dirs), 2)
        for p in config.add_dirs:
            self.assertTrue(p.is_absolute())
            self.assertIsInstance(p, Path)

    def test_add_dirs_empty_list_maps_to_none(self) -> None:
        config = _map_options(AgentOptions(add_dirs=[]))
        self.assertIsNone(config.add_dirs)


class _FakeLLM:
    def __init__(self) -> None:
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):
        return ChatInvokeCompletion(content="ok")


class TestDisallowedToolsMapping(unittest.TestCase):
    def test_disallowed_tools_none_by_default(self) -> None:
        config = _map_options(AgentOptions())
        self.assertIsNone(config.disallowed_tools)

    def test_disallowed_tools_maps_to_tuple(self) -> None:
        config = _map_options(AgentOptions(
            tools="comate",
            disallowed_tools=["Bash", "Write"],
        ))
        self.assertEqual(config.disallowed_tools, ("Bash", "Write"))

    def test_disallowed_tools_empty_list_maps_to_none(self) -> None:
        config = _map_options(AgentOptions(disallowed_tools=[]))
        self.assertIsNone(config.disallowed_tools)


class TestDisallowedToolsFiltering(unittest.TestCase):
    def test_disallowed_tools_excluded_from_definitions(self) -> None:
        @tool("A test tool", name="AllowedTool")
        async def allowed(x: str) -> str:
            return x

        @tool("A banned tool", name="BannedTool")
        async def banned(x: str) -> str:
            return x

        with tempfile.TemporaryDirectory() as tmp:
            template = Agent(
                llm=_FakeLLM(),
                config=AgentConfig(
                    tools=(allowed, banned),
                    disallowed_tools=("BannedTool",),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=Path(tmp),
                ),
            )
            runtime = template.create_runtime()

        tool_names = {d.name for d in runtime.tool_definitions}
        self.assertIn("AllowedTool", tool_names)
        self.assertNotIn("BannedTool", tool_names)


from pydantic import BaseModel as PydanticBaseModel


class SampleSchema(PydanticBaseModel):
    name: str
    age: int


def _to_plain(value):
    if isinstance(value, Mapping):
        return {k: _to_plain(v) for k, v in value.items()}
    if isinstance(value, tuple):
        return [_to_plain(v) for v in value]
    return value


class TestOutputFormatMapping(unittest.TestCase):
    def test_output_format_none_by_default(self) -> None:
        config = _map_options(AgentOptions())
        self.assertIsNone(config.output_format)

    def test_output_format_dict_passthrough(self) -> None:
        raw = {"type": "json_schema", "schema": {"type": "object", "properties": {"x": {"type": "string"}}}}
        config = _map_options(AgentOptions(output_format=raw))
        self.assertIsNotNone(config.output_format)
        self.assertEqual(config.output_format["type"], "json_schema")

    def test_output_format_pydantic_class(self) -> None:
        config = _map_options(AgentOptions(output_format=SampleSchema))
        self.assertIsNotNone(config.output_format)
        self.assertEqual(
            _to_plain(config.output_format),
            build_response_format_from_model(SampleSchema),
        )

    def test_output_format_pydantic_instance(self) -> None:
        instance = SampleSchema(name="test", age=1)
        config = _map_options(AgentOptions(output_format=instance))
        self.assertIsNotNone(config.output_format)
        self.assertEqual(
            _to_plain(config.output_format),
            build_response_format_from_model(SampleSchema),
        )


class TestStructuredOutputParsing(unittest.TestCase):
    def test_completion_has_structured_output_field(self) -> None:
        c = ChatInvokeCompletion(content='{"x": 1}')
        self.assertIsNone(c.structured_output)
        self.assertIsNone(c.structured_output_error)

    def test_completion_structured_output_settable(self) -> None:
        c = ChatInvokeCompletion(content='{"x": 1}', structured_output={"x": 1})
        self.assertEqual(c.structured_output, {"x": 1})


class TestStructuredOutputRetry(unittest.TestCase):
    def test_valid_json_parsed_successfully(self) -> None:
        import json_repair
        result = json_repair.loads('{"name": "test", "age": 30}')
        self.assertEqual(result, {"name": "test", "age": 30})

    def test_json_repair_fixes_minor_errors(self) -> None:
        import json_repair
        result = json_repair.loads('{"name": "test", "age": 30,}')
        self.assertEqual(result["name"], "test")

    def test_structured_output_max_retries_default(self) -> None:
        config = _map_options(AgentOptions())
        self.assertEqual(config.structured_output_max_retries, 3)


from comate_agent_sdk.agent.events import TextEvent as InternalTextEvent


class TestTextEventStructuredOutput(unittest.TestCase):
    def test_text_event_has_structured_output(self) -> None:
        event = InternalTextEvent(content='{"x": 1}', structured_output={"x": 1})
        self.assertEqual(event.structured_output, {"x": 1})

    def test_text_event_structured_output_default_none(self) -> None:
        event = InternalTextEvent(content="hello")
        self.assertIsNone(event.structured_output)
