"""Regression coverage for the include_partial_messages flag.

Background: 当 LLM provider 切换到 streaming 模式后，stream_translator 会向上抛出
TextDeltaEvent / ThinkingDeltaEvent / ToolCallStartEvent 三个 transient 事件。

facade 层的 _filter_events / _filter_events_new 默认应当静默丢弃这三类事件
（与 streaming 改造前的行为一致），仅在 AgentOptions.include_partial_messages=True
时才透传给 SDK 用户 —— 该语义对齐 Claude Code SDK 的 includePartialMessages。
"""

from __future__ import annotations

import asyncio
import unittest
from collections.abc import AsyncIterator

from comate_agent_sdk.agent.events import (
    AgentEvent,
    SessionInitEvent,
    StopEvent as InternalStopEvent,
    TextDeltaEvent,
    TextEvent,
    ThinkingDeltaEvent,
    ToolCallStartEvent,
)
from comate_agent_sdk.facade._internals.adapters import (
    _filter_events,
    _filter_events_new,
)
from comate_agent_sdk.facade.core.events import StopEvent
from comate_agent_sdk.facade.events import DoneEvent


async def _aiter(items: list[AgentEvent]) -> AsyncIterator[AgentEvent]:
    for it in items:
        yield it


def _streaming_event_sequence() -> list[AgentEvent]:
    return [
        SessionInitEvent(session_id="sess-1"),
        ThinkingDeltaEvent(delta="hmm", message_id="m1"),
        TextDeltaEvent(delta="he", message_id="m1"),
        TextDeltaEvent(delta="llo", message_id="m1"),
        ToolCallStartEvent(tool_call_id="tc1", tool="Read"),
        TextEvent(content="hello"),
        InternalStopEvent(reason="completed"),
    ]


class TestIncludePartialMessagesNew(unittest.TestCase):
    """新 API（_filter_events_new，对应 Agent.run_message / run_agent）。"""

    def test_default_drops_partial_events(self) -> None:
        async def collect() -> list:
            return [
                ev
                async for ev in _filter_events_new(
                    _aiter(_streaming_event_sequence())
                )
            ]

        events = asyncio.run(collect())
        # 三个 delta 事件都应被静默丢弃
        for ev in events:
            self.assertNotIsInstance(ev, (TextDeltaEvent, ThinkingDeltaEvent, ToolCallStartEvent))
        # final TextEvent + StopEvent + SessionInitEvent 三件套保留
        self.assertTrue(any(isinstance(ev, TextEvent) for ev in events))
        self.assertTrue(any(isinstance(ev, SessionInitEvent) for ev in events))
        self.assertTrue(any(isinstance(ev, StopEvent) for ev in events))

    def test_flag_on_passes_partial_events(self) -> None:
        async def collect() -> list:
            return [
                ev
                async for ev in _filter_events_new(
                    _aiter(_streaming_event_sequence()),
                    include_partial_messages=True,
                )
            ]

        events = asyncio.run(collect())
        delta_events = [
            ev for ev in events
            if isinstance(ev, (TextDeltaEvent, ThinkingDeltaEvent, ToolCallStartEvent))
        ]
        # 三个 delta 事件全部透传，顺序保留
        self.assertEqual(len(delta_events), 4)
        self.assertIsInstance(delta_events[0], ThinkingDeltaEvent)
        self.assertIsInstance(delta_events[1], TextDeltaEvent)
        self.assertIsInstance(delta_events[2], TextDeltaEvent)
        self.assertIsInstance(delta_events[3], ToolCallStartEvent)


class TestIncludePartialMessagesLegacy(unittest.TestCase):
    """Legacy API（_filter_events，对应 AgentClient.chat / query）。"""

    def test_default_drops_partial_events(self) -> None:
        async def collect() -> list:
            return [
                ev
                async for ev in _filter_events(_aiter(_streaming_event_sequence()))
            ]

        events = asyncio.run(collect())
        for ev in events:
            self.assertNotIsInstance(ev, (TextDeltaEvent, ThinkingDeltaEvent, ToolCallStartEvent))
        self.assertTrue(any(isinstance(ev, TextEvent) for ev in events))
        self.assertTrue(any(isinstance(ev, DoneEvent) for ev in events))

    def test_flag_on_passes_partial_events(self) -> None:
        async def collect() -> list:
            return [
                ev
                async for ev in _filter_events(
                    _aiter(_streaming_event_sequence()),
                    include_partial_messages=True,
                )
            ]

        events = asyncio.run(collect())
        delta_events = [
            ev for ev in events
            if isinstance(ev, (TextDeltaEvent, ThinkingDeltaEvent, ToolCallStartEvent))
        ]
        self.assertEqual(len(delta_events), 4)


if __name__ == "__main__":
    unittest.main()
