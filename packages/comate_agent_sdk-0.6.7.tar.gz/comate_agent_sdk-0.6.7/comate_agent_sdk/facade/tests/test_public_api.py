"""facade `Agent` 公共 API 契约测试。

防止"docs/facade/02-extended-api.md 承诺的方法没在代码里暴露"这类回归。
任何对 `Agent` 公共面（方法/属性）的增删，都必须同步更新本文件的期望集合
和文档，使三者保持一致。
"""

from __future__ import annotations

import unittest
from unittest.mock import AsyncMock, MagicMock

from comate_agent_sdk.facade.core.agent import Agent


# ---------------------------------------------------------------------------
# 公共面契约：与 docs/facade/02-extended-api.md 对齐。
# ---------------------------------------------------------------------------

EXPECTED_PUBLIC_METHODS = frozenset(
    {
        "register_hook",
        "run_message",
        "shutdown",
        "clear_history",
        "compact_conversation",
        "interrupt",
    }
)

EXPECTED_PUBLIC_PROPERTIES = frozenset(
    {
        "is_running",
    }
)


class TestAgentPublicSurface(unittest.TestCase):
    """公共属性集合契约测试（无需 IO，只看类对象）。"""

    def test_required_public_methods_are_exposed(self) -> None:
        public_attrs = {name for name in dir(Agent) if not name.startswith("_")}
        callables = {
            name
            for name in public_attrs
            if callable(getattr(Agent, name, None))
            and not isinstance(getattr(Agent, name, None), property)
        }
        missing = EXPECTED_PUBLIC_METHODS - callables
        self.assertFalse(
            missing,
            f"facade Agent 缺失文档承诺的公共方法: {sorted(missing)}。"
            f" 若有意删除，请同步更新 docs/facade/02-extended-api.md 与本测试。",
        )

    def test_required_public_properties_are_exposed(self) -> None:
        properties = {
            name
            for name in dir(Agent)
            if not name.startswith("_") and isinstance(getattr(Agent, name, None), property)
        }
        missing = EXPECTED_PUBLIC_PROPERTIES - properties
        self.assertFalse(
            missing,
            f"facade Agent 缺失文档承诺的公共属性: {sorted(missing)}",
        )

    def test_no_unexpected_public_attrs(self) -> None:
        """新增公共方法/属性时强制更新期望集合，避免悄悄扩面。"""
        public_attrs = {name for name in dir(Agent) if not name.startswith("_")}
        public_attrs -= {
            name for name in public_attrs if not callable(getattr(Agent, name, None))
            and not isinstance(getattr(Agent, name, None), property)
        }
        unexpected = public_attrs - EXPECTED_PUBLIC_METHODS - EXPECTED_PUBLIC_PROPERTIES
        self.assertFalse(
            unexpected,
            f"facade Agent 暴露了未在期望集合中的公共成员: {sorted(unexpected)}。"
            f" 若是有意新增，请同步在 docs/facade/02-extended-api.md 增加文档"
            f" 并更新本测试的 EXPECTED_PUBLIC_METHODS / EXPECTED_PUBLIC_PROPERTIES。",
        )


# ---------------------------------------------------------------------------
# 转发行为契约：facade 方法必须把调用真正委托给底层 ChatSession。
# ---------------------------------------------------------------------------


class TestClearHistoryForwarding(unittest.IsolatedAsyncioTestCase):
    """clear_history 必须是 async，且把同步调用转发到底层 ChatSession.clear_history。"""

    async def test_clear_history_forwards_to_chat_session(self) -> None:
        agent = Agent()
        mock_session = MagicMock()
        mock_session.clear_history = MagicMock(return_value=None)
        agent._chat_session = mock_session  # 跳过 _ensure_initialized

        result = await agent.clear_history()

        self.assertIsNone(result)
        mock_session.clear_history.assert_called_once_with()

    async def test_clear_history_propagates_underlying_exception(self) -> None:
        """底层抛出的领域异常应原样冒上来，facade 不吞错也不再封装。"""

        class _Boom(RuntimeError):
            pass

        agent = Agent()
        mock_session = MagicMock()
        mock_session.clear_history = MagicMock(side_effect=_Boom("session closed"))
        agent._chat_session = mock_session

        with self.assertRaises(_Boom):
            await agent.clear_history()


class TestCompactConversationForwarding(unittest.IsolatedAsyncioTestCase):
    """compact_conversation 必须 await 底层 compact_context_manual 并透传返回值。"""

    async def test_compact_conversation_awaits_and_returns_result(self) -> None:
        agent = Agent()
        mock_session = MagicMock()
        sentinel = object()
        mock_session.compact_context_manual = AsyncMock(return_value=sentinel)
        agent._chat_session = mock_session

        result = await agent.compact_conversation()

        self.assertIs(
            result,
            sentinel,
            "compact_conversation 必须透传底层返回值（ManualCompactionResult），"
            "不要丢弃，否则调用方无法判断是否真正发生压缩。",
        )
        mock_session.compact_context_manual.assert_awaited_once_with()


if __name__ == "__main__":
    unittest.main(verbosity=2)
