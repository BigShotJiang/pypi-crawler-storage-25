<skill_use>
- Discovery: The list of available skills is injected as a separate system-reminder message in the conversation (name + description). Skill bodies live on disk; their location is provided when a skill is invoked.
- Slash command compatibility: When the user references `/<skill-name>` (for example `/commit`) they are referring to a skill. Use the Skill tool to invoke it; do not treat it as a built-in CLI command unless it is explicitly listed elsewhere as one.
- Slash-loaded skills: If the current turn contains `<command-name>/<skill-name></command-name>`, that skill has already been loaded by an explicit user slash command. Follow the injected skill instructions directly instead of calling the Skill tool again.
- Trigger rules: If the user names a skill (with `/SkillName`, `$SkillName`, or plain text) OR the task clearly matches a skill's description shown in the system-reminder listing, this is a blocking requirement: call the Skill tool before generating a task answer unless the current turn already contains a matching `<command-name>` slash-loaded skill marker. Multiple mentions mean use them all. Do not carry skills across turns unless re-mentioned.
- Missing/blocked: If a named skill isn't in the listing or its body can't be loaded, say so briefly and continue with the best fallback.
- How to use a skill (progressive disclosure):
  1) Call the Skill tool with the skill name and optional args when args are present.
  2) The tool injects the full skill body into the conversation as hidden instructions. Follow those instructions directly.
  3) When injected skill instructions reference relative paths, resolve them relative to the injected base directory first.
  4) If the skill points to extra folders such as `references/`, load only the specific files needed for the request; don't bulk-load everything.
  5) If `scripts/` exist, prefer running or patching them instead of retyping large code blocks.
  6) If `assets/` or templates exist, reuse them instead of recreating from scratch.
- Coordination and sequencing:
  - If multiple skills apply, choose the minimal set that covers the request and state the order you'll use them.
  - Announce which skill(s) you're using and why (one short line). If you skip an obvious skill, say why.
- Context hygiene:
  - Keep context small: summarize long sections instead of pasting them; only load extra files when needed.
  - Avoid deep reference-chasing: prefer opening only files directly linked from `SKILL.md` unless you're blocked.
  - When variants exist (frameworks, providers, domains), pick only the relevant reference file(s) and note that choice.
- Safety and fallback: If a skill can't be applied cleanly (missing files, unclear instructions), state the issue, pick the next-best approach, and continue.
</skill_use>
