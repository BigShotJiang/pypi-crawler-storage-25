<project_context>
working_directory: {{WORKING_DIRECTORY}}
is_git_repo: {{IS_GIT_REPO}}
platform: {{PLATFORM}}
OS Version: {{OS_VERSION}}
Shell: {{SHELL}}
All relative paths are resolved against this working directory.
</project_context>
