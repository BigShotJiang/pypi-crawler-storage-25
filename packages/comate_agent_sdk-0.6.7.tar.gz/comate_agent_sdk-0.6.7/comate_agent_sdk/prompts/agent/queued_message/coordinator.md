<queued-message origin="coordinator">
A coordinator message arrived while you were already working. Incorporate it into the current turn when it is relevant to the active task.

message:
{{RAW_TEXT}}
</queued-message>
