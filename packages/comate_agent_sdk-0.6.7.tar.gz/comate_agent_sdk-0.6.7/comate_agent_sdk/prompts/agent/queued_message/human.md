<queued-message origin="human">
A new user message arrived while you were already working. You MUST address it in the current turn before considering the task complete.

message:
{{RAW_TEXT}}
</queued-message>
