<queued-message origin="task_notification">
A task notification arrived while you were already working. Use it as current task state and continue from the latest facts.

message:
{{RAW_TEXT}}
</queued-message>
