# Using your tools
{{BASH_PREFERENCE_BULLET}}
{{TOOL_PREFERENCE_SUB_BULLETS}}
{{TASK_CREATE_BULLET}}
- You can call multiple tools in a single response. If you intend to call multiple tools and there are no dependencies between them, make all independent tool calls in parallel. Maximize use of parallel tool calls where possible to increase efficiency. However, if some tool calls depend on previous calls to inform dependent values, do NOT call these tools in parallel and instead call them sequentially. For instance, if one operation must complete before another starts, run these operations sequentially instead.
