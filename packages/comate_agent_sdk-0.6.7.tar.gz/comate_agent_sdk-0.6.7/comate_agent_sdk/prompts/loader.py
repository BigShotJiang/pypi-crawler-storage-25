from __future__ import annotations

import re
from collections.abc import Mapping
from importlib.resources import files
from pathlib import PurePosixPath

_PROMPTS_PACKAGE = "comate_agent_sdk.prompts"
_PROMPT_VARIABLE_PATTERN = re.compile(r"{{\s*([A-Za-z_][A-Za-z0-9_]*)\s*}}")


def _normalize_prompt_id(prompt_id: str) -> str:
    normalized = PurePosixPath(str(prompt_id or "").strip())
    if not normalized.parts:
        raise ValueError("prompt_id must not be empty")
    if normalized.is_absolute() or ".." in normalized.parts:
        raise ValueError(f"prompt_id must stay within prompts package: {prompt_id!r}")
    return normalized.as_posix()


def load_prompt(prompt_id: str, *, strip: bool = True) -> str:
    """从 SDK 包内 prompts 目录加载 markdown 文本。"""
    normalized_prompt_id = _normalize_prompt_id(prompt_id)
    resource = files(_PROMPTS_PACKAGE).joinpath(*normalized_prompt_id.split("/"))
    if not resource.is_file():
        raise FileNotFoundError(
            f"Prompt resource not found: {_PROMPTS_PACKAGE}/{normalized_prompt_id}"
        )

    content = resource.read_text(encoding="utf-8")
    if strip:
        return content.strip()
    return content


def render_prompt(
    template: str,
    *,
    variables: Mapping[str, object] | None = None,
    source: str | None = None,
) -> str:
    """渲染 prompt 模板中的 `{{NAME}}` 占位符。"""
    prompt_text = str(template or "")
    if not prompt_text:
        return ""

    provided_variables = dict(variables or {})
    referenced_names = {
        match.group(1)
        for match in _PROMPT_VARIABLE_PATTERN.finditer(prompt_text)
    }
    missing_names = sorted(
        name
        for name in referenced_names
        if name not in provided_variables or provided_variables[name] is None
    )
    if missing_names:
        source_name = str(source or "<inline prompt>")
        raise ValueError(
            f"Missing prompt variables for {source_name}: {', '.join(missing_names)}"
        )

    def _replace(match: re.Match[str]) -> str:
        variable_name = match.group(1)
        return str(provided_variables[variable_name])

    return _PROMPT_VARIABLE_PATTERN.sub(_replace, prompt_text)


def normalize_section_text(text: str) -> str:
    """规范化 header section 文本。

    规则：
    1. 去首尾空白
    2. 折叠 3 个以上连续换行为 2 个（一个空行）
    3. 顶级 `# Title`（单个 `#`）与其首条正文之间不保留空行；
       `## / ###` 等次级标题不受影响

    注：section 之间的空行由上层 `"\n\n".join(...)` 保证；本函数仅处理
    段内标题—正文的紧挨关系。
    """
    stripped = str(text or "").strip()
    if not stripped:
        return ""

    # 先折叠 3+ 换行到一个空行，再去掉顶级 # 标题后的空行
    collapsed = re.sub(r"\n{3,}", "\n\n", stripped)
    collapsed = re.sub(r"(^|\n)(# [^\n]*)\n\n+", r"\1\2\n", collapsed)
    return collapsed
