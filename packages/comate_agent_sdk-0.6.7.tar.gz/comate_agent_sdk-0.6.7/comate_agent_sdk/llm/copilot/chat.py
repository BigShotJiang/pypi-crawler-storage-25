from __future__ import annotations

import asyncio
import json
import logging
import os
import random
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from types import SimpleNamespace
from typing import Any, Literal

import httpx

from comate_agent_sdk.llm.base import BaseChatModel, ToolChoice, ToolDefinition
from comate_agent_sdk.llm.exceptions import ModelProviderError, ModelRateLimitError
from comate_agent_sdk.llm.messages import (
    BaseMessage,
    ContentPartTextParam,
    ContentPartThinkingParam,
    Function,
    ToolCall,
)
from comate_agent_sdk.llm.model_presets import get_model_preset
from comate_agent_sdk.llm.openai.serializer import OpenAIMessageSerializer
from comate_agent_sdk.llm.stream_state import OpenAIStreamState
from comate_agent_sdk.llm.views import ChatInvokeCompletion, ChatInvokeUsage
from comate_agent_sdk.tokens.custom_pricing import resolve_max_input_tokens_from_custom_pricing

logger = logging.getLogger("comate_agent_sdk.llm.copilot")

_DEFAULT_GITHUB_API = "https://api.github.com"
_DEFAULT_COPILOT_API = "https://api.githubcopilot.com"
_TOKEN_EXCHANGE_PATH = "/copilot_internal/v2/token"
_CHAT_COMPLETIONS_PATH = "/chat/completions"
_EDITOR_VERSION = "OpenCode/1.0"
_COPILOT_INTEGRATION_ID = "vscode-chat"
_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


def _sse_json_to_chunk(obj: dict[str, Any]) -> SimpleNamespace:
    choices: list[SimpleNamespace] = []
    for raw_choice in obj.get("choices", []) or []:
        if not isinstance(raw_choice, dict):
            continue
        delta = raw_choice.get("delta") or {}
        if not isinstance(delta, dict):
            delta = {}
        tool_calls = None
        raw_tool_calls = delta.get("tool_calls")
        if isinstance(raw_tool_calls, list):
            tool_calls = []
            for raw_tool_call in raw_tool_calls:
                if not isinstance(raw_tool_call, dict):
                    continue
                raw_function = raw_tool_call.get("function") or {}
                if not isinstance(raw_function, dict):
                    raw_function = {}
                tool_calls.append(
                    SimpleNamespace(
                        index=int(raw_tool_call.get("index") or 0),
                        id=raw_tool_call.get("id"),
                        type=raw_tool_call.get("type"),
                        function=SimpleNamespace(
                            name=raw_function.get("name"),
                            arguments=raw_function.get("arguments") or "",
                        ),
                    )
                )
        choices.append(
            SimpleNamespace(
                delta=SimpleNamespace(
                    content=delta.get("content"),
                    reasoning_content=delta.get("reasoning_content"),
                    tool_calls=tool_calls,
                ),
                finish_reason=raw_choice.get("finish_reason"),
            )
        )

    usage = None
    raw_usage = obj.get("usage")
    if isinstance(raw_usage, dict):
        prompt_details = raw_usage.get("prompt_tokens_details") or {}
        if not isinstance(prompt_details, dict):
            prompt_details = {}
        completion_details = raw_usage.get("completion_tokens_details")
        if isinstance(completion_details, dict):
            completion_details_obj = SimpleNamespace(
                reasoning_tokens=completion_details.get("reasoning_tokens", 0)
            )
        else:
            completion_details_obj = None
        usage = SimpleNamespace(
            prompt_tokens=int(raw_usage.get("prompt_tokens") or 0),
            prompt_tokens_details=SimpleNamespace(
                cached_tokens=prompt_details.get("cached_tokens", 0)
            ),
            completion_tokens=int(raw_usage.get("completion_tokens") or 0),
            completion_tokens_details=completion_details_obj,
            total_tokens=int(raw_usage.get("total_tokens") or 0),
        )

    return SimpleNamespace(choices=choices, usage=usage)


@dataclass
class ChatCopilot(BaseChatModel):
    """GitHub Copilot Plan provider based on GitHub token exchange + chat completions."""

    model: str

    api_key: str | None = None
    base_url: str | httpx.URL | None = _DEFAULT_COPILOT_API
    github_api_url: str | httpx.URL | None = _DEFAULT_GITHUB_API
    timeout: float | httpx.Timeout | None = 60.0
    max_retries: int = 5

    temperature: float | None = 0.1
    frequency_penalty: float | None = 0.3
    top_p: float | None = None
    max_completion_tokens: int | None = 16384
    reasoning_effort: Literal["low", "medium", "high"] = "low"
    reasoning_models: list[str] | None = field(
        default_factory=lambda: [
            "o4-mini",
            "o3",
            "o3-mini",
            "o1",
            "o1-pro",
            "o3-pro",
            "gpt-5",
            "gpt-5-mini"
        ]
    )
    parallel_tool_calls: bool = True

    _bearer_token: str | None = field(default=None, init=False, repr=False)
    _bearer_expires_at: int | None = field(default=None, init=False, repr=False)

    @property
    def provider(self) -> str:
        return "copilot"

    @property
    def name(self) -> str:
        return str(self.model)

    def get_context_window(self) -> int | None:
        return resolve_max_input_tokens_from_custom_pricing(str(self.model))

    def _get_github_token(self) -> str:
        token = (self.api_key or os.getenv("GITHUB_TOKEN", "")).strip()
        if not token:
            raise ModelProviderError(
                message="GitHub token is missing. Set GITHUB_TOKEN or settings llm_levels_api_key.",
                status_code=401,
                model=self.name,
            )
        return token

    def _token_exchange_url(self) -> str:
        base = str(self.github_api_url or _DEFAULT_GITHUB_API).rstrip("/")
        return f"{base}{_TOKEN_EXCHANGE_PATH}"

    def _chat_url(self) -> str:
        base = str(self.base_url or _DEFAULT_COPILOT_API).rstrip("/")
        return f"{base}{_CHAT_COMPLETIONS_PATH}"

    def _build_exchange_headers(self, github_token: str) -> dict[str, str]:
        return {
            "Authorization": f"Token {github_token}",
            "User-Agent": _EDITOR_VERSION,
            "Accept": "application/json",
        }

    def _build_chat_headers(self, bearer: str) -> dict[str, str]:
        # Keep headers aligned with OpenCode behavior:
        # no explicit User-Agent for chat completions.
        return {
            "Authorization": f"Bearer {bearer}",
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Editor-Version": _EDITOR_VERSION,
            "Editor-Plugin-Version": _EDITOR_VERSION,
            "Copilot-Integration-Id": _COPILOT_INTEGRATION_ID,
        }

    async def _http_get(self, *, url: str, headers: dict[str, str]) -> httpx.Response:
        async with httpx.AsyncClient(timeout=self.timeout, verify=False) as client:
            return await client.get(url, headers=headers)

    async def _http_post(
        self,
        *,
        url: str,
        headers: dict[str, str],
        payload: dict[str, Any],
    ) -> httpx.Response:
        async with httpx.AsyncClient(timeout=self.timeout, verify=False) as client:
            return await client.post(url, headers=headers, json=payload)

    def _truncate(self, text: str, max_chars: int = 800) -> str:
        if len(text) <= max_chars:
            return text
        return f"{text[:max_chars]}..."

    async def exchange_bearer(self) -> str:
        github_token = self._get_github_token()
        response = await self._http_get(
            url=self._token_exchange_url(),
            headers=self._build_exchange_headers(github_token),
        )
        if response.status_code != 200:
            message = self._truncate(response.text, max_chars=500)
            raise ModelProviderError(
                message=f"token exchange failed: {response.status_code} {message}",
                status_code=response.status_code,
                model=self.name,
            )

        try:
            data = response.json()
        except Exception as exc:
            raise ModelProviderError(
                message=f"token exchange returned invalid json: {exc}",
                status_code=502,
                model=self.name,
            ) from exc

        token = str(data.get("token") or "").strip()
        if not token:
            raise ModelProviderError(
                message=f"missing token in exchange response: {data}",
                status_code=502,
                model=self.name,
            )

        expires_at = data.get("expires_at")
        self._bearer_token = token
        self._bearer_expires_at = expires_at if isinstance(expires_at, int) else None
        return token

    def _should_refresh_bearer(self) -> bool:
        if not self._bearer_token:
            return True
        if self._bearer_expires_at is None:
            return False
        return time.time() > (self._bearer_expires_at - 60)

    async def _get_bearer(self) -> str:
        if self._should_refresh_bearer():
            return await self.exchange_bearer()
        return str(self._bearer_token)

    async def _sleep_backoff(self, attempt: int, response: httpx.Response) -> None:
        retry_after = response.headers.get("Retry-After")
        if retry_after:
            try:
                await asyncio.sleep(float(retry_after))
                return
            except ValueError:
                pass

        base = 0.5 * (2 ** (attempt - 1))
        jitter = random.random() * 0.5
        await asyncio.sleep(min(20.0, base + jitter))

    def _make_strict_property(self, prop: dict[str, Any], is_required: bool) -> dict[str, Any]:
        result = dict(prop)

        if result.get("type") == "object" and "properties" in result:
            result = self._make_strict_schema(result)

        if result.get("type") == "array" and isinstance(result.get("items"), dict):
            items = result["items"]
            if items.get("type") == "object" and "properties" in items:
                result["items"] = self._make_strict_schema(items)

        if not is_required:
            if "type" in result:
                result["type"] = [result["type"], "null"]
            elif "anyOf" not in result:
                result["anyOf"] = [result, {"type": "null"}]

        return result

    def _make_strict_schema(self, schema: dict[str, Any]) -> dict[str, Any]:
        result = dict(schema)
        properties = dict(result.get("properties") or {})
        required = set(result.get("required") or [])

        strict_properties: dict[str, Any] = {}
        for name, prop in properties.items():
            if not isinstance(prop, dict):
                strict_properties[name] = prop
                continue
            strict_properties[name] = self._make_strict_property(prop, name in required)

        result["properties"] = strict_properties
        result["required"] = list(properties.keys())
        result["additionalProperties"] = False
        return result

    def _serialize_tools(self, tools: list[ToolDefinition]) -> list[dict[str, Any]]:
        serialized: list[dict[str, Any]] = []
        for tool in tools:
            params = tool.parameters
            if tool.strict and isinstance(params, dict) and params.get("properties"):
                params = self._make_strict_schema(params)

            serialized.append(
                {
                    "type": "function",
                    "function": {
                        "name": tool.name,
                        "description": tool.description,
                        "parameters": params,
                        "strict": tool.strict,
                    },
                }
            )
        return serialized

    def _get_tool_choice(self, tool_choice: ToolChoice | None, tools: list[ToolDefinition] | None) -> Any:
        if tool_choice is None or tools is None:
            return None
        if tool_choice == "auto":
            return "auto"
        if tool_choice == "required":
            return "required"
        if tool_choice == "none":
            return "none"
        return {"type": "function", "function": {"name": tool_choice}}

    def _extract_tool_calls(self, message: dict[str, Any]) -> list[ToolCall]:
        tool_calls: list[ToolCall] = []
        raw_tool_calls = message.get("tool_calls") or []
        if not isinstance(raw_tool_calls, list):
            return tool_calls

        for item in raw_tool_calls:
            if not isinstance(item, dict):
                continue
            tool_call_id = str(item.get("id") or "").strip()
            function_obj = item.get("function") or {}
            if not isinstance(function_obj, dict):
                continue
            function_name = str(function_obj.get("name") or "").strip()
            arguments = function_obj.get("arguments", "{}")
            if not isinstance(arguments, str):
                arguments = json.dumps(arguments, ensure_ascii=False)
            if not tool_call_id or not function_name:
                continue
            tool_calls.append(
                ToolCall(
                    id=tool_call_id,
                    function=Function(name=function_name, arguments=arguments),
                    type="function",
                )
            )
        return tool_calls

    def _extract_usage(self, data: dict[str, Any]) -> ChatInvokeUsage | None:
        usage = data.get("usage")
        if not isinstance(usage, dict):
            return None

        prompt_tokens = int(usage.get("prompt_tokens") or 0)
        completion_tokens = int(usage.get("completion_tokens") or 0)
        total_tokens = int(usage.get("total_tokens") or (prompt_tokens + completion_tokens))

        prompt_cached_tokens: int | None = None
        prompt_tokens_details = usage.get("prompt_tokens_details")
        if isinstance(prompt_tokens_details, dict):
            cached = prompt_tokens_details.get("cached_tokens")
            if isinstance(cached, int):
                prompt_cached_tokens = cached

        reasoning_tokens: int | None = 0
        completion_tokens_details = usage.get("completion_tokens_details")
        if isinstance(completion_tokens_details, dict):
            reasoning = completion_tokens_details.get("reasoning_tokens")
            if isinstance(reasoning, int):
                reasoning_tokens = reasoning

        return ChatInvokeUsage(
            prompt_tokens=prompt_tokens,
            prompt_cached_tokens=prompt_cached_tokens,
            prompt_cache_creation_tokens=None,
            prompt_image_tokens=None,
            completion_tokens=completion_tokens,
            reasoning_tokens=reasoning_tokens,
            total_tokens=total_tokens,
        )

    def _extract_text_content(self, message: dict[str, Any]) -> str | None:
        content = message.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts: list[str] = []
            for item in content:
                if isinstance(item, dict) and item.get("type") == "text":
                    text = item.get("text")
                    if isinstance(text, str):
                        parts.append(text)
            if parts:
                return "".join(parts)
        return None

    def _build_completion(self, data: dict[str, Any]) -> ChatInvokeCompletion:
        choices = data.get("choices")
        if not isinstance(choices, list) or not choices:
            raise ModelProviderError(
                message=f"chat response missing choices: {data}",
                status_code=502,
                model=self.name,
            )

        first = choices[0]
        if not isinstance(first, dict):
            raise ModelProviderError(
                message=f"chat response malformed first choice: {first}",
                status_code=502,
                model=self.name,
            )

        message = first.get("message")
        if not isinstance(message, dict):
            raise ModelProviderError(
                message=f"chat response missing message: {first}",
                status_code=502,
                model=self.name,
            )

        content = self._extract_text_content(message)
        reasoning_content = message.get("reasoning_content")
        if not isinstance(reasoning_content, str):
            reasoning_content = None

        raw_content_blocks = None
        if reasoning_content:
            blocks: list[ContentPartThinkingParam | ContentPartTextParam] = [
                ContentPartThinkingParam(thinking=reasoning_content, signature=None)
            ]
            if content:
                blocks.append(ContentPartTextParam(text=content))
            raw_content_blocks = blocks

        return ChatInvokeCompletion(
            content=content,
            thinking=reasoning_content,
            raw_content_blocks=raw_content_blocks,
            tool_calls=self._extract_tool_calls(message),
            usage=self._extract_usage(data),
            stop_reason=str(first.get("finish_reason") or "") or None,
        )

    def _raise_response_error(self, response: httpx.Response, *, prefix: str) -> None:
        message = self._truncate(response.text, max_chars=800)
        if response.status_code == 429:
            raise ModelRateLimitError(
                message=f"{prefix}: {response.status_code} {message}",
                status_code=response.status_code,
                model=self.name,
            )
        raise ModelProviderError(
            message=f"{prefix}: {response.status_code} {message}",
            status_code=response.status_code,
            model=self.name,
        )

    def _build_chat_payload(
        self,
        messages: list[BaseMessage],
        tools: list[ToolDefinition] | None = None,
        tool_choice: ToolChoice | None = None,
        *,
        stream: bool = False,
    ) -> dict[str, Any]:
        openai_messages = OpenAIMessageSerializer.serialize_messages(messages)
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": openai_messages,
            "stream": stream,
        }
        if stream:
            payload["stream_options"] = {"include_usage": True}

        if self.temperature is not None:
            payload["temperature"] = self.temperature
        if self.frequency_penalty is not None:
            payload["frequency_penalty"] = self.frequency_penalty
        if self.top_p is not None:
            payload["top_p"] = self.top_p
        if self.max_completion_tokens is not None:
            payload["max_tokens"] = self.max_completion_tokens

        preset = get_model_preset(str(self.model))
        is_reasoning = preset.supports_thinking and preset.effort is not None
        if not is_reasoning and self.reasoning_models:
            is_reasoning = any(
                str(model_name).lower() in str(self.model).lower()
                for model_name in self.reasoning_models
            )
        if is_reasoning:
            payload["reasoning_effort"] = (
                preset.effort if preset.effort is not None else self.reasoning_effort
            )
            payload.pop("temperature", None)
            payload.pop("frequency_penalty", None)

        if preset.openai_extra_body:
            payload["extra_body"] = dict(preset.openai_extra_body)

        if tools:
            payload["tools"] = self._serialize_tools(tools)
            payload["parallel_tool_calls"] = self.parallel_tool_calls
            resolved_tool_choice = self._get_tool_choice(tool_choice, tools)
            if resolved_tool_choice is not None:
                payload["tool_choice"] = resolved_tool_choice

        return payload

    async def _http_post_stream(
        self,
        *,
        url: str,
        headers: dict[str, str],
        payload: dict[str, Any],
    ) -> AsyncIterator[Any]:
        async with httpx.AsyncClient(timeout=self.timeout, verify=False) as client:
            async with client.stream(
                "POST",
                url,
                headers=headers,
                json=payload,
            ) as response:
                if response.status_code >= 400:
                    await response.aread()
                    self._raise_response_error(
                        response,
                        prefix="chat stream failed",
                    )
                async for line in response.aiter_lines():
                    if not line:
                        continue
                    if not line.startswith("data:"):
                        continue
                    data = line[len("data:"):].strip()
                    if data == "[DONE]":
                        break
                    try:
                        obj = json.loads(data)
                    except json.JSONDecodeError:
                        logger.debug("Skipping invalid Copilot SSE frame: %s", data)
                        continue
                    yield _sse_json_to_chunk(obj)

    async def astream(
        self,
        messages: list[BaseMessage],
        tools: list[ToolDefinition] | None = None,
        tool_choice: ToolChoice | None = None,
        **kwargs: Any,
    ):
        payload = self._build_chat_payload(
            messages,
            tools,
            tool_choice,
            stream=True,
        )
        bearer = await self._get_bearer()
        headers = self._build_chat_headers(bearer)
        url = self._chat_url()

        cancel_event: asyncio.Event | None = kwargs.get("cancel_event")
        async for chunk in self._http_post_stream(
            url=url,
            headers=headers,
            payload=payload,
        ):
            if cancel_event is not None and cancel_event.is_set():
                raise asyncio.CancelledError("llm_cancel")
            yield chunk

    async def ainvoke(
        self,
        messages: list[BaseMessage],
        tools: list[ToolDefinition] | None = None,
        tool_choice: ToolChoice | None = None,
        **kwargs: Any,
    ) -> ChatInvokeCompletion:
        last_error: Exception | None = None
        for attempt in range(1, self.max_retries + 1):
            state = OpenAIStreamState()
            first_chunk_seen = False
            try:
                async for chunk in self.astream(messages, tools, tool_choice, **kwargs):
                    first_chunk_seen = True
                    state.ingest(chunk)
                completion = state.finalize()
                if completion.usage and os.getenv("comate_agent_sdk_LLM_DEBUG"):
                    cached = completion.usage.prompt_cached_tokens or 0
                    input_tokens = completion.usage.prompt_tokens - cached
                    logger.info(
                        f"{self.model}: {input_tokens:,} in + "
                        f"{cached:,} cached + {completion.usage.completion_tokens:,} out"
                    )
                return completion
            except ModelRateLimitError as exc:
                last_error = exc
                if not first_chunk_seen and attempt < self.max_retries:
                    await asyncio.sleep(min(2 ** attempt, 10))
                    continue
                raise
            except ModelProviderError as exc:
                last_error = exc
                if (
                    not first_chunk_seen
                    and exc.status_code == 401
                    and attempt < self.max_retries
                ):
                    await self.exchange_bearer()
                    continue
                if (
                    not first_chunk_seen
                    and exc.status_code in _RETRYABLE_STATUS_CODES
                    and attempt < self.max_retries
                ):
                    await asyncio.sleep(min(2 ** attempt, 10))
                    continue
                raise

        if last_error is not None:
            raise last_error
        raise ModelProviderError(
            message=f"chat failed after retries (max_retries={self.max_retries})",
            status_code=502,
            model=self.name,
        )
