"""ChatDeepSeek: DeepSeek LLM integration with thinking mode support.

DeepSeek API specifics:
- Uses OpenAI-compatible protocol
- Supports thinking mode via `reasoning_content` field in responses
- Requires `reasoning_content` to be preserved in tool call loops (same turn)
- Recommends cleaning historical `reasoning_content` on new turns for bandwidth optimization
"""

import asyncio
import logging
import os
from contextlib import suppress
from dataclasses import dataclass, field
from typing import Any

from openai import APIConnectionError, APIStatusError, RateLimitError
from openai.types.chat.chat_completion import ChatCompletion

from comate_agent_sdk.llm.base import ToolChoice, ToolDefinition
from comate_agent_sdk.llm.deepseek.serializer import DeepSeekMessageSerializer
from comate_agent_sdk.llm.messages import (
    BaseMessage,
    ContentPartTextParam,
    ContentPartThinkingParam,
)
from comate_agent_sdk.llm.exceptions import ModelProviderError, ModelRateLimitError
from comate_agent_sdk.llm.openai.like import ChatOpenAILike
from comate_agent_sdk.llm.stream_state import OpenAIStreamState
from comate_agent_sdk.llm.views import ChatInvokeCompletion, ChatInvokeUsage
from comate_agent_sdk.tokens.custom_pricing import resolve_max_input_tokens_from_custom_pricing

logger = logging.getLogger("comate_agent_sdk.llm.deepseek")


@dataclass
class ChatDeepSeek(ChatOpenAILike):
    """
    DeepSeek LLM client with thinking mode (reasoning_content) support.

    DeepSeek provides extended thinking capabilities through the `reasoning_content`
    field in API responses. This class maps it to the unified thinking infrastructure
    (ContentPartThinkingParam, raw_content_blocks) for consistent handling across
    providers.

    Key features:
    - Extracts `reasoning_content` from responses and maps to `thinking`
    - Preserves structured content blocks for tool call loops
    - Auto-cleans historical `reasoning_content` on new turns (bandwidth optimization)
    - Uses custom serializer to convert thinking blocks back to `reasoning_content`

    Example:
        ```python
        from comate_agent_sdk.llm.deepseek import ChatDeepSeek
        from comate_agent_sdk.llm.messages import UserMessage

        llm = ChatDeepSeek(
            model='deepseek-reasoner',
            api_key='...',
            base_url='https://api.deepseek.com'
        )

        response = await llm.ainvoke(
            messages=[UserMessage(content="Explain quantum computing")],
            tools=None
        )

        # Access thinking content
        if response.thinking:
            print(f"Model reasoning: {response.thinking}")
        print(f"Final answer: {response.content}")
        ```

    Args:
        model: DeepSeek model name (e.g., 'deepseek-chat', 'deepseek-reasoner')
        api_key: DeepSeek API key (defaults to DEEPSEEK_API_KEY env var)
        base_url: API endpoint (defaults to https://api.deepseek.com)
        auto_clean_reasoning: Auto-clean historical reasoning_content on new turns (default: True)
    """

    model: str
    auto_clean_reasoning: bool = True
    """Automatically remove reasoning_content from historical messages on new turns.

    DeepSeek recommends this to save bandwidth, as historical thinking is not needed
    for new requests. Only the current turn's reasoning_content is preserved.
    """

    # Override default reasoning models list (DeepSeek uses different naming)
    reasoning_models: list[str] | None = field(
        default_factory=lambda: ["deepseek-reasoner", "deepseek-v4-pro", "deepseek-v4-flash"]
    )

    @property
    def provider(self) -> str:
        return "deepseek"

    def get_context_window(self) -> int | None:
        """Resolve context window from custom pricing data when available."""
        return resolve_max_input_tokens_from_custom_pricing(str(self.model))

    def get_usage(self, response: "Any") -> ChatInvokeUsage | None:
        """Return usage statistics from a DeepSeek API response."""
        return self._get_usage(response)

    def _extract_reasoning_content(self, response: ChatCompletion) -> str | None:
        """Extract reasoning_content from DeepSeek API response.

        DeepSeek returns reasoning_content as an extra field in the message.
        We use getattr for safe access since it's not in the official OpenAI schema.

        Args:
            response: OpenAI ChatCompletion response

        Returns:
            Reasoning content string, or None if not present
        """
        message = response.choices[0].message
        return getattr(message, "reasoning_content", None)

    def _get_usage(self, response: Any) -> ChatInvokeUsage | None:
        """Extract usage statistics from DeepSeek response.

        DeepSeek uses different cache field names than OpenAI:
        - OpenAI: prompt_tokens_details.cached_tokens
        - DeepSeek: prompt_cache_hit_tokens, prompt_cache_miss_tokens

        Args:
            response: ChatCompletion response from DeepSeek API

        Returns:
            Usage statistics with DeepSeek-specific cache fields
        """
        if response.usage is None:
            return None

        # DeepSeek 的缓存字段（从 extra 中提取）
        prompt_cache_hit = getattr(response.usage, "prompt_cache_hit_tokens", None)
        prompt_cache_miss = getattr(response.usage, "prompt_cache_miss_tokens", None)

        # 计算总的 prompt tokens（命中 + 未命中）
        # 注意：DeepSeek 的 prompt_tokens 可能只包含未命中的部分
        # 需要根据实际 API 返回调整
        total_prompt_tokens = response.usage.prompt_tokens
        if prompt_cache_hit and prompt_cache_miss:
            # 如果两个字段都存在，使用它们的和
            total_prompt_tokens = prompt_cache_hit + prompt_cache_miss

        return ChatInvokeUsage(
            prompt_tokens=total_prompt_tokens,
            prompt_cached_tokens=prompt_cache_hit,  # DeepSeek 的缓存命中
            prompt_cache_creation_tokens=None,  # DeepSeek 不单独统计缓存创建
            prompt_image_tokens=None,
            reasoning_tokens=(
                getattr(
                    response.usage.completion_tokens_details,
                    "reasoning_tokens",
                    0,
                )
                if getattr(response.usage, "completion_tokens_details", None) is not None
                else 0
            ),
            completion_tokens=response.usage.completion_tokens,
            total_tokens=response.usage.total_tokens,
        )

    def normalize_stream_completion(
        self,
        response: ChatInvokeCompletion,
        last_raw_usage: "Any | None" = None,
    ) -> ChatInvokeCompletion:
        """在 streaming path 补偿 DeepSeek 的 cache-aware prompt_tokens 计算。

        stream_llm_events 使用通用 OpenAIStreamState，不会调用 _get_usage()。
        此方法通过 _normalize_stream_completion_for_llm 钩子被调用，接收原始
        usage 对象并重新应用 DeepSeek 特有的 cache 字段补偿逻辑。
        """
        updates: dict[str, Any] = {}

        if response.has_tool_calls:
            from comate_agent_sdk.llm.model_presets import get_model_preset

            if get_model_preset(str(self.model)).supports_thinking:
                raw_blocks = list(response.raw_content_blocks or [])
                has_thinking_block = any(
                    getattr(part, "type", None) == "thinking"
                    for part in raw_blocks
                )
                if not has_thinking_block:
                    raw_blocks.insert(
                        0,
                        ContentPartThinkingParam(
                            thinking=response.thinking or "",
                            signature=None,
                        ),
                    )
                    if response.content:
                        has_text_block = any(
                            getattr(part, "type", None) == "text"
                            for part in raw_blocks
                        )
                        if not has_text_block:
                            raw_blocks.append(ContentPartTextParam(text=response.content))
                updates["thinking"] = response.thinking or ""
                updates["raw_content_blocks"] = raw_blocks

        if last_raw_usage is None:
            return response.model_copy(update=updates) if updates else response
        corrected = self._get_usage_from_raw(last_raw_usage)
        if corrected is not None:
            updates["usage"] = corrected
        return response.model_copy(update=updates) if updates else response

    def _get_usage_from_raw(self, raw_usage: Any) -> ChatInvokeUsage | None:
        """从 streaming chunk 的原始 usage 对象中提取 DeepSeek usage。"""
        prompt_cache_hit = getattr(raw_usage, "prompt_cache_hit_tokens", None)
        prompt_cache_miss = getattr(raw_usage, "prompt_cache_miss_tokens", None)
        completion_tokens = int(getattr(raw_usage, "completion_tokens", 0) or 0)
        total_tokens = int(getattr(raw_usage, "total_tokens", 0) or 0)

        total_prompt_tokens = int(getattr(raw_usage, "prompt_tokens", 0) or 0)
        if prompt_cache_hit and prompt_cache_miss:
            total_prompt_tokens = prompt_cache_hit + prompt_cache_miss

        completion_details = getattr(raw_usage, "completion_tokens_details", None)
        reasoning_tokens = (
            getattr(completion_details, "reasoning_tokens", 0)
            if completion_details is not None
            else 0
        )

        return ChatInvokeUsage(
            prompt_tokens=total_prompt_tokens,
            prompt_cached_tokens=prompt_cache_hit,
            prompt_cache_creation_tokens=None,
            prompt_image_tokens=None,
            reasoning_tokens=reasoning_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
        )

    def _build_structured_content(
        self, reasoning_content: str | None, text_content: str | None
    ) -> list[ContentPartThinkingParam | ContentPartTextParam] | None:
        """Build structured content blocks (thinking + text).

        This creates the raw_content_blocks list that will be preserved in
        AssistantMessage for tool call loops.

        Args:
            reasoning_content: The thinking/reasoning content
            text_content: The final answer text

        Returns:
            List of content blocks, or None if both are empty
        """
        blocks: list[ContentPartThinkingParam | ContentPartTextParam] = []

        # Add thinking block first (matches Anthropic order)
        if reasoning_content is not None:
            blocks.append(
                ContentPartThinkingParam(
                    thinking=reasoning_content,
                    signature=None,  # DeepSeek doesn't use signatures
                )
            )

        # Add text content
        if text_content:
            blocks.append(ContentPartTextParam(text=text_content))

        return blocks if blocks else None

    def _should_clean_historical_reasoning(self, messages: list[BaseMessage]) -> bool:
        """Check if we should clean historical reasoning_content.

        Cleaning is triggered when:
        1. auto_clean_reasoning is enabled
        2. Model preset history_policy is not "preserve"
        3. We're starting a new turn (last message is from user)
        4. There's message history to clean

        Args:
            messages: Message list

        Returns:
            True if should clean historical reasoning
        """
        if not self.auto_clean_reasoning:
            return False

        from comate_agent_sdk.llm.model_presets import get_model_preset

        if get_model_preset(str(self.model)).history_policy == "preserve":
            return False

        if len(messages) < 2:
            return False

        from comate_agent_sdk.llm.messages import UserMessage

        return isinstance(messages[-1], UserMessage)

    async def astream(
        self,
        messages: list[BaseMessage],
        tools: list[ToolDefinition] | None = None,
        tool_choice: ToolChoice | None = None,
        **kwargs: Any,
    ):
        """Yield raw DeepSeek OpenAI-compatible stream chunks."""
        if self._should_clean_historical_reasoning(messages):
            logger.debug(
                "New turn detected, cleaning historical reasoning_content from messages"
            )
            messages = DeepSeekMessageSerializer.strip_thinking_blocks(messages)

        openai_messages = DeepSeekMessageSerializer.serialize_messages(messages)
        model_params = self._build_model_params(tools, tool_choice, **kwargs)
        model_params["stream"] = True
        model_params["stream_options"] = {"include_usage": True}

        try:
            stream = await self.get_client().chat.completions.create(
                model=self.model,
                messages=openai_messages,
                **model_params,
            )
        except RateLimitError as e:
            raise ModelRateLimitError(message=e.message, model=self.name) from e
        except APIConnectionError as e:
            raise ModelProviderError(message=str(e), model=self.name) from e
        except APIStatusError as e:
            raise ModelProviderError(
                message=e.message, status_code=e.status_code, model=self.name
            ) from e

        cancel_event: asyncio.Event | None = kwargs.get("cancel_event")
        try:
            async for chunk in stream:
                if cancel_event is not None and cancel_event.is_set():
                    raise asyncio.CancelledError("llm_cancel")
                yield chunk
        except RateLimitError as e:
            raise ModelRateLimitError(message=e.message, model=self.name) from e
        except APIConnectionError as e:
            raise ModelProviderError(message=str(e), model=self.name) from e
        except APIStatusError as e:
            raise ModelProviderError(
                message=e.message, status_code=e.status_code, model=self.name
            ) from e
        finally:
            close = getattr(stream, "close", None)
            if callable(close):
                with suppress(Exception):
                    result = close()
                    if asyncio.iscoroutine(result):
                        await result

    async def ainvoke(
        self,
        messages: list[BaseMessage],
        tools: list[ToolDefinition] | None = None,
        tool_choice: ToolChoice | None = None,
        **kwargs: Any,
    ) -> ChatInvokeCompletion:
        """Invoke DeepSeek via its stream path and aggregate chunks."""
        state = OpenAIStreamState()
        try:
            async for chunk in self.astream(messages, tools, tool_choice, **kwargs):
                state.ingest(chunk)
                if getattr(chunk, "usage", None) is not None:
                    state.usage = self._get_usage(chunk)
            result = self.normalize_stream_completion(
                state.finalize(),
                getattr(state, "last_raw_usage", None),
            )
        except Exception as e:
            if isinstance(e, ModelProviderError):
                raise
            logger.error(f"Unexpected error in deepseek provider: {e}", exc_info=True)
            raise ModelProviderError(message=str(e), status_code=0, model=self.name) from e

        if result.usage and os.getenv("comate_agent_sdk_LLM_DEBUG"):
            cached = result.usage.prompt_cached_tokens or 0
            input_tokens = result.usage.prompt_tokens - cached
            logger.info(
                f"{self.model}: {input_tokens:,} in + {cached:,} cached (hit) + {result.usage.completion_tokens:,} out"
            )
            if cached > 0:
                cache_rate = (
                    (cached / result.usage.prompt_tokens * 100)
                    if result.usage.prompt_tokens > 0
                    else 0
                )
                logger.info(f"   Cache hit rate: {cache_rate:.1f}%")
        if result.thinking:
            logger.debug("Extracted reasoning_content: %d chars", len(result.thinking))
        return result
