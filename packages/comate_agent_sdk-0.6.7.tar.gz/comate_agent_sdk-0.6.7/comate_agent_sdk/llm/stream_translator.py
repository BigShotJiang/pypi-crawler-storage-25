"""Translate raw SDK stream chunks into agent-layer stream events."""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

from comate_agent_sdk.agent.events import (
    AgentEvent,
    TextDeltaEvent,
    ThinkingDeltaEvent,
    ToolCallStartEvent,
)
from comate_agent_sdk.llm.stream_state import (
    AnthropicStreamState,
    OpenAIStreamState,
)


def translate_openai_chunk(
    chunk: Any,
    state: OpenAIStreamState,
    message_id: str,
) -> Iterator[AgentEvent]:
    """Translate one OpenAI-compatible stream chunk to transient agent events."""
    choices = getattr(chunk, "choices", None) or []
    if not choices:
        return

    delta = getattr(choices[0], "delta", None)
    if delta is None:
        return

    content_delta = getattr(delta, "content", None)
    if content_delta:
        yield TextDeltaEvent(delta=str(content_delta), message_id=message_id)

    thinking_delta = getattr(delta, "reasoning_content", None)
    if thinking_delta:
        yield ThinkingDeltaEvent(delta=str(thinking_delta), message_id=message_id)

    for tc_delta in getattr(delta, "tool_calls", None) or []:
        index = int(getattr(tc_delta, "index", 0) or 0)
        function_delta = getattr(tc_delta, "function", None)
        tool_name = (
            getattr(function_delta, "name", None)
            if function_delta is not None
            else None
        )
        if index in state._started_tool_calls or not tool_name:
            continue
        state._started_tool_calls.add(index)
        tool_call_id = getattr(tc_delta, "id", None) or f"idx_{index}"
        yield ToolCallStartEvent(
            tool_call_id=str(tool_call_id),
            tool=str(tool_name),
        )


def translate_anthropic_event(
    event: Any,
    state: AnthropicStreamState,
    message_id: str,
) -> Iterator[AgentEvent]:
    """Translate one Anthropic stream event to transient agent events."""
    event_type = getattr(event, "type", "")
    if event_type == "content_block_start":
        block = getattr(event, "content_block", None)
        if block is None or getattr(block, "type", None) != "tool_use":
            return
        tool_id = str(getattr(block, "id", "") or "")
        if not tool_id or tool_id in state._started_tool_use_ids:
            return
        state._started_tool_use_ids.add(tool_id)
        yield ToolCallStartEvent(
            tool_call_id=tool_id,
            tool=str(getattr(block, "name", "") or ""),
        )
        return

    if event_type != "content_block_delta":
        return

    delta = getattr(event, "delta", None)
    if delta is None:
        return
    delta_type = getattr(delta, "type", "")
    if delta_type == "text_delta":
        yield TextDeltaEvent(
            delta=str(getattr(delta, "text", "") or ""),
            message_id=message_id,
        )
    elif delta_type == "thinking_delta":
        yield ThinkingDeltaEvent(
            delta=str(getattr(delta, "thinking", "") or ""),
            message_id=message_id,
        )
