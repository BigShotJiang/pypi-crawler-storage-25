"""Stream aggregation state for LLM providers."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Any

from comate_agent_sdk.llm.messages import (
    ContentPartRedactedThinkingParam,
    ContentPartTextParam,
    ContentPartThinkingParam,
    Function,
    ToolCall,
)
from comate_agent_sdk.llm.views import ChatInvokeCompletion, ChatInvokeUsage

logger = logging.getLogger("comate_agent_sdk.llm.stream_state")


@dataclass
class _OpenAIToolCallAcc:
    """Internal accumulator for one OpenAI tool_call streamed across chunks."""

    id: str = ""
    name: str = ""
    args: str = ""
    completed: bool = False


@dataclass
class OpenAIStreamState:
    """Aggregate OpenAI ChatCompletionChunk objects into ChatInvokeCompletion."""

    content_parts: list[str] = field(default_factory=list)
    thinking_parts: list[str] = field(default_factory=list)
    tool_calls_by_index: dict[int, _OpenAIToolCallAcc] = field(default_factory=dict)
    usage: ChatInvokeUsage | None = None
    last_raw_usage: Any = None
    stop_reason: str | None = None

    _started_tool_calls: set[int] = field(default_factory=set)
    _finalized: bool = False

    def ingest(self, chunk: Any) -> None:
        """Absorb one OpenAI-compatible stream chunk into this state."""
        usage = getattr(chunk, "usage", None)
        if usage is not None:
            completion_details = getattr(usage, "completion_tokens_details", None)
            prompt_details = getattr(usage, "prompt_tokens_details", None)
            self.last_raw_usage = usage
            self.usage = ChatInvokeUsage(
                prompt_tokens=int(getattr(usage, "prompt_tokens", 0) or 0),
                prompt_cached_tokens=(
                    getattr(prompt_details, "cached_tokens", None)
                    if prompt_details is not None
                    else None
                ),
                prompt_cache_creation_tokens=None,
                prompt_image_tokens=None,
                reasoning_tokens=(
                    getattr(completion_details, "reasoning_tokens", 0)
                    if completion_details is not None
                    else 0
                ),
                completion_tokens=int(getattr(usage, "completion_tokens", 0) or 0),
                total_tokens=int(getattr(usage, "total_tokens", 0) or 0),
            )
            # 不在此 return：部分 provider（如 GLM）在同一 chunk 里同时携带
            # usage 和 finish_reason，需要继续处理 choices

        choices = getattr(chunk, "choices", None) or []
        if not choices:
            return

        choice = choices[0]
        delta = getattr(choice, "delta", None)
        if delta is None:
            return

        content_delta = getattr(delta, "content", None)
        if content_delta:
            self.content_parts.append(content_delta)

        thinking_delta = getattr(delta, "reasoning_content", None)
        if thinking_delta:
            self.thinking_parts.append(thinking_delta)

        for tc_delta in getattr(delta, "tool_calls", None) or []:
            index = int(getattr(tc_delta, "index", 0) or 0)
            acc = self.tool_calls_by_index.setdefault(index, _OpenAIToolCallAcc())
            tool_call_id = getattr(tc_delta, "id", None)
            if tool_call_id:
                acc.id = str(tool_call_id)
            function_delta = getattr(tc_delta, "function", None)
            if function_delta is None:
                continue
            function_name = getattr(function_delta, "name", None)
            if function_name:
                acc.name = str(function_name)
            arguments_delta = getattr(function_delta, "arguments", None)
            if arguments_delta:
                acc.args += str(arguments_delta)

        finish_reason = getattr(choice, "finish_reason", None)
        if finish_reason is not None:
            self.stop_reason = str(finish_reason)
            for acc in self.tool_calls_by_index.values():
                acc.completed = True

    def finalize(self) -> ChatInvokeCompletion:
        assert not self._finalized, "OpenAIStreamState.finalize() already called"
        self._finalized = True
        return self._build_completion(stop_reason=self.stop_reason)

    def finalize_partial(self, stop_reason: str) -> ChatInvokeCompletion:
        assert not self._finalized, (
            "OpenAIStreamState.finalize_partial() called after finalize()"
        )
        self._finalized = True
        return self._build_completion(stop_reason=stop_reason)

    def _build_completion(self, *, stop_reason: str | None) -> ChatInvokeCompletion:
        content = "".join(self.content_parts) if self.content_parts else None
        thinking = "".join(self.thinking_parts) if self.thinking_parts else None

        tool_calls: list[ToolCall] = []
        for index in sorted(self.tool_calls_by_index):
            acc = self.tool_calls_by_index[index]
            if not acc.completed:
                continue
            if not acc.id or not acc.name:
                logger.debug(
                    "OpenAIStreamState: dropping incomplete tool_call index=%s id=%r name=%r",
                    index,
                    acc.id,
                    acc.name,
                )
                continue
            try:
                json.loads(acc.args)
            except (TypeError, ValueError):
                logger.debug(
                    "OpenAIStreamState: dropping incomplete tool_call index=%s args=%r",
                    index,
                    acc.args,
                )
                continue
            tool_calls.append(
                ToolCall(
                    id=acc.id,
                    function=Function(name=acc.name, arguments=acc.args),
                    type="function",
                )
            )

        raw_content_blocks = None
        if thinking:
            blocks: list[ContentPartThinkingParam | ContentPartTextParam] = [
                ContentPartThinkingParam(thinking=thinking, signature=None)
            ]
            if content:
                blocks.append(ContentPartTextParam(text=content))
            raw_content_blocks = blocks

        return ChatInvokeCompletion(
            content=content,
            thinking=thinking,
            raw_content_blocks=raw_content_blocks,
            tool_calls=tool_calls,
            usage=self.usage,
            stop_reason=stop_reason,
        )


@dataclass
class _AnthropicBlockAcc:
    """Internal accumulator for one Anthropic content block."""

    type: str = ""
    text: str = ""
    thinking: str = ""
    signature: str | None = None
    data: str = ""
    tool_id: str = ""
    tool_name: str = ""
    tool_args: str = ""
    closed: bool = False


@dataclass
class AnthropicStreamState:
    """Aggregate Anthropic RawMessageStreamEvent objects into ChatInvokeCompletion."""

    blocks_by_index: dict[int, _AnthropicBlockAcc] = field(default_factory=dict)
    usage: ChatInvokeUsage | None = None
    stop_reason: str | None = None

    _started_tool_use_ids: set[str] = field(default_factory=set)
    _finalized: bool = False

    def ingest(self, event: Any) -> None:
        event_type = getattr(event, "type", "")
        if event_type == "message_start":
            self._ingest_message_start(event)
            return
        if event_type == "content_block_start":
            self._ingest_content_block_start(event)
            return
        if event_type == "content_block_delta":
            self._ingest_content_block_delta(event)
            return
        if event_type == "content_block_stop":
            self._ingest_content_block_stop(event)
            return
        if event_type == "message_delta":
            self._ingest_message_delta(event)

    def finalize(self) -> ChatInvokeCompletion:
        assert not self._finalized, "AnthropicStreamState.finalize() already called"
        self._finalized = True
        return self._build_completion(stop_reason=self.stop_reason)

    def finalize_partial(self, stop_reason: str) -> ChatInvokeCompletion:
        assert not self._finalized, (
            "AnthropicStreamState.finalize_partial() called after finalize()"
        )
        self._finalized = True
        return self._build_completion(stop_reason=stop_reason)

    def _ingest_message_start(self, event: Any) -> None:
        usage = getattr(getattr(event, "message", None), "usage", None)
        if usage is None:
            return
        input_tokens = int(getattr(usage, "input_tokens", 0) or 0)
        cache_read = int(getattr(usage, "cache_read_input_tokens", 0) or 0)
        cache_creation = int(
            getattr(usage, "cache_creation_input_tokens", 0) or 0
        )
        output_tokens = int(getattr(usage, "output_tokens", 0) or 0)
        prompt_tokens = input_tokens + cache_read + cache_creation
        self.usage = ChatInvokeUsage(
            prompt_tokens=prompt_tokens,
            prompt_cached_tokens=cache_read or None,
            prompt_cache_creation_tokens=cache_creation or None,
            prompt_image_tokens=None,
            completion_tokens=output_tokens,
            total_tokens=prompt_tokens + output_tokens,
        )

    def _ingest_content_block_start(self, event: Any) -> None:
        block = getattr(event, "content_block", None)
        if block is None:
            return
        block_type = str(getattr(block, "type", "") or "")
        acc = _AnthropicBlockAcc(type=block_type)
        if block_type == "tool_use":
            acc.tool_id = str(getattr(block, "id", "") or "")
            acc.tool_name = str(getattr(block, "name", "") or "")
        elif block_type == "redacted_thinking":
            acc.data = str(getattr(block, "data", "") or "")
        index = int(getattr(event, "index", 0) or 0)
        self.blocks_by_index[index] = acc

    def _ingest_content_block_delta(self, event: Any) -> None:
        index = int(getattr(event, "index", 0) or 0)
        acc = self.blocks_by_index.setdefault(index, _AnthropicBlockAcc())
        delta = getattr(event, "delta", None)
        if delta is None:
            return
        delta_type = str(getattr(delta, "type", "") or "")
        if delta_type == "text_delta":
            acc.text += str(getattr(delta, "text", "") or "")
        elif delta_type == "thinking_delta":
            acc.thinking += str(getattr(delta, "thinking", "") or "")
        elif delta_type == "signature_delta":
            acc.signature = str(getattr(delta, "signature", "") or "")
        elif delta_type == "input_json_delta":
            acc.tool_args += str(getattr(delta, "partial_json", "") or "")

    def _ingest_content_block_stop(self, event: Any) -> None:
        index = int(getattr(event, "index", 0) or 0)
        acc = self.blocks_by_index.setdefault(index, _AnthropicBlockAcc())
        acc.closed = True

    def _ingest_message_delta(self, event: Any) -> None:
        delta = getattr(event, "delta", None)
        stop_reason = getattr(delta, "stop_reason", None)
        if stop_reason is not None:
            self.stop_reason = str(stop_reason)

        usage_delta = getattr(event, "usage", None)
        if self.usage is None or usage_delta is None:
            return
        completion_tokens = int(getattr(usage_delta, "output_tokens", 0) or 0)
        # 部分 Anthropic 兼容端点（如 z.ai/GLM）在 message_start 里 input_tokens=0，
        # 实际数值在 message_delta 里才给出。若 delta 里有非零 prompt 数据，优先使用。
        delta_input = int(getattr(usage_delta, "input_tokens", 0) or 0)
        delta_cache_read = int(getattr(usage_delta, "cache_read_input_tokens", 0) or 0)
        delta_cache_creation = int(
            getattr(usage_delta, "cache_creation_input_tokens", 0) or 0
        )
        delta_prompt = delta_input + delta_cache_read + delta_cache_creation
        if delta_prompt > 0:
            prompt_tokens = delta_prompt
            prompt_cached_tokens = delta_cache_read or None
            prompt_cache_creation_tokens = delta_cache_creation or None
        else:
            prompt_tokens = self.usage.prompt_tokens
            prompt_cached_tokens = self.usage.prompt_cached_tokens
            prompt_cache_creation_tokens = self.usage.prompt_cache_creation_tokens
        self.usage = ChatInvokeUsage(
            prompt_tokens=prompt_tokens,
            prompt_cached_tokens=prompt_cached_tokens,
            prompt_cache_creation_tokens=prompt_cache_creation_tokens,
            prompt_image_tokens=self.usage.prompt_image_tokens,
            reasoning_tokens=self.usage.reasoning_tokens,
            completion_tokens=completion_tokens,
            total_tokens=prompt_tokens + completion_tokens,
        )

    def _build_completion(self, *, stop_reason: str | None) -> ChatInvokeCompletion:
        text_parts: list[str] = []
        thinking_parts: list[str] = []
        redacted_parts: list[str] = []
        raw_blocks: list[
            ContentPartTextParam
            | ContentPartThinkingParam
            | ContentPartRedactedThinkingParam
        ] = []
        tool_calls: list[ToolCall] = []

        for index in sorted(self.blocks_by_index):
            acc = self.blocks_by_index[index]
            if acc.type == "text":
                text_parts.append(acc.text)
                raw_blocks.append(ContentPartTextParam(text=acc.text))
            elif acc.type == "thinking":
                thinking_parts.append(acc.thinking)
                raw_blocks.append(
                    ContentPartThinkingParam(
                        thinking=acc.thinking,
                        signature=acc.signature,
                    )
                )
            elif acc.type == "redacted_thinking":
                redacted_parts.append(acc.data)
                raw_blocks.append(ContentPartRedactedThinkingParam(data=acc.data))
            elif acc.type == "tool_use":
                self._append_tool_call_if_complete(index, acc, tool_calls)

        content = "\n".join(text_parts) if text_parts else None
        thinking = "\n".join(thinking_parts) if thinking_parts else None
        redacted = "\n".join(redacted_parts) if redacted_parts else None

        return ChatInvokeCompletion(
            content=content,
            thinking=thinking,
            redacted_thinking=redacted,
            raw_content_blocks=raw_blocks if raw_blocks else None,
            tool_calls=tool_calls,
            usage=self.usage,
            stop_reason=stop_reason,
        )

    def _append_tool_call_if_complete(
        self,
        index: int,
        acc: _AnthropicBlockAcc,
        tool_calls: list[ToolCall],
    ) -> None:
        if not acc.closed:
            logger.debug(
                "AnthropicStreamState: dropping unclosed tool_use index=%s id=%r",
                index,
                acc.tool_id,
            )
            return
        if not acc.tool_id or not acc.tool_name:
            logger.debug(
                "AnthropicStreamState: dropping incomplete tool_use index=%s id=%r name=%r",
                index,
                acc.tool_id,
                acc.tool_name,
            )
            return
        try:
            json.loads(acc.tool_args)
        except (TypeError, ValueError):
            logger.debug(
                "AnthropicStreamState: dropping tool_use with invalid JSON args id=%r",
                acc.tool_id,
            )
            return
        tool_calls.append(
            ToolCall(
                id=acc.tool_id,
                function=Function(name=acc.tool_name, arguments=acc.tool_args),
                type="function",
            )
        )
