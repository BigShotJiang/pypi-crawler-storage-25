import unittest
from types import SimpleNamespace

from comate_agent_sdk.agent.events import (
    TextDeltaEvent,
    ThinkingDeltaEvent,
    ToolCallStartEvent,
)
from comate_agent_sdk.llm.stream_state import AnthropicStreamState
from comate_agent_sdk.llm.stream_translator import translate_anthropic_event


def _ev(type_: str, **kwargs) -> SimpleNamespace:
    return SimpleNamespace(type=type_, **kwargs)


class TestAnthropicTranslator(unittest.TestCase):
    def test_text_delta_emits_text_delta_event(self) -> None:
        state = AnthropicStreamState()
        event = _ev(
            "content_block_delta",
            index=0,
            delta=SimpleNamespace(type="text_delta", text="Hello"),
        )
        events = list(translate_anthropic_event(event, state, "msg-1"))
        self.assertEqual(len(events), 1)
        self.assertIsInstance(events[0], TextDeltaEvent)
        self.assertEqual(events[0].delta, "Hello")

    def test_thinking_delta_emits_thinking_delta_event(self) -> None:
        state = AnthropicStreamState()
        event = _ev(
            "content_block_delta",
            index=0,
            delta=SimpleNamespace(type="thinking_delta", thinking="Pondering"),
        )
        events = list(translate_anthropic_event(event, state, "msg-1"))
        self.assertEqual(len(events), 1)
        self.assertIsInstance(events[0], ThinkingDeltaEvent)

    def test_tool_use_block_start_emits_start(self) -> None:
        state = AnthropicStreamState()
        event = _ev(
            "content_block_start",
            index=0,
            content_block=SimpleNamespace(type="tool_use", id="toolu_1", name="Edit"),
        )
        events = list(translate_anthropic_event(event, state, "msg-1"))
        self.assertEqual(len(events), 1)
        self.assertIsInstance(events[0], ToolCallStartEvent)
        self.assertEqual(events[0].tool_call_id, "toolu_1")

    def test_tool_use_start_idempotent(self) -> None:
        state = AnthropicStreamState()
        event = _ev(
            "content_block_start",
            index=0,
            content_block=SimpleNamespace(type="tool_use", id="toolu_1", name="Edit"),
        )
        list(translate_anthropic_event(event, state, "msg-1"))
        events2 = list(translate_anthropic_event(event, state, "msg-1"))
        self.assertEqual(events2, [])

    def test_input_json_delta_does_not_emit(self) -> None:
        state = AnthropicStreamState()
        event = _ev(
            "content_block_delta",
            index=0,
            delta=SimpleNamespace(type="input_json_delta", partial_json='{"foo":'),
        )
        events = list(translate_anthropic_event(event, state, "msg-1"))
        self.assertEqual(events, [])

    def test_signature_delta_does_not_emit(self) -> None:
        state = AnthropicStreamState()
        event = _ev(
            "content_block_delta",
            index=0,
            delta=SimpleNamespace(type="signature_delta", signature="sig_xyz"),
        )
        events = list(translate_anthropic_event(event, state, "msg-1"))
        self.assertEqual(events, [])

    def test_message_start_does_not_emit(self) -> None:
        state = AnthropicStreamState()
        event = _ev(
            "message_start",
            message=SimpleNamespace(
                id="msg_1",
                usage=SimpleNamespace(
                    input_tokens=0,
                    cache_read_input_tokens=0,
                    cache_creation_input_tokens=0,
                    output_tokens=0,
                ),
            ),
        )
        events = list(translate_anthropic_event(event, state, "msg-1"))
        self.assertEqual(events, [])

    def test_content_block_stop_does_not_emit(self) -> None:
        state = AnthropicStreamState()
        event = _ev("content_block_stop", index=0)
        events = list(translate_anthropic_event(event, state, "msg-1"))
        self.assertEqual(events, [])


if __name__ == "__main__":
    unittest.main()
