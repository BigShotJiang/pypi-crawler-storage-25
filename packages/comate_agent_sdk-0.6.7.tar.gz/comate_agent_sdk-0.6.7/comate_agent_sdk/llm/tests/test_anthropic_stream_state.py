import json
import unittest
from types import SimpleNamespace

from comate_agent_sdk.llm.stream_state import AnthropicStreamState


def _ev(type_: str, **kwargs) -> SimpleNamespace:
    return SimpleNamespace(type=type_, **kwargs)


def _message_start(
    input_tokens: int = 0,
    cache_read: int = 0,
    cache_creation: int = 0,
) -> SimpleNamespace:
    return _ev(
        "message_start",
        message=SimpleNamespace(
            id="msg_1",
            usage=SimpleNamespace(
                input_tokens=input_tokens,
                cache_read_input_tokens=cache_read,
                cache_creation_input_tokens=cache_creation,
                output_tokens=0,
            ),
        ),
    )


def _content_block_start_text(index: int) -> SimpleNamespace:
    return _ev(
        "content_block_start",
        index=index,
        content_block=SimpleNamespace(type="text", text=""),
    )


def _content_block_start_thinking(index: int) -> SimpleNamespace:
    return _ev(
        "content_block_start",
        index=index,
        content_block=SimpleNamespace(type="thinking", thinking="", signature=None),
    )


def _content_block_start_tool_use(index: int, tc_id: str, name: str) -> SimpleNamespace:
    return _ev(
        "content_block_start",
        index=index,
        content_block=SimpleNamespace(
            type="tool_use",
            id=tc_id,
            name=name,
            input={},
        ),
    )


def _text_delta(index: int, text: str) -> SimpleNamespace:
    return _ev(
        "content_block_delta",
        index=index,
        delta=SimpleNamespace(type="text_delta", text=text),
    )


def _thinking_delta(index: int, thinking: str) -> SimpleNamespace:
    return _ev(
        "content_block_delta",
        index=index,
        delta=SimpleNamespace(type="thinking_delta", thinking=thinking),
    )


def _signature_delta(index: int, signature: str) -> SimpleNamespace:
    return _ev(
        "content_block_delta",
        index=index,
        delta=SimpleNamespace(type="signature_delta", signature=signature),
    )


def _input_json_delta(index: int, partial_json: str) -> SimpleNamespace:
    return _ev(
        "content_block_delta",
        index=index,
        delta=SimpleNamespace(type="input_json_delta", partial_json=partial_json),
    )


def _block_stop(index: int) -> SimpleNamespace:
    return _ev("content_block_stop", index=index)


def _message_delta(stop_reason: str, output_tokens: int) -> SimpleNamespace:
    return _ev(
        "message_delta",
        delta=SimpleNamespace(stop_reason=stop_reason),
        usage=SimpleNamespace(output_tokens=output_tokens),
    )


def _message_stop() -> SimpleNamespace:
    return _ev("message_stop")


class TestAnthropicStreamState(unittest.TestCase):
    def test_aggregates_text(self) -> None:
        state = AnthropicStreamState()
        state.ingest(_message_start(input_tokens=100))
        state.ingest(_content_block_start_text(0))
        state.ingest(_text_delta(0, "Hello, "))
        state.ingest(_text_delta(0, "world!"))
        state.ingest(_block_stop(0))
        state.ingest(_message_delta("end_turn", output_tokens=5))
        state.ingest(_message_stop())

        result = state.finalize()
        self.assertEqual(result.content, "Hello, world!")
        self.assertEqual(result.stop_reason, "end_turn")
        self.assertEqual(result.usage.prompt_tokens, 100)
        self.assertEqual(result.usage.completion_tokens, 5)

    def test_aggregates_thinking_with_signature(self) -> None:
        state = AnthropicStreamState()
        state.ingest(_message_start(input_tokens=50))
        state.ingest(_content_block_start_thinking(0))
        state.ingest(_thinking_delta(0, "Let me think..."))
        state.ingest(_signature_delta(0, "sig_xyz"))
        state.ingest(_block_stop(0))
        state.ingest(_content_block_start_text(1))
        state.ingest(_text_delta(1, "Answer: 42"))
        state.ingest(_block_stop(1))
        state.ingest(_message_delta("end_turn", output_tokens=10))

        result = state.finalize()
        self.assertEqual(result.thinking, "Let me think...")
        self.assertEqual(result.content, "Answer: 42")
        self.assertIsNotNone(result.raw_content_blocks)
        first = result.raw_content_blocks[0]
        self.assertEqual(first.thinking, "Let me think...")
        self.assertEqual(first.signature, "sig_xyz")

    def test_aggregates_tool_use(self) -> None:
        state = AnthropicStreamState()
        state.ingest(_message_start(input_tokens=20))
        state.ingest(_content_block_start_tool_use(0, "toolu_1", "Edit"))
        state.ingest(_input_json_delta(0, '{"file_path":'))
        state.ingest(_input_json_delta(0, ' "/tmp/a.py"}'))
        state.ingest(_block_stop(0))
        state.ingest(_message_delta("tool_use", output_tokens=15))

        result = state.finalize()
        self.assertEqual(len(result.tool_calls), 1)
        tc = result.tool_calls[0]
        self.assertEqual(tc.id, "toolu_1")
        self.assertEqual(tc.function.name, "Edit")
        self.assertEqual(json.loads(tc.function.arguments), {"file_path": "/tmp/a.py"})

    def test_finalize_partial_drops_unclosed_tool_use(self) -> None:
        state = AnthropicStreamState()
        state.ingest(_message_start(input_tokens=20))
        state.ingest(_content_block_start_tool_use(0, "toolu_1", "Edit"))
        state.ingest(_input_json_delta(0, '{"file_path": "/tmp/'))

        result = state.finalize_partial(stop_reason="interrupted")
        self.assertEqual(result.tool_calls, [])
        self.assertEqual(result.stop_reason, "interrupted")

    def test_finalize_partial_keeps_text(self) -> None:
        state = AnthropicStreamState()
        state.ingest(_message_start(input_tokens=10))
        state.ingest(_content_block_start_text(0))
        state.ingest(_text_delta(0, "half-written "))
        state.ingest(_text_delta(0, "response"))

        result = state.finalize_partial(stop_reason="interrupted")
        self.assertEqual(result.content, "half-written response")
        self.assertEqual(result.stop_reason, "interrupted")


if __name__ == "__main__":
    unittest.main()
