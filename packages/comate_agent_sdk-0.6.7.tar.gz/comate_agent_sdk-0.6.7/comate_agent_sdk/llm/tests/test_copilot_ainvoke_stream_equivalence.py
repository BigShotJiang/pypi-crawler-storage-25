import asyncio
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from comate_agent_sdk.llm.copilot.chat import ChatCopilot
from comate_agent_sdk.llm.messages import UserMessage


def _chunk(content=None, finish_reason=None, usage=None):
    choices = []
    if content is not None or finish_reason is not None:
        choices = [
            SimpleNamespace(
                delta=SimpleNamespace(
                    content=content,
                    reasoning_content=None,
                    tool_calls=None,
                ),
                finish_reason=finish_reason,
            )
        ]
    return SimpleNamespace(choices=choices, usage=usage)


async def _async_iter(items):
    for item in items:
        yield item


class TestCopilotAinvokeStreamEquivalence(unittest.TestCase):
    def _run(self, coro):
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(coro)
        finally:
            loop.close()

    def test_text_only_response(self) -> None:
        llm = ChatCopilot(model="gpt-4o", api_key="test")
        chunks = [
            _chunk(content="Hello"),
            _chunk(finish_reason="stop"),
            SimpleNamespace(
                choices=[],
                usage=SimpleNamespace(
                    prompt_tokens=5,
                    prompt_tokens_details=SimpleNamespace(cached_tokens=0),
                    completion_tokens=1,
                    completion_tokens_details=None,
                    total_tokens=6,
                ),
            ),
        ]

        with (
            patch.object(llm, "_get_bearer", new=AsyncMock(return_value="bearer-xyz")),
            patch.object(
                llm,
                "_http_post_stream",
                new=lambda **_kwargs: _async_iter(chunks),
            ),
        ):
            result = self._run(llm.ainvoke(messages=[UserMessage(content="Hi")]))

        self.assertEqual(result.content, "Hello")
        self.assertEqual(result.stop_reason, "stop")
        self.assertEqual(result.usage.prompt_tokens, 5)


if __name__ == "__main__":
    unittest.main()
