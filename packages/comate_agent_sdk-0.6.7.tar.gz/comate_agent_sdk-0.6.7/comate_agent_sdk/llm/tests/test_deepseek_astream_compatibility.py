import asyncio
import httpx
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from openai import APIConnectionError

from comate_agent_sdk.llm.exceptions import ModelProviderError
from comate_agent_sdk.llm.deepseek.chat import ChatDeepSeek
from comate_agent_sdk.llm.deepseek.serializer import DeepSeekMessageSerializer
from comate_agent_sdk.llm.messages import (
    AssistantMessage,
    ContentPartTextParam,
    ContentPartThinkingParam,
    ToolMessage,
    UserMessage,
)


def _chunk(
    content=None,
    reasoning_content=None,
    tool_calls=None,
    finish_reason=None,
    usage=None,
):
    choices = []
    if (
        content is not None
        or reasoning_content is not None
        or tool_calls is not None
        or finish_reason is not None
    ):
        choices = [
            SimpleNamespace(
                delta=SimpleNamespace(
                    content=content,
                    reasoning_content=reasoning_content,
                    tool_calls=tool_calls,
                ),
                finish_reason=finish_reason,
            )
        ]
    return SimpleNamespace(choices=choices, usage=usage)


def _usage_chunk() -> SimpleNamespace:
    return SimpleNamespace(
        choices=[],
        usage=SimpleNamespace(
            prompt_tokens=20,
            prompt_cache_hit_tokens=7,
            prompt_cache_miss_tokens=13,
            completion_tokens=10,
            completion_tokens_details=SimpleNamespace(reasoning_tokens=6),
            total_tokens=30,
            prompt_tokens_details=None,
        ),
    )


def _tool_call_delta(
    *,
    index: int,
    tool_call_id: str | None,
    name: str | None,
    arguments: str,
) -> SimpleNamespace:
    return SimpleNamespace(
        index=index,
        id=tool_call_id,
        function=SimpleNamespace(name=name, arguments=arguments),
        type="function",
    )


async def _stream(chunks):
    for chunk in chunks:
        yield chunk


async def _stream_then_connection_error(chunks):
    for chunk in chunks:
        yield chunk
    raise APIConnectionError(
        request=httpx.Request("POST", "https://api.deepseek.com/chat/completions")
    )


class TestDeepSeekAstreamCompatibility(unittest.TestCase):
    def _run(self, coro):
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(coro)
        finally:
            loop.close()

    def _make_llm(self) -> ChatDeepSeek:
        return ChatDeepSeek(
            model="deepseek-reasoner",
            api_key="test-key",
            base_url="https://api.deepseek.com",
        )

    def test_new_turn_strips_historical_reasoning_before_stream_call(self) -> None:
        llm = self._make_llm()
        messages = [
            AssistantMessage(
                content=[
                    ContentPartThinkingParam(thinking="old reasoning"),
                    ContentPartTextParam(text="old answer"),
                ]
            ),
            UserMessage(content="new question"),
        ]
        chunks = [_chunk(content="ok"), _chunk(finish_reason="stop"), _usage_chunk()]
        mock_client = MagicMock()
        mock_client.chat.completions.create = AsyncMock(return_value=_stream(chunks))

        with patch.object(llm, "get_client", return_value=mock_client):
            self._run(llm.ainvoke(messages=messages))

        sent_messages = mock_client.chat.completions.create.call_args.kwargs["messages"]
        assistant_message = sent_messages[0]
        self.assertNotIn("reasoning_content", assistant_message)

    def test_reasoning_content_maps_to_thinking_and_raw_blocks(self) -> None:
        llm = self._make_llm()
        chunks = [
            _chunk(reasoning_content="deep reasoning"),
            _chunk(content="final answer"),
            _chunk(finish_reason="stop"),
            _usage_chunk(),
        ]
        mock_client = MagicMock()
        mock_client.chat.completions.create = AsyncMock(return_value=_stream(chunks))

        with patch.object(llm, "get_client", return_value=mock_client):
            result = self._run(llm.ainvoke(messages=[UserMessage(content="Hi")]))

        self.assertEqual(result.thinking, "deep reasoning")
        self.assertEqual(result.content, "final answer")
        self.assertIsNotNone(result.raw_content_blocks)
        self.assertEqual(result.raw_content_blocks[0].thinking, "deep reasoning")
        self.assertEqual(result.usage.prompt_cached_tokens, 7)
        self.assertEqual(result.usage.reasoning_tokens, 6)

    def test_empty_reasoning_content_with_tool_call_is_preserved_for_next_request(self) -> None:
        llm = self._make_llm()
        chunks = [
            _chunk(
                reasoning_content="",
                tool_calls=[
                    _tool_call_delta(
                        index=0,
                        tool_call_id="call_1",
                        name="Read",
                        arguments='{"file_path":"a.txt"}',
                    )
                ],
            ),
            _chunk(finish_reason="tool_calls"),
            _usage_chunk(),
        ]
        mock_client = MagicMock()
        mock_client.chat.completions.create = AsyncMock(return_value=_stream(chunks))

        with patch.object(llm, "get_client", return_value=mock_client):
            result = self._run(llm.ainvoke(messages=[UserMessage(content="Read a.txt")]))

        self.assertEqual(result.thinking, "")
        self.assertEqual(len(result.tool_calls), 1)
        self.assertIsNotNone(result.raw_content_blocks)
        assert result.raw_content_blocks is not None
        self.assertEqual(result.raw_content_blocks[0].thinking, "")

        serialized = DeepSeekMessageSerializer.serialize_messages([
            AssistantMessage(
                content=result.raw_content_blocks,
                tool_calls=result.tool_calls,
            ),
            ToolMessage(
                tool_call_id="call_1",
                tool_name="Read",
                content="ok",
            ),
        ])

        self.assertEqual(serialized[0].get("reasoning_content"), "")
        self.assertIn("tool_calls", serialized[0])

    def test_stream_iteration_connection_error_is_wrapped(self) -> None:
        llm = self._make_llm()
        mock_client = MagicMock()
        mock_client.chat.completions.create = AsyncMock(
            return_value=_stream_then_connection_error([_chunk(content="partial")])
        )

        async def _consume() -> None:
            async for _ in llm.astream(messages=[UserMessage(content="Hi")]):
                pass

        with patch.object(llm, "get_client", return_value=mock_client):
            with self.assertRaises(ModelProviderError):
                self._run(_consume())


if __name__ == "__main__":
    unittest.main()
