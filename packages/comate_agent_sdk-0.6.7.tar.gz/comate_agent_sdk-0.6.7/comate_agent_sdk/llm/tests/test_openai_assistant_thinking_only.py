"""Regression: OpenAI/DeepSeek serializer must not emit empty content list.

When a reasoning-capable provider (e.g. deepseek-v4-pro) returns a turn that
contains only thinking + tool_call (no text), OpenAIStreamState aggregates
``raw_content_blocks=[ThinkingPart]``. On the next request, serializing this
AssistantMessage must not produce ``content: []`` — that shape violates the
OpenAI protocol (a list ``content`` must be non-empty) and is rejected by
DeepSeek with a 400 about ``reasoning_content in the thinking ...``.

The fix: ``_serialize_assistant_content`` returns ``None`` when filtering
yields an empty list, so ``serialize()`` omits the ``content`` field entirely.
"""

import unittest

from comate_agent_sdk.llm.deepseek.serializer import DeepSeekMessageSerializer
from comate_agent_sdk.llm.messages import (
    AssistantMessage,
    ContentPartTextParam,
    ContentPartThinkingParam,
    Function,
    ToolCall,
    UserMessage,
)
from comate_agent_sdk.llm.openai.serializer import OpenAIMessageSerializer


def _thinking_only_with_tool_call() -> AssistantMessage:
    """Reproduce the exact shape OpenAIStreamState builds for a turn with
    only reasoning_content + tool_calls (no text content)."""
    return AssistantMessage(
        content=[ContentPartThinkingParam(thinking="reason about it", signature=None)],
        tool_calls=[
            ToolCall(
                id="call_1",
                type="function",
                function=Function(name="LS", arguments="{}"),
            )
        ],
    )


class TestOpenAIThinkingOnlyAssistant(unittest.TestCase):
    def test_openai_omits_content_when_only_thinking(self) -> None:
        msg = _thinking_only_with_tool_call()
        serialized = OpenAIMessageSerializer.serialize(msg)

        self.assertNotIn(
            "content",
            serialized,
            msg=(
                "Empty list content violates OpenAI protocol; serializer should "
                "omit content entirely when only thinking parts are present."
            ),
        )
        self.assertIn("tool_calls", serialized)

    def test_openai_keeps_text_when_present(self) -> None:
        msg = AssistantMessage(
            content=[
                ContentPartThinkingParam(thinking="think", signature=None),
                ContentPartTextParam(text="answer"),
            ],
            tool_calls=None,
        )
        serialized = OpenAIMessageSerializer.serialize(msg)

        self.assertEqual(
            serialized.get("content"),
            [{"text": "answer", "type": "text"}],
        )


class TestDeepSeekThinkingOnlyAssistant(unittest.TestCase):
    def test_deepseek_injects_reasoning_and_omits_empty_content(self) -> None:
        msg = _thinking_only_with_tool_call()
        serialized = DeepSeekMessageSerializer.serialize(msg)

        self.assertNotIn(
            "content",
            serialized,
            msg=(
                "DeepSeek 400 root cause: empty content list combined with "
                "tool_calls + reasoning_content is rejected by the API."
            ),
        )
        self.assertEqual(serialized.get("reasoning_content"), "reason about it")
        self.assertIn("tool_calls", serialized)

    def test_deepseek_drops_orphan_thinking_only_history_message(self) -> None:
        msg = AssistantMessage(
            content=[ContentPartThinkingParam(thinking="orphan reasoning", signature=None)],
            tool_calls=None,
        )

        serialized = DeepSeekMessageSerializer.serialize_messages([
            UserMessage(content="previous question"),
            msg,
            UserMessage(content="next question"),
        ])

        self.assertEqual(
            serialized,
            [
                {"role": "user", "content": "previous question"},
                {"role": "user", "content": "next question"},
            ],
        )

    def test_deepseek_drops_empty_assistant_history_message(self) -> None:
        msg = AssistantMessage(
            content=[ContentPartTextParam(text="")],
            tool_calls=None,
        )

        serialized = DeepSeekMessageSerializer.serialize_messages([
            UserMessage(content="previous question"),
            msg,
            UserMessage(content="next question"),
        ])

        self.assertEqual(
            serialized,
            [
                {"role": "user", "content": "previous question"},
                {"role": "user", "content": "next question"},
            ],
        )


if __name__ == "__main__":
    unittest.main()
