import asyncio
import httpx
import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from comate_agent_sdk.llm.anthropic.chat import ChatAnthropic
from comate_agent_sdk.llm.exceptions import ModelProviderError
from comate_agent_sdk.llm.messages import UserMessage


def _ev(type_: str, **kwargs) -> SimpleNamespace:
    return SimpleNamespace(type=type_, **kwargs)


class _MockStream:
    def __init__(self, events):
        self._events = events

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        return None

    def __aiter__(self):
        async def _gen():
            for event in self._events:
                yield event

        return _gen()


class _FailingMockStream:
    def __init__(self, events, error):
        self._events = events
        self._error = error

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        return None

    def __aiter__(self):
        async def _gen():
            for event in self._events:
                yield event
            raise self._error

        return _gen()


class TestAnthropicAinvokeStreamEquivalence(unittest.TestCase):
    def _run(self, coro):
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(coro)
        finally:
            loop.close()

    def test_text_only_response(self) -> None:
        llm = ChatAnthropic(model="claude-sonnet-4-5", api_key="test")
        events = [
            _ev(
                "message_start",
                message=SimpleNamespace(
                    id="msg_1",
                    usage=SimpleNamespace(
                        input_tokens=50,
                        cache_read_input_tokens=0,
                        cache_creation_input_tokens=0,
                        output_tokens=0,
                    ),
                ),
            ),
            _ev(
                "content_block_start",
                index=0,
                content_block=SimpleNamespace(type="text", text=""),
            ),
            _ev(
                "content_block_delta",
                index=0,
                delta=SimpleNamespace(type="text_delta", text="Hello, "),
            ),
            _ev(
                "content_block_delta",
                index=0,
                delta=SimpleNamespace(type="text_delta", text="world!"),
            ),
            _ev("content_block_stop", index=0),
            _ev(
                "message_delta",
                delta=SimpleNamespace(stop_reason="end_turn"),
                usage=SimpleNamespace(output_tokens=4),
            ),
            _ev("message_stop"),
        ]

        mock_client = MagicMock()
        mock_client.messages.stream = MagicMock(return_value=_MockStream(events))
        with patch.object(llm, "get_client", return_value=mock_client):
            result = self._run(llm.ainvoke(messages=[UserMessage(content="Hi")]))

        self.assertEqual(result.content, "Hello, world!")
        self.assertEqual(result.stop_reason, "end_turn")
        self.assertEqual(result.usage.prompt_tokens, 50)
        self.assertEqual(result.usage.completion_tokens, 4)

    def test_tool_use_response(self) -> None:
        llm = ChatAnthropic(model="claude-sonnet-4-5", api_key="test")
        events = [
            _ev(
                "message_start",
                message=SimpleNamespace(
                    id="msg_1",
                    usage=SimpleNamespace(
                        input_tokens=20,
                        cache_read_input_tokens=0,
                        cache_creation_input_tokens=0,
                        output_tokens=0,
                    ),
                ),
            ),
            _ev(
                "content_block_start",
                index=0,
                content_block=SimpleNamespace(
                    type="tool_use",
                    id="toolu_1",
                    name="Edit",
                ),
            ),
            _ev(
                "content_block_delta",
                index=0,
                delta=SimpleNamespace(
                    type="input_json_delta",
                    partial_json='{"file_path":',
                ),
            ),
            _ev(
                "content_block_delta",
                index=0,
                delta=SimpleNamespace(
                    type="input_json_delta",
                    partial_json=' "/tmp/a.py"}',
                ),
            ),
            _ev("content_block_stop", index=0),
            _ev(
                "message_delta",
                delta=SimpleNamespace(stop_reason="tool_use"),
                usage=SimpleNamespace(output_tokens=10),
            ),
        ]

        mock_client = MagicMock()
        mock_client.messages.stream = MagicMock(return_value=_MockStream(events))
        with patch.object(llm, "get_client", return_value=mock_client):
            result = self._run(llm.ainvoke(messages=[UserMessage(content="Edit it")]))

        self.assertEqual(len(result.tool_calls), 1)
        self.assertEqual(result.tool_calls[0].function.name, "Edit")
        self.assertEqual(result.stop_reason, "tool_use")

    def test_stream_iteration_transport_error_is_wrapped(self) -> None:
        llm = ChatAnthropic(model="claude-sonnet-4-5", api_key="test")
        events = [
            _ev(
                "message_start",
                message=SimpleNamespace(
                    id="msg_1",
                    usage=SimpleNamespace(
                        input_tokens=20,
                        cache_read_input_tokens=0,
                        cache_creation_input_tokens=0,
                        output_tokens=0,
                    ),
                ),
            ),
            _ev(
                "content_block_start",
                index=0,
                content_block=SimpleNamespace(type="text", text=""),
            ),
            _ev(
                "content_block_delta",
                index=0,
                delta=SimpleNamespace(type="text_delta", text="partial"),
            ),
        ]

        mock_client = MagicMock()
        mock_client.messages.stream = MagicMock(
            return_value=_FailingMockStream(
                events,
                httpx.ReadError(
                    "server disconnected",
                    request=httpx.Request("POST", "https://api.anthropic.com/v1/messages"),
                ),
            )
        )

        async def _consume() -> None:
            async for _ in llm.astream(messages=[UserMessage(content="Hi")]):
                pass

        with patch.object(llm, "get_client", return_value=mock_client):
            with self.assertRaises(ModelProviderError):
                self._run(_consume())


if __name__ == "__main__":
    unittest.main()
