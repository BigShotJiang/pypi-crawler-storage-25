import unittest

from comate_agent_sdk.llm.anthropic.serializer import AnthropicMessageSerializer
from comate_agent_sdk.llm.messages import (
    AssistantMessage,
    Function,
    ToolCall,
    ToolMessage,
    UserMessage,
)
from comate_agent_sdk.llm.deepseek.serializer import DeepSeekMessageSerializer
from comate_agent_sdk.llm.openai.serializer import OpenAIMessageSerializer


def _build_tool_call(tool_call_id: str, *, name: str = "Read") -> ToolCall:
    return ToolCall(
        id=tool_call_id,
        function=Function(name=name, arguments="{}"),
    )


def _build_tool_result(tool_call_id: str, *, name: str = "Read") -> ToolMessage:
    return ToolMessage(
        tool_call_id=tool_call_id,
        tool_name=name,
        content=f"result:{tool_call_id}",
    )


class TestToolProtocolInvariants(unittest.TestCase):
    def _assert_chat_serializers_raise(self, messages) -> None:
        serializers = [
            ("openai", OpenAIMessageSerializer.serialize_messages),
            ("anthropic", AnthropicMessageSerializer.serialize_messages),
            ("deepseek", DeepSeekMessageSerializer.serialize_messages),
        ]
        for name, serialize in serializers:
            with self.subTest(provider=name):
                with self.assertRaisesRegex(ValueError, "Invalid tool-call message sequence"):
                    serialize(messages)

    def test_openai_and_anthropic_raise_when_non_tool_message_breaks_tool_block(self) -> None:
        messages = [
            UserMessage(content="hello"),
            AssistantMessage(content=None, tool_calls=[_build_tool_call("tc1")]),
            UserMessage(content="hook", is_meta=True),
            _build_tool_result("tc1"),
        ]

        self._assert_chat_serializers_raise(messages)

    def test_openai_and_anthropic_raise_when_tool_results_missing(self) -> None:
        messages = [
            AssistantMessage(
                content=None,
                tool_calls=[_build_tool_call("tc1"), _build_tool_call("tc2")],
            ),
            _build_tool_result("tc1"),
        ]

        self._assert_chat_serializers_raise(messages)

    def test_openai_anthropic_deepseek_raise_for_orphan_tool_result(self) -> None:
        messages = [
            UserMessage(content="hello"),
            _build_tool_result("tc_orphan"),
        ]

        self._assert_chat_serializers_raise(messages)

    def test_openai_anthropic_deepseek_raise_for_duplicate_tool_result(self) -> None:
        messages = [
            AssistantMessage(content=None, tool_calls=[_build_tool_call("tc1")]),
            _build_tool_result("tc1"),
            _build_tool_result("tc1"),
        ]

        self._assert_chat_serializers_raise(messages)

    def test_openai_anthropic_deepseek_raise_for_duplicate_tool_call_id_in_message(self) -> None:
        messages = [
            AssistantMessage(
                content=None,
                tool_calls=[_build_tool_call("tc1"), _build_tool_call("tc1")],
            ),
            _build_tool_result("tc1"),
        ]

        self._assert_chat_serializers_raise(messages)

    def test_openai_anthropic_deepseek_raise_for_duplicate_tool_call_id_across_messages(self) -> None:
        messages = [
            AssistantMessage(content=None, tool_calls=[_build_tool_call("tc1")]),
            _build_tool_result("tc1"),
            AssistantMessage(content=None, tool_calls=[_build_tool_call("tc1")]),
            _build_tool_result("tc1"),
        ]

        self._assert_chat_serializers_raise(messages)

    def test_openai_anthropic_deepseek_raise_for_empty_tool_call_id(self) -> None:
        messages = [
            AssistantMessage(content=None, tool_calls=[_build_tool_call("")]),
        ]

        self._assert_chat_serializers_raise(messages)

    def test_openai_anthropic_deepseek_raise_for_empty_tool_result_id(self) -> None:
        messages = [
            ToolMessage(tool_call_id="", tool_name="Read", content="orphan"),
        ]

        self._assert_chat_serializers_raise(messages)

    def test_openai_and_anthropic_accept_valid_contiguous_tool_block(self) -> None:
        messages = [
            UserMessage(content="hello"),
            AssistantMessage(
                content=None,
                tool_calls=[_build_tool_call("tc1"), _build_tool_call("tc2")],
            ),
            _build_tool_result("tc2"),
            _build_tool_result("tc1"),
            UserMessage(content="done"),
        ]

        openai_messages = OpenAIMessageSerializer.serialize_messages(messages)
        anthropic_messages, _ = AnthropicMessageSerializer.serialize_messages(messages)
        deepseek_messages = DeepSeekMessageSerializer.serialize_messages(messages)
        self.assertEqual(len(openai_messages), 5)
        self.assertEqual(len(anthropic_messages), 3)
        self.assertEqual(len(deepseek_messages), 5)

        grouped_tool_results = anthropic_messages[2]
        self.assertEqual(grouped_tool_results["role"], "user")
        self.assertEqual(
            [
                block["tool_use_id"]
                for block in grouped_tool_results["content"]
                if block["type"] == "tool_result"
            ],
            ["tc2", "tc1"],
        )
        self.assertTrue(
            all(
                block["type"] == "tool_result"
                for block in grouped_tool_results["content"][:2]
            )
        )
        self.assertEqual(grouped_tool_results["content"][2]["type"], "text")
        self.assertEqual(grouped_tool_results["content"][2]["text"], "done")

    def test_anthropic_groups_tool_results_with_error_and_offload_metadata(self) -> None:
        messages = [
            AssistantMessage(
                content=None,
                tool_calls=[_build_tool_call("tc1"), _build_tool_call("tc2")],
            ),
            ToolMessage(
                tool_call_id="tc1",
                tool_name="Read",
                content="boom",
                is_error=True,
            ),
            ToolMessage(
                tool_call_id="tc2",
                tool_name="Read",
                content="ignored after destroy",
                destroyed=True,
                offloaded=True,
                offload_path="/tmp/tool_result/read/tc2.json",
            ),
        ]

        anthropic_messages, _ = AnthropicMessageSerializer.serialize_messages(messages)
        self.assertEqual(len(anthropic_messages), 2)

        grouped_tool_results = anthropic_messages[1]
        self.assertEqual(grouped_tool_results["role"], "user")
        self.assertEqual(len(grouped_tool_results["content"]), 2)

        error_block, offloaded_block = grouped_tool_results["content"]
        self.assertTrue(error_block["is_error"])
        self.assertEqual(error_block["content"], "boom")
        self.assertFalse(offloaded_block["is_error"])
        self.assertIn("/tmp/tool_result/read/tc2.json", offloaded_block["content"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
