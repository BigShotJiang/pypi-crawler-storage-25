import json
import unittest
from types import SimpleNamespace

from comate_agent_sdk.llm.stream_state import OpenAIStreamState


def _text_chunk(content: str) -> SimpleNamespace:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                delta=SimpleNamespace(
                    content=content,
                    reasoning_content=None,
                    tool_calls=None,
                ),
                finish_reason=None,
            )
        ],
        usage=None,
    )


def _reasoning_chunk(content: str) -> SimpleNamespace:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                delta=SimpleNamespace(
                    content=None,
                    reasoning_content=content,
                    tool_calls=None,
                ),
                finish_reason=None,
            )
        ],
        usage=None,
    )


def _tool_call_chunk(
    index: int,
    id_: str | None,
    name: str | None,
    args: str,
) -> SimpleNamespace:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                delta=SimpleNamespace(
                    content=None,
                    reasoning_content=None,
                    tool_calls=[
                        SimpleNamespace(
                            index=index,
                            id=id_,
                            function=SimpleNamespace(name=name, arguments=args),
                            type="function",
                        )
                    ],
                ),
                finish_reason=None,
            )
        ],
        usage=None,
    )


def _finish_chunk(reason: str) -> SimpleNamespace:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                delta=SimpleNamespace(
                    content=None,
                    reasoning_content=None,
                    tool_calls=None,
                ),
                finish_reason=reason,
            )
        ],
        usage=None,
    )


def _usage_chunk(prompt: int, completion: int, total: int) -> SimpleNamespace:
    return SimpleNamespace(
        choices=[],
        usage=SimpleNamespace(
            prompt_tokens=prompt,
            prompt_tokens_details=SimpleNamespace(cached_tokens=0),
            completion_tokens=completion,
            completion_tokens_details=None,
            total_tokens=total,
        ),
    )


class TestOpenAIStreamState(unittest.TestCase):
    def test_aggregates_text_deltas(self) -> None:
        state = OpenAIStreamState()
        state.ingest(_text_chunk("Hello, "))
        state.ingest(_text_chunk("world!"))
        state.ingest(_finish_chunk("stop"))
        state.ingest(_usage_chunk(10, 5, 15))
        result = state.finalize()
        self.assertEqual(result.content, "Hello, world!")
        self.assertEqual(result.stop_reason, "stop")
        self.assertEqual(result.usage.prompt_tokens, 10)
        self.assertEqual(result.usage.completion_tokens, 5)

    def test_aggregates_reasoning_as_thinking(self) -> None:
        state = OpenAIStreamState()
        state.ingest(_reasoning_chunk("Let me think..."))
        state.ingest(_text_chunk("Answer: 42"))
        state.ingest(_finish_chunk("stop"))
        state.ingest(_usage_chunk(8, 4, 12))
        result = state.finalize()
        self.assertEqual(result.thinking, "Let me think...")
        self.assertEqual(result.content, "Answer: 42")
        self.assertIsNotNone(result.raw_content_blocks)

    def test_aggregates_tool_call_across_chunks(self) -> None:
        state = OpenAIStreamState()
        state.ingest(_tool_call_chunk(0, "call_abc", "Edit", ""))
        state.ingest(_tool_call_chunk(0, None, None, '{"file_path":'))
        state.ingest(_tool_call_chunk(0, None, None, '"/tmp/a.py"}'))
        state.ingest(_finish_chunk("tool_calls"))
        state.ingest(_usage_chunk(20, 10, 30))
        result = state.finalize()
        self.assertEqual(len(result.tool_calls), 1)
        tc = result.tool_calls[0]
        self.assertEqual(tc.id, "call_abc")
        self.assertEqual(tc.function.name, "Edit")
        self.assertEqual(json.loads(tc.function.arguments), {"file_path": "/tmp/a.py"})

    def test_finalize_partial_drops_incomplete_tool_call(self) -> None:
        state = OpenAIStreamState()
        state.ingest(_text_chunk("Let me call a tool. "))
        state.ingest(_tool_call_chunk(0, "call_xyz", "Edit", '{"file_path": "/tmp/'))
        result = state.finalize_partial(stop_reason="interrupted")
        self.assertEqual(result.content, "Let me call a tool. ")
        self.assertEqual(result.tool_calls, [])
        self.assertEqual(result.stop_reason, "interrupted")

    def test_finalize_twice_raises(self) -> None:
        state = OpenAIStreamState()
        state.ingest(_text_chunk("x"))
        state.ingest(_finish_chunk("stop"))
        state.ingest(_usage_chunk(1, 1, 2))
        state.finalize()
        with self.assertRaises(AssertionError):
            state.finalize()


if __name__ == "__main__":
    unittest.main()
