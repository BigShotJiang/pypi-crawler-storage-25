import asyncio
import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from comate_agent_sdk.agent.llm import _normalize_stream_completion_for_llm
from comate_agent_sdk.llm.messages import ContentPartTextParam, ContentPartThinkingParam, UserMessage
from comate_agent_sdk.llm.minimax.chat import ChatMiniMax
from comate_agent_sdk.llm.views import ChatInvokeCompletion


def _ev(type_: str, **kwargs) -> SimpleNamespace:
    return SimpleNamespace(type=type_, **kwargs)


class _MockStream:
    def __init__(self, events):
        self._events = events

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        return None

    def __aiter__(self):
        async def _gen():
            for event in self._events:
                yield event

        return _gen()


class TestMiniMaxStreamCompatibility(unittest.TestCase):
    def _run(self, coro):
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(coro)
        finally:
            loop.close()

    def test_stream_finalize_preserves_minimax_cleanup_and_usage(self) -> None:
        llm = ChatMiniMax(model="MiniMax-M2.5", api_key="test")
        events = [
            _ev(
                "message_start",
                message=SimpleNamespace(
                    id="msg_1",
                    usage=SimpleNamespace(
                        input_tokens=20,
                        cache_read_input_tokens=3,
                        cache_creation_input_tokens=2,
                        output_tokens=0,
                    ),
                ),
            ),
            _ev(
                "content_block_start",
                index=0,
                content_block=SimpleNamespace(type="text", text=""),
            ),
            _ev(
                "content_block_delta",
                index=0,
                delta=SimpleNamespace(
                    type="text_delta",
                    text="正常文本\ncandidate </minimax:tool_call>",
                ),
            ),
            _ev("content_block_stop", index=0),
            _ev(
                "content_block_start",
                index=1,
                content_block=SimpleNamespace(type="thinking", thinking="", signature=None),
            ),
            _ev(
                "content_block_delta",
                index=1,
                delta=SimpleNamespace(type="thinking_delta", thinking="内部推理"),
            ),
            _ev("content_block_stop", index=1),
            _ev(
                "message_delta",
                delta=SimpleNamespace(stop_reason="end_turn"),
                usage=SimpleNamespace(output_tokens=7),
            ),
        ]
        mock_client = MagicMock()
        mock_client.messages.stream = MagicMock(return_value=_MockStream(events))

        with patch.object(llm, "get_client", return_value=mock_client):
            result = self._run(llm.ainvoke(messages=[UserMessage(content="Hi")]))

        self.assertEqual(result.content, "正常文本")
        self.assertEqual(result.thinking, "内部推理")
        self.assertEqual(result.usage.prompt_tokens, 25)
        self.assertEqual(result.usage.prompt_cached_tokens, 3)
        self.assertEqual(result.usage.prompt_cache_creation_tokens, 2)
        self.assertEqual(result.usage.completion_tokens, 7)
        self.assertIsInstance(result.raw_content_blocks[0], ContentPartTextParam)
        self.assertEqual(result.raw_content_blocks[0].text, "正常文本")
        self.assertIsInstance(result.raw_content_blocks[1], ContentPartThinkingParam)

    def test_agent_layer_normalize_hook_signature_compat(self) -> None:
        """护栏：agent 层 _normalize_stream_completion_for_llm 钩子调用 provider 的
        normalize_stream_completion 时会以 (response, last_raw_usage) 形态传参，
        子类签名必须兼容；否则 streaming 路径会抛 TypeError，
        最终触发 terminal_agent 的 session event pump failed。

        历史回归点：commit 75e575d 升级了 hook 调用形态但未同步 MiniMax 子类。
        """
        llm = ChatMiniMax(model="MiniMax-M2.5", api_key="test")
        response = ChatInvokeCompletion(
            content="hello",
            raw_content_blocks=[ContentPartTextParam(text="hello")],
        )
        fake_state = SimpleNamespace(last_raw_usage=SimpleNamespace(input_tokens=1))

        # 关键断言：hook 调用形态与子类签名兼容（不抛 TypeError）
        result = _normalize_stream_completion_for_llm(llm, response, fake_state)

        # 同时验证 MiniMax 自身的 cleanup 行为仍生效（hook 不应破坏 normalize 语义）
        self.assertEqual(result.content, "hello")
        self.assertIsInstance(result.raw_content_blocks[0], ContentPartTextParam)


if __name__ == "__main__":
    unittest.main()
