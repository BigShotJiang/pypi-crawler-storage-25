import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import httpx

from comate_agent_sdk.llm.exceptions import ModelProviderError, ModelRateLimitError
from comate_agent_sdk.llm.copilot.chat import ChatCopilot
from comate_agent_sdk.llm.messages import UserMessage


def _resp(
    *,
    status_code: int,
    method: str = "GET",
    url: str = "https://example.com",
    json_body: dict | None = None,
    headers: dict[str, str] | None = None,
    text: str | None = None,
) -> httpx.Response:
    request = httpx.Request(method, url)
    if json_body is not None:
        return httpx.Response(
            status_code=status_code,
            json=json_body,
            headers=headers,
            request=request,
        )
    return httpx.Response(
        status_code=status_code,
        content=(text or "").encode("utf-8"),
        headers=headers,
        request=request,
    )


def _chunk(content=None, reasoning_content=None, tool_calls=None, finish_reason=None, usage=None):
    choices = []
    if (
        content is not None
        or reasoning_content is not None
        or tool_calls is not None
        or finish_reason is not None
    ):
        choices = [
            SimpleNamespace(
                delta=SimpleNamespace(
                    content=content,
                    reasoning_content=reasoning_content,
                    tool_calls=tool_calls,
                ),
                finish_reason=finish_reason,
            )
        ]
    return SimpleNamespace(choices=choices, usage=usage)


def _usage_chunk(
    *,
    prompt_tokens: int = 0,
    cached_tokens: int = 0,
    completion_tokens: int = 0,
    reasoning_tokens: int | None = None,
    total_tokens: int = 0,
):
    completion_details = None
    if reasoning_tokens is not None:
        completion_details = SimpleNamespace(reasoning_tokens=reasoning_tokens)
    return SimpleNamespace(
        choices=[],
        usage=SimpleNamespace(
            prompt_tokens=prompt_tokens,
            prompt_tokens_details=SimpleNamespace(cached_tokens=cached_tokens),
            completion_tokens=completion_tokens,
            completion_tokens_details=completion_details,
            total_tokens=total_tokens,
        ),
    )


async def _async_iter(items):
    for item in items:
        if isinstance(item, Exception):
            raise item
        yield item


class _StreamMock:
    def __init__(self, side_effect):
        self.side_effect = list(side_effect)
        self.call_args_list = []

    def __call__(self, **kwargs):
        self.call_args_list.append(SimpleNamespace(kwargs=kwargs))
        next_item = self.side_effect.pop(0)
        return _async_iter(next_item)

    @property
    def call_count(self) -> int:
        return len(self.call_args_list)


class TestChatCopilot(unittest.IsolatedAsyncioTestCase):
    def _build_llm(self) -> ChatCopilot:
        return ChatCopilot(
            model="gpt-5-mini",
            api_key="gh_test_token",
            base_url="https://api.githubcopilot.com",
            github_api_url="https://api.github.com",
        )

    async def test_exchange_bearer_uses_opencode_user_agent(self) -> None:
        llm = self._build_llm()
        mock_get = AsyncMock(
            return_value=_resp(
                status_code=200,
                json_body={"token": "bearer_1", "expires_at": 9_999_999_999},
            )
        )
        llm._http_get = mock_get  # type: ignore[method-assign]

        token = await llm.exchange_bearer()

        self.assertEqual(token, "bearer_1")
        call_kwargs = mock_get.call_args.kwargs
        headers = call_kwargs["headers"]
        self.assertEqual(headers["Authorization"], "Token gh_test_token")
        self.assertEqual(headers["User-Agent"], "OpenCode/1.0")
        self.assertEqual(headers["Accept"], "application/json")

    async def test_ainvoke_chat_headers_do_not_set_user_agent(self) -> None:
        llm = self._build_llm()
        llm._http_get = AsyncMock(
            return_value=_resp(
                status_code=200,
                json_body={"token": "bearer_1", "expires_at": 9_999_999_999},
            )
        )  # type: ignore[method-assign]
        stream_mock = _StreamMock(
            [
                [
                    _chunk(content="ok"),
                    _chunk(finish_reason="stop"),
                    _usage_chunk(
                        prompt_tokens=10,
                        completion_tokens=3,
                        total_tokens=13,
                    ),
                ]
            ]
        )
        llm._http_post_stream = stream_mock  # type: ignore[method-assign]

        result = await llm.ainvoke(messages=[UserMessage(content="hello")])

        self.assertEqual(result.content, "ok")
        chat_headers = stream_mock.call_args_list[0].kwargs["headers"]
        self.assertEqual(chat_headers["Authorization"], "Bearer bearer_1")
        self.assertEqual(chat_headers["Editor-Version"], "OpenCode/1.0")
        self.assertEqual(chat_headers["Editor-Plugin-Version"], "OpenCode/1.0")
        self.assertEqual(chat_headers["Copilot-Integration-Id"], "vscode-chat")
        self.assertNotIn("User-Agent", chat_headers)

    async def test_ainvoke_refreshes_bearer_after_401(self) -> None:
        llm = self._build_llm()
        llm._http_get = AsyncMock(
            side_effect=[
                _resp(
                    status_code=200,
                    json_body={"token": "bearer_old", "expires_at": 9_999_999_999},
                ),
                _resp(
                    status_code=200,
                    json_body={"token": "bearer_new", "expires_at": 9_999_999_999},
                ),
            ]
        )  # type: ignore[method-assign]
        stream_mock = _StreamMock(
            [
                [
                    ModelProviderError(
                        message="unauthorized",
                        status_code=401,
                        model=llm.name,
                    )
                ],
                [
                    _chunk(content="after-refresh"),
                    _chunk(finish_reason="stop"),
                ],
            ]
        )
        llm._http_post_stream = stream_mock  # type: ignore[method-assign]

        result = await llm.ainvoke(messages=[UserMessage(content="refresh me")])

        self.assertEqual(result.content, "after-refresh")
        self.assertEqual(llm._http_get.await_count, 2)
        self.assertEqual(stream_mock.call_count, 2)
        second_headers = stream_mock.call_args_list[1].kwargs["headers"]
        self.assertEqual(second_headers["Authorization"], "Bearer bearer_new")

    async def test_ainvoke_retries_on_429(self) -> None:
        llm = self._build_llm()
        llm._http_get = AsyncMock(
            return_value=_resp(
                status_code=200,
                json_body={"token": "bearer_1", "expires_at": 9_999_999_999},
            )
        )  # type: ignore[method-assign]
        stream_mock = _StreamMock(
            [
                [
                    ModelRateLimitError(
                        message="rate limit",
                        status_code=429,
                        model=llm.name,
                    )
                ],
                [
                    _chunk(content="retry-ok"),
                    _chunk(finish_reason="stop"),
                ],
            ]
        )
        llm._http_post_stream = stream_mock  # type: ignore[method-assign]

        with patch("comate_agent_sdk.llm.copilot.chat.asyncio.sleep", new=AsyncMock()) as sleep_mock:
            result = await llm.ainvoke(messages=[UserMessage(content="retry")])

        self.assertEqual(result.content, "retry-ok")
        self.assertEqual(stream_mock.call_count, 2)
        sleep_mock.assert_awaited_once()

    async def test_ainvoke_maps_tool_calls_and_usage(self) -> None:
        llm = self._build_llm()
        llm._http_get = AsyncMock(
            return_value=_resp(
                status_code=200,
                json_body={"token": "bearer_1", "expires_at": 9_999_999_999},
            )
        )  # type: ignore[method-assign]
        llm._http_post_stream = _StreamMock(
            [
                [
                    _chunk(reasoning_content="I should call tool first."),
                    _chunk(content="need tool"),
                    _chunk(
                        tool_calls=[
                            SimpleNamespace(
                                index=0,
                                id="call_1",
                                type="function",
                                function=SimpleNamespace(
                                    name="read_file",
                                    arguments="",
                                ),
                            )
                        ]
                    ),
                    _chunk(
                        tool_calls=[
                            SimpleNamespace(
                                index=0,
                                id=None,
                                type="function",
                                function=SimpleNamespace(
                                    name=None,
                                    arguments="{\"path\":\"README.md\"}",
                                ),
                            )
                        ]
                    ),
                    _chunk(finish_reason="tool_calls"),
                    _usage_chunk(
                        prompt_tokens=20,
                        cached_tokens=5,
                        completion_tokens=7,
                        reasoning_tokens=3,
                        total_tokens=27,
                    ),
                ]
            ]
        )  # type: ignore[method-assign]

        result = await llm.ainvoke(messages=[UserMessage(content="read readme")])

        self.assertTrue(result.has_tool_calls)
        self.assertEqual(result.tool_calls[0].function.name, "read_file")
        self.assertEqual(result.thinking, "I should call tool first.")
        assert result.usage is not None
        self.assertEqual(result.usage.prompt_tokens, 20)
        self.assertEqual(result.usage.prompt_cached_tokens, 5)
        self.assertEqual(result.usage.reasoning_tokens, 3)
        self.assertEqual(result.usage.total_tokens, 27)


if __name__ == "__main__":
    unittest.main()
