import asyncio
import httpx
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from openai import APIConnectionError

from comate_agent_sdk.llm.exceptions import ModelProviderError
from comate_agent_sdk.llm.messages import UserMessage
from comate_agent_sdk.llm.openai.chat import ChatOpenAI


def _chunk(content: str | None = None) -> SimpleNamespace:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                delta=SimpleNamespace(content=content, reasoning_content=None, tool_calls=None),
                finish_reason=None,
            )
        ],
        usage=None,
    )


async def _stream_then_connection_error(chunks):
    for chunk in chunks:
        yield chunk
    raise APIConnectionError(
        request=httpx.Request("POST", "https://api.openai.com/v1/chat/completions")
    )


class TestOpenAIAstreamCompatibility(unittest.TestCase):
    def _run(self, coro):
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(coro)
        finally:
            loop.close()

    def test_stream_iteration_connection_error_is_wrapped(self) -> None:
        llm = ChatOpenAI(model="gpt-test", api_key="test-key")
        mock_client = MagicMock()
        mock_client.chat.completions.create = AsyncMock(
            return_value=_stream_then_connection_error([_chunk(content="partial")])
        )

        async def _consume() -> None:
            async for _ in llm.astream(messages=[UserMessage(content="Hi")]):
                pass

        with patch.object(llm, "get_client", return_value=mock_client):
            with self.assertRaises(ModelProviderError):
                self._run(_consume())


if __name__ == "__main__":
    unittest.main()
