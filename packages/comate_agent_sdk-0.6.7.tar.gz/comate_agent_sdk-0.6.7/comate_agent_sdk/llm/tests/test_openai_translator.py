import unittest
from types import SimpleNamespace

from comate_agent_sdk.agent.events import (
    TextDeltaEvent,
    ThinkingDeltaEvent,
    ToolCallStartEvent,
)
from comate_agent_sdk.llm.stream_state import OpenAIStreamState
from comate_agent_sdk.llm.stream_translator import translate_openai_chunk


def _chunk(**delta_fields) -> SimpleNamespace:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                delta=SimpleNamespace(**delta_fields),
                finish_reason=None,
            )
        ],
        usage=None,
    )


class TestOpenAITranslator(unittest.TestCase):
    def test_text_delta_emits_text_delta_event(self) -> None:
        state = OpenAIStreamState()
        chunk = _chunk(content="Hello", reasoning_content=None, tool_calls=None)
        events = list(translate_openai_chunk(chunk, state, "msg-1"))
        self.assertEqual(len(events), 1)
        self.assertIsInstance(events[0], TextDeltaEvent)
        self.assertEqual(events[0].delta, "Hello")
        self.assertEqual(events[0].message_id, "msg-1")

    def test_reasoning_content_emits_thinking_delta(self) -> None:
        state = OpenAIStreamState()
        chunk = _chunk(content=None, reasoning_content="Thinking...", tool_calls=None)
        events = list(translate_openai_chunk(chunk, state, "msg-1"))
        self.assertEqual(len(events), 1)
        self.assertIsInstance(events[0], ThinkingDeltaEvent)
        self.assertEqual(events[0].delta, "Thinking...")

    def test_tool_call_first_appearance_emits_start(self) -> None:
        state = OpenAIStreamState()
        chunk = _chunk(
            content=None,
            reasoning_content=None,
            tool_calls=[
                SimpleNamespace(
                    index=0,
                    id="call_abc",
                    function=SimpleNamespace(name="Edit", arguments=""),
                    type="function",
                )
            ],
        )
        events = list(translate_openai_chunk(chunk, state, "msg-1"))
        self.assertEqual(len(events), 1)
        self.assertIsInstance(events[0], ToolCallStartEvent)
        self.assertEqual(events[0].tool_call_id, "call_abc")
        self.assertEqual(events[0].tool, "Edit")

    def test_tool_call_start_is_idempotent(self) -> None:
        state = OpenAIStreamState()
        c1 = _chunk(
            content=None,
            reasoning_content=None,
            tool_calls=[
                SimpleNamespace(
                    index=0,
                    id="call_abc",
                    function=SimpleNamespace(name="Edit", arguments=""),
                    type="function",
                )
            ],
        )
        c2 = _chunk(
            content=None,
            reasoning_content=None,
            tool_calls=[
                SimpleNamespace(
                    index=0,
                    id=None,
                    function=SimpleNamespace(name=None, arguments='{"file"'),
                    type="function",
                )
            ],
        )
        events1 = list(translate_openai_chunk(c1, state, "msg-1"))
        events2 = list(translate_openai_chunk(c2, state, "msg-1"))
        self.assertEqual(len(events1), 1)
        self.assertEqual(events2, [])

    def test_empty_delta_emits_nothing(self) -> None:
        state = OpenAIStreamState()
        chunk = _chunk(content=None, reasoning_content=None, tool_calls=None)
        events = list(translate_openai_chunk(chunk, state, "msg-1"))
        self.assertEqual(events, [])


if __name__ == "__main__":
    unittest.main()
