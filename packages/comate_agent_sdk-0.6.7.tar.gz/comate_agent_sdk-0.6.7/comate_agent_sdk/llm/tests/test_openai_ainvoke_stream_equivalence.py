"""Regression coverage for ChatOpenAI stream-first ainvoke."""

import asyncio
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from comate_agent_sdk.llm.messages import UserMessage
from comate_agent_sdk.llm.openai.chat import ChatOpenAI


def _chunk(
    content=None,
    reasoning_content=None,
    tool_calls=None,
    finish_reason=None,
    usage=None,
) -> SimpleNamespace:
    choices = []
    if (
        content is not None
        or reasoning_content is not None
        or tool_calls is not None
        or finish_reason is not None
    ):
        choices = [
            SimpleNamespace(
                delta=SimpleNamespace(
                    content=content,
                    reasoning_content=reasoning_content,
                    tool_calls=tool_calls,
                ),
                finish_reason=finish_reason,
            )
        ]
    return SimpleNamespace(choices=choices, usage=usage)


def _usage(prompt=10, completion=5, total=15) -> SimpleNamespace:
    return SimpleNamespace(
        prompt_tokens=prompt,
        prompt_tokens_details=SimpleNamespace(cached_tokens=0),
        completion_tokens=completion,
        completion_tokens_details=None,
        total_tokens=total,
    )


async def _stream(chunks):
    for chunk in chunks:
        yield chunk


class TestOpenAIAinvokeStreamEquivalence(unittest.TestCase):
    def _run(self, coro):
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(coro)
        finally:
            loop.close()

    def test_text_only_response(self) -> None:
        llm = ChatOpenAI(model="gpt-4o-mini", api_key="test")
        chunks = [
            _chunk(content="Hello, "),
            _chunk(content="world!"),
            _chunk(finish_reason="stop"),
            SimpleNamespace(choices=[], usage=_usage(12, 3, 15)),
        ]

        mock_client = MagicMock()
        mock_client.chat.completions.create = AsyncMock(return_value=_stream(chunks))
        with patch.object(llm, "get_client", return_value=mock_client):
            result = self._run(llm.ainvoke(messages=[UserMessage(content="Hi")]))

        self.assertEqual(result.content, "Hello, world!")
        self.assertEqual(result.stop_reason, "stop")
        self.assertEqual(result.usage.prompt_tokens, 12)
        self.assertEqual(result.usage.completion_tokens, 3)
        self.assertEqual(result.tool_calls, [])

    def test_tool_call_response(self) -> None:
        llm = ChatOpenAI(model="gpt-4o-mini", api_key="test")
        tc_start = SimpleNamespace(
            index=0,
            id="call_abc",
            function=SimpleNamespace(name="Edit", arguments=""),
            type="function",
        )
        tc_args_1 = SimpleNamespace(
            index=0,
            id=None,
            function=SimpleNamespace(name=None, arguments='{"file_path":'),
            type="function",
        )
        tc_args_2 = SimpleNamespace(
            index=0,
            id=None,
            function=SimpleNamespace(name=None, arguments=' "/tmp/a.py"}'),
            type="function",
        )
        chunks = [
            _chunk(tool_calls=[tc_start]),
            _chunk(tool_calls=[tc_args_1]),
            _chunk(tool_calls=[tc_args_2]),
            _chunk(finish_reason="tool_calls"),
            SimpleNamespace(choices=[], usage=_usage(20, 10, 30)),
        ]

        mock_client = MagicMock()
        mock_client.chat.completions.create = AsyncMock(return_value=_stream(chunks))
        with patch.object(llm, "get_client", return_value=mock_client):
            result = self._run(
                llm.ainvoke(messages=[UserMessage(content="Edit the file")])
            )

        self.assertEqual(len(result.tool_calls), 1)
        self.assertEqual(result.tool_calls[0].function.name, "Edit")
        self.assertEqual(result.stop_reason, "tool_calls")

    def test_astream_passes_stream_true(self) -> None:
        llm = ChatOpenAI(model="gpt-4o-mini", api_key="test")
        chunks = [
            _chunk(content="x"),
            _chunk(finish_reason="stop"),
            SimpleNamespace(choices=[], usage=_usage()),
        ]

        mock_client = MagicMock()
        mock_client.chat.completions.create = AsyncMock(return_value=_stream(chunks))
        with patch.object(llm, "get_client", return_value=mock_client):
            self._run(llm.ainvoke(messages=[UserMessage(content="Hi")]))

        kwargs = mock_client.chat.completions.create.call_args.kwargs
        self.assertTrue(kwargs.get("stream"))
        self.assertEqual(kwargs.get("stream_options"), {"include_usage": True})


if __name__ == "__main__":
    unittest.main()
