from __future__ import annotations

from comate_agent_sdk.llm.messages import AssistantMessage, BaseMessage, ToolMessage


def validate_tool_call_sequence(messages: list[BaseMessage], *, provider: str) -> None:
    """Validate tool-call protocol invariants before provider serialization.

    Invariant:
    - If assistant message contains tool_calls, subsequent messages must include
      all corresponding ToolMessage(s) before any non-tool message appears.
    - ToolMessage.tool_call_id must match one of required tool_call ids.
    - tool_call ids must be non-empty and unique across the provider payload.
    - each tool_call id must receive exactly one ToolMessage.
    """
    pending_index: int | None = None
    pending_required_ids: set[str] = set()
    pending_seen_ids: set[str] = set()
    all_tool_call_ids: set[str] = set()
    all_tool_result_ids: set[str] = set()

    for idx, message in enumerate(messages):
        if pending_required_ids and not isinstance(message, ToolMessage):
            missing_ids = sorted(pending_required_ids - pending_seen_ids)
            raise ValueError(
                _build_invariant_error(
                    provider=provider,
                    reason=(
                        "tool_calls must be followed by consecutive tool messages "
                        f"until all results arrive; encountered role={message.role!r}"
                    ),
                    index=pending_index if pending_index is not None else idx,
                    required_ids=sorted(pending_required_ids),
                    seen_ids=sorted(pending_seen_ids),
                    missing_ids=missing_ids,
                    messages=messages,
                )
            )

        if isinstance(message, ToolMessage):
            tool_call_id = str(message.tool_call_id or "").strip()
            if not tool_call_id:
                raise ValueError(
                    _build_invariant_error(
                        provider=provider,
                        reason="tool result has empty tool_call_id",
                        index=idx,
                        required_ids=sorted(pending_required_ids),
                        seen_ids=sorted(pending_seen_ids),
                        missing_ids=sorted(pending_required_ids - pending_seen_ids),
                        messages=messages,
                    )
                )
            if tool_call_id in all_tool_result_ids:
                raise ValueError(
                    _build_invariant_error(
                        provider=provider,
                        reason=f"duplicate tool result for tool_call_id={tool_call_id!r}",
                        index=pending_index if pending_index is not None else idx,
                        required_ids=sorted(pending_required_ids),
                        seen_ids=sorted(pending_seen_ids),
                        missing_ids=sorted(pending_required_ids - pending_seen_ids),
                        messages=messages,
                    )
                )
            if not pending_required_ids:
                raise ValueError(
                    _build_invariant_error(
                        provider=provider,
                        reason=f"orphan tool result with tool_call_id={tool_call_id!r}",
                        index=idx,
                        required_ids=[],
                        seen_ids=[],
                        missing_ids=[],
                        messages=messages,
                    )
                )
            if tool_call_id not in pending_required_ids:
                raise ValueError(
                    _build_invariant_error(
                        provider=provider,
                        reason=f"unexpected tool_call_id={tool_call_id!r} in tool result block",
                        index=pending_index if pending_index is not None else idx,
                        required_ids=sorted(pending_required_ids),
                        seen_ids=sorted(pending_seen_ids),
                        missing_ids=sorted(pending_required_ids - pending_seen_ids),
                        messages=messages,
                    )
                )

            pending_seen_ids.add(tool_call_id)
            all_tool_result_ids.add(tool_call_id)
            if pending_required_ids.issubset(pending_seen_ids):
                pending_index = None
                pending_required_ids = set()
                pending_seen_ids = set()
            continue

        if not isinstance(message, AssistantMessage):
            continue
        if not message.tool_calls:
            continue

        required_ids: set[str] = set()
        for tool_call in message.tool_calls:
            tool_call_id = str(tool_call.id or "").strip()
            if not tool_call_id:
                raise ValueError(
                    _build_invariant_error(
                        provider=provider,
                        reason="assistant tool_call has empty id",
                        index=idx,
                        required_ids=sorted(required_ids),
                        seen_ids=[],
                        missing_ids=[],
                        messages=messages,
                    )
                )
            if tool_call_id in required_ids:
                raise ValueError(
                    _build_invariant_error(
                        provider=provider,
                        reason=f"duplicate tool_call id in assistant message: {tool_call_id!r}",
                        index=idx,
                        required_ids=sorted(required_ids),
                        seen_ids=[],
                        missing_ids=[],
                        messages=messages,
                    )
                )
            if tool_call_id in all_tool_call_ids:
                raise ValueError(
                    _build_invariant_error(
                        provider=provider,
                        reason=f"duplicate tool_call id across messages: {tool_call_id!r}",
                        index=idx,
                        required_ids=sorted(required_ids),
                        seen_ids=[],
                        missing_ids=[],
                        messages=messages,
                    )
                )
            required_ids.add(tool_call_id)

        all_tool_call_ids.update(required_ids)
        pending_index = idx
        pending_required_ids = required_ids
        pending_seen_ids = set()

    if pending_required_ids:
        missing_ids = sorted(pending_required_ids - pending_seen_ids)
        raise ValueError(
            _build_invariant_error(
                provider=provider,
                reason="missing tool result messages for assistant tool_calls",
                index=pending_index if pending_index is not None else len(messages) - 1,
                required_ids=sorted(pending_required_ids),
                seen_ids=sorted(pending_seen_ids),
                missing_ids=missing_ids,
                messages=messages,
            )
        )


def _build_invariant_error(
    *,
    provider: str,
    reason: str,
    index: int,
    required_ids: list[str],
    seen_ids: list[str],
    missing_ids: list[str],
    messages: list[BaseMessage],
) -> str:
    excerpt = _format_message_excerpt(messages, center=index, radius=4)
    return (
        f"[{provider}] Invalid tool-call message sequence: {reason}. "
        f"assistant_index={index}, required_ids={required_ids}, seen_ids={seen_ids}, missing_ids={missing_ids}. "
        f"Recent messages: {excerpt}"
    )


def _format_message_excerpt(messages: list[BaseMessage], *, center: int, radius: int) -> str:
    start = max(0, center - radius)
    end = min(len(messages), center + radius + 1)
    parts: list[str] = []
    for idx in range(start, end):
        message = messages[idx]
        if isinstance(message, AssistantMessage) and message.tool_calls:
            tool_ids = [tc.id for tc in message.tool_calls]
            parts.append(f"{idx}:assistant(tool_calls={tool_ids})")
            continue
        if isinstance(message, ToolMessage):
            parts.append(f"{idx}:tool(tool_call_id={message.tool_call_id!r})")
            continue
        parts.append(f"{idx}:{message.role}")
    return " | ".join(parts)
