import re
from dataclasses import dataclass
from typing import Any

from comate_agent_sdk.llm.anthropic.like import ChatAnthropicLike
from comate_agent_sdk.llm.base import ToolChoice, ToolDefinition
from comate_agent_sdk.llm.messages import (
    BaseMessage,
    ContentPartRedactedThinkingParam,
    ContentPartTextParam,
    ContentPartThinkingParam,
)
from comate_agent_sdk.llm.views import ChatInvokeCompletion, ChatInvokeUsage
from comate_agent_sdk.tokens.custom_pricing import (
    resolve_max_input_tokens_from_custom_pricing,
)

_MINIMAX_TOOL_CALL_BLOCK_RE = re.compile(
    r"<minimax:tool_call\b[^>]*>.*?</minimax:tool_call>",
    re.IGNORECASE | re.DOTALL,
)
_MINIMAX_TOOL_CALL_TAG_RE = re.compile(
    r"</?minimax:tool_call\b[^>]*>",
    re.IGNORECASE,
)
_MINIMAX_TOOL_CALL_TRAILING_FRAGMENT_RE = re.compile(
    r"(^|\n)\s*[A-Za-z_][A-Za-z0-9_:-]{0,31}\s*</minimax:tool_call>\s*(?=\n|$)",
    re.IGNORECASE,
)
_BLANK_LINE_RE = re.compile(r"\n{3,}")


@dataclass
class ChatMiniMax(ChatAnthropicLike):
    """MiniMax Anthropic-compatible provider.

    MiniMax-specific quirks vs standard Claude:
    - thinking block response objects are not instances of Anthropic SDK's ThinkingBlock,
      so isinstance(block, ThinkingBlock) fails → use duck-typing via block.type instead.
      Signatures ARE returned via signature_delta and are properly captured by AnthropicStreamState.
    - no prompt-caching beta header
    """

    prompt_cache_beta: str | None = None  # MiniMax 不支持 Anthropic prompt-caching beta

    @property
    def provider(self) -> str:
        return "minimax"

    def get_context_window(self) -> int | None:
        """Resolve MiniMax context window from custom pricing data."""
        return resolve_max_input_tokens_from_custom_pricing(str(self.model))

    def _extract_thinking(self, response):
        """MiniMax response objects are not Anthropic SDK ThinkingBlock instances.
        Duck-type via block.type to avoid isinstance failure."""
        thinking_parts, redacted_parts = [], []
        for block in response.content:
            t = getattr(block, "type", None)
            if t == "thinking":
                thinking_parts.append(getattr(block, "thinking", "") or "")
            elif t == "redacted_thinking":
                redacted_parts.append(getattr(block, "data", "") or "")
        return (
            "\n".join(thinking_parts) or None,
            "\n".join(redacted_parts) or None,
        )

    def _get_usage(self, response) -> ChatInvokeUsage | None:
        """MiniMax usage: true prompt = input + cache_read + cache_creation."""
        u = response.usage
        cache_read = getattr(u, "cache_read_input_tokens", None) or 0
        cache_creation = getattr(u, "cache_creation_input_tokens", None) or 0
        input_tokens = u.input_tokens
        output_tokens = u.output_tokens
        total_prompt = input_tokens + cache_read + cache_creation
        return ChatInvokeUsage(
            prompt_tokens=total_prompt,
            completion_tokens=output_tokens,
            total_tokens=total_prompt + output_tokens,
            prompt_cached_tokens=cache_read or None,
            prompt_cache_creation_tokens=cache_creation or None,
            prompt_image_tokens=None,
        )

    @staticmethod
    def _sanitize_text_fragment(text: str) -> str:
        """Remove MiniMax tool-call protocol residue that may leak into text blocks."""
        cleaned = str(text or "")
        if "minimax:tool_call" not in cleaned.lower():
            return cleaned

        cleaned = _MINIMAX_TOOL_CALL_BLOCK_RE.sub("", cleaned)
        cleaned = _MINIMAX_TOOL_CALL_TRAILING_FRAGMENT_RE.sub(r"\1", cleaned)
        cleaned = _MINIMAX_TOOL_CALL_TAG_RE.sub("", cleaned)
        cleaned = _BLANK_LINE_RE.sub("\n\n", cleaned)
        return cleaned.strip()

    def _extract_text_content(self, response) -> str | None:
        """MiniMax may leak XML-like tool protocol tags into text blocks."""
        if not getattr(response, "content", None):
            return None

        text_parts: list[str] = []
        for block in response.content:
            if getattr(block, "type", None) != "text":
                continue
            cleaned = self._sanitize_text_fragment(getattr(block, "text", "") or "")
            if cleaned:
                text_parts.append(cleaned)

        return "\n".join(text_parts) if text_parts else None

    def normalize_stream_completion(
        self,
        result: ChatInvokeCompletion,
        last_raw_usage: Any | None = None,
    ) -> ChatInvokeCompletion:
        """Apply MiniMax provider-specific cleanup to a streamed completion.

        ``last_raw_usage`` 由 agent 层 ``_normalize_stream_completion_for_llm``
        钩子统一传入；MiniMax 走 AnthropicStreamState，usage 已在
        ``_apply_usage_delta`` 阶段累计完成，此处不需要再次补偿，仅为契合
        hook 调用形态而保留参数。
        """
        raw_blocks = []
        if result.raw_content_blocks:
            for block in result.raw_content_blocks:
                if isinstance(block, ContentPartTextParam):
                    cleaned = self._sanitize_text_fragment(block.text)
                    if cleaned:
                        raw_blocks.append(ContentPartTextParam(text=cleaned))
                elif isinstance(block, ContentPartThinkingParam):
                    raw_blocks.append(
                        ContentPartThinkingParam(
                            thinking=block.thinking,
                            signature=block.signature or "",
                        )
                    )
                elif isinstance(block, ContentPartRedactedThinkingParam):
                    raw_blocks.append(ContentPartRedactedThinkingParam(data=block.data))

        text_parts = [
            block.text for block in raw_blocks if isinstance(block, ContentPartTextParam)
        ]
        content = "\n".join(text_parts) if text_parts else None

        return result.model_copy(
            update={
                "content": content,
                "raw_content_blocks": raw_blocks or None,
            }
        )

    async def ainvoke(
        self,
        messages: list[BaseMessage],
        tools: list[ToolDefinition] | None = None,
        tool_choice: ToolChoice | None = None,
        **kwargs: Any,
    ) -> ChatInvokeCompletion:
        """Invoke via the shared Anthropic stream path, then apply MiniMax cleanup."""
        result = await super().ainvoke(messages, tools, tool_choice, **kwargs)
        return self.normalize_stream_completion(result)

    @staticmethod
    def _build_structured_content(response):
        """Same duck-typing fix for non-streaming path; getattr guards against missing attribute."""
        if not response.content:
            return None
        blocks = []
        for block in response.content:
            t = getattr(block, "type", None)
            if t == "text":
                cleaned = ChatMiniMax._sanitize_text_fragment(getattr(block, "text", "") or "")
                if cleaned:
                    blocks.append(ContentPartTextParam(text=cleaned))
            elif t == "thinking":
                blocks.append(
                    ContentPartThinkingParam(
                        thinking=getattr(block, "thinking", ""),
                        signature=getattr(block, "signature", "") or "",
                    )
                )
            elif t == "redacted_thinking":
                blocks.append(
                    ContentPartRedactedThinkingParam(data=getattr(block, "data", ""))
                )
        return blocks or None
