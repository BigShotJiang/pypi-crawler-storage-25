from comate_agent_sdk.subagent.models import AgentDefinition
from comate_agent_sdk.prompts import load_prompt

PROMPT = load_prompt("subagent/plan.md")

description = "Software architect. Designs implementation strategies, identifies critical files, considers architectural trade-offs. Use before starting multi-phase tasks."

PlanAgent = AgentDefinition(
    name="Plan",  # 唯一标识（用于 Task(subagent_type="example")）
    description=description,  # LLM 可见的描述
    prompt=PROMPT,  # 系统提示
    tools=[
        "Read",
        "Grep",
        "Bash",
        "Glob",
        "LS",
    ],  # None=继承父agent全部工具, ["Read","Grep"]=指定工具
    allow_team_coordination=True,
    skills=None,  # None=继承父agent全部skills, ["skill1"]=指定skills
    extra_write_roots=(),
    model="opus",  # None=继承, "sonnet"/"opus"/"haiku"
    level="HIGH",  # None=继承, "LOW"/"MID"/"HIGH"
    max_iterations=100,  # 最大迭代次数
    timeout=None,  # 超时（秒），None=不限
    source="builtin",  # 固定为 "builtin"，不要修改
)
