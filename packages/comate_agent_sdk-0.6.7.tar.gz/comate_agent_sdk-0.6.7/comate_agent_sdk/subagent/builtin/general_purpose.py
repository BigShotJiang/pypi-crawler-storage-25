from comate_agent_sdk.subagent.models import AgentDefinition
from comate_agent_sdk.prompts import load_prompt, render_prompt

_SYSTEM_ROLE = (
    "You are a Comate worker agent that executes coding tasks "
    "assigned by the orchestrator agent."
)

PROMPT = render_prompt(
    load_prompt("subagent/general_purpose.md"),
    variables={"SYSTEM_ROLE": _SYSTEM_ROLE},
    source="subagent/general_purpose.md",
)

description = (
    "Worker agent for executing implementation tasks: editing code, running commands, "
    "fixing bugs, writing tests, refactoring. Has file read/write and shell access. "
    "Use as the default for tasks that require making changes."
)


GeneralPurposeAgent = AgentDefinition(
    name="general-purpose",
    description=description,
    prompt=PROMPT,
    tools=["Read", "Grep", "Bash", "Glob", "LS", "Edit", "Write"],
    skills=None,        # 继承父 agent 全部 skills
    shared_auto_memory=True,
    model="sonnet",     # MID 档，通用执行任务
    level="MID",
    max_iterations=200,
    timeout=None,
    source="builtin",
)
