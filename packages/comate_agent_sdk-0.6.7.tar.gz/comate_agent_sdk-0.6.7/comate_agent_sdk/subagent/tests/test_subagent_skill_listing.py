"""subagent skill listing 反映筛选后 skills。"""

from __future__ import annotations

from comate_agent_sdk.context import ContextIR
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.skill.execution import rebuild_skill_tool
from comate_agent_sdk.skill.models import SkillDefinition


def test_subagent_skill_listing_reflects_filtered_skills() -> None:
    class FakeSubagent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._runtime_state = type("S", (), {})()
            self._runtime_state.skills = [
                SkillDefinition(name="b", description="visible", prompt="p"),
            ]
            self._runtime_state.tools = []
            self._tool_map = {}
            self._is_subagent = True
            self.is_team_member = False
            self.config = type("C", (), {"disallowed_tools": ()})()

    subagent = FakeSubagent()
    rebuild_skill_tool(subagent)  # type: ignore[arg-type]

    listing = subagent._context.session_state.find_one_by_type(ItemType.SKILL_LISTING)
    assert listing is not None
    assert "- b: visible" in listing.content_text
    assert "- a:" not in listing.content_text
    assert "- c:" not in listing.content_text
