import unittest

from comate_agent_sdk.subagent.builtin.explorer import ExplorerAgent
from comate_agent_sdk.subagent.builtin.general_purpose import GeneralPurposeAgent
from comate_agent_sdk.subagent.builtin.plan import PlanAgent


class TestBuiltinGeneralPurpose(unittest.TestCase):
    def test_general_purpose_prompt_is_rendered_from_template(self) -> None:
        self.assertIn("You are a Comate worker agent", GeneralPurposeAgent.prompt)
        self.assertIn("<working_principles>", GeneralPurposeAgent.prompt)
        self.assertNotIn("{{SYSTEM_ROLE}}", GeneralPurposeAgent.prompt)

    def test_explorer_prompt_is_loaded_from_template(self) -> None:
        self.assertIn("READ-ONLY exploration task", ExplorerAgent.prompt)
        self.assertIn("Return file paths as absolute paths", ExplorerAgent.prompt)

    def test_plan_prompt_is_loaded_from_template(self) -> None:
        self.assertIn("READ-ONLY planning task", PlanAgent.prompt)
        self.assertIn("### Critical Files for Implementation", PlanAgent.prompt)

    def test_plan_prompt_dedicated_tools_match_definition(self) -> None:
        self.assertIn("LS (browse directory)", PlanAgent.prompt)
        self.assertIn("LS", PlanAgent.tools or [])

    def test_general_purpose_has_fixed_execution_tool_set(self) -> None:
        self.assertEqual(
            GeneralPurposeAgent.tools,
            ["Read", "Grep", "Bash", "Glob", "LS", "Edit", "Write"],
        )

    def test_general_purpose_description_matches_fixed_execution_tools(self) -> None:
        self.assertIn("file read/write and shell access", GeneralPurposeAgent.description)

    def test_general_purpose_write_tool_guidance_is_direct(self) -> None:
        self.assertIn("Use Edit for targeted replacements", GeneralPurposeAgent.prompt)
        self.assertNotIn("When available", GeneralPurposeAgent.prompt)


if __name__ == "__main__":
    unittest.main(verbosity=2)
