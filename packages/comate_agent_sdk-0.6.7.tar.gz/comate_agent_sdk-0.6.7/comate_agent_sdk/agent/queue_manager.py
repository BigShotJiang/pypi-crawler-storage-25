from __future__ import annotations

import asyncio
import logging
import threading
import uuid
from collections.abc import Awaitable, Callable, Mapping, Sequence
from datetime import datetime, timezone
from typing import Any

from comate_agent_sdk.agent.events import (
	AgentEvent,
	QueueDirtyEvent,
	QueueDirtyReason,
)
from comate_agent_sdk.agent.queue_types import MessageOrigin, QueuedMessage

logger = logging.getLogger("comate_agent_sdk.agent.queue_manager")

_DEFAULT_QUEUE_MAX_SIZE = 100


class QueueManagerError(Exception):
	pass


class QueueManagerClosedError(QueueManagerError):
	pass


class QueueManagerFullError(QueueManagerError):
	pass


class QueueManager:
	def __init__(
		self,
		*,
		event_emitter: Callable[[AgentEvent], Awaitable[None]] | None = None,
	) -> None:
		self._lock = threading.RLock()
		self._messages: list[QueuedMessage] = []
		self._index: dict[str, int] = {}
		self._closed = False
		self._loop: asyncio.AbstractEventLoop | None = None
		self._wakeup_event: asyncio.Event | None = None
		self._event_emitter = event_emitter
		self._revision = 0

	def bind_to_running_loop(self) -> None:
		loop = asyncio.get_running_loop()
		with self._lock:
			if (
				self._loop is not None
				and self._loop is not loop
				and not self._loop.is_closed()
			):
				raise RuntimeError("QueueManager is already bound to a different event loop")
			if self._loop is loop and self._wakeup_event is not None:
				return
			self._loop = loop
			self._wakeup_event = asyncio.Event()

	def enqueue(
		self,
		content,
		*,
		origin: MessageOrigin,
		origin_metadata: Mapping[str, Any] | None = None,
	) -> str:
		with self._lock:
			if self._closed:
				raise QueueManagerClosedError("QueueManager is closed")
			if len(self._messages) >= _DEFAULT_QUEUE_MAX_SIZE:
				raise QueueManagerFullError("QueueManager queue is full")
			message = QueuedMessage(
				message_id=uuid.uuid4().hex,
				content=content,
				origin=origin,
				enqueued_at=datetime.now(timezone.utc),
				origin_metadata=origin_metadata,
			)
			self._messages.append(message)
			self._index[message.message_id] = len(self._messages) - 1
			self._schedule_dirty(
				QueueDirtyReason.ENQUEUED,
				(message,),
			)
			return message.message_id

	def peek(self) -> tuple[QueuedMessage, ...]:
		with self._lock:
			return tuple(self._messages)

	def cancel(self, message_id: str) -> bool:
		with self._lock:
			index = self._index.get(message_id)
			if index is None:
				return False
			message = self._messages.pop(index)
			self._rebuild_index()
			self._schedule_dirty(QueueDirtyReason.CANCELLED, (message,))
			return True

	def cancel_many(self, message_ids: Sequence[str]) -> int:
		id_set = set(message_ids)
		if not id_set:
			return 0
		with self._lock:
			cancelled: list[QueuedMessage] = []
			kept: list[QueuedMessage] = []
			for message in self._messages:
				if message.message_id in id_set:
					cancelled.append(message)
				else:
					kept.append(message)
			if not cancelled:
				return 0
			self._messages = kept
			self._rebuild_index()
			self._schedule_dirty(QueueDirtyReason.CANCELLED, tuple(cancelled))
			return len(cancelled)

	def clear(self) -> int:
		with self._lock:
			cleared = tuple(self._messages)
			if not cleared:
				return 0
			self._messages.clear()
			self._index.clear()
			self._schedule_dirty(QueueDirtyReason.CLEARED, cleared)
			return len(cleared)

	def close(self) -> None:
		with self._lock:
			if self._closed:
				return
			self._closed = True
			self._revision += 1
			self._schedule_wakeup()

	def peek_for_injection(self) -> tuple[QueuedMessage, ...]:
		return self.peek()

	def consume_batch(
		self,
		message_ids: Sequence[str],
		*,
		emit_dirty: bool = True,
	) -> tuple[QueuedMessage, ...]:
		id_set = set(message_ids)
		if not id_set:
			return ()
		with self._lock:
			consumed: list[QueuedMessage] = []
			kept: list[QueuedMessage] = []
			for message in self._messages:
				if message.message_id in id_set:
					consumed.append(message)
				else:
					kept.append(message)
			if not consumed:
				return ()
			self._messages = kept
			self._rebuild_index()
			if emit_dirty:
				self._schedule_dirty(QueueDirtyReason.CONSUMED, tuple(consumed))
			else:
				self._revision += 1
				self._schedule_wakeup()
			return tuple(consumed)

	def requeue_at_head(self, messages: Sequence[QueuedMessage]) -> None:
		if not messages:
			return
		with self._lock:
			message_ids = {message.message_id for message in messages}
			self._messages = list(messages) + [
				message for message in self._messages if message.message_id not in message_ids
			]
			self._rebuild_index()

	def revision(self) -> int:
		with self._lock:
			return self._revision

	async def wait_non_empty_or_closed(self) -> bool:
		self.bind_to_running_loop()
		while True:
			with self._lock:
				if self._messages:
					return True
				if self._closed:
					return False
				wakeup = self._wakeup_event
				if wakeup is None:
					raise RuntimeError("QueueManager wakeup event is not bound")
				wakeup.clear()
			await wakeup.wait()

	async def wait_changed_or_closed(self, *, since_revision: int) -> bool:
		self.bind_to_running_loop()
		while True:
			with self._lock:
				if self._revision != since_revision:
					return True
				if self._closed:
					return False
				wakeup = self._wakeup_event
				if wakeup is None:
					raise RuntimeError("QueueManager wakeup event is not bound")
				wakeup.clear()
			await wakeup.wait()

	def _rebuild_index(self) -> None:
		self._index = {
			message.message_id: index
			for index, message in enumerate(self._messages)
		}

	def _schedule_dirty(
		self,
		reason: QueueDirtyReason,
		messages: tuple[QueuedMessage, ...],
	) -> None:
		self._revision += 1
		event = QueueDirtyEvent(
			reason=reason,
			queue_size=len(self._messages),
			message_ids=tuple(message.message_id for message in messages),
			origins=tuple(message.origin for message in messages),
		)
		self._schedule_wakeup(event)

	def _schedule_wakeup(self, event: QueueDirtyEvent | None = None) -> None:
		loop = self._loop
		if loop is None:
			return
		try:
			loop.call_soon_threadsafe(self._notify_loop_thread, event)
		except RuntimeError:
			logger.exception("Failed to schedule QueueManager wakeup")

	def _notify_loop_thread(self, event: QueueDirtyEvent | None) -> None:
		if self._wakeup_event is not None:
			self._wakeup_event.set()
		if event is None or self._event_emitter is None:
			return
		try:
			task = asyncio.create_task(self._event_emitter(event))
		except Exception:
			logger.exception("Failed to emit QueueDirtyEvent")
			return
		task.add_done_callback(self._log_event_task_failure)

	@staticmethod
	def _log_event_task_failure(task: asyncio.Task[None]) -> None:
		try:
			task.result()
		except Exception:
			logger.exception("QueueDirtyEvent emitter failed")
