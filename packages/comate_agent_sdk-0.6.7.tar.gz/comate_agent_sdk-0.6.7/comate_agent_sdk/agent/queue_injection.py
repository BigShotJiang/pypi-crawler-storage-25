from __future__ import annotations

from collections.abc import Sequence

from comate_agent_sdk.agent.queue_types import MessageOrigin, QueuedMessage
from comate_agent_sdk.prompts import load_prompt, render_prompt

_PROMPT_BY_ORIGIN = {
	MessageOrigin.HUMAN: "agent/queued_message/human.md",
	MessageOrigin.EXTERNAL: "agent/queued_message/external.md",
	MessageOrigin.COORDINATOR: "agent/queued_message/coordinator.md",
	MessageOrigin.TASK_NOTIFICATION: "agent/queued_message/task_notification.md",
}


def compose_injection_blocks(queued: Sequence[QueuedMessage]) -> list[dict]:
	blocks: list[dict] = []
	for message in queued:
		blocks.append(
			{
				"type": "text",
				"text": _wrap_system_reminder(_render_queued_message(message)),
			}
		)
		blocks.extend(_image_blocks(message))
	return blocks


def _render_queued_message(message: QueuedMessage) -> str:
	prompt_id = _PROMPT_BY_ORIGIN[message.origin]
	variables: dict[str, str] = {"RAW_TEXT": _raw_text(message)}
	if message.origin is MessageOrigin.EXTERNAL:
		variables["CHANNEL_SERVER"] = _external_channel_server(message)
	return render_prompt(
		load_prompt(prompt_id),
		variables=variables,
		source=prompt_id,
	)


def _raw_text(message: QueuedMessage) -> str:
	content = message.content
	if isinstance(content, str):
		return content
	return "\n".join(
		str(getattr(part, "text"))
		for part in content
		if getattr(part, "type", None) == "text"
	)


def _image_blocks(message: QueuedMessage) -> list[dict]:
	content = message.content
	if isinstance(content, str):
		return []
	return [
		part.model_dump(mode="json")
		for part in content
		if getattr(part, "type", None) == "image_url"
	]


def _external_channel_server(message: QueuedMessage) -> str:
	metadata = message.origin_metadata or {}
	server = str(metadata.get("server", "") or "").strip()
	return server or "external channel"


def _wrap_system_reminder(text: str) -> str:
	return f"<system-reminder>\n{text}\n</system-reminder>"
