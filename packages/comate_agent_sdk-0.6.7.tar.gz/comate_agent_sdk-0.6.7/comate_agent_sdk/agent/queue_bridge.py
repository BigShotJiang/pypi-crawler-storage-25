from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

from comate_agent_sdk.agent.queue_manager import QueueManager
from comate_agent_sdk.agent.queue_types import QueuedMessage


@dataclass(frozen=True)
class QueueInjectionBridge:
    trigger_message_id: str | None
    queue_manager: QueueManager
    inject_pending: bool = True

    def peek_for_injection(self) -> tuple[QueuedMessage, ...]:
        return self.queue_manager.peek_for_injection()

    def consume_batch(self, message_ids: Sequence[str]) -> tuple[QueuedMessage, ...]:
        return self.queue_manager.consume_batch(message_ids)

    def requeue_at_head(self, messages: Sequence[QueuedMessage]) -> None:
        self.queue_manager.requeue_at_head(messages)
