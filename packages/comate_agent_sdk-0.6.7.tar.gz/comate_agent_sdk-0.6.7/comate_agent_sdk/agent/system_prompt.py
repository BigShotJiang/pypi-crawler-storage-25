from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from comate_agent_sdk.agent.mode_gating import ModeVisibility
from comate_agent_sdk.prompts import load_prompt, normalize_section_text, render_prompt

logger = logging.getLogger("comate_agent_sdk.agent.system_prompt")

AUTO_MEMORY_DIR_PLACEHOLDER = "AUTO_MEMORY_DIR_PLACEHOLDER"
MEMORY_USAGE_PLACEHOLDER = "MEMORY_USAGE"
SUBAGENT_STRATEGY_PLACEHOLDER = "SUBAGENT_STRATEGY"
SKILL_STRATEGY_PLACEHOLDER = "SKILL_STRATEGY"
_DEFAULT_SYSTEM_PROMPT_TEMPLATE = load_prompt("agent/default_system_prompt.md")
_USING_YOUR_TOOLS_TEMPLATE = load_prompt("agent/using_your_tools.md")
_SESSION_GUIDANCE_TEMPLATE = load_prompt("agent/session_guidance.md")


GENERAL_ROLE = "general"
SOFTWARE_ENGINEERING_ROLE = "software_engineering"
DEFAULT_AGENT_ROLE = GENERAL_ROLE

_ROLE_OPENING_LINES: dict[str, str] = {
    GENERAL_ROLE: (
        "You are Comate, an AI-powered agent developed by AndyLee. an interactive general AI agent running on a user's computer that helps users as a general AI agent."
    ),
    SOFTWARE_ENGINEERING_ROLE: (
        "You are Comate, an AI-powered coding agent developed by AndyLee. You run locally on the user's computer and help with software engineering tasks. You are NOT related to Baidu Comate or any other product with a similar name."
    ),
}

_DEDICATED_TOOL_SUB_BULLETS: list[tuple[str, str]] = [
    ("Read", "  - To read files use Read instead of cat, head, tail, or sed"),
    ("Edit", "  - To edit files use Edit instead of sed or awk"),
    ("Write", "  - To create files use Write instead of cat with heredoc or echo redirection"),
    ("Glob", "  - To search for files use Glob instead of find or ls"),
    ("Grep", "  - To search the content of files, use Grep instead of grep or rg"),
    ("LS", "  - To browse a directory's contents use LS instead of ls"),
]
_DEDICATED_TOOL_NAMES: frozenset[str] = frozenset(
    name for name, _ in _DEDICATED_TOOL_SUB_BULLETS
)

_BASH_PREFERENCE_HEADER = (
    "- Do NOT use the Bash to run commands when a relevant dedicated tool is provided. "
    "Using dedicated tools allows the user to better understand and review your work. "
    "This is CRITICAL to assisting the user:"
)
_BASH_RESERVE_BULLET = (
    "  - Reserve using the Bash exclusively for system commands and terminal operations "
    "that require shell execution."
)
_TASK_CREATE_BULLET = (
    "- Break down and manage your work with the TaskCreate tool. "
    "This tool is helpful for planning your work and helping the user track your progress. "
    "Mark each task as completed as soon as you are done with the task. "
    "Do not batch up multiple tasks before marking them as completed."
)
_AGENT_TOOL_GUIDANCE = (
    "- Use the Agent tool with specialized agents when the task at hand matches the agent's description. "
    "Subagents are valuable for parallelizing independent queries or for protecting the main context window "
    "from excessive results, but they should not be used excessively when not needed. "
    "Importantly, avoid duplicating work that subagents are already doing - if you delegate research to a "
    "subagent, do not also perform the same searches yourself."
)
_EXPLORE_PLAN_GUIDANCE = (
    "- For simple, directed codebase searches (e.g. for a specific file/class/function) use the Glob or Grep directly.\n"
    "- For broader codebase exploration and deep research, use the Agent tool with subagent_type=Explorer. "
    "This is slower than using the Glob or Grep directly, so use this only when a simple, directed search "
    "proves to be insufficient or when your task will clearly require more than 3 queries."
)
_ASK_USER_QUESTION_GUIDANCE = (
    "- If you do not understand why the user has denied a tool call, use the AskUserQuestion to ask them."
)

_MODE_CAPABILITY_LINES: dict[str, str] = {
    "solo": "- **Solo mode** (default): You work independently, using tools directly.",
    "plan": "- **Plan mode**: For complex tasks, you create a structured plan with phases and checkpoints before execution. You can revise the plan as you progress.",
    "subagent": "- **Subagent mode**: You can spawn subagents to delegate subtasks. Subagents run in isolated contexts and report results back to you.",
    "team": "- **Team mode**: You can create a team of named teammates, assign tasks, and coordinate parallel workstreams across multiple agents.",
}

_MODE_SELECTION_LINES: dict[str, str] = {
    "solo": "- Single file edit, simple question -> Solo",
    "plan": "- Multi-step task with 3+ phases or risk of going off track -> Plan mode",
    "subagent": "- Task with independent subtasks that benefit from parallel execution -> Subagent",
    "team": "- Task requiring different roles/expertise or long-running coordination -> Team",
}


def render_using_your_tools(enabled: frozenset[str]) -> str:
    if not enabled:
        return ""

    bash_enabled = "Bash" in enabled
    has_any_dedicated = bool(enabled & _DEDICATED_TOOL_NAMES)
    bash_parent_bullet = _BASH_PREFERENCE_HEADER if bash_enabled and has_any_dedicated else ""

    sub_bullets: list[str] = []
    if bash_enabled:
        for tool_name, line in _DEDICATED_TOOL_SUB_BULLETS:
            if tool_name in enabled:
                sub_bullets.append(line)
        sub_bullets.append(_BASH_RESERVE_BULLET)

    rendered = render_prompt(
        _USING_YOUR_TOOLS_TEMPLATE,
        variables={
            "BASH_PREFERENCE_BULLET": bash_parent_bullet,
            "TOOL_PREFERENCE_SUB_BULLETS": "\n".join(sub_bullets),
            "TASK_CREATE_BULLET": _TASK_CREATE_BULLET if "TaskCreate" in enabled else "",
        },
        source="agent/using_your_tools.md",
    )
    return normalize_section_text(rendered)


def render_session_guidance(enabled: frozenset[str]) -> str:
    agent_block = _AGENT_TOOL_GUIDANCE if "Agent" in enabled else ""
    explore_block = (
        _EXPLORE_PLAN_GUIDANCE
        if "Agent" in enabled and ("Glob" in enabled or "Grep" in enabled)
        else ""
    )
    ask_block = _ASK_USER_QUESTION_GUIDANCE if "AskUserQuestion" in enabled else ""
    if not any(block.strip() for block in (agent_block, explore_block, ask_block)):
        return ""

    rendered = render_prompt(
        _SESSION_GUIDANCE_TEMPLATE,
        variables={
            "AGENT_TOOL_GUIDANCE": agent_block,
            "EXPLORE_PLAN_AGENTS_GUIDANCE": explore_block,
            "ASK_USER_QUESTION_GUIDANCE": ask_block,
        },
        source="agent/session_guidance.md",
    )
    return normalize_section_text(rendered)


def _enabled_modes(vis: ModeVisibility) -> list[str]:
    modes: list[str] = []
    if vis.solo:
        modes.append("solo")
    if vis.plan:
        modes.append("plan")
    if vis.subagent:
        modes.append("subagent")
    if vis.team:
        modes.append("team")
    return modes


def render_mode_capabilities_lines(vis: ModeVisibility) -> str:
    return "\n".join(_MODE_CAPABILITY_LINES[mode] for mode in _enabled_modes(vis))


def render_mode_selection_lines(vis: ModeVisibility) -> str:
    return "\n".join(_MODE_SELECTION_LINES[mode] for mode in _enabled_modes(vis))


def render_tool_hints(tools: list, enabled: frozenset[str]) -> str:
    lines: list[str] = []
    for tool in tools:
        name = getattr(tool, "name", None)
        if not name or name not in enabled:
            continue
        hint = getattr(tool, "prompt_hint", None)
        if not hint or not hint.strip():
            continue
        lines.append(f"- **{name}**: {hint.strip()}")
    return normalize_section_text("\n".join(lines))


def _normalize_role(role: str | None) -> str:
    if role is None:
        return DEFAULT_AGENT_ROLE
    stripped = role.strip()
    if not stripped:
        return DEFAULT_AGENT_ROLE
    # 预定义 key 做大小写归一化（"General" → "general"）
    lowered = stripped.lower()
    if lowered in _ROLE_OPENING_LINES:
        return lowered
    # 非预定义 key → 自定义 opening line，原样返回（保留原始大小写）
    return stripped


def _normalize_auto_memory_dir_for_prompt(auto_memory_dir: str) -> str:
    resolved = Path(auto_memory_dir).expanduser().resolve()
    normalized = resolved.as_posix()
    if not normalized.endswith("/"):
        normalized = f"{normalized}/"
    return normalized


def build_default_system_prompt(
    role: str | None = None,
    *,
    mode_visibility: ModeVisibility | None = None,
) -> str:
    resolved_role = _normalize_role(role)
    if resolved_role in _ROLE_OPENING_LINES:
        opening_line = _ROLE_OPENING_LINES[resolved_role]
    else:
        opening_line = resolved_role
    vis = mode_visibility or ModeVisibility()
    return render_prompt(
        _DEFAULT_SYSTEM_PROMPT_TEMPLATE,
        variables={
            "SYSTEM_ROLE_LINE": opening_line,
            "MODE_CAPABILITIES_LINES": render_mode_capabilities_lines(vis),
            "MODE_SELECTION_LINES": render_mode_selection_lines(vis),
            "PROJECT_CONTEXT": "{{PROJECT_CONTEXT}}",
            MEMORY_USAGE_PLACEHOLDER: f"{{{{{MEMORY_USAGE_PLACEHOLDER}}}}}",
            SUBAGENT_STRATEGY_PLACEHOLDER: f"{{{{{SUBAGENT_STRATEGY_PLACEHOLDER}}}}}",
            SKILL_STRATEGY_PLACEHOLDER: f"{{{{{SKILL_STRATEGY_PLACEHOLDER}}}}}",
        },
        source="agent/default_system_prompt.md",
    )


@dataclass
class SystemPromptConfig:
    """System prompt 配置

    Attributes:
        content: 系统提示内容
        mode:
            - "override": 完全覆盖 SDK 默认 prompt
            - "append": 追加到 SDK 默认 prompt 之后
    """

    content: str
    mode: Literal["override", "append"] = "override"


# 支持 str（向后兼容，等同于 override）或 SystemPromptConfig
SystemPromptType = str | SystemPromptConfig | None


def resolve_system_prompt(
    system_prompt: SystemPromptType,
    *,
    role: str | None = None,
    auto_memory_dir: str | None = None,
    mode_visibility: ModeVisibility | None = None,
) -> str:
    """解析 system_prompt 配置，返回最终的系统提示文本

    逻辑：
    - None → 带 role 的 SDK 默认 prompt
    - str → 完全覆盖（向后兼容）
    - SystemPromptConfig(mode="override") → 完全覆盖
    - SystemPromptConfig(mode="append") → 带 role 的 SDK 默认 + 用户内容
    """
    if system_prompt is None:
        prompt = build_default_system_prompt(role=role, mode_visibility=mode_visibility)
    elif isinstance(system_prompt, str):
        # 向后兼容：str 等同于 override
        prompt = system_prompt
    elif system_prompt.mode == "override":
        prompt = system_prompt.content
    else:
        default_prompt = build_default_system_prompt(
            role=role,
            mode_visibility=mode_visibility,
        )
        prompt = f"{default_prompt}\n\n{system_prompt.content}"

    if auto_memory_dir and AUTO_MEMORY_DIR_PLACEHOLDER in prompt:
        normalized_dir = _normalize_auto_memory_dir_for_prompt(auto_memory_dir)
        prompt = prompt.replace(AUTO_MEMORY_DIR_PLACEHOLDER, normalized_dir)

    return prompt


def resolve_memory_usage_prompt(auto_memory_dir: str | None) -> str:
    """解析 memory usage static header。"""
    if not auto_memory_dir:
        return ""

    normalized_dir = _normalize_auto_memory_dir_for_prompt(auto_memory_dir)
    return render_prompt(
        load_prompt("agent/memory_usage.md"),
        variables={"MEMORY_DIR_PATH": normalized_dir},
        source="agent/memory_usage.md",
    )
