from __future__ import annotations

import asyncio
import json
import logging
import time
from collections.abc import AsyncIterator
from contextlib import nullcontext
from pathlib import Path
from typing import TYPE_CHECKING

from comate_agent_sdk.agent.events import (
    AgentEvent,
    SubagentProgressEvent,
    SubagentToolCallEvent,
    SubagentToolResultEvent,
    TaskUpdatedEvent,
    TextEvent,
    ToolCallEvent,
    ToolResultEvent,
    UsageDeltaEvent,
)
from comate_agent_sdk.llm.messages import ToolCall, ToolMessage

from comate_agent_sdk.agent.interrupt import SessionRunController

from ..execution.state import RunningTaskState, TaskStreamOut

logger = logging.getLogger("comate_agent_sdk.agent")

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime


async def _iter_task_stream_events(
    agent: "AgentRuntime",
    tool_call: ToolCall,
    subagent_name: str,
    description: str,
    current_task_state: RunningTaskState | None,
    out: TaskStreamOut,
    *,
    parent_controller: "SessionRunController | None" = None,
) -> AsyncIterator[AgentEvent]:
    agent_tool = agent._tool_map.get("Agent")
    create_runtime_func = getattr(agent_tool, "_create_subagent_runtime", None)
    if create_runtime_func is None:
        out.tool_message = ToolMessage(
            tool_call_id=tool_call.id,
            tool_name="Agent",
            content="Error: Agent tool is not properly configured for streaming",
            is_error=True,
        )
        return

    try:
        parsed_args = json.loads(tool_call.function.arguments)
    except json.JSONDecodeError:
        parsed_args = {"_raw": tool_call.function.arguments}
    args = parsed_args if isinstance(parsed_args, dict) else {"_raw": tool_call.function.arguments}

    raw_subagent_type = args.get("subagent_type", "")
    subagent_type = raw_subagent_type if isinstance(raw_subagent_type, str) else str(raw_subagent_type)
    raw_prompt = args.get("prompt", "")
    prompt = raw_prompt if isinstance(raw_prompt, str) else str(raw_prompt)

    raw_team_name = args.get("team_name", "")
    if raw_team_name is None:
        raw_team_name = ""
    team_name = raw_team_name if isinstance(raw_team_name, str) else str(raw_team_name)
    raw_name_param = args.get("name", "")
    if raw_name_param is None:
        raw_name_param = ""
    name_param = raw_name_param if isinstance(raw_name_param, str) else str(raw_name_param)
    raw_isolation = args.get("isolation", "")
    if raw_isolation is None:
        raw_isolation = ""
    isolation = raw_isolation if isinstance(raw_isolation, str) else str(raw_isolation)
    raw_level = args.get("level", "")
    if raw_level is None:
        raw_level = ""
    level = raw_level if isinstance(raw_level, str) else str(raw_level)

    subagent_runtime = None
    child_controller: SessionRunController | None = None
    try:
        subagent_runtime, agent_def = await create_runtime_func(
            subagent_type,
            tool_call.id,
            team_name=team_name,
            name=name_param,
            isolation=isolation,
            level=level,
        )
        if current_task_state is not None:
            current_task_state.usage_tracking_mode = "stream"
            runtime_source_prefix = getattr(subagent_runtime, "_subagent_source_prefix", None)
            if isinstance(runtime_source_prefix, str) and runtime_source_prefix:
                current_task_state.source_prefix = runtime_source_prefix

        result_text = ""
        last_non_empty_text = ""
        tool_call_times: dict[str, float] = {}
        timeout = agent_def.timeout if agent_def and agent_def.timeout else None
        timeout_ctx = asyncio.timeout(timeout) if timeout else nullcontext()

        if parent_controller is not None:
            child_controller = parent_controller.create_child()
            subagent_runtime._run_controller = child_controller

        async with timeout_ctx:
            async for event in subagent_runtime.query_stream(prompt):
                if isinstance(event, UsageDeltaEvent):
                    from ..query_stream import _usage_belongs_to_task, _usage_delta_tokens_for_progress

                    if current_task_state is not None and _usage_belongs_to_task(event, current_task_state):
                        delta_tokens = _usage_delta_tokens_for_progress(event)
                        current_task_state.tokens += delta_tokens
                        elapsed_ms = (time.monotonic() - current_task_state.started_at_monotonic) * 1000
                        yield SubagentProgressEvent(
                            tool_call_id=tool_call.id,
                            subagent_name=subagent_name,
                            description=description,
                            status="running",
                            elapsed_ms=elapsed_ms,
                            tokens=current_task_state.tokens,
                            model_name=subagent_runtime.llm.model if subagent_runtime else "",
                        )
                    continue

                if isinstance(event, ToolCallEvent):
                    if result_text.strip():
                        last_non_empty_text = result_text.strip()
                    result_text = ""
                    tool_call_times[event.tool_call_id] = time.time()
                    yield SubagentToolCallEvent(
                        parent_tool_call_id=tool_call.id,
                        subagent_name=subagent_name,
                        tool=event.tool,
                        args=event.args,
                        tool_call_id=event.tool_call_id,
                    )
                    continue

                if isinstance(event, ToolResultEvent):
                    start_time = tool_call_times.get(event.tool_call_id, time.time())
                    duration_ms = (time.time() - start_time) * 1000
                    yield SubagentToolResultEvent(
                        parent_tool_call_id=tool_call.id,
                        subagent_name=subagent_name,
                        tool=event.tool,
                        tool_call_id=event.tool_call_id,
                        is_error=event.is_error,
                        duration_ms=duration_ms,
                    )
                    continue

                if isinstance(event, TaskUpdatedEvent):
                    yield event
                    continue

                if isinstance(event, TextEvent):
                    result_text += event.content

        worktree_dir = getattr(subagent_runtime, "_worktree_dir", None)
        worktree_branch = getattr(subagent_runtime, "_worktree_branch", "")
        if worktree_dir is not None:
            from comate_agent_sdk.subagent.agent_tool import finalize_worktree

            result_text = finalize_worktree(
                result_text, worktree_dir, Path(agent._runtime_state.cwd), worktree_branch
            )

        from comate_agent_sdk.subagent.agent_tool import SUBAGENT_NO_OUTPUT_MARKER

        _model_name = subagent_runtime.llm.model if subagent_runtime else ""
        out.tool_message = ToolMessage(
            tool_call_id=tool_call.id,
            tool_name="Agent",
            content=result_text.strip() or last_non_empty_text or SUBAGENT_NO_OUTPUT_MARKER,
            is_error=False,
            execution_meta={"model_name": _model_name} if _model_name else None,
        )
    except asyncio.TimeoutError:
        _worktree_dir = getattr(subagent_runtime, "_worktree_dir", None) if subagent_runtime else None
        _worktree_branch = getattr(subagent_runtime, "_worktree_branch", "") if subagent_runtime else ""
        if _worktree_dir is not None:
            from comate_agent_sdk.subagent.agent_tool import _cleanup_worktree

            _cleanup_worktree(_worktree_dir, Path(agent._runtime_state.cwd), _worktree_branch)

        _timeout_model = subagent_runtime.llm.model if subagent_runtime else ""
        out.tool_message = ToolMessage(
            tool_call_id=tool_call.id,
            tool_name="Agent",
            content=f"Error: Subagent '{subagent_name}' timeout after {timeout}s",
            is_error=True,
            execution_meta={"model_name": _timeout_model} if _timeout_model else None,
        )
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        _worktree_dir = getattr(subagent_runtime, "_worktree_dir", None) if subagent_runtime else None
        _worktree_branch = getattr(subagent_runtime, "_worktree_branch", "") if subagent_runtime else ""
        if _worktree_dir is not None:
            from comate_agent_sdk.subagent.agent_tool import _cleanup_worktree

            _cleanup_worktree(_worktree_dir, Path(agent._runtime_state.cwd), _worktree_branch)

        error_msg = f"Error in subagent '{subagent_name}': {exc}"
        logger.error(error_msg, exc_info=True)
        _err_model = subagent_runtime.llm.model if subagent_runtime else ""
        out.tool_message = ToolMessage(
            tool_call_id=tool_call.id,
            tool_name="Agent",
            content=error_msg,
            is_error=True,
            execution_meta={"model_name": _err_model} if _err_model else None,
        )
    finally:
        if child_controller is not None:
            child_controller.dispose()

