from __future__ import annotations

import asyncio
import json
import logging
import time
from collections import deque
from collections.abc import AsyncGenerator, AsyncIterator, Awaitable, Callable
from dataclasses import dataclass, field
from contextlib import suppress
from typing import TYPE_CHECKING, Literal

from comate_agent_sdk.agent.events import (
    AgentEvent,
    StepCompleteEvent,
    StopEvent,
    TextEvent,
    ThinkingEvent,
    UsageDeltaEvent,
)
from comate_agent_sdk.agent.external_turns import ExternalTurnInput, build_team_inbox_turn_text
from comate_agent_sdk.agent.interrupt import bridge_to_event
from comate_agent_sdk.agent.llm import _FinalLLMResponse, stream_llm_events
from comate_agent_sdk.agent.tool_exec import _coerce_tool_arguments
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import (
    AssistantMessage,
    ContentPartImageParam,
    ContentPartTextParam,
    ToolCall,
    ToolMessage,
    UserMessage,
)
from comate_agent_sdk.prompts import render_prompt

from . import loop_hooks
from .execution.state import RunningTaskState, TaskStreamOut, TurnEngineState
from .execution.stream_drain import EventDrainHub
from .execution.task_lifecycle import TaskLifecycleEmitter
from .execution.tool_execution import ToolExecutionCallbacks, execute_tool_calls
from .lifecycle import (
    fire_session_start_if_needed as _fire_session_start_if_needed,
    fire_user_prompt_submit as _fire_user_prompt_submit,
    is_interrupt_requested as _is_interrupt_requested,
)
from .policy.ask_user_repair import _emit_policy_repair_events
from .policy.stop_policy import should_continue_after_stop_block
from .policy.tool_call_interceptor import ToolCallInterceptor, is_yield_turn
from .policy.tool_policy import enforce_ask_user_exclusive_policy
from .subagent.stream_runner import _iter_task_stream_events
from ..memory_runtime import (
    RelevantMemoryPrefetch,
    consume_ready_relevant_memory_prefetch,
    start_relevant_memory_prefetch,
)
from ..memory_extract import start_background_memory_extraction

logger = logging.getLogger("comate_agent_sdk.agent")

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime
    from comate_agent_sdk.agent.interrupt import SessionRunController
    from comate_agent_sdk.agent.queue_bridge import QueueInjectionBridge
    from comate_agent_sdk.tokens.views import TokenUsageEntry


@dataclass(slots=True)
class TurnSource:
    kind: Literal["user", "team_inbox"]
    content: str | list[ContentPartTextParam | ContentPartImageParam]
    inbox_event_keys: list[str] = field(default_factory=list)


def _source_matches_prefix(*, source: str, source_prefix: str) -> bool:
    if not source or not source_prefix:
        return False
    return source == source_prefix or source.startswith(f"{source_prefix}:")


def _render_plan_mode_prompt(template: str, *, active_plan_path: str | None) -> str:
    prompt = str(template or "").strip()
    if not prompt:
        return ""

    path_text = str(active_plan_path or "").strip()
    if "{{PLAN_FILE_PATH}}" in prompt:
        return render_prompt(
            prompt,
            variables={"PLAN_FILE_PATH": path_text},
            source="agent/plan_prompt.md",
        )

    if not path_text:
        return prompt

    return (
        f"{prompt}\n\n"
        "## Active Plan File:\n"
        f"- `plan_file_path`: {path_text}\n"
        "- You MUST only use Write/Edit on this file while in Plan Mode.\n"
        "- ExitPlanMode will read this file for approval and will not create a new plan file."
    )


def _usage_belongs_to_task(event: UsageDeltaEvent, state: RunningTaskState) -> bool:
    return _source_matches_prefix(source=event.source, source_prefix=state.source_prefix)


def _usage_delta_tokens_for_progress(event: UsageDeltaEvent) -> int:
    """Subagent progress uses effective token consumption.

    We intentionally exclude cached prompt tokens to avoid inflated progress
    numbers when prompt cache hits are high.
    """
    prompt_tokens = max(int(event.delta_prompt_tokens), 0)
    cached_prompt_tokens = max(int(event.delta_prompt_cached_tokens), 0)
    completion_tokens = max(int(event.delta_completion_tokens), 0)
    prompt_new_tokens = max(prompt_tokens - cached_prompt_tokens, 0)
    return prompt_new_tokens + completion_tokens


def _resolve_task_metadata(
    *,
    tool_call_id: str,
    args: dict,
) -> tuple[str, str, str]:
    subagent_name = ""
    description = ""

    raw_name = args.get("subagent_type")
    if isinstance(raw_name, str):
        subagent_name = raw_name.strip()

    raw_desc = args.get("description")
    if isinstance(raw_desc, str):
        description = raw_desc.strip()

    if not subagent_name:
        subagent_name = "Agent"
    if not description:
        description = subagent_name

    source_prefix = f"subagent:{subagent_name}:{tool_call_id}"
    return subagent_name, description, source_prefix


def _normalize_tool_call_event_args(
    agent: "AgentRuntime",
    *,
    tool_name: str,
    raw_args: object,
) -> dict:
    if not isinstance(raw_args, dict):
        return {"_raw": str(raw_args)}

    tool = agent._tool_map.get(tool_name)
    if tool is None:
        return raw_args

    schema = tool.definition.parameters
    if not isinstance(schema, dict):
        return raw_args

    try:
        coerced = _coerce_tool_arguments(raw_args, schema)
    except Exception as exc:
        logger.debug(f"Failed to normalize ToolCallEvent args for {tool_name}: {exc}")
        return raw_args

    if isinstance(coerced, dict):
        build_observable_input = getattr(tool, "build_observable_input", None)
        if callable(build_observable_input):
            try:
                observable = build_observable_input(coerced)
            except Exception as exc:
                logger.debug(
                    f"Failed to build observable ToolCallEvent args for {tool_name}: {exc}"
                )
            else:
                if isinstance(observable, dict):
                    return observable

    if isinstance(coerced, dict):
        return coerced
    return raw_args

async def _run_stop_hook(agent: "AgentRuntime", stop_reason: str) -> bool:
    return await should_continue_after_stop_block(
        agent,
        stop_reason,
        drain_hidden_immediately=False,
    )


async def _execute_task_streaming(
    agent: "AgentRuntime",
    tool_call: ToolCall,
    meta: tuple[str, str],
    *,
    engine_state: TurnEngineState,
    iter_task_stream_events_fn: Callable[..., AsyncIterator[AgentEvent]],
    parent_controller: "SessionRunController | None" = None,
) -> ToolMessage:
    subagent_name, description = meta
    current_task_state = engine_state.running_tasks.get(tool_call.id)
    out = TaskStreamOut()
    async for event in iter_task_stream_events_fn(
        agent,
        tool_call,
        subagent_name,
        description,
        current_task_state,
        out,
        parent_controller=parent_controller,
    ):
        engine_state.subagent_event_queue.put_nowait(event)
    return out.tool_message or ToolMessage(
        tool_call_id=tool_call.id,
        tool_name="Agent",
        content="Error: streaming task produced no result",
        is_error=True,
    )


def _setup_plan_mode_context(agent: "AgentRuntime") -> None:
    mode_snapshot = agent.get_mode()
    agent._active_mode_snapshot = mode_snapshot
    agent._context.set_plan_mode(mode_snapshot == "plan")
    if mode_snapshot != "plan":
        return

    agent._context.mark_plan_mode_used()
    plan_prompt = _render_plan_mode_prompt(
        str(agent._runtime_state.plan_mode_prompt_template or ""),
        active_plan_path=agent.get_active_plan_path(),
    )
    if not plan_prompt:
        return
    if loop_hooks.has_live_reminder_rule(agent, "plan_mode_prompt"):
        return

    agent.add_hidden_system_reminder(
        plan_prompt,
        metadata={
            "origin": "system_reminder",
            "reminder_rule_ids": ["plan_mode_prompt"],
            "reminder_tools": ["PlanMode"],
        },
    )


def _build_initial_turn_sources(
    message: str | list[ContentPartTextParam | ContentPartImageParam] | ExternalTurnInput,
) -> deque[TurnSource]:
    if isinstance(message, ExternalTurnInput):
        return deque(
            [
                TurnSource(
                    kind="team_inbox",
                    content=build_team_inbox_turn_text(message.turn),
                )
            ]
        )
    return deque([TurnSource(kind="user", content=message)])


async def _inject_turn_message(agent: "AgentRuntime", turn_source: TurnSource) -> None:
    if turn_source.kind == "team_inbox":
        agent._context.add_message(
            UserMessage(
                content=str(turn_source.content),
                is_meta=True,
            ),
            item_type=ItemType.TEAM_INBOX_TURN,
            metadata={
                "origin": "team_inbox_auto_turn",
                "turn_source": "team_inbox",
                "message_count": len(turn_source.inbox_event_keys),
            },
        )
        return

    agent._context.add_message(UserMessage(content=turn_source.content))
    await _fire_user_prompt_submit(agent, turn_source.content)


# ---------------------------------------------------------------------------
# Extracted phases – called from _run_agentic_loop to keep the main loop thin
# ---------------------------------------------------------------------------

@dataclass(slots=True)
class _TextResponseResult:
    """Outcome of handling a no-tool LLM response."""
    events: list[AgentEvent]
    should_continue_loop: bool
    did_compact: bool


@dataclass(slots=True)
class _PolicyResult:
    """Outcome of applying tool-call policies."""
    events: list[AgentEvent]
    repaired: bool
    askuser_repair_attempted: bool
    tool_calls: list[ToolCall]
    assistant_msg: AssistantMessage
    tool_call_diagnostics_by_id: dict[str, dict[str, object]]


def _history_content_for_no_tool_response(response):
    raw_blocks = response.raw_content_blocks
    if isinstance(raw_blocks, list):
        for part in raw_blocks:
            part_type = getattr(part, "type", None)
            if part_type == "text" and getattr(part, "text", ""):
                return raw_blocks
            if part_type == "refusal" and getattr(part, "refusal", ""):
                return raw_blocks
        return response.content or None

    return response.content or None


async def _handle_text_response(
    agent: "AgentRuntime",
    response,
    *,
    drain_hub: "EventDrainHub",
    engine_state: TurnEngineState,
    legacy_inbox_poll_enabled: bool,
) -> _TextResponseResult:
    """Handle LLM response with no tool calls: add message, run hooks, determine stop/continue."""
    events: list[AgentEvent] = []

    history_content = _history_content_for_no_tool_response(response)
    if history_content is not None:
        assistant_msg = AssistantMessage(
            content=history_content,
            tool_calls=None,
        )
        agent._context.add_message(assistant_msg)
    else:
        logger.warning(
            "Skipping assistant history persistence for no-tool response without visible content "
            "(thinking_chars=%d)",
            len(response.thinking or ""),
        )

    after_events, did_compact = await loop_hooks.run_after_llm_response(agent, response, drain_hub)
    events.extend(after_events)

    if response.content:
        events.append(TextEvent(
            content=response.content,
            structured_output=getattr(response, "structured_output", None),
        ))

    if getattr(response, "structured_output_error", None):
        events.append(StopEvent(reason="completed", metadata={
            "structured_output_error": response.structured_output_error,
        }))
        return _TextResponseResult(events=events, should_continue_loop=False, did_compact=did_compact)

    if await _run_stop_hook(agent, "completed"):
        async for hidden_event in drain_hub.drain_hidden_events():
            events.append(hidden_event)
        return _TextResponseResult(events=events, should_continue_loop=True, did_compact=did_compact)

    async for hidden_event in drain_hub.drain_hidden_events():
        events.append(hidden_event)

    if legacy_inbox_poll_enabled:
        turn_end = await loop_hooks.run_legacy_turn_end(agent)
        if turn_end.should_stop:
            loop_hooks.send_shutdown_ack(agent, recipients=turn_end.shutdown_recipients)
            events.append(StopEvent(reason="shutdown_request"))
            return _TextResponseResult(events=events, should_continue_loop=False, did_compact=did_compact)
        if turn_end.continuation_content is not None:
            engine_state.continuation_turn = TurnSource(
                kind="team_inbox",
                content=turn_end.continuation_content,
                inbox_event_keys=turn_end.continuation_keys,
            )
            return _TextResponseResult(events=events, should_continue_loop=False, did_compact=did_compact)

    loop_hooks.send_turn_idle_notification(agent, stop_reason="completed")
    events.append(StopEvent(reason="completed"))
    return _TextResponseResult(events=events, should_continue_loop=False, did_compact=did_compact)


async def _handle_interrupted_response(
    agent: "AgentRuntime",
    response,
    *,
    drain_hub: "EventDrainHub",
) -> list[AgentEvent]:
    """Persist an interrupted partial assistant response without changing message schema."""
    events: list[AgentEvent] = []
    content = _history_content_for_no_tool_response(response)
    if content:
        assistant_msg = AssistantMessage(content=content, tool_calls=None)
        agent._context.add_message(
            assistant_msg,
            metadata={"llm_stop_reason": "interrupted"},
        )

    if response.content:
        events.append(TextEvent(content=response.content))

    async for hidden_event in drain_hub.drain_hidden_events():
        events.append(hidden_event)
    events.append(StopEvent(reason="interrupted"))
    return events


async def _apply_tool_call_policies(
    agent: "AgentRuntime",
    response,
    *,
    askuser_repair_attempted: bool,
    tool_call_interceptor: "ToolCallInterceptor",
    task_lifecycle: "TaskLifecycleEmitter",
    drain_hub: "EventDrainHub",
) -> _PolicyResult:
    """Enforce ask-user exclusive policy and tool-call interception."""
    events: list[AgentEvent] = []

    tool_calls = list(response.tool_calls or [])
    assistant_msg = AssistantMessage(
        content=response.raw_content_blocks or response.content,
        tool_calls=tool_calls,
    )

    ask_policy = await enforce_ask_user_exclusive_policy(
        agent,
        assistant_message=assistant_msg,
        tool_calls=tool_calls,
        askuser_repair_attempted=askuser_repair_attempted,
    )
    new_askuser_repair_attempted = ask_policy.askuser_repair_attempted

    if ask_policy.repaired:
        async for event in _emit_policy_repair_events(
            agent,
            tool_calls=tool_calls,
            task_lifecycle=task_lifecycle,
            drain_hub=drain_hub,
        ):
            events.append(event)
        async for hidden_event in drain_hub.drain_hidden_events():
            events.append(hidden_event)
        return _PolicyResult(
            events=events,
            repaired=True,
            askuser_repair_attempted=new_askuser_repair_attempted,
            tool_calls=tool_calls,
            assistant_msg=assistant_msg,
            tool_call_diagnostics_by_id={},
        )

    tool_calls = ask_policy.tool_calls
    assistant_msg = AssistantMessage(
        content=response.raw_content_blocks or response.content,
        tool_calls=tool_calls,
    )

    intercept_result = tool_call_interceptor.intercept(
        assistant_message=assistant_msg,
        tool_calls=tool_calls,
    )
    tool_calls = intercept_result.tool_calls
    assistant_msg = intercept_result.assistant_message

    tool_call_diagnostics_by_id: dict[str, dict[str, object]] = {}
    if tool_calls and intercept_result.dropped_calls and is_yield_turn(tool_calls[0]):
        dropped_calls = [
            {
                "tool_call_id": str(call.id or "").strip(),
                "tool_name": str(call.function.name or "").strip(),
            }
            for call in intercept_result.dropped_calls
        ]
        tool_call_diagnostics_by_id[tool_calls[0].id] = {
            "reason": "yield_turn_preempted_batch",
            "dropped_calls": dropped_calls,
        }
        logger.info(
            "YieldTurn intercepted mixed tool-call batch; dropped %d call(s)",
            len(dropped_calls),
        )

    return _PolicyResult(
        events=events,
        repaired=False,
        askuser_repair_attempted=new_askuser_repair_attempted,
        tool_calls=tool_calls,
        assistant_msg=assistant_msg,
        tool_call_diagnostics_by_id=tool_call_diagnostics_by_id,
    )


async def _run_agentic_loop(
    agent: "AgentRuntime",
    turn_source: TurnSource,
    *,
    memory_prefetch: RelevantMemoryPrefetch | None,
    engine_state: TurnEngineState,
    drain_hub: EventDrainHub,
    task_lifecycle: TaskLifecycleEmitter,
    tool_call_interceptor: ToolCallInterceptor,
    execute_task_streaming_fn: Callable[[ToolCall, tuple[str, str]], Awaitable[ToolMessage]],
    usage_poll_interval_seconds: float,
    legacy_inbox_poll_enabled: bool,
    queue_bridge: QueueInjectionBridge | None = None,
) -> AsyncIterator[AgentEvent]:
    iterations = 0
    askuser_repair_attempted = False
    initial_queue_injected = False
    llm_call_index = 0

    async def _yield_interrupted_stop() -> AsyncGenerator[AgentEvent, None]:
        async for usage_event in drain_hub.drain_usage_events():
            yield usage_event
        async for hidden_event in drain_hub.drain_hidden_events():
            yield hidden_event
        yield StopEvent(reason="interrupted")

    async def _emit_cancelled_task(tool_call_id: str) -> AsyncGenerator[AgentEvent, None]:
        state = engine_state.running_tasks.pop(tool_call_id, None)
        elapsed_ms = 0.0
        total_tokens = 0
        subagent_name = "Agent"
        description = "Agent"
        if state is not None:
            elapsed_ms = (time.monotonic() - state.started_at_monotonic) * 1000
            total_tokens = state.tokens
            subagent_name = state.subagent_name
            description = state.description
            async for event in task_lifecycle.emit_cancelled(
                tool_call_id=tool_call_id,
                subagent_name=subagent_name,
                description=description,
                elapsed_ms=elapsed_ms,
                tokens=total_tokens,
            ):
                yield event
            async for hidden_event in drain_hub.drain_hidden_events():
                yield hidden_event

        yield StepCompleteEvent(
            step_id=tool_call_id,
            status="cancelled",
            duration_ms=elapsed_ms,
        )

    def _inject_pending_queue(*, call_index: int) -> list[AgentEvent]:
        if queue_bridge is None:
            return []
        if not queue_bridge.inject_pending:
            return []
        queued = queue_bridge.peek_for_injection()
        if not queued:
            return []
        return loop_hooks.inject_queued_messages(
            agent,
            queue_bridge,
            queued,
            call_index=call_index,
        )

    while True:
        if not initial_queue_injected:
            initial_queue_injected = True
            if queue_bridge is not None:
                if queue_bridge.trigger_message_id is not None:
                    queue_bridge.consume_batch([queue_bridge.trigger_message_id])
                for event in _inject_pending_queue(call_index=0):
                    yield event

        if iterations >= agent.config.max_iterations:
            summary = await loop_hooks.run_max_iterations_summary(agent)
            async for usage_event in drain_hub.drain_usage_events():
                yield usage_event
            yield TextEvent(content=summary)
            if await _run_stop_hook(agent, "max_iterations"):
                async for hidden_event in drain_hub.drain_hidden_events():
                    yield hidden_event
                iterations = max(0, agent.config.max_iterations - 1)
                continue
            async for hidden_event in drain_hub.drain_hidden_events():
                yield hidden_event
            yield StopEvent(reason="max_iterations")
            return

        if _is_interrupt_requested(agent):
            async for event in _yield_interrupted_stop():
                yield event
            return

        iterations += 1

        before_iter_events, did_compact = await loop_hooks.run_before_iteration(agent, drain_hub)
        for event in before_iter_events:
            yield event
        if did_compact:
            iterations = 0

        for event in await loop_hooks.run_before_llm_call(agent, drain_hub):
            yield event

        if iterations > 1:
            consume_ready_relevant_memory_prefetch(agent, memory_prefetch)

        cancel_event, cancel_cleanup = bridge_to_event(agent._run_controller) if agent._run_controller else (None, lambda: None)
        try:
            stream_event_queue: asyncio.Queue[AgentEvent] = asyncio.Queue()
            llm_call_index += 1

            async def _consume_llm_stream():
                async for item in stream_llm_events(agent, cancel_event=cancel_event):
                    if isinstance(item, _FinalLLMResponse):
                        return item.response
                    await stream_event_queue.put(item)
                raise RuntimeError("LLM stream completed without final response")

            llm_task = asyncio.create_task(_consume_llm_stream())
            while True:
                async for usage_event in drain_hub.drain_usage_events():
                    yield usage_event
                while True:
                    try:
                        yield stream_event_queue.get_nowait()
                    except asyncio.QueueEmpty:
                        break
                if _is_interrupt_requested(agent) and not llm_task.done():
                    # Fallback: adapter didn't respond to cancel_event, force cancel
                    llm_task.cancel()
                    with suppress(asyncio.CancelledError):
                        await llm_task
                    async for event in _yield_interrupted_stop():
                        yield event
                    return
                done, _ = await asyncio.wait(
                    {llm_task},
                    timeout=usage_poll_interval_seconds,
                    return_when=asyncio.ALL_COMPLETED,
                )
                async for usage_event in drain_hub.drain_usage_events():
                    yield usage_event
                while True:
                    try:
                        yield stream_event_queue.get_nowait()
                    except asyncio.QueueEmpty:
                        break
                if done:
                    break

            response = await llm_task
            async for usage_event in drain_hub.drain_usage_events():
                yield usage_event
            while True:
                try:
                    yield stream_event_queue.get_nowait()
                except asyncio.QueueEmpty:
                    break
        except asyncio.CancelledError:
            async for event in _yield_interrupted_stop():
                yield event
            return
        finally:
            cancel_cleanup()

        if response.thinking:
            yield ThinkingEvent(content=response.thinking)

        if response.stop_reason == "interrupted":
            for event in await _handle_interrupted_response(
                agent,
                response,
                drain_hub=drain_hub,
            ):
                yield event
            return

        if _is_interrupt_requested(agent):
            async for event in _yield_interrupted_stop():
                yield event
            return

        # --- No-tool response: text completion ---
        if not response.has_tool_calls:
            text_result = await _handle_text_response(
                agent, response,
                drain_hub=drain_hub,
                engine_state=engine_state,
                legacy_inbox_poll_enabled=legacy_inbox_poll_enabled,
            )
            events_to_yield = text_result.events
            queue_injection_events: list[AgentEvent] = []
            if (
                queue_bridge is not None
                and not text_result.should_continue_loop
                and queue_bridge.peek_for_injection()
            ):
                terminal_event = events_to_yield[-1] if events_to_yield else None
                if (
                    isinstance(terminal_event, StopEvent)
                    and terminal_event.reason == "completed"
                    and "structured_output_error" not in terminal_event.metadata
                ):
                    queue_injection_events = _inject_pending_queue(
                        call_index=llm_call_index,
                    )
                    if queue_injection_events:
                        events_to_yield = events_to_yield[:-1]

            for event in events_to_yield:
                yield event
            if text_result.did_compact:
                iterations = 0
            if text_result.should_continue_loop:
                continue
            if queue_injection_events:
                for event in queue_injection_events:
                    yield event
                continue
            return

        if response.content:
            yield TextEvent(content=response.content)

        # --- Policy enforcement ---
        policy = await _apply_tool_call_policies(
            agent, response,
            askuser_repair_attempted=askuser_repair_attempted,
            tool_call_interceptor=tool_call_interceptor,
            task_lifecycle=task_lifecycle,
            drain_hub=drain_hub,
        )
        askuser_repair_attempted = policy.askuser_repair_attempted
        for event in policy.events:
            yield event
        if policy.repaired:
            continue

        # --- Tool execution ---
        expected_ids = [call.id for call in policy.tool_calls if str(call.id).strip()]
        agent._context.begin_tool_barrier(expected_ids)

        engine_state.stop_reason = None

        _last_yield_status = ""
        if policy.tool_calls and is_yield_turn(policy.tool_calls[0]):
            try:
                _last_yield_status = str(
                    json.loads(policy.tool_calls[0].function.arguments or "{}").get("status", "") or ""
                ).strip()
            except Exception:
                pass

        async def _before_terminal_stop(reason: str) -> None:
            if reason == "yielded":
                loop_hooks.send_turn_idle_notification(
                    agent,
                    stop_reason="yielded",
                    yield_status=_last_yield_status,
                )

        async for event in execute_tool_calls(
            agent,
            assistant_msg=policy.assistant_msg,
            tool_calls=policy.tool_calls,
            engine_state=engine_state,
            usage_poll_interval_seconds=usage_poll_interval_seconds,
            task_lifecycle=task_lifecycle,
            callbacks=ToolExecutionCallbacks(
                is_interrupt_requested=lambda: _is_interrupt_requested(agent),
                run_stop_hook=lambda reason: _run_stop_hook(agent, reason),
                normalize_tool_call_event_args=lambda tool_name, raw_args: _normalize_tool_call_event_args(
                    agent,
                    tool_name=tool_name,
                    raw_args=raw_args,
                ),
                resolve_task_metadata=lambda tool_call_id, args: _resolve_task_metadata(
                    tool_call_id=tool_call_id,
                    args=args,
                ),
                execute_task_streaming=execute_task_streaming_fn,
                emit_cancelled_task=_emit_cancelled_task,
                yield_interrupted_stop=_yield_interrupted_stop,
                before_terminal_stop=_before_terminal_stop,
            ),
            drain_hub=drain_hub,
            tool_call_diagnostics_by_id=policy.tool_call_diagnostics_by_id,
        ):
            yield event

        if engine_state.stop_reason:
            return

        after_tool_events, did_compact = await loop_hooks.run_after_llm_response(agent, response, drain_hub)
        for event in after_tool_events:
            yield event
        if did_compact:
            iterations = 0

        consume_ready_relevant_memory_prefetch(agent, memory_prefetch)
        for event in _inject_pending_queue(call_index=llm_call_index):
            yield event


async def run_query_stream(
    agent: "AgentRuntime",
    message: str | list[ContentPartTextParam | ContentPartImageParam] | ExternalTurnInput,
    *,
    queue_bridge: QueueInjectionBridge | None = None,
) -> AsyncIterator[AgentEvent]:
    """流式执行：发送消息并逐步产出事件。"""

    usage_poll_interval_seconds = 0.08
    engine_state = TurnEngineState()
    task_lifecycle = TaskLifecycleEmitter(agent)

    drain_hub = EventDrainHub(
        agent,
        usage_queue=engine_state.usage_queue,
        subagent_event_queue=engine_state.subagent_event_queue,
        running_tasks=engine_state.running_tasks,
        usage_tokens_for_progress=_usage_delta_tokens_for_progress,
        usage_belongs_to_task=_usage_belongs_to_task,
    )

    def _on_usage_entry(entry: "TokenUsageEntry") -> None:
        source = entry.source or "unknown"
        usage = entry.usage
        engine_state.usage_queue.put_nowait(
            UsageDeltaEvent(
                source=source,
                model=entry.model,
                level=entry.level,
                delta_prompt_tokens=int(usage.prompt_tokens),
                delta_prompt_cached_tokens=int(usage.prompt_cached_tokens or 0),
                delta_completion_tokens=int(usage.completion_tokens),
                delta_total_tokens=int(usage.total_tokens),
            )
        )

    usage_observer_id = agent._token_cost.subscribe_usage(_on_usage_entry)
    tool_call_interceptor = ToolCallInterceptor()

    try:
        _setup_plan_mode_context(agent)
        await _fire_session_start_if_needed(agent)
        agent.reset_stop_hook_state()
        async for hidden_event in drain_hub.drain_hidden_events():
            yield hidden_event

        turn_sources = _build_initial_turn_sources(message)
        resolve_team_inbox_delivery_mode = getattr(agent, "_resolve_team_inbox_delivery_mode", None)
        if callable(resolve_team_inbox_delivery_mode):
            legacy_inbox_poll_enabled = (
                resolve_team_inbox_delivery_mode() == "legacy_buffer"
            )
        else:
            legacy_inbox_poll_enabled = not bool(
                getattr(getattr(agent, "_team", None), "disable_legacy_inbox_poll", False)
            )

        while turn_sources:
            next_turn_source = turn_sources[0]
            last_stop_reason: str | None = None
            if legacy_inbox_poll_enabled:
                pre_turn = await loop_hooks.check_legacy_before_turn(
                    agent,
                    is_user_turn=(next_turn_source.kind == "user"),
                )
                if pre_turn.should_stop:
                    loop_hooks.send_shutdown_ack(agent, recipients=pre_turn.shutdown_recipients)
                    async for hidden_event in drain_hub.drain_hidden_events():
                        yield hidden_event
                    yield StopEvent(reason="shutdown_request")
                    return

            turn_source = turn_sources.popleft()
            await _inject_turn_message(agent, turn_source)
            async for hidden_event in drain_hub.drain_hidden_events():
                yield hidden_event

            memory_prefetch = start_relevant_memory_prefetch(agent, turn_source.content)
            engine_state.continuation_turn = None
            try:
                async for event in _run_agentic_loop(
                    agent,
                    turn_source,
                    memory_prefetch=memory_prefetch,
                    engine_state=engine_state,
                    drain_hub=drain_hub,
                    task_lifecycle=task_lifecycle,
                    tool_call_interceptor=tool_call_interceptor,
                    # 这里显式依赖引用捕获语义：
                    # engine_state / agent 会在同一 turn 生命周期内持续被原地更新，
                    # 不要把这里改成值快照，否则会打断 streaming task 的实时状态感知。
                    execute_task_streaming_fn=lambda tool_call, meta: _execute_task_streaming(
                        agent,
                        tool_call,
                        meta,
                        engine_state=engine_state,
                        iter_task_stream_events_fn=_iter_task_stream_events,
                        parent_controller=agent._run_controller,
                    ),
                    usage_poll_interval_seconds=usage_poll_interval_seconds,
                    legacy_inbox_poll_enabled=legacy_inbox_poll_enabled,
                    queue_bridge=queue_bridge,
                ):
                    if isinstance(event, StopEvent):
                        last_stop_reason = event.reason
                    yield event
            finally:
                consume_ready_relevant_memory_prefetch(agent, memory_prefetch)
                if memory_prefetch is not None:
                    memory_prefetch.cancel()
                if last_stop_reason == "completed":
                    start_background_memory_extraction(agent)

            if legacy_inbox_poll_enabled and turn_source.inbox_event_keys:
                ack_pending = getattr(agent, "ack_pending_inbox_events", None)
                if callable(ack_pending):
                    ack_pending(turn_source.inbox_event_keys)
            if engine_state.stop_reason:
                return
            if engine_state.continuation_turn is not None:
                turn_sources.append(engine_state.continuation_turn)
                engine_state.continuation_turn = None

    finally:
        agent._active_mode_snapshot = None
        agent._context.set_plan_mode(agent.get_mode() == "plan")
        agent._token_cost.unsubscribe_usage(usage_observer_id)
