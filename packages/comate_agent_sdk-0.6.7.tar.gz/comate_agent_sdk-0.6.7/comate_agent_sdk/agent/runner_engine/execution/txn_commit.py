from __future__ import annotations

from copy import deepcopy

from comate_agent_sdk.context.items import TOOL_OBSERVABLE_INPUTS_METADATA_KEY
from comate_agent_sdk.llm.messages import AssistantMessage

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime


class ToolTxnCommitter:
    """Guarantee tool transaction is committed at most once per assistant turn."""

    def __init__(
        self,
        agent: "AgentRuntime",
        *,
        assistant_message,
        tool_calls,
        assistant_metadata: dict | None = None,
    ) -> None:
        self._agent = agent
        self._assistant_message = assistant_message
        self._tool_calls = list(tool_calls)
        self._assistant_metadata = deepcopy(assistant_metadata) if isinstance(assistant_metadata, dict) else None
        self._committed = False

    @property
    def committed(self) -> bool:
        return self._committed

    def retain_calls(self, tool_calls: list) -> None:
        self._tool_calls = list(tool_calls)
        self._assistant_message = AssistantMessage(
            content=self._assistant_message.content,
            name=self._assistant_message.name,
            refusal=self._assistant_message.refusal,
            tool_calls=list(tool_calls) or None,
        )
        if not isinstance(self._assistant_metadata, dict):
            return
        retained_ids = {
            str(tool_call.id).strip()
            for tool_call in tool_calls
            if str(tool_call.id).strip()
        }
        existing = self._assistant_metadata.get(TOOL_OBSERVABLE_INPUTS_METADATA_KEY)
        if not isinstance(existing, dict):
            return
        self._assistant_metadata[TOOL_OBSERVABLE_INPUTS_METADATA_KEY] = {
            tool_call_id: value
            for tool_call_id, value in existing.items()
            if str(tool_call_id).strip() in retained_ids
        }

    async def commit_if_needed(self, results_by_id: dict) -> bool:
        if self._committed:
            return False
        messages = [self._assistant_message] + [results_by_id[call.id] for call in self._tool_calls]
        metadata_by_index = None
        if self._assistant_metadata:
            metadata_by_index = {0: self._assistant_metadata}
        self._agent._context.add_messages_atomic(
            messages,
            metadata_by_index=metadata_by_index,
        )
        self._committed = True
        return True
