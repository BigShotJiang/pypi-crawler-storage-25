"""Loop hooks: cross-cutting concerns for the agentic loop.

This module collects all non-core logic (ephemeral GC, compaction, team coordination)
so that query_stream.py's _run_agentic_loop stays focused on the core loop mechanics.
Each hook function returns its results explicitly; the loop yields them.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime
    from comate_agent_sdk.agent.events import AgentEvent
    from comate_agent_sdk.agent.queue_bridge import QueueInjectionBridge
    from comate_agent_sdk.agent.queue_types import QueuedMessage
    from .execution.stream_drain import EventDrainHub


async def run_before_iteration(
    agent: "AgentRuntime",
    drain_hub: "EventDrainHub",
) -> tuple[list["AgentEvent"], bool]:
    """Ephemeral GC + pre-compaction check at the start of each loop iteration.

    Returns (events_to_yield, did_compact). Caller resets iteration counter when did_compact.
    """
    from comate_agent_sdk.agent.ephemeral_gc import destroy_ephemeral_messages
    from .compaction import precheck_and_compact

    destroy_ephemeral_messages(agent)
    compacted, compaction_result_event, precheck_meta_events = await precheck_and_compact(agent)

    events: list[AgentEvent] = []
    async for usage_event in drain_hub.drain_usage_events():
        events.append(usage_event)
    if compaction_result_event:
        events.append(compaction_result_event)
    events.extend(precheck_meta_events)
    return events, compacted


async def run_before_llm_call(
    agent: "AgentRuntime",
    drain_hub: "EventDrainHub",
) -> list["AgentEvent"]:
    """Team coordination context injection, then drain accumulated hidden events."""
    from .team_coordination import _inject_team_coordination_context

    _inject_team_coordination_context(agent)
    events: list[AgentEvent] = []
    async for hidden_event in drain_hub.drain_hidden_events():
        events.append(hidden_event)
    return events


def inject_queued_messages(
    agent: "AgentRuntime",
    queue_bridge: "QueueInjectionBridge",
    queued: tuple["QueuedMessage", ...],
    *,
    call_index: int,
) -> list["AgentEvent"]:
    from comate_agent_sdk.agent.events import QueuedMessageInjectedEvent
    from comate_agent_sdk.agent.queue_injection import compose_injection_blocks
    from comate_agent_sdk.llm.messages import UserMessage

    if not queued:
        return []
    if agent._context.has_tool_barrier:
        return []

    blocks = compose_injection_blocks(queued)
    consumed = queue_bridge.consume_batch([message.message_id for message in queued])
    if not consumed:
        return []

    try:
        agent._context.add_message(UserMessage(content=blocks, is_meta=True))
    except Exception:
        queue_bridge.requeue_at_head(consumed)
        raise

    return [
        QueuedMessageInjectedEvent(
            message_ids=tuple(message.message_id for message in consumed),
            origins=tuple(message.origin for message in consumed),
            injected_at_turn=agent._context.turn_number,
            call_index=call_index,
            trigger_message_id=queue_bridge.trigger_message_id,
        )
    ]


async def run_max_iterations_summary(agent: "AgentRuntime") -> str:
    """Generate a summary when the agent hits max_iterations."""
    from .compaction import generate_max_iterations_summary

    return await generate_max_iterations_summary(agent)


async def run_after_llm_response(
    agent: "AgentRuntime",
    response: Any,
    drain_hub: "EventDrainHub",
) -> tuple[list["AgentEvent"], bool]:
    """Post-response compaction check (called after both tool and no-tool paths).

    Returns (events_to_yield, did_compact). Caller resets iteration counter when did_compact.
    """
    from .compaction import check_and_compact

    compacted, compaction_result_event, meta_events = await check_and_compact(agent, response)
    events: list[AgentEvent] = []
    async for usage_event in drain_hub.drain_usage_events():
        events.append(usage_event)
    if compaction_result_event:
        events.append(compaction_result_event)
    events.extend(meta_events)
    return events, compacted


@dataclass(slots=True)
class LegacyTurnEndResult:
    """Result of the legacy inbox poll at turn boundaries."""
    should_stop: bool = False
    shutdown_recipients: list[str] = field(default_factory=list)
    continuation_content: str | None = None
    continuation_keys: list[str] = field(default_factory=list)


async def check_legacy_before_turn(
    agent: "AgentRuntime",
    *,
    is_user_turn: bool,
) -> LegacyTurnEndResult:
    """Legacy inbox poll + shutdown check before a new turn begins.

    Poll only happens for user-originated turns (not team_inbox continuations).
    """
    from .team_coordination import (
        consume_buffered_team_inbox,
        has_buffered_shutdown_request,
        poll_runtime_team_inbox,
    )

    if is_user_turn:
        await poll_runtime_team_inbox(agent)
    if not has_buffered_shutdown_request(agent):
        return LegacyTurnEndResult()
    team_result = consume_buffered_team_inbox(agent)
    if team_result.shutdown_requesters:
        return LegacyTurnEndResult(
            should_stop=True,
            shutdown_recipients=list(team_result.shutdown_requesters),
        )
    return LegacyTurnEndResult()


async def run_legacy_turn_end(agent: "AgentRuntime") -> LegacyTurnEndResult:
    """Legacy inbox poll at the end of a completed turn.

    Checks for pending shutdown requests or continuation messages from team inbox.
    """
    from .team_coordination import (
        consume_buffered_team_inbox,
        notify_team_turn_complete,
        poll_runtime_team_inbox,
    )

    await poll_runtime_team_inbox(agent)
    team_result = consume_buffered_team_inbox(agent)
    if team_result.shutdown_requesters:
        return LegacyTurnEndResult(
            should_stop=True,
            shutdown_recipients=list(team_result.shutdown_requesters),
        )
    if team_result.continuation_content is not None:
        notify_team_turn_complete(agent)
        return LegacyTurnEndResult(
            continuation_content=team_result.continuation_content,
            continuation_keys=list(team_result.continuation_keys or []),
        )
    return LegacyTurnEndResult()


def send_turn_idle_notification(
    agent: "AgentRuntime",
    *,
    stop_reason: str = "completed",
    yield_status: str = "",
    last_send_to: str = "",
) -> None:
    """Notify team leader that this agent's turn is complete and it is now idle."""
    from .team_coordination import _send_team_idle_notification

    _send_team_idle_notification(
        agent,
        stop_reason=stop_reason,
        yield_status=yield_status,
        last_send_to=last_send_to,
    )


def send_shutdown_ack(
    agent: "AgentRuntime",
    *,
    recipients: list[str],
    extra_content: str = "",
) -> None:
    """Send shutdown acknowledgment to the agents that requested shutdown."""
    from .team_coordination import _send_team_shutdown_response

    _send_team_shutdown_response(agent, recipients=recipients, extra_content=extra_content)


def has_live_reminder_rule(agent: "AgentRuntime", rule_id: str) -> bool:
    """Check whether a reminder rule is already active in the current conversation."""
    from .team_coordination import _has_live_reminder_rule

    return _has_live_reminder_rule(agent, rule_id)
