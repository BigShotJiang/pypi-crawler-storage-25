from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from comate_agent_sdk.tools.decorator import Tool

logger = logging.getLogger("comate_agent_sdk.agent")

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core.runtime import AgentRuntime


def invalidate_mcp_tools(agent: "AgentRuntime", *, reason: str = "") -> None:
    agent._mcp_generation += 1
    agent._mcp_dirty = True
    if reason:
        logger.debug(f"已标记 MCP tools dirty：{reason}")


def start_mcp_preload(
    agent: "AgentRuntime",
    *,
    force: bool = False,
) -> asyncio.Task[None] | None:
    if not bool(agent.config.mcp_enabled):
        return None

    preload_task = agent._mcp_preload_task
    if preload_task is not None and not preload_task.done():
        return preload_task

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        logger.debug("跳过 MCP preload：当前没有可用的 event loop")
        return None

    async def _preload_worker() -> None:
        try:
            await agent._load_mcp_tools(force=force)
        finally:
            if agent._mcp_preload_task is preload_task_ref:
                agent._mcp_preload_task = None

    preload_task_ref = loop.create_task(
        _preload_worker(),
        name=f"agent-runtime-mcp-preload-{id(agent)}",
    )
    agent._mcp_preload_task = preload_task_ref
    return preload_task_ref


async def ensure_mcp_tools_loaded(agent: "AgentRuntime", *, force: bool = False) -> None:
    if not bool(agent.config.mcp_enabled):
        if agent._mcp_loaded:
            remove_mcp_tools_from_agent(agent)
        agent._mcp_loaded = True
        agent._mcp_dirty = False
        return

    await agent._await_existing_mcp_preload(force=force)

    if agent._mcp_loaded and not force and not agent._mcp_dirty:
        # TTL refresh check — very cheap when TTL not expired (just monotonic time comparison)
        if agent._mcp_manager is not None:
            try:
                refreshed = await agent._mcp_manager.refresh_tools_if_stale()
                if refreshed:
                    mcp_tools = agent._mcp_manager.tools
                    apply_mcp_tools_to_agent(agent, mcp_tools)
                    agent._tool_map = {
                        tool.name: tool
                        for tool in agent._runtime_state.tools
                        if isinstance(tool, Tool)
                    }
                    overview = agent._mcp_manager.build_server_instructions_text()
                    if overview:
                        meta = agent._mcp_manager.build_server_instructions_metadata()
                        agent._context.set_mcp_tools(overview, metadata=meta)
                    else:
                        try:
                            agent._context.remove_mcp_tools()
                        except Exception:
                            pass
                    new_hash = agent._mcp_manager.tools_hash
                    if new_hash != agent._mcp_tools_hash:
                        agent._mcp_tools_hash = new_hash
                        if hasattr(agent._context, "invalidate_tools_cache"):
                            try:
                                agent._context.invalidate_tools_cache()
                            except Exception:
                                pass
            except Exception as exc:
                logger.warning(f"MCP 工具 TTL 刷新失败：{exc}")
        return

    await agent._load_mcp_tools(force=force)


async def await_existing_mcp_preload(
    agent: "AgentRuntime",
    *,
    force: bool,
) -> None:
    preload_task = agent._mcp_preload_task
    if preload_task is None or preload_task.done() or force:
        return

    current_task = asyncio.current_task()
    if preload_task is current_task:
        return

    await asyncio.shield(preload_task)


async def load_mcp_tools(agent: "AgentRuntime", *, force: bool = False) -> None:
    async with agent._mcp_load_lock:
        if agent._mcp_loaded and not force and not agent._mcp_dirty:
            return

        load_generation = agent._mcp_generation

        from comate_agent_sdk.mcp.config import resolve_mcp_servers
        from comate_agent_sdk.mcp.manager import McpManager
        from comate_agent_sdk.mcp.utils import sanitize_tool_name

        servers = resolve_mcp_servers(
            agent.config.mcp_servers,
            project_root=agent._runtime_state.cwd,
        )

        if agent._tools_allowlist_mode:
            requested_mcp_tools = [
                name
                for name in getattr(agent, "_requested_tool_names", ()) or ()
                if isinstance(name, str) and name.startswith("mcp__")
            ]
            if not requested_mcp_tools:
                if agent._mcp_manager is not None:
                    try:
                        await agent._mcp_manager.aclose()  # type: ignore[union-attr]
                    except Exception as exc:
                        logger.warning(f"关闭旧 MCP manager 失败（忽略）：{exc}")
                    finally:
                        agent._mcp_manager = None
                remove_mcp_tools_from_agent(agent)
                agent._mcp_loaded = True
                if load_generation == agent._mcp_generation:
                    agent._mcp_dirty = False
                return

            requested_server_aliases: set[str] = set()
            for tool_name in requested_mcp_tools:
                parts = tool_name.split("__", 2)
                if len(parts) >= 3 and parts[1].strip():
                    requested_server_aliases.add(parts[1].strip())

            configured_server_aliases = {
                sanitize_tool_name(alias)
                for alias in servers.keys()
            }
            missing_server_aliases = sorted(
                requested_server_aliases - configured_server_aliases
            )
            if missing_server_aliases:
                logger.warning(
                    "白名单中的 MCP 工具未匹配到已配置的 MCP server: %s",
                    missing_server_aliases,
                )

            servers = {
                alias: cfg
                for alias, cfg in servers.items()
                if sanitize_tool_name(alias) in requested_server_aliases
            }

        if not servers:
            if agent._mcp_manager is not None:
                try:
                    await agent._mcp_manager.aclose()  # type: ignore[union-attr]
                except Exception as exc:
                    logger.warning(f"关闭旧 MCP manager 失败（忽略）：{exc}")
                finally:
                    agent._mcp_manager = None
            remove_mcp_tools_from_agent(agent)
            agent._mcp_loaded = True
            if load_generation == agent._mcp_generation:
                agent._mcp_dirty = False
            return

        if agent._mcp_manager is not None:
            try:
                await agent._mcp_manager.aclose()  # type: ignore[union-attr]
            except Exception as exc:
                logger.warning(f"关闭旧 MCP manager 失败（忽略）：{exc}")
            finally:
                agent._mcp_manager = None

        def _on_mcp_tools_ready(new_tools: list[Tool]) -> None:
            apply_mcp_tools_to_agent(agent, new_tools)
            agent._tool_map = {
                tool.name: tool
                for tool in agent._runtime_state.tools
                if isinstance(tool, Tool)
            }
            if agent._mcp_manager is not None:
                try:
                    overview = agent._mcp_manager.build_server_instructions_text()
                    if overview:
                        meta = agent._mcp_manager.build_server_instructions_metadata()
                        agent._context.set_mcp_tools(overview, metadata=meta)
                    else:
                        agent._context.remove_mcp_tools()
                except Exception as exc:
                    logger.warning(f"注入 MCP server instructions 到 ContextIR 失败：{exc}")
            # tools_hash change detection
            if agent._mcp_manager is not None:
                new_hash = agent._mcp_manager.tools_hash
                if new_hash != agent._mcp_tools_hash:
                    agent._mcp_tools_hash = new_hash
                    if hasattr(agent._context, "invalidate_tools_cache"):
                        try:
                            agent._context.invalidate_tools_cache()
                        except Exception:
                            pass

        manager = McpManager(servers)
        await manager.start(on_tools_ready=_on_mcp_tools_ready)
        mcp_tools = manager.tools

        if agent._runtime_state.tool_registry is not None:
            try:
                if hasattr(agent._runtime_state.tool_registry, "all") and hasattr(
                    agent._runtime_state.tool_registry,
                    "unregister",
                ):
                    for tool in agent._runtime_state.tool_registry.all():  # type: ignore[attr-defined]
                        if getattr(tool, "_comate_agent_sdk_mcp_tool", False) is True:
                            agent._runtime_state.tool_registry.unregister(tool.name)  # type: ignore[attr-defined]

                for tool in mcp_tools:
                    agent._runtime_state.tool_registry.register(tool)  # type: ignore[attr-defined]
            except Exception as exc:
                logger.warning(f"更新 tool_registry 的 MCP tools 失败：{exc}")

        apply_mcp_tools_to_agent(agent, mcp_tools)

        overview = manager.build_server_instructions_text()
        if overview:
            meta = manager.build_server_instructions_metadata()
            try:
                agent._context.set_mcp_tools(overview, metadata=meta)
            except Exception as exc:
                logger.warning(f"注入 MCP server instructions 到 ContextIR 失败：{exc}")
        else:
            try:
                agent._context.remove_mcp_tools()
            except Exception:
                pass
        # "无工具"告警仍以 mcp_tools 为准：server 可能已连上但未提供 instructions，
        # 此时 overview 为空是正常的，不意味着工具加载失败。
        if not mcp_tools and servers:
            logger.warning(
                f"配置了 {len(servers)} 个 MCP server，但未加载到任何工具。"
                "请检查 server 连接状态。"
            )

        agent._tool_map = {
            tool.name: tool
            for tool in agent._runtime_state.tools
            if isinstance(tool, Tool)
        }

        tool_names_from_list = {
            tool.name
            for tool in agent._runtime_state.tools
            if isinstance(tool, Tool)
        }
        tool_names_from_map = set(agent._tool_map.keys())
        if tool_names_from_list != tool_names_from_map:
            logger.error(
                f"工具一致性检查失败！tools={len(tool_names_from_list)}, "
                f"_tool_map={len(tool_names_from_map)}, "
                f"差异={tool_names_from_list ^ tool_names_from_map}"
            )

        mcp_tool_names = [
            tool.name
            for tool in agent._runtime_state.tools
            if isinstance(tool, Tool)
            and getattr(tool, "_comate_agent_sdk_mcp_tool", False)
        ]
        logger.info(f"MCP 工具加载完成：共 {len(mcp_tool_names)} 个工具")
        if mcp_tool_names:
            logger.debug(f"MCP 工具列表: {mcp_tool_names}")

        agent._mcp_manager = manager
        agent._mcp_loaded = True
        if load_generation == agent._mcp_generation:
            agent._mcp_dirty = False
        else:
            logger.debug("MCP 配置在加载过程中发生变化，保持 dirty 以便下一次重新加载")


def remove_mcp_tools_from_agent(agent: "AgentRuntime") -> None:
    try:
        agent._runtime_state.tools[:] = [
            tool
            for tool in agent._runtime_state.tools
            if not (
                isinstance(tool, Tool)
                and getattr(tool, "_comate_agent_sdk_mcp_tool", False) is True
            )
        ]
        agent._tool_map = {
            tool.name: tool
            for tool in agent._runtime_state.tools
            if isinstance(tool, Tool)
        }
    except Exception:
        pass

    try:
        if (
            agent._runtime_state.tool_registry is not None
            and hasattr(agent._runtime_state.tool_registry, "all")
            and hasattr(agent._runtime_state.tool_registry, "unregister")
        ):
            for tool in agent._runtime_state.tool_registry.all():  # type: ignore[attr-defined]
                if getattr(tool, "_comate_agent_sdk_mcp_tool", False) is True:
                    agent._runtime_state.tool_registry.unregister(tool.name)  # type: ignore[attr-defined]
    except Exception:
        pass

    try:
        agent._context.remove_mcp_tools()
    except Exception:
        pass


def apply_mcp_tools_to_agent(agent: "AgentRuntime", mcp_tools: list[Tool]) -> None:
    base_tools: list[Tool | str] = [
        tool
        for tool in agent._runtime_state.tools
        if not (
            isinstance(tool, Tool)
            and getattr(tool, "_comate_agent_sdk_mcp_tool", False) is True
        )
    ]

    logger.debug(
        f"_apply_mcp_tools_to_agent: "
        f"base_tools={len(base_tools)}, "
        f"mcp_tools={len(mcp_tools)}, "
        f"allowlist_mode={agent._tools_allowlist_mode}"
    )

    if agent._tools_allowlist_mode:
        # _requested_tool_names 只含白名单中的字符串声明项（不含直接传入的 Tool 实例名）。
        # MCP 工具名以 mcp__ 开头，与内置工具名天然隔离，无误匹配风险。
        allowed = set(agent._requested_tool_names)
        wildcard_prefixes = {
            name[:-1]
            for name in allowed
            if isinstance(name, str)
            and name.startswith("mcp__")
            and name.endswith("__*")
        }
        mcp_names = {t.name for t in mcp_tools}
        filtered_mcp = [
            t
            for t in mcp_tools
            if t.name in allowed
            or any(t.name.startswith(prefix) for prefix in wildcard_prefixes)
        ]

        # Warning: 白名单中声明了但当前不可用的 MCP 工具。mcp__server__* 是
        # server 级授权，不对应真实工具名，不能按 pending tool 处理。
        pending_mcp = [
            n
            for n in allowed
            if n.startswith("mcp__")
            and not n.endswith("__*")
            and n not in mcp_names
        ]
        if pending_mcp:
            logger.warning(
                f"白名单中的 MCP 工具当前不可用（server 可能仍在连接中）: {pending_mcp}"
            )

        merged: list[Tool | str] = list(base_tools) + filtered_mcp
        agent._runtime_state.tools[:] = merged
        return

    merged: list[Tool | str] = list(base_tools)
    existing_names = {tool.name for tool in merged if isinstance(tool, Tool)}
    for tool in mcp_tools:
        if tool.name not in existing_names:
            merged.append(tool)

    logger.debug(f"合并后工具数量: {len(merged)}")
    agent._runtime_state.tools[:] = merged
    logger.debug(f"赋值后 _runtime_state.tools 数量: {len(agent._runtime_state.tools)}")


async def retry_mcp_server(agent: "AgentRuntime", alias: str) -> bool:
    """Let harness trigger manual retry of a failed MCP server."""
    if agent._mcp_manager is None:
        return False
    return await agent._mcp_manager.retry_server(alias)
