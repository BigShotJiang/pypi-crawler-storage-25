import asyncio
import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.events import QueuedMessageInjectedEvent, StopEvent, TextEvent
from comate_agent_sdk.llm.messages import UserMessage
from comate_agent_sdk.llm.views import ChatInvokeCompletion


class _BlockingTextChatModel:
    def __init__(
        self,
        *,
        first_call_started: asyncio.Event,
        release_first_call: asyncio.Event,
    ) -> None:
        self.model = "fake:model"
        self.calls: list[list[object]] = []
        self._idx = 0
        self._first_call_started = first_call_started
        self._release_first_call = release_first_call

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del tools, tool_choice, kwargs
        self.calls.append(list(messages))
        self._idx += 1
        if self._idx == 1:
            self._first_call_started.set()
            await self._release_first_call.wait()
            return ChatInvokeCompletion(content="first response")
        if self._idx == 2:
            return ChatInvokeCompletion(content="second response")
        raise AssertionError(f"Unexpected ainvoke call #{self._idx}")


def _template(llm: _BlockingTextChatModel) -> Agent:
    return Agent(
        llm=llm,  # type: ignore[arg-type]
        config=AgentConfig(
            tools=(),
            agents=(),
            offload_enabled=False,
            memory_background_enabled=False,
            setting_sources=None,
        ),
    )


class TestQueueTextPathInjection(unittest.IsolatedAsyncioTestCase):
    async def test_text_path_removes_completed_stop_and_injects_queue_before_next_llm_call(self) -> None:
        first_call_started = asyncio.Event()
        release_first_call = asyncio.Event()
        llm = _BlockingTextChatModel(
            first_call_started=first_call_started,
            release_first_call=release_first_call,
        )

        with tempfile.TemporaryDirectory() as td:
            session = _template(llm).chat(cwd=Path(td) / "session")
            first_id = await session.send("first")

            async def _collect_events() -> list[object]:
                stream = session.events()
                collected: list[object] = []
                async for event in stream:
                    collected.append(event)
                    if isinstance(event, StopEvent):
                        break
                await stream.aclose()
                return collected

            collect_task = asyncio.create_task(_collect_events())
            await asyncio.wait_for(first_call_started.wait(), timeout=1)
            queued_id = await session.send("queued after text")
            release_first_call.set()
            events = await asyncio.wait_for(collect_task, timeout=2)
            await session.close()

        text_events = [event.content for event in events if isinstance(event, TextEvent)]
        self.assertEqual(text_events, ["first response", "second response"])
        stop_events = [event for event in events if isinstance(event, StopEvent)]
        self.assertEqual([event.reason for event in stop_events], ["completed"])

        injected_events = [
            event for event in events if isinstance(event, QueuedMessageInjectedEvent)
        ]
        self.assertEqual(len(injected_events), 1)
        self.assertEqual(injected_events[0].message_ids, (queued_id,))
        self.assertEqual(injected_events[0].trigger_message_id, first_id)
        self.assertEqual(injected_events[0].call_index, 1)

        self.assertEqual(session.peek_queue(), ())
        self.assertEqual(len(llm.calls), 2)
        first_call_text = "\n".join(
            message.text for message in llm.calls[0] if isinstance(message, UserMessage)
        )
        second_call_text = "\n".join(
            message.text for message in llm.calls[1] if isinstance(message, UserMessage)
        )
        self.assertNotIn("queued after text", first_call_text)
        self.assertIn("queued after text", second_call_text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
