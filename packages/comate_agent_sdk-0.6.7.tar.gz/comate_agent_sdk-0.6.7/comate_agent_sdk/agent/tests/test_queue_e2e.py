import asyncio
import json
import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.events import (
    QueuedMessageInjectedEvent,
    SessionInitEvent,
    StopEvent,
    TextEvent,
    ToolCallEvent,
)
from comate_agent_sdk.llm.messages import Function, ToolCall, UserMessage
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.tools import tool


class _RecordingChatModel:
    def __init__(self, completions: list[ChatInvokeCompletion]) -> None:
        self._completions = completions
        self._idx = 0
        self.model = "fake:model"
        self.calls: list[list[object]] = []

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del tools, tool_choice, kwargs
        self.calls.append(list(messages))
        if self._idx >= len(self._completions):
            raise AssertionError(f"Unexpected ainvoke call #{self._idx + 1}")
        completion = self._completions[self._idx]
        self._idx += 1
        return completion


class _BlockingTextChatModel:
    def __init__(
        self,
        *,
        first_call_started: asyncio.Event,
        release_first_call: asyncio.Event,
    ) -> None:
        self.model = "fake:model"
        self.calls: list[list[object]] = []
        self._idx = 0
        self._first_call_started = first_call_started
        self._release_first_call = release_first_call

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del tools, tool_choice, kwargs
        self.calls.append(list(messages))
        self._idx += 1
        if self._idx == 1:
            self._first_call_started.set()
            await self._release_first_call.wait()
            return ChatInvokeCompletion(content="first response")
        if self._idx == 2:
            return ChatInvokeCompletion(content="second response")
        raise AssertionError(f"Unexpected ainvoke call #{self._idx}")


def _runtime(llm, *, tools=()) -> Agent:  # type: ignore[no-untyped-def]
    return Agent(
        llm=llm,
        config=AgentConfig(
            tools=tuple(tools),
            agents=(),
            offload_enabled=False,
            memory_background_enabled=False,
            setting_sources=None,
        ),
    )


def _tool_call() -> ToolCall:
    return ToolCall(
        id="tc_wait_1",
        function=Function(
            name="WaitTool",
            arguments=json.dumps({}, ensure_ascii=False),
        ),
    )


class TestQueueE2E(unittest.IsolatedAsyncioTestCase):
    async def test_continuous_send_uses_first_as_trigger_and_injects_backlog(self) -> None:
        llm = _RecordingChatModel([ChatInvokeCompletion(content="ok")])
        with tempfile.TemporaryDirectory() as td:
            session = _runtime(llm).chat(cwd=Path(td) / "session")
            first_id = await session.send("first")
            second_id = await session.send("second")
            third_id = await session.send("third")

            stream = session.events()
            events: list[object] = []
            async for event in stream:
                events.append(event)
                if isinstance(event, StopEvent):
                    break
            await stream.aclose()
            await session.close()

        injected = [
            event for event in events if isinstance(event, QueuedMessageInjectedEvent)
        ]
        self.assertEqual(len(injected), 1)
        self.assertEqual(injected[0].message_ids, (second_id, third_id))
        self.assertEqual(injected[0].trigger_message_id, first_id)
        self.assertEqual(injected[0].call_index, 0)
        self.assertEqual(session.peek_queue(), ())

        user_messages = [
            message for message in llm.calls[0] if isinstance(message, UserMessage)
        ]
        self.assertEqual(len(user_messages), 2)
        self.assertFalse(user_messages[0].is_meta)
        self.assertEqual(user_messages[0].content, "first")
        self.assertTrue(user_messages[1].is_meta)
        self.assertIn("second", user_messages[1].text)
        self.assertIn("third", user_messages[1].text)

    async def test_send_during_tool_is_visible_before_next_llm_call(self) -> None:
        release_tool: asyncio.Event | None = None

        @tool("Wait until the test releases this tool.", name="WaitTool")
        async def WaitTool() -> str:
            assert release_tool is not None
            await release_tool.wait()
            return "tool done"

        llm = _RecordingChatModel(
            [
                ChatInvokeCompletion(tool_calls=[_tool_call()]),
                ChatInvokeCompletion(content="done"),
            ]
        )
        with tempfile.TemporaryDirectory() as td:
            session = _runtime(llm, tools=(WaitTool,)).chat(cwd=Path(td) / "session")
            first_id = await session.send("first")
            queued_id = ""
            release_tool = asyncio.Event()

            stream = session.events()
            events: list[object] = []
            async for event in stream:
                events.append(event)
                if isinstance(event, ToolCallEvent):
                    queued_id = await session.send("queued while tool runs")
                    release_tool.set()
                if isinstance(event, StopEvent):
                    break
            await stream.aclose()
            await session.close()

        injected = [
            event for event in events if isinstance(event, QueuedMessageInjectedEvent)
        ]
        self.assertEqual(len(injected), 1)
        self.assertEqual(injected[0].message_ids, (queued_id,))
        self.assertEqual(injected[0].trigger_message_id, first_id)
        self.assertEqual(injected[0].call_index, 1)
        self.assertEqual(session.peek_queue(), ())

        first_call_text = "\n".join(
            message.text for message in llm.calls[0] if isinstance(message, UserMessage)
        )
        second_call_text = "\n".join(
            message.text for message in llm.calls[1] if isinstance(message, UserMessage)
        )
        self.assertNotIn("queued while tool runs", first_call_text)
        self.assertIn("queued while tool runs", second_call_text)

    async def test_text_response_continues_current_turn_when_queue_is_nonempty(self) -> None:
        first_call_started = asyncio.Event()
        release_first_call = asyncio.Event()
        llm = _BlockingTextChatModel(
            first_call_started=first_call_started,
            release_first_call=release_first_call,
        )

        with tempfile.TemporaryDirectory() as td:
            session = _runtime(llm).chat(cwd=Path(td) / "session")
            first_id = await session.send("first")

            async def _collect_events() -> list[object]:
                stream = session.events()
                collected: list[object] = []
                async for event in stream:
                    collected.append(event)
                    if isinstance(event, StopEvent):
                        break
                await stream.aclose()
                return collected

            collect_task = asyncio.create_task(_collect_events())
            await asyncio.wait_for(first_call_started.wait(), timeout=1)
            queued_id = await session.send("queued after text")
            release_first_call.set()
            events = await asyncio.wait_for(collect_task, timeout=2)
            await session.close()

        self.assertEqual(
            [event.content for event in events if isinstance(event, TextEvent)],
            ["first response", "second response"],
        )
        self.assertEqual(
            [event.reason for event in events if isinstance(event, StopEvent)],
            ["completed"],
        )
        injected = [
            event for event in events if isinstance(event, QueuedMessageInjectedEvent)
        ]
        self.assertEqual(len(injected), 1)
        self.assertEqual(injected[0].message_ids, (queued_id,))
        self.assertEqual(injected[0].trigger_message_id, first_id)
        self.assertEqual(injected[0].call_index, 1)
        self.assertEqual(session.peek_queue(), ())

    async def test_close_wakes_events_consumer_and_exits(self) -> None:
        llm = _RecordingChatModel([ChatInvokeCompletion(content="unused")])
        with tempfile.TemporaryDirectory() as td:
            session = _runtime(llm).chat(cwd=Path(td) / "session")

            async def _consume() -> list[object]:
                collected: list[object] = []
                async for event in session.events():
                    collected.append(event)
                return collected

            consume_task = asyncio.create_task(_consume())
            await asyncio.sleep(0)
            await session.close()
            events = await asyncio.wait_for(consume_task, timeout=1)

        self.assertTrue(all(isinstance(event, SessionInitEvent) for event in events))
        self.assertEqual(llm.calls, [])

    async def test_direct_runtime_query_stream_does_not_require_queue_bridge(self) -> None:
        llm = _RecordingChatModel([ChatInvokeCompletion(content="hello")])
        runtime = _runtime(llm)

        events = [event async for event in runtime.query_stream("hello")]

        self.assertEqual(
            [event.content for event in events if isinstance(event, TextEvent)],
            ["hello"],
        )
        self.assertEqual(
            [event.reason for event in events if isinstance(event, StopEvent)],
            ["completed"],
        )
        self.assertEqual(
            [event for event in events if isinstance(event, QueuedMessageInjectedEvent)],
            [],
        )
        self.assertEqual(len(llm.calls), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
