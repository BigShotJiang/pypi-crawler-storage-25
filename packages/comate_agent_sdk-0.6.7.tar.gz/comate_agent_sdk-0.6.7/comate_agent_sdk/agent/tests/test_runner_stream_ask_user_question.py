import asyncio
import json
import unittest

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.events import (
    QueueDirtyEvent,
    QueueDirtyReason,
    StopEvent,
    TextEvent,
    UserQuestionEvent,
)
from comate_agent_sdk.llm.messages import Function, ToolCall, UserMessage
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.tools import tool
from comate_agent_sdk.system_tools.tools import AskUserQuestion


class _FakeChatModel:
    def __init__(self, completions: list[ChatInvokeCompletion]):
        self._completions = completions
        self._idx = 0
        self.model = "fake:model"
        self.calls: list[list[object]] = []

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del tools, tool_choice, kwargs
        self.calls.append(list(messages))
        if self._idx >= len(self._completions):
            raise AssertionError(f"Unexpected ainvoke call #{self._idx + 1}")
        completion = self._completions[self._idx]
        self._idx += 1
        return completion


class TestRunnerStreamAskUserQuestion(unittest.IsolatedAsyncioTestCase):
    async def test_query_stream_uses_raw_envelope_for_user_question_event(self) -> None:
        tool_call = ToolCall(
            id="tc_question_1",
            function=Function(
                name="AskUserQuestion",
                arguments=json.dumps(
                    {
                        "questions": [
                            {
                                "question": "Which implementation do you prefer?",
                                "header": "Impl",
                                "options": [
                                    {"label": "Plan A", "description": "Stable and explicit"},
                                    {"label": "Plan B", "description": "Smaller change set"},
                                ],
                                "multiSelect": False,
                            }
                        ]
                    },
                    ensure_ascii=False,
                ),
            ),
        )

        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(tool_calls=[tool_call]),
            ]
        )

        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(AskUserQuestion,),
                agents=(),
                offload_enabled=False,
                memory_background_enabled=False,
            ),
        )
        agent = template.create_runtime()

        events = []
        async for event in agent.query_stream("need input"):
            events.append(event)

        question_events = [e for e in events if isinstance(e, UserQuestionEvent)]
        self.assertEqual(len(question_events), 1)
        self.assertEqual(len(question_events[0].questions), 1)
        self.assertEqual(question_events[0].questions[0]["header"], "Impl")

        stop_events = [e for e in events if isinstance(e, StopEvent)]
        self.assertEqual(len(stop_events), 1)
        self.assertEqual(stop_events[0].reason, "waiting_for_input")

        tool_messages = [m for m in agent.messages if getattr(m, "role", None) == "tool"]
        self.assertEqual(len(tool_messages), 1)
        tool_message = tool_messages[0]
        self.assertIsNotNone(getattr(tool_message, "raw_envelope", None))
        self.assertIn("# AskUserQuestion", tool_message.text)

    async def test_query_stream_does_not_fallback_to_args_when_envelope_missing(self) -> None:
        @tool("Broken AskUserQuestion that returns plain text", name="AskUserQuestion")
        async def BrokenAskUserQuestion(questions: list[dict]) -> str:
            del questions
            return "plain text without envelope"

        tool_call = ToolCall(
            id="tc_question_2",
            function=Function(
                name="AskUserQuestion",
                arguments=json.dumps(
                    {
                        "questions": [
                            {
                                "question": "Should not be emitted?",
                                "header": "LegacyFallback",
                                "options": [
                                    {"label": "Yes", "description": "legacy"},
                                    {"label": "No", "description": "strict"},
                                ],
                            }
                        ]
                    },
                    ensure_ascii=False,
                ),
            ),
        )

        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(tool_calls=[tool_call]),
                ChatInvokeCompletion(content="done"),
            ]
        )
        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(BrokenAskUserQuestion,),
                agents=(),
                offload_enabled=False,
                memory_background_enabled=False,
            ),
        )
        agent = template.create_runtime()

        events = []
        async for event in agent.query_stream("need input"):
            events.append(event)

        question_events = [e for e in events if isinstance(e, UserQuestionEvent)]
        self.assertEqual(question_events, [])

        stop_events = [e for e in events if isinstance(e, StopEvent)]
        self.assertEqual(len(stop_events), 1)
        self.assertEqual(stop_events[0].reason, "completed")

    async def test_waiting_for_input_prioritizes_answer_over_existing_human_queue(self) -> None:
        question_call = ToolCall(
            id="tc_question_priority",
            function=Function(
                name="AskUserQuestion",
                arguments=json.dumps(
                    {
                        "questions": [
                            {
                                "question": "Which option?",
                                "header": "Choice",
                                "options": [
                                    {"label": "A", "description": "Option A"},
                                    {"label": "B", "description": "Option B"},
                                ],
                            }
                        ]
                    },
                    ensure_ascii=False,
                ),
            ),
        )

        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(tool_calls=[question_call]),
                ChatInvokeCompletion(content="answer processed"),
            ]
        )
        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(AskUserQuestion,),
                agents=(),
                offload_enabled=False,
                memory_background_enabled=False,
            ),
        )
        session = template.chat()
        first_id = await session.send("initial task")
        queued_before_answer_id = ""
        answer_id = ""
        completed_seen = False

        stream = session.events()
        try:
            async for event in stream:
                if isinstance(event, UserQuestionEvent):
                    queued_before_answer_id = await session.send("queued before answer")
                if isinstance(event, StopEvent) and event.reason == "waiting_for_input":
                    answer_id = await session.send("answer to ask")
                    continue
                if isinstance(event, StopEvent) and event.reason == "completed":
                    completed_seen = True
                    break
        finally:
            await stream.aclose()
            await session.close()

        self.assertTrue(completed_seen)
        self.assertNotEqual(queued_before_answer_id, "")
        self.assertNotEqual(answer_id, "")
        self.assertEqual(len(llm._completions), 2)
        self.assertEqual(llm._idx, 2)

        second_call_user_messages = [
            message for message in llm.calls[1] if isinstance(message, UserMessage)
        ]
        second_call_text = "\n".join(message.text for message in second_call_user_messages)
        non_meta_second_call = [
            message for message in second_call_user_messages if not message.is_meta
        ]

        self.assertGreaterEqual(len(non_meta_second_call), 1)
        self.assertEqual(non_meta_second_call[-1].content, "answer to ask")
        self.assertNotIn("queued before answer", second_call_text)
        self.assertEqual(
            [message.message_id for message in session.peek_queue()],
            [queued_before_answer_id],
        )
        self.assertNotIn(first_id, [message.message_id for message in session.peek_queue()])

    async def test_consumed_event_precedes_queued_trigger_text_after_question_answer(self) -> None:
        question_call = ToolCall(
            id="tc_question_consumed_order",
            function=Function(
                name="AskUserQuestion",
                arguments=json.dumps(
                    {
                        "questions": [
                            {
                                "question": "Which option?",
                                "header": "Choice",
                                "options": [
                                    {"label": "A", "description": "Option A"},
                                    {"label": "B", "description": "Option B"},
                                ],
                            }
                        ]
                    },
                    ensure_ascii=False,
                ),
            ),
        )

        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(tool_calls=[question_call]),
                ChatInvokeCompletion(content="answer processed"),
                ChatInvokeCompletion(content="queued processed"),
            ]
        )
        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(AskUserQuestion,),
                agents=(),
                offload_enabled=False,
                memory_background_enabled=False,
            ),
        )
        session = template.chat()
        await session.send("initial task")
        queued_before_answer_id = ""
        order: list[str] = []

        stream = session.events()
        try:
            try:
                async with asyncio.timeout(1):
                    async for event in stream:
                        if isinstance(event, UserQuestionEvent):
                            queued_before_answer_id = await session.send("queued before answer")
                        if isinstance(event, StopEvent) and event.reason == "waiting_for_input":
                            await session.send("answer to ask")
                            continue
                        if (
                            isinstance(event, QueueDirtyEvent)
                            and event.reason is QueueDirtyReason.CONSUMED
                            and queued_before_answer_id in event.message_ids
                        ):
                            order.append("consumed")
                        if isinstance(event, TextEvent) and event.content == "queued processed":
                            order.append("queued_text")
                        if "consumed" in order and "queued_text" in order:
                            break
            except TimeoutError:
                pass
        finally:
            await stream.aclose()
            await session.close()

        self.assertEqual(order, ["consumed", "queued_text"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
