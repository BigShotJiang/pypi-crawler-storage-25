import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.chat_session import (
	ChatSessionClosedError,
	ChatSessionQueueFullError,
)
from comate_agent_sdk.agent.interrupt import SessionRunController
from comate_agent_sdk.agent.queue_manager import _DEFAULT_QUEUE_MAX_SIZE
from comate_agent_sdk.agent.queue_types import MessageOrigin
from comate_agent_sdk.llm.views import ChatInvokeCompletion


class _FakeChatModel:
	model = "fake:model"

	@property
	def provider(self) -> str:
		return "fake"

	@property
	def name(self) -> str:
		return self.model

	async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
		del messages, tools, tool_choice, kwargs
		return ChatInvokeCompletion(content="ok")


def _template() -> Agent:
	return Agent(
		llm=_FakeChatModel(),  # type: ignore[arg-type]
		config=AgentConfig(tools=(), agents=(), offload_enabled=False),
	)


class TestChatSessionQueueApi(unittest.IsolatedAsyncioTestCase):
	async def asyncSetUp(self) -> None:
		self._tmp = tempfile.TemporaryDirectory()
		self.session = _template().chat(cwd=Path(self._tmp.name) / "session")

	async def asyncTearDown(self) -> None:
		await self.session.close()
		self._tmp.cleanup()

	async def test_send_returns_message_id_and_exposes_queue_snapshot(self) -> None:
		message_id = await self.session.send(
			"hello",
			origin=MessageOrigin.EXTERNAL,
			origin_metadata={"server": "slack"},
		)

		snapshot = self.session.peek_queue()

		self.assertEqual(len(snapshot), 1)
		self.assertEqual(snapshot[0].message_id, message_id)
		self.assertEqual(snapshot[0].content, "hello")
		self.assertIs(snapshot[0].origin, MessageOrigin.EXTERNAL)
		self.assertEqual(snapshot[0].origin_metadata, {"server": "slack"})

	async def test_cancel_cancel_many_and_clear_delegate_to_queue_manager(self) -> None:
		first_id = await self.session.send("first")
		second_id = await self.session.send("second")
		third_id = await self.session.send("third")

		self.assertTrue(self.session.cancel(first_id))
		self.assertFalse(self.session.cancel("missing"))
		self.assertEqual(
			[message.message_id for message in self.session.peek_queue()],
			[second_id, third_id],
		)

		self.assertEqual(self.session.cancel_many([third_id, "missing"]), 1)
		self.assertEqual(
			[message.message_id for message in self.session.peek_queue()],
			[second_id],
		)
		self.assertEqual(self.session.clear(), 1)
		self.assertEqual(self.session.peek_queue(), ())

	async def test_send_translates_queue_full_error(self) -> None:
		for index in range(_DEFAULT_QUEUE_MAX_SIZE):
			await self.session.send(f"message-{index}")

		with self.assertRaises(ChatSessionQueueFullError):
			await self.session.send("overflow")

	async def test_send_after_close_raises_closed_error(self) -> None:
		await self.session.close()

		with self.assertRaises(ChatSessionClosedError):
			await self.session.send("closed")

	async def test_is_busy_reflects_runtime_run_controller(self) -> None:
		self.assertFalse(self.session.is_busy())

		controller = SessionRunController()
		self.session._agent._run_controller = controller
		try:
			self.assertTrue(self.session.is_busy())
		finally:
			self.session._agent._run_controller = None


if __name__ == "__main__":
	unittest.main(verbosity=2)
