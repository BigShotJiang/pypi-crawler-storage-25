import asyncio
import unittest
from types import SimpleNamespace

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.events import StopEvent, TextEvent
from comate_agent_sdk.agent.interrupt import SessionRunController
from comate_agent_sdk.context.items import ItemType


def _openai_chunk(content: str) -> SimpleNamespace:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                delta=SimpleNamespace(content=content),
                finish_reason=None,
            )
        ],
        usage=None,
    )


class _InterruptibleStreamingLLM:
    model = "fake-openai"
    provider = "openai"

    def __init__(self) -> None:
        self.started = asyncio.Event()

    @property
    def name(self) -> str:
        return self.model

    async def astream(self, messages, tools=None, tool_choice=None, **kwargs):
        del messages, tools, tool_choice
        cancel_event = kwargs.get("cancel_event")
        yield _openai_chunk("partial text")
        self.started.set()
        while cancel_event is None or not cancel_event.is_set():
            await asyncio.sleep(0.01)
        raise asyncio.CancelledError("llm_cancel")

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):
        del messages, tools, tool_choice, kwargs
        raise AssertionError("streaming test should use astream")


class TestInterruptedPartialPersistence(unittest.IsolatedAsyncioTestCase):
    async def test_interrupted_partial_text_is_persisted_with_metadata(self) -> None:
        llm = _InterruptibleStreamingLLM()
        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                offload_enabled=False,
                memory_background_enabled=False,
            ),
        )
        agent = template.create_runtime()
        controller = SessionRunController()
        agent._run_controller = controller

        events: list[object] = []

        async def _collect() -> None:
            async for event in agent.query_stream("Hi"):
                events.append(event)

        task = asyncio.create_task(_collect())
        await asyncio.wait_for(llm.started.wait(), timeout=3.0)
        controller.interrupt()
        await asyncio.wait_for(task, timeout=3.0)

        self.assertIn(
            "partial text",
            [event.content for event in events if isinstance(event, TextEvent)],
        )
        self.assertEqual(
            [event.reason for event in events if isinstance(event, StopEvent)],
            ["interrupted"],
        )

        assistant_items = [
            item
            for item in agent._context.conversation.items
            if item.item_type == ItemType.ASSISTANT_MESSAGE
        ]
        self.assertEqual(len(assistant_items), 1)
        self.assertEqual(assistant_items[0].content_text, "partial text")
        self.assertEqual(
            assistant_items[0].metadata.get("llm_stop_reason"),
            "interrupted",
        )


if __name__ == "__main__":
    unittest.main()
