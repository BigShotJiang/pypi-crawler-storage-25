import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from comate_agent_sdk.agent.events import StopEvent
from comate_agent_sdk.agent.runner_engine.execution.state import TurnEngineState
from comate_agent_sdk.agent.runner_engine.query_stream import _handle_text_response
from comate_agent_sdk.llm.messages import ContentPartThinkingParam
from comate_agent_sdk.llm.views import ChatInvokeCompletion


class _Context:
    def __init__(self) -> None:
        self.messages = []

    def add_message(self, message) -> None:
        self.messages.append(message)


class _DrainHub:
    async def drain_hidden_events(self):
        if False:
            yield None


class TestThinkingOnlyResponseGuard(unittest.IsolatedAsyncioTestCase):
    async def test_no_tool_thinking_only_response_is_not_persisted(self) -> None:
        agent = SimpleNamespace(_context=_Context())
        response = ChatInvokeCompletion(
            content=None,
            thinking="orphan reasoning",
            raw_content_blocks=[
                ContentPartThinkingParam(thinking="orphan reasoning", signature=None),
            ],
            tool_calls=[],
            stop_reason="stop",
        )

        with (
            patch(
                "comate_agent_sdk.agent.runner_engine.query_stream.loop_hooks.run_after_llm_response",
                new=AsyncMock(return_value=([], False)),
            ),
            patch(
                "comate_agent_sdk.agent.runner_engine.query_stream._run_stop_hook",
                new=AsyncMock(return_value=False),
            ),
            patch(
                "comate_agent_sdk.agent.runner_engine.query_stream.loop_hooks.send_turn_idle_notification"
            ),
        ):
            result = await _handle_text_response(
                agent,
                response,
                drain_hub=_DrainHub(),
                engine_state=TurnEngineState(),
                legacy_inbox_poll_enabled=False,
            )

        self.assertEqual(agent._context.messages, [])
        self.assertEqual(len(result.events), 1)
        self.assertIsInstance(result.events[0], StopEvent)


if __name__ == "__main__":
    unittest.main()
