import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.events import QueuedMessageInjectedEvent, StopEvent
from comate_agent_sdk.llm.messages import UserMessage
from comate_agent_sdk.llm.views import ChatInvokeCompletion


class _RecordingChatModel:
    def __init__(self) -> None:
        self.model = "fake:model"
        self.calls: list[list[object]] = []

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del tools, tool_choice, kwargs
        self.calls.append(list(messages))
        return ChatInvokeCompletion(content="ok")


def _template(llm: _RecordingChatModel) -> Agent:
    return Agent(
        llm=llm,  # type: ignore[arg-type]
        config=AgentConfig(
            tools=(),
            agents=(),
            offload_enabled=False,
            memory_background_enabled=False,
            setting_sources=None,
        ),
    )


class TestQueueInitialInjection(unittest.IsolatedAsyncioTestCase):
    async def test_first_message_triggers_turn_and_backlog_is_injected_before_first_llm_call(self) -> None:
        llm = _RecordingChatModel()
        with tempfile.TemporaryDirectory() as td:
            session = _template(llm).chat(cwd=Path(td) / "session")
            first_id = await session.send("first")
            second_id = await session.send("second")
            third_id = await session.send("third")

            stream = session.events()
            events = []
            async for event in stream:
                events.append(event)
                if isinstance(event, StopEvent):
                    break
            await stream.aclose()
            await session.close()

        injected_events = [
            event for event in events if isinstance(event, QueuedMessageInjectedEvent)
        ]
        self.assertEqual(len(injected_events), 1)
        self.assertEqual(injected_events[0].message_ids, (second_id, third_id))
        self.assertEqual(injected_events[0].trigger_message_id, first_id)
        self.assertEqual(injected_events[0].call_index, 0)

        self.assertEqual(session.peek_queue(), ())
        self.assertEqual(session._agent._context.turn_number, 1)
        self.assertEqual(len(llm.calls), 1)
        user_messages = [
            message
            for message in llm.calls[0]
            if isinstance(message, UserMessage)
        ]
        self.assertEqual(len(user_messages), 2)
        self.assertFalse(user_messages[0].is_meta)
        self.assertEqual(user_messages[0].content, "first")
        self.assertTrue(user_messages[1].is_meta)
        self.assertIn("second", user_messages[1].text)
        self.assertIn("third", user_messages[1].text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
