import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.system_tools.task.tools import TaskCreate
from comate_agent_sdk.system_tools.team.tools import SendMessage
from comate_agent_sdk.system_tools.tools import AskUserQuestion
from comate_agent_sdk.tools.decorator import tool


def _make_fake_tool(name: str):
    @tool("fake", name=name)
    async def _fn() -> str:
        return ""

    return _fn


def test_effective_enabled_tool_names_applies_subagent_filter() -> None:
    from comate_agent_sdk.agent.tool_visibility import effective_enabled_tool_names

    tools = [_make_fake_tool(n) for n in ("Read", "Agent", "TaskCreate", "Grep")]

    assert effective_enabled_tool_names(tools, is_subagent=False) == frozenset(
        {"Read", "Agent", "TaskCreate", "Grep"}
    )
    assert effective_enabled_tool_names(tools, is_subagent=True) == frozenset(
        {"Read", "Grep"}
    )


def test_effective_enabled_tool_names_applies_disallowed_filter() -> None:
    from comate_agent_sdk.agent.tool_visibility import effective_enabled_tool_names

    tools = [_make_fake_tool(n) for n in ("Read", "Bash", "Grep")]

    assert effective_enabled_tool_names(
        tools,
        is_subagent=False,
        disallowed_tools=("Bash",),
    ) == frozenset({"Read", "Grep"})


class _FakeChatModel:
    def __init__(self, content: str = "ok") -> None:
        self.model = "fake:model"
        self._content = content

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        return ChatInvokeCompletion(content=self._content)


class TestToolVisibilityRuntime(unittest.TestCase):
    def test_main_agent_exposes_agent_and_ask_user_question(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            template = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=Path(tmp),
                ),
            )
            runtime = template.create_runtime()

        strategy_item = runtime._context.header.find_one_by_type(ItemType.TOOL_STRATEGY)
        self.assertIsNotNone(strategy_item)
        content = strategy_item.content_text if strategy_item is not None else ""
        self.assertIn("Use the Agent tool with specialized agents", content)
        self.assertIn("- **AskUserQuestion**:", content)

        tool_names = {d.name for d in runtime.tool_definitions}
        self.assertIn("Agent", tool_names)
        self.assertIn("AskUserQuestion", tool_names)

    def test_subagent_hides_agent_and_ask_user_question(self) -> None:
        @tool("Custom agent", name="Agent", usage_rules="custom agent policy")
        async def custom_agent_tool(prompt: str) -> str:
            return prompt

        @tool("A regular subagent tool", name="SubagentTool", usage_rules="regular tool policy")
        async def subagent_tool(input: str) -> str:
            return input

        with tempfile.TemporaryDirectory() as tmp:
            template = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(custom_agent_tool, AskUserQuestion, subagent_tool),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=Path(tmp),
                ),
            )
        runtime = template.create_runtime(is_subagent=True, name="worker")

        runtime_tool_names = {t.name for t in runtime._runtime_state.tools}
        self.assertNotIn("Agent", runtime_tool_names)
        self.assertNotIn("AskUserQuestion", runtime_tool_names)

        schema_tool_names = {d.name for d in runtime.tool_definitions}
        self.assertNotIn("Agent", schema_tool_names)
        self.assertNotIn("AskUserQuestion", schema_tool_names)

        strategy_item = runtime._context.header.find_one_by_type(ItemType.TOOL_STRATEGY)
        self.assertIsNotNone(strategy_item)
        content = strategy_item.content_text if strategy_item is not None else ""
        self.assertNotIn("- **Agent**:", content)
        self.assertNotIn("- **AskUserQuestion**:", content)

    def test_team_subagent_exposes_team_tools_to_runtime_and_schema(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            template = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(TaskCreate, SendMessage, AskUserQuestion),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=Path(tmp),
                ),
            )
            runtime = template.create_runtime(
                is_subagent=True,
                name="worker-1",
                team_name="review-team",
            )

        runtime_tool_names = {t.name for t in runtime._runtime_state.tools}
        self.assertIn("SendMessage", runtime_tool_names)
        self.assertNotIn("TaskCreate", runtime_tool_names)
        self.assertNotIn("AskUserQuestion", runtime_tool_names)

        schema_tool_names = {d.name for d in runtime.tool_definitions}
        self.assertIn("SendMessage", schema_tool_names)
        self.assertNotIn("TaskCreate", schema_tool_names)
        self.assertNotIn("AskUserQuestion", schema_tool_names)

        strategy_item = runtime._context.header.find_one_by_type(ItemType.TOOL_STRATEGY)
        self.assertIsNotNone(strategy_item)
        content = strategy_item.content_text if strategy_item is not None else ""
        self.assertNotIn("- **AskUserQuestion**:", content)


if __name__ == "__main__":
    unittest.main(verbosity=2)
