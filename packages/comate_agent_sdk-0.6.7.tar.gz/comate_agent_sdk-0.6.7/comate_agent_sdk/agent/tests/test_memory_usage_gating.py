from __future__ import annotations

import tempfile
from pathlib import Path

from comate_agent_sdk.agent.setup import setup_memory_usage
from comate_agent_sdk.context import ContextIR
from comate_agent_sdk.context.items import ItemType


def _fake_agent(enabled: bool, tmpdir: Path):
    class A:
        _memory_extraction_enabled = enabled
        _context = ContextIR()

        def _resolve_memory_usage_prompt(self) -> str:
            return "MEMORY_USAGE_BODY"

    agent = A()
    agent._runtime_state = type("S", (), {"cwd": str(tmpdir)})()
    setattr(agent, "_shared_auto_memory_dir", tmpdir)
    return agent


def test_memory_extraction_disabled_skips_injection() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        agent = _fake_agent(enabled=False, tmpdir=Path(tmp))
        setup_memory_usage(agent)  # type: ignore[arg-type]
        assert agent._context.header.find_one_by_type(ItemType.MEMORY_USAGE) is None


def test_memory_extraction_enabled_injects_memory_usage() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        agent = _fake_agent(enabled=True, tmpdir=Path(tmp))
        setup_memory_usage(agent)  # type: ignore[arg-type]
        item = agent._context.header.find_one_by_type(ItemType.MEMORY_USAGE)
        assert item is not None
        assert "MEMORY_USAGE_BODY" in item.content_text
