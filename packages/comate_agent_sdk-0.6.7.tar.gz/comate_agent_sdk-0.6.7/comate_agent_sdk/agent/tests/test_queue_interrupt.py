import asyncio
import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.events import StopEvent
from comate_agent_sdk.llm.views import ChatInvokeCompletion


class _BlockingChatModel:
    def __init__(self, *, started: asyncio.Event) -> None:
        self.model = "fake:model"
        self.started = started

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del messages, tools, tool_choice, kwargs
        self.started.set()
        await asyncio.Event().wait()
        return ChatInvokeCompletion(content="unreachable")


def _template(llm: _BlockingChatModel) -> Agent:
    return Agent(
        llm=llm,  # type: ignore[arg-type]
        config=AgentConfig(
            tools=(),
            agents=(),
            offload_enabled=False,
            memory_background_enabled=False,
            setting_sources=None,
        ),
    )


class TestQueueInterrupt(unittest.IsolatedAsyncioTestCase):
    async def test_interrupt_does_not_clear_queued_messages_not_yet_injected(self) -> None:
        started = asyncio.Event()
        llm = _BlockingChatModel(started=started)

        with tempfile.TemporaryDirectory() as td:
            session = _template(llm).chat(cwd=Path(td) / "session")
            await session.send("trigger")
            events: list[object] = []

            async def _collect_events() -> None:
                stream = session.events()
                async for event in stream:
                    events.append(event)
                    if isinstance(event, StopEvent):
                        break
                await stream.aclose()

            collect_task = asyncio.create_task(_collect_events())
            await asyncio.wait_for(started.wait(), timeout=1)

            queued_id = await session.send("still queued")
            session.run_controller.interrupt("user_esc")

            await asyncio.wait_for(collect_task, timeout=2)

            stop_events = [event for event in events if isinstance(event, StopEvent)]
            self.assertEqual([event.reason for event in stop_events], ["interrupted"])
            self.assertEqual(
                [message.message_id for message in session.peek_queue()],
                [queued_id],
            )
            self.assertEqual(session.peek_queue()[0].content, "still queued")

            await session.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
