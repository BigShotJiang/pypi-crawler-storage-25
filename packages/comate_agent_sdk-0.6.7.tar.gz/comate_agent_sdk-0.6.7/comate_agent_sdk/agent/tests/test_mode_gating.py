from __future__ import annotations

import pytest

from comate_agent_sdk.agent.mode_gating import (
    MODE_REPRESENTATIVE_TOOLS,
    ModeVisibility,
)


def test_mode_representative_tools_complete() -> None:
    assert set(MODE_REPRESENTATIVE_TOOLS.keys()) == {"solo", "plan", "subagent", "team"}
    assert MODE_REPRESENTATIVE_TOOLS["solo"] is None
    assert MODE_REPRESENTATIVE_TOOLS["plan"] == "ExitPlanMode"
    assert MODE_REPRESENTATIVE_TOOLS["subagent"] == "Agent"
    assert MODE_REPRESENTATIVE_TOOLS["team"] == "TeamCreate"


def test_empty_enabled_yields_solo_only() -> None:
    vis = ModeVisibility.from_enabled_tools(frozenset())
    assert vis == ModeVisibility(solo=True, plan=False, subagent=False, team=False)


@pytest.mark.parametrize(
    "enabled,expected",
    [
        (frozenset({"ExitPlanMode"}), ModeVisibility(solo=True, plan=True)),
        (frozenset({"Agent"}), ModeVisibility(solo=True, subagent=True)),
        (frozenset({"TeamCreate"}), ModeVisibility(solo=True, team=True)),
        (
            frozenset({"ExitPlanMode", "Agent", "TeamCreate"}),
            ModeVisibility(solo=True, plan=True, subagent=True, team=True),
        ),
        (frozenset({"Read", "Bash"}), ModeVisibility(solo=True)),
    ],
)
def test_from_enabled_tools(enabled: frozenset[str], expected: ModeVisibility) -> None:
    assert ModeVisibility.from_enabled_tools(enabled) == expected
