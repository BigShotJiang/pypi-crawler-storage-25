from __future__ import annotations

import contextlib
import tempfile
from collections.abc import Iterator
from typing import Any

import pytest

from comate_agent_sdk.context.lower import LoweringPipeline
from comate_agent_sdk.facade.client import AgentClient
from comate_agent_sdk.facade.config.options import AgentOptions, SubagentConfig
from comate_agent_sdk.llm.views import ChatInvokeCompletion


class _StubLLM:
    """最小 stub LLM：测试只触发 template/runtime 的 header 装配，不真正调用模型。"""

    def __init__(self) -> None:
        self.model = "fake:end-to-end"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del messages, tools, tool_choice, kwargs
        return ChatInvokeCompletion(content="stub")


def _dump_system_prompt(runtime: Any) -> str:
    messages = LoweringPipeline.lower(runtime._context)
    for m in messages:
        if type(m).__name__ == "SystemMessage":
            return m.content
    return ""


@contextlib.contextmanager
def _make_runtime(**overrides: Any) -> Iterator[Any]:
    with tempfile.TemporaryDirectory() as tmp:
        options = AgentOptions(
            cwd=tmp,
            setting_sources=[],
            **overrides,
        )
        client = AgentClient(llm=_StubLLM(), options=options)
        yield client._template.create_runtime()


def test_minimal_agent_system_prompt_has_solo_only_and_no_memory() -> None:
    """Read/Write/Grep 三件套 + memory disabled → 只有 Solo mode，无其它 mode / subagents / skills / memory_usage。"""
    with _make_runtime(
        tools=["Read", "Write", "Grep"],
        memory_background_enabled=False,
    ) as runtime:
        prompt_text = _dump_system_prompt(runtime)
        assert "Solo mode" in prompt_text
        assert "Plan mode" not in prompt_text
        assert "Subagent mode" not in prompt_text
        assert "Team mode" not in prompt_text
        assert "<subagents>" not in prompt_text
        assert "<skills>" not in prompt_text
        assert "<memory_usage>" not in prompt_text


def test_coding_agent_system_prompt_has_using_tools_and_session_guidance() -> None:
    """显式 allowlist 含 Agent sentinel + 非空 agents 配置 → 含 using_your_tools 与 session_guidance 段。"""
    with _make_runtime(
        tools=[
            "Bash", "Read", "Write", "Edit", "Glob", "Grep", "LS",
            "TaskCreate", "ExitPlanMode", "Agent",
        ],
        agents={"explorer": SubagentConfig(description="explorer", prompt="you explore")},
        memory_background_enabled=False,
    ) as runtime:
        prompt_text = _dump_system_prompt(runtime)
        assert "Solo mode" in prompt_text
        assert "Plan mode" in prompt_text
        assert "Subagent mode" in prompt_text
        assert "Team mode" not in prompt_text
        assert "To read files use Read instead of cat" in prompt_text
        assert "To edit files use Edit instead of sed or awk" in prompt_text
        assert "Use the Agent tool with specialized agents" in prompt_text
        assert "Glob or Grep directly" in prompt_text


def test_team_lead_agent_system_prompt_has_all_modes() -> None:
    """显式 allowlist 含 Agent/Skill sentinel + TeamCreate + 非空 agents/skills + memory on → 四 mode 齐全 + memory_usage。"""
    with _make_runtime(
        tools=[
            "Bash", "Read", "Write", "Edit", "Glob", "Grep", "LS",
            "TaskCreate", "ExitPlanMode", "Agent", "Skill",
            "TeamCreate", "TeamDelete", "SendMessage",
        ],
        agents={"explorer": SubagentConfig(description="explorer", prompt="you explore")},
        skills=["demo-skill"],
        memory_background_enabled=True,
    ) as runtime:
        prompt_text = _dump_system_prompt(runtime)
        assert "Solo mode" in prompt_text
        assert "Plan mode" in prompt_text
        assert "Subagent mode" in prompt_text
        assert "Team mode" in prompt_text
        assert "<memory_usage>" in prompt_text
