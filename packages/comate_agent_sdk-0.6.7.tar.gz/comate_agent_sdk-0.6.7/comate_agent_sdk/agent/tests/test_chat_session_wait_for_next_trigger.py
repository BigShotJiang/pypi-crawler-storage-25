import asyncio
import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.external_turns import ExternalTurn, ScheduledExternalTurn
from comate_agent_sdk.agent.queue_types import QueuedMessage
from comate_agent_sdk.llm.views import ChatInvokeCompletion


class _FakeChatModel:
	model = "fake:model"

	@property
	def provider(self) -> str:
		return "fake"

	@property
	def name(self) -> str:
		return self.model

	async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
		del messages, tools, tool_choice, kwargs
		return ChatInvokeCompletion(content="ok")


def _template() -> Agent:
	return Agent(
		llm=_FakeChatModel(),  # type: ignore[arg-type]
		config=AgentConfig(tools=(), agents=(), offload_enabled=False),
	)


def _external_turn(turn_id: str = "evt-1") -> ExternalTurn:
	return ExternalTurn(
		turn_id=turn_id,
		source="team_inbox",
		source_event_id=turn_id,
		dedupe_key=f"team_inbox:{turn_id}",
		received_at="2026-04-28T00:00:00+00:00",
		payload={"content": "external"},
		can_auto_consume=True,
		preview="external",
	)


class TestChatSessionWaitForNextTrigger(unittest.IsolatedAsyncioTestCase):
	async def test_wait_for_next_trigger_peeks_user_queue_without_consuming(self) -> None:
		with tempfile.TemporaryDirectory() as td:
			session = _template().chat(cwd=Path(td) / "session")
			message_id = await session.send("hello")

			trigger = await asyncio.wait_for(session._wait_for_next_trigger(), timeout=1)

			self.assertIsNotNone(trigger)
			trigger_kind, payload = trigger
			self.assertEqual(trigger_kind, "user")
			self.assertIsInstance(payload, QueuedMessage)
			self.assertEqual(payload.message_id, message_id)
			self.assertEqual(payload.content, "hello")
			self.assertEqual([message.message_id for message in session.peek_queue()], [message_id])

	async def test_wait_for_next_trigger_prefers_external_turn_over_user_queue(self) -> None:
		with tempfile.TemporaryDirectory() as td:
			session = _template().chat(cwd=Path(td) / "session")
			message_id = await session.send("hello")
			await session.enqueue_external_turn(_external_turn())

			trigger = await asyncio.wait_for(session._wait_for_next_trigger(), timeout=1)

			self.assertIsNotNone(trigger)
			trigger_kind, payload = trigger
			self.assertEqual(trigger_kind, "external")
			self.assertIsInstance(payload, ScheduledExternalTurn)
			self.assertEqual([message.message_id for message in session.peek_queue()], [message_id])

	async def test_wait_for_next_trigger_returns_none_when_message_source_finishes_empty(self) -> None:
		with tempfile.TemporaryDirectory() as td:
			session = _template().chat(cwd=Path(td) / "session", message_source=[])

			trigger = await asyncio.wait_for(session._wait_for_next_trigger(), timeout=1)

			self.assertIsNone(trigger)

	async def test_wait_for_next_trigger_returns_none_when_closed_while_waiting(self) -> None:
		with tempfile.TemporaryDirectory() as td:
			session = _template().chat(cwd=Path(td) / "session")
			waiter = asyncio.create_task(session._wait_for_next_trigger())
			await asyncio.sleep(0)

			await session.close()

			self.assertIsNone(await asyncio.wait_for(waiter, timeout=1))


if __name__ == "__main__":
	unittest.main(verbosity=2)
