from datetime import UTC, datetime

from comate_agent_sdk.agent.queue_types import MessageOrigin, QueuedMessage
from comate_agent_sdk.llm.messages import (
	ContentPartImageParam,
	ContentPartTextParam,
	ImageURL,
)


def _queued(
	message_id: str,
	content,
	origin: MessageOrigin,
	metadata: dict | None = None,
) -> QueuedMessage:
	return QueuedMessage(
		message_id=message_id,
		content=content,
		origin=origin,
		enqueued_at=datetime(2026, 4, 28, tzinfo=UTC),
		origin_metadata=metadata,
	)


def test_compose_injection_blocks_wraps_each_message_in_system_reminder() -> None:
	from comate_agent_sdk.agent.queue_injection import compose_injection_blocks

	blocks = compose_injection_blocks(
		[
			_queued("m1", "first queued", MessageOrigin.HUMAN),
			_queued("m2", "second queued", MessageOrigin.COORDINATOR),
		]
	)

	assert [block["type"] for block in blocks] == ["text", "text"]
	assert blocks[0]["text"].startswith("<system-reminder>")
	assert blocks[0]["text"].endswith("</system-reminder>")
	assert "first queued" in blocks[0]["text"]
	assert "MUST address" in blocks[0]["text"]
	assert "second queued" in blocks[1]["text"]


def test_compose_injection_blocks_uses_external_channel_fallback() -> None:
	from comate_agent_sdk.agent.queue_injection import compose_injection_blocks

	blocks = compose_injection_blocks(
		[_queued("m1", "from outside", MessageOrigin.EXTERNAL)]
	)

	assert "external channel" in blocks[0]["text"]
	assert "untrusted" in blocks[0]["text"].lower()
	assert "from outside" in blocks[0]["text"]


def test_compose_injection_blocks_preserves_multimodal_images_after_wrapper() -> None:
	from comate_agent_sdk.agent.queue_injection import compose_injection_blocks

	first_image = ContentPartImageParam(
		image_url=ImageURL(url="data:image/png;base64,aaa", detail="low")
	)
	second_image = ContentPartImageParam(
		image_url=ImageURL(url="https://example.test/image.png", detail="high")
	)

	blocks = compose_injection_blocks(
		[
			_queued(
				"m1",
				[
					ContentPartTextParam(text="look at these"),
					first_image,
					ContentPartTextParam(text="and compare"),
					second_image,
				],
				MessageOrigin.HUMAN,
			)
		]
	)

	assert len(blocks) == 3
	assert blocks[0]["type"] == "text"
	assert "look at these\nand compare" in blocks[0]["text"]
	assert blocks[1] == first_image.model_dump(mode="json")
	assert blocks[2] == second_image.model_dump(mode="json")
