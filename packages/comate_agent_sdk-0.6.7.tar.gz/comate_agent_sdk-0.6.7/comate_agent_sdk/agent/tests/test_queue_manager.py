from __future__ import annotations

import asyncio
from datetime import UTC, datetime

import pytest

from comate_agent_sdk.agent.queue_types import MessageOrigin, QueuedMessage


async def _wait_for_events(events: list[object], count: int) -> None:
	for _ in range(20):
		if len(events) >= count:
			return
		await asyncio.sleep(0.01)
	raise AssertionError(f"expected {count} events, got {len(events)}")


def test_queue_manager_enqueue_peek_and_cancel_are_fifo() -> None:
	from comate_agent_sdk.agent.queue_manager import QueueManager

	manager = QueueManager()

	first_id = manager.enqueue("first", origin=MessageOrigin.HUMAN)
	second_id = manager.enqueue(
		"second",
		origin=MessageOrigin.EXTERNAL,
		origin_metadata={"server": "slack"},
	)

	snapshot = manager.peek()
	assert [message.message_id for message in snapshot] == [first_id, second_id]
	assert [message.content for message in snapshot] == ["first", "second"]
	assert snapshot[1].origin_metadata == {"server": "slack"}

	assert manager.cancel(first_id) is True
	assert manager.cancel("missing") is False
	assert [message.message_id for message in manager.peek()] == [second_id]


def test_queue_manager_capacity_and_close_errors() -> None:
	from comate_agent_sdk.agent.queue_manager import (
		_DEFAULT_QUEUE_MAX_SIZE,
		QueueManager,
		QueueManagerClosedError,
		QueueManagerFullError,
	)

	manager = QueueManager()
	for index in range(_DEFAULT_QUEUE_MAX_SIZE):
		manager.enqueue(f"m-{index}", origin=MessageOrigin.HUMAN)

	with pytest.raises(QueueManagerFullError):
		manager.enqueue("overflow", origin=MessageOrigin.HUMAN)

	manager.close()
	with pytest.raises(QueueManagerClosedError):
		manager.enqueue("closed", origin=MessageOrigin.HUMAN)


def test_queue_manager_consume_batch_and_requeue_at_head_preserve_order() -> None:
	from comate_agent_sdk.agent.queue_manager import QueueManager

	manager = QueueManager()
	first_id = manager.enqueue("first", origin=MessageOrigin.HUMAN)
	second_id = manager.enqueue("second", origin=MessageOrigin.COORDINATOR)
	third_id = manager.enqueue("third", origin=MessageOrigin.TASK_NOTIFICATION)

	consumed = manager.consume_batch([second_id, "missing", first_id])

	assert [message.message_id for message in consumed] == [first_id, second_id]
	assert [message.message_id for message in manager.peek()] == [third_id]

	manager.requeue_at_head(consumed)

	assert [message.message_id for message in manager.peek()] == [
		first_id,
		second_id,
		third_id,
	]


def test_queue_manager_wait_wakes_after_enqueue_and_emits_dirty_event() -> None:
	asyncio.run(_check_queue_manager_wait_wakes_after_enqueue_and_emits_dirty_event())


async def _check_queue_manager_wait_wakes_after_enqueue_and_emits_dirty_event() -> None:
	from comate_agent_sdk.agent.events import QueueDirtyEvent, QueueDirtyReason
	from comate_agent_sdk.agent.queue_manager import QueueManager

	events: list[object] = []

	async def emit(event: object) -> None:
		events.append(event)

	manager = QueueManager(event_emitter=emit)
	waiter = asyncio.create_task(manager.wait_non_empty_or_closed())
	await asyncio.sleep(0)

	message_id = manager.enqueue("hello", origin=MessageOrigin.HUMAN)

	assert await asyncio.wait_for(waiter, timeout=1) is True
	await _wait_for_events(events, 1)

	event = events[0]
	assert isinstance(event, QueueDirtyEvent)
	assert event.reason is QueueDirtyReason.ENQUEUED
	assert event.queue_size == 1
	assert event.message_ids == (message_id,)
	assert event.origins == (MessageOrigin.HUMAN,)


def test_queue_manager_wait_returns_false_when_closed_empty() -> None:
	asyncio.run(_check_queue_manager_wait_returns_false_when_closed_empty())


async def _check_queue_manager_wait_returns_false_when_closed_empty() -> None:
	from comate_agent_sdk.agent.queue_manager import QueueManager

	manager = QueueManager()
	waiter = asyncio.create_task(manager.wait_non_empty_or_closed())
	await asyncio.sleep(0)

	manager.close()

	assert await asyncio.wait_for(waiter, timeout=1) is False


def test_queue_manager_wait_changed_ignores_existing_messages_until_mutation() -> None:
	asyncio.run(_check_queue_manager_wait_changed_ignores_existing_messages_until_mutation())


async def _check_queue_manager_wait_changed_ignores_existing_messages_until_mutation() -> None:
	from comate_agent_sdk.agent.queue_manager import QueueManager

	manager = QueueManager()
	manager.enqueue("already-queued", origin=MessageOrigin.HUMAN)
	since_revision = manager.revision()
	waiter = asyncio.create_task(
		manager.wait_changed_or_closed(since_revision=since_revision)
	)
	await asyncio.sleep(0)

	assert waiter.done() is False

	manager.enqueue("new-message", origin=MessageOrigin.HUMAN)

	assert await asyncio.wait_for(waiter, timeout=1) is True


def test_queue_manager_does_not_backfill_dirty_events_before_loop_bind() -> None:
	asyncio.run(_check_queue_manager_does_not_backfill_dirty_events_before_loop_bind())


async def _check_queue_manager_does_not_backfill_dirty_events_before_loop_bind() -> None:
	from comate_agent_sdk.agent.queue_manager import QueueManager

	events: list[object] = []

	async def emit(event: object) -> None:
		events.append(event)

	manager = QueueManager(event_emitter=emit)
	manager.enqueue("before-bind", origin=MessageOrigin.HUMAN)

	assert await manager.wait_non_empty_or_closed() is True
	assert events == []


def test_queue_manager_mutations_emit_dirty_events_after_loop_bind() -> None:
	asyncio.run(_check_queue_manager_mutations_emit_dirty_events_after_loop_bind())


async def _check_queue_manager_mutations_emit_dirty_events_after_loop_bind() -> None:
	from comate_agent_sdk.agent.events import QueueDirtyReason
	from comate_agent_sdk.agent.queue_manager import QueueManager

	events: list[object] = []

	async def emit(event: object) -> None:
		events.append(event)

	manager = QueueManager(event_emitter=emit)
	assert manager.peek() == ()
	waiter = asyncio.create_task(manager.wait_non_empty_or_closed())
	await asyncio.sleep(0)

	first_id = manager.enqueue("first", origin=MessageOrigin.HUMAN)
	second_id = manager.enqueue("second", origin=MessageOrigin.EXTERNAL)
	assert await asyncio.wait_for(waiter, timeout=1) is True
	manager.consume_batch([first_id])
	manager.cancel_many([second_id, "missing"])
	manager.clear()
	await _wait_for_events(events, 4)

	assert [event.reason for event in events] == [
		QueueDirtyReason.ENQUEUED,
		QueueDirtyReason.ENQUEUED,
		QueueDirtyReason.CONSUMED,
		QueueDirtyReason.CANCELLED,
	]
	assert events[-1].message_ids == (second_id,)
	assert events[-1].origins == (MessageOrigin.EXTERNAL,)


def test_queue_manager_requeue_at_head_does_not_emit_dirty_event() -> None:
	from comate_agent_sdk.agent.queue_manager import QueueManager

	manager = QueueManager()
	message = QueuedMessage(
		message_id="m1",
		content="hello",
		origin=MessageOrigin.HUMAN,
		enqueued_at=datetime(2026, 4, 28, tzinfo=UTC),
	)

	manager.requeue_at_head([message])

	assert manager.peek() == (message,)
