from __future__ import annotations

import tempfile
from dataclasses import replace
from pathlib import Path

import pytest

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.skill.models import SkillDefinition
from comate_agent_sdk.subagent.models import AgentDefinition


class _FakeChatModel:
    model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        return ChatInvokeCompletion(content="ok")


def _agent_def() -> AgentDefinition:
    return AgentDefinition(name="researcher", description="r", prompt="p")


def _skill_def() -> SkillDefinition:
    return SkillDefinition(name="demo", description="d", prompt="p")


def _create_runtime(config: AgentConfig):
    with tempfile.TemporaryDirectory() as tmp:
        template = Agent(
            llm=_FakeChatModel(),  # type: ignore[arg-type]
            config=replace(
                config,
                cwd=Path(tmp),
                offload_enabled=False,
                setting_sources=None,
            ),
        )
        return template.create_runtime()


def test_allowlist_agent_sentinel_without_agents_fails_fast() -> None:
    with pytest.raises(ValueError, match="Agent capability"):
        _create_runtime(AgentConfig(tools=("Agent",), agents=()))


def test_allowlist_skill_sentinel_without_skills_fails_fast(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("comate_agent_sdk.skill.discover_skills", lambda project_root=None: [])
    with pytest.raises(ValueError, match="Skill capability"):
        _create_runtime(AgentConfig(tools=("Skill",), skills=()))


def test_explicit_agents_present_but_agent_not_requested_fails_fast() -> None:
    with pytest.raises(ValueError, match="Agent capability"):
        _create_runtime(AgentConfig(tools=(), agents=(_agent_def(),)))


def test_explicit_skills_present_but_skill_not_requested_fails_fast() -> None:
    with pytest.raises(ValueError, match="Skill capability"):
        _create_runtime(AgentConfig(tools=(), skills=(_skill_def(),)))


def test_auto_builtin_agents_without_agent_sentinel_do_not_fail_and_do_not_create_agent_tool() -> None:
    runtime = _create_runtime(AgentConfig(tools=("Read",), agents=None))
    tool_names = {t.name for t in runtime._runtime_state.tools}
    assert "Read" in tool_names
    assert "Agent" not in tool_names


def test_tools_none_with_agents_allows_agent_capability() -> None:
    runtime = _create_runtime(AgentConfig(tools=None, agents=(_agent_def(),)))
    tool_names = {t.name for t in runtime._runtime_state.tools}
    assert "Agent" in tool_names


def test_tools_none_with_skills_allows_skill_capability() -> None:
    runtime = _create_runtime(AgentConfig(tools=None, skills=(_skill_def(),)))
    tool_names = {t.name for t in runtime._runtime_state.tools}
    assert "Skill" in tool_names


def test_disallowed_agent_conflict_fails_fast() -> None:
    with pytest.raises(ValueError, match="disallowed_tools"):
        _create_runtime(
            AgentConfig(
                tools=("Agent",),
                agents=(_agent_def(),),
                disallowed_tools=("Agent",),
            )
        )


def test_disallowed_skill_conflict_fails_fast() -> None:
    with pytest.raises(ValueError, match="disallowed_tools"):
        _create_runtime(
            AgentConfig(
                tools=("Skill",),
                skills=(_skill_def(),),
                disallowed_tools=("Skill",),
            )
        )
