"""Tests for MCP whitelist + async connection interaction."""

import logging
import unittest
from unittest.mock import AsyncMock, MagicMock

from comate_agent_sdk.tools import Tool


async def _noop() -> str:
    return ""


def _make_tool(name: str, *, is_mcp: bool = False) -> Tool:
    """Create a minimal Tool for testing."""
    tool = Tool(func=_noop, name=name, description=f"test tool {name}")
    if is_mcp:
        tool._comate_agent_sdk_mcp_tool = True
    return tool


def _make_agent(
    *,
    tools: list[Tool],
    allowlist_mode: bool = True,
    requested_tool_names: list[str] | None = None,
) -> MagicMock:
    """Create a minimal mock AgentRuntime."""
    agent = MagicMock()
    agent._tools_allowlist_mode = allowlist_mode
    agent._requested_tool_names = requested_tool_names or []
    agent._runtime_state.tools = list(tools)
    return agent


class TestApplyMcpToolsWhitelistMode(unittest.TestCase):
    """Test apply_mcp_tools_to_agent() in whitelist mode.

    Note: _mcp_pending_tool_names is deprecated in the new design.
    Whitelist filtering is now driven by _requested_tool_names.
    """

    def test_whitelist_filters_mcp_tools_by_requested_names(self):
        """白名单中声明的 MCP 工具应被合并，未声明的应被过滤掉。"""
        from comate_agent_sdk.agent.core.runtime_mcp import apply_mcp_tools_to_agent

        bash = _make_tool("Bash")
        mcp_search = _make_tool("mcp__tavily__search", is_mcp=True)
        mcp_crawl = _make_tool("mcp__tavily__crawl", is_mcp=True)
        mcp_extra = _make_tool("mcp__tavily__extra", is_mcp=True)

        agent = _make_agent(
            tools=[bash],
            requested_tool_names=["Bash", "mcp__tavily__search", "mcp__tavily__crawl"],
        )

        apply_mcp_tools_to_agent(agent, [mcp_search, mcp_crawl, mcp_extra])

        tool_names = [t.name for t in agent._runtime_state.tools]
        self.assertIn("Bash", tool_names)
        self.assertIn("mcp__tavily__search", tool_names)
        self.assertIn("mcp__tavily__crawl", tool_names)
        self.assertNotIn("mcp__tavily__extra", tool_names)

    def test_whitelist_no_duplicate_on_repeated_callback(self):
        """多次回调调用不应导致工具重复。"""
        from comate_agent_sdk.agent.core.runtime_mcp import apply_mcp_tools_to_agent

        bash = _make_tool("Bash")
        mcp_search = _make_tool("mcp__tavily__search", is_mcp=True)

        agent = _make_agent(
            tools=[bash],
            requested_tool_names=["Bash", "mcp__tavily__search"],
        )

        apply_mcp_tools_to_agent(agent, [mcp_search])
        apply_mcp_tools_to_agent(agent, [mcp_search])

        tool_names = [t.name for t in agent._runtime_state.tools]
        self.assertEqual(tool_names.count("mcp__tavily__search"), 1)

    def test_whitelist_late_server_tools_added_on_callback(self):
        """慢速 server 后来连上时，其工具通过回调被补入。"""
        from comate_agent_sdk.agent.core.runtime_mcp import apply_mcp_tools_to_agent

        bash = _make_tool("Bash")
        mcp_fast = _make_tool("mcp__tavily__search", is_mcp=True)
        mcp_slow = _make_tool("mcp__hyc__ocr", is_mcp=True)

        agent = _make_agent(
            tools=[bash],
            requested_tool_names=["Bash", "mcp__tavily__search", "mcp__hyc__ocr"],
        )

        apply_mcp_tools_to_agent(agent, [mcp_fast])
        tool_names_1 = [t.name for t in agent._runtime_state.tools]
        self.assertIn("mcp__tavily__search", tool_names_1)
        self.assertNotIn("mcp__hyc__ocr", tool_names_1)

        apply_mcp_tools_to_agent(agent, [mcp_fast, mcp_slow])
        tool_names_2 = [t.name for t in agent._runtime_state.tools]
        self.assertIn("mcp__tavily__search", tool_names_2)
        self.assertIn("mcp__hyc__ocr", tool_names_2)

    def test_whitelist_missing_mcp_tool_logs_warning(self):
        """白名单中声明了不存在的 MCP 工具名，应输出 warning 日志。"""
        from comate_agent_sdk.agent.core.runtime_mcp import apply_mcp_tools_to_agent

        bash = _make_tool("Bash")
        mcp_search = _make_tool("mcp__tavily__search", is_mcp=True)

        agent = _make_agent(
            tools=[bash],
            requested_tool_names=["Bash", "mcp__tavily__search", "mcp__hyc__nonexistent"],
        )

        with self.assertLogs("comate_agent_sdk.agent", level=logging.WARNING) as cm:
            apply_mcp_tools_to_agent(agent, [mcp_search])

        self.assertTrue(
            any("mcp__hyc__nonexistent" in msg for msg in cm.output),
            f"Expected warning about mcp__hyc__nonexistent, got: {cm.output}",
        )

    def test_whitelist_empty_mcp_tools_keeps_base_only(self):
        """白名单 + 无 MCP server（空 mcp_tools）：只保留 base tools。"""
        from comate_agent_sdk.agent.core.runtime_mcp import apply_mcp_tools_to_agent

        bash = _make_tool("Bash")
        read = _make_tool("Read")

        agent = _make_agent(
            tools=[bash, read],
            requested_tool_names=["Bash", "Read"],
        )

        apply_mcp_tools_to_agent(agent, [])

        tool_names = [t.name for t in agent._runtime_state.tools]
        self.assertEqual(tool_names, ["Bash", "Read"])

    def test_non_whitelist_mode_unchanged(self):
        """非白名单模式行为不受影响：所有 MCP 工具直接合并。"""
        from comate_agent_sdk.agent.core.runtime_mcp import apply_mcp_tools_to_agent

        bash = _make_tool("Bash")
        mcp_tool = _make_tool("mcp__tavily__search", is_mcp=True)

        agent = _make_agent(
            tools=[bash],
            allowlist_mode=False,
        )

        apply_mcp_tools_to_agent(agent, [mcp_tool])

        tool_names = [t.name for t in agent._runtime_state.tools]
        self.assertIn("Bash", tool_names)
        self.assertIn("mcp__tavily__search", tool_names)


class TestLoadMcpToolsNoPendingValidation(unittest.TestCase):
    """Verify load_mcp_tools no longer raises ValueError for missing MCP tools."""

    def test_whitelist_missing_mcp_tool_no_error(self):
        """白名单中声明了不存在的 MCP 工具名，不应抛 ValueError。"""
        from comate_agent_sdk.agent.core.runtime_mcp import apply_mcp_tools_to_agent

        bash = _make_tool("Bash")
        mcp_search = _make_tool("mcp__tavily__search", is_mcp=True)

        agent = _make_agent(
            tools=[bash],
            requested_tool_names=["Bash", "mcp__tavily__search", "mcp__hyc__nonexistent"],
        )

        # 不应抛异常
        apply_mcp_tools_to_agent(agent, [mcp_search])

        tool_names = [t.name for t in agent._runtime_state.tools]
        self.assertIn("mcp__tavily__search", tool_names)
        self.assertNotIn("mcp__hyc__nonexistent", tool_names)


class TestLlmMcpExceptionHandling(unittest.IsolatedAsyncioTestCase):
    """Test llm.py MCP exception handling refinement.

    Note: _mcp_pending_tool_names is deprecated, but mock still sets it
    to confirm the old condition no longer triggers.
    """

    def _make_llm_agent(self, *, mcp_side_effect: Exception) -> MagicMock:
        """Create a mock agent with necessary config for invoke_llm."""
        agent = MagicMock()
        agent._tools_allowlist_mode = True
        agent._mcp_pending_tool_names = ["mcp__test__tool"]
        agent.ensure_mcp_tools_loaded = AsyncMock(side_effect=mcp_side_effect)
        agent.config.llm_max_retries = 1
        agent.config.tool_choice = None
        agent.config.output_format = None
        agent.tool_definitions = [{"name": "Bash"}]
        agent._context.lower.return_value = [{"role": "user", "content": "test"}]
        agent._context.inject_due_reminders = None
        return agent

    async def test_type_error_still_raises(self):
        """MCP 配置导致的 TypeError 应该仍然 re-raise。"""
        from comate_agent_sdk.agent.llm import invoke_llm

        agent = self._make_llm_agent(mcp_side_effect=TypeError("bad config"))

        with self.assertRaises(TypeError):
            await invoke_llm(agent)

    async def test_connection_timeout_degrades_gracefully(self):
        """MCP 连接超时应该降级继续，不 re-raise。"""
        from comate_agent_sdk.agent.llm import invoke_llm

        agent = self._make_llm_agent(mcp_side_effect=TimeoutError("connection timed out"))

        mock_response = MagicMock()
        mock_response.usage = None
        agent.llm.ainvoke = AsyncMock(return_value=mock_response)

        # 不应抛异常，应降级继续调用 LLM
        result = await invoke_llm(agent)
        agent.llm.ainvoke.assert_called_once()


class TestAllowlistOrthogonalToServerInstructions(unittest.TestCase):
    """spec §4.3.1：provider tools allowlist 与 server instructions 是正交通道。"""

    def test_allowlist_does_not_filter_server_instructions(self):
        from comate_agent_sdk.agent.core.runtime_mcp import apply_mcp_tools_to_agent
        from comate_agent_sdk.context.ir import ContextIR
        from comate_agent_sdk.context.items import ItemType
        from comate_agent_sdk.mcp.manager import McpManager, McpServerRuntimeState

        bash = _make_tool("Bash")
        mcp_search = _make_tool("mcp__tavily__search", is_mcp=True)
        agent = _make_agent(
            tools=[bash],
            requested_tool_names=["Bash"],
        )
        agent._context = ContextIR()

        apply_mcp_tools_to_agent(agent, [mcp_search])
        tool_names = [t.name for t in agent._runtime_state.tools]
        self.assertNotIn("mcp__tavily__search", tool_names)

        mgr = McpManager({})
        mgr._server_states["tavily"] = McpServerRuntimeState(
            alias="tavily",
            status="connected",
            reason=None,
            tool_count=1,
            instructions="用法 X",
        )
        overview = mgr.build_server_instructions_text()
        agent._context.set_mcp_tools(
            overview,
            metadata=mgr.build_server_instructions_metadata(),
        )
        mcp_item = agent._context.session_state.find_one_by_type(ItemType.MCP_TOOL)
        self.assertIsNotNone(mcp_item)
        self.assertIn("# MCP Server Instructions", mcp_item.content_text)
        self.assertIn("## tavily", mcp_item.content_text)


if __name__ == "__main__":
    unittest.main()
