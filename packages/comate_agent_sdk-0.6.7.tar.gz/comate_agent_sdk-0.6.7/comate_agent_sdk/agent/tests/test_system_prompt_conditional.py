from __future__ import annotations

import pytest

from comate_agent_sdk.agent.mode_gating import ModeVisibility
from comate_agent_sdk.agent.system_prompt import (
    render_mode_capabilities_lines,
    render_mode_selection_lines,
    render_session_guidance,
    render_tool_hints,
    render_using_your_tools,
)


@pytest.mark.parametrize(
    "enabled,must_contain,must_not_contain",
    [
        (
            frozenset(),
            [],
            [
                "# Using your tools",
                "You can call multiple tools in a single response",
                "Do NOT use the Bash",
                "instead of cat",
                "TaskCreate",
            ],
        ),
        (
            frozenset({"Bash"}),
            ["Reserve using the Bash exclusively"],
            ["instead of cat", "instead of sed"],
        ),
        (
            frozenset({"Bash", "Read"}),
            ["Do NOT use the Bash", "To read files use Read instead of cat, head, tail, or sed"],
            ["use Edit instead of sed"],
        ),
        (
            frozenset({"Bash", "Read", "Edit", "Write", "Glob", "Grep", "LS"}),
            [
                "To read files use Read instead of cat",
                "To edit files use Edit instead of sed or awk",
                "To create files use Write instead of cat",
                "To search for files use Glob instead of find or ls",
                "To search the content of files, use Grep instead of grep or rg",
                "To browse a directory's contents use LS instead of ls",
            ],
            [],
        ),
        (
            frozenset({"TaskCreate"}),
            ["Break down and manage your work with the TaskCreate tool"],
            [],
        ),
    ],
)
def test_render_using_your_tools(
    enabled: frozenset[str],
    must_contain: list[str],
    must_not_contain: list[str],
) -> None:
    result = render_using_your_tools(enabled)
    for expected in must_contain:
        assert expected in result, f"expected substring not found: {expected!r}"
    for forbidden in must_not_contain:
        assert forbidden not in result, f"forbidden substring present: {forbidden!r}"


def test_render_using_your_tools_returns_empty_without_tools() -> None:
    result = render_using_your_tools(frozenset())
    assert result == ""


@pytest.mark.parametrize(
    "enabled",
    [
        frozenset(),
        frozenset({"Read", "Grep", "Glob"}),
    ],
)
def test_render_session_guidance_returns_empty_without_guidance_body(
    enabled: frozenset[str],
) -> None:
    assert render_session_guidance(enabled) == ""


@pytest.mark.parametrize(
    "enabled,must_contain,must_not_contain",
    [
        (frozenset(), [], ["Use the Agent tool", "Glob or Grep directly", "AskUserQuestion"]),
        (
            frozenset({"Agent"}),
            ["Use the Agent tool with specialized agents"],
            ["Glob or Grep directly"],
        ),
        (
            frozenset({"Agent", "Grep"}),
            ["Use the Agent tool", "Glob or Grep directly", "subagent_type=Explorer"],
            [],
        ),
        (
            frozenset({"Agent", "Glob"}),
            ["Use the Agent tool", "Glob or Grep directly"],
            [],
        ),
        (
            frozenset({"AskUserQuestion"}),
            ["If you do not understand why the user has denied a tool call"],
            ["Use the Agent tool"],
        ),
    ],
)
def test_render_session_guidance(
    enabled: frozenset[str],
    must_contain: list[str],
    must_not_contain: list[str],
) -> None:
    result = render_session_guidance(enabled)
    for expected in must_contain:
        assert expected in result
    for forbidden in must_not_contain:
        assert forbidden not in result


def test_render_mode_capabilities_solo_only() -> None:
    out = render_mode_capabilities_lines(ModeVisibility())
    assert "Solo mode" in out
    assert "Plan mode" not in out
    assert "Subagent mode" not in out
    assert "Team mode" not in out


def test_render_mode_capabilities_full() -> None:
    vis = ModeVisibility(solo=True, plan=True, subagent=True, team=True)
    out = render_mode_capabilities_lines(vis)
    for mode in ("Solo mode", "Plan mode", "Subagent mode", "Team mode"):
        assert mode in out


def test_render_mode_selection_tracks_visibility() -> None:
    out_minimal = render_mode_selection_lines(ModeVisibility())
    assert "Solo" in out_minimal
    assert "Plan" not in out_minimal
    out_full = render_mode_selection_lines(
        ModeVisibility(solo=True, plan=True, subagent=True, team=True)
    )
    for mode in ("Solo", "Plan mode", "Subagent", "Team"):
        assert mode in out_full


def test_render_tool_hints_aggregates_enabled_with_hint() -> None:
    from comate_agent_sdk.tools.decorator import tool

    @tool("desc A", name="HasHint", prompt_hint="must be alone")
    async def a() -> str:
        return ""

    @tool("desc B", name="NoHint")
    async def b() -> str:
        return ""

    tools = [a, b]
    enabled = frozenset({"HasHint", "NoHint"})
    out = render_tool_hints(tools, enabled)
    assert "- **HasHint**: must be alone" in out
    assert "**NoHint**" not in out


def test_render_tool_hints_skips_disabled() -> None:
    from comate_agent_sdk.tools.decorator import tool

    @tool("desc", name="X", prompt_hint="hint")
    async def x() -> str:
        return ""

    assert render_tool_hints([x], frozenset()) == ""


def test_build_default_system_prompt_accepts_mode_visibility() -> None:
    from comate_agent_sdk.agent.system_prompt import build_default_system_prompt

    out = build_default_system_prompt(
        role=None,
        mode_visibility=ModeVisibility(solo=True, subagent=True),
    )
    assert "Solo mode" in out
    assert "Subagent mode" in out
    assert "Plan mode" not in out
    assert "Team mode" not in out


def test_build_default_system_prompt_default_mode_is_solo_only() -> None:
    from comate_agent_sdk.agent.system_prompt import build_default_system_prompt

    out = build_default_system_prompt()
    assert "Solo mode" in out
    assert "Plan mode" not in out


def test_default_system_prompt_template_no_hardcoded_tool_blocks() -> None:
    from comate_agent_sdk.prompts import load_prompt

    template = load_prompt("agent/default_system_prompt.md")

    assert "<tool_guidelines>" not in template
    assert "<tool_use>" not in template
    assert "{{MODE_CAPABILITIES_LINES}}" in template
    assert "{{MODE_SELECTION_LINES}}" in template
    assert "{{TOOL_STRATEGY}}" not in template


def test_setup_tool_strategy_places_tool_hints_inside_using_your_tools_section() -> None:
    """tool_hints 贴在 `# Using your tools` 末尾（单换行），`# Session-specific guidance` 与其用空行分隔。"""
    from comate_agent_sdk.agent.setup import setup_tool_strategy
    from comate_agent_sdk.context import ContextIR
    from comate_agent_sdk.context.items import ItemType
    from comate_agent_sdk.system_tools.tools import AskUserQuestion, Bash

    class FakeAgent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._runtime_state = type("S", (), {})()
            self._runtime_state.tools = [Bash, AskUserQuestion]
            self._is_subagent = False
            self.is_team_member = False
            self.config = type("C", (), {"disallowed_tools": None})()

    agent = FakeAgent()
    setup_tool_strategy(agent)  # type: ignore[arg-type]

    text = agent._context.header.find_one_by_type(ItemType.TOOL_STRATEGY).content_text

    using_idx = text.index("# Using your tools")
    guidance_idx = text.index("# Session-specific guidance")
    hints_idx = text.index("- **AskUserQuestion**")

    # tool_hints 位于两个顶级 section 之间（属于 Using your tools 段）
    assert using_idx < hints_idx < guidance_idx
    # 两个 `#` section 之间必须存在空行分隔
    assert "\n\n# Session-specific guidance" in text
    # tool_hints 作为 bullet 延续，与上一行是单换行（不是空行）
    assert "\n\n- **AskUserQuestion**" not in text


def test_setup_tool_strategy_writes_three_section_concat() -> None:
    from comate_agent_sdk.agent.setup import setup_tool_strategy
    from comate_agent_sdk.context import ContextIR
    from comate_agent_sdk.context.items import ItemType
    from comate_agent_sdk.system_tools.tools import AskUserQuestion, Bash

    class FakeAgent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._runtime_state = type("S", (), {})()
            self._runtime_state.tools = [Bash, AskUserQuestion]
            self._is_subagent = False
            self.is_team_member = False
            self.config = type("C", (), {"disallowed_tools": None})()

    agent = FakeAgent()
    setup_tool_strategy(agent)  # type: ignore[arg-type]

    item = agent._context.header.find_one_by_type(ItemType.TOOL_STRATEGY)
    assert item is not None
    text = item.content_text
    assert "You can call multiple tools in a single response" in text
    assert "If you do not understand why the user has denied a tool call" in text
    assert "Use the Agent tool" not in text
    assert "- **AskUserQuestion**" in text


def test_setup_tool_strategy_skips_empty_session_guidance_section() -> None:
    from comate_agent_sdk.agent.setup import setup_tool_strategy
    from comate_agent_sdk.context import ContextIR
    from comate_agent_sdk.context.items import ItemType
    from comate_agent_sdk.system_tools.tools import Bash, Read

    class FakeAgent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._runtime_state = type("S", (), {})()
            self._runtime_state.tools = [Read, Bash]
            self._is_subagent = True
            self.is_team_member = False
            self.config = type("C", (), {"disallowed_tools": None})()

    agent = FakeAgent()
    setup_tool_strategy(agent)  # type: ignore[arg-type]

    item = agent._context.header.find_one_by_type(ItemType.TOOL_STRATEGY)
    assert item is not None
    assert "# Using your tools" in item.content_text
    assert "# Session-specific guidance" not in item.content_text


def test_setup_subagents_only_creates_tool_not_header(monkeypatch: pytest.MonkeyPatch) -> None:
    from pathlib import Path

    from comate_agent_sdk.agent.setup import setup_subagents
    from comate_agent_sdk.context import ContextIR
    from comate_agent_sdk.context.items import ItemType
    from comate_agent_sdk.subagent.models import AgentDefinition
    from comate_agent_sdk.tools import ToolRegistry
    from comate_agent_sdk.tools.decorator import tool

    @tool("agent tool", name="Agent")
    async def fake_agent_tool() -> str:
        return ""

    def fake_create_agent_tool(**kwargs):  # type: ignore[no-untyped-def]
        return fake_agent_tool

    monkeypatch.setattr(
        "comate_agent_sdk.subagent.agent_tool.create_agent_tool",
        fake_create_agent_tool,
    )

    class FakeAgent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._runtime_state = type("S", (), {})()
            self._runtime_state.agents = [
                AgentDefinition(name="worker", description="w", prompt="p")
            ]
            self._runtime_state.tools = []
            self._runtime_state.tool_registry = ToolRegistry()
            self._runtime_state.cwd = Path.cwd()
            self._runtime_state.llm_levels = {}
            self._runtime_state.user_instruction = None
            self._tool_map = {}
            self.llm = None
            self._token_cost = None
            self.config = type(
                "C",
                (),
                {
                    "dependency_overrides": None,
                    "use_streaming_task": False,
                    "env_options": None,
                },
            )()

    agent = FakeAgent()
    setup_subagents(agent)  # type: ignore[arg-type]

    assert [t.name for t in agent._runtime_state.tools] == ["Agent"]
    assert agent._context.header.find_one_by_type(ItemType.SUBAGENT_STRATEGY) is None


def test_setup_skills_only_creates_tool_not_header() -> None:
    from comate_agent_sdk.agent.setup import setup_skills
    from comate_agent_sdk.context import ContextIR
    from comate_agent_sdk.context.items import ItemType
    from comate_agent_sdk.skill.models import SkillDefinition

    class FakeAgent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._runtime_state = type("S", (), {})()
            self._runtime_state.skills = [
                SkillDefinition(name="demo", description="d", prompt="p")
            ]
            self._runtime_state.tools = []
            self._tool_map = {}

    agent = FakeAgent()
    setup_skills(agent)  # type: ignore[arg-type]

    assert [t.name for t in agent._runtime_state.tools] == ["Skill"]
    assert agent._context.header.find_one_by_type(ItemType.SKILL_STRATEGY) is None
    assert agent._context.session_state.find_one_by_type(ItemType.SKILL_LISTING) is None
