"""对齐回归测试：AgentOptions.tools allowlist 白名单不含 mcp__* 时，
provider tools 数组正确排除 MCP，session_state 仍独立承载 server instructions。

spec §7.2 的完整实现。复现 examples_quick/simple_agent.py 触发的 bug 场景。
"""
from __future__ import annotations

from unittest.mock import MagicMock

from comate_agent_sdk.tools import Tool


async def _noop() -> str:
    return ""


def _make_tool(name: str, *, is_mcp: bool = False) -> Tool:
    tool = Tool(func=_noop, name=name, description=f"test tool {name}")
    if is_mcp:
        setattr(tool, "_comate_agent_sdk_mcp_tool", True)
    return tool


def test_allowlist_scenario_prompt_matches_provider_tools() -> None:
    """复现 examples_quick/simple_agent.py bug 场景。

    tools=["LS","Read","Write","Bash"] 不含 mcp__*；2 个 mock MCP server
    （一个提供 instructions，一个不提供）。
    断言：
      - provider tools 数组不含 mcp__* schema
      - session_state MCP_TOOL item 正确含 # MCP Server Instructions
      - 无旧"逐工具列表"遗留（`- mcp__...` 行绝迹）
    """
    from comate_agent_sdk.agent.core.runtime_mcp import apply_mcp_tools_to_agent
    from comate_agent_sdk.context.ir import ContextIR
    from comate_agent_sdk.context.items import ItemType
    from comate_agent_sdk.mcp.manager import McpManager, McpServerRuntimeState

    agent = MagicMock()
    agent._tools_allowlist_mode = True
    agent._requested_tool_names = ["LS", "Read", "Write", "Bash"]
    agent._runtime_state.tools = [
        _make_tool("LS"),
        _make_tool("Read"),
        _make_tool("Write"),
        _make_tool("Bash"),
    ]
    agent._context = ContextIR()

    discovered_mcp_tools = [
        _make_tool("mcp__server_a__search", is_mcp=True),
        _make_tool("mcp__server_b__fetch", is_mcp=True),
    ]
    apply_mcp_tools_to_agent(agent, discovered_mcp_tools)

    # provider tools 数组来源于 runtime_state.tools；allowlist 不含 mcp__*，
    # 因此这里不应残留任何 MCP tool schema。
    tool_names = [tool.name for tool in agent._runtime_state.tools]
    assert tool_names == ["LS", "Read", "Write", "Bash"]
    assert all(not name.startswith("mcp__") for name in tool_names)

    # MCP server instructions 是正交通道：不受 allowlist 过滤。
    mgr = McpManager({})
    mgr._server_states["server_a"] = McpServerRuntimeState(
        alias="server_a",
        status="connected",
        reason=None,
        tool_count=2,
        instructions="server A 用法",
    )
    mgr._server_states["server_b"] = McpServerRuntimeState(
        alias="server_b",
        status="connected",
        reason=None,
        tool_count=1,
        instructions=None,
    )
    overview = mgr.build_server_instructions_text()
    agent._context.set_mcp_tools(
        overview,
        metadata=mgr.build_server_instructions_metadata(),
    )

    mcp_item = agent._context.session_state.find_one_by_type(ItemType.MCP_TOOL)
    assert mcp_item is not None, "MCP_TOOL item 应存在（server_a 提供 instructions）"
    content = mcp_item.content_text
    assert content.startswith("<mcp_tools>\n")
    assert content.endswith("\n</mcp_tools>")
    assert "# MCP Server Instructions" in content
    assert "## server_a" in content
    assert "server A 用法" in content
    assert "## server_b" not in content  # 无 instructions 的 server 不出现
    assert "- mcp__" not in content      # 旧"逐工具列表"格式绝迹

    assert mcp_item.metadata is not None
    assert "servers" in mcp_item.metadata
    aliases = [s["alias"] for s in mcp_item.metadata["servers"]]
    assert "server_a" in aliases and "server_b" in aliases
    assert len(mcp_item.metadata["servers"]) == 2
