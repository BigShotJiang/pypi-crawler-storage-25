import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.chat_session import ChatSession
from comate_agent_sdk.agent.queue_types import MessageOrigin
from comate_agent_sdk.llm.views import ChatInvokeCompletion


class _FakeChatModel:
	model = "fake:model"

	@property
	def provider(self) -> str:
		return "fake"

	@property
	def name(self) -> str:
		return self.model

	async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
		del messages, tools, tool_choice, kwargs
		return ChatInvokeCompletion(content="ok")


def _template() -> Agent:
	return Agent(
		llm=_FakeChatModel(),  # type: ignore[arg-type]
		config=AgentConfig(tools=(), agents=(), offload_enabled=False),
	)


class TestChatSessionMessageSourceQueue(unittest.IsolatedAsyncioTestCase):
	async def test_message_source_feeds_queue_manager_as_human_source(self) -> None:
		with tempfile.TemporaryDirectory() as td:
			session = ChatSession(
				_template(),
				cwd=Path(td) / "session",
				message_source=["first", "second"],
			)

			await session._ensure_message_source_task()
			self.assertIsNotNone(session._message_source_task)
			await session._message_source_task

			snapshot = session.peek_queue()
			self.assertEqual([message.content for message in snapshot], ["first", "second"])
			self.assertEqual(
				[message.origin for message in snapshot],
				[MessageOrigin.HUMAN, MessageOrigin.HUMAN],
			)
			self.assertEqual(
				[message.origin_metadata for message in snapshot],
				[{"source": "message_source"}, {"source": "message_source"}],
			)
			self.assertTrue(session._message_source_finished_event.is_set())

	async def test_send_is_allowed_when_message_source_exists(self) -> None:
		with tempfile.TemporaryDirectory() as td:
			session = ChatSession(
				_template(),
				cwd=Path(td) / "session",
				message_source=[],
			)

			message_id = await session.send("manual")

			snapshot = session.peek_queue()
			self.assertEqual(len(snapshot), 1)
			self.assertEqual(snapshot[0].message_id, message_id)
			self.assertEqual(snapshot[0].content, "manual")
			self.assertIs(snapshot[0].origin, MessageOrigin.HUMAN)


if __name__ == "__main__":
	unittest.main(verbosity=2)
