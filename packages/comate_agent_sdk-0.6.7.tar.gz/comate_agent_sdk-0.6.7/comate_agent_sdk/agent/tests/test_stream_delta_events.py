import unittest

from comate_agent_sdk.agent.events import (
    AgentEvent,
    TextDeltaEvent,
    ThinkingDeltaEvent,
    ToolCallStartEvent,
)


class TestStreamDeltaEvents(unittest.TestCase):
    def test_text_delta_event_fields(self) -> None:
        ev = TextDeltaEvent(delta="Hello", message_id="msg-1")
        self.assertEqual(ev.delta, "Hello")
        self.assertEqual(ev.message_id, "msg-1")

    def test_thinking_delta_event_fields(self) -> None:
        ev = ThinkingDeltaEvent(delta="Let me think", message_id="msg-2")
        self.assertEqual(ev.delta, "Let me think")
        self.assertEqual(ev.message_id, "msg-2")

    def test_tool_call_start_event_fields(self) -> None:
        ev = ToolCallStartEvent(tool_call_id="toolu_1", tool="Edit")
        self.assertEqual(ev.tool_call_id, "toolu_1")
        self.assertEqual(ev.tool, "Edit")

    def test_events_part_of_agent_event_union(self) -> None:
        td: AgentEvent = TextDeltaEvent(delta="x", message_id="m")
        thd: AgentEvent = ThinkingDeltaEvent(delta="x", message_id="m")
        tcs: AgentEvent = ToolCallStartEvent(tool_call_id="t", tool="T")
        self.assertIsNotNone(td)
        self.assertIsNotNone(thd)
        self.assertIsNotNone(tcs)


if __name__ == "__main__":
    unittest.main()
