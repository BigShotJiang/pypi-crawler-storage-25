import unittest

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.events import QueuedMessageInjectedEvent
from comate_agent_sdk.agent.queue_bridge import QueueInjectionBridge
from comate_agent_sdk.agent.queue_manager import QueueManager
from comate_agent_sdk.agent.queue_types import MessageOrigin
from comate_agent_sdk.llm.messages import UserMessage
from comate_agent_sdk.llm.views import ChatInvokeCompletion


class _FakeChatModel:
    model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del messages, tools, tool_choice, kwargs
        return ChatInvokeCompletion(content="ok")


def _runtime():
    template = Agent(
        llm=_FakeChatModel(),  # type: ignore[arg-type]
        config=AgentConfig(
            tools=(),
            agents=(),
            offload_enabled=False,
            memory_background_enabled=False,
            setting_sources=None,
        ),
    )
    return template.create_runtime()


class TestQueueInjectionTransaction(unittest.TestCase):
    def test_inject_queued_messages_consumes_writes_meta_message_and_emits_event(self) -> None:
        from comate_agent_sdk.agent.runner_engine.loop_hooks import inject_queued_messages

        agent = _runtime()
        manager = QueueManager()
        first_id = manager.enqueue("first queued", origin=MessageOrigin.HUMAN)
        second_id = manager.enqueue("second queued", origin=MessageOrigin.COORDINATOR)
        bridge = QueueInjectionBridge(
            trigger_message_id="trigger-1",
            queue_manager=manager,
        )

        events = inject_queued_messages(
            agent,
            bridge,
            manager.peek_for_injection(),
            call_index=3,
        )

        self.assertEqual(manager.peek(), ())
        self.assertEqual(len(events), 1)
        self.assertIsInstance(events[0], QueuedMessageInjectedEvent)
        self.assertEqual(events[0].message_ids, (first_id, second_id))
        self.assertEqual(events[0].origins, (MessageOrigin.HUMAN, MessageOrigin.COORDINATOR))
        self.assertEqual(events[0].injected_at_turn, 0)
        self.assertEqual(events[0].call_index, 3)
        self.assertEqual(events[0].trigger_message_id, "trigger-1")

        user_messages = [
            message
            for message in agent.messages
            if isinstance(message, UserMessage) and message.is_meta
        ]
        self.assertEqual(len(user_messages), 1)
        self.assertIn("first queued", user_messages[0].text)
        self.assertIn("second queued", user_messages[0].text)

    def test_inject_queued_messages_requeues_consumed_messages_when_context_write_fails(self) -> None:
        from comate_agent_sdk.agent.runner_engine.loop_hooks import inject_queued_messages

        agent = _runtime()
        manager = QueueManager()
        first_id = manager.enqueue("first queued", origin=MessageOrigin.HUMAN)
        second_id = manager.enqueue("second queued", origin=MessageOrigin.COORDINATOR)
        bridge = QueueInjectionBridge(
            trigger_message_id=None,
            queue_manager=manager,
        )

        def _raise(*args, **kwargs):  # type: ignore[no-untyped-def]
            del args, kwargs
            raise RuntimeError("write failed")

        agent._context.add_message = _raise  # type: ignore[method-assign]

        with self.assertRaisesRegex(RuntimeError, "write failed"):
            inject_queued_messages(
                agent,
                bridge,
                manager.peek_for_injection(),
                call_index=0,
            )

        self.assertEqual(
            [message.message_id for message in manager.peek()],
            [first_id, second_id],
        )

    def test_inject_queued_messages_does_not_cross_active_tool_barrier(self) -> None:
        from comate_agent_sdk.agent.runner_engine.loop_hooks import inject_queued_messages

        agent = _runtime()
        manager = QueueManager()
        message_id = manager.enqueue(
            "queued while barrier active",
            origin=MessageOrigin.HUMAN,
        )
        bridge = QueueInjectionBridge(
            trigger_message_id=None,
            queue_manager=manager,
        )
        agent._context.begin_tool_barrier(["tc_pending"])

        events = inject_queued_messages(
            agent,
            bridge,
            manager.peek_for_injection(),
            call_index=1,
        )

        self.assertEqual(events, [])
        self.assertEqual([message.message_id for message in manager.peek()], [message_id])
        self.assertEqual(
            [
                message
                for message in agent.messages
                if isinstance(message, UserMessage) and message.is_meta
            ],
            [],
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
