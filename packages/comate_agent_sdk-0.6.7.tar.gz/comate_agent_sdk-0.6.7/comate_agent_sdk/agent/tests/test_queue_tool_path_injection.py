import asyncio
import json
import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.events import (
    QueuedMessageInjectedEvent,
    StopEvent,
    ToolCallEvent,
)
from comate_agent_sdk.llm.messages import Function, ToolCall, UserMessage
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.tools import tool


class _RecordingChatModel:
    def __init__(self, completions: list[ChatInvokeCompletion]) -> None:
        self._completions = completions
        self._idx = 0
        self.model = "fake:model"
        self.calls: list[list[object]] = []

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del tools, tool_choice, kwargs
        self.calls.append(list(messages))
        if self._idx >= len(self._completions):
            raise AssertionError(f"Unexpected ainvoke call #{self._idx + 1}")
        completion = self._completions[self._idx]
        self._idx += 1
        return completion


def _tool_call() -> ToolCall:
    return ToolCall(
        id="tc_wait_1",
        function=Function(
            name="WaitTool",
            arguments=json.dumps({}, ensure_ascii=False),
        ),
    )


class TestQueueToolPathInjection(unittest.IsolatedAsyncioTestCase):
    async def test_tool_path_injects_message_queued_during_tool_before_next_llm_call(self) -> None:
        release_tool: asyncio.Event | None = None

        @tool("Wait until the test releases this tool.", name="WaitTool")
        async def WaitTool() -> str:
            assert release_tool is not None
            await release_tool.wait()
            return "tool done"

        llm = _RecordingChatModel(
            [
                ChatInvokeCompletion(tool_calls=[_tool_call()]),
                ChatInvokeCompletion(content="done"),
            ]
        )
        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(WaitTool,),
                agents=(),
                offload_enabled=False,
                memory_background_enabled=False,
                setting_sources=None,
            ),
        )

        with tempfile.TemporaryDirectory() as td:
            session = template.chat(cwd=Path(td) / "session")
            first_id = await session.send("first")
            queued_id = ""

            release_tool = asyncio.Event()
            stream = session.events()
            events = []
            async for event in stream:
                events.append(event)
                if isinstance(event, ToolCallEvent):
                    queued_id = await session.send("queued while tool runs")
                    release_tool.set()
                if isinstance(event, StopEvent):
                    break
            await stream.aclose()
            await session.close()

        injected_events = [
            event for event in events if isinstance(event, QueuedMessageInjectedEvent)
        ]
        self.assertEqual(len(injected_events), 1)
        self.assertEqual(injected_events[0].message_ids, (queued_id,))
        self.assertEqual(injected_events[0].trigger_message_id, first_id)
        self.assertEqual(injected_events[0].call_index, 1)

        self.assertEqual(session.peek_queue(), ())
        self.assertEqual(len(llm.calls), 2)
        first_call_text = "\n".join(
            message.text for message in llm.calls[0] if isinstance(message, UserMessage)
        )
        second_call_text = "\n".join(
            message.text for message in llm.calls[1] if isinstance(message, UserMessage)
        )
        self.assertNotIn("queued while tool runs", first_call_text)
        self.assertIn("queued while tool runs", second_call_text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
