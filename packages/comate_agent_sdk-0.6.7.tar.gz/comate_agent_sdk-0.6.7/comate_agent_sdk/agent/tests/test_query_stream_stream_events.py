import unittest
from types import SimpleNamespace

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.events import StopEvent, TextDeltaEvent, TextEvent


def _openai_chunk(content: str, *, finish_reason: str | None = None) -> SimpleNamespace:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                delta=SimpleNamespace(content=content),
                finish_reason=finish_reason,
            )
        ],
        usage=None,
    )


class _StreamingLLM:
    model = "fake-openai"
    provider = "openai"

    @property
    def name(self) -> str:
        return self.model

    async def astream(self, messages, tools=None, tool_choice=None, **kwargs):
        del messages, tools, tool_choice, kwargs
        yield _openai_chunk("Hel")
        yield _openai_chunk("lo", finish_reason="stop")

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):
        del messages, tools, tool_choice, kwargs
        raise AssertionError("query_stream should consume stream_llm_events")


class TestQueryStreamStreamEvents(unittest.IsolatedAsyncioTestCase):
    async def test_query_stream_forwards_transient_deltas_before_durable_text(self) -> None:
        template = Agent(
            llm=_StreamingLLM(),  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                offload_enabled=False,
            ),
        )
        agent = template.create_runtime()

        events = [event async for event in agent.query_stream("Hi")]

        delta_events = [event for event in events if isinstance(event, TextDeltaEvent)]
        text_events = [event for event in events if isinstance(event, TextEvent)]
        stop_events = [event for event in events if isinstance(event, StopEvent)]

        self.assertEqual([event.delta for event in delta_events], ["Hel", "lo"])
        self.assertTrue(any(event.content == "Hello" for event in text_events))
        self.assertTrue(stop_events)
        first_delta_index = next(
            index for index, event in enumerate(events) if isinstance(event, TextDeltaEvent)
        )
        final_text_index = next(
            index
            for index, event in enumerate(events)
            if isinstance(event, TextEvent) and event.content == "Hello"
        )
        self.assertLess(first_delta_index, final_text_index)


if __name__ == "__main__":
    unittest.main()
