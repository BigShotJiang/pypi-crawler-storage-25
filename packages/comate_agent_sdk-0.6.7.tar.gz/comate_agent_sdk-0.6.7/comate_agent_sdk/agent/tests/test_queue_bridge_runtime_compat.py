import unittest

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.queue_manager import QueueManager
from comate_agent_sdk.agent.queue_types import MessageOrigin
from comate_agent_sdk.agent.events import StopEvent, TextEvent
from comate_agent_sdk.llm.views import ChatInvokeCompletion


class _FakeChatModel:
    model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del messages, tools, tool_choice, kwargs
        return ChatInvokeCompletion(content="ok")


def _template() -> Agent:
    return Agent(
        llm=_FakeChatModel(),  # type: ignore[arg-type]
        config=AgentConfig(tools=(), agents=(), offload_enabled=False),
    )


class TestQueueBridgeRuntimeCompat(unittest.IsolatedAsyncioTestCase):
    async def test_runtime_query_stream_without_bridge_keeps_existing_behavior(self) -> None:
        runtime = _template().create_runtime()

        events = [event async for event in runtime.query_stream("hello")]

        self.assertTrue(any(isinstance(event, TextEvent) and event.content == "ok" for event in events))
        self.assertTrue(any(isinstance(event, StopEvent) and event.reason == "completed" for event in events))

    async def test_runtime_query_stream_accepts_internal_optional_bridge(self) -> None:
        from comate_agent_sdk.agent.queue_bridge import QueueInjectionBridge

        runtime = _template().create_runtime()
        manager = QueueManager()
        bridge = QueueInjectionBridge(
            trigger_message_id="trigger-1",
            queue_manager=manager,
        )

        events = [event async for event in runtime.query_stream("hello", queue_bridge=bridge)]

        self.assertTrue(any(isinstance(event, TextEvent) and event.content == "ok" for event in events))

    async def test_agent_template_query_stream_does_not_expose_queue_bridge(self) -> None:
        template = _template()

        with self.assertRaises(TypeError):
            [event async for event in template.query_stream("hello", queue_bridge=object())]  # type: ignore[call-arg]

    def test_queue_injection_bridge_delegates_to_queue_manager(self) -> None:
        from comate_agent_sdk.agent.queue_bridge import QueueInjectionBridge

        manager = QueueManager()
        first_id = manager.enqueue("first", origin=MessageOrigin.HUMAN)
        second_id = manager.enqueue("second", origin=MessageOrigin.COORDINATOR)
        bridge = QueueInjectionBridge(
            trigger_message_id=first_id,
            queue_manager=manager,
        )

        snapshot = bridge.peek_for_injection()
        consumed = bridge.consume_batch([second_id])
        bridge.requeue_at_head(consumed)

        self.assertEqual(bridge.trigger_message_id, first_id)
        self.assertEqual([message.message_id for message in snapshot], [first_id, second_id])
        self.assertEqual([message.message_id for message in manager.peek()], [second_id, first_id])


if __name__ == "__main__":
	unittest.main(verbosity=2)
