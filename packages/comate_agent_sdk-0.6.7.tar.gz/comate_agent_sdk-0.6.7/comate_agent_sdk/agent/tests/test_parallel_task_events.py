import asyncio
import json
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.events import (
    StepCompleteEvent,
    StopEvent,
    SubagentStartEvent,
    SubagentStopEvent,
    ToolResultEvent,
)
from comate_agent_sdk.llm.messages import Function, ToolCall
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.subagent.models import AgentDefinition
from comate_agent_sdk.system_tools.team.config import TeamConfig
from comate_agent_sdk.tools import tool


class _FakeChatModel:
    def __init__(self, completions: list[ChatInvokeCompletion]):
        self._completions = completions
        self._idx = 0
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        if self._idx >= len(self._completions):
            raise AssertionError(f"Unexpected ainvoke call #{self._idx + 1}")
        completion = self._completions[self._idx]
        self._idx += 1
        return completion


class _BackgroundRuntime:
    def __init__(self) -> None:
        self.options = SimpleNamespace(skills=[])
        self.release = asyncio.Event()
        self._suppress_team_idle_notification = False

    async def query(self, prompt: str) -> str:
        _ = prompt
        await self.release.wait()
        return "background complete"

    async def aclose(self) -> None:
        return None


class TestParallelTaskEvents(unittest.IsolatedAsyncioTestCase):
    async def test_query_stream_emits_subagent_start_stop_and_completion_order(self) -> None:
        delays = {"a": 0.25, "b": 0.05, "c": 0.15}

        @tool("Agent tool (test)", name="Agent")
        async def AgentTool(subagent_type: str, prompt: str, description: str = "") -> str:
            await asyncio.sleep(delays[subagent_type])
            return f"ok:{subagent_type}"

        tool_calls = [
            ToolCall(
                id="tc_a",
                function=Function(
                    name="Agent",
                    arguments=json.dumps(
                        {"subagent_type": "a", "prompt": "p", "description": "alpha"},
                        ensure_ascii=False,
                    ),
                ),
            ),
            ToolCall(
                id="tc_b",
                function=Function(
                    name="Agent",
                    arguments=json.dumps(
                        {"subagent_type": "b", "prompt": "p", "description": "beta"},
                        ensure_ascii=False,
                    ),
                ),
            ),
            ToolCall(
                id="tc_c",
                function=Function(
                    name="Agent",
                    arguments=json.dumps(
                        {"subagent_type": "c", "prompt": "p", "description": "gamma"},
                        ensure_ascii=False,
                    ),
                ),
            ),
        ]

        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(tool_calls=tool_calls),
                ChatInvokeCompletion(content="done"),
            ]
        )

        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(AgentTool,),
                agents=(),
                offload_enabled=False,
                task_parallel_enabled=True,
                task_parallel_max_concurrency=4,
            ),
        )
        agent = template.create_runtime()

        events = []
        async for event in agent.query_stream("hi"):
            events.append(event)

        start_names = [e.subagent_name for e in events if isinstance(e, SubagentStartEvent)]
        stop_names = [e.subagent_name for e in events if isinstance(e, SubagentStopEvent)]

        self.assertEqual(start_names, ["a", "b", "c"])
        self.assertEqual(stop_names, ["b", "c", "a"])

        tool_results = [
            e.tool_call_id
            for e in events
            if isinstance(e, ToolResultEvent) and e.tool == "Agent"
        ]
        self.assertEqual(tool_results, ["tc_b", "tc_c", "tc_a"])

        # ToolMessage(s) are written to context in call order for reproducibility
        tool_msgs = [m for m in agent.messages if getattr(m, "role", None) == "tool"]
        tool_msg_ids = [m.tool_call_id for m in tool_msgs if getattr(m, "tool_name", "") == "Agent"]
        self.assertEqual(tool_msg_ids, ["tc_a", "tc_b", "tc_c"])

    async def test_query_parallel_task_writes_context_in_call_order_and_tasks_overlap(self) -> None:
        starts: list[float] = []
        ends: list[float] = []

        @tool("Agent tool (test)", name="Agent")
        async def AgentTool(subagent_type: str, prompt: str, description: str = "") -> str:
            starts.append(time.perf_counter())
            await asyncio.sleep(0.2)
            ends.append(time.perf_counter())
            return f"ok:{subagent_type}"

        tool_calls = [
            ToolCall(
                id="tc1",
                function=Function(
                    name="Agent",
                    arguments=json.dumps(
                        {"subagent_type": "a", "prompt": "p", "description": "d1"},
                        ensure_ascii=False,
                    ),
                ),
            ),
            ToolCall(
                id="tc2",
                function=Function(
                    name="Agent",
                    arguments=json.dumps(
                        {"subagent_type": "b", "prompt": "p", "description": "d2"},
                        ensure_ascii=False,
                    ),
                ),
            ),
            ToolCall(
                id="tc3",
                function=Function(
                    name="Agent",
                    arguments=json.dumps(
                        {"subagent_type": "c", "prompt": "p", "description": "d3"},
                        ensure_ascii=False,
                    ),
                ),
            ),
        ]

        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(tool_calls=tool_calls),
                ChatInvokeCompletion(content="done"),
            ]
        )

        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(AgentTool,),
                agents=(),
                offload_enabled=False,
                task_parallel_enabled=True,
                task_parallel_max_concurrency=4,
            ),
        )
        agent = template.create_runtime()

        _ = await agent.query("hi")

        self.assertEqual(len(starts), 3)
        self.assertEqual(len(ends), 3)
        # If tasks are parallelized, all starts should happen before the first end.
        self.assertLess(max(starts), min(ends))

        tool_msgs = [m for m in agent.messages if getattr(m, "role", None) == "tool"]
        tool_msg_ids = [m.tool_call_id for m in tool_msgs if getattr(m, "tool_name", "") == "Agent"]
        self.assertEqual(tool_msg_ids, ["tc1", "tc2", "tc3"])

    async def test_parallel_future_exception_cancels_pending_tasks_and_commits_results(self) -> None:
        cancelled = asyncio.Event()

        @tool("Agent tool (test)", name="Agent")
        async def AgentTool(subagent_type: str, prompt: str, description: str = "") -> str:
            del subagent_type, prompt, description
            return "ok"

        tool_calls = [
            ToolCall(
                id="tc_fail",
                function=Function(
                    name="Agent",
                    arguments=json.dumps(
                        {"subagent_type": "a", "prompt": "p", "description": "alpha"},
                        ensure_ascii=False,
                    ),
                ),
            ),
            ToolCall(
                id="tc_pending",
                function=Function(
                    name="Agent",
                    arguments=json.dumps(
                        {"subagent_type": "b", "prompt": "p", "description": "beta"},
                        ensure_ascii=False,
                    ),
                ),
            ),
        ]

        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(tool_calls=tool_calls),
                ChatInvokeCompletion(content="done"),
            ]
        )

        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(AgentTool,),
                agents=(),
                offload_enabled=False,
                task_parallel_enabled=True,
                task_parallel_max_concurrency=4,
            ),
        )
        agent = template.create_runtime()

        async def _fake_execute_tool_call(_agent, tool_call):  # type: ignore[no-untyped-def]
            if tool_call.id == "tc_fail":
                raise RuntimeError("boom")
            try:
                await asyncio.Event().wait()
            except asyncio.CancelledError:
                cancelled.set()
                raise

        events: list[object] = []
        with patch(
            "comate_agent_sdk.agent.runner_engine.execution.tool_execution.execute_tool_call",
            _fake_execute_tool_call,
        ):
            async for event in agent.query_stream("hi"):
                events.append(event)

        self.assertTrue(cancelled.is_set())
        self.assertEqual(
            [event.reason for event in events if isinstance(event, StopEvent)],
            ["completed"],
        )

        tool_results = [event for event in events if isinstance(event, ToolResultEvent)]
        self.assertEqual(len(tool_results), 1)
        self.assertEqual(tool_results[0].tool_call_id, "tc_fail")
        self.assertTrue(tool_results[0].is_error)
        self.assertIn("boom", tool_results[0].result)

        cancelled_steps = {
            event.step_id
            for event in events
            if isinstance(event, StepCompleteEvent) and event.status == "cancelled"
        }
        self.assertSetEqual(cancelled_steps, {"tc_pending"})

        tool_msgs = [m for m in agent.messages if getattr(m, "role", None) == "tool"]
        tool_msg_ids = [m.tool_call_id for m in tool_msgs if getattr(m, "tool_name", "") == "Agent"]
        self.assertEqual(tool_msg_ids, ["tc_fail", "tc_pending"])

    async def test_user_task_tool_conflict_raises_when_subagents_enabled(self) -> None:
        @tool("Agent tool (test)", name="Agent")
        async def AgentTool(subagent_type: str, prompt: str, description: str = "") -> str:
            return f"ok:{subagent_type}"

        llm = _FakeChatModel([ChatInvokeCompletion(content="done")])

        project_root = Path(__file__).resolve().parents[3]
        with self.assertRaises(ValueError) as ctx:
            template = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(AgentTool,),
                    cwd=project_root,
                    offload_enabled=False,
                ),
            )
            _ = template.create_runtime()

        self.assertIn("Agent", str(ctx.exception))

    async def test_team_session_call_emits_ack_without_subagent_lifecycle_events(self) -> None:
        tool_call = ToolCall(
            id="tc_bg",
            function=Function(
                name="Agent",
                arguments=json.dumps(
                    {
                        "subagent_type": "worker",
                        "prompt": "p",
                        "description": "bg worker",
                        "team_name": "review-team",
                        "name": "worker-1",
                    },
                    ensure_ascii=False,
                ),
            ),
        )

        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(tool_calls=[tool_call]),
                ChatInvokeCompletion(content="done"),
            ]
        )

        background_runtime = _BackgroundRuntime()
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                template = Agent(
                    llm=llm,  # type: ignore[arg-type]
                    config=AgentConfig(
                        tools=("Agent",),
                        agents=(
                            AgentDefinition(
                                name="worker",
                                description="worker",
                                prompt="You are a worker.",
                                tools=[],
                            ),
                        ),
                        offload_enabled=False,
                        task_parallel_enabled=True,
                        cwd=Path(td),
                    ),
                )
                agent = template.create_runtime(name="captain", team_name="review-team")
                TeamConfig(team_name="review-team").register_member(
                    name="captain",
                    agent_type="leader",
                )

                async def _fake_team_session() -> None:
                    try:
                        await background_runtime.query("p")
                    finally:
                        await background_runtime.aclose()

                with patch(
                    "comate_agent_sdk.agent.core.template.AgentTemplate.create_runtime",
                    return_value=background_runtime,
                ), patch(
                    "comate_agent_sdk.subagent.team_session.start_team_session",
                    return_value=asyncio.create_task(_fake_team_session()),
                ):
                    events = []
                    async for event in agent.query_stream("hi"):
                        events.append(event)

                background_runtime.release.set()
                await agent.aclose()

        self.assertEqual(
            [event.subagent_name for event in events if isinstance(event, SubagentStartEvent)],
            [],
        )
        self.assertEqual(
            [event.subagent_name for event in events if isinstance(event, SubagentStopEvent)],
            [],
        )

        tool_results = [
            event
            for event in events
            if isinstance(event, ToolResultEvent) and event.tool == "Agent"
        ]
        self.assertEqual(len(tool_results), 1)
        self.assertIn("has joined team", tool_results[0].result)
