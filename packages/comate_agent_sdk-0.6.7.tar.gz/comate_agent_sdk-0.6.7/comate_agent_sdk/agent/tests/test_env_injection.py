import subprocess
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.context import EnvOptions
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import UserMessage


def _env_visible_text(agent) -> str:  # type: ignore[no-untyped-def]
    """聚合所有可见 env 文本面。

    CWD 已迁到 project_context（header），不再落到 session_state 的 is_meta
    messages。所以要查 repo 路径必须同时看 header.PROJECT_CONTEXT + is_meta messages。
    """
    meta_texts = [
        m.text
        for m in agent.messages
        if isinstance(m, UserMessage) and bool(getattr(m, "is_meta", False))
    ]
    header_texts = [
        item.content_text
        for item in agent._context.header.items
        if item.item_type == ItemType.PROJECT_CONTEXT
    ]
    return "\n".join(meta_texts + header_texts)


class _FakeChatModel:
    def __init__(self):
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        raise AssertionError("This test should not call the LLM")


def _run_git(args: list[str], cwd: Path) -> None:
    subprocess.run(
        ["git", *args],
        cwd=str(cwd),
        check=True,
        text=True,
        capture_output=True,
    )


def _init_repo(repo_dir: Path) -> None:
    _run_git(["init"], repo_dir)
    _run_git(["config", "user.email", "test@example.com"], repo_dir)
    _run_git(["config", "user.name", "test"], repo_dir)
    (repo_dir / "a.txt").write_text("a", encoding="utf-8")
    _run_git(["add", "a.txt"], repo_dir)
    _run_git(["commit", "-m", "init"], repo_dir)


def test_agent_injects_env_snapshot_from_project_root(tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)

    template = Agent(
        llm=_FakeChatModel(),  # type: ignore[arg-type]
        config=AgentConfig(
            tools=(),
            agents=(),
            offload_enabled=False,
            cwd=repo,
            setting_sources=None,
            env_options=EnvOptions(system_env=True, git_env=True),
        ),
    )
    agent = template.create_runtime()

    merged = _env_visible_text(agent)

    assert "<system_env>" in merged
    assert "<git_env>" in merged
    # CWD 现在住在 project_context（header），不是 system_env
    assert str(repo.resolve()) in merged
    assert merged.index("<system_env>") < merged.index("<git_env>")


def test_agent_env_options_accepts_str_working_dir(tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    other = tmp_path / "other"
    repo.mkdir()
    other.mkdir()
    _init_repo(repo)

    template = Agent(
        llm=_FakeChatModel(),  # type: ignore[arg-type]
        config=AgentConfig(
            tools=(),
            agents=(),
            offload_enabled=False,
            cwd=other,
            setting_sources=None,
            env_options=EnvOptions(system_env=True, git_env=True, working_dir=str(repo)),
        ),
    )
    agent = template.create_runtime()

    merged = _env_visible_text(agent)

    assert "<system_env>" in merged
    # <git_env> 出现本身就是 str→Path 规范化生效的契约：
    # 若 working_dir="str(repo)" 未被接受或未传递给 EnvProvider，会回落到
    # cwd=other（非 git 仓库），<git_env> 将不会出现。
    assert "<git_env>" in merged
