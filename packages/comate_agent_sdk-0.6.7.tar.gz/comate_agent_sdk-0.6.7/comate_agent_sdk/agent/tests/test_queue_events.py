from dataclasses import fields
from typing import get_args

from comate_agent_sdk.agent.events import (
	AgentEvent,
	QueueDirtyEvent,
	QueueDirtyReason,
	QueuedMessageInjectedEvent,
)


def test_queue_dirty_reason_values_are_stable() -> None:
	assert QueueDirtyReason.ENQUEUED == "enqueued"
	assert QueueDirtyReason.CONSUMED == "consumed"
	assert QueueDirtyReason.CANCELLED == "cancelled"
	assert QueueDirtyReason.CLEARED == "cleared"


def test_queue_event_fields_are_fixed() -> None:
	assert [field.name for field in fields(QueueDirtyEvent)] == [
		"reason",
		"queue_size",
		"message_ids",
		"origins",
	]
	assert [field.name for field in fields(QueuedMessageInjectedEvent)] == [
		"message_ids",
		"origins",
		"injected_at_turn",
		"call_index",
		"trigger_message_id",
	]


def test_queue_events_are_in_agent_event_union() -> None:
	union_members = set(get_args(AgentEvent))

	assert QueueDirtyEvent in union_members
	assert QueuedMessageInjectedEvent in union_members
