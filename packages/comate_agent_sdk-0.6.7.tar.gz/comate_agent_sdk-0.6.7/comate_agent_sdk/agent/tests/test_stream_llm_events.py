import asyncio
import unittest
from types import SimpleNamespace

from comate_agent_sdk.agent.events import TextDeltaEvent
from comate_agent_sdk.agent.llm import _FinalLLMResponse, invoke_llm, stream_llm_events
from comate_agent_sdk.llm.messages import UserMessage
from comate_agent_sdk.llm.views import ChatInvokeCompletion


def _openai_chunk(content: str, *, finish_reason: str | None = None) -> SimpleNamespace:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                delta=SimpleNamespace(content=content),
                finish_reason=finish_reason,
            )
        ],
        usage=None,
    )


class _Context:
    total_tokens = 0

    def __init__(self) -> None:
        self.inject_calls = 0

    def inject_due_reminders(self) -> None:
        self.inject_calls += 1

    def lower(self):
        return [UserMessage(content="Hi")]


class _TokenCost:
    def add_usage(self, *args, **kwargs) -> None:
        del args, kwargs


class _FakeAgent:
    def __init__(self, llm) -> None:
        self.llm = llm
        self.config = SimpleNamespace(
            llm_max_retries=1,
            llm_retry_base_delay=0.01,
            llm_retry_max_delay=0.01,
            llm_retryable_status_codes=[429, 500, 502, 503, 504],
            tool_choice=None,
            output_format=None,
            structured_output_max_retries=1,
        )
        self._context = _Context()
        self.tool_definitions = []
        self._token_cost = _TokenCost()
        self._subagent_source_prefix = None
        self._effective_level = None
        self._context_usage_tracker = None
        self.ensure_mcp_calls = 0

    async def ensure_mcp_tools_loaded(self) -> None:
        self.ensure_mcp_calls += 1


class _StreamingLLM:
    model = "fake-openai"
    provider = "openai"

    async def astream(self, messages, tools=None, tool_choice=None, **kwargs):
        del messages, tools, tool_choice, kwargs
        yield _openai_chunk("Hel")
        yield _openai_chunk("lo", finish_reason="stop")

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):
        del messages, tools, tool_choice, kwargs
        raise AssertionError("stream provider should use astream")


class _NonStreamingLLM:
    model = "fake-google"
    provider = "google"

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):
        del messages, tools, tool_choice, kwargs
        return ChatInvokeCompletion(content="fallback")


class TestStreamLlmEvents(unittest.IsolatedAsyncioTestCase):
    async def test_stream_provider_yields_delta_events_and_final_response(self) -> None:
        agent = _FakeAgent(_StreamingLLM())

        items = [item async for item in stream_llm_events(agent)]

        self.assertEqual(agent.ensure_mcp_calls, 1)
        self.assertEqual(agent._context.inject_calls, 1)
        self.assertIsInstance(items[0], TextDeltaEvent)
        self.assertEqual(items[0].delta, "Hel")
        self.assertIsInstance(items[1], TextDeltaEvent)
        self.assertEqual(items[1].delta, "lo")
        self.assertIsInstance(items[2], _FinalLLMResponse)
        self.assertEqual(items[2].response.content, "Hello")
        self.assertEqual(items[2].response.stop_reason, "stop")

    async def test_non_stream_provider_yields_only_final_response(self) -> None:
        agent = _FakeAgent(_NonStreamingLLM())

        items = [item async for item in stream_llm_events(agent)]

        self.assertEqual(len(items), 1)
        self.assertIsInstance(items[0], _FinalLLMResponse)
        self.assertEqual(items[0].response.content, "fallback")

    async def test_invoke_llm_keeps_awaitable_completion_contract(self) -> None:
        agent = _FakeAgent(_StreamingLLM())

        result = await invoke_llm(agent)

        self.assertIsInstance(result, ChatInvokeCompletion)
        self.assertEqual(result.content, "Hello")


if __name__ == "__main__":
    unittest.main()
