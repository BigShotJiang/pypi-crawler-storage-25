from __future__ import annotations

from comate_agent_sdk.tools.decorator import tool


def test_tool_without_prompt_hint_defaults_none() -> None:
    @tool("desc", name="T1")
    async def t1() -> str:
        return "x"

    assert t1.prompt_hint is None


def test_tool_with_prompt_hint_stored() -> None:
    @tool("desc", name="T2", prompt_hint="short policy line")
    async def t2() -> str:
        return "x"

    assert t2.prompt_hint == "short policy line"


def test_facade_tool_decorator_passes_prompt_hint() -> None:
    from comate_agent_sdk.facade.tools.decorators import tool as facade_tool

    @facade_tool("desc", name="T3", prompt_hint="facade hint")
    async def t3() -> str:
        from mcp.types import TextContent

        from comate_agent_sdk.tools import ToolResult

        return ToolResult(content=[TextContent(type="text", text="x")])

    assert t3.prompt_hint == "facade hint"


def test_system_tools_have_prompt_hints() -> None:
    from comate_agent_sdk.system_tools.team.tools import TeamCreate
    from comate_agent_sdk.system_tools.tools import (
        AskUserQuestion,
        ExitPlanMode,
        YieldTurn,
    )

    assert "ONLY tool call" in (AskUserQuestion.prompt_hint or "")
    assert "ONLY tool call" in (YieldTurn.prompt_hint or "")
    assert "Plan mode" in (ExitPlanMode.prompt_hint or "")
    assert "Team mode" in (TeamCreate.prompt_hint or "")
