import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.chat_session import ChatSession
from comate_agent_sdk.agent.queue_bridge import QueueInjectionBridge
from comate_agent_sdk.agent.queue_manager import QueueManager
from comate_agent_sdk.agent.queue_types import MessageOrigin
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import UserMessage
from comate_agent_sdk.llm.views import ChatInvokeCompletion


class _FakeChatModel:
    model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del messages, tools, tool_choice, kwargs
        return ChatInvokeCompletion(content="ok")


def _template() -> Agent:
    return Agent(
        llm=_FakeChatModel(),  # type: ignore[arg-type]
        config=AgentConfig(
            tools=(),
            agents=(),
            offload_enabled=False,
            memory_background_enabled=False,
            setting_sources=None,
        ),
    )


class TestQueueContextInvariants(unittest.IsolatedAsyncioTestCase):
    def test_multiple_queue_injections_do_not_increment_turn_number(self) -> None:
        from comate_agent_sdk.agent.runner_engine.loop_hooks import inject_queued_messages

        agent = _template().create_runtime()
        agent._context.add_message(UserMessage(content="trigger"))
        self.assertEqual(agent._context.turn_number, 1)

        manager = QueueManager()
        bridge = QueueInjectionBridge(trigger_message_id=None, queue_manager=manager)

        first_id = manager.enqueue("first queued", origin=MessageOrigin.HUMAN)
        inject_queued_messages(
            agent,
            bridge,
            manager.peek_for_injection(),
            call_index=0,
        )
        second_id = manager.enqueue("second queued", origin=MessageOrigin.COORDINATOR)
        inject_queued_messages(
            agent,
            bridge,
            manager.peek_for_injection(),
            call_index=1,
        )

        self.assertEqual(agent._context.turn_number, 1)
        self.assertEqual(manager.peek(), ())
        injected_items = [
            item
            for item in agent._context.get_conversation_items_snapshot()
            if item.item_type == ItemType.USER_MESSAGE
            and isinstance(item.message, UserMessage)
            and item.message.is_meta
        ]
        self.assertEqual(len(injected_items), 2)
        self.assertIn("first queued", injected_items[0].message.text)
        self.assertIn("second queued", injected_items[1].message.text)
        self.assertNotEqual(first_id, second_id)

    def test_queue_injection_stays_in_conversation_layer(self) -> None:
        from comate_agent_sdk.agent.runner_engine.loop_hooks import inject_queued_messages

        agent = _template().create_runtime()
        header_before = agent._context.export_header_snapshot()
        session_state_before = [item.item_type for item in agent._context.session_state.items]

        agent._context.add_message(UserMessage(content="trigger"))
        manager = QueueManager()
        manager.enqueue("queued", origin=MessageOrigin.HUMAN)
        bridge = QueueInjectionBridge(trigger_message_id=None, queue_manager=manager)

        inject_queued_messages(
            agent,
            bridge,
            manager.peek_for_injection(),
            call_index=0,
        )

        self.assertEqual(agent._context.export_header_snapshot(), header_before)
        self.assertEqual(
            [item.item_type for item in agent._context.session_state.items],
            session_state_before,
        )
        conversation_items = agent._context.get_conversation_items_snapshot()
        self.assertEqual([item.item_type for item in conversation_items], [ItemType.USER_MESSAGE, ItemType.USER_MESSAGE])
        self.assertFalse(conversation_items[0].message.is_meta)
        self.assertTrue(conversation_items[1].message.is_meta)

    async def test_resume_and_fork_start_with_empty_user_message_queue(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            template = _template()
            session = template.chat(cwd=root)
            await session.send("queued before resume")
            session._ensure_header_persisted()

            resumed = ChatSession.resume(
                template,
                session_id=session.session_id,
                cwd=root,
            )
            forked = session.fork_session()

            self.assertEqual(resumed.peek_queue(), ())
            self.assertEqual(forked.peek_queue(), ())
            self.assertEqual(
                [message.content for message in session.peek_queue()],
                ["queued before resume"],
            )

            await session.close()
            await resumed.close()
            await forked.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
