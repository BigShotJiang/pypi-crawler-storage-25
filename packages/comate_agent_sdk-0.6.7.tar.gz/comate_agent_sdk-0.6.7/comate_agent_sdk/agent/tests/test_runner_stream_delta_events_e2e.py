import unittest
from types import SimpleNamespace

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.events import (
    TextDeltaEvent,
    TextEvent,
    ToolCallEvent,
    ToolCallStartEvent,
)
from comate_agent_sdk.tools import tool


def _chunk(*, delta: SimpleNamespace, finish_reason: str | None = None) -> SimpleNamespace:
    return SimpleNamespace(
        choices=[SimpleNamespace(delta=delta, finish_reason=finish_reason)],
        usage=None,
    )


def _text_chunk(text: str, *, finish_reason: str | None = None) -> SimpleNamespace:
    return _chunk(delta=SimpleNamespace(content=text), finish_reason=finish_reason)


def _tool_chunk(
    *,
    index: int = 0,
    tool_call_id: str | None = None,
    name: str | None = None,
    arguments: str | None = None,
    finish_reason: str | None = None,
) -> SimpleNamespace:
    return _chunk(
        delta=SimpleNamespace(
            tool_calls=[
                SimpleNamespace(
                    index=index,
                    id=tool_call_id,
                    function=SimpleNamespace(name=name, arguments=arguments),
                )
            ]
        ),
        finish_reason=finish_reason,
    )


class _StreamingToolThenTextLLM:
    model = "fake-openai"
    provider = "openai"

    def __init__(self) -> None:
        self.calls = 0

    @property
    def name(self) -> str:
        return self.model

    async def astream(self, messages, tools=None, tool_choice=None, **kwargs):
        del messages, tools, tool_choice, kwargs
        self.calls += 1
        if self.calls == 1:
            yield _tool_chunk(tool_call_id="tc_echo", name="Echo", arguments="")
            yield _tool_chunk(arguments='{"value":"x"}')
            yield _chunk(delta=SimpleNamespace(), finish_reason="tool_calls")
            return
        if self.calls == 2:
            yield _text_chunk("do", finish_reason=None)
            yield _text_chunk("ne", finish_reason="stop")
            return
        raise AssertionError(f"Unexpected astream call #{self.calls}")

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):
        del messages, tools, tool_choice, kwargs
        raise AssertionError("e2e streaming test should use astream")


class TestRunnerStreamDeltaEventsE2E(unittest.IsolatedAsyncioTestCase):
    async def test_stream_chunks_emit_transient_then_durable_events(self) -> None:
        @tool("Echo a value.", name="Echo")
        async def Echo(value: str) -> str:
            return f"echo:{value}"

        template = Agent(
            llm=_StreamingToolThenTextLLM(),  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(Echo,),
                agents=(),
                offload_enabled=False,
                memory_background_enabled=False,
            ),
        )
        agent = template.create_runtime()

        events = [event async for event in agent.query_stream("Hi")]

        tool_start_index = next(
            index for index, event in enumerate(events)
            if isinstance(event, ToolCallStartEvent)
        )
        tool_call_index = next(
            index for index, event in enumerate(events)
            if isinstance(event, ToolCallEvent)
        )
        text_delta_index = next(
            index for index, event in enumerate(events)
            if isinstance(event, TextDeltaEvent)
        )
        text_event_index = next(
            index for index, event in enumerate(events)
            if isinstance(event, TextEvent) and event.content == "done"
        )

        self.assertLess(tool_start_index, tool_call_index)
        self.assertLess(text_delta_index, text_event_index)
        self.assertEqual(
            [event.tool for event in events if isinstance(event, ToolCallStartEvent)],
            ["Echo"],
        )
        self.assertEqual(
            "".join(event.delta for event in events if isinstance(event, TextDeltaEvent)),
            "done",
        )


if __name__ == "__main__":
    unittest.main()
