from __future__ import annotations

from dataclasses import dataclass

MODE_REPRESENTATIVE_TOOLS: dict[str, str | None] = {
    "solo": None,
    "plan": "ExitPlanMode",
    "subagent": "Agent",
    "team": "TeamCreate",
}


@dataclass(frozen=True)
class ModeVisibility:
    solo: bool = True
    plan: bool = False
    subagent: bool = False
    team: bool = False

    @classmethod
    def from_enabled_tools(cls, enabled: frozenset[str]) -> "ModeVisibility":
        return cls(
            solo=True,
            plan=MODE_REPRESENTATIVE_TOOLS["plan"] in enabled,
            subagent=MODE_REPRESENTATIVE_TOOLS["subagent"] in enabled,
            team=MODE_REPRESENTATIVE_TOOLS["team"] in enabled,
        )
