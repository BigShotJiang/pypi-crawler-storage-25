from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from comate_agent_sdk.llm.messages import BaseMessage

logger = logging.getLogger("comate_agent_sdk.agent")

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime


def clear_history(agent: "AgentRuntime") -> None:
    """清空 message history 与 token usage，并重建 ContextIR header。"""
    agent._context.clear()
    agent._token_cost.clear_history()

    from comate_agent_sdk.agent.setup import (
        setup_memory_usage,
        setup_project_context,
        setup_tool_strategy,
        setup_user_instruction,
    )
    from comate_agent_sdk.agent.mode_gating import ModeVisibility
    from comate_agent_sdk.agent.tool_visibility import effective_enabled_tool_names

    effective_enabled = effective_enabled_tool_names(
        agent._runtime_state.tools,
        is_subagent=bool(agent._is_subagent),
        is_team_member=bool(agent.is_team_member),
        disallowed_tools=agent.config.disallowed_tools,
    )
    mode_vis = ModeVisibility.from_enabled_tools(effective_enabled)

    # 重建 IR header 各独立段
    setup_project_context(agent)
    resolved_prompt = agent._resolve_system_prompt(mode_visibility=mode_vis)
    if resolved_prompt:
        agent._context.set_system_prompt(resolved_prompt, cache=True)

    setup_memory_usage(agent)
    setup_tool_strategy(agent)

    # 重建 subagent_strategy（如果有 agents）
    if agent._runtime_state.agents and "Agent" in effective_enabled:
        from comate_agent_sdk.subagent.prompts import generate_subagent_prompt

        agent._context.set_subagent_strategy(generate_subagent_prompt(agent._runtime_state.agents))

    # 重建 skill_strategy（如果有 skills）
    if agent._runtime_state.skills and "Skill" in effective_enabled:
        from comate_agent_sdk.skill.prompts import (
            generate_skill_listing,
            generate_skill_usage_guide,
        )

        agent._context.set_skill_strategy(generate_skill_usage_guide())
        listing = generate_skill_listing(agent._runtime_state.skills)
        if listing:
            agent._context.set_skill_listing(listing)

    is_plan_subagent = bool(getattr(agent, "_is_subagent", False) and agent.name == "Plan")

    # 如果有 user_instruction，重新加载
    if agent._runtime_state.user_instruction and not is_plan_subagent:
        setup_user_instruction(agent)

    # 重建 session_state（env/mcp）
    from comate_agent_sdk.agent.init import (
        _setup_env_info,
        _setup_mcp_session_state,
    )

    _setup_env_info(agent)
    _setup_mcp_session_state(agent)


def load_history(agent: "AgentRuntime", messages: list[BaseMessage]) -> None:
    """加载 message history（保留 header），用于恢复对话。"""
    # 清空现有 conversation（保留 header）
    agent._context.clear_conversation()
    agent._token_cost.clear_history()

    # 逐条加载消息到 IR
    for msg in messages:
        agent._context.add_message(msg)
