from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import TYPE_CHECKING, Any, Mapping

if TYPE_CHECKING:
	from .chat_session import ChatMessage


class MessageOrigin(str, Enum):
	HUMAN = "human"
	EXTERNAL = "external"
	COORDINATOR = "coordinator"
	TASK_NOTIFICATION = "task_notification"


@dataclass(frozen=True)
class QueuedMessage:
	message_id: str
	content: ChatMessage
	origin: MessageOrigin
	enqueued_at: datetime
	origin_metadata: Mapping[str, Any] | None = None
