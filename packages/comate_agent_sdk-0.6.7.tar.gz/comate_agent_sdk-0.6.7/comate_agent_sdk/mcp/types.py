from __future__ import annotations

from typing import (
    Any,
    Literal,
    NotRequired,
    Protocol,
    Required,
    TypedDict,
    TypeAlias,
    runtime_checkable,
)

from comate_agent_sdk.utils.paths import PathInput


class McpSdkServerConfig(TypedDict):
    """Configuration for SDK MCP servers created with create_sdk_mcp_server()."""

    type: Literal["sdk"]
    name: str
    instance: Any  # FastMCP instance


class McpStdioServerConfig(TypedDict):
    """MCP stdio server configuration.

    Notes:
        - type 字段允许缺省（向后兼容），默认按 stdio 处理。
    """

    type: NotRequired[Literal["stdio"]]
    command: str
    args: NotRequired[list[str]]
    env: NotRequired[dict[str, str]]


class McpSSEServerConfig(TypedDict):
    type: Literal["sse"]
    url: str
    headers: NotRequired[dict[str, str]]


class McpOAuthConfig(TypedDict, total=False):
    client_id: Required[str]
    client_secret: str
    issuer: str
    authorization_endpoint: str
    token_endpoint: str
    scope: str
    resource: str
    callback_port: int
    callback_timeout_s: float
    auth_timeout_s: float


class McpHttpServerConfig(TypedDict):
    type: Literal["http", "streamable-http"]
    url: str
    headers: NotRequired[dict[str, str]]
    oauth: NotRequired[McpOAuthConfig]


McpServerConfig: TypeAlias = (
    McpStdioServerConfig | McpSSEServerConfig | McpHttpServerConfig | McpSdkServerConfig
)


McpServersInput: TypeAlias = dict[str, McpServerConfig] | PathInput | None


@runtime_checkable
class SdkMcpTool(Protocol):
    _comate_agent_sdk_mcp_tool_name: str
    _comate_agent_sdk_mcp_tool_description: str

    def __call__(self, *args: Any, **kwargs: Any) -> Any: ...
