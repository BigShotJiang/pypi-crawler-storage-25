"""MCP OAuth 2.1 authorization_code + PKCE support.

OAuth-related failures must not be logged with traceback because upstream HTTP
exceptions may contain sensitive response bodies or callback query parameters.
"""

from __future__ import annotations

import asyncio
import base64
import contextlib
import hashlib
import json
import logging
import os
import re
import sys
import time
import urllib.parse
import webbrowser
from contextlib import AsyncExitStack
from dataclasses import dataclass
from typing import AsyncGenerator

import httpx

from comate_agent_sdk.mcp.token_store import StoredToken, TokenStore
from comate_agent_sdk.mcp.types import McpOAuthConfig

logger = logging.getLogger("comate_agent_sdk.mcp.oauth")

_SENSITIVE_FIELDS = {
    "access_token",
    "refresh_token",
    "client_secret",
    "code",
    "state",
    "code_verifier",
}


class McpOAuthError(Exception):
    """Base class for MCP OAuth errors."""


class NoBrowserError(McpOAuthError):
    pass


class CallbackTimeoutError(McpOAuthError):
    pass


class CallbackStateMismatchError(McpOAuthError):
    pass


class MetadataDiscoveryError(McpOAuthError):
    pass


class AuthorizationError(McpOAuthError):
    pass


class TokenExchangeError(McpOAuthError):
    pass


class RefreshFailedError(McpOAuthError):
    pass


class TokenStorageError(McpOAuthError):
    pass


@dataclass(frozen=True)
class OAuthMetadata:
    authorization_endpoint: str
    token_endpoint: str


def _generate_pkce() -> tuple[str, str]:
    verifier = base64.urlsafe_b64encode(os.urandom(32)).rstrip(b"=").decode("ascii")
    challenge = base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode("ascii")).digest()
    ).rstrip(b"=").decode("ascii")
    return verifier, challenge


def _generate_state() -> str:
    return base64.urlsafe_b64encode(os.urandom(16)).rstrip(b"=").decode("ascii")


def _is_headless() -> bool:
    if os.environ.get("CI"):
        return True
    if sys.platform.startswith("linux"):
        return not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))
    if sys.platform == "darwin":
        return bool(os.environ.get("SSH_CONNECTION"))
    return False


def _redact_value(value: str) -> str:
    redacted = value
    for key in _SENSITIVE_FIELDS:
        redacted = re.sub(
            rf"([\"']?{key}[\"']?\s*[:=]\s*[\"']?)[^\"'\s,}}&]+",
            rf"\1***",
            redacted,
            flags=re.IGNORECASE,
        )
    redacted = re.sub(r"(Bearer\s+)[^\s]+", r"\1***", redacted, flags=re.IGNORECASE)
    return redacted


def _redact_url(url: str) -> str:
    try:
        parsed = urllib.parse.urlparse(url)
        params = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
        redacted = [
            (key, "***" if key.lower() in _SENSITIVE_FIELDS else value)
            for key, value in params
        ]
        return urllib.parse.urlunparse(
            parsed._replace(query=urllib.parse.urlencode(redacted))
        )
    except Exception:
        return _redact_value(url)


def _debug_log_exception_redacted(exc: Exception) -> None:
    logger.debug(
        "oauth exception (redacted): %s: %s",
        type(exc).__name__,
        _redact_value(_redact_url(str(exc))),
    )


async def discover_metadata(
    issuer: str,
    *,
    http_client: httpx.AsyncClient,
    timeout_s: float = 10.0,
) -> OAuthMetadata:
    issuer = issuer.rstrip("/")
    candidates = (
        "/.well-known/oauth-authorization-server",
        "/.well-known/openid-configuration",
    )
    for suffix in candidates:
        url = f"{issuer}{suffix}"
        try:
            response = await http_client.get(url, timeout=timeout_s)
        except httpx.HTTPError as exc:
            _debug_log_exception_redacted(exc)
            continue
        if response.status_code == 404:
            continue
        if response.status_code != 200:
            continue
        try:
            data = response.json()
            return OAuthMetadata(
                authorization_endpoint=data["authorization_endpoint"],
                token_endpoint=data["token_endpoint"],
            )
        except (json.JSONDecodeError, KeyError, TypeError) as exc:
            _debug_log_exception_redacted(exc)
            continue
    raise MetadataDiscoveryError(
        f"metadata discovery failed for issuer={issuer}"
    )


class OAuthAuth(httpx.Auth):
    requires_response_body = False

    def __init__(
        self,
        *,
        alias: str,
        metadata: OAuthMetadata,
        client_id: str,
        client_secret: str | None,
        scope: str | None,
        token: StoredToken,
        token_store: TokenStore,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._alias = alias
        self._metadata = metadata
        self._client_id = client_id
        self._client_secret = client_secret
        self._scope = scope
        self._token = token
        self._token_store = token_store
        self._refresh_http = http_client
        self._lock = asyncio.Lock()

    def sync_auth_flow(self, request: httpx.Request):  # type: ignore[override]
        del request
        raise RuntimeError("OAuthAuth only supports async_auth_flow")

    async def async_auth_flow(
        self,
        request: httpx.Request,
    ) -> AsyncGenerator[httpx.Request, None]:
        token = await self._ensure_fresh()
        request.headers["Authorization"] = f"{token.token_type} {token.access_token}"
        response = yield request
        if response.status_code == 401:
            token = await self._force_refresh_no_interactive(
                rejected_access_token=token.access_token
            )
            request.headers["Authorization"] = (
                f"{token.token_type} {token.access_token}"
            )
            yield request

    async def _persist_token(
        self,
        new_token: StoredToken,
        *,
        previous_token: StoredToken,
    ) -> StoredToken:
        self._token = new_token
        try:
            self._token_store.save(self._alias, new_token)
        except Exception as exc:
            self._token = previous_token
            raise TokenStorageError(
                f"failed to persist token: {type(exc).__name__}"
            ) from exc
        return new_token

    async def _ensure_fresh(self) -> StoredToken:
        async with self._lock:
            now = time.time()
            token = self._token
            if token.expires_at - now >= 60:
                return token
            if token.refresh_token is None:
                raise RefreshFailedError("no refresh_token available")
            new_token = await self._refresh(token.refresh_token)
            self._token = new_token
            return new_token

    async def _force_refresh_no_interactive(
        self,
        *,
        rejected_access_token: str,
    ) -> StoredToken:
        async with self._lock:
            token = self._token
            if token.access_token != rejected_access_token and token.expires_at - time.time() >= 60:
                return token
            if token.refresh_token is None:
                raise RefreshFailedError("no refresh_token available")
            new_token = await self._refresh(token.refresh_token)
            self._token = new_token
            return new_token

    async def _refresh(self, refresh_token: str) -> StoredToken:
        payload: dict[str, str] = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": self._client_id,
        }
        if self._scope:
            payload["scope"] = self._scope

        auth: tuple[str, str] | None = None
        if self._client_secret:
            auth = (self._client_id, self._client_secret)

        owns_client = self._refresh_http is None
        client = self._refresh_http or httpx.AsyncClient(timeout=10.0)
        try:
            response = await client.post(
                self._metadata.token_endpoint,
                data=payload,
                auth=auth,
                timeout=10.0,
            )
        finally:
            if owns_client:
                await client.aclose()

        if response.status_code != 200:
            message = f"token endpoint returned {response.status_code}"
            with contextlib.suppress(Exception):
                error_body = response.json()
                error_name = str(error_body.get("error", "")).strip()
                if error_name:
                    message = error_name
            raise RefreshFailedError(message)

        body = response.json()
        new_token = StoredToken(
            access_token=body["access_token"],
            refresh_token=body.get("refresh_token", refresh_token),
            token_type=body.get("token_type", "Bearer"),
            expires_at=time.time() + float(body.get("expires_in", 3600)) - 30.0,
            scope=body.get("scope"),
        )
        return await self._persist_token(new_token, previous_token=self._token)


async def _run_callback_server(
    *,
    expected_state: str,
    stack: AsyncExitStack,
    port: int,
) -> tuple[int, asyncio.Future[str]]:
    code_future: asyncio.Future[str] = asyncio.get_running_loop().create_future()

    async def _handle(
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        try:
            request_line = await reader.readline()
            while True:
                line = await reader.readline()
                if line in (b"", b"\r\n", b"\n"):
                    break

            parts = request_line.decode(errors="replace").split()
            if len(parts) < 2 or parts[0] != "GET":
                writer.write(b"HTTP/1.0 404 Not Found\r\n\r\n")
                await writer.drain()
                return

            parsed = urllib.parse.urlparse(parts[1])
            if parsed.path != "/callback":
                writer.write(b"HTTP/1.0 404 Not Found\r\n\r\n")
                await writer.drain()
                return

            params = dict(urllib.parse.parse_qsl(parsed.query, keep_blank_values=True))
            if params.get("state") != expected_state:
                writer.write(
                    b"HTTP/1.0 400 Bad Request\r\n"
                    b"Content-Type: text/plain\r\n\r\n"
                    b"state mismatch"
                )
                await writer.drain()
                if not code_future.done():
                    code_future.set_exception(
                        CallbackStateMismatchError("callback state mismatch")
                    )
                return

            error = params.get("error", "").strip()
            if error:
                description = params.get("error_description", "").strip()
                writer.write(
                    b"HTTP/1.0 400 Bad Request\r\n"
                    b"Content-Type: text/plain\r\n\r\n"
                    b"authorization denied"
                )
                await writer.drain()
                if not code_future.done():
                    message = error if not description else f"{error}: {description}"
                    code_future.set_exception(AuthorizationError(message))
                return

            code = params.get("code", "")
            writer.write(
                b"HTTP/1.0 200 OK\r\n"
                b"Content-Type: text/plain\r\n\r\n"
                b"You may close this tab."
            )
            await writer.drain()
            if not code_future.done():
                code_future.set_result(code)
        finally:
            writer.close()
            with contextlib.suppress(Exception):
                await writer.wait_closed()

    server = await asyncio.start_server(_handle, "127.0.0.1", port)
    stack.push_async_callback(server.wait_closed)
    stack.callback(server.close)
    actual_port = server.sockets[0].getsockname()[1]
    return actual_port, code_future


async def _exchange_code_for_token(
    *,
    http_client: httpx.AsyncClient,
    token_endpoint: str,
    code: str,
    redirect_uri: str,
    code_verifier: str,
    client_id: str,
    client_secret: str | None,
) -> StoredToken:
    payload = {
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": redirect_uri,
        "code_verifier": code_verifier,
        "client_id": client_id,
    }
    auth: tuple[str, str] | None = None
    if client_secret:
        auth = (client_id, client_secret)

    response = await http_client.post(
        token_endpoint,
        data=payload,
        auth=auth,
        timeout=10.0,
    )
    if response.status_code != 200:
        raise TokenExchangeError(f"token endpoint returned {response.status_code}")
    body = response.json()
    return StoredToken(
        access_token=body["access_token"],
        refresh_token=body.get("refresh_token"),
        token_type=body.get("token_type", "Bearer"),
        expires_at=time.time() + float(body.get("expires_in", 3600)) - 30.0,
        scope=body.get("scope"),
    )


async def _resolve_metadata(
    cfg: McpOAuthConfig,
    *,
    http_client: httpx.AsyncClient,
) -> OAuthMetadata:
    authorization_endpoint = cfg.get("authorization_endpoint")
    token_endpoint = cfg.get("token_endpoint")
    if authorization_endpoint and token_endpoint:
        return OAuthMetadata(
            authorization_endpoint=authorization_endpoint,
            token_endpoint=token_endpoint,
        )
    issuer = cfg.get("issuer")
    if not issuer:
        raise MetadataDiscoveryError(
            "oauth config missing issuer and explicit endpoints"
        )
    return await discover_metadata(issuer, http_client=http_client)


async def _authorization_code_flow(
    *,
    alias: str,
    cfg: McpOAuthConfig,
    metadata: OAuthMetadata,
    token_store: TokenStore,
    http_client: httpx.AsyncClient,
) -> StoredToken:
    if _is_headless():
        raise NoBrowserError("OAuth requires a browser in a non-headless environment")

    async with AsyncExitStack() as stack:
        verifier, challenge = _generate_pkce()
        state = _generate_state()
        requested_port = int(cfg.get("callback_port", 0) or 0)
        actual_port, code_future = await _run_callback_server(
            expected_state=state,
            stack=stack,
            port=requested_port,
        )
        redirect_uri = f"http://127.0.0.1:{actual_port}/callback"
        params = {
            "response_type": "code",
            "client_id": cfg["client_id"],
            "redirect_uri": redirect_uri,
            "state": state,
            "code_challenge": challenge,
            "code_challenge_method": "S256",
        }
        scope = cfg.get("scope")
        if scope:
            params["scope"] = scope
        resource = cfg.get("resource")
        if resource:
            params["resource"] = resource

        authorization_url = (
            metadata.authorization_endpoint
            + "?"
            + urllib.parse.urlencode(params)
        )
        try:
            opened = webbrowser.open(authorization_url)
        except Exception as exc:
            opened = False
            _debug_log_exception_redacted(exc)
        if not opened:
            logger.warning("OAuth browser launch failed; waiting for manual callback")

        callback_timeout_s = float(cfg.get("callback_timeout_s", 180.0))
        try:
            code = await asyncio.wait_for(code_future, timeout=callback_timeout_s)
        except asyncio.TimeoutError as exc:
            raise CallbackTimeoutError(
                f"oauth callback timed out after {callback_timeout_s}s"
            ) from exc

        token = await _exchange_code_for_token(
            http_client=http_client,
            token_endpoint=metadata.token_endpoint,
            code=code,
            redirect_uri=redirect_uri,
            code_verifier=verifier,
            client_id=cfg["client_id"],
            client_secret=cfg.get("client_secret"),
        )

    try:
        token_store.save(alias, token)
    except Exception as exc:
        raise TokenStorageError(
            f"failed to persist new token: {type(exc).__name__}"
        ) from exc
    return token


async def build_auth(
    alias: str,
    cfg: McpOAuthConfig,
    *,
    token_store: TokenStore,
    auth_timeout_s: float | None = None,
    http_client_for_refresh: httpx.AsyncClient | None = None,
) -> OAuthAuth:
    timeout = float(
        auth_timeout_s if auth_timeout_s is not None else cfg.get("auth_timeout_s", 300.0)
    )
    return await asyncio.wait_for(
        _build_auth_impl(
            alias,
            cfg,
            token_store=token_store,
            http_client_for_refresh=http_client_for_refresh,
        ),
        timeout=timeout,
    )


async def _build_auth_impl(
    alias: str,
    cfg: McpOAuthConfig,
    *,
    token_store: TokenStore,
    http_client_for_refresh: httpx.AsyncClient | None,
) -> OAuthAuth:
    owns_client = http_client_for_refresh is None
    client = http_client_for_refresh or httpx.AsyncClient(timeout=10.0)
    try:
        metadata = await _resolve_metadata(cfg, http_client=client)

        token = token_store.load(alias)
        if token is not None and token.expires_at - time.time() >= 60:
            return OAuthAuth(
                alias=alias,
                metadata=metadata,
                client_id=cfg["client_id"],
                client_secret=cfg.get("client_secret"),
                scope=cfg.get("scope"),
                token=token,
                token_store=token_store,
                http_client=http_client_for_refresh,
            )

        if token is not None and token.refresh_token:
            auth = OAuthAuth(
                alias=alias,
                metadata=metadata,
                client_id=cfg["client_id"],
                client_secret=cfg.get("client_secret"),
                scope=cfg.get("scope"),
                token=token,
                token_store=token_store,
                http_client=http_client_for_refresh,
            )
            try:
                refreshed = await auth._refresh(token.refresh_token)
                auth._token = refreshed
                return auth
            except RefreshFailedError:
                token_store.delete(alias)

        token = await _authorization_code_flow(
            alias=alias,
            cfg=cfg,
            metadata=metadata,
            token_store=token_store,
            http_client=client,
        )
        return OAuthAuth(
            alias=alias,
            metadata=metadata,
            client_id=cfg["client_id"],
            client_secret=cfg.get("client_secret"),
            scope=cfg.get("scope"),
            token=token,
            token_store=token_store,
            http_client=http_client_for_refresh,
        )
    finally:
        if owns_client:
            await client.aclose()
