"""MCP OAuth token local persistence.

Token files are plain JSON on disk. File permissions are the only protection layer.
Callers must serialize concurrent access; this module intentionally stays I/O-only.
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path

from comate_agent_sdk.mcp.utils import sanitize_tool_name

logger = logging.getLogger("comate_agent_sdk.mcp.token_store")


@dataclass(frozen=True)
class StoredToken:
    access_token: str
    refresh_token: str | None
    token_type: str
    expires_at: float
    scope: str | None


class TokenStore:
    def __init__(self, base_dir: Path | None = None) -> None:
        self._base_dir = base_dir or (Path.home() / ".agent" / "mcp_tokens")
        try:
            self._base_dir.mkdir(parents=True, exist_ok=True)
            try:
                os.chmod(self._base_dir, 0o700)
            except OSError as exc:
                logger.warning(f"chmod 0700 on {self._base_dir} failed: {exc}")
        except OSError as exc:
            logger.warning(f"mkdir {self._base_dir} failed: {exc}")

    def _target(self, alias: str) -> Path:
        return self._base_dir / f"{sanitize_tool_name(alias)}.json"

    def load(self, alias: str) -> StoredToken | None:
        target = self._target(alias)
        if not target.exists():
            return None

        try:
            data = json.loads(target.read_text(encoding="utf-8"))
            return StoredToken(
                access_token=data["access_token"],
                refresh_token=data.get("refresh_token"),
                token_type=data["token_type"],
                expires_at=float(data["expires_at"]),
                scope=data.get("scope"),
            )
        except (json.JSONDecodeError, KeyError, ValueError, OSError) as exc:
            logger.warning(f"token file '{target}' corrupt or unreadable: {type(exc).__name__}")
            return None

    def save(self, alias: str, token: StoredToken) -> None:
        target = self._target(alias)
        fd, tmp_name = tempfile.mkstemp(
            dir=str(self._base_dir),
            prefix=".tmp_",
            suffix=".json",
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(asdict(token), handle, ensure_ascii=False)
            try:
                os.chmod(tmp_name, 0o600)
            except OSError as exc:
                logger.warning(f"chmod 0600 on {tmp_name} failed: {exc}")
            os.replace(tmp_name, target)
        finally:
            tmp_path = Path(tmp_name)
            if tmp_path.exists():
                try:
                    tmp_path.unlink()
                except OSError:
                    pass

    def delete(self, alias: str) -> None:
        self._target(alias).unlink(missing_ok=True)
