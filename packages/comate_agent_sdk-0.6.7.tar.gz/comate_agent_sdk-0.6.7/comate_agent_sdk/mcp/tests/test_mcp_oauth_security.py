from __future__ import annotations

import asyncio
import logging
import re
import sys
import webbrowser
from pathlib import Path

import httpx
import pytest

from comate_agent_sdk.mcp.oauth import (
    AuthorizationError,
    CallbackStateMismatchError,
    _redact_url,
)


def test_redact_url_strips_code_and_state() -> None:
    url = "http://127.0.0.1:8080/callback?code=secretCODE&state=csrfXYZ&foo=bar"
    redacted = _redact_url(url)
    assert "secretCODE" not in redacted
    assert "csrfXYZ" not in redacted
    assert "foo=bar" in redacted


def test_redact_url_strips_access_and_refresh_tokens() -> None:
    url = "https://i.test/x?access_token=AT123&refresh_token=RT456"
    redacted = _redact_url(url)
    assert "AT123" not in redacted
    assert "RT456" not in redacted


@pytest.mark.skipif(sys.platform == "win32", reason="POSIX perms")
def test_token_file_is_not_world_readable(tmp_path: Path) -> None:
    import os
    import stat

    from comate_agent_sdk.mcp.token_store import StoredToken, TokenStore

    store = TokenStore(base_dir=tmp_path)
    store.save("notion", StoredToken("at", None, "Bearer", 0.0, None))
    target = tmp_path / "notion.json"
    mode = stat.S_IMODE(os.stat(target).st_mode)
    assert (mode & 0o077) == 0


def test_state_mismatch_rejects_callback(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from comate_agent_sdk.mcp.oauth import build_auth
    from comate_agent_sdk.mcp.token_store import TokenStore

    if sys.platform.startswith("linux"):
        monkeypatch.setenv("DISPLAY", ":0")
    monkeypatch.delenv("CI", raising=False)

    def _fake_open(url: str) -> bool:
        async def _fire() -> None:
            await asyncio.sleep(0.02)
            parsed = httpx.URL(url)
            redirect = parsed.params["redirect_uri"]
            async with httpx.AsyncClient() as client:
                response = await client.get(f"{redirect}?code=abc&state=WRONG")
                assert response.status_code == 400
                assert "state mismatch" in response.text

        asyncio.create_task(_fire())
        return True

    monkeypatch.setattr(webbrowser, "open", _fake_open)
    store = TokenStore(base_dir=tmp_path)

    async def _run() -> None:
        with pytest.raises(CallbackStateMismatchError):
            await build_auth(
                "notion",
                {
                    "client_id": "cid",
                    "authorization_endpoint": "https://i.test/auth",
                    "token_endpoint": "https://i.test/token",
                    "callback_timeout_s": 2.0,
                },
                token_store=store,
                auth_timeout_s=5.0,
            )

    asyncio.run(_run())


def test_authorization_error_rejects_callback_without_leaking_idp_text(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from comate_agent_sdk.mcp.manager import McpManager
    from comate_agent_sdk.mcp.oauth import build_auth
    from comate_agent_sdk.mcp.token_store import TokenStore

    if sys.platform.startswith("linux"):
        monkeypatch.setenv("DISPLAY", ":0")
    monkeypatch.delenv("CI", raising=False)

    def _fake_open(url: str) -> bool:
        async def _fire() -> None:
            await asyncio.sleep(0.02)
            parsed = httpx.URL(url)
            redirect = parsed.params["redirect_uri"]
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{redirect}?error=access_denied"
                    f"&error_description=User+denied+consent"
                    f"&state={parsed.params['state']}"
                )
                assert response.status_code == 400
                assert "authorization denied" in response.text.lower()

        asyncio.create_task(_fire())
        return True

    monkeypatch.setattr(webbrowser, "open", _fake_open)
    store = TokenStore(base_dir=tmp_path)

    async def _run() -> None:
        with pytest.raises(AuthorizationError) as exc_info:
            await build_auth(
                "notion",
                {
                    "client_id": "cid",
                    "authorization_endpoint": "https://i.test/auth",
                    "token_endpoint": "https://i.test/token",
                    "callback_timeout_s": 2.0,
                },
                token_store=store,
                auth_timeout_s=5.0,
            )
        assert "User denied consent" in str(exc_info.value)

    asyncio.run(_run())

    manager = McpManager({})
    cfg = {"type": "http", "url": "https://x.test/"}
    result = manager._friendly_error_message(
        "alias",
        cfg,
        AuthorizationError("access_denied: User denied consent"),
    )  # type: ignore[arg-type]
    assert result == "OAuth authorization denied by server"
    assert "User denied consent" not in result


def test_friendly_error_message_does_not_leak_access_token() -> None:
    from comate_agent_sdk.mcp.manager import McpManager
    from comate_agent_sdk.mcp.oauth import TokenExchangeError

    leaky_exc = TokenExchangeError(
        "status=400 body={'error': 'bad', 'access_token': 'LEAKED_AT_123456'}"
    )
    manager = McpManager({})
    cfg = {"type": "http", "url": "https://x.test/"}
    result = manager._friendly_error_message("alias", cfg, leaky_exc)  # type: ignore[arg-type]
    assert "LEAKED_AT_123456" not in result


def test_oauth_logs_do_not_contain_sensitive_fields(
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    from comate_agent_sdk.mcp.oauth import build_auth
    from comate_agent_sdk.mcp.token_store import StoredToken, TokenStore

    caplog.set_level(logging.DEBUG)
    store = TokenStore(base_dir=tmp_path)
    store.save(
        "notion",
        StoredToken(
            "AT-SECRET-ABCXYZ",
            "RT-SECRET-123",
            "Bearer",
            99_999_999_999.0,
            None,
        ),
    )

    async def _run() -> None:
        await build_auth(
            "notion",
            {
                "client_id": "cid",
                "authorization_endpoint": "https://i.test/auth",
                "token_endpoint": "https://i.test/token",
            },
            token_store=store,
        )

    asyncio.run(_run())

    full_log = "\n".join(record.getMessage() for record in caplog.records)
    assert "AT-SECRET-ABCXYZ" not in full_log
    assert "RT-SECRET-123" not in full_log
    assert not re.search(r"\baccess_token\s*[:=]\s*[^\s\*]", full_log)
