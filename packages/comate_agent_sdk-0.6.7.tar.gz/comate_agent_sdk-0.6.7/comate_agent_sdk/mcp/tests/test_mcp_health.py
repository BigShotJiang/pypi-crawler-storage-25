from __future__ import annotations

import asyncio

from comate_agent_sdk.mcp import create_sdk_mcp_server, mcp_tool
from comate_agent_sdk.mcp.health import collect_mcp_server_health
from comate_agent_sdk.mcp import manager as manager_module
from comate_agent_sdk.mcp.manager import McpManager


def _build_calc_server():
    @mcp_tool(name="add", description="Add two numbers")
    async def add(a: float, b: float) -> str:
        return f"sum={a + b}"

    return create_sdk_mcp_server(name="calculator", tools=[add])


def test_collect_mcp_server_health_marks_connected_server() -> None:
    async def _run() -> None:
        servers = {"calc": _build_calc_server()}
        rows = await collect_mcp_server_health(servers=servers)
        assert len(rows) == 1
        assert rows[0].alias == "calc"
        assert rows[0].connected is True
        assert rows[0].reason is None
        assert rows[0].tool_count >= 1

    asyncio.run(_run())


def test_collect_mcp_server_health_marks_failed_server() -> None:
    async def _run() -> None:
        servers = {"bad-http": {"type": "http", "url": ""}}
        rows = await collect_mcp_server_health(servers=servers)  # type: ignore[arg-type]
        assert len(rows) == 1
        assert rows[0].alias == "bad-http"
        assert rows[0].connected is False
        assert rows[0].reason

    asyncio.run(_run())


def test_collect_mcp_server_health_waits_for_final_failure(
    monkeypatch,
) -> None:
    monkeypatch.setattr(manager_module, "_START_TIMEOUT_S", 0.05)

    async def _fake_open(self: McpManager, alias: str, cfg: dict[str, str]) -> None:
        del alias, cfg
        await asyncio.sleep(0.2)
        raise ConnectionRefusedError("boom")

    async def _run() -> None:
        monkeypatch.setattr(McpManager, "_open_connection", _fake_open)
        rows = await collect_mcp_server_health(
            servers={"bad": {"type": "http", "url": "http://bad.test"}},
            connect_timeout_s=0.3,
        )  # type: ignore[arg-type]
        assert len(rows) == 1
        assert rows[0].alias == "bad"
        assert rows[0].connected is False
        assert rows[0].status == "failed"
        assert rows[0].reason

    asyncio.run(_run())


def test_collect_mcp_server_health_stdio_uses_local_timeout_default(monkeypatch) -> None:
    captured: dict[str, float] = {}

    original_init = McpManager.__init__

    def _wrapped_init(self, servers, *, connect_timeout_s=None, call_timeout_s=60.0, token_store=None):  # type: ignore[no-untyped-def]
        captured["connect_timeout_s"] = connect_timeout_s
        return original_init(
            self,
            servers,
            connect_timeout_s=connect_timeout_s,
            call_timeout_s=call_timeout_s,
            token_store=token_store,
        )

    async def _run() -> None:
        monkeypatch.setattr(McpManager, "__init__", _wrapped_init)
        rows = await collect_mcp_server_health(servers={"calc": _build_calc_server()})
        assert rows[0].connected is True

    asyncio.run(_run())
    assert captured["connect_timeout_s"] is None


def test_collect_mcp_server_health_fails_when_open_connection_hangs(monkeypatch) -> None:
    async def _hang_open(self: McpManager, alias: str, cfg: dict[str, str]) -> None:
        del alias, cfg
        await asyncio.sleep(10)
        raise AssertionError("unreachable")

    async def _run() -> None:
        monkeypatch.setattr(McpManager, "_open_connection", _hang_open)
        started = asyncio.get_running_loop().time()
        rows = await collect_mcp_server_health(
            servers={"bad": {"type": "http", "url": "http://bad.test"}},
            connect_timeout_s=0.1,
        )  # type: ignore[arg-type]
        elapsed = asyncio.get_running_loop().time() - started
        assert rows[0].status == "failed"
        assert rows[0].connected is False
        assert elapsed < 1.0

    asyncio.run(_run())
