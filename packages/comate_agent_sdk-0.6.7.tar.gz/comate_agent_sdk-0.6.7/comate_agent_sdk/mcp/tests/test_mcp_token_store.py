from __future__ import annotations

import os
import stat
import sys
from pathlib import Path

import pytest

from comate_agent_sdk.mcp.token_store import StoredToken, TokenStore


def _sample_token(expires_at: float = 1_700_000_000.0) -> StoredToken:
    return StoredToken(
        access_token="at-abc",
        refresh_token="rt-xyz",
        token_type="Bearer",
        expires_at=expires_at,
        scope="mcp:read",
    )


def test_save_then_load_roundtrip(tmp_path: Path) -> None:
    store = TokenStore(base_dir=tmp_path)
    token = _sample_token()

    store.save("notion", token)

    loaded = store.load("notion")
    assert loaded == token


def test_load_missing_file_returns_none(tmp_path: Path) -> None:
    store = TokenStore(base_dir=tmp_path)
    assert store.load("unknown") is None


def test_load_corrupted_json_returns_none_and_logs_warning(
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    import logging

    store = TokenStore(base_dir=tmp_path)
    store.save("notion", _sample_token())
    (tmp_path / "notion.json").write_text("{not json", encoding="utf-8")

    caplog.set_level(logging.WARNING, logger="comate_agent_sdk.mcp.token_store")
    assert store.load("notion") is None
    assert "corrupt" in caplog.text.lower() or "parse" in caplog.text.lower()


@pytest.mark.skipif(sys.platform == "win32", reason="POSIX permission bits only")
def test_save_creates_dir_with_0700(tmp_path: Path) -> None:
    base = tmp_path / "mcp_tokens"
    store = TokenStore(base_dir=base)

    store.save("notion", _sample_token())

    mode = stat.S_IMODE(os.stat(base).st_mode)
    assert (mode & 0o077) == 0


@pytest.mark.skipif(sys.platform == "win32", reason="POSIX permission bits only")
def test_save_writes_file_with_0600(tmp_path: Path) -> None:
    store = TokenStore(base_dir=tmp_path)

    store.save("notion", _sample_token())

    target = tmp_path / "notion.json"
    mode = stat.S_IMODE(os.stat(target).st_mode)
    assert (mode & 0o077) == 0
    assert (mode & 0o600) == 0o600


def test_save_is_atomic_on_crash(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    store = TokenStore(base_dir=tmp_path)
    old_token = _sample_token(expires_at=100.0)
    new_token = _sample_token(expires_at=200.0)
    store.save("notion", old_token)

    real_replace = os.replace

    def _boom(src: str, dst: str) -> None:
        del src, dst
        raise OSError("simulated crash mid-replace")

    monkeypatch.setattr(os, "replace", _boom)
    with pytest.raises(OSError, match="simulated crash"):
        store.save("notion", new_token)
    monkeypatch.setattr(os, "replace", real_replace)

    loaded = store.load("notion")
    assert loaded is not None
    assert loaded.expires_at == 100.0


def test_save_sanitizes_alias_preventing_path_traversal(tmp_path: Path) -> None:
    store = TokenStore(base_dir=tmp_path)

    store.save("../../evil", _sample_token())

    assert not (tmp_path.parent / "evil.json").exists()
    files = list(tmp_path.glob("*.json"))
    assert len(files) == 1


def test_delete_missing_ok(tmp_path: Path) -> None:
    store = TokenStore(base_dir=tmp_path)
    store.delete("nope")
