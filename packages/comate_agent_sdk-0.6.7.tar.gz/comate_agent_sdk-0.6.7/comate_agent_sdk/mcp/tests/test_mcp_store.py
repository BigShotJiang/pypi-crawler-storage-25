from __future__ import annotations

import json
from pathlib import Path

import pytest

from comate_agent_sdk.mcp.store import (
    McpConfigError,
    load_effective_servers,
    load_mcp_servers_from_path,
    write_mcp_servers_to_path,
)
from comate_agent_sdk.utils.paths import PathInputError


def test_load_mcp_servers_from_path_returns_empty_when_file_missing(tmp_path: Path) -> None:
    path = tmp_path / ".agent" / ".mcp.json"
    assert load_mcp_servers_from_path(path) == {}


def test_load_mcp_servers_requires_mcpservers_top_level(tmp_path: Path) -> None:
    path = tmp_path / ".agent" / ".mcp.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"servers": {"a": {"command": "npx"}}}), encoding="utf-8")

    with pytest.raises(McpConfigError, match="旧格式 'servers'"):
        load_mcp_servers_from_path(path)


def test_load_mcp_servers_rejects_missing_top_level(tmp_path: Path) -> None:
    path = tmp_path / ".agent" / ".mcp.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"foo": "bar"}), encoding="utf-8")

    with pytest.raises(McpConfigError, match="缺少 'mcpServers'"):
        load_mcp_servers_from_path(path)


def test_load_effective_servers_project_overrides_user(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    home = tmp_path / "home"
    project_root = tmp_path / "project"
    user_file = home / ".agent" / ".mcp.json"
    project_file = project_root / ".agent" / ".mcp.json"
    user_file.parent.mkdir(parents=True, exist_ok=True)
    project_file.parent.mkdir(parents=True, exist_ok=True)

    user_file.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "github": {"type": "http", "url": "https://user.example.com/mcp"},
                    "user-only": {"command": "npx", "args": ["-y", "user-mcp"]},
                }
            }
        ),
        encoding="utf-8",
    )
    project_file.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "github": {"type": "http", "url": "https://project.example.com/mcp"},
                    "project-only": {"command": "npx", "args": ["-y", "project-mcp"]},
                }
            }
        ),
        encoding="utf-8",
    )

    monkeypatch.setattr(Path, "home", lambda: home)
    merged = load_effective_servers(project_root=project_root)

    assert merged["github"]["url"] == "https://project.example.com/mcp"  # type: ignore[index]
    assert "user-only" in merged
    assert "project-only" in merged


def test_load_effective_servers_accepts_str_project_root(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    project_root = tmp_path / "project"
    user_file = home / ".agent" / ".mcp.json"
    project_file = project_root / ".agent" / ".mcp.json"
    user_file.parent.mkdir(parents=True, exist_ok=True)
    project_file.parent.mkdir(parents=True, exist_ok=True)

    user_file.write_text(
        json.dumps({"mcpServers": {"user-only": {"command": "npx", "args": ["-y", "user-mcp"]}}}),
        encoding="utf-8",
    )
    project_file.write_text(
        json.dumps({"mcpServers": {"project-only": {"command": "npx", "args": ["-y", "project-mcp"]}}}),
        encoding="utf-8",
    )

    monkeypatch.setattr(Path, "home", lambda: home)
    merged = load_effective_servers(project_root=str(project_root))

    assert "user-only" in merged
    assert "project-only" in merged


def test_write_mcp_servers_to_path_round_trip(tmp_path: Path) -> None:
    path = tmp_path / ".agent" / ".mcp.json"
    servers = {
        "context7": {
            "type": "http",
            "url": "https://mcp.context7.com/mcp",
            "headers": {"CONTEXT7_API_KEY": "ctx7-test"},
        }
    }
    write_mcp_servers_to_path(path=path, servers=servers)

    raw = json.loads(path.read_text(encoding="utf-8"))
    assert sorted(raw.keys()) == ["mcpServers"]
    assert raw["mcpServers"]["context7"]["url"] == "https://mcp.context7.com/mcp"

    loaded = load_mcp_servers_from_path(path)
    assert loaded["context7"]["url"] == "https://mcp.context7.com/mcp"  # type: ignore[index]


def test_load_effective_servers_rejects_invalid_project_root_type() -> None:
    with pytest.raises(PathInputError, match="invalid project_root type"):
        load_effective_servers(project_root=123)  # type: ignore[arg-type]


def test_type_streamable_http_accepted_as_alias(tmp_path: Path) -> None:
    path = tmp_path / ".agent" / ".mcp.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "notion": {
                        "type": "streamable-http",
                        "url": "https://mcp.notion.so/mcp",
                    }
                }
            }
        ),
        encoding="utf-8",
    )

    loaded = load_mcp_servers_from_path(path)
    assert loaded["notion"]["type"] == "http"  # type: ignore[index]


def test_type_http_still_accepted(tmp_path: Path) -> None:
    path = tmp_path / ".agent" / ".mcp.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "srv": {"type": "http", "url": "https://x.test/mcp"}
                }
            }
        ),
        encoding="utf-8",
    )

    loaded = load_mcp_servers_from_path(path)
    assert loaded["srv"]["type"] == "http"  # type: ignore[index]


def test_type_is_normalized_to_http_on_load(tmp_path: Path) -> None:
    path = tmp_path / ".agent" / ".mcp.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "srv": {
                        "type": "streamable-http",
                        "url": "https://x.test/mcp",
                    }
                }
            }
        ),
        encoding="utf-8",
    )

    loaded = load_mcp_servers_from_path(path)
    write_mcp_servers_to_path(path=path, servers=loaded)
    raw = json.loads(path.read_text(encoding="utf-8"))
    assert raw["mcpServers"]["srv"]["type"] == "http"


def test_type_unknown_still_rejected(tmp_path: Path) -> None:
    path = tmp_path / ".agent" / ".mcp.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps({"mcpServers": {"srv": {"type": "grpc", "url": "x"}}}),
        encoding="utf-8",
    )

    with pytest.raises(McpConfigError, match="type 非法"):
        load_mcp_servers_from_path(path)


def test_type_is_case_insensitive(tmp_path: Path) -> None:
    path = tmp_path / ".agent" / ".mcp.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "srv": {"type": "HTTP", "url": "https://x.test/"}
                }
            }
        ),
        encoding="utf-8",
    )

    loaded = load_mcp_servers_from_path(path)
    assert loaded["srv"]["type"] == "http"  # type: ignore[index]


def test_oauth_requires_client_id(tmp_path: Path) -> None:
    path = tmp_path / ".agent" / ".mcp.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "srv": {
                        "type": "http",
                        "url": "https://x.test/mcp",
                        "oauth": {"issuer": "https://x.test/"},
                    }
                }
            }
        ),
        encoding="utf-8",
    )

    with pytest.raises(McpConfigError, match="client_id"):
        load_mcp_servers_from_path(path)


def test_oauth_requires_issuer_or_endpoints(tmp_path: Path) -> None:
    path = tmp_path / ".agent" / ".mcp.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "srv": {
                        "type": "http",
                        "url": "https://x.test/mcp",
                        "oauth": {"client_id": "cid"},
                    }
                }
            }
        ),
        encoding="utf-8",
    )

    with pytest.raises(McpConfigError, match="issuer"):
        load_mcp_servers_from_path(path)


def test_headers_authorization_and_oauth_mutual_exclusive(tmp_path: Path) -> None:
    for key in ("Authorization", "authorization", "AUTHORIZATION"):
        path = tmp_path / f".agent-{key}" / ".mcp.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(
                {
                    "mcpServers": {
                        "srv": {
                            "type": "http",
                            "url": "https://x.test/mcp",
                            "headers": {key: "Bearer xxx"},
                            "oauth": {
                                "client_id": "cid",
                                "issuer": "https://i.test/",
                            },
                        }
                    }
                }
            ),
            encoding="utf-8",
        )

        with pytest.raises(McpConfigError, match="Authorization.*oauth.*不能同时"):
            load_mcp_servers_from_path(path)


def test_oauth_rejected_for_sse_transport(tmp_path: Path) -> None:
    path = tmp_path / ".agent" / ".mcp.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "srv": {
                        "type": "sse",
                        "url": "https://x.test/sse",
                        "oauth": {
                            "client_id": "cid",
                            "issuer": "https://i.test/",
                        },
                    }
                }
            }
        ),
        encoding="utf-8",
    )

    with pytest.raises(McpConfigError, match="sse.*oauth"):
        load_mcp_servers_from_path(path)
