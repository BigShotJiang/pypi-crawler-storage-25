from __future__ import annotations

import asyncio
import base64
import hashlib
import re
import time
import urllib.parse
from pathlib import Path

import httpx
import pytest

from comate_agent_sdk.mcp.oauth import (
    MetadataDiscoveryError,
    OAuthAuth,
    OAuthMetadata,
    RefreshFailedError,
    _generate_pkce,
    _generate_state,
    discover_metadata,
)
from comate_agent_sdk.mcp.token_store import StoredToken, TokenStore


def test_pkce_verifier_is_43_plus_chars_urlsafe() -> None:
    verifier, _challenge = _generate_pkce()
    assert 43 <= len(verifier) <= 128
    assert re.fullmatch(r"[A-Za-z0-9\-_]+", verifier)


def test_pkce_challenge_is_sha256_base64url_of_verifier() -> None:
    verifier, challenge = _generate_pkce()
    expected = base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode("ascii")).digest()
    ).rstrip(b"=").decode("ascii")
    assert challenge == expected


def test_state_is_urlsafe_base64_16_bytes() -> None:
    state = _generate_state()
    assert re.fullmatch(r"[A-Za-z0-9\-_]+", state)
    assert 20 <= len(state) <= 24


def test_discover_metadata_uses_rfc8414_well_known_path() -> None:
    requested_urls: list[str] = []

    async def _handler(request: httpx.Request) -> httpx.Response:
        requested_urls.append(str(request.url))
        return httpx.Response(
            200,
            json={
                "authorization_endpoint": "https://i.test/auth",
                "token_endpoint": "https://i.test/token",
            },
        )

    async def _run() -> None:
        transport = httpx.MockTransport(_handler)
        async with httpx.AsyncClient(transport=transport) as client:
            meta = await discover_metadata("https://i.test", http_client=client)
        assert meta == OAuthMetadata(
            authorization_endpoint="https://i.test/auth",
            token_endpoint="https://i.test/token",
        )
        assert requested_urls[0].endswith("/.well-known/oauth-authorization-server")

    asyncio.run(_run())


def test_discover_metadata_fallback_to_openid_configuration() -> None:
    async def _handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("oauth-authorization-server"):
            return httpx.Response(404)
        return httpx.Response(
            200,
            json={
                "authorization_endpoint": "https://i.test/auth",
                "token_endpoint": "https://i.test/token",
            },
        )

    async def _run() -> None:
        transport = httpx.MockTransport(_handler)
        async with httpx.AsyncClient(transport=transport) as client:
            meta = await discover_metadata("https://i.test", http_client=client)
        assert meta.authorization_endpoint == "https://i.test/auth"

    asyncio.run(_run())


def test_discover_metadata_both_404_raises_MetadataDiscoveryError() -> None:
    async def _handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(404)

    async def _run() -> None:
        transport = httpx.MockTransport(_handler)
        async with httpx.AsyncClient(transport=transport) as client:
            with pytest.raises(MetadataDiscoveryError):
                await discover_metadata("https://i.test", http_client=client)

    asyncio.run(_run())


def _build_auth(tmp_path: Path, *, token: StoredToken) -> OAuthAuth:
    store = TokenStore(base_dir=tmp_path)
    store.save("test", token)
    meta = OAuthMetadata(
        authorization_endpoint="https://i.test/auth",
        token_endpoint="https://i.test/token",
    )
    return OAuthAuth(
        alias="test",
        metadata=meta,
        client_id="cid",
        client_secret=None,
        scope=None,
        token=token,
        token_store=store,
    )


def test_OAuthAuth_async_auth_flow_attaches_bearer_header(tmp_path: Path) -> None:
    token = StoredToken("at-1", "rt-1", "Bearer", time.time() + 3600, None)
    auth = _build_auth(tmp_path, token=token)

    async def _run() -> None:
        req = httpx.Request("POST", "https://s.test/mcp")
        gen = auth.async_auth_flow(req)
        sent = await gen.__anext__()
        assert sent.headers["Authorization"] == "Bearer at-1"
        with pytest.raises(StopAsyncIteration):
            await gen.asend(httpx.Response(200, request=req))

    asyncio.run(_run())


def test_OAuthAuth_async_auth_flow_retries_once_on_401(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    token = StoredToken("at-old", "rt-xyz", "Bearer", time.time() + 3600, None)
    auth = _build_auth(tmp_path, token=token)

    async def _fake_refresh(self, refresh_token: str) -> StoredToken:
        del self, refresh_token
        return StoredToken("at-new", "rt-xyz", "Bearer", time.time() + 3600, None)

    monkeypatch.setattr(OAuthAuth, "_refresh", _fake_refresh)

    async def _run() -> None:
        req = httpx.Request("POST", "https://s.test/mcp")
        gen = auth.async_auth_flow(req)
        first = await gen.__anext__()
        assert first.headers["Authorization"] == "Bearer at-old"
        second = await gen.asend(httpx.Response(401, request=req))
        assert second.headers["Authorization"] == "Bearer at-new"
        with pytest.raises(StopAsyncIteration):
            await gen.asend(httpx.Response(200, request=req))

    asyncio.run(_run())


def test_refresh_flow_updates_expires_at_and_persists(tmp_path: Path) -> None:
    old_token = StoredToken("at-old", "rt-xyz", "Bearer", 100.0, None)
    store = TokenStore(base_dir=tmp_path)
    store.save("test", old_token)
    meta = OAuthMetadata(
        authorization_endpoint="https://i.test/auth",
        token_endpoint="https://i.test/token",
    )

    async def _handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path.endswith("/token")
        body = dict(urllib.parse.parse_qsl((await request.aread()).decode()))
        assert body["grant_type"] == "refresh_token"
        assert body["refresh_token"] == "rt-xyz"
        return httpx.Response(
            200,
            json={
                "access_token": "at-new",
                "refresh_token": "rt-xyz",
                "token_type": "Bearer",
                "expires_in": 3600,
            },
        )

    async def _run() -> None:
        transport = httpx.MockTransport(_handler)
        async with httpx.AsyncClient(transport=transport) as client:
            auth = OAuthAuth(
                alias="test",
                metadata=meta,
                client_id="cid",
                client_secret=None,
                scope=None,
                token=old_token,
                token_store=store,
                http_client=client,
            )
            new_token = await auth._refresh("rt-xyz")
        assert new_token.access_token == "at-new"
        assert new_token.expires_at > time.time()
        reloaded = store.load("test")
        assert reloaded is not None
        assert reloaded.access_token == "at-new"

    asyncio.run(_run())


def test_refresh_with_invalid_grant_raises_RefreshFailedError(tmp_path: Path) -> None:
    token = StoredToken("at-1", "rt-xyz", "Bearer", 100.0, None)
    store = TokenStore(base_dir=tmp_path)
    store.save("test", token)
    meta = OAuthMetadata(
        authorization_endpoint="https://i.test/auth",
        token_endpoint="https://i.test/token",
    )

    async def _handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(400, json={"error": "invalid_grant"})

    async def _run() -> None:
        transport = httpx.MockTransport(_handler)
        async with httpx.AsyncClient(transport=transport) as client:
            auth = OAuthAuth(
                alias="test",
                metadata=meta,
                client_id="cid",
                client_secret=None,
                scope=None,
                token=token,
                token_store=store,
                http_client=client,
            )
            with pytest.raises(RefreshFailedError):
                await auth._refresh("rt-xyz")

    asyncio.run(_run())
