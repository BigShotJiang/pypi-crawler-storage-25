from __future__ import annotations

import asyncio
import socket
import sys
import time
import urllib.parse
import webbrowser
from pathlib import Path

import httpx
import pytest

from comate_agent_sdk.mcp.oauth import NoBrowserError, OAuthAuth, OAuthMetadata, build_auth
from comate_agent_sdk.mcp.token_store import StoredToken, TokenStore


def test_warm_start_uses_cached_token_without_browser(tmp_path: Path) -> None:
    store = TokenStore(base_dir=tmp_path)
    store.save(
        "notion",
        StoredToken("at-cached", "rt-x", "Bearer", time.time() + 3600, None),
    )

    async def _run() -> None:
        auth = await build_auth(
            "notion",
            {
                "client_id": "cid",
                "authorization_endpoint": "https://i.test/auth",
                "token_endpoint": "https://i.test/token",
            },
            token_store=store,
        )
        assert auth._token.access_token == "at-cached"

    asyncio.run(_run())


def test_expired_token_triggers_refresh_not_reauth(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    store = TokenStore(base_dir=tmp_path)
    store.save(
        "notion",
        StoredToken("at-old", "rt-xyz", "Bearer", time.time() - 100, None),
    )
    refresh_count = [0]

    async def _handler(request: httpx.Request) -> httpx.Response:
        del request
        refresh_count[0] += 1
        return httpx.Response(
            200,
            json={
                "access_token": "at-refreshed",
                "refresh_token": "rt-xyz",
                "token_type": "Bearer",
                "expires_in": 3600,
            },
        )

    def _panic_browser(url: str) -> bool:
        raise AssertionError(f"webbrowser.open called unexpectedly with {url}")

    monkeypatch.setattr(webbrowser, "open", _panic_browser)

    async def _run() -> None:
        transport = httpx.MockTransport(_handler)
        async with httpx.AsyncClient(transport=transport) as client:
            auth = await build_auth(
                "notion",
                {
                    "client_id": "cid",
                    "authorization_endpoint": "https://i.test/auth",
                    "token_endpoint": "https://i.test/token",
                },
                token_store=store,
                http_client_for_refresh=client,
            )
        assert refresh_count[0] == 1
        assert auth._token.access_token == "at-refreshed"

    asyncio.run(_run())


@pytest.mark.skipif(sys.platform == "win32", reason="env-based headless detection")
def test_headless_detection_raises_NoBrowserError(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("CI", "1")
    store = TokenStore(base_dir=tmp_path)

    async def _run() -> None:
        with pytest.raises(NoBrowserError):
            await build_auth(
                "notion",
                {
                    "client_id": "cid",
                    "authorization_endpoint": "https://i.test/auth",
                    "token_endpoint": "https://i.test/token",
                },
                token_store=store,
            )

    asyncio.run(_run())


def test_cold_start_authorization_code_flow_saves_token(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    store = TokenStore(base_dir=tmp_path)
    monkeypatch.delenv("CI", raising=False)
    if sys.platform.startswith("linux"):
        monkeypatch.setenv("DISPLAY", ":0")

    async def _handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/.well-known/oauth-authorization-server"):
            return httpx.Response(
                200,
                json={
                    "authorization_endpoint": "https://i.test/auth",
                    "token_endpoint": "https://i.test/token",
                },
            )
        if request.url.path == "/token":
            return httpx.Response(
                200,
                json={
                    "access_token": "at-fresh",
                    "refresh_token": "rt-new",
                    "token_type": "Bearer",
                    "expires_in": 3600,
                },
            )
        return httpx.Response(404)

    def _fake_open(url: str) -> bool:
        async def _fire() -> None:
            await asyncio.sleep(0.02)
            parsed = urllib.parse.urlparse(url)
            params = dict(urllib.parse.parse_qsl(parsed.query))
            redirect = params["redirect_uri"]
            code = "code-abc"
            state = params["state"]
            async with httpx.AsyncClient() as client:
                await client.get(f"{redirect}?code={code}&state={state}")

        asyncio.create_task(_fire())
        return True

    monkeypatch.setattr(webbrowser, "open", _fake_open)

    async def _run() -> None:
        transport = httpx.MockTransport(_handler)
        async with httpx.AsyncClient(transport=transport) as client:
            auth = await build_auth(
                "notion",
                {"client_id": "cid", "issuer": "https://i.test"},
                token_store=store,
                http_client_for_refresh=client,
                auth_timeout_s=5.0,
            )
        assert auth._token.access_token == "at-fresh"
        loaded = store.load("notion")
        assert loaded is not None
        assert loaded.access_token == "at-fresh"

    asyncio.run(_run())


def test_aclose_during_pending_callback_releases_port(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("CI", raising=False)
    if sys.platform.startswith("linux"):
        monkeypatch.setenv("DISPLAY", ":0")

    monkeypatch.setattr(webbrowser, "open", lambda _url: True)

    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    chosen_port = sock.getsockname()[1]
    sock.close()

    store = TokenStore(base_dir=tmp_path)

    async def _run() -> None:
        with pytest.raises(asyncio.TimeoutError):
            await build_auth(
                "notion",
                {
                    "client_id": "cid",
                    "authorization_endpoint": "https://i.test/auth",
                    "token_endpoint": "https://i.test/token",
                    "callback_port": chosen_port,
                    "callback_timeout_s": 30.0,
                },
                token_store=store,
                auth_timeout_s=0.3,
            )

        server = await asyncio.start_server(lambda _r, _w: None, "127.0.0.1", chosen_port)
        server.close()
        await server.wait_closed()

    asyncio.run(_run())


def test_concurrent_call_tools_single_flight_refresh(tmp_path: Path) -> None:
    store = TokenStore(base_dir=tmp_path)
    expired = StoredToken("at-old", "rt-xyz", "Bearer", time.time() - 100, None)
    store.save("test", expired)
    auth = OAuthAuth(
        alias="test",
        metadata=OAuthMetadata(
            authorization_endpoint="https://i.test/auth",
            token_endpoint="https://i.test/token",
        ),
        client_id="cid",
        client_secret=None,
        scope=None,
        token=expired,
        token_store=store,
    )

    refresh_calls = 0
    gate = asyncio.Event()

    async def _fake_refresh(self, refresh_token: str) -> StoredToken:
        nonlocal refresh_calls
        del self, refresh_token
        refresh_calls += 1
        await gate.wait()
        return StoredToken("at-new", "rt-xyz", "Bearer", time.time() + 3600, None)

    auth._refresh = _fake_refresh.__get__(auth, OAuthAuth)  # type: ignore[method-assign]

    async def _run() -> None:
        tasks = [asyncio.create_task(auth._ensure_fresh()) for _ in range(10)]
        await asyncio.sleep(0.05)
        gate.set()
        results = await asyncio.gather(*tasks)
        assert refresh_calls == 1
        assert {token.access_token for token in results} == {"at-new"}

    asyncio.run(_run())
