"""Regression tests for MCP server instructions capture along the
_create_session → _open_connection → _server_states data flow.

对齐 spec §4.2.1-§4.2.5 的路径约定。

项目未配置 pytest-asyncio，沿用 test_mcp_manager_lifecycle.py 的
`asyncio.run(_run())` 包裹风格。
"""
from __future__ import annotations

import asyncio
import contextlib
from contextlib import AsyncExitStack, asynccontextmanager
from unittest.mock import AsyncMock, MagicMock, patch

from mcp.types import (
    Implementation,
    InitializeResult,
    ServerCapabilities,
)


def _make_init_result(instructions: str | None) -> InitializeResult:
    return InitializeResult(
        protocolVersion="2024-11-05",
        capabilities=ServerCapabilities(),
        serverInfo=Implementation(name="test-server", version="0.1"),
        instructions=instructions,
    )


def _make_client_session_patch(mock_session: AsyncMock) -> MagicMock:
    """ClientSession(...) 在被 `stack.enter_async_context(...)` 消费时，
    必须让 __aenter__ yield 回同一个 mock session。"""
    mock_session.__aenter__ = AsyncMock(return_value=mock_session)
    mock_session.__aexit__ = AsyncMock(return_value=None)
    return MagicMock(return_value=mock_session)


def test_create_session_stdio_captures_instructions() -> None:
    """spec §4.2.1 stdio 分支接住 init_result.instructions"""
    from comate_agent_sdk.mcp.manager import McpManager

    async def _run() -> None:
        mgr = McpManager({})
        fake_init = _make_init_result("stdio 用法说明")
        mock_session = AsyncMock()
        mock_session.initialize = AsyncMock(return_value=fake_init)

        @asynccontextmanager
        async def fake_stdio_client(*_a, **_kw):
            yield MagicMock(), MagicMock()

        with patch(
            "comate_agent_sdk.mcp.manager.stdio_client",
            side_effect=fake_stdio_client,
        ), patch(
            "comate_agent_sdk.mcp.manager.ClientSession",
            new=_make_client_session_patch(mock_session),
        ):
            async with AsyncExitStack() as stack:
                session, gsid, instructions = await mgr._create_session(
                    stack,
                    "srv_a",
                    {"type": "stdio", "command": "echo", "args": []},
                    "stdio",
                )
                assert instructions == "stdio 用法说明"
                assert gsid is None
                assert session is mock_session

    asyncio.run(_run())


def test_create_session_stdio_instructions_none() -> None:
    """spec §4.2.1 stdio 分支 server 未提供 instructions 时保持 None"""
    from comate_agent_sdk.mcp.manager import McpManager

    async def _run() -> None:
        mgr = McpManager({})
        fake_init = _make_init_result(None)
        mock_session = AsyncMock()
        mock_session.initialize = AsyncMock(return_value=fake_init)

        @asynccontextmanager
        async def fake_stdio_client(*_a, **_kw):
            yield MagicMock(), MagicMock()

        with patch(
            "comate_agent_sdk.mcp.manager.stdio_client",
            side_effect=fake_stdio_client,
        ), patch(
            "comate_agent_sdk.mcp.manager.ClientSession",
            new=_make_client_session_patch(mock_session),
        ):
            async with AsyncExitStack() as stack:
                _, _, instructions = await mgr._create_session(
                    stack,
                    "srv_a",
                    {"type": "stdio", "command": "echo", "args": []},
                    "stdio",
                )
                assert instructions is None

    asyncio.run(_run())


def test_create_session_sse_captures_instructions() -> None:
    """spec §4.2.1 sse 分支接住 init_result.instructions"""
    from comate_agent_sdk.mcp.manager import McpManager

    async def _run() -> None:
        mgr = McpManager({})
        fake_init = _make_init_result("sse 用法说明")
        mock_session = AsyncMock()
        mock_session.initialize = AsyncMock(return_value=fake_init)

        @asynccontextmanager
        async def fake_sse_client(*_a, **_kw):
            yield MagicMock(), MagicMock()

        with patch(
            "comate_agent_sdk.mcp.manager.sse_client",
            side_effect=fake_sse_client,
        ), patch(
            "comate_agent_sdk.mcp.manager.ClientSession",
            new=_make_client_session_patch(mock_session),
        ):
            async with AsyncExitStack() as stack:
                session, gsid, instructions = await mgr._create_session(
                    stack,
                    "srv_a",
                    {"type": "sse", "url": "https://x.test/sse"},
                    "sse",
                )
                assert instructions == "sse 用法说明"
                assert gsid is None
                assert session is mock_session

    asyncio.run(_run())


def test_create_session_http_captures_instructions_and_get_session_id() -> None:
    """spec §4.2.1 http 分支接住 instructions 同时回传 get_session_id"""
    from comate_agent_sdk.mcp.manager import McpManager

    async def _run() -> None:
        mgr = McpManager({})
        fake_init = _make_init_result("http 用法说明")
        mock_session = AsyncMock()
        mock_session.initialize = AsyncMock(return_value=fake_init)

        sentinel_get_session_id = MagicMock(return_value="sid-123")

        @asynccontextmanager
        async def fake_http_client(*_a, **_kw):
            yield MagicMock(), MagicMock(), sentinel_get_session_id

        @asynccontextmanager
        async def fake_httpx_async_client(*_a, **_kw):
            yield MagicMock()

        with patch(
            "comate_agent_sdk.mcp.manager.streamable_http_client",
            side_effect=fake_http_client,
        ), patch(
            "comate_agent_sdk.mcp.manager.httpx.AsyncClient",
            side_effect=fake_httpx_async_client,
        ), patch(
            "comate_agent_sdk.mcp.manager.ClientSession",
            new=_make_client_session_patch(mock_session),
        ):
            async with AsyncExitStack() as stack:
                session, gsid, instructions = await mgr._create_session(
                    stack,
                    "srv_a",
                    {"type": "http", "url": "https://x.test/mcp"},
                    "http",
                )
                assert instructions == "http 用法说明"
                assert gsid is sentinel_get_session_id
                assert session is mock_session

    asyncio.run(_run())


def test_create_session_sdk_returns_none_per_n8() -> None:
    """spec N8: SDK 分支 ctx manager 吞掉 InitializeResult，instructions 固定 None"""
    from comate_agent_sdk.mcp.manager import McpManager

    async def _run() -> None:
        mgr = McpManager({})
        mock_session = AsyncMock()

        @asynccontextmanager
        async def fake_ctx_factory(_instance):
            yield mock_session

        with patch(
            "comate_agent_sdk.mcp.manager.create_connected_server_and_client_session",
            side_effect=fake_ctx_factory,
        ):
            async with AsyncExitStack() as stack:
                session, gsid, instructions = await mgr._create_session(
                    stack,
                    "srv_sdk",
                    {"type": "sdk", "instance": object()},
                    "sdk",
                )
                assert instructions is None
                assert gsid is None
                assert session is mock_session

    asyncio.run(_run())


# ---------------------------------------------------------------------------
# spec §4.2.5: _open_connection 返回 (session, instructions)，三调用方分别处理
# ---------------------------------------------------------------------------


def test_retry_server_writes_instructions_to_state() -> None:
    """spec §4.2.4：retry 成功后 state 应含 instructions"""
    from comate_agent_sdk.mcp.manager import McpManager

    async def _run() -> None:
        mgr = McpManager({"srv_a": {"type": "stdio", "command": "echo", "args": []}})

        mock_session = AsyncMock()
        mock_session.list_tools = AsyncMock(return_value=MagicMock(tools=[]))

        async def fake_open(_alias, _cfg):
            return mock_session, "用法 X"

        mgr._open_connection = fake_open  # type: ignore[method-assign]
        mgr._close_connection = AsyncMock()
        mgr._list_all_tools = AsyncMock(return_value=[])

        ok = await mgr.retry_server("srv_a")
        assert ok is True
        assert mgr._server_states["srv_a"].instructions == "用法 X"

    asyncio.run(_run())


def test_run_server_worker_writes_instructions_to_state() -> None:
    """spec §4.2.4：worker 成功后 state 应含 instructions"""
    from types import SimpleNamespace

    from comate_agent_sdk.mcp.manager import McpManager

    async def _run() -> None:
        mgr = McpManager({"srv_a": {"type": "stdio", "command": "echo", "args": []}})
        mock_session = AsyncMock()

        async def fake_open(_alias, _cfg):
            return mock_session, "worker 用法"

        mgr._open_connection = fake_open  # type: ignore[method-assign]
        mgr._list_all_tools = AsyncMock(
            return_value=[
                SimpleNamespace(
                    name="foo",
                    description="foo desc",
                    inputSchema={"type": "object", "properties": {}},
                )
            ]
        )
        ready: asyncio.Future[bool] = asyncio.get_running_loop().create_future()

        await mgr._run_server_worker(
            "srv_a",
            {"type": "stdio", "command": "echo", "args": []},
            ready,
        )

        assert ready.done() and ready.result() is True
        assert mgr._server_states["srv_a"].instructions == "worker 用法"
        assert mgr._server_states["srv_a"].tool_count == 1

    asyncio.run(_run())


def test_session_expired_reconnect_does_not_refresh_instructions() -> None:
    """spec N9：call_tool 重连忽略 instructions，_server_states 不变"""
    from comate_agent_sdk.mcp.manager import (
        McpManager,
        McpServerRuntimeState,
        McpToolInfo,
        _CachedConnection,
    )

    async def _run() -> None:
        mgr = McpManager({"srv_a": {"type": "http", "url": "https://x.test/mcp"}})
        mgr._server_states["srv_a"] = McpServerRuntimeState(
            alias="srv_a",
            status="connected",
            reason=None,
            tool_count=1,
            instructions="老用法",
        )
        mgr._tool_info_by_mapped["mcp__srv_a__foo"] = McpToolInfo(
            server_alias="srv_a",
            server_type="http",
            remote_name="foo",
            mapped_name="mcp__srv_a__foo",
            description="foo",
            input_schema={"type": "object", "properties": {}},
        )

        old_shutdown = asyncio.Event()
        old_owner = asyncio.create_task(old_shutdown.wait())
        old_session = AsyncMock()
        old_session.call_tool = AsyncMock(side_effect=ConnectionResetError("expired"))
        mgr._conn_cache["srv_a"] = _CachedConnection(
            alias="srv_a",
            server_type="http",
            config_hash="old",
            session=old_session,
            owner_task=old_owner,
            shutdown_event=old_shutdown,
        )

        new_session = AsyncMock()
        new_session.call_tool = AsyncMock(
            return_value=MagicMock(content=[], isError=False)
        )

        async def fake_close(alias):
            old_shutdown.set()
            mgr._conn_cache.pop(alias, None)

        async def fake_open(alias, _cfg):
            shutdown = asyncio.Event()
            owner = asyncio.create_task(shutdown.wait())
            mgr._conn_cache[alias] = _CachedConnection(
                alias=alias,
                server_type="http",
                config_hash="new",
                session=new_session,
                owner_task=owner,
                shutdown_event=shutdown,
            )
            return new_session, "新用法"

        mgr._close_connection = fake_close  # type: ignore[method-assign]
        mgr._open_connection = fake_open  # type: ignore[method-assign]

        result = await mgr.call_tool("mcp__srv_a__foo", {})
        assert result.is_error is False
        # N9：重连不刷新 state，老 instructions 仍保持。
        assert mgr._server_states["srv_a"].instructions == "老用法"

        for cached in list(mgr._conn_cache.values()):
            cached.shutdown_event.set()
            await cached.owner_task
        if not old_owner.done():
            old_shutdown.set()
            await old_owner

    asyncio.run(_run())


# ---------------------------------------------------------------------------
# spec §4.2.4: cache-hit 路径应从旧 state 继承 instructions（B2 Blocker 修复）
# ---------------------------------------------------------------------------


def test_cache_hit_preserves_instructions() -> None:
    """进入 manager.py cache-hit 分支需要 3 个条件同时成立：
    1. _conn_cache[alias] 存在且 config_hash 匹配
    2. _tools_list_cache[alias] 存在（tool_infos 非空）
    3. _server_states[alias] 已存在（代表上次已连接）
    """
    import time

    from comate_agent_sdk.mcp.manager import (
        McpManager,
        McpServerRuntimeState,
        McpToolInfo,
        _CachedConnection,
        _CachedToolList,
    )

    async def _run() -> None:
        cfg = {"type": "stdio", "command": "echo", "args": []}
        mgr = McpManager({"srv_a": cfg})
        alias = "srv_a"

        # 1. 旧 state 带 instructions
        mgr._server_states[alias] = McpServerRuntimeState(
            alias=alias,
            status="connected",
            reason=None,
            tool_count=1,
            instructions="旧 instructions",
        )
        # 2. 工具列表 cache
        tool_info = McpToolInfo(
            server_alias=alias,
            server_type="stdio",
            remote_name="foo",
            mapped_name="mcp__srv_a__foo",
            description="test",
            input_schema={},
        )
        mgr._tools_list_cache[alias] = _CachedToolList(
            alias=alias,
            tool_infos=(tool_info,),
            fetched_at=time.monotonic(),
        )
        # 3. 连接 cache (config_hash 必须匹配)
        config_hash = mgr._compute_config_hash(cfg)
        mock_session = AsyncMock()
        shutdown = asyncio.Event()
        mock_owner_task = asyncio.create_task(shutdown.wait())
        mgr._conn_cache[alias] = _CachedConnection(
            alias=alias,
            server_type="stdio",
            config_hash=config_hash,
            session=mock_session,
            owner_task=mock_owner_task,
            shutdown_event=shutdown,
            get_session_id=None,
        )

        try:
            await mgr.start(on_tools_ready=lambda _t: None)

            assert mgr._server_states[alias].instructions == "旧 instructions"
            assert mgr._server_states[alias].status == "connected"
        finally:
            shutdown.set()
            with contextlib.suppress(Exception):
                await asyncio.wait_for(mock_owner_task, timeout=1.0)

    asyncio.run(_run())
