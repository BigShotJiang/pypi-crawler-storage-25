"""Unit tests for build_server_instructions_text / _metadata.

对齐 spec §4.3.2-§4.3.3。
"""
from __future__ import annotations

from comate_agent_sdk.mcp.manager import McpManager, McpServerRuntimeState


def _make_mgr() -> McpManager:
    return McpManager({})


class TestBuildServerInstructionsText:
    def test_empty_returns_empty_string(self):
        mgr = _make_mgr()
        assert mgr.build_server_instructions_text() == ""

    def test_single_server_with_instructions(self):
        mgr = _make_mgr()
        mgr._server_states["srv_a"] = McpServerRuntimeState(
            alias="srv_a",
            status="connected",
            reason=None,
            tool_count=2,
            instructions="用法 A",
        )
        result = mgr.build_server_instructions_text()
        assert result.startswith("<mcp_tools>\n")
        assert result.endswith("\n</mcp_tools>")
        assert "# MCP Server Instructions" in result
        assert "## srv_a\n用法 A" in result

    def test_single_server_no_instructions_returns_empty(self):
        mgr = _make_mgr()
        mgr._server_states["srv_a"] = McpServerRuntimeState(
            alias="srv_a",
            status="connected",
            reason=None,
            tool_count=2,
            instructions=None,
        )
        assert mgr.build_server_instructions_text() == ""

    def test_failed_server_skipped(self):
        mgr = _make_mgr()
        mgr._server_states["srv_a"] = McpServerRuntimeState(
            alias="srv_a",
            status="failed",
            reason="connection refused",
            tool_count=0,
            instructions="should not appear",
        )
        assert mgr.build_server_instructions_text() == ""

    def test_multi_server_mixed(self):
        mgr = _make_mgr()
        mgr._server_states["srv_a"] = McpServerRuntimeState(
            alias="srv_a",
            status="connected",
            reason=None,
            tool_count=2,
            instructions="用法 A",
        )
        mgr._server_states["srv_b"] = McpServerRuntimeState(
            alias="srv_b",
            status="connected",
            reason=None,
            tool_count=1,
            instructions=None,
        )
        mgr._server_states["srv_c"] = McpServerRuntimeState(
            alias="srv_c",
            status="failed",
            reason="x",
            tool_count=0,
            instructions="说明 C",
        )
        mgr._server_states["srv_z"] = McpServerRuntimeState(
            alias="srv_z",
            status="connected",
            reason=None,
            tool_count=1,
            instructions="用法 Z",
        )
        result = mgr.build_server_instructions_text()
        assert "## srv_a\n用法 A" in result
        assert "## srv_z\n用法 Z" in result
        assert "srv_b" not in result
        assert "srv_c" not in result
        # 字典序：srv_a 在 srv_z 前
        assert result.index("srv_a") < result.index("srv_z")


class TestBuildServerInstructionsMetadata:
    def test_metadata_includes_all_servers_regardless_of_status(self):
        mgr = _make_mgr()
        mgr._server_states["srv_a"] = McpServerRuntimeState(
            alias="srv_a",
            status="connected",
            reason=None,
            tool_count=2,
            instructions="A",
        )
        mgr._server_states["srv_b"] = McpServerRuntimeState(
            alias="srv_b",
            status="failed",
            reason="x",
            tool_count=0,
        )
        meta = mgr.build_server_instructions_metadata()
        assert "servers" in meta
        assert len(meta["servers"]) == 2
        by_alias = {s["alias"]: s for s in meta["servers"]}
        assert by_alias["srv_a"]["has_instructions"] is True
        assert by_alias["srv_a"]["instructions"] == "A"
        assert by_alias["srv_b"]["has_instructions"] is False
        assert by_alias["srv_b"]["status"] == "failed"
