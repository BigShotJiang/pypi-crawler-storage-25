"""Unified system reminder engine."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Callable

from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.prompts import load_prompt

if TYPE_CHECKING:
    from comate_agent_sdk.context.items import ContextItem
    from comate_agent_sdk.llm.messages import ToolMessage

logger = logging.getLogger("comate_agent_sdk.context.reminder_engine")

AGENT_NUDGE_GAP = 8
AGENT_NUDGE_COOLDOWN = 8
TASK_EMPTY_NUDGE_GAP = 15

_TASK_EMPTY_REMINDER_CONTENT = load_prompt("reminders/task_empty_reminder.md")


class ReminderOrigin(Enum):
    SYSTEM_REMINDER = "system_reminder"


@dataclass(slots=True, frozen=True)
class ReminderMessageEnvelope:
    rule_id: str
    tool_name: str
    content: str


@dataclass(slots=True)
class ToolTriggeredReminder:
    reminder_id: str
    trigger_tool: str
    content: str
    fired: bool = False
    pending: bool = False


@dataclass(slots=True)
class ReminderState:
    turn: int = 0
    mode_plan: bool = False
    plan_mode_reminder_template: str = ""
    plan_exit_pending: bool = False
    plan_exit_reminder_template: str = ""
    plan_mode_was_used: bool = False
    last_agent_turn: int = 0
    last_agent_nudge_turn: int = 0
    last_task_tool_turn: int = 0
    task_open_count: int = 0
    task_last_changed_turn: int = 0
    last_task_tool_nudge_turn: int = 0


@dataclass(slots=True)
class TaskListState:
    list_id: str = "default"
    tasks: list[dict[str, Any]] = field(default_factory=list)
    updated_at: float = 0.0
    turn_number_at_update: int = 0


@dataclass(slots=True)
class ReminderEngine:
    state: ReminderState = field(default_factory=ReminderState)
    task_state: TaskListState = field(default_factory=TaskListState)
    _tool_triggered: dict[str, ToolTriggeredReminder] = field(default_factory=dict)

    def clear(self) -> None:
        self.state = ReminderState()
        self.task_state = TaskListState()

    def set_turn(self, turn: int) -> None:
        self.state.turn = max(0, int(turn))

    def set_plan_mode(self, enabled: bool) -> None:
        was_plan = self.state.mode_plan
        self.state.mode_plan = bool(enabled)
        if not was_plan and enabled:
            self.state.plan_mode_was_used = False
        elif was_plan and not enabled and self.state.plan_exit_reminder_template:
            if self.state.plan_mode_was_used:
                self.state.plan_exit_pending = True
            self.state.plan_mode_was_used = False

    def mark_plan_mode_used(self) -> None:
        if self.state.mode_plan:
            self.state.plan_mode_was_used = True

    def set_plan_mode_reminder_template(self, template: str) -> None:
        self.state.plan_mode_reminder_template = str(template or "")

    def set_plan_exit_reminder_template(self, template: str) -> None:
        self.state.plan_exit_reminder_template = str(template or "")

    def register_tool_triggered_reminder(
        self, reminder_id: str, trigger_tool: str, content: str
    ) -> None:
        """注册一个 tool-triggered reminder。若 id 已存在则跳过（幂等）。"""
        if reminder_id in self._tool_triggered:
            return
        self._tool_triggered[reminder_id] = ToolTriggeredReminder(
            reminder_id=reminder_id,
            trigger_tool=trigger_tool,
            content=content,
        )

    @staticmethod
    def _normalize_open_tasks(tasks: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return [
            task
            for task in tasks
            if isinstance(task, dict) and task.get("status") in ("pending", "in_progress")
        ]

    def set_task_list(
        self,
        *,
        tasks: list[dict[str, Any]],
        current_turn: int,
        list_id: str = "default",
    ) -> None:
        open_tasks = self._normalize_open_tasks(tasks)
        normalized_turn = max(0, int(current_turn))
        self.task_state = TaskListState(
            list_id=str(list_id or "default"),
            tasks=open_tasks,
            updated_at=time.time(),
            turn_number_at_update=normalized_turn,
        )
        self.update_task_state(
            open_count=len(open_tasks),
            turn=normalized_turn,
            update_last_write_turn=True,
        )

    def restore_task_list(
        self,
        *,
        tasks: list[dict[str, Any]],
        turn_number_at_update: int,
        current_turn: int,
        list_id: str = "default",
    ) -> None:
        open_tasks = self._normalize_open_tasks(tasks)
        normalized_turn_at_update = max(0, int(turn_number_at_update))
        self.task_state = TaskListState(
            list_id=str(list_id or "default"),
            tasks=open_tasks,
            updated_at=time.time(),
            turn_number_at_update=normalized_turn_at_update,
        )
        self.update_task_state(
            open_count=len(open_tasks),
            turn=current_turn,
            update_last_write_turn=False,
        )
        self.restore_task_tool_turn(normalized_turn_at_update)

    def get_task_state(self) -> dict[str, Any]:
        return {
            "list_id": self.task_state.list_id,
            "tasks": list(self.task_state.tasks),
            "updated_at": self.task_state.updated_at,
            "turn_number_at_update": self.task_state.turn_number_at_update,
        }

    def has_open_tasks(self) -> bool:
        return bool(self.task_state.tasks)

    def get_task_persist_turn_number_at_update(self) -> int:
        return int(self.task_state.turn_number_at_update)

    def update_task_state(
        self,
        *,
        open_count: int,
        turn: int,
        update_last_write_turn: bool,
    ) -> None:
        normalized_count = max(0, int(open_count))
        normalized_turn = max(0, int(turn))
        self.set_turn(normalized_turn)
        count_changed = (self.state.task_open_count == 0) != (normalized_count == 0)
        if count_changed:
            self.state.task_last_changed_turn = normalized_turn
            logger.debug(f"Task empty-state changed at turn={normalized_turn}")
        self.state.task_open_count = normalized_count
        if update_last_write_turn:
            self.state.last_task_tool_turn = normalized_turn

    def restore_task_tool_turn(self, turn_number_at_update: int) -> None:
        self.state.last_task_tool_turn = max(0, int(turn_number_at_update))

    def record_tool_event(
        self,
        *,
        tool_name: str,
        turn: int,
        payload: dict[str, Any] | None = None,
    ) -> None:
        normalized_turn = max(0, int(turn))
        self.set_turn(normalized_turn)

        # tool-triggered reminder scan（无条件，在所有分支之前）
        for reminder in self._tool_triggered.values():
            if not reminder.fired and reminder.trigger_tool == tool_name:
                reminder.pending = True

        if tool_name == "Agent":
            self.state.last_agent_turn = normalized_turn
            logger.debug(f"Recorded Agent event at turn={normalized_turn}")
            return

        if tool_name not in {"TaskCreate", "TaskList", "TaskUpdate"}:
            return

        if payload and isinstance(payload.get("tasks"), list):
            tasks = [task for task in payload["tasks"] if isinstance(task, dict)]
            list_id = str(payload.get("list_id", self.task_state.list_id or "default"))
            self.set_task_list(tasks=tasks, current_turn=normalized_turn, list_id=list_id)
        else:
            self.update_task_state(
                open_count=self.state.task_open_count,
                turn=normalized_turn,
                update_last_write_turn=True,
            )
        self.task_state.turn_number_at_update = normalized_turn
        logger.debug(
            f"Recorded task coordination event at turn={normalized_turn}, open_count={self.state.task_open_count}"
        )

    def rehydrate_from_conversation(
        self,
        *,
        turn: int,
        conversation_items: list[ContextItem],
        is_system_reminder_item: Callable[[ContextItem], bool],
        suppress_task_nudge_on_next_turn: bool = False,
    ) -> None:
        from comate_agent_sdk.llm.messages import ToolMessage

        current = self.state
        rebuilt = ReminderState(
            turn=max(0, int(turn)),
            mode_plan=bool(current.mode_plan),
            plan_mode_reminder_template=str(current.plan_mode_reminder_template or ""),
            plan_exit_reminder_template=str(current.plan_exit_reminder_template or ""),
            last_agent_turn=0,
            last_agent_nudge_turn=0,
            last_task_tool_turn=max(0, int(current.last_task_tool_turn)),
            task_open_count=max(0, int(current.task_open_count)),
            task_last_changed_turn=max(0, int(current.task_last_changed_turn)),
            last_task_tool_nudge_turn=max(0, int(current.last_task_tool_nudge_turn)),
        )
        rebuilt_task_state = TaskListState(
            list_id=self.task_state.list_id,
            tasks=list(self.task_state.tasks),
            updated_at=self.task_state.updated_at,
            turn_number_at_update=self.task_state.turn_number_at_update,
        )

        for item in conversation_items:
            if item.destroyed:
                continue

            item_turn = max(0, int(getattr(item, "created_turn", 0) or 0))
            if item.item_type == ItemType.TOOL_RESULT and not bool(item.is_tool_error):
                tool_name = str(item.tool_name or "").strip()
                if not tool_name and isinstance(item.message, ToolMessage):
                    tool_name = str(item.message.tool_name or "").strip()

                if tool_name == "Agent":
                    rebuilt.last_agent_turn = max(rebuilt.last_agent_turn, item_turn)
                elif tool_name in {"TaskCreate", "TaskList", "TaskUpdate"}:
                    rebuilt.last_task_tool_turn = max(rebuilt.last_task_tool_turn, item_turn)
                    envelope = (item.metadata or {}).get("tool_raw_envelope")
                    if isinstance(envelope, dict):
                        data = envelope.get("data", {})
                        if isinstance(data, dict):
                            raw_tasks = data.get("tasks")
                            if isinstance(raw_tasks, list):
                                tasks = [task for task in raw_tasks if isinstance(task, dict)]
                                open_tasks = self._normalize_open_tasks(tasks)
                                normalized_open = len(open_tasks)
                                if (rebuilt.task_open_count == 0) != (normalized_open == 0):
                                    rebuilt.task_last_changed_turn = max(
                                        rebuilt.task_last_changed_turn,
                                        item_turn,
                                    )
                                rebuilt.task_open_count = normalized_open
                                rebuilt_task_state = TaskListState(
                                    list_id=str(data.get("list_id", "default") or "default"),
                                    tasks=open_tasks,
                                    updated_at=time.time(),
                                    turn_number_at_update=item_turn,
                                )

            if not is_system_reminder_item(item):
                continue
            metadata = item.metadata or {}
            raw_rule_ids = metadata.get("reminder_rule_ids", [])
            if isinstance(raw_rule_ids, list):
                rule_ids = {str(rule_id) for rule_id in raw_rule_ids}
            else:
                rule_ids = set()

            reminder_turn = max(0, int(metadata.get("reminder_turn", item_turn) or item_turn))
            if "agent_gap_reminder" in rule_ids:
                rebuilt.last_agent_nudge_turn = max(rebuilt.last_agent_nudge_turn, reminder_turn)
            if "task_empty_reminder" in rule_ids:
                rebuilt.last_task_tool_nudge_turn = max(
                    rebuilt.last_task_tool_nudge_turn,
                    reminder_turn,
                )

            # Restore tool-triggered fired state
            for rid in rule_ids:
                if rid in self._tool_triggered:
                    self._tool_triggered[rid].fired = True
                    self._tool_triggered[rid].pending = False

        if suppress_task_nudge_on_next_turn:
            rebuilt.last_agent_nudge_turn = max(rebuilt.last_agent_nudge_turn, rebuilt.turn)

        self.state = rebuilt
        self.task_state = rebuilt_task_state

    def collect_due_reminders(self, *, turn: int) -> list[ReminderMessageEnvelope]:
        self.set_turn(turn)
        state = self.state
        reminders: list[ReminderMessageEnvelope] = []

        if state.mode_plan:
            content = str(state.plan_mode_reminder_template or "").strip()
            if not content:
                return reminders
            reminders.append(
                ReminderMessageEnvelope(
                    rule_id="plan_mode_forced",
                    tool_name="PlanMode",
                    content=content,
                )
            )
            return reminders

        if state.plan_exit_pending:
            state.plan_exit_pending = False
            content = str(state.plan_exit_reminder_template or "").strip()
            if content:
                reminders.append(
                    ReminderMessageEnvelope(
                        rule_id="plan_exit_reminder",
                        tool_name="PlanMode",
                        content=content,
                    )
                )
            return reminders

        gap_agent = state.turn - state.last_agent_turn
        cooldown_agent = state.turn - state.last_agent_nudge_turn
        if gap_agent >= AGENT_NUDGE_GAP and cooldown_agent >= AGENT_NUDGE_COOLDOWN:
            reminders.append(
                ReminderMessageEnvelope(
                    rule_id="agent_gap_reminder",
                    tool_name="Agent",
                    content=(
                        "Consider using the Agent tool with specialized subagents when appropriate:\n"
                        "- Explorer: For codebase exploration and research\n"
                        "- Plan: For designing implementation plans"
                    ),
                )
            )
            state.last_agent_nudge_turn = state.turn
            logger.debug(
                f"Agent reminder triggered at turn={state.turn} "
                f"(gap={gap_agent}, cooldown={cooldown_agent})"
            )

        gap_empty = state.turn - state.task_last_changed_turn
        empty_state_not_nudged = state.last_task_tool_nudge_turn < state.task_last_changed_turn
        if (
            state.turn > 0
            and state.task_open_count == 0
            and gap_empty % TASK_EMPTY_NUDGE_GAP == 0
            and empty_state_not_nudged
        ):
            reminders.append(
                ReminderMessageEnvelope(
                    rule_id="task_empty_reminder",
                    tool_name="TaskCreate",
                    content=_TASK_EMPTY_REMINDER_CONTENT,
                )
            )
            state.last_task_tool_nudge_turn = state.turn
            logger.debug(
                f"Task empty reminder triggered at turn={state.turn} "
                f"(gap={gap_empty}, state_changed_turn={state.task_last_changed_turn})"
            )

        # tool-triggered reminders
        for reminder in self._tool_triggered.values():
            if reminder.pending:
                reminders.append(
                    ReminderMessageEnvelope(
                        rule_id=reminder.reminder_id,
                        tool_name=reminder.trigger_tool,
                        content=reminder.content,
                    )
                )
                reminder.fired = True
                reminder.pending = False

        return reminders

    @staticmethod
    def render_merged_message(reminders: list[ReminderMessageEnvelope]) -> str:
        if not reminders:
            return ""
        if len(reminders) == 1:
            body = reminders[0].content
        else:
            lines = ["Multiple reminders for this turn:"]
            for reminder in reminders:
                lines.append(f"- [{reminder.tool_name}] {reminder.content}")
            body = "\n".join(lines)
        return f"<system-reminder>\n{body}\n</system-reminder>"
