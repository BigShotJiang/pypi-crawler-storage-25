from __future__ import annotations

import logging
import os
import platform
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import date
from pathlib import Path

from comate_agent_sdk.utils.paths import PathInput, normalize_path_input

logger = logging.getLogger("comate_agent_sdk.context.env")


# 对齐 Claude Code src/constants/prompts.ts:740。硬编码英文、关键 token 保留原词
# （/dev/null / NUL / forward slashes）—— 模型对英文指令与字面 token 的遵守率更高。
_WINDOWS_SHELL_HINT = (
    "use Unix shell syntax, not Windows — e.g., /dev/null not NUL, forward slashes in paths"
)


def _get_shell_info_line() -> str:
    """生成 `Shell:` 行；Windows 上挂 POSIX 语法硬提醒。

    信息源：`$SHELL` 环境变量（不耦合 system_tools.bash_executor，保持 context 模块独立）。
    Windows 通常不设 SHELL，此时显示 `Shell: unknown (...)` —— 提示仍然有效。
    """
    shell_path = os.environ.get("SHELL", "unknown")
    if "zsh" in shell_path:
        shell_name = "zsh"
    elif "bash" in shell_path:
        shell_name = "bash"
    else:
        shell_name = shell_path

    if sys.platform == "win32":
        return f"Shell: {shell_name} ({_WINDOWS_SHELL_HINT})"
    return f"Shell: {shell_name}"


def _get_os_version_line() -> str:
    """生成 `OS Version:` 行；Windows 上用 platform.version()（构建号）比 release()（仅 "10"）更可诊断。

    对齐 Claude Code src/constants/prompts.ts:752 的 getUnameSR —— Windows 特殊处理，
    其它平台保持 `{system} {release}` 格式。
    """
    if sys.platform == "win32":
        return f"OS Version: Windows {platform.release()} ({platform.version()})"
    return f"OS Version: {platform.system()} {platform.release()}"


def get_project_shell_env() -> dict[str, str]:
    """返回 <project_context> 模板所需的 bash/shell 三件套 value。

    与 EnvProvider.get_system_env() 共享底层字段生成逻辑（_get_shell_info_line /
    _get_os_version_line），但只返回裸 value（不含 "Shell: " / "OS Version: " 前缀），
    由模板负责 key 拼接，避免 key 在模板和代码两端重复。
    """
    shell_value = _get_shell_info_line().removeprefix("Shell: ")
    os_version_value = _get_os_version_line().removeprefix("OS Version: ")
    return {
        "PLATFORM": sys.platform,
        "OS_VERSION": os_version_value,
        "SHELL": shell_value,
    }


@dataclass(frozen=True)
class EnvOptions:
    """环境信息配置选项（用于初始化时快照）"""

    system_env: bool = False
    """是否启用系统环境信息"""
    git_env: bool = False
    """是否启用 Git 状态信息"""
    working_dir: PathInput | None = None
    """工作目录（默认：agent.project_root > cwd）"""
    git_status_limit: int = 10
    """git status 最大保留行数（超过截断）"""
    git_log_limit: int = 6
    """git log 最大保留行数（超过截断）"""

    def __post_init__(self) -> None:
        if self.working_dir is None:
            return
        object.__setattr__(
            self,
            "working_dir",
            normalize_path_input(self.working_dir, field_name="working_dir"),
        )


@dataclass(frozen=True)
class EnvProvider:
    """环境信息提供者（负责采集并格式化）"""

    git_status_limit: int = 10
    git_log_limit: int = 6

    def get_system_env(self, working_dir: Path, extra_lines: list[str] | None = None) -> str:
        """获取系统环境信息，返回 <system_env>...</system_env> 格式

        Args:
            working_dir: 当前工作目录
            extra_lines: 在 </system_env> 前追加的额外行（调用方按需注入）
        """
        tz_name = time.tzname[0] if time.tzname else "Unknown"

        lines = [
            "<system_env>",
            f"today's date: {date.today().isoformat()}",
            f"user timezone: {tz_name}",
            f"python version: {platform.python_version()}"
        ]
        if extra_lines:
            lines.extend(extra_lines)
        lines.append("</system_env> \n")
        return "\n".join(lines)

    def get_git_env(self, working_dir: Path) -> str | None:
        """获取 Git 状态信息，返回 <git_env>...</git_env> 格式

        若 working_dir 不在 git 仓库中，返回 None。
        """
        normalized_dir = working_dir.expanduser().resolve()
        if not self.is_git_repo(normalized_dir):
            return None

        branch = self._git_current_branch(normalized_dir)
        status_text = self._git_status_text(normalized_dir, limit=self.git_status_limit)
        log_text = self._git_recent_commits_text(normalized_dir, limit=self.git_log_limit)

        lines = [
            "<git_env>",
            "This is the git status at the start of the conversation. Note that this status is a snapshot in time, and will not update during the conversation.",
            f"Current Branch: {branch}",
            "Status:",
            status_text,
            "Recent Commits:",
            log_text,
            "</git_env> \n",
        ]
        return "\n".join(lines)

    def _run_git(self, args: list[str], cwd: Path) -> str | None:
        cmd = ["git", *args]
        try:
            proc = subprocess.run(
                cmd,
                cwd=str(cwd),
                text=True,
                encoding="utf-8",
                capture_output=True,
                check=False,
            )
        except FileNotFoundError:
            logger.warning("未找到 git 可执行文件，无法采集 GIT_ENV")
            return None
        except Exception:
            logger.exception(f"执行 git 命令失败: {cmd}")
            return None

        if proc.returncode != 0:
            stderr = (proc.stderr or "").strip()
            if stderr:
                logger.debug(f"git 命令返回非零: {cmd}, stderr={stderr}")
            return None

        return (proc.stdout or "").rstrip("\n")

    def is_git_repo(self, cwd: Path) -> bool:
        out = self._run_git(["rev-parse", "--is-inside-work-tree"], cwd=cwd)
        return (out or "").strip().lower() == "true"

    def _git_current_branch(self, cwd: Path) -> str:
        branch = self._run_git(["rev-parse", "--abbrev-ref", "HEAD"], cwd=cwd)
        if not branch:
            return "unknown"
        if branch.strip() != "HEAD":
            return branch.strip()

        sha = self._run_git(["rev-parse", "--short", "HEAD"], cwd=cwd) or "unknown"
        return f"detached@{sha.strip()}"

    def _git_status_text(self, cwd: Path, *, limit: int) -> str:
        out = self._run_git(["status", "--porcelain"], cwd=cwd)
        if out is None:
            return "（无法获取 git status）"

        lines = [ln.rstrip() for ln in out.splitlines() if ln.strip()]
        if not lines:
            return "（无变更）"

        if limit <= 0 or len(lines) <= limit:
            return "\n".join(lines)

        kept = lines[:limit]
        omitted = len(lines) - limit
        kept.append(f"...（已截断，省略 {omitted} 行）")
        return "\n".join(kept)

    def _git_recent_commits_text(self, cwd: Path, *, limit: int) -> str:
        if limit <= 0:
            return "（已关闭）"

        out = self._run_git(
            ["log", f"-n{limit}", "--pretty=format:%h %s"],
            cwd=cwd,
        )
        if out is None:
            return "（无法获取 git log）"

        lines = [ln.rstrip() for ln in out.splitlines() if ln.strip()]
        return "\n".join(lines) if lines else "（无提交记录）"
