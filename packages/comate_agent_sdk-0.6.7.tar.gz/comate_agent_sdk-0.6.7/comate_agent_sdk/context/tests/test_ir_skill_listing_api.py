"""ContextIR.set_skill_listing / remove_skill_listing API 测试。"""

from __future__ import annotations

from comate_agent_sdk.context import ContextIR
from comate_agent_sdk.context.items import ItemType


def test_set_skill_listing_creates_session_state_item() -> None:
    ctx = ContextIR()
    ctx.set_skill_listing("LISTING_TEXT")

    item = ctx.session_state.find_one_by_type(ItemType.SKILL_LISTING)
    assert item is not None
    assert item.content_text == "LISTING_TEXT"


def test_set_skill_listing_idempotent_overwrite() -> None:
    ctx = ContextIR()
    ctx.set_skill_listing("first")
    ctx.set_skill_listing("second")

    items = ctx.session_state.find_by_type(ItemType.SKILL_LISTING)
    assert len(items) == 1
    assert items[0].content_text == "second"


def test_remove_skill_listing_removes_item() -> None:
    ctx = ContextIR()
    ctx.set_skill_listing("LISTING_TEXT")
    ctx.remove_skill_listing()

    assert ctx.session_state.find_one_by_type(ItemType.SKILL_LISTING) is None


def test_remove_skill_listing_when_absent_is_noop() -> None:
    ctx = ContextIR()
    ctx.remove_skill_listing()

    assert ctx.session_state.find_one_by_type(ItemType.SKILL_LISTING) is None


def test_skill_listing_does_not_appear_in_static_header() -> None:
    ctx = ContextIR()
    ctx.set_skill_listing("LISTING_TEXT")

    header_types = [item.item_type for item in ctx.header.items]
    assert ItemType.SKILL_LISTING not in header_types
