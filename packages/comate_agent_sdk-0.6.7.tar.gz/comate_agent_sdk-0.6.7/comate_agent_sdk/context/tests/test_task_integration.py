"""Task 协调与 ContextIR reminder 状态联动测试。"""

from comate_agent_sdk.context import ContextIR
from comate_agent_sdk.llm.messages import UserMessage


def test_set_task_list_updates_engine_state() -> None:
    ctx = ContextIR()
    ctx.set_turn_number(1)
    ctx.reminder_engine.set_task_list(
        tasks=[{"id": "1", "subject": "Task 1", "status": "pending", "open_blocked_by": []}],
        current_turn=ctx.turn_number,
        list_id="default",
    )
    assert ctx._reminder_engine.state.task_open_count == 1
    assert ctx._reminder_engine.state.task_last_changed_turn == 1
    assert ctx._reminder_engine.state.last_task_tool_turn == 1


def test_empty_task_reminder_is_injected_as_meta_message() -> None:
    """空任务态 reminder 应作为 is_meta message 注入。

    断言契约（rule_id / origin）而不是 prompt 字面量 —— prompt 内容会随
    reminders/task_empty_reminder.md 演化，锁字面量会 drift。
    """
    ctx = ContextIR()
    ctx.add_message(UserMessage(content="hello"))
    ctx.reminder_engine.set_task_list(
        tasks=[{"id": "1", "subject": "Task 1", "status": "pending", "open_blocked_by": []}],
        current_turn=ctx.turn_number,
        list_id="default",
    )
    ctx.set_turn_number(2)
    ctx.reminder_engine.set_task_list(tasks=[], current_turn=ctx.turn_number, list_id="default")

    item = ctx.inject_due_reminders()
    assert item is not None
    assert item.item_type.value == "system_reminder"
    assert item.metadata.get("origin") == "system_reminder"
    assert "task_empty_reminder" in (item.metadata.get("reminder_rule_ids") or [])


