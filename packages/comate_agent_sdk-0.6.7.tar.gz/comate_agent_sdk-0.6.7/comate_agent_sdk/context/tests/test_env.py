import platform as _platform
import subprocess
import sys
from pathlib import Path

import pytest

from comate_agent_sdk.context.env import EnvProvider, get_project_shell_env
from comate_agent_sdk.context.info import _build_categories
from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.prompts import load_prompt, render_prompt


def _render_project_context(working_dir: Path) -> str:
    """使用当前 get_project_shell_env() 渲染 <project_context>，供 Shell/OS 相关断言使用。"""
    return render_prompt(
        load_prompt("agent/project_context.md"),
        variables={
            "WORKING_DIRECTORY": str(working_dir),
            "IS_GIT_REPO": "false",
            **get_project_shell_env(),
        },
        source="agent/project_context.md",
    )


def _run_git(args: list[str], cwd: Path) -> None:
    subprocess.run(
        ["git", *args],
        cwd=str(cwd),
        check=True,
        text=True,
        capture_output=True,
    )


def _init_repo(repo_dir: Path) -> None:
    _run_git(["init"], repo_dir)
    _run_git(["config", "user.email", "test@example.com"], repo_dir)
    _run_git(["config", "user.name", "test"], repo_dir)


def _commit_file(repo_dir: Path, name: str, content: str, message: str) -> None:
    p = repo_dir / name
    p.write_text(content, encoding="utf-8")
    _run_git(["add", name], repo_dir)
    _run_git(["commit", "-m", message], repo_dir)


def test_env_provider_system_env_and_git_env_limits(tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)

    for i in range(7):
        _commit_file(repo, f"f{i}.txt", f"v{i}", f"c{i}")

    for i in range(12):
        (repo / f"u{i}.txt").write_text("x", encoding="utf-8")

    provider = EnvProvider(git_status_limit=10, git_log_limit=6)

    system_env = provider.get_system_env(repo)
    assert "<system_env>" in system_env
    # CWD 已迁移到 project_context，system_env 不再包含
    assert "task_working_directory" not in system_env
    # bash/shell 三件套（platform / OS Version / Shell）已迁移到 project_context
    assert "platform:" not in system_env
    assert "OS Version:" not in system_env
    assert "Shell:" not in system_env
    # 会话时刻类字段仍留在 system_env
    assert "today's date:" in system_env
    assert "python version:" in system_env

    git_env = provider.get_git_env(repo)
    assert git_env is not None
    assert "<git_env>" in git_env
    assert "Current Branch:" in git_env

    lines = git_env.splitlines()

    status_start = lines.index("Status:") + 1
    commits_start = lines.index("Recent Commits:")
    status_lines = [ln for ln in lines[status_start:commits_start] if ln.strip()]
    assert len(status_lines) == 11
    assert status_lines[-1].startswith("...（已截断，省略 ")

    commit_lines = [
        ln
        for ln in lines[commits_start + 1 :]
        if ln.strip() and not ln.strip().startswith("</git_env>")
    ]
    assert len(commit_lines) == 6


def test_context_ir_session_state_env_order_is_stable() -> None:
    ctx = ContextIR()
    ctx.set_system_env("<system_env>\nX\n</system_env>")
    ctx.set_skill_strategy("SKILL")

    header_types = [item.item_type for item in ctx.header.items]
    assert header_types == [ItemType.SKILL_STRATEGY]

    state_types = [item.item_type for item in ctx.session_state.items]
    assert state_types == [ItemType.SYSTEM_ENV]

    ctx.set_git_env("<git_env>\nY\n</git_env>")
    state_types = [item.item_type for item in ctx.session_state.items]
    assert state_types == [ItemType.SYSTEM_ENV, ItemType.GIT_ENV]


def test_context_info_categories_include_env() -> None:
    ctx = ContextIR()
    ctx.set_system_env("<system_env>\nX\n</system_env>")
    ctx.set_git_env("<git_env>\nY\n</git_env>")

    status = ctx.get_budget_status()
    categories = _build_categories(status.tokens_by_type, ctx)
    labels = {c.label for c in categories}
    assert "System Env" in labels
    assert "Git Env" in labels


def test_system_env_no_longer_contains_cwd_or_shell(tmp_path: Path) -> None:
    """After CWD + bash/shell migration to project_context, system_env should not contain any of them."""
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_repo(repo)
    _commit_file(repo, "f.txt", "v", "init")

    provider = EnvProvider()
    system_env = provider.get_system_env(repo)

    # CWD 系列（首轮迁移）
    assert "task_working_directory" not in system_env
    assert "All relative paths" not in system_env
    assert "is git repo" not in system_env
    # bash/shell 三件套（本次迁移）
    assert "platform:" not in system_env
    assert "OS Version:" not in system_env
    assert "Shell:" not in system_env
    # 仍保留的会话时刻类字段
    assert "<system_env>" in system_env
    assert "today's date:" in system_env
    assert "python version:" in system_env


# -----------------------------
# Shell / OS Version 行 + Windows 定向提醒（对齐 Claude Code）
# bash 三件套已从 <system_env> 迁移到 <project_context>，断言目标随之切换。
# -----------------------------


def test_project_context_contains_shell_line_on_posix(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """POSIX 平台：project_context 的 Shell: 行存在，且不带 Windows 专属提示。"""
    monkeypatch.setattr(sys, "platform", "linux")
    monkeypatch.setenv("SHELL", "/usr/bin/zsh")

    rendered = _render_project_context(tmp_path)

    assert "Shell: zsh" in rendered
    assert "use Unix shell syntax" not in rendered


def test_project_context_shell_line_detects_bash_from_env(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """$SHELL 含 bash 时，project_context 的 Shell 行显示 bash（取基础名，不是完整路径）。"""
    monkeypatch.setattr(sys, "platform", "linux")
    monkeypatch.setenv("SHELL", "/opt/homebrew/bin/bash")

    rendered = _render_project_context(tmp_path)

    assert "Shell: bash" in rendered


def test_project_context_shell_line_has_posix_hint_on_windows(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Windows 平台：project_context 的 Shell 行必须挂硬编码的 POSIX 语法提醒。

    直译自 Claude Code src/constants/prompts.ts:740 —— 关键 token（/dev/null、NUL、
    forward slashes）不翻译，避免模型对英文关键词的识别被削弱。
    迁移到 project_context 后该提醒进入 SystemMessage 段，attention 权重更高。
    """
    monkeypatch.setattr(sys, "platform", "win32")

    rendered = _render_project_context(tmp_path)

    assert "Shell:" in rendered
    assert "use Unix shell syntax, not Windows" in rendered
    assert "/dev/null not NUL" in rendered
    assert "forward slashes in paths" in rendered


def test_project_context_os_version_friendly_on_windows(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Windows 平台：project_context 的 OS Version 使用 platform.version()（构建号）比 release()（只给 "10"）更可诊断。

    对齐 Claude Code src/constants/prompts.ts:752 的 getUnameSR —— Windows 上用
    os.version() 而不是 os.type() 拿到更友好的版本描述。
    """
    monkeypatch.setattr(sys, "platform", "win32")
    monkeypatch.setattr(_platform, "release", lambda: "10")
    monkeypatch.setattr(_platform, "version", lambda: "10.0.22621")

    rendered = _render_project_context(tmp_path)

    assert "OS Version: Windows 10 (10.0.22621)" in rendered
