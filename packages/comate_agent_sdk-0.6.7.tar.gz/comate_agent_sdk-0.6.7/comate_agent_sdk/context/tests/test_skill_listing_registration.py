"""SKILL_LISTING registry 一致性测试。"""

from __future__ import annotations

from comate_agent_sdk.context import ContextIR
from comate_agent_sdk.context.header.order import (
    SESSION_STATE_ITEM_ORDER,
    SESSION_STATE_ITEM_TYPES_IN_ORDER,
    STATIC_HEADER_ITEM_ORDER,
)
from comate_agent_sdk.context.info import _build_categories
from comate_agent_sdk.context.items import DEFAULT_PRIORITIES, ItemType
from comate_agent_sdk.context.offload import OffloadPolicy


def test_skill_listing_item_type_exists() -> None:
    assert ItemType.SKILL_LISTING.value == "skill_listing"


def test_skill_listing_priority_is_never_compressed() -> None:
    assert DEFAULT_PRIORITIES[ItemType.SKILL_LISTING] == 100


def test_skill_listing_in_session_state_order_after_output_style() -> None:
    assert ItemType.SKILL_LISTING in SESSION_STATE_ITEM_ORDER
    assert SESSION_STATE_ITEM_ORDER[ItemType.SKILL_LISTING] > SESSION_STATE_ITEM_ORDER[ItemType.OUTPUT_STYLE]
    assert ItemType.SKILL_LISTING in SESSION_STATE_ITEM_TYPES_IN_ORDER


def test_skill_listing_not_in_static_header_order() -> None:
    assert ItemType.SKILL_LISTING not in STATIC_HEADER_ITEM_ORDER


def test_skill_listing_offload_disabled() -> None:
    policy = OffloadPolicy()
    assert policy.type_enabled["skill_listing"] is False


def test_skill_listing_in_context_info_categories() -> None:
    ctx = ContextIR()
    ctx.set_skill_listing("LISTING_TEXT")

    status = ctx.get_budget_status()
    labels = {category.label for category in _build_categories(status.tokens_by_type, ctx)}

    assert "Skill Listing" in labels
