from __future__ import annotations

import pytest

from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import UserMessage


def test_header_snapshot_roundtrip_restores_only_header_items() -> None:
    """快照只持久化 static header 段；session_state（含 user_instruction）不纳入快照。"""
    source = ContextIR()
    source.set_system_prompt("SNAPSHOT_PROMPT", cache=False)
    source.set_memory_usage("SNAPSHOT_MEMORY_USAGE", cache=False)
    source.set_tool_strategy("SNAPSHOT_TOOL_STRATEGY")
    source.set_system_env("<system_env>SNAPSHOT_ENV</system_env>")
    source.set_output_style("<output_style>SNAPSHOT_STYLE</output_style>")
    source.set_user_instruction("SNAPSHOT_USER_INSTRUCTION", cache=False)

    snapshot = source.export_header_snapshot()

    restored = ContextIR()
    restored.import_header_snapshot(snapshot)

    prompt_item = restored.header.find_one_by_type(ItemType.SYSTEM_PROMPT)
    memory_usage_item = restored.header.find_one_by_type(ItemType.MEMORY_USAGE)
    tool_item = restored.header.find_one_by_type(ItemType.TOOL_STRATEGY)
    env_item = restored.session_state.find_one_by_type(ItemType.SYSTEM_ENV)
    style_item = restored.session_state.find_one_by_type(ItemType.OUTPUT_STYLE)
    assert prompt_item is not None
    assert memory_usage_item is not None
    assert tool_item is not None
    # session_state 在 resume 后被清空，由运行时重新注入
    assert env_item is None
    assert style_item is None
    assert prompt_item.content_text == "SNAPSHOT_PROMPT"
    assert memory_usage_item.content_text == "SNAPSHOT_MEMORY_USAGE"
    assert tool_item.content_text == "SNAPSHOT_TOOL_STRATEGY"
    # user_instruction 不纳入快照，由运行时重新注入（生命周期对齐）
    assert restored.user_instruction_item is None


def test_header_order_includes_memory_usage_between_system_prompt_and_tool_strategy() -> None:
    ctx = ContextIR()
    ctx.set_tool_strategy("TOOL")
    ctx.set_memory_usage("MEMORY_USAGE")
    ctx.set_system_prompt("SYSTEM")

    header_types = [item.item_type for item in ctx.header.items]
    assert header_types == [
        ItemType.SYSTEM_PROMPT,
        ItemType.MEMORY_USAGE,
        ItemType.TOOL_STRATEGY,
    ]


def test_header_snapshot_rejects_non_header_item() -> None:
    ctx = ContextIR()
    snapshot = {
        "schema_version": 1,
        "header_items": [
            {
                "item_type": "user_message",
                "message": None,
                "content_text": "bad",
                "token_count": 1,
                "priority": 50,
                "ephemeral": False,
                "destroyed": False,
                "tool_name": None,
                "created_at": 0.0,
                "metadata": {},
                "cache_hint": False,
                "offload_path": None,
                "offloaded": False,
                "is_tool_error": False,
                "created_turn": 0,
            }
        ],
        "user_instruction_item": None,
    }
    with pytest.raises(ValueError):
        ctx.import_header_snapshot(snapshot)


def test_header_snapshot_legacy_memory_item_silently_ignored() -> None:
    """旧版 schema（v2）中的 memory_item / user_instruction_item 字段被静默忽略，不报错。"""
    ctx = ContextIR()
    legacy_snapshot = {
        "schema_version": 1,
        "header_items": [],
        "memory_item": {
            "id": "legacy01",
            "item_type": "memory",
            "message": UserMessage(content="LEGACY_MEMORY", is_meta=True).model_dump(mode="json"),
            "content_text": "LEGACY_MEMORY",
            "token_count": 0,
            "priority": 100,
            "ephemeral": False,
            "destroyed": False,
            "tool_name": None,
            "created_at": 0.0,
            "metadata": {},
            "cache_hint": False,
            "offload_path": None,
            "offloaded": False,
            "is_tool_error": False,
            "created_turn": 0,
        },
    }

    # 不应抛出异常，旧字段静默忽略
    ctx.import_header_snapshot(legacy_snapshot)
    # user_instruction_item 不从快照恢复，由运行时刷新
    assert ctx.user_instruction_item is None


def test_project_context_position_in_static_header_order():
    """PROJECT_CONTEXT must sit immediately after SYSTEM_PROMPT and before TOOL_STRATEGY.

    语义：用户自定义的 system_prompt（含 subagent 的 prompt）先建立身份，
    随后立刻给出空间坐标（project_context），再进入工具/策略说明。
    """
    from comate_agent_sdk.context.header.order import (
        STATIC_HEADER_ITEM_ORDER,
        STATIC_HEADER_ITEM_TYPES_IN_ORDER,
    )
    from comate_agent_sdk.context.items import ItemType

    assert ItemType.PROJECT_CONTEXT in STATIC_HEADER_ITEM_ORDER
    assert STATIC_HEADER_ITEM_TYPES_IN_ORDER[0] == ItemType.SYSTEM_PROMPT
    assert STATIC_HEADER_ITEM_TYPES_IN_ORDER[1] == ItemType.PROJECT_CONTEXT

    pc_idx = STATIC_HEADER_ITEM_TYPES_IN_ORDER.index(ItemType.PROJECT_CONTEXT)
    ts_idx = STATIC_HEADER_ITEM_TYPES_IN_ORDER.index(ItemType.TOOL_STRATEGY)
    assert pc_idx < ts_idx, "project_context must precede tool_strategy"


def test_set_project_context_adds_header_item():
    """set_project_context should add a PROJECT_CONTEXT item to the header segment."""
    from comate_agent_sdk.context.ir import ContextIR
    from comate_agent_sdk.context.items import ItemType

    ctx = ContextIR()
    ctx.set_project_context("<project_context>\nworking_directory: /tmp/test\n</project_context>")

    item = ctx.header.find_one_by_type(ItemType.PROJECT_CONTEXT)
    assert item is not None
    assert "working_directory: /tmp/test" in item.content_text


def test_header_snapshot_includes_project_context():
    """export/import roundtrip should preserve PROJECT_CONTEXT."""
    from comate_agent_sdk.context.ir import ContextIR
    from comate_agent_sdk.context.items import ItemType

    ctx = ContextIR()
    ctx.set_project_context("<project_context>\nworking_directory: /tmp/test\nis_git_repo: true\n</project_context>")
    ctx.set_system_prompt("You are a test agent.")

    snapshot = ctx.export_header_snapshot()
    item_types = [item["item_type"] for item in snapshot["header_items"]]
    assert "project_context" in item_types

    ctx2 = ContextIR()
    ctx2.import_header_snapshot(snapshot)
    restored = ctx2.header.find_one_by_type(ItemType.PROJECT_CONTEXT)
    assert restored is not None
    assert "working_directory: /tmp/test" in restored.content_text


def test_project_context_prompt_renders_correctly() -> None:
    """project_context.md template should render with working_directory, is_git_repo, and bash/shell 三件套."""
    from comate_agent_sdk.prompts import load_prompt, render_prompt

    template = load_prompt("agent/project_context.md")
    rendered = render_prompt(
        template,
        variables={
            "WORKING_DIRECTORY": "/home/user/project",
            "IS_GIT_REPO": "true",
            "PLATFORM": "linux",
            "OS_VERSION": "Linux 6.17.0-14-generic",
            "SHELL": "bash",
        },
        source="agent/project_context.md",
    )
    assert "<project_context>" in rendered
    assert "working_directory: /home/user/project" in rendered
    assert "is_git_repo: true" in rendered
    assert "platform: linux" in rendered
    assert "OS Version: Linux 6.17.0-14-generic" in rendered
    assert "Shell: bash" in rendered
    assert "All relative paths are resolved against this working directory." in rendered
    assert "</project_context>" in rendered
    # 模板内不应残留未替换的 {{VAR}} 占位符
    assert "{{" not in rendered
    assert "}}" not in rendered


def test_import_header_snapshot_rejects_legacy_skill_strategy_with_skills_block() -> None:
    """旧 skill_strategy snapshot 含 <skills> listing 时必须 fail fast，不做兼容迁移。"""
    ctx = ContextIR()
    legacy = ContextIR()
    legacy.set_system_prompt("SYS", cache=False)
    legacy.set_skill_strategy(
        "<skills>\n- demo: old listing\n</skills>\n\n"
        "<skill_use>\n- old usage\n</skill_use>"
    )

    snapshot = legacy.export_header_snapshot()

    with pytest.raises(ValueError, match="legacy skill_strategy snapshot contains <skills>"):
        ctx.import_header_snapshot(snapshot)
