"""spec §5.1 + §7.4：MCP_TOOL 是 session_state，不能进入 header_snapshot。"""
from __future__ import annotations

import pytest

from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import UserMessage


def test_mcp_tool_session_state_is_not_exported_to_header_snapshot() -> None:
    ctx = ContextIR()
    ctx.set_system_prompt("SYSTEM", cache=False)
    ctx.set_mcp_tools(
        "<mcp_tools>\n# MCP Server Instructions\n\n## srv\n用法\n</mcp_tools>"
    )

    snapshot = ctx.export_header_snapshot()
    item_types = [item["item_type"] for item in snapshot["header_items"]]
    assert ItemType.MCP_TOOL.value not in item_types


def test_header_snapshot_rejects_mcp_tool_item() -> None:
    ctx = ContextIR()
    snapshot = {
        "schema_version": 3,
        "header_items": [
            {
                "id": "mcp00001",
                "item_type": ItemType.MCP_TOOL.value,
                "message": UserMessage(
                    content=(
                        "<mcp_tools>\n# MCP Server Instructions\n\n"
                        "## srv\n用法\n</mcp_tools>"
                    ),
                    is_meta=True,
                ).model_dump(mode="json"),
                "content_text": (
                    "<mcp_tools>\n# MCP Server Instructions\n\n"
                    "## srv\n用法\n</mcp_tools>"
                ),
                "token_count": 0,
                "priority": 94,
                "ephemeral": False,
                "destroyed": False,
                "tool_name": None,
                "created_at": 0.0,
                "metadata": {},
                "cache_hint": False,
                "offload_path": None,
                "offloaded": False,
                "is_tool_error": False,
                "created_turn": 0,
            }
        ],
    }

    with pytest.raises(ValueError, match="unsupported header item_type"):
        ctx.import_header_snapshot(snapshot)
