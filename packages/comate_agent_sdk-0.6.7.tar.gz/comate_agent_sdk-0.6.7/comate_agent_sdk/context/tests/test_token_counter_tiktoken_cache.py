from __future__ import annotations

import os
import tempfile
from importlib import import_module
from pathlib import Path

import pytest

from comate_agent_sdk.context.budget import TokenCounter


def test_token_counter_uses_packaged_cl100k_cache_without_network(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.delenv("TIKTOKEN_CACHE_DIR", raising=False)
    monkeypatch.delenv("DATA_GYM_CACHE_DIR", raising=False)
    monkeypatch.setattr(tempfile, "gettempdir", lambda: str(tmp_path))

    pytest.importorskip("tiktoken")
    tiktoken_load = import_module("tiktoken.load")
    tiktoken_registry = import_module("tiktoken.registry")

    tiktoken_registry.ENCODINGS.pop("cl100k_base", None)
    original_read_file = tiktoken_load.read_file

    def read_file_without_http(blobpath: str) -> bytes:
        if "://" in blobpath:
            raise AssertionError(f"unexpected network tokenizer fetch: {blobpath}")
        return original_read_file(blobpath)

    monkeypatch.setattr(tiktoken_load, "read_file", read_file_without_http)

    assert TokenCounter().count("hello world") > 0

    assert "TIKTOKEN_CACHE_DIR" not in os.environ
    assert os.path.isfile(os.path.join(tmp_path, "data-gym-cache", "9b5ad71b2ce5302211f9c61530b329a4922fc6a4"))


def test_token_counter_falls_back_when_tiktoken_init_fails(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    tiktoken = pytest.importorskip("tiktoken")

    def raise_runtime_error(_encoding_name: str) -> object:
        raise RuntimeError("network unavailable")

    monkeypatch.setattr(tiktoken, "get_encoding", raise_runtime_error)

    text = "abcdefghi"

    with caplog.at_level("WARNING", logger="comate_agent_sdk.context.budget"):
        assert TokenCounter().count(text) == 3

    assert "初始化 tiktoken cl100k_base 编码失败" in caplog.text
