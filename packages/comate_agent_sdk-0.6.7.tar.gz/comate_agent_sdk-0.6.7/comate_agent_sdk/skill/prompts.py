"""Skill prompt helpers（usage guide 与 listing 分离）。"""

from __future__ import annotations

from comate_agent_sdk.prompts import load_prompt
from comate_agent_sdk.skill.models import SkillDefinition

MAX_LISTING_DESC_CHARS = 250
LISTING_OPENING_LINE = "The following skills are available for use with the Skill tool:"


def _listing_description(skill: SkillDefinition) -> str:
    description = skill.description
    if skill.when_to_use:
        description = f"{description} - {skill.when_to_use}"
    if len(description) > MAX_LISTING_DESC_CHARS:
        return f"{description[: MAX_LISTING_DESC_CHARS - 3]}..."
    return description


def generate_skill_usage_guide() -> str:
    """返回 SDK 内置 skill 行为指南。"""
    return load_prompt("skill/usage_guide.md")


def generate_skill_listing(skills: list[SkillDefinition]) -> str:
    """生成 skill listing 纯文本；<system-reminder> 包裹由 lowering 添加。"""
    active_skills = [s for s in skills if not s.disable_model_invocation]
    if not active_skills:
        return ""

    lines = [f"- {skill.name}: {_listing_description(skill)}" for skill in active_skills]
    return f"{LISTING_OPENING_LINE}\n\n" + "\n".join(lines)
