"""Skill 自动发现和加载"""

import logging
from pathlib import Path

from comate_agent_sdk.skill.models import SkillDefinition
from comate_agent_sdk.utils.paths import PathInput, normalize_path_input

logger = logging.getLogger(__name__)


def discover_skills(project_root: PathInput | None = None) -> list[SkillDefinition]:
    """自动发现所有 Skill

    扫描路径（优先级从高到低）：
    1. {project_root}/.agent/skills/
    2. {project_root}/.claude/skills/
    3. ~/.agent/skills/
    4. ~/.claude/skills/

    支持两种格式：
    - .agent/skills: 单个目录或一层 namespace（兼容 Comate 历史格式）
    - .claude/skills: skill-name/SKILL.md（一层扫描，对齐 Claude Code）

    注意：
    - 前面的目录会覆盖后面的同名 skills
    - 跳过 disable_model_invocation=True 的 skills（在 create_skill_tool 中过滤）
    """
    project_root = normalize_path_input(
        project_root if project_root is not None else Path.cwd(),
        field_name="project_root",
    )

    scan_roots = [
        (project_root / ".agent" / "skills", True),
        (project_root / ".claude" / "skills", False),
        (Path.home() / ".agent" / "skills", True),
        (Path.home() / ".claude" / "skills", False),
    ]

    skills: list[SkillDefinition] = []
    seen_names: set[str] = set()

    for skill_dir, allow_namespace in scan_roots:
        if not skill_dir.exists():
            continue

        _load_skills_from_root(
            skill_dir,
            skills=skills,
            seen_names=seen_names,
            allow_namespace=allow_namespace,
        )

    return skills


def _append_skill(
    skill_dir: Path,
    *,
    skills: list[SkillDefinition],
    seen_names: set[str],
    namespace: str | None = None,
    use_frontmatter_name: bool = True,
) -> None:
    try:
        skill = SkillDefinition.from_directory(
            skill_dir,
            namespace=namespace,
            use_frontmatter_name=use_frontmatter_name,
        )
        if skill.name in seen_names:
            logger.info(f"Skipping duplicate skill '{skill.name}' from {skill_dir}")
            return
        skills.append(skill)
        seen_names.add(skill.name)
        logger.info(f"Loaded skill '{skill.name}' from {skill_dir}")
    except Exception as e:
        logger.warning(f"Failed to load skill from {skill_dir}: {e}")


def _load_skills_from_root(
    skill_dir: Path,
    *,
    skills: list[SkillDefinition],
    seen_names: set[str],
    allow_namespace: bool,
) -> None:
    for item in sorted(skill_dir.iterdir()):
        if not item.is_dir():
            continue

        if (item / "SKILL.md").exists():
            _append_skill(
                item,
                skills=skills,
                seen_names=seen_names,
                use_frontmatter_name=allow_namespace,
            )
            continue

        if not allow_namespace:
            continue

        namespace = item.name
        for sub_item in sorted(item.iterdir()):
            if not sub_item.is_dir():
                continue
            if not (sub_item / "SKILL.md").exists():
                continue
            _append_skill(
                sub_item,
                skills=skills,
                seen_names=seen_names,
                namespace=namespace,
            )
