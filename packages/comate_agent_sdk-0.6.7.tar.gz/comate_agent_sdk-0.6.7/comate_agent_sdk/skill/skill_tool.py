"""Skill Meta-Tool 实现

设计决策：
- Tool description 只包含简洁的功能说明
- Skills 列表通过独立的 system-reminder meta user message 注入
- 行为指南放在 system_prompt 中，避免把详细使用规则塞进 Tool description
"""

import logging

from comate_agent_sdk.skill.models import SkillDefinition
from comate_agent_sdk.tools import Tool, tool

logger = logging.getLogger(__name__)


def create_skill_tool(skills: list[SkillDefinition]) -> Tool:
    """创建 Skill meta-tool（简洁版）

    Tool description 只包含简洁的功能说明。
    Skills 列表通过独立 system-reminder 注入，行为指南通过 system_prompt 注入。

    Args:
        skills: Skill 定义列表（用于日志记录，实际列表在 system_prompt 中）

    Returns:
        Skill 工具实例
    """
    # 过滤掉 disable_model_invocation=True 的 skills（仅用于日志）
    active_skills = [s for s in skills if not s.disable_model_invocation]
    logger.debug(f"Creating Skill tool with {len(active_skills)} active skill(s)")

    skill_usage_rule = """Execute a skill within the main conversation.

When users ask you to perform tasks, check if any available skills match.
Skills provide specialized capabilities, workflows, and domain knowledge.

How to invoke:
- Use this tool with the skill name and optional args
- Examples:
  - skill="pdf" - invoke the pdf skill
  - skill="commit", args="-m 'Fix bug'" - invoke with arguments
  - skill="ms-office-suite:pdf" - invoke using a fully qualified name

Important:
- Available skills are listed in system-reminder messages in the conversation.
- When a skill matches the user's request, call this tool before generating a task answer.
- When users reference "/<something>" (for example "/commit"), they may be referring to a user-invocable skill. Use this tool for matching skills listed in the system-reminder skill listing.
- If you see a <command-name>/skill-name</command-name> marker in the current turn, that skill has already been loaded by a user slash command. Follow the injected skill instructions directly instead of calling this tool again.
- Do not guess skill names that are not listed.
    """

    # 简洁的工具描述（详细使用规则在 system_prompt 中）
    description = "Execute a listed skill and inject its full instructions before continuing."

    @tool(description, name="Skill", usage_rules=skill_usage_rule)
    async def Skill(skill: str, args: str | None = None) -> str:
        """调用 Skill

        Args:
            skill: Skill 名称
            args: Optional arguments passed to the skill.
        """
        # 实际执行逻辑在 Agent._execute_skill_call() 中
        _ = args
        return f"Skill '{skill}' loaded"

    return Skill
