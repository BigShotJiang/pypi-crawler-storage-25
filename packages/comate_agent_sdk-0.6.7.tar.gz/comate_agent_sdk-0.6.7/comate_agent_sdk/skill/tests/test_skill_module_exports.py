from __future__ import annotations


def test_new_exports_available() -> None:
    from comate_agent_sdk.skill import (
        generate_skill_listing,
        generate_skill_usage_guide,
    )

    assert callable(generate_skill_listing)
    assert callable(generate_skill_usage_guide)


def test_legacy_export_removed() -> None:
    import comate_agent_sdk.skill as skill_mod

    assert not hasattr(skill_mod, "generate_" + "skill_prompt")
