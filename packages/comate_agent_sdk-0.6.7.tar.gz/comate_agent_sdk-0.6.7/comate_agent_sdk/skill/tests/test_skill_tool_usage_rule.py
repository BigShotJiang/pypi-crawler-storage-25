from __future__ import annotations

from comate_agent_sdk.skill import create_skill_tool
from comate_agent_sdk.skill.models import SkillDefinition


def _get_usage_rule() -> str:
    tool = create_skill_tool(
        [SkillDefinition(name="demo", description="d", prompt="p")]
    )
    return tool.usage_rules


def test_usage_rule_references_system_reminder_messages() -> None:
    text = _get_usage_rule()
    assert "Available skills are listed in system-reminder messages in the conversation" in text


def test_usage_rule_does_not_reference_old_system_prompt_phrasing() -> None:
    text = _get_usage_rule()
    assert (
        "Available skills are listed in the system "
        + "prompt "
        + "under "
        + "<skills>"
    ) not in text
    assert ("listed under " + "<skills>") not in text


def test_usage_rule_keeps_do_not_guess_clause() -> None:
    assert "Do not guess skill names that are not listed" in _get_usage_rule()
