from __future__ import annotations

import unittest
from pathlib import Path

from comate_agent_sdk.skill.models import SkillDefinition


class TestSkillDefinition(unittest.TestCase):
    def test_from_markdown_supports_quoted_description(self) -> None:
        skill = SkillDefinition.from_markdown(
            content=(
                "---\n"
                "name: xlsx\n"
                'description: "Specialized spreadsheet workflow."\n'
                "---\n"
                "\n"
                "Use openpyxl."
            ),
            dir_name="xlsx",
            base_dir=Path("/tmp/xlsx"),
        )

        self.assertEqual(skill.name, "xlsx")
        self.assertEqual(skill.description, "Specialized spreadsheet workflow.")
        self.assertEqual(skill.prompt, "Use openpyxl.")

    def test_from_markdown_supports_legacy_double_dash_closing_fence(self) -> None:
        skill = SkillDefinition.from_markdown(
            content=(
                "---\n"
                "name: xlsx\n"
                'description: "Specialized spreadsheet workflow."\n'
                "--\n"
                "\n"
                "Use openpyxl."
            ),
            dir_name="xlsx",
            base_dir=Path("/tmp/xlsx"),
        )

        self.assertEqual(skill.name, "xlsx")
        self.assertEqual(skill.description, "Specialized spreadsheet workflow.")
        self.assertEqual(skill.prompt, "Use openpyxl.")
        self.assertNotIn("name: xlsx", skill.description)

    def test_from_markdown_supports_legacy_frontmatter_without_opening_fence(self) -> None:
        skill = SkillDefinition.from_markdown(
            content=(
                "name: xlsx\n"
                'description: "Specialized spreadsheet workflow."\n'
                "--\n"
                "\n"
                "Use openpyxl."
            ),
            dir_name="xlsx",
            base_dir=Path("/tmp/xlsx"),
        )

        self.assertEqual(skill.name, "xlsx")
        self.assertEqual(skill.description, "Specialized spreadsheet workflow.")
        self.assertEqual(skill.prompt, "Use openpyxl.")


    def test_from_markdown_with_namespace_uses_prefix(self) -> None:
        """namespace 参数应拼接 namespace:dir_name 作为最终名称"""
        skill = SkillDefinition.from_markdown(
            content=(
                "---\n"
                "description: test skill\n"
                "---\n"
                "\n"
                "Do something."
            ),
            dir_name="executing-plans",
            base_dir=Path("/tmp/executing-plans"),
            namespace="superpowers",
        )
        self.assertEqual(skill.name, "superpowers:executing-plans")

    def test_from_markdown_with_namespace_frontmatter_overrides_short_name(self) -> None:
        """namespace 由目录决定，frontmatter name 只覆盖短名部分"""
        skill = SkillDefinition.from_markdown(
            content=(
                "---\n"
                "name: my-custom-name\n"
                "description: test skill\n"
                "---\n"
                "\n"
                "Do something."
            ),
            dir_name="executing-plans",
            base_dir=Path("/tmp/executing-plans"),
            namespace="superpowers",
        )
        self.assertEqual(skill.name, "superpowers:my-custom-name")

    def test_from_markdown_without_namespace_unchanged(self) -> None:
        """namespace=None 时行为不变（向后兼容）"""
        skill = SkillDefinition.from_markdown(
            content=(
                "---\n"
                "name: my-skill\n"
                "description: test skill\n"
                "---\n"
                "\n"
                "Do something."
            ),
            dir_name="my-skill",
            base_dir=Path("/tmp/my-skill"),
        )
        self.assertEqual(skill.name, "my-skill")

    def test_from_markdown_parses_claude_skill_fields(self) -> None:
        skill = SkillDefinition.from_markdown(
            content=(
                "---\n"
                "description: commit workflow\n"
                "when_to_use: When preparing a git commit.\n"
                "arguments: message files\n"
                "user-invocable: false\n"
                "disable-model-invocation: false\n"
                "---\n"
                "\n"
                "Commit with $message and $files."
            ),
            dir_name="commit",
            base_dir=Path("/tmp/commit"),
        )

        self.assertEqual(skill.when_to_use, "When preparing a git commit.")
        self.assertEqual(skill.argument_names, ("message", "files"))
        self.assertFalse(skill.user_invocable)
        self.assertFalse(skill.disable_model_invocation)

    def test_get_prompt_adds_claude_base_dir_and_replaces_variables(self) -> None:
        skill = SkillDefinition(
            name="demo",
            description="demo",
            prompt=(
                "Read ${CLAUDE_SKILL_DIR}/references/x.md in "
                "${CLAUDE_SESSION_ID}; legacy {baseDir}."
            ),
            base_dir=Path("/tmp/demo"),
        )

        prompt = skill.get_prompt(session_id="session-123")

        self.assertIn("Base directory for this skill: /tmp/demo\n\n", prompt)
        self.assertIn("/tmp/demo/references/x.md", prompt)
        self.assertIn("session-123", prompt)
        self.assertIn("legacy /tmp/demo", prompt)

    def test_get_prompt_substitutes_arguments(self) -> None:
        skill = SkillDefinition(
            name="demo",
            description="demo",
            prompt="Full=$ARGUMENTS first=$0 second=$ARGUMENTS[1] named=$target",
            argument_names=("target",),
        )

        prompt = skill.get_prompt(args='"hello world" file.py')

        self.assertEqual(
            prompt,
            'Full="hello world" file.py first=hello world second=file.py named=hello world',
        )

    def test_get_prompt_appends_arguments_when_no_placeholder_exists(self) -> None:
        skill = SkillDefinition(
            name="demo",
            description="demo",
            prompt="Run the workflow.",
        )

        self.assertEqual(
            skill.get_prompt(args="--all"),
            "Run the workflow.\n\nARGUMENTS: --all",
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
