from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING
from typing import Literal

from comate_agent_sdk.llm.messages import ToolCall, ToolMessage, UserMessage

logger = logging.getLogger("comate_agent_sdk.agent")

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime


@dataclass(frozen=True, slots=True)
class SkillInvocationResult:
    success: bool
    message: str
    skill_name: str | None = None


async def invoke_skill_by_name(
    agent: "AgentRuntime",
    skill_name: str,
    *,
    args: str | None = None,
    invocation_source: Literal["user_slash", "model_tool"] = "user_slash",
    flush: bool = True,
) -> SkillInvocationResult:
    """按名称调用 Skill，并将完整 prompt 注入 ContextIR。"""
    normalized_name = str(skill_name or "").strip()
    if normalized_name.startswith("/"):
        normalized_name = normalized_name[1:]
    normalized_args = args if args is None or isinstance(args, str) else str(args)

    skill_def = (
        next((s for s in agent._runtime_state.skills if s.name == normalized_name), None)
        if agent._runtime_state.skills
        else None
    )
    if not skill_def:
        return SkillInvocationResult(
            success=False,
            message=f"Unknown Skill '{normalized_name}'",
            skill_name=normalized_name or None,
        )

    if invocation_source == "user_slash" and not bool(
        getattr(skill_def, "user_invocable", True)
    ):
        return SkillInvocationResult(
            success=False,
            message=f"Skill '{normalized_name}' is not user-invocable",
            skill_name=normalized_name,
        )

    if invocation_source == "model_tool" and bool(
        getattr(skill_def, "disable_model_invocation", False)
    ):
        return SkillInvocationResult(
            success=False,
            message=f"Skill '{normalized_name}' is disabled for model invocation",
            skill_name=normalized_name,
        )

    full_prompt = skill_def.get_prompt(
        args=normalized_args,
        session_id=getattr(agent, "_session_id", None),
    )
    agent._context.add_skill_injection(
        skill_name=normalized_name,
        prompt_msg=UserMessage(content=full_prompt, is_meta=True),
    )
    if flush:
        agent._context.flush_pending_skill_items()

    return SkillInvocationResult(
        success=True,
        message=f"Skill '{normalized_name}' loaded successfully and will remain active",
        skill_name=normalized_name,
    )


async def execute_skill_call(agent: "AgentRuntime", tool_call: ToolCall) -> ToolMessage:
    """执行 Skill 调用（特殊处理）。"""
    parsed_args = json.loads(tool_call.function.arguments)
    skill_name = parsed_args.get("skill") or parsed_args.get("skill_name")
    skill_args = parsed_args.get("args")
    if skill_args is not None and not isinstance(skill_args, str):
        skill_args = str(skill_args)

    result = await invoke_skill_by_name(
        agent,
        str(skill_name or ""),
        args=skill_args,
        invocation_source="model_tool",
        flush=False,
    )
    if not result.success:
        return ToolMessage(
            tool_call_id=tool_call.id,
            tool_name="Skill",
            content=f"Error: {result.message}",
            is_error=True,
        )

    # 返回 ToolMessage（调用方会先添加这个，再 flush pending items）
    return ToolMessage(
        tool_call_id=tool_call.id,
        tool_name="Skill",
        content=result.message,
        is_error=False,
    )


def rebuild_skill_tool(agent: "AgentRuntime") -> None:
    """重建 Skill 工具（用于 Subagent Skills 筛选后更新工具描述）。"""
    from comate_agent_sdk.agent.tool_visibility import effective_enabled_tool_names
    from comate_agent_sdk.skill import (
        create_skill_tool,
        generate_skill_listing,
        generate_skill_usage_guide,
    )

    # 1. 移除旧的 Skill 工具
    agent._runtime_state.tools[:] = [t for t in agent._runtime_state.tools if t.name != "Skill"]
    agent._tool_map.pop("Skill", None)

    # 2. 移除 IR 中的旧 Skill 策略与 listing
    agent._context.remove_skill_strategy()
    agent._context.remove_skill_listing()

    # 3. 如果还有 skills，重新生成
    if agent._runtime_state.skills:
        skill_tool = create_skill_tool(agent._runtime_state.skills)
        agent._runtime_state.tools.append(skill_tool)
        agent._tool_map["Skill"] = skill_tool

        enabled = effective_enabled_tool_names(
            agent._runtime_state.tools,
            is_subagent=bool(agent._is_subagent),
            is_team_member=bool(agent.is_team_member),
            disallowed_tools=agent.config.disallowed_tools,
        )
        if "Skill" in enabled:
            agent._context.set_skill_strategy(generate_skill_usage_guide())
            listing = generate_skill_listing(agent._runtime_state.skills)
            if listing:
                agent._context.set_skill_listing(listing)
        elif "Skill" not in enabled:
            logger.warning("Skip skill_strategy/listing injection because Skill is not enabled")

        logger.debug(f"Rebuilt Skill tool with {len(agent._runtime_state.skills)} skill(s)")
    else:
        logger.debug("Removed Skill tool (no skills remaining)")


def remove_skill_strategy(agent: "AgentRuntime") -> None:
    """辅助函数：仅移除 skill_strategy（用于调试/外部调用）。"""
    agent._context.remove_skill_strategy()
