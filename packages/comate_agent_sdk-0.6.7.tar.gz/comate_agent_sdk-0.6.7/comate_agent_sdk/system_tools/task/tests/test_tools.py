from __future__ import annotations

import asyncio
import json
from unittest.mock import AsyncMock, patch

from comate_agent_sdk.system_tools.output_formatter import OutputFormatter
from comate_agent_sdk.system_tools.task import TaskStore
from comate_agent_sdk.system_tools.task.timing import DEFAULT_TASKLIST_TEAM_BLOCK_SECONDS
from comate_agent_sdk.system_tools.task.tools import TaskCreate, TaskGet, TaskList, TaskUpdate
from comate_agent_sdk.tools.system_context import bind_system_tool_context


def _parse(raw: str) -> dict:
    return json.loads(raw)


def test_task_create_definition_matches_schema_contract() -> None:
    schema = TaskCreate.definition.parameters

    assert schema["type"] == "object"
    assert schema["additionalProperties"] is False
    assert schema["required"] == ["subject"]
    assert schema["properties"]["subject"]["type"] == "string"
    assert schema["properties"]["subject"]["minLength"] == 1
    assert (
        schema["properties"]["subject"]["description"]
        == "Brief actionable title in imperative form"
    )
    assert (
        schema["properties"]["description"]["description"]
        == "Detailed description with context and acceptance criteria"
    )
    assert (
        schema["properties"]["owner"]["description"]
        == "Assignee name. In Team mode, prefer leaving empty and assigning later."
    )
    assert "blocked_by" not in schema["properties"]
    assert "metadata" not in schema["properties"]


def test_task_tools_flow(tmp_path) -> None:
    asyncio.run(_test_task_tools_flow(tmp_path))


async def _test_task_tools_flow(tmp_path) -> None:
    store = TaskStore(store_dir=tmp_path / "tasks", list_id="shared")
    with bind_system_tool_context(project_root=tmp_path, task_store=store):
        created = _parse(
            await TaskCreate.execute(
                subject="Set up store",
                description="Create the persistent store wiring for the shared task list.",
            )
        )
        assert created["ok"]
        assert created["data"]["task"]["id"] == "1"
        assert created["data"]["list_id"] == "shared"
        assert (
            created["data"]["task"]["description"]
            == "Create the persistent store wiring for the shared task list."
        )

        listed = _parse(await TaskList.execute())
        assert listed["ok"]
        assert listed["data"]["total"] == 1
        assert (
            listed["data"]["tasks"][0]["description"]
            == "Create the persistent store wiring for the shared task list."
        )

        updated = _parse(await TaskUpdate.execute(task_id="1", status="in_progress", owner="agent-a"))
        assert updated["ok"]
        assert updated["data"]["task"]["status"] == "in_progress"
        assert updated["data"]["task"]["owner"] == "agent-a"

        details = _parse(await TaskGet.execute(task_id="1"))
        assert details["ok"]
        assert details["data"]["task"]["subject"] == "Set up store"


def test_task_tools_accept_prefixed_task_ids(tmp_path) -> None:
    asyncio.run(_test_task_tools_accept_prefixed_task_ids(tmp_path))


async def _test_task_tools_accept_prefixed_task_ids(tmp_path) -> None:
    store = TaskStore(store_dir=tmp_path / "tasks", list_id="prefixed")
    with bind_system_tool_context(project_root=tmp_path, task_store=store):
        _parse(await TaskCreate.execute(subject="A"))
        _parse(await TaskCreate.execute(subject="B"))
        dep_result = _parse(await TaskUpdate.execute(task_id="2", add_blocked_by=["#1"]))
        assert dep_result["ok"]
        assert dep_result["data"]["task"]["blocked_by"] == ["1"]

        fetched = _parse(await TaskGet.execute(task_id="task-2"))
        assert fetched["ok"]
        assert fetched["data"]["task"]["id"] == "2"

        _parse(await TaskCreate.execute(subject="C"))
        _parse(await TaskCreate.execute(subject="D"))

        updated = _parse(await TaskUpdate.execute(task_id="#2", add_blocked_by=[" TASK-3 "]))
        assert updated["ok"]
        assert updated["data"]["task"]["blocked_by"] == ["1", "3"]

        reverse = _parse(await TaskUpdate.execute(task_id="#2", add_blocks=["task-4"]))
        assert reverse["ok"]
        fourth = store.get_task("4")
        assert fourth is not None
        assert fourth.blocked_by == ["2"]


def test_task_formatter_surfaces_owner_for_agent_consumption(tmp_path) -> None:
    asyncio.run(_test_task_formatter_surfaces_owner_for_agent_consumption(tmp_path))


async def _test_task_formatter_surfaces_owner_for_agent_consumption(tmp_path) -> None:
    store = TaskStore(store_dir=tmp_path / "tasks", list_id="shared")
    with bind_system_tool_context(project_root=tmp_path, task_store=store):
        _parse(await TaskCreate.execute(subject="Review task ownership"))
        listed = _parse(
            await TaskUpdate.execute(task_id="1", status="in_progress", owner="andy")
        )
        details = _parse(await TaskGet.execute(task_id="1"))

    formatted_list = OutputFormatter.format(
        tool_name="TaskUpdate",
        tool_call_id="tc_task_update_owner",
        result_dict=listed,
    )
    formatted_get = OutputFormatter.format(
        tool_name="TaskGet",
        tool_call_id="tc_task_get_owner",
        result_dict=details,
    )

    assert "Owner: andy" in formatted_get.text
    assert "owner=andy" in formatted_list.text


# P2: TaskCreate explicit owner

def test_task_create_with_explicit_owner(tmp_path) -> None:
    asyncio.run(_test_task_create_with_explicit_owner(tmp_path))


async def _test_task_create_with_explicit_owner(tmp_path) -> None:
    store = TaskStore(store_dir=tmp_path / "tasks", list_id="p2")
    with bind_system_tool_context(project_root=tmp_path, task_store=store):
        result = _parse(await TaskCreate.execute(subject="Task A", owner="lead-agent"))
        assert result["ok"]
        assert result["data"]["task"]["owner"] == "lead-agent"


def test_task_create_fallback_owner(tmp_path) -> None:
    asyncio.run(_test_task_create_fallback_owner(tmp_path))


async def _test_task_create_fallback_owner(tmp_path) -> None:
    store = TaskStore(store_dir=tmp_path / "tasks", list_id="p2b")
    with bind_system_tool_context(project_root=tmp_path, task_store=store, session_id="sess-123"):
        result = _parse(await TaskCreate.execute(subject="Task B"))
        assert result["ok"]
        assert result["data"]["task"]["owner"] == "sess-123"


def test_task_create_team_mode_defaults_owner_empty(tmp_path) -> None:
    asyncio.run(_test_task_create_team_mode_defaults_owner_empty(tmp_path))


async def _test_task_create_team_mode_defaults_owner_empty(tmp_path) -> None:
    store = TaskStore(store_dir=tmp_path / "tasks", list_id="review-team")
    with bind_system_tool_context(
        project_root=tmp_path,
        task_store=store,
        session_id="sess-team",
        team_name="review-team",
        subagent_name="worker-1",
    ):
        result = _parse(await TaskCreate.execute(subject="Task C"))
        assert result["ok"]
        assert result["data"]["task"]["owner"] == ""


def test_task_update_team_mode_claims_owner(tmp_path) -> None:
    asyncio.run(_test_task_update_team_mode_claims_owner(tmp_path))


async def _test_task_update_team_mode_claims_owner(tmp_path) -> None:
    store = TaskStore(store_dir=tmp_path / "tasks", list_id="review-team")
    with bind_system_tool_context(
        project_root=tmp_path,
        task_store=store,
        session_id="sess-team",
        team_name="review-team",
    ):
        _parse(await TaskCreate.execute(subject="Task D"))
        result = _parse(
            await TaskUpdate.execute(task_id="1", status="in_progress", owner="worker-1")
        )
        assert result["ok"]
        assert result["data"]["task"]["owner"] == "worker-1"


def test_task_list_team_mode_blocks_for_five_seconds(tmp_path) -> None:
    asyncio.run(_test_task_list_team_mode_blocks_for_five_seconds(tmp_path))


async def _test_task_list_team_mode_blocks_for_five_seconds(tmp_path) -> None:
    store = TaskStore(store_dir=tmp_path / "tasks", list_id="review-team")
    with bind_system_tool_context(
        project_root=tmp_path,
        task_store=store,
        session_id="sess-team",
        team_name="review-team",
        subagent_name="worker-1",
    ):
        _parse(await TaskCreate.execute(subject="Task E"))
        with patch(
            "comate_agent_sdk.system_tools.task.tools.asyncio.sleep",
            new_callable=AsyncMock,
        ) as sleep_mock:
            listed = _parse(await TaskList.execute())

    assert listed["ok"]
    sleep_mock.assert_awaited_once_with(DEFAULT_TASKLIST_TEAM_BLOCK_SECONDS)


def test_task_list_non_team_mode_does_not_block(tmp_path) -> None:
    asyncio.run(_test_task_list_non_team_mode_does_not_block(tmp_path))


async def _test_task_list_non_team_mode_does_not_block(tmp_path) -> None:
    store = TaskStore(store_dir=tmp_path / "tasks", list_id="shared")
    with bind_system_tool_context(project_root=tmp_path, task_store=store):
        _parse(await TaskCreate.execute(subject="Task F"))
        with patch(
            "comate_agent_sdk.system_tools.task.tools.asyncio.sleep",
            new_callable=AsyncMock,
        ) as sleep_mock:
            listed = _parse(await TaskList.execute())

    assert listed["ok"]
    sleep_mock.assert_not_awaited()


def test_task_list_team_mode_uses_configured_block_seconds(tmp_path) -> None:
    asyncio.run(_test_task_list_team_mode_uses_configured_block_seconds(tmp_path))


async def _test_task_list_team_mode_uses_configured_block_seconds(tmp_path) -> None:
    store = TaskStore(store_dir=tmp_path / "tasks", list_id="review-team")
    with patch.dict("os.environ", {"COMATE_TASKLIST_TEAM_BLOCK_SECONDS": "1.25"}):
        with bind_system_tool_context(
            project_root=tmp_path,
            task_store=store,
            session_id="sess-team",
            team_name="review-team",
            subagent_name="worker-1",
        ):
            _parse(await TaskCreate.execute(subject="Task G"))
            with patch(
                "comate_agent_sdk.system_tools.task.tools.asyncio.sleep",
                new_callable=AsyncMock,
            ) as sleep_mock:
                listed = _parse(await TaskList.execute())

    assert listed["ok"]
    sleep_mock.assert_awaited_once_with(1.25)


# P3: TaskUpdate delete

def test_task_delete_via_update(tmp_path) -> None:
    asyncio.run(_test_task_delete_via_update(tmp_path))


async def _test_task_delete_via_update(tmp_path) -> None:
    store = TaskStore(store_dir=tmp_path / "tasks", list_id="p3")
    with bind_system_tool_context(project_root=tmp_path, task_store=store):
        _parse(await TaskCreate.execute(subject="To be deleted"))
        result = _parse(await TaskUpdate.execute(task_id="1", delete=True))
        assert result["ok"]
        assert result["data"]["task"]["deleted"] is True
        assert result["data"]["total"] == 0


def test_task_delete_not_found(tmp_path) -> None:
    asyncio.run(_test_task_delete_not_found(tmp_path))


async def _test_task_delete_not_found(tmp_path) -> None:
    store = TaskStore(store_dir=tmp_path / "tasks", list_id="p3b")
    with bind_system_tool_context(project_root=tmp_path, task_store=store):
        result = _parse(await TaskUpdate.execute(task_id="999", delete=True))
        assert not result["ok"]
        assert result["error"]["code"] == "NOT_FOUND"


def test_task_delete_with_dependents(tmp_path) -> None:
    asyncio.run(_test_task_delete_with_dependents(tmp_path))


async def _test_task_delete_with_dependents(tmp_path) -> None:
    store = TaskStore(store_dir=tmp_path / "tasks", list_id="p3c")
    with bind_system_tool_context(project_root=tmp_path, task_store=store):
        _parse(await TaskCreate.execute(subject="A"))
        _parse(await TaskCreate.execute(subject="B"))
        _parse(await TaskUpdate.execute(task_id="1", add_blocks=["2"]))
        result = _parse(await TaskUpdate.execute(task_id="1", delete=True))
        assert not result["ok"]
        assert result["error"]["code"] == "CONFLICT"


# P1: add_blocked_by / add_blocks

def test_add_blocked_by_appends(tmp_path) -> None:
    asyncio.run(_test_add_blocked_by_appends(tmp_path))


async def _test_add_blocked_by_appends(tmp_path) -> None:
    store = TaskStore(store_dir=tmp_path / "tasks", list_id="p1a")
    with bind_system_tool_context(project_root=tmp_path, task_store=store):
        _parse(await TaskCreate.execute(subject="A"))
        _parse(await TaskCreate.execute(subject="B"))
        _parse(await TaskCreate.execute(subject="C"))
        _parse(await TaskUpdate.execute(task_id="2", add_blocked_by=["1"]))
        result = _parse(await TaskUpdate.execute(task_id="2", add_blocked_by=["3"]))
        assert result["ok"]
        assert result["data"]["task"]["blocked_by"] == ["1", "3"]


def test_add_blocks_reverse(tmp_path) -> None:
    asyncio.run(_test_add_blocks_reverse(tmp_path))


async def _test_add_blocks_reverse(tmp_path) -> None:
    store = TaskStore(store_dir=tmp_path / "tasks", list_id="p1b")
    with bind_system_tool_context(project_root=tmp_path, task_store=store):
        _parse(await TaskCreate.execute(subject="A"))
        _parse(await TaskCreate.execute(subject="B"))
        _parse(await TaskCreate.execute(subject="C"))
        result = _parse(await TaskUpdate.execute(task_id="1", add_blocks=["2", "3"]))
        assert result["ok"]
        a = store.get_task("1")
        assert a is not None
        assert "2" in a.blocks
        assert "3" in a.blocks
        b = store.get_task("2")
        c = store.get_task("3")
        assert b is not None and "1" in b.blocked_by
        assert c is not None and "1" in c.blocked_by


def test_add_blocked_by_dedup(tmp_path) -> None:
    asyncio.run(_test_add_blocked_by_dedup(tmp_path))


async def _test_add_blocked_by_dedup(tmp_path) -> None:
    store = TaskStore(store_dir=tmp_path / "tasks", list_id="p1c")
    with bind_system_tool_context(project_root=tmp_path, task_store=store):
        _parse(await TaskCreate.execute(subject="A"))
        _parse(await TaskCreate.execute(subject="B"))
        _parse(await TaskUpdate.execute(task_id="2", add_blocked_by=["1"]))
        result = _parse(await TaskUpdate.execute(task_id="2", add_blocked_by=["1"]))
        assert result["ok"]
        assert result["data"]["task"]["blocked_by"] == ["1"]


def test_combined_add_blocked_by_and_add_blocks_atomic(tmp_path) -> None:
    asyncio.run(_test_combined_add_blocked_by_and_add_blocks_atomic(tmp_path))


async def _test_combined_add_blocked_by_and_add_blocks_atomic(tmp_path) -> None:
    store = TaskStore(store_dir=tmp_path / "tasks", list_id="atomic")
    with bind_system_tool_context(project_root=tmp_path, task_store=store):
        _parse(await TaskCreate.execute(subject="A"))
        _parse(await TaskCreate.execute(subject="B"))
        _parse(await TaskCreate.execute(subject="C"))
        result = _parse(
            await TaskUpdate.execute(task_id="2", add_blocked_by=["1"], add_blocks=["3"])
        )
        assert result["ok"]
        b = store.get_task("2")
        assert b is not None
        assert "1" in b.blocked_by
        assert "3" in b.blocks
        a = store.get_task("1")
        assert a is not None
        assert "2" in a.blocks
        c = store.get_task("3")
        assert c is not None
        assert "2" in c.blocked_by


def test_task_update_schema_has_descriptions_for_all_fields() -> None:
    schema = TaskUpdate.definition.parameters
    props = schema["properties"]
    for field_name, field_schema in props.items():
        desc = field_schema.get("description") or ""
        # Check nested anyOf for description
        if not desc:
            for variant in field_schema.get("anyOf", []):
                if isinstance(variant, dict) and "description" in variant:
                    desc = variant["description"]
        assert desc, f"Field '{field_name}' in TaskUpdate is missing description"


def test_task_update_definition_uses_usage_rules() -> None:
    from comate_agent_sdk.system_tools.description import TASK_UPDATE_USAGE_RULES
    defn = TaskUpdate.definition
    assert defn.description == TASK_UPDATE_USAGE_RULES.strip()



def test_task_get_schema_has_description() -> None:
    schema = TaskGet.definition.parameters
    assert "description" in schema["properties"]["task_id"]


def test_task_list_schema_has_description() -> None:
    schema = TaskList.definition.parameters
    assert "description" in schema["properties"]["status"]
