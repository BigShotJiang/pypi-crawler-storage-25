from __future__ import annotations

import asyncio
import json
import logging
import re
from typing import Annotated, Any

from pydantic import BaseModel, Field, model_validator

from comate_agent_sdk.system_tools.task.models import TaskItem, TaskStatus
from comate_agent_sdk.system_tools.task.store import (
    TaskStore,
    TaskStoreConflictError,
    TaskStoreTimeoutError,
)
from comate_agent_sdk.system_tools.task.timing import (
    DEFAULT_TASKLIST_TEAM_BLOCK_SECONDS,
    TASKLIST_TEAM_BLOCK_ENV_VAR,
    resolve_tasklist_team_block_seconds,
)
from comate_agent_sdk.system_tools.tool_result import err, ok
from comate_agent_sdk.tools.decorator import tool
from comate_agent_sdk.tools.depends import Depends
from comate_agent_sdk.tools.system_context import SystemToolContext, get_system_tool_context
from comate_agent_sdk.system_tools.description import TASK_CREATE_USAGE_RULES, TASK_LIST_USAGE_RULES, TASK_UPDATE_USAGE_RULES

logger = logging.getLogger(__name__)
_TASK_ID_PREFIX_PATTERN = re.compile(r"^(?:#|task-)(\d+)$", re.IGNORECASE)


def _task_store(ctx: SystemToolContext) -> TaskStore:
    if ctx.task_store is None:
        raise RuntimeError("TaskStore 未注入")
    return ctx.task_store


async def _maybe_block_task_list_for_team_mode(ctx: SystemToolContext) -> None:
    in_team_mode = bool(str(getattr(ctx, "team_name", "") or "").strip())
    if not in_team_mode:
        return
    await asyncio.sleep(resolve_tasklist_team_block_seconds())


def _task_to_dict(task: TaskItem, store: TaskStore) -> dict[str, Any]:
    payload = task.model_dump(mode="json")
    payload["open_blocked_by"] = store.get_open_blocked_by(task.id)
    return payload


def _tasks_payload(store: TaskStore, tasks: list[TaskItem]) -> list[dict[str, Any]]:
    return [_task_to_dict(task, store) for task in tasks]


def _by_status(tasks: list[TaskItem]) -> dict[str, int]:
    counts = {status.value: 0 for status in TaskStatus}
    for task in tasks:
        counts[task.status.value] += 1
    return counts


def _summary_for_tasks(tasks: list[TaskItem]) -> str:
    total = len(tasks)
    counts = _by_status(tasks)
    return (
        f"tasks={total} pending={counts['pending']} "
        f"in_progress={counts['in_progress']} completed={counts['completed']}"
    )


def _normalize_task_id_value(value: Any) -> Any:
    raw = str(value or "").strip()
    if not raw:
        return value
    if raw.isdigit():
        return str(int(raw))
    match = _TASK_ID_PREFIX_PATTERN.fullmatch(raw)
    if match is None:
        return raw
    return str(int(match.group(1)))


def _normalize_task_id_list(values: Any) -> Any:
    if not isinstance(values, list):
        return values
    return [_normalize_task_id_value(value) for value in values]


class TaskCreateInput(BaseModel):
    subject: str = Field(
        min_length=1,
        description="Brief actionable title in imperative form",
    )
    description: str = Field(
        default="",
        description="Detailed description with context and acceptance criteria",
    )
    owner: str = Field(
        default="",
        description="Assignee name. In Team mode, prefer leaving empty and assigning later.",
    )

    model_config = {"extra": "forbid"}

    @model_validator(mode="after")
    def _normalize_subject(self) -> "TaskCreateInput":
        self.subject = self.subject.strip()
        self.description = self.description.strip()
        return self


class TaskListInput(BaseModel):
    status: list[TaskStatus] | None = Field(default=None, description="Filter by status (e.g. ['pending', 'in_progress'])")

    model_config = {"extra": "forbid"}


class TaskGetInput(BaseModel):
    task_id: str = Field(min_length=1, description="ID of the task to retrieve")

    model_config = {"extra": "forbid"}

    @model_validator(mode="after")
    def _normalize_task_id(self) -> "TaskGetInput":
        self.task_id = _normalize_task_id_value(self.task_id)
        return self


class TaskUpdateInput(BaseModel):
    task_id: str = Field(min_length=1, description="ID of the task to update")
    status: TaskStatus | None = Field(None, description="New status: pending, in_progress, or completed")
    subject: str | None = Field(None, description="Replacement title in imperative form")
    description: str | None = Field(None, description="Replacement description with context and acceptance criteria")
    owner: str | None = Field(None, description="New owner for the task")
    add_blocked_by: list[str] | None = Field(None, description="Task IDs that must complete before this task")
    add_blocks: list[str] | None = Field(None, description="Task IDs that this task blocks")
    metadata: dict[str, Any] | None = Field(None, description="Metadata keys to merge. Set a key to null to delete it.")
    delete: bool = Field(False, description="Set true to permanently delete this task")

    model_config = {"extra": "forbid"}

    @model_validator(mode="after")
    def _normalize_ids(self) -> "TaskUpdateInput":
        self.task_id = _normalize_task_id_value(self.task_id)
        self.add_blocked_by = _normalize_task_id_list(self.add_blocked_by)
        self.add_blocks = _normalize_task_id_list(self.add_blocks)
        return self

    @model_validator(mode="before")
    @classmethod
    def _coerce_stringified_fields(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        for list_field in ("add_blocked_by", "add_blocks"):
            value = data.get(list_field)
            if isinstance(value, str):
                try:
                    parsed = json.loads(value)
                    if isinstance(parsed, list):
                        data[list_field] = parsed
                except Exception:
                    pass
        metadata = data.get("metadata")
        if isinstance(metadata, str):
            try:
                parsed = json.loads(metadata)
                if isinstance(parsed, dict):
                    data["metadata"] = parsed
            except Exception:
                pass
        return data


@tool(
    "Create a task in the persistent task list.",
    name="TaskCreate",
    usage_rules=TASK_CREATE_USAGE_RULES,
)
async def TaskCreate(
    params: TaskCreateInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    store = _task_store(ctx)
    try:
        explicit_owner = params.owner.strip() if params.owner else ""
        in_team_mode = bool(str(getattr(ctx, "team_name", "") or "").strip())
        # A6: owner 语义收敛为“当前认领者”。
        # Team 模式下未显式传 owner 时保持未分配；非 Team 模式维持历史 fallback。
        if explicit_owner:
            owner = explicit_owner
        elif in_team_mode:
            owner = ""
        else:
            owner = (
                str(getattr(ctx, "subagent_name", None) or "").strip()
                or str(ctx.session_id or "").strip()
            )
        task = await store.async_create_task(
            subject=params.subject,
            description=params.description,
            owner=owner,
        )
        tasks = store.list_tasks()
        return ok(
            data={
                "list_id": store.list_id_value(),
                "task": _task_to_dict(task, store),
                "tasks": _tasks_payload(store, tasks),
                "total": len(tasks),
                "by_status": _by_status(tasks),
                "summary": _summary_for_tasks(tasks),
            },
            meta={"list_id": store.list_id_value(), "task_id": task.id},
        )
    except TaskStoreTimeoutError as exc:
        logger.warning(f"TaskCreate timeout: {exc}")
        return err("TIMEOUT", str(exc), retryable=True)
    except TaskStoreConflictError as exc:
        return err("CONFLICT", str(exc))
    except Exception as exc:
        logger.error(f"TaskCreate failed: {exc}", exc_info=True)
        return err("INTERNAL", f"TaskCreate failed: {exc}")


@tool(
    "List tasks from the shared persistent task list.",
    name="TaskList",
    usage_rules=TASK_LIST_USAGE_RULES,
)
async def TaskList(
    params: TaskListInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    store = _task_store(ctx)
    try:
        await _maybe_block_task_list_for_team_mode(ctx)
        tasks = store.list_tasks(status_filter=params.status)
        return ok(
            data={
                "list_id": store.list_id_value(),
                "tasks": _tasks_payload(store, tasks),
                "total": len(tasks),
                "by_status": _by_status(tasks),
                "summary": _summary_for_tasks(tasks),
            },
            meta={"list_id": store.list_id_value()},
        )
    except TaskStoreTimeoutError as exc:
        logger.warning(f"TaskList timeout: {exc}")
        return err("TIMEOUT", str(exc), retryable=True)
    except Exception as exc:
        logger.error(f"TaskList failed: {exc}", exc_info=True)
        return err("INTERNAL", f"TaskList failed: {exc}")


@tool(
    "Get details for a single task, including open blockers and reverse dependents.",
    name="TaskGet",
)
async def TaskGet(
    params: TaskGetInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    store = _task_store(ctx)
    try:
        task = store.get_task(params.task_id)
        if task is None:
            return err("NOT_FOUND", f"Task not found: {params.task_id}")

        open_blocked_by = store.get_open_blocked_by(task.id)
        blocked_by_detail = [
            _task_to_dict(dependency, store)
            for dependency_id in task.blocked_by
            if (dependency := store.get_task(dependency_id)) is not None
        ]
        blocks_detail = [
            _task_to_dict(dependent, store)
            for dependent_id in task.blocks
            if (dependent := store.get_task(dependent_id)) is not None
        ]
        return ok(
            data={
                "list_id": store.list_id_value(),
                "task": _task_to_dict(task, store),
                "blocks_detail": blocks_detail,
                "blocked_by_detail": blocked_by_detail,
                "open_blocked_by": open_blocked_by,
            },
            meta={"list_id": store.list_id_value(), "task_id": task.id},
        )
    except TaskStoreTimeoutError as exc:
        logger.warning(f"TaskGet timeout: {exc}")
        return err("TIMEOUT", str(exc), retryable=True)
    except Exception as exc:
        logger.error(f"TaskGet failed: {exc}", exc_info=True)
        return err("INTERNAL", f"TaskGet failed: {exc}")


@tool(
    "Update an existing persistent task. Use to claim ownership, change status, or edit dependencies.",
    name="TaskUpdate",
    usage_rules=TASK_UPDATE_USAGE_RULES,
)
async def TaskUpdate(
    params: TaskUpdateInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    store = _task_store(ctx)
    try:
        updates = params.model_dump(exclude_none=True)
        task_id = str(updates.pop("task_id"))
        updates.pop("delete", None)
        add_blocked_by = updates.pop("add_blocked_by", None)
        add_blocks = updates.pop("add_blocks", None)

        if params.delete:
            deleted = await store.async_delete_task(task_id)
            if not deleted:
                return err("NOT_FOUND", f"Task not found: {task_id}")
            tasks = store.list_tasks()
            return ok(
                data={
                    "list_id": store.list_id_value(),
                    "task": {"id": task_id, "deleted": True},
                    "tasks": _tasks_payload(store, tasks),
                    "total": len(tasks),
                    "by_status": _by_status(tasks),
                    "summary": _summary_for_tasks(tasks),
                },
                meta={"list_id": store.list_id_value(), "task_id": task_id},
            )

        if add_blocked_by:
            updates["extend_blocked_by"] = add_blocked_by
        if add_blocks:
            updates["extend_blocks"] = add_blocks
        task = await store.async_update_task(task_id, **updates)

        tasks = store.list_tasks()
        return ok(
            data={
                "list_id": store.list_id_value(),
                "task": _task_to_dict(task, store),
                "tasks": _tasks_payload(store, tasks),
                "total": len(tasks),
                "by_status": _by_status(tasks),
                "summary": _summary_for_tasks(tasks),
            },
            meta={"list_id": store.list_id_value(), "task_id": task.id},
        )
    except TaskStoreTimeoutError as exc:
        logger.warning(f"TaskUpdate timeout: {exc}")
        return err("TIMEOUT", str(exc), retryable=True)
    except TaskStoreConflictError as exc:
        code = "NOT_FOUND" if "not found" in str(exc).lower() else "CONFLICT"
        return err(code, str(exc))
    except Exception as exc:
        logger.error(f"TaskUpdate failed: {exc}", exc_info=True)
        return err("INTERNAL", f"TaskUpdate failed: {exc}")
