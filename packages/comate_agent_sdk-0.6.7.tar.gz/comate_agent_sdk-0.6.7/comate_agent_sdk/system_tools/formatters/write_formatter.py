"""Formatter for Write/Edit tool results."""
from __future__ import annotations

from typing import Any

from comate_agent_sdk.system_tools.formatters.types import FormattedToolResult, ToolExecutionMeta

from .common import _as_int, _duration_from_result


def format_write_like_result(
    tool_name: str,
    tool_call_id: str,
    result: dict[str, Any],
) -> FormattedToolResult:
    data = result.get("data", {})
    env_meta = result.get("meta", {})

    relpath = str(data.get("relpath") or "")
    file_path = ""
    resolved_file_path = ""
    operation = ""
    sha_before = None
    sha_after = None
    if isinstance(env_meta, dict):
        file_path = str(env_meta.get("file_path") or "")
        resolved_file_path = str(env_meta.get("resolved_file_path") or "")
        operation = str(env_meta.get("operation") or "")
        sha_before = env_meta.get("sha256_before")
        sha_after = env_meta.get("sha256_after")

    display_path = resolved_file_path or file_path or relpath or "unknown"
    if not operation:
        operation = tool_name.lower()
    if sha_after is None:
        sha_after = data.get("sha256") or data.get("after_sha256")

    if tool_name == "Write":
        if operation == "append":
            text = f"The file {display_path} has been appended successfully."
        else:
            text = f"The file {display_path} has been written successfully."
    elif tool_name == "Edit":
        replace_all = bool(env_meta.get("replace_all")) if isinstance(env_meta, dict) else False
        if replace_all:
            text = f"The file {display_path} has been updated. All occurrences were successfully replaced."
        else:
            text = f"The file {display_path} has been updated successfully."
    else:
        text = f"The file {display_path} has been updated successfully."

    verify_path = relpath or display_path
    hints = [
        {
            "action": "Read",
            "priority": "high",
            "args": {
                "file_path": verify_path,
                "offset": 1,
                "limit": 200,
            },
        }
    ]

    file_ops = {
        "file_path": display_path,
        "operation": operation,
        "bytes_written": _as_int(data.get("bytes_written") or data.get("bytes"), 0),
        "sha256_before": sha_before,
        "sha256_after": sha_after,
    }
    file_ops = {k: v for k, v in file_ops.items() if v is not None}

    meta = ToolExecutionMeta(
        tool_name=tool_name,
        tool_call_id=tool_call_id,
        status="ok",
        file_ops=file_ops,
        retrieval_hints=hints,
        duration_ms=_duration_from_result(result),
    )
    return FormattedToolResult(text=text, meta=meta)
