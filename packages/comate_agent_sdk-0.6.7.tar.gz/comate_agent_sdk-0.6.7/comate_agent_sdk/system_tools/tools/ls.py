from __future__ import annotations

from ._common import *

class LSInput(BaseModel):
    path: str = Field(description="Absolute or relative directory path to list. Use '.' for project root.")
    ignore: list[str] | None = Field(default=None, description="List of glob patterns to exclude, e.g. ['*.pyc', '__pycache__'].")
    head_limit: int = Field(default=_LIST_SPILL_LIMIT, ge=1, le=300, description="Maximum number of entries to return (default: 100).")
    include_hidden: bool = Field(default=False, description="If True, include hidden files and directories (names starting with '.').")
    sort_by: Literal["name", "mtime", "size"] = Field(default="name", description="Sort order: name (default, alphabetical), mtime (most recently modified first), size (largest first).")

    model_config = {"extra": "forbid"}

def _sort_ls(entries: list[dict[str, Any]], sort_by: str) -> list[dict[str, Any]]:
    if sort_by == "mtime":
        return sorted(entries, key=lambda x: (x["mtime"], x["name"]), reverse=True)
    if sort_by == "size":
        return sorted(entries, key=lambda x: (x["size"], x["name"]), reverse=True)
    return sorted(entries, key=lambda x: x["name"])

@tool(
    "List directory contents (like 'ls'). Use Glob for finding files by pattern.",
    name="LS",
    usage_rules=LS_USAGE_RULES,
    observable_input_backfill=_backfill_search_path,
)
async def LS(
    params: LSInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    try:
        p = resolve_for_search(
            user_path=params.path,
            project_root=_project_root(ctx),
            workspace_root=_workspace_root(ctx),
            extra_read_roots=_extra_read_roots(ctx),
        )
    except PathGuardError as exc:
        return _path_error_result(exc)

    if not await _exists(p):
        return err(
            "NOT_FOUND",
            _build_search_path_not_found_message(
                user_path=params.path,
                resolved_path=p,
                ctx=ctx,
                tool_name="LS",
            ).replace("Search path", "Path"),
        )
    if not await _is_dir(p):
        return err("INVALID_ARGUMENT", f"Path is not a directory: {params.path}")

    ignore = params.ignore or []

    def _collect_entries(path: Path) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for child in path.iterdir():
            name = child.name
            if not params.include_hidden and name.startswith("."):
                continue
            if any(fnmatch(name, pat) for pat in ignore):
                continue

            item_type = "dir" if child.is_dir() else "file" if child.is_file() else "other"
            try:
                st = child.stat()
                size = int(st.st_size) if child.is_file() else 0
                mtime = int(st.st_mtime)
            except Exception:
                size = 0
                mtime = 0

            rows.append({
                "name": name,
                "type": item_type,
                "size": size,
                "mtime": mtime,
            })
        return rows

    entries = await iu.io_call(_collect_entries, p)
    entries = _sort_ls(entries, params.sort_by)

    total = len(entries)
    preview = entries[: params.head_limit]

    # P1-5: Semantic summary
    dir_count = sum(1 for e in entries if e["type"] == "dir")
    file_count = sum(1 for e in entries if e["type"] == "file")
    total_size = sum(e["size"] for e in entries)

    data: dict[str, Any] = {
        "entries": preview,
        "count": total,
        "truncated": total > len(preview),
        "truncated_reason": "head_limit_reached" if total > len(preview) else None,
        "path": to_safe_relpath(p, roots=_allowed_roots(ctx)),
        "summary": {
            "dir_count": dir_count,
            "file_count": file_count,
            "total_size": iu.format_file_size(total_size),
        },
    }

    if total > len(preview):
        artifact = await iu.spill_json(
            artifact_store=_artifact_store(ctx),
            namespace="ls",
            data={"entries": entries, "count": total},
            ttl_seconds=_ARTIFACT_TTL_SECONDS,
        )
        data["artifact"] = artifact

    return ok(
        data=data,
        meta={
            "path": params.path,
            "resolved_path": data["path"],
            "ignore": ignore,
            "head_limit": params.head_limit,
            "include_hidden": params.include_hidden,
            "sort_by": params.sort_by,
        },
    )
