from __future__ import annotations

from ._base import *
from ._context import *

def _memory_relpath_from_user_path(user_path: str) -> Path | None:
    raw = str(user_path or "").strip()
    if not raw:
        return None

    expanded = Path(raw).expanduser()
    if expanded.is_absolute():
        return None

    parts = [p for p in PurePath(raw).parts if p not in (".", "")]
    if not parts:
        return None

    relpath: Path | None = None
    if len(parts) == 1 and parts[0].lower() == "memory.md":
        relpath = Path("MEMORY.md")
    elif parts[0].lower() == "memory" and len(parts) > 1:
        relpath = Path(*parts[1:])

    if relpath is None:
        return None
    if any(part in {"", ".."} for part in relpath.parts):
        return None
    return relpath

def _memory_root_from_ctx(ctx: SystemToolContext) -> Path | None:
    for root in tuple(ctx.extra_write_roots or ()):
        resolved = root.expanduser().resolve()
        if resolved.name.lower() == "memory":
            return resolved
    return None

def _memory_index_guard_mode() -> Literal["off", "warn", "enforce"]:
    raw = str(os.getenv(_MEMORY_INDEX_GUARD_MODE_ENV, _MEMORY_INDEX_GUARD_DEFAULT_MODE)).strip().lower()
    if raw in {"off", "warn", "enforce"}:
        return raw
    logger.warning(
        f"Invalid {_MEMORY_INDEX_GUARD_MODE_ENV}={raw!r}, fallback to {_MEMORY_INDEX_GUARD_DEFAULT_MODE!r}"
    )
    return _MEMORY_INDEX_GUARD_DEFAULT_MODE

def _memory_index_freeform_streak_limit() -> int:
    raw = str(os.getenv(_MEMORY_INDEX_FREEFORM_STREAK_ENV, str(_MEMORY_INDEX_FREEFORM_STREAK_DEFAULT))).strip()
    try:
        value = int(raw)
    except Exception:
        logger.warning(
            f"Invalid {_MEMORY_INDEX_FREEFORM_STREAK_ENV}={raw!r}, fallback to {_MEMORY_INDEX_FREEFORM_STREAK_DEFAULT}"
        )
        return _MEMORY_INDEX_FREEFORM_STREAK_DEFAULT
    return max(1, value)

def _is_memory_index_target(path: Path, ctx: SystemToolContext) -> bool:
    if path.name.lower() != "memory.md":
        return False
    memory_root = _memory_root_from_ctx(ctx)
    if memory_root is None:
        return False
    return path.resolve() == (memory_root / "MEMORY.md").resolve()

def _is_memory_write_target(path: Path, ctx: SystemToolContext) -> bool:
    memory_root = _memory_root_from_ctx(ctx)
    if memory_root is None:
        return False
    try:
        path.resolve().relative_to(memory_root)
        return True
    except ValueError:
        return False

def _memory_index_violation_reason(content: str) -> str | None:
    freeform_limit = _memory_index_freeform_streak_limit()
    freeform_streak = 0
    for line in content.splitlines():
        text = line.strip()
        if not text:
            freeform_streak = 0
            continue
        if _MEMORY_INDEX_HEADING_RE.match(text):
            freeform_streak = 0
            continue
        if _MEMORY_INDEX_ENTRY_RE.match(text):
            freeform_streak = 0
            continue
        if _MEMORY_INDEX_LEGACY_ENTRY_RE.match(text):
            return (
                "Legacy MEMORY.md index format is not allowed. "
                "Use the new format: - @filename.md - short description."
            )

        freeform_streak += 1
        if freeform_streak >= freeform_limit:
            return (
                "MEMORY.md must be an index-only router file. "
                "Write detailed memory to `memory/<topic>.md`, then keep one-line index entries in MEMORY.md "
                "for example: - @debugging.md - summary."
            )
    return None

def _enforce_memory_index_policy(
    *,
    path: Path,
    content: str,
    ctx: SystemToolContext,
) -> tuple[dict[str, Any] | None, str | None]:
    if not _is_memory_index_target(path, ctx):
        return None, None

    reason = _memory_index_violation_reason(content)
    if reason is None:
        return None, None

    mode = _memory_index_guard_mode()
    if mode == "off":
        return None, None
    if mode == "warn":
        logger.warning(f"MEMORY.md index guard warning: {reason}")
        return None, reason
    return err("INVALID_ARGUMENT", reason), None

def _enforce_memory_secret_policy(
    *,
    path: Path,
    content: str,
    ctx: SystemToolContext,
) -> dict[str, Any] | None:
    if not _is_memory_write_target(path, ctx):
        return None
    detected = scan_for_secrets(content)
    if not detected:
        return None
    detected_text = ", ".join(sorted(detected))
    return err(
        "INVALID_ARGUMENT",
        (
            "Refusing to write potential secrets to memory file: "
            f"detected {detected_text}. Store secrets outside memory."
        ),
        meta={"detected": detected},
    )

__all__ = [name for name in globals() if not name.startswith("__")]
