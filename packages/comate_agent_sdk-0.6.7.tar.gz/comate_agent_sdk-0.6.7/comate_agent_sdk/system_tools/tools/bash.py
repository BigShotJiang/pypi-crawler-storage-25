from __future__ import annotations

from ._common import *

class BashInput(BaseModel):
    command: str = Field(
        min_length=1,
        description="Shell command string, e.g. 'git status' or 'python -c \"print(1)\"'.",
    )
    description: str | None = Field(default=None, description="Optional concise description of what this command does.")
    timeout_ms: int = Field(default=_BASH_DEFAULT_TIMEOUT_MS, ge=1, le=_BASH_MAX_TIMEOUT_MS, description="Timeout in milliseconds (default: 120000ms / 2min, max: 600000ms / 10min). Increase for long-running commands like builds, tests, or installs.")
    env: dict[str, str] | None = Field(default=None, description="Optional environment variable overrides")
    max_output_chars: int = Field(default=_BASH_OUTPUT_DEFAULT_MAX_CHARS, ge=200, le=200_000, description="Maximum output characters returned (default: 30000). Reduce if output is too large.")
    max_disk_bytes: int = Field(
        default=_BASH_DEFAULT_MAX_DISK_BYTES,
        ge=1024,
        description="Maximum captured output bytes written to disk before stopping the command.",
    )

    model_config = {"extra": "forbid"}

    @model_validator(mode="before")
    @classmethod
    def _coerce_stringified_fields(cls, data: Any) -> Any:
        """Defense-in-depth: 修复非原生 OpenAI 模型将参数值字符串化的问题。"""
        if not isinstance(data, dict):
            return data

        # env: '{}' / '{"K":"V"}' / 'null' → dict | None
        env = data.get("env")
        if isinstance(env, str):
            normalized = env.strip().lower()
            if normalized in ("null", "none", ""):
                data["env"] = None
            else:
                try:
                    parsed = json.loads(env)
                    if isinstance(parsed, dict):
                        data["env"] = parsed
                    elif parsed is None:
                        data["env"] = None
                except (json.JSONDecodeError, TypeError):
                    pass

        # timeout_ms: "120000" → 120000
        timeout_ms = data.get("timeout_ms")
        if isinstance(timeout_ms, str):
            try:
                data["timeout_ms"] = int(timeout_ms)
            except (ValueError, TypeError):
                pass

        # max_output_chars: "30000" → 30000
        max_output_chars = data.get("max_output_chars")
        if isinstance(max_output_chars, str):
            try:
                data["max_output_chars"] = int(max_output_chars)
            except (ValueError, TypeError):
                pass

        max_disk_bytes = data.get("max_disk_bytes")
        if isinstance(max_disk_bytes, str):
            try:
                data["max_disk_bytes"] = int(max_disk_bytes)
            except (ValueError, TypeError):
                pass

        return data

def _backfill_bash_observable_input(args: dict[str, Any]) -> None:
    if args.get("description") is None:
        args.pop("description", None)
    if args.get("max_disk_bytes") is None:
        args["max_disk_bytes"] = _BASH_DEFAULT_MAX_DISK_BYTES

@tool(
    "Run shell command string. Use command='git status'. Use cd in command to change the persistent Bash working directory.",
    name="Bash",
    usage_rules=BASH_USAGE_RULES,
    observable_input_backfill=_backfill_bash_observable_input,
)
async def Bash(
    params: BashInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    _maybe_cleanup_loop_dicts()  # P2-8: Periodic cleanup
    start = time.monotonic()

    cwd = _current_bash_cwd(ctx)

    validation_err = _validate_bash_command(params, cwd=cwd, ctx=ctx)
    if validation_err is not None:
        return validation_err

    env = os.environ.copy()
    if ctx.config_env:
        env.update(ctx.config_env)
    if params.env:
        env.update(params.env)

    timed_out = False
    interrupted = False
    overflowed = False
    stdout = ""
    stderr = ""
    exit_code = -1
    artifact: dict[str, Any] | None = None

    proc: subprocess.Popen[str] | None = None
    unregister_interrupt_callback: Callable[[], None] | None = None
    artifact_store = _artifact_store(ctx)
    output_dir = artifact_store.base_dir / "bash"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_fd, output_tmp_name = tempfile.mkstemp(
        prefix=".tmp_bash_",
        suffix=".txt",
        dir=str(output_dir),
    )
    os.close(output_fd)
    output_path = Path(output_tmp_name)
    cwd_fd, cwd_tmp_name = tempfile.mkstemp(
        prefix=".tmp_bash_cwd_",
        suffix=".txt",
        dir=str(output_dir),
    )
    os.close(cwd_fd)
    cwd_path = Path(cwd_tmp_name)
    output_file: Any | None = None

    def _output_size_bytes() -> int:
        try:
            return output_path.stat().st_size
        except FileNotFoundError:
            return 0

    def _send_interrupt_signal(*, force: bool, mark_interrupted: bool) -> None:
        nonlocal interrupted
        if proc is None or proc.returncode is not None:
            return

        if mark_interrupted:
            interrupted = True

        try:
            if proc.pid is not None:
                bash_executor.tree_kill(proc.pid, force=force)
        except ProcessLookupError:
            return
        except Exception as exc:
            logger.warning("failed to signal bash process: %s", exc, exc_info=True)

    async def _terminate_process_with_grace(*, mark_interrupted: bool) -> None:
        _send_interrupt_signal(force=False, mark_interrupted=mark_interrupted)
        if proc is None or proc.returncode is not None:
            return
        try:
            await iu.io_call(proc.wait, timeout=0.8)
            return
        except subprocess.TimeoutExpired:
            pass

        _send_interrupt_signal(force=True, mark_interrupted=mark_interrupted)
        if proc is None or proc.returncode is not None:
            return
        try:
            await iu.io_call(proc.wait, timeout=0.8)
        except subprocess.TimeoutExpired:
            logger.warning("bash process did not exit after SIGKILL fallback")

    async with iu.bash_semaphore():
        try:
            try:
                tracking_command = (
                    f"eval {shlex.quote(params.command)}\n"
                    "__comate_bash_status=$?\n"
                    f"pwd -P > {shlex.quote(str(cwd_path))}\n"
                    "exit $__comate_bash_status"
                )
                cmd = _build_bash_command(tracking_command)
            except FileNotFoundError:
                duration_ms = int((time.monotonic() - start) * 1000)
                return err(
                    "BASH_NOT_AVAILABLE",
                    "Bash executable not available on this machine.",
                    meta={
                        "command": params.command,
                        "cwd": str(cwd),
                        "timeout_ms": params.timeout_ms,
                        "max_output_chars": params.max_output_chars,
                        "max_disk_bytes": params.max_disk_bytes,
                        "duration_ms": duration_ms,
                    },
                )

            create_kwargs: dict[str, Any] = {
                "cwd": str(cwd),
                "env": env,
            }
            if os.name != "nt":
                create_kwargs["start_new_session"] = True

            output_file = output_path.open("wb")
            create_kwargs["stdout"] = output_file
            create_kwargs["stderr"] = subprocess.STDOUT

            try:
                proc = subprocess.Popen(cmd, **create_kwargs)
            except FileNotFoundError:
                duration_ms = int((time.monotonic() - start) * 1000)
                return err(
                    "BASH_NOT_AVAILABLE",
                    "Bash executable not available on this machine.",
                    meta={
                        "command": params.command,
                        "cwd": str(cwd),
                        "timeout_ms": params.timeout_ms,
                        "max_output_chars": params.max_output_chars,
                        "max_disk_bytes": params.max_disk_bytes,
                        "duration_ms": duration_ms,
                    },
                )

            run_controller = getattr(ctx, "run_controller", None)
            if run_controller is not None:
                def _on_interrupt(reason: str, interrupt_count: int) -> None:
                    force = interrupt_count >= 2 or str(reason).strip().lower().endswith("force")
                    _send_interrupt_signal(force=force, mark_interrupted=True)

                unregister_interrupt_callback = run_controller.register_interrupt_callback(_on_interrupt)
                if run_controller.is_interrupted:
                    _on_interrupt(
                        str(run_controller.reason or "user"),
                        max(1, int(run_controller.interrupt_count)),
                    )

            deadline = start + (params.timeout_ms / 1000.0)
            while True:
                if proc.returncode is None and hasattr(proc, "poll"):
                    proc.poll()
                if proc.returncode is not None:
                    break
                if _output_size_bytes() > params.max_disk_bytes:
                    overflowed = True
                    await _terminate_process_with_grace(mark_interrupted=False)
                    break
                if time.monotonic() >= deadline:
                    timed_out = True
                    await _terminate_process_with_grace(mark_interrupted=False)
                    break
                await asyncio.sleep(0.05)

            if proc.returncode is None:
                try:
                    await iu.io_call(proc.wait, timeout=1.0)
                except subprocess.TimeoutExpired:
                    pass
            if proc.returncode is not None:
                exit_code = int(proc.returncode)
        except asyncio.CancelledError:
            await _terminate_process_with_grace(mark_interrupted=True)
            raise
        finally:
            if output_file is not None:
                output_file.close()
                output_file = None
            if unregister_interrupt_callback is not None:
                unregister_interrupt_callback()
                unregister_interrupt_callback = None

    duration_ms = int((time.monotonic() - start) * 1000)
    stdout_total_bytes = _output_size_bytes()

    final_cwd: Path | None = None
    cwd_reset_message = ""
    try:
        final_cwd_text = cwd_path.read_text(encoding="utf-8", errors="replace").strip()
        if final_cwd_text:
            candidate_cwd = Path(final_cwd_text).expanduser().resolve()
            if candidate_cwd.exists() and candidate_cwd.is_dir():
                if any(
                    _is_under(candidate_cwd, root)
                    for root in _bash_cwd_allowed_roots(ctx)
                ):
                    final_cwd = candidate_cwd
                    _set_bash_cwd(ctx, candidate_cwd)
                else:
                    project_root = _project_root(ctx)
                    final_cwd = project_root
                    _set_bash_cwd(ctx, project_root)
                    cwd_reset_message = f"Shell cwd was reset to {project_root}"
    except OSError:
        final_cwd = None
    finally:
        try:
            cwd_path.unlink()
        except FileNotFoundError:
            pass

    has_more_chars = False
    try:
        with output_path.open("r", encoding="utf-8", errors="replace") as f:
            preview = f.read(params.max_output_chars + 1)
        if len(preview) > params.max_output_chars:
            has_more_chars = True
            preview = preview[:params.max_output_chars]
        stdout = preview
    except FileNotFoundError:
        stdout = ""

    if cwd_reset_message:
        stderr = cwd_reset_message

    should_spill = has_more_chars or overflowed
    truncated_reason = None
    if overflowed:
        truncated_reason = "output_overflow"
    elif has_more_chars:
        truncated_reason = "output_too_large"

    temp_file_consumed = False
    if should_spill:
        try:
            artifact = await artifact_store.put_file(
                namespace="bash",
                source_path=output_path,
                mime="text/plain",
                ttl_seconds=_ARTIFACT_TTL_SECONDS,
            )
            temp_file_consumed = True
        except Exception:
            relpath = os.path.relpath(str(output_path), str(_workspace_root(ctx)))
            artifact = {
                "id": f"temp:{output_path.name}",
                "relpath": relpath,
                "bytes": output_path.stat().st_size if output_path.exists() else 0,
                "sha256": "",
                "mime": "text/plain",
                "created_at": int(time.time()),
                "ttl_seconds": int(_ARTIFACT_TTL_SECONDS),
            }

    if output_path.exists() and (not should_spill or temp_file_consumed):
        try:
            output_path.unlink()
        except FileNotFoundError:
            pass

    data = {
        "stdout": stdout,
        "stderr": stderr,
        "exit_code": exit_code,
        "timed_out": timed_out,
        "interrupted": interrupted,
        "killed": timed_out or interrupted or overflowed,
        "duration_ms": duration_ms,
        "truncated": bool(should_spill),
        "truncated_reason": truncated_reason,
        "stdout_truncated": bool(should_spill),
        "stdout_total_bytes": stdout_total_bytes,
        "stdout_dropped_lines": 0,
        "stderr_truncated": False,
        "stderr_total_bytes": 0,
        "stderr_dropped_lines": 0,
    }
    if artifact is not None:
        data["artifact"] = artifact

    exec_meta = {
        "command": params.command,
        "cwd": str(cwd),
        "timeout_ms": params.timeout_ms,
        "max_output_chars": params.max_output_chars,
        "max_disk_bytes": params.max_disk_bytes,
        "duration_ms": duration_ms,
    }
    if final_cwd is not None:
        exec_meta["final_cwd"] = str(final_cwd)

    if overflowed:
        return err(
            "OUTPUT_OVERFLOW",
            f"Command output exceeded {params.max_disk_bytes} bytes and was stopped",
            data=data,
            retryable=True,
            meta=exec_meta,
        )

    if timed_out:
        return err(
            "TIMEOUT",
            f"Command timed out after {params.timeout_ms}ms",
            data=data,
            retryable=True,
            meta=exec_meta,
        )

    if interrupted:
        return err(
            "INTERRUPTED",
            "Command interrupted by user",
            data=data,
            retryable=True,
            meta=exec_meta,
        )

    return ok(data=data, meta=exec_meta)
