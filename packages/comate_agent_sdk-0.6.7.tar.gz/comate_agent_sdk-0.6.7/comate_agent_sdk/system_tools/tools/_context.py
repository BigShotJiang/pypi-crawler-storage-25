from __future__ import annotations

from ._base import *

def _project_root(ctx: SystemToolContext) -> Path:
    return ctx.project_root.resolve()

def _workspace_root(ctx: SystemToolContext) -> Path:
    if ctx.workspace_root is not None:
        return ctx.workspace_root.resolve()
    return (_project_root(ctx) / ".agent_workspace").resolve()

def _session_root_from_ctx(ctx: SystemToolContext) -> Path | None:
    if ctx.session_root is None:
        return None
    return ctx.session_root.resolve()

def _allowed_roots(ctx: SystemToolContext) -> list[Path]:
    roots = [_project_root(ctx)]
    roots.append(_workspace_root(ctx))
    roots.extend(list(ctx.extra_write_roots or ()))
    return roots

def _bash_cwd_allowed_roots(ctx: SystemToolContext) -> list[Path]:
    return [*_allowed_roots(ctx), *list(ctx.extra_read_roots or ())]

def _current_bash_cwd(ctx: SystemToolContext) -> Path:
    project_root = _project_root(ctx)
    getter = ctx.bash_cwd_getter
    if getter is None:
        return project_root
    try:
        cwd = Path(getter()).expanduser().resolve()
    except Exception as exc:
        logger.warning(
            "failed to resolve bash cwd; falling back to project root: %s",
            exc,
            exc_info=True,
        )
        _set_bash_cwd(ctx, project_root)
        return project_root
    if not cwd.exists() or not cwd.is_dir():
        _set_bash_cwd(ctx, project_root)
        return project_root
    if not any(_is_under(cwd, root) for root in _bash_cwd_allowed_roots(ctx)):
        _set_bash_cwd(ctx, project_root)
        return project_root
    return cwd

def _set_bash_cwd(ctx: SystemToolContext, cwd: Path) -> None:
    setter = ctx.bash_cwd_setter
    if setter is None:
        return
    setter(cwd.resolve())

def _extra_read_roots(ctx: SystemToolContext) -> tuple[Path, ...]:
    return ctx.extra_read_roots or ()

def _artifact_store(ctx: SystemToolContext) -> ArtifactStore:
    return ArtifactStore(_workspace_root(ctx))

def _is_under(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False

def _is_team_inbox_json_path(path: Path) -> bool:
    teams_root = resolve_teams_base_dir().resolve()
    resolved_path = path.resolve()
    if not _is_under(resolved_path, teams_root):
        return False
    if resolved_path.suffix != ".json":
        return False
    return resolved_path.parent.name == "inboxes"

__all__ = [name for name in globals() if not name.startswith("__")]
