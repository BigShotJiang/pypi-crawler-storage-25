from __future__ import annotations

from ._base import *
from ._context import *

def _validate_bash_command(
    params: BashInput,
    *,
    cwd: Path,
    ctx: SystemToolContext,
) -> dict[str, Any] | None:
    violation = BASH_COMMAND_POLICY.validate(
        command=params.command,
        cwd=cwd,
        allowed_roots=_allowed_roots(ctx),
    )
    if violation is None:
        return None
    return err(violation.code, violation.message)

def _build_bash_command(command: str) -> list[str]:
    return bash_executor.build_shell_invocation(command)

__all__ = [name for name in globals() if not name.startswith("__")]
