from __future__ import annotations

from ._common import *
from .write import _normalize_write_input_for_path

class EditInput(BaseModel):
    file_path: str = Field(description="Target file path")
    old_string: str = Field(description="Text to replace. Must match exactly (including whitespace and indentation). Use empty string only to create a new file or fill an existing empty file.")
    new_string: str = Field(description="Replacement text")
    replace_all: bool = Field(default=False, description="If True, replace all occurrences. Use when old_string appears multiple times and all should be replaced.")

    model_config = {"extra": "forbid"}

def _line_range_from_span(content: str, start: int, end: int) -> tuple[int, int]:
    """Find 1-based start and end line numbers of a span in content."""
    if start < 0 or end < start:
        return (0, 0)
    start_line = content[:start].count("\n") + 1
    end_line = start_line + content[start:end].count("\n")
    return (start_line, end_line)

@tool(
    "Perform exact string replacement in a file. Existing files must be Read first.",
    name="Edit",
    usage_rules=EDIT_USAGE_RULES,
)
async def Edit(
    params: EditInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    try:
        path = await _resolve_write_path(user_path=params.file_path, ctx=ctx)
    except PathGuardError as exc:
        return _path_error_result(exc)

    actual_new_string = _normalize_write_input_for_path(path, params.new_string)
    if params.old_string == actual_new_string:
        return _invalid_argument("new_string must differ from old_string", field="new_string")

    try:
        file_size = int((await _stat(path)).st_size)
        if file_size > _MAX_EDIT_FILE_SIZE:
            return err(
                "FILE_TOO_LARGE",
                (
                    f"File is too large to edit ({iu.format_file_size(file_size)}). "
                    f"Maximum editable file size is {iu.format_file_size(_MAX_EDIT_FILE_SIZE)}."
                ),
            )
    except FileNotFoundError:
        pass

    root_refs = _allowed_roots(ctx)
    memory_index_warning: str | None = None
    async with iu.file_lock(path):
        exists = await _exists(path)
        created = False
        if not exists:
            if params.old_string != "":
                similar = iu.find_similar_file(path)
                suggestion = f" Did you mean {similar}?" if similar else ""
                message = (
                    f"File not found: {params.file_path}.{suggestion} "
                    "To create a new file with Edit, set old_string to ''."
                ) if suggestion else (
                    f"File not found: {params.file_path}. "
                    "To create a new file with Edit, set old_string to ''."
                )
                return err(
                    "NOT_FOUND",
                    message,
                )
            before = ""
            current_version_token = None
            after = actual_new_string
            replacements = 1
            created = True
            line_count = iu.count_text_lines(after)
            start_line = 1 if line_count > 0 else 0
            end_line = line_count if line_count > 0 else 0
        else:
            if await _is_dir(path):
                return err("IS_DIRECTORY", f"Path is a directory: {params.file_path}")
            if not await _is_file(path):
                return err("PERMISSION_DENIED", f"Path is not a regular file: {params.file_path}")
            if not await _require_read(ctx, path):
                return err("PRECONDITION_FAILED", f"Must Read file before modifying it: {params.file_path}")

            before = await _read_text(path)

            current_version_token = _read_stat_fingerprint(await _stat(path))
            if await _check_version_conflict(ctx, path, current_version_token):
                return err(
                    "CONFLICT",
                    f"File has been modified externally since last Read. Re-read the file before editing: {params.file_path}",
                    meta={"conflict_type": "external_modification", "file_path": params.file_path},
                )

            if params.old_string == "":
                if before != "":
                    return err(
                        "CONFLICT",
                        (
                            "old_string='' is only allowed when creating a new file or filling an existing empty file: "
                            f"{params.file_path}"
                        ),
                    )
                after = actual_new_string
                replacements = 1
                line_count = iu.count_text_lines(after)
                start_line = 1 if line_count > 0 else 0
                end_line = line_count if line_count > 0 else 0
            else:
                matches = iu.find_edit_matches(before, params.old_string)
                count = len(matches)
                if count == 0:
                    preview = iu.truncate_line(params.old_string, 120)
                    return err(
                        "CONFLICT",
                        f"old_string not found in file: {params.file_path}. Search text: {preview}",
                    )

                if not params.replace_all and count > 1:
                    return err(
                        "CONFLICT",
                        f"old_string appears {count} times; provide a more specific old_string or set replace_all=true",
                    )

                start_line, end_line = _line_range_from_span(before, matches[0][0], matches[0][1])
                after = iu.apply_edit_matches(
                    before,
                    old_string=params.old_string,
                    new_string=actual_new_string,
                    matches=matches,
                    replace_all=params.replace_all,
                )
                replacements = count if params.replace_all else 1

        policy_error = _enforce_memory_secret_policy(
            path=path,
            content=after,
            ctx=ctx,
        )
        if policy_error is not None:
            return policy_error

        policy_error, memory_index_warning = _enforce_memory_index_policy(
            path=path,
            content=after,
            ctx=ctx,
        )
        if policy_error is not None:
            return policy_error

        await _atomic_write_text(path, after)

    before_sha = iu.sha256_text(before) if before else None
    after_sha = iu.sha256_text(after)
    after_version_token = _read_stat_fingerprint(await _stat(path))

    await _mark_read_with_version(ctx, path, after_version_token)
    await _invalidate_read_ranges(ctx, path)
    relpath = to_safe_relpath(path, roots=root_refs)
    diff_lines = iu.generate_unified_diff(
        before, after, fromfile=params.file_path, tofile=params.file_path
    )
    structured_patch = [] if created else iu.generate_structured_patch(
        before, after, fromfile=params.file_path, tofile=params.file_path
    )
    return ok(
        data={
            "replacements": replacements,
            "created": created,
            "before_sha256": before_sha,
            "after_sha256": after_sha,
            "relpath": relpath,
            "diff": diff_lines,
            "start_line": start_line,
            "end_line": end_line,
            "type": "create" if created else "update",
            "structured_patch": structured_patch,
            "original_file": None if created else before,
        },
        meta={
            "file_path": params.file_path,
            "operation": "replace",
            "created": created,
            "replace_all": params.replace_all,
            "replacements": replacements,
            "sha256_before": before_sha,
            "sha256_after": after_sha,
            "memory_index_guard_warning": memory_index_warning,
        },
    )
