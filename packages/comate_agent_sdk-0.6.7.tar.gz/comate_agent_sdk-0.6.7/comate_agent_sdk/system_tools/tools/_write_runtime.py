from __future__ import annotations

from ._base import *
from ._context import *
from ._memory import *

async def _resolve_write_path(
    *,
    user_path: str,
    ctx: SystemToolContext,
) -> Path:
    """Resolve write target.

    Three-stage explicit routing:
    1. Memory route: dedicated matcher for memory/MEMORY.md paths.
    2. Absolute path route: check against all known writable roots.
    3. Relative path route: unconditionally resolve under project_root.
    """
    workspace_root = _workspace_root(ctx)
    project_root = _project_root(ctx)
    extra_roots = tuple(ctx.extra_write_roots or ())

    # Stage 1: Memory route (dedicated matcher, unchanged)
    memory_relpath = _memory_relpath_from_user_path(user_path)
    if memory_relpath is not None:
        memory_root = _memory_root_from_ctx(ctx)
        if memory_root is not None:
            return resolve_for_write(
                user_path=memory_relpath.as_posix(),
                workspace_root=memory_root,
            )

    candidate = normalize_user_path(user_path)

    # Stage 2: Absolute path — check against known writable roots in priority order
    if candidate.is_absolute():
        for root in (project_root, workspace_root, *extra_roots):
            try:
                return resolve_for_write(user_path=user_path, workspace_root=root)
            except PathGuardError:
                continue
        raise PathGuardError(
            "PATH_ESCAPE",
            f"path is outside all allowed write roots",
        )

    # Stage 3: Relative path — unconditionally resolve under project_root
    return resolve_for_write(user_path=user_path, workspace_root=project_root)

def _atomic_write_bytes_sync(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    original_mode: int | None = None
    try:
        original_mode = stat_module.S_IMODE(os.stat(path).st_mode)
    except FileNotFoundError:
        pass
    fd, tmp_name = tempfile.mkstemp(prefix=".tmp_", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        if original_mode is not None:
            os.chmod(tmp_name, original_mode)
        os.replace(tmp_name, path)
        try:
            dir_fd = os.open(str(path.parent), os.O_DIRECTORY)
        except Exception:
            dir_fd = None
        if dir_fd is not None:
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
    finally:
        if os.path.exists(tmp_name):
            try:
                os.remove(tmp_name)
            except FileNotFoundError:
                pass

async def _atomic_write_text(path: Path, content: str, *, encoding: str = "utf-8") -> None:
    payload = content.encode(encoding)
    await iu.io_call(_atomic_write_bytes_sync, path, payload)

def _path_error_result(exc: PathGuardError) -> dict[str, Any]:
    return err(exc.code, exc.message)

def _invalid_argument(message: str, *, field: str | None = None) -> dict[str, Any]:
    field_errors: list[dict[str, Any]] = []
    if field:
        field_errors.append({"field": field, "message": message})
    return err("INVALID_ARGUMENT", message, field_errors=field_errors)

__all__ = [name for name in globals() if not name.startswith("__")]
