from __future__ import annotations

import sys
from types import ModuleType

from ._common import *
from .ask_user_question import AskUserQuestion, AskUserQuestionInput, Question, QuestionOption
from .bash import Bash, BashInput
from .edit import Edit, EditInput, _line_range_from_span
from .exit_plan_mode import ExitPlanMode, ExitPlanModeInput
from .glob import Glob, GlobInput
from .grep import Grep, GrepInput
from .ls import LS, LSInput
from .read import Read, ReadInput
from .web_fetch import WebFetch, WebFetchInput
from .write import Write, WriteInput, _normalize_write_input_for_path
from .yield_turn import YieldTurn, YieldTurnInput

SYSTEM_TOOLS: list[Tool] = [
    Bash,
    Read,
    Write,
    Edit,
    Glob,
    Grep,
    LS,
    *TASK_TOOLS,
    TeamCreate,
    TeamDelete,
    SendMessage,
    WebFetch,
    YieldTurn,
    ExitPlanMode,
    AskUserQuestion,
]


class _ToolsFacadeModule(ModuleType):
    def __setattr__(self, name: str, value: object) -> None:
        super().__setattr__(name, value)
        if not name.startswith("_"):
            return

        package_name = __name__
        for module_name, module in tuple(sys.modules.items()):
            if module_name == package_name:
                continue
            if not module_name.startswith(f"{package_name}."):
                continue
            if hasattr(module, name):
                ModuleType.__setattr__(module, name, value)


sys.modules[__name__].__class__ = _ToolsFacadeModule
