from __future__ import annotations

from ._base import *

async def _read_text(path: Path, *, encoding: str = "utf-8") -> str:
    return await iu.io_call(path.read_text, encoding=encoding, errors="replace")

def _read_bytes_prefix_sync(path: Path, limit: int) -> bytes:
    with path.open("rb") as handle:
        return handle.read(limit)

async def _read_bytes_prefix(path: Path, *, limit: int) -> bytes:
    return await iu.io_call(_read_bytes_prefix_sync, path, limit)

async def _exists(path: Path) -> bool:
    return await iu.io_call(path.exists)

async def _is_dir(path: Path) -> bool:
    return await iu.io_call(path.is_dir)

async def _is_file(path: Path) -> bool:
    return await iu.io_call(path.is_file)

async def _stat(path: Path):
    return await iu.io_call(path.stat)

def _read_stat_fingerprint(file_stat: os.stat_result) -> str:
    mtime_ns = getattr(file_stat, "st_mtime_ns", None)
    if mtime_ns is None:
        mtime_ns = int(file_stat.st_mtime * 1_000_000_000)
    return f"mtime_ns={int(mtime_ns)}|size={int(file_stat.st_size)}"

def _normalize_read_offset(offset: int) -> int:
    return offset if offset > 0 else 1

def _format_read_line(line_no: int, content: str) -> str:
    return f"{line_no:>{_READ_LINE_NUMBER_WIDTH}}\t{content}"

@dataclass
class _ReadScanResult:
    selected_lines: list[tuple[int, str]]
    total_lines: int
    has_more: bool
    stat_fingerprint: str
    problem_line: int | None = None
    problem_line_bytes: int | None = None

def _read_text_range_sync(
    path: Path,
    *,
    offset_line: int,
    limit_lines: int | None,
    stat_fingerprint: str,
) -> _ReadScanResult:
    selected_lines: list[tuple[int, str]] = []
    total_lines = 0
    has_more = False

    with path.open("r", encoding="utf-8", errors="replace") as handle:
        for total_lines, raw_line in enumerate(handle, start=1):
            line_content = raw_line[:-1] if raw_line.endswith("\n") else raw_line

            if total_lines < offset_line:
                continue

            if limit_lines is not None and len(selected_lines) >= limit_lines:
                has_more = True
                continue

            line_size_bytes = len(line_content.encode("utf-8"))
            if line_size_bytes > _READ_HARD_LINE_LIMIT:
                return _ReadScanResult(
                    selected_lines=selected_lines,
                    total_lines=total_lines,
                    has_more=has_more,
                    stat_fingerprint=stat_fingerprint,
                    problem_line=total_lines,
                    problem_line_bytes=line_size_bytes,
                )

            selected_lines.append((total_lines, line_content))

    return _ReadScanResult(
        selected_lines=selected_lines,
        total_lines=total_lines,
        has_more=has_more,
        stat_fingerprint=stat_fingerprint,
    )

async def _read_text_range(
    path: Path,
    *,
    offset_line: int,
    limit_lines: int | None,
    stat_fingerprint: str,
) -> _ReadScanResult:
    return await iu.io_call(
        _read_text_range_sync,
        path,
        offset_line=offset_line,
        limit_lines=limit_lines,
        stat_fingerprint=stat_fingerprint,
    )

def _looks_binary_sample(sample: bytes) -> bool:
    if not sample:
        return False
    if b"\x00" in sample:
        return True

    suspicious = 0
    for byte in sample:
        if byte < 32 and byte not in (9, 10, 12, 13):
            suspicious += 1
        elif byte == 127:
            suspicious += 1
    return suspicious * 10 >= len(sample) * 3

async def _detect_binary_read_target(path: Path) -> str | None:
    if any(suffix.lower() in _READ_BINARY_EXTENSIONS for suffix in path.suffixes):
        return "extension_blacklist"

    sample = await _read_bytes_prefix(path, limit=_READ_BINARY_SCAN_BYTES)
    if _looks_binary_sample(sample):
        return "content_scan"
    return None

__all__ = [name for name in globals() if not name.startswith("__")]
