from __future__ import annotations

from ._common import *

class WebFetchInput(BaseModel):
    url: str = Field(
        description="The URL to fetch content from",
        json_schema_extra={"format": "uri"},
    )
    prompt: str = Field(description="The prompt to run on the fetched content")

    model_config = {"extra": "forbid"}

@tool("Fetch webpage → markdown → LLM summary. Returns summary + full markdown artifact. Cached 15min. Prefer MCP-provided web fetch(or scrape) tools (named like \"mcp__*\") if available.", name="WebFetch", usage_rules=WEBFETCH_USAGE_RULES)
async def WebFetch(
    params: WebFetchInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    url = params.url.strip()
    prompt = params.prompt

    if not url:
        return _invalid_argument("url cannot be empty", field="url")
    if url.startswith("http://"):
        url = f"https://{url[7:]}"

    now = time.time()
    iu.cleanup_ttl_cache(_WEBFETCH_CACHE, now=now, ttl=_WEBFETCH_CACHE_TTL_SECONDS)

    cached = _WEBFETCH_CACHE.get(url)
    if cached and (now - float(cached.get("ts", 0.0)) <= _WEBFETCH_CACHE_TTL_SECONDS):
        markdown = str(cached.get("markdown", ""))
        final_url = str(cached.get("final_url", url))
        status = int(cached.get("status", 200))
        markdown_tokens = cached.get("markdown_tokens")
        content_signal = cached.get("content_signal")
        cached_hit = True
    else:
        cached_hit = False
        markdown_tokens = None
        content_signal = None
        try:
            from curl_cffi import requests as crequests
        except Exception as exc:
            return err("TOOL_NOT_AVAILABLE", f"WebFetch missing dependency curl_cffi: {exc}")

        # 1. 优先请求 Markdown (Cloudflare Markdown for Agents)
        try:
            response = await iu.io_call(
                crequests.get,
                url,
                timeout=_WEBFETCH_TIMEOUT_SECONDS,
                impersonate="chrome",
                headers={"Accept": "text/markdown, text/html"},
            )
        except Exception as exc:
            return err("INTERNAL", f"WebFetch request failed: {exc}", retryable=True)

        # 尝试获取 headers，支持 dict 或 SimpleNamespace
        def _get_header(resp, key):
            headers = getattr(resp, "headers", None)
            if headers is None:
                return None
            if isinstance(headers, dict):
                return headers.get(key)
            # SimpleNamespace 等对象
            return getattr(headers, key, None)

        status = int(getattr(response, "status_code", 0) or 0)
        final_url = str(getattr(response, "url", "") or url)
        markdown_tokens = _get_header(response, "x-markdown-tokens")
        content_signal = _get_header(response, "content-signal")

        if status != 200:
            # Markdown 请求失败，尝试普通 HTML 请求
            try:
                response = await iu.io_call(
                    crequests.get,
                    url,
                    timeout=_WEBFETCH_TIMEOUT_SECONDS,
                    impersonate="chrome",
                )
            except Exception as exc:
                return err("INTERNAL", f"WebFetch request failed: {exc}", retryable=True)

            status = int(getattr(response, "status_code", 0) or 0)
            final_url = str(getattr(response, "url", "") or url)
            html_text = str(getattr(response, "text", "") or "")
            markdown_tokens = None
            content_signal = None

            if status != 200:
                preview = iu.truncate_text(html_text, 2000)
                code = "NOT_FOUND" if status == 404 else "INTERNAL"
                return err(
                    code,
                    f"HTTP {status} fetching {final_url}",
                    meta={"status": status, "preview": preview},
                )

            try:
                from markdownify import markdownify as to_markdown
            except Exception as exc:
                return err("TOOL_NOT_AVAILABLE", f"WebFetch missing dependency markdownify: {exc}")

            markdown = await iu.io_call(to_markdown, html_text)
        else:
            # Markdown 请求成功
            markdown = str(getattr(response, "text", "") or "")

        # P2-9: Cache fingerprint
        content_sha256 = iu.sha256_text(markdown)
        _WEBFETCH_CACHE[url] = {
            "ts": now,
            "markdown": markdown,
            "final_url": final_url,
            "status": status,
            "markdown_tokens": markdown_tokens,
            "content_signal": content_signal,
            "content_sha256": content_sha256,
            "fetch_time": int(now),
        }

    artifact = await iu.spill_text(
        artifact_store=_artifact_store(ctx),
        namespace="webfetch",
        text=markdown,
        mime="text/markdown",
        ttl_seconds=_ARTIFACT_TTL_SECONDS,
    )

    if ctx.llm_levels is None or "LOW" not in ctx.llm_levels:
        return err("TOOL_NOT_AVAILABLE", "WebFetch requires llm_levels['LOW']")

    markdown_for_llm = markdown
    truncated_for_llm = False
    if len(markdown_for_llm) > _WEBFETCH_MARKDOWN_TRUNCATE_CHARS:
        markdown_for_llm = markdown_for_llm[:_WEBFETCH_MARKDOWN_TRUNCATE_CHARS]
        truncated_for_llm = True

    llm = ctx.llm_levels["LOW"]
    try:
        completion = await asyncio.wait_for(
            llm.ainvoke(
                messages=[
                    UserMessage(
                        content=(
                            f"{prompt}\n\n<url>{final_url}</url>\n\n"
                            f"<content>\n{markdown_for_llm}\n</content>"
                        )
                    )
                ],
                tools=None,
                tool_choice=None,
            ),
            timeout=_WEBFETCH_LLM_TIMEOUT_SECONDS,
        )
    except asyncio.TimeoutError:
        return err(
            "TIMEOUT",
            f"WebFetch LLM timeout after {_WEBFETCH_LLM_TIMEOUT_SECONDS}s",
            retryable=True,
        )
    except Exception as exc:
        logger.error(f"WebFetch LLM call failed: {exc}", exc_info=True)
        return err("INTERNAL", f"WebFetch LLM call failed: {exc}", retryable=True)

    if completion.usage and ctx.token_cost is not None:
        source = "webfetch"
        if ctx.subagent_source_prefix:
            source = f"{ctx.subagent_source_prefix}:webfetch"
        elif ctx.subagent_name:
            source = f"subagent:{ctx.subagent_name}:webfetch"
        ctx.token_cost.add_usage(
            str(llm.model),
            completion.usage,
            level="LOW",
            source=source,
        )

    # P2-9: Expose cache fingerprint to agent
    cache_sha256 = cached.get("content_sha256", "") if cached_hit else content_sha256
    cache_fetch_time = cached.get("fetch_time") if cached_hit else int(now)

    return ok(
        data={
            "final_url": final_url,
            "status": status,
            "cached": cached_hit,
            "cache_fingerprint": cache_sha256[:16] if cache_sha256 else "",
            "fetch_time": cache_fetch_time,
            "artifact": artifact,
            "truncated_for_llm": truncated_for_llm,
            "summary_text": completion.text,
            "model_used": str(llm.model),
            "markdown_tokens": markdown_tokens,
            "content_signal": content_signal,
        },
        meta={
            "url": url,
            "prompt_length": len(prompt),
            "final_url": final_url,
            "status": status,
            "cached": cached_hit,
            "truncated_for_llm": truncated_for_llm,
            "model_used": str(llm.model),
            "markdown_tokens": markdown_tokens,
            "content_signal": content_signal,
        },
    )
