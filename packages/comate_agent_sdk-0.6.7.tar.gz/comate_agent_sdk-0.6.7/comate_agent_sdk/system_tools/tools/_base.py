from __future__ import annotations

import asyncio
from datetime import datetime
import difflib
import functools
import json
import logging
import os
import re
import shlex
import signal
import shutil
import stat as stat_module
import subprocess
import sysconfig
import tempfile
import threading
import time
from collections import defaultdict
from dataclasses import dataclass
from fnmatch import fnmatch
from wcmatch.glob import globmatch, GLOBSTAR, DOTMATCH, BRACE

_GLOB_FLAGS = GLOBSTAR | DOTMATCH | BRACE
from pathlib import Path, PurePath
from typing import Annotated, Any, Callable, Literal, TypeVar

from pydantic import BaseModel, Field, field_validator, model_validator
from pydantic_core import PydanticUseDefault

from comate_agent_sdk.context.budget import TokenCounter
from comate_agent_sdk.llm.messages import UserMessage
from comate_agent_sdk.system_tools import _internal_utils as iu
from comate_agent_sdk.system_tools.artifact_store import ArtifactStore
from comate_agent_sdk.system_tools import bash_executor
from comate_agent_sdk.system_tools.description import (
    ASK_USER_QUESTION_USAGE_RULES,
    BASH_USAGE_RULES,
    EDIT_USAGE_RULES,
    EXIT_PLAN_MODE_USAGE_RULES,
    GLOB_USAGE_RULES,
    GREP_USAGE_RULES,
    LS_USAGE_RULES,
    READ_USAGE_RULES,
    WEBFETCH_USAGE_RULES,
    WRITE_USAGE_RULES,
    YIELD_TURN_USAGE_RULES,
)
from comate_agent_sdk.system_tools.policy_engine import (
    BASH_COMMAND_POLICY,
    READ_REGISTRY_POLICY,
)
from comate_agent_sdk.system_tools.path_guard import (
    PathGuardError,
    normalize_user_path,
    resolve_for_read,
    resolve_for_search,
    resolve_for_write,
    suggest_path_under_roots,
    to_safe_relpath,
)
from comate_agent_sdk.system_tools.secret_scanner import scan_for_secrets
from comate_agent_sdk.system_tools.task import TASK_TOOLS
from comate_agent_sdk.system_tools.team.config import resolve_teams_base_dir
from comate_agent_sdk.system_tools.team.tools import (
    SendMessage,
    TeamCreate,
    TeamDelete,
)
from comate_agent_sdk.system_tools.task.tools import (
    TaskCreate,
    TaskCreateInput,
    TaskGet,
    TaskGetInput,
    TaskList,
    TaskListInput,
    TaskUpdate,
    TaskUpdateInput,
)
from comate_agent_sdk.system_tools.tool_result import err, ok
from comate_agent_sdk.tools.decorator import Tool, tool
from comate_agent_sdk.tools.depends import Depends
from comate_agent_sdk.tools.system_context import SystemToolContext, get_system_tool_context

logger = logging.getLogger(__name__)

_READ_MIN_LIMIT = 1
_READ_DEFAULT_LIMIT = 2000
_LINE_TRUNCATE_CHARS = 2000
_READ_BINARY_SCAN_BYTES = 8192
_READ_FULL_FILE_MAX_BYTES = 256 * 1024
_READ_MAX_OUTPUT_TOKENS = 25_000
_READ_LINE_NUMBER_WIDTH = 6
_READ_BINARY_EXTENSIONS = frozenset(
    {
        ".7z",
        ".a",
        ".avi",
        ".bin",
        ".bmp",
        ".bz2",
        ".class",
        ".db",
        ".dll",
        ".dylib",
        ".eot",
        ".exe",
        ".flac",
        ".gif",
        ".gz",
        ".ico",
        ".jar",
        ".jpeg",
        ".jpg",
        ".mp3",
        ".mp4",
        ".o",
        ".ogg",
        ".otf",
        ".pdf",
        ".png",
        ".pyc",
        ".pyo",
        ".so",
        ".sqlite",
        ".tar",
        ".ttf",
        ".wav",
        ".wasm",
        ".webm",
        ".webp",
        ".woff",
        ".woff2",
        ".xz",
        ".zip",
    }
)

_BASH_DEFAULT_TIMEOUT_MS = 120_000
_BASH_MAX_TIMEOUT_MS = 600_000
_BASH_OUTPUT_DEFAULT_MAX_CHARS = 30_000
_BASH_DEFAULT_MAX_DISK_BYTES = 100 * 1024 * 1024
_READ_HARD_LINE_LIMIT = 50 * 1024
_MAX_EDIT_FILE_SIZE = 1024 * 1024 * 1024

_WEBFETCH_TIMEOUT_SECONDS = 20
_WEBFETCH_LLM_TIMEOUT_SECONDS = 30
_WEBFETCH_CACHE_TTL_SECONDS = 15 * 60
_WEBFETCH_MARKDOWN_TRUNCATE_CHARS = 50_000

_TEXT_SPILL_CHARS = 10_000
_BYTES_SPILL_LIMIT = 16 * 1024
_READ_TEXT_SPILL_CHARS = 30_000
_READ_BYTES_SPILL_LIMIT = 64 * 1024
_LIST_SPILL_LIMIT = 100
_GLOB_DEFAULT_HEAD_LIMIT = 100
_ARTIFACT_TTL_SECONDS = 3600
_GREP_CONTENT_PER_FILE_MAX_COUNT = 1000
_GREP_CONTENT_PARSE_MAX_CHARS = 200_000
_GREP_CONTENT_MATCH_EVENT_LIMIT = 5000
_SEARCH_RG_TIMEOUT_SECONDS = 20.0
_SEARCH_RG_TIMEOUT_SECONDS_WSL = 60.0
_SEARCH_RG_GRACE_SECONDS = 5.0
_SUBPROCESS_INTERRUPT_GRACE_SECONDS = 0.8
_MEMORY_INDEX_GUARD_MODE_ENV = "COMATE_MEMORY_INDEX_GUARD_MODE"
_MEMORY_INDEX_FREEFORM_STREAK_ENV = "COMATE_MEMORY_INDEX_FREEFORM_STREAK"
_MEMORY_INDEX_GUARD_DEFAULT_MODE = "warn"
_MEMORY_INDEX_FREEFORM_STREAK_DEFAULT = 3
_READ_REUSE_ENABLED_ENV = "COMATE_READ_REUSE_ENABLED"
_MEMORY_INDEX_ENTRY_RE = re.compile(
    r"^\s*(?:[-*+]|\d+\.)\s+@[^\s@]+\.md\s*-\s*.+\s*$"
)
_MEMORY_INDEX_LEGACY_ENTRY_RE = re.compile(
    r"^\s*(?:[-*+]|\d+\.)\s+`[^`]+\.md`\s*(?:\|\s*.+)?\s*$"
)
_MEMORY_INDEX_HEADING_RE = re.compile(r"^\s{0,3}#{1,6}\s+\S.*$")

_SEARCH_EXCLUDED_DIRS = (".bzr", ".git", ".hg", ".jj", ".sl", ".svn")

_RIPGREP_MISSING_MESSAGE = (
    "ripgrep (rg) binary not found. It is a pinned dependency of comate-agent-sdk "
    "and should be installed automatically by `uv sync`. If you see this error, "
    "run `uv sync` and verify that the current Python interpreter's scripts "
    "directory (sysconfig.get_path('scripts')) contains `rg` (`rg.exe` on Windows)."
)

@functools.cache
def _find_ripgrep() -> str | None:
    """Locate the ripgrep executable for Glob/Grep tools.

    Resolution order:
    1. ``shutil.which('rg')`` — covers any installation that puts rg on PATH.
    2. ``sysconfig.get_path('scripts')`` — the wheel-installed script directory
       of the **current** interpreter. The pinned ``ripgrep`` wheel ships
       ``rg[.exe]`` via the standard ``<pkg>.data/scripts`` mechanism, which
       ``pip``/``uv`` materialize into this directory. This fallback rescues
       environments where the venv scripts dir is not on PATH (common on
       Windows when the parent process launches Python without activating
       the venv).
    """
    path = shutil.which("rg")
    if path:
        return path

    scripts_dir = sysconfig.get_path("scripts")
    if scripts_dir:
        candidate = Path(scripts_dir) / ("rg.exe" if os.name == "nt" else "rg")
        if candidate.is_file():
            return str(candidate)

    return None

_WEBFETCH_CACHE: dict[str, dict[str, Any]] = {}
# Backward-compatible alias for existing tests/introspection.
_READ_REGISTRY_MEMORY = READ_REGISTRY_POLICY.memory
_READ_REUSE_MESSAGE = (
    "File unchanged since last read. The earlier Read result for this file and range is still current; refer to that instead of re-reading."
)
_READ_TOKEN_COUNTER = TokenCounter()

# P2-8: Cleanup counter for loop-local dicts (every 100 calls)
_CLEANUP_CALL_COUNTER = 0
_CLEANUP_FREQUENCY = 100



def _maybe_cleanup_loop_dicts() -> None:
    """Low-frequency cleanup of loop-local dicts to prevent memory leaks."""
    global _CLEANUP_CALL_COUNTER
    _CLEANUP_CALL_COUNTER += 1
    if _CLEANUP_CALL_COUNTER % _CLEANUP_FREQUENCY == 0:
        iu.cleanup_loop_local_dicts()
        READ_REGISTRY_POLICY.cleanup_stale_loops()

__all__ = [name for name in globals() if not name.startswith("__")]
