from __future__ import annotations

from ._common import *

class GrepInput(BaseModel):
    pattern: str = Field(description="Ripgrep regex pattern to search for, e.g. 'def\\s+\\w+', 'TODO|FIXME', 'class\\s+Foo'.")
    path: str | None = Field(default=None, description="Directory or file to search in. Defaults to project root when omitted.")
    glob: str | None = Field(default=None, description="Filter files by glob pattern, e.g. '*.py', '**/*.ts'. Applied on top of path.")
    type: str | None = Field(default=None, description="Filter by file type shorthand, e.g. 'py', 'js', 'rust'. Faster than glob for common types.")
    output_mode: Literal["content", "files_with_matches", "count"] = Field(default="files_with_matches", description="files_with_matches (default): return only file paths; content: return matching lines with context; count: return match count per file.")

    B: int | None = Field(default=None, alias="-B", ge=0, description="Lines of context before each match.")
    A: int | None = Field(default=None, alias="-A", ge=0, description="Lines of context after each match.")
    C: int | None = Field(default=None, alias="-C", ge=0, description="Lines of context before and after each match (shorthand for equal -B and -A).")
    context: int | None = Field(default=None, ge=0, description="Lines of context before and after each match. Takes precedence over -C/-A/-B when set.")
    i: bool | None = Field(default=None, alias="-i", description="Case-insensitive search.")
    n: bool | None = Field(default=True, alias="-n", description="Show line numbers in output (default: True).")

    head_limit: int = Field(
        default=250,
        ge=0,
        description=(
            "Limit output to first N lines/entries, equivalent to \"| head -N\". "
            "Works across all output modes: content (limits output lines), "
            "files_with_matches (limits file paths), count (limits count entries). "
            "Defaults to 250 when unspecified. "
            "Pass 0 for unlimited (use sparingly — large result sets waste context)."
        ),
    )
    offset: int = Field(default=0, ge=0, description="Skip the first N results before applying head_limit.")
    multiline: bool = Field(default=False, description="Enable multiline mode where patterns can span multiple lines.")

    model_config = {"populate_by_name": True, "extra": "forbid"}

    @staticmethod
    def _coerce_int(value: Any) -> Any:
        if value is None:
            return None
        if isinstance(value, bool):
            raise ValueError("boolean is not a valid integer")
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                raise PydanticUseDefault()
            return int(stripped)
        return value

    @staticmethod
    def _coerce_bool(value: Any) -> Any:
        if value is None:
            return None
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            stripped = value.strip().lower()
            if not stripped:
                raise PydanticUseDefault()
            if stripped in {"1", "true", "yes", "on"}:
                return True
            if stripped in {"0", "false", "no", "off"}:
                return False
            raise ValueError(f"cannot coerce {value!r} to bool")
        return value

    _coerce_int_fields = field_validator(
        "head_limit",
        "offset",
        "A",
        "B",
        "C",
        "context",
        mode="before",
    )(_coerce_int)
    _coerce_bool_fields = field_validator(
        "i",
        "n",
        "multiline",
        mode="before",
    )(_coerce_bool)

@tool(
    r"""A powerful search tool built on ripgrep

  Usage:
  - ALWAYS use Grep for search tasks. NEVER invoke `grep` or `rg` as a Bash command. The Grep tool has been optimized for correct permissions and access.
  - Supports full regex syntax (e.g., "log.*Error", "function\s+\w+")
  - Filter files with glob parameter (e.g., "*.js", "**/*.tsx") or type parameter (e.g., "js", "py", "rust")
  - Output modes: "content" shows matching lines, "files_with_matches" shows only file paths (default), "count" shows match counts
  - Use Agent tool for open-ended searches requiring multiple rounds
  - Pattern syntax: Uses ripgrep (not grep) - literal braces need escaping (use `interface\{\}` to find `interface{}` in Go code)
  - Multiline matching: By default patterns match within single lines only. For cross-line patterns like `struct \{[\s\S]*?field`, use `multiline: true`""",
    name="Grep",
    usage_rules=GREP_USAGE_RULES,
    observable_input_backfill=_backfill_search_path,
)
async def Grep(
    params: GrepInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    _maybe_cleanup_loop_dicts()  # P2-8: Periodic cleanup
    try:
        if _is_unc_like(params.path):
            search_path = Path(str(params.path).strip())
        else:
            search_path = resolve_for_search(
                user_path=params.path,
                project_root=_project_root(ctx),
                extra_read_roots=_extra_read_roots(ctx),
                workspace_root=_workspace_root(ctx),
            )
    except PathGuardError as exc:
        return _path_error_result(exc)

    if not _is_unc_like(str(search_path)) and not await _exists(search_path):
        return err(
            "NOT_FOUND",
            _build_search_path_not_found_message(
                user_path=params.path,
                resolved_path=search_path,
                ctx=ctx,
                tool_name="Grep",
            ),
        )

    run_controller = getattr(ctx, "run_controller", None)
    stop_event = threading.Event()
    unregister_interrupt_callback: Callable[[], None] | None = None
    if run_controller is not None:
        unregister_interrupt_callback = run_controller.register_interrupt_callback(
            lambda _reason, _count: stop_event.set()
        )
        if run_controller.is_interrupted:
            stop_event.set()

    rg_path = _find_ripgrep()
    if not rg_path:
        if unregister_interrupt_callback is not None:
            unregister_interrupt_callback()
        return err("RIPGREP_MISSING", _RIPGREP_MISSING_MESSAGE)

    root_refs = _allowed_roots(ctx)
    search_path_rel = to_safe_relpath(search_path.resolve(), roots=root_refs)
    timeout_seconds = _search_rg_timeout_seconds()

    def _grep_meta(**extra: Any) -> dict[str, Any]:
        meta = {
            "engine": "rg",
            "pattern": params.pattern,
            "path": params.path,
            "search_path": search_path_rel,
            "glob": params.glob,
            "type": params.type,
            "output_mode": params.output_mode,
            "head_limit": params.head_limit,
            "offset": params.offset,
            "context": params.context,
            "multiline": params.multiline,
            "timed_out": False,
            "retried_single_thread": False,
            "timeout_seconds": timeout_seconds,
        }
        meta.update(extra)
        return meta

    try:
        if params.output_mode == "files_with_matches":
            cmd = _build_rg_base_args(rg_path, params) + [
                "--sortr=modified",
                "-l",
                "--max-count",
                "1",
                *(["-e", params.pattern] if params.pattern.startswith("-") else [params.pattern]),
                str(search_path),
            ]
            rel_files: list[str] = []
            total = 0
            lower_bound = False

            def _on_file_line(raw_line: str) -> bool:
                nonlocal total, lower_bound
                line = raw_line.strip()
                if not line:
                    return True
                total += 1
                if total > params.offset and (params.head_limit == 0 or len(rel_files) < params.head_limit):
                    rel_files.append(
                        to_safe_relpath(Path(line).resolve(), roots=root_refs)
                    )
                if params.head_limit > 0 and total >= params.offset + params.head_limit + 1:
                    lower_bound = True
                    return False
                return True

            def _reset_stream_state() -> None:
                nonlocal total, lower_bound
                rel_files.clear()
                total = 0
                lower_bound = False

            stream, retried_single_thread = await _run_rg_streaming_lines(
                cmd,
                on_stdout_line=_on_file_line,
                reset_state_on_retry=_reset_stream_state,
                stdout_capture_max_chars=0,
                stderr_capture_max_chars=_TEXT_SPILL_CHARS,
                run_controller=run_controller,
            )
            if stream.returncode == 2:
                return err("INVALID_ARGUMENT", (stream.stderr_capture or stream.stdout_capture).strip() or "rg failed")
            if stream.timed_out and total == 0:
                return err(
                    "TIMEOUT",
                    f"Grep timed out after {timeout_seconds:.0f}s",
                    meta=_grep_meta(
                        timed_out=True,
                        retried_single_thread=retried_single_thread,
                    ),
                )
            if stream.returncode == 1 and total == 0:
                return ok(
                    data={
                        "files": [],
                        "count": 0,
                        "truncated": False,
                        "total_matches_is_lower_bound": False,
                    },
                    meta=_grep_meta(retried_single_thread=retried_single_thread),
                )
            if stream.returncode not in {0, 1} and not stream.stopped_early and not stream.timed_out:
                return err("INTERNAL", (stream.stderr_capture or stream.stdout_capture).strip() or "rg failed", retryable=True)

            if stream.timed_out:
                logger.warning(f"Grep files_with_matches timed out with partial results after {timeout_seconds:.0f}s")
            lower_bound = lower_bound or stream.stopped_early or stream.timed_out
            preview = rel_files
            return ok(
                data={
                    "files": preview,
                    "count": total,
                    "truncated": lower_bound or total > len(preview),
                    "truncated_reason": "timeout" if stream.timed_out else ("head_limit_reached" if lower_bound else None),
                    "total_matches_is_lower_bound": lower_bound,
                },
                meta=_grep_meta(
                    timed_out=stream.timed_out,
                    retried_single_thread=retried_single_thread,
                ),
            )

        if params.output_mode == "count":
            cmd = _build_rg_base_args(rg_path, params) + [
                "-c",
                *(["-e", params.pattern] if params.pattern.startswith("-") else [params.pattern]),
                str(search_path),
            ]
            counts: list[dict[str, Any]] = []
            total_matches = 0
            file_count = 0
            lower_bound = False

            def _on_count_line(raw_line: str) -> bool:
                nonlocal total_matches, file_count, lower_bound
                row = raw_line.strip()
                if not row:
                    return True
                try:
                    file_part, count_part = row.rsplit(":", 1)
                    count_value = int(count_part)
                except Exception:
                    return True
                file_count += 1
                total_matches += count_value
                if file_count > params.offset and (params.head_limit == 0 or len(counts) < params.head_limit):
                    counts.append(
                        {
                            "file": to_safe_relpath(Path(file_part).resolve(), roots=root_refs),
                            "count": count_value,
                        }
                    )
                if params.head_limit > 0 and file_count >= params.offset + params.head_limit + 1:
                    lower_bound = True
                    return False
                return True

            def _reset_count_state() -> None:
                nonlocal total_matches, file_count, lower_bound
                counts.clear()
                total_matches = 0
                file_count = 0
                lower_bound = False

            stream, retried_single_thread = await _run_rg_streaming_lines(
                cmd,
                on_stdout_line=_on_count_line,
                reset_state_on_retry=_reset_count_state,
                stdout_capture_max_chars=0,
                stderr_capture_max_chars=_TEXT_SPILL_CHARS,
                run_controller=run_controller,
            )
            if stream.returncode == 2:
                return err("INVALID_ARGUMENT", (stream.stderr_capture or stream.stdout_capture).strip() or "rg failed")
            if stream.timed_out and file_count == 0:
                return err(
                    "TIMEOUT",
                    f"Grep timed out after {timeout_seconds:.0f}s",
                    meta=_grep_meta(
                        timed_out=True,
                        retried_single_thread=retried_single_thread,
                    ),
                )
            if stream.returncode == 1 and file_count == 0:
                return ok(
                    data={
                        "counts": [],
                        "total_matches": 0,
                        "truncated": False,
                        "total_matches_is_lower_bound": False,
                    },
                    meta=_grep_meta(retried_single_thread=retried_single_thread),
                )
            if stream.returncode not in {0, 1} and not stream.stopped_early and not stream.timed_out:
                return err("INTERNAL", (stream.stderr_capture or stream.stdout_capture).strip() or "rg failed", retryable=True)

            if stream.timed_out:
                logger.warning(f"Grep count timed out with partial results after {timeout_seconds:.0f}s")
            lower_bound = lower_bound or stream.stopped_early or stream.timed_out
            preview = counts
            return ok(
                data={
                    "counts": preview,
                    "total_matches": total_matches,
                    "truncated": lower_bound or file_count > len(preview),
                    "truncated_reason": "timeout" if stream.timed_out else ("head_limit_reached" if lower_bound else None),
                    "total_matches_is_lower_bound": lower_bound,
                },
                meta=_grep_meta(
                    timed_out=stream.timed_out,
                    retried_single_thread=retried_single_thread,
                ),
            )

        before, after = _compute_context_window(params)
        per_file_limit = _GREP_CONTENT_PER_FILE_MAX_COUNT
        if params.head_limit > 0:
            per_file_limit = min(
                _GREP_CONTENT_PER_FILE_MAX_COUNT,
                max(1, params.offset + params.head_limit + 1),
            )
        per_file_max_count = min(
            _GREP_CONTENT_PER_FILE_MAX_COUNT,
            per_file_limit,
        )
        content_match_limit = _GREP_CONTENT_MATCH_EVENT_LIMIT
        if params.head_limit > 0:
            content_match_limit = min(
                _GREP_CONTENT_MATCH_EVENT_LIMIT,
                params.offset + params.head_limit + 1,
            )
        cmd = _build_rg_base_args(rg_path, params) + [
            "--json",
            "--max-count",
            str(per_file_max_count),
            *(["-e", params.pattern] if params.pattern.startswith("-") else [params.pattern]),
            str(search_path),
        ]
        matches: list[dict[str, Any]] = []
        line_refs: list[tuple[str, int]] = []
        total_matches = 0
        lower_bound = False

        def _on_rg_json_line(raw_line: str) -> bool:
            nonlocal total_matches, lower_bound
            row = raw_line.strip()
            if not row:
                return True

            try:
                evt = json.loads(row)
            except json.JSONDecodeError:
                return True
            if evt.get("type") != "match":
                return True

            data = evt.get("data", {})
            path_text = ((data.get("path") or {}).get("text") or "").strip()
            line_no = data.get("line_number")
            line_text = ((data.get("lines") or {}).get("text") or "").rstrip("\n")

            total_matches += 1
            if total_matches >= content_match_limit:
                lower_bound = True
                return False
            if total_matches <= params.offset:
                return True
            if params.head_limit > 0 and len(matches) >= params.head_limit:
                return True

            abs_path = str(Path(path_text).resolve()) if path_text else ""
            rel_file = to_safe_relpath(Path(abs_path), roots=root_refs) if abs_path else ""
            ln = int(line_no) if line_no is not None else 0

            matches.append(
                {
                    "file": rel_file,
                    "line_number": ln if params.n and line_no is not None else None,
                    "line": iu.truncate_line(line_text, _LINE_TRUNCATE_CHARS),
                    "before_context": None,
                    "after_context": None,
                }
            )
            line_refs.append((abs_path, ln))
            return True

        def _reset_content_state() -> None:
            nonlocal total_matches, lower_bound
            matches.clear()
            line_refs.clear()
            total_matches = 0
            lower_bound = False

        stream, retried_single_thread = await _run_rg_streaming_lines(
            cmd,
            on_stdout_line=_on_rg_json_line,
            reset_state_on_retry=_reset_content_state,
            stdout_capture_max_chars=_GREP_CONTENT_PARSE_MAX_CHARS,
            stderr_capture_max_chars=_TEXT_SPILL_CHARS,
            run_controller=run_controller,
        )

        if stream.returncode == 2:
            return err("INVALID_ARGUMENT", (stream.stderr_capture or stream.stdout_capture).strip() or "rg failed")
        if stream.timed_out and total_matches == 0:
            return err(
                "TIMEOUT",
                f"Grep timed out after {timeout_seconds:.0f}s",
                meta=_grep_meta(
                    timed_out=True,
                    retried_single_thread=retried_single_thread,
                ),
            )
        if stream.returncode == 1 and total_matches == 0:
            return ok(
                data={"matches": [], "total_matches": 0, "truncated": False},
                meta=_grep_meta(retried_single_thread=retried_single_thread),
            )
        if stream.returncode not in {0, 1} and not stream.stopped_early and not stream.timed_out:
            return err("INTERNAL", (stream.stderr_capture or stream.stdout_capture).strip() or "rg failed", retryable=True)

        if stream.timed_out:
            logger.warning(f"Grep content timed out with partial results after {timeout_seconds:.0f}s")
        if stream.stopped_early or stream.timed_out:
            lower_bound = True

        if (before > 0 or after > 0) and matches:
            by_file: dict[str, list[tuple[int, int]]] = defaultdict(list)
            for idx, (abs_path, line_no) in enumerate(line_refs):
                if not abs_path or line_no <= 0:
                    continue
                by_file[abs_path].append((idx, line_no))

            for abs_path, refs in by_file.items():
                try:
                    file_lines = await _read_text(Path(abs_path))
                except Exception:
                    continue
                lines = file_lines.splitlines()
                total_lines = len(lines)
                for idx, line_no in refs:
                    ln0 = line_no - 1
                    b0 = max(0, ln0 - before)
                    a1 = min(total_lines, ln0 + 1 + after)
                    matches[idx]["before_context"] = [iu.truncate_line(s, _LINE_TRUNCATE_CHARS) for s in lines[b0:ln0]]
                    matches[idx]["after_context"] = [iu.truncate_line(s, _LINE_TRUNCATE_CHARS) for s in lines[ln0 + 1 : a1]]

        matches_by_file: dict[str, dict[str, Any]] = {}
        for match in matches:
            file = match["file"]
            if file not in matches_by_file:
                matches_by_file[file] = {
                    "file": file,
                    "match_count": 0,
                    "matches": [],
                }
            match_entry = {k: v for k, v in match.items() if k != "file"}
            matches_by_file[file]["matches"].append(match_entry)
            matches_by_file[file]["match_count"] += 1

        truncated = total_matches > len(matches) or lower_bound
        avg_matches_per_file = total_matches / max(len(matches_by_file), 1)
        top_files = sorted(
            [(file, data["match_count"]) for file, data in matches_by_file.items()],
            key=lambda x: x[1],
            reverse=True,
        )[:5]

        data = {
            "matches_by_file": matches_by_file,
            "total_matches": total_matches,
            "file_count": len(matches_by_file),
            "truncated": truncated,
            "truncated_reason": "timeout" if stream.timed_out else ("head_limit_reached" if truncated else None),
            "total_matches_is_lower_bound": lower_bound,
            "summary": {
                "files_with_matches": len(matches_by_file),
                "avg_matches_per_file": round(avg_matches_per_file, 1),
                "top_files": top_files,
            },
        }

        raw_capture = stream.stdout_capture
        if truncated or stream.stdout_capture_truncated or len(raw_capture.encode("utf-8")) > _BYTES_SPILL_LIMIT:
            artifact = await iu.spill_text(
                artifact_store=_artifact_store(ctx),
                namespace="grep_content",
                text=raw_capture,
                mime="text/plain",
                ttl_seconds=_ARTIFACT_TTL_SECONDS,
            )
            data["artifact"] = artifact
            if stream.stdout_capture_truncated:
                data["raw_output_truncated"] = True

        return ok(
            data=data,
            meta=_grep_meta(
                timed_out=stream.timed_out,
                retried_single_thread=retried_single_thread,
            ),
        )
    except asyncio.CancelledError:
        stop_event.set()
        raise
    finally:
        if unregister_interrupt_callback is not None:
            unregister_interrupt_callback()
