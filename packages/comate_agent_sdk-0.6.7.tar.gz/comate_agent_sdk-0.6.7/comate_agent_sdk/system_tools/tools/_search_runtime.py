from __future__ import annotations

from ._base import *
from ._context import *
from ._file_io import *
from ._write_runtime import *

def _compute_context_window(params: GrepInput) -> tuple[int, int]:
    if params.context is not None:
        context = max(0, int(params.context))
        return context, context
    before = params.B or 0
    after = params.A or 0
    if params.C is not None:
        before = int(params.C)
        after = int(params.C)
    return max(0, int(before)), max(0, int(after))

def _split_glob_patterns(glob_value: str | None) -> list[str]:
    if not glob_value:
        return []
    patterns: list[str] = []
    for chunk in glob_value.split():
        patterns.extend(part for part in chunk.split(",") if part)
    return patterns

def _extract_glob_base_directory(pattern: str) -> tuple[str, str]:
    match = re.search(r"[*?[{]", pattern)
    if match is None:
        return str(Path(pattern).parent), Path(pattern).name

    static_prefix = pattern[: match.start()]
    last_sep_index = max(static_prefix.rfind("/"), static_prefix.rfind(os.sep))
    if last_sep_index == -1:
        return "", pattern

    base_dir = static_prefix[:last_sep_index]
    relative_pattern = pattern[last_sep_index + 1 :]
    if not base_dir and last_sep_index == 0:
        base_dir = os.sep
    return base_dir, relative_pattern

def _env_truthy(name: str, *, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}

def _read_reuse_enabled() -> bool:
    return _env_truthy(_READ_REUSE_ENABLED_ENV, default=True)

@functools.cache
def _is_wsl() -> bool:
    """Detect Windows Subsystem for Linux by inspecting /proc/version.

    Cached because the underlying value is fixed for the lifetime of the
    process. Falls back to ``False`` on any read error (non-Linux hosts,
    sandboxed envs without /proc, etc.).
    """
    try:
        with open("/proc/version", "r", encoding="utf-8", errors="ignore") as fh:
            content = fh.read().lower()
    except OSError:
        return False
    return "microsoft" in content or "wsl" in content

def _default_search_rg_timeout_seconds() -> float:
    return _SEARCH_RG_TIMEOUT_SECONDS_WSL if _is_wsl() else _SEARCH_RG_TIMEOUT_SECONDS

def _search_rg_timeout_seconds() -> float:
    default = _default_search_rg_timeout_seconds()
    raw = os.getenv("CLAUDE_CODE_GLOB_TIMEOUT_SECONDS")
    if raw is None or not raw.strip():
        return default
    try:
        parsed = float(raw)
    except ValueError:
        return default
    return parsed if parsed > 0 else default

def _path_looks_like_glob(path: str | None) -> bool:
    return bool(path) and any(ch in path for ch in "*?[]{}")


_IS_WINDOWS = os.name == "nt"

def _is_unc_like(user_path: str | None) -> bool:
    if not _IS_WINDOWS:
        return False
    if not user_path:
        return False
    return user_path.strip().startswith(("\\\\", "//"))

def _build_search_path_not_found_message(
    *,
    user_path: str | None,
    resolved_path: Path,
    ctx: SystemToolContext,
    tool_name: str,
) -> str:
    displayed_path = user_path or str(resolved_path)
    suggestion = suggest_path_under_roots(
        user_path=user_path or str(resolved_path),
        project_root=_project_root(ctx),
        workspace_root=_workspace_root(ctx),
        extra_read_roots=_extra_read_roots(ctx),
    )
    message = f"Search path not found: {displayed_path}."
    if suggestion:
        message += f" Did you mean {suggestion}?"
    if _path_looks_like_glob(user_path):
        if tool_name == "Grep":
            message += " path must be an existing file or directory; put wildcards in glob instead."
        elif tool_name == "Glob":
            message += " path must be an existing directory; keep wildcards in pattern instead."
        else:
            message += " path must be an existing directory; remove wildcard characters from path."
    return message

def _resolve_glob_search_target(
    *,
    params: GlobInput,
    ctx: SystemToolContext,
) -> tuple[Path, str]:
    if _is_unc_like(params.pattern):
        base_dir, relative_pattern = _extract_glob_base_directory(params.pattern)
        return Path(base_dir or os.sep), relative_pattern

    if Path(params.pattern).is_absolute():
        base_dir, relative_pattern = _extract_glob_base_directory(params.pattern)
        search_dir = resolve_for_search(
            user_path=base_dir or os.sep,
            project_root=_project_root(ctx),
            workspace_root=_workspace_root(ctx),
            extra_read_roots=_extra_read_roots(ctx),
        )
        return search_dir, relative_pattern

    if _is_unc_like(params.path):
        return Path(str(params.path).strip()), params.pattern

    search_dir = resolve_for_search(
        user_path=params.path,
        project_root=_project_root(ctx),
        workspace_root=_workspace_root(ctx),
        extra_read_roots=_extra_read_roots(ctx),
    )
    return search_dir, params.pattern

def _glob_match_path(path: Path, *, search_root: Path, pattern: str) -> bool:
    rel = path.relative_to(search_root).as_posix()
    return globmatch(rel, pattern, flags=_GLOB_FLAGS) or globmatch(path.name, pattern, flags=_GLOB_FLAGS)

def _glob_sort_key(path: Path, *, roots: list[Path]) -> tuple[float, str]:
    try:
        mtime = path.stat().st_mtime_ns
    except OSError:
        mtime = 0
    return (mtime, to_safe_relpath(path.resolve(), roots=roots))

def _build_glob_rg_args(rg_path: str, pattern: str) -> list[str]:
    no_ignore = _env_truthy("CLAUDE_CODE_GLOB_NO_IGNORE", default=True)
    hidden = _env_truthy("CLAUDE_CODE_GLOB_HIDDEN", default=True)
    args = [
        rg_path,
        "--files",
        "--sort=modified",
        "--glob",
        pattern,
    ]
    if hidden:
        args.append("--hidden")
    if no_ignore:
        args.append("--no-ignore")
    for excluded_dir in _SEARCH_EXCLUDED_DIRS:
        args.extend(["--glob", f"!{excluded_dir}"])
    return args


_SearchItemT = TypeVar("_SearchItemT")

def _apply_search_pagination(
    items: list[_SearchItemT], *, head_limit: int, offset: int
) -> tuple[list[_SearchItemT], bool]:
    if head_limit == 0:
        return items[offset:], False
    return items[offset : offset + head_limit], len(items) > offset + head_limit

def _build_rg_base_args(rg_path: str, params: GrepInput) -> list[str]:
    args: list[str] = [rg_path, "--color=never", "--max-columns", "500", "--hidden"]
    if params.i:
        args.append("-i")
    for excluded_dir in _SEARCH_EXCLUDED_DIRS:
        args.extend(["--glob", f"!{excluded_dir}"])
    for glob_pattern in _split_glob_patterns(params.glob):
        args.extend(["--glob", glob_pattern])
    if params.type:
        args.extend(["--type", params.type])
    if params.multiline:
        args.extend(["-U", "--multiline-dotall"])
    return args

async def _run_subprocess(args: list[str], *, cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    return await iu.io_call(
        subprocess.run,
        args,
        capture_output=True,
        text=True,
        encoding="utf-8",
        cwd=str(cwd) if cwd is not None else None,
    )

def _append_bounded_text(
    chunks: list[str],
    text: str,
    *,
    current_chars: int,
    max_chars: int,
) -> tuple[int, bool]:
    if max_chars <= 0:
        return current_chars, True
    if current_chars >= max_chars:
        return current_chars, True

    remain = max_chars - current_chars
    if len(text) <= remain:
        chunks.append(text)
        return current_chars + len(text), False

    chunks.append(text[:remain])
    return max_chars, True

@dataclass
class _StreamingSubprocessResult:
    returncode: int
    stdout_capture: str
    stderr_capture: str
    stdout_capture_truncated: bool
    stderr_capture_truncated: bool
    stopped_early: bool
    timed_out: bool

async def _run_subprocess_streaming_lines(
    args: list[str],
    *,
    cwd: Path | None = None,
    on_stdout_line: Callable[[str], bool] | None = None,
    stdout_capture_max_chars: int = _GREP_CONTENT_PARSE_MAX_CHARS,
    stderr_capture_max_chars: int = _TEXT_SPILL_CHARS,
    run_controller: Any | None = None,
    timeout_seconds: float | None = None,
    grace_seconds: float = _SUBPROCESS_INTERRUPT_GRACE_SECONDS,
) -> _StreamingSubprocessResult:
    create_kwargs: dict[str, Any] = {
        "stdout": asyncio.subprocess.PIPE,
        "stderr": asyncio.subprocess.PIPE,
        "cwd": str(cwd) if cwd is not None else None,
    }
    if os.name != "nt":
        create_kwargs["start_new_session"] = True

    proc = await asyncio.create_subprocess_exec(*args, **create_kwargs)

    assert proc.stdout is not None
    assert proc.stderr is not None

    stdout_chunks: list[str] = []
    stderr_chunks: list[str] = []
    stdout_chars = 0
    stderr_chars = 0
    stdout_capture_truncated = False
    stderr_capture_truncated = False
    stopped_early = False
    interrupted = False
    unregister_interrupt_callback: Callable[[], None] | None = None

    def _send_interrupt_signal(*, force: bool, mark_interrupted: bool) -> None:
        nonlocal interrupted
        if proc.returncode is not None:
            return

        if mark_interrupted:
            interrupted = True

        try:
            if os.name == "nt":
                if force:
                    proc.kill()
                else:
                    proc.terminate()
                return

            sig = signal.SIGKILL if force else signal.SIGTERM
            if proc.pid is not None:
                os.killpg(proc.pid, sig)
        except ProcessLookupError:
            return
        except Exception as exc:
            logger.warning(f"failed to signal subprocess: {exc}", exc_info=True)

    async def _terminate_process_with_grace(*, mark_interrupted: bool) -> None:
        _send_interrupt_signal(force=False, mark_interrupted=mark_interrupted)
        if proc.returncode is not None:
            return
        try:
            await asyncio.wait_for(
                proc.wait(),
                timeout=grace_seconds,
            )
            return
        except asyncio.TimeoutError:
            pass

        _send_interrupt_signal(force=True, mark_interrupted=mark_interrupted)
        if proc.returncode is not None:
            return
        try:
            await asyncio.wait_for(
                proc.wait(),
                timeout=grace_seconds,
            )
        except asyncio.TimeoutError:
            logger.warning("subprocess did not exit after SIGKILL fallback")

    if run_controller is not None:
        def _on_interrupt(reason: str, interrupt_count: int) -> None:
            force = (
                interrupt_count >= 2
                or str(reason).strip().lower().endswith("force")
            )
            _send_interrupt_signal(force=force, mark_interrupted=True)

        unregister_interrupt_callback = run_controller.register_interrupt_callback(
            _on_interrupt
        )
        if run_controller.is_interrupted:
            _on_interrupt(
                str(run_controller.reason or "user"),
                max(1, int(run_controller.interrupt_count)),
            )

    async def _consume_stdout() -> None:
        nonlocal stdout_chars, stdout_capture_truncated, stopped_early

        while True:
            raw = await proc.stdout.readline()
            if not raw:
                break
            text = raw.decode("utf-8", errors="replace")

            stdout_chars, clipped = _append_bounded_text(
                stdout_chunks,
                text,
                current_chars=stdout_chars,
                max_chars=stdout_capture_max_chars,
            )
            stdout_capture_truncated = stdout_capture_truncated or clipped

            if stopped_early:
                continue
            if on_stdout_line is None:
                continue

            row = text.rstrip("\n")
            should_continue = bool(on_stdout_line(row))
            if not should_continue:
                stopped_early = True
                _send_interrupt_signal(force=False, mark_interrupted=False)

    async def _consume_stderr() -> None:
        nonlocal stderr_chars, stderr_capture_truncated
        while True:
            raw = await proc.stderr.read(4096)
            if not raw:
                break
            text = raw.decode("utf-8", errors="replace")
            stderr_chars, clipped = _append_bounded_text(
                stderr_chunks,
                text,
                current_chars=stderr_chars,
                max_chars=stderr_capture_max_chars,
            )
            stderr_capture_truncated = stderr_capture_truncated or clipped

    stdout_task = asyncio.create_task(_consume_stdout())
    stderr_task = asyncio.create_task(_consume_stderr())
    wait_task = asyncio.create_task(proc.wait())
    timed_out = False

    try:
        gather_task = asyncio.gather(stdout_task, stderr_task, wait_task)
        if timeout_seconds is not None:
            await asyncio.wait_for(gather_task, timeout=timeout_seconds)
        else:
            await gather_task
        returncode = wait_task.result()
    except asyncio.TimeoutError:
        timed_out = True
        logger.warning(f"subprocess timed out after {timeout_seconds}s: {' '.join(args[:6])}")
        await _terminate_process_with_grace(mark_interrupted=False)
        await asyncio.gather(stdout_task, stderr_task, return_exceptions=True)
        returncode = proc.returncode if proc.returncode is not None else 124
    except asyncio.CancelledError:
        await _terminate_process_with_grace(mark_interrupted=True)
        stdout_task.cancel()
        stderr_task.cancel()
        wait_task.cancel()
        raise
    finally:
        if unregister_interrupt_callback is not None:
            unregister_interrupt_callback()

    if interrupted:
        raise asyncio.CancelledError

    return _StreamingSubprocessResult(
        returncode=int(returncode),
        stdout_capture="".join(stdout_chunks),
        stderr_capture="".join(stderr_chunks),
        stdout_capture_truncated=stdout_capture_truncated,
        stderr_capture_truncated=stderr_capture_truncated,
        stopped_early=stopped_early,
        timed_out=timed_out,
    )


_EAGAIN_OS_ERROR_CODES: tuple[str, ...] = ("os error 11", "os error 35")

def _is_eagain_error(stderr: str) -> bool:
    if "Resource temporarily unavailable" in stderr:
        return True
    return any(code in stderr for code in _EAGAIN_OS_ERROR_CODES)

async def _run_rg_streaming_lines(
    args: list[str],
    *,
    cwd: Path | None = None,
    on_stdout_line: Callable[[str], bool] | None = None,
    reset_state_on_retry: Callable[[], None] | None = None,
    stdout_capture_max_chars: int = _GREP_CONTENT_PARSE_MAX_CHARS,
    stderr_capture_max_chars: int = _TEXT_SPILL_CHARS,
    run_controller: Any | None = None,
) -> tuple[_StreamingSubprocessResult, bool]:
    timeout_seconds = _search_rg_timeout_seconds()
    stream = await _run_subprocess_streaming_lines(
        args,
        cwd=cwd,
        on_stdout_line=on_stdout_line,
        stdout_capture_max_chars=stdout_capture_max_chars,
        stderr_capture_max_chars=stderr_capture_max_chars,
        run_controller=run_controller,
        timeout_seconds=timeout_seconds,
        grace_seconds=_SEARCH_RG_GRACE_SECONDS,
    )
    retried_single_thread = False
    if (
        not stream.timed_out
        and stream.returncode not in {0, 1}
        and _is_eagain_error(stream.stderr_capture)
    ):
        retried_single_thread = True
        retry_args = list(args)
        retry_args[1:1] = ["-j", "1"]
        logger.warning(f"ripgrep hit EAGAIN; retrying single-threaded: {' '.join(args[:6])}")
        if reset_state_on_retry is not None:
            reset_state_on_retry()
        stream = await _run_subprocess_streaming_lines(
            retry_args,
            cwd=cwd,
            on_stdout_line=on_stdout_line,
            stdout_capture_max_chars=stdout_capture_max_chars,
            stderr_capture_max_chars=stderr_capture_max_chars,
            run_controller=run_controller,
            timeout_seconds=timeout_seconds,
            grace_seconds=_SEARCH_RG_GRACE_SECONDS,
        )
    return stream, retried_single_thread

def _backfill_search_path(args: dict[str, Any]) -> None:
    path = args.get("path")
    if path is None or (isinstance(path, str) and not path.strip()):
        args["path"] = "."

__all__ = [name for name in globals() if not name.startswith("__")]
