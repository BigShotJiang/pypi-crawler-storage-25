from __future__ import annotations

from ._common import *

class QuestionOption(BaseModel):
    label: str = Field(max_length=50, description="Display text for this option (1-5 words)")
    description: str = Field(description="Explanation of this option")

    model_config = {"extra": "forbid"}

class Question(BaseModel):
    question: str = Field(description="The complete question to ask the user")
    header: str = Field(max_length=12, description="Short label displayed as a chip/tag (max 12 chars)")
    options: list[QuestionOption] = Field(min_length=2, max_length=4, description="Available options (2-4)")
    multiSelect: bool = Field(default=False, description="If True, user can select multiple options. Default False (single select only).")

    model_config = {"extra": "forbid"}

class AskUserQuestionInput(BaseModel):
    questions: list[Question] = Field(min_length=1, max_length=4, description="Questions to ask")

    model_config = {"extra": "forbid"}

    @model_validator(mode="before")
    @classmethod
    def _coerce_stringified_questions(cls, data: Any) -> Any:
        """Defense-in-depth: 修复 LLM 将 questions 数组字符串化的问题。"""
        if not isinstance(data, dict):
            return data
        questions = data.get("questions")
        if isinstance(questions, str):
            try:
                parsed = json.loads(questions)
                if isinstance(parsed, list):
                    data["questions"] = parsed
            except (json.JSONDecodeError, TypeError):
                pass
        return data

@tool(
    "Use this tool ONLY during active task execution when you need structured input (requirements, choices, clarification). Never use for: greetings, casual chat, or when no task has been assigned. If uncertain, respond conversationally instead. Hard rule: AskUserQuestion must be called alone (no other tool calls in the same response). Tool result means waiting for user input; user answers come in the next user message.",
    name="AskUserQuestion",
    usage_rules=ASK_USER_QUESTION_USAGE_RULES,
    prompt_hint="Must be the ONLY tool call in a response. Calling it alongside other tools causes runtime error.",
)
async def AskUserQuestion(
    params: AskUserQuestionInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    try:
        questions_data = [q.model_dump(mode="json") for q in params.questions]
        logger.info(f"AskUserQuestion prepared {len(questions_data)} question(s)")
        return ok(
            data={
                "status": "waiting_for_input",
                "questions": questions_data,
            },
            message=f"Prepared {len(questions_data)} question(s) for user",
            meta={
                "status": "waiting_for_input",
                "question_count": len(questions_data),
            },
        )
    except Exception as exc:
        logger.error(f"AskUserQuestion failed: {exc}", exc_info=True)
        return err("INTERNAL", f"AskUserQuestion failed: {exc}")
