from __future__ import annotations

from ._common import *

class GlobInput(BaseModel):
    pattern: str = Field(description="Glob pattern to match file paths, e.g. '**/*.py' (recursive), '*.json' (current dir), 'src/**/*.ts'.")
    path: str | None = Field(default=None, description="Directory to search in. Defaults to project root when omitted.")

    model_config = {"extra": "forbid"}

@tool(
    r"""- Fast file pattern matching tool that works with any codebase size
- Supports glob patterns like "**/*.js" or "src/**/*.ts"
- Returns matching file paths sorted by modification time
- Use this tool when you need to find files by name patterns
- When you are doing an open ended search that may require multiple rounds of globbing and grepping, use the Agent tool instead""",
    name="Glob",
    usage_rules=GLOB_USAGE_RULES,
    observable_input_backfill=_backfill_search_path,
)
async def Glob(
    params: GlobInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    try:
        search_dir, search_pattern = _resolve_glob_search_target(params=params, ctx=ctx)
    except PathGuardError as exc:
        return _path_error_result(exc)

    if not _is_unc_like(str(search_dir)) and not await _exists(search_dir):
        return err(
            "NOT_FOUND",
            _build_search_path_not_found_message(
                user_path=params.path,
                resolved_path=search_dir,
                ctx=ctx,
                tool_name="Glob",
            ),
        )

    run_controller = getattr(ctx, "run_controller", None)
    stop_event = threading.Event()
    unregister_interrupt_callback: Callable[[], None] | None = None
    if run_controller is not None:
        unregister_interrupt_callback = run_controller.register_interrupt_callback(
            lambda _reason, _count: stop_event.set()
        )
        if run_controller.is_interrupted:
            stop_event.set()

    root_refs = _allowed_roots(ctx)
    rg_path = _find_ripgrep()
    timeout_seconds = _search_rg_timeout_seconds()

    try:
        if search_dir.is_file():
            candidates = [search_dir] if _glob_match_path(search_dir, search_root=search_dir.parent, pattern=search_pattern) else []
            candidates = sorted(candidates, key=lambda item: _glob_sort_key(item, roots=root_refs))
            matches = [to_safe_relpath(p.resolve(), roots=root_refs) for p in candidates]
        elif rg_path:
            cmd = _build_glob_rg_args(rg_path, search_pattern) + ["."]
            rel_files: list[str] = []
            total = 0
            lower_bound = False

            def _on_file_line(raw_line: str) -> bool:
                nonlocal total, lower_bound
                line = raw_line.strip()
                if not line:
                    return True
                total += 1
                if total <= _GLOB_DEFAULT_HEAD_LIMIT:
                    normalized = line[2:] if line.startswith("./") else line
                    rel_files.append(
                        to_safe_relpath((search_dir / normalized).resolve(), roots=root_refs)
                    )
                if total >= _GLOB_DEFAULT_HEAD_LIMIT + 1:
                    lower_bound = True
                    return False
                return True

            def _reset_stream_state() -> None:
                nonlocal total, lower_bound
                rel_files.clear()
                total = 0
                lower_bound = False

            stream, retried_single_thread = await _run_rg_streaming_lines(
                cmd,
                cwd=search_dir,
                on_stdout_line=_on_file_line,
                reset_state_on_retry=_reset_stream_state,
                stdout_capture_max_chars=0,
                stderr_capture_max_chars=_TEXT_SPILL_CHARS,
                run_controller=run_controller,
            )
            if stream.returncode == 2:
                return err("INVALID_ARGUMENT", (stream.stderr_capture or stream.stdout_capture).strip() or "rg failed")
            if stream.timed_out and total == 0:
                return err(
                    "TIMEOUT",
                    f"Glob timed out after {timeout_seconds:.0f}s",
                    meta={
                        "engine": "rg",
                        "pattern": params.pattern,
                        "path": params.path,
                        "search_path": to_safe_relpath(search_dir, roots=root_refs),
                        "head_limit": _GLOB_DEFAULT_HEAD_LIMIT,
                        "count_is_lower_bound": False,
                        "timed_out": True,
                        "retried_single_thread": retried_single_thread,
                        "timeout_seconds": timeout_seconds,
                    },
                )
            if stream.returncode == 1 and total == 0:
                return ok(
                    data={
                        "matches": [],
                        "count": 0,
                        "count_is_lower_bound": False,
                        "search_path": to_safe_relpath(search_dir, roots=root_refs),
                        "truncated": False,
                        "truncated_reason": None,
                        "summary": {"total_files": 0, "file_extensions": {}},
                    },
                    meta={
                        "engine": "rg",
                        "pattern": params.pattern,
                        "path": params.path,
                        "search_path": to_safe_relpath(search_dir, roots=root_refs),
                        "head_limit": _GLOB_DEFAULT_HEAD_LIMIT,
                        "count_is_lower_bound": False,
                        "timed_out": False,
                        "retried_single_thread": retried_single_thread,
                        "timeout_seconds": timeout_seconds,
                    },
                )
            if stream.returncode not in {0, 1} and not stream.stopped_early and not stream.timed_out:
                return err("INTERNAL", (stream.stderr_capture or stream.stdout_capture).strip() or "rg failed", retryable=True)

            if stream.timed_out:
                logger.warning(f"Glob timed out with partial results after {timeout_seconds:.0f}s")
            count_is_lower_bound = lower_bound or stream.stopped_early or stream.timed_out
            total_count = total
            matches = rel_files
            glob_meta = {
                "engine": "rg",
                "timed_out": stream.timed_out,
                "retried_single_thread": retried_single_thread,
                "timeout_seconds": timeout_seconds,
            }
        else:
            return err("RIPGREP_MISSING", _RIPGREP_MISSING_MESSAGE)
    except asyncio.CancelledError:
        stop_event.set()
        raise
    finally:
        if unregister_interrupt_callback is not None:
            unregister_interrupt_callback()

    if stop_event.is_set():
        raise asyncio.CancelledError

    if search_dir.is_file():
        total_count = len(matches)
        count_is_lower_bound = False
        glob_meta = {
            "engine": "python",
            "timed_out": False,
            "retried_single_thread": False,
            "timeout_seconds": None,
        }

    preview = matches[: _GLOB_DEFAULT_HEAD_LIMIT]
    truncated = count_is_lower_bound or total_count > len(preview)

    # P1-5: Semantic summary
    file_extensions: dict[str, int] = {}
    for m in preview:
        ext = Path(m).suffix or "(no extension)"
        file_extensions[ext] = file_extensions.get(ext, 0) + 1

    data: dict[str, Any] = {
        "matches": preview,
        "count": total_count,
        "count_is_lower_bound": count_is_lower_bound,
        "search_path": to_safe_relpath(search_dir, roots=root_refs),
        "truncated": truncated,
        "truncated_reason": "timeout" if glob_meta["timed_out"] else ("head_limit_reached" if truncated else None),
        "summary": {
            "total_files": total_count,
            "file_extensions": dict(sorted(file_extensions.items(), key=lambda x: x[1], reverse=True)[:10]),
        },
    }

    return ok(
        data=data,
        meta={
            "pattern": params.pattern,
            "path": params.path,
            "search_path": data["search_path"],
            "head_limit": _GLOB_DEFAULT_HEAD_LIMIT,
            "count_is_lower_bound": count_is_lower_bound,
            **glob_meta,
        },
    )
