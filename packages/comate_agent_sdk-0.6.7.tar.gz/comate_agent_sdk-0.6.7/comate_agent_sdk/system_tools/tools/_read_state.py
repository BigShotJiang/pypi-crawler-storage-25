from __future__ import annotations

from ._base import *
from ._context import *

async def _mark_read(ctx: SystemToolContext, path: Path) -> None:
    """Mark file as read (without version tracking, for backward compatibility)."""
    await READ_REGISTRY_POLICY.mark_read(
        session_root=_session_root_from_ctx(ctx),
        session_id=ctx.session_id,
        path=path,
    )

async def _mark_read_with_version(
    ctx: SystemToolContext,
    path: Path,
    version_token: str,
) -> None:
    """Mark file as read with version tracking (for Edit conflict detection)."""
    await READ_REGISTRY_POLICY.mark_read_with_version(
        session_root=_session_root_from_ctx(ctx),
        session_id=ctx.session_id,
        path=path,
        version_token=version_token,
    )

async def _mark_read_range_with_version(
    ctx: SystemToolContext,
    path: Path,
    version_token: str,
    *,
    offset_line: int,
    limit_lines: int | None,
) -> None:
    await READ_REGISTRY_POLICY.mark_read_range(
        session_root=_session_root_from_ctx(ctx),
        session_id=ctx.session_id,
        path=path,
        version_token=version_token,
        offset_line=offset_line,
        limit_lines=limit_lines,
    )

async def _require_read(ctx: SystemToolContext, path: Path) -> bool:
    return await READ_REGISTRY_POLICY.has_read(
        session_root=_session_root_from_ctx(ctx),
        session_id=ctx.session_id,
        path=path,
    )

async def _check_version_conflict(
    ctx: SystemToolContext,
    path: Path,
    current_version_token: str,
) -> bool:
    """Check if file has been modified externally since last Read.

    Returns:
        True if conflict detected (version mismatch), False otherwise
    """
    has_read, stored_version_token = await READ_REGISTRY_POLICY.has_read_with_version(
        session_root=_session_root_from_ctx(ctx),
        session_id=ctx.session_id,
        path=path,
    )
    if not has_read:
        return False  # Not read yet, no conflict
    if stored_version_token is None:
        return False  # Read without version tracking (old behavior), no conflict check
    return stored_version_token != current_version_token  # Conflict if versions differ

async def _has_read_range_with_version(
    ctx: SystemToolContext,
    path: Path,
    version_token: str,
    *,
    offset_line: int,
    limit_lines: int | None,
) -> bool:
    return await READ_REGISTRY_POLICY.has_read_range(
        session_root=_session_root_from_ctx(ctx),
        session_id=ctx.session_id,
        path=path,
        version_token=version_token,
        offset_line=offset_line,
        limit_lines=limit_lines,
    )

async def _invalidate_read_ranges(ctx: SystemToolContext, path: Path) -> None:
    await READ_REGISTRY_POLICY.clear_read_ranges_for_path(
        session_root=_session_root_from_ctx(ctx),
        session_id=ctx.session_id,
        path=path,
    )

__all__ = [name for name in globals() if not name.startswith("__")]
