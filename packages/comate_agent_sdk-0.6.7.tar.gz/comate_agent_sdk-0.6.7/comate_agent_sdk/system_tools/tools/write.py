from __future__ import annotations

from ._common import *

class WriteInput(BaseModel):
    file_path: str = Field(description="Target file path")
    content: str = Field(description="Content to write")
    mode: Literal["overwrite", "append"] = Field(default="overwrite", description="overwrite (default): replaces the entire file content; append: adds content to the end of the file.")
    encoding: str = Field(default="utf-8", description="File encoding (default: utf-8).")

    model_config = {"extra": "forbid"}

def _normalize_write_input_for_path(path: Path, content: str) -> str:
    if path.suffix.lower() in {".md", ".mdx"}:
        return content
    return iu.strip_trailing_whitespace(content)

@tool(
    "Create file or overwrite/append entire contents. Existing files: MUST Read first. Use Edit for targeted replacements.",
    name="Write",
    usage_rules=WRITE_USAGE_RULES,
)
async def Write(
    params: WriteInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    try:
        path = await _resolve_write_path(user_path=params.file_path, ctx=ctx)
    except PathGuardError as exc:
        return _path_error_result(exc)

    root_refs = _allowed_roots(ctx)
    normalized_content = _normalize_write_input_for_path(path, params.content)
    before_content: str | None = None
    memory_index_warning: str | None = None
    async with iu.file_lock(path):
        existed = await _exists(path)
        if existed and await _is_dir(path):
            return err("IS_DIRECTORY", f"Path is a directory: {params.file_path}")
        if existed and not await _is_file(path):
            return err("PERMISSION_DENIED", f"Path is not a regular file: {params.file_path}")
        if existed and not await _require_read(ctx, path):
            return err("PRECONDITION_FAILED", f"File already exists. Use Read(file_path='{params.file_path}') first, then retry Write.", meta={"file_path": params.file_path})

        if existed:
            before_content = await _read_text(path, encoding=params.encoding)
            current_version_token = _read_stat_fingerprint(await _stat(path))
            if await _check_version_conflict(ctx, path, current_version_token):
                return err(
                    "CONFLICT",
                    f"File has been modified externally since last Read. Re-read the file before writing: {params.file_path}",
                    meta={"conflict_type": "external_modification", "file_path": params.file_path},
                )

        if params.mode == "append" and before_content is not None:
            final_content = before_content + normalized_content
        elif params.mode == "append" and before_content is None:
            final_content = normalized_content
        else:
            final_content = normalized_content

        policy_error = _enforce_memory_secret_policy(
            path=path,
            content=final_content,
            ctx=ctx,
        )
        if policy_error is not None:
            return policy_error

        policy_error, memory_index_warning = _enforce_memory_index_policy(
            path=path,
            content=final_content,
            ctx=ctx,
        )
        if policy_error is not None:
            return policy_error

        await _atomic_write_text(path, final_content, encoding=params.encoding)

    final_bytes = len(final_content.encode(params.encoding, errors="replace"))
    op_bytes = len(normalized_content.encode(params.encoding, errors="replace"))
    op_lines = len(normalized_content.rstrip("\n").split("\n")) if normalized_content else 0
    relpath = to_safe_relpath(path, roots=root_refs)
    sha256_before = iu.sha256_text(before_content) if before_content is not None else None
    sha256_after = iu.sha256_text(final_content)
    final_version_token = _read_stat_fingerprint(await _stat(path))
    operation = "create" if not existed else ("append" if params.mode == "append" else "overwrite")
    write_type = "create" if not existed else ("append" if params.mode == "append" else "update")
    structured_patch = (
        []
        if before_content is None
        else iu.generate_structured_patch(
            before_content,
            final_content,
            fromfile=params.file_path,
            tofile=params.file_path,
        )
    )
    await _mark_read_with_version(ctx, path, final_version_token)
    await _invalidate_read_ranges(ctx, path)
    return ok(
        data={
            "bytes_written": op_bytes,
            "lines_written": op_lines,
            "file_bytes": final_bytes,
            "created": not existed,
            "sha256": sha256_after,
            "relpath": relpath,
            "type": write_type,
            "structured_patch": structured_patch,
            "original_file": before_content,
        },
        meta={
            "file_path": params.file_path,
            "resolved_file_path": str(path),
            "operation": operation,
            "sha256_before": sha256_before,
            "sha256_after": sha256_after,
            "encoding": params.encoding,
            "mode": params.mode,
            "memory_index_guard_warning": memory_index_warning,
        },
    )
