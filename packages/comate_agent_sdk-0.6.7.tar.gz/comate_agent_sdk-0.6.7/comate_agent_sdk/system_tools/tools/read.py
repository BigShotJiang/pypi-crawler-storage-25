from __future__ import annotations

from ._common import *

class ReadInput(BaseModel):
    file_path: str = Field(description="Path to text file")
    offset: int = Field(
        default=1,
        ge=0,
        description="1-based line number to start reading from. Passing 0 is tolerated and treated as 1.",
    )
    limit: int | None = Field(
        default=None,
        ge=_READ_MIN_LIMIT,
        description=(
            "Number of lines to read. When omitted, Read returns the default page size "
            f"({_READ_DEFAULT_LIMIT} lines) from offset on small files. "
            "You MUST provide limit when reading any file larger than 256KB, and advance pages "
            "by setting offset to next_offset_line from the previous response."
        ),
    )

    model_config = {"extra": "forbid"}

    @model_validator(mode="before")
    @classmethod
    def _normalize_legacy_aliases(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        if "offset" not in data and "offset_line" in data:
            data["offset"] = data.pop("offset_line")
        if "limit" not in data and "limit_lines" in data:
            data["limit"] = data.pop("limit_lines")
        data.pop("max_line_chars", None)
        return data

    @property
    def limit_was_explicitly_provided(self) -> bool:
        return "limit" in self.model_fields_set

def _backfill_read_observable_input(args: dict[str, Any]) -> None:
    offset = args.get("offset")
    if offset is None:
        args["offset"] = 1

    if args.get("limit") is None:
        args["limit"] = _READ_DEFAULT_LIMIT

@tool(
    f"Read file with line numbers. When limit is omitted on small files, Read returns up to {_READ_DEFAULT_LIMIT} lines from offset. "
    "You MUST pass limit when reading files larger than 256KB; omitted-limit calls on such files are rejected up front. "
    "Repeating the same unchanged slice may return a reuse stub instead of full content.",
    name="Read",
    usage_rules=READ_USAGE_RULES,
    observable_input_backfill=_backfill_read_observable_input,
)
async def Read(
    params: ReadInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    _maybe_cleanup_loop_dicts()  # P2-8: Periodic cleanup
    try:
        path = resolve_for_read(
            user_path=params.file_path,
            project_root=_project_root(ctx),
            workspace_root=_workspace_root(ctx),
            extra_read_roots=_extra_read_roots(ctx),
        )
    except PathGuardError as exc:
        return _path_error_result(exc)

    if _is_team_inbox_json_path(path):
        return err(
            "POLICY_DENIED",
            (
                "Inbox messages are delivered automatically. "
                'If you are waiting for teammates or new inbox work, call YieldTurn(status="waiting_for_teammate") instead of reading inbox files.'
            ),
        )

    if not await _exists(path):
        similar = iu.find_similar_file(path)
        suggestion = f" Did you mean {similar}?" if similar else ""
        return err("NOT_FOUND", f"File not found: {params.file_path}.{suggestion}")
    if await _is_dir(path):
        return err("IS_DIRECTORY", f"Path is a directory: {params.file_path}")
    if not await _is_file(path):
        return err("PERMISSION_DENIED", f"Path is not a regular file: {params.file_path}")
    binary_reason = await _detect_binary_read_target(path)
    if binary_reason is not None:
        return err(
            "BINARY_FILE",
            f"Read only supports text files. Refusing binary file: {params.file_path}",
            meta={
                "file_path": params.file_path,
                "resolved_file_path": str(path),
                "detected_by": binary_reason,
            },
        )

    file_stat = await _stat(path)
    file_bytes = int(file_stat.st_size)
    stat_fingerprint = _read_stat_fingerprint(file_stat)
    effective_offset_line = _normalize_read_offset(params.offset)
    limit_was_provided = params.limit_was_explicitly_provided
    effective_limit = params.limit if limit_was_provided else _READ_DEFAULT_LIMIT

    if not limit_was_provided and file_bytes > _READ_FULL_FILE_MAX_BYTES:
        return err(
            "OUTPUT_TOO_LARGE",
            (
                f"File is {iu.format_file_size(file_bytes)}, which exceeds the "
                f"{iu.format_file_size(_READ_FULL_FILE_MAX_BYTES)} default full-file limit. "
                f"Retry this call with limit set, e.g. "
                f'Read(file_path="{params.file_path}", offset={effective_offset_line}, limit={_READ_DEFAULT_LIMIT}).'
            ),
            retryable=True,
            meta={
                "file_path": params.file_path,
                "resolved_file_path": str(path),
                "offset": effective_offset_line,
                "offset_line": effective_offset_line,
                "limit": None,
                "limit_lines": None,
                "suggested_offset": effective_offset_line,
                "suggested_offset_line": effective_offset_line,
                "suggested_limit": _READ_DEFAULT_LIMIT,
                "suggested_limit_lines": _READ_DEFAULT_LIMIT,
                "encoding": "utf-8",
                "file_bytes": file_bytes,
                "max_file_size_bytes": _READ_FULL_FILE_MAX_BYTES,
                "truncated_reason": "file_size_limit",
            },
        )

    if _read_reuse_enabled() and await _has_read_range_with_version(
        ctx,
        path,
        stat_fingerprint,
        offset_line=effective_offset_line,
        limit_lines=effective_limit,
    ):
        return ok(
            data={
                "content": "",
                "total_lines": 0,
                "lines_returned": 0,
                "has_more": False,
                "truncated": False,
                "reused_previous_result": True,
                "reuse_message": _READ_REUSE_MESSAGE,
                "meta": {
                    "encoding": "utf-8",
                    "file_bytes": file_bytes,
                },
            },
            meta={
                "file_path": params.file_path,
                "resolved_file_path": str(path),
                "offset": effective_offset_line,
                "offset_line": effective_offset_line,
                "limit": effective_limit,
                "limit_lines": effective_limit,
                "encoding": "utf-8",
                "file_bytes": file_bytes,
            },
        )

    scan_result = await _read_text_range(
        path,
        offset_line=effective_offset_line,
        limit_lines=effective_limit,
        stat_fingerprint=stat_fingerprint,
    )

    if scan_result.problem_line is not None and scan_result.problem_line_bytes is not None:
        kb_size = scan_result.problem_line_bytes / 1024
        limit_kb = _READ_HARD_LINE_LIMIT / 1024
        quoted_path = shlex.quote(str(path))
        return err(
            "OUTPUT_TOO_LARGE",
            f"Line {scan_result.problem_line} is {kb_size:.1f}KB, exceeds single-line limit ({limit_kb:.1f}KB).",
            meta={
                "file_path": params.file_path,
                "resolved_file_path": str(path),
                "problem_line": scan_result.problem_line,
                "line_size_bytes": scan_result.problem_line_bytes,
                "hard_limit_bytes": _READ_HARD_LINE_LIMIT,
                "single_line_extractable": True,
                "extract_command": f"sed -n '{scan_result.problem_line}p' {quoted_path} | head -c {_READ_HARD_LINE_LIMIT}",
                "total_lines": scan_result.total_lines,
                "file_bytes": file_bytes,
                "offset": effective_offset_line,
                "offset_line": effective_offset_line,
                "limit": effective_limit,
                "limit_lines": effective_limit,
            },
        )

    formatted_lines = [
        _format_read_line(line_no, line_content)
        for line_no, line_content in scan_result.selected_lines
    ]
    content = "\n".join(formatted_lines)
    output_tokens = _READ_TOKEN_COUNTER.count(content)
    avg_line_length = int(file_bytes / max(scan_result.total_lines, 1))

    if output_tokens > _READ_MAX_OUTPUT_TOKENS:
        lines_returned = len(scan_result.selected_lines)
        suggested_limit: int | None = None
        if lines_returned > 1 and output_tokens > 0:
            estimated = int((_READ_MAX_OUTPUT_TOKENS * lines_returned) / output_tokens)
            if estimated >= lines_returned:
                estimated = lines_returned - 1
            suggested_limit = max(_READ_MIN_LIMIT, estimated) if estimated > 0 else None
        extract_command: str | None = None
        field_errors = [
            {
                "field": "offset",
                "message": f"Keep offset={effective_offset_line} and reduce the response size to continue reading this range.",
            }
        ]
        if suggested_limit is not None:
            field_errors.append(
                {
                    "field": "limit",
                    "message": f"Current slice is too large; retry with limit={suggested_limit} or smaller.",
                }
            )
            error_message = (
                "Read slice exceeded the output token budget. "
                f"Retry Read with the same offset={effective_offset_line} and a smaller limit "
                f"(for example {suggested_limit}) instead of repeating the same request."
            )
        else:
            extract_command = f"sed -n '{effective_offset_line}p' {shlex.quote(str(path))}"
            error_message = (
                "The first requested line still exceeds the Read output token budget. "
                "Use Bash with a precise extractor (for example `sed -n 'Np' file`) or narrow the target further before retrying Read."
            )
        return err(
            "OUTPUT_TOO_LARGE",
            error_message,
            field_errors=field_errors,
            meta={
                "file_path": params.file_path,
                "resolved_file_path": str(path),
                "offset": effective_offset_line,
                "offset_line": effective_offset_line,
                "limit": effective_limit,
                "limit_lines": effective_limit,
                "suggested_offset": effective_offset_line,
                "suggested_offset_line": effective_offset_line,
                "suggested_limit": suggested_limit,
                "suggested_limit_lines": suggested_limit,
                "recommend_alternative": "bash_precise_extract" if suggested_limit is None else None,
                "extract_command": extract_command,
                "encoding": "utf-8",
                "file_bytes": file_bytes,
                "truncated_reason": "output_too_large",
                "total_lines": scan_result.total_lines,
                "max_output_tokens": _READ_MAX_OUTPUT_TOKENS,
                "output_tokens": output_tokens,
            },
        )

    data: dict[str, Any] = {
        "content": content,
        "total_lines": scan_result.total_lines,
        "lines_returned": len(scan_result.selected_lines),
        "has_more": scan_result.has_more,
        "truncated": bool(scan_result.has_more),
        "truncated_reason": "line_limit" if scan_result.has_more else None,
        "summary": {
            "file_size_kb": round(file_bytes / 1024, 2),
            "total_lines": scan_result.total_lines,
            "avg_line_length": avg_line_length,
        },
        "meta": {
            "encoding": "utf-8",
            "file_bytes": file_bytes,
            "output_tokens": output_tokens,
        },
    }

    if scan_result.has_more:
        data["next_offset_line"] = effective_offset_line + len(scan_result.selected_lines)

    await _mark_read_with_version(ctx, path, scan_result.stat_fingerprint)
    await _mark_read_range_with_version(
        ctx,
        path,
        scan_result.stat_fingerprint,
        offset_line=effective_offset_line,
        limit_lines=effective_limit,
    )

    return ok(
        data=data,
        meta={
            "file_path": params.file_path,
            "resolved_file_path": str(path),
            "offset": effective_offset_line,
            "offset_line": effective_offset_line,
            "limit": effective_limit,
            "limit_lines": effective_limit,
            "encoding": "utf-8",
            "file_bytes": file_bytes,
            "max_output_tokens": _READ_MAX_OUTPUT_TOKENS,
        },
    )
