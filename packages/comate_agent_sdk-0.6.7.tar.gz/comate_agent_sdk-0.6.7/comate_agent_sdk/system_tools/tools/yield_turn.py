from __future__ import annotations

from ._common import *

class YieldTurnInput(BaseModel):
    status: str = Field(
        min_length=1,
        description="Short machine-readable yield status, e.g. waiting_for_teammate.",
    )

    model_config = {"extra": "forbid"}

@tool(
    "Yield control back to the runtime and end the current turn deterministically.",
    name="YieldTurn",
    usage_rules=YIELD_TURN_USAGE_RULES,
    prompt_hint="Must be the ONLY tool call in a response. Signals end of current turn so queued team messages can be delivered.",
)
async def YieldTurn(
    params: YieldTurnInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    del ctx
    try:
        normalized_status = str(params.status or "").strip()
        logger.info(f"YieldTurn requested with status={normalized_status!r}")
        return ok(
            data={
                "status": "yielded",
                "yield_status": normalized_status,
            },
            message=f"Yielded turn with status={normalized_status}",
            meta={
                "status": "yielded",
                "yield_status": normalized_status,
            },
        )
    except Exception as exc:
        logger.error(f"YieldTurn failed: {exc}", exc_info=True)
        return err("INTERNAL", f"YieldTurn failed: {exc}")
