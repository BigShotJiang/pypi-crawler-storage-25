from __future__ import annotations

from ._common import *

class ExitPlanModeInput(BaseModel):
    plan_markdown: str | None = Field(
        default=None,
        description="Deprecated: plan markdown must be written to active plan file before calling ExitPlanMode.",
    )
    summary: str = Field(min_length=1, description="Short summary shown in approval UI.")
    title: str | None = Field(default=None, description="Deprecated: title is no longer used for plan filename.")
    execution_prompt: str | None = Field(
        default=None,
        description="Optional prompt to auto-run in Act Mode after approval.",
    )

    model_config = {"extra": "forbid"}

@tool(
    "Finalize plan artifact and request approval to leave Plan Mode.",
    name="ExitPlanMode",
    usage_rules=EXIT_PLAN_MODE_USAGE_RULES,
    prompt_hint="Use in Plan mode when the plan file is ready for user approval. Does NOT execute the plan.",
)
async def ExitPlanMode(
    params: ExitPlanModeInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    try:
        if str(params.plan_markdown or "").strip():
            return err(
                "INVALID_ARGUMENT",
                "plan_markdown is deprecated. Write your plan to the active plan file, then call ExitPlanMode.",
            )

        if ctx is None or ctx.active_plan_path is None:
            return err(
                "INVALID_ARGUMENT",
                "No active plan file is bound to this session. Enter Plan Mode and edit the provided plan file first.",
            )

        path = ctx.active_plan_path.expanduser().resolve()
        if not await _exists(path):
            return err(
                "NOT_FOUND",
                f"Active plan file not found: {path}. Use Write to create it before calling ExitPlanMode.",
            )

        plan_markdown = (await _read_text(path, encoding="utf-8")).strip()
        if not plan_markdown:
            return err(
                "INVALID_ARGUMENT",
                f"Active plan file is empty: {path}. Add plan content before calling ExitPlanMode.",
            )

        execution_prompt = str(params.execution_prompt or "").strip()
        if not execution_prompt:
            execution_prompt = "implement it all. do everything in the plan, don't cherry-pick, do not stop until all tasks and phases are completed, don't pause for confirmation mid-flow."

        logger.info(f"ExitPlanMode finalized active plan artifact: {path}")
        return ok(
            data={
                "status": "waiting_for_plan_approval",
                "plan_path": str(path),
                "summary": params.summary,
                "execution_prompt": execution_prompt,
            },
            message=f"Plan is ready for approval: {path}",
            meta={
                "status": "waiting_for_plan_approval",
                "plan_path": str(path),
            },
        )
    except Exception as exc:
        logger.error(f"ExitPlanMode failed: {exc}", exc_info=True)
        return err("INTERNAL", f"ExitPlanMode failed: {exc}")
