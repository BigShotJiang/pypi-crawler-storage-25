import unittest

from comate_agent_sdk.context.truncation import TruncationRecord
from comate_agent_sdk.system_tools.output_formatter import OutputFormatter, _default_truncation
from comate_agent_sdk.system_tools.tool_result import err, ok


class TestOutputFormatter(unittest.TestCase):
    def test_format_bash_preserves_preview_without_secondary_truncation(self) -> None:
        preview = "x" * 7000
        payload = ok(
            data={
                "stdout": preview,
                "stderr": "",
                "exit_code": 0,
                "timed_out": False,
                "interrupted": False,
                "killed": False,
                "duration_ms": 12,
                "truncated": False,
                "truncated_reason": None,
                "stdout_truncated": False,
                "stdout_total_bytes": len(preview),
                "stdout_dropped_lines": 0,
                "stderr_truncated": False,
                "stderr_total_bytes": 0,
                "stderr_dropped_lines": 0,
            },
            meta={
                "command": "echo preview",
            },
        )

        formatted = OutputFormatter.format(
            tool_name="Bash",
            tool_call_id="tc_bash_preview",
            result_dict=payload,
        )

        self.assertIn(preview, formatted.text)
        self.assertNotIn("...(truncated)", formatted.text)

    def test_format_bash_truncated_uses_artifact_relpath(self) -> None:
        payload = ok(
            data={
                "stdout": "line1\nline2",
                "stderr": "",
                "exit_code": 0,
                "timed_out": False,
                "interrupted": False,
                "killed": False,
                "duration_ms": 12,
                "truncated": True,
                "truncated_reason": "output_too_large",
                "stdout_truncated": True,
                "stdout_total_bytes": 2048,
                "stdout_dropped_lines": 10,
                "stderr_truncated": False,
                "stderr_total_bytes": 0,
                "stderr_dropped_lines": 0,
                "artifact": {
                    "relpath": ".agent_workspace/.agent/artifacts/bash/abc123.txt",
                    "mime": "text/plain",
                },
            },
            meta={
                "command": "long command",
            },
        )

        formatted = OutputFormatter.format(
            tool_name="Bash",
            tool_call_id="tc_bash_truncated",
            result_dict=payload,
        )

        self.assertIn(".agent_workspace/.agent/artifacts/bash/abc123.txt", formatted.text)
        self.assertIn("Recommended next step:", formatted.text)
        self.assertIsNotNone(formatted.meta.retrieval_hints)
        self.assertTrue(
            all("format" not in (hint.get("args") or {}) for hint in (formatted.meta.retrieval_hints or []))
        )
        self.assertIn("# Bash: long command", formatted.text)

    def test_format_read_with_truncation_footer_and_hints(self) -> None:
        payload = ok(
            data={
                "content": "     1\tline1\n     2\tline2",
                "total_lines": 1200,
                "lines_returned": 2,
                "has_more": True,
                "next_offset_line": 3,
                "truncated": True,
                "artifact": {"relpath": ".agent_workspace/.artifacts/read/abc.txt"},
            },
            meta={
                "file_path": "src/main.py",
                "offset_line": 1,
                "limit_lines": 2,
            },
        )

        formatted = OutputFormatter.format(
            tool_name="Read",
            tool_call_id="tc_read_1",
            result_dict=payload,
        )

        self.assertIn("# Read: src/main.py", formatted.text)
        self.assertIn("Lines 1-2 of 1200", formatted.text)
        self.assertIn("Recommended next step:", formatted.text)
        self.assertEqual(formatted.meta.status, "ok")
        self.assertIsNotNone(formatted.meta.truncation)
        self.assertIsInstance(formatted.meta.truncation, TruncationRecord)
        self.assertTrue(formatted.meta.truncation.formatter_truncated)
        self.assertEqual(formatted.meta.truncation.formatter_reason, "line_limit")
        self.assertIsNotNone(formatted.meta.retrieval_hints)
        self.assertGreaterEqual(len(formatted.meta.retrieval_hints), 2)
        self.assertTrue(
            all("format" not in (hint.get("args") or {}) for hint in (formatted.meta.retrieval_hints or []))
        )

    def test_format_write_includes_file_ops(self) -> None:
        payload = ok(
            data={
                "bytes_written": 12,
                "file_bytes": 40,
                "created": False,
                "sha256": "after_hash",
                "relpath": "src/config.json",
            },
            meta={
                "file_path": "src/config.json",
                "operation": "overwrite",
                "sha256_before": "before_hash",
                "sha256_after": "after_hash",
            },
        )

        formatted = OutputFormatter.format(
            tool_name="Write",
            tool_call_id="tc_write_1",
            result_dict=payload,
        )

        self.assertEqual(
            formatted.text,
            "The file src/config.json has been written successfully.",
        )
        self.assertEqual(formatted.meta.status, "ok")
        self.assertIsNotNone(formatted.meta.file_ops)
        self.assertEqual(formatted.meta.file_ops["operation"], "overwrite")
        self.assertEqual(formatted.meta.file_ops["sha256_after"], "after_hash")

    def test_format_write_prefers_resolved_file_path(self) -> None:
        payload = ok(
            data={
                "bytes_written": 7,
                "file_bytes": 7,
                "created": True,
                "sha256": "after_hash",
                "relpath": "optimize-thinking-blocks-compaction.md",
            },
            meta={
                "file_path": "~/.agent/plans/optimize-thinking-blocks-compaction.md",
                "resolved_file_path": "/tmp/home/.agent/plans/optimize-thinking-blocks-compaction.md",
                "operation": "create",
                "sha256_after": "after_hash",
            },
        )

        formatted = OutputFormatter.format(
            tool_name="Write",
            tool_call_id="tc_write_2",
            result_dict=payload,
        )

        self.assertEqual(
            formatted.text,
            "The file /tmp/home/.agent/plans/optimize-thinking-blocks-compaction.md has been written successfully.",
        )
        self.assertEqual(
            formatted.meta.file_ops["file_path"],
            "/tmp/home/.agent/plans/optimize-thinking-blocks-compaction.md",
        )

    def test_format_edit_replace_all_uses_compact_message(self) -> None:
        payload = ok(
            data={
                "replacements": 2,
                "created": False,
                "before_sha256": "before_hash",
                "after_sha256": "after_hash",
                "relpath": "src/config.json",
            },
            meta={
                "file_path": "src/config.json",
                "operation": "replace",
                "replace_all": True,
                "sha256_before": "before_hash",
                "sha256_after": "after_hash",
            },
        )

        formatted = OutputFormatter.format(
            tool_name="Edit",
            tool_call_id="tc_edit_1",
            result_dict=payload,
        )

        self.assertEqual(
            formatted.text,
            "The file src/config.json has been updated. All occurrences were successfully replaced.",
        )
        self.assertEqual(formatted.meta.file_ops["operation"], "replace")

    def test_format_error_includes_retry_footer(self) -> None:
        payload = err(
            "INVALID_ARGUMENT",
            "invalid path",
            field_errors=[{"field": "path", "message": "must be absolute"}],
        )
        formatted = OutputFormatter.format(
            tool_name="Grep",
            tool_call_id="tc_grep_1",
            result_dict=payload,
        )

        self.assertIn("# Grep Error", formatted.text)
        self.assertIn("Code: INVALID_ARGUMENT", formatted.text)
        self.assertIn("Recommended next step:", formatted.text)
        self.assertEqual(formatted.meta.status, "error")
        self.assertEqual(formatted.meta.error_code, "INVALID_ARGUMENT")
        self.assertEqual(formatted.meta.error_field, "path")

    def test_format_ask_user_question(self) -> None:
        payload = ok(
            data={
                "status": "waiting_for_input",
                "questions": [
                    {
                        "question": "Which option?",
                        "header": "Choice",
                        "options": [
                            {"label": "A", "description": "Option A"},
                            {"label": "B", "description": "Option B"},
                        ],
                        "multiSelect": False,
                    }
                ],
            },
            message="Prepared 1 question(s) for user",
        )
        formatted = OutputFormatter.format(
            tool_name="AskUserQuestion",
            tool_call_id="tc_question_1",
            result_dict=payload,
        )

        self.assertIn("# AskUserQuestion", formatted.text)
        self.assertIn("Question count: 1", formatted.text)
        self.assertEqual(formatted.meta.status, "ok")

    def test_default_truncation_returns_truncation_record(self) -> None:
        record = _default_truncation(
            {
                "truncated": True,
                "raw_output_truncated": True,
                "total_matches": 123,
            }
        )
        self.assertIsNotNone(record)
        assert record is not None
        self.assertIsInstance(record, TruncationRecord)
        self.assertTrue(record.formatter_truncated)
        self.assertIn("output_capture_limit", record.formatter_reason)
        self.assertEqual(record.formatter_total_estimate, 123)

    def test_format_read_no_truncation_returns_none(self) -> None:
        payload = ok(
            data={
                "content": "     1\tline1\n     2\tline2",
                "total_lines": 2,
                "lines_returned": 2,
                "has_more": False,
                "truncated": False,
            },
            meta={
                "file_path": "src/main.py",
                "offset_line": 1,
                "limit_lines": 2,
            },
        )
        formatted = OutputFormatter.format(
            tool_name="Read",
            tool_call_id="tc_read_no_truncation",
            result_dict=payload,
        )
        self.assertIsNone(formatted.meta.truncation)

    def test_format_read_reused_previous_result_prefers_stub_body(self) -> None:
        payload = ok(
            data={
                "content": "ignored body",
                "total_lines": 200,
                "lines_returned": 0,
                "has_more": False,
                "truncated": False,
                "reused_previous_result": True,
                "reuse_message": "File unchanged since last read. The earlier Read result for this file and range is still current; refer to that instead of re-reading.",
            },
            meta={
                "file_path": "src/main.py",
                "offset_line": 1,
                "limit_lines": 200,
            },
        )
        formatted = OutputFormatter.format(
            tool_name="Read",
            tool_call_id="tc_read_reused",
            result_dict=payload,
        )
        self.assertIn("File unchanged since last read", formatted.text)
        self.assertIn("refer to that instead of re-reading", formatted.text)
        self.assertNotIn("ignored body", formatted.text)
        self.assertIsNone(formatted.meta.truncation)

    def test_format_read_output_too_large_error_prefers_read_retry_hint(self) -> None:
        payload = err(
            "OUTPUT_TOO_LARGE",
            "Read slice exceeded the tool budget.",
            field_errors=[
                {"field": "offset", "message": "Keep the same offset."},
                {"field": "limit", "message": "Reduce the window."},
            ],
            meta={
                "file_path": "docs/wide.md",
                "suggested_offset": 1,
                "suggested_limit": 120,
            },
        )
        formatted = OutputFormatter.format(
            tool_name="Read",
            tool_call_id="tc_read_too_large",
            result_dict=payload,
        )
        self.assertIn("Code: OUTPUT_TOO_LARGE", formatted.text)
        self.assertIn("Meaning: The selected Read slice is too large to return in one result.", formatted.text)
        self.assertIn("Recommended next step:", formatted.text)
        self.assertIn('Read(file_path="docs/wide.md", offset=1, limit=120)', formatted.text)
        self.assertNotIn('Read(offset="<correct_value>")', formatted.text)
        self.assertIsNotNone(formatted.meta.retrieval_hints)

    def test_format_read_output_too_large_hint_uses_new_range_names(self) -> None:
        payload = err(
            "OUTPUT_TOO_LARGE",
            "Read slice exceeded the tool budget.",
            meta={
                "file_path": "docs/wide.md",
                "suggested_offset": 1,
                "suggested_limit": 3,
            },
        )
        formatted = OutputFormatter.format(
            tool_name="Read",
            tool_call_id="tc_read_keep_max_line",
            result_dict=payload,
        )
        self.assertIn(
            'Read(file_path="docs/wide.md", offset=1, limit=3)',
            formatted.text,
        )

    def test_format_read_output_too_large_bash_alternative_steers_to_precise_extract(self) -> None:
        payload = err(
            "OUTPUT_TOO_LARGE",
            "Read slice exceeded the tool budget and lines are clipped.",
            meta={
                "file_path": "docs/clipped.md",
                "suggested_offset_line": 1,
                "suggested_limit_lines": 14,
                "suggested_max_line_chars": 2000,
                "recommend_alternative": "bash_precise_extract",
                "extract_command": "sed -n '1,14p' docs/clipped.md",
            },
        )
        formatted = OutputFormatter.format(
            tool_name="Read",
            tool_call_id="tc_read_bash_alt",
            result_dict=payload,
        )
        bash_line = 'Bash(command="sed -n \'1,14p\' docs/clipped.md")'
        grep_line = (
            'Grep(pattern="<keywords>", path="docs/clipped.md", output_mode="content")'
        )
        read_line = (
            'Read(file_path="docs/clipped.md", offset=1, limit=14)'
        )
        self.assertIn(bash_line, formatted.text)
        self.assertIn(grep_line, formatted.text)
        self.assertIn(read_line, formatted.text)
        self.assertLess(
            formatted.text.index(bash_line),
            formatted.text.index(read_line),
            "Bash hint must appear before Read hint when lines are clipped",
        )
        self.assertLess(
            formatted.text.index(read_line),
            formatted.text.index(grep_line),
            "Grep hint must remain secondary when lines are clipped",
        )

    def test_format_read_output_too_large_without_range_hint_has_no_read_retry(self) -> None:
        payload = err(
            "OUTPUT_TOO_LARGE",
            "Read slice exceeded the tool budget.",
            meta={
                "file_path": "docs/unicode.md",
                "suggested_offset": 1,
            },
        )
        formatted = OutputFormatter.format(
            tool_name="Read",
            tool_call_id="tc_read_too_large_chars",
            result_dict=payload,
        )
        self.assertNotIn("Recommended next step:", formatted.text)
        self.assertIsNone(formatted.meta.retrieval_hints)

    def test_format_task_result_with_open_tasks(self) -> None:
        payload = ok(
            data={
                "list_id": "shared",
                "total": 4,
                "by_status": {
                    "pending": 2,
                    "in_progress": 1,
                "completed": 1,
                },
                "tasks": [
                    {
                        "id": "1",
                        "subject": "Fix authentication bug",
                        "status": "pending",
                        "owner": "andy",
                        "description": "Investigate the auth middleware token parsing path.",
                        "open_blocked_by": [],
                    },
                    {
                        "id": "2",
                        "subject": "Add unit tests",
                        "status": "in_progress",
                        "owner": "worker-b",
                        "description": "Cover the edge cases around expired tokens.",
                        "open_blocked_by": [],
                    },
                    {
                        "id": "3",
                        "subject": "Update docs",
                        "status": "pending",
                        "owner": "",
                        "open_blocked_by": ["1"],
                    },
                    {
                        "id": "4",
                        "subject": "Refactor code",
                        "status": "completed",
                        "owner": "worker-c",
                        "open_blocked_by": [],
                    },
                ],
            },
        )

        formatted = OutputFormatter.format(
            tool_name="TaskList",
            tool_call_id="tc_task_1",
            result_dict=payload,
        )

        self.assertIn("# TaskList", formatted.text)
        self.assertIn("Task Namespace: shared", formatted.text)
        self.assertIn("Total tasks: 4", formatted.text)
        self.assertIn("Open Tasks:", formatted.text)
        self.assertIn("- [pending] #1 Fix authentication bug owner=andy", formatted.text)
        self.assertIn("  Description: Investigate the auth middleware token parsing path.", formatted.text)
        self.assertIn("- [in_progress] #2 Add unit tests owner=worker-b", formatted.text)
        self.assertIn("  Description: Cover the edge cases around expired tokens.", formatted.text)
        self.assertIn("blocked_by=#1", formatted.text)
        self.assertEqual(formatted.meta.status, "ok")

    def test_format_task_result_with_selected_task(self) -> None:
        payload = ok(
            data={
                "list_id": "default",
                "task": {
                    "id": "2",
                    "subject": "Finalize release checklist",
                    "status": "completed",
                    "owner": "andy",
                    "description": "Double-check release blockers.",
                    "blocked_by": ["1"],
                    "open_blocked_by": [],
                    "blocks": ["5"],
                    "metadata": {"priority": "high"},
                },
                "blocked_by_detail": [
                    {
                        "id": "1",
                        "subject": "Ship release notes",
                        "status": "completed",
                        "owner": "writer",
                        "open_blocked_by": [],
                    }
                ],
                "blocks_detail": [
                    {
                        "id": "5",
                        "subject": "Publish release",
                        "status": "pending",
                        "owner": "ops",
                        "open_blocked_by": ["2"],
                    }
                ],
                "summary": "tasks=2 pending=0 in_progress=0 completed=2",
            },
        )

        formatted = OutputFormatter.format(
            tool_name="TaskGet",
            tool_call_id="tc_task_2",
            result_dict=payload,
        )

        self.assertIn("# TaskGet", formatted.text)
        self.assertIn("Selected Task:", formatted.text)
        self.assertIn("Task ID: #2", formatted.text)
        self.assertIn("Status: [completed] Finalize release checklist", formatted.text)
        self.assertIn("Owner: andy", formatted.text)
        self.assertIn("Description: Double-check release blockers.", formatted.text)
        self.assertIn("Blocked By: #1", formatted.text)
        self.assertIn("Blocks: #5", formatted.text)
        self.assertIn('Metadata: {"priority": "high"}', formatted.text)
        self.assertIn("Blocked By Detail:", formatted.text)
        self.assertIn("- [completed] #1 Ship release notes owner=writer", formatted.text)
        self.assertIn("Blocks Detail:", formatted.text)
        self.assertIn("- [pending] #5 Publish release owner=ops blocked_by=#2", formatted.text)
        self.assertNotIn("Total tasks: 0", formatted.text)

    def test_format_task_create_result_highlights_task_id_for_follow_up(self) -> None:
        payload = ok(
            data={
                "list_id": "session-123",
                "task": {
                    "id": "1",
                    "subject": "Search TODO comments",
                    "status": "pending",
                    "owner": "andy",
                    "open_blocked_by": [],
                },
                "tasks": [
                    {
                        "id": "1",
                        "subject": "Search TODO comments",
                        "status": "pending",
                        "owner": "andy",
                        "open_blocked_by": [],
                    }
                ],
                "total": 1,
                "by_status": {
                    "pending": 1,
                    "in_progress": 0,
                    "completed": 0,
                },
                "summary": "tasks=1 pending=1 in_progress=0 completed=0",
            },
        )

        formatted = OutputFormatter.format(
            tool_name="TaskCreate",
            tool_call_id="tc_task_create",
            result_dict=payload,
        )

        self.assertIn("Task ID: #1", formatted.text)
        self.assertIn("Owner: andy", formatted.text)
        self.assertIn(
            "Display IDs may appear as `#1`, but use `task_id=\"1\"` for TaskGet/TaskUpdate.",
            formatted.text,
        )
        self.assertIn("Task Namespace: session-123", formatted.text)


    def test_format_error_precondition_failed_hints_read(self) -> None:
        payload = err("PRECONDITION_FAILED", "Must Read file before modifying it: /tmp/f.py", meta={"file_path": "/tmp/f.py"})
        formatted = OutputFormatter.format(tool_name="Edit", tool_call_id="tc_edit_pre", result_dict=payload)
        read_hints = [h for h in (formatted.meta.retrieval_hints or []) if h.get("action") == "Read"]
        self.assertEqual(read_hints[0]["args"]["file_path"], "/tmp/f.py")

    def test_format_error_conflict_external_modification_hints_read(self) -> None:
        payload = err("CONFLICT", "modified externally", meta={"conflict_type": "external_modification", "file_path": "/tmp/f.py"})
        formatted = OutputFormatter.format(tool_name="Edit", tool_call_id="tc_edit_ext", result_dict=payload)
        assert any(h.get("action") == "Read" for h in (formatted.meta.retrieval_hints or []))
        assert not any(h.get("args", {}).get("fix_arguments") for h in (formatted.meta.retrieval_hints or []))

    def test_format_error_conflict_ambiguous_match_hints_fix_arguments(self) -> None:
        payload = err("CONFLICT", "old_string appears 2 times", meta={"conflict_type": "ambiguous_match", "file_path": "/tmp/f.py"})
        formatted = OutputFormatter.format(tool_name="Edit", tool_call_id="tc_edit_amb", result_dict=payload)
        assert any(h.get("args", {}).get("fix_arguments") for h in (formatted.meta.retrieval_hints or []))

    def test_format_error_bash_timeout_shows_stdout_or_stderr_or_artifact(self) -> None:
        payload = err(
            "TIMEOUT",
            "Command timed out after 120000ms",
            data={
                "stdout": "",
                "stderr": "compiling module B failed",
                "truncated": True,
                "artifact": {"relpath": ".agent/artifacts/bash/abc123.txt", "mime": "text/plain"},
            },
            retryable=True,
            meta={"command": "make build", "cwd": "/tmp", "duration_ms": 120000},
        )
        formatted = OutputFormatter.format(tool_name="Bash", tool_call_id="tc_bash_timeout", result_dict=payload)
        self.assertIn("Partial Output", formatted.text)
        self.assertIn("compiling module B failed", formatted.text)
        self.assertIn("abc123.txt", formatted.text)

    def test_format_error_read_hard_line_limit_exposes_bash_recovery_hint(self) -> None:
        payload = err(
            "OUTPUT_TOO_LARGE",
            "Line 1 is too large",
            meta={
                "file_path": "/tmp/huge.txt",
                "problem_line": 1,
                "hard_limit_bytes": 20480,
                "single_line_extractable": True,
                "extract_command": "sed -n '1p' /tmp/huge.txt | head -c 20480",
            },
        )
        formatted = OutputFormatter.format(tool_name="Read", tool_call_id="tc_read_hard", result_dict=payload)
        self.assertIn("Bash(", formatted.text)

    def test_glob_truncated_hint_tracks_current_pagination_contract(self) -> None:
        payload = ok(
            data={
                "matches": [f"file{i}.py" for i in range(500)],
                "count": 500,
                "count_is_lower_bound": True,
                "truncated": True,
                "truncated_reason": "head_limit_reached",
                "search_path": "/tmp",
            }
        )
        formatted = OutputFormatter.format(tool_name="Glob", tool_call_id="tc_glob", result_dict=payload)
        hints = [h for h in (formatted.meta.retrieval_hints or []) if h.get("action") == "Glob"]
        self.assertEqual(hints[0]["args"]["pattern"], "**/*")
        self.assertEqual(hints[0]["args"]["path"], "/tmp")
        self.assertNotIn("head_limit", hints[0]["args"])
        self.assertNotIn("[Showing results with pagination", formatted.text)
        self.assertNotIn("schema max head_limit (300)", formatted.text)

    def test_ls_truncated_hint_respects_schema_max(self) -> None:
        payload = ok(
            data={
                "entries": [{"name": f"f{i}", "type": "file", "size": 1} for i in range(500)],
                "count": 500,
                "truncated": True,
                "truncated_reason": "head_limit_reached",
                "path": "/tmp",
            }
        )
        formatted = OutputFormatter.format(tool_name="LS", tool_call_id="tc_ls", result_dict=payload)
        hints = [h for h in (formatted.meta.retrieval_hints or []) if h.get("action") == "LS"]
        self.assertEqual(hints[0]["args"]["head_limit"], 300)

    # ──────────────── G2: read_hint removed ────────────────

    def test_bash_envelope_no_read_hint_field(self) -> None:
        payload = ok(
            data={
                "stdout": "x",
                "stderr": "",
                "exit_code": 0,
                "timed_out": False,
                "interrupted": False,
                "killed": False,
                "duration_ms": 1,
                "truncated": True,
                "stdout_truncated": True,
                "stdout_total_bytes": 1,
                "stdout_dropped_lines": 0,
                "stderr_truncated": False,
                "stderr_total_bytes": 0,
                "stderr_dropped_lines": 0,
                "artifact": {"relpath": ".agent/artifacts/bash/abc.txt", "mime": "text/plain"},
            },
            meta={"command": "x"},
        )
        self.assertNotIn("read_hint", payload["data"])
        formatted = OutputFormatter.format(
            tool_name="Bash", tool_call_id="tc_bash_no_hint", result_dict=payload
        )
        self.assertIn(".agent/artifacts/bash/abc.txt", formatted.text)

    # ──────────────── GR1: Grep formatter clip ────────────────

    def test_format_grep_content_no_clip_no_note(self) -> None:
        payload = ok(
            data={
                "matches_by_file": {
                    "a.py": {"matches": [{"line_number": 1, "line": "hit"}]},
                    "b.py": {"matches": [{"line_number": 2, "line": "hit"}]},
                },
                "total_matches": 2,
                "file_count": 2,
                "truncated": False,
            },
            meta={"output_mode": "content", "pattern": "hit", "search_path": "."},
        )
        formatted = OutputFormatter.format(
            tool_name="Grep", tool_call_id="tc_grep_ok", result_dict=payload
        )
        self.assertNotIn("Formatter capped", formatted.text)
        # TruncationRecord 不应标记 formatter_clip
        if formatted.meta.truncation is not None:
            self.assertNotIn("formatter_clip", formatted.meta.truncation.formatter_reason or "")

    def test_format_grep_content_flattens_to_grep_lines(self) -> None:
        payload = ok(
            data={
                "matches_by_file": {
                    "a.py": {
                        "matches": [
                            {"line_number": 3, "line": "first hit"},
                            {"line_number": 8, "line": "second hit"},
                        ]
                    },
                },
                "total_matches": 2,
                "file_count": 1,
                "truncated": False,
            },
            meta={"output_mode": "content", "pattern": "hit", "search_path": "."},
        )
        formatted = OutputFormatter.format(
            tool_name="Grep", tool_call_id="tc_grep_flat", result_dict=payload
        )
        self.assertIn("a.py:3:first hit", formatted.text)
        self.assertIn("a.py:8:second hit", formatted.text)
        self.assertNotIn("# Grep", formatted.text)
        self.assertNotIn("## a.py", formatted.text)

    def test_format_grep_files_with_matches_uses_claude_style_text(self) -> None:
        payload = ok(
            data={
                "files": ["src/a.py", "src/b.py"],
                "count": 2,
                "truncated": False,
            },
            meta={
                "output_mode": "files_with_matches",
                "pattern": "foo",
                "search_path": "src",
                "head_limit": 250,
            },
        )
        formatted = OutputFormatter.format(
            tool_name="Grep", tool_call_id="tc_grep_files", result_dict=payload
        )
        self.assertIn("Found 2 files limit: 250", formatted.text)
        self.assertIn("src/a.py", formatted.text)
        self.assertIn("src/b.py", formatted.text)
        self.assertNotIn("# Grep", formatted.text)
        self.assertNotIn("- src/a.py", formatted.text)
        self.assertIsNone(formatted.meta.retrieval_hints)

    def test_format_grep_count_uses_claude_style_text(self) -> None:
        payload = ok(
            data={
                "counts": [{"file": "src/a.py", "count": 3}],
                "total_matches": 3,
                "truncated": False,
            },
            meta={
                "output_mode": "count",
                "pattern": "foo",
                "search_path": "src",
                "head_limit": 250,
            },
        )
        formatted = OutputFormatter.format(
            tool_name="Grep", tool_call_id="tc_grep_count", result_dict=payload
        )
        self.assertIn("src/a.py:3", formatted.text)
        self.assertIn(
            "Found 3 total occurrences across 1 file. with pagination = limit: 250",
            formatted.text,
        )
        self.assertNotIn("# Grep", formatted.text)
        self.assertIsNone(formatted.meta.retrieval_hints)

    def test_format_grep_count_no_matches_keeps_zero_summary(self) -> None:
        payload = ok(
            data={
                "counts": [],
                "total_matches": 0,
                "truncated": False,
            },
            meta={
                "output_mode": "count",
                "pattern": "foo",
                "search_path": "src",
                "head_limit": 250,
            },
        )
        formatted = OutputFormatter.format(
            tool_name="Grep", tool_call_id="tc_grep_count_empty", result_dict=payload
        )
        self.assertIn("No matches found", formatted.text)
        self.assertIn("Found 0 total occurrences across 0 files.", formatted.text)

    def test_format_grep_count_lower_bound_uses_at_least_wording(self) -> None:
        payload = ok(
            data={
                "counts": [{"file": "src/a.py", "count": 3}],
                "total_matches": 3,
                "truncated": True,
                "truncated_reason": "timeout",
                "total_matches_is_lower_bound": True,
            },
            meta={
                "output_mode": "count",
                "pattern": "foo",
                "search_path": "src",
                "head_limit": 250,
            },
        )
        formatted = OutputFormatter.format(
            tool_name="Grep", tool_call_id="tc_grep_count_lower_bound", result_dict=payload
        )
        self.assertIn("Found at least 3 total occurrences across 1 file.", formatted.text)
        self.assertIsNotNone(formatted.meta.retrieval_hints)

    def test_format_grep_content_pagination_keeps_block_format(self) -> None:
        payload = ok(
            data={
                "matches_by_file": {
                    "a.py": {"matches": [{"line_number": 3, "line": "first hit"}]},
                },
                "total_matches": 1,
                "file_count": 1,
                "truncated": False,
            },
            meta={"output_mode": "content", "pattern": "hit", "search_path": ".", "head_limit": 250},
        )
        formatted = OutputFormatter.format(
            tool_name="Grep", tool_call_id="tc_grep_content_page", result_dict=payload
        )
        self.assertIn("[Showing results with pagination = limit: 250]", formatted.text)
        self.assertIsNone(formatted.meta.retrieval_hints)

    def test_format_grep_files_with_matches_shows_offset_even_when_not_truncated(self) -> None:
        payload = ok(
            data={
                "files": ["src/b.py"],
                "count": 2,
                "truncated": False,
            },
            meta={
                "output_mode": "files_with_matches",
                "pattern": "foo",
                "search_path": "src",
                "head_limit": 250,
                "offset": 1,
            },
        )
        formatted = OutputFormatter.format(
            tool_name="Grep", tool_call_id="tc_grep_files_offset", result_dict=payload
        )
        self.assertIn("Found 2 files limit: 250, offset: 1", formatted.text)

    def test_format_grep_content_formatter_clip_by_files(self) -> None:
        matches_by_file = {
            f"f{i}.py": {"matches": [{"line_number": 1, "line": "hit"}]} for i in range(60)
        }
        payload = ok(
            data={
                "matches_by_file": matches_by_file,
                "total_matches": 60,
                "file_count": 60,
                "truncated": False,
            },
            meta={"output_mode": "content", "pattern": "hit", "search_path": ".", "head_limit": 0},
        )
        formatted = OutputFormatter.format(
            tool_name="Grep", tool_call_id="tc_grep_clip_files", result_dict=payload
        )
        self.assertIn("Formatter capped", formatted.text)
        self.assertIn("50/60 files", formatted.text)
        self.assertIsNotNone(formatted.meta.truncation)
        self.assertTrue(formatted.meta.truncation.formatter_truncated)
        self.assertIn("formatter_clip", formatted.meta.truncation.formatter_reason)

    def test_format_grep_content_formatter_clip_by_matches_per_file(self) -> None:
        payload = ok(
            data={
                "matches_by_file": {
                    "a.py": {
                        "matches": [{"line_number": i, "line": f"hit-{i}"} for i in range(25)]
                    },
                },
                "total_matches": 25,
                "file_count": 1,
                "truncated": False,
            },
            meta={"output_mode": "content", "pattern": "hit", "search_path": ".", "head_limit": 0},
        )
        formatted = OutputFormatter.format(
            tool_name="Grep", tool_call_id="tc_grep_clip_per_file", result_dict=payload
        )
        self.assertIn("Formatter capped", formatted.text)
        self.assertTrue(formatted.meta.truncation.formatter_truncated)

    def test_format_grep_content_skips_formatter_clip_when_head_limit_positive(self) -> None:
        matches_by_file = {
            f"f{i}.py": {"matches": [{"line_number": 1, "line": "hit"}]} for i in range(60)
        }
        payload = ok(
            data={
                "matches_by_file": matches_by_file,
                "total_matches": 60,
                "file_count": 60,
                "truncated": False,
            },
            meta={"output_mode": "content", "pattern": "hit", "search_path": ".", "head_limit": 250},
        )
        formatted = OutputFormatter.format(
            tool_name="Grep", tool_call_id="tc_grep_no_clip_with_head", result_dict=payload
        )
        self.assertNotIn("Formatter capped", formatted.text)
        if formatted.meta.truncation is not None:
            self.assertNotIn("formatter_clip", formatted.meta.truncation.formatter_reason or "")

    def test_format_glob_uses_plain_paths_without_legacy_header(self) -> None:
        payload = ok(
            data={
                "matches": ["src/a.py", "src/b.py"],
                "count": 2,
                "truncated": False,
                "search_path": "src",
            },
            meta={"pattern": "*.py", "search_path": "src"},
        )
        formatted = OutputFormatter.format(
            tool_name="Glob", tool_call_id="tc_glob_plain", result_dict=payload
        )
        self.assertEqual(formatted.text, "src/a.py\nsrc/b.py")
        self.assertNotIn("# Glob", formatted.text)
        self.assertNotIn("Matches shown:", formatted.text)

    def test_format_glob_truncation_notice_exact_string(self) -> None:
        payload = ok(
            data={
                "matches": ["src/a.py"],
                "count": 101,
                "truncated": True,
                "truncated_reason": "head_limit_reached",
                "search_path": "src",
            },
            meta={"pattern": "*.py", "search_path": "src"},
        )
        formatted = OutputFormatter.format(
            tool_name="Glob", tool_call_id="tc_glob_trunc", result_dict=payload
        )
        self.assertIn(
            "(Results are truncated. Consider using a more specific path or pattern.)",
            formatted.text,
        )
        self.assertNotIn("[Showing results with pagination", formatted.text)

    # ──────────────── T6: Team formatters ────────────────

    def test_format_send_message_unicast_no_yieldturn_hint(self) -> None:
        payload = ok(
            data={"to": "researcher", "type": "message", "delivered_to": ["researcher"]},
            meta={"from": "lead", "team": "alpha", "content": "check auth module"},
        )
        formatted = OutputFormatter.format(
            tool_name="SendMessage", tool_call_id="tc_sm1", result_dict=payload
        )
        self.assertIn("lead → researcher", formatted.text)
        self.assertIn("team=alpha", formatted.text)
        self.assertIn("check auth module", formatted.text)
        yt_hints = [
            h for h in (formatted.meta.retrieval_hints or []) if h.get("action") == "YieldTurn"
        ]
        self.assertEqual(yt_hints, [])

    def test_format_send_message_broadcast_has_yieldturn_hint(self) -> None:
        payload = ok(
            data={"to": "*", "type": "message", "delivered_to": ["a", "b"]},
            meta={"from": "lead", "team": "alpha", "content": "phase 1 done"},
        )
        formatted = OutputFormatter.format(
            tool_name="SendMessage", tool_call_id="tc_sm2", result_dict=payload
        )
        self.assertIn("Recommended next step:", formatted.text)
        self.assertIn("YieldTurn", formatted.text)
        yt_hints = [
            h for h in (formatted.meta.retrieval_hints or []) if h.get("action") == "YieldTurn"
        ]
        self.assertEqual(len(yt_hints), 1)

    def test_format_send_message_shutdown_has_yieldturn_hint(self) -> None:
        payload = ok(
            data={"to": "*", "type": "shutdown_request", "delivered_to": ["a", "b"]},
            meta={"from": "lead", "team": "alpha", "content": "wrap up"},
        )
        formatted = OutputFormatter.format(
            tool_name="SendMessage", tool_call_id="tc_sm3", result_dict=payload
        )
        self.assertIn("shutdown_request", formatted.text)
        yt_hints = [
            h for h in (formatted.meta.retrieval_hints or []) if h.get("action") == "YieldTurn"
        ]
        self.assertEqual(len(yt_hints), 1)

    def test_format_send_message_content_preview_truncates(self) -> None:
        long_content = "a" * 200
        payload = ok(
            data={"to": "r", "type": "message", "delivered_to": ["r"]},
            meta={"from": "lead", "team": "alpha", "content": long_content},
        )
        formatted = OutputFormatter.format(
            tool_name="SendMessage", tool_call_id="tc_sm4", result_dict=payload
        )
        self.assertIn("...", formatted.text)
        self.assertNotIn("a" * 200, formatted.text)

    def test_format_team_create_has_agent_spawn_hint(self) -> None:
        payload = ok(
            data={
                "team_name": "alpha",
                "config_path": "/home/u/.agent/teams/alpha/config.json",
                "description": "research team",
            },
            meta={"leader": "lead"},
        )
        formatted = OutputFormatter.format(
            tool_name="TeamCreate", tool_call_id="tc_tc1", result_dict=payload
        )
        self.assertIn("TeamCreate: alpha", formatted.text)
        self.assertIn("Leader: lead", formatted.text)
        self.assertIn("Agent(", formatted.text)
        agent_hints = [
            h for h in (formatted.meta.retrieval_hints or []) if h.get("action") == "Agent"
        ]
        self.assertEqual(len(agent_hints), 1)
        self.assertEqual(agent_hints[0]["args"]["team_name"], "alpha")

    def test_format_team_delete_shows_cleaned_list(self) -> None:
        payload = ok(
            data={
                "team_name": "alpha",
                "cleaned": [
                    "team_dir: /home/u/.agent/teams/alpha",
                    "task_file: /home/u/.agent/tasks/alpha.json",
                ],
            }
        )
        formatted = OutputFormatter.format(
            tool_name="TeamDelete", tool_call_id="tc_td1", result_dict=payload
        )
        self.assertIn("TeamDelete: alpha", formatted.text)
        self.assertIn("team_dir: /home/u/.agent/teams/alpha", formatted.text)
        # TeamDelete 不加 hint
        self.assertIsNone(formatted.meta.retrieval_hints)

    def test_format_team_delete_empty_cleaned(self) -> None:
        payload = ok(data={"team_name": "ghost", "cleaned": []})
        formatted = OutputFormatter.format(
            tool_name="TeamDelete", tool_call_id="tc_td2", result_dict=payload
        )
        self.assertIn("nothing cleaned", formatted.text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
