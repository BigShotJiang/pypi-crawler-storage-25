import asyncio
import json
import tempfile
from pathlib import Path

from comate_agent_sdk.system_tools.policy_engine import (
    BASH_COMMAND_POLICY,
    READ_REGISTRY_POLICY,
)


def test_bash_policy_requires_rg_max_count() -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        violation = BASH_COMMAND_POLICY.validate(
            command=f"rg --line-number --no-heading --color=never foo {root}",
            cwd=root,
            allowed_roots=[root],
        )
        assert violation is not None
        assert violation.code == "POLICY_DENIED"


def test_bash_policy_accepts_valid_rg_scope() -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        violation = BASH_COMMAND_POLICY.validate(
            command=f"rg --line-number --no-heading --color=never --max-count 10 foo {root}",
            cwd=root,
            allowed_roots=[root],
        )
        assert violation is None


def test_bash_policy_rejects_malformed_command() -> None:
    violation = BASH_COMMAND_POLICY.validate(
        command="'unterminated",
        cwd=Path.cwd(),
        allowed_roots=[Path.cwd()],
    )
    assert violation is not None
    assert violation.code == "INVALID_ARGUMENT"


def test_bash_policy_allows_cd_only() -> None:
    violation = BASH_COMMAND_POLICY.validate(
        command="cd src",
        cwd=Path.cwd(),
        allowed_roots=[Path.cwd()],
    )
    assert violation is None


def test_bash_policy_allows_cd_in_compound_command() -> None:
    violation = BASH_COMMAND_POLICY.validate(
        command="cd src && git diff",
        cwd=Path.cwd(),
        allowed_roots=[Path.cwd()],
    )
    assert violation is None


def test_bash_policy_allows_previously_banned_commands() -> None:
    """对齐 Claude Code 哲学后，cat/ls/head/tail/find/grep 不再被运行时拦截。"""
    cwd = Path.cwd()
    for command in (
        "cat a.txt",
        "ls /tmp",
        "head -10 a.txt",
        "tail -20 a.txt",
        "find . -name foo",
        "grep pattern file",
    ):
        violation = BASH_COMMAND_POLICY.validate(
            command=command,
            cwd=cwd,
            allowed_roots=[cwd],
        )
        assert violation is None, (
            f"Expected {command!r} to be allowed under CC-aligned policy, "
            f"got violation {violation!r}"
        )


def test_bash_policy_allows_pipeline_with_previously_banned_commands() -> None:
    """复合命令和 pipeline 中含 cat/head 等也应放行（spec A1 决议）。"""
    cwd = Path.cwd()

    # 复合命令（多 segment 用 ; 拆分）
    violation = BASH_COMMAND_POLICY.validate(
        command="echo start; cat a.txt",
        cwd=cwd,
        allowed_roots=[cwd],
    )
    assert violation is None

    # pipeline：rg 后接 head（rg 仍需 max-count + 显式 PATH——保留护栏）
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        violation = BASH_COMMAND_POLICY.validate(
            command=(
                f"rg --line-number --no-heading --color=never --max-count 10 "
                f"foo {root} | head -20"
            ),
            cwd=root,
            allowed_roots=[root],
        )
        assert violation is None


def test_read_registry_policy_persists_to_session_root() -> None:
    READ_REGISTRY_POLICY.clear_memory()

    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        session_root = root / "sessions" / "s1"
        target = root / "a.txt"
        target.write_text("x\n", encoding="utf-8")

        async def _run() -> bool:
            await READ_REGISTRY_POLICY.mark_read(
                session_root=session_root,
                session_id="s1",
                path=target,
            )
            return await READ_REGISTRY_POLICY.has_read(
                session_root=session_root,
                session_id="s1",
                path=target,
            )

        assert asyncio.run(_run())
        idx = session_root / "read_index.json"
        assert idx.exists()
        payload = json.loads(idx.read_text(encoding="utf-8"))
        assert payload.get("schema_version") == 5
        assert str(target.resolve()) in payload.get("files", [])


def test_read_registry_policy_tracks_ranges_by_version() -> None:
    READ_REGISTRY_POLICY.clear_memory()

    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        session_root = root / "sessions" / "s1"
        target = root / "a.txt"
        target.write_text("x\n", encoding="utf-8")

        async def _run() -> tuple[bool, bool, bool]:
            await READ_REGISTRY_POLICY.mark_read_range(
                session_root=session_root,
                session_id="s1",
                path=target,
                sha256="sha-a",
                offset_line=1,
                limit_lines=100,
            )
            same_range = await READ_REGISTRY_POLICY.has_read_range(
                session_root=session_root,
                session_id="s1",
                path=target,
                sha256="sha-a",
                offset_line=1,
                limit_lines=100,
            )
            different_range = await READ_REGISTRY_POLICY.has_read_range(
                session_root=session_root,
                session_id="s1",
                path=target,
                sha256="sha-a",
                offset_line=101,
                limit_lines=100,
            )
            different_version = await READ_REGISTRY_POLICY.has_read_range(
                session_root=session_root,
                session_id="s1",
                path=target,
                sha256="sha-b",
                offset_line=1,
                limit_lines=100,
            )
            return same_range, different_range, different_version

        same_range, different_range, different_version = asyncio.run(_run())
        assert same_range is True
        assert different_range is False
        assert different_version is False

        idx = session_root / "read_index.json"
        payload = json.loads(idx.read_text(encoding="utf-8"))
        assert payload.get("schema_version") == 5
        ranges = payload.get("read_ranges", {})
        assert str(target.resolve()) in ranges


def test_read_registry_policy_does_not_reuse_legacy_range_signature() -> None:
    READ_REGISTRY_POLICY.clear_memory()

    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        session_root = root / "sessions" / "s1"
        session_root.mkdir(parents=True, exist_ok=True)
        target = root / "a.txt"
        target.write_text("x\n", encoding="utf-8")

        payload = {
            "schema_version": 5,
            "files": [str(target.resolve())],
            "file_versions": {str(target.resolve()): "sha-a"},
            "read_ranges": {
                str(target.resolve()): ["sha-a|offset_semantics_version=2|1|100|line_numbers|2000"],
            },
        }
        (session_root / "read_index.json").write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        async def _run() -> tuple[bool, bool]:
            has_read = await READ_REGISTRY_POLICY.has_read(
                session_root=session_root,
                session_id="s1",
                path=target,
            )
            has_range = await READ_REGISTRY_POLICY.has_read_range(
                session_root=session_root,
                session_id="s1",
                path=target,
                sha256="sha-a",
                offset_line=1,
                limit_lines=100,
            )
            return has_read, has_range

        has_read, has_range = asyncio.run(_run())
        assert has_read is True
        assert has_range is False


def test_read_registry_policy_can_clear_ranges_for_path() -> None:
    READ_REGISTRY_POLICY.clear_memory()

    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        session_root = root / "sessions" / "s1"
        target = root / "a.txt"
        target.write_text("x\n", encoding="utf-8")

        async def _run() -> tuple[bool, bool]:
            await READ_REGISTRY_POLICY.mark_read_range(
                session_root=session_root,
                session_id="s1",
                path=target,
                sha256="sha-a",
                offset_line=1,
                limit_lines=100,
            )
            before_clear = await READ_REGISTRY_POLICY.has_read_range(
                session_root=session_root,
                session_id="s1",
                path=target,
                sha256="sha-a",
                offset_line=1,
                limit_lines=100,
            )
            await READ_REGISTRY_POLICY.clear_read_ranges_for_path(
                session_root=session_root,
                session_id="s1",
                path=target,
            )
            after_clear = await READ_REGISTRY_POLICY.has_read_range(
                session_root=session_root,
                session_id="s1",
                path=target,
                sha256="sha-a",
                offset_line=1,
                limit_lines=100,
            )
            return before_clear, after_clear

        before_clear, after_clear = asyncio.run(_run())
        assert before_clear is True
        assert after_clear is False


def test_read_registry_cleanup_stale_loops_removes_old_loops():
    """cleanup_stale_loops 应保留当前 loop + 最近 10 个，删除更旧的。"""
    from comate_agent_sdk.system_tools.policy_engine import ReadRegistryPolicy

    policy = ReadRegistryPolicy()
    # 注入 15 个假 loop id（小整数，不会与真实 loop 的内存地址冲突）
    for i in range(1, 16):
        policy._locks_by_loop[i]  # trigger defaultdict to create empty dict

    async def _run():
        policy.cleanup_stale_loops()

    asyncio.run(_run())

    # 当前真实 loop id 不在 1-15 中，所以 1-15 全部参与淘汰
    # 保留最近 10 个（6-15），删除最旧的 5 个（1-5）
    assert len(policy._locks_by_loop) == 10
    for i in range(6, 16):
        assert i in policy._locks_by_loop, f"loop id {i} should be retained"
    for i in range(1, 6):
        assert i not in policy._locks_by_loop, f"loop id {i} should be removed"


def test_read_registry_cleanup_stale_loops_no_op_under_limit():
    """少于等于 10 个旧 loop 时不应删除任何条目。"""
    from comate_agent_sdk.system_tools.policy_engine import ReadRegistryPolicy

    policy = ReadRegistryPolicy()
    for i in range(1, 6):
        policy._locks_by_loop[i]  # trigger defaultdict to create empty dict

    async def _run():
        policy.cleanup_stale_loops()

    asyncio.run(_run())

    assert len(policy._locks_by_loop) == 5
    for i in range(1, 6):
        assert i in policy._locks_by_loop
