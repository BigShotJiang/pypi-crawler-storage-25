from __future__ import annotations

import signal
from pathlib import Path
from unittest import mock

import pytest

from comate_agent_sdk.system_tools import bash_executor


@pytest.fixture(autouse=True)
def _clear_discover_bash_cache() -> None:
    bash_executor.discover_bash.cache_clear()
    yield
    bash_executor.discover_bash.cache_clear()


def test_build_shell_invocation_uses_command_string() -> None:
    with mock.patch.object(bash_executor, "discover_bash", return_value=Path("/bin/bash")):
        cmd = bash_executor.build_shell_invocation("git status")

    assert cmd == [
        "/bin/bash",
        "-c",
        "source ~/.bash_profile 2>/dev/null; source ~/.bashrc 2>/dev/null; git status",
    ]


def test_discover_bash_prefers_explicit_environment_override(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("COMATE_BASH_EXECUTABLE", "/custom/bash")
    assert bash_executor.discover_bash() == Path("/custom/bash")


def test_tree_kill_posix_graceful_uses_sigterm() -> None:
    with mock.patch.object(bash_executor.os, "name", "posix"), mock.patch.object(
        bash_executor.os,
        "killpg",
    ) as killpg:
        bash_executor.tree_kill(1234, force=False)

    killpg.assert_called_once_with(1234, signal.SIGTERM)


def test_tree_kill_posix_force_uses_sigkill() -> None:
    with mock.patch.object(bash_executor.os, "name", "posix"), mock.patch.object(
        bash_executor.os,
        "killpg",
    ) as killpg:
        bash_executor.tree_kill(1234, force=True)

    killpg.assert_called_once_with(1234, signal.SIGKILL)


def test_tree_kill_windows_graceful_terminates_children_then_root() -> None:
    root = mock.MagicMock()
    child1 = mock.MagicMock()
    child2 = mock.MagicMock()
    root.children.return_value = [child1, child2]

    with mock.patch.object(bash_executor.os, "name", "nt"), mock.patch.object(
        bash_executor, "psutil"
    ) as psu:
        psu.Process.return_value = root
        psu.Error = Exception

        bash_executor.tree_kill(4321, force=False)

    root.children.assert_called_once_with(recursive=True)
    child2.terminate.assert_called_once_with()
    child1.terminate.assert_called_once_with()
    root.terminate.assert_called_once_with()
    child1.kill.assert_not_called()
    child2.kill.assert_not_called()
    root.kill.assert_not_called()


def test_tree_kill_windows_force_kills_children_then_root() -> None:
    root = mock.MagicMock()
    child = mock.MagicMock()
    root.children.return_value = [child]

    with mock.patch.object(bash_executor.os, "name", "nt"), mock.patch.object(
        bash_executor, "psutil"
    ) as psu:
        psu.Process.return_value = root
        psu.Error = Exception

        bash_executor.tree_kill(4321, force=True)

    child.kill.assert_called_once_with()
    root.kill.assert_called_once_with()
    child.terminate.assert_not_called()
    root.terminate.assert_not_called()


def test_is_windows_wsl_shim_detects_system32_and_sysnative() -> None:
    assert bash_executor._is_windows_wsl_shim(r"C:\Windows\System32\bash.exe") is True
    assert bash_executor._is_windows_wsl_shim(r"c:\windows\system32\bash.exe") is True
    assert bash_executor._is_windows_wsl_shim(r"C:\Windows\Sysnative\bash.exe") is True
    assert bash_executor._is_windows_wsl_shim("C:/Windows/System32/bash.exe") is True
    assert bash_executor._is_windows_wsl_shim(r"C:\Program Files\Git\bin\bash.exe") is False
    assert bash_executor._is_windows_wsl_shim("/usr/bin/bash") is False


# -----------------------------
# 防御层：rewrite_windows_null_redirect（对齐 Claude Code src/utils/bash/shellQuoting.ts）
# 模型有时会幻觉 CMD 语法（如 `ls 2>nul`）—— bash 遇到 `2>nul` 会真创建
# 一个叫 nul 的文件，在 Windows 是保留设备名，破坏 git 且极难删除。
# 见 anthropics/claude-code#4928。
# -----------------------------


def test_rewrite_windows_null_redirect_basic_forms() -> None:
    assert bash_executor.rewrite_windows_null_redirect("ls 2>nul") == "ls 2>/dev/null"
    assert bash_executor.rewrite_windows_null_redirect("cmd >nul") == "cmd >/dev/null"
    assert bash_executor.rewrite_windows_null_redirect("cmd >> nul") == "cmd >> /dev/null"
    assert bash_executor.rewrite_windows_null_redirect("cmd &>nul") == "cmd &>/dev/null"


def test_rewrite_windows_null_redirect_case_insensitive() -> None:
    assert bash_executor.rewrite_windows_null_redirect("cmd >NUL") == "cmd >/dev/null"
    assert bash_executor.rewrite_windows_null_redirect("cmd >Nul") == "cmd >/dev/null"
    assert bash_executor.rewrite_windows_null_redirect("cmd 2>NUL") == "cmd 2>/dev/null"


def test_rewrite_windows_null_redirect_respects_word_boundaries() -> None:
    """不应改写 null / nullable / nul.txt / 参数里出现的 nul"""
    assert bash_executor.rewrite_windows_null_redirect("cmd >null") == "cmd >null"
    assert bash_executor.rewrite_windows_null_redirect("cmd >nullable") == "cmd >nullable"
    assert bash_executor.rewrite_windows_null_redirect("cmd >nul.txt") == "cmd >nul.txt"
    assert bash_executor.rewrite_windows_null_redirect("cat nul.txt") == "cat nul.txt"


def test_rewrite_windows_null_redirect_in_compound_commands() -> None:
    assert (
        bash_executor.rewrite_windows_null_redirect("rm x 2>nul && echo ok")
        == "rm x 2>/dev/null && echo ok"
    )
    assert (
        bash_executor.rewrite_windows_null_redirect("cmd >nul | next")
        == "cmd >/dev/null | next"
    )


def test_build_shell_invocation_rewrites_windows_null_redirect() -> None:
    """集成：build_shell_invocation 在拼装命令前应用重写，防止 bash 创建字面量 nul 文件。"""
    with mock.patch.object(bash_executor, "discover_bash", return_value=Path("/bin/bash")):
        cmd = bash_executor.build_shell_invocation("rm -f tmp 2>nul")

    assert cmd[2].endswith("rm -f tmp 2>/dev/null")
    assert "2>nul" not in cmd[2]


def test_discover_bash_falls_back_when_which_returns_wsl_shim(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("COMATE_BASH_EXECUTABLE", raising=False)
    git_bash = Path(r"C:\Program Files\Git\bin\bash.exe")

    real_is_file = Path.is_file

    def fake_is_file(self: Path) -> bool:
        if self == git_bash:
            return True
        if str(self) == "/bin/bash":
            return False
        return real_is_file(self)

    with mock.patch.object(bash_executor.os, "name", "nt"), mock.patch.object(
        bash_executor, "_is_wsl", return_value=False
    ), mock.patch.object(
        bash_executor.shutil, "which", return_value=r"C:\Windows\System32\bash.exe"
    ), mock.patch.object(
        bash_executor, "_WINDOWS_GIT_BASH_CANDIDATES", (git_bash,)
    ), mock.patch.object(
        Path, "is_file", fake_is_file
    ):
        assert bash_executor.discover_bash() == git_bash
