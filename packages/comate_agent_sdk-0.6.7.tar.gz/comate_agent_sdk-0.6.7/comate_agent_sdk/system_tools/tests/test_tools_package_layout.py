from comate_agent_sdk.system_tools.tools import Bash as FacadeBash
from comate_agent_sdk.system_tools.tools import Read as FacadeRead
from comate_agent_sdk.system_tools.tools import SYSTEM_TOOLS
from comate_agent_sdk.system_tools.tools.bash import Bash as ModuleBash
from comate_agent_sdk.system_tools.tools.read import Read as ModuleRead


def test_tools_package_keeps_facade_imports_and_tool_modules() -> None:
    assert FacadeBash is ModuleBash
    assert FacadeRead is ModuleRead
    assert ModuleBash in SYSTEM_TOOLS
    assert ModuleRead in SYSTEM_TOOLS
