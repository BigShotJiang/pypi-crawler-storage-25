"""Internal utilities for system tools.

This module contains low-level helper functions extracted from tools.py
to keep the main module size under control (<700 LOC guideline).
"""
from __future__ import annotations

import asyncio
import difflib
import hashlib
import re
from collections import defaultdict
from pathlib import Path
from typing import Any, Callable

from comate_agent_sdk.system_tools.artifact_store import ArtifactStore


# ────────────────────────────────────────────────────────────────────────────
# Global state (loop-local locks and semaphores)
# ────────────────────────────────────────────────────────────────────────────
_FILE_LOCKS_BY_LOOP: dict[int, dict[str, asyncio.Lock]] = defaultdict(dict)
_BASH_SEMAPHORES: dict[int, asyncio.Semaphore] = {}


def loop_id() -> int:
    """Get the ID of the current running event loop."""
    return id(asyncio.get_running_loop())


def file_lock(path: Path) -> asyncio.Lock:
    """Get or create a per-file lock for the current event loop."""
    lid = loop_id()
    key = str(path.resolve())
    lock = _FILE_LOCKS_BY_LOOP[lid].get(key)
    if lock is None:
        lock = asyncio.Lock()
        _FILE_LOCKS_BY_LOOP[lid][key] = lock
    return lock


def bash_semaphore() -> asyncio.Semaphore:
    """Get or create a bash semaphore (max 4 concurrent) for the current event loop."""
    lid = loop_id()
    sem = _BASH_SEMAPHORES.get(lid)
    if sem is None:
        sem = asyncio.Semaphore(4)
        _BASH_SEMAPHORES[lid] = sem
    return sem


# ────────────────────────────────────────────────────────────────────────────
# Hash utilities
# ────────────────────────────────────────────────────────────────────────────
def sha256_text(text: str) -> str:
    """Compute SHA-256 hex digest of UTF-8 encoded text."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def sha256_bytes(payload: bytes) -> str:
    """Compute SHA-256 hex digest of raw bytes."""
    return hashlib.sha256(payload).hexdigest()


# ────────────────────────────────────────────────────────────────────────────
# Text truncation
# ────────────────────────────────────────────────────────────────────────────
def truncate_text(text: str, max_chars: int) -> str:
    """Truncate text to max_chars, appending '...(truncated)' if needed."""
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + "\n...(truncated)"


def truncate_line(line: str, max_chars: int) -> str:
    """Truncate a single line to max_chars, appending '...(truncated)' if needed."""
    if len(line) <= max_chars:
        return line
    return line[:max_chars] + "...(truncated)"


# ────────────────────────────────────────────────────────────────────────────
# TTL cache cleanup
# ────────────────────────────────────────────────────────────────────────────
def cleanup_ttl_cache(cache: dict[str, dict[str, Any]], *, now: float, ttl: int) -> None:
    """Remove expired entries from a TTL cache.

    Args:
        cache: Dict mapping keys to dicts with 'ts' field
        now: Current timestamp (seconds since epoch)
        ttl: Time-to-live in seconds
    """
    expired: list[str] = []
    for k, v in cache.items():
        ts = float(v.get("ts", 0.0))
        if now - ts > ttl:
            expired.append(k)
    for k in expired:
        cache.pop(k, None)


def cleanup_loop_local_dicts() -> None:
    """Clean up loop-local dictionaries, keeping current + 10 most recent loops.

    Prevents unbounded memory growth in long-running processes.
    Cleans both _FILE_LOCKS_BY_LOOP and _BASH_SEMAPHORES.
    """
    try:
        current_lid = loop_id()
    except RuntimeError:
        # No running loop (shouldn't happen in normal usage)
        return

    # Collect all loop IDs from both dicts
    all_lids = sorted(set(_FILE_LOCKS_BY_LOOP.keys()) | set(_BASH_SEMAPHORES.keys()))
    if current_lid in all_lids:
        all_lids.remove(current_lid)

    # Remove oldest loops beyond the retention limit (keep 10 most recent)
    retention_limit = 10
    if len(all_lids) > retention_limit:
        to_remove = all_lids[:-retention_limit]
        for lid in to_remove:
            _FILE_LOCKS_BY_LOOP.pop(lid, None)
            _BASH_SEMAPHORES.pop(lid, None)


# ────────────────────────────────────────────────────────────────────────────
# Async I/O wrapper
# ────────────────────────────────────────────────────────────────────────────
async def io_call(func: Callable, /, *args: Any, **kwargs: Any) -> Any:
    """Run a blocking I/O function in a thread pool executor."""
    return await asyncio.to_thread(func, *args, **kwargs)


# ────────────────────────────────────────────────────────────────────────────
# Unified diff generation
# ────────────────────────────────────────────────────────────────────────────
def generate_unified_diff(
    before: str,
    after: str,
    fromfile: str = "",
    tofile: str = "",
) -> list[str]:
    """Generate unified diff lines between two strings.

    Args:
        before: Original text
        after: Modified text
        fromfile: Label for 'before' (e.g., filename)
        tofile: Label for 'after' (e.g., filename)

    Returns:
        List of diff lines (without trailing newlines)
    """
    before_lines = before.splitlines(keepends=True)
    after_lines = after.splitlines(keepends=True)
    diff = difflib.unified_diff(
        before_lines,
        after_lines,
        fromfile=fromfile,
        tofile=tofile,
    )
    return [line.rstrip("\n") for line in diff]


_UNIFIED_DIFF_HUNK_RE = re.compile(
    r"^@@ -(?P<old_start>\d+)(?:,(?P<old_lines>\d+))? "
    r"\+(?P<new_start>\d+)(?:,(?P<new_lines>\d+))? @@"
)


def _parse_hunk_line_count(raw: str | None) -> int:
    return 1 if raw is None else int(raw)


def generate_structured_patch(
    before: str,
    after: str,
    *,
    fromfile: str = "",
    tofile: str = "",
) -> list[dict[str, Any]]:
    """Generate structured unified diff hunks using SDK field names."""
    diff_lines = generate_unified_diff(before, after, fromfile=fromfile, tofile=tofile)
    hunks: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None

    for line in diff_lines:
        match = _UNIFIED_DIFF_HUNK_RE.match(line)
        if match:
            if current is not None:
                hunks.append(current)
            current = {
                "old_start": int(match.group("old_start")),
                "old_lines": _parse_hunk_line_count(match.group("old_lines")),
                "new_start": int(match.group("new_start")),
                "new_lines": _parse_hunk_line_count(match.group("new_lines")),
                "lines": [],
            }
            continue
        if current is not None:
            current["lines"].append(line)

    if current is not None:
        hunks.append(current)
    return hunks


LEFT_SINGLE_CURLY_QUOTE = "‘"
RIGHT_SINGLE_CURLY_QUOTE = "’"
LEFT_DOUBLE_CURLY_QUOTE = "“"
RIGHT_DOUBLE_CURLY_QUOTE = "”"


def normalize_quotes(text: str) -> str:
    return (
        text.replace(LEFT_SINGLE_CURLY_QUOTE, "'")
        .replace(RIGHT_SINGLE_CURLY_QUOTE, "'")
        .replace(LEFT_DOUBLE_CURLY_QUOTE, '"')
        .replace(RIGHT_DOUBLE_CURLY_QUOTE, '"')
    )


def strip_trailing_whitespace(text: str) -> str:
    """Strip trailing whitespace from each line while preserving line endings."""
    if text == "":
        return text

    parts: list[str] = []
    for line in text.splitlines(keepends=True):
        if line.endswith("\r\n"):
            body = line[:-2]
            ending = "\r\n"
        elif line.endswith("\n") or line.endswith("\r"):
            body = line[:-1]
            ending = line[-1]
        else:
            body = line
            ending = ""
        parts.append(re.sub(r"[^\S\r\n]+$", "", body) + ending)
    return "".join(parts)


def find_similar_file(file_path: str | Path) -> str | None:
    """Find a sibling with the same stem but a different extension."""
    candidate = Path(file_path)
    try:
        directory = candidate.parent
        stem = candidate.stem
        for sibling in sorted(directory.iterdir(), key=lambda item: item.name):
            if sibling.name == candidate.name:
                continue
            if not sibling.is_file():
                continue
            if sibling.stem == stem:
                return sibling.name
    except FileNotFoundError:
        return None
    except NotADirectoryError:
        return None
    return None


def find_edit_matches(file_content: str, search_string: str) -> list[tuple[int, int, str]]:
    if search_string == "":
        return [(0, 0, "")]

    matches: list[tuple[int, int, str]] = []
    start = 0
    while True:
        index = file_content.find(search_string, start)
        if index < 0:
            break
        end = index + len(search_string)
        matches.append((index, end, search_string))
        start = end
    if matches:
        return matches

    normalized_search = normalize_quotes(search_string)
    normalized_file = normalize_quotes(file_content)
    start = 0
    while True:
        index = normalized_file.find(normalized_search, start)
        if index < 0:
            break
        end = index + len(search_string)
        matches.append((index, end, file_content[index:end]))
        start = end
    return matches


def _quote_style_targets(*, old_string: str, actual_old_string: str, quote_char: str) -> list[str]:
    targets: list[str] = []
    for expected_char, actual_char in zip(old_string, actual_old_string, strict=False):
        if expected_char == quote_char and actual_char != quote_char:
            targets.append(actual_char)
    return targets


def _apply_quote_targets(text: str, *, quote_char: str, targets: list[str]) -> str:
    if not targets:
        return text
    if text.count(quote_char) != len(targets):
        return text

    result: list[str] = []
    target_index = 0
    for char in text:
        if char == quote_char:
            result.append(targets[target_index])
            target_index += 1
            continue
        result.append(char)
    return "".join(result)


def preserve_quote_style(old_string: str, actual_old_string: str, new_string: str) -> str:
    if old_string == actual_old_string:
        return new_string

    double_quote_targets = _quote_style_targets(
        old_string=old_string,
        actual_old_string=actual_old_string,
        quote_char='"',
    )
    single_quote_targets = _quote_style_targets(
        old_string=old_string,
        actual_old_string=actual_old_string,
        quote_char="'",
    )
    if not double_quote_targets and not single_quote_targets:
        return new_string

    result = new_string
    result = _apply_quote_targets(
        result,
        quote_char='"',
        targets=double_quote_targets,
    )
    result = _apply_quote_targets(
        result,
        quote_char="'",
        targets=single_quote_targets,
    )
    return result


def _is_full_line_match(content: str, *, start: int, end: int) -> bool:
    line_start = content.rfind("\n", 0, start) + 1
    line_end = content.find("\n", end)
    if line_end < 0:
        line_end = len(content)
    return start == line_start and end == line_end


def count_text_lines(text: str) -> int:
    if text == "":
        return 0
    return len(text.splitlines())


def apply_edit_matches(
    original_content: str,
    *,
    old_string: str,
    new_string: str,
    matches: list[tuple[int, int, str]],
    replace_all: bool,
) -> str:
    if not matches:
        return original_content

    selected_matches = matches if replace_all else matches[:1]
    result: list[str] = []
    last_index = 0
    for start, end, actual_old_string in selected_matches:
        result.append(original_content[last_index:start])
        replacement = preserve_quote_style(old_string, actual_old_string, new_string)
        adjusted_end = end
        if (
            new_string == ""
            and not actual_old_string.endswith("\n")
            and original_content.startswith("\n", end)
            and _is_full_line_match(original_content, start=start, end=end)
        ):
            adjusted_end += 1
        result.append(replacement)
        last_index = adjusted_end
    result.append(original_content[last_index:])
    return "".join(result)


# ────────────────────────────────────────────────────────────────────────────
# Artifact spilling (high-level wrappers, still depends on ctx)
# ────────────────────────────────────────────────────────────────────────────
async def spill_text(
    *,
    artifact_store: ArtifactStore,
    namespace: str,
    text: str,
    mime: str,
    ttl_seconds: int,
) -> dict[str, Any]:
    """Spill large text to artifact store.

    Args:
        artifact_store: ArtifactStore instance
        namespace: Artifact namespace (e.g., 'read', 'bash')
        text: Text content to spill
        mime: MIME type (e.g., 'text/plain')
        ttl_seconds: Time-to-live in seconds

    Returns:
        Artifact metadata dict (relpath, size, etc.)
    """
    return await artifact_store.put_text(
        namespace=namespace,
        text=text,
        mime=mime,
        ttl_seconds=ttl_seconds,
    )


async def spill_json(
    *,
    artifact_store: ArtifactStore,
    namespace: str,
    data: Any,
    ttl_seconds: int,
) -> dict[str, Any]:
    """Spill JSON-serializable data to artifact store.

    Args:
        artifact_store: ArtifactStore instance
        namespace: Artifact namespace (e.g., 'grep_files')
        data: JSON-serializable data
        ttl_seconds: Time-to-live in seconds

    Returns:
        Artifact metadata dict (relpath, size, etc.)
    """
    return await artifact_store.put_json(
        namespace=namespace,
        data=data,
        ttl_seconds=ttl_seconds,
    )


def format_file_size(size_bytes: int) -> str:
    """智能单位转换：B/KB/MB/GB

    Args:
        size_bytes: 文件大小（字节）

    Returns:
        带单位的可读字符串（如 "1.5KB", "512B", "2.3MB"）
    """
    if size_bytes < 1024:
        return f"{size_bytes}B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f}KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / 1024 / 1024:.1f}MB"
    else:
        return f"{size_bytes / 1024 / 1024 / 1024:.1f}GB"
