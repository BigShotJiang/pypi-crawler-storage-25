from __future__ import annotations

import functools
import logging
import os
import re
import shutil
import signal
from pathlib import Path

import psutil

logger = logging.getLogger(__name__)

# 对齐 Claude Code src/utils/bash/shellQuoting.ts:124。
# 模型偶尔会幻觉 CMD 语法（`ls 2>nul`），bash 下会字面创建一个叫 nul 的文件 ——
# Windows 上 NUL 是保留设备名，该文件极难删除且会破坏 git。见 anthropics/claude-code#4928。
# 在 POSIX 上同样执行重写：`nul` 字面量文件在 Linux 也是无用垃圾，无条件改写零副作用。
_NUL_REDIRECT_PATTERN = re.compile(r"(\d?&?>+\s*)[Nn][Uu][Ll](?=\s|$|[|&;)\n])")

_WINDOWS_GIT_BASH_CANDIDATES = (
    Path(r"C:\Program Files\Git\bin\bash.exe"),
    Path(r"C:\Program Files (x86)\Git\bin\bash.exe"),
)
_BASH_RC_PREAMBLE = "source ~/.bash_profile 2>/dev/null; source ~/.bashrc 2>/dev/null; "
_WSL_SHIM_SUFFIXES = (
    r"\windows\system32\bash.exe",
    r"\windows\sysnative\bash.exe",
)


def _is_wsl() -> bool:
    try:
        content = Path("/proc/version").read_text(encoding="utf-8", errors="ignore").lower()
    except OSError:
        return False
    return "microsoft" in content or "wsl" in content


def _is_windows_wsl_shim(path_str: str) -> bool:
    normalized = path_str.replace("/", "\\").lower()
    return any(normalized.endswith(suffix) for suffix in _WSL_SHIM_SUFFIXES)


@functools.cache
def discover_bash() -> Path:
    override = str(os.getenv("COMATE_BASH_EXECUTABLE", "")).strip()
    if override:
        return Path(override)

    if os.name != "nt" or _is_wsl():
        candidate = Path("/bin/bash")
        if candidate.is_file():
            return candidate

    which_bash = shutil.which("bash.exe" if os.name == "nt" else "bash")
    if which_bash:
        if os.name == "nt" and _is_windows_wsl_shim(which_bash):
            logger.warning(
                "Ignoring WSL bash shim at %s; set COMATE_BASH_EXECUTABLE to pin a Git Bash path.",
                which_bash,
            )
        else:
            return Path(which_bash)

    if os.name == "nt":
        for candidate in _WINDOWS_GIT_BASH_CANDIDATES:
            if candidate.is_file():
                return candidate

    raise FileNotFoundError("bash executable not found")


def rewrite_windows_null_redirect(command: str) -> str:
    """把 Windows CMD 风格的 `>nul` / `2>nul` 重写为 POSIX `/dev/null`。

    匹配：`>nul`, `> NUL`, `2>nul`, `&>nul`, `>>nul`（大小写不敏感）
    不匹配：`>null`, `>nullable`, `>nul.txt`, `cat nul.txt`
    """
    return _NUL_REDIRECT_PATTERN.sub(r"\1/dev/null", command)


def build_shell_invocation(command: str) -> list[str]:
    bash_path = discover_bash()
    return [
        str(bash_path),
        "-c",
        _BASH_RC_PREAMBLE + rewrite_windows_null_redirect(command),
    ]


def tree_kill(pid: int, *, force: bool) -> None:
    if os.name != "nt":
        sig = signal.SIGKILL if force else signal.SIGTERM
        os.killpg(pid, sig)
        return

    proc = psutil.Process(pid)
    children = proc.children(recursive=True)
    for child in reversed(children):
        try:
            if force:
                child.kill()
            else:
                child.terminate()
        except psutil.Error:
            logger.debug("failed to signal child process %s", child.pid, exc_info=True)

    if force:
        proc.kill()
    else:
        proc.terminate()
