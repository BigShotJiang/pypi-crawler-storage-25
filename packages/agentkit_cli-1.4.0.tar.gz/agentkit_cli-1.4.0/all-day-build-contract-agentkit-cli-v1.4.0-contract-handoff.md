# All-Day Build Contract: agentkit-cli v1.4.0 contract handoff

Status: In progress
Owner: subagent agentkit-next-spec-builder
Scope type: Deliverable-gated

## Objective

Restore the missing `agentkit contract` command on top of the shipped `v1.3.0 map` branch, then make the contract builder map-aware so the advertised `analyze -> map -> contract` lane is real in the current repo truth.

## Why this build

The current shipped map branch documents and markets `analyze -> map -> contract`, but the actual CLI surface in that branch does not expose a `contract` command. That contradiction is the sharpest adjacent gap in the workflow.

## Deliverables

- [ ] Reintroduce deterministic contract engine + CLI on the current map branch
- [ ] Extend the contract flow so it can ingest repo-map context directly from a local target or saved map JSON
- [ ] Add focused tests for contract restore and map-aware handoff behavior
- [ ] Update README/help text for the real handoff workflow
- [ ] Run focused validation and record current repo state

## Non-negotiable rules

1. Use only this isolated worktree.
2. Prefer deterministic behavior and schema-backed output.
3. Do not refactor unrelated command surfaces.
4. Keep the feature narrow: restore `contract`, then improve the `map -> contract` handoff.
5. End with concrete implementation progress, not just notes.

## Test requirements

- [ ] Run focused `contract` and `map` tests while iterating
- [ ] Re-run a stable focused slice after docs/CLI wiring lands
- [ ] Record exact commands and results in the final handoff

## Stop conditions

- If porting `contract` reveals incompatible upstream drift that would make behavior non-deterministic, stop and write a decision memo.
- If the map-aware extension broadens beyond a narrow handoff improvement, cut scope and ship the restore first.
