"""
Comprehensive Unit Tests for Pollinations AI Models.

Tests all FREE Pollinations AI models for:
- Model format validation
- API request format
- Coding task capabilities
- Text prompt handling

All models listed at https://pollinations.ai/models (Text tab, non-PAID)
"""

import os
from unittest.mock import MagicMock, patch

import httpx
import pytest

# ═══════════════════════════════════════════════════════════════════════════════
# POLLINATIONS MODEL DEFINITIONS
# ═══════════════════════════════════════════════════════════════════════════════

# All FREE text models from Pollinations AI
# Ordered by responses per pollen (capacity)
POLLINATIONS_FREE_MODELS = [
    # High capacity models (>1000 responses per pollen)
    {"id": "qwen-safety", "name": "Qwen3Guard 8B", "capacity": 125000, "capabilities": []},
    {"id": "nova-fast", "name": "Nova Micro", "capacity": 9100, "capabilities": []},
    {"id": "mistral", "name": "Mistral Small 3.2", "capacity": 4300, "capabilities": ["vision"]},
    {
        "id": "gemini-fast",
        "name": "Gemini 2.5 Flash Lite",
        "capacity": 2100,
        "capabilities": ["vision", "search", "code_exec"],
    },
    {"id": "nova", "name": "Nova 2 Lite", "capacity": 1400, "capabilities": ["reasoning"]},
    {"id": "grok", "name": "Grok 4.1 Fast", "capacity": 1300, "capabilities": []},
    {"id": "openai", "name": "GPT-5.4 Nano", "capacity": 1200, "capabilities": ["vision"]},
    {
        "id": "gemini-search",
        "name": "Gemini 2.5 Flash Lite Search",
        "capacity": 1100,
        "capabilities": ["vision", "search", "code_exec"],
    },
    {"id": "qwen-coder", "name": "Qwen3 Coder 30B", "capacity": 1000, "capabilities": []},
    {
        "id": "perplexity-fast",
        "name": "Perplexity Sonar",
        "capacity": 950,
        "capabilities": ["search"],
    },
    {"id": "openai-fast", "name": "GPT-5 Nano", "capacity": 700, "capabilities": ["vision"]},
    # Medium capacity models (100-500 responses per pollen)
    {
        "id": "qwen-vision",
        "name": "Qwen3 VL 30B Thinking",
        "capacity": 400,
        "capabilities": ["vision", "reasoning"],
    },
    {"id": "minimax", "name": "MiniMax M2.7", "capacity": 250, "capabilities": ["reasoning"]},
    {
        "id": "openai-audio",
        "name": "GPT Audio Mini",
        "capacity": 150,
        "capabilities": ["vision", "audio_in", "audio_out"],
    },
    {"id": "deepseek", "name": "DeepSeek V3.2", "capacity": 150, "capabilities": ["reasoning"]},
    {"id": "midijourney", "name": "MIDIjourney", "capacity": 100, "capabilities": []},
    {"id": "claude-fast", "name": "Claude Haiku 4.5", "capacity": 100, "capabilities": ["vision"]},
    {
        "id": "kimi",
        "name": "Moonshot Kimi K2.5",
        "capacity": 100,
        "capabilities": ["vision", "reasoning"],
    },
]

# Models best suited for coding tasks
CODING_MODELS = [
    "qwen-coder",  # Specialized coding model
    "deepseek",  # Known for code quality
    "grok",  # Good general coding
    "openai",  # Reliable coding
    "openai-fast",  # Fast coding
    "mistral",  # Good coding
    "gemini-fast",  # Code execution
    "claude-fast",  # High quality code
]

# Models with reasoning capabilities
REASONING_MODELS = [
    "nova",
    "qwen-vision",
    "minimax",
    "deepseek",
    "kimi",
]

# Models with vision capabilities
VISION_MODELS = [
    "mistral",
    "gemini-fast",
    "openai",
    "gemini-search",
    "openai-fast",
    "qwen-vision",
    "openai-audio",
    "claude-fast",
    "kimi",
]


# ═══════════════════════════════════════════════════════════════════════════════
# MODEL FORMAT VALIDATION TESTS
# ═══════════════════════════════════════════════════════════════════════════════


class TestPollinationsModelFormat:
    """Test Pollinations model format and structure."""

    @pytest.mark.parametrize("model", POLLINATIONS_FREE_MODELS)
    def test_model_has_required_fields(self, model):
        """Each model should have id, name, and capacity."""
        assert "id" in model
        assert "name" in model
        assert "capacity" in model
        assert "capabilities" in model

    @pytest.mark.parametrize("model", POLLINATIONS_FREE_MODELS)
    def test_model_id_format(self, model):
        """Model IDs should be valid identifiers."""
        model_id = model["id"]
        assert len(model_id) > 0
        assert len(model_id) < 50
        # Should be lowercase with hyphens
        assert model_id == model_id.lower() or "-" in model_id

    @pytest.mark.parametrize("model", POLLINATIONS_FREE_MODELS)
    def test_model_capacity_positive(self, model):
        """Model capacity should be positive."""
        assert model["capacity"] > 0

    @pytest.mark.parametrize("model", POLLINATIONS_FREE_MODELS)
    def test_model_capabilities_valid(self, model):
        """Model capabilities should be from valid set."""
        valid_capabilities = {"vision", "reasoning", "search", "code_exec", "audio_in", "audio_out"}
        for cap in model["capabilities"]:
            assert cap in valid_capabilities


# ═══════════════════════════════════════════════════════════════════════════════
# API REQUEST FORMAT TESTS
# ═══════════════════════════════════════════════════════════════════════════════


class TestPollinationsRequestFormat:
    """Test API request format for Pollinations models."""

    POLLINATIONS_API_URL = "https://gen.pollinations.ai/v1/chat/completions"

    @pytest.mark.parametrize("model", POLLINATIONS_FREE_MODELS)
    def test_chat_request_format(self, model):
        """Chat request should have correct format."""
        request = {
            "model": model["id"],
            "messages": [{"role": "user", "content": "Hello"}],
            "temperature": 0.7,
            "max_tokens": 1024,
            "stream": False,
        }

        assert request["model"] == model["id"]
        assert len(request["messages"]) == 1
        assert request["messages"][0]["role"] == "user"

    @pytest.mark.parametrize("model", POLLINATIONS_FREE_MODELS)
    def test_streaming_request_format(self, model):
        """Streaming request should have stream=True."""
        request = {
            "model": model["id"],
            "messages": [{"role": "user", "content": "Hello"}],
            "stream": True,
        }

        assert request["stream"] is True

    def test_authorization_header_format(self):
        """Authorization header should be Bearer token format."""
        api_key = "sk_test_key"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

        assert headers["Authorization"].startswith("Bearer ")
        assert "sk_" in headers["Authorization"]


# ═══════════════════════════════════════════════════════════════════════════════
# CODING TASK TESTS
# ═══════════════════════════════════════════════════════════════════════════════


class TestPollinationsCodingTasks:
    """Test coding task prompts for Pollinations models."""

    CODING_PROMPTS = [
        "Write a Python function to check if a number is prime.",
        "Write a JavaScript function to reverse a string.",
        "Write a Python function that calculates the factorial of a number.",
        "Write a simple REST API endpoint in Python using FastAPI.",
        "Write a SQL query to find duplicate emails in a users table.",
    ]

    @pytest.mark.parametrize("model_id", CODING_MODELS)
    @pytest.mark.parametrize("prompt", CODING_PROMPTS)
    def test_coding_prompt_request_format(self, model_id, prompt):
        """Coding prompts should generate valid requests."""
        request = {
            "model": model_id,
            "messages": [
                {"role": "system", "content": "You are a helpful coding assistant."},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.3,  # Lower temp for code
            "max_tokens": 2048,
        }

        assert request["model"] == model_id
        assert len(request["messages"]) == 2
        assert request["temperature"] == 0.3

    @pytest.mark.parametrize("model_id", CODING_MODELS)
    def test_code_generation_system_prompt(self, model_id):
        """Code generation should use appropriate system prompt."""
        request = {
            "model": model_id,
            "messages": [
                {
                    "role": "system",
                    "content": "You are an expert Python developer. Write clean, efficient code.",
                },
                {
                    "role": "user",
                    "content": "Write a function to sort a list of dictionaries by a key.",
                },
            ],
        }

        system_msg = request["messages"][0]
        assert system_msg["role"] == "system"
        assert "Python" in system_msg["content"] or "developer" in system_msg["content"]


# ═══════════════════════════════════════════════════════════════════════════════
# TEXT PROMPT TESTS
# ═══════════════════════════════════════════════════════════════════════════════


class TestPollinationsTextPrompts:
    """Test general text prompts for all Pollinations models."""

    TEXT_PROMPTS = [
        "Hello, how are you?",
        "What is 2 + 2?",
        "Explain recursion in simple terms.",
        "Write a haiku about programming.",
        "List three benefits of test-driven development.",
    ]

    @pytest.mark.parametrize("model", POLLINATIONS_FREE_MODELS)
    @pytest.mark.parametrize("prompt", TEXT_PROMPTS)
    def test_text_prompt_request(self, model, prompt):
        """Text prompts should generate valid requests."""
        request = {
            "model": model["id"],
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.7,
            "max_tokens": 500,
        }

        assert request["model"] == model["id"]
        assert request["messages"][0]["content"] == prompt
        assert request["max_tokens"] > 0


# ═══════════════════════════════════════════════════════════════════════════════
# REASONING MODEL TESTS
# ═══════════════════════════════════════════════════════════════════════════════


class TestPollinationsReasoningModels:
    """Test reasoning prompts for reasoning-capable models."""

    REASONING_PROMPTS = [
        "If A > B and B > C, is A > C? Explain step by step.",
        "What comes next in the sequence: 2, 6, 12, 20, 30, ?",
        "A farmer has 17 sheep. All but 9 run away. How many are left?",
        "If it takes 5 machines 5 minutes to make 5 widgets, how long would it take 100 machines to make 100 widgets?",
    ]

    @pytest.mark.parametrize("model_id", REASONING_MODELS)
    @pytest.mark.parametrize("prompt", REASONING_PROMPTS)
    def test_reasoning_prompt_request(self, model_id, prompt):
        """Reasoning prompts should work with reasoning models."""
        request = {
            "model": model_id,
            "messages": [
                {"role": "system", "content": "Think step by step before answering."},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.2,  # Low temp for reasoning
        }

        assert request["model"] == model_id
        assert "step by step" in request["messages"][0]["content"].lower()


# ═══════════════════════════════════════════════════════════════════════════════
# PROVIDER IMPORT TESTS
# ═══════════════════════════════════════════════════════════════════════════════


class TestPollinationsProviderImport:
    """Test that Pollinations provider can be imported and configured."""

    def test_pollinations_models_import(self):
        """POLLINATIONS_MODELS should be importable."""
        from sage.providers.openai_compat import POLLINATIONS_MODELS

        assert len(POLLINATIONS_MODELS) >= 17  # All free models
        model_ids = [m.id for m in POLLINATIONS_MODELS]
        assert "openai" in model_ids
        assert "qwen-coder" in model_ids
        assert "deepseek" in model_ids

    def test_provider_spec_exists(self):
        """Pollinations ProviderSpec should exist."""
        from sage.providers.openai_compat import PROVIDER_SPECS

        pollinations_specs = [s for s in PROVIDER_SPECS if s.name == "pollinations"]
        assert len(pollinations_specs) == 1

        spec = pollinations_specs[0]
        # Updated URL: text.pollinations.ai is the working endpoint
        assert spec.base_url == "https://text.pollinations.ai"
        assert spec.env_var == "POLLINATIONS_API_KEY"
        assert spec.requires_key is False

    def test_openai_compat_provider_creation(self):
        """OpenAICompatProvider should be creatable for Pollinations."""
        from sage.config import SageConfig
        from sage.providers.openai_compat import PROVIDER_SPECS, OpenAICompatProvider

        pollinations_spec = next(s for s in PROVIDER_SPECS if s.name == "pollinations")
        config = SageConfig()

        provider = OpenAICompatProvider(pollinations_spec, config)
        assert provider.name == "pollinations"
        assert provider.is_available() is True  # No key required


# ═══════════════════════════════════════════════════════════════════════════════
# ENVIRONMENT VARIABLE TESTS
# ═══════════════════════════════════════════════════════════════════════════════


class TestPollinationsEnvironment:
    """Test environment variable handling for Pollinations."""

    def test_api_key_from_env(self):
        """Provider should read API key from environment."""
        with patch.dict(os.environ, {"POLLINATIONS_API_KEY": "sk_test_key"}):
            from sage.config import SageConfig
            from sage.providers.openai_compat import PROVIDER_SPECS, OpenAICompatProvider

            pollinations_spec = next(s for s in PROVIDER_SPECS if s.name == "pollinations")
            config = SageConfig()

            provider = OpenAICompatProvider(pollinations_spec, config)
            assert provider._api_key == "sk_test_key"

    def test_works_without_api_key(self):
        """Provider should work without API key (free tier)."""
        with patch.dict(os.environ, {}, clear=True):
            # Remove any existing key
            os.environ.pop("POLLINATIONS_API_KEY", None)

            from sage.config import SageConfig
            from sage.providers.openai_compat import PROVIDER_SPECS, OpenAICompatProvider

            pollinations_spec = next(s for s in PROVIDER_SPECS if s.name == "pollinations")
            config = SageConfig()

            provider = OpenAICompatProvider(pollinations_spec, config)
            assert provider.is_available() is True


# ═══════════════════════════════════════════════════════════════════════════════
# MODEL LISTING TESTS
# ═══════════════════════════════════════════════════════════════════════════════


class TestPollinationsModelListing:
    """Test model listing functionality."""

    def test_list_all_models(self):
        """Provider should list all Pollinations models."""
        from sage.config import SageConfig
        from sage.providers.openai_compat import PROVIDER_SPECS, OpenAICompatProvider

        pollinations_spec = next(s for s in PROVIDER_SPECS if s.name == "pollinations")
        config = SageConfig()

        provider = OpenAICompatProvider(pollinations_spec, config)
        models = provider.list_models()

        assert len(models) >= 17
        model_ids = [m.id for m in models]

        # Check key models are present
        assert "openai" in model_ids
        assert "grok" in model_ids
        assert "qwen-coder" in model_ids
        assert "deepseek" in model_ids
        assert "claude-fast" in model_ids

    def test_model_info_structure(self):
        """Each model should have proper ModelInfo structure."""
        from sage.config import SageConfig
        from sage.providers.openai_compat import PROVIDER_SPECS, OpenAICompatProvider

        pollinations_spec = next(s for s in PROVIDER_SPECS if s.name == "pollinations")
        config = SageConfig()

        provider = OpenAICompatProvider(pollinations_spec, config)
        models = provider.list_models()

        for model in models:
            assert hasattr(model, "id")
            assert hasattr(model, "provider")
            assert hasattr(model, "name")
            assert model.provider == "pollinations"


# ═══════════════════════════════════════════════════════════════════════════════
# CLOUD MODEL ID PREFIX TESTS
# ═══════════════════════════════════════════════════════════════════════════════


class TestCloudModelIdFormat:
    """Test cloud model ID format (cloud: prefix)."""

    @pytest.mark.parametrize("model", POLLINATIONS_FREE_MODELS)
    def test_cloud_prefix_format(self, model):
        """Cloud model IDs should have cloud: prefix in API."""
        cloud_id = f"cloud:{model['id']}"
        assert cloud_id.startswith("cloud:")
        assert ":" in cloud_id

    def test_model_id_extraction(self):
        """Should be able to extract model ID from cloud: prefix."""
        cloud_id = "cloud:openai"
        model_id = cloud_id.split(":")[1]
        assert model_id == "openai"

    @pytest.mark.parametrize("model", POLLINATIONS_FREE_MODELS)
    def test_full_model_id_format(self, model):
        """Full model ID should be cloud:{model_id}."""
        full_id = f"cloud:{model['id']}"
        parts = full_id.split(":")
        assert len(parts) == 2
        assert parts[0] == "cloud"
        assert parts[1] == model["id"]


# ═══════════════════════════════════════════════════════════════════════════════
# RESILIENCE TESTS
# ═══════════════════════════════════════════════════════════════════════════════


class TestPollinationsResilience:
    """Test provider resilience against rate limits and transient failures."""

    def _provider(self):
        from sage.config import SageConfig
        from sage.providers.openai_compat import PROVIDER_SPECS, OpenAICompatProvider

        pollinations_spec = next(s for s in PROVIDER_SPECS if s.name == "pollinations")
        provider = OpenAICompatProvider(pollinations_spec, SageConfig())
        provider._rate_limiter.acquire = MagicMock(return_value=True)
        return provider

    def _rate_limited_response(self, retry_after: str = "0") -> MagicMock:
        response = MagicMock()
        response.status_code = 429
        response.headers = {"Retry-After": retry_after}
        exc = httpx.HTTPStatusError("rate limited", request=MagicMock(), response=response)
        response.raise_for_status.side_effect = exc
        return response

    def _ok_response(self, content: str = "OK") -> MagicMock:
        response = MagicMock()
        response.raise_for_status.return_value = None
        response.json.return_value = {"choices": [{"message": {"content": content}}]}
        return response

    def test_generate_retries_429_then_succeeds(self):
        """429s should back off and retry instead of failing immediately."""
        provider = self._provider()

        with (
            patch("sage.providers.openai_compat.time.sleep") as mock_sleep,
            patch("sage.providers.openai_compat.httpx.Client") as mock_client_cls,
        ):
            client = MagicMock()
            mock_client_cls.return_value.__enter__.return_value = client
            client.post.side_effect = [self._rate_limited_response("1"), self._ok_response("OK")]

            from sage.providers.base import Message

            result = provider.generate([Message(role="user", content="Ping")], model="openai")

        assert result == "OK"
        assert client.post.call_count == 2
        mock_sleep.assert_called_once()

    def test_rate_limit_uses_pollinations_retry_profile(self):
        """Pollinations should use a more patient retry profile than generic providers."""
        provider = self._provider()

        assert provider._retry_config.max_attempts >= 5
        assert provider._retry_config.base_delay >= 1.0

    def test_generate_accepts_structured_content_blocks(self):
        """Providers should accept OpenAI-style content arrays, not only raw strings."""
        provider = self._provider()

        response = MagicMock()
        response.raise_for_status.return_value = None
        response.json.return_value = {
            "choices": [
                {
                    "message": {
                        "content": [
                            {"type": "text", "text": "Hello "},
                            {"type": "output_text", "text": "world"},
                        ]
                    }
                }
            ]
        }

        with patch("sage.providers.openai_compat.httpx.Client") as mock_client_cls:
            client = MagicMock()
            mock_client_cls.return_value.__enter__.return_value = client
            client.post.return_value = response

            from sage.providers.base import Message

            result = provider.generate([Message(role="user", content="Ping")], model="openai")

        assert result == "Hello world"

    def test_stream_accepts_structured_delta_content(self):
        """Streaming chunks may also emit structured content parts."""
        provider = self._provider()

        stream_response = MagicMock()
        stream_response.raise_for_status.return_value = None
        stream_response.iter_lines.return_value = [
            'data: {"choices":[{"delta":{"content":[{"type":"text","text":"Hello"}]}}]}',
            'data: {"choices":[{"delta":{"content":[{"type":"text","text":" world"}]}}]}',
            "data: [DONE]",
        ]

        stream_ctx = MagicMock()
        stream_ctx.__enter__.return_value = stream_response
        stream_ctx.__exit__.return_value = False

        with patch("sage.providers.openai_compat.httpx.Client") as mock_client_cls:
            client = MagicMock()
            mock_client_cls.return_value.__enter__.return_value = client
            client.stream.return_value = stream_ctx

            from sage.providers.base import Message

            chunks = list(provider.stream([Message(role="user", content="Ping")], model="openai"))

        assert "".join(chunks) == "Hello world"

    def test_generate_missing_content_raises_clear_error(self):
        """If upstream omits text entirely, we should raise a clear runtime error."""
        provider = self._provider()

        response = MagicMock()
        response.raise_for_status.return_value = None
        response.json.return_value = {"choices": [{"message": {"role": "assistant"}}]}

        with (
            patch("sage.providers.openai_compat.httpx.Client") as mock_client_cls,
            pytest.raises(RuntimeError, match="without text content"),
        ):
            client = MagicMock()
            mock_client_cls.return_value.__enter__.return_value = client
            client.post.return_value = response

            from sage.providers.base import Message

            provider.generate([Message(role="user", content="Ping")], model="openai")
