"""SAGE Task Execution Management (Items 4201-4300).

Implements:
- Task State Machine (Items 4201-4250)
- Comprehensive Task Execution (Items 4251-4300)
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import Any

from sage.core.reasoning_engine import AdvancedReasoningEngine
from sage.core.context_persistence import ContextPersistenceManager, TaskProgress
from sage.core.tdd import TDDGate


class TaskState(Enum):
    """Status of a task."""

    PENDING = auto()
    RUNNING = auto()
    COMPLETED = auto()
    FAILED = auto()


class TaskPriority(Enum):
    """Priority of a task."""

    LOW = auto()
    MEDIUM = auto()
    HIGH = auto()
    CRITICAL = auto()


@dataclass
class Task:
    """A single task to be executed."""

    id: str
    description: str
    priority: TaskPriority = TaskPriority.MEDIUM
    state: TaskState = TaskState.PENDING
    dependencies: list[str] = field(default_factory=list)
    result: Any = None
    error: str | None = None


@dataclass
class TaskEvent:
    """An event related to a task."""

    task_id: str
    event_type: str
    timestamp: float = field(default_factory=time.time)
    data: dict[str, Any] = field(default_factory=dict)


class TaskBus:
    """A simple event bus for tasks."""

    def __init__(self):
        self.subscribers: list[Any] = []

    def subscribe(self, subscriber: Any) -> None:
        """Subscribe to task events."""
        self.subscribers.append(subscriber)

    def publish(self, event: TaskEvent) -> None:
        """Publish a task event."""
        for subscriber in self.subscribers:
            if hasattr(subscriber, "on_task_event"):
                subscriber.on_task_event(event)


class TaskExecution:
    """Execution state of a task."""

    task_id: str
    description: str
    status: TaskState = TaskState.PENDING
    result: Any = None
    error: str | None = None


class ComprehensiveTaskExecutor:
    """
    P0 Items 4251-4300: Orchestrates complex task execution.
    """

    def __init__(self, sage_root: str):
        self.sage_root = Path(sage_root)
        self.reasoning_engine = AdvancedReasoningEngine()
        self.tasks: dict[str, TaskExecution] = {}

    def execute_task(self, task_description: str) -> TaskExecution:
        """Execute a task with full orchestration."""
        task_id = f"task_{len(self.tasks) + 1}"
        task = TaskExecution(task_id=task_id, description=task_description)
        self.tasks[task_id] = task

        task.status = TaskState.RUNNING

        try:
            # Analyze task
            analysis = self.reasoning_engine.analyze_problem(task_description)

            # Perform execution (simulated for now)
            task.result = {
                "task_id": task_id,
                "analysis": analysis,
                "outcome": "success",
            }
            task.status = TaskState.COMPLETED

        except Exception as e:
            task.status = TaskState.FAILED
            task.error = str(e)

        return task

    def get_task_status(self, task_id: str) -> TaskState | None:
        """Get the status of a task."""
        task = self.tasks.get(task_id)
        return task.status if task else None


class TaskManager:
    """Manages multi-task execution with per-task TDD enforcement.

    This class tracks the execution of multiple tasks (e.g., implementing 100 items)
    and ensures:
    1. Each task is tracked individually
    2. TDD is enforced for each task
    3. Progress persists across conversation turns
    4. Tasks can be resumed from where they left off

    Fixes the issue where SAGE would generate a list of 100 items but only implement
    a few before stopping or failing tests.
    """

    def __init__(
        self,
        cwd: Path,
        tdd_gate: TDDGate,
        context_manager: ContextPersistenceManager | None = None,
    ):
        self.cwd = cwd
        self.tdd_gate = tdd_gate
        self.context_manager = context_manager or ContextPersistenceManager(cwd)
        self.context = self.context_manager.get_current_context()
        if self.context is None:
            self.context = self.context_manager.create_context()

        # Task list parsed from model output
        self.parsed_tasks: list[dict[str, Any]] = []
        self.current_task_index: int = 0

        # CRITICAL: Restore parsed_tasks from persisted context
        # The tasks are stored in accumulated_items with a special _task_list marker
        if self.context.accumulated_items:
            task_list_item = next(
                (
                    item
                    for item in self.context.accumulated_items
                    if item.get("_type") == "task_list"
                ),
                None,
            )
            if task_list_item and task_list_item.get("tasks"):
                self.parsed_tasks = task_list_item["tasks"]
                self.current_task_index = task_list_item.get("current_index", 0)

    def parse_task_list(self, model_output: str) -> list[dict[str, Any]]:
        """Parse numbered tasks from model output.

        Extracts items like:
        1. **Item title**: Description
        2. Item title — Description
        3. Item: Description

        Returns list of dicts with 'number', 'title', 'description', 'status'
        """
        tasks = []
        seen_numbers = set()

        # Match various numbered list formats
        patterns = [
            # Format: 1. **Title**: Description or 1. **Title** — Description
            r"^\s*(\d+)[.)\]]\s*\*\*([^*]+)\*\*\s*[:\-—]\s*(.+)$",
            # Format: 1. **Title** (bold title, no description)
            r"^\s*(\d+)[.)\]]\s*\*\*([^*]+)\*\*\s*$",
            # Format: 1. Title: Description (with colon)
            r"^\s*(\d+)[.)\]]\s*([^:\n]+):\s*(.+)$",
            # Format: 1. Title - Description (with dash)
            r"^\s*(\d+)[.)\]]\s*([^\-\n]+)\s*[\-—]\s*(.+)$",
            # Format: 1. Title (simple, no description)
            r"^\s*(\d+)[.)\]]\s*(.+)$",
        ]

        for line in model_output.split("\n"):
            line = line.strip()
            if not line:
                continue

            # Skip section headers (lines with just ## or similar)
            if line.startswith("#"):
                continue

            for pattern_index, pattern in enumerate(patterns):
                match = re.match(pattern, line)
                if match:
                    groups = match.groups()
                    number = int(groups[0])

                    # Skip if we've already seen this number (avoid duplicates)
                    if number in seen_numbers:
                        break

                    title = groups[1].strip()
                    description = groups[2].strip() if len(groups) > 2 else ""

                    # Don't split on the colon inside a backticked path like `app.py:9`.
                    if pattern_index == 2 and title.count("`") % 2 == 1:
                        continue

                    # Clean up title (remove trailing punctuation)
                    title = title.rstrip(":").rstrip("-").rstrip("—").strip()

                    # Skip items with very short titles (likely parsing errors)
                    if len(title) < 3:
                        continue

                    tasks.append(
                        {
                            "number": number,
                            "title": title,
                            "description": description,
                            "status": "pending",
                            "test_passed": False,
                            "files_written": [],
                        }
                    )
                    seen_numbers.add(number)
                    break

        self.parsed_tasks = tasks

        # Initialize TaskProgress if we have tasks
        if tasks:
            self.context.task_progress = TaskProgress(total_items=len(tasks))

            # CRITICAL: Persist task list to context for recovery across sessions
            # Remove any existing task_list entries first
            self.context.accumulated_items = [
                item for item in self.context.accumulated_items if item.get("_type") != "task_list"
            ]
            # Add new task list
            self.context.accumulated_items.append(
                {
                    "_type": "task_list",
                    "tasks": tasks,
                    "current_index": 0,
                    "_added_at": time.time(),
                }
            )
            self.context_manager.save_context(self.context)

        return tasks

    def get_next_task(self) -> dict[str, Any] | None:
        """Get the next pending task to execute."""
        for i, task in enumerate(self.parsed_tasks):
            if task["status"] == "pending":
                self.current_task_index = i
                task["status"] = "in_progress"
                if self.context.task_progress:
                    self.context.task_progress.current_item = task["number"]
                    self.context_manager.save_context(self.context)
                return task
        return None

    def mark_task_complete(self, task_number: int, files_written: list[str] | None = None) -> None:
        """Mark a task as completed."""
        for task in self.parsed_tasks:
            if task["number"] == task_number:
                task["status"] = "completed"
                task["test_passed"] = True
                if files_written:
                    task["files_written"] = files_written
                break

        if self.context.task_progress:
            self.context.task_progress.mark_completed(task_number)

        # Persist updated task state
        self._persist_task_state()

    def mark_task_failed(self, task_number: int, reason: str = "") -> None:
        """Mark a task as failed."""
        for task in self.parsed_tasks:
            if task["number"] == task_number:
                task["status"] = "failed"
                task["failure_reason"] = reason
                break

        if self.context.task_progress:
            self.context.task_progress.mark_failed(task_number, reason)

        # Persist updated task state
        self._persist_task_state()

    def _persist_task_state(self) -> None:
        """Persist current task state to context."""
        # Update the task_list item in accumulated_items
        for item in self.context.accumulated_items:
            if item.get("_type") == "task_list":
                item["tasks"] = self.parsed_tasks
                item["current_index"] = self.current_task_index
                break
        self.context_manager.save_context(self.context)

    def get_progress_summary(self) -> str:
        """Get a summary of task progress."""
        if not self.parsed_tasks:
            return "No tasks parsed yet."

        total = len(self.parsed_tasks)
        completed = sum(1 for t in self.parsed_tasks if t["status"] == "completed")
        failed = sum(1 for t in self.parsed_tasks if t["status"] == "failed")
        pending = sum(1 for t in self.parsed_tasks if t["status"] == "pending")
        in_progress = sum(1 for t in self.parsed_tasks if t["status"] == "in_progress")

        return (
            f"📊 Task Progress: {completed}/{total} completed "
            f"({completed / total * 100:.1f}%)\n"
            f"   ✅ Completed: {completed} | ❌ Failed: {failed} | "
            f"⏳ Pending: {pending} | 🔄 In Progress: {in_progress}"
        )

    def get_remaining_tasks(self) -> list[dict[str, Any]]:
        """Get all tasks that are not yet completed."""
        return [t for t in self.parsed_tasks if t["status"] not in {"completed", "failed"}]

    def get_resumable_tasks(self) -> list[dict[str, Any]]:
        """Get tasks that still need work, including previously failed items."""
        return [t for t in self.parsed_tasks if t["status"] != "completed"]

    def get_continuation_prompt(self) -> str:
        """Generate a prompt to continue implementing remaining tasks."""
        remaining = self.get_remaining_tasks()
        if not remaining:
            return ""

        completed = [t for t in self.parsed_tasks if t["status"] == "completed"]

        prompt = (
            f"## CONTINUATION REQUIRED\n\n"
            f"You have completed {len(completed)}/{len(self.parsed_tasks)} tasks.\n"
            f"Continue implementing the remaining {len(remaining)} tasks:\n\n"
        )

        for task in remaining[:10]:  # Show up to 10 remaining tasks
            prompt += f"{task['number']}. {task['title']}"
            if task.get("description"):
                prompt += f": {task['description']}"
            prompt += "\n"

        if len(remaining) > 10:
            prompt += f"... and {len(remaining) - 10} more tasks\n"

        prompt += (
            "\n## IMPLEMENTATION RULES\n"
            "1. Implement ONE task at a time\n"
            "2. Write tests FIRST (FILE: tests/test_*.py)\n"
            "3. Run tests to see them fail (RUN: pytest tests/test_*.py -v)\n"
            "4. Write implementation (FILE: src/*.py)\n"
        )
        return prompt


# Alias for backward compatibility during migration
TaskExecutionManager = TaskManager
