"""Tests for report generation."""

import json
import pytest

from migra.diff import SchemaDiff
from migra.migration import MigrationManager
from migra.report import DiffReport, ReportGenerator
from migra.schema import Column, Schema, Table


class TestDiffReport:
    def test_creation(self):
        report = DiffReport(source_name="a", target_name="b")
        assert report.source_name == "a"
        assert report.timestamp

    def test_to_dict(self):
        report = DiffReport(
            source_name="a", target_name="b",
            total_changes=5, max_risk="HIGH",
        )
        d = report.to_dict()
        assert d["source"] == "a"
        assert d["total_changes"] == 5

    def test_to_json(self):
        report = DiffReport(source_name="a", target_name="b")
        j = report.to_json()
        data = json.loads(j)
        assert data["source"] == "a"

    def test_to_markdown(self):
        report = DiffReport(
            source_name="v1", target_name="v2",
            total_changes=3, max_risk="MEDIUM",
            summary={"ADD_COLUMN": 2, "DROP_COLUMN": 1},
            risk_breakdown={"SAFE": 2, "DESTRUCTIVE": 1},
            affected_tables=["users", "orders"],
            changes=[
                {"risk_level": "SAFE", "description": "Add column x"},
                {"risk_level": "DESTRUCTIVE", "description": "Drop column y"},
            ],
            warnings=["Be careful"],
        )
        md = report.to_markdown()
        assert "# Schema Diff Report" in md
        assert "ADD_COLUMN" in md
        assert "users" in md
        assert "Be careful" in md
        assert "DESTRUCTIVE" in md

    def test_to_markdown_empty(self):
        report = DiffReport(source_name="a", target_name="b")
        md = report.to_markdown()
        assert "# Schema Diff Report" in md

    def test_to_markdown_no_warnings(self):
        report = DiffReport(source_name="a", target_name="b", total_changes=0)
        md = report.to_markdown()
        assert "Warnings" not in md


class TestReportGenerator:
    def test_generate_diff_report(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="id", type="INTEGER")]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[
                Column(name="id", type="INTEGER"),
                Column(name="name", type="TEXT"),
            ]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        gen = ReportGenerator()
        report = gen.generate_diff_report(diff, "schema_v1", "schema_v2")
        assert report.total_changes == 1
        assert report.source_name == "schema_v1"
        assert "t" in report.affected_tables

    def test_generate_diff_report_no_changes(self):
        s = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INTEGER")])])
        diff = SchemaDiff(source=s, target=s)
        diff.compute()

        gen = ReportGenerator()
        report = gen.generate_diff_report(diff)
        assert report.total_changes == 0
        assert report.max_risk == "SAFE"

    def test_generate_diff_report_uncomputed(self):
        a = Schema()
        b = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INTEGER")])])
        diff = SchemaDiff(source=a, target=b)
        # Don't compute

        gen = ReportGenerator()
        report = gen.generate_diff_report(diff)
        assert report.total_changes > 0

    def test_generate_migration_report(self, tmp_path):
        mgr = MigrationManager(tmp_path / "migrations")
        mgr.init()
        mgr.create_migration(name="test", up_sql="SELECT 1;")
        mgr.load_migrations()

        gen = ReportGenerator()
        report = gen.generate_migration_report(mgr)
        assert report["health"] == "healthy"
        assert report["status"]["total"] == 1

    def test_generate_migration_report_degraded(self, tmp_path):
        mgr = MigrationManager(tmp_path / "migrations")
        mgr.init()
        m = mgr.create_migration(name="test", up_sql="SELECT 1;")
        mgr.apply_migration(m)
        m.up_sql = "TAMPERED"  # corrupt checksum

        gen = ReportGenerator()
        report = gen.generate_migration_report(mgr)
        assert report["health"] == "degraded"

    def test_risk_breakdown(self):
        a = Schema(tables=[
            Table(name="t", columns=[
                Column(name="x", type="TEXT"),
                Column(name="y", type="INTEGER"),
            ]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[
                Column(name="x", type="TEXT"),
                Column(name="y", type="INTEGER"),
                Column(name="z", type="TEXT"),
            ]),
            Table(name="t2", columns=[Column(name="id", type="INTEGER")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        gen = ReportGenerator()
        report = gen.generate_diff_report(diff)
        assert "SAFE" in report.risk_breakdown
