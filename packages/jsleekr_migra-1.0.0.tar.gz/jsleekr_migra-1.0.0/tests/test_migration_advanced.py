"""Advanced migration tests."""

import pytest
from pathlib import Path

from migra.migration import Migration, MigrationManager, MigrationStatus


class TestMigrationAdvanced:
    def test_sql_file_roundtrip_with_multiline(self):
        m = Migration(
            id="001_complex",
            version="001",
            name="complex",
            up_sql="""CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    name TEXT
);

CREATE INDEX idx_email ON users (email);""",
            down_sql="DROP INDEX idx_email;\nDROP TABLE users;",
            description="Complex migration with multiline SQL",
        )
        content = m.to_sql_file()
        m2 = Migration.from_sql_file(content)
        assert m2.id == m.id
        assert "CREATE TABLE" in m2.up_sql
        assert "CREATE INDEX" in m2.up_sql
        assert "DROP INDEX" in m2.down_sql

    def test_checksum_consistent(self):
        m = Migration(id="001", version="1", name="test",
                      up_sql="SELECT 1;", down_sql="SELECT 2;")
        cs1 = m._compute_checksum()
        cs2 = m._compute_checksum()
        assert cs1 == cs2

    def test_checksum_changes_with_sql(self):
        m1 = Migration(id="001", version="1", name="test", up_sql="SELECT 1;")
        m2 = Migration(id="001", version="1", name="test", up_sql="SELECT 2;")
        assert m1.checksum != m2.checksum

    def test_from_sql_file_no_metadata(self):
        content = """-- +migrate Up
CREATE TABLE t(id INT);

-- +migrate Down
DROP TABLE t;
"""
        m = Migration.from_sql_file(content, "my_migration.sql")
        assert m.id == "my_migration"
        assert "CREATE TABLE" in m.up_sql

    def test_from_dict_all_fields(self):
        data = {
            "id": "001",
            "version": "1",
            "name": "test",
            "description": "desc",
            "up_sql": "UP;",
            "down_sql": "DOWN;",
            "status": "APPLIED",
            "checksum": "abc123",
            "created_at": "2024-01-01",
            "applied_at": "2024-01-02",
            "execution_time_ms": 42,
            "depends_on": ["000"],
            "tags": ["schema"],
        }
        m = Migration.from_dict(data)
        assert m.status == MigrationStatus.APPLIED
        assert m.applied_at == "2024-01-02"
        assert m.execution_time_ms == 42
        assert m.depends_on == ["000"]
        assert m.tags == ["schema"]


class TestMigrationManagerAdvanced:
    @pytest.fixture
    def mgr(self, tmp_path):
        m = MigrationManager(tmp_path / "migrations")
        m.init()
        return m

    def test_apply_with_dependencies_chain(self, mgr):
        m1 = mgr.create_migration(name="first", up_sql="S1;", down_sql="D1;")
        m2 = mgr.create_migration(name="second", up_sql="S2;", down_sql="D2;",
                                   depends_on=[m1.id])
        m3 = mgr.create_migration(name="third", up_sql="S3;", down_sql="D3;",
                                   depends_on=[m2.id])

        # Apply all in order
        results = mgr.apply_all()
        assert all(r["status"] == "applied" for r in results)
        assert len(results) == 3

    def test_rollback_preserves_order(self, mgr):
        m1 = mgr.create_migration(name="m1", up_sql="S1;", down_sql="D1;")
        m2 = mgr.create_migration(name="m2", up_sql="S2;", down_sql="D2;")
        m3 = mgr.create_migration(name="m3", up_sql="S3;", down_sql="D3;")
        mgr.apply_all()

        results = mgr.rollback_last(count=2)
        assert len(results) == 2
        # Most recent should be rolled back first
        assert results[0]["migration_id"] == m3.id
        assert results[1]["migration_id"] == m2.id

    def test_status_report_complete(self, mgr):
        m1 = mgr.create_migration(name="m1")
        m2 = mgr.create_migration(name="m2")
        m3 = mgr.create_migration(name="m3", down_sql="D3;")
        mgr.apply_migration(m1)
        mgr.apply_migration(m2)
        mgr.apply_migration(m3)
        mgr.rollback_migration(m3)

        report = mgr.status_report()
        assert report["total"] == 3
        assert report["applied"] == 2
        assert report["rolled_back"] == 1
        assert report["pending"] == 0

    def test_migration_names_sanitized(self, mgr):
        m = mgr.create_migration(name="Add User Profiles (v2)")
        assert " " not in m.id
        assert "(" not in m.id
        assert ")" not in m.id

    def test_concurrent_creates(self, mgr):
        # Create multiple quickly
        migrations = []
        for i in range(5):
            m = mgr.create_migration(name=f"migration_{i}", up_sql=f"SELECT {i};")
            migrations.append(m)

        mgr2 = MigrationManager(mgr.migrations_dir)
        loaded = mgr2.load_migrations()
        assert len(loaded) == 5

    def test_history_survives_reload(self, mgr):
        m1 = mgr.create_migration(name="m1", up_sql="S1;")
        m2 = mgr.create_migration(name="m2", up_sql="S2;")
        mgr.apply_migration(m1)
        mgr.apply_migration(m2)

        # Fresh manager
        mgr2 = MigrationManager(mgr.migrations_dir)
        mgr2.load_migrations()

        applied = mgr2.get_applied()
        assert len(applied) == 2
        pending = mgr2.get_pending()
        assert len(pending) == 0

    def test_dry_run_idempotent(self, mgr):
        m = mgr.create_migration(name="test", up_sql="S;")
        r1 = mgr.apply_migration(m, dry_run=True)
        r2 = mgr.apply_migration(m, dry_run=True)
        assert r1["status"] == "dry_run"
        assert r2["status"] == "dry_run"
        assert m.status == MigrationStatus.PENDING

    def test_apply_already_applied_idempotent(self, mgr):
        m = mgr.create_migration(name="test", up_sql="S;")
        mgr.apply_migration(m)
        r = mgr.apply_migration(m)
        assert r["status"] == "already_applied"

    def test_rollback_not_applied_safe(self, mgr):
        m = mgr.create_migration(name="test", down_sql="D;")
        r = mgr.rollback_migration(m)
        assert r["status"] == "not_applied"

    def test_validate_checksums_all_clean(self, mgr):
        for i in range(3):
            m = mgr.create_migration(name=f"m{i}", up_sql=f"SELECT {i};")
            mgr.apply_migration(m)
        issues = mgr.validate_checksums()
        assert len(issues) == 0
