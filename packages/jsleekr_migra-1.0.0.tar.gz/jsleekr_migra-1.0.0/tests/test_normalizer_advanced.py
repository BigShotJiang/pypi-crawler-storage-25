"""Advanced normalizer tests."""

import pytest
from migra.normalizer import SchemaNormalizer
from migra.schema import Column, Constraint, Index, Schema, Table


class TestNormalizerWithDiff:
    """Test normalizer integration with diff engine."""

    def test_int_vs_integer_normalized(self):
        normalizer = SchemaNormalizer()
        a = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INT")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INTEGER")])])

        a_norm = normalizer.normalize(a)
        b_norm = normalizer.normalize(b)

        from migra.diff import SchemaDiff
        diff = SchemaDiff(source=a_norm, target=b_norm)
        changes = diff.compute()
        assert len(changes) == 0

    def test_bool_vs_boolean_normalized(self):
        normalizer = SchemaNormalizer()
        a = Schema(tables=[Table(name="t", columns=[Column(name="active", type="BOOL")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="active", type="BOOLEAN")])])

        a_norm = normalizer.normalize(a)
        b_norm = normalizer.normalize(b)

        from migra.diff import SchemaDiff
        diff = SchemaDiff(source=a_norm, target=b_norm)
        changes = diff.compute()
        assert len(changes) == 0

    def test_datetime_vs_timestamp_normalized(self):
        normalizer = SchemaNormalizer()
        a = Schema(tables=[Table(name="t", columns=[Column(name="ts", type="DATETIME")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="ts", type="TIMESTAMP")])])

        a_norm = normalizer.normalize(a)
        b_norm = normalizer.normalize(b)

        from migra.diff import SchemaDiff
        diff = SchemaDiff(source=a_norm, target=b_norm)
        changes = diff.compute()
        assert len(changes) == 0

    def test_serial_normalized_to_integer_autoinc(self):
        normalizer = SchemaNormalizer()
        a = Schema(tables=[Table(name="t", columns=[Column(name="id", type="SERIAL")])])
        b = Schema(tables=[Table(name="t", columns=[
            Column(name="id", type="INTEGER", auto_increment=True),
        ])])

        a_norm = normalizer.normalize(a)
        b_norm = normalizer.normalize(b)

        from migra.diff import SchemaDiff
        diff = SchemaDiff(source=a_norm, target=b_norm)
        changes = diff.compute()
        assert len(changes) == 0

    def test_normalize_multiple_columns(self):
        normalizer = SchemaNormalizer()
        schema = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INT"),
                Column(name="active", type="BOOL"),
                Column(name="name", type="NVARCHAR", max_length=100),
                Column(name="amount", type="MONEY"),
                Column(name="data", type="LONGTEXT"),
                Column(name="ts", type="DATETIME"),
            ]),
        ])

        norm = normalizer.normalize(schema)
        cols = {c.name: c.type for c in norm.tables[0].columns}
        assert cols["id"] == "INTEGER"
        assert cols["active"] == "BOOLEAN"
        assert cols["name"] == "VARCHAR"
        assert cols["amount"] == "DECIMAL"
        assert cols["data"] == "TEXT"
        assert cols["ts"] == "TIMESTAMP"

    def test_normalize_preserves_non_type_fields(self):
        normalizer = SchemaNormalizer()
        schema = Schema(tables=[
            Table(name="t", columns=[
                Column(name="id", type="INT", primary_key=True, nullable=False,
                       unique=True, default="0", max_length=None, precision=None,
                       scale=None, comment="Primary key"),
            ]),
        ])

        norm = normalizer.normalize(schema)
        col = norm.tables[0].columns[0]
        assert col.primary_key is True
        assert col.nullable is False
        assert col.unique is True
        assert col.default == "0"
        assert col.comment == "Primary key"

    def test_normalize_preserves_indexes(self):
        normalizer = SchemaNormalizer()
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")],
                  indexes=[Index(name="idx_x", columns=["x"], unique=True)]),
        ])

        norm = normalizer.normalize(schema)
        assert len(norm.tables[0].indexes) == 1
        assert norm.tables[0].indexes[0].unique is True

    def test_normalize_preserves_constraints(self):
        normalizer = SchemaNormalizer()
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")],
                  constraints=[Constraint(name="uq_x", type="UNIQUE", columns=["x"])]),
        ])

        norm = normalizer.normalize(schema)
        assert len(norm.tables[0].constraints) == 1
