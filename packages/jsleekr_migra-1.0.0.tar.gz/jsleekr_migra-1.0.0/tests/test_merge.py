"""Tests for schema merge."""

import pytest

from migra.merge import ConflictType, MergeConflict, MergeResult, SchemaMerger
from migra.schema import Column, Constraint, Index, Schema, Table


class TestSchemaMerger:
    def test_merge_disjoint(self):
        a = Schema(tables=[Table(name="users", columns=[Column(name="id", type="INTEGER")])])
        b = Schema(tables=[Table(name="orders", columns=[Column(name="id", type="INTEGER")])])
        merger = SchemaMerger()
        result = merger.merge(a, b)
        assert len(result.schema.tables) == 2
        assert not result.has_conflicts

    def test_merge_same_schema(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INTEGER")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INTEGER")])])
        merger = SchemaMerger()
        result = merger.merge(a, b)
        assert len(result.schema.tables) == 1
        assert not result.has_conflicts

    def test_merge_new_columns(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INTEGER")])])
        b = Schema(tables=[Table(name="t", columns=[
            Column(name="id", type="INTEGER"),
            Column(name="name", type="TEXT"),
        ])])
        merger = SchemaMerger()
        result = merger.merge(a, b)
        table = result.schema.get_table("t")
        assert len(table.columns) == 2
        assert not result.has_conflicts

    def test_merge_column_type_conflict(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="INTEGER")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")])])
        merger = SchemaMerger(prefer="b")
        result = merger.merge(a, b)
        assert result.has_conflicts
        assert any(c.conflict_type == ConflictType.COLUMN_TYPE for c in result.conflicts)
        # prefer="b" so TEXT wins
        col = result.schema.get_table("t").get_column("x")
        assert col.type == "TEXT"

    def test_merge_column_type_conflict_prefer_a(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="INTEGER")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")])])
        merger = SchemaMerger(prefer="a")
        result = merger.merge(a, b)
        col = result.schema.get_table("t").get_column("x")
        assert col.type == "INTEGER"

    def test_merge_nullable_conflict(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT", nullable=True)])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT", nullable=False)])])
        merger = SchemaMerger()
        result = merger.merge(a, b)
        assert any(c.conflict_type == ConflictType.COLUMN_NULLABLE for c in result.conflicts)

    def test_merge_default_conflict(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT", default="'a'")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT", default="'b'")])])
        merger = SchemaMerger()
        result = merger.merge(a, b)
        assert any(c.conflict_type == ConflictType.COLUMN_DEFAULT for c in result.conflicts)

    def test_merge_index_conflict(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")],
                                 indexes=[Index(name="idx", columns=["x"])])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")],
                                 indexes=[Index(name="idx", columns=["x"], unique=True)])])
        merger = SchemaMerger()
        result = merger.merge(a, b)
        assert any(c.conflict_type == ConflictType.INDEX_DEFINITION for c in result.conflicts)

    def test_merge_new_index(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")],
                                 indexes=[Index(name="idx_x", columns=["x"])])])
        merger = SchemaMerger()
        result = merger.merge(a, b)
        assert len(result.schema.get_table("t").indexes) == 1
        assert not result.has_conflicts

    def test_merge_constraint_conflict(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")],
                                 constraints=[Constraint(name="ck", type="CHECK", columns=[], expression="x > 0")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")],
                                 constraints=[Constraint(name="ck", type="CHECK", columns=[], expression="x > 10")])])
        merger = SchemaMerger()
        result = merger.merge(a, b)
        assert any(c.conflict_type == ConflictType.CONSTRAINT_DEFINITION for c in result.conflicts)

    def test_merge_comment_conflict(self):
        a = Schema(tables=[Table(name="t", comment="old")])
        b = Schema(tables=[Table(name="t", comment="new")])
        merger = SchemaMerger(prefer="b")
        result = merger.merge(a, b)
        assert any(c.conflict_type == ConflictType.TABLE_COMMENT for c in result.conflicts)
        assert result.schema.get_table("t").comment == "new"

    def test_tables_added(self):
        a = Schema(tables=[Table(name="t1")])
        b = Schema(tables=[Table(name="t1"), Table(name="t2")])
        merger = SchemaMerger()
        result = merger.merge(a, b)
        assert "t2" in result.tables_added

    def test_tables_merged(self):
        a = Schema(tables=[Table(name="t1", columns=[Column(name="id", type="INTEGER")])])
        b = Schema(tables=[Table(name="t1", columns=[Column(name="id", type="INTEGER")])])
        merger = SchemaMerger()
        result = merger.merge(a, b)
        assert "t1" in result.tables_merged

    def test_empty_merge(self):
        merger = SchemaMerger()
        result = merger.merge(Schema(), Schema())
        assert len(result.schema.tables) == 0
        assert not result.has_conflicts

    def test_merge_preserves_name(self):
        a = Schema(name="db_a")
        b = Schema(name="db_b")
        merger = SchemaMerger()
        result = merger.merge(a, b)
        assert result.schema.name == "db_a"

    def test_merge_preserves_version(self):
        a = Schema(version="1.0")
        b = Schema(version="2.0")
        merger = SchemaMerger()
        result = merger.merge(a, b)
        assert result.schema.version == "2.0"


class TestMergeConflict:
    def test_to_dict(self):
        conflict = MergeConflict(
            table_name="users",
            object_name="email",
            conflict_type=ConflictType.COLUMN_TYPE,
            source_a="VARCHAR",
            source_b="TEXT",
            resolution="b",
        )
        d = conflict.to_dict()
        assert d["table_name"] == "users"
        assert d["conflict_type"] == "COLUMN_TYPE"
        assert d["resolution"] == "b"


class TestMergeResult:
    def test_has_conflicts(self):
        result = MergeResult(
            schema=Schema(),
            conflicts=[MergeConflict("t", "x", "TYPE", "a", "b")],
        )
        assert result.has_conflicts

    def test_no_conflicts(self):
        result = MergeResult(schema=Schema())
        assert not result.has_conflicts

    def test_unresolved_conflicts(self):
        result = MergeResult(
            schema=Schema(),
            conflicts=[
                MergeConflict("t", "x", "TYPE", "a", "b", resolution="a"),
                MergeConflict("t", "y", "TYPE", "c", "d", resolution=None),
            ],
        )
        assert len(result.unresolved_conflicts) == 1

    def test_to_dict(self):
        result = MergeResult(
            schema=Schema(),
            tables_added=["t2"],
            tables_merged=["t1"],
        )
        d = result.to_dict()
        assert d["tables_added"] == ["t2"]
        assert d["has_conflicts"] is False
