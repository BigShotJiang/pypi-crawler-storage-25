"""Tests for schema and migration validation."""

import pytest

from migra.schema import Column, Constraint, Index, Schema, Table
from migra.validator import (
    MigrationValidator,
    SchemaValidator,
    ValidationIssue,
    ValidationSeverity,
)


class TestSchemaValidator:
    def test_no_issues(self):
        schema = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER", primary_key=True),
                Column(name="email", type="VARCHAR", max_length=255, nullable=False),
            ]),
        ])
        validator = SchemaValidator()
        issues = validator.validate(schema)
        errors = [i for i in issues if i.severity == ValidationSeverity.ERROR]
        assert len(errors) == 0

    def test_no_primary_key(self):
        schema = Schema(tables=[
            Table(name="logs", columns=[
                Column(name="message", type="TEXT"),
            ]),
        ])
        validator = SchemaValidator()
        issues = validator.validate(schema)
        pk_issues = [i for i in issues if i.code == "NO_PRIMARY_KEY"]
        assert len(pk_issues) == 1

    def test_with_pk_constraint(self):
        schema = Schema(tables=[
            Table(
                name="t", columns=[Column(name="id", type="INTEGER")],
                constraints=[Constraint(name="pk_t", type="PRIMARY KEY", columns=["id"])],
            ),
        ])
        validator = SchemaValidator()
        issues = validator.validate(schema)
        pk_issues = [i for i in issues if i.code == "NO_PRIMARY_KEY"]
        assert len(pk_issues) == 0

    def test_temp_table_prefix(self):
        schema = Schema(tables=[
            Table(name="tmp_data", columns=[Column(name="id", type="INTEGER", primary_key=True)]),
        ])
        validator = SchemaValidator()
        issues = validator.validate(schema)
        prefix_issues = [i for i in issues if i.code == "TABLE_PREFIX"]
        assert len(prefix_issues) == 1

    def test_fk_missing_table(self):
        schema = Schema(tables=[
            Table(name="orders", columns=[
                Column(name="user_id", type="INTEGER", references="nonexistent.id"),
            ]),
        ])
        validator = SchemaValidator()
        issues = validator.validate(schema)
        fk_issues = [i for i in issues if i.code == "FK_MISSING_TABLE"]
        assert len(fk_issues) >= 1

    def test_fk_valid_reference(self):
        schema = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER", primary_key=True),
            ]),
            Table(name="orders", columns=[
                Column(name="user_id", type="INTEGER", references="users.id"),
            ]),
        ])
        validator = SchemaValidator()
        issues = validator.validate(schema)
        fk_errors = [i for i in issues if i.code == "FK_MISSING_TABLE"]
        assert len(fk_errors) == 0

    def test_fk_constraint_missing_table(self):
        schema = Schema(tables=[
            Table(
                name="orders",
                columns=[Column(name="user_id", type="INTEGER")],
                constraints=[Constraint(
                    name="fk_user", type="FOREIGN KEY", columns=["user_id"],
                    references_table="nonexistent", references_columns=["id"],
                )],
            ),
        ])
        validator = SchemaValidator()
        issues = validator.validate(schema)
        fk_issues = [i for i in issues if i.code == "FK_MISSING_TABLE"]
        assert len(fk_issues) >= 1

    def test_deprecated_type(self):
        schema = Schema(tables=[
            Table(name="t", columns=[
                Column(name="id", type="INTEGER", primary_key=True),
                Column(name="amount", type="MONEY"),
            ]),
        ])
        validator = SchemaValidator()
        issues = validator.validate(schema)
        type_issues = [i for i in issues if i.code == "DEPRECATED_TYPE"]
        assert len(type_issues) == 1

    def test_varchar_no_length(self):
        schema = Schema(tables=[
            Table(name="t", columns=[
                Column(name="id", type="INTEGER", primary_key=True),
                Column(name="name", type="VARCHAR"),
            ]),
        ])
        validator = SchemaValidator()
        issues = validator.validate(schema)
        varchar_issues = [i for i in issues if i.code == "VARCHAR_NO_LENGTH"]
        assert len(varchar_issues) == 1

    def test_fk_no_index(self):
        schema = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER", primary_key=True),
            ]),
            Table(name="orders", columns=[
                Column(name="id", type="INTEGER", primary_key=True),
                Column(name="user_id", type="INTEGER", references="users.id"),
            ]),
        ])
        validator = SchemaValidator()
        issues = validator.validate(schema)
        idx_issues = [i for i in issues if i.code == "FK_NO_INDEX"]
        assert len(idx_issues) >= 1

    def test_fk_with_index(self):
        schema = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER", primary_key=True),
            ]),
            Table(
                name="orders",
                columns=[
                    Column(name="id", type="INTEGER", primary_key=True),
                    Column(name="user_id", type="INTEGER", references="users.id"),
                ],
                indexes=[
                    Index(name="idx_user_id", columns=["user_id"]),
                ],
            ),
        ])
        validator = SchemaValidator()
        issues = validator.validate(schema)
        idx_issues = [i for i in issues if i.code == "FK_NO_INDEX" and i.table == "orders"]
        assert len(idx_issues) == 0

    def test_duplicate_index(self):
        schema = Schema(tables=[
            Table(
                name="t",
                columns=[Column(name="id", type="INTEGER", primary_key=True)],
                indexes=[
                    Index(name="idx_1", columns=["id"]),
                    Index(name="idx_2", columns=["id"]),
                ],
            ),
        ])
        validator = SchemaValidator()
        issues = validator.validate(schema)
        dup_issues = [i for i in issues if i.code == "DUPLICATE_INDEX"]
        assert len(dup_issues) == 1

    def test_mostly_nullable(self):
        schema = Schema(tables=[
            Table(name="t", columns=[
                Column(name="a", type="TEXT", nullable=True),
                Column(name="b", type="TEXT", nullable=True),
                Column(name="c", type="TEXT", nullable=True),
                Column(name="d", type="TEXT", nullable=True),
                Column(name="e", type="TEXT", nullable=True),
            ]),
        ])
        validator = SchemaValidator()
        issues = validator.validate(schema)
        nullable_issues = [i for i in issues if i.code == "MOSTLY_NULLABLE"]
        assert len(nullable_issues) == 1

    def test_reserved_word_table(self):
        schema = Schema(tables=[
            Table(name="select", columns=[
                Column(name="id", type="INTEGER", primary_key=True),
            ]),
        ])
        validator = SchemaValidator()
        issues = validator.validate(schema)
        reserved = [i for i in issues if i.code == "RESERVED_WORD"]
        assert any("select" in i.message for i in reserved)

    def test_reserved_word_column(self):
        schema = Schema(tables=[
            Table(name="t", columns=[
                Column(name="id", type="INTEGER", primary_key=True),
                Column(name="order", type="INTEGER"),
            ]),
        ])
        validator = SchemaValidator()
        issues = validator.validate(schema)
        reserved = [i for i in issues if i.code == "RESERVED_WORD"]
        assert any("order" in i.message for i in reserved)

    def test_too_many_columns(self):
        cols = [Column(name=f"col_{i}", type="TEXT") for i in range(51)]
        cols[0].primary_key = True
        schema = Schema(tables=[Table(name="wide", columns=cols)])
        validator = SchemaValidator()
        issues = validator.validate(schema)
        wide_issues = [i for i in issues if i.code == "TOO_MANY_COLUMNS"]
        assert len(wide_issues) == 1

    def test_validate_table(self):
        table = Table(name="t", columns=[Column(name="x", type="TEXT")])
        validator = SchemaValidator()
        issues = validator.validate_table(table)
        assert isinstance(issues, list)

    def test_empty_schema(self):
        validator = SchemaValidator()
        issues = validator.validate(Schema())
        assert len(issues) == 0


class TestMigrationValidator:
    def test_valid_sql(self):
        validator = MigrationValidator()
        issues = validator.validate_sql("ALTER TABLE t ADD COLUMN x TEXT;")
        errors = [i for i in issues if i.severity == ValidationSeverity.ERROR]
        assert len(errors) == 0

    def test_empty_sql(self):
        validator = MigrationValidator()
        issues = validator.validate_sql("")
        assert any(i.code == "EMPTY_MIGRATION" for i in issues)

    def test_drop_without_if_exists(self):
        validator = MigrationValidator()
        issues = validator.validate_sql("DROP TABLE users;")
        assert any(i.code == "DROP_WITHOUT_IF_EXISTS" for i in issues)

    def test_drop_with_if_exists(self):
        validator = MigrationValidator()
        issues = validator.validate_sql("DROP TABLE IF EXISTS users;")
        assert not any(i.code == "DROP_WITHOUT_IF_EXISTS" for i in issues)

    def test_truncate_warning(self):
        validator = MigrationValidator()
        issues = validator.validate_sql("TRUNCATE TABLE users;")
        assert any(i.code == "TRUNCATE_TABLE" for i in issues)

    def test_no_transaction(self):
        validator = MigrationValidator()
        issues = validator.validate_sql("ALTER TABLE t ADD COLUMN x TEXT;\nALTER TABLE t ADD COLUMN y INT;")
        assert any(i.code == "NO_TRANSACTION" for i in issues)

    def test_type_change(self):
        validator = MigrationValidator()
        issues = validator.validate_sql("ALTER TABLE t ALTER COLUMN x TYPE BIGINT;")
        assert any(i.code == "TYPE_CHANGE" for i in issues)

    def test_set_not_null(self):
        validator = MigrationValidator()
        issues = validator.validate_sql("ALTER TABLE t ALTER COLUMN x SET NOT NULL;")
        assert any(i.code == "SET_NOT_NULL" for i in issues)

    def test_no_false_no_transaction_for_semicolons_in_strings(self):
        validator = MigrationValidator()
        # Single statement with semicolons inside a string literal
        issues = validator.validate_sql("INSERT INTO t VALUES ('a;b;c');")
        assert not any(i.code == "NO_TRANSACTION" for i in issues)

    def test_no_transaction_with_real_multiple_statements(self):
        validator = MigrationValidator()
        issues = validator.validate_sql(
            "INSERT INTO t VALUES ('a;b'); INSERT INTO t VALUES ('c');"
        )
        assert any(i.code == "NO_TRANSACTION" for i in issues)


class TestValidationIssue:
    def test_to_dict(self):
        issue = ValidationIssue(
            severity=ValidationSeverity.ERROR,
            code="TEST",
            message="test issue",
            table="users",
            column="email",
        )
        d = issue.to_dict()
        assert d["severity"] == "ERROR"
        assert d["code"] == "TEST"
        assert d["table"] == "users"
        assert d["column"] == "email"

    def test_str(self):
        issue = ValidationIssue(
            severity=ValidationSeverity.WARNING,
            code="TEST",
            message="test",
            table="users",
        )
        s = str(issue)
        assert "WARNING" in s
        assert "TEST" in s
        assert "users" in s

    def test_str_with_column(self):
        issue = ValidationIssue(
            severity=ValidationSeverity.INFO,
            code="TEST",
            message="test",
            table="users",
            column="email",
        )
        s = str(issue)
        assert "users.email" in s

    def test_str_no_location(self):
        issue = ValidationIssue(
            severity=ValidationSeverity.ERROR,
            code="TEST",
            message="test",
        )
        s = str(issue)
        assert "[ERROR]" in s

    def test_to_dict_minimal(self):
        issue = ValidationIssue(
            severity=ValidationSeverity.INFO,
            code="TEST",
            message="test",
        )
        d = issue.to_dict()
        assert "table" not in d
        assert "column" not in d
        assert "context" not in d

    def test_to_dict_with_context(self):
        issue = ValidationIssue(
            severity=ValidationSeverity.INFO,
            code="TEST",
            message="test",
            context={"key": "value"},
        )
        d = issue.to_dict()
        assert d["context"]["key"] == "value"
