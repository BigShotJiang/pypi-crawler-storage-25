"""Integration tests - end-to-end workflows."""

import json
import pytest
from pathlib import Path

from migra.schema import Column, Constraint, Index, Schema, Table
from migra.diff import SchemaDiff, RiskLevel
from migra.planner import MigrationPlanner
from migra.migration import MigrationManager, MigrationStatus
from migra.parser import SQLParser
from migra.snapshot import SnapshotManager
from migra.validator import SchemaValidator
from migra.loader import SchemaLoader
from migra.merge import SchemaMerger
from migra.graph import MigrationGraph
from migra.report import ReportGenerator
from migra.linter import MigrationLinter
from migra.normalizer import SchemaNormalizer


class TestEndToEndWorkflow:
    """Test a complete migration workflow."""

    def test_full_migration_lifecycle(self, tmp_path):
        """Schema v1 -> v2 -> validate -> plan -> create -> apply -> rollback."""
        # Define schemas
        v1 = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER", primary_key=True, nullable=False),
                Column(name="email", type="VARCHAR", max_length=255),
            ]),
        ])

        v2 = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER", primary_key=True, nullable=False),
                Column(name="email", type="VARCHAR", max_length=255),
                Column(name="name", type="TEXT"),
                Column(name="created_at", type="TIMESTAMP", default="NOW()"),
            ], indexes=[
                Index(name="idx_users_email", columns=["email"], unique=True),
            ]),
            Table(name="posts", columns=[
                Column(name="id", type="INTEGER", primary_key=True, nullable=False),
                Column(name="user_id", type="INTEGER", references="users.id"),
                Column(name="title", type="TEXT", nullable=False),
                Column(name="body", type="TEXT"),
            ]),
        ])

        # 1. Diff
        diff = SchemaDiff(source=v1, target=v2)
        changes = diff.compute()
        assert len(changes) > 0
        assert diff.has_changes

        # 2. Validate target
        validator = SchemaValidator()
        issues = validator.validate(v2)
        errors = [i for i in issues if i.severity.value == "ERROR"]
        assert len(errors) == 0

        # 3. Plan migration
        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert plan.total_steps > 0
        assert "CREATE TABLE" in plan.up_sql or "ADD COLUMN" in plan.up_sql

        # 4. Lint the SQL
        linter = MigrationLinter()
        lint_issues = linter.lint(plan.up_sql)
        # No errors expected for this simple case

        # 5. Create migration
        mgr = MigrationManager(tmp_path / "migrations")
        mgr.init()
        migration = mgr.create_migration(
            name="v1_to_v2",
            up_sql=plan.up_sql,
            down_sql=plan.down_sql,
        )
        assert migration.id
        assert migration.status == MigrationStatus.PENDING

        # 6. Apply
        result = mgr.apply_migration(migration)
        assert result["status"] == "applied"
        assert migration.status == MigrationStatus.APPLIED

        # 7. Validate checksums
        issues = mgr.validate_checksums()
        assert len(issues) == 0

        # 8. Rollback
        result = mgr.rollback_migration(migration)
        assert result["status"] == "rolled_back"

    def test_snapshot_drift_workflow(self, tmp_path):
        """Save snapshot -> modify -> detect drift."""
        snap_mgr = SnapshotManager(tmp_path / "snapshots")

        v1 = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER"),
                Column(name="email", type="TEXT"),
            ]),
        ])
        snap_mgr.save(v1, label="baseline")

        v2 = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER"),
                Column(name="email", type="TEXT"),
                Column(name="phone", type="TEXT"),
            ]),
        ])
        assert snap_mgr.has_drift(v2)
        details = snap_mgr.drift_details(v2)
        assert details["drifted"]
        assert details["changes"] > 0

    def test_multi_dialect_generation(self):
        """Same diff generates different SQL for different dialects."""
        a = Schema()
        b = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER", primary_key=True),
                Column(name="email", type="VARCHAR", max_length=255),
            ]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        pg_plan = MigrationPlanner(dialect="postgresql").plan(diff)
        my_plan = MigrationPlanner(dialect="mysql").plan(diff)
        sq_plan = MigrationPlanner(dialect="sqlite").plan(diff)

        assert '"users"' in pg_plan.up_sql  # double quotes
        assert '`users`' in my_plan.up_sql  # backticks
        assert '"users"' in sq_plan.up_sql
        assert "ENGINE=InnoDB" in my_plan.up_sql

    def test_parse_diff_plan_roundtrip(self, tmp_path):
        """Parse SQL -> diff -> plan -> valid SQL."""
        sql = """
        CREATE TABLE users (
            id INTEGER PRIMARY KEY NOT NULL,
            email VARCHAR(255) UNIQUE,
            name TEXT,
            created_at TIMESTAMP DEFAULT NOW()
        );
        CREATE UNIQUE INDEX idx_email ON users (email);
        """
        parser = SQLParser()
        source = parser.parse(sql)

        # Add table
        target_sql = sql + """
        CREATE TABLE posts (
            id INTEGER PRIMARY KEY NOT NULL,
            user_id INTEGER REFERENCES users(id),
            title TEXT NOT NULL,
            body TEXT
        );
        """
        target = parser.parse(target_sql)

        diff = SchemaDiff(source=source, target=target)
        changes = diff.compute()
        assert len(changes) > 0

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "CREATE TABLE" in plan.up_sql

    def test_schema_merge_then_diff(self):
        """Merge two schemas then diff against original."""
        base = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER"),
            ]),
        ])

        branch_a = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER"),
                Column(name="email", type="TEXT"),
            ]),
        ])

        branch_b = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER"),
                Column(name="name", type="TEXT"),
            ]),
        ])

        merger = SchemaMerger()
        result = merger.merge(branch_a, branch_b)
        merged = result.schema

        # Diff base vs merged
        diff = SchemaDiff(source=base, target=merged)
        changes = diff.compute()
        # Should have added both email and name
        add_cols = [c for c in changes if c.change_type.value == "ADD_COLUMN"]
        assert len(add_cols) == 2

    def test_migration_graph_workflow(self, tmp_path):
        """Create migrations with deps, resolve execution order."""
        mgr = MigrationManager(tmp_path / "migrations")
        mgr.init()

        m1 = mgr.create_migration(name="create_users", up_sql="CREATE TABLE users(id INT);")
        m2 = mgr.create_migration(name="create_posts", up_sql="CREATE TABLE posts(id INT);",
                                   depends_on=[m1.id])
        m3 = mgr.create_migration(name="add_fk", up_sql="ALTER TABLE posts ADD COLUMN user_id INT;",
                                   depends_on=[m1.id, m2.id])

        graph = MigrationGraph()
        graph.add_migration(m1)
        graph.add_migration(m2)
        graph.add_migration(m3)

        order = graph.get_execution_order()
        ids = [m.id for m in order]
        assert ids.index(m1.id) < ids.index(m2.id)
        assert ids.index(m2.id) < ids.index(m3.id)

    def test_report_generation(self):
        """Generate complete diff report."""
        a = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER"),
                Column(name="email", type="TEXT"),
            ]),
        ])
        b = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER"),
                Column(name="email", type="VARCHAR", max_length=255),
                Column(name="name", type="TEXT"),
            ]),
            Table(name="posts", columns=[
                Column(name="id", type="INTEGER"),
            ]),
        ])

        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        gen = ReportGenerator()
        report = gen.generate_diff_report(diff, "v1", "v2")
        assert report.total_changes > 0

        # Generate markdown
        md = report.to_markdown()
        assert "# Schema Diff Report" in md

        # Generate JSON
        j = report.to_json()
        data = json.loads(j)
        assert data["total_changes"] > 0

    def test_normalize_then_diff(self):
        """Normalize types before diffing."""
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="id", type="INT")]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="id", type="INTEGER")]),
        ])

        # Without normalization - types differ
        diff_raw = SchemaDiff(source=a, target=b)
        raw_changes = diff_raw.compute()
        assert len(raw_changes) > 0  # INT != INTEGER

        # With normalization - should be same
        normalizer = SchemaNormalizer()
        a_norm = normalizer.normalize(a)
        b_norm = normalizer.normalize(b)
        diff_norm = SchemaDiff(source=a_norm, target=b_norm)
        norm_changes = diff_norm.compute()
        assert len(norm_changes) == 0

    def test_loader_roundtrip(self, tmp_path):
        """Save and load schema in different formats."""
        loader = SchemaLoader()
        schema = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER", primary_key=True),
                Column(name="email", type="VARCHAR", max_length=255),
            ]),
        ])

        # JSON roundtrip
        json_path = tmp_path / "schema.json"
        loader.save(schema, json_path)
        loaded_json = loader.load(json_path)
        assert len(loaded_json.tables) == 1
        assert loaded_json.tables[0].columns[0].name == "id"

        # YAML roundtrip
        yaml_path = tmp_path / "schema.yml"
        loader.save(schema, yaml_path)
        loaded_yaml = loader.load(yaml_path)
        assert len(loaded_yaml.tables) == 1

    def test_complex_schema_diff(self):
        """Test diffing a complex schema with all object types."""
        source = Schema(tables=[
            Table(
                name="users",
                columns=[
                    Column(name="id", type="INTEGER", primary_key=True),
                    Column(name="email", type="VARCHAR", max_length=255),
                    Column(name="old_field", type="TEXT"),
                ],
                indexes=[
                    Index(name="idx_email", columns=["email"], unique=True),
                    Index(name="idx_old", columns=["old_field"]),
                ],
                constraints=[
                    Constraint(name="pk_users", type="PRIMARY KEY", columns=["id"]),
                ],
                comment="Users table v1",
            ),
        ])

        target = Schema(tables=[
            Table(
                name="users",
                columns=[
                    Column(name="id", type="BIGINT", primary_key=True),  # type change
                    Column(name="email", type="VARCHAR", max_length=320),  # length change
                    Column(name="username", type="VARCHAR", max_length=50),  # new
                    # old_field dropped
                ],
                indexes=[
                    Index(name="idx_email", columns=["email"], unique=True),
                    Index(name="idx_username", columns=["username"]),  # new
                    # idx_old dropped
                ],
                constraints=[
                    Constraint(name="pk_users", type="PRIMARY KEY", columns=["id"]),
                    Constraint(name="uq_username", type="UNIQUE", columns=["username"]),  # new
                ],
                comment="Users table v2",
            ),
        ])

        diff = SchemaDiff(source=source, target=target)
        changes = diff.compute()

        change_types = {c.change_type.value for c in changes}
        assert "ALTER_COLUMN" in change_types  # id type, email length
        assert "ADD_COLUMN" in change_types  # username
        assert "DROP_COLUMN" in change_types  # old_field
        assert "ADD_INDEX" in change_types  # idx_username
        assert "DROP_INDEX" in change_types  # idx_old
        assert "ADD_CONSTRAINT" in change_types  # uq_username
        assert "CHANGE_COMMENT" in change_types

        # Should have destructive changes
        assert diff.has_destructive_changes


class TestEdgeCases:
    def test_empty_schemas_diff(self):
        diff = SchemaDiff(source=Schema(), target=Schema())
        assert len(diff.compute()) == 0

    def test_single_column_table(self):
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="id", type="INTEGER")]),
        ])
        assert schema.fingerprint()

    def test_schema_with_all_types(self):
        from migra.schema import ColumnType
        types = [ct.value for ct in ColumnType]
        columns = [Column(name=f"col_{t.lower()}", type=t) for t in types]
        table = Table(name="all_types", columns=columns)
        schema = Schema(tables=[table])
        assert schema.fingerprint()
        assert len(schema.tables[0].columns) == len(types)

    def test_deep_dependency_chain(self, tmp_path):
        graph = MigrationGraph()
        from migra.migration import Migration
        prev_id = None
        for i in range(10):
            mid = f"m_{i:03d}"
            m = Migration(id=mid, version=str(i), name=mid,
                         depends_on=[prev_id] if prev_id else [])
            graph.add_migration(m)
            prev_id = mid

        order = graph.get_execution_order()
        assert len(order) == 10
        for i in range(9):
            assert order[i].id == f"m_{i:03d}"

    def test_large_schema_fingerprint(self):
        tables = []
        for i in range(100):
            cols = [Column(name=f"col_{j}", type="TEXT") for j in range(10)]
            tables.append(Table(name=f"table_{i}", columns=cols))
        schema = Schema(tables=tables)
        fp = schema.fingerprint()
        assert fp
        assert len(fp) == 16

    def test_unicode_column_names(self):
        table = Table(name="test", columns=[
            Column(name="name_ko", type="TEXT"),
            Column(name="desc_jp", type="TEXT"),
        ])
        assert table.fingerprint()

    def test_very_long_sql(self):
        long_sql = "SELECT " + ", ".join(f"col_{i}" for i in range(1000)) + " FROM t;"
        linter = MigrationLinter()
        issues = linter.lint(long_sql)
        assert isinstance(issues, list)
