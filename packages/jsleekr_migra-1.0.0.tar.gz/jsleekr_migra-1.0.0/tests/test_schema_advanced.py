"""Advanced schema tests."""

import json
import pytest

from migra.schema import Column, Constraint, ConstraintType, Index, Schema, Table


class TestSchemaAdvanced:
    def test_dependency_order_chain(self):
        schema = Schema(tables=[
            Table(name="c", constraints=[
                Constraint(name="fk_b", type="FOREIGN KEY", columns=["b_id"],
                           references_table="b", references_columns=["id"]),
            ]),
            Table(name="b", constraints=[
                Constraint(name="fk_a", type="FOREIGN KEY", columns=["a_id"],
                           references_table="a", references_columns=["id"]),
            ]),
            Table(name="a"),
        ])
        order = schema.dependency_order()
        assert order.index("a") < order.index("b")
        assert order.index("b") < order.index("c")

    def test_dependency_order_diamond(self):
        schema = Schema(tables=[
            Table(name="d", constraints=[
                Constraint(name="fk_b", type="FOREIGN KEY", columns=["b_id"],
                           references_table="b", references_columns=["id"]),
                Constraint(name="fk_c", type="FOREIGN KEY", columns=["c_id"],
                           references_table="c", references_columns=["id"]),
            ]),
            Table(name="b", constraints=[
                Constraint(name="fk_a", type="FOREIGN KEY", columns=["a_id"],
                           references_table="a", references_columns=["id"]),
            ]),
            Table(name="c", constraints=[
                Constraint(name="fk_a", type="FOREIGN KEY", columns=["a_id"],
                           references_table="a", references_columns=["id"]),
            ]),
            Table(name="a"),
        ])
        order = schema.dependency_order()
        assert order.index("a") < order.index("b")
        assert order.index("a") < order.index("c")
        assert order.index("b") < order.index("d")
        assert order.index("c") < order.index("d")

    def test_large_schema_serialization(self):
        tables = []
        for i in range(50):
            cols = [Column(name=f"col_{j}", type="TEXT") for j in range(5)]
            tables.append(Table(name=f"table_{i}", columns=cols))
        schema = Schema(name="large_db", tables=tables)

        j = schema.to_json()
        loaded = Schema.from_json(j)
        assert len(loaded.tables) == 50

    def test_schema_with_complex_defaults(self):
        table = Table(name="t", columns=[
            Column(name="id", type="INTEGER", default="nextval('seq')"),
            Column(name="ts", type="TIMESTAMP", default="CURRENT_TIMESTAMP"),
            Column(name="uuid", type="UUID", default="gen_random_uuid()"),
            Column(name="arr", type="ARRAY", default="'{}'"),
        ])
        d = table.to_dict()
        t2 = Table.from_dict(d)
        assert t2.columns[0].default == "nextval('seq')"
        assert t2.columns[1].default == "CURRENT_TIMESTAMP"

    def test_schema_fingerprint_order_independent(self):
        s1 = Schema(tables=[
            Table(name="a", columns=[Column(name="x", type="TEXT")]),
            Table(name="b", columns=[Column(name="y", type="TEXT")]),
        ])
        s2 = Schema(tables=[
            Table(name="b", columns=[Column(name="y", type="TEXT")]),
            Table(name="a", columns=[Column(name="x", type="TEXT")]),
        ])
        assert s1.fingerprint() == s2.fingerprint()

    def test_table_fingerprint_column_order_independent(self):
        t1 = Table(name="t", columns=[
            Column(name="a", type="TEXT"),
            Column(name="b", type="INTEGER"),
        ])
        t2 = Table(name="t", columns=[
            Column(name="b", type="INTEGER"),
            Column(name="a", type="TEXT"),
        ])
        assert t1.fingerprint() == t2.fingerprint()

    def test_table_to_dict_no_indexes(self):
        t = Table(name="t", columns=[Column(name="id", type="INTEGER")])
        d = t.to_dict()
        assert "indexes" not in d
        assert "constraints" not in d

    def test_schema_from_dict_minimal(self):
        data = {"tables": [{"name": "t", "columns": [{"name": "id", "type": "INT"}]}]}
        s = Schema.from_dict(data)
        assert s.name == "default"
        assert len(s.tables) == 1

    def test_column_comment_serialization(self):
        col = Column(name="x", type="TEXT", comment="This is a test column")
        d = col.to_dict()
        assert d["comment"] == "This is a test column"
        col2 = Column.from_dict(d)
        assert col2.comment == "This is a test column"

    def test_index_from_dict_defaults(self):
        data = {"name": "idx", "columns": ["a"]}
        idx = Index.from_dict(data)
        assert idx.unique is False
        assert idx.index_type == "BTREE"

    def test_constraint_from_dict_defaults(self):
        data = {"name": "c", "type": "UNIQUE", "columns": ["x"]}
        c = Constraint.from_dict(data)
        assert c.deferrable is False
        assert c.on_delete is None

    def test_empty_table_fingerprint(self):
        t1 = Table(name="empty1")
        t2 = Table(name="empty1")
        assert t1.fingerprint() == t2.fingerprint()

    def test_different_schema_names_different_fingerprints(self):
        t1 = Table(name="t", schema="public")
        t2 = Table(name="t", schema="app")
        assert t1.fingerprint() != t2.fingerprint()

    def test_add_remove_roundtrip(self):
        s = Schema()
        t = Table(name="users")
        s.add_table(t)
        assert len(s.tables) == 1
        removed = s.remove_table("users")
        assert removed is not None
        assert len(s.tables) == 0
