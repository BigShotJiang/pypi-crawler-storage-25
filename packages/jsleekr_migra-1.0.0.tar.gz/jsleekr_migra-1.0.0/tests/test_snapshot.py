"""Tests for snapshot management."""

import pytest

from migra.schema import Column, Schema, Table
from migra.snapshot import Snapshot, SnapshotManager


class TestSnapshot:
    def test_creation(self):
        schema = Schema(tables=[Table(name="t")])
        snap = Snapshot(id="test", schema=schema)
        assert snap.id == "test"
        assert snap.created_at

    def test_to_dict(self):
        schema = Schema(tables=[Table(name="t")])
        snap = Snapshot(id="test", schema=schema, label="v1")
        d = snap.to_dict()
        assert d["id"] == "test"
        assert d["label"] == "v1"

    def test_from_dict(self):
        data = {
            "id": "test",
            "schema": {"name": "db", "tables": []},
            "label": "v1",
        }
        snap = Snapshot.from_dict(data)
        assert snap.id == "test"
        assert snap.label == "v1"

    def test_fingerprint(self):
        schema = Schema(tables=[Table(name="t")])
        snap = Snapshot(id="test", schema=schema)
        assert snap.fingerprint()


class TestSnapshotManager:
    @pytest.fixture
    def mgr(self, tmp_path):
        return SnapshotManager(tmp_path / "snapshots")

    def test_init(self, mgr):
        path = mgr.init()
        assert path.exists()

    def test_save(self, mgr):
        schema = Schema(tables=[
            Table(name="users", columns=[Column(name="id", type="INTEGER")]),
        ])
        snap = mgr.save(schema)
        assert snap.id
        assert snap.created_at

    def test_save_with_label(self, mgr):
        schema = Schema(tables=[Table(name="t")])
        snap = mgr.save(schema, label="baseline")
        assert snap.label == "baseline"

    def test_load(self, mgr):
        schema = Schema(tables=[Table(name="t")])
        snap = mgr.save(schema)
        loaded = mgr.load(snap.id)
        assert loaded is not None
        assert loaded.id == snap.id

    def test_load_not_found(self, mgr):
        mgr.init()
        assert mgr.load("nonexistent") is None

    def test_list_snapshots(self, mgr):
        s1 = Schema(tables=[Table(name="t1")])
        s2 = Schema(tables=[Table(name="t2")])
        mgr.save(s1, label="s1")
        mgr.save(s2, label="s2")
        snaps = mgr.list_snapshots()
        assert len(snaps) == 2

    def test_list_empty(self, mgr):
        mgr.init()
        snaps = mgr.list_snapshots()
        assert len(snaps) == 0

    def test_list_nonexistent_dir(self, tmp_path):
        mgr = SnapshotManager(tmp_path / "nope")
        snaps = mgr.list_snapshots()
        assert len(snaps) == 0

    def test_latest(self, mgr):
        s1 = Schema(tables=[Table(name="t1")])
        s2 = Schema(tables=[Table(name="t2")])
        mgr.save(s1, label="s1")
        snap2 = mgr.save(s2, label="s2")
        latest = mgr.latest()
        assert latest is not None
        assert latest.label == "s2"

    def test_latest_empty(self, mgr):
        mgr.init()
        assert mgr.latest() is None

    def test_delete(self, mgr):
        schema = Schema(tables=[Table(name="t")])
        snap = mgr.save(schema)
        assert mgr.delete(snap.id)
        assert mgr.load(snap.id) is None

    def test_delete_not_found(self, mgr):
        mgr.init()
        assert mgr.delete("nonexistent") is False

    def test_has_drift_no_baseline(self, mgr):
        mgr.init()
        schema = Schema(tables=[Table(name="t")])
        assert mgr.has_drift(schema) is False

    def test_has_drift_no_change(self, mgr):
        schema = Schema(tables=[Table(name="t")])
        mgr.save(schema)
        assert mgr.has_drift(schema) is False

    def test_has_drift_changed(self, mgr):
        s1 = Schema(tables=[Table(name="t")])
        mgr.save(s1)
        s2 = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")]),
        ])
        assert mgr.has_drift(s2) is True

    def test_drift_details_no_baseline(self, mgr):
        mgr.init()
        schema = Schema(tables=[Table(name="t")])
        details = mgr.drift_details(schema)
        assert details["drifted"] is False
        assert details["reason"] == "no_baseline"

    def test_drift_details_no_drift(self, mgr):
        schema = Schema(tables=[Table(name="t")])
        mgr.save(schema)
        details = mgr.drift_details(schema)
        assert details["drifted"] is False

    def test_drift_details_with_drift(self, mgr):
        s1 = Schema(tables=[Table(name="t")])
        mgr.save(s1)
        s2 = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")]),
        ])
        details = mgr.drift_details(s2)
        assert details["drifted"] is True
        assert details["changes"] > 0
        assert "summary" in details
