"""Advanced validator tests."""

import pytest
from migra.schema import Column, Constraint, Index, Schema, Table
from migra.validator import (
    MigrationValidator, SchemaValidator, ValidationIssue, ValidationSeverity,
    PrimaryKeyRule, NamingConventionRule, ForeignKeyRule, ColumnTypeRule,
    IndexRule, NullableRule, ReservedWordRule, TableSizeRule, ValidationRule,
)


class TestIndividualRules:
    def test_primary_key_rule_with_column_pk(self):
        rule = PrimaryKeyRule()
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="id", type="INTEGER", primary_key=True)]),
        ])
        issues = rule.check(schema)
        assert len(issues) == 0

    def test_primary_key_rule_with_constraint_pk(self):
        rule = PrimaryKeyRule()
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="id", type="INTEGER")],
                  constraints=[Constraint(name="pk", type="PRIMARY KEY", columns=["id"])]),
        ])
        issues = rule.check(schema)
        assert len(issues) == 0

    def test_naming_convention_bak_prefix(self):
        rule = NamingConventionRule()
        schema = Schema(tables=[Table(name="bak_users")])
        issues = rule.check(schema)
        assert any(i.code == "TABLE_PREFIX" for i in issues)

    def test_naming_convention_old_prefix(self):
        rule = NamingConventionRule()
        schema = Schema(tables=[Table(name="old_data")])
        issues = rule.check(schema)
        assert any(i.code == "TABLE_PREFIX" for i in issues)

    def test_naming_convention_clean(self):
        rule = NamingConventionRule()
        schema = Schema(tables=[Table(name="users")])
        issues = rule.check(schema)
        prefix_issues = [i for i in issues if i.code == "TABLE_PREFIX"]
        assert len(prefix_issues) == 0

    def test_fk_rule_constraint_valid(self):
        rule = ForeignKeyRule()
        schema = Schema(tables=[
            Table(name="users", columns=[Column(name="id", type="INTEGER")]),
            Table(name="orders", columns=[Column(name="uid", type="INTEGER")],
                  constraints=[Constraint(
                      name="fk", type="FOREIGN KEY", columns=["uid"],
                      references_table="users", references_columns=["id"],
                  )]),
        ])
        issues = rule.check(schema)
        fk_errors = [i for i in issues if i.code == "FK_MISSING_TABLE"]
        assert len(fk_errors) == 0

    def test_column_type_float8(self):
        rule = ColumnTypeRule()
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="FLOAT8")]),
        ])
        issues = rule.check(schema)
        assert any(i.code == "DEPRECATED_TYPE" for i in issues)

    def test_column_type_int2(self):
        rule = ColumnTypeRule()
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="INT2")]),
        ])
        issues = rule.check(schema)
        assert any(i.code == "DEPRECATED_TYPE" for i in issues)

    def test_index_rule_fk_constraint_no_index(self):
        rule = IndexRule()
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="uid", type="INTEGER")],
                  constraints=[Constraint(
                      name="fk", type="FOREIGN KEY", columns=["uid"],
                      references_table="users", references_columns=["id"],
                  )]),
        ])
        issues = rule.check(schema)
        assert any(i.code == "FK_NO_INDEX" for i in issues)

    def test_index_rule_no_duplicates(self):
        rule = IndexRule()
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")],
                  indexes=[
                      Index(name="idx_a", columns=["x"]),
                  ]),
        ])
        issues = rule.check(schema)
        dup_issues = [i for i in issues if i.code == "DUPLICATE_INDEX"]
        assert len(dup_issues) == 0

    def test_nullable_rule_below_threshold(self):
        rule = NullableRule()
        schema = Schema(tables=[
            Table(name="t", columns=[
                Column(name="a", type="TEXT", nullable=True),
                Column(name="b", type="TEXT", nullable=False),
                Column(name="c", type="TEXT", nullable=False),
                Column(name="d", type="TEXT", nullable=False),
                Column(name="e", type="TEXT", nullable=False),
            ]),
        ])
        issues = rule.check(schema)
        assert len(issues) == 0  # Only 20% nullable

    def test_reserved_word_all_reserved(self):
        rule = ReservedWordRule()
        schema = Schema(tables=[
            Table(name="table", columns=[Column(name="select", type="TEXT")]),
        ])
        issues = rule.check(schema)
        assert len(issues) >= 2

    def test_table_size_under_limit(self):
        rule = TableSizeRule()
        cols = [Column(name=f"c{i}", type="TEXT") for i in range(10)]
        schema = Schema(tables=[Table(name="t", columns=cols)])
        issues = rule.check(schema)
        assert len(issues) == 0

    def test_table_size_at_limit(self):
        rule = TableSizeRule()
        cols = [Column(name=f"c{i}", type="TEXT") for i in range(50)]
        schema = Schema(tables=[Table(name="t", columns=cols)])
        issues = rule.check(schema)
        assert len(issues) == 0  # Exactly at limit, not over

    def test_custom_rule(self):
        class CustomRule(ValidationRule):
            def check(self, schema):
                return [ValidationIssue(
                    severity=ValidationSeverity.INFO,
                    code="CUSTOM",
                    message="Custom check",
                )]

        validator = SchemaValidator()
        validator.add_rule(CustomRule())
        issues = validator.validate(Schema())
        assert any(i.code == "CUSTOM" for i in issues)


class TestMigrationValidatorAdvanced:
    def test_validate_safe_operations(self):
        v = MigrationValidator()
        sqls = [
            "ALTER TABLE t ADD COLUMN x TEXT;",
            "CREATE INDEX idx ON t (x);",
            "DROP TABLE IF EXISTS tmp;",
        ]
        for sql in sqls:
            issues = v.validate_sql(sql)
            errors = [i for i in issues if i.severity == ValidationSeverity.ERROR]
            assert len(errors) == 0, f"Unexpected error for: {sql}"

    def test_validate_whitespace_only(self):
        v = MigrationValidator()
        issues = v.validate_sql("   \n  \t  ")
        assert any(i.code == "EMPTY_MIGRATION" for i in issues)

    def test_validate_single_statement(self):
        v = MigrationValidator()
        issues = v.validate_sql("ALTER TABLE t ADD COLUMN x TEXT;")
        no_txn = [i for i in issues if i.code == "NO_TRANSACTION"]
        assert len(no_txn) == 0  # Single statement doesn't need transaction

    def test_validate_multiple_dangerous_ops(self):
        v = MigrationValidator()
        sql = """
        DROP TABLE users;
        TRUNCATE TABLE logs;
        ALTER TABLE orders ALTER COLUMN id TYPE BIGINT;
        ALTER TABLE products ALTER COLUMN name SET NOT NULL;
        """
        issues = v.validate_sql(sql)
        codes = {i.code for i in issues}
        assert "DROP_WITHOUT_IF_EXISTS" in codes
        assert "TRUNCATE_TABLE" in codes
        assert "TYPE_CHANGE" in codes
        assert "SET_NOT_NULL" in codes
