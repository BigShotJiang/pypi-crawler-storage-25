"""Tests for migration squasher."""

import pytest

from migra.migration import Migration, MigrationStatus
from migra.squasher import MigrationSquasher


def _m(mid: str, up: str = "", down: str = "", status: str = "PENDING", deps: list[str] = None) -> Migration:
    return Migration(id=mid, version="1", name=mid, up_sql=up, down_sql=down,
                     status=MigrationStatus(status), depends_on=deps or [])


class TestMigrationSquasher:
    def test_squash_two(self):
        squasher = MigrationSquasher()
        m1 = _m("001", up="CREATE TABLE t(id INT);", down="DROP TABLE t;")
        m2 = _m("002", up="ALTER TABLE t ADD COLUMN x TEXT;", down="ALTER TABLE t DROP COLUMN x;")
        result = squasher.squash([m1, m2])
        assert "CREATE TABLE" in result.up_sql
        assert "ADD COLUMN" in result.up_sql
        assert "squashed" in result.tags

    def test_squash_down_reversed(self):
        squasher = MigrationSquasher()
        m1 = _m("001", up="S1;", down="D1;")
        m2 = _m("002", up="S2;", down="D2;")
        result = squasher.squash([m1, m2])
        # Down should be in reverse order
        assert result.down_sql.index("D2;") < result.down_sql.index("D1;")

    def test_squash_empty_raises(self):
        squasher = MigrationSquasher()
        with pytest.raises(ValueError, match="No migrations"):
            squasher.squash([])

    def test_squash_single(self):
        squasher = MigrationSquasher()
        m = _m("001", up="SELECT 1;")
        result = squasher.squash([m])
        assert result.id == "001"

    def test_squash_custom_name(self):
        squasher = MigrationSquasher()
        m1 = _m("001", up="S1;", down="D1;")
        m2 = _m("002", up="S2;", down="D2;")
        result = squasher.squash([m1, m2], name="combined")
        assert "combined" in result.name

    def test_squash_custom_description(self):
        squasher = MigrationSquasher()
        m1 = _m("001", up="S1;")
        m2 = _m("002", up="S2;")
        result = squasher.squash([m1, m2], description="Test squash")
        assert result.description == "Test squash"

    def test_squash_three(self):
        squasher = MigrationSquasher()
        migrations = [
            _m("001", up="CREATE TABLE t1(id INT);", down="DROP TABLE t1;"),
            _m("002", up="CREATE TABLE t2(id INT);", down="DROP TABLE t2;"),
            _m("003", up="CREATE INDEX idx ON t1(id);", down="DROP INDEX idx;"),
        ]
        result = squasher.squash(migrations)
        assert "t1" in result.up_sql
        assert "t2" in result.up_sql
        assert "INDEX" in result.up_sql

    def test_squash_empty_sql_skipped(self):
        squasher = MigrationSquasher()
        m1 = _m("001", up="SELECT 1;", down="")
        m2 = _m("002", up="", down="SELECT 2;")
        result = squasher.squash([m1, m2])
        assert "SELECT 1" in result.up_sql
        assert "SELECT 2" in result.down_sql

    def test_can_squash_ok(self):
        squasher = MigrationSquasher()
        migrations = [
            _m("001", up="S1;", down="D1;"),
            _m("002", up="S2;", down="D2;"),
        ]
        ok, issues = squasher.can_squash(migrations)
        assert ok is True
        assert len(issues) == 0

    def test_can_squash_empty(self):
        squasher = MigrationSquasher()
        ok, issues = squasher.can_squash([])
        assert ok is False

    def test_can_squash_mixed_status(self):
        squasher = MigrationSquasher()
        migrations = [
            _m("001", up="S1;", down="D1;", status="APPLIED"),
            _m("002", up="S2;", down="D2;", status="PENDING"),
        ]
        ok, issues = squasher.can_squash(migrations)
        assert ok is False
        assert any("Mixed statuses" in i for i in issues)

    def test_can_squash_no_down(self):
        squasher = MigrationSquasher()
        migrations = [
            _m("001", up="S1;", down="D1;"),
            _m("002", up="S2;", down=""),
        ]
        ok, issues = squasher.can_squash(migrations)
        assert ok is False
        assert any("rollback" in i.lower() for i in issues)

    def test_can_squash_external_deps(self):
        squasher = MigrationSquasher()
        migrations = [
            _m("002", up="S2;", down="D2;", deps=["external_001"]),
        ]
        ok, issues = squasher.can_squash(migrations)
        assert ok is False
        assert any("external" in i.lower() for i in issues)

    def test_optimize_sql(self):
        squasher = MigrationSquasher()
        sql = "SELECT 1;\nSELECT 2;"
        result = squasher.optimize_sql(sql)
        assert isinstance(result, str)
