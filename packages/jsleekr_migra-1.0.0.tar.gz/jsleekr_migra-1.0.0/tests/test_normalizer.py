"""Tests for schema normalizer."""

import pytest

from migra.normalizer import SchemaNormalizer, TYPE_ALIASES, SERIAL_TYPES
from migra.schema import Column, Schema, Table


class TestSchemaNormalizer:
    @pytest.fixture
    def normalizer(self):
        return SchemaNormalizer()

    def test_normalize_int_alias(self, normalizer):
        assert normalizer._normalize_type("INT") == "INTEGER"

    def test_normalize_bool_alias(self, normalizer):
        assert normalizer._normalize_type("BOOL") == "BOOLEAN"

    def test_normalize_float4(self, normalizer):
        assert normalizer._normalize_type("FLOAT4") == "FLOAT"

    def test_normalize_varchar_alias(self, normalizer):
        assert normalizer._normalize_type("CHARACTER VARYING") == "VARCHAR"

    def test_normalize_datetime_alias(self, normalizer):
        assert normalizer._normalize_type("DATETIME") == "TIMESTAMP"

    def test_normalize_serial(self, normalizer):
        assert normalizer._normalize_type("SERIAL") == "INTEGER"

    def test_normalize_bigserial(self, normalizer):
        assert normalizer._normalize_type("BIGSERIAL") == "BIGINT"

    def test_normalize_unknown_type(self, normalizer):
        assert normalizer._normalize_type("UUID") == "UUID"

    def test_normalize_case_insensitive(self, normalizer):
        assert normalizer._normalize_type("int") == "INTEGER"
        assert normalizer._normalize_type("Bool") == "BOOLEAN"

    def test_normalize_column(self, normalizer):
        col = Column(name="id", type="INT", primary_key=True)
        norm = normalizer._normalize_column(col)
        assert norm.type == "INTEGER"
        assert norm.primary_key is True

    def test_normalize_serial_column(self, normalizer):
        col = Column(name="id", type="SERIAL")
        norm = normalizer._normalize_column(col)
        assert norm.type == "INTEGER"
        assert norm.auto_increment is True

    def test_normalize_table(self, normalizer):
        table = Table(name="users", columns=[
            Column(name="id", type="INT", primary_key=True),
            Column(name="active", type="BOOL"),
        ])
        norm = normalizer._normalize_table(table)
        assert norm.columns[0].type == "INTEGER"
        assert norm.columns[1].type == "BOOLEAN"

    def test_normalize_schema(self, normalizer):
        schema = Schema(tables=[
            Table(name="t", columns=[
                Column(name="id", type="INT"),
                Column(name="dt", type="DATETIME"),
            ]),
        ])
        norm = normalizer.normalize(schema)
        assert norm.tables[0].columns[0].type == "INTEGER"
        assert norm.tables[0].columns[1].type == "TIMESTAMP"

    def test_normalize_preserves_metadata(self, normalizer):
        schema = Schema(name="test", version="1.0", metadata={"key": "val"})
        norm = normalizer.normalize(schema)
        assert norm.name == "test"
        assert norm.version == "1.0"
        assert norm.metadata["key"] == "val"

    def test_normalize_name_strips_quotes(self, normalizer):
        assert normalizer._normalize_name('"users"') == "users"
        assert normalizer._normalize_name('`orders`') == "orders"

    def test_type_comparison(self, normalizer):
        assert normalizer.normalize_type_for_comparison("INT", "INTEGER")
        assert normalizer.normalize_type_for_comparison("BOOL", "BOOLEAN")
        assert not normalizer.normalize_type_for_comparison("TEXT", "INTEGER")

    def test_normalize_money(self, normalizer):
        assert normalizer._normalize_type("MONEY") == "DECIMAL"

    def test_normalize_nvarchar(self, normalizer):
        assert normalizer._normalize_type("NVARCHAR") == "VARCHAR"

    def test_normalize_longtext(self, normalizer):
        assert normalizer._normalize_type("LONGTEXT") == "TEXT"

    def test_normalize_varbinary(self, normalizer):
        assert normalizer._normalize_type("VARBINARY") == "BYTEA"

    def test_all_aliases_covered(self):
        normalizer = SchemaNormalizer()
        for alias, target in TYPE_ALIASES.items():
            assert normalizer._normalize_type(alias) == target

    def test_all_serial_types(self):
        normalizer = SchemaNormalizer()
        for serial, (target, is_auto) in SERIAL_TYPES.items():
            assert normalizer._normalize_type(serial) == target

    def test_normalize_empty_schema(self, normalizer):
        schema = Schema()
        norm = normalizer.normalize(schema)
        assert len(norm.tables) == 0
