"""Advanced CLI tests."""

import json
import pytest
from click.testing import CliRunner

from migra.cli import main
from migra.schema import Column, Schema, Table


@pytest.fixture
def runner():
    return CliRunner()


class TestCLISchemaFiles:
    def test_diff_sql_files(self, runner, tmp_path):
        f1 = tmp_path / "v1.sql"
        f1.write_text("CREATE TABLE t (id INTEGER);", encoding="utf-8")
        f2 = tmp_path / "v2.sql"
        f2.write_text("CREATE TABLE t (id INTEGER, name TEXT);", encoding="utf-8")

        result = runner.invoke(main, ["diff", str(f1), str(f2)], catch_exceptions=False)
        assert result.exit_code == 0
        assert "ADD_COLUMN" in result.output

    def test_diff_yaml_files(self, runner, tmp_path):
        import yaml
        s1 = {"tables": [{"name": "t", "columns": [{"name": "id", "type": "INTEGER"}]}]}
        s2 = {"tables": [{"name": "t", "columns": [
            {"name": "id", "type": "INTEGER"},
            {"name": "x", "type": "TEXT"},
        ]}]}
        f1 = tmp_path / "v1.yml"
        f2 = tmp_path / "v2.yml"
        f1.write_text(yaml.dump(s1), encoding="utf-8")
        f2.write_text(yaml.dump(s2), encoding="utf-8")

        result = runner.invoke(main, ["diff", str(f1), str(f2)], catch_exceptions=False)
        assert result.exit_code == 0

    def test_diff_with_dialect(self, runner, tmp_path):
        schema = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INTEGER")])])
        f1 = tmp_path / "a.json"
        f2 = tmp_path / "b.json"
        f1.write_text(schema.to_json(), encoding="utf-8")
        s2 = Schema(tables=[Table(name="t", columns=[
            Column(name="id", type="INTEGER"),
            Column(name="x", type="TEXT"),
        ])])
        f2.write_text(s2.to_json(), encoding="utf-8")

        result = runner.invoke(main, ["diff", str(f1), str(f2), "-d", "mysql"], catch_exceptions=False)
        assert result.exit_code == 0

    def test_plan_with_dialect(self, runner, tmp_path):
        s1 = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INTEGER")])])
        s2 = Schema(tables=[Table(name="t", columns=[
            Column(name="id", type="INTEGER"),
            Column(name="x", type="TEXT"),
        ])])
        f1 = tmp_path / "a.json"
        f2 = tmp_path / "b.json"
        f1.write_text(s1.to_json(), encoding="utf-8")
        f2.write_text(s2.to_json(), encoding="utf-8")

        result = runner.invoke(main, ["plan", str(f1), str(f2), "-d", "mysql", "--dry-run"],
                               catch_exceptions=False)
        assert result.exit_code == 0

    def test_validate_json_output(self, runner, tmp_path):
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="order", type="TEXT")]),
        ])
        f = tmp_path / "schema.json"
        f.write_text(schema.to_json(), encoding="utf-8")

        result = runner.invoke(main, ["validate", str(f), "-o", "json"], catch_exceptions=False)
        assert result.exit_code == 0

    def test_snapshot_and_drift(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="id", type="INTEGER")]),
        ])
        f = tmp_path / "schema.json"
        f.write_text(schema.to_json(), encoding="utf-8")

        result = runner.invoke(main, ["snapshot", str(f), "-l", "v1"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "Snapshot saved" in result.output

    def test_create_and_status(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        runner.invoke(main, ["init"], catch_exceptions=False)
        runner.invoke(main, ["create", "test_migration"], catch_exceptions=False)

        result = runner.invoke(main, ["status"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "Migration Status" in result.output

    def test_apply_and_rollback(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        runner.invoke(main, ["init"], catch_exceptions=False)
        runner.invoke(main, ["create", "test_migration"], catch_exceptions=False)

        result = runner.invoke(main, ["apply"], catch_exceptions=False)
        assert result.exit_code == 0

        result = runner.invoke(main, ["rollback"], catch_exceptions=False)
        assert result.exit_code == 0

    def test_apply_dry_run(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        runner.invoke(main, ["init"], catch_exceptions=False)
        runner.invoke(main, ["create", "test_migration"], catch_exceptions=False)

        result = runner.invoke(main, ["apply", "--dry-run"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "Dry run" in result.output


class TestCLIErrorHandling:
    def test_diff_nonexistent_file(self, runner, tmp_path):
        f = tmp_path / "schema.json"
        f.write_text(Schema().to_json(), encoding="utf-8")
        result = runner.invoke(main, ["diff", str(f), str(tmp_path / "nope.json")])
        assert result.exit_code != 0

    def test_validate_nonexistent_file(self, runner, tmp_path):
        result = runner.invoke(main, ["validate", str(tmp_path / "nope.json")])
        assert result.exit_code != 0
