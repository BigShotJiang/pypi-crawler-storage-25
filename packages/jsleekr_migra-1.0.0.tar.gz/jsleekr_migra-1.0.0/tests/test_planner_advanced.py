"""Advanced planner tests - complex scenarios."""

import pytest

from migra.diff import SchemaDiff
from migra.planner import MigrationPlanner
from migra.schema import Column, Constraint, Index, Schema, Table


class TestPostgreSQLAdvanced:
    def test_table_with_all_features(self):
        a = Schema()
        b = Schema(tables=[
            Table(
                name="orders",
                columns=[
                    Column(name="id", type="BIGINT", primary_key=True, nullable=False, auto_increment=True),
                    Column(name="user_id", type="INTEGER", nullable=False),
                    Column(name="total", type="DECIMAL", precision=10, scale=2, default="0.00"),
                    Column(name="status", type="VARCHAR", max_length=20, default="'pending'"),
                    Column(name="created_at", type="TIMESTAMPTZ", default="NOW()"),
                    Column(name="notes", type="TEXT"),
                ],
                indexes=[
                    Index(name="idx_orders_user", columns=["user_id"]),
                    Index(name="idx_orders_status", columns=["status"]),
                    Index(name="idx_orders_created", columns=["created_at"]),
                ],
                constraints=[
                    Constraint(
                        name="fk_orders_user", type="FOREIGN KEY", columns=["user_id"],
                        references_table="users", references_columns=["id"],
                        on_delete="CASCADE",
                    ),
                    Constraint(
                        name="ck_status", type="CHECK", columns=[],
                        expression="status IN ('pending', 'active', 'done')",
                    ),
                ],
                comment="Order records",
            ),
        ])

        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "CREATE TABLE" in plan.up_sql
        assert "FOREIGN KEY" in plan.up_sql
        assert "CHECK" in plan.up_sql

    def test_partial_index(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="status", type="TEXT")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="status", type="TEXT")],
                                 indexes=[Index(name="idx", columns=["status"], condition="status = 'active'")])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "WHERE" in plan.up_sql

    def test_alter_column_remove_default(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT", default="'old'")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "DROP DEFAULT" in plan.up_sql

    def test_alter_column_make_nullable(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT", nullable=False)])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT", nullable=True)])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "DROP NOT NULL" in plan.up_sql
        assert "SET NOT NULL" in plan.down_sql

    def test_add_primary_key_constraint(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INTEGER")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INTEGER")],
                                 constraints=[Constraint(name="pk_t", type="PRIMARY KEY", columns=["id"])])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "PRIMARY KEY" in plan.up_sql

    def test_comment_null(self):
        a = Schema(tables=[Table(name="t", columns=[], comment="old")])
        b = Schema(tables=[Table(name="t", columns=[], comment=None)])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "IS NULL" in plan.up_sql

    def test_drop_table_has_warnings(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INTEGER")])])
        b = Schema()
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert len(plan.warnings) > 0
        assert any("DESTRUCTIVE" in w for w in plan.warnings)


class TestMySQLAdvanced:
    def test_drop_column(self):
        a = Schema(tables=[Table(name="t", columns=[
            Column(name="id", type="INTEGER"),
            Column(name="old", type="TEXT"),
        ])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INTEGER")])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="mysql")
        plan = planner.plan(diff)
        assert "DROP COLUMN" in plan.up_sql

    def test_drop_index(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")],
                                 indexes=[Index(name="idx_x", columns=["x"])])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="mysql")
        plan = planner.plan(diff)
        assert "DROP INDEX" in plan.up_sql

    def test_add_fk_constraint(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="uid", type="INTEGER")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="uid", type="INTEGER")],
                                 constraints=[Constraint(
                                     name="fk_uid", type="FOREIGN KEY", columns=["uid"],
                                     references_table="users", references_columns=["id"],
                                 )])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="mysql")
        plan = planner.plan(diff)
        assert "FOREIGN KEY" in plan.up_sql

    def test_drop_constraint(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")],
                                 constraints=[Constraint(name="uq_x", type="UNIQUE", columns=["x"])])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="mysql")
        plan = planner.plan(diff)
        assert "DROP CONSTRAINT" in plan.up_sql


class TestSQLiteAdvanced:
    def test_drop_column(self):
        a = Schema(tables=[Table(name="t", columns=[
            Column(name="id", type="INTEGER"),
            Column(name="old", type="TEXT"),
        ])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INTEGER")])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="sqlite")
        plan = planner.plan(diff)
        assert "DROP COLUMN" in plan.up_sql

    def test_drop_table(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INTEGER")])])
        b = Schema()
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="sqlite")
        plan = planner.plan(diff)
        assert "DROP TABLE" in plan.up_sql

    def test_drop_index(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")],
                                 indexes=[Index(name="idx_x", columns=["x"])])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="sqlite")
        plan = planner.plan(diff)
        assert "DROP INDEX" in plan.up_sql

    def test_drop_constraint_warning(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")],
                                 constraints=[Constraint(name="uq_x", type="UNIQUE", columns=["x"])])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="sqlite")
        plan = planner.plan(diff)
        assert any("recreation" in w.lower() for w in plan.warnings)

    def test_comment_ignored(self):
        a = Schema(tables=[Table(name="t", columns=[], comment="old")])
        b = Schema(tables=[Table(name="t", columns=[], comment="new")])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="sqlite")
        plan = planner.plan(diff)
        # SQLite doesn't support comments
        assert "does not support" in plan.up_sql.lower() or plan.up_sql.strip() == ""


class TestPlanStepOrder:
    def test_creates_before_drops(self):
        a = Schema(tables=[
            Table(name="old_table", columns=[Column(name="id", type="INTEGER")]),
        ])
        b = Schema(tables=[
            Table(name="new_table", columns=[Column(name="id", type="INTEGER")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        types = [s.change.change_type.value for s in plan.steps]
        if "ADD_TABLE" in types and "DROP_TABLE" in types:
            assert types.index("ADD_TABLE") < types.index("DROP_TABLE")

    def test_columns_before_indexes(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INTEGER")])])
        b = Schema(tables=[Table(name="t", columns=[
            Column(name="id", type="INTEGER"),
            Column(name="name", type="TEXT"),
        ], indexes=[Index(name="idx_name", columns=["name"])])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        types = [s.change.change_type.value for s in plan.steps]
        if "ADD_COLUMN" in types and "ADD_INDEX" in types:
            assert types.index("ADD_COLUMN") < types.index("ADD_INDEX")
