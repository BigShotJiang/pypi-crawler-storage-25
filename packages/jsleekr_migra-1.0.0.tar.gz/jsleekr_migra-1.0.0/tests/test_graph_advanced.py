"""Advanced graph tests."""

import pytest
from migra.graph import MigrationGraph, MigrationNode
from migra.migration import Migration, MigrationStatus


def _m(mid, deps=None, status="PENDING"):
    return Migration(id=mid, version="1", name=mid,
                     depends_on=deps or [], status=MigrationStatus(status))


class TestGraphAdvanced:
    def test_wide_graph(self):
        """Many migrations all depending on one root."""
        g = MigrationGraph()
        g.add_migration(_m("root"))
        for i in range(20):
            g.add_migration(_m(f"leaf_{i}", ["root"]))

        order = g.get_execution_order()
        assert order[0].id == "root"
        assert len(order) == 21

    def test_deep_graph(self):
        """Long chain of dependencies."""
        g = MigrationGraph()
        prev = None
        for i in range(50):
            mid = f"m_{i:03d}"
            g.add_migration(_m(mid, [prev] if prev else []))
            prev = mid

        order = g.get_execution_order()
        assert len(order) == 50
        for i in range(49):
            assert order[i].id == f"m_{i:03d}"

    def test_multiple_roots(self):
        g = MigrationGraph()
        g.add_migration(_m("a"))
        g.add_migration(_m("b"))
        g.add_migration(_m("c", ["a", "b"]))
        roots = g.find_roots()
        assert set(roots) == {"a", "b"}

    def test_multiple_leaves(self):
        g = MigrationGraph()
        g.add_migration(_m("a"))
        g.add_migration(_m("b", ["a"]))
        g.add_migration(_m("c", ["a"]))
        leaves = g.find_leaves()
        assert set(leaves) == {"b", "c"}

    def test_rollback_safety_chain(self):
        g = MigrationGraph()
        g.add_migration(_m("a", status="APPLIED"))
        g.add_migration(_m("b", ["a"], status="APPLIED"))
        g.add_migration(_m("c", ["b"], status="APPLIED"))

        safe_c, _ = g.is_safe_to_rollback("c")
        assert safe_c is True

        safe_b, blockers_b = g.is_safe_to_rollback("b")
        assert safe_b is False
        assert "c" in blockers_b

        safe_a, blockers_a = g.is_safe_to_rollback("a")
        assert safe_a is False

    def test_subgraph_preserves_deps(self):
        g = MigrationGraph()
        g.add_migration(_m("a"))
        g.add_migration(_m("b", ["a"]))
        g.add_migration(_m("c", ["b"]))

        sub = g.subgraph({"a", "b"})
        assert len(sub) == 2
        order = sub.get_execution_order()
        assert order[0].id == "a"

    def test_remove_updates_dependents(self):
        g = MigrationGraph()
        g.add_migration(_m("a"))
        g.add_migration(_m("b", ["a"]))
        g.add_migration(_m("c", ["a"]))

        g.remove_migration("a")
        # b and c should still be in graph
        assert "b" in g
        assert "c" in g

    def test_validate_complex_graph(self):
        g = MigrationGraph()
        g.add_migration(_m("a"))
        g.add_migration(_m("b", ["a"]))
        g.add_migration(_m("c", ["a", "b"]))
        g.add_migration(_m("d", ["c"]))
        issues = g.validate()
        assert len(issues) == 0

    def test_transitive_deps_diamond(self):
        g = MigrationGraph()
        g.add_migration(_m("a"))
        g.add_migration(_m("b", ["a"]))
        g.add_migration(_m("c", ["a"]))
        g.add_migration(_m("d", ["b", "c"]))

        deps = g.get_dependencies("d")
        assert deps == {"a", "b", "c"}

    def test_transitive_dependents(self):
        g = MigrationGraph()
        g.add_migration(_m("a"))
        g.add_migration(_m("b", ["a"]))
        g.add_migration(_m("c", ["b"]))
        g.add_migration(_m("d", ["c"]))

        dependents = g.get_dependents("a")
        assert dependents == {"b", "c", "d"}
