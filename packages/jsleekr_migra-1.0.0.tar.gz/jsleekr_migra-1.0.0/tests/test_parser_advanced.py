"""Advanced parser tests."""

import pytest
from migra.parser import SQLParser


class TestSQLParserComplex:
    def test_parse_multiple_foreign_keys(self):
        sql = """
        CREATE TABLE order_items (
            id INTEGER PRIMARY KEY,
            order_id INTEGER,
            product_id INTEGER,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        fks = [c for c in table.constraints if c.type == "FOREIGN KEY"]
        assert len(fks) == 2

    def test_parse_composite_primary_key(self):
        sql = """
        CREATE TABLE user_roles (
            user_id INTEGER,
            role_id INTEGER,
            PRIMARY KEY (user_id, role_id)
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        pk = [c for c in table.constraints if c.type == "PRIMARY KEY"]
        assert len(pk) == 1
        assert set(pk[0].columns) == {"user_id", "role_id"}

    def test_parse_complex_schema(self):
        sql = """
        CREATE TABLE users (
            id INTEGER PRIMARY KEY NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            name TEXT,
            role TEXT DEFAULT 'user' NOT NULL,
            created_at TIMESTAMP DEFAULT NOW()
        );

        CREATE TABLE posts (
            id INTEGER PRIMARY KEY NOT NULL,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            body TEXT,
            published BOOLEAN DEFAULT FALSE,
            CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE UNIQUE INDEX idx_users_email ON users (email);
        CREATE INDEX idx_posts_user ON posts (user_id);
        CREATE INDEX idx_posts_published ON posts (published) WHERE published = TRUE;
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        assert len(schema.tables) == 2

        users = schema.get_table("users")
        assert users is not None
        assert len(users.columns) == 5
        assert users.get_column("email").unique is True
        assert users.get_column("email").nullable is False

        posts = schema.get_table("posts")
        assert posts is not None
        assert len(posts.constraints) == 1
        assert posts.constraints[0].name == "fk_user"

        assert len(users.indexes) == 1
        assert len(posts.indexes) == 2

    def test_parse_decimal_column(self):
        sql = "CREATE TABLE t (price DECIMAL(10,2));"
        parser = SQLParser()
        schema = parser.parse(sql)
        col = schema.tables[0].get_column("price")
        assert col.type == "DECIMAL"
        assert col.precision == 10
        assert col.scale == 2

    def test_parse_varchar_column(self):
        sql = "CREATE TABLE t (name VARCHAR(100));"
        parser = SQLParser()
        schema = parser.parse(sql)
        col = schema.tables[0].get_column("name")
        assert col.type == "VARCHAR"
        assert col.max_length == 100

    def test_parse_numeric_column(self):
        sql = "CREATE TABLE t (amount NUMERIC(15,4));"
        parser = SQLParser()
        schema = parser.parse(sql)
        col = schema.tables[0].get_column("amount")
        assert col.precision == 15
        assert col.scale == 4

    def test_parse_multiple_indexes(self):
        sql = """
        CREATE TABLE t (a TEXT, b TEXT, c TEXT);
        CREATE INDEX idx_a ON t (a);
        CREATE INDEX idx_b ON t (b);
        CREATE UNIQUE INDEX idx_c ON t (c);
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        assert len(table.indexes) == 3
        unique_idxs = [i for i in table.indexes if i.unique]
        assert len(unique_idxs) == 1

    def test_parse_all_constraint_types(self):
        sql = """
        CREATE TABLE t (
            id INTEGER,
            email TEXT,
            age INTEGER,
            dept_id INTEGER,
            PRIMARY KEY (id),
            UNIQUE (email),
            CHECK (age >= 0),
            FOREIGN KEY (dept_id) REFERENCES departments(id)
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        types = {c.type for c in table.constraints}
        assert "PRIMARY KEY" in types
        assert "UNIQUE" in types
        assert "CHECK" in types
        assert "FOREIGN KEY" in types

    def test_parse_on_update_cascade(self):
        sql = """
        CREATE TABLE t (
            ref_id INTEGER,
            FOREIGN KEY (ref_id) REFERENCES other(id) ON DELETE CASCADE ON UPDATE CASCADE
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        fk = schema.tables[0].constraints[0]
        assert fk.on_delete == "CASCADE"
        assert fk.on_update == "CASCADE"

    def test_parse_on_delete_set_null(self):
        sql = """
        CREATE TABLE t (
            ref_id INTEGER,
            FOREIGN KEY (ref_id) REFERENCES other(id) ON DELETE SET NULL
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        fk = schema.tables[0].constraints[0]
        assert fk.on_delete == "SET NULL"

    def test_parse_backtick_identifiers(self):
        sql = "CREATE TABLE `my_table` (`my_col` INTEGER);"
        parser = SQLParser()
        schema = parser.parse(sql)
        assert len(schema.tables) == 1

    def test_parse_empty_table(self):
        sql = "CREATE TABLE empty ();"
        parser = SQLParser()
        schema = parser.parse(sql)
        # May not parse successfully - that's ok
        assert isinstance(schema.tables, list)

    def test_parse_preserves_column_order(self):
        sql = """
        CREATE TABLE t (
            z_col TEXT,
            a_col TEXT,
            m_col TEXT
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        names = [c.name for c in schema.tables[0].columns]
        assert names == ["z_col", "a_col", "m_col"]
