"""Tests for configuration management."""

import json
import pytest

from migra.config import MigraConfig


class TestMigraConfig:
    def test_defaults(self):
        config = MigraConfig()
        assert config.migrations_dir == "migrations"
        assert config.dialect == "postgresql"
        assert config.auto_confirm is False
        assert config.dry_run is False
        assert config.allow_destructive is False

    def test_from_dict(self):
        data = {
            "migrations_dir": "db/migrations",
            "dialect": "mysql",
            "auto_confirm": True,
            "allow_destructive": True,
        }
        config = MigraConfig.from_dict(data)
        assert config.migrations_dir == "db/migrations"
        assert config.dialect == "mysql"
        assert config.auto_confirm is True

    def test_to_dict(self):
        config = MigraConfig(dialect="mysql", auto_confirm=True)
        d = config.to_dict()
        assert d["dialect"] == "mysql"
        assert d["auto_confirm"] is True

    def test_to_dict_with_schema_file(self):
        config = MigraConfig(schema_file="schema.json")
        d = config.to_dict()
        assert d["schema_file"] == "schema.json"

    def test_to_dict_without_optional(self):
        config = MigraConfig()
        d = config.to_dict()
        assert "schema_file" not in d
        assert "environments" not in d

    def test_environments(self):
        config = MigraConfig(environments={
            "prod": {"dialect": "postgresql", "host": "prod-db"},
            "dev": {"dialect": "sqlite", "host": "localhost"},
        })
        assert config.get_environment("prod")["host"] == "prod-db"
        assert config.get_environment("dev")["dialect"] == "sqlite"
        assert config.get_environment("staging") == {}

    def test_save_load_yaml(self, tmp_path):
        config = MigraConfig(
            dialect="mysql",
            migrations_dir="db/migrations",
            auto_confirm=True,
        )
        path = tmp_path / ".migra.yml"
        config.save(str(path))
        loaded = MigraConfig.load(str(path))
        assert loaded.dialect == "mysql"
        assert loaded.migrations_dir == "db/migrations"
        assert loaded.auto_confirm is True

    def test_save_load_json(self, tmp_path):
        config = MigraConfig(dialect="sqlite")
        path = tmp_path / ".migra.json"
        config.save(str(path))
        loaded = MigraConfig.load(str(path))
        assert loaded.dialect == "sqlite"

    def test_load_nonexistent(self, tmp_path):
        config = MigraConfig.load(str(tmp_path / "nonexistent.yml"))
        assert config.dialect == "postgresql"  # defaults

    def test_load_unsupported_format(self, tmp_path):
        path = tmp_path / "config.txt"
        path.write_text("test", encoding="utf-8")
        config = MigraConfig.load(str(path))
        assert config.dialect == "postgresql"  # defaults

    def test_hooks(self):
        config = MigraConfig(hooks={
            "pre_migrate": ["echo 'migrating'"],
            "post_migrate": ["echo 'done'"],
        })
        d = config.to_dict()
        assert "hooks" in d
        assert len(d["hooks"]["pre_migrate"]) == 1

    def test_naming_convention(self):
        config = MigraConfig(naming_convention="sequential")
        assert config.naming_convention == "sequential"

    def test_roundtrip_full(self, tmp_path):
        config = MigraConfig(
            migrations_dir="db/m",
            dialect="mysql",
            schema_file="s.json",
            target_schema_file="t.json",
            auto_confirm=True,
            dry_run=True,
            allow_destructive=True,
            naming_convention="sequential",
            environments={"prod": {"host": "db"}},
            hooks={"pre": ["echo hi"]},
        )
        path = tmp_path / ".migra.yml"
        config.save(str(path))
        loaded = MigraConfig.load(str(path))
        assert loaded.migrations_dir == "db/m"
        assert loaded.dialect == "mysql"
        assert loaded.schema_file == "s.json"
        assert loaded.auto_confirm is True
        assert loaded.environments["prod"]["host"] == "db"
