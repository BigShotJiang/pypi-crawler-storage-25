"""Tests for SQL parser."""

import pytest

from migra.parser import SQLParser


class TestSQLParser:
    def test_parse_simple_table(self):
        sql = """
        CREATE TABLE users (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            email VARCHAR(255) UNIQUE
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        assert len(schema.tables) == 1
        table = schema.tables[0]
        assert table.name == "users"
        assert len(table.columns) == 3

    def test_parse_column_types(self):
        sql = """
        CREATE TABLE test (
            a INTEGER,
            b TEXT,
            c VARCHAR(100),
            d BOOLEAN,
            e DECIMAL(10, 2),
            f TIMESTAMP
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        assert table.get_column("a").type == "INTEGER"
        assert table.get_column("b").type == "TEXT"
        assert table.get_column("c").type == "VARCHAR"
        assert table.get_column("c").max_length == 100
        assert table.get_column("e").type == "DECIMAL"
        assert table.get_column("e").precision == 10
        assert table.get_column("e").scale == 2

    def test_parse_not_null(self):
        sql = """
        CREATE TABLE t (
            a INTEGER NOT NULL,
            b TEXT
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        assert table.get_column("a").nullable is False
        assert table.get_column("b").nullable is True

    def test_parse_primary_key(self):
        sql = """
        CREATE TABLE t (
            id INTEGER PRIMARY KEY,
            name TEXT
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        assert table.get_column("id").primary_key is True
        assert table.get_column("name").primary_key is False

    def test_parse_unique(self):
        sql = """
        CREATE TABLE t (
            email VARCHAR(255) UNIQUE
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        assert table.get_column("email").unique is True

    def test_parse_default(self):
        sql = """
        CREATE TABLE t (
            status TEXT DEFAULT 'active' NOT NULL
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        col = table.get_column("status")
        assert col.default == "'ACTIVE'"  # uppercased by parser

    def test_parse_references(self):
        sql = """
        CREATE TABLE orders (
            user_id INTEGER REFERENCES users(id)
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        assert table.get_column("user_id").references == "users.id"

    def test_parse_table_constraint_pk(self):
        sql = """
        CREATE TABLE t (
            a INTEGER,
            b INTEGER,
            PRIMARY KEY (a, b)
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        assert len(table.constraints) == 1
        assert table.constraints[0].type == "PRIMARY KEY"
        assert table.constraints[0].columns == ["a", "b"]

    def test_parse_table_constraint_fk(self):
        sql = """
        CREATE TABLE orders (
            user_id INTEGER,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        fk = table.constraints[0]
        assert fk.type == "FOREIGN KEY"
        assert fk.references_table == "users"
        assert fk.on_delete == "CASCADE"

    def test_parse_table_constraint_unique(self):
        sql = """
        CREATE TABLE t (
            a TEXT,
            b TEXT,
            UNIQUE (a, b)
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        assert len(table.constraints) == 1
        assert table.constraints[0].type == "UNIQUE"

    def test_parse_named_constraint(self):
        sql = """
        CREATE TABLE t (
            a INTEGER,
            CONSTRAINT pk_t PRIMARY KEY (a)
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        assert len(table.constraints) == 1
        assert table.constraints[0].name == "pk_t"

    def test_parse_named_fk_constraint(self):
        sql = """
        CREATE TABLE orders (
            user_id INTEGER,
            CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES users(id)
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        assert table.constraints[0].name == "fk_user"
        assert table.constraints[0].references_table == "users"

    def test_parse_named_unique_constraint(self):
        sql = """
        CREATE TABLE t (
            email TEXT,
            CONSTRAINT uq_email UNIQUE (email)
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        assert table.constraints[0].name == "uq_email"
        assert table.constraints[0].type == "UNIQUE"

    def test_parse_named_check_constraint(self):
        sql = """
        CREATE TABLE t (
            age INTEGER,
            CONSTRAINT ck_age CHECK (age >= 0)
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        assert table.constraints[0].name == "ck_age"
        assert table.constraints[0].type == "CHECK"

    def test_parse_create_index(self):
        sql = """
        CREATE TABLE users (id INTEGER, name TEXT);
        CREATE INDEX idx_name ON users (name);
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        assert len(table.indexes) == 1
        assert table.indexes[0].name == "idx_name"

    def test_parse_unique_index(self):
        sql = """
        CREATE TABLE users (id INTEGER, email TEXT);
        CREATE UNIQUE INDEX idx_email ON users (email);
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        assert table.indexes[0].unique is True

    def test_parse_multi_column_index(self):
        sql = """
        CREATE TABLE t (a TEXT, b TEXT, c TEXT);
        CREATE INDEX idx_abc ON t (a, b, c);
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        assert table.indexes[0].columns == ["a", "b", "c"]

    def test_parse_multiple_tables(self):
        sql = """
        CREATE TABLE users (
            id INTEGER PRIMARY KEY,
            name TEXT
        );
        CREATE TABLE orders (
            id INTEGER PRIMARY KEY,
            user_id INTEGER REFERENCES users(id)
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        assert len(schema.tables) == 2

    def test_parse_if_not_exists(self):
        sql = "CREATE TABLE IF NOT EXISTS t (id INTEGER);"
        parser = SQLParser()
        schema = parser.parse(sql)
        assert len(schema.tables) == 1
        assert schema.tables[0].name == "t"

    def test_parse_schema_qualified(self):
        sql = "CREATE TABLE app.users (id INTEGER);"
        parser = SQLParser()
        schema = parser.parse(sql)
        assert schema.tables[0].name == "users"
        assert schema.tables[0].schema == "app"

    def test_parse_comments_removed(self):
        sql = """
        -- This is a comment
        CREATE TABLE t (
            id INTEGER -- primary key
        );
        /* multi
           line
           comment */
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        assert len(schema.tables) == 1

    def test_parse_empty(self):
        parser = SQLParser()
        schema = parser.parse("")
        assert len(schema.tables) == 0

    def test_parse_check_constraint(self):
        sql = """
        CREATE TABLE t (
            age INTEGER,
            CHECK (age >= 0)
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        table = schema.tables[0]
        assert len(table.constraints) == 1
        assert table.constraints[0].type == "CHECK"

    def test_parse_fk_on_update(self):
        sql = """
        CREATE TABLE t (
            ref_id INTEGER,
            FOREIGN KEY (ref_id) REFERENCES other(id) ON UPDATE SET NULL
        );
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        fk = schema.tables[0].constraints[0]
        assert fk.on_update == "SET NULL"

    def test_parse_partial_index(self):
        sql = """
        CREATE TABLE t (id INTEGER, status TEXT);
        CREATE INDEX idx_active ON t (id) WHERE status = 'active';
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        idx = schema.tables[0].indexes[0]
        assert idx.condition is not None
        assert "active" in idx.condition

    def test_parse_concurrently_index(self):
        sql = """
        CREATE TABLE t (id INTEGER, name TEXT);
        CREATE INDEX CONCURRENTLY idx_name ON t (name);
        """
        parser = SQLParser()
        schema = parser.parse(sql)
        assert len(schema.tables[0].indexes) == 1

    def test_parse_file(self, tmp_path):
        sql_file = tmp_path / "schema.sql"
        sql_file.write_text("CREATE TABLE t (id INTEGER);", encoding="utf-8")
        parser = SQLParser()
        schema = parser.parse_file(str(sql_file))
        assert len(schema.tables) == 1

    def test_parse_quoted_identifiers(self):
        sql = '''CREATE TABLE "my table" ("my col" INTEGER);'''
        parser = SQLParser()
        schema = parser.parse(sql)
        # Should handle quoted identifiers
        assert len(schema.tables) >= 0  # may or may not parse complex quoted names

    def test_parse_auto_increment(self):
        sql = "CREATE TABLE t (id INTEGER AUTO_INCREMENT);"
        parser = SQLParser()
        schema = parser.parse(sql)
        if schema.tables:
            col = schema.tables[0].get_column("id")
            if col:
                assert col.auto_increment is True
