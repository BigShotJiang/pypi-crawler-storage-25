"""Tests for migration SQL linter."""

import pytest

from migra.linter import (
    BackwardCompatRule,
    DataLossRule,
    EnumRule,
    LockTableRule,
    MigrationLinter,
    TimeoutRule,
)


class TestLockTableRule:
    def test_add_not_null_without_default(self):
        rule = LockTableRule()
        issues = rule.check("ALTER TABLE t ADD COLUMN x INTEGER NOT NULL;")
        assert any("LOCK_ADD_NOTNULL" in i.code for i in issues)

    def test_add_not_null_with_default(self):
        rule = LockTableRule()
        issues = rule.check("ALTER TABLE t ADD COLUMN x INTEGER NOT NULL DEFAULT 0;")
        assert not any("LOCK_ADD_NOTNULL" in i.code for i in issues)

    def test_create_index_without_concurrently(self):
        rule = LockTableRule()
        issues = rule.check("CREATE INDEX idx ON t (x);")
        assert any("LOCK_INDEX" in i.code for i in issues)

    def test_create_index_with_concurrently(self):
        rule = LockTableRule()
        issues = rule.check("CREATE INDEX CONCURRENTLY idx ON t (x);")
        assert not any("LOCK_INDEX" in i.code for i in issues)

    def test_create_unique_index_without_concurrently(self):
        rule = LockTableRule()
        issues = rule.check("CREATE UNIQUE INDEX idx ON t (x);")
        assert any("LOCK_INDEX" in i.code for i in issues)

    def test_add_nullable_column(self):
        rule = LockTableRule()
        issues = rule.check("ALTER TABLE t ADD COLUMN x TEXT;")
        assert not any("LOCK_ADD_NOTNULL" in i.code for i in issues)


class TestDataLossRule:
    def test_drop_column(self):
        rule = DataLossRule()
        issues = rule.check("ALTER TABLE t DROP COLUMN x;")
        assert any("DATA_LOSS_DROP_COLUMN" in i.code for i in issues)

    def test_drop_table(self):
        rule = DataLossRule()
        issues = rule.check("DROP TABLE t;")
        assert any("DATA_LOSS_DROP_TABLE" in i.code for i in issues)

    def test_truncate(self):
        rule = DataLossRule()
        issues = rule.check("TRUNCATE TABLE t;")
        assert any("DATA_LOSS_TRUNCATE" in i.code for i in issues)

    def test_safe_operation(self):
        rule = DataLossRule()
        issues = rule.check("ALTER TABLE t ADD COLUMN x TEXT;")
        assert len(issues) == 0


class TestBackwardCompatRule:
    def test_rename_column(self):
        rule = BackwardCompatRule()
        issues = rule.check("ALTER TABLE t RENAME COLUMN old TO new;")
        assert any("COMPAT_RENAME" in i.code for i in issues)

    def test_rename_table(self):
        rule = BackwardCompatRule()
        issues = rule.check("ALTER TABLE old RENAME TABLE TO new;")
        assert any("COMPAT_RENAME" in i.code for i in issues)

    def test_type_change(self):
        rule = BackwardCompatRule()
        issues = rule.check("ALTER TABLE t ALTER COLUMN x TYPE BIGINT;")
        assert any("COMPAT_TYPE_CHANGE" in i.code for i in issues)

    def test_safe_alter(self):
        rule = BackwardCompatRule()
        issues = rule.check("ALTER TABLE t ADD COLUMN x TEXT;")
        assert len(issues) == 0


class TestEnumRule:
    def test_add_enum_value(self):
        rule = EnumRule()
        issues = rule.check("ALTER TYPE status ADD VALUE 'archived';")
        assert any("ENUM_ADD_VALUE" in i.code for i in issues)

    def test_no_enum(self):
        rule = EnumRule()
        issues = rule.check("ALTER TABLE t ADD COLUMN x TEXT;")
        assert len(issues) == 0


class TestTimeoutRule:
    def test_backfill_without_where(self):
        rule = TimeoutRule()
        issues = rule.check("UPDATE users SET status = 'active';")
        assert any("TIMEOUT_BACKFILL" in i.code for i in issues)

    def test_update_with_where(self):
        rule = TimeoutRule()
        issues = rule.check("UPDATE users SET status = 'active' WHERE id = 1;")
        assert not any("TIMEOUT_BACKFILL" in i.code for i in issues)

    def test_create_index_timeout(self):
        rule = TimeoutRule()
        issues = rule.check("CREATE INDEX idx ON t (x);")
        assert any("TIMEOUT_INDEX" in i.code for i in issues)


class TestMigrationLinter:
    def test_lint_safe_sql(self):
        linter = MigrationLinter()
        issues = linter.lint("ALTER TABLE t ADD COLUMN x TEXT;")
        # Should be no errors
        errors = [i for i in issues if i.severity.value == "ERROR"]
        assert len(errors) == 0

    def test_lint_dangerous_sql(self):
        linter = MigrationLinter()
        issues = linter.lint("DROP TABLE users; ALTER TABLE t DROP COLUMN x;")
        assert len(issues) > 0
        assert any(i.severity.value == "ERROR" for i in issues)

    def test_lint_file(self, tmp_path):
        sql_file = tmp_path / "migration.sql"
        sql_file.write_text("DROP TABLE users;", encoding="utf-8")
        linter = MigrationLinter()
        issues = linter.lint_file(str(sql_file))
        assert len(issues) > 0

    def test_add_custom_rule(self):
        linter = MigrationLinter()
        initial_count = len(linter.rules)
        linter.add_rule(DataLossRule())
        assert len(linter.rules) == initial_count + 1

    def test_summary(self):
        linter = MigrationLinter()
        issues = linter.lint("DROP TABLE t; CREATE INDEX idx ON t2 (x);")
        summary = linter.summary(issues)
        assert isinstance(summary, dict)
        assert sum(summary.values()) == len(issues)

    def test_lint_empty(self):
        linter = MigrationLinter()
        issues = linter.lint("")
        assert isinstance(issues, list)

    def test_lint_multiple_issues(self):
        sql = """
        DROP TABLE old_users;
        ALTER TABLE users DROP COLUMN legacy;
        CREATE INDEX idx ON users (email);
        UPDATE users SET status = 'active';
        """
        linter = MigrationLinter()
        issues = linter.lint(sql)
        assert len(issues) >= 4  # drop table, drop col, index lock, backfill
