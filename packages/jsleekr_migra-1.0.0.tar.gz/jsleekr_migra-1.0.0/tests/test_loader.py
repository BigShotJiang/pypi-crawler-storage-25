"""Tests for schema loader."""

import json
import pytest
import yaml

from migra.loader import SchemaLoader
from migra.schema import Column, Schema, Table


class TestSchemaLoader:
    @pytest.fixture
    def loader(self):
        return SchemaLoader()

    def test_load_json(self, loader, tmp_path):
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="id", type="INTEGER")]),
        ])
        path = tmp_path / "schema.json"
        path.write_text(json.dumps(schema.to_dict(), indent=2), encoding="utf-8")
        loaded = loader.load(path)
        assert len(loaded.tables) == 1
        assert loaded.tables[0].name == "t"

    def test_load_yaml(self, loader, tmp_path):
        data = {
            "name": "test",
            "tables": [
                {"name": "users", "columns": [
                    {"name": "id", "type": "INTEGER", "primary_key": True},
                    {"name": "email", "type": "VARCHAR", "max_length": 255},
                ]},
            ],
        }
        path = tmp_path / "schema.yml"
        path.write_text(yaml.dump(data), encoding="utf-8")
        loaded = loader.load(path)
        assert len(loaded.tables) == 1
        assert loaded.tables[0].name == "users"

    def test_load_yaml_extension(self, loader, tmp_path):
        data = {"name": "test", "tables": []}
        path = tmp_path / "schema.yaml"
        path.write_text(yaml.dump(data), encoding="utf-8")
        loaded = loader.load(path)
        assert loaded.name == "test"

    def test_load_sql(self, loader, tmp_path):
        sql = "CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT);"
        path = tmp_path / "schema.sql"
        path.write_text(sql, encoding="utf-8")
        loaded = loader.load(path)
        assert len(loaded.tables) == 1
        assert loaded.tables[0].name == "users"

    def test_load_ddl(self, loader, tmp_path):
        sql = "CREATE TABLE t (id INTEGER);"
        path = tmp_path / "schema.ddl"
        path.write_text(sql, encoding="utf-8")
        loaded = loader.load(path)
        assert len(loaded.tables) == 1

    def test_load_not_found(self, loader, tmp_path):
        with pytest.raises(FileNotFoundError):
            loader.load(tmp_path / "nonexistent.json")

    def test_load_unsupported(self, loader, tmp_path):
        path = tmp_path / "schema.txt"
        path.write_text("test", encoding="utf-8")
        with pytest.raises(ValueError, match="Unsupported"):
            loader.load(path)

    def test_from_json(self, loader):
        data = {"name": "test", "tables": [{"name": "t", "columns": []}]}
        schema = loader.from_json(json.dumps(data))
        assert schema.name == "test"

    def test_from_yaml(self, loader):
        data = {"name": "test", "tables": [{"name": "t", "columns": []}]}
        schema = loader.from_yaml(yaml.dump(data))
        assert schema.name == "test"

    def test_from_yaml_empty(self, loader):
        schema = loader.from_yaml("")
        assert len(schema.tables) == 0

    def test_from_sql(self, loader):
        schema = loader.from_sql("CREATE TABLE t (id INTEGER);")
        assert len(schema.tables) == 1

    def test_save_json(self, loader, tmp_path):
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="id", type="INTEGER")]),
        ])
        path = tmp_path / "out.json"
        loader.save(schema, path)
        assert path.exists()
        loaded = json.loads(path.read_text(encoding="utf-8"))
        assert loaded["tables"][0]["name"] == "t"

    def test_save_yaml(self, loader, tmp_path):
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="id", type="INTEGER")]),
        ])
        path = tmp_path / "out.yml"
        loader.save(schema, path)
        assert path.exists()
        loaded = yaml.safe_load(path.read_text(encoding="utf-8"))
        assert loaded["tables"][0]["name"] == "t"

    def test_save_explicit_format(self, loader, tmp_path):
        schema = Schema(tables=[Table(name="t")])
        path = tmp_path / "out.data"
        loader.save(schema, path, fmt="json")
        assert path.exists()
        data = json.loads(path.read_text(encoding="utf-8"))
        assert data["tables"][0]["name"] == "t"

    def test_save_unsupported(self, loader, tmp_path):
        schema = Schema()
        path = tmp_path / "out.txt"
        with pytest.raises(ValueError, match="Unsupported"):
            loader.save(schema, path)

    def test_roundtrip_json(self, loader, tmp_path):
        schema = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER", primary_key=True),
                Column(name="email", type="VARCHAR", max_length=255),
            ]),
        ])
        path = tmp_path / "schema.json"
        loader.save(schema, path)
        loaded = loader.load(path)
        assert len(loaded.tables) == 1
        assert loaded.tables[0].columns[0].name == "id"

    def test_roundtrip_yaml(self, loader, tmp_path):
        schema = Schema(tables=[
            Table(name="orders", columns=[
                Column(name="id", type="INTEGER"),
                Column(name="amount", type="DECIMAL", precision=10, scale=2),
            ]),
        ])
        path = tmp_path / "schema.yaml"
        loader.save(schema, path)
        loaded = loader.load(path)
        assert len(loaded.tables) == 1
        assert loaded.tables[0].columns[1].name == "amount"

    def test_dialect_passed_to_sql_parser(self, tmp_path):
        loader = SchemaLoader(dialect="mysql")
        sql = "CREATE TABLE t (id INTEGER);"
        path = tmp_path / "schema.sql"
        path.write_text(sql, encoding="utf-8")
        loaded = loader.load(path)
        assert len(loaded.tables) == 1
