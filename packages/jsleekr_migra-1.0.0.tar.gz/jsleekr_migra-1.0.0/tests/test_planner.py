"""Tests for migration planner and SQL generation."""

import pytest

from migra.diff import ChangeType, DiffResult, RiskLevel, SchemaDiff
from migra.planner import MigrationPlan, MigrationPlanner, PlanStep
from migra.schema import Column, Constraint, Index, Schema, Table


class TestMigrationPlanner:
    def test_plan_add_table(self):
        a = Schema()
        b = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER", primary_key=True, nullable=False),
                Column(name="email", type="VARCHAR", max_length=255),
            ]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert plan.total_steps > 0
        assert "CREATE TABLE" in plan.up_sql
        assert "DROP TABLE" in plan.down_sql

    def test_plan_drop_table(self):
        a = Schema(tables=[
            Table(name="tmp", columns=[
                Column(name="id", type="INTEGER"),
            ]),
        ])
        b = Schema()
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "DROP TABLE" in plan.up_sql

    def test_plan_add_column(self):
        a = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER"),
            ]),
        ])
        b = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER"),
                Column(name="email", type="VARCHAR", max_length=255),
            ]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "ADD COLUMN" in plan.up_sql

    def test_plan_drop_column(self):
        a = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER"),
                Column(name="old_col", type="TEXT"),
            ]),
        ])
        b = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER"),
            ]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "DROP COLUMN" in plan.up_sql

    def test_plan_alter_column_type(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="INTEGER")]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="BIGINT")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "TYPE" in plan.up_sql

    def test_plan_alter_column_nullable(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT", nullable=True)]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT", nullable=False)]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "SET NOT NULL" in plan.up_sql
        assert "DROP NOT NULL" in plan.down_sql

    def test_plan_alter_column_default(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT", default="'hello'")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "SET DEFAULT" in plan.up_sql

    def test_plan_add_index(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")],
                  indexes=[Index(name="idx_x", columns=["x"])]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "CREATE" in plan.up_sql
        assert "INDEX" in plan.up_sql
        assert "CONCURRENTLY" in plan.up_sql

    def test_plan_drop_index(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")],
                  indexes=[Index(name="idx_x", columns=["x"])]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "DROP INDEX" in plan.up_sql

    def test_plan_add_constraint(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")],
                  constraints=[Constraint(name="uq_x", type="UNIQUE", columns=["x"])]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "UNIQUE" in plan.up_sql

    def test_plan_add_fk_constraint(self):
        a = Schema(tables=[
            Table(name="orders", columns=[Column(name="user_id", type="INTEGER")]),
        ])
        b = Schema(tables=[
            Table(name="orders", columns=[Column(name="user_id", type="INTEGER")],
                  constraints=[Constraint(
                      name="fk_user", type="FOREIGN KEY", columns=["user_id"],
                      references_table="users", references_columns=["id"],
                      on_delete="CASCADE",
                  )]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "FOREIGN KEY" in plan.up_sql
        assert "REFERENCES" in plan.up_sql
        assert "CASCADE" in plan.up_sql

    def test_plan_add_check_constraint(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="age", type="INTEGER")]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="age", type="INTEGER")],
                  constraints=[Constraint(
                      name="ck_age", type="CHECK", columns=[],
                      expression="age >= 0",
                  )]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "CHECK" in plan.up_sql
        assert "age >= 0" in plan.up_sql

    def test_plan_drop_constraint(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")],
                  constraints=[Constraint(name="uq_x", type="UNIQUE", columns=["x"])]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "DROP CONSTRAINT" in plan.up_sql

    def test_plan_comment_change(self):
        a = Schema(tables=[Table(name="t", columns=[], comment="old")])
        b = Schema(tables=[Table(name="t", columns=[], comment="new")])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert "COMMENT ON TABLE" in plan.up_sql

    def test_plan_max_risk(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")]),
        ])
        b = Schema()
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert plan.max_risk == RiskLevel.DESTRUCTIVE

    def test_plan_warnings(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[
                Column(name="x", type="TEXT"),
                Column(name="y", type="INTEGER", nullable=False),
            ]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert len(plan.warnings) > 0

    def test_plan_ordering(self):
        a = Schema()
        b = Schema(tables=[
            Table(name="t", columns=[
                Column(name="id", type="INTEGER"),
                Column(name="name", type="TEXT"),
            ],
            indexes=[Index(name="idx_name", columns=["name"])],
            constraints=[Constraint(name="uq_name", type="UNIQUE", columns=["name"])]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        # Table creation should come before index/constraint creation
        types = [s.change.change_type for s in plan.steps]
        if ChangeType.ADD_TABLE in types and ChangeType.ADD_INDEX in types:
            assert types.index(ChangeType.ADD_TABLE) < types.index(ChangeType.ADD_INDEX)

    def test_unsupported_dialect(self):
        diff = SchemaDiff(source=Schema(), target=Schema())
        diff.compute()
        planner = MigrationPlanner(dialect="oracle")
        with pytest.raises(ValueError, match="Unsupported dialect"):
            planner.plan(diff)

    def test_empty_plan(self):
        diff = SchemaDiff(source=Schema(), target=Schema())
        diff.compute()
        planner = MigrationPlanner(dialect="postgresql")
        plan = planner.plan(diff)
        assert plan.total_steps == 0
        assert plan.max_risk == RiskLevel.SAFE


class TestMySQLGenerator:
    def test_create_table(self):
        a = Schema()
        b = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER", primary_key=True),
            ]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="mysql")
        plan = planner.plan(diff)
        assert "ENGINE=InnoDB" in plan.up_sql

    def test_drop_table(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="id", type="INTEGER")]),
        ])
        b = Schema()
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="mysql")
        plan = planner.plan(diff)
        assert "DROP TABLE" in plan.up_sql

    def test_add_column(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INTEGER")])])
        b = Schema(tables=[Table(name="t", columns=[
            Column(name="id", type="INTEGER"),
            Column(name="x", type="TEXT"),
        ])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="mysql")
        plan = planner.plan(diff)
        assert "ADD COLUMN" in plan.up_sql

    def test_alter_column(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="INTEGER")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="BIGINT")])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="mysql")
        plan = planner.plan(diff)
        assert "MODIFY COLUMN" in plan.up_sql

    def test_add_index(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")],
                                 indexes=[Index(name="idx_x", columns=["x"])])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="mysql")
        plan = planner.plan(diff)
        assert "CREATE" in plan.up_sql and "INDEX" in plan.up_sql

    def test_comment_change(self):
        a = Schema(tables=[Table(name="t", columns=[], comment="old")])
        b = Schema(tables=[Table(name="t", columns=[], comment="new")])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="mysql")
        plan = planner.plan(diff)
        assert "COMMENT" in plan.up_sql

    def test_backtick_quoting(self):
        a = Schema()
        b = Schema(tables=[
            Table(name="users", columns=[Column(name="id", type="INTEGER")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="mysql")
        plan = planner.plan(diff)
        assert "`users`" in plan.up_sql


class TestSQLiteGenerator:
    def test_create_table(self):
        a = Schema()
        b = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER", primary_key=True),
            ]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="sqlite")
        plan = planner.plan(diff)
        assert "CREATE TABLE" in plan.up_sql

    def test_alter_column_warning(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="INTEGER")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="sqlite")
        plan = planner.plan(diff)
        assert len(plan.warnings) > 0  # SQLite limitation warning

    def test_add_column(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="id", type="INTEGER")])])
        b = Schema(tables=[Table(name="t", columns=[
            Column(name="id", type="INTEGER"),
            Column(name="x", type="TEXT"),
        ])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="sqlite")
        plan = planner.plan(diff)
        assert "ADD COLUMN" in plan.up_sql

    def test_add_constraint_warning(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")],
                                 constraints=[Constraint(name="uq", type="UNIQUE", columns=["x"])])])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()

        planner = MigrationPlanner(dialect="sqlite")
        plan = planner.plan(diff)
        assert any("recreation" in w.lower() for w in plan.warnings)


class TestPlanStep:
    def test_to_dict(self):
        change = DiffResult(
            change_type=ChangeType.ADD_TABLE,
            table_name="t",
            description="test",
        )
        step = PlanStep(
            order=1,
            up_sql="CREATE TABLE t(id INT);",
            down_sql="DROP TABLE t;",
            description="test",
            risk_level=RiskLevel.SAFE,
            change=change,
        )
        d = step.to_dict()
        assert d["order"] == 1
        assert d["up_sql"] == "CREATE TABLE t(id INT);"
        assert d["risk_level"] == "SAFE"


class TestMigrationPlan:
    def test_up_sql(self):
        plan = MigrationPlan(steps=[
            PlanStep(order=1, up_sql="S1;", down_sql="D1;", description="",
                     risk_level=RiskLevel.SAFE,
                     change=DiffResult(change_type=ChangeType.ADD_TABLE, table_name="t")),
            PlanStep(order=2, up_sql="S2;", down_sql="D2;", description="",
                     risk_level=RiskLevel.SAFE,
                     change=DiffResult(change_type=ChangeType.ADD_TABLE, table_name="t2")),
        ])
        assert "S1;" in plan.up_sql
        assert "S2;" in plan.up_sql

    def test_down_sql_reversed(self):
        plan = MigrationPlan(steps=[
            PlanStep(order=1, up_sql="S1;", down_sql="D1;", description="",
                     risk_level=RiskLevel.SAFE,
                     change=DiffResult(change_type=ChangeType.ADD_TABLE, table_name="t")),
            PlanStep(order=2, up_sql="S2;", down_sql="D2;", description="",
                     risk_level=RiskLevel.SAFE,
                     change=DiffResult(change_type=ChangeType.ADD_TABLE, table_name="t2")),
        ])
        # Down SQL should be in reverse order
        down = plan.down_sql
        assert down.index("D2;") < down.index("D1;")

    def test_to_dict(self):
        plan = MigrationPlan()
        d = plan.to_dict()
        assert d["steps"] == []
        assert d["total_steps"] == 0
        assert d["max_risk"] == "SAFE"
