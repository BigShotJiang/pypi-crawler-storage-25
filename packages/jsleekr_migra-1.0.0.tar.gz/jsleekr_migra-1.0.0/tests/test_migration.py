"""Tests for migration management."""

import json
import os
import pytest
from pathlib import Path

from migra.migration import Migration, MigrationManager, MigrationStatus


class TestMigration:
    def test_creation(self):
        m = Migration(id="001_init", version="001", name="init")
        assert m.id == "001_init"
        assert m.status == MigrationStatus.PENDING
        assert m.checksum  # auto-generated

    def test_checksum_auto_generated(self):
        m = Migration(id="001", version="1", name="test", up_sql="CREATE TABLE t(id INT);")
        assert m.checksum
        assert len(m.checksum) == 16

    def test_checksum_validation(self):
        m = Migration(id="001", version="1", name="test", up_sql="SELECT 1;")
        assert m.validate_checksum()

    def test_checksum_mismatch(self):
        m = Migration(id="001", version="1", name="test", up_sql="SELECT 1;")
        m.up_sql = "SELECT 2;"
        assert not m.validate_checksum()

    def test_to_dict(self):
        m = Migration(
            id="001_init", version="001", name="init",
            up_sql="CREATE TABLE t(id INT);",
            down_sql="DROP TABLE t;",
            tags=["schema"],
        )
        d = m.to_dict()
        assert d["id"] == "001_init"
        assert d["up_sql"] == "CREATE TABLE t(id INT);"
        assert d["tags"] == ["schema"]

    def test_from_dict(self):
        data = {
            "id": "001_init",
            "version": "001",
            "name": "init",
            "up_sql": "CREATE TABLE t(id INT);",
            "down_sql": "DROP TABLE t;",
            "status": "PENDING",
        }
        m = Migration.from_dict(data)
        assert m.id == "001_init"
        assert m.status == MigrationStatus.PENDING

    def test_to_sql_file(self):
        m = Migration(
            id="001_init", version="001", name="init",
            up_sql="CREATE TABLE t(id INT);",
            down_sql="DROP TABLE t;",
            description="Initial migration",
        )
        content = m.to_sql_file()
        assert "-- Migration: 001_init" in content
        assert "-- +migrate Up" in content
        assert "CREATE TABLE t(id INT);" in content
        assert "-- +migrate Down" in content
        assert "DROP TABLE t;" in content

    def test_from_sql_file(self):
        content = """-- Migration: 001_init
-- Version: 001
-- Name: init
-- Description: Initial migration
-- Created: 2024-01-01T00:00:00
-- Checksum: abc123

-- +migrate Up
CREATE TABLE t(id INT);

-- +migrate Down
DROP TABLE t;
"""
        m = Migration.from_sql_file(content)
        assert m.id == "001_init"
        assert m.version == "001"
        assert m.name == "init"
        assert "CREATE TABLE" in m.up_sql
        assert "DROP TABLE" in m.down_sql

    def test_from_sql_file_with_filename(self):
        content = """-- +migrate Up
SELECT 1;
-- +migrate Down
SELECT 2;
"""
        m = Migration.from_sql_file(content, filename="002_add_users.sql")
        assert m.id == "002_add_users"
        assert m.version == "002"

    def test_roundtrip_sql_file(self):
        m1 = Migration(
            id="001_init", version="001", name="init",
            up_sql="CREATE TABLE t(id INT);",
            down_sql="DROP TABLE t;",
        )
        content = m1.to_sql_file()
        m2 = Migration.from_sql_file(content)
        assert m2.id == m1.id
        assert m2.up_sql == m1.up_sql
        assert m2.down_sql == m1.down_sql

    def test_created_at_auto(self):
        m = Migration(id="001", version="1", name="test")
        assert m.created_at  # should be auto-set

    def test_depends_on(self):
        m = Migration(id="002", version="2", name="test", depends_on=["001"])
        assert m.depends_on == ["001"]

    def test_status_values(self):
        assert MigrationStatus.PENDING.value == "PENDING"
        assert MigrationStatus.APPLIED.value == "APPLIED"
        assert MigrationStatus.ROLLED_BACK.value == "ROLLED_BACK"
        assert MigrationStatus.FAILED.value == "FAILED"
        assert MigrationStatus.SKIPPED.value == "SKIPPED"


class TestMigrationManager:
    @pytest.fixture
    def mgr(self, tmp_path):
        m = MigrationManager(tmp_path / "migrations")
        m.init()
        return m

    def test_init(self, tmp_path):
        mgr = MigrationManager(tmp_path / "migrations")
        path = mgr.init()
        assert path.exists()
        assert mgr.history_file.exists()

    def test_create_migration(self, mgr):
        m = mgr.create_migration(
            name="create users",
            up_sql="CREATE TABLE users(id INT);",
            down_sql="DROP TABLE users;",
        )
        assert m.id
        assert "create_users" in m.id
        assert m.up_sql == "CREATE TABLE users(id INT);"
        filepath = mgr.migrations_dir / f"{m.id}.sql"
        assert filepath.exists()

    def test_create_migration_with_tags(self, mgr):
        m = mgr.create_migration(
            name="test",
            tags=["schema", "v1"],
        )
        assert m.tags == ["schema", "v1"]

    def test_create_migration_with_depends(self, mgr):
        m1 = mgr.create_migration(name="first")
        m2 = mgr.create_migration(name="second", depends_on=[m1.id])
        assert m2.depends_on == [m1.id]

    def test_load_migrations(self, mgr):
        mgr.create_migration(name="m1", up_sql="SELECT 1;")
        mgr.create_migration(name="m2", up_sql="SELECT 2;")

        mgr2 = MigrationManager(mgr.migrations_dir)
        loaded = mgr2.load_migrations()
        assert len(loaded) == 2

    def test_get_pending(self, mgr):
        mgr.create_migration(name="m1")
        mgr.create_migration(name="m2")
        pending = mgr.get_pending()
        assert len(pending) == 2

    def test_get_applied(self, mgr):
        m = mgr.create_migration(name="m1")
        mgr.apply_migration(m)
        applied = mgr.get_applied()
        assert len(applied) == 1

    def test_get_migration(self, mgr):
        m = mgr.create_migration(name="test")
        found = mgr.get_migration(m.id)
        assert found is not None
        assert found.id == m.id

    def test_get_migration_not_found(self, mgr):
        assert mgr.get_migration("nonexistent") is None

    def test_apply_migration(self, mgr):
        m = mgr.create_migration(name="test", up_sql="SELECT 1;")
        result = mgr.apply_migration(m)
        assert result["status"] == "applied"
        assert m.status == MigrationStatus.APPLIED
        assert m.applied_at is not None

    def test_apply_already_applied(self, mgr):
        m = mgr.create_migration(name="test")
        mgr.apply_migration(m)
        result = mgr.apply_migration(m)
        assert result["status"] == "already_applied"

    def test_apply_dry_run(self, mgr):
        m = mgr.create_migration(name="test", up_sql="SELECT 1;")
        result = mgr.apply_migration(m, dry_run=True)
        assert result["status"] == "dry_run"
        assert m.status == MigrationStatus.PENDING

    def test_apply_blocked_by_dependency(self, mgr):
        m1 = mgr.create_migration(name="first")
        m2 = mgr.create_migration(name="second", depends_on=[m1.id])
        result = mgr.apply_migration(m2)
        assert result["status"] == "blocked"

    def test_rollback_migration(self, mgr):
        m = mgr.create_migration(name="test", down_sql="DROP TABLE t;")
        mgr.apply_migration(m)
        result = mgr.rollback_migration(m)
        assert result["status"] == "rolled_back"
        assert m.status == MigrationStatus.ROLLED_BACK

    def test_rollback_not_applied(self, mgr):
        m = mgr.create_migration(name="test")
        result = mgr.rollback_migration(m)
        assert result["status"] == "not_applied"

    def test_rollback_no_down_sql(self, mgr):
        m = mgr.create_migration(name="test", down_sql="")
        mgr.apply_migration(m)
        result = mgr.rollback_migration(m)
        assert result["status"] == "no_rollback"

    def test_rollback_dry_run(self, mgr):
        m = mgr.create_migration(name="test", down_sql="DROP TABLE t;")
        mgr.apply_migration(m)
        result = mgr.rollback_migration(m, dry_run=True)
        assert result["status"] == "dry_run"
        assert m.status == MigrationStatus.APPLIED

    def test_apply_all(self, mgr):
        mgr.create_migration(name="m1", up_sql="SELECT 1;")
        mgr.create_migration(name="m2", up_sql="SELECT 2;")
        results = mgr.apply_all()
        assert len(results) == 2
        assert all(r["status"] == "applied" for r in results)

    def test_apply_all_dry_run(self, mgr):
        mgr.create_migration(name="m1", up_sql="SELECT 1;")
        results = mgr.apply_all(dry_run=True)
        assert len(results) == 1
        assert results[0]["status"] == "dry_run"

    def test_rollback_last(self, mgr):
        m1 = mgr.create_migration(name="m1", down_sql="D1;")
        m2 = mgr.create_migration(name="m2", down_sql="D2;")
        mgr.apply_all()
        results = mgr.rollback_last(count=1)
        assert len(results) == 1
        assert results[0]["status"] == "rolled_back"

    def test_rollback_last_multiple(self, mgr):
        m1 = mgr.create_migration(name="m1", down_sql="D1;")
        m2 = mgr.create_migration(name="m2", down_sql="D2;")
        mgr.apply_all()
        results = mgr.rollback_last(count=2)
        assert len(results) == 2

    def test_validate_checksums(self, mgr):
        m = mgr.create_migration(name="test", up_sql="SELECT 1;")
        mgr.apply_migration(m)
        issues = mgr.validate_checksums()
        assert len(issues) == 0

    def test_validate_checksums_mismatch(self, mgr):
        m = mgr.create_migration(name="test", up_sql="SELECT 1;")
        mgr.apply_migration(m)
        m.up_sql = "SELECT 2;"  # tamper
        issues = mgr.validate_checksums()
        assert len(issues) == 1
        assert issues[0]["issue"] == "checksum_mismatch"

    def test_status_report(self, mgr):
        m1 = mgr.create_migration(name="m1")
        m2 = mgr.create_migration(name="m2")
        mgr.apply_migration(m1)
        report = mgr.status_report()
        assert report["total"] == 2
        assert report["applied"] == 1
        assert report["pending"] == 1

    def test_history_persistence(self, mgr):
        m = mgr.create_migration(name="test", up_sql="SELECT 1;")
        mgr.apply_migration(m)

        # Reload
        mgr2 = MigrationManager(mgr.migrations_dir)
        mgr2.load_migrations()
        applied = mgr2.get_applied()
        assert len(applied) == 1
        assert applied[0].status == MigrationStatus.APPLIED

    def test_init_idempotent(self, tmp_path):
        mgr = MigrationManager(tmp_path / "migrations")
        mgr.init()
        mgr.init()  # should not fail

    def test_load_empty_dir(self, tmp_path):
        mgr = MigrationManager(tmp_path / "migrations")
        mgr.init()
        migrations = mgr.load_migrations()
        assert len(migrations) == 0

    def test_load_nonexistent_dir(self, tmp_path):
        mgr = MigrationManager(tmp_path / "nonexistent")
        migrations = mgr.load_migrations()
        assert len(migrations) == 0

    def test_create_migration_description(self, mgr):
        m = mgr.create_migration(name="test", description="Test migration")
        assert m.description == "Test migration"

    def test_apply_all_stops_on_blocked(self, mgr):
        m1 = mgr.create_migration(name="m1")
        m2 = mgr.create_migration(name="m2", depends_on=[m1.id])
        # Don't apply m1, try to apply all
        # m1 should succeed, m2 should also succeed since m1 is applied first
        results = mgr.apply_all()
        assert len(results) == 2
