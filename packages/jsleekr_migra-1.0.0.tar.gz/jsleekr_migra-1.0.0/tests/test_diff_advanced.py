"""Advanced diff tests."""

import pytest
from migra.diff import ChangeType, RiskLevel, SchemaDiff
from migra.schema import Column, Constraint, Index, Schema, Table


class TestDiffMultiTable:
    def test_diff_three_tables(self):
        a = Schema(tables=[
            Table(name="t1", columns=[Column(name="id", type="INTEGER")]),
            Table(name="t2", columns=[Column(name="id", type="INTEGER")]),
            Table(name="t3", columns=[Column(name="id", type="INTEGER")]),
        ])
        b = Schema(tables=[
            Table(name="t1", columns=[
                Column(name="id", type="INTEGER"),
                Column(name="x", type="TEXT"),
            ]),
            Table(name="t3", columns=[Column(name="id", type="INTEGER")]),
            Table(name="t4", columns=[Column(name="id", type="INTEGER")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        types = {c.change_type for c in changes}
        assert ChangeType.ADD_COLUMN in types  # t1.x
        assert ChangeType.DROP_TABLE in types  # t2
        assert ChangeType.ADD_TABLE in types  # t4

    def test_diff_only_indexes_changed(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="id", type="INTEGER")],
                  indexes=[Index(name="idx_a", columns=["id"])]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="id", type="INTEGER")],
                  indexes=[Index(name="idx_b", columns=["id"])]),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        types = {c.change_type for c in changes}
        assert ChangeType.ADD_INDEX in types
        assert ChangeType.DROP_INDEX in types

    def test_diff_only_constraints_changed(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")],
                  constraints=[Constraint(name="c1", type="UNIQUE", columns=["x"])]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")],
                  constraints=[Constraint(name="c2", type="CHECK", columns=[], expression="x IS NOT NULL")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        types = {c.change_type for c in changes}
        assert ChangeType.ADD_CONSTRAINT in types
        assert ChangeType.DROP_CONSTRAINT in types


class TestDiffColumnDetails:
    def test_unique_change(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT", unique=False)])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT", unique=True)])])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 1
        assert "unique" in changes[0].description

    def test_reference_change(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="INTEGER")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="INTEGER", references="other.id")])])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 1

    def test_auto_increment_change(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="INTEGER")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="INTEGER", auto_increment=True)])])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 1

    def test_precision_change(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="DECIMAL", precision=10)])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="DECIMAL", precision=15)])])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 1
        assert "precision" in changes[0].description

    def test_scale_change(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="DECIMAL", precision=10, scale=2)])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="DECIMAL", precision=10, scale=4)])])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 1

    def test_multiple_column_changes(self):
        a = Schema(tables=[Table(name="t", columns=[
            Column(name="a", type="INTEGER"),
            Column(name="b", type="TEXT"),
            Column(name="c", type="BOOLEAN"),
        ])])
        b = Schema(tables=[Table(name="t", columns=[
            Column(name="a", type="BIGINT"),  # type change
            Column(name="b", type="TEXT"),  # no change
            Column(name="d", type="TEXT"),  # new (c dropped)
        ])])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        types = [c.change_type for c in changes]
        assert ChangeType.ALTER_COLUMN in types
        assert ChangeType.ADD_COLUMN in types
        assert ChangeType.DROP_COLUMN in types

    def test_nullable_to_not_null_no_default(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT", nullable=True)])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT", nullable=False)])])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert changes[0].risk_level == RiskLevel.HIGH

    def test_max_length_increase_safe(self):
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="VARCHAR", max_length=100)])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="VARCHAR", max_length=255)])])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        # Increase is generally safe (LOW risk for alter column)
        assert changes[0].risk_level in (RiskLevel.LOW, RiskLevel.MEDIUM)


class TestDiffSorting:
    def test_changes_sorted_by_table(self):
        a = Schema(tables=[
            Table(name="alpha", columns=[Column(name="id", type="INTEGER")]),
            Table(name="beta", columns=[Column(name="id", type="INTEGER")]),
        ])
        b = Schema()
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        tables = [c.table_name for c in changes]
        assert tables == sorted(tables)
