"""Advanced snapshot tests."""

import json
import time
import pytest

from migra.schema import Column, Schema, Table
from migra.snapshot import Snapshot, SnapshotManager


class TestSnapshotAdvanced:
    def test_snapshot_metadata(self):
        schema = Schema(tables=[Table(name="t")])
        snap = Snapshot(id="test", schema=schema, metadata={"env": "prod", "version": "1.0"})
        d = snap.to_dict()
        assert d["metadata"]["env"] == "prod"
        loaded = Snapshot.from_dict(d)
        assert loaded.metadata["version"] == "1.0"

    def test_snapshot_label_roundtrip(self):
        data = {
            "id": "test",
            "schema": {"name": "db", "tables": []},
            "label": "v1.0.0",
            "created_at": "2024-01-01",
        }
        snap = Snapshot.from_dict(data)
        assert snap.label == "v1.0.0"
        assert snap.created_at == "2024-01-01"


class TestSnapshotManagerAdvanced:
    @pytest.fixture
    def mgr(self, tmp_path):
        return SnapshotManager(tmp_path / "snapshots")

    def test_multiple_snapshots_ordered(self, mgr):
        for i in range(5):
            s = Schema(tables=[Table(name=f"t{i}")])
            mgr.save(s, label=f"v{i}")

        snaps = mgr.list_snapshots()
        assert len(snaps) == 5

    def test_drift_after_table_add(self, mgr):
        v1 = Schema(tables=[Table(name="users")])
        mgr.save(v1)

        v2 = Schema(tables=[Table(name="users"), Table(name="posts")])
        assert mgr.has_drift(v2)
        details = mgr.drift_details(v2)
        assert details["changes"] > 0
        assert "ADD_TABLE" in str(details["summary"])

    def test_drift_after_table_drop(self, mgr):
        v1 = Schema(tables=[Table(name="users"), Table(name="old_data")])
        mgr.save(v1)

        v2 = Schema(tables=[Table(name="users")])
        assert mgr.has_drift(v2)
        details = mgr.drift_details(v2)
        assert details["max_risk"] == "DESTRUCTIVE"

    def test_drift_after_column_change(self, mgr):
        v1 = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="INTEGER")]),
        ])
        mgr.save(v1)

        v2 = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="BIGINT")]),
        ])
        assert mgr.has_drift(v2)

    def test_no_drift_same_schema(self, mgr):
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="id", type="INTEGER")]),
        ])
        mgr.save(schema)
        assert not mgr.has_drift(schema)

    def test_delete_all_snapshots(self, mgr):
        for i in range(3):
            mgr.save(Schema(tables=[Table(name=f"t{i}")]), label=f"v{i}")

        snaps = mgr.list_snapshots()
        for snap in snaps:
            mgr.delete(snap.id)

        assert len(mgr.list_snapshots()) == 0
        assert mgr.latest() is None

    def test_snapshot_fingerprint_matches_schema(self, mgr):
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="id", type="INTEGER")]),
        ])
        snap = mgr.save(schema)
        assert snap.fingerprint() == schema.fingerprint()

    def test_corrupted_snapshot_file(self, mgr):
        mgr.init()
        bad_file = mgr.snapshots_dir / "bad.json"
        bad_file.write_text("not valid json", encoding="utf-8")
        snaps = mgr.list_snapshots()
        # Should skip corrupted files
        assert len(snaps) == 0
