"""Tests for schema diff engine."""

import pytest

from migra.diff import ChangeType, DiffResult, RiskLevel, SchemaDiff
from migra.schema import Column, Constraint, Index, Schema, Table


class TestDiffResult:
    def test_creation(self):
        result = DiffResult(
            change_type=ChangeType.ADD_TABLE,
            table_name="users",
            description="Create table users",
        )
        assert result.change_type == ChangeType.ADD_TABLE
        assert result.table_name == "users"

    def test_qualified_table(self):
        result = DiffResult(
            change_type=ChangeType.ADD_TABLE,
            table_name="users",
            table_schema="app",
        )
        assert result.qualified_table == "app.users"

    def test_to_dict(self):
        result = DiffResult(
            change_type=ChangeType.ADD_COLUMN,
            table_name="users",
            object_name="email",
            risk_level=RiskLevel.SAFE,
            description="Add email",
        )
        d = result.to_dict()
        assert d["change_type"] == "ADD_COLUMN"
        assert d["object_name"] == "email"

    def test_str(self):
        result = DiffResult(
            change_type=ChangeType.DROP_TABLE,
            table_name="tmp",
            risk_level=RiskLevel.DESTRUCTIVE,
            description="Drop table tmp",
        )
        s = str(result)
        assert "DESTRUCTIVE" in s
        assert "DROP_TABLE" in s


class TestSchemaDiff:
    def _schema_a(self):
        return Schema(tables=[
            Table(
                name="users",
                columns=[
                    Column(name="id", type="INTEGER", primary_key=True, nullable=False),
                    Column(name="email", type="VARCHAR", max_length=255),
                    Column(name="name", type="TEXT"),
                ],
                indexes=[
                    Index(name="idx_email", columns=["email"], unique=True),
                ],
            ),
        ])

    def _schema_b(self):
        return Schema(tables=[
            Table(
                name="users",
                columns=[
                    Column(name="id", type="INTEGER", primary_key=True, nullable=False),
                    Column(name="email", type="VARCHAR", max_length=255),
                    Column(name="name", type="TEXT"),
                    Column(name="age", type="INTEGER"),
                ],
                indexes=[
                    Index(name="idx_email", columns=["email"], unique=True),
                ],
            ),
        ])

    def test_no_changes(self):
        a = self._schema_a()
        b = self._schema_a()
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 0
        assert not diff.has_changes

    def test_add_column(self):
        diff = SchemaDiff(source=self._schema_a(), target=self._schema_b())
        changes = diff.compute()
        add_cols = [c for c in changes if c.change_type == ChangeType.ADD_COLUMN]
        assert len(add_cols) == 1
        assert add_cols[0].object_name == "age"

    def test_drop_column(self):
        diff = SchemaDiff(source=self._schema_b(), target=self._schema_a())
        changes = diff.compute()
        drop_cols = [c for c in changes if c.change_type == ChangeType.DROP_COLUMN]
        assert len(drop_cols) == 1
        assert drop_cols[0].object_name == "age"
        assert drop_cols[0].risk_level == RiskLevel.DESTRUCTIVE

    def test_add_table(self):
        a = Schema()
        b = Schema(tables=[
            Table(name="users", columns=[Column(name="id", type="INTEGER")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.ADD_TABLE
        assert changes[0].risk_level == RiskLevel.SAFE

    def test_drop_table(self):
        a = Schema(tables=[
            Table(name="users", columns=[Column(name="id", type="INTEGER")]),
        ])
        b = Schema()
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.DROP_TABLE
        assert changes[0].risk_level == RiskLevel.DESTRUCTIVE

    def test_alter_column_type(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="INTEGER")]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="BIGINT")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.ALTER_COLUMN
        assert changes[0].risk_level == RiskLevel.MEDIUM

    def test_alter_column_nullable(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT", nullable=True)]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT", nullable=False)]),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 1
        assert changes[0].risk_level == RiskLevel.HIGH

    def test_alter_column_default(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT", default=None)]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT", default="'hello'")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 1

    def test_add_index(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")]),
        ])
        b = Schema(tables=[
            Table(
                name="t",
                columns=[Column(name="x", type="TEXT")],
                indexes=[Index(name="idx_x", columns=["x"])],
            ),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.ADD_INDEX

    def test_drop_index(self):
        a = Schema(tables=[
            Table(
                name="t",
                columns=[Column(name="x", type="TEXT")],
                indexes=[Index(name="idx_x", columns=["x"])],
            ),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.DROP_INDEX

    def test_alter_index(self):
        a = Schema(tables=[
            Table(
                name="t",
                columns=[Column(name="x", type="TEXT")],
                indexes=[Index(name="idx_x", columns=["x"])],
            ),
        ])
        b = Schema(tables=[
            Table(
                name="t",
                columns=[Column(name="x", type="TEXT")],
                indexes=[Index(name="idx_x", columns=["x"], unique=True)],
            ),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.ALTER_INDEX

    def test_add_constraint(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")]),
        ])
        b = Schema(tables=[
            Table(
                name="t",
                columns=[Column(name="x", type="TEXT")],
                constraints=[
                    Constraint(name="uq_x", type="UNIQUE", columns=["x"]),
                ],
            ),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.ADD_CONSTRAINT

    def test_drop_constraint(self):
        a = Schema(tables=[
            Table(
                name="t",
                columns=[Column(name="x", type="TEXT")],
                constraints=[
                    Constraint(name="uq_x", type="UNIQUE", columns=["x"]),
                ],
            ),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.DROP_CONSTRAINT

    def test_comment_change(self):
        a = Schema(tables=[
            Table(name="t", columns=[], comment="old"),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[], comment="new"),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.CHANGE_COMMENT

    def test_has_destructive_changes(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")]),
        ])
        b = Schema()
        diff = SchemaDiff(source=a, target=b)
        diff.compute()
        assert diff.has_destructive_changes

    def test_max_risk(self):
        diff = SchemaDiff(source=self._schema_a(), target=self._schema_b())
        diff.compute()
        assert diff.max_risk in list(RiskLevel)

    def test_max_risk_empty(self):
        diff = SchemaDiff(source=self._schema_a(), target=self._schema_a())
        assert diff.max_risk == RiskLevel.SAFE

    def test_summary(self):
        diff = SchemaDiff(source=self._schema_a(), target=self._schema_b())
        diff.compute()
        summary = diff.summary()
        assert "ADD_COLUMN" in summary

    def test_filter_by_risk(self):
        a = Schema(tables=[
            Table(name="t", columns=[
                Column(name="x", type="TEXT"),
                Column(name="y", type="INTEGER"),
            ]),
        ])
        b = Schema()
        diff = SchemaDiff(source=a, target=b)
        diff.compute()
        destructive = diff.filter_by_risk(RiskLevel.DESTRUCTIVE)
        assert len(destructive) > 0

    def test_filter_by_table(self):
        a = Schema(tables=[
            Table(name="t1", columns=[Column(name="x", type="TEXT")]),
            Table(name="t2", columns=[Column(name="y", type="TEXT")]),
        ])
        b = Schema(tables=[
            Table(name="t1", columns=[Column(name="x", type="TEXT")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()
        t2_changes = diff.filter_by_table("t2")
        assert len(t2_changes) == 1

    def test_affected_tables(self):
        a = Schema(tables=[
            Table(name="t1", columns=[Column(name="x", type="TEXT")]),
        ])
        b = Schema(tables=[
            Table(name="t1", columns=[
                Column(name="x", type="TEXT"),
                Column(name="y", type="INTEGER"),
            ]),
            Table(name="t2", columns=[Column(name="z", type="TEXT")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        diff.compute()
        affected = diff.affected_tables()
        assert "t1" in affected
        assert "t2" in affected

    def test_compute_idempotent(self):
        diff = SchemaDiff(source=self._schema_a(), target=self._schema_b())
        changes1 = diff.compute()
        changes2 = diff.compute()
        assert len(changes1) == len(changes2)

    def test_multiple_table_changes(self):
        a = Schema(tables=[
            Table(name="t1", columns=[Column(name="a", type="TEXT")]),
            Table(name="t2", columns=[Column(name="b", type="TEXT")]),
        ])
        b = Schema(tables=[
            Table(name="t1", columns=[
                Column(name="a", type="TEXT"),
                Column(name="c", type="INTEGER"),
            ]),
            Table(name="t3", columns=[Column(name="d", type="TEXT")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        types = {c.change_type for c in changes}
        assert ChangeType.ADD_TABLE in types
        assert ChangeType.DROP_TABLE in types
        assert ChangeType.ADD_COLUMN in types

    def test_add_not_null_column_high_risk(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[
                Column(name="x", type="TEXT"),
                Column(name="y", type="INTEGER", nullable=False),
            ]),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert changes[0].risk_level == RiskLevel.HIGH

    def test_alter_column_max_length_decrease(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="VARCHAR", max_length=255)]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="VARCHAR", max_length=100)]),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert changes[0].risk_level == RiskLevel.HIGH

    def test_alter_column_primary_key_change(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="INTEGER", primary_key=False)]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="INTEGER", primary_key=True)]),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert changes[0].risk_level == RiskLevel.HIGH

    def test_add_pk_constraint_medium_risk(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")],
                  constraints=[Constraint(name="pk_x", type="PRIMARY KEY", columns=["x"])]),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert changes[0].risk_level == RiskLevel.MEDIUM

    def test_alter_constraint(self):
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")],
                  constraints=[Constraint(name="ck", type="CHECK", columns=[], expression="x > 0")]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")],
                  constraints=[Constraint(name="ck", type="CHECK", columns=[], expression="x > 10")]),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.ALTER_CONSTRAINT

    def test_schema_with_different_schemas(self):
        a = Schema(tables=[
            Table(name="users", schema="v1"),
        ])
        b = Schema(tables=[
            Table(name="users", schema="v2"),
        ])
        diff = SchemaDiff(source=a, target=b)
        changes = diff.compute()
        assert len(changes) == 2  # drop v1.users, add v2.users


class TestChangeType:
    def test_values(self):
        assert ChangeType.ADD_TABLE.value == "ADD_TABLE"
        assert ChangeType.DROP_TABLE.value == "DROP_TABLE"
        assert ChangeType.ALTER_COLUMN.value == "ALTER_COLUMN"


class TestRiskLevel:
    def test_values(self):
        assert RiskLevel.SAFE.value == "SAFE"
        assert RiskLevel.DESTRUCTIVE.value == "DESTRUCTIVE"
