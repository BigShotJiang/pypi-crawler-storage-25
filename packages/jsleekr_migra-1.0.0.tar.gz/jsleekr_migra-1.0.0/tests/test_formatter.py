"""Tests for SQL formatter."""

import pytest
from migra.formatter import SQLFormatter


class TestSQLFormatter:
    @pytest.fixture
    def fmt(self):
        return SQLFormatter()

    def test_format_empty(self, fmt):
        assert fmt.format("") == ""
        assert fmt.format("  ") == "  "

    def test_format_simple_statement(self, fmt):
        result = fmt.format("select 1")
        assert result.endswith(";")

    def test_format_create_table(self, fmt):
        sql = "CREATE TABLE users (id INTEGER, name TEXT, email VARCHAR(255))"
        result = fmt.format_create_table(sql)
        assert "CREATE TABLE" in result
        assert "\n" in result
        assert result.endswith(";")

    def test_format_create_table_with_suffix(self, fmt):
        sql = "CREATE TABLE t (id INT) ENGINE=InnoDB"
        result = fmt.format_create_table(sql)
        assert "ENGINE=InnoDB" in result

    def test_format_preserves_indent(self, fmt):
        sql = "CREATE TABLE t (id INT, name TEXT)"
        result = fmt.format_create_table(sql)
        assert "    " in result  # default indent

    def test_custom_indent(self):
        fmt = SQLFormatter(indent="  ")
        sql = "CREATE TABLE t (id INT, name TEXT)"
        result = fmt.format_create_table(sql)
        lines = result.split("\n")
        assert any(line.startswith("  ") for line in lines)

    def test_uppercase_keywords(self, fmt):
        sql = "create table users (id integer primary key)"
        result = fmt.format(sql)
        assert "CREATE" in result

    def test_no_uppercase(self):
        fmt = SQLFormatter(uppercase_keywords=False)
        sql = "create table t (id int)"
        result = fmt.format(sql)
        # Should preserve lowercase
        assert "create" in result or "CREATE" in result  # format_create_table may uppercase

    def test_add_semicolons(self, fmt):
        sql = "SELECT 1;\nSELECT 2"
        result = fmt.add_semicolons(sql)
        assert result.count(";") >= 2

    def test_add_semicolons_already_present(self, fmt):
        sql = "SELECT 1;\n\nSELECT 2;"
        result = fmt.add_semicolons(sql)
        assert result.count(";") == 2

    def test_remove_comments_line(self, fmt):
        sql = "SELECT 1; -- this is a comment\nSELECT 2;"
        result = fmt.remove_comments(sql)
        assert "--" not in result
        assert "SELECT 1" in result

    def test_remove_comments_block(self, fmt):
        sql = "SELECT 1; /* block comment */ SELECT 2;"
        result = fmt.remove_comments(sql)
        assert "/*" not in result
        assert "*/" not in result

    def test_remove_comments_multiline_block(self, fmt):
        sql = "SELECT 1;\n/* multi\nline\ncomment */\nSELECT 2;"
        result = fmt.remove_comments(sql)
        assert "multi" not in result

    def test_format_multiple_statements(self, fmt):
        sql = "CREATE TABLE t1 (id INT); CREATE TABLE t2 (id INT)"
        result = fmt.format(sql)
        assert "t1" in result
        assert "t2" in result
        assert "\n\n" in result

    def test_format_alter_table(self, fmt):
        sql = "alter table users add column email text"
        result = fmt.format(sql)
        assert "ALTER" in result
        assert result.endswith(";")

    def test_split_column_defs_with_parens(self, fmt):
        body = "id INT, name VARCHAR(255), price DECIMAL(10, 2)"
        parts = fmt._split_column_defs(body)
        assert len(parts) == 3

    def test_remove_comments_preserves_line_comment_in_string(self, fmt):
        sql = "INSERT INTO t VALUES ('value -- not a comment')"
        result = fmt.remove_comments(sql)
        assert "-- not a comment" in result
        assert result.strip() == sql.strip()

    def test_remove_comments_preserves_block_comment_in_string(self, fmt):
        sql = "INSERT INTO t VALUES ('value /* not a comment */ end')"
        result = fmt.remove_comments(sql)
        assert "/* not a comment */" in result
        assert result.strip() == sql.strip()

    def test_remove_comments_mixed_real_and_string(self, fmt):
        sql = "SELECT 'a -- b' FROM t -- real comment"
        result = fmt.remove_comments(sql)
        assert "'a -- b'" in result
        assert "real comment" not in result

    def test_format_non_create_table(self, fmt):
        sql = "DROP TABLE IF EXISTS users"
        result = fmt.format(sql)
        assert "DROP" in result
        assert result.endswith(";")
