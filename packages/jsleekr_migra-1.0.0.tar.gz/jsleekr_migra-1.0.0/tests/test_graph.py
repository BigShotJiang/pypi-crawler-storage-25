"""Tests for migration dependency graph."""

import pytest

from migra.graph import MigrationGraph, MigrationNode
from migra.migration import Migration, MigrationStatus


def _m(mid: str, depends: list[str] = None, status: str = "PENDING") -> Migration:
    return Migration(
        id=mid, version="1", name=mid,
        depends_on=depends or [],
        status=MigrationStatus(status),
    )


class TestMigrationGraph:
    def test_add_migration(self):
        g = MigrationGraph()
        g.add_migration(_m("001"))
        assert "001" in g
        assert len(g) == 1

    def test_remove_migration(self):
        g = MigrationGraph()
        g.add_migration(_m("001"))
        m = g.remove_migration("001")
        assert m is not None
        assert "001" not in g

    def test_remove_not_found(self):
        g = MigrationGraph()
        assert g.remove_migration("nope") is None

    def test_execution_order_simple(self):
        g = MigrationGraph()
        g.add_migration(_m("001"))
        g.add_migration(_m("002", ["001"]))
        g.add_migration(_m("003", ["002"]))
        order = g.get_execution_order()
        ids = [m.id for m in order]
        assert ids.index("001") < ids.index("002")
        assert ids.index("002") < ids.index("003")

    def test_execution_order_diamond(self):
        g = MigrationGraph()
        g.add_migration(_m("001"))
        g.add_migration(_m("002", ["001"]))
        g.add_migration(_m("003", ["001"]))
        g.add_migration(_m("004", ["002", "003"]))
        order = g.get_execution_order()
        ids = [m.id for m in order]
        assert ids.index("001") < ids.index("002")
        assert ids.index("001") < ids.index("003")
        assert ids.index("002") < ids.index("004")
        assert ids.index("003") < ids.index("004")

    def test_execution_order_no_deps(self):
        g = MigrationGraph()
        g.add_migration(_m("a"))
        g.add_migration(_m("b"))
        g.add_migration(_m("c"))
        order = g.get_execution_order()
        assert len(order) == 3

    def test_execution_order_empty(self):
        g = MigrationGraph()
        assert g.get_execution_order() == []

    def test_circular_dependency(self):
        g = MigrationGraph()
        g.add_migration(_m("a", ["b"]))
        g.add_migration(_m("b", ["a"]))
        with pytest.raises(ValueError, match="Circular dependency"):
            g.get_execution_order()

    def test_rollback_order(self):
        g = MigrationGraph()
        g.add_migration(_m("001"))
        g.add_migration(_m("002", ["001"]))
        order = g.get_rollback_order()
        ids = [m.id for m in order]
        assert ids.index("002") < ids.index("001")

    def test_get_dependencies(self):
        g = MigrationGraph()
        g.add_migration(_m("001"))
        g.add_migration(_m("002", ["001"]))
        g.add_migration(_m("003", ["002"]))
        deps = g.get_dependencies("003")
        assert "001" in deps
        assert "002" in deps
        assert "003" not in deps

    def test_get_dependencies_none(self):
        g = MigrationGraph()
        g.add_migration(_m("001"))
        deps = g.get_dependencies("001")
        assert len(deps) == 0

    def test_get_dependencies_not_found(self):
        g = MigrationGraph()
        assert g.get_dependencies("nope") == set()

    def test_get_dependents(self):
        g = MigrationGraph()
        g.add_migration(_m("001"))
        g.add_migration(_m("002", ["001"]))
        g.add_migration(_m("003", ["002"]))
        deps = g.get_dependents("001")
        assert "002" in deps
        assert "003" in deps

    def test_get_dependents_none(self):
        g = MigrationGraph()
        g.add_migration(_m("001"))
        assert len(g.get_dependents("001")) == 0

    def test_get_dependents_not_found(self):
        g = MigrationGraph()
        assert g.get_dependents("nope") == set()

    def test_safe_to_rollback(self):
        g = MigrationGraph()
        g.add_migration(_m("001", status="APPLIED"))
        g.add_migration(_m("002", ["001"], status="PENDING"))
        safe, blockers = g.is_safe_to_rollback("001")
        assert safe is True

    def test_not_safe_to_rollback(self):
        g = MigrationGraph()
        g.add_migration(_m("001", status="APPLIED"))
        g.add_migration(_m("002", ["001"], status="APPLIED"))
        safe, blockers = g.is_safe_to_rollback("001")
        assert safe is False
        assert "002" in blockers

    def test_find_roots(self):
        g = MigrationGraph()
        g.add_migration(_m("001"))
        g.add_migration(_m("002", ["001"]))
        g.add_migration(_m("003"))
        roots = g.find_roots()
        assert "001" in roots
        assert "003" in roots
        assert "002" not in roots

    def test_find_leaves(self):
        g = MigrationGraph()
        g.add_migration(_m("001"))
        g.add_migration(_m("002", ["001"]))
        leaves = g.find_leaves()
        assert "002" in leaves
        assert "001" not in leaves

    def test_validate_ok(self):
        g = MigrationGraph()
        g.add_migration(_m("001"))
        g.add_migration(_m("002", ["001"]))
        issues = g.validate()
        assert len(issues) == 0

    def test_validate_missing_dep(self):
        g = MigrationGraph()
        g.add_migration(_m("002", ["001"]))
        issues = g.validate()
        assert any("missing" in i.lower() for i in issues)

    def test_validate_cycle(self):
        g = MigrationGraph()
        g.add_migration(_m("a", ["b"]))
        g.add_migration(_m("b", ["a"]))
        issues = g.validate()
        assert any("circular" in i.lower() for i in issues)

    def test_subgraph(self):
        g = MigrationGraph()
        g.add_migration(_m("001"))
        g.add_migration(_m("002", ["001"]))
        g.add_migration(_m("003", ["002"]))
        sub = g.subgraph({"001", "002"})
        assert len(sub) == 2
        assert "003" not in sub

    def test_len(self):
        g = MigrationGraph()
        assert len(g) == 0
        g.add_migration(_m("001"))
        assert len(g) == 1

    def test_contains(self):
        g = MigrationGraph()
        g.add_migration(_m("001"))
        assert "001" in g
        assert "002" not in g

    def test_remove_cleans_references(self):
        g = MigrationGraph()
        g.add_migration(_m("001"))
        g.add_migration(_m("002", ["001"]))
        g.remove_migration("001")
        # 002 should still be in graph but dep on 001 cleaned
        assert "002" in g


class TestMigrationNode:
    def test_id_property(self):
        m = _m("test_id")
        node = MigrationNode(migration=m)
        assert node.id == "test_id"
