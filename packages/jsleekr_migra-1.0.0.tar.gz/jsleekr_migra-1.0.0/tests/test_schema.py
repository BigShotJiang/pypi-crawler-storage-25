"""Tests for schema models."""

import json
import pytest

from migra.schema import (
    Column, ColumnType, Constraint, ConstraintType, Index, IndexType,
    Schema, Table,
)


class TestColumn:
    def test_basic_creation(self):
        col = Column(name="id", type="INTEGER")
        assert col.name == "id"
        assert col.type == "INTEGER"
        assert col.nullable is True
        assert col.default is None
        assert col.primary_key is False

    def test_full_creation(self):
        col = Column(
            name="email",
            type="VARCHAR",
            nullable=False,
            default="''",
            unique=True,
            max_length=255,
            comment="User email",
        )
        assert col.name == "email"
        assert col.nullable is False
        assert col.unique is True
        assert col.max_length == 255

    def test_to_dict(self):
        col = Column(name="id", type="INTEGER", primary_key=True, nullable=False)
        d = col.to_dict()
        assert d["name"] == "id"
        assert d["type"] == "INTEGER"
        assert d["nullable"] is False
        assert d["primary_key"] is True

    def test_from_dict(self):
        data = {"name": "age", "type": "INTEGER", "nullable": True}
        col = Column.from_dict(data)
        assert col.name == "age"
        assert col.type == "INTEGER"
        assert col.nullable is True

    def test_from_dict_defaults(self):
        data = {"name": "x", "type": "TEXT"}
        col = Column.from_dict(data)
        assert col.nullable is True
        assert col.primary_key is False
        assert col.unique is False
        assert col.auto_increment is False

    def test_fingerprint(self):
        col1 = Column(name="id", type="INTEGER")
        col2 = Column(name="id", type="INTEGER")
        assert col1.fingerprint() == col2.fingerprint()

    def test_fingerprint_differs_on_type(self):
        col1 = Column(name="id", type="INTEGER")
        col2 = Column(name="id", type="BIGINT")
        assert col1.fingerprint() != col2.fingerprint()

    def test_fingerprint_differs_on_nullable(self):
        col1 = Column(name="id", type="INTEGER", nullable=True)
        col2 = Column(name="id", type="INTEGER", nullable=False)
        assert col1.fingerprint() != col2.fingerprint()

    def test_fingerprint_with_default(self):
        col = Column(name="status", type="TEXT", default="'active'")
        fp = col.fingerprint()
        assert "default=" in fp

    def test_fingerprint_with_reference(self):
        col = Column(name="user_id", type="INTEGER", references="users.id")
        fp = col.fingerprint()
        assert "ref=" in fp

    def test_fingerprint_with_max_length(self):
        col = Column(name="name", type="VARCHAR", max_length=100)
        fp = col.fingerprint()
        assert "len=100" in fp

    def test_fingerprint_with_precision_scale(self):
        col = Column(name="price", type="DECIMAL", precision=10, scale=2)
        fp = col.fingerprint()
        assert "prec=10" in fp
        assert "scale=2" in fp

    def test_fingerprint_with_auto_increment(self):
        col = Column(name="id", type="INTEGER", auto_increment=True)
        fp = col.fingerprint()
        assert "autoinc" in fp

    def test_to_dict_minimal(self):
        col = Column(name="x", type="TEXT")
        d = col.to_dict()
        assert "primary_key" not in d
        assert "unique" not in d
        assert "references" not in d

    def test_to_dict_full(self):
        col = Column(
            name="x", type="VARCHAR", nullable=False, default="''",
            primary_key=True, unique=True, references="t.id",
            comment="test", max_length=50, precision=10, scale=2,
            auto_increment=True,
        )
        d = col.to_dict()
        assert d["primary_key"] is True
        assert d["unique"] is True
        assert d["references"] == "t.id"
        assert d["comment"] == "test"
        assert d["max_length"] == 50
        assert d["auto_increment"] is True

    def test_roundtrip(self):
        col = Column(
            name="price", type="DECIMAL", nullable=False,
            precision=10, scale=2, default="0.00",
        )
        d = col.to_dict()
        col2 = Column.from_dict(d)
        assert col2.name == col.name
        assert col2.type == col.type
        assert col2.precision == col.precision
        assert col2.scale == col.scale


class TestIndex:
    def test_basic_creation(self):
        idx = Index(name="idx_users_email", columns=["email"])
        assert idx.name == "idx_users_email"
        assert idx.columns == ["email"]
        assert idx.unique is False

    def test_unique_index(self):
        idx = Index(name="idx_users_email", columns=["email"], unique=True)
        assert idx.unique is True

    def test_multi_column(self):
        idx = Index(name="idx_comp", columns=["a", "b", "c"])
        assert len(idx.columns) == 3

    def test_to_dict(self):
        idx = Index(name="idx_test", columns=["col1"], unique=True, index_type="HASH")
        d = idx.to_dict()
        assert d["name"] == "idx_test"
        assert d["unique"] is True
        assert d["index_type"] == "HASH"

    def test_from_dict(self):
        data = {"name": "idx_test", "columns": ["a", "b"], "unique": True}
        idx = Index.from_dict(data)
        assert idx.name == "idx_test"
        assert idx.columns == ["a", "b"]
        assert idx.unique is True

    def test_fingerprint(self):
        idx1 = Index(name="idx", columns=["a"])
        idx2 = Index(name="idx", columns=["a"])
        assert idx1.fingerprint() == idx2.fingerprint()

    def test_fingerprint_differs(self):
        idx1 = Index(name="idx", columns=["a"])
        idx2 = Index(name="idx", columns=["b"])
        assert idx1.fingerprint() != idx2.fingerprint()

    def test_partial_index(self):
        idx = Index(name="idx", columns=["status"], condition="status = 'active'")
        d = idx.to_dict()
        assert d["condition"] == "status = 'active'"

    def test_covering_index(self):
        idx = Index(name="idx", columns=["a"], include=["b", "c"])
        d = idx.to_dict()
        assert d["include"] == ["b", "c"]

    def test_fingerprint_with_condition(self):
        idx = Index(name="idx", columns=["a"], condition="x > 0")
        fp = idx.fingerprint()
        assert "where=" in fp

    def test_fingerprint_with_include(self):
        idx = Index(name="idx", columns=["a"], include=["b"])
        fp = idx.fingerprint()
        assert "include=" in fp


class TestConstraint:
    def test_primary_key(self):
        con = Constraint(name="pk_users", type="PRIMARY KEY", columns=["id"])
        assert con.type == "PRIMARY KEY"
        assert con.columns == ["id"]

    def test_foreign_key(self):
        con = Constraint(
            name="fk_orders_user",
            type="FOREIGN KEY",
            columns=["user_id"],
            references_table="users",
            references_columns=["id"],
            on_delete="CASCADE",
        )
        assert con.references_table == "users"
        assert con.on_delete == "CASCADE"

    def test_to_dict(self):
        con = Constraint(
            name="fk_test", type="FOREIGN KEY", columns=["a"],
            references_table="t", references_columns=["id"],
            on_delete="CASCADE", on_update="SET NULL",
        )
        d = con.to_dict()
        assert d["references_table"] == "t"
        assert d["on_delete"] == "CASCADE"
        assert d["on_update"] == "SET NULL"

    def test_from_dict(self):
        data = {
            "name": "uq_email", "type": "UNIQUE", "columns": ["email"],
        }
        con = Constraint.from_dict(data)
        assert con.name == "uq_email"
        assert con.type == "UNIQUE"

    def test_fingerprint(self):
        con1 = Constraint(name="pk", type="PRIMARY KEY", columns=["id"])
        con2 = Constraint(name="pk", type="PRIMARY KEY", columns=["id"])
        assert con1.fingerprint() == con2.fingerprint()

    def test_fingerprint_with_fk_details(self):
        con = Constraint(
            name="fk", type="FOREIGN KEY", columns=["uid"],
            references_table="users", references_columns=["id"],
            on_delete="CASCADE",
        )
        fp = con.fingerprint()
        assert "ref=users" in fp
        assert "ondelete=CASCADE" in fp

    def test_deferrable(self):
        con = Constraint(name="fk", type="FOREIGN KEY", columns=["x"], deferrable=True)
        d = con.to_dict()
        assert d["deferrable"] is True
        fp = con.fingerprint()
        assert "deferrable" in fp

    def test_check_constraint(self):
        con = Constraint(
            name="ck_age", type="CHECK", columns=[],
            expression="age >= 0",
        )
        d = con.to_dict()
        assert d["expression"] == "age >= 0"

    def test_to_dict_minimal(self):
        con = Constraint(name="pk", type="PRIMARY KEY", columns=["id"])
        d = con.to_dict()
        assert "expression" not in d
        assert "references_table" not in d
        assert "deferrable" not in d


class TestTable:
    def _make_table(self):
        return Table(
            name="users",
            schema="public",
            columns=[
                Column(name="id", type="INTEGER", primary_key=True, nullable=False),
                Column(name="email", type="VARCHAR", max_length=255, unique=True),
                Column(name="name", type="TEXT"),
            ],
            indexes=[
                Index(name="idx_users_email", columns=["email"], unique=True),
            ],
            constraints=[
                Constraint(name="pk_users", type="PRIMARY KEY", columns=["id"]),
            ],
        )

    def test_creation(self):
        table = self._make_table()
        assert table.name == "users"
        assert len(table.columns) == 3
        assert len(table.indexes) == 1

    def test_get_column(self):
        table = self._make_table()
        col = table.get_column("email")
        assert col is not None
        assert col.name == "email"

    def test_get_column_not_found(self):
        table = self._make_table()
        assert table.get_column("nonexistent") is None

    def test_get_index(self):
        table = self._make_table()
        idx = table.get_index("idx_users_email")
        assert idx is not None

    def test_get_index_not_found(self):
        table = self._make_table()
        assert table.get_index("nonexistent") is None

    def test_get_constraint(self):
        table = self._make_table()
        con = table.get_constraint("pk_users")
        assert con is not None

    def test_get_constraint_not_found(self):
        table = self._make_table()
        assert table.get_constraint("nonexistent") is None

    def test_column_names(self):
        table = self._make_table()
        assert table.column_names() == ["id", "email", "name"]

    def test_primary_key_columns(self):
        table = self._make_table()
        assert table.primary_key_columns() == ["id"]

    def test_foreign_key_constraints(self):
        table = Table(
            name="orders",
            columns=[Column(name="user_id", type="INTEGER")],
            constraints=[
                Constraint(
                    name="fk_user", type="FOREIGN KEY", columns=["user_id"],
                    references_table="users", references_columns=["id"],
                ),
            ],
        )
        fks = table.foreign_key_constraints()
        assert len(fks) == 1
        assert fks[0].references_table == "users"

    def test_to_dict(self):
        table = self._make_table()
        d = table.to_dict()
        assert d["name"] == "users"
        assert len(d["columns"]) == 3
        assert len(d["indexes"]) == 1

    def test_from_dict(self):
        table = self._make_table()
        d = table.to_dict()
        table2 = Table.from_dict(d)
        assert table2.name == table.name
        assert len(table2.columns) == len(table.columns)

    def test_fingerprint(self):
        t1 = self._make_table()
        t2 = self._make_table()
        assert t1.fingerprint() == t2.fingerprint()

    def test_fingerprint_changes(self):
        t1 = self._make_table()
        t2 = self._make_table()
        t2.columns.append(Column(name="age", type="INTEGER"))
        assert t1.fingerprint() != t2.fingerprint()

    def test_comment(self):
        table = Table(name="test", comment="Test table")
        d = table.to_dict()
        assert d["comment"] == "Test table"

    def test_no_comment_in_dict(self):
        table = Table(name="test")
        d = table.to_dict()
        assert "comment" not in d

    def test_empty_table(self):
        table = Table(name="empty")
        assert table.column_names() == []
        assert table.primary_key_columns() == []
        assert table.foreign_key_constraints() == []


class TestSchema:
    def _make_schema(self):
        return Schema(
            name="test_db",
            tables=[
                Table(
                    name="users",
                    columns=[
                        Column(name="id", type="INTEGER", primary_key=True),
                        Column(name="email", type="VARCHAR", max_length=255),
                    ],
                ),
                Table(
                    name="orders",
                    columns=[
                        Column(name="id", type="INTEGER", primary_key=True),
                        Column(name="user_id", type="INTEGER", references="users.id"),
                    ],
                    constraints=[
                        Constraint(
                            name="fk_user", type="FOREIGN KEY", columns=["user_id"],
                            references_table="users", references_columns=["id"],
                        ),
                    ],
                ),
            ],
        )

    def test_creation(self):
        schema = self._make_schema()
        assert schema.name == "test_db"
        assert len(schema.tables) == 2

    def test_get_table(self):
        schema = self._make_schema()
        table = schema.get_table("users")
        assert table is not None
        assert table.name == "users"

    def test_get_table_not_found(self):
        schema = self._make_schema()
        assert schema.get_table("nonexistent") is None

    def test_table_names(self):
        schema = self._make_schema()
        assert "users" in schema.table_names()
        assert "orders" in schema.table_names()

    def test_add_table(self):
        schema = Schema()
        schema.add_table(Table(name="test"))
        assert len(schema.tables) == 1

    def test_add_table_duplicate(self):
        schema = Schema()
        schema.add_table(Table(name="test"))
        with pytest.raises(ValueError, match="already exists"):
            schema.add_table(Table(name="test"))

    def test_remove_table(self):
        schema = self._make_schema()
        removed = schema.remove_table("users")
        assert removed is not None
        assert removed.name == "users"
        assert len(schema.tables) == 1

    def test_remove_table_not_found(self):
        schema = self._make_schema()
        assert schema.remove_table("nonexistent") is None

    def test_to_json(self):
        schema = self._make_schema()
        j = schema.to_json()
        data = json.loads(j)
        assert data["name"] == "test_db"
        assert len(data["tables"]) == 2

    def test_from_json(self):
        schema = self._make_schema()
        j = schema.to_json()
        schema2 = Schema.from_json(j)
        assert schema2.name == schema.name
        assert len(schema2.tables) == len(schema.tables)

    def test_fingerprint(self):
        s1 = self._make_schema()
        s2 = self._make_schema()
        assert s1.fingerprint() == s2.fingerprint()

    def test_fingerprint_changes(self):
        s1 = self._make_schema()
        s2 = self._make_schema()
        s2.tables[0].columns.append(Column(name="extra", type="TEXT"))
        assert s1.fingerprint() != s2.fingerprint()

    def test_dependency_order(self):
        schema = self._make_schema()
        order = schema.dependency_order()
        users_idx = order.index("users")
        orders_idx = order.index("orders")
        assert users_idx < orders_idx

    def test_dependency_order_circular(self):
        schema = Schema(tables=[
            Table(
                name="a",
                constraints=[
                    Constraint(name="fk_b", type="FOREIGN KEY", columns=["b_id"],
                               references_table="b", references_columns=["id"]),
                ],
            ),
            Table(
                name="b",
                constraints=[
                    Constraint(name="fk_a", type="FOREIGN KEY", columns=["a_id"],
                               references_table="a", references_columns=["id"]),
                ],
            ),
        ])
        with pytest.raises(ValueError, match="Circular dependency"):
            schema.dependency_order()

    def test_version_metadata(self):
        schema = Schema(name="db", version="1.0.0", metadata={"env": "prod"})
        d = schema.to_dict()
        assert d["version"] == "1.0.0"
        assert d["metadata"]["env"] == "prod"

    def test_empty_schema(self):
        schema = Schema()
        assert schema.name == "default"
        assert schema.tables == []
        assert schema.fingerprint()

    def test_get_table_with_schema(self):
        schema = Schema(tables=[
            Table(name="users", schema="app"),
            Table(name="users", schema="admin"),
        ])
        t1 = schema.get_table("users", "app")
        t2 = schema.get_table("users", "admin")
        assert t1 is not None
        assert t2 is not None
        assert t1.schema == "app"
        assert t2.schema == "admin"

    def test_dependency_order_no_deps(self):
        schema = Schema(tables=[
            Table(name="a"),
            Table(name="b"),
            Table(name="c"),
        ])
        order = schema.dependency_order()
        assert set(order) == {"a", "b", "c"}

    def test_dependency_order_self_reference(self):
        schema = Schema(tables=[
            Table(
                name="tree",
                constraints=[
                    Constraint(name="fk_parent", type="FOREIGN KEY", columns=["parent_id"],
                               references_table="tree", references_columns=["id"]),
                ],
            ),
        ])
        order = schema.dependency_order()
        assert order == ["tree"]


class TestColumnType:
    def test_enum_values(self):
        assert ColumnType.INTEGER.value == "INTEGER"
        assert ColumnType.VARCHAR.value == "VARCHAR"
        assert ColumnType.JSONB.value == "JSONB"
        assert ColumnType.UUID.value == "UUID"

    def test_string_comparison(self):
        assert ColumnType.INTEGER == "INTEGER"
        assert ColumnType.TEXT == "TEXT"


class TestConstraintType:
    def test_enum_values(self):
        assert ConstraintType.PRIMARY_KEY.value == "PRIMARY KEY"
        assert ConstraintType.FOREIGN_KEY.value == "FOREIGN KEY"
        assert ConstraintType.UNIQUE.value == "UNIQUE"
        assert ConstraintType.CHECK.value == "CHECK"


class TestIndexType:
    def test_enum_values(self):
        assert IndexType.BTREE.value == "BTREE"
        assert IndexType.HASH.value == "HASH"
        assert IndexType.GIN.value == "GIN"
