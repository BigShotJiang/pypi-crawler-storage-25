"""Advanced merge tests."""

import pytest
from migra.merge import SchemaMerger, MergeConflict, ConflictType
from migra.schema import Column, Constraint, Index, Schema, Table


class TestMergeComplexScenarios:
    def test_merge_three_way(self):
        """Merge branch_a and branch_b that both diverged from base."""
        merger = SchemaMerger()

        branch_a = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER"),
                Column(name="email", type="TEXT"),
                Column(name="phone", type="TEXT"),  # added in A
            ]),
            Table(name="logs", columns=[Column(name="id", type="INTEGER")]),  # added in A
        ])

        branch_b = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER"),
                Column(name="email", type="TEXT"),
                Column(name="name", type="TEXT"),  # added in B
            ]),
            Table(name="posts", columns=[Column(name="id", type="INTEGER")]),  # added in B
        ])

        result = merger.merge(branch_a, branch_b)
        merged = result.schema

        # Should have all tables
        assert merged.get_table("users") is not None
        assert merged.get_table("logs") is not None
        assert merged.get_table("posts") is not None

        # Users should have columns from both
        users = merged.get_table("users")
        assert users.get_column("phone") is not None
        assert users.get_column("name") is not None

    def test_merge_preserves_indexes(self):
        merger = SchemaMerger()
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")],
                  indexes=[Index(name="idx_a", columns=["x"])]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")],
                  indexes=[Index(name="idx_b", columns=["x"], unique=True)]),
        ])
        result = merger.merge(a, b)
        assert len(result.schema.get_table("t").indexes) == 2

    def test_merge_preserves_constraints(self):
        merger = SchemaMerger()
        a = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")],
                  constraints=[Constraint(name="c_a", type="UNIQUE", columns=["x"])]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")],
                  constraints=[Constraint(name="c_b", type="CHECK", columns=[], expression="x IS NOT NULL")]),
        ])
        result = merger.merge(a, b)
        assert len(result.schema.get_table("t").constraints) == 2

    def test_merge_prefer_a_on_all_conflicts(self):
        merger = SchemaMerger(prefer="a")
        a = Schema(tables=[
            Table(name="t", columns=[
                Column(name="x", type="INTEGER", nullable=False, default="0"),
            ]),
        ])
        b = Schema(tables=[
            Table(name="t", columns=[
                Column(name="x", type="TEXT", nullable=True, default="''"),
            ]),
        ])
        result = merger.merge(a, b)
        col = result.schema.get_table("t").get_column("x")
        assert col.type == "INTEGER"
        assert col.nullable is False
        assert col.default == "0"

    def test_merge_many_tables(self):
        merger = SchemaMerger()
        a_tables = [Table(name=f"a_{i}", columns=[Column(name="id", type="INTEGER")]) for i in range(10)]
        b_tables = [Table(name=f"b_{i}", columns=[Column(name="id", type="INTEGER")]) for i in range(10)]
        a = Schema(tables=a_tables)
        b = Schema(tables=b_tables)
        result = merger.merge(a, b)
        assert len(result.schema.tables) == 20
        assert not result.has_conflicts

    def test_merge_result_tables_sorted(self):
        merger = SchemaMerger()
        a = Schema(tables=[Table(name="z"), Table(name="a")])
        b = Schema(tables=[Table(name="m")])
        result = merger.merge(a, b)
        names = [t.name for t in result.schema.tables]
        assert names == sorted(names)

    def test_merge_no_comment_conflict_when_null(self):
        merger = SchemaMerger()
        a = Schema(tables=[Table(name="t", comment=None)])
        b = Schema(tables=[Table(name="t", comment="new comment")])
        result = merger.merge(a, b)
        # No conflict when a has no comment
        comment_conflicts = [c for c in result.conflicts if c.conflict_type == ConflictType.TABLE_COMMENT]
        assert len(comment_conflicts) == 0
        assert result.schema.get_table("t").comment == "new comment"

    def test_merge_conflict_resolution_in_result(self):
        merger = SchemaMerger(prefer="b")
        a = Schema(tables=[Table(name="t", columns=[Column(name="x", type="INTEGER")])])
        b = Schema(tables=[Table(name="t", columns=[Column(name="x", type="TEXT")])])
        result = merger.merge(a, b)
        assert all(c.resolution == "b" for c in result.conflicts)
