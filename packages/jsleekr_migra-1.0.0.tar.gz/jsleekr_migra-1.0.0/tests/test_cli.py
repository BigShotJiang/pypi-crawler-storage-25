"""Tests for CLI interface."""

import json
import pytest
from click.testing import CliRunner

from migra.cli import main
from migra.schema import Column, Schema, Table


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def schema_files(tmp_path):
    """Create source and target schema files."""
    source = Schema(tables=[
        Table(name="users", columns=[
            Column(name="id", type="INTEGER", primary_key=True, nullable=False),
            Column(name="email", type="VARCHAR", max_length=255),
        ]),
    ])
    target = Schema(tables=[
        Table(name="users", columns=[
            Column(name="id", type="INTEGER", primary_key=True, nullable=False),
            Column(name="email", type="VARCHAR", max_length=255),
            Column(name="name", type="TEXT"),
        ]),
    ])

    source_file = tmp_path / "source.json"
    target_file = tmp_path / "target.json"
    source_file.write_text(source.to_json(), encoding="utf-8")
    target_file.write_text(target.to_json(), encoding="utf-8")

    return str(source_file), str(target_file)


class TestCLIInit:
    def test_init(self, runner, tmp_path):
        result = runner.invoke(main, ["init"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "Initialized" in result.output


class TestCLIDiff:
    def test_diff_no_changes(self, runner, tmp_path):
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="id", type="INTEGER")]),
        ])
        f1 = tmp_path / "a.json"
        f2 = tmp_path / "b.json"
        f1.write_text(schema.to_json(), encoding="utf-8")
        f2.write_text(schema.to_json(), encoding="utf-8")

        result = runner.invoke(main, ["diff", str(f1), str(f2)], catch_exceptions=False)
        assert result.exit_code == 0
        assert "No differences" in result.output

    def test_diff_with_changes(self, runner, schema_files):
        result = runner.invoke(main, ["diff", schema_files[0], schema_files[1]], catch_exceptions=False)
        assert result.exit_code == 0
        assert "ADD_COLUMN" in result.output

    def test_diff_json_output(self, runner, schema_files):
        result = runner.invoke(main, ["diff", schema_files[0], schema_files[1], "-o", "json"], catch_exceptions=False)
        assert result.exit_code == 0


class TestCLIPlan:
    def test_plan_no_changes(self, runner, tmp_path):
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="id", type="INTEGER")]),
        ])
        f = tmp_path / "schema.json"
        f.write_text(schema.to_json(), encoding="utf-8")

        result = runner.invoke(main, ["plan", str(f), str(f)], catch_exceptions=False)
        assert result.exit_code == 0
        assert "No changes" in result.output

    def test_plan_dry_run(self, runner, schema_files):
        result = runner.invoke(main, ["plan", schema_files[0], schema_files[1], "--dry-run"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "Migration Plan" in result.output

    def test_plan_creates_file(self, runner, schema_files, tmp_path):
        result = runner.invoke(main, ["plan", schema_files[0], schema_files[1], "-n", "add_name"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "Migration created" in result.output


class TestCLIStatus:
    def test_status_empty(self, runner, tmp_path):
        result = runner.invoke(main, ["status"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "Migration Status" in result.output


class TestCLIValidate:
    def test_validate_clean(self, runner, tmp_path):
        schema = Schema(tables=[
            Table(name="users", columns=[
                Column(name="id", type="INTEGER", primary_key=True),
            ]),
        ])
        f = tmp_path / "schema.json"
        f.write_text(schema.to_json(), encoding="utf-8")

        result = runner.invoke(main, ["validate", str(f)], catch_exceptions=False)
        assert result.exit_code == 0

    def test_validate_with_issues(self, runner, tmp_path):
        schema = Schema(tables=[
            Table(name="t", columns=[
                Column(name="data", type="TEXT"),
            ]),
        ])
        f = tmp_path / "schema.json"
        f.write_text(schema.to_json(), encoding="utf-8")

        result = runner.invoke(main, ["validate", str(f)], catch_exceptions=False)
        assert result.exit_code == 0

    def test_validate_json_output(self, runner, tmp_path):
        schema = Schema(tables=[
            Table(name="t", columns=[Column(name="x", type="TEXT")]),
        ])
        f = tmp_path / "schema.json"
        f.write_text(schema.to_json(), encoding="utf-8")

        result = runner.invoke(main, ["validate", str(f), "-o", "json"], catch_exceptions=False)
        assert result.exit_code == 0


class TestCLICreate:
    def test_create_migration(self, runner, tmp_path):
        result = runner.invoke(main, ["init"], catch_exceptions=False)
        result = runner.invoke(main, ["create", "add_users"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "Migration created" in result.output

    def test_create_with_description(self, runner, tmp_path):
        result = runner.invoke(main, ["init"], catch_exceptions=False)
        result = runner.invoke(main, ["create", "add_users", "-d", "Add users table"], catch_exceptions=False)
        assert result.exit_code == 0


class TestCLIApply:
    def test_apply_no_pending(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(main, ["apply"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "No pending" in result.output


class TestCLIRollback:
    def test_rollback_none(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(main, ["rollback"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "No migrations to rollback" in result.output
