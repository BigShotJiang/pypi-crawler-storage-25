"""Migration squashing - combine multiple migrations into one."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from migra.migration import Migration, MigrationStatus


class MigrationSquasher:
    """Squash multiple migrations into a single migration."""

    def squash(
        self,
        migrations: list[Migration],
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Migration:
        """Squash a list of migrations into one."""
        if not migrations:
            raise ValueError("No migrations to squash")

        if len(migrations) == 1:
            return migrations[0]

        # Combine SQL
        up_parts = []
        down_parts = []

        for m in migrations:
            if m.up_sql.strip():
                up_parts.append(f"-- From: {m.id}")
                up_parts.append(m.up_sql)
                up_parts.append("")

        # Down in reverse order
        for m in reversed(migrations):
            if m.down_sql.strip():
                down_parts.append(f"-- Undo: {m.id}")
                down_parts.append(m.down_sql)
                down_parts.append("")

        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
        squash_name = name or f"squash_{migrations[0].id}_to_{migrations[-1].id}"
        safe_name = squash_name.replace(" ", "_").lower()

        squashed = Migration(
            id=f"{timestamp}_{safe_name}",
            version=timestamp,
            name=squash_name,
            description=description or f"Squashed {len(migrations)} migrations: {migrations[0].id} to {migrations[-1].id}",
            up_sql="\n".join(up_parts).strip(),
            down_sql="\n".join(down_parts).strip(),
            tags=["squashed"],
        )

        return squashed

    def can_squash(self, migrations: list[Migration]) -> tuple[bool, list[str]]:
        """Check if migrations can be safely squashed."""
        issues = []

        if not migrations:
            issues.append("No migrations to squash")
            return False, issues

        # Check all are applied or all are pending
        statuses = {m.status for m in migrations}
        if len(statuses) > 1:
            issues.append(f"Mixed statuses: {', '.join(s.value for s in statuses)}")

        # Check for missing down SQL
        no_down = [m.id for m in migrations if not m.down_sql.strip()]
        if no_down:
            issues.append(f"Migrations without rollback SQL: {', '.join(no_down)}")

        # Check for dependency issues
        migration_ids = {m.id for m in migrations}
        for m in migrations:
            external_deps = set(m.depends_on) - migration_ids
            if external_deps:
                issues.append(f"Migration {m.id} has external dependencies: {', '.join(external_deps)}")

        return len(issues) == 0, issues

    def _split_statements(self, sql: str) -> list[str]:
        """Split SQL into statements on semicolons, respecting string literals.

        Semicolons inside single-quoted strings are not treated as statement
        separators.  This avoids breaking DEFAULT ';' or similar constructs.
        """
        statements: list[str] = []
        current: list[str] = []
        in_single_quote = False

        for ch in sql:
            if ch == "'" and not in_single_quote:
                in_single_quote = True
                current.append(ch)
            elif ch == "'" and in_single_quote:
                # Check for escaped quote (SQL '' escape)
                # We just toggle — consecutive '' will toggle twice, which is correct
                in_single_quote = False
                current.append(ch)
            elif ch == ";" and not in_single_quote:
                stmt = "".join(current).strip()
                if stmt and not stmt.startswith("--"):
                    statements.append(stmt)
                elif stmt:
                    # Keep comment-only blocks
                    statements.append(stmt)
                current = []
            else:
                current.append(ch)

        # Handle last segment (after final semicolon or if no trailing semicolon)
        remaining = "".join(current).strip()
        if remaining and not remaining.startswith("--"):
            statements.append(remaining)
        elif remaining:
            statements.append(remaining)

        return statements

    def optimize_sql(self, up_sql: str) -> str:
        """Basic SQL optimization for squashed migrations.

        Removes CREATE TABLE / DROP TABLE pairs for the same table
        by operating on full SQL statements rather than individual lines.
        """
        import re

        # Split into statements respecting string literals
        statements = self._split_statements(up_sql)

        # Track tables created and dropped to cancel out pairs
        created_tables: dict[str, int] = {}  # table_name -> statement index
        dropped_indices: set[int] = set()
        created_indices: set[int] = set()

        for i, stmt in enumerate(statements):
            upper = stmt.upper()
            # Match CREATE TABLE
            create_match = re.match(
                r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:\w+\.)?[`\"]?(\w+)",
                upper,
            )
            if create_match:
                table_name = create_match.group(1)
                created_tables[table_name] = i
                continue

            # Match DROP TABLE
            drop_match = re.match(
                r"DROP\s+TABLE\s+(?:IF\s+EXISTS\s+)?(?:\w+\.)?[`\"]?(\w+)",
                upper,
            )
            if drop_match:
                table_name = drop_match.group(1)
                if table_name in created_tables:
                    created_indices.add(created_tables.pop(table_name))
                    dropped_indices.add(i)

        # Rebuild, skipping cancelled pairs
        skip = created_indices | dropped_indices
        result_parts = []
        for i, stmt in enumerate(statements):
            if i not in skip:
                result_parts.append(stmt)

        return ";\n\n".join(result_parts) + (";" if result_parts else "")
