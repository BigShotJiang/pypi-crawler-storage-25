"""SQL schema parser - parse CREATE TABLE statements into Schema objects."""

from __future__ import annotations

import re
from typing import Optional

from migra.schema import Column, Constraint, Index, Schema, Table


class SQLParser:
    """Parse SQL DDL statements into Schema objects."""

    def __init__(self, dialect: str = "postgresql") -> None:
        self.dialect = dialect

    def parse(self, sql: str) -> Schema:
        """Parse SQL DDL into a Schema."""
        schema = Schema()
        statements = self._split_statements(sql)

        for stmt in statements:
            stmt = stmt.strip()
            if not stmt:
                continue

            upper = stmt.upper().strip()
            if upper.startswith("CREATE TABLE"):
                table = self._parse_create_table(stmt)
                if table:
                    schema.tables.append(table)
            elif upper.startswith("CREATE INDEX") or upper.startswith("CREATE UNIQUE INDEX"):
                idx, table_name = self._parse_create_index(stmt)
                if idx and table_name:
                    table = schema.get_table(table_name)
                    if table:
                        table.indexes.append(idx)

        return schema

    def parse_file(self, path: str) -> Schema:
        """Parse a SQL file into a Schema."""
        with open(path, "r", encoding="utf-8") as f:
            return self.parse(f.read())

    def _split_statements(self, sql: str) -> list[str]:
        """Split SQL into individual statements.

        Respects string literals so that semicolons, comment markers (--),
        and block comment markers inside quoted strings are preserved.
        """
        # Remove comments while respecting string literals
        sql = self._strip_comments(sql)

        statements: list[str] = []
        current = ""
        paren_depth = 0
        in_string = False
        i = 0
        n = len(sql)

        while i < n:
            ch = sql[i]
            if ch == "'" and not in_string:
                in_string = True
                current += ch
                i += 1
            elif ch == "'" and in_string:
                current += ch
                if i + 1 < n and sql[i + 1] == "'":
                    current += sql[i + 1]
                    i += 2
                else:
                    in_string = False
                    i += 1
            elif not in_string:
                if ch == "(":
                    paren_depth += 1
                elif ch == ")":
                    paren_depth -= 1
                elif ch == ";" and paren_depth == 0:
                    statements.append(current.strip())
                    current = ""
                    i += 1
                    continue
                current += ch
                i += 1
            else:
                current += ch
                i += 1

        if current.strip():
            statements.append(current.strip())

        return statements

    def _strip_comments(self, sql: str) -> str:
        """Remove SQL comments while preserving string literal contents."""
        result: list[str] = []
        i = 0
        n = len(sql)
        in_string = False

        while i < n:
            if sql[i] == "'" and not in_string:
                in_string = True
                result.append(sql[i])
                i += 1
            elif sql[i] == "'" and in_string:
                result.append(sql[i])
                if i + 1 < n and sql[i + 1] == "'":
                    result.append(sql[i + 1])
                    i += 2
                else:
                    in_string = False
                    i += 1
            elif not in_string and sql[i] == "-" and i + 1 < n and sql[i + 1] == "-":
                # Line comment -- skip to end of line
                end = sql.find("\n", i)
                if end == -1:
                    break
                i = end  # keep the newline
            elif not in_string and sql[i:i+2] == "/*":
                # Block comment -- skip to closing */
                end = sql.find("*/", i + 2)
                if end == -1:
                    break
                i = end + 2
            else:
                result.append(sql[i])
                i += 1

        return "".join(result)

    def _parse_create_table(self, sql: str) -> Optional[Table]:
        """Parse a CREATE TABLE statement."""
        # Extract table name
        pattern = r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:(\w+)\.)?[`\"]?(\w+)[`\"]?"
        match = re.match(pattern, sql, re.IGNORECASE)
        if not match:
            return None

        schema_name = match.group(1) or "public"
        table_name = match.group(2)

        # Extract column definitions (between parentheses)
        paren_start = sql.index("(")
        paren_end = self._find_matching_paren(sql, paren_start)
        if paren_end < 0:
            return None

        body = sql[paren_start + 1:paren_end].strip()

        table = Table(name=table_name, schema=schema_name)

        # Split by commas, respecting parentheses
        parts = self._split_column_defs(body)

        for part in parts:
            part = part.strip()
            if not part:
                continue

            upper_part = part.upper().strip()
            if upper_part.startswith("PRIMARY KEY"):
                constraint = self._parse_table_constraint(part, "PRIMARY KEY")
                if constraint:
                    table.constraints.append(constraint)
            elif upper_part.startswith("FOREIGN KEY"):
                constraint = self._parse_table_constraint(part, "FOREIGN KEY")
                if constraint:
                    table.constraints.append(constraint)
            elif upper_part.startswith("UNIQUE"):
                constraint = self._parse_table_constraint(part, "UNIQUE")
                if constraint:
                    table.constraints.append(constraint)
            elif upper_part.startswith("CHECK"):
                constraint = self._parse_table_constraint(part, "CHECK")
                if constraint:
                    table.constraints.append(constraint)
            elif upper_part.startswith("CONSTRAINT"):
                constraint = self._parse_named_constraint(part)
                if constraint:
                    table.constraints.append(constraint)
            else:
                column = self._parse_column_def(part)
                if column:
                    table.columns.append(column)

        return table

    def _parse_column_def(self, sql: str) -> Optional[Column]:
        """Parse a column definition."""
        sql = sql.strip()
        if not sql:
            return None

        # Extract name and type
        pattern = r"[`\"]?(\w+)[`\"]?\s+(\w+(?:\s*\([^)]*\))?)"
        match = re.match(pattern, sql, re.IGNORECASE)
        if not match:
            return None

        name = match.group(1)
        col_type = match.group(2).upper()
        rest = sql[match.end():].strip().upper()

        # Parse type details
        max_length = None
        precision = None
        scale = None
        base_type = col_type

        type_match = re.match(r"(\w+)\s*\((\d+)(?:\s*,\s*(\d+))?\)", col_type)
        if type_match:
            base_type = type_match.group(1)
            if type_match.group(3):
                precision = int(type_match.group(2))
                scale = int(type_match.group(3))
            else:
                if base_type in ("VARCHAR", "CHAR", "VARYING"):
                    max_length = int(type_match.group(2))
                else:
                    precision = int(type_match.group(2))

        nullable = "NOT NULL" not in rest
        primary_key = "PRIMARY KEY" in rest
        unique = "UNIQUE" in rest
        auto_increment = any(kw in rest for kw in ("AUTO_INCREMENT", "AUTOINCREMENT", "SERIAL", "GENERATED"))

        # Parse DEFAULT
        default = None
        default_match = re.search(r"DEFAULT\s+(.+?)(?:\s+(?:NOT|NULL|PRIMARY|UNIQUE|CHECK|REFERENCES|CONSTRAINT|$))", rest)
        if default_match:
            default = default_match.group(1).strip().rstrip(",")
        elif "DEFAULT" in rest:
            default_match2 = re.search(r"DEFAULT\s+(\S+)", rest)
            if default_match2:
                default = default_match2.group(1).strip().rstrip(",")

        # Parse REFERENCES (from original sql, not uppercased rest)
        references = None
        ref_match = re.search(r"REFERENCES\s+[`\"]?(\w+)[`\"]?\s*\(\s*[`\"]?(\w+)[`\"]?\s*\)", sql, re.IGNORECASE)
        if ref_match:
            references = f"{ref_match.group(1)}.{ref_match.group(2)}"

        return Column(
            name=name,
            type=base_type,
            nullable=nullable,
            default=default,
            primary_key=primary_key,
            unique=unique,
            references=references,
            max_length=max_length,
            precision=precision,
            scale=scale,
            auto_increment="SERIAL" in col_type or auto_increment,
        )

    def _parse_create_index(self, sql: str) -> tuple[Optional[Index], Optional[str]]:
        """Parse a CREATE INDEX statement."""
        unique = "UNIQUE" in sql.upper()
        pattern = r"CREATE\s+(?:UNIQUE\s+)?INDEX\s+(?:CONCURRENTLY\s+)?(?:IF\s+NOT\s+EXISTS\s+)?[`\"]?(\w+)[`\"]?\s+ON\s+(?:(\w+)\.)?[`\"]?(\w+)[`\"]?\s*\(\s*([^)]+)\s*\)"
        match = re.match(pattern, sql, re.IGNORECASE)
        if not match:
            return None, None

        idx_name = match.group(1)
        table_name = match.group(3)
        cols_str = match.group(4)
        columns = [c.strip().strip('`"') for c in cols_str.split(",")]

        # Check for WHERE clause (partial index)
        condition = None
        where_match = re.search(r"WHERE\s+(.+)", sql, re.IGNORECASE)
        if where_match:
            condition = where_match.group(1).strip().rstrip(";")

        idx = Index(
            name=idx_name,
            columns=columns,
            unique=unique,
            condition=condition,
        )
        return idx, table_name

    def _parse_table_constraint(self, sql: str, constraint_type: str) -> Optional[Constraint]:
        """Parse an inline table constraint."""
        if constraint_type == "PRIMARY KEY":
            match = re.search(r"PRIMARY\s+KEY\s*\(\s*([^)]+)\s*\)", sql, re.IGNORECASE)
            if match:
                cols = [c.strip().strip('`"') for c in match.group(1).split(",")]
                return Constraint(
                    name=f"pk_{'_'.join(cols)}",
                    type="PRIMARY KEY",
                    columns=cols,
                )
        elif constraint_type == "FOREIGN KEY":
            match = re.search(
                r"FOREIGN\s+KEY\s*\(\s*([^)]+)\s*\)\s*REFERENCES\s+[`\"]?(\w+)[`\"]?\s*\(\s*([^)]+)\s*\)",
                sql, re.IGNORECASE
            )
            if match:
                cols = [c.strip().strip('`"') for c in match.group(1).split(",")]
                ref_table = match.group(2)
                ref_cols = [c.strip().strip('`"') for c in match.group(3).split(",")]

                on_delete = None
                on_update = None
                del_match = re.search(r"ON\s+DELETE\s+(CASCADE|SET\s+NULL|RESTRICT|NO\s+ACTION|SET\s+DEFAULT)", sql, re.IGNORECASE)
                if del_match:
                    on_delete = del_match.group(1).upper()
                upd_match = re.search(r"ON\s+UPDATE\s+(CASCADE|SET\s+NULL|RESTRICT|NO\s+ACTION|SET\s+DEFAULT)", sql, re.IGNORECASE)
                if upd_match:
                    on_update = upd_match.group(1).upper()

                return Constraint(
                    name=f"fk_{'_'.join(cols)}_{ref_table}",
                    type="FOREIGN KEY",
                    columns=cols,
                    references_table=ref_table,
                    references_columns=ref_cols,
                    on_delete=on_delete,
                    on_update=on_update,
                )
        elif constraint_type == "UNIQUE":
            match = re.search(r"UNIQUE\s*\(\s*([^)]+)\s*\)", sql, re.IGNORECASE)
            if match:
                cols = [c.strip().strip('`"') for c in match.group(1).split(",")]
                return Constraint(
                    name=f"uq_{'_'.join(cols)}",
                    type="UNIQUE",
                    columns=cols,
                )
        elif constraint_type == "CHECK":
            match = re.search(r"CHECK\s*\(\s*(.+)\s*\)", sql, re.IGNORECASE)
            if match:
                return Constraint(
                    name=f"ck_{hash(match.group(1)) & 0xFFFF:04x}",
                    type="CHECK",
                    columns=[],
                    expression=match.group(1),
                )

        return None

    def _parse_named_constraint(self, sql: str) -> Optional[Constraint]:
        """Parse a named constraint."""
        match = re.match(r"CONSTRAINT\s+[`\"]?(\w+)[`\"]?\s+(.+)", sql, re.IGNORECASE)
        if not match:
            return None

        name = match.group(1)
        rest = match.group(2).strip()
        upper_rest = rest.upper()

        if upper_rest.startswith("PRIMARY KEY"):
            constraint = self._parse_table_constraint(rest, "PRIMARY KEY")
            if constraint:
                constraint.name = name
            return constraint
        elif upper_rest.startswith("FOREIGN KEY"):
            constraint = self._parse_table_constraint(rest, "FOREIGN KEY")
            if constraint:
                constraint.name = name
            return constraint
        elif upper_rest.startswith("UNIQUE"):
            constraint = self._parse_table_constraint(rest, "UNIQUE")
            if constraint:
                constraint.name = name
            return constraint
        elif upper_rest.startswith("CHECK"):
            constraint = self._parse_table_constraint(rest, "CHECK")
            if constraint:
                constraint.name = name
            return constraint

        return None

    def _find_matching_paren(self, sql: str, start: int) -> int:
        """Find the matching closing parenthesis, respecting string literals."""
        depth = 0
        in_string = False
        i = start
        n = len(sql)
        while i < n:
            ch = sql[i]
            if ch == "'" and not in_string:
                in_string = True
                i += 1
            elif ch == "'" and in_string:
                if i + 1 < n and sql[i + 1] == "'":
                    i += 2  # skip escaped quote
                else:
                    in_string = False
                    i += 1
            elif not in_string:
                if ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                    if depth == 0:
                        return i
                i += 1
            else:
                i += 1
        return -1

    def _split_column_defs(self, body: str) -> list[str]:
        """Split column definitions by commas, respecting parentheses and string literals."""
        parts = []
        current = ""
        depth = 0
        in_string = False
        i = 0
        n = len(body)

        while i < n:
            ch = body[i]
            if ch == "'" and not in_string:
                in_string = True
                current += ch
                i += 1
            elif ch == "'" and in_string:
                current += ch
                if i + 1 < n and body[i + 1] == "'":
                    current += body[i + 1]
                    i += 2
                else:
                    in_string = False
                    i += 1
            elif not in_string:
                if ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                elif ch == "," and depth == 0:
                    parts.append(current.strip())
                    current = ""
                    i += 1
                    continue
                current += ch
                i += 1
            else:
                current += ch
                i += 1

        if current.strip():
            parts.append(current.strip())

        return parts
