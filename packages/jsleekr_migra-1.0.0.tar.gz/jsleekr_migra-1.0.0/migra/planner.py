"""Migration planner - generates migration SQL from schema diffs."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from migra.diff import ChangeType, DiffResult, RiskLevel, SchemaDiff
from migra.schema import Column, Constraint, Index, Schema, Table


@dataclass
class PlanStep:
    """A single step in a migration plan."""
    order: int
    up_sql: str
    down_sql: str
    description: str
    risk_level: RiskLevel
    change: DiffResult
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "order": self.order,
            "up_sql": self.up_sql,
            "down_sql": self.down_sql,
            "description": self.description,
            "risk_level": self.risk_level.value,
            "warnings": self.warnings,
            "change": self.change.to_dict(),
        }


@dataclass
class MigrationPlan:
    """A complete migration plan."""
    steps: list[PlanStep] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def up_sql(self) -> str:
        return "\n\n".join(s.up_sql for s in self.steps if s.up_sql)

    @property
    def down_sql(self) -> str:
        # Reverse order for down
        return "\n\n".join(s.down_sql for s in reversed(self.steps) if s.down_sql)

    @property
    def max_risk(self) -> RiskLevel:
        if not self.steps:
            return RiskLevel.SAFE
        risk_order = [RiskLevel.SAFE, RiskLevel.LOW, RiskLevel.MEDIUM, RiskLevel.HIGH, RiskLevel.DESTRUCTIVE]
        return max((s.risk_level for s in self.steps), key=lambda r: risk_order.index(r))

    @property
    def total_steps(self) -> int:
        return len(self.steps)

    def to_dict(self) -> dict[str, Any]:
        return {
            "steps": [s.to_dict() for s in self.steps],
            "warnings": self.warnings,
            "max_risk": self.max_risk.value,
            "total_steps": self.total_steps,
        }


class MigrationPlanner:
    """Generates migration SQL from schema diffs."""

    def __init__(self, dialect: str = "postgresql") -> None:
        self.dialect = dialect
        self._generators = {
            "postgresql": PostgreSQLGenerator(),
            "mysql": MySQLGenerator(),
            "sqlite": SQLiteGenerator(),
        }

    def plan(self, diff: SchemaDiff) -> MigrationPlan:
        """Generate a migration plan from a schema diff."""
        if not diff._computed:
            diff.compute()

        generator = self._generators.get(self.dialect)
        if not generator:
            raise ValueError(f"Unsupported dialect: {self.dialect}")

        plan = MigrationPlan()
        order = 0

        # Sort changes: creates first, then alters, then drops
        priority = {
            ChangeType.ADD_TABLE: 0,
            ChangeType.ADD_COLUMN: 1,
            ChangeType.ADD_INDEX: 2,
            ChangeType.ADD_CONSTRAINT: 3,
            ChangeType.ALTER_COLUMN: 4,
            ChangeType.ALTER_INDEX: 5,
            ChangeType.ALTER_CONSTRAINT: 6,
            ChangeType.CHANGE_COMMENT: 7,
            ChangeType.DROP_CONSTRAINT: 8,
            ChangeType.DROP_INDEX: 9,
            ChangeType.DROP_COLUMN: 10,
            ChangeType.DROP_TABLE: 11,
            ChangeType.RENAME_TABLE: 12,
            ChangeType.RENAME_COLUMN: 13,
        }

        sorted_changes = sorted(diff.changes, key=lambda c: priority.get(c.change_type, 99))

        for change in sorted_changes:
            order += 1
            up_sql, down_sql, warnings = generator.generate(change)
            step = PlanStep(
                order=order,
                up_sql=up_sql,
                down_sql=down_sql,
                description=change.description,
                risk_level=change.risk_level,
                change=change,
                warnings=warnings,
            )
            plan.steps.append(step)
            plan.warnings.extend(warnings)

        return plan


class SQLGenerator:
    """Base SQL generator."""

    def generate(self, change: DiffResult) -> tuple[str, str, list[str]]:
        """Generate up SQL, down SQL, and warnings."""
        method = getattr(self, f"_gen_{change.change_type.value.lower()}", None)
        if method:
            return method(change)
        return f"-- TODO: {change.description}", "", [f"Unsupported change type: {change.change_type.value}"]

    def _quote_identifier(self, name: str) -> str:
        return f'"{name}"'

    def _column_def(self, col_data: dict) -> str:
        """Generate column definition from column dict."""
        parts = [self._quote_identifier(col_data["name"])]

        col_type = col_data["type"]
        if col_data.get("max_length"):
            col_type += f"({col_data['max_length']})"
        elif col_data.get("precision"):
            if col_data.get("scale"):
                col_type += f"({col_data['precision']}, {col_data['scale']})"
            else:
                col_type += f"({col_data['precision']})"
        parts.append(col_type)

        if not col_data.get("nullable", True):
            parts.append("NOT NULL")

        if col_data.get("default") is not None:
            parts.append(f"DEFAULT {col_data['default']}")

        if col_data.get("primary_key"):
            parts.append("PRIMARY KEY")

        if col_data.get("unique"):
            parts.append("UNIQUE")

        if col_data.get("references"):
            ref_parts = col_data["references"].split(".")
            if len(ref_parts) == 2:
                parts.append(f"REFERENCES {self._quote_identifier(ref_parts[0])}({self._quote_identifier(ref_parts[1])})")

        return " ".join(parts)


class PostgreSQLGenerator(SQLGenerator):
    """PostgreSQL-specific SQL generator."""

    def _gen_add_table(self, change: DiffResult) -> tuple[str, str, list[str]]:
        table_data = change.new_value
        columns = [self._column_def(c) for c in table_data.get("columns", [])]
        col_str = ",\n    ".join(columns)

        schema = table_data.get("schema", "public")
        table_name = f'{self._quote_identifier(schema)}.{self._quote_identifier(table_data["name"])}'

        up = f"CREATE TABLE {table_name} (\n    {col_str}\n);"
        down = f"DROP TABLE IF EXISTS {table_name};"

        # Generate indexes
        for idx_data in table_data.get("indexes", []):
            unique = "UNIQUE " if idx_data.get("unique") else ""
            idx_cols = ", ".join(self._quote_identifier(c) for c in idx_data["columns"])
            idx_name = self._quote_identifier(idx_data["name"])
            up += f"\n\nCREATE {unique}INDEX {idx_name} ON {table_name} ({idx_cols});"

        # Generate constraints
        for con_data in table_data.get("constraints", []):
            con_name = self._quote_identifier(con_data["name"])
            con_type = con_data["type"]
            con_cols = ", ".join(self._quote_identifier(c) for c in con_data["columns"])

            if con_type == "FOREIGN KEY" and con_data.get("references_table"):
                ref_table = self._quote_identifier(con_data["references_table"])
                ref_cols = ", ".join(self._quote_identifier(c) for c in (con_data.get("references_columns") or []))
                fk_clause = f"FOREIGN KEY ({con_cols}) REFERENCES {ref_table}({ref_cols})"
                if con_data.get("on_delete"):
                    fk_clause += f" ON DELETE {con_data['on_delete']}"
                if con_data.get("on_update"):
                    fk_clause += f" ON UPDATE {con_data['on_update']}"
                up += f"\n\nALTER TABLE {table_name} ADD CONSTRAINT {con_name} {fk_clause};"
            elif con_type == "UNIQUE":
                up += f"\n\nALTER TABLE {table_name} ADD CONSTRAINT {con_name} UNIQUE ({con_cols});"
            elif con_type == "CHECK" and con_data.get("expression"):
                up += f"\n\nALTER TABLE {table_name} ADD CONSTRAINT {con_name} CHECK ({con_data['expression']});"

        return up, down, []

    def _gen_drop_table(self, change: DiffResult) -> tuple[str, str, list[str]]:
        table_data = change.old_value
        schema = table_data.get("schema", "public")
        table_name = f'{self._quote_identifier(schema)}.{self._quote_identifier(table_data["name"])}'

        up = f"DROP TABLE IF EXISTS {table_name} CASCADE;"

        # Generate recreation SQL for down
        columns = [self._column_def(c) for c in table_data.get("columns", [])]
        col_str = ",\n    ".join(columns)
        down = f"CREATE TABLE {table_name} (\n    {col_str}\n);"

        warnings = ["DESTRUCTIVE: This will permanently delete the table and all its data"]
        return up, down, warnings

    def _gen_add_column(self, change: DiffResult) -> tuple[str, str, list[str]]:
        col_data = change.new_value
        table_name = f'{self._quote_identifier(change.table_schema)}.{self._quote_identifier(change.table_name)}'
        col_def = self._column_def(col_data)

        up = f"ALTER TABLE {table_name} ADD COLUMN {col_def};"
        down = f"ALTER TABLE {table_name} DROP COLUMN {self._quote_identifier(col_data['name'])};"

        warnings = []
        if not col_data.get("nullable", True) and col_data.get("default") is None:
            warnings.append(f"Adding NOT NULL column {col_data['name']} without DEFAULT will fail if table has existing rows")
        return up, down, warnings

    def _gen_drop_column(self, change: DiffResult) -> tuple[str, str, list[str]]:
        col_data = change.old_value
        table_name = f'{self._quote_identifier(change.table_schema)}.{self._quote_identifier(change.table_name)}'

        up = f"ALTER TABLE {table_name} DROP COLUMN {self._quote_identifier(col_data['name'])};"
        down = f"ALTER TABLE {table_name} ADD COLUMN {self._column_def(col_data)};"

        warnings = [f"DESTRUCTIVE: Dropping column {col_data['name']} will permanently delete its data"]
        return up, down, warnings

    def _gen_alter_column(self, change: DiffResult) -> tuple[str, str, list[str]]:
        old_col = change.old_value
        new_col = change.new_value
        table_name = f'{self._quote_identifier(change.table_schema)}.{self._quote_identifier(change.table_name)}'
        col_name = self._quote_identifier(change.object_name or old_col["name"])

        up_parts = []
        down_parts = []
        warnings = []

        if old_col.get("type") != new_col.get("type"):
            new_type = new_col["type"]
            if new_col.get("max_length"):
                new_type += f"({new_col['max_length']})"
            old_type = old_col["type"]
            if old_col.get("max_length"):
                old_type += f"({old_col['max_length']})"
            up_parts.append(f"ALTER TABLE {table_name} ALTER COLUMN {col_name} TYPE {new_type};")
            down_parts.append(f"ALTER TABLE {table_name} ALTER COLUMN {col_name} TYPE {old_type};")
            warnings.append(f"Type change from {old_col['type']} to {new_col['type']} may cause data loss")

        if old_col.get("nullable") != new_col.get("nullable"):
            if new_col.get("nullable"):
                up_parts.append(f"ALTER TABLE {table_name} ALTER COLUMN {col_name} DROP NOT NULL;")
                down_parts.append(f"ALTER TABLE {table_name} ALTER COLUMN {col_name} SET NOT NULL;")
            else:
                up_parts.append(f"ALTER TABLE {table_name} ALTER COLUMN {col_name} SET NOT NULL;")
                down_parts.append(f"ALTER TABLE {table_name} ALTER COLUMN {col_name} DROP NOT NULL;")
                warnings.append(f"Setting NOT NULL on {change.object_name} may fail if NULLs exist")

        if old_col.get("default") != new_col.get("default"):
            if new_col.get("default") is not None:
                up_parts.append(f"ALTER TABLE {table_name} ALTER COLUMN {col_name} SET DEFAULT {new_col['default']};")
            else:
                up_parts.append(f"ALTER TABLE {table_name} ALTER COLUMN {col_name} DROP DEFAULT;")
            if old_col.get("default") is not None:
                down_parts.append(f"ALTER TABLE {table_name} ALTER COLUMN {col_name} SET DEFAULT {old_col['default']};")
            else:
                down_parts.append(f"ALTER TABLE {table_name} ALTER COLUMN {col_name} DROP DEFAULT;")

        up = "\n".join(up_parts) if up_parts else f"-- No SQL needed for: {change.description}"
        down = "\n".join(down_parts) if down_parts else ""

        return up, down, warnings

    def _gen_add_index(self, change: DiffResult) -> tuple[str, str, list[str]]:
        idx_data = change.new_value
        table_name = f'{self._quote_identifier(change.table_schema)}.{self._quote_identifier(change.table_name)}'
        idx_name = self._quote_identifier(idx_data["name"])
        unique = "UNIQUE " if idx_data.get("unique") else ""
        cols = ", ".join(self._quote_identifier(c) for c in idx_data["columns"])

        up = f"CREATE {unique}INDEX CONCURRENTLY {idx_name} ON {table_name} ({cols});"
        down = f"DROP INDEX IF EXISTS {self._quote_identifier(change.table_schema)}.{idx_name};"

        if idx_data.get("condition"):
            up = up.rstrip(";") + f" WHERE {idx_data['condition']};"

        return up, down, []

    def _gen_drop_index(self, change: DiffResult) -> tuple[str, str, list[str]]:
        idx_data = change.old_value
        table_name = f'{self._quote_identifier(change.table_schema)}.{self._quote_identifier(change.table_name)}'
        idx_name = self._quote_identifier(idx_data["name"])

        up = f"DROP INDEX IF EXISTS {self._quote_identifier(change.table_schema)}.{idx_name};"
        unique = "UNIQUE " if idx_data.get("unique") else ""
        cols = ", ".join(self._quote_identifier(c) for c in idx_data["columns"])
        down = f"CREATE {unique}INDEX {idx_name} ON {table_name} ({cols});"

        return up, down, []

    def _gen_alter_index(self, change: DiffResult) -> tuple[str, str, list[str]]:
        old_idx = change.old_value
        new_idx = change.new_value
        table_name = f'{self._quote_identifier(change.table_schema)}.{self._quote_identifier(change.table_name)}'
        idx_name = self._quote_identifier(change.object_name or old_idx["name"])

        # Drop and recreate
        unique_new = "UNIQUE " if new_idx.get("unique") else ""
        new_cols = ", ".join(self._quote_identifier(c) for c in new_idx["columns"])
        unique_old = "UNIQUE " if old_idx.get("unique") else ""
        old_cols = ", ".join(self._quote_identifier(c) for c in old_idx["columns"])

        schema_prefix = self._quote_identifier(change.table_schema)
        up = f"DROP INDEX IF EXISTS {schema_prefix}.{idx_name};\nCREATE {unique_new}INDEX {idx_name} ON {table_name} ({new_cols});"
        down = f"DROP INDEX IF EXISTS {schema_prefix}.{idx_name};\nCREATE {unique_old}INDEX {idx_name} ON {table_name} ({old_cols});"

        return up, down, []

    def _gen_add_constraint(self, change: DiffResult) -> tuple[str, str, list[str]]:
        con_data = change.new_value
        table_name = f'{self._quote_identifier(change.table_schema)}.{self._quote_identifier(change.table_name)}'
        con_name = self._quote_identifier(con_data["name"])
        con_type = con_data["type"]
        cols = ", ".join(self._quote_identifier(c) for c in con_data["columns"])

        if con_type == "FOREIGN KEY" and con_data.get("references_table"):
            ref_table = self._quote_identifier(con_data["references_table"])
            ref_cols = ", ".join(self._quote_identifier(c) for c in (con_data.get("references_columns") or []))
            clause = f"FOREIGN KEY ({cols}) REFERENCES {ref_table}({ref_cols})"
            if con_data.get("on_delete"):
                clause += f" ON DELETE {con_data['on_delete']}"
            if con_data.get("on_update"):
                clause += f" ON UPDATE {con_data['on_update']}"
            up = f"ALTER TABLE {table_name} ADD CONSTRAINT {con_name} {clause};"
        elif con_type == "UNIQUE":
            up = f"ALTER TABLE {table_name} ADD CONSTRAINT {con_name} UNIQUE ({cols});"
        elif con_type == "CHECK" and con_data.get("expression"):
            up = f"ALTER TABLE {table_name} ADD CONSTRAINT {con_name} CHECK ({con_data['expression']});"
        elif con_type == "PRIMARY KEY":
            up = f"ALTER TABLE {table_name} ADD CONSTRAINT {con_name} PRIMARY KEY ({cols});"
        else:
            up = f"-- TODO: Add constraint {con_name} of type {con_type}"

        down = f"ALTER TABLE {table_name} DROP CONSTRAINT IF EXISTS {con_name};"
        return up, down, []

    def _gen_drop_constraint(self, change: DiffResult) -> tuple[str, str, list[str]]:
        con_data = change.old_value
        table_name = f'{self._quote_identifier(change.table_schema)}.{self._quote_identifier(change.table_name)}'
        con_name = self._quote_identifier(con_data["name"])

        up = f"ALTER TABLE {table_name} DROP CONSTRAINT IF EXISTS {con_name};"
        # Recreate for down - simplified
        down = f"-- TODO: Recreate constraint {con_data['name']}"

        return up, down, []

    def _gen_alter_constraint(self, change: DiffResult) -> tuple[str, str, list[str]]:
        old_con = change.old_value
        new_con = change.new_value
        table_name = f'{self._quote_identifier(change.table_schema)}.{self._quote_identifier(change.table_name)}'
        con_name = self._quote_identifier(change.object_name or old_con["name"])

        up = f"ALTER TABLE {table_name} DROP CONSTRAINT IF EXISTS {con_name};"
        # Re-add new constraint
        up_add, _, warnings = self._gen_add_constraint(DiffResult(
            change_type=ChangeType.ADD_CONSTRAINT,
            table_name=change.table_name,
            table_schema=change.table_schema,
            object_name=change.object_name,
            new_value=new_con,
        ))
        up += f"\n{up_add}"

        down = f"ALTER TABLE {table_name} DROP CONSTRAINT IF EXISTS {con_name};"
        down_add, _, _ = self._gen_add_constraint(DiffResult(
            change_type=ChangeType.ADD_CONSTRAINT,
            table_name=change.table_name,
            table_schema=change.table_schema,
            object_name=change.object_name,
            new_value=old_con,
        ))
        down += f"\n{down_add}"

        return up, down, warnings

    def _gen_change_comment(self, change: DiffResult) -> tuple[str, str, list[str]]:
        table_name = f'{self._quote_identifier(change.table_schema)}.{self._quote_identifier(change.table_name)}'
        new_comment = (change.new_value or "").replace("'", "''")
        old_comment = (change.old_value or "").replace("'", "''")

        if change.new_value:
            up = f"COMMENT ON TABLE {table_name} IS '{new_comment}';"
        else:
            up = f"COMMENT ON TABLE {table_name} IS NULL;"

        if change.old_value:
            down = f"COMMENT ON TABLE {table_name} IS '{old_comment}';"
        else:
            down = f"COMMENT ON TABLE {table_name} IS NULL;"

        return up, down, []


class MySQLGenerator(SQLGenerator):
    """MySQL-specific SQL generator."""

    def _quote_identifier(self, name: str) -> str:
        return f"`{name}`"

    def _gen_add_table(self, change: DiffResult) -> tuple[str, str, list[str]]:
        table_data = change.new_value
        columns = [self._column_def(c) for c in table_data.get("columns", [])]
        col_str = ",\n    ".join(columns)
        table_name = self._quote_identifier(table_data["name"])

        up = f"CREATE TABLE {table_name} (\n    {col_str}\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
        down = f"DROP TABLE IF EXISTS {table_name};"
        return up, down, []

    def _gen_drop_table(self, change: DiffResult) -> tuple[str, str, list[str]]:
        table_data = change.old_value
        table_name = self._quote_identifier(table_data["name"])
        up = f"DROP TABLE IF EXISTS {table_name};"
        columns = [self._column_def(c) for c in table_data.get("columns", [])]
        col_str = ",\n    ".join(columns)
        down = f"CREATE TABLE {table_name} (\n    {col_str}\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
        return up, down, ["DESTRUCTIVE: This will permanently delete the table and all its data"]

    def _gen_add_column(self, change: DiffResult) -> tuple[str, str, list[str]]:
        col_data = change.new_value
        table_name = self._quote_identifier(change.table_name)
        col_def = self._column_def(col_data)
        up = f"ALTER TABLE {table_name} ADD COLUMN {col_def};"
        down = f"ALTER TABLE {table_name} DROP COLUMN {self._quote_identifier(col_data['name'])};"
        warnings = []
        if not col_data.get("nullable", True) and col_data.get("default") is None:
            warnings.append(f"Adding NOT NULL column without DEFAULT may fail on existing rows")
        return up, down, warnings

    def _gen_drop_column(self, change: DiffResult) -> tuple[str, str, list[str]]:
        col_data = change.old_value
        table_name = self._quote_identifier(change.table_name)
        up = f"ALTER TABLE {table_name} DROP COLUMN {self._quote_identifier(col_data['name'])};"
        down = f"ALTER TABLE {table_name} ADD COLUMN {self._column_def(col_data)};"
        return up, down, [f"DESTRUCTIVE: Dropping column {col_data['name']}"]

    def _gen_alter_column(self, change: DiffResult) -> tuple[str, str, list[str]]:
        old_col = change.old_value
        new_col = change.new_value
        table_name = self._quote_identifier(change.table_name)
        col_def = self._column_def(new_col)
        old_col_def = self._column_def(old_col)
        up = f"ALTER TABLE {table_name} MODIFY COLUMN {col_def};"
        down = f"ALTER TABLE {table_name} MODIFY COLUMN {old_col_def};"
        return up, down, []

    def _gen_add_index(self, change: DiffResult) -> tuple[str, str, list[str]]:
        idx_data = change.new_value
        table_name = self._quote_identifier(change.table_name)
        idx_name = self._quote_identifier(idx_data["name"])
        unique = "UNIQUE " if idx_data.get("unique") else ""
        cols = ", ".join(self._quote_identifier(c) for c in idx_data["columns"])
        up = f"CREATE {unique}INDEX {idx_name} ON {table_name} ({cols});"
        down = f"DROP INDEX {idx_name} ON {table_name};"
        return up, down, []

    def _gen_drop_index(self, change: DiffResult) -> tuple[str, str, list[str]]:
        idx_data = change.old_value
        table_name = self._quote_identifier(change.table_name)
        idx_name = self._quote_identifier(idx_data["name"])
        unique = "UNIQUE " if idx_data.get("unique") else ""
        cols = ", ".join(self._quote_identifier(c) for c in idx_data["columns"])
        up = f"DROP INDEX {idx_name} ON {table_name};"
        down = f"CREATE {unique}INDEX {idx_name} ON {table_name} ({cols});"
        return up, down, []

    def _gen_add_constraint(self, change: DiffResult) -> tuple[str, str, list[str]]:
        con_data = change.new_value
        table_name = self._quote_identifier(change.table_name)
        con_name = self._quote_identifier(con_data["name"])
        cols = ", ".join(self._quote_identifier(c) for c in con_data["columns"])

        if con_data["type"] == "FOREIGN KEY" and con_data.get("references_table"):
            ref_table = self._quote_identifier(con_data["references_table"])
            ref_cols = ", ".join(self._quote_identifier(c) for c in (con_data.get("references_columns") or []))
            up = f"ALTER TABLE {table_name} ADD CONSTRAINT {con_name} FOREIGN KEY ({cols}) REFERENCES {ref_table}({ref_cols});"
        elif con_data["type"] == "UNIQUE":
            up = f"ALTER TABLE {table_name} ADD CONSTRAINT {con_name} UNIQUE ({cols});"
        else:
            up = f"-- TODO: Add constraint {con_data['name']}"

        down = f"ALTER TABLE {table_name} DROP CONSTRAINT {con_name};"
        return up, down, []

    def _gen_drop_constraint(self, change: DiffResult) -> tuple[str, str, list[str]]:
        con_data = change.old_value
        table_name = self._quote_identifier(change.table_name)
        con_name = self._quote_identifier(con_data["name"])
        up = f"ALTER TABLE {table_name} DROP CONSTRAINT {con_name};"
        down = f"-- TODO: Recreate constraint {con_data['name']}"
        return up, down, []

    def _gen_change_comment(self, change: DiffResult) -> tuple[str, str, list[str]]:
        table_name = self._quote_identifier(change.table_name)
        new_comment = (change.new_value or "").replace("'", "''")
        old_comment = (change.old_value or "").replace("'", "''")
        up = f"ALTER TABLE {table_name} COMMENT = '{new_comment}';"
        down = f"ALTER TABLE {table_name} COMMENT = '{old_comment}';"
        return up, down, []


class SQLiteGenerator(SQLGenerator):
    """SQLite-specific SQL generator."""

    def _gen_add_table(self, change: DiffResult) -> tuple[str, str, list[str]]:
        table_data = change.new_value
        columns = [self._column_def(c) for c in table_data.get("columns", [])]
        col_str = ",\n    ".join(columns)
        table_name = self._quote_identifier(table_data["name"])
        up = f"CREATE TABLE {table_name} (\n    {col_str}\n);"
        down = f"DROP TABLE IF EXISTS {table_name};"
        return up, down, []

    def _gen_drop_table(self, change: DiffResult) -> tuple[str, str, list[str]]:
        table_data = change.old_value
        table_name = self._quote_identifier(table_data["name"])
        up = f"DROP TABLE IF EXISTS {table_name};"
        columns = [self._column_def(c) for c in table_data.get("columns", [])]
        col_str = ",\n    ".join(columns)
        down = f"CREATE TABLE {table_name} (\n    {col_str}\n);"
        return up, down, ["DESTRUCTIVE: This will permanently delete the table"]

    def _gen_add_column(self, change: DiffResult) -> tuple[str, str, list[str]]:
        col_data = change.new_value
        table_name = self._quote_identifier(change.table_name)
        col_def = self._column_def(col_data)
        up = f"ALTER TABLE {table_name} ADD COLUMN {col_def};"
        down = f"-- SQLite does not support DROP COLUMN before 3.35.0"
        warnings = ["SQLite has limited ALTER TABLE support"]
        return up, down, warnings

    def _gen_drop_column(self, change: DiffResult) -> tuple[str, str, list[str]]:
        col_data = change.old_value
        table_name = self._quote_identifier(change.table_name)
        up = f"ALTER TABLE {table_name} DROP COLUMN {self._quote_identifier(col_data['name'])};"
        down = f"ALTER TABLE {table_name} ADD COLUMN {self._column_def(col_data)};"
        return up, down, ["SQLite DROP COLUMN requires version 3.35.0+"]

    def _gen_alter_column(self, change: DiffResult) -> tuple[str, str, list[str]]:
        return (
            f"-- SQLite does not support ALTER COLUMN. Table recreation needed for {change.table_name}",
            "",
            ["SQLite does not support ALTER COLUMN - manual table recreation required"],
        )

    def _gen_add_index(self, change: DiffResult) -> tuple[str, str, list[str]]:
        idx_data = change.new_value
        table_name = self._quote_identifier(change.table_name)
        idx_name = self._quote_identifier(idx_data["name"])
        unique = "UNIQUE " if idx_data.get("unique") else ""
        cols = ", ".join(self._quote_identifier(c) for c in idx_data["columns"])
        up = f"CREATE {unique}INDEX {idx_name} ON {table_name} ({cols});"
        down = f"DROP INDEX IF EXISTS {idx_name};"
        return up, down, []

    def _gen_drop_index(self, change: DiffResult) -> tuple[str, str, list[str]]:
        idx_data = change.old_value
        table_name = self._quote_identifier(change.table_name)
        idx_name = self._quote_identifier(idx_data["name"])
        unique = "UNIQUE " if idx_data.get("unique") else ""
        cols = ", ".join(self._quote_identifier(c) for c in idx_data["columns"])
        up = f"DROP INDEX IF EXISTS {idx_name};"
        down = f"CREATE {unique}INDEX {idx_name} ON {table_name} ({cols});"
        return up, down, []

    def _gen_add_constraint(self, change: DiffResult) -> tuple[str, str, list[str]]:
        return (
            f"-- SQLite does not support ADD CONSTRAINT. Must recreate table {change.table_name}",
            "",
            ["SQLite does not support ADD CONSTRAINT - manual table recreation required"],
        )

    def _gen_drop_constraint(self, change: DiffResult) -> tuple[str, str, list[str]]:
        return (
            f"-- SQLite does not support DROP CONSTRAINT. Must recreate table {change.table_name}",
            "",
            ["SQLite does not support DROP CONSTRAINT - manual table recreation required"],
        )

    def _gen_change_comment(self, change: DiffResult) -> tuple[str, str, list[str]]:
        return "-- SQLite does not support table comments", "", []
