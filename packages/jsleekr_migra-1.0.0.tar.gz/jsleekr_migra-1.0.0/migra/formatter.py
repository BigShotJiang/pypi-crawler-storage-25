"""SQL formatter - format migration SQL for readability."""

from __future__ import annotations

import re
from typing import Optional


class SQLFormatter:
    """Format SQL for readability."""

    def __init__(self, indent: str = "    ", uppercase_keywords: bool = True) -> None:
        self.indent = indent
        self.uppercase_keywords = uppercase_keywords

    SQL_KEYWORDS = {
        "SELECT", "FROM", "WHERE", "JOIN", "LEFT", "RIGHT", "INNER", "OUTER",
        "ON", "AND", "OR", "NOT", "IN", "EXISTS", "BETWEEN", "LIKE", "IS",
        "NULL", "TRUE", "FALSE", "INSERT", "INTO", "VALUES", "UPDATE", "SET",
        "DELETE", "CREATE", "ALTER", "DROP", "TABLE", "INDEX", "VIEW",
        "COLUMN", "ADD", "MODIFY", "CHANGE", "RENAME", "PRIMARY", "KEY",
        "FOREIGN", "REFERENCES", "UNIQUE", "CHECK", "CONSTRAINT", "DEFAULT",
        "NOT NULL", "CASCADE", "RESTRICT", "IF", "EXISTS", "BEGIN", "COMMIT",
        "ROLLBACK", "GRANT", "REVOKE", "TYPE", "CONCURRENTLY",
    }

    def format(self, sql: str) -> str:
        """Format SQL string."""
        if not sql.strip():
            return sql

        statements = self._split_statements(sql)
        formatted = []

        for stmt in statements:
            stmt = stmt.strip()
            if not stmt:
                continue
            formatted_stmt = self._format_statement(stmt)
            formatted.append(formatted_stmt)

        return "\n\n".join(formatted)

    def format_create_table(self, sql: str) -> str:
        """Format a CREATE TABLE statement."""
        # Find the column definitions
        match = re.match(
            r"(CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?\S+)\s*\(\s*(.*)\s*\)(.*)",
            sql, re.IGNORECASE | re.DOTALL,
        )
        if not match:
            return sql

        header = match.group(1).strip()
        body = match.group(2).strip()
        suffix = match.group(3).strip()

        if self.uppercase_keywords:
            header = self._uppercase_keywords_in(header)

        # Split column definitions
        parts = self._split_column_defs(body)
        formatted_parts = [f"{self.indent}{p.strip()}" for p in parts if p.strip()]

        result = f"{header} (\n" + ",\n".join(formatted_parts) + "\n)"
        if suffix:
            result += f" {suffix}"
        if not result.endswith(";"):
            result += ";"
        return result

    def _format_statement(self, sql: str) -> str:
        """Format a single SQL statement."""
        upper = sql.upper().strip()

        if upper.startswith("CREATE TABLE"):
            return self.format_create_table(sql)

        if self.uppercase_keywords:
            sql = self._uppercase_keywords_in(sql)

        if not sql.endswith(";"):
            sql += ";"

        return sql

    def _uppercase_keywords_in(self, sql: str) -> str:
        """Uppercase SQL keywords in a string, preserving string literals."""
        # Split SQL into quoted and unquoted segments
        segments: list[str] = []
        i = 0
        n = len(sql)
        while i < n:
            if sql[i] == "'":
                # Find matching closing quote (handle '' escapes)
                j = i + 1
                while j < n:
                    if sql[j] == "'":
                        if j + 1 < n and sql[j + 1] == "'":
                            j += 2  # skip escaped quote
                        else:
                            j += 1
                            break
                    else:
                        j += 1
                # Keep string literal as-is
                segments.append(sql[i:j])
                i = j
            else:
                # Consume non-quoted segment up to next quote
                j = sql.find("'", i)
                if j == -1:
                    j = n
                segment = sql[i:j]
                # Uppercase keywords only in non-quoted text
                # Use re.sub with a word-boundary approach to preserve whitespace
                def _upper_kw(m: re.Match) -> str:
                    word = m.group(0)
                    clean = word.strip("(),;")
                    if clean.upper() in self.SQL_KEYWORDS:
                        return word.upper()
                    return word
                segments.append(re.sub(r"\S+", _upper_kw, segment))
                i = j
        return "".join(segments)

    def _split_statements(self, sql: str) -> list[str]:
        """Split SQL into statements, respecting string literals."""
        parts = []
        current = ""
        depth = 0
        in_string = False
        i = 0
        n = len(sql)

        while i < n:
            char = sql[i]

            if char == "-" and not in_string and i + 1 < n and sql[i + 1] == "-":
                # Line comment - skip to end of line
                end = sql.find("\n", i)
                if end == -1:
                    current += sql[i:]
                    break
                current += sql[i:end + 1]
                i = end + 1
                continue

            if char == "'" and not in_string:
                in_string = True
                current += char
                i += 1
            elif char == "'" and in_string:
                current += char
                # Handle '' escape
                if i + 1 < n and sql[i + 1] == "'":
                    current += sql[i + 1]
                    i += 2
                else:
                    in_string = False
                    i += 1
            elif not in_string:
                if char == "(":
                    depth += 1
                elif char == ")":
                    depth -= 1
                elif char == ";" and depth == 0:
                    parts.append(current.strip())
                    current = ""
                    i += 1
                    continue
                current += char
                i += 1
            else:
                current += char
                i += 1

        if current.strip():
            parts.append(current.strip())

        return parts

    def _split_column_defs(self, body: str) -> list[str]:
        """Split column definitions, respecting parentheses and string literals."""
        parts = []
        current = ""
        depth = 0
        in_string = False
        i = 0
        n = len(body)

        while i < n:
            ch = body[i]
            if ch == "'" and not in_string:
                in_string = True
                current += ch
                i += 1
            elif ch == "'" and in_string:
                current += ch
                if i + 1 < n and body[i + 1] == "'":
                    current += body[i + 1]
                    i += 2
                else:
                    in_string = False
                    i += 1
            elif not in_string:
                if ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                elif ch == "," and depth == 0:
                    parts.append(current)
                    current = ""
                    i += 1
                    continue
                current += ch
                i += 1
            else:
                current += ch
                i += 1

        if current.strip():
            parts.append(current)

        return parts

    def add_semicolons(self, sql: str) -> str:
        """Ensure all statements end with semicolons."""
        statements = self._split_statements(sql)
        return "\n\n".join(
            s.rstrip(";").strip() + ";" for s in statements if s.strip()
        )

    def remove_comments(self, sql: str) -> str:
        """Remove SQL comments while preserving string literal contents."""
        result: list[str] = []
        i = 0
        n = len(sql)

        while i < n:
            if sql[i] == "'":
                # String literal -- copy verbatim until closing quote
                j = i + 1
                while j < n:
                    if sql[j] == "'":
                        if j + 1 < n and sql[j + 1] == "'":
                            j += 2  # skip escaped quote
                        else:
                            j += 1
                            break
                    else:
                        j += 1
                result.append(sql[i:j])
                i = j
            elif sql[i] == "-" and i + 1 < n and sql[i + 1] == "-":
                # Line comment -- skip to end of line
                end = sql.find("\n", i)
                if end == -1:
                    break
                i = end  # keep the newline
            elif sql[i:i + 2] == "/*":
                # Block comment -- skip to closing */
                end = sql.find("*/", i + 2)
                if end == -1:
                    break
                i = end + 2
            else:
                result.append(sql[i])
                i += 1

        text = "".join(result)
        # Clean up extra whitespace
        text = re.sub(r"\n\s*\n", "\n\n", text)
        return text.strip()
