"""Schema normalization - standardize types and naming across dialects."""

from __future__ import annotations

import re
from typing import Optional

from migra.schema import Column, Schema, Table


# Type mappings for normalization
TYPE_ALIASES: dict[str, str] = {
    "INT": "INTEGER",
    "INT4": "INTEGER",
    "INT8": "BIGINT",
    "INT2": "SMALLINT",
    "BOOL": "BOOLEAN",
    "FLOAT4": "FLOAT",
    "FLOAT8": "DOUBLE",
    "REAL": "FLOAT",
    "DOUBLE PRECISION": "DOUBLE",
    "CHARACTER VARYING": "VARCHAR",
    "CHARACTER": "CHAR",
    "VARYING": "VARCHAR",
    "TIMESTAMP WITHOUT TIME ZONE": "TIMESTAMP",
    "TIMESTAMP WITH TIME ZONE": "TIMESTAMPTZ",
    "TIME WITHOUT TIME ZONE": "TIME",
    "TIME WITH TIME ZONE": "TIMETZ",
    "STRING": "TEXT",
    "CLOB": "TEXT",
    "NVARCHAR": "VARCHAR",
    "NCHAR": "CHAR",
    "NTEXT": "TEXT",
    "TINYINT": "SMALLINT",
    "MEDIUMINT": "INTEGER",
    "LONGTEXT": "TEXT",
    "MEDIUMTEXT": "TEXT",
    "TINYTEXT": "TEXT",
    "LONGBLOB": "BLOB",
    "MEDIUMBLOB": "BLOB",
    "TINYBLOB": "BLOB",
    "VARBINARY": "BYTEA",
    "BINARY": "BYTEA",
    "DATETIME": "TIMESTAMP",
    "NUMBER": "NUMERIC",
    "MONEY": "DECIMAL",
}

# Auto-increment type normalization
SERIAL_TYPES: dict[str, tuple[str, bool]] = {
    "SERIAL": ("INTEGER", True),
    "BIGSERIAL": ("BIGINT", True),
    "SMALLSERIAL": ("SMALLINT", True),
}


class SchemaNormalizer:
    """Normalize schemas for consistent comparison."""

    def __init__(self, target_dialect: str = "postgresql") -> None:
        self.target_dialect = target_dialect

    def normalize(self, schema: Schema) -> Schema:
        """Normalize the entire schema."""
        normalized_tables = [self._normalize_table(t) for t in schema.tables]
        return Schema(
            name=schema.name,
            tables=normalized_tables,
            version=schema.version,
            metadata=schema.metadata,
        )

    def _normalize_table(self, table: Table) -> Table:
        """Normalize a table."""
        return Table(
            name=self._normalize_name(table.name),
            schema=table.schema,
            columns=[self._normalize_column(c) for c in table.columns],
            indexes=table.indexes,
            constraints=table.constraints,
            comment=table.comment,
        )

    def _normalize_column(self, col: Column) -> Column:
        """Normalize a column."""
        norm_type = self._normalize_type(col.type)
        auto_inc = col.auto_increment

        # Handle SERIAL types
        if col.type.upper() in SERIAL_TYPES:
            norm_type, auto_inc = SERIAL_TYPES[col.type.upper()]

        return Column(
            name=self._normalize_name(col.name),
            type=norm_type,
            nullable=col.nullable,
            default=col.default,
            primary_key=col.primary_key,
            unique=col.unique,
            references=col.references,
            comment=col.comment,
            max_length=col.max_length,
            precision=col.precision,
            scale=col.scale,
            auto_increment=auto_inc,
        )

    def _normalize_type(self, type_str: str) -> str:
        """Normalize a column type."""
        upper = type_str.upper().strip()

        # Check aliases
        if upper in TYPE_ALIASES:
            return TYPE_ALIASES[upper]

        # Check SERIAL types
        if upper in SERIAL_TYPES:
            return SERIAL_TYPES[upper][0]

        return upper

    def _normalize_name(self, name: str) -> str:
        """Normalize an identifier name."""
        # Remove quotes
        name = name.strip('"').strip('`').strip("'")
        return name

    def normalize_type_for_comparison(self, type_a: str, type_b: str) -> bool:
        """Check if two types are equivalent after normalization."""
        return self._normalize_type(type_a) == self._normalize_type(type_b)
