"""Unified schema loader - supports JSON, YAML, and SQL formats."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import yaml

from migra.parser import SQLParser
from migra.schema import Schema


class SchemaLoader:
    """Load schemas from various file formats."""

    def __init__(self, dialect: str = "postgresql") -> None:
        self.dialect = dialect

    def load(self, path: str | Path) -> Schema:
        """Load schema from a file, auto-detecting format."""
        filepath = Path(path)
        if not filepath.exists():
            raise FileNotFoundError(f"Schema file not found: {path}")

        content = filepath.read_text(encoding="utf-8")
        suffix = filepath.suffix.lower()

        if suffix == ".json":
            return self.from_json(content)
        elif suffix in (".yml", ".yaml"):
            return self.from_yaml(content)
        elif suffix in (".sql", ".ddl"):
            return self.from_sql(content)
        else:
            raise ValueError(f"Unsupported file format: {suffix}")

    def from_json(self, content: str) -> Schema:
        """Parse JSON schema."""
        data = json.loads(content)
        return Schema.from_dict(data)

    def from_yaml(self, content: str) -> Schema:
        """Parse YAML schema."""
        data = yaml.safe_load(content)
        if data is None:
            return Schema()
        return Schema.from_dict(data)

    def from_sql(self, content: str) -> Schema:
        """Parse SQL DDL."""
        parser = SQLParser(dialect=self.dialect)
        return parser.parse(content)

    def save(self, schema: Schema, path: str | Path, fmt: Optional[str] = None) -> None:
        """Save schema to a file."""
        filepath = Path(path)
        if fmt is None:
            fmt = filepath.suffix.lstrip(".").lower()

        if fmt == "json":
            content = json.dumps(schema.to_dict(), indent=2)
        elif fmt in ("yml", "yaml"):
            content = yaml.dump(schema.to_dict(), default_flow_style=False, sort_keys=False)
        else:
            raise ValueError(f"Unsupported output format: {fmt}")

        filepath.write_text(content, encoding="utf-8")
