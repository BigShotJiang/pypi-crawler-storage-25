"""Schema comparison and migration report generation."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

from migra.diff import DiffResult, RiskLevel, SchemaDiff
from migra.migration import Migration, MigrationManager
from migra.schema import Schema


@dataclass
class DiffReport:
    """Comprehensive diff report."""
    source_name: str
    target_name: str
    timestamp: str = ""
    changes: list[dict[str, Any]] = field(default_factory=list)
    summary: dict[str, int] = field(default_factory=dict)
    risk_breakdown: dict[str, int] = field(default_factory=dict)
    affected_tables: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    max_risk: str = "SAFE"
    total_changes: int = 0

    def __post_init__(self) -> None:
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> dict[str, Any]:
        return {
            "source": self.source_name,
            "target": self.target_name,
            "timestamp": self.timestamp,
            "total_changes": self.total_changes,
            "max_risk": self.max_risk,
            "summary": self.summary,
            "risk_breakdown": self.risk_breakdown,
            "affected_tables": self.affected_tables,
            "changes": self.changes,
            "warnings": self.warnings,
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    def to_markdown(self) -> str:
        """Generate Markdown report."""
        lines = [
            f"# Schema Diff Report",
            f"",
            f"**Generated:** {self.timestamp}",
            f"**Source:** {self.source_name}",
            f"**Target:** {self.target_name}",
            f"**Total Changes:** {self.total_changes}",
            f"**Max Risk:** {self.max_risk}",
            f"",
            f"## Summary",
            f"",
        ]

        if self.summary:
            lines.append("| Change Type | Count |")
            lines.append("|------------|-------|")
            for change_type, count in sorted(self.summary.items()):
                lines.append(f"| {change_type} | {count} |")
            lines.append("")

        if self.risk_breakdown:
            lines.append("## Risk Breakdown")
            lines.append("")
            lines.append("| Risk Level | Count |")
            lines.append("|-----------|-------|")
            for risk, count in sorted(self.risk_breakdown.items()):
                lines.append(f"| {risk} | {count} |")
            lines.append("")

        if self.affected_tables:
            lines.append("## Affected Tables")
            lines.append("")
            for table in sorted(self.affected_tables):
                lines.append(f"- {table}")
            lines.append("")

        if self.changes:
            lines.append("## Changes")
            lines.append("")
            for i, change in enumerate(self.changes, 1):
                risk = change.get("risk_level", "SAFE")
                desc = change.get("description", "")
                lines.append(f"{i}. **[{risk}]** {desc}")
            lines.append("")

        if self.warnings:
            lines.append("## Warnings")
            lines.append("")
            for w in self.warnings:
                lines.append(f"- {w}")

        return "\n".join(lines)


class ReportGenerator:
    """Generate reports from schema diffs."""

    def generate_diff_report(
        self,
        diff: SchemaDiff,
        source_name: str = "source",
        target_name: str = "target",
    ) -> DiffReport:
        """Generate a diff report."""
        if not diff._computed:
            diff.compute()

        risk_breakdown: dict[str, int] = {}
        for change in diff.changes:
            risk = change.risk_level.value
            risk_breakdown[risk] = risk_breakdown.get(risk, 0) + 1

        return DiffReport(
            source_name=source_name,
            target_name=target_name,
            changes=[c.to_dict() for c in diff.changes],
            summary=diff.summary(),
            risk_breakdown=risk_breakdown,
            affected_tables=sorted(diff.affected_tables()),
            max_risk=diff.max_risk.value,
            total_changes=len(diff.changes),
        )

    def generate_migration_report(self, manager: MigrationManager) -> dict[str, Any]:
        """Generate a migration status report."""
        status = manager.status_report()
        checksum_issues = manager.validate_checksums()

        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "status": status,
            "checksum_issues": checksum_issues,
            "health": "healthy" if not checksum_issues else "degraded",
        }
