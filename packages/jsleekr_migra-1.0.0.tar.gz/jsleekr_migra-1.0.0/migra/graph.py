"""Migration dependency graph and topological sorting."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from migra.migration import Migration


@dataclass
class MigrationNode:
    """A node in the migration dependency graph."""
    migration: Migration
    depends_on: set[str] = field(default_factory=set)
    dependents: set[str] = field(default_factory=set)

    @property
    def id(self) -> str:
        return self.migration.id


class MigrationGraph:
    """Dependency graph for migrations."""

    def __init__(self) -> None:
        self.nodes: dict[str, MigrationNode] = {}

    def add_migration(self, migration: Migration) -> None:
        """Add a migration to the graph."""
        node = MigrationNode(
            migration=migration,
            depends_on=set(migration.depends_on),
        )
        self.nodes[migration.id] = node

        # Update dependents
        for dep_id in migration.depends_on:
            if dep_id in self.nodes:
                self.nodes[dep_id].dependents.add(migration.id)

        # Update existing nodes that depend on this
        for other in self.nodes.values():
            if migration.id in other.depends_on:
                node.dependents.add(other.id)

    def remove_migration(self, migration_id: str) -> Optional[Migration]:
        """Remove a migration from the graph."""
        node = self.nodes.pop(migration_id, None)
        if not node:
            return None

        # Clean up references
        for dep_id in node.depends_on:
            if dep_id in self.nodes:
                self.nodes[dep_id].dependents.discard(migration_id)

        for dep_id in node.dependents:
            if dep_id in self.nodes:
                self.nodes[dep_id].depends_on.discard(migration_id)

        return node.migration

    def get_execution_order(self) -> list[Migration]:
        """Get migrations in topological order (dependencies first)."""
        if not self.nodes:
            return []

        # Kahn's algorithm
        in_degree: dict[str, int] = {}
        for node_id, node in self.nodes.items():
            in_degree[node_id] = len(node.depends_on & set(self.nodes.keys()))

        queue = sorted([nid for nid, deg in in_degree.items() if deg == 0])
        result: list[Migration] = []

        while queue:
            current = queue.pop(0)
            result.append(self.nodes[current].migration)

            for dependent in sorted(self.nodes[current].dependents):
                if dependent in in_degree:
                    in_degree[dependent] -= 1
                    if in_degree[dependent] == 0:
                        queue.append(dependent)

        if len(result) != len(self.nodes):
            cycle_nodes = set(self.nodes.keys()) - {m.id for m in result}
            raise ValueError(f"Circular dependency detected involving: {', '.join(sorted(cycle_nodes))}")

        return result

    def get_rollback_order(self) -> list[Migration]:
        """Get migrations in reverse topological order (dependents first)."""
        return list(reversed(self.get_execution_order()))

    def get_dependencies(self, migration_id: str) -> set[str]:
        """Get all transitive dependencies of a migration."""
        if migration_id not in self.nodes:
            return set()

        visited: set[str] = set()

        def dfs(node_id: str) -> None:
            for dep_id in self.nodes.get(node_id, MigrationNode(Migration(id="", version="", name=""))).depends_on:
                if dep_id not in visited and dep_id in self.nodes:
                    visited.add(dep_id)
                    dfs(dep_id)

        dfs(migration_id)
        return visited

    def get_dependents(self, migration_id: str) -> set[str]:
        """Get all transitive dependents of a migration."""
        if migration_id not in self.nodes:
            return set()

        visited: set[str] = set()

        def dfs(node_id: str) -> None:
            for dep_id in self.nodes.get(node_id, MigrationNode(Migration(id="", version="", name=""))).dependents:
                if dep_id not in visited and dep_id in self.nodes:
                    visited.add(dep_id)
                    dfs(dep_id)

        dfs(migration_id)
        return visited

    def is_safe_to_rollback(self, migration_id: str) -> tuple[bool, list[str]]:
        """Check if a migration can be safely rolled back."""
        dependents = self.get_dependents(migration_id)
        applied_dependents = [
            d for d in dependents
            if self.nodes[d].migration.status.value == "APPLIED"
        ]
        return len(applied_dependents) == 0, applied_dependents

    def find_roots(self) -> list[str]:
        """Find migrations with no dependencies."""
        return sorted([
            nid for nid, node in self.nodes.items()
            if not (node.depends_on & set(self.nodes.keys()))
        ])

    def find_leaves(self) -> list[str]:
        """Find migrations with no dependents."""
        return sorted([
            nid for nid, node in self.nodes.items()
            if not node.dependents
        ])

    def validate(self) -> list[str]:
        """Validate the graph for issues."""
        issues = []

        # Check for missing dependencies
        for node_id, node in self.nodes.items():
            for dep_id in node.depends_on:
                if dep_id not in self.nodes:
                    issues.append(f"Migration {node_id} depends on missing migration {dep_id}")

        # Check for cycles
        try:
            self.get_execution_order()
        except ValueError as e:
            issues.append(str(e))

        return issues

    def subgraph(self, migration_ids: set[str]) -> MigrationGraph:
        """Create a subgraph with only specified migrations."""
        sub = MigrationGraph()
        for mid in migration_ids:
            if mid in self.nodes:
                sub.add_migration(self.nodes[mid].migration)
        return sub

    def __len__(self) -> int:
        return len(self.nodes)

    def __contains__(self, migration_id: str) -> bool:
        return migration_id in self.nodes
