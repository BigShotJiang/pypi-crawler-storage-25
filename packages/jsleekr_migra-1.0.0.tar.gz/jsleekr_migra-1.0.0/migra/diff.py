"""Schema diffing engine."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

from migra.schema import Column, Constraint, Index, Schema, Table


class ChangeType(str, Enum):
    """Types of schema changes."""
    ADD_TABLE = "ADD_TABLE"
    DROP_TABLE = "DROP_TABLE"
    RENAME_TABLE = "RENAME_TABLE"
    ADD_COLUMN = "ADD_COLUMN"
    DROP_COLUMN = "DROP_COLUMN"
    ALTER_COLUMN = "ALTER_COLUMN"
    RENAME_COLUMN = "RENAME_COLUMN"
    ADD_INDEX = "ADD_INDEX"
    DROP_INDEX = "DROP_INDEX"
    ALTER_INDEX = "ALTER_INDEX"
    ADD_CONSTRAINT = "ADD_CONSTRAINT"
    DROP_CONSTRAINT = "DROP_CONSTRAINT"
    ALTER_CONSTRAINT = "ALTER_CONSTRAINT"
    CHANGE_COMMENT = "CHANGE_COMMENT"


class RiskLevel(str, Enum):
    """Risk level for a change."""
    SAFE = "SAFE"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    DESTRUCTIVE = "DESTRUCTIVE"


@dataclass
class DiffResult:
    """A single schema change."""
    change_type: ChangeType
    table_name: str
    table_schema: str = "public"
    object_name: Optional[str] = None  # column/index/constraint name
    old_value: Optional[Any] = None
    new_value: Optional[Any] = None
    risk_level: RiskLevel = RiskLevel.SAFE
    description: str = ""
    reversible: bool = True

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "change_type": self.change_type.value,
            "table_name": self.table_name,
            "table_schema": self.table_schema,
            "risk_level": self.risk_level.value,
            "description": self.description,
            "reversible": self.reversible,
        }
        if self.object_name:
            d["object_name"] = self.object_name
        if self.old_value is not None:
            d["old_value"] = self.old_value
        if self.new_value is not None:
            d["new_value"] = self.new_value
        return d

    @property
    def qualified_table(self) -> str:
        return f"{self.table_schema}.{self.table_name}"

    def __str__(self) -> str:
        return f"[{self.risk_level.value}] {self.change_type.value}: {self.description}"


@dataclass
class SchemaDiff:
    """Compares two schemas and produces a list of changes."""
    source: Schema
    target: Schema
    changes: list[DiffResult] = field(default_factory=list)
    _computed: bool = False

    def compute(self) -> list[DiffResult]:
        """Compute all differences between source and target."""
        if self._computed:
            return self.changes

        self.changes = []
        self._diff_tables()
        self._computed = True
        return self.changes

    def _diff_tables(self) -> None:
        source_tables = {(t.schema, t.name): t for t in self.source.tables}
        target_tables = {(t.schema, t.name): t for t in self.target.tables}

        source_keys = set(source_tables.keys())
        target_keys = set(target_tables.keys())

        # Tables added in target
        for key in sorted(target_keys - source_keys):
            table = target_tables[key]
            self.changes.append(DiffResult(
                change_type=ChangeType.ADD_TABLE,
                table_name=table.name,
                table_schema=table.schema,
                new_value=table.to_dict(),
                risk_level=RiskLevel.SAFE,
                description=f"Create table {table.schema}.{table.name}",
                reversible=True,
            ))

        # Tables dropped from source
        for key in sorted(source_keys - target_keys):
            table = source_tables[key]
            self.changes.append(DiffResult(
                change_type=ChangeType.DROP_TABLE,
                table_name=table.name,
                table_schema=table.schema,
                old_value=table.to_dict(),
                risk_level=RiskLevel.DESTRUCTIVE,
                description=f"Drop table {table.schema}.{table.name}",
                reversible=False,
            ))

        # Tables that exist in both
        for key in sorted(source_keys & target_keys):
            self._diff_table(source_tables[key], target_tables[key])

    def _diff_table(self, source: Table, target: Table) -> None:
        """Diff columns, indexes, and constraints of a table."""
        self._diff_columns(source, target)
        self._diff_indexes(source, target)
        self._diff_constraints(source, target)

        # Comment changes
        if source.comment != target.comment:
            self.changes.append(DiffResult(
                change_type=ChangeType.CHANGE_COMMENT,
                table_name=target.name,
                table_schema=target.schema,
                old_value=source.comment,
                new_value=target.comment,
                risk_level=RiskLevel.SAFE,
                description=f"Change comment on {target.schema}.{target.name}",
            ))

    def _diff_columns(self, source: Table, target: Table) -> None:
        source_cols = {c.name: c for c in source.columns}
        target_cols = {c.name: c for c in target.columns}

        # Added columns
        for name in sorted(set(target_cols) - set(source_cols)):
            col = target_cols[name]
            risk = RiskLevel.SAFE
            if not col.nullable and col.default is None:
                risk = RiskLevel.HIGH
            self.changes.append(DiffResult(
                change_type=ChangeType.ADD_COLUMN,
                table_name=target.name,
                table_schema=target.schema,
                object_name=name,
                new_value=col.to_dict(),
                risk_level=risk,
                description=f"Add column {name} to {target.schema}.{target.name}",
            ))

        # Dropped columns
        for name in sorted(set(source_cols) - set(target_cols)):
            col = source_cols[name]
            self.changes.append(DiffResult(
                change_type=ChangeType.DROP_COLUMN,
                table_name=source.name,
                table_schema=source.schema,
                object_name=name,
                old_value=col.to_dict(),
                risk_level=RiskLevel.DESTRUCTIVE,
                description=f"Drop column {name} from {source.schema}.{source.name}",
                reversible=False,
            ))

        # Modified columns
        for name in sorted(set(source_cols) & set(target_cols)):
            self._diff_column(source, source_cols[name], target_cols[name])

    def _diff_column(self, table: Table, source: Column, target: Column) -> None:
        if source.fingerprint() == target.fingerprint():
            return

        changes: list[str] = []
        risk = RiskLevel.LOW

        if source.type != target.type:
            changes.append(f"type: {source.type} -> {target.type}")
            risk = RiskLevel.MEDIUM

        if source.nullable != target.nullable:
            if target.nullable:
                changes.append("nullable: false -> true")
            else:
                changes.append("nullable: true -> false")
                risk = RiskLevel.HIGH

        if source.default != target.default:
            changes.append(f"default: {source.default} -> {target.default}")

        if source.max_length != target.max_length:
            changes.append(f"max_length: {source.max_length} -> {target.max_length}")
            if target.max_length is not None and source.max_length is not None:
                if target.max_length < source.max_length:
                    risk = RiskLevel.HIGH

        if source.precision != target.precision:
            changes.append(f"precision: {source.precision} -> {target.precision}")

        if source.scale != target.scale:
            changes.append(f"scale: {source.scale} -> {target.scale}")

        if source.primary_key != target.primary_key:
            changes.append(f"primary_key: {source.primary_key} -> {target.primary_key}")
            risk = RiskLevel.HIGH

        if source.unique != target.unique:
            changes.append(f"unique: {source.unique} -> {target.unique}")

        if source.references != target.references:
            changes.append(f"references: {source.references} -> {target.references}")

        if source.auto_increment != target.auto_increment:
            changes.append(f"auto_increment: {source.auto_increment} -> {target.auto_increment}")

        if changes:
            self.changes.append(DiffResult(
                change_type=ChangeType.ALTER_COLUMN,
                table_name=table.name,
                table_schema=table.schema,
                object_name=source.name,
                old_value=source.to_dict(),
                new_value=target.to_dict(),
                risk_level=risk,
                description=f"Alter column {source.name} on {table.schema}.{table.name}: {'; '.join(changes)}",
            ))

    def _diff_indexes(self, source: Table, target: Table) -> None:
        source_idxs = {i.name: i for i in source.indexes}
        target_idxs = {i.name: i for i in target.indexes}

        for name in sorted(set(target_idxs) - set(source_idxs)):
            idx = target_idxs[name]
            self.changes.append(DiffResult(
                change_type=ChangeType.ADD_INDEX,
                table_name=target.name,
                table_schema=target.schema,
                object_name=name,
                new_value=idx.to_dict(),
                risk_level=RiskLevel.LOW,
                description=f"Create index {name} on {target.schema}.{target.name}",
            ))

        for name in sorted(set(source_idxs) - set(target_idxs)):
            idx = source_idxs[name]
            self.changes.append(DiffResult(
                change_type=ChangeType.DROP_INDEX,
                table_name=source.name,
                table_schema=source.schema,
                object_name=name,
                old_value=idx.to_dict(),
                risk_level=RiskLevel.MEDIUM,
                description=f"Drop index {name} from {source.schema}.{source.name}",
            ))

        for name in sorted(set(source_idxs) & set(target_idxs)):
            src = source_idxs[name]
            tgt = target_idxs[name]
            if src.fingerprint() != tgt.fingerprint():
                self.changes.append(DiffResult(
                    change_type=ChangeType.ALTER_INDEX,
                    table_name=target.name,
                    table_schema=target.schema,
                    object_name=name,
                    old_value=src.to_dict(),
                    new_value=tgt.to_dict(),
                    risk_level=RiskLevel.MEDIUM,
                    description=f"Alter index {name} on {target.schema}.{target.name}",
                ))

    def _diff_constraints(self, source: Table, target: Table) -> None:
        source_cons = {c.name: c for c in source.constraints}
        target_cons = {c.name: c for c in target.constraints}

        for name in sorted(set(target_cons) - set(source_cons)):
            con = target_cons[name]
            risk = RiskLevel.LOW
            if con.type in ("PRIMARY KEY", "UNIQUE", "NOT NULL"):
                risk = RiskLevel.MEDIUM
            self.changes.append(DiffResult(
                change_type=ChangeType.ADD_CONSTRAINT,
                table_name=target.name,
                table_schema=target.schema,
                object_name=name,
                new_value=con.to_dict(),
                risk_level=risk,
                description=f"Add constraint {name} on {target.schema}.{target.name}",
            ))

        for name in sorted(set(source_cons) - set(target_cons)):
            con = source_cons[name]
            self.changes.append(DiffResult(
                change_type=ChangeType.DROP_CONSTRAINT,
                table_name=source.name,
                table_schema=source.schema,
                object_name=name,
                old_value=con.to_dict(),
                risk_level=RiskLevel.MEDIUM,
                description=f"Drop constraint {name} from {source.schema}.{source.name}",
            ))

        for name in sorted(set(source_cons) & set(target_cons)):
            src = source_cons[name]
            tgt = target_cons[name]
            if src.fingerprint() != tgt.fingerprint():
                self.changes.append(DiffResult(
                    change_type=ChangeType.ALTER_CONSTRAINT,
                    table_name=target.name,
                    table_schema=target.schema,
                    object_name=name,
                    old_value=src.to_dict(),
                    new_value=tgt.to_dict(),
                    risk_level=RiskLevel.MEDIUM,
                    description=f"Alter constraint {name} on {target.schema}.{target.name}",
                ))

    @property
    def has_changes(self) -> bool:
        if not self._computed:
            self.compute()
        return len(self.changes) > 0

    @property
    def has_destructive_changes(self) -> bool:
        if not self._computed:
            self.compute()
        return any(c.risk_level == RiskLevel.DESTRUCTIVE for c in self.changes)

    @property
    def max_risk(self) -> RiskLevel:
        if not self._computed:
            self.compute()
        if not self.changes:
            return RiskLevel.SAFE
        risk_order = [RiskLevel.SAFE, RiskLevel.LOW, RiskLevel.MEDIUM, RiskLevel.HIGH, RiskLevel.DESTRUCTIVE]
        return max((c.risk_level for c in self.changes), key=lambda r: risk_order.index(r))

    def summary(self) -> dict[str, int]:
        """Return counts by change type."""
        if not self._computed:
            self.compute()
        counts: dict[str, int] = {}
        for change in self.changes:
            key = change.change_type.value
            counts[key] = counts.get(key, 0) + 1
        return counts

    def filter_by_risk(self, min_risk: RiskLevel) -> list[DiffResult]:
        """Return changes at or above a risk level."""
        if not self._computed:
            self.compute()
        risk_order = [RiskLevel.SAFE, RiskLevel.LOW, RiskLevel.MEDIUM, RiskLevel.HIGH, RiskLevel.DESTRUCTIVE]
        min_idx = risk_order.index(min_risk)
        return [c for c in self.changes if risk_order.index(c.risk_level) >= min_idx]

    def filter_by_table(self, table_name: str) -> list[DiffResult]:
        """Return changes for a specific table."""
        if not self._computed:
            self.compute()
        return [c for c in self.changes if c.table_name == table_name]

    def affected_tables(self) -> set[str]:
        """Return names of all affected tables."""
        if not self._computed:
            self.compute()
        return {c.table_name for c in self.changes}
