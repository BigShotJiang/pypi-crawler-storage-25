"""CLI interface for migra."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table as RichTable
from rich.text import Text

from migra.config import MigraConfig
from migra.diff import RiskLevel, SchemaDiff
from migra.migration import MigrationManager, MigrationStatus
from migra.parser import SQLParser
from migra.planner import MigrationPlanner
from migra.schema import Schema
from migra.snapshot import SnapshotManager
from migra.validator import MigrationValidator, SchemaValidator

console = Console()


def _load_config(config_path: Optional[str] = None) -> MigraConfig:
    """Load configuration."""
    if config_path:
        return MigraConfig.load(config_path)
    for name in (".migra.yml", ".migra.yaml", ".migra.json"):
        if Path(name).exists():
            return MigraConfig.load(name)
    return MigraConfig()


def _load_schema(path: str, dialect: str = "postgresql") -> Schema:
    """Load schema from a JSON or SQL file."""
    filepath = Path(path)
    if not filepath.exists():
        console.print(f"[red]Error: File not found: {path}[/red]")
        sys.exit(1)

    content = filepath.read_text(encoding="utf-8")

    if filepath.suffix == ".json":
        return Schema.from_json(content)
    elif filepath.suffix in (".sql", ".ddl"):
        parser = SQLParser(dialect=dialect)
        return parser.parse(content)
    elif filepath.suffix in (".yml", ".yaml"):
        import yaml
        data = yaml.safe_load(content)
        return Schema.from_dict(data)
    else:
        console.print(f"[red]Error: Unsupported file format: {filepath.suffix}[/red]")
        sys.exit(1)


@click.group()
@click.option("--config", "-c", help="Config file path")
@click.pass_context
def main(ctx: click.Context, config: Optional[str] = None) -> None:
    """migra - Database schema migration manager."""
    ctx.ensure_object(dict)
    ctx.obj["config"] = _load_config(config)


@main.command()
@click.pass_context
def init(ctx: click.Context) -> None:
    """Initialize migra in the current directory."""
    config = ctx.obj["config"]
    manager = MigrationManager(config.migrations_dir)
    path = manager.init()
    SnapshotManager().init()
    config.save()
    console.print(f"[green]Initialized migra[/green]")
    console.print(f"  Migrations dir: {path}")
    console.print(f"  Config: .migra.yml")


@main.command()
@click.argument("source")
@click.argument("target")
@click.option("--dialect", "-d", default=None, help="SQL dialect")
@click.option("--output", "-o", default=None, help="Output format (text, json)")
@click.pass_context
def diff(ctx: click.Context, source: str, target: str, dialect: Optional[str] = None,
         output: Optional[str] = None) -> None:
    """Compare two schemas and show differences."""
    config = ctx.obj["config"]
    d = dialect or config.dialect

    source_schema = _load_schema(source, d)
    target_schema = _load_schema(target, d)

    schema_diff = SchemaDiff(source=source_schema, target=target_schema)
    changes = schema_diff.compute()

    if output == "json":
        result = {
            "changes": [c.to_dict() for c in changes],
            "summary": schema_diff.summary(),
            "has_destructive": schema_diff.has_destructive_changes,
        }
        console.print_json(json.dumps(result))
        return

    if not changes:
        console.print("[green]No differences found.[/green]")
        return

    console.print(f"\n[bold]Schema Diff: {len(changes)} changes[/bold]\n")

    table = RichTable(show_header=True)
    table.add_column("#", style="dim", width=4)
    table.add_column("Risk", width=12)
    table.add_column("Type", width=20)
    table.add_column("Description")

    risk_colors = {
        RiskLevel.SAFE: "green",
        RiskLevel.LOW: "blue",
        RiskLevel.MEDIUM: "yellow",
        RiskLevel.HIGH: "red",
        RiskLevel.DESTRUCTIVE: "bold red",
    }

    for i, change in enumerate(changes, 1):
        color = risk_colors.get(change.risk_level, "white")
        table.add_row(
            str(i),
            Text(change.risk_level.value, style=color),
            change.change_type.value,
            change.description,
        )

    console.print(table)
    console.print(f"\n[bold]Summary:[/bold] Max risk: [{risk_colors[schema_diff.max_risk]}]{schema_diff.max_risk.value}[/]")


@main.command()
@click.argument("source")
@click.argument("target")
@click.option("--dialect", "-d", default=None, help="SQL dialect")
@click.option("--name", "-n", default=None, help="Migration name")
@click.option("--dry-run", is_flag=True, help="Show SQL without creating files")
@click.pass_context
def plan(ctx: click.Context, source: str, target: str, dialect: Optional[str] = None,
         name: Optional[str] = None, dry_run: bool = False) -> None:
    """Generate migration SQL from schema diff."""
    config = ctx.obj["config"]
    d = dialect or config.dialect

    source_schema = _load_schema(source, d)
    target_schema = _load_schema(target, d)

    schema_diff = SchemaDiff(source=source_schema, target=target_schema)
    schema_diff.compute()

    if not schema_diff.has_changes:
        console.print("[green]No changes to migrate.[/green]")
        return

    planner = MigrationPlanner(dialect=d)
    migration_plan = planner.plan(schema_diff)

    console.print(f"\n[bold]Migration Plan: {migration_plan.total_steps} steps[/bold]")
    console.print(f"Max risk: {migration_plan.max_risk.value}\n")

    console.print(Panel(migration_plan.up_sql, title="UP Migration", border_style="green"))
    console.print(Panel(migration_plan.down_sql, title="DOWN Migration", border_style="red"))

    if migration_plan.warnings:
        console.print("\n[yellow]Warnings:[/yellow]")
        for w in migration_plan.warnings:
            console.print(f"  [yellow]! {w}[/yellow]")

    if not dry_run:
        migration_name = name or f"migration_{'_'.join(schema_diff.affected_tables())}"
        manager = MigrationManager(config.migrations_dir)
        manager.init()
        migration = manager.create_migration(
            name=migration_name,
            up_sql=migration_plan.up_sql,
            down_sql=migration_plan.down_sql,
            description=f"Auto-generated from schema diff ({migration_plan.total_steps} changes)",
        )
        console.print(f"\n[green]Migration created: {migration.id}[/green]")


@main.command()
@click.option("--dialect", "-d", default=None, help="SQL dialect")
@click.pass_context
def status(ctx: click.Context, dialect: Optional[str] = None) -> None:
    """Show migration status."""
    config = ctx.obj["config"]
    manager = MigrationManager(config.migrations_dir)
    manager.load_migrations()

    report = manager.status_report()

    console.print(f"\n[bold]Migration Status[/bold]")
    console.print(f"  Total: {report['total']}")
    console.print(f"  Pending: [yellow]{report['pending']}[/yellow]")
    console.print(f"  Applied: [green]{report['applied']}[/green]")
    console.print(f"  Rolled back: [red]{report['rolled_back']}[/red]")
    console.print(f"  Failed: [bold red]{report['failed']}[/bold red]")

    if report["migrations"]:
        console.print()
        table = RichTable(show_header=True)
        table.add_column("ID", width=35)
        table.add_column("Name", width=25)
        table.add_column("Status", width=12)
        table.add_column("Version", width=15)

        status_colors = {
            "PENDING": "yellow",
            "APPLIED": "green",
            "ROLLED_BACK": "red",
            "FAILED": "bold red",
            "SKIPPED": "dim",
        }

        for m in report["migrations"]:
            color = status_colors.get(m["status"], "white")
            table.add_row(
                m["id"],
                m["name"],
                Text(m["status"], style=color),
                m["version"],
            )

        console.print(table)


@main.command()
@click.option("--dry-run", is_flag=True, help="Show what would be applied")
@click.option("--target", "-t", default=None, help="Apply up to specific migration ID")
@click.pass_context
def apply(ctx: click.Context, dry_run: bool = False, target: Optional[str] = None) -> None:
    """Apply pending migrations."""
    config = ctx.obj["config"]
    manager = MigrationManager(config.migrations_dir)
    manager.load_migrations()

    pending = manager.get_pending()
    if not pending:
        console.print("[green]No pending migrations.[/green]")
        return

    console.print(f"\n[bold]Applying {len(pending)} migration(s)...[/bold]\n")

    results = manager.apply_all(dry_run=dry_run)

    for result in results:
        status_val = result["status"]
        mid = result["migration_id"]
        if status_val == "applied":
            console.print(f"  [green]Applied[/green] {mid} ({result.get('execution_time_ms', 0)}ms)")
        elif status_val == "dry_run":
            console.print(f"  [yellow]Dry run[/yellow] {mid}")
        elif status_val == "blocked":
            console.print(f"  [red]Blocked[/red] {mid}: {result.get('reason', '')}")
        elif status_val == "already_applied":
            console.print(f"  [dim]Skipped[/dim] {mid} (already applied)")


@main.command()
@click.option("--count", "-n", default=1, help="Number of migrations to rollback")
@click.option("--dry-run", is_flag=True, help="Show what would be rolled back")
@click.pass_context
def rollback(ctx: click.Context, count: int = 1, dry_run: bool = False) -> None:
    """Rollback applied migrations."""
    config = ctx.obj["config"]
    manager = MigrationManager(config.migrations_dir)
    manager.load_migrations()

    results = manager.rollback_last(count=count, dry_run=dry_run)

    if not results:
        console.print("[yellow]No migrations to rollback.[/yellow]")
        return

    for result in results:
        status_val = result["status"]
        mid = result["migration_id"]
        if status_val == "rolled_back":
            console.print(f"  [green]Rolled back[/green] {mid}")
        elif status_val == "dry_run":
            console.print(f"  [yellow]Dry run rollback[/yellow] {mid}")
        elif status_val == "no_rollback":
            console.print(f"  [red]No rollback SQL[/red] {mid}: {result.get('reason', '')}")


@main.command()
@click.argument("schema_file")
@click.option("--dialect", "-d", default=None, help="SQL dialect")
@click.option("--output", "-o", default=None, help="Output format (text, json)")
@click.pass_context
def validate(ctx: click.Context, schema_file: str, dialect: Optional[str] = None,
             output: Optional[str] = None) -> None:
    """Validate a schema for best practices."""
    config = ctx.obj["config"]
    d = dialect or config.dialect

    schema = _load_schema(schema_file, d)
    validator = SchemaValidator()
    issues = validator.validate(schema)

    if output == "json":
        console.print_json(json.dumps([i.to_dict() for i in issues]))
        return

    if not issues:
        console.print("[green]No validation issues found.[/green]")
        return

    console.print(f"\n[bold]Validation: {len(issues)} issues[/bold]\n")

    severity_colors = {
        "ERROR": "red",
        "WARNING": "yellow",
        "INFO": "blue",
    }

    for issue in issues:
        color = severity_colors.get(issue.severity.value, "white")
        console.print(f"  [{color}]{issue}[/{color}]")


@main.command()
@click.argument("schema_file")
@click.option("--label", "-l", default=None, help="Snapshot label")
@click.option("--dialect", "-d", default=None, help="SQL dialect")
@click.pass_context
def snapshot(ctx: click.Context, schema_file: str, label: Optional[str] = None,
             dialect: Optional[str] = None) -> None:
    """Save a schema snapshot."""
    config = ctx.obj["config"]
    d = dialect or config.dialect

    schema = _load_schema(schema_file, d)
    snap_mgr = SnapshotManager()
    snap = snap_mgr.save(schema, label=label)

    console.print(f"[green]Snapshot saved: {snap.id}[/green]")
    if label:
        console.print(f"  Label: {label}")
    console.print(f"  Fingerprint: {snap.fingerprint()}")


@main.command()
@click.argument("schema_file")
@click.option("--dialect", "-d", default=None, help="SQL dialect")
@click.pass_context
def drift(ctx: click.Context, schema_file: str, dialect: Optional[str] = None) -> None:
    """Check for schema drift from latest snapshot."""
    config = ctx.obj["config"]
    d = dialect or config.dialect

    schema = _load_schema(schema_file, d)
    snap_mgr = SnapshotManager()

    details = snap_mgr.drift_details(schema)

    if not details.get("drifted"):
        if details.get("reason") == "no_baseline":
            console.print("[yellow]No baseline snapshot found. Run 'migra snapshot' first.[/yellow]")
        else:
            console.print("[green]No drift detected.[/green]")
        return

    console.print(f"\n[bold red]Schema drift detected![/bold red]")
    console.print(f"  Changes: {details['changes']}")
    console.print(f"  Max risk: {details['max_risk']}")
    console.print(f"  Since: {details['snapshot_date']}")

    if details.get("summary"):
        console.print("\n  Change summary:")
        for change_type, count in details["summary"].items():
            console.print(f"    {change_type}: {count}")


@main.command(name="create")
@click.argument("name")
@click.option("--description", "-d", default="", help="Migration description")
@click.pass_context
def create_migration(ctx: click.Context, name: str, description: str = "") -> None:
    """Create an empty migration."""
    config = ctx.obj["config"]
    manager = MigrationManager(config.migrations_dir)
    manager.init()

    migration = manager.create_migration(
        name=name,
        up_sql="-- Add your UP migration SQL here",
        down_sql="-- Add your DOWN migration SQL here",
        description=description,
    )

    console.print(f"[green]Migration created: {migration.id}[/green]")
    filepath = manager.migrations_dir / f"{migration.id}.sql"
    console.print(f"  File: {filepath}")


if __name__ == "__main__":
    main()
