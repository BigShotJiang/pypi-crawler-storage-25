"""Configuration management for migra."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import yaml


@dataclass
class MigraConfig:
    """Configuration for migra."""
    migrations_dir: str = "migrations"
    dialect: str = "postgresql"
    schema_file: Optional[str] = None
    target_schema_file: Optional[str] = None
    auto_confirm: bool = False
    dry_run: bool = False
    allow_destructive: bool = False
    naming_convention: str = "timestamp"  # timestamp, sequential, custom
    environments: dict[str, dict[str, str]] = field(default_factory=dict)
    hooks: dict[str, list[str]] = field(default_factory=dict)

    @classmethod
    def load(cls, path: str | Path = ".migra.yml") -> MigraConfig:
        """Load configuration from file."""
        filepath = Path(path)
        if not filepath.exists():
            return cls()

        content = filepath.read_text(encoding="utf-8")
        if filepath.suffix in (".yml", ".yaml"):
            data = yaml.safe_load(content) or {}
        elif filepath.suffix == ".json":
            data = json.loads(content)
        else:
            return cls()

        return cls.from_dict(data)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MigraConfig:
        return cls(
            migrations_dir=data.get("migrations_dir", "migrations"),
            dialect=data.get("dialect", "postgresql"),
            schema_file=data.get("schema_file"),
            target_schema_file=data.get("target_schema_file"),
            auto_confirm=data.get("auto_confirm", False),
            dry_run=data.get("dry_run", False),
            allow_destructive=data.get("allow_destructive", False),
            naming_convention=data.get("naming_convention", "timestamp"),
            environments=data.get("environments", {}),
            hooks=data.get("hooks", {}),
        )

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "migrations_dir": self.migrations_dir,
            "dialect": self.dialect,
            "auto_confirm": self.auto_confirm,
            "dry_run": self.dry_run,
            "allow_destructive": self.allow_destructive,
            "naming_convention": self.naming_convention,
        }
        if self.schema_file:
            d["schema_file"] = self.schema_file
        if self.target_schema_file:
            d["target_schema_file"] = self.target_schema_file
        if self.environments:
            d["environments"] = self.environments
        if self.hooks:
            d["hooks"] = self.hooks
        return d

    def save(self, path: str | Path = ".migra.yml") -> None:
        """Save configuration to file."""
        filepath = Path(path)
        data = self.to_dict()
        if filepath.suffix in (".yml", ".yaml"):
            content = yaml.dump(data, default_flow_style=False, sort_keys=False)
        else:
            content = json.dumps(data, indent=2)
        filepath.write_text(content, encoding="utf-8")

    def get_environment(self, name: str) -> dict[str, str]:
        """Get environment-specific settings."""
        return self.environments.get(name, {})
