"""Migration management - create, track, and apply migrations."""

from __future__ import annotations

import hashlib
import json
import os
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from migra.schema import Schema


class MigrationStatus(str, Enum):
    """Status of a migration."""
    PENDING = "PENDING"
    APPLIED = "APPLIED"
    ROLLED_BACK = "ROLLED_BACK"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"


@dataclass
class Migration:
    """Represents a single migration."""
    id: str
    version: str
    name: str
    description: str = ""
    up_sql: str = ""
    down_sql: str = ""
    status: MigrationStatus = MigrationStatus.PENDING
    checksum: str = ""
    created_at: str = ""
    applied_at: Optional[str] = None
    execution_time_ms: Optional[int] = None
    depends_on: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()
        if not self.checksum:
            self.checksum = self._compute_checksum()

    def _compute_checksum(self) -> str:
        content = f"{self.up_sql}\n---\n{self.down_sql}"
        return hashlib.sha256(content.encode()).hexdigest()[:16]

    def validate_checksum(self) -> bool:
        return self.checksum == self._compute_checksum()

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "version": self.version,
            "name": self.name,
            "description": self.description,
            "up_sql": self.up_sql,
            "down_sql": self.down_sql,
            "status": self.status.value,
            "checksum": self.checksum,
            "created_at": self.created_at,
            "applied_at": self.applied_at,
            "execution_time_ms": self.execution_time_ms,
            "depends_on": self.depends_on,
            "tags": self.tags,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Migration:
        return cls(
            id=data["id"],
            version=data["version"],
            name=data["name"],
            description=data.get("description", ""),
            up_sql=data.get("up_sql", ""),
            down_sql=data.get("down_sql", ""),
            status=MigrationStatus(data.get("status", "PENDING")),
            checksum=data.get("checksum", ""),
            created_at=data.get("created_at", ""),
            applied_at=data.get("applied_at"),
            execution_time_ms=data.get("execution_time_ms"),
            depends_on=data.get("depends_on", []),
            tags=data.get("tags", []),
        )

    def to_sql_file(self) -> str:
        """Generate SQL file content."""
        lines = [
            f"-- Migration: {self.id}",
            f"-- Version: {self.version}",
            f"-- Name: {self.name}",
            f"-- Description: {self.description}",
            f"-- Created: {self.created_at}",
            f"-- Checksum: {self.checksum}",
            "",
            "-- +migrate Up",
            self.up_sql,
            "",
            "-- +migrate Down",
            self.down_sql,
            "",
        ]
        return "\n".join(lines)

    @classmethod
    def from_sql_file(cls, content: str, filename: str = "") -> Migration:
        """Parse a SQL migration file."""
        meta: dict[str, str] = {}
        for line in content.split("\n"):
            line = line.strip()
            if line.startswith("-- Migration:"):
                meta["id"] = line.split(":", 1)[1].strip()
            elif line.startswith("-- Version:"):
                meta["version"] = line.split(":", 1)[1].strip()
            elif line.startswith("-- Name:"):
                meta["name"] = line.split(":", 1)[1].strip()
            elif line.startswith("-- Description:"):
                meta["description"] = line.split(":", 1)[1].strip()
            elif line.startswith("-- Created:"):
                meta["created_at"] = line.split(":", 1)[1].strip()
            elif line.startswith("-- Checksum:"):
                meta["checksum"] = line.split(":", 1)[1].strip()

        # Split up/down
        up_sql = ""
        down_sql = ""
        section = None
        for line in content.split("\n"):
            stripped = line.strip()
            if stripped == "-- +migrate Up":
                section = "up"
                continue
            elif stripped == "-- +migrate Down":
                section = "down"
                continue

            if section == "up":
                up_sql += line + "\n"
            elif section == "down":
                down_sql += line + "\n"

        # Extract version from filename if not in metadata
        version = meta.get("version", "")
        if not version and filename:
            match = re.match(r"^(\d+)", Path(filename).stem)
            if match:
                version = match.group(1)

        migration_id = meta.get("id", "")
        if not migration_id and filename:
            migration_id = Path(filename).stem

        return cls(
            id=migration_id,
            version=version,
            name=meta.get("name", migration_id),
            description=meta.get("description", ""),
            up_sql=up_sql.strip(),
            down_sql=down_sql.strip(),
            created_at=meta.get("created_at", ""),
            checksum=meta.get("checksum", ""),
        )


class MigrationManager:
    """Manages a set of migrations."""

    def __init__(self, migrations_dir: str | Path = "migrations") -> None:
        self.migrations_dir = Path(migrations_dir)
        self.migrations: list[Migration] = []
        self.history_file = self.migrations_dir / ".migra_history.json"

    def init(self) -> Path:
        """Initialize migrations directory."""
        self.migrations_dir.mkdir(parents=True, exist_ok=True)
        if not self.history_file.exists():
            self._save_history()
        return self.migrations_dir

    def create_migration(
        self,
        name: str,
        up_sql: str = "",
        down_sql: str = "",
        description: str = "",
        depends_on: Optional[list[str]] = None,
        tags: Optional[list[str]] = None,
    ) -> Migration:
        """Create a new migration."""
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
        safe_name = re.sub(r"[^a-zA-Z0-9_]", "_", name.lower())
        migration_id = f"{timestamp}_{safe_name}"
        version = timestamp

        migration = Migration(
            id=migration_id,
            version=version,
            name=name,
            description=description,
            up_sql=up_sql,
            down_sql=down_sql,
            depends_on=depends_on or [],
            tags=tags or [],
        )

        # Save to file
        self.migrations_dir.mkdir(parents=True, exist_ok=True)
        filepath = self.migrations_dir / f"{migration_id}.sql"
        filepath.write_text(migration.to_sql_file(), encoding="utf-8")

        self.migrations.append(migration)
        return migration

    def load_migrations(self) -> list[Migration]:
        """Load all migrations from the directory."""
        self.migrations = []
        if not self.migrations_dir.exists():
            return self.migrations

        # Load history
        history = self._load_history()

        for filepath in sorted(self.migrations_dir.glob("*.sql")):
            content = filepath.read_text(encoding="utf-8")
            migration = Migration.from_sql_file(content, filepath.name)

            # Apply history
            if migration.id in history:
                h = history[migration.id]
                migration.status = MigrationStatus(h.get("status", "PENDING"))
                migration.applied_at = h.get("applied_at")
                migration.execution_time_ms = h.get("execution_time_ms")

            self.migrations.append(migration)

        return self.migrations

    def get_pending(self) -> list[Migration]:
        """Get all pending migrations."""
        return [m for m in self.migrations if m.status == MigrationStatus.PENDING]

    def get_applied(self) -> list[Migration]:
        """Get all applied migrations."""
        return [m for m in self.migrations if m.status == MigrationStatus.APPLIED]

    def get_migration(self, migration_id: str) -> Optional[Migration]:
        """Get a migration by ID."""
        for m in self.migrations:
            if m.id == migration_id:
                return m
        return None

    def apply_migration(self, migration: Migration, dry_run: bool = False) -> dict[str, Any]:
        """Apply a migration (simulate)."""
        if migration.status == MigrationStatus.APPLIED:
            return {"status": "already_applied", "migration_id": migration.id}

        # Check dependencies
        for dep_id in migration.depends_on:
            dep = self.get_migration(dep_id)
            if dep and dep.status != MigrationStatus.APPLIED:
                return {
                    "status": "blocked",
                    "migration_id": migration.id,
                    "reason": f"Dependency {dep_id} not applied",
                }

        if dry_run:
            return {
                "status": "dry_run",
                "migration_id": migration.id,
                "sql": migration.up_sql,
            }

        start = time.monotonic()
        # Simulate execution
        migration.status = MigrationStatus.APPLIED
        migration.applied_at = datetime.now(timezone.utc).isoformat()
        migration.execution_time_ms = int((time.monotonic() - start) * 1000)

        self._save_history()
        return {
            "status": "applied",
            "migration_id": migration.id,
            "execution_time_ms": migration.execution_time_ms,
        }

    def rollback_migration(self, migration: Migration, dry_run: bool = False) -> dict[str, Any]:
        """Rollback a migration (simulate)."""
        if migration.status != MigrationStatus.APPLIED:
            return {"status": "not_applied", "migration_id": migration.id}

        if not migration.down_sql:
            return {
                "status": "no_rollback",
                "migration_id": migration.id,
                "reason": "No down migration SQL",
            }

        if dry_run:
            return {
                "status": "dry_run",
                "migration_id": migration.id,
                "sql": migration.down_sql,
            }

        start = time.monotonic()
        migration.status = MigrationStatus.ROLLED_BACK
        migration.execution_time_ms = int((time.monotonic() - start) * 1000)

        self._save_history()
        return {
            "status": "rolled_back",
            "migration_id": migration.id,
            "execution_time_ms": migration.execution_time_ms,
        }

    def apply_all(self, dry_run: bool = False) -> list[dict[str, Any]]:
        """Apply all pending migrations in order."""
        results = []
        for migration in self.get_pending():
            result = self.apply_migration(migration, dry_run=dry_run)
            results.append(result)
            if result["status"] in ("failed", "blocked"):
                break
        return results

    def rollback_last(self, count: int = 1, dry_run: bool = False) -> list[dict[str, Any]]:
        """Rollback the last N applied migrations."""
        applied = self.get_applied()
        applied.reverse()  # Most recent first
        results = []
        for migration in applied[:count]:
            result = self.rollback_migration(migration, dry_run=dry_run)
            results.append(result)
        return results

    def validate_checksums(self) -> list[dict[str, str]]:
        """Validate all migration checksums."""
        issues = []
        for migration in self.migrations:
            if migration.status == MigrationStatus.APPLIED:
                if not migration.validate_checksum():
                    issues.append({
                        "migration_id": migration.id,
                        "issue": "checksum_mismatch",
                        "expected": migration.checksum,
                        "actual": migration._compute_checksum(),
                    })
        return issues

    def status_report(self) -> dict[str, Any]:
        """Generate a status report."""
        return {
            "total": len(self.migrations),
            "pending": len(self.get_pending()),
            "applied": len(self.get_applied()),
            "rolled_back": len([m for m in self.migrations if m.status == MigrationStatus.ROLLED_BACK]),
            "failed": len([m for m in self.migrations if m.status == MigrationStatus.FAILED]),
            "migrations": [
                {
                    "id": m.id,
                    "name": m.name,
                    "status": m.status.value,
                    "version": m.version,
                }
                for m in self.migrations
            ],
        }

    def _load_history(self) -> dict[str, dict[str, Any]]:
        if not self.history_file.exists():
            return {}
        try:
            data = json.loads(self.history_file.read_text(encoding="utf-8"))
            return data.get("migrations", {})
        except (json.JSONDecodeError, OSError):
            return {}

    def _save_history(self) -> None:
        history: dict[str, dict[str, Any]] = {}
        for m in self.migrations:
            if m.status != MigrationStatus.PENDING:
                history[m.id] = {
                    "status": m.status.value,
                    "applied_at": m.applied_at,
                    "execution_time_ms": m.execution_time_ms,
                }
        data = {"version": 1, "migrations": history}
        self.migrations_dir.mkdir(parents=True, exist_ok=True)
        self.history_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
