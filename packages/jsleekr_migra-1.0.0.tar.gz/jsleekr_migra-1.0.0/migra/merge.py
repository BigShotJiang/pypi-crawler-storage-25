"""Schema merge - merge multiple schemas with conflict detection."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from migra.schema import Column, Constraint, Index, Schema, Table


class ConflictType:
    COLUMN_TYPE = "COLUMN_TYPE"
    COLUMN_NULLABLE = "COLUMN_NULLABLE"
    COLUMN_DEFAULT = "COLUMN_DEFAULT"
    INDEX_DEFINITION = "INDEX_DEFINITION"
    CONSTRAINT_DEFINITION = "CONSTRAINT_DEFINITION"
    TABLE_COMMENT = "TABLE_COMMENT"


@dataclass
class MergeConflict:
    """A conflict detected during schema merge."""
    table_name: str
    object_name: str
    conflict_type: str
    source_a: Any
    source_b: Any
    resolution: Optional[str] = None  # "a", "b", or None (unresolved)

    def to_dict(self) -> dict[str, Any]:
        return {
            "table_name": self.table_name,
            "object_name": self.object_name,
            "conflict_type": self.conflict_type,
            "source_a": str(self.source_a),
            "source_b": str(self.source_b),
            "resolution": self.resolution,
        }


@dataclass
class MergeResult:
    """Result of a schema merge operation."""
    schema: Schema
    conflicts: list[MergeConflict] = field(default_factory=list)
    tables_added: list[str] = field(default_factory=list)
    tables_merged: list[str] = field(default_factory=list)

    @property
    def has_conflicts(self) -> bool:
        return len(self.conflicts) > 0

    @property
    def unresolved_conflicts(self) -> list[MergeConflict]:
        return [c for c in self.conflicts if c.resolution is None]

    def to_dict(self) -> dict[str, Any]:
        return {
            "conflicts": [c.to_dict() for c in self.conflicts],
            "tables_added": self.tables_added,
            "tables_merged": self.tables_merged,
            "has_conflicts": self.has_conflicts,
        }


class SchemaMerger:
    """Merge two schemas together with conflict detection."""

    def __init__(self, prefer: str = "b") -> None:
        """Initialize merger.

        Args:
            prefer: Which schema to prefer on conflict ("a" or "b").
        """
        self.prefer = prefer

    def merge(self, schema_a: Schema, schema_b: Schema) -> MergeResult:
        """Merge schema_b into schema_a."""
        result_tables: list[Table] = []
        conflicts: list[MergeConflict] = []
        tables_added: list[str] = []
        tables_merged: list[str] = []

        a_tables = {(t.schema, t.name): t for t in schema_a.tables}
        b_tables = {(t.schema, t.name): t for t in schema_b.tables}

        # Tables only in A
        for key, table in a_tables.items():
            if key not in b_tables:
                result_tables.append(table)

        # Tables only in B
        for key, table in b_tables.items():
            if key not in a_tables:
                result_tables.append(table)
                tables_added.append(table.name)

        # Tables in both - merge
        for key in sorted(set(a_tables) & set(b_tables)):
            merged, table_conflicts = self._merge_table(a_tables[key], b_tables[key])
            result_tables.append(merged)
            conflicts.extend(table_conflicts)
            tables_merged.append(merged.name)

        merged_schema = Schema(
            name=schema_a.name or schema_b.name,
            tables=sorted(result_tables, key=lambda t: (t.schema, t.name)),
            version=schema_b.version or schema_a.version,
        )

        return MergeResult(
            schema=merged_schema,
            conflicts=conflicts,
            tables_added=tables_added,
            tables_merged=tables_merged,
        )

    def _merge_table(self, a: Table, b: Table) -> tuple[Table, list[MergeConflict]]:
        """Merge two tables."""
        conflicts: list[MergeConflict] = []

        # Merge columns
        merged_columns, col_conflicts = self._merge_columns(a, b)
        conflicts.extend(col_conflicts)

        # Merge indexes
        merged_indexes, idx_conflicts = self._merge_indexes(a, b)
        conflicts.extend(idx_conflicts)

        # Merge constraints
        merged_constraints, con_conflicts = self._merge_constraints(a, b)
        conflicts.extend(con_conflicts)

        # Comment conflict
        comment = a.comment
        if a.comment != b.comment and b.comment is not None:
            if a.comment is not None:
                conflicts.append(MergeConflict(
                    table_name=a.name,
                    object_name="<table>",
                    conflict_type=ConflictType.TABLE_COMMENT,
                    source_a=a.comment,
                    source_b=b.comment,
                    resolution=self.prefer,
                ))
            comment = b.comment if self.prefer == "b" else a.comment

        merged = Table(
            name=a.name,
            schema=a.schema,
            columns=merged_columns,
            indexes=merged_indexes,
            constraints=merged_constraints,
            comment=comment,
        )
        return merged, conflicts

    def _merge_columns(self, a: Table, b: Table) -> tuple[list[Column], list[MergeConflict]]:
        a_cols = {c.name: c for c in a.columns}
        b_cols = {c.name: c for c in b.columns}
        conflicts: list[MergeConflict] = []
        result: list[Column] = []

        # Preserve order from A, then add new from B
        seen = set()
        for col in a.columns:
            if col.name in b_cols:
                bc = b_cols[col.name]
                if col.fingerprint() != bc.fingerprint():
                    # Conflict
                    if col.type != bc.type:
                        conflicts.append(MergeConflict(
                            table_name=a.name, object_name=col.name,
                            conflict_type=ConflictType.COLUMN_TYPE,
                            source_a=col.type, source_b=bc.type,
                            resolution=self.prefer,
                        ))
                    if col.nullable != bc.nullable:
                        conflicts.append(MergeConflict(
                            table_name=a.name, object_name=col.name,
                            conflict_type=ConflictType.COLUMN_NULLABLE,
                            source_a=col.nullable, source_b=bc.nullable,
                            resolution=self.prefer,
                        ))
                    if col.default != bc.default:
                        conflicts.append(MergeConflict(
                            table_name=a.name, object_name=col.name,
                            conflict_type=ConflictType.COLUMN_DEFAULT,
                            source_a=col.default, source_b=bc.default,
                            resolution=self.prefer,
                        ))
                    result.append(bc if self.prefer == "b" else col)
                else:
                    result.append(col)
            else:
                result.append(col)
            seen.add(col.name)

        for col in b.columns:
            if col.name not in seen:
                result.append(col)

        return result, conflicts

    def _merge_indexes(self, a: Table, b: Table) -> tuple[list[Index], list[MergeConflict]]:
        a_idxs = {i.name: i for i in a.indexes}
        b_idxs = {i.name: i for i in b.indexes}
        conflicts: list[MergeConflict] = []
        result: list[Index] = []

        seen = set()
        for idx in a.indexes:
            if idx.name in b_idxs:
                bi = b_idxs[idx.name]
                if idx.fingerprint() != bi.fingerprint():
                    conflicts.append(MergeConflict(
                        table_name=a.name, object_name=idx.name,
                        conflict_type=ConflictType.INDEX_DEFINITION,
                        source_a=idx.to_dict(), source_b=bi.to_dict(),
                        resolution=self.prefer,
                    ))
                    result.append(bi if self.prefer == "b" else idx)
                else:
                    result.append(idx)
            else:
                result.append(idx)
            seen.add(idx.name)

        for idx in b.indexes:
            if idx.name not in seen:
                result.append(idx)

        return result, conflicts

    def _merge_constraints(self, a: Table, b: Table) -> tuple[list[Constraint], list[MergeConflict]]:
        a_cons = {c.name: c for c in a.constraints}
        b_cons = {c.name: c for c in b.constraints}
        conflicts: list[MergeConflict] = []
        result: list[Constraint] = []

        seen = set()
        for con in a.constraints:
            if con.name in b_cons:
                bc = b_cons[con.name]
                if con.fingerprint() != bc.fingerprint():
                    conflicts.append(MergeConflict(
                        table_name=a.name, object_name=con.name,
                        conflict_type=ConflictType.CONSTRAINT_DEFINITION,
                        source_a=con.to_dict(), source_b=bc.to_dict(),
                        resolution=self.prefer,
                    ))
                    result.append(bc if self.prefer == "b" else con)
                else:
                    result.append(con)
            else:
                result.append(con)
            seen.add(con.name)

        for con in b.constraints:
            if con.name not in seen:
                result.append(con)

        return result, conflicts
