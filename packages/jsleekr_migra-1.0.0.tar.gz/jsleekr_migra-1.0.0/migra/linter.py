"""SQL migration linter - checks migration SQL for anti-patterns."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Optional

from migra.validator import ValidationIssue, ValidationSeverity


class LintRule:
    """A linting rule for migration SQL."""
    code: str = ""
    severity: ValidationSeverity = ValidationSeverity.INFO
    description: str = ""

    def check(self, sql: str) -> list[ValidationIssue]:
        raise NotImplementedError


class LockTableRule(LintRule):
    """Detect operations that acquire heavy locks."""
    code = "LOCK_TABLE"
    severity = ValidationSeverity.WARNING
    description = "Operation may acquire exclusive lock"

    def check(self, sql: str) -> list[ValidationIssue]:
        issues = []
        upper = sql.upper()

        # ALTER TABLE without CONCURRENTLY
        if "ALTER TABLE" in upper and "ADD COLUMN" in upper:
            if "NOT NULL" in upper and "DEFAULT" not in upper:
                issues.append(ValidationIssue(
                    severity=self.severity, code="LOCK_ADD_NOTNULL",
                    message="Adding NOT NULL column without DEFAULT requires table rewrite (full lock)",
                ))

        # CREATE INDEX without CONCURRENTLY
        if re.search(r"CREATE\s+(?:UNIQUE\s+)?INDEX\s+(?!CONCURRENTLY)", upper):
            issues.append(ValidationIssue(
                severity=self.severity, code="LOCK_INDEX",
                message="CREATE INDEX without CONCURRENTLY will lock table for writes",
            ))

        return issues


class DataLossRule(LintRule):
    """Detect operations that may cause data loss."""
    code = "DATA_LOSS"
    severity = ValidationSeverity.ERROR
    description = "Operation may cause data loss"

    def check(self, sql: str) -> list[ValidationIssue]:
        issues = []
        upper = sql.upper()

        if "DROP COLUMN" in upper:
            issues.append(ValidationIssue(
                severity=self.severity, code="DATA_LOSS_DROP_COLUMN",
                message="DROP COLUMN permanently deletes data",
            ))

        if "DROP TABLE" in upper:
            issues.append(ValidationIssue(
                severity=self.severity, code="DATA_LOSS_DROP_TABLE",
                message="DROP TABLE permanently deletes table and data",
            ))

        if "TRUNCATE" in upper:
            issues.append(ValidationIssue(
                severity=self.severity, code="DATA_LOSS_TRUNCATE",
                message="TRUNCATE permanently deletes all rows",
            ))

        return issues


class BackwardCompatRule(LintRule):
    """Detect backward-incompatible changes."""
    code = "COMPAT"
    severity = ValidationSeverity.WARNING
    description = "Change may break existing code"

    def check(self, sql: str) -> list[ValidationIssue]:
        issues = []
        upper = sql.upper()

        if "RENAME COLUMN" in upper or "RENAME TABLE" in upper:
            issues.append(ValidationIssue(
                severity=self.severity, code="COMPAT_RENAME",
                message="Rename operations break existing queries",
            ))

        if re.search(r"ALTER\s+TABLE.*ALTER\s+COLUMN.*TYPE", upper):
            issues.append(ValidationIssue(
                severity=self.severity, code="COMPAT_TYPE_CHANGE",
                message="Column type change may break existing code",
            ))

        return issues


class EnumRule(LintRule):
    """Detect enum-related issues."""
    code = "ENUM"
    severity = ValidationSeverity.INFO
    description = "Enum-related best practices"

    def check(self, sql: str) -> list[ValidationIssue]:
        issues = []
        upper = sql.upper()

        if "ALTER TYPE" in upper and "ADD VALUE" in upper:
            issues.append(ValidationIssue(
                severity=ValidationSeverity.INFO, code="ENUM_ADD_VALUE",
                message="ALTER TYPE ADD VALUE cannot be rolled back inside a transaction",
            ))

        return issues


class TimeoutRule(LintRule):
    """Suggest statement timeouts for long operations."""
    code = "TIMEOUT"
    severity = ValidationSeverity.INFO
    description = "Long-running operation considerations"

    def check(self, sql: str) -> list[ValidationIssue]:
        issues = []
        upper = sql.upper()

        # Backfill operations
        if "UPDATE" in upper and "SET" in upper and "WHERE" not in upper:
            issues.append(ValidationIssue(
                severity=ValidationSeverity.WARNING, code="TIMEOUT_BACKFILL",
                message="UPDATE without WHERE may be a full-table backfill - consider batching",
            ))

        # Large index creation
        if "CREATE INDEX" in upper:
            issues.append(ValidationIssue(
                severity=ValidationSeverity.INFO, code="TIMEOUT_INDEX",
                message="Index creation may take long on large tables - consider statement_timeout",
            ))

        return issues


class MigrationLinter:
    """Lint migration SQL for anti-patterns and best practices."""

    def __init__(self) -> None:
        self.rules: list[LintRule] = [
            LockTableRule(),
            DataLossRule(),
            BackwardCompatRule(),
            EnumRule(),
            TimeoutRule(),
        ]

    def lint(self, sql: str) -> list[ValidationIssue]:
        """Lint migration SQL."""
        issues: list[ValidationIssue] = []
        for rule in self.rules:
            issues.extend(rule.check(sql))
        return issues

    def lint_file(self, path: str) -> list[ValidationIssue]:
        """Lint a migration SQL file."""
        with open(path, "r", encoding="utf-8") as f:
            return self.lint(f.read())

    def add_rule(self, rule: LintRule) -> None:
        """Add a custom lint rule."""
        self.rules.append(rule)

    def summary(self, issues: list[ValidationIssue]) -> dict[str, int]:
        """Summarize issues by severity."""
        counts: dict[str, int] = {}
        for issue in issues:
            key = issue.severity.value
            counts[key] = counts.get(key, 0) + 1
        return counts
