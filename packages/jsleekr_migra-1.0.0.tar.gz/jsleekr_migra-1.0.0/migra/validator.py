"""Schema and migration validation."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

from migra.schema import Column, Constraint, Schema, Table


class ValidationSeverity(str, Enum):
    """Validation issue severity."""
    ERROR = "ERROR"
    WARNING = "WARNING"
    INFO = "INFO"


@dataclass
class ValidationIssue:
    """A single validation issue."""
    severity: ValidationSeverity
    code: str
    message: str
    table: Optional[str] = None
    column: Optional[str] = None
    context: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "severity": self.severity.value,
            "code": self.code,
            "message": self.message,
        }
        if self.table:
            d["table"] = self.table
        if self.column:
            d["column"] = self.column
        if self.context:
            d["context"] = self.context
        return d

    def __str__(self) -> str:
        loc = ""
        if self.table:
            loc = f" [{self.table}"
            if self.column:
                loc += f".{self.column}"
            loc += "]"
        return f"[{self.severity.value}] {self.code}{loc}: {self.message}"


class SchemaValidator:
    """Validates schema for best practices and common issues."""

    def __init__(self) -> None:
        self.rules: list[ValidationRule] = [
            PrimaryKeyRule(),
            NamingConventionRule(),
            ForeignKeyRule(),
            ColumnTypeRule(),
            IndexRule(),
            NullableRule(),
            ReservedWordRule(),
            TableSizeRule(),
        ]

    def validate(self, schema: Schema) -> list[ValidationIssue]:
        """Run all validation rules against a schema."""
        issues: list[ValidationIssue] = []
        for rule in self.rules:
            issues.extend(rule.check(schema))
        return issues

    def validate_table(self, table: Table) -> list[ValidationIssue]:
        """Validate a single table."""
        schema = Schema(tables=[table])
        return self.validate(schema)

    def add_rule(self, rule: ValidationRule) -> None:
        """Add a custom validation rule."""
        self.rules.append(rule)


class ValidationRule:
    """Base validation rule."""

    def check(self, schema: Schema) -> list[ValidationIssue]:
        raise NotImplementedError


class PrimaryKeyRule(ValidationRule):
    """Check that every table has a primary key."""

    def check(self, schema: Schema) -> list[ValidationIssue]:
        issues = []
        for table in schema.tables:
            has_pk = any(c.primary_key for c in table.columns)
            has_pk_constraint = any(
                c.type == "PRIMARY KEY" for c in table.constraints
            )
            if not has_pk and not has_pk_constraint:
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.WARNING,
                    code="NO_PRIMARY_KEY",
                    message=f"Table {table.name} has no primary key",
                    table=table.name,
                ))
        return issues


class NamingConventionRule(ValidationRule):
    """Check naming conventions."""

    RESERVED_PREFIXES = {"tmp_", "temp_", "bak_", "old_"}

    def check(self, schema: Schema) -> list[ValidationIssue]:
        issues = []
        for table in schema.tables:
            # Table name checks
            if not table.name.islower() and not table.name.isupper():
                if not all(c.isalnum() or c == "_" for c in table.name):
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.INFO,
                        code="TABLE_NAMING",
                        message=f"Table name '{table.name}' contains special characters",
                        table=table.name,
                    ))

            for prefix in self.RESERVED_PREFIXES:
                if table.name.lower().startswith(prefix):
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.WARNING,
                        code="TABLE_PREFIX",
                        message=f"Table '{table.name}' has temporary prefix '{prefix}'",
                        table=table.name,
                    ))

            # Column name checks
            for col in table.columns:
                if not all(c.isalnum() or c == "_" for c in col.name):
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.INFO,
                        code="COLUMN_NAMING",
                        message=f"Column name '{col.name}' contains special characters",
                        table=table.name,
                        column=col.name,
                    ))
        return issues


class ForeignKeyRule(ValidationRule):
    """Check foreign key references."""

    def check(self, schema: Schema) -> list[ValidationIssue]:
        issues = []
        table_names = {t.name for t in schema.tables}

        for table in schema.tables:
            # Check column references
            for col in table.columns:
                if col.references:
                    ref_parts = col.references.split(".")
                    if len(ref_parts) == 2:
                        ref_table = ref_parts[0]
                        if ref_table not in table_names:
                            issues.append(ValidationIssue(
                                severity=ValidationSeverity.ERROR,
                                code="FK_MISSING_TABLE",
                                message=f"Foreign key references non-existent table '{ref_table}'",
                                table=table.name,
                                column=col.name,
                            ))

            # Check constraint references
            for constraint in table.constraints:
                if constraint.type == "FOREIGN KEY" and constraint.references_table:
                    if constraint.references_table not in table_names:
                        issues.append(ValidationIssue(
                            severity=ValidationSeverity.ERROR,
                            code="FK_MISSING_TABLE",
                            message=f"Foreign key constraint references non-existent table '{constraint.references_table}'",
                            table=table.name,
                            context={"constraint": constraint.name},
                        ))
        return issues


class ColumnTypeRule(ValidationRule):
    """Check column types for best practices."""

    DEPRECATED_TYPES = {"MONEY", "FLOAT4", "FLOAT8", "INT2", "INT4", "INT8"}

    def check(self, schema: Schema) -> list[ValidationIssue]:
        issues = []
        for table in schema.tables:
            for col in table.columns:
                if col.type.upper() in self.DEPRECATED_TYPES:
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.INFO,
                        code="DEPRECATED_TYPE",
                        message=f"Column type '{col.type}' is deprecated or non-standard",
                        table=table.name,
                        column=col.name,
                    ))

                # Check VARCHAR without length
                if col.type.upper() == "VARCHAR" and col.max_length is None:
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.INFO,
                        code="VARCHAR_NO_LENGTH",
                        message=f"VARCHAR column without explicit length (consider TEXT)",
                        table=table.name,
                        column=col.name,
                    ))
        return issues


class IndexRule(ValidationRule):
    """Check index usage patterns."""

    def check(self, schema: Schema) -> list[ValidationIssue]:
        issues = []
        for table in schema.tables:
            # Check for foreign keys without indexes
            fk_columns = set()
            for constraint in table.constraints:
                if constraint.type == "FOREIGN KEY":
                    fk_columns.update(constraint.columns)

            indexed_columns = set()
            for idx in table.indexes:
                indexed_columns.update(idx.columns)

            for col in table.columns:
                if col.references and col.name not in indexed_columns:
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.WARNING,
                        code="FK_NO_INDEX",
                        message=f"Foreign key column '{col.name}' has no index",
                        table=table.name,
                        column=col.name,
                    ))

            for fk_col in fk_columns:
                if fk_col not in indexed_columns:
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.WARNING,
                        code="FK_NO_INDEX",
                        message=f"Foreign key column '{fk_col}' has no index",
                        table=table.name,
                        column=fk_col,
                    ))

            # Check for duplicate indexes
            idx_signatures: dict[str, str] = {}
            for idx in table.indexes:
                sig = ",".join(sorted(idx.columns))
                if sig in idx_signatures:
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.WARNING,
                        code="DUPLICATE_INDEX",
                        message=f"Index '{idx.name}' duplicates '{idx_signatures[sig]}'",
                        table=table.name,
                        context={"index": idx.name, "duplicate_of": idx_signatures[sig]},
                    ))
                else:
                    idx_signatures[sig] = idx.name

        return issues


class NullableRule(ValidationRule):
    """Check for nullable best practices."""

    def check(self, schema: Schema) -> list[ValidationIssue]:
        issues = []
        for table in schema.tables:
            nullable_count = sum(1 for c in table.columns if c.nullable)
            total = len(table.columns)
            if total > 0 and nullable_count / total > 0.8:
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.INFO,
                    code="MOSTLY_NULLABLE",
                    message=f"Table has {nullable_count}/{total} nullable columns ({nullable_count*100//total}%)",
                    table=table.name,
                ))
        return issues


class ReservedWordRule(ValidationRule):
    """Check for SQL reserved words in names."""

    RESERVED = {
        "SELECT", "INSERT", "UPDATE", "DELETE", "DROP", "CREATE", "ALTER",
        "TABLE", "INDEX", "VIEW", "FROM", "WHERE", "JOIN", "ON", "AND",
        "OR", "NOT", "IN", "EXISTS", "BETWEEN", "LIKE", "IS", "NULL",
        "TRUE", "FALSE", "GROUP", "ORDER", "BY", "HAVING", "LIMIT",
        "OFFSET", "UNION", "ALL", "AS", "CASE", "WHEN", "THEN", "ELSE",
        "END", "BEGIN", "COMMIT", "ROLLBACK", "GRANT", "REVOKE",
        "USER", "ROLE", "PASSWORD", "DATABASE", "SCHEMA", "SEQUENCE",
        "TRIGGER", "FUNCTION", "PROCEDURE", "TYPE", "COLUMN", "ROW",
        "KEY", "PRIMARY", "FOREIGN", "REFERENCES", "CONSTRAINT",
        "DEFAULT", "CHECK", "UNIQUE",
    }

    def check(self, schema: Schema) -> list[ValidationIssue]:
        issues = []
        for table in schema.tables:
            if table.name.upper() in self.RESERVED:
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.WARNING,
                    code="RESERVED_WORD",
                    message=f"Table name '{table.name}' is a SQL reserved word",
                    table=table.name,
                ))
            for col in table.columns:
                if col.name.upper() in self.RESERVED:
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.WARNING,
                        code="RESERVED_WORD",
                        message=f"Column name '{col.name}' is a SQL reserved word",
                        table=table.name,
                        column=col.name,
                    ))
        return issues


class TableSizeRule(ValidationRule):
    """Check for tables with too many columns."""

    MAX_COLUMNS = 50

    def check(self, schema: Schema) -> list[ValidationIssue]:
        issues = []
        for table in schema.tables:
            if len(table.columns) > self.MAX_COLUMNS:
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.WARNING,
                    code="TOO_MANY_COLUMNS",
                    message=f"Table has {len(table.columns)} columns (max recommended: {self.MAX_COLUMNS})",
                    table=table.name,
                ))
        return issues


class MigrationValidator:
    """Validates migration SQL for common issues."""

    @staticmethod
    def _split_statements(sql: str) -> list[str]:
        """Split SQL into statements on semicolons, respecting string literals.

        Handles escaped single quotes ('') inside string literals so that
        a semicolon after an escaped quote is not mistaken for a statement
        separator.
        """
        statements: list[str] = []
        current: list[str] = []
        in_string = False
        i = 0
        n = len(sql)

        while i < n:
            ch = sql[i]
            if ch == "'" and not in_string:
                in_string = True
                current.append(ch)
                i += 1
            elif ch == "'" and in_string:
                current.append(ch)
                if i + 1 < n and sql[i + 1] == "'":
                    # Escaped quote ('') — stay inside the string
                    current.append(sql[i + 1])
                    i += 2
                else:
                    in_string = False
                    i += 1
            elif ch == ";" and not in_string:
                stmt = "".join(current).strip()
                if stmt:
                    statements.append(stmt)
                current = []
                i += 1
            else:
                current.append(ch)
                i += 1

        remaining = "".join(current).strip()
        if remaining:
            statements.append(remaining)

        return statements

    def validate_sql(self, sql: str) -> list[ValidationIssue]:
        """Validate migration SQL."""
        issues = []

        if not sql.strip():
            issues.append(ValidationIssue(
                severity=ValidationSeverity.WARNING,
                code="EMPTY_MIGRATION",
                message="Migration SQL is empty",
            ))
            return issues

        upper = sql.upper()

        # Check for dangerous operations
        if "DROP TABLE" in upper and "IF EXISTS" not in upper:
            issues.append(ValidationIssue(
                severity=ValidationSeverity.ERROR,
                code="DROP_WITHOUT_IF_EXISTS",
                message="DROP TABLE without IF EXISTS",
            ))

        if "TRUNCATE" in upper:
            issues.append(ValidationIssue(
                severity=ValidationSeverity.WARNING,
                code="TRUNCATE_TABLE",
                message="TRUNCATE TABLE is destructive and not transactional in all databases",
            ))

        # Check for missing transaction
        statements = [s.strip() for s in self._split_statements(sql) if s.strip()]
        if len(statements) > 1 and "BEGIN" not in upper:
            issues.append(ValidationIssue(
                severity=ValidationSeverity.INFO,
                code="NO_TRANSACTION",
                message="Multiple statements without explicit transaction",
            ))

        # Check for data type changes that might lose data
        if "ALTER" in upper and "TYPE" in upper:
            issues.append(ValidationIssue(
                severity=ValidationSeverity.WARNING,
                code="TYPE_CHANGE",
                message="Column type change detected - may cause data loss",
            ))

        # Check for NOT NULL without DEFAULT on existing tables
        if "SET NOT NULL" in upper:
            issues.append(ValidationIssue(
                severity=ValidationSeverity.WARNING,
                code="SET_NOT_NULL",
                message="Setting NOT NULL may fail if existing rows have NULL values",
            ))

        return issues
