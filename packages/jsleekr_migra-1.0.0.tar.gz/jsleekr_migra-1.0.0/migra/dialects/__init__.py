"""Database dialect support."""
