"""Schema representation models."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class ColumnType(str, Enum):
    """Standard column types."""
    INTEGER = "INTEGER"
    BIGINT = "BIGINT"
    SMALLINT = "SMALLINT"
    SERIAL = "SERIAL"
    BIGSERIAL = "BIGSERIAL"
    TEXT = "TEXT"
    VARCHAR = "VARCHAR"
    CHAR = "CHAR"
    BOOLEAN = "BOOLEAN"
    FLOAT = "FLOAT"
    DOUBLE = "DOUBLE"
    DECIMAL = "DECIMAL"
    NUMERIC = "NUMERIC"
    DATE = "DATE"
    TIME = "TIME"
    TIMESTAMP = "TIMESTAMP"
    TIMESTAMPTZ = "TIMESTAMPTZ"
    JSON = "JSON"
    JSONB = "JSONB"
    UUID = "UUID"
    BYTEA = "BYTEA"
    BLOB = "BLOB"
    ARRAY = "ARRAY"
    ENUM = "ENUM"
    CUSTOM = "CUSTOM"


class ConstraintType(str, Enum):
    """Constraint types."""
    PRIMARY_KEY = "PRIMARY KEY"
    FOREIGN_KEY = "FOREIGN KEY"
    UNIQUE = "UNIQUE"
    CHECK = "CHECK"
    NOT_NULL = "NOT NULL"
    DEFAULT = "DEFAULT"


class IndexType(str, Enum):
    """Index types."""
    BTREE = "BTREE"
    HASH = "HASH"
    GIN = "GIN"
    GIST = "GIST"
    BRIN = "BRIN"


@dataclass
class Column:
    """Represents a database column."""
    name: str
    type: str
    nullable: bool = True
    default: Optional[str] = None
    primary_key: bool = False
    unique: bool = False
    references: Optional[str] = None  # "table.column"
    comment: Optional[str] = None
    max_length: Optional[int] = None
    precision: Optional[int] = None
    scale: Optional[int] = None
    auto_increment: bool = False

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        d: dict[str, Any] = {
            "name": self.name,
            "type": self.type,
            "nullable": self.nullable,
        }
        if self.default is not None:
            d["default"] = self.default
        if self.primary_key:
            d["primary_key"] = True
        if self.unique:
            d["unique"] = True
        if self.references:
            d["references"] = self.references
        if self.comment:
            d["comment"] = self.comment
        if self.max_length is not None:
            d["max_length"] = self.max_length
        if self.precision is not None:
            d["precision"] = self.precision
        if self.scale is not None:
            d["scale"] = self.scale
        if self.auto_increment:
            d["auto_increment"] = True
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Column:
        """Deserialize from dictionary."""
        return cls(
            name=data["name"],
            type=data["type"],
            nullable=data.get("nullable", True),
            default=data.get("default"),
            primary_key=data.get("primary_key", False),
            unique=data.get("unique", False),
            references=data.get("references"),
            comment=data.get("comment"),
            max_length=data.get("max_length"),
            precision=data.get("precision"),
            scale=data.get("scale"),
            auto_increment=data.get("auto_increment", False),
        )

    def fingerprint(self) -> str:
        """Generate a fingerprint for change detection."""
        parts = [self.name, self.type, str(self.nullable)]
        if self.default is not None:
            parts.append(f"default={self.default}")
        if self.primary_key:
            parts.append("pk")
        if self.unique:
            parts.append("unique")
        if self.references:
            parts.append(f"ref={self.references}")
        if self.max_length is not None:
            parts.append(f"len={self.max_length}")
        if self.precision is not None:
            parts.append(f"prec={self.precision}")
        if self.scale is not None:
            parts.append(f"scale={self.scale}")
        if self.auto_increment:
            parts.append("autoinc")
        return "|".join(parts)


@dataclass
class Index:
    """Represents a database index."""
    name: str
    columns: list[str]
    unique: bool = False
    index_type: str = "BTREE"
    condition: Optional[str] = None  # partial index WHERE clause
    include: Optional[list[str]] = None  # covering index columns

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "name": self.name,
            "columns": self.columns,
            "unique": self.unique,
            "index_type": self.index_type,
        }
        if self.condition:
            d["condition"] = self.condition
        if self.include:
            d["include"] = self.include
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Index:
        return cls(
            name=data["name"],
            columns=data["columns"],
            unique=data.get("unique", False),
            index_type=data.get("index_type", "BTREE"),
            condition=data.get("condition"),
            include=data.get("include"),
        )

    def fingerprint(self) -> str:
        parts = [self.name, ",".join(self.columns), str(self.unique), self.index_type]
        if self.condition:
            parts.append(f"where={self.condition}")
        if self.include:
            parts.append(f"include={','.join(self.include)}")
        return "|".join(parts)


@dataclass
class Constraint:
    """Represents a database constraint."""
    name: str
    type: str  # ConstraintType value
    columns: list[str]
    expression: Optional[str] = None  # for CHECK constraints
    references_table: Optional[str] = None  # for FK
    references_columns: Optional[list[str]] = None  # for FK
    on_delete: Optional[str] = None
    on_update: Optional[str] = None
    deferrable: bool = False

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "name": self.name,
            "type": self.type,
            "columns": self.columns,
        }
        if self.expression:
            d["expression"] = self.expression
        if self.references_table:
            d["references_table"] = self.references_table
        if self.references_columns:
            d["references_columns"] = self.references_columns
        if self.on_delete:
            d["on_delete"] = self.on_delete
        if self.on_update:
            d["on_update"] = self.on_update
        if self.deferrable:
            d["deferrable"] = True
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Constraint:
        return cls(
            name=data["name"],
            type=data["type"],
            columns=data["columns"],
            expression=data.get("expression"),
            references_table=data.get("references_table"),
            references_columns=data.get("references_columns"),
            on_delete=data.get("on_delete"),
            on_update=data.get("on_update"),
            deferrable=data.get("deferrable", False),
        )

    def fingerprint(self) -> str:
        parts = [self.name, self.type, ",".join(self.columns)]
        if self.expression:
            parts.append(f"expr={self.expression}")
        if self.references_table:
            parts.append(f"ref={self.references_table}")
        if self.references_columns:
            parts.append(f"refcols={','.join(self.references_columns)}")
        if self.on_delete:
            parts.append(f"ondelete={self.on_delete}")
        if self.on_update:
            parts.append(f"onupdate={self.on_update}")
        if self.deferrable:
            parts.append("deferrable")
        return "|".join(parts)


@dataclass
class Table:
    """Represents a database table."""
    name: str
    schema: str = "public"
    columns: list[Column] = field(default_factory=list)
    indexes: list[Index] = field(default_factory=list)
    constraints: list[Constraint] = field(default_factory=list)
    comment: Optional[str] = None

    def get_column(self, name: str) -> Optional[Column]:
        for col in self.columns:
            if col.name == name:
                return col
        return None

    def get_index(self, name: str) -> Optional[Index]:
        for idx in self.indexes:
            if idx.name == name:
                return idx
        return None

    def get_constraint(self, name: str) -> Optional[Constraint]:
        for con in self.constraints:
            if con.name == name:
                return con
        return None

    def column_names(self) -> list[str]:
        return [c.name for c in self.columns]

    def primary_key_columns(self) -> list[str]:
        return [c.name for c in self.columns if c.primary_key]

    def foreign_key_constraints(self) -> list[Constraint]:
        return [c for c in self.constraints if c.type == ConstraintType.FOREIGN_KEY.value]

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "name": self.name,
            "schema": self.schema,
            "columns": [c.to_dict() for c in self.columns],
        }
        if self.indexes:
            d["indexes"] = [i.to_dict() for i in self.indexes]
        if self.constraints:
            d["constraints"] = [c.to_dict() for c in self.constraints]
        if self.comment:
            d["comment"] = self.comment
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Table:
        return cls(
            name=data["name"],
            schema=data.get("schema", "public"),
            columns=[Column.from_dict(c) for c in data.get("columns", [])],
            indexes=[Index.from_dict(i) for i in data.get("indexes", [])],
            constraints=[Constraint.from_dict(c) for c in data.get("constraints", [])],
            comment=data.get("comment"),
        )

    def fingerprint(self) -> str:
        """Generate a fingerprint for the entire table."""
        parts = [f"table:{self.schema}.{self.name}"]
        for col in sorted(self.columns, key=lambda c: c.name):
            parts.append(f"col:{col.fingerprint()}")
        for idx in sorted(self.indexes, key=lambda i: i.name):
            parts.append(f"idx:{idx.fingerprint()}")
        for con in sorted(self.constraints, key=lambda c: c.name):
            parts.append(f"con:{con.fingerprint()}")
        raw = "\n".join(parts)
        return hashlib.sha256(raw.encode()).hexdigest()[:16]


@dataclass
class Schema:
    """Represents a complete database schema."""
    name: str = "default"
    tables: list[Table] = field(default_factory=list)
    version: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def get_table(self, name: str, schema: str = "public") -> Optional[Table]:
        for t in self.tables:
            if t.name == name and t.schema == schema:
                return t
        return None

    def table_names(self) -> list[str]:
        return [t.name for t in self.tables]

    def add_table(self, table: Table) -> None:
        existing = self.get_table(table.name, table.schema)
        if existing:
            raise ValueError(f"Table {table.schema}.{table.name} already exists")
        self.tables.append(table)

    def remove_table(self, name: str, schema: str = "public") -> Optional[Table]:
        for i, t in enumerate(self.tables):
            if t.name == name and t.schema == schema:
                return self.tables.pop(i)
        return None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "name": self.name,
            "tables": [t.to_dict() for t in self.tables],
        }
        if self.version:
            d["version"] = self.version
        if self.metadata:
            d["metadata"] = self.metadata
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Schema:
        return cls(
            name=data.get("name", "default"),
            tables=[Table.from_dict(t) for t in data.get("tables", [])],
            version=data.get("version"),
            metadata=data.get("metadata", {}),
        )

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    @classmethod
    def from_json(cls, text: str) -> Schema:
        return cls.from_dict(json.loads(text))

    def fingerprint(self) -> str:
        """Generate a fingerprint for the entire schema."""
        parts = [f"schema:{self.name}"]
        for table in sorted(self.tables, key=lambda t: f"{t.schema}.{t.name}"):
            parts.append(table.fingerprint())
        raw = "\n".join(parts)
        return hashlib.sha256(raw.encode()).hexdigest()[:16]

    def dependency_order(self) -> list[str]:
        """Return table names in dependency order (topological sort)."""
        graph: dict[str, set[str]] = {}
        for table in self.tables:
            graph[table.name] = set()
            for constraint in table.constraints:
                if constraint.type == ConstraintType.FOREIGN_KEY.value and constraint.references_table:
                    if constraint.references_table != table.name:
                        graph[table.name].add(constraint.references_table)

        visited: set[str] = set()
        result: list[str] = []
        temp: set[str] = set()

        def visit(node: str) -> None:
            if node in temp:
                raise ValueError(f"Circular dependency detected involving {node}")
            if node in visited:
                return
            temp.add(node)
            for dep in graph.get(node, set()):
                if dep in graph:
                    visit(dep)
            temp.remove(node)
            visited.add(node)
            result.append(node)

        for name in sorted(graph.keys()):
            visit(name)

        return result
