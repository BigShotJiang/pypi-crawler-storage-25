"""Schema snapshot management - save and compare schema states."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from migra.schema import Schema


@dataclass
class Snapshot:
    """A point-in-time schema snapshot."""
    id: str
    schema: Schema
    created_at: str = ""
    label: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "schema": self.schema.to_dict(),
            "created_at": self.created_at,
            "label": self.label,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Snapshot:
        return cls(
            id=data["id"],
            schema=Schema.from_dict(data["schema"]),
            created_at=data.get("created_at", ""),
            label=data.get("label"),
            metadata=data.get("metadata", {}),
        )

    def fingerprint(self) -> str:
        return self.schema.fingerprint()


class SnapshotManager:
    """Manages schema snapshots."""

    def __init__(self, snapshots_dir: str | Path = ".migra/snapshots") -> None:
        self.snapshots_dir = Path(snapshots_dir)

    def init(self) -> Path:
        """Initialize snapshots directory."""
        self.snapshots_dir.mkdir(parents=True, exist_ok=True)
        return self.snapshots_dir

    def save(self, schema: Schema, label: Optional[str] = None) -> Snapshot:
        """Save a schema snapshot."""
        self.snapshots_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
        fingerprint = schema.fingerprint()
        snapshot_id = f"{timestamp}_{fingerprint}"

        snapshot = Snapshot(
            id=snapshot_id,
            schema=schema,
            label=label,
        )

        filepath = self.snapshots_dir / f"{snapshot_id}.json"
        filepath.write_text(json.dumps(snapshot.to_dict(), indent=2), encoding="utf-8")

        return snapshot

    def load(self, snapshot_id: str) -> Optional[Snapshot]:
        """Load a snapshot by ID."""
        filepath = self.snapshots_dir / f"{snapshot_id}.json"
        if not filepath.exists():
            return None
        data = json.loads(filepath.read_text(encoding="utf-8"))
        return Snapshot.from_dict(data)

    def list_snapshots(self) -> list[Snapshot]:
        """List all snapshots."""
        if not self.snapshots_dir.exists():
            return []

        snapshots = []
        for filepath in sorted(self.snapshots_dir.glob("*.json")):
            try:
                data = json.loads(filepath.read_text(encoding="utf-8"))
                snapshots.append(Snapshot.from_dict(data))
            except (json.JSONDecodeError, KeyError):
                continue
        return snapshots

    def latest(self) -> Optional[Snapshot]:
        """Get the latest snapshot."""
        snapshots = self.list_snapshots()
        return snapshots[-1] if snapshots else None

    def delete(self, snapshot_id: str) -> bool:
        """Delete a snapshot."""
        filepath = self.snapshots_dir / f"{snapshot_id}.json"
        if filepath.exists():
            filepath.unlink()
            return True
        return False

    def has_drift(self, current: Schema) -> bool:
        """Check if schema has drifted from latest snapshot."""
        latest = self.latest()
        if not latest:
            return False
        return latest.fingerprint() != current.fingerprint()

    def drift_details(self, current: Schema) -> dict[str, Any]:
        """Get detailed drift information."""
        latest = self.latest()
        if not latest:
            return {"drifted": False, "reason": "no_baseline"}

        if latest.fingerprint() == current.fingerprint():
            return {"drifted": False}

        from migra.diff import SchemaDiff
        diff = SchemaDiff(source=latest.schema, target=current)
        diff.compute()

        return {
            "drifted": True,
            "snapshot_id": latest.id,
            "snapshot_date": latest.created_at,
            "changes": len(diff.changes),
            "summary": diff.summary(),
            "max_risk": diff.max_risk.value,
        }
