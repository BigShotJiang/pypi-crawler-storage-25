# polymarket-slippage

Slippage estimator for Polymarket CLOB order books. Estimates average fill price and slippage for a given position size.

Standalone re-export from [polymarket-trading-mcp](https://github.com/whitmorelabs/polymarket-mcp).

## Install

```bash
pip install polymarket-slippage
```

## Usage

```python
from polymarket_slippage import estimate_slippage
```

## Source

Part of [Whitmore Labs polymarket-mcp](https://github.com/whitmorelabs/polymarket-mcp).
