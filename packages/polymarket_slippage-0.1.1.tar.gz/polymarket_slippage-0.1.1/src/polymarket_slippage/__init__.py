"""
polymarket-slippage — Slippage estimator for Polymarket CLOB order books.

Standalone re-export from polymarket-trading-mcp.
"""
from polymarket_mcp.tools.slippage import estimate_slippage

__all__ = ["estimate_slippage"]
__version__ = "0.1.0"
