def main():
    print("Running Experiment 2")