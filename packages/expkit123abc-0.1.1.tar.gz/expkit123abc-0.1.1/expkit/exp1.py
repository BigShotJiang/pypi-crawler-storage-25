def main():
    print("Running Experiment 1")