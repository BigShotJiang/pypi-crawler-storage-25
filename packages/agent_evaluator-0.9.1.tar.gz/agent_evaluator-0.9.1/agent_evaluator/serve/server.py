"""
FastAPI application factory for agent-eval serve.
"""
from __future__ import annotations

import os
import urllib.request
from contextlib import asynccontextmanager
from pathlib import Path

try:
    from importlib.metadata import version as _pkg_version
    _VERSION = _pkg_version("agent-evaluator")
except Exception:
    _VERSION = "0.6.0"

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi import Request

from .loader import load_results
from .routers import data as data_router
from .routers import export as export_router
from .routers import stream as stream_router
from .routers import transparency as transparency_router
from .routers import golden as golden_router
from .routers import config as config_router
from .routers import webhook as webhook_router
from .routers import conversation as conversation_router
from .routers import alerts as alerts_router
from .routers import feedback as feedback_router
from .routers import anomaly as anomaly_router
from .routers import cost as cost_router

_TEMPLATES_DIR = Path(__file__).parent / "templates"
# CDN 에셋 캐시는 사용자 홈 디렉토리에 저장 — pip 설치 경로(site-packages)는 읽기 전용일 수 있음
_STATIC_DIR = Path(
    os.environ.get("AGENT_EVALUATOR_CACHE_DIR",
                   str(Path.home() / ".cache" / "agent-evaluator" / "static"))
)

# CDN assets to cache for --offline mode
_OFFLINE_ASSETS = {
    "alpine.min.js":    "https://cdn.jsdelivr.net/npm/alpinejs@3.14.1/dist/cdn.min.js",
    "plotly.min.js":    "https://cdn.jsdelivr.net/npm/plotly.js-dist@2.35.2/plotly.min.js",
    "tabulator.min.js": "https://cdn.jsdelivr.net/npm/tabulator-tables@6.3.0/dist/js/tabulator.min.js",
    "tabulator.min.css":"https://cdn.jsdelivr.net/npm/tabulator-tables@6.3.0/dist/css/tabulator_midnight.min.css",
    "tabulator_simple.min.css": "https://cdn.jsdelivr.net/npm/tabulator-tables@6.3.0/dist/css/tabulator_simple.min.css",
    "chart.min.js":     "https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js",
    "reveal.js":        "https://cdn.jsdelivr.net/npm/reveal.js@5.1.0/dist/reveal.js",
    "reveal.css":       "https://cdn.jsdelivr.net/npm/reveal.js@5.1.0/dist/reveal.css",
    "reveal-reset.css": "https://cdn.jsdelivr.net/npm/reveal.js@5.1.0/dist/reset.css",
    "reveal-night.css": "https://cdn.jsdelivr.net/npm/reveal.js@5.1.0/dist/theme/night.css",
    "reveal-white.css": "https://cdn.jsdelivr.net/npm/reveal.js@5.1.0/dist/theme/white.css",
    "qrcode.min.js":    "https://cdn.jsdelivr.net/npm/qrcode@1.5.1/build/qrcode.min.js",
}


def _setup_offline_assets(app: FastAPI) -> None:
    """Download CDN assets once and mount them at /static."""
    _STATIC_DIR.mkdir(parents=True, exist_ok=True)
    missing = [name for name in _OFFLINE_ASSETS if not (_STATIC_DIR / name).exists()]
    if missing:
        print(f"[offline] {len(missing)}개 CDN 에셋 다운로드 중...")
        for name in missing:
            url = _OFFLINE_ASSETS[name]
            dest = _STATIC_DIR / name
            try:
                urllib.request.urlretrieve(url, dest)
                print(f"  ✅  {name}")
            except Exception as e:
                print(f"  ❌  {name}: {e}")
    app.mount("/static", StaticFiles(directory=str(_STATIC_DIR)), name="static")


def reload_results(app: FastAPI) -> None:
    """Re-scan the results directory and update app state."""
    app.state.result_set = load_results(app.state.results_dir)


def create_app(
    results_dir: Path,
    title: str = "Agent Evaluator Dashboard",
    watch: bool = False,
    version: str = _VERSION,
    offline: bool = False,
) -> FastAPI:
    # ------------------------------------------------------------------ #
    # Lifespan: file watcher startup / shutdown
    # ------------------------------------------------------------------ #
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        if watch:
            from .watcher import FileWatcher
            watcher = FileWatcher(results_dir)
            watcher.start()
            app.state.watcher = watcher

            # Hook: reload result_set on every file change
            original_broadcast = watcher._broadcast

            def _reload_and_broadcast(event: str) -> None:
                reload_results(app)
                original_broadcast(event)

            watcher._broadcast = _reload_and_broadcast

        yield

        if watch and app.state.watcher:
            app.state.watcher.stop()

    app = FastAPI(title=title, version=version, docs_url="/api/docs",
                  redoc_url="/api/redoc", openapi_version="3.1.0",
                  lifespan=lifespan)

    # CORS — localhost-only (dashboard is never exposed to the public internet)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:8765", "http://127.0.0.1:8765",
                       "http://localhost:*", "http://127.0.0.1:*"],
        allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["*"],
    )

    # HTML 응답 캐시 완전 차단 (브라우저 캐시로 인한 구버전 HTML 서빙 방지)
    from starlette.middleware.base import BaseHTTPMiddleware

    class NoCacheHTMLMiddleware(BaseHTTPMiddleware):
        async def dispatch(self, request, call_next):
            response = await call_next(request)
            ct = response.headers.get("content-type", "")
            if "text/html" in ct:
                response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
                response.headers["Pragma"] = "no-cache"
                response.headers["Expires"] = "0"
            return response

    app.add_middleware(NoCacheHTMLMiddleware)

    # State
    app.state.results_dir = results_dir
    app.state.title = title
    app.state.version = version
    app.state.result_set = load_results(results_dir)
    app.state.watcher = None
    app.state.offline = offline

    # Offline static assets
    if offline:
        _setup_offline_assets(app)

    # Routers
    app.include_router(data_router.router)
    app.include_router(export_router.router)
    app.include_router(stream_router.router)
    app.include_router(transparency_router.router)
    app.include_router(golden_router.router)
    app.include_router(config_router.router)
    app.include_router(webhook_router.router)
    app.include_router(conversation_router.router)
    app.include_router(alerts_router.router)
    app.include_router(feedback_router.router)
    app.include_router(anomaly_router.router)
    app.include_router(cost_router.router)

    # Templates
    templates = Jinja2Templates(directory=str(_TEMPLATES_DIR))

    # ------------------------------------------------------------------ #
    # HTML routes
    # ------------------------------------------------------------------ #
    # serve 명령어 삭제 시 마이그레이션 가이드:
    #   1. dashboard.html.j2 파일 삭제
    #   2. 아래 "/" 라우트를 RedirectResponse("/dashboard") 로 교체
    #   3. /slides, /sdk-docs, /api/* 라우트는 그대로 유지 (독립적)
    # ------------------------------------------------------------------ #

    @app.get("/", response_class=HTMLResponse, include_in_schema=False)
    async def dashboard(request: Request):
        resp = templates.TemplateResponse(
            request,
            "dashboard.html.j2",
            {
                "title":   app.state.title,
                "version": app.state.version,
                "watch":   watch,
                "offline": app.state.offline,
            },
        )
        resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        resp.headers["Pragma"] = "no-cache"
        return resp

    @app.get("/slides", response_class=HTMLResponse, include_in_schema=False)
    async def slides(request: Request):
        return templates.TemplateResponse(
            request,
            "slides.html.j2",
            {
                "title":   app.state.title,
                "version": app.state.version,
                "offline": app.state.offline,
            },
        )

    @app.get("/sdk-docs", response_class=HTMLResponse, include_in_schema=False)
    async def sdk_docs(request: Request):
        return templates.TemplateResponse(
            request,
            "sdk_docs.html.j2",
            {
                "title":   app.state.title,
                "version": app.state.version,
                "offline": app.state.offline,
            },
        )

    @app.get("/dashboard", response_class=HTMLResponse, include_in_schema=False)
    async def dashboard2(request: Request):
        resp = templates.TemplateResponse(
            request,
            "dashboard2.html.j2",
            {
                "title":   app.state.title,
                "version": app.state.version,
                "watch":   watch,
                "offline": app.state.offline,
            },
        )
        resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        resp.headers["Pragma"] = "no-cache"
        return resp

    return app
