import re
import time
from typing import List, Tuple
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../")))

from pgsi_analyzer.measurement import measure_energy_to_csv, measure_time_to_csv

from pgsi_analyzer.config import DEFAULT_PARAMS as __default__, get_measurement_runs


# Minimal dummy FASTA sequence when no input file is provided (e.g. file_path empty or missing)
_DUMMY_FASTA_SEQUENCE = "agggtaaa|tttaccct" * 100


def read_fasta_file(file_path: str) -> str:
    """
    Reads a FASTA file and returns the DNA sequence as a single string.
    Removes descriptions and line breaks.
    If file_path is empty or the file is missing, returns a minimal dummy sequence
    so the benchmark can run without failing.
    """
    if not file_path or not os.path.isfile(file_path):
        return _DUMMY_FASTA_SEQUENCE
    with open(file_path, 'r') as file:
        content = file.read()

    # Remove description lines and newlines
    return re.sub(r">.*\n|\n", "", content)

def count_patterns(sequence: str, patterns: List[str]) -> List[Tuple[str, int]]:
    """
    Counts occurrences of each pattern in the DNA sequence.
    """
    results = []
    for pattern in patterns:
        count = len(re.findall(pattern, sequence))
        results.append((pattern, count))
    return results

def apply_substitutions(sequence: str, substitutions: List[Tuple[str, str]]) -> str:
    """
    Applies a series of substitution patterns to the DNA sequence.
    """
    for pattern, replacement in substitutions:
        sequence = re.sub(pattern, replacement, sequence)
    return sequence

def regex_redux(file_path: str) -> None:
    """
    Main function to execute the Regex-Redux benchmark.
    """
    # Step 1: Read and clean the input sequence
    sequence = read_fasta_file(file_path).lower()
    initial_length = len(sequence)

    # Step 2: Count the original patterns
    patterns = [
        'agggtaaa|tttaccct',
        '[cgt]gggtaaa|tttaccc[acg]',
        'a[act]ggtaaa|tttacc[agt]t',
        'ag[act]gtaaa|tttac[agt]ct',
        'agg[act]taaa|ttta[agt]cct',
        'aggg[acg]aaa|ttt[cgt]ccct',
        'agggt[cgt]aa|tt[acg]accct',
        'agggta[cgt]a|t[acg]taccct',
        'agggtaa[cgt]|[acg]ttaccct'
    ]

    # Counting occurrences
    pattern_counts = count_patterns(sequence, patterns)

    # Step 3: Apply the substitutions
    substitutions = [
        (r'tHa[Nt]', '<4>'),
        (r'aND|caN|Ha[DS]|WaS', '<3>'),
        (r'a[NSt]|BY', '<2>'),
        (r'<[^>]*>', '|'),
        (r'\|[^|][^|]*\|', '-')
    ]

    modified_sequence = apply_substitutions(sequence, substitutions)

    # Step 4: Output results
    print("Pattern Counts:")
    for pattern, count in pattern_counts:
        print(f"{pattern}: {count}")

    print("\nInitial Length:", initial_length)
    print("Cleaned Length:", len(sequence))
    print("Substituted Length:", len(modified_sequence))

@measure_time_to_csv(n=get_measurement_runs("regex_redux"), csv_filename="regex_redux_pycompile")
def run_time_benchmark(file_path: str) -> None:
    """
    Measure and log the time it takes to run the Regex-Redux benchmark.
    """
    regex_redux(file_path)
    time.sleep(0.01)

@measure_energy_to_csv(n=get_measurement_runs("regex_redux"), csv_filename="regex_redux_pycompile")
def run_energy_benchmark(file_path: str) -> None:
    """
    Measure and log the energy consumption of the Regex-Redux benchmark.
    """
    regex_redux(file_path)
    time.sleep(0.01)


if __name__ == "__main__":
    file_path = __default__["regex_redux"].get("file_path", "") or ""

    # You can change this to driver(file_path) if you want plain output
    run_energy_benchmark(file_path)
    run_time_benchmark(file_path)
