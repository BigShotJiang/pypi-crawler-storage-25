import os
from pathlib import Path

from setuptools import Extension, setup

def _add_path_if_exists(bucket, path):
    if path and os.path.isdir(path) and path not in bucket:
        bucket.append(path)


def _resolve_windows_sdk_version(sdk_root):
    raw_candidates = [
        os.environ.get("WindowsSDKVersion", ""),
        os.environ.get("UCRTVersion", ""),
        os.environ.get("WindowsSDKLibVersion", ""),
    ]

    for candidate in raw_candidates:
        candidate = candidate.strip().strip("\\/")
        if candidate and os.path.isdir(os.path.join(sdk_root, "Include", candidate)):
            return candidate

    include_root = Path(sdk_root) / "Include"
    if not include_root.is_dir():
        return ""

    versions = sorted(
        [p.name for p in include_root.iterdir() if p.is_dir()],
        reverse=True,
    )
    return versions[0] if versions else ""


def _resolve_windows_sdk_root():
    env_roots = [
        os.environ.get("WindowsSdkDir", ""),
        os.environ.get("UniversalCRTSdkDir", ""),
        r"C:\Program Files (x86)\Windows Kits\10",
    ]
    for root in env_roots:
        root = root.strip().strip('"')
        if root and os.path.isdir(root):
            return root
    return ""


def _split_include_env():
    include_env = os.environ.get("INCLUDE", "")
    return [p for p in include_env.split(os.pathsep) if p]


# 1. Handle Windows SDK / MSVC Paths
sdk_root = _resolve_windows_sdk_root()
sdk_version = _resolve_windows_sdk_version(sdk_root) if sdk_root else ""
msvc_root = os.environ.get("VCToolsInstallDir", "").rstrip("\\")

include_dirs = ["src/mWinPy/native"]
library_dirs = []

if sdk_root and sdk_version:
    _add_path_if_exists(include_dirs, os.path.join(sdk_root, "Include", sdk_version, "ucrt"))
    _add_path_if_exists(include_dirs, os.path.join(sdk_root, "Include", sdk_version, "shared"))
    _add_path_if_exists(include_dirs, os.path.join(sdk_root, "Include", sdk_version, "um"))
    _add_path_if_exists(library_dirs, os.path.join(sdk_root, "Lib", sdk_version, "ucrt", "x64"))
    _add_path_if_exists(library_dirs, os.path.join(sdk_root, "Lib", sdk_version, "um", "x64"))

for include_path in _split_include_env():
    _add_path_if_exists(include_dirs, include_path)

if msvc_root:
    _add_path_if_exists(include_dirs, os.path.join(msvc_root, "include"))
    _add_path_if_exists(library_dirs, os.path.join(msvc_root, "lib", "x64"))

# 2. Define the Extension
ext = Extension(
    name="mWinPy._mWinPy",
    sources=[
        "src/mWinPy/native/module/_mWinPy.c",
        "src/mWinPy/native/process/mProcess.c",
        "src/mWinPy/native/process/py_mProcess.c",
    ],
    include_dirs=include_dirs,
    library_dirs=library_dirs,
    libraries=["user32", "psapi"],
    extra_link_args=["/MANIFEST:NO"] if os.name == "nt" else [],
)

setup(
    ext_modules=[ext],
)