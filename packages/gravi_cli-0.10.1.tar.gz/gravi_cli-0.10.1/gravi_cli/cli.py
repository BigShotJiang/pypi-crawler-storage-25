"""
Main CLI interface for gravi.

Implements all CLI commands using Click framework.
"""

import os
import sys
import json
import time
import socket
import shlex
import webbrowser
from datetime import datetime, UTC

import click

from . import __version__
from .auth import get_mom_url, get_mom_token, get_instance_config, get_instance_token
from .client import MomClient
from .config import (
    Config,
    load_config,
    save_config,
    delete_config,
    config_exists,
    get_config_path,
)
from .exceptions import (
    NotAuthenticatedError,
    InvalidTokenError,
    APIError,
    RateLimitError,
    ConfigError,
    PermissionDeniedError,
)


@click.group()
@click.version_option(version=__version__, prog_name="gravi")
def main():
    """Gravi CLI - Gravitate infrastructure management tool."""
    pass


@main.command()
@click.option(
    "--mom-url",
    envvar="GRAVI_MOM_URL",
    default="https://mom.gravitate.energy/api",
    help="Mom API URL (default: https://mom.gravitate.energy/api)",
)
def login(mom_url):
    """Authenticate with mom via browser."""
    client = MomClient(mom_url)

    # Check if already logged in
    if config_exists():
        try:
            config = load_config()
            click.echo(f"Already logged in as {config.user_email}")
            if click.confirm("Do you want to log in again?", default=False):
                delete_config()
            else:
                return
        except Exception:
            # Config corrupted, proceed with login
            pass

    # Step 1: Initiate device authorization
    click.echo("Initiating authentication...")

    # Get device name from hostname with fallback
    try:
        device_name = socket.gethostname()
        if not device_name or device_name == "localhost":
            device_name = "unknown-device"
    except Exception:
        device_name = "unknown-device"

    try:
        device_auth = client.initiate_device_auth(device_name=device_name)
    except APIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    # Step 2: Display instructions
    click.echo("\n" + "=" * 60)
    click.echo("Please authorize this CLI tool:")
    click.echo(f"  1. Opening browser to: {device_auth['verification_uri_complete']}")
    click.echo(f"  2. Or manually visit: {device_auth['verification_uri']}")
    click.echo(f"     and enter code: {device_auth['user_code']}")
    click.echo("=" * 60 + "\n")

    # Step 3: Open browser automatically
    try:
        webbrowser.open(device_auth["verification_uri_complete"])
    except Exception:
        click.echo("Could not open browser automatically. Please visit the URL manually.")

    # Step 4: Poll for authorization
    device_code = device_auth["device_code"]
    interval = device_auth["interval"]
    expires_in = device_auth["expires_in"]

    click.echo("Waiting for authorization...", nl=False)

    start_time = time.time()
    while time.time() - start_time < expires_in:
        time.sleep(interval)

        try:
            result = client.poll_device_auth(device_code)
        except APIError as e:
            if "expired" in str(e).lower():
                click.echo(" ✗")
                click.echo("\nError: Authorization timed out. Please try again.", err=True)
                sys.exit(1)
            # Continue polling on other errors
            click.echo(".", nl=False)
            continue

        if result.get("error"):
            if result["error"] == "expired_token":
                click.echo(" ✗")
                click.echo("\nError: Authorization timed out. Please try again.", err=True)
                sys.exit(1)
            # Continue polling for other errors
            click.echo(".", nl=False)
            continue

        if result.get("authorized"):
            click.echo(" ✓")

            # Step 5: Extract credentials from response
            user_email = result["user_email"]
            token_id = result["token_id"]
            refresh_token = result["refresh_token"]
            refresh_expires_in = result["refresh_expires_in"]
            device_name = result["device_name"]  # Final device name (may have been edited by user)

            # Save config (without mom_url - it's runtime only)
            config = Config(
                user_email=user_email,
                refresh_token=refresh_token,
                refresh_token_expires_at=datetime.now(UTC) + timedelta(seconds=refresh_expires_in),
                token_id=token_id,
                device_name=device_name,
            )

            try:
                save_config(config)
            except ConfigError as e:
                click.echo(f"\nError saving config: {e}", err=True)
                sys.exit(1)

            click.echo(f"\n✓ Successfully logged in as {user_email}")
            click.echo(f"  Credentials saved to: {get_config_path()}")
            return

        click.echo(".", nl=False)

    # Timeout
    click.echo(" ✗")
    click.echo("\nError: Authorization timed out or cancelled. Please try again.", err=True)
    sys.exit(1)


@main.command()
def logout():
    """Clear local credentials and revoke token on backend."""
    try:
        config = load_config()

        # Try to revoke token on backend
        try:
            mom_token = get_mom_token()
            mom_url = get_mom_url()
            client = MomClient(mom_url)
            # Delete this specific token by token_id
            client.delete_cli_token(config.token_id, mom_token)
            click.echo("✓ Token revoked on server")
        except Exception as e:
            click.echo(f"⚠  Could not revoke token on server: {e}")
            click.echo("  (Will still clear local credentials)")

        # Delete local config file
        config_path = get_config_path()
        if delete_config():
            click.echo(f"✓ Local credentials cleared from {config_path}")
        else:
            click.echo("No local credentials found")

    except FileNotFoundError:
        click.echo("✓ Logged out (no existing session)")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
def status():
    """Show login status and token expiry."""
    try:
        config = load_config()

        mom_url = get_mom_url()

        click.echo("Gravi CLI Status")
        click.echo("=" * 40)
        click.echo(f"User:         {config.user_email}")
        click.echo(f"Mom URL:      {mom_url}")
        click.echo(f"Device:       {config.device_name}")
        click.echo(f"Token ID:     {config.token_id}")

        # Calculate expiry
        # Handle both string (from config file) and datetime object
        if isinstance(config.refresh_token_expires_at, str):
            expires_at = datetime.fromisoformat(config.refresh_token_expires_at.replace("Z", "+00:00"))
        else:
            expires_at = config.refresh_token_expires_at

        time_remaining = expires_at - datetime.now(UTC)
        days_remaining = time_remaining.days

        if days_remaining < 0:
            click.echo("Token:        ✗ EXPIRED")
            click.echo("Action:       Run 'gravi login' to re-authenticate")
        elif days_remaining < 2:
            click.echo(f"Token:        ⚠  Expires in {days_remaining} day(s)")
            click.echo("Action:       Will auto-renew on next use")
        else:
            click.echo(f"Token:        ✓ Valid for {days_remaining} more days")

    except FileNotFoundError:
        click.echo("Not logged in. Run 'gravi login' to authenticate.")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)


@main.command()
def whoami():
    """Show current user info and mom URL."""
    try:
        config = load_config()

        # Get fresh access token to verify we're still authenticated
        mom_token = get_mom_token()
        mom_url = get_mom_url()

        click.echo(f"Logged in as: {config.user_email}")
        click.echo(f"Mom URL:      {mom_url}")
        click.echo(f"Device:       {config.device_name}")

    except FileNotFoundError:
        click.echo("Not logged in. Run 'gravi login' to authenticate.")
    except NotAuthenticatedError:
        click.echo("Session expired. Run 'gravi login' to re-authenticate.")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)


@main.group()
def creds():
    """Manage shared DB credentials used by bbd-client.

    Mom strips credentials from the connection strings it returns, so
    BBDClient.from_mom needs the dev/prod Atlas user+password locally.
    These are stored at ~/.config/gravitate/bb_tools.env and read by
    bbd_client at construction time.
    """
    pass


_CREDS_PATH = os.path.expanduser("~/.config/gravitate/bb_tools.env")
_CREDS_KEYS = {"dev": "DB_DEV_CREDENTIALS", "prod": "DB_PROD_CREDENTIALS"}
_OP_ITEM_NAMES = {
    "dev": "Gravitate Atlas Dev Credentials",
    "prod": "Gravitate Atlas Prod Credentials",
}


def _read_creds_file() -> dict:
    if not os.path.isfile(_CREDS_PATH):
        return {}
    out = {}
    with open(_CREDS_PATH) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, val = line.partition("=")
            out[key.strip()] = val.strip().strip('"').strip("'")
    return out


def _write_creds_file(values: dict) -> None:
    os.makedirs(os.path.dirname(_CREDS_PATH), exist_ok=True)
    lines = [f"{k}={v}" for k, v in values.items()]
    with open(_CREDS_PATH, "w") as f:
        f.write("\n".join(lines) + "\n")
    try:
        os.chmod(_CREDS_PATH, 0o600)
    except OSError:
        pass


def _redact(value: str) -> str:
    """Show 'user:****' so we can confirm what's set without leaking."""
    if not value or ":" not in value:
        return "<malformed>"
    user, _, _ = value.partition(":")
    return f"{user}:****"


# ---------------------------------------------------------------------------
# 1Password integration
# ---------------------------------------------------------------------------
# Same item-name convention bbd-client uses for lookups: one item per tier
# in the user's personal vault, with 'username' and 'password' fields.

def _op_available() -> bool:
    """True when `op` is on PATH and at least one account is configured."""
    import shutil
    if shutil.which("op") is None:
        return False
    import subprocess
    try:
        result = subprocess.run(
            ["op", "account", "list", "--format=json"],
            capture_output=True, timeout=5, check=False,
        )
        return result.returncode == 0 and len(result.stdout.strip()) > 2
    except (subprocess.TimeoutExpired, OSError):
        return False


_op_responding = True  # process-level: flips False after first timeout


def _op_read_item(tier: str) -> tuple[str, str] | None:
    """Read (username, password) from 1P for tier. None on any failure.

    3-second timeout falls through fast when the desktop integration is
    waiting for an auth that can't happen (AFK / locked). After the first
    such failure in this process we stop trying — subsequent tiers fall
    through immediately instead of burning another 3s.
    """
    global _op_responding
    if not _op_responding:
        return None
    import json
    import subprocess
    try:
        result = subprocess.run(
            ["op", "item", "get", _OP_ITEM_NAMES[tier], "--format", "json"],
            capture_output=True, timeout=3, check=False,
        )
    except subprocess.TimeoutExpired:
        _op_responding = False
        return None
    except OSError:
        _op_responding = False
        return None
    if result.returncode != 0:
        return None
    try:
        item = json.loads(result.stdout)
        username = password = None
        for f in item.get("fields", []):
            purpose = f.get("purpose", "")
            ident = (f.get("id") or "").lower()
            label = (f.get("label") or "").lower()
            if purpose == "USERNAME" or ident == "username" or label == "username":
                username = f.get("value")
            elif purpose == "PASSWORD" or ident == "password" or label == "password":
                password = f.get("value")
        if username and password:
            return username, password
    except (json.JSONDecodeError, KeyError, TypeError):
        pass
    return None


def _op_item_exists(tier: str) -> bool:
    import subprocess
    try:
        result = subprocess.run(
            ["op", "item", "get", _OP_ITEM_NAMES[tier], "--format", "json"],
            capture_output=True, timeout=10, check=False,
        )
    except (subprocess.TimeoutExpired, OSError):
        return False
    return result.returncode == 0


def _op_write_item(tier: str, username: str, password: str) -> bool:
    """Create or update the 1P item for tier. Returns True on success."""
    import subprocess
    item_name = _OP_ITEM_NAMES[tier]
    if _op_item_exists(tier):
        # Update existing — `op item edit` updates fields by label.
        cmd = [
            "op", "item", "edit", item_name,
            f"username={username}",
            f"password={password}",
        ]
    else:
        cmd = [
            "op", "item", "create",
            "--category=login",
            f"--title={item_name}",
            "--tags=Gravitate,Atlas",
            f"username={username}",
            f"password={password}",
        ]
    try:
        result = subprocess.run(cmd, capture_output=True, timeout=20, check=False)
    except (subprocess.TimeoutExpired, OSError) as e:
        click.echo(f"  ✗ op subprocess failed: {e}", err=True)
        return False
    if result.returncode != 0:
        click.echo(
            f"  ✗ op {cmd[1]} {cmd[2]} failed: {result.stderr.decode(errors='replace').strip()}",
            err=True,
        )
        return False
    return True


def _try_mom_atlas(tier: str) -> str | None:
    """Fetch tier creds from mom; return 'user:pass' or None on miss/failure.

    Failures (no auth, network, server) are non-fatal — caller falls
    through to file/1P. Cached per process to avoid repeated round-trips.
    """
    cached = _MOM_CRED_CACHE.get(tier)
    if cached is not _SENTINEL:
        return cached
    try:
        from .auth import get_atlas_credentials
        result = get_atlas_credentials(tier)
    except Exception:
        # NotAuthenticatedError / APIError / network — silent fall-through.
        _MOM_CRED_CACHE[tier] = None
        return None
    if not result:
        _MOM_CRED_CACHE[tier] = None
        return None
    cred = f"{result['username']}:{result['password']}"
    _MOM_CRED_CACHE[tier] = cred
    return cred


_SENTINEL = object()
_MOM_CRED_CACHE: dict[str, str | None | object] = {
    "dev": _SENTINEL, "prod": _SENTINEL,
}


def _resolve_credential(tier: str) -> tuple[str | None, str]:
    """Return (value, source) for tier — same lookup order as bbd-client.

    Order: env var > mom > local file > 1Password.
    source ∈ {'env', 'mom', 'file', '1password', 'missing'}.
    """
    key = _CREDS_KEYS[tier]
    if v := os.getenv(key):
        return v, "env"
    if v := _try_mom_atlas(tier):
        return v, "mom"
    file_values = _read_creds_file()
    if v := file_values.get(key):
        return v, "file"
    if _op_available():
        pair = _op_read_item(tier)
        if pair:
            return f"{pair[0]}:{pair[1]}", "1password"
    return None, "missing"


@creds.command("status")
def creds_status():
    """Show which DB credentials are configured and where they come from.

    Lookup order: env var > 1Password > ~/.config/gravitate/bb_tools.env.
    The same order bbd-client uses at construction time.
    """
    op_avail = _op_available()
    click.echo(f"1Password CLI: {'available' if op_avail else 'not available'}"
               + (f" (items: {', '.join(_OP_ITEM_NAMES.values())})" if op_avail else ""))
    click.echo(f"File:          {_CREDS_PATH}"
               + ("" if os.path.isfile(_CREDS_PATH) else "  (does not exist)"))
    click.echo()
    for tier in _CREDS_KEYS:
        value, source = _resolve_credential(tier)
        if value:
            click.echo(f"  ✓ {tier:4s}  from {source:9s}  {_redact(value)}")
        else:
            click.echo(f"  ✗ {tier:4s}  <missing>")


@creds.command("check")
@click.option("--tier", type=click.Choice(["dev", "prod", "any"]), default="any",
              help="Which tier(s) must be set. 'any' passes if at least one is set.")
def creds_check(tier):
    """Exit 0 if required credentials are resolvable, 1 if missing.

    Checks the full lookup chain (env > 1Password > file). Useful for
    scripts and the dev bootstrap to detect missing config.
    """
    have = {t: _resolve_credential(t)[0] is not None for t in _CREDS_KEYS}
    ok = any(have.values()) if tier == "any" else have[tier]
    if ok:
        click.echo("OK")
        sys.exit(0)
    click.echo("Missing required DB credentials. Run: gravi creds set", err=True)
    sys.exit(1)


@creds.command("set")
@click.option("--dev", "dev_value", default=None,
              help="Dev credentials as 'user:pass' (one-shot, non-interactive).")
@click.option("--prod", "prod_value", default=None,
              help="Prod credentials as 'user:pass' (one-shot, non-interactive).")
@click.option("--from-env", is_flag=True,
              help="Read DB_DEV_CREDENTIALS / DB_PROD_CREDENTIALS from environment.")
@click.option("--stdin", "use_stdin", is_flag=True,
              help="Read newline-separated 'tier=user:pass' lines from stdin.")
@click.option("--mom", "use_mom", is_flag=True,
              help="Force write to mom's encrypted secrets store (default).")
@click.option("--1password", "use_1password", is_flag=True,
              help="Force write to 1Password instead of mom.")
@click.option("--file", "use_file", is_flag=True,
              help="Force write to ~/.config/gravitate/bb_tools.env instead of mom.")
def creds_set(dev_value, prod_value, from_env, use_stdin, use_mom, use_1password, use_file):
    """Set DB credentials. Mom-encrypted by default.

    \b
    Backend selection (one wins; default is mom):
      --mom              Mom's /api/secrets/atlas (encrypted at rest).
                         Requires `gravi login`. This is the default.
      --1password        1Password 'Gravitate Atlas {Tier} Credentials'
                         items in your personal vault.
      --file             ~/.config/gravitate/bb_tools.env (mode 0600).

    \b
    Input modes:
      Interactive        Prompts for any tier not provided via flags.
      --dev / --prod     One-shot 'user:pass' (visible in shell history).
      --from-env         Reads from current DB_*_CREDENTIALS env vars.
      --stdin            Reads 'tier=user:pass' lines from stdin.

    \b
    bbd-client looks up creds in this order at runtime:
      env var > mom > file > 1Password
    """
    selected = sum(1 for f in (use_mom, use_1password, use_file) if f)
    if selected > 1:
        click.echo("Error: --mom / --1password / --file are mutually exclusive.", err=True)
        sys.exit(2)

    if use_1password:
        if not _op_available():
            click.echo("Error: --1password requested but `op` is not installed or signed in.", err=True)
            sys.exit(2)
        backend = "1password"
    elif use_file:
        backend = "file"
    else:
        # Default: mom. (use_mom flag is just explicit; same as default.)
        backend = "mom"

    # Collect new creds from non-interactive sources first.
    new_creds: dict[str, str] = {}
    if from_env:
        for tier, key in _CREDS_KEYS.items():
            if v := os.getenv(key):
                new_creds[tier] = v
    if use_stdin:
        for line in sys.stdin:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            tier, _, value = line.partition("=")
            tier = tier.strip().lower()
            if tier in _CREDS_KEYS and value.strip():
                new_creds[tier] = value.strip()
    if dev_value:
        new_creds["dev"] = dev_value
    if prod_value:
        new_creds["prod"] = prod_value

    # Validate format.
    for tier, cred in new_creds.items():
        if ":" not in cred:
            click.echo(f"Error: {tier} credentials must be 'user:pass' (got '{cred[:8]}...')", err=True)
            sys.exit(2)

    # Interactive fallback for anything not supplied.
    if not new_creds and not sys.stdin.isatty():
        click.echo(
            "Error: not running interactively, and no --dev/--prod/--from-env/--stdin flag given.\n"
            "Run 'gravi creds set --help' for non-interactive options.",
            err=True,
        )
        sys.exit(2)

    if not new_creds:
        # Interactive prompts. For each tier, show current source if any.
        for tier in ("dev", "prod"):
            current_value, current_source = _resolve_credential(tier)
            if current_value:
                if not click.confirm(
                    f"{tier} credentials already set (from {current_source}: {_redact(current_value)}). Update?",
                    default=False,
                ):
                    continue
            click.echo(f"\n[{tier}] DB credentials")
            username = click.prompt("  username", default="", show_default=False)
            if not username:
                click.echo("  (skipped)")
                continue
            password = click.prompt("  password", hide_input=True, default="", show_default=False)
            if not password:
                click.echo("  (skipped — password required)")
                continue
            new_creds[tier] = f"{username}:{password}"

    if not new_creds:
        click.echo("\nNo changes made.")
        return

    # Write to chosen backend.
    if backend == "mom":
        click.echo(f"\nWriting to mom ({len(new_creds)} tier(s))...")
        from .auth import set_atlas_credentials
        ok_count = 0
        for tier, cred in new_creds.items():
            username, _, password = cred.partition(":")
            try:
                set_atlas_credentials(tier, username, password)
                click.echo(f"  ✓ {tier:4s}  stored in mom")
                # Invalidate local cache so subsequent reads see the new value.
                _MOM_CRED_CACHE[tier] = _SENTINEL
                ok_count += 1
            except NotAuthenticatedError:
                click.echo(
                    f"\nError: not logged in to mom. Run `gravi login` first,\n"
                    f"or pass --file to store in ~/.config/gravitate/bb_tools.env.",
                    err=True,
                )
                sys.exit(1)
            except Exception as e:
                click.echo(f"  ✗ {tier:4s}  {type(e).__name__}: {e}", err=True)
        if ok_count != len(new_creds):
            sys.exit(1)
    elif backend == "1password":
        click.echo(f"\nWriting to 1Password ({len(new_creds)} tier(s))...")
        ok_count = 0
        for tier, cred in new_creds.items():
            username, _, password = cred.partition(":")
            if _op_write_item(tier, username, password):
                click.echo(f"  ✓ {tier:4s}  {_OP_ITEM_NAMES[tier]}")
                ok_count += 1
        if ok_count != len(new_creds):
            click.echo(f"\n{ok_count}/{len(new_creds)} tier(s) saved. Re-run to retry failed ones.", err=True)
            sys.exit(1)
    else:  # file
        values = _read_creds_file()
        for tier, cred in new_creds.items():
            values[_CREDS_KEYS[tier]] = cred
        _write_creds_file(values)
        click.echo(f"\n✓ Wrote {len(new_creds)} tier(s) to {_CREDS_PATH} (mode 0600)")

    click.echo()
    creds_status.callback()


@creds.command("prime")
@click.option("--tmux", is_flag=True,
              help="Also export into the running tmux server's global env so "
                   "all current and future panes inherit the values.")
@click.option("--unset", is_flag=True,
              help="Print 'unset' commands for the same vars (cleanup).")
def creds_prime(tmux, unset):
    """Print eval-able shell exports for DB_DEV_CREDENTIALS / DB_PROD_CREDENTIALS.

    \b
    Use case: you're at the machine now but plan to be away (tmux session,
    locked desktop). Prime the env vars once while authenticated; tmux
    panes hold them in memory and bbd-client picks them up via env-var
    lookup (highest priority) without ever touching `op` again — even
    when the desktop is locked.

    \b
    Usage:
      eval $(gravi creds prime)            # current shell
      eval $(gravi creds prime --tmux)     # also tmux global env
      eval $(gravi creds prime --unset)    # clear them later

    \b
    Tradeoff: credentials live in process memory until the shell exits.
    On a personal locked machine that's fine — anyone with /proc access
    is already root.
    """
    if unset:
        for key in _CREDS_KEYS.values():
            click.echo(f"unset {key};")
            if tmux:
                click.echo(f"tmux set-environment -gru {key} 2>/dev/null;")
        return

    missing = []
    for tier, key in _CREDS_KEYS.items():
        value, source = _resolve_credential(tier)
        if not value:
            missing.append(tier)
            continue
        # Single-quote the value, escaping embedded single quotes for shell.
        escaped = value.replace("'", "'\\''")
        click.echo(f"export {key}='{escaped}';")
        if tmux:
            click.echo(f"tmux set-environment -g {key} '{escaped}' 2>/dev/null;")

    # Echo a comment to stderr so the user sees what happened (eval consumes stdout).
    if missing:
        click.echo(f"# WARNING: missing credentials for: {', '.join(missing)}", err=True)
    else:
        click.echo(
            "# Primed DB_DEV_CREDENTIALS + DB_PROD_CREDENTIALS"
            + (" (and tmux global env)" if tmux else ""),
            err=True,
        )


@main.group()
def tokens():
    """Manage CLI authorization tokens."""
    pass


@tokens.command("list")
def tokens_list():
    """List all authorized CLI tokens."""
    try:
        config = load_config()
        mom_token = get_mom_token()
        mom_url = get_mom_url()
        client = MomClient(mom_url)

        response = client.list_cli_tokens(mom_token)

        if not response["tokens"]:
            click.echo("No active tokens found.")
            return

        click.echo("Active CLI Tokens:")
        click.echo("=" * 80)

        for token in response["tokens"]:
            is_current = token["id"] == config.token_id
            marker = "→" if is_current else " "

            click.echo(f"{marker} ID: {token['id']}")
            click.echo(f"  Device:      {token['device_name']}")
            click.echo(f"  Type:        {token['token_type']}")
            click.echo(f"  Created:     {token['created_at']}")
            click.echo(f"  Last used:   {token.get('last_used_at', 'Never')}")
            click.echo(f"  Expires in:  {token['days_until_expiry']} days")
            if is_current:
                click.echo("  (Current session)")
            click.echo()

    except NotAuthenticatedError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@tokens.command("revoke")
@click.argument("token_id", required=False)
@click.option("--all", is_flag=True, help="Revoke all tokens")
def tokens_revoke(token_id, all):
    """Revoke a CLI token by ID, or all tokens."""
    try:
        config = load_config()
        mom_token = get_mom_token()
        mom_url = get_mom_url()
        client = MomClient(mom_url)

        if all:
            if not click.confirm(
                "Are you sure you want to revoke ALL tokens? This will log you out everywhere.",
                default=False,
            ):
                click.echo("Cancelled.")
                return

            # Get all tokens and revoke them
            response = client.list_cli_tokens(mom_token)
            for token in response["tokens"]:
                client.delete_cli_token(token["id"], mom_token)
                click.echo(f"✓ Revoked token: {token['device_name']}")

            # Clear local config
            delete_config()
            click.echo("\n✓ All tokens revoked. You are now logged out.")

        elif token_id:
            client.delete_cli_token(token_id, mom_token)
            click.echo(f"✓ Token {token_id} revoked")

            # If revoking current token, clear local config
            # Compare as strings to handle both string and ObjectId types
            if str(token_id) == str(config.token_id):
                delete_config()
                click.echo("✓ Current session ended. Run 'gravi login' to re-authenticate.")

        else:
            click.echo("Error: Specify a token ID or use --all flag", err=True)
            click.echo("Usage: gravi tokens revoke <token_id>")
            click.echo("       gravi tokens revoke --all")
            sys.exit(1)

    except NotAuthenticatedError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument("instance_key")
@click.option(
    "--format",
    type=click.Choice(["json", "env"]),
    default="json",
    help="Output format (default: json)",
)
def config(instance_key, format):
    """Get instance configuration (credentials, URLs, etc.).

    Mom strips username:password from connection-string fields (conn_str,
    fdb_conn_str, ...). Other values like system_psk are returned as-is —
    callers (scripts, bbd-client) need them.
    """
    try:
        config_data = get_instance_config(instance_key)

        if format == "json":
            click.echo(json.dumps(config_data, indent=2))
        elif format == "env":
            # Flatten config for environment variables
            click.echo(f"# Environment variables for {instance_key}")
            click.echo(f"export INSTANCE_KEY={shlex.quote(config_data['instance_key'])}")
            click.echo(f"export INSTANCE_NAME={shlex.quote(config_data['name'])}")
            click.echo(f"export API_URL={shlex.quote(config_data['api_url'])}")

            for key, value in config_data.get("config", {}).items():
                env_key = key.upper()
                # Quote values to handle special characters and spaces
                click.echo(f"export {env_key}={shlex.quote(str(value))}")

    except NotAuthenticatedError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument("instance_key")
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    help="Output as JSON for scripting",
)
@click.option(
    "--admin",
    is_flag=True,
    default=False,
    help="Request an admin token (only honored if you have admin access on the target).",
)
def token(instance_key, output_json, admin):
    """Get access and refresh tokens for an instance."""
    try:
        token_data = get_instance_token(instance_key, admin_requested=admin)

        if output_json:
            click.echo(json.dumps({
                "access_token": token_data.get("access_token", ""),
                "refresh_token": token_data.get("refresh_token", ""),
            }))
        else:
            click.echo(f"AccessToken: {token_data.get('access_token', 'N/A')}")
            click.echo(f"RefreshToken: {token_data.get('refresh_token', 'N/A')}")

    except NotAuthenticatedError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except PermissionDeniedError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


# Add missing import for timedelta
from datetime import timedelta

import asyncio


@main.command()
@click.argument("burner_id", required=False)
@click.option("--mongo-port", type=int, help="Local port for MongoDB tunnel (default: auto from 27017)")
@click.option("--redis-port", type=int, help="Local port for Redis tunnel (default: auto from 6379)")
def dbtun(burner_id, mongo_port, redis_port):
    """Tunnel to database services in a burner instance.

    Opens local ports that tunnel to MongoDB and Redis in the burner.
    Use MongoDB Compass or redis-cli to connect via the displayed connection strings.

    If BURNER_ID is not provided, uses the most recently created burner.

    Examples:

        gravi dbtun              # Auto-select newest burner

        gravi dbtun burner01     # Connect to specific burner

        gravi dbtun tank --mongo-port 27500   # Use specific MongoDB port
    """
    from .tunnel import run_tunnel

    try:
        mom_token = get_mom_token()
        mom_url = get_mom_url()
        client = MomClient(mom_url)

        # If no burner_id provided, find the newest one
        if not burner_id:
            response = client.list_burners(mom_token, status="ready")
            burners = response.get("burners", [])

            if not burners:
                click.echo("Error: No active burners found. Create one first.", err=True)
                sys.exit(1)

            # Burners are sorted by created_at desc, so first is newest
            burner_id = burners[0]["burner_id"]
            click.echo(f"Auto-selected: {burner_id}")

        # Run the tunnel
        asyncio.run(run_tunnel(mom_url, mom_token, burner_id, mongo_port, redis_port))

    except NotAuthenticatedError:
        click.echo("Error: Please run 'gravi login' first", err=True)
        sys.exit(1)
    except KeyboardInterrupt:
        click.echo("\nDisconnected.")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument("burner_id")
@click.argument("database")
@click.argument("collection")
@click.option("--filter", "-f", "query_filter", help="JSON query filter (e.g., '{\"status\": \"active\"}')")
@click.option("--projection", "-p", help="JSON projection (e.g., '{\"_id\": 0, \"name\": 1}')")
@click.option("--sort", "-s", help="JSON sort spec (e.g., '{\"created_at\": -1}')")
@click.option("--limit", "-l", type=int, default=10, help="Max documents to return (default: 10)")
@click.option("--skip", type=int, default=0, help="Documents to skip")
@click.option("--count", is_flag=True, help="Return count instead of documents")
@click.option("--one", is_flag=True, help="Return only the first document (find_one)")
@click.option("--raw", is_flag=True, help="Output raw JSON (no formatting)")
def query(burner_id, database, collection, query_filter, projection, sort, limit, skip, count, one, raw):
    """Query a burner's MongoDB database without a tunnel.

    Execute read-only queries directly through Mom API. Useful for quick
    data inspection or scripted access.

    Examples:

        gravi query tank backend orders --limit 5

        gravi query tank backend orders -f '{"status": "delivered"}' --count

        gravi query tank backend users --one -f '{"email": "admin@test.com"}'

        gravi query tank pricing price_v2 -s '{"effective_date": -1}' -l 20
    """
    import json as json_module

    try:
        mom_token = get_mom_token()
        mom_url = get_mom_url()
        client = MomClient(mom_url)

        # Determine operation
        operation = "find"
        if count:
            operation = "count"
        elif one:
            operation = "find_one"

        # Parse JSON options
        filter_dict = None
        if query_filter:
            try:
                filter_dict = json_module.loads(query_filter)
            except json_module.JSONDecodeError as e:
                click.echo(f"Error: Invalid JSON filter: {e}", err=True)
                sys.exit(1)

        projection_dict = None
        if projection:
            try:
                projection_dict = json_module.loads(projection)
            except json_module.JSONDecodeError as e:
                click.echo(f"Error: Invalid JSON projection: {e}", err=True)
                sys.exit(1)

        sort_dict = None
        if sort:
            try:
                sort_dict = json_module.loads(sort)
            except json_module.JSONDecodeError as e:
                click.echo(f"Error: Invalid JSON sort: {e}", err=True)
                sys.exit(1)

        # Execute query
        response = client.query_burner_db(
            burner_id=burner_id,
            access_token=mom_token,
            database=database,
            collection=collection,
            operation=operation,
            filter=filter_dict,
            projection=projection_dict,
            sort=sort_dict,
            limit=limit,
            skip=skip,
        )

        # Output results
        if raw:
            click.echo(json_module.dumps(response))
        elif operation == "count":
            click.echo(f"Count: {response['results']}")
        else:
            results = response.get("results")
            if results is None:
                click.echo("No results found")
            elif isinstance(results, list):
                click.echo(f"Found {response['count']} document(s):")
                if response.get("truncated"):
                    click.echo(f"  (showing first {limit}, more available)")
                click.echo()
                for doc in results:
                    click.echo(json_module.dumps(doc, indent=2, default=str))
                    click.echo()
            else:
                click.echo(json_module.dumps(results, indent=2, default=str))

    except NotAuthenticatedError:
        click.echo("Error: Please run 'gravi login' first", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
@click.option("--type", "filter_type", type=click.Choice(["burner", "instance", "all"]), default="all", help="Filter by type")
def instances(output_json, filter_type):
    """List all instances and burners you have access to."""
    try:
        mom_token = get_mom_token()
        mom_url = get_mom_url()
        client = MomClient(mom_url)

        all_instances = []

        # Get MOM instances
        if filter_type in ("instance", "all"):
            response = client.list_my_instances(mom_token)
            for inst in response.get("instances", []):
                all_instances.append({
                    "key": inst["key"],
                    "name": inst["name"],
                    "type": inst["type"],
                    "status": "registered",
                    "url": inst.get("url", ""),
                })

        # Get burners
        if filter_type in ("burner", "all"):
            response = client.list_burners(mom_token)
            for b in response.get("burners", []):
                all_instances.append({
                    "key": b["burner_id"],
                    "name": b.get("custom_name") or b["burner_id"],
                    "type": "burner",
                    "status": b["status"],
                    "url": b.get("url", ""),
                })

        if output_json:
            click.echo(json.dumps({"instances": all_instances}))
        else:
            if not all_instances:
                click.echo("No instances found.")
                return

            click.echo("Instances")
            click.echo("=" * 80)
            click.echo(f"{'Key':<12} {'Name':<18} {'Type':<10} {'Status':<12} {'URL':<28}")
            click.echo("-" * 80)
            for inst in sorted(all_instances, key=lambda x: (x["type"], x["key"])):
                key = inst["key"][:12]
                name = inst["name"][:18]
                inst_type = inst["type"][:10]
                status = inst["status"][:12]
                url = inst["url"][:28] if inst["url"] else "-"
                click.echo(f"{key:<12} {name:<18} {inst_type:<10} {status:<12} {url:<28}")

            click.echo("=" * 80)
            click.echo(f"Total: {len(all_instances)} instance(s)")

    except NotAuthenticatedError:
        click.echo("Error: Please run 'gravi login' first", err=True)
        sys.exit(1)
    except APIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


# ============================================================================
# Burner Commands
# ============================================================================

@main.group()
def burner():
    """Manage ephemeral burner instances."""
    pass


def poll_operation_until_complete(
    client: MomClient,
    token: str,
    operation_id: str,
    show_progress: bool = True,
    poll_interval: float = 2.0,
    timeout: float = 600.0,
) -> dict:
    """
    Poll an operation until it completes or fails.

    Args:
        client: MomClient instance
        token: Access token
        operation_id: Operation ID to poll
        show_progress: Whether to print progress
        poll_interval: Seconds between polls
        timeout: Maximum time to wait

    Returns:
        Final operation status dict
    """
    start_time = time.time()
    last_step = None

    while True:
        if time.time() - start_time > timeout:
            return {"status": "failed", "error_message": "Timeout waiting for operation"}

        status = client.get_operation_status(operation_id, token)

        if show_progress:
            current_step = status.get("current_step")
            progress = status.get("progress_percent", 0)
            if current_step and current_step != last_step:
                click.echo(f"\n  {current_step}...", nl=False)
                last_step = current_step
            else:
                click.echo(".", nl=False)

        if status["status"] in ("completed", "failed"):
            if show_progress:
                click.echo()
            return status

        time.sleep(poll_interval)


@burner.command("start")
@click.option("--ttl", "ttl_hours", default=2, type=int, help="Time-to-live in hours (1-168)")
@click.option("--sheet-id", default=None, help="Google Sheet ID for full seeding ('default' for the shared default sheet)")
@click.option("--source-env", default=None, help="Source environment to copy from")
@click.option("--build", default="dev", help="Build to deploy (dev, test, rc, SHA, or branch name)")
@click.option("--simple-demand", is_flag=True, help="Use even demand distribution")
@click.option("--auto-sync", "auto_sync", is_flag=True, help="Enable image auto-sync after the burner is ready")
@click.option("--auto-sync-interval", type=click.IntRange(2, 5), default=3, show_default=True, help="Auto-sync check interval in minutes (2-5)")
@click.option("--sync", is_flag=True, help="Wait for burner to be ready")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def burner_start(ttl_hours, sheet_id, source_env, build, simple_demand, auto_sync, auto_sync_interval, sync, output_json):
    """Create a new burner instance.

    Examples:

        gravi burner start                      # Quick barebone burner

        gravi burner start --ttl 8              # 8 hour TTL

        gravi burner start --sync               # Wait until ready

        gravi burner start --sheet-id ABC123    # Full seed from sheet

        gravi burner start --build rc           # Deploy a specific build
    """
    try:
        mom_token = get_mom_token()
        mom_url = get_mom_url()
        client = MomClient(mom_url)

        # Determine seed level based on options
        seed_level = "barebone"
        if sheet_id:
            seed_level = "full"
        elif source_env:
            seed_level = "copy"

        # Initiate creation
        response = client.create_burner(
            access_token=mom_token,
            ttl_hours=ttl_hours,
            sheet_id=sheet_id,
            source_env=source_env,
            seed_level=seed_level,
            build=build,
            simple_demand=simple_demand,
            auto_sync_enabled=auto_sync,
            auto_sync_interval_minutes=auto_sync_interval,
        )

        burner_id = response["burner_id"]
        operation_id = response["operation_id"]

        if not sync:
            # Async mode: just output the operation info and exit
            if output_json:
                click.echo(json.dumps(response))
            else:
                click.echo(f"Burner '{burner_id}' creation started")
                click.echo(f"  Operation ID: {operation_id}")
                click.echo(f"\nUse 'gravi burner status {burner_id}' to check status")
            return

        # Sync mode: poll until complete
        if not output_json:
            click.echo(f"Creating burner '{burner_id}'", nl=False)

        final_result = poll_operation_until_complete(
            client, mom_token, operation_id,
            show_progress=(not output_json)
        )

        if final_result["status"] == "completed":
            # Fetch the burner details
            burner_info = client.get_burner(burner_id, mom_token)

            if output_json:
                click.echo(json.dumps(burner_info))
            else:
                click.echo(f"\nBurner ready:")
                click.echo(f"  ID:      {burner_info['burner_id']}")
                click.echo(f"  URL:     https://{burner_info['url']}")
                click.echo(f"  Expires: {burner_info['expires_at']}")
        else:
            error_msg = final_result.get("error_message", "Unknown error")
            if output_json:
                click.echo(json.dumps({"error": error_msg, "burner_id": burner_id}))
            else:
                click.echo(f"\nError: {error_msg}", err=True)
            sys.exit(1)

    except NotAuthenticatedError:
        click.echo("Error: Please run 'gravi login' first", err=True)
        sys.exit(1)
    except RateLimitError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except APIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@burner.command("delete")
@click.argument("burner_id")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def burner_delete(burner_id, output_json):
    """Delete a burner instance.

    Examples:

        gravi burner delete tank

        gravi burner delete pump --json
    """
    try:
        mom_token = get_mom_token()
        mom_url = get_mom_url()
        client = MomClient(mom_url)

        response = client.delete_burner(burner_id, mom_token)

        if output_json:
            click.echo(json.dumps(response))
        else:
            click.echo(f"Burner '{burner_id}' deletion initiated")
            click.echo(f"  Operation ID: {response['operation_id']}")

    except NotAuthenticatedError:
        click.echo("Error: Please run 'gravi login' first", err=True)
        sys.exit(1)
    except APIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@burner.command("list")
@click.option("--status", type=click.Choice(["ready", "creating", "failed", "expired"]), default=None, help="Filter by status")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def burner_list(status, output_json):
    """List all burner instances.

    Examples:

        gravi burner list

        gravi burner list --status ready

        gravi burner list --json
    """
    try:
        mom_token = get_mom_token()
        mom_url = get_mom_url()
        client = MomClient(mom_url)

        response = client.list_burners(mom_token, status=status)

        if output_json:
            click.echo(json.dumps(response))
        else:
            burners = response.get("burners", [])
            total = response.get("total", len(burners))

            if not burners:
                click.echo("No burners found.")
                return

            click.echo("Burner Instances")
            click.echo("=" * 90)
            click.echo(f"{'ID':<12} {'Name':<15} {'Status':<10} {'URL':<35} {'Expires':<20}")
            click.echo("-" * 90)

            for b in burners:
                burner_id = b.get("burner_id", "")
                name = b.get("custom_name") or "-"
                status_val = b.get("status", "")
                url = b.get("url", "")
                expires = b.get("expires_at", "")[:16] if b.get("expires_at") else ""
                click.echo(f"{burner_id:<12} {name:<15} {status_val:<10} {url:<35} {expires:<20}")

            click.echo("=" * 90)
            click.echo(f"Total: {total} burner(s)")

    except NotAuthenticatedError:
        click.echo("Error: Please run 'gravi login' first", err=True)
        sys.exit(1)
    except APIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@burner.command("status")
@click.argument("burner_id")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def burner_status(burner_id, output_json):
    """Get detailed status of a burner.

    Examples:

        gravi burner status tank

        gravi burner status pump --json
    """
    try:
        mom_token = get_mom_token()
        mom_url = get_mom_url()
        client = MomClient(mom_url)

        burner_info = client.get_burner(burner_id, mom_token)

        if output_json:
            click.echo(json.dumps(burner_info))
        else:
            click.echo(f"Burner: {burner_info['burner_id']}")
            click.echo("=" * 40)
            click.echo(f"Status:     {burner_info['status']}")
            click.echo(f"URL:        https://{burner_info['url']}")
            click.echo(f"Created by: {burner_info['created_by']}")
            click.echo(f"Created:    {burner_info['created_at']}")
            click.echo(f"Expires:    {burner_info['expires_at']}")
            click.echo(f"TTL:        {burner_info['ttl_hours']} hours")
            click.echo(f"Build:      {burner_info['build']}")
            click.echo(f"Seed level: {burner_info['seed_level']}")
            if burner_info.get('custom_name'):
                click.echo(f"Name:       {burner_info['custom_name']}")
            if burner_info.get('sheet_id'):
                click.echo(f"Sheet ID:   {burner_info['sheet_id']}")

    except NotAuthenticatedError:
        click.echo("Error: Please run 'gravi login' first", err=True)
        sys.exit(1)
    except APIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@burner.command("pods")
@click.argument("burner_id")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def burner_pods(burner_id, output_json):
    """List pods in a burner instance.

    Shows all pods grouped by deployment with their status.

    Examples:

        gravi burner pods tank

        gravi burner pods pump --json
    """
    try:
        mom_token = get_mom_token()
        mom_url = get_mom_url()
        client = MomClient(mom_url)

        data = client.list_burner_pods(burner_id, mom_token)

        if output_json:
            click.echo(json.dumps(data))
        else:
            click.echo(f"Pods in burner '{burner_id}' ({data['namespace']})")
            click.echo("=" * 60)

            for deployment in data.get("deployments", []):
                ready = deployment["ready_replicas"]
                desired = deployment["desired_replicas"]
                status_icon = "✓" if ready == desired else "○"
                click.echo(f"\n{status_icon} {deployment['name']} ({ready}/{desired} ready)")

                for pod in deployment.get("pods", []):
                    pod_status = pod.get("status", "Unknown")
                    restarts = pod.get("restart_count", 0)
                    restart_str = f" (restarts: {restarts})" if restarts > 0 else ""
                    status_color = "green" if pod_status == "Running" else "yellow"
                    click.echo(f"    {pod['name']}: {pod_status}{restart_str}")

    except NotAuthenticatedError:
        click.echo("Error: Please run 'gravi login' first", err=True)
        sys.exit(1)
    except APIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@burner.command("logs")
@click.argument("burner_id")
@click.argument("pod_name")
@click.option("--tail", "-n", "tail_lines", default=100, type=int, help="Number of lines (default: 100)")
@click.option("--container", "-c", default=None, help="Container name (optional)")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def burner_logs(burner_id, pod_name, tail_lines, container, output_json):
    """Fetch logs from a pod in a burner.

    Examples:

        gravi burner logs tank backend-xyz

        gravi burner logs tank backend-xyz --tail 500

        gravi burner logs tank backend-xyz -c backend
    """
    try:
        mom_token = get_mom_token()
        mom_url = get_mom_url()
        client = MomClient(mom_url)

        data = client.get_pod_logs(
            burner_id=burner_id,
            pod_name=pod_name,
            access_token=mom_token,
            container=container,
            tail_lines=tail_lines,
        )

        if output_json:
            click.echo(json.dumps(data))
        else:
            if data.get("truncated"):
                click.echo(f"[Showing last {tail_lines} lines, logs truncated]", err=True)
            # API returns 'lines' as array or 'logs' as string
            logs = data.get("logs") or "\n".join(data.get("lines", []))
            click.echo(logs)

    except NotAuthenticatedError:
        click.echo("Error: Please run 'gravi login' first", err=True)
        sys.exit(1)
    except APIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@burner.command("restart")
@click.argument("burner_id")
@click.argument("deployment_name")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def burner_restart(burner_id, deployment_name, output_json):
    """Restart a deployment in a burner.

    Triggers a rolling restart of all pods in the deployment.

    Examples:

        gravi burner restart tank backend

        gravi burner restart pump forecast
    """
    try:
        mom_token = get_mom_token()
        mom_url = get_mom_url()
        client = MomClient(mom_url)

        response = client.restart_deployment(burner_id, deployment_name, mom_token)

        if output_json:
            click.echo(json.dumps(response))
        else:
            click.echo(f"Restart initiated for '{deployment_name}' in burner '{burner_id}'")

    except NotAuthenticatedError:
        click.echo("Error: Please run 'gravi login' first", err=True)
        sys.exit(1)
    except APIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@burner.group("autosync")
def burner_autosync():
    """Manage image auto-sync for a burner.

    When enabled, the burner periodically checks for stale images and
    restarts deployments whose tag has been rebuilt since.
    """
    pass


def _print_autosync_status(status: dict, output_json: bool):
    if output_json:
        click.echo(json.dumps(status, default=str))
        return
    click.echo(f"Burner:           {status['burner_id']}")
    click.echo(f"Enabled:          {status['enabled']}")
    click.echo(f"Interval:         {status['interval_minutes']} min")
    click.echo(f"Last run:         {status.get('last_run_at') or 'Never'}")
    click.echo(f"Last result:      {status.get('last_result') or 'N/A'}")
    click.echo(f"Last updated:     {status.get('last_updated_count', 0)} deployment(s)")
    click.echo(f"In progress:      {status.get('in_progress', False)}")


@burner_autosync.command("status")
@click.argument("burner_id")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def burner_autosync_status(burner_id, output_json):
    """Show auto-sync status for BURNER_ID."""
    try:
        client = MomClient(get_mom_url())
        status = client.get_auto_sync_status(burner_id, get_mom_token())
        _print_autosync_status(status, output_json)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@burner_autosync.command("enable")
@click.argument("burner_id")
@click.option("--interval", type=click.IntRange(2, 5), default=3, show_default=True, help="Check interval in minutes (2-5)")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def burner_autosync_enable(burner_id, interval, output_json):
    """Enable auto-sync on BURNER_ID."""
    try:
        client = MomClient(get_mom_url())
        status = client.update_auto_sync_config(burner_id, True, interval, get_mom_token())
        if not output_json:
            click.echo(f"✓ Auto-sync enabled on '{burner_id}' (interval: {interval} min)")
        _print_autosync_status(status, output_json)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@burner_autosync.command("disable")
@click.argument("burner_id")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def burner_autosync_disable(burner_id, output_json):
    """Disable auto-sync on BURNER_ID."""
    try:
        client = MomClient(get_mom_url())
        # Backend requires interval even when disabling — preserve current.
        current = client.get_auto_sync_status(burner_id, get_mom_token())
        status = client.update_auto_sync_config(
            burner_id, False, current.get("interval_minutes", 3), get_mom_token()
        )
        if not output_json:
            click.echo(f"✓ Auto-sync disabled on '{burner_id}'")
        _print_autosync_status(status, output_json)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@burner_autosync.command("trigger")
@click.argument("burner_id")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def burner_autosync_trigger(burner_id, output_json):
    """Run an auto-sync check on BURNER_ID immediately."""
    try:
        client = MomClient(get_mom_url())
        result = client.trigger_auto_sync(burner_id, get_mom_token())
        if output_json:
            click.echo(json.dumps(result, default=str))
        else:
            click.echo(f"✓ Auto-sync triggered for '{burner_id}'")
            if isinstance(result, dict):
                for k, v in result.items():
                    click.echo(f"  {k}: {v}")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@burner.command("recreate")
@click.argument("burner_id")
@click.option("--sync", is_flag=True, help="Wait for burner to be ready")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def burner_recreate(burner_id, sync, output_json):
    """Recreate a burner with the same settings but latest builds.

    Destroys the existing burner and recreates it in the same namespace
    with identical settings (TTL, seed level, source env, etc.) but fresh
    infrastructure and the latest container images.

    Use this when:
    - Database is corrupted and you want to start fresh
    - You want the latest builds without changing settings
    - Something went wrong and you need a clean slate

    Examples:

        gravi burner recreate tank

        gravi burner recreate pump --sync
    """
    try:
        mom_token = get_mom_token()
        mom_url = get_mom_url()
        client = MomClient(mom_url)

        # Initiate recreation
        response = client.recreate_burner(burner_id, mom_token)

        operation_id = response["operation_id"]

        if not sync:
            # Async mode: just output the operation info and exit
            if output_json:
                click.echo(json.dumps(response))
            else:
                click.echo(f"Burner '{burner_id}' recreation started")
                click.echo(f"  Operation ID: {operation_id}")
                click.echo(f"\nUse 'gravi burner status {burner_id}' to check status")
            return

        # Sync mode: poll until complete
        if not output_json:
            click.echo(f"Recreating burner '{burner_id}'", nl=False)

        final_result = poll_operation_until_complete(
            client, mom_token, operation_id,
            show_progress=(not output_json)
        )

        if final_result["status"] == "completed":
            # Fetch the burner details
            burner_info = client.get_burner(burner_id, mom_token)

            if output_json:
                click.echo(json.dumps(burner_info))
            else:
                click.echo(f"\nBurner recreated:")
                click.echo(f"  ID:      {burner_info['burner_id']}")
                click.echo(f"  URL:     https://{burner_info['url']}")
                click.echo(f"  Expires: {burner_info['expires_at']}")
        else:
            error_msg = final_result.get("error_message", "Unknown error")
            if output_json:
                click.echo(json.dumps({"error": error_msg, "burner_id": burner_id}))
            else:
                click.echo(f"\nError: {error_msg}", err=True)
            sys.exit(1)

    except NotAuthenticatedError:
        click.echo("Error: Please run 'gravi login' first", err=True)
        sys.exit(1)
    except RateLimitError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except APIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@burner.command("duplicate")
@click.argument("burner_id")
@click.option("--ttl", "ttl_hours", default=None, type=int, help="Override TTL in hours (1-168)")
@click.option("--name", "custom_name", default=None, help="Custom name for the new burner")
@click.option("--sync", is_flag=True, help="Wait for burner to be ready")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def burner_duplicate(burner_id, ttl_hours, custom_name, sync, output_json):
    """Duplicate a burner to a new namespace with the same settings.

    Creates a new burner instance with identical settings (seed level, source
    env, sheet ID, etc.) from the source burner. The new burner gets a fresh
    name from the pool and starts with a fresh TTL.

    Use this when:
    - You want another instance with the same configuration
    - You need to test something in parallel
    - You want to preserve the original while experimenting

    Examples:

        gravi burner duplicate tank

        gravi burner duplicate pump --ttl 8

        gravi burner duplicate tank --sync
    """
    try:
        mom_token = get_mom_token()
        mom_url = get_mom_url()
        client = MomClient(mom_url)

        # Initiate duplication
        response = client.duplicate_burner(
            burner_id=burner_id,
            access_token=mom_token,
            ttl_hours=ttl_hours,
            custom_name=custom_name,
        )

        new_burner_id = response["new_burner_id"]
        operation_id = response["operation_id"]

        if not sync:
            # Async mode: just output the operation info and exit
            if output_json:
                click.echo(json.dumps(response))
            else:
                click.echo(f"Burner '{burner_id}' duplication started")
                click.echo(f"  New burner ID: {new_burner_id}")
                click.echo(f"  Operation ID:  {operation_id}")
                click.echo(f"\nUse 'gravi burner status {new_burner_id}' to check status")
            return

        # Sync mode: poll until complete
        if not output_json:
            click.echo(f"Duplicating burner '{burner_id}' to '{new_burner_id}'", nl=False)

        final_result = poll_operation_until_complete(
            client, mom_token, operation_id,
            show_progress=(not output_json)
        )

        if final_result["status"] == "completed":
            # Fetch the new burner details
            burner_info = client.get_burner(new_burner_id, mom_token)

            if output_json:
                click.echo(json.dumps(burner_info))
            else:
                click.echo(f"\nBurner duplicated:")
                click.echo(f"  ID:      {burner_info['burner_id']}")
                click.echo(f"  URL:     https://{burner_info['url']}")
                click.echo(f"  Expires: {burner_info['expires_at']}")
        else:
            error_msg = final_result.get("error_message", "Unknown error")
            if output_json:
                click.echo(json.dumps({"error": error_msg, "new_burner_id": new_burner_id}))
            else:
                click.echo(f"\nError: {error_msg}", err=True)
            sys.exit(1)

    except NotAuthenticatedError:
        click.echo("Error: Please run 'gravi login' first", err=True)
        sys.exit(1)
    except RateLimitError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except APIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


# ============================================================================
# MongoDB Whitelist Commands
# ============================================================================

def get_public_ip() -> str:
    """Get public IP address using ipify.org."""
    import requests as req
    try:
        response = req.get("https://api.ipify.org?format=json", timeout=5)
        response.raise_for_status()
        return response.json()["ip"]
    except Exception as e:
        raise APIError(f"Failed to detect public IP: {e}")


@main.group()
def mongo():
    """Manage MongoDB Atlas access."""
    pass


# ============================================================================
# ArgoCD Watch Commands
# ============================================================================


@main.command()
@click.argument("app_name", required=False)
@click.option("--all", "persistent", is_flag=True, help="Notify on every sync (persistent)")
@click.option("--cancel", is_flag=True, help="Cancel watch for the app")
@click.option("--list", "list_watches", is_flag=True, help="List active watches")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def watch(app_name, persistent, cancel, list_watches, output_json):
    """Watch ArgoCD app and get Slack DM on sync.

    Subscribe to sync notifications for an ArgoCD application.
    By default, creates a one-shot watch that notifies on the next sync.

    Examples:

        gravi watch mom              # One-shot: notify on next sync

        gravi watch mom --all        # Persistent: notify on every sync

        gravi watch mom --cancel     # Cancel watch for the app

        gravi watch --list           # List all active watches
    """
    try:
        mom_token = get_mom_token()
        mom_url = get_mom_url()
        client = MomClient(mom_url)

        if list_watches:
            # List all active watches
            response = client.list_argocd_watches(mom_token)

            if output_json:
                click.echo(json.dumps(response))
            else:
                subs = response.get("subscriptions", [])
                if not subs:
                    click.echo("No active watches.")
                    return

                click.echo("Active ArgoCD Watches")
                click.echo("=" * 70)
                click.echo(f"{'App':<20} {'Mode':<12} {'Expires':<24} {'Notified':<10}")
                click.echo("-" * 70)

                for sub in subs:
                    app = sub["app_name"][:20]
                    mode = "persistent" if sub["persistent"] else "one-shot"
                    expires = sub["expires_at"][:19].replace("T", " ")
                    notified = "yes" if sub["notified"] else "no"
                    click.echo(f"{app:<20} {mode:<12} {expires:<24} {notified:<10}")

                click.echo("=" * 70)
                click.echo(f"Total: {response['total']} watch(es)")

        elif cancel:
            if not app_name:
                click.echo("Error: Specify an app name to cancel watch", err=True)
                click.echo("Usage: gravi watch <app_name> --cancel")
                sys.exit(1)

            response = client.cancel_argocd_watch(mom_token, app_name)

            if output_json:
                click.echo(json.dumps(response))
            else:
                click.echo(f"Cancelled watch for '{app_name}'")

        else:
            if not app_name:
                click.echo("Error: Specify an app name to watch", err=True)
                click.echo("Usage: gravi watch <app_name>")
                click.echo("       gravi watch --list")
                sys.exit(1)

            response = client.create_argocd_watch(mom_token, app_name, persistent)

            if output_json:
                click.echo(json.dumps(response))
            else:
                mode = "persistent" if persistent else "one-shot"
                click.echo(f"Watching '{app_name}' ({mode})")
                if not persistent:
                    click.echo("  You will be notified via Slack DM on the next sync.")
                else:
                    click.echo("  You will be notified via Slack DM on every sync.")
                click.echo(f"  Expires: {response['expires_at'][:19].replace('T', ' ')}")
                click.echo(f"\nUse 'gravi watch {app_name} --cancel' to stop watching.")

    except NotAuthenticatedError:
        click.echo("Error: Please run 'gravi login' first", err=True)
        sys.exit(1)
    except APIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@mongo.command("whitelist")
@click.option("--add", "action", flag_value="add", help="Add your IP to whitelist")
@click.option("--remove", "remove_ip", default=None, help="Remove an IP from whitelist")
@click.option("--list", "action", flag_value="list", help="List whitelisted IPs")
@click.option("--ip", default=None, help="Specify IP address (for --add)")
@click.option("--comment", "-c", default="", help="Comment for the whitelist entry")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def mongo_whitelist(action, remove_ip, ip, comment, output_json):
    """Manage MongoDB Atlas IP whitelist.

    Allows you to whitelist your IP address to access the development
    MongoDB cluster. IPs are automatically removed after 4 hours.

    Examples:

        gravi mongo whitelist              # Show current IP status

        gravi mongo whitelist --add        # Add your current IP

        gravi mongo whitelist --add --ip 1.2.3.4  # Add specific IP

        gravi mongo whitelist --list       # Show your whitelisted IPs

        gravi mongo whitelist --remove 1.2.3.4    # Remove an IP
    """
    try:
        mom_token = get_mom_token()
        mom_url = get_mom_url()
        client = MomClient(mom_url)

        if remove_ip:
            response = client.remove_whitelisted_ip(mom_token, remove_ip)
            if output_json:
                click.echo(json.dumps(response))
            else:
                click.echo(f"Removed IP {remove_ip} from whitelist")

        elif action == "add":
            if not ip:
                ip = get_public_ip()
                check_response = client.check_ip_whitelisted(mom_token, ip)
                if check_response.get("is_already_whitelisted"):
                    click.echo(f"IP {ip} is already whitelisted")
                    return

            response = client.add_ip_to_whitelist(mom_token, ip, comment)
            if output_json:
                click.echo(json.dumps(response))
            elif response.get("requires_approval"):
                click.echo(f"IP {response['ip_address']} requires admin approval")
                if response.get("country_name"):
                    click.echo(f"  Country: {response['country_name']} ({response.get('country_code', '')})")
                click.echo(f"  {response.get('message', 'Request submitted for review')}")
            else:
                click.echo(f"Added IP {response['ip_address']} to whitelist")
                if response.get("expires_at"):
                    click.echo(f"  Expires: {response['expires_at']}")

        elif action == "list":
            response = client.list_whitelisted_ips(mom_token)
            if output_json:
                click.echo(json.dumps(response))
            else:
                ips = response.get("ips", [])
                if not ips:
                    click.echo("No whitelisted IPs found.")
                    return

                click.echo("Whitelisted IPs")
                click.echo("=" * 70)
                click.echo(f"{'IP Address':<18} {'Expires':<24} {'Comment':<26}")
                click.echo("-" * 70)
                for entry in ips:
                    ip_addr = entry["ip_address"]
                    expires = entry["expires_at"][:19].replace("T", " ")
                    entry_comment = entry.get("comment", "")[:26]
                    click.echo(f"{ip_addr:<18} {expires:<24} {entry_comment:<26}")

        else:
            ip = get_public_ip()
            response = client.check_ip_whitelisted(mom_token, ip)
            if output_json:
                click.echo(json.dumps(response))
            else:
                click.echo(f"Your IP: {response['ip_address']}")
                if response.get("is_already_whitelisted"):
                    click.echo("Status: Whitelisted")
                else:
                    click.echo("Status: Not whitelisted")
                    click.echo("\nRun 'gravi mongo whitelist --add' to whitelist your IP")

    except NotAuthenticatedError:
        click.echo("Error: Please run 'gravi login' first", err=True)
        sys.exit(1)
    except APIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
