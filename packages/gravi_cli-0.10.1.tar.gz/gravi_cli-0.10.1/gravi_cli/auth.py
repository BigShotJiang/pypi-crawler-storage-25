"""
Authentication and token management for gravi CLI.

Handles token refresh, auto-renewal, and provides the main API
for accessing mom and instance credentials.
"""

import os
import socket
import time
import webbrowser
from datetime import datetime, timedelta, UTC

from .client import MomClient
from .config import Config, load_config, save_config, delete_config, config_exists
from .exceptions import NotAuthenticatedError, InvalidTokenError, APIError

# In-process caches. Access tokens and instance config responses are reused
# for the remainder of this process to avoid per-call round trips to mom.
_MOM_TOKEN_CACHE: dict = {}               # {"access_token": str, "expires_at": datetime}
_INSTANCE_CONFIG_CACHE: dict = {}         # {instance_key: (expires_at, config_dict)}
_INSTANCE_TOKEN_CACHE: dict = {}          # {(instance_key, admin_requested): (expires_at, token_dict)}
_MOM_TOKEN_REFRESH_SKEW = timedelta(seconds=60)   # refresh this early before expiry
_INSTANCE_CACHE_TTL = timedelta(minutes=5)        # config/token TTL


def clear_token_cache() -> None:
    """Drop all in-process auth caches. Next call hits mom fresh."""
    _MOM_TOKEN_CACHE.clear()
    _INSTANCE_CONFIG_CACHE.clear()
    _INSTANCE_TOKEN_CACHE.clear()


def get_mom_url() -> str:
    """
    Get mom URL from environment or use default.

    Returns:
        Mom API base URL

    Priority:
        1. GRAVI_MOM_URL environment variable
        2. Default: https://mom.gravitate.energy/api
    """
    return os.getenv("GRAVI_MOM_URL", "https://mom.gravitate.energy/api")


def ensure_logged_in() -> None:
    """
    Ensure the user is logged in, triggering the login flow if not.

    This function checks if the user has valid authentication credentials.
    If not authenticated or if the refresh token is invalid/expired, it
    automatically initiates the device authorization flow and opens a browser
    for the user to authorize.

    Raises:
        Exception: If the login flow fails or is cancelled
    """
    # Check if already logged in with valid credentials
    if config_exists():
        try:
            config = load_config()
            # Try to get a token to verify it's still valid
            mom_url = get_mom_url()
            client = MomClient(mom_url)
            try:
                client.refresh_token(config.refresh_token)
                # Token is valid, user is logged in
                return
            except (InvalidTokenError, APIError):
                # Token expired or invalid, need to re-authenticate
                print(f"Your authentication has expired. Logging in again...")
                delete_config()
        except Exception:
            # Config corrupted, proceed with login
            pass

    # Not logged in or token expired - initiate login flow
    print("Gravi CLI requires authentication.")
    print("Opening browser for login...")

    mom_url = get_mom_url()
    client = MomClient(mom_url)

    # Get device name
    try:
        device_name = socket.gethostname()
        if not device_name or device_name == "localhost":
            device_name = "unknown-device"
    except Exception:
        device_name = "unknown-device"

    # Initiate device authorization
    try:
        device_auth = client.initiate_device_auth(device_name=device_name)
    except APIError as e:
        raise Exception(f"Failed to initiate login: {e}")

    # Display instructions
    print("\n" + "=" * 60)
    print("Please authorize this CLI tool:")
    print(f"  1. Opening browser to: {device_auth['verification_uri_complete']}")
    print(f"  2. Or manually visit: {device_auth['verification_uri']}")
    print(f"     and enter code: {device_auth['user_code']}")
    print("=" * 60 + "\n")

    # Open browser automatically
    try:
        webbrowser.open(device_auth["verification_uri_complete"])
    except Exception:
        print("Could not open browser automatically. Please visit the URL manually.")

    # Poll for authorization
    device_code = device_auth["device_code"]
    interval = device_auth["interval"]
    expires_in = device_auth["expires_in"]

    print("Waiting for authorization...", end="", flush=True)

    start_time = time.time()
    while time.time() - start_time < expires_in:
        time.sleep(interval)

        try:
            result = client.poll_device_auth(device_code)
        except APIError as e:
            if "expired" in str(e).lower():
                print(" ✗")
                raise Exception("Authorization timed out. Please try again.")
            # Continue polling on other errors
            print(".", end="", flush=True)
            continue

        if result.get("error"):
            if result["error"] == "expired_token":
                print(" ✗")
                raise Exception("Authorization timed out. Please try again.")
            # Continue polling for other errors
            print(".", end="", flush=True)
            continue

        if result.get("authorized"):
            print(" ✓")

            # Extract credentials from response
            user_email = result["user_email"]
            token_id = result["token_id"]
            refresh_token = result["refresh_token"]
            refresh_expires_in = result["refresh_expires_in"]
            device_name = result["device_name"]

            # Save config
            config = Config(
                user_email=user_email,
                refresh_token=refresh_token,
                refresh_token_expires_at=datetime.now(UTC) + timedelta(seconds=refresh_expires_in),
                token_id=token_id,
                device_name=device_name,
            )
            save_config(config)

            print(f"\n✓ Successfully logged in as {user_email}")
            print(f"  Device: {device_name}")
            return

        print(".", end="", flush=True)

    # Timed out
    print(" ✗")
    raise Exception("Authorization timed out. Please try again.")


def get_mom_token() -> str:
    """
    Get valid Mom access token, refreshing if necessary.

    This function:
    1. Checks for GRAVI_REFRESH_TOKEN environment variable (CI/CD usage)
    2. Falls back to config file refresh token
    3. Refreshes the access token using the refresh token
    4. Auto-renews refresh token if <7 days remaining (saves to config)
    5. Returns fresh access token (in-memory only, not persisted)

    Returns:
        Valid mom access token

    Raises:
        NotAuthenticatedError: If not logged in or token expired
        InvalidTokenError: If refresh token is invalid or revoked
    """
    # Serve from in-process cache if token is still comfortably valid
    cached_expiry = _MOM_TOKEN_CACHE.get("expires_at")
    if cached_expiry and datetime.now(UTC) + _MOM_TOKEN_REFRESH_SKEW < cached_expiry:
        return _MOM_TOKEN_CACHE["access_token"]

    # Check for CI/CD environment variable first
    refresh_token = os.getenv("GRAVI_REFRESH_TOKEN")

    # Fall back to config file if not in CI/CD
    if not refresh_token:
        if not config_exists():
            raise NotAuthenticatedError("Please run 'gravi login' first")

        config = load_config()
        refresh_token = config.refresh_token
    else:
        # CI/CD mode - load config if it exists (for potential auto-renewal)
        config = None
        if config_exists():
            config = load_config()

    if not refresh_token:
        raise NotAuthenticatedError("Please run 'gravi login' first")

    # Always get fresh access token from refresh token
    mom_url = get_mom_url()
    client = MomClient(mom_url)

    try:
        response = client.refresh_token(refresh_token)
    except InvalidTokenError:
        raise NotAuthenticatedError("Refresh token expired or revoked. Please run 'gravi login' again")

    # Check if refresh token was renewed (auto-renewal if <7 days remaining)
    if "refresh_token" in response and config:
        config.refresh_token = response["refresh_token"]
        config.refresh_token_expires_at = datetime.now(UTC) + timedelta(seconds=response["refresh_expires_in"])
        save_config(config)

    # Cache access token in-memory (not persisted) until shortly before its expiry
    access_token = response["access_token"]
    expires_in = response.get("expires_in", 3600)
    _MOM_TOKEN_CACHE["access_token"] = access_token
    _MOM_TOKEN_CACHE["expires_at"] = datetime.now(UTC) + timedelta(seconds=expires_in)
    return access_token


def get_instance_config(instance_key: str) -> dict:
    """
    Get instance credentials and connection information.

    Args:
        instance_key: Instance identifier (e.g., "dev", "prod")

    Returns:
        Instance credentials dictionary:
        {
            "type": "dev",
            "short_name": "dev",
            "dbs": {
                "backend": "dev_backend",
                "price": "dev_price",
                ...
            },
            "conn_str": "mongodb+srv://...",
            "url": "https://dev.bb.gravitate.energy",
            "auth_server": "https://dev.bb.gravitate.energy/service/auth",
            "system_psk": "...",
            ...
        }

    Raises:
        NotAuthenticatedError: If not logged in or token expired
        InvalidTokenError: If token is invalid or revoked
        APIError: If API request fails
    """
    cached = _INSTANCE_CONFIG_CACHE.get(instance_key)
    if cached and datetime.now(UTC) < cached[0]:
        return cached[1]

    mom_url = get_mom_url()
    mom_token = get_mom_token()
    client = MomClient(mom_url)
    config = client.get_instance_credentials(instance_key, mom_token)
    _INSTANCE_CONFIG_CACHE[instance_key] = (
        datetime.now(UTC) + _INSTANCE_CACHE_TTL,
        config,
    )
    return config


def list_instances(env: str | None = None) -> list[dict]:
    """
    List instances the authenticated user has access to.

    Args:
        env: Optional filter — "dev" or "prod". If None, returns all.

    Returns:
        List of instance dicts with at least "key", "name", "type", "url".

    Raises:
        NotAuthenticatedError: If not logged in or token expired
        APIError: If API request fails
    """
    mom_url = get_mom_url()
    mom_token = get_mom_token()
    client = MomClient(mom_url)
    response = client.list_my_instances(mom_token)
    instances = response.get("instances", [])
    if env:
        instances = [i for i in instances if i.get("type") == env]
    return instances


def get_instance_token(instance_key: str, admin_requested: bool = False) -> dict:
    """
    Get instance access token/credentials.

    Args:
        instance_key: Instance identifier (e.g., "dev", "prod")
        admin_requested: If True, ask the target for an admin token instead
            of a user token. Only honored when the caller has admin access
            on the target — otherwise the target falls back to a user token
            (or rejects, depending on its policy).

    Returns:
        Instance-specific credentials (format varies by instance type)
        Examples:
        - ServiceNow OAuth: {"access_token": "...", "token_type": "Bearer", "expires_in": 3600}
        - API Key based: {"api_key": "...", "environment": "production"}
        - Custom format: Any JSON structure the instance provides

    Raises:
        NotAuthenticatedError: If not logged in or token expired
        InvalidTokenError: If token is invalid or revoked
        APIError: If API request fails
    """
    # Cache key includes admin_requested so admin and user tokens don't alias.
    cache_key = (instance_key, admin_requested)
    cached = _INSTANCE_TOKEN_CACHE.get(cache_key)
    if cached and datetime.now(UTC) < cached[0]:
        return cached[1]

    mom_url = get_mom_url()
    mom_token = get_mom_token()
    client = MomClient(mom_url)
    token = client.get_instance_token(instance_key, mom_token, admin_requested=admin_requested)

    ttl = _INSTANCE_CACHE_TTL
    if isinstance(token, dict) and isinstance(token.get("expires_in"), (int, float)):
        ttl = min(ttl, timedelta(seconds=max(0, token["expires_in"] - 60)))
    _INSTANCE_TOKEN_CACHE[cache_key] = (datetime.now(UTC) + ttl, token)
    return token


# ---------------------------------------------------------------------------
# User secrets (encrypted in mom)
# ---------------------------------------------------------------------------
# bbd-client imports these in-process to look up the user's stored creds.
# Keeping the mom URL / auth knowledge inside gravi-cli means bbd-client
# never has to learn how to talk to mom directly.

def get_atlas_credentials(tier: str) -> dict | None:
    """Fetch the authenticated user's atlas credentials from mom.

    Returns {"username": ..., "password": ..., "tier": ..., "updated_at": ...}
    on success. Returns None if no credentials are stored for this tier
    (404). Raises NotAuthenticatedError if not logged in to mom.

    Other failures (network, 5xx) propagate as APIError so the caller can
    decide whether to fall through to other credential sources.
    """
    from .exceptions import APIError
    mom_url = get_mom_url()
    mom_token = get_mom_token()
    client = MomClient(mom_url)
    try:
        return client.get_atlas_credentials(mom_token, tier)
    except APIError as e:
        # Treat "not stored" as a soft miss; everything else surfaces.
        if "404" in str(e) or "not found" in str(e).lower():
            return None
        raise


def set_atlas_credentials(tier: str, username: str, password: str) -> dict:
    """Store atlas creds in mom for the authenticated user. Returns the echo."""
    mom_url = get_mom_url()
    mom_token = get_mom_token()
    client = MomClient(mom_url)
    return client.set_atlas_credentials(mom_token, tier, username, password)


def delete_atlas_credentials(tier: str) -> dict:
    mom_url = get_mom_url()
    mom_token = get_mom_token()
    client = MomClient(mom_url)
    return client.delete_atlas_credentials(mom_token, tier)


def list_my_secrets() -> dict:
    mom_url = get_mom_url()
    mom_token = get_mom_token()
    client = MomClient(mom_url)
    return client.list_my_secrets(mom_token)
