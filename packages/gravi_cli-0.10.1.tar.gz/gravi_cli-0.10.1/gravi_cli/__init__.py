"""
Gravi CLI - Command-line tool for Gravitate infrastructure management.

This package provides CLI access to Gravitate's mom infrastructure,
allowing developers to authenticate, manage tokens, and access instance
configurations and credentials.

Query API (programmatic access to burner databases):
    from gravi_cli.query import query_burner, query_burner_full

    results = query_burner("tank", "backend", "orders", limit=10)
"""

__version__ = "0.10.1"

# Expose query functions for easy programmatic access
from gravi_cli.query import query_burner, query_burner_full

__all__ = ["query_burner", "query_burner_full", "__version__"]
