"""
Programmatic interface for querying burner MongoDB databases.

This module provides a simple function interface for executing queries
against burner databases without needing to manage database tunnels.

Usage:
    from gravi_cli.query import query_burner

    # Simple find
    results = query_burner("tank", "backend", "orders", limit=10)

    # With filter
    results = query_burner(
        "tank", "backend", "orders",
        filter={"status": "delivered"},
        sort={"created_at": -1},
        limit=50
    )

    # Count documents
    count = query_burner(
        "tank", "backend", "orders",
        operation="count",
        filter={"status": "pending"}
    )

    # Find one
    user = query_burner(
        "tank", "backend", "users",
        operation="find_one",
        filter={"email": "admin@test.com"}
    )
"""

from typing import Any

from .auth import get_mom_token, get_mom_url
from .client import MomClient
from .exceptions import NotAuthenticatedError


def query_burner(
    burner_id: str,
    database: str,
    collection: str,
    operation: str = "find",
    filter: dict | None = None,
    projection: dict | None = None,
    pipeline: list[dict] | None = None,
    sort: dict | None = None,
    limit: int = 100,
    skip: int = 0,
) -> dict | list | int | None:
    """
    Query a burner's MongoDB database without needing a tunnel.

    This is a convenience function that handles authentication and
    client setup automatically.

    Args:
        burner_id: Burner ID (e.g., 'tank', 'pump')
        database: Database name (e.g., 'backend', 'pricing', 'forecast')
        collection: Collection name
        operation: Query operation ('find', 'find_one', 'count', 'aggregate')
        filter: Query filter (for find/find_one/count)
        projection: Fields to include/exclude
        pipeline: Aggregation pipeline (for aggregate)
        sort: Sort specification (e.g., {'created_at': -1})
        limit: Max documents to return (default 100, max 1000)
        skip: Documents to skip (default 0)

    Returns:
        For 'find': list of documents
        For 'find_one': single document dict or None
        For 'count': integer count
        For 'aggregate': list of documents

    Raises:
        NotAuthenticatedError: If not logged in (run 'gravi login')
        Exception: For API errors

    Examples:
        >>> results = query_burner("tank", "backend", "orders", limit=5)
        >>> print(f"Found {len(results)} orders")

        >>> count = query_burner("tank", "backend", "orders", operation="count")
        >>> print(f"Total orders: {count}")
    """
    mom_token = get_mom_token()
    mom_url = get_mom_url()
    client = MomClient(mom_url)

    response = client.query_burner_db(
        burner_id=burner_id,
        access_token=mom_token,
        database=database,
        collection=collection,
        operation=operation,
        filter=filter,
        projection=projection,
        pipeline=pipeline,
        sort=sort,
        limit=limit,
        skip=skip,
    )

    return response.get("results")


def query_burner_full(
    burner_id: str,
    database: str,
    collection: str,
    **kwargs,
) -> dict:
    """
    Query a burner's MongoDB database and return full response metadata.

    Same as query_burner() but returns the full response including
    count and truncated flags.

    Returns:
        {
            "burner_id": "tank",
            "database": "backend",
            "collection": "orders",
            "operation": "find",
            "results": [...],
            "count": 10,
            "truncated": false
        }
    """
    mom_token = get_mom_token()
    mom_url = get_mom_url()
    client = MomClient(mom_url)

    return client.query_burner_db(
        burner_id=burner_id,
        access_token=mom_token,
        database=database,
        collection=collection,
        **kwargs,
    )
