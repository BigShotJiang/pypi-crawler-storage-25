"""Combat system — handles ATTACK commands, damage calculation, and death detection."""

from __future__ import annotations

import random
from typing import TYPE_CHECKING

from faraway_realms.combat.damage_types import effectiveness
from faraway_realms.combat.stats import Pool
from faraway_realms.combat.status import is_stunned
from faraway_realms.entities.entity import GameEntity, get_combat_profile
from faraway_realms.systems.base import System
from faraway_realms.world.events import Event, EventType

# When True, completing a cast resets the caster's attack cooldown.
CAST_REPRIMES_ATTACK: bool = True

if TYPE_CHECKING:
    from faraway_realms.world.event_bus import EventBus


def _stat_value(entity: GameEntity, key: str, default: int) -> int:
    stat = entity.stats.get(key)
    return stat.value if stat is not None else default


class CombatSystem(System):
    """Handles ATTACK commands: cooldown gating, damage calculation, death emission.

    Parameters
    ----------
    entities : dict[int, GameEntity]
        Shared entity registry.
    bus : EventBus
        Event bus; ENTITY_HIT and ENTITY_DYING events are published directly.
    """

    def __init__(self, entities: dict[int, GameEntity], bus: EventBus) -> None:
        self._entities = entities
        self._bus = bus
        self._last_attack_tick: dict[int, int] = {}
        self._casting_entities: set[int] = set()
        bus.subscribe(EventType.ENTITY_DYING, self._on_death, priority=0)
        bus.subscribe(EventType.ENTITY_DIED, self._on_entity_died, priority=0)
        bus.subscribe(EventType.STUN_APPLIED, self._on_stun, priority=1)
        bus.subscribe(EventType.STATUS_EXPIRED, self._on_status_expired, priority=0)
        bus.subscribe(EventType.CAST_STARTED, self._on_cast_started, priority=0)
        bus.subscribe(EventType.CAST_COMPLETE, self._on_cast_complete, priority=0)
        bus.subscribe(EventType.CAST_CANCELLED, self._on_cast_cancelled, priority=0)
        bus.subscribe(EventType.TARGET_CHANGED, self._on_target_changed, priority=0)

    def handle(
        self,
        attacker_id: int,
        target_id: int,
        abs_tick: int,
        *,
        bypass_cooldown: bool = False,
    ) -> None:
        """Process an attack, publishing ENTITY_HIT and DEATH events as needed.

        Parameters
        ----------
        attacker_id : int
            Resolved entity ID of the attacker.
        target_id : int
            Resolved entity ID of the target.
        abs_tick : int
            Current tick, used for cooldown tracking and event scheduling.
        bypass_cooldown : bool
            When ``True``, skip the cooldown gate (used for opportunity attacks).
        """
        attacker = self._entities.get(attacker_id)
        target = self._entities.get(target_id)
        if attacker is None or target is None:
            return
        haste = self._haste_factor(attacker, abs_tick)
        attack_ready = self._is_attack_ready(attacker_id, attacker, abs_tick, haste)
        if not bypass_cooldown and not attack_ready:
            return
        self._last_attack_tick[attacker_id] = abs_tick
        damage, crit = self._calc_damage(attacker, target)
        self._apply_stagger(attacker, target, target_id, abs_tick)
        self._publish_hit(attacker_id, target_id, damage, crit, abs_tick)

    def effective_last_attack(self, entity_id: int) -> int:
        """Return the tick this entity last attacked.

        Stagger pushback is encoded directly into ``_last_attack_tick``, so
        this value already reflects any active stagger delay.

        Parameters
        ----------
        entity_id : int
            Entity to query.

        Returns
        -------
        int
            Tick of the last recorded (or stagger-adjusted) attack.
        """
        return self._last_attack_tick.get(entity_id, -(10**9))

    def forget(self, entity_id: int) -> None:
        """Remove attack-timing state for *entity_id*, resetting the cooldown bar.

        Parameters
        ----------
        entity_id : int
            Entity whose cooldown tracking should be cleared.
        """
        self._last_attack_tick.pop(entity_id, None)

    def prime(self, entity_id: int, abs_tick: int, *, force: bool = False) -> None:
        """Initialise the attack cooldown as if this entity just attacked.

        Parameters
        ----------
        entity_id : int
            Entity to prime.
        abs_tick : int
            Current tick; the cooldown timer starts from here.
        force : bool
            When ``True``, always reset the cooldown clock.  Use for
            intentional resets (player target switch, cast reprime).  When
            ``False`` (default), priming is a no-op for an entity that is
            already being tracked — preserves the charge built up during a
            chase when the NPC briefly loses sight and re-enters ChaseState.
        """
        if not force and entity_id in self._last_attack_tick:
            return
        self._last_attack_tick[entity_id] = abs_tick

    def _is_attack_ready(
        self,
        attacker_id: int,
        attacker: GameEntity,
        abs_tick: int,
        haste_factor: float = 1.0,
    ) -> bool:
        if is_stunned(attacker, abs_tick) or attacker_id in self._casting_entities:
            return False
        last = self.effective_last_attack(attacker_id)
        return abs_tick - last >= self._effective_attack_every(attacker, haste_factor)

    def cooldown_fraction(self, entity_id: int, abs_tick: int) -> float:
        """Return how far through the attack cooldown this entity is (0–1).

        Parameters
        ----------
        entity_id : int
            Entity to query.
        abs_tick : int
            Current absolute tick.

        Returns
        -------
        float
            ``0.0`` when unprimed, frozen (stunned or casting), or immediately
            after an attack; ``1.0`` when ready to attack.
        """
        if entity_id not in self._last_attack_tick:
            return 0.0
        entity = self._entities.get(entity_id)
        if entity is None:
            return 1.0
        if is_stunned(entity, abs_tick) or entity_id in self._casting_entities:
            return 0.0
        last = self.effective_last_attack(entity_id)
        effective = self._effective_attack_every(
            entity, self._haste_factor(entity, abs_tick)
        )
        return min(1.0, (abs_tick - last) / effective)

    def _effective_attack_every(
        self, entity: GameEntity, haste_factor: float = 1.0
    ) -> int:
        speed = entity.stats.get("attack_speed")
        bonus = speed.value if speed is not None else 0
        base = max(1, get_combat_profile(entity).attack_every - bonus)
        return max(1, round(base / haste_factor))

    def _calc_damage(
        self, attacker: GameEntity, target: GameEntity
    ) -> tuple[int, bool]:
        str_val = _stat_value(attacker, "strength", 1)
        armor_val = _stat_value(target, "armor", 0)
        acp = get_combat_profile(attacker)
        tcp = get_combat_profile(target)
        mult = effectiveness(acp.damage_type, tcp.armor_type)
        base = max(1, round((str_val - armor_val) * mult))
        crit = self._roll_crit(attacker)
        return (base * 2 if crit else base), crit

    def _roll_crit(self, attacker: GameEntity) -> bool:
        crit_val = _stat_value(attacker, "crit_chance", 0)
        return (
            crit_val > 0 and random.randint(1, 100) <= crit_val  # noqa: S311 — game logic
        )

    def _apply_stagger(
        self,
        attacker: GameEntity,
        target: GameEntity,
        target_id: int,
        abs_tick: int,
    ) -> int:
        """Push the target's attack cooldown back if they are mid-cooldown.

        Stagger has no effect when the target is already fully ready to attack
        — they have recovered from their last swing and are balanced.  When
        mid-cooldown, the remaining wait is extended by
        ``max(1, attacker_strength // 2)`` ticks (capped so the bar never
        resets past its starting point).

        Parameters
        ----------
        attacker : GameEntity
            The entity landing the hit; determines pushback magnitude.
        target : GameEntity
            The entity being staggered; used to read ``attack_every``.
        target_id : int
            Entity ID used to update ``_last_attack_tick``.
        abs_tick : int
            Current absolute tick.

        Returns
        -------
        int
            Ticks of pushback applied; ``0`` when no stagger was applied.
        """
        target_last = self._last_attack_tick.get(target_id, -(10**9))
        elapsed = abs_tick - target_last
        if elapsed >= self._effective_attack_every(target):
            return 0  # already ready — not staggered
        pushback = max(1, _stat_value(attacker, "strength", 1) // 2)
        # Advance last_attack_tick forward (extending remaining cooldown).
        # Cap at abs_tick so the bar never goes below 0.
        self._last_attack_tick[target_id] = min(abs_tick, target_last + pushback)
        return pushback

    def _on_death(self, event: Event) -> None:
        """Clear cooldown tracking for entities targeting the dying entity.

        Fires on ENTITY_DYING (priority 0) before DeathSystem clears target
        refs, so target_id comparisons still resolve correctly.
        """
        dead_id = event.source_id
        for eid, entity in self._entities.items():
            if entity.target_id == dead_id:
                self.forget(eid)

    def _on_entity_died(self, event: Event) -> None:
        """Forget cooldown tracking for the entity that has now been removed."""
        self.forget(event.source_id)
        self._casting_entities.discard(event.source_id)

    def _on_stun(self, event: Event) -> None:
        """Prime the attack cooldown of a newly stunned entity."""
        eid = event.target_id or event.source_id
        self.prime(eid, event.resolve_at_tick)

    def _on_status_expired(self, event: Event) -> None:
        """Reset the attack bar to zero when a stun expires."""
        if event.payload and event.payload.get("stun"):
            self.prime(event.source_id, event.resolve_at_tick, force=True)

    def _on_cast_started(self, event: Event) -> None:
        """Track that this entity has an active timed cast in progress."""
        self._casting_entities.add(event.source_id)

    def _on_cast_complete(self, event: Event) -> None:
        """Reset the caster's attack cooldown when a cast completes."""
        self._casting_entities.discard(event.source_id)
        if CAST_REPRIMES_ATTACK:
            self.prime(event.source_id, event.resolve_at_tick, force=True)

    def _on_cast_cancelled(self, event: Event) -> None:
        """Reset the attack bar when a cast is cancelled."""
        self._casting_entities.discard(event.source_id)
        self.prime(event.source_id, event.resolve_at_tick, force=True)

    def _on_target_changed(self, event: Event) -> None:
        """Reset the attack cooldown when an entity switches targets."""
        self.prime(event.source_id, event.resolve_at_tick, force=True)

    def _haste_factor(self, entity: GameEntity, abs_tick: int) -> float:
        """Return the combined haste multiplier from entity's active statuses."""
        factors = [
            s.haste
            for s in entity.status_effects
            if not s.is_expired(abs_tick) and s.haste != 1.0
        ]
        return max(factors) if factors else 1.0

    def _publish_hit(
        self,
        attacker_id: int,
        target_id: int,
        damage: int,
        crit: bool,
        abs_tick: int,
    ) -> None:
        """Apply damage and publish ENTITY_HIT (and DEATH if pool depleted).

        ENTITY_HIT must be published before DEATH.  BloodSystem subscribes to
        ENTITY_HIT and captures animation data (positions, colours) while both
        entities are still alive.  EventBus dispatches in publish order, so
        swapping these two publishes would silently break kill-blow animations.
        """
        target = self._entities.get(target_id)
        if target is None:
            return
        self._bus.publish(
            Event(
                event_type=EventType.ENTITY_HIT,
                source_id=attacker_id,
                target_id=target_id,
                resolve_at_tick=abs_tick,
                payload={"damage": damage, "crit": crit, "is_ability": False},
            )
        )
        pool = target.stats.get(get_combat_profile(target).death_stat)
        if not isinstance(pool, Pool):
            return
        pool.modify(-damage)
        if pool.is_empty:
            self._bus.publish(
                Event(
                    event_type=EventType.ENTITY_DYING,
                    source_id=target_id,
                    resolve_at_tick=abs_tick,
                )
            )
