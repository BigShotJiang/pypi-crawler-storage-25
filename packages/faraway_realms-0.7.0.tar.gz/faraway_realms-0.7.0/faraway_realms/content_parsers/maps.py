"""Parser for map profile YAML definitions."""

from __future__ import annotations

from faraway_realms.effects.fog import FogParams
from faraway_realms.mapgen.generator import GeneratorConfig
from faraway_realms.mapgen.map_profile import MAP_PROFILE_REGISTRY, MapProfile
from faraway_realms.mapgen.scatter_pass import ScatterReplacement, ScatterRule


def parse_map_profiles(entries: dict) -> None:
    """Populate MAP_PROFILE_REGISTRY from a parsed YAML entries dict.

    Parameters
    ----------
    entries : dict
        Mapping of profile name → raw YAML dict, as produced by
        :class:`~faraway_realms.content.ContentLoader`.
    """
    for name, data in entries.items():
        MAP_PROFILE_REGISTRY[name] = _parse_map_profile(name, data)


def _parse_labels(data: dict, key: str) -> tuple[str, ...] | None:
    """Parse a label list from *data[key]*.

    Absent key → ``None`` (all types eligible, preserves old default behaviour).
    Explicit empty list → empty tuple (spawn nothing).
    Populated list → tuple of label strings.
    """
    if key not in data:
        return None
    raw = data[key]
    return tuple(raw) if raw else ()


def _parse_generator(data: dict) -> GeneratorConfig:
    kind = str(data.get("generator", "cave"))
    raw = data.get("generator_params") or {}
    params = tuple(
        (k, v) for k, v in raw.items() if isinstance(v, (int, float, str, bool))
    )
    return GeneratorConfig(kind=kind, params=params)


def _parse_map_profile(name: str, data: dict) -> MapProfile:
    texture = data.get("texture") or {}
    patches_raw = texture.get("patches")
    overlays_raw = texture.get("overlays")
    return MapProfile(
        name=name,
        generator=_parse_generator(data),
        creature_labels=_parse_labels(data, "creature_labels"),
        creature_count=int(data.get("creature_count", 0)),
        creature_min_player_distance=int(data.get("creature_min_player_distance", 8)),
        static_object_labels=_parse_labels(data, "static_object_labels"),
        static_object_count=int(data.get("static_object_count", 0)),
        static_object_min_player_distance=int(
            data.get("static_object_min_player_distance", 8)
        ),
        floor_tile=str(data.get("floor_tile", "cave_floor")),
        wall_tile=str(data.get("wall_tile", "cave_wall")),
        texture_patches=tuple(patches_raw) if patches_raw is not None else None,
        texture_overlays=tuple(overlays_raw) if overlays_raw is not None else None,
        noise_texture=bool(data.get("noise_texture", True)),
        noise_scale=float(data.get("noise_scale", 0.06)),
        noise_strength=float(data.get("noise_strength", 0.15)),
        scatter=tuple(_parse_scatter_rule(r) for r in data.get("scatter", [])),
        ambient=float(data.get("ambient", 0.35)),
        fog=_parse_fog(data.get("fog") or {}),
        generate_doors=bool(data.get("generate_doors", False)),
        door_tile=str(data.get("door_tile", "")),
        door_density=float(data.get("door_density", 1.0)),
    )


def _parse_scatter_rule(data: dict) -> ScatterRule:
    return ScatterRule(
        target=str(data["target"]),
        replacements=tuple(
            ScatterReplacement(
                tile=str(r["tile"]),
                probability=float(r["probability"]),
                inherit_bg=bool(r.get("inherit_bg", False)),
                inherit_fg=bool(r.get("inherit_fg", False)),
            )
            for r in data.get("replacements", [])
        ),
        zone=data.get("zone") or None,
        exclude_zones=tuple(data.get("exclude_zones") or []),
    )


def _parse_fog(data: dict) -> FogParams:
    color_raw = data.get("color", [130, 145, 165])
    return FogParams(
        density=float(data.get("density", 0.5)),
        scale=float(data.get("scale", 0.15)),
        wind_x=float(data.get("wind_x", 0.25)),
        wind_y=float(data.get("wind_y", 0.10)),
        color=(int(color_raw[0]), int(color_raw[1]), int(color_raw[2])),
        opacity_min=float(data.get("opacity_min", 0.0)),
        opacity_max=float(data.get("opacity_max", 0.20)),
        seed=int(data.get("seed", 7)),
    )
