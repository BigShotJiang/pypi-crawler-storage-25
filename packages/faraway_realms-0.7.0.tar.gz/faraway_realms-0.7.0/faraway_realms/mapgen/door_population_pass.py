"""Door population pass — places door tiles at corridor chokepoints."""

from __future__ import annotations

import random

from faraway_realms.mapgen.base import DoorCandidate, MapGenResult, PopulationPass
from faraway_realms.mapgen.map_profile import MapProfile
from faraway_realms.world.map import Map


class DoorPopulationPass(PopulationPass):
    """Places door tiles at ``door_candidates`` produced by the generator.

    Skipped when ``profile.generate_doors`` is False or ``door_tile`` is empty.
    Each candidate covers a 2-tile corridor opening; both tiles are placed
    atomically (or skipped together if either is not walkable).

    Parameters
    ----------
    profile : MapProfile
        Map profile supplying ``generate_doors``, ``door_tile`` (registry key),
        and ``door_density`` (fraction of candidates that receive a door).
    """

    def __init__(self, profile: MapProfile) -> None:
        self._profile = profile

    def apply(self, result: MapGenResult, rng: random.Random) -> None:
        """Place doors at candidate positions according to density.

        Parameters
        ----------
        result : MapGenResult
            Generation result with ``door_candidates`` populated.
        rng : random.Random
            Seeded RNG for deterministic placement.
        """
        if not self._profile.generate_doors or not self._profile.door_tile:
            return
        for candidate in result.door_candidates:
            if rng.random() < self._profile.door_density:
                self._place_pair(
                    result.map, result.tile_type_ids, candidate, self._profile.door_tile
                )

    @staticmethod
    def _place_pair(
        game_map: Map,
        tile_type_ids: dict,
        candidate: DoorCandidate,
        tile_name: str,
    ) -> None:
        """Place a door on both tiles of a 2-wide corridor opening.

        Skipped when the corridor is wider than 2 tiles (corridor crossing).
        """
        x2 = candidate.x + (1 if candidate.horizontal else 0)
        y2 = candidate.y + (0 if candidate.horizontal else 1)
        x3 = candidate.x + (2 if candidate.horizontal else 0)
        y3 = candidate.y + (0 if candidate.horizontal else 2)
        if (
            game_map.is_walkable(candidate.x, candidate.y)
            and game_map.is_walkable(x2, y2)
            and not game_map.is_walkable(x3, y3)
        ):
            game_map.replace_tile(candidate.x, candidate.y, tile_name)
            game_map.replace_tile(x2, y2, tile_name)
            tile_type_ids[(candidate.x, candidate.y)] = tile_name
            tile_type_ids[(x2, y2)] = tile_name
