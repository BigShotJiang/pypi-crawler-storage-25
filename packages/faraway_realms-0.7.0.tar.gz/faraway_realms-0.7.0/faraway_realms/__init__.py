"""Faraway Realms — a real-time tick-based roguelike RPG."""

__version__ = "0.7.0"
