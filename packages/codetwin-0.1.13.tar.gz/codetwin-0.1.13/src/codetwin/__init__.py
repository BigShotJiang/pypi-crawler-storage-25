import platform
import subprocess
import sys
from pathlib import Path


def _bootstrap_binary() -> None:
    tag = "v0.1.13"
    base = "https://github.com/carlosferreyra/codetwin".rstrip("/")

    match platform.system().lower():
        case "windows":
            url = f"{base}/releases/download/{tag}/codetwin-installer.ps1"
            cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", f"iwr -useb '{url}' | iex"]
        case _:
            url = f"{base}/releases/download/{tag}/codetwin-installer.sh"
            cmd = ["sh", "-c", f"curl -LsSf '{url}' | sh"]

    subprocess.run(cmd, check=False)


def main() -> int:
    bin_name = "codetwin"
    if platform.system().lower() == "windows":
        bin_name += ".exe"

    # Use absolute path to avoid recursion with the Python shim in PATH.
    exe = Path.home() / ".cargo" / "bin" / bin_name

    if not exe.exists():
        print(f"Binary not found at {exe}. Attempting to install...", file=sys.stderr)
        _bootstrap_binary()

    if exe.exists():
        return subprocess.run([str(exe), *sys.argv[1:]]).returncode

    print(f"Failed to find or install {bin_name} at {exe}", file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main())