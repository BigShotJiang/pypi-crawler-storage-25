"""ModelPricing.ai Python client for cost estimates and tracking."""

from .client import ModelPricingClient

try:
    from .async_client import AsyncModelPricingClient
except ImportError:
    AsyncModelPricingClient = None  # type: ignore[assignment,misc]

try:
    from ._version import __version__
except ImportError:
    __version__ = "0.0.0.dev0"

__all__ = ["AsyncModelPricingClient", "ModelPricingClient", "__version__"]
