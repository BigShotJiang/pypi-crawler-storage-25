"""Internal helpers for extracting usage data from provider SDK responses.

Supports the three common response shapes:

* Anthropic Messages — ``usage.input_tokens`` / ``usage.output_tokens``,
  with optional ``cache_read_input_tokens`` / ``cache_creation_input_tokens``.
* OpenAI Responses API — ``usage.input_tokens`` / ``usage.output_tokens``.
* OpenAI Chat Completions — ``usage.prompt_tokens`` / ``usage.completion_tokens``,
  with optional ``prompt_tokens_details.cached_tokens`` (or top-level
  ``cached_tokens`` on older SDK shapes). Cached tokens are a SUBSET of
  ``prompt_tokens``, so we subtract before reporting ``tokens_in`` to keep the
  ModelPricing.ai API's additive cache semantics.

The extractor accepts either a Pydantic model (duck-typed via ``model_dump``)
or a plain ``dict`` with the same shape.
"""

from typing import Any, NamedTuple


class ExtractedUsage(NamedTuple):
    """Token counts extracted from a provider SDK response.

    ``tokens_in`` is fresh non-cached input tokens; cache fields are additive
    (separate from tokens_in) and map 1:1 to the matching :func:`estimate`
    kwargs.
    """

    model: str
    tokens_in: int
    tokens_out: int
    cache_read: int = 0
    cache_write_5m: int = 0
    cache_write_1h: int = 0


def extract_usage(response: Any) -> ExtractedUsage:
    """Extract usage fields from a provider response.

    @param response - An Anthropic or OpenAI SDK response object (Pydantic
        model) or a dict with the same shape.
    @returns :class:`ExtractedUsage` with model name, fresh input/output
        token counts, and any cache-token fields.
    @throws ValueError if the response shape is unrecognized or the ``model``
        field is missing.
    """
    if hasattr(response, "model_dump"):
        data = response.model_dump(mode="json")
    elif isinstance(response, dict):
        data = response
    else:
        raise ValueError(
            "response must be a Pydantic model or dict — got "
            f"{type(response).__name__}"
        )

    model = data.get("model")
    if not isinstance(model, str) or not model.strip():
        raise ValueError("response is missing a non-empty 'model' field")

    usage = data.get("usage")
    if not isinstance(usage, dict):
        raise ValueError("response is missing a 'usage' object")

    if "input_tokens" in usage and "output_tokens" in usage:
        # Anthropic Messages or OpenAI Responses. Cache fields only present
        # on Anthropic; OpenAI Responses doesn't surface them on this shape.
        return ExtractedUsage(
            model=model,
            tokens_in=int(usage["input_tokens"]),
            tokens_out=int(usage["output_tokens"]),
            cache_read=int(usage.get("cache_read_input_tokens") or 0),
            cache_write_5m=int(usage.get("cache_creation_input_tokens") or 0),
        )

    if "prompt_tokens" in usage and "completion_tokens" in usage:
        # OpenAI Chat Completions. cached_tokens is a subset of prompt_tokens —
        # subtract so the additive cache semantic holds in our API.
        details = usage.get("prompt_tokens_details")
        cached = (
            int(details.get("cached_tokens") or 0)
            if isinstance(details, dict)
            else int(usage.get("cached_tokens") or 0)
        )
        prompt_tokens = int(usage["prompt_tokens"])
        return ExtractedUsage(
            model=model,
            tokens_in=max(prompt_tokens - cached, 0),
            tokens_out=int(usage["completion_tokens"]),
            cache_read=cached,
        )

    raise ValueError(
        "unrecognized usage shape — expected Anthropic Messages, OpenAI "
        "Responses, or OpenAI Chat Completions (usage.input_tokens/"
        "output_tokens or usage.prompt_tokens/completion_tokens)"
    )
