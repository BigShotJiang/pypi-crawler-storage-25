import logging
import os
from collections.abc import Callable
from typing import Any, TypeVar

import requests
from pydantic import ValidationError as PydanticValidationError
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential_jitter,
)

from ._extractors import extract_usage
from .errors import (
    ModelPricingError,
    NotFound,
    ServerError,
    Unauthorized,
    ValidationError,
)
from .models import EstimateResponse

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


def _build_cache_payload(
    cache_read_tokens: int | None,
    cache_write_5m_tokens: int | None,
    cache_write_1h_tokens: int | None,
) -> dict[str, int] | None:
    """Build the metrics.cache payload from the optional cache kwargs.

    Returns None when no cache field is set so the caller can omit the key
    entirely. Each field is included only when it is a positive integer —
    zero-valued kwargs are treated as absent.

    Token counts are rejected if they are not true non-negative ``int`` values.
    Floats are rejected explicitly — silently truncating ``1.9 → 1`` could
    miscount billed cache tokens, so callers must round before passing in.
    ``bool`` is also rejected (``True``/``False`` are technically ``int`` in
    Python but never make sense as a token count).

    @throws ValueError if any provided value is not a non-negative ``int``.
    """
    fields = (
        ("read", cache_read_tokens),
        ("write5m", cache_write_5m_tokens),
        ("write1h", cache_write_1h_tokens),
    )
    payload: dict[str, int] = {}
    for name, value in fields:
        if value is None:
            continue
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"cache.{name} tokens must be a non-negative integer")
        if value > 0:
            payload[name] = value
    return payload or None


class ModelPricingClient:
    """Synchronous client for the ModelPricing.ai API.

    Sends cost-estimation requests to the ``/v1/estimate`` endpoint and
    returns typed :class:`EstimateResponse` objects.  Retries automatically
    on transient server errors with exponential back-off.

    @param api_key - API key (falls back to ``MODELPRICING_API_KEY`` env var).
    @param base_url - API base URL (falls back to ``MODELPRICING_BASE_URL``).
    @param timeout - Request timeout in seconds.
    @param session - Optional pre-configured ``requests.Session``.
    @param max_retries - Maximum retry attempts for transient errors.
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        timeout: float = 30.0,
        session: requests.Session | None = None,
        max_retries: int = 3,
    ) -> None:
        resolved_key = api_key or os.environ.get("MODELPRICING_API_KEY")
        if not resolved_key or not isinstance(resolved_key, str):
            raise ValueError(
                "api_key is required — pass it as an argument or set the "
                "MODELPRICING_API_KEY environment variable"
            )
        self.api_key = resolved_key
        configured_base = base_url or os.environ.get(
            "MODELPRICING_BASE_URL", "https://api.modelpricing.ai"
        )
        self.base_url = configured_base.rstrip("/")
        self.timeout = timeout
        self._owns_session = session is None
        self._session = session or requests.Session()
        self.max_retries = max_retries

    # -- context manager --------------------------------------------------

    def __enter__(self) -> "ModelPricingClient":
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if self._owns_session:
            self._session.close()

    # -- internals --------------------------------------------------------

    def _headers(self) -> dict[str, str]:
        """Build the default request headers."""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _retry_on_server_error(self, func: F) -> F:
        """Wrap *func* with tenacity retry on server/connection errors."""
        return retry(
            retry=retry_if_exception_type(
                (ServerError, requests.exceptions.RequestException)
            ),
            stop=stop_after_attempt(self.max_retries + 1),
            wait=wait_exponential_jitter(initial=0.1, max=2, jitter=0.5),
            reraise=True,
        )(func)

    def _handle_response(self, response: requests.Response) -> EstimateResponse:
        """Parse an HTTP response into an :class:`EstimateResponse`.

        @param response - The raw ``requests.Response``.
        @returns Validated estimate response.
        @throws Unauthorized on 401.
        @throws NotFound on 404.
        @throws ValidationError on 422.
        @throws ServerError on 5xx.
        @throws ModelPricingError on other non-200 status codes.
        """
        if response.status_code == 200:
            data = response.json()
            try:
                return EstimateResponse.model_validate(data)
            except PydanticValidationError as exc:
                logger.warning("Failed to validate estimate response: %s", exc)
                raise ModelPricingError(
                    f"Unexpected response structure: {exc}",
                    status_code=200,
                ) from exc
        if response.status_code == 401:
            raise Unauthorized("Unauthorized", status_code=401)
        if response.status_code == 404:
            raise NotFound("Not found", status_code=404)
        if response.status_code == 422:
            try:
                data = response.json()
                message = data.get("error") or "Unprocessable Entity"
                details = data.get("details")
                if details:
                    message = f"{message}: {details}"
            except (ValueError, KeyError):
                message = "Unprocessable Entity"
            raise ValidationError(message, status_code=422)

        try:
            data = response.json()
            message = data.get("error") or response.text or "HTTP error"
        except (ValueError, KeyError):
            message = response.text or "HTTP error"

        if 500 <= response.status_code <= 599:
            raise ServerError(message, status_code=response.status_code)
        raise ModelPricingError(message, status_code=response.status_code)

    # -- public API -------------------------------------------------------

    def estimate(
        self,
        *,
        model: str,
        tokens_in: int,
        tokens_out: int,
        cache_read_tokens: int | None = None,
        cache_write_5m_tokens: int | None = None,
        cache_write_1h_tokens: int | None = None,
        trace_id: dict[str, Any] | None = None,
    ) -> EstimateResponse:
        """Estimate the cost of an LLM API call.

        Calls ``POST /v1/estimate`` and returns a validated response.
        Retries automatically on 5xx errors with exponential back-off.

        @param model - Canonical model identifier (e.g. ``"gpt-4o-mini"``).
        @param tokens_in - Fresh non-cached input tokens (must be >= 0).
        @param tokens_out - Number of output tokens (must be >= 0).
        @param cache_read_tokens - Optional cache-hit tokens (additive, separate
            from tokens_in).
        @param cache_write_5m_tokens - Optional cache-write tokens at 5-minute
            TTL (Anthropic).
        @param cache_write_1h_tokens - Optional cache-write tokens at 1-hour
            TTL (Anthropic).
        @param trace_id - Optional pass-through trace data returned in the response.
        @returns Validated :class:`EstimateResponse` with cost breakdown.
        @throws ValueError if model is empty or token counts are negative.
        @throws Unauthorized on invalid API key (401).
        @throws ValidationError on unknown model or bad metrics (422).
        @throws ServerError on 5xx after retries are exhausted.
        """
        if not isinstance(model, str) or not model.strip():
            raise ValueError("model must be a non-empty string")
        if not isinstance(tokens_in, (int, float)) or tokens_in < 0:
            raise ValueError("tokens_in must be a non-negative number")
        if not isinstance(tokens_out, (int, float)) or tokens_out < 0:
            raise ValueError("tokens_out must be a non-negative number")

        cache_payload = _build_cache_payload(
            cache_read_tokens, cache_write_5m_tokens, cache_write_1h_tokens
        )

        def _make_request() -> EstimateResponse:
            url = f"{self.base_url}/v1/estimate"
            metrics: dict[str, Any] = {
                "tokensIn": int(tokens_in),
                "tokensOut": int(tokens_out),
            }
            if cache_payload is not None:
                metrics["cache"] = cache_payload
            payload: dict[str, Any] = {"model": model, "metrics": metrics}
            if trace_id is not None:
                payload["traceId"] = trace_id

            logger.debug("POST %s %s", url, payload)
            response = self._session.post(
                url, json=payload, headers=self._headers(), timeout=self.timeout
            )
            return self._handle_response(response)

        return self._retry_on_server_error(_make_request)()

    def estimate_from_response(
        self,
        response: Any,
        *,
        trace_id: dict[str, Any] | None = None,
    ) -> EstimateResponse:
        """Estimate cost directly from a provider SDK response object.

        Accepts the Pydantic response returned by the Anthropic or OpenAI SDK
        (or a dict with the same shape), extracts the model name, token
        counts, and any cache-token fields, and forwards them to
        :meth:`estimate`. Supports Anthropic Messages, OpenAI Chat Completions,
        and OpenAI Responses API.

        For Anthropic, ``cache_creation_input_tokens`` is routed to
        ``cache_write_5m_tokens`` (the SDK response does not distinguish 5m
        vs 1h TTL — pass the right kwarg to :meth:`estimate` directly if you
        used 1h TTL). For OpenAI, ``cached_tokens`` is subtracted from
        ``tokens_in`` so the additive semantic holds.

        @param response - The provider response object (Pydantic model or dict).
        @param trace_id - Optional pass-through trace data returned in the response.
        @returns Validated :class:`EstimateResponse` with cost breakdown.
        @throws ValueError if the response shape is unrecognized.
        @throws Unauthorized on invalid API key (401).
        @throws ValidationError on unknown model or bad metrics (422).
        @throws ServerError on 5xx after retries are exhausted.
        """
        usage = extract_usage(response)
        return self.estimate(
            model=usage.model,
            tokens_in=usage.tokens_in,
            tokens_out=usage.tokens_out,
            cache_read_tokens=usage.cache_read or None,
            cache_write_5m_tokens=usage.cache_write_5m or None,
            cache_write_1h_tokens=usage.cache_write_1h or None,
            trace_id=trace_id,
        )
