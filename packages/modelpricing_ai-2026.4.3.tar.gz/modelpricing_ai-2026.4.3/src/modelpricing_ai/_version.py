"""Version identifier — set by CI."""

__version__ = "2026.4.3"
