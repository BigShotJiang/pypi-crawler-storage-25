"""Custom exception hierarchy for the ModelPricing.ai client."""


class ModelPricingError(Exception):
    """Base exception for all ModelPricing client errors.

    @param message - Human-readable error description.
    @param status_code - HTTP status code, if applicable.
    """

    def __init__(self, message: str, *, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class Unauthorized(ModelPricingError):
    """Raised on HTTP 401 — invalid or missing API key."""


class ValidationError(ModelPricingError):
    """Raised on HTTP 422 — unknown model or invalid request metrics."""


class NotFound(ModelPricingError):
    """Raised on HTTP 404 — unknown endpoint."""


class ServerError(ModelPricingError):
    """Raised on HTTP 5xx — transient server-side failure."""
