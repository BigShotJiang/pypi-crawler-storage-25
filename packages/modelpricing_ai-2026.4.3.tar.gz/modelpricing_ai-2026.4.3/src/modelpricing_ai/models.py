"""Pydantic response models for the ModelPricing.ai API."""

from typing import Any

from pydantic import BaseModel, Field


class EstimateBreakdown(BaseModel):
    """Cost breakdown for a single direction (input or output).

    @param unit - Pricing unit (e.g. ``"per-1M-input"``).
    @param branch - Pricing tier that matched the model.
    @param qty - Number of tokens.
    @param rate - Per-unit rate in USD.
    @param subtotal - Computed cost for this direction.
    """

    unit: str
    branch: str
    qty: int
    rate: float
    subtotal: float


class EstimateCacheBreakdownGroup(BaseModel):
    """Per-cache-field cost breakdowns.

    Each field is present only when the request supplied a non-zero count for
    it AND the model prices that cache operation.

    @param read - Cache-read (hit) tokens at the cache-read rate.
    @param write5m - Cache-write tokens at 5-minute TTL (Anthropic).
    @param write1h - Cache-write tokens at 1-hour TTL (Anthropic).
    """

    read: EstimateBreakdown | None = None
    write5m: EstimateBreakdown | None = None
    write1h: EstimateBreakdown | None = None


class EstimateBreakdownGroup(BaseModel):
    """Grouped input/output (and optional cache) cost breakdowns.

    @param input - Breakdown for input tokens.
    @param output - Breakdown for output tokens.
    @param cache - Optional cache-token breakdown. Absent when the request
        sent no cache fields or the model does not price caching.
    """

    input: EstimateBreakdown
    output: EstimateBreakdown
    cache: EstimateCacheBreakdownGroup | None = None


class EstimateResponse(BaseModel):
    """API response for a cost estimation request.

    @param total - Total estimated cost in USD.
    @param breakdown - Line-item breakdown of input/output costs.
    @param model - Canonical model identifier returned by the server.
    @param traceId - Optional pass-through trace data.
    """

    total: float
    breakdown: EstimateBreakdownGroup
    model: str
    traceId: dict[str, Any] | None = Field(default=None)
