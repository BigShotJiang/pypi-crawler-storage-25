from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import click

from . import __version__
from .errors import activate
from .transpiler import run_transpiled, transpile_file

CONTEXT_SETTINGS = dict(help_option_names=["-h", "--help"])

def _load_effective_pack(project: Path, lang: str) -> dict:
    """
    Load pack for a file. Priority:
    1. custom_pack in .foreignthon.toml — no installed pack needed
    2. installed pack via entry points
    """
    import json

    from .pack import load_pack

    # Walk up to find .foreignthon.toml
    search = project if project.is_dir() else project.parent
    toml_path = None
    for parent in [search, *search.parents]:
        candidate = parent / ".foreignthon.toml"
        if candidate.exists():
            toml_path = candidate
            break

    # Check for custom_pack first — if found, load it directly
    # and merge on top of template (no installed pack required)
    if toml_path:
        for line in toml_path.read_text(encoding="utf-8").splitlines():
            if line.strip().startswith("custom_pack") and not line.strip().startswith("#"):
                custom_path = toml_path.parent / line.split("=", 1)[1].strip().strip('"').strip("'")
                if custom_path.exists():
                    custom = json.loads(custom_path.read_text(encoding="utf-8"))
                    # If custom pack has meta with a code, it's a standalone pack
                    if custom.get("meta", {}).get("code"):
                        return custom
                    # Otherwise it's an override — merge on top of installed pack
                    pack = load_pack(lang)
                    for section in ("keywords", "builtins", "exceptions", "stdlib", "error_messages"):
                        if section in custom:
                            pack[section] = {**pack.get(section, {}), **custom[section]}
                    if "postfix_keywords" in custom:
                        pack["postfix_keywords"] = custom["postfix_keywords"]
                    return pack
                break

    # Fall back to installed pack
    return load_pack(lang)


def _pick(mapping: dict, english: str, fallback: str) -> str:
    reverse = {v: k for k, v in mapping.items()}
    return reverse.get(english, fallback)


def _git_init(project: Path) -> None:
    git_ok = subprocess.run(["git", "--version"], capture_output=True).returncode == 0
    if git_ok:
        subprocess.run(["git", "init"], cwd=project, capture_output=True)
        subprocess.run(["git", "add", "."], cwd=project, capture_output=True)
        subprocess.run(
            ["git", "commit", "-m", "initial commit"],
            cwd=project, capture_output=True,
        )


def _lang_from_file(path: Path) -> str:
    suffixes = path.suffixes
    if len(suffixes) >= 2 and suffixes[-1] == ".py":
        return suffixes[-2].lstrip(".")
    return "en"


@click.group(context_settings=CONTEXT_SETTINGS)
@click.version_option(__version__, prog_name="fpy")
def main():
    """ForeignThon — write Python in any language."""
    pass


@main.command(context_settings=CONTEXT_SETTINGS)
@click.argument("name", default="")
@click.option("--lang", "-l", required=True, help="Language code (e.g. es, ta)")
@click.option("--no-git", is_flag=True, help="Skip git init")
def new(name: str, lang: str, no_git: bool):
    """
    Create a new ForeignThon project.

    \b
    fpy new myproject --lang es     # creates myproject/
    fpy new --lang es               # initializes current directory
    """
    from .pack import PackNotFoundError

    if name:
        project = Path(name)
        if project.exists():
            click.echo(f"✗ '{name}' already exists.", err=True)
            raise SystemExit(1)
        project.mkdir(parents=True)
    else:
        project = Path.cwd()
        if any(project.iterdir()):
            click.echo("✗ Current directory is not empty.", err=True)
            raise SystemExit(1)

    is_custom = lang == "custom"

    if is_custom:
        lang_code = click.prompt("Language code (e.g. ru, fr, de)")
        lang_name_en = click.prompt("Language name in English (e.g. Russian)")
        lang_name_native = click.prompt("Language name in its own script (e.g. Русский)")
        pack = _make_scaffold_pack(lang_code, lang_name_en, lang_name_native)
        lang = lang_code
    else:
        try:
            pack = _load_effective_pack(project, lang)
        except PackNotFoundError:
            click.echo(f"✗ Language pack '{lang}' not installed.", err=True)
            click.echo(f"  Run: pip install foreignthon-{lang}", err=True)
            raise SystemExit(1)

    lang_name = pack["meta"]["native_name"]

    if is_custom:
        import json
        (project / "custom.json").write_text(
            json.dumps(pack, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        toml_custom_line = 'custom_pack = "custom.json"'
        click.echo("  Created custom.json — fill in your translations!")
    else:
        toml_custom_line = '# custom_pack = "custom.json"'

    (project / ".foreignthon.toml").write_text(
        f'[foreignthon]\n'
        f'lang = "{lang}"\n'
        f'\n'
        f'# Optional: path to a local JSON that overrides pack keywords\n'
        f'{toml_custom_line}\n',
        encoding="utf-8",
    )

    (project / ".gitignore").write_text(
        "__pycache__/\n"
        "*.py[cod]\n"
        "*.egg-info/\n"
        "dist/\n"
        "build/\n"
        ".venv/\n"
        ".pytest_cache/\n"
        ".DS_Store\n"
        "Thumbs.db\n",
        encoding="utf-8",
    )

    src = project / "src"
    src.mkdir(exist_ok=True)

    bi_print = _pick(pack["builtins"], "print", "print")
    (src / f"main.{lang}.py").write_text(
        f"# Hello, World! in {lang_name}\n"
        f'{bi_print}("Hello, World!")\n',
        encoding="utf-8",
    )

    (project / "README.md").write_text(
        f"# {name or project.name}\n\n"
        f"A ForeignThon project in {lang_name}.\n\n"
        f"## Run\n\n"
        f"```bash\n"
        f"fpy run src/main.{lang}.py\n"
        f"```\n\n"
        f"## Custom pack override\n\n"
        f"Create a `custom.json` and set `custom_pack = \"custom.json\"` "
        f"in `.foreignthon.toml` to add or override keywords locally.\n",
        encoding="utf-8",
    )

    if not no_git:
        _git_init(project)

    click.echo(f"✓ Created '{name or '.'}' [{lang_name}]")
    if name:
        click.echo(f"  cd {name}")
    click.echo(f"  fpy run src/main.{lang}.py")


@main.command(context_settings=CONTEXT_SETTINGS)
@click.argument("file", type=click.Path(exists=True, path_type=Path))
@click.option("--lang", "-l", default=None, help="Override language code (e.g. es, ta)")
@click.option("--keep", is_flag=True, help="Keep the compiled .py alongside the source")
def run(file: Path, lang: str | None, keep: bool):
    """Transpile and run a foreign-language Python file."""
    if lang:
        source = file.read_text(encoding="utf-8")
        if not source.startswith("# foreignthon:"):
            source = f"# foreignthon: {lang}\n" + source
            file.write_text(source, encoding="utf-8")

    detected_lang = lang or _lang_from_file(file)
    activate(detected_lang)

    pack = _load_effective_pack(file, detected_lang)
    transpiled = transpile_file(file, pack=pack)

    if keep:
        out_path = file.with_suffix("").with_suffix(".compiled.py")
        out_path.write_text(transpiled, encoding="utf-8")
        click.echo(f"Compiled: {out_path}")

    run_transpiled(file, transpiled)


@main.command(context_settings=CONTEXT_SETTINGS)
@click.argument("file", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--output", "-o", default=None,
    help="Output file or directory. Defaults to same directory as source."
)
def compile(file: Path, output: str | None):
    """
    Transpile a foreign-language file to standard Python.

    \b
    fpy compile script.es.py              # → script.compiled.py
    fpy compile script.es.py -o out/      # → out/script.compiled.py
    fpy compile script.es.py -o out.py    # → out.py
    """
    detected_lang = _lang_from_file(file)
    pack = _load_effective_pack(file, detected_lang)
    transpiled = transpile_file(file, pack=pack)

    if output is None:
        out_path = file.with_suffix("").with_suffix(".compiled.py")
    else:
        out = Path(output)
        if out.is_dir() or str(output).endswith("/"):
            out.mkdir(parents=True, exist_ok=True)
            out_path = out / file.with_suffix("").with_suffix(".compiled.py").name
        else:
            out_path = out

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(transpiled, encoding="utf-8")
    click.echo(f"Compiled: {out_path}")


@main.command(context_settings=CONTEXT_SETTINGS)
@click.argument("file", type=click.Path(exists=True, path_type=Path))
def check(file: Path):
    """Validate a foreign-language file without running it."""
    import ast

    detected_lang = _lang_from_file(file)
    try:
        pack = _load_effective_pack(file, detected_lang)
        transpiled = transpile_file(file, pack=pack)
        ast.parse(transpiled)
        click.echo(f"✓ {file.name} looks good.")
    except SyntaxError as e:
        click.echo(f"✗ Syntax error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"✗ {e}", err=True)
        sys.exit(1)


@main.command("pack", context_settings=CONTEXT_SETTINGS)
@click.argument("json_file", type=click.Path(exists=True, path_type=Path))
def validate_pack(json_file: Path):
    """Validate a language pack JSON file."""
    import json

    from .pack import REQUIRED_SECTIONS

    with open(json_file, encoding="utf-8") as f:
        data = json.load(f)

    missing = REQUIRED_SECTIONS - data.keys()
    if missing:
        click.echo(f"✗ Missing sections: {missing}", err=True)
        sys.exit(1)

    click.echo(f"✓ Pack '{data['meta']['name']}' is valid.")


@main.command(context_settings=CONTEXT_SETTINGS)
@click.argument("file", type=click.Path(exists=True, path_type=Path))
@click.option("--lang", "-l", required=True, help="Target language code (e.g. es, ta)")
@click.option("--postfix", is_flag=True, help="Use @@ postfix style for if/elif/while")
@click.option("--output", "-o", default=None, help="Output file or directory")
def decompile(file: Path, lang: str, postfix: bool, output: str | None):
    """
    Convert standard Python back to a foreign language.

    \b
    fpy decompile script.py --lang es
    fpy decompile script.py --lang ta --postfix
    fpy decompile script.py --lang es -o out/
    """
    from .transpiler import detranspile_file

    pack = _load_effective_pack(file, lang)
    result = detranspile_file(file, lang, postfix=postfix, pack=pack)

    ext = f".{lang}.py"

    if output is None:
        stem = file.stem if not file.stem.endswith(f".{lang}") else file.stem
        out_path = file.with_name(stem + ext)
    else:
        out = Path(output)
        if out.is_dir() or str(output).endswith("/"):
            out.mkdir(parents=True, exist_ok=True)
            out_path = out / (file.stem + ext)
        else:
            out_path = out

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(result, encoding="utf-8")
    click.echo(f"Decompiled: {out_path}")


def _make_scaffold_pack(lang_code: str, lang_name: str, native_name: str) -> dict:
    """
    Load template.json — single source of truth for all pack keys.
    To add new keywords/builtins, edit template.json only.
    """
    import json
    from importlib.resources import files

    template_path = files("foreignthon") / "template.json"
    pack = json.loads(template_path.read_text(encoding="utf-8"))
    pack["meta"]["name"] = lang_name
    pack["meta"]["native_name"] = native_name
    pack["meta"]["code"] = lang_code
    return pack