"""Anthropic provider examples."""
