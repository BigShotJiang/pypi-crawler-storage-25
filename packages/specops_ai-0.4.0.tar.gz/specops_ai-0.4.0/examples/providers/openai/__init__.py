"""OpenAI provider examples."""
