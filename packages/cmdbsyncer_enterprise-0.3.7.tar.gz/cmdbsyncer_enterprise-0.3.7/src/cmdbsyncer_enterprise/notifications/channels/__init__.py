"""
Channel sender implementations for Enterprise channel types.

Slack / MS Teams / generic Webhook are kept here because they are
Enterprise-only. They are wired into the OSS dispatcher at
activation time via ``register_channel_sender``.

The sub-modules import :func:`resolve_account` from the OSS helper
(``application.helpers.notification_channels``) so the same
Account-lookup path applies for community email and enterprise
channels alike.
"""
from application.helpers.notification_channels import resolve_account  # noqa: F401

from .slack import send as slack_send
from .msteams import send as msteams_send
from .webhook import send as webhook_send
