"""
Enterprise notification channels (feature: ``notifications``).

The dispatcher itself lives in OSS now. This package only adds the
Enterprise-only channel types — Slack, MS Teams and generic Webhook —
plus the matching Account plugin types so operators can configure
their endpoints in the New-Account flow.
"""
from application.helpers.plugins import register_plugin_type
from application.helpers.notification_channels import register_channel_sender
from application.models.notification_channel import register_channel_type

from .channels import slack_send, msteams_send, webhook_send

__all__ = ['register_admin_views', 'activate']


def activate():
    """Idempotent. Called on every process start."""
    register_channel_type('slack',   'Slack')
    register_channel_type('msteams', 'MS Teams')
    register_channel_type('webhook', 'Webhook')

    register_channel_sender('slack',   slack_send)
    register_channel_sender('msteams', msteams_send)
    register_channel_sender('webhook', webhook_send)

    register_plugin_type(
        'slack',
        'Slack',
        description='Notification delivery to a Slack workspace.',
        account_presets={'address': 'https://hooks.slack.com/services/...'},
        account_custom_field_presets={
            'slack_channel': '',
            'slack_mention': '',
        },
    )
    register_plugin_type(
        'msteams',
        'MS Teams',
        description='Notification delivery to a Microsoft Teams channel.',
        account_presets={'address': 'https://<tenant>.webhook.office.com/...'},
        account_custom_field_presets={},
    )
    register_plugin_type(
        'webhook',
        'Webhook',
        description=('Notification delivery to a generic HTTPS webhook. '
                     'Password is the optional HMAC-SHA256 signing secret.'),
        account_presets={'address': 'https://webhook.example.com/hook'},
        account_custom_field_presets={
            'extra_headers': '',
        },
    )


def register_admin_views(admin):
    """No-op — the rule + channel admin lives in OSS."""


activate()
