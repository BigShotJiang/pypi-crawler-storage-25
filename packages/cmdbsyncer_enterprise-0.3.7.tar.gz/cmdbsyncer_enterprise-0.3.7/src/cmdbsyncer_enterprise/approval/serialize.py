"""
Document ↔ BSON-compatible dict helpers.

The approval queue stores documents as plain dicts so MongoDB's
`replace_one` / `insert_one` can round-trip them exactly. MongoEngine's
`to_mongo()` gives us SON, which we normalise to a pure Python dict.
"""
from datetime import datetime

import bson


# Same list as the audit log — fields whose value we must never show
# in the admin diff view. The underlying payload still contains the
# real value so the change can be applied on approval.
REDACTED_FIELDS = frozenset({
    'password', 'password_crypted', 'webhook_token',
    'master_password_env', 'vault_token_env',
    'tfa_secret', 'totp_secret', 'signing_secret',
})


def _to_python(value):
    """BSON types → plain Python for Mongo-dict storage."""
    if isinstance(value, bson.ObjectId):
        return str(value)
    if isinstance(value, dict):
        return {k: _to_python(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_to_python(v) for v in value]
    if isinstance(value, datetime):
        return value
    return value


def serialize(document):
    """Dump a MongoEngine document to a plain dict (ObjectId → str)."""
    raw = document.to_mongo().to_dict()
    return _to_python(raw)


def redact_for_display(payload):
    """Return a copy of `payload` with REDACTED_FIELDS masked."""
    if not payload:
        return {}
    out = {}
    for key, value in payload.items():
        if key in REDACTED_FIELDS:
            out[key] = '***REDACTED***' if value else value
        elif isinstance(value, dict):
            out[key] = redact_for_display(value)
        else:
            out[key] = value
    return out


# Bookkeeping fields that the audit signal handler also drops so the
# approval diff matches what a normal save would produce — these flap on
# every write and add no review value.
_DIFF_IGNORED_FIELDS = frozenset({
    '_id', '_cls',
    'last_login', 'date_password',
    'last_start', 'last_ended', 'last_success_at', 'next_run',
    'is_running', 'last_message', 'all_messages', 'pid',
    'run_once_next',
})


def _redact_value(field, value):
    if field in REDACTED_FIELDS:
        return '***REDACTED***' if value else value
    return value


def diff_payloads(before, after):
    """
    Build an audit-log compatible `{field: {before, after}}` map from
    the raw before/after payloads stored on a PendingChange. Mirrors the
    shape produced by the MongoEngine audit signal so the
    Audit-Log admin renders both sources identically.
    """
    before = before or {}
    after = after or {}
    keys = (set(before) | set(after)) - _DIFF_IGNORED_FIELDS
    diff = {}
    for key in keys:
        old = before.get(key)
        new = after.get(key)
        if old == new:
            continue
        diff[key] = {
            'before': _redact_value(key, old),
            'after': _redact_value(key, new),
        }
    return diff
