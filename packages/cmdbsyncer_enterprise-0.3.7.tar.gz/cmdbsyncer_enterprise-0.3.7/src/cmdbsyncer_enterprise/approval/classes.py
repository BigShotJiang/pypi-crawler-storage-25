"""
Resource-type name → MongoEngine class map.

Used both at view-wrapping time (to know which view handles which
type) and at apply-time (to dispatch the approved payload to the
right collection). Enterprise-only classes are imported defensively
so this module loads even when a feature is not co-licensed.
"""
import logging

log = logging.getLogger(__name__)

RESOURCE_CLASSES = {}


def _try(import_path, name):
    try:
        module_path, class_name = import_path.rsplit('.', 1)
        module = __import__(module_path, fromlist=[class_name])
        RESOURCE_CLASSES[name] = getattr(module, class_name)
    except (ImportError, AttributeError) as exp:
        log.info("Approval: %s unavailable (%s)", name, exp)


# OSS models
_try('application.models.account.Account', 'Account')
_try('application.models.user.User', 'User')
_try('application.models.cron.CronGroup', 'CronGroup')
_try('application.modules.custom_attributes.models.CustomAttributeRule',
     'CustomAttributeRule')
_try('application.modules.rule.models.Rule', 'Rule')

# Enterprise-owned models
_try('cmdbsyncer_enterprise.secrets.models.SecretStore', 'SecretStore')
_try('cmdbsyncer_enterprise.secrets.models.AccountSecretBinding',
     'AccountSecretBinding')
_try('cmdbsyncer_enterprise.webhook_signatures.models.WebhookPolicy',
     'WebhookPolicy')
_try('application.models.notification_channel.NotificationChannel',
     'NotificationChannel')
_try('application.models.notification_rule.NotificationRule',
     'NotificationRule')
_try('cmdbsyncer_enterprise.backup.models.BackupConfig', 'BackupConfig')
_try('cmdbsyncer_enterprise.audit_log.siem.AuditSink', 'AuditSink')


# Views that must NEVER be gated — otherwise approving becomes
# recursive (approval queue requires approval to process) or operators
# lose the ability to configure the feature itself.
EXCLUDED_MODEL_NAMES = frozenset({
    'PendingChange', 'ApprovalPolicy', 'SelfApprovalGrant',
    'AuditEntry',  # WORM — already append-only
    'CronStats', 'BackupHistory',  # read-only system tables
    'LogEntry', 'NotificationState', 'Host',
})
