"""
Flask-Admin view interception.

At app startup we iterate `admin._views`, and for every ModelView
whose model is present in `RESOURCE_CLASSES` we wrap its
`create_model` / `update_model` / `delete_model` methods. The
wrappers check a short-TTL cache: if an `ApprovalPolicy` is
enabled for this model, the mutation is queued as a `PendingChange`
instead of being persisted.

Policies can be created/updated at runtime; the TTL cache (5s)
makes the lookup cheap without requiring a restart after policy
changes.
"""
import logging
import time
from datetime import datetime

from flask import flash, g, request
from flask_admin.model.template import BaseListRowAction
from flask_login import current_user
from markupsafe import Markup
from mongoengine.errors import DoesNotExist

from application.helpers.audit import audit

from .classes import RESOURCE_CLASSES, EXCLUDED_MODEL_NAMES
from .models import ApprovalPolicy, PendingChange
from .serialize import serialize

log = logging.getLogger(__name__)

_CACHE_TTL = 5
_gated_cache = {}  # model_name -> (timestamp, bool)


def _is_gated(model_name):
    now = time.time()
    cached = _gated_cache.get(model_name)
    if cached and cached[0] > now - _CACHE_TTL:
        return cached[1]
    try:
        ApprovalPolicy.objects.get(resource_type=model_name, enabled=True)
        value = True
    except DoesNotExist:
        value = False
    _gated_cache[model_name] = (now, value)
    return value


def _current_user_tuple():
    try:
        if current_user and current_user.is_authenticated:
            return (str(current_user.id),
                    current_user.email or current_user.name or 'unknown')
    except Exception:  # pylint: disable=broad-exception-caught
        pass
    return (None, 'system')


def _emit_submitted(pc):
    uid, uname = _current_user_tuple()
    # The audit entry records the *queueing*, not the actual resource
    # mutation — the mutation only happens once a different admin
    # clicks Approve. We spell that out in the `message` so log
    # readers don't misread the `success` outcome as "the resource
    # was changed".
    audit('approval.submitted',
          actor_type='user', actor_id=uid, actor_name=uname,
          target_type=pc.resource_type,
          target_id=pc.resource_id, target_name=pc.resource_name,
          message=(f'Queued for approval — {pc.resource_type} '
                   f'`{pc.resource_name}` is NOT yet modified '
                   f'(pending #{pc.id}).'),
          metadata={'operation': pc.operation,
                    'stage': 'queued',
                    'pending_change_id': str(pc.id)})


def _queue_create(model_class, form):
    temp = model_class()
    form.populate_obj(temp)
    uid, uname = _current_user_tuple()
    pc = PendingChange(
        resource_type=model_class.__name__,
        resource_id=None,
        resource_name=str(temp) or None,
        operation='create',
        before_payload={},
        after_payload=serialize(temp),
        requester_id=uid, requester_name=uname,
        submitted_at=datetime.utcnow(),
    )
    pc.save()
    _emit_submitted(pc)
    flash('Change submitted for approval — another admin must approve '
          'it before it takes effect.', 'info')
    # Return the unsaved instance so Flask-Admin's create_view treats
    # this as success and redirects instead of re-rendering the form.
    return temp


def _queue_update(model_class, form, existing):
    before = serialize(existing)
    # Populate a *cloned* instance so the live DB object stays
    # untouched — `form.populate_obj` mutates in place.
    clone_data = existing.to_mongo().to_dict()
    clone = model_class._from_son(clone_data)  # pylint: disable=protected-access
    form.populate_obj(clone)
    after = serialize(clone)

    uid, uname = _current_user_tuple()
    pc = PendingChange(
        resource_type=model_class.__name__,
        resource_id=str(existing.id),
        resource_name=str(existing),
        operation='update',
        before_payload=before,
        after_payload=after,
        requester_id=uid, requester_name=uname,
        submitted_at=datetime.utcnow(),
    )
    pc.save()
    _emit_submitted(pc)
    flash('Change submitted for approval — the original record is '
          'unchanged until a second admin approves.', 'info')
    return True


def _queue_delete(model_class, existing):
    uid, uname = _current_user_tuple()
    pc = PendingChange(
        resource_type=model_class.__name__,
        resource_id=str(existing.id),
        resource_name=str(existing),
        operation='delete',
        before_payload=serialize(existing),
        after_payload={},
        requester_id=uid, requester_name=uname,
        submitted_at=datetime.utcnow(),
    )
    pc.save()
    _emit_submitted(pc)
    flash('Deletion submitted for approval — the record stays in place '
          'until a second admin approves.', 'info')
    return True


def _flash_pending_for_record(model_class, record_id):
    """
    If an unresolved pending change exists for this exact record, surface
    it as a warning flash. Operators opening the edit form are otherwise
    blind to in-flight approvals — they would either re-submit the same
    edit (dup queue entry) or wonder why their last save "didn't take".
    """
    if not record_id:
        return
    if isinstance(record_id, (list, tuple)):
        record_id = record_id[0] if record_id else None
        if not record_id:
            return
    try:
        pending = PendingChange.objects(
            resource_type=model_class.__name__,
            resource_id=str(record_id),
            status='pending',
        ).order_by('-submitted_at').first()
    except Exception:  # pylint: disable=broad-exception-caught
        return
    if not pending:
        return
    when = (pending.submitted_at.strftime('%Y-%m-%d %H:%M UTC')
            if pending.submitted_at else '?')
    flash(
        f'Pending approval: {pending.operation} requested by '
        f'{pending.requester_name or "?"} at {when}. The record stays '
        f'unchanged until a second admin approves — see Pending Changes '
        f'(#{pending.id}).',
        'warning')


def _pending_ids_for(model_class):
    """
    Set of `resource_id` strings that currently have a pending change for
    `model_class`. Cached on `flask.g` for the duration of the request so
    a list view with N rows triggers exactly one Mongo query, not N.
    """
    cache_key = f'_approval_pending_ids_{model_class.__name__}'
    cached = getattr(g, cache_key, None)
    if cached is not None:
        return cached
    try:
        ids = {pc.resource_id for pc in PendingChange.objects(
            resource_type=model_class.__name__,
            status='pending',
        ).only('resource_id') if pc.resource_id}
    except Exception:  # pylint: disable=broad-exception-caught
        ids = set()
    setattr(g, cache_key, ids)
    return ids


class _PendingApprovalRowAction(BaseListRowAction):
    """
    Adds a small "pending" badge to rows whose record has an open
    PendingChange. Renders empty for rows that don't, so existing list
    layouts stay unchanged.
    """
    def __init__(self, model_class):
        super().__init__(title='Pending approval')
        self.model_class = model_class

    def render(self, context, row_id, row):
        if str(row_id) not in _pending_ids_for(self.model_class):
            return Markup('')
        return Markup(
            '<span title="Pending approval — record unchanged until '
            'a second admin approves" '
            'style="background:#f0ad4e;color:#fff;padding:2px 6px;'
            'border-radius:3px;font-size:11px;white-space:nowrap;">'
            '<i class="fa fa-clock-o"></i> pending</span>'
        )


def _patch_view(view, model_class):
    """Wrap a single Flask-Admin view's CRUD methods."""
    name = model_class.__name__
    original_create = view.create_model
    original_update = view.update_model
    original_delete = view.delete_model
    original_on_form_prefill = view.on_form_prefill
    original_edit_view = view.edit_view

    def create_model(form):
        if not _is_gated(name):
            return original_create(form)
        try:
            return _queue_create(model_class, form)
        except Exception as exp:  # pylint: disable=broad-exception-caught
            log.exception("Approval: queue_create failed for %s", name)
            flash(f'Could not queue change: {exp}', 'error')
            return False

    def update_model(form, model):
        if not _is_gated(name):
            return original_update(form, model)
        try:
            return _queue_update(model_class, form, model)
        except Exception as exp:  # pylint: disable=broad-exception-caught
            log.exception("Approval: queue_update failed for %s", name)
            flash(f'Could not queue change: {exp}', 'error')
            return False

    def delete_model(model):
        if not _is_gated(name):
            return original_delete(model)
        try:
            return _queue_delete(model_class, model)
        except Exception as exp:  # pylint: disable=broad-exception-caught
            log.exception("Approval: queue_delete failed for %s", name)
            flash(f'Could not queue deletion: {exp}', 'error')
            return False

    def on_form_prefill(form, id):  # pylint: disable=redefined-builtin
        # Cheap to query — runs only when an admin opens an edit form.
        # Flashed regardless of policy state so a stale pending entry
        # remains visible even after the policy gate is disabled.
        _flash_pending_for_record(model_class, id)
        return original_on_form_prefill(form, id)

    def edit_view():
        # Belt-and-braces: some custom subclasses override edit_view
        # without calling on_form_prefill. Flashing here guarantees the
        # banner shows up on any GET.
        if request.method == 'GET':
            _flash_pending_for_record(model_class, request.args.get('id'))
        return original_edit_view()

    view.create_model = create_model
    view.update_model = update_model
    view.delete_model = delete_model
    view.on_form_prefill = on_form_prefill
    view.edit_view = edit_view

    # Append the pending badge without clobbering existing row actions
    # (e.g. DefaultModelView's clone link).
    extras = list(view.column_extra_row_actions or [])
    extras.append(_PendingApprovalRowAction(model_class))
    view.column_extra_row_actions = extras


def wrap_admin_views(admin):
    """Install the interception on every tracked ModelView."""
    wrapped = 0
    for view in admin._views:  # pylint: disable=protected-access
        model = getattr(view, 'model', None)
        if model is None:
            continue
        name = model.__name__
        if name in EXCLUDED_MODEL_NAMES:
            continue
        if name not in RESOURCE_CLASSES:
            # Model isn't on the gated list at all — skip to keep the
            # no-policy path identical to the unwrapped one.
            continue
        _patch_view(view, model)
        wrapped += 1
    log.info("Approval: wrapped %d admin view(s)", wrapped)
