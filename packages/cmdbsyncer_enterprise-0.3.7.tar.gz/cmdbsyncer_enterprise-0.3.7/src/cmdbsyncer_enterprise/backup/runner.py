"""
Backup execution.

Produces `<bucket>/<prefix><config_name>/<ts>.gz[.gpg]` (S3) or
`<local_path>/<config_name>/<ts>.gz[.gpg]` (filesystem) by piping:

    mongodump --archive → gzip → [gpg --encrypt]  → destination

`mongodump` is spawned as a subprocess; its stdout is streamed through
the transforms so a 10 GB dump doesn't need 10 GB of disk scratch
space. For S3, boto3's multi-part uploader handles the chunking
transparently; for local destinations the stream is copied straight
into a file on disk (which works equally well against a CIFS/NFS mount
point — mount the share at the OS level, point `local_path` at it).

Restore walks the same pipeline in reverse:

    destination read → [gpg --decrypt] → gunzip → mongorestore --archive
"""
import logging
import os
import shlex
import shutil
import subprocess
import tempfile
import time
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse

from flask import current_app

from application.helpers.get_account import (
    AccountNotFoundError,
    get_account_by_name,
)

from application.helpers.audit import audit

from .models import BackupConfig, BackupHistory

log = logging.getLogger(__name__)


def _mongo_uri_parts():
    """Extract host/port/db/user/password from the OSS mongo URI."""
    uri = current_app.config.get('MONGODB_HOST') \
        or current_app.config.get('MONGODB_SETTINGS', {}).get('host') \
        or 'mongodb://localhost:27017/cmdbsyncer'
    parsed = urlparse(uri)
    return {
        'host': parsed.hostname or 'localhost',
        'port': parsed.port or 27017,
        'db': (parsed.path or '/').lstrip('/') or 'cmdbsyncer',
        'user': parsed.username,
        'password': parsed.password,
    }


def _mongodump_cmd():
    binary = shutil.which('mongodump')
    if not binary:
        raise RuntimeError(
            "mongodump not found on PATH — install the mongodb-database-tools "
            "package on the syncer host"
        )
    parts = _mongo_uri_parts()
    cmd = [binary, '--host', parts['host'], '--port', str(parts['port']),
           '--db', parts['db'], '--archive', '--quiet']
    if parts['user']:
        cmd.extend(['--username', parts['user']])
    if parts['password']:
        cmd.extend(['--password', parts['password']])
    return cmd


def _s3_client(config):
    try:
        import boto3  # pylint: disable=import-outside-toplevel
    except ImportError as exp:
        raise RuntimeError(
            "boto3 is required for the scheduled_backup feature. "
            "Install with `pip install 'cmdbsyncer-enterprise[backup]'`."
        ) from exp

    kwargs = {}
    account = None
    if account_name := (config.account or '').strip():
        try:
            account = get_account_by_name(account_name)
        except AccountNotFoundError as exc:
            raise RuntimeError(
                f"Backup {config.name!r}: Account {account_name!r} "
                f"not found or disabled"
            ) from exc
    if account:
        if endpoint := (account.get('address') or '').strip():
            kwargs['endpoint_url'] = endpoint
        if region := (account.get('region') or '').strip():
            kwargs['region_name'] = region
        ak = (account.get('username') or '').strip()
        sk = account.get('password') or ''
        if ak and sk:
            kwargs['aws_access_key_id'] = ak
            kwargs['aws_secret_access_key'] = sk
        elif ak or sk:
            raise RuntimeError(
                f"Backup {config.name!r}: Account {account_name!r} "
                f"must set both username (access key) and password "
                f"(secret key), or leave both blank for the default "
                f"AWS credential chain"
            )
    return boto3.client('s3', **kwargs)


def _gpg_encrypt_pipe(recipient):
    """Return a subprocess.Popen piping gpg --encrypt."""
    binary = shutil.which('gpg') or shutil.which('gpg2')
    if not binary:
        raise RuntimeError("gpg binary not found — install GnuPG on the host")
    return subprocess.Popen(  # noqa: S603
        [binary, '--batch', '--yes', '--trust-model', 'always',
         '--encrypt', '--recipient', recipient, '--output', '-'],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE,
    )


def _build_pipeline(config):
    """
    Chain mongodump → gzip → [gpg] and return (start_proc, final_proc,
    suffix). The caller reads final_proc.stdout and uploads to S3.
    """
    dump = subprocess.Popen(_mongodump_cmd(),  # noqa: S603
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    procs = [dump]
    stream = dump.stdout
    suffix_parts = []

    if config.compression == 'gzip':
        gzip_proc = subprocess.Popen(  # noqa: S603
            ['gzip', '-c'], stdin=stream, stdout=subprocess.PIPE,
        )
        procs.append(gzip_proc)
        stream = gzip_proc.stdout
        suffix_parts.append('gz')

    if config.encryption == 'gpg':
        if not (config.gpg_recipient or '').strip():
            raise RuntimeError("encryption=gpg requires gpg_recipient")
        gpg_proc = _gpg_encrypt_pipe(config.gpg_recipient.strip())
        # Relay: read from `stream`, write to gpg.stdin, collect from gpg.stdout
        # Simplest portable approach: spawn a relay thread.
        import threading  # pylint: disable=import-outside-toplevel

        def _relay(src, dst):
            try:
                shutil.copyfileobj(src, dst)
            finally:
                dst.close()

        threading.Thread(
            target=_relay, args=(stream, gpg_proc.stdin), daemon=True,
        ).start()
        procs.append(gpg_proc)
        stream = gpg_proc.stdout
        suffix_parts.append('gpg')

    suffix = '.'.join(suffix_parts) if suffix_parts else 'bson'
    return procs, stream, suffix


def _prune_old_s3(config, s3):
    """Delete S3 backups older than `retention_days` from the bucket prefix."""
    if not config.retention_days or config.retention_days <= 0:
        return 0
    cutoff = datetime.now(timezone.utc) - timedelta(days=config.retention_days)
    prefix = f"{(config.prefix or '').rstrip('/')}/{config.name}/"
    paginator = s3.get_paginator('list_objects_v2')
    to_delete = []
    for page in paginator.paginate(Bucket=config.bucket, Prefix=prefix):
        for obj in page.get('Contents', []):
            if obj['LastModified'] < cutoff:
                to_delete.append({'Key': obj['Key']})
    # S3 delete_objects is batched to max 1000 at a time.
    deleted = 0
    for i in range(0, len(to_delete), 1000):
        batch = to_delete[i:i + 1000]
        s3.delete_objects(Bucket=config.bucket, Delete={'Objects': batch})
        deleted += len(batch)
    return deleted


def _local_dir(config):
    """Resolve and validate the per-config target directory."""
    base = (config.local_path or '').strip()
    if not base:
        raise RuntimeError(
            "destination_type=local requires local_path to be set"
        )
    if not os.path.isabs(base):
        raise RuntimeError(
            f"local_path must be absolute, got {base!r}"
        )
    target = os.path.join(base, config.name)
    os.makedirs(target, exist_ok=True)
    return target


def _prune_old_local(config):
    """Delete filesystem backups older than `retention_days` in local_path."""
    if not config.retention_days or config.retention_days <= 0:
        return 0
    cutoff = time.time() - config.retention_days * 86400
    target = _local_dir(config)
    deleted = 0
    for name in os.listdir(target):
        path = os.path.join(target, name)
        try:
            if os.path.isfile(path) and os.path.getmtime(path) < cutoff:
                os.unlink(path)
                deleted += 1
        except OSError:
            # Best-effort prune: a missing file / permission denied
            # shouldn't crash the backup that just succeeded.
            continue
    return deleted


def _wait_pipeline(procs):
    """Wait for every subprocess in the pipeline and raise on non-zero exit."""
    for proc in procs:
        proc.wait(timeout=60)
        if proc.returncode != 0:
            stderr = (proc.stderr.read().decode('utf-8', 'replace')
                      if proc.stderr else '')
            raise RuntimeError(
                f"Backup pipeline stage {shlex.join(proc.args)!s} "
                f"exited {proc.returncode}: {stderr.strip()}"
            )


def _write_local(config, stream, filename):
    """Stream the archive into local_path/<name>/<filename>; return (full_path, size)."""
    target_dir = _local_dir(config)
    full_path = os.path.join(target_dir, filename)
    # Write to a .tmp sibling so a crash mid-backup doesn't leave a
    # half-written file that retention treats as a real backup.
    tmp_path = full_path + '.tmp'
    try:
        with open(tmp_path, 'wb') as dest:
            shutil.copyfileobj(stream, dest, length=1024 * 1024)
        os.replace(tmp_path, full_path)
    except BaseException:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise
    return full_path, os.path.getsize(full_path)


def run_backup(config_name):
    """Execute a backup for the named config. Raises on any failure."""
    config = BackupConfig.objects.get(name=config_name, enabled=True)

    history = BackupHistory(
        config_name=config.name,
        started_at=datetime.now(timezone.utc),
        status='running',
    )
    history.save()

    t0 = time.time()
    destination_type = config.destination_type or 's3'
    try:
        procs, stream, suffix = _build_pipeline(config)

        ts = history.started_at.strftime('%Y%m%dT%H%M%SZ')
        filename = f"{ts}.{suffix}"

        if destination_type == 'local':
            full_path, size_bytes = _write_local(config, stream, filename)
            _wait_pipeline(procs)

            history.object_key = full_path
            history.size_bytes = size_bytes
            pruned = _prune_old_local(config)
            notification_message = (
                f"Wrote {full_path} ({size_bytes} bytes, "
                f"{round(time.time() - t0, 2)}s). "
                f"Pruned {pruned} old file(s)."
            )
        else:
            key = (f"{(config.prefix or '').rstrip('/')}/{config.name}/"
                   f"{filename}")
            s3 = _s3_client(config)

            extra = {}
            if config.s3_sse:
                extra['ServerSideEncryption'] = config.s3_sse

            s3.upload_fileobj(stream, config.bucket, key, ExtraArgs=extra)
            _wait_pipeline(procs)

            head = s3.head_object(Bucket=config.bucket, Key=key)
            history.object_key = key
            history.size_bytes = head.get('ContentLength') or 0
            pruned = _prune_old_s3(config, s3)
            notification_message = (
                f"Uploaded s3://{config.bucket}/{key} "
                f"({history.size_bytes} bytes, "
                f"{round(time.time() - t0, 2)}s). "
                f"Pruned {pruned} old object(s)."
            )

        history.status = 'success'
        history.ended_at = datetime.now(timezone.utc)
        history.duration_seconds = round(time.time() - t0, 2)
        history.save()

        audit('backup.succeeded',
              target_type='BackupConfig',
              target_id=str(config.id),
              target_name=config.name,
              message=notification_message,
              metadata={'key': history.object_key,
                        'destination': destination_type,
                        'size': history.size_bytes,
                        'duration_s': history.duration_seconds,
                        'pruned': pruned})
    except Exception as exp:  # pylint: disable=broad-exception-caught
        history.status = 'failure'
        history.error = str(exp)
        history.ended_at = datetime.now(timezone.utc)
        history.duration_seconds = round(time.time() - t0, 2)
        history.save()
        audit('backup.failed', outcome='failure',
              target_type='BackupConfig',
              target_id=str(config.id),
              target_name=config.name,
              message=f"Backup {config.name} failed: {exp}",
              metadata={'error': str(exp)})
        raise


def list_backups(config_name):
    """Enumerate backups at the configured destination, newest first."""
    config = BackupConfig.objects.get(name=config_name)
    out = []
    if (config.destination_type or 's3') == 'local':
        target = _local_dir(config)
        for name in os.listdir(target):
            path = os.path.join(target, name)
            if not os.path.isfile(path) or name.endswith('.tmp'):
                continue
            stat = os.stat(path)
            out.append({
                'key': path,
                'size': stat.st_size,
                'last_modified': datetime.fromtimestamp(
                    stat.st_mtime, tz=timezone.utc,
                ).isoformat(),
            })
        out.sort(key=lambda r: r['last_modified'], reverse=True)
        return out

    s3 = _s3_client(config)
    prefix = f"{(config.prefix or '').rstrip('/')}/{config.name}/"
    paginator = s3.get_paginator('list_objects_v2')
    for page in paginator.paginate(Bucket=config.bucket, Prefix=prefix):
        for obj in page.get('Contents', []):
            out.append({'key': obj['Key'],
                        'size': obj['Size'],
                        'last_modified': obj['LastModified'].isoformat()})
    return out


def restore_backup(config_name, object_key):
    """
    Download and mongorestore one object. Pipe sequence:
        destination read → [gpg --decrypt] → gunzip → mongorestore --archive
    Destination database comes from the OSS mongo config — operators
    should point the syncer at a scratch DB before restoring a snapshot
    from another install.

    For destination_type='local', `object_key` is the absolute path to
    the archive file inside the configured local_path tree.
    """
    config = BackupConfig.objects.get(name=config_name)
    destination_type = config.destination_type or 's3'

    if destination_type == 'local':
        if not os.path.isfile(object_key):
            raise RuntimeError(f"Backup file not found: {object_key!r}")
        # Copy to a working tempfile — the restore pipeline mutates
        # (decrypt / gunzip) the input file in place.
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            with open(object_key, 'rb') as src:
                shutil.copyfileobj(src, tmp, length=1024 * 1024)
            local_path = tmp.name
    else:
        s3 = _s3_client(config)
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            s3.download_fileobj(config.bucket, object_key, tmp)
            local_path = tmp.name

    try:
        source = local_path
        if object_key.endswith('.gpg'):
            binary = shutil.which('gpg') or shutil.which('gpg2')
            if not binary:
                raise RuntimeError("gpg binary missing for decrypt")
            decrypted = local_path + '.dec'
            subprocess.check_call(  # noqa: S603
                [binary, '--batch', '--yes', '--decrypt',
                 '--output', decrypted, source],
            )
            source = decrypted

        if source.endswith('.gz') or object_key.endswith('.gz'):
            gunzipped = source.rsplit('.', 1)[0] + '.bson'
            with open(source, 'rb') as fin, open(gunzipped, 'wb') as fout:
                subprocess.check_call(['gunzip', '-c'],  # noqa: S603
                                      stdin=fin, stdout=fout)
            source = gunzipped

        binary = shutil.which('mongorestore')
        if not binary:
            raise RuntimeError("mongorestore not found on PATH")
        parts = _mongo_uri_parts()
        cmd = [binary, '--host', parts['host'], '--port', str(parts['port']),
               '--archive=' + source, '--drop']
        if parts['user']:
            cmd.extend(['--username', parts['user']])
        if parts['password']:
            cmd.extend(['--password', parts['password']])
        subprocess.check_call(cmd)  # noqa: S603

        audit('backup.restored',
              target_type='BackupConfig',
              target_id=str(config.id),
              target_name=config.name,
              metadata={'key': object_key})
    finally:
        try:
            os.unlink(local_path)
        except OSError:
            pass
