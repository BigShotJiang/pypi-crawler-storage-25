# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Device Power Default Capability."""

import time
import typing
from typing import Any, Callable, Optional, Union

from gazoo_device import decorators
from gazoo_device import errors
from gazoo_device import gdm_logger
from gazoo_device.auxiliary_devices import cambrionix
from gazoo_device.auxiliary_devices import dli_powerswitch
from gazoo_device.auxiliary_devices import dlink_switch
from gazoo_device.auxiliary_devices import unifi_poe_switch
from gazoo_device.capabilities.interfaces import device_power_base
from gazoo_device.capabilities.interfaces import switchboard_base
from gazoo_device.utility import deprecation_utils
import immutabledict

_PowerHubDevice = Union[cambrionix.Cambrionix,
                        dli_powerswitch.DliPowerSwitch,
                        dlink_switch.DLinkSwitch,
                        unifi_poe_switch.UnifiPoeSwitch]

logger = gdm_logger.get_logger()

_HUB_TYPE_PROPERTY = "device_power_hub_type"
_HUB_TYPE_CAMBRIONIX = "cambrionix"
_HUB_TYPE_POWERSWITCH = "powerswitch"
_HUB_TYPE_UNIFI_SWITCH = "unifi_switch"

SUPPORTED_HUB_TYPES = (
    _HUB_TYPE_CAMBRIONIX,
    _HUB_TYPE_POWERSWITCH,
    _HUB_TYPE_UNIFI_SWITCH,
)

_HUB_TYPE_PROPS = immutabledict.immutabledict({
    _HUB_TYPE_CAMBRIONIX: ("device_usb_hub_name", "device_usb_port"),
    _HUB_TYPE_POWERSWITCH: ("powerswitch_name", "powerswitch_port"),
    _HUB_TYPE_UNIFI_SWITCH: ("unifi_switch_name", "unifi_switch_port"),
})


class DevicePowerDefault(device_power_base.DevicePowerBase):
  """Base class for device_power."""

  def __init__(
      self,
      device_name: str,
      get_manager: Callable[[], Any],
      default_hub_type: str,
      props: dict[str, Any],
      usb_ports_discovered: bool,
      wait_until_connected_fn: Callable[[], None],
      wait_for_bootup_complete_fn: Callable[[], None],
      get_switchboard_if_initialized:
      Callable[[], Optional[switchboard_base.SwitchboardBase]],
      change_triggers_reboot: bool = False,
      usb_hub_name_prop: str = "device_usb_hub_name",
      usb_port_prop: str = "device_usb_port",
  ):
    """Create an instance of the device_power capability.

    The power switch type can be changed by setting the 'device_power_hub_type'
    property. The valid hub types are 'cambrionix', 'powerswitch', and
    'unifi_switch'.

    Each hub type also requires a corresponding hub_name and hub_port property
    to be set.

    Cambrionix requires 'device_usb_hub_name' and 'device_usb_port' to be set.
      (These names can be changed by passing in the different property names)

    Powerswitch requires 'powerswitch_name' and 'powerswitch_port' to be set.

    Unifi_switch requires 'unifi_switch_name' and 'unifi_switch_port' to be set.

    Args:
      device_name: Name of the device this capability is attached to.
      get_manager: The "get_manager" method of a device instance.
      default_hub_type: Type of switch for power cycling.
      props: Dictionary of device props from configuration file.
      usb_ports_discovered: True if the USB ports are discovered by gdm detect.
      wait_until_connected_fn: a method to wait for the device to become
        reachable.
      wait_for_bootup_complete_fn: A method that the capability can call to wait
        for a reboot to complete if triggered by a change.
      get_switchboard_if_initialized: Method which returns a Switchboard
        capability instance if it's already initialized or None otherwise.
      change_triggers_reboot: Set change_triggers_reboot to TRUE if changing the
        power mode for the device causes a reboot.
      usb_hub_name_prop: Name of the hub name property.
      usb_port_prop: Name of the hub port property.

    Raises:
      ValueError: If hub type is not a known type.
    """
    super().__init__(device_name=device_name)

    self._hub = None
    self._usb_ports_discovered = usb_ports_discovered
    self._props = props
    hub_type = self._props["optional"].get(_HUB_TYPE_PROPERTY, default_hub_type)
    if hub_type not in SUPPORTED_HUB_TYPES:
      raise ValueError("Hub type {} is not supported. Valid types: {}".format(
          hub_type, SUPPORTED_HUB_TYPES))
    self._hub_type = hub_type
    self._hub_name_prop, self._port_prop = _HUB_TYPE_PROPS[self._hub_type]
    if self._hub_type == _HUB_TYPE_CAMBRIONIX:
      self._hub_name_prop = usb_hub_name_prop
      self._port_prop = usb_port_prop

    # Set where the hub/port propeties are in _props.
    if self._hub_type == _HUB_TYPE_CAMBRIONIX and self._usb_ports_discovered:
      self._dict_name = "persistent_identifiers"
    else:
      self._dict_name = "optional"

    self._wait_for_bootup_complete_fn = wait_for_bootup_complete_fn
    self._get_switchboard_if_initialized = get_switchboard_if_initialized
    self._change_triggers_reboot = change_triggers_reboot
    self._wait_until_connected_fn = wait_until_connected_fn
    self._get_manager = get_manager

  @classmethod
  def get_used_device_classes(cls) -> set[type[Any]]:
    """Returns all device classes this capability can create through Manager."""
    return set(typing.get_args(_PowerHubDevice))

  @decorators.CapabilityLogDecorator(logger, level=decorators.DEBUG)
  def health_check(self):
    """Checks that the capability is ready to use.

    Raises:
      CapabilityNotReadyError: If expected properties are not set or
        unable to create auxiliary device for power switching.
    """
    unset_props = []
    if self.hub_name is None:
      unset_props.append(self._hub_name_prop)
    if self.port_number is None:
      unset_props.append(self._port_prop)
    if unset_props:
      if self._hub_type == _HUB_TYPE_CAMBRIONIX and self._usb_ports_discovered:
        msg_format = ("If device is connected to {}, "
                      "set them via 'gdm redetect {}'")
      else:
        msg_format = ("If device is connected to {}, "
                      "set them via 'gdm set-prop {} <property> <value>'")
      if not self._props["optional"].get(_HUB_TYPE_PROPERTY):
        msg_format += (
            f"Note that {_HUB_TYPE_PROPERTY} is not set and currently"
            f" fallbacking to {self._hub_type}. If you're actually connected"
            " device to a different power hub, please set"
            f" {_HUB_TYPE_PROPERTY} to the correct value. Check"
            " https://github.com/google/gazoo-device/blob/master/gazoo_device/gazoo/tests/matter/docs/setup/testbed.md#set-device-power-hub-and-ports"
            " for more details."
        )
      msg = msg_format.format(self._hub_type, self._device_name)
      error_msg = "properties {} are unset. ".format(
          " and ".join(unset_props)) + msg
      raise errors.CapabilityNotReadyError(
          msg=error_msg, device_name=self._device_name)
    try:
      self._hub = typing.cast(_PowerHubDevice,
                              self._get_manager().create_device(self.hub_name))
    except errors.DeviceError as err:
      raise errors.CapabilityNotReadyError(
          msg=str(err), device_name=self._device_name)
    self._healthy = True

  @decorators.CapabilityLogDecorator(logger, level=decorators.DEBUG)
  def close(self):
    """Closes the hub device instance."""
    if self._hub:
      self._hub.close()
    super().close()

  def _get_prop(self, prop_name: str) -> Any:
    """Retrieves a property, falling back to persistent if empty."""
    if (val := self._props["optional"].get(prop_name)) is not None and val != "":  # pylint: disable=g-explicit-bool-comparison
      return val
    return self._props["persistent_identifiers"].get(prop_name)

  @decorators.OptionalProperty
  def hub_name(self):
    """Name of the hub the device is attached to."""
    return self._get_prop(self._hub_name_prop)

  @decorators.OptionalProperty
  def hub_type(self):
    """Device type of the hub."""
    return self._hub_type

  @decorators.DynamicProperty
  def port_mode(self):
    """port mode."""
    if not self.healthy:
      self.health_check()
    return self._hub.switch_power.get_mode(self.port_number)

  @decorators.OptionalProperty
  def port_number(self):
    """Port number the device is attached to."""
    port_number = self._get_prop(self._port_prop)
    if port_number is not None:
      return int(port_number)
    return None

  @decorators.CapabilityLogDecorator(logger)
  def cycle(self, no_wait=False, sleep_time=2):
    """Power off then power on the device.

    Args:
        no_wait (bool):  Return before verifying boot up.
        sleep_time (float): Time in secs to completely power off device.
    """
    if not self.healthy:
      self.health_check()
    self.off()
    time.sleep(sleep_time)  # Small delay before calling power_on.
    self.on(no_wait=no_wait)

  @decorators.CapabilityLogDecorator(logger)
  def off(self, close_transports=True):
    """Turn off power to the device.

    Args:
      close_transports (bool): Whether to close transports when powering off.
    """
    if not self.healthy:
      self.health_check()
    # No-op if port is already off.
    status = self._hub.switch_power.get_mode(self.port_number)
    if status == "off":
      return
    switchboard = self._get_switchboard_if_initialized()
    if self._change_triggers_reboot:
      if (switchboard is not None and
          switchboard.health_checked and
          switchboard.healthy):
        switchboard.add_log_note(
            f"GDM triggered reboot via {self.hub_type} power change.")
      self._hub.switch_power.power_off(self.port_number)
      self._wait_for_bootup_complete_fn()
    else:
      if (close_transports and
          switchboard is not None and
          switchboard.health_checked and
          switchboard.healthy):
        switchboard.close_all_transports()
      self._hub.switch_power.power_off(self.port_number)

  @decorators.CapabilityLogDecorator(logger)
  def on(self, no_wait=False):
    """Turn on power to the device.

    If Switchboard hasn't been initialized then transports won't be opened
    and GDM triggered reboot won't be logged to avoid initializing the
    switchboard. Note that if no_wait=False then Switchboard will be initialized
    at the end.

    Args:
        no_wait (bool): Return without verifying boot up and reopening
            communication transports.
    """
    if not self.healthy:
      self.health_check()
    # No-op if port is already on.
    status = self._hub.switch_power.get_mode(self.port_number)
    if status in ["sync", "charge", "on"]:
      return

    switchboard = self._get_switchboard_if_initialized()
    if self._change_triggers_reboot:
      if (switchboard is not None and
          switchboard.health_checked and
          switchboard.healthy):
        switchboard.add_log_note(
            f"GDM triggered reboot via {self.hub_type} power change.")
    self._hub.switch_power.power_on(self.port_number)

    if not no_wait:
      self._wait_until_connected_fn()
      # If 'change_triggers_reboot' is True, we didn't close transports during
      # device_power.off(), so they're already open.
      if (not self._change_triggers_reboot and
          switchboard is not None and
          switchboard.health_checked and
          switchboard.healthy):
        switchboard.open_all_transports()
      self._wait_for_bootup_complete_fn()


deprecation_utils.add_deprecated_attributes(DevicePowerDefault,
                                            [("power_off", "off", True),
                                             ("power_on", "on", True),
                                             ("power_cycle", "cycle", True)])
