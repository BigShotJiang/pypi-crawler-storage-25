"""
Subprocess tests for the console CLI.

Set the CONSOLE_PATH environment variable to the path of the console executable
(or a test wrapper) to enable the integration-style tests. If CONSOLE_PATH is
not set, only --version and help-related tests run (no external side effects).
"""

import os
import sys
import json
import re
import subprocess
import tempfile
import time
from pathlib import Path

import pytest
from dotenv import load_dotenv

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

repo_root = Path(__file__).resolve().parents[1]
dotenv_path = repo_root / ".env"
if dotenv_path.exists():
    load_dotenv(dotenv_path)

# Path to console executable/script. Prefer env var for test harnesses.
CONSOLE_PATH = os.environ.get("CONSOLE_PATH")

DEFAULT_NUMBER_OF_PROCESSES = 64
CASES_PATH = os.path.abspath(".\\tests\\cases")
TEST_TIMEOUT = int(os.environ.get("TEST_TIMEOUT_SECONDS", "600"))  # seconds
CLUSTER = os.environ.get("PSRCLOUD_TEST_CLUSTER", "Internal")

# Enable passing --debug to every console invocation when TEST_DEBUG env var is truthy
TEST_DEBUG = os.environ.get("TEST_DEBUG", "").lower() in ("1", "true", "yes")


def _base_cmd():
    if CONSOLE_PATH.lower().endswith(".py"):
        return [sys.executable, CONSOLE_PATH]
    return [CONSOLE_PATH]


def _run_console(args):
    args = list(args)
    if TEST_DEBUG and "--debug" not in args:
        args.append("--debug")
    cmd = _base_cmd() + args
    return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)


def test_version_prints_and_exits_ok():
    res = _run_console(["--version"])
    assert res.returncode == 0
    output = (res.stdout or res.stderr or "").strip()
    assert output, "version output should not be empty"


def test_no_args_shows_usage_and_exits_nonzero():
    res = _run_console([])
    assert res.returncode != 0
    out = (res.stdout + res.stderr).lower()
    assert "usage" in out or "psrcloudconsole" in out


@pytest.mark.skipif("CONSOLE_PATH" not in os.environ, reason="requires CONSOLE_PATH to run external CLI")
def test_jsonfile_parsing_triggers_auth(tmp_path):
    # Write a params file that dispatches to 'auth' (safe command)
    params = {"command": "auth"}
    p = tmp_path / "params.json"
    p.write_text(json.dumps(params), encoding="utf-8")

    res = _run_console(["jsonfile", str(p)])
    assert res.returncode == 0


@pytest.mark.skipif("CONSOLE_PATH" not in os.environ, reason="requires CONSOLE_PATH to run external CLI")
def test_run_missing_required_args_exits_nonzero(tmp_path):
    # A JSON with 'run' but missing required flags should make the CLI exit nonzero
    params = {"command": "run", "case-path": "/tmp/incomplete"}
    p = tmp_path / "params_run.json"
    p.write_text(json.dumps(params), encoding="utf-8")

    res = _run_console(["jsonfile", str(p)])
    assert res.returncode != 0
    out = (res.stdout + res.stderr).lower()
    assert "error" in out or "the following arguments are required" in out

@pytest.mark.skipif("CONSOLE_PATH" not in os.environ, reason="requires CONSOLE_PATH to run external CLI")
def test_sddp_platform_console():
    case_name = "test_sddp18"
    data_path = os.path.join(CASES_PATH, "sddp-platform_sddp")
    argv = [
        "run",
        "--case-path",
        data_path,
        "--case-name",
        case_name,
        "--cluster",
        CLUSTER,
        "--program",
        "SDDP",
        "--program-version",
        "18.0.6",
        "--execution-type",
        "Operation Planning (Default)",
        "--memory-per-process-ratio",
        "2:1",
        "--price-optimized",
        "--number-of-processes",
        str(DEFAULT_NUMBER_OF_PROCESSES),
        "--repository-duration",
        "1",
    ]

    # start run
    res = _run_console(argv)
    assert res.returncode == 0, f"run failed: {res.stdout}\n{res.stderr}"

    # try to extract case id from output (stdout or stderr)
    out = (res.stdout or "") + "\n" + (res.stderr or "")
    m = re.search(r"\b(\d{1,10})\b", out)
    assert m, f"Could not find case id in run output:\n{out}"
    case_id = int(m.group(1))

    # poll status until SUCCESS or timeout
    deadline = time.time() + TEST_TIMEOUT
    while time.time() < deadline:
        st = _run_console(["status", "--case-id", str(case_id), "--cluster", CLUSTER])
        combined = (st.stdout or "") + "\n" + (st.stderr or "")
        if re.search(r"SUCCESS", combined, re.IGNORECASE):
            return
        if re.search(r"FAILED|ERROR", combined, re.IGNORECASE):
            pytest.fail(f"Case failed according to status output:\n{combined}")
        time.sleep(5)

    pytest.fail(f"Timeout waiting for case {case_id} to reach SUCCESS (waited {TEST_TIMEOUT}s)")

if __name__ == "__main__":
    print("Running tests using console from:", CONSOLE_PATH)
    #pytest.main([__file__])