# PSR Cloud. Copyright (C) PSR, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import io
import json
import os
import sys
import tempfile
import time
import traceback
from contextlib import contextmanager
from pathlib import Path

from dotenv import load_dotenv

project_root = str(Path(__file__).resolve().parent.parent)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from psr.cloud import AWS, Case, Client, ExecutionStatus
from psr.cloud.dev import DevClient, Version

TIMEOUT_SECONDS = 60 * 40  # 40 minutes

DEFAULT_NUMBER_OF_PROCESSES = 64

DEFAULT_BUGDET = "PSRCloud - Testes"

SHARED_DIR = os.path.join(tempfile.gettempdir(), "psrcloud-tests", ".shared")

if os.path.exists(".env"):
    load_dotenv()

PSRCLOUD_TEST_CLUSTER = os.environ.get("PSRCLOUD_TEST_CLUSTER", "Staging")
PSRCLOUD_PYTHON_CLIENT = os.environ.get("PSRCLOUD_PYTHON_CLIENT", False)
PSRCLOUD_AMI_ID = os.environ.get("PSRCLOUD_AMI_ID", None)
PSRCLOUD_PRICE_OPTIMIZED = (
    os.environ.get("PSRCLOUD_PRICE_OPTIMIZED", "true").lower() == "true"
)
if PSRCLOUD_AMI_ID == "":
    PSRCLOUD_AMI_ID = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def save_shared(name, value):
    os.makedirs(SHARED_DIR, exist_ok=True)
    with open(os.path.join(SHARED_DIR, name), "w") as f:
        f.write(value)


def load_shared(name):
    with open(os.path.join(SHARED_DIR, name)) as f:
        return f.read().strip()


def create_client(pat=False, deploy=False):
    if deploy:
        return DevClient(
            cluster=PSRCLOUD_TEST_CLUSTER,
            python_client=True,
            import_desktop=False,
            test_mode=True,
            username=os.environ.get("PSR_CLOUD_USER_DEPLOY"),
            password=os.environ.get("PSR_CLOUD_PASSWORD_HASH_DEPLOY"),
            verbose=True,
        )
    elif pat and PSRCLOUD_TEST_CLUSTER == "Internal":
        return Client(
            cluster=PSRCLOUD_TEST_CLUSTER,
            python_client=PSRCLOUD_PYTHON_CLIENT,
            import_desktop=False,
            test_mode=True,
            email=os.environ.get("PSR_CLOUD_EMAIL"),
            pat=os.environ.get("PSR_CLOUD_ACCESS_TOKEN"),
            verbose=True,
        )
    else:
        return Client(
            cluster=PSRCLOUD_TEST_CLUSTER,
            python_client=PSRCLOUD_PYTHON_CLIENT,
            import_desktop=False,
            test_mode=True,
            username=os.environ.get("PSR_CLOUD_USER"),
            password=os.environ.get("PSR_CLOUD_PASSWORD_HASH"),
            verbose=True,
        )


# ---------------------------------------------------------------------------
# Independent Tests & Parents
# ---------------------------------------------------------------------------


def test_sddp_standalone():
    client = create_client()
    case = Case(
        name="test_sddp_standalone",
        data_path=AWS.download_test_case("sddp_policy.zip"),
        program="SDDP",
        program_version="17.3.7",
        execution_type="Default",
        memory_per_process_ratio="2:1",
        price_optimized=PSRCLOUD_PRICE_OPTIMIZED,
        number_of_processes=DEFAULT_NUMBER_OF_PROCESSES,
        repository_duration=1,
        ami_id=PSRCLOUD_AMI_ID,
        budget=DEFAULT_BUGDET,
    )
    case_id = client.run_case(case)
    status = client._check_until_status(
        case_id, ExecutionStatus.SUCCESS, timeout=TIMEOUT_SECONDS
    )
    assert status, f"Case {case_id} failed to complete successfully"
    save_shared("sddp_standalone_case_id", str(case_id))


def test_ncp():
    client = create_client()
    case = Case(
        name="test_ncp",
        data_path=AWS.download_test_case("ncp.zip"),
        program="NCP",
        program_version="5.29",
        execution_type="Standard",
        memory_per_process_ratio="2:1",
        price_optimized=PSRCLOUD_PRICE_OPTIMIZED,
        number_of_processes=DEFAULT_NUMBER_OF_PROCESSES,
        repository_duration=1,
        ami_id=PSRCLOUD_AMI_ID,
        budget=DEFAULT_BUGDET,
    )
    case_id = client.run_case(case)
    assert client._check_until_status(
        case_id, ExecutionStatus.SUCCESS, timeout=TIMEOUT_SECONDS
    )


def test_publish_version():
    client = create_client(deploy=True)
    build_path = AWS.download_test_sddp_build()
    version_name = "test_publish_version"

    sddp_version = Version(
        model="SDDP",
        name=version_name,
        execution_types=[
            "Operation Planning",
            "Expansion Planning",
            "Reliability Analysis",
            "Maintenance Scheduling",
        ],
        execution_types_description=[
            "Operation Planning (Default)",
            "Expansion Planning",
            "Reliability Analysis",
            "Maintenance Scheduling",
        ],
        build_path=build_path,
        groups=["SDDP_DEV"],
        latest_version=False,
        build_id=os.urandom(8).hex(),
    )

    client.publish_model_version(
        sddp_version,
        cluster_list=[PSRCLOUD_TEST_CLUSTER],
    )
    save_shared("published_version_name", version_name)


def test_cancel_case():
    client = create_client(pat=True)
    case = Case(
        name="test_cancel_case",
        data_path=AWS.download_test_case("sddp_policy.zip"),
        program="SDDP",
        program_version="17.3.7",
        execution_type="Default",
        memory_per_process_ratio="2:1",
        price_optimized=PSRCLOUD_PRICE_OPTIMIZED,
        number_of_processes=DEFAULT_NUMBER_OF_PROCESSES,
        repository_duration=1,
        ami_id=PSRCLOUD_AMI_ID,
        budget=DEFAULT_BUGDET,
    )
    case_id = client.run_case(case)
    assert client._check_until_status(
        case_id, ExecutionStatus.RUNNING, timeout=TIMEOUT_SECONDS
    )
    assert client.cancel_case(case_id, wait=True)


def test_get_soap_objects():
    client = create_client()
    programs = client.get_programs()
    assert len(programs) > 0
    for program in programs:
        program_versions = client.get_program_versions(program)
        assert len(program_versions) > 0
        for version in program_versions.values():
            execution_types = client.get_execution_types(program, version)
            assert len(execution_types) >= 0
    assert len(client.get_memory_per_process_ratios()) > 0
    assert len(client.get_repository_durations()) > 0
    assert len(client.get_budgets()) >= 0


def test_get_case():
    client = create_client()
    cases = client.get_all_cases_since(60)
    assert len(cases) > 0
    assert isinstance(client.get_case(cases[0].id), Case)


def test_optgen_standalone():
    client = create_client()
    case = Case(
        name="test_optgen_standalone",
        data_path=AWS.download_test_case("optgen.zip"),
        program="OPTGEN",
        program_version="8.2.5",
        execution_type="SDDP 17.3.12",
        memory_per_process_ratio="2:1",
        price_optimized=PSRCLOUD_PRICE_OPTIMIZED,
        number_of_processes=DEFAULT_NUMBER_OF_PROCESSES,
        repository_duration=1,
        ami_id=PSRCLOUD_AMI_ID,
        budget=DEFAULT_BUGDET,
    )
    case_id = client.run_case(case)
    assert client._check_until_status(case_id, ExecutionStatus.SUCCESS)


def test_platform_optgen():
    client = create_client()
    case = Case(
        name="test_platform_optgen",
        data_path=AWS.download_test_case("sddp-platform-complete.zip"),
        program="SDDP",
        program_version="18.0.7",
        execution_type="Expansion Planning",
        memory_per_process_ratio="2:1",
        price_optimized=PSRCLOUD_PRICE_OPTIMIZED,
        number_of_processes=DEFAULT_NUMBER_OF_PROCESSES,
        repository_duration=1,
        ami_id=PSRCLOUD_AMI_ID,
        budget=DEFAULT_BUGDET,
    )
    case_id = client.run_case(case)
    assert client._check_until_status(
        case_id, ExecutionStatus.SUCCESS, timeout=TIMEOUT_SECONDS
    )


def test_platform_optmain():
    client = create_client()
    case = Case(
        name="test_platform_optmain",
        data_path=AWS.download_test_case("sddp-platform-complete.zip"),
        program="SDDP",
        program_version="18.0.7",
        execution_type="Maintenance Scheduling",
        memory_per_process_ratio="2:1",
        price_optimized=PSRCLOUD_PRICE_OPTIMIZED,
        number_of_processes=DEFAULT_NUMBER_OF_PROCESSES,
        repository_duration=1,
        ami_id=PSRCLOUD_AMI_ID,
        budget=DEFAULT_BUGDET,
    )
    case_id = client.run_case(case)
    assert client._check_until_status(
        case_id, ExecutionStatus.SUCCESS, timeout=TIMEOUT_SECONDS
    )


# ---------------------------------------------------------------------------
# Dependent Tests
# ---------------------------------------------------------------------------


def test_download_results():
    client = create_client()
    sddp_standalone_case_id = load_shared("sddp_standalone_case_id")
    download_path = os.path.join(tempfile.gettempdir(), "psrcloud-tests", "results")
    client._clean_folder(download_path)
    client.download_results(sddp_standalone_case_id, download_path)
    assert os.path.exists(os.path.join(download_path, "download.ok"))
    client._clean_folder(download_path)


def test_psrio():
    client = create_client()
    sddp_standalone_case_id = load_shared("sddp_standalone_case_id")
    psrio_case = Case(
        name="test_psrio",
        data_path=AWS.download_test_case("psrio.zip"),
        program="PSRIO",
        execution_type="SDDP",
        program_version="1.2.0",
        memory_per_process_ratio="2:1",
        price_optimized=PSRCLOUD_PRICE_OPTIMIZED,
        number_of_processes=1,
        repository_duration=1,
        parent_case_id=sddp_standalone_case_id,
        ami_id=PSRCLOUD_AMI_ID,
        budget=DEFAULT_BUGDET,
    )
    psrio_case_id = client.run_case(psrio_case)
    assert client._check_until_status(
        psrio_case_id, ExecutionStatus.SUCCESS, timeout=TIMEOUT_SECONDS
    )


def test_sddp_simulation():
    client = create_client()
    sddp_standalone_case_id = load_shared("sddp_standalone_case_id")
    simulation_case = Case(
        name="test_sddp_simulation",
        data_path=AWS.download_test_case("sddp_simulation.zip"),
        program="SDDP",
        program_version="17.3.7",
        execution_type="Default",
        memory_per_process_ratio="2:1",
        price_optimized=PSRCLOUD_PRICE_OPTIMIZED,
        number_of_processes=DEFAULT_NUMBER_OF_PROCESSES,
        repository_duration=1,
        parent_case_id=sddp_standalone_case_id,
        ami_id=PSRCLOUD_AMI_ID,
        budget=DEFAULT_BUGDET,
    )
    sim_case_id = client.run_case(simulation_case)
    assert client._check_until_status(
        sim_case_id, ExecutionStatus.SUCCESS, timeout=TIMEOUT_SECONDS
    )


def test_graf():
    client = create_client()
    if client._python_client:
        print("Skipping Graf: not ready for python client")
        return

    sddp_standalone_case_id = load_shared("sddp_standalone_case_id")
    graf_files_path = tempfile.mkdtemp()
    client._pre_process_graph(graf_files_path, sddp_standalone_case_id)
    assert os.path.exists(os.path.join(graf_files_path, "indice.grf"))

    graf_name = "test_graf"
    with open(os.path.join(graf_files_path, "instruc.grf"), "w") as f:
        f.write(f"""INIGRAPH {graf_name}
HORIZON,-1
Etapa inicial           :    1
Ano inicial             : 2013
Etapa final             :   12
Ano final               : 2013
# bloques a graficar    :   -1
Suma bloques?           :    1
Suma etapas por ano?    :   -1
Titulo eje-x            :
Titulo primario eje-y   :
Titulo secundario eje-y :
# Series seleccionadas  :   -1
grafica series selecc.? :   -1
grafica promedio?       :    1
grafica desv. standard? :   -1
grafica cuantil sup?    :    0
grafica cuantil inf?    :    0
CHARTTYPE -1
CHARTNAME 1
Nombre variable   1     :Block length in pu
# de agentes a graficar :00001
nombre del agente       :Length
ENDGRAPH""")

    graf_case = Case(
        name="test_graf",
        data_path=graf_files_path,
        program="GRAF",
        execution_type="Old Compatibility",
        program_version="0",
        memory_per_process_ratio="2:1",
        price_optimized=PSRCLOUD_PRICE_OPTIMIZED,
        number_of_processes=1,
        repository_duration=1,
        parent_case_id=sddp_standalone_case_id,
        ami_id=PSRCLOUD_AMI_ID,
        budget=DEFAULT_BUGDET,
    )
    client.run_case(graf_case)
    assert os.path.exists(os.path.join(graf_files_path, "graf.ok"))
    client._clean_folder(graf_files_path)


def test_platform_sddp():
    client = create_client()
    version_name = load_shared("published_version_name")
    case = Case(
        name="test_platform_sddp",
        data_path=AWS.download_test_case("sddp-platform-complete.zip"),
        program="SDDP",
        program_version=version_name,
        execution_type="Operation Planning (Default)",
        memory_per_process_ratio="2:1",
        price_optimized=PSRCLOUD_PRICE_OPTIMIZED,
        number_of_processes=DEFAULT_NUMBER_OF_PROCESSES,
        repository_duration=1,
        ami_id=PSRCLOUD_AMI_ID,
        budget=DEFAULT_BUGDET,
    )
    case_id = client.run_case(case)
    assert client._check_until_status(
        case_id, ExecutionStatus.SUCCESS, timeout=TIMEOUT_SECONDS
    )


# ===========================================================================
# doit task runner configuration
# ===========================================================================

DOIT_CONFIG = {
    "verbosity": 0,
    "backend": "json",
}

GREEN = "\033[92m"
RED = "\033[91m"
BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"

ALL_TESTS = [
    test_cancel_case,
    test_get_soap_objects,
    test_get_case,
    test_optgen_standalone,
    test_sddp_standalone,
    test_publish_version,
    test_download_results,
    test_psrio,
    test_sddp_simulation,
    test_graf,
    test_platform_sddp,
    test_platform_optgen,
    test_platform_optmain,
    test_ncp,
]

DEPENDENCIES = {
    test_download_results: ["test_sddp_standalone"],
    test_psrio: ["test_sddp_standalone"],
    test_sddp_simulation: ["test_sddp_standalone"],
    test_graf: ["test_sddp_standalone"],
    test_platform_sddp: ["test_publish_version"],
}

RESULTS_DIR = os.path.join(tempfile.gettempdir(), "psrcloud-tests", ".results")

# Save a dup of the real stdout fd BEFORE anything can redirect it.
# This is used to print PASSED/FAILED even while stdout/stderr are captured.
_real_stdout_fd = os.dup(1)
_out = os.fdopen(_real_stdout_fd, "w", closefd=False)


def _print(msg):
    _out.write(msg + "\n")
    _out.flush()


def _completed_count():
    """Count completed tests by counting result files on disk (shared across workers)."""
    if not os.path.exists(RESULTS_DIR):
        return 0
    return sum(1 for f in os.listdir(RESULTS_DIR) if f.endswith(".json"))


@contextmanager
def _capture_all_output():
    """Capture ALL output (stdout, stderr, logging, C-level writes) using OS-level fd redirection."""
    stdout_file = tempfile.TemporaryFile(mode="w+b")
    stderr_file = tempfile.TemporaryFile(mode="w+b")

    # Save original file descriptors
    saved_stdout_fd = os.dup(1)
    saved_stderr_fd = os.dup(2)

    # Save original Python-level streams
    saved_stdout = sys.stdout
    saved_stderr = sys.stderr

    try:
        # Redirect OS-level file descriptors to temp files
        os.dup2(stdout_file.fileno(), 1)
        os.dup2(stderr_file.fileno(), 2)

        # Also redirect Python-level streams
        sys.stdout = io.TextIOWrapper(
            os.fdopen(os.dup(stdout_file.fileno()), "wb", closefd=True),
            write_through=True,
        )
        sys.stderr = io.TextIOWrapper(
            os.fdopen(os.dup(stderr_file.fileno()), "wb", closefd=True),
            write_through=True,
        )

        yield stdout_file, stderr_file
    finally:
        # Flush Python streams before restoring
        sys.stdout.flush()
        sys.stderr.flush()

        # Restore Python-level streams
        sys.stdout = saved_stdout
        sys.stderr = saved_stderr

        # Restore OS-level file descriptors
        os.dup2(saved_stdout_fd, 1)
        os.dup2(saved_stderr_fd, 2)
        os.close(saved_stdout_fd)
        os.close(saved_stderr_fd)


def run_test(func):
    """Wrapper that captures output and only shows it on failure."""
    name = func.__name__
    start = time.time()
    try:
        with _capture_all_output() as (stdout_file, stderr_file):
            func()
        elapsed = time.time() - start
        _save_result(name, True, elapsed, "", "")
        count = _completed_count()
        total = int(os.environ.get("PSRCLOUD_TEST_TOTAL", len(ALL_TESTS)))
        _print(
            f"{BOLD}{GREEN}  PASSED  {RESET} {DIM}[{count}/{total}]{RESET} {name} {DIM}({elapsed:.1f}s){RESET}"
        )
        return True
    except Exception:
        elapsed = time.time() - start
        error_msg = traceback.format_exc()
        stdout_file.seek(0)
        stderr_file.seek(0)
        captured = stdout_file.read().decode(
            "utf-8", errors="replace"
        ) + stderr_file.read().decode("utf-8", errors="replace")
        _save_result(name, False, elapsed, error_msg, captured)
        count = _completed_count()
        total = int(os.environ.get("PSRCLOUD_TEST_TOTAL", len(ALL_TESTS)))
        _print(
            f"{BOLD}{RED}  FAILED  {RESET} {DIM}[{count}/{total}]{RESET} {name} {DIM}({elapsed:.1f}s){RESET}"
        )
        return True  # Always succeed for doit; reporting is handled via result files


def _save_result(name, passed, elapsed, error, log):
    """Save a single test result to a JSON file."""
    os.makedirs(RESULTS_DIR, exist_ok=True)
    result = {
        "name": name,
        "passed": passed,
        "elapsed": elapsed,
        "error": error,
        "log": log,
    }
    filepath = os.path.join(RESULTS_DIR, f"{name}.json")
    with open(filepath, "w") as f:
        json.dump(result, f)


def _make_task(func):
    task = {
        "actions": [(run_test, [func])],
        "verbosity": 0,
    }
    if func in DEPENDENCIES:
        task["setup"] = DEPENDENCIES[func]
    return task


for _func in ALL_TESTS:
    _task_name = f"task_{_func.__name__}"
    globals()[_task_name] = (lambda f: lambda: _make_task(f))(_func)
    globals()[_task_name].__doc__ = _func.__name__
