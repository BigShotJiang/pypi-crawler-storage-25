"""
Internal authentication module for psr.cloud.

This module is for internal use only and should not be imported directly by users.
"""

from .sso import SSOClient

__all__ = ["SSOClient"]
