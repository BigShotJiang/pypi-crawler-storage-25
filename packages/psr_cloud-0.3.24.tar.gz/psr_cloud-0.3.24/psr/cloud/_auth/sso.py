"""SSO authentication using OpenID Connect with PKCE."""

import base64
import hashlib
import json
import os
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any, Optional
from urllib.parse import parse_qs, urlparse

import requests

from .credential_manager import CredentialManager

_TOKEN_KEYS: list[str] = ["access_token", "refresh_token", "id_token"]


class SSOClient:
    """
    SSO client for OpenID Connect authentication with PKCE.

    This client handles the full OAuth2 Authorization Code Flow with PKCE,
    including token storage, refresh, and interactive login.
    """

    def __init__(
        self,
        client_id: str = "285k9plmolqhpb4c1ropncmlnb",
        service_name: str = "PycloudSSO",
        authorization_url: str = "https://sso.psr-inc.com/login",
        token_url: str = "https://auth.psr-inc.com/token",  # nosec
        port: int = 43217,
        scopes: str = "openid phone email",
    ) -> None:
        """
        Initializes the SSO client.

        Args:
            client_id: The OAuth2 client ID.
            service_name: The service name for credential storage.
            authorization_url: The identity provider's authorization endpoint.
            token_url: The identity provider's token endpoint.
            port: The local port for the callback server.
            scopes: The OAuth2 scopes to request.
        """
        self._client_id = client_id
        self._service_name = service_name
        self._authorization_url = authorization_url
        self._token_url = token_url
        self._port = port
        self._redirect_uri = f"http://localhost:{port}/callback/"
        self._scopes = scopes

        self._cred_manager = CredentialManager(service_name)
        self._authorization_code: str | None = None
        self._expected_state: str | None = None

    def _decode_jwt_payload_unsafely(self, token: str) -> dict[str, Any]:
        """
        Decodes the payload part of a JWT without verifying the signature.

        Args:
            token: The JWT string to decode.

        Returns:
            A dictionary containing the decoded payload claims.
            Returns an empty dictionary if decoding fails.
        """
        try:
            parts = token.split(".")
            if len(parts) < 2:
                return {}
            payload_b64 = parts[1]
            payload_b64 += "=" * ((4 - len(payload_b64) % 4) % 4)
            payload_bytes = base64.urlsafe_b64decode(payload_b64)
            return json.loads(payload_bytes)
        except Exception:
            return {}

    def _is_token_expired(self, token: str, buffer_seconds: int = 60) -> bool:
        """
        Determines if a JWT is expired based on its 'exp' claim.

        Args:
            token: The JWT to check.
            buffer_seconds: Safety buffer in seconds. Defaults to 60.

        Returns:
            True if the token is expired or has no 'exp' claim, False otherwise.
        """
        payload = self._decode_jwt_payload_unsafely(token)
        exp = payload.get("exp")
        if not exp:
            return True

        return (time.time() + buffer_seconds) > exp

    def _save_tokens(self, tokens: dict[str, Any]) -> None:
        """
        Persists OAuth2 tokens to the secure Credential Manager.

        Args:
            tokens: A dictionary containing token response data.
        """
        if "refresh_token" in tokens:
            self._cred_manager.save_secret("refresh_token", tokens["refresh_token"])
        if "access_token" in tokens:
            self._cred_manager.save_secret("access_token", tokens["access_token"])
        if "id_token" in tokens:
            self._cred_manager.save_secret("id_token", tokens["id_token"])

    def _refresh_tokens(self) -> bool:
        """
        Attempts to obtain new tokens using the stored refresh token.

        Returns:
            True if tokens were successfully refreshed, False otherwise.
        """
        refresh_token_val = self._cred_manager.get_secret("refresh_token")
        if not refresh_token_val:
            return False

        payload = {
            "grant_type": "refresh_token",
            "client_id": self._client_id,
            "refresh_token": refresh_token_val,
        }

        try:
            response = requests.post(self._token_url, data=payload, timeout=10)
            response.raise_for_status()
            new_tokens = response.json()

            self._save_tokens(new_tokens)
            return True
        except requests.exceptions.RequestException:
            return False

    def _generate_pkce_pair(self) -> tuple[str, str]:
        """
        Generates a cryptographic pair for PKCE (RFC 7636).

        Returns:
            A tuple containing (code_verifier, code_challenge).
        """
        code_verifier = (
            base64.urlsafe_b64encode(os.urandom(40)).decode("utf-8").rstrip("=")
        )
        sha256_hash = hashlib.sha256(code_verifier.encode("utf-8")).digest()
        code_challenge = (
            base64.urlsafe_b64encode(sha256_hash).decode("utf-8").rstrip("=")
        )
        return code_verifier, code_challenge

    def _create_callback_handler(self) -> type[BaseHTTPRequestHandler]:
        """
        Creates a callback handler class with access to this client instance.

        Returns:
            A BaseHTTPRequestHandler subclass.
        """
        client = self

        class CallbackHandler(BaseHTTPRequestHandler):
            """HTTP handler that captures OAuth2 authorization codes."""

            def log_message(self, _format: str, *_args: Any) -> None:
                """Suppress HTTP server logging."""
                pass

            def do_GET(self) -> None:
                """Process the OAuth2 callback."""
                query_components = parse_qs(urlparse(self.path).query)

                if "code" in query_components:
                    received_state = query_components.get("state", [None])[0]

                    if received_state != client._expected_state:
                        self.send_response(400)
                        self.send_header("Content-type", "text/html")
                        self.end_headers()
                        self.wfile.write(
                            b"<h1>Login Failed.</h1>"
                            b"<p>State validation failed. Possible CSRF attack.</p>"
                        )
                        threading.Thread(target=self.server.shutdown).start()
                        return

                    client._authorization_code = query_components["code"][0]
                    self.send_response(200)
                    self.send_header("Content-type", "text/html")
                    self.end_headers()
                    self.wfile.write(
                        b"<h1>Login successful!</h1>"
                        b"<p>You can close this tab now.</p>"
                    )
                else:
                    self.send_response(400)
                    self.send_header("Content-type", "text/html")
                    self.end_headers()
                    self.wfile.write(
                        b"<h1>Login Failed.</h1>"
                        b"<p>Authorization code not found.</p>"
                    )
                threading.Thread(target=self.server.shutdown).start()

        return CallbackHandler

    def _perform_interactive_login(self) -> bool:
        """
        Executes the full interactive Authorization Code Flow with PKCE.

        Returns:
            True if login was successful, False otherwise.
        """
        self._authorization_code = None

        code_verifier, code_challenge = self._generate_pkce_pair()
        self._expected_state = (
            base64.urlsafe_b64encode(os.urandom(32)).decode("utf-8").rstrip("=")
        )

        params = {
            "client_id": self._client_id,
            "response_type": "code",
            "scope": self._scopes,
            "redirect_uri": self._redirect_uri,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
            "state": self._expected_state,
            "prompt": "login",
        }
        auth_url = f"{self._authorization_url}?{requests.compat.urlencode(params)}"

        try:
            handler_class = self._create_callback_handler()
            httpd = HTTPServer(("localhost", self._port), handler_class)
        except OSError:
            return False

        # Timeout after 2 minutes
        timeout_timer = threading.Timer(120, httpd.shutdown)
        timeout_timer.start()

        webbrowser.open(auth_url)

        httpd.serve_forever()
        timeout_timer.cancel()
        httpd.server_close()

        if self._authorization_code:
            token_payload = {
                "grant_type": "authorization_code",
                "code": self._authorization_code,
                "redirect_uri": self._redirect_uri,
                "client_id": self._client_id,
                "code_verifier": code_verifier,
            }

            try:
                response = requests.post(
                    self._token_url, data=token_payload, timeout=10
                )
                response.raise_for_status()
                tokens: dict[str, Any] = response.json()

                self._save_tokens(tokens)
                return True

            except requests.exceptions.RequestException:
                return False
        else:
            return False

    def ensure_active_session(self) -> Optional[str]:
        """
        Ensures a valid session exists by checking, refreshing, or creating one.

        The priority order is:
        1. Return an existing, non-expired ID token's paired access token.
        2. Attempt to refresh tokens using a stored refresh token.
        3. Trigger a full interactive login flow if previous methods fail.

        Returns:
            A valid access token if successful, or None if all attempts failed.
        """
        id_token = self._cred_manager.get_secret("id_token")
        if id_token:
            if not self._is_token_expired(id_token):
                return self._cred_manager.get_secret("id_token")

        if self._refresh_tokens():
            return self._cred_manager.get_secret("id_token")

        if self._perform_interactive_login():
            return self._cred_manager.get_secret("id_token")

        return None

    def logout(self) -> None:
        """
        Logs out the user by removing all stored tokens.
        """
        self._cred_manager.clear_all_credentials(_TOKEN_KEYS)

    def get_email(self) -> Optional[str]:
        """
        Extracts the email from the stored ID token.

        Returns:
            The email address if found in the token, None otherwise.
        """
        id_token = self._cred_manager.get_secret("id_token")
        if not id_token:
            return None
        payload = self._decode_jwt_payload_unsafely(id_token)
        return payload.get("email")
