# NiemaFS
Niema's Python library for reading data from various file system standards

## Installation
NiemaFS can be installed using `pip`:

```bash
sudo pip install niemafs
```

If you are using a machine on which you lack administrative powers, NiemaFS can be installed locally using `pip`:

```bash
pip install --user niemafs
```

## Usage
The workflow to use each of the NiemaFS classes is as follows:

1. Instantiate the appropriate NiemaFS class by providing a path `path` and a file-like object `file_obj`
2. Iterate over the contents of the NiemaFS object using a for-loop, each iteration of which will yield a `tuple` as follows:
    1. The [`Path`](https://docs.python.org/3/library/pathlib.html#pathlib.Path) of the file/folder within the file system
    2. The modification timestamp of the file/folder as a [`datetime`](https://docs.python.org/3/library/datetime.html#datetime.datetime), or `None` if the file system does not store timestamps
    3. The contents of the file as [`bytes`](https://docs.python.org/3/library/stdtypes.html#bytes), or `None` for directories

```python
for curr_path, curr_timestamp, curr_data in fs:
    if curr_data is None:
        print('DIR', curr_path, curr_timestamp)
    else:
        print('FILE', curr_path, curr_timestamp, len(curr_data))
```

See the [documentation](https://niema.net/NiemaFS) as well as the [example scripts](scripts) for more information. This repository also contains [example files](example) to test the NiemaFS classes.

### [`DirFS`](https://niema.net/NiemaFS/#niemafs.DirFS) — Directories

```python
from niemafs import DirFS
fs = DirFS(path=target_path)
```

### [`GcmFS`](https://niema.net/NiemaFS/#niemafs.GcmFS) — Nintendo GameCube Mini-DVD

```python
from niemafs import GcmFS
with open(target_path, 'rb') as target_file:
    fs = GcmFS(path=target_path, file_obj=target_file)
```

### [`GcRarcFS`](https://niema.net/NiemaFS/#niemafs.GcRarcFS) — Nintendo GameCube RARC Archive

```python
from niemafs import GcRarcFS
with open(target_path, 'rb') as target_file:
    fs = GcRarcFS(path=target_path, file_obj=target_file)
```

### [`IsoFS`](https://niema.net/NiemaFS/#niemafs.IsoFS) — ISO 9660 Disc Image

```python
from niemafs import IsoFS
with open(target_path, 'rb') as target_file:
    fs = IsoFS(path=target_path, file_obj=target_file)
```

### [`TarFS`](https://niema.net/NiemaFS/#niemafs.TarFS) — TAR Archive

```python
from niemafs import TarFS
with open(target_path, 'rb') as target_file:
    fs = TarFS(path=target_path, file_obj=target_file)
```

### [`TgcFS`](https://niema.net/NiemaFS/#niemafs.TgcFS) — Nintendo GameCube TGC Image

```python
from niemafs import TgcFS
with open(target_path, 'rb') as target_file:
    fs = TgcFS(path=target_path, file_obj=target_file)
```

### [`WiiFS`](https://niema.net/NiemaFS/#niemafs.WiiFS) — Nintendo Wii DVD
Note that, due to the need to decrypt the file system, this is extremely memory-intensive (each partition is loaded into memory to process in parallel for speed).

```python
from niemafs import WiiFS
with open(target_path, 'rb') as target_file:
    fs = WiiFS(path=target_path, file_obj=target_file)
```

### [`ZipFS`](https://niema.net/NiemaFS/#niemafs.ZipFS) — ZIP Archive

```python
from niemafs import ZipFS
with open(target_path, 'rb') as target_file:
    fs = ZipFS(path=target_path, file_obj=target_file)
```

# Acknowledgements
The following resources were extremely helpful in the development of NiemaFS:

* [Custom Mario Kart Wiiki](https://wiki.tockdom.com/) — [RARC (File Format)](https://wiki.tockdom.com/wiki/RARC_(File_Format))
* [GC-Forever](https://www.gc-forever.com/) — [Yet Another Gamecube Documentation](https://www.gc-forever.com/yagcd/)
* [Luma's Workshop](https://www.lumasworkshop.com/) — [RARC (File Format)](https://www.lumasworkshop.com/wiki/RARC_(File_Format))
* [OS Development Wiki](https://wiki.osdev.org/) — [File Systems](https://wiki.osdev.org/File_Systems)
* [TGCtoGCM](https://www.romhacking.net/utilities/1096/)
* [Wii.py](https://github.com/grp/Wii.py)
* [WiiBrew](https://wiibrew.org) — [Wii Disc](https://wiibrew.org/wiki/Wii_disc)
