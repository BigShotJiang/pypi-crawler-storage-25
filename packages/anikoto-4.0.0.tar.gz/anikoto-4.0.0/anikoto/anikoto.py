
try:
    from curl_cffi import requests
except ImportError:
    import requests
import argparse
from traceback import format_exc

import logging
import os
import datetime
import re
from bs4 import BeautifulSoup
import base64
import yt_dlp
import subprocess
from urllib.parse import urlparse

class CustomFormatter(logging.Formatter):
    COLORS = {
        'DEBUG': '\033[31m',      # Red
        'INFO': '\033[32m',       # Green
        'WARNING': '\033[36m',    # Cyan
        'ERROR': '\033[33m',      # Yellow
        'CRITICAL': '\033[31m\033[47m\033[1m',  # Red text on white background, bold
    }
    RESET = '\033[0m'  # Reset to default color

    def format(self, record):
        log_color = self.COLORS.get(record.levelname, '')
        reset_color = self.RESET
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        process_id = os.getpid()
        log_message = f"{log_color}{timestamp}:{process_id}:{record.levelname}:{record.name}:{reset_color}{log_color}{record.msg}{reset_color}"
        return log_message

def configure_logging():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(CustomFormatter())
    logger.addHandler(console_handler)    


configure_logging()


def clean_name(name):
    name = re.sub(r'[\\/*?:"<>|]', '_', name)
    name = re.sub(r'\s+', ' ', name).strip()
    return name

def download(url, referer, path, anime, title, number,args):
    anime = clean_name(anime)
    if not os.path.exists(f"{path}/{anime}"):
        os.makedirs(f"{path}/{anime}")
    logging.info(f"Downloading E{number} {title} from {url}")
    if os.path.exists(f"{path}/{anime}/{anime} E{number} {title}.mp4"):
        logging.info(f"File already exists: {path}/{anime}/{anime} E{number} {title}.mp4")
        return
    
    downloader = args.downloader
    if downloader == 'yt-dlp':
        ydl_opts = {
            # 'format': 'bv+ba',  
            'http_headers':  {
                    
                    
                    
                    'user-agent': "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36",
                    
                    'accept': "*/*",
                    'origin': referer,
                    
                    'referer': referer,
                    
                    'priority': "u=1, i"
                },

            'external_downloader': 'aria2c', 
            'hls_prefer_native': {'m3u8': 'native', 'dash': 'native'},
            'concurrent_fragment_downloads':10,

            'paths': {
                'temp': 'temp',  
                'home': f'{path}/{anime}' 
            },
            'outtmpl': f'{anime} E{number} {title}.%(ext)s', 
            'generic':{
                'impersonate': 'Edge',
            },
            # 'cookiesfrombrowser': ('chrome'),
            # 'verbose':True,
            # 'debug_printtraffic':True,
            'socket_timeout':10,
            'nocheckcertificate': True,
            # 'encoding':'gzip, deflate, br, zstd',
        }
        if args.debug:
            ydl_opts['debug_printtraffic'] = True
            ydl_opts['verbose'] = True

        if args.quality:
            # ydl_opts['format'] = f'bv[height<=?{args.quality}]+ba'
            ydl_opts['format_sort'] = [f'res:{args.quality}']
        if args.debug:
            logging.debug(ydl_opts)
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])

    elif downloader == 'ffmpeg':
        headers = (
            "user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/141.0.0.0 Safari/537.36\r\n"
            f"referer: {referer}\r\n"
            f'accept-language:en-US,en;q=0.9\r\n'
            'accept-encoding: gzip, deflate, br, zstd\r\n'
            "accept: */*\r\n"
   
            "sec-fetch-dest: empty\r\n"
            "sec-fetch-mode: cors\r\n"
            "sec-fetch-site: cross-site\r\n"
        )
        # print(headers)
        cmd = [
            "ffmpeg",
            '-extension_picky', '0',
            "-headers", headers,
            "-i", url,
            "-acodec", "copy",
            '-vcodec', 'copy',
            "-loglevel", "debug",
            "-y",
            f"{path}/{anime}/{anime} E{number} {title}.mp4"
        ]

        subprocess.run(cmd, check=True)
    
    else:
        subprocess.run([
            'N_m3u8DL-RE',url,
            "-H","user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/141.0.0.0 Safari/537.36",
            "-H",f"referer: {referer}",
            "-H",f'accept-language:en-US,en;q=0.9',
            "-H",'accept-encoding: gzip, deflate, br, zstd',
            "-H","accept: */*",

            "-H","sec-fetch-dest: empty",
            "-H","sec-fetch-mode: cors",
            "-H","sec-fetch-site: cross-site",
            '--save-dir',f"{path}/{anime}",
            '--log-level', 'DEBUG',
            '--save-name', f"{anime} E{number} {title} 3",
            '-M', 'format=mp4'
    ])
        
def subtitles(response, session, args, anime, number, title):
    anime = clean_name(anime)
    if "tracks" in response:
        for track in response['tracks']:
            try:
                logging.info(f"Track: {track.get('label')} ({track.get('kind')})")
                if track.get('file'):
                    logging.info(f"Track URL: {track.get('file')}")
                    if not os.path.exists(f"{args.path}/{anime}/{anime} E{number} {title} {track.get('label')}.vtt"):
                        logging.info(f"Downloading subtitles for E{number} {title} {track.get('label')}")
                        s_r = session.get(track.get('file'),headers={
                            "referer": "https://megaplay.buzz/",
                        })
                        if s_r.status_code == 200:
                            logging.info(f"{args.path}/{anime}/{anime} E{number} {title} {track.get('label')}.vtt")
                            if not os.path.exists(f"{args.path}/{anime}/"):
                                os.makedirs(f"{args.path}/{anime}/")
                            with open(f"{args.path}/{anime}/{anime} E{number} {title} {track.get('label')}.vtt", 'wb') as f:
                                f.write(s_r.content)
            except:
                logging.info(format_exc())       
                    
            # else:
            #     logging.warning(f"Track Request Error{s_r.text}")

def main():
    version = "3.5.0"
    session = requests.Session()
    # session.verify = False
    session.headers.update({
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36",
        "x-requested-with": "XMLHttpRequest",
    })
    parser = argparse.ArgumentParser(description="Anikoto (https://anikoto.tv/) Downloader", epilog="Example usage:\n python3 anikoto.py OPTIONS URL")
    parser.add_argument("--version","-v", action="version", version=f"%(prog)s {version}")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    parser.add_argument("url", help="Video Url like: https://anikoto.tv/watch/solo-leveling-ilh08/ep-1")
    parser.add_argument("--quality","-q", choices=['2160','1440',"1080", "720", "480",'360'],default="1080", help="Choose a Quality")
    parser.add_argument("--audio", "-a", choices=['sub', 'dub'], default='dub', help="Download Audio")
    parser.add_argument("--downloader", "-d", choices=['yt-dlp', 'N_m3u8DL-RE', 'ffmpeg'], default='yt-dlp', help="Downloader")
    parser.add_argument("--subtitles", "-ss", action="store_true",default=True, help="Download Subs")
    parser.add_argument("--list", action="store_true",default=False, help="List Episodes")
    parser.add_argument("--last", action="store_true",default=False, help="Only Download Last Episode")
    parser.add_argument("--path", "-p", help="path to save the file", default=os.getcwd())
    parser.add_argument("--source", help="select source",)
    parser.add_argument("--range", "-r", help="Specify episode range (e.g. 1-5) if you want to download only episode 1129 use 1129-1129")


    args = parser.parse_args()

    r = session.get(args.url)
    
    parsed = urlparse(r.url)
    domain = f"{parsed.scheme}://{parsed.netloc}"


    search = re.search(rf'{domain}/anime/getinfo/(\d+)', r.text)
    soup = BeautifulSoup(r.text, 'html.parser')
    title_element = soup.find('h1', class_='title d-title')
    anime = title_element.get_text(strip=True)
    if not search:
        logging.error("Error: Unable to find the video ID in the provided URL.")
        exit(1)
    video_id = search.group(1)
    r = session.get(f"{domain}/ajax/episode/list/{video_id}?vrf=")
    html_code = r.json()['result']


    soup = BeautifulSoup(html_code, 'html.parser')
    episodes = soup.find_all('li', {'data-html': 'true'})
    episode_data = []

    i = 1
    for episode in episodes:
        title = episode.get('title')
        data_ids = episode.find('a').get('data-ids')
        data_mal = episode.find('a').get('data-mal')
        data_timestamp = episode.find('a').get('data-timestamp')
        episode_data.append({'title': title, 'data-ids': data_ids, 'data-mel': data_mal, 'data-timestamp': data_timestamp, 'number': i})
        i+=1
    del i

    for number, data in enumerate(episode_data, start=1):
        print(f"{number}: {data['title']}")
        if args.debug:
            title = data['title']
            print(f"Data IDs: {data['data-ids']}")
            data_ids = data['data-ids']
            data_mel = data['data-mel']
            print(f"Data MAL: {data_mal}")
            data_timestamp = data['data-timestamp']
            print(f"Data Timestamp: {data['data-timestamp']}")
            print()


    if args.range:
        try:
            start, end = map(int, args.range.split('-'))
            episode_data = episode_data[start-1:end]
            logging.info(f"Downloading episodes {start} to {end}:")
            for number, data in enumerate(episode_data, start=start):
                print(f"{number}: {data['title']}")
        except Exception as e:
            logging.info(f"Invalid range format. Use like '1-5'. Error: {e}")
            exit(1)

    if args.list:
        logging.info("List of Episodes:")
        for data in episode_data:
            print(f"{data['number']}: {data['title']}")
        exit(0)

    if args.last:
        episode_data = episode_data[-1:]
        logging.info("Last Episode:")
        # if args.debug:
        for data in episode_data:       
            print(f"{data['number']}: {data['title']}")


        
    # if 'kiwi' in args.source.lower():
    try:
        if not args.source or 'kiwi' in args.source.lower():
            for data in episode_data:
                number = data['number']
                # print(f'https://mapper.kotostream.online/api/mal/{data['data-mel']}/{number}/{data['data-timestamp']}')
                # r = session.get(f"https://mapper.kotostream.online/api/mal/{data['data-mel']}/{number}/{data['data-timestamp']}", timeout=5, verify=False) # seems down 
                logging.info(f"Trying to get stream URL for E{number} {data['title']} from Kiwi Stream")
                logging.info(f"Request URL: https://mapper.mewcdn.online/api/mal/{data['data-mel']}/{number}/{data['data-timestamp']}")
                r = session.get(f"https://mapper.mewcdn.online/api/mal/{data['data-mel']}/{number}/{data['data-timestamp']}", headers={
                    'User-Agent': "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0",
                    'referer': domain,
                    'origin': domain,   

                })
                if r.status_code == 200:
                    for stream in r.json():
                        if "Stream" in stream and args.quality in stream:
                            # print(stream)
                            if args.debug:
                                print(r.json())
                            server_code = r.json()[stream][args.audio]['url']
                            url = f"{domain}/ajax/server"
                            querystring = {"get":server_code}
                            r = session.get(url, params=querystring)
                            url = r.json()['result']['url']
                            if "#" in url:
                                url = base64.b64decode(url.split("#")[1]).decode('utf-8')
                                # download(url, f"{domain}/", args.path,anime, data['title'], number, args,)
                                download(url, f"https://kwik.cx2.mewcdn.online", args.path,anime, data['title'], number, args,)
    except Exception as e:
        logging.error(f'ERROR:{e}')
        if args.debug:
            print(format_exc())


    # if 'megaplay' in args.source.lower() or args.subtitles:

    for data in episode_data: 
        try:
            number = data['number']
            title = data['title']
            url = f"{domain}/ajax/server/list"
            querystring = {"servers":data['data-ids']}

            r = session.get(url, params=querystring)
            soup = BeautifulSoup(r.json()['result'], 'html.parser')

            servers = soup.find_all('div', class_='type')

            server_data = []
            for server in servers:
    
                server_type = server.get('data-type').upper() 
                server_item = server.find_all('li') 
                for li in server_item:
                    data_link_id = li.get('data-link-id')
                    server_data.append({'type': server_type, 'data-link-id': data_link_id, 'li': li.text})

            
            for data in server_data:
                if args.debug:
                    print()
                    print(f"type: {data['type']}")
                    print(f"data-link-id: {data['data-link-id']}")
                    print(f'server_item: {data['li']}')
                    print()

                if args.source:
                    if args.source.lower() not in data['li'].lower():
                        continue

                url = f"{domain}/ajax/server"
                
                querystring = {"get":data['data-link-id']}
                try:
                    r = session.get(url, params=querystring)
                except Exception as e:
                    print(format_exc())
                    continue
                url = r.json()['result']['url']
     
                main_r = session.get(url, headers={
                    "referer": f"{domain}/",
                })
                # print(r.text)
                
                # MegaPlay
                # if not args.source or 'megaplay' in args.source.lower():
                id_ = re.search(r' data-id=\"(\d+)\"', main_r.text)
                if id_:
                    id_ = id_.group(1)

                    r = session.get("https://megaplay.buzz/stream/getSources", params={"id":id_})
                    if 'sources' in r.json():
                        if args.debug:
                            print(r.json()['sources']['file'])

                        subtitles(r.json(), session, args, anime, number, title)
                        
                        if data['type'].lower() == args.audio.lower():
                            download(r.json()['sources']['file'], "https://megaplay.buzz/", args.path, anime, title, number, args, )

            # vidstream
            # if not args.source or 'vidstream' in args.source.lower():
                id_2 = re.search(r' data-ep-id=\"(\d+)\"', main_r.text)

                if id_2:
                    id_2 = id_2.group(1)
                    type_ = re.search(r"type: '(\w+)',", main_r.text)
                    if not type_:
                        raise Exception("Error: type not found")
                    type_ = type_.group(1)
                    domain2 = re.search(r"domain2_url: '(.+)',", main_r.text)
                    if not domain2:
                        raise Exception("Error: domain not found")
                    domain2 = domain2.group(1)
                    
                    response = session.get(f'{domain2}/save_data.php?id={id_2}-{type_}', headers={
                        'referer': domain
                    })
                    # print(response.text)
                    subtitles(response.json()['data'], session, args, anime, number, title)

                    if type_.lower() == args.audio.lower():
                            download(response.json()['data']['sources'][0]['url'],domain, args.path, anime, title, number, args, )

                    


                
        except Exception as e:
            logging.error(f'ERROR:{e}')
            if args.debug:
                print(format_exc())


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        logging.debug(format_exc())