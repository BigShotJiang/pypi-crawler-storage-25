"""Tests for Mistral AI auto-instrumentation."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from fibinaci._testing.mock_client import MockFibinaci
from fibinaci.instrumentation._wrapper import ProviderConfig, _extract_span


@dataclass
class FakeUsage:
    prompt_tokens: int = 85
    completion_tokens: int = 40
    total_tokens: int = 125


@dataclass
class FakeChoice:
    finish_reason: str = "stop"
    message: Any = None


@dataclass
class FakeResponse:
    model: str = "mistral-large-latest"
    usage: FakeUsage = None
    choices: list = None

    def __post_init__(self):
        if self.usage is None:
            self.usage = FakeUsage()
        if self.choices is None:
            self.choices = [FakeChoice()]


class TestMistralInstrumentation:
    @pytest.fixture
    def setup_mistral(self):
        mod = MagicMock()
        chat_resource_cls = MagicMock()
        original_complete = MagicMock(return_value=FakeResponse())
        original_acomplete = MagicMock(return_value=FakeResponse())
        chat_resource_cls.complete = original_complete
        chat_resource_cls.complete_async = original_acomplete
        mod.resources.ChatResource = chat_resource_cls
        mod.Mistral.chat = chat_resource_cls
        return mod, chat_resource_cls, original_complete

    def test_instrument_patches_complete(self, setup_mistral, mock_fibinaci: MockFibinaci):
        mod, chat_resource_cls, original_complete = setup_mistral
        with patch.dict("sys.modules", {
            "mistralai": mod,
            "mistralai.resources": mod.resources,
        }):
            from fibinaci.instrumentation.mistral import MistralInstrumentor
            inst = MistralInstrumentor()
            inst.instrument()
            assert chat_resource_cls.complete is not original_complete
            inst.uninstrument()

    def test_span_captured_on_success(self, mock_fibinaci: MockFibinaci):
        config = ProviderConfig(
            name="mistral",
            input_tokens_field="prompt_tokens",
            output_tokens_field="completion_tokens",
            finish_reason_getter=lambda r: getattr(r.choices[0], "finish_reason", None) if getattr(r, "choices", None) else None,
        )
        response = FakeResponse()
        started = datetime(2025, 3, 29, 12, 0, 0, tzinfo=timezone.utc)
        ended = datetime(2025, 3, 29, 12, 0, 1, tzinfo=timezone.utc)

        span_dict = _extract_span(config, {"model": "mistral-large-latest"}, response, started, ended)

        assert span_dict["span_kind"] == "model_call"
        assert span_dict["provider"] == "mistral"
        assert span_dict["tokens_input"] == 85
        assert span_dict["tokens_output"] == 40
        assert span_dict["status"] == "ok"
        assert span_dict["model_call"]["finish_reason"] == "stop"
        assert span_dict.get("cost_usd") is not None
