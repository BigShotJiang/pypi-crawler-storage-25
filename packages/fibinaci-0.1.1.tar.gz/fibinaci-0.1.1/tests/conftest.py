import sys
import os

# Add the SDK source to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from fibinaci._testing.mock_client import MockFibinaci
from fibinaci._globals import shutdown


@pytest.fixture(autouse=True)
def _reset_globals():
    """Reset global state between tests."""
    yield
    shutdown()


@pytest.fixture
def mock_fibinaci():
    mock = MockFibinaci()
    yield mock
    mock.teardown()
