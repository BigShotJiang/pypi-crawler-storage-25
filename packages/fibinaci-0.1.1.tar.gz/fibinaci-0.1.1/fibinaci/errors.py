"""Fibinaci SDK exceptions."""
from __future__ import annotations


class FibinaciError(Exception):
    """Base exception for all SDK errors."""


class APIError(FibinaciError):
    """Raised when the Fibinaci API returns a non-2xx response."""

    def __init__(
        self,
        message: str,
        status_code: int,
        error_type: str | None = None,
        error_code: str | None = None,
        request_id: str | None = None,
    ) -> None:
        self.status_code = status_code
        self.error_type = error_type
        self.error_code = error_code
        self.request_id = request_id
        super().__init__(message)


class AuthError(APIError):
    """401 — invalid or missing API key."""


class RateLimitError(APIError):
    """429 — too many requests."""

    def __init__(
        self,
        message: str,
        retry_after: int | None = None,
        **kwargs,
    ) -> None:
        self.retry_after = retry_after
        super().__init__(message, status_code=429, **kwargs)


class ConfigError(FibinaciError):
    """Raised when SDK configuration is invalid."""
