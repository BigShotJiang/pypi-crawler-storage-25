"""Pytest fixtures for Fibinaci SDK testing."""
from __future__ import annotations

import pytest

from fibinaci._testing.mock_client import MockFibinaci


@pytest.fixture
def mock_fibinaci():
    """Pytest fixture that provides a MockFibinaci instance.

    Automatically tears down after the test.

    Usage::

        def test_my_workflow(mock_fibinaci):
            # ... run code that uses fibinaci ...
            spans = mock_fibinaci.get_spans()
            assert len(spans) == 1
    """
    mock = MockFibinaci()
    yield mock
    mock.teardown()
