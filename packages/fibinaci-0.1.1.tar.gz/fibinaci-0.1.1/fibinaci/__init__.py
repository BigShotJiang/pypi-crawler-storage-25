"""Fibinaci Python SDK — universal AI activity data layer."""
from fibinaci._version import __version__
from fibinaci.client import AsyncFibinaci, Fibinaci
from fibinaci.tracing.context import outcome, span, trace
from fibinaci.tracing.decorators import observe


def instrument(**kwargs) -> None:
    """Auto-instrument detected AI libraries (OpenAI, Anthropic, etc.)."""
    from fibinaci.instrumentation import instrument as _instrument
    _instrument(**kwargs)


__all__ = [
    "__version__",
    "Fibinaci",
    "AsyncFibinaci",
    "instrument",
    "trace",
    "span",
    "outcome",
    "observe",
]
