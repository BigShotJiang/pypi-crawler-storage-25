"""Base class for library instrumentors."""
from __future__ import annotations

from abc import ABC, abstractmethod


class BaseInstrumentor(ABC):
    @abstractmethod
    def instrument(self) -> None:
        ...

    @abstractmethod
    def uninstrument(self) -> None:
        ...
