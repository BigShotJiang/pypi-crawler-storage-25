"""Track which libraries have been instrumented."""
from __future__ import annotations

from fibinaci.instrumentation._base import BaseInstrumentor


class InstrumentationRegistry:
    def __init__(self) -> None:
        self._instruments: dict[str, BaseInstrumentor] = {}

    def register(self, name: str, instrumentor: BaseInstrumentor) -> None:
        self._instruments[name] = instrumentor

    def is_instrumented(self, name: str) -> bool:
        return name in self._instruments

    def uninstrument_all(self) -> None:
        for name, inst in list(self._instruments.items()):
            try:
                inst.uninstrument()
            except Exception:
                pass
        self._instruments.clear()
