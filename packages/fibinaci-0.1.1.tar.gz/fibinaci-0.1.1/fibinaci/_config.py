"""SDK configuration loaded from environment variables or constructor args."""
from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass
class FibinaciConfig:
    api_key: str = ""
    base_url: str = "https://api.fibinaci.com"
    environment: str = "production"
    flush_interval: float = 5.0  # seconds
    flush_size: int = 100  # spans
    max_buffer_size: int = 10_000
    timeout: float = 30.0
    max_retries: int = 3
    encryption_key_path: str | None = None
    debug: bool = False

    def __post_init__(self) -> None:
        self.api_key = self.api_key or os.environ.get("FIBINACI_API_KEY", "")
        self.base_url = self.base_url or os.environ.get("FIBINACI_BASE_URL", "https://api.fibinaci.com")
        self.environment = self.environment or os.environ.get("FIBINACI_ENVIRONMENT", "production")
        self.encryption_key_path = self.encryption_key_path or os.environ.get("FIBINACI_ENCRYPTION_KEY_PATH")
        self.debug = self.debug or os.environ.get("FIBINACI_DEBUG", "").lower() in ("1", "true")
        # Strip trailing slash
        self.base_url = self.base_url.rstrip("/")
