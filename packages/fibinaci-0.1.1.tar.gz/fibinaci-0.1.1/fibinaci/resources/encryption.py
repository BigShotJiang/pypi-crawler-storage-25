from __future__ import annotations

from typing import Any

from fibinaci.resources.base import AsyncResource, SyncResource


class Encryption(SyncResource):
    def create_key(self, *, public_key: str, algorithm: str, key_id: str | None = None) -> dict:
        body: dict[str, Any] = {"public_key": public_key, "algorithm": algorithm}
        if key_id is not None:
            body["key_id"] = key_id
        return self._post("/v1/encryption-keys", body=body)

    def verify(self, *, event_id: str, payload: dict | None = None) -> dict:
        body: dict[str, Any] = {"event_id": event_id}
        if payload is not None:
            body["payload"] = payload
        return self._post("/v1/verify", body=body)


class AsyncEncryption(AsyncResource):
    async def create_key(self, *, public_key: str, algorithm: str, key_id: str | None = None) -> dict:
        body: dict[str, Any] = {"public_key": public_key, "algorithm": algorithm}
        if key_id is not None:
            body["key_id"] = key_id
        return await self._post("/v1/encryption-keys", body=body)

    async def verify(self, *, event_id: str, payload: dict | None = None) -> dict:
        body: dict[str, Any] = {"event_id": event_id}
        if payload is not None:
            body["payload"] = payload
        return await self._post("/v1/verify", body=body)
