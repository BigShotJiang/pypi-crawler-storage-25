from __future__ import annotations

from typing import Any

from fibinaci.resources.base import AsyncResource, SyncResource


class Export(SyncResource):
    def spans(self, *, started_at_gte: str, started_at_lte: str, **kwargs: Any) -> dict:
        return self._get("/v1/export/spans", **{"started_at[gte]": started_at_gte, "started_at[lte]": started_at_lte, **kwargs})

    def traces(self, *, started_at_gte: str, started_at_lte: str, **kwargs: Any) -> dict:
        return self._get("/v1/export/traces", **{"started_at[gte]": started_at_gte, "started_at[lte]": started_at_lte, **kwargs})

    def create_job(self, *, resource_type: str, started_at_gte: str, started_at_lte: str, **kwargs: Any) -> dict:
        return self._post("/v1/export/jobs", body={
            "resource_type": resource_type,
            "started_at_gte": started_at_gte,
            "started_at_lte": started_at_lte,
            **kwargs,
        })

    def get_job(self, job_id: str) -> dict:
        return self._get(f"/v1/export/jobs/{job_id}")

    def list_jobs(self, **kwargs: Any) -> dict:
        return self._get("/v1/export/jobs", **kwargs)


class AsyncExport(AsyncResource):
    async def spans(self, *, started_at_gte: str, started_at_lte: str, **kwargs: Any) -> dict:
        return await self._get("/v1/export/spans", **{"started_at[gte]": started_at_gte, "started_at[lte]": started_at_lte, **kwargs})

    async def traces(self, *, started_at_gte: str, started_at_lte: str, **kwargs: Any) -> dict:
        return await self._get("/v1/export/traces", **{"started_at[gte]": started_at_gte, "started_at[lte]": started_at_lte, **kwargs})

    async def create_job(self, *, resource_type: str, started_at_gte: str, started_at_lte: str, **kwargs: Any) -> dict:
        return await self._post("/v1/export/jobs", body={
            "resource_type": resource_type,
            "started_at_gte": started_at_gte,
            "started_at_lte": started_at_lte,
            **kwargs,
        })

    async def get_job(self, job_id: str) -> dict:
        return await self._get(f"/v1/export/jobs/{job_id}")

    async def list_jobs(self, **kwargs: Any) -> dict:
        return await self._get("/v1/export/jobs", **kwargs)
