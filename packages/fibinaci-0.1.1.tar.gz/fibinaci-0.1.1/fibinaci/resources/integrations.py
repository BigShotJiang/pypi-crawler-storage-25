from __future__ import annotations

from typing import Any

from fibinaci.resources.base import AsyncResource, SyncResource


class Integrations(SyncResource):
    def create(self, *, provider: str, bucket_name: str, **kwargs: Any) -> dict:
        return self._post("/v1/integrations/blob-storage", body={"provider": provider, "bucket_name": bucket_name, **kwargs})

    def list(self) -> dict:
        return self._get("/v1/integrations/blob-storage")

    def get(self, integration_id: str) -> dict:
        return self._get(f"/v1/integrations/blob-storage/{integration_id}")

    def update(self, integration_id: str, **kwargs: Any) -> dict:
        return self._patch(f"/v1/integrations/blob-storage/{integration_id}", body=kwargs)

    def delete(self, integration_id: str) -> None:
        self._delete(f"/v1/integrations/blob-storage/{integration_id}")

    def test(self, integration_id: str) -> dict:
        return self._post(f"/v1/integrations/blob-storage/{integration_id}/test")


class AsyncIntegrations(AsyncResource):
    async def create(self, *, provider: str, bucket_name: str, **kwargs: Any) -> dict:
        return await self._post("/v1/integrations/blob-storage", body={"provider": provider, "bucket_name": bucket_name, **kwargs})

    async def list(self) -> dict:
        return await self._get("/v1/integrations/blob-storage")

    async def get(self, integration_id: str) -> dict:
        return await self._get(f"/v1/integrations/blob-storage/{integration_id}")

    async def update(self, integration_id: str, **kwargs: Any) -> dict:
        return await self._patch(f"/v1/integrations/blob-storage/{integration_id}", body=kwargs)

    async def delete(self, integration_id: str) -> None:
        await self._delete(f"/v1/integrations/blob-storage/{integration_id}")

    async def test(self, integration_id: str) -> dict:
        return await self._post(f"/v1/integrations/blob-storage/{integration_id}/test")
