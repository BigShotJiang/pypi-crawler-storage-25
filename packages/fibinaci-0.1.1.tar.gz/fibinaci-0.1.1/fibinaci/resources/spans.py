from __future__ import annotations

import builtins
from typing import Any

from fibinaci.resources.base import AsyncResource, SyncResource


class Spans(SyncResource):
    def list(self, *, cursor: str | None = None, limit: int = 100, **filters: Any) -> dict:
        return self._get("/v1/spans", cursor=cursor, limit=limit, **filters)

    def get(self, span_id: str) -> dict:
        return self._get(f"/v1/spans/{span_id}")

    def create(self, span: dict) -> dict:
        return self._post("/v1/spans", body=span)

    def create_batch(self, spans: builtins.list[dict]) -> dict:
        return self._post("/v1/spans/batch", body={"spans": spans})

    def ingest_events(self, events: builtins.list[dict]) -> dict:
        return self._post("/v1/events", body={"events": events})

    def ingest_otel(self, body: dict) -> dict:
        return self._post("/v1/otel", body=body)


class AsyncSpans(AsyncResource):
    async def list(self, *, cursor: str | None = None, limit: int = 100, **filters: Any) -> dict:
        return await self._get("/v1/spans", cursor=cursor, limit=limit, **filters)

    async def get(self, span_id: str) -> dict:
        return await self._get(f"/v1/spans/{span_id}")

    async def create(self, span: dict) -> dict:
        return await self._post("/v1/spans", body=span)

    async def create_batch(self, spans: builtins.list[dict]) -> dict:
        return await self._post("/v1/spans/batch", body={"spans": spans})

    async def ingest_events(self, events: builtins.list[dict]) -> dict:
        return await self._post("/v1/events", body={"events": events})

    async def ingest_otel(self, body: dict) -> dict:
        return await self._post("/v1/otel", body=body)
