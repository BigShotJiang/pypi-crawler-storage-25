from __future__ import annotations

from typing import Any

from fibinaci.resources.base import AsyncResource, SyncResource


class Annotations(SyncResource):
    def create(self, span_id: str, *, label: str, **kwargs) -> dict:
        return self._post(f"/v1/spans/{span_id}/annotations", body={"label": label, **kwargs})

    def list(self, *, cursor: str | None = None, limit: int = 100, **filters: Any) -> dict:
        return self._get("/v1/annotations", cursor=cursor, limit=limit, **filters)


class AsyncAnnotations(AsyncResource):
    async def create(self, span_id: str, *, label: str, **kwargs) -> dict:
        return await self._post(f"/v1/spans/{span_id}/annotations", body={"label": label, **kwargs})

    async def list(self, *, cursor: str | None = None, limit: int = 100, **filters: Any) -> dict:
        return await self._get("/v1/annotations", cursor=cursor, limit=limit, **filters)
