from __future__ import annotations

from fibinaci.resources.base import AsyncResource, SyncResource


class Outcomes(SyncResource):
    def create(self, trace_id: str, *, success: bool, **kwargs) -> dict:
        return self._post(f"/v1/traces/{trace_id}/outcome", body={"success": success, **kwargs})

    def get(self, trace_id: str) -> dict:
        return self._get(f"/v1/traces/{trace_id}/outcome")


class AsyncOutcomes(AsyncResource):
    async def create(self, trace_id: str, *, success: bool, **kwargs) -> dict:
        return await self._post(f"/v1/traces/{trace_id}/outcome", body={"success": success, **kwargs})

    async def get(self, trace_id: str) -> dict:
        return await self._get(f"/v1/traces/{trace_id}/outcome")
