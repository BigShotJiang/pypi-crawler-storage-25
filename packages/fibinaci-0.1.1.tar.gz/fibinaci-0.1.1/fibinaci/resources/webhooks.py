from __future__ import annotations


from fibinaci.resources.base import AsyncResource, SyncResource


class Webhooks(SyncResource):
    def create(self, *, url: str, events: list[str], **kwargs) -> dict:
        return self._post("/v1/webhooks", body={"url": url, "events": events, **kwargs})

    def list(self) -> dict:
        return self._get("/v1/webhooks")

    def get(self, webhook_id: str) -> dict:
        return self._get(f"/v1/webhooks/{webhook_id}")

    def update(self, webhook_id: str, **kwargs) -> dict:
        return self._patch(f"/v1/webhooks/{webhook_id}", body=kwargs)

    def delete(self, webhook_id: str) -> None:
        self._delete(f"/v1/webhooks/{webhook_id}")

    def test(self, webhook_id: str, event_type: str = "span.created") -> dict:
        return self._post(f"/v1/webhooks/{webhook_id}/test", body={"event_type": event_type})


class AsyncWebhooks(AsyncResource):
    async def create(self, *, url: str, events: list[str], **kwargs) -> dict:
        return await self._post("/v1/webhooks", body={"url": url, "events": events, **kwargs})

    async def list(self) -> dict:
        return await self._get("/v1/webhooks")

    async def get(self, webhook_id: str) -> dict:
        return await self._get(f"/v1/webhooks/{webhook_id}")

    async def update(self, webhook_id: str, **kwargs) -> dict:
        return await self._patch(f"/v1/webhooks/{webhook_id}", body=kwargs)

    async def delete(self, webhook_id: str) -> None:
        await self._delete(f"/v1/webhooks/{webhook_id}")

    async def test(self, webhook_id: str, event_type: str = "span.created") -> dict:
        return await self._post(f"/v1/webhooks/{webhook_id}/test", body={"event_type": event_type})
