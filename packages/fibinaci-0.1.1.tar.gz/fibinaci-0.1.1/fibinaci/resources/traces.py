from __future__ import annotations

from typing import Any

from fibinaci.resources.base import AsyncResource, SyncResource


class Traces(SyncResource):
    def list(self, *, cursor: str | None = None, limit: int = 100, expand: str | None = None, **filters: Any) -> dict:
        return self._get("/v1/traces", cursor=cursor, limit=limit, expand=expand, **filters)

    def get(self, trace_id: str, *, expand: str | None = None) -> dict:
        return self._get(f"/v1/traces/{trace_id}", expand=expand)


class AsyncTraces(AsyncResource):
    async def list(self, *, cursor: str | None = None, limit: int = 100, expand: str | None = None, **filters: Any) -> dict:
        return await self._get("/v1/traces", cursor=cursor, limit=limit, expand=expand, **filters)

    async def get(self, trace_id: str, *, expand: str | None = None) -> dict:
        return await self._get(f"/v1/traces/{trace_id}", expand=expand)
