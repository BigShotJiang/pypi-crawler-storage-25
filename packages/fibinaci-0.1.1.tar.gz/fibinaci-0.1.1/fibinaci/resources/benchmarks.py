from __future__ import annotations


from fibinaci.resources.base import AsyncResource, SyncResource


class Benchmarks(SyncResource):
    def model_latency(self, *, model: str | None = None, provider: str | None = None, period: str = "24h") -> dict:
        return self._get("/v1/benchmarks/model-latency", model=model, provider=provider, period=period)

    def cost_per_outcome(self, *, use_case: str | None = None, period: str = "30d") -> dict:
        return self._get("/v1/benchmarks/cost-per-outcome", use_case=use_case, period=period)

    def model_drift(self, *, model: str | None = None, period: str = "7d") -> dict:
        return self._get("/v1/benchmarks/model-drift", model=model, period=period)


class AsyncBenchmarks(AsyncResource):
    async def model_latency(self, *, model: str | None = None, provider: str | None = None, period: str = "24h") -> dict:
        return await self._get("/v1/benchmarks/model-latency", model=model, provider=provider, period=period)

    async def cost_per_outcome(self, *, use_case: str | None = None, period: str = "30d") -> dict:
        return await self._get("/v1/benchmarks/cost-per-outcome", use_case=use_case, period=period)

    async def model_drift(self, *, model: str | None = None, period: str = "7d") -> dict:
        return await self._get("/v1/benchmarks/model-drift", model=model, period=period)
