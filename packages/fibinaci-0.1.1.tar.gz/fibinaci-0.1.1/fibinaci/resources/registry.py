from __future__ import annotations

from fibinaci.resources.base import AsyncResource, SyncResource


class Registry(SyncResource):
    def span_kinds(self) -> dict:
        return self._get("/v1/registry/span-kinds")

    def providers(self) -> dict:
        return self._get("/v1/registry/providers")

    def tool_types(self) -> dict:
        return self._get("/v1/registry/tool-types")


class AsyncRegistry(AsyncResource):
    async def span_kinds(self) -> dict:
        return await self._get("/v1/registry/span-kinds")

    async def providers(self) -> dict:
        return await self._get("/v1/registry/providers")

    async def tool_types(self) -> dict:
        return await self._get("/v1/registry/tool-types")
