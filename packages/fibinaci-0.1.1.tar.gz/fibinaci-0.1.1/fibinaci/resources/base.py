"""Base resource with shared HTTP helpers."""
from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from fibinaci.client import AsyncFibinaci, Fibinaci


class SyncResource:
    """Base for synchronous resources."""

    def __init__(self, client: Fibinaci) -> None:
        self._client = client

    def _get(self, path: str, **params: Any) -> Any:
        return self._client.request("GET", path, params={k: v for k, v in params.items() if v is not None})

    def _post(self, path: str, body: dict | None = None, **kwargs: Any) -> Any:
        return self._client.request("POST", path, json=body, **kwargs)

    def _patch(self, path: str, body: dict) -> Any:
        return self._client.request("PATCH", path, json=body)

    def _delete(self, path: str) -> Any:
        return self._client.request("DELETE", path)


class AsyncResource:
    """Base for asynchronous resources."""

    def __init__(self, client: AsyncFibinaci) -> None:
        self._client = client

    async def _get(self, path: str, **params: Any) -> Any:
        return await self._client.request("GET", path, params={k: v for k, v in params.items() if v is not None})

    async def _post(self, path: str, body: dict | None = None, **kwargs: Any) -> Any:
        return await self._client.request("POST", path, json=body, **kwargs)

    async def _patch(self, path: str, body: dict) -> Any:
        return await self._client.request("PATCH", path, json=body)

    async def _delete(self, path: str) -> Any:
        return await self._client.request("DELETE", path)
