from __future__ import annotations

from fibinaci.resources.base import AsyncResource, SyncResource


class ApiKeys(SyncResource):
    def create(self, *, name: str, environment: str, **kwargs) -> dict:
        return self._post("/v1/api-keys", body={"name": name, "environment": environment, **kwargs})

    def list(self) -> dict:
        return self._get("/v1/api-keys")

    def revoke(self, key_id: str) -> None:
        self._delete(f"/v1/api-keys/{key_id}")


class AsyncApiKeys(AsyncResource):
    async def create(self, *, name: str, environment: str, **kwargs) -> dict:
        return await self._post("/v1/api-keys", body={"name": name, "environment": environment, **kwargs})

    async def list(self) -> dict:
        return await self._get("/v1/api-keys")

    async def revoke(self, key_id: str) -> None:
        await self._delete(f"/v1/api-keys/{key_id}")
