from __future__ import annotations

from typing import Any

from fibinaci.resources.base import AsyncResource, SyncResource


class Usage(SyncResource):
    def get(self, **kwargs: Any) -> dict:
        return self._get("/v1/usage", **kwargs)

    def current_period(self) -> dict:
        return self._get("/v1/usage/current-period")


class AsyncUsage(AsyncResource):
    async def get(self, **kwargs: Any) -> dict:
        return await self._get("/v1/usage", **kwargs)

    async def current_period(self) -> dict:
        return await self._get("/v1/usage/current-period")
