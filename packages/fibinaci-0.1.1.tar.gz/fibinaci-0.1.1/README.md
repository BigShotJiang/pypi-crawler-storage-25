# fibinaci

Python SDK for [Fibinaci](https://fibinaci.com) — universal AI activity data layer.

## Install

```bash
pip install fibinaci
```

## Quick start

```python
import fibinaci

# Auto-instrument OpenAI, Anthropic, etc.
fibinaci.instrument()

# Or use manual tracing
from fibinaci import trace, span, outcome

with trace("my-workflow"):
    with span("step-1", span_kind="model_call"):
        pass
    outcome(success=True, score=0.95)
```

## Configuration

Set via environment variables or pass to client:

```bash
export FIBINACI_API_KEY=fib_live_sk_...
export FIBINACI_BASE_URL=https://api.fibinaci.com  # default
```

```python
from fibinaci import Fibinaci

client = Fibinaci(api_key="fib_live_sk_...")
traces = client.traces.list()
```

## Testing

```python
from fibinaci._testing import MockFibinaci

mock = MockFibinaci()
# ... run your code ...
spans = mock.get_spans()
assert len(spans) == 3
```
