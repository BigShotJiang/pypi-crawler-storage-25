import logging
from typing import Dict, List, Any, Optional,Callable,Awaitable
import uuid
import time
from datetime import datetime
import inspect
import aiohttp
from ..model.device_status import NodeExecutionResult,WorkflowExecutionResponse,WorkflowExecutionRequest,ExecutionConfig

# 导入上面两个文件的内容
# 假设 model_workflow.py 定义了 Base, WorkflowTemplate, WorkflowNode 等
# 假设 workflow_dataclasses.py 定义了 ExecutionConfig, WorkflowExecutionRequest 等

class WorkflowExecutor:
    """工作流执行引擎"""
    async def execute_workflow(
            self,
            request: WorkflowExecutionRequest,
            current_mqtt_data,
            device_id: Optional[str] = None,
            get_realtime_image: Optional[Callable[[str], Awaitable[Dict]]] = None,
            call_edge_model: Optional[Callable[[str], Awaitable[Dict]]] = None
    ) -> WorkflowExecutionResponse:
        """执行工作流"""
        success = True
        execution_id = request.execution_id or str(uuid.uuid4())
        start_time = time.time()
        execution_record = {
            'template_id':request.template_id,
            'execution_id':execution_id,
            'model_mappings':{
                node_name: {
                    'model_id': mapping.model_id,
                    'endpoint': mapping.endpoint
                }
                for node_name, mapping in request.execution_config.model_mappings.items()
            },
            'parameter_overrides':request.execution_config.parameter_overrides,
            'status':'running',
            'input_data':request.input_data,
            'start_time':datetime.utcnow()
        }

        node_results = {}

        try:
            # 工作流模板
            template = request.template
            if not template:
                raise ValueError(f"工作流模板 {request.template_id} 不存在")

            # 按执行顺序获取节点
            nodes = sorted(template['nodes'], key=lambda n: n['execution_order'])

            # 构建执行上下文
            context = {
                'workflow_input': request.input_data,
                'device_id': device_id,  # 直接传递device_id
                '_get_realtime_image': get_realtime_image # 将函数放入上下文
            }
            # 预处理连接关系，构建每个节点的输入源映射
            connections_map = self._build_connections_map(template.get('connections', []))
            # 执行每个节点
            for node in nodes:
                # 将连接关系添加到节点上下文中
                node_connections = connections_map.get(node['name'], [])
                node['target_connections'] = node_connections  # 临时添加到节点，供_build_node_input使用

                node_result = await self._execute_node(
                    device_id,
                    node,
                    context,
                    execution_record,
                    request.execution_config,
                    current_mqtt_data,call_edge_model
                )

                node_results[node['name']] = node_result

                # 更新上下文
                if node_result.success and node_result.data:
                    # 将节点输出按 outputs 定义的格式存入上下文
                    context[node['name']] = node_result.data

                    # 同时也将各个输出字段单独存入上下文，方便直接引用
                    for field_name, field_value in node_result.data.items():
                        context[f"{node['name']}.{field_name}"] = field_value

                # 检查是否需要停止
                if not node_result.success and not node['skip_on_failure']:
                    execution_record['status'] = 'failed'
                    execution_record['error_message'] = f"节点 {node.name} 执行失败: {node_result.error}"
                    break

            # 构建最终输出
            final_output = self._build_final_output(template, context)

            # 更新执行记录
            # execution_record['status'] = 'completed'
            # execution_record['output_data'] = final_output
            # execution_record['end_time'] = datetime.utcnow()
            # execution_record['total_duration'] = (
            #         execution_record['end_time'] - execution_record['start_time']
            # ).total_seconds()
            #
            # success = execution_record['status'] == 'completed'

        except Exception as e:
            execution_record['status'] = 'failed'
            execution_record['error_message'] = str(e)
            execution_record['end_time'] = datetime.utcnow()
            success = False
            final_output = None


        # 构建响应
        return WorkflowExecutionResponse(
            success=success,
            execution_id=execution_id,
            data=final_output,
            error=execution_record.get('error_message',None),
            execution_time=time.time() - start_time,
            node_results=node_results
        )

    def _build_connections_map(self, connections: List[Dict]) -> Dict[str, List[Dict]]:
        """
        构建节点连接映射
        返回格式: {target_node_name: [connection_configs]}
        """
        connections_map = {}
        for conn in connections:
            target_node = conn['target_node_name']
            if target_node not in connections_map:
                connections_map[target_node] = []

            # 构建连接配置
            conn_config = {
                'source_node_name': conn['source_node_name'],
                'source_output': conn['source_output'],
                'target_input': conn['target_input'],
                'transform_script': conn.get('transform_script'),
                'condition': conn.get('condition')
            }
            connections_map[target_node].append(conn_config)

        return connections_map

    async def _execute_node(self,device_id,
                            node: Dict[str, Any],
                            context: Dict[str, Any],
                            execution_record: Dict[str, Any],
                            execution_config: ExecutionConfig,
                            current_mqtt_data: Dict[str, Any],call_edge_model) -> NodeExecutionResult:
        """执行单个节点"""

        start_time = time.time()

        try:
            # 检查执行条件
            if node['condition']:
                if not self._evaluate_condition(node['condition'], context):
                    # 创建节点执行记录（跳过）
                    self._create_node_execution_record(
                        node, execution_record, execution_config,
                        status='skipped', start_time=datetime.utcnow()
                    )

                    return NodeExecutionResult(
                        node_name=node['name'],
                        success=True,
                        data={},
                        execution_time=0.0
                    )

            # 获取该节点的模型配置
            model_mapping = execution_config.model_mappings.get(node['name'])
            if not model_mapping:
                raise ValueError(f"节点 '{node['name']}' 未配置模型映射")

            # 构建节点输入
            node_input = self._build_node_input(node, context)

            # 合并参数
            actual_parameters = node.get('default_parameters', {}).copy()
            if node['name'] in execution_config.parameter_overrides:
                actual_parameters.update(execution_config.parameter_overrides[node['name']])
            if model_mapping.parameters_override:
                actual_parameters.update(model_mapping.parameters_override)

            # 创建节点执行记录
            node_execution = self._create_node_execution_record(
                node, execution_record, execution_config,
                status='running',
                start_time=datetime.utcnow(),
                input_data=node_input,
                actual_parameters=actual_parameters
            )

            # 执行调用模型（这里调用您的模型调用逻辑）
            model_output = await self._call_model(
                device_id,
                model_mapping.model_type,
                model_mapping.model_id,
                model_mapping.endpoint,
                node_input,
                actual_parameters,
                node['timeout'] or 30,
                call_edge_model
            )
            # 根据节点配置的 outputs 字段格式化输出
            formatted_output = self._format_node_output(node, model_output)

            # 应用输出映射（如果配置了 output_mapping）
            if node.get('output_mapping'):
                mapped_output = {}
                for source_key, target_key in node['output_mapping'].items():
                    # 支持嵌套字段访问
                    value = self._get_nested_value(formatted_output, source_key)
                    if value is not None:
                        mapped_output[target_key] = value
                    else:
                        logging.warning(f"节点 {node['name']} 输出映射: 源字段 {source_key} 不存在")
                formatted_output = mapped_output

            # 更新节点执行记录
            # node_execution['status'] = 'completed'
            # node_execution['output_data'] = model_output
            # node_execution['end_time'] = datetime.utcnow()
            # node_execution['duration'] = (node_execution.end_time - node_execution.start_time).total_seconds()


            return NodeExecutionResult(
                node_name=node['name'],
                success=True,
                model_id=model_mapping.model_id,
                endpoint_url=model_mapping.endpoint,
                data=model_output,
                execution_time=time.time() - start_time
            )

        except Exception as e:
            logging.error(f"执行节点报错：{e}")
            # 更新节点执行记录为失败
            # if 'node_execution' in locals():
            #     node_execution.status = 'failed'
            #     node_execution.error_message = str(e)
            #     node_execution.end_time = datetime.utcnow()

            return NodeExecutionResult(
                node_name=node['name'],
                success=False,
                model_id=model_mapping.model_id if 'model_mapping' in locals() else None,
                endpoint_url=model_mapping.endpoint if 'model_mapping' in locals() else None,
                error=str(e),
                execution_time=time.time() - start_time
            )

    def _format_node_output(self, node: Dict[str, Any], model_output: Dict[str, Any]) -> Dict[str, Any]:
        """
        根据节点配置的 outputs 字段格式化输出

        Args:
            node: 节点配置
            model_output: 模型原始输出

        Returns:
            格式化后的输出，只包含节点 outputs 中定义的字段

        Raises:
            ValueError: 当模型输出缺少节点定义的必需字段时
        """
        formatted_output = {}

        # 获取节点定义的输出字段
        node_outputs = node.get('outputs', [])

        if not node_outputs:
            # 如果没有定义 outputs，返回原始输出
            logging.warning(f"节点 {node['name']} 未定义 outputs，直接返回模型输出")
            return model_output

        # 根据 outputs 定义提取字段
        missing_fields = []
        for output_field in node_outputs:
            field_name = output_field.get('name')
            if not field_name:
                continue

            required = output_field.get('required', True)

            # 从模型输出中获取对应字段
            if field_name in model_output:
                formatted_output[field_name] = model_output[field_name]
            else:
                if required:
                    missing_fields.append(field_name)
                else:
                    # 可选字段，使用默认值
                    data_type = output_field.get('data_type', 'string')
                    formatted_output[field_name] = self._get_default_value_for_type(data_type)
                    logging.warning(f"节点 {node['name']} 可选输出字段 '{field_name}' 未在模型输出中找到，使用默认值")

        # 如果有必需的字段缺失，抛出错误
        if missing_fields:
            error_msg = f"节点 {node['name']} 模型输出缺少必需字段: {missing_fields}. 模型实际输出字段: {list(model_output.keys())}"
            logging.error(error_msg)
            raise ValueError(error_msg)

        # 检查是否有多余的字段（可选，用于调试）
        extra_fields = set(model_output.keys()) - set(formatted_output.keys())
        if extra_fields:
            logging.debug(f"节点 {node['name']} 模型输出包含未定义的字段: {extra_fields}")

        return formatted_output

    def _get_default_value_for_type(self, data_type: str) -> Any:
        """
        根据数据类型返回默认值
        """
        default_values = {
            'string': '',
            'number': 0,
            'integer': 0,
            'float': 0.0,
            'boolean': False,
            'array': [],
            'object': {},
            'any': None
        }
        return default_values.get(data_type, None)
    def _get_nested_value(self, data: Dict[str, Any], key_path: str) -> Any:
        """
        获取嵌套字典中的值
        例如: "results.data" 会获取 data['results']['data']
        """
        try:
            if '.' not in key_path:
                return data.get(key_path)

            parts = key_path.split('.')
            current = data
            for part in parts:
                if isinstance(current, dict) and part in current:
                    current = current[part]
                else:
                    return None
            return current
        except Exception as e:
            logging.error(f"获取嵌套值失败: {key_path}, 错误: {e}")
            return None

    def _create_node_execution_record(self,
                                      node: Dict[str, Any],
                                      execution_record: Dict[str, Any],
                                      execution_config: Dict[str, Any],
                                      status: str,
                                      start_time: datetime,
                                      input_data: Optional[Dict] = None,
                                      actual_parameters: Optional[Dict] = None) :
        """创建节点执行记录"""

        model_mapping = execution_config.model_mappings.get(node['name'])

        return {}

    def _build_node_input(self, node: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        """
        构建节点输入，严格按照 input_mapping 和 connections 配置
        """
        input_data = {}
        missing_sources = []

        # 处理 input_mapping
        if node.get('input_mapping'):
            for target_key, source_key in node['input_mapping'].items():
                value = self._parse_source_key(source_key, context)
                if value is not None:
                    input_data[target_key] = value
                else:
                    # 检查是否是必需字段
                    # 这里可以根据节点的 inputs 定义来判断是否必需
                    missing_sources.append(source_key)

        # 处理 connections
        if 'connections' in node:
            for conn in node['connections']:
                source_node_name = conn.get('source_node_name')
                source_output = conn.get('source_output')
                target_input = conn.get('target_input')

                if source_node_name in context:
                    source_data = context[source_node_name]

                    if source_output:
                        value = self._get_nested_value(source_data, source_output)
                        if value is None:
                            error_msg = f"节点 {node['name']} 从源节点 {source_node_name} 获取字段 {source_output} 失败，源节点输出: {source_data}"
                            logging.error(error_msg)
                            raise ValueError(error_msg)
                    else:
                        value = source_data

                    if target_input:
                        input_data[target_input] = value
                    else:
                        if isinstance(value, dict):
                            input_data.update(value)
                        else:
                            input_data['data'] = value
                else:
                    missing_sources.append(source_node_name)

        # 如果有缺失的数据源，抛出错误
        if missing_sources:
            error_msg = f"节点 {node['name']} 缺少必需的数据源: {missing_sources}"
            logging.error(error_msg)
            raise ValueError(error_msg)

        logging.debug(f"节点 {node['name']} 构建的输入: {input_data}")
        return input_data

    def _parse_source_key(self, source_key: str, context: Dict[str, Any]) -> Any:
        """
        解析数据源键，支持多种格式：
        1. device.image.url          # 设备图像URL
        2. device.image.data         # 设备图像base64数据
        3. node_name.field_name      # 其他节点输出字段
        4. workflow_input.field      # 工作流输入参数
        """
        try:
            if '.' not in source_key:
                # 简写形式
                if source_key in context.get("workflow_input", {}):
                    return context["workflow_input"][source_key]
                # 尝试从节点输出中查找
                if source_key in context:
                    return context[source_key]
                return None

            parts = source_key.split('.')
            root = parts[0]

            if root == "device":
                # 设备数据处理
                if len(parts) >= 3:
                    data_type = parts[1]  # image 或 audio
                    field = parts[2]  # url, data, timestamp 等
                    device_id = context.get('device_id')
                    get_realtime_image = context.get('_get_realtime_image')

                    if data_type == 'image' and device_id and get_realtime_image:
                        # 检查 get_realtime_image 是否是协程函数
                        if inspect.iscoroutinefunction(get_realtime_image):
                            # 这是一个问题：_parse_source_key 是同步方法，不能直接 await
                            # 需要从上层传入已经获取好的图像数据
                            logging.error("在同步方法中无法调用异步函数 get_realtime_image")
                            return None
                        else:
                            # 同步调用
                            image_data = get_realtime_image(device_id)
                            if field == 'url':
                                return image_data.get('url')
                            elif field == 'data':
                                return image_data.get('data')
                            elif field == 'timestamp':
                                return image_data.get('timestamp')
                            else:
                                return image_data.get(field)

            elif root == "workflow_input":
                # 工作流输入参数
                workflow_input = context.get("workflow_input", {})
                if len(parts) == 2:
                    return workflow_input.get(parts[1])

            else:
                # 其他节点输出
                node_name = parts[0]
                field_name = '.'.join(parts[1:])  # 支持嵌套字段

                if node_name in context:
                    node_output = context[node_name]
                    # 获取嵌套字段的值
                    return self._get_nested_value(node_output, field_name)

            return None

        except Exception as e:
            logging.error(f"解析source_key失败: {source_key}, 错误: {e}")
            return None

    def _build_final_output(self, template: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        """构建最终输出"""
        if template['output_schema']:
            # 根据输出schema构建输出
            output = {}
            for field, config in template['output_schema'].items():
                source = config.get('source', '')
                if '.' in source:
                    node_name, output_field = source.split('.', 1)
                    if node_name in context and output_field in context[node_name]:
                        output[field] = context[node_name][output_field]
        else:
            # 默认输出最后一个节点的输出
            last_node = template['nodes'][-1]
            output = context.get(last_node.name, {})

        # 添加执行元数据
        output['_metadata'] = {
            'workflow_id': template['id'],
            'workflow_name': template['name'],
            'version': template['version'],
            'execution_time': datetime.utcnow().isoformat()
        }

        return output

    def _evaluate_condition(self, condition: str, context: Dict[str, Any]) -> bool:
        """评估执行条件"""
        try:
            # 安全地评估条件表达式
            return eval(condition, {"__builtins__": {}}, context)
        except:
            return False

    async def _call_model(self,
                          device_id,
                          model_type: str,
                          model_id: str,
                          endpoint: str,
                          input_data: Dict[str, Any],
                          parameters: Dict[str, Any],
                          timeout: int,call_edge_model) -> Dict[str, Any]:
        """
            动态调用模型，适配任意工作流配置

            参数：
            - input_data: 已经通过input_mapping处理好的数据，字段名由工作流定义
            - parameters: 模型参数（来自default_parameters和parameter_overrides）

            返回：
            - 模型输出数据，字段名和结构由模型决定
        """
        try:

            # 构建模型调用所需的输入格式
            model_input = input_data.copy()
            # 如果有参数覆盖，合并到输入中
            if parameters:
                model_input['parameters'] = parameters

                # 构建模型映射配置
            model_mapping = {
                "edge_url": endpoint,
                "model_id": model_id,
                "timeout": timeout
            }
            logging.info(f"调用模型 - ID: {model_id}, 端点: {endpoint}")
            logging.debug(f"模型输入数据: {input_data}")

            # 调用边缘模型
            result = None
            if model_type == 'chat-completion':
                # 构建 OpenAI 兼容的 chat completion 请求格式
                # 处理 messages 字段
                messages = [
                    {
                        "role": "user",
                        "content": "nihao"
                    }
                ]

                # 准备 chat completion 的请求体
                chat_payload = {
                    "model": model_id,
                    "messages": messages,
                    "stream": False  # 默认不使用流式输出
                }

                # 添加可选参数
                # if 'temperature' in model_input:
                #     chat_payload['temperature'] = model_input['temperature']
                # elif parameters and 'temperature' in parameters:
                #     chat_payload['temperature'] = parameters['temperature']
                #
                # if 'max_tokens' in model_input:
                #     chat_payload['max_tokens'] = model_input['max_tokens']
                # elif parameters and 'max_tokens' in parameters:
                #     chat_payload['max_tokens'] = parameters['max_tokens']
                #
                # if 'top_p' in model_input:
                #     chat_payload['top_p'] = model_input['top_p']
                # elif parameters and 'top_p' in parameters:
                #     chat_payload['top_p'] = parameters['top_p']
                #
                # if 'frequency_penalty' in model_input:
                #     chat_payload['frequency_penalty'] = model_input['frequency_penalty']
                #
                # if 'presence_penalty' in model_input:
                #     chat_payload['presence_penalty'] = model_input['presence_penalty']

                logging.debug(f"Chat completion 请求体: {chat_payload}")

                # 构建完整的 API URL
                api_url = f"http://{endpoint}/v1/chat/completions"

                # 使用 aiohttp 发送 POST 请求
                async with aiohttp.ClientSession() as session:
                    async with session.post(
                            api_url,
                            json=chat_payload,
                            headers={"Content-Type": "application/json"},
                            timeout=aiohttp.ClientTimeout(total=timeout)
                    ) as response:
                        if response.status != 200:
                            error_text = await response.text()
                            raise Exception(f"模型调用失败，HTTP状态码: {response.status}, 错误信息: {error_text}")

                        # 解析响应
                        response_data = await response.json()

                        # 提取模型输出内容
                        # OpenAI 兼容格式的响应结构: response.choices[0].message.content
                        if 'choices' in response_data and len(response_data['choices']) > 0:
                            # result = {
                            #     "content": response_data['choices'][0]['message']['content'],
                            #     "raw_response": response_data  # 保存完整响应，以便后续处理
                            # }
                            result = response_data['choices'][0]['message']['content']
                        else:
                            # 如果响应格式不符合预期，返回原始响应
                            # result = {"raw_response": response_data}
                            result = response_data
            else:
                result = call_edge_model(device_id, model_id, model_input, model_mapping)

            # 直接返回模型结果，不做硬编码的字段处理
            # 因为工作流的output_mapping会处理字段映射
            model_output = self._extract_model_output(result)

            logging.info(f"{model_id}模型调用成功")
            logging.debug(f"模型输出: {model_output}")

            return model_output
        except Exception as e:
            raise Exception(f"模型调用失败 ({model_id}): {str(e)}")

    def _extract_model_output(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """
        从模型调用结果中提取输出数据
        保持原始结构，让output_mapping来处理字段映射
        """
        # 如果result包含标准的数据结构
        if isinstance(result, dict):
            # 如果result有data字段，优先使用data
            if 'data' in result:
                output_data = result['data']
                # 如果data是字典，直接返回
                if isinstance(output_data, dict):
                    return output_data
                # 如果data是其他类型，包装成字典
                else:
                    return {'result': output_data}
            # 如果result有output字段
            elif 'output' in result:
                return {'output': result['output']}
            # 直接返回result
            else:
                return result
        # 如果result不是字典，包装成标准格式
        else:
            return {'result': result}