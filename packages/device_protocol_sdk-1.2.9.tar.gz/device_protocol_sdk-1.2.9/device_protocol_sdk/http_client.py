# http_client.py - 完全修复版
import aiohttp
import asyncio
import json
import time
import logging
from typing import Dict, Any, Optional, List, Union
from concurrent.futures import ThreadPoolExecutor
import threading
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class EdgeCallResult:
    """边端调用结果"""
    success: bool = False
    data: Any = None
    error: str = None
    edge_url: str = None
    model_id: str = None
    execution_time: float = 0.0
    http_status: int = 0

    def __bool__(self):
        return self.success

    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            'success': self.success,
            'data': self._safe_value(self.data),
            'error': self.error,
            'edge_url': self.edge_url,
            'model_id': self.model_id,
            'execution_time': self.execution_time,
            'http_status': self.http_status
        }

    def _safe_value(self, value):
        """确保值可序列化"""
        if value is None:
            return None
        if isinstance(value, (str, int, float, bool)):
            return value
        if isinstance(value, dict):
            return {k: self._safe_value(v) for k, v in value.items()}
        if isinstance(value, list):
            return [self._safe_value(item) for item in value]
        try:
            return str(value)
        except:
            return None


class SimpleEdgeClient:
    """简单边端客户端 - 修复会话管理问题"""

    def __init__(self):
        self._executor = ThreadPoolExecutor(
            max_workers=10,
            thread_name_prefix="EdgeClient"
        )
        self._session_cache = {}
        self._cache_lock = threading.Lock()

    def _create_session(self) -> aiohttp.ClientSession:
        """创建新的HTTP会话"""
        timeout = aiohttp.ClientTimeout(total=30)
        connector = aiohttp.TCPConnector(
            limit=10,
            enable_cleanup_closed=True,
            force_close=False  # 改为False避免问题
        )

        # 创建会话时不使用异步上下文管理器
        session = aiohttp.ClientSession(
            timeout=timeout,
            connector=connector,
            json_serialize=json.dumps
        )

        logger.debug("创建新的HTTP会话")
        return session

    async def _get_session_for_url(self, edge_url: str) -> aiohttp.ClientSession:
        """为特定URL获取会话"""
        with self._cache_lock:
            if edge_url not in self._session_cache:
                self._session_cache[edge_url] = self._create_session()
            return self._session_cache[edge_url]

    def _cleanup_session(self, edge_url: str):
        """清理会话缓存"""
        with self._cache_lock:
            if edge_url in self._session_cache:
                session = self._session_cache.pop(edge_url)
                # 异步关闭会话
                asyncio.create_task(session.close())
                logger.debug(f"清理会话: {edge_url}")

    async def _call_model_async_simple(self, edge_url: str, model_id: str, inputs: Any, **kwargs) -> EdgeCallResult:
        """
        异步调用边端模型 - 简单版本
        每次调用创建新会话，避免会话管理问题
        """
        start_time = time.time()
        session = None

        try:
            # 规范化URL
            edge_url = edge_url.strip().rstrip('/')
            if not edge_url.startswith(('http://', 'https://')):
                edge_url = f"http://{edge_url}"
            # 创建临时会话
            timeout_val = kwargs.get('timeout', 30)
            session_timeout = aiohttp.ClientTimeout(total=timeout_val)

            # 重要：使用临时会话，每次请求创建新会话
            connector = aiohttp.TCPConnector(limit=1, force_close=True)
            session = aiohttp.ClientSession(
                timeout=session_timeout,
                connector=connector
            )

            # 构建URL
            url = f"{edge_url}/models/execute"

            # 准备请求数据
            payload = {"inputs": inputs}
            if 'params' in kwargs:
                payload['params'] = kwargs['params']

            # 准备请求头
            headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
            }

            if 'session_id' in kwargs:
                headers['X-Session-ID'] = kwargs['session_id']
            if 'mission_id' in kwargs:
                headers['X-Mission-ID'] = kwargs['mission_id']

            logger.info(f"调用边端模型: {model_id} @ {edge_url}")

            # 发送请求
            async with session.post(url, json=payload, headers=headers) as response:
                response_text = await response.text()
                execution_time = time.time() - start_time

                logger.debug(f"响应状态: {response.status}, 耗时: {execution_time:.2f}s")

                if response.status == 200:
                    try:
                        result_data = json.loads(response_text)

                        # 处理不同的响应格式
                        if isinstance(result_data, dict):
                            # 优先使用success字段
                            if 'success' in result_data:
                                success = bool(result_data.get('success'))
                                data = result_data.get('data', result_data)
                            else:
                                success = True
                                data = result_data
                        else:
                            success = True
                            data = result_data

                        return EdgeCallResult(
                            success=success,
                            data=data,
                            edge_url=edge_url,
                            model_id=model_id,
                            execution_time=execution_time,
                            http_status=response.status
                        )

                    except json.JSONDecodeError:
                        # 如果不是JSON，返回原始文本
                        return EdgeCallResult(
                            success=True,
                            data=response_text,
                            edge_url=edge_url,
                            model_id=model_id,
                            execution_time=execution_time,
                            http_status=response.status
                        )

                else:
                    # HTTP错误
                    error_msg = f"HTTP {response.status}"
                    if response_text:
                        error_msg += f": {response_text[:100]}"

                    return EdgeCallResult(
                        success=False,
                        error=error_msg,
                        edge_url=edge_url,
                        model_id=model_id,
                        execution_time=execution_time,
                        http_status=response.status
                    )

        except asyncio.TimeoutError:
            logger.error(f"请求超时: {model_id} @ {edge_url}")
            return EdgeCallResult(
                success=False,
                error='请求超时',
                edge_url=edge_url,
                model_id=model_id,
                execution_time=time.time() - start_time
            )

        except Exception as e:
            logger.error(f"调用异常 {model_id} @ {edge_url}: {type(e).__name__}: {e}")
            return EdgeCallResult(
                success=False,
                error=f"{type(e).__name__}: {str(e)}",
                edge_url=edge_url,
                model_id=model_id,
                execution_time=time.time() - start_time
            )

        finally:
            # 确保会话被关闭
            if session and not session.closed:
                await session.close()

    def call_model_sync(self, edge_url: str, model_id: str, inputs: Any, **kwargs) -> EdgeCallResult:
        """
        同步调用边端模型 - 线程安全
        """
        try:
            # 使用线程池执行异步调用
            future = self._executor.submit(
                self._run_in_thread,
                edge_url,
                model_id,
                inputs,
                kwargs
            )

            # 设置超时
            timeout = kwargs.get('timeout', 30) + 5
            return future.result(timeout=timeout)

        except Exception as e:
            logger.error(f"同步调用失败: {type(e).__name__}: {e}")
            return EdgeCallResult(
                success=False,
                error=f"调用失败: {type(e).__name__}: {str(e)}",
                edge_url=edge_url,
                model_id=model_id
            )

    def _run_in_thread(self, edge_url: str, model_id: str, inputs: Any, kwargs: Dict) -> EdgeCallResult:
        """
        使用 asyncio.run() 简化事件循环管理
        """
        try:
            # 创建异步包装函数
            async def wrapper():
                return await self._call_model_async_simple(edge_url, model_id, inputs, **kwargs)

            # asyncio.run 会自动管理事件循环生命周期
            result = asyncio.run(wrapper())
            return result

        except Exception as e:
            logger.error(f"线程执行失败: {type(e).__name__}: {e}", exc_info=True)
            return EdgeCallResult(
                success=False,
                error=f"线程执行失败: {type(e).__name__}: {str(e)}",
                edge_url=edge_url,
                model_id=model_id
            )

    async def call_model_async(self, edge_url: str, model_id: str, inputs: Any, **kwargs) -> EdgeCallResult:
        """异步调用边端模型"""
        return await self._call_model_async_simple(edge_url, model_id, inputs, **kwargs)

    def cleanup(self):
        """清理资源"""
        # 清理会话缓存
        with self._cache_lock:
            for edge_url, session in self._session_cache.items():
                if not session.closed:
                    try:
                        # 在后台关闭会话
                        asyncio.create_task(session.close())
                    except:
                        pass
            self._session_cache.clear()

        # 关闭线程池
        if self._executor:
            self._executor.shutdown(wait=False)


# 全局单例实例
_edge_client_instance = None
_edge_client_lock = threading.Lock()


def get_edge_client() -> SimpleEdgeClient:
    """获取边端客户端实例（单例模式）"""
    global _edge_client_instance

    with _edge_client_lock:
        if _edge_client_instance is None:
            _edge_client_instance = SimpleEdgeClient()

        return _edge_client_instance