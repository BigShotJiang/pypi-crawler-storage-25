from abc import ABC, abstractmethod
import threading
import json,uuid,time
from typing import List
from collections import defaultdict
from .model.device_key import DeviceKey
from .model.action_item import ActionItem
from .model.device_status import DeviceStatus,MessageType,MessageLevel
from typing import Dict, Any, Optional
import grpc
from . import device_pb2
import asyncio
import requests
import base64
from contextlib import contextmanager
from typing import Generator
import logging
from .http_client import get_edge_client, EdgeCallResult
from .model.device_status import DeviceImage,DeviceAudio
from .model_workflow.executer_service import WorkflowExecutor
from .model.device_status import NodeExecutionResult,WorkflowExecutionResponse,WorkflowExecutionRequest,ExecutionConfig,ModelMapping



logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()  # 输出到控制台
    ]
)
logger = logging.getLogger(__name__)



class AbstractDevice(ABC):
    _status_cache: Dict[DeviceKey, dict] = {}
    _connection_pool: Dict[DeviceKey, Any] = {}  # 类级连接池
    _monitor_flags = defaultdict(bool)  # 状态监控标志
    _monitor_futures = {}

    _lock = threading.Lock()  # 线程安全锁
    _status_lock = threading.RLock()  # 新增：状态读取可重入锁

    def __init__(self):
        self._grpc_stub = None
        self._current_mission_id = None
        self._edge_client = get_edge_client()  # 获取边端客户端实例

        self._device_pusher = None  # 新增：DevicePusher引用

    def set_device_pusher(self, pusher):
        """设置DevicePusher引用"""
        self._device_pusher = pusher

    def set_grpc_stub(self, grpc_stub):
        """设置gRPC stub用于发送消息"""
        self._grpc_stub = grpc_stub

    def set_current_mission_id(self, mission_id: str):
        """设置当前任务的mission_id"""
        self._current_mission_id = mission_id

    @contextmanager
    def mission_context(self, mission_id: str) -> Generator[None, None, None]:
        """为任务提供独立的上下文"""
        original_mission_id = getattr(self, '_current_mission_id', None)
        try:
            self._current_mission_id = mission_id
            yield
        finally:
            self._current_mission_id = original_mission_id

    def send_message(self, device_id: int, message_type: MessageType, content: str, level: MessageLevel,role:str="tab",
                     metadata: Optional[Dict[str, Any]] = None,
                     mission_id: Optional[str] = None) -> bool:
        """
        通过消息队列发送消息（线程安全）
        """
        target_mission_id = mission_id or self._current_mission_id
        if not target_mission_id:
            logger.warning("未提供mission_id且当前无任务上下文")
            return False

        # 如果有DevicePusher引用，使用消息队列
        if self._device_pusher and hasattr(self._device_pusher, 'submit_message'):
            try:
                return self._device_pusher.submit_message(
                    device_id=device_id,
                    message_type=message_type,
                    content=content,
                    level=level,
                    role=role,
                    metadata=metadata,
                    mission_id=target_mission_id
                )
            except Exception as e:
                logger.error(f"通过消息队列发送失败: {e}")
                # 降级方案：尝试直接发送
                return self._fallback_send_message(
                    device_id, message_type, content, level,role, metadata, target_mission_id
                )
        else:
            # 如果没有pusher引用，使用降级方案
            logger.warning("未找到DevicePusher引用，使用降级方案发送消息")
            return self._fallback_send_message(
                device_id, message_type, content, level,role, metadata, target_mission_id
            )

    def _fallback_send_message(self, device_id: int, message_type: MessageType, content: str, level: MessageLevel,role,
                               metadata: Optional[Dict[str, Any]] = None,
                               mission_id: Optional[str] = None) -> bool:
        """
        降级方案：直接发送消息（当消息队列不可用时）
        """
        if not self._grpc_stub:
            logger.warning("gRPC stub未设置，无法发送消息")
            return False

        try:
            device_message = device_pb2.DeviceMessage(
                mission_id=mission_id,
                message_type=message_type.value,
                message_level=level.value,
                content=content,
                timestamp=int(time.time()),
                metadata=json.dumps(metadata) if metadata else "",
                device_id=int(device_id)
            )

            # 检查是否在异步上下文中
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    # 在运行中的循环中，提交异步任务
                    asyncio.create_task(self._grpc_stub.ReceiveDeviceMessage(device_message))
                    return True
            except RuntimeError:
                pass  # 没有事件循环

            # 同步调用（创建新循环）
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            try:
                loop.run_until_complete(self._grpc_stub.ReceiveDeviceMessage(device_message))
                return True
            finally:
                loop.close()

        except Exception as e:
            logger.error(f"降级方案发送消息失败: {e}")
            return False

    def send_text_message(self, device_id: int, text: str,level:MessageLevel, role: str = "tab",**kwargs) -> bool:
        """发送纯文本消息的快捷方法"""
        return self.send_message(device_id,MessageType.TEXT, text,level, role, **kwargs)

    def send_image_message(self, device_id: int, image_data_or_url: str,level:MessageLevel, role: str = "tab", **kwargs) -> bool:
        """发送图像消息的快捷方法"""
        metadata = kwargs.pop('metadata', {})
        if 'description' not in metadata:
            metadata['description'] = '设备上传的图像'
        return self.send_message(device_id,MessageType.IMAGE, image_data_or_url,level, role, metadata, **kwargs)

    def send_video_url_message(self, device_id: int, video_url: str,level:MessageLevel, role: str = "tab", **kwargs) -> bool:
        """发送视频URL消息的快捷方法"""
        metadata = kwargs.pop('metadata', {})
        if 'description' not in metadata:
            metadata['description'] = '设备视频流地址'
        return self.send_message(device_id,MessageType.VIDEO_URL, video_url,level, role, metadata, **kwargs)

    # ========== 边端模型调用 ==========

    def call_edge_model(self,
                        edge_url: str,
                        model_id: str,
                        inputs: Any,
                        **kwargs) -> EdgeCallResult:
        """
        调用边端模型（同步，线程安全）

        Args:
            edge_url: 边端地址，如 "http://192.168.1.175:8080" 或 "192.168.1.175:8080"
            model_id: 模型ID
            inputs: 输入数据
            **kwargs:
                - params: 模型参数
                - timeout: 超时秒数
                - session_id: 会话ID
                - mission_id: 任务ID

        Returns:
            EdgeCallResult对象
        """
        try:
            # 添加当前任务ID
            if 'mission_id' not in kwargs and self._current_mission_id:
                kwargs['mission_id'] = self._current_mission_id

            # 记录调用信息
            logger.info(f"调用边端模型: {model_id} @ {edge_url}")

            # 使用边端客户端调用
            result = self._edge_client.call_model_sync(edge_url, model_id, inputs, **kwargs)

            # 记录结果
            if result.success:
                logger.info(f"模型调用成功: {model_id}, 耗时: {result.execution_time:.2f}s")
            else:
                logger.warning(f"模型调用失败: {model_id}, 错误: {result.error}")

            return result

        except Exception as e:
            logger.error(f"调用边端模型异常: {e}")
            return EdgeCallResult(
                success=False,
                error=f"调用异常: {str(e)}",
                edge_url=edge_url,
                model_id=model_id
            )

    def call_edge_model_with_params(self,
                                    model_id: str,
                                    inputs: Any,
                                    params: Dict,
                                    **kwargs) -> EdgeCallResult:
        """
        从参数中解析边端地址并调用

        Args:
            model_id: 模型ID
            inputs: 输入数据
            params: 参数字典，应包含边端地址
            **kwargs: 额外参数

        Returns:
            EdgeCallResult对象
        """
        # 提取边端地址
        edge_url = self._extract_edge_url(params)
        if not edge_url:
            return EdgeCallResult(
                success=False,
                error="参数中未找到边端地址",
                model_id=model_id
            )

        # 合并参数
        call_kwargs = kwargs.copy()
        if 'params' not in call_kwargs:
            call_kwargs['params'] = {}

        call_kwargs['params'].update(params)

        return self.call_edge_model(edge_url, model_id, inputs, **call_kwargs)

    def _extract_edge_url(self, params: Dict) -> Optional[str]:
        """
        从参数中提取边端地址

        支持格式:
        1. edge_url 参数
        2. current_pod_id 参数（兼容旧格式）
        3. 直接是IP:Port格式的参数
        """
        # 1. edge_url 参数
        edge_url = params.get('edge_url')
        if edge_url and isinstance(edge_url, str):
            # 确保有协议头
            if not edge_url.startswith(('http://', 'https://')):
                edge_url = f"http://{edge_url}"
            return edge_url

        # 2. current_pod_id（兼容旧格式）
        pod_id = params.get('current_pod_id')
        if pod_id and isinstance(pod_id, str):
            if ':' in pod_id:
                return f"http://{pod_id}"
            else:
                return f"http://{pod_id}:8080"

        # 3. 检查是否有类似IP:Port的参数
        for key, value in params.items():
            if isinstance(value, str) and ':' in value:
                parts = value.split(':')
                if len(parts) == 2 and parts[1].isdigit():
                    # 可能是IP:Port格式
                    return f"http://{value}"

        return None

    # ========== 结果处理助手 ==========

    def handle_model_result(self,
                            device_id: int,
                            result: EdgeCallResult,
                            success_msg: str = "模型调用成功",
                            error_msg: str = "模型调用失败",
                            **extra_info) -> Dict:
        """
        处理模型调用结果

        Args:
            device_id: 设备ID
            result: 调用结果
            success_msg: 成功消息模板
            error_msg: 失败消息模板
            **extra_info: 额外信息用于消息格式化

        Returns:
            标准化结果字典
        """
        if not isinstance(result, EdgeCallResult):
            # 如果result不是EdgeCallResult，转换为EdgeCallResult
            error_text = str(result) if result else "未知错误"
            result = EdgeCallResult(
                success=False,
                error=f"无效的返回类型: {type(result).__name__}",
                model_id="unknown"
            )

        if result.success:
            # 成功
            final_msg = success_msg
            level = MessageLevel.SUCCESS

            # 准备格式化参数
            format_params = {
                'model': result.model_id or '未知模型',
                'edge': result.edge_url or '未知边端',
                'time': f"{result.execution_time:.2f}",
                'status': result.http_status or 200,
                **extra_info
            }

            # 从结果数据提取信息
            if result.data and isinstance(result.data, dict):
                if 'detection_count' in result.data:
                    format_params['count'] = result.data['detection_count']
                elif 'detections' in result.data and isinstance(result.data['detections'], list):
                    format_params['count'] = len(result.data['detections'])
                elif 'result' in result.data:
                    format_params['result'] = str(result.data['result'])[:100]

            # 格式化消息
            try:
                final_msg = final_msg.format(**format_params)
            except:
                pass  # 如果格式化失败，使用原消息

            # 发送消息
            self.send_text_message(device_id, final_msg, level)

            # 返回标准化结果
            return {
                'status': 'success',
                'message': final_msg,
                'model_result': result.data,
                'metadata': {
                    'model_id': result.model_id,
                    'edge_url': result.edge_url,
                    'execution_time': result.execution_time,
                    'http_status': result.http_status
                }
            }

        else:
            # 失败
            final_error = error_msg
            level = MessageLevel.ERROR

            # 准备错误信息
            error_info = {
                'model': result.model_id or '未知模型',
                'edge': result.edge_url or '未知边端',
                'error': result.error or '未知错误',
                'status': result.http_status or 0,
                **extra_info
            }

            try:
                final_error = final_error.format(**error_info)
            except:
                final_error = f"{error_msg}: {result.error}"

            # 发送错误消息
            self.send_text_message(device_id, final_error, level)

            return {
                'status': 'error',
                'message': final_error,
                'error': result.error,
                'metadata': {
                    'model_id': result.model_id,
                    'edge_url': result.edge_url,
                    'http_status': result.http_status
                }
            }

    # ========== 健康检查 ==========

    def check_edge_health(self, edge_url: str) -> bool:
        """检查边端健康状态（简化版）"""
        try:
            # 直接尝试调用健康接口
            result = self.call_edge_model(
                edge_url=edge_url,
                model_id="health_check",  # 使用虚拟模型ID
                inputs={},
                timeout=5
            )
            return result.success and result.http_status == 200
        except:
            return False

    @property
    @abstractmethod
    def protocol_name(self) -> str:
        pass
    
    def is_cluster(self):
        return 0
    
    @abstractmethod
    def get_action_list(self) -> List[ActionItem]:
        pass
    def connect(self, device_key: DeviceKey) -> Any:
        """带设备ID的连接池实现"""
        with self._lock:
            if device_key not in self._connection_pool:
                is_connect,client = self._create_client(device_key.device_id,device_key.connection_str)
                if is_connect:
                    self._connection_pool[device_key] = client
                return is_connect,client
            else:
                client = self._connection_pool[device_key]
                return True,client


    def disconnect(self, device_key: DeviceKey):
        with self._lock:
            if device_key in self._connection_pool:
                self._close_client(self._connection_pool[device_key],device_key.device_id,device_key.connection_str)
                # 清空连接池中对应device_key的数据
                del self._connection_pool[device_key]
                logger.info(f"已从连接池中移除设备 {device_key}")


    def is_connected(self, device_key: DeviceKey) -> bool:
        with self._lock:
            if conn := self._connection_pool.get(device_key):
                return True
        return False

    @abstractmethod
    def _create_client(self,device_id:int, connection_str: str) -> tuple[bool, Any]:
        pass

    @abstractmethod
    def _close_client(self,client, device_id: int, connection_str: str) -> Any:
        pass

    def get_device_status(self,client,device_id:str,connection_str:str) -> DeviceStatus:
        pass
    
    def get_device_status_list(self,client,device_id:str,connection_str:str) -> List[DeviceStatus]:
        pass

    def _ensure_connection(self, device_key: DeviceKey) -> Any:
        """确保设备连接存在，如果不存在则创建"""
        client = self._connection_pool.get(device_key)
        if client is not None:
            return client

        # 尝试连接
        success, result = self.connect(device_key)
        if not success:
            raise ConnectionError(f"无法连接设备 {device_key.device_id}: {result}")

        client = self._connection_pool.get(device_key)
        if client is None:
            raise ConnectionError(f"连接已建立但客户端对象缺失: {device_key.device_id}")

        return client

    def get_status(self, device_id: str, connection_str: str) -> DeviceStatus:
        my_device = DeviceKey(device_id=device_id, connection_str=connection_str)

        # 确保连接存在
        client = self._ensure_connection(my_device)
        is_cluster = self.is_cluster()
        if is_cluster == 0:
            return [self.get_device_status(client, device_id, connection_str)]
        else:
            return self.get_device_status_list(client, device_id, connection_str)

    # def excute_command(self,device_id:str,connection_str:str, command: str, params: Dict[str, Any],
    #                   mission_id: str):
    #     my_device = DeviceKey(device_id=device_id, connection_str=connection_str)
    #     this_client = self._ensure_connection(my_device)
    #     with self.mission_context(mission_id):
    #         self.execute(this_client,device_id,connection_str,command,params)

    @abstractmethod
    def execute(self,client,device_id:int,connection_str:str, command: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """执行控制指令"""
        pass

    async def excute_command_async(self,judge_url:str, device_id: str, connection_str: str, command: str,
                                   params: Dict[str, Any], mission_id: str,model_stream_config: Dict[str, Any],model_workflow_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        异步执行命令 - 支持同步模型流调用
        """
        my_device = DeviceKey(device_id=device_id, connection_str=connection_str)
        this_client = self._ensure_connection(my_device)

        with self.mission_context(mission_id):
            if model_stream_config:
                # 异步执行命令并同步进行模型流调用
                logger.info(f"设备 {device_id} 执行命令 {command} 并开启模型流调用")
                return await self.execute_with_model_stream(
                    judge_url,this_client, int(device_id), connection_str,
                    command, params, mission_id, model_stream_config
                )
            elif model_workflow_config:
                logger.info(f"设备 {device_id} 执行命令 {command} 并开启模型工作流调用")
                return await self.execute_with_model_workflow(
                    judge_url,this_client, int(device_id), connection_str,
                    command, params, mission_id, model_workflow_config
                )
            else:
                # 异步执行普通命令
                # return await asyncio.get_event_loop().run_in_executor(
                #     None,
                #     lambda: self.execute(this_client, device_id, connection_str, command, params)
                # )
                result = await asyncio.to_thread(
                    self.execute, this_client, device_id, connection_str, command, params
                )
                return result
    def excute_command(self, device_id: str, connection_str: str, command: str,
                       params: Dict[str, Any], mission_id: str) -> Dict[str, Any]:
        """
        同步执行命令 - 保持向后兼容
        内部调用异步版本
        """
        try:
            # 在线程池中运行异步函数
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            result = loop.run_until_complete(
                self.excute_command_async(device_id, connection_str, command, params, mission_id)
            )
            loop.close()
            return result
        except Exception as e:
            logger.error(f"执行命令失败: {e}")
            return {
                "success": False,
                "error": str(e),
                "command": command
            }
    # @abstractmethod
    def get_realtime_image(self, device_id: int, format: str = 'jpg') -> Optional[DeviceImage]:
        """
        获取设备实时图像（子类必须实现）

        Returns:
            Dict包含图像信息，例如：
            {
                "url": "http://192.168.1.100/image.jpg",  # 图像URL
                "data": "base64编码数据",  # 可选：base64编码的图像数据
                "timestamp": 1234567890,
                "format": "jpg"
            }
        """
        pass

    # @abstractmethod
    def get_realtime_audio(self, device_id: int, duration: int = 10) -> Optional[DeviceAudio]:
        """
        获取设备实时音频

        Args:
            device_id: 设备ID
            duration: 音频时长（秒）

        return DeviceAudio(
                url=audio_info.get("url"),
                data=audio_info.get("data"),
                timestamp=audio_info.get("timestamp", time.time()),
                duration=duration,
                sample_rate=audio_info.get("sample_rate", 16000),
                device_id=device_id
            )
        """
    async def call_model_with_image_stream(self,judge_url:str,mission_id:str, device_id: int, model_config: Dict[str, Any],
                                           stop_event: Optional[asyncio.Event] = None) -> Dict[str, Any]:
        """
        使用图像流循环调用模型（异步版本）
        持续运行直到 stop_event 被设置或发生异常
        """
        model_id = model_config.get("model_id")
        model_type = model_config.get("model_type")
        interval = model_config.get("interval", 1.0)
        send_messages = model_config.get("send_messages", True)

        rule = model_config.get("rule",{})
        mqtt_topic = None
        #通过judge_url调用规则开始接口
        if rule:
            try:
                # 同步调用放到线程池中执行
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None,
                    lambda: self.call_ctrl_list_api("start", mission_id, rule,judge_url=judge_url)
                )
                mqtt_topic = result.get('topic')
            except Exception as e:
                logger.error(f"调用规则开始接口失败: {e}")


        # 新增：MQTT订阅配置
        mqtt_qos = 0
        use_mqtt = mqtt_topic is not None and self._device_pusher

        # MQTT消息存储
        mqtt_messages = []
        latest_mqtt_data = None

        # 定义MQTT回调函数
        def on_mqtt_message(client, userdata, msg):
            try:
                nonlocal latest_mqtt_data
                payload = msg.payload.decode('utf-8')
                data = json.loads(payload)
                latest_mqtt_data = {
                    "topic": msg.topic,
                    "payload": data,
                    "timestamp": time.time()
                }
                mqtt_messages.append(latest_mqtt_data)
                logger.info(f"收到MQTT消息: {msg.topic} - {data}")
            except Exception as e:
                logger.error(f"解析MQTT消息失败: {e}")

        # 需要从mqtt中获取最新的model
        if use_mqtt:
            try:
                if self._device_pusher.mqtt_client:
                    # 设置消息回调
                    self._device_pusher.mqtt_client.on_message = on_mqtt_message
                    # 订阅话题（同步操作）
                    loop = asyncio.get_event_loop()
                    await loop.run_in_executor(
                        None,
                        lambda: self._device_pusher.mqtt_client.subscribe(mqtt_topic, mqtt_qos)
                    )
                    logger.info(f"已订阅MQTT话题: {mqtt_topic}")
            except Exception as e:
                logger.error(f"MQTT订阅失败: {e}")
                use_mqtt = False

        start_time = time.time()
        call_count = 0
        success_count = 0
        detection_results = []

        try:
            # 持续循环调用模型，直到 stop_event 被设置
            while True:
                # 检查是否应该停止（如果提供了 stop_event）
                if stop_event and stop_event.is_set():
                    # 同步调用放到线程池中执行
                    try:
                        loop = asyncio.get_event_loop()
                        await loop.run_in_executor(
                            None,
                            lambda: self.call_ctrl_list_api("stop", mission_id, rule,judge_url=judge_url)
                        )
                    except Exception as e:
                        logger.error(f"调用规则停止接口失败: {e}")
                    logger.info(f"接收到停止信号，结束模型流调用")
                    break

                call_start = time.time()

                # 1. 获取实时图像
                image_info = None
                try:
                    loop = asyncio.get_event_loop()
                    image_info = await loop.run_in_executor(
                        None,
                        lambda: self.get_realtime_image(device_id)
                    )
                except Exception as e:
                    logger.error(f"获取实时图像失败: {e}")

                if not image_info:
                    logger.warning(f"设备 {device_id} 无法获取图像")
                    # 使用异步sleep
                    await asyncio.sleep(interval)
                    continue

                # 1-2. 获取最新的MQTT数据
                current_mqtt_data = None
                if use_mqtt:
                    # 这里我们直接使用最新的消息，因为回调函数会自动更新
                    current_mqtt_data = latest_mqtt_data
                    if current_mqtt_data:
                        pyload = current_mqtt_data['payload']
                        model_object = pyload[model_type]
                        if model_object and len(model_object) > 0:
                            model_id = list(model_object.keys())[0]
                            # 获取该模型的信息
                            model_config = model_object[model_id].get("model_info", {})

                        logger.info(f"使用MQTT数据: {current_mqtt_data.get('topic')}")
                    else:
                        logger.debug("暂无MQTT数据")


                # 2. 准备模型输入
                inputs = self._prepare_model_inputs_from_image(image_info, model_config)

                # 3. 调用模型（同步调用）
                result = None
                try:
                    loop = asyncio.get_event_loop()
                    result = await loop.run_in_executor(
                        None,
                        lambda: self._call_edge_model(device_id, model_id, inputs, model_config)
                    )
                except Exception as e:
                    logger.error(f"调用边端模型失败: {e}")
                    result = {
                        "success": False,
                        "error": str(e),
                        "model_id": model_id
                    }
                call_count += 1

                if result and result.get("success"):
                    success_count += 1

                    # 记录检测结果
                    if result.get("data"):
                        detection_results.append(result["data"])

                    # 发送消息
                    if send_messages:
                        self._send_detection_message(device_id, result, image_info)

                # # 4. 等待间隔
                # elapsed = time.time() - call_start
                # if elapsed < interval:
                #     remaining = interval - elapsed
                #     # 使用asyncio.wait_for配合停止信号检查
                #     try:
                #         # 如果停止事件被设置，则立即退出
                #         if stop_event:
                #             # 等待停止事件被设置，但不超过剩余时间
                #             done, pending = await asyncio.wait(
                #                 [asyncio.sleep(remaining), stop_event.wait()],
                #                 return_when=asyncio.FIRST_COMPLETED
                #             )
                #             # 如果stop_event先完成，则退出循环
                #             if stop_event.is_set():
                #                 break
                #         else:
                #             await asyncio.sleep(remaining)
                #     except asyncio.CancelledError:
                #         # 如果任务被取消，则退出循环
                #         break

        except asyncio.CancelledError:
            logger.info(f"模型流调用被取消")
            # 正常处理取消，不记录为异常
        except Exception as e:
            logger.error(f"模型流调用异常: {e}")
        finally:
            # 取消MQTT订阅
            if use_mqtt and self._device_pusher.mqtt_client:
                try:
                    self._device_pusher.mqtt_client.unsubscribe(mqtt_topic)
                    # 恢复原来的消息回调
                    self._device_pusher.mqtt_client.on_message = self._device_pusher.on_mqtt_message
                    logger.info(f"已取消订阅MQTT话题: {mqtt_topic}")
                except Exception as e:
                    logger.error(f"取消订阅MQTT失败: {e}")
            end_time = time.time()

        return {
            "total_calls": call_count,
            "success_calls": success_count,
            "success_rate": success_count / call_count if call_count > 0 else 0,
            "detection_results": detection_results,
            "duration_actual": end_time - start_time,
            "status": "completed" if call_count > 0 else "no_calls"
        }
    def get_realtime_image2(self, device_id: int, format: str = 'jpg') -> Optional[Dict[str, Any]]:
        image_data = ""
        with open("E:\\images\\1.jpg", 'rb') as f:
            image_data = f.read()
            # 2. 转换为Base64字符串
        base64_str = base64.b64encode(image_data).decode('utf-8')

        return {
                # "url": "",  # 图像URL
                "data": base64_str,  # 可选：base64编码的图像数据
                "timestamp": 1234567890,
                "format": "jpg"
            }
    async def call_model_with_workflow_stream(self,judge_url:str,mission_id:str, device_id: int, model_workflow_config: Dict[str, Any],
                                           stop_event: Optional[asyncio.Event] = None) -> Dict[str, Any]:
        """
        使用图像流循环调用模型（异步版本）
        持续运行直到 stop_event 被设置或发生异常
        """
        workflow_id = model_workflow_config.get("workflow_id")
        model_mappings = model_workflow_config.get("model_mappings",{})
        workflow_template = model_workflow_config.get("workflow_template",{})
        parameter_overrides = model_workflow_config.get("parameter_overrides",{})
        execution_id =model_workflow_config.get("model_mappings",str(uuid.uuid4()))
        send_messages = model_workflow_config.get("send_messages", True)

        rule = model_workflow_config.get("rule",{})
        mqtt_topic = None

        get_image_func = lambda dev_id: self.get_realtime_image(dev_id)
        call_edge_model = lambda dev_id, model_id, inputs, config: self._call_edge_model(dev_id, model_id, inputs,config)

        #通过judge_url调用规则开始接口
        if rule:
            try:
                # 同步调用放到线程池中执行
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None,
                    lambda: self.call_ctrl_list_api("start", mission_id, rule,base_url=judge_url)
                )
                if 'data' in result and 'topic' in result['data']:
                    mqtt_topic = result.get('data').get('topic')
            except Exception as e:
                logger.error(f"调用规则开始接口失败: {e}")


        # 新增：MQTT订阅配置
        mqtt_qos = 0
        use_mqtt = mqtt_topic is not None and self._device_pusher

        # MQTT消息存储
        mqtt_messages = []
        latest_mqtt_data = None

        # 定义MQTT回调函数
        def on_mqtt_message(client, userdata, msg):
            try:
                nonlocal latest_mqtt_data
                payload = msg.payload.decode('utf-8')
                data = json.loads(payload)
                latest_mqtt_data = {
                    "topic": msg.topic,
                    "payload": data,
                    "timestamp": time.time()
                }
                mqtt_messages.append(latest_mqtt_data)
                logger.info(f"收到MQTT消息: {msg.topic} - {data}")
            except Exception as e:
                logger.error(f"解析MQTT消息失败: {e}")

        # 需要从mqtt中获取最新的model
        if use_mqtt:
            try:
                if self._device_pusher.mqtt_client:
                    # 设置消息回调
                    self._device_pusher.mqtt_client.on_message = on_mqtt_message
                    # 订阅话题（同步操作）
                    loop = asyncio.get_event_loop()
                    await loop.run_in_executor(
                        None,
                        lambda: self._device_pusher.mqtt_client.subscribe(mqtt_topic, mqtt_qos)
                    )
                    logger.info(f"已订阅MQTT话题: {mqtt_topic}")
            except Exception as e:
                logger.error(f"MQTT订阅失败: {e}")
                use_mqtt = False

        start_time = time.time()
        call_count = 0
        success_count = 0
        detection_results = []

        # 新增：存储去重后的工作流执行结果列表（每个结果值只存储一次）
        workflow_result_history = []
        # 新增：上一次的结果，用于检测变化
        last_result = None
        # 新增：记录每种结果的统计信息
        result_statistics = {}

        def make_result_hashable(result):
            """将结果转换为可哈希的类型"""
            if result is None:
                return None
            elif isinstance(result, (str, int, float, bool)):
                return result
            elif isinstance(result, list):
                # 将列表转换为元组（可哈希）
                return tuple(make_result_hashable(item) for item in result)
            elif isinstance(result, dict):
                # 将字典转换为可哈希的形式（元组的元组）
                return tuple((k, make_result_hashable(v)) for k, v in sorted(result.items()))
            else:
                # 其他类型，转换为字符串
                try:
                    return str(result)
                except:
                    return repr(result)

        try:
            # 持续循环调用模型，直到 stop_event 被设置
            while True:
                # 检查是否应该停止（如果提供了 stop_event）
                if stop_event and stop_event.is_set():
                    # 同步调用放到线程池中执行
                    try:
                        loop = asyncio.get_event_loop()
                        await loop.run_in_executor(
                            None,
                            lambda: self.call_ctrl_list_api("stop", mission_id, rule,base_url=judge_url)
                        )
                    except Exception as e:
                        logger.error(f"调用规则停止接口失败: {e}")
                    logger.info(f"接收到停止信号，结束模型流调用")
                    break
                await asyncio.sleep(0.001)  # 1毫秒，足够让其他任务运行
                call_start = time.time()

                # 1. 获取最新的MQTT数据
                current_mqtt_data = None
                if use_mqtt:
                    # 这里我们直接使用最新的消息，因为回调函数会自动更新
                    current_mqtt_data = latest_mqtt_data
                    if current_mqtt_data:
                        pyload = current_mqtt_data['payload']
                        for node_name, mapping in model_mappings.items():
                            this_node = pyload.get(node_name)
                            if this_node:
                                mapping['model_id'] = this_node['deploy_name']
                                mapping['endpoint'] = this_node['target_url']
                        logger.info(f"使用MQTT数据: {current_mqtt_data.get('topic')}")
                    else:
                        logger.debug("暂无MQTT数据")

                #2.调用模型工作流
                execute_service = WorkflowExecutor()
                execution_config = ExecutionConfig(
                    model_mappings={
                        node_name: ModelMapping(
                            model_id=mapping['model_id'],
                            endpoint=mapping['endpoint'],
                            model_type=mapping['model_type'],
                            parameters_override=None
                        )
                        for node_name, mapping in model_mappings.items()
                    },
                    parameter_overrides=parameter_overrides
                )
                request = WorkflowExecutionRequest(
                    template_id = workflow_id,
                    template = workflow_template,
                    input_data = {},
                    execution_config = execution_config,
                    execution_id = execution_id

                )

                result = await  execute_service.execute_workflow(request,current_mqtt_data,device_id,get_realtime_image=get_image_func,call_edge_model=call_edge_model)
                node_result = result.node_results
                # if 'detector' in node_result:
                #     #WorkflowExecutionResponse
                #     detector = node_result['detector']
                #     data = detector.data
                #     this_result = data['result']
                #
                #     hashable_result = make_result_hashable(this_result)
                #
                #     call_count += 1
                #
                #     # 检查结果每次大模型的结果是否发生变化
                #     if hashable_result != last_result:
                #         if last_result is not None:
                #             logger.info(f"工作流执行结果变化: {last_result} -> {this_result}")
                #             self.send_text_message(device_id, f"检测到{this_result}", MessageLevel.INFO)
                #         else:
                #             logger.info(f"工作流执行初始结果: {this_result}")
                #             self.send_text_message(device_id, f"检测到{this_result}", MessageLevel.INFO)
                #         last_result = this_result
                #
                #         # 如果这是新的结果值，添加到历史记录中
                #         # 检查是否已经记录过这个结果值
                #         existing_result = next((r for r in workflow_result_history if r['result'] == this_result), None)
                #         if existing_result is None:
                #             # 首次出现这个结果，添加到历史记录
                #             result_record = {
                #                 'result': this_result,
                #                 'first_seen_time': time.time(),
                #                 'first_seen_iteration': call_count,
                #                 'occurrence_count': 1
                #             }
                #             workflow_result_history.append(result_record)
                #             logger.info(f"新结果值首次出现并已记录: {this_result}")
                #         else:
                #             # 这个结果值之前出现过，更新统计信息
                #             existing_result['occurrence_count'] += 1
                #             existing_result['last_seen_time'] = time.time()
                #             existing_result['last_seen_iteration'] = call_count
                #             logger.info(f"结果值再次出现: {this_result} (第{existing_result['occurrence_count']}次)")
                #     else:
                #         # 结果没有变化，更新统计信息
                #         if this_result is not None:
                #             # 查找这个结果的记录
                #             existing_result = next((r for r in workflow_result_history if r['result'] == this_result),
                #                                    None)
                #             if existing_result is not None:
                #                 existing_result['occurrence_count'] += 1
                #                 existing_result['last_seen_time'] = time.time()
                #                 existing_result['last_seen_iteration'] = call_count
                #                 logger.debug(
                #                     f"结果值保持不变: {this_result} (持续次数: {existing_result['occurrence_count']})")
                #
                #     logger.info(f"工作流执行第{call_count}次结果：{this_result}")
                #
                #     # 更新结果统计（使用可哈希的结果作为键）
                #     if hashable_result not in result_statistics:
                #         result_statistics[hashable_result] = 0
                #     result_statistics[hashable_result] += 1
                #
                #     # 判断是否为成功结果（这里需要根据你的业务逻辑调整）
                #     # 如果结果是一个列表，你可以检查列表是否为空，或者有其他判断逻辑
                #     if this_result is not None:
                #         if isinstance(this_result, list):
                #             # 如果结果是非空列表，认为是成功
                #             if len(this_result) > 0:
                #                 success_count += 1
                #         elif isinstance(this_result, bool):
                #             # 如果结果是布尔值，True为成功
                #             if this_result:
                #                 success_count += 1
                #         elif isinstance(this_result, (int, float)):
                #             # 如果结果是数值，非0为成功（根据业务逻辑调整）
                #             if this_result != 0:
                #                 success_count += 1
                #         else:
                #             # 其他类型，非空为成功
                #             success_count += 1




                # # 4. 等待间隔
                # elapsed = time.time() - call_start
                # if elapsed < interval:
                #     remaining = interval - elapsed
                #     # 使用asyncio.wait_for配合停止信号检查
                #     try:
                #         # 如果停止事件被设置，则立即退出
                #         if stop_event:
                #             # 等待停止事件被设置，但不超过剩余时间
                #             done, pending = await asyncio.wait(
                #                 [asyncio.sleep(remaining), stop_event.wait()],
                #                 return_when=asyncio.FIRST_COMPLETED
                #             )
                #             # 如果stop_event先完成，则退出循环
                #             if stop_event.is_set():
                #                 break
                #         else:
                #             await asyncio.sleep(remaining)
                #     except asyncio.CancelledError:
                #         # 如果任务被取消，则退出循环
                #         break

        except asyncio.CancelledError:
            logger.info(f"模型流调用被取消")
            # 正常处理取消，不记录为异常
        except Exception as e:
            logger.error(f"模型流调用异常: {e}")
        finally:
            # 取消MQTT订阅
            if use_mqtt and self._device_pusher.mqtt_client:
                try:
                    self._device_pusher.mqtt_client.unsubscribe(mqtt_topic)
                    # 恢复原来的消息回调
                    self._device_pusher.mqtt_client.on_message = self._device_pusher.on_mqtt_message
                    logger.info(f"已取消订阅MQTT话题: {mqtt_topic}")
                except Exception as e:
                    logger.error(f"取消订阅MQTT失败: {e}")
            end_time = time.time()
        # realtime_image = self.get_realtime_image2(device_id)
        # if realtime_image:
        #     data = realtime_image['data']
        #     self.send_image_message(device_id, data, MessageLevel.INFO)

        workflow_result_history = workflow_result_history
        results_list = []
        for record in workflow_result_history:
            result_value = record.get('result')
            count = record.get('occurrence_count', 1)

            # 简化显示
            if isinstance(result_value, list):
                if len(result_value) == 0:
                    result_str = "[]"  # 空列表
                elif len(result_value) <= 3:
                    # 如果列表长度<=3，显示所有元素
                    items = []
                    for item in result_value:
                        if isinstance(item, (str, int, float, bool)):
                            items.append(str(item))
                        elif isinstance(item, dict):
                            items.append("{...}")
                        elif isinstance(item, list):
                            items.append("[...]")
                        else:
                            items.append(str(type(item).__name__))
                    result_str = f"[{', '.join(items)}]"
                else:
                    # 如果列表较长，显示前3项和后缀
                    items = []
                    for i in range(min(3, len(result_value))):
                        item = result_value[i]
                        if isinstance(item, (str, int, float, bool)):
                            items.append(str(item))
                        elif isinstance(item, dict):
                            items.append("{...}")
                        elif isinstance(item, list):
                            items.append("[...]")
                        else:
                            items.append(str(type(item).__name__))
                    result_str = f"[{', '.join(items)}, ...共{len(result_value)}项]"

            results_list.append(f"{result_str}({count}次)")

        this_re = f"结果序列: {' -> '.join(results_list)}"
        self.send_text_message(device_id, f"阶段检测总结：{this_re}，请根据任务给出总结", MessageLevel.INFO, "user")
        return {
            "total_calls": call_count,
            "success_calls": success_count,
            "success_rate": success_count / call_count if call_count > 0 else 0,
            "detection_results": detection_results,
            "duration_actual": end_time - start_time,
            "status": "completed" if call_count > 0 else "no_calls"
        }
    def _prepare_model_inputs_from_image(self, image_info: Dict[str, Any], model_config: Dict[str, Any]) -> Dict[str, Any]:
        """从图像信息准备模型输入"""
        inputs = {}

        # 添加图像输入
        if "url" in image_info:
            inputs["image_url"] = image_info["url"]
        elif "data" in image_info:
            inputs["image"] = image_info["data"]
        elif "path" in image_info:
            inputs["image_path"] = image_info["path"]

        # 添加时间戳
        inputs["timestamp"] = image_info.get("timestamp", time.time())

        # 添加其他输入参数
        params = model_config.get("params", {})
        if "inputs" in params:
            inputs.update(params["inputs"])

        return inputs

    def _call_edge_model(self, device_id: int, model_id: str, inputs: Dict[str, Any],
                         model_config: Dict[str, Any]) -> Dict[str, Any]:
        """调用边端模型"""
        try:
            params = model_config.get("params", {})

            # 提取边端URL
            edge_url = model_config.get("edge_url")
            if not edge_url:
                edge_url = self._extract_edge_url(params)

            if edge_url:
                # 使用具体边端URL调用
                result = self.call_edge_model(edge_url, model_id, inputs, **params)
            else:
                # 从参数中提取边端URL
                result = self.call_edge_model_with_params(model_id, inputs, params)

            # 转换为字典格式
            if isinstance(result, EdgeCallResult):
                return {
                    "success": result.success,
                    "data": result.data,
                    "error": result.error,
                    "model_id": model_id,
                    "edge_url": result.edge_url
                }
            else:
                return {
                    "success": False,
                    "error": f"未知的返回类型: {type(result)}",
                    "model_id": model_id
                }
        except Exception as e:
            logger.error(f"失败: {e}")
    def _send_detection_message(self, device_id: int, result: Dict[str, Any], image_info: Dict[str, Any]):
        """发送检测结果消息"""
        if not result.get("success"):
            return

        data = result.get("data", {})

        # 统计检测数量
        detection_count = 0
        if "detection_count" in data:
            detection_count = data["detection_count"]
        elif "detections" in data and isinstance(data["detections"], list):
            detection_count = len(data["detections"])

        if detection_count > 0:
            # 发送文本消息
            message = f"检测到 {detection_count} 个目标"
            self.send_text_message(device_id, message, MessageLevel.INFO)

            # 发送图像消息
            image_url = image_info.get("url")
            if image_url:
                self.send_image_message(
                    device_id,
                    image_url,
                    MessageLevel.INFO,
                    metadata={
                        "detection_count": detection_count,
                        "model_id": result.get("model_id"),
                        "timestamp": time.time()
                    }
                )

    async def execute_with_model_stream(self,judge_url:str, client, device_id: int, connection_str: str,
                                        command: str, params: Dict[str, Any],
                                        mission_id: str, model_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        执行命令并同步进行模型流调用（异步版本）
        """
        # 创建停止事件
        stop_event = asyncio.Event()
        device_result = None

        try:
            # 启动模型任务，传入停止事件
            model_task = asyncio.create_task(
                self.call_model_with_image_stream(judge_url,mission_id,device_id, model_config, stop_event)
            )
            # model_task = None
            # 执行设备命令
            device_result = await asyncio.to_thread(
                self.execute, client, device_id, connection_str, command, params
            )
            logger.info("device_result:")
        except Exception as e:
            logger.error(f"设备执行异常: {e}")
            device_result = {"status": "error", "error": str(e)}
        finally:
            # 设置停止事件，通知模型停止
            stop_event.set()

        # 获取模型结果
        model_result = None
        if model_task:
            try:
                model_result = await model_task
            except Exception as e:
                logger.error(f"获取模型结果异常: {e}")
                model_result = {
                    "total_calls": 0,
                    "success_calls": 0,
                    "success_rate": 0,
                    "detection_results": [],
                    "duration_actual": 0,
                    "status": f"error: {str(e)}"
                }

        return {
            "device_command_result": device_result,
            "model_stream_result": model_result,
            "mission_id": mission_id,
            "command": command
        }


    async def execute_with_model_workflow(self,judge_url:str, client, device_id: int, connection_str: str,
                                        command: str, params: Dict[str, Any],
                                        mission_id: str, model_workflow_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        执行命令并同步进行模型流调用（异步版本）
        """
        # 创建停止事件
        stop_event = asyncio.Event()
        device_result = None

        try:
            # 启动模型任务，传入停止事件
            model_task = asyncio.create_task(
                self.call_model_with_workflow_stream(judge_url,mission_id,device_id, model_workflow_config, stop_event)
            )
            # model_task = None
            # 执行设备命令
            device_result = await asyncio.to_thread(
                self.execute, client, device_id, connection_str, command, params
            )
            logger.info("device_result:")
        except Exception as e:
            logger.error(f"设备执行异常: {e}")
            device_result = {"status": "error", "error": str(e)}
        finally:
            # 设置停止事件，通知模型停止
            stop_event.set()

        # 获取模型结果
        model_result = None
        if model_task:
            try:
                model_result = await model_task
            except Exception as e:
                logger.error(f"获取模型结果异常: {e}")
                model_result = {
                    "total_calls": 0,
                    "success_calls": 0,
                    "success_rate": 0,
                    "detection_results": [],
                    "duration_actual": 0,
                    "status": f"error: {str(e)}"
                }

        return {
            "device_command_result": device_result,
            "model_stream_result": model_result,
            "mission_id": mission_id,
            "command": command
        }

    def to_json(self):
        """序列化设备信息"""
        actions = [item.dict() for item in self.get_action_list()]
        return json.dumps({
            "protocol": self.protocol_name,
            "action_list": actions,
            "is_cluster": self.is_cluster()
        }, ensure_ascii=False)

    def call_ctrl_list_api(self,
            action: str = "start",
            job_id: str = "xx",
            data: Optional[Dict[str, Any]] = None,
            base_url: str = "http://192.168.1.175:8000/api/v1/ctrl/list"
    ) -> Dict[str, Any]:
        """
        调用ctrl/list接口

        参数:
            action: 操作类型，默认为"start"
            job_id: 任务ID，默认为"xx"
            data: 数据参数，如果为None则使用默认数据
            base_url: API基础URL

        返回:
            接口返回的JSON数据转换为的字典

        异常:
            requests.exceptions.RequestException: 请求失败时抛出
        """

        # 默认数据
        default_data = {
            "version": "0.0.1",
            "id": "rule_4030",
            "machine": [
                {
                    "field_name": "network_bytes",
                    "weights": 0.5
                },
                {
                    "field_name": "cpu_usage",
                    "weights": 0.5
                }
            ],
            "models": [
                {
                    "type": "object-detection",
                    "size": {
                        "op": "<=",
                        "value": "200MB"
                    }
                },
                {
                    "type": "text-generation",
                    "size": {
                        "op": ">=",
                        "value": "15MB"
                    }
                }
            ]
        }

        # 使用传入的data或默认数据
        request_data = data if data is not None else default_data

        # 构造请求体
        payload = {
            "action": action,
            "job_id": job_id,
            "data": request_data
        }

        try:
            # 发送POST请求
            response = requests.post(
                base_url,
                json=payload,  # 使用json参数自动设置Content-Type为application/json
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                },
                timeout=30  # 设置超时时间
            )

            # 检查响应状态
            response.raise_for_status()

            # 解析JSON响应
            result = response.json()
            return result

        except requests.exceptions.RequestException as e:
            print(f"请求失败: {e}")
            raise
        except json.JSONDecodeError as e:
            print(f"响应JSON解析失败: {e}")
            raise
