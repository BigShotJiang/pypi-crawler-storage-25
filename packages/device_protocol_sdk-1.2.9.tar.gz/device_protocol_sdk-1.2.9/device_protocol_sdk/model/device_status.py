# device_status.py
from typing import TypedDict, Optional
from enum import Enum
import time
from typing import Dict, Any
from dataclasses import dataclass, field, asdict
class DeviceStatus(TypedDict, total=False):
    """设备状态固定格式"""
    is_lock: Optional[int]  # 必填
    heartbeat: Optional[int]  # 必填
    battery: Optional[float]  # 必填
    airspeed: Optional[float]  # 必填
    groundspeed: Optional[float]  # 必填
    yaw_degrees: Optional[float]  # 必填
    roll: Optional[float]  # 必填
    pitch: Optional[float]  # 必填
    yaw: Optional[float]  # 必填
    lat: Optional[float]  # 必填
    lon: Optional[float]  # 必填
    alt: Optional[float]  # 必填
    vzspeed: Optional[float]  # 必填
    height: Optional[float]  # 必填


class MessageType(Enum):
    TEXT = "text"  # 纯文本消息
    IMAGE = "image"  # 图像消息
    VIDEO_URL = "video_url"  # 视频流URL
    PROGRESS = "progress"  # 进度更新
    STATUS = "status"  # 状态更新

#消息级别: failed, warning, info, success
class MessageLevel(Enum):
    FAILED = "failed"
    WARNING = "warning"
    INFO = "info"
    SUCCESS = "success"
@dataclass
class DeviceImage:
    url: str
    data: Optional[str] = None  # base64编码
    timestamp: float = None
    format: str = "jpg"
    device_id: int = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = time.time()
@dataclass
class DeviceAudio:
    url: str
    data: Optional[str] = None  # base64编码
    timestamp: float = None
    duration: float = 0.0
    sample_rate: int = 16000
    device_id: int = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = time.time()
@dataclass
class NodeExecutionResult:
    """节点执行结果"""
    node_name: str
    success: bool
    model_id: Optional[str] = None
    endpoint_url: Optional[str] = None
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    execution_time: float = 0.0
@dataclass
class WorkflowExecutionResponse:
    """工作流执行响应"""
    success: bool
    execution_id: str
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    execution_time: float = 0.0
    node_results: Dict[str, NodeExecutionResult] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'success': self.success,
            'execution_id': self.execution_id,
            'data': self.data,
            'error': self.error,
            'execution_time': self.execution_time,
            'node_results': {
                node_name: {
                    'success': result.success,
                    'model_id': result.model_id,
                    'endpoint_url': result.endpoint_url,
                    'execution_time': result.execution_time,
                    'error': result.error
                }
                for node_name, result in self.node_results.items()
            }
        }
@dataclass
class ModelMapping:
    """模型映射信息（执行时传入）"""
    model_id: str
    endpoint: str
    model_type: str
    parameters_override: Optional[Dict[str, Any]] = None

@dataclass
class ExecutionConfig:
    """执行配置（执行时传入）"""
    model_mappings: Dict[str, ModelMapping]  # {node_name: ModelMapping}
    parameter_overrides: Dict[str, Dict[str, Any]] = field(default_factory=dict)  # {node_name: {param: value}}

    def to_dict(self) -> Dict[str, Any]:
        return {
            'model_mappings': {
                node_name: {
                    'model_id': mapping.model_id,
                    'endpoint': mapping.endpoint,
                    'parameters_override': mapping.parameters_override
                }
                for node_name, mapping in self.model_mappings.items()
            },
            'parameter_overrides': self.parameter_overrides
        }

@dataclass
class WorkflowExecutionRequest:
    """工作流执行请求"""
    template_id: int
    template:Dict[str, Any]
    input_data: Dict[str, Any]
    execution_config: ExecutionConfig
    execution_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data['execution_config'] = self.execution_config.to_dict()
        return data