# -*- coding: utf-8 -*-
from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='cm_shengyunmu',
    version='1.0.1',
    description='计算概论C课程汉语拼音声母、韵母、韵部提取工具',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='Chen Mo',
    author_email='chenmoemail@126.com',
    url='',
    packages=find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Natural Language :: Chinese (Simplified)',
        'Intended Audience :: Education',
        'Topic :: Education',
        'Topic :: Text Processing :: Linguistic',
    ],
    python_requires='>=3.6',
    license='MIT',
    keywords='pinyin chinese 拼音 声母 韵母 韵部 教学 计算概论C',
)
