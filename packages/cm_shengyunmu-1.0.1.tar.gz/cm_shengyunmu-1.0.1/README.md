# cm_shengyunmu

汉语拼音**声母**、**韵母**、**韵部**提取工具，为《计算概论C》课程教学编写。

## 功能简介

本库提供 3 个函数和 3 个常量，可以从汉语拼音中提取声母、韵母，以及查询韵部归属。配合 `xpinyin` 库使用，可以完成诗句押韵判断等拼音相关的教学练习。

- **23 个声母**，支持双字母声母（zh、ch、sh）优先匹配
- **35 个韵母**，归为 **15 个韵部**
- 兼容 `xpinyin` 库的输出格式（包括末尾的数字声调）

## 安装

```bash
pip install cm_shengyunmu
```

## 使用示例

### 提取声母

```python
import cm_shengyunmu

cm_shengyunmu.get_shengmu('shuang')  # 'sh'
cm_shengyunmu.get_shengmu('long')    # 'l'
cm_shengyunmu.get_shengmu('an')      # None（没有声母）
cm_shengyunmu.get_shengmu('long3')   # 'l'（自动兼容数字声调）
```

### 提取韵母

```python
cm_shengyunmu.get_yunmu('shuang')    # 'uang'
cm_shengyunmu.get_yunmu('long')      # 'ong'
cm_shengyunmu.get_yunmu('an')        # 'an'（没有声母时整个就是韵母）
```

### 查询韵部

```python
cm_shengyunmu.get_yunbu('uang')      # 'ang韵'
cm_shengyunmu.get_yunbu('ong')       # 'ong韵'
cm_shengyunmu.get_yunbu('an')        # 'an韵'
```

> **【注意】** `get_yunbu()` 的参数是**韵母**，不是完整的拼音！如果传入 `'shuang'` 会返回 `None`。要从拼音中先用 `get_yunmu()` 提取韵母。

### 查看数据表

```python
# 声母表（23 个，元组）
print(cm_shengyunmu.SHENGMU_ALL)

# 韵母表（35 个，元组）
print(cm_shengyunmu.YUNMU_ALL)

# 韵部对照字典（韵母 → 韵部名称）
print(cm_shengyunmu.YUNBU_DICT)
print(cm_shengyunmu.YUNBU_DICT['uang'])   # 'ang韵'
```

### 配合 xpinyin 使用的完整流程

```python
import xpinyin
import cm_shengyunmu

p = xpinyin.Pinyin()

char = '龙'
pinyin = p.get_pinyin(char)                    # 'long'
shengmu = cm_shengyunmu.get_shengmu(pinyin)     # 'l'
yunmu = cm_shengyunmu.get_yunmu(pinyin)         # 'ong'
yunbu = cm_shengyunmu.get_yunbu(yunmu)          # 'ong韵'
```

## 韵部对照表

押韵只看韵腹 + 韵尾是否相同，韵头不参与判断。例如 `iao`（如"漂"）和 `ao`（如"高"）同属 `ao 韵`。

| 韵部 | 包含的韵母 |
|:---:|:---|
| a 韵 | a、ia、ua |
| o 韵 | o、uo |
| e 韵 | e、ie、ue |
| i 韵 | i |
| u 韵 | u |
| v 韵 | v |
| ai 韵 | ai、uai |
| ei 韵 | ei、ui |
| ao 韵 | ao、iao |
| ou 韵 | ou、iu |
| an 韵 | an、ian、uan、van |
| en 韵 | en、in、un、vn |
| ang 韵 | ang、iang、uang |
| eng 韵 | eng、ing、ueng |
| ong 韵 | ong、iong |

> 注：`v` 表示 `ü`，与 `xpinyin` 库的转写规则一致。

## 注意事项

- 本库**不支持**带符号声调的拼音（如 `'lóng'`、`'shuāng'`），只支持无声调或数字声调。
- `get_yunbu()` 的参数是**韵母**，不是完整拼音。

## 许可证

MIT License
