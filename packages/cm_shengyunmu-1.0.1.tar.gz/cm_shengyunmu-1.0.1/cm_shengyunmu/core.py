# -*- coding: utf-8 -*-
"""
cm_shengyunmu.core —— 核心功能实现

提供 3 个函数和 3 个常量：
    函数：get_shengmu / get_yunmu / get_yunbu
    常量：SHENGMU_ALL / YUNMU_ALL / YUNBU_DICT
"""


# =====================
# 常量：声母表
# =====================
# 汉语拼音共 23 个声母，其中 zh、ch、sh 为双字母声母
# 注意：双字母声母必须排在 z、c、s 前面，确保匹配时优先匹配双字母
SHENGMU_ALL = (
    'zh', 'ch', 'sh',
    'b', 'p', 'm', 'f',
    'd', 't', 'n', 'l',
    'g', 'k', 'h',
    'j', 'q', 'x',
    'r', 'z', 'c', 's',
    'y', 'w',
)


# =====================
# 常量：韵母表
# =====================
# 按韵部分组顺序排列，共 35 个韵母
YUNMU_ALL = (
    # a 韵
    'a', 'ia', 'ua',
    # o 韵
    'o', 'uo',
    # e 韵
    'e', 'ie', 'ue',
    # i 韵
    'i',
    # u 韵
    'u',
    # v 韵
    'v',
    # ai 韵
    'ai', 'uai',
    # ei 韵
    'ei', 'ui',
    # ao 韵
    'ao', 'iao',
    # ou 韵
    'ou', 'iu',
    # an 韵
    'an', 'ian', 'uan', 'van',
    # en 韵
    'en', 'in', 'un', 'vn',
    # ang 韵
    'ang', 'iang', 'uang',
    # eng 韵
    'eng', 'ing', 'ueng',
    # ong 韵
    'ong', 'iong',
)


# =====================
# 常量：韵部对照字典
# =====================
# 韵母 → 韵部名称的映射，共 35 个韵母，15 个韵部
YUNBU_DICT = {
    # a 韵
    'a': 'a韵', 'ia': 'a韵', 'ua': 'a韵',
    # o 韵
    'o': 'o韵', 'uo': 'o韵',
    # e 韵
    'e': 'e韵', 'ie': 'e韵', 'ue': 'e韵',
    # i 韵
    'i': 'i韵',
    # u 韵
    'u': 'u韵',
    # v 韵（ü）
    'v': 'v韵',
    # ai 韵
    'ai': 'ai韵', 'uai': 'ai韵',
    # ei 韵
    'ei': 'ei韵', 'ui': 'ei韵',
    # ao 韵
    'ao': 'ao韵', 'iao': 'ao韵',
    # ou 韵
    'ou': 'ou韵', 'iu': 'ou韵',
    # an 韵
    'an': 'an韵', 'ian': 'an韵', 'uan': 'an韵', 'van': 'an韵',
    # en 韵
    'en': 'en韵', 'in': 'en韵', 'un': 'en韵', 'vn': 'en韵',
    # ang 韵
    'ang': 'ang韵', 'iang': 'ang韵', 'uang': 'ang韵',
    # eng 韵
    'eng': 'eng韵', 'ing': 'eng韵', 'ueng': 'eng韵',
    # ong 韵
    'ong': 'ong韵', 'iong': 'ong韵',
}


# =====================
# 内部辅助函数
# =====================
def _strip_tone(pinyin):
    """剥掉拼音末尾的数字声调（兼容 xpinyin 的 tone_marks='numbers' 输出）。"""
    if not pinyin:
        return pinyin
    if pinyin[-1].isdigit():
        return pinyin[:-1]
    return pinyin


# =====================
# 对外函数
# =====================
def get_shengmu(pinyin):
    """Extract the initial consonant (shengmu) from a Pinyin syllable.

    Mandarin Chinese has 23 initials, among which ``zh``, ``ch``, and ``sh``
    are two-letter initials. This function matches two-letter initials first
    to avoid mis-identifying ``sh`` as ``s``.

    Args:
        pinyin (str): A Pinyin syllable without tone marks, e.g. ``'shuang'``,
            ``'long'``. Trailing digit tone marks (as produced by ``xpinyin``
            with ``tone_marks='numbers'``) are stripped automatically, so
            ``'long3'`` is accepted.

    Returns:
        str or None: The initial consonant as a string (e.g. ``'sh'``,
        ``'l'``), or ``None`` if the syllable has no initial (e.g. ``'an'``,
        ``'ou'``) or the input is empty.

    Examples:
        >>> get_shengmu('shuang')
        'sh'
        >>> get_shengmu('long')
        'l'
        >>> get_shengmu('an') is None
        True
        >>> get_shengmu('long3')  # tone number stripped
        'l'
        >>> get_shengmu('') is None
        True

    Note:
        Pinyin with diacritic tone marks (e.g. ``'lóng'``, ``'shuāng'``) is
        **not** supported. Use unmarked Pinyin or digit-tone Pinyin only.
    """
    if not pinyin:
        return None
    pinyin = _strip_tone(pinyin.lower().strip())
    if not pinyin:
        return None
    for shengmu in SHENGMU_ALL:
        if pinyin.startswith(shengmu):
            # 确保去掉声母后还剩下韵母，否则说明这个拼音就是个韵母本身
            if len(pinyin) > len(shengmu):
                return shengmu
    return None


def get_yunmu(pinyin):
    """Extract the final (yunmu) from a Pinyin syllable.

    The yunmu is what remains after removing the initial consonant. When a
    syllable has no initial (e.g. ``'an'``, ``'ou'``), the entire syllable
    is the yunmu.

    Args:
        pinyin (str): A Pinyin syllable without tone marks, e.g. ``'shuang'``,
            ``'long'``. Trailing digit tone marks are stripped automatically.

    Returns:
        str: The yunmu as a string (e.g. ``'uang'``, ``'ong'``, ``'an'``).
        Returns an empty string if the input is empty.

    Examples:
        >>> get_yunmu('shuang')
        'uang'
        >>> get_yunmu('long')
        'ong'
        >>> get_yunmu('an')
        'an'
        >>> get_yunmu('long3')  # tone number stripped
        'ong'
        >>> get_yunmu('')
        ''

    Note:
        Pinyin with diacritic tone marks (e.g. ``'lóng'``) is **not**
        supported.
    """
    if not pinyin:
        return ''
    pinyin = _strip_tone(pinyin.lower().strip())
    if not pinyin:
        return ''
    for shengmu in SHENGMU_ALL:
        if pinyin.startswith(shengmu) and len(pinyin) > len(shengmu):
            return pinyin[len(shengmu):]
    return pinyin


def get_yunbu(yunmu):
    """Look up the rhyme group (yunbu) that a given yunmu belongs to.

    Chinese rhyming is determined by the main vowel and coda only; the
    medial glide is ignored. This function groups the 35 yunmu into 15
    rhyme groups, within which all yunmu are considered rhyming. For
    example, ``'iao'`` (as in 漂) and ``'ao'`` (as in 高) both belong to
    ``'ao韵'`` because they share the ``ao`` portion.

    Args:
        yunmu (str): A yunmu (final), **not** a full Pinyin syllable. To
            obtain a yunmu from a full Pinyin syllable, call
            :func:`get_yunmu` first.

    Returns:
        str or None: The rhyme group name (e.g. ``'ang韵'``, ``'ong韵'``),
        or ``None`` if the yunmu is not in the rhyme table or the input is
        empty.

    Examples:
        >>> get_yunbu('uang')
        'ang韵'
        >>> get_yunbu('ong')
        'ong韵'
        >>> get_yunbu('an')
        'an韵'
        >>> get_yunbu('xyz') is None
        True
        >>> get_yunbu('') is None
        True

    Note:
        **The argument must be a yunmu, not a full Pinyin syllable.**
        Passing a full syllable like ``'shuang'`` will return ``None``.
        Always extract the yunmu first via :func:`get_yunmu`.
    """
    if not yunmu:
        return None
    return YUNBU_DICT.get(yunmu.lower().strip())
