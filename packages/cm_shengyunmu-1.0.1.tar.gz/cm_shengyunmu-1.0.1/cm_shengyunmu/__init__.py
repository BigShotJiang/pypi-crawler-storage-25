# -*- coding: utf-8 -*-
"""
cm-shengyunmu —— 汉语拼音声母、韵母、韵部提取工具

一个为《计算概论C》课程教学编写的第三方库，提供从汉语拼音中提取声母、
韵母以及查询韵部归属的简单工具。可以配合 xpinyin 库使用，用于完成
拼音相关的教学练习（如诗句押韵判断）。

对外函数：
    get_shengmu(pinyin) —— 提取声母
    get_yunmu(pinyin)   —— 提取韵母
    get_yunbu(yunmu)    —— 查询韵部

对外常量：
    SHENGMU_ALL —— 23 个声母的元组
    YUNMU_ALL   —— 35 个韵母的元组
    YUNBU_DICT   —— 韵母到韵部名称的字典（共 15 个韵部）

使用示例：
    >>> import cm_shengyunmu
    >>> cm_shengyunmu.get_shengmu('shuang')
    'sh'
    >>> cm_shengyunmu.get_yunmu('shuang')
    'uang'
    >>> cm_shengyunmu.get_yunbu('uang')
    'ang韵'
"""

from .core import (
    get_shengmu,
    get_yunmu,
    get_yunbu,
    SHENGMU_ALL,
    YUNMU_ALL,
    YUNBU_DICT,
)

__version__ = '1.0.1'

__all__ = [
    'get_shengmu',
    'get_yunmu',
    'get_yunbu',
    'SHENGMU_ALL',
    'YUNMU_ALL',
    'YUNBU_DICT',
]
