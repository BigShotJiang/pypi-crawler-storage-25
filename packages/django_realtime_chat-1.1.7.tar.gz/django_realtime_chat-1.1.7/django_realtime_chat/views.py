import json
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.db import models
from django.contrib.auth import get_user_model

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser
from rest_framework.permissions import IsAuthenticated

from .models import Conversation, Message
from . import __version__

User = get_user_model()


@login_required
def chat_home(request):
    """Page principale : liste les conversations de l'utilisateur connecté."""
    user = request.user
    conversations = Conversation.objects.filter(
        models.Q(user1=user) | models.Q(user2=user)
    ).select_related("user1", "user2").order_by("-updated_at")

    # Enrichir chaque conversation avec l'interlocuteur et le dernier message
    for conv in conversations:
        conv.other_user = conv.user2 if conv.user1 == user else conv.user1
        conv.last_message = conv.messages.order_by("-created_at").first()

    all_users = User.objects.exclude(id=user.id)

    return render(request, "django_realtime_chat/chat.html", {
        "conversations": conversations,
        "all_users": all_users,
        "current_user_id": user.id,
        "current_username": user.username,
        "plugin_version": __version__,
    })


@login_required
def start_conversation(request, user_id):
    """Démarre ou récupère une conversation avec un autre utilisateur."""
    other_user = get_object_or_404(User, id=user_id)
    user = request.user

    # Chercher dans les deux sens
    conv = Conversation.objects.filter(
        models.Q(user1=user, user2=other_user) |
        models.Q(user1=other_user, user2=user)
    ).first()

    if not conv:
        conv = Conversation.objects.create(user1=user, user2=other_user)

    return redirect("django_realtime_chat:chat_home")


@login_required
def message_history(request, conversation_id):
    """Retourne l'historique JSON des messages d'une conversation."""
    user = request.user
    conversation = get_object_or_404(
        Conversation,
        id=conversation_id,
        **{"user1": user} if Conversation.objects.filter(id=conversation_id, user1=user).exists()
        else {"user2": user}
    )

    # Récupérer la conversation en vérifiant que l'utilisateur y participe
    conversation = Conversation.objects.filter(
        id=conversation_id
    ).filter(
        models.Q(user1=user) | models.Q(user2=user)
    ).first()

    if not conversation:
        return JsonResponse({"error": "Conversation introuvable"}, status=404)

    messages = conversation.messages.select_related("sender").order_by("created_at")
    data = [
        {
            "id": msg.id,
            "sender_id": msg.sender.id,
            "sender_username": msg.sender.username,
            "content": msg.content,
            "file_url": msg.file.url if msg.file else None,
            "file_type": msg.file_type,
            "created_at": msg.created_at.isoformat(),
        }
        for msg in messages
    ]
    return JsonResponse({"messages": data, "conversation_id": conversation_id})


@login_required
def user_list(request):
    """Retourne la liste des utilisateurs (hors soi-même) en JSON."""
    users = User.objects.exclude(id=request.user.id).values("id", "username")
    return JsonResponse({"users": list(users)})


class FileUploadView(APIView):
    """Upload d'un fichier dans une conversation."""
    parser_classes = [MultiPartParser]
    permission_classes = [IsAuthenticated]

    def post(self, request):
        file = request.FILES.get("file")
        receiver_id = request.data.get("receiver_id")

        if not file or not receiver_id:
            return Response({"error": "Fichier et receiver_id requis"}, status=400)

        sender = request.user
        receiver = get_object_or_404(User, id=receiver_id)

        conv, _ = Conversation.objects.get_or_create_between(sender, receiver)
        msg = Message.objects.create(
            conversation=conv,
            sender=sender,
            file=file,
            file_type=file.content_type,
        )
        return Response({"status": "ok", "file_url": request.build_absolute_uri(msg.file.url)})
