from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()


class ConversationManager(models.Manager):
    def get_or_create_between(self, user1, user2):
        """Récupère ou crée une conversation entre deux utilisateurs (ordre indifférent)."""
        conv = self.filter(
            models.Q(user1=user1, user2=user2) |
            models.Q(user1=user2, user2=user1)
        ).first()
        if conv:
            return conv, False
        return self.create(user1=user1, user2=user2), True


class Conversation(models.Model):
    user1 = models.ForeignKey(
        User, related_name="conversations1", on_delete=models.CASCADE
    )
    user2 = models.ForeignKey(
        User, related_name="conversations2", on_delete=models.CASCADE
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = ConversationManager()

    class Meta:
        ordering = ["-updated_at"]

    def __str__(self):
        return f"Conversation {self.user1.username} ↔ {self.user2.username}"

    def other_user_for(self, user):
        return self.user2 if self.user1 == user else self.user1


class Message(models.Model):
    conversation = models.ForeignKey(
        Conversation, related_name="messages", on_delete=models.CASCADE
    )
    sender = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField(blank=True)
    file = models.FileField(upload_to="chat_files/", null=True, blank=True)
    file_type = models.CharField(max_length=100, blank=True)
    image = models.ImageField(upload_to="chat_images/", null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at"]

    def __str__(self):
        return f"[{self.created_at:%H:%M}] {self.sender.username}: {self.content[:40]}"
