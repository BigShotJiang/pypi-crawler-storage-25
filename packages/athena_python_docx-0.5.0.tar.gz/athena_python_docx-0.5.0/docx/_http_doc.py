"""HTTP-backed Superdoc document handle.

Wire format (matches ``apps/api/src/commands/types.ts``):

    POST /docs/:id/commands
    {
      "client": {"type": "python-sdk", "version": "<x.y.z>"},
      "commands": [
        {"type": "CreateParagraph", "text": "Hi", "at": {"kind": "documentEnd"}},
        ...
      ],
      "return": {"snapshot": false}
    }

The path-proxy at the bottom of this file is the SDK's internal call surface
— call sites still use ``self._session.doc.create.paragraph({...})`` for
historical reasons. The proxy converts the dotted path + camelCase params
dict into a typed :class:`docx.commands.Command`, then routes it through
:class:`docx._buffer.CommandBuffer` so:

* queries / creates flush eagerly (and drain pending mutations in the same
  HTTP request),
* pure mutations buffer and auto-flush on a short idle window.

Removing the path-proxy facade and rewriting call sites to construct
:class:`Command` instances directly is a deliberate follow-up — the wire
format is now typed end-to-end either way.
"""

from __future__ import annotations

import json
from typing import Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from docx._buffer import CommandBuffer
from docx.commands import (
    BlocksList,
    ClearParagraphAlignment,
    ClearParagraphIndentation,
    ClearParagraphSpacing,
    ClearParagraphTabStops,
    Command,
    CommentsCreate,
    CommentsDelete,
    CommentsGet,
    CommentsList,
    CommentsPatch,
    CreateHeading,
    CreateImage,
    CreateParagraph,
    CreateSectionBreak,
    CreateTable,
    Find,
    FormatApply,
    GetNode,
    GetNodeById,
    HeaderFootersGet,
    HeaderFootersList,
    HeaderFootersRefsSetLinkedToPrevious,
    HeaderFootersResolve,
    ImagesGet,
    ImagesList,
    Info,
    Insert,
    InsertLineBreak,
    InsertTab,
    ListsMerge,
    ListsSplit,
    MarkdownToFragment,
    Replace,
    SectionsGet,
    SectionsList,
    SelectionCurrent,
    SetImageAltText,
    SetImageDecorative,
    SetImageSize,
    SetParagraphAlignment,
    SetParagraphFlowOptions,
    SetParagraphIndentation,
    SetParagraphKeepOptions,
    SetParagraphSpacing,
    SetParagraphStyle,
    SetParagraphTabStop,
    SetSectionBreakType,
    SetSectionHeaderFooterMargins,
    SetSectionLinkToPrevious,
    SetSectionPageMargins,
    SetSectionPageSetup,
    SetSectionTitlePage,
    TablesGet,
    TablesGetCells,
    TablesGetProperties,
    TablesInsertColumn,
    TablesInsertRow,
    TablesMergeCells,
    TablesSetCellProperties,
    TablesSetColumnWidth,
    TablesSetLayout,
    TablesSetRowHeight,
    TablesSetStyle,
    TablesSetTableOptions,
)
from docx.errors import (
    AuthenticationError,
    DocxError,
    SessionError,
)


def _user_agent() -> str:
    # Lazy import — docx/__init__.py imports api.py at package load, but
    # _http_doc is only imported lazily from client.py at session-open
    # time, so the package is fully initialized by the time this runs.
    from docx import __version__

    return f"athena-python-docx/{__version__}"


def _sdk_version() -> str:
    from docx import __version__

    return __version__


def _build_retry_session() -> requests.Session:
    """A requests.Session with status-only retry for transient failures.

    Retries up to 3 times with exponential backoff on 429/502/503/504.
    Connect/read retries are explicitly disabled: the server's batch
    handler leaves the doc in an undefined state on partial failure, so
    a connection drop *after* the server processed the request would
    risk double-applying the successful prefix on a transport-level
    retry. Status-code retries are safe — the server explicitly signaled
    "try again" and didn't commit the work.
    """
    s = requests.Session()
    retry = Retry(
        total=None,        # use the per-counter limits below, not a global cap
        status=3,
        connect=0,
        read=0,
        other=0,
        backoff_factor=0.5,
        status_forcelist=(429, 502, 503, 504),
        allowed_methods=frozenset(["POST"]),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    s.mount("http://", adapter)
    s.mount("https://", adapter)
    return s


def _http_post_json(
    *,
    session: requests.Session,
    url: str,
    api_key: str,
    body: dict,
    timeout: float = 60.0,
) -> dict:
    """POST JSON, parse JSON, raise typed errors on non-2xx."""
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
        "Accept": "application/json",
        "User-Agent": _user_agent(),
    }
    try:
        resp = session.post(
            url,
            data=json.dumps(body).encode("utf-8"),
            headers=headers,
            timeout=timeout,
        )
    except requests.ConnectionError as e:
        raise SessionError(
            f"Unable to reach docx-studio at {url}: {e}",
        ) from e
    except requests.Timeout as e:
        raise SessionError(
            f"docx-studio timed out at {url}: {e}",
        ) from e

    # 207 (Multi-Status) is the server's signal for partial-batch
    # failure: some commands succeeded, some failed. We surface it as a
    # DocxError so callers can't silently consume a short `applied`
    # array and act on the wrong command's result. Must come BEFORE the
    # 2xx success path because 207 ∈ [200, 300).
    if resp.status_code == 207:
        body = resp.text
        try:
            parsed = json.loads(body) if body else {}
        except json.JSONDecodeError:
            parsed = {"raw": body}
        raise DocxError(
            f"docx-studio batch reported a partial failure: {parsed!r}",
        )

    if 200 <= resp.status_code < 300:
        try:
            return resp.json()
        except ValueError as e:
            raise DocxError(
                f"docx-studio returned non-JSON body: {resp.text[:200]!r}",
            ) from e

    err_body: str = resp.text
    if resp.status_code in (401, 403):
        raise AuthenticationError(
            f"docx-studio rejected the request (HTTP {resp.status_code}): {err_body}",
        )
    raise DocxError(
        f"docx-studio returned HTTP {resp.status_code}: {err_body}",
    )


# ---------------------------------------------------------------------------
# HttpClient — the bare HTTP transport. Stateless wrt batching.
# ---------------------------------------------------------------------------


class HttpClient:
    """Owns the HTTP transport for a Document.

    One HttpClient per Document; one shared :class:`requests.Session` per
    HttpClient (so connection pooling + retry strategy is reused across
    consecutive batches). Stateless wrt batching — the
    :class:`CommandBuffer` sitting in front of it owns the queue.
    """

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        session: requests.Session | None = None,
    ) -> None:
        self._base_url: str = base_url.rstrip("/")
        self._api_key: str = api_key
        self._session: requests.Session = session or _build_retry_session()

    def close(self) -> None:
        """Release the pooled HTTP connections held by ``requests.Session``.

        Idempotent — ``requests.Session.close`` tolerates being called
        multiple times. Long-lived workers that open and close many
        documents will leak sockets without this.
        """
        try:
            self._session.close()
        except Exception:  # noqa: BLE001
            pass

    def execute_batch(
        self,
        asset_id: str,
        commands: list[Command],
    ) -> list[Any]:
        """POST a batch of typed commands, return per-command result dicts.

        On success, length matches len(commands). On 207 partial-failure,
        the server returns 207 with `applied` (the successful prefix) plus
        an `error` for the failing command — :func:`_http_post_json`
        translates that to a :class:`DocxError`. We don't pad partial
        results because the doc state is undefined.
        """
        if not commands:
            return []

        url: str = f"{self._base_url}/docs/{asset_id}/commands"
        body: dict[str, Any] = {
            "client": {"type": "python-sdk", "version": _sdk_version()},
            "commands": [c.to_dict() for c in commands],
            "return": {"snapshot": False},
        }
        resp: dict = _http_post_json(
            session=self._session,
            url=url,
            api_key=self._api_key,
            body=body,
        )
        applied = resp.get("applied")
        # An empty applied list paired with an `error` field is the
        # 'all-commands-failed' shape — surface it rather than returning
        # an empty result list to a caller that's about to index [-1].
        if not isinstance(applied, list) or (not applied and resp.get("error")):
            err = resp.get("error")
            if err:
                raise DocxError(f"docx-studio batch failed: {err!r}")
            raise DocxError(
                f"docx-studio response missing applied[]: {resp!r}",
            )

        if len(applied) != len(commands):
            raise DocxError(
                f"docx-studio applied {len(applied)} of {len(commands)} commands",
            )

        results: list[Any] = []
        for entry in applied:
            if isinstance(entry, dict):
                result = entry.get("result")
                results.append(result if isinstance(result, dict) else {})
            else:
                results.append({})
        return results


# ---------------------------------------------------------------------------
# Path proxy — translates dotted paths + camelCase param dicts into typed
# Command instances and ships them through the buffer.
# ---------------------------------------------------------------------------


# Map snake_case dotted paths (the "op" name as the SDK constructs it via
# attribute walking) to Command classes. Centralized here so adding a new
# op = adding a row to this table + a Command subclass + a Zod schema.
_OP_TO_COMMAND: dict[str, type[Command]] = {
    # Block creation
    "create.paragraph": CreateParagraph,
    "create.heading": CreateHeading,
    "create.table": CreateTable,
    "create.image": CreateImage,
    "create.section_break": CreateSectionBreak,
    # Inline mutations
    "insert": Insert,
    "replace": Replace,
    "insert_line_break": InsertLineBreak,
    "insert_tab": InsertTab,
    "format.apply": FormatApply,
    "format.paragraph.set_alignment": SetParagraphAlignment,
    "format.paragraph.clear_alignment": ClearParagraphAlignment,
    "format.paragraph.set_indentation": SetParagraphIndentation,
    "format.paragraph.clear_indentation": ClearParagraphIndentation,
    "format.paragraph.set_spacing": SetParagraphSpacing,
    "format.paragraph.clear_spacing": ClearParagraphSpacing,
    "format.paragraph.set_keep_options": SetParagraphKeepOptions,
    "format.paragraph.set_flow_options": SetParagraphFlowOptions,
    "format.paragraph.set_tab_stop": SetParagraphTabStop,
    "format.paragraph.clear_all_tab_stops": ClearParagraphTabStops,
    "styles.paragraph.set_style": SetParagraphStyle,
    # Sections
    "sections.set_page_margins": SetSectionPageMargins,
    "sections.set_page_setup": SetSectionPageSetup,
    "sections.set_header_footer_margins": SetSectionHeaderFooterMargins,
    "sections.set_break_type": SetSectionBreakType,
    "sections.set_title_page": SetSectionTitlePage,
    "sections.set_link_to_previous": SetSectionLinkToPrevious,
    # Tables (mutations)
    "tables.insert_row": TablesInsertRow,
    "tables.insert_column": TablesInsertColumn,
    "tables.merge_cells": TablesMergeCells,
    "tables.set_style": TablesSetStyle,
    "tables.set_layout": TablesSetLayout,
    "tables.set_table_options": TablesSetTableOptions,
    "tables.set_cell_properties": TablesSetCellProperties,
    "tables.set_column_width": TablesSetColumnWidth,
    "tables.set_row_height": TablesSetRowHeight,
    # Images (mutations)
    "images.set_size": SetImageSize,
    "images.set_alt_text": SetImageAltText,
    "images.set_decorative": SetImageDecorative,
    "images.get": ImagesGet,
    # Queries
    "blocks.list": BlocksList,
    "find": Find,
    "get_node_by_id": GetNodeById,
    "get_node": GetNode,
    "images.list": ImagesList,
    "info": Info,
    "sections.list": SectionsList,
    "sections.get": SectionsGet,
    "tables.get": TablesGet,
    "tables.get_cells": TablesGetCells,
    "tables.get_properties": TablesGetProperties,
    "markdown_to_fragment": MarkdownToFragment,
    # Comments
    "comments.create": CommentsCreate,
    "comments.patch": CommentsPatch,
    "comments.delete": CommentsDelete,
    "comments.get": CommentsGet,
    "comments.list": CommentsList,
    # Headers & Footers
    "header_footers.list": HeaderFootersList,
    "header_footers.get": HeaderFootersGet,
    "header_footers.resolve": HeaderFootersResolve,
    "header_footers.refs.set_linked_to_previous": HeaderFootersRefsSetLinkedToPrevious,
    # Lists & Selection (SuperDoc 1.8.1 additions; not exposed on the
    # python-docx parity surface — registered here for typed-bus
    # completeness when advanced callers reach for them).
    "lists.merge": ListsMerge,
    "lists.split": ListsSplit,
    "selection.current": SelectionCurrent,
}


def _camel_to_snake(s: str) -> str:
    out: list[str] = []
    for i, ch in enumerate(s):
        if ch.isupper() and i > 0:
            out.append("_")
        out.append(ch.lower())
    return "".join(out)


# Wire-level field renames per op. The Python SDK passes some keys whose
# names collide with our discriminator (`type`); we route them through
# differently-named dataclass fields and rename back in the server applier.
_FIELD_RENAMES: dict[str, dict[str, str]] = {
    "find": {"type": "node_type"},
    "insert": {"type": "value_type"},
    # `in` is a Python reserved keyword; the Command dataclass field is
    # `in_` (trailing underscore). When callers thread the canonical wire
    # name `in` (e.g., header/footer story locators on create.* ops) the
    # path-proxy → snake-case transform leaves it as `in`, which then
    # clashes at `cls(**snake_params)` since the dataclass declares
    # `in_`. Rename here so SuperDoc-shaped payloads round-trip cleanly.
    "create.paragraph": {"in": "in_"},
    "create.heading": {"in": "in_"},
    "create.table": {"in": "in_"},
}


def _build_command(op: str, params: dict[str, Any]) -> Command:
    """Construct a typed Command from the legacy op-name + params-dict shape."""
    cls = _OP_TO_COMMAND.get(op)
    if cls is None:
        raise DocxError(
            f"Unknown docx-studio op: {op!r}. "
            f"Add a Command subclass + lookup entry in docx/_http_doc.py.",
        )

    # Convert param keys camelCase → snake_case to match dataclass fields.
    snake_params: dict[str, Any] = {
        _camel_to_snake(k): v for k, v in params.items()
    }

    # Apply per-op renames (e.g. find: type → node_type).
    renames = _FIELD_RENAMES.get(op)
    if renames:
        for src, dst in renames.items():
            if src in snake_params:
                snake_params[dst] = snake_params.pop(src)

    try:
        return cls(**snake_params)
    except TypeError as e:
        raise DocxError(
            f"Invalid params for op {op!r}: {e}. params={params!r}",
        ) from e


class _PathProxy:
    """Lazy attribute walker.

    ``doc.create.paragraph(p)`` accumulates the path ``"create.paragraph"``;
    the terminal ``__call__`` translates ``(op, p)`` into a typed
    :class:`Command` and ships it through the buffer.
    """

    __slots__ = ("_buffer", "_path")

    def __init__(self, buffer: CommandBuffer, path: str) -> None:
        self._buffer: CommandBuffer = buffer
        self._path: str = path

    def __getattr__(self, name: str) -> "_PathProxy":
        if name.startswith("__"):
            raise AttributeError(name)
        new_path: str = f"{self._path}.{name}" if self._path else name
        return _PathProxy(self._buffer, new_path)

    async def __call__(self, params: dict | None = None) -> Any:
        # The existing SDK is async-style (calls go through run_sync);
        # __call__ is async to match. The work inside is synchronous —
        # _http_post_json blocks — but it runs on a persistent event-loop
        # thread, so the calling thread is fine.
        cmd = _build_command(self._path, params or {})
        result = self._buffer.call(cmd)
        # Buffered (non-eager) calls return None; existing call sites
        # typically don't read the result of pure mutations, but a few do
        # check `if result:` defensively. Return an empty dict to keep
        # them happy.
        return result if result is not None else {}


class HttpDocHandle:
    """Drop-in replacement for ``superdoc.AsyncSuperDocClient.open()``'s
    return value. Existing SDK call sites use ``self._session.doc.<X>(p)``
    where ``X`` is a dotted path on the bound doc API; this object
    forwards every such access to the HTTP transport via _PathProxy +
    CommandBuffer.
    """

    __slots__ = ("_buffer", "_asset_id", "_client")

    def __init__(self, client: HttpClient, asset_id: str) -> None:
        self._asset_id: str = asset_id
        self._client: HttpClient = client
        self._buffer: CommandBuffer = CommandBuffer(client, asset_id)

    @property
    def buffer(self) -> CommandBuffer:
        return self._buffer

    @property
    def client(self) -> HttpClient:
        return self._client

    def __getattr__(self, name: str) -> _PathProxy:
        if name.startswith("__"):
            raise AttributeError(name)
        return _PathProxy(self._buffer, name)
