"""Table-related enums — python-docx parity (docx.enum.table)."""

from __future__ import annotations

from enum import Enum


class WD_ROW_HEIGHT_RULE(Enum):
    AUTO = "auto"
    AT_LEAST = "atLeast"
    EXACTLY = "exact"

    def to_superdoc(self) -> str:
        return self.value


# Short alias used by python-docx
WD_ROW_HEIGHT = WD_ROW_HEIGHT_RULE


class WD_TABLE_ALIGNMENT(Enum):
    LEFT = "left"
    CENTER = "center"
    RIGHT = "right"

    def to_superdoc(self) -> str:
        return self.value


class WD_TABLE_DIRECTION(Enum):
    LTR = "ltr"
    RTL = "rtl"

    def to_superdoc(self) -> str:
        return self.value


class WD_ALIGN_VERTICAL(Enum):
    TOP = "top"
    CENTER = "center"
    BOTTOM = "bottom"
    BOTH = "both"

    def to_superdoc(self) -> str:
        # Superdoc enum: top | center | bottom
        if self == WD_ALIGN_VERTICAL.BOTH:
            return "center"
        return self.value


# python-docx exposes WD_CELL_VERTICAL_ALIGNMENT as an alias for cells
WD_CELL_VERTICAL_ALIGNMENT = WD_ALIGN_VERTICAL
