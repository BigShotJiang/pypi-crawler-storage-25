"""Section-related enums — python-docx parity (docx.enum.section)."""

from __future__ import annotations

from enum import Enum


class WD_ORIENTATION(Enum):
    PORTRAIT = "portrait"
    LANDSCAPE = "landscape"

    def to_superdoc(self) -> str:
        return self.value


# python-docx also exposes a short alias
WD_ORIENT = WD_ORIENTATION


class WD_SECTION_START(Enum):
    CONTINUOUS = "continuous"
    NEW_COLUMN = "nextColumn"
    NEW_PAGE = "nextPage"
    EVEN_PAGE = "evenPage"
    ODD_PAGE = "oddPage"

    def to_superdoc(self) -> str:
        if self == WD_SECTION_START.CONTINUOUS:
            return "continuous"
        if self == WD_SECTION_START.EVEN_PAGE:
            return "evenPage"
        if self == WD_SECTION_START.ODD_PAGE:
            return "oddPage"
        return "nextPage"


WD_SECTION = WD_SECTION_START


class WD_HEADER_FOOTER_INDEX(Enum):
    """Header/footer slot per section — primary, even-page, first-page.

    Word stores up to three header definitions (and three footer
    definitions) per section: the primary one used by default, an
    even-page override (when "different odd & even pages" is on), and
    a first-page override (when "different first page" is on).
    """

    PRIMARY = "primary"
    EVEN_PAGE = "even_page"
    FIRST_PAGE = "first_page"


WD_HEADER_FOOTER = WD_HEADER_FOOTER_INDEX
