"""Style-related enums — python-docx parity (docx.enum.style).

Stock python-docx 1.2.0 exposes three style enums in this module:

- :class:`WD_STYLE_TYPE`  — 4 values: CHARACTER, LIST, PARAGRAPH, TABLE.
- :class:`WD_STYLE`       — 132 values with negative-integer wIndex IDs
  matching Word's `<w:styleIds>` table (Heading 1 = -2, Body Text = -67,
  …). Used when an agent passes a Word-canonical style id rather than
  a display name.
- :class:`WD_BUILTIN_STYLE` — the display-name flavor of the same set,
  using the strings that show up in Word's UI (Heading 1 = "Heading 1",
  Body Text = "Body Text", …).

The two-flavor split is deliberate in stock python-docx: `WD_STYLE` IDs
match the OOXML schema's negative wIndex; display names are how
templates and the UI reference styles. We mirror both for parity.
"""

from __future__ import annotations

from enum import Enum


class WD_STYLE_TYPE(Enum):
    """Identifies the type of a style (one of four kinds Word supports)."""

    PARAGRAPH = "paragraph"
    CHARACTER = "character"
    LIST = "list"
    TABLE = "table"


class WD_STYLE(Enum):
    """Word's built-in style identifiers — negative integer wIndex values.

    Mirrors python-docx 1.2.0's :class:`WD_STYLE` enum exactly. Use the
    display-name flavor :class:`WD_BUILTIN_STYLE` when you need the
    string that appears in Word's UI; use this enum when the OOXML
    contract calls for the numeric id.
    """

    BLOCK_QUOTATION = -85
    BODY_TEXT = -67
    BODY_TEXT_2 = -81
    BODY_TEXT_3 = -82
    BODY_TEXT_FIRST_INDENT = -78
    BODY_TEXT_FIRST_INDENT_2 = -79
    BODY_TEXT_INDENT = -68
    BODY_TEXT_INDENT_2 = -83
    BODY_TEXT_INDENT_3 = -84
    BOOK_TITLE = -265
    CAPTION = -35
    CLOSING = -64
    COMMENT_REFERENCE = -40
    COMMENT_TEXT = -31
    DATE = -77
    DEFAULT_PARAGRAPH_FONT = -66
    EMPHASIS = -89
    ENDNOTE_REFERENCE = -43
    ENDNOTE_TEXT = -44
    ENVELOPE_ADDRESS = -37
    ENVELOPE_RETURN = -38
    FOOTER = -33
    FOOTNOTE_REFERENCE = -39
    FOOTNOTE_TEXT = -30
    HEADER = -32
    HEADING_1 = -2
    HEADING_2 = -3
    HEADING_3 = -4
    HEADING_4 = -5
    HEADING_5 = -6
    HEADING_6 = -7
    HEADING_7 = -8
    HEADING_8 = -9
    HEADING_9 = -10
    HTML_ACRONYM = -96
    HTML_ADDRESS = -97
    HTML_CITE = -98
    HTML_CODE = -99
    HTML_DFN = -100
    HTML_KBD = -101
    HTML_NORMAL = -95
    HTML_PRE = -102
    HTML_SAMP = -103
    HTML_TT = -104
    HTML_VAR = -105
    HYPERLINK = -86
    HYPERLINK_FOLLOWED = -87
    INDEX_1 = -11
    INDEX_2 = -12
    INDEX_3 = -13
    INDEX_4 = -14
    INDEX_5 = -15
    INDEX_6 = -16
    INDEX_7 = -17
    INDEX_8 = -18
    INDEX_9 = -19
    INDEX_HEADING = -34
    INTENSE_EMPHASIS = -262
    INTENSE_QUOTE = -182
    INTENSE_REFERENCE = -264
    LINE_NUMBER = -41
    LIST = -48
    LIST_2 = -51
    LIST_3 = -52
    LIST_4 = -53
    LIST_5 = -54
    LIST_BULLET = -49
    LIST_BULLET_2 = -55
    LIST_BULLET_3 = -56
    LIST_BULLET_4 = -57
    LIST_BULLET_5 = -58
    LIST_CONTINUE = -69
    LIST_CONTINUE_2 = -70
    LIST_CONTINUE_3 = -71
    LIST_CONTINUE_4 = -72
    LIST_CONTINUE_5 = -73
    LIST_NUMBER = -50
    LIST_NUMBER_2 = -59
    LIST_NUMBER_3 = -60
    LIST_NUMBER_4 = -61
    LIST_NUMBER_5 = -62
    LIST_PARAGRAPH = -180
    MACRO_TEXT = -46
    MESSAGE_HEADER = -74
    NAV_PANE = -90
    NORMAL = -1
    NORMAL_INDENT = -29
    NORMAL_OBJECT = -158
    NORMAL_TABLE = -106
    NOTE_HEADING = -80
    PAGE_NUMBER = -42
    PLAIN_TEXT = -91
    QUOTE = -181
    SALUTATION = -76
    SIGNATURE = -65
    STRONG = -88
    SUBTITLE = -75
    SUBTLE_EMPHASIS = -261
    SUBTLE_REFERENCE = -263
    TABLE_COLORFUL_GRID = -172
    TABLE_COLORFUL_LIST = -171
    TABLE_COLORFUL_SHADING = -170
    TABLE_DARK_LIST = -169
    TABLE_LIGHT_GRID = -161
    TABLE_LIGHT_GRID_ACCENT_1 = -175
    TABLE_LIGHT_LIST = -160
    TABLE_LIGHT_LIST_ACCENT_1 = -174
    TABLE_LIGHT_SHADING = -159
    TABLE_LIGHT_SHADING_ACCENT_1 = -173
    TABLE_MEDIUM_GRID_1 = -166
    TABLE_MEDIUM_GRID_2 = -167
    TABLE_MEDIUM_GRID_3 = -168
    TABLE_MEDIUM_LIST_1 = -164
    TABLE_MEDIUM_LIST_1_ACCENT_1 = -178
    TABLE_MEDIUM_LIST_2 = -165
    TABLE_MEDIUM_SHADING_1 = -162
    TABLE_MEDIUM_SHADING_1_ACCENT_1 = -176
    TABLE_MEDIUM_SHADING_2 = -163
    TABLE_MEDIUM_SHADING_2_ACCENT_1 = -177
    TABLE_OF_AUTHORITIES = -45
    TABLE_OF_FIGURES = -36
    TITLE = -63
    TOAHEADING = -47
    TOC_1 = -20
    TOC_2 = -21
    TOC_3 = -22
    TOC_4 = -23
    TOC_5 = -24
    TOC_6 = -25
    TOC_7 = -26
    TOC_8 = -27
    TOC_9 = -28


class WD_BUILTIN_STYLE(Enum):
    """Display names of Word's built-in styles.

    Same set as :class:`WD_STYLE` but keyed on the human-readable name
    Word's UI shows. Useful when matching against a paragraph's
    ``style.name``. Values match python-docx's display-name table.
    """

    BLOCK_QUOTATION = "Quote"
    BODY_TEXT = "Body Text"
    BODY_TEXT_2 = "Body Text 2"
    BODY_TEXT_3 = "Body Text 3"
    BODY_TEXT_FIRST_INDENT = "Body Text First Indent"
    BODY_TEXT_FIRST_INDENT_2 = "Body Text First Indent 2"
    BODY_TEXT_IND = "Body Text Indent"
    BODY_TEXT_IND_2 = "Body Text Indent 2"
    BODY_TEXT_IND_3 = "Body Text Indent 3"
    CAPTION = "Caption"
    DEFAULT_PARAGRAPH_FONT = "Default Paragraph Font"
    EMPHASIS = "Emphasis"
    HEADING_1 = "Heading 1"
    HEADING_2 = "Heading 2"
    HEADING_3 = "Heading 3"
    HEADING_4 = "Heading 4"
    HEADING_5 = "Heading 5"
    HEADING_6 = "Heading 6"
    HEADING_7 = "Heading 7"
    HEADING_8 = "Heading 8"
    HEADING_9 = "Heading 9"
    INTENSE_EMPHASIS = "Intense Emphasis"
    INTENSE_QUOTE = "Intense Quote"
    INTENSE_REFERENCE = "Intense Reference"
    LIST_BULLET = "List Bullet"
    LIST_BULLET_2 = "List Bullet 2"
    LIST_BULLET_3 = "List Bullet 3"
    LIST_NUMBER = "List Number"
    LIST_NUMBER_2 = "List Number 2"
    LIST_NUMBER_3 = "List Number 3"
    MACRO_TEXT = "Macro Text"
    NAV_PANE = "Nav Pane"
    NORMAL = "Normal"
    NORMAL_INDENT = "Normal Indent"
    NORMAL_TABLE = "Normal Table"
    NO_SPACING = "No Spacing"
    QUOTE = "Quote"
    SUBTITLE = "Subtitle"
    STRONG = "Strong"
    TABLE_GRID = "Table Grid"
    TITLE = "Title"
    TOC_1 = "TOC 1"
    TOC_2 = "TOC 2"
    TOC_3 = "TOC 3"
