"""HTTP bootstrap for Document.create().

The SDK's primary transport is y-websocket via Superdoc; this module is
the *only* HTTP client in the package. It exists solely so that
``Document.create()`` can hit ``POST /docs/empty`` on docx-studio to
provision a new SuperDocument asset and receive a collab bundle to open
the document with.

We use ``urllib`` from stdlib to avoid pulling ``httpx`` / ``requests``
into the runtime — this code runs in Daytona sandboxes where every MB
matters, and the existing SDK already keeps its dep tree tight.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import TypedDict

from docx.errors import (
    AuthenticationError,
    DocxError,
    SessionError,
)


class _CollabBundle(TypedDict):
    """The collab credentials returned alongside a freshly-created asset.

    Note: env-var-shape (matches what ``Session`` reads), even though
    the wire format from docx-studio uses different key names. The
    keys are renamed at parse time.
    """

    SUPERDOC_COLLAB_TOKEN: str
    KERYX_WS_URL: str
    ATHENA_WORKSPACE_ID: str


class CreateAssetResult(TypedDict):
    """Parsed response from ``POST /docs/empty``."""

    asset_id: str
    name: str
    workspace_id: str
    collab: _CollabBundle


_BASE_URL_ENV = "ATHENA_DOCX_BASE_URL"
_API_KEY_ENV = "ATHENA_DOCX_API_KEY"  # noqa: S105


def create_empty_document(
    *,
    base_url: str | None = None,
    api_key: str | None = None,
    name: str | None = None,
    parent_folder_id: str | None = None,
    workspace_id: str | None = None,
    timeout: float = 30.0,
) -> CreateAssetResult:
    """Call ``POST {base_url}/docs/empty`` and parse the response.

    Args:
        base_url: docx-studio API base, e.g. ``https://docx-studio.stg.athenaintel.com``.
            Falls back to ``$ATHENA_DOCX_BASE_URL``.
        api_key: Athena API key (PropelAuth user API key) or PropelAuth
            access token. Sent as ``Authorization: Bearer <api_key>``.
            Falls back to ``$ATHENA_DOCX_API_KEY``.
        name: Optional display title.
        parent_folder_id: Optional parent folder; defaults to workspace root.
        workspace_id: Optional workspace UUID; defaults to caller's
            current workspace.
        timeout: Request timeout in seconds.

    Returns:
        Parsed response dict with the new asset_id and a collab bundle
        ready to feed into ``Session(..., bundle=...)``.

    Raises:
        SessionError: missing base_url or unparseable response.
        AuthenticationError: missing api_key, or the server returned 401/403.
        DocxError: any other 4xx/5xx from the server.
    """
    resolved_base: str | None = base_url or os.environ.get(_BASE_URL_ENV)
    resolved_key: str | None = api_key or os.environ.get(_API_KEY_ENV)

    if not resolved_base:
        raise SessionError(
            f"Missing base_url and {_BASE_URL_ENV} env var. "
            "Pass base_url= to Document.create() or set the env var.",
        )
    if not resolved_key:
        raise AuthenticationError(
            f"Missing api_key and {_API_KEY_ENV} env var. "
            "Pass api_key= to Document.create() or set the env var.",
        )

    url: str = resolved_base.rstrip("/") + "/docs/empty"
    body: dict[str, str] = {}
    if name is not None:
        body["name"] = name
    if parent_folder_id is not None:
        body["parentFolderId"] = parent_folder_id
    if workspace_id is not None:
        body["workspaceId"] = workspace_id

    # Lazy import — _http is loaded lazily by Document.create(), so the
    # package is fully initialized by the time we reach this code.
    from docx import __version__

    payload: bytes = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(  # noqa: S310
        url,
        data=payload,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {resolved_key}",
            "Accept": "application/json",
            "User-Agent": f"athena-python-docx/{__version__}",
        },
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
            raw: bytes = resp.read()
    except urllib.error.HTTPError as e:
        err_body: str = ""
        try:
            err_body = e.read().decode("utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass
        if e.code in (401, 403):
            raise AuthenticationError(
                f"docx-studio rejected the API key (HTTP {e.code}): {err_body}",
            ) from e
        raise DocxError(
            f"docx-studio /docs/empty returned HTTP {e.code}: {err_body}",
        ) from e
    except urllib.error.URLError as e:
        raise SessionError(
            f"Unable to reach docx-studio at {url}: {e.reason}",
        ) from e

    try:
        parsed: dict = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise SessionError(
            f"docx-studio returned non-JSON response: {raw[:200]!r}",
        ) from e

    asset_id_obj = parsed.get("assetId")
    name_obj = parsed.get("name")
    ws_obj = parsed.get("workspaceId")
    collab_obj = parsed.get("collab")
    if not (
        isinstance(asset_id_obj, str)
        and isinstance(name_obj, str)
        and isinstance(ws_obj, str)
        and isinstance(collab_obj, dict)
    ):
        raise SessionError(
            f"docx-studio response is missing required fields: {parsed!r}",
        )
    token_obj = collab_obj.get("token")
    ws_url_obj = collab_obj.get("wsUrl")
    bundle_ws_obj = collab_obj.get("workspaceId")
    if not (
        isinstance(token_obj, str)
        and isinstance(ws_url_obj, str)
        and isinstance(bundle_ws_obj, str)
    ):
        raise SessionError(
            f"docx-studio collab bundle is malformed: {collab_obj!r}",
        )

    return CreateAssetResult(
        asset_id=asset_id_obj,
        name=name_obj,
        workspace_id=ws_obj,
        collab=_CollabBundle(
            SUPERDOC_COLLAB_TOKEN=token_obj,
            KERYX_WS_URL=ws_url_obj,
            ATHENA_WORKSPACE_ID=bundle_ws_obj,
        ),
    )
