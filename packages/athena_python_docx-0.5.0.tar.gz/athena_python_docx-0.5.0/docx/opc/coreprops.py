"""CoreProperties — python-docx docx.opc.coreprops.CoreProperties parity.

SuperDoc's ``DocInfoResult`` doesn't surface OOXML core-properties
(``title``, ``author``, ``subject``, ``keywords``, ``created``,
``modified``, etc.). Reads return whatever has been written within
the current process (best-effort, in-memory) and writes emit
:class:`PendingCorePropertyMutationWarning` so callers know the value
is **not** persisted to the document — a fresh ``Document(asset_id)``
in another process will see the empty/default values until SuperDoc
lands a metadata mutation op.

``last_modified_by`` is a special case: it's intentionally omitted
because Keryx owns attribution at the collab layer. Setters on it
are also memory-only but don't warn — see
``python-sdk/CLAUDE.md`` § *Intentionally omitted*.
"""

from __future__ import annotations

import warnings
from datetime import datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from docx.client import Session


class PendingCorePropertyMutationWarning(UserWarning):
    """Emitted when a ``CoreProperties`` setter is invoked but
    persistence is pending SuperDoc support. The value is stashed
    in-process so subsequent reads on the same instance return the
    written value, but a fresh ``Document(asset_id)`` will not
    surface it.
    """


_PERSISTENCE_PENDING_MSG = (
    "CoreProperties.{prop} = ... was stashed locally but NOT persisted "
    "to the document. SuperDoc's DocInfoResult does not include OOXML "
    "core-properties (title, author, subject, keywords, created, "
    "modified, …) and there is no metadata mutation op. The value will "
    "not survive across processes. See "
    "docx-studio/PYTHON_DOCX_PARITY_GAPS.md § 'What unblocks the "
    "remaining work' for the wire-op shape needed."
)


def _warn_pending(prop: str) -> None:
    warnings.warn(
        _PERSISTENCE_PENDING_MSG.format(prop=prop),
        PendingCorePropertyMutationWarning,
        stacklevel=3,
    )


class CoreProperties:
    def __init__(self, *, session: "Session") -> None:
        self._session: "Session" = session
        self._cache: dict[str, object] = {}

    @property
    def author(self) -> str:
        return str(self._cache.get("author", ""))

    @author.setter
    def author(self, value: str) -> None:
        _warn_pending("author")
        self._cache["author"] = value

    @property
    def category(self) -> str:
        return str(self._cache.get("category", ""))

    @category.setter
    def category(self, value: str) -> None:
        _warn_pending("category")
        self._cache["category"] = value

    @property
    def comments(self) -> str:
        return str(self._cache.get("comments", ""))

    @comments.setter
    def comments(self, value: str) -> None:
        _warn_pending("comments")
        self._cache["comments"] = value

    @property
    def content_status(self) -> str:
        return str(self._cache.get("content_status", ""))

    @content_status.setter
    def content_status(self, value: str) -> None:
        _warn_pending("content_status")
        self._cache["content_status"] = value

    @property
    def created(self) -> datetime | None:
        v = self._cache.get("created")
        return v if isinstance(v, datetime) else None

    @created.setter
    def created(self, value: datetime | None) -> None:
        _warn_pending("created")
        self._cache["created"] = value

    @property
    def identifier(self) -> str:
        return str(self._cache.get("identifier", ""))

    @identifier.setter
    def identifier(self, value: str) -> None:
        _warn_pending("identifier")
        self._cache["identifier"] = value

    @property
    def keywords(self) -> str:
        return str(self._cache.get("keywords", ""))

    @keywords.setter
    def keywords(self, value: str) -> None:
        _warn_pending("keywords")
        self._cache["keywords"] = value

    @property
    def language(self) -> str:
        return str(self._cache.get("language", ""))

    @language.setter
    def language(self, value: str) -> None:
        _warn_pending("language")
        self._cache["language"] = value

    @property
    def last_modified_by(self) -> str:
        # Intentionally returns empty — attribution is Keryx-owned.
        # See CLAUDE.md § 'Intentionally omitted'. The setter is
        # memory-only but does NOT warn because this property is a
        # documented intentional deviation, not an upstream block.
        return str(self._cache.get("last_modified_by", ""))

    @last_modified_by.setter
    def last_modified_by(self, value: str) -> None:
        self._cache["last_modified_by"] = value

    @property
    def last_printed(self) -> datetime | None:
        v = self._cache.get("last_printed")
        return v if isinstance(v, datetime) else None

    @last_printed.setter
    def last_printed(self, value: datetime | None) -> None:
        _warn_pending("last_printed")
        self._cache["last_printed"] = value

    @property
    def modified(self) -> datetime | None:
        v = self._cache.get("modified")
        return v if isinstance(v, datetime) else None

    @modified.setter
    def modified(self, value: datetime | None) -> None:
        _warn_pending("modified")
        self._cache["modified"] = value

    @property
    def revision(self) -> int:
        v = self._cache.get("revision", 0)
        return int(v) if isinstance(v, (int, float, str)) else 0

    @revision.setter
    def revision(self, value: int) -> None:
        _warn_pending("revision")
        self._cache["revision"] = value

    @property
    def subject(self) -> str:
        return str(self._cache.get("subject", ""))

    @subject.setter
    def subject(self, value: str) -> None:
        _warn_pending("subject")
        self._cache["subject"] = value

    @property
    def title(self) -> str:
        return str(self._cache.get("title", ""))

    @title.setter
    def title(self, value: str) -> None:
        _warn_pending("title")
        self._cache["title"] = value

    @property
    def version(self) -> str:
        return str(self._cache.get("version", ""))

    @version.setter
    def version(self, value: str) -> None:
        _warn_pending("version")
        self._cache["version"] = value


__all__ = ["CoreProperties", "PendingCorePropertyMutationWarning"]
