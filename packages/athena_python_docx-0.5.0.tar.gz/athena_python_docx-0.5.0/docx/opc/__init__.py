"""docx.opc — Open Packaging Convention bindings (stubbed)."""
