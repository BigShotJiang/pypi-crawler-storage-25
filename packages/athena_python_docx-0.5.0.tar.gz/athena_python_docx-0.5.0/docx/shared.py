"""Length and color types — python-docx parity.

python-docx defines these in docx.shared. We mirror the class surface,
but delegate underlying math (Inches→Emu, Pt→Emu) to simple formulas.
"""

from __future__ import annotations


class Length(int):
    """Base Length class. 914400 EMU = 1 inch. Matches python-docx.shared.Length."""

    def __new__(cls, emu: int | float) -> "Length":
        return super().__new__(cls, int(emu))

    @property
    def emu(self) -> int:
        return int(self)

    @property
    def inches(self) -> float:
        return int(self) / 914400

    @property
    def cm(self) -> float:
        return int(self) / 360000

    @property
    def mm(self) -> float:
        return int(self) / 36000

    @property
    def pt(self) -> float:
        return int(self) / 12700

    @property
    def twips(self) -> int:
        # 1 pt = 20 twips, and 1 pt = 12700 EMU, so 1 twip = 635 EMU.
        return int(self) // 635


class Emu(Length):
    """English Metric Unit. 914400 EMU = 1 inch."""


class Inches(Length):
    def __new__(cls, inches: float) -> "Inches":
        return super().__new__(cls, int(inches * 914400))  # type: ignore[return-value]


class Pt(Length):
    def __new__(cls, points: float) -> "Pt":
        return super().__new__(cls, int(round(points * 12700)))  # type: ignore[return-value]


class Cm(Length):
    def __new__(cls, cm: float) -> "Cm":
        return super().__new__(cls, int(cm * 360000))  # type: ignore[return-value]


class Mm(Length):
    def __new__(cls, mm: float) -> "Mm":
        return super().__new__(cls, int(mm * 36000))  # type: ignore[return-value]


class Twips(Length):
    """Twentieth of a point. 20 twips = 1 pt."""

    def __new__(cls, twips: float) -> "Twips":
        return super().__new__(cls, int(twips * 635))  # type: ignore[return-value]


class RGBColor(tuple):
    """24-bit RGB color. python-docx parity."""

    def __new__(cls, r: int, g: int, b: int) -> "RGBColor":
        if not all(0 <= v <= 255 for v in (r, g, b)):
            raise ValueError(
                f"RGBColor components must be 0..255; got ({r}, {g}, {b})",
            )
        return super().__new__(cls, (r, g, b))  # type: ignore[arg-type]

    def __str__(self) -> str:
        r, g, b = self
        return f"{r:02X}{g:02X}{b:02X}"

    def __repr__(self) -> str:
        return f"RGBColor(0x{self[0]:02X}, 0x{self[1]:02X}, 0x{self[2]:02X})"

    @classmethod
    def from_string(cls, rgb_hex_str: str) -> "RGBColor":
        s: str = rgb_hex_str.lstrip("#")
        if len(s) != 6:
            raise ValueError(
                f"RGBColor.from_string expects 6 hex chars; got {rgb_hex_str!r}",
            )
        return cls(int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))


class Parented:
    """python-docx mixin — we stub as an empty base to satisfy isinstance."""

    def __init__(self, parent: object | None = None) -> None:
        self._parent = parent


def lazyproperty(func):
    """Decorator: compute on first access, cache on instance. python-docx helper."""
    attr_name = "_lazy_" + func.__name__

    def _get(self):
        if not hasattr(self, attr_name):
            object.__setattr__(self, attr_name, func(self))
        return getattr(self, attr_name)

    return property(_get)
