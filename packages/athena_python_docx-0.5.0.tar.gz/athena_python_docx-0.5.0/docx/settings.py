"""Document Settings — python-docx docx.settings.Settings stub.

Superdoc doesn't surface Word app settings; we provide a minimal proxy
so attribute access doesn't raise for the common properties.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from docx.client import Session


class Settings:
    def __init__(self, *, session: "Session") -> None:
        self._session: "Session" = session
        self._odd_and_even_pages_header_footer: bool = False

    @property
    def odd_and_even_pages_header_footer(self) -> bool:
        return self._odd_and_even_pages_header_footer

    @odd_and_even_pages_header_footer.setter
    def odd_and_even_pages_header_footer(self, value: bool) -> None:
        self._odd_and_even_pages_header_footer = bool(value)

    @property
    def element(self) -> None:
        return None
