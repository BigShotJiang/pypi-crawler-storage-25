"""Document class — mirrors python-docx's Document.

Phase 1 supported methods:
    .paragraphs        -> list[Paragraph]  (snapshot on access)
    .tables            -> list[Table]
    .add_paragraph(text, style=None) -> Paragraph
    .add_heading(text, level=1) -> Paragraph
    .add_table(rows, cols, style=None) -> Table
    .add_picture(image_path_or_stream, width=None, height=None) -> None
    .add_page_break() -> None
    .save(path=None) -> None  (path ignored; always in-place)
    .close() -> None
"""

from __future__ import annotations

import base64
import io
import sys
from typing import TYPE_CHECKING, BinaryIO, Iterator

from docx._batching import run_sync
from docx.client import Session
from docx.errors import DocumentClosedError, ValidationError
# python-docx re-exports a subset of symbols at docx.document; mirror those
# so `from docx.document import Emu` etc. works.
from docx.enum.section import WD_SECTION, WD_SECTION_START  # noqa: F401
from docx.enum.text import WD_BREAK  # noqa: F401
from docx.section import Section, Sections  # noqa: F401
from docx.shared import Cm, Emu, Inches, Length, Mm, Pt, RGBColor, Twips  # noqa: F401
from docx.text.run import Run  # noqa: F401

if TYPE_CHECKING:
    from collections.abc import Sequence

    from docx.comments import Comment, Comments
    from docx.shape import InlineShape
    from docx.styles.style import ParagraphStyle, TableStyle
    from docx.table import Table
    from docx.text.paragraph import Paragraph


def _log_warn(msg: str) -> None:
    print(f"[docx-sdk] WARN: {msg}", file=sys.stderr)


class Document:
    """A Word document backed by a Superdoc/Keryx Y.Doc.

    Construct via :func:`docx.api.Document` (recommended) — do not
    instantiate this class directly in user code.
    """

    def __init__(
        self,
        *,
        asset_id: str,
        http_base_url: str | None = None,
        http_api_key: str | None = None,
    ) -> None:
        self._session: Session = Session(
            asset_id=asset_id,
            http_base_url=http_base_url,
            http_api_key=http_api_key,
        )
        self._saved: bool = False
        self._closed: bool = False

    @classmethod
    def create(
        cls,
        name: str | None = None,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        parent_folder_id: str | None = None,
        workspace_id: str | None = None,
    ) -> "Document":
        """Create a new SuperDocument asset and return an opened Document.

        Hits ``POST {base_url}/docs/empty`` on docx-studio with the
        provided Athena API key, then returns a Document bound to the
        new asset.

        Args:
            name: Display title for the new document. Defaults to the
                Athena naming convention if omitted.
            base_url: docx-studio API base URL. Falls back to
                ``$ATHENA_DOCX_BASE_URL``.
            api_key: Athena API key (PropelAuth user API key) or
                access token. Falls back to ``$ATHENA_DOCX_API_KEY``.
            parent_folder_id: Optional parent folder; defaults to
                workspace root.
            workspace_id: Optional workspace UUID; defaults to the
                caller's current workspace as resolved by Agora.

        Returns:
            A Document bound to the newly-created asset.

        Raises:
            SessionError: missing base_url, or docx-studio is unreachable.
            AuthenticationError: missing api_key, or 401/403 from server.
            DocxError: any other server-side failure.

        DEVIATION FROM python-docx: stock python-docx returns a blank
        in-memory document for ``Document(None)``. Our SDK is backed by
        an Athena asset, so we expose a separate ``create()`` factory
        rather than overloading the constructor.
        """
        from docx._http import create_empty_document

        result = create_empty_document(
            base_url=base_url,
            api_key=api_key,
            name=name,
            parent_folder_id=parent_folder_id,
            workspace_id=workspace_id,
        )
        return cls(
            asset_id=result["asset_id"],
            http_base_url=base_url,
            http_api_key=api_key,
        )

    # ---- Public properties ----

    @property
    def paragraphs(self) -> list["Paragraph"]:
        """Return all paragraphs in document order.

        python-docx returns a live list; we return a snapshot. For a
        live-ish list, call this again.
        """
        from docx.text.paragraph import Paragraph

        self._ensure_open()
        # doc.blocks.list takes `nodeTypes: list[str]` (not `type: str`).
        # Include "heading" too so iterating over paragraphs covers both —
        # python-docx does not distinguish headings from paragraphs at the
        # Document.paragraphs level either (they're all Paragraph instances).
        raw: object = run_sync(
            self._session.doc.blocks.list(
                {"nodeTypes": ["paragraph", "heading"], "includeText": True},
            ),
        )
        # Real shape: {"blocks": [{"kind":"block","nodeType":..,"nodeId":..,"text":..}], ...}
        if isinstance(raw, dict):
            blocks_obj: object = raw.get("blocks", [])
            blocks: list = blocks_obj if isinstance(blocks_obj, list) else []
        elif isinstance(raw, list):
            blocks = raw
        else:
            blocks = []
        out: list["Paragraph"] = []
        for b in blocks:
            if not isinstance(b, dict):
                continue
            node_id: str = str(b.get("nodeId", ""))
            if node_id:
                nt_raw = b.get("nodeType")
                nt: str = nt_raw if isinstance(nt_raw, str) and nt_raw else "paragraph"
                out.append(
                    Paragraph(
                        session=self._session,
                        node_id=node_id,
                        node_type=nt,
                    ),
                )
        return out

    @property
    def tables(self) -> list["Table"]:
        """Return all tables in document order."""
        from docx.table import Table

        self._ensure_open()
        find_result: dict = run_sync(
            self._session.doc.find({"type": "table"}),
        )
        items: list[dict] = find_result.get("items", [])
        return [
            Table(session=self._session, node_id=item["address"]["nodeId"])
            for item in items
        ]

    @property
    def sections(self):
        """Return the document's sections collection."""

        self._ensure_open()
        return Sections(session=self._session)

    def iter_inner_content(self) -> "Iterator[Paragraph | Table]":
        """Yield each top-level Paragraph or Table in document order.

        Mirrors python-docx 1.x. Order follows the SuperDoc block list,
        which is document order. Paragraphs include both ``paragraph`` and
        ``heading`` node types — python-docx surfaces both as ``Paragraph``
        instances at this level.
        """
        from docx.table import Table
        from docx.text.paragraph import Paragraph

        self._ensure_open()
        raw: object = run_sync(
            self._session.doc.blocks.list(
                {
                    "nodeTypes": ["paragraph", "heading", "table"],
                    "includeText": False,
                },
            ),
        )
        blocks: list = []
        if isinstance(raw, dict):
            blocks_obj: object = raw.get("blocks", [])
            if isinstance(blocks_obj, list):
                blocks = blocks_obj
        elif isinstance(raw, list):
            blocks = raw
        for b in blocks:
            if not isinstance(b, dict):
                continue
            node_id: str = str(b.get("nodeId", ""))
            if not node_id:
                continue
            nt = b.get("nodeType")
            if nt == "table":
                yield Table(session=self._session, node_id=node_id)
            else:
                yield Paragraph(
                    session=self._session,
                    node_id=node_id,
                    node_type=nt if isinstance(nt, str) else "paragraph",
                )

    @property
    def inline_shapes(self):
        """Return the document's inline-shape collection."""
        from docx.shape import InlineShapes

        self._ensure_open()
        return InlineShapes(session=self._session)

    @property
    def styles(self):
        """Return the document's styles collection."""
        from docx.styles.styles import Styles

        self._ensure_open()
        return Styles(session=self._session)

    @property
    def core_properties(self):
        """Return a minimal CoreProperties proxy.

        Most python-docx fields aren't surfaced by Superdoc; accessing an
        unsupported field returns None rather than raising.
        """
        from docx.opc.coreprops import CoreProperties

        return CoreProperties(session=self._session)

    @property
    def settings(self):
        """Return a minimal Settings proxy (stubbed; Superdoc doesn't surface app settings)."""
        from docx.settings import Settings

        return Settings(session=self._session)

    @property
    def element(self):
        """python-docx returns the underlying lxml element. We return a best-effort proxy."""
        return None

    part = element

    # ---- Comments (stubbed — see docx-studio/PYTHON_DOCX_PARITY_GAPS.md § 3.1) ----

    @property
    def comments(self) -> "Comments":
        """Return a :class:`Comments` collection for the document.

        Stub — yields an empty collection and accepts ``isinstance``
        checks. ``add_comment`` raises until backend support lands.
        """
        from docx.comments import Comments

        return Comments(session=self._session)

    def add_comment(
        self,
        runs: "Run | Sequence[Run]",
        text: "str | None" = "",
        author: str = "",
        initials: "str | None" = "",
    ) -> "Comment":
        """Insert a comment anchored to one or more runs.

        Mirrors python-docx ``Document.add_comment(runs, text, author,
        initials) -> Comment``. The runs must be co-located in a single
        block (Word can't anchor a comment to disjoint blocks); if they
        span multiple blocks the comment is created unanchored.
        """
        from docx.comments import _create_anchored_comment

        return _create_anchored_comment(
            self._session,
            runs,
            text=text or "",
            author=author,
            initials=initials or "",
        )

    # ---- Append operations ----

    @staticmethod
    def _normalize_text(text: str) -> str:
        """Normalize line endings like python-docx: \\r\\n → \\n\\n, lone \\r → \\n."""
        # python-docx's text IO strips \r and converts \r to \n.
        if not text:
            return text
        # \r\n → \n\n (preserves paragraph-break semantics)
        return text.replace("\r\n", "\n\n").replace("\r", "\n")

    def add_paragraph(
        self,
        text: str = "",
        style: "str | ParagraphStyle | None" = None,
    ) -> "Paragraph":
        """Append a new paragraph at the end of the document.

        Args:
            text: The paragraph text.
            style: Style name string (e.g. "Heading 1", "Normal") or a
                   :class:`ParagraphStyle` instance. ``None`` uses the
                   default style.

        Returns:
            The newly-created Paragraph.
        """
        from docx.styles.style import ParagraphStyle
        from docx.text.paragraph import Paragraph

        self._ensure_open()

        # Coerce ParagraphStyle instances to their style id so the rest
        # of this method can treat `style` as an Optional[str].
        style_str: str | None = (
            style.style_id if isinstance(style, ParagraphStyle) else style
        )

        # Use Superdoc's canonical primitive `doc.create.paragraph`. It
        # accepts an `at` anchor and a `text` body; an empty `text` creates
        # a truly-empty paragraph (no markdown-parser edge case).
        #
        # For heading styles we still dispatch to add_heading, which uses
        # `doc.create.heading` (also canonical, takes `level`).
        if style_str and style_str.lower().startswith("heading"):
            try:
                level: int = int(style_str.rsplit(" ", 1)[-1])
            except ValueError:
                level = 1
            return self.add_heading(text=text, level=level)
        if style_str and style_str.lower() == "title":
            return self.add_heading(text=text, level=0)

        # python-docx parity: tabs and line breaks in `text` must
        # round-trip as Word ``<w:tab/>`` / ``<w:br/>`` elements, not
        # literal characters. SuperDoc's ``create.paragraph(text=…)``
        # stores them as literal text, so when control chars are
        # present we create an EMPTY paragraph and let
        # ``Paragraph.add_run`` (which segments tabs/breaks) do the
        # heavy lifting.
        normalized: str = self._normalize_text(text)
        has_control_chars = any(ch in "\t\n\r" for ch in normalized)
        params: dict = {
            "text": "" if has_control_chars else normalized,
            "at": {"kind": "documentEnd"},
        }
        result: dict = run_sync(
            self._session.doc.create.paragraph(params),
        )
        node_id: str = _extract_inserted_node_id(result, expected_type="paragraph")
        if not node_id:
            raise RuntimeError(
                f"Superdoc did not return a nodeId for add_paragraph: {result!r}",
            )
        para = Paragraph(
            session=self._session, node_id=node_id, node_type="paragraph",
        )
        if has_control_chars and normalized:
            # Use the segment-aware path on Paragraph.add_run so each
            # tab/newline lands as a real inline.
            para.add_run(normalized)
        # Apply non-heading paragraph styles via setStyle. python-docx
        # does this implicitly when you pass `style=...` — we mirror by
        # routing through Paragraph.style which calls
        # doc.styles.paragraph.setStyle on Superdoc.
        if style_str:
            # Don't swallow style-application failures — a bad styleId
            # or transport error otherwise leaves the user with a
            # paragraph that quietly missed the style they asked for.
            para.style = style_str
        return para

    def add_heading(
        self,
        text: str = "",
        level: int = 1,
    ) -> "Paragraph":
        """Append a heading via Superdoc's canonical `doc.create.heading`."""
        from docx.text.paragraph import Paragraph

        self._ensure_open()
        if not 0 <= level <= 9:
            raise ValidationError(
                f"level must be in 0..9; got {level}",
            )

        # python-docx parity: tabs/newlines in `text` must round-trip
        # as Word inlines, not literal characters. SuperDoc's
        # create.heading / create.paragraph store the `text` parameter
        # as a single text run, so when control chars are present we
        # create an empty block and let Paragraph.add_run segment the
        # text into proper tab/lineBreak inlines.
        normalized = self._normalize_text(text)
        has_control_chars = any(ch in "\t\n\r" for ch in normalized)
        wire_text = "" if has_control_chars else normalized

        # python-docx semantics: level=0 is Title, 1..9 are Heading N.
        # Superdoc's doc.create.heading only accepts integer levels 1..6,
        # so Title (level=0) routes through create.paragraph followed by a
        # style change to "Title". Levels 7..9 fall through to create.heading
        # and will raise a SuperDocError if the runtime rejects them — that
        # mirrors python-docx's tolerance without silently degrading.
        if level == 0:
            result: dict = run_sync(
                self._session.doc.create.paragraph(
                    {"text": wire_text, "at": {"kind": "documentEnd"}},
                ),
            )
            node_id: str = _extract_inserted_node_id(
                result, expected_type="paragraph",
            )
            if not node_id:
                raise RuntimeError(
                    f"Superdoc did not return a nodeId for add_heading(level=0): {result!r}",
                )
            paragraph = Paragraph(
                session=self._session,
                node_id=node_id,
                node_type="paragraph",
            )
            paragraph.style = "Title"
            if has_control_chars and normalized:
                paragraph.add_run(normalized)
            return paragraph

        params: dict = {
            "text": wire_text,
            "level": level,
            "at": {"kind": "documentEnd"},
        }
        result = run_sync(
            self._session.doc.create.heading(params),
        )
        # Bug fix: was passing expected_type="paragraph" here (wrong); the
        # fallback loop recovered but the code of intent was wrong. Fixed to
        # expected_type="heading" so we extract from the correct response key.
        node_id = _extract_inserted_node_id(result, expected_type="heading")
        if not node_id:
            raise RuntimeError(
                f"Superdoc did not return a nodeId for add_heading: {result!r}",
            )
        heading = Paragraph(
            session=self._session, node_id=node_id, node_type="heading",
        )
        if has_control_chars and normalized:
            heading.add_run(normalized)
        return heading

    def add_table(
        self,
        rows: int,
        cols: int,
        style: "str | TableStyle | None" = None,
    ) -> "Table":
        """Append a table with the given dimensions via `doc.create.table`."""
        from docx.table import Table

        self._ensure_open()
        if rows < 1 or cols < 1:
            raise ValidationError(
                f"rows and cols must be >= 1; got rows={rows} cols={cols}",
            )

        # The real param is `columns` (not `cols`). `at` is required to
        # position the table; we always append to document end.
        result: dict = run_sync(
            self._session.doc.create.table(
                {
                    "rows": rows,
                    "columns": cols,
                    "at": {"kind": "documentEnd"},
                },
            ),
        )
        node_id: str = _extract_inserted_node_id(result, expected_type="table")
        if not node_id:
            raise RuntimeError(
                f"Superdoc did not return a nodeId for add_table: {result!r}",
            )

        if style:
            from docx.styles.style import BaseStyle

            style_id = style.style_id if isinstance(style, BaseStyle) else str(style)
            run_sync(
                self._session.doc.tables.set_style(
                    {"nodeId": node_id, "styleId": style_id},
                ),
            )
            # Re-fetch nodeId — set_style may rotate it. Prefer matching the
            # original id; fall back to last-in-list with a warning.
            refetch: dict = run_sync(
                self._session.doc.find({"type": "table"}),
            )
            items: list[dict] = refetch.get("items", [])
            matched: bool = any(
                isinstance(item, dict)
                and item.get("address", {}).get("nodeId") == node_id
                for item in items
            )
            if not matched and items:
                last: dict = items[-1] if isinstance(items[-1], dict) else {}
                new_id: str = str(last.get("address", {}).get("nodeId", ""))
                if new_id:
                    import sys
                    print(
                        f"[docx-sdk] WARN: add_table nodeId rotated after "
                        f"set_style: {node_id} -> {new_id}",
                        file=sys.stderr,
                    )
                    node_id = new_id

        return Table(session=self._session, node_id=node_id)

    def add_picture(
        self,
        image_path_or_stream: str | BinaryIO,
        width: "int | Length | None" = None,
        height: "int | Length | None" = None,
    ) -> "InlineShape":
        """Append an inline image via ``doc.create.image``.

        Mirrors python-docx ``Document.add_picture`` — returns the new
        :class:`InlineShape` proxy.
        """
        from docx._image_utils import sniff_content_type
        from docx.shape import InlineShape
        from docx.text.run import _build_inline_shape_info

        self._ensure_open()

        image_bytes: bytes
        fallback_path: str = ""
        if isinstance(image_path_or_stream, str):
            with open(image_path_or_stream, "rb") as f:
                image_bytes = f.read()
            fallback_path = image_path_or_stream
        elif isinstance(image_path_or_stream, io.IOBase):
            image_bytes = image_path_or_stream.read()
        else:
            raise TypeError(
                "Expected path str or binary stream, "
                f"got {type(image_path_or_stream).__name__}",
            )
        # Magic-byte sniff first (catches mistyped extensions and bytes
        # streams without filenames); extension is the fallback only
        # for unknown/off-format payloads. Mirrors python-docx's
        # Pillow-based detection without requiring Pillow.
        content_type: str = sniff_content_type(
            image_bytes, fallback_path=fallback_path
        )

        b64: str = base64.b64encode(image_bytes).decode("ascii")
        data_uri: str = f"data:{content_type};base64,{b64}"

        w_px: float = _emu_to_px(width) if width is not None else 576.0
        h_px: float = _emu_to_px(height) if height is not None else 432.0

        result: object = run_sync(
            self._session.doc.create.image(
                {
                    "src": data_uri,
                    "size": {"width": w_px, "height": h_px},
                    "at": {"kind": "documentEnd"},
                },
            ),
        )
        info = _build_inline_shape_info(result, width=w_px, height=h_px)
        return InlineShape(session=self._session, info=info)

    def add_section(self, start_type: "WD_SECTION_START" = WD_SECTION_START.NEW_PAGE):  # type: ignore[name-defined]
        """Append a new section and return its Section proxy.

        Mirrors python-docx: creating a section adds a trailing empty
        paragraph that marks the section boundary.
        """

        self._ensure_open()
        # python-docx always inserts an anchor paragraph at the section break
        self.add_paragraph("")
        break_type: str = "nextPage"
        if start_type is not None:
            if isinstance(start_type, WD_SECTION_START):
                break_type = start_type.to_superdoc()
            elif isinstance(start_type, str):
                break_type = start_type
        run_sync(
            self._session.doc.create.section_break(
                {"at": {"kind": "documentEnd"}, "breakType": break_type},
            ),
        )
        info: object = run_sync(self._session.doc.sections.list({}))
        items: list = []
        if isinstance(info, dict):
            items_obj = info.get("items", [])
            if isinstance(items_obj, list):
                items = items_obj
        if not items:
            raise RuntimeError(
                "Superdoc did not return any sections after add_section",
            )
        last = items[-1]
        addr = last.get("address", {}) if isinstance(last, dict) else {}
        return Section(session=self._session, address=addr if isinstance(addr, dict) else {})

    def add_page_break(self) -> None:
        """Append a page break at the end of the document.

        python-docx appends an empty paragraph with a page-break run inside;
        `doc.paragraphs` includes that new paragraph. We mirror by adding
        an anchor paragraph first, then the section break.
        """
        self._ensure_open()
        # Anchor paragraph so doc.paragraphs reflects the break visually.
        self.add_paragraph("")
        run_sync(
            self._session.doc.create.section_break(
                {"at": {"kind": "documentEnd"}, "breakType": "nextPage"},
            ),
        )

    # ---- Lifecycle ----

    def _flush(self) -> None:
        """Internal: drain pending mutations to Keryx without requiring
        a path (used by ``__exit__`` and lifecycle teardown)."""
        self._ensure_open()
        run_sync(self._session.save(in_place=True))
        self._saved = True

    def save(self, path_or_stream: "str | BinaryIO") -> None:  # noqa: ARG002
        """Flush pending edits to Keryx.

        ``path_or_stream`` matches python-docx's ``Document.save`` signature
        and is required to match the upstream contract — calling
        ``save()`` with no argument is a TypeError, just like python-docx.
        The argument is accepted but ignored at runtime: writes are always
        in-place against the Y.Doc. To export to a local file, use the
        Olympus UI's Export DOCX.
        """
        self._flush()

    def close(self) -> None:
        """Close the session. Not strictly needed (context-managed)."""
        if self._closed:
            return
        try:
            run_sync(self._session.close())
        finally:
            self._closed = True

    def __enter__(self) -> "Document":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:  # noqa: ANN001
        if exc_type is None and not self._saved and self._session.is_open:
            try:
                # Use _flush(), not save() — python-docx requires
                # save(path_or_stream); the context-manager path has no
                # path to forward, so it drains internally.
                self._flush()
            except Exception as e:
                _log_warn(f"autosave failed for {self._session.asset_id}: {e}")
        self.close()

    # ---- Internals ----

    def _ensure_open(self) -> None:
        if self._closed:
            raise DocumentClosedError(
                f"Document {self._session.asset_id} is closed.",
            )
        if not self._session.is_open:
            run_sync(self._session.open())


# ---- Module-level helpers ----

def _extract_inserted_node_id(result: dict, *, expected_type: str) -> str:
    """Parse Superdoc create/insert response to find the new node's blockId.

    Real observed shapes (superdoc-sdk 1.6.0.dev29):

      doc.create.paragraph/heading/table returns
          {"success": True, "<paragraph|heading|table>": {"nodeId": "..."}}

      doc.insert (markdown/text) returns
          {"receipt": {"resolution": {"target": {"blockId": "..."}}}, ...}

    We probe create-shape first (nested by expected_type), then insert-shape.
    Returns "" if nothing matches.
    """
    if not isinstance(result, dict):
        return ""

    # Shape 1 — doc.create.paragraph/heading/table/image: top-level key
    # named by the result type holds `{kind, nodeType, nodeId}`.
    for key in (expected_type, "paragraph", "heading", "table", "image"):
        obj = result.get(key)
        if isinstance(obj, dict):
            node_id = obj.get("nodeId")
            if isinstance(node_id, str) and node_id:
                return node_id

    # Shape 2 — doc.insert: receipt.resolution.target.blockId.
    receipt: object = result.get("receipt")
    if isinstance(receipt, dict):
        resolution: object = receipt.get("resolution")
        if isinstance(resolution, dict):
            target: object = resolution.get("target")
            if isinstance(target, dict):
                block_id: str = str(target.get("blockId", ""))
                if block_id:
                    return block_id

    # Shape 3 — top-level blockId or target.blockId.
    top_block: object = result.get("blockId")
    if isinstance(top_block, str) and top_block:
        return top_block
    top_target: object = result.get("target")
    if isinstance(top_target, dict):
        tb: str = str(top_target.get("blockId", ""))
        if tb:
            return tb

    # Shape 4 (legacy): nested result.result.insertedNodes[] / nodes[].
    data_obj: object = result.get("result", {})
    data: dict = data_obj if isinstance(data_obj, dict) else {}
    nodes_obj: object = data.get("insertedNodes", data.get("nodes", []))
    nodes: list = nodes_obj if isinstance(nodes_obj, list) else []
    for node in nodes:
        if not isinstance(node, dict):
            continue
        if node.get("type") == expected_type:
            return str(node.get("nodeId", ""))
    if nodes and isinstance(nodes[-1], dict):
        return str(nodes[-1].get("nodeId", ""))

    return ""


def _emu_to_px(emu: object) -> float:
    """EMU → px at 96 DPI. 914400 EMU = 1 inch.

    Accepts Emu/Inches/Pt subclasses (all of which are int) or plain int.
    """
    val: float = float(emu) if not hasattr(emu, "emu") else float(emu.emu)  # type: ignore[union-attr]
    return val / 914400.0 * 96.0
