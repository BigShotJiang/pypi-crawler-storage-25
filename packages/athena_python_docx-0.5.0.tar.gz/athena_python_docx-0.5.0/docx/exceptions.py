"""Public exception classes — python-docx parity (``docx.exceptions``).

python-docx exposes three exception types here:

  * :class:`PythonDocxError` — root for all package errors.
  * :class:`InvalidXmlError` — XML-layer error (athena never raises
    this; included for ``except`` parity).
  * :class:`InvalidSpanError` — raised by ``_Cell.merge`` when the
    requested merge would produce an invalid span.

athena-python-docx already has its own :mod:`docx.errors` hierarchy
(``DocxError``, ``ValidationError``, etc.) for SDK-internal concerns.
We bridge the two by making :class:`InvalidSpanError` a subclass of
both ``PythonDocxError`` (for python-docx parity) and
:class:`docx.errors.ValidationError` (so existing ``except
ValidationError`` handlers keep working).
"""

from __future__ import annotations

from docx.errors import ValidationError


class PythonDocxError(Exception):
    """Root exception for python-docx parity errors."""


class InvalidXmlError(PythonDocxError):
    """Raised when an XML document is malformed.

    athena-python-docx does not parse XML locally — included only so
    ``except InvalidXmlError`` clauses written against python-docx
    continue to compile.
    """


class InvalidSpanError(PythonDocxError, ValidationError):
    """Raised by ``_Cell.merge`` when the requested merge would result
    in a non-rectangular or otherwise illegal span."""


__all__ = ["PythonDocxError", "InvalidXmlError", "InvalidSpanError"]
