"""Re-export of :class:`docx.text.run.Font` at the canonical
``docx.text.font`` path.

python-docx defines ``Font`` in ``docx/text/font.py`` and uses it as a
``run.font`` proxy. athena-python-docx defined ``Font`` next to ``Run``
in :mod:`docx.text.run` for historical reasons. This shim restores
parity for ``from docx.text.font import Font`` import paths without
duplicating the implementation.
"""

from __future__ import annotations

from docx.text.run import Font

__all__ = ["Font"]
