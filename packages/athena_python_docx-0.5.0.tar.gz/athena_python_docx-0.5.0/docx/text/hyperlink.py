"""Hyperlink — python-docx docx.text.hyperlink.Hyperlink parity.

Exposed via `Paragraph.hyperlinks`. Wraps a run that carries a hyperlink
mark or an `href` attribute.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from docx.text.paragraph import Paragraph


class Hyperlink:
    def __init__(
        self,
        *,
        paragraph: "Paragraph",
        target: str,
        run: dict | None = None,
    ) -> None:
        self._paragraph: "Paragraph" = paragraph
        self._target: str = target
        self._run: dict | None = run

    @property
    def address(self) -> str:
        return self._target

    @property
    def url(self) -> str:
        return self._target

    @property
    def fragment(self) -> str:
        return ""

    @property
    def text(self) -> str:
        if isinstance(self._run, dict):
            t = self._run.get("text")
            if isinstance(t, str):
                return t
        return ""

    @property
    def runs(self) -> list:
        return []

    @property
    def contains_page_break(self) -> bool:
        return False
