"""Style classes — python-docx ``docx.styles.style`` parity.

Each public read-write property is also a setter. Style *metadata*
mutations (``name``, ``priority``, ``hidden``, ``locked``,
``quick_style``, ``unhide_when_used``, ``base_style``,
``next_paragraph_style``) are **not yet persisted** through SuperDoc.

SuperDoc 1.7 exposes only:

  * ``doc.styles.apply`` — patches the document-level ``docDefaults``
    block in ``word/styles.xml`` (target.scope is constrained to
    ``"docDefaults"``; there's no per-style variant).
  * ``doc.styles.paragraph.setStyle`` / ``clearStyle`` — apply or
    remove a style reference on a paragraph (does not mutate the
    style definition itself).

Per-style metadata mutation needs a new SuperDoc op
(``doc.styles.setMetadata`` or equivalent) that doesn't exist as of
1.7. Until then, the setters here store the new value locally on
the instance and emit a :class:`PendingStyleMutationWarning` so
callers see at runtime that the mutation will be lost on document
save. This trades silent no-op for "warn-and-no-op". See
``docx-studio/PYTHON_DOCX_PARITY_GAPS.md`` § *What unblocks the
remaining work* for the exact wire-op shape needed.
"""

from __future__ import annotations

import warnings
from typing import TYPE_CHECKING, Any

from docx._batching import run_sync

if TYPE_CHECKING:
    from docx.client import Session
    from docx.enum.style import WD_STYLE_TYPE
    from docx.text.run import Font


class PendingStyleMutationWarning(UserWarning):
    """Emitted when a style setter is invoked but persistence is
    pending backend support."""


_PERSISTENCE_PENDING_MSG = (
    "{cls}.{prop} = ... was stashed locally but NOT persisted to the "
    "document. SuperDoc 1.7's doc.styles.apply only mutates docDefaults; "
    "per-style metadata (name, priority, hidden, locked, quickStyle, "
    "basedOn, next, unhideWhenUsed) needs a new SuperDoc op that doesn't "
    "exist yet. See docx-studio/PYTHON_DOCX_PARITY_GAPS.md § 'What unblocks "
    "the remaining work' for the wire-op shape needed."
)


def _warn_pending(cls: str, prop: str) -> None:
    warnings.warn(
        _PERSISTENCE_PENDING_MSG.format(cls=cls, prop=prop),
        PendingStyleMutationWarning,
        stacklevel=3,
    )


class BaseStyle:
    """Base for all style kinds. Matches python-docx.styles.style.BaseStyle."""

    def __init__(
        self,
        *,
        name: str,
        style_type: "WD_STYLE_TYPE",
        session: "Session | None" = None,
    ) -> None:
        self._name: str = name
        self._type: "WD_STYLE_TYPE" = style_type
        self._session: "Session | None" = session
        # Local override storage for write-side parity (see module docstring).
        self._overrides: dict[str, Any] = {}

    # ---- name ----
    @property
    def name(self) -> str:
        return self._overrides.get("name", self._name)

    @name.setter
    def name(self, value: str) -> None:
        _warn_pending(type(self).__name__, "name")
        self._overrides["name"] = value

    # ---- style_id ----
    @property
    def style_id(self) -> str:
        return self._overrides.get("style_id", self._name)

    @style_id.setter
    def style_id(self, value: str) -> None:
        _warn_pending(type(self).__name__, "style_id")
        self._overrides["style_id"] = value

    @property
    def type(self) -> "WD_STYLE_TYPE":
        return self._type

    @property
    def builtin(self) -> bool:
        """python-docx 1.x: True if this style is one of Word's
        built-in styles (Heading 1, Body Text, Normal Table, …).

        We check against the static built-in lists in
        :mod:`docx.styles.styles` rather than asking SuperDoc — the set
        is fixed by Word and doesn't depend on per-document styling.
        """
        from docx.styles.styles import (
            _BUILTIN_CHARACTER_STYLES,
            _BUILTIN_PARAGRAPH_STYLES,
            _BUILTIN_TABLE_STYLES,
        )

        return self._name in (
            *_BUILTIN_PARAGRAPH_STYLES,
            *_BUILTIN_CHARACTER_STYLES,
            *_BUILTIN_TABLE_STYLES,
        )

    # ---- locked ----
    @property
    def locked(self) -> bool:
        """python-docx 1.x: True if the style is locked from UI editing.

        SuperDoc doesn't currently surface a per-style locked flag in
        ``doc.info``, so the read side returns the local override (or
        ``False`` if untouched).
        """
        return bool(self._overrides.get("locked", False))

    @locked.setter
    def locked(self, value: bool) -> None:
        _warn_pending(type(self).__name__, "locked")
        self._overrides["locked"] = bool(value)

    # ---- hidden ----
    @property
    def hidden(self) -> bool:
        return bool(self._overrides.get("hidden", False))

    @hidden.setter
    def hidden(self, value: bool) -> None:
        _warn_pending(type(self).__name__, "hidden")
        self._overrides["hidden"] = bool(value)

    # ---- quick_style ----
    @property
    def quick_style(self) -> bool:
        return bool(self._overrides.get("quick_style", False))

    @quick_style.setter
    def quick_style(self, value: bool) -> None:
        _warn_pending(type(self).__name__, "quick_style")
        self._overrides["quick_style"] = bool(value)

    # ---- priority ----
    @property
    def priority(self) -> int | None:
        return self._overrides.get("priority")

    @priority.setter
    def priority(self, value: int | None) -> None:
        _warn_pending(type(self).__name__, "priority")
        self._overrides["priority"] = value

    # ---- unhide_when_used ----
    @property
    def unhide_when_used(self) -> bool:
        return bool(self._overrides.get("unhide_when_used", False))

    @unhide_when_used.setter
    def unhide_when_used(self, value: bool) -> None:
        _warn_pending(type(self).__name__, "unhide_when_used")
        self._overrides["unhide_when_used"] = bool(value)

    def delete(self) -> None:
        return None


class _StyleFontBacking:
    """Quacks like a :class:`Run` for :class:`Font`'s purposes — reads
    backing data off a :class:`BaseStyle` instead of off run inline marks.

    Reads: ``fontFamily`` / ``fontSize`` come from
    ``info.styles.paragraphStyles[styleId]`` (the only style metadata
    SuperDoc 1.8 surfaces). Everything else falls back to the style's
    ``_overrides`` dict.
    Writes: warn-and-stash, same shape as the rest of the
    style-setter contract.

    A local override always wins over the info read, so ``font.size =
    Pt(14)`` round-trips correctly from the caller's perspective even
    though the mutation isn't persisted to the document.
    """

    def __init__(self, style: "BaseStyle") -> None:
        self._style: "BaseStyle" = style

    def _info_entry(self) -> dict | None:
        if self._style._session is None:
            return None
        try:
            info: object = run_sync(self._style._session.doc.info({}))
        except Exception:
            return None
        if not isinstance(info, dict):
            return None
        styles_block = info.get("styles")
        if not isinstance(styles_block, dict):
            return None
        items = styles_block.get("paragraphStyles")
        if not isinstance(items, list):
            return None
        target_id = self._style.style_id
        for entry in items:
            if isinstance(entry, dict) and entry.get("styleId") == target_id:
                return entry
        return None

    def _read_inline_attr(self, key: str) -> Any:
        # Local override wins — callers see their own writes round-trip.
        override_key = f"font.{key}"
        if override_key in self._style._overrides:
            return self._style._overrides[override_key]
        # Fall back to SuperDoc's per-style info for the two fields it
        # surfaces. Other attributes return None — SuperDoc doesn't
        # expose them at the style level.
        if key in ("fontFamily", "fontSize"):
            entry = self._info_entry()
            if entry is not None:
                value = entry.get(key)
                if value is not None:
                    return value
        return None

    def _apply_inline(self, **kwargs: Any) -> None:
        cls = type(self._style).__name__
        for key, value in kwargs.items():
            _warn_pending(cls, f"font.{key}")
            self._style._overrides[f"font.{key}"] = value

    # ---- Run-shaped mirror properties for Font's delegations ----
    @property
    def bold(self) -> bool | None:
        v = self._read_inline_attr("bold")
        return bool(v) if isinstance(v, bool) else None

    @bold.setter
    def bold(self, value: bool | None) -> None:
        if value is None:
            return
        self._apply_inline(bold=bool(value))

    @property
    def italic(self) -> bool | None:
        v = self._read_inline_attr("italic")
        return bool(v) if isinstance(v, bool) else None

    @italic.setter
    def italic(self, value: bool | None) -> None:
        if value is None:
            return
        self._apply_inline(italic=bool(value))

    @property
    def underline(self) -> Any:
        v = self._read_inline_attr("underline")
        if isinstance(v, bool):
            return v
        return v if v is not None else None

    @underline.setter
    def underline(self, value: Any) -> None:
        if value is None:
            return
        self._apply_inline(underline=value)

    @property
    def style(self) -> str | None:
        v = self._read_inline_attr("rStyle")
        return str(v) if v else None

    @style.setter
    def style(self, value: str | None) -> None:
        if value is None:
            return
        self._apply_inline(rStyle=str(value))


class CharacterStyle(BaseStyle):
    @property
    def base_style(self) -> "CharacterStyle | None":
        return self._overrides.get("base_style")

    @base_style.setter
    def base_style(self, value: "CharacterStyle | None") -> None:
        _warn_pending(type(self).__name__, "base_style")
        self._overrides["base_style"] = value

    @property
    def font(self) -> "Font":
        """The :class:`Font` object exposing this style's character
        formatting (font name, size, color, bold, italic, …).

        Backed by a :class:`_StyleFontBacking` so reads pull from
        SuperDoc's ``info.styles.paragraphStyles`` and writes are
        warn-and-stashed via :class:`PendingStyleMutationWarning`. The
        backing is constructed lazily so accessing ``style.font``
        without using it is free.
        """
        from docx.text.run import Font

        backing = self._overrides.get("__font_backing__")
        if backing is None:
            backing = _StyleFontBacking(self)
            self._overrides["__font_backing__"] = backing
        return Font(backing)


class ParagraphStyle(CharacterStyle):
    @property
    def paragraph_format(self):
        return None

    @property
    def next_paragraph_style(self) -> "ParagraphStyle | None":
        return self._overrides.get("next_paragraph_style")

    @next_paragraph_style.setter
    def next_paragraph_style(self, value: "ParagraphStyle | None") -> None:
        _warn_pending(type(self).__name__, "next_paragraph_style")
        self._overrides["next_paragraph_style"] = value


class TableStyle(ParagraphStyle):
    pass


# python-docx's canonical name is ``_TableStyle`` (single-underscore
# convention for "users receive this but don't construct it"). We
# expose ``TableStyle`` publicly and alias the underscore name so
# ``from docx.styles.style import _TableStyle`` works at parity.
_TableStyle = TableStyle


class _NumberingStyle(BaseStyle):
    pass


__all__ = [
    "BaseStyle",
    "CharacterStyle",
    "ParagraphStyle",
    "TableStyle",
    "PendingStyleMutationWarning",
]
