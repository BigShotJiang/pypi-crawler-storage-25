"""docx.styles — mirrors python-docx.styles."""
