"""Styles collection — python-docx docx.styles.styles.Styles parity.

Backed by a best-effort read of Superdoc's `doc.info`/`doc.getInfo` output
and in-memory tracking for add_style/delete_style. Since Superdoc owns
the underlying style registry, full round-tripping is Phase 2.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from docx._batching import run_sync
from docx.enum.style import WD_STYLE_TYPE
from docx.styles.style import (
    BaseStyle,
    CharacterStyle,
    ParagraphStyle,
    TableStyle,
    _NumberingStyle,
)

if TYPE_CHECKING:
    from docx.client import Session


_BUILTIN_PARAGRAPH_STYLES = [
    "Normal", "Heading 1", "Heading 2", "Heading 3", "Heading 4",
    "Heading 5", "Heading 6", "Heading 7", "Heading 8", "Heading 9",
    "Title", "Subtitle", "Quote", "Intense Quote", "No Spacing",
    "List Paragraph", "Caption", "TOC 1", "TOC 2", "TOC 3",
    "Body Text", "Body Text 2", "Body Text 3",
]
_BUILTIN_CHARACTER_STYLES = [
    "Default Paragraph Font", "Emphasis", "Strong", "Intense Emphasis",
    "Intense Reference", "Book Title",
]
_BUILTIN_TABLE_STYLES = [
    "Normal Table", "Table Grid", "Light Shading", "Medium Shading 1",
    "Medium Grid 1", "Colorful Grid", "List Table 1", "List Table 2",
]


class Styles:
    """Collection of styles. Iterable, len, __getitem__."""

    def __init__(self, *, session: "Session") -> None:
        self._session: "Session" = session
        self._added: dict[str, BaseStyle] = {}

    def _all(self) -> list[BaseStyle]:
        out: list[BaseStyle] = []
        try:
            info: object = run_sync(self._session.doc.info({}))
        except Exception:
            info = None
        # Try to pull style list from doc.info if available.
        if isinstance(info, dict):
            styles_obj: object = info.get("styles")
            if isinstance(styles_obj, dict):
                par_styles = styles_obj.get("paragraphStyles")
                if isinstance(par_styles, list):
                    for ps in par_styles:
                        if isinstance(ps, dict):
                            name = ps.get("name") or ps.get("styleId")
                            if isinstance(name, str):
                                out.append(
                                    ParagraphStyle(
                                        name=name,
                                        style_type=WD_STYLE_TYPE.PARAGRAPH,
                                        session=self._session,
                                    ),
                                )
        if not out:
            # Fallback to builtin list.
            for name in _BUILTIN_PARAGRAPH_STYLES:
                out.append(
                    ParagraphStyle(
                        name=name,
                        style_type=WD_STYLE_TYPE.PARAGRAPH,
                        session=self._session,
                    ),
                )
            for name in _BUILTIN_CHARACTER_STYLES:
                out.append(
                    CharacterStyle(
                        name=name,
                        style_type=WD_STYLE_TYPE.CHARACTER,
                        session=self._session,
                    ),
                )
            for name in _BUILTIN_TABLE_STYLES:
                out.append(
                    TableStyle(
                        name=name,
                        style_type=WD_STYLE_TYPE.TABLE,
                        session=self._session,
                    ),
                )
        out.extend(self._added.values())
        return out

    def __iter__(self):
        return iter(self._all())

    def __len__(self) -> int:
        return len(self._all())

    def __contains__(self, name: object) -> bool:
        if not isinstance(name, str):
            return False
        return any(s.name == name for s in self._all())

    def __getitem__(self, key: str) -> BaseStyle:
        for s in self._all():
            if s.name == key or s.style_id == key:
                return s
        raise KeyError(f"Style {key!r} not found")

    def get_by_id(
        self,
        style_id: str | None,
        style_type: "WD_STYLE_TYPE",
    ) -> BaseStyle | None:
        """Look up a style by its style id (not display name).

        Mirrors python-docx 1.x ``Styles.get_by_id``. Returns ``None`` if
        ``style_id`` is None or if no style matches both the id and the
        type. (python-docx returns the default for the type when given
        None; we follow that contract via :meth:`default`.)
        """
        if style_id is None:
            return self.default(style_type)
        for s in self._all():
            if s.style_id == style_id and s.type == style_type:
                return s
        return None

    def get_style_id(
        self,
        style_or_name: object,
        style_type: "WD_STYLE_TYPE",
    ) -> str | None:
        """Resolve a style instance or display name to its style id.

        Mirrors python-docx 1.x ``Styles.get_style_id``. Accepts either
        a ``BaseStyle`` (returns its ``style_id``) or a string name
        (looks up by name within the matching type). Returns ``None``
        when ``style_or_name`` is None or unresolved.
        """
        if style_or_name is None:
            return None
        # Style instance: trust its own style_id, but only if the
        # type matches what the caller asked for.
        if isinstance(style_or_name, BaseStyle):
            if style_or_name.type != style_type:
                return None
            return style_or_name.style_id
        # String name: scan for a same-type style with matching name.
        if isinstance(style_or_name, str):
            for s in self._all():
                if s.type == style_type and s.name == style_or_name:
                    return s.style_id
            return None
        return None

    def default(self, style_type: "WD_STYLE_TYPE") -> BaseStyle | None:
        """Return the default style for a style type."""
        if style_type == WD_STYLE_TYPE.PARAGRAPH:
            return ParagraphStyle(name="Normal", style_type=style_type, session=self._session)
        if style_type == WD_STYLE_TYPE.CHARACTER:
            return CharacterStyle(name="Default Paragraph Font", style_type=style_type, session=self._session)
        if style_type == WD_STYLE_TYPE.TABLE:
            return TableStyle(name="Normal Table", style_type=style_type, session=self._session)
        return None

    def add_style(
        self,
        name: str,
        style_type: "WD_STYLE_TYPE",
        builtin: bool = False,  # noqa: ARG002
    ) -> BaseStyle:
        """Track a new style. Note: Superdoc owns the real registry; this
        is an in-memory shim for parity with python-docx."""
        if style_type == WD_STYLE_TYPE.PARAGRAPH:
            s: BaseStyle = ParagraphStyle(name=name, style_type=style_type, session=self._session)
        elif style_type == WD_STYLE_TYPE.CHARACTER:
            s = CharacterStyle(name=name, style_type=style_type, session=self._session)
        elif style_type == WD_STYLE_TYPE.TABLE:
            s = TableStyle(name=name, style_type=style_type, session=self._session)
        elif style_type == WD_STYLE_TYPE.LIST:
            s = _NumberingStyle(name=name, style_type=style_type, session=self._session)
        else:
            raise ValueError(f"Unknown style_type: {style_type!r}")
        self._added[name] = s
        return s

    def delete_style(self, name: str) -> None:
        self._added.pop(name, None)

    @property
    def latent_styles(self) -> "_LatentStyles":
        """Latent style definitions — Word's "use this style if it
        appears" registry.

        Stub. SuperDoc 1.7's ``DocInfoResult.styles`` exposes only
        ``paragraphStyles[]`` (a flat usage-count list of in-use
        styles); it doesn't surface the OOXML ``<w:latentStyles>``
        block (defaults + per-style ``semiHidden`` / ``uiPriority`` /
        ``unhideWhenUsed``). Returns an empty container so iteration
        and membership checks behave (``for ls in styles.latent_styles:
        …`` is a no-op rather than an exception). See
        ``docx-studio/PYTHON_DOCX_PARITY_GAPS.md`` § *Latent styles*.
        """
        return _LatentStyles()


class _LatentStyles:
    """Empty stub for python-docx ``LatentStyles``.

    Iterable, sized, indexable, but currently always empty. SuperDoc
    1.7 doesn't surface latent-style metadata; once it does, this
    class reads from ``doc.info().styles.latentStyles`` and yields
    real ``LatentStyle`` proxies.
    """

    def __iter__(self):
        return iter(())

    def __len__(self) -> int:
        return 0

    def __getitem__(self, key: object) -> "_LatentStyles":
        raise KeyError(key)

    @property
    def default_priority(self) -> int | None:
        return None

    @property
    def default_to_locked(self) -> bool:
        return False
