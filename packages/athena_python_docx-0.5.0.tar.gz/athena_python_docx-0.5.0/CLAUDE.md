# athena-python-docx SDK — Claude Instructions

## API Parity Rule (MANDATORY)

**This SDK MUST be a 100% exact replica of the standard [python-docx](https://python-docx.readthedocs.io/) API.**

Every class, method, property, and parameter name must match python-docx exactly. The goal is that any code written for python-docx works identically with this SDK — no surprises, no differences.

### What this means in practice

- **Do NOT add new methods** that don't exist in python-docx
- **Do NOT add new properties** that don't exist in python-docx
- **Do NOT rename parameters** — use the exact same parameter names as python-docx
- **Do NOT change method signatures** — if python-docx's `add_heading()` takes `(text, level=1)`, ours must too
- **Do NOT change return types** — if python-docx's `paragraph.runs` returns `list[Run]`, ours must too

### How to verify parity

Before adding or modifying any API surface:

1. Check the [python-docx documentation](https://python-docx.readthedocs.io/)
2. Check the [python-docx source code](https://github.com/python-openxml/python-docx)
3. Confirm the method/property/parameter exists with the same name and signature
4. If it doesn't exist in python-docx, **do not add it** without explicit user approval

Run `uv run pytest tests/test_python_docx_api_parity.py -v -s` to verify parity.

### Intentionally omitted (Superdoc SDK limitations)

These standard python-docx members don't apply to a Superdoc-backed SDK:

- `Paragraph._p`, `Run._r` — XML element access (no local XML)
- `Document.part`, `Paragraph.part`, `Run.part` — package part access
- `Document.core_properties.last_modified_by` — we use Keryx attribution instead
- `Document.settings` — Word app settings (not surfaced by Superdoc)
- `InlineShape.chart` — charts (Phase 2+)
- `Comment.add_paragraph` / `Comment.add_table` /
  `Comment.iter_inner_content` / `Comment.paragraphs` /
  `Comment.tables` — SuperDoc models a comment as a single text body,
  not a `BlockItemContainer`. Use `Comment.text` instead. The
  paragraph/table-bearing surface raises `CommentsNotImplementedError`.

### Phase-3b upstream-blocked surface

These are *shipped at the surface* but partially or fully no-op at
runtime, pending SuperDoc SDK changes outside this repo. The
upstream constraints have been verified against
[SuperDoc's published docs](https://docs.superdoc.dev/document-api/reference/styles/apply)
and the bundled TypeScript types in
`node_modules/@superdoc-dev/sdk/dist/generated/client.d.ts`. See
`docx-studio/PYTHON_DOCX_PARITY_GAPS.md` § *What unblocks the
remaining work* for the exact wire-op shape needed to unblock each.

- **24 setters on `BaseStyle` / `CharacterStyle` / `ParagraphStyle`**
  (`name`, `style_id`, `hidden`, `locked`, `priority`, `quick_style`,
  `unhide_when_used`, `base_style`, `next_paragraph_style`) emit
  `PendingStyleMutationWarning` and stash on `_overrides`.
  SuperDoc 1.7's `doc.styles.apply` is constrained to
  `target.scope: "docDefaults"` — no per-style metadata variant.
  Behavior pinned by `tests/test_style_setters_contract.py` (11
  tests); when SuperDoc lands a metadata op, those tests will need
  to flip to assert real bus calls.
- **`Styles.latent_styles`** returns an empty `_LatentStyles` —
  `DocInfoResult.styles` only surfaces `paragraphStyles[]` (a flat
  usage-count list), not the OOXML `<w:latentStyles>` block.

### Intentional deviations (additions / different semantics)

These differ from stock python-docx because the SDK is asset-backed,
not file-backed. Each is documented in the relevant docstring.

- **`Document.create(name=, base_url=, api_key=, parent_folder_id=, workspace_id=)`**
  classmethod. Stock python-docx returns a blank in-memory document
  for `Document(None)`; we can't fabricate a SuperDocument asset
  client-side, so net-new asset creation is a separate factory that
  hits `POST {base_url}/docs/empty`. The constructor positional-arg
  shape (`Document(asset_id)`) is preserved for parity.

### If you need a deviation

If there is a genuine technical reason why a deviation from python-docx is necessary:

1. **Stop and ask the user** before implementing
2. Explain what the deviation is and why it's needed
3. Get explicit confirmation that the deviation is acceptable
4. Document the deviation in the "Intentionally omitted" list above

## Architecture (0.5.0+)

This is a **thin HTTP client** that mimics the sync python-docx API.

- Sync façade (matches python-docx) — `doc.save()`, `paragraph.add_run()`
- Every internal call constructs a typed `Command` dataclass
  (`docx.commands`) and ships it through a `CommandBuffer`
  (`docx._buffer`) which POSTs to docx-studio's `/docs/:id/commands`.
- HTTP transport: `requests.Session` with a Retry (3 attempts, 0.5s
  backoff, 429/502/503/504). The legacy `transport="direct"` (embedded
  Superdoc CLI + y-websocket from Python) was removed in 0.5.0; agent
  pods no longer embed Superdoc.
- Batching: queries and response-bearing creates flush eagerly (and
  drain pending pure mutations in the same batch); pure mutations
  buffer with a 100 ms idle timer. `Document.save()` and the context
  manager exit drain explicitly. `docx.flush_all()` is the Daytona
  prelude hook — flushes every live buffer in the process.
- The path-proxy in `_http_doc.py` is an internal translation layer:
  call sites that look like `await self._session.doc.create.paragraph(p)`
  resolve to `CommandBuffer.call(CreateParagraph(**p))`. Rewriting call
  sites to construct `Command` dataclasses directly is a possible
  follow-up — the wire format is typed end-to-end either way.

## Development

```bash
uv venv
uv pip install -e ".[dev]"
uv run pytest tests/ -x -q
uv run pytest tests/test_python_docx_api_parity.py -v
```
