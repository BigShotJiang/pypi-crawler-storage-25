"""Regression tests for parity round 2 — CoreProperties / Picture /
add_break degradation.

Each test pins a specific behavior so a future regression makes the
gap visible. See ``docx-studio/PYTHON_DOCX_PARITY_GAPS.md`` § 'What
unblocks the remaining work' for the wire-op shapes still pending.
"""

from __future__ import annotations

import warnings
from typing import Any

import pytest


# ---------------------------------------------------------------------------
# CoreProperties — setters now warn instead of silently no-op'ing
# ---------------------------------------------------------------------------


def test_core_properties_setters_emit_pending_warning(
    mock_session: Any,
) -> None:
    """``doc.core_properties.title = …`` (and the rest of the writable
    surface) must emit :class:`PendingCorePropertyMutationWarning` so
    callers know the value lives only in process memory — SuperDoc
    has no metadata wire op to round-trip it.

    The previous impl silently stashed in ``_cache`` and pretended to
    work, which made any code that round-tripped a Document through
    a fresh ``Document(asset_id)`` lose the value with no signal.
    """
    from docx.opc.coreprops import (
        CoreProperties,
        PendingCorePropertyMutationWarning,
    )

    cp = CoreProperties(session=mock_session)
    for prop, value in [
        ("title", "Hello"),
        ("author", "Brendon"),
        ("subject", "Subj"),
        ("keywords", "k1, k2"),
        ("comments", "note"),
        ("category", "cat"),
        ("language", "en-US"),
        ("identifier", "id-1"),
        ("version", "1.0"),
        ("content_status", "draft"),
        ("revision", 5),
    ]:
        with pytest.warns(PendingCorePropertyMutationWarning, match=prop):
            setattr(cp, prop, value)
        # In-process read still surfaces the value (best-effort).
        assert getattr(cp, prop) == value if prop != "revision" else getattr(cp, prop) == 5


def test_core_properties_last_modified_by_does_not_warn(
    mock_session: Any,
) -> None:
    """``last_modified_by`` is a documented intentional deviation
    (Keryx-owned attribution, not an upstream block) — its setter
    should *not* emit ``PendingCorePropertyMutationWarning``.
    """
    from docx.opc.coreprops import (
        CoreProperties,
        PendingCorePropertyMutationWarning,
    )

    cp = CoreProperties(session=mock_session)
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        cp.last_modified_by = "someone"
    pending = [
        w for w in captured if issubclass(w.category, PendingCorePropertyMutationWarning)
    ]
    assert pending == [], (
        "last_modified_by is intentional deviation, must not warn — "
        f"got {[str(w.message) for w in pending]}"
    )


# ---------------------------------------------------------------------------
# InlineShape.picture accessor + Picture.image_bytes round-trip
# ---------------------------------------------------------------------------


def test_inline_shape_exposes_picture_accessor(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``InlineShape.picture`` must return a :class:`Picture` proxy —
    previously this property was missing entirely and code reaching
    for ``shape.picture.image_bytes`` raised ``AttributeError``."""
    from docx.shape import InlineShape, Picture

    shape = InlineShape(session=mock_session, info={"nodeId": "img-1"})
    pic = shape.picture
    assert isinstance(pic, Picture)


def test_picture_image_bytes_decodes_data_uri(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Picture.image_bytes must decode a ``data:image/png;base64,…`` src
    into raw bytes — the prior implementation hardcoded ``b""`` so the
    accessor always lied. Tests the full ``images.get`` round-trip
    through the path-proxy."""
    import base64

    from docx.shape import InlineShape

    payload = b"\x89PNG\r\n\x1a\nfake-bytes"
    b64 = base64.b64encode(payload).decode("ascii")
    fake_sd_methods.scripted_returns["images.get"] = {
        "src": f"data:image/png;base64,{b64}",
        "name": "logo.png",
    }
    shape = InlineShape(session=mock_session, info={"nodeId": "img-1"})
    assert shape.picture.image_bytes == payload
    assert shape.picture.content_type == "image/png"
    assert shape.picture.filename == "logo.png"


def test_picture_external_url_returns_empty_bytes_with_content_type(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """When the image source is an external URL (not a data URI), the
    SDK is HTTP-only and doesn't fetch external bytes. ``image_bytes``
    returns ``b""`` but ``content_type`` may still be reported when
    SuperDoc returns it explicitly — this disambiguates 'no image'
    from 'image not inlined'."""
    from docx.shape import InlineShape

    fake_sd_methods.scripted_returns["images.get"] = {
        "url": "https://cdn.example.com/foo.jpg",
        "contentType": "image/jpeg",
    }
    shape = InlineShape(session=mock_session, info={"nodeId": "img-2"})
    assert shape.picture.image_bytes == b""
    assert shape.picture.content_type == "image/jpeg"


# ---------------------------------------------------------------------------
# Run.add_break — column / line-clear breaks now warn instead of silently
# coercing to a line break
# ---------------------------------------------------------------------------


def test_add_break_column_warns_about_degradation(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``Run.add_break(WD_BREAK.COLUMN)`` previously fell through to
    ``insertLineBreak`` with no signal — that's a silent fidelity
    loss. Now it emits :class:`PendingBreakDegradationWarning` so
    callers know to track the gap in
    ``PYTHON_DOCX_PARITY_GAPS.md``."""
    from docx.enum.text import WD_BREAK
    from docx.text.run import PendingBreakDegradationWarning, Run

    run = Run.__new__(Run)
    run._session = mock_session
    run._block_id = "p-1"
    run._range = (0, 5)

    with pytest.warns(PendingBreakDegradationWarning, match="COLUMN"):
        run.add_break(WD_BREAK.COLUMN)

    # Still emits a real line-break op so the document model stays valid.
    ops = [c[0] for c in fake_sd_methods.calls]
    assert "insert_line_break" in ops


def test_add_break_section_continuous_routes_to_section_break(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``WD_BREAK.SECTION_CONTINUOUS`` / ``SECTION_EVEN_PAGE`` /
    ``SECTION_ODD_PAGE`` route through ``create.section_break`` with
    the correct ``breakType`` — previously they all fell through to
    ``insertLineBreak`` (silent corruption).
    """
    from docx.enum.text import WD_BREAK
    from docx.text.run import Run

    cases: list[tuple[WD_BREAK, str]] = [
        (WD_BREAK.SECTION_CONTINUOUS, "continuous"),
        (WD_BREAK.SECTION_EVEN_PAGE, "evenPage"),
        (WD_BREAK.SECTION_ODD_PAGE, "oddPage"),
        (WD_BREAK.SECTION_NEXT_PAGE, "nextPage"),
        (WD_BREAK.PAGE, "nextPage"),  # Existing PAGE handling unchanged.
    ]
    for break_type, expected_wire in cases:
        fake_sd_methods.calls.clear()
        run = Run.__new__(Run)
        run._session = mock_session
        run._block_id = "p-1"
        run._range = (0, 0)

        run.add_break(break_type)

        section_calls = [
            c for c in fake_sd_methods.calls if c[0] == "create.section_break"
        ]
        assert section_calls, f"{break_type.name} must route to create.section_break"
        params = section_calls[0][1] or {}
        assert params.get("breakType") == expected_wire, (
            f"{break_type.name} must send breakType={expected_wire!r}, "
            f"got {params.get('breakType')!r}"
        )


def test_add_break_line_unchanged(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``WD_BREAK.LINE`` (default) and ``WD_BREAK.TEXT_WRAPPING`` both
    route to ``insertLineBreak`` without warning — Word treats
    text-wrapping as a line break."""
    from docx.enum.text import WD_BREAK
    from docx.text.run import PendingBreakDegradationWarning, Run

    for bt in (WD_BREAK.LINE, WD_BREAK.TEXT_WRAPPING):
        fake_sd_methods.calls.clear()
        run = Run.__new__(Run)
        run._session = mock_session
        run._block_id = "p-1"
        run._range = (0, 5)

        with warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter("always")
            run.add_break(bt)

        line_calls = [c for c in fake_sd_methods.calls if c[0] == "insert_line_break"]
        assert line_calls, f"{bt.name} must route to insert_line_break"
        degradations = [
            w for w in captured if issubclass(w.category, PendingBreakDegradationWarning)
        ]
        assert degradations == [], (
            f"{bt.name} is a real line-break, must not emit "
            f"PendingBreakDegradationWarning"
        )


# ---------------------------------------------------------------------------
# Path-proxy registration for the new image ops
# ---------------------------------------------------------------------------


def test_run_clears_inline_marks_via_null_when_set_to_none(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """python-docx semantics: ``font.bold = None`` (and family) clears
    the explicit mark. The earlier impl silently no-op'd. After Round
    1 fix every None-setter passes ``null`` through on the wire."""
    from docx.text.run import Run

    cases: list[tuple[str, str]] = [
        ("bold", "bold"),
        ("italic", "italic"),
        ("strike", "strike"),
        ("all_caps", "caps"),
        ("name", "fontFamily"),
    ]
    for python_attr, wire_key in cases:
        fake_sd_methods.calls.clear()
        run = Run(session=mock_session, block_id="p-1", range_=(0, 5))
        if python_attr in ("bold", "italic"):
            setattr(run, python_attr, None)
        else:
            setattr(run.font, python_attr, None)
        ops = [c for c in fake_sd_methods.calls if c[0] == "format.apply"]
        assert ops, (
            f"font.{python_attr} = None must emit format.apply, not "
            "silently no-op"
        )
        _, params = ops[0]
        assert params["inline"][wire_key] is None, (
            f"font.{python_attr} = None must send {wire_key}: null, "
            f"got {params['inline'].get(wire_key)!r}"
        )


def test_run_color_rgb_none_clears(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``run.font.color.rgb = None`` should emit format.apply with
    color: null, matching python-docx's clear-on-None semantics."""
    from docx.text.run import Run

    run = Run(session=mock_session, block_id="p-1", range_=(0, 5))
    run.font.color.rgb = None
    ops = [c for c in fake_sd_methods.calls if c[0] == "format.apply"]
    assert ops
    _, params = ops[0]
    assert params["inline"]["color"] is None


def test_paragraph_text_renders_tab_and_linebreak_inlines(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``paragraph.text`` must render tab inlines as ``\\t`` and
    lineBreak inlines as ``\\n``, matching python-docx 1.2.0. Earlier
    impl silently dropped both — so a paragraph with tabs returned
    a string that didn't match python-docx's output for the same
    source."""
    from docx.text.paragraph import Paragraph

    fake_sd_methods.scripted_returns["get_node_by_id"] = {
        "node": {
            "paragraph": {
                "inlines": [
                    {"run": {"text": "hello"}},
                    {"type": "tab"},
                    {"run": {"text": "world"}},
                    {"type": "lineBreak"},
                    {"run": {"text": "!"}},
                ],
            },
        },
    }
    para = Paragraph(session=mock_session, node_id="p-1", node_type="paragraph")
    assert para.text == "hello\tworld\n!"


def test_paragraph_runs_offsets_count_tab_and_linebreak(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``Paragraph.runs`` must advance offset by 1 for each tab /
    lineBreak inline so the resulting Run ranges align with
    SuperDoc's text-address space (``insert_tab({offset})`` and
    friends count tabs/breaks too)."""
    from docx.text.paragraph import Paragraph
    from docx.text.run import Run

    fake_sd_methods.scripted_returns["get_node_by_id"] = {
        "node": {
            "paragraph": {
                "inlines": [
                    {"run": {"text": "hello"}},
                    {"type": "tab"},
                    {"run": {"text": "world"}},
                ],
            },
        },
    }
    para = Paragraph(session=mock_session, node_id="p-1", node_type="paragraph")
    runs = list(para.runs)
    assert len(runs) == 2
    r0, r1 = runs
    assert isinstance(r0, Run) and isinstance(r1, Run)
    # First run: "hello" at [0, 5)
    assert r0._range == (0, 5)
    # Second run: "world" — must start at 6 (skips tab at index 5),
    # not 5 (would overlap the tab).
    assert r1._range == (6, 11), (
        f"second run range was {r1._range}, expected (6, 11) — "
        "Paragraph.runs must count tab inlines toward offset"
    )


def test_cell_merge_returns_top_left_when_self_is_bottom_right(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``_Cell.merge`` previously returned ``self`` regardless of
    which corner the caller started from. python-docx returns the
    top-left of the merged region — addressable consistently. Pin
    the corrected behavior so a future regression doesn't silently
    return the bottom-right cell when called as
    ``bottom_right.merge(top_left)``."""
    from docx.table import Table, _Cell

    table = Table(session=mock_session, node_id="t-1")
    fake_sd_methods.scripted_returns["tables.get"] = {
        "rows": 3,
        "cols": 3,
        "styleId": "TableGrid",
    }

    bottom_right = _Cell(table=table, row=2, col=2)
    top_left = _Cell(table=table, row=0, col=0)
    result = bottom_right.merge(top_left)
    assert (result._row, result._col) == (0, 0), (
        f"merge from bottom-right must return top-left cell; got "
        f"({result._row}, {result._col})"
    )
    # And the wire payload must have a normalized rectangle.
    merge_calls = [c for c in fake_sd_methods.calls if c[0] == "tables.merge_cells"]
    assert merge_calls
    _, params = merge_calls[0]
    assert params["start"] == {"rowIndex": 0, "columnIndex": 0}
    assert params["end"] == {"rowIndex": 2, "columnIndex": 2}


def test_add_run_segments_tabs_and_newlines_into_inlines(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``Paragraph.add_run("hello\\tworld\\nfoo")`` must split the
    text into a sequence of insert + insert_tab + insert + insert_line_break
    + insert ops — matching python-docx's contract that tabs and
    newlines become real inline elements rather than literal chars.
    """
    from docx.text.paragraph import Paragraph

    fake_sd_methods.scripted_returns["get_node_by_id"] = {
        "node": {"paragraph": {"inlines": []}},
    }
    para = Paragraph(session=mock_session, node_id="p-1", node_type="paragraph")
    para.add_run("hello\tworld\nfoo")

    op_sequence = [c[0] for c in fake_sd_methods.calls if c[0] in (
        "insert", "insert_tab", "insert_line_break"
    )]
    assert op_sequence == [
        "insert",
        "insert_tab",
        "insert",
        "insert_line_break",
        "insert",
    ], (
        f"add_run('hello\\tworld\\nfoo') must emit "
        "insert+insert_tab+insert+insert_line_break+insert; got "
        f"{op_sequence}"
    )


def test_image_sniff_content_type_detects_png_jpeg_gif_webp() -> None:
    """``sniff_content_type`` must return the correct MIME for each
    of the four formats SuperDoc accepts inline. Magic-byte sniff
    beats extension when the two disagree (common with screen-capture
    PNGs that are actually JPEGs, etc.)."""
    from docx._image_utils import sniff_content_type

    cases: list[tuple[bytes, str]] = [
        (b"\x89PNG\r\n\x1a\n" + b"\x00" * 16, "image/png"),
        (b"\xff\xd8\xff\xe0" + b"\x00" * 16, "image/jpeg"),
        (b"GIF89a" + b"\x00" * 16, "image/gif"),
        (b"GIF87a" + b"\x00" * 16, "image/gif"),
        (b"RIFF" + b"\x00\x00\x00\x00" + b"WEBP" + b"\x00" * 16, "image/webp"),
    ]
    for payload, expected in cases:
        assert sniff_content_type(payload) == expected, (
            f"Expected {expected} for {payload[:8]!r}"
        )


def test_image_sniff_prefers_magic_bytes_over_extension() -> None:
    """A file ending in .png whose bytes are a JPEG must be reported
    as ``image/jpeg`` — magic bytes are the source of truth.
    Mistyped extensions are common from OS screen-capture flows
    (Mac's screencapture saves to .png by default but produces
    JPEG bytes when user edits in Preview and copies)."""
    from docx._image_utils import sniff_content_type

    jpeg_bytes = b"\xff\xd8\xff\xe0" + b"\x00" * 16
    assert (
        sniff_content_type(jpeg_bytes, fallback_path="screenshot.png")
        == "image/jpeg"
    )


def test_image_sniff_falls_back_to_extension_on_unknown_bytes() -> None:
    """Unknown magic bytes + a known extension → extension wins."""
    from docx._image_utils import sniff_content_type

    unknown_bytes = b"\x00\x00\x00\x00not-a-real-image"
    assert sniff_content_type(unknown_bytes, fallback_path="x.jpg") == "image/jpeg"
    assert sniff_content_type(unknown_bytes, fallback_path="x.gif") == "image/gif"
    assert sniff_content_type(unknown_bytes, fallback_path="x.webp") == "image/webp"


def test_image_sniff_default_is_png_when_everything_unknown() -> None:
    """Backward-compat: when neither magic bytes nor extension match,
    default to ``image/png``. Matches the prior silent-default so
    callers that previously relied on it keep working."""
    from docx._image_utils import sniff_content_type

    assert sniff_content_type(b"unknown bytes here") == "image/png"
    assert sniff_content_type(b"unknown", fallback_path="weird.bmp") == "image/png"


def test_set_section_link_to_previous_sends_correct_wire_shape(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``Section.{first_page_header,even_page_footer,…}.is_linked_to_previous = …``
    must send SuperDoc's required {target, kind, variant, linked} shape.

    The previous code synthesised ``kind: "firstPageHeader"`` and used
    ``linkedToPrevious`` as the bool field — both rejected silently
    because the apps/api applier punts SuperDoc's strict types via
    ``AnyDoc``. This test pins the corrected wire shape so first/even-
    page link toggles are no longer silently dropped.
    """
    from docx.section import Section, _HeaderFooter

    section = Section.__new__(Section)
    section._session = mock_session
    section._address = {"kind": "section", "sectionId": "sec-7"}

    cases: list[tuple[str, bool, bool, str, str]] = [
        # (header|footer, first_page, even_page, expected_kind, expected_variant)
        ("header", False, False, "header", "default"),
        ("footer", False, False, "footer", "default"),
        ("header", True, False, "header", "first"),
        ("footer", True, False, "footer", "first"),
        ("header", False, True, "header", "even"),
        ("footer", False, True, "footer", "even"),
    ]
    for kind, first_page, even_page, expected_kind, expected_variant in cases:
        fake_sd_methods.calls.clear()
        hf = _HeaderFooter(
            section=section,
            kind=kind,
            first_page=first_page,
            even_page=even_page,
        )
        hf.is_linked_to_previous = False

        sec_calls = [
            c for c in fake_sd_methods.calls if c[0] == "sections.set_link_to_previous"
        ]
        assert sec_calls, (
            f"({kind}, first={first_page}, even={even_page}): "
            "expected sections.set_link_to_previous emission"
        )
        _, params = sec_calls[0]
        assert params["kind"] == expected_kind, (
            f"({kind}, first={first_page}, even={even_page}): kind="
            f"{params.get('kind')!r}, expected {expected_kind!r}"
        )
        assert params["variant"] == expected_variant, (
            f"({kind}, first={first_page}, even={even_page}): variant="
            f"{params.get('variant')!r}, expected {expected_variant!r}"
        )
        assert params["linked"] is False
        assert "linkedToPrevious" not in params, (
            "Old wire field name leaked back — the SuperDoc applier "
            "rejects it silently via AnyDoc punt."
        )


def test_build_command_routes_images_get_alttext_decorative() -> None:
    """``images.get`` / ``images.set_alt_text`` / ``images.set_decorative``
    must construct the right Command dataclass through ``_build_command``
    — registering an op without registering the lookup is a silent gap
    that only surfaces when a caller actually exercises the path-proxy."""
    from docx._http_doc import _build_command
    from docx.commands import (
        ImagesGet,
        SetImageAltText,
        SetImageDecorative,
    )

    g = _build_command("images.get", {"imageId": "img-1"})
    assert isinstance(g, ImagesGet)
    assert g.image_id == "img-1"

    a = _build_command(
        "images.set_alt_text", {"imageId": "img-1", "altText": "Athena logo"}
    )
    assert isinstance(a, SetImageAltText)
    assert a.alt_text == "Athena logo"

    d = _build_command(
        "images.set_decorative", {"imageId": "img-1", "decorative": True}
    )
    assert isinstance(d, SetImageDecorative)
    assert d.decorative is True
