"""Tests for the python-docx 1.x ``iter_inner_content`` API.

Locks the parity contract surfaced by tests/fidelity/parity_crawl.py:
- ``Document.iter_inner_content`` yields Paragraph | Table in doc order.
- ``Paragraph.iter_inner_content`` yields Run | Hyperlink in inline order.
- ``Run.iter_inner_content`` yields str segments (and "\\f" page-break
  markers if present).

These tests use the fake-session FakeSession to drive the SDK without
network — same harness the fidelity battery uses.
"""

from __future__ import annotations

from tests.fidelity.fake_session import install_fake_session


def test_document_iter_inner_content_yields_paragraphs_then_table() -> None:
    install_fake_session()
    from docx import Document
    from docx.table import Table
    from docx.text.paragraph import Paragraph

    doc = Document("asset_fake")
    doc.add_paragraph("Intro")
    doc.add_heading("Section A", level=1)
    doc.add_table(rows=2, cols=2)
    doc.add_paragraph("Conclusion")

    items = list(doc.iter_inner_content())
    types = [type(i).__name__ for i in items]
    assert "Table" in types
    assert types.count("Paragraph") >= 3
    # All yielded items are the correct type.
    assert all(isinstance(i, (Paragraph, Table)) for i in items)


def test_paragraph_iter_inner_content_yields_runs() -> None:
    install_fake_session()
    from docx import Document
    from docx.text.run import Run

    doc = Document("asset_fake")
    p = doc.add_paragraph("Hello ")
    p.add_run("world").bold = True
    p.add_run("!")

    items = list(p.iter_inner_content())
    # All items are runs (no hyperlinks in this case)
    assert all(isinstance(i, Run) for i in items)
    # Concatenated text equals paragraph text
    assert "".join(i.text for i in items) == p.text


def test_run_iter_inner_content_yields_text_segment() -> None:
    install_fake_session()
    from docx import Document

    doc = Document("asset_fake")
    p = doc.add_paragraph("")
    r = p.add_run("plain text")

    items = list(r.iter_inner_content())
    assert items == ["plain text"]


def test_run_iter_inner_content_empty_run_yields_nothing() -> None:
    install_fake_session()
    from docx import Document

    doc = Document("asset_fake")
    p = doc.add_paragraph("")
    r = p.add_run("")

    assert list(r.iter_inner_content()) == []
