"""Phase C: tables completeness — _Cell.grid_span / iter_inner_content,
_Row.grid_cols_after / grid_cols_before, _Cell.add_table /
_Cell.merge signature parity.
"""

from __future__ import annotations

from typing import Any


def _make_table(mock_session: Any, *, node_id: str = "tbl-1"):
    from docx.table import Table

    return Table(session=mock_session, node_id=node_id)


def _scripted_get(rows: int, cols: int, *, row_info=None, cells=None):
    """Build a scripted ``tables.get`` payload with optional rowInfo
    and per-cell metadata."""
    out = {"rows": rows, "cols": cols, "styleId": "TableGrid"}
    if row_info is not None:
        out["rowInfo"] = row_info
    if cells is not None:
        out["cells"] = cells
    return out


def test_cell_grid_span_default_is_one(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """A normal cell has grid_span == 1."""
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(2, 2)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-1", "text": "x"}],
    }
    table = _make_table(mock_session)
    cell = table.cell(0, 0)
    assert cell.grid_span == 1


def test_cell_grid_span_reflects_horizontal_merge(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """A horizontally-merged cell reports its span via the cell info
    ``gridSpan`` field."""
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(2, 4)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-merge", "text": "merged", "gridSpan": 3}],
    }
    table = _make_table(mock_session)
    cell = table.cell(0, 0)
    assert cell.grid_span == 3


def test_cell_grid_span_minimum_is_one(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Defensively floor at 1 even if SuperDoc returns 0."""
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(1, 1)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-1", "gridSpan": 0}],
    }
    table = _make_table(mock_session)
    assert table.cell(0, 0).grid_span == 1


def test_cell_iter_inner_content_yields_paragraphs(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``_Cell.iter_inner_content`` yields a Paragraph for each
    paragraph nodeId discovered inside the cell via ``getNodeById``."""
    from docx.text.paragraph import Paragraph

    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(1, 1)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-1", "text": "hi"}],
    }
    # The _Cell paragraph-id walker calls getNodeById on the cell and
    # walks the response for paragraph nodes. This shape matches the
    # block-list flat-address branch in `_collect_paragraph_ids`.
    fake_sd_methods.scripted_returns["get_node_by_id"] = {
        "node": {
            "tableCell": {
                "blocks": [
                    {"nodeType": "paragraph", "nodeId": "p-cell-0"},
                    {"nodeType": "paragraph", "nodeId": "p-cell-1"},
                ],
            },
        },
    }
    table = _make_table(mock_session)
    cell = table.cell(0, 0)
    items = list(cell.iter_inner_content())
    assert len(items) == 2
    assert all(isinstance(p, Paragraph) for p in items)


def test_row_grid_cols_before_and_after(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Row 0 has gridBefore=2, gridAfter=1 → grid_cols_before/after
    reflect those values."""
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(
        2, 4, row_info=[{"gridBefore": 2, "gridAfter": 1}, {}]
    )
    table = _make_table(mock_session)
    row0 = table.rows[0]
    row1 = table.rows[1]
    assert row0.grid_cols_before == 2
    assert row0.grid_cols_after == 1
    # row1 has no entries — defaults to 0.
    assert row1.grid_cols_before == 0
    assert row1.grid_cols_after == 0


def test_cell_add_table_signature_no_width(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """_Cell.add_table(rows, cols) — no width parameter, matching
    upstream. Calling with positional or keyword works."""
    import inspect

    from docx.table import _Cell

    sig = inspect.signature(_Cell.add_table)
    params = [p.name for p in sig.parameters.values() if p.name != "self"]
    assert params == ["rows", "cols"]


def test_cell_merge_uses_other_cell_param_name() -> None:
    """``_Cell.merge(other_cell)`` — keyword arg parity with upstream."""
    import inspect

    from docx.table import _Cell

    sig = inspect.signature(_Cell.merge)
    params = [p.name for p in sig.parameters.values() if p.name != "self"]
    assert params == ["other_cell"]
