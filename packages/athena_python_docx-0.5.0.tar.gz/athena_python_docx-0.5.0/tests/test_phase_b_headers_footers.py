"""Phase B: Headers & Footers parity.

Pins the surface and wire behavior of the header/footer block
container. SuperDoc 1.8.1 exposes ``doc.headerFooters.{list, get,
resolve, refs.set, refs.clear, refs.setLinkedToPrevious, parts.*}``
plus an ``in: {storyType: "headerFooterSlot", …}`` parameter on
``doc.create.{paragraph, heading, table}``. This SDK ships:

  * ``Section.{header, footer, first_page_header, first_page_footer,
    even_page_header, even_page_footer}`` — return ``_HeaderFooter``
    proxies aliased as ``_Header`` / ``_Footer`` for upstream parity.
  * ``_Header.add_paragraph(text, style)`` and ``add_table(rows, cols,
    width)`` route through ``create.{paragraph, table}`` with the
    correct ``in`` story locator.
  * ``_Header.is_linked_to_previous`` (read/write).
  * ``_Header.paragraphs`` / ``tables`` / ``iter_inner_content`` —
    read-side returns empty (SuperDoc 1.8 lacks per-story block
    listing); see PYTHON_DOCX_PARITY_GAPS.md.
"""

from __future__ import annotations

from typing import Any


def _find_call(calls: list[tuple[str, Any]], op_name: str) -> tuple[str, Any] | None:
    for call in calls:
        if call[0] == op_name:
            return call
    return None


def _make_section(mock_session: Any, *, section_id: str = "sec-1"):
    from docx.section import Section

    return Section(session=mock_session, address={"kind": "section", "sectionId": section_id})


def test_section_header_returns_header_alias(mock_session: Any) -> None:
    """``Section.header`` returns a ``_Header`` (upstream parity name)."""
    from docx.section import _Header, _Footer

    section = _make_section(mock_session)
    h = section.header
    f = section.footer
    assert isinstance(h, _Header)
    assert isinstance(f, _Footer)


def test_section_first_and_even_variants_return_header_alias(
    mock_session: Any,
) -> None:
    from docx.section import _Header, _Footer

    section = _make_section(mock_session)
    assert isinstance(section.first_page_header, _Header)
    assert isinstance(section.first_page_footer, _Footer)
    assert isinstance(section.even_page_header, _Header)
    assert isinstance(section.even_page_footer, _Footer)


def test_header_add_paragraph_targets_header_footer_slot(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """add_paragraph routes through create.paragraph with the right
    ``in: {storyType: "headerFooterSlot", section, headerFooterKind,
    variant}`` locator."""
    fake_sd_methods.scripted_returns["create.paragraph"] = {
        "success": True,
        "paragraph": {"nodeId": "p-hdr-1"},
    }
    section = _make_section(mock_session, section_id="sec-42")
    header = section.header
    header.add_paragraph("Page header text")

    call = _find_call(fake_sd_methods.calls, "create.paragraph")
    assert call is not None
    _, params = call
    assert params["text"] == "Page header text"
    assert params["in"] == {
        "kind": "story",
        "storyType": "headerFooterSlot",
        "section": {"kind": "section", "sectionId": "sec-42"},
        "headerFooterKind": "header",
        "variant": "default",
    }


def test_first_page_footer_uses_first_variant(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    fake_sd_methods.scripted_returns["create.paragraph"] = {
        "success": True,
        "paragraph": {"nodeId": "p-1"},
    }
    section = _make_section(mock_session, section_id="sec-7")
    footer = section.first_page_footer
    footer.add_paragraph("First page footer")

    call = _find_call(fake_sd_methods.calls, "create.paragraph")
    assert call is not None
    _, params = call
    assert params["in"]["headerFooterKind"] == "footer"
    assert params["in"]["variant"] == "first"


def test_even_page_header_uses_even_variant(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    fake_sd_methods.scripted_returns["create.paragraph"] = {
        "success": True,
        "paragraph": {"nodeId": "p-1"},
    }
    section = _make_section(mock_session, section_id="sec-3")
    header = section.even_page_header
    header.add_paragraph("Even page header")

    call = _find_call(fake_sd_methods.calls, "create.paragraph")
    _, params = call  # type: ignore[misc]
    assert params["in"]["variant"] == "even"
    assert params["in"]["headerFooterKind"] == "header"


def test_header_add_table_targets_slot(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """add_table threads the same ``in`` story locator through
    ``create.table``."""
    from docx.shared import Inches

    fake_sd_methods.scripted_returns["create.table"] = {
        "success": True,
        "table": {"nodeId": "t-1"},
    }
    section = _make_section(mock_session, section_id="sec-9")
    header = section.header
    header.add_table(2, 3, Inches(4))

    call = _find_call(fake_sd_methods.calls, "create.table")
    assert call is not None
    _, params = call
    assert params["rows"] == 2 and params["columns"] == 3
    assert params["in"]["storyType"] == "headerFooterSlot"
    assert params["in"]["headerFooterKind"] == "header"


def test_header_paragraphs_and_tables_empty_until_supplied(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """SuperDoc 1.8 has no per-story block listing — reads return [].
    Must not raise on iteration; ``len()`` works."""
    section = _make_section(mock_session)
    header = section.header
    assert header.paragraphs == []
    assert header.tables == []
    assert list(header.iter_inner_content()) == []


def test_header_is_linked_to_previous_setter_calls_set_link_to_previous(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Setting ``is_linked_to_previous`` on a header sends both the
    sections set_link_to_previous op (athena-canonical) AND the
    SuperDoc headerFooters refs.setLinkedToPrevious op."""
    section = _make_section(mock_session, section_id="sec-12")
    header = section.header
    header.is_linked_to_previous = False

    sec_call = _find_call(
        fake_sd_methods.calls, "sections.set_link_to_previous"
    )
    assert sec_call is not None
    _, sp = sec_call
    # SuperDoc's wire is `linked: bool` + `kind: header|footer` +
    # `variant: default|first|even`. Earlier athena code used
    # `linkedToPrevious` and a mangled `kind: firstPageHeader` — both
    # silently rejected by SuperDoc since the applier punts SuperDoc's
    # strict types via `AnyDoc`. Pin the corrected shape so the next
    # regression makes the bug visible.
    assert sp["linked"] is False
    assert sp["kind"] == "header"
    assert sp["variant"] == "default"

    # Also the SuperDoc-side mirror.
    hf_call = _find_call(
        fake_sd_methods.calls,
        "header_footers.refs.set_linked_to_previous",
    )
    assert hf_call is not None
    _, hp = hf_call
    assert hp["linked"] is False
    assert hp["target"]["headerFooterKind"] == "header"
    assert hp["target"]["variant"] == "default"
