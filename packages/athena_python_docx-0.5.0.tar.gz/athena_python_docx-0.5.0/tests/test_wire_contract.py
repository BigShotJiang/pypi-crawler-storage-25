"""Wire-contract test — every registered op round-trips end-to-end.

This is the CI-side regression net for the class of bug that bit us
on PR #19766: the path-proxy looks up the right ``Command`` dataclass,
but a field rename (``in`` → ``in_``) was missing in
``_FIELD_RENAMES`` and the dataclass ctor raised ``TypeError`` only
when *real* SuperDoc-shaped payloads hit the path-proxy in
production. Unit tests with FakeSession bypass ``_build_command``
entirely, so the bug stayed invisible.

This test exercises the full ``op-name → Command dataclass →
to_dict() → wire JSON`` pipeline for *every* op in
``_OP_TO_COMMAND`` and pins:

1.  ``_build_command(op_name, fixture)`` constructs the right
    ``Command`` subclass without raising.
2.  ``cmd.to_dict()`` produces the expected ``type`` discriminator
    (PascalCase class name) and the expected camelCase wire fields.
3.  Field renames (``in`` → ``in_``, ``type`` → ``node_type`` /
    ``value_type``) round-trip cleanly through both directions of
    the path-proxy.

The fixture dict at the top of this file is the contract. Adding a
new op without adding a fixture entry FAILS the test — that's the
forcing function. Every entry must use realistic, SuperDoc-shaped
payloads (NOT mock placeholders), so the test catches schema drift
the moment it happens.
"""

from __future__ import annotations

from typing import Any

import pytest

# Realistic, SuperDoc-shaped payloads for every registered op. These
# mirror what the SDK actually sends in production — using mock
# placeholders here would defeat the purpose of the contract test.
_WIRE_FIXTURES: dict[str, dict[str, Any]] = {
    # Block creation
    "create.paragraph": {
        "text": "hello",
        "at": {"kind": "documentEnd"},
        "in": {
            "kind": "story",
            "storyType": "headerFooterSlot",
            "section": {"kind": "section", "sectionId": "sec-1"},
            "headerFooterKind": "header",
            "variant": "default",
        },
    },
    "create.heading": {
        "text": "H",
        "level": 1,
        "at": {"kind": "documentEnd"},
        "in": {"kind": "story", "storyType": "body"},
    },
    "create.table": {
        "rows": 2,
        "columns": 3,
        "at": {"kind": "documentEnd"},
        "in": {"kind": "story", "storyType": "body"},
    },
    "create.image": {
        "src": "data:image/png;base64,iVBORw0KGgoAAAANS",
        "size": {"width": 100, "height": 50},
        "at": {"kind": "documentEnd"},
    },
    "create.section_break": {
        "at": {"kind": "documentEnd"},
        "breakType": "nextPage",
    },
    # Inline mutations
    # Real Insert callers (docx/text/run.py::add_text) send a `target`
    # selection + `value` + `type`; the `type` field is renamed to
    # `value_type` on the Python side and serialised back as
    # `valueType` on the wire (sender keeps `type` for SuperDoc; the
    # discriminator wins).
    "insert": {
        "target": {
            "kind": "selection",
            "start": {"kind": "text", "blockId": "p-1", "offset": 5},
            "end": {"kind": "text", "blockId": "p-1", "offset": 5},
        },
        "value": "abc",
        "type": "text",
    },
    "replace": {
        "target": {"kind": "text", "blockId": "p-1", "range": {"start": 0, "end": 3}},
        "text": "new",
    },
    "insert_line_break": {"blockId": "p-1", "offset": 5},
    "insert_tab": {"blockId": "p-1", "offset": 5},
    "format.apply": {
        "target": {"kind": "text", "blockId": "p-1", "range": {"start": 0, "end": 5}},
        "inline": {"bold": True},
    },
    # Real paragraph-format callers send `target: {kind: "block",
    # nodeType, nodeId}` — see docx/text/paragraph.py::_block_target.
    "format.paragraph.set_alignment": {
        "target": {"kind": "block", "nodeType": "paragraph", "nodeId": "p-1"},
        "alignment": "center",
    },
    "format.paragraph.clear_alignment": {
        "target": {"kind": "block", "nodeType": "paragraph", "nodeId": "p-1"},
    },
    "format.paragraph.set_indentation": {
        "target": {"kind": "block", "nodeType": "paragraph", "nodeId": "p-1"},
        "left": 36.0,
    },
    "format.paragraph.clear_indentation": {
        "target": {"kind": "block", "nodeType": "paragraph", "nodeId": "p-1"},
    },
    "format.paragraph.set_spacing": {
        "target": {"kind": "block", "nodeType": "paragraph", "nodeId": "p-1"},
        "before": 6.0,
    },
    "format.paragraph.clear_spacing": {
        "target": {"kind": "block", "nodeType": "paragraph", "nodeId": "p-1"},
    },
    "format.paragraph.set_keep_options": {
        "target": {"kind": "block", "nodeType": "paragraph", "nodeId": "p-1"},
        "keepNext": True,
    },
    "format.paragraph.set_flow_options": {
        "target": {"kind": "block", "nodeType": "paragraph", "nodeId": "p-1"},
        "pageBreakBefore": True,
    },
    "format.paragraph.set_tab_stop": {
        "target": {"kind": "block", "nodeType": "paragraph", "nodeId": "p-1"},
        "position": 144.0,
        "alignment": "left",
    },
    "format.paragraph.clear_all_tab_stops": {
        "target": {"kind": "block", "nodeType": "paragraph", "nodeId": "p-1"},
    },
    "styles.paragraph.set_style": {
        "target": {"kind": "block", "nodeType": "paragraph", "nodeId": "p-1"},
        "styleId": "Heading1",
    },
    # Sections
    "sections.set_page_margins": {
        "target": {"kind": "section", "sectionId": "sec-1"},
        "left": 72.0,
        "right": 72.0,
    },
    "sections.set_page_setup": {
        "target": {"kind": "section", "sectionId": "sec-1"},
        "width": 612.0,
        "height": 792.0,
    },
    "sections.set_header_footer_margins": {
        "target": {"kind": "section", "sectionId": "sec-1"},
        "header": 36.0,
    },
    "sections.set_break_type": {
        "target": {"kind": "section", "sectionId": "sec-1"},
        "breakType": "nextPage",
    },
    "sections.set_title_page": {
        "target": {"kind": "section", "sectionId": "sec-1"},
        # SuperDoc wire field is `enabled`, not `titlePage`.
        "enabled": True,
    },
    "sections.set_link_to_previous": {
        "target": {"kind": "section", "sectionId": "sec-1"},
        "kind": "header",
        "variant": "default",
        "linked": False,
    },
    # Tables (mutations) — fixtures mirror docx/table.py callers.
    "tables.insert_row": {
        "nodeId": "t-1",
        "rowIndex": 0,
        "position": "below",
        "count": 1,
    },
    "tables.insert_column": {
        "nodeId": "t-1",
        "columnIndex": 0,
        "position": "right",
        "count": 1,
    },
    "tables.merge_cells": {
        "nodeId": "t-1",
        "start": {"rowIndex": 0, "columnIndex": 0},
        "end": {"rowIndex": 1, "columnIndex": 1},
    },
    "tables.set_style": {"nodeId": "t-1", "styleId": "TableGrid"},
    # SuperDoc's wire field is `autoFitMode`, not `autoFit`. Alignment
    # and tableDirection are setLayout fields, not setTableOptions.
    "tables.set_layout": {
        "nodeId": "t-1",
        "autoFitMode": "fixedWidth",
        "alignment": "center",
        "tableDirection": "ltr",
    },
    "tables.set_table_options": {
        "nodeId": "t-1",
        "defaultCellMargins": {
            "topPt": 5.0,
            "rightPt": 5.0,
            "bottomPt": 5.0,
            "leftPt": 5.0,
        },
        "cellSpacingPt": 0.0,
    },
    # Real callers (docx/table.py::_cell_address) send a block-shaped
    # target — matches DocTablesSetCellPropertiesParams.
    "tables.set_cell_properties": {
        "target": {"kind": "block", "nodeType": "tableCell", "nodeId": "tc-1"},
        "verticalAlign": "center",
        "preferredWidthPt": 144.0,
    },
    "tables.set_column_width": {
        "nodeId": "t-1",
        "columnIndex": 0,
        "widthPt": 144.0,
    },
    "tables.set_row_height": {
        "nodeId": "t-1",
        "rowIndex": 0,
        "heightPt": 24.0,
        "rule": "atLeast",
    },
    # Images (mutations + read)
    # SuperDoc DocImagesSetSizeParams: imageId + size:{width,height,unit?}
    "images.set_size": {
        "imageId": "img-1",
        "size": {"width": 100.0, "height": 50.0, "unit": "pt"},
    },
    "images.set_alt_text": {"imageId": "img-1", "altText": "Athena logo"},
    "images.set_decorative": {"imageId": "img-1", "decorative": True},
    "images.get": {"imageId": "img-1"},
    # Queries
    "blocks.list": {"nodeTypes": ["paragraph", "heading"], "includeText": True},
    "find": {"type": "paragraph"},
    "get_node_by_id": {"id": "p-1"},
    "get_node": {"target": {"kind": "block", "nodeType": "paragraph", "nodeId": "p-1"}},
    "images.list": {},
    "info": {},
    "sections.list": {},
    "sections.get": {"target": {"kind": "section", "sectionId": "sec-1"}},
    "tables.get": {"nodeId": "t-1"},
    "tables.get_cells": {"nodeId": "t-1", "rowIndex": 0, "columnIndex": 0},
    "tables.get_properties": {"nodeId": "t-1"},
    "markdown_to_fragment": {"markdown": "# H"},
    # Comments
    "comments.create": {
        "text": "anchored comment",
        "target": {
            "kind": "text",
            "blockId": "p-1",
            "range": {"start": 0, "end": 5},
        },
    },
    # SuperDoc's wire field for comment id is `id:`, NOT `commentId:` —
    # `docx/comments.py` and `docx/text/run.py` correctly send `id`.
    "comments.patch": {"id": "c-1", "text": "edit"},
    "comments.delete": {"id": "c-1"},
    "comments.get": {"id": "c-1"},
    "comments.list": {},
    # Headers & Footers
    "header_footers.list": {},
    "header_footers.get": {
        "target": {
            # SuperDoc + Zod both expect `headerFooterSlot`, not `headerFooter`.
            "kind": "headerFooterSlot",
            "section": {"kind": "section", "sectionId": "sec-1"},
            "headerFooterKind": "header",
            "variant": "default",
        },
    },
    "header_footers.resolve": {
        "target": {
            "kind": "headerFooterSlot",
            "section": {"kind": "section", "sectionId": "sec-1"},
            "headerFooterKind": "header",
            "variant": "default",
        },
    },
    # See docx/section.py::is_linked_to_previous setter — wire shape is
    # `target: <slot>, linked: bool`.
    "header_footers.refs.set_linked_to_previous": {
        "target": {
            "kind": "headerFooterSlot",
            "section": {"kind": "section", "sectionId": "sec-1"},
            "headerFooterKind": "header",
            "variant": "default",
        },
        "linked": True,
    },
    # Lists & Selection (typed-bus extras — no python-docx parity surface)
    "lists.merge": {
        "target": {"kind": "block", "nodeType": "listItem", "nodeId": "li-1"},
        "direction": "next",
    },
    "lists.split": {
        "target": {"kind": "block", "nodeType": "listItem", "nodeId": "li-1"},
        "restartNumbering": True,
    },
    "selection.current": {},
}


# ---------------------------------------------------------------------------
# Coverage assertion: every registered op must have a fixture
# ---------------------------------------------------------------------------


def test_every_registered_op_has_a_wire_fixture() -> None:
    """The fixture map MUST cover every op in ``_OP_TO_COMMAND``.

    Adding a new op without adding a fixture entry fails this test —
    that's the forcing function that keeps the wire-contract surface
    in lockstep with the registry.
    """
    from docx._http_doc import _OP_TO_COMMAND

    registered = set(_OP_TO_COMMAND.keys())
    fixtured = set(_WIRE_FIXTURES.keys())

    missing = registered - fixtured
    extra = fixtured - registered

    assert not missing, (
        "These ops are registered in _OP_TO_COMMAND but have no wire "
        f"fixture in test_wire_contract.py: {sorted(missing)}. Add a "
        "realistic fixture entry — tests with mock placeholders defeat "
        "the contract."
    )
    assert not extra, (
        "These ops are in the fixture map but no longer registered "
        f"in _OP_TO_COMMAND: {sorted(extra)}. Either re-register or "
        "remove the stale fixture."
    )


# ---------------------------------------------------------------------------
# End-to-end round-trip: op-name + params → Command → wire JSON
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("op_name", sorted(_WIRE_FIXTURES.keys()))
def test_op_round_trips_through_path_proxy_and_wire(op_name: str) -> None:
    """For each op:
    1. ``_build_command(op_name, fixture)`` constructs the right Command
       subclass without raising — catches missing ``_OP_TO_COMMAND``
       entries, broken ``_FIELD_RENAMES``, and dataclass-init errors.
    2. ``cmd.to_dict()`` produces a wire dict with a ``type`` key
       whose value matches the Command class's PascalCase name.
    3. Reserved-keyword renames round-trip both ways: ``in`` →
       ``in_`` on the Python side, ``in_`` → ``in`` on the wire.
    """
    from docx._http_doc import _OP_TO_COMMAND, _build_command

    expected_cls = _OP_TO_COMMAND[op_name]
    fixture = _WIRE_FIXTURES[op_name]

    cmd = _build_command(op_name, fixture)

    assert isinstance(cmd, expected_cls), (
        f"_build_command({op_name!r}, …) returned {type(cmd).__name__}, "
        f"expected {expected_cls.__name__}"
    )

    wire = cmd.to_dict()
    assert wire["type"] == expected_cls.__name__, (
        f"{op_name}: wire 'type' is {wire['type']!r}, must be PascalCase "
        f"class name {expected_cls.__name__!r} so the Zod discriminator "
        "matches in apps/api/src/commands/types.ts."
    )

    # Reserved-keyword fields must round-trip. If the input fixture
    # passed an `in:` / `type:` key, the Python dataclass field has
    # the suffixed name (`in_`/`node_type`) but the wire dict must
    # serialize back to the canonical SuperDoc name.
    if "in" in fixture:
        assert "in" in wire and "in_" not in wire, (
            f"{op_name}: `in` field must serialise back to wire `in`, "
            f"not `in_`. Got wire keys: {sorted(wire.keys())}"
        )
    if op_name == "find" and "type" in fixture:
        # `find` renames `type` → `node_type` on the Python side; on the
        # wire the discriminator overwrites the user `type` so we just
        # verify nodeType made it into the dataclass and discriminator
        # is the class name.
        assert wire["type"] == "Find"
    if op_name == "insert" and "type" in fixture:
        # `insert` renames `type` → `value_type`. On the wire it should
        # serialise as `valueType`; the discriminator is `Insert`.
        assert wire["type"] == "Insert"
        assert "valueType" in wire, (
            f"insert: expected `valueType` on wire, got keys {sorted(wire.keys())}"
        )


# ---------------------------------------------------------------------------
# camelCase contract — Python snake_case keys must translate cleanly
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("op_name", sorted(_WIRE_FIXTURES.keys()))
def test_wire_keys_are_camel_case_or_known_exception(op_name: str) -> None:
    """Every wire key must be camelCase (or the discriminator ``type``).

    The only acceptable underscores in a wire key are inside the
    ``type`` discriminator (which is PascalCase, no underscores
    anyway). A snake_case wire key means ``_snake_to_camel`` failed
    to convert a dataclass field name — typically because a field
    was added without thinking about the wire side. Catch it here.
    """
    from docx._http_doc import _build_command

    cmd = _build_command(op_name, _WIRE_FIXTURES[op_name])
    wire = cmd.to_dict()

    for key in wire.keys():
        if key == "type":
            continue
        assert "_" not in key, (
            f"{op_name}: wire key {key!r} contains an underscore — "
            "that means a dataclass field name didn't get camelCase'd "
            "by _snake_to_camel. Either fix the field name or the "
            "transform. Full wire dict keys: " + repr(sorted(wire.keys()))
        )
