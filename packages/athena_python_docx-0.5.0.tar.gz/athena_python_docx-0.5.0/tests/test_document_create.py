"""Tests for Document.create() — the net-new SuperDocument factory.

The HTTP layer is the only thing exercised here; the resulting Document
is *not* opened (open() would require a live Keryx WebSocket). That's
fine for a unit test — Session.open() is covered by the smoke
integration test which actually talks to Keryx.
"""

from __future__ import annotations

import io
import json
from typing import Any
from unittest.mock import patch

import pytest

from docx import Document
from docx.errors import AuthenticationError, DocxError, SessionError


_FAKE_RESPONSE: dict[str, Any] = {
    "assetId": "asset_aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
    "name": "Untitled Word Document",
    "workspaceId": "ws_11111111-2222-3333-4444-555555555555",
    "collab": {
        "token": "fake.jwt.signature",
        "wsUrl": "wss://keryx.stg.athenaintel.com",
        "workspaceId": "ws_11111111-2222-3333-4444-555555555555",
    },
}


class _FakeResponse:
    """urllib.request.urlopen context-manager stand-in."""

    def __init__(self, body: bytes, status: int = 201) -> None:
        self._body = body
        self.status = status

    def __enter__(self) -> "_FakeResponse":
        return self

    def __exit__(self, *args: object) -> None:
        return None

    def read(self) -> bytes:
        return self._body


def _fake_urlopen_ok(*_args: object, **_kwargs: object) -> _FakeResponse:
    return _FakeResponse(json.dumps(_FAKE_RESPONSE).encode("utf-8"))


def test_create_happy_path_http() -> None:
    """HTTP 201 → Document with the asset_id + base_url/api_key wired
    onto the Session. There's no bundle anymore (0.5.0 dropped the legacy
    direct transport); the API service mints its own JWT server-side."""
    with patch("docx._http.urllib.request.urlopen", side_effect=_fake_urlopen_ok):
        doc = Document.create(
            name="My doc",
            base_url="https://docx-studio.stg.athenaintel.com",
            api_key="bg_test_key",
        )

    assert doc._session.asset_id == _FAKE_RESPONSE["assetId"]  # noqa: SLF001
    assert doc._session._http_base_url == "https://docx-studio.stg.athenaintel.com"  # noqa: SLF001
    assert doc._session._http_api_key == "bg_test_key"  # noqa: SLF001


def test_create_missing_base_url_raises_session_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("ATHENA_DOCX_BASE_URL", raising=False)
    with pytest.raises(SessionError, match="ATHENA_DOCX_BASE_URL"):
        Document.create(name="x", api_key="bg_test_key")


def test_create_missing_api_key_raises_authentication_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("ATHENA_DOCX_API_KEY", raising=False)
    with pytest.raises(AuthenticationError, match="ATHENA_DOCX_API_KEY"):
        Document.create(name="x", base_url="https://example.com")


def test_create_401_maps_to_authentication_error() -> None:
    import urllib.error

    def _401(*_a: object, **_k: object) -> _FakeResponse:
        raise urllib.error.HTTPError(
            url="https://example.com/docs/empty",
            code=401,
            msg="Unauthorized",
            hdrs=None,  # type: ignore[arg-type]
            fp=io.BytesIO(b'{"error":"bad key"}'),
        )

    with patch("docx._http.urllib.request.urlopen", side_effect=_401):
        with pytest.raises(AuthenticationError, match="HTTP 401"):
            Document.create(
                name="x",
                base_url="https://example.com",
                api_key="bad_key",
            )


def test_create_500_maps_to_docx_error() -> None:
    import urllib.error

    def _500(*_a: object, **_k: object) -> _FakeResponse:
        raise urllib.error.HTTPError(
            url="https://example.com/docs/empty",
            code=500,
            msg="Internal Server Error",
            hdrs=None,  # type: ignore[arg-type]
            fp=io.BytesIO(b'{"error":"boom"}'),
        )

    with patch("docx._http.urllib.request.urlopen", side_effect=_500):
        with pytest.raises(DocxError, match="HTTP 500"):
            Document.create(
                name="x",
                base_url="https://example.com",
                api_key="bg_test_key",
            )


def test_create_uses_env_var_fallbacks(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Env-var fallbacks for base_url + api_key when not passed explicitly."""
    monkeypatch.setenv("ATHENA_DOCX_BASE_URL", "https://docx-studio.stg.athenaintel.com")
    monkeypatch.setenv("ATHENA_DOCX_API_KEY", "bg_env_key")
    with patch("docx._http.urllib.request.urlopen", side_effect=_fake_urlopen_ok):
        doc = Document.create(name="env-fallback")
    assert doc._session.asset_id == _FAKE_RESPONSE["assetId"]  # noqa: SLF001


def test_create_request_body_includes_optional_fields() -> None:
    """parent_folder_id and workspace_id flow through to the request body."""
    captured: dict[str, Any] = {}

    def _capture(req: Any, **_kwargs: Any) -> _FakeResponse:
        captured["url"] = req.full_url
        captured["headers"] = dict(req.headers)
        captured["body"] = json.loads(req.data.decode("utf-8"))
        return _FakeResponse(json.dumps(_FAKE_RESPONSE).encode("utf-8"))

    with patch("docx._http.urllib.request.urlopen", side_effect=_capture):
        Document.create(
            name="explicit",
            base_url="https://example.com",
            api_key="bg_test_key",
            parent_folder_id="folder_abc",
            workspace_id="ws_explicit",
        )

    assert captured["url"] == "https://example.com/docs/empty"
    assert captured["headers"]["Authorization"] == "Bearer bg_test_key"
    assert captured["body"] == {
        "name": "explicit",
        "parentFolderId": "folder_abc",
        "workspaceId": "ws_explicit",
    }
