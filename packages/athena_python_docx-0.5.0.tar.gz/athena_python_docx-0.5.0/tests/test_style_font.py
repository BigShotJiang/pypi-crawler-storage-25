"""Tests for the ``Style.font`` read+write surface.

Verifies that ``style.font.name`` / ``style.font.size`` read through to
SuperDoc's ``info.styles.paragraphStyles[styleId]`` payload, and that
writes warn-and-stash with the new value visible to subsequent reads.
"""

from __future__ import annotations

from typing import Any

import pytest

from docx.shared import Pt
from docx.styles.style import (
    CharacterStyle,
    ParagraphStyle,
    PendingStyleMutationWarning,
)
from docx.text.run import Font


def _make_style(cls: type, *, style_id: str, session: Any):
    from docx.enum.style import WD_STYLE_TYPE

    return cls(name=style_id, style_type=WD_STYLE_TYPE.PARAGRAPH, session=session)


def _scripted_info(items: list[dict]) -> dict:
    return {
        "counts": {"paragraphs": 0},
        "outline": [],
        "capabilities": {},
        "revision": "r-test",
        "styles": {"paragraphStyles": items},
    }


def test_character_style_font_returns_font_instance(mock_session: Any) -> None:
    """`style.font` returns a real :class:`Font` instance, not None,
    so ``isinstance(s.font, Font)`` checks (and `style.font.X` access)
    work like upstream python-docx."""
    style = _make_style(CharacterStyle, style_id="Heading 1", session=mock_session)
    assert isinstance(style.font, Font)


def test_style_font_name_reads_from_info(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """`style.font.name` returns ``info.styles.paragraphStyles[styleId].fontFamily``."""
    fake_sd_methods.scripted_returns["info"] = _scripted_info(
        [
            {"styleId": "Heading 1", "count": 3, "fontFamily": "Calibri", "fontSize": 16},
            {"styleId": "Normal", "count": 42, "fontFamily": "Times New Roman"},
        ]
    )
    style = _make_style(CharacterStyle, style_id="Heading 1", session=mock_session)
    assert style.font.name == "Calibri"


def test_style_font_size_reads_from_info_as_pt(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """`style.font.size` returns a :class:`Pt` length built from
    ``info.styles.paragraphStyles[styleId].fontSize``."""
    fake_sd_methods.scripted_returns["info"] = _scripted_info(
        [{"styleId": "Heading 1", "count": 3, "fontFamily": "Calibri", "fontSize": 16}]
    )
    style = _make_style(CharacterStyle, style_id="Heading 1", session=mock_session)
    size = style.font.size
    assert isinstance(size, Pt)
    assert size.pt == 16.0


def test_style_font_returns_none_when_style_not_in_info(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """A style with no usage in the document doesn't appear in
    ``info.styles.paragraphStyles``; reads return ``None``."""
    fake_sd_methods.scripted_returns["info"] = _scripted_info([])
    style = _make_style(CharacterStyle, style_id="Heading 99", session=mock_session)
    assert style.font.name is None
    assert style.font.size is None


def test_style_font_setter_warns_and_round_trips(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """`style.font.name = "Arial"` warns + stashes; subsequent read
    returns the override regardless of what info says."""
    fake_sd_methods.scripted_returns["info"] = _scripted_info(
        [{"styleId": "Heading 1", "count": 3, "fontFamily": "Calibri", "fontSize": 16}]
    )
    style = _make_style(CharacterStyle, style_id="Heading 1", session=mock_session)

    with pytest.warns(PendingStyleMutationWarning, match="font.fontFamily"):
        style.font.name = "Arial"
    # Override wins over the info read.
    assert style.font.name == "Arial"


def test_style_font_size_setter_round_trips(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    fake_sd_methods.scripted_returns["info"] = _scripted_info(
        [{"styleId": "Heading 1", "count": 3, "fontFamily": "Calibri", "fontSize": 16}]
    )
    style = _make_style(CharacterStyle, style_id="Heading 1", session=mock_session)
    with pytest.warns(PendingStyleMutationWarning, match="font.fontSize"):
        style.font.size = Pt(24)
    new_size = style.font.size
    assert isinstance(new_size, Pt)
    assert new_size.pt == 24.0


def test_style_font_bool_props_warn_and_round_trip(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """SuperDoc doesn't expose per-style bold/italic at the
    ``info.styles`` level; the read side returns the local override
    (or ``None`` if untouched), the setter warns and stashes."""
    style = _make_style(CharacterStyle, style_id="Custom", session=mock_session)
    assert style.font.bold is None
    assert style.font.italic is None

    with pytest.warns(PendingStyleMutationWarning, match="font.bold"):
        style.font.bold = True
    with pytest.warns(PendingStyleMutationWarning, match="font.italic"):
        style.font.italic = True
    assert style.font.bold is True
    assert style.font.italic is True


def test_style_font_does_not_call_info_when_no_session(
    fake_sd_methods: Any,
) -> None:
    """A detached style (no session) reads return None and never call
    SuperDoc's info."""
    style = _make_style(CharacterStyle, style_id="Detached", session=None)
    # Pre-condition: no recorded calls.
    assert fake_sd_methods.calls == []
    assert style.font.name is None
    # Still no calls.
    assert fake_sd_methods.calls == []


def test_paragraph_style_inherits_font_from_character_style(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """`ParagraphStyle.font` works the same as `CharacterStyle.font`
    (since `ParagraphStyle` extends `CharacterStyle`)."""
    fake_sd_methods.scripted_returns["info"] = _scripted_info(
        [{"styleId": "Body", "count": 7, "fontFamily": "Georgia", "fontSize": 11}]
    )
    style = _make_style(ParagraphStyle, style_id="Body", session=mock_session)
    assert isinstance(style.font, Font)
    assert style.font.name == "Georgia"
    assert style.font.size is not None and style.font.size.pt == 11.0


def test_style_font_caches_backing(mock_session: Any) -> None:
    """Repeated `style.font` access reuses the same backing — overrides
    written through one ``font`` proxy are visible through the next."""
    style = _make_style(CharacterStyle, style_id="X", session=mock_session)
    with pytest.warns(PendingStyleMutationWarning):
        style.font.bold = True
    # New access — same backing, override still present.
    assert style.font.bold is True
