"""Tests for the parity-misc additions:

- ``Run.contains_page_break`` (was only on Paragraph)
- ``Paragraph.rendered_page_breaks`` + ``RenderedPageBreak`` proxy
- ``Font.math``
- ``Section.iter_inner_content``
- ``Styles.get_by_id`` / ``Styles.get_style_id``
- ``BaseStyle.builtin`` / ``BaseStyle.locked``
- ``WD_STYLE`` (132 values) / ``WD_STYLE_TYPE`` (4 values) split
"""

from __future__ import annotations

from tests.fidelity.fake_session import install_fake_session


# ---------------------------------------------------------------------------
# Page-break inspection
# ---------------------------------------------------------------------------


def test_run_contains_page_break_false_when_no_break() -> None:
    install_fake_session()
    from docx import Document

    doc = Document("asset_fake")
    p = doc.add_paragraph("plain")
    r = list(p.runs)[0]
    assert r.contains_page_break is False


def test_run_contains_page_break_true_when_form_feed_present() -> None:
    install_fake_session()
    from docx import Document

    doc = Document("asset_fake")
    p = doc.add_paragraph("before\fafter")
    r = list(p.runs)[0]
    assert r.contains_page_break is True


def test_paragraph_rendered_page_breaks_empty_for_plain_text() -> None:
    install_fake_session()
    from docx import Document

    doc = Document("asset_fake")
    p = doc.add_paragraph("no breaks here")
    assert p.rendered_page_breaks == []


def test_paragraph_rendered_page_breaks_yields_proxy_per_break() -> None:
    install_fake_session()
    from docx import Document
    from docx.text.paragraph import RenderedPageBreak

    doc = Document("asset_fake")
    # Two hard breaks → 2 RenderedPageBreak instances.
    p = doc.add_paragraph("before\fmiddle\fafter")
    breaks = p.rendered_page_breaks
    assert len(breaks) == 2
    assert all(isinstance(b, RenderedPageBreak) for b in breaks)
    assert breaks[0].preceding_paragraph_text == "before"
    # Offset is the position of the \f character in the paragraph text.
    assert breaks[0].offset == len("before")


# ---------------------------------------------------------------------------
# Font.math
# ---------------------------------------------------------------------------


def test_font_math_setter_records_inline_mark() -> None:
    install_fake_session()
    from docx import Document

    doc = Document("asset_fake")
    p = doc.add_paragraph()
    r = p.add_run("E = mc^2")
    r.font.math = True
    # Confirmed via the recorded SuperDoc op trace.
    calls = doc._session.calls()  # type: ignore[attr-defined]
    format_calls = [c for c in calls if c[0] == "format.apply"]
    assert format_calls, "expected at least one format.apply call"
    last = format_calls[-1][1]
    assert last["inline"].get("math") is True


# ---------------------------------------------------------------------------
# Section.iter_inner_content
# ---------------------------------------------------------------------------


def test_section_iter_inner_content_yields_blocks() -> None:
    install_fake_session()
    from docx import Document
    from docx.table import Table
    from docx.text.paragraph import Paragraph

    doc = Document("asset_fake")
    doc.add_heading("Title", level=1)
    doc.add_paragraph("first body")
    doc.add_table(rows=2, cols=2)
    doc.add_paragraph("after table")

    section = doc.sections[0]
    items = list(section.iter_inner_content())
    types = [type(i).__name__ for i in items]
    assert "Table" in types
    assert types.count("Paragraph") >= 3
    assert all(isinstance(i, (Paragraph, Table)) for i in items)


# ---------------------------------------------------------------------------
# Styles.get_by_id / get_style_id
# ---------------------------------------------------------------------------


def test_styles_get_by_id_returns_default_for_none() -> None:
    install_fake_session()
    from docx import Document
    from docx.enum.style import WD_STYLE_TYPE

    doc = Document("asset_fake")
    s = doc.styles.get_by_id(None, WD_STYLE_TYPE.PARAGRAPH)
    assert s is not None
    assert s.name == "Normal"


def test_styles_get_by_id_returns_none_for_unknown_id() -> None:
    install_fake_session()
    from docx import Document
    from docx.enum.style import WD_STYLE_TYPE

    doc = Document("asset_fake")
    s = doc.styles.get_by_id("no_such_style_id", WD_STYLE_TYPE.PARAGRAPH)
    assert s is None


def test_styles_get_style_id_resolves_name_to_id() -> None:
    install_fake_session()
    from docx import Document
    from docx.enum.style import WD_STYLE_TYPE

    doc = Document("asset_fake")
    sid = doc.styles.get_style_id("Heading 1", WD_STYLE_TYPE.PARAGRAPH)
    # In our model name == style_id, so any returned non-None string is fine.
    assert sid == "Heading 1"


def test_styles_get_style_id_returns_none_for_wrong_type() -> None:
    install_fake_session()
    from docx import Document
    from docx.enum.style import WD_STYLE_TYPE

    doc = Document("asset_fake")
    # "Heading 1" exists as a paragraph style; asking under TABLE rejects.
    sid = doc.styles.get_style_id("Heading 1", WD_STYLE_TYPE.TABLE)
    assert sid is None


# ---------------------------------------------------------------------------
# BaseStyle.builtin / .locked
# ---------------------------------------------------------------------------


def test_base_style_builtin_true_for_word_default_names() -> None:
    install_fake_session()
    from docx import Document

    doc = Document("asset_fake")
    s = doc.styles["Heading 1"]
    assert s.builtin is True


def test_base_style_builtin_false_for_custom_name() -> None:
    install_fake_session()
    from docx import Document
    from docx.enum.style import WD_STYLE_TYPE

    doc = Document("asset_fake")
    custom = doc.styles.add_style("CustomCalloutStyle", WD_STYLE_TYPE.PARAGRAPH)
    assert custom.builtin is False


def test_base_style_locked_returns_false() -> None:
    install_fake_session()
    from docx import Document

    doc = Document("asset_fake")
    s = doc.styles["Normal"]
    assert s.locked is False


# ---------------------------------------------------------------------------
# WD_STYLE / WD_STYLE_TYPE / WD_BUILTIN_STYLE separation
# ---------------------------------------------------------------------------


def test_wd_style_type_has_four_kinds() -> None:
    from docx.enum.style import WD_STYLE_TYPE

    names = {m.name for m in WD_STYLE_TYPE}
    assert names == {"PARAGRAPH", "CHARACTER", "LIST", "TABLE"}


def test_wd_style_has_full_word_canonical_set() -> None:
    """Stock python-docx 1.2.0 ships 132 WD_STYLE members; we mirror exactly."""
    from docx.enum.style import WD_STYLE

    assert len(list(WD_STYLE)) == 132
    # Spot-check a few well-known wIndex values.
    assert WD_STYLE.NORMAL.value == -1
    assert WD_STYLE.HEADING_1.value == -2
    assert WD_STYLE.BODY_TEXT.value == -67


def test_wd_style_is_distinct_from_wd_style_type() -> None:
    from docx.enum.style import WD_STYLE, WD_STYLE_TYPE

    assert WD_STYLE is not WD_STYLE_TYPE


def test_wd_underline_inherited_value() -> None:
    """0.5.0 fixed INHERITED to match python-docx (= -1, not 'inherited')."""
    from docx.enum.text import WD_UNDERLINE

    assert WD_UNDERLINE.INHERITED.value == -1
