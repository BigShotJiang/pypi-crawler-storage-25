"""Run AB_PROBE_CASES through stock python-docx vs our FakeSession SDK
and print per-case diff.

Uses a richer extractor than the legacy binary_round_trip — captures
alignment, indents, spacing, line-spacing, keep flags, run font
properties, table column/row sizing, section page setup. The comparator
emits a structured diff per field so we can correlate residual gaps to
specific python-docx surfaces.

Usage:
    uv run python tests/fidelity/ab_probe_runner.py
    uv run python tests/fidelity/ab_probe_runner.py --filter abp01
    uv run python tests/fidelity/ab_probe_runner.py --verbose
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

_SDK_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_SDK_ROOT))

from tests.fidelity.ab_probe_cases import AB_PROBE_CASES  # noqa: E402
from tests.fidelity.binary_round_trip import (  # noqa: E402
    install_fake_session,
    run_stock_and_save,
)
from tests.fidelity.complex_cases import ComplexCase  # noqa: E402


# ----------------------------------------------------------------------
# Stock extractor — runs in the .venv-pydocx subprocess, captures rich
# paragraph + run + section state from a saved .docx.
# ----------------------------------------------------------------------

_STOCK_EXTRACT_SCRIPT = '''
import json, sys
from docx import Document
from docx.shared import Length

def emu(v):
    if v is None:
        return None
    if isinstance(v, Length):
        return int(v)
    return int(v) if v else None

def hex_color(c):
    if c is None or c.rgb is None:
        return None
    return str(c.rgb)

d = Document(__INPUT__)
paragraphs = []
for p in d.paragraphs:
    pf = p.paragraph_format
    runs = []
    for r in p.runs:
        f = r.font
        runs.append({
            "text": r.text,
            "bold": r.bold,
            "italic": r.italic,
            "underline": r.underline if isinstance(r.underline, bool) else (r.underline.value if r.underline else None) if hasattr(r.underline, "value") else r.underline,
            "strike": f.strike,
            "double_strike": f.double_strike,
            "all_caps": f.all_caps,
            "small_caps": f.small_caps,
            "subscript": f.subscript,
            "superscript": f.superscript,
            "font_name": f.name,
            "font_size_emu": emu(f.size),
            "font_color": hex_color(f.color),
            "highlight": f.highlight_color.value if f.highlight_color else None,
            "math": f.math,
        })
    paragraphs.append({
        "text": p.text,
        "style": p.style.name if p.style else "",
        "alignment": p.alignment.value if p.alignment else None,
        "left_indent_emu": emu(pf.left_indent),
        "right_indent_emu": emu(pf.right_indent),
        "first_line_indent_emu": emu(pf.first_line_indent),
        "space_before_emu": emu(pf.space_before),
        "space_after_emu": emu(pf.space_after),
        "line_spacing": pf.line_spacing if isinstance(pf.line_spacing, (int, float)) else (emu(pf.line_spacing) if pf.line_spacing else None),
        "line_spacing_rule": pf.line_spacing_rule.value if pf.line_spacing_rule else None,
        "keep_with_next": pf.keep_with_next,
        "keep_together": pf.keep_together,
        "page_break_before": pf.page_break_before,
        "widow_control": pf.widow_control,
        "runs": runs,
    })

tables = []
for t in d.tables:
    rows = []
    for row in t.rows:
        rows.append([c.text for c in row.cells])
    tables.append({
        "rows": rows,
        "alignment": t.alignment.value if t.alignment else None,
    })

sections = []
for s in d.sections:
    sections.append({
        "orientation": s.orientation.value if s.orientation else None,
        "page_width_emu": emu(s.page_width),
        "page_height_emu": emu(s.page_height),
        "left_margin_emu": emu(s.left_margin),
        "right_margin_emu": emu(s.right_margin),
        "top_margin_emu": emu(s.top_margin),
        "bottom_margin_emu": emu(s.bottom_margin),
    })

out = {
    "paragraph_count": len(paragraphs),
    "table_count": len(tables),
    "section_count": len(sections),
    "paragraphs": paragraphs,
    "tables": tables,
    "sections": sections,
}
print(json.dumps(out))
'''


def extract_stock(path: Path) -> dict:
    pydocx_py = _SDK_ROOT / ".venv-pydocx" / "bin" / "python"
    if not pydocx_py.exists():
        return {"error": "no .venv-pydocx"}
    script = _STOCK_EXTRACT_SCRIPT.replace("__INPUT__", repr(str(path)))
    env = dict(os.environ)
    env.pop("PYTHONPATH", None)
    res = subprocess.run(
        [str(pydocx_py), "-c", script],
        capture_output=True,
        text=True,
        timeout=30,
        cwd="/tmp",
        env=env,
    )
    if res.returncode != 0:
        return {"error": res.stderr[:500]}
    return json.loads(res.stdout)


# ----------------------------------------------------------------------
# Our extractor — pulls the same shape from the FakeSession state.
# ----------------------------------------------------------------------


def extract_ours(case: ComplexCase) -> tuple[bool, str, dict]:
    install_fake_session()
    from docx import Document
    from docx.shared import Inches, Pt, RGBColor  # noqa: F401

    try:
        doc = Document("asset_fake")
        ns = {"doc": doc, "RGBColor": RGBColor, "Pt": Pt, "Inches": Inches}
        exec(compile(case.script, f"<case:{case.name}>", "exec"), ns, ns)
        # _flush() drains buffered mutations to the fake; save() in
        # 0.5.0 mirrors python-docx and requires path_or_stream.
        doc._flush()  # noqa: SLF001
        state = doc._session.state()  # type: ignore[attr-defined]
    except Exception as e:  # noqa: BLE001
        return False, f"{type(e).__name__}: {e}", {}

    # Twips → EMU: 1 twip = 635 EMU (1/20pt × 12700).
    def twips_to_emu(v):
        if v is None:
            return None
        return int(v) * 635

    # SuperDoc text-align values map to python-docx WD_ALIGN_PARAGRAPH.value:
    #   "left"=0, "center"=1, "right"=2, "justify"=3, "distribute"=4 (rough).
    _ALIGN_MAP = {"left": 0, "center": 1, "right": 2, "justify": 3, "start": 0, "end": 2}

    paragraphs = []
    for b in state.blocks:
        runs = []
        if b.inlines:
            for inline in b.inlines:
                rd = inline.get("run") or {}
                if not isinstance(rd, dict):
                    continue
                size = rd.get("fontSize")
                size_emu = None
                if isinstance(size, (int, float)):
                    size_emu = int(size * 12700)
                # SDK writes some marks under SuperDoc-native key names that
                # don't match python-docx's pythonic property names —
                # `dstrike` for double-strike, `caps` for all-caps, etc.
                # We surface python-docx names here so the diff lines up.
                # SuperDoc stores subscript/superscript as a single
                # `vertAlign` mark with three states: "baseline" / "subscript"
                # / "superscript". python-docx surfaces them as two
                # independent boolean Font properties — translate.
                vert = rd.get("vertAlign")
                # python-docx returns False (not None) when the property
                # was explicitly cleared; we treat the absence of vertAlign
                # as "not set" but a vertAlign of "baseline" as the
                # baseline state where both flags are False.
                if vert == "subscript":
                    sub_v, sup_v = True, False
                elif vert == "superscript":
                    sub_v, sup_v = False, True
                elif vert == "baseline":
                    sub_v, sup_v = False, False
                else:
                    sub_v = rd.get("subscript")
                    sup_v = rd.get("superscript")
                runs.append({
                    "text": rd.get("text", ""),
                    "bold": rd.get("bold"),
                    "italic": rd.get("italic"),
                    "underline": rd.get("underline"),
                    "strike": rd.get("strike"),
                    "double_strike": rd.get("dstrike") or rd.get("doubleStrike"),
                    "all_caps": rd.get("caps") or rd.get("allCaps"),
                    "small_caps": rd.get("smallCaps"),
                    "subscript": sub_v,
                    "superscript": sup_v,
                    "font_name": rd.get("fontFamily"),
                    "font_size_emu": size_emu,
                    "font_color": rd.get("color"),
                    "highlight": rd.get("highlight"),
                    "math": rd.get("math"),
                })
        # Map SuperDoc lineRule + line value to python-docx's
        # WD_LINE_SPACING enum value:
        #   stored "auto" + multiplier 1.0 → SINGLE (0)
        #   stored "auto" + multiplier 1.5 → ONE_POINT_FIVE (1)
        #   stored "auto" + multiplier 2.0 → DOUBLE (2)
        #   stored "auto" + other          → MULTIPLE (5)
        #   stored "atLeast"               → AT_LEAST (3)
        #   stored "exact"                 → EXACTLY (4)
        def _map_line_rule(rule, multiplier):
            if rule == "atLeast":
                return 3
            if rule in ("exact", "exactly"):
                return 4
            if rule == "auto":
                if multiplier == 1.0:
                    return 0
                if multiplier == 1.5:
                    return 1
                if multiplier == 2.0:
                    return 2
                return 5
            return None

        attrs = b.attrs or {}
        indent = attrs.get("indent") or attrs.get("indentation") or {}
        spacing = attrs.get("spacing") or {}
        # SuperDoc's "spacing.line" semantics: when lineRule is "auto",
        # "line" is a multiplier × 240 (twips); otherwise twips. We
        # surface the raw value plus rule so the comparator can apply
        # python-docx's matching reverse mapping.
        line_v = spacing.get("line")
        line_rule = spacing.get("lineRule")
        line_spacing = None
        if line_v is not None:
            if line_rule == "auto":
                line_spacing = float(line_v) / 240.0
            else:
                # Stored in twips; python-docx returns a Length (EMU).
                line_spacing = twips_to_emu(line_v)
        paragraphs.append({
            "text": b.text,
            "style": b.style_id or "",
            "alignment": _ALIGN_MAP.get(b.alignment) if isinstance(b.alignment, str) else b.alignment,
            "left_indent_emu": twips_to_emu(indent.get("left")),
            "right_indent_emu": twips_to_emu(indent.get("right")),
            "first_line_indent_emu": (
                twips_to_emu(indent.get("firstLine"))
                if indent.get("firstLine") is not None
                else (-twips_to_emu(indent.get("hanging")) if indent.get("hanging") is not None else None)
            ),
            "space_before_emu": twips_to_emu(spacing.get("before")),
            "space_after_emu": twips_to_emu(spacing.get("after")),
            "line_spacing": line_spacing,
            "line_spacing_rule": _map_line_rule(line_rule, line_spacing),
            "keep_with_next": attrs.get("keepNext"),
            "keep_together": attrs.get("keepLines"),
            "page_break_before": attrs.get("pageBreakBefore"),
            "widow_control": attrs.get("widowControl"),
            "runs": runs,
        })

    tables = []
    for t in state.tables:
        if t.parent_cell is not None:
            continue
        rows = []
        for r_idx, row in enumerate(t.cells):
            rows.append([t.cells[r_idx][c_idx].text for c_idx in range(len(row))])
        tables.append({"rows": rows, "alignment": t.alignment})

    # Section units: SuperDoc stores width/height/margins in points,
    # orientation as a string. Stock python-docx returns Lengths (EMU) and
    # the WD_ORIENTATION enum value (int).
    _ORIENT_MAP = {"portrait": 0, "landscape": 1}

    def pt_to_emu(v):
        if v is None:
            return None
        return int(round(float(v) * 12700))

    sections = []
    for s in state.sections:
        ps = s.page_setup or {}
        mg = s.margins or {}
        orient = ps.get("orientation")
        sections.append({
            "orientation": _ORIENT_MAP.get(orient) if isinstance(orient, str) else orient,
            "page_width_emu": pt_to_emu(ps.get("width")),
            "page_height_emu": pt_to_emu(ps.get("height")),
            "left_margin_emu": pt_to_emu(mg.get("left")),
            "right_margin_emu": pt_to_emu(mg.get("right")),
            "top_margin_emu": pt_to_emu(mg.get("top")),
            "bottom_margin_emu": pt_to_emu(mg.get("bottom")),
        })

    return True, "", {
        "paragraph_count": len(paragraphs),
        "table_count": len(tables),
        "section_count": len(sections),
        "paragraphs": paragraphs,
        "tables": tables,
        "sections": sections,
    }


# ----------------------------------------------------------------------
# Comparator — emits one diff line per differing field.
# ----------------------------------------------------------------------


def _diff_dict(prefix: str, a: dict, b: dict, ignore: set[str] | None = None) -> list[str]:
    ignore = ignore or set()
    out: list[str] = []
    for k in sorted(set(a) | set(b)):
        if k in ignore:
            continue
        av, bv = a.get(k), b.get(k)
        if av != bv:
            out.append(f"{prefix}.{k}: stock={av!r} ours={bv!r}")
    return out


# Fields that python-docx returns as None when not explicitly set; our
# fake may also leave them None. Only flag when both sides have a value
# and they disagree, or stock has a value and we don't.
_TOLERATE_NONE = False  # set True to suppress "stock=X ours=None" rows


def diff_features(
    stock: dict,
    ours: dict,
    *,
    focus: list[str] | None = None,
    skip_sections: bool = False,
) -> list[str]:
    if "error" in stock:
        return [f"stock error: {stock['error'][:200]}"]
    diffs: list[str] = []

    # python-docx pads with a trailing empty paragraph; trim before
    # detailed comparison.
    s_paras = list(stock["paragraphs"])
    o_paras = list(ours["paragraphs"])
    while s_paras and not s_paras[-1]["text"]:
        s_paras.pop()
    while o_paras and not o_paras[-1]["text"]:
        o_paras.pop()

    if len(s_paras) != len(o_paras):
        diffs.append(
            f"paragraph_count (trimmed): stock={len(s_paras)} ours={len(o_paras)}"
        )

    for i, (s, o) in enumerate(zip(s_paras, o_paras)):
        if s["text"] != o["text"]:
            diffs.append(f"paragraphs[{i}].text: stock={s['text']!r} ours={o['text']!r}")
        if focus and "paragraph" in focus or focus is None:
            for k in (
                "alignment",
                "left_indent_emu",
                "right_indent_emu",
                "first_line_indent_emu",
                "space_before_emu",
                "space_after_emu",
                "line_spacing",
                "line_spacing_rule",
                "keep_with_next",
                "keep_together",
                "page_break_before",
                "widow_control",
            ):
                sv, ov = s.get(k), o.get(k)
                if sv != ov:
                    diffs.append(f"paragraphs[{i}].{k}: stock={sv!r} ours={ov!r}")
        # runs
        s_runs = s.get("runs") or []
        o_runs = o.get("runs") or []
        for j in range(max(len(s_runs), len(o_runs))):
            sr = s_runs[j] if j < len(s_runs) else {}
            or_ = o_runs[j] if j < len(o_runs) else {}
            for k in (
                "text",
                "bold",
                "italic",
                "underline",
                "strike",
                "double_strike",
                "all_caps",
                "small_caps",
                "subscript",
                "superscript",
                "font_name",
                "font_size_emu",
                "font_color",
                "highlight",
                "math",
            ):
                sv, ov = sr.get(k), or_.get(k)
                if sv != ov:
                    diffs.append(
                        f"paragraphs[{i}].runs[{j}].{k}: stock={sv!r} ours={ov!r}"
                    )

    # Sections — suppress unless the case explicitly tagged itself
    # `section`. Word's default template carries margins/page-size/etc.
    # that the fake's default section doesn't model; comparing them here
    # would drown every non-section probe in noise.
    #
    # Even on `section`-tagged probes, python-docx returns `None` for
    # fields the user hasn't explicitly assigned even when Word's
    # underlying template default is well-defined (1in margins,
    # PORTRAIT orientation, US Letter). Our fake always surfaces the
    # default values, which would flood diff output. We treat
    # "stock=None ours=Word-default" as a match.
    _SECTION_DEFAULTS = {
        "orientation": 0,              # PORTRAIT
        "page_width_emu": 7772400,     # 8.5in (US Letter)
        "page_height_emu": 10058400,   # 11in
        "left_margin_emu": 1143000,    # 1.25in (Word default)
        "right_margin_emu": 1143000,
        "top_margin_emu": 914400,      # 1in
        "bottom_margin_emu": 914400,
    }
    if not skip_sections:
        s_secs = stock.get("sections") or []
        o_secs = ours.get("sections") or []
        for i in range(max(len(s_secs), len(o_secs))):
            ss = s_secs[i] if i < len(s_secs) else {}
            os_ = o_secs[i] if i < len(o_secs) else {}
            for k in sorted(set(ss) | set(os_)):
                sv, ov = ss.get(k), os_.get(k)
                if sv == ov:
                    continue
                if sv is None and ov == _SECTION_DEFAULTS.get(k):
                    continue  # stock didn't surface the default; we did
                diffs.append(f"sections[{i}].{k}: stock={sv!r} ours={ov!r}")

    return diffs


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--filter", default=None)
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    cases = AB_PROBE_CASES
    if args.filter:
        cases = [c for c in cases if args.filter in c.name]
    if not cases:
        print("(no cases)")
        return 0

    print(f"[ab-probe-rich] {len(cases)} cases")
    print()
    matched = 0
    diff_total: list[tuple[str, list[str]]] = []
    skipped: list[tuple[str, str]] = []

    with tempfile.TemporaryDirectory() as td:
        td_p = Path(td)
        for case in cases:
            out = td_p / f"{case.name}.docx"
            ok, err = run_stock_and_save(case, out)
            if not ok:
                skipped.append((case.name, f"stock: {err[:80]}"))
                print(f"  ⏭  {case.name:45} — SKIP (stock: {err[:80]})")
                continue
            stock = extract_stock(out)
            ours_ok, ours_err, ours = extract_ours(case)
            if not ours_ok:
                skipped.append((case.name, f"ours: {ours_err[:80]}"))
                print(f"  ❌ {case.name:45} — OUR SDK ERROR: {ours_err[:80]}")
                continue
            if "fake_limitation" in case.tags:
                # Exercise the SDK path (we got here, so no exception)
                # but don't diff — the fake doesn't model the relevant
                # behaviour. Surface it so we don't pretend it passed.
                print(f"  ☑  {case.name:45} — RAN (fake_limitation, diff skipped)")
                continue
            skip_sections = "section" not in case.tags
            diffs = diff_features(stock, ours, skip_sections=skip_sections)
            if not diffs:
                matched += 1
                print(f"  ✅ {case.name:45} — MATCH")
            else:
                diff_total.append((case.name, diffs))
                print(f"  ⚠️  {case.name:45} — DIFF ({len(diffs)})")
                for d in diffs[:8]:
                    print(f"      {d}")
                if len(diffs) > 8:
                    print(f"      …{len(diffs) - 8} more")

    print()
    print("=" * 60)
    print(f"matched: {matched}/{len(cases)} | diffs: {len(diff_total)} | skipped: {len(skipped)}")
    return 0 if not diff_total else 1


if __name__ == "__main__":
    sys.exit(main())
