"""A/B parity probe cases — generated to exercise python-docx surface
area NOT covered by the existing fidelity battery.

Each case is a python-docx-style script. The companion runner executes
each script via stock python-docx (saves a real .docx) and via our
FakeSession-driven SDK (records ops + simulates state), then diffs the
extracted feature sets. Diffs feed back into per-turn fixes.

The probes are organised by python-docx surface area (one file-level
list per turn) so we can correlate fixes back to what triggered them.
"""

from __future__ import annotations

from .complex_cases import ComplexCase

# Turn 1: paragraph indents — left, right, first_line, hanging.
# python-docx exposes these as docx.text.parfmt.ParagraphFormat properties
# accepting Length/Emu/Inches/Pt/Mm/Cm/Twips. We've shipped the setters
# but never specifically diffed a stock-write/our-write cycle.
TURN1_INDENTS: list[ComplexCase] = [
    ComplexCase(
        name="abp01_indent_left_right",
        description="Paragraph with left + right indents in Inches",
        script=(
            "from docx.shared import Inches\n"
            "p = doc.add_paragraph('left+right')\n"
            "p.paragraph_format.left_indent = Inches(0.5)\n"
            "p.paragraph_format.right_indent = Inches(0.25)"
        ),
        tags=("ab_probe", "indent"),
    ),
    ComplexCase(
        name="abp02_first_line_indent",
        description="First-line indent (positive)",
        script=(
            "from docx.shared import Inches\n"
            "p = doc.add_paragraph('first-line')\n"
            "p.paragraph_format.first_line_indent = Inches(0.5)"
        ),
        tags=("ab_probe", "indent"),
    ),
    ComplexCase(
        name="abp03_hanging_indent",
        description="Hanging indent (negative first_line_indent)",
        script=(
            "from docx.shared import Inches\n"
            "p = doc.add_paragraph('hanging')\n"
            "p.paragraph_format.left_indent = Inches(0.5)\n"
            "p.paragraph_format.first_line_indent = Inches(-0.5)"
        ),
        tags=("ab_probe", "indent"),
    ),
]

# Turn 2: run-level formatting bools — small_caps, all_caps,
# double_strike, strike, subscript, superscript. python-docx exposes
# these as Font properties; SuperDoc maps them through inline marks.
TURN2_RUN_FORMATTING: list[ComplexCase] = [
    ComplexCase(
        name="abp04_strike",
        description="Run with strike",
        script=(
            "p = doc.add_paragraph()\n"
            "r = p.add_run('struck')\n"
            "r.font.strike = True"
        ),
        tags=("ab_probe", "run_format"),
    ),
    ComplexCase(
        name="abp05_double_strike",
        description="Run with double-strike",
        script=(
            "p = doc.add_paragraph()\n"
            "r = p.add_run('twice')\n"
            "r.font.double_strike = True"
        ),
        tags=("ab_probe", "run_format"),
    ),
    ComplexCase(
        name="abp06_all_caps",
        description="Run with all_caps",
        script=(
            "p = doc.add_paragraph()\n"
            "r = p.add_run('shouty')\n"
            "r.font.all_caps = True"
        ),
        tags=("ab_probe", "run_format"),
    ),
    ComplexCase(
        name="abp07_small_caps",
        description="Run with small_caps",
        script=(
            "p = doc.add_paragraph()\n"
            "r = p.add_run('petite')\n"
            "r.font.small_caps = True"
        ),
        tags=("ab_probe", "run_format"),
    ),
    # FAKE-LIMITATION: multi-run-per-paragraph collapses into a single
    # merged inline in the FakeSession (its `insert` handler concatenates
    # into one run). Real SuperDoc preserves the runs because it tracks
    # ProseMirror inlines separately, so format.apply on a text range
    # splits the inline. The SDK code path is correct; verifying against
    # real Daytona (L8) is needed to confirm. Until then we tag these
    # cases `fake_limitation` so the runner skips diff-checking them but
    # still exercises the SDK plumbing.
    ComplexCase(
        name="abp08_subscript",
        description="Run with subscript",
        script=(
            "p = doc.add_paragraph()\n"
            "p.add_run('H')\n"
            "r = p.add_run('2')\n"
            "r.font.subscript = True\n"
            "p.add_run('O')"
        ),
        tags=("ab_probe", "run_format", "fake_limitation"),
    ),
    ComplexCase(
        name="abp09_superscript",
        description="Run with superscript",
        script=(
            "p = doc.add_paragraph()\n"
            "p.add_run('x')\n"
            "r = p.add_run('2')\n"
            "r.font.superscript = True"
        ),
        tags=("ab_probe", "run_format", "fake_limitation"),
    ),
]


# Turn 3: keep flags + page-break-before + widow control. Stock
# python-docx exposes them as ParagraphFormat booleans backed by
# w:keepNext / w:keepLines / w:pageBreakBefore / w:widowControl XML
# elements. SDK routes through format.paragraph.set_keep_options /
# set_flow_options.
TURN3_PARA_FLOW: list[ComplexCase] = [
    ComplexCase(
        name="abp10_keep_with_next",
        description="Paragraph with keep_with_next=True",
        script=(
            "p = doc.add_paragraph('intro')\n"
            "p.paragraph_format.keep_with_next = True"
        ),
        tags=("ab_probe", "para_flow"),
    ),
    ComplexCase(
        name="abp11_keep_together",
        description="Paragraph with keep_together=True",
        script=(
            "p = doc.add_paragraph('whole')\n"
            "p.paragraph_format.keep_together = True"
        ),
        tags=("ab_probe", "para_flow"),
    ),
    ComplexCase(
        name="abp12_page_break_before",
        description="Paragraph with page_break_before=True",
        script=(
            "p = doc.add_paragraph('chapter')\n"
            "p.paragraph_format.page_break_before = True"
        ),
        tags=("ab_probe", "para_flow"),
    ),
    ComplexCase(
        name="abp13_widow_control",
        description="Paragraph with widow_control=False",
        script=(
            "p = doc.add_paragraph('lonely')\n"
            "p.paragraph_format.widow_control = False"
        ),
        tags=("ab_probe", "para_flow"),
    ),
]


# Turn 4: paragraph spacing — space_before / space_after / line_spacing.
TURN4_PARA_SPACING: list[ComplexCase] = [
    ComplexCase(
        name="abp14_space_before_after",
        description="Paragraph with space_before and space_after in Pt",
        script=(
            "from docx.shared import Pt\n"
            "p = doc.add_paragraph('with spacing')\n"
            "p.paragraph_format.space_before = Pt(12)\n"
            "p.paragraph_format.space_after = Pt(6)"
        ),
        tags=("ab_probe", "para_spacing"),
    ),
    ComplexCase(
        name="abp15_line_spacing_multiple",
        description="Paragraph with line_spacing as 1.5 multiplier",
        script=(
            "p = doc.add_paragraph('1.5x line spacing')\n"
            "p.paragraph_format.line_spacing = 1.5"
        ),
        tags=("ab_probe", "para_spacing"),
    ),
]


# Turn 5: alignment — every WD_ALIGN_PARAGRAPH value.
TURN5_ALIGNMENT: list[ComplexCase] = [
    ComplexCase(
        name="abp16_align_center",
        description="Center-aligned paragraph",
        script=(
            "from docx.enum.text import WD_ALIGN_PARAGRAPH\n"
            "p = doc.add_paragraph('centered')\n"
            "p.alignment = WD_ALIGN_PARAGRAPH.CENTER"
        ),
        tags=("ab_probe", "alignment"),
    ),
    ComplexCase(
        name="abp17_align_right",
        description="Right-aligned paragraph",
        script=(
            "from docx.enum.text import WD_ALIGN_PARAGRAPH\n"
            "p = doc.add_paragraph('right')\n"
            "p.alignment = WD_ALIGN_PARAGRAPH.RIGHT"
        ),
        tags=("ab_probe", "alignment"),
    ),
    ComplexCase(
        name="abp18_align_justify",
        description="Justified paragraph",
        script=(
            "from docx.enum.text import WD_ALIGN_PARAGRAPH\n"
            "p = doc.add_paragraph('justified')\n"
            "p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY"
        ),
        tags=("ab_probe", "alignment"),
    ),
]


# Aggregate is what the runner consumes.
# Turn 6: font name + size + color.
TURN6_FONT_BASICS: list[ComplexCase] = [
    ComplexCase(
        name="abp19_font_name",
        description="Run with explicit font_name",
        script=(
            "p = doc.add_paragraph()\n"
            "r = p.add_run('Helvetica run')\n"
            "r.font.name = 'Helvetica'"
        ),
        tags=("ab_probe", "font"),
    ),
    ComplexCase(
        name="abp20_font_size_pt",
        description="Run with font_size = Pt(14)",
        script=(
            "from docx.shared import Pt\n"
            "p = doc.add_paragraph()\n"
            "r = p.add_run('14pt')\n"
            "r.font.size = Pt(14)"
        ),
        tags=("ab_probe", "font"),
    ),
    ComplexCase(
        name="abp21_font_color_rgb",
        description="Run with font_color set to red",
        script=(
            "from docx.shared import RGBColor\n"
            "p = doc.add_paragraph()\n"
            "r = p.add_run('red text')\n"
            "r.font.color.rgb = RGBColor(0xFF, 0x00, 0x00)"
        ),
        tags=("ab_probe", "font"),
    ),
]


# Turn 7: multi-paragraph — exercise document order, paragraph counts,
# style propagation across paragraphs.
TURN7_MULTI_PARAGRAPH: list[ComplexCase] = [
    ComplexCase(
        name="abp22_three_paragraphs",
        description="Three sequential paragraphs preserve text + order",
        script=(
            "doc.add_paragraph('first')\n"
            "doc.add_paragraph('second')\n"
            "doc.add_paragraph('third')"
        ),
        tags=("ab_probe", "multi_para"),
    ),
    ComplexCase(
        name="abp23_mixed_styles",
        description="Heading 1, body, Heading 2, body",
        script=(
            "doc.add_heading('Top', level=1)\n"
            "doc.add_paragraph('body under top')\n"
            "doc.add_heading('Mid', level=2)\n"
            "doc.add_paragraph('body under mid')"
        ),
        tags=("ab_probe", "multi_para", "styles"),
    ),
]


# Turn 8: heading levels 1-6.
TURN8_HEADING_LEVELS: list[ComplexCase] = [
    ComplexCase(
        name=f"abp24_heading_level_{lvl}",
        description=f"Heading at level {lvl}",
        script=f"doc.add_heading('H{lvl}', level={lvl})",
        tags=("ab_probe", "heading"),
    )
    for lvl in (1, 2, 3, 4, 5, 6)
]


# Turn 9: tab stops with various alignments + leaders.
TURN9_TAB_STOPS: list[ComplexCase] = [
    ComplexCase(
        name="abp30_tab_stop_left",
        description="Left-aligned tab stop at 1in",
        script=(
            "from docx.shared import Inches\n"
            "from docx.enum.text import WD_TAB_ALIGNMENT\n"
            "p = doc.add_paragraph('with tab')\n"
            "p.paragraph_format.tab_stops.add_tab_stop(Inches(1), WD_TAB_ALIGNMENT.LEFT)"
        ),
        tags=("ab_probe", "tab_stops"),
    ),
    ComplexCase(
        name="abp31_tab_stop_center",
        description="Center-aligned tab stop at 2in",
        script=(
            "from docx.shared import Inches\n"
            "from docx.enum.text import WD_TAB_ALIGNMENT\n"
            "p = doc.add_paragraph('with tab')\n"
            "p.paragraph_format.tab_stops.add_tab_stop(Inches(2), WD_TAB_ALIGNMENT.CENTER)"
        ),
        tags=("ab_probe", "tab_stops"),
    ),
]


# Turn 10: text replacement + edge cases on paragraph.text setter.
TURN10_TEXT_REPLACE: list[ComplexCase] = [
    ComplexCase(
        name="abp32_paragraph_text_setter",
        description="Setting paragraph.text replaces all content",
        script=(
            "p = doc.add_paragraph('initial text')\n"
            "p.text = 'replaced'"
        ),
        tags=("ab_probe", "text_setter"),
    ),
    ComplexCase(
        name="abp33_run_text_setter",
        description="Setting run.text replaces just the run's content",
        script=(
            "p = doc.add_paragraph()\n"
            "r = p.add_run('original')\n"
            "r.text = 'updated'"
        ),
        tags=("ab_probe", "text_setter"),
    ),
]


# Turn 11: empty edge cases.
TURN11_EMPTY_EDGES: list[ComplexCase] = [
    ComplexCase(
        name="abp34_empty_paragraph",
        description="Empty paragraph survives the round-trip",
        script=("doc.add_paragraph('')"),
        tags=("ab_probe", "edges"),
    ),
    ComplexCase(
        name="abp35_paragraph_then_empty",
        description="Content paragraph followed by empty paragraph",
        script=(
            "doc.add_paragraph('content')\n"
            "doc.add_paragraph('')"
        ),
        tags=("ab_probe", "edges"),
    ),
]


# Turn 12: tables — basic dims + cell text.
TURN12_TABLES_BASIC: list[ComplexCase] = [
    ComplexCase(
        name="abp36_table_2x2_with_text",
        description="2x2 table, all cells populated",
        script=(
            "t = doc.add_table(rows=2, cols=2)\n"
            "t.cell(0,0).text = 'a'\n"
            "t.cell(0,1).text = 'b'\n"
            "t.cell(1,0).text = 'c'\n"
            "t.cell(1,1).text = 'd'"
        ),
        tags=("ab_probe", "table"),
    ),
    ComplexCase(
        name="abp37_table_horizontal_merge",
        description="2x3 table with horizontal header merge",
        script=(
            "t = doc.add_table(rows=2, cols=3)\n"
            "t.cell(0,0).merge(t.cell(0,2))\n"
            "t.cell(0,0).text = 'header'\n"
            "for c in range(3): t.cell(1,c).text = f'b{c}'"
        ),
        tags=("ab_probe", "table"),
    ),
]


# Turn 13: section page setup. Tagged `section` so the runner does
# diff section-level fields (most other turns suppress them).
TURN13_SECTIONS: list[ComplexCase] = [
    ComplexCase(
        name="abp40_section_landscape",
        description="Set section orientation to landscape",
        script=(
            "from docx.enum.section import WD_ORIENTATION\n"
            "s = doc.sections[0]\n"
            "s.orientation = WD_ORIENTATION.LANDSCAPE\n"
            "doc.add_paragraph('on landscape')"
        ),
        tags=("ab_probe", "section"),
    ),
    ComplexCase(
        name="abp41_section_margins",
        description="Set explicit page margins",
        script=(
            "from docx.shared import Inches\n"
            "s = doc.sections[0]\n"
            "s.left_margin = Inches(0.5)\n"
            "s.right_margin = Inches(0.75)\n"
            "s.top_margin = Inches(1.25)\n"
            "s.bottom_margin = Inches(1.0)"
        ),
        tags=("ab_probe", "section"),
    ),
]


# Turn 14: combined inline marks on one run.
TURN14_COMBINED_MARKS: list[ComplexCase] = [
    ComplexCase(
        name="abp42_bold_italic_underline",
        description="One run with bold + italic + underline",
        script=(
            "p = doc.add_paragraph()\n"
            "r = p.add_run('triple')\n"
            "r.bold = True\n"
            "r.italic = True\n"
            "r.underline = True"
        ),
        tags=("ab_probe", "combined_marks"),
    ),
    ComplexCase(
        name="abp43_color_size_bold",
        description="One run with color + size + bold",
        script=(
            "from docx.shared import Pt, RGBColor\n"
            "p = doc.add_paragraph()\n"
            "r = p.add_run('big red bold')\n"
            "r.bold = True\n"
            "r.font.size = Pt(18)\n"
            "r.font.color.rgb = RGBColor(0xC0, 0x10, 0x20)"
        ),
        tags=("ab_probe", "combined_marks"),
    ),
]


# Turn 15: insert paragraph before, plus mixed-content paragraphs that
# stress the inline-splitting work from Turn 2.
TURN15_INSERTIONS: list[ComplexCase] = [
    ComplexCase(
        name="abp44_insert_paragraph_before",
        description="paragraph.insert_paragraph_before adds before existing",
        script=(
            "p = doc.add_paragraph('second')\n"
            "p.insert_paragraph_before('first')"
        ),
        tags=("ab_probe", "insertions"),
    ),
    ComplexCase(
        name="abp45_mixed_marks_runs",
        description="Three runs in one paragraph, each with a different mark",
        script=(
            "p = doc.add_paragraph()\n"
            "r1 = p.add_run('bold ')\n"
            "r1.bold = True\n"
            "r2 = p.add_run('italic ')\n"
            "r2.italic = True\n"
            "r3 = p.add_run('underline')\n"
            "r3.underline = True"
        ),
        tags=("ab_probe", "insertions"),
    ),
]


AB_PROBE_CASES: list[ComplexCase] = [
    *TURN1_INDENTS,
    *TURN2_RUN_FORMATTING,
    *TURN3_PARA_FLOW,
    *TURN4_PARA_SPACING,
    *TURN5_ALIGNMENT,
    *TURN6_FONT_BASICS,
    *TURN7_MULTI_PARAGRAPH,
    *TURN8_HEADING_LEVELS,
    *TURN9_TAB_STOPS,
    *TURN10_TEXT_REPLACE,
    *TURN11_EMPTY_EDGES,
    *TURN12_TABLES_BASIC,
    *TURN13_SECTIONS,
    *TURN14_COMBINED_MARKS,
    *TURN15_INSERTIONS,
]
