"""Layer 5 — op-trace snapshot harness.

For each fidelity case, record the exact sequence of Superdoc ops our SDK
emits. Snapshots are saved to `op_snapshots/<case_name>.json` and checked
into git. Regressions (op-sequence drift) show up as a diff against the
snapshot.

Usage:
    # Capture snapshots for all cases (first-time or after intentional changes)
    .venv/bin/python tests/fidelity/op_snapshot.py --update

    # Check current behavior against committed snapshots
    .venv/bin/python tests/fidelity/op_snapshot.py --check
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

_SDK_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_SDK_ROOT))

from tests.fidelity.complex_cases import CASES, ComplexCase  # noqa: E402
from tests.fidelity.extreme_cases import EXTREME_CASES  # noqa: E402
from tests.fidelity.fake_session import install_fake_session  # noqa: E402
from tests.fidelity.mega_cases import MEGA_CASES  # noqa: E402
from tests.fidelity.real_world_cases import REAL_WORLD_CASES  # noqa: E402

_SNAP_DIR = _SDK_ROOT / "tests" / "fidelity" / "op_snapshots"
ALL_CASES = CASES + REAL_WORLD_CASES + EXTREME_CASES + MEGA_CASES


def _run_case(case: ComplexCase) -> tuple[bool, str, list[str]]:
    install_fake_session()
    from docx import Document
    from docx import flush_all
    from docx.shared import Pt, RGBColor  # noqa: F401

    doc = Document("asset_fake")
    try:
        local_ns: dict = {"doc": doc, "RGBColor": RGBColor, "Pt": Pt}
        exec(compile(case.script, f"<case:{case.name}>", "exec"), local_ns, local_ns)
    except Exception as e:  # noqa: BLE001
        return False, f"{type(e).__name__}: {e}", []
    flush_all()
    ops = [op for op, _ in doc._session.calls()]  # type: ignore[attr-defined]
    return True, "", ops


def cmd_update() -> int:
    _SNAP_DIR.mkdir(parents=True, exist_ok=True)
    for case in ALL_CASES:
        ok, err, ops = _run_case(case)
        if not ok:
            print(f"  ⚠️ {case.name}: skipped ({err})")
            continue
        path = _SNAP_DIR / f"{case.name}.json"
        path.write_text(json.dumps(ops, indent=2))
    print(f"[update] wrote {len(ALL_CASES)} snapshots to {_SNAP_DIR}")
    return 0


def cmd_check() -> int:
    if not _SNAP_DIR.exists():
        print("no snapshots — run --update first")
        return 1
    drift = 0
    missing = 0
    pass_count = 0
    for case in ALL_CASES:
        snap_path = _SNAP_DIR / f"{case.name}.json"
        if not snap_path.exists():
            print(f"  ➕ {case.name}: no snapshot (add with --update)")
            missing += 1
            continue
        ok, err, ops = _run_case(case)
        if not ok:
            print(f"  💥 {case.name}: {err}")
            drift += 1
            continue
        expected = json.loads(snap_path.read_text())
        if ops == expected:
            pass_count += 1
        else:
            drift += 1
            print(f"  ❌ {case.name}: op drift")
            # Show first 3 divergences
            for i, (e, g) in enumerate(zip(expected, ops)):
                if e != g:
                    print(f"      idx {i}: expected={e!r} got={g!r}")
                    if i > 5:
                        break
            if len(expected) != len(ops):
                print(f"      length: expected={len(expected)} got={len(ops)}")
    print()
    print(f"snapshot check: {pass_count} clean, {drift} drifted, {missing} missing")
    return 0 if drift == 0 else 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--update", action="store_true")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    if args.update:
        return cmd_update()
    if args.check:
        return cmd_check()
    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
