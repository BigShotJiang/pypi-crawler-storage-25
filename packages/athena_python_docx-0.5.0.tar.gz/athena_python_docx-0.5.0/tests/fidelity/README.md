# Fidelity tests

End-to-end comparison of `athena-python-docx` against stock `python-docx`.
For each test case (a small script using the python-docx API), the runner:

1. Executes the script via **stock `python-docx`** (installed to an
   isolated site-packages at `/tmp/docx-fidelity-stock-site-packages`)
   and saves the resulting `.docx` to `/tmp/docx-fidelity-artifacts/`.
2. Executes the same script via **`athena-python-docx`** inside a
   Daytona sandbox (the `document-exec:v<N>` image). The resulting Y.Doc
   is exported to `.docx` by Superdoc and downloaded back to
   `/tmp/docx-fidelity-artifacts/`.
3. Reads both `.docx` files back with stock `python-docx` and extracts a
   normalized feature set (paragraph text + style, runs + bold/italic/
   underline/color, table row/col counts + cell texts).
4. Compares the feature sets and prints a scorecard.

Stylistic differences that stem from the two libraries' different default
templates (font, margins, theme colors) are intentionally ignored — the
focus is on the content-level operations an agent actually cares about.

## Running

```bash
cd agora && infisical run -- \
    uv run python \
    "$(git rev-parse --show-toplevel)/docx-studio/python-sdk/tests/fidelity/runner.py"
```

Configuration via env vars:

| Var | Default | Purpose |
|-----|---------|---------|
| `ATHENA_DOCX_FIDELITY_ASSET_ID` | `asset_de593a96-…-2b16ad` (existing staging test doc) | SuperDoc asset to write against — contents are cleared via `doc.clear_content()` between cases |
| `DAYTONA_DOCUMENT_EXEC_SNAPSHOT` | `document-exec:v1` (from agora settings) | Snapshot to spin up |

## Interpreting results

| Status | Meaning |
|---|---|
| `✅ OK` | Athena script succeeded and content matches stock python-docx |
| `⚠️ DIFF` | Athena script succeeded but content differs — see listed diffs |
| `🟡 STUB_HIT` | Case hit an expected `NotImplementedError` stub (a known Phase-2 gap) |
| `🟠 UNEXPECTED_PASS` | Case was expected to raise a stub error, but didn't — probably means the Phase-2 gap has been filled; re-classify the case |
| `🔴 WRONG_EXC` | Case raised, but the wrong exception type |
| `❌ SCRIPT_ERROR` | Athena side crashed with an unexpected exception |
| `❌ SETUP_ERROR` | Pre-flight `doc.clear_content()` failed |
| `❌ EXPORT_ERROR` | Superdoc couldn't save the Y.Doc to `.docx` |
| `❌ DOWNLOAD_ERROR` | `fs.download_file` on the Daytona sandbox failed |

## Adding cases

Edit `cases.py` and add a `Case(...)` entry. Keep scripts minimal (one
surface per case where possible). If the operation is a known Phase-2
stub, set `expected_athena_exc="NotImplementedError"` so the case is
scored as `STUB_HIT` rather than as a failure.

## Known caveats

- The runner shares **one** SuperDoc asset across all cases, clearing
  content between each via `doc.clear_content()`. If `clear_content`
  ever regresses, every case after the first will be corrupted. The
  runner reports that as `SETUP_ERROR`.
- Stock python-docx's default template pads the document with a trailing
  empty paragraph. The comparator filters empty paragraphs before
  counting, but paragraph indices in diff output are 0-based on the
  non-empty subset only.
- `skip_content_diff=True` on a case tells the runner to only check that
  the athena side didn't raise; useful for structural ops
  (`add_page_break`) where the exported OOXML legitimately differs from
  the stock output.
