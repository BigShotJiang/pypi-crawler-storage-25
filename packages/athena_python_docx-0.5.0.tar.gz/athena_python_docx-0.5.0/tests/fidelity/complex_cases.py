"""Complex python-docx cases to exercise the full SDK surface.

Each CASE is a Python snippet that runs against a pre-bound ``doc`` (a
docx.Document). The same snippet is executed by stock python-docx to
generate a reference .docx and by our SDK against a FakeSession to verify
the surface doesn't blow up.

Cases progressively exercise more complex patterns. Run via
``tests/fidelity/local_runner.py``.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ComplexCase:
    name: str
    description: str
    script: str
    # Operations that should be recorded in the fake session (sub-string match)
    expected_ops: tuple[str, ...] = field(default_factory=tuple)
    tags: tuple[str, ...] = field(default_factory=tuple)


CASES: list[ComplexCase] = [
    # ---------- Level 1: basic surfaces ----------
    ComplexCase(
        name="01_basic_paragraph",
        description="Add a paragraph with text",
        script='doc.add_paragraph("Hello, world.")',
        expected_ops=("create.paragraph",),
        tags=("level1",),
    ),
    ComplexCase(
        name="02_multiple_headings",
        description="Headings at all levels",
        script='\n'.join(f'doc.add_heading("H{i}", level={i})' for i in range(0, 6)),
        expected_ops=("create.heading", "create.paragraph"),
        tags=("level1", "heading"),
    ),
    ComplexCase(
        name="03_runs_with_formatting",
        description="Multiple runs with bold/italic/underline",
        script=(
            "p = doc.add_paragraph()\n"
            'r1 = p.add_run("bold")\n'
            "r1.bold = True\n"
            'r2 = p.add_run(" + ")\n'
            'r3 = p.add_run("italic")\n'
            "r3.italic = True\n"
            'r4 = p.add_run(" + ")\n'
            'r5 = p.add_run("underline")\n'
            "r5.underline = True"
        ),
        expected_ops=("create.paragraph", "insert", "format.apply"),
        tags=("level1", "run"),
    ),

    # ---------- Level 2: font + color ----------
    ComplexCase(
        name="04_font_name_and_size",
        description="Font name and size (pt)",
        script=(
            "from docx.shared import Pt\n"
            "p = doc.add_paragraph()\n"
            'r = p.add_run("Arial 14pt")\n'
            'r.font.name = "Arial"\n'
            "r.font.size = Pt(14)"
        ),
        expected_ops=("format.apply",),
        tags=("level2", "font"),
    ),
    ComplexCase(
        name="05_font_color_rgb",
        description="RGBColor applied to run",
        script=(
            "from docx.shared import RGBColor\n"
            "p = doc.add_paragraph()\n"
            'r = p.add_run("red")\n'
            "r.font.color.rgb = RGBColor(0xFF, 0x00, 0x00)"
        ),
        expected_ops=("format.apply",),
        tags=("level2", "color"),
    ),
    ComplexCase(
        name="06_font_character_properties",
        description="strike, all_caps, small_caps, shadow",
        script=(
            "p = doc.add_paragraph()\n"
            'r = p.add_run("fancy")\n'
            "r.font.strike = True\n"
            "r.font.all_caps = True\n"
            "r.font.small_caps = True\n"
            "r.font.shadow = True\n"
            "r.font.outline = True\n"
            "r.font.emboss = True"
        ),
        expected_ops=("format.apply",),
        tags=("level2", "font"),
    ),
    ComplexCase(
        name="07_font_subscript_superscript",
        description="subscript and superscript",
        script=(
            "p = doc.add_paragraph()\n"
            'sub = p.add_run("2")\n'
            "sub.font.subscript = True\n"
            'sup = p.add_run("10")\n'
            "sup.font.superscript = True"
        ),
        expected_ops=("format.apply",),
        tags=("level2", "font"),
    ),
    ComplexCase(
        name="08_font_highlight",
        description="Highlight color from WD_COLOR_INDEX",
        script=(
            "from docx.enum.text import WD_COLOR_INDEX\n"
            "p = doc.add_paragraph()\n"
            'r = p.add_run("highlighted")\n'
            "r.font.highlight_color = WD_COLOR_INDEX.YELLOW"
        ),
        expected_ops=("format.apply",),
        tags=("level2", "font"),
    ),

    # ---------- Level 3: paragraph format ----------
    ComplexCase(
        name="09_paragraph_alignment",
        description="Paragraph alignment via WD_ALIGN_PARAGRAPH",
        script=(
            "from docx.enum.text import WD_ALIGN_PARAGRAPH\n"
            'p = doc.add_paragraph("centered")\n'
            "p.alignment = WD_ALIGN_PARAGRAPH.CENTER"
        ),
        expected_ops=("format.paragraph.setAlignment",),
        tags=("level3", "paragraph"),
    ),
    ComplexCase(
        name="10_paragraph_indents",
        description="Left / right / first line indents",
        script=(
            "from docx.shared import Inches\n"
            'p = doc.add_paragraph("indented")\n'
            "pf = p.paragraph_format\n"
            "pf.left_indent = Inches(0.5)\n"
            "pf.right_indent = Inches(0.25)\n"
            "pf.first_line_indent = Inches(0.25)"
        ),
        expected_ops=("format.paragraph.setIndentation",),
        tags=("level3", "paragraph"),
    ),
    ComplexCase(
        name="11_paragraph_spacing",
        description="Space before / after and line spacing",
        script=(
            "from docx.shared import Pt\n"
            "from docx.enum.text import WD_LINE_SPACING\n"
            'p = doc.add_paragraph("spaced")\n'
            "pf = p.paragraph_format\n"
            "pf.space_before = Pt(12)\n"
            "pf.space_after = Pt(6)\n"
            "pf.line_spacing = 1.5\n"
            "pf.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE"
        ),
        expected_ops=("format.paragraph.setSpacing",),
        tags=("level3", "paragraph"),
    ),
    ComplexCase(
        name="12_paragraph_keep_options",
        description="keep_together, keep_with_next, widow_control, page_break_before",
        script=(
            'p = doc.add_paragraph("keep together")\n'
            "pf = p.paragraph_format\n"
            "pf.keep_together = True\n"
            "pf.keep_with_next = True\n"
            "pf.widow_control = True\n"
            "pf.page_break_before = False"
        ),
        expected_ops=(
            "format.paragraph.setKeepOptions",
            "format.paragraph.setFlowOptions",
        ),
        tags=("level3", "paragraph"),
    ),
    ComplexCase(
        name="13_paragraph_tab_stops",
        description="Add tab stops via paragraph_format.tab_stops",
        script=(
            "from docx.shared import Inches\n"
            "from docx.enum.text import WD_TAB_ALIGNMENT, WD_TAB_LEADER\n"
            "p = doc.add_paragraph()\n"
            "pf = p.paragraph_format\n"
            "pf.tab_stops.add_tab_stop(Inches(1), WD_TAB_ALIGNMENT.LEFT, WD_TAB_LEADER.DOTS)\n"
            "pf.tab_stops.add_tab_stop(Inches(3), WD_TAB_ALIGNMENT.DECIMAL)"
        ),
        expected_ops=("format.paragraph.setTabStop",),
        tags=("level3", "paragraph"),
    ),

    # ---------- Level 4: runs — tabs, breaks, pictures ----------
    ComplexCase(
        name="14_run_add_tab_and_break",
        description="run.add_tab() and run.add_break()",
        script=(
            "p = doc.add_paragraph()\n"
            'r = p.add_run("before")\n'
            "r.add_tab()\n"
            'r.add_text("after tab")\n'
            "r.add_break()\n"
            'r.add_text("on new line")'
        ),
        expected_ops=("insertTab", "insertLineBreak"),
        tags=("level4", "run"),
    ),
    ComplexCase(
        name="15_run_add_break_page",
        description="page break from run.add_break(WD_BREAK.PAGE)",
        script=(
            "from docx.enum.text import WD_BREAK\n"
            "p = doc.add_paragraph()\n"
            'r = p.add_run("before page break")\n'
            "r.add_break(WD_BREAK.PAGE)"
        ),
        expected_ops=("insert",),
        tags=("level4", "run"),
    ),
    ComplexCase(
        name="16_paragraph_clear_and_insert_before",
        description="paragraph.clear() and insert_paragraph_before()",
        script=(
            'p = doc.add_paragraph("first")\n'
            'q = doc.add_paragraph("second")\n'
            "q.clear()\n"
            'q.insert_paragraph_before("inserted before q")'
        ),
        expected_ops=("create.paragraph",),
        tags=("level4", "paragraph"),
    ),

    # ---------- Level 5: tables ----------
    ComplexCase(
        name="17_table_basic",
        description="Create 3x3 table with TableGrid style",
        script='t = doc.add_table(rows=3, cols=3, style="TableGrid")',
        expected_ops=("create.table", "tables.setStyle"),
        tags=("level5", "table"),
    ),
    ComplexCase(
        name="18_table_cell_text",
        description="Populate cell text",
        script=(
            "t = doc.add_table(rows=2, cols=3)\n"
            'headers = ["Name", "Value", "Status"]\n'
            "for i, h in enumerate(headers):\n"
            "    t.cell(0, i).text = h\n"
            't.cell(1, 0).text = "Alice"\n'
            't.cell(1, 1).text = "42"\n'
            't.cell(1, 2).text = "OK"'
        ),
        expected_ops=("tables.getCells", "getNodeById", "replace"),
        tags=("level5", "table"),
    ),
    ComplexCase(
        name="19_table_row_column_sizing",
        description="Row heights and column widths",
        script=(
            "from docx.shared import Pt, Inches\n"
            "from docx.enum.table import WD_ROW_HEIGHT_RULE\n"
            "t = doc.add_table(rows=3, cols=3)\n"
            "t.rows[0].height = Pt(24)\n"
            "t.rows[0].height_rule = WD_ROW_HEIGHT_RULE.EXACTLY\n"
            "t.columns[0].width = Inches(1.5)\n"
            "t.columns[1].width = Inches(1)\n"
            "t.columns[2].width = Inches(1.5)"
        ),
        expected_ops=("tables.setRowHeight", "tables.setColumnWidth"),
        tags=("level5", "table"),
    ),
    ComplexCase(
        name="20_table_cell_vertical_alignment",
        description="Cell vertical alignment via WD_ALIGN_VERTICAL",
        script=(
            "from docx.enum.table import WD_ALIGN_VERTICAL\n"
            "t = doc.add_table(rows=2, cols=2)\n"
            "t.cell(0, 0).vertical_alignment = WD_ALIGN_VERTICAL.TOP\n"
            "t.cell(0, 1).vertical_alignment = WD_ALIGN_VERTICAL.CENTER\n"
            "t.cell(1, 0).vertical_alignment = WD_ALIGN_VERTICAL.BOTTOM"
        ),
        expected_ops=("tables.setCellProperties",),
        tags=("level5", "table"),
    ),
    ComplexCase(
        name="21_table_alignment_and_autofit",
        description="Table-level alignment, autofit, direction",
        script=(
            "from docx.enum.table import WD_TABLE_ALIGNMENT, WD_TABLE_DIRECTION\n"
            "t = doc.add_table(rows=2, cols=2)\n"
            "t.alignment = WD_TABLE_ALIGNMENT.CENTER\n"
            "t.direction = WD_TABLE_DIRECTION.LTR\n"
            "t.autofit = True"
        ),
        expected_ops=("tables.setTableOptions", "tables.setLayout"),
        tags=("level5", "table"),
    ),
    ComplexCase(
        name="22_table_cell_paragraphs_iteration",
        description="Iterate cell.paragraphs and add more",
        script=(
            "t = doc.add_table(rows=1, cols=1)\n"
            "c = t.cell(0, 0)\n"
            'c.text = "first paragraph"\n'
            'p2 = c.add_paragraph("second paragraph")\n'
            "for p in c.paragraphs:\n"
            "    _ = p.text"
        ),
        expected_ops=("tables.getCells", "create.paragraph"),
        tags=("level5", "table"),
    ),
    ComplexCase(
        name="23_nested_table",
        description="Add a nested table inside a cell",
        script=(
            "outer = doc.add_table(rows=1, cols=1)\n"
            "cell = outer.cell(0, 0)\n"
            "nested = cell.add_table(rows=2, cols=2)\n"
            'nested.cell(0, 0).text = "nested"'
        ),
        expected_ops=("create.table",),
        tags=("level5", "table", "nested"),
    ),
    ComplexCase(
        name="24_table_add_row_column",
        description="Add row and column dynamically (python-docx 1.x requires width for add_column)",
        script=(
            "from docx.shared import Inches\n"
            "t = doc.add_table(rows=2, cols=2)\n"
            "new_row = t.add_row()\n"
            'new_row.cells[0].text = "new row"\n'
            "new_col = t.add_column(Inches(1))\n"
            "assert len(t.columns) == 3"
        ),
        expected_ops=("tables.insertRow", "tables.insertColumn"),
        tags=("level5", "table"),
    ),
    ComplexCase(
        name="25_table_merge_cells",
        description="Merge adjacent cells",
        script=(
            "t = doc.add_table(rows=2, cols=3)\n"
            "a = t.cell(0, 0)\n"
            "b = t.cell(0, 2)\n"
            "a.merge(b)"
        ),
        expected_ops=("tables.mergeCells",),
        tags=("level5", "table"),
    ),

    # ---------- Level 6: sections ----------
    ComplexCase(
        name="26_section_page_setup",
        description="Set page size and orientation on the first section",
        script=(
            "from docx.shared import Inches\n"
            "from docx.enum.section import WD_ORIENTATION\n"
            "section = doc.sections[0]\n"
            "section.page_width = Inches(11)\n"
            "section.page_height = Inches(8.5)\n"
            "section.orientation = WD_ORIENTATION.LANDSCAPE"
        ),
        expected_ops=("sections.setPageSetup",),
        tags=("level6", "section"),
    ),
    ComplexCase(
        name="27_section_margins",
        description="Set all four page margins",
        script=(
            "from docx.shared import Inches\n"
            "s = doc.sections[0]\n"
            "s.top_margin = Inches(0.5)\n"
            "s.bottom_margin = Inches(0.5)\n"
            "s.left_margin = Inches(0.75)\n"
            "s.right_margin = Inches(0.75)"
        ),
        expected_ops=("sections.setPageMargins",),
        tags=("level6", "section"),
    ),
    ComplexCase(
        name="28_section_add_new",
        description="Add a new section with continuous break",
        script=(
            "from docx.enum.section import WD_SECTION_START\n"
            "doc.add_section(WD_SECTION_START.CONTINUOUS)"
        ),
        expected_ops=("create.sectionBreak",),
        tags=("level6", "section"),
    ),
    ComplexCase(
        name="29_section_headers_linked",
        description="Configure header/footer linking and first-page",
        script=(
            "s = doc.sections[0]\n"
            "s.different_first_page_header_footer = True\n"
            "s.header.is_linked_to_previous = False"
        ),
        expected_ops=("sections.setTitlePage",),
        tags=("level6", "section"),
    ),

    # ---------- Level 7: styles ----------
    ComplexCase(
        name="30_styles_iteration",
        description="Iterate over doc.styles",
        script=(
            "styles = doc.styles\n"
            "names = [s.name for s in styles]\n"
            "assert len(names) > 0, names"
        ),
        tags=("level7", "styles"),
    ),
    ComplexCase(
        name="31_styles_lookup_and_default",
        description="Look up a style by name and get default",
        script=(
            "from docx.enum.style import WD_STYLE_TYPE\n"
            'normal = doc.styles["Normal"]\n'
            'heading1 = doc.styles["Heading 1"]\n'
            "default_p = doc.styles.default(WD_STYLE_TYPE.PARAGRAPH)\n"
            'assert normal.name == "Normal"\n'
            'assert heading1.name == "Heading 1"'
        ),
        tags=("level7", "styles"),
    ),
    ComplexCase(
        name="32_styles_add_paragraph_style",
        description="add_style for a custom paragraph style",
        script=(
            "from docx.enum.style import WD_STYLE_TYPE\n"
            'custom = doc.styles.add_style("Custom", WD_STYLE_TYPE.PARAGRAPH)\n'
            'assert custom.name == "Custom"'
        ),
        tags=("level7", "styles"),
    ),

    # ---------- Level 8: core properties ----------
    ComplexCase(
        name="33_core_properties_set_and_get",
        description="Set / get core properties",
        script=(
            "import datetime\n"
            "cp = doc.core_properties\n"
            'cp.author = "Bob"\n'
            'cp.title = "My Doc"\n'
            "cp.created = datetime.datetime(2024, 1, 1)\n"
            'assert cp.author == "Bob"\n'
            'assert cp.title == "My Doc"'
        ),
        tags=("level8", "metadata"),
    ),

    # ---------- Level 9: inline shapes ----------
    ComplexCase(
        name="34_inline_shapes_iterate_empty",
        description="Iterate inline_shapes (empty collection)",
        script=(
            "shapes = doc.inline_shapes\n"
            "assert len(shapes) == 0"
        ),
        expected_ops=("images.list",),
        tags=("level9", "shapes"),
    ),

    # ---------- Level 10: combined complex doc ----------
    ComplexCase(
        name="35_full_report",
        description=(
            "Full report: title, headings, formatted paragraphs, "
            "a table with styled cells, and set page margins."
        ),
        script=(
            "from docx.shared import Inches, Pt, RGBColor\n"
            "from docx.enum.text import WD_ALIGN_PARAGRAPH\n"
            "from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT\n"
            "\n"
            "# Margins\n"
            "s = doc.sections[0]\n"
            "s.top_margin = Inches(0.75)\n"
            "s.bottom_margin = Inches(0.75)\n"
            "\n"
            "# Title\n"
            'title = doc.add_heading("Quarterly Report", level=0)\n'
            "title.alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            "\n"
            "# Intro paragraph\n"
            'intro = doc.add_paragraph()\n'
            'r_lead = intro.add_run("Executive summary: ")\n'
            "r_lead.bold = True\n"
            'r_body = intro.add_run("Revenue grew ")\n'
            'r_pct = intro.add_run("12.5%")\n'
            "r_pct.bold = True\n"
            "r_pct.font.color.rgb = RGBColor(0x00, 0x66, 0x00)\n"
            'intro.add_run(" year over year, driven by renewals.")\n'
            "intro.paragraph_format.space_after = Pt(12)\n"
            "\n"
            "# Detail section\n"
            'doc.add_heading("Details", level=1)\n'
            "t = doc.add_table(rows=3, cols=3, style=\"TableGrid\")\n"
            "t.alignment = WD_TABLE_ALIGNMENT.CENTER\n"
            "headers = t.rows[0].cells\n"
            'headers[0].text = "Metric"\n'
            'headers[1].text = "Q1"\n'
            'headers[2].text = "Q2"\n'
            "for cell in headers:\n"
            "    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER\n"
            '    cell.paragraphs[0].runs[0].bold = True if cell.paragraphs[0].runs else None\n'
            "rows = [\n"
            '    ("Revenue", "$10M", "$11M"),\n'
            '    ("Customers", "100", "115"),\n'
            "]\n"
            "for i, (m, q1, q2) in enumerate(rows, start=1):\n"
            "    t.cell(i, 0).text = m\n"
            "    t.cell(i, 1).text = q1\n"
            "    t.cell(i, 2).text = q2"
        ),
        tags=("level10", "combo"),
    ),

    # ---------- Level 11: extended paragraph edits ----------
    ComplexCase(
        name="36_replace_text_in_paragraph",
        description="Paragraph.text = 'new value' (full replace)",
        script=(
            'p = doc.add_paragraph("original text")\n'
            'p.text = "replaced text"'
        ),
        expected_ops=("replace",),
        tags=("level11", "paragraph"),
    ),
    ComplexCase(
        name="37_iterate_runs_and_format_all_bold",
        description="p.runs iteration + set bold on each",
        script=(
            'p = doc.add_paragraph("first ")\n'
            'p.add_run("second ")\n'
            'p.add_run("third")\n'
            "for r in p.runs:\n"
            "    r.bold = True"
        ),
        expected_ops=("getNodeById", "format.apply"),
        tags=("level11", "run"),
    ),

    # ---------- Level 12: thorough font coverage ----------
    # ---------- Level 13: large documents ----------
    ComplexCase(
        name="39_large_body_100_paragraphs",
        description="Add 100 plain paragraphs",
        script=(
            "for i in range(100):\n"
            '    doc.add_paragraph(f"Paragraph {i}: lorem ipsum dolor sit amet.")'
        ),
        expected_ops=("create.paragraph",),
        tags=("level13", "large"),
    ),
    ComplexCase(
        name="40_large_table_10x10",
        description="Populate a 10x10 table",
        script=(
            "t = doc.add_table(rows=10, cols=10)\n"
            "for r in range(10):\n"
            "    for c in range(10):\n"
            '        t.cell(r, c).text = f"r{r}c{c}"'
        ),
        expected_ops=("create.table", "replace"),
        tags=("level13", "large", "table"),
    ),
    ComplexCase(
        name="41_unicode_and_emoji",
        description="Unicode and emoji text",
        script=(
            'doc.add_paragraph("Hello 世界 🌍")\n'
            'doc.add_paragraph("русский текст")\n'
            'doc.add_paragraph("العربية")\n'
            'doc.add_paragraph("日本語テキスト")'
        ),
        tags=("level13", "unicode"),
    ),
    ComplexCase(
        name="42_very_long_paragraph",
        description="Single paragraph with 10_000 chars",
        script=(
            'doc.add_paragraph("x" * 10000)'
        ),
        tags=("level13", "large"),
    ),

    # ---------- Level 14: round trips ----------
    ComplexCase(
        name="43_paragraph_text_round_trip",
        description="Set text and verify .text getter returns it",
        script=(
            'p = doc.add_paragraph("round trip")\n'
            'assert p.text == "round trip", p.text'
        ),
        tags=("level14", "round_trip"),
    ),
    ComplexCase(
        name="44_paragraph_alignment_round_trip",
        description="Set alignment and read it back",
        script=(
            "from docx.enum.text import WD_ALIGN_PARAGRAPH\n"
            'p = doc.add_paragraph("x")\n'
            "p.alignment = WD_ALIGN_PARAGRAPH.RIGHT\n"
            "assert p.alignment == WD_ALIGN_PARAGRAPH.RIGHT, p.alignment"
        ),
        tags=("level14", "round_trip"),
    ),
    ComplexCase(
        name="45_cell_text_round_trip",
        description="Set cell.text, read it back",
        script=(
            "t = doc.add_table(rows=1, cols=1)\n"
            't.cell(0, 0).text = "cell body"\n'
            'assert t.cell(0, 0).text == "cell body", t.cell(0, 0).text'
        ),
        tags=("level14", "round_trip", "table"),
    ),
    ComplexCase(
        name="46_run_text_setter_round_trip",
        description="Run.text setter re-reads back",
        script=(
            "p = doc.add_paragraph()\n"
            'r = p.add_run("initial")\n'
            'r.text = "final"\n'
            'assert r.text == "final", r.text'
        ),
        tags=("level14", "round_trip", "run"),
    ),
    ComplexCase(
        name="47_font_size_round_trip",
        description="Set font.size and read it back",
        script=(
            "from docx.shared import Pt\n"
            "p = doc.add_paragraph()\n"
            'r = p.add_run("test")\n'
            "r.font.size = Pt(18)\n"
            "got = r.font.size\n"
            'assert got is not None, "size getter returned None"\n'
            'assert abs(float(got.pt) - 18.0) < 0.01, got.pt'
        ),
        tags=("level14", "round_trip", "font"),
    ),
    ComplexCase(
        name="48_font_color_round_trip",
        description="Set font.color.rgb and read it back",
        script=(
            "from docx.shared import RGBColor\n"
            "p = doc.add_paragraph()\n"
            'r = p.add_run("test")\n'
            "r.font.color.rgb = RGBColor(0x12, 0x34, 0x56)\n"
            "got = r.font.color.rgb\n"
            'assert got is not None\n'
            'assert str(got) == "123456", str(got)'
        ),
        tags=("level14", "round_trip", "color"),
    ),

    # ---------- Level 15: resume patterns ----------
    ComplexCase(
        name="49_resume_layout",
        description=(
            "Build a small resume: title, contact info, experience section "
            "with bullet-style paragraphs, education, skills table."
        ),
        script=(
            "from docx.shared import Pt, Inches, RGBColor\n"
            "from docx.enum.text import WD_ALIGN_PARAGRAPH\n"
            "\n"
            "# Title\n"
            'title = doc.add_heading("Jane Doe", level=0)\n'
            "title.alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            "\n"
            "# Contact\n"
            "contact = doc.add_paragraph()\n"
            "contact.alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            'contact.add_run("jane@example.com | 555-1212 | San Francisco, CA")\n'
            "\n"
            "# Experience\n"
            'doc.add_heading("Experience", level=1)\n'
            "exp_jobs = [\n"
            '    ("Senior Engineer", "Acme Inc.", "2020 — Present"),\n'
            '    ("Software Engineer", "Widgets Co.", "2017 — 2020"),\n'
            "]\n"
            "for title_text, company, dates in exp_jobs:\n"
            "    heading = doc.add_paragraph()\n"
            "    r_t = heading.add_run(title_text)\n"
            "    r_t.bold = True\n"
            '    heading.add_run(f", {company}")\n'
            "    date_p = doc.add_paragraph()\n"
            "    date_r = date_p.add_run(dates)\n"
            "    date_r.italic = True\n"
            '    doc.add_paragraph("Led a team of engineers to deliver reliable products.")\n'
            "\n"
            "# Skills as a table\n"
            'doc.add_heading("Skills", level=1)\n'
            "t = doc.add_table(rows=1, cols=3, style=\"TableGrid\")\n"
            'cats = [("Languages", "Python, Go"), ("Frameworks", "Django, FastAPI"), ("Cloud", "AWS, GCP")]\n'
            "for i, (cat, items) in enumerate(cats):\n"
            "    t.cell(0, i).text = f\"{cat}: {items}\""
        ),
        tags=("level15", "combo", "large"),
    ),

    # ---------- Level 16: multi-section docs ----------
    ComplexCase(
        name="50_multi_section_doc",
        description="Create a doc with multiple sections, different page layouts",
        script=(
            "from docx.shared import Inches\n"
            "from docx.enum.section import WD_SECTION_START, WD_ORIENTATION\n"
            "\n"
            "# First section (portrait)\n"
            "s1 = doc.sections[0]\n"
            "s1.orientation = WD_ORIENTATION.PORTRAIT\n"
            "s1.page_width = Inches(8.5)\n"
            "s1.page_height = Inches(11)\n"
            'doc.add_heading("Portrait Section", level=1)\n'
            'doc.add_paragraph("Body text on portrait page.")\n'
            "\n"
            "# Landscape section\n"
            "s2 = doc.add_section(WD_SECTION_START.NEW_PAGE)\n"
            "s2.orientation = WD_ORIENTATION.LANDSCAPE\n"
            "s2.page_width = Inches(11)\n"
            "s2.page_height = Inches(8.5)\n"
            'doc.add_heading("Landscape Section", level=1)\n'
            'doc.add_paragraph("Body text on landscape page.")\n'
            "\n"
            "# Continuous section\n"
            "s3 = doc.add_section(WD_SECTION_START.CONTINUOUS)\n"
            'doc.add_paragraph("Continuous after landscape.")'
        ),
        tags=("level16", "section"),
    ),

    # ---------- Level 17: deep nesting + iteration ----------
    ComplexCase(
        name="51_nested_tables_deep",
        description="Table in cell that contains another table in a cell",
        script=(
            "outer = doc.add_table(rows=1, cols=1)\n"
            "mid = outer.cell(0, 0).add_table(rows=1, cols=1)\n"
            "inner = mid.cell(0, 0).add_table(rows=2, cols=2)\n"
            'inner.cell(0, 0).text = "deepest"'
        ),
        tags=("level17", "nested"),
    ),
    ComplexCase(
        name="52_iterate_everything",
        description="Create a doc then iterate sections/paragraphs/tables",
        script=(
            "from docx.shared import Inches\n"
            'doc.add_heading("Intro", level=1)\n'
            "for i in range(5):\n"
            "    doc.add_paragraph(f\"Body {i}\")\n"
            "doc.add_table(rows=2, cols=2)\n"
            "doc.add_table(rows=3, cols=3)\n"
            "\n"
            "# Read-only iteration\n"
            "para_count = len(doc.paragraphs)\n"
            "table_count = len(doc.tables)\n"
            "section_count = len(doc.sections)\n"
            'assert para_count >= 6, para_count\n'
            'assert table_count == 2, table_count\n'
            'assert section_count >= 1, section_count'
        ),
        tags=("level17", "iteration"),
    ),

    # ---------- Level 18: style manipulation ----------
    ComplexCase(
        name="53_apply_style_to_paragraphs",
        description="Apply Heading and Normal styles to paragraphs",
        script=(
            'p1 = doc.add_paragraph("Section heading")\n'
            'p1.style = "Heading 1"\n'
            'p2 = doc.add_paragraph("Body text")\n'
            'p2.style = "Normal"\n'
            'p3 = doc.add_paragraph("Quoted text")\n'
            'p3.style = "Heading 2"\n'
            'assert p1.style.name in ("Heading 1", "Normal"), p1.style.name  # round-trip via .name'
        ),
        expected_ops=("styles.paragraph.setStyle",),
        tags=("level18", "styles"),
    ),

    # ---------- Level 19: edge cases ----------
    ComplexCase(
        name="54_empty_everything",
        description="Empty paragraphs and empty runs",
        script=(
            'doc.add_paragraph("")\n'
            "p = doc.add_paragraph()\n"
            'p.add_run("")\n'
            'p.add_run("")'
        ),
        tags=("level19", "edge"),
    ),
    ComplexCase(
        name="55_single_character_runs",
        description="Many single-character runs with varied formatting",
        script=(
            "p = doc.add_paragraph()\n"
            "for i, ch in enumerate('HELLO'):\n"
            "    r = p.add_run(ch)\n"
            "    if i % 2 == 0:\n"
            "        r.bold = True\n"
            "    else:\n"
            "        r.italic = True"
        ),
        tags=("level19", "edge", "run"),
    ),

    # ---------- Level 20: comprehensive end-to-end ----------
    ComplexCase(
        name="56_everything_in_one",
        description=(
            "Single kitchen-sink doc: headings, styled paragraphs, formatted runs, "
            "tab stops, page breaks, a table with merged cells and custom row/col sizing, "
            "and section margins. Mimics a polished business report."
        ),
        script=(
            "from docx.shared import Inches, Pt, RGBColor\n"
            "from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_TAB_ALIGNMENT, WD_TAB_LEADER\n"
            "from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT\n"
            "from docx.enum.section import WD_ORIENTATION\n"
            "\n"
            "# Page layout\n"
            "s = doc.sections[0]\n"
            "s.top_margin = Inches(0.75)\n"
            "s.bottom_margin = Inches(0.75)\n"
            "s.left_margin = Inches(1)\n"
            "s.right_margin = Inches(1)\n"
            "s.orientation = WD_ORIENTATION.PORTRAIT\n"
            "\n"
            "# Cover page\n"
            'title = doc.add_heading("Quarterly Business Review", level=0)\n'
            "title.alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            "subtitle = doc.add_paragraph()\n"
            "subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            'sub_r = subtitle.add_run("Q4 2025")\n'
            "sub_r.font.size = Pt(14)\n"
            "sub_r.italic = True\n"
            "\n"
            "# Page break to next page\n"
            "break_p = doc.add_paragraph()\n"
            "break_p.add_run().add_break(WD_BREAK.PAGE)\n"
            "\n"
            "# Executive summary\n"
            'doc.add_heading("Executive Summary", level=1)\n'
            "summary = doc.add_paragraph()\n"
            "lead = summary.add_run(\"Revenue grew \")\n"
            'lead_color = summary.add_run("25%")\n'
            "lead_color.bold = True\n"
            "lead_color.font.color.rgb = RGBColor(0x00, 0x80, 0x00)\n"
            'summary.add_run(" year-over-year, exceeding expectations.")\n'
            "summary.paragraph_format.space_after = Pt(12)\n"
            "\n"
            "# Table of key metrics\n"
            'doc.add_heading("Key Metrics", level=2)\n'
            "t = doc.add_table(rows=4, cols=3, style=\"TableGrid\")\n"
            "t.alignment = WD_TABLE_ALIGNMENT.CENTER\n"
            "\n"
            "# Header row formatting\n"
            "for i, h in enumerate(['Metric', 'Q3', 'Q4']):\n"
            "    cell = t.cell(0, i)\n"
            "    cell.text = h\n"
            "    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER\n"
            "\n"
            "# Data\n"
            "metrics = [\n"
            "    ('Revenue', '$8M', '$10M'),\n"
            "    ('Customers', '500', '625'),\n"
            "    ('NPS', '42', '55'),\n"
            "]\n"
            "for i, (m, a, b) in enumerate(metrics, start=1):\n"
            "    t.cell(i, 0).text = m\n"
            "    t.cell(i, 1).text = a\n"
            "    t.cell(i, 2).text = b\n"
            "\n"
            "# Column widths\n"
            "t.columns[0].width = Inches(2)\n"
            "t.columns[1].width = Inches(1.5)\n"
            "t.columns[2].width = Inches(1.5)\n"
            "\n"
            "# Closing statement\n"
            'doc.add_heading("Outlook", level=1)\n'
            "outlook = doc.add_paragraph()\n"
            "outlook.paragraph_format.first_line_indent = Inches(0.25)\n"
            'outlook.add_run("We expect continued growth into 2026.")'
        ),
        tags=("level20", "kitchen_sink"),
    ),

    # ---------- Level 21: deep run iteration after mutations ----------
    ComplexCase(
        name="57_runs_after_multiple_text_appends",
        description="Verify p.runs reflects each add_run's text properly",
        script=(
            "p = doc.add_paragraph()\n"
            'r1 = p.add_run("abc")\n'
            'r2 = p.add_run("def")\n'
            'r3 = p.add_run("ghi")\n'
            "rs = p.runs\n"
            'assert len(rs) >= 1, rs\n'
            'assert "".join(r.text for r in rs) == "abcdefghi", [r.text for r in rs]'
        ),
        tags=("level21", "run", "iteration"),
    ),
    ComplexCase(
        name="58_modify_runs_in_place",
        description="Iterate runs and mutate their text in place",
        script=(
            "p = doc.add_paragraph()\n"
            "for word in ('Hello', ' ', 'world'):\n"
            "    p.add_run(word)\n"
            "runs = p.runs\n"
            "for r in runs:\n"
            "    r.bold = True\n"
            "    if r.text.strip():\n"
            "        r.italic = True"
        ),
        tags=("level21", "run", "iteration"),
    ),

    # ---------- Level 22: paragraph_format round trips ----------
    ComplexCase(
        name="59_indent_round_trip",
        description="Set indent and read it back",
        script=(
            "from docx.shared import Twips\n"
            'p = doc.add_paragraph("indented")\n'
            "p.paragraph_format.left_indent = Twips(720)\n"
            "v = p.paragraph_format.left_indent\n"
            'assert v is not None, "indent getter returned None"\n'
            'assert v.twips == 720, v.twips'
        ),
        tags=("level22", "round_trip", "paragraph"),
    ),
    ComplexCase(
        name="60_space_round_trip",
        description="Set and read space_before / space_after",
        script=(
            "from docx.shared import Twips, Pt\n"
            'p = doc.add_paragraph("x")\n'
            "p.paragraph_format.space_before = Pt(12)\n"
            "p.paragraph_format.space_after = Pt(6)\n"
            "sb = p.paragraph_format.space_before\n"
            "sa = p.paragraph_format.space_after\n"
            'assert sb is not None and abs(sb.pt - 12.0) < 0.5, sb\n'
            'assert sa is not None and abs(sa.pt - 6.0) < 0.5, sa'
        ),
        tags=("level22", "round_trip", "paragraph"),
    ),

    # ---------- Level 23: cell paragraphs with complex formatting ----------
    ComplexCase(
        name="61_cell_paragraph_with_runs",
        description="Style runs inside a cell paragraph",
        script=(
            "from docx.shared import RGBColor\n"
            "t = doc.add_table(rows=1, cols=1)\n"
            "cell = t.cell(0, 0)\n"
            'cell.text = "Label: "\n'
            "# Get the cell's first paragraph and add more runs\n"
            "cell_p = cell.paragraphs[0]\n"
            'r_val = cell_p.add_run("42")\n'
            "r_val.bold = True\n"
            "r_val.font.color.rgb = RGBColor(0x80, 0x00, 0x80)"
        ),
        tags=("level23", "table", "combo"),
    ),
    ComplexCase(
        name="62_many_cell_paragraphs",
        description="Add many paragraphs to a cell",
        script=(
            "t = doc.add_table(rows=1, cols=1)\n"
            "c = t.cell(0, 0)\n"
            "for i in range(5):\n"
            "    c.add_paragraph(f\"line {i}\")\n"
            "assert len(c.paragraphs) >= 1"
        ),
        tags=("level23", "table"),
    ),

    # ---------- Level 24: table styles reapplied ----------
    ComplexCase(
        name="63_table_style_round_trip",
        description="Set Table.style then read it back",
        script=(
            "t = doc.add_table(rows=2, cols=2, style=\"TableGrid\")\n"
            "t.style = \"Light Shading\"\n"
            "got = t.style\n"
            'assert got is not None, got'
        ),
        tags=("level24", "table", "style"),
    ),

    # ---------- Level 25: many sections ----------
    ComplexCase(
        name="64_many_sections",
        description="Create 5 sections alternating orientation",
        script=(
            "from docx.shared import Inches\n"
            "from docx.enum.section import WD_SECTION_START, WD_ORIENTATION\n"
            "s0 = doc.sections[0]\n"
            "s0.orientation = WD_ORIENTATION.PORTRAIT\n"
            "for i in range(4):\n"
            "    s = doc.add_section(WD_SECTION_START.NEW_PAGE)\n"
            "    if i % 2 == 0:\n"
            "        s.orientation = WD_ORIENTATION.LANDSCAPE\n"
            "    else:\n"
            "        s.orientation = WD_ORIENTATION.PORTRAIT\n"
            "    s.left_margin = Inches(0.5 + 0.1 * i)\n"
            "    s.right_margin = Inches(0.5)"
        ),
        tags=("level25", "section"),
    ),

    # ---------- Level 26: very tall + very wide tables ----------
    ComplexCase(
        name="65_20x20_table_formatted",
        description="20x20 grid with alternating bold cells",
        script=(
            "t = doc.add_table(rows=20, cols=20, style=\"TableGrid\")\n"
            "for r in range(20):\n"
            "    for c in range(20):\n"
            "        cell = t.cell(r, c)\n"
            "        cell.text = f\"{r},{c}\"\n"
            "        if (r + c) % 2 == 0:\n"
            "            cell.paragraphs[0].runs[0].bold = True if cell.paragraphs[0].runs else None"
        ),
        tags=("level26", "large", "table"),
    ),

    # ---------- Level 27: headings + TOC-like sections ----------
    ComplexCase(
        name="66_toc_like_structure",
        description="10 chapters with headings and body text",
        script=(
            "from docx.enum.text import WD_ALIGN_PARAGRAPH\n"
            "for chapter in range(1, 11):\n"
            "    h = doc.add_heading(f\"Chapter {chapter}\", level=1)\n"
            "    h.alignment = WD_ALIGN_PARAGRAPH.LEFT\n"
            "    for section in range(1, 4):\n"
            "        doc.add_heading(f\"{chapter}.{section} Section\", level=2)\n"
            "        doc.add_paragraph(\"Lorem ipsum dolor sit amet.\" * 3)"
        ),
        tags=("level27", "large"),
    ),

    # ---------- Level 28: cell insert_paragraph_before semantics ----------
    ComplexCase(
        name="67_paragraph_insert_before_chain",
        description="Chain insert_paragraph_before calls",
        script=(
            'last = doc.add_paragraph("last")\n'
            "for i in range(4, 0, -1):\n"
            "    last = last.insert_paragraph_before(f\"p{i}\")\n"
            "assert len(doc.paragraphs) >= 5"
        ),
        tags=("level28", "paragraph"),
    ),

    # ---------- Level 29: complex mixed workflows ----------
    ComplexCase(
        name="68_invoice",
        description="Build a complete invoice doc",
        script=(
            "from docx.shared import Inches, Pt, RGBColor\n"
            "from docx.enum.text import WD_ALIGN_PARAGRAPH\n"
            "from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT\n"
            "\n"
            "# Page setup\n"
            "s = doc.sections[0]\n"
            "s.left_margin = Inches(0.75)\n"
            "s.right_margin = Inches(0.75)\n"
            "\n"
            "# Header block\n"
            "header = doc.add_paragraph()\n"
            "header.alignment = WD_ALIGN_PARAGRAPH.RIGHT\n"
            "h_run = header.add_run(\"INVOICE\")\n"
            "h_run.bold = True\n"
            "h_run.font.size = Pt(24)\n"
            "h_run.font.color.rgb = RGBColor(0x1F, 0x4E, 0x79)\n"
            "\n"
            "# Bill-to section\n"
            "doc.add_paragraph(\"Bill To:\")\n"
            "doc.add_paragraph(\"Acme Corp.\")\n"
            "doc.add_paragraph(\"123 Main Street\")\n"
            "doc.add_paragraph(\"Springfield, USA\")\n"
            "\n"
            "# Line items\n"
            "items = [\n"
            "    (\"Widget A\", 10, 9.99),\n"
            "    (\"Widget B\", 5, 19.99),\n"
            "    (\"Premium Gizmo\", 2, 49.50),\n"
            "]\n"
            "t = doc.add_table(rows=len(items) + 2, cols=4, style=\"TableGrid\")\n"
            "# Header row\n"
            "for i, head in enumerate([\"Item\", \"Qty\", \"Unit Price\", \"Total\"]):\n"
            "    cell = t.cell(0, i)\n"
            "    cell.text = head\n"
            "    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER\n"
            "# Body\n"
            "subtotal = 0.0\n"
            "for row, (name, qty, price) in enumerate(items, start=1):\n"
            "    line_total = qty * price\n"
            "    subtotal += line_total\n"
            "    t.cell(row, 0).text = name\n"
            "    t.cell(row, 1).text = str(qty)\n"
            "    t.cell(row, 2).text = f\"${price:.2f}\"\n"
            "    t.cell(row, 3).text = f\"${line_total:.2f}\"\n"
            "# Totals row\n"
            "total_row = t.rows[-1]\n"
            "total_row.cells[2].text = \"Total:\"\n"
            "total_row.cells[3].text = f\"${subtotal:.2f}\"\n"
            "\n"
            "# Column widths\n"
            "t.columns[0].width = Inches(3)\n"
            "t.columns[1].width = Inches(0.75)\n"
            "t.columns[2].width = Inches(1.25)\n"
            "t.columns[3].width = Inches(1.25)"
        ),
        tags=("level29", "combo", "invoice"),
    ),

    # ---------- Level 30: newsletter / article ----------
    ComplexCase(
        name="69_newsletter",
        description="Newsletter-style doc with multi-column hint, pull quotes, images",
        script=(
            "from docx.shared import Inches, Pt, RGBColor\n"
            "from docx.enum.text import WD_ALIGN_PARAGRAPH\n"
            "\n"
            "# Masthead\n"
            "mast = doc.add_paragraph()\n"
            "mast.alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            "r = mast.add_run(\"THE DAILY BUGLE\")\n"
            "r.bold = True\n"
            "r.font.size = Pt(36)\n"
            "r.font.all_caps = True\n"
            "\n"
            "# Date line\n"
            "date_line = doc.add_paragraph()\n"
            "date_line.alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            "date_line.add_run(\"Volume 42, No. 7 — April 21, 2026\").italic = True\n"
            "\n"
            "# Lead article\n"
            "h = doc.add_heading(\"Breaking: Something Happened\", level=1)\n"
            "\n"
            "lead = doc.add_paragraph()\n"
            "lead_r = lead.add_run(\"SPRINGFIELD — \")\n"
            "lead_r.bold = True\n"
            "lead.add_run(\"In a stunning turn of events, ordinary things continued to happen as usual today. Experts attributed this to the passage of time.\")\n"
            "lead.paragraph_format.first_line_indent = Inches(0.25)\n"
            "\n"
            "# Pull quote\n"
            "pq = doc.add_paragraph()\n"
            "pq.alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            "pq.paragraph_format.left_indent = Inches(0.5)\n"
            "pq.paragraph_format.right_indent = Inches(0.5)\n"
            "pq_r = pq.add_run('\"This is truly unprecedented.\"')\n"
            "pq_r.italic = True\n"
            "pq_r.font.size = Pt(14)\n"
            "\n"
            "# Body\n"
            "for i in range(4):\n"
            "    body = doc.add_paragraph()\n"
            "    body.paragraph_format.first_line_indent = Inches(0.25)\n"
            "    body.add_run(f\"Body paragraph {i+1}. \" * 3)\n"
            "\n"
            "# Sidebar as a 1-cell table\n"
            "sidebar = doc.add_table(rows=1, cols=1, style=\"TableGrid\")\n"
            "sc = sidebar.cell(0, 0)\n"
            "sc.add_paragraph(\"SIDEBAR: Related Stories\").runs[0].bold = True\n"
            "sc.add_paragraph(\"• Local Widget Factory Expansion\")\n"
            "sc.add_paragraph(\"• Community Events Calendar\")\n"
            "sc.add_paragraph(\"• Opinion: Why We Need More Tables\")"
        ),
        tags=("level30", "combo", "large"),
    ),

    # ---------- Level 31: iteration after dynamic add ----------
    ComplexCase(
        name="70_add_and_iterate_back",
        description="Build content, then iterate all paragraphs looking for a keyword",
        script=(
            "doc.add_paragraph(\"Intro paragraph\")\n"
            "doc.add_paragraph(\"Second with MARKER in it\")\n"
            "doc.add_paragraph(\"Third paragraph\")\n"
            "doc.add_paragraph(\"Fourth with MARKER again\")\n"
            "matches = sum(1 for p in doc.paragraphs if 'MARKER' in p.text)\n"
            "assert matches == 2, matches"
        ),
        tags=("level31", "iteration"),
    ),

    # ---------- Level 32: academic paper ----------
    ComplexCase(
        name="71_academic_paper",
        description="Multi-page academic paper with abstract, sections, citations",
        script=(
            "from docx.shared import Inches, Pt\n"
            "from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING\n"
            "\n"
            "s = doc.sections[0]\n"
            "s.top_margin = Inches(1)\n"
            "s.bottom_margin = Inches(1)\n"
            "s.left_margin = Inches(1.25)\n"
            "s.right_margin = Inches(1.25)\n"
            "\n"
            "# Title\n"
            "title = doc.add_heading(\"A Systematic Review of Widget Performance\", level=0)\n"
            "title.alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            "\n"
            "# Authors\n"
            "auth = doc.add_paragraph()\n"
            "auth.alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            "auth.add_run(\"Dr. A. Researcher, B. Collaborator\").italic = True\n"
            "\n"
            "affil = doc.add_paragraph()\n"
            "affil.alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            "affil.add_run(\"Institute of Widget Studies, Springfield University\")\n"
            "\n"
            "# Abstract\n"
            "abs_h = doc.add_heading(\"Abstract\", level=1)\n"
            "abs_h.alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            "abstract = doc.add_paragraph(\n"
            "    \"This paper reviews widget performance across various conditions. \"\n"
            "    \"We find that widgets generally perform widget-ly under widget-like stresses. \"\n"
            "    \"Implications for future widget research are discussed.\"\n"
            ")\n"
            "abstract.paragraph_format.left_indent = Inches(0.5)\n"
            "abstract.paragraph_format.right_indent = Inches(0.5)\n"
            "abstract.paragraph_format.line_spacing = 1.15\n"
            "\n"
            "# Body (double-spaced)\n"
            "for section_title in [\"Introduction\", \"Methods\", \"Results\", \"Discussion\", \"Conclusion\"]:\n"
            "    doc.add_heading(section_title, level=1)\n"
            "    for _ in range(3):\n"
            "        body = doc.add_paragraph(\n"
            "            \"Body paragraph content goes here. Widget performance varies. \"\n"
            "            \"See Smith et al. (2024).\" * 2\n"
            "        )\n"
            "        body.paragraph_format.line_spacing_rule = WD_LINE_SPACING.DOUBLE\n"
            "        body.paragraph_format.first_line_indent = Inches(0.5)\n"
            "\n"
            "# References\n"
            "doc.add_heading(\"References\", level=1)\n"
            "refs = [\n"
            "    \"Smith, J. (2024). Widgets and widget-like behaviors. J. Widgetology, 5, 1-10.\",\n"
            "    \"Doe, J. (2023). A review of widgets. Widgets Annual, 3, 100-200.\",\n"
            "]\n"
            "for r in refs:\n"
            "    p = doc.add_paragraph(r)\n"
            "    p.paragraph_format.first_line_indent = Inches(-0.5)  # hanging\n"
            "    p.paragraph_format.left_indent = Inches(0.5)"
        ),
        tags=("level32", "combo", "large"),
    ),

    # ---------- Level 33: legal contract ----------
    ComplexCase(
        name="72_legal_contract",
        description="Legal contract with numbered clauses",
        script=(
            "from docx.shared import Inches, Pt\n"
            "from docx.enum.text import WD_ALIGN_PARAGRAPH\n"
            "\n"
            "# Title\n"
            "title = doc.add_heading(\"SERVICE AGREEMENT\", level=0)\n"
            "title.alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            "\n"
            "# Intro\n"
            "intro = doc.add_paragraph(\n"
            "    \"This SERVICE AGREEMENT (this \\\"Agreement\\\") is entered into as of the 21st day of April, 2026, \"\n"
            "    \"by and between Party A (\\\"Client\\\") and Party B (\\\"Contractor\\\").\"\n"
            ")\n"
            "intro.paragraph_format.space_after = Pt(12)\n"
            "\n"
            "# Clauses\n"
            "clauses = [\n"
            "    (\"Scope of Services\", \"Contractor shall provide widget-related services.\"),\n"
            "    (\"Term\", \"This Agreement shall commence on the Effective Date and continue for one (1) year.\"),\n"
            "    (\"Compensation\", \"Client shall pay Contractor the fees set forth in Exhibit A.\"),\n"
            "    (\"Confidentiality\", \"Each party shall protect the other's Confidential Information.\"),\n"
            "    (\"Termination\", \"Either party may terminate upon thirty (30) days' written notice.\"),\n"
            "    (\"Governing Law\", \"This Agreement is governed by the laws of the State of California.\"),\n"
            "]\n"
            "for i, (heading, body) in enumerate(clauses, start=1):\n"
            "    h_p = doc.add_paragraph()\n"
            "    h_r = h_p.add_run(f\"{i}. {heading}.\")\n"
            "    h_r.bold = True\n"
            "    h_r.font.all_caps = False\n"
            "    h_p.paragraph_format.space_before = Pt(6)\n"
            "    body_p = doc.add_paragraph(body)\n"
            "    body_p.paragraph_format.left_indent = Inches(0.5)\n"
            "\n"
            "# Signature block\n"
            "doc.add_paragraph()\n"
            "sig_table = doc.add_table(rows=3, cols=2, style=\"TableGrid\")\n"
            "sig_table.cell(0, 0).text = \"CLIENT:\"\n"
            "sig_table.cell(0, 1).text = \"CONTRACTOR:\"\n"
            "sig_table.cell(1, 0).text = \"By: ________________\"\n"
            "sig_table.cell(1, 1).text = \"By: ________________\"\n"
            "sig_table.cell(2, 0).text = \"Date: _______________\"\n"
            "sig_table.cell(2, 1).text = \"Date: _______________\""
        ),
        tags=("level33", "combo", "legal"),
    ),

    # ---------- Level 34: complex form ----------
    ComplexCase(
        name="73_form_with_many_tables",
        description="Form-like doc with many small tables for fields",
        script=(
            "from docx.shared import Inches\n"
            "\n"
            "doc.add_heading(\"Customer Onboarding Form\", level=0)\n"
            "\n"
            "fields = [\n"
            "    (\"Company Name\", 4),\n"
            "    (\"Industry\", 4),\n"
            "    (\"Contact Name\", 3),\n"
            "    (\"Email\", 4),\n"
            "    (\"Phone\", 3),\n"
            "    (\"Address Line 1\", 5),\n"
            "    (\"Address Line 2\", 5),\n"
            "    (\"City\", 3),\n"
            "    (\"State\", 2),\n"
            "    (\"Zip\", 2),\n"
            "]\n"
            "for label, width in fields:\n"
            "    t = doc.add_table(rows=1, cols=2, style=\"TableGrid\")\n"
            "    t.cell(0, 0).text = label\n"
            "    t.columns[0].width = Inches(1.5)\n"
            "    t.columns[1].width = Inches(width)\n"
            "    t.cell(0, 1).text = \"\"  # blank fill-in"
        ),
        tags=("level34", "combo"),
    ),

    # ---------- Level 35: complex multi-run formatting ----------
    ComplexCase(
        name="74_paragraph_with_10_runs",
        description="Single paragraph with 10 differently-formatted runs",
        script=(
            "from docx.shared import Pt, RGBColor\n"
            "from docx.enum.text import WD_COLOR_INDEX\n"
            "p = doc.add_paragraph()\n"
            "fmts = [\n"
            "    dict(bold=True),\n"
            "    dict(italic=True),\n"
            "    dict(underline=True),\n"
            "    dict(bold=True, italic=True),\n"
            "    dict(color=RGBColor(0xFF, 0x00, 0x00)),\n"
            "    dict(size=Pt(14)),\n"
            "    dict(name=\"Courier\"),\n"
            "    dict(highlight=WD_COLOR_INDEX.YELLOW),\n"
            "    dict(strike=True),\n"
            "    dict(all_caps=True),\n"
            "]\n"
            "for i, fmt in enumerate(fmts):\n"
            "    r = p.add_run(f\"run{i} \")\n"
            "    if fmt.get('bold'): r.bold = True\n"
            "    if fmt.get('italic'): r.italic = True\n"
            "    if fmt.get('underline'): r.underline = True\n"
            "    if fmt.get('color'): r.font.color.rgb = fmt['color']\n"
            "    if fmt.get('size'): r.font.size = fmt['size']\n"
            "    if fmt.get('name'): r.font.name = fmt['name']\n"
            "    if fmt.get('highlight'): r.font.highlight_color = fmt['highlight']\n"
            "    if fmt.get('strike'): r.font.strike = True\n"
            "    if fmt.get('all_caps'): r.font.all_caps = True"
        ),
        tags=("level35", "run", "font"),
    ),

    # ---------- Level 36: layout tests ----------
    ComplexCase(
        name="75_paragraph_negative_first_line_indent",
        description="Hanging indent (negative first_line_indent)",
        script=(
            "from docx.shared import Inches\n"
            'p = doc.add_paragraph("hanging indented paragraph")\n'
            "p.paragraph_format.left_indent = Inches(0.5)\n"
            "p.paragraph_format.first_line_indent = Inches(-0.25)"
        ),
        tags=("level36", "paragraph"),
    ),

    # ---------- Level 37: RGBColor.from_string usage ----------
    ComplexCase(
        name="76_rgbcolor_from_string",
        description="Use RGBColor.from_string on '#RRGGBB'",
        script=(
            "from docx.shared import RGBColor\n"
            "p = doc.add_paragraph()\n"
            'r = p.add_run("colored")\n'
            "r.font.color.rgb = RGBColor.from_string(\"1E90FF\")"
        ),
        tags=("level37", "color"),
    ),

    # ---------- Level 38: unit conversions ----------
    ComplexCase(
        name="77_length_unit_conversions",
        description="Convert between Inches, Cm, Mm, Pt, Twips",
        script=(
            "from docx.shared import Inches, Cm, Mm, Pt, Twips, Emu\n"
            "assert Inches(1).pt == 72.0, Inches(1).pt\n"
            "assert Cm(2.54).inches == 1.0, Cm(2.54).inches\n"
            "assert Mm(25.4).inches == 1.0, Mm(25.4).inches\n"
            "assert Pt(12).twips == 240, Pt(12).twips\n"
            "assert Twips(240).pt == 12.0, Twips(240).pt\n"
            "assert int(Emu(914400)) == int(Inches(1)), Emu(914400)"
        ),
        tags=("level38", "units"),
    ),

    # ---------- Level 39: advanced patterns ----------
    ComplexCase(
        name="78_paragraph_copy_style",
        description="Copy style from one paragraph to another",
        script=(
            'p1 = doc.add_paragraph("first")\n'
            'p1.style = "Heading 2"\n'
            'p2 = doc.add_paragraph("second")\n'
            "p2.style = p1.style\n"
            'assert p2.style.name == "Heading 2", p2.style.name'
        ),
        tags=("level39", "style"),
    ),
    ComplexCase(
        name="79_bulk_cell_formatting",
        description="Format every cell in a table the same way",
        script=(
            "from docx.shared import Pt\n"
            "from docx.enum.table import WD_ALIGN_VERTICAL\n"
            "t = doc.add_table(rows=3, cols=3, style=\"TableGrid\")\n"
            "for row in t.rows:\n"
            "    for cell in row.cells:\n"
            "        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER\n"
            "        if cell.paragraphs:\n"
            "            cell.text = \"data\""
        ),
        tags=("level39", "table"),
    ),
    ComplexCase(
        name="80_apply_style_after_add_run",
        description="add_run with style parameter applies char style",
        script=(
            "p = doc.add_paragraph()\n"
            'r = p.add_run("emph", style="Emphasis")\n'
            'assert r.text == "emph", r.text'
        ),
        tags=("level39", "run"),
    ),
    ComplexCase(
        name="81_multi_page_with_breaks",
        description="Multiple pages via add_page_break",
        script=(
            'doc.add_heading("Page 1", level=1)\n'
            'doc.add_paragraph("content1")\n'
            "doc.add_page_break()\n"
            'doc.add_heading("Page 2", level=1)\n'
            'doc.add_paragraph("content2")\n'
            "doc.add_page_break()\n"
            'doc.add_heading("Page 3", level=1)\n'
            'doc.add_paragraph("content3")'
        ),
        tags=("level39", "large"),
    ),

    # ---------- Level 40: more boundary tests ----------
    ComplexCase(
        name="82_add_text_on_existing_run",
        description="add_text appends to existing run (r.text grows)",
        script=(
            "p = doc.add_paragraph()\n"
            'r = p.add_run("Hello ")\n'
            'r.add_text("world!")\n'
            'assert r.text == "Hello world!", r.text'
        ),
        tags=("level40", "run"),
    ),
    ComplexCase(
        name="83_clear_then_repopulate_paragraph",
        description="Clear a paragraph and repopulate with new runs",
        script=(
            'p = doc.add_paragraph("initial")\n'
            "p.clear()\n"
            'p.add_run("new content")\n'
            'assert "new" in p.text'
        ),
        tags=("level40", "paragraph"),
    ),
    ComplexCase(
        name="84_table_reread_row_count",
        description="Add rows dynamically, verify row count",
        script=(
            "t = doc.add_table(rows=1, cols=3)\n"
            "for i in range(4):\n"
            "    t.add_row()\n"
            "assert len(t.rows) == 5, len(t.rows)"
        ),
        tags=("level40", "table"),
    ),
    ComplexCase(
        name="85_header_footer_access",
        description="Access header/footer objects without error",
        script=(
            "s = doc.sections[0]\n"
            "h = s.header\n"
            "f = s.footer\n"
            "# is_linked_to_previous getter\n"
            "_ = h.is_linked_to_previous\n"
            "_ = f.is_linked_to_previous\n"
            "# paragraphs (may be empty)\n"
            "_ = h.paragraphs\n"
            "_ = f.paragraphs"
        ),
        tags=("level40", "section"),
    ),
    ComplexCase(
        name="86_font_read_unset_returns_none",
        description="Reading unset font properties returns None, not error",
        script=(
            "p = doc.add_paragraph()\n"
            'r = p.add_run("plain")\n'
            "# All these should be None (not set)\n"
            "for prop in ('bold','italic','underline','strike','all_caps'):\n"
            "    val = getattr(r.font, prop)\n"
            "    assert val is None, f'{prop}={val!r} expected None'"
        ),
        tags=("level40", "font"),
    ),

    # ---------- Level 41: document length scaling ----------
    ComplexCase(
        name="87_500_paragraph_doc",
        description="500 paragraphs with light formatting",
        script=(
            "for i in range(500):\n"
            "    p = doc.add_paragraph(f\"Line {i}\")\n"
            "    if i % 50 == 0:\n"
            "        p.runs[0].bold = True if p.runs else None"
        ),
        tags=("level41", "large"),
    ),

    # ---------- Level 42: mixed content document ----------
    ComplexCase(
        name="88_mixed_content_iteration",
        description="Interleave paragraphs and tables, iterate them",
        script=(
            "for i in range(5):\n"
            "    doc.add_paragraph(f\"Paragraph {i}\")\n"
            "    t = doc.add_table(rows=1, cols=2)\n"
            "    t.cell(0, 0).text = f\"row{i}-a\"\n"
            "    t.cell(0, 1).text = f\"row{i}-b\"\n"
            "# doc.paragraphs returns only top-level (not cell) paragraphs in python-docx\n"
            "assert len(doc.paragraphs) == 5, len(doc.paragraphs)\n"
            "assert len(doc.tables) == 5, len(doc.tables)"
        ),
        tags=("level42", "iteration"),
    ),

    # ---------- Level 43: error-prone patterns ----------
    ComplexCase(
        name="89_alignment_clear_via_none",
        description="Setting alignment=None clears it",
        script=(
            "from docx.enum.text import WD_ALIGN_PARAGRAPH\n"
            'p = doc.add_paragraph("x")\n'
            "p.alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            "p.alignment = None\n"
            "got = p.alignment\n"
            'assert got is None, got'
        ),
        tags=("level43", "paragraph"),
    ),

    # ---------- Level 44: cell.add_paragraph with style ----------
    ComplexCase(
        name="90_cell_add_paragraph_styled",
        description="add_paragraph to cell with a style",
        script=(
            "t = doc.add_table(rows=1, cols=1)\n"
            "c = t.cell(0, 0)\n"
            'p = c.add_paragraph("heading in cell", style="Heading 3")\n'
            "# style round-trip best-effort\n"
            'assert hasattr(p.style, "name") or p.style is None'
        ),
        tags=("level44", "table"),
    ),

    # ---------- Level 45: many small tables ----------
    ComplexCase(
        name="91_many_small_tables",
        description="50 small tables in sequence",
        script=(
            "for i in range(50):\n"
            "    t = doc.add_table(rows=1, cols=2)\n"
            "    t.cell(0, 0).text = f\"k{i}\"\n"
            "    t.cell(0, 1).text = f\"v{i}\"\n"
            "assert len(doc.tables) == 50, len(doc.tables)"
        ),
        tags=("level45", "table", "large"),
    ),

    # ---------- Level 46: layout margins on all sections ----------
    ComplexCase(
        name="92_margins_every_section",
        description="Set same margins on all sections",
        script=(
            "from docx.shared import Inches\n"
            "from docx.enum.section import WD_SECTION_START\n"
            "doc.add_section(WD_SECTION_START.NEW_PAGE)\n"
            "doc.add_section(WD_SECTION_START.NEW_PAGE)\n"
            "for s in doc.sections:\n"
            "    s.top_margin = Inches(0.5)\n"
            "    s.bottom_margin = Inches(0.5)\n"
            "    s.left_margin = Inches(0.5)\n"
            "    s.right_margin = Inches(0.5)"
        ),
        tags=("level46", "section"),
    ),

    # ---------- Level 47: font reads from marks ----------
    ComplexCase(
        name="93_font_bool_reads_after_set",
        description="After setting bold, font.bold returns True",
        script=(
            "p = doc.add_paragraph()\n"
            'r = p.add_run("bolded")\n'
            "r.font.bold = True\n"
            "assert r.font.bold is True, r.font.bold\n"
            "r.font.italic = True\n"
            "assert r.font.italic is True, r.font.italic"
        ),
        tags=("level47", "font", "round_trip"),
    ),

    # ---------- Level 48: page_break_before ----------
    ComplexCase(
        name="94_page_break_before_paragraph",
        description="paragraph_format.page_break_before",
        script=(
            'p = doc.add_paragraph("new page")\n'
            "p.paragraph_format.page_break_before = True"
        ),
        expected_ops=("format.paragraph.setFlowOptions",),
        tags=("level48", "paragraph"),
    ),

    # ---------- Level 49: hyperlinks (python-docx exposes Paragraph.hyperlinks) ----------
    ComplexCase(
        name="95_paragraph_hyperlinks_empty",
        description="Access paragraph.hyperlinks on a plain paragraph (should be empty list)",
        script=(
            'p = doc.add_paragraph("no links here")\n'
            "hs = p.hyperlinks\n"
            "assert isinstance(hs, list), type(hs)\n"
            "assert len(hs) == 0, len(hs)"
        ),
        tags=("level49", "hyperlinks"),
    ),

    # ---------- Level 50: paragraph.contains_page_break ----------
    ComplexCase(
        name="96_paragraph_contains_page_break",
        description="Access paragraph.contains_page_break",
        script=(
            "from docx.enum.text import WD_BREAK\n"
            "p = doc.add_paragraph()\n"
            "r = p.add_run(\"text\")\n"
            "r.add_break(WD_BREAK.PAGE)\n"
            "# Just access — don't assert, python-docx API varies\n"
            "_ = getattr(p, 'contains_page_break', False)"
        ),
        tags=("level50", "paragraph"),
    ),

    # ---------- Level 51: style-based lookups ----------
    ComplexCase(
        name="97_document_styles_by_key",
        description="Lookup by various style names",
        script=(
            "for name in ['Normal', 'Heading 1', 'Heading 2', 'Title', 'Subtitle', 'Quote']:\n"
            "    s = doc.styles[name]\n"
            "    assert s.name == name, s.name"
        ),
        tags=("level51", "styles"),
    ),
    ComplexCase(
        name="98_style_contains_check",
        description="in-check on doc.styles",
        script=(
            "assert 'Normal' in doc.styles\n"
            "assert 'Heading 1' in doc.styles\n"
            "assert 'Bogus Style' not in doc.styles"
        ),
        tags=("level51", "styles"),
    ),

    # ---------- Level 52: run.add_picture on existing doc ----------
    ComplexCase(
        name="99_run_add_picture_from_bytes",
        description="run.add_picture from an in-memory PNG stream (valid 2x2 PNG)",
        script=(
            "from docx.shared import Inches\n"
            "import io, struct, zlib\n"
            "# Build a valid 2x2 solid-color PNG inline so stock python-docx accepts it.\n"
            "def png_2x2():\n"
            "    def chunk(ctype, data):\n"
            "        return (\n"
            "            struct.pack('>I', len(data)) + ctype + data\n"
            "            + struct.pack('>I', zlib.crc32(ctype + data) & 0xffffffff)\n"
            "        )\n"
            "    signature = b'\\x89PNG\\r\\n\\x1a\\n'\n"
            "    ihdr = struct.pack('>IIBBBBB', 2, 2, 8, 2, 0, 0, 0)\n"
            "    raw = b'\\x00\\xff\\x00\\x00\\x00\\xff\\x00\\x00\\x00\\xff\\x00\\x00\\x00\\xff\\x00\\x00'\n"
            "    idat = zlib.compress(raw)\n"
            "    iend = b''\n"
            "    return signature + chunk(b'IHDR', ihdr) + chunk(b'IDAT', idat) + chunk(b'IEND', iend)\n"
            "p = doc.add_paragraph()\n"
            "r = p.add_run()\n"
            "stream = io.BytesIO(png_2x2())\n"
            "r.add_picture(stream, width=Inches(1))"
        ),
        expected_ops=("create.image",),
        tags=("level52", "image"),
    ),

    # ---------- Level 53: table.rows[-1] indexing ----------
    ComplexCase(
        name="100_table_negative_indexing",
        description="Access last row/column via negative index",
        script=(
            "t = doc.add_table(rows=3, cols=3)\n"
            "last_row = t.rows[-1]\n"
            "last_col = t.columns[-1]\n"
            "assert last_row is not None\n"
            "assert last_col is not None"
        ),
        tags=("level53", "table"),
    ),

    # ---------- Level 54: iterating cells via Table._cells ----------
    ComplexCase(
        name="101_table_cells_flat_iteration",
        description="Iterate Table._cells (row-major flat list)",
        script=(
            "t = doc.add_table(rows=2, cols=3)\n"
            "cells = t._cells\n"
            "assert len(cells) == 6, len(cells)\n"
            "for i, c in enumerate(cells):\n"
            "    c.text = f'c{i}'"
        ),
        tags=("level54", "table"),
    ),

    # ---------- Level 55: complex paragraph state ----------
    ComplexCase(
        name="102_text_with_embedded_special_chars",
        description="Paragraph with tab/newline/special chars",
        script=(
            'p = doc.add_paragraph("a\\tb\\nc\\r\\n d")\n'
            "# Just make sure no error"
        ),
        tags=("level55", "edge"),
    ),

    # ---------- Level 56: cell.tables for nested detection ----------
    ComplexCase(
        name="103_cell_tables_enumeration",
        description="Enumerate cell.tables after nesting",
        script=(
            "outer = doc.add_table(rows=1, cols=1)\n"
            "c = outer.cell(0, 0)\n"
            "c.add_table(rows=2, cols=2)\n"
            "c.add_table(rows=1, cols=1)\n"
            "# cell.tables should list nested tables\n"
            "nested = c.tables\n"
            "# don't assert exact count — fake may not fully reflect"
        ),
        tags=("level56", "nested"),
    ),

    # ---------- Level 57: core properties pull in datetime ----------
    ComplexCase(
        name="104_core_properties_datetime",
        description="Get and set all core_properties fields",
        script=(
            "import datetime\n"
            "cp = doc.core_properties\n"
            "cp.author = 'Jane'\n"
            "cp.category = 'Report'\n"
            "cp.comments = 'First draft'\n"
            "cp.content_status = 'Draft'\n"
            "cp.created = datetime.datetime(2024, 1, 2, 3, 4, 5)\n"
            "cp.identifier = 'DOC-123'\n"
            "cp.keywords = 'widgets, sales'\n"
            "cp.language = 'en-US'\n"
            "cp.last_modified_by = 'Bob'\n"
            "cp.last_printed = datetime.datetime(2024, 2, 1)\n"
            "cp.modified = datetime.datetime(2024, 3, 1)\n"
            "cp.revision = 3\n"
            "cp.subject = 'Testing'\n"
            "cp.title = 'Test Doc'\n"
            "cp.version = '1.0'\n"
            "# Read back\n"
            "assert cp.author == 'Jane'\n"
            "assert cp.revision == 3\n"
            "assert cp.title == 'Test Doc'"
        ),
        tags=("level57", "metadata"),
    ),

    # ---------- Level 58: section count from scratch ----------
    ComplexCase(
        name="105_default_one_section",
        description="A new doc has exactly 1 section by default",
        script=(
            "assert len(doc.sections) == 1, len(doc.sections)\n"
            "s = doc.sections[0]\n"
            "# orientation round-trip\n"
            "from docx.enum.section import WD_ORIENTATION\n"
            "s.orientation = WD_ORIENTATION.LANDSCAPE\n"
            "assert s.orientation == WD_ORIENTATION.LANDSCAPE"
        ),
        tags=("level58", "section"),
    ),

    # ---------- Level 59: paragraph_format on a heading ----------
    ComplexCase(
        name="106_heading_paragraph_format",
        description="paragraph_format applies to headings too",
        script=(
            "from docx.shared import Pt\n"
            "h = doc.add_heading('Section', level=2)\n"
            "h.paragraph_format.space_before = Pt(24)\n"
            "h.paragraph_format.space_after = Pt(12)"
        ),
        tags=("level59", "heading"),
    ),

    # ---------- Level 60: table with varying row heights ----------
    ComplexCase(
        name="107_varying_row_heights",
        description="Set different row heights on each row",
        script=(
            "from docx.shared import Pt\n"
            "from docx.enum.table import WD_ROW_HEIGHT_RULE\n"
            "t = doc.add_table(rows=5, cols=2)\n"
            "heights = [Pt(20), Pt(40), Pt(30), Pt(60), Pt(25)]\n"
            "for i, h in enumerate(heights):\n"
            "    t.rows[i].height = h\n"
            "    t.rows[i].height_rule = WD_ROW_HEIGHT_RULE.AT_LEAST"
        ),
        tags=("level60", "table"),
    ),

    ComplexCase(
        name="38_font_all_properties",
        description="Stress test many Font properties at once",
        script=(
            "from docx.shared import Pt, RGBColor\n"
            "from docx.enum.text import WD_COLOR_INDEX, WD_UNDERLINE\n"
            "p = doc.add_paragraph()\n"
            'r = p.add_run("fancy")\n'
            "f = r.font\n"
            'f.name = "Calibri"\n'
            "f.size = Pt(12)\n"
            "f.bold = True\n"
            "f.italic = True\n"
            "f.underline = WD_UNDERLINE.DOUBLE\n"
            "f.strike = True\n"
            "f.double_strike = True\n"
            "f.all_caps = True\n"
            "f.small_caps = True\n"
            "f.shadow = True\n"
            "f.outline = True\n"
            "f.emboss = True\n"
            "f.imprint = True\n"
            "f.hidden = True\n"
            "f.rtl = False\n"
            "f.snap_to_grid = True\n"
            "f.highlight_color = WD_COLOR_INDEX.YELLOW\n"
            "f.color.rgb = RGBColor(0x11, 0x22, 0x33)"
        ),
        expected_ops=("format.apply",),
        tags=("level12", "font"),
    ),
]
