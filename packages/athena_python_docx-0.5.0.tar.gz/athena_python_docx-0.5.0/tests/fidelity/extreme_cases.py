"""Extreme / adversarial cases — push the SDK to its limits.

These are pattens designed to find gaps: deep nesting, long documents,
edge-case character properties, simultaneous state mutations, etc.
"""

from __future__ import annotations

from tests.fidelity.complex_cases import ComplexCase


EXTREME_CASES: list[ComplexCase] = [
    # ---- Deep nesting ----
    ComplexCase(
        name="ex01_five_levels_deep_tables",
        description="5-level deep nested tables",
        script=(
            "current = doc.add_table(rows=1, cols=1).cell(0, 0)\n"
            "for i in range(4):\n"
            "    nested = current.add_table(rows=1, cols=1)\n"
            "    current = nested.cell(0, 0)\n"
            "current.text = 'deepest'"
        ),
        tags=("extreme", "nested"),
    ),

    # ---- Unicode stress ----
    ComplexCase(
        name="ex02_unicode_everywhere",
        description="Unicode in all surfaces (headings, runs, cells, styles)",
        script=(
            "doc.add_heading('タイトル — Title', level=0)\n"
            "p = doc.add_paragraph()\n"
            "p.add_run('日本語 ').bold = True\n"
            "p.add_run('한국어 ').italic = True\n"
            "p.add_run('中文').underline = True\n"
            "t = doc.add_table(rows=1, cols=3, style='TableGrid')\n"
            "for i, label in enumerate(['日本', '한국', '中国']):\n"
            "    t.cell(0, i).text = label"
        ),
        tags=("extreme", "unicode"),
    ),

    # ---- 1000 paragraphs ----
    ComplexCase(
        name="ex03_1000_paragraphs",
        description="1000 paragraphs — stress the linear insert path",
        script=(
            "for i in range(1000):\n"
            "    doc.add_paragraph(f'Line {i}')"
        ),
        tags=("extreme", "large"),
    ),

    # ---- 50x50 table ----
    ComplexCase(
        name="ex04_50x50_table",
        description="2500-cell table",
        script=(
            "t = doc.add_table(rows=50, cols=50)\n"
            "# Light touch — just fill diagonal\n"
            "for i in range(50):\n"
            "    t.cell(i, i).text = f'd{i}'"
        ),
        tags=("extreme", "large", "table"),
    ),

    # ---- Long paragraph in a cell ----
    ComplexCase(
        name="ex05_long_text_in_cell",
        description="Cell with 5000-char text",
        script=(
            "t = doc.add_table(rows=1, cols=1, style='TableGrid')\n"
            "t.cell(0, 0).text = 'Long text. ' * 500"
        ),
        tags=("extreme", "large", "table"),
    ),

    # ---- Many small runs ----
    ComplexCase(
        name="ex06_hundred_tiny_runs",
        description="Paragraph with 100 single-char runs, each with different formatting",
        script=(
            "p = doc.add_paragraph()\n"
            "for i in range(100):\n"
            "    r = p.add_run(chr(65 + (i % 26)))\n"
            "    if i % 3 == 0:\n"
            "        r.bold = True\n"
            "    if i % 5 == 0:\n"
            "        r.italic = True\n"
            "    if i % 7 == 0:\n"
            "        r.underline = True"
        ),
        tags=("extreme", "run"),
    ),

    # ---- All font flags ----
    ComplexCase(
        name="ex07_every_font_boolean",
        description="Turn on every single Font bool flag",
        script=(
            "p = doc.add_paragraph()\n"
            "r = p.add_run('maximally formatted')\n"
            "for attr in [\n"
            "    'bold', 'italic', 'strike', 'double_strike',\n"
            "    'all_caps', 'small_caps', 'shadow', 'outline',\n"
            "    'emboss', 'imprint', 'hidden', 'rtl', 'cs_bold',\n"
            "    'cs_italic', 'complex_script', 'snap_to_grid',\n"
            "]:\n"
            "    setattr(r.font, attr, True)"
        ),
        tags=("extreme", "font"),
    ),

    # ---- Sections back-to-back ----
    ComplexCase(
        name="ex08_many_continuous_sections",
        description="Multiple continuous sections",
        script=(
            "from docx.enum.section import WD_SECTION_START\n"
            "for _ in range(10):\n"
            "    doc.add_section(WD_SECTION_START.CONTINUOUS)"
        ),
        tags=("extreme", "section"),
    ),

    # ---- Tab-stop stress ----
    ComplexCase(
        name="ex09_many_tab_stops",
        description="Add 10 tab stops to a paragraph",
        script=(
            "from docx.shared import Inches\n"
            "from docx.enum.text import WD_TAB_ALIGNMENT\n"
            "p = doc.add_paragraph()\n"
            "for i in range(1, 11):\n"
            "    p.paragraph_format.tab_stops.add_tab_stop(\n"
            "        Inches(i * 0.5),\n"
            "        WD_TAB_ALIGNMENT.LEFT,\n"
            "    )"
        ),
        tags=("extreme", "paragraph"),
    ),

    # ---- Complex bill-of-materials ----
    ComplexCase(
        name="ex10_complex_bom",
        description="Complex BOM document: headings, nested tables, merged cells, formatted runs",
        script=(
            "from docx.shared import Inches, Pt, RGBColor\n"
            "from docx.enum.text import WD_ALIGN_PARAGRAPH\n"
            "from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT\n"
            "\n"
            "doc.add_heading('Bill of Materials', level=0).alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            "\n"
            "for section_idx, section in enumerate(['Electrical', 'Mechanical', 'Software'], start=1):\n"
            "    h = doc.add_heading(f'{section_idx}. {section}', level=1)\n"
            "    t = doc.add_table(rows=5, cols=5, style='TableGrid')\n"
            "    t.alignment = WD_TABLE_ALIGNMENT.CENTER\n"
            "    # Merge the top-left two cells for section label\n"
            "    a = t.cell(0, 0)\n"
            "    b = t.cell(0, 1)\n"
            "    a.merge(b)\n"
            "    a.text = f'{section} BOM'\n"
            "    # Headers row\n"
            "    headers = ['Part', 'Qty', 'Unit Cost', 'Line Cost', 'Supplier']\n"
            "    for i, h_text in enumerate(headers):\n"
            "        c = t.cell(1, i)\n"
            "        c.text = h_text\n"
            "        c.vertical_alignment = WD_ALIGN_VERTICAL.CENTER\n"
            "        if c.paragraphs and c.paragraphs[0].runs:\n"
            "            c.paragraphs[0].runs[0].bold = True\n"
            "    # 3 rows of data\n"
            "    for row_idx in range(2, 5):\n"
            "        t.cell(row_idx, 0).text = f'Part-{section_idx}-{row_idx}'\n"
            "        t.cell(row_idx, 1).text = str(row_idx)\n"
            "        t.cell(row_idx, 2).text = f'${row_idx * 10}'\n"
            "        t.cell(row_idx, 3).text = f'${row_idx * 10 * row_idx}'\n"
            "        t.cell(row_idx, 4).text = 'ACME'"
        ),
        tags=("extreme", "combo"),
    ),

    # ---- Conditional formatting based on row parity ----
    ComplexCase(
        name="ex11_banded_rows_formatting",
        description="20-row table with banded-row background (via font color proxy for now)",
        script=(
            "from docx.shared import RGBColor\n"
            "t = doc.add_table(rows=20, cols=4, style='TableGrid')\n"
            "for r in range(20):\n"
            "    for c in range(4):\n"
            "        cell = t.cell(r, c)\n"
            "        cell.text = f'r{r}c{c}'\n"
            "        if r % 2 == 0 and cell.paragraphs and cell.paragraphs[0].runs:\n"
            "            cell.paragraphs[0].runs[0].font.color.rgb = RGBColor(0x80, 0x80, 0x80)"
        ),
        tags=("extreme", "table"),
    ),

    # ---- Section reconfiguration ----
    ComplexCase(
        name="ex12_section_reconfigure",
        description="Reconfigure section page setup multiple times",
        script=(
            "from docx.shared import Inches\n"
            "from docx.enum.section import WD_ORIENTATION\n"
            "s = doc.sections[0]\n"
            "s.orientation = WD_ORIENTATION.PORTRAIT\n"
            "s.page_width = Inches(8.5)\n"
            "s.page_height = Inches(11)\n"
            "# Change it\n"
            "s.orientation = WD_ORIENTATION.LANDSCAPE\n"
            "s.page_width = Inches(11)\n"
            "s.page_height = Inches(8.5)\n"
            "# Change margins progressively\n"
            "for m in [0.5, 0.75, 1.0, 1.25]:\n"
            "    s.top_margin = Inches(m)\n"
            "    s.left_margin = Inches(m)"
        ),
        tags=("extreme", "section"),
    ),

    # ---- Many paragraphs in a cell ----
    ComplexCase(
        name="ex13_cell_with_10_paragraphs",
        description="Single cell with 10 paragraphs, each differently styled",
        script=(
            "from docx.enum.text import WD_ALIGN_PARAGRAPH\n"
            "t = doc.add_table(rows=1, cols=1, style='TableGrid')\n"
            "c = t.cell(0, 0)\n"
            "alignments = [\n"
            "    WD_ALIGN_PARAGRAPH.LEFT, WD_ALIGN_PARAGRAPH.CENTER,\n"
            "    WD_ALIGN_PARAGRAPH.RIGHT, WD_ALIGN_PARAGRAPH.JUSTIFY,\n"
            "]\n"
            "for i in range(10):\n"
            "    p = c.add_paragraph(f'Cell para {i}')\n"
            "    p.alignment = alignments[i % 4]"
        ),
        tags=("extreme", "table"),
    ),

    # ---- Multi-style table with headers, body, footer ----
    ComplexCase(
        name="ex14_styled_report_table",
        description="Tri-zone table (header / body / footer) with distinct formatting",
        script=(
            "from docx.shared import Pt, RGBColor\n"
            "from docx.enum.table import WD_ALIGN_VERTICAL\n"
            "t = doc.add_table(rows=5, cols=3, style='TableGrid')\n"
            "# Header row\n"
            "for i, h in enumerate(['Category', 'Q1', 'Q2']):\n"
            "    cell = t.cell(0, i)\n"
            "    cell.text = h\n"
            "    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER\n"
            "    if cell.paragraphs and cell.paragraphs[0].runs:\n"
            "        r = cell.paragraphs[0].runs[0]\n"
            "        r.bold = True\n"
            "        r.font.size = Pt(14)\n"
            "        r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)\n"
            "# Body rows\n"
            "for i, (name, q1, q2) in enumerate([\n"
            "    ('Revenue', '$1M', '$1.2M'),\n"
            "    ('Users', '10K', '12K'),\n"
            "    ('NPS', '40', '45'),\n"
            "], start=1):\n"
            "    t.cell(i, 0).text = name\n"
            "    t.cell(i, 1).text = q1\n"
            "    t.cell(i, 2).text = q2\n"
            "# Total row\n"
            "t.cell(4, 0).text = 'Total'\n"
            "t.cell(4, 1).text = '—'\n"
            "t.cell(4, 2).text = '—'\n"
            "for i in range(3):\n"
            "    cell = t.cell(4, i)\n"
            "    if cell.paragraphs and cell.paragraphs[0].runs:\n"
            "        cell.paragraphs[0].runs[0].bold = True\n"
            "        cell.paragraphs[0].runs[0].italic = True"
        ),
        tags=("extreme", "combo", "table"),
    ),

    # ---- Paragraph properties — all at once ----
    ComplexCase(
        name="ex15_paragraph_all_format_props",
        description="Set every ParagraphFormat property in one go",
        script=(
            "from docx.shared import Pt, Inches\n"
            "from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING\n"
            "p = doc.add_paragraph('fully formatted paragraph')\n"
            "pf = p.paragraph_format\n"
            "pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY\n"
            "pf.left_indent = Inches(0.5)\n"
            "pf.right_indent = Inches(0.25)\n"
            "pf.first_line_indent = Inches(0.25)\n"
            "pf.space_before = Pt(12)\n"
            "pf.space_after = Pt(6)\n"
            "pf.line_spacing = 1.5\n"
            "pf.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE\n"
            "pf.keep_together = True\n"
            "pf.keep_with_next = True\n"
            "pf.widow_control = True\n"
            "pf.page_break_before = False"
        ),
        tags=("extreme", "paragraph"),
    ),

    # ---- Mixed text + break ----
    ComplexCase(
        name="ex16_runs_interleaved_with_breaks",
        description="Runs with interleaved breaks and tabs",
        script=(
            "from docx.enum.text import WD_BREAK\n"
            "p = doc.add_paragraph()\n"
            "for i, text in enumerate(['first', 'second', 'third']):\n"
            "    r = p.add_run(text)\n"
            "    if i < 2:\n"
            "        r.add_tab()\n"
            "p.add_run().add_break()  # trailing line break"
        ),
        tags=("extreme", "run"),
    ),

    # ---- All WD_BREAK variants ----
    ComplexCase(
        name="ex17_all_break_kinds",
        description="Exercise LINE and PAGE breaks",
        script=(
            "from docx.enum.text import WD_BREAK\n"
            "p = doc.add_paragraph()\n"
            "p.add_run('before line').add_break(WD_BREAK.LINE)\n"
            "p.add_run('after line').add_break(WD_BREAK.PAGE)\n"
            "p.add_run('after page break')"
        ),
        tags=("extreme", "run"),
    ),

    # ---- Read back after adding lots of content ----
    ComplexCase(
        name="ex18_read_back_large_doc",
        description="After building a huge doc, iterate and assert counts",
        script=(
            "# Build\n"
            "for i in range(50):\n"
            "    doc.add_heading(f'H {i}', level=(i % 6) + 1)\n"
            "    doc.add_paragraph(f'Body {i}')\n"
            "# Verify\n"
            "ps = doc.paragraphs\n"
            "assert len(ps) == 100, len(ps)\n"
            "# Some content assertions\n"
            "bodies = [p for p in ps if p.text.startswith('Body')]\n"
            "assert len(bodies) == 50, len(bodies)"
        ),
        tags=("extreme", "iteration"),
    ),

    # ---- Mutating runs after iteration ----
    ComplexCase(
        name="ex19_mutate_all_runs",
        description="Read doc.paragraphs, then mutate every run's text",
        script=(
            "for i in range(5):\n"
            "    p = doc.add_paragraph()\n"
            "    for j in range(3):\n"
            "        p.add_run(f'w{i}{j} ')\n"
            "# Now mutate\n"
            "for p in doc.paragraphs:\n"
            "    for r in p.runs:\n"
            "        r.bold = True"
        ),
        tags=("extreme", "run", "iteration"),
    ),

    # ---- Full kitchen-sink v2 ----
    ComplexCase(
        name="ex20_kitchen_sink_v2",
        description="Huge multi-chapter doc with every feature lightly touched",
        script=(
            "from docx.shared import Inches, Pt, RGBColor\n"
            "from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING, WD_BREAK\n"
            "from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT\n"
            "from docx.enum.section import WD_ORIENTATION, WD_SECTION_START\n"
            "\n"
            "# Section setup\n"
            "s0 = doc.sections[0]\n"
            "s0.top_margin = Inches(1)\n"
            "s0.bottom_margin = Inches(1)\n"
            "s0.left_margin = Inches(1.25)\n"
            "s0.right_margin = Inches(1.25)\n"
            "s0.orientation = WD_ORIENTATION.PORTRAIT\n"
            "\n"
            "# Title page\n"
            "t = doc.add_heading('Comprehensive Report', level=0)\n"
            "t.alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            "subtitle = doc.add_paragraph()\n"
            "subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER\n"
            "sr = subtitle.add_run('A Study in Widget Dynamics')\n"
            "sr.italic = True\n"
            "sr.font.size = Pt(14)\n"
            "\n"
            "# Page break to TOC\n"
            "doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)\n"
            "doc.add_heading('Contents', level=1)\n"
            "for i in range(1, 6):\n"
            "    p = doc.add_paragraph(f'{i}. Chapter {i}')\n"
            "    p.paragraph_format.first_line_indent = Inches(0.25)\n"
            "\n"
            "# Chapters\n"
            "for chap in range(1, 6):\n"
            "    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)\n"
            "    doc.add_heading(f'Chapter {chap}', level=1)\n"
            "    for sec in range(1, 4):\n"
            "        doc.add_heading(f'{chap}.{sec} Section', level=2)\n"
            "        body = doc.add_paragraph()\n"
            "        body.paragraph_format.first_line_indent = Inches(0.5)\n"
            "        body.paragraph_format.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE\n"
            "        body_r = body.add_run(\n"
            "            'Body paragraph with substantive content. ' * 6\n"
            "        )\n"
            "        # Insert a table every third section\n"
            "        if sec == 3:\n"
            "            table = doc.add_table(rows=3, cols=4, style='TableGrid')\n"
            "            table.alignment = WD_TABLE_ALIGNMENT.CENTER\n"
            "            for c_idx, h in enumerate(['Metric', 'Before', 'After', 'Δ']):\n"
            "                cell = table.cell(0, c_idx)\n"
            "                cell.text = h\n"
            "                cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER\n"
            "                if cell.paragraphs and cell.paragraphs[0].runs:\n"
            "                    cell.paragraphs[0].runs[0].bold = True\n"
            "            for r_idx, vals in enumerate([\n"
            "                ('Revenue', '$1M', '$2M', '+100%'),\n"
            "                ('NPS', '30', '50', '+67%'),\n"
            "            ], start=1):\n"
            "                for c_idx, v in enumerate(vals):\n"
            "                    table.cell(r_idx, c_idx).text = v\n"
            "\n"
            "# Landscape appendix\n"
            "app_s = doc.add_section(WD_SECTION_START.NEW_PAGE)\n"
            "app_s.orientation = WD_ORIENTATION.LANDSCAPE\n"
            "app_s.page_width = Inches(11)\n"
            "app_s.page_height = Inches(8.5)\n"
            "doc.add_heading('Appendix A: Wide Data', level=1)\n"
            "wide = doc.add_table(rows=3, cols=8, style='TableGrid')\n"
            "for r in range(3):\n"
            "    for c in range(8):\n"
            "        wide.cell(r, c).text = f'{r}-{c}'"
        ),
        tags=("extreme", "kitchen_sink"),
    ),
]
