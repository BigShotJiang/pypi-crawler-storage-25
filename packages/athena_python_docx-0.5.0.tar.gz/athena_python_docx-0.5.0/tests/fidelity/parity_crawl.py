"""Crawl stock python-docx and our SDK to produce a parity spec.

Walks every public class and module member exposed by python-docx 1.x,
records the full signature + docstring first line + property kind, then
does the same for our SDK and diffs.

Emits `parity_spec.json` for the coverage tracker + a human-readable
summary of gaps.

Run:
    .venv-pydocx/bin/python tests/fidelity/parity_crawl.py --stock
    .venv/bin/python tests/fidelity/parity_crawl.py --ours
    .venv/bin/python tests/fidelity/parity_crawl.py --diff
"""

from __future__ import annotations

import argparse
import importlib
import inspect
import json
import sys
from pathlib import Path

SDK_ROOT = Path(__file__).resolve().parents[2]
_STOCK_VENV = SDK_ROOT / ".venv-pydocx" / "lib"
_PARITY_SPEC = SDK_ROOT / "tests" / "fidelity" / "parity_spec.json"


# python-docx public modules we care about (stable public API).
_PUBLIC_MODULES = [
    "docx",
    "docx.api",
    "docx.document",
    "docx.enum.text",
    "docx.enum.section",
    "docx.enum.table",
    "docx.enum.style",
    "docx.opc.coreprops",
    "docx.section",
    "docx.settings",
    "docx.shape",
    "docx.shared",
    "docx.styles.style",
    "docx.styles.styles",
    "docx.table",
    "docx.text.font",
    "docx.text.hyperlink",
    "docx.text.paragraph",
    "docx.text.parfmt",
    "docx.text.run",
]


def _crawl_one(mod_path: str) -> dict:
    try:
        mod = importlib.import_module(mod_path)
    except Exception as e:
        return {"__error__": f"import failed: {e!r}"}
    out: dict = {}
    for name, obj in inspect.getmembers(mod):
        if name.startswith("_"):
            continue
        qualname = f"{mod_path}.{name}"
        try:
            if inspect.isclass(obj) and obj.__module__.startswith("docx"):
                out[qualname] = _crawl_class(obj)
            elif inspect.isfunction(obj) and obj.__module__.startswith("docx"):
                out[qualname] = _entry("function", obj)
            elif inspect.ismodule(obj):
                continue
            # Bare classes from enum live here too.
        except Exception as e:
            out[qualname] = {"__error__": repr(e)}
    return out


# Inherited-from-builtin names we never want to treat as API surface.
_NOISE_MEMBERS = frozenset({
    # int
    "as_integer_ratio", "bit_count", "bit_length", "conjugate",
    "denominator", "from_bytes", "imag", "is_integer",
    "numerator", "real", "to_bytes",
    # str
    "capitalize", "casefold", "center", "count", "encode",
    "endswith", "expandtabs", "find", "format", "format_map",
    "index", "isalnum", "isalpha", "isascii", "isdecimal",
    "isdigit", "isidentifier", "islower", "isnumeric",
    "isprintable", "isspace", "istitle", "isupper", "join",
    "ljust", "lower", "lstrip", "maketrans", "partition",
    "removeprefix", "removesuffix", "replace", "rfind",
    "rindex", "rjust", "rpartition", "rsplit", "rstrip",
    "split", "splitlines", "startswith", "strip", "swapcase",
    "title", "translate", "upper", "zfill",
    # tuple (RGBColor)
    "count", "index",
    # enum-specific
    "name", "value",
})


def _crawl_class(cls) -> dict:
    entry = {
        "kind": "class",
        "bases": [b.__name__ for b in cls.__bases__ if b is not object],
        "doc": _first_line(cls.__doc__),
        "members": {},
    }
    for name, member in inspect.getmembers(cls):
        if name.startswith("_"):
            continue
        if name in _NOISE_MEMBERS:
            continue
        try:
            if isinstance(member, property):
                entry["members"][name] = {
                    "kind": "property",
                    "doc": _first_line(member.__doc__),
                    "readable": member.fget is not None,
                    "writable": member.fset is not None,
                }
            elif callable(member):
                entry["members"][name] = _entry("method", member)
            else:
                # Class-level constants (enum values)
                entry["members"][name] = {
                    "kind": "attribute",
                    "repr": repr(member)[:120],
                }
        except Exception as e:
            entry["members"][name] = {"__error__": repr(e)}
    return entry


def _entry(kind: str, obj) -> dict:
    try:
        sig = str(inspect.signature(obj))
    except (TypeError, ValueError):
        sig = "(?)"
    return {
        "kind": kind,
        "signature": sig,
        "doc": _first_line(getattr(obj, "__doc__", "")),
    }


def _first_line(text: str | None) -> str:
    if not text:
        return ""
    return text.strip().splitlines()[0][:160]


def crawl_all() -> dict:
    return {m: _crawl_one(m) for m in _PUBLIC_MODULES}


def diff_specs(stock: dict, ours: dict) -> dict:
    """Compare stock vs ours at the member level."""
    report: dict = {"missing_modules": [], "missing_classes": [], "missing_members": [], "signature_mismatches": []}
    for mod_path, s_entries in stock.items():
        o_entries = ours.get(mod_path, {})
        if not o_entries or "__error__" in o_entries:
            report["missing_modules"].append(mod_path)
            continue
        for qual, s_entry in s_entries.items():
            o_entry = o_entries.get(qual)
            if o_entry is None:
                if s_entry.get("kind") == "class":
                    report["missing_classes"].append(qual)
                else:
                    report["missing_members"].append(qual)
                continue
            if s_entry.get("kind") == "class":
                for m_name, s_member in s_entry.get("members", {}).items():
                    o_member = o_entry.get("members", {}).get(m_name)
                    if o_member is None:
                        report["missing_members"].append(f"{qual}.{m_name}")
                        continue
                    s_sig = s_member.get("signature", "")
                    o_sig = o_member.get("signature", "")
                    if s_sig and o_sig and s_sig != o_sig and s_member.get("kind") != "property":
                        report["signature_mismatches"].append({
                            "path": f"{qual}.{m_name}",
                            "stock": s_sig,
                            "ours": o_sig,
                        })
            else:
                # function-level sig compare
                s_sig = s_entry.get("signature", "")
                o_sig = o_entry.get("signature", "")
                if s_sig and o_sig and s_sig != o_sig:
                    report["signature_mismatches"].append({
                        "path": qual,
                        "stock": s_sig,
                        "ours": o_sig,
                    })
    return report


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stock", action="store_true", help="crawl stock python-docx, write stock_spec.json")
    parser.add_argument("--ours", action="store_true", help="crawl our SDK, write ours_spec.json")
    parser.add_argument("--diff", action="store_true", help="diff and print summary")
    args = parser.parse_args()
    if args.stock:
        spec = crawl_all()
        out = SDK_ROOT / "tests" / "fidelity" / "stock_spec.json"
        out.write_text(json.dumps(spec, indent=2))
        total_members = sum(
            len(entry.get("members", {}))
            for mod in spec.values()
            for entry in mod.values()
            if isinstance(entry, dict) and entry.get("kind") == "class"
        )
        print(f"[stock] wrote {out} — {len(_PUBLIC_MODULES)} modules, {total_members} class members")
        return 0
    if args.ours:
        spec = crawl_all()
        out = SDK_ROOT / "tests" / "fidelity" / "ours_spec.json"
        out.write_text(json.dumps(spec, indent=2))
        total_members = sum(
            len(entry.get("members", {}))
            for mod in spec.values()
            for entry in mod.values()
            if isinstance(entry, dict) and entry.get("kind") == "class"
        )
        print(f"[ours] wrote {out} — {len(_PUBLIC_MODULES)} modules, {total_members} class members")
        return 0
    if args.diff:
        stock_path = SDK_ROOT / "tests" / "fidelity" / "stock_spec.json"
        ours_path = SDK_ROOT / "tests" / "fidelity" / "ours_spec.json"
        if not stock_path.exists() or not ours_path.exists():
            print("run --stock then --ours first")
            return 1
        stock = json.loads(stock_path.read_text())
        ours = json.loads(ours_path.read_text())
        report = diff_specs(stock, ours)

        out = SDK_ROOT / "tests" / "fidelity" / "parity_diff.json"
        out.write_text(json.dumps(report, indent=2))
        print("=== PARITY DIFF ===")
        print(f"  Missing modules:       {len(report['missing_modules'])}")
        print(f"  Missing classes:       {len(report['missing_classes'])}")
        print(f"  Missing members:       {len(report['missing_members'])}")
        print(f"  Signature mismatches:  {len(report['signature_mismatches'])}")
        if report["missing_classes"]:
            print("\nMissing classes:")
            for c in report["missing_classes"][:20]:
                print(f"  - {c}")
        if report["missing_members"]:
            print("\nMissing members (first 30):")
            for m in report["missing_members"][:30]:
                print(f"  - {m}")
        if report["signature_mismatches"]:
            print("\nSignature mismatches (first 15):")
            for m in report["signature_mismatches"][:15]:
                print(f"  - {m['path']}: stock={m['stock']} ours={m['ours']}")
        print(f"\nFull diff: {out}")
        return 0
    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
