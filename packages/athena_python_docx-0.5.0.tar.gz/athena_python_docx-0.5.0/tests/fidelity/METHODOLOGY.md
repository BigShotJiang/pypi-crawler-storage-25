# Fidelity Testing Methodology

A multi-layer strategy to reach 100% coverage of the python-docx API surface
that `athena-python-docx` claims to replicate. Each layer catches a different
class of drift between our Superdoc-backed implementation and stock python-docx.

## Layers

| # | Layer | Catches | Runtime |
|---|---|---|---|
| L1 | **Import surface parity** — tests that every public class/method/property python-docx exposes is importable from our SDK. | Missing API surface (AttributeError in user code). | <1s, local. |
| L2 | **Signature parity** — inspect.signature on every public callable must match python-docx (or be a documented deviation). | Parameter renames, missing optional args. | <1s, local. |
| L3 | **Enum value parity** — every WD_* enum has matching member names + values. | Silent failure when agent passes `WD_ALIGN_PARAGRAPH.DISTRIBUTE`. | <1s, local. |
| L4 | **Local behavior (fake-session)** — 147 cases in `complex_cases/real_world_cases/extreme_cases/mega_cases` run through our SDK with `FakeSession` recording every Superdoc op. | NotImplementedError stubs, AttributeError, logic errors. | ~10s, local. |
| L5 | **Op-trace snapshot** — each case's recorded Superdoc-op sequence is pinned. Regressions show up as op-count or op-sequence diffs. | Refactor drift (e.g. switching from `doc.replace` to `doc.insert`). | <1s, local. |
| L6 | **Property round-trip** — for every setter, the getter returns the value (or a normalized form). | Cosmetic read/write asymmetry. | ~10s, local. |
| L7 | **Binary round-trip vs stock python-docx** — each case's script is run by stock python-docx to produce a reference `.docx` and by our SDK's fake session to produce an in-memory model. Extracted features (para text, style, runs + formatting, table cells, alignment, indent, spacing) are diff'd. | Structural differences not caught by op-tracing. | ~20s, local. |
| L8 | **Daytona + real Keryx** (`runner.py`) — our SDK runs inside a document-exec sandbox against a live Superdoc doc, exports the resulting `.docx`, and that `.docx` is diff'd against the stock-generated reference. | Protocol/server mismatches (like the `_Cell.text` `getNodeById` walker that worked in the fake but failed against real Superdoc). | ~3m, network. |
| L9 | **Real exported-docx feature diff** — exports both sides' `.docx` files open them with stock python-docx and compare the extracted semantic feature set (runs, fonts, tables, sections, headers). | Visual drift after Superdoc's OOXML serialization. | ~30s incremental. |
| L10 | **Agent-in-the-loop replay** — pull failing LangSmith sessions, extract the `code` the agent tried to run, and replay each against the current SDK + Daytona. | Real-world failures we missed in design. | ~1m per session. |

## Roadmap to 100% python-docx coverage

### Phase 1: Inventory

Crawl stock python-docx and produce the exhaustive list of callables and
properties to cover. Use `inspect.getmembers` + `typing.get_type_hints`.

Output: `tests/fidelity/parity_spec.json` — one entry per `(module.path,
member)` tuple with signature, docstring, return type.

### Phase 2: Surface-coverage tracker

Per-member status in a spreadsheet-like JSON:

```json
{
  "docx.text.paragraph.Paragraph.alignment": {
    "status": "implemented",
    "signature_match": true,
    "round_trip_tested": true,
    "binary_diff_ok": true,
    "live_daytona_ok": true,
    "first_shipped": "0.2.0"
  },
  "docx.text.font.Font.highlight_color": {
    "status": "implemented",
    ...
  },
  "docx.section.Section.first_page_footer": {
    "status": "stub",
    "signature_match": true,
    "round_trip_tested": false,
    "blocker": "Header/Footer paragraph iteration requires doc.headerFooters.parts.list + per-part getNodeById, not yet wired."
  }
}
```

A CI job blocks merges that decrease coverage.

### Phase 3: Generated cases

For every python-docx public method, auto-generate a minimum-viable test
case from its signature: "call with each required param filled by a
representative value, assert no exception, assert getter round-trip where
applicable." ~200 cases generated automatically.

### Phase 4: Property-based tests

Use `hypothesis` to fuzz lengths, unicode, nested tables, merge cells,
margin values — the kind of inputs that production agents generate but
hand-written tests miss.

### Phase 5: Docx corpus replay

Collect a corpus of real-world .docx files from:
- python-docx's test fixtures on GitHub
- Tutorials that emit full documents (MSDN, textbook samples)
- Agora's staging assets exported to .docx

For each: run `Document.from_file(path)` (Phase 2 feature), mutate via
our SDK, re-export, compare.

### Phase 6: Agent behavioral replay

Daily job scans the last 24h of `agora-staging` and `agora-production`
langsmith traces for `execute_word_document_code` tool calls. Extracts
the `code` argument, deduplicates by script fingerprint, and runs each
through the Daytona-backed runner. Any new failure is opened as a gap.

### Phase 7: Coverage percentage

The scorecard reports:
```
python-docx API coverage:
  Classes:     28 / 30  (93%)
  Methods:     142 / 156  (91%)
  Properties:  287 / 302  (95%)
  Enum values: 67 / 73  (92%)

Round-trip fidelity:
  Binary match rate:    112 / 112  (100%)
  Live Daytona pass:    15 / 15  (100%)
  Property getter/setter round-trips: 82 / 85  (96%)
```

Target: every row at 100%, with deviations documented in CLAUDE.md.
