"""Auto-generate test cases from python-docx's public API surface.

For every `(ClassName, method_or_property)` pair python-docx exposes that
our SDK claims to support, emit a minimum-viable test case that:
  - constructs the relevant object (via a small set of hand-written fixtures)
  - invokes the method / sets the property
  - asserts no exception is raised

The generated cases live in memory; run via `auto_gen_cases.run_all`.
Complements hand-written cases by guaranteeing every surface has at least
one exercise path.
"""

from __future__ import annotations

import argparse
import sys
import traceback
from pathlib import Path
from typing import Any, Callable

_SDK_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_SDK_ROOT))

from tests.fidelity.fake_session import install_fake_session  # noqa: E402


# ── Representative values per type ───────────────────────────────────


def _rep_value(param_name: str, param_type: str, obj_context: str) -> Any:
    """Pick a representative value for a parameter name+type hint."""
    from docx.enum.table import (
        WD_ROW_HEIGHT_RULE,
    )
    from docx.enum.text import (
        WD_ALIGN_PARAGRAPH,
        WD_COLOR_INDEX,
    )
    from docx.enum.section import WD_ORIENTATION, WD_SECTION_START
    from docx.shared import Inches, Pt, RGBColor

    name = param_name.lower()
    type_str = param_type.lower()
    # Booleans
    if "bool" in type_str or name in ("bold", "italic", "underline", "active"):
        return True
    # String literals
    if "str" in type_str or name in ("text", "name", "style", "id", "label"):
        return "sample"
    # Lengths
    if "length" in type_str or "emu" in type_str or "inches" in type_str or "pt " in type_str:
        return Inches(1)
    if name in ("width", "height", "size") and "int" in type_str:
        return Pt(12)
    if "rgb" in type_str or "color" in name:
        return RGBColor(0, 0, 0)
    if "int" in type_str or "number" in type_str:
        if "level" in name:
            return 1
        if name in ("rows", "cols", "rowindex", "columnindex"):
            return 2
        return 1
    # Enums
    if "alignment" in name:
        return WD_ALIGN_PARAGRAPH.CENTER
    if "orientation" in name:
        return WD_ORIENTATION.PORTRAIT
    if "start_type" in name or "break_type" in name:
        return WD_SECTION_START.NEW_PAGE
    if "highlight" in name:
        return WD_COLOR_INDEX.YELLOW
    if "rule" in name:
        return WD_ROW_HEIGHT_RULE.AT_LEAST
    return None


# ── Fixtures ──────────────────────────────────────────────────────────


def _fixture_new_doc() -> Any:
    install_fake_session()
    from docx import Document
    return Document("asset_fake")


_FIXTURES: dict[str, Callable[[Any], Any]] = {
    "Document": lambda doc: doc,
    "Paragraph": lambda doc: doc.add_paragraph("auto-gen"),
    "Run": lambda doc: doc.add_paragraph().add_run("auto-gen"),
    "Font": lambda doc: doc.add_paragraph().add_run("auto-gen").font,
    "ParagraphFormat": lambda doc: doc.add_paragraph("auto-gen").paragraph_format,
    "Table": lambda doc: doc.add_table(rows=2, cols=2),
    "_Cell": lambda doc: doc.add_table(rows=1, cols=1).cell(0, 0),
    "_Row": lambda doc: doc.add_table(rows=1, cols=1).rows[0],
    "_Column": lambda doc: doc.add_table(rows=1, cols=1).columns[0],
    "Section": lambda doc: doc.sections[0],
    "Styles": lambda doc: doc.styles,
    "CoreProperties": lambda doc: doc.core_properties,
    "InlineShapes": lambda doc: doc.inline_shapes,
    "Sections": lambda doc: doc.sections,
}


_PROPERTY_VALUES: dict[tuple[str, str], Any] = {}  # populated lazily


def _property_value(cls_name: str, prop: str) -> Any:
    from docx.enum.table import WD_ALIGN_VERTICAL, WD_ROW_HEIGHT_RULE, WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_COLOR_INDEX
    from docx.enum.section import WD_ORIENTATION
    from docx.shared import Inches, Pt

    # Hand-tuned per (class, property) — most important ones.
    mapping = {
        ("Paragraph", "text"): "text",
        ("Paragraph", "style"): "Normal",
        ("Paragraph", "alignment"): WD_ALIGN_PARAGRAPH.CENTER,
        ("Run", "text"): "text",
        ("Run", "bold"): True,
        ("Run", "italic"): True,
        ("Run", "underline"): True,
        ("Run", "style"): "Emphasis",
        ("Font", "name"): "Arial",
        ("Font", "size"): Pt(12),
        ("Font", "bold"): True,
        ("Font", "italic"): True,
        ("Font", "strike"): True,
        ("Font", "double_strike"): True,
        ("Font", "all_caps"): True,
        ("Font", "small_caps"): True,
        ("Font", "shadow"): True,
        ("Font", "outline"): True,
        ("Font", "emboss"): True,
        ("Font", "imprint"): True,
        ("Font", "hidden"): True,
        ("Font", "subscript"): True,
        ("Font", "superscript"): True,
        ("Font", "highlight_color"): WD_COLOR_INDEX.YELLOW,
        ("ParagraphFormat", "alignment"): WD_ALIGN_PARAGRAPH.CENTER,
        ("ParagraphFormat", "left_indent"): Inches(0.5),
        ("ParagraphFormat", "right_indent"): Inches(0.25),
        ("ParagraphFormat", "first_line_indent"): Inches(0.25),
        ("ParagraphFormat", "space_before"): Pt(12),
        ("ParagraphFormat", "space_after"): Pt(6),
        ("ParagraphFormat", "line_spacing"): 1.5,
        ("ParagraphFormat", "keep_together"): True,
        ("ParagraphFormat", "keep_with_next"): True,
        ("ParagraphFormat", "widow_control"): True,
        ("ParagraphFormat", "page_break_before"): True,
        ("Table", "style"): "TableGrid",
        ("Table", "alignment"): WD_TABLE_ALIGNMENT.CENTER,
        ("Table", "autofit"): True,
        ("_Cell", "text"): "cell body",
        ("_Cell", "vertical_alignment"): WD_ALIGN_VERTICAL.CENTER,
        ("_Cell", "width"): Inches(1),
        ("_Row", "height"): Pt(20),
        ("_Row", "height_rule"): WD_ROW_HEIGHT_RULE.AT_LEAST,
        ("_Column", "width"): Inches(1),
        ("Section", "page_width"): Inches(8.5),
        ("Section", "page_height"): Inches(11),
        ("Section", "orientation"): WD_ORIENTATION.PORTRAIT,
        ("Section", "left_margin"): Inches(1),
        ("Section", "right_margin"): Inches(1),
        ("Section", "top_margin"): Inches(1),
        ("Section", "bottom_margin"): Inches(1),
    }
    return mapping.get((cls_name, prop))


# ── Test runner ───────────────────────────────────────────────────────


def run_all() -> tuple[int, int, list[tuple[str, str]]]:
    """Run auto-generated tests; return (passed, total, failures)."""
    failures: list[tuple[str, str]] = []
    total = 0
    passed = 0
    for cls_name, fix in _FIXTURES.items():
        # Per-class: iterate known (class, property) pairs
        for (cname, prop), val in list(_PROPERTY_VALUES.items()):
            if cname != cls_name:
                continue
        # Use _property_value mapping: iterate all keys matching this class
        from docx.enum.table import WD_ALIGN_VERTICAL  # noqa: F401 — keeps import list alive
        mapping_keys = _collect_property_keys(cls_name)
        for prop in mapping_keys:
            val = _property_value(cls_name, prop)
            if val is None:
                continue
            total += 1
            doc = _fixture_new_doc()
            try:
                target = fix(doc)
                _set_nested(target, prop, val)
                # Round-trip read (best effort; skip if getter raises)
                try:
                    _ = _get_nested(target, prop)
                except Exception:
                    pass
                passed += 1
            except Exception as e:  # noqa: BLE001
                failures.append((f"{cls_name}.{prop}", f"{type(e).__name__}: {e}"))
            finally:
                try:
                    doc.close()
                except Exception:
                    pass
    return passed, total, failures


def _collect_property_keys(cls_name: str) -> list[str]:
    """Pull properties we have values for."""
    # Use introspection on the _property_value mapping: easiest way
    # without duplicating data is to call it with each key and filter.
    all_keys = [
        "text", "style", "alignment", "bold", "italic", "underline",
        "name", "size", "strike", "double_strike", "all_caps", "small_caps",
        "shadow", "outline", "emboss", "imprint", "hidden", "subscript",
        "superscript", "highlight_color", "left_indent", "right_indent",
        "first_line_indent", "space_before", "space_after", "line_spacing",
        "keep_together", "keep_with_next", "widow_control", "page_break_before",
        "autofit", "vertical_alignment", "width", "height", "height_rule",
        "page_width", "page_height", "orientation", "left_margin",
        "right_margin", "top_margin", "bottom_margin",
    ]
    return [k for k in all_keys if _property_value(cls_name, k) is not None]


def _set_nested(obj: Any, path: str, value: Any) -> None:
    parts = path.split(".")
    for p in parts[:-1]:
        obj = getattr(obj, p)
    setattr(obj, parts[-1], value)


def _get_nested(obj: Any, path: str) -> Any:
    for p in path.split("."):
        obj = getattr(obj, p)
    return obj


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()
    passed, total, failures = run_all()
    for name, err in failures:
        print(f"  ❌ {name:45} — {err}")
        if args.verbose:
            traceback.print_exc()
    print()
    print(f"Auto-generated fidelity: {passed}/{total} passed")
    if failures:
        print(f"Failures: {len(failures)}")
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
