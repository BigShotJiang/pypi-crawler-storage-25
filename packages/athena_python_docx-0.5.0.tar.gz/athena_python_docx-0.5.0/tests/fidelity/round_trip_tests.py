"""Layer 6 — property round-trip harness.

For every `(setter, getter)` pair in our SDK, verify that after setting
a value the getter returns the same value (or a deterministic
normalization).

Properties to test are enumerated from `parity_spec` — only those that
stock python-docx exposes as read/write and that we actually implement.

Run:
    .venv/bin/python tests/fidelity/round_trip_tests.py
    .venv/bin/python tests/fidelity/round_trip_tests.py --verbose
"""

from __future__ import annotations

import argparse
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

_SDK_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_SDK_ROOT))

from tests.fidelity.fake_session import install_fake_session  # noqa: E402


@dataclass
class RoundTripCase:
    name: str
    setup: Callable[[Any], Any]  # (doc) -> object to test against
    prop: str
    value: Any
    expected_getter: Callable[[Any], bool] | None = None  # validator


def _eq(v: Any) -> Callable[[Any], bool]:
    return lambda got: got == v


def _value_equals(expected: Any) -> Callable[[Any], bool]:
    return lambda got: got is not None and got == expected


def _length_within(expected_pt: float, tol: float = 0.5) -> Callable[[Any], bool]:
    from docx.shared import Length

    def check(got: Any) -> bool:
        if got is None:
            return False
        if isinstance(got, Length) or hasattr(got, "pt"):
            return abs(float(got.pt) - expected_pt) < tol
        return False

    return check


# ── Cases ─────────────────────────────────────────────────────────────


def _cases() -> list[RoundTripCase]:
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Inches, Pt, RGBColor

    def _paragraph(doc):
        return doc.add_paragraph("round-trip target")

    def _heading(doc):
        return doc.add_heading("heading", level=1)

    def _run(doc):
        p = doc.add_paragraph()
        return p.add_run("run target")

    def _cell(doc):
        t = doc.add_table(rows=1, cols=1)
        return t.cell(0, 0)

    cases: list[RoundTripCase] = [
        # Paragraph-level
        RoundTripCase(
            "Paragraph.text",
            _paragraph,
            "text",
            "new text",
            _eq("new text"),
        ),
        RoundTripCase(
            "Paragraph.alignment (CENTER)",
            _paragraph,
            "alignment",
            WD_ALIGN_PARAGRAPH.CENTER,
            _eq(WD_ALIGN_PARAGRAPH.CENTER),
        ),
        RoundTripCase(
            "Paragraph.alignment (RIGHT)",
            _paragraph,
            "alignment",
            WD_ALIGN_PARAGRAPH.RIGHT,
            _eq(WD_ALIGN_PARAGRAPH.RIGHT),
        ),
        # ParagraphFormat
        RoundTripCase(
            "ParagraphFormat.left_indent",
            _paragraph,
            "paragraph_format.left_indent",
            Inches(0.5),
            _length_within(36),
        ),
        RoundTripCase(
            "ParagraphFormat.space_before",
            _paragraph,
            "paragraph_format.space_before",
            Pt(12),
            _length_within(12),
        ),
        RoundTripCase(
            "ParagraphFormat.space_after",
            _paragraph,
            "paragraph_format.space_after",
            Pt(6),
            _length_within(6),
        ),
        # Run
        RoundTripCase("Run.text", _run, "text", "updated", _eq("updated")),
        RoundTripCase("Run.bold", _run, "bold", True, _eq(True)),
        RoundTripCase("Run.italic", _run, "italic", True, _eq(True)),
        # Font.size/name/color
        RoundTripCase(
            "Font.size",
            _run,
            "font.size",
            Pt(18),
            _length_within(18),
        ),
        RoundTripCase(
            "Font.color.rgb",
            _run,
            "font.color.rgb",
            RGBColor(0x11, 0x22, 0x33),
            lambda got: got is not None and str(got) == "112233",
        ),
        # Font booleans
        RoundTripCase("Font.strike", _run, "font.strike", True, _eq(True)),
        RoundTripCase("Font.all_caps", _run, "font.all_caps", True, _eq(True)),
        RoundTripCase("Font.small_caps", _run, "font.small_caps", True, _eq(True)),
        RoundTripCase("Font.shadow", _run, "font.shadow", True, _eq(True)),
        # Cell.text (on freshly-created cell)
        RoundTripCase("Cell.text", _cell, "text", "A1", _eq("A1")),
    ]
    return cases


def _set_nested(obj: Any, path: str, value: Any) -> None:
    """Walk `a.b.c` attribute path and assign value."""
    parts = path.split(".")
    for p in parts[:-1]:
        obj = getattr(obj, p)
    setattr(obj, parts[-1], value)


def _get_nested(obj: Any, path: str) -> Any:
    parts = path.split(".")
    for p in parts:
        obj = getattr(obj, p)
    return obj


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    install_fake_session()
    from docx import Document

    passes = 0
    failures: list[tuple[str, str]] = []
    for case in _cases():
        doc = Document("asset_fake")
        try:
            target = case.setup(doc)
            _set_nested(target, case.prop, case.value)
            got = _get_nested(target, case.prop)
            if case.expected_getter is None:
                ok = got is not None
            else:
                ok = bool(case.expected_getter(got))
            if ok:
                passes += 1
                print(f"  ✅ {case.name:45}")
            else:
                print(f"  ❌ {case.name:45} — got {got!r}, wanted {case.value!r}")
                failures.append((case.name, f"got {got!r}"))
        except Exception as e:  # noqa: BLE001
            print(f"  💥 {case.name:45} — {type(e).__name__}: {e}")
            if args.verbose:
                traceback.print_exc()
            failures.append((case.name, repr(e)))
        finally:
            doc.close()

    total = len(_cases())
    print()
    print(f"Results: {passes}/{total} round-trips matched")
    if failures:
        print(f"Failures: {len(failures)}")
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
