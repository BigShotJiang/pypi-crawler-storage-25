"""Tests for the HTTP transport — the path-walking proxy that turns
``doc.create.paragraph(p)`` into a typed POST /commands round-trip.

Mocks ``requests.Session.post`` so no network is needed.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any
from unittest.mock import patch

import pytest
import requests

from docx import __version__ as SDK_VERSION
from docx._http_doc import HttpClient, HttpDocHandle
from docx.errors import AuthenticationError, DocxError, SessionError


class _FakeResponse:
    """Minimal stand-in for requests.Response.

    Only implements the surface our HTTP client touches: ``status_code``,
    ``text``, and ``json()``.
    """

    def __init__(self, *, status_code: int, body: bytes | str) -> None:
        self.status_code = status_code
        if isinstance(body, bytes):
            self._body_bytes = body
            self._body_text = body.decode("utf-8", errors="replace")
        else:
            self._body_bytes = body.encode("utf-8")
            self._body_text = body

    @property
    def text(self) -> str:
        return self._body_text

    def json(self) -> Any:
        return json.loads(self._body_text)


def _ok_body(applied_results: list[dict[str, Any]]) -> bytes:
    return json.dumps(
        {"assetId": "asset_test", "applied": applied_results},
    ).encode("utf-8")


def test_path_proxy_walks_dotted_path() -> None:
    """``doc.create.paragraph(p)`` should POST one command with type
    ``CreateParagraph`` and the params hoisted as flat fields. ``create.*``
    is response-bearing so the call flushes eagerly."""
    captured: dict[str, Any] = {}

    def _capture(url: str, **kwargs: Any) -> _FakeResponse:
        captured["url"] = url
        captured["body"] = json.loads(kwargs["data"].decode("utf-8"))
        captured["auth"] = kwargs["headers"].get("Authorization")
        return _FakeResponse(
            status_code=200,
            body=_ok_body(
                [{"index": 0, "type": "CreateParagraph", "result": {"nodeId": "para_42"}}],
            ),
        )

    client = HttpClient(base_url="https://example.com", api_key="bg_key")

    with patch.object(client._session, "post", side_effect=_capture):
        doc = HttpDocHandle(client, "asset_8eaf4c95")
        result = asyncio.run(
            doc.create.paragraph({"text": "hi", "at": {"kind": "documentEnd"}}),
        )

    assert result == {"nodeId": "para_42"}
    assert captured["url"] == "https://example.com/docs/asset_8eaf4c95/commands"
    assert captured["auth"] == "Bearer bg_key"
    body = captured["body"]
    assert body["client"] == {"type": "python-sdk", "version": SDK_VERSION}
    assert body["return"] == {"snapshot": False}
    assert body["commands"] == [
        {"type": "CreateParagraph", "text": "hi", "at": {"kind": "documentEnd"}},
    ]


def test_deeply_nested_paths() -> None:
    """``doc.format.paragraph.set_alignment(p)`` walks three levels and
    serializes as ``SetParagraphAlignment``. It's a pure mutation, so it
    buffers — the explicit ``buffer.flush()`` triggers the POST."""
    captured: dict[str, Any] = {}

    def _capture(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        captured["body"] = json.loads(kwargs["data"].decode("utf-8"))
        return _FakeResponse(
            status_code=200,
            body=_ok_body(
                [{"index": 0, "type": "SetParagraphAlignment", "result": {}}],
            ),
        )

    client = HttpClient(base_url="https://example.com", api_key="bg_key")

    with patch.object(client._session, "post", side_effect=_capture):
        doc = HttpDocHandle(client, "asset_test")
        asyncio.run(
            doc.format.paragraph.set_alignment(
                {
                    "target": {"kind": "block", "nodeType": "paragraph", "nodeId": "p1"},
                    "alignment": "center",
                },
            ),
        )
        # Pure mutations buffer; force the flush so the assertion below
        # has a body to inspect.
        doc.buffer.flush()

    cmd = captured["body"]["commands"][0]
    assert cmd["type"] == "SetParagraphAlignment"
    assert cmd["alignment"] == "center"


def test_401_maps_to_auth_error() -> None:
    client = HttpClient(base_url="https://example.com", api_key="bad")

    def _401(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        return _FakeResponse(status_code=401, body=b'{"error":"bad key"}')

    with patch.object(client._session, "post", side_effect=_401):
        doc = HttpDocHandle(client, "asset_test")
        with pytest.raises(AuthenticationError, match="HTTP 401"):
            asyncio.run(
                doc.create.paragraph({"text": "x", "at": {"kind": "documentEnd"}}),
            )


def test_500_maps_to_docx_error() -> None:
    client = HttpClient(base_url="https://example.com", api_key="ok")

    def _500(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        return _FakeResponse(status_code=500, body=b'{"error":"boom"}')

    with patch.object(client._session, "post", side_effect=_500):
        doc = HttpDocHandle(client, "asset_test")
        with pytest.raises(DocxError, match="HTTP 500"):
            asyncio.run(
                doc.create.paragraph({"text": "x", "at": {"kind": "documentEnd"}}),
            )


def test_unreachable_server_maps_to_session_error() -> None:
    client = HttpClient(base_url="https://nope", api_key="ok")

    def _down(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        raise requests.ConnectionError("connection refused")

    with patch.object(client._session, "post", side_effect=_down):
        doc = HttpDocHandle(client, "asset_test")
        with pytest.raises(SessionError, match="Unable to reach"):
            asyncio.run(
                doc.create.paragraph({"text": "x", "at": {"kind": "documentEnd"}}),
            )


def test_dunder_attrs_dont_deepen_path() -> None:
    """``__getattr__`` must reject Python special-name lookups so
    iteration / hash don't silently extend the path."""
    client = HttpClient(base_url="https://example.com", api_key="ok")
    doc = HttpDocHandle(client, "asset_test")

    with pytest.raises(AttributeError):
        _ = doc.__iter__  # noqa: B018

    proxy = doc.create
    with pytest.raises(AttributeError):
        _ = proxy.__iter__  # noqa: B018
