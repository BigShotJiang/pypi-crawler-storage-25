"""Cross-language wire-contract test.

This complements ``test_wire_contract.py`` (Python-only) by closing the
loop on the OTHER side of the boundary: every fixture must pass the
apps/api Zod ``SdkCommandSchema`` validator. The detection target:

* Python-side dataclass field name drifts from the Zod schema name.
  Today the apps/api applier punts SuperDoc's strict types via
  ``AnyDoc``, so ``bun run typecheck`` cannot catch this. Real bugs
  surface only at runtime when the Fastify validator rejects the
  payload at the production edge.

How it works:

1. For every op in ``_OP_TO_COMMAND``, build a Command via the
   path-proxy fixture in ``test_wire_contract._WIRE_FIXTURES``.
2. Serialise to wire JSON via ``cmd.to_dict()``.
3. Write the resulting ``{op_name: wire_dict}`` map to a tmp file.
4. Spawn ``bun run apps/api/scripts/validate-wire-fixtures.ts`` and
   pipe the file in via stdin. The validator runs each payload
   through ``SdkCommandSchema.safeParse(...)`` AND verifies no keys
   were silently stripped.
5. Assert exit-zero.

If ``bun`` is not on PATH the test is skipped — local dev without
bun shouldn't be a hard gate. CI always has bun.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import pytest

from tests.test_wire_contract import _WIRE_FIXTURES


_REPO_ROOT = Path(__file__).resolve().parents[3]
_VALIDATOR = (
    _REPO_ROOT
    / "docx-studio"
    / "apps"
    / "api"
    / "scripts"
    / "validate-wire-fixtures.ts"
)


@pytest.mark.skipif(
    shutil.which("bun") is None,
    reason="bun not on PATH — TS-side wire-contract validator can't run",
)
def test_every_fixture_validates_against_zod_command_schema(tmp_path: Path) -> None:
    """All fixtures must round-trip cleanly through the Zod
    discriminated-union ``SdkCommandSchema`` AND not lose any keys
    to silent-stripping.

    Failure modes this catches:
    - Python dataclass field name (e.g. ``linked_to_previous``)
      doesn't match the Zod schema name (e.g. ``linked``)
    - Python sends an extra key Zod doesn't know about (the schema
      strips it; SuperDoc never sees it)
    - Discriminator drift (``type`` field is a name Zod doesn't
      include in the union)
    - Required-field omission on the Zod side
    """
    from docx._http_doc import _OP_TO_COMMAND, _build_command

    # Build wire payloads for every registered op.
    wire_map: dict[str, dict] = {}
    for op_name, fixture in _WIRE_FIXTURES.items():
        cmd = _build_command(op_name, fixture)
        wire_map[op_name] = cmd.to_dict()

    # Sanity-check: every registered op covered.
    missing = set(_OP_TO_COMMAND.keys()) - set(wire_map.keys())
    assert not missing, (
        f"Wire fixtures missing for: {sorted(missing)}. "
        "test_wire_contract should have failed first — investigate."
    )

    fixtures_path = tmp_path / "wire_fixtures.json"
    fixtures_path.write_text(json.dumps(wire_map, indent=2))

    assert _VALIDATOR.exists(), (
        f"TS validator not found at {_VALIDATOR}. "
        "Did docx-studio/apps/api/scripts/validate-wire-fixtures.ts "
        "get moved or deleted?"
    )

    result = subprocess.run(
        ["bun", "run", str(_VALIDATOR), str(fixtures_path)],
        capture_output=True,
        text=True,
        timeout=60,
    )

    if result.returncode != 0:
        # Surface the validator's stdout/stderr verbatim so the
        # failing fixture and the Zod issue path land in the
        # pytest output without further translation.
        pytest.fail(
            f"TS-side wire-contract validator rejected fixtures:\n\n"
            f"--- stdout ---\n{result.stdout}\n"
            f"--- stderr ---\n{result.stderr}\n"
        )
