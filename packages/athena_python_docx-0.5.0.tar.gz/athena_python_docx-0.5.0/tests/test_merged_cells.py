"""Tests for merged-cell read-back behaviour.

python-docx semantics: when cells are merged, every grid position inside
the merge region is an alias of the master cell — reading
``cell(r,c).text`` returns the master's text regardless of which
position you ask for. This is the rw08 fidelity case that was the only
binary-round-trip diff in the parity gap analysis.

Drives the SDK's ``_Cell._cell_info`` against the FakeSession's grid
resolver (which mirrors real SuperDoc's behaviour: ``tables.getCells``
for a position inside a merge returns the master cell).
"""

from __future__ import annotations

from tests.fidelity.fake_session import install_fake_session


def test_horizontal_merge_aliases_text_across_positions() -> None:
    install_fake_session()
    from docx import Document

    doc = Document("asset_fake")
    t = doc.add_table(rows=3, cols=3)

    a = t.cell(0, 0)
    b = t.cell(0, 2)
    a.merge(b)
    a.text = "Header (merged)"

    # All three top-row positions resolve to the master.
    assert t.cell(0, 0).text == "Header (merged)"
    assert t.cell(0, 1).text == "Header (merged)"
    assert t.cell(0, 2).text == "Header (merged)"

    # Body cells are unaffected.
    for r in range(1, 3):
        for c in range(3):
            t.cell(r, c).text = f"r{r}c{c}"
    assert t.cell(1, 0).text == "r1c0"
    assert t.cell(2, 2).text == "r2c2"


def test_vertical_merge_aliases_text_across_positions() -> None:
    install_fake_session()
    from docx import Document

    doc = Document("asset_fake")
    t = doc.add_table(rows=3, cols=2)

    a = t.cell(0, 0)
    b = t.cell(2, 0)
    a.merge(b)
    a.text = "Spans 3 rows"

    assert t.cell(0, 0).text == "Spans 3 rows"
    assert t.cell(1, 0).text == "Spans 3 rows"
    assert t.cell(2, 0).text == "Spans 3 rows"
    # Adjacent column unaffected.
    assert t.cell(0, 1).text == ""


def test_unmerged_cells_unchanged() -> None:
    """Sanity: a regular table without any merges still works the same."""
    install_fake_session()
    from docx import Document

    doc = Document("asset_fake")
    t = doc.add_table(rows=2, cols=2)
    t.cell(0, 0).text = "A"
    t.cell(0, 1).text = "B"
    t.cell(1, 0).text = "C"
    t.cell(1, 1).text = "D"
    assert [
        [t.cell(r, c).text for c in range(2)] for r in range(2)
    ] == [["A", "B"], ["C", "D"]]
