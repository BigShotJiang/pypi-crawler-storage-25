"""Comment behavioral tests.

Verifies that ``Document.add_comment`` / ``Comments.add_comment`` /
``Comments.list`` / ``Run.mark_comment_range`` translate to the right
SuperDoc ``doc.comments.*`` ops.
"""

from __future__ import annotations

from typing import Any

import pytest


def _find_call(calls: list[tuple[str, Any]], op_name: str) -> tuple[str, Any] | None:
    for call in calls:
        if call[0] == op_name:
            return call
    return None


def _all_calls(calls: list[tuple[str, Any]], op_name: str) -> list[tuple[str, Any]]:
    return [c for c in calls if c[0] == op_name]


def _make_doc(mock_session: Any):
    from docx.document import Document

    doc = Document.__new__(Document)
    doc._session = mock_session
    doc._saved = False
    doc._closed = False
    return doc


def test_add_comment_unanchored_calls_comments_create(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    """Comments.add_comment(text) → comments.create({text}).

    No ``target`` should be sent — this is the unanchored path. SuperDoc
    derives the author from session credentials, so author / initials
    don't appear on the wire either.
    """
    from docx.comments import Comments

    fake_sd_methods.scripted_returns["comments.create"] = {
        "success": True,
        "inserted": [
            {"kind": "entity", "entityType": "comment", "entityId": "c-42"}
        ],
    }
    comments = Comments(session=mock_session)
    c = comments.add_comment("hello", author="Alice", initials="A")

    call = _find_call(fake_sd_methods.calls, "comments.create")
    assert call is not None
    _, params = call
    assert params == {"text": "hello"}
    # Returned proxy carries the round-tripped id + locally-recorded author.
    assert c.comment_id == "c-42"
    assert c.author == "Alice"
    assert c.initials == "A"
    assert c.text == "hello"


def test_document_add_comment_anchors_to_run_range(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    """doc.add_comment([run], "...") sends a text-range target."""
    from docx.text.run import Run

    fake_sd_methods.scripted_returns["comments.create"] = {
        "success": True,
        "inserted": [
            {"kind": "entity", "entityType": "comment", "entityId": "c-anchor"}
        ],
    }

    doc = _make_doc(mock_session)
    run = Run(session=mock_session, block_id="p1", range_=(0, 5))
    c = doc.add_comment([run], text="note", author="Bob")

    call = _find_call(fake_sd_methods.calls, "comments.create")
    assert call is not None
    _, params = call
    assert params["text"] == "note"
    assert params["target"] == {
        "kind": "text",
        "blockId": "p1",
        "range": {"start": 0, "end": 5},
    }
    assert c.comment_id == "c-anchor"


def test_document_add_comment_disjoint_blocks_unanchored(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    """Runs from different blocks → unanchored (no target) per Word's
    rule that a single comment can't span disjoint blocks."""
    from docx.text.run import Run

    fake_sd_methods.scripted_returns["comments.create"] = {
        "success": True,
        "inserted": [
            {"kind": "entity", "entityType": "comment", "entityId": "c-1"}
        ],
    }
    doc = _make_doc(mock_session)
    r1 = Run(session=mock_session, block_id="p1", range_=(0, 3))
    r2 = Run(session=mock_session, block_id="p2", range_=(0, 3))
    doc.add_comment([r1, r2], text="multi")

    call = _find_call(fake_sd_methods.calls, "comments.create")
    assert call is not None
    _, params = call
    assert "target" not in params


def test_run_mark_comment_range_patches_existing_comment(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    """run.mark_comment_range(last_run, comment_id) sends a comments.patch
    re-anchoring the comment to span both runs."""
    from docx.text.run import Run

    r1 = Run(session=mock_session, block_id="p1", range_=(0, 3))
    r2 = Run(session=mock_session, block_id="p1", range_=(7, 10))
    r1.mark_comment_range(r2, 99)

    call = _find_call(fake_sd_methods.calls, "comments.patch")
    assert call is not None
    _, params = call
    assert params["id"] == "99"
    assert params["target"] == {
        "kind": "text",
        "blockId": "p1",
        "range": {"start": 0, "end": 10},
    }


def test_run_mark_comment_range_rejects_cross_block_pair(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    from docx.text.run import Run

    r1 = Run(session=mock_session, block_id="pA", range_=(0, 3))
    r2 = Run(session=mock_session, block_id="pB", range_=(0, 3))
    with pytest.raises(ValueError, match="same paragraph"):
        r1.mark_comment_range(r2, 1)
    # No comments.patch call leaked through.
    assert _find_call(fake_sd_methods.calls, "comments.patch") is None


def test_comments_iter_yields_comment_proxies(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    """`for c in doc.comments` yields Comment proxies built from the
    SuperDoc ``items`` payload."""
    from docx.comments import Comment, Comments

    fake_sd_methods.scripted_returns["comments.list"] = {
        "evaluatedRevision": "r1",
        "total": 2,
        "items": [
            {"id": "c1", "text": "first", "creatorName": "Alice", "status": "open"},
            {"id": "c2", "text": "second", "creatorName": "Bob", "status": "resolved"},
        ],
        "page": {"limit": 50, "offset": 0, "returned": 2},
    }
    comments = Comments(session=mock_session)
    seen = list(comments)
    assert len(seen) == 2
    assert all(isinstance(c, Comment) for c in seen)
    assert seen[0].comment_id == "c1"
    assert seen[0].author == "Alice"
    assert seen[1].text == "second"


def test_comments_get_returns_proxy(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    from docx.comments import Comments

    fake_sd_methods.scripted_returns["comments.get"] = {
        "address": {"kind": "entity", "entityType": "comment", "entityId": "c9"},
        "commentId": "c9",
        "text": "deep dive",
        "status": "open",
    }
    comments = Comments(session=mock_session)
    c = comments.get("c9")
    assert c is not None
    assert c.comment_id == "c9"
    assert c.text == "deep dive"


def test_comment_text_setter_calls_comments_patch(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    from docx.comments import Comment

    c = Comment(
        session=mock_session,
        info={"id": "c-edit", "commentId": "c-edit", "text": "old"},
    )
    c.text = "new"

    call = _find_call(fake_sd_methods.calls, "comments.patch")
    assert call is not None
    _, params = call
    assert params == {"id": "c-edit", "text": "new"}
    # Local state is also updated for read-back parity.
    assert c.text == "new"


def test_comment_block_container_surface_raises(mock_session: Any) -> None:
    """SuperDoc models a comment as a single text body — the
    paragraph/table-bearing surface raises CommentsNotImplementedError."""
    from docx.comments import Comment, CommentsNotImplementedError

    c = Comment(session=mock_session, info={"id": "x", "text": "body"})
    # paragraphs / tables return empty lists for iteration parity.
    assert c.paragraphs == []
    assert c.tables == []
    # add_paragraph / add_table / iter_inner_content raise.
    with pytest.raises(CommentsNotImplementedError):
        c.add_paragraph("more")
    with pytest.raises(CommentsNotImplementedError):
        c.iter_inner_content()
