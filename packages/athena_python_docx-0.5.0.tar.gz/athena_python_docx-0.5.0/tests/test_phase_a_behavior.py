"""Phase A behavior parity tests.

Pins three behavior fixes that close real gaps versus upstream:

  * ``Document.add_picture`` returns an :class:`InlineShape` (was None).
  * ``Paragraph.iter_inner_content`` yields :class:`RenderedPageBreak`
    between text segments separated by the form-feed sentinel.
  * ``paragraph.style`` returns a :class:`ParagraphStyle` instance
    populated from the live SuperDoc payload.
"""

from __future__ import annotations

from typing import Any


def _find_call(calls: list[tuple[str, Any]], op_name: str) -> tuple[str, Any] | None:
    for call in calls:
        if call[0] == op_name:
            return call
    return None


def _make_doc(mock_session: Any):
    from docx.document import Document

    doc = Document.__new__(Document)
    doc._session = mock_session
    doc._saved = False
    doc._closed = False
    return doc


def test_document_add_picture_returns_inline_shape(
    mock_session: Any, fake_sd_methods: Any, tmp_path: Any
) -> None:
    """Document.add_picture returns an InlineShape, matching upstream."""
    from docx.shape import InlineShape

    fake_sd_methods.scripted_returns["create.image"] = {
        "success": True,
        "image": {"nodeId": "img-doc-1"},
    }
    img = tmp_path / "x.png"
    img.write_bytes(b"\x89PNG\r\n\x1a\n")
    doc = _make_doc(mock_session)
    shape = doc.add_picture(str(img))
    assert isinstance(shape, InlineShape)


def test_run_add_picture_returns_inline_shape(
    mock_session: Any, fake_sd_methods: Any, tmp_path: Any
) -> None:
    """Run.add_picture also returns an InlineShape (regression test —
    we landed this in an earlier PR; pin it here too)."""
    from docx.shape import InlineShape
    from docx.text.run import Run

    fake_sd_methods.scripted_returns["create.image"] = {
        "success": True,
        "image": {"nodeId": "img-run-1"},
    }
    img = tmp_path / "y.png"
    img.write_bytes(b"\x89PNG\r\n\x1a\n")
    run = Run(session=mock_session, block_id="p1", range_=(0, 0))
    shape = run.add_picture(str(img))
    assert isinstance(shape, InlineShape)


def test_paragraph_iter_inner_content_yields_rendered_page_break(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """A run whose text contains the form-feed sentinel splits into
    pre/post text-runs with a :class:`RenderedPageBreak` yielded
    between them."""
    from docx.text.pagebreak import RenderedPageBreak
    from docx.text.paragraph import Paragraph
    from docx.text.run import Run

    fake_sd_methods.scripted_returns["get_node_by_id"] = {
        "node": {
            "paragraph": {
                "inlines": [
                    {"run": {"text": "before\fafter"}},
                ],
            },
        },
    }
    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    items = list(para.iter_inner_content())

    assert len(items) == 3
    assert isinstance(items[0], Run)
    assert items[0].text == "before"
    assert isinstance(items[1], RenderedPageBreak)
    assert items[1].preceding_paragraph_text == "before"
    assert isinstance(items[2], Run)
    assert items[2].text == "after"


def test_paragraph_iter_inner_content_no_break_yields_run_only(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Plain text runs without a sentinel still yield a single Run."""
    from docx.text.paragraph import Paragraph
    from docx.text.run import Run

    fake_sd_methods.scripted_returns["get_node_by_id"] = {
        "node": {
            "paragraph": {
                "inlines": [{"run": {"text": "no break here"}}],
            },
        },
    }
    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    items = list(para.iter_inner_content())
    assert len(items) == 1
    assert isinstance(items[0], Run)
    assert items[0].text == "no break here"


def test_paragraph_style_returns_paragraph_style_instance(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``paragraph.style`` returns a :class:`ParagraphStyle`, not a
    raw string — matching python-docx."""
    from docx.styles.style import ParagraphStyle
    from docx.text.paragraph import Paragraph

    fake_sd_methods.scripted_returns["get_node_by_id"] = {
        "node": {"paragraph": {}, "styleId": "Heading 2"},
    }
    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    style = para.style
    assert isinstance(style, ParagraphStyle)
    assert style.style_id == "Heading 2"


def test_paragraph_iter_inner_content_multiple_breaks(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """A run with multiple ``\\f`` sentinels yields multiple
    RenderedPageBreaks between the surviving text segments."""
    from docx.text.paragraph import Paragraph

    fake_sd_methods.scripted_returns["get_node_by_id"] = {
        "node": {
            "paragraph": {
                "inlines": [
                    {"run": {"text": "a\fb\fc"}},
                ],
            },
        },
    }
    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    items = list(para.iter_inner_content())
    kinds = [type(i).__name__ for i in items]
    # Run("a"), RPB, Run("b"), RPB, Run("c")
    assert kinds == ["Run", "RenderedPageBreak", "Run", "RenderedPageBreak", "Run"]
    assert items[0].text == "a"  # type: ignore[union-attr]
    assert items[2].text == "b"  # type: ignore[union-attr]
    assert items[4].text == "c"  # type: ignore[union-attr]
