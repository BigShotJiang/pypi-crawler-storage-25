"""Tests that ``Document.add_paragraph`` / ``Document.add_table`` /
``Paragraph.insert_paragraph_before`` accept style instances, not
just style-name strings — matching python-docx ``style: str |
ParagraphStyle | None`` and ``style: str | _TableStyle | None``
type annotations.
"""

from __future__ import annotations

from typing import Any


def _find_call(calls: list[tuple[str, Any]], op_name: str) -> tuple[str, Any] | None:
    for call in calls:
        if call[0] == op_name:
            return call
    return None


def _make_doc(mock_session: Any):
    from docx.document import Document

    doc = Document.__new__(Document)
    doc._session = mock_session
    doc._saved = False
    doc._closed = False
    return doc


def _make_paragraph_style(name: str, *, session: Any):
    from docx.enum.style import WD_STYLE_TYPE
    from docx.styles.style import ParagraphStyle

    return ParagraphStyle(name=name, style_type=WD_STYLE_TYPE.PARAGRAPH, session=session)


def _make_table_style(name: str, *, session: Any):
    from docx.enum.style import WD_STYLE_TYPE
    from docx.styles.style import TableStyle

    return TableStyle(name=name, style_type=WD_STYLE_TYPE.TABLE, session=session)


def test_add_paragraph_accepts_paragraph_style_instance(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """add_paragraph(text, style=ParagraphStyle(...)) coerces the
    style instance to its style_id and applies it via setStyle."""
    doc = _make_doc(mock_session)
    style = _make_paragraph_style("Quote", session=mock_session)
    doc.add_paragraph("hi", style=style)

    create = _find_call(fake_sd_methods.calls, "create.paragraph")
    assert create is not None

    # The style is applied via doc.styles.paragraph.set_style after creation.
    set_style = _find_call(fake_sd_methods.calls, "styles.paragraph.set_style")
    assert set_style is not None
    _, params = set_style
    assert params["styleId"] == "Quote"


def test_add_paragraph_string_style_still_works(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Backwards-compat: string style names still apply via setStyle."""
    doc = _make_doc(mock_session)
    doc.add_paragraph("hi", style="Quote")

    set_style = _find_call(fake_sd_methods.calls, "styles.paragraph.set_style")
    assert set_style is not None
    _, params = set_style
    assert params["styleId"] == "Quote"


def test_add_paragraph_heading_style_routes_to_add_heading(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """`style="Heading 2"` early-returns to add_heading — uses the
    create.heading path, not create.paragraph."""
    doc = _make_doc(mock_session)
    doc.add_paragraph("Section", style="Heading 2")

    heading = _find_call(fake_sd_methods.calls, "create.heading")
    paragraph = _find_call(fake_sd_methods.calls, "create.paragraph")
    assert heading is not None
    assert paragraph is None  # heading branch doesn't call create.paragraph


def test_add_table_accepts_table_style_instance(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """add_table(rows, cols, style=TableStyle(...)) coerces the style
    instance to its style_id when calling tables.set_style."""
    doc = _make_doc(mock_session)
    style = _make_table_style("Light Grid", session=mock_session)
    doc.add_table(2, 3, style=style)

    set_style = _find_call(fake_sd_methods.calls, "tables.set_style")
    assert set_style is not None
    _, params = set_style
    assert params["styleId"] == "Light Grid"


def test_add_paragraph_no_style_skips_setstyle(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """When style=None, no setStyle call is made — the new paragraph
    inherits the document default."""
    doc = _make_doc(mock_session)
    doc.add_paragraph("plain")

    assert _find_call(fake_sd_methods.calls, "styles.paragraph.set_style") is None
