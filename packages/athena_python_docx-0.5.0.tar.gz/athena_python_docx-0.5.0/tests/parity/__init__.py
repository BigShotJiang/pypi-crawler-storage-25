"""Parity gap analysis harness for athena-python-docx vs python-docx.

See ``README.md`` in this directory for usage. The pytest entry point is
``tests/parity/test_parity_gap.py``.
"""
