"""Introspect the currently-importable ``docx`` package and emit a JSON
snapshot of its public surface.

This script is intentionally **stdlib-only and has no `docx` import at
module level** so it can be invoked twice — once in an isolated env that
has only upstream ``python-docx``, and once in the athena-python-docx
venv — and the resulting snapshots compared.

Usage:

    python introspect.py --out /tmp/upstream_surface.json
    python introspect.py --out /tmp/athena_surface.json --package docx

The snapshot schema is documented in README.md.
"""

from __future__ import annotations

import argparse
import importlib
import inspect
import json
import sys
import traceback
from pathlib import Path
from typing import Any

SENTINEL_NO_DEFAULT = "<NO_DEFAULT>"
SENTINEL_UNREPR = "<UNREPR>"
SENTINEL_NO_ANNOTATION = None

# python-docx convention: classes whose name starts with ``_`` but
# users still receive instances of them via return values. These get
# promoted into the parity surface even without ``__all__`` listing.
# Anything outside this set stays filtered (parser internals, abstract
# bases used only for isinstance() checks within the package, etc.).
_PUBLIC_UNDERSCORE_CLASS_NAMES: frozenset[str] = frozenset(
    {
        "_Cell",
        "_Column",
        "_Columns",
        "_Footer",
        "_Header",
        "_NumberingStyle",
        "_Row",
        "_Rows",
        "_TableStyle",
    }
)


def _safe_repr(value: Any, *, max_len: int = 200) -> str:
    try:
        out = repr(value)
    except Exception:
        return SENTINEL_UNREPR
    if len(out) > max_len:
        out = out[:max_len] + "..."
    return out


def _annotation_str(annotation: Any) -> str | None:
    if annotation is inspect.Parameter.empty:
        return SENTINEL_NO_ANNOTATION
    if isinstance(annotation, str):
        return annotation
    return _safe_repr(annotation, max_len=300)


def _serialize_default(default: Any) -> str:
    if default is inspect.Parameter.empty:
        return SENTINEL_NO_DEFAULT
    return _safe_repr(default)


def _serialize_param(p: inspect.Parameter) -> dict[str, Any]:
    return {
        "name": p.name,
        "kind": p.kind.name,
        "default": _serialize_default(p.default),
        "annotation": _annotation_str(p.annotation),
    }


def _serialize_signature(func: Any) -> dict[str, Any] | None:
    try:
        sig = inspect.signature(func)
    except (TypeError, ValueError):
        return None
    return {
        "params": [_serialize_param(p) for p in sig.parameters.values()],
        "return_annotation": _annotation_str(sig.return_annotation),
    }


def _is_descriptor(obj: Any, kind: type) -> bool:
    return isinstance(obj, kind)


def _classify_member(
    cls: type, name: str
) -> tuple[str, dict[str, Any]] | None:
    """Return ``(kind, payload)`` for a class member, or ``None`` to skip.

    Uses :func:`inspect.getattr_static` to avoid invoking descriptors
    (some property getters in python-docx assume an XML element).
    """

    raw = inspect.getattr_static(cls, name, inspect.Parameter.empty)
    if raw is inspect.Parameter.empty:
        return None

    if isinstance(raw, property):
        doc = (raw.__doc__ or "").strip()
        return "property", {
            "has_setter": raw.fset is not None,
            "has_deleter": raw.fdel is not None,
            "doc_first_line": doc.splitlines()[0] if doc else None,
        }

    if isinstance(raw, staticmethod):
        return "staticmethod", {"signature": _serialize_signature(raw.__func__)}

    if isinstance(raw, classmethod):
        return "classmethod", {"signature": _serialize_signature(raw.__func__)}

    if inspect.isfunction(raw) or inspect.ismethod(raw) or inspect.isbuiltin(raw):
        return "method", {"signature": _serialize_signature(raw)}

    # Class-level data attributes (enum values, constants, nested classes).
    if inspect.isclass(raw):
        return "nested_class", {
            "module": raw.__module__,
            "qualname": raw.__qualname__,
        }

    return "attr", {
        "type": type(raw).__name__,
        "repr": _safe_repr(raw),
    }


def _serialize_class(cls: type) -> dict[str, Any]:
    members: dict[str, dict[str, Any]] = {}
    # `dir()` walks the MRO; we deliberately include inherited members
    # because callers see them on the class.
    for name in sorted(dir(cls)):
        # Skip dunders — almost all are inherited from `object` or the
        # metaclass and add no parity signal.
        if name.startswith("__") and name.endswith("__"):
            continue
        try:
            classified = _classify_member(cls, name)
        except Exception as exc:  # pragma: no cover - defensive
            members[name] = {"kind": "error", "error": f"{type(exc).__name__}: {exc}"}
            continue
        if classified is None:
            continue
        kind, payload = classified
        members[name] = {"kind": kind, **payload}

    try:
        ctor_sig = _serialize_signature(cls)
    except Exception:
        ctor_sig = None

    bases = []
    for b in cls.__bases__:
        if b is object:
            continue
        bases.append(f"{b.__module__}.{b.__qualname__}")

    return {
        "kind": "class",
        "qualname": cls.__qualname__,
        "module": cls.__module__,
        "bases": bases,
        "ctor_signature": ctor_sig,
        "is_abstract": inspect.isabstract(cls),
        "members": members,
    }


def _serialize_function(func: Any) -> dict[str, Any]:
    return {
        "kind": "function",
        "module": getattr(func, "__module__", None),
        "qualname": getattr(func, "__qualname__", None),
        "signature": _serialize_signature(func),
    }


def _is_defined_in(obj: Any, mod_name: str) -> bool:
    """True if ``obj`` was defined in ``mod_name`` (not a re-export)."""
    obj_mod = getattr(obj, "__module__", None)
    if obj_mod is None:
        return False
    return obj_mod == mod_name


def _serialize_module(mod_name: str, *, include_reexports: bool) -> dict[str, Any]:
    try:
        mod = importlib.import_module(mod_name)
    except Exception as exc:
        return {
            "_import_error": f"{type(exc).__name__}: {exc}",
            "_traceback": traceback.format_exc(limit=3),
            "members": {},
        }

    declared_all = getattr(mod, "__all__", None)
    members: dict[str, Any] = {}
    for name, obj in inspect.getmembers(mod):
        if name.startswith("__") and name.endswith("__"):
            continue
        if name.startswith("_"):
            # Single-underscore module-level names are typically private
            # impl detail. EXCEPT for the small set of classes
            # python-docx exposes by convention as "users receive these
            # as return values but don't construct them directly" —
            # those need parity. A blanket isclass() check would also
            # promote parser internals like ``_BaseChildElement`` to the
            # parity surface, which adds noise to the allowlist.
            #
            # Module-level functions / constants stay filtered too.
            promotion_ok = (
                inspect.isclass(obj)
                and name in _PUBLIC_UNDERSCORE_CLASS_NAMES
            )
            if not promotion_ok:
                if declared_all is None or name not in declared_all:
                    continue

        # Limit to symbols defined in this module unless this is the
        # top-level facade module (e.g., `docx`) where re-exports ARE
        # the public surface, or include_reexports is True.
        if not include_reexports and not _is_defined_in(obj, mod_name):
            if declared_all is None or name not in declared_all:
                continue

        if inspect.isclass(obj):
            # Always serialize where the class is *defined* — the canonical
            # location. If we're seeing it as a re-export, point to its
            # canonical module so the comparator can resolve it.
            entry: dict[str, Any]
            if _is_defined_in(obj, mod_name):
                entry = _serialize_class(obj)
            else:
                entry = {
                    "kind": "class_reexport",
                    "canonical": f"{obj.__module__}.{obj.__qualname__}",
                }
            members[name] = entry
        elif inspect.isfunction(obj) or inspect.isbuiltin(obj):
            members[name] = _serialize_function(obj)
        else:
            # Module-level constants (e.g., `MAX_INT = 0x7FFFFFFF`).
            members[name] = {
                "kind": "module_attr",
                "type": type(obj).__name__,
                "repr": _safe_repr(obj),
            }

    return {"members": members}


def _discover_modules(pkg_name: str) -> list[str]:
    """Walk the package directory and return all submodule dotted names."""
    pkg = importlib.import_module(pkg_name)
    pkg_file = getattr(pkg, "__file__", None)
    if pkg_file is None:
        return [pkg_name]
    base = Path(pkg_file).parent
    out: set[str] = {pkg_name}
    for py_file in base.rglob("*.py"):
        if py_file.name == "__init__.py":
            rel_parts = py_file.parent.relative_to(base).parts
        else:
            rel_parts = py_file.relative_to(base).with_suffix("").parts
        if rel_parts:
            out.add(".".join((pkg_name, *rel_parts)))
    return sorted(out)


def build_snapshot(pkg_name: str = "docx") -> dict[str, Any]:
    pkg = importlib.import_module(pkg_name)
    modules = _discover_modules(pkg_name)

    snapshot: dict[str, Any] = {
        "package": pkg_name,
        "package_file": getattr(pkg, "__file__", None),
        "package_version": getattr(pkg, "__version__", None),
        "python_version": sys.version.split()[0],
        "modules": {},
    }

    for mod_name in modules:
        # Top-level facade (`docx`) — include re-exports so factories like
        # `Document` show up. Submodules — only definitions.
        is_top = mod_name == pkg_name
        snapshot["modules"][mod_name] = _serialize_module(
            mod_name, include_reexports=is_top
        )

    return snapshot


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True, help="output JSON path")
    ap.add_argument(
        "--package", default="docx", help="package name to introspect (default: docx)"
    )
    ap.add_argument(
        "--source-prefix",
        action="append",
        default=[],
        help=(
            "prepend this directory to sys.path before importing (repeatable). "
            "Use to disambiguate when multiple distributions share a name."
        ),
    )
    ap.add_argument(
        "--expect-source",
        default=None,
        help=(
            "abort if the resolved package's __file__ is not under this "
            "directory. Sanity-check for path-shadowing bugs."
        ),
    )
    args = ap.parse_args()

    for prefix in reversed(args.source_prefix):
        sys.path.insert(0, str(Path(prefix).resolve()))

    pkg = importlib.import_module(args.package)
    pkg_file = getattr(pkg, "__file__", None)
    if args.expect_source is not None:
        expected = Path(args.expect_source).resolve()
        if pkg_file is None or expected not in Path(pkg_file).resolve().parents:
            print(
                f"ERROR: expected {args.package} under {expected!s}, "
                f"but resolved {pkg_file!r}. sys.path[0:5]={sys.path[:5]}",
                file=sys.stderr,
            )
            return 2

    snapshot = build_snapshot(args.package)
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(snapshot, indent=2, sort_keys=True) + "\n")
    print(
        f"wrote {out_path} (version={snapshot['package_version']}, "
        f"modules={len(snapshot['modules'])}, "
        f"file={snapshot['package_file']!r})",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
