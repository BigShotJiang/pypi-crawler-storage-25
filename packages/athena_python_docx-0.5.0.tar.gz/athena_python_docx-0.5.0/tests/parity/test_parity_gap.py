"""Deep parity-gap test for athena-python-docx vs python-docx.

This test does NOT just check a hand-curated set of attribute names —
the older ``test_python_docx_api_parity.py`` already covers the
critical-path surface that way. Instead, this test loads:

    * a frozen snapshot of upstream python-docx's public surface
      (``snapshots/upstream_python_docx_<version>.json``), and
    * a freshly-introspected snapshot of the live athena package,

runs the structured comparator in ``compare.py`` against the
``intentional_deviations.json`` allowlist, and asserts that **no NEW
actionable gaps** have appeared since the committed
``baseline_gaps.json``.

Side effects (always, even on success): writes the live athena
snapshot to ``snapshots/athena_latest.json`` and renders
``reports/GAP_ANALYSIS.md`` so a human reviewer can scan the report
during PR review.

To refresh the upstream snapshot when bumping python-docx, run::

    uv run python tests/parity/run_parity.py refresh-upstream --version 1.X.Y

To accept a new gap (or recognize that you've fixed one), run::

    uv run python tests/parity/run_parity.py compare --update-baseline

"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.parity import compare as parity_compare
from tests.parity import introspect as parity_introspect

THIS_DIR = Path(__file__).parent.resolve()
SNAPSHOT_DIR = THIS_DIR / "snapshots"
REPORT_DIR = THIS_DIR / "reports"
DEVIATIONS_PATH = THIS_DIR / "intentional_deviations.json"
BASELINE_PATH = THIS_DIR / "baseline_gaps.json"


def _latest_upstream_snapshot() -> Path:
    paths = sorted(SNAPSHOT_DIR.glob("upstream_python_docx_*.json"))
    if not paths:
        pytest.skip(
            "no committed upstream snapshot — run "
            "`uv run python tests/parity/run_parity.py refresh-upstream`"
        )
    return paths[-1]


@pytest.fixture(scope="session")
def upstream_snapshot() -> dict:
    return json.loads(_latest_upstream_snapshot().read_text())


@pytest.fixture(scope="session")
def athena_snapshot() -> dict:
    """Introspect the *live* athena-python-docx package.

    Pytest's import resolution loads athena's ``docx`` (because cwd is
    ``python-sdk/`` and the package directory shadows the dev-dep
    install of upstream python-docx). We sanity-check that, then dump
    the snapshot in-process — no subprocess hop needed.
    """
    import docx

    sdk_root = THIS_DIR.parent.parent  # …/python-sdk
    pkg_path = Path(docx.__file__).resolve()
    expected = (sdk_root / "docx").resolve()
    assert expected in pkg_path.parents or pkg_path.parent == expected, (
        f"`import docx` resolved to {pkg_path}, expected something under "
        f"{expected}. Run from python-sdk/ or set PYTHONPATH."
    )

    snapshot = parity_introspect.build_snapshot("docx")
    SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)
    (SNAPSHOT_DIR / "athena_latest.json").write_text(
        json.dumps(snapshot, indent=2, sort_keys=True) + "\n"
    )
    return snapshot


@pytest.fixture(scope="session")
def deviations() -> dict:
    return json.loads(DEVIATIONS_PATH.read_text())


@pytest.fixture(scope="session")
def gap_report(
    upstream_snapshot: dict, athena_snapshot: dict, deviations: dict
) -> parity_compare.GapReport:
    deviations = dict(deviations)
    deviations["__source__"] = str(DEVIATIONS_PATH)
    report = parity_compare.compare(upstream_snapshot, athena_snapshot, deviations)

    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    (REPORT_DIR / "GAP_ANALYSIS.md").write_text(parity_compare.render_markdown(report))
    (REPORT_DIR / "gap_report.json").write_text(
        json.dumps(report.to_dict(), indent=2, sort_keys=True) + "\n"
    )
    return report


@pytest.fixture(scope="session")
def baseline() -> dict | None:
    if not BASELINE_PATH.exists():
        return None
    return json.loads(BASELINE_PATH.read_text())


def test_snapshot_dump_succeeds(athena_snapshot: dict) -> None:
    """Sanity check — the introspection produced a non-trivial snapshot."""
    assert athena_snapshot["package"] == "docx"
    assert len(athena_snapshot["modules"]) > 5
    assert "docx" in athena_snapshot["modules"]
    assert "docx.document" in athena_snapshot["modules"]


def test_compare_runs(gap_report: parity_compare.GapReport) -> None:
    """The comparator produces a report with both buckets populated."""
    assert gap_report.upstream_version is not None
    assert gap_report.athena_version is not None
    # Until athena reaches 100% parity there will always be intentional
    # findings (XML/OPC layer); assert that the allowlist is wired up.
    assert len(gap_report.intentional) > 0, (
        "intentional_deviations.json should be filtering OOXML-layer "
        "findings into the intentional bucket"
    )


def test_no_new_actionable_gaps(
    gap_report: parity_compare.GapReport, baseline: dict | None
) -> None:
    """Ratchet: the set of actionable gap locations must be a subset of
    the committed baseline."""
    if baseline is None:
        pytest.skip(
            "no baseline_gaps.json yet — run "
            "`uv run python tests/parity/run_parity.py compare --update-baseline`"
        )
    baseline_locations = set(baseline.get("actionable_locations", []))
    current_locations = {
        f"{f.kind}:{f.location}" for f in gap_report.actionable
    }
    new_gaps = sorted(current_locations - baseline_locations)
    assert not new_gaps, (
        "new actionable parity gaps detected (not in baseline_gaps.json):\n  "
        + "\n  ".join(new_gaps)
        + "\n\nEither close the gap, or accept it by running:\n  "
        "uv run python tests/parity/run_parity.py compare --update-baseline"
    )


def test_baseline_does_not_drift_open(
    gap_report: parity_compare.GapReport, baseline: dict | None
) -> None:
    """Inverse ratchet: warn when the baseline is staler than reality
    (i.e., gaps have been fixed but the baseline wasn't refreshed)."""
    if baseline is None:
        pytest.skip("no baseline yet")
    baseline_locations = set(baseline.get("actionable_locations", []))
    current_locations = {
        f"{f.kind}:{f.location}" for f in gap_report.actionable
    }
    closed_gaps = sorted(baseline_locations - current_locations)
    if closed_gaps:
        # Don't fail — just print. Closing gaps is good; we just want
        # the user to refresh the baseline so future regressions of
        # those same gaps re-surface.
        print(
            "\n[parity-baseline] {0} closed gaps detected — refresh "
            "baseline with `uv run python tests/parity/run_parity.py "
            "compare --update-baseline`:\n  {1}".format(
                len(closed_gaps), "\n  ".join(closed_gaps)
            )
        )
