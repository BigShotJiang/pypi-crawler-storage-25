# python-docx parity gap harness

Re-runnable, structural comparison of `athena-python-docx` against the
upstream `python-docx` reference API. The pre-existing
[`tests/test_python_docx_api_parity.py`](../test_python_docx_api_parity.py)
asserts a hand-curated set of attribute names exists; **this** harness
does the deep work — every class, every method, every signature on
both sides, diffed and bucketed.

## What it produces

Run the harness end-to-end:

```bash
uv run python tests/parity/run_parity.py all --update-baseline
```

That emits four artifacts in `tests/parity/`:

| File | Purpose |
|---|---|
| `snapshots/upstream_python_docx_<v>.json` | Frozen surface of upstream python-docx at version `<v>` |
| `snapshots/athena_latest.json` | Surface of the live athena package |
| `reports/GAP_ANALYSIS.md` | Human-readable gap report (read this) |
| `reports/gap_report.json` | Same data, structured (CI-readable) |
| `baseline_gaps.json` | Currently-known actionable gaps; the test ratchets against this |

## Architecture

```
introspect.py  ─┐
                ├──► JSON surface snapshot
introspect.py  ─┘     (per package)
                          │
                          ▼
                     compare.py ──► GapReport ──► Markdown + JSON
                          ▲
                          │
            intentional_deviations.json  (allowlist)
```

- **`introspect.py`** — stdlib-only. Walks the package tree, captures
  every public class / method / property / signature into a structured
  JSON snapshot. Has a `--source-prefix PATH` flag so the same script
  can introspect athena (point at `python-sdk/`) or upstream
  python-docx (run inside an isolated `uv` env that only has
  `python-docx==X` installed).

- **`compare.py`** — diffs two snapshots into a `GapReport` of seven
  finding kinds: `module_missing`, `class_missing`, `member_missing`,
  `member_kind_drift`, `signature_drift`, `ctor_signature_drift`,
  `return_annotation_drift`. Each finding is filtered against
  `intentional_deviations.json` and bucketed as **actionable** or
  **intentional**.

- **`intentional_deviations.json`** — allowlist of expected deviations.
  Mirrors the "Intentionally omitted" section in
  [`python-sdk/CLAUDE.md`](../../CLAUDE.md). Patterns support `*`
  (single segment) and `**` (any number of segments). See the file's
  `_README` block for syntax.

- **`run_parity.py`** — CLI orchestrator. Wraps the three scripts
  above with sensible defaults. The pytest entry shells out only when
  refreshing the upstream snapshot; the live athena snapshot is built
  in-process for speed.

- **`test_parity_gap.py`** — pytest. Runs every test session:
    1. introspects athena in-process,
    2. loads the committed upstream snapshot,
    3. compares,
    4. writes `GAP_ANALYSIS.md` + `gap_report.json`,
    5. asserts no NEW gaps appeared since `baseline_gaps.json`.

## Common workflows

### "Did my change introduce a parity gap?"

```bash
uv run pytest tests/parity/test_parity_gap.py -v
```

If the test fails with `new actionable parity gaps detected …`, either
fix the gap or — if the new divergence is intentional — add it to
`intentional_deviations.json` (with a `_comment ──` rationale line) and
re-run with `--update-baseline`.

### "I bumped python-docx in pyproject.toml — refresh the snapshot."

```bash
uv run python tests/parity/run_parity.py refresh-upstream --version 1.3.0
git rm tests/parity/snapshots/upstream_python_docx_1.2.0.json   # only one snapshot lives at HEAD
uv run python tests/parity/run_parity.py compare --update-baseline
git add tests/parity/snapshots tests/parity/baseline_gaps.json tests/parity/reports
```

The harness picks the lexicographically-newest
`upstream_python_docx_*.json` automatically.

### "I closed a gap — accept the smaller baseline."

```bash
uv run python tests/parity/run_parity.py compare --update-baseline
git add tests/parity/baseline_gaps.json tests/parity/reports
```

`test_baseline_does_not_drift_open` will print the closed gaps so you
know what changed; the regular ratchet still passes either way.

### "I deliberately want a deviation from python-docx."

1. Add a stanza to
   [`python-sdk/CLAUDE.md`](../../CLAUDE.md) §
   *Intentionally omitted* / *Intentional deviations*.
2. Add the corresponding pattern to
   `tests/parity/intentional_deviations.json` with a
   `_comment ──` rationale line.
3. Re-run the comparator. The finding moves from **actionable** to
   **intentional**.

## Snapshot schema (in case you need it)

```jsonc
{
  "package": "docx",
  "package_version": "1.2.0",
  "package_file": "/abs/path/to/docx/__init__.py",
  "python_version": "3.12.6",
  "modules": {
    "docx.text.run": {
      "members": {
        "Run": {
          "kind": "class",
          "module": "docx.text.run",
          "qualname": "Run",
          "bases": ["docx.shared.Parented"],
          "ctor_signature": {
            "params": [{"name": "r", "kind": "POSITIONAL_OR_KEYWORD",
                        "default": "<NO_DEFAULT>", "annotation": "CT_R"},
                       …],
            "return_annotation": null
          },
          "is_abstract": false,
          "members": {
            "add_break": {"kind": "method",
                          "signature": {"params": […],
                                        "return_annotation": null}},
            "bold":      {"kind": "property",
                          "has_setter": true, "has_deleter": false,
                          "doc_first_line": "Tri-state — True/False/None"}
          }
        }
      }
    }
  }
}
```

## What this harness DOES NOT do

- **Behavioral parity.** A method that exists with the same signature
  may still behave differently. Behavioral parity is covered by
  end-to-end tests in `tests/fidelity/` and the regular unit-test suite.
- **Type-annotation parity.** Return-annotation drift is reported as
  `minor`; per-parameter annotation drift is reported as informational
  only (signatures are compared on names + kinds + defaults). The SDK
  inevitably diverges on type names because it operates on `Session`
  / `dict` payloads instead of `lxml._Element` / `CT_*` objects.
- **Internal implementation details.** Members starting with `_` are
  reported but most are filtered to *intentional* via the allowlist.
  CLAUDE.md's parity rule covers the *public* surface.
