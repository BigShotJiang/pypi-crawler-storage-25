"""CLI orchestrator for the python-docx parity gap analysis.

Subcommands:

  refresh-upstream [--version 1.2.0]
      Spin up an isolated env containing only ``python-docx==<version>``,
      run ``introspect.py`` against it, and write the result to
      ``snapshots/upstream_python_docx_<version>.json``.

  refresh-athena
      Snapshot the current athena-python-docx source. Writes to
      ``snapshots/athena_latest.json``.

  compare [--upstream PATH] [--athena PATH] [--update-baseline]
      Compare the two latest snapshots, render
      ``reports/GAP_ANALYSIS.md``, and write the JSON gap report.
      With ``--update-baseline``, overwrites the committed
      ``baseline_gaps.json`` with the current actionable list.

  all [--upstream-version VERSION]
      refresh-upstream && refresh-athena && compare.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

THIS_DIR = Path(__file__).parent.resolve()
SDK_ROOT = THIS_DIR.parent.parent.resolve()  # …/python-sdk
SNAPSHOT_DIR = THIS_DIR / "snapshots"
REPORT_DIR = THIS_DIR / "reports"
DEVIATIONS_PATH = THIS_DIR / "intentional_deviations.json"
BASELINE_PATH = THIS_DIR / "baseline_gaps.json"
INTROSPECT = THIS_DIR / "introspect.py"
COMPARE_MODULE = THIS_DIR / "compare.py"
DEFAULT_UPSTREAM_VERSION = "1.2.0"


def _ensure_dirs() -> None:
    SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)


def _upstream_snapshot_path(version: str) -> Path:
    return SNAPSHOT_DIR / f"upstream_python_docx_{version}.json"


def _athena_snapshot_path() -> Path:
    return SNAPSHOT_DIR / "athena_latest.json"


def refresh_upstream(version: str) -> Path:
    """Snapshot upstream python-docx via an isolated uv env."""
    _ensure_dirs()
    out = _upstream_snapshot_path(version)

    cmd = [
        "uv",
        "run",
        "--no-project",
        "--isolated",
        "--with",
        f"python-docx=={version}",
        "python",
        str(INTROSPECT),
        "--out",
        str(out),
    ]
    # cwd must NOT contain a `docx/` directory or it will shadow the
    # installed python-docx via sys.path[0]. Use a neutral directory.
    neutral_cwd = "/tmp" if Path("/tmp").is_dir() else str(Path.home())
    print(f"[upstream] {' '.join(cmd)} (cwd={neutral_cwd})", file=sys.stderr)
    subprocess.run(cmd, cwd=neutral_cwd, check=True)
    return out


def refresh_athena() -> Path:
    """Snapshot the live athena-python-docx package."""
    _ensure_dirs()
    out = _athena_snapshot_path()

    cmd = [
        "uv",
        "run",
        "python",
        str(INTROSPECT),
        "--out",
        str(out),
        "--source-prefix",
        str(SDK_ROOT),
        "--expect-source",
        str(SDK_ROOT / "docx"),
    ]
    print(f"[athena] {' '.join(cmd)}", file=sys.stderr)
    subprocess.run(cmd, cwd=str(SDK_ROOT), check=True)
    return out


def compare_snapshots(
    *,
    upstream: Path | None = None,
    athena: Path | None = None,
    update_baseline: bool = False,
) -> dict:
    _ensure_dirs()
    if upstream is None:
        upstream = sorted(SNAPSHOT_DIR.glob("upstream_python_docx_*.json"))[-1]
    if athena is None:
        athena = _athena_snapshot_path()

    md_out = REPORT_DIR / "GAP_ANALYSIS.md"
    json_out = REPORT_DIR / "gap_report.json"

    cmd = [
        "uv",
        "run",
        "python",
        str(COMPARE_MODULE),
        "--upstream",
        str(upstream),
        "--athena",
        str(athena),
        "--deviations",
        str(DEVIATIONS_PATH),
        "--out-md",
        str(md_out),
        "--out-json",
        str(json_out),
    ]
    print(f"[compare] {' '.join(cmd)}", file=sys.stderr)
    subprocess.run(cmd, cwd=str(SDK_ROOT), check=True)
    report = json.loads(json_out.read_text())

    if update_baseline:
        baseline = {
            "_README": (
                "Snapshot of currently-known actionable parity gaps. The "
                "pytest at tests/test_parity_gap.py asserts no NEW gaps "
                "appear (i.e., gaps not in this list). Refresh with "
                "`uv run python tests/parity/run_parity.py compare "
                "--update-baseline`."
            ),
            "upstream_python_docx_version": report.get("upstream_version"),
            "athena_python_docx_version": report.get("athena_version"),
            "actionable_count": sum(
                1 for f in report["findings"] if not f["intentional"]
            ),
            "actionable_locations": sorted(
                {f"{f['kind']}:{f['location']}" for f in report["findings"] if not f["intentional"]}
            ),
        }
        BASELINE_PATH.write_text(json.dumps(baseline, indent=2, sort_keys=True) + "\n")
        print(
            f"[baseline] wrote {BASELINE_PATH} "
            f"(actionable_count={baseline['actionable_count']})",
            file=sys.stderr,
        )

    return report


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    sp_up = sub.add_parser("refresh-upstream", help="snapshot upstream python-docx")
    sp_up.add_argument("--version", default=DEFAULT_UPSTREAM_VERSION)

    sub.add_parser("refresh-athena", help="snapshot athena-python-docx")

    sp_cmp = sub.add_parser("compare", help="compare snapshots and emit report")
    sp_cmp.add_argument("--upstream", default=None)
    sp_cmp.add_argument("--athena", default=None)
    sp_cmp.add_argument(
        "--update-baseline",
        action="store_true",
        help="write the current actionable list to baseline_gaps.json",
    )

    sp_all = sub.add_parser("all", help="refresh both snapshots and compare")
    sp_all.add_argument("--upstream-version", default=DEFAULT_UPSTREAM_VERSION)
    sp_all.add_argument("--update-baseline", action="store_true")

    args = ap.parse_args()

    if args.cmd == "refresh-upstream":
        refresh_upstream(args.version)
    elif args.cmd == "refresh-athena":
        refresh_athena()
    elif args.cmd == "compare":
        report = compare_snapshots(
            upstream=Path(args.upstream) if args.upstream else None,
            athena=Path(args.athena) if args.athena else None,
            update_baseline=args.update_baseline,
        )
        actionable = sum(1 for f in report["findings"] if not f["intentional"])
        print(f"actionable={actionable}")
    elif args.cmd == "all":
        refresh_upstream(args.upstream_version)
        refresh_athena()
        report = compare_snapshots(update_baseline=args.update_baseline)
        actionable = sum(1 for f in report["findings"] if not f["intentional"])
        print(f"actionable={actionable}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
