"""Lock-in tests for the style-setter stub contract.

The 24 style metadata setters across :class:`BaseStyle` /
:class:`CharacterStyle` / :class:`ParagraphStyle` are upstream-blocked
on SuperDoc 1.7 — see ``docx-studio/PYTHON_DOCX_PARITY_GAPS.md`` for
why. Until SuperDoc adds a per-style metadata op, the SDK behavior is:

1. Calling a setter emits a :class:`PendingStyleMutationWarning`.
2. The new value is stashed in ``self._overrides`` and read back via
   the matching getter (so callers see what they wrote even though
   it's not persisted to the document on save).
3. No SuperDoc bus call is made.

This test file pins all three rules. When SuperDoc lands the
metadata op, these tests will need to flip to assert real
``doc.styles.setMetadata`` calls — which will make the missing
support visible to anyone running the suite.
"""

from __future__ import annotations

from typing import Any

import pytest

from docx.styles.style import (
    BaseStyle,
    CharacterStyle,
    ParagraphStyle,
    PendingStyleMutationWarning,
)


# ---- Properties on BaseStyle that should warn-and-stash ----
_BASE_BOOL_PROPS = ("hidden", "locked", "quick_style", "unhide_when_used")
_BASE_OTHER = (
    ("name", "Custom Name"),
    ("style_id", "custom-id"),
    ("priority", 5),
)


def _make_style(cls: type, **kwargs: Any):
    """Construct a style without a session — setters don't need one."""
    from docx.enum.style import WD_STYLE_TYPE

    return cls(name="Heading 1", style_type=WD_STYLE_TYPE.PARAGRAPH, **kwargs)


@pytest.mark.parametrize("prop", _BASE_BOOL_PROPS)
def test_base_style_bool_setter_warns_and_round_trips(prop: str) -> None:
    style = _make_style(BaseStyle)
    with pytest.warns(PendingStyleMutationWarning, match=prop):
        setattr(style, prop, True)
    assert getattr(style, prop) is True
    with pytest.warns(PendingStyleMutationWarning, match=prop):
        setattr(style, prop, False)
    assert getattr(style, prop) is False


@pytest.mark.parametrize("prop, value", _BASE_OTHER)
def test_base_style_value_setter_warns_and_round_trips(
    prop: str, value: object
) -> None:
    style = _make_style(BaseStyle)
    with pytest.warns(PendingStyleMutationWarning, match=prop):
        setattr(style, prop, value)
    assert getattr(style, prop) == value


def test_character_style_inherits_base_setters_and_adds_base_style() -> None:
    style = _make_style(CharacterStyle)
    # Inherited from BaseStyle.
    with pytest.warns(PendingStyleMutationWarning, match="hidden"):
        style.hidden = True
    assert style.hidden is True
    # CharacterStyle-only.
    other = _make_style(CharacterStyle)
    with pytest.warns(PendingStyleMutationWarning, match="base_style"):
        style.base_style = other
    assert style.base_style is other


def test_paragraph_style_inherits_chain_and_adds_next_paragraph_style() -> None:
    style = _make_style(ParagraphStyle)
    # 3-level inheritance — BaseStyle.priority through CharacterStyle.
    with pytest.warns(PendingStyleMutationWarning, match="priority"):
        style.priority = 12
    assert style.priority == 12
    # ParagraphStyle-only.
    other = _make_style(ParagraphStyle)
    with pytest.warns(PendingStyleMutationWarning, match="next_paragraph_style"):
        style.next_paragraph_style = other
    assert style.next_paragraph_style is other


def test_setter_does_not_call_superdoc_bus() -> None:
    """Style-metadata setters are pure local state — no wire op fires.

    When SuperDoc adds the metadata op, this test should flip to
    assert the expected `doc.styles.setMetadata(...)` call.
    """
    from unittest.mock import MagicMock

    session = MagicMock()
    style = _make_style(BaseStyle, session=session)
    with pytest.warns(PendingStyleMutationWarning):
        style.priority = 99
    # No method on `session.doc` should have been touched. (MagicMock
    # records anything; we check the styles namespace specifically.)
    assert not session.doc.styles.method_calls
    assert not session.doc.styles.apply.called


def test_warning_message_points_to_superdoc_constraint() -> None:
    """The warning text should name the upstream constraint so users
    understand it's a SuperDoc gap, not an athena bug."""
    style = _make_style(BaseStyle)
    with pytest.warns(PendingStyleMutationWarning) as captured:
        style.hidden = True
    assert len(captured) == 1
    msg = str(captured[0].message)
    assert "SuperDoc" in msg
    assert "docDefaults" in msg
    assert "PYTHON_DOCX_PARITY_GAPS.md" in msg
