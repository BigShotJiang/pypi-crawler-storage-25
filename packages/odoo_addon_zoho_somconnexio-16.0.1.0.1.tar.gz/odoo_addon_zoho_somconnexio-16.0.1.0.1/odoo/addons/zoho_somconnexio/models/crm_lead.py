from odoo import models

from zoho_somconnexio_python_client.functions.activate_deal_from_odoo import (
    ActivateZohoDealFromOdoo,
)


class CrmLead(models.Model):
    _inherit = "crm.lead"

    def action_set_new(self):
        stage_lead_to_fill_id = self.env.ref("somconnexio.stage_lead_to_fill")
        leads_to_activate_deal = [
            lead for lead in self if lead.stage_id == stage_lead_to_fill_id
        ]

        super(CrmLead, self).action_set_new()

        for lead in leads_to_activate_deal:
            ActivateZohoDealFromOdoo.activate_deal(lead.id)
