from mock import patch
from odoo.addons.somconnexio.tests.helper_service import crm_lead_create
from odoo.addons.somconnexio.tests.sc_test_case import SCTestCase


class CRMLeadTest(SCTestCase):
    def setUp(self, *args, **kwargs):
        super().setUp(*args, **kwargs)
        self.partner_id = self.browse_ref("somconnexio.res_partner_2_demo")

        self.mobile_crm_lead = crm_lead_create(
            self.env, self.partner_id, "mobile", portability=True
        )
        self.mobile_crm_lead.write(
            {"stage_id": self.env.ref("somconnexio.stage_lead_to_fill").id}
        )

    @patch("odoo.addons.zoho_somconnexio.models.crm_lead.ActivateZohoDealFromOdoo")
    def test_call_zoho_when_lead_to_fill_change_to_new(self, ActivateZohoDealMock):
        self.mobile_crm_lead.action_set_new()
        ActivateZohoDealMock.activate_deal.assert_called_once_with(
            self.mobile_crm_lead.id
        )
