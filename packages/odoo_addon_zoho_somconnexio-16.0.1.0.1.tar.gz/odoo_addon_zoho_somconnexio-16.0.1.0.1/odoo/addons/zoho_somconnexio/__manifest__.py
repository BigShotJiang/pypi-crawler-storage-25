{
    "name": "Zoho - SomConnexio",
    "version": "16.0.1.0.1",
    "summary": """
        This module provides communication with Zoho Som Serveis.
    """,
    "description": """
       Add Zoho call when CRMLead in to fill stage is set new
    """,
    "author": "Coopdevs Treball SCCL, " "Som Connexió SCCL",
    "website": "https://coopdevs.org",
    "license": "AGPL-3",
    "category": "Cooperative management",
    "depends": ["somconnexio"],
    "data": [],
    "demo": [],
    "external_dependencies": {"python": ["zoho_somconnexio_python_client"]},
    "application": False,
    "installable": True,
}
