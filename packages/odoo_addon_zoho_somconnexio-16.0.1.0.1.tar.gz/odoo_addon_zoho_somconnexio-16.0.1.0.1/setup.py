import setuptools

setuptools.setup(
    setup_requires=['setuptools-odoo'],
    odoo_addon={
        "external_dependencies_override": {
            "python": {
                "zoho_somconnexio_python_client": "zoho_somconnexio_python_client==0.1.5",  # noqa E501
            },
        },
    },
)
