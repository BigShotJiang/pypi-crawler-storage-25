# Wave 1 connectors — imported eagerly so they self-register with CatalogRegistry
try:
    from .unity_catalog import UnityCatalogConnector  # noqa: F401
except ImportError:
    pass  # databricks-sdk not installed

try:
    from .collibra import CollibraConnector  # noqa: F401
except ImportError:
    pass  # requests not installed

try:
    from .alation import AlationConnector  # noqa: F401
except ImportError:
    pass  # requests not installed

try:
    from .purview import PurviewConnector  # noqa: F401
except ImportError:
    pass  # msal or requests not installed

# Wave 2 connectors
try:
    from .informatica import InformaticaConnector  # noqa: F401
except ImportError:
    pass  # requests not installed

try:
    from .immuta import ImmutaConnector  # noqa: F401
except ImportError:
    pass  # requests not installed

try:
    from .datahub import DataHubConnector  # noqa: F401
except ImportError:
    pass  # requests not installed
