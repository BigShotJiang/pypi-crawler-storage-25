"""
AutoPIL Catalog Integration layer.

Imports trigger connector self-registration with CatalogRegistry.
"""

from .base import CatalogConnector
from .enricher import ClassificationEnricher
from .registry import CatalogRegistry
from .scheduler import BackgroundSyncScheduler

# Trigger connector registration
from . import connectors  # noqa: F401

__all__ = [
    "CatalogConnector",
    "CatalogRegistry",
    "ClassificationEnricher",
    "BackgroundSyncScheduler",
]
