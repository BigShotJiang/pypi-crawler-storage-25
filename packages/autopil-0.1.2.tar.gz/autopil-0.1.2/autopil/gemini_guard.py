"""
AutoPIL GeminiGuard — context governance for Google Gemini agents.

See packages/core/autopil/gemini_guard.py for full documentation.
This file keeps the root autopil/ namespace in sync.
"""

from .guard import ContextGuard
from .models import SensitivityLevel
from typing import Any, Callable, Optional


class GeminiGuard(ContextGuard):
    """
    AutoPIL ContextGuard for Google Gemini agents.

    Drop-in replacement for ContextGuard that tags every audit event
    with source_type='gemini'.

    Usage:
        from autopil.gemini_guard import GeminiGuard

        guard = GeminiGuard(policy_path="policies/", audit_db="autopil.db")

        @guard.protect(
            agent_role="loan_agent",
            user_id="agent_01",
            source_id="account_summaries",
        )
        def get_account_summary(customer_id: str) -> dict:
            return {"balance": 142000}
    """

    _source_type: str = "gemini"

    async def call_if_allowed_async(
        self,
        fn: Callable[..., Any],
        *,
        agent_role: str,
        user_id: str,
        source_id: str,
        sensitivity_level: SensitivityLevel = SensitivityLevel.MEDIUM,
        session_id: Optional[str] = None,
        fn_args: Optional[dict] = None,
    ) -> Any:
        """Async version of call_if_allowed for async Gemini tool functions."""
        protected = self.protect_async(
            agent_role=agent_role,
            user_id=user_id,
            source_id=source_id,
            sensitivity_level=sensitivity_level,
            session_id=session_id,
        )(fn)
        return await protected(**(fn_args or {}))

    def call_if_allowed(
        self,
        fn: Callable[..., Any],
        *,
        agent_role: str,
        user_id: str,
        source_id: str,
        sensitivity_level: SensitivityLevel = SensitivityLevel.MEDIUM,
        session_id: Optional[str] = None,
        fn_args: Optional[dict] = None,
    ) -> Any:
        """Inline guard for use inside a Gemini tool-call dispatch loop."""
        protected = self.protect(
            agent_role=agent_role,
            user_id=user_id,
            source_id=source_id,
            sensitivity_level=sensitivity_level,
            session_id=session_id,
        )(fn)
        return protected(**(fn_args or {}))
