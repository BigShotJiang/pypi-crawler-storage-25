# Changelog

## v5.0.1 (2026-04-18)

### Competitor benchmark
- **Public competitor leaderboard** under `docs/benchmarks/` comparing checkllm to DeepEval, Ragas, and promptfoo on HaluBench, RAGTruth (hallucination, faithfulness, context_relevance), and TruthfulQA. checkllm holds rank 1 on every published row.
- **TruthfulQA balanced loader** — `load_truthfulqa_from_rows` now emits `best_answer` / `incorrect_answers[0]` sample pairs so ROC-AUC is well-defined on the slice.
- **Answer-aware `ContextRelevanceMetric`** — `evaluate(...)` accepts an optional `answer` kwarg; when provided, the judge grades whether the retrieved context precisely justifies that specific answer. The answer-less path keeps its original semantics.

## v3.2.0 (2026-04-06)

### VS Code Extension
- **checkllm for VS Code** — inline LLM test results in the editor
  - CodeLens annotations above test functions showing pass/fail count, average score, and cost
  - Green/red gutter dots next to each test function
  - Hover popup with per-check score table
  - Auto-refresh when `.checkllm/` result files change
  - Commands: Run Tests, Estimate Costs, Refresh Results
  - Configurable judge backend, model, threshold, and budget via VS Code settings
  - Status bar showing aggregate pass/fail count

## v3.1.0 (2026-04-06)

### Framework Integrations
- **LangChain integration** — `CheckllmCallbackHandler` validates chain/LLM outputs via `on_chain_end` and `on_llm_end` callbacks. Supports `"log"` and `"raise"` failure modes.
- **LlamaIndex integration** — `CheckllmCallbackHandler` validates query engine responses via `on_event_end` callback. Same API as the LangChain handler.
- Both integrations require zero framework dependencies at import time — only checkllm internals are used.

### Enhanced Dashboard
- **Trend charts** — `/api/trends` endpoint returns score-over-time data; frontend renders inline SVG line charts with pass/fail colored dots
- **Cost breakdown** — `/api/cost-breakdown` endpoint returns per-metric and per-test cost aggregation; frontend renders bar charts
- **Search/filter** — filter runs by label, commit, or test name in the runs list

## v3.0.0b1 (2026-04-06)

### CI/CD
- **`checkllm ci` command** — auto-detects GitHub Actions environment, runs tests, and posts formatted results as PR comments. Supports `--budget`, `--compare`, `--fail-on-regression`, and `--no-comment` flags.

### Pytest Helpers
- **Pre-built fixtures** — `shared_judge` (session-scoped judge reuse), `budget_session` (cross-test cost tracking), `auto_snapshot` (auto-save snapshots after sessions). Import from `checkllm.pytest_helpers`.

### Documentation
- **MkDocs site** — full documentation with guides for deterministic checks, LLM metrics, guardrails, CI/CD, custom metrics, plugins, and configuration. Run `mkdocs serve` locally.
- **CONTRIBUTING.md** — contributor guide with architecture overview, step-by-step instructions for adding checks, metrics, and plugins
- **Community templates** — GitHub issue templates (bug report, feature request, new metric proposal) and PR template

## v3.0.0a1 (2026-04-04)

### Developer Experience
- **Auto-detect judge backend** — checkllm now auto-detects the best available LLM judge from your environment (OpenAI > Anthropic > Gemini > Ollama). Zero config needed.
- **Interactive `checkllm init`** — scaffolds tailored test files based on your use case (RAG, chatbot, agent, general) with `--ci` flag for GitHub Actions
- **Smart error messages** — actionable guidance when API keys are missing, budgets are exceeded, or dependencies are needed
- **Cost estimation** — `checkllm estimate tests/` shows expected cost before running; `--dry-run` flag on `checkllm run`
- **Fluent assertions** — `check.that(output).contains("Python").has_no_pii().max_tokens(200)`

### Plugin System
- **Community metric discovery** — third-party packages can register metrics via entry points; `checkllm list-metrics` shows builtin + plugins with source attribution

### CLI
- New `checkllm estimate` command
- `checkllm run --dry-run` flag
- Enhanced `checkllm list-metrics` with categories and plugin discovery
- `checkllm init --use-case` and `--ci` flags

### Internal
- New modules: `discovery.py`, `errors.py`, `estimator.py`, `chain.py`
- Default `judge_backend` changed from `"openai"` to `"auto"`

## 2.0.0 (2026-03-29)

### New LLM-as-Judge Metrics (8 new, 24 total)

- **g_eval** — G-Eval: custom criteria evaluation with chain-of-thought reasoning (most flexible metric)
- **contextual_precision** — are the most relevant retrieved documents ranked higher? (Ragas-style)
- **contextual_recall** — what fraction of the ground-truth answer is supported by context? (Ragas-style)
- **task_completion** — did the LLM actually accomplish the user's stated goal?
- **role_adherence** — does the LLM stay in its assigned persona/role throughout?
- **tool_accuracy** — agent tool selection and parameter correctness evaluation
- **knowledge_retention** — does the chatbot remember facts from earlier in the conversation?
- **conversation_completeness** — were all user requests fulfilled across the multi-turn exchange?

### New Deterministic Checks (5 new, 33 total)

- **bleu** — BLEU score (1-4 gram) with brevity penalty for reference comparison
- **rouge_l** — ROUGE-L (LCS-based F1) for summary/translation evaluation
- **json_field** — JSONPath-style deep field assertions with conditions (exists, gt, lt, contains, type)
- **is_valid_sql** — SQL syntax validation (balanced parens, keywords, string literals)
- **is_valid_markdown** — markdown structure validation with optional header/list/code-block requirements

### Multi-Turn Conversational Evaluation

- **ConversationalTestCase** model for multi-turn conversation threads
- **Turn** model (role, content, metadata) with user/assistant/system filtering
- `format_transcript()` for readable conversation formatting
- Knowledge retention and conversation completeness metrics operate on full conversation context

### Agent / Agentic Workflow Evaluation

- **AgentTestCase** with query, steps, tool calls, trajectory, and final output
- **ToolCall** model (name, parameters, result, timestamp)
- **AgentStep** model (thought, action, tool_call, observation)
- `validate_tool_calls()` — compare actual vs expected tool usage
- `validate_trajectory_length()` — ensure agent efficiency
- `validate_tool_order()` — verify tool call sequencing via LCS
- `validate_no_repeated_tools()` — detect redundant tool usage

### Synthetic Test Data Generation

- **Synthesizer** class — generate test cases from documents or descriptions using an LLM
- `from_documents()` — ground test cases in provided document corpus
- `from_description()` — generate from free-text system description
- `evolve()` — make existing test cases more challenging
- 6 evolution strategies: simple, reasoning, multi_context, conditional, adversarial, comparative
- Parallel batch generation with cost tracking

### Red Teaming / Adversarial Testing

- **RedTeamer** — automated vulnerability scanning for LLM applications
- 10 vulnerability types: prompt injection, jailbreak, PII leakage, harmful content, bias exploitation, context manipulation, instruction override, role escape, data extraction, encoding attack
- 8 attack enhancement strategies: direct, roleplay, leetspeak, ROT-13, base64, multi-turn, logic trap, authority
- 70+ built-in attack templates
- Heuristic + LLM-judge evaluation of attack success
- **VulnerabilityReport** with severity breakdown and summary

### Batch API Support

- **BatchEvaluator** — submit evaluation jobs via OpenAI batch API for 50% cost savings
- JSONL request building, file upload, polling, and result retrieval
- Automatic cost estimation at batch discount rate

### Streaming Evaluation

- **StreamingEvaluator** — evaluate LLM outputs as they stream token by token
- Configurable check intervals with sync and async check support
- Early stop conditions for immediate termination
- **StreamingCheckpoint** model for progressive evaluation status

### OpenTelemetry Tracing

- **Tracer** with `span()` context manager and `trace()` decorator
- Integrates with OpenTelemetry when available, falls back to local-only
- Record CheckResults as span events
- Nested span support, JSON export, sync and async function tracing

### Experiment Tracking

- **ExperimentTracker** with SQLite persistence
- `start_run()`, `log_results()`, `end_run()` lifecycle
- Run comparison with score/pass-rate/cost diffs and per-metric analysis
- `best_run()` by avg_score, pass_rate, cost, or custom metric
- Tag-based filtering and prompt version tracking

### YAML Declarative Evaluation Configs

- Define evaluations in YAML (promptfoo-style): providers, prompts, tests, assertions
- **YamlEvalRunner** — orchestrate provider x prompt x test matrix
- Jinja2 template rendering for prompt variables
- 30+ assertion types mapped to deterministic and LLM checks
- `checkllm yaml-run config.yaml` CLI command

### Interactive Web Dashboard

- `checkllm dashboard` — browser-based UI for exploring evaluation results
- Dark theme with modern design, no external JS/CSS dependencies
- Experiment run list with search/filter
- Run detail view with score distribution charts
- Side-by-side run comparison with delta badges

### New CLI Commands

- `checkllm dashboard` — launch interactive web dashboard
- `checkllm yaml-run` — run YAML-defined evaluations
- `checkllm redteam` — automated red teaming against an LLM
- `checkllm experiments` — view and compare experiment tracking data

### GitHub Action Template

- Ready-to-use `.github/workflows/checkllm-action.yml` template
- Deterministic + LLM evaluation with budget controls
- Automatic PR comment with results summary
- Artifact upload for full reports

### Stats

- 1,112 tests (up from 836)
- 87 public API symbols (up from 55)
- 74 source files, 16,350 LOC
- 84 test files, 13,031 LOC
- 24 LLM-as-judge metrics + 33 deterministic checks
- 14 CLI commands

## 1.0.0 (2026-03-29)

### Parallel Evaluation Engines

- **AsyncEngine** — asyncio-based with configurable concurrency and backpressure
- **ThreadPoolEngine** — threading-based for I/O-bound judge calls in sync code
- **ProcessPoolEngine** — for CPU-bound deterministic checks at scale
- **HybridEngine** — auto-routes judge calls to async, deterministic to threads
- **create_engine()** factory with `engine="auto"` smart selection
- All engines track tasks submitted/completed, average execution time, queue depth

### Multi-Provider Judge Backends

- **GeminiJudge** — Google Gemini API (gemini-2.0-flash, gemini-2.0-pro, etc.)
- **AzureOpenAIJudge** — Azure-hosted OpenAI models
- **OllamaJudge** — local models via Ollama HTTP API (cost=0, no API key needed)
- **LiteLLMJudge** — 100+ models through LiteLLM unified interface
- **CustomHTTPJudge** — any REST endpoint with configurable response parsing
- **create_judge()** factory for all 7 backends

### Consensus Judging

- Run the same evaluation across multiple judges simultaneously
- 7 aggregation strategies: `majority`, `unanimous`, `mean`, `weighted`, `median`, `min`, `max`
- `ConsensusJudge` class implements `JudgeBackend` protocol (nestable)
- `consensus()` convenience function for quick multi-judge evaluation
- Tracks agreement ratio, individual votes, costs per judge

### New LLM-as-Judge Metrics (8 new)

- **faithfulness** — RAG: is the answer faithful to retrieved context?
- **context_relevance** — RAG: is the retrieved context relevant to the query?
- **answer_completeness** — does the answer fully address all parts of the question?
- **instruction_following** — does the output follow given format/style/constraint instructions?
- **summarization** — summary accuracy, conciseness, and key information retention
- **bias** — demographic, cultural, gender, racial bias detection (1.0=no bias)
- **consistency** — multi-output consistency comparison
- **groundedness** — claim-by-claim grounding across multiple source documents

### Embedding-based Semantic Similarity

- `check.semantic_similarity()` using embedding cosine similarity
- **OpenAIEmbeddings** — text-embedding-3-small/large, ada-002 with cost tracking
- **SentenceTransformerEmbeddings** — local models (all-MiniLM-L6-v2, etc.), cost=0
- **CachedEmbeddings** — LRU cache wrapper for any embedding backend
- `batch_semantic_similarity()` with text deduplication for efficiency

### Guardrails Mode (Runtime Validation)

- **Guard** class for production runtime LLM output validation
- `guard.validate(output)` / `guard.avalidate(output)` — sync and async
- **CheckSpec** model for declarative check definitions
- Predefined guards: `safety_guard`, `quality_guard`, `rag_guard`
- **GuardrailMiddleware** — ASGI middleware for FastAPI/Starlette
- **@guardrail** decorator for function-level validation
- Soft checks that record but don't block

### Rate Limiting & Circuit Breaker

- **TokenBucketRateLimiter** — classic token bucket with async acquire
- **PerProviderRateLimiter** — separate limits per provider
- **CircuitBreaker** — auto-disable failing backends (CLOSED→OPEN→HALF_OPEN→CLOSED)
- **ResilientJudge** — wraps any judge with rate limiting + circuit breaker + fallback
- **RetryPolicy** — configurable retry with exponential backoff and jitter
- **with_retry()** async utility

### Enhanced Reporting

- **A/B comparison reports** — side-by-side HTML/Markdown/terminal with color-coded deltas
- **Trend reports** — inline SVG charts for score/pass-rate/cost over time
- **CSV export** — `write_csv()` and `results_to_dataframe()` for data analysis
- **GitHub PR comments** — `generate_pr_comment()` with collapsible details, `post_pr_comment()` via API

### Configuration Profiles

- Define profiles in `[tool.checkllm.profiles.dev]`, `[tool.checkllm.profiles.ci]`, etc.
- Activate via `CHECKLLM_PROFILE=ci` or `--profile ci`
- Merge order: defaults → base config → profile → env vars
- New `engine` config option for parallel execution strategy

### Programmatic API

- `evaluate()` async function — use checkllm outside pytest
- `check_output()` sync wrapper — one-liner validation
- **Evaluator** builder — fluent API with `.with_judge()`, `.add_check()`, `.run()`, `.batch_run()`
- `parse_check_shorthand()` — parse `"no_pii"` or `"max_tokens:200"` into check specs

### Watch Mode

- `checkllm watch tests/` — re-run tests on file changes
- Cross-platform polling (no external dependencies)
- Debounced detection, configurable patterns and intervals
- Rich terminal output with run history

### Other

- 836 tests (up from ~250)
- 55 public API symbols exported from top-level package
- Optional dependencies: `checkllm[gemini]`, `checkllm[litellm]`, `checkllm[embeddings]`, `checkllm[all]`

## 0.3.0 (2026-03-29)

### Testing Helpers (`checkllm.testing`)

- **MockJudge** — fake judge backend with configurable scores, queued per-metric responses, and call tracking assertions
- **make_collector()** — factory with test-friendly defaults (cache disabled, MockJudge)
- **assert_all_passed()**, **assert_score_above()** — assertion helpers

### New Deterministic Checks

- **no_pii** — regex-based PII detection (email, phone, SSN, credit card, IP address)
- **language** — heuristic word-frequency language detection (en, es, fr, de, pt)
- **greater_than**, **less_than**, **between** — numeric extraction and comparison

### New Report Formats

- **Markdown report** (`--checkllm-markdown`) — ideal for PR comments and GitHub Actions
- **JSONL export** (`--checkllm-jsonl`) — one JSON record per line for data pipelines
- Both available as pytest flags and programmatic API

### Other

- **py.typed** marker for PEP 561 type checking
- Exported `MockJudge`, `make_collector`, `assert_all_passed`, `assert_score_above` from top-level package

## 0.2.0 (2026-03-28)

### New Checks (Deterministic)

- **similarity** — Levenshtein ratio for fuzzy string comparison
- **readability** — Flesch-Kincaid Grade Level with min/max bounds
- **min_tokens**, **word_count**, **char_count**, **sentence_count** — text length checks with flexible bounds
- **all_of**, **any_of**, **none_of** — compound substring checks
- **is_json** — validate parseable JSON without requiring a schema
- **is_valid_python** — validate Python syntax (auto-strips markdown code fences)

### New Metrics (LLM-as-Judge)

- **fluency** — writing quality and naturalness
- **coherence** — logical structure and consistency
- **sentiment** — tone/mood assessment (0=negative, 1=positive)
- **correctness** — semantic comparison against expected/reference answers

### Developer Experience

- **Soft assertions** (`check.expect.*`) — same API as `check` but never fails the test. Soft checks are recorded with `[soft]` prefix for monitoring during prompt iteration.
- **py.typed** — PEP 561 marker for type checking support
- **Rich progress bar** in `checkllm eval` command
- **Enhanced HTML report** — modern design with score bars, collapsible test sections, pass rate visualization

### Features

- **Judge response caching**: SQLite-backed content-addressable cache for LLM judge responses. Cache hits return instantly at zero cost. Configurable TTL (default 7 days). CLI commands: `checkllm cache --stats`, `checkllm cache --clear`. Disable with `--no-cache` or `CHECKLLM_CACHE_ENABLED=false`.
- **Parallel judge execution**: Async judge calls are rate-limited via configurable `asyncio.Semaphore` (default 10 concurrent). Use `asyncio.gather` with async check methods for parallel evaluation.
- **Cost budgets**: Set a max USD spend per run with `--budget`, `CHECKLLM_BUDGET`, or `budget` in pyproject.toml. When exceeded, remaining judge calls are skipped with a clear warning.
- **Historical run tracking**: Every test run is recorded in `.checkllm/history.db` with timestamp, git commit, label, scores, and costs. CLI: `checkllm history`, `--run ID`, `--compare ID1,ID2`, `--trend test::metric`.
- **Enhanced run comparison**: Side-by-side diff of two historical runs showing per-test score deltas with color-coded improvements/regressions.
- **CSV and JSON dataset support**: `load_dataset()` and `@dataset()` now auto-detect `.csv`, `.json`, `.yaml`, `.yml` files. CSV extra columns go into `case.metadata`.
- **Customizable judge prompts**: Override the system prompt for any built-in metric via `system_prompt=` kwarg on `check.hallucination()`, `check.relevance()`, `check.toxicity()`, `check.rubric()`, and their async variants.
- **Structured logging**: Python `logging` module integration. Set `CHECKLLM_LOG_LEVEL=DEBUG` or configure in pyproject.toml. Logs cache hits/misses, costs, budget warnings.

### Configuration

New `[tool.checkllm]` options: `cache_enabled`, `cache_dir`, `cache_ttl_seconds`, `max_concurrency`, `budget`, `log_level`.

New environment variables: `CHECKLLM_CACHE_ENABLED`, `CHECKLLM_CACHE_DIR`, `CHECKLLM_CACHE_TTL`, `CHECKLLM_MAX_CONCURRENCY`, `CHECKLLM_BUDGET`, `CHECKLLM_LOG_LEVEL`.

## 0.1.0 (2026-03-28)

Initial release.

### Features

- **pytest plugin** with `check` fixture for LLM testing in pytest
- **Deterministic checks**: `contains`, `not_contains`, `regex`, `json_schema`, `max_tokens`, `latency`, `cost`
- **LLM-as-judge metrics**: `hallucination`, `relevance`, `toxicity`, `rubric`
- **Custom metrics** via `@metric` decorator and plugin entry points
- **Dataset system**: YAML loading, generator functions, `@dataset` decorator for parametrized tests
- **Regression detection**: Welch's t-test with configurable p-value threshold
- **Snapshot system**: save/load/compare test result baselines
- **Reporting**: Rich terminal output, HTML reports, JUnit XML
- **CLI**: `checkllm run`, `snapshot`, `report`, `eval`, `diff`, `init`
- **Multiple judge backends**: OpenAI and Anthropic
- **Retry logic** with exponential backoff for transient API failures
- **Cost tracking** from OpenAI/Anthropic token usage
- **Configuration** via `pyproject.toml [tool.checkllm]` and environment variables
