# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "ours_privacy"
__version__ = "1.12.1"  # x-release-please-version
