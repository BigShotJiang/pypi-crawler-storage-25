import logging
from typing import Optional

import requests
from zeep import Client
from zeep.exceptions import Fault
from zeep.transports import Transport
from zeep.wsse.username import UsernameToken

from drac_notifier.config import SMIS_PASSWORD
from drac_notifier.config import SMIS_SERVER
from drac_notifier.config import SMIS_USERNAME

logger = logging.getLogger(__name__)


class SmisClient:
    """Client to interact with UserPortal"""

    def __init__(self):
        self.server = SMIS_SERVER
        self.username = SMIS_USERNAME
        self.password = SMIS_PASSWORD

        session = requests.Session()
        session.auth = (self.username, self.password)
        transport = Transport(session=session)

        user_wsdl_url = f"{self.server}/SMISServer-ejb3/UserLookupWebService/UserLookupWebServiceBean?wsdl"
        self.user_client = Client(
            user_wsdl_url,
            transport=transport,
            wsse=UsernameToken(self.username, self.password),
        )

        smis_wsdl_url = (
            f"{self.server}/SMISServer-ejb3/SMISWebService/SMISWebServiceBean?wsdl"
        )
        self.smis_client = Client(
            smis_wsdl_url,
            transport=transport,
            wsse=UsernameToken(self.username, self.password),
        )

    def get_user_email(self, username: str) -> Optional[str]:
        smis_username = username.split("/")[0]
        try:
            user_id = self.user_client.service.getUserIdForUserName(smis_username)

            if not user_id:
                logger.warning(f"No SMIS user ID found for {smis_username}")
                return None

            user_light_vo = self.smis_client.service.findUserByScientistPk(user_id)

            if not user_light_vo:
                logger.warning(f"No SMIS user found for ID {user_id}")
                return None

            email = getattr(user_light_vo, "scientistEmail", None)
            return email

        except Fault as fault:
            logger.warning(
                f"SMIS lookup failed for username={smis_username}: {fault.message}"
            )
            return None

        except Exception:
            logger.exception(
                f"Unexpected error while retrieving email for {smis_username}"
            )
            return None
