import logging
from typing import List
from typing import Optional

from icat_plus_client import ApiClient
from icat_plus_client import CatalogueApi
from icat_plus_client import Configuration
from icat_plus_client import SessionApi
from icat_plus_client.models import Credentials
from icat_plus_client.models import Investigation
from icat_plus_client.models import Investigationusers

from drac_notifier.config import ICAT_PLUS_PASSWORD
from drac_notifier.config import ICAT_PLUS_PLUGIN
from drac_notifier.config import ICAT_PLUS_SERVER
from drac_notifier.config import ICAT_PLUS_USERNAME

logger = logging.getLogger(__name__)


class IcatClient:
    """Client to interact with ICAT+"""

    def __init__(self):
        self.configuration = Configuration(host=ICAT_PLUS_SERVER)
        self.username = ICAT_PLUS_USERNAME
        self.password = ICAT_PLUS_PASSWORD
        self.plugin = ICAT_PLUS_PLUGIN
        self.session_id: Optional[str] = None

    def login(self) -> Optional[str]:
        """Authenticate and store session_id"""
        try:
            with ApiClient(self.configuration) as api_client:
                api_instance = SessionApi(api_client)
                cred = Credentials(
                    username=self.username,
                    password=self.password,
                    plugin=self.plugin,
                )
                response = api_instance.session_post(cred)
                self.session_id = response.session_id
                logger.info("Logged in to ICAT+, session_id obtained")
                return self.session_id
        except Exception as exc:
            logger.exception("Unexpected error during login: %s", exc)
        return None

    def get_investigations(
        self,
        release_dates: Optional[str] = None,
    ) -> List[Investigation]:
        """Fetch investigations from ICAT+"""
        if not self.session_id:
            logger.error("No session_id. Please login first.")
            return []

        with ApiClient(self.configuration) as api_client:
            api_instance = CatalogueApi(api_client)
            try:
                investigations = api_instance.catalogue_session_id_investigation_get(
                    session_id=self.session_id,
                    release_dates=release_dates,
                )
                logger.info(
                    "Fetched %d investigations",
                    len(investigations) if investigations else 0,
                )
                return investigations or []
            except Exception as exc:
                logger.exception("Unexpected error fetching investigations: %s", exc)
        return []

    def get_investigation_users(
        self,
        investigation_id: str,
    ) -> List[Investigationusers]:
        """Fetch investigation users from ICAT+"""
        if not self.session_id:
            logger.error("No session_id. Please login first.")
            return []

        with ApiClient(self.configuration) as api_client:
            api_instance = CatalogueApi(api_client)
            try:
                users = api_instance.catalogue_session_id_investigation_id_investigation_id_investigationusers_get(
                    session_id=self.session_id,
                    investigation_id=investigation_id,
                )
                logger.info(
                    "Fetched %d investigation users",
                    len(users) if users else 0,
                )
                return users or []
            except Exception as exc:
                logger.exception(
                    "Unexpected error fetching investigation users: %s", exc
                )
        return []
