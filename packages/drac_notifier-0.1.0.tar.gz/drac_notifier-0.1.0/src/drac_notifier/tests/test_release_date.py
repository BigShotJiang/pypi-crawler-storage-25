from datetime import date

from drac_notifier.notifications.end_embargo import _calculate_target_dates


def test_calculate_target_dates_with_given_date():
    result = _calculate_target_dates("2026-03-23")
    assert result[0] == "2026-04-23"
    assert result[1] == "2026-06-23"


def test_calculate_target_dates_with_default_today(monkeypatch):
    class FakeDate(date):
        @classmethod
        def today(cls):
            return cls(2026, 3, 23)

    monkeypatch.setattr("drac_notifier.notifications.end_embargo.date", FakeDate)

    result = _calculate_target_dates()
    assert result[0] == "2026-04-23"
    assert result[1] == "2026-06-23"
