import os

from dotenv import load_dotenv

load_dotenv(override=True)  # loads .env


def get_env(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise RuntimeError(f"Environment variable {name} is required but not set.")
    return value


ICAT_PLUS_SERVER = get_env("ICAT_PLUS_SERVER")
ICAT_PLUS_USERNAME = get_env("ICAT_PLUS_USERNAME")
ICAT_PLUS_PASSWORD = get_env("ICAT_PLUS_PASSWORD")
ICAT_PLUS_PLUGIN = get_env("ICAT_PLUS_PLUGIN")
SMIS_SERVER = get_env("SMIS_SERVER")
SMIS_USERNAME = get_env("SMIS_USERNAME")
SMIS_PASSWORD = get_env("SMIS_PASSWORD")
BCC_EMAIL = get_env("BCC_EMAIL")
SENDER_EMAIL = get_env("SENDER_EMAIL")
