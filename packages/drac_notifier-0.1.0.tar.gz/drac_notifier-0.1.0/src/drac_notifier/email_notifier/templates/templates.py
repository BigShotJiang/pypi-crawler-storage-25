from datetime import datetime
from typing import Tuple
from urllib.parse import quote

from icat_plus_client.models import Investigation

from .end_embargo import EMBARGO_TEMPLATE


def build_embargo_email(inv: Investigation) -> Tuple[str, str]:
    start_date = _format_date(inv.start_date)
    end_date = _format_date(inv.end_date)
    proposal = inv.name
    beamline = inv.instrument.name
    release_date = _format_date(inv.release_date)
    proposal_subject = f"{proposal} on {beamline} From {start_date} to {end_date}"
    mailto_subject = f"Embargo extension: {proposal_subject}"
    mailto_subject_encoded = quote(mailto_subject)
    mailto_link = f"mailto:doroffice@esrf.fr?subject={mailto_subject_encoded}"
    subject = f"ESRF data end of embargo: {proposal_subject}"

    html = EMBARGO_TEMPLATE.format(
        proposal=proposal,
        beamline=beamline,
        start_date=start_date,
        end_date=end_date,
        release_date=release_date,
        doi_link=f"https://doi.org/{inv.doi}",
        data_policy="https://www.esrf.fr/files/live/sites/www/files/Infrastructure/Computing/ESRF-data-policy_20240101.pdf",
        mailto_link=mailto_link,
    )

    return subject, html


def _format_date(date_str: str) -> str:
    dt = datetime.fromisoformat(date_str)
    return dt.strftime("%Y-%m-%d")
