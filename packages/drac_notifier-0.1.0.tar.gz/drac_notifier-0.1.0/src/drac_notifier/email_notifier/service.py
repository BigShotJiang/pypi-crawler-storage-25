import logging
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import List
from typing import Optional

logger = logging.getLogger(__name__)


class EmailService:
    def __init__(
        self,
        smtp_host: str,
        sender: str,
        reply_to: str,
        bcc: Optional[str] = None,
        mode: str = "normal",
    ):
        if mode not in {"normal", "dry-run", "test"}:
            raise ValueError(f"Invalid mode: {mode}")
        self.mode = mode
        self.smtp_host = smtp_host
        self.sender = sender
        self.reply_to = reply_to
        self.bcc = bcc

    def send_html_email(
        self, subject: str, html_body: str, to_emails: List[str]
    ) -> None:
        if not to_emails:
            logger.warning("[EMAIL][SKIP] No recipients")
            return
        recipients = list(dict.fromkeys(to_emails))
        if self.mode == "dry-run":
            logger.info(
                f"[EMAIL][DRY_RUN] subject='{subject}' intended_recipients={recipients}"
            )
            return
        msg = MIMEMultipart()
        msg["Subject"] = subject
        msg["From"] = self.sender
        msg["Reply-To"] = self.reply_to
        if self.mode == "test":
            if not self.bcc:
                logger.warning("[EMAIL][TEST_MODE] No BCC specified, skipping")
                return
            send_list = [self.bcc]
            msg["To"] = self.bcc
            logger.info(
                f"[EMAIL][TEST] subject='{subject}' redirected_to_bcc={self.bcc} original_recipients={recipients}"
            )
        else:
            send_list = recipients.copy()
            msg["To"] = ", ".join(recipients)
            if self.bcc:
                send_list.append(self.bcc)
        msg.attach(MIMEText(html_body, "html"))
        try:
            with smtplib.SMTP(self.smtp_host) as server:
                server.sendmail(self.sender, send_list, msg.as_string())

            logger.info(
                f"[EMAIL][SENT] subject='{subject}' to={recipients} bcc={self.bcc}"
            )
        except Exception:
            logger.exception("[EMAIL][ERROR] Failed to send email")
