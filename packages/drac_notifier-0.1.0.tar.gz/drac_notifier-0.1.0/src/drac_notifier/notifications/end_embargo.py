import logging
from datetime import date
from datetime import datetime
from typing import List
from typing import Optional
from typing import Set

from dateutil.relativedelta import relativedelta
from icat_plus_client.models import Investigation
from icat_plus_client.models import Investigationusers

from drac_notifier.clients.icat_plus import IcatClient
from drac_notifier.clients.smis import SmisClient
from drac_notifier.config import BCC_EMAIL
from drac_notifier.config import SENDER_EMAIL
from drac_notifier.email_notifier.service import EmailService
from drac_notifier.email_notifier.templates.templates import build_embargo_email

logger = logging.getLogger(__name__)


def send_embargo_notifications(
    reference_date: Optional[str], mode: str = "normal"
) -> None:
    logger.info("START EMBARGO NOTIFICATIONS")
    client = IcatClient()
    client.login()
    smis_client = SmisClient()
    email_service = EmailService(
        smtp_host="localhost",
        sender=SENDER_EMAIL,
        reply_to=SENDER_EMAIL,
        bcc=BCC_EMAIL,
        mode=mode,
    )

    target_dates = _calculate_target_dates(reference_date)
    release_dates = ",".join(target_dates)
    logger.info(f"Release dates: {release_dates}")

    investigations = client.get_investigations(release_dates=release_dates)
    for inv in investigations:
        logger.info(
            f"[INVESTIGATION] id={inv.id} name={inv.name} release_date={inv.release_date}"
        )
        users = client.get_investigation_users(inv.id)
        emails = set()
        missing_users = []
        for user in users:
            email = smis_client.get_user_email(user.name)

            if email:
                emails.add(email)
                logger.info(
                    f"[USER][OK] inv_id={inv.id} user={user.name} role={user.role} email={email}"
                )
            else:
                missing_users.append(user.name)
                logger.warning(
                    f"[USER][NO_EMAIL] inv_id={inv.id} user={user.name} role={user.role}"
                )
        # summary
        skip = _log_summary_investigation(inv, users, emails, missing_users)
        if skip:
            continue

        try:
            subject, html = build_embargo_email(inv)
        except Exception:
            logger.exception(
                f"[EMAIL][ERROR] Failed to build email for inv_id={inv.id}"
            )
            continue
        logger.info(f"[EMAIL][PREPARE] inv_id={inv.id} recipients={len(emails)}")
        email_service.send_html_email(
            subject=subject,
            html_body=html,
            to_emails=list(emails),
        )

        logger.info("=" * 60)

    logger.info("END Embargo notifications sent successfully")


def _log_summary_investigation(
    inv: Investigation,
    users: List[Investigationusers],
    emails: Set[str],
    missing_users: List[str],
) -> bool:
    logger.info(
        f"[SUMMARY] inv_id={inv.id} total_users={len(users)} "
        f"emails_found={len(emails)} missing={len(missing_users)}"
    )
    if missing_users:
        logger.warning(
            f"[SUMMARY][MISSING_EMAILS] inv_id={inv.id} users={missing_users}"
        )
    if not emails:
        logger.warning(f"[SKIP] No emails for investigation {inv.id} name={inv.name}")
        return True
    return False


def _calculate_target_dates(reference_date: Optional[str] = None) -> List[str]:
    """
    Returns the target dates for embargo notifications:
      - 1 month after reference_date
      - 3 months after reference_date

    If reference_date is None, use today.
    """
    if reference_date:
        ref_date = datetime.strptime(reference_date, "%Y-%m-%d").date()
    else:
        ref_date = date.today()
    one_month_date = ref_date + relativedelta(months=1)
    three_month_date = ref_date + relativedelta(months=3)

    return [one_month_date.isoformat(), three_month_date.isoformat()]
