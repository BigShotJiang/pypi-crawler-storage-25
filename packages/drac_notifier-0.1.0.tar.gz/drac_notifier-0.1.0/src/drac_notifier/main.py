import argparse
import logging
from datetime import datetime

from drac_notifier.notifications.end_embargo import send_embargo_notifications

logging.basicConfig(level=logging.INFO, format="%(levelname)s:%(name)s:%(message)s")
logger = logging.getLogger(__name__)


def main():
    parser = argparse.ArgumentParser(
        description="DRAC Notifier tasks",
        epilog="Example: python -m drac_notifier.main embargo 2026-02-01 --mode dry-run",
    )
    parser.add_argument("task", choices=["embargo"], help="Task to run")
    parser.add_argument(
        "date",
        nargs="?",
        default=None,
        help="Reference date in YYYY-MM-DD format (optional)",
    )
    parser.add_argument(
        "--mode",
        choices=["normal", "dry-run", "test"],
        default="normal",
        help="Email sending mode: normal (send), dry-run (no send), test (send only to bcc)",
    )

    args = parser.parse_args()

    if args.date:
        try:
            datetime.strptime(args.date, "%Y-%m-%d")
        except ValueError:
            logger.error("Invalid date format: %s. Expected YYYY-MM-DD", args.date)
            return

    if args.task == "embargo":
        send_embargo_notifications(reference_date=args.date, mode=args.mode)
    else:
        logger.error("Unknown task: %s", args.task)


if __name__ == "__main__":
    main()
