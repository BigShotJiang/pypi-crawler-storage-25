# drac-notifier

Service for sending user notifications from ICAT based on data lifecycle events.

## End of embargo email

An email is sent to all users linked to an experiment session to notify them of the end of the embargo period, 3 months and 1 month before the end date.
