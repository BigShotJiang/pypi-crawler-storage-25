"""
Jiskta Python SDK
~~~~~~~~~~~~~~~~~

Simple client for the Jiskta Climate Data API.
https://jiskta.com/docs

Usage::

    from jiskta import JisktaClient

    client = JisktaClient(api_key="sk_live_...")
    df = client.query(
        lat=(48.0, 49.0),
        lon=(2.0, 3.0),
        start="2023-01",
        end="2023-12",
        variables=["no2", "pm2p5"],
    )
    print(df.head())
"""

from .client import JisktaClient, Variable, CamsVariable, Era5Variable, Aggregate
from .exceptions import JisktaError, AuthError, InsufficientCreditsError, RateLimitError

__version__ = "0.5.2"
__all__ = [
    "JisktaClient",
    "Variable", "CamsVariable", "Era5Variable", "Aggregate",
    "JisktaError", "AuthError", "InsufficientCreditsError", "RateLimitError",
]
