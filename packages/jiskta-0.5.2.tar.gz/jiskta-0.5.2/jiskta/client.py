from __future__ import annotations

import io
import os
import time
from typing import Literal, Sequence

import requests

from .exceptions import AuthError, InsufficientCreditsError, JisktaError, RateLimitError

_DEFAULT_BASE_URL = "https://api.jiskta.com"

CamsVariable = Literal["no2", "pm2p5", "pm10", "o3"]
Era5Variable = Literal["t2m", "u10", "v10", "blh", "tp"]
Variable = Literal[
    # CAMS EU / Global air quality
    "no2", "pm2p5", "pm10", "o3",
    # ERA5 meteorology
    "t2m", "u10", "v10", "blh", "tp",
    # Derived from ERA5
    "wind_speed", "wind_dir",
    # VIIRS nighttime lights (economic activity proxy)
    "viirs_radiance",
    # GHSL — Global Human Settlement Layer
    "ghsl_pop", "ghsl_built", "ghsl_built_nres",
    # MODIS land cover
    "modis_urban",
    # ODIAC fossil-fuel CO₂ emissions
    "odiac_co2",
]

Aggregate = Literal[
    "hourly", "daily", "monthly", "annual",
    "area_hourly", "area_daily", "area_monthly",
    "diurnal", "exceedance", "percentile",
    "seasonal", "trend", "max", "min", "cumulative", "stddev",
]

_WIND_DERIVED = frozenset(("wind_speed", "wind_dir"))


def _expand_wind_vars(variables: list[str]) -> tuple[list[str], bool]:
    """Replace wind_speed/wind_dir with u10/v10 for the API call.

    Returns the expanded variable list and a flag indicating whether any
    wind-derived variables were requested.
    """
    requested = set(variables)
    if not (_WIND_DERIVED & requested):
        return variables, False

    expanded = [v for v in variables if v not in _WIND_DERIVED]
    if "u10" not in expanded:
        expanded.append("u10")
    if "v10" not in expanded:
        expanded.append("v10")
    return expanded, True


def _compute_wind_derived(
    df: "pd.DataFrame",
    orig_variables: list[str],
    api_variables: list[str],
) -> "pd.DataFrame":
    """Post-process a DataFrame to add wind_speed and/or wind_dir columns.

    wind_speed = √(u10² + v10²)  [m/s]
    wind_dir   = meteorological convention — direction wind is coming FROM,
                 0° = North, 90° = East.  Formula: (270 − atan2(v10, u10)) % 360
    """
    import math

    needs_speed = "wind_speed" in orig_variables
    needs_dir = "wind_dir" in orig_variables
    had_u10 = "u10" in orig_variables
    had_v10 = "v10" in orig_variables

    # Locate u10/v10 columns (handles "u10", "u10_mean", "u10_min", etc.)
    u10_col = next((c for c in df.columns if c == "u10" or c.startswith("u10_")), None)
    v10_col = next((c for c in df.columns if c == "v10" or c.startswith("v10_")), None)

    if u10_col is None or v10_col is None:
        return df  # no wind data in response (e.g. trend mode)

    suffix = u10_col[3:]  # "" for hourly, "_mean" for daily/monthly, etc.

    if needs_speed:
        df[f"wind_speed{suffix}"] = (df[u10_col] ** 2 + df[v10_col] ** 2) ** 0.5

    if needs_dir:
        u_vals = df[u10_col].to_numpy()
        v_vals = df[v10_col].to_numpy()
        df[f"wind_dir{suffix}"] = [
            (270 - math.degrees(math.atan2(float(v), float(u)))) % 360
            for u, v in zip(u_vals, v_vals)
        ]

    # Drop u10/v10 if the caller did not request them directly
    if not had_u10:
        df = df.drop(columns=[u10_col], errors="ignore")
    if not had_v10:
        df = df.drop(columns=[v10_col], errors="ignore")

    return df


class JisktaClient:
    """
    Client for the Jiskta Climate Data API.

    Parameters
    ----------
    api_key:
        Your ``sk_live_...`` key from https://jiskta.com/dashboard.
        If omitted, the ``JISKTA_API_KEY`` environment variable is used.
    base_url:
        Override the API base URL (useful for testing).
    timeout:
        Request timeout in seconds (default: 60).
    max_retries:
        Number of retries on HTTP 429 / transient errors (default: 3).
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: int = 60,
        max_retries: int = 3,
    ) -> None:
        resolved = api_key or os.environ.get("JISKTA_API_KEY", "")
        if not resolved:
            raise ValueError(
                "api_key is required. Pass it directly or set the JISKTA_API_KEY "
                "environment variable."
            )
        self._api_key = resolved
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._session = requests.Session()
        self._session.headers.update({"X-API-Key": api_key})

    # ── Public API ────────────────────────────────────────────────────────────

    def query(
        self,
        *,
        lat: float | tuple[float, float] | None = None,
        lon: float | tuple[float, float] | None = None,
        start: str,
        end: str,
        variables: Sequence[Variable] = ("no2",),
        aggregate: Aggregate = "daily",
        threshold: float | None = None,
        percentile: int | None = None,
        area: str | None = None,
        facility: "str | int | None" = None,
        sort_by: str | None = None,
        sort_dir: Literal["asc", "desc"] | None = None,
        unit: Literal["ppb"] | None = None,
        round: int | None = None,
        dry_run: bool = False,
        missing_null: bool = False,
        no_header: bool = False,
        include_polygon: bool = False,
        return_divergence: bool = False,
    ) -> "pd.DataFrame | tuple[pd.DataFrame, dict | None]":
        """
        Query climate data and return a pandas DataFrame.

        Parameters
        ----------
        lat:
            ``(lat_min, lat_max)`` bounding box **or** a single ``float``
            for a point query (snaps to nearest 0.1° grid cell).
            Optional when ``area`` or ``facility`` is provided.
        lon:
            ``(lon_min, lon_max)`` bounding box **or** a single ``float``
            for a point query (snaps to nearest 0.1° grid cell).
            Optional when ``area`` or ``facility`` is provided.
        start:
            Start date — accepts ``"YYYY-MM-DD"`` or ``"YYYY-MM"``.
        end:
            End date — accepts ``"YYYY-MM-DD"`` or ``"YYYY-MM"``.
        variables:
            One or more variable names. CAMS air quality: ``"no2"``,
            ``"pm2p5"``, ``"pm10"``, ``"o3"``. ERA5 meteorology: ``"t2m"``,
            ``"u10"``, ``"v10"``, ``"blh"``, ``"tp"``, ``"wind_speed"``,
            ``"wind_dir"``. Multi-variable responses are columnar.
        aggregate:
            Temporal aggregation level (default: ``"daily"``).
        threshold:
            µg/m³ threshold for exceedance queries.
        percentile:
            Percentile (0–100) for percentile queries.
        area:
            Named region (e.g. ``"paris"``, ``"belgium"``, ``"france"``).
            When provided, ``lat``/``lon`` are not required.
        facility:
            E-PRTR facility ID (``inspire_hash`` integer or string).
            When provided, the query is snapped to the facility's location
            and ``lat``/``lon`` are not required. Use ``facilities()`` to
            look up IDs. Combine with ``aggregate="trend"`` and
            ``return_divergence=True`` to get the satellite-vs-self-reported
            divergence signal.
        sort_by:
            Column name to sort CSV output by.
        sort_dir:
            Sort direction: ``"asc"`` or ``"desc"``.
        unit:
            Output unit override, e.g. ``"ppb"``.
        round:
            Number of decimal places to round values to.
        dry_run:
            If ``True``, return a cost estimate without executing the query.
        missing_null:
            If ``True``, emit empty string for missing cells instead of NaN.
        include_polygon:
            If ``True``, include ``area_polygon`` GeoJSON in the raw response.
        return_divergence:
            If ``True``, return a ``(DataFrame, divergence_dict)`` tuple
            instead of just the DataFrame. The ``divergence_dict`` is
            populated only when ``facility`` + ``aggregate="trend"`` are
            used with a CAMS pollutant variable.

        Returns
        -------
        pandas.DataFrame or (pandas.DataFrame, dict | None)
            Parsed CSV result (columns vary by aggregate mode).
            When ``return_divergence=True``, returns a 2-tuple
            ``(df, divergence)`` where ``divergence`` is a dict with keys
            ``cams_slope``, ``cams_r2``, ``eprtr_slope``, ``eprtr_pollutant``,
            ``eprtr_r2``, ``direction``, ``score`` — or ``None`` if not available.

        Raises
        ------
        ValueError
            If none of ``lat``/``lon``, ``area``, or ``facility`` is provided.
        AuthError
            Invalid API key.
        InsufficientCreditsError
            Not enough credits.
        RateLimitError
            Server overloaded; back off and retry.
        JisktaError
            Any other API error.

        Examples
        --------
        >>> # Point query with divergence signal
        >>> fac = client.facilities(q="neste porvoo")[0]
        >>> df, div = client.query(
        ...     facility=fac["inspire_hash"],
        ...     start="2015-01", end="2023-12",
        ...     variables=["no2"], aggregate="trend",
        ...     return_divergence=True,
        ... )
        >>> print(div["direction"])   # "consistent" / "overstated" / "understated"
        >>> print(div["score"])       # 0.0 – 1.0 confidence
        """
        import pandas as pd  # lazy import — not required at install time

        # wind_speed / wind_dir are derived from u10 + v10 — expand before the API call
        orig_variables = list(variables)
        variables, _wind_requested = _expand_wind_vars(orig_variables)

        params: dict[str, str | float | int] = {
            "time_start": start,
            "time_end": end,
            "variables": ",".join(variables),
            "format": "csv",
            "aggregate": aggregate,
        }

        if area is not None:
            params["area"] = area
        elif facility is not None:
            params["facility_id"] = str(facility)
        elif lat is not None and lon is not None:
            if isinstance(lat, (int, float)) and isinstance(lon, (int, float)):
                params["lat"] = float(lat)
                params["lon"] = float(lon)
            else:
                params["lat_min"] = lat[0]
                params["lat_max"] = lat[1]
                params["lon_min"] = lon[0]
                params["lon_max"] = lon[1]
        else:
            raise ValueError("Either lat/lon, area, or facility must be provided.")

        if threshold is not None:
            params["threshold"] = threshold
            params["aggregate"] = "exceedance"
        if percentile is not None:
            params["percentile"] = percentile
            params["aggregate"] = "percentile"
        if sort_by is not None:
            params["sort_by"] = sort_by
        if sort_dir is not None:
            params["sort_dir"] = sort_dir
        if unit is not None:
            params["unit"] = unit
        if round is not None:
            params["round"] = round
        if dry_run:
            params["dry_run"] = "true"
        if missing_null:
            params["missing"] = "null"
        if no_header:
            params["no_header"] = "true"
        if include_polygon:
            params["include_polygon"] = "true"

        data = self._get("/api/v1/climate/query", params)
        csv_text = data.get("output", "")
        df = pd.read_csv(io.StringIO(csv_text)) if csv_text.strip() else pd.DataFrame()
        if _wind_requested:
            df = _compute_wind_derived(df, orig_variables, variables)
        if return_divergence:
            return df, data.get("divergence")
        return df

    def stats(
        self,
        *,
        lat: tuple[float, float] | None = None,
        lon: tuple[float, float] | None = None,
        start: str,
        end: str,
        variables: Sequence[Variable] = ("no2",),
        area: str | None = None,
    ) -> dict:
        """
        Return summary statistics (min/max/mean/count) without a DataFrame.
        Uses ``format=stats`` — cheapest output format.

        Parameters
        ----------
        lat:
            ``(lat_min, lat_max)`` bounding box. Optional when ``area`` is provided.
        lon:
            ``(lon_min, lon_max)`` bounding box. Optional when ``area`` is provided.
        start:
            Start date — accepts ``"YYYY-MM-DD"`` or ``"YYYY-MM"``.
        end:
            End date — accepts ``"YYYY-MM-DD"`` or ``"YYYY-MM"``.
        variables:
            One or more variable names.
        area:
            Named region (e.g. ``"paris"``). When provided, ``lat``/``lon`` are not required.

        Raises
        ------
        ValueError
            If neither ``lat``/``lon`` nor ``area`` is provided.
        """
        params: dict[str, str | float | int] = {
            "time_start": start,
            "time_end": end,
            "variables": ",".join(variables),
            "format": "stats",
        }

        if area is not None:
            params["area"] = area
        elif lat is not None and lon is not None:
            params["lat_min"] = lat[0]
            params["lat_max"] = lat[1]
            params["lon_min"] = lon[0]
            params["lon_max"] = lon[1]
        else:
            raise ValueError("Either lat/lon or area must be provided.")

        return self._get("/api/v1/climate/query", params)

    def credits(self) -> dict:
        """
        Return current credit balance and key metadata.

        Returns a dict with at minimum ``credits_remaining`` and ``credits_used``.
        Implemented via a minimal stats query (costs 0 credits on cache hit).
        For real-time balance, prefer reading ``meta`` from ``query()``.
        """
        return self._get("/api/v1/climate/query", {
            "lat_min": "48.8", "lat_max": "48.9",
            "lon_min": "2.3",  "lon_max": "2.4",
            "time_start": "2023-01", "time_end": "2023-01",
            "variables": "no2", "format": "stats",
        })

    def query_with_mask(
        self,
        *,
        lat_min: float,
        lat_max: float,
        lon_min: float,
        lon_max: float,
        start: str,
        end: str,
        variables: Sequence[Variable] = ("no2",),
        aggregate: Aggregate = "daily",
        mask: dict,
        **kwargs,
    ) -> "pd.DataFrame":
        """
        Query climate data within a GeoJSON polygon mask via HTTP POST.

        Parameters
        ----------
        lat_min, lat_max, lon_min, lon_max:
            Bounding box for the query.
        start:
            Start date — accepts ``"YYYY-MM-DD"`` or ``"YYYY-MM"``.
        end:
            End date — accepts ``"YYYY-MM-DD"`` or ``"YYYY-MM"``.
        variables:
            One or more variable names.
        aggregate:
            Temporal aggregation level (default: ``"daily"``).
        mask:
            GeoJSON ``Polygon`` or ``MultiPolygon`` geometry dict. Only grid
            cells whose centres fall inside the polygon are returned.
        **kwargs:
            Additional parameters forwarded to the API (e.g. ``threshold``,
            ``percentile``, ``sort_by``, ``unit``, ``round``).

        Returns
        -------
        pandas.DataFrame
            Parsed result. Columns vary by aggregate mode.
        """
        import pandas as pd  # lazy import

        orig_variables = list(variables)
        variables, _wind_requested = _expand_wind_vars(orig_variables)

        body: dict = {
            "lat_min": lat_min,
            "lat_max": lat_max,
            "lon_min": lon_min,
            "lon_max": lon_max,
            "time_start": start,
            "time_end": end,
            "variables": ",".join(variables),
            "format": "csv",
            "aggregate": aggregate,
            "mask": mask,
            **kwargs,
        }

        data = self._post("/api/v1/climate/query", body)
        csv_text = data.get("output", "")
        if not csv_text.strip():
            return pd.DataFrame()
        df = pd.read_csv(io.StringIO(csv_text))
        if _wind_requested:
            df = _compute_wind_derived(df, orig_variables, list(variables))
        return df

    def enrich(self, lat: float, lon: float, *, year: int | None = None) -> dict:
        """
        Look up the NUTS3 administrative region for a geographic point.
        Also returns WRI Aqueduct 4.0 water risk scores and nearest E-PRTR
        industrial facility (within 5 km) when configured on the server.

        Parameters
        ----------
        lat:
            Latitude (decimal degrees, WGS-84).
        lon:
            Longitude (decimal degrees, WGS-84).
        year:
            Optional reference year for NUTS boundary edition (future use).

        Returns
        -------
        dict
            Keys: ``nuts3_id``, ``nuts3_name``, ``country``, ``lat``, ``lon``.
            Optional: ``water_stress`` (BWS/BWD/RFR/DRR scores + labels),
            ``nearest_facility`` (E-PRTR facility within 5 km).

        Raises
        ------
        JisktaError
            If the point is outside EU NUTS3 coverage (status 404) or another error occurs.

        Examples
        --------
        >>> result = client.enrich(lat=48.85, lon=2.35)
        >>> result["nuts3_id"]
        'FR101'
        >>> result.get("water_stress", {}).get("bws_label")
        'Low-Medium'
        """
        params: dict[str, str | int] = {"lat": lat, "lon": lon}
        if year is not None:
            params["year"] = year
        return self._get("/api/v1/enrich", params)

    def link(
        self,
        *,
        lat_min: float | None = None,
        lat_max: float | None = None,
        lon_min: float | None = None,
        lon_max: float | None = None,
        area: str | None = None,
        start: str,
        end: str,
        datasets: list,
        resolution: str = "nuts3",
        compute: list | None = None,
        per_year: bool = False,
        output_format: str | None = None,
        as_dataframe: bool = True,
    ):
        """
        Aggregate raster climate data to administrative regions (NUTS3 / country).

        This performs a spatial join: for each region inside the bounding box,
        it computes the mean of each raster variable across the grid cells that fall
        within that region. Optionally, cross-dataset operations (correlations,
        regressions, top-N rankings) are computed across all regions.

        Parameters
        ----------
        lat_min, lat_max, lon_min, lon_max:
            Bounding box. Optional when ``area`` is provided.
        area:
            Named area shortcut (e.g. ``"paris"``, ``"france"``, ``"india"``).
            Also accepts OSM relation IDs: ``"osm:71525"``.
            Replaces ``lat_min`` / ``lat_max`` / ``lon_min`` / ``lon_max``.
        start:
            Start date — ``"YYYY-MM-DD"`` or ``"YYYY-MM"``.
        end:
            End date — ``"YYYY-MM-DD"`` or ``"YYYY-MM"``.
        datasets:
            List of dicts with ``name`` (your alias) and ``source`` keys.
            Sources: ``cams_no2``, ``cams_pm2p5``, ``cams_pm10``, ``cams_o3``,
            ``era5_t2m``, ``era5_blh``, ``era5_tp``, ``era5_u10``, ``era5_v10``,
            ``viirs_radiance``,
            ``wb_gdp_usd``, ``wb_gdp_per_capita``, ``wb_gdp_growth``,
            ``wb_inflation_cpi``, ``wb_co2_per_capita``, ``wb_population``,
            ``wb_exports_pct``, ``wb_urban_pct``.
        resolution:
            Spatial aggregation level: ``"nuts3"`` (default), ``"country"``, or ``"cell"``.
        compute:
            Optional list of cross-dataset operations. Each dict has:
            - ``op``: ``"mean"``, ``"sum"``, ``"min"``, ``"max"``, ``"count"``,
              ``"pearson_r"``, ``"top_n"``
            - ``input`` (or ``value``): dataset name for scalar ops
            - ``x``, ``y``: dataset names for ``pearson_r``
            - ``output``: key name in response
            - ``include_n``: bool, include sample size for pearson_r
            - ``n``, ``direction``: for top_n
        per_year:
            If True, run one query per calendar year in [start, end] and return a
            year-indexed result. Defaults to CSV output when True.
        output_format:
            ``"json"`` (default), ``"csv"``, or ``"geojson"``.
        as_dataframe:
            If True (default), return the ``units`` list as a ``pandas.DataFrame``.
            If False, return the raw JSON dict.
            Ignored when ``output_format="csv"`` (returns raw CSV string) or
            ``output_format="geojson"`` (returns GeoJSON dict).

        Returns
        -------
        pandas.DataFrame or dict or str
            - ``as_dataframe=True`` (default): DataFrame with one row per region.
            - ``as_dataframe=False``: raw API response dict.
            - ``output_format="csv"``: CSV string (one row per region per year).
            - ``output_format="geojson"``: GeoJSON FeatureCollection dict.

        Raises
        ------
        ValueError
            If neither bbox nor ``area`` is provided.

        Examples
        --------
        >>> # France NO₂ trend by NUTS3, 2018–2022
        >>> df = client.link(
        ...     area="france",
        ...     start="2018-01-01", end="2022-12-31",
        ...     datasets=[{"name": "no2", "source": "cams_no2"}],
        ...     compute=[{"op": "mean", "input": "no2", "output": "no2_mean"}],
        ... )
        >>> df.sort_values("no2_mean", ascending=False).head(5)

        >>> # Multi-year CSV (one row per region per year)
        >>> csv = client.link(
        ...     area="germany",
        ...     start="2015-01-01", end="2022-12-31",
        ...     datasets=[{"name": "no2", "source": "cams_no2"}],
        ...     per_year=True, output_format="csv", as_dataframe=False,
        ... )
        >>> print(csv[:200])
        """
        import pandas as pd  # lazy import

        if area is None and any(v is None for v in (lat_min, lat_max, lon_min, lon_max)):
            raise ValueError("Either area or all of lat_min/lat_max/lon_min/lon_max must be provided.")

        body: dict = {
            "time_range": {"start": start, "end": end},
            "resolution": resolution,
            "datasets": datasets,
        }
        if area is not None:
            body["area"] = area
        else:
            body["bbox"] = {"lat_min": lat_min, "lat_max": lat_max,
                            "lon_min": lon_min, "lon_max": lon_max}
        if compute:
            body["compute"] = compute
        if per_year:
            body["per_year"] = True
        if output_format:
            body["output_format"] = output_format

        data = self._post("/api/v1/link", body)

        # CSV response is a plain string
        if isinstance(data, str):
            return data

        # GeoJSON or explicit non-dataframe
        if not as_dataframe or output_format == "geojson":
            return data

        units = data.get("units", [])
        if not units:
            return pd.DataFrame()
        return pd.DataFrame(units)

    def areas(
        self,
        *,
        q: str | None = None,
        bbox: tuple[float, float, float, float] | None = None,
        id: int | None = None,
        osm: int | None = None,
    ) -> dict:
        """
        Search named areas for use with the ``area=`` query parameter.

        Parameters
        ----------
        q:
            Name search (e.g. ``"paris"``). Returns first match.
        bbox:
            ``(lat_min, lat_max, lon_min, lon_max)`` — returns up to 50
            overlapping areas.
        id:
            Direct area ID lookup.
        osm:
            OSM relation ID lookup (e.g. ``54094`` for Paris).

        Returns
        -------
        dict
            Keys: ``status``, ``source``, ``count``, ``areas`` (list of area dicts).

        Examples
        --------
        >>> client.areas(q="paris")
        >>> client.areas(bbox=(48.7, 49.0, 2.2, 2.6))
        >>> client.areas(osm=54094)
        """
        params: dict = {}
        if q is not None:
            params["q"] = q
        elif bbox is not None:
            params["bbox"] = f"{bbox[0]},{bbox[1]},{bbox[2]},{bbox[3]}"
        elif id is not None:
            params["id"] = id
        elif osm is not None:
            params["osm"] = osm
        else:
            raise ValueError("One of q, bbox, id, or osm must be provided.")
        return self._get("/api/v1/areas", params)

    def coverage(self) -> dict:
        """
        Return live data coverage for all datasets.

        No authentication required. Returns availability per month/variable
        for CAMS, ERA5, VIIRS, and other sources.

        Returns
        -------
        dict
            Keys: ``status``, ``coverage`` (nested by variable and month).
        """
        return self._get("/api/v1/coverage", {})

    def redeem(self, code: str) -> dict:
        """
        Redeem a voucher code to add free credits to your account.

        Parameters
        ----------
        code:
            The voucher code (e.g. ``"WELCOME-2025"``).

        Returns
        -------
        dict
            Keys: ``credits_added``, ``credits_remaining``, ``description``.

        Raises
        ------
        JisktaError
            404 if code is invalid, 409 if already redeemed, 410 if expired.
        """
        return self._post("/api/v1/redeem", {"code": code})

    def facilities(
        self,
        *,
        lat: float | None = None,
        lon: float | None = None,
        radius_km: float | None = None,
        lat_min: float | None = None,
        lat_max: float | None = None,
        lon_min: float | None = None,
        lon_max: float | None = None,
        q: str | None = None,
        country: str | None = None,
        sector: str | None = None,
        id: "str | int | None" = None,
        emissions: bool = False,
        max: int | None = None,
        as_dataframe: bool = True,
    ) -> "pd.DataFrame | list":
        """
        Search E-PRTR industrial facilities.

        Returns facilities matching the given location, bounding box, name
        query, or direct ID lookup. At least one of ``lat``/``lon``/
        ``radius_km``, ``lat_min``/``lat_max``/``lon_min``/``lon_max``,
        ``q``, or ``id`` must be provided.

        Parameters
        ----------
        lat, lon:
            Centre point for radius search. Requires ``radius_km``.
        radius_km:
            Search radius in km around ``lat``/``lon``. Max 500.
        lat_min, lat_max, lon_min, lon_max:
            Bounding box search.
        q:
            Name substring search (e.g. ``"arcelormittal"``).
        country:
            ISO-2 country filter (e.g. ``"BE"``). Optional alongside ``q``.
        sector:
            PRTR sector substring filter (e.g. ``"metals"``).
        id:
            Direct facility lookup by ``inspire_hash`` (integer or string).
        emissions:
            If ``True``, include annual emission series
            (``nox_kg``, ``pm10_kg``, ``pm25_kg``, ``co2_kg``).
        as_dataframe:
            If ``True`` (default), return a ``pandas.DataFrame`` with one row
            per facility. If ``False``, return the raw list of dicts.

        Returns
        -------
        pandas.DataFrame or list of dict
            Facility records. Each record has at minimum:
            ``inspire_hash``, ``name``, ``country``, ``lat``, ``lon``,
            ``sector``. With ``emissions=True``, adds emission columns.

        Raises
        ------
        ValueError
            If no search criterion is provided.

        Examples
        --------
        >>> # Facilities within 10 km of Ghent
        >>> df = client.facilities(lat=51.05, lon=3.72, radius_km=10)
        >>> print(df[["name", "country", "sector"]])

        >>> # All ArcelorMittal facilities in Belgium with emissions
        >>> df = client.facilities(q="arcelormittal", country="BE", emissions=True)
        >>> print(df[["name", "nox_kg"]].head())

        >>> # Direct lookup by ID
        >>> fac = client.facilities(id=1986304935103026946)[0]
        >>> print(fac["name"])  # "ArcelorMittal Belgium"
        """
        import pandas as pd  # lazy import

        params: dict[str, str | float | int] = {}

        if id is not None:
            params["id"] = str(id)
        elif lat is not None and lon is not None:
            params["lat"] = lat
            params["lon"] = lon
            if radius_km is not None:
                params["radius_km"] = radius_km
        elif lat_min is not None:
            params["lat_min"] = lat_min
            params["lat_max"] = lat_max  # type: ignore[assignment]
            params["lon_min"] = lon_min  # type: ignore[assignment]
            params["lon_max"] = lon_max  # type: ignore[assignment]
        elif q is not None:
            params["q"] = q
        else:
            raise ValueError(
                "Provide one of: id, lat/lon[/radius_km], "
                "lat_min/lat_max/lon_min/lon_max, or q."
            )

        if country is not None:
            params["country"] = country
        if sector is not None:
            params["sector"] = sector
        if emissions:
            params["emissions"] = "true"
        if max is not None:
            params["max"] = max

        result = self._get("/api/v1/facilities", params)
        if isinstance(result, list):
            facilities_list: list = result
        elif isinstance(result, dict) and "inspire_hash" in result:
            # id= mode returns a single facility object (not wrapped in a list)
            facilities_list = [result]
        else:
            facilities_list = result.get("facilities", [])

        if not as_dataframe:
            return facilities_list
        if not facilities_list:
            return pd.DataFrame()
        return pd.DataFrame(facilities_list)

    # ── Utilities ─────────────────────────────────────────────────────────────

    def health(self) -> dict:
        """
        Check the API server health. No authentication required.

        Returns
        -------
        dict
            ``{"status": "healthy", "auth_enabled": true}``

        Examples
        --------
        >>> client.health()
        {'status': 'healthy', 'auth_enabled': True}
        """
        resp = self._session.get(self._base_url + "/health", timeout=10)
        resp.raise_for_status()
        return resp.json()

    def water_risk(
        self,
        *,
        lat_min: float,
        lat_max: float,
        lon_min: float,
        lon_max: float,
        format: str = "json",
        labels: bool = False,
        vars: str | None = None,
        as_dataframe: bool = True,
    ) -> "pd.DataFrame | dict":
        """
        Return WRI Aqueduct 4.0 water risk scores for every 0.1° cell in a
        bounding box.

        Covers CSRD ESRS E3-1 §27 (water stress/depletion) and E3-3 §38
        (flood/drought risk). Credits: 0 (static dataset).

        Parameters
        ----------
        lat_min, lat_max, lon_min, lon_max:
            Bounding box (max 50°×50°).
        format:
            ``"json"`` (default) or ``"csv"``.
        labels:
            When True, include human-readable label strings alongside scores.
        vars:
            Comma-separated indicator filter: ``"bws"``, ``"bwd"``,
            ``"rfr"``, ``"drr"`` (default: all four).
        as_dataframe:
            When True (default) and format is ``"json"``, return a
            ``pd.DataFrame`` of cells. Pass ``False`` for the raw dict.

        Returns
        -------
        pd.DataFrame | dict
            DataFrame with columns ``lat, lon, bws[, bwd, rfr, drr]`` or
            the raw JSON dict when ``as_dataframe=False``.

        Scores: 1=Low, 2=Low-Medium, 3=Medium-High, 4=High,
        5=Extremely High. ``None``/NaN = no catchment data.

        Examples
        --------
        >>> df = client.water_risk(lat_min=48, lat_max=52, lon_min=0, lon_max=5)
        >>> df[["lat", "lon", "bws"]].head()
        """
        params: dict[str, str | float | bool] = {
            "lat_min": lat_min,
            "lat_max": lat_max,
            "lon_min": lon_min,
            "lon_max": lon_max,
            "format": format,
        }
        if labels:
            params["labels"] = "true"
        if vars is not None:
            params["vars"] = vars

        result = self._get("/api/v1/water-risk", params)

        if not as_dataframe or format != "json":
            return result
        cells = result.get("cells", [])
        if not cells:
            return pd.DataFrame()
        return pd.DataFrame(cells)

    # ── Internal ──────────────────────────────────────────────────────────────

    def _post(self, path: str, body: dict) -> dict:
        url = self._base_url + path
        delay = 0.5
        last_exc: Exception | None = None

        for attempt in range(self._max_retries + 1):
            try:
                resp = self._session.post(url, json=body, timeout=self._timeout)
            except requests.RequestException as exc:
                last_exc = exc
                if attempt < self._max_retries:
                    time.sleep(delay)
                    delay *= 2
                    continue
                raise JisktaError(f"Network error: {exc}") from exc

            if resp.status_code == 429:
                if attempt < self._max_retries:
                    time.sleep(delay)
                    delay *= 2
                    continue
                raise RateLimitError("Server is busy; retry later.", status_code=429)

            if resp.status_code == 401:
                raise AuthError("Invalid API key.", status_code=401)

            if resp.status_code == 402:
                raise InsufficientCreditsError(
                    "Insufficient credits. Buy more at https://jiskta.com/pricing",
                    status_code=402,
                )

            try:
                data = resp.json()
            except ValueError as exc:
                raise JisktaError(f"Non-JSON response ({resp.status_code}): {resp.text[:200]}") from exc

            if resp.status_code != 200:
                msg = data.get("error") or data.get("message") or resp.text[:200]
                raise JisktaError(msg, status_code=resp.status_code)

            return data

        raise JisktaError("Max retries exceeded") from last_exc

    def _get(self, path: str, params: dict) -> dict:
        url = self._base_url + path
        delay = 0.5
        last_exc: Exception | None = None

        for attempt in range(self._max_retries + 1):
            try:
                resp = self._session.get(url, params=params, timeout=self._timeout)
            except requests.RequestException as exc:
                last_exc = exc
                if attempt < self._max_retries:
                    time.sleep(delay)
                    delay *= 2
                    continue
                raise JisktaError(f"Network error: {exc}") from exc

            if resp.status_code == 429:
                if attempt < self._max_retries:
                    time.sleep(delay)
                    delay *= 2
                    continue
                raise RateLimitError("Server is busy; retry later.", status_code=429)

            if resp.status_code == 401:
                raise AuthError("Invalid API key.", status_code=401)

            if resp.status_code == 402:
                raise InsufficientCreditsError(
                    "Insufficient credits. Buy more at https://jiskta.com/pricing",
                    status_code=402,
                )

            try:
                data = resp.json()
            except ValueError as exc:
                raise JisktaError(f"Non-JSON response ({resp.status_code}): {resp.text[:200]}") from exc

            if resp.status_code != 200:
                msg = data.get("error") or data.get("message") or resp.text[:200]
                raise JisktaError(msg, status_code=resp.status_code)

            return data

        raise JisktaError("Max retries exceeded") from last_exc
