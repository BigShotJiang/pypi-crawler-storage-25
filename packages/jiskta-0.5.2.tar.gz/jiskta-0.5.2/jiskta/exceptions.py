class JisktaError(Exception):
    """Base exception for all Jiskta API errors."""
    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class AuthError(JisktaError):
    """Invalid or missing API key."""


class InsufficientCreditsError(JisktaError):
    """Not enough credits to complete the query."""


class RateLimitError(JisktaError):
    """Server is overloaded; retry after backoff."""
