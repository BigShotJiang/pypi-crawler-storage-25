"""Tests for JisktaClient using mocked HTTP responses."""

import io
from urllib.parse import urlparse, parse_qs

import pytest
import responses as resp_lib

from jiskta import JisktaClient, AuthError, InsufficientCreditsError, RateLimitError, JisktaError

API = "https://api.jiskta.com"
KEY = "sk_live_test"

NO2_CSV = "lat,lon,date,no2_mean\n48.75,2.25,2023-01-01,12.3\n48.75,2.25,2023-01-02,11.1\n"
MULTI_CSV = "lat,lon,date,no2_mean,pm2p5_mean\n48.75,2.25,2023-01-01,12.3,8.1\n48.75,2.25,2023-01-02,11.1,7.4\n"
ERA5_CSV = "lat,lon,date,t2m_mean\n48.75,2.25,2023-01-01,278.5\n48.75,2.25,2023-01-02,279.1\n"
CROSS_CSV = "lat,lon,date,no2_mean,t2m_mean\n48.75,2.25,2023-01-01,12.3,278.5\n48.75,2.25,2023-01-02,11.1,279.1\n"


@pytest.fixture
def client():
    return JisktaClient(api_key=KEY)


# ── Basic query behaviour ─────────────────────────────────────────────────────

@resp_lib.activate
def test_query_returns_dataframe(client):
    resp_lib.add(
        resp_lib.GET, f"{API}/api/v1/climate/query",
        json={"status": "success", "output": NO2_CSV, "credits_used": 1, "credits_remaining": 999},
        status=200,
    )
    df = client.query(lat=(48.7, 49.0), lon=(2.2, 2.5), start="2023-01", end="2023-01")
    assert len(df) == 2
    assert "no2_mean" in df.columns
    assert df["no2_mean"].iloc[0] == pytest.approx(12.3)


@resp_lib.activate
def test_query_sends_variables_param_not_pollutants(client):
    """HTTP request must use variables= not pollutants=."""
    resp_lib.add(
        resp_lib.GET, f"{API}/api/v1/climate/query",
        json={"status": "success", "output": NO2_CSV, "credits_used": 1, "credits_remaining": 999},
        status=200,
    )
    client.query(lat=(48.7, 49.0), lon=(2.2, 2.5), start="2023-01", end="2023-01", variables=["no2"])
    req = resp_lib.calls[0].request
    qs = parse_qs(urlparse(req.url).query)
    assert "variables" in qs, "must send variables= param"
    assert qs["variables"] == ["no2"]
    assert "pollutants" not in qs, "must not send pollutants= param"


@resp_lib.activate
def test_query_default_variable_is_no2(client):
    resp_lib.add(
        resp_lib.GET, f"{API}/api/v1/climate/query",
        json={"status": "success", "output": NO2_CSV, "credits_used": 1, "credits_remaining": 999},
        status=200,
    )
    client.query(lat=(48.7, 49.0), lon=(2.2, 2.5), start="2023-01", end="2023-01")
    qs = parse_qs(urlparse(resp_lib.calls[0].request.url).query)
    assert qs["variables"] == ["no2"]


@resp_lib.activate
def test_empty_output_returns_empty_df(client):
    resp_lib.add(
        resp_lib.GET, f"{API}/api/v1/climate/query",
        json={"status": "success", "output": "", "credits_used": 1, "credits_remaining": 998},
        status=200,
    )
    df = client.query(lat=(48.7, 49.0), lon=(2.2, 2.5), start="2023-01", end="2023-01")
    assert df.empty


# ── Multi-variable (columnar) output ─────────────────────────────────────────

@resp_lib.activate
def test_multi_cams_columnar_output(client):
    """Two CAMS variables return a columnar DataFrame with two value columns."""
    resp_lib.add(
        resp_lib.GET, f"{API}/api/v1/climate/query",
        json={"status": "success", "output": MULTI_CSV, "credits_used": 2, "credits_remaining": 997},
        status=200,
    )
    df = client.query(
        lat=(48.7, 49.0), lon=(2.2, 2.5), start="2023-01", end="2023-01",
        variables=["no2", "pm2p5"],
    )
    assert len(df) == 2
    assert "no2_mean" in df.columns
    assert "pm2p5_mean" in df.columns
    req_qs = parse_qs(urlparse(resp_lib.calls[0].request.url).query)
    assert req_qs["variables"] == ["no2,pm2p5"]


@resp_lib.activate
def test_era5_variable_query(client):
    """ERA5 variable (t2m) returns a DataFrame with t2m_mean column."""
    resp_lib.add(
        resp_lib.GET, f"{API}/api/v1/climate/query",
        json={"status": "success", "output": ERA5_CSV, "credits_used": 1, "credits_remaining": 996},
        status=200,
    )
    df = client.query(
        lat=(48.7, 49.0), lon=(2.2, 2.5), start="2023-01", end="2023-01",
        variables=["t2m"],
    )
    assert "t2m_mean" in df.columns
    assert df["t2m_mean"].iloc[0] == pytest.approx(278.5)
    qs = parse_qs(urlparse(resp_lib.calls[0].request.url).query)
    assert qs["variables"] == ["t2m"]


@resp_lib.activate
def test_cross_dataset_join(client):
    """Mixed CAMS + ERA5 variables return columnar output."""
    resp_lib.add(
        resp_lib.GET, f"{API}/api/v1/climate/query",
        json={"status": "success", "output": CROSS_CSV, "credits_used": 2, "credits_remaining": 995},
        status=200,
    )
    df = client.query(
        lat=(48.7, 49.0), lon=(2.2, 2.5), start="2023-01", end="2023-01",
        variables=["no2", "t2m"],
    )
    assert "no2_mean" in df.columns
    assert "t2m_mean" in df.columns
    assert len(df) == 2


@resp_lib.activate
def test_multi_era5_variables(client):
    """Multiple ERA5 variables are sent comma-separated."""
    resp_lib.add(
        resp_lib.GET, f"{API}/api/v1/climate/query",
        json={"status": "success", "output": "lat,lon,date,u10_mean,v10_mean\n48.75,2.25,2023-01-01,2.1,-0.5\n", "credits_used": 2, "credits_remaining": 993},
        status=200,
    )
    df = client.query(
        lat=(48.7, 49.0), lon=(2.2, 2.5), start="2023-01", end="2023-01",
        variables=["u10", "v10"],
    )
    assert "u10_mean" in df.columns
    assert "v10_mean" in df.columns
    qs = parse_qs(urlparse(resp_lib.calls[0].request.url).query)
    assert qs["variables"] == ["u10,v10"]


# ── stats() ──────────────────────────────────────────────────────────────────

@resp_lib.activate
def test_stats_returns_dict(client):
    resp_lib.add(
        resp_lib.GET, f"{API}/api/v1/climate/query",
        json={"status": "success", "output": "Rows matched: 744\nMin: 5.2\nMax: 38.1\nAverage: 14.3"},
        status=200,
    )
    result = client.stats(lat=(48.7, 49.0), lon=(2.2, 2.5), start="2023-01", end="2023-01")
    assert result["status"] == "success"


@resp_lib.activate
def test_stats_sends_variables_param(client):
    resp_lib.add(
        resp_lib.GET, f"{API}/api/v1/climate/query",
        json={"status": "success", "output": "Rows matched: 100"},
        status=200,
    )
    client.stats(lat=(48.7, 49.0), lon=(2.2, 2.5), start="2023-01", end="2023-01", variables=["pm2p5"])
    qs = parse_qs(urlparse(resp_lib.calls[0].request.url).query)
    assert qs["variables"] == ["pm2p5"]
    assert "pollutants" not in qs


@resp_lib.activate
def test_stats_sends_format_stats(client):
    resp_lib.add(
        resp_lib.GET, f"{API}/api/v1/climate/query",
        json={"status": "success", "output": "Rows matched: 100"},
        status=200,
    )
    client.stats(lat=(48.7, 49.0), lon=(2.2, 2.5), start="2023-01", end="2023-01")
    qs = parse_qs(urlparse(resp_lib.calls[0].request.url).query)
    assert qs.get("format") == ["stats"]


# ── Threshold / percentile query modes ───────────────────────────────────────

@resp_lib.activate
def test_threshold_query_sets_exceedance_aggregate(client):
    resp_lib.add(
        resp_lib.GET, f"{API}/api/v1/climate/query",
        json={"status": "success", "output": "lat,lon,hours_above,total_hours,pct_above\n48.75,2.25,12,744,1.6\n", "credits_used": 1, "credits_remaining": 992},
        status=200,
    )
    df = client.query(
        lat=(48.7, 49.0), lon=(2.2, 2.5), start="2023-01", end="2023-01",
        variables=["no2"], threshold=40.0,
    )
    assert "hours_above" in df.columns
    qs = parse_qs(urlparse(resp_lib.calls[0].request.url).query)
    assert qs["aggregate"] == ["exceedance"]
    assert qs["threshold"] == ["40.0"]


@resp_lib.activate
def test_percentile_query_sets_aggregate(client):
    resp_lib.add(
        resp_lib.GET, f"{API}/api/v1/climate/query",
        json={"status": "success", "output": "lat,lon,p95\n48.75,2.25,28.4\n", "credits_used": 1, "credits_remaining": 991},
        status=200,
    )
    df = client.query(
        lat=(48.7, 49.0), lon=(2.2, 2.5), start="2023-01", end="2023-12",
        variables=["no2"], percentile=95,
    )
    qs = parse_qs(urlparse(resp_lib.calls[0].request.url).query)
    assert qs["aggregate"] == ["percentile"]
    assert qs["percentile"] == ["95"]


# ── Error handling ────────────────────────────────────────────────────────────

@resp_lib.activate
def test_auth_error(client):
    resp_lib.add(resp_lib.GET, f"{API}/api/v1/climate/query", json={"error": "invalid key"}, status=401)
    with pytest.raises(AuthError):
        client.query(lat=(48.7, 49.0), lon=(2.2, 2.5), start="2023-01", end="2023-01")


@resp_lib.activate
def test_insufficient_credits(client):
    resp_lib.add(resp_lib.GET, f"{API}/api/v1/climate/query", json={"error": "no credits"}, status=402)
    with pytest.raises(InsufficientCreditsError):
        client.query(lat=(48.7, 49.0), lon=(2.2, 2.5), start="2023-01", end="2023-01")


@resp_lib.activate
def test_rate_limit_exhausted():
    resp_lib.add(resp_lib.GET, f"{API}/api/v1/climate/query", json={}, status=429)
    c = JisktaClient(api_key=KEY, max_retries=0)
    with pytest.raises(RateLimitError):
        c.query(lat=(48.7, 49.0), lon=(2.2, 2.5), start="2023-01", end="2023-01")


@resp_lib.activate
def test_non_json_response_raises_jiskta_error(client):
    resp_lib.add(resp_lib.GET, f"{API}/api/v1/climate/query", body="Internal Server Error", status=500, content_type="text/plain")
    with pytest.raises(JisktaError):
        client.query(lat=(48.7, 49.0), lon=(2.2, 2.5), start="2023-01", end="2023-01")


def test_missing_api_key():
    with pytest.raises(ValueError):
        JisktaClient(api_key="")


@resp_lib.activate
def test_credits_returns_dict(client):
    resp_lib.add(
        resp_lib.GET, f"{API}/api/v1/climate/query",
        json={"credits_remaining": 9500, "credits_used": 0, "status": "success", "output": ""},
        status=200,
    )
    result = client.credits()
    assert isinstance(result, dict)
    assert result["credits_remaining"] == 9500

