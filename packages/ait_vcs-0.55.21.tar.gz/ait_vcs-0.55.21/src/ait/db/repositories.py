from __future__ import annotations

import json
import sqlite3
import uuid
from dataclasses import dataclass, field

from ait.db.schema import SCHEMA_VERSION


@dataclass(frozen=True)
class NewIntent:
    id: str
    repo_id: str
    title: str
    created_at: str
    created_by_actor_type: str
    created_by_actor_id: str
    trigger_source: str
    description: str | None = None
    kind: str | None = None
    parent_intent_id: str | None = None
    root_intent_id: str | None = None
    trigger_prompt_ref: str | None = None
    status: str = "open"
    tags: tuple[str, ...] = ()
    metadata: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class IntentRecord:
    id: str
    schema_version: int
    repo_id: str
    title: str
    description: str | None
    kind: str | None
    parent_intent_id: str | None
    root_intent_id: str
    created_at: str
    created_by_actor_type: str
    created_by_actor_id: str
    trigger_source: str
    trigger_prompt_ref: str | None
    status: str
    tags: tuple[str, ...]
    metadata: dict[str, str]


@dataclass(frozen=True)
class NewAttempt:
    id: str
    intent_id: str
    agent_id: str
    workspace_ref: str
    base_ref_oid: str
    started_at: str
    ownership_token: str
    agent_model: str | None = None
    agent_harness: str | None = None
    agent_harness_version: str | None = None
    workspace_kind: str = "worktree"
    base_ref_name: str | None = None
    heartbeat_at: str | None = None
    reported_status: str = "created"
    verified_status: str = "pending"


@dataclass(frozen=True)
class AttemptRecord:
    id: str
    schema_version: int
    intent_id: str
    ordinal: int
    agent_id: str
    agent_model: str | None
    agent_harness: str | None
    agent_harness_version: str | None
    workspace_kind: str
    workspace_ref: str
    base_ref_oid: str
    base_ref_name: str | None
    started_at: str
    ended_at: str | None
    heartbeat_at: str | None
    reported_status: str
    verified_status: str
    ownership_token: str
    raw_trace_ref: str | None
    logs_ref: str | None
    result_promotion_ref: str | None
    result_exit_code: int | None


@dataclass(frozen=True)
class EvidenceSummaryRecord:
    id: str
    schema_version: int
    attempt_id: str
    observed_tool_calls: int
    observed_file_reads: int
    observed_file_writes: int
    observed_commands_run: int
    observed_duration_ms: int
    observed_tests_run: int
    observed_tests_passed: int
    observed_tests_failed: int
    observed_lint_passed: bool | None
    observed_build_passed: bool | None
    raw_prompt_ref: str | None
    raw_trace_ref: str | None
    logs_ref: str | None


@dataclass(frozen=True)
class AttemptCommitRecord:
    attempt_id: str
    commit_oid: str
    base_commit_oid: str
    insertions: int | None
    deletions: int | None
    touched_files: tuple[str, ...]


@dataclass(frozen=True)
class AttemptOutcomeRecord:
    attempt_id: str
    schema_version: int
    outcome_class: str
    confidence: str
    reasons: tuple[str, ...]
    classified_at: str


@dataclass(frozen=True)
class NewMemoryFact:
    id: str
    kind: str
    topic: str
    body: str
    summary: str
    status: str
    confidence: str
    valid_from: str
    created_at: str
    updated_at: str
    source_attempt_id: str | None = None
    source_trace_ref: str | None = None
    source_commit_oid: str | None = None
    source_file_path: str | None = None
    valid_to: str | None = None
    superseded_by: str | None = None


@dataclass(frozen=True)
class MemoryFactRecord:
    id: str
    schema_version: int
    kind: str
    topic: str
    body: str
    summary: str
    status: str
    confidence: str
    source_attempt_id: str | None
    source_trace_ref: str | None
    source_commit_oid: str | None
    source_file_path: str | None
    valid_from: str
    valid_to: str | None
    superseded_by: str | None
    created_at: str
    updated_at: str


@dataclass(frozen=True)
class MemoryFactEntityRecord:
    memory_fact_id: str
    entity: str
    entity_type: str
    weight: float


@dataclass(frozen=True)
class NewMemoryFactEdge:
    id: str
    source_fact_id: str
    target_fact_id: str
    edge_type: str
    confidence: str
    created_at: str


@dataclass(frozen=True)
class MemoryFactEdgeRecord:
    id: str
    source_fact_id: str
    target_fact_id: str
    edge_type: str
    confidence: str
    created_at: str


@dataclass(frozen=True)
class NewMemoryRetrievalEvent:
    id: str
    attempt_id: str
    query: str
    selected_fact_ids: tuple[str, ...]
    ranker_version: str
    budget_chars: int
    created_at: str


@dataclass(frozen=True)
class MemoryRetrievalEventRecord:
    id: str
    attempt_id: str
    query: str
    selected_fact_ids: tuple[str, ...]
    ranker_version: str
    budget_chars: int
    created_at: str


def insert_intent(conn: sqlite3.Connection, new_intent: NewIntent) -> IntentRecord:
    root_intent_id = new_intent.root_intent_id or new_intent.id
    with conn:
        conn.execute(
            """
            INSERT INTO intents(
                id, schema_version, repo_id, title, description, kind,
                parent_intent_id, root_intent_id, created_at,
                created_by_actor_type, created_by_actor_id,
                trigger_source, trigger_prompt_ref, status, tags_json, metadata_json
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                new_intent.id,
                SCHEMA_VERSION,
                new_intent.repo_id,
                new_intent.title,
                new_intent.description,
                new_intent.kind,
                new_intent.parent_intent_id,
                root_intent_id,
                new_intent.created_at,
                new_intent.created_by_actor_type,
                new_intent.created_by_actor_id,
                new_intent.trigger_source,
                new_intent.trigger_prompt_ref,
                new_intent.status,
                _json_dump(list(new_intent.tags)),
                _json_dump(new_intent.metadata),
            ),
        )

    return get_intent(conn, new_intent.id)


def get_intent(conn: sqlite3.Connection, intent_id: str) -> IntentRecord | None:
    row = conn.execute("SELECT * FROM intents WHERE id = ?", (intent_id,)).fetchone()
    if row is None:
        return None
    return _row_to_intent(row)


def list_intent_attempts(conn: sqlite3.Connection, intent_id: str) -> list[AttemptRecord]:
    rows = conn.execute(
        "SELECT * FROM attempts WHERE intent_id = ? ORDER BY ordinal ASC",
        (intent_id,),
    ).fetchall()
    return [_row_to_attempt(row) for row in rows]


def insert_attempt(conn: sqlite3.Connection, new_attempt: NewAttempt) -> AttemptRecord:
    with conn:
        intent_row = conn.execute(
            "SELECT id FROM intents WHERE id = ?", (new_attempt.intent_id,)
        ).fetchone()
        if intent_row is None:
            raise LookupError(f"intent not found: {new_attempt.intent_id}")

        ordinal = _next_attempt_ordinal(conn, new_attempt.intent_id)
        conn.execute(
            """
            INSERT INTO attempts(
                id, schema_version, intent_id, ordinal, agent_id, agent_model,
                agent_harness, agent_harness_version, workspace_kind, workspace_ref,
                base_ref_oid, base_ref_name, started_at, ended_at, heartbeat_at,
                reported_status, verified_status, ownership_token, raw_trace_ref,
                logs_ref, result_promotion_ref, result_exit_code
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?, ?, NULL, NULL, NULL, NULL)
            """,
            (
                new_attempt.id,
                SCHEMA_VERSION,
                new_attempt.intent_id,
                ordinal,
                new_attempt.agent_id,
                new_attempt.agent_model,
                new_attempt.agent_harness,
                new_attempt.agent_harness_version,
                new_attempt.workspace_kind,
                new_attempt.workspace_ref,
                new_attempt.base_ref_oid,
                new_attempt.base_ref_name,
                new_attempt.started_at,
                new_attempt.heartbeat_at,
                new_attempt.reported_status,
                new_attempt.verified_status,
                new_attempt.ownership_token,
            ),
        )
        conn.execute(
            """
            INSERT INTO evidence_summaries(
                id, schema_version, attempt_id,
                observed_tool_calls, observed_file_reads, observed_file_writes,
                observed_commands_run, observed_duration_ms, observed_tests_run,
                observed_tests_passed, observed_tests_failed
            )
            VALUES (?, ?, ?, 0, 0, 0, 0, 0, 0, 0, 0)
            """,
            (f"{new_attempt.id}:evidence:{uuid.uuid4().hex}", SCHEMA_VERSION, new_attempt.id),
        )

    return get_attempt(conn, new_attempt.id)


def get_attempt(conn: sqlite3.Connection, attempt_id: str) -> AttemptRecord | None:
    row = conn.execute("SELECT * FROM attempts WHERE id = ?", (attempt_id,)).fetchone()
    if row is None:
        return None
    return _row_to_attempt(row)


def get_attempt_by_workspace_ref(
    conn: sqlite3.Connection, workspace_ref: str
) -> AttemptRecord | None:
    row = conn.execute(
        "SELECT * FROM attempts WHERE workspace_ref = ?",
        (workspace_ref,),
    ).fetchone()
    if row is None:
        return None
    return _row_to_attempt(row)


def get_evidence_summary(
    conn: sqlite3.Connection, attempt_id: str
) -> EvidenceSummaryRecord | None:
    row = conn.execute(
        "SELECT * FROM evidence_summaries WHERE attempt_id = ?", (attempt_id,)
    ).fetchone()
    if row is None:
        return None
    return _row_to_evidence_summary(row)


def list_evidence_files(conn: sqlite3.Connection, attempt_id: str) -> dict[str, tuple[str, ...]]:
    rows = conn.execute(
        """
        SELECT kind, file_path
        FROM evidence_files
        WHERE attempt_id = ?
        ORDER BY kind, file_path
        """,
        (attempt_id,),
    ).fetchall()
    grouped: dict[str, list[str]] = {}
    for row in rows:
        grouped.setdefault(str(row["kind"]), []).append(str(row["file_path"]))
    return {kind: tuple(paths) for kind, paths in grouped.items()}


def list_attempt_commits(conn: sqlite3.Connection, attempt_id: str) -> list[AttemptCommitRecord]:
    rows = conn.execute(
        """
        SELECT *
        FROM attempt_commits
        WHERE attempt_id = ?
        ORDER BY rowid ASC
        """,
        (attempt_id,),
    ).fetchall()
    return [_row_to_attempt_commit(row) for row in rows]


def get_attempt_outcome(conn: sqlite3.Connection, attempt_id: str) -> AttemptOutcomeRecord | None:
    row = conn.execute(
        "SELECT * FROM attempt_outcomes WHERE attempt_id = ?",
        (attempt_id,),
    ).fetchone()
    if row is None:
        return None
    return _row_to_attempt_outcome(row)


def upsert_attempt_outcome(
    conn: sqlite3.Connection,
    *,
    attempt_id: str,
    outcome_class: str,
    confidence: str,
    reasons: tuple[str, ...],
    classified_at: str,
) -> None:
    with conn:
        conn.execute(
            """
            INSERT INTO attempt_outcomes(
                attempt_id, schema_version, outcome_class, confidence, reasons_json, classified_at
            )
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(attempt_id) DO UPDATE SET
                schema_version = excluded.schema_version,
                outcome_class = excluded.outcome_class,
                confidence = excluded.confidence,
                reasons_json = excluded.reasons_json,
                classified_at = excluded.classified_at
            """,
            (
                attempt_id,
                SCHEMA_VERSION,
                outcome_class,
                confidence,
                _json_dump(list(reasons)),
                classified_at,
            ),
        )


def upsert_memory_fact(conn: sqlite3.Connection, fact: NewMemoryFact) -> MemoryFactRecord:
    with conn:
        conn.execute(
            """
            INSERT INTO memory_facts(
                id, schema_version, kind, topic, body, summary, status,
                confidence, source_attempt_id, source_trace_ref,
                source_commit_oid, source_file_path, valid_from, valid_to,
                superseded_by, created_at, updated_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                schema_version = excluded.schema_version,
                kind = excluded.kind,
                topic = excluded.topic,
                body = excluded.body,
                summary = excluded.summary,
                status = excluded.status,
                confidence = excluded.confidence,
                source_attempt_id = excluded.source_attempt_id,
                source_trace_ref = excluded.source_trace_ref,
                source_commit_oid = excluded.source_commit_oid,
                source_file_path = excluded.source_file_path,
                valid_from = excluded.valid_from,
                valid_to = excluded.valid_to,
                superseded_by = excluded.superseded_by,
                updated_at = excluded.updated_at
            """,
            (
                fact.id,
                SCHEMA_VERSION,
                fact.kind,
                fact.topic,
                fact.body,
                fact.summary,
                fact.status,
                fact.confidence,
                fact.source_attempt_id,
                fact.source_trace_ref,
                fact.source_commit_oid,
                fact.source_file_path,
                fact.valid_from,
                fact.valid_to,
                fact.superseded_by,
                fact.created_at,
                fact.updated_at,
            ),
        )
    row = get_memory_fact(conn, fact.id)
    if row is None:
        raise LookupError(f"memory fact not found after upsert: {fact.id}")
    return row


def get_memory_fact(conn: sqlite3.Connection, fact_id: str) -> MemoryFactRecord | None:
    row = conn.execute(
        "SELECT * FROM memory_facts WHERE id = ?",
        (fact_id,),
    ).fetchone()
    if row is None:
        return None
    return _row_to_memory_fact(row)


def list_memory_facts(
    conn: sqlite3.Connection,
    *,
    status: str | None = None,
    kind: str | None = None,
    topic: str | None = None,
    source_attempt_id: str | None = None,
    include_superseded: bool = False,
    limit: int = 100,
) -> list[MemoryFactRecord]:
    clauses: list[str] = []
    params: list[object] = []
    if status is not None:
        clauses.append("status = ?")
        params.append(status)
    elif not include_superseded:
        clauses.append("status != 'superseded'")
    if kind is not None:
        clauses.append("kind = ?")
        params.append(kind)
    if topic is not None:
        clauses.append("topic = ?")
        params.append(topic)
    if source_attempt_id is not None:
        clauses.append("source_attempt_id = ?")
        params.append(source_attempt_id)
    where = "WHERE " + " AND ".join(clauses) if clauses else ""
    rows = conn.execute(
        f"""
        SELECT *
        FROM memory_facts
        {where}
        ORDER BY updated_at DESC, id ASC
        LIMIT ?
        """,
        (*params, limit),
    ).fetchall()
    return [_row_to_memory_fact(row) for row in rows]


def replace_memory_fact_entities(
    conn: sqlite3.Connection,
    *,
    memory_fact_id: str,
    entities: tuple[MemoryFactEntityRecord, ...],
) -> None:
    with conn:
        conn.execute(
            "DELETE FROM memory_fact_entities WHERE memory_fact_id = ?",
            (memory_fact_id,),
        )
        for entity in entities:
            conn.execute(
                """
                INSERT INTO memory_fact_entities(memory_fact_id, entity, entity_type, weight)
                VALUES (?, ?, ?, ?)
                """,
                (
                    memory_fact_id,
                    entity.entity,
                    entity.entity_type,
                    entity.weight,
                ),
            )


def list_memory_fact_entities(
    conn: sqlite3.Connection,
    memory_fact_id: str,
) -> list[MemoryFactEntityRecord]:
    rows = conn.execute(
        """
        SELECT *
        FROM memory_fact_entities
        WHERE memory_fact_id = ?
        ORDER BY entity_type, entity
        """,
        (memory_fact_id,),
    ).fetchall()
    return [_row_to_memory_fact_entity(row) for row in rows]


def insert_memory_fact_edge(
    conn: sqlite3.Connection,
    edge: NewMemoryFactEdge,
) -> MemoryFactEdgeRecord:
    with conn:
        conn.execute(
            """
            INSERT INTO memory_fact_edges(
                id, source_fact_id, target_fact_id, edge_type, confidence, created_at
            )
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                edge.id,
                edge.source_fact_id,
                edge.target_fact_id,
                edge.edge_type,
                edge.confidence,
                edge.created_at,
            ),
        )
    row = get_memory_fact_edge(conn, edge.id)
    if row is None:
        raise LookupError(f"memory fact edge not found after insert: {edge.id}")
    return row


def get_memory_fact_edge(conn: sqlite3.Connection, edge_id: str) -> MemoryFactEdgeRecord | None:
    row = conn.execute(
        "SELECT * FROM memory_fact_edges WHERE id = ?",
        (edge_id,),
    ).fetchone()
    if row is None:
        return None
    return _row_to_memory_fact_edge(row)


def list_memory_fact_edges(
    conn: sqlite3.Connection,
    *,
    source_fact_id: str | None = None,
    target_fact_id: str | None = None,
    edge_type: str | None = None,
) -> list[MemoryFactEdgeRecord]:
    clauses: list[str] = []
    params: list[object] = []
    if source_fact_id is not None:
        clauses.append("source_fact_id = ?")
        params.append(source_fact_id)
    if target_fact_id is not None:
        clauses.append("target_fact_id = ?")
        params.append(target_fact_id)
    if edge_type is not None:
        clauses.append("edge_type = ?")
        params.append(edge_type)
    where = "WHERE " + " AND ".join(clauses) if clauses else ""
    rows = conn.execute(
        f"""
        SELECT *
        FROM memory_fact_edges
        {where}
        ORDER BY created_at DESC, id ASC
        """,
        tuple(params),
    ).fetchall()
    return [_row_to_memory_fact_edge(row) for row in rows]


def insert_memory_retrieval_event(
    conn: sqlite3.Connection,
    event: NewMemoryRetrievalEvent,
) -> MemoryRetrievalEventRecord:
    with conn:
        conn.execute(
            """
            INSERT INTO memory_retrieval_events(
                id, attempt_id, query, selected_fact_ids_json,
                ranker_version, budget_chars, created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                event.id,
                event.attempt_id,
                event.query,
                _json_dump(list(event.selected_fact_ids)),
                event.ranker_version,
                event.budget_chars,
                event.created_at,
            ),
        )
    row = get_memory_retrieval_event(conn, event.id)
    if row is None:
        raise LookupError(f"memory retrieval event not found after insert: {event.id}")
    return row


def get_memory_retrieval_event(
    conn: sqlite3.Connection,
    event_id: str,
) -> MemoryRetrievalEventRecord | None:
    row = conn.execute(
        "SELECT * FROM memory_retrieval_events WHERE id = ?",
        (event_id,),
    ).fetchone()
    if row is None:
        return None
    return _row_to_memory_retrieval_event(row)


def list_memory_retrieval_events(
    conn: sqlite3.Connection,
    *,
    attempt_id: str | None = None,
    limit: int | None = None,
) -> list[MemoryRetrievalEventRecord]:
    clauses: list[str] = []
    params: list[object] = []
    if attempt_id is not None:
        clauses.append("attempt_id = ?")
        params.append(attempt_id)
    where = "WHERE " + " AND ".join(clauses) if clauses else ""
    limit_clause = ""
    if limit is not None:
        limit_clause = "LIMIT ?"
        params.append(limit)
    rows = conn.execute(
        f"""
        SELECT *
        FROM memory_retrieval_events
        {where}
        ORDER BY created_at DESC, id ASC
        {limit_clause}
        """,
        tuple(params),
    ).fetchall()
    return [_row_to_memory_retrieval_event(row) for row in rows]


def insert_attempt_commit(
    conn: sqlite3.Connection,
    *,
    attempt_id: str,
    commit_oid: str,
    base_commit_oid: str,
    touched_files: tuple[str, ...] = (),
    insertions: int | None = None,
    deletions: int | None = None,
) -> None:
    with conn:
        conn.execute(
            """
            INSERT INTO attempt_commits(
                attempt_id, commit_oid, base_commit_oid, insertions, deletions, touched_files_json
            )
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                attempt_id,
                commit_oid,
                base_commit_oid,
                insertions,
                deletions,
                _json_dump(list(touched_files)),
            ),
        )


def replace_attempt_commits(
    conn: sqlite3.Connection,
    *,
    attempt_id: str,
    commits: tuple[AttemptCommitRecord, ...],
) -> None:
    with conn:
        conn.execute("DELETE FROM attempt_commits WHERE attempt_id = ?", (attempt_id,))
        for commit in commits:
            conn.execute(
                """
                INSERT INTO attempt_commits(
                    attempt_id, commit_oid, base_commit_oid, insertions, deletions, touched_files_json
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    commit.attempt_id,
                    commit.commit_oid,
                    commit.base_commit_oid,
                    commit.insertions,
                    commit.deletions,
                    _json_dump(list(commit.touched_files)),
                ),
            )


def insert_evidence_file(
    conn: sqlite3.Connection, *, attempt_id: str, file_path: str, kind: str
) -> None:
    with conn:
        conn.execute(
            """
            INSERT OR IGNORE INTO evidence_files(attempt_id, file_path, kind)
            VALUES (?, ?, ?)
            """,
            (attempt_id, file_path, kind),
        )


def replace_evidence_files_kind(
    conn: sqlite3.Connection,
    *,
    attempt_id: str,
    kind: str,
    file_paths: tuple[str, ...],
) -> None:
    with conn:
        conn.execute(
            "DELETE FROM evidence_files WHERE attempt_id = ? AND kind = ?",
            (attempt_id, kind),
        )
        for file_path in file_paths:
            conn.execute(
                """
                INSERT INTO evidence_files(attempt_id, file_path, kind)
                VALUES (?, ?, ?)
                """,
                (attempt_id, file_path, kind),
            )


def update_attempt(
    conn: sqlite3.Connection,
    attempt_id: str,
    *,
    base_ref_oid: str | None = None,
    base_ref_name: str | None = None,
    reported_status: str | None = None,
    verified_status: str | None = None,
    ended_at: str | None = None,
    heartbeat_at: str | None = None,
    raw_trace_ref: str | None = None,
    logs_ref: str | None = None,
    result_promotion_ref: str | None = None,
    result_exit_code: int | None = None,
) -> None:
    updates: list[tuple[str, object]] = []
    if base_ref_oid is not None:
        updates.append(("base_ref_oid", base_ref_oid))
    if base_ref_name is not None:
        updates.append(("base_ref_name", base_ref_name))
    if reported_status is not None:
        updates.append(("reported_status", reported_status))
    if verified_status is not None:
        updates.append(("verified_status", verified_status))
    if ended_at is not None:
        updates.append(("ended_at", ended_at))
    if heartbeat_at is not None:
        updates.append(("heartbeat_at", heartbeat_at))
    if raw_trace_ref is not None:
        updates.append(("raw_trace_ref", raw_trace_ref))
    if logs_ref is not None:
        updates.append(("logs_ref", logs_ref))
    if result_promotion_ref is not None:
        updates.append(("result_promotion_ref", result_promotion_ref))
    if result_exit_code is not None:
        updates.append(("result_exit_code", result_exit_code))
    if not updates:
        return
    assignments = ", ".join(f"{column} = ?" for column, _ in updates)
    params = tuple(value for _, value in updates) + (attempt_id,)
    with conn:
        conn.execute(f"UPDATE attempts SET {assignments} WHERE id = ?", params)


def update_intent_status(conn: sqlite3.Connection, intent_id: str, status: str) -> None:
    with conn:
        conn.execute(
            "UPDATE intents SET status = ? WHERE id = ?",
            (status, intent_id),
        )


def insert_intent_edge(
    conn: sqlite3.Connection,
    *,
    parent_intent_id: str,
    child_intent_id: str,
    edge_type: str,
    created_at: str,
) -> None:
    with conn:
        conn.execute(
            """
            INSERT OR REPLACE INTO intent_edges(parent_intent_id, child_intent_id, edge_type, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (parent_intent_id, child_intent_id, edge_type, created_at),
        )


def _next_attempt_ordinal(conn: sqlite3.Connection, intent_id: str) -> int:
    row = conn.execute(
        "SELECT COALESCE(MAX(ordinal), 0) AS max_ordinal FROM attempts WHERE intent_id = ?",
        (intent_id,),
    ).fetchone()
    return int(row["max_ordinal"]) + 1


def _row_to_intent(row: sqlite3.Row) -> IntentRecord:
    return IntentRecord(
        id=str(row["id"]),
        schema_version=int(row["schema_version"]),
        repo_id=str(row["repo_id"]),
        title=str(row["title"]),
        description=_str_or_none(row["description"]),
        kind=_str_or_none(row["kind"]),
        parent_intent_id=_str_or_none(row["parent_intent_id"]),
        root_intent_id=str(row["root_intent_id"]),
        created_at=str(row["created_at"]),
        created_by_actor_type=str(row["created_by_actor_type"]),
        created_by_actor_id=str(row["created_by_actor_id"]),
        trigger_source=str(row["trigger_source"]),
        trigger_prompt_ref=_str_or_none(row["trigger_prompt_ref"]),
        status=str(row["status"]),
        tags=tuple(_json_load(row["tags_json"])),
        metadata=dict(_json_load(row["metadata_json"])),
    )


def _row_to_attempt(row: sqlite3.Row) -> AttemptRecord:
    return AttemptRecord(
        id=str(row["id"]),
        schema_version=int(row["schema_version"]),
        intent_id=str(row["intent_id"]),
        ordinal=int(row["ordinal"]),
        agent_id=str(row["agent_id"]),
        agent_model=_str_or_none(row["agent_model"]),
        agent_harness=_str_or_none(row["agent_harness"]),
        agent_harness_version=_str_or_none(row["agent_harness_version"]),
        workspace_kind=str(row["workspace_kind"]),
        workspace_ref=str(row["workspace_ref"]),
        base_ref_oid=str(row["base_ref_oid"]),
        base_ref_name=_str_or_none(row["base_ref_name"]),
        started_at=str(row["started_at"]),
        ended_at=_str_or_none(row["ended_at"]),
        heartbeat_at=_str_or_none(row["heartbeat_at"]),
        reported_status=str(row["reported_status"]),
        verified_status=str(row["verified_status"]),
        ownership_token=str(row["ownership_token"]),
        raw_trace_ref=_str_or_none(row["raw_trace_ref"]),
        logs_ref=_str_or_none(row["logs_ref"]),
        result_promotion_ref=_str_or_none(row["result_promotion_ref"]),
        result_exit_code=_int_or_none(row["result_exit_code"]),
    )


def _row_to_evidence_summary(row: sqlite3.Row) -> EvidenceSummaryRecord:
    return EvidenceSummaryRecord(
        id=str(row["id"]),
        schema_version=int(row["schema_version"]),
        attempt_id=str(row["attempt_id"]),
        observed_tool_calls=int(row["observed_tool_calls"]),
        observed_file_reads=int(row["observed_file_reads"]),
        observed_file_writes=int(row["observed_file_writes"]),
        observed_commands_run=int(row["observed_commands_run"]),
        observed_duration_ms=int(row["observed_duration_ms"]),
        observed_tests_run=int(row["observed_tests_run"]),
        observed_tests_passed=int(row["observed_tests_passed"]),
        observed_tests_failed=int(row["observed_tests_failed"]),
        observed_lint_passed=_bool_or_none(row["observed_lint_passed"]),
        observed_build_passed=_bool_or_none(row["observed_build_passed"]),
        raw_prompt_ref=_str_or_none(row["raw_prompt_ref"]),
        raw_trace_ref=_str_or_none(row["raw_trace_ref"]),
        logs_ref=_str_or_none(row["logs_ref"]),
    )


def _row_to_attempt_commit(row: sqlite3.Row) -> AttemptCommitRecord:
    return AttemptCommitRecord(
        attempt_id=str(row["attempt_id"]),
        commit_oid=str(row["commit_oid"]),
        base_commit_oid=str(row["base_commit_oid"]),
        insertions=_int_or_none(row["insertions"]),
        deletions=_int_or_none(row["deletions"]),
        touched_files=tuple(_json_load(row["touched_files_json"])),
    )


def _row_to_attempt_outcome(row: sqlite3.Row) -> AttemptOutcomeRecord:
    return AttemptOutcomeRecord(
        attempt_id=str(row["attempt_id"]),
        schema_version=int(row["schema_version"]),
        outcome_class=str(row["outcome_class"]),
        confidence=str(row["confidence"]),
        reasons=tuple(str(item) for item in _json_load(row["reasons_json"])),
        classified_at=str(row["classified_at"]),
    )


def _row_to_memory_fact(row: sqlite3.Row) -> MemoryFactRecord:
    return MemoryFactRecord(
        id=str(row["id"]),
        schema_version=int(row["schema_version"]),
        kind=str(row["kind"]),
        topic=str(row["topic"]),
        body=str(row["body"]),
        summary=str(row["summary"]),
        status=str(row["status"]),
        confidence=str(row["confidence"]),
        source_attempt_id=_str_or_none(row["source_attempt_id"]),
        source_trace_ref=_str_or_none(row["source_trace_ref"]),
        source_commit_oid=_str_or_none(row["source_commit_oid"]),
        source_file_path=_str_or_none(row["source_file_path"]),
        valid_from=str(row["valid_from"]),
        valid_to=_str_or_none(row["valid_to"]),
        superseded_by=_str_or_none(row["superseded_by"]),
        created_at=str(row["created_at"]),
        updated_at=str(row["updated_at"]),
    )


def _row_to_memory_fact_entity(row: sqlite3.Row) -> MemoryFactEntityRecord:
    return MemoryFactEntityRecord(
        memory_fact_id=str(row["memory_fact_id"]),
        entity=str(row["entity"]),
        entity_type=str(row["entity_type"]),
        weight=float(row["weight"]),
    )


def _row_to_memory_fact_edge(row: sqlite3.Row) -> MemoryFactEdgeRecord:
    return MemoryFactEdgeRecord(
        id=str(row["id"]),
        source_fact_id=str(row["source_fact_id"]),
        target_fact_id=str(row["target_fact_id"]),
        edge_type=str(row["edge_type"]),
        confidence=str(row["confidence"]),
        created_at=str(row["created_at"]),
    )


def _row_to_memory_retrieval_event(row: sqlite3.Row) -> MemoryRetrievalEventRecord:
    return MemoryRetrievalEventRecord(
        id=str(row["id"]),
        attempt_id=str(row["attempt_id"]),
        query=str(row["query"]),
        selected_fact_ids=tuple(str(item) for item in _json_load(row["selected_fact_ids_json"])),
        ranker_version=str(row["ranker_version"]),
        budget_chars=int(row["budget_chars"]),
        created_at=str(row["created_at"]),
    )


def _json_dump(value: object) -> str:
    return json.dumps(value, separators=(",", ":"), sort_keys=True)


def _json_load(value: object) -> object:
    return json.loads(str(value))


def _bool_or_none(value: object) -> bool | None:
    if value is None:
        return None
    return bool(int(value))


def _int_or_none(value: object) -> int | None:
    if value is None:
        return None
    return int(value)


def _str_or_none(value: object) -> str | None:
    if value is None:
        return None
    return str(value)
