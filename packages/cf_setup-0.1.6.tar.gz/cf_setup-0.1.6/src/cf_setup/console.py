from __future__ import annotations

from collections import deque
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
import io
from pathlib import Path
import subprocess
import sys
from typing import Iterator

from .reporting import current_event_stream, format_duration_seconds


@dataclass(frozen=True)
class CommandResult:
    args: list[str]
    returncode: int
    stdout: str
    stderr: str = ""


class ConsoleLogger:
    def __init__(self, *, show_details: bool, log_path: Path | None) -> None:
        self.show_details = bool(show_details)
        self.log_path = log_path.resolve() if log_path else None
        self._recent_lines: deque[str] = deque(maxlen=25)
        self._log_handle = None
        if self.log_path is not None:
            self.log_path.parent.mkdir(parents=True, exist_ok=True)
            self._log_handle = self.log_path.open("a", encoding="utf-8")
            self._write_log_raw(f"==== session started {datetime.now().astimezone().isoformat()} ====")

    def close(self) -> None:
        if self._log_handle is not None:
            self._write_log_raw(f"==== session ended {datetime.now().astimezone().isoformat()} ====")
            self._log_handle.close()
            self._log_handle = None

    @staticmethod
    def _safe_terminal_text(message: str, stream) -> str:
        encoding = getattr(stream, "encoding", None) or "utf-8"
        return str(message).encode(encoding, errors="replace").decode(encoding, errors="replace")

    def _write_log_raw(self, line: str) -> None:
        if self._log_handle is None:
            self._recent_lines.append(line)
            return
        self._recent_lines.append(line)
        self._log_handle.write(line.rstrip("\n") + "\n")
        self._log_handle.flush()

    def log(self, message: str) -> None:
        timestamp = datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S")
        for line in str(message).splitlines() or [""]:
            self._write_log_raw(f"{timestamp} | {line}")

    def _emit_terminal(self, prefix: str, message: str, *, stream=None) -> None:
        target = stream or sys.stdout
        print(self._safe_terminal_text(f"{prefix} {message}", target), file=target, flush=True)

    def progress(self, message: str) -> None:
        self.log(f"PROGRESS {message}")
        self._emit_terminal("[..]", message)

    def success(self, message: str) -> None:
        self.log(f"SUCCESS {message}")
        self._emit_terminal("[ok]", message)

    def skipped(self, message: str) -> None:
        self.log(f"SKIPPED {message}")
        self._emit_terminal("[--]", message)

    def error(self, message: str) -> None:
        self.log(f"ERROR {message}")
        self._emit_terminal("[!!]", message, stream=sys.stderr)

    def record_step(self, step_report) -> None:
        duration = format_duration_seconds(getattr(step_report, "duration_seconds", None))
        suffix = f" ({duration})" if duration else ""
        detail = getattr(step_report, "detail", "")
        message = f"{getattr(step_report, 'step', 'step')}{suffix}"
        status = getattr(step_report, "status", "success")
        if status in {"success", "planned"}:
            self.success(message)
        elif status in {"skipped", "pending"}:
            self.skipped(message)
        elif status in {"running", "retry"}:
            self.progress(message)
        else:
            self.error(message)
        if detail:
            self.log(f"STEP-DETAIL {getattr(step_report, 'step', 'step')} {detail}")

    def emit_table(self, title: str, headers: list[str], rows: list[list[str]]) -> None:
        self._emit_terminal("[..]", title)
        if not rows:
            self._emit_terminal("    ", "(no rows)")
            return
        widths = [len(header) for header in headers]
        for row in rows:
            for index, value in enumerate(row):
                widths[index] = max(widths[index], len(value))
        header_line = " | ".join(header.ljust(widths[index]) for index, header in enumerate(headers))
        separator_line = "-+-".join("-" * widths[index] for index in range(len(headers)))
        self._emit_terminal("    ", header_line)
        self._emit_terminal("    ", separator_line)
        for row in rows:
            rendered = " | ".join(value.ljust(widths[index]) for index, value in enumerate(row))
            self._emit_terminal("    ", rendered)

    def print_recent_log_tail(self, *, header: str = "Recent log lines:") -> None:
        if not self._recent_lines:
            return
        self._emit_terminal("[..]", header, stream=sys.stderr)
        for line in self._recent_lines:
            self._emit_terminal("    ", line, stream=sys.stderr)

    def run_process(
        self,
        args: list[str],
        *,
        cwd: Path,
        env: dict[str, str],
    ) -> CommandResult:
        rendered = subprocess.list2cmdline([str(token) for token in args])
        self.log(f"COMMAND cwd={cwd}")
        self.log(f"COMMAND args={rendered}")
        current_event_stream().emit(
            "command_started",
            argv=[str(token) for token in args],
            cwd=str(cwd),
        )
        process = subprocess.Popen(
            args,
            cwd=str(cwd),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        stdout_chunks: list[str] = []
        assert process.stdout is not None
        for line in process.stdout:
            stdout_chunks.append(line)
            self.log(line.rstrip("\n"))
            if self.show_details:
                target = sys.stdout
                text = self._safe_terminal_text(line, target)
                print(text, end="", file=target, flush=True)
        process.wait()
        self.log(f"COMMAND returncode={process.returncode}")
        current_event_stream().emit(
            "command_finished",
            argv=[str(token) for token in args],
            cwd=str(cwd),
            returncode=int(process.returncode or 0),
        )
        return CommandResult(args=list(args), returncode=int(process.returncode or 0), stdout="".join(stdout_chunks))


class NullConsoleLogger(ConsoleLogger):
    def __init__(self) -> None:
        self.show_details = False
        self.log_path = None
        self._recent_lines = deque(maxlen=25)
        self._log_handle = None

    def close(self) -> None:
        return None

    def _write_log_raw(self, line: str) -> None:
        self._recent_lines.append(line)

    def _emit_terminal(self, prefix: str, message: str, *, stream=None) -> None:
        target = stream or sys.stdout
        print(f"{prefix} {message}", file=target, flush=True)


_NULL_CONSOLE = NullConsoleLogger()
_ACTIVE_CONSOLE: ConsoleLogger | None = None


def current_console() -> ConsoleLogger:
    return _ACTIVE_CONSOLE or _NULL_CONSOLE


@contextmanager
def activate_console(*, show_details: bool, log_path: Path | None) -> Iterator[ConsoleLogger]:
    global _ACTIVE_CONSOLE
    previous = _ACTIVE_CONSOLE
    console = ConsoleLogger(show_details=show_details, log_path=log_path)
    _ACTIVE_CONSOLE = console
    try:
        yield console
    finally:
        console.close()
        _ACTIVE_CONSOLE = previous


@contextmanager
def ensure_console(*, show_details: bool, log_path: Path | None) -> Iterator[ConsoleLogger]:
    if _ACTIVE_CONSOLE is not None:
        yield _ACTIVE_CONSOLE
        return
    with activate_console(show_details=show_details, log_path=log_path) as console:
        yield console
