from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import tomllib


def normalize_name(value: str) -> str:
    return value.strip().lower().replace("_", "-")


DEPENDENCY_KINDS = {"compile", "tooling", "runtime_service", "app_runtime"}


@dataclass(frozen=True)
class ModuleDependency:
    package_name: str
    kind: str


@dataclass(frozen=True)
class ModuleDefinition:
    package_name: str
    path: str | None
    aliases: tuple[str, ...]
    editable: bool
    native_prereqs: bool
    engine_build: bool
    web_build: bool
    dependencies: tuple[ModuleDependency, ...]

    @property
    def all_aliases(self) -> tuple[str, ...]:
        return (self.package_name, *self.aliases)

    @property
    def depends_on(self) -> tuple[str, ...]:
        return tuple(dependency.package_name for dependency in self.dependencies)

    @property
    def is_distribution_mode(self) -> bool:
        return self.path is None


@dataclass(frozen=True)
class HookDefinition:
    hook_id: str
    when: str
    action: str
    requires_modules: tuple[str, ...]


@dataclass(frozen=True)
class InstallManifest:
    path: Path
    modules: dict[str, ModuleDefinition]
    profiles: dict[str, tuple[str, ...]]
    hooks: tuple[HookDefinition, ...]

    def alias_lookup(self) -> dict[str, str]:
        lookup: dict[str, str] = {}
        for package_name, module in self.modules.items():
            for alias in module.all_aliases:
                lookup[normalize_name(alias)] = package_name
        return lookup

    def resolve_module_name(self, raw_name: str) -> str:
        lookup = self.alias_lookup()
        normalized = normalize_name(raw_name)
        if normalized not in lookup:
            supported = ", ".join(sorted(self.modules))
            raise ValueError(f"Unknown module '{raw_name}'. Supported modules: {supported}")
        return lookup[normalized]


def _load_module_definition(package_name: str, raw: dict) -> ModuleDefinition:
    aliases = tuple(str(item) for item in raw.get("aliases", []))
    dependency_kinds = {
        normalize_name(name): str(kind)
        for name, kind in (raw.get("dependency_kinds", {}) or {}).items()
    }
    raw_dependencies = [normalize_name(item) for item in raw.get("depends_on", [])]
    unknown_dependency_kind_keys = sorted(name for name in dependency_kinds if name not in raw_dependencies)
    if unknown_dependency_kind_keys:
        raise ValueError(
            f"Module '{package_name}' defines dependency_kinds for unknown dependencies: "
            f"{', '.join(unknown_dependency_kind_keys)}"
        )
    dependencies: list[ModuleDependency] = []
    for normalized_name in raw_dependencies:
        dependency_kind = dependency_kinds.get(normalized_name, "app_runtime")
        if dependency_kind not in DEPENDENCY_KINDS:
            supported = ", ".join(sorted(DEPENDENCY_KINDS))
            raise ValueError(
                f"Module '{package_name}' dependency '{normalized_name}' uses unsupported kind '{dependency_kind}'. "
                f"Supported kinds: {supported}"
            )
        dependencies.append(ModuleDependency(package_name=normalized_name, kind=dependency_kind))
    path_value = raw.get("path")
    return ModuleDefinition(
        package_name=package_name,
        path=str(path_value) if path_value is not None else None,
        aliases=aliases,
        editable=bool(raw.get("editable", True)),
        native_prereqs=bool(raw.get("native_prereqs", False)),
        engine_build=bool(raw.get("engine_build", False)),
        web_build=bool(raw.get("web_build", False)),
        dependencies=tuple(dependencies),
    )


def load_manifest(path: Path) -> InstallManifest:
    data = tomllib.loads(path.read_text(encoding="utf-8"))
    raw_modules = data.get("modules")
    raw_profiles = data.get("profiles")
    if not isinstance(raw_modules, dict) or not raw_modules:
        raise ValueError("Manifest must define at least one module.")
    if not isinstance(raw_profiles, dict) or not raw_profiles:
        raise ValueError("Manifest must define at least one profile.")

    modules: dict[str, ModuleDefinition] = {}
    for package_name, raw_definition in raw_modules.items():
        normalized_name = normalize_name(package_name)
        modules[normalized_name] = _load_module_definition(normalized_name, raw_definition)

    for package_name, module in modules.items():
        for dependency in module.depends_on:
            if dependency not in modules:
                raise ValueError(f"Module '{package_name}' depends on unknown module '{dependency}'.")

    profiles: dict[str, tuple[str, ...]] = {}
    for profile_name, entries in raw_profiles.items():
        normalized_profile = normalize_name(profile_name)
        if not isinstance(entries, list) or not entries:
            raise ValueError(f"Profile '{profile_name}' must contain at least one entry.")
        profiles[normalized_profile] = tuple(str(item) for item in entries)

    hooks: list[HookDefinition] = []
    for raw_hook in data.get("hooks", []):
        hook = HookDefinition(
            hook_id=str(raw_hook["id"]),
            when=str(raw_hook["when"]),
            action=str(raw_hook["action"]),
            requires_modules=tuple(normalize_name(item) for item in raw_hook.get("requires_modules", [])),
        )
        for required_module in hook.requires_modules:
            if required_module not in modules:
                raise ValueError(f"Hook '{hook.hook_id}' requires unknown module '{required_module}'.")
        hooks.append(hook)

    return InstallManifest(path=path, modules=modules, profiles=profiles, hooks=tuple(hooks))
