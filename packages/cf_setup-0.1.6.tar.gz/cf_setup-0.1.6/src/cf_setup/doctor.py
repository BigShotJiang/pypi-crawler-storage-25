from __future__ import annotations

import json
from dataclasses import dataclass
from importlib import metadata
from typing import Any

from cf_service_contracts import ProviderKey, get_provider, require_provider

from .cogniflow_paths import resolve_workspace_dir
from .provider_registry import (
    _distribution_or_none,
    _iter_service_provider_entry_points,
    _list_service_provider_entry_points,
    _load_ontology_consumer_semantics,
    _load_ontology_provider_semantics,
    build_provider_registry_payload,
    load_ontology_contract_semantics,
    provider_registry_path_for_workspace,
)


@dataclass(frozen=True)
class PythonProviderDiagnostic:
    provider_key: str
    entry_point_name: str
    entry_point_value: str | None
    status: str
    package_name: str | None
    package_version: str | None
    load_error: str | None


@dataclass(frozen=True)
class NativeProviderDiagnostic:
    provider_key: str
    package_name: str | None
    contract_symbol: str | None
    contract_version: int | None
    status: str
    library_path: str | None
    load_error: str | None


@dataclass(frozen=True)
class ContractDiagnostic:
    contract_name: str
    contract_version: str | None
    provider_key: str | None
    provider_package: str | None
    consumer_keys: list[str]
    status: str


def _module_to_package_name(module_name: str) -> str | None:
    top = module_name.split(".")[0]
    for candidate in (top.replace("_", "-"), top):
        dist = _distribution_or_none(candidate)
        if dist is not None:
            return dist.metadata.get("Name", candidate)
    return None


def _module_to_package_version(module_name: str) -> str | None:
    top = module_name.split(".")[0]
    for candidate in (top.replace("_", "-"), top):
        dist = _distribution_or_none(candidate)
        if dist is not None:
            return dist.version
    return None


def _safe_load_entry_point(entry_point_value: str) -> tuple[bool, str | None]:
    try:
        module_name, attr_name = entry_point_value.split(":", 1)
        module = __import__(module_name, fromlist=[attr_name])
        getattr(module, attr_name)
        return True, None
    except Exception as exc:
        return False, str(exc)


def run_provider_diagnostics() -> dict[str, Any]:
    python_providers: list[dict[str, Any]] = []
    native_providers: list[dict[str, Any]] = []
    missing_providers: list[str] = []
    duplicate_providers: list[str] = []
    load_errors: list[dict[str, str]] = []

    expected_python_keys: set[str] = set()
    for name in dir(ProviderKey):
        if not name.isupper():
            continue
        value = getattr(ProviderKey, name)
        if isinstance(value, str):
            expected_python_keys.add(value)

    entry_points = _iter_service_provider_entry_points()
    entry_points_list = _list_service_provider_entry_points()

    # Detect duplicate entry-point keys before dict collapse
    seen_keys: set[str] = set()
    for key, _value in entry_points_list:
        if key in seen_keys:
            if key not in duplicate_providers:
                duplicate_providers.append(key)
        seen_keys.add(key)

    # Python providers
    resolved_python_keys: set[str] = set()
    for key in sorted(expected_python_keys):
        ep_value = entry_points.get(key)
        if ep_value:
            resolved_python_keys.add(key)
            load_ok, load_err = _safe_load_entry_point(ep_value)
            module_name = ep_value.split(":", 1)[0]
            pkg_name = _module_to_package_name(module_name)
            pkg_version = _module_to_package_version(module_name)
            status = "resolved" if load_ok else "load_error"
            if not load_ok:
                load_errors.append(
                    {"provider_key": key, "error": load_err or "unknown"}
                )
            python_providers.append(
                {
                    "provider_key": key,
                    "entry_point_name": key,
                    "entry_point_value": ep_value,
                    "status": status,
                    "package_name": pkg_name,
                    "package_version": pkg_version,
                    "load_error": load_err,
                }
            )
        else:
            missing_providers.append(key)
            python_providers.append(
                {
                    "provider_key": key,
                    "entry_point_name": key,
                    "entry_point_value": None,
                    "status": "missing",
                    "package_name": None,
                    "package_version": None,
                    "load_error": None,
                }
            )

    # Native providers
    native_payload: dict[str, Any] | None = None
    native_payload_error: str | None = None
    try:
        native_payload = build_provider_registry_payload()
    except Exception as exc:
        native_payload_error = str(exc)

    ontology_providers = _load_ontology_provider_semantics()
    native_provider_keys = {
        p.provider_key
        for p in ontology_providers
        if p.provider_kind == "https://cogniflow.odea-project.org/cf#provider_kind_native_registry"
    }

    if native_payload is not None and "providers" in native_payload:
        for key in sorted(native_provider_keys):
            provider_data = native_payload["providers"].get(key)
            if provider_data:
                native_providers.append(
                    {
                        "provider_key": key,
                        "package_name": provider_data.get("package_name"),
                        "contract_symbol": provider_data.get("contract_symbol"),
                        "contract_version": provider_data.get("contract_version"),
                        "status": "resolved",
                        "library_path": provider_data.get("library_path"),
                        "load_error": None,
                    }
                )
            else:
                missing_providers.append(key)
                native_providers.append(
                    {
                        "provider_key": key,
                        "package_name": None,
                        "contract_symbol": None,
                        "contract_version": None,
                        "status": "missing",
                        "library_path": None,
                        "load_error": None,
                    }
                )
    else:
        for key in sorted(native_provider_keys):
            err_msg = native_payload_error or "registry build failed"
            native_providers.append(
                {
                    "provider_key": key,
                    "package_name": None,
                    "contract_symbol": None,
                    "contract_version": None,
                    "status": "registry_error",
                    "library_path": None,
                    "load_error": err_msg,
                }
            )
            load_errors.append({"provider_key": key, "error": err_msg})

    return {
        "schema_version": "cf_doctor_providers.v1",
        "python_providers": python_providers,
        "native_providers": native_providers,
        "missing_providers": missing_providers,
        "duplicate_providers": duplicate_providers,
        "load_errors": load_errors,
    }


def run_contract_diagnostics() -> dict[str, Any]:
    contracts = load_ontology_contract_semantics()
    consumers = _load_ontology_consumer_semantics()
    entry_points = _iter_service_provider_entry_points()

    # Build provider_key -> consumer_keys mapping
    consumer_keys_by_provider: dict[str, list[str]] = {}
    for consumer in consumers:
        for contract_key in consumer.contract_keys:
            consumer_keys_by_provider.setdefault(contract_key, []).append(
                consumer.consumer_key
            )

    # Determine which provider keys have native registry entries
    native_payload: dict[str, Any] | None = None
    try:
        native_payload = build_provider_registry_payload()
    except Exception:
        pass
    native_provider_keys: set[str] = set()
    if native_payload is not None and "providers" in native_payload:
        native_provider_keys = set(native_payload["providers"].keys())

    contract_diagnostics: list[dict[str, Any]] = []
    missing_contracts: list[str] = []

    for contract in contracts:
        provider_key = contract.provider_key
        provider_package: str | None = None
        has_python_entry_point = provider_key in entry_points
        has_native_provider = provider_key in native_provider_keys

        if provider_key:
            if has_python_entry_point:
                ep_value = entry_points[provider_key]
                module_name = ep_value.split(":", 1)[0]
                provider_package = _module_to_package_name(module_name)
            elif has_native_provider:
                provider_data = native_payload["providers"][provider_key]  # type: ignore[index]
                provider_package = provider_data.get("package_name")

        consumer_keys = sorted(
            set(consumer_keys_by_provider.get(provider_key or "", []))
        )

        if not provider_key:
            status = "missing_provider"
        elif has_python_entry_point or has_native_provider:
            status = "active"
        else:
            status = "missing_provider_entry_point"
            missing_contracts.append(contract.contract_name)

        contract_diagnostics.append(
            {
                "contract_name": contract.contract_name,
                "contract_version": contract.contract_version,
                "provider_key": provider_key,
                "provider_package": provider_package,
                "consumer_keys": consumer_keys,
                "status": status,
            }
        )

    return {
        "schema_version": "cf_doctor_contracts.v1",
        "contracts": contract_diagnostics,
        "missing_contracts": missing_contracts,
    }


def run_step_diagnostics() -> dict[str, Any]:
    """Report step discovery state through StepDiscoveryContractV1 and cogniflow.steps entry points."""
    step_discovery_status = "missing"
    step_discovery_error: str | None = None
    step_packages: list[dict[str, Any]] = []
    step_graphs: list[dict[str, Any]] = []
    processing_steps: list[dict[str, Any]] = []
    step_entry_points: list[dict[str, Any]] = []

    try:
        entry_points = _iter_service_provider_entry_points()
        if ProviderKey.STEP_DISCOVERY in entry_points:
            ep_value = entry_points[ProviderKey.STEP_DISCOVERY]
            load_ok, load_err = _safe_load_entry_point(ep_value)
            step_discovery_status = "resolved" if load_ok else "load_error"
            if not load_ok:
                step_discovery_error = load_err
        else:
            step_discovery_status = "missing_entry_point"
    except Exception as exc:
        step_discovery_status = "error"
        step_discovery_error = str(exc)

    if step_discovery_status == "resolved":
        try:
            step_discovery = require_provider(ProviderKey.STEP_DISCOVERY)
            step_packages = list(step_discovery.get_step_packages() or [])
            processing_steps = list(step_discovery.get_processing_steps() or [])
        except Exception as exc:
            step_discovery_error = str(exc)
            step_discovery_status = "error"

    try:
        from importlib.metadata import entry_points as eps

        try:
            step_eps = eps(group="cogniflow.steps")
        except TypeError:
            step_eps = eps().select(group="cogniflow.steps")
        for ep in step_eps:
            step_entry_points.append(
                {
                    "name": ep.name,
                    "value": ep.value,
                }
            )
    except Exception as exc:
        step_entry_points = []
        if step_discovery_error is None:
            step_discovery_error = f"step entry-point enumeration failed: {exc}"

    try:
        semantics_runtime = get_provider(ProviderKey.SEMANTICS_RUNTIME)
        if semantics_runtime is not None:
            graphs = semantics_runtime.list_step_graphs()
            step_graphs = [
                {
                    "graph_id": g.get("graph_id"),
                    "graph_type": g.get("graph_type"),
                    "graph_kind": g.get("graph_kind"),
                    "aliases": g.get("aliases", []),
                }
                for g in graphs
            ]
    except Exception:
        pass

    return {
        "schema_version": "cf_doctor_steps.v1",
        "step_discovery": {
            "provider_key": ProviderKey.STEP_DISCOVERY,
            "status": step_discovery_status,
            "error": step_discovery_error,
        },
        "step_packages": step_packages,
        "processing_steps": [
            {
                "graph_id": s.get("graph_id"),
                "graph_type": s.get("graph_type"),
                "graph_kind": s.get("graph_kind"),
                "aliases": s.get("aliases", []),
            }
            for s in processing_steps
        ],
        "step_graphs": step_graphs,
        "step_entry_points": step_entry_points,
        "missing_providers": []
        if step_discovery_status in {"resolved", "error"}
        else [ProviderKey.STEP_DISCOVERY],
    }


def run_runtime_diagnostics() -> dict[str, Any]:
    """Report runtime state: pipeline manager, engine runner, pipeline runtime, DataHive."""
    pipeline_manager_status = "missing"
    pipeline_manager_error: str | None = None
    pipeline_runtime_status = "missing"
    pipeline_runtime_error: str | None = None
    engine_runner_status = "missing"
    engine_runner_error: str | None = None
    datahive_status = "missing"
    datahive_error: str | None = None
    engine_executable: str | None = None
    runtime_summaries: dict[str, Any] = {}
    manager_status: dict[str, Any] = {}

    entry_points = _iter_service_provider_entry_points()

    # Pipeline manager
    if ProviderKey.PIPELINE_MANAGER in entry_points:
        ep_value = entry_points[ProviderKey.PIPELINE_MANAGER]
        load_ok, load_err = _safe_load_entry_point(ep_value)
        pipeline_manager_status = "resolved" if load_ok else "load_error"
        if not load_ok:
            pipeline_manager_error = load_err
    else:
        pipeline_manager_status = "missing_entry_point"

    if pipeline_manager_status == "resolved":
        try:
            pipeline_manager = require_provider(ProviderKey.PIPELINE_MANAGER)
            manager_status = dict(pipeline_manager.status() or {})
        except Exception as exc:
            pipeline_manager_error = str(exc)
            pipeline_manager_status = "error"

    # Pipeline runtime
    if ProviderKey.PIPELINE_RUNTIME in entry_points:
        ep_value = entry_points[ProviderKey.PIPELINE_RUNTIME]
        load_ok, load_err = _safe_load_entry_point(ep_value)
        pipeline_runtime_status = "resolved" if load_ok else "load_error"
        if not load_ok:
            pipeline_runtime_error = load_err
    else:
        pipeline_runtime_status = "missing_entry_point"

    if pipeline_runtime_status == "resolved":
        try:
            pipeline_runtime = require_provider(ProviderKey.PIPELINE_RUNTIME)
            runtime_summaries = dict(pipeline_runtime.list_runtime_summaries() or {})
        except Exception as exc:
            pipeline_runtime_error = str(exc)
            pipeline_runtime_status = "error"

    # Engine runner
    if ProviderKey.ENGINE_RUNNER in entry_points:
        ep_value = entry_points[ProviderKey.ENGINE_RUNNER]
        load_ok, load_err = _safe_load_entry_point(ep_value)
        engine_runner_status = "resolved" if load_ok else "load_error"
        if not load_ok:
            engine_runner_error = load_err
    else:
        engine_runner_status = "missing_entry_point"

    if engine_runner_status == "resolved":
        try:
            engine_runner = require_provider(ProviderKey.ENGINE_RUNNER)
            engine_executable = str(engine_runner.resolve_cf_pipeline_v2_executable())
        except Exception as exc:
            engine_runner_error = str(exc)
            engine_runner_status = "error"

    # DataHive runs
    if ProviderKey.DATAHIVE_RUNS in entry_points:
        ep_value = entry_points[ProviderKey.DATAHIVE_RUNS]
        load_ok, load_err = _safe_load_entry_point(ep_value)
        datahive_status = "resolved" if load_ok else "load_error"
        if not load_ok:
            datahive_error = load_err
    else:
        datahive_status = "missing_entry_point"

    if datahive_status == "resolved":
        try:
            datahive = require_provider(ProviderKey.DATAHIVE_RUNS)
            from pathlib import Path

            workspace = resolve_workspace_dir()
            datahive.resolve_data_hive_root(workspace)
        except Exception as exc:
            datahive_error = str(exc)
            datahive_status = "error"

    missing_providers = [
        key
        for key, status in [
            (ProviderKey.PIPELINE_MANAGER, pipeline_manager_status),
            (ProviderKey.PIPELINE_RUNTIME, pipeline_runtime_status),
            (ProviderKey.ENGINE_RUNNER, engine_runner_status),
            (ProviderKey.DATAHIVE_RUNS, datahive_status),
        ]
        if status in {"missing_entry_point", "load_error"}
    ]

    return {
        "schema_version": "cf_doctor_runtime.v1",
        "pipeline_manager": {
            "provider_key": ProviderKey.PIPELINE_MANAGER,
            "status": pipeline_manager_status,
            "manager_status": manager_status,
            "error": pipeline_manager_error,
        },
        "pipeline_runtime": {
            "provider_key": ProviderKey.PIPELINE_RUNTIME,
            "status": pipeline_runtime_status,
            "runtime_summaries": runtime_summaries,
            "error": pipeline_runtime_error,
        },
        "engine_runner": {
            "provider_key": ProviderKey.ENGINE_RUNNER,
            "status": engine_runner_status,
            "engine_executable": engine_executable,
            "error": engine_runner_error,
        },
        "datahive_runs": {
            "provider_key": ProviderKey.DATAHIVE_RUNS,
            "status": datahive_status,
            "error": datahive_error,
        },
        "missing_providers": missing_providers,
    }


def run_setup_diagnostics() -> dict[str, Any]:
    """Report setup orchestration state and contract consumption evidence."""
    from pathlib import Path

    setup_contract_status = "missing"
    setup_contract_error: str | None = None
    try:
        entry_points = _iter_service_provider_entry_points()
        if ProviderKey.SETUP_ORCHESTRATION in entry_points:
            ep_value = entry_points[ProviderKey.SETUP_ORCHESTRATION]
            load_ok, load_err = _safe_load_entry_point(ep_value)
            setup_contract_status = "resolved" if load_ok else "load_error"
            if not load_ok:
                setup_contract_error = load_err
        else:
            setup_contract_status = "missing_entry_point"
    except Exception as exc:
        setup_contract_status = "error"
        setup_contract_error = str(exc)

    # Prerequisite diagnostics via contract surface
    prerequisites: dict[str, Any] = {}
    prerequisite_error: str | None = None
    try:
        from .service_contract_provider import SetupOrchestrationProvider

        provider = SetupOrchestrationProvider()
        prerequisites = provider.diagnose_prerequisites()
    except Exception as exc:
        prerequisite_error = str(exc)

    # Provider registry refresh capability evidence
    registry_refresh_status = "unknown"
    registry_refresh_error: str | None = None
    try:
        workspace_dir = resolve_workspace_dir()
        registry_path = provider_registry_path_for_workspace(workspace_dir)
        registry_refresh_status = "path_computed"
    except Exception as exc:
        registry_refresh_error = str(exc)

    # Setup plan / dry-run capability evidence
    # plan_installation does not take dry_run; dry-run is handled at execute_install level.
    install_dry_run_capable = True
    plan_error: str | None = None
    try:
        import dataclasses
        from .installer import InstallerOptions

        field_names = {f.name for f in dataclasses.fields(InstallerOptions)}
        install_dry_run_capable = "dry_run" in field_names
    except Exception as exc:
        plan_error = str(exc)

    # Setup bootstrap path classification (non-runtime)
    bootstrap_paths = [
        {
            "path": "cf_setup/install_manifest.toml",
            "owner": "cf-setup",
            "classification": "setup_bootstrap",
            "reason": "Setup manifest used for installation planning.",
        },
        {
            "path": "cf_ontology/ontology/foundations/contracts/service_contracts.nq",
            "owner": "cf-ontology",
            "classification": "setup_bootstrap",
            "reason": "Ontology provider vocabulary used for registry refresh and contract diagnostics.",
        },
    ]

    # Contract consumption audit for setup-adjacent paths
    contract_consumption = {
        "setup_orchestration": setup_contract_status,
        "setup_bootstrap": "contract_bound",
        "pipeline_authoring": "contract_bound",
        "pipeline_manager": "contract_bound",
        "datahive_runs": "contract_bound",
        "semantics_store": "contract_bound",
    }

    return {
        "schema_version": "cf_doctor_setup.v1",
        "setup_contract": {
            "provider_key": ProviderKey.SETUP_ORCHESTRATION,
            "status": setup_contract_status,
            "error": setup_contract_error,
        },
        "prerequisites": {
            "status": "resolved" if not prerequisite_error else "error",
            "tools": prerequisites,
            "error": prerequisite_error,
        },
        "provider_registry_refresh": {
            "status": registry_refresh_status,
            "workspace_registry_path": str(registry_path) if registry_refresh_status == "path_computed" else None,
            "error": registry_refresh_error,
        },
        "plan_capability": {
            "install_dry_run_capable": install_dry_run_capable,
            "error": plan_error,
        },
        "bootstrap_paths": bootstrap_paths,
        "contract_consumption": contract_consumption,
        "bypass_findings": [],
    }
