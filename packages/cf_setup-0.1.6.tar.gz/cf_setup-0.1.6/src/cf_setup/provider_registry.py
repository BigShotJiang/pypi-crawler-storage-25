from __future__ import annotations

from dataclasses import dataclass
from importlib import metadata
import json
from pathlib import Path
import re
from urllib.parse import urlparse
from urllib.request import url2pathname

from cf_service_contracts import ProviderKey


PROVIDER_REGISTRY_ENV = "CF_PROVIDER_REGISTRY_PATH"
PROVIDER_REGISTRY_FILENAME = "provider_registry.v1.json"
PROVIDER_REGISTRY_SCHEMA = "provider_registry.v1"
PROVIDER_DESCRIPTOR_SCHEMA = "provider_descriptor.v1"
_CF_BASE = "https://cogniflow.odea-project.org/cf#"
_RDF_TYPE = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
_SERVICE_PROVIDER = f"{_CF_BASE}ServiceProvider"
_SERVICE_CONSUMER = f"{_CF_BASE}ServiceConsumer"
_PROVIDER_KIND = f"{_CF_BASE}providerKind"
_PROVIDER_KEY = f"{_CF_BASE}providerKey"
_PROVIDES_CONTRACT = f"{_CF_BASE}providesContract"
_CONSUMER_KEY = f"{_CF_BASE}consumerKey"
_CONSUMES_CONTRACT = f"{_CF_BASE}consumesContract"
_ENTRY_POINT_GROUP = f"{_CF_BASE}entryPointGroup"
_ENTRY_POINT_NAME = f"{_CF_BASE}entryPointName"
_CONTRACT_SYMBOL = f"{_CF_BASE}contractSymbol"
_DESCRIPTOR_SCHEMA_VERSION = f"{_CF_BASE}descriptorSchemaVersion"
_PYTHON_PROVIDER_KIND = f"{_CF_BASE}provider_kind_python_entry_point"
_NATIVE_PROVIDER_KIND = f"{_CF_BASE}provider_kind_native_registry"
_CONTRACT_VERSION = f"{_CF_BASE}contractVersion"
_CONTRACT_SCOPE = f"{_CF_BASE}contractScope"
_ONTOLOGY_PROVIDER_VOCAB_RELATIVE = Path(
    "sandcastle/cf_ontology/src/cf_ontology/ontology/foundations/contracts/service_contracts.nq"
)
_INSTALLED_ONTOLOGY_PROVIDER_VOCAB = Path(
    "cf_ontology/ontology/foundations/contracts/service_contracts.nq"
)
_EDITABLE_ONTOLOGY_PROVIDER_VOCAB = Path(
    "src/cf_ontology/ontology/foundations/contracts/service_contracts.nq"
)
_IRI_TRIPLE_RE = re.compile(
    r"^<(?P<subj>[^>]+)>\s+<(?P<pred>[^>]+)>\s+<(?P<obj>[^>]+)>\s+\.$"
)
_LITERAL_TRIPLE_RE = re.compile(
    r'^<(?P<subj>[^>]+)>\s+<(?P<pred>[^>]+)>\s+"(?P<obj>(?:[^"\\]|\\.)*)"(?:\^\^<(?P<dtype>[^>]+)>)?\s+\.$'
)
_PROVIDER_KEY_REF_RE = re.compile(r"ProviderKey\.([A-Z_]+)")


@dataclass(frozen=True)
class ProviderPackage:
    package_name: str
    import_package_name: str
    source_package_dir: str
    repo_project_dir: str
    descriptor_relative_path: str


@dataclass(frozen=True)
class ProviderRegistryRefreshResult:
    path: Path
    payload: dict[str, object]


@dataclass(frozen=True)
class OntologyProviderSemantics:
    iri: str
    provider_key: str
    provider_kind: str
    entry_point_group: str | None = None
    entry_point_name: str | None = None
    contract_symbol: str | None = None
    descriptor_schema_version: str | None = None


@dataclass(frozen=True)
class OntologyConsumerSemantics:
    iri: str
    consumer_key: str
    contract_keys: frozenset[str]


@dataclass(frozen=True)
class ConsumerPackageSurface:
    consumer_key: str
    source_root: str


@dataclass(frozen=True)
class OntologyContractSemantics:
    iri: str
    contract_name: str
    contract_version: str | None
    scope_iri: str | None
    provider_key: str | None


PROVIDER_PACKAGES = (
    ProviderPackage(
        package_name="cf-pipeline-sdk",
        import_package_name="cogniflow_pipeline_sdk",
        source_package_dir="src/cogniflow_pipeline_sdk",
        repo_project_dir="sandcastle/cf_pipeline/cf_pipeline_sdk",
        descriptor_relative_path="cogniflow_pipeline_sdk/provider_descriptor.v1.json",
    ),
    ProviderPackage(
        package_name="cf-opcua-server",
        import_package_name="cf_opcua_server",
        source_package_dir="src/cf_opcua_server",
        repo_project_dir="sandcastle/cf_opcua_server",
        descriptor_relative_path="cf_opcua_server/provider_descriptor.v1.json",
    ),
    ProviderPackage(
        package_name="cf-datahive",
        import_package_name="cf_datahive",
        source_package_dir="src/cf_datahive",
        repo_project_dir="sandcastle/cf_datahive",
        descriptor_relative_path="cf_datahive/provider_descriptor.v1.json",
    ),
    ProviderPackage(
        package_name="cf-workspace-store",
        import_package_name="cf_workspace_store",
        source_package_dir="src/cf_workspace_store",
        repo_project_dir="sandcastle/cf_workspace_store",
        descriptor_relative_path="cf_workspace_store/provider_descriptor.v1.json",
    ),
)

CONSUMER_PACKAGE_SURFACES = (
    ConsumerPackageSurface("cf_web_backend", "sandcastle/cf_web/src"),
    ConsumerPackageSurface(
        "cf_pipeline_manager", "sandcastle/cf_pipeline/cf_pipeline_manager/src"
    ),
    ConsumerPackageSurface(
        "cf_pipeline_creator", "sandcastle/cf_pipeline/cf_pipeline_creator/src"
    ),
    ConsumerPackageSurface("cf_setup", "sandcastle/cf_setup/src"),
    ConsumerPackageSurface("cf_iri_site", "sandcastle/cf_iri_site/src"),
    ConsumerPackageSurface(
        "cf_semantics_runtime", "sandcastle/cf_semantics_runtime/src"
    ),
)


def provider_registry_path_for_workspace(workspace_dir: Path) -> Path:
    return (workspace_dir / "runtime" / PROVIDER_REGISTRY_FILENAME).resolve()


def _try_distribution_file(
    distribution: metadata.Distribution, relative_path: str
) -> Path | None:
    candidate = Path(distribution.locate_file(Path(relative_path))).resolve()
    if candidate.exists():
        return candidate
    return None


def _read_direct_url_payload(
    distribution: metadata.Distribution,
) -> dict[str, object] | None:
    text = distribution.read_text("direct_url.json")
    if not text:
        return None
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return None
    return payload if isinstance(payload, dict) else None


def _editable_project_root(distribution: metadata.Distribution) -> Path | None:
    payload = _read_direct_url_payload(distribution)
    if not payload:
        return None
    dir_info = payload.get("dir_info")
    if not isinstance(dir_info, dict) or not dir_info.get("editable"):
        return None
    raw_url = payload.get("url")
    if not isinstance(raw_url, str) or not raw_url.strip():
        return None
    parsed = urlparse(raw_url)
    if parsed.scheme != "file":
        return None
    path = url2pathname(parsed.path or "")
    if parsed.netloc:
        path = f"//{parsed.netloc}{path}"
    candidate = Path(path)
    if candidate.exists():
        return candidate.resolve()
    return None


def _editable_descriptor_path(
    distribution: metadata.Distribution, package: ProviderPackage
) -> Path | None:
    project_root = _editable_project_root(distribution)
    if project_root is None:
        return None
    candidate = (
        project_root
        / package.source_package_dir
        / Path(package.descriptor_relative_path).name
    ).resolve()
    if candidate.exists():
        return candidate
    return None


def _locate_descriptor(
    distribution: metadata.Distribution, package: ProviderPackage
) -> Path | None:
    descriptor_path = _try_distribution_file(
        distribution, package.descriptor_relative_path
    )
    if descriptor_path is not None:
        return descriptor_path
    return _editable_descriptor_path(distribution, package)


def _resolve_first_existing(
    distribution: metadata.Distribution, candidates: list[str]
) -> Path | None:
    for relative_path in candidates:
        candidate = _try_distribution_file(distribution, relative_path)
        if candidate is not None:
            return candidate
    return None


def _distribution_or_none(package_name: str) -> metadata.Distribution | None:
    try:
        return metadata.distribution(package_name)
    except metadata.PackageNotFoundError:
        return None


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[4]


def _locate_ontology_provider_vocab() -> Path:
    repo_candidate = (_repo_root() / _ONTOLOGY_PROVIDER_VOCAB_RELATIVE).resolve()
    if repo_candidate.exists():
        return repo_candidate

    distribution = _distribution_or_none("cf-ontology")
    if distribution is None:
        raise FileNotFoundError(
            "Ontology provider vocabulary not found. Checked repo path "
            f"{repo_candidate} and no installed cf-ontology distribution was available."
        )

    installed_candidate = _try_distribution_file(
        distribution, str(_INSTALLED_ONTOLOGY_PROVIDER_VOCAB)
    )
    if installed_candidate is not None:
        return installed_candidate

    editable_root = _editable_project_root(distribution)
    if editable_root is not None:
        editable_candidate = (
            editable_root / _EDITABLE_ONTOLOGY_PROVIDER_VOCAB
        ).resolve()
        if editable_candidate.exists():
            return editable_candidate

    raise FileNotFoundError(
        "Ontology provider vocabulary not found in cf-ontology distribution. "
        f"Checked {_INSTALLED_ONTOLOGY_PROVIDER_VOCAB} and {_EDITABLE_ONTOLOGY_PROVIDER_VOCAB}."
    )


def _iter_nquads_lines(path: Path) -> list[str]:
    return [
        line.strip()
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def _decode_literal(value: str) -> str:
    return json.loads(f'"{value}"')


def _load_ontology_provider_semantics() -> list[OntologyProviderSemantics]:
    path = _locate_ontology_provider_vocab()
    type_map: dict[str, str] = {}
    fields: dict[str, dict[str, str]] = {}

    for line in _iter_nquads_lines(path):
        iri_match = _IRI_TRIPLE_RE.match(line)
        if iri_match:
            subj = iri_match.group("subj")
            pred = iri_match.group("pred")
            obj = iri_match.group("obj")
            if pred == _RDF_TYPE:
                type_map[subj] = obj
                continue
            fields.setdefault(subj, {})[pred] = obj
            continue

        literal_match = _LITERAL_TRIPLE_RE.match(line)
        if literal_match:
            subj = literal_match.group("subj")
            pred = literal_match.group("pred")
            obj = _decode_literal(literal_match.group("obj"))
            fields.setdefault(subj, {})[pred] = obj

    providers: list[OntologyProviderSemantics] = []
    for subj, rdf_type in type_map.items():
        if rdf_type != _SERVICE_PROVIDER:
            continue
        values = fields.get(subj, {})
        provider_key = values.get(_PROVIDER_KEY)
        provider_kind = values.get(_PROVIDER_KIND)
        if not provider_key or not provider_kind:
            continue
        providers.append(
            OntologyProviderSemantics(
                iri=subj,
                provider_key=provider_key,
                provider_kind=provider_kind,
                entry_point_group=values.get(_ENTRY_POINT_GROUP),
                entry_point_name=values.get(_ENTRY_POINT_NAME),
                contract_symbol=values.get(_CONTRACT_SYMBOL),
                descriptor_schema_version=values.get(_DESCRIPTOR_SCHEMA_VERSION),
            )
        )

    return providers


def _contract_key_by_contract_iri(path: Path) -> dict[str, str]:
    type_map: dict[str, str] = {}
    fields: dict[str, dict[str, str]] = {}
    for line in _iter_nquads_lines(path):
        iri_match = _IRI_TRIPLE_RE.match(line)
        if iri_match:
            subj = iri_match.group("subj")
            pred = iri_match.group("pred")
            obj = iri_match.group("obj")
            if pred == _RDF_TYPE:
                type_map[subj] = obj
                continue
            fields.setdefault(subj, {})[pred] = obj
            continue
        literal_match = _LITERAL_TRIPLE_RE.match(line)
        if literal_match:
            subj = literal_match.group("subj")
            pred = literal_match.group("pred")
            obj = _decode_literal(literal_match.group("obj"))
            fields.setdefault(subj, {})[pred] = obj
    contract_key_by_iri: dict[str, str] = {}
    for subj, rdf_type in type_map.items():
        if rdf_type != _SERVICE_PROVIDER:
            continue
        values = fields.get(subj, {})
        provider_key = values.get(_PROVIDER_KEY)
        contract_iri = values.get(_PROVIDES_CONTRACT)
        if provider_key and contract_iri:
            contract_key_by_iri[contract_iri] = provider_key
    return contract_key_by_iri


def _load_ontology_consumer_semantics() -> list[OntologyConsumerSemantics]:
    path = _locate_ontology_provider_vocab()
    type_map: dict[str, str] = {}
    literal_fields: dict[str, dict[str, str]] = {}
    iri_fields: dict[str, dict[str, list[str]]] = {}
    contract_key_by_iri = _contract_key_by_contract_iri(path)

    for line in _iter_nquads_lines(path):
        iri_match = _IRI_TRIPLE_RE.match(line)
        if iri_match:
            subj = iri_match.group("subj")
            pred = iri_match.group("pred")
            obj = iri_match.group("obj")
            if pred == _RDF_TYPE:
                type_map[subj] = obj
                continue
            iri_fields.setdefault(subj, {}).setdefault(pred, []).append(obj)
            continue
        literal_match = _LITERAL_TRIPLE_RE.match(line)
        if literal_match:
            subj = literal_match.group("subj")
            pred = literal_match.group("pred")
            obj = _decode_literal(literal_match.group("obj"))
            literal_fields.setdefault(subj, {})[pred] = obj

    consumers: list[OntologyConsumerSemantics] = []
    for subj, rdf_type in type_map.items():
        if rdf_type != _SERVICE_CONSUMER:
            continue
        consumer_key = literal_fields.get(subj, {}).get(_CONSUMER_KEY)
        contract_iris = iri_fields.get(subj, {}).get(_CONSUMES_CONTRACT, [])
        contract_keys = frozenset(
            contract_key_by_iri[contract_iri]
            for contract_iri in contract_iris
            if contract_iri in contract_key_by_iri
        )
        if not consumer_key:
            continue
        consumers.append(
            OntologyConsumerSemantics(
                iri=subj,
                consumer_key=consumer_key,
                contract_keys=contract_keys,
            )
        )
    return consumers


def _python_provider_key_constants() -> set[str]:
    keys: set[str] = set()
    for name in dir(ProviderKey):
        if not name.isupper():
            continue
        value = getattr(ProviderKey, name)
        if isinstance(value, str):
            keys.add(value)
    return keys


def _list_service_provider_entry_points() -> list[tuple[str, str]]:
    entry_points = metadata.entry_points()
    if hasattr(entry_points, "select"):
        selected = entry_points.select(group="cogniflow.service_providers")
    elif isinstance(entry_points, dict):
        selected = entry_points.get("cogniflow.service_providers", [])
    else:
        selected = entry_points
    return [(entry_point.name, entry_point.value) for entry_point in selected]


def _iter_service_provider_entry_points() -> dict[str, str]:
    return dict(_list_service_provider_entry_points())


def _validate_python_provider_semantics(
    ontology_providers: list[OntologyProviderSemantics],
    entry_points: dict[str, str],
) -> None:
    python_providers = [
        provider
        for provider in ontology_providers
        if provider.provider_kind == _PYTHON_PROVIDER_KIND
    ]
    ontology_keys = {provider.provider_key for provider in python_providers}
    provider_key_constants = _python_provider_key_constants()
    if ontology_keys != provider_key_constants:
        missing_in_ontology = sorted(provider_key_constants - ontology_keys)
        missing_in_provider_key = sorted(ontology_keys - provider_key_constants)
        raise ValueError(
            "Python provider ontology keys do not match cf_service_contracts.ProviderKey. "
            f"Missing in ontology: {missing_in_ontology}; missing in ProviderKey: {missing_in_provider_key}."
        )

    entry_point_names = set(entry_points)
    if ontology_keys != entry_point_names:
        missing_in_ontology = sorted(entry_point_names - ontology_keys)
        missing_in_entry_points = sorted(ontology_keys - entry_point_names)
        raise ValueError(
            "Python provider ontology keys do not match installed cogniflow.service_providers entry points. "
            f"Missing in ontology: {missing_in_ontology}; missing in entry points: {missing_in_entry_points}."
        )

    for provider in python_providers:
        key = provider.provider_key
        if provider.entry_point_group != "cogniflow.service_providers":
            raise ValueError(
                f"Ontology python provider {key!r} must declare entryPointGroup "
                "'cogniflow.service_providers'."
            )
        if provider.entry_point_name != key:
            raise ValueError(
                f"Ontology python provider {key!r} must declare entryPointName equal to providerKey; "
                f"got {provider.entry_point_name!r}."
            )


def validate_python_provider_semantics() -> None:
    ontology_providers = _load_ontology_provider_semantics()
    _validate_python_provider_semantics(
        ontology_providers, _iter_service_provider_entry_points()
    )


def _package_provider_keys(source_root: Path) -> set[str]:
    keys: set[str] = set()
    for path in source_root.rglob("*.py"):
        text = path.read_text(encoding="utf-8")
        for match in _PROVIDER_KEY_REF_RE.finditer(text):
            attr_name = match.group(1)
            value = getattr(ProviderKey, attr_name, None)
            if isinstance(value, str):
                keys.add(value)
    return keys


def _validate_python_consumer_semantics(
    ontology_consumers: list[OntologyConsumerSemantics],
    package_contract_usage: dict[str, set[str]],
) -> None:
    ontology_by_key = {
        consumer.consumer_key: consumer for consumer in ontology_consumers
    }
    expected_keys = {surface.consumer_key for surface in CONSUMER_PACKAGE_SURFACES}
    ontology_keys = set(ontology_by_key)
    if ontology_keys != expected_keys:
        missing_in_ontology = sorted(expected_keys - ontology_keys)
        extra_in_ontology = sorted(ontology_keys - expected_keys)
        raise ValueError(
            "Service consumer keys do not match the configured package-level consumer surfaces. "
            f"Missing in ontology: {missing_in_ontology}; extra in ontology: {extra_in_ontology}."
        )

    for consumer_key, observed_contract_keys in package_contract_usage.items():
        declared_contract_keys = ontology_by_key[consumer_key].contract_keys
        if declared_contract_keys != observed_contract_keys:
            missing_in_ontology = sorted(
                observed_contract_keys - declared_contract_keys
            )
            missing_in_code = sorted(declared_contract_keys - observed_contract_keys)
            raise ValueError(
                f"Service consumer contract usage drift for {consumer_key!r}. "
                f"Missing in ontology: {missing_in_ontology}; missing in code: {missing_in_code}."
            )


def validate_python_consumer_semantics(*, distribution_mode: bool = False) -> None:
    """Validate that ontology consumer contract declarations match code usage.

    In distribution mode the source roots declared in CONSUMER_PACKAGE_SURFACES
    are not available (the package is installed from PyPI and there is no local
    repository checkout).  _repo_root() returns a heuristic path that is unreliable
    outside the repository.  To avoid a false drift failure we skip the per-surface
    source scan and only verify that the ontology consumer keys match the configured
    surface keys (structural check), without scanning source files for ProviderKey
    references.
    """
    ontology_consumers = _load_ontology_consumer_semantics()
    if distribution_mode:
        # In distribution mode: verify ontology consumer keys match configured
        # surface keys, but do not scan source files (no repository checkout available).
        expected_keys = {surface.consumer_key for surface in CONSUMER_PACKAGE_SURFACES}
        ontology_keys = {consumer.consumer_key for consumer in ontology_consumers}
        if ontology_keys != expected_keys:
            missing_in_ontology = sorted(expected_keys - ontology_keys)
            extra_in_ontology = sorted(ontology_keys - expected_keys)
            raise ValueError(
                "Service consumer keys do not match the configured package-level consumer surfaces. "
                f"Missing in ontology: {missing_in_ontology}; extra in ontology: {extra_in_ontology}."
            )
        return
    package_contract_usage = {
        surface.consumer_key: _package_provider_keys(
            (_repo_root() / surface.source_root).resolve()
        )
        for surface in CONSUMER_PACKAGE_SURFACES
    }
    _validate_python_consumer_semantics(ontology_consumers, package_contract_usage)


def load_ontology_contract_semantics() -> list[OntologyContractSemantics]:
    path = _locate_ontology_provider_vocab()
    type_map: dict[str, str] = {}
    literal_fields: dict[str, dict[str, str]] = {}
    iri_fields: dict[str, dict[str, list[str]]] = {}

    for line in _iter_nquads_lines(path):
        iri_match = _IRI_TRIPLE_RE.match(line)
        if iri_match:
            subj = iri_match.group("subj")
            pred = iri_match.group("pred")
            obj = iri_match.group("obj")
            if pred == _RDF_TYPE:
                type_map[subj] = obj
                continue
            iri_fields.setdefault(subj, {}).setdefault(pred, []).append(obj)
            continue

        literal_match = _LITERAL_TRIPLE_RE.match(line)
        if literal_match:
            subj = literal_match.group("subj")
            pred = literal_match.group("pred")
            obj = _decode_literal(literal_match.group("obj"))
            literal_fields.setdefault(subj, {})[pred] = obj

    contract_key_by_iri = _contract_key_by_contract_iri(path)

    contracts: list[OntologyContractSemantics] = []
    for subj, rdf_type in type_map.items():
        if rdf_type != f"{_CF_BASE}ServiceContract":
            continue
        values = literal_fields.get(subj, {})
        version = values.get(_CONTRACT_VERSION)
        scope_iris = iri_fields.get(subj, {}).get(_CONTRACT_SCOPE, [])
        scope_iri = scope_iris[0] if scope_iris else None
        contract_name = subj.split("#")[-1] if "#" in subj else subj.split("/")[-1]
        provider_key = contract_key_by_iri.get(subj)
        contracts.append(
            OntologyContractSemantics(
                iri=subj,
                contract_name=contract_name,
                contract_version=version,
                scope_iri=scope_iri,
                provider_key=provider_key,
            )
        )
    return contracts


def _validate_native_provider_semantics(
    ontology_providers: list[OntologyProviderSemantics],
    provider_key: str,
    contract_symbol: str,
    schema_version: str,
) -> None:
    provider = next(
        (
            row
            for row in ontology_providers
            if row.provider_key == provider_key
            and row.provider_kind == _NATIVE_PROVIDER_KIND
        ),
        None,
    )
    if provider is None:
        raise ValueError(
            f"Native provider {provider_key!r} is missing from the ontology provider model."
        )
    if provider.contract_symbol != contract_symbol:
        raise ValueError(
            f"Ontology contractSymbol mismatch for native provider {provider_key!r}: "
            f"{provider.contract_symbol!r} != {contract_symbol!r}."
        )
    if provider.descriptor_schema_version != schema_version:
        raise ValueError(
            f"Ontology descriptorSchemaVersion mismatch for native provider {provider_key!r}: "
            f"{provider.descriptor_schema_version!r} != {schema_version!r}."
        )


def _missing_descriptor_error(
    package: ProviderPackage, distribution: metadata.Distribution
) -> FileNotFoundError:
    installed_candidate = Path(
        distribution.locate_file(Path(package.descriptor_relative_path))
    ).resolve()
    editable_root = _editable_project_root(distribution)
    editable_candidate = (
        (
            editable_root
            / package.source_package_dir
            / Path(package.descriptor_relative_path).name
        ).resolve()
        if editable_root is not None
        else None
    )
    checked_paths = [str(installed_candidate)]
    if editable_candidate is not None:
        checked_paths.append(str(editable_candidate))
    return FileNotFoundError(
        "Provider descriptor for "
        f"{package.package_name} not found. Checked: {', '.join(checked_paths)} "
        f"(repo project hint: {package.repo_project_dir})."
    )


def build_provider_registry_payload() -> dict[str, object]:
    ontology_providers = _load_ontology_provider_semantics()
    providers: dict[str, dict[str, object]] = {}

    for package in PROVIDER_PACKAGES:
        distribution = _distribution_or_none(package.package_name)
        if distribution is None:
            continue

        descriptor_path = _locate_descriptor(distribution, package)
        if descriptor_path is None:
            raise _missing_descriptor_error(package, distribution)

        descriptor = json.loads(descriptor_path.read_text(encoding="utf-8"))
        if descriptor.get("schema_version") != PROVIDER_DESCRIPTOR_SCHEMA:
            raise ValueError(
                f"Unsupported provider descriptor schema in {descriptor_path}: {descriptor.get('schema_version')!r}"
            )
        _validate_native_provider_semantics(
            ontology_providers,
            str(descriptor["provider_key"]),
            str(descriptor["contract_symbol"]),
            str(descriptor["schema_version"]),
        )

        library_candidates = [
            str(candidate) for candidate in descriptor.get("library_candidates", [])
        ]
        library_path = _resolve_first_existing(distribution, library_candidates)
        if library_path is None:
            raise FileNotFoundError(
                "Provider library for "
                f"{package.package_name} not found from descriptor {descriptor_path}. "
                f"Checked candidates: {', '.join(library_candidates)}"
            )

        runtime_paths: list[str] = []
        seen_runtime_paths: set[str] = set()
        runtime_dir = library_path.parent
        runtime_key = str(runtime_dir)
        if runtime_key not in seen_runtime_paths:
            seen_runtime_paths.add(runtime_key)
            runtime_paths.append(runtime_key)

        for relative_path in descriptor.get("runtime_dir_candidates", []):
            if not isinstance(relative_path, str):
                continue
            candidate = _try_distribution_file(distribution, relative_path)
            if candidate is None or not candidate.is_dir():
                continue
            runtime_key = str(candidate)
            if runtime_key in seen_runtime_paths:
                continue
            seen_runtime_paths.add(runtime_key)
            runtime_paths.append(runtime_key)

        providers[str(descriptor["provider_key"])] = {
            "package_name": package.package_name,
            "contract_symbol": str(descriptor["contract_symbol"]),
            "contract_version": int(descriptor["contract_version"]),
            "library_path": str(library_path),
            "runtime_paths": runtime_paths,
        }

    return {
        "schema_version": PROVIDER_REGISTRY_SCHEMA,
        "providers": providers,
    }


def refresh_provider_registry(workspace_dir: Path, *, distribution_mode: bool = False) -> ProviderRegistryRefreshResult:
    registry_path = provider_registry_path_for_workspace(workspace_dir)
    registry_path.parent.mkdir(parents=True, exist_ok=True)
    validate_python_provider_semantics()
    validate_python_consumer_semantics(distribution_mode=distribution_mode)
    payload = build_provider_registry_payload()
    registry_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )
    return ProviderRegistryRefreshResult(path=registry_path, payload=payload)
