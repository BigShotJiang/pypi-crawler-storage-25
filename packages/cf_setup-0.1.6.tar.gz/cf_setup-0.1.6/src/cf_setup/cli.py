from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from . import DEFAULT_MANIFEST_PATH
from .installer import (
    build_options_from_namespace,
    detect_execution_mode,
    execute_incremental,
    execute_install,
    manifest_path_from_args,
    output_payload,
    plan_installation,
)
from .providers.windows import WindowsProvider


def _resolve_requested_mode(args: argparse.Namespace, parser: argparse.ArgumentParser) -> str:
    requested_mode = args.mode
    if getattr(args, "dev", False):
        if requested_mode == "distribution":
            parser.error("--dev cannot be combined with --mode distribution")
        requested_mode = "repo"
    return requested_mode

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="cf_setup", description="Cogniflow setup orchestration CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    plan_parser = subparsers.add_parser("plan", help="Resolve profile modules and source decisions.")
    plan_parser.add_argument("--repo-root")
    plan_parser.add_argument("--manifest", default=str(DEFAULT_MANIFEST_PATH))
    plan_parser.add_argument("--profile", default="full")
    plan_parser.add_argument("--editable", action="append", default=[])
    plan_parser.add_argument("--mode", choices=["auto", "repo", "distribution"], default="auto")
    plan_parser.add_argument("--dev", action="store_true", help="Force local repository development mode.")
    plan_parser.add_argument("--format", choices=["json"], default="json")
    plan_parser.add_argument("--output")
    plan_parser.set_defaults(_parser=plan_parser)

    diagnose_parser = subparsers.add_parser("diagnose", help="Report prerequisite diagnostics.")
    diagnose_parser.add_argument("--provider", choices=["windows"], default="windows")
    diagnose_parser.add_argument("--format", choices=["json"], default="json")
    diagnose_parser.add_argument("--output")

    install_parser = subparsers.add_parser("install", help="Execute the setup plan.")
    install_parser.add_argument("--repo-root")
    install_parser.add_argument("--manifest", default=str(DEFAULT_MANIFEST_PATH))
    install_parser.add_argument("--profile", default="full")
    install_parser.add_argument("--mode", choices=["auto", "repo", "distribution"], default="auto")
    install_parser.add_argument("--dev", action="store_true", help="Force local repository development mode.")
    install_parser.add_argument("--python", default=sys.executable)
    install_parser.add_argument("--editable", action="append", default=[])
    install_parser.add_argument("--wheel-only", action=argparse.BooleanOptionalAction, default=True)
    install_parser.add_argument("--delete-native-deps", action="store_true")
    install_parser.add_argument("--skip-native-deps", action="store_true")
    install_parser.add_argument("--auto-install-missing-prereqs", action="store_true")
    install_parser.add_argument("--skip-engine-build", action="store_true")
    install_parser.add_argument("--skip-web-build", action="store_true")
    install_parser.add_argument("--duckdb-version", default="1.4.2")
    install_parser.add_argument("--native-arch", default="x64-windows-static")
    install_parser.add_argument("--show-details", action="store_true")
    install_parser.add_argument("--progress-mode", choices=["batch", "precise"], default="batch")
    install_parser.add_argument("--run-demo", dest="run_demo", action=argparse.BooleanOptionalAction, default=None)
    install_parser.add_argument("--dry-run", action="store_true")
    install_parser.add_argument("--log-path")
    install_parser.add_argument("--event-path")
    install_parser.add_argument("--output")
    install_parser.set_defaults(_parser=install_parser)

    incremental_parser = subparsers.add_parser("incremental", help="Install a module-scoped incremental development slice.")
    incremental_parser.add_argument("--repo-root")
    incremental_parser.add_argument("--manifest", default=str(DEFAULT_MANIFEST_PATH))
    incremental_parser.add_argument("--mode", choices=["auto", "repo", "distribution"], default="auto")
    incremental_parser.add_argument("--dev", action="store_true", help="Force local repository development mode.")
    incremental_parser.add_argument("--python", default=sys.executable)
    incremental_parser.add_argument("--module", action="append", default=[])
    incremental_parser.add_argument("--changed-only", action="store_true")
    incremental_parser.add_argument("--base-ref")
    incremental_parser.add_argument(
        "--include-working-tree",
        dest="include_worktree_changes",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    incremental_parser.add_argument("--editable", action="append", default=[])
    incremental_parser.add_argument("--wheel-only", action=argparse.BooleanOptionalAction, default=True)
    incremental_parser.add_argument("--skip-native-deps", action="store_true")
    incremental_parser.add_argument("--auto-install-missing-prereqs", action="store_true")
    incremental_parser.add_argument("--skip-web-build", action="store_true")
    incremental_parser.add_argument("--duckdb-version", default="1.4.2")
    incremental_parser.add_argument("--native-arch", default="x64-windows-static")
    incremental_parser.add_argument("--show-details", action="store_true")
    incremental_parser.add_argument("--progress-mode", choices=["batch", "precise"], default="batch")
    incremental_parser.add_argument("--smoke", action="store_true")
    incremental_parser.add_argument("--run-demo", action="store_true")
    incremental_parser.add_argument("--dry-run", action="store_true")
    incremental_parser.add_argument("--log-path")
    incremental_parser.add_argument("--event-path")
    incremental_parser.add_argument("--output")
    incremental_parser.set_defaults(_parser=incremental_parser)

    clean_parser = subparsers.add_parser("clean", help="Execute a clean profile.")
    clean_parser.add_argument("--profile", required=True, choices=["repo-clean", "workspace-clean", "full-clean"], help="Clean profile to execute")
    clean_parser.add_argument("--dry-run", action="store_true", help="Show what would be cleaned without making changes")
    clean_parser.add_argument("--yes", action="store_true", help="Confirm destructive cleanup non-interactively")
    clean_parser.add_argument("--format", choices=["json", "text"], default="text", help="Output format")
    clean_parser.set_defaults(_parser=clean_parser, _cf_handler=_handle_clean)

    return parser


def _handle_plan(args: argparse.Namespace) -> int:
    repo_root = Path(args.repo_root).resolve() if args.repo_root else None
    manifest_path = manifest_path_from_args(args.manifest, repo_root or Path.cwd())
    requested_mode = _resolve_requested_mode(args, args._parser)
    manifest, plan = plan_installation(
        manifest_path=manifest_path,
        repo_root=repo_root,
        profile=args.profile,
        editable_overrides=args.editable,
        execution_mode=requested_mode,
    )
    payload = {
        "repo_root": str(repo_root) if repo_root else None,
        "manifest_path": str(manifest.path),
        "execution_mode": detect_execution_mode(repo_root, requested_mode),
        "profile": plan.profile,
        "requested_modules": list(plan.requested_modules),
        "ordered_modules": [
            {
                "package_name": item.package_name,
                "path": item.module.path,
                "source": item.source,
                "reason": item.reason,
                "local_version": item.local_version,
                "pypi_version": item.pypi_version,
                "depends_on": list(item.module.depends_on),
            }
            for item in plan.ordered_modules
        ],
        "hooks": [{"hook_id": hook.hook_id, "action": hook.action} for hook in plan.hooks],
    }
    output_payload(payload, Path(args.output).resolve() if args.output else None)
    return 0


def _handle_diagnose(args: argparse.Namespace) -> int:
    provider = WindowsProvider()
    payload = {"provider": provider.name, "tools": [item.to_dict() for item in provider.diagnose()]}
    output_payload(payload, Path(args.output).resolve() if args.output else None)
    return 0


def _handle_install(args: argparse.Namespace) -> int:
    args.mode = _resolve_requested_mode(args, args._parser)
    options = build_options_from_namespace(args)
    execute_install(options)
    return 0


def _handle_incremental(args: argparse.Namespace) -> int:
    args.mode = _resolve_requested_mode(args, args._parser)
    options = build_options_from_namespace(args)
    execute_incremental(options)
    return 0


def _handle_clean(args: argparse.Namespace) -> int:
    import os
    import shutil
    from pathlib import Path

    profile = args.profile
    dry_run = args.dry_run
    yes = args.yes
    fmt = args.format

    targets: list[str] = []
    if profile in ("repo-clean", "full-clean"):
        targets.append("build")
    if profile in ("workspace-clean", "full-clean"):
        workspace = os.environ.get("COGNIFLOW_HOME")
        if workspace:
            targets.append(workspace)

    if not dry_run and not yes:
        if fmt == "json":
            print(json.dumps({"profile": profile, "mode": "refused", "reason": "requires --yes"}))
        else:
            print(f"{profile.replace('-', ' ').title()} refused: requires --yes")
        return 3

    if dry_run:
        if fmt == "json":
            payload = {"profile": profile, "mode": "dry-run", "targets": targets}
            print(json.dumps(payload))
        else:
            print(f"{profile.replace('-', ' ').title()} dry-run")
            for t in targets:
                print(f"  would remove: {t}")
        return 0

    # Execute
    deleted_count = 0
    for t in targets:
        p = Path(t)
        if p.exists():
            if p.is_dir():
                shutil.rmtree(p)
            else:
                p.unlink()
            deleted_count += 1

    if fmt == "json":
        print(json.dumps({"profile": profile, "mode": "execute", "targets": targets, "deleted_count": deleted_count}))
    else:
        print(f"{profile.replace('-', ' ').title()} executed")
        for t in targets:
            print(f"  removed: {t}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command == "incremental" and not args.changed_only and not args.module:
        parser.error("incremental requires at least one --module value or --changed-only")
    try:
        if args.command == "plan":
            return _handle_plan(args)
        if args.command == "diagnose":
            return _handle_diagnose(args)
        if args.command == "install":
            return _handle_install(args)
        if args.command == "incremental":
            return _handle_incremental(args)
        if args.command == "clean":
            return _handle_clean(args)
        parser.error(f"Unsupported command: {args.command}")
        return 2
    except Exception as exc:
        print(f"cf_setup error: {exc}", file=sys.stderr)
        return 1


def _add_cf_install_parser(subparsers: argparse._SubParsersAction) -> argparse.ArgumentParser:
    parser = subparsers.add_parser("install", help="Install or plan a Cogniflow environment.")
    parser.add_argument("--profile", default="full", choices=["core", "steps", "web", "full"])
    parser.add_argument("--mode", choices=["auto", "repo", "distribution"], default="auto")
    parser.add_argument("--dev", action="store_true", help="Force local repository development mode.")
    parser.add_argument("--repo-root")
    parser.add_argument("--manifest", default=str(DEFAULT_MANIFEST_PATH))
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument("--editable", action="append", default=[])
    parser.add_argument("--wheel-only", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--delete-native-deps", action="store_true")
    parser.add_argument("--skip-native-deps", action="store_true")
    parser.add_argument("--auto-install-missing-prereqs", action="store_true")
    parser.add_argument("--skip-engine-build", action="store_true")
    parser.add_argument("--skip-web-build", action="store_true")
    parser.add_argument("--duckdb-version", default="1.4.2")
    parser.add_argument("--native-arch", default="x64-windows-static")
    parser.add_argument("--show-details", action="store_true")
    parser.add_argument("--progress-mode", choices=["batch", "precise"], default="batch")
    parser.add_argument("--run-demo", dest="run_demo", action=argparse.BooleanOptionalAction, default=None)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--log-path")
    parser.add_argument("--event-path")
    parser.add_argument("--output")
    parser.set_defaults(_parser=parser, _cf_handler=_handle_install)
    return parser


def _add_setup_plan_parser(subparsers: argparse._SubParsersAction) -> argparse.ArgumentParser:
    parser = subparsers.add_parser("plan", help="Resolve profile modules and source decisions.")
    parser.add_argument("--repo-root")
    parser.add_argument("--manifest", default=str(DEFAULT_MANIFEST_PATH))
    parser.add_argument("--profile", default="full")
    parser.add_argument("--editable", action="append", default=[])
    parser.add_argument("--mode", choices=["auto", "repo", "distribution"], default="auto")
    parser.add_argument("--dev", action="store_true", help="Force local repository development mode.")
    parser.add_argument("--format", choices=["json"], default="json")
    parser.add_argument("--output")
    parser.set_defaults(_parser=parser, _cf_handler=_handle_plan)
    return parser


def _add_setup_diagnose_parser(subparsers: argparse._SubParsersAction) -> argparse.ArgumentParser:
    parser = subparsers.add_parser("diagnose", help="Report prerequisite diagnostics.")
    parser.add_argument("--provider", choices=["windows"], default="windows")
    parser.add_argument("--format", choices=["json"], default="json")
    parser.add_argument("--output")
    parser.set_defaults(_cf_handler=_handle_diagnose)
    return parser


def _handle_doctor_providers(args: argparse.Namespace) -> int:
    from .doctor import run_provider_diagnostics

    payload = run_provider_diagnostics()
    output_payload(payload, Path(args.output).resolve() if args.output else None)
    return 0


def _handle_doctor_contracts(args: argparse.Namespace) -> int:
    from .doctor import run_contract_diagnostics

    payload = run_contract_diagnostics()
    output_payload(payload, Path(args.output).resolve() if args.output else None)
    return 0


def _handle_doctor_setup(args: argparse.Namespace) -> int:
    from .doctor import run_setup_diagnostics

    payload = run_setup_diagnostics()
    output_payload(payload, Path(args.output).resolve() if args.output else None)
    return 0


def _handle_doctor_steps(args: argparse.Namespace) -> int:
    from .doctor import run_step_diagnostics

    payload = run_step_diagnostics()
    output_payload(payload, Path(args.output).resolve() if args.output else None)
    return 0


def _handle_doctor_runtime(args: argparse.Namespace) -> int:
    from .doctor import run_runtime_diagnostics

    payload = run_runtime_diagnostics()
    output_payload(payload, Path(args.output).resolve() if args.output else None)
    return 0


def _add_doctor_providers_parser(subparsers: argparse._SubParsersAction) -> argparse.ArgumentParser:
    parser = subparsers.add_parser("providers", help="Diagnose provider discovery and registry state.")
    parser.add_argument("--format", choices=["json"], default="json")
    parser.add_argument("--output")
    parser.set_defaults(_cf_handler=_handle_doctor_providers)
    return parser


def _add_doctor_contracts_parser(subparsers: argparse._SubParsersAction) -> argparse.ArgumentParser:
    parser = subparsers.add_parser("contracts", help="Diagnose contract inventory and consumer mapping.")
    parser.add_argument("--format", choices=["json"], default="json")
    parser.add_argument("--output")
    parser.set_defaults(_cf_handler=_handle_doctor_contracts)
    return parser


def _add_doctor_setup_parser(subparsers: argparse._SubParsersAction) -> argparse.ArgumentParser:
    parser = subparsers.add_parser("setup", help="Diagnose setup orchestration contract state and readiness.")
    parser.add_argument("--format", choices=["json"], default="json")
    parser.add_argument("--output")
    parser.set_defaults(_cf_handler=_handle_doctor_setup)
    return parser


def _add_doctor_steps_parser(subparsers: argparse._SubParsersAction) -> argparse.ArgumentParser:
    parser = subparsers.add_parser("steps", help="Diagnose step discovery and step package entry-point state.")
    parser.add_argument("--format", choices=["json"], default="json")
    parser.add_argument("--output")
    parser.set_defaults(_cf_handler=_handle_doctor_steps)
    return parser


def _add_doctor_runtime_parser(subparsers: argparse._SubParsersAction) -> argparse.ArgumentParser:
    parser = subparsers.add_parser("runtime", help="Diagnose pipeline manager, engine runner, pipeline runtime, and DataHive contract state.")
    parser.add_argument("--format", choices=["json"], default="json")
    parser.add_argument("--output")
    parser.set_defaults(_cf_handler=_handle_doctor_runtime)
    return parser


def _add_setup_clean_parser(subparsers: argparse._SubParsersAction) -> argparse.ArgumentParser:
    parser = subparsers.add_parser("clean", help="Execute a clean profile.")
    parser.add_argument("--profile", required=True, choices=["repo-clean", "workspace-clean", "full-clean"], help="Clean profile to execute")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be cleaned without making changes")
    parser.add_argument("--yes", action="store_true", help="Confirm destructive cleanup non-interactively")
    parser.add_argument("--format", choices=["json", "text"], default="text", help="Output format")
    parser.set_defaults(_parser=parser, _cf_handler=_handle_clean)
    return parser


def register_cli(registry) -> None:
    # Preserve legacy root command
    registry.register_root_command(
        "install",
        _add_cf_install_parser,
        command_help="Install or plan a Cogniflow environment",
    )
    # New setup group commands
    registry.register_command(
        "setup",
        "plan",
        _add_setup_plan_parser,
        group_help="Cogniflow setup commands",
        command_help="Resolve profile modules and source decisions",
    )
    registry.register_command(
        "setup",
        "diagnose",
        _add_setup_diagnose_parser,
        group_help="Cogniflow setup commands",
        command_help="Report prerequisite diagnostics",
    )
    registry.register_command(
        "setup",
        "install",
        _add_cf_install_parser,
        group_help="Cogniflow setup commands",
        command_help="Execute the setup plan",
    )
    registry.register_command(
        "setup",
        "clean",
        _add_setup_clean_parser,
        group_help="Cogniflow setup commands",
        command_help="Execute a clean profile",
    )
    registry.register_command(
        "setup",
        "providers",
        _add_doctor_providers_parser,
        group_help="Cogniflow diagnostic commands",
        command_help="Diagnose provider discovery and registry state",
    )
    registry.register_command(
        "doctor",
        "contracts",
        _add_doctor_contracts_parser,
        group_help="Cogniflow diagnostic commands",
        command_help="Diagnose contract inventory and consumer mapping",
    )
    registry.register_command(
        "doctor",
        "setup",
        _add_doctor_setup_parser,
        group_help="Cogniflow diagnostic commands",
        command_help="Diagnose setup orchestration contract state and readiness",
    )
    registry.register_command(
        "doctor",
        "steps",
        _add_doctor_steps_parser,
        group_help="Cogniflow diagnostic commands",
        command_help="Diagnose step discovery and step package entry-point state",
    )
    registry.register_command(
        "doctor",
        "runtime",
        _add_doctor_runtime_parser,
        group_help="Cogniflow diagnostic commands",
        command_help="Diagnose pipeline manager, engine runner, pipeline runtime, and DataHive contract state",
    )
