"""Cogniflow setup orchestration package."""

from pathlib import Path

__version__ = "0.1.3"
PACKAGE_ROOT = Path(__file__).resolve().parent
DEFAULT_MANIFEST_PATH = PACKAGE_ROOT / "install_manifest.toml"
DISTRIBUTION_MANIFEST_PATH = PACKAGE_ROOT / "install_manifest_distribution.toml"


def find_repo_root(start: Path | None = None) -> Path | None:
    candidate = (start or Path.cwd()).resolve()
    search_roots = [candidate, *candidate.parents]
    for root in search_roots:
        if (root / "sandcastle").exists() and (
            root / "sandcastle" / "cf_setup" / "src" / "cf_setup" / "install_manifest.toml"
        ).exists():
            return root
    return None


REPO_ROOT = find_repo_root(PACKAGE_ROOT) or find_repo_root()

__all__ = ["__version__", "DEFAULT_MANIFEST_PATH", "REPO_ROOT", "find_repo_root"]
